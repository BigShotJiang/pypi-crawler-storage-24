import json
from pathlib import Path
from typing import NoReturn

import pytest

from screenshot._models_plans import BrowserPlan, CapturePlan, RunnerPlan
from screenshot._shared.storage import LocalStorageBackend
from screenshot.models import CaptureOptions, ScreenshotOptions
from screenshot.selenium_runner import (
    _apply_browser_mutations,
    _capture_full_page,
    _capture_url_with_viewports,
    _collect_links,
    _create_driver,
    _failed_entry,
    _scroll_page,
    _SeleniumImportError,
    capture_screenshots_async,
)


@pytest.mark.asyncio
async def test_selenium_runner_missing_dependency(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    def _raise() -> NoReturn:
        raise _SeleniumImportError("Selenium backend unavailable")

    monkeypatch.setattr("screenshot.selenium_runner._load_selenium_modules", _raise)

    result = await capture_screenshots_async(
        "test-job",
        "https://example.com",
        store_dir=tmp_path,
        partition_date=None,
        options=ScreenshotOptions(capture=CaptureOptions(enabled=True)),
        html_snapshot_path=None,
        cancel_token=None,
        storage=None,
    )

    assert result.requested == 0
    assert result.captured == 0
    assert result.failed == 0
    assert result.errors and "Selenium backend unavailable" in result.errors[0].message


@pytest.mark.asyncio
async def test_selenium_runner_disabled_capture_skips_without_loading_dependencies(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    def _raise() -> NoReturn:
        raise AssertionError("selenium modules should not be loaded when capture is disabled")

    monkeypatch.setattr("screenshot.selenium_runner._load_selenium_modules", _raise)

    result = await capture_screenshots_async(
        "disabled-job",
        "https://example.com",
        store_dir=tmp_path,
        partition_date=None,
        options=ScreenshotOptions(capture=CaptureOptions(enabled=False)),
        html_snapshot_path=None,
        cancel_token=None,
        storage=None,
    )

    assert result.requested == 0
    assert result.captured == 0
    assert result.failed == 0
    assert result.metadata_path is None
    assert result.errors == []


@pytest.mark.asyncio
async def test_selenium_navigation_retry_logs(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch, caplog: pytest.LogCaptureFixture
) -> None:
    caplog.set_level("DEBUG")

    # Build fakes returned by _load_selenium_modules()
    class TimeoutException(Exception):
        pass

    class WebDriverException(Exception):
        pass

    class Options:
        def __init__(self) -> None:
            self.binary_location = None

        def add_argument(self, *_args: object) -> None:
            return None

    class _Driver:
        def __init__(self) -> None:
            self._calls = 0
            self.title = "ok"

        def set_page_load_timeout(self, _timeout: object) -> None:
            return None

        def get(self, _url: object) -> None:
            # Fail first call with timeout, then succeed
            self._calls += 1
            if self._calls == 1:
                raise TimeoutException("nav timeout")
            return None

        def execute_cdp_cmd(self, *_args: object, **_kwargs: object) -> dict[str, str]:
            # Return values used by full-page capture path if invoked
            return {"data": ""}

        def get_screenshot_as_png(self) -> bytes:
            return b"PNG"

        @property
        def page_source(self) -> str:
            return "<html/>"

        def quit(self) -> None:
            return None

    class webdriver:
        @staticmethod
        def Chrome(*_args: object, **_kwargs: object) -> _Driver:
            return _Driver()

    def _fake_loader() -> (
        tuple[type[webdriver], type[Options], type[TimeoutException], type[WebDriverException]]
    ):
        return webdriver, Options, TimeoutException, WebDriverException

    monkeypatch.setattr("screenshot.selenium_runner._load_selenium_modules", _fake_loader)

    res = await capture_screenshots_async(
        "job",
        "https://example.com",
        store_dir=tmp_path,
        partition_date=None,
        options=ScreenshotOptions(capture=CaptureOptions(enabled=True)),
        html_snapshot_path=None,
        cancel_token=None,
        storage=None,
    )

    assert res.captured >= 1
    # Ensure our retry logging hook fired
    assert "Retrying navigation (selenium)" in caplog.text


@pytest.mark.asyncio
async def test_selenium_metadata_embeds_partition_date_and_artifact_paths(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    class TimeoutException(Exception):
        pass

    class WebDriverException(Exception):
        pass

    class Options:
        def __init__(self) -> None:
            self.binary_location = None

        def add_argument(self, *_args: object) -> None:
            return None

    class _Driver:
        def __init__(self) -> None:
            self.title = "ok"

        def set_page_load_timeout(self, _timeout: object) -> None:
            return None

        def get(self, _url: object) -> None:
            return None

        def execute_script(self, script: str, *args: object) -> int | list[str] | bool | None:
            if "Math.max" in script:
                return 200
            if "querySelectorAll('a[href]')" in script:
                return []
            if "window.scrollTo" in script:
                return True
            return None

        def execute_cdp_cmd(self, *_args: object, **_kwargs: object) -> dict[str, str]:
            return {"data": ""}

        def get_screenshot_as_png(self) -> bytes:
            return b"PNG"

        @property
        def page_source(self) -> str:
            return "<html/>"

        def quit(self) -> None:
            return None

    class webdriver:
        @staticmethod
        def Chrome(*_args: object, **_kwargs: object) -> _Driver:
            return _Driver()

    def _fake_loader() -> (
        tuple[
            type[webdriver],
            type[Options],
            type[TimeoutException],
            type[WebDriverException],
        ]
    ):
        return webdriver, Options, TimeoutException, WebDriverException

    monkeypatch.setattr("screenshot.selenium_runner._load_selenium_modules", _fake_loader)

    result = await capture_screenshots_async(
        "partitioned-job",
        "https://example.com",
        store_dir=tmp_path,
        partition_date="2026-03-14",
        job_metadata={"campaign": "spring-launch", "source": "test"},
        options=ScreenshotOptions(capture=CaptureOptions(enabled=True)),
        html_snapshot_path=None,
        cancel_token=None,
        storage=None,
    )

    assert result.metadata_path is not None
    payload = json.loads(result.metadata_path.read_text(encoding="utf-8"))
    assert payload["partition_date"] == "2026-03-14"
    assert payload["metadata"] == {"campaign": "spring-launch", "source": "test"}
    entry = payload["entries"][0]
    screenshot_path = Path(entry["screenshot_path"])
    assert screenshot_path.exists()
    assert screenshot_path.parent == result.metadata_path.parent.parent / "assets" / "screenshots"


class _FailingCloudStorage(LocalStorageBackend):
    def upload_file(self, path: Path) -> None:
        raise RuntimeError(f"boom uploading {path}")


@pytest.mark.asyncio
async def test_selenium_storage_upload_failure_warns(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch, caplog: pytest.LogCaptureFixture
) -> None:
    class TimeoutException(Exception):
        pass

    class WebDriverException(Exception):
        pass

    class Options:
        def __init__(self) -> None:
            self.binary_location = None

        def add_argument(self, *_args: object) -> None:
            return None

    class _Driver:
        def __init__(self) -> None:
            self.title = "ok"

        def set_page_load_timeout(self, _timeout: object) -> None:
            return None

        def get(self, _url: object) -> None:
            return None

        def execute_script(self, script: str, *args: object) -> int | list[str] | bool | None:
            if "Math.max" in script:
                return 200
            if "querySelectorAll('a[href]')" in script:
                return []
            if "window.scrollTo" in script:
                return True
            return None

        def execute_cdp_cmd(self, *_args: object, **_kwargs: object) -> dict[str, str]:
            return {"data": ""}

        def get_screenshot_as_png(self) -> bytes:
            return b"PNG"

        @property
        def page_source(self) -> str:
            return "<html/>"

        def quit(self) -> None:
            return None

    class webdriver:
        @staticmethod
        def Chrome(*_args: object, **_kwargs: object) -> _Driver:
            return _Driver()

    def _fake_loader() -> (
        tuple[
            type[webdriver],
            type[Options],
            type[TimeoutException],
            type[WebDriverException],
        ]
    ):
        return webdriver, Options, TimeoutException, WebDriverException

    monkeypatch.setattr("screenshot.selenium_runner._load_selenium_modules", _fake_loader)
    caplog.set_level("WARNING")

    result = await capture_screenshots_async(
        "upload-warning",
        "https://example.com",
        store_dir=tmp_path,
        partition_date=None,
        options=ScreenshotOptions(capture=CaptureOptions(enabled=True)),
        html_snapshot_path=None,
        cancel_token=None,
        storage=_FailingCloudStorage(),
    )

    assert result.metadata_path is not None
    assert "Storage upload failed" in caplog.text


def test_apply_browser_mutations_executes_optional_scripts() -> None:
    executed: list[str] = []

    class Driver:
        def execute_script(self, script: str, *args: object) -> None:
            executed.append(script)

    browser_plan = BrowserPlan(
        allow_autoplay=True,
        hide_overlays=True,
        reduced_motion=True,
        disable_animations=True,
        mute_media=True,
        block_media=False,
        compatibility_level="low",
        user_agent="UA",
    )
    runner_plan = RunnerPlan(
        extra_styles=("body {color:red;}",),
        extra_init_scripts=("console.log('init');",),
        navigation_strategies=(),
        playwright_executable_path=None,
        extra={},
    )

    _apply_browser_mutations(Driver(), browser_plan, runner_plan)

    assert any("autoplay" in script.lower() for script in executed)
    assert any("hide-overlays" in script for script in executed)
    assert any("disable-animations" in script for script in executed)
    assert any("console.log('init');" in script for script in executed)


def test_apply_browser_mutations_skips_autoplay_when_disabled() -> None:
    executed: list[str] = []

    class Driver:
        def execute_script(self, script: str, *args: object) -> None:
            executed.append(script)

    browser_plan = BrowserPlan(
        allow_autoplay=False,
        hide_overlays=False,
        reduced_motion=False,
        disable_animations=False,
        mute_media=False,
        block_media=False,
        compatibility_level="low",
        user_agent=None,
    )
    runner_plan = RunnerPlan(
        extra_styles=(),
        extra_init_scripts=(),
        navigation_strategies=(),
        playwright_executable_path=None,
        extra={},
    )

    _apply_browser_mutations(Driver(), browser_plan, runner_plan)

    assert not any("autoplay" in script.lower() for script in executed)


def test_create_driver_applies_compatibility_flags() -> None:
    captured_args: list[str] = []

    class Options:
        def __init__(self) -> None:
            self.binary_location = None

        def add_argument(self, arg: str) -> None:
            captured_args.append(arg)

    class Driver:
        def execute_cdp_cmd(self, *_args: object, **_kwargs: object) -> dict[str, object]:
            return {}

    class Webdriver:
        @staticmethod
        def Chrome(*_args: object, **kwargs: object) -> Driver:
            return Driver()

    browser_plan = BrowserPlan(
        allow_autoplay=False,
        hide_overlays=False,
        reduced_motion=False,
        disable_animations=False,
        mute_media=False,
        block_media=False,
        compatibility_level="high",
        user_agent="Agent/1.0",
    )
    runner_plan = RunnerPlan(
        extra_styles=(),
        extra_init_scripts=(),
        navigation_strategies=(),
        playwright_executable_path=None,
        extra={"chrome_args": ["--custom-flag"]},
    )

    _driver, temp_profile = _create_driver(
        webdriver=Webdriver,
        Options=Options,
        WebDriverException=RuntimeError,
        viewport_spec={"viewport": {"width": 100, "height": 50}, "device_scale_factor": 1.0},
        browser_plan=browser_plan,
        runner_plan=runner_plan,
    )
    temp_profile.cleanup()

    assert "--allow-running-insecure-content" in captured_args
    assert "--ignore-certificate-errors" in captured_args
    assert "--user-agent=Agent/1.0" in captured_args
    assert "--custom-flag" in captured_args
    assert "--autoplay-policy=no-user-gesture-required" not in captured_args


def test_scroll_page_and_collect_links(monkeypatch: pytest.MonkeyPatch) -> None:
    heights = [100, 120, 120]

    class Driver:
        def __init__(self) -> None:
            self._scroll_calls = 0

        def execute_script(self, script: str, *args: object) -> int | bool | None:
            if "Math.max" in script:
                value = heights[min(self._scroll_calls, len(heights) - 1)]
                self._scroll_calls += 1
                return value
            if "window.scrollY" in script:
                return True
            return None

    monkeypatch.setattr("time.sleep", lambda _seconds: None)
    driver = Driver()
    scroll_height = _scroll_page(driver, max_steps=3, delay_ms=10)
    assert scroll_height == heights[-1]

    class LinkDriver:
        def execute_script(self, *_args: object) -> list[str | None]:
            return ["https://example.com/a", "/b", "mailto:test@example.com", None]

    links = _collect_links(
        driver=LinkDriver(),
        current_url="https://example.com",
        origin="example.com",
        depth=0,
        max_depth=1,
        max_pages=5,
    )
    assert links == ["https://example.com/a", "https://example.com/b"]


def test_failed_entry_structure() -> None:
    entry = _failed_entry(2, 1, "desktop", "https://example.com", 10.0, "boom")
    assert entry["index"] == 2
    assert entry["status"] == "failed"
    assert entry["timeout_seconds"] == 10.0


def test_capture_url_handles_driver_init_failure(
    monkeypatch: pytest.MonkeyPatch, tmp_path: Path
) -> None:
    capture_plan = CapturePlan(
        max_pages=1,
        depth=0,
        delay_ms=0,
        viewport_specs={"desktop": {"viewport": {"width": 100, "height": 50}}},
        viewport_details=[
            {
                "name": "desktop",
                "width": 100,
                "height": 50,
                "device_scale_factor": 1.0,
                "is_mobile": False,
            }
        ],
        primary_viewport="desktop",
        timeout_sec=5.0,
        max_total_duration_sec=5.0,
        max_capture_attempts=1,
        max_viewport_concurrency=1,
        scroll_enabled=False,
        scroll_step_delay_ms=250,
        max_scroll_steps=15,
        full_page_capture=False,
        settle_timeout_ms=0,
    )
    browser_plan = BrowserPlan(
        allow_autoplay=False,
        hide_overlays=False,
        reduced_motion=False,
        disable_animations=False,
        mute_media=False,
        block_media=False,
        compatibility_level="low",
        user_agent=None,
    )
    runner_plan = RunnerPlan(
        extra_styles=(),
        extra_init_scripts=(),
        navigation_strategies=(),
        playwright_executable_path=None,
        extra={},
    )

    def fake_create_driver(**_kwargs: object) -> NoReturn:
        raise RuntimeError("boom")

    monkeypatch.setattr("screenshot.selenium_runner._create_driver", fake_create_driver)

    class DummyWebdriver:
        pass

    class DummyOptions:
        pass

    outcome = _capture_url_with_viewports(
        webdriver=DummyWebdriver,
        Options=DummyOptions,
        TimeoutException=RuntimeError,
        WebDriverException=RuntimeError,
        job_id="job",
        url="https://example.com",
        origin="example.com",
        depth=0,
        capture_plan=capture_plan,
        browser_plan=browser_plan,
        runner_plan=runner_plan,
        screenshot_dir=tmp_path,
        page_index=0,
        snapshot_path=None,
        snapshot_written=False,
    )

    assert outcome.failed == 1
    assert outcome.errors and outcome.errors[0].error_type == "driver_init"


def test_capture_url_uses_scroll_tuning(monkeypatch: pytest.MonkeyPatch, tmp_path: Path) -> None:
    recorded: dict[str, int] = {}

    def fake_scroll_page(_driver: object, *, max_steps: int, delay_ms: int) -> int:
        recorded["max_steps"] = max_steps
        recorded["delay_ms"] = delay_ms
        return 200

    monkeypatch.setattr("screenshot.selenium_runner._scroll_page", fake_scroll_page)

    class FakeDriver:
        title = "Fake"

        def set_page_load_timeout(self, *_args: object, **_kwargs: object) -> None:
            return None

        def get(self, *_args: object, **_kwargs: object) -> None:
            return None

        def execute_script(self, *_args: object, **_kwargs: object) -> int:
            return 0

        def get_screenshot_as_png(self) -> bytes:
            return b"PNG"

        def quit(self) -> None:
            return None

    def fake_create_driver(**_kwargs: object) -> tuple[FakeDriver, None]:
        return FakeDriver(), None

    monkeypatch.setattr("screenshot.selenium_runner._create_driver", fake_create_driver)

    capture_plan = CapturePlan(
        max_pages=1,
        depth=0,
        delay_ms=0,
        viewport_specs={"desktop": {"viewport": {"width": 100, "height": 50}}},
        viewport_details=[
            {
                "name": "desktop",
                "width": 100,
                "height": 50,
                "device_scale_factor": 1.0,
                "is_mobile": False,
            }
        ],
        primary_viewport="desktop",
        timeout_sec=5.0,
        max_total_duration_sec=5.0,
        max_capture_attempts=1,
        max_viewport_concurrency=1,
        scroll_enabled=True,
        scroll_step_delay_ms=155,
        max_scroll_steps=6,
        full_page_capture=False,
        settle_timeout_ms=0,
    )
    browser_plan = BrowserPlan(
        allow_autoplay=False,
        hide_overlays=False,
        reduced_motion=False,
        disable_animations=False,
        mute_media=False,
        block_media=False,
        compatibility_level="low",
        user_agent=None,
    )
    runner_plan = RunnerPlan(
        extra_styles=(),
        extra_init_scripts=(),
        navigation_strategies=(),
        playwright_executable_path=None,
        extra={},
    )

    class DummyWebdriver:
        pass

    class DummyOptions:
        pass

    outcome = _capture_url_with_viewports(
        webdriver=DummyWebdriver,
        Options=DummyOptions,
        TimeoutException=RuntimeError,
        WebDriverException=RuntimeError,
        job_id="job",
        url="https://example.com",
        origin="example.com",
        depth=0,
        capture_plan=capture_plan,
        browser_plan=browser_plan,
        runner_plan=runner_plan,
        screenshot_dir=tmp_path,
        page_index=0,
        snapshot_path=None,
        snapshot_written=False,
    )

    assert outcome.captured == 1
    assert recorded == {"max_steps": 6, "delay_ms": 155}


def test_selenium_timings_emitted_when_enabled(
    monkeypatch: pytest.MonkeyPatch, tmp_path: Path
) -> None:
    monkeypatch.setenv("SCREENSHOT_ENABLE_TIMING", "1")
    monkeypatch.setattr("screenshot.selenium_runner.ENABLE_TIMING", True)

    class FakeDriver:
        title = "Fake"

        def set_page_load_timeout(self, *_args: object, **_kwargs: object) -> None:
            return None

        def get(self, *_args: object, **_kwargs: object) -> None:
            return None

        def execute_script(self, *_args: object, **_kwargs: object) -> None:
            return None

        def get_screenshot_as_png(self) -> bytes:
            return b"PNG"

        def quit(self) -> None:
            return None

    def fake_create_driver(**_kwargs: object) -> tuple[FakeDriver, None]:
        return FakeDriver(), None

    monkeypatch.setattr("screenshot.selenium_runner._create_driver", fake_create_driver)

    capture_plan = CapturePlan(
        max_pages=1,
        depth=0,
        delay_ms=0,
        viewport_specs={"desktop": {"viewport": {"width": 100, "height": 50}}},
        viewport_details=[
            {
                "name": "desktop",
                "width": 100,
                "height": 50,
                "device_scale_factor": 1.0,
                "is_mobile": False,
            }
        ],
        primary_viewport="desktop",
        timeout_sec=5.0,
        max_total_duration_sec=5.0,
        max_capture_attempts=1,
        max_viewport_concurrency=1,
        scroll_enabled=False,
        scroll_step_delay_ms=250,
        max_scroll_steps=15,
        full_page_capture=False,
        settle_timeout_ms=0,
    )
    browser_plan = BrowserPlan(
        allow_autoplay=False,
        hide_overlays=False,
        reduced_motion=False,
        disable_animations=False,
        mute_media=False,
        block_media=False,
        compatibility_level="low",
        user_agent=None,
    )
    runner_plan = RunnerPlan(
        extra_styles=(),
        extra_init_scripts=(),
        navigation_strategies=(),
        playwright_executable_path=None,
        extra={},
    )

    class DummyWebdriver:
        pass

    class DummyOptions:
        pass

    outcome = _capture_url_with_viewports(
        webdriver=DummyWebdriver,
        Options=DummyOptions,
        TimeoutException=RuntimeError,
        WebDriverException=RuntimeError,
        job_id="job",
        url="https://example.com",
        origin="example.com",
        depth=0,
        capture_plan=capture_plan,
        browser_plan=browser_plan,
        runner_plan=runner_plan,
        screenshot_dir=tmp_path,
        page_index=0,
        snapshot_path=None,
        snapshot_written=False,
    )

    assert outcome.captured == 1
    assert outcome.entries
    timings = outcome.entries[0].get("timings")
    assert isinstance(timings, dict)
    assert {
        "navigation_ms",
        "scroll_ms",
        "post_scroll_wait_ms",
        "screenshot_ms",
        "total_ms",
    }.issubset(timings.keys())
    assert timings["scroll_ms"] == 0.0
    assert timings["post_scroll_wait_ms"] == 0.0


def test_capture_full_page_fallback(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    class Driver:
        def __init__(self) -> None:
            self._scripts: list[str] = []

        def execute_cdp_cmd(self, *_args: object, **_kwargs: object) -> None:
            raise RuntimeError("cdp unsupported")

        def get_screenshot_as_png(self) -> bytes:
            return b"FAKEPNG"

        def execute_script(self, *_args: object, **_kwargs: object) -> int:
            return 200

    out_path = tmp_path / "shot.png"
    _capture_full_page(
        Driver(),
        {"viewport": {"width": 120, "height": 80}, "device_scale_factor": 1.0},
        out_path,
    )
    assert out_path.exists()
