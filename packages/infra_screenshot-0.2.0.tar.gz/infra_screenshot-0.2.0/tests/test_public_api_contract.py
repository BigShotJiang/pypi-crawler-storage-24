from __future__ import annotations

import importlib

import pytest

import screenshot
import screenshot.backends as screenshot_backends
import screenshot.cli as screenshot_cli
import screenshot.models as screenshot_models
from screenshot import ScreenshotCaptureOutcome, ScreenshotCaptureResult


def test_top_level_public_api_exposes_library_first_surface() -> None:
    expected = {
        "ScreenshotJob",
        "ScreenshotOptions",
        "ScreenshotCaptureResult",
        "ScreenshotCaptureOutcome",
        "ScreenshotBatchResult",
        "ScreenshotService",
        "ScreenshotBackend",
        "backends",
        "capabilities",
        "find_capabilities",
    }

    assert expected.issubset(set(screenshot.__all__))


def test_removed_legacy_exports_stay_removed() -> None:
    removed = {
        "ScreenshotJobSpec",
        "ScreenshotMetadata",
        "ScreenshotResourceResult",
        "ScreenshotResourceOutcome",
        "ScreenshotResourceError",
    }

    for name in removed:
        assert not hasattr(screenshot, name)
        assert not hasattr(screenshot_models, name)
        assert name not in screenshot.__all__
        assert name not in screenshot_models.__all__


def test_runtime_backends_live_in_backends_module_not_cli() -> None:
    assert hasattr(screenshot_backends, "PlaywrightScreenshotBackend")
    assert hasattr(screenshot_backends, "SeleniumScreenshotBackend")
    assert hasattr(screenshot_backends, "build_local_screenshot_service")

    assert not hasattr(screenshot_cli, "PlaywrightScreenshotBackend")
    assert not hasattr(screenshot_cli, "SeleniumScreenshotBackend")
    assert not hasattr(screenshot_cli, "build_local_screenshot_service")


def test_capture_result_uses_outcome_not_succeeded_property() -> None:
    result = ScreenshotCaptureResult(
        requested=1,
        captured=1,
        failed=0,
        metadata_path=None,
        entries=[],
        errors=[],
        job_id="demo",
    )

    assert result.outcome is ScreenshotCaptureOutcome.SUCCESS
    assert result.has_artifacts is True
    assert not hasattr(result, "succeeded")


@pytest.mark.parametrize("module_name", ["screenshot._internal", "screenshot.cli_config"])
def test_removed_legacy_modules_are_not_importable(module_name: str) -> None:
    with pytest.raises(ModuleNotFoundError):
        importlib.import_module(module_name)
