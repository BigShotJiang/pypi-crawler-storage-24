"""Tests for the task-oriented capability index."""

from __future__ import annotations

from screenshot.capabilities import CAPABILITIES, find_capabilities


def test_find_capabilities_returns_all_for_empty_query() -> None:
    assert find_capabilities("") == list(CAPABILITIES)


def test_find_capabilities_ranks_playwright_capture_first() -> None:
    matches = find_capabilities("playwright timeout viewport")

    assert matches
    assert matches[0].slug == "playwright-capture"


def test_find_capabilities_matches_selenium_terms() -> None:
    matches = find_capabilities("selenium chrome driver")
    slugs = {capability.slug for capability in matches}

    assert "selenium-capture" in slugs


def test_find_capabilities_matches_batch_summary_storage_terms() -> None:
    matches = find_capabilities("batch summary storage backend")
    slugs = {capability.slug for capability in matches}

    assert "screenshot-service" in slugs
    assert "storage-summary-integration" in slugs
