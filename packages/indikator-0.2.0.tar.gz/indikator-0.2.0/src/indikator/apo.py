"""APO (Absolute Price Oscillator) indicator module."""

from datawarden import (
  Finite,
  NotEmpty,
  Validated,
  validate,
)
from nonfig import Ge, Hyper, configurable
import pandas as pd

from indikator._results import IndicatorResult
from indikator.ema import ema
from indikator.sma import sma


@configurable
@validate
def apo(
  data: Validated[pd.Series[float], Finite, NotEmpty],
  fast_period: Hyper[int, Ge[2]] = 12,
  slow_period: Hyper[int, Ge[2]] = 26,
  matype: Hyper[int] = 0,  # 0=SMA, 1=EMA
) -> IndicatorResult:
  """Calculate Absolute Price Oscillator (APO).

  APO = FastMA - SlowMA

  Args:
    data: Input Series.
    fast_period: Fast MA period (default 12).
    slow_period: Slow MA period (default 26).
    matype: Moving Average type (0=SMA, 1=EMA). Default 0.

  Returns:
    IndicatorResult
  """
  # TA-Lib logic:
  # If matype=0, use SMA. If 1, use EMA.

  if matype == 1:
    fast_ma = ema(data, period=fast_period).value
    slow_ma = ema(data, period=slow_period).value
  else:
    # Default to SMA
    fast_ma = sma(data, period=fast_period).value
    slow_ma = sma(data, period=slow_period).value

  apo_values = fast_ma - slow_ma
  apo_np = apo_values

  return IndicatorResult(data_index=data.index, value=apo_np, name="apo")
