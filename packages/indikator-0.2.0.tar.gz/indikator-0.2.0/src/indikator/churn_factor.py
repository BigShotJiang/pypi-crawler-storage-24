"""Churn Factor indicator module.

This module calculates the Churn Factor, which measures the relationship
between volume and price range.
"""

from datawarden import (
  Finite,
  NotEmpty,
  Validated,
  validate,
)
from nonfig import Gt, Hyper, configurable
import numpy as np
import pandas as pd

from indikator._constants import DEFAULT_EPSILON
from indikator._results import IndicatorResult
from indikator.utils import to_numpy


@configurable
@validate
def churn_factor(
  high: Validated[pd.Series[float], Finite, NotEmpty],
  low: Validated[pd.Series[float], Finite, NotEmpty],
  volume: Validated[pd.Series[float], Finite, NotEmpty],
  epsilon: Hyper[float, Gt[0.0]] = DEFAULT_EPSILON,
) -> IndicatorResult:
  """Calculate Churn Factor.

  Churn factor measures the efficiency of volume in moving the price.
  High churn means high volume but low price movement (indecision/turning point).

  Formula:
  Churn = Volume / (High - Low)

  Interpretation:
  - High Churn: High volume with tight range (distribution/accumulation)
  - Low Churn: Price moving freely on low volume (or low vol/low range)

  Args:
    high: High prices Series.
    low: Low prices Series.
    volume: Volume Series.
    epsilon: Division by zero protection.

  Returns:
    IndicatorResult(index, churn)
  """
  # Convert to numpy
  high_arr = to_numpy(high)
  low_arr = to_numpy(low)
  vol_arr = to_numpy(volume)

  price_range = high_arr - low_arr

  # Calculate Churn: Vol / Range
  # Handle zero range
  churn = np.zeros_like(vol_arr)

  valid_range = price_range > epsilon
  churn[valid_range] = vol_arr[valid_range] / price_range[valid_range]

  return IndicatorResult(data_index=high.index, value=churn, name="churn")
