"""Utility specialized for Indikator results and Pandas integration."""

from __future__ import annotations

from typing import TypeVar

import numpy as np
from numpy.typing import NDArray
import pandas as pd

T = TypeVar("T", pd.Series, pd.DataFrame)


def to_numpy(data: pd.Series[float]) -> NDArray[np.float64]:
  """Convert Series to numpy array with float64 type."""
  return data.to_numpy(dtype=np.float64, copy=False)  # pyright: ignore[reportUnknownMemberType]


def trim_nans[T: (pd.Series, pd.DataFrame)](data: T) -> T:
  """Remove leading NaNs from the dataset.

  Common for indicators with lookback periods.
  """
  if isinstance(data, pd.DataFrame):
    # Drop rows where any column is NaN
    return data.dropna()  # pyright: ignore[reportUnknownMemberType]
  return data.dropna()


def clean_extreme[T: (pd.Series, pd.DataFrame)](data: T, sigma: float = 3.0) -> T:
  """Clamp data within N-sigma bounds."""
  if isinstance(data, pd.DataFrame):
    res = data.copy()
    for col in res.columns:
      m = res[col].mean()
      s = res[col].std()
      res[col] = res[col].clip(m - sigma * s, m + sigma * s)
    return res
  m = data.mean()
  s = data.std()
  return data.clip(m - sigma * s, m + sigma * s)
