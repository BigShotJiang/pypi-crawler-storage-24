"""IncAgent Demo Dashboard — HTMLダッシュボードで取引を可視化

実行するとブラウザが自動で開き、法人エージェントの自律取引をリアルタイム表示。
"""

import asyncio
import os
import tempfile
import time
import webbrowser
from datetime import datetime, timezone

from incagent import (
    Contract,
    ContractTerms,
    IncAgent,
    NegotiationPolicy,
)
from incagent.messaging import MessageBus


def generate_html(data: dict) -> str:
    now = data["timestamp"]
    agents_info = data["agents"]
    deals = data["deals"]
    small_deals = data["small_deals"]
    tax = data["tax"]
    vendors = data["vendors"]
    ledger_status = data["ledger_status"]
    ledger_entries = data["ledger_entries"]
    partners = data["partners"]
    total_value = data["total_value"]
    deal_count = data["deal_count"]

    # Build deal rows
    deal_rows = ""
    for d in deals:
        if d["agreed"]:
            deal_rows += f"""
            <tr>
                <td><span class="badge badge-success">AGREED</span></td>
                <td>{d['title']}</td>
                <td>{d['buyer']} &rarr; {d['seller']}</td>
                <td class="mono">${d['unit_price']:,.2f}</td>
                <td class="mono">{d['quantity']:,}</td>
                <td class="mono amount">${d['total']:,.2f}</td>
                <td>{d['rounds']}R / {d['time']}</td>
            </tr>"""
        else:
            deal_rows += f"""
            <tr class="row-failed">
                <td><span class="badge badge-fail">FAILED</span></td>
                <td>{d['title']}</td>
                <td>{d['buyer']} &rarr; {d['seller']}</td>
                <td colspan="3">{d.get('reason', 'N/A')}</td>
                <td>—</td>
            </tr>"""

    # Small deal rows
    small_rows = ""
    for s in small_deals:
        status_cls = "badge-success" if s["agreed"] else "badge-fail"
        status_txt = "AGREED" if s["agreed"] else "FAILED"
        val = f"${s['total']:,.2f}" if s["agreed"] else "—"
        small_rows += f"""
            <tr>
                <td><span class="badge {status_cls}">{status_txt}</span></td>
                <td>{s['title']}</td>
                <td>{s['seller']}</td>
                <td class="mono amount">{val}</td>
            </tr>"""

    # Vendor rows
    vendor_rows = ""
    for v in vendors:
        flag = '<span class="flag-1099">1099-NEC</span>' if v["needs_1099"] else ""
        vendor_rows += f"""
            <tr>
                <td>{v['vendor_name']}</td>
                <td class="mono amount">${v['total_paid']:,.2f}</td>
                <td>{flag}</td>
            </tr>"""

    # Ledger rows
    ledger_rows = ""
    for l in ledger_status:
        icon = "shield-check" if l["valid"] else "shield-x"
        cls = "text-green" if l["valid"] else "text-red"
        ledger_rows += f"""
            <tr>
                <td>{l['name']}</td>
                <td class="mono">{l['entries']}</td>
                <td class="{cls}">{'VERIFIED' if l['valid'] else 'CORRUPTED'}</td>
            </tr>"""

    # Activity log
    activity_html = ""
    for e in ledger_entries[:12]:
        ts = e['timestamp'][:19].replace('T', ' ')
        action = e['action'].replace('_', ' ').title()
        activity_html += f'<div class="log-entry"><span class="log-time">{ts}</span><span class="log-action">{action}</span></div>\n'

    # Partner rows
    partner_rows = ""
    for p in partners:
        rel = p.get('success_rate', 0) * 100
        bar_cls = "bar-green" if rel >= 80 else "bar-yellow" if rel >= 50 else "bar-red"
        partner_rows += f"""
            <tr>
                <td>{p['partner_name']}</td>
                <td>
                    <div class="rel-bar"><div class="rel-fill {bar_cls}" style="width:{rel}%"></div></div>
                    <span class="mono">{rel:.0f}%</span>
                </td>
                <td class="mono">${p.get('avg_price', 0):,.2f}</td>
                <td class="mono">{p.get('total_trades', 0)}</td>
            </tr>"""

    # Agent cards
    agent_cards = ""
    for a in agents_info:
        agent_cards += f"""
        <div class="agent-card">
            <div class="agent-role {'role-buyer' if a['role'] == 'buyer' else 'role-seller'}">{a['role'].upper()}</div>
            <div class="agent-name">{a['name']}</div>
            <div class="agent-id">{a['id']}</div>
        </div>"""

    return f"""<!DOCTYPE html>
<html lang="ja">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>IncAgent — AI Corporate Agent Dashboard</title>
<style>
* {{ margin: 0; padding: 0; box-sizing: border-box; }}
body {{ background: #0a0e1a; color: #e0e4ef; font-family: 'Inter', -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif; }}
.container {{ max-width: 1200px; margin: 0 auto; padding: 32px 24px; }}

/* Header */
.header {{ text-align: center; margin-bottom: 40px; padding-bottom: 24px; border-bottom: 1px solid #1e2940; }}
.header h1 {{ font-size: 28px; font-weight: 700; color: #fff; margin-bottom: 4px; }}
.header h1 span {{ color: #6366f1; }}
.header .subtitle {{ color: #64748b; font-size: 14px; }}
.header .timestamp {{ color: #475569; font-size: 12px; margin-top: 8px; font-family: 'JetBrains Mono', monospace; }}

/* Agent Cards */
.agents-grid {{ display: flex; gap: 16px; margin-bottom: 32px; justify-content: center; }}
.agent-card {{ background: #111827; border: 1px solid #1e2940; border-radius: 12px; padding: 20px 28px; text-align: center; min-width: 200px; }}
.agent-name {{ font-size: 18px; font-weight: 600; color: #fff; margin: 8px 0 4px; }}
.agent-id {{ font-size: 11px; color: #475569; font-family: 'JetBrains Mono', monospace; }}
.agent-role {{ display: inline-block; font-size: 10px; font-weight: 700; letter-spacing: 1px; padding: 3px 10px; border-radius: 4px; }}
.role-buyer {{ background: #1e3a5f; color: #60a5fa; }}
.role-seller {{ background: #1a3d2e; color: #4ade80; }}

/* KPI Strip */
.kpi-strip {{ display: grid; grid-template-columns: repeat(4, 1fr); gap: 16px; margin-bottom: 32px; }}
.kpi {{ background: #111827; border: 1px solid #1e2940; border-radius: 12px; padding: 20px; }}
.kpi-label {{ font-size: 12px; color: #64748b; text-transform: uppercase; letter-spacing: 0.5px; margin-bottom: 4px; }}
.kpi-value {{ font-size: 28px; font-weight: 700; font-family: 'JetBrains Mono', monospace; }}
.kpi-value.green {{ color: #4ade80; }}
.kpi-value.red {{ color: #f87171; }}
.kpi-value.blue {{ color: #60a5fa; }}
.kpi-value.yellow {{ color: #facc15; }}

/* Section */
.section {{ margin-bottom: 32px; }}
.section-title {{ font-size: 16px; font-weight: 600; color: #94a3b8; margin-bottom: 12px; display: flex; align-items: center; gap: 8px; }}
.section-title::before {{ content: ''; display: inline-block; width: 3px; height: 16px; background: #6366f1; border-radius: 2px; }}

/* Tables */
table {{ width: 100%; border-collapse: collapse; background: #111827; border-radius: 12px; overflow: hidden; }}
th {{ background: #0f172a; color: #64748b; font-size: 11px; text-transform: uppercase; letter-spacing: 0.5px; padding: 12px 16px; text-align: left; font-weight: 600; }}
td {{ padding: 12px 16px; border-top: 1px solid #1e2940; font-size: 14px; }}
tr:hover {{ background: #1a2235; }}
.mono {{ font-family: 'JetBrains Mono', monospace; }}
.amount {{ color: #4ade80; font-weight: 600; }}
.row-failed td {{ opacity: 0.5; }}

/* Badges */
.badge {{ display: inline-block; font-size: 10px; font-weight: 700; letter-spacing: 0.5px; padding: 3px 8px; border-radius: 4px; }}
.badge-success {{ background: #064e3b; color: #4ade80; }}
.badge-fail {{ background: #4c1d1d; color: #f87171; }}
.flag-1099 {{ background: #7c2d12; color: #fb923c; font-size: 10px; font-weight: 700; padding: 2px 6px; border-radius: 3px; }}

/* Two column layout */
.two-col {{ display: grid; grid-template-columns: 1fr 1fr; gap: 24px; }}
@media (max-width: 768px) {{ .two-col {{ grid-template-columns: 1fr; }} }}

/* Activity Log */
.log-entry {{ display: flex; gap: 12px; padding: 8px 16px; border-bottom: 1px solid #1e2940; font-size: 13px; }}
.log-entry:hover {{ background: #1a2235; }}
.log-time {{ color: #475569; font-family: 'JetBrains Mono', monospace; font-size: 12px; white-space: nowrap; }}
.log-action {{ color: #94a3b8; }}
.log-container {{ background: #111827; border-radius: 12px; overflow: hidden; max-height: 400px; overflow-y: auto; }}

/* Reliability bar */
.rel-bar {{ display: inline-block; width: 80px; height: 6px; background: #1e2940; border-radius: 3px; vertical-align: middle; margin-right: 8px; }}
.rel-fill {{ height: 100%; border-radius: 3px; }}
.bar-green {{ background: #4ade80; }}
.bar-yellow {{ background: #facc15; }}
.bar-red {{ background: #f87171; }}
.text-green {{ color: #4ade80; font-weight: 600; }}
.text-red {{ color: #f87171; font-weight: 600; }}

/* Footer */
.footer {{ text-align: center; padding: 32px 0 16px; color: #334155; font-size: 12px; border-top: 1px solid #1e2940; margin-top: 32px; }}
.footer a {{ color: #6366f1; text-decoration: none; }}
</style>
</head>
<body>
<div class="container">

<div class="header">
    <h1><span>Inc</span>Agent Dashboard</h1>
    <div class="subtitle">AI Corporate Agent &mdash; Autonomous Trading Report</div>
    <div class="timestamp">{now}</div>
</div>

<div class="agents-grid">
    {agent_cards}
</div>

<div class="kpi-strip">
    <div class="kpi">
        <div class="kpi-label">Total Volume</div>
        <div class="kpi-value green">${total_value:,.0f}</div>
    </div>
    <div class="kpi">
        <div class="kpi-label">Deals Closed</div>
        <div class="kpi-value blue">{deal_count}</div>
    </div>
    <div class="kpi">
        <div class="kpi-label">Total Expenses</div>
        <div class="kpi-value red">${tax['total_expenses']:,.0f}</div>
    </div>
    <div class="kpi">
        <div class="kpi-label">1099-NEC Vendors</div>
        <div class="kpi-value yellow">{tax['vendors_needing_1099']}</div>
    </div>
</div>

<div class="section">
    <div class="section-title">Negotiations</div>
    <table>
        <tr><th>Status</th><th>Contract</th><th>Parties</th><th>Unit Price</th><th>Qty</th><th>Total</th><th>Rounds</th></tr>
        {deal_rows}
    </table>
</div>

<div class="section">
    <div class="section-title">Additional Trades</div>
    <table>
        <tr><th>Status</th><th>Contract</th><th>Seller</th><th>Total</th></tr>
        {small_rows}
    </table>
</div>

<div class="two-col">
    <div class="section">
        <div class="section-title">Tax &mdash; Vendor Breakdown (FY2026)</div>
        <table>
            <tr><th>Vendor</th><th>Total Paid</th><th>Flag</th></tr>
            {vendor_rows}
        </table>
    </div>
    <div class="section">
        <div class="section-title">Partner Reliability</div>
        <table>
            <tr><th>Partner</th><th>Reliability</th><th>Avg Price</th><th>Trades</th></tr>
            {partner_rows}
        </table>
    </div>
</div>

<div class="two-col">
    <div class="section">
        <div class="section-title">Ledger Integrity</div>
        <table>
            <tr><th>Agent</th><th>Entries</th><th>Hash Chain</th></tr>
            {ledger_rows}
        </table>
    </div>
    <div class="section">
        <div class="section-title">Activity Log (Acme Corp)</div>
        <div class="log-container">
            {activity_html}
        </div>
    </div>
</div>

<div class="footer">
    Powered by <a href="https://incagent.ai">IncAgent</a> &mdash; AI agents run the company. Humans execute.
</div>

</div>
</body>
</html>"""


async def main() -> None:
    # Clean DB for fresh run
    import shutil
    home = os.path.expanduser("~")
    incagent_dir = os.path.join(home, ".incagent")
    if os.path.exists(incagent_dir):
        shutil.rmtree(incagent_dir)

    bus = MessageBus()

    print("Starting agents...")

    acme = IncAgent(name="Acme Corp", role="buyer", autonomous_mode=True, message_bus=bus)
    cloudpeak = IncAgent(name="CloudPeak", role="seller", autonomous_mode=True, message_bus=bus)
    nexus = IncAgent(name="NexusTech", role="seller", autonomous_mode=True, message_bus=bus)
    agents = [acme, cloudpeak, nexus]

    agents_info = [
        {"name": a.name, "role": a.identity.role, "id": a.identity.fingerprint()[:16]}
        for a in agents
    ]

    # ── Deal 1: GPU ──
    print("Negotiating GPU Cluster Hours...")
    contract_gpu = Contract(
        title="GPU Cluster Hours Q2 2026",
        terms=ContractTerms(
            quantity=2000, unit_price_range=(50, 80), currency="USD",
            delivery_days=14, payment_terms="net_30",
            custom={"gpu_type": "NVIDIA H100", "region": "us-east-1", "sla": "99.95%"},
        ),
    )
    policy_gpu = NegotiationPolicy(min_price=45.0, max_price=72.0, min_quantity=1500, max_quantity=3000, max_rounds=6)
    t0 = time.monotonic()
    r_gpu = await acme.negotiate(contract_gpu, counterparty=cloudpeak, policy=policy_gpu)
    t_gpu = f"{time.monotonic() - t0:.1f}s"

    # ── Deal 2: Data Pipeline ──
    print("Negotiating Data Pipeline...")
    contract_data = Contract(
        title="Enterprise Data Pipeline License",
        terms=ContractTerms(
            quantity=500, unit_price_range=(120, 250), currency="USD",
            delivery_days=7, payment_terms="net_30",
            custom={"support_tier": "premium", "data_retention": "90 days"},
        ),
    )
    policy_data = NegotiationPolicy(min_price=100.0, max_price=220.0, max_rounds=5)
    t0 = time.monotonic()
    r_data = await acme.negotiate(contract_data, counterparty=nexus, policy=policy_data)
    t_data = f"{time.monotonic() - t0:.1f}s"

    deals = []
    for title, r, buyer, seller, t_elapsed in [
        ("GPU Cluster Hours Q2 2026", r_gpu, "Acme Corp", "CloudPeak", t_gpu),
        ("Enterprise Data Pipeline License", r_data, "Acme Corp", "NexusTech", t_data),
    ]:
        if r.final_terms:
            deals.append({
                "agreed": True, "title": title, "buyer": buyer, "seller": seller,
                "unit_price": r.final_terms.unit_price, "quantity": r.final_terms.quantity,
                "total": r.final_terms.estimated_value(), "rounds": r.rounds, "time": t_elapsed,
            })
        else:
            deals.append({"agreed": False, "title": title, "buyer": buyer, "seller": seller, "reason": r.reason})

    # ── Small trades ──
    print("Running additional trades...")
    small_contracts = [
        ("Consulting Services", 5, (100, 200), cloudpeak, "CloudPeak"),
        ("API Monitoring Setup", 10, (30, 60), nexus, "NexusTech"),
        ("Security Audit", 1, (500, 800), cloudpeak, "CloudPeak"),
    ]
    small_deals = []
    for title, qty, price_range, seller, seller_name in small_contracts:
        c = Contract(title=title, terms=ContractTerms(quantity=qty, unit_price_range=price_range, currency="USD"))
        p = NegotiationPolicy(min_price=price_range[0] * 0.8, max_price=price_range[1], max_rounds=3)
        r = await acme.negotiate(c, counterparty=seller, policy=p)
        small_deals.append({
            "agreed": r.final_terms is not None,
            "title": title, "seller": seller_name,
            "total": r.final_terms.estimated_value() if r.final_terms else 0,
        })

    # ── Collect data ──
    print("Generating dashboard...")
    tax = acme.get_tax_summary(2026)
    vendors = acme._tax.get_vendor_summary(2026) or []

    ledger_status = []
    for a in agents:
        entries = a.get_ledger_entries()
        valid = a.verify_ledger()
        ledger_status.append({"name": a.name, "entries": len(entries), "valid": valid})

    ledger_entries = acme.get_ledger_entries(limit=12)
    partners = acme._memory.get_all_partners() or []

    total_value = sum(d["total"] for d in deals if d["agreed"])
    total_value += sum(s["total"] for s in small_deals if s["agreed"])
    deal_count = sum(1 for d in deals if d["agreed"]) + sum(1 for s in small_deals if s["agreed"])

    data = {
        "timestamp": datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M:%S UTC"),
        "agents": agents_info,
        "deals": deals,
        "small_deals": small_deals,
        "tax": tax,
        "vendors": vendors,
        "ledger_status": ledger_status,
        "ledger_entries": ledger_entries,
        "partners": partners,
        "total_value": total_value,
        "deal_count": deal_count,
    }

    html = generate_html(data)

    # Write and open
    out_path = os.path.join(os.path.dirname(__file__), "dashboard.html")
    with open(out_path, "w", encoding="utf-8") as f:
        f.write(html)

    print(f"Dashboard saved: {out_path}")
    webbrowser.open(f"file:///{os.path.abspath(out_path).replace(os.sep, '/')}")

    for a in agents:
        a.close()


if __name__ == "__main__":
    asyncio.run(main())
