"""Phase 3 — Contract enforcement tightening for abi-observability.

Validates NDJSON output structure against expected tier2 schemas.
"""

from __future__ import annotations

import json

from abi_observability.exporters import build_json_summary
from abi_observability.models import Event, Span


class TestTier2EventEnvelopeCompliance:
    """Event NDJSON output matches tier2-event-envelope/1.0 structure."""

    def test_event_has_schema_version(self):
        event = Event(
            event_id="evt-001",
            event_type="RUN_STARTED",
            timestamp="2025-01-01T00:00:00Z",
            run_id="run001",
        )
        record = json.loads(event.to_ndjson_line())
        assert record["schema_version"] == "tier2-event-envelope/1.0"

    def test_event_fields_are_strings(self):
        event = Event(
            event_id="evt-002",
            event_type="TOOL_INVOKED",
            timestamp="2025-01-01T00:00:00Z",
            run_id="run001",
        )
        record = json.loads(event.to_ndjson_line())
        assert isinstance(record["event_id"], str)
        assert isinstance(record["event_type"], str)
        assert isinstance(record["timestamp"], str)


class TestTier2SpanEnvelopeCompliance:
    """Span NDJSON output matches tier2-span-envelope/1.0 structure."""

    def test_span_has_schema_version(self):
        span = Span(
            span_id="span-001",
            trace_id="trace-001",
            name="test",
            start_time="2025-01-01T00:00:00Z",
            end_time="2025-01-01T00:00:01Z",
        )
        record = json.loads(span.to_ndjson_line())
        assert record["schema_version"] == "tier2-span-envelope/1.0"

    def test_span_has_required_fields(self):
        span = Span(
            span_id="span-002",
            trace_id="trace-001",
            name="tool_call",
            start_time="2025-01-01T00:00:00Z",
            end_time="2025-01-01T00:00:01Z",
            parent_span_id="span-001",
        )
        record = json.loads(span.to_ndjson_line())
        required = {"span_id", "trace_id", "name", "start_time", "end_time", "schema_version"}
        assert required.issubset(record.keys())


class TestTier2SummaryCompliance:
    """Summary output matches tier2-summary/1.0 structure."""

    def test_summary_has_schema_version(self, sample_events):
        summary = build_json_summary(sample_events)
        assert summary["schema_version"] == "tier2-summary/1.0"

    def test_summary_has_required_keys(self, sample_events, sample_spans):
        summary = build_json_summary(sample_events, sample_spans)
        assert "total_events" in summary
        assert "events_by_type" in summary
        assert "events_by_category" in summary
        assert "total_spans" in summary
        assert "spans_by_status" in summary

    def test_summary_counts_accurate(self, sample_events):
        summary = build_json_summary(sample_events)
        assert summary["total_events"] == len(sample_events)
        type_total = sum(summary["events_by_type"].values())
        assert type_total == len(sample_events)
