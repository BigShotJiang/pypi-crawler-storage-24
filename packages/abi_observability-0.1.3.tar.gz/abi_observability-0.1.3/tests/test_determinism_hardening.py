"""Phase 1 — Determinism hardening tests for abi-observability.

Verifies:
- Event/Span NDJSON serialization produces identical SHA-256 hashes
- Redaction output is deterministic
- Exporter output is hash-stable
"""

from __future__ import annotations

import hashlib
import json

from abi_observability.exporters import build_json_summary, build_timeline_md
from abi_observability.models import Event, Span
from abi_observability.redaction import redact_dict, redact_event
from abi_observability.writers import write_events_ndjson, write_spans_ndjson


def _sha256(data: str | bytes) -> str:
    if isinstance(data, str):
        data = data.encode()
    return hashlib.sha256(data).hexdigest()


class TestEventNdjsonHashStability:
    """Event.to_ndjson_line() produces identical hash for identical input."""

    def test_event_hash_stable(self):
        event = Event(
            event_id="evt-stable-001",
            event_type="RUN_STARTED",
            timestamp="2025-01-01T00:00:00Z",
            run_id="test0001",
            payload={"message": "Determinism test"},
        )
        hashes = {_sha256(event.to_ndjson_line()) for _ in range(10)}
        assert len(hashes) == 1, f"Expected 1 hash, got {len(hashes)}"

    def test_span_hash_stable(self):
        span = Span(
            span_id="span-stable-001",
            trace_id="trace-001",
            name="test_span",
            start_time="2025-01-01T00:00:00Z",
            end_time="2025-01-01T00:00:01Z",
            status="ok",
            attributes={"key": "value"},
        )
        hashes = {_sha256(span.to_ndjson_line()) for _ in range(10)}
        assert len(hashes) == 1

    def test_event_with_complex_payload_stable(self):
        event = Event(
            event_id="evt-stable-002",
            event_type="POLICY_DECISION",
            timestamp="2025-01-01T00:00:00Z",
            run_id="test0001",
            payload={"z_key": 3, "a_key": 1, "m_key": {"nested_z": 9, "nested_a": 0}},
        )
        lines = [event.to_ndjson_line() for _ in range(10)]
        assert all(line == lines[0] for line in lines)


class TestWriterFileHashStability:
    """Writing same data twice produces byte-identical files."""

    def test_events_file_hash_identical(self, sample_events, tmp_path):
        p1 = tmp_path / "e1.ndjson"
        p2 = tmp_path / "e2.ndjson"
        write_events_ndjson(sample_events, p1)
        write_events_ndjson(sample_events, p2)
        assert _sha256(p1.read_bytes()) == _sha256(p2.read_bytes())

    def test_spans_file_hash_identical(self, sample_spans, tmp_path):
        p1 = tmp_path / "s1.ndjson"
        p2 = tmp_path / "s2.ndjson"
        write_spans_ndjson(sample_spans, p1)
        write_spans_ndjson(sample_spans, p2)
        assert _sha256(p1.read_bytes()) == _sha256(p2.read_bytes())


class TestRedactionDeterminism:
    """Redaction produces identical output for identical input."""

    def test_redact_event_hash_stable(self):
        event = Event(
            event_id="evt-redact-001",
            event_type="MODEL_CALL",
            timestamp="2025-01-01T00:00:00Z",
            payload={"api_key": "secret-123", "model": "claude", "z_field": "z", "a_field": "a"},
        )
        redacted1 = redact_event(event)
        redacted2 = redact_event(event)
        assert redacted1.to_ndjson_line() == redacted2.to_ndjson_line()

    def test_redact_dict_key_order_stable(self):
        data = {"z_api_key": "secret", "a_name": "test", "m_value": 42}
        r1 = redact_dict(data)
        r2 = redact_dict(data)
        assert json.dumps(r1, sort_keys=True) == json.dumps(r2, sort_keys=True)


class TestExporterHashStability:
    """Exporter outputs are hash-stable."""

    def test_timeline_md_hash_stable(self, sample_events, sample_spans):
        md1 = build_timeline_md(sample_events, sample_spans)
        md2 = build_timeline_md(sample_events, sample_spans)
        assert _sha256(md1) == _sha256(md2)

    def test_json_summary_hash_stable(self, sample_events, sample_spans):
        s1 = build_json_summary(sample_events, sample_spans)
        s2 = build_json_summary(sample_events, sample_spans)
        j1 = json.dumps(s1, sort_keys=True)
        j2 = json.dumps(s2, sort_keys=True)
        assert _sha256(j1) == _sha256(j2)
