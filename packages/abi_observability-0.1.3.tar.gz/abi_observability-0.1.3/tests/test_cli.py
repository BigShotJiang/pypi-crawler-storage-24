"""Tests for CLI interface."""
from abi_observability.cli import main


class TestCLI:
    def test_emit_demo(self, tmp_path, capsys):
        out_dir = tmp_path / "demo_out"
        rc = main(["emit-demo", "--out-dir", str(out_dir)])
        assert rc == 0
        assert (out_dir / "events.ndjson").exists()
        assert (out_dir / "spans.ndjson").exists()

    def test_build_timeline(self, ndjson_dir, tmp_path, capsys):
        out = tmp_path / "timeline.md"
        rc = main(["build-timeline", "--in-dir", str(ndjson_dir), "--out", str(out)])
        assert rc == 0
        assert out.exists()
