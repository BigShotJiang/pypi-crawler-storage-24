"""Tests for the dashboard module."""
from __future__ import annotations

import json
import tempfile
from http.client import HTTPConnection
from pathlib import Path
from threading import Thread
from time import sleep

import pytest

from abi_observability.dashboard.dashboard_api import DashboardServer
from abi_observability.dashboard.data_source import RunDataSource
from abi_observability.models import Event, Span
from abi_observability.writers import write_events_ndjson, write_ndjson, write_spans_ndjson


@pytest.fixture
def sample_run_dir(tmp_path: Path) -> Path:
    """Create a sample run evidence pack for testing."""
    run_dir = tmp_path / "runs" / "evidence_pack_test001"
    run_dir.mkdir(parents=True)

    # Create sample events
    events = [
        Event(
            event_id="evt-001",
            event_type="RUN_STARTED",
            timestamp="2025-01-01T00:00:00Z",
            run_id="test001",
            payload={"message": "Test run started"},
        ),
        Event(
            event_id="evt-002",
            event_type="PHASE_STARTED",
            timestamp="2025-01-01T00:00:01Z",
            run_id="test001",
            payload={"phase": "BUILD"},
        ),
        Event(
            event_id="evt-003",
            event_type="MODEL_CALL",
            timestamp="2025-01-01T00:00:02Z",
            run_id="test001",
            payload={"model": "claude-sonnet", "token_count": 1000, "cost": 0.015},
        ),
        Event(
            event_id="evt-004",
            event_type="PHASE_COMPLETED",
            timestamp="2025-01-01T00:00:03Z",
            run_id="test001",
            payload={"phase": "BUILD"},
        ),
        Event(
            event_id="evt-005",
            event_type="RUN_COMPLETED",
            timestamp="2025-01-01T00:00:04Z",
            run_id="test001",
            payload={"status": "success"},
        ),
    ]

    # Create sample spans
    spans = [
        Span(
            span_id="span-001",
            trace_id="trace-001",
            name="test_run",
            start_time="2025-01-01T00:00:00Z",
            end_time="2025-01-01T00:00:04Z",
            status="ok",
        ),
    ]

    # Write files
    write_events_ndjson(events, run_dir / "events.ndjson")
    write_spans_ndjson(spans, run_dir / "spans.ndjson")

    # Create manifest
    manifest = {
        "schema_version": "tier2-pack-manifest/1.0",
        "run_id": "test001",
        "created_at": "2025-01-01T00:00:00Z",
        "components": {
            "events": "events.ndjson",
            "spans": "spans.ndjson",
        },
    }
    with open(run_dir / "manifest.json", "w") as f:
        json.dump(manifest, f, indent=2, sort_keys=True)

    # Create summary
    summary = {
        "schema_version": "tier2-summary/1.0",
        "total_events": 5,
        "total_spans": 1,
    }
    with open(run_dir / "summary.json", "w") as f:
        json.dump(summary, f, indent=2, sort_keys=True)

    return tmp_path / "runs"


class TestRunDataSource:
    """Test the RunDataSource class."""

    def test_list_runs(self, sample_run_dir: Path) -> None:
        """Test listing runs from a directory."""
        source = RunDataSource(runs_dir=sample_run_dir)
        runs = source.list_runs()

        assert len(runs) == 1
        assert runs[0]["run_id"] == "test001"
        assert runs[0]["status"] == "success"
        assert runs[0]["total_events"] == 5
        assert runs[0]["total_tokens"] == 1000
        assert runs[0]["total_cost"] == 0.015

    def test_list_runs_empty_dir(self, tmp_path: Path) -> None:
        """Test listing runs from an empty directory."""
        empty_dir = tmp_path / "empty_runs"
        empty_dir.mkdir()

        source = RunDataSource(runs_dir=empty_dir)
        runs = source.list_runs()

        assert len(runs) == 0

    def test_get_run(self, sample_run_dir: Path) -> None:
        """Test getting detailed run information."""
        source = RunDataSource(runs_dir=sample_run_dir)
        run = source.get_run("test001")

        assert run is not None
        assert run["run_id"] == "test001"
        assert run["status"] == "success"
        assert run["total_events"] == 5
        assert run["total_spans"] == 1
        assert run["total_tokens"] == 1000
        assert run["total_cost"] == 0.015
        assert run["duration_ms"] == 4000
        assert len(run["phases"]) == 1
        assert run["phases"][0]["name"] == "BUILD"

    def test_get_run_not_found(self, sample_run_dir: Path) -> None:
        """Test getting a non-existent run."""
        source = RunDataSource(runs_dir=sample_run_dir)
        run = source.get_run("nonexistent")

        assert run is None

    def test_get_run_tasks(self, sample_run_dir: Path) -> None:
        """Test getting task details for a run."""
        source = RunDataSource(runs_dir=sample_run_dir)
        tasks = source.get_run_tasks("test001")

        # This run has no explicit task events, so should return empty
        assert isinstance(tasks, list)

    def test_calculate_tokens_and_cost(self, sample_run_dir: Path) -> None:
        """Test token and cost calculation."""
        source = RunDataSource(runs_dir=sample_run_dir)
        run = source.get_run("test001")

        assert run is not None
        assert run["total_tokens"] == 1000
        assert run["total_cost"] == 0.015

    def test_determine_status_success(self, tmp_path: Path) -> None:
        """Test status determination for successful run."""
        run_dir = tmp_path / "runs" / "success_run"
        run_dir.mkdir(parents=True)

        events = [
            Event(
                event_id="evt-001",
                event_type="RUN_STARTED",
                timestamp="2025-01-01T00:00:00Z",
                run_id="success001",
            ),
            Event(
                event_id="evt-002",
                event_type="RUN_COMPLETED",
                timestamp="2025-01-01T00:00:01Z",
                run_id="success001",
                payload={"status": "success"},
            ),
        ]
        write_events_ndjson(events, run_dir / "events.ndjson")

        source = RunDataSource(runs_dir=tmp_path / "runs")
        run = source.get_run("success001")

        assert run is not None
        assert run["status"] == "success"

    def test_determine_status_failed(self, tmp_path: Path) -> None:
        """Test status determination for failed run."""
        run_dir = tmp_path / "runs" / "failed_run"
        run_dir.mkdir(parents=True)

        events = [
            Event(
                event_id="evt-001",
                event_type="RUN_STARTED",
                timestamp="2025-01-01T00:00:00Z",
                run_id="failed001",
            ),
            Event(
                event_id="evt-002",
                event_type="TASK_FAILED",
                timestamp="2025-01-01T00:00:01Z",
                run_id="failed001",
                payload={"task_id": "task-1"},
            ),
        ]
        write_events_ndjson(events, run_dir / "events.ndjson")

        source = RunDataSource(runs_dir=tmp_path / "runs")
        run = source.get_run("failed001")

        assert run is not None
        assert run["status"] == "failed"

    def test_determine_status_running(self, tmp_path: Path) -> None:
        """Test status determination for running (incomplete) run."""
        run_dir = tmp_path / "runs" / "running_run"
        run_dir.mkdir(parents=True)

        events = [
            Event(
                event_id="evt-001",
                event_type="RUN_STARTED",
                timestamp="2025-01-01T00:00:00Z",
                run_id="running001",
            ),
        ]
        write_events_ndjson(events, run_dir / "events.ndjson")

        source = RunDataSource(runs_dir=tmp_path / "runs")
        run = source.get_run("running001")

        assert run is not None
        assert run["status"] == "running"


class TestDashboardServer:
    """Test the DashboardServer class."""

    @pytest.fixture
    def server_thread(self, sample_run_dir: Path) -> tuple[Thread, int]:
        """Start the dashboard server in a background thread."""
        import socket

        # Use OS-assigned port to avoid conflicts in CI
        with socket.socket() as s:
            s.bind(("127.0.0.1", 0))
            port = s.getsockname()[1]

        def run_server():
            server = DashboardServer(port=port, runs_dir=sample_run_dir)
            # We'll run it briefly for testing
            from http.server import HTTPServer

            from abi_observability.dashboard.dashboard_api import DashboardHandler

            DashboardHandler.data_source = server.data_source
            httpd = HTTPServer(("127.0.0.1", port), DashboardHandler)
            httpd.timeout = 0.1
            # Serve a few requests then stop
            for _ in range(20):
                httpd.handle_request()

        thread = Thread(target=run_server, daemon=True)
        thread.start()
        sleep(0.5)  # Give server time to start

        return thread, port

    def test_health_endpoint(self, server_thread: tuple[Thread, int]) -> None:
        """Test /api/health endpoint."""
        _, port = server_thread

        conn = HTTPConnection("127.0.0.1", port, timeout=5)
        try:
            conn.request("GET", "/api/health")
            response = conn.getresponse()
            data = json.loads(response.read().decode())

            assert response.status == 200
            assert data["status"] == "ok"
            assert data["service"] == "abi-observability-dashboard"
        finally:
            conn.close()

    def test_runs_endpoint(self, server_thread: tuple[Thread, int]) -> None:
        """Test /api/runs endpoint."""
        _, port = server_thread

        conn = HTTPConnection("127.0.0.1", port, timeout=5)
        try:
            conn.request("GET", "/api/runs")
            response = conn.getresponse()
            data = json.loads(response.read().decode())

            assert response.status == 200
            assert "runs" in data
            assert len(data["runs"]) == 1
            assert data["runs"][0]["run_id"] == "test001"
        finally:
            conn.close()

    def test_run_detail_endpoint(self, server_thread: tuple[Thread, int]) -> None:
        """Test /api/runs/{run_id} endpoint."""
        _, port = server_thread

        conn = HTTPConnection("127.0.0.1", port, timeout=5)
        try:
            conn.request("GET", "/api/runs/test001")
            response = conn.getresponse()
            data = json.loads(response.read().decode())

            assert response.status == 200
            assert data["run_id"] == "test001"
            assert data["status"] == "success"
            assert data["total_events"] == 5
        finally:
            conn.close()

    def test_run_tasks_endpoint(self, server_thread: tuple[Thread, int]) -> None:
        """Test /api/runs/{run_id}/tasks endpoint."""
        _, port = server_thread

        conn = HTTPConnection("127.0.0.1", port, timeout=5)
        try:
            conn.request("GET", "/api/runs/test001/tasks")
            response = conn.getresponse()
            data = json.loads(response.read().decode())

            assert response.status == 200
            assert data["run_id"] == "test001"
            assert "tasks" in data
            assert isinstance(data["tasks"], list)
        finally:
            conn.close()

    def test_static_file_serving(self, server_thread: tuple[Thread, int]) -> None:
        """Test serving static files."""
        _, port = server_thread

        conn = HTTPConnection("127.0.0.1", port, timeout=5)
        try:
            conn.request("GET", "/")
            response = conn.getresponse()
            content = response.read()

            assert response.status == 200
            assert b"ABI Observability Dashboard" in content
            assert b"<!DOCTYPE html>" in content
        finally:
            conn.close()

    def test_not_found(self, server_thread: tuple[Thread, int]) -> None:
        """Test 404 response for non-existent endpoints."""
        _, port = server_thread

        conn = HTTPConnection("127.0.0.1", port, timeout=5)
        try:
            conn.request("GET", "/api/nonexistent")
            response = conn.getresponse()
            data = json.loads(response.read().decode())

            assert response.status == 404
            assert "error" in data
        finally:
            conn.close()


@pytest.fixture
def sample_dogfood_run_dir(tmp_path: Path) -> Path:
    """Create a sample dogfood.py format run directory for testing."""
    run_dir = tmp_path / "runs" / "run-2025-01-01-120000"
    run_dir.mkdir(parents=True)

    # Create run_results.json (array of task results)
    run_results = [
        {
            "task_id": "T-001",
            "title": "Build project",
            "status": "PASS",
            "attempts": 1,
            "started_at": "2025-01-01T12:00:00Z",
            "completed_at": "2025-01-01T12:01:00Z",
        },
        {
            "task_id": "T-002",
            "title": "Run tests",
            "status": "PASS",
            "attempts": 2,
            "started_at": "2025-01-01T12:01:00Z",
            "completed_at": "2025-01-01T12:03:00Z",
        },
        {
            "task_id": "T-003",
            "title": "Deploy to staging",
            "status": "PASS_UNVERIFIED",
            "attempts": 1,
            "started_at": "2025-01-01T12:03:00Z",
            "completed_at": "2025-01-01T12:05:00Z",
        },
    ]

    with open(run_dir / "run_results.json", "w") as f:
        json.dump(run_results, f, indent=2)

    # Create run_summary.md
    summary_md = """# Run Summary

| Task ID | Title | Status | Attempts |
|---------|-------|--------|----------|
| T-001 | Build project | PASS | 1 |
| T-002 | Run tests | PASS | 2 |
| T-003 | Deploy to staging | PASS_UNVERIFIED | 1 |
"""
    with open(run_dir / "run_summary.md", "w") as f:
        f.write(summary_md)

    # Create per-task logs
    with open(run_dir / "T-001.log", "w") as f:
        f.write("Building project...\nBuild successful!\n")

    with open(run_dir / "T-002.log", "w") as f:
        f.write("Running tests...\nAttempt 1 failed.\nAttempt 2 passed!\n")

    # Create generation_records.jsonl with token/cost data
    generation_records = [
        {
            "task_id": "T-001",
            "input_tokens": 500,
            "output_tokens": 300,
            "cost_usd": 0.012,
        },
        {
            "task_id": "T-002",
            "input_tokens": 800,
            "output_tokens": 400,
            "cost_usd": 0.018,
        },
        {
            "task_id": "T-003",
            "input_tokens": 600,
            "output_tokens": 250,
            "cost_usd": 0.013,
        },
    ]

    write_ndjson(generation_records, run_dir / "generation_records.jsonl")

    return tmp_path / "runs"


class TestDogfoodFormat:
    """Test support for dogfood.py output format."""

    def test_list_dogfood_runs(self, sample_dogfood_run_dir: Path) -> None:
        """Test listing runs in dogfood format."""
        source = RunDataSource(runs_dir=sample_dogfood_run_dir)
        runs = source.list_runs()

        assert len(runs) == 1
        run = runs[0]
        assert run["run_id"] == "run-2025-01-01-120000"
        assert run["status"] == "success"
        assert run["total_events"] == 3  # 3 tasks
        assert run["total_tokens"] == 2850  # 500+300+800+400+600+250
        assert run["total_cost"] == 0.043  # 0.012+0.018+0.013
        assert run["format"] == "dogfood"

    def test_get_dogfood_run(self, sample_dogfood_run_dir: Path) -> None:
        """Test getting detailed dogfood run information."""
        source = RunDataSource(runs_dir=sample_dogfood_run_dir)
        run = source.get_run("run-2025-01-01-120000")

        assert run is not None
        assert run["run_id"] == "run-2025-01-01-120000"
        assert run["status"] == "success"
        assert run["total_events"] == 3
        assert run["total_spans"] == 0  # Not applicable for dogfood
        assert run["total_tokens"] == 2850
        assert run["total_cost"] == 0.043
        assert run["duration_ms"] == 300000  # 5 minutes
        assert run["started_at"] == "2025-01-01T12:00:00Z"
        assert run["completed_at"] == "2025-01-01T12:05:00Z"
        assert run["phases"] == []  # No phases in dogfood format
        assert run["format"] == "dogfood"

    def test_get_dogfood_run_tasks(self, sample_dogfood_run_dir: Path) -> None:
        """Test getting task details from dogfood format."""
        source = RunDataSource(runs_dir=sample_dogfood_run_dir)
        tasks = source.get_run_tasks("run-2025-01-01-120000")

        assert len(tasks) == 3

        # Check first task
        task1 = tasks[0]
        assert task1["task_id"] == "T-001"
        assert task1["title"] == "Build project"
        assert task1["status"] == "PASS"
        assert task1["attempts"] == 1
        assert task1["duration_ms"] == 60000  # 1 minute
        assert task1["started_at"] == "2025-01-01T12:00:00Z"
        assert task1["completed_at"] == "2025-01-01T12:01:00Z"

        # Check second task
        task2 = tasks[1]
        assert task2["task_id"] == "T-002"
        assert task2["title"] == "Run tests"
        assert task2["status"] == "PASS"
        assert task2["attempts"] == 2
        assert task2["duration_ms"] == 120000  # 2 minutes

        # Check third task
        task3 = tasks[2]
        assert task3["task_id"] == "T-003"
        assert task3["status"] == "PASS_UNVERIFIED"

    def test_dogfood_status_determination(self, tmp_path: Path) -> None:
        """Test status determination for dogfood runs."""
        run_dir = tmp_path / "runs" / "failed-run"
        run_dir.mkdir(parents=True)

        # Create a run with a failed task
        run_results = [
            {
                "task_id": "T-001",
                "title": "Task 1",
                "status": "PASS",
                "attempts": 1,
                "started_at": "2025-01-01T12:00:00Z",
                "completed_at": "2025-01-01T12:01:00Z",
            },
            {
                "task_id": "T-002",
                "title": "Task 2",
                "status": "FAIL",
                "attempts": 3,
                "started_at": "2025-01-01T12:01:00Z",
                "completed_at": "2025-01-01T12:02:00Z",
            },
        ]

        with open(run_dir / "run_results.json", "w") as f:
            json.dump(run_results, f)

        source = RunDataSource(runs_dir=tmp_path / "runs")
        run = source.get_run("failed-run")

        assert run is not None
        assert run["status"] == "failed"

    def test_dogfood_without_generation_records(self, tmp_path: Path) -> None:
        """Test dogfood format without generation_records.jsonl."""
        run_dir = tmp_path / "runs" / "no-gen-records"
        run_dir.mkdir(parents=True)

        run_results = [
            {
                "task_id": "T-001",
                "title": "Task 1",
                "status": "PASS",
                "attempts": 1,
                "started_at": "2025-01-01T12:00:00Z",
                "completed_at": "2025-01-01T12:01:00Z",
            },
        ]

        with open(run_dir / "run_results.json", "w") as f:
            json.dump(run_results, f)

        source = RunDataSource(runs_dir=tmp_path / "runs")
        run = source.get_run("no-gen-records")

        assert run is not None
        assert run["total_tokens"] == 0
        assert run["total_cost"] == 0.0

    def test_mixed_format_runs(
        self, sample_run_dir: Path, sample_dogfood_run_dir: Path, tmp_path: Path
    ) -> None:
        """Test listing runs when both formats are present."""
        # Create a mixed directory with both formats
        mixed_dir = tmp_path / "mixed_runs"
        mixed_dir.mkdir()

        # Copy evidence pack format
        evidence_pack = mixed_dir / "evidence_pack_test001"
        evidence_pack.mkdir()
        import shutil

        for file in (sample_run_dir / "evidence_pack_test001").iterdir():
            shutil.copy(file, evidence_pack)

        # Copy dogfood format
        dogfood_run = mixed_dir / "run-2025-01-01-120000"
        dogfood_run.mkdir()
        for file in (sample_dogfood_run_dir / "run-2025-01-01-120000").iterdir():
            shutil.copy(file, dogfood_run)

        source = RunDataSource(runs_dir=mixed_dir)
        runs = source.list_runs()

        assert len(runs) == 2

        # Find each run by format
        dogfood_runs = [r for r in runs if r.get("format") == "dogfood"]
        evidence_runs = [r for r in runs if r.get("format") != "dogfood"]

        assert len(dogfood_runs) == 1
        assert len(evidence_runs) == 1
