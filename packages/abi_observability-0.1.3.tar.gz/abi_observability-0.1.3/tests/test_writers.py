"""Tests for NDJSON writers."""
import json

from abi_observability.models import Event, Span
from abi_observability.writers import (
    append_event,
    append_span,
    read_ndjson,
    write_events_ndjson,
    write_spans_ndjson,
)


class TestWriteEvents:
    def test_writes_ndjson(self, sample_events, tmp_path):
        path = tmp_path / "events.ndjson"
        count = write_events_ndjson(sample_events, path)
        assert count == len(sample_events)
        assert path.exists()

    def test_deterministic_ordering(self, sample_events, tmp_path):
        """Same input always produces same output."""
        p1 = tmp_path / "out1.ndjson"
        p2 = tmp_path / "out2.ndjson"
        write_events_ndjson(sample_events, p1)
        write_events_ndjson(sample_events, p2)
        assert p1.read_text() == p2.read_text()

    def test_sorted_by_timestamp(self, tmp_path):
        events = [
            Event(event_id="b", event_type="LATE", timestamp="2025-01-01T00:00:02Z", run_id="r1"),
            Event(event_id="a", event_type="EARLY", timestamp="2025-01-01T00:00:01Z", run_id="r1"),
        ]
        path = tmp_path / "events.ndjson"
        write_events_ndjson(events, path)
        records = read_ndjson(path)
        assert records[0]["event_type"] == "EARLY"
        assert records[1]["event_type"] == "LATE"

    def test_each_line_is_valid_json(self, sample_events, tmp_path):
        path = tmp_path / "events.ndjson"
        write_events_ndjson(sample_events, path)
        for line in path.read_text().strip().split("\n"):
            json.loads(line)  # Should not raise


class TestWriteSpans:
    def test_writes_ndjson(self, sample_spans, tmp_path):
        path = tmp_path / "spans.ndjson"
        count = write_spans_ndjson(sample_spans, path)
        assert count == len(sample_spans)

    def test_deterministic(self, sample_spans, tmp_path):
        p1 = tmp_path / "s1.ndjson"
        p2 = tmp_path / "s2.ndjson"
        write_spans_ndjson(sample_spans, p1)
        write_spans_ndjson(sample_spans, p2)
        assert p1.read_text() == p2.read_text()


class TestAppend:
    def test_append_event(self, tmp_path):
        path = tmp_path / "events.ndjson"
        e1 = Event(event_id="1", event_type="A", timestamp="t1", run_id="r1")
        e2 = Event(event_id="2", event_type="B", timestamp="t2", run_id="r1")
        append_event(e1, path)
        append_event(e2, path)
        records = read_ndjson(path)
        assert len(records) == 2

    def test_append_span(self, tmp_path):
        path = tmp_path / "spans.ndjson"
        s = Span(span_id="1", trace_id="t1", name="test", start_time="t1", end_time="t2")
        append_span(s, path)
        records = read_ndjson(path)
        assert len(records) == 1


class TestReadNdjson:
    def test_read_existing(self, fixtures_dir):
        records = read_ndjson(fixtures_dir / "sample_events.ndjson")
        assert len(records) >= 3

    def test_read_missing(self, tmp_path):
        records = read_ndjson(tmp_path / "nonexistent.ndjson")
        assert records == []
