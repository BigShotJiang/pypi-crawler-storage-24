"""Phase 2 — Evidence deepening for abi-observability.

Verifies:
- Log schema validation (events have required fields)
- Schema rejection behavior (malformed events detected)
- Span records include required traceability fields
"""

from __future__ import annotations

import json

from abi_observability.models import EVENT_CATEGORIES, EVENT_TYPE_TO_CATEGORY, Event, Span
from abi_observability.writers import read_ndjson, write_events_ndjson, write_spans_ndjson


class TestEventSchemaValidation:
    """Events written to NDJSON include all required fields."""

    def test_event_ndjson_has_required_fields(self, sample_events, tmp_path):
        path = tmp_path / "events.ndjson"
        write_events_ndjson(sample_events, path)
        records = read_ndjson(path)
        for record in records:
            assert "event_id" in record, "Missing event_id"
            assert "event_type" in record, "Missing event_type"
            assert "timestamp" in record, "Missing timestamp"
            assert "schema_version" in record, "Missing schema_version"
            assert record["schema_version"] == "tier2-event-envelope/1.0"

    def test_span_ndjson_has_required_fields(self, sample_spans, tmp_path):
        path = tmp_path / "spans.ndjson"
        write_spans_ndjson(sample_spans, path)
        records = read_ndjson(path)
        for record in records:
            assert "span_id" in record, "Missing span_id"
            assert "trace_id" in record, "Missing trace_id"
            assert "name" in record, "Missing name"
            assert "start_time" in record, "Missing start_time"
            assert "end_time" in record, "Missing end_time"
            assert "schema_version" in record, "Missing schema_version"
            assert record["schema_version"] == "tier2-span-envelope/1.0"


class TestSchemaRejection:
    """Malformed data is properly detected."""

    def test_event_without_event_id_fails_ndjson_parse(self):
        """Events missing required fields produce incomplete NDJSON."""
        event = Event(event_id="", event_type="RUN_STARTED", timestamp="2025-01-01T00:00:00Z")
        line = event.to_ndjson_line()
        record = json.loads(line)
        # empty string event_id indicates incomplete record
        assert record["event_id"] == ""

    def test_span_without_trace_id_detectable(self):
        span = Span(span_id="s1", trace_id="", name="test", start_time="t1", end_time="t2")
        record = json.loads(span.to_ndjson_line())
        assert record["trace_id"] == ""

    def test_unknown_event_type_classified_as_system(self):
        """Unknown event types default to 'system' category."""
        event = Event(event_id="e1", event_type="UNKNOWN_TYPE", timestamp="t1")
        assert event.category == "system"


class TestEventCategoryCompleteness:
    """All declared event types have a category mapping."""

    def test_all_categories_have_types(self):
        for category, types in EVENT_CATEGORIES.items():
            assert len(types) > 0, f"Category '{category}' has no types"

    def test_reverse_lookup_complete(self):
        total_types = sum(len(types) for types in EVENT_CATEGORIES.values())
        assert len(EVENT_TYPE_TO_CATEGORY) == total_types

    def test_no_duplicate_type_assignments(self):
        """Each event type is in exactly one category."""
        seen = {}
        for category, types in EVENT_CATEGORIES.items():
            for t in types:
                assert t not in seen, f"Type '{t}' in both '{seen[t]}' and '{category}'"
                seen[t] = category
