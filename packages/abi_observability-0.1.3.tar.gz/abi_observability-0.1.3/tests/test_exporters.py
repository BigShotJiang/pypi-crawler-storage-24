"""Tests for offline exporters."""
import json

from abi_observability.exporters import (
    build_json_summary,
    build_timeline_md,
    export_summary,
    export_timeline,
)


class TestTimelineMd:
    def test_builds_timeline(self, sample_events, sample_spans):
        md = build_timeline_md(sample_events, sample_spans)
        assert "# Run Timeline" in md
        assert "## Events" in md
        assert "## Spans" in md
        assert "RUN_STARTED" in md

    def test_deterministic(self, sample_events, sample_spans):
        md1 = build_timeline_md(sample_events, sample_spans)
        md2 = build_timeline_md(sample_events, sample_spans)
        assert md1 == md2

    def test_events_chronological(self, sample_events):
        md = build_timeline_md(sample_events)
        lines = [line for line in md.split("\n") if line.startswith("|") and "2025" in line]
        timestamps = [line.split("|")[1].strip() for line in lines]
        assert timestamps == sorted(timestamps)

    def test_no_spans_ok(self, sample_events):
        md = build_timeline_md(sample_events)
        assert "## Events" in md
        assert "## Spans" not in md


class TestJsonSummary:
    def test_counts_events(self, sample_events):
        summary = build_json_summary(sample_events)
        assert summary["total_events"] == len(sample_events)
        assert "events_by_type" in summary
        assert "events_by_category" in summary

    def test_counts_spans(self, sample_events, sample_spans):
        summary = build_json_summary(sample_events, sample_spans)
        assert summary["total_spans"] == len(sample_spans)

    def test_deterministic(self, sample_events):
        s1 = build_json_summary(sample_events)
        s2 = build_json_summary(sample_events)
        assert json.dumps(s1, sort_keys=True) == json.dumps(s2, sort_keys=True)


class TestExportFunctions:
    def test_export_timeline_from_ndjson(self, ndjson_dir, tmp_path):
        out = tmp_path / "timeline.md"
        export_timeline(ndjson_dir, out)
        assert out.exists()
        content = out.read_text()
        assert "# Run Timeline" in content

    def test_export_summary_from_ndjson(self, ndjson_dir, tmp_path):
        out = tmp_path / "summary.json"
        export_summary(ndjson_dir, out)
        assert out.exists()
        data = json.loads(out.read_text())
        assert data["total_events"] > 0
