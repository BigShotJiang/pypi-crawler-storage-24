"""Shared fixtures for abi-observability tests."""
from pathlib import Path

import pytest

from abi_observability.models import Event, Span

FIXTURES_DIR = Path(__file__).resolve().parent / "fixtures"


@pytest.fixture
def sample_events() -> list[Event]:
    return [
        Event(
            event_id="evt-001",
            event_type="RUN_STARTED",
            timestamp="2025-01-01T00:00:00Z",
            run_id="test0001",
            payload={"message": "Run started"},
        ),
        Event(
            event_id="evt-002",
            event_type="POLICY_DECISION",
            timestamp="2025-01-01T00:00:01Z",
            run_id="test0001",
            payload={"decision": "allow", "tool": "read_file"},
        ),
        Event(
            event_id="evt-003",
            event_type="TOOL_INVOKED",
            timestamp="2025-01-01T00:00:02Z",
            run_id="test0001",
            payload={"tool": "read_file"},
        ),
        Event(
            event_id="evt-004",
            event_type="RUN_COMPLETED",
            timestamp="2025-01-01T00:00:03Z",
            run_id="test0001",
            payload={"status": "success"},
        ),
    ]


@pytest.fixture
def sample_spans() -> list[Span]:
    return [
        Span(
            span_id="span-001",
            trace_id="trace-001",
            name="test_run",
            start_time="2025-01-01T00:00:00Z",
            end_time="2025-01-01T00:00:03Z",
            status="ok",
            attributes={"run_id": "test0001"},
        ),
        Span(
            span_id="span-002",
            trace_id="trace-001",
            name="tool_call",
            start_time="2025-01-01T00:00:02Z",
            end_time="2025-01-01T00:00:02.500Z",
            status="ok",
            parent_span_id="span-001",
            attributes={"tool": "read_file"},
        ),
    ]


@pytest.fixture
def fixtures_dir() -> Path:
    return FIXTURES_DIR


@pytest.fixture
def ndjson_dir(sample_events, sample_spans, tmp_path) -> Path:
    """Create a temp directory with NDJSON files."""
    from abi_observability.writers import write_events_ndjson, write_spans_ndjson

    write_events_ndjson(sample_events, tmp_path / "events.ndjson")
    write_spans_ndjson(sample_spans, tmp_path / "spans.ndjson")
    return tmp_path
