"""Tests for the event collector and exporters."""
import json
from pathlib import Path

import pytest

from abi_observability.collector import Collector, CollectorConfig, get_collector, reset_collector
from abi_observability.exporters.langfuse_exporter import (
    LangfuseExporter,
    LangfuseExporterConfig,
)
from abi_observability.exporters.otlp_exporter import OTLPExporter, OTLPExporterConfig
from abi_observability.models import Event, Span


class TestOTLPExporter:
    """Test OTLP exporter functionality."""

    def test_export_to_file(self, sample_spans, tmp_path):
        """Test exporting spans to OTLP JSONL file."""
        config = OTLPExporterConfig(
            export_type="file",
            file_path=tmp_path / "otlp_traces.jsonl",
        )
        exporter = OTLPExporter(config)

        result = exporter.export(sample_spans)

        assert result["status"] == "success"
        assert result["exported"] == len(sample_spans)
        assert Path(result["file_path"]).exists()

        # Verify JSONL format
        content = Path(result["file_path"]).read_text()
        lines = [line for line in content.strip().split("\n") if line]
        assert len(lines) == 1  # One batch export

        # Parse and verify OTLP structure
        otlp_data = json.loads(lines[0])
        assert "resourceSpans" in otlp_data
        assert len(otlp_data["resourceSpans"]) > 0

        # Verify span structure
        resource_span = otlp_data["resourceSpans"][0]
        assert "resource" in resource_span
        assert "scopeSpans" in resource_span
        assert len(resource_span["scopeSpans"]) > 0

        scope_span = resource_span["scopeSpans"][0]
        assert "spans" in scope_span
        assert len(scope_span["spans"]) == len(sample_spans)

        # Verify span fields
        otlp_span = scope_span["spans"][0]
        assert "traceId" in otlp_span
        assert "spanId" in otlp_span
        assert "name" in otlp_span
        assert "startTimeUnixNano" in otlp_span
        assert "endTimeUnixNano" in otlp_span
        assert "status" in otlp_span

    def test_export_empty_spans(self):
        """Test exporting empty span list."""
        exporter = OTLPExporter()
        result = exporter.export([])

        assert result["status"] == "success"
        assert result["exported"] == 0

    def test_convert_span_to_otlp(self, sample_spans):
        """Test conversion of internal span to OTLP format."""
        exporter = OTLPExporter()
        span = sample_spans[0]

        otlp_span = exporter._span_to_otlp(span)

        assert otlp_span["name"] == span.name
        assert otlp_span["traceId"] is not None
        assert otlp_span["spanId"] is not None
        assert otlp_span["status"]["code"] in (1, 2)  # OK or ERROR

    def test_attribute_conversion(self):
        """Test attribute type conversion to OTLP format."""
        exporter = OTLPExporter()

        # Test different types
        assert exporter._attribute_to_otlp("bool_key", True)["value"]["boolValue"] is True
        assert exporter._attribute_to_otlp("int_key", 42)["value"]["intValue"] == 42
        assert exporter._attribute_to_otlp("float_key", 3.14)["value"]["doubleValue"] == 3.14
        assert exporter._attribute_to_otlp("str_key", "test")["value"]["stringValue"] == "test"

        # Complex types should be JSON-stringified
        complex_val = {"nested": "value"}
        result = exporter._attribute_to_otlp("complex", complex_val)
        assert json.loads(result["value"]["stringValue"]) == complex_val


class TestLangfuseExporter:
    """Test Langfuse exporter functionality."""

    def test_export_spans_offline(self, sample_spans, tmp_path):
        """Test exporting spans to Langfuse offline JSONL."""
        config = LangfuseExporterConfig(
            mode="offline",
            file_path=tmp_path / "langfuse_traces.jsonl",
        )
        exporter = LangfuseExporter(config)

        result = exporter.export_spans(sample_spans)

        assert result["status"] == "success"
        assert result["exported"] > 0
        assert result["mode"] == "offline"
        assert Path(result["file_path"]).exists()

        # Verify JSONL format
        content = Path(result["file_path"]).read_text()
        lines = [line for line in content.strip().split("\n") if line]
        assert len(lines) == 1  # One trace per trace_id

        # Parse and verify Langfuse trace structure
        trace = json.loads(lines[0])
        assert "id" in trace
        assert "name" in trace
        assert "timestamp" in trace
        assert "spans" in trace

    def test_export_events_offline(self, sample_events, tmp_path):
        """Test exporting events to Langfuse offline JSONL."""
        config = LangfuseExporterConfig(
            mode="offline",
            file_path=tmp_path / "langfuse_events.jsonl",
        )
        exporter = LangfuseExporter(config)

        result = exporter.export_events(sample_events)

        assert result["status"] == "success"
        assert result["exported"] == len(sample_events)

        # Verify observations
        content = Path(result["file_path"]).read_text()
        lines = [line for line in content.strip().split("\n") if line]
        assert len(lines) == len(sample_events)

        # Parse first observation
        obs = json.loads(lines[0])
        assert obs["type"] == "EVENT"
        assert "id" in obs
        assert "traceId" in obs
        assert "name" in obs

    def test_export_generation_record(self, tmp_path):
        """Test exporting a GenerationRecord."""
        config = LangfuseExporterConfig(
            mode="offline",
            file_path=tmp_path / "langfuse_gen.jsonl",
        )
        exporter = LangfuseExporter(config)

        generation_record = {
            "generation_id": "gen-001",
            "run_id": "run-001",
            "phase": "planning",
            "task": "code_generation",
            "model": "claude-sonnet-4.5",
            "prompt": "Write a hello world function",
            "completion": "def hello(): print('Hello, world!')",
            "timestamp": "2025-01-01T00:00:00Z",
            "metadata": {
                "usage": {"input_tokens": 10, "output_tokens": 20},
                "model_parameters": {"temperature": 0.7},
            },
        }

        result = exporter.export_generation(generation_record)

        assert result["status"] == "success"
        assert result["exported"] == 1

        # Verify generation format
        content = Path(result["file_path"]).read_text()
        gen = json.loads(content.strip())
        assert gen["type"] == "GENERATION"
        assert gen["model"] == "claude-sonnet-4.5"
        assert gen["input"] == "Write a hello world function"
        assert gen["output"] == "def hello(): print('Hello, world!')"
        assert gen["usage"]["input_tokens"] == 10

    def test_online_mode_requires_credentials(self):
        """Test that online mode fails without credentials."""
        config = LangfuseExporterConfig(
            mode="online",
            public_key="",
            secret_key="",
        )
        exporter = LangfuseExporter(config)

        result = exporter.export_spans([])

        # Should fail with missing credentials
        assert result["status"] in ("success", "error")  # empty list is success
        # Only test with actual spans
        span = Span(
            span_id="test",
            trace_id="test",
            name="test",
            start_time="2025-01-01T00:00:00Z",
            end_time="2025-01-01T00:00:01Z",
        )
        result = exporter.export_spans([span])
        if result["status"] == "error":
            assert "LANGFUSE_PUBLIC_KEY" in result["error"] or "LANGFUSE_SECRET_KEY" in result["error"]


class TestCollector:
    """Test the event collector."""

    def test_collector_initialization(self):
        """Test collector initializes with default config."""
        collector = Collector()
        assert collector.config.buffer_size == 100
        assert collector.config.flush_interval == 60.0

    def test_collector_from_config(self):
        """Test collector with custom config."""
        config = CollectorConfig(
            buffer_size=50,
            flush_interval=30.0,
            enabled_exporters=["file"],
            auto_flush=False,
        )
        collector = Collector(config)

        assert collector.config.buffer_size == 50
        assert collector.config.flush_interval == 30.0
        assert collector.config.auto_flush is False

    def test_collect_events(self, sample_events):
        """Test collecting events."""
        config = CollectorConfig(auto_flush=False)
        collector = Collector(config)

        collector.collect_events(sample_events)

        status = collector.buffer_status
        assert status["events_buffered"] == len(sample_events)
        assert status["total_buffered"] == len(sample_events)

    def test_collect_spans(self, sample_spans):
        """Test collecting spans."""
        config = CollectorConfig(auto_flush=False)
        collector = Collector(config)

        collector.collect_spans(sample_spans)

        status = collector.buffer_status
        assert status["spans_buffered"] == len(sample_spans)
        assert status["total_buffered"] == len(sample_spans)

    def test_flush_to_file(self, sample_events, sample_spans, tmp_path, monkeypatch):
        """Test flushing events and spans to file."""
        # Set file path via environment
        monkeypatch.setenv("ABI_COLLECTOR_FILE_PATH", str(tmp_path / "collector_data"))

        config = CollectorConfig(
            auto_flush=False,
            enabled_exporters=["file"],
        )
        collector = Collector(config)

        collector.collect_events(sample_events)
        collector.collect_spans(sample_spans)

        result = collector.flush()

        assert result["events_flushed"] == len(sample_events)
        assert result["spans_flushed"] == len(sample_spans)

        # Verify files were created
        events_file = tmp_path / "collector_data" / "events.ndjson"
        spans_file = tmp_path / "collector_data" / "spans.ndjson"

        assert events_file.exists()
        assert spans_file.exists()

        # Verify content
        events_lines = events_file.read_text().strip().split("\n")
        assert len(events_lines) == len(sample_events)

        spans_lines = spans_file.read_text().strip().split("\n")
        assert len(spans_lines) == len(sample_spans)

    def test_auto_flush_on_buffer_size(self, sample_events, tmp_path, monkeypatch):
        """Test auto-flush when buffer size is reached."""
        monkeypatch.setenv("ABI_COLLECTOR_FILE_PATH", str(tmp_path / "collector_data"))

        config = CollectorConfig(
            buffer_size=2,  # Small buffer
            auto_flush=True,
            enabled_exporters=["file"],
        )
        collector = Collector(config)

        # Add events one by one
        collector.collect_event(sample_events[0])
        assert collector.buffer_status["events_buffered"] == 1

        collector.collect_event(sample_events[1])
        # Should auto-flush at buffer_size=2
        assert collector.buffer_status["events_buffered"] == 0

    def test_global_collector(self):
        """Test global collector singleton."""
        reset_collector()

        collector1 = get_collector()
        collector2 = get_collector()

        assert collector1 is collector2

        reset_collector()

    def test_collector_shutdown(self, sample_spans, tmp_path, monkeypatch):
        """Test collector shutdown flushes data."""
        monkeypatch.setenv("ABI_COLLECTOR_FILE_PATH", str(tmp_path / "collector_data"))

        config = CollectorConfig(
            auto_flush=False,
            enabled_exporters=["file"],
        )
        collector = Collector(config)

        collector.collect_spans(sample_spans)
        result = collector.shutdown()

        assert result["spans_flushed"] == len(sample_spans)
        assert collector.buffer_status["spans_buffered"] == 0


class TestIntegration:
    """Integration tests for collector with exporters."""

    def test_collector_with_otlp_exporter(self, sample_spans, tmp_path, monkeypatch):
        """Test collector with OTLP exporter enabled."""
        monkeypatch.setenv("ABI_OTLP_EXPORT_TYPE", "file")
        monkeypatch.setenv("ABI_OTLP_FILE_PATH", str(tmp_path / "otlp_output.jsonl"))

        config = CollectorConfig(
            auto_flush=False,
            enabled_exporters=["otlp"],
        )
        collector = Collector(config)

        collector.collect_spans(sample_spans)
        result = collector.flush()

        assert result["spans_flushed"] == len(sample_spans)
        assert "otlp" in result["exporters"]

        # Verify OTLP file was created
        otlp_file = tmp_path / "otlp_output.jsonl"
        assert otlp_file.exists()

    def test_collector_with_langfuse_exporter(self, sample_spans, tmp_path, monkeypatch):
        """Test collector with Langfuse exporter enabled."""
        monkeypatch.setenv("LANGFUSE_MODE", "offline")
        monkeypatch.setenv("LANGFUSE_FILE_PATH", str(tmp_path / "langfuse_output.jsonl"))

        config = CollectorConfig(
            auto_flush=False,
            enabled_exporters=["langfuse"],
        )
        collector = Collector(config)

        collector.collect_spans(sample_spans)
        result = collector.flush()

        assert result["spans_flushed"] == len(sample_spans)
        assert "langfuse_spans" in result["exporters"]

        # Verify Langfuse file was created
        langfuse_file = tmp_path / "langfuse_output.jsonl"
        assert langfuse_file.exists()

    def test_collector_with_multiple_exporters(self, sample_spans, tmp_path, monkeypatch):
        """Test collector with multiple exporters enabled simultaneously."""
        monkeypatch.setenv("ABI_COLLECTOR_FILE_PATH", str(tmp_path / "file_output"))
        monkeypatch.setenv("ABI_OTLP_EXPORT_TYPE", "file")
        monkeypatch.setenv("ABI_OTLP_FILE_PATH", str(tmp_path / "otlp_output.jsonl"))
        monkeypatch.setenv("LANGFUSE_MODE", "offline")
        monkeypatch.setenv("LANGFUSE_FILE_PATH", str(tmp_path / "langfuse_output.jsonl"))

        config = CollectorConfig(
            auto_flush=False,
            enabled_exporters=["file", "otlp", "langfuse"],
        )
        collector = Collector(config)

        collector.collect_spans(sample_spans)
        result = collector.flush()

        assert result["spans_flushed"] == len(sample_spans)

        # All three exporters should have results
        assert "file_spans" in result["exporters"]
        assert "otlp" in result["exporters"]
        assert "langfuse_spans" in result["exporters"]

        # Verify all files were created
        assert (tmp_path / "file_output" / "spans.ndjson").exists()
        assert (tmp_path / "otlp_output.jsonl").exists()
        assert (tmp_path / "langfuse_output.jsonl").exists()
