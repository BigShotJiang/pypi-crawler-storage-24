"""Tests for redaction and classification."""
from abi_observability.models import Event
from abi_observability.redaction import (
    classify_event,
    classify_events,
    is_sensitive_key,
    redact_dict,
    redact_event,
)


class TestSensitiveKeyDetection:
    def test_api_key(self):
        assert is_sensitive_key("api_key") is True

    def test_secret_token(self):
        assert is_sensitive_key("secret_token") is True

    def test_password(self):
        assert is_sensitive_key("db_password") is True

    def test_safe_key(self):
        assert is_sensitive_key("username") is False

    def test_case_insensitive(self):
        assert is_sensitive_key("API_KEY") is True


class TestRedactDict:
    def test_redacts_sensitive(self):
        data = {"api_key": "sk-12345", "name": "test"}
        redacted = redact_dict(data)
        assert redacted["api_key"] == "<REDACTED>"
        assert redacted["name"] == "test"

    def test_nested_redaction(self):
        data = {"config": {"secret_token": "abc123", "host": "localhost"}}
        redacted = redact_dict(data)
        assert redacted["config"]["secret_token"] == "<REDACTED>"
        assert redacted["config"]["host"] == "localhost"

    def test_list_redaction(self):
        data = {"items": [{"password": "secret"}, {"name": "safe"}]}
        redacted = redact_dict(data)
        assert redacted["items"][0]["password"] == "<REDACTED>"
        assert redacted["items"][1]["name"] == "safe"

    def test_deterministic(self):
        data = {"b_key": "val_b", "a_secret": "val_a", "c_key": "val_c"}
        r1 = redact_dict(data)
        r2 = redact_dict(data)
        assert r1 == r2


class TestRedactEvent:
    def test_redacts_payload(self):
        event = Event(
            event_id="1",
            event_type="MODEL_CALL",
            timestamp="t1",
            payload={"api_key": "secret", "model": "claude"},
        )
        redacted = redact_event(event)
        assert redacted.payload["api_key"] == "<REDACTED>"
        assert redacted.payload["model"] == "claude"
        # Original unchanged
        assert event.payload["api_key"] == "secret"


class TestClassification:
    def test_policy_event(self):
        event = Event(event_id="1", event_type="POLICY_DECISION", timestamp="t1")
        assert classify_event(event) == "policy"

    def test_eval_event(self):
        event = Event(event_id="1", event_type="EVAL_COMPLETED", timestamp="t1")
        assert classify_event(event) == "eval"

    def test_tool_event(self):
        event = Event(event_id="1", event_type="TOOL_INVOKED", timestamp="t1")
        assert classify_event(event) == "tool"

    def test_model_event(self):
        event = Event(event_id="1", event_type="MODEL_CALL", timestamp="t1")
        assert classify_event(event) == "model"

    def test_file_event(self):
        event = Event(event_id="1", event_type="FILE_WRITE", timestamp="t1")
        assert classify_event(event) == "file"

    def test_system_event(self):
        event = Event(event_id="1", event_type="RUN_STARTED", timestamp="t1")
        assert classify_event(event) == "system"

    def test_unknown_defaults_to_system(self):
        event = Event(event_id="1", event_type="CUSTOM_THING", timestamp="t1")
        assert classify_event(event) == "system"

    def test_classify_batch(self, sample_events):
        classified = classify_events(sample_events)
        assert len(classified["system"]) >= 2  # RUN_STARTED, RUN_COMPLETED
        assert len(classified["policy"]) >= 1  # POLICY_DECISION
        assert len(classified["tool"]) >= 1  # TOOL_INVOKED
