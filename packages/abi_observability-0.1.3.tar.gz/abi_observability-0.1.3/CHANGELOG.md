# Changelog

All notable changes to this project will be documented in this file.

## [Unreleased]

## [0.1.2] - 2026-03-02
### Added
- Documentation pack standardization (v1)

### Added
- Presentation standardization: README header block, privacy statement, tier line.

## [0.1.1] - 2026-02-27

### Added

- Tagged: abi-fleet-anchor-phase2-v1 (fleet presentation baseline).
- CHANGELOG.md bootstrapped from existing tags
- docs/HYGIENE_POLICY.md — clean tree requirement and quarantine protocol
- script/changelog-update bash shim + script/_lib/changelog_update.py

### Changed

- .gitignore extended with ecosystem hygiene patterns

## [0.1.0] - 2026-02-26

### Added

- Event/span pipeline with offline exporters

[0.1.0]: https://github.com/AbilityBI/abi-observability/releases/tag/v0.1.0
[0.1.1]: https://github.com/AbilityBI/abi-observability/compare/v0.1.0...v0.1.1
