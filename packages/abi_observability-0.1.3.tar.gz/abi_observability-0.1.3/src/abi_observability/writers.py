"""NDJSON appenders for events and spans.

Writes append-only NDJSON files compatible with evidence pack format:
- events.ndjson
- spans.ndjson

Key properties:
- Deterministic ordering: events/spans sorted by stable sort keys
- Deterministic timestamps: injectable for reproducibility
- Append-only: never modify existing lines
"""
from __future__ import annotations

import json
from pathlib import Path
from typing import Any

from abi_observability.models import Event, Span


def write_events_ndjson(events: list[Event], path: Path) -> int:
    """Write events to NDJSON file.

    Events are sorted by (timestamp, event_id) for deterministic ordering.
    Returns the number of events written.
    """
    sorted_events = sorted(events, key=lambda e: (e.timestamp, e.event_id))
    path.parent.mkdir(parents=True, exist_ok=True)
    with open(path, "w", encoding="utf-8") as f:
        for event in sorted_events:
            f.write(event.to_ndjson_line() + "\n")
    return len(sorted_events)


def write_spans_ndjson(spans: list[Span], path: Path) -> int:
    """Write spans to NDJSON file.

    Spans are sorted by (start_time, span_id) for deterministic ordering.
    Returns the number of spans written.
    """
    sorted_spans = sorted(spans, key=lambda s: (s.start_time, s.span_id))
    path.parent.mkdir(parents=True, exist_ok=True)
    with open(path, "w", encoding="utf-8") as f:
        for span in sorted_spans:
            f.write(span.to_ndjson_line() + "\n")
    return len(sorted_spans)


def append_event(event: Event, path: Path) -> None:
    """Append a single event to an NDJSON file."""
    path.parent.mkdir(parents=True, exist_ok=True)
    with open(path, "a", encoding="utf-8") as f:
        f.write(event.to_ndjson_line() + "\n")


def append_span(span: Span, path: Path) -> None:
    """Append a single span to an NDJSON file."""
    path.parent.mkdir(parents=True, exist_ok=True)
    with open(path, "a", encoding="utf-8") as f:
        f.write(span.to_ndjson_line() + "\n")


def write_ndjson(records: list[dict[str, Any]], path: Path) -> int:
    """Write generic records to NDJSON file.

    Args:
        records: List of dictionaries to write
        path: Path to write to

    Returns:
        Number of records written
    """
    path.parent.mkdir(parents=True, exist_ok=True)
    with open(path, "w", encoding="utf-8") as f:
        for record in records:
            f.write(json.dumps(record, ensure_ascii=False, sort_keys=True) + "\n")
    return len(records)


def read_ndjson(path: Path) -> list[dict[str, Any]]:
    """Read an NDJSON file and return list of parsed records."""
    if not path.exists():
        return []
    records = []
    with open(path, encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if line:
                records.append(json.loads(line))
    return records
