"""Redaction and classification for observable events.

- Recursively redacts sensitive keys from event payloads
- Classifies events into categories: policy, eval, tool, model, file, system
"""
from __future__ import annotations

from typing import Any

from abi_observability.models import EVENT_TYPE_TO_CATEGORY, Event

# Keys that should always be redacted
SENSITIVE_KEY_PATTERNS = [
    "api_key",
    "secret",
    "token",
    "password",
    "credential",
    "authorization",
    "private_key",
    "access_key",
    "secret_key",
    "session_id",
    "cookie",
]

REDACTION_MARKER = "<REDACTED>"


def is_sensitive_key(key: str) -> bool:
    """Check if a key name suggests sensitive content."""
    lower_key = key.lower()
    return any(pattern in lower_key for pattern in SENSITIVE_KEY_PATTERNS)


def redact_dict(data: dict[str, Any], depth: int = 0, max_depth: int = 20) -> dict[str, Any]:
    """Recursively redact sensitive keys from a dictionary.

    Keys matching SENSITIVE_KEY_PATTERNS have their values replaced with <REDACTED>.
    Recurses into nested dicts and lists up to max_depth.
    """
    if depth > max_depth:
        return data

    result = {}
    for key in sorted(data.keys()):
        value = data[key]
        if is_sensitive_key(key):
            result[key] = REDACTION_MARKER
        elif isinstance(value, dict):
            result[key] = redact_dict(value, depth + 1, max_depth)
        elif isinstance(value, list):
            result[key] = redact_list(value, depth + 1, max_depth)
        else:
            result[key] = value
    return result


def redact_list(data: list[Any], depth: int = 0, max_depth: int = 20) -> list[Any]:
    """Recursively redact sensitive keys within list items."""
    if depth > max_depth:
        return data

    result = []
    for item in data:
        if isinstance(item, dict):
            result.append(redact_dict(item, depth + 1, max_depth))
        elif isinstance(item, list):
            result.append(redact_list(item, depth + 1, max_depth))
        else:
            result.append(item)
    return result


def redact_event(event: Event) -> Event:
    """Return a new Event with sensitive data redacted."""
    return Event(
        event_id=event.event_id,
        event_type=event.event_type,
        timestamp=event.timestamp,
        run_id=event.run_id,
        payload=redact_dict(event.payload),
        metadata=redact_dict(event.metadata),
    )


def classify_event(event: Event) -> str:
    """Classify an event into a category.

    Categories: policy, eval, tool, model, file, system
    """
    return EVENT_TYPE_TO_CATEGORY.get(event.event_type, "system")


def classify_events(events: list[Event]) -> dict[str, list[Event]]:
    """Classify a list of events by category."""
    classified: dict[str, list[Event]] = {
        "policy": [],
        "eval": [],
        "tool": [],
        "model": [],
        "file": [],
        "system": [],
    }
    for event in events:
        category = classify_event(event)
        classified[category].append(event)
    return classified
