"""Langfuse exporter for LLM observability.

Exports traces and generations to Langfuse for LLM observability and evaluation.
Supports both offline mode (JSONL for later upload) and online mode (direct HTTP).

Configuration via environment variables:
- LANGFUSE_PUBLIC_KEY: Public API key for Langfuse
- LANGFUSE_SECRET_KEY: Secret API key for Langfuse
- LANGFUSE_HOST: Langfuse host URL (default: https://cloud.langfuse.com)
- LANGFUSE_MODE: "offline" or "online" (default: "offline")
- LANGFUSE_FILE_PATH: Path for offline export (default: ./langfuse_traces.jsonl)

Mapping strategy:
- run_id → trace_id
- phase → span
- task → generation (for LLM calls)
"""
from __future__ import annotations

import json
import os
from dataclasses import dataclass
from pathlib import Path
from typing import Any

from abi_observability.models import Event, Span


@dataclass
class LangfuseExporterConfig:
    """Configuration for Langfuse exporter."""

    mode: str = "offline"  # "offline" or "online"
    public_key: str = ""
    secret_key: str = ""
    host: str = "https://cloud.langfuse.com"
    file_path: Path = Path("./langfuse_traces.jsonl")
    timeout_seconds: int = 10

    @classmethod
    def from_env(cls) -> LangfuseExporterConfig:
        """Load configuration from environment variables."""
        mode = os.getenv("LANGFUSE_MODE", "offline")
        public_key = os.getenv("LANGFUSE_PUBLIC_KEY", "")
        secret_key = os.getenv("LANGFUSE_SECRET_KEY", "")
        host = os.getenv("LANGFUSE_HOST", "https://cloud.langfuse.com")
        file_path = Path(os.getenv("LANGFUSE_FILE_PATH", "./langfuse_traces.jsonl"))
        timeout = int(os.getenv("LANGFUSE_TIMEOUT", "10"))

        return cls(
            mode=mode,
            public_key=public_key,
            secret_key=secret_key,
            host=host,
            file_path=file_path,
            timeout_seconds=timeout,
        )


class LangfuseExporter:
    """Exports traces and generations to Langfuse.

    Converts internal Event and Span objects to Langfuse trace format.
    Supports both offline (JSONL) and online (HTTP) modes.
    """

    def __init__(self, config: LangfuseExporterConfig | None = None) -> None:
        """Initialize Langfuse exporter.

        Args:
            config: Optional configuration. If None, loads from environment.
        """
        self.config = config or LangfuseExporterConfig.from_env()
        self._http_available = self._check_http_available()

    def _check_http_available(self) -> bool:
        """Check if HTTP export dependencies are available."""
        try:
            import urllib.request  # noqa: F401

            return True
        except ImportError:
            return False

    def export_spans(self, spans: list[Span]) -> dict[str, Any]:
        """Export spans as Langfuse traces.

        Args:
            spans: List of spans to export.

        Returns:
            Export result with status and metadata.
        """
        if not spans:
            return {"status": "success", "exported": 0, "message": "No spans to export"}

        traces = self._convert_spans_to_traces(spans)

        if self.config.mode == "online":
            return self._export_online(traces)
        else:
            return self._export_offline(traces)

    def export_events(self, events: list[Event]) -> dict[str, Any]:
        """Export events as Langfuse observations.

        Args:
            events: List of events to export.

        Returns:
            Export result with status and metadata.
        """
        if not events:
            return {"status": "success", "exported": 0, "message": "No events to export"}

        observations = self._convert_events_to_observations(events)

        if self.config.mode == "online":
            return self._export_online(observations)
        else:
            return self._export_offline(observations)

    def export_generation(self, generation_record: dict[str, Any]) -> dict[str, Any]:
        """Export a GenerationRecord as a Langfuse generation.

        Args:
            generation_record: Generation record from T-0205 format.

        Returns:
            Export result with status and metadata.
        """
        langfuse_gen = self._convert_generation_record(generation_record)

        if self.config.mode == "online":
            return self._export_online([langfuse_gen])
        else:
            return self._export_offline([langfuse_gen])

    def _convert_spans_to_traces(self, spans: list[Span]) -> list[dict[str, Any]]:
        """Convert internal spans to Langfuse trace format.

        Groups spans by trace_id and creates hierarchical traces.
        """
        # Group by trace_id
        traces_by_id: dict[str, list[Span]] = {}
        for span in spans:
            if span.trace_id not in traces_by_id:
                traces_by_id[span.trace_id] = []
            traces_by_id[span.trace_id].append(span)

        traces = []
        for trace_id, trace_spans in traces_by_id.items():
            # Find root span (no parent)
            root_spans = [s for s in trace_spans if not s.parent_span_id]
            root_span = root_spans[0] if root_spans else trace_spans[0]

            trace = {
                "id": trace_id,
                "name": root_span.name,
                "timestamp": root_span.start_time,
                "metadata": {
                    "source": "abi-observability",
                    **root_span.attributes,
                },
                "spans": [self._span_to_langfuse(s) for s in trace_spans],
            }
            traces.append(trace)

        return traces

    def _span_to_langfuse(self, span: Span) -> dict[str, Any]:
        """Convert a single span to Langfuse span format."""
        return {
            "id": span.span_id,
            "traceId": span.trace_id,
            "name": span.name,
            "startTime": span.start_time,
            "endTime": span.end_time,
            "level": "ERROR" if span.status == "error" else "DEFAULT",
            "metadata": span.attributes,
            "parentObservationId": span.parent_span_id or None,
        }

    def _convert_events_to_observations(self, events: list[Event]) -> list[dict[str, Any]]:
        """Convert events to Langfuse observations.

        Events are converted to generic observations with type "EVENT".
        """
        observations = []
        for event in events:
            obs = {
                "id": event.event_id,
                "traceId": event.run_id,
                "type": "EVENT",
                "name": event.event_type,
                "startTime": event.timestamp,
                "metadata": {
                    "category": event.category,
                    **event.metadata,
                },
                "input": event.payload,
            }
            observations.append(obs)

        return observations

    def _convert_generation_record(self, record: dict[str, Any]) -> dict[str, Any]:
        """Convert a GenerationRecord to Langfuse generation format.

        Expected GenerationRecord structure (from T-0205):
        {
            "generation_id": str,
            "run_id": str,
            "phase": str,
            "task": str,
            "model": str,
            "prompt": str,
            "completion": str,
            "timestamp": str,
            "metadata": dict,
        }
        """
        return {
            "id": record.get("generation_id", ""),
            "traceId": record.get("run_id", ""),
            "type": "GENERATION",
            "name": record.get("task", "generation"),
            "startTime": record.get("timestamp", ""),
            "model": record.get("model", ""),
            "modelParameters": record.get("metadata", {}).get("model_parameters", {}),
            "input": record.get("prompt", ""),
            "output": record.get("completion", ""),
            "metadata": {
                "phase": record.get("phase", ""),
                "task": record.get("task", ""),
                **record.get("metadata", {}),
            },
            "usage": record.get("metadata", {}).get("usage", {}),
        }

    def _export_offline(self, items: list[dict[str, Any]]) -> dict[str, Any]:
        """Export items to a JSONL file for later upload.

        Args:
            items: List of Langfuse-formatted items (traces/observations/generations).

        Returns:
            Export result.
        """
        try:
            self.config.file_path.parent.mkdir(parents=True, exist_ok=True)

            # Append each item as a line in JSONL
            with open(self.config.file_path, "a", encoding="utf-8") as f:
                for item in items:
                    json.dump(item, f, ensure_ascii=False, sort_keys=True)
                    f.write("\n")

            return {
                "status": "success",
                "exported": len(items),
                "mode": "offline",
                "file_path": str(self.config.file_path),
            }
        except Exception as e:
            return {
                "status": "error",
                "exported": 0,
                "error": str(e),
            }

    def _export_online(self, items: list[dict[str, Any]]) -> dict[str, Any]:
        """Export items via HTTP to Langfuse API.

        Args:
            items: List of Langfuse-formatted items.

        Returns:
            Export result.
        """
        if not self._http_available:
            return {
                "status": "error",
                "exported": 0,
                "error": "HTTP export requires urllib (should be in stdlib)",
            }

        if not self.config.public_key or not self.config.secret_key:
            return {
                "status": "error",
                "exported": 0,
                "error": "Missing LANGFUSE_PUBLIC_KEY or LANGFUSE_SECRET_KEY",
            }

        try:
            import base64
            import urllib.request

            # Langfuse uses Basic Auth with public_key:secret_key
            credentials = f"{self.config.public_key}:{self.config.secret_key}"
            auth_header = base64.b64encode(credentials.encode()).decode()

            endpoint = f"{self.config.host}/api/public/ingestion"

            # Langfuse batch ingestion format
            payload = {
                "batch": items,
                "metadata": {
                    "source": "abi-observability",
                    "version": "0.1.3",
                },
            }

            json_data = json.dumps(payload).encode("utf-8")

            req = urllib.request.Request(
                endpoint,
                data=json_data,
                headers={
                    "Content-Type": "application/json",
                    "Authorization": f"Basic {auth_header}",
                },
                method="POST",
            )

            with urllib.request.urlopen(req, timeout=self.config.timeout_seconds) as response:
                status_code = response.getcode()

            if status_code == 200 or status_code == 201 or status_code == 207:
                return {
                    "status": "success",
                    "exported": len(items),
                    "mode": "online",
                    "endpoint": endpoint,
                    "http_status": status_code,
                }
            else:
                return {
                    "status": "error",
                    "exported": 0,
                    "error": f"HTTP {status_code}",
                }

        except Exception as e:
            return {
                "status": "error",
                "exported": 0,
                "error": str(e),
            }
