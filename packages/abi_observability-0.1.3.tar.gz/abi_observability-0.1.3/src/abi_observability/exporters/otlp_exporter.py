"""OpenTelemetry Protocol (OTLP) exporter.

Exports spans in OTLP-compatible JSON format without requiring the full OTel SDK.
Supports both file export (JSONL) and HTTP export to a collector endpoint.

Configuration via environment variables:
- ABI_OTLP_ENDPOINT: HTTP endpoint for OTLP collector (e.g., http://localhost:4318/v1/traces)
- ABI_OTLP_EXPORT_TYPE: "file" or "http" (default: "file")
- ABI_OTLP_FILE_PATH: Path for file export (default: ./otlp_traces.jsonl)
"""
from __future__ import annotations

import json
import os
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Any

from abi_observability.models import Span
from abi_observability.otel_genai import GenAIAttributes


@dataclass
class OTLPExporterConfig:
    """Configuration for OTLP exporter."""

    export_type: str = "file"  # "file" or "http"
    endpoint: str = "http://localhost:4318/v1/traces"
    file_path: Path = Path("./otlp_traces.jsonl")
    timeout_seconds: int = 10

    @classmethod
    def from_env(cls) -> OTLPExporterConfig:
        """Load configuration from environment variables."""
        export_type = os.getenv("ABI_OTLP_EXPORT_TYPE", "file")
        endpoint = os.getenv("ABI_OTLP_ENDPOINT", "http://localhost:4318/v1/traces")
        file_path = Path(os.getenv("ABI_OTLP_FILE_PATH", "./otlp_traces.jsonl"))
        timeout = int(os.getenv("ABI_OTLP_TIMEOUT", "10"))

        return cls(
            export_type=export_type,
            endpoint=endpoint,
            file_path=file_path,
            timeout_seconds=timeout,
        )


class OTLPExporter:
    """Exports spans in OpenTelemetry Protocol (OTLP) format.

    Converts internal Span objects to OTLP-compatible JSON without requiring
    the full OpenTelemetry SDK. Supports both file and HTTP export modes.
    """

    def __init__(self, config: OTLPExporterConfig | None = None) -> None:
        """Initialize OTLP exporter.

        Args:
            config: Optional configuration. If None, loads from environment.
        """
        self.config = config or OTLPExporterConfig.from_env()
        self._http_available = self._check_http_available()

    def _check_http_available(self) -> bool:
        """Check if HTTP export dependencies are available."""
        try:
            import urllib.request  # noqa: F401

            return True
        except ImportError:
            return False

    def export(self, spans: list[Span]) -> dict[str, Any]:
        """Export spans in OTLP format.

        Args:
            spans: List of spans to export.

        Returns:
            Export result with status and metadata.
        """
        if not spans:
            return {"status": "success", "exported": 0, "message": "No spans to export"}

        otlp_payload = self._convert_to_otlp(spans)

        if self.config.export_type == "http":
            return self._export_http(otlp_payload)
        else:
            return self._export_file(otlp_payload)

    def _convert_to_otlp(self, spans: list[Span]) -> dict[str, Any]:
        """Convert internal spans to OTLP JSON format.

        OTLP format follows the OpenTelemetry Protocol specification:
        https://opentelemetry.io/docs/specs/otlp/
        """
        # Group spans by trace_id for OTLP resource spans structure
        traces: dict[str, list[Span]] = {}
        for span in spans:
            if span.trace_id not in traces:
                traces[span.trace_id] = []
            traces[span.trace_id].append(span)

        resource_spans = []
        for trace_id, trace_spans in traces.items():
            # Separate GenAI spans from general spans for proper instrumentation scoping
            genai_spans = []
            general_spans = []
            for span in trace_spans:
                if any(k.startswith("gen_ai.") for k in span.attributes):
                    genai_spans.append(span)
                else:
                    general_spans.append(span)

            scope_spans_list = []
            if general_spans:
                scope_spans_list.append({
                    "scope": {
                        "name": "abi-observability",
                        "version": "0.1.3",
                    },
                    "spans": [self._span_to_otlp(s) for s in general_spans],
                })
            if genai_spans:
                scope_spans_list.append({
                    "scope": {
                        "name": "abi-observability.genai",
                        "version": "0.1.3",
                    },
                    "spans": [self._span_to_otlp(s) for s in genai_spans],
                })
            if not scope_spans_list:
                # Fallback: shouldn't happen, but emit empty scope if no spans categorized
                scope_spans_list.append({
                    "scope": {
                        "name": "abi-observability",
                        "version": "0.1.3",
                    },
                    "spans": [],
                })

            resource_spans.append({
                "resource": {
                    "attributes": [
                        {"key": "service.name", "value": {"stringValue": "abi-service"}},
                        {"key": "trace.id", "value": {"stringValue": trace_id}},
                    ]
                },
                "scopeSpans": scope_spans_list,
            })

        return {
            "resourceSpans": resource_spans,
        }

    def _span_to_otlp(self, span: Span) -> dict[str, Any]:
        """Convert a single span to OTLP span format."""
        # Convert ISO timestamps to nanoseconds
        start_time_ns = self._iso_to_nanos(span.start_time)
        end_time_ns = self._iso_to_nanos(span.end_time)

        # Convert span_id and trace_id to hex (OTLP expects hex-encoded IDs)
        # OTLP spec: trace_id = 32 hex chars (16 bytes), span_id = 16 hex chars (8 bytes)
        span_id_hex = self._id_to_hex(span.span_id, length=16)
        trace_id_hex = self._id_to_hex(span.trace_id, length=32)
        parent_span_id_hex = self._id_to_hex(span.parent_span_id, length=16) if span.parent_span_id else ""

        # Convert status
        status_code = 2 if span.status == "error" else 1  # 1=OK, 2=ERROR

        # Convert attributes to OTLP format
        attributes = []
        for key, value in span.attributes.items():
            attributes.append(self._attribute_to_otlp(key, value))

        # Convert events to OTLP format
        events = []
        for event in span.events:
            event_attrs = []
            if isinstance(event, dict):
                for key, value in event.items():
                    if key not in ("name", "timestamp"):
                        event_attrs.append(self._attribute_to_otlp(key, value))
                events.append({
                    "name": event.get("name", "event"),
                    "timeUnixNano": self._iso_to_nanos(event.get("timestamp", "")),
                    "attributes": event_attrs,
                })

        otlp_span: dict[str, Any] = {
            "traceId": trace_id_hex,
            "spanId": span_id_hex,
            "name": span.name,
            "kind": 1,  # SPAN_KIND_INTERNAL
            "startTimeUnixNano": start_time_ns,
            "endTimeUnixNano": end_time_ns,
            "status": {"code": status_code},
            "attributes": attributes,
        }

        if parent_span_id_hex:
            otlp_span["parentSpanId"] = parent_span_id_hex

        if events:
            otlp_span["events"] = events

        return otlp_span

    def _attribute_to_otlp(self, key: str, value: Any) -> dict[str, Any]:
        """Convert an attribute to OTLP attribute format."""
        attr: dict[str, Any] = {"key": key}

        if isinstance(value, bool):
            attr["value"] = {"boolValue": value}
        elif isinstance(value, int):
            attr["value"] = {"intValue": value}
        elif isinstance(value, float):
            attr["value"] = {"doubleValue": value}
        elif isinstance(value, str):
            attr["value"] = {"stringValue": value}
        else:
            # Convert to JSON string for complex types
            attr["value"] = {"stringValue": json.dumps(value)}

        return attr

    def _iso_to_nanos(self, iso_timestamp: str) -> int:
        """Convert ISO 8601 timestamp to Unix nanoseconds.

        Args:
            iso_timestamp: ISO 8601 formatted timestamp.

        Returns:
            Unix timestamp in nanoseconds.
        """
        if not iso_timestamp:
            return 0

        try:
            from datetime import datetime

            # Handle both Z and +00:00 timezone formats
            dt = datetime.fromisoformat(iso_timestamp.replace("Z", "+00:00"))
            return int(dt.timestamp() * 1_000_000_000)
        except Exception:
            # Fallback: use current time
            return int(time.time() * 1_000_000_000)

    def _id_to_hex(self, id_str: str, length: int = 16) -> str:
        """Convert ID string to hex format for OTLP.

        OTLP spec requires trace_id as 32 hex chars (16 bytes) and
        span_id as 16 hex chars (8 bytes).

        Args:
            id_str: The source ID string.
            length: Target hex string length (32 for trace_id, 16 for span_id).
        """
        if not id_str:
            return ""

        # Remove any non-alphanumeric characters
        clean_id = "".join(c for c in id_str if c.isalnum())

        # Convert to bytes and then to hex
        hex_id = clean_id.encode("utf-8").hex()

        # Pad or truncate to the specified length
        if len(hex_id) < length:
            hex_id = hex_id.ljust(length, "0")
        elif len(hex_id) > length:
            hex_id = hex_id[:length]

        return hex_id

    def _export_file(self, payload: dict[str, Any]) -> dict[str, Any]:
        """Export OTLP payload to a JSONL file.

        Args:
            payload: OTLP-formatted payload.

        Returns:
            Export result.
        """
        try:
            self.config.file_path.parent.mkdir(parents=True, exist_ok=True)

            # Append to JSONL file
            with open(self.config.file_path, "a", encoding="utf-8") as f:
                json.dump(payload, f, ensure_ascii=False, sort_keys=True)
                f.write("\n")

            span_count = sum(
                len(ss.get("spans", []))
                for rs in payload.get("resourceSpans", [])
                for ss in rs.get("scopeSpans", [])
            )

            return {
                "status": "success",
                "exported": span_count,
                "file_path": str(self.config.file_path),
            }
        except Exception as e:
            return {
                "status": "error",
                "exported": 0,
                "error": str(e),
            }

    def _export_http(self, payload: dict[str, Any]) -> dict[str, Any]:
        """Export OTLP payload via HTTP to a collector endpoint.

        Args:
            payload: OTLP-formatted payload.

        Returns:
            Export result.
        """
        if not self._http_available:
            return {
                "status": "error",
                "exported": 0,
                "error": "HTTP export requires urllib (should be in stdlib)",
            }

        try:
            import urllib.request

            json_data = json.dumps(payload).encode("utf-8")

            req = urllib.request.Request(
                self.config.endpoint,
                data=json_data,
                headers={
                    "Content-Type": "application/json",
                },
                method="POST",
            )

            with urllib.request.urlopen(req, timeout=self.config.timeout_seconds) as response:
                status_code = response.getcode()

            span_count = sum(
                len(ss.get("spans", []))
                for rs in payload.get("resourceSpans", [])
                for ss in rs.get("scopeSpans", [])
            )

            if status_code == 200 or status_code == 202:
                return {
                    "status": "success",
                    "exported": span_count,
                    "endpoint": self.config.endpoint,
                    "http_status": status_code,
                }
            else:
                return {
                    "status": "error",
                    "exported": 0,
                    "error": f"HTTP {status_code}",
                }

        except Exception as e:
            return {
                "status": "error",
                "exported": 0,
                "error": str(e),
            }
