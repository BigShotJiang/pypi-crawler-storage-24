"""Exporters for OpenTelemetry and Langfuse integration.

This package provides OTLP and Langfuse exporters alongside the offline
exporters (timeline/summary) from the sibling exporters.py module.

The offline functions are re-exported here for backward compatibility
so that ``from abi_observability.exporters import build_timeline_md``
continues to work after the package was introduced.
"""
from __future__ import annotations

import importlib.util
from pathlib import Path
from typing import Any

# ---------------------------------------------------------------------------
# Re-export offline exporter functions from the sibling ``exporters.py`` file.
#
# Because this ``exporters/`` directory shadows the ``exporters.py`` module,
# a normal ``import`` cannot reach it.  We use importlib to load it by path
# without mutating sys.path (the previous approach was fragile).
# ---------------------------------------------------------------------------
_LEGACY_MODULE_PATH = Path(__file__).resolve().parent.parent / "exporters.py"

def _load_legacy_module() -> Any:
    """Load the sibling exporters.py by file path."""
    spec = importlib.util.spec_from_file_location(
        "abi_observability._exporters_offline", _LEGACY_MODULE_PATH
    )
    if spec is None or spec.loader is None:
        raise ImportError(f"Cannot load offline exporters from {_LEGACY_MODULE_PATH}")
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod

_legacy = _load_legacy_module()

build_timeline_md = _legacy.build_timeline_md
build_json_summary = _legacy.build_json_summary
export_timeline = _legacy.export_timeline
export_summary = _legacy.export_summary
_load_events = _legacy._load_events
_load_spans = _legacy._load_spans

# ---------------------------------------------------------------------------
# OTLP and Langfuse exporters (graceful fallback if deps are missing)
# ---------------------------------------------------------------------------
try:
    from abi_observability.exporters.otlp_exporter import OTLPExporter
except ImportError:
    OTLPExporter = None  # type: ignore

try:
    from abi_observability.exporters.langfuse_exporter import LangfuseExporter
except ImportError:
    LangfuseExporter = None  # type: ignore

__all__ = [
    # Offline exporters (from sibling exporters.py)
    "build_timeline_md",
    "build_json_summary",
    "export_timeline",
    "export_summary",
    "_load_events",
    "_load_spans",
    # Backend exporters
    "OTLPExporter",
    "LangfuseExporter",
]
