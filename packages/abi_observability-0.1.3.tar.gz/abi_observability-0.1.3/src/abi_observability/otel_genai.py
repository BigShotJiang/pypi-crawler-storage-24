"""OpenTelemetry GenAI Semantic Conventions alignment.

Maps ABI observability attributes to OTel GenAI SIG semantic conventions.
See: https://opentelemetry.io/docs/specs/semconv/gen-ai/

This module provides constants and helpers for emitting telemetry that
conforms to the OTel GenAI semantic conventions, making ABI telemetry
interoperable with any OTel-compatible backend.

Usage:
    from abi_observability.otel_genai import GenAIAttributes, to_genai_attributes

    span.attributes.update(to_genai_attributes(
        system="anthropic",
        model="claude-sonnet-4-20250514",
        input_tokens=1500,
        output_tokens=300,
    ))
"""

from __future__ import annotations

from typing import Any


class GenAIAttributes:
    """OTel GenAI semantic convention attribute keys.

    Based on: https://opentelemetry.io/docs/specs/semconv/gen-ai/gen-ai-spans/
    """

    # Required
    SYSTEM = "gen_ai.system"
    REQUEST_MODEL = "gen_ai.request.model"
    OPERATION_NAME = "gen_ai.operation.name"

    # Request attributes
    REQUEST_MAX_TOKENS = "gen_ai.request.max_tokens"
    REQUEST_TEMPERATURE = "gen_ai.request.temperature"
    REQUEST_TOP_P = "gen_ai.request.top_p"
    REQUEST_STOP_SEQUENCES = "gen_ai.request.stop_sequences"

    # Response attributes
    RESPONSE_MODEL = "gen_ai.response.model"
    RESPONSE_ID = "gen_ai.response.id"
    RESPONSE_FINISH_REASONS = "gen_ai.response.finish_reasons"

    # Usage attributes
    USAGE_INPUT_TOKENS = "gen_ai.usage.input_tokens"
    USAGE_OUTPUT_TOKENS = "gen_ai.usage.output_tokens"

    # ABI extensions (namespaced to avoid collision)
    ABI_RUN_ID = "abi.run_id"
    ABI_PHASE = "abi.phase"
    ABI_AGENT_ROLE = "abi.agent.role"
    ABI_BUDGET_REMAINING = "abi.budget.remaining_tokens"


# ABI event type to OTel GenAI operation mapping
ABI_EVENT_TO_GENAI_OPERATION: dict[str, str] = {
    "MODEL_CALL": "chat",
    "MODEL_RESPONSE": "chat",
    "TOOL_INVOKED": "tool",
    "TOOL_COMPLETED": "tool",
}


def to_genai_attributes(
    *,
    system: str,
    model: str,
    operation: str = "chat",
    input_tokens: int | None = None,
    output_tokens: int | None = None,
    temperature: float | None = None,
    max_tokens: int | None = None,
    response_id: str | None = None,
    finish_reason: str | None = None,
) -> dict[str, Any]:
    """Build an OTel GenAI-compliant attribute dict.

    Args:
        system: The AI system (e.g., "anthropic", "openai", "local").
        model: The model identifier.
        operation: The operation name (default: "chat").
        input_tokens: Number of input tokens used.
        output_tokens: Number of output tokens generated.
        temperature: Sampling temperature.
        max_tokens: Maximum tokens requested.
        response_id: Provider response ID.
        finish_reason: Completion reason.

    Returns:
        Dict of OTel GenAI semantic convention attributes.
    """
    attrs: dict[str, Any] = {
        GenAIAttributes.SYSTEM: system,
        GenAIAttributes.REQUEST_MODEL: model,
        GenAIAttributes.OPERATION_NAME: operation,
    }

    if input_tokens is not None:
        attrs[GenAIAttributes.USAGE_INPUT_TOKENS] = input_tokens
    if output_tokens is not None:
        attrs[GenAIAttributes.USAGE_OUTPUT_TOKENS] = output_tokens
    if temperature is not None:
        attrs[GenAIAttributes.REQUEST_TEMPERATURE] = temperature
    if max_tokens is not None:
        attrs[GenAIAttributes.REQUEST_MAX_TOKENS] = max_tokens
    if response_id is not None:
        attrs[GenAIAttributes.RESPONSE_ID] = response_id
    if finish_reason is not None:
        attrs[GenAIAttributes.RESPONSE_FINISH_REASONS] = [finish_reason]

    return attrs
