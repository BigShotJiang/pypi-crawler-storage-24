"""Offline exporters — produce timeline.md and JSON summary from NDJSON.

No network exporters — all output is local files.
"""
from __future__ import annotations

import json
from pathlib import Path
from typing import Any

from abi_observability.models import Event, Span
from abi_observability.redaction import classify_event
from abi_observability.writers import read_ndjson


def build_timeline_md(
    events: list[Event],
    spans: list[Span] | None = None,
) -> str:
    """Build a deterministic timeline.md from events and optional spans.

    Events are sorted by timestamp for chronological ordering.
    """
    lines = [
        "# Run Timeline",
        "",
        "## Events",
        "",
        "| Time | Type | Category | Summary |",
        "|------|------|----------|---------|",
    ]

    sorted_events = sorted(events, key=lambda e: (e.timestamp, e.event_id))
    for event in sorted_events:
        category = classify_event(event)
        summary = _event_summary(event)
        lines.append(f"| {event.timestamp} | {event.event_type} | {category} | {summary} |")

    if spans:
        lines.extend([
            "",
            "## Spans",
            "",
            "| Start | End | Name | Status | Duration |",
            "|-------|-----|------|--------|----------|",
        ])
        sorted_spans = sorted(spans, key=lambda s: (s.start_time, s.span_id))
        for span in sorted_spans:
            duration = _calc_duration(span.start_time, span.end_time)
            lines.append(
                f"| {span.start_time} | {span.end_time} "
                f"| {span.name} | {span.status} | {duration} |"
            )

    lines.append("")  # Trailing newline
    return "\n".join(lines)


def build_json_summary(
    events: list[Event],
    spans: list[Span] | None = None,
) -> dict[str, Any]:
    """Build a lightweight JSON summary report.

    Counts by type, category, and duration summary.
    """
    # Count events by type
    type_counts: dict[str, int] = {}
    category_counts: dict[str, int] = {}

    for event in events:
        type_counts[event.event_type] = type_counts.get(event.event_type, 0) + 1
        cat = classify_event(event)
        category_counts[cat] = category_counts.get(cat, 0) + 1

    summary: dict[str, Any] = {
        "schema_version": "tier2-summary/1.0",
        "total_events": len(events),
        "events_by_type": dict(sorted(type_counts.items())),
        "events_by_category": dict(sorted(category_counts.items())),
    }

    if spans:
        span_statuses: dict[str, int] = {}
        for span in spans:
            span_statuses[span.status] = span_statuses.get(span.status, 0) + 1
        summary["total_spans"] = len(spans)
        summary["spans_by_status"] = dict(sorted(span_statuses.items()))

    return summary


def export_timeline(in_dir: Path, out_path: Path) -> None:
    """Export NDJSON files from a directory to a timeline.md file."""
    events = _load_events(in_dir)
    spans = _load_spans(in_dir)
    timeline = build_timeline_md(events, spans)
    out_path.parent.mkdir(parents=True, exist_ok=True)
    out_path.write_text(timeline, encoding="utf-8")


def export_summary(in_dir: Path, out_path: Path) -> None:
    """Export NDJSON files to a JSON summary report."""
    events = _load_events(in_dir)
    spans = _load_spans(in_dir)
    summary = build_json_summary(events, spans)
    out_path.parent.mkdir(parents=True, exist_ok=True)
    with open(out_path, "w", encoding="utf-8") as f:
        json.dump(summary, f, indent=2, ensure_ascii=False, sort_keys=True)
        f.write("\n")


def _load_events(in_dir: Path) -> list[Event]:
    """Load events from events.ndjson in a directory."""
    events_path = in_dir / "events.ndjson"
    records = read_ndjson(events_path)
    return [
        Event(
            event_id=r.get("event_id", ""),
            event_type=r.get("event_type", ""),
            timestamp=r.get("timestamp", ""),
            run_id=r.get("run_id", ""),
            payload=r.get("payload", {}),
            metadata=r.get("metadata", {}),
        )
        for r in records
    ]


def _load_spans(in_dir: Path) -> list[Span]:
    """Load spans from spans.ndjson in a directory."""
    spans_path = in_dir / "spans.ndjson"
    records = read_ndjson(spans_path)
    return [
        Span(
            span_id=r.get("span_id", ""),
            trace_id=r.get("trace_id", ""),
            name=r.get("name", ""),
            start_time=r.get("start_time", ""),
            end_time=r.get("end_time", ""),
            status=r.get("status", "ok"),
            parent_span_id=r.get("parent_span_id", ""),
            attributes=r.get("attributes", {}),
            events=r.get("events", []),
        )
        for r in records
    ]


def _event_summary(event: Event) -> str:
    """Generate a brief summary of an event for the timeline."""
    payload = event.payload
    if "message" in payload:
        return str(payload["message"])[:80]
    if "tool" in payload:
        return f"Tool: {payload['tool']}"
    if "model" in payload:
        return f"Model: {payload['model']}"
    if "status" in payload:
        return f"Status: {payload['status']}"
    return event.event_type


def _calc_duration(start: str, end: str) -> str:
    """Calculate duration between ISO timestamps (best effort)."""
    try:
        from datetime import datetime

        s = datetime.fromisoformat(start.replace("Z", "+00:00"))
        e = datetime.fromisoformat(end.replace("Z", "+00:00"))
        delta = e - s
        total_ms = int(delta.total_seconds() * 1000)
        if total_ms < 1000:
            return f"{total_ms}ms"
        return f"{total_ms / 1000:.1f}s"
    except Exception:
        return "?"
