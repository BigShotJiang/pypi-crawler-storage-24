import sys

from abi_observability.cli import main

sys.exit(main())
