"""ABI Observability — event/span pipeline with offline exporters.

New in 0.1.3:
- Status dashboard backend with lightweight HTTP API
- Interactive web UI for visualizing pipeline runs
- Real-time pipeline monitoring with auto-refresh
- Per-task metrics (LLM provider, tokens, cost, duration)

Previous (0.1.2):
- OTLP exporter for OpenTelemetry integration
- Langfuse exporter for LLM observability
- In-process event collector with buffering and multi-exporter support
"""
__version__ = "0.1.3"

# Core models, classification constants, and writers
from abi_observability.models import EVENT_CATEGORIES, EVENT_TYPE_TO_CATEGORY, Event, Span
from abi_observability.writers import (
    append_event,
    append_span,
    read_ndjson,
    write_events_ndjson,
    write_spans_ndjson,
)

# Collector and exporters
from abi_observability.collector import Collector, CollectorConfig, get_collector, reset_collector

# OTel GenAI semantic conventions alignment
from abi_observability.otel_genai import (
    ABI_EVENT_TO_GENAI_OPERATION,
    GenAIAttributes,
    to_genai_attributes,
)

# Optional: OTLP and Langfuse exporters (graceful fallback if not available)
try:
    from abi_observability.exporters import LangfuseExporter, OTLPExporter
except ImportError:
    OTLPExporter = None  # type: ignore
    LangfuseExporter = None  # type: ignore

__all__ = [
    # Version
    "__version__",
    # Core models and classification
    "Event",
    "Span",
    "EVENT_CATEGORIES",
    "EVENT_TYPE_TO_CATEGORY",
    # Writers
    "write_events_ndjson",
    "write_spans_ndjson",
    "append_event",
    "append_span",
    "read_ndjson",
    # Collector
    "Collector",
    "CollectorConfig",
    "get_collector",
    "reset_collector",
    # OTel GenAI alignment
    "GenAIAttributes",
    "to_genai_attributes",
    "ABI_EVENT_TO_GENAI_OPERATION",
    # Exporters
    "OTLPExporter",
    "LangfuseExporter",
    # Dashboard (CLI usage: python -m abi_observability.dashboard)
]
