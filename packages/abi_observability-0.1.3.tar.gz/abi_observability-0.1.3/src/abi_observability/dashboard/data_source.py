"""Data source layer for reading run evidence packs."""
from __future__ import annotations

import json
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path
from typing import Any

from abi_observability.models import Event, Span
from abi_observability.writers import read_ndjson


@dataclass
class RunInfo:
    """High-level information about a pipeline run."""

    run_id: str
    status: str
    total_events: int
    total_spans: int
    total_tokens: int
    total_cost: float
    duration_ms: int
    started_at: str
    completed_at: str
    phases: list[dict[str, Any]]


@dataclass
class TaskInfo:
    """Detailed task-level information."""

    task_id: str
    phase: str
    llm_provider: str
    status: str
    tokens: int
    cost: float
    duration_ms: int
    started_at: str
    completed_at: str


@dataclass
class DogfoodTask:
    """Task result from dogfood.py format."""

    task_id: str
    title: str
    status: str
    attempts: int
    started_at: str | None
    completed_at: str | None
    duration_ms: int


class RunDataSource:
    """Read run evidence packs from the runs/ directory."""

    def __init__(self, runs_dir: Path | None = None):
        """Initialize the data source.

        Args:
            runs_dir: Directory containing run evidence packs. Defaults to ./runs
        """
        if runs_dir is None:
            runs_dir = Path.cwd() / "runs"
        self.runs_dir = runs_dir

    def list_runs(self, limit: int = 50) -> list[dict[str, Any]]:
        """List recent pipeline runs.

        Returns:
            List of run summaries, most recent first.
        """
        runs = []

        if not self.runs_dir.exists():
            return []

        # Look for run directories (evidence packs or dogfood format)
        for run_dir in sorted(self.runs_dir.iterdir(), reverse=True):
            if not run_dir.is_dir():
                continue

            # Check for dogfood format first (run_results.json)
            dogfood_results = run_dir / "run_results.json"
            if dogfood_results.exists():
                run_summary = self._load_dogfood_run_summary(run_dir)
                if run_summary:
                    runs.append(run_summary)
                if len(runs) >= limit:
                    break
                continue

            # Check for evidence pack format (manifest.json or summary.json)
            manifest_path = run_dir / "manifest.json"
            summary_path = run_dir / "summary.json"

            if not manifest_path.exists() and not summary_path.exists():
                continue

            run_summary = self._load_run_summary(run_dir)
            if run_summary:
                runs.append(run_summary)

            if len(runs) >= limit:
                break

        return runs

    def get_run(self, run_id: str) -> dict[str, Any] | None:
        """Get detailed information about a specific run.

        Args:
            run_id: The run identifier

        Returns:
            Detailed run information or None if not found
        """
        run_dir = self._find_run_dir(run_id)
        if not run_dir:
            return None

        # Check if this is a dogfood format run
        dogfood_results = run_dir / "run_results.json"
        if dogfood_results.exists():
            return self._load_dogfood_run(run_dir)

        # Load all components (evidence pack format)
        events = self._load_events(run_dir)
        spans = self._load_spans(run_dir)
        summary = self._load_summary(run_dir)
        manifest = self._load_manifest(run_dir)

        # Calculate metrics
        phases = self._extract_phases(events)
        total_tokens, total_cost = self._calculate_tokens_and_cost(events)
        duration_ms = self._calculate_duration(events)
        started_at, completed_at = self._get_time_bounds(events)

        return {
            "run_id": run_id,
            "status": self._determine_status(events),
            "total_events": len(events),
            "total_spans": len(spans),
            "total_tokens": total_tokens,
            "total_cost": total_cost,
            "duration_ms": duration_ms,
            "started_at": started_at,
            "completed_at": completed_at,
            "phases": phases,
            "summary": summary,
            "manifest": manifest,
            "format": "evidence_pack",
        }

    def get_run_tasks(self, run_id: str) -> list[dict[str, Any]]:
        """Get per-task details for a run.

        Args:
            run_id: The run identifier

        Returns:
            List of task details
        """
        run_dir = self._find_run_dir(run_id)
        if not run_dir:
            return []

        # Check if this is a dogfood format run
        dogfood_results = run_dir / "run_results.json"
        if dogfood_results.exists():
            return self._load_dogfood_tasks(run_dir)

        events = self._load_events(run_dir)
        tasks = self._extract_tasks(events)
        return tasks

    def _find_run_dir(self, run_id: str) -> Path | None:
        """Find the directory for a given run_id."""
        if not self.runs_dir.exists():
            return None

        # Try direct match first (run_id as directory name)
        direct_match = self.runs_dir / run_id
        if direct_match.exists() and direct_match.is_dir():
            return direct_match

        # Try evidence_pack_{run_id} format
        evidence_pack_match = self.runs_dir / f"evidence_pack_{run_id}"
        if evidence_pack_match.exists():
            return evidence_pack_match

        # Search all directories
        for run_dir in self.runs_dir.iterdir():
            if not run_dir.is_dir():
                continue

            # Check for dogfood format (directory name matches run_id)
            if run_dir.name == run_id:
                return run_dir

            manifest = self._load_manifest(run_dir)
            if manifest and manifest.get("run_id") == run_id:
                return run_dir

            # Check events for run_id
            events = self._load_events(run_dir)
            if events and events[0].run_id == run_id:
                return run_dir

        return None

    def _load_run_summary(self, run_dir: Path) -> dict[str, Any] | None:
        """Load a lightweight run summary."""
        try:
            manifest = self._load_manifest(run_dir)
            summary = self._load_summary(run_dir)
            events = self._load_events(run_dir)

            if not events:
                return None

            run_id = events[0].run_id if events else run_dir.name
            started_at, completed_at = self._get_time_bounds(events)
            total_tokens, total_cost = self._calculate_tokens_and_cost(events)

            return {
                "run_id": run_id,
                "status": self._determine_status(events),
                "total_events": len(events),
                "total_tokens": total_tokens,
                "total_cost": total_cost,
                "started_at": started_at,
                "completed_at": completed_at,
                "dir": str(run_dir),
            }
        except Exception:
            return None

    def _load_events(self, run_dir: Path) -> list[Event]:
        """Load events from a run directory."""
        events_path = run_dir / "events.ndjson"
        if not events_path.exists():
            return []

        try:
            records = read_ndjson(events_path)
            return [
                Event(
                    event_id=r.get("event_id", ""),
                    event_type=r.get("event_type", ""),
                    timestamp=r.get("timestamp", ""),
                    run_id=r.get("run_id", ""),
                    payload=r.get("payload", {}),
                    metadata=r.get("metadata", {}),
                )
                for r in records
            ]
        except Exception:
            return []

    def _load_spans(self, run_dir: Path) -> list[Span]:
        """Load spans from a run directory."""
        spans_path = run_dir / "spans.ndjson"
        if not spans_path.exists():
            return []

        try:
            records = read_ndjson(spans_path)
            return [
                Span(
                    span_id=r.get("span_id", ""),
                    trace_id=r.get("trace_id", ""),
                    name=r.get("name", ""),
                    start_time=r.get("start_time", ""),
                    end_time=r.get("end_time", ""),
                    status=r.get("status", "ok"),
                    parent_span_id=r.get("parent_span_id", ""),
                    attributes=r.get("attributes", {}),
                    events=r.get("events", []),
                )
                for r in records
            ]
        except Exception:
            return []

    def _load_summary(self, run_dir: Path) -> dict[str, Any] | None:
        """Load summary.json if it exists."""
        summary_path = run_dir / "summary.json"
        if not summary_path.exists():
            return None

        try:
            with open(summary_path, encoding="utf-8") as f:
                return json.load(f)
        except Exception:
            return None

    def _load_manifest(self, run_dir: Path) -> dict[str, Any] | None:
        """Load manifest.json if it exists."""
        manifest_path = run_dir / "manifest.json"
        if not manifest_path.exists():
            return None

        try:
            with open(manifest_path, encoding="utf-8") as f:
                return json.load(f)
        except Exception:
            return None

    def _extract_phases(self, events: list[Event]) -> list[dict[str, Any]]:
        """Extract phase information from events."""
        phases = []
        phase_starts: dict[str, Event] = {}

        for event in events:
            if event.event_type == "PHASE_STARTED":
                phase_name = event.payload.get("phase", "unknown")
                phase_starts[phase_name] = event

            elif event.event_type == "PHASE_COMPLETED":
                phase_name = event.payload.get("phase", "unknown")
                start_event = phase_starts.get(phase_name)

                phases.append({
                    "name": phase_name,
                    "status": "completed",
                    "started_at": start_event.timestamp if start_event else event.timestamp,
                    "completed_at": event.timestamp,
                    "duration_ms": self._calc_duration_ms(
                        start_event.timestamp if start_event else event.timestamp,
                        event.timestamp,
                    ),
                })

        return phases

    def _extract_tasks(self, events: list[Event]) -> list[dict[str, Any]]:
        """Extract task-level details from events."""
        tasks = []
        task_starts: dict[str, Event] = {}

        for event in events:
            if event.event_type == "TASK_STARTED":
                task_id = event.payload.get("task_id", event.event_id)
                task_starts[task_id] = event

            elif event.event_type in ("TASK_COMPLETED", "TASK_FAILED"):
                task_id = event.payload.get("task_id", event.event_id)
                start_event = task_starts.get(task_id)

                tokens = event.payload.get("tokens", 0)
                cost = event.payload.get("cost", 0.0)

                tasks.append({
                    "task_id": task_id,
                    "phase": event.payload.get("phase", "unknown"),
                    "llm_provider": event.payload.get("llm_provider", "unknown"),
                    "status": "completed" if event.event_type == "TASK_COMPLETED" else "failed",
                    "tokens": tokens,
                    "cost": cost,
                    "duration_ms": self._calc_duration_ms(
                        start_event.timestamp if start_event else event.timestamp,
                        event.timestamp,
                    ),
                    "started_at": start_event.timestamp if start_event else event.timestamp,
                    "completed_at": event.timestamp,
                })

        return tasks

    def _calculate_tokens_and_cost(self, events: list[Event]) -> tuple[int, float]:
        """Calculate total tokens and cost from events."""
        total_tokens = 0
        total_cost = 0.0

        for event in events:
            if event.event_type in ("MODEL_CALL", "MODEL_RESPONSE", "GENAI_TELEMETRY"):
                total_tokens += event.payload.get("token_count", 0)
                total_tokens += event.payload.get("output_tokens", 0)
                total_cost += event.payload.get("cost", 0.0)

        return total_tokens, total_cost

    def _calculate_duration(self, events: list[Event]) -> int:
        """Calculate total run duration in milliseconds."""
        if not events:
            return 0

        started_at, completed_at = self._get_time_bounds(events)
        return self._calc_duration_ms(started_at, completed_at)

    def _get_time_bounds(self, events: list[Event]) -> tuple[str, str]:
        """Get earliest and latest timestamps from events."""
        if not events:
            return "", ""

        timestamps = [e.timestamp for e in events if e.timestamp]
        if not timestamps:
            return "", ""

        return min(timestamps), max(timestamps)

    def _calc_duration_ms(self, start: str, end: str) -> int:
        """Calculate duration in milliseconds between ISO timestamps."""
        try:
            from datetime import datetime

            s = datetime.fromisoformat(start.replace("Z", "+00:00"))
            e = datetime.fromisoformat(end.replace("Z", "+00:00"))
            delta = e - s
            return int(delta.total_seconds() * 1000)
        except Exception:
            return 0

    def _determine_status(self, events: list[Event]) -> str:
        """Determine run status from events."""
        for event in reversed(events):
            if event.event_type == "RUN_COMPLETED":
                return event.payload.get("status", "success")
            elif event.event_type == "TASK_FAILED":
                return "failed"
            elif event.event_type == "CIRCUIT_BREAKER_TRIPPED":
                return "failed"

        # Check if run is still in progress
        has_started = any(e.event_type == "RUN_STARTED" for e in events)
        has_completed = any(e.event_type == "RUN_COMPLETED" for e in events)

        if has_started and not has_completed:
            return "running"

        return "unknown"

    # Dogfood format support methods

    def _load_dogfood_run_summary(self, run_dir: Path) -> dict[str, Any] | None:
        """Load a lightweight run summary from dogfood.py format."""
        try:
            results_path = run_dir / "run_results.json"
            if not results_path.exists():
                return None

            with open(results_path, encoding="utf-8") as f:
                tasks = json.load(f)

            if not isinstance(tasks, list) or len(tasks) == 0:
                return None

            # Determine overall status
            status = self._determine_dogfood_status(tasks)

            # Extract run_id from directory name
            run_id = run_dir.name

            # Get time bounds and calculate duration
            started_at, completed_at = self._get_dogfood_time_bounds(tasks)
            duration_ms = self._calc_duration_ms(started_at, completed_at) if started_at and completed_at else 0

            # Load token/cost data if available
            total_tokens, total_cost = self._load_generation_records(run_dir)

            return {
                "run_id": run_id,
                "status": status,
                "total_events": len(tasks),  # Use task count as event count
                "total_tokens": total_tokens,
                "total_cost": total_cost,
                "started_at": started_at or "",
                "completed_at": completed_at or "",
                "dir": str(run_dir),
                "format": "dogfood",
            }
        except Exception:
            return None

    def _load_dogfood_run(self, run_dir: Path) -> dict[str, Any] | None:
        """Load detailed run information from dogfood.py format."""
        try:
            results_path = run_dir / "run_results.json"
            if not results_path.exists():
                return None

            with open(results_path, encoding="utf-8") as f:
                tasks = json.load(f)

            if not isinstance(tasks, list):
                return None

            # Extract run_id from directory name
            run_id = run_dir.name

            # Determine overall status
            status = self._determine_dogfood_status(tasks)

            # Get time bounds and calculate duration
            started_at, completed_at = self._get_dogfood_time_bounds(tasks)
            duration_ms = self._calc_duration_ms(started_at, completed_at) if started_at and completed_at else 0

            # Load token/cost data if available
            total_tokens, total_cost = self._load_generation_records(run_dir)

            return {
                "run_id": run_id,
                "status": status,
                "total_events": len(tasks),
                "total_spans": 0,  # Not applicable for dogfood format
                "total_tokens": total_tokens,
                "total_cost": total_cost,
                "duration_ms": duration_ms,
                "started_at": started_at or "",
                "completed_at": completed_at or "",
                "phases": [],  # Dogfood format doesn't have phases
                "summary": None,
                "manifest": None,
                "format": "dogfood",
            }
        except Exception:
            return None

    def _load_dogfood_tasks(self, run_dir: Path) -> list[dict[str, Any]]:
        """Load task details from dogfood.py format."""
        try:
            results_path = run_dir / "run_results.json"
            if not results_path.exists():
                return []

            with open(results_path, encoding="utf-8") as f:
                tasks = json.load(f)

            if not isinstance(tasks, list):
                return []

            # Convert dogfood tasks to standard format
            result = []
            for task in tasks:
                task_id = task.get("task_id", "")
                title = task.get("title", "")
                status = task.get("status", "UNKNOWN")
                attempts = task.get("attempts", 0)
                started_at = task.get("started_at", "")
                completed_at = task.get("completed_at", "")

                duration_ms = 0
                if started_at and completed_at:
                    duration_ms = self._calc_duration_ms(started_at, completed_at)

                result.append({
                    "task_id": task_id,
                    "title": title,
                    "status": status,
                    "attempts": attempts,
                    "started_at": started_at,
                    "completed_at": completed_at,
                    "duration_ms": duration_ms,
                    "phase": "",  # Not applicable
                    "llm_provider": "",  # Not in dogfood format
                    "tokens": 0,  # Will be enriched from generation_records if available
                    "cost": 0.0,
                })

            return result
        except Exception:
            return []

    def _determine_dogfood_status(self, tasks: list[dict[str, Any]]) -> str:
        """Determine overall run status from dogfood tasks."""
        if not tasks:
            return "unknown"

        # Check for any failures
        for task in tasks:
            status = task.get("status", "").upper()
            if status == "FAIL":
                return "failed"

        # Check if all tasks are complete
        all_complete = all(
            task.get("status", "").upper() in ("PASS", "PASS_UNVERIFIED", "SKIP", "FAIL")
            for task in tasks
        )

        if all_complete:
            return "success"

        return "running"

    def _get_dogfood_time_bounds(self, tasks: list[dict[str, Any]]) -> tuple[str, str]:
        """Get earliest and latest timestamps from dogfood tasks."""
        if not tasks:
            return "", ""

        started_times = [t.get("started_at") for t in tasks if t.get("started_at")]
        completed_times = [t.get("completed_at") for t in tasks if t.get("completed_at")]

        started_at = min(started_times) if started_times else ""
        completed_at = max(completed_times) if completed_times else ""

        return started_at, completed_at

    def _load_generation_records(self, run_dir: Path) -> tuple[int, float]:
        """Load token and cost data from generation_records.jsonl if available."""
        gen_records_path = run_dir / "generation_records.jsonl"
        if not gen_records_path.exists():
            return 0, 0.0

        try:
            records = read_ndjson(gen_records_path)
            total_tokens = 0
            total_cost = 0.0

            for record in records:
                # Sum up input and output tokens
                total_tokens += record.get("input_tokens", 0)
                total_tokens += record.get("output_tokens", 0)
                total_cost += record.get("cost_usd", 0.0)

            return total_tokens, total_cost
        except Exception:
            return 0, 0.0
