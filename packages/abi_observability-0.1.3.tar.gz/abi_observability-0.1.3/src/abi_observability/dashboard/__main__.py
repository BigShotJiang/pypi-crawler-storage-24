"""CLI entry point for the dashboard server.

Usage:
    python -m abi_observability.dashboard --port 8080
    python -m abi_observability.dashboard --runs-dir ./my-runs
"""
from __future__ import annotations

import argparse
import sys
from pathlib import Path

from abi_observability.dashboard.dashboard_api import DashboardServer


def main() -> int:
    """Run the dashboard server."""
    parser = argparse.ArgumentParser(
        description="ABI Observability Dashboard Server",
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    parser.add_argument(
        "--port",
        type=int,
        default=8080,
        help="Port to listen on (default: 8080)",
    )
    parser.add_argument(
        "--runs-dir",
        type=Path,
        default=None,
        help="Directory containing run evidence packs (default: ./runs)",
    )

    args = parser.parse_args()

    # Create and start the server
    server = DashboardServer(port=args.port, runs_dir=args.runs_dir)
    server.start()

    return 0


if __name__ == "__main__":
    sys.exit(main())
