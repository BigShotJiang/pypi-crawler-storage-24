"""Lightweight HTTP API for the dashboard using Python's built-in http.server."""
from __future__ import annotations

import json
from http.server import BaseHTTPRequestHandler, HTTPServer
from pathlib import Path
from typing import Any
from urllib.parse import parse_qs, urlparse

from abi_observability.dashboard.data_source import RunDataSource


class DashboardHandler(BaseHTTPRequestHandler):
    """HTTP request handler for the dashboard API."""

    data_source: RunDataSource

    def do_GET(self) -> None:
        """Handle GET requests."""
        parsed = urlparse(self.path)
        path = parsed.path
        query_params = parse_qs(parsed.query)

        # API endpoints
        if path == "/api/health":
            self._handle_health()
        elif path == "/api/runs":
            self._handle_list_runs(query_params)
        elif path.startswith("/api/runs/") and path.endswith("/tasks"):
            run_id = path.split("/")[3]
            self._handle_run_tasks(run_id)
        elif path.startswith("/api/runs/"):
            run_id = path.split("/")[3]
            self._handle_get_run(run_id)
        elif path == "/" or path == "/index.html":
            self._serve_static("index.html")
        elif path.startswith("/static/"):
            # Serve static files
            filename = path.split("/")[-1]
            self._serve_static(filename)
        else:
            self._send_error(404, "Not Found")

    def _handle_health(self) -> None:
        """Handle /api/health endpoint."""
        self._send_json({"status": "ok", "service": "abi-observability-dashboard"})

    def _handle_list_runs(self, query_params: dict[str, list[str]]) -> None:
        """Handle /api/runs endpoint."""
        limit = int(query_params.get("limit", ["50"])[0])
        runs = self.data_source.list_runs(limit=limit)
        self._send_json({"runs": runs, "total": len(runs)})

    def _handle_get_run(self, run_id: str) -> None:
        """Handle /api/runs/{run_id} endpoint."""
        run = self.data_source.get_run(run_id)
        if run:
            self._send_json(run)
        else:
            self._send_error(404, f"Run not found: {run_id}")

    def _handle_run_tasks(self, run_id: str) -> None:
        """Handle /api/runs/{run_id}/tasks endpoint."""
        tasks = self.data_source.get_run_tasks(run_id)
        self._send_json({"run_id": run_id, "tasks": tasks, "total": len(tasks)})

    def _serve_static(self, filename: str) -> None:
        """Serve static files from the static/ directory."""
        static_dir = Path(__file__).parent / "static"
        file_path = static_dir / filename

        if not file_path.exists():
            self._send_error(404, "File not found")
            return

        # Determine content type
        content_type = "text/html"
        if filename.endswith(".css"):
            content_type = "text/css"
        elif filename.endswith(".js"):
            content_type = "application/javascript"
        elif filename.endswith(".json"):
            content_type = "application/json"

        try:
            with open(file_path, "rb") as f:
                content = f.read()

            self.send_response(200)
            self.send_header("Content-Type", content_type)
            self.send_header("Content-Length", str(len(content)))
            self.end_headers()
            self.wfile.write(content)
        except Exception as e:
            self._send_error(500, f"Error reading file: {e}")

    def _send_json(self, data: dict[str, Any]) -> None:
        """Send a JSON response."""
        content = json.dumps(data, indent=2, ensure_ascii=False).encode("utf-8")
        self.send_response(200)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(content)))
        self.send_header("Access-Control-Allow-Origin", "*")
        self.end_headers()
        self.wfile.write(content)

    def _send_error(self, code: int, message: str) -> None:
        """Send an error response."""
        content = json.dumps({"error": message}).encode("utf-8")
        self.send_response(code)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(content)))
        self.end_headers()
        self.wfile.write(content)

    def log_message(self, format: str, *args: Any) -> None:
        """Log an HTTP request (override to customize logging)."""
        # Keep default logging for now
        super().log_message(format, *args)


class DashboardServer:
    """Lightweight HTTP server for the dashboard."""

    def __init__(self, port: int = 8080, runs_dir: Path | None = None):
        """Initialize the dashboard server.

        Args:
            port: Port to listen on
            runs_dir: Directory containing run evidence packs
        """
        self.port = port
        self.data_source = RunDataSource(runs_dir=runs_dir)

        # Monkey-patch the handler class to inject the data source
        DashboardHandler.data_source = self.data_source

    def start(self) -> None:
        """Start the HTTP server."""
        server = HTTPServer(("0.0.0.0", self.port), DashboardHandler)
        print(f"Dashboard server running at http://localhost:{self.port}")
        print(f"Runs directory: {self.data_source.runs_dir}")
        print("Press Ctrl+C to stop")

        try:
            server.serve_forever()
        except KeyboardInterrupt:
            print("\nShutting down server...")
            server.shutdown()
            server.server_close()
