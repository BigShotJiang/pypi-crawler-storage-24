"""Dashboard module for abi-observability.

Lightweight HTTP API and web UI for visualizing pipeline runs.

DEPRECATION NOTICE:
    This Python/static-HTML dashboard is superseded by the Next.js dashboard
    at ``abi-infra/dashboard/`` (React 19, Recharts, Tailwind).
    This module remains functional for environments without Node.js but
    receives no new features. Prefer ``cd dashboard && npm run dev`` for
    the canonical CTO-grade dashboard experience.
"""
from abi_observability.dashboard.data_source import RunDataSource
from abi_observability.dashboard.dashboard_api import DashboardServer

__all__ = ["DashboardServer", "RunDataSource"]
