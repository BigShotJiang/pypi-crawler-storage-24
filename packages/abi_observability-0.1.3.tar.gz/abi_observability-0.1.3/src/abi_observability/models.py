"""Internal models for events and spans.

Uses internal format compatible with abi-core trace-event/1.0 and span/1.0 schemas.
"""
from __future__ import annotations

import json
from dataclasses import asdict, dataclass, field
from typing import Any

# Event classification categories
EVENT_CATEGORIES = {
    "policy": ["POLICY_DECISION", "POLICY_OVERRIDE", "HIL_CHECKPOINT"],
    "eval": ["EVAL_STARTED", "EVAL_COMPLETED", "REGRESSION_CHECK"],
    "tool": ["TOOL_INVOKED", "TOOL_COMPLETED", "MCP_INVOKED"],
    "model": ["MODEL_CALL", "MODEL_RESPONSE", "GENAI_TELEMETRY"],
    "file": ["FILE_READ", "FILE_WRITE", "ARTIFACT_CREATED"],
    "system": [
        "RUN_STARTED", "RUN_COMPLETED", "PHASE_STARTED", "PHASE_COMPLETED",
        "TASK_STARTED", "TASK_COMPLETED", "TASK_FAILED",
        "CIRCUIT_BREAKER_TRIPPED", "RECOVERY_NEEDED",
    ],
}

# Reverse lookup: event_type -> category
EVENT_TYPE_TO_CATEGORY: dict[str, str] = {}
for category, types in EVENT_CATEGORIES.items():
    for event_type in types:
        EVENT_TYPE_TO_CATEGORY[event_type] = category


@dataclass
class Event:
    """An observable event in the ABI pipeline."""
    event_id: str
    event_type: str
    timestamp: str
    run_id: str = ""
    payload: dict[str, Any] = field(default_factory=dict)
    metadata: dict[str, Any] = field(default_factory=dict)

    @property
    def category(self) -> str:
        return EVENT_TYPE_TO_CATEGORY.get(self.event_type, "system")

    def to_dict(self) -> dict[str, Any]:
        d = asdict(self)
        d["schema_version"] = "tier2-event-envelope/1.0"
        return d

    def to_ndjson_line(self) -> str:
        return json.dumps(self.to_dict(), ensure_ascii=False, sort_keys=True)


@dataclass
class Span:
    """A trace span (OpenTelemetry-inspired)."""
    span_id: str
    trace_id: str
    name: str
    start_time: str
    end_time: str
    status: str = "ok"  # ok | error
    parent_span_id: str = ""
    attributes: dict[str, Any] = field(default_factory=dict)
    events: list[dict[str, Any]] = field(default_factory=list)

    def to_dict(self) -> dict[str, Any]:
        d = asdict(self)
        d["schema_version"] = "tier2-span-envelope/1.0"
        return d

    def to_ndjson_line(self) -> str:
        return json.dumps(self.to_dict(), ensure_ascii=False, sort_keys=True)
