"""CLI for abi-observability.

Usage:
    python -m abi_observability.cli emit-demo --out-dir <dir>
    python -m abi_observability.cli build-timeline --in-dir <dir> --out <file>
"""
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

from abi_observability.exporters import build_json_summary, build_timeline_md, export_summary
from abi_observability.models import Event, Span
from abi_observability.otel_genai import GenAIAttributes, to_genai_attributes
from abi_observability.redaction import redact_event
from abi_observability.writers import write_events_ndjson, write_spans_ndjson


def _make_demo_events() -> list[Event]:
    """Create deterministic demo events."""
    return [
        Event(
            event_id="evt-001",
            event_type="RUN_STARTED",
            timestamp="2025-01-01T00:00:00Z",
            run_id="demo0001",
            payload={"message": "Demo run started"},
        ),
        Event(
            event_id="evt-002",
            event_type="POLICY_DECISION",
            timestamp="2025-01-01T00:00:01Z",
            run_id="demo0001",
            payload={"decision": "allow", "tool": "read_file"},
        ),
        Event(
            event_id="evt-003",
            event_type="TOOL_INVOKED",
            timestamp="2025-01-01T00:00:02Z",
            run_id="demo0001",
            payload={"tool": "read_file", "path": "src/main.py"},
        ),
        Event(
            event_id="evt-004",
            event_type="MODEL_CALL",
            timestamp="2025-01-01T00:00:03Z",
            run_id="demo0001",
            payload={
                GenAIAttributes.SYSTEM: "anthropic",
                GenAIAttributes.REQUEST_MODEL: "claude-sonnet-4-20250514",
                GenAIAttributes.OPERATION_NAME: "chat",
                GenAIAttributes.USAGE_INPUT_TOKENS: 1200,
                GenAIAttributes.USAGE_OUTPUT_TOKENS: 300,
                "api_key": "sk-secret-123",
            },
        ),
        Event(
            event_id="evt-005",
            event_type="EVAL_COMPLETED",
            timestamp="2025-01-01T00:00:04Z",
            run_id="demo0001",
            payload={"suite_id": "demo-suite", "passed": 3, "failed": 0},
        ),
        Event(
            event_id="evt-006",
            event_type="RUN_COMPLETED",
            timestamp="2025-01-01T00:00:05Z",
            run_id="demo0001",
            payload={"status": "success", "message": "Demo run completed"},
        ),
    ]


def _make_demo_spans() -> list[Span]:
    """Create deterministic demo spans."""
    return [
        Span(
            span_id="span-001",
            trace_id="trace-001",
            name="demo_run",
            start_time="2025-01-01T00:00:00Z",
            end_time="2025-01-01T00:00:05Z",
            status="ok",
            attributes={"run_id": "demo0001"},
        ),
        Span(
            span_id="span-002",
            trace_id="trace-001",
            name="policy_eval",
            start_time="2025-01-01T00:00:01Z",
            end_time="2025-01-01T00:00:01.500Z",
            status="ok",
            parent_span_id="span-001",
            attributes={"bundle": "default"},
        ),
        Span(
            span_id="span-003",
            trace_id="trace-001",
            name="tool_execution",
            start_time="2025-01-01T00:00:02Z",
            end_time="2025-01-01T00:00:03Z",
            status="ok",
            parent_span_id="span-001",
            attributes={"tool": "read_file"},
        ),
        Span(
            span_id="span-004",
            trace_id="trace-001",
            name="chat",
            start_time="2025-01-01T00:00:03Z",
            end_time="2025-01-01T00:00:04Z",
            status="ok",
            parent_span_id="span-001",
            attributes=to_genai_attributes(
                system="anthropic",
                model="claude-sonnet-4-20250514",
                operation="chat",
                input_tokens=1200,
                output_tokens=300,
            ),
        ),
    ]


def cmd_emit_demo(args: argparse.Namespace) -> int:
    """Emit demo events and spans to NDJSON files."""
    out_dir = Path(args.out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)

    events = _make_demo_events()
    spans = _make_demo_spans()

    # Redact sensitive data before writing
    redacted_events = [redact_event(e) for e in events]

    n_events = write_events_ndjson(redacted_events, out_dir / "events.ndjson")
    n_spans = write_spans_ndjson(spans, out_dir / "spans.ndjson")

    print(f"Emitted {n_events} events to {out_dir / 'events.ndjson'}")
    print(f"Emitted {n_spans} spans to {out_dir / 'spans.ndjson'}")

    # Also write summary
    summary = build_json_summary(redacted_events, spans)
    summary_path = out_dir / "summary.json"
    with open(summary_path, "w") as f:
        json.dump(summary, f, indent=2, sort_keys=True)
        f.write("\n")
    print(f"Summary written to {summary_path}")

    return 0


def cmd_build_timeline(args: argparse.Namespace) -> int:
    """Build timeline from NDJSON files."""
    in_dir = Path(args.in_dir)
    out_path = Path(args.out)

    if not in_dir.exists():
        print(f"Error: Input directory does not exist: {in_dir}", file=sys.stderr)
        return 1

    # Load events and spans
    from abi_observability.exporters import _load_events, _load_spans

    events = _load_events(in_dir)
    spans = _load_spans(in_dir)

    timeline = build_timeline_md(events, spans)

    out_path.parent.mkdir(parents=True, exist_ok=True)
    out_path.write_text(timeline, encoding="utf-8")
    print(f"Timeline written to {out_path} ({len(events)} events, {len(spans)} spans)")

    # Also write summary
    summary_path = out_path.parent / "summary.json"
    export_summary(in_dir, summary_path)
    print(f"Summary written to {summary_path}")

    return 0


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="abi-observability",
        description="ABI Observability — event/span pipeline with offline exporters",
    )
    sub = parser.add_subparsers(dest="command", required=True)

    p_emit = sub.add_parser("emit-demo", help="Emit demo events and spans")
    p_emit.add_argument("--out-dir", required=True, help="Output directory")

    p_timeline = sub.add_parser("build-timeline", help="Build timeline from NDJSON")
    p_timeline.add_argument("--in-dir", required=True, help="Input directory with NDJSON files")
    p_timeline.add_argument("--out", required=True, help="Output timeline.md path")

    return parser


def main(argv: list[str] | None = None) -> int:
    parser = build_parser()
    args = parser.parse_args(argv)

    commands = {
        "emit-demo": cmd_emit_demo,
        "build-timeline": cmd_build_timeline,
    }

    return commands[args.command](args)


if __name__ == "__main__":
    sys.exit(main())
