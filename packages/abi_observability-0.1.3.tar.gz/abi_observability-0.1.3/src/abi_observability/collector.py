"""In-process event collector for abi-observability.

A simple event collector that:
- Receives events and spans from orchestrator's EventBus (when it exists)
- Buffers events and spans in memory
- Flushes to configured exporters on demand or at intervals
- Supports multiple exporters simultaneously

Configuration via environment variables:
- ABI_COLLECTOR_BUFFER_SIZE: Max events/spans before auto-flush (default: 100)
- ABI_COLLECTOR_FLUSH_INTERVAL: Auto-flush interval in seconds (default: 60, 0 to disable)
- ABI_COLLECTOR_EXPORTERS: Comma-separated list of exporters to enable (default: "file")
  Options: "file", "otlp", "langfuse"
"""
from __future__ import annotations

import os
import time
from dataclasses import dataclass, field
from typing import Any

from abi_observability.models import Event, Span


@dataclass
class CollectorConfig:
    """Configuration for the event collector."""

    buffer_size: int = 100
    flush_interval: float = 60.0  # seconds, 0 to disable
    enabled_exporters: list[str] = field(default_factory=lambda: ["file"])
    auto_flush: bool = True

    @classmethod
    def from_env(cls) -> CollectorConfig:
        """Load configuration from environment variables."""
        buffer_size = int(os.getenv("ABI_COLLECTOR_BUFFER_SIZE", "100"))
        flush_interval = float(os.getenv("ABI_COLLECTOR_FLUSH_INTERVAL", "60.0"))
        exporters_str = os.getenv("ABI_COLLECTOR_EXPORTERS", "file")
        enabled_exporters = [e.strip() for e in exporters_str.split(",") if e.strip()]
        auto_flush = os.getenv("ABI_COLLECTOR_AUTO_FLUSH", "true").lower() == "true"

        return cls(
            buffer_size=buffer_size,
            flush_interval=flush_interval,
            enabled_exporters=enabled_exporters,
            auto_flush=auto_flush,
        )


class Collector:
    """In-process event and span collector.

    Buffers events and spans in memory and flushes to configured exporters.
    Supports multiple exporters simultaneously for flexible observability.
    """

    def __init__(self, config: CollectorConfig | None = None) -> None:
        """Initialize the collector.

        Args:
            config: Optional configuration. If None, loads from environment.
        """
        self.config = config or CollectorConfig.from_env()
        self._events: list[Event] = []
        self._spans: list[Span] = []
        self._last_flush_time = time.time()
        self._exporters: list[Any] = []
        self._setup_exporters()

    def _setup_exporters(self) -> None:
        """Setup exporters based on configuration."""
        from abi_observability.writers import append_event, append_span

        self._file_writer_available = True
        self._file_event_path = None
        self._file_span_path = None

        # Setup file exporter (using existing writers)
        if "file" in self.config.enabled_exporters:
            from pathlib import Path

            base_path = Path(os.getenv("ABI_COLLECTOR_FILE_PATH", "./observability_data"))
            self._file_event_path = base_path / "events.ndjson"
            self._file_span_path = base_path / "spans.ndjson"

        # Setup OTLP exporter
        if "otlp" in self.config.enabled_exporters:
            try:
                from abi_observability.exporters.otlp_exporter import OTLPExporter

                self._exporters.append(("otlp", OTLPExporter()))
            except ImportError:
                pass  # Gracefully skip if not available

        # Setup Langfuse exporter
        if "langfuse" in self.config.enabled_exporters:
            try:
                from abi_observability.exporters.langfuse_exporter import LangfuseExporter

                self._exporters.append(("langfuse", LangfuseExporter()))
            except ImportError:
                pass  # Gracefully skip if not available

    def collect_event(self, event: Event) -> None:
        """Collect a single event.

        Args:
            event: Event to collect.
        """
        self._events.append(event)
        self._check_flush()

    def collect_span(self, span: Span) -> None:
        """Collect a single span.

        Args:
            span: Span to collect.
        """
        self._spans.append(span)
        self._check_flush()

    def collect_events(self, events: list[Event]) -> None:
        """Collect multiple events.

        Args:
            events: List of events to collect.
        """
        self._events.extend(events)
        self._check_flush()

    def collect_spans(self, spans: list[Span]) -> None:
        """Collect multiple spans.

        Args:
            spans: List of spans to collect.
        """
        self._spans.extend(spans)
        self._check_flush()

    def _check_flush(self) -> None:
        """Check if auto-flush conditions are met."""
        if not self.config.auto_flush:
            return

        # Check buffer size
        total_items = len(self._events) + len(self._spans)
        if total_items >= self.config.buffer_size:
            self.flush()
            return

        # Check time interval
        if self.config.flush_interval > 0:
            elapsed = time.time() - self._last_flush_time
            if elapsed >= self.config.flush_interval:
                self.flush()

    def flush(self) -> dict[str, Any]:
        """Flush buffered events and spans to all configured exporters.

        Returns:
            Flush results with status for each exporter.
        """
        results: dict[str, Any] = {
            "events_flushed": len(self._events),
            "spans_flushed": len(self._spans),
            "exporters": {},
        }

        # Export to file (using existing writers)
        if self._file_event_path and self._events:
            try:
                from abi_observability.writers import append_event

                for event in self._events:
                    append_event(event, self._file_event_path)
                results["exporters"]["file_events"] = {
                    "status": "success",
                    "count": len(self._events),
                }
            except Exception as e:
                results["exporters"]["file_events"] = {
                    "status": "error",
                    "error": str(e),
                }

        if self._file_span_path and self._spans:
            try:
                from abi_observability.writers import append_span

                for span in self._spans:
                    append_span(span, self._file_span_path)
                results["exporters"]["file_spans"] = {
                    "status": "success",
                    "count": len(self._spans),
                }
            except Exception as e:
                results["exporters"]["file_spans"] = {
                    "status": "error",
                    "error": str(e),
                }

        # Export to configured exporters
        for exporter_name, exporter in self._exporters:
            try:
                if self._spans and hasattr(exporter, "export"):
                    # OTLP exporter
                    result = exporter.export(self._spans)
                    results["exporters"][exporter_name] = result
                elif hasattr(exporter, "export_spans") and self._spans:
                    # Langfuse exporter - spans
                    result = exporter.export_spans(self._spans)
                    results["exporters"][f"{exporter_name}_spans"] = result
                if self._events and hasattr(exporter, "export_events"):
                    # Langfuse exporter - events
                    result = exporter.export_events(self._events)
                    results["exporters"][f"{exporter_name}_events"] = result
            except Exception as e:
                results["exporters"][exporter_name] = {
                    "status": "error",
                    "error": str(e),
                }

        # Clear buffers
        self._events.clear()
        self._spans.clear()
        self._last_flush_time = time.time()

        return results

    def shutdown(self) -> dict[str, Any]:
        """Shutdown the collector and flush any remaining data.

        Returns:
            Final flush results.
        """
        return self.flush()

    @property
    def buffer_status(self) -> dict[str, Any]:
        """Get current buffer status.

        Returns:
            Dictionary with buffer statistics.
        """
        return {
            "events_buffered": len(self._events),
            "spans_buffered": len(self._spans),
            "total_buffered": len(self._events) + len(self._spans),
            "buffer_size_limit": self.config.buffer_size,
            "time_since_last_flush": time.time() - self._last_flush_time,
            "flush_interval": self.config.flush_interval,
        }


# Global singleton collector (optional convenience)
_global_collector: Collector | None = None


def get_collector() -> Collector:
    """Get or create the global collector instance.

    Returns:
        The global Collector instance.
    """
    global _global_collector
    if _global_collector is None:
        _global_collector = Collector()
    return _global_collector


def reset_collector() -> None:
    """Reset the global collector (useful for testing)."""
    global _global_collector
    if _global_collector is not None:
        _global_collector.shutdown()
    _global_collector = None
