# Verification Notes — abi-observability

## Traceability Markers

### Full node ID: determinism

```
tests/test_exporters.py::TestJsonSummary::test_deterministic
```

Verifies that the same events produce identical JSON summary output via
`json.dumps(sort_keys=True)` across repeated exports.

### Full node ID: timestamp exclusion

N/A — abi-observability on main does not produce hashed payloads with
timestamp fields in the digest. Chronological ordering is tested separately.
The stability node below serves as the second traceability anchor.

### Full node ID: stability

```
tests/test_writers.py::TestWriteEvents::test_deterministic_ordering
```

Asserts that the same events written to two separate files produce
byte-identical NDJSON output, confirming stable serialization order.

---

## Tranche History

- **Control Plane Tranche** (base HEAD `431efe2`) — determinism hardening, evidence deepening, contract enforcement

### Control Plane Tranche — Capability Advancement

**Determinism hardening** — 9 tests in `tests/test_determinism_hardening.py`

Full node ID:
```
tests/test_determinism_hardening.py::TestDeterminismHardening::test_event_ndjson_hash_stability
```

**Evidence deepening** — 8 tests in `tests/test_evidence_deepening.py`

Full node ID:
```
tests/test_evidence_deepening.py::TestEvidenceDeepening::test_event_ndjson_has_required_fields
```

**Contract enforcement** — 7 tests in `tests/test_contract_enforcement.py`

Full node ID:
```
tests/test_contract_enforcement.py::TestContractEnforcement::test_event_envelope_has_valid_structure
```

24 new tests total. All pass. SHA-256 hash stability for events, spans,
exporters. Schema validation for tier-2 event/span/summary envelopes.
