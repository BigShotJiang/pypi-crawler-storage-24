# Roadmap

## Near Term
- OpenTelemetry exporter
- Span correlation with abi-evals results

## Later
- Real-time streaming observability dashboard
