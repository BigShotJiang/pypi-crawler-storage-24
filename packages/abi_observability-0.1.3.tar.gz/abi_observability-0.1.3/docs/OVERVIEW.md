# Overview

## Purpose
Provides structured observability for AbilityBI AI pipeline runs with offline-first design for private environments.

## Primary Users
- AbilityBI engineering and AI pipeline operators

## Scope
- What it covers: Event and span pipeline with offline exporters for AbilityBI runtime observability.
- What it does not cover: External distribution or unsanctioned integrations
