# Architecture

## High-Level Design
Event and span pipeline with offline exporters for AbilityBI runtime observability.

## Components
- src/abi_observability/ — event pipeline and exporters
- tests/ — observability unit tests

## Interfaces
Inputs: Structured data, policy definitions, or API requests depending on module.
Outputs: Processed results, evidence packs, or structured reports.
