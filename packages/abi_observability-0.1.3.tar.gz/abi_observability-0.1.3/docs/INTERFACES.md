# abi-observability Interfaces

## NDJSON Output

### events.ndjson
One JSON object per line, sorted by (timestamp, event_id):
```json
{"event_id":"...","event_type":"...","timestamp":"...","run_id":"...","payload":{...},"metadata":{...}}
```

### spans.ndjson
One JSON object per line, sorted by (start_time, span_id):
```json
{"span_id":"...","trace_id":"...","name":"...","start_time":"...","end_time":"...","status":"...","attributes":{...}}
```

## Exporters

### timeline.md
Markdown table with chronological events and spans.

### summary.json
```json
{
  "total_events": N,
  "events_by_type": {"RUN_STARTED": N, ...},
  "events_by_category": {"system": N, "policy": N, ...},
  "total_spans": N,
  "spans_by_status": {"ok": N, "error": N}
}
```

## CLI Commands

| Command | Description |
|---------|-------------|
| `emit-demo --out-dir <dir>` | Emit sample events/spans to NDJSON |
| `build-timeline --in-dir <dir> --out <file>` | Build timeline from NDJSON |
