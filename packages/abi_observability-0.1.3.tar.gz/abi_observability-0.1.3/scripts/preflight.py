#!/usr/bin/env python3
"""Preflight check for abi-observability."""
from __future__ import annotations

import subprocess
import sys
from pathlib import Path

REPO_ROOT = Path(__file__).resolve().parent.parent

REQUIRED_FILES = [
    "README.md",
    "SECURITY.md",
    "pyproject.toml",
    "src/abi_observability/__init__.py",
    "src/abi_observability/writers.py",
    "src/abi_observability/redaction.py",
    "src/abi_observability/exporters.py",
    "src/abi_observability/cli.py",
    "tests/fixtures/sample_events.ndjson",
    "tests/fixtures/sample_spans.ndjson",
]


def check_files() -> list[str]:
    return [f for f in REQUIRED_FILES if not (REPO_ROOT / f).exists()]


def run_lint() -> int:
    print("=== Running ruff ===")
    return subprocess.run(
        [sys.executable, "-m", "ruff", "check", "src/", "tests/"],
        cwd=REPO_ROOT,
    ).returncode


def run_tests() -> int:
    print("=== Running pytest ===")
    return subprocess.run(
        [sys.executable, "-m", "pytest", "tests/", "-v", "--tb=short"],
        cwd=REPO_ROOT,
    ).returncode


def main() -> int:
    print("abi-observability preflight check")
    print("=" * 40)

    print("\n--- File presence ---")
    missing = check_files()
    for f in missing:
        print(f"  FAIL: Missing {f}")
    if not missing:
        print("  OK: All required files present")

    print()
    lint_rc = run_lint()
    print()
    test_rc = run_tests()

    if missing or lint_rc != 0 or test_rc != 0:
        print("\nPREFLIGHT FAILED")
        return 1
    print("\nPREFLIGHT PASSED")
    return 0


if __name__ == "__main__":
    sys.exit(main())
