"""Demo of OTLP and Langfuse exporters with the Collector.

This demo shows how to:
1. Create events and spans
2. Use the Collector to buffer and export to multiple destinations
3. Export to OTLP format (for OpenTelemetry)
4. Export to Langfuse format (for LLM observability)
"""
from __future__ import annotations

import os
from pathlib import Path

from abi_observability import (
    Collector,
    CollectorConfig,
    Event,
    OTLPExporter,
    LangfuseExporter,
    Span,
)


def main() -> None:
    """Run the exporters demo."""
    print("=== ABI Observability Exporters Demo ===\n")

    # Setup output directory
    output_dir = Path(__file__).parent / "output"
    output_dir.mkdir(exist_ok=True)

    # Configure environment for exporters
    os.environ["ABI_COLLECTOR_FILE_PATH"] = str(output_dir / "collector_output")
    os.environ["ABI_OTLP_EXPORT_TYPE"] = "file"
    os.environ["ABI_OTLP_FILE_PATH"] = str(output_dir / "otlp_traces.jsonl")
    os.environ["LANGFUSE_MODE"] = "offline"
    os.environ["LANGFUSE_FILE_PATH"] = str(output_dir / "langfuse_traces.jsonl")

    # Create sample events and spans
    events = create_sample_events()
    spans = create_sample_spans()

    print(f"Created {len(events)} events and {len(spans)} spans\n")

    # Demo 1: Direct OTLP export
    print("--- Demo 1: Direct OTLP Export ---")
    otlp_exporter = OTLPExporter()
    otlp_result = otlp_exporter.export(spans)
    print(f"OTLP Export: {otlp_result}")
    print(f"  Output: {output_dir / 'otlp_traces.jsonl'}\n")

    # Demo 2: Direct Langfuse export
    print("--- Demo 2: Direct Langfuse Export ---")
    langfuse_exporter = LangfuseExporter()
    langfuse_spans_result = langfuse_exporter.export_spans(spans)
    langfuse_events_result = langfuse_exporter.export_events(events)
    print(f"Langfuse Spans Export: {langfuse_spans_result}")
    print(f"Langfuse Events Export: {langfuse_events_result}")
    print(f"  Output: {output_dir / 'langfuse_traces.jsonl'}\n")

    # Demo 3: Collector with multiple exporters
    print("--- Demo 3: Collector with Multiple Exporters ---")
    config = CollectorConfig(
        auto_flush=False,
        enabled_exporters=["file", "otlp", "langfuse"],
    )
    collector = Collector(config)

    # Collect events and spans
    collector.collect_events(events)
    collector.collect_spans(spans)

    # Check buffer status
    status = collector.buffer_status
    print(f"Buffer status: {status['events_buffered']} events, {status['spans_buffered']} spans")

    # Flush to all exporters
    flush_result = collector.flush()
    print(f"\nFlush result:")
    print(f"  Events flushed: {flush_result['events_flushed']}")
    print(f"  Spans flushed: {flush_result['spans_flushed']}")
    print(f"  Exporters:")
    for exporter_name, exporter_result in flush_result["exporters"].items():
        print(f"    - {exporter_name}: {exporter_result.get('status', 'unknown')}")

    # Demo 4: Export a GenerationRecord (simulating T-0205 format)
    print("\n--- Demo 4: Export GenerationRecord (Langfuse) ---")
    generation_record = {
        "generation_id": "gen-demo-001",
        "run_id": "run-demo-001",
        "phase": "code_generation",
        "task": "write_hello_world",
        "model": "claude-sonnet-4.5",
        "prompt": "Write a Python function that prints 'Hello, World!'",
        "completion": "def hello_world():\n    print('Hello, World!')",
        "timestamp": "2025-01-01T12:00:00Z",
        "metadata": {
            "usage": {
                "input_tokens": 15,
                "output_tokens": 12,
                "total_tokens": 27,
            },
            "model_parameters": {
                "temperature": 0.7,
                "max_tokens": 1000,
            },
        },
    }

    gen_exporter = LangfuseExporter()
    gen_result = gen_exporter.export_generation(generation_record)
    print(f"Generation export: {gen_result}")

    print(f"\n=== Demo Complete ===")
    print(f"All outputs written to: {output_dir}")
    print("\nFiles created:")
    for file in sorted(output_dir.rglob("*")):
        if file.is_file():
            size = file.stat().st_size
            print(f"  - {file.relative_to(output_dir)} ({size} bytes)")


def create_sample_events() -> list[Event]:
    """Create sample events for the demo."""
    return [
        Event(
            event_id="evt-demo-001",
            event_type="RUN_STARTED",
            timestamp="2025-01-01T12:00:00Z",
            run_id="run-demo-001",
            payload={"message": "Demo run started"},
        ),
        Event(
            event_id="evt-demo-002",
            event_type="POLICY_DECISION",
            timestamp="2025-01-01T12:00:01Z",
            run_id="run-demo-001",
            payload={"decision": "allow", "tool": "code_generator"},
        ),
        Event(
            event_id="evt-demo-003",
            event_type="MODEL_CALL",
            timestamp="2025-01-01T12:00:02Z",
            run_id="run-demo-001",
            payload={"model": "claude-sonnet-4.5", "tokens": 1500},
        ),
        Event(
            event_id="evt-demo-004",
            event_type="TOOL_INVOKED",
            timestamp="2025-01-01T12:00:03Z",
            run_id="run-demo-001",
            payload={"tool": "code_generator", "language": "python"},
        ),
        Event(
            event_id="evt-demo-005",
            event_type="RUN_COMPLETED",
            timestamp="2025-01-01T12:00:04Z",
            run_id="run-demo-001",
            payload={"status": "success", "message": "Demo completed"},
        ),
    ]


def create_sample_spans() -> list[Span]:
    """Create sample spans for the demo."""
    return [
        Span(
            span_id="span-demo-001",
            trace_id="trace-demo-001",
            name="demo_run",
            start_time="2025-01-01T12:00:00Z",
            end_time="2025-01-01T12:00:04Z",
            status="ok",
            attributes={"run_id": "run-demo-001", "environment": "demo"},
        ),
        Span(
            span_id="span-demo-002",
            trace_id="trace-demo-001",
            name="policy_check",
            start_time="2025-01-01T12:00:01Z",
            end_time="2025-01-01T12:00:01.200Z",
            status="ok",
            parent_span_id="span-demo-001",
            attributes={"policy": "allow_code_generation"},
        ),
        Span(
            span_id="span-demo-003",
            trace_id="trace-demo-001",
            name="llm_call",
            start_time="2025-01-01T12:00:02Z",
            end_time="2025-01-01T12:00:03.500Z",
            status="ok",
            parent_span_id="span-demo-001",
            attributes={
                "model": "claude-sonnet-4.5",
                "input_tokens": 15,
                "output_tokens": 12,
            },
        ),
        Span(
            span_id="span-demo-004",
            trace_id="trace-demo-001",
            name="code_generation",
            start_time="2025-01-01T12:00:03Z",
            end_time="2025-01-01T12:00:03.800Z",
            status="ok",
            parent_span_id="span-demo-001",
            attributes={"language": "python", "lines_of_code": 2},
        ),
    ]


if __name__ == "__main__":
    main()
