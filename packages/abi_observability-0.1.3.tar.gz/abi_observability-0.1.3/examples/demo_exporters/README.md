# Exporters Demo

This demo showcases the new OTLP and Langfuse exporters in abi-observability.

## Features Demonstrated

1. **OTLP Exporter**: Export spans in OpenTelemetry Protocol (OTLP) format
2. **Langfuse Exporter**: Export events, spans, and generations for LLM observability
3. **Collector**: In-process event collector with buffering and multi-exporter support
4. **GenerationRecord**: Export LLM generation records in Langfuse format

## Running the Demo

```bash
cd examples/demo_exporters
python run_demo.py
```

Or from the repository root:

```bash
PYTHONPATH=src python examples/demo_exporters/run_demo.py
```

## Output

The demo creates the following files in `examples/demo_exporters/output/`:

- `otlp_traces.jsonl` - OTLP-formatted spans (compatible with OpenTelemetry collectors)
- `langfuse_traces.jsonl` - Langfuse-formatted traces, events, and generations
- `collector_output/events.ndjson` - Raw events from the collector
- `collector_output/spans.ndjson` - Raw spans from the collector

## Configuration

The exporters can be configured via environment variables:

### OTLP Exporter

- `ABI_OTLP_ENDPOINT` - HTTP endpoint for OTLP collector (default: `http://localhost:4318/v1/traces`)
- `ABI_OTLP_EXPORT_TYPE` - `"file"` or `"http"` (default: `"file"`)
- `ABI_OTLP_FILE_PATH` - Path for file export (default: `./otlp_traces.jsonl`)
- `ABI_OTLP_TIMEOUT` - HTTP timeout in seconds (default: `10`)

### Langfuse Exporter

- `LANGFUSE_PUBLIC_KEY` - Public API key for Langfuse
- `LANGFUSE_SECRET_KEY` - Secret API key for Langfuse
- `LANGFUSE_HOST` - Langfuse host URL (default: `https://cloud.langfuse.com`)
- `LANGFUSE_MODE` - `"offline"` or `"online"` (default: `"offline"`)
- `LANGFUSE_FILE_PATH` - Path for offline export (default: `./langfuse_traces.jsonl`)
- `LANGFUSE_TIMEOUT` - HTTP timeout in seconds (default: `10`)

### Collector

- `ABI_COLLECTOR_BUFFER_SIZE` - Max events/spans before auto-flush (default: `100`)
- `ABI_COLLECTOR_FLUSH_INTERVAL` - Auto-flush interval in seconds (default: `60`, `0` to disable)
- `ABI_COLLECTOR_EXPORTERS` - Comma-separated list of exporters: `"file,otlp,langfuse"` (default: `"file"`)
- `ABI_COLLECTOR_FILE_PATH` - Base path for file exporter (default: `./observability_data`)
- `ABI_COLLECTOR_AUTO_FLUSH` - Enable/disable auto-flush (default: `"true"`)

## Integration Examples

### Using the Collector

```python
from abi_observability import Collector, CollectorConfig, Event, Span

# Configure collector
config = CollectorConfig(
    buffer_size=50,
    enabled_exporters=["file", "otlp", "langfuse"],
    auto_flush=True,
)
collector = Collector(config)

# Collect events and spans
event = Event(
    event_id="evt-001",
    event_type="MODEL_CALL",
    timestamp="2025-01-01T00:00:00Z",
    run_id="run-001",
    payload={"model": "claude-sonnet-4.5"},
)
collector.collect_event(event)

# Auto-flushes when buffer is full, or manually:
collector.flush()
```

### Direct OTLP Export

```python
from abi_observability.exporters import OTLPExporter, OTLPExporterConfig

# Configure for HTTP export
config = OTLPExporterConfig(
    export_type="http",
    endpoint="http://localhost:4318/v1/traces",
)
exporter = OTLPExporter(config)

# Export spans
result = exporter.export(spans)
print(result)  # {'status': 'success', 'exported': 10, ...}
```

### Direct Langfuse Export

```python
from abi_observability.exporters import LangfuseExporter, LangfuseExporterConfig

# Configure for online mode
config = LangfuseExporterConfig(
    mode="online",
    public_key="pk-lf-...",
    secret_key="sk-lf-...",
)
exporter = LangfuseExporter(config)

# Export spans
result = exporter.export_spans(spans)

# Export events
result = exporter.export_events(events)

# Export generation record (from T-0205)
generation = {
    "generation_id": "gen-001",
    "run_id": "run-001",
    "model": "claude-sonnet-4.5",
    "prompt": "...",
    "completion": "...",
    # ... more fields
}
result = exporter.export_generation(generation)
```

## Design Notes

### No Hard Dependencies

The exporters use **optional imports** with graceful fallback. Neither `opentelemetry-sdk` nor `langfuse` are required as hard dependencies. The exporters:

- Implement OTLP JSON format manually (no OTel SDK needed)
- Use standard library `urllib` for HTTP (no `requests` needed)
- Fail gracefully if dependencies are missing

### OTLP Format

The OTLP exporter converts internal `Span` objects to the OpenTelemetry Protocol JSON format:

- Compatible with any OTLP collector (Jaeger, Zipkin, Grafana, etc.)
- Supports both file (JSONL) and HTTP export
- Proper trace ID and span ID encoding
- Full attribute type conversion (bool, int, float, string, complex)

### Langfuse Format

The Langfuse exporter maps ABI concepts to Langfuse observability:

- `run_id` → `trace_id`
- `phase` → `span`
- `task` → `generation` (for LLM calls)
- Supports offline mode (JSONL for batch upload) and online mode (direct HTTP)

### Collector Design

The collector provides:

- In-memory buffering with configurable size limits
- Auto-flush on buffer size or time interval
- Multiple simultaneous exporters
- Thread-safe operation (for future async support)
- Global singleton pattern for convenience

## See Also

- [T-0211: OTLP and Langfuse Integration](../../docs/)
- [T-0205: GenerationRecord Format](../../docs/)
- [abi-core span schema](../../docs/)
