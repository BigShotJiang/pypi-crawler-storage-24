#!/usr/bin/env python3
"""Demo script to generate sample run data and launch the dashboard.

This script:
1. Creates sample run evidence packs in ./runs
2. Launches the dashboard server at http://localhost:8080
3. Opens the dashboard in your default browser

Usage:
    python examples/demo_dashboard/run_demo.py
"""
from __future__ import annotations

import json
import sys
import webbrowser
from pathlib import Path
from time import sleep

sys.path.insert(0, str(Path(__file__).resolve().parent.parent.parent / "src"))

from abi_observability.dashboard.dashboard_api import DashboardServer
from abi_observability.models import Event, Span
from abi_observability.writers import write_events_ndjson, write_spans_ndjson


def create_sample_runs() -> None:
    """Create sample run evidence packs for demonstration."""
    runs_dir = Path.cwd() / "runs"
    runs_dir.mkdir(exist_ok=True)

    print("Creating sample run evidence packs...")

    # Run 1: Successful multi-phase run
    create_run_1(runs_dir)

    # Run 2: Failed run with errors
    create_run_2(runs_dir)

    # Run 3: Running (incomplete) run
    create_run_3(runs_dir)

    print(f"Created 3 sample runs in {runs_dir}")


def create_run_1(runs_dir: Path) -> None:
    """Create a successful multi-phase run."""
    run_id = "demo-success-001"
    run_dir = runs_dir / f"evidence_pack_{run_id}"
    run_dir.mkdir(exist_ok=True)

    events = [
        Event(
            event_id="evt-001",
            event_type="RUN_STARTED",
            timestamp="2025-01-15T10:00:00Z",
            run_id=run_id,
            payload={"message": "Starting successful demo run"},
        ),
        # Planning phase
        Event(
            event_id="evt-002",
            event_type="PHASE_STARTED",
            timestamp="2025-01-15T10:00:01Z",
            run_id=run_id,
            payload={"phase": "PLANNING"},
        ),
        Event(
            event_id="evt-003",
            event_type="TASK_STARTED",
            timestamp="2025-01-15T10:00:02Z",
            run_id=run_id,
            payload={"task_id": "task-plan-1", "phase": "PLANNING"},
        ),
        Event(
            event_id="evt-004",
            event_type="MODEL_CALL",
            timestamp="2025-01-15T10:00:03Z",
            run_id=run_id,
            payload={
                "model": "claude-sonnet-4.5",
                "token_count": 2500,
                "cost": 0.0375,
            },
        ),
        Event(
            event_id="evt-005",
            event_type="TASK_COMPLETED",
            timestamp="2025-01-15T10:00:05Z",
            run_id=run_id,
            payload={
                "task_id": "task-plan-1",
                "phase": "PLANNING",
                "llm_provider": "anthropic",
                "tokens": 2500,
                "cost": 0.0375,
            },
        ),
        Event(
            event_id="evt-006",
            event_type="PHASE_COMPLETED",
            timestamp="2025-01-15T10:00:06Z",
            run_id=run_id,
            payload={"phase": "PLANNING"},
        ),
        # Build phase
        Event(
            event_id="evt-007",
            event_type="PHASE_STARTED",
            timestamp="2025-01-15T10:00:07Z",
            run_id=run_id,
            payload={"phase": "BUILD"},
        ),
        Event(
            event_id="evt-008",
            event_type="TASK_STARTED",
            timestamp="2025-01-15T10:00:08Z",
            run_id=run_id,
            payload={"task_id": "task-build-1", "phase": "BUILD"},
        ),
        Event(
            event_id="evt-009",
            event_type="MODEL_CALL",
            timestamp="2025-01-15T10:00:09Z",
            run_id=run_id,
            payload={
                "model": "gpt-4o",
                "token_count": 3200,
                "cost": 0.048,
            },
        ),
        Event(
            event_id="evt-010",
            event_type="TASK_COMPLETED",
            timestamp="2025-01-15T10:00:12Z",
            run_id=run_id,
            payload={
                "task_id": "task-build-1",
                "phase": "BUILD",
                "llm_provider": "openai",
                "tokens": 3200,
                "cost": 0.048,
            },
        ),
        Event(
            event_id="evt-011",
            event_type="PHASE_COMPLETED",
            timestamp="2025-01-15T10:00:13Z",
            run_id=run_id,
            payload={"phase": "BUILD"},
        ),
        # Test phase
        Event(
            event_id="evt-012",
            event_type="PHASE_STARTED",
            timestamp="2025-01-15T10:00:14Z",
            run_id=run_id,
            payload={"phase": "TEST"},
        ),
        Event(
            event_id="evt-013",
            event_type="EVAL_STARTED",
            timestamp="2025-01-15T10:00:15Z",
            run_id=run_id,
            payload={"suite_id": "integration-tests", "cases": 12},
        ),
        Event(
            event_id="evt-014",
            event_type="EVAL_COMPLETED",
            timestamp="2025-01-15T10:00:20Z",
            run_id=run_id,
            payload={"suite_id": "integration-tests", "passed": 12, "failed": 0},
        ),
        Event(
            event_id="evt-015",
            event_type="PHASE_COMPLETED",
            timestamp="2025-01-15T10:00:21Z",
            run_id=run_id,
            payload={"phase": "TEST"},
        ),
        Event(
            event_id="evt-016",
            event_type="RUN_COMPLETED",
            timestamp="2025-01-15T10:00:22Z",
            run_id=run_id,
            payload={"status": "success", "message": "All phases completed successfully"},
        ),
    ]

    spans = [
        Span(
            span_id="span-001",
            trace_id="trace-001",
            name="orchestration_run",
            start_time="2025-01-15T10:00:00Z",
            end_time="2025-01-15T10:00:22Z",
            status="ok",
            attributes={"run_id": run_id},
        ),
    ]

    write_events_ndjson(events, run_dir / "events.ndjson")
    write_spans_ndjson(spans, run_dir / "spans.ndjson")
    _write_manifest(run_dir, run_id, "2025-01-15T10:00:00Z")


def create_run_2(runs_dir: Path) -> None:
    """Create a failed run with errors."""
    run_id = "demo-failed-002"
    run_dir = runs_dir / f"evidence_pack_{run_id}"
    run_dir.mkdir(exist_ok=True)

    events = [
        Event(
            event_id="evt-001",
            event_type="RUN_STARTED",
            timestamp="2025-01-15T11:00:00Z",
            run_id=run_id,
            payload={"message": "Starting demo run (will fail)"},
        ),
        Event(
            event_id="evt-002",
            event_type="PHASE_STARTED",
            timestamp="2025-01-15T11:00:01Z",
            run_id=run_id,
            payload={"phase": "BUILD"},
        ),
        Event(
            event_id="evt-003",
            event_type="TASK_STARTED",
            timestamp="2025-01-15T11:00:02Z",
            run_id=run_id,
            payload={"task_id": "task-build-1", "phase": "BUILD"},
        ),
        Event(
            event_id="evt-004",
            event_type="MODEL_CALL",
            timestamp="2025-01-15T11:00:03Z",
            run_id=run_id,
            payload={
                "model": "claude-sonnet-4.5",
                "token_count": 1800,
                "cost": 0.027,
            },
        ),
        Event(
            event_id="evt-005",
            event_type="TASK_FAILED",
            timestamp="2025-01-15T11:00:05Z",
            run_id=run_id,
            payload={
                "task_id": "task-build-1",
                "phase": "BUILD",
                "llm_provider": "anthropic",
                "tokens": 1800,
                "cost": 0.027,
                "error": "Syntax error in generated code",
            },
        ),
        Event(
            event_id="evt-006",
            event_type="CIRCUIT_BREAKER_TRIPPED",
            timestamp="2025-01-15T11:00:06Z",
            run_id=run_id,
            payload={"reason": "Task failure threshold exceeded"},
        ),
    ]

    spans = [
        Span(
            span_id="span-001",
            trace_id="trace-002",
            name="orchestration_run",
            start_time="2025-01-15T11:00:00Z",
            end_time="2025-01-15T11:00:06Z",
            status="error",
            attributes={"run_id": run_id},
        ),
    ]

    write_events_ndjson(events, run_dir / "events.ndjson")
    write_spans_ndjson(spans, run_dir / "spans.ndjson")
    _write_manifest(run_dir, run_id, "2025-01-15T11:00:00Z")


def create_run_3(runs_dir: Path) -> None:
    """Create a running (incomplete) run."""
    run_id = "demo-running-003"
    run_dir = runs_dir / f"evidence_pack_{run_id}"
    run_dir.mkdir(exist_ok=True)

    events = [
        Event(
            event_id="evt-001",
            event_type="RUN_STARTED",
            timestamp="2025-01-15T12:00:00Z",
            run_id=run_id,
            payload={"message": "Starting demo run (in progress)"},
        ),
        Event(
            event_id="evt-002",
            event_type="PHASE_STARTED",
            timestamp="2025-01-15T12:00:01Z",
            run_id=run_id,
            payload={"phase": "PLANNING"},
        ),
        Event(
            event_id="evt-003",
            event_type="MODEL_CALL",
            timestamp="2025-01-15T12:00:02Z",
            run_id=run_id,
            payload={
                "model": "claude-sonnet-4.5",
                "token_count": 1500,
                "cost": 0.0225,
            },
        ),
    ]

    spans = [
        Span(
            span_id="span-001",
            trace_id="trace-003",
            name="orchestration_run",
            start_time="2025-01-15T12:00:00Z",
            end_time="2025-01-15T12:00:02Z",
            status="ok",
            attributes={"run_id": run_id},
        ),
    ]

    write_events_ndjson(events, run_dir / "events.ndjson")
    write_spans_ndjson(spans, run_dir / "spans.ndjson")
    _write_manifest(run_dir, run_id, "2025-01-15T12:00:00Z")


def _write_manifest(run_dir: Path, run_id: str, created_at: str) -> None:
    """Write a manifest.json file."""
    manifest = {
        "schema_version": "tier2-pack-manifest/1.0",
        "run_id": run_id,
        "created_at": created_at,
        "components": {
            "events": "events.ndjson",
            "spans": "spans.ndjson",
        },
    }
    with open(run_dir / "manifest.json", "w") as f:
        json.dump(manifest, f, indent=2, sort_keys=True)
        f.write("\n")


def main() -> None:
    """Main entry point."""
    print("=== ABI Observability Dashboard Demo ===\n")

    # Create sample data
    create_sample_runs()

    # Launch the dashboard
    print("\nStarting dashboard server...")
    port = 8080

    # Try to open the browser after a short delay
    def open_browser():
        sleep(1.5)
        url = f"http://localhost:{port}"
        print(f"\nOpening dashboard at {url}")
        try:
            webbrowser.open(url)
        except Exception:
            print(f"  (Could not auto-open browser. Please visit {url} manually)")

    import threading

    threading.Thread(target=open_browser, daemon=True).start()

    # Start the server
    server = DashboardServer(port=port)
    server.start()


if __name__ == "__main__":
    main()
