#!/usr/bin/env python3
"""Basic demo of abi-observability."""
from __future__ import annotations

import json
import sys
import tempfile
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent.parent / "src"))

from abi_observability.exporters import build_json_summary, build_timeline_md
from abi_observability.models import Event, Span
from abi_observability.redaction import classify_events, redact_event
from abi_observability.writers import write_events_ndjson, write_spans_ndjson


def main() -> None:
    print("=== abi-observability Basic Demo ===\n")

    events = [
        Event(
            event_id="evt-001", event_type="RUN_STARTED",
            timestamp="2025-01-01T00:00:00Z", run_id="demo0001",
            payload={"message": "Demo started"},
        ),
        Event(
            event_id="evt-002", event_type="MODEL_CALL",
            timestamp="2025-01-01T00:00:01Z", run_id="demo0001",
            payload={"model": "claude-sonnet", "api_key": "sk-secret-key"},
        ),
        Event(
            event_id="evt-003", event_type="RUN_COMPLETED",
            timestamp="2025-01-01T00:00:02Z", run_id="demo0001",
            payload={"status": "success"},
        ),
    ]

    spans = [
        Span(
            span_id="span-001", trace_id="trace-001", name="demo_run",
            start_time="2025-01-01T00:00:00Z", end_time="2025-01-01T00:00:02Z",
        ),
    ]

    # Redact sensitive data
    print("--- Redaction ---")
    for e in events:
        redacted = redact_event(e)
        if e.payload != redacted.payload:
            print(f"  {e.event_type}: api_key redacted")

    # Classify events
    print("\n--- Classification ---")
    classified = classify_events(events)
    for cat, evts in sorted(classified.items()):
        if evts:
            print(f"  {cat}: {len(evts)} event(s)")

    # Write NDJSON
    with tempfile.TemporaryDirectory() as tmp:
        tmp_path = Path(tmp)
        redacted_events = [redact_event(e) for e in events]
        write_events_ndjson(redacted_events, tmp_path / "events.ndjson")
        write_spans_ndjson(spans, tmp_path / "spans.ndjson")
        print(f"\n--- Written to {tmp_path} ---")

        # Build timeline
        timeline = build_timeline_md(redacted_events, spans)
        print("\n--- Timeline ---")
        print(timeline)

        # Build summary
        summary = build_json_summary(redacted_events, spans)
        print("--- Summary ---")
        print(json.dumps(summary, indent=2, sort_keys=True))

    print("\nDemo complete.")


if __name__ == "__main__":
    main()
