#!/usr/bin/env python3
"""Cross-repo integration demo for abi-observability.

Simulates a mock orchestration step:
1. Creates a synthetic PlanGraph
2. Emits events for policy decisions, tool calls, and eval results
3. Writes spans for the execution timeline
4. Redacts sensitive data from events
5. Exports timeline.md and summary.json
6. Outputs a small evidence-pack-like folder

Runs entirely offline. Does not require other abi-* repos to be installed.
"""
from __future__ import annotations

import json
import sys
import tempfile
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent.parent / "src"))

from abi_observability.exporters import build_json_summary, build_timeline_md
from abi_observability.models import Event, Span
from abi_observability.redaction import classify_events, redact_event
from abi_observability.writers import write_events_ndjson, write_spans_ndjson

FIXED_TS = "2025-01-01T00:00:00Z"
RUN_ID = "e2e00001"


def make_synthetic_plan_graph() -> dict:
    """Create a small synthetic PlanGraph (plan-graph/1.0 compatible)."""
    return {
        "schema_version": "plan-graph/1.0",
        "run_id": RUN_ID,
        "description": "Demo plan graph for observability pipeline",
        "nodes": [
            {
                "node_id": "step-1",
                "name": "Policy evaluation",
                "depends_on": [],
                "status": "completed",
                "agent": "policy-engine",
                "metadata": {"node_type": "GATE_CHECK"},
            },
            {
                "node_id": "step-2",
                "name": "Tool execution",
                "depends_on": ["step-1"],
                "status": "completed",
                "agent": "builder",
                "metadata": {"node_type": "TOOL_CALL", "tool": "read_file"},
            },
            {
                "node_id": "step-3",
                "name": "Model invocation",
                "depends_on": ["step-2"],
                "status": "completed",
                "agent": "builder",
                "metadata": {"node_type": "AGENT_TASK", "model": "claude-sonnet"},
            },
            {
                "node_id": "step-4",
                "name": "Eval run",
                "depends_on": ["step-3"],
                "status": "completed",
                "agent": "evaluator",
                "metadata": {"node_type": "EVAL_RUN"},
            },
        ],
    }


def make_orchestration_events() -> list[Event]:
    """Create events from a simulated orchestration run across all ABI components."""
    return [
        # System events
        Event(
            event_id="evt-001", event_type="RUN_STARTED",
            timestamp="2025-01-01T00:00:00Z", run_id=RUN_ID,
            payload={"message": "Orchestration run started"},
        ),
        Event(
            event_id="evt-002", event_type="PHASE_STARTED",
            timestamp="2025-01-01T00:00:01Z", run_id=RUN_ID,
            payload={"phase": "PLAN", "node_count": 4},
        ),
        # Policy events (abi-policy)
        Event(
            event_id="evt-003", event_type="POLICY_DECISION",
            timestamp="2025-01-01T00:00:02Z", run_id=RUN_ID,
            payload={"decision": "allow", "tool": "read_file", "policy": "default"},
        ),
        Event(
            event_id="evt-004", event_type="POLICY_DECISION",
            timestamp="2025-01-01T00:00:03Z", run_id=RUN_ID,
            payload={"decision": "deny", "tool": "shell_exec", "policy": "default"},
        ),
        # Tool events (abi-runtime)
        Event(
            event_id="evt-005", event_type="TOOL_INVOKED",
            timestamp="2025-01-01T00:00:04Z", run_id=RUN_ID,
            payload={"tool": "read_file", "path": "src/main.py"},
        ),
        Event(
            event_id="evt-006", event_type="TOOL_COMPLETED",
            timestamp="2025-01-01T00:00:05Z", run_id=RUN_ID,
            payload={"tool": "read_file", "bytes_read": 256},
        ),
        # Model events (abi-runtime provider)
        Event(
            event_id="evt-007", event_type="MODEL_CALL",
            timestamp="2025-01-01T00:00:06Z", run_id=RUN_ID,
            payload={
                "model": "claude-sonnet",
                "token_count": 1500,
                "api_key": "sk-secret-key-12345",  # Should be redacted!
            },
        ),
        Event(
            event_id="evt-008", event_type="MODEL_RESPONSE",
            timestamp="2025-01-01T00:00:07Z", run_id=RUN_ID,
            payload={"model": "claude-sonnet", "output_tokens": 500},
        ),
        # File events
        Event(
            event_id="evt-009", event_type="FILE_WRITE",
            timestamp="2025-01-01T00:00:08Z", run_id=RUN_ID,
            payload={"path": "output/analysis.txt", "bytes": 512},
        ),
        Event(
            event_id="evt-010", event_type="ARTIFACT_CREATED",
            timestamp="2025-01-01T00:00:09Z", run_id=RUN_ID,
            payload={"artifact_id": "sha256:abc123", "type": "analysis"},
        ),
        # Eval events (abi-evals)
        Event(
            event_id="evt-011", event_type="EVAL_STARTED",
            timestamp="2025-01-01T00:00:10Z", run_id=RUN_ID,
            payload={"suite_id": "cross-repo-e2e", "cases": 5},
        ),
        Event(
            event_id="evt-012", event_type="EVAL_COMPLETED",
            timestamp="2025-01-01T00:00:11Z", run_id=RUN_ID,
            payload={"suite_id": "cross-repo-e2e", "passed": 5, "failed": 0},
        ),
        # Completion
        Event(
            event_id="evt-013", event_type="RUN_COMPLETED",
            timestamp="2025-01-01T00:00:12Z", run_id=RUN_ID,
            payload={"status": "success", "message": "All steps completed"},
        ),
    ]


def make_orchestration_spans() -> list[Span]:
    """Create spans from the simulated orchestration run."""
    return [
        Span(
            span_id="span-001", trace_id="trace-001",
            name="orchestration_run",
            start_time="2025-01-01T00:00:00Z",
            end_time="2025-01-01T00:00:12Z",
            status="ok",
            attributes={"run_id": RUN_ID, "total_nodes": 4},
        ),
        Span(
            span_id="span-002", trace_id="trace-001",
            name="policy_evaluation",
            start_time="2025-01-01T00:00:02Z",
            end_time="2025-01-01T00:00:03Z",
            status="ok",
            parent_span_id="span-001",
            attributes={"bundle": "default", "decisions": 2},
        ),
        Span(
            span_id="span-003", trace_id="trace-001",
            name="tool_execution",
            start_time="2025-01-01T00:00:04Z",
            end_time="2025-01-01T00:00:05Z",
            status="ok",
            parent_span_id="span-001",
            attributes={"tool": "read_file"},
        ),
        Span(
            span_id="span-004", trace_id="trace-001",
            name="model_invocation",
            start_time="2025-01-01T00:00:06Z",
            end_time="2025-01-01T00:00:07Z",
            status="ok",
            parent_span_id="span-001",
            attributes={"model": "claude-sonnet"},
        ),
        Span(
            span_id="span-005", trace_id="trace-001",
            name="eval_run",
            start_time="2025-01-01T00:00:10Z",
            end_time="2025-01-01T00:00:11Z",
            status="ok",
            parent_span_id="span-001",
            attributes={"suite_id": "cross-repo-e2e"},
        ),
    ]


def main() -> None:
    print("=== abi-observability Cross-Repo Integration Demo ===\n")

    # 1. Create PlanGraph
    print("--- Step 1: Create PlanGraph ---")
    plan_graph = make_synthetic_plan_graph()
    print(f"  Nodes: {len(plan_graph['nodes'])}")

    # 2. Generate events and spans
    print("\n--- Step 2: Generate Events & Spans ---")
    events = make_orchestration_events()
    spans = make_orchestration_spans()
    print(f"  Events: {len(events)}")
    print(f"  Spans: {len(spans)}")

    # 3. Redact sensitive data
    print("\n--- Step 3: Redact Sensitive Data ---")
    redacted_events = [redact_event(e) for e in events]
    for orig, red in zip(events, redacted_events, strict=True):
        if orig.payload != red.payload:
            print(f"  {orig.event_type}: sensitive data redacted")

    # 4. Classify events
    print("\n--- Step 4: Classify Events ---")
    classified = classify_events(redacted_events)
    for cat, evts in sorted(classified.items()):
        if evts:
            print(f"  {cat}: {len(evts)} event(s)")

    # 5. Write evidence-pack-like folder
    with tempfile.TemporaryDirectory() as tmp:
        pack_dir = Path(tmp) / f"evidence_pack_{RUN_ID}"
        pack_dir.mkdir(parents=True)

        print("\n--- Step 5: Write Evidence Pack ---")

        # plan_graph.json
        with open(pack_dir / "plan_graph.json", "w") as f:
            json.dump(plan_graph, f, indent=2, sort_keys=True)
            f.write("\n")
        print("  plan_graph.json")

        # events.ndjson (redacted)
        n_events = write_events_ndjson(redacted_events, pack_dir / "events.ndjson")
        print(f"  events.ndjson ({n_events} events)")

        # spans.ndjson
        n_spans = write_spans_ndjson(spans, pack_dir / "spans.ndjson")
        print(f"  spans.ndjson ({n_spans} spans)")

        # policy_decisions.ndjson (extracted from policy events)
        policy_events = classified.get("policy", [])
        with open(pack_dir / "policy_decisions.ndjson", "w") as f:
            for pe in policy_events:
                decision_record = {
                    "schema_version": "tier2-policy-decision/1.0",
                    "run_id": pe.run_id,
                    "policy_id": pe.payload.get("policy", "default"),
                    "decision": pe.payload.get("decision", "allow"),
                    "decided_at": pe.timestamp,
                    "reason": f"Tool: {pe.payload.get('tool', 'unknown')}",
                    "context": pe.payload,
                }
                f.write(json.dumps(decision_record, sort_keys=True) + "\n")
        print(f"  policy_decisions.ndjson ({len(policy_events)} decisions)")

        # timeline.md
        timeline = build_timeline_md(redacted_events, spans)
        (pack_dir / "timeline.md").write_text(timeline)
        print("  timeline.md")

        # summary.json
        summary = build_json_summary(redacted_events, spans)
        with open(pack_dir / "summary.json", "w") as f:
            json.dump(summary, f, indent=2, sort_keys=True)
            f.write("\n")
        print("  summary.json")

        # manifest.json
        manifest = {
            "schema_version": "tier2-pack-manifest/1.0",
            "run_id": RUN_ID,
            "created_at": FIXED_TS,
            "components": {
                "plan_graph": "plan_graph.json",
                "events": "events.ndjson",
                "spans": "spans.ndjson",
                "policy_decisions": "policy_decisions.ndjson",
                "timeline": "timeline.md",
                "summary": "summary.json",
            },
            "summary": {"total_files": 6, "total_artifacts": 0},
        }
        with open(pack_dir / "manifest.json", "w") as f:
            json.dump(manifest, f, indent=2, sort_keys=True)
            f.write("\n")
        print("  manifest.json")

        # 6. Verify determinism
        print("\n--- Step 6: Verify Determinism ---")
        events2 = make_orchestration_events()
        redacted2 = [redact_event(e) for e in events2]
        timeline2 = build_timeline_md(redacted2, make_orchestration_spans())
        assert timeline == timeline2, "Timeline is not deterministic!"
        print("  Timeline: deterministic (verified)")

        summary2 = build_json_summary(redacted2, make_orchestration_spans())
        assert json.dumps(summary, sort_keys=True) == json.dumps(summary2, sort_keys=True)
        print("  Summary: deterministic (verified)")

        print("\n--- Evidence Pack Contents ---")
        for item in sorted(pack_dir.iterdir()):
            print(f"  {item.name} ({item.stat().st_size} bytes)")

    print("\nCross-repo integration demo complete.")


if __name__ == "__main__":
    main()
