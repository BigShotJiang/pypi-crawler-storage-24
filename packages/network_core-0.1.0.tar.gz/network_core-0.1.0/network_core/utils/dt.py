import datetime, pytz


def convertUNIXToDT(timestamp: float, timezone="Australia/Sydney") -> datetime.datetime:
    australian_timezone = pytz.timezone(timezone)
    utc_dt = datetime.datetime.fromtimestamp(timestamp, tz=pytz.utc)
    return utc_dt.astimezone(australian_timezone)


def convertUNIXToHumanReadable(timestamp: float, timezone="Australia/Sydney") -> str:
    dt = convertUNIXToDT(timestamp=timestamp, timezone=timezone)
    ms = dt.microsecond // 1000  # get milliseconds, doing this so it isn't 0
    return dt.strftime("%Y-%m-%d %H:%M:%S") + f".{ms}"


def getDatetimeFromTime(time: datetime.time) -> datetime.datetime:
    return datetime.datetime.combine(datetime.datetime.today(), time=time)


def addBufferToTime(time: datetime.time, buffer_in_seconds: float) -> datetime.time:
    delta = datetime.timedelta(seconds=buffer_in_seconds)
    return (getDatetimeFromTime(time=time) + delta).time()


def fast_strptime(s: str) -> float:
    """
    2026-01-11 12:25:31.689768 +0530 IST to UNIX
    """
    parts = s.split()

    # Drop trailing timezone name (like 'UTC', 'AEDT', etc.)
    if len(parts) > 3:
        s = " ".join(parts[:3])
    else:
        s = " ".join(parts)

    # Handle too many fractional digits (datetime only supports microseconds)
    date, time_str, offset = s.split()
    if "." in time_str:
        main, frac = time_str.split(".")
        frac = frac[:6]  # truncate nanoseconds to microseconds
        time_str = f"{main}.{frac}"
    s = f"{date} {time_str} {offset}"

    fmt = "%Y-%m-%d %H:%M:%S.%f %z" if "." in time_str else "%Y-%m-%d %H:%M:%S %z"

    return datetime.datetime.strptime(s, fmt).timestamp()
