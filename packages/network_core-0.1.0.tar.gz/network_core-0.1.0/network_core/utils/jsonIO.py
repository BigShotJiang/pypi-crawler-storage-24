import datetime
import json
from typing import Union, List, Dict, Iterator

import orjson
import numpy as np


def numpy_to_lists(obj):
    """
    Recursively convert NumPy arrays (and NumPy scalars) back to Python lists/int/float.
    """
    if isinstance(obj, np.ndarray):
        # Convert array to nested list
        return [numpy_to_lists(x) for x in obj]
    elif isinstance(obj, (np.integer, np.floating)):
        # Convert NumPy scalar to Python scalar
        return obj.item()
    elif isinstance(obj, dict):
        return {k: numpy_to_lists(v) for k, v in obj.items()}
    elif isinstance(obj, list):
        # Already a list, convert its elements recursively
        return [numpy_to_lists(x) for x in obj]
    else:
        return obj


class JSONCustomEncoder(json.JSONEncoder):
    """
    Custom JSON encoder that recursively converts NumPy arrays and scalars
    to lists and native Python types.
    """

    def default(self, obj):
        # Use your recursive conversion
        obj_converted = numpy_to_lists(obj)
        # After conversion, let the base class handle normal types
        return super().default(obj_converted)


def lists_to_numpy(obj: dict | list):
    if isinstance(obj, list):
        return np.array([lists_to_numpy(x) for x in obj])
    elif isinstance(obj, dict):
        return {k: lists_to_numpy(v) for k, v in obj.items()}
    else:
        return obj


class JSONCustomDecoder(json.JSONDecoder):
    """
    Custom JSON decoder to convert lists back into NumPy arrays.
    """

    def __init__(self, *args, **kwargs):
        # Use object_hook to intercept all dicts/lists during decoding
        super().__init__(object_hook=self.object_hook, *args, **kwargs)

    def object_hook(self, obj):
        return lists_to_numpy(obj)


def saveDctAsJSON(path: str, data: Union[Dict, List[Dict]], append: bool = False):
    """
    Save a dict or list of dicts as JSON.

    ALWAYS SAVES AT A LINE SEPERATED JSON

    - Dict: saved as a single pretty-printed JSON object.
    - List[Dict]: line-delimited JSON.
    """
    mode = "a" if append else "w"
    with open(path, mode) as f:
        if isinstance(data, dict):
            json.dump(data, f, separators=(",", ":"), cls=JSONCustomEncoder)
            f.write("\n")
        elif isinstance(data, list):
            # Write each item as a line-delimited JSON object
            for item in data:
                json.dump(item, f)
                f.write("\n")


def loadJSONAsDct(
    path: str, use_custom_decoder: bool = False
) -> Union[Dict, List[Dict]]:
    """
    Load JSON from a file. Handles:
    - Single dict (pretty-printed or one-line)
    - List of dicts (array or line-delimited)
    """

    with open(path, "r") as f:
        text = f.read().strip()
        if not text:
            return {}  # empty file
        try:
            return json.loads(text)  # dict or list saved as JSON array
        except json.JSONDecodeError:
            # fallback: line-delimited JSON
            result = []
            with open(path, "r") as f2:
                for line in f2:
                    line = line.strip()
                    if line:
                        result.append(
                            json.loads(
                                line,
                                cls=JSONCustomDecoder if use_custom_decoder else None,
                            )
                        )
            return result


def loadJsonLines(path: str, np_convert: bool = False) -> Iterator[dict]:
    with open(path, "rb") as f:  # orjson expects bytes
        for line in f:
            line = line.strip()
            if line:
                yield (
                    orjson.loads(line)
                    if not np_convert
                    else lists_to_numpy(orjson.loads(line))
                )  # type: ignore
