import csv
from typing import Iterator


def read_csv_to_dicts(file_path) -> Iterator[dict]:
    with open(file_path, newline="") as f:
        reader = csv.DictReader(f)
        for row in reader:
            yield row
