# Define PacketInfo class
from typing import List
from .dataModels import PacketType, TransPortType, PacketInfo, FiveTuple
from scapy.all import UDP, TCP, IP, IPv6  # type: ignore


def getPacketType(packet):
    """
    Here packet is a scapy packet
    """
    if TCP in packet:
        return PacketType.TCP
    elif UDP in packet:
        return PacketType.UDP
    return PacketType.UNKNOWN


def getPacketInfoFromPacket(packet, direction: int):
    packet_type = getPacketType(packet)

    payload_bytes = b""
    if UDP in packet:
        payload_bytes = bytes(packet[UDP].payload)
    elif TCP in packet:
        payload_bytes = bytes(packet[TCP].payload)

    return PacketInfo(
        length=len(packet),
        timestamp=float(packet.time),
        direction=direction,
        packet_type=packet_type,
        transport_payload=payload_bytes,
        other_info=(
            {"seq": packet[TCP].seq} if packet_type == PacketType.TCP else dict()
        ),
    )


class Connection:
    def __init__(
        self,
        five_tuple: FiveTuple,
        other_info=None,
    ):
        self.five_tuple = five_tuple
        self.connection_type: set[PacketType] = set()
        self.packet_stream: List[PacketInfo] = []
        self.other_info = other_info
        self.__sni = None
        self.is_quic = False

    @staticmethod
    def getTransPortType(packet):
        if TCP in packet:
            return TransPortType.TCP
        elif UDP in packet:
            return TransPortType.UDP
        return TransPortType.UNKNOWN

    @staticmethod
    def getConnFromPacket(packet):
        transport_type = Connection.getTransPortType(packet)

        packet_type = getPacketType(packet)
        if packet_type == PacketType.UNKNOWN:
            return None
        ip_layer = IP if IP in packet else IPv6

        if transport_type == TransPortType.TCP:
            ft = FiveTuple(
                src_ip=packet[ip_layer].src,
                dst_ip=packet[ip_layer].dst,
                src_port=packet[TCP].sport,
                dst_port=packet[TCP].dport,
                transport_type=transport_type,
            )
            return Connection(five_tuple=ft)
        elif transport_type == TransPortType.UDP:
            ft = FiveTuple(
                src_ip=packet[ip_layer].src,
                dst_ip=packet[ip_layer].dst,
                src_port=packet[UDP].sport,
                dst_port=packet[UDP].dport,
                transport_type=transport_type,
            )
            return Connection(five_tuple=ft)
        return None

    def addPacket(self, packet: PacketInfo):
        if packet.packet_type == PacketType.UNKNOWN:
            assert False, "Packet Type is Unknown"
        self.connection_type.add(packet.packet_type)
        self.packet_stream.append(packet)

    def __len__(self):
        return len(self.packet_stream)

    def setSNI(self, sni: str):
        self.__sni = sni

    def getSNI(self):
        return self.__sni

    def getPacketsOfTypes(self, packet_types: set[PacketType]) -> List[PacketInfo]:
        return list(filter(lambda x: x.packet_type in packet_types, self.packet_stream))

    def getRemovedPacketsOfTypes(self, packet_types: set[PacketType]):
        return list(
            filter(lambda x: x.packet_type not in packet_types, self.packet_stream)
        )

    def getPacketsOfDirection(self, direction: int) -> list[PacketInfo]:
        return [p for p in self.packet_stream if p.direction == direction]

    def getSubConnection(self, packet_types: List[PacketType]):
        packets = self.getPacketsOfTypes(packet_types=set(packet_types))

        new_conn = Connection(five_tuple=self.five_tuple)
        for packet in packets:
            new_conn.addPacket(packet=packet)
        return new_conn

    def getDuration(self):
        """
        Returns the duration of connection on seconds
        """
        if len(self.packet_stream) == 0:
            return 0

        return self.packet_stream[-1].timestamp - self.packet_stream[0].timestamp

    def sort(self):
        self.packet_stream.sort(key=lambda x: x.timestamp)

    def pps(self):
        num_packets = len(self.packet_stream)
        duration = self.getDuration()
        if num_packets == 0 or duration == 0:
            return 0

        return num_packets / duration

    def removePayload(self):
        """
        This is an irreversable operation, removes packets inplace
        """
        for packet in self.packet_stream:
            packet.transport_payload = bytes()

    @property
    def down_bytes(self):
        total = 0
        for p in self.packet_stream:
            if p.direction == 1:
                total += p.length
        return total

    @property
    def up_bytes(self):
        total = 0
        for p in self.packet_stream:
            if p.direction == 0:
                total += p.length
        return total

    @property
    def down_packets(self):
        total = 0
        for p in self.packet_stream:
            if p.direction == 1:
                total += 1
        return total

    @property
    def up_packets(self):
        total = 0
        for p in self.packet_stream:
            if p.direction == 0:
                total += 1
        return total

    @property
    def start_timestamp(self):
        return self.packet_stream[0].timestamp

    @property
    def end_timestamp(self):
        return self.packet_stream[-1].timestamp
