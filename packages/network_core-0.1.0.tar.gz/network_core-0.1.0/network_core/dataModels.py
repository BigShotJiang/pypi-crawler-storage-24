from enum import Enum
from dataclasses import dataclass, field


class PacketType(Enum):
    TLS = 0
    DTLS = 1
    RTP = 2
    RTCP = 3
    STUN = 4
    TURN = 5
    QUIC = 6

    TCP = 7
    UDP = 8
    UNKNOWN = 9


class TransPortType(Enum):
    TCP = 0
    UDP = 1
    UNKNOWN = 2


@dataclass
class FiveTuple:
    src_ip: str
    dst_ip: str
    src_port: int
    dst_port: int
    transport_type: TransPortType

    def _get_key(self):
        return (
            self.src_ip,
            self.dst_ip,
            self.src_port,
            self.dst_port,
            self.transport_type.name,
        )

    def __hash__(self) -> int:
        return hash(self._get_key())

    def rev_ft(self) -> "FiveTuple":
        return FiveTuple(
            src_ip=self.dst_ip,
            src_port=self.dst_port,
            dst_ip=self.src_ip,
            dst_port=self.src_port,
            transport_type=self.transport_type,
        )


@dataclass
class PacketInfo:
    length: int
    timestamp: float
    direction: int
    packet_type: PacketType
    transport_payload: bytes = field(default_factory=bytes)
    other_info: dict = field(default_factory=dict)
