from .conn import Connection
from .dataModels import PacketInfo, PacketType, FiveTuple
from .utils.dt import convertUNIXToHumanReadable

import numpy as np


class ConnStats:
    def __init__(self, conn: Connection):
        self.conn = conn

    def getUpStreamBytes(self):
        packet_stream = self.conn.packet_stream

        up_stream_bytes = 0
        for packet in packet_stream:
            if packet.direction == 0:
                up_stream_bytes += packet.length
        return up_stream_bytes

    def getDownStreamBytes(self):
        packet_stream = self.conn.packet_stream

        down_stream_bytes = 0
        for packet in packet_stream:
            if packet.direction == 1:
                down_stream_bytes += packet.length
        return down_stream_bytes

    def getConnSpan(self):
        packet_stream = self.conn.packet_stream
        return packet_stream[-1].timestamp - packet_stream[0].timestamp

    def getPacketTypeCounts(self):
        packet_stream = self.conn.packet_stream
        packet_type_counts = dict()
        for packet in packet_stream:
            packet_type_counts[packet.packet_type] = 1 + packet_type_counts.get(
                packet.packet_type, 0
            )
        return packet_type_counts

    def getStartTime(self):
        return convertUNIXToHumanReadable(self.conn.packet_stream[0].timestamp)

    def getEndTime(self):
        return convertUNIXToHumanReadable(self.conn.packet_stream[-1].timestamp)


def filterConnections(
    connections: list[Connection],
    connection_types: list[PacketType],
    min_packets: int | None = None,
    min_duration_in_seconds: float | None = None,
):
    """
    filter connections by connection types, the connection must have atleast one packet of the types in the connection_types
    :param connections: List of connections to filter
    :param connection_types: List of connection types to filter by
    :return: Filtered connections
    """

    def doesContainConnectionTypes(
        connection: Connection, connection_types: list[PacketType]
    ):
        for connection_type in connection_types:
            if connection_type not in connection.connection_type:
                return False
        return True

    f_connections = [
        connection
        for connection in connections
        if doesContainConnectionTypes(connection, connection_types)
    ]

    if min_packets is not None:
        f_connections = [
            connection for connection in f_connections if len(connection) >= min_packets
        ]
    if min_duration_in_seconds is not None:
        f_connections = [
            connection
            for connection in f_connections
            if ConnStats(connection).getConnSpan() >= min_duration_in_seconds
        ]
    return f_connections


def combine_connections(connections: list[Connection], enforce_transport=False):
    """
    Combine connections with the same src_ip, src_port, dst_ip, dst_port and transport_type in the end. The first connection's ip and port will be used
    :param connections: List of connections to combine
    :param enforce_transport: If True, enforce that all connections have the same transport_type
    :return: Combined connection sorted by timestamp
    """
    if len(connections) == 0:
        return None
    if len(connections) == 1:
        return connections[0]

    combined_connection = Connection(
        five_tuple=connections[0].five_tuple,
    )
    for connection in connections:
        if len(connection) == 0:
            continue
        if enforce_transport:
            assert (
                connection.five_tuple.transport_type
                == combined_connection.five_tuple.transport_type
            ), f"{connection.five_tuple.transport_type}, {combined_connection.five_tuple.transport_type}, {len(connection)}"
        for packet in connection.packet_stream:
            combined_connection.addPacket(packet)
    # important to sort it in order of timestamp
    combined_connection.packet_stream = sorted(
        combined_connection.packet_stream, key=lambda x: x.timestamp
    )
    return combined_connection


def printConns(connections: list[Connection]):
    """
    Utility to print connections
    """

    def splitTimeString(time_str):
        return time_str.split(" ")[1]

    for conn in connections:
        stat = ConnStats(conn)
        print(
            conn.five_tuple,
            f"SNI {conn.getSNI()}",
            f"Start time {splitTimeString(stat.getStartTime())}",
            f"End Time {splitTimeString(stat.getEndTime())}",
            f"Duration {stat.getConnSpan()}",
            f"Upstream Bytes {stat.getUpStreamBytes()}",
            f"Downstream Bytes {stat.getDownStreamBytes()}",
            conn.connection_type,
            f"Num Packets {len(conn)}",
        )


def getPacketsInInterval(
    packet_stream: list[PacketInfo],
    start_time_timestamp: float,
    end_timestamp: float,
) -> list[PacketInfo]:
    """
    packet_stream is assumed to be sorted, by timestamp
    Also, ideally packet_stream should contain packets from the same direction.

    Returns packets from  with timestamp larger or equal to start_timestamp and just smaller than end_timestamp
    It then becomes the function user's responsibility to validate if there are enough packets in the interval.
    """

    def bSearch(time: float):
        start_index = 0
        end_index = len(packet_stream) - 1
        just_left_of_time, just_right_or_equal_of_time = None, None
        while start_index <= end_index:
            mid_index = (start_index + end_index) // 2
            mid_timestamp = packet_stream[mid_index].timestamp
            if mid_timestamp >= time:
                just_right_or_equal_of_time = mid_index
                end_index = mid_index - 1
            elif mid_timestamp < time:
                just_left_of_time = mid_index
                start_index = mid_index + 1

        return just_left_of_time, just_right_or_equal_of_time

    _, left = bSearch(time=start_time_timestamp)
    right, _ = bSearch(time=end_timestamp)

    if (left is None or right is None) or left > right:
        return []

    return packet_stream[left : right + 1]


def normalizePacketStream(packet_stream: list[PacketInfo]) -> dict:
    def normIAT(iat: np.ndarray, limit=200) -> np.ndarray:
        """
        iats are in miliseconds
        """
        iat = np.clip(iat, 0, limit)  # Same as capping
        return np.log1p(iat) / np.log1p(limit)

    sizes = np.array([p.length for p in packet_stream])
    times = np.array([p.timestamp * 100 for p in packet_stream])
    iats = np.diff(times) if len(times) > 1 else np.array([])

    return {
        "mean_size": sizes.mean(),
        "std_size": sizes.std(),
        "burstiness": (sizes.max() - sizes.min()) / (sizes.mean() + 1e-5),
        "mean_iat": iats.mean(),
        "std_iat": iats.std(),
        "packet_count": len(sizes),
        "unique_sizes": len(set(sizes)),
        "lengths": (sizes / 1500).tolist(),
        "iats": [0] + normIAT(iats).tolist(),
        "timestamps": [p.timestamp for p in packet_stream],
    }
