"""Robot Resources - AI Execution Intelligence Layer."""

__version__ = "2.1.2"
