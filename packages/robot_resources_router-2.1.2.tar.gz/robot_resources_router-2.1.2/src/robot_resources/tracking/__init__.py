"""Outcome tracking module.

Provides SQLite-backed persistence for routing decisions,
enabling cost savings analysis and routing quality monitoring.
"""

from robot_resources.tracking.calculator import CostCalculator, CostResult
from robot_resources.tracking.db import OutcomeDB
from robot_resources.tracking.models import OutcomeRecord, OutcomeSummary
from robot_resources.tracking.recorder import OutcomeRecorder
from robot_resources.tracking.reports import ReportData, build_report
from robot_resources.tracking.telemetry import TelemetryReporter, get_telemetry_reporter

__all__ = [
    "CostCalculator",
    "CostResult",
    "OutcomeDB",
    "OutcomeRecord",
    "OutcomeRecorder",
    "OutcomeSummary",
    "ReportData",
    "TelemetryReporter",
    "build_report",
    "get_telemetry_reporter",
]
