"""Routing engine module.

Provides intelligent model selection based on task detection
and cost optimization.
"""

from robot_resources.routing.classifier import ClassificationResult, classify_with_llm
from robot_resources.routing.decision_log import DecisionLog, RoutingDecision
from robot_resources.routing.router import async_route_prompt, route_prompt
from robot_resources.routing.selector import (
    CAPABILITY_THRESHOLD,
    MODELS_DB,
    calculate_savings,
    get_capable_models,
    rank_capable_models,
    select_cheapest_model,
)
from robot_resources.routing.task_detection import (
    TaskType,
    analyze_prompt,
    detect_task_type,
)

__all__ = [
    # Task detection
    "detect_task_type",
    "analyze_prompt",
    "TaskType",
    # Model selection
    "get_capable_models",
    "select_cheapest_model",
    "rank_capable_models",
    "calculate_savings",
    "MODELS_DB",
    "CAPABILITY_THRESHOLD",
    # Router
    "route_prompt",
    "async_route_prompt",
    # Classifier
    "classify_with_llm",
    "ClassificationResult",
    # Decision Log
    "DecisionLog",
    "RoutingDecision",
]
