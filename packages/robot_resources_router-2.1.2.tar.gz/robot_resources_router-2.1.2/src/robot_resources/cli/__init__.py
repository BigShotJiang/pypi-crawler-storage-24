"""CLI module for Robot Resources."""
