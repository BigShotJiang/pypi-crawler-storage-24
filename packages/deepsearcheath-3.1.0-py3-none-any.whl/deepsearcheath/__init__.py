# =============================================================================
# deepsearcheath
# =============================================================================
#
# 새 아키텍처:
#   from deepsearcheath import DeepSearch
#   ds = DeepSearch()
#   price, mktcap = await ds.stock.get(["AAPL"], "2024-01-01", "2025-01-01")
#
# 레거시:
#   from deepsearcheath import deepsearch as ds
#   ds.DeepSearchGlobalAPI()
#
# =============================================================================

from .core import DeepSearch
from .client.http import DeepSearchClient, KRXClient
from .pipeline.market import prepare_market_data
from .pipeline.news import prepare_news_data, collect_news_frozen, collect_news_liquid

__version__ = "3.1.0"

__all__ = [
    "DeepSearch",
    "DeepSearchClient",
    "KRXClient",
    "prepare_market_data",
    "prepare_news_data",
    "collect_news_frozen",
    "collect_news_liquid",
]
