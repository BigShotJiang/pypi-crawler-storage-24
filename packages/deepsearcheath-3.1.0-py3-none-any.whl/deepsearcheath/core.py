from .facade.stock import StockFacade
from .facade.news import NewsFacade
from .facade.backtest import BacktestFacade


class DeepSearch:
    """
    통합 진입점.

    ds = DeepSearch()

    # 시세
    price, mktcap = await ds.stock.get(["AAPL"], "2024-01-01", "2025-01-01")
    krx = await ds.stock.krx_daily("20250312")

    # 뉴스
    news = await ds.news.get(symbols=["AAPL"], date_from="2024-01-01", date_to="2025-01-01")
    await ds.news.collect(symbols, "2024-01-01", "2025-01-01", mode="frozen")

    # 백테스트
    total, detail = ds.backtest.run(portfolio, price_data, fee=0.0025)
    """

    def __init__(self, cache_dir: str = ".cache/market_data", concurrency: int = 10):
        self.stock = StockFacade(cache_dir=cache_dir, concurrency=concurrency)
        self.news = NewsFacade(cache_dir=cache_dir, concurrency=concurrency)
        self.backtest = BacktestFacade()
