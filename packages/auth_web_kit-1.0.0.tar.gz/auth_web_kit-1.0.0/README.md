# Auth Web Kit

Библиотека для аутентификации в NiceGUI приложениях.

## Установка

```bash
pip install auth-web-kit
```


## Быстрый старт

```python
from openapi_client import some as some_client
from openapi_client import another as another_client
from settings import settings


auth = shared.Auth(
    redis=redis_client,
    redirect_from=settings.app.SELF_REDIRECT_URL,
    auth_web_client_url=settings.auth_client.WEB_URL,
    unauthorized_exception_classes=[
        some_client.exceptions.UnauthorizedException,
        another_client.exceptions.UnauthorizedException,
    ],
    forbidden_exception_classes=[
        some_client.exceptions.ForbiddenException,
        another_client.exceptions.ForbiddenException,
    ],
)
error = shared.Error()

# порядок подключения важен
app.add_middleware(auth.middleware)
app.add_middleware(error.middleware)

app.on_exception(auth.on.unknown_error)
app.on_exception(auth.on.unauthorized)
```

