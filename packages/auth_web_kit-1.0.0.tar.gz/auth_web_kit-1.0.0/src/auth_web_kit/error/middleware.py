import logging
from pathlib import Path

from fastapi import Request
from starlette.middleware.base import BaseHTTPMiddleware
from starlette.responses import HTMLResponse


logger = logging.getLogger(__name__)


class ErrorMiddleware(BaseHTTPMiddleware):
    async def dispatch(self, request: Request, call_next):
        try:
            return await call_next(request)

        except Exception as e:
            logger.exception(e)

            current_dir = Path(__file__).parent.parent
            template_path = current_dir / "templates" / "error.html"

            with open(template_path, "r", encoding="utf-8") as file:
                html_content = file.read()

            html_content = html_content.replace("{{ error_message }}", str(e))
            return HTMLResponse(content=html_content, status_code=500)
