import logging
from typing import Optional

import redis as redis_lib

from .schema import RedisStringSchema, RedisListSchema

logger = logging.getLogger(__name__)

class BaseToken[T]:
    def __init__(self, key: str, redis: redis_lib.Redis, browser_id: str):
        self.redis = redis
        self.key = f"{browser_id}:token:{key}"

        self.expire = RedisStringSchema[int](
            key=f"{browser_id}:token:{key}:expire", redis=redis, browser_id=browser_id
        )

    def set(self, value: T, expire: int) -> None:
        self.redis.set(self.key, value)
        self.redis.set(f"{self.key}:expire", expire)

    def get(self) -> Optional[T]:
        return self.redis.get(self.key)

    def delete(self) -> None:
        self.redis.delete(self.key)
        self.redis.delete(f"{self.key}:expire")


class Token:
    def __init__(self, redis: redis_lib.Redis, browser_id: str):
        self.access = BaseToken[str](key="access", redis=redis, browser_id=browser_id)
        self.refresh = BaseToken[str](key="refresh", redis=redis, browser_id=browser_id)


class User:
    def __init__(self, redis: redis_lib.Redis, browser_id: str):
        self.id = RedisStringSchema[int](key="user:id", redis=redis, browser_id=browser_id)
        self.email = RedisStringSchema[str](
            key="user:email", redis=redis, browser_id=browser_id
        )
        self.first_name = RedisStringSchema[str](
            key="user:first_name", redis=redis, browser_id=browser_id
        )
        self.last_name = RedisStringSchema[str](
            key="user:last_name", redis=redis, browser_id=browser_id
        )
        self.middle_name = RedisStringSchema[str](
            key="user:middle_name", redis=redis, browser_id=browser_id
        )
        self.roles = RedisListSchema[str](
            key="user:roles", redis=redis, browser_id=browser_id
        )
        self.current_role = RedisStringSchema[str](
            key="user:current_role", redis=redis, browser_id=browser_id
        )

    def __str__(self) -> str:
        return f"User(id={self.id.get()}, email={self.email.get()}, first_name={self.first_name.get()}, last_name={self.last_name.get()}, middle_name={self.middle_name.get()})"


class RedisStorage:
    def __init__(self, redis: redis_lib.Redis, browser_id: str):
        logger.info(f"Using Redis storage for browser {browser_id}")
        
        self.redis = redis
        self.browser_id = browser_id


    @property
    def token(self) -> Token:
        return Token(self.redis, self.browser_id)

    @property
    def user(self) -> User:
        return User(redis=self.redis, browser_id=self.browser_id)

    def scopes(self, backend_code_name: str) -> RedisStringSchema[str]:
        return RedisStringSchema[str](
            key=f"scopes:{backend_code_name}",
            redis=self.redis,
            browser_id=self.browser_id,
        )
