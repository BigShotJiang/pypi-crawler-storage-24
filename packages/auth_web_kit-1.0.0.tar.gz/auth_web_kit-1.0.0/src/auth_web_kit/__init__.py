"""Auth Web Kit - библиотека для аутентификации в NiceGUI приложениях."""

from starlette.middleware.base import BaseHTTPMiddleware

from . import storage
from .auth.middleware import AuthMiddleware
from .error.middleware import ErrorMiddleware

__all__ = ['storage', 'Auth', 'Error']

import redis as redis_lib
from .on import On


class Auth:
    def __init__(
        self,
        redis: redis_lib.Redis,
        redirect_from: str,
        auth_web_client_url: str,
        unauthorized_exception_classes: list[type[BaseException]],
        forbidden_exception_classes: list[type[BaseException]]
    ):
        self.redis = redis
        self.redirect_from = redirect_from
        self.auth_web_client_url = auth_web_client_url
        self.unauthorized_exception_classes = unauthorized_exception_classes
        self.forbidden_exception_classes = forbidden_exception_classes
    
    @property
    def middleware(self) -> type[BaseHTTPMiddleware]:
        AuthMiddleware.redis = self.redis
        AuthMiddleware.redirect_from = self.redirect_from
        AuthMiddleware.redirect_to = self.auth_web_client_url
        AuthMiddleware.unauthorized_exception_classes = self.unauthorized_exception_classes
        AuthMiddleware.forbidden_exception_classes = self.forbidden_exception_classes
        return AuthMiddleware
    
    @property
    def on(self) -> On:
        On.redis = self.redis
        On.unauthorized_exception_classes = self.unauthorized_exception_classes
        On.forbidden_exception_classes = self.forbidden_exception_classes
        return On()


class Error:
    @property
    def middleware(self) -> type[BaseHTTPMiddleware]:
        return ErrorMiddleware