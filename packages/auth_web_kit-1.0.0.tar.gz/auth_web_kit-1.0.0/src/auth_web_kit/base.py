import redis as redis_lib


class BaseParams:
    redis: redis_lib.Redis
    
    redirect_from: str
    redirect_to: str
    
    unauthorized_exception_classes: list[type]
    forbidden_exception_classes: list[type]