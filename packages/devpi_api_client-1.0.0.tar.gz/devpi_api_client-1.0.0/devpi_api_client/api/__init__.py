"""Convenience re-exports for devpi API sub-clients."""

from devpi_api_client.api.auth import Auth
from devpi_api_client.api.index import Index
from devpi_api_client.api.project import Project
from devpi_api_client.api.token import Token
from devpi_api_client.api.user import User

__all__ = [
    "Auth",
    "Index",
    "Project",
    "Token",
    "User",
]
