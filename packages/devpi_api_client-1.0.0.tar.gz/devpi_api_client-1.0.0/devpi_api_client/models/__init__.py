"""
Data models for devpi API client.

This module contains Pydantic models for all data structures used by
the devpi API client, including users, indexes, projects, and tokens.
"""

from devpi_api_client.models.index import IndexConfig, IndexList
from devpi_api_client.models.project import ProjectVersion
from devpi_api_client.models.token import TokenInfo
from devpi_api_client.models.user import (
    UserCreateResponse,
    UserDeleteResponse,
    UserInfo,
    UserList,
)

__all__ = [
    # User models
    "UserInfo",
    "UserList",
    "UserCreateResponse",
    "UserDeleteResponse",
    # Index models
    "IndexConfig",
    "IndexList",
    # Project models
    "ProjectVersion",
    # Token models
    "TokenInfo",
]
