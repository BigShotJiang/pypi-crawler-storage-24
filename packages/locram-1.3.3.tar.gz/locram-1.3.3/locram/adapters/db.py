import sqlite3
from contextlib import contextmanager
from pathlib import Path

from locram.config import DB_PATH, VAULT_PATH

_SCHEMA_PATH = Path(__file__).parent.parent / "schema.sql"


@contextmanager
def get_connection(path: Path = DB_PATH):
    conn = sqlite3.connect(str(path))
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA journal_mode = WAL")
    conn.execute("PRAGMA foreign_keys = ON")
    try:
        yield conn
        conn.commit()
    except Exception:
        conn.rollback()
        raise
    finally:
        conn.close()


def init_db(path: Path = DB_PATH) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    VAULT_PATH.mkdir(parents=True, exist_ok=True)
    schema = _SCHEMA_PATH.read_text()
    conn = sqlite3.connect(str(path))
    try:
        conn.executescript(schema)
        conn.commit()
    finally:
        conn.close()
