from locram.interfaces.page_repository import PageRepository


class SearchService:

    def __init__(self, repo: PageRepository):
        self._repo = repo

    def search(self, query: str, limit: int = 20) -> list[dict]:
        """FTS5 BM25 full-text search with snippets."""
        return self._repo.search_fts(query, limit=limit)

    def find_similar(self, page_id: str, limit: int = 10) -> list[dict]:
        """Phase 1: BM25-only similarity.
        Phase 2: + vector embedding similarity (deferred)."""
        page = self._repo.get(page_id)
        if not page or not page.title:
            return []
        # Use title as the search query for BM25 similarity
        results = self._repo.search_fts(page.title, limit=limit + 1)
        return [r for r in results if r["id"] != page_id][:limit]
