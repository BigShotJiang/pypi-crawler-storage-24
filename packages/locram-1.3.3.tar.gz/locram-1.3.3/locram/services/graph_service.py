from locram.interfaces.page_repository import PageRepository


class GraphService:
    """Pure read-only graph analytics. No writes."""

    def __init__(self, repo: PageRepository):
        self._repo = repo

    def find_orphaned(self, limit: int = 50) -> list[dict]:
        return self._repo.find_orphaned(limit=limit)

    def find_central(self, limit: int = 20) -> list[dict]:
        return self._repo.find_central(limit=limit)

    def find_due_for_review(self, limit: int = 50) -> list[dict]:
        return self._repo.find_due_for_review(limit=limit)

    def get_graph_summary(self, limit: int = 500) -> dict:
        """Returns graph stats + topology. Hard limit: 500 pages."""
        limit = min(limit, 500)
        pages = self._repo.get_all_pages_summary(limit=limit)
        links = self._repo.get_all_links(limit=limit)

        type_dist: dict[str, int] = {}
        for p in pages:
            type_dist[p["type"]] = type_dist.get(p["type"], 0) + 1

        return {
            "page_count": len(pages),
            "link_count": len(links),
            "type_distribution": type_dist,
            "pages": pages,
            "links": links,
            "truncated": len(pages) == limit,
        }

