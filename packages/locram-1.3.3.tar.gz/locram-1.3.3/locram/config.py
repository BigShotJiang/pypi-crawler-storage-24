import os
from pathlib import Path

LOCRAM_HOME = Path(os.environ.get("LOCRAM_HOME", Path.home() / ".locram"))
DB_PATH = LOCRAM_HOME / "locram.db"
VAULT_PATH = LOCRAM_HOME / "vault"

VAULT_EXCLUDED_DIRS = {".obsidian", ".trash", ".archive", "attachments", "templates", "Excalidraw"}
