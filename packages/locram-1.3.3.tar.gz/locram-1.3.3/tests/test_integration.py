"""End-to-end integration: full flow through services."""
import sqlite3

import frontmatter
import pytest
from ulid import ULID

from locram.models.page import Page


def test_full_zettelkasten_flow(pages_svc, links_svc, search_svc, graph_svc, repo, vault):
    # Create notes
    hub = pages_svc.create_page("AI Knowledge Hub", type="hub", subject=["ai"])
    perm = pages_svc.create_page("Transformer Architecture", type="permanent",
                                  content="Self-attention mechanism scales well.")
    fleeting = pages_svc.create_page("Quick thought on embeddings", type="fleeting",
                                      content="Embeddings capture semantic meaning.")

    # Link
    links_svc.link_pages(hub.id, perm.id, "related")
    links_svc.set_parent(perm.id, hub.id)

    # Get with context
    fetched_hub = pages_svc.get_page(hub.id)
    assert any(c["id"] == perm.id for c in fetched_hub.connected_to)
    assert any(s["id"] == perm.id for s in fetched_hub.sub_items)

    # Search
    results = search_svc.search("attention")
    assert any(r["id"] == perm.id for r in results)

    # Promote fleeting → note-taking
    promote_result = pages_svc.promote_page(fleeting.id)
    assert promote_result["new_type"] == "note-taking"

    # Orphaned
    orphans = graph_svc.find_orphaned()
    orphan_ids = [o["id"] for o in orphans]
    # fleeting note has no links, still orphaned (hub→perm linked, fleeting not linked)
    assert fleeting.id in orphan_ids or promote_result["new_type"] == "note-taking"

    # Graph summary
    gs = graph_svc.get_graph_summary()
    assert gs["page_count"] == 3
    assert gs["link_count"] >= 1

    # Vault: 3 .md files
    vault_files = list(vault.vault_path.glob("*.md"))
    assert len(vault_files) == 3

    # Soft delete
    ok = pages_svc.delete_page(fleeting.id)
    assert ok
    refreshed = repo.get(fleeting.id)
    assert refreshed.status.value == "to_delete"

    # Hard delete
    pages_svc.delete_page(perm.id, hard=True)
    assert repo.get(perm.id) is None


def test_inline_mentions_exact_title_lookup(pages_svc, repo):
    """inline_mentions must resolve [[wikilinks]] via exact title match, not FTS."""
    target = pages_svc.create_page("Transformer Architecture", content="About transformers.")
    referrer = pages_svc.create_page(
        "Attention Overview",
        content="See also [[Transformer Architecture]] for details.",
    )

    enriched = pages_svc.get_page(referrer.id)
    assert len(enriched.inline_mentions) == 1
    assert enriched.inline_mentions[0]["id"] == target.id
    assert enriched.inline_mentions[0]["title"] == "Transformer Architecture"


def test_inline_mentions_missing_target(pages_svc, repo):
    """Wikilink to non-existent page must not appear in inline_mentions."""
    page = pages_svc.create_page(
        "Dangling Link",
        content="References [[NonExistent Page]] here.",
    )
    enriched = pages_svc.get_page(page.id)
    assert enriched.inline_mentions == []


def test_inline_mentions_special_chars(pages_svc, repo):
    """Titles with hyphens and other chars that break FTS must still resolve."""
    target = pages_svc.create_page("Note-Taking Notes", content="About note-taking.")
    referrer = pages_svc.create_page(
        "Overview",
        content="See [[Note-Taking Notes]] for methodology.",
    )
    enriched = pages_svc.get_page(referrer.id)
    assert len(enriched.inline_mentions) == 1
    assert enriched.inline_mentions[0]["id"] == target.id


def test_ddd_compliance_models_no_io():
    """models/ must not import from sqlite3, json, pathlib, or locram.*"""
    import locram.models.enums as enum_mod
    import locram.models.link as link_mod
    import locram.models.page as page_mod

    for mod in (page_mod, enum_mod, link_mod):
        with open(mod.__file__) as f:
            src = f.read()
        assert "import sqlite3" not in src
        assert "import json" not in src
        assert "from locram" not in src


def test_get_page_by_exact_title(pages_svc):
    """get_page_by_identifier resolves an exact title to the correct page."""
    page = pages_svc.create_page("Unique Title For Lookup", content="Content here.")
    found = pages_svc.get_page_by_identifier("Unique Title For Lookup")
    assert found is not None
    assert found.id == page.id
    assert found.title == "Unique Title For Lookup"


def test_get_page_by_id_still_works(pages_svc):
    """get_page_by_identifier with a page_id still returns the page."""
    page = pages_svc.create_page("Another Page")
    found = pages_svc.get_page_by_identifier(page.id)
    assert found is not None
    assert found.id == page.id


def test_get_page_ambiguous_title(pages_svc, repo):
    """Two pages with the same title → ValueError with helpful message."""
    pages_svc.create_page("Duplicate Title")
    repo.create(Page(id=str(ULID()), title="Duplicate Title"))
    with pytest.raises(ValueError, match="Ambiguous title"):
        pages_svc.get_page_by_identifier("Duplicate Title")


def test_get_page_not_found(pages_svc):
    """Non-existent id and non-existent title → None."""
    assert pages_svc.get_page_by_identifier("nonexistent-id") is None
    assert pages_svc.get_page_by_identifier("Nonexistent Title") is None


def test_list_pages_since_days(pages_svc, repo):
    """since_days filters to recently updated pages."""
    recent = pages_svc.create_page("Recent Note", content="Just created.")

    old = repo.create(Page(id=str(ULID()), title="Old Note"))
    with sqlite3.connect(str(repo.db_path)) as conn:
        conn.execute(
            "UPDATE pages SET updated_at = '2000-01-01T00:00:00Z' WHERE id = ?",
            (old.id,),
        )

    results_7 = pages_svc.list_pages(since_days=7)
    ids_7 = [r["id"] for r in results_7]
    assert recent.id in ids_7
    assert old.id not in ids_7

    # Without filter: both pages should appear
    results_all = pages_svc.list_pages()
    ids_all = [r["id"] for r in results_all]
    assert recent.id in ids_all
    assert old.id in ids_all


def test_mark_reviewed_resets_review_clock(pages_svc, repo):
    """mark_reviewed resets the review countdown without touching updated_at."""
    note = pages_svc.create_page("Review Target", review_interval_days=1)
    original_updated_at = note.updated_at

    with sqlite3.connect(str(repo.db_path)) as conn:
        conn.execute(
            "UPDATE pages SET reviewed_at = '2000-01-01T00:00:00Z' WHERE id = ?",
            (note.id,),
        )

    due = repo.find_due_for_review()
    due_ids = [d["id"] for d in due]
    assert note.id in due_ids

    result = pages_svc.mark_reviewed(note.id)
    assert result["reviewed_at"] is not None

    due_after = repo.find_due_for_review()
    due_after_ids = [d["id"] for d in due_after]
    assert note.id not in due_after_ids

    refreshed = repo.get(note.id)
    assert refreshed.updated_at == original_updated_at


def test_mark_reviewed_not_found(pages_svc):
    """mark_reviewed on non-existent page returns error dict."""
    result = pages_svc.mark_reviewed("nonexistent-id")
    assert "error" in result


def test_mark_reviewed_vault_file_updated(pages_svc, vault):
    """mark_reviewed writes reviewed timestamp into the .md frontmatter."""
    note = pages_svc.create_page("Vault Review Test")
    pages_svc.mark_reviewed(note.id)

    md_files = list(vault.vault_path.rglob("*.md"))
    found = False
    for f in md_files:
        post = frontmatter.load(str(f))
        if post.metadata.get("id") == note.id:
            assert post.metadata.get("reviewed") is not None
            found = True
            break
    assert found, "No .md file found with the reviewed note's id"


def test_next_review_at_uses_reviewed_at(pages_svc):
    """After mark_reviewed, next_review_at is based on reviewed_at, not updated_at."""
    note = pages_svc.create_page("Review Base Test", review_interval_days=7)
    pages_svc.mark_reviewed(note.id)

    enriched = pages_svc.get_page(note.id)
    assert enriched.reviewed_at is not None
    assert enriched.next_review_at is not None
    assert enriched.next_review_at > enriched.reviewed_at


def test_content_update_invalidates_review(pages_svc, repo):
    """Editing content after mark_reviewed clears reviewed_at."""
    note = pages_svc.create_page("Invalidation Test", review_interval_days=1)
    pages_svc.mark_reviewed(note.id)

    reviewed = repo.get(note.id)
    assert reviewed.reviewed_at is not None

    pages_svc.update_page(note.id, content="Significantly changed content.")

    after_edit = repo.get(note.id)
    assert after_edit.reviewed_at is None

    with sqlite3.connect(str(repo.db_path)) as conn:
        conn.execute(
            "UPDATE pages SET updated_at = '2000-01-01T00:00:00Z' WHERE id = ?",
            (note.id,),
        )

    due = repo.find_due_for_review()
    due_ids = [d["id"] for d in due]
    assert note.id in due_ids


def test_get_page_exposes_reviewed_at(pages_svc):
    """get_page returns reviewed_at in the enriched Page after mark_reviewed."""
    note = pages_svc.create_page("Expose Review Test")
    pages_svc.mark_reviewed(note.id)

    enriched = pages_svc.get_page(note.id)
    assert enriched.reviewed_at is not None


def test_update_page_via_explicit_params(pages_svc, repo):
    """update_page applies explicit content updates and clears reviewed_at."""
    note = pages_svc.create_page("Explicit Update Test", content="before")
    pages_svc.mark_reviewed(note.id)

    updated = pages_svc.update_page(note.id, content="after")
    assert updated is not None
    assert updated.content == "after"
    assert updated.reviewed_at is None

    refreshed = repo.get(note.id)
    assert refreshed is not None
    assert refreshed.content == "after"
    assert refreshed.reviewed_at is None


def test_ddd_services_no_concrete_adapters():
    """services/ must not import concrete adapter classes."""
    import locram.services.graph_service as gs
    import locram.services.link_service as ls
    import locram.services.page_service as ps
    import locram.services.search_service as ss

    for mod in (ps, ls, ss, gs):
        with open(mod.__file__) as f:
            src = f.read()
        assert "SqlitePageRepository" not in src
        assert "ObsidianVaultStore" not in src
