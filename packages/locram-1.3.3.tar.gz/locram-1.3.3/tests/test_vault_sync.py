"""Vault write-through, sync, ID index, deletion detection, recursive scan."""

import frontmatter
import pytest

from locram.config import VAULT_EXCLUDED_DIRS
from locram.models.page import Page

_BARE_FRONTMATTER = (
    "---\ntype: fleeting\nstatus: active\nsubject: []\ntags: []\nreview in: 7\n---\n"
)


def test_create_writes_md(pages_svc, vault, tmp_home):
    pages_svc.create_page("My Note", content="Hello world")
    vault_files = list((tmp_home / "vault").glob("*.md"))
    assert any(f.name == "My Note.md" for f in vault_files)


def test_frontmatter_fields(pages_svc, vault, tmp_home):
    page = pages_svc.create_page(
        "Frontmatter Test", type="permanent", subject=["ai"], tags=["test"]
    )
    md_file = (tmp_home / "vault" / "Frontmatter Test.md")
    assert md_file.exists()
    post = frontmatter.load(str(md_file))
    assert post["type"] == "permanent"
    assert post["id"] == page.id
    assert "ai" in post["subject"]
    assert "test" in post["tags"]


def test_id_index_o1_lookup(pages_svc, vault):
    page = pages_svc.create_page("Indexed Note")
    assert page.id in vault._id_index


def test_sync_detects_vault_edit(pages_svc, vault, repo, tmp_home):
    page = pages_svc.create_page("Editable", content="Original")
    md_path = vault._id_index[page.id]

    # Human edits the file
    post = frontmatter.load(str(md_path))
    post.content = "Edited content"
    md_path.write_text(frontmatter.dumps(post), encoding="utf-8")

    stats = vault.sync()
    assert stats["updated"] >= 1

    refreshed = repo.get(page.id)
    assert refreshed.content == "Edited content"


def test_sync_new_file_without_id(vault, repo, tmp_home):
    new_file = tmp_home / "vault" / "new-human-note.md"
    new_file.write_text(
        _BARE_FRONTMATTER + "# New Human Note\n\nContent here.\n",
        encoding="utf-8",
    )
    stats = vault.sync()
    assert stats["inserted"] >= 1
    assert stats["deleted"] == 0, "New file without id must not be marked deleted"

    renamed = tmp_home / "vault" / "New Human Note.md"
    assert renamed.exists()
    assert not new_file.exists()

    post = frontmatter.load(str(renamed))
    assert post.get("id")  # ULID assigned

    page = repo.get(post["id"])
    assert page is not None
    assert page.title == "New Human Note"
    assert page.status.value == "active", "Newly inserted page must remain active after sync"


def test_sync_empty_frontmatter_id_is_treated_as_missing(vault, repo, tmp_home):
    new_file = tmp_home / "vault" / "Untitled.md"
    new_file.write_text(
        "---\n"
        "id:\n"
        "type: fleeting\n"
        "status: active\n"
        "subject: []\n"
        "tags: []\n"
        "review in: 7\n"
        "---\n\n"
        "# Testing header, file name and title\n\n"
        "Body text.\n",
        encoding="utf-8",
    )

    stats = vault.sync()
    assert stats["inserted"] >= 1

    renamed = tmp_home / "vault" / "Testing header, file name and title.md"
    assert renamed.exists()
    assert not new_file.exists()

    post = frontmatter.load(str(renamed))
    assert post["id"] != "None"

    page = repo.get(post["id"])
    assert page is not None
    assert page.title == "Testing header, file name and title"
    assert repo.get("None") is None


def test_sync_skips_newborn_template_only_note(vault, repo, tmp_home):
    new_file = tmp_home / "vault" / "Untitled.md"
    new_file.write_text(
        "---\n"
        "id:\n"
        "type: fleeting\n"
        "subject: []\n"
        "tags: []\n"
        "status: active\n"
        "created: 2026-03-22T03:48\n"
        "updated: 2026-03-22T03:48\n"
        "review in: 7\n"
        "parent:\n"
        "---\n\n"
        "<!-- type: fleeting | note-taking | permanent | structure | hub -->\n"
        "<!-- status: active | archived | to_delete -->\n",
        encoding="utf-8",
    )

    stats = vault.sync()
    assert stats["inserted"] == 0
    assert stats["updated"] == 0
    assert stats["skipped"] >= 1

    post = frontmatter.load(str(new_file))
    assert post.metadata.get("id") is None
    assert repo.get("None") is None
    assert repo.list_pages() == []


def test_sync_skips_h1_without_body(vault, repo, tmp_home):
    new_file = tmp_home / "vault" / "Untitled.md"
    new_file.write_text(
        "---\n"
        "id:\n"
        "type: fleeting\n"
        "status: active\n"
        "subject: []\n"
        "tags: []\n"
        "review in: 7\n"
        "---\n\n"
        "# Half Typed Title\n",
        encoding="utf-8",
    )

    stats = vault.sync()
    assert stats["inserted"] == 0
    assert stats["updated"] == 0
    assert stats["skipped"] >= 1
    assert new_file.exists()

    post = frontmatter.load(str(new_file))
    assert post.metadata.get("id") is None
    assert repo.list_pages() == []


def test_sync_renames_untitled_file_to_h1_title(vault, repo, tmp_home):
    note = tmp_home / "vault" / "Untitled.md"
    note.write_text(
        "---\n"
        "id:\n"
        "type: fleeting\n"
        "status: active\n"
        "subject: []\n"
        "tags: []\n"
        "review in: 7\n"
        "---\n\n"
        "# Testing header, file name and title\n\n"
        "Body text.\n",
        encoding="utf-8",
    )

    stats = vault.sync()
    assert stats["inserted"] >= 1

    renamed = tmp_home / "vault" / "Testing header, file name and title.md"
    assert renamed.exists()
    assert not note.exists()

    post = frontmatter.load(str(renamed))
    page = repo.get(post["id"])
    assert page is not None
    assert page.title == "Testing header, file name and title"


def test_sync_loop_prevention(pages_svc, vault, repo):
    """After write-through, full sync must be a no-op (no spurious updates)."""
    pages_svc.create_page("Loop Test", content="Stable content")
    stats = vault.sync()
    assert stats["updated"] == 0
    assert stats["inserted"] == 0


def test_deletion_detection(pages_svc, vault, repo, tmp_home):
    page = pages_svc.create_page("To Delete")
    md_path = vault._id_index[page.id]
    md_path.unlink()

    stats = vault.sync()
    assert stats["deleted"] >= 1

    refreshed = repo.get(page.id)
    assert refreshed.status.value == "to_delete"


def test_title_rename_updates_file(pages_svc, vault, tmp_home):
    page = pages_svc.create_page("Old Title")
    old_path = vault._id_index[page.id]
    assert old_path.exists()

    pages_svc.update_page(page.id, title="New Title")
    new_path = vault._id_index[page.id]
    assert new_path.name == "New Title.md"
    assert not old_path.exists()


def test_filename_collision_uses_suffix(pages_svc, vault, tmp_home):
    p1 = pages_svc.create_page("Same Title")
    p2 = pages_svc.create_page("Same Title")
    path1 = vault._id_index[p1.id]
    path2 = vault._id_index[p2.id]
    assert path1 != path2
    assert path1.name == "Same Title.md"
    assert path2.name == "Same Title 2.md"


def test_sync_recursive_finds_notes_in_subdirs(vault, repo, tmp_home):
    """Notes in non-excluded subdirectories must be discovered by sync."""
    subdir = tmp_home / "vault" / "projects"
    subdir.mkdir()
    note = subdir / "deep-note.md"
    note.write_text(
        _BARE_FRONTMATTER + "# Deep Note\n\nDeep content.\n",
        encoding="utf-8",
    )
    stats = vault.sync()
    assert stats["inserted"] >= 1

    renamed = subdir / "Deep Note.md"
    assert renamed.exists()
    assert not note.exists()

    post = frontmatter.load(str(renamed))
    page = repo.get(post["id"])
    assert page is not None
    assert page.title == "Deep Note"


def test_sync_recursive_excludes_obsidian_dir(vault, repo, tmp_home):
    """Files inside VAULT_EXCLUDED_DIRS must be ignored by sync."""
    for excluded in (".obsidian", "templates", "attachments"):
        assert excluded in VAULT_EXCLUDED_DIRS
        excl_dir = tmp_home / "vault" / excluded
        excl_dir.mkdir(exist_ok=True)
        (excl_dir / "should-ignore.md").write_text(
            _BARE_FRONTMATTER + "Ignored.\n", encoding="utf-8"
        )

    stats = vault.sync()
    assert stats["inserted"] == 0
    assert stats["updated"] == 0


def test_sync_recursive_deletion_detection_with_subdirs(pages_svc, vault, repo, tmp_home):
    """A note moved into an excluded dir must be detected as deleted."""
    page = pages_svc.create_page("Will Move")
    md_path = vault._id_index[page.id]
    assert md_path.exists()

    trash = tmp_home / "vault" / ".trash"
    trash.mkdir(exist_ok=True)
    md_path.rename(trash / md_path.name)

    stats = vault.sync()
    assert stats["deleted"] >= 1
    refreshed = repo.get(page.id)
    assert refreshed.status.value == "to_delete"


def test_sync_prefers_h1_title_over_slug_filename(vault, repo, tmp_home):
    """Manual vault notes with slugified filenames should use H1 as DB title."""
    note = tmp_home / "vault" / "agent-workflow-in-locram.md"
    note.write_text(
        _BARE_FRONTMATTER
        + "# Agent Workflow in locram\n\n"
        + "Instructions for agents.\n",
        encoding="utf-8",
    )

    stats = vault.sync()
    assert stats["inserted"] >= 1

    renamed = tmp_home / "vault" / "Agent Workflow in locram.md"
    assert renamed.exists()
    assert not note.exists()

    post = frontmatter.load(str(renamed))
    page = repo.get(post["id"])
    assert page is not None
    assert page.title == "Agent Workflow in locram"


def test_sync_updates_existing_slug_title_from_h1(vault, repo, tmp_home):
    """Full sync must repair existing DB titles that were imported from path.stem."""
    note = tmp_home / "vault" / "agent-workflow-in-locram.md"
    note.write_text(
        "---\n"
        "id: 01TESTSYNCREPAIRTITLE0000001\n"
        "type: fleeting\n"
        "status: active\n"
        "subject: []\n"
        "tags: []\n"
        "review in: 7\n"
        "---\n"
        "# Agent Workflow in locram\n\n"
        "Instructions for agents.\n",
        encoding="utf-8",
    )
    repo.create(
        Page(
            id="01TESTSYNCREPAIRTITLE0000001",
            title="agent-workflow-in-locram",
            content="# Agent Workflow in locram\n\nInstructions for agents.\n",
        )
    )

    stats = vault.sync()
    assert stats["updated"] >= 1

    page = repo.get("01TESTSYNCREPAIRTITLE0000001")
    assert page is not None
    assert page.title == "Agent Workflow in locram"


def test_watch_install_non_macos(monkeypatch):
    """install_watcher and uninstall_watcher must raise RuntimeError on non-macOS."""
    import locram.vault.watcher as watcher_mod
    monkeypatch.setattr(watcher_mod.sys, "platform", "linux")
    with pytest.raises(RuntimeError, match="macOS only"):
        watcher_mod.install_watcher()
    with pytest.raises(RuntimeError, match="macOS only"):
        watcher_mod.uninstall_watcher()
