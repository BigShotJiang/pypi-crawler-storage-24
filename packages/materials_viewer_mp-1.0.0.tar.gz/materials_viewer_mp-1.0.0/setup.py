"""
Materials Viewer - Materials Project 材料查询工具
PyPI 安装配置文件
"""

from setuptools import setup, find_packages
import os

# 读取 README 文件
here = os.path.abspath(os.path.dirname(__file__))
try:
    with open(os.path.join(here, 'README.md'), encoding='utf-8') as f:
        long_description = f.read()
except FileNotFoundError:
    long_description = 'Materials Viewer - Materials Project 材料查询工具'

setup(
    # 包名称
    name='materials-viewer-mp',
    
    # 版本号
    version='1.0.0',
    
    # 作者信息
    author='haiw201',
    author_email='hwang@tongji.edu.cn',

    # 包描述
    description='Materials Project 材料查询工具 - 支持化学式查询、带隙筛选、3D可视化',
    long_description=long_description,
    long_description_content_type='text/markdown',

    # 项目主页
    url='https://github.com/haiw201/materials-viewer',
    
    # 包目录
    packages=find_packages(),
    
    # 包含数据文件
    include_package_data=True,
    
    # 依赖包
    install_requires=[
        'pymatgen>=2023.0.0',
        'ase>=3.22.0',
    ],
    
    # 可选依赖
    extras_require={
        'dev': [
            'pytest>=6.0',
            'black>=21.0',
            'flake8>=3.9',
        ],
    },
    
    # 入口点
    entry_points={
        'console_scripts': [
            'mv=materials_viewer.cli:main',
            'materials-viewer=materials_viewer.cli:main',
        ],
    },
    
    # Python 版本要求
    python_requires='>=3.8',
    
    # 分类标签
    classifiers=[
        'Development Status :: 4 - Beta',
        'Intended Audience :: Science/Research',
        'Topic :: Scientific/Engineering :: Chemistry',
        'Topic :: Scientific/Engineering :: Physics',
        'License :: OSI Approved :: MIT License',
        'Programming Language :: Python :: 3',
        'Programming Language :: Python :: 3.8',
        'Programming Language :: Python :: 3.9',
        'Programming Language :: Python :: 3.10',
        'Programming Language :: Python :: 3.11',
        'Operating System :: OS Independent',
    ],
    
    # 关键词
    keywords='materials-project dft vasp chemistry physics materials-science',
    
    # 项目链接
    project_urls={
        'Bug Reports': 'https://github.com/haiw201/materials-viewer/issues',
        'Source': 'https://github.com/haiw201/materials-viewer',
        'Documentation': 'https://github.com/haiw201/materials-viewer/blob/main/README.md',
    },
)
