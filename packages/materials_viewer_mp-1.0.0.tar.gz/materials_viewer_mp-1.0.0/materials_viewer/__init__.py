"""
Materials Viewer - Materials Project 材料查询工具

一个基于 Python + Tkinter 的图形化工具，用于查询和可视化 Materials Project 数据库中的材料信息。

功能特性：
    - 根据化学式查询 Materials Project 数据库
    - 显示材料信息：ID、空间群、能量、形成能、带隙
    - 支持带隙范围筛选
    - 支持空间群筛选（符号或序号）
    - 支持点击表头排序
    - 支持下载 CIF 和 POSCAR 格式
    - 支持3D结构可视化（VESTA/ASE）
    - 支持批量下载
    - API Key 和 VESTA 路径自动保存

使用方法：
    >>> from materials_viewer import MaterialsViewer
    >>> app = MaterialsViewer()
    >>> app.run()

命令行使用：
    $ mv
    或
    $ materials-viewer

作者：haiw201
邮箱：hwang@tongji.edu.cn
版本：1.0.0
许可证：MIT
"""

__version__ = '1.0.0'
__author__ = 'haiw201'
__email__ = 'hwang@tongji.edu.cn'
__license__ = 'MIT'

from .mv import App as MaterialsViewer

__all__ = ['MaterialsViewer']
