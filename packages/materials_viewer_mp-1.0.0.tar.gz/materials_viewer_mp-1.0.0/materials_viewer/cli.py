"""
Materials Viewer - 命令行入口

提供命令行启动方式：
    $ mv
    $ materials-viewer
"""

import sys
import tkinter as tk
from .mv import App


def main():
    """命令行入口函数"""
    root = tk.Tk()
    app = App(root)
    root.mainloop()


if __name__ == '__main__':
    main()
