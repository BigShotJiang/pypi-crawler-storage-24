
# vars_show

Show variable

## Usage

```console
Usage: genesis vars show [OPTIONS] UUID
```

## Options

* `uuid` (REQUIRED):
    * Type: text
    * Default: `sentinel.unset`
    * Usage: `uuid`

* `help`:
    * Type: boolean
    * Default: `false`
    * Usage: `--help`

  Show this message and exit.

## CLI Help

```console
Usage: genesis vars show [OPTIONS] UUID

  Show variable

Options:
  --help  Show this message and exit.
```
