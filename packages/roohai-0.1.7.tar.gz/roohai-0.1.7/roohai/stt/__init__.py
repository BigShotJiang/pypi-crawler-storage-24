"""Speech-to-text model implementations."""

from roohai.stt.whisper import WhisperSTT
from roohai.stt.wav2vec2 import Wav2Vec2STT
from roohai.stt.deepgram import DeepgramSTT
from roohai.stt.nvidia_nemo import NvidiaCanarySTT, NvidiaParakeetSTT

__all__ = ["WhisperSTT", "Wav2Vec2STT", "DeepgramSTT", "NvidiaCanarySTT", "NvidiaParakeetSTT"]
