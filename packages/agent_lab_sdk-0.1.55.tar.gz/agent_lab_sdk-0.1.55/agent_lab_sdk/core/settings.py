from pydantic import Field
from pydantic_settings import BaseSettings

ENV_PREFIX = "SDK_AGENT_LAB_"


class Settings(BaseSettings):
    USE_TOKEN_PROVIDER_AGS: bool = False
    GIGACHAT_MODEL: str | None = Field(alias="GIGACHAT_MODEL", default=None)
    GIGACHAT_CREDENTIAL_ID: str | None = None
    REDIS_THROTTLE_ENABLED: bool = False
    AGENT_SERVICE_NAME: str | None = Field(alias="AGENT_SERVICE_NAME", default=None)

    REDIS_HOST: str = "localhost"
    REDIS_PORT: int = 6379
    REDIS_PASSWORD: str | None = None
    REDIS_DB: str | None = None
    REDIS_SOCKET_CONNECT_TIMEOUT: int | None = None
    REDIS_SOCKET_TIMEOUT: int | None = None
    REDIS_LOCK_TIMEOUT: int = 300
    REDIS_KEY_PREFIX: str = "agent-sdk"
    REDIS_MAX_CONNECTIONS: int | None = None

    REDIS_SEMAPHORE_TIMEOUT: int = 3600
    REDIS_BLOCKING_TIMEOUT: int = 120

    AGENT_SERVICE_ENABLED: bool = True
    AGENT_SERVICE_URL: str = "http://localhost:8081"
    AGENT_SERVICE_TIMEOUT: int = 60
    AGENT_SERVICE_VERSION_PREFIX: str = "v1"
    AGENT_SERVICE_RETRY_ATTEMPTS: int = 3
    AGENT_SERVICE_TOKEN: str | None = None

    class Config:
        env_prefix = ENV_PREFIX


settings = Settings()
