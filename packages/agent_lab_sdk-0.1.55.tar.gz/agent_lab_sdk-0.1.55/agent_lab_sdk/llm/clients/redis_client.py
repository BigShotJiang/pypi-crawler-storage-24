import logging
from contextlib import contextmanager

from redis import Redis as RedisSync
from redis.exceptions import LockError

from agent_lab_sdk.core.settings import settings

logger = logging.getLogger(__name__)


class RedisClient:
    def __init__(self):
        self._redis_sync = None
        self.redis_key_prefix = f"{settings.REDIS_KEY_PREFIX.rstrip(':')}:" if settings.REDIS_KEY_PREFIX else ""
        self.lock_name = f"{self.redis_key_prefix}lock:{{}}"

    def get_redis(self) -> RedisSync:
        if self._redis_sync is None:
            self._redis_sync = RedisSync(
                host=settings.REDIS_HOST,
                port=settings.REDIS_PORT,
                password=settings.REDIS_PASSWORD,
                db=settings.REDIS_DB,
                max_connections=settings.REDIS_MAX_CONNECTIONS,
                socket_connect_timeout=settings.REDIS_SOCKET_CONNECT_TIMEOUT,
                socket_timeout=settings.REDIS_SOCKET_TIMEOUT,
                decode_responses=True
            )
        return self._redis_sync

    @contextmanager
    def redis_lock(self, name: str, blocking_timeout: float = None):
        lock = self.get_redis().lock(self.lock_name.format(name), settings.REDIS_LOCK_TIMEOUT, blocking_timeout=blocking_timeout)
        acquired = lock.acquire()
        try:
            yield acquired
        finally:
            try:
                lock.release()
            except LockError:
                logger.warning("Redis lock already released")
