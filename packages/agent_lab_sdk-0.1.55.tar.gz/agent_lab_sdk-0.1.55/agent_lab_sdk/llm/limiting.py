import logging
import threading
import time
from contextlib import contextmanager, asynccontextmanager, ExitStack, AsyncExitStack

from agent_lab_sdk.core.settings import settings
from agent_lab_sdk.llm.managers.ags_token_manager import AgsTokenManager
if settings.REDIS_THROTTLE_ENABLED:
    from agent_lab_sdk.llm.managers.limits_manager import get_limits_manager

logger = logging.getLogger(__name__)


class Limiting:
    def __init__(self, internal_semaphore, model_type, in_use, waiting, wait_hist):
        self._in_use = in_use
        self._waiting = waiting
        self._wait_hist = wait_hist
        self._lock = threading.Lock()
        self._internal_semaphore = internal_semaphore
        self._model_type = model_type

        self._current = 0
        self._in_use.set(0)
        self._waiting.set(0)
        if settings.REDIS_THROTTLE_ENABLED:
            self._limits_manager = get_limits_manager()

    def get_semaphore_keys(self, key_type, model, agent_id, credential_id):
        key = "{}_{}_{}_{}".format(key_type, model, agent_id, credential_id)
        total_key = "{}_{}".format(key_type, model)
        return key, total_key

    def _dec_waiting_inc_current(self):
        self._waiting.dec()
        with self._lock:
            self._current += 1

    def _wait_hist_in_use_update(self, start):
        elapsed = time.time() - start
        self._wait_hist.observe(elapsed)
        self._in_use.set(self._current)

    def _dec_current_in_use_update(self):
        with self._lock:
            self._current -= 1
        self._in_use.set(self._current)

    @contextmanager
    def acquire(self, model, credential_id):
        self._waiting.inc()
        start = time.time()

        try:
            self._internal_semaphore.acquire()
            if settings.REDIS_THROTTLE_ENABLED:
                logger.info("redis throttle enabled")
                with ExitStack() as stack:
                    try:
                        key, total_key = self.get_semaphore_keys(self._model_type, model, settings.AGENT_SERVICE_NAME, credential_id)
                        ags_limits = AgsTokenManager.get_token_by_env(model, credential_id)
                        stack.enter_context(self._limits_manager.with_concurrency_limit(ags_limits.total_limits, total_key))
                        stack.enter_context(self._limits_manager.with_concurrency_limit(ags_limits.limits, key))
                        self._limits_manager.with_rate_limit(ags_limits.total_limits, total_key)
                        self._limits_manager.with_rate_limit(ags_limits.limits, key)
                    finally:
                        self._dec_waiting_inc_current()
                    self._wait_hist_in_use_update(start)
                    yield
            else:
                self._dec_waiting_inc_current()
                self._wait_hist_in_use_update(start)
                yield
        finally:
            try:
                self._internal_semaphore.release()
            finally:
                self._dec_current_in_use_update()

    @asynccontextmanager
    async def acquire_async(self, model, credential_id):
        self._waiting.inc()
        start = time.time()

        try:
            await self._internal_semaphore.acquire_async()
            if settings.REDIS_THROTTLE_ENABLED:
                logger.info("redis throttle enabled")
                async with AsyncExitStack() as stack:
                    try:
                        key, total_key = self.get_semaphore_keys(self._model_type, model, settings.AGENT_SERVICE_NAME, credential_id)
                        ags_limits = AgsTokenManager.get_token_by_env(model, credential_id)
                        await stack.enter_async_context(self._limits_manager.with_concurrency_limit_async(ags_limits.total_limits, total_key))
                        await stack.enter_async_context(self._limits_manager.with_concurrency_limit_async(ags_limits.limits, key))
                        await self._limits_manager.with_rate_limit_async(ags_limits.total_limits, total_key)
                        await self._limits_manager.with_rate_limit_async(ags_limits.limits, key)
                    finally:
                        self._dec_waiting_inc_current()
                    self._wait_hist_in_use_update(start)
                    yield
            else:
                self._dec_waiting_inc_current()
                self._wait_hist_in_use_update(start)
                yield
        finally:
            try:
                await self._internal_semaphore.release_async()
            finally:
                self._dec_current_in_use_update()
