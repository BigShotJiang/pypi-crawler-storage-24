# nopycln: file
__version__ = "0.3.0"

from jaxdf import conv, logger
from jaxdf.core import constants, operator
# Import geometry elements
from jaxdf.geometry import Domain
from jaxdf.mods import Module

from jaxdf.discretization import (    # isort:skip
    Continuous, FiniteDifferences, FourierSeries, Linear, OnGrid)

from jaxdf.core import Field    # isort:skip

from jaxdf import util, geometry, mods, operators    # isort:skip
from jaxdf.util import get_implementations, has_implementation    # isort:skip

# Must be imported after discretization
from jaxdf.operators.magic import *    # isort:skip
from jaxdf import operators    # isort:skip

__all__ = [
    '__version__',
    'constants',
    'conv',
    'geometry',
    'logger',
    'operator',
    'operators',
    'util',
    'Continuous',
    'Domain',
    'FiniteDifferences',
    'FourierSeries',
    'Field',
    'Linear',
    'Module',
    'OnGrid',
    'get_implementations',
    'has_implementation',
]
