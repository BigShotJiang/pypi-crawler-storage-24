import setuptools

with open('requirements.txt') as f:
    requirements = [
        line.split('#')[0].strip()
        for line in f
        if line.split('#')[0].strip()
    ]

setuptools.setup(
    name='geney',
    version='1.7.0',
    python_requires='>3.10',
    description='A Python package for gene expression modeling.',
    url='https://github.com/nicolaslynn/geney',
    author='Nicolas Lynn',
    author_email='nicolasalynn@gmail.com',
    license='Free for non-commercial use',
    packages=setuptools.find_packages(),
    install_requires=requirements,
    include_package_data=False,
    package_data={
        'geney': [
            'transcription/targets_human.txt',
        ],
    },
    classifiers=[
        'Development Status :: 1 - Planning',
        'Intended Audience :: Science/Research',
        'License :: Free for non-commercial use',
        'Operating System :: POSIX :: Linux',
        'Operating System :: MacOS',
        'Programming Language :: Python :: 3.9',
    ],
)



