"""I/O module tests"""
