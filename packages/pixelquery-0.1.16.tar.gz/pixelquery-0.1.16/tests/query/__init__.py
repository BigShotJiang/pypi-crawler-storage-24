"""Query module tests"""
