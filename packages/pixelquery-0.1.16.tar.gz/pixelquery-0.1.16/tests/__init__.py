"""
PixelQuery Test Suite
"""
