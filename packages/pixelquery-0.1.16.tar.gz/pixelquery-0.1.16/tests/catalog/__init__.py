"""Catalog module tests"""
