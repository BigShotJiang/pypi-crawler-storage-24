"""
Tests for utility modules
"""
