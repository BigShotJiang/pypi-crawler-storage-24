GITHUB_RELEASE_YAML = """name: PyForge Release

on:
  push:
    tags:
      - 'v*'
      - '[0-9]*.[0-9]*.[0-9]*'
  workflow_dispatch:
    inputs:
      pypi_deploy:
        description: 'Publish package to PyPI'
        required: true
        default: 'true'
        type: choice
        options: ['true', 'false']
      docker_build:
        description: 'Build and push Docker image'
        required: true
        default: 'true'
        type: choice
        options: ['true', 'false']
      bump:
        description: 'Version bump for non-tag dispatch runs'
        required: false
        default: ''
        type: choice
        options:
          - ''
          - 'shame'
          - 'default'
          - 'proud'
          - 'patch'
          - 'minor'
          - 'major'
          - 'alpha'
          - 'beta'
          - 'rc'
      plugin_timeout_seconds:
        description: 'Per-hook timeout in seconds for pyproject plugin commands'
        required: false
        default: '300'

concurrency:
  group: ${{ github.workflow }}-${{ github.ref }}
  cancel-in-progress: true

permissions:
  contents: write
  id-token: write

jobs:
  publish_release:
    name: Publish / GitHub Release
    if: ${{ startsWith(github.ref, 'refs/tags/') }}
    runs-on: ubuntu-latest
    timeout-minutes: 10
    steps:
      - name: Checkout Code
        uses: actions/checkout@v5
        with:
          fetch-depth: 0

      - name: Extract Release Notes from CHANGELOG.md
        id: notes
        shell: bash
        run: |
          set -euo pipefail
          TAG="${GITHUB_REF_NAME}"
          BODY_FILE="release-notes.md"

          python - <<'PY'
          from pathlib import Path
          import os

          tag = os.environ.get("GITHUB_REF_NAME", "")
          changelog = Path("CHANGELOG.md")
          out = Path("release-notes.md")

          if not changelog.exists():
              out.write_text(
                  f"Release {tag}\n\nNo CHANGELOG.md found in repository.",
                  encoding="utf-8",
              )
          else:
              lines = changelog.read_text(encoding="utf-8").splitlines()
              tag_plain = tag.lstrip("v")
              starts = [
                  f"## [{tag}]",
                  f"## [v{tag}]",
                  f"## [{tag_plain}]",
                  f"## [v{tag_plain}]",
              ]

              start_idx = -1
              for i, line in enumerate(lines):
                  if any(line.startswith(prefix) for prefix in starts):
                      start_idx = i
                      break

              if start_idx == -1:
                  out.write_text(
                      f"Release {tag}\n\nNo matching changelog section found.",
                      encoding="utf-8",
                  )
              else:
                  end_idx = len(lines)
                  for j in range(start_idx + 1, len(lines)):
                      if lines[j].startswith("## "):
                          end_idx = j
                          break
                  section = "\n".join(lines[start_idx:end_idx]).strip() + "\n"
                  out.write_text(section, encoding="utf-8")
          PY

          echo "path=${BODY_FILE}" >> "$GITHUB_OUTPUT"

      - name: Publish GitHub Release
        uses: softprops/action-gh-release@v2
        with:
          tag_name: ${{ github.ref_name }}
          name: ${{ github.ref_name }}
          body_path: ${{ steps.notes.outputs.path }}

  deploy_pypi:
    name: Deploy / PyPI
    if: >-
      ${{ github.event_name != 'workflow_dispatch' ||
      github.event.inputs.pypi_deploy == 'true' }}
    runs-on: ubuntu-latest
    timeout-minutes: 30
    steps:
      - name: Checkout Code
        uses: actions/checkout@v5
        with:
          fetch-depth: 0

      - name: PyForge / PyPI Deploy
        uses: ertanturk/pyforge-deploy@main
        with:
          python_version: '3.12'
          pypi_deploy: 'true'
          docker_build: 'false'
          bump: >-
            ${{ github.event_name == 'workflow_dispatch' &&
            github.event.inputs.bump || '' }}
          docker_platforms: 'linux/amd64,linux/arm64'
          pyforge_cache: 'true'
          pyforge_ast_cache_ttl: '900'
          pyforge_pypi_cache_ttl: '900'
          plugin_timeout_seconds: >-
            ${{ github.event_name == 'workflow_dispatch' &&
            github.event.inputs.plugin_timeout_seconds || '300' }}
          target_branch: ${{ github.event.repository.default_branch }}
        env:
          PYFORGE_JSON_LOGS: '1'

  deploy_docker:
    name: Deploy / Docker
    if: >-
      ${{ github.event_name != 'workflow_dispatch' ||
      github.event.inputs.docker_build == 'true' }}
    runs-on: ubuntu-latest
    timeout-minutes: 30
    steps:
      - name: Checkout Code
        uses: actions/checkout@v5
        with:
          fetch-depth: 0

      - name: PyForge / Docker Deploy
        uses: ertanturk/pyforge-deploy@main
        with:
          python_version: '3.12'
          pypi_deploy: 'false'
          docker_build: 'true'
          bump: ''
          docker_platforms: 'linux/amd64,linux/arm64'
          pyforge_cache: 'true'
          pyforge_ast_cache_ttl: '900'
          pyforge_pypi_cache_ttl: '900'
          plugin_timeout_seconds: >-
            ${{ github.event_name == 'workflow_dispatch' &&
            github.event.inputs.plugin_timeout_seconds || '300' }}
          target_branch: ${{ github.event.repository.default_branch }}
        env:
          PYFORGE_JSON_LOGS: '1'
          DOCKERHUB_USERNAME: ${{ secrets.DOCKERHUB_USERNAME }}
          DOCKERHUB_TOKEN: ${{ secrets.DOCKERHUB_TOKEN }}
"""
