"""Async TCP transport for Hunter Douglas PowerRise Platinum.

Manages the TCP socket connection to the hub on port 522, handling
connection, reconnection, keep-alive, and command/response framing.
"""

import asyncio
import contextlib
import logging
import re
from time import monotonic
from typing import Any

from aiopowerrise.const import (
    COMMAND_TIMEOUT,
    CONNECT_TIMEOUT,
    DEFAULT_PORT,
    KEEPALIVE_INTERVAL,
)
from aiopowerrise.exceptions import PowerRiseConnectionError, PowerRiseTimeoutError

# Matches the connection-number prefix the hub prepends to every response line.
# Format: one or more digits followed by a space, e.g. "3 $ack" → "3 " stripped.
_CONN_PREFIX_RE = re.compile(r"^\d+ ")

_LOGGER = logging.getLogger(__name__)


class Transport:
    """Async TCP transport for the PowerRise Platinum hub."""

    # Class-level attribute annotations for static analysis.
    _line_queue: asyncio.Queue[str | None]
    _command_queue: asyncio.Queue[str] | None
    _command_lock: asyncio.Lock
    _reconnect_callback: Any | None
    _last_sent_command: str | None
    _last_sent_time: float | None

    def __init__(self, host: str, port: int = DEFAULT_PORT) -> None:
        """Initialize the transport.

        Args:
            host: IP address or hostname of the hub.
            port: TCP port (default 522).
        """
        self._host = host
        self._port = port
        self._reader: asyncio.StreamReader | None = None
        self._writer: asyncio.StreamWriter | None = None
        self._connected = False
        self._keepalive_task: asyncio.Task[None] | None = None
        self._reader_task: asyncio.Task[None] | None = None

        # Connection number assigned by the hub (e.g. 3 for the third client).
        # Parsed from the banner line on connect; None until then.
        self._connection_number: int | None = None

        # Called with every unsolicited line received while no command is active
        self._line_callback: Any | None = None

        # Called (with no arguments) when the reader loop detects a disconnect
        self._disconnect_callback: Any | None = None

        # Serialises all writes to the socket; also gates _command_queue access
        self._command_lock: asyncio.Lock = asyncio.Lock()

        # Non-None only while a send_command call is in-flight; the reader loop
        # delivers incoming lines here rather than to _line_callback
        self._command_queue: asyncio.Queue[str] | None = None

        # Optional callback invoked after an implicit reconnect inside send_command
        self._reconnect_callback: Any | None = None

        # Diagnostics: the most recently sent command and its wall-clock time
        self._last_sent_command: str | None = None
        self._last_sent_time: float | None = None

    @property
    def host(self) -> str:
        """Return the host address."""
        return self._host

    @property
    def port(self) -> int:
        """Return the port."""
        return self._port

    @property
    def connection_number(self) -> int | None:
        """Return the connection number assigned by the hub, or None if not yet connected."""
        return self._connection_number

    @property
    def connected(self) -> bool:
        """Return True if connected."""
        return self._connected and self._writer is not None

    def set_line_callback(self, callback: Any | None) -> None:
        """Register a callback for unsolicited lines from the hub."""
        self._line_callback = callback

    def set_disconnect_callback(self, callback: Any | None) -> None:
        """Register a callback invoked when the reader loop detects a disconnect."""
        self._disconnect_callback = callback

    def set_reconnect_callback(self, callback: Any | None) -> None:
        """Register a callback invoked after a successful implicit reconnect inside send_command."""
        self._reconnect_callback = callback

    # reconnect callback intentionally not provided

    def start_listener(self) -> None:
        """Start the background reader/dispatcher task.

        Safe to call multiple times; does nothing if already running.
        """
        if self._reader_task is None or self._reader_task.done():
            self._reader_task = asyncio.create_task(self._reader_loop())

    async def connect(self) -> None:
        """Open a TCP connection to the hub.

        Reads the initial banner (e.g. "3 HunterDouglas Shade Controller") and
        captures the connection number that the hub prepends to all responses.

        Raises:
            PowerRiseConnectionError: If the connection fails.
        """
        if self.connected:
            return

        try:
            self._reader, self._writer = await asyncio.wait_for(
                asyncio.open_connection(self._host, self._port),
                timeout=CONNECT_TIMEOUT,
            )
            self._connected = True
            _LOGGER.info("Connected to hub at %s:%d", self._host, self._port)

            # Read initial banner and drain startup data directly (reader
            # loop is not running yet, so we call readline() safely here).
            banner_lines = await self._read_until_sentinel("Shade Controller", timeout=CONNECT_TIMEOUT)
            self._parse_connection_number(banner_lines)
            await self._drain_buffer()

            # Start the single reader loop so all subsequent readline() calls
            # happen exclusively inside it.  send_command() and the listener
            # callback both receive lines via the queue/callback routing in
            # _reader_loop rather than touching the StreamReader directly.
            self.start_listener()

        except TimeoutError as exc:
            self._connected = False
            msg = f"Connection to {self._host}:{self._port} timed out"
            raise PowerRiseConnectionError(msg) from exc
        except OSError as exc:
            self._connected = False
            msg = f"Failed to connect to {self._host}:{self._port}: {exc}"
            raise PowerRiseConnectionError(msg) from exc

    def _parse_connection_number(self, banner_lines: list[str]) -> None:
        """Extract the connection number from the hub banner lines.

        The hub banner is formatted as ``"N HunterDouglas Shade Controller"``
        where N is the connection number (1-based, varies by how many clients
        are currently connected).  We store it so callers can correlate
        responses if needed.
        """
        for line in banner_lines:
            m = _CONN_PREFIX_RE.match(line)
            if m:
                try:
                    self._connection_number = int(m.group(0).strip())
                    _LOGGER.debug("Hub connection number: %d", self._connection_number)
                except ValueError:
                    pass
                return

    async def close(self) -> None:
        """Close the TCP connection."""
        self._connected = False

        for task in (self._keepalive_task, self._reader_task):
            if task and not task.done():
                task.cancel()
                with contextlib.suppress(asyncio.CancelledError):
                    await task
        self._keepalive_task = None
        self._reader_task = None

        if self._writer:
            try:
                self._writer.close()
                await self._writer.wait_closed()
            except Exception:  # noqa: BLE001
                pass
            self._writer = None
            self._reader = None
        _LOGGER.info("Disconnected from hub")

    async def reconnect(self) -> None:
        """Close and re-open the connection.

        connect() automatically starts the reader loop, so no extra call to
        start_listener() is needed here.
        """
        await self.close()
        await self.connect()

    async def send_nowait(self, command: str) -> None:
        """Send a command that expects no response (fire-and-forget).

        Acquires the command lock so the write is not interleaved with an
        in-flight ``send_command``, but does not install a command queue and
        does not wait for any reply lines.

        Raises:
            PowerRiseConnectionError: If not connected.
        """
        async with self._command_lock:
            if not self.connected:
                raise PowerRiseConnectionError("Not connected to hub")
            assert self._writer is not None
            _LOGGER.debug("Sending (no-wait): %s", command)
            self._writer.write((command + "\r\n").encode("ascii"))
            await self._writer.drain()

    async def send_command(
        self,
        command: str,
        sentinel: str | None = None,
        timeout: float = COMMAND_TIMEOUT,
    ) -> list[str]:
        """Send a command and collect response lines from the shared reader queue.

        Only one command may be in-flight at a time (serialised by
        _command_lock).  While the lock is held, the _reader_loop routes all
        incoming lines to _command_queue instead of the listener callback, so
        the two paths never race on the StreamReader.

        Raises:
            PowerRiseConnectionError: If not connected or reconnect fails.
            PowerRiseTimeoutError: If sentinel not received within timeout.
        """
        async with self._command_lock:
            if not self.connected:
                raise PowerRiseConnectionError("Not connected to hub")

            assert self._writer is not None

            # Install a per-command queue so _reader_loop delivers to us.
            q: asyncio.Queue[str] = asyncio.Queue()
            self._command_queue = q

            try:
                _LOGGER.debug("Sending: %s", command)
                # record last-sent info
                self._last_sent_command = command
                self._last_sent_time = monotonic()
                self._writer.write((command + "\r\n").encode("ascii"))
                await self._writer.drain()

                result = await self._collect_response(q, sentinel, timeout)
                return result
            except (OSError, TimeoutError) as exc:
                _LOGGER.warning("Command failed, attempting reconnect: %s", exc)
                try:
                    await self.reconnect()
                    # Reinstall the queue after reconnect
                    q = asyncio.Queue()
                    self._command_queue = q
                    assert self._writer is not None
                    # record last-sent info for the retried write
                    self._last_sent_command = command
                    self._last_sent_time = monotonic()
                    self._writer.write((command + "\r\n").encode("ascii"))
                    await self._writer.drain()
                    result = await self._collect_response(q, sentinel, timeout)
                    # Internal reconnect+retry succeeded — schedule the reconnect
                    # callback as a task so the hub can refresh state if desired.
                    cb = self._reconnect_callback
                    if cb is not None:
                        asyncio.create_task(cb())
                    _LOGGER.debug("Command succeeded after internal reconnect")
                    return result
                except Exception as inner_exc:
                    raise PowerRiseConnectionError(f"Command failed after reconnect: {inner_exc}") from inner_exc
            finally:
                # Remove the command queue so _reader_loop reverts to callback mode.
                self._command_queue = None

    async def _collect_response(
        self,
        q: asyncio.Queue[str],
        sentinel: str | None,
        timeout: float,
    ) -> list[str]:
        """Read lines from the command queue until sentinel is seen or timeout."""
        lines: list[str] = []
        try:
            async with asyncio.timeout(timeout):
                while True:
                    line = await q.get()
                    lines.append(line)
                    _LOGGER.debug("Received: %s", line[:80])
                    if sentinel and sentinel in line:
                        break
        except TimeoutError, asyncio.CancelledError:
            if sentinel and not lines:
                raise PowerRiseTimeoutError(f"Timeout waiting for sentinel '{sentinel}'") from None
            _LOGGER.debug(
                "Timeout reading (got %d lines, sentinel '%s' not found)",
                len(lines),
                sentinel,
            )
        return lines

    async def _drain_buffer(self) -> None:
        """Read and discard any pending data in the buffer after connect."""
        assert self._reader is not None
        try:
            async with asyncio.timeout(0.5):
                while True:
                    raw = await self._reader.readline()
                    if not raw:
                        break
        except TimeoutError, asyncio.CancelledError:
            pass

    async def _read_until_sentinel(self, sentinel: str, timeout: float = CONNECT_TIMEOUT) -> list[str]:
        """Read lines directly from the reader until sentinel is found.

        Only called during ``connect()`` before the reader loop is started.
        Returns the raw (un-stripped) lines so the caller can parse the
        connection-number prefix from the banner.
        """
        assert self._reader is not None
        lines: list[str] = []
        try:
            async with asyncio.timeout(timeout):
                while True:
                    raw = await self._reader.readline()
                    if not raw:
                        break
                    line = raw.decode("ascii", errors="replace").strip()
                    if line:
                        lines.append(line)
                    if sentinel in line:
                        break
        except TimeoutError, asyncio.CancelledError:
            pass
        return lines

    def start_keepalive(self) -> None:
        """Start the keep-alive task."""
        if self._keepalive_task is None or self._keepalive_task.done():
            self._keepalive_task = asyncio.create_task(self._keepalive_loop())

    async def _reader_loop(self) -> None:
        """Single background task that owns the StreamReader exclusively.

        Every decoded line is stripped of its connection-number prefix (e.g.
        ``"3 $ack"`` becomes ``"$ack"``) before being routed to either:
        - ``_command_queue`` if a command is currently active, or
        - the ``_line_callback`` for unsolicited push updates.

        Because this is the *only* coroutine that calls ``readline()``,
        the RuntimeError from two concurrent readers is impossible.
        """
        _LOGGER.debug("Background reader started")
        assert self._reader is not None
        clean_exit = False
        while self.connected:
            try:
                try:
                    async with asyncio.timeout(2.0):
                        raw = await self._reader.readline()
                except TimeoutError:
                    continue
                except OSError as exc:
                    _LOGGER.warning("Hub connection lost in reader loop: %s", exc)
                    self._connected = False
                    break

                if not raw:
                    _LOGGER.warning("Hub closed the connection (reader loop)")
                    self._connected = False
                    break

                line = raw.decode("ascii", errors="replace").strip()
                if not line:
                    continue

                # Strip the leading connection-number prefix (e.g. "3 ") so all
                # downstream parsers and sentinel checks see clean "$..." lines.
                line = _CONN_PREFIX_RE.sub("", line, count=1)

                if "$ctb" in line:
                    continue

                _LOGGER.debug("Reader received: %s", line[:80])

                cq = self._command_queue
                if cq is not None:
                    # A command is active — deliver to its queue.
                    await cq.put(line)
                else:
                    # No active command — deliver to listener callback.
                    cb = self._line_callback
                    if cb is not None:
                        try:
                            cb(line)
                        except Exception:  # noqa: BLE001
                            _LOGGER.exception("Error in line callback")

            except asyncio.CancelledError:
                clean_exit = True
                break
            except Exception:  # noqa: BLE001
                _LOGGER.exception("Unexpected error in reader loop")
                await asyncio.sleep(1.0)
        _LOGGER.debug("Background reader stopped")
        # Fire disconnect callback only on unexpected loss (not clean close())
        if not clean_exit:
            cb = self._disconnect_callback
            if cb is not None:
                try:
                    cb()
                except Exception:  # noqa: BLE001
                    _LOGGER.exception("Error in disconnect callback")

    async def _keepalive_loop(self) -> None:
        """Periodically send a dummy command to keep the connection alive.

        ``$dmy`` is fire-and-forget (the hub sends no reply), so we use
        send_nowait rather than send_command to avoid blocking on a sentinel.
        """
        while self.connected:
            try:
                await asyncio.sleep(KEEPALIVE_INTERVAL)
                if self.connected:
                    await self.send_nowait("$dmy")
                    _LOGGER.debug("Keep-alive sent")
            except asyncio.CancelledError:
                break
            except Exception:  # noqa: BLE001
                _LOGGER.debug("Keep-alive failed, will retry next cycle")
