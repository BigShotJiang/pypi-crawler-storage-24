"""Synchronous client for the Alveare API."""

from __future__ import annotations

import os
import time
from typing import Any, Dict, List, Optional, Union

import httpx

from .errors import APIError, AuthenticationError, AlveareError, RateLimitError
from .types import (
    ChatCompletion,
    HealthStatus,
    InferResponse,
    ModelList,
    UsageStats,
)

_DEFAULT_BASE_URL = "https://api.alveare.ai"
_DEFAULT_TIMEOUT = 60.0
_MAX_RETRIES = 3
_RETRY_BASE_DELAY = 0.5  # seconds
_RETRYABLE_STATUS_CODES = {429, 500, 502, 503, 504}


class _ChatCompletions:
    """Namespace that mirrors the ``client.chat.completions.create(...)`` pattern."""

    def __init__(self, client: Alveare) -> None:
        self._client = client

    def create(
        self,
        *,
        model: str,
        messages: List[Dict[str, Any]],
        max_tokens: Optional[int] = None,
        temperature: Optional[float] = None,
        top_p: Optional[float] = None,
        stop: Optional[Union[str, List[str]]] = None,
        **kwargs: Any,
    ) -> ChatCompletion:
        """Create a chat completion (OpenAI-compatible).

        Args:
            model: The model/specialist to use (e.g. ``"alveare-summarise"``).
            messages: A list of message dicts with ``role`` and ``content`` keys.
            max_tokens: Maximum number of tokens to generate.
            temperature: Sampling temperature.
            top_p: Nucleus sampling parameter.
            stop: Stop sequence(s).
            **kwargs: Additional parameters forwarded to the API.

        Returns:
            A :class:`~alveare.types.ChatCompletion` dataclass.
        """
        body: Dict[str, Any] = {"model": model, "messages": messages}
        if max_tokens is not None:
            body["max_tokens"] = max_tokens
        if temperature is not None:
            body["temperature"] = temperature
        if top_p is not None:
            body["top_p"] = top_p
        if stop is not None:
            body["stop"] = stop
        body.update(kwargs)

        data = self._client._request("POST", "/v1/chat/completions", json_body=body)
        return ChatCompletion.from_dict(data)


class _Chat:
    """Namespace for ``client.chat.completions``."""

    def __init__(self, client: Alveare) -> None:
        self.completions = _ChatCompletions(client)


class _Models:
    """Namespace for ``client.models.list()``."""

    def __init__(self, client: Alveare) -> None:
        self._client = client

    def list(self) -> ModelList:
        """List all available models/specialists.

        Returns:
            A :class:`~alveare.types.ModelList` dataclass.
        """
        data = self._client._request("GET", "/v1/models")
        return ModelList.from_dict(data)


class Alveare:
    """Synchronous client for the Alveare inference API.

    Args:
        api_key: Your Alveare API key. Falls back to the ``ALVEARE_API_KEY``
            environment variable when not provided.
        base_url: Override the API base URL. Falls back to the
            ``ALVEARE_BASE_URL`` environment variable, then to
            ``https://api.alveare.ai``.
        timeout: Request timeout in seconds (default 60).
        max_retries: Maximum number of automatic retries for transient errors
            (default 3).

    Raises:
        AlveareError: If no API key is provided and the environment variable
            is not set.
    """

    def __init__(
        self,
        *,
        api_key: Optional[str] = None,
        base_url: Optional[str] = None,
        timeout: float = _DEFAULT_TIMEOUT,
        max_retries: int = _MAX_RETRIES,
    ) -> None:
        self.api_key = api_key or os.environ.get("ALVEARE_API_KEY", "")
        if not self.api_key:
            raise AlveareError(
                "No API key provided. Pass api_key= or set the "
                "ALVEARE_API_KEY environment variable."
            )
        self.base_url = (
            base_url
            or os.environ.get("ALVEARE_BASE_URL")
            or _DEFAULT_BASE_URL
        ).rstrip("/")
        self.max_retries = max_retries

        self._http = httpx.Client(
            base_url=self.base_url,
            timeout=timeout,
            headers={
                "Authorization": f"Bearer {self.api_key}",
                "Content-Type": "application/json",
                "User-Agent": "alveare-python/0.1.0",
            },
        )

        # Namespaced sub-resources
        self.chat = _Chat(self)
        self.models = _Models(self)

    # ------------------------------------------------------------------
    # Public helpers
    # ------------------------------------------------------------------

    def infer(
        self,
        *,
        specialist: str,
        prompt: str,
        max_tokens: Optional[int] = None,
        **kwargs: Any,
    ) -> InferResponse:
        """Call the native ``/v1/infer`` endpoint.

        Args:
            specialist: The specialist to invoke (e.g. ``"summarise"``).
            prompt: The input text.
            max_tokens: Maximum tokens for the response.
            **kwargs: Additional body parameters forwarded to the API.

        Returns:
            An :class:`~alveare.types.InferResponse` dataclass.
        """
        body: Dict[str, Any] = {"specialist": specialist, "prompt": prompt}
        if max_tokens is not None:
            body["max_tokens"] = max_tokens
        body.update(kwargs)

        data = self._request("POST", "/v1/infer", json_body=body)
        return InferResponse.from_dict(data)

    def usage(self) -> UsageStats:
        """Retrieve usage statistics from ``/v1/usage``.

        Returns:
            A :class:`~alveare.types.UsageStats` dataclass.
        """
        data = self._request("GET", "/v1/usage")
        return UsageStats.from_dict(data)

    def health(self) -> HealthStatus:
        """Check the API health via ``/health``.

        Returns:
            A :class:`~alveare.types.HealthStatus` dataclass.
        """
        data = self._request("GET", "/health")
        return HealthStatus.from_dict(data)

    # ------------------------------------------------------------------
    # Lifecycle
    # ------------------------------------------------------------------

    def close(self) -> None:
        """Close the underlying HTTP transport."""
        self._http.close()

    def __enter__(self) -> Alveare:
        return self

    def __exit__(self, *args: Any) -> None:
        self.close()

    # ------------------------------------------------------------------
    # Internal
    # ------------------------------------------------------------------

    def _request(
        self,
        method: str,
        path: str,
        *,
        json_body: Optional[Dict[str, Any]] = None,
    ) -> Dict[str, Any]:
        """Execute an HTTP request with retry logic.

        Retries up to ``self.max_retries`` times on transient errors (429,
        5xx) using exponential backoff. The ``Retry-After`` header is
        respected when present.
        """
        last_exc: Optional[Exception] = None

        for attempt in range(self.max_retries + 1):
            try:
                response = self._http.request(method, path, json=json_body)
            except httpx.TimeoutException as exc:
                last_exc = exc
                if attempt < self.max_retries:
                    self._backoff(attempt)
                    continue
                raise AlveareError(f"Request timed out after {self.max_retries + 1} attempts") from exc
            except httpx.HTTPError as exc:
                last_exc = exc
                if attempt < self.max_retries:
                    self._backoff(attempt)
                    continue
                raise AlveareError(f"HTTP transport error: {exc}") from exc

            if response.status_code < 400:
                return response.json()

            # Parse error body once
            request_id: Optional[str] = response.headers.get("x-request-id")
            try:
                body = response.json()
            except Exception:
                body = {"error": response.text}
            message = body.get("error", {}).get("message", response.text) if isinstance(body.get("error"), dict) else str(body.get("error", response.text))

            # Non-retryable auth errors
            if response.status_code in (401, 403):
                raise AuthenticationError(
                    message=message,
                    status_code=response.status_code,
                    request_id=request_id,
                    body=body,
                )

            # Retryable?
            if response.status_code in _RETRYABLE_STATUS_CODES and attempt < self.max_retries:
                retry_after = self._parse_retry_after(response)
                delay = retry_after if retry_after is not None else self._backoff_delay(attempt)
                time.sleep(delay)
                continue

            # Rate limit but out of retries
            if response.status_code == 429:
                raise RateLimitError(
                    message=message,
                    status_code=429,
                    request_id=request_id,
                    body=body,
                    retry_after=self._parse_retry_after(response),
                )

            raise APIError(
                message=message,
                status_code=response.status_code,
                request_id=request_id,
                body=body,
            )

        # Should not be reached, but satisfy the type checker
        raise AlveareError("Unexpected retry loop exit") from last_exc

    # ------------------------------------------------------------------
    # Retry helpers
    # ------------------------------------------------------------------

    @staticmethod
    def _backoff_delay(attempt: int) -> float:
        return _RETRY_BASE_DELAY * (2 ** attempt)

    def _backoff(self, attempt: int) -> None:
        time.sleep(self._backoff_delay(attempt))

    @staticmethod
    def _parse_retry_after(response: httpx.Response) -> Optional[float]:
        header = response.headers.get("retry-after")
        if header is None:
            return None
        try:
            return float(header)
        except (ValueError, TypeError):
            return None
