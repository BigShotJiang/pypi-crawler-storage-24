"""Custom exceptions for the Alveare SDK."""

from __future__ import annotations

from typing import Optional


class AlveareError(Exception):
    """Base exception for all Alveare SDK errors."""

    def __init__(self, message: str) -> None:
        self.message = message
        super().__init__(message)


class APIError(AlveareError):
    """Raised when the Alveare API returns a non-success response."""

    def __init__(
        self,
        message: str,
        status_code: int,
        request_id: Optional[str] = None,
        body: Optional[dict] = None,
    ) -> None:
        self.status_code = status_code
        self.request_id = request_id
        self.body = body
        detail = f"[HTTP {status_code}] {message}"
        if request_id:
            detail += f" (request_id={request_id})"
        super().__init__(detail)


class AuthenticationError(APIError):
    """Raised when API key is missing, invalid, or revoked (HTTP 401/403)."""

    def __init__(
        self,
        message: str = "Invalid or missing API key",
        status_code: int = 401,
        request_id: Optional[str] = None,
        body: Optional[dict] = None,
    ) -> None:
        super().__init__(message, status_code, request_id, body)


class RateLimitError(APIError):
    """Raised when the API returns HTTP 429 (rate limit exceeded).

    The ``retry_after`` attribute contains the number of seconds to wait
    before retrying, as indicated by the ``Retry-After`` response header.
    It is ``None`` when the header is absent.
    """

    def __init__(
        self,
        message: str = "Rate limit exceeded",
        status_code: int = 429,
        request_id: Optional[str] = None,
        body: Optional[dict] = None,
        retry_after: Optional[float] = None,
    ) -> None:
        self.retry_after = retry_after
        super().__init__(message, status_code, request_id, body)
