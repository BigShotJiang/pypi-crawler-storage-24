"""Alveare Python SDK -- Private SLM Inference-as-a-Service."""

from .async_client import AsyncAlveare
from .client import Alveare
from .errors import APIError, AuthenticationError, AlveareError, RateLimitError
from .types import (
    ChatCompletion,
    ChatChoice,
    ChatMessage,
    CompletionUsage,
    HealthStatus,
    InferResponse,
    Model,
    ModelList,
    UsageStats,
)

__all__ = [
    "Alveare",
    "AsyncAlveare",
    # Errors
    "AlveareError",
    "APIError",
    "AuthenticationError",
    "RateLimitError",
    # Types
    "InferResponse",
    "ChatCompletion",
    "ChatChoice",
    "ChatMessage",
    "CompletionUsage",
    "UsageStats",
    "Model",
    "ModelList",
    "HealthStatus",
]

__version__ = "0.1.0"
