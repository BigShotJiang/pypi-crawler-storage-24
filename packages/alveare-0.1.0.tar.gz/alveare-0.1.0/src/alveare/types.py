"""Request and response types for the Alveare SDK."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional


# ---------------------------------------------------------------------------
# Native /v1/infer
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class InferResponse:
    """Response from the ``/v1/infer`` endpoint."""

    id: str
    specialist: str
    result: str
    tokens_used: int
    latency_ms: int
    cached: bool

    @property
    def text(self) -> str:
        """Convenience alias for ``result``."""
        return self.result

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> InferResponse:
        return cls(
            id=data["id"],
            specialist=data["specialist"],
            result=data["result"],
            tokens_used=data["tokens_used"],
            latency_ms=data["latency_ms"],
            cached=data.get("cached", False),
        )


# ---------------------------------------------------------------------------
# OpenAI-compatible /v1/chat/completions
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class ChatMessage:
    """A single message within a chat completion response."""

    role: str
    content: Optional[str] = None

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> ChatMessage:
        return cls(role=data.get("role", "assistant"), content=data.get("content"))


@dataclass(frozen=True)
class ChatChoice:
    """One of the choices returned in a chat completion."""

    index: int
    message: ChatMessage
    finish_reason: Optional[str] = None

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> ChatChoice:
        return cls(
            index=data.get("index", 0),
            message=ChatMessage.from_dict(data.get("message", {})),
            finish_reason=data.get("finish_reason"),
        )


@dataclass(frozen=True)
class CompletionUsage:
    """Token usage breakdown for a chat completion."""

    prompt_tokens: int = 0
    completion_tokens: int = 0
    total_tokens: int = 0

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> CompletionUsage:
        return cls(
            prompt_tokens=data.get("prompt_tokens", 0),
            completion_tokens=data.get("completion_tokens", 0),
            total_tokens=data.get("total_tokens", 0),
        )


@dataclass(frozen=True)
class ChatCompletion:
    """Response from the ``/v1/chat/completions`` endpoint."""

    id: str
    object: str
    created: int
    model: str
    choices: List[ChatChoice] = field(default_factory=list)
    usage: Optional[CompletionUsage] = None

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> ChatCompletion:
        return cls(
            id=data.get("id", ""),
            object=data.get("object", "chat.completion"),
            created=data.get("created", 0),
            model=data.get("model", ""),
            choices=[ChatChoice.from_dict(c) for c in data.get("choices", [])],
            usage=(
                CompletionUsage.from_dict(data["usage"])
                if "usage" in data
                else None
            ),
        )


# ---------------------------------------------------------------------------
# /v1/usage
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class UsageStats:
    """Response from the ``/v1/usage`` endpoint."""

    data: Dict[str, Any]

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> UsageStats:
        return cls(data=data)

    def __getitem__(self, key: str) -> Any:
        return self.data[key]


# ---------------------------------------------------------------------------
# /v1/models
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class Model:
    """A single model (specialist) returned by ``/v1/models``."""

    id: str
    object: str = "model"
    owned_by: str = "alveare"

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> Model:
        return cls(
            id=data["id"],
            object=data.get("object", "model"),
            owned_by=data.get("owned_by", "alveare"),
        )


@dataclass(frozen=True)
class ModelList:
    """Response from the ``/v1/models`` endpoint."""

    object: str
    data: List[Model] = field(default_factory=list)

    @classmethod
    def from_dict(cls, payload: Dict[str, Any]) -> ModelList:
        return cls(
            object=payload.get("object", "list"),
            data=[Model.from_dict(m) for m in payload.get("data", [])],
        )

    def __iter__(self):  # type: ignore[override]
        return iter(self.data)

    def __len__(self) -> int:
        return len(self.data)


# ---------------------------------------------------------------------------
# /health
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class HealthStatus:
    """Response from the ``/health`` endpoint."""

    status: str
    data: Dict[str, Any] = field(default_factory=dict)

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> HealthStatus:
        status = data.get("status", "unknown")
        return cls(status=status, data=data)

    @property
    def is_healthy(self) -> bool:
        return self.status == "ok"
