# Alveare Python SDK

Python client for the [Alveare](https://alveare.ai) Private SLM Inference-as-a-Service platform.

## Installation

```bash
pip install alveare
```

## Quick start

```python
from alveare import Alveare

client = Alveare(api_key="alv_live_...")

# Native inference
result = client.infer(
    specialist="summarise",
    prompt="Summarise this quarterly report...",
    max_tokens=256,
)
print(result.text)

# OpenAI-compatible chat completions
completion = client.chat.completions.create(
    model="alveare-summarise",
    messages=[{"role": "user", "content": "Summarise this..."}],
    max_tokens=256,
)
print(completion.choices[0].message.content)
```

## Async usage

```python
import asyncio
from alveare import AsyncAlveare

async def main():
    async with AsyncAlveare(api_key="alv_live_...") as client:
        result = await client.infer(specialist="summarise", prompt="...")
        print(result.text)

asyncio.run(main())
```

## Configuration

| Parameter    | Environment variable   | Default                      |
|------------- |----------------------- |------------------------------|
| `api_key`    | `ALVEARE_API_KEY`     | *required*                   |
| `base_url`   | `ALVEARE_BASE_URL`    | `https://api.alveare.ai`   |
| `timeout`    | --                     | `60.0`                       |
| `max_retries`| --                     | `3`                          |

## Error handling

```python
from alveare import Alveare, AuthenticationError, RateLimitError, APIError

client = Alveare(api_key="alv_live_...")

try:
    result = client.infer(specialist="summarise", prompt="...")
except AuthenticationError:
    print("Check your API key")
except RateLimitError as e:
    print(f"Rate limited. Retry after {e.retry_after}s")
except APIError as e:
    print(f"API error {e.status_code}: {e.message}")
```

## Requirements

- Python 3.9+
- [httpx](https://www.python-httpx.org/) (installed automatically)

## License

MIT
