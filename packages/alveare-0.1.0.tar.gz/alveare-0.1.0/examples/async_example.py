"""Async usage of the Alveare SDK."""

import asyncio

from alveare import AsyncAlveare, AlveareError


async def main() -> None:
    async with AsyncAlveare(api_key="alv_live_xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx") as client:
        # Native infer
        try:
            result = await client.infer(
                specialist="summarise",
                prompt="Summarise this quarterly report: revenue grew 23% YoY...",
                max_tokens=256,
            )
            print(f"[infer] {result.text}")
        except AlveareError as exc:
            print(f"Error: {exc}")

        # Chat completions
        try:
            completion = await client.chat.completions.create(
                model="alveare-summarise",
                messages=[{"role": "user", "content": "Summarise this quarterly report..."}],
                max_tokens=256,
            )
            print(f"[chat] {completion.choices[0].message.content}")
        except AlveareError as exc:
            print(f"Error: {exc}")

        # Run multiple requests concurrently
        try:
            usage_task = asyncio.create_task(client.usage())
            models_task = asyncio.create_task(client.models.list())
            health_task = asyncio.create_task(client.health())

            usage, models, health = await asyncio.gather(
                usage_task, models_task, health_task
            )
            print(f"\nUsage: {usage.data}")
            print(f"Models: {[m.id for m in models]}")
            print(f"Health: {health.status}")
        except AlveareError as exc:
            print(f"Error: {exc}")


if __name__ == "__main__":
    asyncio.run(main())
