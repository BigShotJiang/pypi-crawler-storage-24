"""Basic synchronous usage of the Alveare SDK."""

from alveare import Alveare, AlveareError

# Initialise the client. The API key can also be set via the
# ALVEARE_API_KEY environment variable.
client = Alveare(api_key="alv_live_xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx")

# --- Native /v1/infer endpoint ---
try:
    result = client.infer(
        specialist="summarise",
        prompt="Summarise this quarterly report: revenue grew 23% YoY...",
        max_tokens=256,
    )
    print(f"[infer] {result.text}")
    print(f"  tokens_used={result.tokens_used}  latency={result.latency_ms}ms  cached={result.cached}")
except AlveareError as exc:
    print(f"Error: {exc}")

# --- OpenAI-compatible chat completions ---
try:
    completion = client.chat.completions.create(
        model="alveare-summarise",
        messages=[{"role": "user", "content": "Summarise this quarterly report..."}],
        max_tokens=256,
    )
    print(f"\n[chat] {completion.choices[0].message.content}")
except AlveareError as exc:
    print(f"Error: {exc}")

# --- List models ---
try:
    models = client.models.list()
    print("\nAvailable models:")
    for model in models:
        print(f"  - {model.id}")
except AlveareError as exc:
    print(f"Error: {exc}")

# --- Usage stats ---
try:
    usage = client.usage()
    print(f"\nUsage: {usage.data}")
except AlveareError as exc:
    print(f"Error: {exc}")

# --- Health check ---
try:
    health = client.health()
    print(f"\nHealth: {health.status} (healthy={health.is_healthy})")
except AlveareError as exc:
    print(f"Error: {exc}")

client.close()
