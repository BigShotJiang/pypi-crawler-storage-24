"""GitHub builtin plugin."""
