"""
cydms.mri
---------
MRI processing — skull stripping, mesh generation, cortical thickness
"""
import numpy as np
import nibabel as nib
import gc
from scipy import ndimage
from scipy.ndimage import label
from skimage import measure


def process_mri(mri_path):
    img = nib.load(mri_path)
    m_data = img.get_fdata().astype(np.float32)

    voxel_size = np.abs(img.header.get_zooms()[:3])
    min_vox = float(np.min(voxel_size))
    lo_pct = 76 if min_vox >= 0.9 else 50
    lo_thresh = np.percentile(m_data[m_data > 0], lo_pct)
    hi_thresh = np.percentile(m_data[m_data > 0], 98)

    brain_mask = (m_data > lo_thresh) & (m_data < hi_thresh)
    brain_mask = ndimage.binary_fill_holes(brain_mask)
    brain_mask = ndimage.binary_erosion(brain_mask, iterations=5)
    brain_mask = ndimage.binary_dilation(brain_mask, iterations=2)
    brain_mask = ndimage.binary_fill_holes(brain_mask)

    labeled, n = label(brain_mask)
    if n > 0:
        sizes = [np.sum(labeled == i) for i in range(1, n+1)]
        brain_mask = labeled == (np.argmax(sizes) + 1)
    del labeled; gc.collect()

    m_clean = m_data * brain_mask.astype(np.float32)
    nonzero = m_clean[m_clean > 0]
    if len(nonzero) == 0:
        raise ValueError("ไม่พบ brain voxel หลัง masking — ลองปรับ threshold หรือตรวจสอบไฟล์ NIfTI")

    verts, all_faces, _, _ = measure.marching_cubes(m_clean, level=np.percentile(nonzero, 40))
    del m_clean; gc.collect()

    # แปลง verts จาก voxel index → RAS mm ด้วย affine จาก NIfTI header
    affine = img.affine.astype(np.float32)
    verts_h = np.hstack([verts, np.ones((len(verts), 1), dtype=np.float32)])
    verts_ras = (affine @ verts_h.T).T[:, :3]
    v_center = (verts_ras.min(axis=0) + verts_ras.max(axis=0)) / 2
    verts_final = verts_ras - v_center

    # Cortical thickness — ใช้ m_data ที่มีอยู่ downsample 4x เพื่อประหยัด RAM
    from scipy import ndimage as ndi
    mri_ds = m_data[::4, ::4, ::4]
    del m_data; gc.collect()

    lo_t = np.percentile(mri_ds[mri_ds > 0], 20)
    hi_t = np.percentile(mri_ds[mri_ds > 0], 98)
    mask_t = (mri_ds > lo_t) & (mri_ds < hi_t)
    mask_t = ndi.binary_fill_holes(mask_t)
    mask_t = ndi.binary_erosion(mask_t, iterations=1)
    del mri_ds; gc.collect()

    # แปลง voxel index ของ mask_t → RAS mm เพื่อแบ่ง lobe ตาม orientation จริง
    # ใช้ affine เดิม × 4 เพราะ downsample 4x
    affine_ds = affine.copy()
    affine_ds[:3, :3] *= 4

    mask_coords = np.array(np.where(mask_t)).T.astype(np.float32)  # (N, 3) voxel idx
    mask_h = np.hstack([mask_coords, np.ones((len(mask_coords), 1), dtype=np.float32)])
    mask_ras = (affine_ds @ mask_h.T).T[:, :3]  # RAS mm

    # แบ่ง lobe ด้วย RAS mm — Y+ = Anterior (Frontal), Y- = Posterior (Occipital)
    # X = Left/Right, Z = Superior/Inferior
    y = mask_ras[:, 1]
    z = mask_ras[:, 2]
    frontal_mask   = y > 25
    occipital_mask = y < -45
    temporal_mask  = (~frontal_mask) & (~occipital_mask) & (z < -15)
    parietal_mask  = (~frontal_mask) & (~occipital_mask) & (~temporal_mask)

    n_total = max(len(mask_ras), 1)
    thickness = {
        'frontal':   float(np.sum(frontal_mask))   / n_total * 100,
        'occipital': float(np.sum(occipital_mask)) / n_total * 100,
        'temporal':  float(np.sum(temporal_mask))  / n_total * 100,
        'parietal':  float(np.sum(parietal_mask))  / n_total * 100,
    }

    # asymmetry ตาม X axis (RAS: X+ = Right, X- = Left)
    x = mask_ras[:, 0]
    left_sum  = float(np.sum(x < 0))
    right_sum = float(np.sum(x >= 0))
    asymmetry = abs(left_sum - right_sum) / max(left_sum + right_sum, 1)
    del mask_t, mask_ras; gc.collect()

    mri_extent = float(np.max(np.abs(verts_final)))

    return {
        'verts':         verts_final.tolist(),
        'faces':         all_faces.tolist(),
        'thickness':     thickness,
        'asymmetry':     round(asymmetry * 100, 2),
        'voxel_size':    min_vox,
        'threshold_pct': lo_pct,
        'mri_extent':    mri_extent,
        'ras_center':    v_center.tolist(),
    }