"""CrawlNest MCP Server

A Model Context Protocol server for web scraping with anti-bot bypass.
Use with Claude Desktop, Cursor, Windsurf, and other MCP clients.
"""

__version__ = "0.1.0"
