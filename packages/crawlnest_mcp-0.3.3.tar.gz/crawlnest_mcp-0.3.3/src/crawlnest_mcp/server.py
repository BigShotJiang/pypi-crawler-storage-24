"""CrawlNest MCP Server

A Model Context Protocol server that exposes CrawlNest's web scraping capabilities
to AI assistants like Claude Desktop using FastMCP for proper Context support.
"""

import json
import logging

from mcp.server.fastmcp import Context, FastMCP

from .tools.crawl_website import handle_crawl_website
from .tools.extract_structured import handle_extract_structured
from .tools.image import handle_download_image
from .tools.reddit import (
    handle_reddit_about,
    handle_reddit_community,
    handle_reddit_explore,
    handle_reddit_feed,
    handle_reddit_popular,
    handle_reddit_post,
    handle_reddit_search,
)
from .tools.scrape_url import handle_scrape_url
from .tools.twitter import (
    handle_fetch_tweet,
    handle_twitter_for_you,
    handle_twitter_home_timeline,
    handle_twitter_news,
    handle_twitter_search,
    handle_twitter_trending,
    handle_twitter_user_info,
)
from .tools.video import handle_download_video, handle_transcribe_video

# Set up file logging - debug output goes here, NOT to stdout/stderr
# Remove any existing handlers first
root_logger = logging.getLogger()
for handler in root_logger.handlers[:]:
    root_logger.removeHandler(handler)

# Create file handler
file_handler = logging.FileHandler("/tmp/mcp_server.log")
file_handler.setLevel(logging.DEBUG)
formatter = logging.Formatter("%(asctime)s - %(levelname)s - %(message)s")
file_handler.setFormatter(formatter)

# Configure root logger
root_logger.setLevel(logging.DEBUG)
root_logger.addHandler(file_handler)

logger = logging.getLogger(__name__)

# Suppress verbose httpx/httpcore logging
logging.getLogger("httpx").setLevel(logging.WARNING)
logging.getLogger("httpcore").setLevel(logging.WARNING)

# Create FastMCP server instance with longer timeout for long-running crawls
server = FastMCP("crawlnest")


# --- JSON response helper ---

def _parse_result(result) -> dict:
    """Parse handler result (list[TextContent]) into a dict."""
    if result and len(result) > 0:
        try:
            response_data: dict = json.loads(result[0].text)
            return response_data
        except json.JSONDecodeError:
            return {"success": False, "error": "Invalid JSON response from handler"}
    return {"success": False, "error": "No content returned"}


# =============================================================================
# Web Scraping Tools
# =============================================================================


@server.tool()
async def scrape_url(
    url: str,
    proxy: str | None = None,
    useragent: str | None = None,
    ctx: Context | None = None,
) -> dict:
    """
    GENERAL PURPOSE: Scrape a URL to get raw page content, images, links, and metadata.

    Use this for exploratory browsing or getting general page information.
    For structured data extraction (e.g., extract products with name, price, image),
    use extract_structured tool instead.

    Uses CrawlNest's multi-layer scraping with automatic anti-bot bypass.
    """
    logger.info(f"[scrape_url] Called with URL: {url}")
    result = await handle_scrape_url({"url": url, "proxy": proxy, "useragent": useragent})
    return _parse_result(result)


@server.tool()
async def crawl_website(
    url: str,
    max_pages: int = 10,
    same_domain: bool = True,
    include_pattern: str | None = None,
    exclude_pattern: str | None = None,
    ctx: Context | None = None,
) -> dict:
    """
    Crawl an entire website and extract content from multiple pages.

    Uses sitemap.xml for efficient URL discovery when available, otherwise
    follows HTML links. Supports up to 50 pages with real-time progress tracking.
    Useful for scraping blogs, documentation sites, or entire website sections.
    Returns an array of page objects with content, url, title, and metadata.
    """
    logger.info(
        f"[crawl_website] Called with URL: {url}, max_pages: {max_pages}, ctx: {ctx is not None}"
    )

    arguments = {
        "url": url,
        "max_pages": max_pages,
        "same_domain": same_domain,
        "include_pattern": include_pattern,
        "exclude_pattern": exclude_pattern,
    }

    result = await handle_crawl_website(arguments, ctx=ctx)
    return _parse_result(result)


@server.tool()
async def extract_structured(
    url: str,
    schema: dict[str, str],
    multiple: bool = True,
    output_format: str = "json",
    ctx: Context | None = None,
) -> dict:
    """
    STRUCTURED DATA EXTRACTION: Extract specific fields from a webpage using a schema.

    Use this whenever you need to extract multiple items with specific fields.
    Examples: extract products, job listings, articles, listings, etc.

    Returns raw page content (text, html, images, links) for the LLM to intelligently
    extract and format as the desired output format (JSON, CSV, Markdown, HTML, YAML, XML, or text).

    Args:
        url: URL to extract from
        schema: Field definitions to extract (e.g., {"name": "product name", "price": "price in USD", "image": "product image"})
        multiple: Extract multiple items as array (default: true)
        output_format: Desired output format - json, csv, markdown, html, yaml, xml, text (default: json)
    """
    logger.info(
        f"[extract_structured] Called with URL: {url}, format: {output_format}, ctx: {ctx is not None}"
    )
    result = await handle_extract_structured(
        {"url": url, "schema": schema, "multiple": multiple, "output_format": output_format},
        ctx=ctx,
    )
    return _parse_result(result)


# =============================================================================
# Twitter Tools
# =============================================================================


@server.tool()
async def fetch_tweet(
    url: str,
    ctx: Context | None = None,
) -> dict:
    """
    Fetch a single tweet's text content, engagement stats, and author info from a Twitter/X URL.

    Use this when the user wants to read a tweet, see its likes/retweets/replies, or get
    the author's info. Returns tweet text, media URLs, engagement metrics, and author data.

    This tool returns tweet DATA (text, stats, media references). For downloading the actual
    video file from a tweet, use download_video. For transcribing speech from a tweet video,
    use transcribe_video. For getting images, use download_image.

    No Twitter credentials required — credentials only improve reliability.
    """
    logger.info(f"[fetch_tweet] URL: {url}")
    result = await handle_fetch_tweet({"url": url})
    return _parse_result(result)


@server.tool()
async def twitter_user_info(
    screen_name: str,
    ctx: Context | None = None,
) -> dict:
    """
    Fetch a Twitter/X user's profile information.

    Returns profile data including display name, bio, follower/following counts,
    verification status, and profile images. Uses FxTwitter API — no credentials needed.
    """
    logger.info(f"[twitter_user_info] screen_name: {screen_name}")
    result = await handle_twitter_user_info({"screen_name": screen_name})
    return _parse_result(result)


@server.tool()
async def twitter_search(
    query: str,
    filter: str = "top",
    next_page_token: str | None = None,
    ctx: Context | None = None,
) -> dict:
    """
    Search Twitter/X for tweets matching a query.

    Requires Twitter credentials (auth_token + ct0) saved via API or dashboard.
    Supports pagination with next_page_token from previous responses.

    Args:
        query: Search query string
        filter: Result filter — top (default), live, user, media, or list
        next_page_token: Pagination cursor from previous search response
    """
    logger.info(f"[twitter_search] query: {query}, filter: {filter}")
    args: dict = {"query": query, "filter": filter}
    if next_page_token:
        args["next_page_token"] = next_page_token
    result = await handle_twitter_search(args)
    return _parse_result(result)


@server.tool()
async def twitter_trending(
    global_trending: bool = False,
    ctx: Context | None = None,
) -> dict:
    """
    Fetch trending topics on Twitter/X.

    Requires Twitter credentials (auth_token + ct0) saved via API or dashboard.

    Args:
        global_trending: If false (default), returns local/regional trend names only.
                        If true, returns global trending tweets with full content.
    """
    logger.info(f"[twitter_trending] global: {global_trending}")
    result = await handle_twitter_trending({"global_trending": global_trending})
    return _parse_result(result)


@server.tool()
async def twitter_news(
    ctx: Context | None = None,
) -> dict:
    """
    Fetch the Twitter/X news timeline.

    Returns current news stories as shown in Twitter's news section.
    Requires Twitter credentials (auth_token + ct0) saved via API or dashboard.
    """
    logger.info("[twitter_news] Fetching news timeline")
    result = await handle_twitter_news({})
    return _parse_result(result)


@server.tool()
async def twitter_for_you(
    ctx: Context | None = None,
) -> dict:
    """
    Fetch the Twitter/X "For You" explore timeline.

    Returns algorithmically curated content from the Explore page.
    Requires Twitter credentials (auth_token + ct0) saved via API or dashboard.
    """
    logger.info("[twitter_for_you] Fetching explore timeline")
    result = await handle_twitter_for_you({})
    return _parse_result(result)


@server.tool()
async def twitter_home_timeline(
    tab: str = "for_you",
    ctx: Context | None = None,
) -> dict:
    """
    Fetch the Twitter/X home timeline.

    Returns the authenticated user's home feed. Requires Twitter credentials
    (auth_token + ct0) saved via API or dashboard.

    Args:
        tab: Timeline tab — "for_you" (default) or "following"
    """
    logger.info(f"[twitter_home_timeline] tab: {tab}")
    result = await handle_twitter_home_timeline({"tab": tab})
    return _parse_result(result)


# =============================================================================
# Reddit Tools
# =============================================================================


@server.tool()
async def reddit_post(
    url: str,
    include_comments: bool = True,
    comment_depth: int | None = None,
    comment_sort: str | None = None,
    ctx: Context | None = None,
) -> dict:
    """
    Fetch a Reddit post with its comment tree.

    Returns post content, metadata, and optionally the full comment tree.
    No Reddit credentials needed for public posts.

    Args:
        url: Full Reddit post URL
        include_comments: Include comment tree (default: true)
        comment_depth: Max comment nesting depth (optional)
        comment_sort: Comment sort order — confidence, top, new, controversial, old, qa
    """
    logger.info(f"[reddit_post] URL: {url}")
    args: dict = {"url": url, "include_comments": include_comments}
    if comment_depth is not None:
        args["comment_depth"] = comment_depth
    if comment_sort:
        args["comment_sort"] = comment_sort
    result = await handle_reddit_post(args)
    return _parse_result(result)


@server.tool()
async def reddit_community(
    subreddit: str,
    sort: str = "hot",
    time_filter: str | None = None,
    limit: int = 25,
    after: str | None = None,
    ctx: Context | None = None,
) -> dict:
    """
    Fetch posts from a subreddit.

    Returns a listing of posts with titles, scores, comment counts, and content.
    Supports sorting and pagination. No Reddit credentials needed.

    Args:
        subreddit: Subreddit name without r/ prefix (e.g., "technology")
        sort: Sort order — best, hot (default), new, top, rising
        time_filter: Time range for "top" sort — hour, day, week, month, year, all
        limit: Number of posts to return (max 100, default 25)
        after: Pagination cursor from previous response
    """
    logger.info(f"[reddit_community] r/{subreddit}, sort: {sort}")
    args: dict = {"subreddit": subreddit, "sort": sort, "limit": limit}
    if time_filter:
        args["time_filter"] = time_filter
    if after:
        args["after"] = after
    result = await handle_reddit_community(args)
    return _parse_result(result)


@server.tool()
async def reddit_about(
    subreddit: str,
    ctx: Context | None = None,
) -> dict:
    """
    Fetch subreddit metadata and information.

    Returns subscriber count, description, rules, creation date, and other metadata.
    No Reddit credentials needed.

    Args:
        subreddit: Subreddit name without r/ prefix (e.g., "technology")
    """
    logger.info(f"[reddit_about] r/{subreddit}")
    result = await handle_reddit_about({"subreddit": subreddit})
    return _parse_result(result)


@server.tool()
async def reddit_search(
    query: str,
    category: str = "posts",
    subreddit: str | None = None,
    sort: str = "relevance",
    time_filter: str | None = None,
    limit: int = 25,
    after: str | None = None,
    ctx: Context | None = None,
) -> dict:
    """
    Search across Reddit for posts, communities, comments, people, or media.

    Supports global search or scoped to a specific subreddit.
    No Reddit credentials needed.

    Args:
        query: Search query string
        category: Search category — posts (default), communities, comments, people, media
        subreddit: Limit search to this subreddit (optional)
        sort: Sort order — relevance (default), hot, top, new, comments
        time_filter: Time range for "top" sort — hour, day, week, month, year, all
        limit: Number of results (max 100, default 25)
        after: Pagination cursor from previous response
    """
    logger.info(f"[reddit_search] query: {query}, category: {category}")
    args: dict = {"query": query, "category": category, "sort": sort, "limit": limit}
    if subreddit:
        args["subreddit"] = subreddit
    if time_filter:
        args["time_filter"] = time_filter
    if after:
        args["after"] = after
    result = await handle_reddit_search(args)
    return _parse_result(result)


@server.tool()
async def reddit_explore(
    category: str = "popular",
    limit: int = 25,
    after: str | None = None,
    ctx: Context | None = None,
) -> dict:
    """
    Discover subreddits by category.

    Browse popular, new, or default subreddits. No Reddit credentials needed.

    Args:
        category: Discovery category — popular (default), new, default
        limit: Number of subreddits to return (max 100, default 25)
        after: Pagination cursor from previous response
    """
    logger.info(f"[reddit_explore] category: {category}")
    args: dict = {"category": category, "limit": limit}
    if after:
        args["after"] = after
    result = await handle_reddit_explore(args)
    return _parse_result(result)


@server.tool()
async def reddit_popular(
    sort: str = "hot",
    time_filter: str | None = None,
    geo_filter: str | None = None,
    limit: int = 25,
    after: str | None = None,
    ctx: Context | None = None,
) -> dict:
    """
    Fetch trending posts across all of Reddit.

    Returns popular posts site-wide with optional geographic filtering.
    No Reddit credentials needed.

    Args:
        sort: Sort order — best, hot (default), new, top, rising
        time_filter: Time range for "top" sort — hour, day, week, month, year, all
        geo_filter: Country code for regional trending (e.g., "US", "GB", "DE")
        limit: Number of posts (max 100, default 25)
        after: Pagination cursor from previous response
    """
    logger.info(f"[reddit_popular] sort: {sort}, geo: {geo_filter}")
    args: dict = {"sort": sort, "limit": limit}
    if time_filter:
        args["time_filter"] = time_filter
    if geo_filter:
        args["geo_filter"] = geo_filter
    if after:
        args["after"] = after
    result = await handle_reddit_popular(args)
    return _parse_result(result)


@server.tool()
async def reddit_feed(
    feed: str = "home",
    sort: str | None = None,
    time_filter: str | None = None,
    use_cookies: bool = False,
    limit: int = 25,
    after: str | None = None,
    ctx: Context | None = None,
) -> dict:
    """
    Fetch a Reddit feed (home or news).

    Without credentials, returns generic public content. With credentials
    (use_cookies=true), returns personalized content from subscribed subreddits.
    News feed is only available with credentials.

    Save Reddit credentials first via API: POST /api/subreddit/credentials

    Args:
        feed: Feed type — "home" (default) or "news"
        sort: Sort order — best, hot, new, top, rising (optional)
        time_filter: Time range for "top" sort — hour, day, week, month, year, all
        use_cookies: Use saved Reddit credentials for personalized feed (default: false)
        limit: Number of posts (max 100, default 25)
        after: Pagination cursor from previous response
    """
    logger.info(f"[reddit_feed] feed: {feed}, cookies: {use_cookies}")
    args: dict = {"feed": feed, "use_cookies": use_cookies, "limit": limit}
    if sort:
        args["sort"] = sort
    if time_filter:
        args["time_filter"] = time_filter
    if after:
        args["after"] = after
    result = await handle_reddit_feed(args)
    return _parse_result(result)


# =============================================================================
# Video Tools
# =============================================================================


@server.tool()
async def download_video(
    url: str,
    platform: str,
    quality: str = "best",
    ctx: Context | None = None,
) -> dict:
    """
    Get video download URLs and metadata from a Twitter/X tweet or Reddit post.

    Use this when the user wants to download a video, get video URLs, check available
    quality options, or see video metadata (resolution, bitrate, duration, thumbnail).
    Returns all available quality variants — the user can open or download the URLs directly.

    This tool does NOT transcribe or extract text from videos. For speech-to-text
    transcription, use the transcribe_video tool instead.

    Since MCP is text-based, this returns metadata and CDN URLs — not the binary stream.

    Args:
        url: Tweet or Reddit post URL containing a video
        platform: Source platform — "twitter" or "reddit"
        quality: Preferred quality — "best" (default) or a pixel height (e.g. "720")
    """
    logger.info(f"[download_video] URL: {url}, platform: {platform}, quality: {quality}")
    args: dict = {"url": url, "platform": platform}
    if quality != "best":
        args["quality"] = quality
    result = await handle_download_video(args)
    return _parse_result(result)


@server.tool()
async def transcribe_video(
    url: str,
    platform: str,
    language: str | None = None,
    ctx: Context | None = None,
) -> dict:
    """
    Transcribe speech from a Twitter/X or Reddit video into text.

    Use this when the user wants to know what is being said in a video, get a transcript,
    generate subtitles/captions, or convert video speech to text. Works with videos of any
    length — uses a generous timeout to handle long transcriptions.

    Extracts audio in-memory, sends to Whisper speech-to-text. Returns the full transcript
    with optional timestamps. No video is downloaded or saved to disk.

    This tool does NOT return video URLs or metadata. For downloading videos, use the
    download_video tool instead.

    Args:
        url: Tweet or Reddit post URL containing a video with speech/audio
        platform: Source platform — "twitter" or "reddit"
        language: Language hint (ISO 639-1, e.g. 'en', 'es'). Auto-detected if omitted.
    """
    logger.info(f"[transcribe_video] URL: {url}, platform: {platform}")
    args: dict = {"url": url, "platform": platform}
    if language:
        args["language"] = language
    result = await handle_transcribe_video(args)
    return _parse_result(result)


# =============================================================================
# Image Tools
# =============================================================================


@server.tool()
async def download_image(
    url: str,
    platform: str,
    ctx: Context | None = None,
) -> dict:
    """
    Get image URLs and metadata from a Twitter/X tweet or Reddit post.

    Use this when the user wants to download images, get image URLs, or see image
    metadata from a tweet or Reddit post. Supports single images, multi-image tweets
    (up to 4), and Reddit gallery posts (unlimited images).

    Returns all image URLs with dimensions. The response includes `image_count` and
    `is_gallery`. When multiple images are found, present each image separately with
    its index (0-based) so the user knows exactly how many images are available.

    This tool is for IMAGES only. For videos, use download_video or transcribe_video.

    Since MCP is text-based, this returns metadata (URLs, dimensions), not binary data.
    The returned URLs are direct CDN links the user can open or download.

    Args:
        url: Tweet or Reddit post URL containing image(s)
        platform: Source platform — "twitter" or "reddit"
    """
    logger.info(f"[download_image] URL: {url}, platform: {platform}")
    result = await handle_download_image({"url": url, "platform": platform})
    return _parse_result(result)


def main():
    """Entry point for the MCP server."""
    logger.info("=" * 70)
    logger.info("CrawlNest MCP Server Started (FastMCP)")
    logger.info("Transport: stdio (Claude Desktop compatible)")
    logger.info("Tools: scraping (3) + twitter (7) + reddit (7) + video (2) + image (1) = 20 total")
    logger.info("Waiting for connections...")
    logger.info("=" * 70)
    server.run()


if __name__ == "__main__":
    main()
