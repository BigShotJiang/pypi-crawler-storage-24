# Copyright [2025] [IBM]
# Licensed under the Apache License, Version 2.0 (http://www.apache.org/licenses/LICENSE-2.0)
# See the LICENSE file in the project root for license information.

"""Catalog service for managing catalogs and schemas in IBM watsonx.data."""

# Made with Bob
