# Copyright [2025] [IBM]
# Licensed under the Apache License, Version 2.0 (http://www.apache.org/licenses/LICENSE-2.0)
# See the LICENSE file in the project root for license information.

"""Models for catalog service."""

from app.services.catalog.models.list_schemas import (
    ListSchemasRequest,
    ListSchemasResponse,
)

__all__ = [
    "ListSchemasRequest",
    "ListSchemasResponse",
]

# Made with Bob
