# Copyright [2025] [IBM]
# Licensed under the Apache License, Version 2.0 (http://www.apache.org/licenses/LICENSE-2.0)
# See the LICENSE file in the project root for license information.

from typing import List
from pydantic import BaseModel, Field
from app.shared.models import BaseResponseModel


class ListSchemasRequest(BaseModel):
    """Request model for listing schemas in a catalog."""
    
    catalog_id: str = Field(
        ...,
        description="Catalog name/ID to list schemas from",
        min_length=1,
        max_length=128,
        pattern=r"^[a-zA-Z0-9\-_]+$"
    )
    engine_id: str = Field(
        ...,
        description="Engine name/ID to use for listing schemas",
        min_length=1,
        max_length=128,
        pattern=r"^[a-zA-Z0-9\-]+$"
    )
    auth_instance_id: str = Field(
        ...,
        description="CRN (Cloud Resource Name) for authorization",
        min_length=1,
        max_length=128,
        pattern=r"^[a-zA-Z0-9\-\:/]+$"
    )


class ListSchemasResponse(BaseResponseModel):
    """Response model for listing schemas in a catalog."""
    
    message: str = Field(..., description="Response message")
    message_code: str = Field(..., description="Response message code")
    schemas: List[str] = Field(
        ...,
        description="List of schema names in the catalog",
        max_length=10000
    )

# Made with Bob
