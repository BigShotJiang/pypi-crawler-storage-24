"""
Kevros governance middleware for AI agent pipelines.

    pip install kevros-agent-framework

Two modes:
    Remote (default): pip install kevros-agent-framework
    Embedded:         pip install kevros-agent-framework[embedded]
"""

from .config import KevrosConfig
from .client import KevrosGovernanceClient
from .models import (
    Decision, IntentType, IntentSource, OutcomeStatus,
    VerifyRequest, VerifyResponse,
    AttestRequest, AttestResponse,
    BindIntentRequest, BindIntentResponse,
    VerifyOutcomeRequest, VerifyOutcomeResponse,
)

from .middleware import KevrosGovernanceMiddleware, GovernanceDeniedException
from .function_middleware import KevrosFunctionMiddleware

# Embedded provider requires gateway internals (pip install kevros-agent-framework[embedded])
try:
    from .embedded import EmbeddedGovernanceProvider
except ImportError:
    EmbeddedGovernanceProvider = None  # type: ignore[assignment,misc]

__all__ = [
    "KevrosConfig",
    "KevrosGovernanceClient",
    "KevrosGovernanceMiddleware",
    "KevrosFunctionMiddleware",
    "GovernanceDeniedException",
    "EmbeddedGovernanceProvider",
    "Decision", "IntentType", "IntentSource", "OutcomeStatus",
    "VerifyRequest", "VerifyResponse",
    "AttestRequest", "AttestResponse",
    "BindIntentRequest", "BindIntentResponse",
    "VerifyOutcomeRequest", "VerifyOutcomeResponse",
]

from importlib.metadata import version as _meta_version, PackageNotFoundError

try:
    __version__ = _meta_version("kevros-agent-framework")
except PackageNotFoundError:
    __version__ = "0.0.0-dev"
