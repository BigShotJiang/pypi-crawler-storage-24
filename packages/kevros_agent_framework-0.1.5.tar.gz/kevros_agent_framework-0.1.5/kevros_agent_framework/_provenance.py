"""
Build provenance record — auto-generated, do not edit.

This file is embedded by the CI/CD pipeline at build time.
It provides hash verification and optional cryptographic
signature verification for this package distribution.
"""

PROVENANCE = {
    'schema_version': '1.0',
    'artifact_hash': 'sha512:8a6dec0c1bab660e36fea20b6c5d3805d1b7963d7398b262decdbe830d610ebaa8d6dfa928b9097a5d14d7b775c8f4f3d2f42475c479bd5352810e2a76e32d17',
    'version': '0.1.5',
    'registry': 'pypi',
    'package_name': 'kevros-agent-framework',
    'build_timestamp': '2026-03-23T21:22:09Z',
    'build_host_hash': 'sha256:662b791465090e83f3f5d452c444c6d307bbda0b81137b466308aac435ab32db',
    'git_commit': 'cef095d425edcea4add4a56f2966aa901c580938',
    'git_branch': 'sdk-v0.3.10',
    'signer': 'github-actions-oidc',
    'signature_algorithm': '',
    'signature': '',
    'public_key': '',
    'dependencies_hash': 'sha256:8408f01b9ba9053715a034f467fa5eb9e5326759dcb6fababe1801fb67383a6a',
}


def get_provenance() -> dict:
    """Return a copy of the build provenance record."""
    return dict(PROVENANCE)
