# kevros-agent-framework

Kevros governance middleware for Microsoft AutoGen and Semantic Kernel agents. Cryptographic action verification, intent binding, and hash-chained provenance for multi-agent workflows. Fail-closed by default.

## Installation

```bash
pip install kevros-agent-framework
```

Requires `autogen-agentchat` or `semantic-kernel` as a peer dependency.

## Quick Start (AutoGen)

```python
from autogen import AssistantAgent, UserProxyAgent
from kevros_agent_framework import KevrosMiddleware

# Initialize middleware
middleware = KevrosMiddleware(api_key="your-kevros-api-key")

assistant = AssistantAgent(
    name="governed_agent",
    llm_config={"model": "gpt-4"}
)

# Wrap the agent with Kevros governance
governed_assistant = middleware.wrap(assistant)
```

## Quick Start (Semantic Kernel)

```python
import semantic_kernel as sk
from kevros_agent_framework import KevrosFilter

kernel = sk.Kernel()
kevros_filter = KevrosFilter(api_key="your-kevros-api-key")

# Register as a function invocation filter
kernel.add_filter("function_invocation", kevros_filter)
```

## How It Works

The middleware intercepts every agent action before execution and routes it through Kevros governance:

```
Agent proposes action
    |
    v
KevrosMiddleware.verify(action)
    |
    +-- ALLOW --> execute --> attest(result) --> hash-chained log
    |
    +-- CLAMP --> execute with bounded parameters --> attest
    |
    +-- DENY --> block execution, return reason to agent
```

Every decision is cryptographically signed. Every attestation links to the previous one via SHA-256 chain. The full provenance trail is exportable as a compliance bundle.

## Governance Endpoints

| Endpoint | Price | Description |
|---|---|---|
| `/governance/verify` | $0.01 | Action verification. Signed ALLOW, CLAMP, or DENY. |
| `/governance/attest` | $0.02 | Hash-chained provenance attestation. |
| `/governance/bind` | $0.02 | Cryptographic intent-to-command binding proof. |
| `/governance/bundle` | $0.05 | Compliance evidence export for audit. |
| `/shield/scan` | $0.01 | Threat detection and input validation. |
| `/media/attest` | $0.05 | PQC-signed media attestation certificate. |
| `/governance/batch` | $0.01 | Batch operations. Multiple calls, one request. |

## Multi-Agent Governance

In multi-agent workflows (AutoGen GroupChat, Semantic Kernel multi-agent orchestration), Kevros governs each agent independently. Every agent in the group gets its own provenance chain.

```python
from autogen import GroupChat, GroupChatManager
from kevros_agent_framework import KevrosMiddleware

middleware = KevrosMiddleware(api_key="your-kevros-api-key")

# Each agent gets its own governance context
researcher = middleware.wrap(researcher_agent)
analyst = middleware.wrap(analyst_agent)
writer = middleware.wrap(writer_agent)

group_chat = GroupChat(
    agents=[researcher, analyst, writer],
    messages=[]
)
```

Each agent's actions are verified, attested, and logged to its own hash chain. Cross-agent interactions generate linked attestations for full traceability.

## Configuration

```python
middleware = KevrosMiddleware(
    api_key="your-kevros-api-key",
    base_url="https://governance.taskhawktech.com",  # default
    fail_closed=True,    # default; DENY on any error
    auto_attest=True,    # default; attest every ALLOW automatically
    auto_bind=False      # optional; bind intent on every action
)
```

## Environment Variables

```
KEVROS_API_KEY=your-kevros-api-key
KEVROS_BASE_URL=https://governance.taskhawktech.com
```

## Payment Protocols

| Protocol | Rail | Settlement |
|---|---|---|
| x402 | USDC on Base | Per-call. Coinbase Commerce + Cloudflare. |
| L402 | Lightning Network | Per-call. Instant sats. |
| MPP / Stripe Tempo | Fiat (USD) | Subscription or credit packs. |

## Pricing

| Tier | Monthly | Included Calls |
|---|---|---|
| Free | $0 | 1,000 |
| Scout | $29 | 5,000 |
| Sentinel | $149 | 50,000 |
| Sovereign | $499 | 500,000 |

1,000 calls/month free. No credit card required.

## Links

| Resource | URL |
|---|---|
| Kevros Gateway | https://governance.taskhawktech.com |
| Microsoft AutoGen | https://github.com/microsoft/autogen |
| Semantic Kernel | https://github.com/microsoft/semantic-kernel |
| API Docs | https://governance.taskhawktech.com/docs |
| Status | https://governance.taskhawktech.com/status |

## License

Proprietary. Copyright 2026 TaskHawk Systems, LLC.

CAGE Code 10YV4. SAM.gov registered. NIST 800-171 / DFARS 252.204-7012 aligned.

## Contact

j.mcgraw@taskhawktech.com

+JM
