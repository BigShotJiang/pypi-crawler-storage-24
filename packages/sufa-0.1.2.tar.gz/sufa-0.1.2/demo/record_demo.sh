#!/bin/bash
# sufa Demo - Scanning http://testphp.vulnweb.com/

echo ""
echo "========================================================="
echo "   sufa - AI-Powered Vulnerability Scanner"
echo "   Demo: Scanning testphp.vulnweb.com"
echo "========================================================="
echo ""
sleep 2

echo "[Step 1] Check AI Provider"
echo '$ sufa provider test'
sufa provider test 2>/dev/null
echo ""
sleep 2

echo "[Step 2] Create a Project"
echo '$ sufa project create "Vulnweb Audit"'
sufa project create "Vulnweb Audit" 2>/dev/null
echo ""
sleep 2

echo "[Step 3] Scan the homepage"
echo '$ sufa scan http://testphp.vulnweb.com/'
sufa scan http://testphp.vulnweb.com/ 2>/dev/null
echo ""
sleep 2

echo "[Step 4] Scan login page"
echo '$ sufa scan http://testphp.vulnweb.com/login.php'
sufa scan http://testphp.vulnweb.com/login.php 2>/dev/null
echo ""
sleep 2

echo "[Step 5] Scan a page with parameters (SQL injection target)"
echo '$ sufa scan http://testphp.vulnweb.com/listproducts.php?cat=1'
sufa scan "http://testphp.vulnweb.com/listproducts.php?cat=1" 2>/dev/null
echo ""
sleep 2

echo "[Step 6] Scan search page"
echo '$ sufa scan http://testphp.vulnweb.com/search.php?test=query'
sufa scan "http://testphp.vulnweb.com/search.php?test=query" 2>/dev/null
echo ""
sleep 2

echo "[Step 7] View all findings"
echo '$ sufa findings list'
sufa findings list 2>/dev/null
echo ""
sleep 2

echo "[Step 8] Generate HTML report"
echo '$ sufa report generate --format html --output vulnweb_report.html'
sufa report generate --format html --output /tmp/vulnweb_report.html 2>/dev/null
echo ""
sleep 2

echo "[Step 9] Generate JSON report"
echo '$ sufa report generate --format json --output vulnweb_report.json'
sufa report generate --format json --output /tmp/vulnweb_report.json 2>/dev/null
echo ""
sleep 2

echo "========================================================="
echo "   Demo Complete!"
echo "   GitHub:  github.com/sufiyansaidsha/sufaAI"
echo "   Install: pip install sufa"
echo "   Docker:  docker pull sufaai/sufaai:0.1.0"
echo "========================================================="
echo ""
sleep 3
