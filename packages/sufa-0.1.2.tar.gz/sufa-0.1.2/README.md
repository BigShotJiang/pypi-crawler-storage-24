# sufa

AI-powered web vulnerability analysis platform.

sufa combines AI reasoning, traditional scanning techniques, attack chain discovery, and pentester workflows into a unified CLI tool with Burp Suite integration.

## Features

- **AI-Powered Analysis** -- Passive and active vulnerability detection using Ollama, OpenAI, Claude, or Gemini
- **Central Traffic Store** -- Persist, replay, and analyze HTTP traffic
- **Smart Deduplication** -- Endpoint normalization prevents redundant analysis
- **Attack Chain Discovery** -- AI connects individual findings into multi-step attack paths
- **Event-Driven Architecture** -- Extensible plugin system with publish/subscribe events
- **Data Redaction** -- Automatically strips sensitive data before sending to AI providers
- **Multiple Report Formats** -- JSON, HTML, PDF, SARIF for CI/CD integration

## Quick Start

```bash
pip install sufa

# Configure AI provider
sufa config set ai.provider ollama
sufa config set ai.model deepseek-r1:latest

# Test connectivity
sufa provider test

# Scan a target
sufa scan https://target.example.com

# View findings
sufa findings list

# Generate report
sufa report generate --format html
```

## CLI Commands

```
sufa scan <url>                    Passive scan a target
sufa scan --profile deep <url>     Deep scan with active verification
sufa proxy start --port 8080       Start intercept proxy
sufa import <file.har>             Import HAR file for analysis
sufa replay <request-id>           Replay a stored request
sufa findings list                 List all findings
sufa findings chains               Show discovered attack chains
sufa report generate --format pdf  Generate report
sufa project create "name"         Create a project
sufa config set <key> <value>      Set configuration
sufa provider test                 Test AI provider connectivity
sufa server start                  Start API server (Enterprise)
```

## AI Providers

| Provider | Local | Cost |
|----------|-------|------|
| Ollama   | Yes   | Free |
| OpenAI   | No    | Paid |
| Claude   | No    | Paid |
| Gemini   | No    | Paid |

## Documentation

For the complete usage guide covering all commands, configuration, plugins, Docker, Burp Suite integration, and more:

**[Full Usage Guide](docs/USAGE.md)**

## Development

```bash
pip install -e ".[dev,all]"
pytest
```

## License

MIT
