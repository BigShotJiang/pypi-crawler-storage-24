"""HTML form and parameterized link extraction for vulnerability discovery."""

from __future__ import annotations

import re
from dataclasses import dataclass, field
from html.parser import HTMLParser
from urllib.parse import urljoin, urlparse


@dataclass
class FormField:
    """A single form field (input, textarea, select)."""

    name: str
    field_type: str = "text"
    value: str = ""


@dataclass
class FormData:
    """A discovered HTML form with its fields."""

    action: str
    method: str = "GET"
    fields: list[FormField] = field(default_factory=list)
    enctype: str = "application/x-www-form-urlencoded"


class _FormParser(HTMLParser):
    """HTML parser that extracts form elements and their fields."""

    def __init__(self) -> None:
        super().__init__()
        self.forms: list[dict] = []
        self._current: dict | None = None

    def handle_starttag(
        self, tag: str, attrs: list[tuple[str, str | None]]
    ) -> None:
        a = {k: (v or "") for k, v in attrs}
        tag = tag.lower()

        if tag == "form":
            self._current = {
                "action": a.get("action", ""),
                "method": a.get("method", "GET").upper(),
                "enctype": a.get(
                    "enctype", "application/x-www-form-urlencoded"
                ),
                "fields": [],
            }
            return

        if self._current is None:
            return

        if tag == "input":
            name = a.get("name", "")
            input_type = a.get("type", "text").lower()
            if name and input_type not in (
                "submit", "button", "image", "reset",
            ):
                self._current["fields"].append({
                    "name": name,
                    "type": input_type,
                    "value": a.get("value", ""),
                })
        elif tag == "textarea":
            name = a.get("name", "")
            if name:
                self._current["fields"].append(
                    {"name": name, "type": "textarea", "value": ""}
                )
        elif tag == "select":
            name = a.get("name", "")
            if name:
                self._current["fields"].append(
                    {"name": name, "type": "select", "value": ""}
                )

    def handle_endtag(self, tag: str) -> None:
        if tag.lower() == "form" and self._current is not None:
            self.forms.append(self._current)
            self._current = None


def extract_forms(html: str, base_url: str) -> list[FormData]:
    """Extract all forms and their input fields from HTML content."""
    parser = _FormParser()
    try:
        parser.feed(html)
    except Exception:
        return []

    results = []
    for f in parser.forms:
        action = (
            urljoin(base_url, f["action"]) if f["action"] else base_url
        )
        fields = [
            FormField(
                name=fd["name"],
                field_type=fd["type"],
                value=fd["value"],
            )
            for fd in f["fields"]
        ]
        if fields:
            results.append(FormData(
                action=action,
                method=f["method"],
                fields=fields,
                enctype=f["enctype"],
            ))
    return results


_PARAM_LINK_RE = re.compile(
    r'href=["\']([^"\']*\?[^"\']+)["\']', re.IGNORECASE
)


def extract_parameterized_links(
    html: str, base_url: str
) -> list[str]:
    """Extract links that contain query parameters (high-value targets)."""
    links: set[str] = set()
    for match in _PARAM_LINK_RE.finditer(html):
        href = match.group(1)
        if href.startswith(("#", "mailto:", "tel:", "javascript:")):
            continue
        absolute = urljoin(base_url, href)
        parsed = urlparse(absolute)
        if parsed.query and parsed.scheme in ("http", "https"):
            links.add(absolute)
    return sorted(links)


_TEST_VALUES: dict[str, str] = {
    "text": "test123",
    "search": "test123",
    "url": "http://test.com",
    "tel": "1234567890",
    "email": "test@test.com",
    "password": "TestPass123!",
    "number": "1",
    "range": "50",
    "textarea": "test content here",
    "select": "1",
    "hidden": "",
    "checkbox": "on",
    "radio": "on",
    "date": "2024-01-01",
}


def build_form_test_data(form: FormData) -> dict[str, str]:
    """Build a dict of test values for submitting a form."""
    data: dict[str, str] = {}
    for f in form.fields:
        if f.field_type == "file":
            continue
        if f.field_type == "hidden" and f.value:
            data[f.name] = f.value
        else:
            data[f.name] = _TEST_VALUES.get(f.field_type, "test123")
    return data
