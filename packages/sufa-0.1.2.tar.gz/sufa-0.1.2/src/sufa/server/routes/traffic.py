"""API routes for traffic management and Burp bridge ingestion."""

from __future__ import annotations

import asyncio
from urllib.parse import urlparse

from fastapi import APIRouter, HTTPException
from pydantic import BaseModel

from sufa.burp.bridge import parse_burp_traffic
from sufa.core.db import Repository
from sufa.core.events import EventBus
from sufa.core.traffic import TrafficStore
from sufa.core.utils.logging import get_logger

router = APIRouter()
logger = get_logger(__name__)

BURP_SCAN_ID = "burp-live"


class TrafficPayload(BaseModel):
    request: dict
    response: dict | None = None
    source: str = "api"


def _get_or_create_burp_scan(repo: Repository, base_url: str):
    """Get or create the live Burp scan for real-time analysis."""
    from sufa.core.models import Scan, ScanStatus, ScanType
    from sufa.core.models.scan import ScanProfile

    scan = repo.get_scan(BURP_SCAN_ID)
    if scan:
        return scan
    scan = Scan(
        id=BURP_SCAN_ID,
        target_url=base_url,
        scan_type=ScanType.PASSIVE,
        profile=ScanProfile.STANDARD,
        status=ScanStatus.RUNNING,
        project_id="",
    )
    repo.save_scan(scan)
    return scan


async def _analyze_traffic_background(entry_id: str) -> None:
    """Run AI analysis on a traffic entry in the background."""
    from sufa.core.ai.cost import CostTracker
    from sufa.core.ai.router import AIRouter
    from sufa.core.dedup import Deduplicator
    from sufa.core.scanner.passive import PassiveScanner
    from sufa.core.scanner.profiles import get_profile
    from sufa.core.scanner.scope import ScopeManager
    from sufa.core.utils.config import SufaConfig

    repo = Repository()
    entry = repo.get_traffic(entry_id)
    if not entry or not entry.response or entry.response.status_code == 0:
        return

    scan = repo.get_scan(BURP_SCAN_ID)
    if not scan:
        return

    config = SufaConfig()
    router = AIRouter(config)
    scope = ScopeManager()
    scope.set_target(entry.request.url)
    dedup = Deduplicator()
    cost = CostTracker()
    profile = get_profile("standard")

    scanner = PassiveScanner(
        router=router,
        repo=repo,
        event_bus=EventBus(),
        deduplicator=dedup,
        scope=scope,
        cost_tracker=cost,
        confidence_threshold=profile.confidence_threshold,
    )

    try:
        findings = await scanner.analyze_traffic(entry, scan)
        for f in findings:
            repo.save_finding(f)
        scan.stats.findings_count += len(findings)
        scan.stats.analyzed += 1
        repo.save_scan(scan)
        if findings:
            logger.info(
                "burp_analysis_complete",
                url=entry.request.url[:80],
                findings=len(findings),
            )
    except Exception:
        logger.exception("burp_analysis_error", url=entry.request.url[:80])
        scan.stats.errors += 1
        repo.save_scan(scan)
    finally:
        repo.close()


@router.post("/traffic")
async def ingest_traffic(
    payload: TrafficPayload,
    analyze: bool = True,
):
    """Receive traffic from external sources (Burp bridge, API clients).

    When analyze=true (default), runs AI vulnerability analysis in the
    background. Findings appear in GET /api/v1/findings?scan_id=burp-live
    """
    entry = parse_burp_traffic(payload.model_dump())
    if not entry.response or entry.response.status_code == 0:
        return {"id": entry.id, "url": entry.request.url, "analyzing": False}

    repo = Repository()
    bus = EventBus()
    parsed = urlparse(entry.request.url)
    base_url = f"{parsed.scheme}://{parsed.netloc}"
    scan = _get_or_create_burp_scan(repo, base_url)
    entry.scan_id = scan.id
    store = TrafficStore(repo, bus)
    store.store(entry)

    if analyze:
        asyncio.create_task(_analyze_traffic_background(entry.id))

    return {
        "id": entry.id,
        "url": entry.request.url,
        "scan_id": scan.id,
        "analyzing": analyze,
    }


@router.get("/traffic")
async def list_traffic(
    scan_id: str = "",
    host: str = "",
    limit: int = 50,
):
    """List stored traffic entries."""
    repo = Repository()
    entries = repo.list_traffic(scan_id=scan_id, host=host, limit=limit)
    return [
        {
            "id": e.id,
            "method": e.request.method.value,
            "url": e.request.url,
            "host": e.request.host,
            "status_code": e.response.status_code if e.response else 0,
            "timestamp": e.timestamp.isoformat(),
            "source": e.source,
        }
        for e in entries
    ]


@router.get("/traffic/{traffic_id}")
async def get_traffic(traffic_id: str):
    """Get a specific traffic entry."""
    repo = Repository()
    entry = repo.get_traffic(traffic_id)
    if not entry:
        raise HTTPException(status_code=404, detail="Traffic entry not found")
    return entry.model_dump()
