"""AI-powered payload generator for agentic pentesting."""

from __future__ import annotations

import json
import re

from sufa.core.ai.router import AIRouter
from sufa.core.http.normalizer import normalize_request_body, normalize_response_body
from sufa.core.http.redactor import redact_traffic_for_ai
from sufa.core.models import Finding, TrafficEntry
from sufa.core.utils.logging import get_logger

logger = get_logger(__name__)

PAYLOAD_PROMPT = """You are a security expert generating test payloads for
vulnerability verification.

A passive scan found: {title} ({cwe_id}) at {url}
Parameter to test: {parameter}

Given the request/response below, generate 3-5 specific payloads that would best
verify this vulnerability. Consider: database type (MySQL/PostgreSQL/MSSQL),
framework, response format, WAF evasion.
Payloads must be safe for testing (no destructive commands). Keep each payload under 200 chars.

HTTP Traffic:
{traffic_data}

Respond with ONLY a JSON object:
{{"payloads": ["payload1", "payload2", "payload3"]}}
"""


def _build_traffic_data(entry: TrafficEntry) -> str:
    """Build traffic summary for the payload generation prompt."""
    req = entry.request
    resp = entry.response

    req_body = normalize_request_body(req.body) if req.body else ""
    redacted_headers, redacted_body, redacted_url = redact_traffic_for_ai(
        req.headers,
        req_body,
        req.url,
    )

    data: dict = {
        "request": {
            "method": req.method.value,
            "url": redacted_url,
            "parameters": [
                {"name": p.name, "value": p.value[:100], "type": p.param_type}
                for p in req.parameters[:10]
            ],
        },
    }
    if redacted_body:
        data["request"]["body"] = redacted_body[:500]

    if resp and resp.status_code:
        resp_body = normalize_response_body(resp.body) if resp.body else ""
        resp_headers, resp_body_redacted, _ = redact_traffic_for_ai(
            resp.headers,
            resp_body,
            "",
        )
        data["response"] = {
            "status_code": resp.status_code,
            "body": resp_body_redacted[:800],
        }

    return json.dumps(data, indent=2)


def _parse_payloads(text: str) -> list[str]:
    """Extract payload list from AI response."""
    text = text.strip()
    text = re.sub(r"```(?:json)?\s*", "", text)
    text = text.rstrip("`")

    start = text.find("{")
    end = text.rfind("}") + 1
    if start < 0 or end <= start:
        return []

    try:
        data = json.loads(text[start:end])
        payloads = data.get("payloads", [])
        if isinstance(payloads, list):
            return [
                str(p).strip()[:500] for p in payloads if p and isinstance(p, (str, int, float))
            ]
    except (json.JSONDecodeError, TypeError):
        pass
    return []


class PayloadGenerator:
    """Generates context-aware payloads using AI."""

    def __init__(self, router: AIRouter) -> None:
        self._router = router

    async def generate(
        self,
        finding: Finding,
        entry: TrafficEntry,
        limit: int = 5,
    ) -> list[str]:
        """Generate payloads tailored to the finding and traffic context."""
        traffic_data = _build_traffic_data(entry)
        prompt = PAYLOAD_PROMPT.format(
            title=finding.title,
            cwe_id=finding.cwe_id,
            url=finding.url,
            parameter=finding.parameter,
            traffic_data=traffic_data,
        )

        response = await self._router.analyze(prompt)
        if not response.success:
            logger.warning(
                "payload_gen_failed",
                url=finding.url[:80],
                error=response.error[:100],
            )
            return []

        payloads = _parse_payloads(response.text)
        if payloads:
            logger.debug(
                "payloads_generated",
                count=len(payloads),
                url=finding.url[:80],
            )
        return payloads[:limit]
