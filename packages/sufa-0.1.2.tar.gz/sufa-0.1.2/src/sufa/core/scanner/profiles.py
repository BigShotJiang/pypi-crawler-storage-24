"""Scan profile definitions for quick, standard, and deep scans."""

from __future__ import annotations

from dataclasses import dataclass


@dataclass
class ScanProfileConfig:
    name: str
    max_concurrent_ai: int
    confidence_threshold: int
    max_request_body: int
    max_response_body: int
    enable_active: bool
    enable_crawler: bool
    crawl_depth: int
    crawl_max_pages: int
    ai_delay_seconds: float
    max_findings_per_endpoint: int
    enable_chain_analysis: bool


PROFILES: dict[str, ScanProfileConfig] = {
    "quick": ScanProfileConfig(
        name="quick",
        max_concurrent_ai=1,
        confidence_threshold=70,
        max_request_body=1000,
        max_response_body=1500,
        enable_active=False,
        enable_crawler=False,
        crawl_depth=0,
        crawl_max_pages=1,
        ai_delay_seconds=1.0,
        max_findings_per_endpoint=3,
        enable_chain_analysis=False,
    ),
    "standard": ScanProfileConfig(
        name="standard",
        max_concurrent_ai=2,
        confidence_threshold=50,
        max_request_body=2000,
        max_response_body=3000,
        enable_active=False,
        enable_crawler=True,
        crawl_depth=2,
        crawl_max_pages=25,
        ai_delay_seconds=2.0,
        max_findings_per_endpoint=10,
        enable_chain_analysis=False,
    ),
    "deep": ScanProfileConfig(
        name="deep",
        max_concurrent_ai=3,
        confidence_threshold=40,
        max_request_body=4000,
        max_response_body=6000,
        enable_active=True,
        enable_crawler=True,
        crawl_depth=3,
        crawl_max_pages=50,
        ai_delay_seconds=3.0,
        max_findings_per_endpoint=20,
        enable_chain_analysis=True,
    ),
}


def get_profile(name: str) -> ScanProfileConfig:
    return PROFILES.get(name.lower(), PROFILES["standard"])
