"""Configuration management for sufa."""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any

_DEFAULT_CONFIG: dict[str, Any] = {
    "ai.provider": "ollama",
    "ai.api_url": "http://localhost:11434",
    "ai.api_key": "",
    "ai.model": "deepseek-r1:latest",
    "ai.max_tokens": 4096,
    "ai.timeout": 120,
    "ai.priority": "ollama",
    "ai.num_ctx": 2048,
    "ai.max_concurrent": 1,
    "ai.request_delay": 2.0,
    "scan.confidence_threshold": 50,
    "scan.payload_mode": "hybrid",
    "scan.max_request_body": 2000,
    "scan.max_response_body": 3000,
    "scan.skip_extensions": (
        ".js,.css,.png,.jpg,.jpeg,.gif,.svg,.woff,.woff2,.ttf,.eot,.ico,.mp4,.mp3"
    ),
    "redact.enabled": True,
    "redact.patterns": "authorization,cookie,x-api-key,x-auth-token",
    "logging.verbose": False,
    "logging.level": "INFO",
    "project.name": "default",
    "project.db_path": "",
}

CONFIG_DIR = Path.home() / ".sufa"
CONFIG_FILE = CONFIG_DIR / "config.json"


class SufaConfig:
    """Manages sufa configuration with dot-notation keys."""

    def __init__(self, config_path: Path | None = None) -> None:
        self._path = config_path or CONFIG_FILE
        self._data: dict[str, Any] = dict(_DEFAULT_CONFIG)
        self._load()

    def _load(self) -> None:
        if self._path.exists():
            try:
                with open(self._path) as f:
                    stored = json.load(f)
                self._data.update(stored)
            except (json.JSONDecodeError, OSError):
                pass

    def save(self) -> None:
        self._path.parent.mkdir(parents=True, exist_ok=True)
        with open(self._path, "w") as f:
            json.dump(self._data, f, indent=2)

    def get(self, key: str, default: Any = None) -> Any:
        return self._data.get(key, default)

    def set(self, key: str, value: Any) -> None:
        if isinstance(value, str):
            if value.lower() in ("true", "false"):
                value = value.lower() == "true"
            else:
                try:
                    value = int(value)
                except ValueError:
                    try:
                        value = float(value)
                    except ValueError:
                        pass
        self._data[key] = value

        if key == "ai.provider" and isinstance(value, str):
            self._auto_configure_provider(value.lower())

        self.save()

    def _auto_configure_provider(self, provider: str) -> None:
        """Auto-set default API URL and model when switching providers."""
        from sufa.core.ai.router import PROVIDER_DEFAULTS

        defaults = PROVIDER_DEFAULTS.get(provider, {})
        if not defaults:
            return

        current_url = self._data.get("ai.api_url", "")
        is_default_url = any(
            current_url == d.get("api_url", "") for d in PROVIDER_DEFAULTS.values()
        )
        if is_default_url or not current_url:
            self._data["ai.api_url"] = defaults["api_url"]

        current_model = self._data.get("ai.model", "")
        is_default_model = any(
            current_model == d.get("model", "") for d in PROVIDER_DEFAULTS.values()
        )
        if is_default_model or not current_model:
            self._data["ai.model"] = defaults["model"]

        chain = self.priority_chain
        if provider not in chain:
            chain.insert(0, provider)
            self._data["ai.priority"] = ",".join(chain)

    def get_all(self) -> dict[str, Any]:
        return dict(self._data)

    def get_db_path(self) -> Path:
        custom = self._data.get("project.db_path")
        if custom:
            return Path(custom)
        return CONFIG_DIR / "sufa.db"

    @property
    def provider(self) -> str:
        return str(self._data.get("ai.provider", "ollama")).lower()

    @property
    def api_url(self) -> str:
        return str(self._data.get("ai.api_url", "http://localhost:11434"))

    @property
    def api_key(self) -> str:
        return str(self._data.get("ai.api_key", ""))

    @property
    def model(self) -> str:
        return str(self._data.get("ai.model", "deepseek-r1:latest"))

    @property
    def max_tokens(self) -> int:
        return int(self._data.get("ai.max_tokens", 4096))

    @property
    def timeout(self) -> int:
        return int(self._data.get("ai.timeout", 120))

    @property
    def priority_chain(self) -> list[str]:
        raw = str(self._data.get("ai.priority", "ollama"))
        return [p.strip().lower() for p in raw.split(",") if p.strip()]
