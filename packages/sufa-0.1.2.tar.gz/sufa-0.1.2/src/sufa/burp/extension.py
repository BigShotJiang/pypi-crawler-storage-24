"""Thin Jython bridge for Burp Suite integration.

This file is designed to be loaded as a Burp extension. It forwards traffic
to a running sufa instance over HTTP, keeping all intelligence in the Python 3 codebase.

Usage:
    1. Start sufa server: sufa server start --port 9000
    2. In Burp: Extender -> Extensions -> Add -> extension.py
    3. Browse your target through Burp (authenticated traffic is captured as-is)
    4. Traffic is forwarded and analyzed in real-time by the AI
    5. View findings: sufa findings list --scan burp-live
"""

# NOTE: This module uses Python 2/Jython compatible syntax for Burp compatibility.
# It communicates with the main sufa process (Python 3) via HTTP.

import json
import threading

import urllib2

SUFA_URL = "http://localhost:9000"


class BurpExtender:
    """Burp Suite extension that bridges to sufa."""

    def registerExtenderCallbacks(self, callbacks):
        self._callbacks = callbacks
        self._helpers = callbacks.getHelpers()
        callbacks.setExtensionName("sufa Bridge")
        callbacks.registerHttpListener(self)
        callbacks.registerContextMenuFactory(self)

        self._sufa_url = SUFA_URL
        self._enabled = True

        self.stdout = callbacks.getStdout()
        self._log("[sufa] Bridge extension loaded")
        self._log("[sufa] Forwarding traffic to: " + self._sufa_url)

    def processHttpMessage(self, toolFlag, messageIsRequest, messageInfo):
        if messageIsRequest:
            return
        if not self._enabled:
            return

        thread = threading.Thread(
            target=self._forward_traffic,
            args=(messageInfo,),
        )
        thread.daemon = True
        thread.start()

    def _forward_traffic(self, messageInfo):
        try:
            request_info = self._helpers.analyzeRequest(messageInfo)
            url = str(request_info.getUrl())
            method = str(request_info.getMethod())

            request_bytes = messageInfo.getRequest()
            response_bytes = messageInfo.getResponse()

            req_headers = {}
            for header in request_info.getHeaders():
                header = str(header)
                if ": " in header:
                    k, v = header.split(": ", 1)
                    req_headers[k] = v

            req_body = ""
            body_offset = request_info.getBodyOffset()
            if body_offset < len(request_bytes):
                req_body = self._helpers.bytesToString(request_bytes[body_offset:])

            resp_info = self._helpers.analyzeResponse(response_bytes) if response_bytes else None
            status_code = resp_info.getStatusCode() if resp_info else 0

            resp_headers = {}
            resp_body = ""
            if resp_info:
                for header in resp_info.getHeaders():
                    header = str(header)
                    if ": " in header:
                        k, v = header.split(": ", 1)
                        resp_headers[k] = v
                resp_body_offset = resp_info.getBodyOffset()
                if resp_body_offset < len(response_bytes):
                    raw_bytes = response_bytes[resp_body_offset:]
                    resp_body = self._helpers.bytesToString(raw_bytes)[:3000]

            payload = json.dumps(
                {
                    "request": {
                        "method": method,
                        "url": url,
                        "headers": req_headers,
                        "body": req_body[:2000],
                    },
                    "response": {
                        "status_code": status_code,
                        "headers": resp_headers,
                        "body": resp_body,
                    },
                    "source": "burp",
                }
            )

            req = urllib2.Request(
                self._sufa_url + "/api/v1/traffic",
                data=payload,
                headers={"Content-Type": "application/json"},
            )
            urllib2.urlopen(req, timeout=5)

        except Exception as e:
            self._log("[sufa] Error forwarding: " + str(e))

    def createMenuItems(self, invocation):
        from javax.swing import JMenuItem

        items = []
        item = JMenuItem("Analyze with sufa")
        item.addActionListener(lambda e: self._analyze_selected(invocation))
        items.append(item)
        return items

    def _analyze_selected(self, invocation):
        messages = invocation.getSelectedMessages()
        if not messages:
            return
        for msg in messages:
            self._forward_traffic(msg)
        self._log(f"[sufa] Sent {len(messages)} requests for analysis")

    def _log(self, msg):
        try:
            self.stdout.write((msg + "\n").encode())
        except Exception:
            pass
