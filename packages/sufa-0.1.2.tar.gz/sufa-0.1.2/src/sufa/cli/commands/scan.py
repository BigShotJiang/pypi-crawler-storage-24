"""CLI commands for scanning targets."""

from __future__ import annotations

import asyncio
from urllib.parse import urlparse

import httpx
import typer

from sufa.cli.display import (
    console,
    print_error,
    print_findings_table,
    print_info,
    print_success,
)

app = typer.Typer(no_args_is_help=True)


# ── Helpers ──────────────────────────────────────────────────────


def _build_entry(
    method: str,
    url: str,
    resp: httpx.Response,
    scan_id: str,
    source: str = "cli",
    body: str = "",
):
    """Build a TrafficEntry from an httpx response."""
    from sufa.core.http.parser import build_request, build_response
    from sufa.core.models import TrafficEntry

    req_model = build_request(
        method, str(resp.url), dict(resp.request.headers), body,
    )
    resp_model = build_response(
        resp.status_code, dict(resp.headers), resp.text,
    )
    return TrafficEntry(
        request=req_model,
        response=resp_model,
        scan_id=scan_id,
        source=source,
    )


async def _crawl_target(target: str, depth: int, max_pages: int):
    """Use the spider to discover URLs on the target."""
    from sufa.crawler.spider import Spider

    spider = Spider(max_depth=depth, max_pages=max_pages)
    discovered = await spider.crawl(target)
    return discovered


async def _submit_form(form, scan_id: str, client: httpx.AsyncClient):
    """Submit a form with test values and capture the response."""
    from sufa.crawler.form_extractor import build_form_test_data

    test_data = build_form_test_data(form)
    if not test_data:
        return None

    try:
        if form.method == "GET":
            resp = await client.get(form.action, params=test_data)
            body = ""
        else:
            resp = await client.post(form.action, data=test_data)
            body = "&".join(f"{k}={v}" for k, v in test_data.items())
        return _build_entry(
            form.method, form.action, resp, scan_id, "form", body,
        )
    except Exception:
        return None


async def _discover_js_endpoints(
    js_sources: list[tuple[str, str]],
    target: str,
    scan_id: str,
    client: httpx.AsyncClient,
    visited: set[str],
):
    """Extract API endpoints from collected JavaScript and fetch them."""
    from sufa.crawler.js_parser import extract_endpoints

    entries = []
    for content, base_url in js_sources:
        endpoints = extract_endpoints(content, target)
        for ep in endpoints:
            if ep in visited:
                continue
            visited.add(ep)
            parsed = urlparse(ep)
            if not parsed.netloc:
                continue
            try:
                resp = await client.get(ep)
                entries.append(
                    _build_entry("GET", ep, resp, scan_id, "js_discovery")
                )
            except Exception:
                continue
    return entries


async def _discover_api_specs(
    target: str, scan_id: str, client: httpx.AsyncClient, visited: set[str]
):
    """Try OpenAPI/GraphQL discovery and fetch discovered endpoints."""
    from urllib.parse import urljoin

    from sufa.crawler.api_discovery import (
        discover_graphql,
        discover_openapi,
        extract_graphql_operations,
        extract_openapi_endpoints,
    )

    entries = []

    spec = await discover_openapi(target)
    if spec:
        for ep in extract_openapi_endpoints(spec):
            url = urljoin(target, ep["path"])
            if url in visited:
                continue
            visited.add(url)
            try:
                resp = await client.request(ep["method"], url)
                entries.append(_build_entry(
                    ep["method"], url, resp, scan_id, "openapi",
                ))
            except Exception:
                continue

    gql = await discover_graphql(target)
    if gql:
        ops = extract_graphql_operations(gql)
        if ops:
            entries.append(_build_entry(
                "POST", target, httpx.Response(200), scan_id, "graphql",
            ))

    return entries


# ── Main scan pipeline ───────────────────────────────────────────


def _run_scan(
    target: str,
    profile_name: str,
    project_id: str,
    active_flag: bool,
    depth_override: int | None,
    max_pages_override: int | None,
    payload_mode_override: str | None = None,
) -> None:
    """Execute the full scan workflow."""
    from sufa.core.ai.cost import CostTracker
    from sufa.core.ai.router import AIRouter
    from sufa.core.db import Repository, init_db
    from sufa.core.dedup import Deduplicator
    from sufa.core.events import EventBus
    from sufa.core.models import Scan, ScanStatus, ScanType
    from sufa.core.scanner.passive import PassiveScanner
    from sufa.core.scanner.profiles import get_profile
    from sufa.core.scanner.scope import ScopeManager
    from sufa.core.traffic import TrafficStore
    from sufa.core.utils.config import SufaConfig
    from sufa.core.utils.logging import setup_logging

    config = SufaConfig()
    setup_logging(verbose=bool(config.get("logging.verbose")))

    profile = get_profile(profile_name)
    if depth_override is not None:
        profile.crawl_depth = depth_override
        profile.enable_crawler = depth_override > 0
    if max_pages_override is not None:
        profile.crawl_max_pages = max_pages_override

    init_db(config.get_db_path())
    repo = Repository()
    bus = EventBus()
    router = AIRouter(config)
    scope = ScopeManager()
    scope.set_target(target)
    dedup = Deduplicator()
    cost = CostTracker()

    scanner = PassiveScanner(
        router=router,
        repo=repo,
        event_bus=bus,
        deduplicator=dedup,
        scope=scope,
        cost_tracker=cost,
        confidence_threshold=profile.confidence_threshold,
    )

    scan = Scan(
        target_url=target,
        scan_type=ScanType.PASSIVE,
        profile=profile_name,
        project_id=project_id,
    )

    fetch_timeout = float(config.get("scan.fetch_timeout", 45))
    request_delay = float(config.get("ai.request_delay", 2.0))
    target_domain = urlparse(target).netloc

    async def full_scan() -> Scan:
        timeout = httpx.Timeout(fetch_timeout, connect=20)
        async with httpx.AsyncClient(
            timeout=timeout, follow_redirects=True, verify=False,
        ) as client:
            entries, js_sources = await _phase_collect(
                target, target_domain, profile, scan.id,
                client, scope,
            )

            if js_sources:
                visited = {e.request.url for e in entries}
                js_entries = await _discover_js_endpoints(
                    js_sources, target, scan.id, client, visited,
                )
                if js_entries:
                    print_info(
                        f"JS discovery: {len(js_entries)} API endpoints"
                    )
                    entries.extend(js_entries)

            if profile.enable_crawler:
                visited = {e.request.url for e in entries}
                api_entries = await _discover_api_specs(
                    target, scan.id, client, visited,
                )
                if api_entries:
                    print_info(
                        f"API discovery: {len(api_entries)} endpoints"
                    )
                    entries.extend(api_entries)

            store = TrafficStore(repo, bus)
            for entry in entries:
                store.store(entry)

            print_info(
                f"Analyzing {len(entries)} traffic entries with AI..."
            )

            scan.status = ScanStatus.RUNNING
            scan.stats.total_requests = len(entries)
            repo.save_scan(scan)

            for i, entry in enumerate(entries, 1):
                url_short = entry.request.url[:55]
                method = entry.request.method.value
                try:
                    findings = await scanner.analyze_traffic(
                        entry, scan
                    )
                    n = len(findings)
                    label = f"[{i}/{len(entries)}] {method} {url_short}"
                    if n > 0:
                        print_success(f"{label} — {n} finding(s)")
                    else:
                        console.print(
                            f"  [dim]{label} — clean[/dim]"
                        )
                except Exception:
                    scan.stats.errors += 1
                    console.print(
                        f"  [dim][{i}/{len(entries)}] {method} "
                        f"{url_short} — error[/dim]"
                    )
                await asyncio.sleep(request_delay)

            scan.status = ScanStatus.COMPLETED
            repo.save_scan(scan)

            if (
                (profile.enable_active or active_flag)
                and scan.stats.findings_count > 0
            ):
                await _phase_active(
                    scan, entries, repo, router, fetch_timeout, config,
                    payload_mode_override,
                )

            return scan

    result = asyncio.run(full_scan())

    print_success(
        f"Scan complete: {result.stats.analyzed} analyzed, "
        f"{result.stats.findings_count} findings, "
        f"{result.stats.skipped} skipped"
    )

    if result.stats.findings_count > 0:
        findings_list = repo.list_findings(scan_id=result.id)
        print_findings_table([f.model_dump() for f in findings_list])

    if cost.total_calls > 0:
        print_info(
            f"AI cost: ~${cost.estimated_cost_usd:.4f} "
            f"({cost.total_calls} calls)"
        )

    repo.close()


async def _phase_collect(
    target: str,
    target_domain: str,
    profile,
    scan_id: str,
    client: httpx.AsyncClient,
    scope,
):
    """Phase 1 & 2: Crawl, fetch pages, extract forms and links."""
    from sufa.crawler.form_extractor import (
        extract_forms,
        extract_parameterized_links,
    )

    entries = []
    js_sources: list[tuple[str, str]] = []
    visited: set[str] = set()
    form_count = 0
    param_link_count = 0

    urls = [target]
    if profile.enable_crawler and profile.crawl_depth > 0:
        print_info(
            f"Crawling (depth={profile.crawl_depth}, "
            f"max={profile.crawl_max_pages} pages)..."
        )
        discovered = await _crawl_target(
            target, profile.crawl_depth, profile.crawl_max_pages,
        )
        urls = list(dict.fromkeys(urls + discovered))
        print_info(f"Discovered {len(urls)} pages")

    print_info("Fetching pages and extracting forms...")

    for url in urls:
        if url in visited:
            continue
        visited.add(url)

        if scope.should_skip(url, ""):
            continue

        parsed = urlparse(url)
        if parsed.netloc != target_domain:
            continue

        try:
            resp = await client.get(url)
        except Exception:
            continue

        entry = _build_entry("GET", url, resp, scan_id, "crawl")
        entries.append(entry)

        ct = resp.headers.get("content-type", "")

        if "text/html" in ct:
            forms = extract_forms(resp.text, url)
            for form in forms:
                form_parsed = urlparse(form.action)
                if form_parsed.netloc != target_domain:
                    continue
                form_entry = await _submit_form(
                    form, scan_id, client,
                )
                if form_entry:
                    entries.append(form_entry)
                    form_count += 1

            param_links = extract_parameterized_links(resp.text, url)
            for link in param_links[:15]:
                if link in visited:
                    continue
                visited.add(link)
                link_parsed = urlparse(link)
                if link_parsed.netloc != target_domain:
                    continue
                try:
                    link_resp = await client.get(link)
                    entries.append(_build_entry(
                        "GET", link, link_resp, scan_id, "param_link",
                    ))
                    param_link_count += 1
                except Exception:
                    continue

        if "javascript" in ct or url.endswith(".js"):
            js_sources.append((resp.text, url))

    parts = []
    if form_count:
        parts.append(f"{form_count} forms")
    if param_link_count:
        parts.append(f"{param_link_count} parameterized links")
    if js_sources:
        parts.append(f"{len(js_sources)} JS files")
    if parts:
        print_info(f"Extracted: {', '.join(parts)}")

    return entries, js_sources


async def _phase_active(
    scan, entries, repo, router, timeout, config, payload_mode_override=None
):
    """Phase 3: Active verification of findings with parameters."""
    from sufa.core.scanner.active.engine import ActiveScanner

    findings_list = repo.list_findings(scan_id=scan.id)
    param_findings = [f for f in findings_list if f.parameter]
    if not param_findings:
        return

    mode = payload_mode_override or config.get("scan.payload_mode", "hybrid")
    print_info(
        f"Active verification: {len(param_findings)} findings "
        f"(payload mode: {mode})..."
    )

    active = ActiveScanner(
        router=router,
        timeout=timeout,
        config=config,
        payload_mode=payload_mode_override,
    )
    verified = 0

    for finding in param_findings:
        matching = [
            e for e in entries if finding.url == e.request.url
        ]
        if not matching:
            continue
        try:
            updated = await active.verify_finding(finding, matching[0])
            if updated.status == "confirmed":
                verified += 1
                repo.save_finding(updated)
        except Exception:
            continue

    if verified:
        print_success(f"Active verification confirmed {verified} findings")


# ── CLI command ──────────────────────────────────────────────────


@app.callback(invoke_without_command=True)
def scan_target(
    target: str = typer.Argument(..., help="Target URL to scan"),
    profile: str = typer.Option(
        "standard", "--profile", "-p",
        help="Scan profile: quick, standard, deep",
    ),
    project_id: str = typer.Option(
        "", "--project", help="Project ID to associate scan with",
    ),
    active: bool = typer.Option(
        False, "--active", "-a",
        help="Enable active scanning (payload injection)",
    ),
    depth: int = typer.Option(
        None, "--depth", "-d",
        help="Override crawl depth (0=no crawl)",
    ),
    max_pages: int = typer.Option(
        None, "--max-pages", "-m",
        help="Override max pages to crawl",
    ),
    payload_mode: str | None = typer.Option(
        None, "--payload-mode",
        help="Payload mode: static, agentic, or hybrid",
    ),
) -> None:
    """Scan a target URL for vulnerabilities."""
    if not target.startswith("http"):
        target = f"https://{target}"

    print_info(f"Starting scan: {target}")
    print_info(f"Profile: {profile}")

    try:
        _run_scan(
            target, profile, project_id, active,
            depth, max_pages, payload_mode,
        )
    except KeyboardInterrupt:
        print_error("Scan cancelled by user")
        raise typer.Exit(1)
    except Exception as e:
        msg = _friendly_error(e)
        print_error(f"Scan failed: {msg}")
        raise typer.Exit(1)


def _friendly_error(exc: Exception) -> str:
    """Turn common exceptions into human-readable messages."""
    name = type(exc).__name__
    text = str(exc).strip()
    if isinstance(exc, httpx.ConnectTimeout):
        return (
            "Connection timed out — target may be "
            "unreachable or behind a firewall"
        )
    if isinstance(exc, httpx.ReadTimeout):
        return (
            "Read timed out — server accepted the connection "
            "but didn't respond in time"
        )
    if isinstance(exc, httpx.ConnectError):
        return (
            f"Connection refused or DNS resolution failed "
            f"({text or name})"
        )
    if isinstance(exc, httpx.HTTPStatusError):
        return f"HTTP {exc.response.status_code} from target"
    return text or name
