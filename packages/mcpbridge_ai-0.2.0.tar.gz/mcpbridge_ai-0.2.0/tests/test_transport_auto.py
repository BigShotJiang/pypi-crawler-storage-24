from mcpbridge.transport.auto import detect_transport
from mcpbridge.transport.http_sse import HttpSseTransport
from mcpbridge.transport.stdio import StdioTransport
from mcpbridge.transport.streamable_http import StreamableHttpTransport
from mcpbridge.transport.websocket import WebSocketTransport


def test_detect_stdio_when_command_present():
    t = detect_transport(
        {
            "command": "python",
            "args": ["server.py"],
            "env": {},
            "headers": {},
            "timeout": 30,
        }
    )
    assert isinstance(t, StdioTransport)


def test_detect_websocket_by_scheme():
    t = detect_transport({"url": "ws://localhost:9000", "transport": "auto", "headers": {}, "timeout": 30})
    assert isinstance(t, WebSocketTransport)


def test_detect_http_sse_by_path():
    t = detect_transport({"url": "http://localhost:3000/sse", "transport": "auto", "headers": {}, "timeout": 30})
    assert isinstance(t, HttpSseTransport)


def test_default_to_streamable_http():
    t = detect_transport({"url": "http://localhost:3000", "transport": "auto", "headers": {}, "timeout": 30})
    assert isinstance(t, StreamableHttpTransport)

