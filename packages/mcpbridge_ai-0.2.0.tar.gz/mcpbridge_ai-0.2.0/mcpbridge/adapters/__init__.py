"""LLM provider adapters for mcpbridge.

Provider adapters are imported here so they can be re-exported from the
top-level `mcpbridge` package.
"""

from __future__ import annotations

from mcpbridge.adapters.base import BaseLLMAdapter
from mcpbridge.adapters.anthropic import AnthropicAdapter
from mcpbridge.adapters.azure_openai import AzureOpenAIAdapter
from mcpbridge.adapters.bedrock import BedrockAdapter
from mcpbridge.adapters.cohere import CohereAdapter
from mcpbridge.adapters.groq import GroqAdapter
from mcpbridge.adapters.gemini import GeminiAdapter
from mcpbridge.adapters.mistral import MistralAdapter
from mcpbridge.adapters.ollama import OllamaAdapter
from mcpbridge.adapters.openai import OpenAIAdapter
from mcpbridge.adapters.openai_compatible import OpenAICompatibleAdapter
from mcpbridge.adapters.together import TogetherAdapter

# The exports below are what __init__.py expects.
__all__ = [
    "BaseLLMAdapter",
    "AnthropicAdapter",
    "OpenAIAdapter",
    "GeminiAdapter",
    "MistralAdapter",
    "CohereAdapter",
    "GroqAdapter",
    "OllamaAdapter",
    "TogetherAdapter",
    "BedrockAdapter",
    "AzureOpenAIAdapter",
    "OpenAICompatibleAdapter",
]

