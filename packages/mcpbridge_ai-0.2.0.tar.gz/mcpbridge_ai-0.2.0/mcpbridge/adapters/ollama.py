"""Ollama adapter (local OpenAI-compatible /api/chat)."""

from __future__ import annotations

import httpx
import logging
from typing import Any

from mcpbridge.adapters._openai_style import (
    append_tool_results_openai,
    extract_text_openai,
    extract_tool_calls_openai,
    is_done_openai,
)
from mcpbridge.adapters.base import BaseLLMAdapter, ToolCall, ToolResult
from mcpbridge.config import LLMConfig
from mcpbridge.exceptions import ToolsNotSupportedError
from mcpbridge.utils.token_counter import estimate_messages_tokens

logger = logging.getLogger("mcpbridge")


class OllamaAdapter(BaseLLMAdapter):
    """Adapter for the local Ollama service."""

    def __init__(self, llm_config: LLMConfig) -> None:
        try:
            import ollama as _ollama  # noqa: F401
        except ImportError as e:
            raise ImportError("Missing `ollama` dependency. Install with: pip install mcpbridge[ollama]") from e

        self._provider = "ollama"
        self._model = llm_config.model
        self._base_url = (llm_config.base_url or "http://localhost:11434").rstrip("/")
        self._timeout = int(llm_config.timeout)

        self._temperature = float(llm_config.temperature)
        self._max_tokens = int(llm_config.max_tokens)
        self._top_p = llm_config.top_p
        self._stop_sequences = llm_config.stop_sequences
        self._extra_params = dict(llm_config.extra_params or {})

    @property
    def provider_name(self) -> str:
        return self._provider

    @property
    def supports_parallel_tool_calls(self) -> bool:
        return True

    @property
    def supports_system_prompt(self) -> bool:
        return False

    async def chat(self, messages: list[dict[str, Any]], tools: list[dict[str, Any]], system: str | None = None, **kwargs: Any) -> Any:
        if system and (not messages or messages[0].get("role") != "system"):
            messages = [{"role": "system", "content": system}, *messages]

        # Ollama does not use `temperature`? It does. Keep best-effort.
        payload: dict[str, Any] = {
            "model": self._model,
            "messages": messages,
            "stream": False,
            "tools": tools if tools else None,
            **self._extra_params,
        }
        if self._temperature is not None:
            payload["temperature"] = self._temperature
        payload["num_predict"] = self._max_tokens
        if self._top_p is not None:
            payload["top_p"] = self._top_p
        if self._stop_sequences:
            payload["stop"] = self._stop_sequences
        payload = {k: v for k, v in payload.items() if v is not None}

        url = f"{self._base_url}/api/chat"
        async with httpx.AsyncClient(timeout=self._timeout) as client:
            resp = await client.post(url, json=payload)
            # Ollama returns 200 with error object sometimes.
            if resp.status_code >= 400:
                raise httpx.HTTPStatusError("Ollama chat failed", request=resp.request, response=resp)
            data = resp.json()
            if isinstance(data, dict) and data.get("error") and "does not support tools" in str(data.get("error")):
                raise ToolsNotSupportedError("Ollama model does not support tools.")
            return data

    def extract_tool_calls(self, response: Any) -> list[ToolCall]:
        return extract_tool_calls_openai(response)

    def extract_text(self, response: Any) -> str:
        return extract_text_openai(response)

    def is_done(self, response: Any) -> bool:
        return is_done_openai(response)

    def append_tool_results(self, messages: list[dict[str, Any]], response: Any, tool_results: list[ToolResult]) -> list[dict[str, Any]]:
        return append_tool_results_openai(messages, response, tool_results)

    def count_tokens(self, messages: list[dict[str, Any]], system: str) -> int:
        return estimate_messages_tokens(messages, system, provider=self._provider)

