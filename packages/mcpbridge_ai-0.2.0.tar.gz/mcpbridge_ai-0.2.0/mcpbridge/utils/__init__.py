"""Utility helpers for mcpbridge."""

from __future__ import annotations

