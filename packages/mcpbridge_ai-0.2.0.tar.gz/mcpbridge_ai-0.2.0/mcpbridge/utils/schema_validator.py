"""JSON schema validation for tool arguments."""

from __future__ import annotations

from typing import Any

import jsonschema


def validate_tool_args(args: dict[str, Any], schema: dict[str, Any]) -> tuple[bool, str | None]:
    """Validate tool arguments against a JSON Schema.

    Returns:
        (is_valid, error_message_or_None)
    """
    if schema is None:
        return True, None
    if not isinstance(args, dict):
        return False, "Tool arguments must be an object"

    try:
        jsonschema.validate(instance=args, schema=schema)
        return True, None
    except jsonschema.ValidationError as e:
        return False, str(e)

