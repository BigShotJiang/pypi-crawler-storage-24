"""mcpbridge public package interface.

This package provides a production-ready universal bridge between MCP servers and LLM
providers.
"""

from __future__ import annotations

from mcpbridge.bridge import MCPBridge
from mcpbridge.exceptions import *  # noqa: F403
from mcpbridge.llm_router import LLMRouter
from mcpbridge.session import SessionManager

from mcpbridge.adapters import (
    AnthropicAdapter,
    AzureOpenAIAdapter,
    BedrockAdapter,
    CohereAdapter,
    GeminiAdapter,
    GroqAdapter,
    MistralAdapter,
    OllamaAdapter,
    OpenAIAdapter,
    OpenAICompatibleAdapter,
    TogetherAdapter,
)

__all__ = [
    "MCPBridge",
    "SessionManager",
    "LLMRouter",
    # Adapters
    "AnthropicAdapter",
    "OpenAIAdapter",
    "GeminiAdapter",
    "MistralAdapter",
    "CohereAdapter",
    "GroqAdapter",
    "OllamaAdapter",
    "TogetherAdapter",
    "BedrockAdapter",
    "AzureOpenAIAdapter",
    "OpenAICompatibleAdapter",
]

