"""LLM adapter router.

Maps a `BridgeConfig.llm.provider` string to the appropriate adapter class.
"""

from __future__ import annotations

from typing import Any

from mcpbridge.adapters import (
    AnthropicAdapter,
    AzureOpenAIAdapter,
    BedrockAdapter,
    CohereAdapter,
    GeminiAdapter,
    GroqAdapter,
    MistralAdapter,
    OllamaAdapter,
    OpenAIAdapter,
    OpenAICompatibleAdapter,
    TogetherAdapter,
)
from mcpbridge.config import BridgeConfig
from mcpbridge.exceptions import ProviderNotFoundError


class LLMRouter:
    """Resolve a configured LLM provider to an adapter instance."""

    def __init__(self, config: BridgeConfig) -> None:
        self._config = config

    def resolve(self) -> Any:
        """Return a configured `BaseLLMAdapter` instance."""
        provider = self._config.llm.provider
        llm_cfg = self._config.llm

        if provider == "anthropic":
            return AnthropicAdapter(llm_cfg)
        if provider == "openai":
            return OpenAIAdapter(llm_cfg)
        if provider == "gemini":
            return GeminiAdapter(llm_cfg)
        if provider == "mistral":
            return MistralAdapter(llm_cfg)
        if provider == "cohere":
            return CohereAdapter(llm_cfg)
        if provider == "groq":
            return GroqAdapter(llm_cfg)
        if provider == "ollama":
            return OllamaAdapter(llm_cfg)
        if provider == "together":
            return TogetherAdapter(llm_cfg)
        if provider == "bedrock":
            return BedrockAdapter(llm_cfg)
        if provider == "azure_openai":
            return AzureOpenAIAdapter(llm_cfg)
        if provider == "openai_compatible":
            return OpenAICompatibleAdapter(llm_cfg)

        raise ProviderNotFoundError(f"Unsupported llm provider: {provider}")

