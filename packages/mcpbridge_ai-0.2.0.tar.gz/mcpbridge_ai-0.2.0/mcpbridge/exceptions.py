"""Custom exceptions for mcpbridge.

These exceptions are used across configuration, transports, protocol handling,
LLM providers, and the agentic loop.
"""

from __future__ import annotations


class MCPBridgeError(Exception):
    """Base exception for all MCPBridge errors."""


## Config
class ConfigValidationError(MCPBridgeError):
    """Raised when bridge configuration fails validation."""


class ProviderNotFoundError(MCPBridgeError):
    """Raised when a requested LLM provider is unknown or unsupported."""


class ModelNotFoundError(MCPBridgeError):
    """Raised when a configured model is unknown/unsupported for a provider."""


class APIKeyMissingError(MCPBridgeError):
    """Raised when a required API key is missing for a provider."""


## Transport
class TransportError(MCPBridgeError):
    """Base exception for transport-layer errors."""


class TransportConnectionError(TransportError):
    """Raised when a transport cannot connect."""


class TransportDisconnectedError(TransportError):
    """Raised when an established transport disconnects unexpectedly."""


class TransportTimeoutError(TransportError):
    """Raised when a transport request times out."""


## MCP Protocol
class MCPProtocolError(MCPBridgeError):
    """Raised when MCP protocol messages are malformed or invalid."""


class MCPToolNotFoundError(MCPBridgeError):
    """Raised when an MCP tool cannot be found in the discovered registry."""


class MCPToolCallError(MCPBridgeError):
    """Raised when an MCP tool invocation fails (tool execution error)."""


class MCPSchemaValidationError(MCPBridgeError):
    """Raised when JSON schema validation fails for tool arguments/results."""


## LLM
class LLMError(MCPBridgeError):
    """Base exception for LLM-provider errors."""


class LLMRateLimitError(LLMError):
    """Raised when the LLM provider returns a rate limit error."""


class LLMAuthError(LLMError):
    """Raised when authentication with the LLM provider fails."""


class LLMContextLengthError(LLMError):
    """Raised when the model context length is exceeded."""


class ToolsNotSupportedError(LLMError):
    """Raised when the configured model/provider does not support tool calling."""


## Loop / Agentic
class MaxIterationsError(MCPBridgeError):
    """Raised when the loop reaches the configured max iterations."""


class LoopTimeoutError(MCPBridgeError):
    """Raised when the loop exceeds a configured timeout."""


class BridgeInUseError(MCPBridgeError):
    """Raised when a single bridge instance is used concurrently by two runs."""


class SessionLimitError(MCPBridgeError):
    """Raised when SessionManager exceeds its max sessions."""


__all__ = [
    "MCPBridgeError",
    # Config
    "ConfigValidationError",
    "ProviderNotFoundError",
    "ModelNotFoundError",
    "APIKeyMissingError",
    # Transport
    "TransportError",
    "TransportConnectionError",
    "TransportDisconnectedError",
    "TransportTimeoutError",
    # MCP Protocol
    "MCPProtocolError",
    "MCPToolNotFoundError",
    "MCPToolCallError",
    "MCPSchemaValidationError",
    # LLM
    "LLMError",
    "LLMRateLimitError",
    "LLMAuthError",
    "LLMContextLengthError",
    "ToolsNotSupportedError",
    # Loop
    "MaxIterationsError",
    "LoopTimeoutError",
    # Concurrency / Sessions
    "BridgeInUseError",
    "SessionLimitError",
]

