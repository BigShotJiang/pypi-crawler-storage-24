"""Transport layer for connecting to MCP servers."""

from __future__ import annotations

