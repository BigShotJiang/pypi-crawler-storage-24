"""Abstract MCP transport interfaces.

MCP uses JSON-RPC 2.0 messages. Transports are responsible for moving those
messages between the mcpbridge client and an MCP server.
"""

from __future__ import annotations

import abc
from typing import Any


class BaseTransport(abc.ABC):
    """Abstract base class for all MCP transports."""

    @abc.abstractmethod
    async def connect(self) -> None:
        """Connect to the MCP server (or spawn the process)."""

    @abc.abstractmethod
    async def send(self, message: dict[str, Any]) -> dict[str, Any]:
        """Send a JSON-RPC request and return the matching response."""

    @abc.abstractmethod
    async def send_notification(self, method: str, params: dict[str, Any]) -> None:
        """Send a JSON-RPC notification (no response expected)."""

    @abc.abstractmethod
    async def close(self) -> None:
        """Close the transport and release any resources."""

    @property
    @abc.abstractmethod
    def is_connected(self) -> bool:
        """Whether the transport is currently connected."""

