import pytest
import pandas as pd
import numpy as np
from rictsc import RICTSCClassifier

def test_classifier_init():
    """Verify that the classifier initializes with default settings."""
    model = RICTSCClassifier(seed=42)
    assert model.seed == 42
    assert model.is_fitted is False

def test_package_import():
    """Ensure the package version and main class are accessible."""
    import rictsc
    assert hasattr(rictsc, "__version__")
    assert hasattr(rictsc, "RICTSCClassifier")

print("Sanity test script created. Run 'pytest' to verify.")