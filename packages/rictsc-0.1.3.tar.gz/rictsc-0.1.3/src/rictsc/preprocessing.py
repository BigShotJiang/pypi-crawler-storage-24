# src/rictsc/preprocessing.py

import os
# Use relative import to access the utility class
from .utils.preprocessing_utils import LakeDataPreprocessor 

def define_paths():
    """Default paths for the Greenland SGL project as defined in the research."""
    return {
        "sentinel_nc": "data/all_lakes_2019_LS.nc",
        "carra_nc": "data/CARRA_GrIS_Dataset.nc",
        "geojson": "data/GrIS_lakes.geojson",
        "output_dir": "data/processed"
    }

def define_carra_variables():
    """Environmental variables used for causal discovery (albedo, humidity, pressure, etc.)."""
    return ["al", "r2", "sd", "sp", "sro", "sst", "t2m"]

def main():
    """
    CLI entry point. This allows users to run:
    'rictsc-preprocess' directly from the terminal.
    """
    paths = define_paths()
    carra_vars = define_carra_variables()

    # Initialize the processor using the internal utility class
    processor = LakeDataPreprocessor(
        sentinel_nc_path=paths["sentinel_nc"],
        carra_nc_path=paths["carra_nc"],
        geojson_path=paths["geojson"],
        output_dir=paths["output_dir"]
    )

    print("Starting RIC-TSC Preprocessing Pipeline...")
    
    # Step 1: Process satellite and reanalysis data into a combined CSV
    final_df = processor.process_all_lakes(carra_vars=carra_vars)

    # Step 2: Generate sanity check plots in the figures directory
    csv_path = os.path.join(paths["output_dir"], "all_lakes_timeseries.csv")
    sanity_output_dir = "figures/sanity_checks"
    processor.sanity_check_plot(csv_path, output_dir=sanity_output_dir)
    
    print(f"Preprocessing complete. Data saved to {paths['output_dir']}")

if __name__ == "__main__":
    main()