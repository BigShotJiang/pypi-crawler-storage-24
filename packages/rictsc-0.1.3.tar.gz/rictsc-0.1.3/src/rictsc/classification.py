import numpy as np
import pandas as pd
from sklearn.linear_model import RidgeClassifierCV
from sklearn.preprocessing import LabelEncoder
from sktime.transformations.panel.rocket import MiniRocket
from .utils.region_exp_utils import build_dataset

class RICTSCClassifier:
    """
    Robust Intervention-invariant Causal Time Series Classifier (RIC-TSC).
    Wraps the MiniRocket transformation and RidgeClassifierCV pipeline.
    """

    def __init__(self, seq_len=365, seed=42):
        """
        Initializes the classifier with a fixed sequence length and random seed.
        """
        self.seq_len = seq_len
        self.seed = seed
        self.rocket = MiniRocket(random_state=seed)
        self.clf = RidgeClassifierCV(alphas=np.logspace(-3, 3, 10))
        self.le = LabelEncoder()
        self.is_fitted = False

    def fit(self, df, feature_cols, label_col="label"):
        """
        Prepares the dataset and fits the MiniRocket and Ridge models.
        
        Args:
            df: DataFrame containing the causal time series.
            feature_cols: List of strings for the causal features.
            label_col: The target column for classification.
        """
        # Convert tabular data into the 3D format required by sktime
        X, y, self.le, _, _ = build_dataset(
            df, feature_cols, label_col, seq_len=self.seq_len
        )

        if X is None:
            raise ValueError("Dataset construction failed. Check sequence lengths.")

        # Fit the MiniRocket transform
        self.rocket.fit(X)
        X_transformed = self.rocket.transform(X)

        # Train the Ridge Classifier
        self.clf.fit(X_transformed, y)
        self.is_fitted = True
        return self

    def predict(self, df, feature_cols, label_col="label"):
        """
        Predicts labels for a given dataset using the fitted pipeline.
        """
        if not self.is_fitted:
            raise RuntimeError("Classifier must be fitted before calling predict.")

        X, _, _, _, _ = build_dataset(
            df, feature_cols, label_col, seq_len=self.seq_len, label_encoder=self.le
        )

        if X is None:
            raise ValueError("Dataset construction failed for prediction data.")

        X_transformed = self.rocket.transform(X)
        y_pred_encoded = self.clf.predict(X_transformed)
        
        return self.le.inverse_transform(y_pred_encoded)

    def get_classes(self):
        """Returns the original class labels from the LabelEncoder."""
        return self.le.classes_