import os
import pandas as pd
from .utils.causal_dataset_utils import (
    load_causal_parents,
    extract_regionwise_data,
    save_region_datasets
)

def get_default_config():
    """
    Returns the default file paths and configuration for causal feature extraction.
    """
    return {
        "causal_parents_path": "causality/Causal_Parents_of_HV_anom_by_Region.csv",
        "input_timeseries_path": "data/processed/all_lakes_timeseries.csv",
        "output_directory": "data/region_causal_datasets"
    }

def generate_causal_features(input_csv, parents_csv, output_dir):
    """
    Processes the full timeseries dataset to extract region-specific causal 
    features based on J-PCMCI+ discovery results.
    """
    df = pd.read_csv(input_csv)
    df["date"] = pd.to_datetime(df["date"])
    df = df.sort_values(["lake_id", "date"]).copy()

    # Generate dummy variables used as causal parents in specific regions
    df["t-dummy"] = df["date"].dt.dayofyear
    df["s-dummy"] = df["lake_id"].astype("category").cat.codes
    df["r-dummy"] = df["region"].astype("category").cat.codes

    # Load the mapping of lagged parents per region
    region_parents = load_causal_parents(parents_csv)

    # Iteratively process each region and save the resulting feature sets
    for region, parent_map in region_parents.items():
        print(f"Processing causal features for region: {region}")
        causal_df = extract_regionwise_data(df, region, parent_map)
        save_region_datasets(causal_df, region, output_dir)

def main():
    """
    Main execution logic for generating causal datasets.
    """
    config = get_default_config()
    
    if not os.path.exists(config["input_timeseries_path"]):
        print(f"Error: Input file not found at {config['input_timeseries_path']}")
        return

    generate_causal_features(
        input_csv=config["input_timeseries_path"],
        parents_csv=config["causal_parents_path"],
        output_dir=config["output_directory"]
    )
    print(f"Causal dataset generation complete. Files saved to {config['output_directory']}")

if __name__ == "__main__":
    main()