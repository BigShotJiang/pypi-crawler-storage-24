from .classification import RICTSCClassifier
from .preprocessing import main as run_preprocessing
from .causality import generate_causal_features

__version__ = "0.1.0"
__author__ = "Emam Hossain, Muhammad Hasan Ferdous, Devon Dunmire, Aneesh Subramanian, Md Osman Gani"

# Define what is accessible when a user imports * from the package
__all__ = [
    "RICTSCClassifier",
    "run_preprocessing",
    "generate_causal_features"
]