# -*- coding: utf-8 -*-

# Copyright (c) 2016-2026 by University of Kassel and Fraunhofer Institute for Energy Economics
# and Energy System Technology (IEE), Kassel. All rights reserved.

import os

from pandapower.__init__ import pp_dir
from pandapower.file_io import from_json


def ieee_european_lv_asymmetric(scenario="on_peak_566", **kwargs):
    """
    Loads the IEEE European LV network, a generic 0.416 kV network serviced by one 0.8 MVA MV/LV
    transformer station. The network supplies 906 LV buses and 55 1-PH loads
    The network layout is mostly radial.

    The data source can be found at https://cmte.ieee.org/pes-testfeeders/resources/

    The network can be loaded with three different scenarios for On-Peak and Off-Peak load
    which are defined by scaling factors for loads / generators.
    These scenarios are a good starting point for working with this
    network, but you are of course free to parametrize the network for your use case.

    The network also includes geographical information of lines and buses for plotting.

    Parameters:
        scenario (str, "on_peak_566"): defines the scaling for load and generation

                - "on_peak_566": 09:26 AM: On Peak (566 min)
                - "off_peak_1": 12:01 AM: Off Peak (1 min)
                - "off_peak_1440": 12:00 AM: Off Peak (1440 min)

    Returns:
         pandapowerNet: the ieee european low voltage asymmetric network

    EXAMPLE:
        >>> from pandapower.networks import ieee_european_lv_asymmetric
        >>> net = ieee_european_lv_asymmetric("off_peak_1")
    """
    if scenario == "off_peak_1":
        net = from_json(os.path.join(pp_dir, "networks", "IEEE_European_LV_Off_Peak_1.json"),
                        **kwargs)
    elif scenario == "on_peak_566":
        net = from_json(os.path.join(pp_dir, "networks", "IEEE_European_LV_On_Peak_566.json"),
                        **kwargs)
    elif scenario == "off_peak_1440":
        net = from_json(os.path.join(pp_dir, "networks", "IEEE_European_LV_Off_Peak_1440.json"),
                        **kwargs)
    else:
        raise ValueError(f"Unknown scenario {scenario} - chose 'on_peak_566', 'off_peak_1' or 'off_peak_1440'")
    return net
