# -*- coding: utf-8 -*-

# Copyright (c) 2016-2026 by University of Kassel and Fraunhofer Institute for Energy Economics
# and Energy System Technology (IEE), Kassel. All rights reserved.


import copy

import numpy as np
from scipy.io import savemat

from pandapower.converter.pypower import to_ppc

import logging

logger = logging.getLogger(__name__)


def to_mpc(net, filename=None, **kwargs):
    """
    This function converts a pandapower net to a matpower case files (.mat) version 2.
    Note: python is 0-based while Matlab is 1-based.

    Parameters:
        net: The pandapower net.
        filename (str, None): File path + name of the mat file which will be created. If None the mpc will only be
            returned

    Keyword Arguments:
        any: are passed to :func:`to_ppc`

    EXAMPLE:
        >>> from pandapower.converter.matpower import to_mpc
        >>> from pandapower.networks.power_system_test_cases import case9
        >>>
        >>> net = case9()
        >>> to_mpc(net, "case9.mat")
    """
    ppc = to_ppc(net, **kwargs)

    mpc = {}
    mpc["mpc"] = _ppc2mpc(ppc)
    if filename is not None:
        # savemat
        savemat(filename, mpc)

    return mpc


def _ppc2mpc(ppc):
    """
    Convert network in Pypower/Matpower format
    Convert 0-based python to 1-based Matlab

    **INPUT**:
        * net - The pandapower format network
        * filename - File path + name of the mat file which is created
    """

    # convert to matpower
    # Matlab is one-based, so all entries (buses, lines, gens) have to start with 1 instead of 0
    mpc = copy.deepcopy(ppc)
    if np.any(mpc["bus"][:, 0] == 0):
        mpc["bus"][:, 0] = mpc["bus"][:, 0] + 1
        mpc["gen"][:, 0] = mpc["gen"][:, 0] + 1
        mpc["branch"][:, 0:2] = mpc["branch"][:, 0:2] + 1
    # adjust for the matpower converter -> taps should be 0 when there is no transformer, but are 1
    mpc["branch"][mpc["branch"][:, 8] == 1, 8] = 0
    # version is a string
    mpc["version"] = str(mpc["version"])
    # baseMVA has to be a float instead of int
    mpc["baseMVA"] = mpc["baseMVA"] * 1.0
    return mpc