from bs4 import Tag


def btf(el: Tag, *args, **kwargs) -> Tag | None:
    """Typed bs4 find that returns Tag | None."""
    result = el.find(*args, **kwargs)
    return result if isinstance(result, Tag) else None


def btf_strict(el: Tag, *args, **kwargs) -> Tag:
    """Typed bs4 find that returns Tag (raises ValueError if not found)."""
    result = el.find(*args, **kwargs)
    if not isinstance(result, Tag):
        raise ValueError(f"Tag not found: {args}, {kwargs}")
    return result


def btfa(el: Tag, *args, **kwargs) -> list[Tag]:
    """Typed bs4 find_all that returns list of Tags."""
    return el.find_all(*args, **kwargs)
