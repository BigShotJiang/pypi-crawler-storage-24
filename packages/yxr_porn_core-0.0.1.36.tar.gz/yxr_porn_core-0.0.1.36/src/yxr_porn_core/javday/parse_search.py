import re
from typing import cast

from bs4 import BeautifulSoup
from pydantic import BaseModel

from yxr_porn_core.bs4_utils import btf, btfa


class ParseSearchItem(BaseModel):
    title: str
    cover_url: str
    likes: str
    views: str
    href: str


ParseSearchResult = list[ParseSearchItem]


# https://javday.tv/search/?wd=91cm-166
def parse_search(html: str) -> ParseSearchResult:
    soup = BeautifulSoup(html, "lxml")

    items = btfa(soup, "a", class_="videoBox")

    results: list[ParseSearchItem] = []
    for o in items:
        title_el = btf(o, class_="title")
        title = title_el.text.strip() if title_el else ""
        views_el = btf(o, class_="views")
        views_number = btf(views_el, class_="number") if views_el else None
        views = views_number.text.strip() if views_number else ""
        likes_el = btf(o, class_="likes")
        likes_number = btf(likes_el, class_="number") if likes_el else None
        likes = likes_number.text.strip() if likes_number else ""
        cover_el = btf(o, class_="videoBox-cover")
        style = cover_el.get("style", "") if cover_el else ""
        style_str = style if isinstance(style, str) else ""
        match = re.search(r"^background-image: url\((.*)\);$", style_str)
        cover_url = match.group(1) if match else ""
        href = cast("str", o.get("href", ""))
        results.append(
            ParseSearchItem(
                title=title,
                views=views,
                likes=likes,
                cover_url=cover_url,
                href=href,
            )
        )

    return results
