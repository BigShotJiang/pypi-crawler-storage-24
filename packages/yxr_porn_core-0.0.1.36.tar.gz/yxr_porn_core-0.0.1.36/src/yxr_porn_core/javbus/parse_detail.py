import re

from bs4 import BeautifulSoup
from pydantic import BaseModel

from yxr_porn_core.bs4_utils import btf, btf_strict, btfa


class AItem(BaseModel):
    text: str
    url: str


class DetailItem(BaseModel):
    title: str
    cover_url: str
    tags: list[AItem]
    artists: list[AItem]
    product_id: str
    date_str: str
    length: str
    director: str
    producers: str
    distributor: str
    torrents: list[AItem]
    sample_images: list[str]


def re_pick(s: str, regstr: str) -> str:
    res = re.search(regstr, s)
    return "" if res is None else res.group(1).strip()


def parse_detail(html: str) -> DetailItem:
    soup = BeautifulSoup(html, "lxml")
    container = btf_strict(soup, "div", class_="container")
    big_image_a = btf_strict(container, "a", class_="bigImage")
    big_image = btf_strict(big_image_a, "img")
    cover_url = big_image["src"]
    title = big_image["title"]
    info = btf_strict(container, "div", class_="info")
    info_text = info.text

    product_id = re_pick(info_text, "識別碼: (.*)")
    date_str = re_pick(info_text, "發行日期: (.*)")
    length = re_pick(info_text, "長度: (.*)分鐘")
    director = re_pick(info_text, "導演: (.*)")
    producers = re_pick(info_text, "製作商: (.*)")
    distributor = re_pick(info_text, "發行商: (.*)")

    genres = btfa(info, "label")
    tags = [
        AItem(text=o.text, url=href if isinstance((href := btf_strict(o, "a")["href"]), str) else "") for o in genres
    ]
    artists = [
        AItem(text=o.text, url=href if isinstance((href := btf_strict(o, "a")["href"]), str) else "")
        for o in btfa(info, "div", class_="star-name")
    ]

    sample_waterfall = btf(container, "div", id="sample-waterfall")
    sample_images: list[str] = []
    if sample_waterfall:
        for o in btfa(sample_waterfall, "a", class_="sample-box"):
            href_raw = o.get("href")
            if isinstance(href_raw, str):
                sample_images.append(href_raw)

    cover_url_val = cover_url if isinstance(cover_url, str) else ""
    title_val = title if isinstance(title, str) else ""
    return DetailItem(
        title=title_val,
        cover_url=cover_url_val,
        tags=tags,
        artists=artists,
        product_id=product_id,
        date_str=date_str,
        length=length,
        director=director,
        producers=producers,
        distributor=distributor,
        torrents=[],
        sample_images=sample_images,
    )
