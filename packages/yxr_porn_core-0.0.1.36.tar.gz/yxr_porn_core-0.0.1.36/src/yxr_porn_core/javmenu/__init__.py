from yxr_porn_core.javmenu.parse_code import StructPeople, parse_code

__all__ = ["StructPeople", "parse_code"]
