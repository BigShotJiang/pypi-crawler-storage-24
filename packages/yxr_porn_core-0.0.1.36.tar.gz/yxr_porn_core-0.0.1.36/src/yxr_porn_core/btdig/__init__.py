from bs4 import BeautifulSoup, Tag
from pydantic import BaseModel

from yxr_porn_core.bs4_utils import btf_strict, btfa


class FileItem(BaseModel):
    name: str
    size: str | None = None  # 可能为空（如目录）


class SearchResultItem(BaseModel):
    title: str
    url: str
    files_count: int
    total_size: str
    age: str
    file_list: list[FileItem]


# ================== Parse Functions ==================


def parse_search(html: str) -> list[SearchResultItem]:
    """Example html: https://en.btdig.com/search?q=MIMK-136"""
    soup = BeautifulSoup(html, "lxml")

    results: list[SearchResultItem] = []

    result_items = soup.find_all("div", class_="one_result")
    if not result_items:
        return results

    for item in result_items:
        # 标题和链接
        name_div = item.find("div", class_="torrent_name")
        a_tag = name_div.find("a") if name_div else None
        title = a_tag.get_text().strip() if a_tag else ""
        url = a_tag["href"] if a_tag and "href" in a_tag.attrs else ""

        # 文件数量
        files_count_span = item.find("span", class_="torrent_files")
        files_count = int(files_count_span.text.strip()) if files_count_span else 0

        # 总大小
        total_size_span = item.find("span", class_="torrent_size")
        total_size = total_size_span.text.strip() if total_size_span else ""

        # 时间
        age_span = item.find("span", class_="torrent_age")
        age = age_span.text.strip() if age_span else ""

        # 文件列表解析
        excerpt_div = item.find("div", class_="torrent_excerpt")
        file_list = []

        if excerpt_div:
            for div in btfa(excerpt_div, "div"):
                fa_class = div.get("class", [])
                if "fa-file" in " ".join(fa_class):
                    name = div.get_text().strip() or ""
                    size_span = div.find_next("span")
                    size = size_span.get_text().strip() if isinstance(size_span, Tag) else ""
                    if name:
                        file_list.append(FileItem(name=name, size=size))

        results.append(
            SearchResultItem(
                title=title,
                url=url,
                files_count=files_count,
                total_size=total_size,
                age=age,
                file_list=file_list,
            ),
        )

    return results


class TorrentInfo(BaseModel):
    name: str
    size: str
    age: str
    files: int


def parse_item(html_content: str) -> TorrentInfo:
    soup = BeautifulSoup(html_content, "lxml")

    name_td = btf_strict(soup, "td", string="Name:")
    name_sibling = name_td.find_next_sibling("td")
    name = name_sibling.get_text().strip() if isinstance(name_sibling, Tag) else ""
    size_td = btf_strict(soup, "td", string="Size:")
    size_sibling = size_td.find_next_sibling("td")
    size = size_sibling.get_text().strip() if isinstance(size_sibling, Tag) else ""
    age_td = btf_strict(soup, "td", string="Age:")
    age_sibling = age_td.find_next_sibling("td")
    age = age_sibling.get_text().strip() if isinstance(age_sibling, Tag) else ""
    files_td = btf_strict(soup, "td", string="Files:")
    files_sibling = files_td.find_next_sibling("td")
    files = int(files_sibling.get_text().strip()) if isinstance(files_sibling, Tag) else 0

    return TorrentInfo(name=name, size=size, age=age, files=files)
