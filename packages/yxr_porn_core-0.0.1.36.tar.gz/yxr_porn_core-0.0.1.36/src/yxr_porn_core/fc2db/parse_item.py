import logging
import re
from typing import cast

from bs4 import BeautifulSoup
from pydantic import BaseModel

from yxr_porn_core.bs4_utils import btf_strict, btfa

logger = logging.getLogger("yxr_porn_core.fc2db.parse_item")


class Actress(BaseModel):
    name: str = ""
    url: str = ""


class ParseItemResult(BaseModel):
    url: str = ""
    product_id: str = ""
    title: str = ""
    cover_url: str = ""
    actresses: list[Actress] = []
    release_date: str = ""  # yyyy-mm-dd
    length: str = ""  # hh:mm:ss or mm:ss
    seller: str = ""  # 作品贩售者
    tags: list[str] = []  # タグ: str
    error_code: str = ""  # 例如 "404 Not Found"


# https://fc2db.net/work/4821506/
def parse_item(html: str) -> ParseItemResult:
    soup = BeautifulSoup(html, "lxml")

    # 提取URL
    url = cast("str", btf_strict(soup, "link", rel="canonical").get("href"))

    # 提取产品ID数字
    product_id_num = ""
    product_id = ""

    pattern = r"/work/(\d+)"
    match = re.search(pattern, url)
    if match:
        product_id_num = cast("str", match.group(1))
    else:
        raise ValueError(f"URL {url} 不匹配模式 {pattern}")
    # 尝试从页面中的商品ID字段获取 - 从dl结构中提取

    product_id = f"FC2-{product_id_num}"

    # 提取标题
    title = ""
    h2_tags = btfa(soup, "h2")
    title = h2_tags[0].get_text().strip()

    # 提取封面图片
    cover_url = ""
    img_tags = btfa(soup, "img", class_="wp-post-image")
    src = img_tags[0].get("src", "")
    cover_url = src if isinstance(src, str) else ""

    actresses: list[Actress] = []
    for elem in soup.find_all(string=lambda text: text and "出演女優" in text):
        a_tags = btfa(elem.parent.parent, "a")
        for a in a_tags:
            name = a.get_text().strip()
            href = a.get("href", "")
            actresses.append(Actress(name=name, url=href if isinstance(href, str) else ""))

    # 提取发售日期、收录时长、作品贩售者
    release_date = ""
    length = ""
    seller = ""

    # 从dl结构中提取
    dl_tags = btfa(soup, "dl")
    for dl in dl_tags:
        dt_tags = btfa(dl, "dt")
        dd_tags = btfa(dl, "dd")
        for dt, dd in zip(dt_tags, dd_tags, strict=False):
            dt_text = dt.get_text().strip()
            dd_text = dd.get_text().strip()
            if "販売日" in dt_text:
                release_date = dd_text
            elif "収録時間" in dt_text:
                length = dd_text
            elif "作品販売者" in dt_text:
                # 提取卖家名称, 不包含图片
                seller = btf_strict(dd, "span").get_text().strip()

    # 提取tags
    tags: list[str] = [a.get_text().strip() for a in soup.find_all("a", href=re.compile(r"/work-tags/"))]

    return ParseItemResult(
        url=url,
        product_id=product_id,
        title=title,
        cover_url=cover_url,
        actresses=actresses,
        release_date=release_date,
        length=length,
        seller=seller,
        tags=tags,
    )
