﻿from __future__ import annotations

from concurrent.futures import ThreadPoolExecutor
import hashlib
import hmac
import json
import os
import ssl
import threading
import time
import urllib.error
import urllib.request
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from typing import Any, Callable
from urllib.parse import urlencode, urlparse


def _build_ssl_context() -> ssl.SSLContext:
    ca_bundle = os.environ.get("AGENT_HUB_CA_BUNDLE", "").strip()
    if ca_bundle:
        return ssl.create_default_context(cafile=ca_bundle)
    try:
        import certifi
        return ssl.create_default_context(cafile=certifi.where())
    except Exception:
        return ssl.create_default_context()

TaskHandler = Callable[[str, str], str | dict[str, Any]]
MAX_REQUEST_BYTES = 1_048_576  # 1 MiB hard limit


def _extract_text_from_hub_message(message: dict[str, Any]) -> str:
    parts = message.get("parts", []) if isinstance(message, dict) else []
    if not isinstance(parts, list):
        return json.dumps(message, ensure_ascii=True)

    texts: list[str] = []
    for part in parts:
        if isinstance(part, dict) and part.get("text"):
            texts.append(str(part["text"]))
    return "\n".join(texts).strip()


def parse_routed_payload(task_message: dict[str, Any]) -> tuple[str, str, dict[str, Any] | None]:
    raw_text = _extract_text_from_hub_message(task_message)
    query = ""
    user_input = raw_text
    envelope = None

    try:
        payload = json.loads(raw_text)
    except Exception:
        return query, user_input, envelope

    if not isinstance(payload, dict):
        return query, user_input, envelope

    args = payload.get("arguments")
    if isinstance(args, dict):
        query = str(args.get("query") or "")
        input_value = args.get("input")
        if isinstance(input_value, str):
            user_input = input_value
        elif input_value is not None:
            user_input = json.dumps(input_value, ensure_ascii=True)

    env = payload.get("a2a_envelope")
    if isinstance(env, dict):
        envelope = env

    return query, user_input, envelope


def _http_json(
    method: str,
    url: str,
    *,
    body: dict[str, Any] | None = None,
    timeout: float = 60.0,
    extra_headers: dict[str, str] | None = None,
) -> tuple[int, dict[str, Any] | list[Any] | str]:
    headers: dict[str, str] = {"Content-Type": "application/json"}
    if extra_headers:
        headers.update(extra_headers)

    data = json.dumps(body).encode("utf-8") if body is not None else None
    req = urllib.request.Request(url, data=data, headers=headers, method=method)

    try:
        with urllib.request.urlopen(req, timeout=timeout, context=_build_ssl_context()) as resp:
            raw = resp.read().decode("utf-8")
            try:
                return resp.status, json.loads(raw) if raw else {}
            except Exception:
                return resp.status, raw
    except urllib.error.HTTPError as exc:
        raw = exc.read().decode("utf-8", errors="replace")
        try:
            payload = json.loads(raw) if raw else {}
        except Exception:
            payload = raw
        return exc.code, payload
    except urllib.error.URLError as exc:
        reason = getattr(exc, "reason", exc)
        raise ConnectionError(f"request failed: {reason}") from exc


def _build_signature(token: str, timestamp: str, body_bytes: bytes) -> str:
    message = timestamp.encode("utf-8") + b"." + body_bytes
    digest = hmac.new(token.encode("utf-8"), message, hashlib.sha256).hexdigest()
    return f"sha256={digest}"


def _send_hub_callback(callback_url: str, callback_token: str, payload: dict[str, Any]) -> tuple[int, dict[str, Any] | list[Any] | str]:
    body_bytes = json.dumps(payload).encode("utf-8")
    ts = str(int(time.time()))
    sig = _build_signature(callback_token, ts, body_bytes)
    return _http_json(
        "POST",
        callback_url,
        body=payload,
        timeout=20.0,
        extra_headers={
            "X-Hub-Callback-Token": callback_token,
            "X-Hub-Timestamp": ts,
            "X-Hub-Signature": sig,
        },
    )


def _is_loopback(hostname: str | None) -> bool:
    return hostname in {"localhost", "127.0.0.1", "::1"}


def _is_loopback_bind_host(hostname: str) -> bool:
    return hostname.strip().lower() in {"localhost", "127.0.0.1", "::1"}


def _is_allowed_callback_url(callback_url: str, hub_url: str) -> bool:
    try:
        cb = urlparse(callback_url)
        hub = urlparse(hub_url)
    except Exception:
        return False

    if cb.scheme != hub.scheme:
        return False

    cb_port = cb.port or (443 if cb.scheme == "https" else 80)
    hub_port = hub.port or (443 if hub.scheme == "https" else 80)
    if cb_port != hub_port:
        return False

    if cb.hostname != hub.hostname:
        if not (_is_loopback(cb.hostname) and _is_loopback(hub.hostname)):
            return False

    return cb.path.startswith("/api/v1/tasks/") and cb.path.endswith("/callback")


def _to_error_payload(agent_name: str, exc: Exception, *, expose_error_details: bool) -> dict[str, Any]:
    error_text = (
        f"{agent_name} processing error: {type(exc).__name__}: {exc}"
        if expose_error_details
        else f"{agent_name} processing error"
    )
    return {
        "status": "failed",
        "error": error_text,
        "agent_name": agent_name,
    }


def _to_success_payload(agent_name: str, output: str | dict[str, Any]) -> dict[str, Any]:
    if isinstance(output, dict):
        payload = dict(output)
        payload.setdefault("status", "completed")
        payload.setdefault("agent_name", agent_name)
        return payload
    return {
        "status": "completed",
        "parts": [{"text": str(output)}],
        "agent_name": agent_name,
    }


def _extract_presented_api_key(headers: Any) -> str:
    auth_header = str(headers.get("Authorization", "")).strip()
    if auth_header.lower().startswith("bearer "):
        return auth_header[7:].strip()
    return str(headers.get("X-Agent-API-Key", "")).strip()


def _safe_preview(text: str, limit: int = 160) -> str:
    compact = " ".join(text.split())
    return compact[:limit]


class AgentServer:
    def __init__(
        self,
        *,
        name: str,
        port: int,
        bind_host: str = "127.0.0.1",
        hub_url: str,
        handler: TaskHandler,
        inbound_api_key: str | None = None,
        allow_insecure_bind: bool = False,
        max_request_bytes: int = MAX_REQUEST_BYTES,
        max_inflight_tasks: int = 32,
        expose_error_details: bool = False,
    ) -> None:
        self.name = name
        self.port = port
        self.bind_host = (bind_host or "127.0.0.1").strip()
        self.hub_url = hub_url
        self.handler = handler
        self.inbound_api_key = (inbound_api_key or "").strip()
        self.allow_insecure_bind = bool(allow_insecure_bind)
        self.max_request_bytes = max(1, int(max_request_bytes))
        self.max_inflight_tasks = max(1, int(max_inflight_tasks))
        self.expose_error_details = expose_error_details
        self._inflight = threading.BoundedSemaphore(self.max_inflight_tasks)
        self._executor = ThreadPoolExecutor(max_workers=self.max_inflight_tasks)

        if (
            not _is_loopback_bind_host(self.bind_host)
            and not self.inbound_api_key
            and not self.allow_insecure_bind
        ):
            raise ValueError(
                "Refusing non-loopback bind without inbound_api_key. "
                "Set inbound_api_key, or set allow_insecure_bind=True only for trusted networks."
            )

    def serve_forever(self) -> None:
        server = ThreadingHTTPServer((self.bind_host, self.port), self._build_handler())
        print(f"{self.name} running on http://{self.bind_host}:{self.port}")
        try:
            server.serve_forever()
        finally:
            self._executor.shutdown(wait=False, cancel_futures=True)

    def _build_handler(self):
        outer = self

        class Handler(BaseHTTPRequestHandler):
            def log_message(self, fmt: str, *args: Any) -> None:  # noqa: A003
                return

            def do_POST(self) -> None:  # noqa: N802
                if self.path != "/":
                    self.send_response(404)
                    self.end_headers()
                    return

                peer_ip = self.client_address[0] if self.client_address else "-"
                forwarded_for = str(self.headers.get("X-Forwarded-For", "")).strip()

                if outer.inbound_api_key:
                    presented_key = _extract_presented_api_key(self.headers)
                    if not presented_key or not hmac.compare_digest(presented_key, outer.inbound_api_key):
                        print(f"[{outer.name}] rejected unauthorized request from ip={peer_ip} xff={forwarded_for!r}")
                        self.send_response(401)
                        self.end_headers()
                        self.wfile.write(b'{"error":"unauthorized"}')
                        return

                content_length_header = self.headers.get("Content-Length")
                if content_length_header is None:
                    self.send_response(411)
                    self.end_headers()
                    self.wfile.write(b'{"error":"content-length required"}')
                    return
                try:
                    length = int(content_length_header)
                except Exception:
                    self.send_response(400)
                    self.end_headers()
                    self.wfile.write(b'{"error":"invalid content-length"}')
                    return
                if length < 0 or length > outer.max_request_bytes:
                    self.send_response(413)
                    self.end_headers()
                    self.wfile.write(b'{"error":"request too large"}')
                    return

                raw = self.rfile.read(length)
                try:
                    body = json.loads(raw.decode("utf-8"))
                except Exception:
                    self.send_response(400)
                    self.end_headers()
                    self.wfile.write(b'{"error":"invalid json"}')
                    return
                if not isinstance(body, dict):
                    self.send_response(400)
                    self.end_headers()
                    self.wfile.write(b'{"error":"invalid payload"}')
                    return

                task_id = str(body.get("task_id") or "")
                message = body.get("message", {})
                callback_url = str(body.get("callback_url") or "")
                callback_auth = body.get("callback_auth") or {}
                callback_token = str(callback_auth.get("token") or "")

                if not task_id or not callback_url or not callback_token:
                    self.send_response(400)
                    self.end_headers()
                    self.wfile.write(b'{"error":"invalid task payload"}')
                    return

                if not _is_allowed_callback_url(callback_url, outer.hub_url):
                    self.send_response(400)
                    self.end_headers()
                    self.wfile.write(b'{"error":"invalid callback_url"}')
                    return

                query, user_input, _envelope = parse_routed_payload(message)
                print(
                    f"[{outer.name}] accepted task={task_id} ip={peer_ip} "
                    f"xff={forwarded_for!r} query={_safe_preview(query)!r}"
                )

                if not outer._inflight.acquire(blocking=False):
                    self.send_response(429)
                    self.end_headers()
                    self.wfile.write(b'{"error":"agent busy"}')
                    return

                def _process_async() -> None:
                    try:
                        output = outer.handler(query, user_input)
                        result_payload = _to_success_payload(outer.name, output)
                    except Exception as exc:  # noqa: BLE001
                        result_payload = _to_error_payload(
                            outer.name,
                            exc,
                            expose_error_details=outer.expose_error_details,
                        )
                    try:
                        status, _payload = _send_hub_callback(callback_url, callback_token, result_payload)
                        print(f"[{outer.name}] callback HTTP {status} task={task_id}")
                    except Exception as exc:  # noqa: BLE001
                        print(
                            f"[{outer.name}] callback failed task={task_id} "
                            f"url={callback_url!r} error={type(exc).__name__}: {exc}"
                        )
                    finally:
                        outer._inflight.release()

                outer._executor.submit(_process_async)

                self.send_response(202)
                self.send_header("Content-Type", "application/json")
                self.end_headers()
                self.wfile.write(b'{"status":"accepted"}')

        return Handler


def run_agent_server(
    *,
    name: str,
    port: int,
    bind_host: str = "127.0.0.1",
    hub_url: str,
    handler: TaskHandler,
    inbound_api_key: str | None = None,
    allow_insecure_bind: bool = False,
    max_request_bytes: int = MAX_REQUEST_BYTES,
    max_inflight_tasks: int = 32,
    expose_error_details: bool = False,
) -> None:
    AgentServer(
        name=name,
        port=port,
        bind_host=bind_host,
        hub_url=hub_url,
        handler=handler,
        inbound_api_key=inbound_api_key,
        allow_insecure_bind=allow_insecure_bind,
        max_request_bytes=max_request_bytes,
        max_inflight_tasks=max_inflight_tasks,
        expose_error_details=expose_error_details,
    ).serve_forever()


def _join_hub_url(base_url: str, path: str, *, query: dict[str, Any] | None = None) -> str:
    base = base_url.rstrip("/")
    qs = ""
    if query:
        qs = "?" + urlencode(query)
    return f"{base}{path}{qs}"


class AgentPullWorker:
    def __init__(
        self,
        *,
        name: str,
        hub_url: str,
        agent_api_key: str,
        handler: TaskHandler,
        poll_wait_seconds: int = 20,
        poll_retry_delay_seconds: float = 1.0,
        max_inflight_tasks: int = 32,
        expose_error_details: bool = False,
    ) -> None:
        self.name = name
        self.hub_url = hub_url.rstrip("/")
        self.agent_api_key = (agent_api_key or "").strip()
        self.handler = handler
        self.poll_wait_seconds = max(0, min(int(poll_wait_seconds), 60))
        self.poll_retry_delay_seconds = max(0.1, float(poll_retry_delay_seconds))
        self.max_inflight_tasks = max(1, int(max_inflight_tasks))
        self.expose_error_details = expose_error_details
        self._inflight = threading.BoundedSemaphore(self.max_inflight_tasks)
        self._executor = ThreadPoolExecutor(max_workers=self.max_inflight_tasks)

        if not self.agent_api_key:
            raise ValueError("agent_api_key is required for pull mode")

    def _next_task_url(self) -> str:
        return _join_hub_url(
            self.hub_url,
            "/api/v1/a2a/pull/tasks/next",
            query={"wait_seconds": self.poll_wait_seconds},
        )

    def serve_forever(self) -> None:
        print(f"{self.name} pull worker connected to {self.hub_url}")
        try:
            while True:
                if not self._inflight.acquire(blocking=False):
                    time.sleep(0.05)
                    continue

                release_needed = True
                try:
                    try:
                        status, payload = _http_json(
                            "GET",
                            self._next_task_url(),
                            timeout=float(max(10, self.poll_wait_seconds + 5)),
                            extra_headers={"Authorization": f"Bearer {self.agent_api_key}"},
                        )
                    except Exception as exc:  # noqa: BLE001
                        print(f"[{self.name}] pull failed: {type(exc).__name__}: {exc}")
                        self._inflight.release()
                        release_needed = False
                        time.sleep(self.poll_retry_delay_seconds)
                        continue

                    if status == 204:
                        self._inflight.release()
                        release_needed = False
                        continue

                    if status != 200 or not isinstance(payload, dict):
                        print(f"[{self.name}] pull HTTP {status}")
                        self._inflight.release()
                        release_needed = False
                        time.sleep(self.poll_retry_delay_seconds)
                        continue

                    task_id = str(payload.get("task_id") or "")
                    message = payload.get("message", {})
                    callback_url = str(payload.get("callback_url") or "")
                    callback_auth = payload.get("callback_auth") or {}
                    callback_token = str(callback_auth.get("token") or "")
                    if not task_id or not callback_url or not callback_token:
                        print(f"[{self.name}] invalid pull payload")
                        self._inflight.release()
                        release_needed = False
                        continue

                    query, user_input, _envelope = parse_routed_payload(message)
                    print(f"[{self.name}] pulled task={task_id} query={_safe_preview(query)!r}")

                    def _process_async(
                        *,
                        task_id_snapshot: str = task_id,
                        callback_url_snapshot: str = callback_url,
                        callback_token_snapshot: str = callback_token,
                        query_snapshot: str = query,
                        user_input_snapshot: str = user_input,
                    ) -> None:
                        try:
                            output = self.handler(query_snapshot, user_input_snapshot)
                            result_payload = _to_success_payload(self.name, output)
                        except Exception as exc:  # noqa: BLE001
                            result_payload = _to_error_payload(
                                self.name,
                                exc,
                                expose_error_details=self.expose_error_details,
                            )
                        try:
                            status_code, _ = _send_hub_callback(
                                callback_url_snapshot,
                                callback_token_snapshot,
                                result_payload,
                            )
                            print(
                                f"[{self.name}] callback HTTP {status_code} "
                                f"task={task_id_snapshot}"
                            )
                        except Exception as exc:  # noqa: BLE001
                            print(
                                f"[{self.name}] callback failed task={task_id_snapshot} "
                                f"url={callback_url_snapshot!r} "
                                f"error={type(exc).__name__}: {exc}"
                            )
                        finally:
                            self._inflight.release()

                    self._executor.submit(_process_async)
                    # Semaphore ownership moves to the async task.
                    release_needed = False
                except KeyboardInterrupt:
                    raise
                except Exception as exc:  # noqa: BLE001
                    print(f"[{self.name}] pull loop error: {type(exc).__name__}: {exc}")
                    if release_needed:
                        self._inflight.release()
                    time.sleep(self.poll_retry_delay_seconds)
        finally:
            self._executor.shutdown(wait=False, cancel_futures=True)


def run_agent_pull_worker(
    *,
    name: str,
    hub_url: str,
    agent_api_key: str,
    handler: TaskHandler,
    poll_wait_seconds: int = 20,
    poll_retry_delay_seconds: float = 1.0,
    max_inflight_tasks: int = 32,
    expose_error_details: bool = False,
) -> None:
    AgentPullWorker(
        name=name,
        hub_url=hub_url,
        agent_api_key=agent_api_key,
        handler=handler,
        poll_wait_seconds=poll_wait_seconds,
        poll_retry_delay_seconds=poll_retry_delay_seconds,
        max_inflight_tasks=max_inflight_tasks,
        expose_error_details=expose_error_details,
    ).serve_forever()
