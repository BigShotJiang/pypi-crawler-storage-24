from __future__ import annotations

import json
import os
import re
import ssl
import urllib.error
import urllib.parse
import urllib.request
from typing import Any


def _build_ssl_context() -> ssl.SSLContext:
    """
    Build a TLS context for Hub HTTPS calls.

    Priority:
    1) AGENT_HUB_CA_BUNDLE (explicit CA file path)
    2) certifi CA bundle (if installed)
    3) platform default trust store
    """
    ca_bundle = os.environ.get("AGENT_HUB_CA_BUNDLE", "").strip()
    if ca_bundle:
        return ssl.create_default_context(cafile=ca_bundle)

    try:
        import certifi  # type: ignore

        return ssl.create_default_context(cafile=certifi.where())
    except Exception:
        return ssl.create_default_context()


def _json_request(
    method: str,
    url: str,
    *,
    bearer_key: str,
    body: dict[str, Any] | None = None,
    timeout: float = 30.0,
) -> tuple[int, Any]:
    payload = json.dumps(body).encode("utf-8") if body is not None else None
    req = urllib.request.Request(
        url,
        method=method,
        data=payload,
        headers={
            "Authorization": f"Bearer {bearer_key}",
            "Content-Type": "application/json",
        },
    )
    try:
        with urllib.request.urlopen(req, timeout=timeout, context=_build_ssl_context()) as resp:
            raw = resp.read().decode("utf-8")
            if not raw.strip():
                return resp.status, {}
            try:
                return resp.status, json.loads(raw)
            except Exception:
                return resp.status, raw
    except urllib.error.HTTPError as exc:
        raw = exc.read().decode("utf-8", errors="replace")
        try:
            payload = json.loads(raw) if raw else {}
        except Exception:
            payload = raw
        return exc.code, payload
    except urllib.error.URLError as exc:
        reason = str(getattr(exc, "reason", exc))
        if "CERTIFICATE_VERIFY_FAILED" in reason:
            raise RuntimeError(
                "TLS certificate verification failed for Hub URL. "
                "Install certifi (pip install certifi) or set AGENT_HUB_CA_BUNDLE "
                "to a trusted CA bundle path."
            ) from exc
        raise RuntimeError(f"network request failed: {reason}") from exc


def _slugify(value: str) -> str:
    lowered = value.strip().lower()
    replaced = re.sub(r"[^a-z0-9]+", "-", lowered)
    clean = replaced.strip("-")
    return clean or "agent"


def _get_current_user_id(*, hub_url: str, user_api_key: str) -> str:
    status, payload = _json_request(
        "GET",
        f"{hub_url.rstrip('/')}/api/v1/users/me",
        bearer_key=user_api_key,
        body=None,
    )
    if status != 200 or not isinstance(payload, dict):
        raise RuntimeError(f"failed to resolve current user: HTTP {status} payload={payload!r}")
    user_id = str(payload.get("id", "")).strip()
    if not user_id:
        raise RuntimeError("current user response did not include id")
    return user_id


def _find_owned_agent_by_name(
    *,
    hub_url: str,
    user_api_key: str,
    owner_user_id: str,
    name: str,
) -> str | None:
    query = urllib.parse.urlencode(
        {
            "search": name,
            "page": 1,
            "page_size": 100,
            "include_system": "false",
        }
    )
    status, payload = _json_request(
        "GET",
        f"{hub_url.rstrip('/')}/api/v1/agents?{query}",
        bearer_key=user_api_key,
        body=None,
    )
    if status != 200 or not isinstance(payload, dict):
        return None
    items = payload.get("items")
    if not isinstance(items, list):
        return None
    wanted = name.strip().lower()
    for item in items:
        if not isinstance(item, dict):
            continue
        owner = item.get("owner")
        owner_id = str(owner.get("id", "")).strip() if isinstance(owner, dict) else ""
        if owner_id != owner_user_id:
            continue
        if str(item.get("name", "")).strip().lower() != wanted:
            continue
        found_id = str(item.get("id", "")).strip()
        if found_id:
            return found_id
    return None


def _agent_create_payload(
    *,
    name: str,
    description: str,
    endpoint_url: str,
    capability_name: str,
    capability_description: str,
    tags: list[str],
    is_public: bool,
    timeout_seconds: float,
    max_concurrent_tasks: int,
    metadata: dict[str, Any] | None,
) -> dict[str, Any]:
    return {
        "name": name,
        "description": description,
        "endpoint_url": endpoint_url,
        "auth_type": "none",
        "auth_config": None,
        "a2a_enabled": True,
        "is_public": is_public,
        "version": "1.0.0",
        "capabilities": [
            {
                "name": capability_name,
                "description": capability_description,
                "input_schema": {
                    "type": "object",
                    "properties": {
                        "query": {"type": "string"},
                        "input": {},
                    },
                    "required": ["query"],
                },
            }
        ],
        "tags": tags,
        "metadata": metadata,
        "timeout_seconds": timeout_seconds,
        "max_concurrent_tasks": max_concurrent_tasks,
    }


def _agent_update_payload(
    *,
    description: str,
    endpoint_url: str,
    capability_name: str,
    capability_description: str,
    tags: list[str],
    is_public: bool,
    timeout_seconds: float,
    max_concurrent_tasks: int,
    metadata: dict[str, Any] | None,
) -> dict[str, Any]:
    return {
        "description": description,
        "endpoint_url": endpoint_url,
        "auth_type": "none",
        "auth_config": None,
        "a2a_enabled": True,
        "status": "active",
        "is_public": is_public,
        "version": "1.0.0",
        "capabilities": [
            {
                "name": capability_name,
                "description": capability_description,
                "input_schema": {
                    "type": "object",
                    "properties": {
                        "query": {"type": "string"},
                        "input": {},
                    },
                    "required": ["query"],
                },
            }
        ],
        "tags": tags,
        "metadata": metadata,
        "timeout_seconds": timeout_seconds,
        "max_concurrent_tasks": max_concurrent_tasks,
    }


def bootstrap_pull_agent(
    *,
    hub_url: str,
    user_api_key: str,
    name: str,
    description: str,
    capability_name: str,
    capability_description: str,
    endpoint_id: str | None = None,
    tags: list[str] | None = None,
    is_public: bool = False,
    timeout_seconds: float = 90.0,
    max_concurrent_tasks: int = 10,
    key_label: str | None = None,
    key_expires_in_days: int | None = None,
    metadata: dict[str, Any] | None = None,
) -> dict[str, str]:
    """
    Create or update a pull-mode agent and mint a new agent pull key.

    Returns:
        {
            "agent_id": "...",
            "agent_name": "...",
            "endpoint_url": "pull://...",
            "agent_api_key": "ah_a_..."
        }
    """
    normalized_hub = hub_url.strip().rstrip("/")
    raw_user_key = user_api_key.strip()
    if not normalized_hub:
        raise ValueError("hub_url is required")
    if not raw_user_key:
        raise ValueError("user_api_key is required")
    if not raw_user_key.startswith("ah_k_"):
        raise ValueError("user_api_key must start with ah_k_")
    if not name.strip():
        raise ValueError("name is required")
    if not capability_name.strip():
        raise ValueError("capability_name is required")

    endpoint_target = (endpoint_id or _slugify(name)).strip()
    endpoint_url = f"pull://{endpoint_target}"
    normalized_tags = [t.strip() for t in (tags or []) if t.strip()]
    effective_metadata = {"transport": "pull"}
    if isinstance(metadata, dict):
        effective_metadata.update(metadata)

    owner_user_id = _get_current_user_id(hub_url=normalized_hub, user_api_key=raw_user_key)
    existing_agent_id = _find_owned_agent_by_name(
        hub_url=normalized_hub,
        user_api_key=raw_user_key,
        owner_user_id=owner_user_id,
        name=name,
    )

    if existing_agent_id:
        status, payload = _json_request(
            "PUT",
            f"{normalized_hub}/api/v1/agents/{existing_agent_id}",
            bearer_key=raw_user_key,
            body=_agent_update_payload(
                description=description,
                endpoint_url=endpoint_url,
                capability_name=capability_name,
                capability_description=capability_description,
                tags=normalized_tags,
                is_public=is_public,
                timeout_seconds=timeout_seconds,
                max_concurrent_tasks=max_concurrent_tasks,
                metadata=effective_metadata,
            ),
        )
        if status != 200 or not isinstance(payload, dict):
            raise RuntimeError(f"failed to update agent {name}: HTTP {status} payload={payload!r}")
        agent_id = str(payload.get("id") or existing_agent_id)
    else:
        status, payload = _json_request(
            "POST",
            f"{normalized_hub}/api/v1/agents",
            bearer_key=raw_user_key,
            body=_agent_create_payload(
                name=name,
                description=description,
                endpoint_url=endpoint_url,
                capability_name=capability_name,
                capability_description=capability_description,
                tags=normalized_tags,
                is_public=is_public,
                timeout_seconds=timeout_seconds,
                max_concurrent_tasks=max_concurrent_tasks,
                metadata=effective_metadata,
            ),
        )
        if status != 201 or not isinstance(payload, dict):
            raise RuntimeError(f"failed to create agent {name}: HTTP {status} payload={payload!r}")
        agent_id = str(payload.get("id", "")).strip()
        if not agent_id:
            raise RuntimeError(f"agent created without id: {name}")

    key_body: dict[str, Any] = {"label": key_label or f"{_slugify(name)}-pull-worker"}
    if key_expires_in_days is not None:
        key_body["expires_in_days"] = int(key_expires_in_days)

    key_status, key_payload = _json_request(
        "POST",
        f"{normalized_hub}/api/v1/agents/{agent_id}/keys",
        bearer_key=raw_user_key,
        body=key_body,
    )
    if key_status != 201 or not isinstance(key_payload, dict):
        raise RuntimeError(
            f"failed to create agent key for {name}: HTTP {key_status} payload={key_payload!r}"
        )
    raw_agent_key = str(key_payload.get("key", "")).strip()
    if not raw_agent_key:
        raise RuntimeError(f"agent key response missing raw key: {name}")

    return {
        "agent_id": agent_id,
        "agent_name": name,
        "endpoint_url": endpoint_url,
        "agent_api_key": raw_agent_key,
    }
