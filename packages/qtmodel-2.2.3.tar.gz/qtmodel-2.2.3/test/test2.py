from src.qtmodel import *
mdb.set_url("http://10.33.176.44:61076/")
# print(odb.get_element_force(ids=1,stage_id=-1,case_name="ST:时变荷载"))
print(odb.get_initial_tension_load(case_name="初拉力荷载"))