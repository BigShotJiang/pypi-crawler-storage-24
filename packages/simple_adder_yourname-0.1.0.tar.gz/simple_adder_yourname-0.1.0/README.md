# Simple Adder

A simple Python library to add two numbers.

```python
from simple_adder import add
print(add(2, 3))  # 5
```
