"""Prism — Multi-API Intelligent Router CLI."""

__version__ = "1.0.0"
__app_name__ = "prism"
