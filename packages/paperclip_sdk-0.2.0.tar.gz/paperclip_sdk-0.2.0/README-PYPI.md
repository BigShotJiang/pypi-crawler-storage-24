# paperclip-sdk

Public Python SDK for calling Paperclip remote functions.

## Install

```bash
poetry add paperclip-sdk
```

or

```bash
pip install paperclip-sdk
```

## Configure authentication

```bash
export LEASEKEY_API_KEY="your-api-key"
```

## Sync usage

```python
from paperclip_sdk import PaperclipClient

with PaperclipClient(base_url="https://leasekey.org") as client:
    result = client.call("core.hello_world", name="Ada")
    print(result)
```

## Async usage

```python
import asyncio

from paperclip_sdk import AsyncPaperclipClient


async def main() -> None:
    async with AsyncPaperclipClient(base_url="https://leasekey.org") as client:
        result = await client.call("core.hello_world", name="Ada")
        print(result)


asyncio.run(main())
```

## Function handles

```python
from paperclip_sdk import PaperclipClient

with PaperclipClient(base_url="https://leasekey.org") as client:
    hello_world = client.function("core.hello_world")
    print(hello_world("Ada"))
```

## Async function handles

```python
import asyncio

from paperclip_sdk import AsyncPaperclipClient


async def main() -> None:
    async with AsyncPaperclipClient(base_url="https://leasekey.org") as client:
        hello_world = client.function("core.hello_world")
        print(await hello_world("Ada"))


asyncio.run(main())
```

## Typed exceptions

```python
from paperclip_sdk import (
    PaperclipAuthenticationError,
    PaperclipNotFoundError,
    PaperclipPermissionError,
    PaperclipRateLimitError,
    PaperclipServerError,
    PaperclipTransportError,
    PaperclipInvalidResponseError,
)
```

## Notes

- The default base URL is `https://leasekey.org`, so passing `base_url` is optional.
- The SDK automatically sends `User-Agent: paperclip-sdk/<version>`.
- The SDK also sends `X-Leasekey-SDK-Version: <version>`.
- Built-in retry behavior covers retryable transport failures and these HTTP statuses:
  `408`, `425`, `429`, `502`, `503`, `504`.
