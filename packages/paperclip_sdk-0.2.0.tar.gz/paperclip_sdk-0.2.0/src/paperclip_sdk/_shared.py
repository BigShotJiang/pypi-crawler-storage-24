# src/paperclip_sdk/_shared.py

import logging
import random
from dataclasses import dataclass, field
from datetime import datetime, timezone
from email.utils import parsedate_to_datetime
from importlib.metadata import PackageNotFoundError
from importlib.metadata import version as package_version
from typing import Any

import httpx

from paperclip_sdk._exceptions import (PaperclipAuthenticationError,
                                       PaperclipClientError,
                                       PaperclipHTTPError,
                                       PaperclipInvalidResponseError,
                                       PaperclipNotFoundError,
                                       PaperclipPermissionError,
                                       PaperclipRateLimitError,
                                       PaperclipServerError)

DEFAULT_BASE_URL = "https://leasekey.org"
API_KEY_ENV_VAR = "LEASEKEY_API_KEY"
RPC_RUN_PATH = "/rpc/run"


@dataclass(frozen=True, slots=True)
class RetryPolicy:
    max_attempts: int = 5
    initial_backoff: float = 0.25
    max_backoff: float = 8.0
    backoff_multiplier: float = 2.0
    retryable_status_codes: frozenset[int] = field(
        default_factory=lambda: frozenset({408, 425, 429, 502, 503, 504})
    )

    def validate(self) -> None:
        if self.max_attempts < 1:
            raise ValueError("RetryPolicy.max_attempts must be >= 1")
        if self.initial_backoff < 0:
            raise ValueError("RetryPolicy.initial_backoff must be >= 0")
        if self.max_backoff < 0:
            raise ValueError("RetryPolicy.max_backoff must be >= 0")
        if self.backoff_multiplier < 1:
            raise ValueError("RetryPolicy.backoff_multiplier must be >= 1")
        if self.max_backoff < self.initial_backoff:
            raise ValueError("RetryPolicy.max_backoff must be >= initial_backoff")


def get_sdk_version() -> str:
    try:
        return package_version("paperclip-sdk")
    except PackageNotFoundError:
        return "0.0.0"


def build_request_headers(request_id: str) -> dict[str, str]:
    sdk_version = get_sdk_version()
    return {
        "Idempotency-Key": request_id,
        "X-Paperclip-Request-Id": request_id,
        "X-Leasekey-Request-Id": request_id,
        "X-Leasekey-SDK-Version": sdk_version,
        "User-Agent": f"paperclip-sdk/{sdk_version}",
    }


def build_payload(
    function_name: str,
    request_id: str,
    args: tuple[Any, ...],
    kwargs: dict[str, Any],
) -> dict[str, Any]:
    return {
        "function": function_name,
        "args": list(args),
        "kwargs": kwargs,
        "request_id": request_id,
    }


def extract_error_message(response: httpx.Response) -> str:
    try:
        data = response.json()
    except ValueError:
        return response.text

    detail = data.get("detail")
    if isinstance(detail, str):
        return detail

    return response.text


def parse_response_json(response: httpx.Response) -> dict[str, Any]:
    try:
        data = response.json()
    except ValueError as exc:
        raise PaperclipInvalidResponseError(
            "Invalid JSON response from Paperclip RPC server"
        ) from exc

    if not isinstance(data, dict):
        raise PaperclipInvalidResponseError("Invalid RPC response payload")

    return data


def extract_result_from_response(
    data: dict[str, Any],
    *,
    function_name: str,
) -> Any:
    if not data.get("ok"):
        raise PaperclipClientError(f"RPC call failed: {function_name}")
    return data.get("result")


def parse_retry_after(response: httpx.Response, *, max_delay: float) -> float | None:
    retry_after = response.headers.get("Retry-After")
    if not retry_after:
        return None

    retry_after = retry_after.strip()

    try:
        seconds = float(retry_after)
        return max(0.0, min(seconds, max_delay))
    except ValueError:
        pass

    try:
        retry_at = parsedate_to_datetime(retry_after)
        if retry_at.tzinfo is None:
            retry_at = retry_at.replace(tzinfo=timezone.utc)

        seconds = (retry_at - datetime.now(timezone.utc)).total_seconds()
        return max(0.0, min(seconds, max_delay))
    except (TypeError, ValueError, OverflowError):
        return None


def to_ms(seconds: float) -> float:
    return round(seconds * 1000.0, 2)


def configure_default_client_debug_logger(
    client_logger: logging.Logger,
    *,
    handler_name: str,
) -> None:
    client_logger.setLevel(logging.DEBUG)
    client_logger.propagate = False

    for handler in client_logger.handlers:
        if handler.get_name() == handler_name:
            return

    handler = logging.StreamHandler()
    handler.set_name(handler_name)
    handler.setLevel(logging.DEBUG)
    handler.setFormatter(
        logging.Formatter("%(asctime)s %(levelname)s %(name)s %(message)s")
    )
    client_logger.addHandler(handler)


def should_retry_response(
    status_code: int,
    *,
    attempt: int,
    retry_policy: RetryPolicy,
) -> bool:
    if attempt >= retry_policy.max_attempts:
        return False
    return status_code in retry_policy.retryable_status_codes


def should_retry_connect_error(
    *,
    attempt: int,
    retry_policy: RetryPolicy,
) -> bool:
    return attempt < retry_policy.max_attempts


def compute_retry_delay(
    attempt: int,
    *,
    retry_policy: RetryPolicy,
    random_source: random.Random,
    response: httpx.Response | None = None,
) -> float:
    if response is not None:
        retry_after_delay = parse_retry_after(
            response,
            max_delay=retry_policy.max_backoff,
        )
        if retry_after_delay is not None:
            return retry_after_delay

    cap = min(
        retry_policy.max_backoff,
        retry_policy.initial_backoff
        * (retry_policy.backoff_multiplier ** (attempt - 1)),
    )
    return random_source.uniform(0.0, cap)


def map_http_status_error(
    *,
    status_code: int,
    message: str,
) -> PaperclipHTTPError:
    if status_code == 401:
        return PaperclipAuthenticationError(message, status_code=status_code)
    if status_code == 403:
        return PaperclipPermissionError(message, status_code=status_code)
    if status_code == 404:
        return PaperclipNotFoundError(message, status_code=status_code)
    if status_code == 429:
        return PaperclipRateLimitError(message, status_code=status_code)
    if 500 <= status_code <= 599:
        return PaperclipServerError(message, status_code=status_code)
    return PaperclipHTTPError(message, status_code=status_code)


__all__ = [
    "DEFAULT_BASE_URL",
    "API_KEY_ENV_VAR",
    "RPC_RUN_PATH",
    "RetryPolicy",
    "build_request_headers",
    "build_payload",
    "extract_error_message",
    "parse_response_json",
    "extract_result_from_response",
    "parse_retry_after",
    "to_ms",
    "configure_default_client_debug_logger",
    "should_retry_response",
    "should_retry_connect_error",
    "compute_retry_delay",
    "map_http_status_error",
    "get_sdk_version",
]
