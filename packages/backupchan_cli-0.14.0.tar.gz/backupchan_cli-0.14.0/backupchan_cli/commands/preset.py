from backupchan_cli import utility
from backupchan import API
from backupchan_presets import Presets, PresetError
import requests

#
# Utility functions
#

def separated_path_list(paths: list[str]) -> str:
    return '; '.join([f"'{path}'" for path in paths])

#
#
#

def setup_subcommands(subparser):
    #
    #
    #
    
    list_cmd = subparser.add_parser("list", help="List all presets")
    list_cmd.set_defaults(func=do_list)

    #
    #
    #

    new_cmd = subparser.add_parser("new", help="Create a new preset")
    new_cmd.add_argument("name", type=str, help="Name of the new preset. Must be unique.")
    new_cmd.add_argument("location", type=str, help="Path to file or directory to back up")
    new_cmd.add_argument("target_id", type=str, help="ID of the target to upload backups to")
    new_cmd.add_argument("--exclude", "-e", type=str, nargs="+", action="extend", help="Exclude paths (supports wildcards; mutually exclusve with --include)")
    new_cmd.add_argument("--include", "-i", type=str, nargs="+", action="extend", help="Include only these paths (supports wildcards; mutually exclusive with --exclude)")
    new_cmd.set_defaults(func=do_new)

    #
    #
    #

    delete_cmd = subparser.add_parser("delete", help="Delete an existing preset")
    delete_cmd.add_argument("name", type=str, help="Name of the preset to delete")
    delete_cmd.set_defaults(func=do_delete)

    #
    #
    #

    rename_cmd = subparser.add_parser("rename", help="Rename an existing preset")
    rename_cmd.add_argument("old_name", type=str, help="Current name of the preset")
    rename_cmd.add_argument("new_name", type=str, help="Rename preset to this name")
    rename_cmd.set_defaults(func=do_rename)

    #
    #
    #

    upload_cmd = subparser.add_parser("upload", help="Upload a backup according to an existing preset")
    upload_cmd.add_argument("name", type=str, help="Name of the preset to use")
    upload_cmd.add_argument("--automatic", "-a", action="store_true", help="Mark this backup as automatic")
    upload_cmd.add_argument("--sequential", "-s", action="store_true", help="Upload sequentially")
    upload_cmd.set_defaults(func=do_upload)

    #
    #
    #

    reset_cmd = subparser.add_parser("reset", help="Delete all existing presets")
    reset_cmd.set_defaults(func=do_reset)

#
# backupchan preset list
#

def do_list(args, presets: Presets, _):
    if len(presets) == 0:
        print("There are no presets.")
        return

    for preset_name in presets:
        preset = presets[preset_name]
        print(f" | '{preset_name}' - location: '{preset.location}', target: '{preset.target_id}'", end="")
        if preset.exclude:
            print(f", exclude: {separated_path_list(preset.exclude)}")
        elif preset.include:
            print(f", include: {separated_path_list(preset.include)}")
        else:
            print()

#
# backupchan preset new
#

def do_new(args, presets: Presets, _):
    if args.exclude and args.include:
        utility.failure("Exclude and include patterns cannot be used together")
    presets.add(args.name, args.location, args.target_id, args.exclude, args.include)
    presets.save()
    print("Preset saved.")

#
# backupchan preset delete
#

def do_delete(args, presets: Presets, _):
    presets.remove(args.name)
    presets.save()
    print("Preset deleted.")

#
# backupchan preset rename
#

def do_rename(args, presets: Presets, _):
    try:
        presets.rename(args.old_name, args.new_name)
    except PresetError as exc:
        utility.failure(f"Failed to rename: {str(exc)}")
    presets.save()
    print(f"Renamed preset '{args.old_name}' to '{args.new_name}'.")

#
# backupchan preset upload
#

def do_upload(args, presets: Presets, api: API):
    if args.name not in presets:
        utility.failure(f"Preset '{args.name}' not found")

    if args.sequential:
        try:
            for index, total_files, filename in presets[args.name].seq_upload(api, not args.automatic):
                print(f"Upload file {index + 1} of {total_files}: {filename}")
        except requests.exceptions.ConnectionError:
            utility.failure_network()
        except BackupchanAPIError as exc:
            utility.failure(f"Failed to upload backup: {str(exc)}")
        except Exception as exc:
            api.seq_terminate(args.target_id)
            utility.failure(f"Client error: {str(exc)}")
        print("Backup uploaded.")
    else:
        job_id = presets[args.name].upload(api, not args.automatic)
        print(f"Backup uploaded with preset '{args.name}' and is now being processed by job #{job_id}.")

#
# backupchan preset reset
#

def do_reset(args, _, __):
    Presets().save()
    print(f"Presets reset.")
