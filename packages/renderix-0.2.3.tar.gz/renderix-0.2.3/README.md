# renderix
![PyPI - Version](https://img.shields.io/pypi/v/renderix?color=%23a6e3a1)

Simple templating engine.

`renderix` renders a template file by replacing placeholders like `{{ variable_name }}` with values loaded from a TOML file named `renderix.toml` in the current working directory.

---

## Features

- Tiny, no-dependency templating
- Variables loaded from `renderix.toml`
- Replaces placeholders in the form: `{{ name }}`
- Output to stdout by default, or write to a file
- Verbose mode for debugging
- For loops

---

## Installation
```bash
uv tool install renderix
```

Or:

```bash
git clone https://codeberg.org/nietarne/renderix.git
cd renderix
uv tool install .
```

## Quick start
1. Create a `renderix.toml` in your working directory:
```toml
name = "John Doe"
```
2. Create a template file, e.g. `template.txt`:
```
Hello {{ name }}
```
3. Render it to stdout:
```bash
renderix -t template.txt
```

### For loops
Suppose you want to print a list of employees an their age.

`renderix.toml`:
```toml
[[employees]]
name = "Jhon"
age = 40

[[employees]]
name = "Jane"
age = 42

[[employees]]
name = "Joe"
age = 46
```

In your template:
```
{{ for employee in employees }}
- {{ employee.name }} is {{ employee.age }} years old
{{ endfor }}
```

