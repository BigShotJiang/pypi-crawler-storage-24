import argparse
import logging

from renderix.renderer import Renderer

from . import __version__

logger = logging.getLogger(__name__)


def main() -> None:
    """Entry point for the renderix command-line interface.

    Parses CLI arguments, configures logging, and renders a template file using
    variables from `renderix.toml`.

    CLI options:
        -v/--version:   Print version and exit.
        -V/--verbose:   Enable verbose logging.
        -t/--template:  Template file to process (required).
        -o/--output:    Output file to write (defaults to stdout).
    """
    parser = argparse.ArgumentParser(
        prog="renderix",
        description="Simple and fast templating engine",
        formatter_class=lambda prog: argparse.HelpFormatter(
            prog,
            max_help_position=35,
            width=100,
        ),
    )
    parser.color = False

    parser.add_argument(
        "-v",
        "--version",
        action="version",
        version=f"%(prog)s {__version__}",
        help="Print version and exit",
    )
    parser.add_argument(
        "-V",
        "--verbose",
        action="store_true",
        help="Enable verbose output",
    )
    parser.add_argument(
        "-t",
        "--template",
        required=True,
        help="Template file to process",
    )
    parser.add_argument(
        "-o",
        "--output",
        required=False,
        help="File to write output to (defaults to stdout)",
    )

    args = parser.parse_args()

    logging.basicConfig(
        level=logging.DEBUG if args.verbose else logging.WARNING,
        format="%(levelname)s: %(message)s",
    )

    renderer = Renderer(logger)
    renderer.render(args.template, args.output, args.verbose)


if __name__ == "__main__":
    main()
