import json
import re
import sys
import tomllib
from logging import Logger
from pathlib import Path
from typing import Any, Optional

VARIABLE_FILE = "renderix.toml"

FOR_LOOP_RE = re.compile(
    r"[^\S\n]*\{\{ for (\w+) in (\w+) \}\}[^\S\n]*\n(.*?)[^\S\n]*\{\{ endfor \}\}[^\S\n]*(?:\n|$)",
    re.DOTALL,
)
VARIABLE_RE_CACHE: dict[str, re.Pattern[str]] = {}


class Renderer:
    logger: Logger

    def __init__(self, logger: Logger) -> None:
        self.logger = logger

    def render(
        self,
        template_file_name: str,
        out_file_name: Optional[str],
        verbose: bool,
    ) -> None:
        """Render a template file.

        Loads the template file, expands any for loops, substitutes variables
        found in `renderix.toml` and writes the rendered output either to stdout
        (if `out_file_name` is None) or to the specified output file.

        Exits 1 if the template file does not exist

        Args:
            `template_file_name`: Path to the template file to render.
            `out_file_name`: Output file path. If None, prints to stdout.
        """
        try:
            self.logger.info("Reading: %s", template_file_name)
            with Path(template_file_name).open("rb") as f:
                content = f.read().decode()
        except FileNotFoundError:
            self.logger.error(
                "No such file or directory: %s", template_file_name
            )
            sys.exit(1)

        config = self._load_variables_from_toml(VARIABLE_FILE)

        content = self._expand_loops(content, config)

        for name in config:
            if not isinstance(config[name], list):
                content = self._replace_scalar_variable(
                    name, config[name], content
                )

        if out_file_name is None:
            if verbose:
                print("\n=========== RESULT ===========")
            sys.stdout.write(content)
        else:
            if out_file_name:
                self.logger.info("Writing to: %s", out_file_name)
            with open(out_file_name, "w", encoding="utf-8") as f:
                f.write(content)

    def _load_variables_from_toml(self, file_name: str) -> dict[str, Any]:
        """Load template variables from a TOML file.

        Reads the TOML file at `file_name` and returns the parsed configuration
        as a dictionary mapping variable names to values.

        Exits 1 if the template file does not exist

        Args:
            `file_name`: Path to the TOML file containing variables.

        Returns:
            A dictionary of variables loaded from the TOML file.
        """
        self.logger.info("Loading %s", file_name)

        try:
            with Path(file_name).open("rb") as f:
                config = tomllib.load(f)
        except FileNotFoundError:
            self.logger.error("No such file or directory: %s", file_name)
            sys.exit(1)

        self.logger.info("Variables loaded")
        for name, value in config.items():
            if isinstance(value, list):
                for item in value:
                    if isinstance(item, dict):
                        self.logger.debug(
                            "%s = %s", name, json.dumps(item, indent=4)
                        )
            else:
                self.logger.debug("%s = %r", name, value)

        return config

    def _replace_scalar_variable(
        self, variable_name: str, variable_value: str, content: str
    ) -> str:
        """Replace templated variable occurrences in content.

        Replaces all instances of the placeholder pattern `{{ variable_name }}`
        in `content` with `variable_value`. Compiled patterns are cached in
        `VARIABLE_RE_CACHE` to avoid recompilation across calls.

        Args:
            `variable_name`: Name of the variable to replace.
            `variable_value`: Value to substitute into the template.
            `content`: Template content.

        Returns:
            The updated content with replacements applied.
        """
        self.logger.info("Replacing %s", variable_name)

        if variable_name not in VARIABLE_RE_CACHE:
            VARIABLE_RE_CACHE[variable_name] = re.compile(
                r"\{\{ " + re.escape(variable_name) + r" \}\}"
            )

        return VARIABLE_RE_CACHE[variable_name].sub(
            str(variable_value), content
        )

    def _render_loop_body(self, item_name: str, item: Any, content: str) -> str:
        """Render one iteration of a for loop body for a single item.

        Substitutes all `{{ item_name.field }}` placeholders in `content` with
        the corresponding field values from `item`. If `item` is a dict, field
        lookup is by key. For scalar values (str, int, float, bool),
        `{{ item_name }}` is substituted directly with the stringified value.

        Args:
            `item_name`: The loop variable name as written in the template.
            `item`: The current iteration value (dict or scalar).
            `content`: The template body between `{{ for ... }}` and `{{ endfor }}`.

        Returns:
            The rendered body string for this iteration.
        """
        field_re = re.compile(r"\{\{ " + re.escape(item_name) + r"\.(\w+) \}\}")

        if not isinstance(item, dict):
            if field_re.search(content):
                self.logger.error(
                    "Field access used on scalar loop variable %r", item_name
                )
                sys.exit(1)
            return content.replace(f"{{{{ {item_name} }}}}", str(item))

        rendered = content
        for match in field_re.finditer(content):
            field = match.group(1)
            if field not in item:
                self.logger.error("Field %r not found in item %r", field, item)
                sys.exit(1)
            rendered = rendered.replace(match.group(0), str(item[field]))

        return rendered

    def _expand_loops(self, content: str, config: dict[str, Any]) -> str:
        """Expand all `{{ for ... }}` loops in the template content.

        Scans `content` for loop blocks of the form:
            {{ for item in items }}
            body
            {{ endfor }}

        For each match, looks up `items` in `config` (which must be a list),
        renders the body for every element, concatenates the results, and
        replaces the original loop block with the expanded output.

        All loops in the template are processed, including multiple distinct
        loops. Nested loops are not supported.

        Args:
            `content`: The raw template content string.
            `config`: Variable mapping loaded from the TOML file.

        Returns:
            The template content with all loop blocks expanded.
        """
        result = content
        for match in FOR_LOOP_RE.finditer(content):
            item_name, collection_name, body = (
                match.group(1),
                match.group(2),
                match.group(3),
            )
            self.logger.info("Expanding for-loop: %s", collection_name)
            if collection_name not in config:
                self.logger.error(
                    "Loop variable %r not found in config", collection_name
                )
                sys.exit(1)
            collection = config[collection_name]
            if not isinstance(collection, list):
                self.logger.error(
                    "Loop variable %r is not a list (got %s)",
                    collection_name,
                    type(collection).__name__,
                )
                sys.exit(1)

            expanded = "".join(
                self._render_loop_body(item_name, item, body)
                for item in collection
            )
            result = result.replace(match.group(0), expanded)
        return result
