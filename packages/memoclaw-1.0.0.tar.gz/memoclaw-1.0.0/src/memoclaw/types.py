"""Pydantic models for MemoClaw API requests and responses."""

from __future__ import annotations

from typing import Any, Literal

from pydantic import BaseModel, Field

MemoryType = Literal[
    "correction", "preference", "decision", "project", "observation", "general"
]

RelationType = Literal[
    "related_to", "derived_from", "contradicts", "supersedes", "supports"
]

SuggestedCategory = Literal["stale", "fresh", "hot", "decaying"]


# ── Shared ────────────────────────────────────────────────────────────────────


class Message(BaseModel):
    role: str
    content: str


class RelatedMemorySummary(BaseModel):
    id: str
    content: str
    importance: float
    memory_type: MemoryType
    namespace: str


class RelationWithMemory(BaseModel):
    id: str
    relation_type: RelationType
    direction: Literal["outgoing", "incoming"]
    memory: RelatedMemorySummary
    metadata: dict[str, Any] = Field(default_factory=dict)
    created_at: str


class Relation(BaseModel):
    id: str
    source_id: str
    target_id: str
    relation_type: RelationType
    metadata: dict[str, Any] = Field(default_factory=dict)
    created_at: str


# ── Memory ────────────────────────────────────────────────────────────────────


class Memory(BaseModel):
    id: str
    user_id: str
    namespace: str
    content: str
    embedding_model: str
    metadata: dict[str, Any] = Field(default_factory=dict)
    importance: float
    memory_type: MemoryType
    session_id: str | None = None
    agent_id: str | None = None
    created_at: str
    updated_at: str
    accessed_at: str
    access_count: int
    deleted_at: str | None = None
    expires_at: str | None = None
    pinned: bool = False
    immutable: bool = False


# ── Recall ────────────────────────────────────────────────────────────────────


class RecallSignals(BaseModel):
    vector: float
    keyword: float
    recency: float
    base_importance: float
    effective_importance: float
    context_importance: float
    relation_count: int
    type_decay: float


class RecallMemory(BaseModel):
    id: str
    content: str
    similarity: float
    metadata: dict[str, Any] = Field(default_factory=dict)
    importance: float
    memory_type: MemoryType
    namespace: str
    session_id: str | None = None
    agent_id: str | None = None
    pinned: bool = False
    immutable: bool = False
    created_at: str
    access_count: int
    relations: list[RelationWithMemory] | None = None
    signals: RecallSignals | None = Field(default=None, alias="_signals")


# ── Store ─────────────────────────────────────────────────────────────────────


class StoreResult(BaseModel):
    id: str
    stored: bool
    deduplicated: bool
    tokens_used: int


class StoreBatchResult(BaseModel):
    ids: list[str]
    stored: bool
    count: int
    deduplicated_count: int
    tokens_used: int


# ── Recall response ──────────────────────────────────────────────────────────


class RecallResponse(BaseModel):
    memories: list[RecallMemory]
    query_tokens: int


# ── List response ────────────────────────────────────────────────────────────


class ListResponse(BaseModel):
    memories: list[Memory]
    total: int
    limit: int
    offset: int


# ── Delete ───────────────────────────────────────────────────────────────────


class DeleteResult(BaseModel):
    deleted: bool
    id: str | None = None


class DeleteBatchItemResult(BaseModel):
    id: str
    deleted: bool
    error: str | None = None


class DeleteNamespaceResult(BaseModel):
    deleted: bool
    deleted_count: int


# ── Ingest ───────────────────────────────────────────────────────────────────


class IngestResult(BaseModel):
    memory_ids: list[str]
    facts_extracted: int
    facts_stored: int
    facts_deduplicated: int
    relations_created: int
    tokens_used: int


# ── Extract ──────────────────────────────────────────────────────────────────


class ExtractResult(BaseModel):
    memory_ids: list[str]
    facts_extracted: int
    facts_stored: int
    facts_deduplicated: int
    tokens_used: int


# ── Consolidate ──────────────────────────────────────────────────────────────


class ClusterInfo(BaseModel):
    memory_ids: list[str]
    similarity: float
    merged_into: str | None = None


class ConsolidateResult(BaseModel):
    clusters_found: int
    memories_merged: int
    memories_created: int
    clusters: list[ClusterInfo]


# ── Suggested ────────────────────────────────────────────────────────────────


class SuggestedMemory(BaseModel):
    id: str
    content: str
    metadata: dict[str, Any] = Field(default_factory=dict)
    importance: float
    memory_type: MemoryType
    namespace: str
    session_id: str | None = None
    agent_id: str | None = None
    created_at: str
    accessed_at: str
    access_count: int
    relation_count: int
    category: SuggestedCategory
    review_score: float


class SuggestedResponse(BaseModel):
    suggested: list[SuggestedMemory]
    categories: dict[str, int]
    total: int


# ── Relations response ───────────────────────────────────────────────────────


class RelationsResponse(BaseModel):
    relations: list[RelationWithMemory]


# ── Free-tier status ─────────────────────────────────────────────────────────


class MigrateResult(BaseModel):
    """Result of a bulk markdown migration."""

    memory_ids: list[str]
    files_processed: int
    memories_created: int
    memories_deduplicated: int
    tokens_used: int


class FreeTierStatus(BaseModel):
    wallet: str
    free_tier_remaining: int
    free_tier_total: int
    free_tier_used: int


class PingResult(BaseModel):
    """Result of a health check / ping."""

    ok: bool
    latency_ms: float
    auth: str  # "signed" or "wallet-only"
    free_tier_remaining: int


# ── Context ──────────────────────────────────────────────────────────────────


class ContextResult(BaseModel):
    """Result of assembling a context block from memories."""

    context: Any  # str for text format, dict for structured format
    memories_used: int
    tokens: int


# ── Namespaces ───────────────────────────────────────────────────────────────


class Namespace(BaseModel):
    name: str
    count: int
    last_memory_at: str | None = None


class NamespacesResponse(BaseModel):
    namespaces: list[Namespace]
    total: int


# ── Stats ────────────────────────────────────────────────────────────────────


class TypeCount(BaseModel):
    memory_type: str
    count: int


class NamespaceCount(BaseModel):
    namespace: str
    count: int


class StatsResponse(BaseModel):
    total_memories: int
    pinned_count: int
    never_accessed: int
    total_accesses: int
    avg_importance: float
    oldest_memory: str | None = None
    newest_memory: str | None = None
    by_type: list[TypeCount] = Field(default_factory=list)
    by_namespace: list[NamespaceCount] = Field(default_factory=list)


# ── Export ───────────────────────────────────────────────────────────────────


class ExportResponse(BaseModel):
    format: str
    memories: list[Any]
    count: int


# ── History ──────────────────────────────────────────────────────────────────


class HistoryEntry(BaseModel):
    id: str
    memory_id: str
    changes: dict[str, Any]
    created_at: str


class HistoryResponse(BaseModel):
    history: list[HistoryEntry]


# ── Batch store input ────────────────────────────────────────────────────────


class UpdateInput(BaseModel):
    """Input for a single memory in a batch update request."""

    id: str
    content: str | None = None
    metadata: dict[str, Any] | None = None
    importance: float | None = None
    memory_type: MemoryType | None = None
    namespace: str | None = None
    pinned: bool | None = None
    immutable: bool | None = None
    expires_at: str | None = None


class UpdateBatchResultItem(BaseModel):
    """Result of a single item in a batch update operation."""

    id: str
    updated: bool
    error: str | None = None


class UpdateBatchResult(BaseModel):
    """Result of a batch update operation."""

    results: list[UpdateBatchResultItem]
    updated: int
    failed: int
    tokens_used: int


class CoreMemoriesResponse(BaseModel):
    """Response from GET /v1/core-memories."""

    memories: list[Memory]
    total: int


class PinCoreMemoryResult(BaseModel):
    """Response from POST /v1/memories/core."""

    pinned: bool
    id: str


class UnpinCoreMemoryResult(BaseModel):
    """Response from DELETE /v1/memories/core/:id."""

    unpinned: bool
    id: str


class TextSearchResponse(BaseModel):
    """Response from GET /v1/memories/search."""

    memories: list[Memory]
    total: int


class MemoryGraphNode(BaseModel):
    """A node in the memory graph."""

    id: str
    content: str
    importance: float
    memory_type: MemoryType | None = None
    namespace: str | None = None


class MemoryGraphEdge(BaseModel):
    """An edge in the memory graph."""

    source_id: str
    target_id: str
    relation_type: RelationType


class MemoryGraphResponse(BaseModel):
    """Response from GET /v1/memories/{id}/graph."""

    root: MemoryGraphNode
    nodes: list[MemoryGraphNode]
    edges: list[MemoryGraphEdge]
    depth: int


class StoreInput(BaseModel):
    """Input for a single memory in a batch store request."""

    content: str
    metadata: dict[str, Any] | None = None
    importance: float | None = None
    tags: list[str] | None = None
    namespace: str | None = None
    memory_type: MemoryType | None = None
    session_id: str | None = None
    agent_id: str | None = None
    expires_at: str | None = None
    pinned: bool | None = None
    immutable: bool | None = None
