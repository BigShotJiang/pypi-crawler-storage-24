"""Tests for MemoClaw sync client (mocked HTTP)."""

from __future__ import annotations

from unittest.mock import patch

import httpx
import pytest
import respx

from memoclaw import (
    AsyncMemoClaw,
    MemoClaw,
    NotFoundError,
    StoreResult,
    ValidationError,
)

# A valid Ethereum private key for testing (DO NOT use in production)
TEST_PRIVATE_KEY = "0x4c0883a69102937d6231471b5dbb6204fe512961708279f15a8f7e20b4e3b1fb"
BASE_URL = "https://api.memoclaw.com"


@pytest.fixture
def client():
    c = MemoClaw(private_key=TEST_PRIVATE_KEY, base_url=BASE_URL)
    yield c
    c.close()


@pytest.fixture
def async_client():
    return AsyncMemoClaw(private_key=TEST_PRIVATE_KEY, base_url=BASE_URL)


def _assert_wallet_auth_header(request: httpx.Request):
    """Validate x-wallet-auth header format: {address}:{timestamp}:{signature}."""
    auth = request.headers.get("x-wallet-auth", "")
    parts = auth.split(":")
    # address:timestamp:signature (signature is hex without 0x, so no extra colons)
    assert len(parts) == 3, f"Expected 3 parts in wallet auth, got {len(parts)}: {auth}"
    address, timestamp, signature = parts
    assert address.startswith("0x"), "Address should start with 0x"
    assert len(address) == 42, "Address should be 42 chars"
    assert timestamp.isdigit(), "Timestamp should be numeric"
    assert len(signature) > 0, "Signature should not be empty"


class TestWalletAuth:
    @respx.mock
    def test_auth_header_format(self, client: MemoClaw):
        route = respx.get(f"{BASE_URL}/v1/free-tier/status").mock(
            return_value=httpx.Response(
                200,
                json={
                    "wallet": "0x2c7536E3605D9C16a7a3D7b1898e529396a65c23",
                    "free_tier_remaining": 1000,
                    "free_tier_total": 1000,
                    "free_tier_used": 0,
                },
            )
        )
        client.status()
        assert route.called
        _assert_wallet_auth_header(route.calls[0].request)


class TestStore:
    @respx.mock
    def test_store_basic(self, client: MemoClaw):
        respx.post(f"{BASE_URL}/v1/store").mock(
            return_value=httpx.Response(
                201,
                json={
                    "id": "mem-123",
                    "stored": True,
                    "deduplicated": False,
                    "tokens_used": 42,
                },
            )
        )
        result = client.store("User prefers tabs", importance=0.8, tags=["prefs"])
        assert isinstance(result, StoreResult)
        assert result.id == "mem-123"
        assert result.tokens_used == 42

    @respx.mock
    def test_store_with_all_options(self, client: MemoClaw):
        route = respx.post(f"{BASE_URL}/v1/store").mock(
            return_value=httpx.Response(
                201,
                json={
                    "id": "mem-456",
                    "stored": True,
                    "deduplicated": True,
                    "tokens_used": 30,
                },
            )
        )
        result = client.store(
            "Test content",
            importance=0.9,
            tags=["a", "b"],
            namespace="project",
            memory_type="preference",
            session_id="sess1",
            agent_id="agent1",
            expires_at="2026-01-01T00:00:00Z",
        )
        assert result.deduplicated is True
        # Verify body was sent correctly
        body = route.calls[0].request.content
        assert b"Test content" in body


class TestRecall:
    @respx.mock
    def test_recall_basic(self, client: MemoClaw):
        respx.post(f"{BASE_URL}/v1/recall").mock(
            return_value=httpx.Response(
                200,
                json={
                    "memories": [
                        {
                            "id": "m1",
                            "content": "User prefers tabs",
                            "similarity": 0.95,
                            "metadata": {"tags": ["prefs"]},
                            "importance": 0.8,
                            "memory_type": "preference",
                            "namespace": "default",
                            "session_id": None,
                            "agent_id": None,
                            "created_at": "2025-01-01T00:00:00Z",
                            "access_count": 3,
                        }
                    ],
                    "query_tokens": 5,
                },
            )
        )
        result = client.recall("code preferences", limit=5)
        assert len(result.memories) == 1
        assert result.memories[0].similarity == 0.95
        assert result.query_tokens == 5


class TestGet:
    @respx.mock
    def test_get_memory(self, client: MemoClaw):
        respx.get(f"{BASE_URL}/v1/memories/mem-123").mock(
            return_value=httpx.Response(
                200,
                json={
                    "id": "mem-123",
                    "user_id": "u1",
                    "namespace": "default",
                    "content": "Test content",
                    "embedding_model": "text-embedding-3-small",
                    "metadata": {},
                    "importance": 0.8,
                    "memory_type": "general",
                    "session_id": None,
                    "agent_id": None,
                    "created_at": "2025-01-01T00:00:00Z",
                    "updated_at": "2025-01-01T00:00:00Z",
                    "accessed_at": "2025-01-01T00:00:00Z",
                    "access_count": 1,
                    "deleted_at": None,
                    "expires_at": None,
                    "pinned": False,
                },
            )
        )
        result = client.get("mem-123")
        assert result.id == "mem-123"
        assert result.content == "Test content"


class TestUpdate:
    @respx.mock
    def test_update_content(self, client: MemoClaw):
        respx.patch(f"{BASE_URL}/v1/memories/mem-123").mock(
            return_value=httpx.Response(
                200,
                json={
                    "id": "mem-123",
                    "user_id": "u1",
                    "namespace": "default",
                    "content": "Updated content",
                    "embedding_model": "text-embedding-3-small",
                    "metadata": {},
                    "importance": 0.9,
                    "memory_type": "general",
                    "session_id": None,
                    "agent_id": None,
                    "created_at": "2025-01-01T00:00:00Z",
                    "updated_at": "2025-06-01T00:00:00Z",
                    "accessed_at": "2025-01-01T00:00:00Z",
                    "access_count": 1,
                    "deleted_at": None,
                    "expires_at": None,
                },
            )
        )
        result = client.update("mem-123", content="Updated content", importance=0.9)
        assert result.content == "Updated content"
        assert result.importance == 0.9


class TestDelete:
    @respx.mock
    def test_delete(self, client: MemoClaw):
        respx.delete(f"{BASE_URL}/v1/memories/mem-123").mock(
            return_value=httpx.Response(
                200, json={"deleted": True, "id": "mem-123"}
            )
        )
        result = client.delete("mem-123")
        assert result.deleted is True
        assert result.id == "mem-123"


class TestList:
    @respx.mock
    def test_list_basic(self, client: MemoClaw):
        respx.get(f"{BASE_URL}/v1/memories").mock(
            return_value=httpx.Response(
                200,
                json={
                    "memories": [],
                    "total": 0,
                    "limit": 20,
                    "offset": 0,
                },
            )
        )
        result = client.list()
        assert result.total == 0


class TestIngest:
    @respx.mock
    def test_ingest_messages(self, client: MemoClaw):
        respx.post(f"{BASE_URL}/v1/ingest").mock(
            return_value=httpx.Response(
                201,
                json={
                    "memory_ids": ["a", "b"],
                    "facts_extracted": 3,
                    "facts_stored": 2,
                    "facts_deduplicated": 1,
                    "relations_created": 1,
                    "tokens_used": 150,
                },
            )
        )
        result = client.ingest(
            messages=[
                {"role": "user", "content": "I prefer Python over JS"},
                {"role": "assistant", "content": "Noted!"},
            ]
        )
        assert result.facts_extracted == 3
        assert len(result.memory_ids) == 2


class TestExtract:
    @respx.mock
    def test_extract(self, client: MemoClaw):
        respx.post(f"{BASE_URL}/v1/memories/extract").mock(
            return_value=httpx.Response(
                201,
                json={
                    "memory_ids": ["a"],
                    "facts_extracted": 1,
                    "facts_stored": 1,
                    "facts_deduplicated": 0,
                    "tokens_used": 50,
                },
            )
        )
        result = client.extract([{"role": "user", "content": "I use vim"}])
        assert result.facts_extracted == 1


class TestConsolidate:
    @respx.mock
    def test_consolidate(self, client: MemoClaw):
        respx.post(f"{BASE_URL}/v1/memories/consolidate").mock(
            return_value=httpx.Response(
                200,
                json={
                    "clusters_found": 1,
                    "memories_merged": 2,
                    "memories_created": 1,
                    "clusters": [
                        {
                            "memory_ids": ["a", "b"],
                            "similarity": 0.92,
                            "merged_into": "c",
                        }
                    ],
                },
            )
        )
        result = client.consolidate(min_similarity=0.85)
        assert result.clusters_found == 1
        assert result.clusters[0].merged_into == "c"


class TestSuggested:
    @respx.mock
    def test_suggested(self, client: MemoClaw):
        respx.get(f"{BASE_URL}/v1/suggested").mock(
            return_value=httpx.Response(
                200,
                json={
                    "suggested": [
                        {
                            "id": "s1",
                            "content": "stale memory",
                            "metadata": {},
                            "importance": 0.8,
                            "memory_type": "general",
                            "namespace": "default",
                            "session_id": None,
                            "agent_id": None,
                            "created_at": "2025-01-01T00:00:00Z",
                            "accessed_at": "2025-01-01T00:00:00Z",
                            "access_count": 0,
                            "relation_count": 0,
                            "category": "stale",
                            "review_score": 0.75,
                        }
                    ],
                    "categories": {"stale": 1},
                    "total": 1,
                },
            )
        )
        result = client.suggested(category="stale")
        assert result.total == 1
        assert result.suggested[0].category == "stale"


class TestRelations:
    @respx.mock
    def test_create_relation(self, client: MemoClaw):
        respx.post(f"{BASE_URL}/v1/memories/m1/relations").mock(
            return_value=httpx.Response(
                201,
                json={
                    "id": "rel1",
                    "source_id": "m1",
                    "target_id": "m2",
                    "relation_type": "related_to",
                    "metadata": {},
                    "created_at": "2025-01-01T00:00:00Z",
                },
            )
        )
        result = client.create_relation("m1", "m2", "related_to")
        assert result.id == "rel1"
        assert result.relation_type == "related_to"

    @respx.mock
    def test_list_relations(self, client: MemoClaw):
        respx.get(f"{BASE_URL}/v1/memories/m1/relations").mock(
            return_value=httpx.Response(200, json={"relations": []})
        )
        result = client.list_relations("m1")
        assert result == []

    @respx.mock
    def test_delete_relation(self, client: MemoClaw):
        respx.delete(f"{BASE_URL}/v1/memories/m1/relations/rel1").mock(
            return_value=httpx.Response(200, json={"deleted": True})
        )
        result = client.delete_relation("m1", "rel1")
        assert result.deleted is True


class TestStatus:
    @respx.mock
    def test_status(self, client: MemoClaw):
        respx.get(f"{BASE_URL}/v1/free-tier/status").mock(
            return_value=httpx.Response(
                200,
                json={
                    "wallet": "0xabc",
                    "free_tier_remaining": 950,
                    "free_tier_total": 1000,
                    "free_tier_used": 50,
                },
            )
        )
        result = client.status()
        assert result.free_tier_remaining == 950


class TestErrorMapping:
    @respx.mock
    def test_404_raises_not_found(self, client: MemoClaw):
        respx.delete(f"{BASE_URL}/v1/memories/nonexistent").mock(
            return_value=httpx.Response(
                404,
                json={"error": {"code": "NOT_FOUND", "message": "Memory not found"}},
            )
        )
        with pytest.raises(NotFoundError) as exc_info:
            client.delete("nonexistent")
        assert exc_info.value.status_code == 404
        assert exc_info.value.code == "NOT_FOUND"

    @respx.mock
    def test_422_raises_validation(self, client: MemoClaw):
        respx.post(f"{BASE_URL}/v1/store").mock(
            return_value=httpx.Response(
                422,
                json={
                    "error": {
                        "code": "VALIDATION_ERROR",
                        "message": "Invalid content",
                    }
                },
            )
        )
        with pytest.raises(ValidationError) as exc_info:
            client.store("some content that triggers server-side validation")
        assert exc_info.value.status_code == 422


class TestPayment402:
    @respx.mock
    def test_402_without_x402_raises(self, client: MemoClaw):
        """When x402 is not available, 402 should raise PaymentRequiredError."""
        respx.post(f"{BASE_URL}/v1/store").mock(
            return_value=httpx.Response(
                402,
                json={
                    "error": {
                        "code": "PAYMENT_REQUIRED",
                        "message": "Free tier exhausted",
                    }
                },
            )
        )
        from memoclaw.errors import PaymentRequiredError

        # Patch x402 import to fail
        with patch("memoclaw._client._try_x402_payment", return_value=None):
            with pytest.raises(PaymentRequiredError):
                client.store("test")

    @respx.mock
    def test_402_with_x402_retries(self, client: MemoClaw):
        """When x402 provides payment headers, the request should be retried."""
        # First call returns 402, second succeeds
        route = respx.post(f"{BASE_URL}/v1/store").mock(
            side_effect=[
                httpx.Response(
                    402,
                    json={
                        "error": {
                            "code": "PAYMENT_REQUIRED",
                            "message": "Free tier exhausted",
                        }
                    },
                ),
                httpx.Response(
                    201,
                    json={
                        "id": "mem-paid",
                        "stored": True,
                        "deduplicated": False,
                        "tokens_used": 42,
                    },
                ),
            ]
        )
        with patch(
            "memoclaw._client._try_x402_payment",
            return_value={"x-payment": "paid-token"},
        ):
            result = client.store("test")
            assert result.id == "mem-paid"
            assert route.call_count == 2


class TestEnvVar:
    def test_env_var_fallback(self, monkeypatch):
        monkeypatch.setenv("MEMOCLAW_PRIVATE_KEY", TEST_PRIVATE_KEY)
        c = MemoClaw()
        c.close()

    def test_missing_key_raises(self, monkeypatch):
        monkeypatch.delenv("MEMOCLAW_PRIVATE_KEY", raising=False)
        monkeypatch.delenv("MEMOCLAW_WALLET", raising=False)
        with pytest.raises(ValueError, match="No private key|No authentication"):
            MemoClaw()


class TestWalletOnlyAuth:
    """Test wallet-only (read-only) authentication mode."""

    def test_wallet_only_init(self, monkeypatch):
        monkeypatch.delenv("MEMOCLAW_PRIVATE_KEY", raising=False)
        monkeypatch.delenv("MEMOCLAW_WALLET", raising=False)
        monkeypatch.delenv("MEMOCLAW_URL", raising=False)
        c = MemoClaw(wallet_address="0x1234567890abcdef1234567890abcdef12345678", base_url=BASE_URL)
        c.close()

    def test_wallet_only_env_var(self, monkeypatch):
        monkeypatch.delenv("MEMOCLAW_PRIVATE_KEY", raising=False)
        monkeypatch.delenv("MEMOCLAW_URL", raising=False)
        monkeypatch.setenv("MEMOCLAW_WALLET", "0x1234567890abcdef1234567890abcdef12345678")
        c = MemoClaw(base_url=BASE_URL)
        c.close()

    @respx.mock
    def test_wallet_only_sends_plain_address(self, monkeypatch):
        monkeypatch.delenv("MEMOCLAW_PRIVATE_KEY", raising=False)
        monkeypatch.delenv("MEMOCLAW_WALLET", raising=False)
        monkeypatch.delenv("MEMOCLAW_URL", raising=False)
        wallet = "0x1234567890abcdef1234567890abcdef12345678"
        respx.get(f"{BASE_URL}/v1/free-tier/status").mock(
            return_value=httpx.Response(
                200,
                json={
                    "wallet": wallet,
                    "free_tier_remaining": 100,
                    "free_tier_total": 100,
                    "free_tier_used": 0,
                },
            )
        )
        c = MemoClaw(wallet_address=wallet, base_url=BASE_URL)
        result = c.status()
        assert result.free_tier_remaining == 100
        # Verify the auth header is just the wallet address (no signature)
        req = respx.calls.last.request
        assert req.headers["x-wallet-auth"] == wallet
        c.close()

    def test_wallet_only_rejects_paid_endpoints(self, monkeypatch):
        """Wallet-only clients should raise ValueError for paid endpoints."""
        monkeypatch.delenv("MEMOCLAW_PRIVATE_KEY", raising=False)
        monkeypatch.delenv("MEMOCLAW_WALLET", raising=False)
        monkeypatch.delenv("MEMOCLAW_URL", raising=False)
        wallet = "0x1234567890abcdef1234567890abcdef12345678"
        c = MemoClaw(wallet_address=wallet, base_url=BASE_URL)

        import pytest

        paid_methods = [
            ("store", lambda: c.store("test")),
            ("store_batch", lambda: c.store_batch([{"content": "test"}])),
            ("recall", lambda: c.recall("query")),
            ("update", lambda: c.update("mem-1", content="new")),
            ("update_batch", lambda: c.update_batch([{"id": "mem-1", "content": "new"}])),
            ("ingest", lambda: c.ingest(text="test")),
            ("extract", lambda: c.extract([{"role": "user", "content": "test"}])),
            ("consolidate", lambda: c.consolidate()),
            ("create_relation", lambda: c.create_relation("m1", "m2", "related_to")),
            ("migrate", lambda: c.migrate([{"filename": "f.md", "content": "c"}])),
            ("assemble_context", lambda: c.assemble_context("query")),
        ]

        for method_name, fn in paid_methods:
            with pytest.raises(ValueError, match="requires a private key"):
                fn()

        c.close()


class TestContextManager:
    @respx.mock
    def test_sync_context_manager(self):
        respx.get(f"{BASE_URL}/v1/free-tier/status").mock(
            return_value=httpx.Response(
                200,
                json={
                    "wallet": "0xabc",
                    "free_tier_remaining": 1000,
                    "free_tier_total": 1000,
                    "free_tier_used": 0,
                },
            )
        )
        with MemoClaw(private_key=TEST_PRIVATE_KEY, base_url=BASE_URL) as c:
            result = c.status()
            assert result.free_tier_remaining == 1000


class TestStoreBatch:
    @respx.mock
    def test_store_batch_nests_tags_in_metadata(self, client: MemoClaw):
        """StoreInput.tags should be nested inside metadata, not sent as top-level field."""
        from memoclaw import StoreInput

        route = respx.post(f"{BASE_URL}/v1/store/batch").mock(
            return_value=httpx.Response(
                201,
                json={
                    "ids": ["m1", "m2"],
                    "stored": True,
                    "count": 2,
                    "deduplicated_count": 0,
                    "tokens_used": 84,
                },
            )
        )
        inputs = [
            StoreInput(content="Memory A", tags=["tag1", "tag2"], importance=0.8),
            StoreInput(content="Memory B", metadata={"existing": True}, tags=["tag3"]),
        ]
        result = client.store_batch(inputs)
        assert result.count == 2

        # Verify the request body has tags nested inside metadata
        import json as json_mod
        body = json_mod.loads(route.calls[0].request.content)
        memories = body["memories"]
        # First memory: tags should be inside metadata
        assert "tags" not in memories[0] or "tags" in memories[0].get("metadata", {})
        assert memories[0]["metadata"]["tags"] == ["tag1", "tag2"]
        # Second memory: tags merged into existing metadata
        assert memories[1]["metadata"]["tags"] == ["tag3"]
        assert memories[1]["metadata"]["existing"] is True
        # tags should NOT be a top-level field
        assert "tags" not in {k for k in memories[0] if k != "metadata"}


class TestIterMemories:
    @respx.mock
    def test_iter_memories_pagination(self, client: MemoClaw):
        """iter_memories should auto-paginate through all memories."""
        mem_json = lambda i: {
            "id": f"m{i}", "user_id": "u1", "namespace": "default",
            "content": f"mem {i}", "embedding_model": "text-embedding-3-small",
            "metadata": {}, "importance": 0.5, "memory_type": "general",
            "session_id": None, "agent_id": None,
            "created_at": "2025-01-01T00:00:00Z",
            "updated_at": "2025-01-01T00:00:00Z",
            "accessed_at": "2025-01-01T00:00:00Z",
            "access_count": 0, "deleted_at": None, "expires_at": None,
            "pinned": False,
        }
        route = respx.get(f"{BASE_URL}/v1/memories").mock(
            side_effect=[
                httpx.Response(200, json={
                    "memories": [mem_json(1), mem_json(2)],
                    "total": 3, "limit": 2, "offset": 0,
                }),
                httpx.Response(200, json={
                    "memories": [mem_json(3)],
                    "total": 3, "limit": 2, "offset": 2,
                }),
            ]
        )
        memories = list(client.iter_memories(batch_size=2))
        assert len(memories) == 3
        assert [m.id for m in memories] == ["m1", "m2", "m3"]
        assert route.call_count == 2

    @respx.mock
    def test_iter_memories_with_filters(self, client: MemoClaw):
        """iter_memories should pass memory_type, before, after, include_deleted to list()."""
        mem_json = {
            "id": "m1", "user_id": "u1", "namespace": "default",
            "content": "mem 1", "embedding_model": "text-embedding-3-small",
            "metadata": {}, "importance": 0.5, "memory_type": "preference",
            "session_id": None, "agent_id": None,
            "created_at": "2025-06-01T00:00:00Z",
            "updated_at": "2025-06-01T00:00:00Z",
            "accessed_at": "2025-06-01T00:00:00Z",
            "access_count": 0, "deleted_at": None, "expires_at": None,
            "pinned": False,
        }
        route = respx.get(f"{BASE_URL}/v1/memories").mock(
            return_value=httpx.Response(200, json={
                "memories": [mem_json],
                "total": 1, "limit": 50, "offset": 0,
            })
        )
        memories = list(client.iter_memories(
            memory_type="preference",
            after="2025-01-01T00:00:00Z",
            before="2026-01-01T00:00:00Z",
            include_deleted=True,
        ))
        assert len(memories) == 1
        url_str = str(route.calls[0].request.url)
        assert "memory_type=preference" in url_str
        assert "after=2025-01-01" in url_str
        assert "before=2026-01-01" in url_str
        assert "include_deleted=true" in url_str

    @respx.mock
    def test_iter_export_pagination(self, client: MemoClaw):
        """iter_export should auto-paginate through all memories."""
        mem_json = lambda i: {
            "id": f"m{i}", "user_id": "u1", "namespace": "default",
            "content": f"mem {i}", "embedding_model": "text-embedding-3-small",
            "metadata": {}, "importance": 0.5, "memory_type": "general",
            "session_id": None, "agent_id": None,
            "created_at": "2025-01-01T00:00:00Z",
            "updated_at": "2025-01-01T00:00:00Z",
            "accessed_at": "2025-01-01T00:00:00Z",
            "access_count": 0, "deleted_at": None, "expires_at": None,
            "pinned": False,
        }
        route = respx.get(f"{BASE_URL}/v1/memories").mock(
            side_effect=[
                httpx.Response(200, json={
                    "memories": [mem_json(1), mem_json(2)],
                    "total": 3, "limit": 2, "offset": 0,
                }),
                httpx.Response(200, json={
                    "memories": [mem_json(3)],
                    "total": 3, "limit": 2, "offset": 2,
                }),
            ]
        )
        memories = list(client.iter_export(batch_size=2))
        assert len(memories) == 3
        assert [m.id for m in memories] == ["m1", "m2", "m3"]
        assert route.call_count == 2

    @respx.mock
    def test_iter_export_with_namespace_filter(self, client: MemoClaw):
        """iter_export should pass namespace filter to list."""
        mem_json = {
            "id": "m1", "user_id": "u1", "namespace": "project-a",
            "content": "mem 1", "embedding_model": "text-embedding-3-small",
            "metadata": {}, "importance": 0.5, "memory_type": "general",
            "session_id": None, "agent_id": None,
            "created_at": "2025-01-01T00:00:00Z",
            "updated_at": "2025-01-01T00:00:00Z",
            "accessed_at": "2025-01-01T00:00:00Z",
            "access_count": 0, "deleted_at": None, "expires_at": None,
            "pinned": False,
        }
        route = respx.get(f"{BASE_URL}/v1/memories").mock(
            return_value=httpx.Response(200, json={
                "memories": [mem_json],
                "total": 1, "limit": 50, "offset": 0,
            })
        )
        memories = list(client.iter_export(namespace="project-a"))
        assert len(memories) == 1
        assert memories[0].namespace == "project-a"
        # Verify the namespace param was sent
        assert "namespace=project-a" in str(route.calls[0].request.url)


class TestAsyncClient:
    @respx.mock
    @pytest.mark.asyncio
    async def test_async_store(self, async_client: AsyncMemoClaw):
        respx.post(f"{BASE_URL}/v1/store").mock(
            return_value=httpx.Response(
                201,
                json={
                    "id": "async-123",
                    "stored": True,
                    "deduplicated": False,
                    "tokens_used": 42,
                },
            )
        )
        result = await async_client.store("Async test", importance=0.5)
        assert result.id == "async-123"
        await async_client.close()

    @respx.mock
    @pytest.mark.asyncio
    async def test_async_context_manager(self):
        respx.get(f"{BASE_URL}/v1/free-tier/status").mock(
            return_value=httpx.Response(
                200,
                json={
                    "wallet": "0xabc",
                    "free_tier_remaining": 1000,
                    "free_tier_total": 1000,
                    "free_tier_used": 0,
                },
            )
        )
        async with AsyncMemoClaw(private_key=TEST_PRIVATE_KEY, base_url=BASE_URL) as c:
            result = await c.status()
            assert result.free_tier_remaining == 1000

    @respx.mock
    @pytest.mark.asyncio
    async def test_async_create_factory(self):
        """AsyncMemoClaw.create() validates connection via ping()."""
        respx.get(f"{BASE_URL}/v1/free-tier/status").mock(
            return_value=httpx.Response(
                200,
                json={
                    "wallet": "0xabc",
                    "free_tier_remaining": 100,
                    "free_tier_total": 100,
                    "free_tier_used": 0,
                },
            )
        )
        client = await AsyncMemoClaw.create(
            private_key=TEST_PRIVATE_KEY,
            base_url=BASE_URL,
            validate_on_init=True,
        )
        assert client is not None
        await client.close()

    @respx.mock
    @pytest.mark.asyncio
    async def test_async_create_factory_no_validate(self):
        """AsyncMemoClaw.create(validate_on_init=False) skips ping."""
        client = await AsyncMemoClaw.create(
            private_key=TEST_PRIVATE_KEY,
            base_url=BASE_URL,
            validate_on_init=False,
        )
        assert client is not None
        await client.close()


# ── Parameter validation tests ───────────────────────────────────────────────


class TestParameterValidation:
    """Tests for client-side numeric parameter validation."""

    def test_list_negative_limit(self, client: MemoClaw):
        with pytest.raises(ValueError, match="limit must be a positive integer"):
            client.list(limit=-1)

    def test_list_zero_limit(self, client: MemoClaw):
        with pytest.raises(ValueError, match="limit must be a positive integer"):
            client.list(limit=0)

    def test_list_negative_offset(self, client: MemoClaw):
        with pytest.raises(ValueError, match="offset must be a non-negative integer"):
            client.list(offset=-5)

    @respx.mock
    def test_recall_invalid_min_similarity(self, client: MemoClaw):
        with pytest.raises(ValueError, match="min_similarity must be between"):
            client.recall("test query", min_similarity=1.5)

    @respx.mock
    def test_recall_negative_min_similarity(self, client: MemoClaw):
        with pytest.raises(ValueError, match="min_similarity must be between"):
            client.recall("test query", min_similarity=-0.1)

    @respx.mock
    def test_recall_negative_limit(self, client: MemoClaw):
        with pytest.raises(ValueError, match="limit must be a positive integer"):
            client.recall("test query", limit=-1)

    def test_iter_memories_zero_batch_size(self, client: MemoClaw):
        with pytest.raises(ValueError, match="batch_size must be a positive integer"):
            # Need to consume the generator to trigger validation
            list(client.iter_memories(batch_size=0))

    @respx.mock
    def test_text_search_negative_limit(self, client: MemoClaw):
        with pytest.raises(ValueError, match="limit must be a positive integer"):
            client.text_search("test", limit=-1)

    @respx.mock
    def test_delete_namespace_empty_string(self, client: MemoClaw):
        with pytest.raises(ValueError, match="namespace"):
            client.delete_namespace("")

    @respx.mock
    def test_delete_namespace_zero_batch_size(self, client: MemoClaw):
        with pytest.raises(ValueError, match="batch_size must be a positive integer"):
            client.delete_namespace("test", batch_size=0)


@pytest.mark.asyncio
class TestAsyncParameterValidation:
    """Async versions of parameter validation tests."""

    async def test_list_negative_limit(self):
        client = AsyncMemoClaw(private_key=TEST_PRIVATE_KEY, base_url=BASE_URL)
        with pytest.raises(ValueError, match="limit must be a positive integer"):
            await client.list(limit=-1)
        await client.close()

    async def test_list_negative_offset(self):
        client = AsyncMemoClaw(private_key=TEST_PRIVATE_KEY, base_url=BASE_URL)
        with pytest.raises(ValueError, match="offset must be a non-negative integer"):
            await client.list(offset=-5)
        await client.close()

    async def test_recall_invalid_min_similarity(self):
        client = AsyncMemoClaw(private_key=TEST_PRIVATE_KEY, base_url=BASE_URL)
        with pytest.raises(ValueError, match="min_similarity must be between"):
            await client.recall("test query", min_similarity=2.0)
        await client.close()
