"""Tests for builder patterns."""

import pytest

from memoclaw import MemoryBuilder, RecallBuilder, StoreInput


class TestMemoryBuilder:
    def test_basic_builder(self):
        builder = MemoryBuilder()
        memory = builder.content("Test memory").build()
        
        assert isinstance(memory, StoreInput)
        assert memory.content == "Test memory"

    def test_full_builder(self):
        memory = (
            MemoryBuilder()
            .content("User prefers dark mode")
            .importance(0.9)
            .tags(["preferences", "ui"])
            .namespace("app-settings")
            .memory_type("preference")
            .pinned(True)
            .build()
        )
        
        assert memory.content == "User prefers dark mode"
        assert memory.importance == 0.9
        assert memory.tags == ["preferences", "ui"]
        assert memory.namespace == "app-settings"
        assert memory.memory_type == "preference"
        assert memory.pinned is True

    def test_add_tag(self):
        memory = (
            MemoryBuilder()
            .content("Test")
            .add_tag("tag1")
            .add_tag("tag2")
            .build()
        )
        assert memory.tags == ["tag1", "tag2"]

    def test_add_metadata(self):
        memory = (
            MemoryBuilder()
            .content("Test")
            .add_metadata("key1", "value1")
            .add_metadata("key2", 42)
            .build()
        )
        assert memory.metadata == {"key1": "value1", "key2": 42}

    def test_set_metadata(self):
        memory = (
            MemoryBuilder()
            .content("Test")
            .metadata({"custom": "data"})
            .build()
        )
        assert memory.metadata == {"custom": "data"}

    def test_expires_in_days(self):
        memory = (
            MemoryBuilder()
            .content("Test")
            .expires_in_days(7)
            .build()
        )
        assert memory.expires_at is not None
        assert memory.expires_at.endswith("Z")
        # Must not have double timezone suffix (e.g., "+00:00Z")
        assert "+00:00Z" not in memory.expires_at

    def test_importance_validation_high(self):
        with pytest.raises(ValueError, match="between 0.0 and 1.0"):
            MemoryBuilder().content("Test").importance(1.5)

    def test_importance_validation_low(self):
        with pytest.raises(ValueError, match="between 0.0 and 1.0"):
            MemoryBuilder().content("Test").importance(-0.1)

    def test_build_requires_content(self):
        with pytest.raises(ValueError, match="content is required"):
            MemoryBuilder().build()

    def test_to_dict(self):
        result = (
            MemoryBuilder()
            .content("Test memory")
            .importance(0.8)
            .to_dict()
        )
        assert result == {
            "content": "Test memory",
            "importance": 0.8,
        }


class TestRecallBuilder:
    def test_basic_recall(self):
        params = RecallBuilder().query("search term").build()
        
        assert params == {"query": "search term"}

    def test_full_recall(self):
        params = (
            RecallBuilder()
            .query("dark mode preferences")
            .limit(10)
            .min_similarity(0.7)
            .namespace("app-settings")
            .session("sess-123")
            .agent("agent-456")
            .include_relations(True)
            .build()
        )
        
        assert params["query"] == "dark mode preferences"
        assert params["limit"] == 10
        assert params["min_similarity"] == 0.7
        assert params["namespace"] == "app-settings"
        assert params["session_id"] == "sess-123"
        assert params["agent_id"] == "agent-456"
        assert params["include_relations"] is True

    def test_recall_with_tags(self):
        params = (
            RecallBuilder()
            .query("test")
            .tags(["tag1", "tag2"])
            .build()
        )
        
        assert params["tags"] == ["tag1", "tag2"]

    def test_recall_with_memory_type(self):
        params = (
            RecallBuilder()
            .query("test")
            .memory_type("preference")
            .build()
        )
        
        assert params["memory_type"] == "preference"

    def test_recall_requires_query(self):
        with pytest.raises(ValueError, match="query is required"):
            RecallBuilder().build()

    def test_min_similarity_validation(self):
        with pytest.raises(ValueError, match="between 0.0 and 1.0"):
            RecallBuilder().query("test").min_similarity(1.1)


# ── Tests from PR: builder classes with client integration ──

import respx
import httpx

from memoclaw import MemoClaw, AsyncMemoClaw
from memoclaw.builders import (
    AsyncBatchStore,
    AsyncMemoryFilter,
    AsyncRecallQuery,
    AsyncStoreBuilder,
    BatchStore,
    MemoryFilter,
    RecallQuery,
    RelationBuilder,
    StoreBuilder,
)

# Test private key
TEST_PRIVATE_KEY = "0x4c0883a69102937d6231471b5dbb6204fe512961708279f15a8f7e20b4e3b1fb"
BASE_URL = "https://api.memoclaw.com"

@pytest.fixture
def client():
    c = MemoClaw(private_key=TEST_PRIVATE_KEY, base_url=BASE_URL)
    yield c
    c.close()


@pytest.fixture
def async_client():
    return AsyncMemoClaw(private_key=TEST_PRIVATE_KEY, base_url=BASE_URL)


class TestRecallQuery:
    """Tests for RecallQuery builder."""

    @respx.mock
    def test_basic_recall(self, client: MemoClaw):
        """Test basic recall with query only."""
        respx.post(f"{BASE_URL}/v1/recall").mock(
            return_value=httpx.Response(
                200,
                json={
                    "memories": [
                        {
                            "id": "m1",
                            "content": "User prefers Python",
                            "similarity": 0.95,
                            "metadata": {},
                            "importance": 0.8,
                            "memory_type": "preference",
                            "namespace": "default",
                            "session_id": None,
                            "agent_id": None,
                            "created_at": "2025-01-01T00:00:00Z",
                            "access_count": 1,
                        }
                    ],
                    "query_tokens": 5,
                },
            )
        )
        
        result = (RecallQuery(client)
            .with_query("programming language preferences")
            .execute())
        
        assert len(result.memories) == 1
        assert result.memories[0].content == "User prefers Python"

    @respx.mock
    def test_recall_with_filters(self, client: MemoClaw):
        """Test recall with multiple filters."""
        respx.post(f"{BASE_URL}/v1/recall").mock(
            return_value=httpx.Response(
                200,
                json={"memories": [], "query_tokens": 5},
            )
        )
        
        result = (RecallQuery(client)
            .with_query("preferences")
            .with_limit(10)
            .with_min_similarity(0.7)
            .with_namespace("user-prefs")
            .with_tags(["important"])
            .with_session_id("session-123")
            .with_memory_type("preference")
            .include_relations()
            .execute())
        
        assert result is not None

    def test_recall_without_query_raises(self, client: MemoClaw):
        """Test that executing without query raises ValueError."""
        with pytest.raises(ValueError, match="Query is required"):
            RecallQuery(client).execute()

    def test_invalid_similarity_raises(self, client: MemoClaw):
        """Test that invalid similarity raises ValueError."""
        with pytest.raises(ValueError, match="min_similarity must be between"):
            RecallQuery(client).with_min_similarity(1.5)


class TestAsyncRecallQuery:
    """Tests for AsyncRecallQuery builder."""

    @respx.mock
    @pytest.mark.asyncio
    async def test_async_recall(self, async_client: AsyncMemoClaw):
        """Test async recall query."""
        respx.post(f"{BASE_URL}/v1/recall").mock(
            return_value=httpx.Response(
                200,
                json={"memories": [], "query_tokens": 5},
            )
        )
        
        result = await (AsyncRecallQuery(async_client)
            .with_query("test")
            .execute())
        
        assert result is not None


class TestMemoryFilter:
    """Tests for MemoryFilter builder."""

    @respx.mock
    def test_iter_memories(self, client: MemoClaw):
        """Test iterating over memories with filters."""
        mem_json = lambda i: {
            "id": f"m{i}",
            "user_id": "u1",
            "namespace": "default",
            "content": f"mem {i}",
            "embedding_model": "text-embedding-3-small",
            "metadata": {},
            "importance": 0.5,
            "memory_type": "general",
            "session_id": None,
            "agent_id": None,
            "created_at": "2025-01-01T00:00:00Z",
            "updated_at": "2025-01-01T00:00:00Z",
            "accessed_at": "2025-01-01T00:00:00Z",
            "access_count": 0,
            "deleted_at": None,
            "expires_at": None,
            "pinned": False,
        }
        
        respx.get(f"{BASE_URL}/v1/memories").mock(
            side_effect=[
                httpx.Response(200, json={
                    "memories": [mem_json(1)],
                    "total": 1,
                    "limit": 50,
                    "offset": 0,
                }),
            ]
        )
        
        memories = list(MemoryFilter(client)
            .with_namespace("default")
            .iter_memories())
        
        assert len(memories) == 1

    @respx.mock
    def test_count(self, client: MemoClaw):
        """Test counting memories."""
        respx.get(f"{BASE_URL}/v1/memories").mock(
            return_value=httpx.Response(
                200,
                json={
                    "memories": [],
                    "total": 42,
                    "limit": 1,
                    "offset": 0,
                },
            )
        )
        
        count = MemoryFilter(client).with_namespace("test").count()
        assert count == 42

    def test_invalid_batch_size_raises(self, client: MemoClaw):
        """Test that invalid batch size raises ValueError."""
        with pytest.raises(ValueError, match="batch_size must be positive"):
            MemoryFilter(client).with_batch_size(0)


class TestAsyncMemoryFilter:
    """Tests for AsyncMemoryFilter builder."""

    @respx.mock
    @pytest.mark.asyncio
    async def test_async_iter_memories(self, async_client: AsyncMemoClaw):
        """Test async iteration over memories."""
        respx.get(f"{BASE_URL}/v1/memories").mock(
            return_value=httpx.Response(
                200,
                json={
                    "memories": [],
                    "total": 0,
                    "limit": 50,
                    "offset": 0,
                },
            )
        )
        
        memories = [m async for m in AsyncMemoryFilter(async_client).iter_memories()]
        assert memories == []


class TestRelationBuilder:
    """Tests for RelationBuilder."""

    @respx.mock
    def test_create_single_relation(self, client: MemoClaw):
        """Test creating a single relation."""
        respx.post(f"{BASE_URL}/v1/memories/m1/relations").mock(
            return_value=httpx.Response(
                201,
                json={
                    "id": "rel1",
                    "source_id": "m1",
                    "target_id": "m2",
                    "relation_type": "related_to",
                    "metadata": {},
                    "created_at": "2025-01-01T00:00:00Z",
                },
            )
        )
        
        result = (RelationBuilder(client, "m1")
            .relate_to("m2", "related_to")
            .create_all())
        
        assert len(result) == 1
        assert result[0]["target_id"] == "m2"

    @respx.mock
    def test_create_multiple_relations(self, client: MemoClaw):
        """Test creating multiple relations."""
        respx.post(f"{BASE_URL}/v1/memories/m1/relations").mock(
            side_effect=[
                httpx.Response(
                    201,
                    json={
                        "id": f"rel{i}",
                        "source_id": "m1",
                        "target_id": f"m{i}",
                        "relation_type": "related_to",
                        "metadata": {},
                        "created_at": "2025-01-01T00:00:00Z",
                    },
                )
                for i in range(2, 5)
            ]
        )
        
        result = (RelationBuilder(client, "m1")
            .relate_to("m2", "related_to")
            .relate_to("m3", "supports")
            .relate_to("m4", "contradicts")
            .create_all())
        
        assert len(result) == 3


class TestBatchStore:
    """Tests for BatchStore."""

    @respx.mock
    def test_add_single_memory(self, client: MemoClaw):
        """Test adding a single memory to batch."""
        respx.post(f"{BASE_URL}/v1/store/batch").mock(
            return_value=httpx.Response(
                201,
                json={
                    "ids": ["mem-1"],
                    "stored": True,
                    "count": 1,
                    "deduplicated_count": 0,
                    "tokens_used": 10,
                },
            )
        )
        
        store = BatchStore(client)
        store.add("Test memory", importance=0.5)
        
        assert store.count() == 1
        result = store.execute()
        
        assert result["count"] == 1
        assert "mem-1" in result["ids"]

    @respx.mock
    def test_add_many_memories(self, client: MemoClaw):
        """Test adding many memories."""
        respx.post(f"{BASE_URL}/v1/store/batch").mock(
            return_value=httpx.Response(
                201,
                json={
                    "ids": ["mem-1", "mem-2"],
                    "stored": True,
                    "count": 2,
                    "deduplicated_count": 0,
                    "tokens_used": 20,
                },
            )
        )
        
        store = BatchStore(client)
        store.add_many([
            {"content": "Memory 1"},
            {"content": "Memory 2"},
        ])
        
        assert store.count() == 2
        result = store.execute()
        
        assert result["count"] == 2

    @respx.mock
    def test_auto_chunking_large_batch(self, client: MemoClaw):
        """Test automatic chunking for large batches."""
        # Create 150 memories - should be split into 2 batches
        memories = [{"content": f"Memory {i}"} for i in range(150)]
        
        respx.post(f"{BASE_URL}/v1/store/batch").mock(
            side_effect=[
                httpx.Response(
                    201,
                    json={
                        "ids": [f"mem-{i}" for i in range(100)],
                        "stored": True,
                        "count": 100,
                        "deduplicated_count": 0,
                        "tokens_used": 1000,
                    },
                ),
                httpx.Response(
                    201,
                    json={
                        "ids": [f"mem-{i}" for i in range(100, 150)],
                        "stored": True,
                        "count": 50,
                        "deduplicated_count": 0,
                        "tokens_used": 500,
                    },
                ),
            ]
        )
        
        store = BatchStore(client)
        store.add_many(memories)
        
        result = store.execute()
        
        assert result["count"] == 150
        assert result["tokens_used"] == 1500

    def test_empty_batch(self, client: MemoClaw):
        """Test executing empty batch."""
        store = BatchStore(client)
        result = store.execute()
        
        assert result["count"] == 0
        assert result["ids"] == []

    def test_tags_nested_under_metadata(self, client: MemoClaw):
        """Test that tags are correctly nested under metadata, not top-level."""
        store = BatchStore(client)
        store.add("Test memory", tags=["important", "test"])

        assert store.count() == 1
        memory = store._memories[0]
        # Tags must be under metadata.tags, not at top level
        assert "tags" not in memory or memory.get("tags") is None or isinstance(memory.get("metadata", {}).get("tags"), list)
        assert memory["metadata"]["tags"] == ["important", "test"]
        assert "tags" not in {k for k in memory if k != "metadata"}

    def test_tags_merged_with_metadata(self, client: MemoClaw):
        """Test that tags and custom metadata are merged correctly."""
        store = BatchStore(client)
        store.add("Test memory", tags=["test"], metadata={"source": "unit-test"})

        memory = store._memories[0]
        assert memory["metadata"]["tags"] == ["test"]
        assert memory["metadata"]["source"] == "unit-test"


class TestStoreBuilder:
    """Tests for StoreBuilder."""

    @respx.mock
    def test_store_basic(self, client: MemoClaw):
        """Test basic store with builder."""
        respx.post(f"{BASE_URL}/v1/store").mock(
            return_value=httpx.Response(
                201,
                json={
                    "id": "mem-123",
                    "stored": True,
                    "deduplicated": False,
                    "tokens_used": 42,
                },
            )
        )
        
        result = (StoreBuilder(client)
            .content("User prefers dark mode")
            .importance(0.9)
            .tags(["preferences", "ui"])
            .namespace("user-prefs")
            .execute())
        
        assert result.id == "mem-123"
        assert result.stored is True

    @respx.mock
    def test_store_with_all_options(self, client: MemoClaw):
        """Test store with all options."""
        route = respx.post(f"{BASE_URL}/v1/store").mock(
            return_value=httpx.Response(
                201,
                json={
                    "id": "mem-456",
                    "stored": True,
                    "deduplicated": False,
                    "tokens_used": 30,
                },
            )
        )
        
        result = (StoreBuilder(client)
            .content("Test content")
            .importance(0.5)
            .add_tag("tag1")
            .add_tag("tag2")
            .namespace("project")
            .memory_type("preference")
            .session_id("sess1")
            .agent_id("agent1")
            .pinned(True)
            .metadata({"custom": "value"})
            .execute())
        
        assert result.id == "mem-456"
        # Verify body was sent correctly
        body = route.calls[0].request.content
        assert b"Test content" in body
        assert b"tag1" in body
        assert b"tag2" in body

    def test_store_without_content_raises(self, client: MemoClaw):
        """Test that executing without content raises ValueError."""
        with pytest.raises(ValueError, match="Content is required"):
            StoreBuilder(client).execute()

    def test_invalid_importance_raises(self, client: MemoClaw):
        """Test that invalid importance raises ValueError."""
        with pytest.raises(ValueError, match="importance must be between"):
            StoreBuilder(client).content("test").importance(1.5)


class TestRecallBuilderAfter:
    """Test that RecallBuilder supports the after() filter."""

    def test_after_included_in_params(self):
        params = (
            RecallBuilder()
            .query("test query")
            .after("2026-01-01T00:00:00Z")
            .build()
        )
        assert params["query"] == "test query"
        assert params["after"] == "2026-01-01T00:00:00Z"

    def test_after_combined_with_other_filters(self):
        params = (
            RecallBuilder()
            .query("test")
            .tags(["important"])
            .memory_type("preference")
            .after("2026-03-01T00:00:00Z")
            .build()
        )
        assert params["tags"] == ["important"]
        assert params["memory_type"] == "preference"
        assert params["after"] == "2026-03-01T00:00:00Z"

    def test_after_only_filter(self):
        params = (
            RecallBuilder()
            .query("test")
            .after("2026-01-01T00:00:00Z")
            .build()
        )
        assert params["after"] == "2026-01-01T00:00:00Z"

    def test_no_extra_keys_when_none_set(self):
        params = RecallBuilder().query("test").build()
        assert "tags" not in params
        assert "memory_type" not in params
        assert "after" not in params


class TestAsyncRelationBuilder:
    """Test AsyncRelationBuilder for use with AsyncMemoClaw."""

    @pytest.fixture
    def async_client(self):
        import httpx
        import respx
        from memoclaw import AsyncMemoClaw
        c = AsyncMemoClaw(private_key="0x4c0883a69102937d6231471b5dbb6204fe512961708279f15a8f7e20b4e3b1fb")
        return c

    @pytest.mark.asyncio
    async def test_create_all_relations(self, async_client):
        import respx
        from httpx import Response
        from memoclaw.builders import AsyncRelationBuilder

        with respx.mock:
            route = respx.post(url__regex=r".*v1/memories/.*/relations").mock(
                side_effect=[
                    Response(201, json={
                        "id": "rel-1",
                        "source_id": "mem-123",
                        "target_id": "mem-456",
                        "relation_type": "related_to",
                        "created_at": "2026-01-01T00:00:00Z",
                    }),
                    Response(201, json={
                        "id": "rel-2",
                        "source_id": "mem-123",
                        "target_id": "mem-789",
                        "relation_type": "supports",
                        "created_at": "2026-01-01T00:00:00Z",
                    }),
                ]
            )

            builder = AsyncRelationBuilder(async_client, "mem-123")
            results = await (
                builder
                .relate_to("mem-456", "related_to")
                .relate_to("mem-789", "supports")
                .create_all()
            )

            assert len(results) == 2
            assert results[0]["id"] == "rel-1"
            assert results[0]["target_id"] == "mem-456"
            assert results[0]["relation_type"] == "related_to"
            assert results[1]["id"] == "rel-2"
            assert results[1]["target_id"] == "mem-789"
            assert route.call_count == 2

    @pytest.mark.asyncio
    async def test_create_all_clears_pending(self, async_client):
        import respx
        from httpx import Response
        from memoclaw.builders import AsyncRelationBuilder

        with respx.mock:
            respx.post(url__regex=r".*v1/memories/.*/relations").mock(
                return_value=Response(201, json={
                    "id": "rel-1",
                    "source_id": "mem-123",
                    "target_id": "mem-456",
                    "relation_type": "related_to",
                    "created_at": "2026-01-01T00:00:00Z",
                })
            )

            builder = AsyncRelationBuilder(async_client, "mem-123")
            builder.relate_to("mem-456", "related_to")
            await builder.create_all()
            
            # Second call should return empty since relations were cleared
            results = await builder.create_all()
            assert results == []


class TestAsyncBatchStore:
    """Test AsyncBatchStore for use with AsyncMemoClaw."""

    @pytest.fixture
    def async_client(self):
        """Create an async client for testing."""
        from memoclaw import AsyncMemoClaw
        c = AsyncMemoClaw(private_key="0x4c0883a69102937d6231471b5dbb6204fe512961708279f15a8f7e20b4e3b1fb")
        return c

    async def test_add_and_execute(self, async_client):
        import respx
        from httpx import Response

        with respx.mock:
            respx.post(url__regex=r".*v1/store/batch").mock(
                return_value=Response(200, json={
                    "ids": ["mem-1", "mem-2"],
                    "stored": True,
                    "count": 2,
                    "deduplicated_count": 0,
                    "tokens_used": 10,
                })
            )

            store = AsyncBatchStore(async_client)
            result = await (store
                .add("Memory one", importance=0.8, tags=["test"])
                .add("Memory two", namespace="ns")
                .execute())

            assert result["stored"] is True
            assert result["count"] == 2
            assert result["ids"] == ["mem-1", "mem-2"]
            assert result["tokens_used"] == 10

    async def test_empty_batch_returns_no_op(self, async_client):
        store = AsyncBatchStore(async_client)
        result = await store.execute()
        assert result["stored"] is False
        assert result["count"] == 0
        assert result["ids"] == []

    async def test_count(self, async_client):
        store = AsyncBatchStore(async_client)
        assert store.count() == 0
        store.add("One")
        assert store.count() == 1
        store.add("Two").add("Three")
        assert store.count() == 3

    async def test_add_many(self, async_client):
        import respx
        from httpx import Response

        with respx.mock:
            respx.post(url__regex=r".*v1/store/batch").mock(
                return_value=Response(200, json={
                    "ids": ["mem-1", "mem-2", "mem-3"],
                    "stored": True,
                    "count": 3,
                    "deduplicated_count": 0,
                    "tokens_used": 15,
                })
            )

            store = AsyncBatchStore(async_client)
            memories = [
                {"content": "Memory A"},
                {"content": "Memory B"},
                {"content": "Memory C"},
            ]
            result = await store.add_many(memories).execute()
            assert result["count"] == 3

    async def test_execute_clears_batch(self, async_client):
        import respx
        from httpx import Response

        with respx.mock:
            respx.post(url__regex=r".*v1/store/batch").mock(
                return_value=Response(200, json={
                    "ids": ["mem-1"],
                    "stored": True,
                    "count": 1,
                    "deduplicated_count": 0,
                    "tokens_used": 5,
                })
            )

            store = AsyncBatchStore(async_client)
            store.add("Memory one")
            await store.execute()
            assert store.count() == 0

    async def test_chunking_large_batch(self, async_client):
        import respx
        from httpx import Response

        call_count = 0

        def mock_response(request):
            nonlocal call_count
            call_count += 1
            # Return 100 IDs for first chunk, 10 for second
            count = 100 if call_count == 1 else 10
            return Response(200, json={
                "ids": [f"mem-{i}" for i in range(count)],
                "stored": True,
                "count": count,
                "deduplicated_count": 0,
                "tokens_used": count,
            })

        with respx.mock:
            respx.post(url__regex=r".*v1/store/batch").mock(side_effect=mock_response)

            store = AsyncBatchStore(async_client)
            # Add 110 memories — should chunk into 100 + 10
            for i in range(110):
                store.add(f"Memory {i}")
            result = await store.execute()

            assert call_count == 2
            assert result["count"] == 110
            assert result["tokens_used"] == 110

    async def test_add_with_all_options(self, async_client):
        import respx
        from httpx import Response

        with respx.mock:
            route = respx.post(url__regex=r".*v1/store/batch").mock(
                return_value=Response(200, json={
                    "ids": ["mem-1"],
                    "stored": True,
                    "count": 1,
                    "deduplicated_count": 0,
                    "tokens_used": 5,
                })
            )

            store = AsyncBatchStore(async_client)
            await (store
                .add(
                    "Full options memory",
                    importance=0.9,
                    tags=["tag1", "tag2"],
                    namespace="test-ns",
                    memory_type="preference",
                    session_id="sess-1",
                    agent_id="agent-1",
                    metadata={"custom": "value"},
                )
                .execute())

            # Verify the request body
            import json
            body = json.loads(route.calls[0].request.content)
            mem = body["memories"][0]
            assert mem["content"] == "Full options memory"
            assert mem["importance"] == 0.9
            assert mem["namespace"] == "test-ns"
            assert mem["memory_type"] == "preference"
            assert mem["session_id"] == "sess-1"
            assert mem["agent_id"] == "agent-1"
            assert mem["metadata"]["tags"] == ["tag1", "tag2"]
            assert mem["metadata"]["custom"] == "value"
