"""Capcat — A command-line tool designed to solve content preservation challenges with Ethical Scraping."""

__version__ = "1.0.36"
__all__ = ["__version__"]
