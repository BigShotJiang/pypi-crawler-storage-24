"""Abbe MCP Server — AI workforce impact analysis tools for coding assistants."""

__version__ = "0.1.0"
