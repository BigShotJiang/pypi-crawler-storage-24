from yua._client import YUA
from yua._errors import (
    APIError,
    AuthenticationError,
    BadRequestError,
    RateLimitError,
)
from yua._streaming import Stream
from yua.types.chat import (
    ChatCompletion,
    ChatCompletionChunk,
    ChatCompletionChoice,
    ChatCompletionChunkChoice,
    ChatCompletionDelta,
    ChatCompletionMessage,
    ChatMessageInput,
    CompletionUsage,
    YuaExtension,
    YuaStreamEvent,
)

__all__ = [
    "YUA",
    "APIError",
    "AuthenticationError",
    "BadRequestError",
    "RateLimitError",
    "Stream",
    "ChatCompletion",
    "ChatCompletionChunk",
    "ChatCompletionChoice",
    "ChatCompletionChunkChoice",
    "ChatCompletionDelta",
    "ChatCompletionMessage",
    "ChatMessageInput",
    "CompletionUsage",
    "YuaExtension",
    "YuaStreamEvent",
]

__version__ = "0.2.0"
