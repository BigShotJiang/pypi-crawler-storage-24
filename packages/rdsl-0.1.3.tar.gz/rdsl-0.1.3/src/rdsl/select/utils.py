import numpy as np
import pandas as pd
from rdkit import Chem
from rdkit.Chem import rdchem, rdPartialCharges

from rdsl.select.consts import (
    _ARTIFACT_RESIDUES,
    _BACKBONE_ATOMS,
    _INORGANIC_RESIDUES,
    _NUCLEIC_ACID_RESIDUES,
    _PROTEIN_RESIDUES,
    _WATER_RESIDUES,
    SIDECHAIN_ATOMS,
)


def _is_protein(residue_info) -> bool:
    """Return True if this atom is a protein atom based on PDB residue info."""
    if residue_info is None:
        return False
    resn = residue_info.GetResidueName().strip()
    return resn in SIDECHAIN_ATOMS


def _is_nucleic_acid(residue_info) -> bool:
    """Return True if this atom is a nucleic acid atom based on PDB residue info."""
    if residue_info is None:
        return False
    resn = residue_info.GetResidueName().strip()
    return resn in _NUCLEIC_ACID_RESIDUES


def _is_polymer(residue_info) -> bool:
    """Return True if this atom is a polymer atom based on PDB residue info."""
    if residue_info is None:
        return False
    resn = residue_info.GetResidueName().strip()
    return resn in _NUCLEIC_ACID_RESIDUES or resn in SIDECHAIN_ATOMS


def _is_water(residue_info) -> bool:
    """Return True if this atom is a water atom based on PDB residue info."""
    if residue_info is None:
        return False
    return residue_info.GetResidueName().strip() in _WATER_RESIDUES


def _is_sidechain(residue_info) -> bool:
    """Return True if this atom is a sidechain atom based on PDB residue info."""
    if residue_info is None:
        return False

    resn = residue_info.GetResidueName().strip()
    name = residue_info.GetName().strip()

    # Must be a known amino acid
    if resn not in SIDECHAIN_ATOMS:
        return False

    return name in SIDECHAIN_ATOMS[resn]


def _is_artifact(residue_info) -> bool:
    """Return True if this atom is an artifact atom based on PDB residue info."""
    if residue_info is None:
        return False
    resn = residue_info.GetResidueName().strip()
    return resn in _ARTIFACT_RESIDUES


def _is_backbone(residue_info) -> bool:
    """Return True if this atom is a backbone atom based on PDB residue info."""
    if residue_info is None:
        return False

    resn = residue_info.GetResidueName().strip()
    # Must be a known amino acid
    if resn not in SIDECHAIN_ATOMS:
        return False
    name = residue_info.GetName().strip()
    return name in _BACKBONE_ATOMS


def _get_inorganic_atoms(mol: Chem.Mol) -> np.ndarray:
    """Return boolean mask of atoms belonging to inorganic fragments or residues."""
    frags = Chem.GetMolFrags(mol, asMols=False)
    mask = np.zeros(mol.GetNumAtoms(), dtype=bool)

    for frag_atoms in frags:
        resnames = set()
        has_carbon = False
        for i in frag_atoms:
            atom = mol.GetAtomWithIdx(int(i))
            if atom.GetAtomicNum() == 6:
                has_carbon = True
            info = atom.GetPDBResidueInfo()
            if info is not None:
                resnames.add(info.GetResidueName().strip())

        # If it's a mixed fragment (inorganic residues + carbon/protein/etc.),
        # only mark the specific inorganic residues.
        if (resnames & _INORGANIC_RESIDUES) and (has_carbon or (resnames - _INORGANIC_RESIDUES - _WATER_RESIDUES)):
            for i in frag_atoms:
                atom = mol.GetAtomWithIdx(int(i))
                info = atom.GetPDBResidueInfo()
                if info and info.GetResidueName().strip() in _INORGANIC_RESIDUES:
                    mask[int(i)] = True
            continue

        # For purely inorganic fragments (known inorganic residue OR no carbon at all)
        if resnames & _INORGANIC_RESIDUES:
            mask[list(frag_atoms)] = True
            continue

        if not has_carbon and not (resnames & _WATER_RESIDUES):
            mask[list(frag_atoms)] = True

    return mask


def _get_organic_atoms(mol: Chem.Mol, inorganic_mask: np.ndarray) -> np.ndarray:
    """Return boolean mask of atoms belonging to organic fragments or residues."""
    frags = Chem.GetMolFrags(mol, asMols=False)
    mask = np.zeros(mol.GetNumAtoms(), dtype=bool)

    for frag_atoms in frags:
        resnames = set()
        has_carbon = False
        for i in frag_atoms:
            atom = mol.GetAtomWithIdx(int(i))
            if atom.GetAtomicNum() == 6:
                has_carbon = True
            info = atom.GetPDBResidueInfo()
            if info is not None:
                resnames.add(info.GetResidueName().strip())

        if not has_carbon:
            continue

        # If it's a mixed fragment (bonded to protein/nucleic/inorganic),
        # only mark atoms that don't belong to those other categories.
        other_categories = _PROTEIN_RESIDUES | _NUCLEIC_ACID_RESIDUES | _WATER_RESIDUES | _ARTIFACT_RESIDUES
        if resnames & other_categories:
            for i in frag_atoms:
                if inorganic_mask[int(i)]:
                    continue
                atom = mol.GetAtomWithIdx(int(i))
                info = atom.GetPDBResidueInfo()
                if info:
                    resn = info.GetResidueName().strip()
                    if resn in other_categories:
                        continue
                mask[int(i)] = True
            continue

        # Purely organic fragment (no protein/nucleic etc.)
        # Still respect the inorganic_mask for specific atoms (e.g. metals in ligands)
        for i in frag_atoms:
            if not inorganic_mask[int(i)]:
                mask[int(i)] = True

    return mask


# All column names that _create_context can populate (used for lazy context creation).
CONTEXT_COLUMNS = frozenset({
    "index",
    "elem",
    "atomic_number",
    "mass",
    "atom_map_number",
    "valence",
    "explicit_valence",
    "implicit_valence",
    "isotope",
    "aromatic",
    "aliphatic",
    "cyclic",
    "acyclic",
    "hetatm",
    "hydrogens",
    "heavy",
    "ring",
    "degree",
    "formal_charge",
    "partial_charge",
    "radical_electrons",
    "hybridization",
    "stereo",
    "chain",
    "residue",
    "resi",
    "resn",
    "resv",
    "name",
    "alt",
    "b",
    "q",
    "id",
    "sidechain",
    "backbone",
    "solvent",
    "polymer",
    "protein",
    "nucleic",
    "inorganic",
    "organic",
    "metals",
    "artefact",
})


def _is_metal(atom: rdchem.Atom) -> bool:
    return atom.GetSymbol() in {
        "Li",
        "Na",
        "K",
        "Rb",
        "Cs",
        "Be",
        "Mg",
        "Ca",
        "Sr",
        "Ba",
        "Sc",
        "Ti",
        "V",
        "Cr",
        "Mn",
        "Fe",
        "Co",
        "Ni",
        "Cu",
        "Zn",
        "Y",
        "Zr",
        "Nb",
        "Mo",
        "Ru",
        "Rh",
        "Pd",
        "Ag",
        "Cd",
        "Hf",
        "Ta",
        "W",
        "Re",
        "Os",
        "Ir",
        "Pt",
        "Au",
        "Hg",
        "Al",
        "Ga",
        "In",
        "Sn",
        "Pb",
        "Bi",
        "La",
        "Ce",
        "Pr",
        "Nd",
        "Sm",
        "Eu",
        "Gd",
        "Tb",
        "Dy",
        "Ho",
        "Er",
        "Tm",
        "Yb",
        "Lu",
    }


def _atom_getters():
    """Build getter map for context columns. Used by _create_context."""
    return {
        "index": lambda a, ri, idx, pc: a.GetIdx(),
        "elem": lambda a, ri, idx, pc: a.GetSymbol(),
        "atomic_number": lambda a, ri, idx, pc: a.GetAtomicNum(),
        "mass": lambda a, ri, idx, pc: a.GetMass(),
        "atom_map_number": lambda a, ri, idx, pc: a.GetAtomMapNum(),
        "valence": lambda a, ri, idx, pc: a.GetTotalValence(),
        "explicit_valence": lambda a, ri, idx, pc: a.GetValence(Chem.ValenceType.EXPLICIT),
        "implicit_valence": lambda a, ri, idx, pc: a.GetValence(Chem.ValenceType.IMPLICIT),
        "isotope": lambda a, ri, idx, pc: a.GetIsotope(),
        "aromatic": lambda a, ri, idx, pc: a.GetIsAromatic(),
        "aliphatic": lambda a, ri, idx, pc: not a.GetIsAromatic(),
        "cyclic": lambda a, ri, idx, pc: a.IsInRing(),
        "acyclic": lambda a, ri, idx, pc: not a.IsInRing(),
        "hetatm": lambda a, ri, idx, pc: ri.GetIsHeteroAtom() if ri else None,
        "hydrogens": lambda a, ri, idx, pc: a.GetSymbol() == "H",
        "heavy": lambda a, ri, idx, pc: a.GetSymbol() != "H",
        "ring": lambda a, ri, idx, pc: a.IsInRing(),
        "degree": lambda a, ri, idx, pc: a.GetDegree(),
        "formal_charge": lambda a, ri, idx, pc: a.GetFormalCharge(),
        "partial_charge": lambda a, ri, idx, pc: (
            a.GetDoubleProp("_GasteigerCharge") if a.HasProp("_GasteigerCharge") else None
        ),
        "radical_electrons": lambda a, ri, idx, pc: a.GetNumRadicalElectrons(),
        "hybridization": lambda a, ri, idx, pc: str(a.GetHybridization()),
        "stereo": lambda a, ri, idx, pc: a.GetProp("_CIPCode") if a.HasProp("_CIPCode") else "",
        "chain": lambda a, ri, idx, pc: ri.GetChainId() if ri else None,
        "residue": lambda a, ri, idx, pc: (
            f"{ri.GetChainId()}:{ri.GetResidueNumber()}{ri.GetInsertionCode().strip()}" if ri else None
        ),
        "resi": lambda a, ri, idx, pc: f"{ri.GetResidueNumber()}{ri.GetInsertionCode().strip()}" if ri else None,
        "resn": lambda a, ri, idx, pc: ri.GetResidueName().strip() if ri else None,
        "resv": lambda a, ri, idx, pc: ri.GetResidueNumber() if ri else None,
        "name": lambda a, ri, idx, pc: ri.GetName().strip() if ri else None,
        "alt": lambda a, ri, idx, pc: ri.GetAltLoc() if ri else None,
        "b": lambda a, ri, idx, pc: ri.GetTempFactor() if ri else None,
        "q": lambda a, ri, idx, pc: ri.GetOccupancy() if ri else None,
        "id": lambda a, ri, idx, pc: ri.GetSerialNumber() if ri else None,
        "sidechain": lambda a, ri, idx, pc: _is_sidechain(ri),
        "backbone": lambda a, ri, idx, pc: _is_backbone(ri),
        "solvent": lambda a, ri, idx, pc: _is_water(ri),
        "polymer": lambda a, ri, idx, pc: _is_polymer(ri),
        "protein": lambda a, ri, idx, pc: _is_protein(ri),
        "nucleic": lambda a, ri, idx, pc: _is_nucleic_acid(ri),
        "inorganic": lambda a, ri, idx, pc: bool(pc["inorganic_mask"][idx]),
        "organic": lambda a, ri, idx, pc: bool(pc["organic_mask"][idx]),
        "metals": lambda a, ri, idx, pc: _is_metal(a),
        "artefact": lambda a, ri, idx, pc: _is_artifact(ri),
    }


_ATOM_GETTERS = _atom_getters()


def _create_context(mol: Chem.Mol, columns: set[str] | None = None) -> pd.DataFrame:
    """Create a DataFrame with atom properties for selection.

    If columns is provided, only those properties are computed (faster for large molecules
    when the query only uses a subset of attributes). If columns is None, all properties
    are computed.
    """
    want = CONTEXT_COLUMNS if columns is None else (columns & CONTEXT_COLUMNS)
    if not want:
        return pd.DataFrame(index=range(mol.GetNumAtoms()))

    precomputed: dict = {}
    if "inorganic" in want or "organic" in want:
        precomputed["inorganic_mask"] = _get_inorganic_atoms(mol)
        precomputed["organic_mask"] = _get_organic_atoms(mol, precomputed["inorganic_mask"])
    if "partial_charge" in want and not mol.GetAtomWithIdx(0).HasProp("_GasteigerCharge"):
        rdPartialCharges.ComputeGasteigerCharges(mol)
    if "stereo" in want:
        Chem.AssignStereochemistry(mol, force=True, cleanIt=True)

    getters = _ATOM_GETTERS
    data = []
    for idx, atom in enumerate(mol.GetAtoms()):
        residue_info = atom.GetPDBResidueInfo()
        row = {}
        for col in want:
            row[col] = getters[col](atom, residue_info, idx, precomputed)
        data.append(row)

    return pd.DataFrame(data)
