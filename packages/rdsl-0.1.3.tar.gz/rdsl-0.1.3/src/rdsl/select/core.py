import argparse
import sys
from pathlib import Path
from typing import Literal, NamedTuple

import numpy as np
from loguru import logger
from rdkit import Chem

from rdsl.select.base import BrokenBondError
from rdsl.select.parser import _parse_expr
from rdsl.select.utils import _create_context


class SelectionResult(NamedTuple):
    """Result of a molecule selection.

    Attributes:
        mol: The extracted subset molecule, or None if no atoms were selected.
        atom_mapping: Mapping from new atom indices to original atom indices.
        bond_mapping: Mapping from new bond indices to original bond indices.
    """

    mol: Chem.Mol | None
    atom_mapping: dict[int, int]
    bond_mapping: dict[int, int]


def select_atom_ids(mol: Chem.Mol, expr: str) -> np.ndarray:
    """Select atoms from an RDKit molecule.

    Args:
        mol: RDKit molecule
        expr: Selection expression

    Returns:
        Array of selected atom indices (0-based)

    Examples:
        >>> select_atom_ids(mol, "aromatic")  # All aromatic atoms
        >>> select_atom_ids(mol, "elem C and ring")  # Carbon atoms in rings
        >>> select_atom_ids(mol, 'smarts "c1ccccc1"')  # Benzene rings
        >>> select_atom_ids(mol, "ringsize 6")  # Atoms in 6-membered rings
        >>> select_atom_ids(mol, "elem C within 3.0 of elem N")  # Carbons within 3.0 Angstroms of nitrogen
        >>> select_atom_ids(mol, "first elem C")  # First carbon by index
        >>> select_atom_ids(mol, "nth 1 aromatic")  # First aromatic atom
        >>> select_atom_ids(mol, "last ring")  # Last atom in ring
    """
    parsed = _parse_expr(expr)
    root = parsed[0]
    ctx = _create_context(mol, root.required_columns())
    selected = root.apply(mol, ctx)
    atom_ids = np.where(selected)[0]

    # Store selected atoms on molecule for jupyter visualisation
    mol.__sssAtoms = [int(i) for i in atom_ids]
    mol.__sssQry = None

    return atom_ids


def select_atoms(mol: Chem.Mol, expr: str) -> list[Chem.Atom]:
    """Select atoms from an RDKit molecule and return them as Atom objects.

    Args:
        mol: RDKit molecule
        expr: Selection expression

    Returns:
        List of selected atom objects

    Examples:
        >>> select_atoms(mol, "aromatic")  # All aromatic atoms
        >>> select_atoms(mol, "elem C and ring")  # Carbon atoms in rings
        >>> select_atoms(mol, 'smarts "c1ccccc1"')  # Custom SMARTS pattern
        >>> select_atoms(mol, "ringsize 6")  # Atoms in 6-membered rings
        >>> select_atoms(mol, "elem C within 3.0 of elem N")  # Carbons within 3.0 Angstroms of nitrogen
        >>> select_atoms(mol, "first elem C")  # First carbon by index
        >>> select_atoms(mol, "last ring")  # Last atom in ring
    """
    atom_ids = select_atom_ids(mol, expr)
    return [mol.GetAtomWithIdx(int(i)) for i in atom_ids]


def select_molecule(
    mol: Chem.Mol,
    expr: str,
    broken_bonds: Literal["radicals", "hydrogens", "wildcards"] = "hydrogens",
) -> SelectionResult:
    """Extract a subset of a molecule based on a selection expression.

    Args:
        mol: RDKit molecule
        expr: Selection expression
        broken_bonds: How to handle bonds broken between atoms in the subset and atoms outside.
            * `hydrogens`: Insert implicit hydrogens when bonds are broken, to maintain valence (default).
            * `radicals`: Break the bond and leave the atoms with an unsatisfied valence.
            * `wildcards`: Replace broken bonds with wildcard atoms (*).

    Returns:
        A SelectionResult object containing the subset molecule and mappings.

    Examples:
        >>> result = select_molecule(mol, "aromatic")
        >>> submol = result.mol
        >>> original_idx = result.atom_mapping[0]
    """
    selected_indices = select_atom_ids(mol, expr)

    if len(selected_indices) == 0:
        return SelectionResult(None, {}, {})

    # Get atoms to delete (everything NOT selected)
    all_indices = set(range(mol.GetNumAtoms()))
    to_delete = sorted(all_indices - set(selected_indices), reverse=True)

    # Copy molecule and handle broken bonds
    new_mol = Chem.RWMol(mol)

    # Store original indices in atom/bond properties for mapping later
    for atom in new_mol.GetAtoms():
        atom.SetIntProp("_original_idx", atom.GetIdx())
    for bond in new_mol.GetBonds():
        bond.SetIntProp("_original_idx", bond.GetIdx())

    if broken_bonds == "radicals":
        for atom in new_mol.GetAtoms():
            atom.SetNumExplicitHs(atom.GetTotalNumHs())
            atom.SetNoImplicit(True)

    elif broken_bonds == "wildcards":
        # Find which bonds connect a selected atom to a non-selected one
        selected_set = set(selected_indices)
        has_coords = mol.GetNumConformers() > 0

        for bond in mol.GetBonds():
            idx1 = bond.GetBeginAtomIdx()
            idx2 = bond.GetEndAtomIdx()

            kept_idx = None
            removed_idx = None
            if idx1 in selected_set and idx2 not in selected_set:
                kept_idx = idx1
                removed_idx = idx2
            elif idx2 in selected_set and idx1 not in selected_set:
                kept_idx = idx2
                removed_idx = idx1

            if kept_idx is not None:
                # Add wildcard atom and connect with the same bond type
                wildcard_idx = new_mol.AddAtom(Chem.Atom(0))  # Atomic number 0 is '*'
                new_mol.AddBond(kept_idx, wildcard_idx, bond.GetBondType())

                # Set 3D position if conformers exist
                if has_coords:
                    if removed_idx is None:
                        raise BrokenBondError(bond.GetIdx())
                    for i in range(mol.GetNumConformers()):
                        pos = mol.GetConformer(i).GetAtomPosition(removed_idx)
                        new_mol.GetConformer(i).SetAtomPosition(wildcard_idx, pos)

    # Delete atoms in reverse order to keep indices valid
    for idx in to_delete:
        new_mol.RemoveAtom(int(idx))

    subset_mol = new_mol.GetMol()

    # Collect mapping and clear properties
    atom_mapping = {}
    bond_mapping = {}

    for atom in subset_mol.GetAtoms():
        if atom.HasProp("_original_idx"):
            atom_mapping[atom.GetIdx()] = atom.GetIntProp("_original_idx")
            atom.ClearProp("_original_idx")
    for bond in subset_mol.GetBonds():
        if bond.HasProp("_original_idx"):
            bond_mapping[bond.GetIdx()] = bond.GetIntProp("_original_idx")
            bond.ClearProp("_original_idx")

    # Sanitization
    sani_fail = Chem.SanitizeMol(subset_mol, catchErrors=True)
    if sani_fail:
        # Some subsets might not be sanitizable (e.g. radicals if broken_bonds="radicals")
        logger.debug("Sanitization produced warnings for subset molecule")

    return SelectionResult(subset_mol, atom_mapping, bond_mapping)


def main():
    parser = argparse.ArgumentParser(description="Select a subset of atoms from a molecule and save the result.")
    parser.add_argument("input_file", help="Input molecule file (PDB or SDF)")
    parser.add_argument("output_file", help="Output file to save the subset molecule")
    parser.add_argument("query", help="Selection expression")
    parser.add_argument(
        "--broken-bonds",
        choices=["radicals", "hydrogens", "wildcards"],
        default="hydrogens",
        help="How to handle broken bonds (default: hydrogens)",
    )
    args = parser.parse_args()

    input_path = Path(args.input_file)
    output_path = Path(args.output_file)

    if not input_path.exists():
        logger.error(f"Input file not found: {input_path}")
        sys.exit(1)

    ext = input_path.suffix.lower()

    # Load molecule without removing hydrogens
    if ext == ".pdb":
        mol = Chem.MolFromPDBFile(str(input_path), removeHs=False, sanitize=False)
    elif ext in [".sdf", ".sd", ".mol"]:
        supplier = Chem.SDMolSupplier(str(input_path), removeHs=False, sanitize=True)
        mol = None
        for m in supplier:
            if m is not None:
                mol = m
                break
    else:
        logger.error(f"Unsupported input file extension: {ext}. Only .pdb and .sdf/.sd/.mol are supported.")
        sys.exit(1)

    if mol is None:
        logger.error(f"Failed to load molecule from {input_path}")
        sys.exit(1)

    logger.info(f"Applying query: '{args.query}' to {mol.GetNumAtoms()} atoms")
    try:
        result = select_molecule(mol, args.query, broken_bonds=args.broken_bonds)
    except Exception as e:
        logger.error(f"Selection failed: {e}")
        sys.exit(1)

    if result.mol is None:
        logger.error("No atoms selected.")
        sys.exit(1)

    logger.info(f"Selected {result.mol.GetNumAtoms()} atoms. Saving to {output_path}")

    out_ext = output_path.suffix.lower()
    if out_ext == ".pdb":
        try:
            Chem.MolToPDBFile(result.mol, str(output_path))
        except Exception as e:
            logger.error(f"Failed to write PDB file: {e}")
            sys.exit(1)
    elif out_ext in [".sdf", ".sd", ".mol"]:
        try:
            writer = Chem.SDWriter(str(output_path))
            writer.write(result.mol)
            writer.close()
        except Exception as e:
            logger.error(f"Failed to write SDF file: {e}")
            sys.exit(1)
    else:
        logger.error(f"Unsupported output file extension: {out_ext}. Only .pdb and .sdf/.sd/.mol are supported.")
        sys.exit(1)


if __name__ == "__main__":
    main()
