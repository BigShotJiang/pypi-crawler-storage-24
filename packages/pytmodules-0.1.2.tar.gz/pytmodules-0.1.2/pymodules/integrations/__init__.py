"""Framework integrations for pymodules."""
