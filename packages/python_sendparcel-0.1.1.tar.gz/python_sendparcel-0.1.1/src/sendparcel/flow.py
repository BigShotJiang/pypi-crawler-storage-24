"""Shipment flow orchestrator."""

from __future__ import annotations

from typing import Any

import httpx

from sendparcel.enums import ShipmentStatus
from sendparcel.exceptions import (
    CommunicationError,
    ProviderCapabilityError,
    SendParcelException,
)
from sendparcel.fsm import transition_shipment
from sendparcel.protocols import Shipment, ShipmentRepository
from sendparcel.provider import (
    BaseProvider,
    CancellableProvider,
    LabelProvider,
    PullStatusProvider,
    PushCallbackProvider,
)
from sendparcel.types import (
    AddressInfo,
    CreateLabelOutcome,
    CreateShipmentOutcome,
    ParcelInfo,
    ShipmentUpdateOutcome,
    ShipmentUpdateResult,
)
from sendparcel.validators import run_validators


class ShipmentFlow:
    """Framework-agnostic shipment orchestration."""

    def __init__(
        self,
        repository: ShipmentRepository,
        config: dict[str, Any] | None = None,
        validators: list[Any] | None = None,
        registry: Any = None,
    ) -> None:
        self.repository = repository
        self.config = config or {}
        self.validators = validators or []
        from sendparcel.registry import registry as default_registry

        self.registry = registry or default_registry

    async def create_shipment(
        self,
        provider_slug: str,
        *,
        sender_address: AddressInfo,
        receiver_address: AddressInfo,
        parcels: list[ParcelInfo],
        **kwargs: Any,
    ) -> CreateShipmentOutcome:
        """Create a shipment record with explicit address and parcel data."""

        self.registry.get_by_slug(provider_slug)
        shipment = await self.repository.create(
            provider=provider_slug,
            status=ShipmentStatus.NEW.value,
            **kwargs,
        )
        provider = self._get_provider(shipment)
        result = await self._call_provider(
            provider.create_shipment(
                sender_address=sender_address,
                receiver_address=receiver_address,
                parcels=parcels,
                **kwargs,
            )
        )
        shipment.external_id = str(result.get("external_id", ""))
        shipment.tracking_number = str(result.get("tracking_number", ""))
        transition_shipment(shipment, ShipmentStatus.CREATED)
        label = result.get("label")
        if label is not None:
            transition_shipment(shipment, ShipmentStatus.LABEL_READY)
        saved = await self.repository.save(shipment)
        return CreateShipmentOutcome(shipment=saved, label=label)

    async def create_label(
        self, shipment: Shipment, **kwargs: Any
    ) -> CreateLabelOutcome:
        """Create provider label and persist shipment metadata."""

        run_validators({"shipment": shipment}, validators=self.validators)
        provider = self._get_provider(shipment)
        if not isinstance(provider, LabelProvider):
            raise ProviderCapabilityError(
                f"Provider {shipment.provider!r} does not support "
                "label creation"
            )
        label = await self._call_provider(provider.create_label(**kwargs))
        transition_shipment(shipment, ShipmentStatus.LABEL_READY)
        saved = await self.repository.save(shipment)
        return CreateLabelOutcome(shipment=saved, label=label)

    async def handle_callback(
        self,
        shipment: Shipment,
        data: dict[str, Any],
        headers: dict[str, Any],
        **kwargs: Any,
    ) -> ShipmentUpdateOutcome:
        """Verify and apply provider callback."""

        provider = self._get_provider(shipment)
        if not isinstance(provider, PushCallbackProvider):
            raise ProviderCapabilityError(
                f"Provider {shipment.provider!r} does not support "
                "push callbacks"
            )
        await self._call_provider(
            provider.verify_callback(data, headers, **kwargs)
        )
        update = await self._call_provider(
            provider.handle_callback(data, headers, **kwargs)
        )
        normalized_update = update or ShipmentUpdateResult()
        saved = await self._apply_update(shipment, normalized_update)
        return ShipmentUpdateOutcome(shipment=saved, update=normalized_update)

    async def fetch_and_update_status(
        self, shipment: Shipment
    ) -> ShipmentUpdateOutcome:
        """Fetch status from provider and persist."""

        provider = self._get_provider(shipment)
        if not isinstance(provider, PullStatusProvider):
            raise ProviderCapabilityError(
                f"Provider {shipment.provider!r} does not support "
                "status polling"
            )
        update = await self._call_provider(provider.fetch_shipment_status())
        normalized_update = update or ShipmentUpdateResult()
        saved = await self._apply_update(shipment, normalized_update)
        return ShipmentUpdateOutcome(shipment=saved, update=normalized_update)

    async def cancel_shipment(self, shipment: Shipment, **kwargs: Any) -> bool:
        """Cancel shipment via provider and persist state."""

        provider = self._get_provider(shipment)
        if not isinstance(provider, CancellableProvider):
            raise ProviderCapabilityError(
                f"Provider {shipment.provider!r} does not support cancellation"
            )
        cancelled = await self._call_provider(
            provider.cancel_shipment(**kwargs)
        )
        if cancelled:
            transition_shipment(shipment, ShipmentStatus.CANCELLED)
            await self.repository.save(shipment)
        return bool(cancelled)

    def _get_provider(self, shipment: Shipment) -> BaseProvider:
        provider_class = self.registry.get_by_slug(shipment.provider)
        provider_config = self.config.get(shipment.provider, {})
        return provider_class(shipment, config=provider_config)

    async def _apply_update(
        self, shipment: Shipment, update: ShipmentUpdateResult
    ) -> Shipment:
        tracking_number = update.get("tracking_number")
        if tracking_number:
            shipment.tracking_number = str(tracking_number)
        status = update.get("status")
        if status is not None:
            transition_shipment(shipment, status)
        return await self.repository.save(shipment)

    async def _call_provider(self, coro: Any) -> Any:
        """Call a provider coroutine, wrapping non-domain errors."""

        try:
            return await coro
        except SendParcelException:
            raise
        except httpx.HTTPError as exc:
            raise CommunicationError(
                str(exc),
                context={"original_error": type(exc).__name__},
            ) from exc
        except Exception as exc:
            raise CommunicationError(
                str(exc),
                context={"original_error": type(exc).__name__},
            ) from exc
