# mcpzoo-numbase

> 进制转换 — 二进制八进制十进制十六进制互转

## Installation

```bash
uvx mcpzoo-numbase
```

## uvx JSON

```json
{
  "mcpServers": {
    "numbase": {
      "args": ["mcpzoo-numbase"],
      "command": "uvx"
    }
  }
}
```
