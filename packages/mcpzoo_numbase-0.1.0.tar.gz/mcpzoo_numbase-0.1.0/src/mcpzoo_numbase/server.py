from mcp.server.fastmcp import FastMCP

mcp = FastMCP("numbase")

@mcp.tool()
def convert_base(number: str, from_base: int = 10, to_base: int = 16) -> str:
    """在不同进制（2-36）间转换数字。"""
    if not (2 <= from_base <= 36) or not (2 <= to_base <= 36):
        return "进制支持范围是 2 到 36 之间"
        
    # 先转为 10 进制
    try:
        val10 = int(number.strip(), from_base)
    except ValueError:
        return f"无法将 {number} 作为 {from_base} 进制解析"
        
    if to_base == 10:
        return str(val10)
        
    if val10 == 0:
        return "0"
        
    # 10 进制转为目标进制
    chars = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ"
    res = ""
    n = abs(val10)
    while n > 0:
        n, m = divmod(n, to_base)
        res = chars[m] + res
        
    if val10 < 0:
        res = "-" + res
        
    return res

def main():
    mcp.run()

if __name__ == "__main__":
    main()
