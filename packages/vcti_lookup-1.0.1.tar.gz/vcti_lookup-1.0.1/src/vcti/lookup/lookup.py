# Copyright Visual Collaboration Technologies Inc. All Rights Reserved.
# See LICENSE for details.
"""Lookup — attribute-based filtering for any sequence of items.

``Lookup`` operates on any :class:`~collections.abc.Sequence` whose
items have an ID and attributes.  By default, attribute values are
read via ``item[key]`` (works with dicts, numpy rows, pandas rows,
and any object implementing ``__getitem__``), with a ``getattr``
fallback for plain objects and dataclasses.

An optional *getter* function can be passed for edge cases (nested
access, value transforms, ``.attributes`` dicts).

The input sequence is stored **as-is** — no copying.  This means a
``list[dict]``, a numpy structured array, or any other ``Sequence``
can be used directly without conversion overhead.
"""

from collections.abc import Iterator, Sequence
from typing import Any, overload

from .getter import MISSING, ValueGetter
from .rule import Rule


def _default_get_value(item: Any, key: str) -> Any:
    """Fast default: ``item[key]`` with ``getattr`` fallback.

    Covers dicts, numpy structured-array rows, pandas rows, and any
    object supporting ``__getitem__``.  Falls back to ``getattr`` for
    plain objects and dataclasses.  Returns :data:`MISSING` if the
    attribute is not found by either method.
    """
    try:
        return item[key]
    except (KeyError, IndexError, ValueError):
        # KeyError: dict missing key / numpy missing field name
        # IndexError: sequence out of range
        # ValueError: numpy field not in dtype
        return MISSING
    except TypeError:
        # item doesn't support __getitem__ (e.g. dataclass, plain object)
        val = getattr(item, key, MISSING)
        return val


class Lookup[T]:
    """Attribute-based filtering for any sequence of items.

    Items are kept in their original order and stored as-is (no copy).
    When an ID can be determined, items are also indexed for O(1)
    retrieval via :meth:`get`.

    Attribute values are read via ``item[key]`` by default, which works
    with dicts, numpy structured-array rows, and any ``__getitem__``
    object.  For plain objects and dataclasses, a ``getattr`` fallback
    is used automatically.  Pass a custom *getter* for edge cases.

    Args:
        items: Sequence of items to index.  Stored by reference — not
            copied.  Must support ``len()`` and iteration.
        id_key: Key or field name used as unique ID.
        id_attr: Object attribute name used as unique ID.
        getter: Optional function ``(item, key) -> value`` for
            custom attribute extraction.  When ``None`` (the default),
            the fast ``item[key]`` / ``getattr`` path is used.

    Raises:
        ValueError: If two items share the same ID.

    Examples:
        >>> from vcti.lookup import Lookup, Rule
        >>> items = [{"id": 1, "type": "pdf"}, {"id": 2, "type": "txt"}]
        >>> lk = Lookup(items)
        >>> lk.filter([Rule("type", "==", "pdf")])
        [{'id': 1, 'type': 'pdf'}]
    """

    def __init__(
        self,
        items: Sequence[T],
        *,
        id_key: str | None = None,
        id_attr: str | None = None,
        getter: ValueGetter | None = None,
    ) -> None:
        self._items: Sequence[T] = items
        self._getter = getter
        self._id_key = id_key
        self._id_attr = id_attr
        self._index: dict[Any, T] = {}

        for item in self._items:
            item_id = self._get_id(item)
            if item_id is not None:
                if item_id in self._index:
                    raise ValueError(f"Duplicate ID: {item_id!r}")
                self._index[item_id] = item

    # ── Properties ─────────────────────────────────────────────

    @property
    def items(self) -> Sequence[T]:
        """The underlying item sequence (same reference, no copy)."""
        return self._items

    # ── Value access ─────────────────────────────────────────────

    def _get_value(self, item: T, key: str) -> Any:
        """Read an attribute value from *item*.

        Uses the custom getter if one was provided, otherwise the
        fast ``item[key]`` / ``getattr`` default path.
        """
        if self._getter is not None:
            return self._getter(item, key)
        return _default_get_value(item, key)

    # ── ID helpers ──────────────────────────────────────────────

    def _get_id(self, item: T) -> Any:
        """Resolve the ID of *item* using the configured strategy.

        Priority:
        1. ``id_key`` — reads via ``_get_value``
        2. ``id_attr`` — uses ``getattr``
        3. Auto-detect: ``.id`` attribute, then ``"id"`` dict key
        """
        if self._id_key:
            val = self._get_value(item, self._id_key)
            return None if val is MISSING else val
        if self._id_attr:
            return getattr(item, self._id_attr, None)
        # Auto-detect
        if hasattr(item, "id"):
            return item.id  # type: ignore[union-attr]
        if isinstance(item, dict):
            return item.get("id")
        return None

    # ── Internal iterators ─────────────────────────────────────

    def _iter_matches(self, rules: list[Rule]) -> Iterator[T]:
        """Yield items matching **all** *rules* (AND logic), lazily."""
        from vcti.predicate import evaluate

        for item in self._items:
            if all(self._matches(item, rule, evaluate) for rule in rules):
                yield item

    def _iter_matches_any(self, rules: list[Rule]) -> Iterator[T]:
        """Yield items matching **any** of *rules* (OR logic), lazily."""
        from vcti.predicate import evaluate

        for item in self._items:
            for rule in rules:
                if self._matches(item, rule, evaluate):
                    yield item
                    break

    def _matches(self, item: T, rule: Rule, evaluate_fn: Any) -> bool:
        """Test whether *item* satisfies *rule*.

        When ``rule.value`` is ``None`` the operator is assumed to be
        unary (e.g. ``is_empty``, ``exists``) and only the attribute
        value is passed to ``evaluate_fn``.
        """
        attr_value = self._get_value(item, rule.attribute)
        if attr_value is MISSING:
            return False
        if rule.value is None:
            return evaluate_fn(rule.operator, attr_value, **rule.modifiers)
        return evaluate_fn(rule.operator, attr_value, rule.value, **rule.modifiers)

    # ── Filtering ───────────────────────────────────────────────

    def filter(self, rules: list[Rule]) -> list[T]:
        """Return items matching **all** rules (AND logic).

        Args:
            rules: Filter conditions.  An empty list returns all items.

        Returns:
            Items that satisfy every rule, in original order.
        """
        if not rules:
            return list(self._items)
        return list(self._iter_matches(rules))

    def filter_any(self, rules: list[Rule]) -> list[T]:
        """Return items matching **any** rule (OR logic).

        Args:
            rules: Filter conditions.  An empty list returns no items.

        Returns:
            Items that satisfy at least one rule, in original order
            with no duplicates.
        """
        if not rules:
            return []
        return list(self._iter_matches_any(rules))

    def exclude(self, rules: list[Rule]) -> list[T]:
        """Return items that do **not** match all *rules*.

        This is the complement of :meth:`filter`: an item is excluded
        only when it satisfies **every** rule.

        Args:
            rules: Filter conditions.  An empty list returns no items
                (because ``filter([])`` returns all items).

        Returns:
            Items that fail at least one rule, in original order.
        """
        if not rules:
            return []

        from vcti.predicate import evaluate

        return [
            item
            for item in self._items
            if not all(self._matches(item, rule, evaluate) for rule in rules)
        ]

    # ── Convenience methods ─────────────────────────────────────

    def first(self, rules: list[Rule]) -> T | None:
        """Return the first item matching all *rules*, or ``None``.

        Short-circuits: stops as soon as the first match is found.
        """
        if not rules:
            return self._items[0] if self._items else None
        return next(self._iter_matches(rules), None)

    def first_any(self, rules: list[Rule]) -> T | None:
        """Return the first item matching **any** rule, or ``None``.

        Short-circuits: stops as soon as the first match is found.
        """
        if not rules:
            return None
        return next(self._iter_matches_any(rules), None)

    def first_id(self, rules: list[Rule]) -> Any | None:
        """Return the ID of the first matching item, or ``None``."""
        match = self.first(rules)
        if match is None:
            return None
        return self._get_id(match)

    def matching_ids(self, rules: list[Rule]) -> list[Any]:
        """Return IDs of all items matching all *rules*."""
        return [iid for item in self.filter(rules) if (iid := self._get_id(item)) is not None]

    def count(self, rules: list[Rule]) -> int:
        """Return the number of items matching all *rules*.

        More efficient than ``len(self.filter(rules))`` because it
        does not build the result list.
        """
        if not rules:
            return len(self._items)
        return sum(1 for _ in self._iter_matches(rules))

    def get(self, item_id: Any) -> T | None:
        """Look up an item by its ID.

        Args:
            item_id: The unique identifier.

        Returns:
            The item, or ``None`` if no item has that ID.
        """
        return self._index.get(item_id)

    # ── Container protocol ──────────────────────────────────────

    def __len__(self) -> int:
        return len(self._items)

    def __iter__(self) -> Iterator[T]:
        return iter(self._items)

    def __contains__(self, item_id: Any) -> bool:
        return item_id in self._index

    @overload
    def __getitem__(self, index: int) -> T: ...
    @overload
    def __getitem__(self, index: slice) -> Sequence[T]: ...

    def __getitem__(self, index: int | slice) -> T | Sequence[T]:
        """Access items by index or slice.

        Args:
            index: Integer index or slice.

        Returns:
            A single item for an integer index, or a subsequence
            for a slice.

        Raises:
            IndexError: If the integer index is out of range.
        """
        return self._items[index]

    def __repr__(self) -> str:
        return f"Lookup({len(self._items)} items, {len(self._index)} indexed)"
