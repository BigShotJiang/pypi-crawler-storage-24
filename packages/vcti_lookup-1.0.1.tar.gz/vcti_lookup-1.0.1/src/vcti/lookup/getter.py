# Copyright Visual Collaboration Technologies Inc. All Rights Reserved.
# See LICENSE for details.
"""ValueGetter type alias, MISSING sentinel, and built-in getter functions.

A value getter extracts an attribute value from an item by name.
Built-in getters cover dicts, objects, objects with an
``.attributes`` dict, numpy structured-array rows, and an
auto-detecting getter that handles both dicts and objects
transparently.

Getters return :data:`MISSING` when the requested attribute does not
exist on the item.  This lets the filtering layer distinguish "attribute
not present" from "attribute is present but its value is ``None``".
"""

from collections.abc import Callable
from typing import Any


class _Missing:
    """Sentinel indicating an attribute was not found on an item.

    There is exactly one instance of this class, exposed as
    :data:`MISSING`.  Use ``value is MISSING`` to test.
    """

    __slots__ = ()
    _instance: "_Missing | None" = None

    def __new__(cls) -> "_Missing":
        if cls._instance is None:
            cls._instance = super().__new__(cls)
        return cls._instance

    def __repr__(self) -> str:
        return "MISSING"

    def __bool__(self) -> bool:
        return False


MISSING: Any = _Missing()
"""Sentinel returned by getters when the attribute does not exist.

Use ``value is MISSING`` to check.  ``MISSING`` is falsy.
"""

type ValueGetter = Callable[[Any, str], Any]
"""Signature: ``(item, attribute_name) -> value``.

A value getter is any callable that takes an item and an attribute name
and returns the corresponding value, or :data:`MISSING` if the
attribute is absent.
"""


def dict_getter(item: dict, attr: str) -> Any:
    """Extract an attribute from a dict item.

    Args:
        item: A dictionary.
        attr: Key to look up.

    Returns:
        The value for *attr*, or :data:`MISSING` if the key is absent.
    """
    if attr in item:
        return item[attr]
    return MISSING


def object_getter(item: Any, attr: str) -> Any:
    """Extract an attribute from an object via ``getattr``.

    Args:
        item: Any object.
        attr: Attribute name.

    Returns:
        The attribute value, or :data:`MISSING` if the attribute is
        absent.
    """
    if hasattr(item, attr):
        return getattr(item, attr)
    return MISSING


def attributes_getter(item: Any, attr: str) -> Any:
    """Extract an attribute from an object's ``.attributes`` dict.

    This getter is designed for legacy entity objects that store
    filterable data in an ``attributes`` dictionary.

    Args:
        item: An object expected to have an ``attributes`` dict.
        attr: Key to look up in ``item.attributes``.

    Returns:
        The value from ``item.attributes``, or :data:`MISSING` if the
        object has no ``attributes`` dict or the key is absent.
    """
    if hasattr(item, "attributes"):
        attrs = item.attributes
        if attr in attrs:
            return attrs[attr]
    return MISSING


def auto_getter(item: Any, attr: str) -> Any:
    """Auto-detecting getter that works with dicts and objects.

    If the item is a dict, looks up the key.  Otherwise falls back to
    ``getattr``.

    Args:
        item: A dict or any object.
        attr: Attribute name or dict key.

    Returns:
        The value, or :data:`MISSING` if the attribute is absent.
    """
    if isinstance(item, dict):
        if attr in item:
            return item[attr]
        return MISSING
    if hasattr(item, attr):
        return getattr(item, attr)
    return MISSING


def numpy_getter(row: Any, attr: str) -> Any:
    """Extract a field from a numpy structured-array row.

    Works with ``numpy.void`` (a single row of a structured array) or
    any object supporting ``row[attr]`` with string keys.

    Args:
        row: A numpy structured-array row or similar mapping.
        attr: Field name.

    Returns:
        The field value, or :data:`MISSING` if the field does not exist.

    Examples:
        >>> import numpy as np
        >>> dt = np.dtype([("x", "f8"), ("y", "f8")])
        >>> arr = np.array([(1.0, 2.0), (3.0, 4.0)], dtype=dt)
        >>> numpy_getter(arr[0], "x")
        1.0
        >>> numpy_getter(arr[0], "z") is MISSING
        True
    """
    try:
        return row[attr]
    except (ValueError, IndexError, KeyError):
        return MISSING
