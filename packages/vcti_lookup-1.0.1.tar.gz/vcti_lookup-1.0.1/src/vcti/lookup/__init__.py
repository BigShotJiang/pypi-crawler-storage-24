# Copyright Visual Collaboration Technologies Inc. All Rights Reserved.
# See LICENSE for details.
"""vcti-lookup — attribute-based item lookup and filtering.

Public API re-exports for convenient access.
"""

from importlib.metadata import version

from .getter import (
    MISSING,
    ValueGetter,
    attributes_getter,
    auto_getter,
    dict_getter,
    numpy_getter,
    object_getter,
)
from .lookup import Lookup
from .rule import Rule

__version__ = version("vcti-lookup")

__all__ = [
    "__version__",
    "MISSING",
    "ValueGetter",
    "auto_getter",
    "attributes_getter",
    "dict_getter",
    "numpy_getter",
    "object_getter",
    "Lookup",
    "Rule",
]
