# Copyright Visual Collaboration Technologies Inc. All Rights Reserved.
# See LICENSE for details.
"""Rule dataclass for attribute-based filtering conditions.

A ``Rule`` describes a single predicate: an attribute name, an
operator symbol (resolved by vcti-predicate), an optional comparison
value, and optional modifier keyword arguments forwarded to
``vcti.predicate.evaluate()``.
"""

from dataclasses import dataclass, field
from typing import Any


@dataclass(frozen=True)
class Rule:
    """Immutable filter condition.

    Args:
        attribute: Name of the attribute to test.
        operator: Symbol name recognised by vcti-predicate
            (e.g. ``"=="``, ``"^="``, ``"contains"``).
        value: Right-hand side operand for binary operators.
            Omit or set to ``None`` for unary operators.
        modifiers: Keyword arguments forwarded to
            ``vcti.predicate.evaluate()`` (e.g.
            ``{"case_sensitive": True}``).

    Examples:
        >>> Rule("type", "==", "pdf")
        Rule(attribute='type', operator='==', value='pdf', modifiers={})
        >>> Rule("name", "^=", "Report", modifiers={"case_sensitive": True})
        Rule(attribute='name', operator='^=', value='Report', modifiers={'case_sensitive': True})
    """

    attribute: str
    operator: str = "=="
    value: Any = None
    modifiers: dict[str, Any] = field(default_factory=dict)
