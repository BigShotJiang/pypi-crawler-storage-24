# Copyright Visual Collaboration Technologies Inc. All Rights Reserved.
# See LICENSE for details.
"""Tests for the Rule dataclass."""

import pytest

from vcti.lookup.rule import Rule


class TestRuleCreation:
    def test_all_fields(self):
        rule = Rule("type", "==", "pdf", {"case_sensitive": True})
        assert rule.attribute == "type"
        assert rule.operator == "=="
        assert rule.value == "pdf"
        assert rule.modifiers == {"case_sensitive": True}

    def test_defaults(self):
        rule = Rule("name")
        assert rule.attribute == "name"
        assert rule.operator == "=="
        assert rule.value is None
        assert rule.modifiers == {}

    def test_operator_default(self):
        rule = Rule("size", value=100)
        assert rule.operator == "=="

    def test_empty_modifiers_default(self):
        rule = Rule("type", "!=", "txt")
        assert rule.modifiers == {}

    def test_modifiers_not_shared_between_instances(self):
        """Each Rule gets its own modifiers dict."""
        r1 = Rule("a")
        r2 = Rule("b")
        assert r1.modifiers is not r2.modifiers


class TestRuleFrozen:
    def test_immutable_attribute(self):
        rule = Rule("type", "==", "pdf")
        with pytest.raises(AttributeError):
            rule.attribute = "name"  # type: ignore[misc]

    def test_immutable_operator(self):
        rule = Rule("type", "==", "pdf")
        with pytest.raises(AttributeError):
            rule.operator = "!="  # type: ignore[misc]

    def test_immutable_value(self):
        rule = Rule("type", "==", "pdf")
        with pytest.raises(AttributeError):
            rule.value = "txt"  # type: ignore[misc]

    def test_immutable_modifiers(self):
        rule = Rule("type", "==", "pdf")
        with pytest.raises(AttributeError):
            rule.modifiers = {}  # type: ignore[misc]


class TestRuleEquality:
    def test_equal_rules(self):
        r1 = Rule("type", "==", "pdf")
        r2 = Rule("type", "==", "pdf")
        assert r1 == r2

    def test_unequal_rules(self):
        r1 = Rule("type", "==", "pdf")
        r2 = Rule("type", "!=", "pdf")
        assert r1 != r2

    def test_equal_with_modifiers(self):
        r1 = Rule("name", "^=", "R", {"case_sensitive": True})
        r2 = Rule("name", "^=", "R", {"case_sensitive": True})
        assert r1 == r2


class TestRuleRepr:
    def test_repr(self):
        rule = Rule("type", "==", "pdf")
        r = repr(rule)
        assert "type" in r
        assert "==" in r
        assert "pdf" in r
