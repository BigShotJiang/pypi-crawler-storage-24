# Copyright Visual Collaboration Technologies Inc. All Rights Reserved.
# See LICENSE for details.
"""Tests for the Lookup class."""

import re
from dataclasses import dataclass

import pytest

import vcti.lookup
from vcti.lookup import MISSING, Lookup, Rule
from vcti.lookup.getter import attributes_getter, dict_getter, object_getter

# ── Test fixtures ───────────────────────────────────────────────


@dataclass
class File:
    id: int
    type: str
    size: int
    tags: list


class Entity:
    def __init__(self, id, attributes):
        self.id = id
        self.attributes = attributes


DICT_ITEMS = [
    {"id": 1, "type": "pdf", "size": 1000, "tags": ["doc", "important"]},
    {"id": 2, "type": "txt", "size": 200, "tags": ["notes"]},
    {"id": 3, "type": "pdf", "size": 1500, "tags": ["doc", "archive"]},
    {"id": 4, "type": "jpg", "size": 3000, "tags": ["image"]},
]

DATACLASS_ITEMS = [
    File(1, "pdf", 1000, ["doc", "important"]),
    File(2, "txt", 200, ["notes"]),
    File(3, "pdf", 1500, ["doc", "archive"]),
    File(4, "jpg", 3000, ["image"]),
]

ENTITY_ITEMS = [
    Entity(1, {"type": "pdf", "size": 1000}),
    Entity(2, {"type": "txt", "size": 200}),
    Entity(3, {"type": "pdf", "size": 1500}),
    Entity(4, {"type": "jpg", "size": 3000}),
]


# ── Version ─────────────────────────────────────────────────────


class TestVersion:
    def test_version_exists(self):
        assert hasattr(vcti.lookup, "__version__")

    def test_version_is_valid_semver(self):
        assert re.match(r"^\d+\.\d+\.\d+", vcti.lookup.__version__)


# ── Construction ────────────────────────────────────────────────


class TestConstruction:
    def test_from_dicts(self):
        lk = Lookup(DICT_ITEMS)
        assert len(lk) == 4

    def test_from_dataclasses(self):
        lk = Lookup(DATACLASS_ITEMS)
        assert len(lk) == 4

    def test_from_entities(self):
        lk = Lookup(ENTITY_ITEMS)
        assert len(lk) == 4

    def test_empty_collection(self):
        lk = Lookup([])
        assert len(lk) == 0

    def test_duplicate_id_raises(self):
        items = [{"id": 1, "type": "a"}, {"id": 1, "type": "b"}]
        with pytest.raises(ValueError, match="Duplicate ID"):
            Lookup(items)

    def test_duplicate_id_dataclass_raises(self):
        items = [File(1, "a", 100, []), File(1, "b", 200, [])]
        with pytest.raises(ValueError, match="Duplicate ID"):
            Lookup(items)

    def test_id_key(self):
        items = [{"uid": "a", "x": 1}, {"uid": "b", "x": 2}]
        lk = Lookup(items, id_key="uid")
        assert lk.get("a") == items[0]
        assert lk.get("b") == items[1]

    def test_id_attr(self):
        @dataclass
        class Item:
            uid: str
            x: int

        items = [Item("a", 1), Item("b", 2)]
        lk = Lookup(items, id_attr="uid")
        assert lk.get("a") == items[0]

    def test_items_without_id(self):
        """Items without any ID are stored but not indexed."""
        items = [{"x": 1}, {"x": 2}]
        lk = Lookup(items)
        assert len(lk) == 2
        assert lk.get("anything") is None

    def test_object_without_id(self):
        """Objects without .id and not dicts are stored but not indexed."""

        @dataclass
        class Point:
            x: int
            y: int

        items = [Point(1, 2), Point(3, 4)]
        lk = Lookup(items)
        assert len(lk) == 2
        assert lk.get("anything") is None

    def test_no_copy(self):
        """Constructor stores the sequence by reference, no copy."""
        items = [{"id": 1, "x": 10}, {"id": 2, "x": 20}]
        lk = Lookup(items)
        assert lk._items is items


# ── items property ──────────────────────────────────────────────


class TestItemsProperty:
    def test_returns_same_reference(self):
        lk = Lookup(DICT_ITEMS)
        assert lk.items is DICT_ITEMS


# ── Iteration ───────────────────────────────────────────────────


class TestIteration:
    def test_iter(self):
        lk = Lookup(DICT_ITEMS)
        assert list(lk) == DICT_ITEMS

    def test_len(self):
        lk = Lookup(DICT_ITEMS)
        assert len(lk) == 4

    def test_contains(self):
        lk = Lookup(DICT_ITEMS)
        assert 1 in lk
        assert 99 not in lk

    def test_repr(self):
        lk = Lookup(DICT_ITEMS)
        r = repr(lk)
        assert "4 items" in r
        assert "4 indexed" in r


# ── __getitem__ ─────────────────────────────────────────────────


class TestGetItem:
    def test_integer_index(self):
        lk = Lookup(DICT_ITEMS)
        assert lk[0] == DICT_ITEMS[0]
        assert lk[3] == DICT_ITEMS[3]

    def test_negative_index(self):
        lk = Lookup(DICT_ITEMS)
        assert lk[-1] == DICT_ITEMS[-1]

    def test_slice(self):
        lk = Lookup(DICT_ITEMS)
        assert lk[1:3] == DICT_ITEMS[1:3]

    def test_out_of_range_raises(self):
        lk = Lookup(DICT_ITEMS)
        with pytest.raises(IndexError):
            lk[100]


# ── get() ───────────────────────────────────────────────────────


class TestGet:
    def test_get_existing(self):
        lk = Lookup(DICT_ITEMS)
        assert lk.get(1) == DICT_ITEMS[0]

    def test_get_missing(self):
        lk = Lookup(DICT_ITEMS)
        assert lk.get(99) is None

    def test_get_dataclass(self):
        lk = Lookup(DATACLASS_ITEMS)
        assert lk.get(2) == DATACLASS_ITEMS[1]


# ── filter() — AND logic ───────────────────────────────────────


class TestFilter:
    def test_single_rule(self):
        lk = Lookup(DICT_ITEMS)
        result = lk.filter([Rule("type", "==", "pdf")])
        assert len(result) == 2
        assert {r["id"] for r in result} == {1, 3}

    def test_multiple_rules_and_logic(self):
        lk = Lookup(DICT_ITEMS)
        rules = [Rule("type", "==", "pdf"), Rule("size", ">", 1200)]
        result = lk.filter(rules)
        assert len(result) == 1
        assert result[0]["id"] == 3

    def test_empty_rules_returns_all(self):
        lk = Lookup(DICT_ITEMS)
        assert len(lk.filter([])) == 4

    def test_no_matches_returns_empty(self):
        lk = Lookup(DICT_ITEMS)
        result = lk.filter([Rule("type", "==", "mp3")])
        assert result == []

    def test_missing_attribute_excluded(self):
        lk = Lookup(DICT_ITEMS)
        result = lk.filter([Rule("missing_attr", "==", "value")])
        assert result == []

    def test_filter_dataclasses(self):
        lk = Lookup(DATACLASS_ITEMS)
        result = lk.filter([Rule("type", "==", "pdf")])
        assert len(result) == 2
        assert {f.id for f in result} == {1, 3}

    def test_filter_with_contains(self):
        lk = Lookup(DICT_ITEMS)
        result = lk.filter([Rule("tags", "contains", "doc")])
        assert {r["id"] for r in result} == {1, 3}

    def test_filter_with_not_contains(self):
        lk = Lookup(DICT_ITEMS)
        result = lk.filter([Rule("tags", "!contains", "doc")])
        assert {r["id"] for r in result} == {2, 4}

    def test_filter_less_than(self):
        lk = Lookup(DICT_ITEMS)
        result = lk.filter([Rule("size", "<", 2000)])
        assert {r["id"] for r in result} == {1, 2, 3}

    def test_filter_none_valued_attribute(self):
        """Items with None values should be matchable, not silently skipped."""
        items = [
            {"id": 1, "status": None},
            {"id": 2, "status": "active"},
            {"id": 3, "status": "inactive"},
        ]
        lk = Lookup(items)
        result = lk.filter([Rule("status", "==", "active")])
        assert len(result) == 1
        assert result[0]["id"] == 2


# ── filter_any() — OR logic ────────────────────────────────────


class TestFilterAny:
    def test_or_logic(self):
        lk = Lookup(DICT_ITEMS)
        rules = [Rule("type", "==", "pdf"), Rule("type", "==", "jpg")]
        result = lk.filter_any(rules)
        assert {r["id"] for r in result} == {1, 3, 4}

    def test_empty_rules_returns_empty(self):
        lk = Lookup(DICT_ITEMS)
        assert lk.filter_any([]) == []

    def test_no_matches(self):
        lk = Lookup(DICT_ITEMS)
        result = lk.filter_any([Rule("type", "==", "mp3")])
        assert result == []

    def test_no_duplicates(self):
        """An item matching multiple rules should appear once."""
        lk = Lookup(DICT_ITEMS)
        rules = [Rule("type", "==", "pdf"), Rule("size", ">", 500)]
        result = lk.filter_any(rules)
        ids = [r["id"] for r in result]
        assert len(ids) == len(set(ids))

    def test_or_with_dataclasses(self):
        lk = Lookup(DATACLASS_ITEMS)
        rules = [Rule("size", "<", 300), Rule("size", ">", 2500)]
        result = lk.filter_any(rules)
        assert {f.id for f in result} == {2, 4}

    def test_preserves_insertion_order(self):
        lk = Lookup(DICT_ITEMS)
        rules = [Rule("type", "==", "jpg"), Rule("type", "==", "pdf")]
        result = lk.filter_any(rules)
        ids = [r["id"] for r in result]
        assert ids == [1, 3, 4]

    def test_filter_any_with_modifiers(self):
        items = [
            {"id": 1, "name": "Hello"},
            {"id": 2, "name": "hello"},
            {"id": 3, "name": "World"},
        ]
        lk = Lookup(items)
        rules = [
            Rule("name", "==", "Hello", {"case_sensitive": True}),
            Rule("name", "==", "World", {"case_sensitive": True}),
        ]
        result = lk.filter_any(rules)
        assert {r["id"] for r in result} == {1, 3}


# ── exclude() — NOT logic ──────────────────────────────────────


class TestExclude:
    def test_exclude_single_rule(self):
        lk = Lookup(DICT_ITEMS)
        result = lk.exclude([Rule("type", "==", "pdf")])
        assert {r["id"] for r in result} == {2, 4}

    def test_exclude_multiple_rules_and(self):
        """Excludes only items matching ALL rules."""
        lk = Lookup(DICT_ITEMS)
        rules = [Rule("type", "==", "pdf"), Rule("size", ">", 1200)]
        result = lk.exclude(rules)
        ids = {r["id"] for r in result}
        assert ids == {1, 2, 4}  # item 3 is pdf AND >1200

    def test_exclude_empty_rules_returns_empty(self):
        lk = Lookup(DICT_ITEMS)
        assert lk.exclude([]) == []

    def test_exclude_no_matches_returns_all(self):
        lk = Lookup(DICT_ITEMS)
        result = lk.exclude([Rule("type", "==", "mp3")])
        assert len(result) == 4

    def test_exclude_is_complement_of_filter(self):
        lk = Lookup(DICT_ITEMS)
        rules = [Rule("size", "<", 2000)]
        filtered = lk.filter(rules)
        excluded = lk.exclude(rules)
        all_ids = {r["id"] for r in filtered} | {r["id"] for r in excluded}
        assert all_ids == {1, 2, 3, 4}
        assert len(filtered) + len(excluded) == len(lk)


# ── first() and first_any() ────────────────────────────────────


class TestFirst:
    def test_first_match(self):
        lk = Lookup(DICT_ITEMS)
        result = lk.first([Rule("type", "==", "pdf")])
        assert result is not None
        assert result["id"] == 1

    def test_first_no_match(self):
        lk = Lookup(DICT_ITEMS)
        result = lk.first([Rule("type", "==", "mp4")])
        assert result is None

    def test_first_empty_rules_returns_first_item(self):
        lk = Lookup(DICT_ITEMS)
        result = lk.first([])
        assert result == DICT_ITEMS[0]

    def test_first_empty_collection(self):
        lk = Lookup([])
        assert lk.first([]) is None

    def test_first_id_match(self):
        lk = Lookup(DICT_ITEMS)
        result = lk.first_id([Rule("type", "==", "pdf")])
        assert result == 1

    def test_first_id_no_match(self):
        lk = Lookup(DICT_ITEMS)
        result = lk.first_id([Rule("type", "==", "mp4")])
        assert result is None


class TestFirstAny:
    def test_first_any_match(self):
        lk = Lookup(DICT_ITEMS)
        rules = [Rule("type", "==", "jpg"), Rule("type", "==", "pdf")]
        result = lk.first_any(rules)
        assert result is not None
        assert result["id"] == 1  # pdf comes before jpg in list

    def test_first_any_no_match(self):
        lk = Lookup(DICT_ITEMS)
        result = lk.first_any([Rule("type", "==", "mp3")])
        assert result is None

    def test_first_any_empty_rules(self):
        lk = Lookup(DICT_ITEMS)
        assert lk.first_any([]) is None


# ── matching_ids() ──────────────────────────────────────────────


class TestMatchingIds:
    def test_matching_ids(self):
        lk = Lookup(DICT_ITEMS)
        ids = lk.matching_ids([Rule("size", "<", 2000)])
        assert set(ids) == {1, 2, 3}

    def test_matching_ids_empty(self):
        lk = Lookup(DICT_ITEMS)
        ids = lk.matching_ids([Rule("type", "==", "mp3")])
        assert ids == []

    def test_matching_ids_dataclass(self):
        lk = Lookup(DATACLASS_ITEMS)
        ids = lk.matching_ids([Rule("type", "==", "pdf")])
        assert set(ids) == {1, 3}


# ── count() ─────────────────────────────────────────────────────


class TestCount:
    def test_count_with_rules(self):
        lk = Lookup(DICT_ITEMS)
        assert lk.count([Rule("type", "==", "pdf")]) == 2

    def test_count_no_matches(self):
        lk = Lookup(DICT_ITEMS)
        assert lk.count([Rule("type", "==", "mp3")]) == 0

    def test_count_empty_rules(self):
        lk = Lookup(DICT_ITEMS)
        assert lk.count([]) == 4

    def test_count_equals_len_of_filter(self):
        lk = Lookup(DICT_ITEMS)
        rules = [Rule("size", ">", 500)]
        assert lk.count(rules) == len(lk.filter(rules))


# ── Getter override ────────────────────────────────────────────


class TestGetterOverride:
    def test_dict_getter(self):
        lk = Lookup(DICT_ITEMS, getter=dict_getter)
        result = lk.filter([Rule("type", "==", "pdf")])
        assert len(result) == 2

    def test_object_getter(self):
        lk = Lookup(DATACLASS_ITEMS, getter=object_getter)
        result = lk.filter([Rule("type", "==", "txt")])
        assert len(result) == 1
        assert result[0].id == 2

    def test_attributes_getter(self):
        lk = Lookup(ENTITY_ITEMS, getter=attributes_getter)
        result = lk.filter([Rule("type", "==", "pdf")])
        assert len(result) == 2
        assert {e.id for e in result} == {1, 3}

    def test_custom_getter(self):
        """A custom getter can transform values on the fly."""
        items = [{"id": 1, "name": "HELLO"}, {"id": 2, "name": "Hello"}]

        def lower_getter(item, attr):
            if attr not in item:
                return MISSING
            val = item[attr]
            return val.lower() if isinstance(val, str) else val

        lk = Lookup(items, getter=lower_getter)
        # Case-sensitive: only exact "hello" matches.  The getter
        # lowered both "HELLO" and "Hello" so both now equal "hello".
        result = lk.filter([Rule("name", "==", "hello", {"case_sensitive": True})])
        assert len(result) == 2


# ── Modifiers forwarding ───────────────────────────────────────


class TestModifiers:
    def test_case_sensitive_modifier(self):
        items = [
            {"id": 1, "name": "Hello"},
            {"id": 2, "name": "hello"},
        ]
        lk = Lookup(items)

        # Default: case-insensitive
        result = lk.filter([Rule("name", "==", "hello")])
        assert len(result) == 2

        # Case-sensitive via modifier
        result = lk.filter([Rule("name", "==", "Hello", {"case_sensitive": True})])
        assert len(result) == 1
        assert result[0]["id"] == 1

    def test_startswith_case_sensitive(self):
        items = [
            {"id": 1, "name": "Report_Q1"},
            {"id": 2, "name": "report_Q2"},
        ]
        lk = Lookup(items)

        # Case-insensitive (default)
        result = lk.filter([Rule("name", "^=", "report")])
        assert len(result) == 2

        # Case-sensitive
        result = lk.filter([Rule("name", "^=", "Report", {"case_sensitive": True})])
        assert len(result) == 1
        assert result[0]["id"] == 1


# ── Unary operators ─────────────────────────────────────────────


class TestUnaryOperators:
    def test_is_empty_string(self):
        items = [
            {"id": 1, "name": ""},
            {"id": 2, "name": "hello"},
        ]
        lk = Lookup(items)
        result = lk.filter([Rule("name", "is_empty")])
        assert len(result) == 1
        assert result[0]["id"] == 1

    def test_is_empty_none(self):
        items = [
            {"id": 1, "name": None},
            {"id": 2, "name": "hello"},
        ]
        lk = Lookup(items)
        result = lk.filter([Rule("name", "is_empty")])
        assert len(result) == 1
        assert result[0]["id"] == 1

    def test_not_is_empty(self):
        items = [
            {"id": 1, "name": ""},
            {"id": 2, "name": "hello"},
            {"id": 3, "name": None},
        ]
        lk = Lookup(items)
        result = lk.filter([Rule("name", "!is_empty")])
        assert len(result) == 1
        assert result[0]["id"] == 2


# ── Numpy integration ──────────────────────────────────────────


class TestNumpyIntegration:
    @pytest.fixture
    def np(self):
        return pytest.importorskip("numpy")

    def test_filter_structured_array_direct(self, np):
        """Numpy structured array passed directly — no list() conversion."""
        from vcti.lookup.getter import numpy_getter

        dt = np.dtype([("id", "i4"), ("type", "U10"), ("size", "f8")])
        data = np.array(
            [
                (1, "pdf", 1000.0),
                (2, "txt", 200.0),
                (3, "pdf", 1500.0),
            ],
            dtype=dt,
        )

        lk = Lookup(data, getter=numpy_getter, id_key="id")
        assert lk._items is data  # no copy
        result = lk.filter([Rule("type", "==", "pdf")])
        assert len(result) == 2

    def test_filter_structured_array_no_getter(self, np):
        """Default item[key] path works on numpy rows without getter."""
        dt = np.dtype([("id", "i4"), ("type", "U10"), ("size", "f8")])
        data = np.array(
            [
                (1, "pdf", 1000.0),
                (2, "txt", 200.0),
                (3, "pdf", 1500.0),
            ],
            dtype=dt,
        )

        lk = Lookup(data, id_key="id")
        result = lk.filter([Rule("type", "==", "pdf")])
        assert len(result) == 2

    def test_filter_structured_array_numeric(self, np):
        from vcti.lookup.getter import numpy_getter

        dt = np.dtype([("id", "i4"), ("value", "f8")])
        data = np.array([(1, 10.0), (2, 20.0), (3, 30.0)], dtype=dt)

        lk = Lookup(data, getter=numpy_getter, id_key="id")
        result = lk.filter([Rule("value", ">", 15.0)])
        assert len(result) == 2

    def test_matching_ids_as_indices(self, np):
        """Level 2 pattern: use matching_ids to index back into data."""
        dt = np.dtype([("id", "i4"), ("type", "U10"), ("value", "f8")])
        data = np.array(
            [
                (0, "sensor", 3.14),
                (1, "actuator", 2.71),
                (2, "sensor", 1.41),
            ],
            dtype=dt,
        )

        lk = Lookup(data, id_key="id")
        indices = lk.matching_ids([Rule("type", "==", "sensor")])
        assert indices == [0, 2]
        # User maps back to their data
        assert float(data[indices[0]]["value"]) == pytest.approx(3.14)
        assert float(data[indices[1]]["value"]) == pytest.approx(1.41)


# ── Tuple input ────────────────────────────────────────────────


class TestTupleInput:
    def test_tuple_sequence(self):
        """Tuples are valid Sequences."""
        items = (
            {"id": 1, "type": "pdf"},
            {"id": 2, "type": "txt"},
        )
        lk = Lookup(items)
        assert len(lk) == 2
        assert lk.filter([Rule("type", "==", "pdf")]) == [items[0]]

    def test_tuple_no_copy(self):
        items = ({"id": 1, "x": 10},)
        lk = Lookup(items)
        assert lk._items is items


# ── Default fast path (item[key] / getattr fallback) ───────────


class TestDefaultFastPath:
    def test_dataclass_without_getter(self):
        """Dataclasses work via getattr fallback — no getter needed."""
        lk = Lookup(DATACLASS_ITEMS)
        result = lk.filter([Rule("type", "==", "pdf")])
        assert len(result) == 2
        assert {f.id for f in result} == {1, 3}

    def test_entity_without_getter_uses_getattr(self):
        """Plain objects use getattr fallback for top-level attributes."""
        lk = Lookup(ENTITY_ITEMS)
        # Entity has .id as a top-level attribute
        assert lk.get(1) is not None

    def test_missing_key_returns_missing(self):
        """Default path returns MISSING for absent dict keys."""
        from vcti.lookup.lookup import _default_get_value

        assert _default_get_value({"a": 1}, "b") is MISSING

    def test_missing_attr_returns_missing(self):
        """Default path returns MISSING for absent object attributes."""
        from vcti.lookup.lookup import _default_get_value

        @dataclass
        class Obj:
            x: int

        assert _default_get_value(Obj(10), "y") is MISSING

    def test_none_value_preserved(self):
        """item[key] returns None (not MISSING) when value is None."""
        from vcti.lookup.lookup import _default_get_value

        assert _default_get_value({"x": None}, "x") is None

    def test_dict_fast_path(self):
        """Dicts use item[key] directly — no TypeError fallback."""
        from vcti.lookup.lookup import _default_get_value

        assert _default_get_value({"name": "hello"}, "name") == "hello"


# ── Regex operator ──────────────────────────────────────────────


class TestRegexOperator:
    def test_regex_match(self):
        items = [
            {"id": 1, "name": "report_2024_Q1.pdf"},
            {"id": 2, "name": "notes.txt"},
            {"id": 3, "name": "report_2024_Q2.pdf"},
        ]
        lk = Lookup(items)
        result = lk.filter([Rule("name", "~=", r"report_\d{4}_Q\d")])
        assert {r["id"] for r in result} == {1, 3}

    def test_regex_no_match(self):
        items = [{"id": 1, "name": "hello"}]
        lk = Lookup(items)
        result = lk.filter([Rule("name", "~=", r"^\d+")])
        assert result == []


# ── Exists / not exists operators ───────────────────────────────


class TestExistsOperator:
    def test_exists(self):
        """exists treats None as 'not exists' — only non-None values pass."""
        items = [
            {"id": 1, "name": "hello"},
            {"id": 2, "name": None},
            {"id": 3, "name": "world"},
        ]
        lk = Lookup(items)
        result = lk.filter([Rule("name", "exists")])
        assert {r["id"] for r in result} == {1, 3}

    def test_exists_missing_attribute(self):
        """Items without the attribute at all are excluded."""
        items = [
            {"id": 1, "name": "hello"},
            {"id": 2},
        ]
        lk = Lookup(items)
        result = lk.filter([Rule("name", "exists")])
        assert len(result) == 1
        assert result[0]["id"] == 1

    def test_not_exists(self):
        """!exists matches None values and missing attributes."""
        items = [
            {"id": 1, "name": "hello"},
            {"id": 2, "name": None},
        ]
        lk = Lookup(items)
        result = lk.filter([Rule("name", "!exists")])
        assert len(result) == 1
        assert result[0]["id"] == 2


# ── Insertion order preservation ────────────────────────────────


class TestInsertionOrder:
    """All filtering methods must preserve original insertion order."""

    def _make_items(self):
        return [{"id": i, "type": ["a", "b", "c"][i % 3], "val": i} for i in range(20)]

    def test_filter_preserves_order(self):
        items = self._make_items()
        lk = Lookup(items)
        result = lk.filter([Rule("type", "==", "a")])
        ids = [r["id"] for r in result]
        assert ids == sorted(ids)

    def test_filter_any_preserves_order(self):
        items = self._make_items()
        lk = Lookup(items)
        result = lk.filter_any([Rule("type", "==", "b"), Rule("type", "==", "c")])
        ids = [r["id"] for r in result]
        assert ids == sorted(ids)

    def test_exclude_preserves_order(self):
        items = self._make_items()
        lk = Lookup(items)
        result = lk.exclude([Rule("type", "==", "a")])
        ids = [r["id"] for r in result]
        assert ids == sorted(ids)


# ── Stress test ─────────────────────────────────────────────────


class TestStress:
    def test_large_collection_filter(self):
        """Filter 10k items to verify correctness at scale."""
        types = ["pdf", "txt", "jpg", "csv", "xlsx"]
        items = [{"id": i, "type": types[i % 5], "size": (i * 37) % 10000} for i in range(10_000)]
        lk = Lookup(items)

        result = lk.filter([Rule("type", "==", "pdf")])
        assert len(result) == 2000  # every 5th item

        result = lk.filter([Rule("type", "==", "pdf"), Rule("size", ">", 5000)])
        assert all(r["type"] == "pdf" and r["size"] > 5000 for r in result)

    def test_large_collection_first_short_circuits(self):
        """first() on 10k items should not process all items."""
        items = [{"id": i, "type": "pdf" if i == 0 else "txt", "size": i} for i in range(10_000)]
        lk = Lookup(items)
        result = lk.first([Rule("type", "==", "pdf")])
        assert result is not None
        assert result["id"] == 0

    def test_large_collection_count(self):
        """count() on 10k items matches len(filter())."""
        types = ["pdf", "txt", "jpg"]
        items = [{"id": i, "type": types[i % 3]} for i in range(10_000)]
        lk = Lookup(items)
        rules = [Rule("type", "==", "pdf")]
        assert lk.count(rules) == len(lk.filter(rules))
