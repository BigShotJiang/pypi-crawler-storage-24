# Copyright Visual Collaboration Technologies Inc. All Rights Reserved.
# See LICENSE for details.
"""Tests for value getter functions and MISSING sentinel."""

from dataclasses import dataclass

import pytest

from vcti.lookup.getter import (
    MISSING,
    attributes_getter,
    auto_getter,
    dict_getter,
    numpy_getter,
    object_getter,
)

# ── Fixtures ────────────────────────────────────────────────────


@dataclass
class SampleObject:
    name: str
    size: int


class EntityWithAttributes:
    def __init__(self, attrs: dict):
        self.attributes = attrs


# ── MISSING sentinel ───────────────────────────────────────────


class TestMissing:
    def test_is_singleton(self):
        from vcti.lookup.getter import _Missing

        assert _Missing() is MISSING

    def test_is_falsy(self):
        assert not MISSING
        assert bool(MISSING) is False

    def test_repr(self):
        assert repr(MISSING) == "MISSING"

    def test_is_not_none(self):
        assert MISSING is not None


# ── dict_getter ────────────────────────────────────────────────


class TestDictGetter:
    def test_existing_key(self):
        item = {"name": "report.pdf", "size": 1024}
        assert dict_getter(item, "name") == "report.pdf"

    def test_missing_key_returns_missing(self):
        item = {"name": "report.pdf"}
        assert dict_getter(item, "missing") is MISSING

    def test_none_value_key(self):
        item = {"name": None}
        assert dict_getter(item, "name") is None

    def test_empty_dict(self):
        assert dict_getter({}, "any") is MISSING

    def test_false_value_key(self):
        item = {"active": False}
        assert dict_getter(item, "active") is False

    def test_zero_value_key(self):
        item = {"count": 0}
        assert dict_getter(item, "count") == 0


# ── object_getter ──────────────────────────────────────────────


class TestObjectGetter:
    def test_existing_attribute(self):
        obj = SampleObject(name="test", size=100)
        assert object_getter(obj, "name") == "test"

    def test_missing_attribute_returns_missing(self):
        obj = SampleObject(name="test", size=100)
        assert object_getter(obj, "missing") is MISSING

    def test_with_dataclass(self):
        obj = SampleObject(name="report", size=2048)
        assert object_getter(obj, "size") == 2048

    def test_none_valued_attribute(self):
        class Obj:
            val = None

        assert object_getter(Obj(), "val") is None


# ── attributes_getter ─────────────────────────────────────────


class TestAttributesGetter:
    def test_existing_attribute(self):
        entity = EntityWithAttributes({"type": "pdf", "size": 500})
        assert attributes_getter(entity, "type") == "pdf"

    def test_missing_attribute(self):
        entity = EntityWithAttributes({"type": "pdf"})
        assert attributes_getter(entity, "missing") is MISSING

    def test_no_attributes_dict(self):
        obj = SampleObject(name="test", size=100)
        assert attributes_getter(obj, "name") is MISSING

    def test_empty_attributes(self):
        entity = EntityWithAttributes({})
        assert attributes_getter(entity, "any") is MISSING

    def test_none_valued_attribute(self):
        entity = EntityWithAttributes({"status": None})
        assert attributes_getter(entity, "status") is None


# ── auto_getter ────────────────────────────────────────────────


class TestAutoGetter:
    def test_dict_item(self):
        item = {"name": "test.txt", "size": 256}
        assert auto_getter(item, "name") == "test.txt"

    def test_dict_missing_key(self):
        item = {"name": "test.txt"}
        assert auto_getter(item, "missing") is MISSING

    def test_object_item(self):
        obj = SampleObject(name="report", size=1024)
        assert auto_getter(obj, "name") == "report"

    def test_object_missing_attr(self):
        obj = SampleObject(name="report", size=1024)
        assert auto_getter(obj, "missing") is MISSING

    def test_dataclass_item(self):
        obj = SampleObject(name="data", size=512)
        assert auto_getter(obj, "size") == 512

    def test_prefers_dict_get_for_dicts(self):
        """Dicts should use key lookup, not getattr()."""
        d = {"key": "value"}
        assert auto_getter(d, "key") == "value"
        assert auto_getter(d, "nonexistent") is MISSING

    def test_dict_none_value(self):
        item = {"status": None}
        assert auto_getter(item, "status") is None

    def test_object_none_value(self):
        class Obj:
            status = None

        assert auto_getter(Obj(), "status") is None


# ── numpy_getter ───────────────────────────────────────────────


class TestNumpyGetter:
    @pytest.fixture
    def np(self):
        np = pytest.importorskip("numpy")
        return np

    def test_structured_array_field(self, np):
        dt = np.dtype([("x", "f8"), ("y", "f8")])
        arr = np.array([(1.0, 2.0)], dtype=dt)
        assert numpy_getter(arr[0], "x") == 1.0

    def test_missing_field_returns_missing(self, np):
        dt = np.dtype([("x", "f8")])
        arr = np.array([(1.0,)], dtype=dt)
        assert numpy_getter(arr[0], "z") is MISSING

    def test_works_with_dict_like(self):
        """numpy_getter should work with any mapping-like object."""
        d = {"a": 10}
        assert numpy_getter(d, "a") == 10
        assert numpy_getter(d, "missing") is MISSING

    def test_integer_field_names(self, np):
        dt = np.dtype([("id", "i4"), ("name", "U20"), ("value", "f8")])
        arr = np.array([(1, "sensor", 3.14)], dtype=dt)
        row = arr[0]
        assert numpy_getter(row, "id") == 1
        assert numpy_getter(row, "name") == "sensor"
