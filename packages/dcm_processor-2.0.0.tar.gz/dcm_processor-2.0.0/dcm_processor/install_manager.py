import argparse
from .libs.config import get_app_subdirs, get_app_config
from .libs.component_lib import CompManager
from dcm_processor_utils import REGISTRY_API_URL

def install_component_args(parser: argparse.ArgumentParser):
    """Patch install service command line args"""
    parser.add_argument(
        "file", metavar="file", type=str, nargs="*", help="Component(s) to install"
    )
    parser.add_argument(
        "-r",
        dest="requirement_file",
        type=str,
        help="Path to a requirements file with a list of services or workers to install",
    )
    parser.add_argument(
        "-s",
        "--service-only",
        dest="service_only",
        action="store_true",
        help="Install only service and skip worker if it exists"
    )
    parser.add_argument(
        "-w",
        "--worker-only",
        dest="worker_only",
        action="store_true",
        help="Install only worker and skip service if it exists"
    )
    parser.add_argument(
        "-f",
        "--force",
        dest="force",
        action="store_true",
        help="Force install component even if it exists"
    )
    parser.add_argument(
        "-a",
        "--app",
        dest="app",
        type=str,
        help="Application environment where action is performed default to the current default application",
    )
    parser.add_argument(
        "--reg",
        "--registry",
        dest="registry",
        type=str,
        help=f"Optional registry to use, defaults to '{REGISTRY_API_URL}' or the env DCM_PROCESSOR_REGISTRY",
    )

def uninstall_component_args(parser: argparse.ArgumentParser):
    """Patch uninstall service command line args"""
    parser.add_argument(
        "name", metavar="name", type=str, nargs="+", help="Components to uninstall"
    )
    parser.add_argument(
        "-s",
        "--service-only",
        dest="service_only",
        action="store_true",
        help="Install only service and skip worker if it exists"
    )
    parser.add_argument(
        "-w",
        "--worker-only",
        dest="worker_only",
        action="store_true",
        help="Install only worker and skip service if it exists"
    )
    parser.add_argument(
        "-a",
        "--app",
        dest="app",
        type=str,
        help="Application environment where action is performed default to the current default application",
    )

def handle_install_component(args):
    app = get_app_config(args.app)
    com_mgr = CompManager(registry=args.registry, **app)

    app_dirs = get_app_subdirs(args.app)

    com_mgr.install_module(
        file=args.file,
        requirements=args.requirement_file,
        force=args.force,
        service_only=args.service_only,
        worker_only=args.worker_only,
        app_service_dir={
            "modules": app_dirs.get("modules"),
            "registry": app_dirs.get("registry")
        },
        app_worker_dir=app_dirs.get("workers")
    )

def handle_uninstall_component(args):
    app = get_app_config(args.app)
    com_mgr = CompManager(**app)

    app_dirs = get_app_subdirs(args.app)

    com_mgr.uninstall_module(
        name=args.name,
        service_only=args.service_only,
        worker_only=args.worker_only,
        app_service_dir={
            "modules": app_dirs.get("modules"),
            "registry": app_dirs.get("registry")
        },
        app_worker_dir=app_dirs.get("workers")
    )
