import argparse, signal, time, os, pathlib, tempfile, json
from datetime import datetime
from types import SimpleNamespace as Namespace
from .libs.config import insert_app, get_default_app, get_app_config, get_app_subdirs
from dcm_processor_utils import APPSETTINGS
from .libs.downloaders import zip_directory, unzip_file
from .install_manager import handle_install_component
from dcm_processor_db_provider import DBManager
from .constants import VERSION

def _get_app_runner_cls():
    from .libs.app_runner import AppRunner
    return AppRunner

def create_app_args(parser: argparse.ArgumentParser):
    """Patch create app command line args"""
    parser.add_argument(
        "app", metavar="app_name", type=str, help="Name of the application must be unique across installation"
    )
    parser.add_argument(
        "--db-url",
        dest="db_url",
        type=str,
        default="mongodb://localhost:27017",
        help="Connection to the MongoDB instance to store application data",
    )
    parser.add_argument(
        "--db-name",
        dest="db_name",
        type=str,
        help="The database name for this application, should be unique per application. Will default to dcm_processor_app_<appname>",
    )
    parser.add_argument(
        "--db-provider",
        dest="db_provider",
        type=str,
        default="mongodb",
        help="The database name for this application, should be unique per application.",
    )

def start_app_args(parser: argparse.ArgumentParser):
    """Patch start application command line args"""
    parser.add_argument(
        "app", metavar="app", type=str, nargs="*", help="App(s) to start"
    )
    parser.add_argument(
        "-j",
        "--jobs",
        dest="num_jobs",
        type=int,
        help="Number of workers to spawn for each application",
    )
    parser.add_argument(
        "-d",
        "--detach",
        dest="detach",
        action="store_true",
        help="Run the app in detached mode",
    )

def stop_app_args(parser: argparse.ArgumentParser):
    """Patch stop application command line args"""
    parser.add_argument(
        "app", metavar="app", type=str, nargs="*", help="Application(s) to start"
    )

def status_app_args(parser: argparse.ArgumentParser):
    """Patch application status command line args"""
    parser.add_argument(
        "app", metavar="app", type=str, nargs="*", help="Application(s) to get status from"
    )

def restart_app_args(parser: argparse.ArgumentParser):
    """Patch restart application command line args"""
    parser.add_argument(
        "app", metavar="app", type=str, nargs="*", help="App(s) to start"
    )
    parser.add_argument(
        "-j",
        "--jobs",
        dest="num_jobs",
        type=int,
        help="Number of workers to spawn for each application",
    )
    parser.add_argument(
        "-d",
        "--detach",
        dest="detach",
        action="store_true",
        help="Run the app in detached mode",
    )

def view_app_logs_args(parser: argparse.ArgumentParser):
    """Patch view app logs command line args"""
    parser.add_argument(
        "app", metavar="app", type=str, nargs="?", help="Application to load logs from"
    )
    parser.add_argument(
        "-f",
        "--follow",
        action="store_true",
        help="Follow the log file in real time (like tail -f)"
    )
    parser.add_argument(
        "-n",
        "--lines",
        type=int,
        default=10,
        help="Number of lines to show from the end of the log (default: 10)"
    )

def backup_app_args(parser: argparse.ArgumentParser):
    """Patch backup app command line args"""
    parser.add_argument(
        "app", metavar="app", type=str, nargs="?", help="Service(s) to start"
    )
    parser.add_argument(
        "-p",
        "--path",
        dest="backup_path",
        type=str,
        help="Path to location where the backup will be created",
    )

def restore_app_args(parser: argparse.ArgumentParser):
    """Patch restore app command line args"""
    parser.add_argument(
        "app", metavar="app", type=str, nargs="?", help="Service(s) to start"
    )
    parser.add_argument(
        "-f",
        "--filename",
        dest="backup_file",
        type=str,
        required=True,
        help="Filename of the backup to be restored",
    )
    parser.add_argument(
        "--reset",
        dest="reset_app",
        action="store_true",
        help="Whether to clear existing data in application",
    )

def init_app_args(parser: argparse.ArgumentParser):
    """Patch init app command line args"""
    parser.add_argument(
        "app", metavar="app", type=str, nargs="?", help="App to initialize"
    )
    parser.add_argument(
        "-r",
        "--registry",
        dest="registry",
        type=str,
        help="The URL of the registry defaults to 'https://dcm-processor.com' or to the env DCM_PROCESSOR_REGISTRY if available",
    )
    parser.add_argument(
        "-f"
        "--force",
        dest="force_init",
        action="store_true",
        help="Whether to force re-initialize app if its already initialized",
    )

def handle_create_app(args):
    
    app_info = {
        "name": args.app,
        "dburl": args.db_url,
        "dbname": args.db_name or f"dcm_processor_app_{args.app}",
        "dbprovider": "mongodb" # Support only mongodb for now
    }

    insert_id = insert_app(app_info)

    if insert_id:
        # Initialize app here.....
        print(f"Application successfully created!", insert_id)
    else:
        print("Unable to create application!")

def handle_start_app(args):
    apps = args.app
    detach = args.detach

    if len(apps) == 0:
        apps = [get_default_app()]

    runners = ()
    AppRunner = _get_app_runner_cls()

    for app in apps:
        runner = AppRunner(app_name=app, num_workers=args.num_jobs)
        runner.start()
        runners += (runner, )

    if not detach:
        running = True
        def handle_signal(signum, frame):
            nonlocal running
            running = False

        # Register signals
        signal.signal(signal.SIGINT, handle_signal)   # Ctrl+C
        signal.signal(signal.SIGTERM, handle_signal)  # kill, systemd stop, etc.

        # Main loop
        print("Press Ctrl+C to stop.")
        while running:
            time.sleep(1)

        print("Stopping applications...")
        for runner in runners:
            runner.stop()
    else:
        os._exit(0)
        #sys._exit(0)

def handle_stop_app(args):
    apps = args.app
    
    if len(apps) == 0:
        apps = [get_default_app()]

    AppRunner = _get_app_runner_cls()
    for app in apps:
        runner = AppRunner(app_name=app)
        runner.stop()

def handle_restart_app(args):
    handle_stop_app(args)
    time.sleep(2)
    handle_start_app(args)

def handle_view_app_logs(args):
    app_name = args.app or get_default_app()
    config = get_app_config(app_name)

    app_dirs = get_app_subdirs(app_name)
    base_app_dir = app_dirs.get("app")
    log_file = os.path.join(base_app_dir, "logs.txt")

    if config is None or log_file is None:
        print(f"Application with name '{app_name}' does not exist!")
        return

    if not (os.path.exists(log_file) and os.path.isfile(log_file)):
        pathlib.Path(base_app_dir).mkdir(parents=True, exist_ok=True)
        with open(log_file, "a"):
            pass  # just create an empty file

    # Read last N lines
    with open(log_file, "r") as f:
        lines = f.readlines()
        tail_lines = lines[-args.lines :]
        for line in tail_lines:
            print(line, end="")

    # Follow the log file if requested
    if args.follow:
        try:
            with open(log_file, "r") as f:
                # Move to the end
                f.seek(0, os.SEEK_END)
                while True:
                    line = f.readline()
                    if line:
                        print(line, end="")
                    else:
                        time.sleep(0.5)
        except KeyboardInterrupt:
            print("\nStopped following logs.")

def handle_status_app(args):
    apps = args.app
    
    if len(apps) == 0:
        apps = [get_default_app()]

    AppRunner = _get_app_runner_cls()
    for app in apps:
        runner = AppRunner(app_name=app)
        runner.status()

def handle_backup_app(args):

    with tempfile.TemporaryDirectory() as tmpdir:
        now = datetime.now()
        timestamp = now.strftime("%Y-%m-%d_%H-%M-%S")
        
        backup_dir = args.backup_path or os.getcwd()
        filename = os.path.join(backup_dir, f"dcm-processor-backup_{timestamp}.zip")
        app_name = args.app or get_default_app()
        config = get_app_config(app_name)

        mgr = DBManager(
            dbprovider=config.get("dbprovider"),
            dburl=config.get("dburl"),
            dbname=config.get("dbname"),
        )

        # export objects and files
        mgr.prepare_backup(tmpdir)

        config["dcm-processor-version"] = VERSION
        # Add config.json
        with open(os.path.join(tmpdir, "config.json"), 'w', encoding='utf-8') as f:
            json.dump(config, f, indent=4)

        os.makedirs(backup_dir, exist_ok=True)
        zip_directory(tmpdir, filename)

        print(f"backup created successfully at {filename}")
        
def handle_restore_app(args):
    filename = args.backup_file

    with tempfile.TemporaryDirectory() as tmpdir:
        print(f"restoring backap from {filename}")
        output_path = os.path.join(tmpdir, "backup")
        unzip_file(filename, output_path)
        config_filename = os.path.join(output_path, "config.json")

        if not os.path.exists(config_filename):
            print("Error in backup data!!")
            return
        
        source_config = None
        with open(config_filename, 'r', encoding='utf-8') as f:
            source_config = json.load(f)

        app_name = args.app or get_default_app()
        config = get_app_config(app_name)

        mgr = DBManager(
            dbprovider=config.get("dbprovider"),
            dbname=config.get("dbname"),
            dburl=config.get("dburl")
        )

        mgr.restore_backup(output_path, source_config.get("dbprovider"), clear_app=args.reset_app)
        print("Backup restoring completed!")

def handle_init_app(args):
    app_name = args.app or get_default_app()

    config = get_app_config(app_name)
    force_init = args.force_init

    mgr = DBManager(
        dbprovider=config.get("dbprovider"),
        dburl=config.get("dburl"),
        dbname=config.get("dbname"),
    )

    is_init = mgr.get_app_settings(APPSETTINGS.INITIALIZED)

    if (not is_init) or (is_init is None) or (force_init):
        workers = [
            "dcm-processor-default-worker"
        ]
        services = []

        # Install workers
        for worker in workers:
            install_args = Namespace(
                app=app_name,
                file=[worker],
                force=True,
                worker_only=True,
                service_only=False,
                requirement_file=None,
                registry=args.registry
            )
            handle_install_component(install_args)

        # Install services
        for service in services:
            install_args = Namespace(
                app=app_name,
                file=[service],
                force=True,
                worker_only=False,
                service_only=False,
                requirement_file=None,
                registry=args.registry
            )
            handle_install_component(install_args)

        # Set initialized
        mgr.set_app_settings(APPSETTINGS.INITIALIZED, True)
        mgr.set_app_settings(APPSETTINGS.DEFAULT_WORKER, "dcm-processor-default-worker")
