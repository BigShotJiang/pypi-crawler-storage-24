import argparse, os
from tabulate import tabulate
from dcm_processor_db_provider import DBManager
from .libs.config import get_device_id, get_app_config

def patch_node_args(parser: argparse.ArgumentParser):
    subparsers = parser.add_subparsers(dest="node_command")

    add_parser = subparsers.add_parser("add", help="Add a new dicom node to application")
    create_node_args(add_parser)

    edit_parser = subparsers.add_parser("edit", help="Edit existing dicom node")
    edit_node_args(edit_parser)

    remove_parser = subparsers.add_parser("remove", help="Remove dicom node from application")
    remove_node_args(remove_parser)

    list_parser = subparsers.add_parser("list", help="List configured node in the application")
    list_nodes_args(list_parser)

    get_parser = subparsers.add_parser("get", help="Get detailed information about a node")
    get_node_args(get_parser)

def create_node_args(parser: argparse.ArgumentParser):
    """Patch create dicom node command line args"""
    parser.add_argument(
        "node_name", metavar="node_name", type=str, help="Name of the node must be unique across an application"
    )
    parser.add_argument(
        "--app",
        dest="app",
        type=str,
        help="The application name to add the node, defaults to default app.",
    )
    parser.add_argument(
        "--aet",
        dest="aet",
        type=str,
        default="dcm-processor",
        help="The AET for the node",
        required=True
    )
    parser.add_argument(
        "--host",
        dest="host",
        type=str,
        default="0.0.0.0",
        help="The host for the node",
        required=True
    )
    parser.add_argument(
        "--port",
        dest="port",
        type=int,
        help="The port that will be bind to this node",
        required=True
    )
    parser.add_argument(
        "--tls",
        dest="tls",
        action="store_true",
        help="Enable tls for this node",
    )
    parser.add_argument(
        "--cert-file",
        dest="tls_cert_file",
        type=str,
        help="Path to the tls cert file",
    )
    parser.add_argument(
        "--key-file",
        dest="tls_key_file",
        type=str,
        help="Path to the tls key file",
    )
    parser.add_argument(
        "--ca-file",
        dest="tls_ca_file",
        type=str,
        help="Path to the tls ca file for verifying peers",
    )
    parser.add_argument(
        "--max-pdu",
        dest="max_pdu",
        type=int,
        help="Max PDU for dicom node",
    )

def edit_node_args(parser: argparse.ArgumentParser):
    """Patch edit node args"""
    parser.add_argument(
        "node_name", metavar="node_name", type=str, help="Name of the node already exist in selected application"
    )
    parser.add_argument(
        "--app",
        dest="app",
        type=str,
        help="The application name to edit the node, defaults to default app.",
    )
    parser.add_argument(
        "--aet",
        dest="aet",
        type=str,
        help="The AET for the node",
    )
    parser.add_argument(
        "--host",
        dest="host",
        type=str,
        help="The host for the node",
    )
    parser.add_argument(
        "--port",
        dest="port",
        type=int,
        help="The port that will be bind to this node",
    )
    parser.add_argument(
        "--tls",
        dest="tls",
        action="store_true",
        help="Enable tls for this node",
    )
    parser.add_argument(
        "--no-tls",
        dest="no_tls",
        action="store_true",
        help="Disable tls for this node",
    )
    parser.add_argument(
        "--cert-file",
        dest="tls_cert_file",
        type=str,
        help="Path to the tls cert file",
    )
    parser.add_argument(
        "--key-file",
        dest="tls_key_file",
        type=str,
        help="Path to the tls key file",
    )
    parser.add_argument(
        "--ca-file",
        dest="tls_ca_file",
        type=str,
        help="Path to the tls ca file for verifying peers",
    )
    parser.add_argument(
        "--max-pdu",
        dest="max_pdu",
        type=int,
        help="Max PDU for dicom node",
    )

def remove_node_args(parser: argparse.ArgumentParser):
    """Patch remove node command line args"""
    parser.add_argument(
        "node_name", metavar="node_name", type=str, help="Name of the node already exist in selected application"
    )
    parser.add_argument(
        "--app",
        dest="app",
        type=str,
        help="The application name to edit the node, defaults to default app.",
    )

def list_nodes_args(parser: argparse.ArgumentParser):
    """Patch show nodes command line args"""
    parser.add_argument(
        "--app",
        dest="app",
        type=str,
        help="The application name to edit the node, defaults to default app.",
    )

def get_node_args(parser: argparse.ArgumentParser):
    """Patch get node command line args"""
    parser.add_argument(
        "node_name", metavar="node_name", type=str, help="Name of the node already exist in selected application"
    )
    parser.add_argument(
        "--app",
        dest="app",
        type=str,
        help="The application name to edit the node, defaults to default app.",
    )

def handle_node_main(args):
    node_command = args.node_command

    if node_command == "add":
        handle_add(args)
    elif node_command == "edit":
        handle_edit(args)
    elif node_command == "remove":
        handle_remove(args)
    elif node_command == "list":
        handle_list(args)
    elif node_command == "get":
        handle_get(args)

def handle_add(args):
    data = {
        "name": args.node_name,
        "host": args.host,
        "port": args.port,
        "aet": args.aet,
        "pdu": args.max_pdu,
        "device_id": get_device_id()
    }

    edit_tls = args.tls or args.no_tls

    if args.tls:
        data["tls"] = True
        cert_file = args.tls_cert_file
        key_file = args.tls_key_file
        ca_file = args.tls_ca_file
        trusted_ca = ca_file is None

        if args.cert_file is None:
            print("Cert file required for tls node!")
            return
        
        if args.key_file is None:
            print("Key file required for tls node!")
            return

        if not (os.path.exists(cert_file) and os.path.isfile(cert_file)):
            print(f"Cert file {cert_file} does not exists!")
            return
        
        if not (os.path.exists(key_file) and os.path.isfile(key_file)):
            print(f"Key file {key_file} does not exists!")
            return
        
        if (not trusted_ca) and not (os.path.exists(ca_file) and os.path.isfile(ca_file)):
            print(f"CA file {ca_file} does not exists!")
            return

        data["cert_file"] = cert_file
        data["key_file"] = key_file
        data["ca_file"] = ca_file
    else:
        data["tls"] = False

    config = get_app_config(args.app)
    
    mgr = DBManager(
        dbname=config.get("dbname"),
        dburl=config.get("dburl"),
        dbprovider=config.get("dbprovider"),
    )

    res = mgr.create_dicom_node(data=data)
    print(f"DICOM Node added with id {res}")

def handle_edit(args):
    data = {
        "name": args.node_name,
        "host": args.host,
        "port": args.port,
        "aet": args.aet,
        "pdu": args.max_pdu
    }

    edit_tls = args.tls or args.no_tls

    if edit_tls and args.tls:
        data["tls"] = True
        cert_file = args.tls_cert_file
        key_file = args.tls_key_file
        ca_file = args.tls_ca_file
        trusted_ca = ca_file is None

        if cert_file is None:
            print("Cert file required for tls node!")
            return
        
        if key_file is None:
            print("Key file required for tls node!")
            return

        if not (os.path.exists(cert_file) and os.path.isfile(cert_file)):
            print(f"Cert file {cert_file} does not exists!")
            return
        
        if not (os.path.exists(key_file) and os.path.isfile(key_file)):
            print(f"Key file {key_file} does not exists!")
            return
        
        if (not trusted_ca) and not (os.path.exists(ca_file) and os.path.isfile(ca_file)):
            print(f"CA file {ca_file} does not exists!")
            return

        data["cert_file"] = cert_file
        data["key_file"] = key_file
        data["ca_file"] = ca_file
    elif edit_tls and args.no_tls:
        data["tls"] = False

    update_data = {}

    for k in data:
        if not data[k] is None:
            update_data[k] = data[k]

    config = get_app_config(args.app)
    
    mgr = DBManager(
        dbname=config.get("dbname"),
        dburl=config.get("dburl"),
        dbprovider=config.get("dbprovider"),
    )

    res = mgr.update_dicom_node(name=args.node_name, data={"$set": update_data})
    print(f"Updated node with id {res}")

def handle_remove(args):
    config = get_app_config(args.app)
    mgr = DBManager(
        dbname=config.get("dbname"),
        dburl=config.get("dburl"),
        dbprovider=config.get("dbprovider"),
    )

    res = mgr.remove_dicom_node(name=args.node_name)
    if not res is None:
        print(f"DICOM Node with id {res} removed!")

def handle_list(args):
    config = get_app_config(args.app)
    mgr = DBManager(
        dbname=config.get("dbname"),
        dburl=config.get("dburl"),
        dbprovider=config.get("dbprovider"),
    )

    items = mgr.find_dicom_nodes()
    for item in items:
        if 'device_id' in item:
            del item["device_id"]

    print(tabulate(items, headers="keys", tablefmt="grid"))

def handle_get(args):
    config = get_app_config(args.app)
    mgr = DBManager(
        dbname=config.get("dbname"),
        dburl=config.get("dburl"),
        dbprovider=config.get("dbprovider"),
    )

    item = mgr.get_dicom_node(name=args.node_name)
    if not item is None:
        print(DBManager.to_json(item, config.get("dbprovider")))