import argparse, os
from tabulate import tabulate
from dcm_processor_db_provider import DBManager
from .libs.config import get_app_config

def patch_peer_args(parser: argparse.ArgumentParser):
    subparsers = parser.add_subparsers(dest="peer_command")

    add_parser = subparsers.add_parser("add", help="Add a new dicom peer to application")
    create_peer_args(add_parser)

    edit_parser = subparsers.add_parser("edit", help="Edit existing dicom peer")
    edit_peer_args(edit_parser)

    remove_parser = subparsers.add_parser("remove", help="Remove dicom peer from application")
    remove_peer_args(remove_parser)

    list_parser = subparsers.add_parser("list", help="List configured peer in the application")
    list_peers_args(list_parser)

    get_parser = subparsers.add_parser("get", help="Get detailed information about a peer")
    get_peer_args(get_parser)

def create_peer_args(parser: argparse.ArgumentParser):
    """Patch create dicom peer command line args"""
    parser.add_argument(
        "peer_name", metavar="peer_name", type=str, help="Name of the peer must be unique across an application"
    )
    parser.add_argument(
        "--app",
        dest="app",
        type=str,
        help="The application name to add the peer, defaults to default app.",
    )
    parser.add_argument(
        "--aet",
        dest="aet",
        type=str,
        default="dcm-processor",
        help="The called AET for the peer",
        required=True
    )
    parser.add_argument(
        "--calling-aet",
        dest="calling_aet",
        type=str,
        help="The calling AET for the peer",
    )
    parser.add_argument(
        "--host",
        dest="host",
        type=str,
        default="0.0.0.0",
        help="The host for the peer",
        required=True
    )
    parser.add_argument(
        "--port",
        dest="port",
        type=int,
        help="The port that will be bind to this peer",
        required=True
    )
    parser.add_argument(
        "--tls",
        dest="tls",
        action="store_true",
        help="Enable tls for this peer",
    )
    parser.add_argument(
        "--cert-file",
        dest="tls_cert_file",
        type=str,
        help="Path to the tls cert file",
    )
    parser.add_argument(
        "--key-file",
        dest="tls_key_file",
        type=str,
        help="Path to the tls key file",
    )
    parser.add_argument(
        "--ca-file",
        dest="tls_ca_file",
        type=str,
        help="Path to the tls ca file for verifying peers",
    )
    parser.add_argument(
        "-a",
        "--allowed-aet",
        dest="allowed_aets",
        type=str,
        action="append",
        help="Whitelist one or more peer AETs",
    )

    parser.add_argument(
        "-i"
        "--allowed-ip",
        dest="allowed_ips",
        type=str,
        action="append",
        help="Whitelist one or more peer IP addresses",
    )

def edit_peer_args(parser: argparse.ArgumentParser):
    """Patch edit peer args"""
    parser.add_argument(
        "peer_name", metavar="peer_name", type=str, help="Name of the peer already exist in selected application"
    )
    parser.add_argument(
        "--app",
        dest="app",
        type=str,
        help="The application name to edit the peer, defaults to default app.",
    )
    parser.add_argument(
        "--aet",
        dest="aet",
        type=str,
        help="The called AET for the peer",
    )
    parser.add_argument(
        "--calling-aet",
        dest="calling_aet",
        type=str,
        help="The calling AET for the peer",
    )
    parser.add_argument(
        "--host",
        dest="host",
        type=str,
        help="The host for the peer",
    )
    parser.add_argument(
        "--port",
        dest="port",
        type=int,
        help="The port that will be bind to this peer",
    )
    parser.add_argument(
        "--tls",
        dest="tls",
        action="store_true",
        help="Enable tls for this peer",
    )
    parser.add_argument(
        "--no-tls",
        dest="no_tls",
        action="store_true",
        help="Disable tls for this peer",
    )
    parser.add_argument(
        "--cert-file",
        dest="tls_cert_file",
        type=str,
        help="Path to the tls cert file",
    )
    parser.add_argument(
        "--key-file",
        dest="tls_key_file",
        type=str,
        help="Path to the tls key file",
    )
    parser.add_argument(
        "--ca-file",
        dest="tls_ca_file",
        type=str,
        help="Path to the tls ca file for verifying peers",
    )
    parser.add_argument(
        "-a",
        "--allowed-aet",
        dest="allowed_aets",
        type=str,
        action="append",
        help="Whitelist one or more peer AETs",
    )
    parser.add_argument(
        "-i"
        "--allowed-ip",
        dest="allowed_ips",
        type=str,
        action="append",
        help="Whitelist one or more peer IP addresses",
    )
    parser.add_argument(
        "--clear-aets",
        dest="clear_aet",
        action="store_true",
        help="Clear existing whitelisted AETs",
    )
    parser.add_argument(
        "--clear-ips",
        dest="clear_ip",
        action="store_true",
        help="Clear existing whitelisted IPs",
    )

def remove_peer_args(parser: argparse.ArgumentParser):
    """Patch remove peer command line args"""
    parser.add_argument(
        "peer_name", metavar="peer_name", type=str, help="Name of the peer already exist in selected application"
    )
    parser.add_argument(
        "--app",
        dest="app",
        type=str,
        help="The application name to edit the peer, defaults to default app.",
    )

def list_peers_args(parser: argparse.ArgumentParser):
    """Patch show peers command line args"""
    parser.add_argument(
        "--app",
        dest="app",
        type=str,
        help="The application name to edit the peer, defaults to default app.",
    )

def get_peer_args(parser: argparse.ArgumentParser):
    """Patch get peer command line args"""
    parser.add_argument(
        "peer_name", metavar="peer_name", type=str, help="Name of the peer already exist in selected application"
    )
    parser.add_argument(
        "--app",
        dest="app",
        type=str,
        help="The application name to edit the peer, defaults to default app.",
    )

def handle_peer_main(args):
    peer_command = args.peer_command

    if peer_command == "add":
        handle_add(args)
    elif peer_command == "edit":
        handle_edit(args)
    elif peer_command == "remove":
        handle_remove(args)
    elif peer_command == "list":
        handle_list(args)
    elif peer_command == "get":
        handle_get(args)

def handle_add(args):
    data = {
        "name": args.peer_name,
        "host": args.host,
        "port": args.port,
        "aet": args.aet,
        "whitelist_aet": args.allowed_aets or [],
        "whitelist_ip": args.allowed_ips or [],
    }

    if args.tls:
        data["tls"] = True
        cert_file = args.tls_cert_file
        key_file = args.tls_key_file
        ca_file = args.tls_ca_file
        trusted_ca = ca_file is None

        if args.cert_file is None:
            print("Cert file required for tls peer!")
            return
        
        if args.key_file is None:
            print("Key file required for tls peer!")
            return

        if not (os.path.exists(cert_file) and os.path.isfile(cert_file)):
            print(f"Cert file {cert_file} does not exists!")
            return
        
        if not (os.path.exists(key_file) and os.path.isfile(key_file)):
            print(f"Key file {key_file} does not exists!")
            return
        
        if (not trusted_ca) and not (os.path.exists(ca_file) and os.path.isfile(ca_file)):
            print(f"CA file {ca_file} does not exists!")
            return

        data["cert_file"] = cert_file
        data["key_file"] = key_file
        data["ca_file"] = ca_file
    else:
        data["tls"] = False

    config = get_app_config(args.app)
    
    mgr = DBManager(
        dbname=config.get("dbname"),
        dburl=config.get("dburl"),
        dbprovider=config.get("dbprovider"),
    )

    res = mgr.create_dicom_peer(data=data)
    print(f"DICOM peer added with id {res}")

def handle_edit(args):
    data = {
        "name": args.peer_name,
        "host": args.host,
        "port": args.port,
        "aet": args.aet,
    }

    edit_tls = args.tls or args.no_tls

    if edit_tls and args.tls:
        data["tls"] = True
        cert_file = args.tls_cert_file
        key_file = args.tls_key_file
        ca_file = args.tls_ca_file
        trusted_ca = ca_file is None

        if cert_file is None:
            print("Cert file required for tls peer!")
            return
        
        if key_file is None:
            print("Key file required for tls peer!")
            return

        if not (os.path.exists(cert_file) and os.path.isfile(cert_file)):
            print(f"Cert file {cert_file} does not exists!")
            return
        
        if not (os.path.exists(key_file) and os.path.isfile(key_file)):
            print(f"Key file {key_file} does not exists!")
            return
        
        if (not trusted_ca) and not (os.path.exists(ca_file) and os.path.isfile(ca_file)):
            print(f"CA file {ca_file} does not exists!")
            return

        data["cert_file"] = cert_file
        data["key_file"] = key_file
        data["ca_file"] = ca_file
    elif edit_tls and args.no_tls:
        data["tls"] = False

    update_data = {}

    for k in data:
        if not data[k] is None:
            update_data[k] = data[k]

    config = get_app_config(args.app)
    mgr = DBManager(
        dbname=config.get("dbname"),
        dburl=config.get("dburl"),
        dbprovider=config.get("dbprovider"),
    )

    # get existing object
    peer = mgr.get_dicom_peer(name=args.peer_name)

    if args.clear_aet:
        update_data["whitelist_aet"] = args.allowed_aets or []
    else:
        update_data["whitelist_aet"] = peer.get("whitelist_aet", []) + (args.allowed_aets or [])

    if args.clear_ip:
        update_data["whitelist_ip"] = args.allowed_ips or []
    else:
        update_data["whitelist_ip"] = peer.get("whitelist_aet", []) + (args.allowed_ips or [])
    

    res = mgr.update_dicom_peer(name=args.peer_name, data={"$set": update_data})
    print(f"Updated peer with id {res}")

def handle_remove(args):
    config = get_app_config(args.app)
    mgr = DBManager(
        dbname=config.get("dbname"),
        dburl=config.get("dburl"),
        dbprovider=config.get("dbprovider"),
    )

    res = mgr.remove_dicom_peer(name=args.peer_name)
    if not res is None:
        print(f"DICOM peer with id {res} removed!")

def handle_list(args):
    config = get_app_config(args.app)
    mgr = DBManager(
        dbname=config.get("dbname"),
        dburl=config.get("dburl"),
        dbprovider=config.get("dbprovider"),
    )

    items = mgr.find_dicom_peers()
    print(tabulate(items, headers="keys", tablefmt="grid"))

def handle_get(args):
    config = get_app_config(args.app)
    mgr = DBManager(
        dbname=config.get("dbname"),
        dburl=config.get("dburl"),
        dbprovider=config.get("dbprovider"),
    )

    item = mgr.get_dicom_peer(name=args.peer_name)
    if not item is None:
        print(DBManager.to_json(item, config.get("dbprovider")))