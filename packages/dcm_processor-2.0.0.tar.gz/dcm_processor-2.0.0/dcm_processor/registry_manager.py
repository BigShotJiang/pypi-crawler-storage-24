import argparse, json, os, re, shutil, tempfile
import getpass
from pathlib import Path

import requests

from .libs.config import set_registry_token, remove_registry_token, get_registry_token
from dcm_processor_utils import REGISTRY_API_URL, zip_directory, unzip_file

SUPPORTED_ARCHIVE_EXTENSIONS = (
    ".zip",
    ".tar",
    ".tar.gz",
    ".tgz",
    ".tar.bz2",
    ".tbz2",
)
SEMVER_PATTERN = re.compile(
    r"^(0|[1-9]\d*)\.(0|[1-9]\d*)\.(0|[1-9]\d*)"
    r"(?:-((?:0|[1-9]\d*|[0-9A-Za-z-]*[A-Za-z-][0-9A-Za-z-]*)"
    r"(?:\.(?:0|[1-9]\d*|[0-9A-Za-z-]*[A-Za-z-][0-9A-Za-z-]*))*))?"
    r"(?:\+([0-9A-Za-z-]+(?:\.[0-9A-Za-z-]+)*))?$"
)

def registry_args(parser: argparse.ArgumentParser):
    """Patch generate module command line args"""
    subparsers = parser.add_subparsers(dest="registry_action")
    subparsers.required = True

    login = subparsers.add_parser("login", help="Login to a registry")
    login.add_argument(
        "-r",
        "--registry",
        dest="registry",
        type=str,
        help="The URL of the registry defaults to 'https://dcm-processor.com' or to the env DCM_PROCESSOR_REGISTRY if available",
    )
    login.add_argument(
        "-u",
        "--username",
        dest="username",
        help="The username (email) in case of login",
    )
    login.add_argument(
        "-p",
        "--password",
        dest="password",
        help="The password for login. When omitted will prompted to enter manually"
    )

    logout = subparsers.add_parser("logout", help="Logout from a registry")
    logout.add_argument(
        "-r",
        "--registry",
        dest="registry",
        type=str,
        help="The URL of the registry defaults to 'https://dcm-processor.com' or to the env DCM_PROCESSOR_REGISTRY if available",
    )

    publish = subparsers.add_parser("publish", help="Publish a package archive to a registry")
    publish.add_argument(
        "file",
        type=str,
        help="Path to the package archive to publish",
    )
    publish.add_argument(
        "-r",
        "--registry",
        dest="registry",
        type=str,
        help="The URL of the registry defaults to 'https://dcm-processor.com' or to the env DCM_PROCESSOR_REGISTRY if available",
    )
    publish.add_argument(
        "--visibility",
        dest="visibility",
        choices=["public", "private"],
        help="Visibility to use when the package is created by this upload",
    )
    publish.add_argument(
        "-f",
        "--force-replace",
        dest="force_replace",
        action="store_true",
        help="Replace an existing version if it already exists",
    )

def handle_registry(args):
    action = args.registry_action

    if action == "login":
        return handle_registry_login(args)

    if action == "logout":
        return handle_registry_logout(args)

    if action == "publish":
        return handle_registry_publish(args)

    print(args)

def handle_registry_login(args):
    base_url = os.environ.get("DCM_PROCESSOR_REGISTRY", REGISTRY_API_URL)
    registry = str(args.registry or base_url).strip().rstrip("/")
    username = str(args.username or "").strip().lower()
    password = args.password

    if username == "":
        print("Username is required for registry login.", flush=True)
        return False

    if password is None:
        password = getpass.getpass("Registry password: ")

    if str(password).strip() == "":
        print("Password is required for registry login.", flush=True)
        return False

    try:
        response = requests.post(
            f"{registry}/api/login",
            json={
                "email": username,
                "password": password,
            },
            timeout=30,
        )
    except Exception as exc:
        print(f"Unable to contact registry: {exc}", flush=True)
        return False

    try:
        payload = response.json()
    except Exception:
        payload = {}

    if response.status_code != 200:
        message = payload.get("error") or payload.get("message") or f"Login failed with status {response.status_code}"
        print(message, flush=True)
        return False

    token = payload.get("token")
    if not token:
        print("Registry login succeeded but no token was returned.", flush=True)
        return False

    set_registry_token(registry, token)
    print(f"Logged in to {registry}", flush=True)
    return True

def handle_registry_logout(args):
    base_url = os.environ.get("DCM_PROCESSOR_REGISTRY", REGISTRY_API_URL)
    registry = str(args.registry or base_url).strip().rstrip("/")
    remove_registry_token(registry)
    print(f"Logged out from {registry}", flush=True)
    return True

def _is_registry_auth_failure(response, payload):
    if response.status_code not in (401, 403):
        return False

    message = str(payload.get("error") or payload.get("message") or "").strip().lower()
    auth_markers = (
        "missing or invalid bearer token",
        "not authenticated",
        "unauthorized",
        "forbidden",
        "token",
        "expired",
    )
    return any(marker in message for marker in auth_markers)

def _resolve_manifest_relative_path(manifest_dir: Path, relative_path: str):
    raw = str(relative_path or "").strip()
    if raw == "":
        return None

    target = (manifest_dir / raw).resolve()
    try:
        target.relative_to(manifest_dir.resolve())
    except ValueError:
        return None

    return target

def _find_manifest_file(root: Path):
    for candidate in root.rglob("dcm-processor.json"):
        return candidate
    return None

def _load_manifest(root: Path):
    manifest_path = _find_manifest_file(root)

    if manifest_path is None:
        raise RuntimeError("Package does not contain dcm-processor.json.")

    try:
        manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
    except Exception as exc:
        raise RuntimeError(f"Unable to read dcm-processor.json: {exc}") from exc

    if not isinstance(manifest, dict):
        raise RuntimeError("dcm-processor.json must contain a JSON object.")

    return manifest_path.resolve(), manifest

def _iter_relevant_publish_paths(source_root: Path):
    manifest_path, manifest = _load_manifest(source_root)
    manifest_dir = manifest_path.parent.resolve()
    source_root = source_root.resolve()
    selected = {manifest_path}

    for readme in manifest_dir.iterdir():
        if not readme.is_file():
            continue
        name = readme.name
        if name == "README.md" or (name.startswith("README_") and name.endswith(".md")):
            selected.add(readme.resolve())

    worker = manifest.get("worker")
    if isinstance(worker, dict):
        worker_path = _resolve_manifest_relative_path(manifest_dir, worker.get("path"))
        if worker_path is not None and worker_path.exists():
            selected.add(worker_path.resolve())

    service = manifest.get("service")
    if isinstance(service, dict):
        for field in ("registry", "module"):
            service_path = _resolve_manifest_relative_path(manifest_dir, service.get(field))
            if service_path is not None and service_path.exists():
                selected.add(service_path.resolve())

    return sorted(selected, key=lambda item: len(item.parts))

def _copy_selected_publish_paths(source_root: Path, staging_root: Path):
    for path in _iter_relevant_publish_paths(source_root):
        relative_path = path.relative_to(source_root)
        destination = staging_root / relative_path

        if path.is_dir():
            shutil.copytree(path, destination, dirs_exist_ok=True)
        else:
            destination.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(path, destination)

def _build_publish_archive_for_directory(source: Path, temp_dir: str):
    staging_dir = Path(temp_dir) / "publish-stage"
    staging_dir.mkdir(parents=True, exist_ok=True)
    _copy_selected_publish_paths(source, staging_dir)

    archive_name = f"{source.name}.zip"
    archive_path = Path(temp_dir) / archive_name
    return Path(zip_directory(str(staging_dir), str(archive_path)))

def _validate_package_root(root: Path):
    errors = []
    try:
        manifest_path, manifest = _load_manifest(root)
    except RuntimeError as exc:
        return [str(exc)]

    manifest_dir = manifest_path.parent.resolve()
    name = str(manifest.get("name") or "").strip()
    version = str(manifest.get("version") or "").strip()

    if name == "":
        errors.append("Manifest field 'name' is required.")

    if version == "":
        errors.append("Manifest field 'version' is required.")
    elif SEMVER_PATTERN.match(version) is None:
        errors.append("Manifest field 'version' must be a valid semantic version.")

    worker = manifest.get("worker")
    service = manifest.get("service")

    if worker is None and service is None:
        errors.append("Manifest must define at least one of 'worker' or 'service'.")

    if worker is not None:
        if not isinstance(worker, dict):
            errors.append("Manifest field 'worker' must be an object.")
        else:
            worker_path = str(worker.get("path") or "").strip()
            if worker_path == "":
                errors.append("Manifest field 'worker.path' is required when 'worker' is defined.")
            else:
                resolved_worker_path = _resolve_manifest_relative_path(manifest_dir, worker_path)
                if resolved_worker_path is None or not resolved_worker_path.exists():
                    errors.append(f"Worker path '{worker_path}' does not exist relative to dcm-processor.json.")

    if service is not None:
        if not isinstance(service, dict):
            errors.append("Manifest field 'service' must be an object.")
        else:
            registry_path = str(service.get("registry") or "").strip()
            module_path = str(service.get("module") or "").strip()
            jobs = service.get("jobs")

            if registry_path == "":
                errors.append("Manifest field 'service.registry' is required when 'service' is defined.")
            else:
                resolved_registry_path = _resolve_manifest_relative_path(manifest_dir, registry_path)
                if resolved_registry_path is None or not resolved_registry_path.exists():
                    errors.append(f"Service registry path '{registry_path}' does not exist relative to dcm-processor.json.")
                elif not resolved_registry_path.is_dir():
                    errors.append(f"Service registry path '{registry_path}' must be a directory.")
                elif not resolved_registry_path.joinpath("__init__.py").is_file():
                    errors.append(f"Service registry path '{registry_path}' must contain __init__.py.")

            if module_path == "":
                errors.append("Manifest field 'service.module' is required when 'service' is defined.")
            else:
                resolved_module_path = _resolve_manifest_relative_path(manifest_dir, module_path)
                if resolved_module_path is None or not resolved_module_path.exists():
                    errors.append(f"Service module path '{module_path}' does not exist relative to dcm-processor.json.")
                elif not resolved_module_path.is_dir():
                    errors.append(f"Service module path '{module_path}' must be a directory.")
                elif not resolved_module_path.joinpath("__init__.py").is_file():
                    errors.append(f"Service module path '{module_path}' must contain __init__.py.")

            if not isinstance(jobs, list) or len(jobs) == 0:
                errors.append("Manifest field 'service.jobs' must contain at least one job.")
            else:
                required_job_fields = ("jobName", "workerEntry", "registryEntry", "events")
                for index, job in enumerate(jobs, start=1):
                    if not isinstance(job, dict):
                        errors.append(f"Service job #{index} must be an object.")
                        continue

                    for field in required_job_fields:
                        value = job.get(field)
                        if field == "events":
                            if not isinstance(value, list) or len(value) == 0:
                                errors.append(f"Service job #{index} must define a non-empty '{field}' list.")
                        else:
                            if str(value or "").strip() == "":
                                errors.append(f"Service job #{index} must define '{field}'.")

    return errors

def _validate_publish_source(source: Path):
    if source.is_dir():
        return _validate_package_root(source)

    with tempfile.TemporaryDirectory() as temp_dir:
        extract_dir = Path(temp_dir) / "extracted"
        if not unzip_file(source, extract_dir):
            return [f"Unable to extract archive '{source.name}'."]
        return _validate_package_root(extract_dir)

def handle_registry_publish(args):
    base_url = os.environ.get("DCM_PROCESSOR_REGISTRY", REGISTRY_API_URL)
    registry = str(args.registry or base_url).strip().rstrip("/")
    token = get_registry_token(registry)

    if not token:
        print(
            f"No registry login found for {registry}. Run 'dcm-processor registry login -r {registry}' first.",
            flush=True,
        )
        return False

    source = Path(str(args.file)).expanduser().resolve()
    if not source.exists():
        print(f"Path '{source}' does not exist.", flush=True)
        return False

    if source.is_file():
        source_name = source.name.lower()
        if not source_name.endswith(SUPPORTED_ARCHIVE_EXTENSIONS):
            supported = ", ".join(SUPPORTED_ARCHIVE_EXTENSIONS)
            print(
                f"Unsupported archive format for '{source}'. Supported formats: {supported}",
                flush=True,
            )
            return False

    validation_errors = _validate_publish_source(source)
    if validation_errors:
        print("Package validation failed:", flush=True)
        for error in validation_errors:
            print(f"- {error}", flush=True)
        return False

    headers = {
        "Authorization": f"Bearer {token}",
    }

    def perform_upload(archive_path: Path):
        data = {}
        if args.visibility:
            data["visibility"] = args.visibility
        if args.force_replace:
            data["force_replace"] = "1"

        with archive_path.open("rb") as archive_handle:
            files = {
                "archive": (archive_path.name, archive_handle),
            }
            response = requests.post(
                f"{registry}/api/releases",
                headers=headers,
                data=data,
                files=files,
                timeout=120,
            )
        return response

    try:
        if source.is_dir():
            with tempfile.TemporaryDirectory() as temp_dir:
                archive_path = _build_publish_archive_for_directory(source, temp_dir)
                response = perform_upload(archive_path)
        else:
            response = perform_upload(source)
    except Exception as exc:
        print(f"Unable to publish package: {exc}", flush=True)
        return False

    try:
        payload = response.json()
    except Exception:
        payload = {}

    if _is_registry_auth_failure(response, payload):
        remove_registry_token(registry)
        print(
            f"Your registry login for {registry} is missing, invalid, or expired. "
            f"Stored token removed. Run 'dcm-processor registry login -r {registry}' first.",
            flush=True,
        )
        return False

    if response.status_code not in (200, 201):
        message = payload.get("error") or payload.get("message") or f"Publish failed with status {response.status_code}"
        print(message, flush=True)
        return False

    message = payload.get("message", "Release uploaded")
    package = (((payload.get("data") or {}).get("package")) or "")
    version = (((payload.get("data") or {}).get("version")) or "")

    if package and version:
        print(f"{message}: {package} {version}", flush=True)
    else:
        print(message, flush=True)

    return True
