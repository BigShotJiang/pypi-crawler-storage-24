import sqlite3, os
from pathlib import Path
from dcm_processor_db_provider import DBManager
from dcm_processor_utils import get_device_id as get_dev_id
from dcm_processor_utils import SETTINGS

APPS_DB_FILENAME = "config.db"
APPS_SUBDIR = "apps"
WORKERS_SUBDIR = "workers"
REGISTRY_SUBDIR = "registry"
MODULES_SUBDIR = "modules"

def get_config_folder():
    #  Check env var
    env_path = os.environ.get('DCM_PROCESSOR_CONFIG_DIR')
    if not env_path is None:
        if os.path.isdir(env_path):
            return os.path.abspath(os.path.expandvars(os.path.expanduser(env_path)))
    
    # Return defaul .dcm-processor path
    return os.path.abspath(os.path.expandvars(os.path.expanduser(os.path.join(Path.home().expanduser().absolute(),".dcm-processor"))))

def get_db_path():
    config_folder = get_config_folder()
    db_path = os.path.join(config_folder, APPS_DB_FILENAME)
    return db_path

def get_db_connection():
    conn = sqlite3.connect(
        get_db_path(),
        timeout=10,
        check_same_thread=False
    )
    conn.row_factory = sqlite3.Row
    return conn

def initialize_config_db():

    config_folder = get_config_folder()
    os.makedirs(config_folder, exist_ok=True)

    conn = get_db_connection()
    cursor = conn.cursor()

    try:

        cursor.execute("""
        CREATE TABLE IF NOT EXISTS applications (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT UNIQUE,
            dbprovider TEXT NOT NULL,
            dburl TEXT NOT NULL,
            dbname TEXT NOT NULL
        )
        """)

        # TODO: Create users table and verify users for admin commands

        cursor.execute("""
        CREATE TABLE IF NOT EXISTS settings (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT UNIQUE,
            value_type TEXT NOT NULL,
            value TEXT
        )
        """)

        conn.commit()
    except Exception as exc:
        print(f"Error initializing database: {exc}")
    
    finally:
        cursor.close()
        conn.close()

def insert_app(app: dict):
    initialize_config_db()

    conn = get_db_connection()
    cursor = conn.cursor()
    last_id = None

    try:
        cursor.execute(
            "INSERT INTO applications (name, dbprovider, dburl, dbname) VALUES (?, ?, ?, ?)",
            (app.get("name"), app.get("dbprovider"), app.get("dburl"), app.get("dbname"))
        )

        last_id = cursor.lastrowid
        conn.commit()

        default_app = get_settings(SETTINGS.DEFAULT_APP.value, conn)
        if default_app is None:
            set_settings(SETTINGS.DEFAULT_APP.value, app.get("name"), conn)

    except Exception as ex:
        print(f"Error: {ex}")
        last_id = None

    finally:
        cursor.close()
        conn.close()

    if not last_id is None:
        # create initial dirs
        config_dir = get_config_folder()
        app_dir = os.path.join(config_dir, APPS_SUBDIR, app.get("name"))
        workers_dir = os.path.join(app_dir, WORKERS_SUBDIR)
        modules_dir = os.path.join(app_dir, MODULES_SUBDIR)
        registry_dir = os.path.join(app_dir, REGISTRY_SUBDIR)

        os.makedirs(app_dir, exist_ok=True)
        os.makedirs(workers_dir, exist_ok=True)
        os.makedirs(modules_dir, exist_ok=True)
        os.makedirs(registry_dir, exist_ok=True)

    return last_id

def update_app(name, key, value):
    initialize_config_db()

    conn = get_db_connection()
    cursor = conn.cursor()
    last_id = None

    try:
        cursor.execute(
            f"UPDATE applications SET {key} = ? WHERE name = ?",
            (value, name)
        )

        last_id = cursor.lastrowid
        conn.commit()

    except Exception as ex:
        print(f"Error: {ex}")
        last_id = None

    finally:
        cursor.close()
        conn.close()

    return last_id

def remove_app(app_name):
    initialize_config_db()

    conn = get_db_connection()
    cursor = conn.cursor()
    last_id = None

    get_settings("default_app", conn)

    try:
        cursor.execute(
            "DELETE FROM applications WHERE name = ?", (app_name,)
        )

        last_id = cursor.lastrowid
        conn.commit()

        cursor.execute("SELECT * FROM applications ORDER BY id DESC LIMIT 1")
        app = cursor.fetchone()

        if app:
            app = dict(app)
            set_settings(SETTINGS.DEFAULT_APP.value, app.get("name"), conn)
        else:
            unset_settings(SETTINGS.DEFAULT_APP.value, conn)

    except Exception as ex:
        print(f"Error: {ex}")
        last_id = None

    finally:
        cursor.close()
        conn.close()

    return last_id

def get_app_config(app_name=None):
    initialize_config_db()

    if app_name is None:
        app_name = get_default_app()

    conn = get_db_connection()
    cursor = conn.cursor()
    app = None

    try:

        cursor.execute("SELECT * FROM applications WHERE name = ? ORDER BY id DESC LIMIT 1", (app_name,))
        app = cursor.fetchone()

        if app:
            app = dict(app)

    except Exception as ex:
        print(f"Error: {ex}")

    finally:
        cursor.close()
        conn.close()

    return app

def get_all_apps():
    initialize_config_db()

    conn = get_db_connection()
    cursor = conn.cursor()
    items = []

    try:

        cursor.execute("SELECT * FROM applications ORDER BY id DESC")
        apps = cursor.fetchall()
        items = []
        for app in apps:
            items.append(dict(app))

    except Exception as ex:
        print(f"Error: {ex}")

    finally:
        cursor.close()
        conn.close()

    return items

def get_settings(name, existing_conn=None):
    conn = existing_conn or get_db_connection()
    value = None

    try:
        cursor = conn.cursor()

        cursor.execute("SELECT * FROM settings WHERE name=?", (name, ))
        data = cursor.fetchone()

        if not data is None:
            data = dict(data)
            value = data.get("value")
            value_type = data.get("value_type", "text")
            if not value is None:
                try:
                    if value_type == "int":
                        value = int(value)
                    if value_type == "bool":
                        value = bool(value)
                    if value_type == "float":
                        value = float(value)
                except Exception as ex:
                    print(ex)
            
            return value
    except Exception as exc:
        print(exc)
    finally:
        cursor.close()
        if existing_conn is None:
            conn.close()
    
    return value

def get_all_settings(existing_conn=None):
    conn = existing_conn or get_db_connection()
    items = []

    try:
        cursor = conn.cursor()

        cursor.execute("SELECT * FROM settings")
        res = cursor.fetchall()

        for item in res:
            data = dict(item)
            value = data.get("value")
            value_type = data.get("value_type", "text")
            if not value is None:
                try:
                    if value_type == "int":
                        value = int(value)
                    if value_type == "bool":
                        value = bool(value)
                    if value_type == "float":
                        value = float(value)
                except Exception as ex:
                    print(ex)

            items.append({"name": data.get("name"), "value": value})
    except Exception as exc:
        print(exc)
    finally:
        cursor.close()
        if existing_conn is None:
            conn.close()
    
    return items

def has_settings(name, existing_conn=None):
    """
    Check if a setting exists in the database.

    :param name: The name of the setting to check.
    :param existing_conn: Optional existing DB connection to reuse.
    :return: True if the setting exists, False otherwise.
    """
    conn = existing_conn or get_db_connection()
    exists = False

    try:
        cursor = conn.cursor()
        cursor.execute("SELECT 1 FROM settings WHERE name=? LIMIT 1", (name,))
        data = cursor.fetchone()
        exists = data is not None
    except Exception as exc:
        print(exc)
    finally:
        cursor.close()
        if existing_conn is None:
            conn.close()

    return exists

def set_settings(name, value, existing_conn=None):
    v_type = "text"
    
    if type(value) == int:
        v_type = "int"

    if type(value) == bool:
        v_type = "bool"

    if type(value) == float:
        v_type = "float"
    
    conv_value = str(value)

    conn = existing_conn or get_db_connection()
    cursor = conn.cursor()
    last_id = None

    try:

        cursor.execute("""
            INSERT INTO settings (name, value_type, value)
            VALUES (?, ?, ?)
            ON CONFLICT(name) DO UPDATE SET
                value_type=excluded.value_type, value=excluded.value
            """,
            (name, v_type, conv_value)
        )

        last_id = cursor.lastrowid
        conn.commit()

        # Check if default application is not set and set it.

    except Exception as ex:
        print(f"Error: {ex}")
        last_id = None

    finally:
        cursor.close()
        if existing_conn is None:
            conn.close()

    return last_id

def unset_settings(name, existing_conn=None):
    conn = existing_conn or get_db_connection()
    cursor = conn.cursor()
    last_id = None

    try:

        cursor.execute(" DELETE FROM settings WHERE name = ?", (name,))
        conn.commit()
        last_id = cursor.lastrowid
        # Check if default application is not set and set it.

    except Exception as ex:
        print(f"Error: {ex}")

    finally:
        cursor.close()
        if existing_conn is None:
            conn.close()

    return last_id

def get_default_app():
    return get_settings(SETTINGS.DEFAULT_APP.value)

def get_device_id():
    if has_settings(SETTINGS.DEVICE_ID.value):
        return get_settings(SETTINGS.DEVICE_ID.value)
    else:
        device_id = get_dev_id()
        set_settings(SETTINGS.DEVICE_ID.value, device_id)
        return device_id

def get_app_db_mgr(app_name: str|None = None) -> DBManager:
    app = get_app_config(app_name)
    db_mgr = DBManager(**app)
    return db_mgr

def get_component_path(name: str, dirname: str) -> str:
    new_path = os.path.join(dirname, name)
    return str(Path(new_path).resolve())

def get_app_subdirs(name=None):
    config_dir = get_config_folder()

    if name is None:
        name = get_default_app()

    app_dir = os.path.join(config_dir, APPS_SUBDIR, name)

    workers_dir = os.path.join(app_dir, WORKERS_SUBDIR)
    modules_dir = os.path.join(app_dir, MODULES_SUBDIR)
    registry_dir = os.path.join(app_dir, REGISTRY_SUBDIR)

    return {
        "app": app_dir,
        "workers": workers_dir,
        "modules": modules_dir,
        "registry": registry_dir
    }

def set_registry_token(registry, token):
    registry_key = str(registry).strip().rstrip("/")
    setting_name = f"registry_token:{registry_key}"
    return set_settings(setting_name, token)

def get_registry_token(registry):
    registry_key = str(registry).strip().rstrip("/")
    setting_name = f"registry_token:{registry_key}"
    return get_settings(setting_name)

def remove_registry_token(registry):
    registry_key = str(registry).strip().rstrip("/")
    setting_name = f"registry_token:{registry_key}"
    return unset_settings(setting_name)
