from .downloaders import (
    classify_path, download_and_extract_web_path,
    find_dcm_processor_json, split_version_expr,
    zip_directory_to_bytesio, unzip_file, is_path
)

import tempfile, os, json, shutil
from pathlib import Path
from urllib.parse import urljoin

import requests
from dcm_processor_worker import WorkerManager
from .config import get_device_id, get_registry_token
from dcm_processor_db_provider import DBManager
from dcm_processor_utils import REGISTRY_API_URL


class CompManager:

    def __init__(self, dburl, dbname, dbprovider, registry=None, **kwargs):
        self.dburl = dburl
        self.dbname = dbname
        self.dbprovider = str(dbprovider).strip().lower()
        self.dbMgr = DBManager(dburl, dbname, dbprovider)
        self.registry = registry

    def __registry_base_url(self):
        base_url = self.registry or os.environ.get("DCM_PROCESSOR_REGISTRY", REGISTRY_API_URL)
        return str(base_url).strip().rstrip("/")

    def __try_registry_install(self, file, temp_dir, service_only=False, worker_only=False, force=False, worker_dir=None, service_dir=None):
        file_path = self.__handle_registry_file(file, temp_dir)

        if file_path is None:
            return False

        self.__install_from_path(
            comp_path=file_path,
            service_only=service_only,
            worker_only=worker_only,
            force=force,
            worker_dir=worker_dir,
            service_dir=service_dir,
        )
        return True

    def __handle_worker_install(self, comp_path, settings, force=False, worker_dir=None):
        name = settings.get("name")
        version = settings.get("version")
        exists = self.dbMgr.worker_exists(name)
    
        if exists:
            if force:
                wk = self.dbMgr.get_worker(name)
                
                files = WorkerManager.remove_worker(
                    settings=wk,
                    wtype=wk.get("type"),
                    worker_dir=worker_dir
                )

                self.dbMgr.remove_worker_by_id(
                    worker_id=wk.get("_id"),
                    comp_file_fields=None if files is None else list((f"worker_files.{fn}" for fn in files))
                )
            else:
                return True
        
        worker_info = settings.get("worker", {})
        worker_info["name"] = name
        worker_info["version"] = version

        wpath = worker_info.get("path")
        wtype = worker_info.get("type")

        full_path = os.path.join(comp_path, wpath)

        worker_dict, worker_files = WorkerManager.install_worker(
            settings=worker_info,
            dirname=full_path,
            wtype=wtype,
            worker_dir=worker_dir,
            force=force
        )

        worker_files_saved = {}

        if not worker_files is None:
            for k in worker_files:
                wk_file_path = worker_files[k]
                worker_files_saved[k] = self.dbMgr.upload_component_file(
                    file=wk_file_path,
                    metadata={
                        "name": name,
                        "version": version,
                        "type": "worker_file",
                    }
                )

        if worker_dict is None:
            worker_dict = {}

        worker_dict["name"] = name
        worker_dict["version"] = version
        worker_dict["type"] = wtype
        worker_dict["device_id"] = get_device_id()
        worker_dict["worker_files"] = worker_files_saved

        return self.dbMgr.create_worker(worker_dict)

    def __handle_service_install(self, comp_path, settings, force=False, service_dir=None):

        name = settings.get("name")

        exists = self.dbMgr.service_exists(name)
        if exists:
            if force:
                self.dbMgr.remove_service(
                    service_name=name,
                    comp_file_fields=["module", "registry"]
                )
            else:
                return True

        sett = settings.get("service", {})
        requirements = {}

        required_services = sett.get("required_services", [])
        required_workers = sett.get("required_workers", [])

        for req in required_services:
            # check if exists in services
            req_exp = split_version_expr(req)
            exists = self.dbMgr.service_exists(req_exp[0])
            if not exists:
                requirements[req_exp[0]] = {"s": True, "w": False, "file": req}
        
        for req in required_workers:
            req_exp = split_version_expr(req)
            # check if exists in workers
            exists = self.dbMgr.worker_exists(req_exp[0])
            if not exists:
                if req_exp[0] in requirements:
                    requirements[req_exp[0]]["w"] = True
                else:
                    requirements[req_exp[0]] = {"w": True, "s": False, "file": req}

        for req in requirements:
            if requirements[req]["w"] and requirements[req]["s"]:
                res = self.__handle_file(requirements[req]["file"])
            elif requirements[req]["s"]:
                res = self.__handle_file(requirements[req]["file"], service_only=True)
            elif requirements[req]["w"]:
                res = self.__handle_file(requirements[req]["file"], worker_only=True)
        
        module = sett.get("module")
        registry = sett.get("registry")

        if (module is None) or (registry is None):
            print("registry and module fields are required for service definition!")
            return False
        
        module_path = os.path.join(comp_path, module)
        registry_path = os.path.join(comp_path, registry)

        if (not os.path.exists(module_path)) or (not os.path.isdir(module_path)):
            print(f"Wrong module path '{module_path}' for service '{name}'")
            return False

        if (not os.path.exists(registry_path)) or (not os.path.isdir(registry_path)):
            print(f"Wrong registry path '{module_path}' for service '{name}'")
            return False

        module_file_id = self.dbMgr.upload_component_file(
            file=zip_directory_to_bytesio(module_path),
            metadata={
                "name": name,
                "version": settings.get("version"),
                "type": "service_module",
            }
        )

        registry_file_id = self.dbMgr.upload_component_file(
            file=zip_directory_to_bytesio(registry_path),
            metadata={
                "name": name,
                "version": settings.get("version"),
                "type": "service_registry",
            }
        )

        service_payload = {
            "name": name,
            "version": settings.get("version"),
            "jobs": sett.get("jobs", []),
            "module": module_file_id,
            "registry": registry_file_id
        }

        res = self.dbMgr.create_service(service_payload)

        return not res is None

    def __install_from_path(self, comp_path, service_only=False, worker_only=False, force=False, worker_dir=None, service_dir=None):

        if not os.path.exists(comp_path):
            print(f"File or dir {comp_path} does not exists!")
            return
        
        elif os.path.isdir(comp_path):
            dcm_proc_json = find_dcm_processor_json(comp_path)

            if dcm_proc_json is None:
                print(f"Component does not have 'dcm-processor.json' file")
                return
            
            settings = {}
            with open(dcm_proc_json.resolve(), 'r') as f:
                settings = json.load(f)

            name = settings.get("name")
            version = settings.get("version")
            if name is None:
                print(f"name field missing in dcm-processor.json file.", flush=True)
            
            if version is None:
                print(f"version field missing in dcm-processor.json file.", flush=True)

            worker = settings.get("worker")
            if (not worker is None) and (not service_only):
                self.__handle_worker_install(
                    comp_path=dcm_proc_json.parent,
                    settings=settings,
                    force=force,
                    worker_dir=worker_dir
                )

            service = settings.get("service")
            if (not service is None) and (not worker_only):
                self.__handle_service_install(
                    comp_path=dcm_proc_json.parent,
                    settings=settings,
                    force=force,
                    service_dir=service_dir,
                )

        elif os.path.isfile(comp_path):
            output_dir = Path(comp_path).parent.joinpath('extracted_output')
            if unzip_file(comp_path, output_dir):
                return self.__install_from_path(
                    comp_path=output_dir,
                    service_only=service_only,
                    worker_only=worker_only,
                    force=force,
                    worker_dir=worker_dir,
                    service_dir=service_dir,
                )
            else:
                print(f"Wrong file format for installing component!")
                return

    def __handle_registry_file(self, file, temp_dir):
        base_url = self.__registry_base_url()
        query_url = f"{base_url}/api/package-query"
        headers = {}
        bearer_token = get_registry_token(base_url)

        if bearer_token:
            headers["Authorization"] = f"Bearer {bearer_token}"

        try:
            response = requests.get(
                query_url,
                params={"q": file},
                headers=headers or None,
                timeout=30,
            )
            response.raise_for_status()
            payload = response.json()
        except Exception as exc:
            print(f"Unable to query registry for '{file}': {exc}", flush=True)
            return None

        if not payload.get("success", False):
            message = payload.get("message", "Registry query failed")
            print(message, flush=True)
            return None

        download_url = payload.get("download_url")
        if not download_url:
            print("Registry response does not include a download URL.", flush=True)
            return None

        download_url = urljoin(f"{base_url}/", str(download_url))

        return download_and_extract_web_path(
            url=download_url,
            temp_dir=temp_dir,
            bearer_token=bearer_token,
        )

    def __handle_file(self, file, service_only=False, worker_only=False, force=False, worker_dir=None, service_dir=None):
        file = str(file).strip()
        info = classify_path(file)

        if info is None:
            with tempfile.TemporaryDirectory() as temp_dir:
                if not self.__try_registry_install(
                    file=file,
                    temp_dir=temp_dir,
                    service_only=service_only,
                    worker_only=worker_only,
                    force=force,
                    worker_dir=worker_dir,
                    service_dir=service_dir,
                ):
                    return False
        else:
            file_type = info.get("type")

            if file_type == "local":

                if not info.get('exists', False):
                    if not is_path(file):
                        with tempfile.TemporaryDirectory() as temp_dir:
                            if self.__try_registry_install(
                                file=file,
                                temp_dir=temp_dir,
                                service_only=service_only,
                                worker_only=worker_only,
                                force=force,
                                worker_dir=worker_dir,
                                service_dir=service_dir,
                            ):
                                return True
                    print(f"Path {file} does not exist!", flush=True)
                    return False
                
                with tempfile.TemporaryDirectory() as temp_dir:
                    if os.path.isdir(file):
                        dest = shutil.copytree(file, os.path.join(temp_dir, 'component'))
                        self.__install_from_path(
                            comp_path=dest,
                            service_only=service_only,
                            worker_only=worker_only,
                            force=force,
                            worker_dir=worker_dir,
                            service_dir=service_dir
                        )
                    elif os.path.isfile(file):
                        filename = os.path.join(temp_dir, Path(file).name)
                        shutil.copy2(file, filename)
                        self.__install_from_path(
                            comp_path=filename,
                            service_only=service_only,
                            worker_only=worker_only,
                            force=force,
                            worker_dir=worker_dir,
                            service_dir=service_dir
                        )

            if file_type == "web":
                
                with tempfile.TemporaryDirectory() as temp_dir:
                    file_path = download_and_extract_web_path(file, temp_dir)
                    
                    if file_path is None:
                        print(f"Unable to download/clone file from {file}!", flush=True)
                        return False
                    
                    self.__install_from_path(
                        comp_path=file_path,
                        service_only=service_only,
                        worker_only=worker_only,
                        force=force,
                        worker_dir=worker_dir,
                        service_dir=service_dir
                    )
    
    def __handle_name_uninstall(self, name, service_only=False, worker_only=False, worker_dir=None, service_dir=None):
        if not worker_only:
            # handle service
            self.dbMgr.remove_service(
                service_name=name,
                comp_file_fields=["module", "registry"]
            )

        if not service_only:
            # handle worker
            wk = self.dbMgr.get_worker(name)
            
            if wk is None:
                return
            
            files = WorkerManager.remove_worker(
                settings=wk,
                wtype=wk.get("type"),
                worker_dir=worker_dir
            )

            self.dbMgr.remove_worker_by_id(
                worker_id=wk.get("_id"),
                comp_file_fields=None if files is None else list((f"worker_files.{fn}" for fn in files))
            )

    def uninstall_module(self, **kwargs):
        names = kwargs.get("name", [])

        for name in names:
            self.__handle_name_uninstall(
                name=name,
                service_dir=kwargs.get("app_service_dir"),
                worker_dir=kwargs.get("app_worker_dir"),
                service_only=kwargs.get("service_only", False),
                worker_only=kwargs.get("worker_only", False),
            )

    def install_module(self, **kwargs):
        files = list(kwargs.get("file", []) or [])
        requirements_file = kwargs.get("requirements")

        if requirements_file:
            requirement_path = Path(str(requirements_file)).expanduser().resolve()

            if not requirement_path.exists() or not requirement_path.is_file():
                print(f"Requirements file '{requirement_path}' does not exist!", flush=True)
                return False

            try:
                for line in requirement_path.read_text(encoding="utf-8").splitlines():
                    entry = line.strip()
                    if entry == "" or entry.startswith("#"):
                        continue
                    files.append(entry)
            except Exception as exc:
                print(f"Unable to read requirements file '{requirement_path}': {exc}", flush=True)
                return False

        for file in files:
            self.__handle_file(
                file=file,
                service_dir=kwargs.get("app_service_dir"),
                worker_dir=kwargs.get("app_worker_dir"),
                service_only=kwargs.get("service_only", False),
                worker_only=kwargs.get("worker_only", False),
                force=kwargs.get("force", False)
            )

        return True
