import json, tomlkit
from datetime import datetime

def parse_datetime(value: str):
    # Base date formats
    date_formats = ["%Y-%m-%d", "%d.%m.%Y", "%Y/%m/%d"]
    # Extend with time versions
    time_formats = ["%H:%M", "%H:%M:%S"]

    # Generate all combinations
    formats = []
    for d in date_formats:
        formats.append(d)  # just date
        for t in time_formats:
            formats.append(f"{d} {t}")  # date + time

    for fmt in formats:
        try:
            return datetime.strptime(value, fmt)
        except ValueError:
            continue

    raise ValueError(f"Invalid date/time format: {value}")

def parse_toml(value: str):
    # Wrap inside a fake TOML section
    value = value.strip()

    if not (value.startswith('{') or value.startswith('[')):
        value = "{" + value + "}"

    toml_text = f"data = {value}"
    parsed = dict(tomlkit.parse(toml_text))
    return parsed["data"]

def parse_json(value: str):
    try:
        return parse_toml(value)
    except Exception as ex:
        print(f"Error in toml: {ex}")
        return json.loads(value)

TYPE_MAP = {
    "str": str,
    "int": int,
    "float": float,
    "json": parse_json,
    "date": parse_datetime,
    "bool": lambda x: x.lower() in ["true", "1", "yes"],
}
