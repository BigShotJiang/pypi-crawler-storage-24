import psutil, pathlib
import sys, time, os, logging, threading, multiprocessing
from dcm_processor_dicom_server import DicomServer
from dcm_processor_job_scheduler import JobScheduler
from dcm_processor_db_provider import DBManager
from .config import get_device_id, get_app_subdirs, get_app_config
from mqas import main as worker_process


class WorkerWrapper:
    def __init__(self, mongo_url, mongo_dbname, mongo_colname=None, channels=None):
        self.mongo_url = mongo_url
        self.mongo_dbname = mongo_dbname
        self.mongo_colname = mongo_colname or "jobs"
        self.jobs_channel = channels or [get_device_id()]
        self.subprocess = None

    def start(self):

        if isinstance(self.jobs_channel, list):
            cmd_args = (
                ["worker"]
                + self.jobs_channel
                + [
                    f"--conn={self.mongo_url}",
                    f"--dbname={self.mongo_dbname}",
                    f"--colname={self.mongo_colname}",
                    "--logger=dcm_processor_worker.logger",
                    "--verbosity=errorcompletedprogress",
                    "--no-sub-process",
                ]
            )
        else:
            cmd_args = [
                "worker",
                self.jobs_channel,
                f"--conn={self.mongo_url}",
                f"--dbname={self.mongo_dbname}",
                f"--colname={self.mongo_colname}",
                "--logger=dcm_processor_worker.logger",
                "--verbosity=errorcompletedprogress",
                "--no-sub-process",
            ]

        worker_process(cmd_args)

    def start_in_background(self):
        """Start dicom server application in the background"""
        if not self.subprocess is None:
            if self.subprocess.is_alive():
                self.subprocess.join()
            self.subprocess = None

        self.subprocess = threading.Thread(target=self.start, args=(), daemon=True)
        self.subprocess.start()

    def stop(self):
        """Stop dicom server application"""
        if not self.subprocess is None:
            if self.subprocess.is_alive():
                self.subprocess.join()

        self.subprocess = None

class AppRunnerBase:
    def __init__(self, app_name, num_workers=None):
        self.app_name = app_name
        self.num_workers = max(1, num_workers or 1)
        self.config = get_app_config(app_name=app_name)
        self.app_dirs = get_app_subdirs(name=app_name)
        base_app_dir = self.app_dirs.get("app")
        self.pid_file = os.path.join(base_app_dir, ".process.pid")
        self.log_file = os.path.join(base_app_dir, "logs.txt")
        pathlib.Path(base_app_dir).mkdir(parents=True, exist_ok=True)

        self.running = False
        self.dicom_servers = ()
        self.schedulers = ()
        self.workers = ()
        self.logger = None

    def configure_logger(self):
        if self.logger is None:
            logger = logging.getLogger(self.app_name)
            logger.setLevel(logging.INFO)

            fh = logging.FileHandler(self.log_file)
            fh.setFormatter(logging.Formatter("%(asctime)s [%(levelname)s] %(name)s: %(message)s"))
            logger.addHandler(fh)
            logger.propagate = False
            self.logger = logger

    def __start_services(self):

        if self.config is None:
            print(f"Cannot start application, application with name {self.app_name} does not exist!")
            return
        
        mgr = DBManager(
            dburl=self.config.get("dburl"),
            dbname=self.config.get("dbname"),
            dbprovider=self.config.get("dbprovider")
        )

        # Start scheduler
        scheduler = JobScheduler(
            dburl=self.config.get("dburl"),
            dbname=self.config.get("dbname"),
            dbprovider=self.config.get("dbprovider"),
            device_id=get_device_id()
        )

        scheduler.start_in_background()
        self.schedulers += (scheduler,)

        # Load dicom nodes and start them
        nodes = mgr.find_dicom_nodes(query={"device_id": get_device_id()})

        for node in nodes:
            node_kwargs = dict(
                ae_title=node.get("aet"),
                dburl=self.config.get("dburl"),
                dbname=self.config.get("dbname"),
                dbprovider=self.config.get("dbprovider"),
                max_pdu_size=node.get("pdu")
            )
            if node.get("tls"):
                node_kwargs["enable_tls"] = True
                node_kwargs["tls_cert_file"] = node.get("cert_file")
                node_kwargs["tls_key_file"] = node.get("key_file")
                node_kwargs["tls_ca_file"] = node.get("ca_file")
                node_kwargs["tls_trusted_ca"] = node.get("ca_file") is None

            server = DicomServer(**node_kwargs)
            server.start_in_background(host=node.get("host"), port=node.get("port"))
            self.dicom_servers += (server,)       

        # Start workers
        for i in range(self.num_workers):
            worker = WorkerWrapper(
                mongo_url=self.config.get("dburl"),
                mongo_dbname=self.config.get("dbname"),
                mongo_colname="jobs",
                channels=[get_device_id()]
            )

            worker.start_in_background()

            self.workers += (worker,)

    def __stop_services(self):
        print("Stop services called!")
        for worker in self.workers:
            worker.stop()

        for server in self.dicom_servers:
            server.stop()

        for scheduler in self.schedulers:
            scheduler.stop()

    def processing_loop(self):
        self.running = True

        self.__start_services()

        while self.running:
            # Replace this with your actual processing code
            time.sleep(1)

        self.__stop_services()

    # ------------------ Restart ------------------
    def restart(self):
        self.stop()
        time.sleep(1)
        self.start()

    # ------------------ Status ------------------
    def status(self):
        if not os.path.exists(self.pid_file):
            print(f"Application '{self.app_name}' is not running")
            return

        with open(self.pid_file) as f:
            pid = int(f.read())

        try:
            p = psutil.Process(pid)
            if p.is_running() and p.status() != psutil.STATUS_ZOMBIE:  # Check if process exists
                print(f"Application '{self.app_name}' running with PID {pid}")
            elif p.is_running():
                print(f"Application '{self.app_name}' running as ZOMBIE with PID {pid}")
            else:
                print(f"Application '{self.app_name}' is not running")
        except (psutil.NoSuchProcess, psutil.TimeoutExpired):
            print(f"Process not found or already terminated")
            if os.path.exists(self.pid_file):
                os.remove(self.pid_file)
        except ProcessLookupError:
            print(f"PID file exists for '{self.app_name}' but process not found")
            if os.path.exists(self.pid_file):
                os.remove(self.pid_file)

class AppRunner(AppRunnerBase):
    def __init__(self, app_name, num_workers=None):
        super().__init__(app_name, num_workers)
        self.process = None

    # ------------------ Start ------------------
    def start(self):
        if os.path.exists(self.pid_file):
            print(f"Application already running with PID file {self.pid_file}")
            return

        # Start a detached background process
        self.process = multiprocessing.Process(target=self.__run_child, daemon=False)
        self.process.start()
        print(f"Sarted application '{self.app_name}' with logs at {self.log_file}")

        # Write PID file of the child process
        with open(self.pid_file, "w") as f:
            f.write(str(self.process.pid))

    # ------------------ Child process ------------------
    def __run_child(self):
        """
        Runs in the background as a detached process.
        """

        log_file=open(self.log_file, 'a+')

        sys.stderr=log_file
        sys.stdout=log_file

        self.configure_logger()
        self.logger.info(f"Starting application...")
        self.processing_loop()

        log_file.close()

    # ------------------ Stop ------------------
    def stop(self):
        if not os.path.exists(self.pid_file):
            print("Application is not running")
            return

        with open(self.pid_file) as f:
            pid = int(f.read())

        self.configure_logger()
        self.logger.info("Stopping application...")

        try:
            # Use psutil to terminate process reliably on Windows
            p = psutil.Process(pid)
            p.terminate()  # sends SIGTERM equivalent
            p.wait(timeout=10)
            print(f"Stopped application '{self.app_name}'")
        except (psutil.NoSuchProcess, psutil.TimeoutExpired):
            print(f"Process {pid} not found or already terminated")
        finally:
            if os.path.exists(self.pid_file):
                os.remove(self.pid_file)