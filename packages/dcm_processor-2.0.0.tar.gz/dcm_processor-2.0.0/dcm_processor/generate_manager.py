import argparse, os, json
from dcm_processor_worker import WorkerManager
from .libs.config import get_component_path

def generate_component_args(parser: argparse.ArgumentParser):
    """Patch generate module command line args"""
    parser.add_argument(
        "component", choices=["worker", "service"], help="The component type to generate"
    )
    parser.add_argument(
        "name", type=str, help="The name of component to generate"
    )
    parser.add_argument(
        "-p", "--path", dest="dirname", type=str, help="Path to where to create the template, defaults to current directory",
        default="."
    )
    parser.add_argument(
        "-t",
        "--type",
        dest="type",
        choices=list(WorkerManager.worker_providers.keys()),
        type=str,
        default="venv",
        help="The type of worker to generate in case of component=worker",
    )
    parser.add_argument(
        "-w",
        "--inc-worker",
        dest="inc_worker",
        action="store_true",
        help="Include worker configuration in case where component=service"
    )
    parser.add_argument(
        "-e",
        "--event",
        choices=["stable-patient", "stable-study", "stable-series"],
        dest="event",
        action="append",
        help="Specify the events to handle in case of a service component"
    )

def handle_generate_component(args):
    comp = args.component

    if comp == "worker":
        handle_worker_generation(args)

    if comp == "service":
        handle_service_generation(args)

def handle_worker_generation(args, existing_settings=None):
    wtype = args.type
    name = args.name
    dir_name = args.dirname

    base_dir =  get_component_path(name=name, dirname=dir_name)
    WorkerManager.create_worker(name=name, wtype=wtype, dirname=base_dir)


    settings = {
        "name": name,
        "summary": "",
        "version": "0.0.1",
        "tags": [name],
        "worker": {
            "path": "worker",
            "type": wtype
        },
    }

    write_settings(settings=settings, existing_settings=existing_settings, dirname=base_dir)

def handle_service_generation(args):
    name = args.name
    dir_name = args.dirname

    base_dir = get_component_path(name=name, dirname=dir_name)
    modulePath = os.path.join(base_dir, "module")
    registryPath = os.path.join(base_dir, "registry")

    os.makedirs(modulePath, exist_ok=True)
    os.makedirs(registryPath, exist_ok=True)

    with open(os.path.join(registryPath, '__init__.py'), 'w') as f:
        f.write('from .main import callback')

    with open(os.path.join(modulePath, '__init__.py'), 'w') as f:
        f.write('from .main import worker')

    callback_code = [
        '\n',
        'def callback(session_id, job_name, headers, params, added_params, **kwargs):\n',
        '\tinjected_params = {"custom-data": "Some new data"}\n',
        '\n',
        '\t# Check header information etc. to see if you have to execute job\n'
        '\t# If Yes return True with the additional injected params\n'
        '\t# If No return False with additional injected params\n'
        '\n'
        '\treturn True, injected_params'
    ]
    
    worker_code = [
        '\n',
        'def worker(session_id, job_name, headers, params, added_params, **kwargs):\n',
        '\tpass\n',
    ]
    
    with open(os.path.join(registryPath, 'main.py'), 'w') as txt:
        txt.writelines(callback_code)

    with open(os.path.join(modulePath, 'main.py'), 'w') as txt:
        txt.writelines(worker_code)

    settings = {
        "name": name,
        "version": "0.0.1",
        "summary": "",
        "tags": [name],
        "service": {
            "registry": "registry",
            "module": "module",
            "required_services": [],
            "required_workers": [],
            "jobs": [
                {
                    "jobName": name,
                    "workerEntry": "worker",
                    "registryEntry": "callback",
                    "events": ["stable-series"] if len(args.event or []) == 0 else args.event,
                    "dependsOn": [],
                    "worker": name if args.inc_worker else None,
                    "timeout": "1h",
                    "params": {},
                    "sortPosition": 0,
                    "description": ""
                }
            ]
        },
    }

    if args.inc_worker:
        return handle_worker_generation(args, settings)
    else:
        write_settings(settings=settings, existing_settings=None, dirname=base_dir)

def write_settings(settings, existing_settings, dirname):
    settings_path = os.path.join(dirname, "dcm-processor.json")
    readme_path = os.path.join(dirname, "README.md")

    if os.path.exists(settings_path) and existing_settings is None:
        with open(settings_path, 'r') as f:
            existing_settings = json.load(f)

    settings.update(existing_settings or {})

    if "worker" in settings and "service" in settings:
        if "jobs" in settings.get("service", {}):
            for job in settings.get("service", {}).get("jobs", []):
                job["worker"] = settings.get("name")

    with open(settings_path, "w") as f:
        json.dump(settings, f, indent=4)

    name = settings.get("name")
    if not os.path.exists(readme_path):
        with open(readme_path, "w") as f:
            f.write(f"# {name}")