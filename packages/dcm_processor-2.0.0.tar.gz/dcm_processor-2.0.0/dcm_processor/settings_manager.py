import argparse, json
from tabulate import tabulate
from .libs.config import (
    get_app_config, get_all_apps, set_settings,
    SETTINGS, update_app, unset_settings,
    get_all_settings
)

TYPE_MAP = {
    "str": str,
    "int": int,
    "float": float,
    "bool": lambda x: x.lower() in ["true", "1", "yes"],
}

def patch_app_args(parser: argparse.ArgumentParser):
    subparsers = parser.add_subparsers(dest="app_command")

    edit_parser = subparsers.add_parser("set", help="Edit app params")
    set_app_args(edit_parser)

    remove_parser = subparsers.add_parser("unset", help="Remove app params")
    unset_app_args(remove_parser)

    list_parser = subparsers.add_parser("list", help="List configured apps")
    list_app_args(list_parser)

    get_parser = subparsers.add_parser("get", help="Get detailed information about a app")
    get_app_args(get_parser)

    default_parser = subparsers.add_parser("default", help="Change current default application")
    default_app_args(default_parser)

def set_app_args(parser: argparse.ArgumentParser):
    """Patch set app args"""
    parser.add_argument(
        "app_name", metavar="app_name", type=str, help="Name of the app already exist in selected application"
    )
    parser.add_argument(
        "--app",
        dest="app",
        type=str,
        help="The application name to edit the app, defaults to default app.",
    )
    parser.add_argument(
        "-j",
        "--job",
        dest="job",
        type=str,
        help="The job within the given app to edit, if absent all jobs are edited",
    )
    parser.add_argument(
        "-k",
        "--key",
        dest="key",
        type=str,
        required=True,
        help="The variable name or key in params to edit",
    )
    parser.add_argument(
        "-v",
        "--value",
        dest="value",
        type=str,
        required=True,
        help="The value to set for the params key",
    )
    parser.add_argument(
        "-t",
        "--type",
        dest="type",
        type=str,
        default='str',
        choices=list(TYPE_MAP.keys()),
        help="The type for the provided value",
    )

def unset_app_args(parser: argparse.ArgumentParser):
    """Patch unset app command line args"""
    parser.add_argument(
        "app_name", metavar="app_name", type=str, help="Name of the app already exist in selected application"
    )
    parser.add_argument(
        "--app",
        dest="app",
        type=str,
        help="The application name to edit the app, defaults to default app.",
    )
    parser.add_argument(
        "-j",
        "--job",
        dest="job",
        type=str,
        help="The job within the given app to edit, if absent all jobs are edited",
    )
    parser.add_argument(
        "-k",
        "--key",
        dest="key",
        type=str,
        help="The variable name or key in params to edit",
    )

def get_app_args(parser: argparse.ArgumentParser):
    """Patch get app command line args"""
    parser.add_argument(
        "app_name", metavar="app_name", type=str, help="Name of the app already exist in selected application"
    )

def default_app_args(parser: argparse.ArgumentParser):
    """Patch get app command line args"""
    parser.add_argument(
        "app_name", metavar="app_name", type=str, help="Name of the app already exist in selected application"
    )

def list_app_args(parser: argparse.ArgumentParser):
    """Patch show app command line args"""
    parser.add_argument(
        "-g",
        dest="global_config",
        action="store_true",
        help="Show global config instead of apps",
    )

def handle_app_main(args):
    app_command = args.app_command

    if app_command == "set":
        handle_set(args)
    elif app_command == "unset":
        handle_unset(args)
    elif app_command == "list":
        handle_list(args)
    elif app_command == "get":
        handle_get(args)
    elif app_command == "default":
        handle_default(args)

def handle_set(args):
    if not args.type in TYPE_MAP:
        print(f"Value type '{args.type}' is not supported!")
        return
    
    formatted_value = TYPE_MAP[args.type](args.value)

    app_name = args.app_name

    if app_name is None:
        if args.key in [s.value for s in SETTINGS]:
            print(f"Key '{args.key}' not supported")
            return
        
        set_settings(args.key, formatted_value)
        print(f"Global config successfully updated!")
    else:
        if args.key not in ["dbprovider", "dbname", "dburl"]:
            print(f"Key '{args.key}' not supported")
            return
        
        update_app(app_name, args.key, formatted_value)
        print(f"App config successfully updated!")

def handle_unset(args):
    app_name = args.app_name

    if app_name is None:
        if args.key in [s.value for s in SETTINGS]:
            print(f"Key '{args.key}' not supported")
            return
        
        unset_settings(args.key)
        print(f"Global config successfully updated!")
    else:
        print(f"App config successfully updated!")

def handle_list(args):
    if args.global_config:
        items = get_all_settings()
        print(tabulate(items, headers="keys", tablefmt="grid"))
    else:
        items = get_all_apps()
        print(tabulate(items, headers="keys", tablefmt="grid"))

def handle_get(args):
    config = get_app_config(args.app_name)
    print(json.dumps(config, indent=4))

def handle_default(args):
    config = get_app_config(args.app_name)
    if config is None:
        print(f"App '{args.app_name}' does not exist!")
        return
    
    set_settings(SETTINGS.DEFAULT_APP.value, args.app_name)
    print(f"Default app changed to '{args.app_name}'")

