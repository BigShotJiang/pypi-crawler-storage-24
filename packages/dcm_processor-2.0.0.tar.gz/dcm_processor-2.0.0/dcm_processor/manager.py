import argparse
from .app_manager import  (
    handle_create_app, handle_start_app,
    handle_stop_app, handle_restart_app,
    handle_view_app_logs, handle_backup_app,
    handle_restore_app
)
from .app_manager import (
    create_app_args, start_app_args,
    stop_app_args, view_app_logs_args,
    restart_app_args, backup_app_args,
    restore_app_args, status_app_args,
    handle_status_app, init_app_args,
    handle_init_app
)
from .generate_manager import generate_component_args, handle_generate_component
from .install_manager import (
    install_component_args, uninstall_component_args,
    handle_install_component, handle_uninstall_component
)

from .dicom_manager import patch_node_args, handle_node_main
from .peer_manager import patch_peer_args, handle_peer_main
from .service_manager import patch_service_args, handle_service_main
from .worker_manager import patch_worker_args, handle_worker_main
from .settings_manager import patch_app_args, handle_app_main
from .registry_manager import registry_args, handle_registry
from .constants import VERSION

def parse_args():
    """
    Build command line arguments for admin service
    """
    parent_parser = argparse.ArgumentParser(
        description="The dcm-processor command line tool", add_help=True
    )
    subparsers = parent_parser.add_subparsers(dest="command")

    create_app = subparsers.add_parser("create", help="Create a dcm-processor application")
    create_app_args(create_app)

    init_app = subparsers.add_parser("init", help="Initialize a dcm-processor application")
    init_app_args(init_app)

    registry = subparsers.add_parser("registry", help="Manage registry api access")
    registry_args(registry)

    start = subparsers.add_parser("start", help="Start application(s)")
    start_app_args(start)

    stop = subparsers.add_parser("stop", help="Stop application(s)")
    stop_app_args(stop)

    status = subparsers.add_parser("status", help="Get application(s) status")
    status_app_args(status)

    restart = subparsers.add_parser("restart", help="Restart application(s)")
    restart_app_args(restart)

    logs = subparsers.add_parser("logs", help="View application logs")
    view_app_logs_args(logs)

    subparsers.add_parser("version", help="Get application version")

    generate = subparsers.add_parser("generate", aliases=["gen", "g"], help="Generate application component (e.g. service, worker)")
    generate_component_args(generate)

    install = subparsers.add_parser("install", help="Install service or worker environment")
    install_component_args(install)

    uninstall = subparsers.add_parser("uninstall", help="Uninstall service or worker environment")
    uninstall_component_args(uninstall)

    backup = subparsers.add_parser("backup", help="Backup an entire application")
    backup_app_args(backup)

    restore = subparsers.add_parser("restore", help="Restore an entire application")
    restore_app_args(restore)

    dicom_node = subparsers.add_parser("dicom-node", aliases=["node"], help="Manage dicom nodes")
    patch_node_args(dicom_node)

    dicom_peer = subparsers.add_parser("dicom-peer", aliases=["peer"], help="Manage dicom peers")
    patch_peer_args(dicom_peer)

    service_config = subparsers.add_parser("service", help="Manage application services")
    patch_service_args(service_config)

    worker_config = subparsers.add_parser("worker", help="Manage application workers")
    patch_worker_args(worker_config)

    app_config = subparsers.add_parser("app", help="Manage application configuration")
    patch_app_args(app_config)

    args = parent_parser.parse_args()
    return args, parent_parser

def main():
    """
    Entrypoint to dcm-processor cli
    """
    
    args, parser = parse_args()
    command = args.command

    if command == "create":
        handle_create_app(args)
    elif command == "init":
        handle_init_app(args)
    elif command == "start":
        handle_start_app(args)
    elif command == "stop":
        handle_stop_app(args)
    elif command == "status":
        handle_status_app(args)
    elif command == "restart":
        handle_restart_app(args)
    elif command == "logs":
        handle_view_app_logs(args)
    elif command == "version":
        print(VERSION, flush=True)
    elif command in ["generate", "gen", "g"]:
        handle_generate_component(args)
    elif command == "install":
        handle_install_component(args)
    elif command == "uninstall":
        handle_uninstall_component(args)
    elif command == "backup":
        handle_backup_app(args)
    elif command == "restore":
        handle_restore_app(args)
    elif command in ["dicom-node", "node"]:
        handle_node_main(args)
    elif command in ["dicom-peer", "peer"]:
        handle_peer_main(args)
    elif command == "service":
        handle_service_main(args)
    elif command == "worker":
        handle_worker_main(args)
    elif command == "app":
        handle_app_main(args)
    elif command == "registry":
        handle_registry(args)
    else:
        parser.print_help()

if __name__ == "__main__":
    main()
