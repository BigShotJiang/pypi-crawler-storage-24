import argparse
from tabulate import tabulate
from dcm_processor_db_provider import DBManager
from .libs.config import get_app_config
from .libs.misc import TYPE_MAP

def patch_service_args(parser: argparse.ArgumentParser):
    subparsers = parser.add_subparsers(dest="service_command")

    edit_parser = subparsers.add_parser("set", help="Edit service params")
    set_service_args(edit_parser)

    remove_parser = subparsers.add_parser("unset", help="Remove service params")
    unset_service_args(remove_parser)

    list_parser = subparsers.add_parser("list", help="List configured service in the application")
    list_services_args(list_parser)

    get_parser = subparsers.add_parser("get", help="Get detailed information about a service")
    get_service_args(get_parser)

def set_service_args(parser: argparse.ArgumentParser):
    """Patch set service args"""
    parser.add_argument(
        "service_name", metavar="service_name", type=str, help="Name of the service already exist in selected application"
    )
    parser.add_argument(
        "--app",
        dest="app",
        type=str,
        help="The application name to edit the service, defaults to default app.",
    )
    parser.add_argument(
        "-j",
        "--job",
        dest="job",
        type=str,
        help="The job within the given service to edit, if absent all jobs are edited",
    )
    parser.add_argument(
        "-k",
        "--key",
        dest="key",
        type=str,
        required=True,
        help="The variable name or key in params to edit",
    )
    parser.add_argument(
        "-v",
        "--value",
        dest="value",
        type=str,
        required=True,
        help="The value to set for the params key",
    )
    parser.add_argument(
        "-t",
        "--type",
        dest="type",
        type=str,
        default='str',
        choices=list(TYPE_MAP.keys()),
        help="The type for the provided value",
    )

def unset_service_args(parser: argparse.ArgumentParser):
    """Patch unset service command line args"""
    parser.add_argument(
        "service_name", metavar="service_name", type=str, help="Name of the service already exist in selected application"
    )
    parser.add_argument(
        "--app",
        dest="app",
        type=str,
        help="The application name to edit the service, defaults to default app.",
    )
    parser.add_argument(
        "-j",
        "--job",
        dest="job",
        type=str,
        help="The job within the given service to edit, if absent all jobs are edited",
    )
    parser.add_argument(
        "-k",
        "--key",
        dest="key",
        type=str,
        help="The variable name or key in params to edit",
    )

def list_services_args(parser: argparse.ArgumentParser):
    """Patch show services command line args"""
    parser.add_argument(
        "--app",
        dest="app",
        type=str,
        help="The application name to edit the service, defaults to default app.",
    )

def get_service_args(parser: argparse.ArgumentParser):
    """Patch get service command line args"""
    parser.add_argument(
        "service_name", metavar="service_name", type=str, help="Name of the service already exist in selected application"
    )
    parser.add_argument(
        "--app",
        dest="app",
        type=str,
        help="The application name to edit the service, defaults to default app.",
    )

def handle_service_main(args):
    service_command = args.service_command

    if service_command == "set":
        handle_set(args)
    elif service_command == "unset":
        handle_unset(args)
    elif service_command == "list":
        handle_list(args)
    elif service_command == "get":
        handle_get(args)

def handle_set(args):
    if not args.type in TYPE_MAP:
        print(f"Value type '{args.type}' is not supported!")
        return
    
    formatted_value = TYPE_MAP[args.type](args.value)

    config = get_app_config(args.app)
    mgr = DBManager(
        dbname=config.get("dbname"),
        dburl=config.get("dburl"),
        dbprovider=config.get("dbprovider"),
    )

    # get existing object
    res = mgr.set_service_param(
        name=args.service_name,
        key=args.key,
        value=formatted_value,
        job_name=args.job
    )

    print(f"Service with id {res} updated!")

def handle_unset(args):
    config = get_app_config(args.app)
    mgr = DBManager(
        dbname=config.get("dbname"),
        dburl=config.get("dburl"),
        dbprovider=config.get("dbprovider"),
    )

    res = mgr.unset_service_param(
        name=args.service_name,
        key=args.key,
        job_name=args.job
    )

    if not res is None:
        print(f"Service with id {res} updated!")

def handle_list(args):
    config = get_app_config(args.app)
    mgr = DBManager(
        dbname=config.get("dbname"),
        dburl=config.get("dburl"),
        dbprovider=config.get("dbprovider"),
    )

    items = mgr.get_services(select=["_id", "name", "version", "jobs.jobName"])
    for item in items:
        item["jobs"] = ", ".join((i.get("jobName") for i in item.get("jobs", [])))

    print(tabulate(items, headers="keys", tablefmt="grid"))

def handle_get(args):
    config = get_app_config(args.app)
    mgr = DBManager(
        dbname=config.get("dbname"),
        dburl=config.get("dburl"),
        dbprovider=config.get("dbprovider"),
    )

    item = mgr.get_service(name=args.service_name)
    if not item is None:
        print(DBManager.to_json(item, config.get("dbprovider")))

