import argparse
from tabulate import tabulate
from dcm_processor_db_provider import DBManager
from .libs.config import get_app_config
from .libs.misc import TYPE_MAP

def patch_worker_args(parser: argparse.ArgumentParser):
    subparsers = parser.add_subparsers(dest="worker_command")

    edit_parser = subparsers.add_parser("set", help="Edit worker params")
    set_worker_args(edit_parser)

    remove_parser = subparsers.add_parser("unset", help="Remove worker params")
    unset_worker_args(remove_parser)

    list_parser = subparsers.add_parser("list", help="List configured worker in the application")
    list_workers_args(list_parser)

    get_parser = subparsers.add_parser("get", help="Get detailed information about a worker")
    get_worker_args(get_parser)

def set_worker_args(parser: argparse.ArgumentParser):
    """Patch set worker args"""
    parser.add_argument(
        "worker_name", metavar="worker_name", type=str, help="Name of the worker already exist in selected application"
    )
    parser.add_argument(
        "--app",
        dest="app",
        type=str,
        help="The application name to edit the worker, defaults to default app.",
    )
    parser.add_argument(
        "-j",
        "--job",
        dest="job",
        type=str,
        help="The job within the given worker to edit, if absent all jobs are edited",
    )
    parser.add_argument(
        "-k",
        "--key",
        dest="key",
        type=str,
        required=True,
        help="The variable name or key in params to edit",
    )
    parser.add_argument(
        "-v",
        "--value",
        dest="value",
        type=str,
        required=True,
        help="The value to set for the params key",
    )
    parser.add_argument(
        "-t",
        "--type",
        dest="type",
        type=str,
        default='str',
        choices=list(TYPE_MAP.keys()),
        help="The type for the provided value",
    )

def unset_worker_args(parser: argparse.ArgumentParser):
    """Patch unset worker command line args"""
    parser.add_argument(
        "worker_name", metavar="worker_name", type=str, help="Name of the worker already exist in selected application"
    )
    parser.add_argument(
        "--app",
        dest="app",
        type=str,
        help="The application name to edit the worker, defaults to default app.",
    )
    parser.add_argument(
        "-j",
        "--job",
        dest="job",
        type=str,
        help="The job within the given worker to edit, if absent all jobs are edited",
    )
    parser.add_argument(
        "-k",
        "--key",
        dest="key",
        type=str,
        help="The variable name or key in params to edit",
    )

def list_workers_args(parser: argparse.ArgumentParser):
    """Patch show workers command line args"""
    parser.add_argument(
        "--app",
        dest="app",
        type=str,
        help="The application name to edit the worker, defaults to default app.",
    )

def get_worker_args(parser: argparse.ArgumentParser):
    """Patch get worker command line args"""
    parser.add_argument(
        "worker_name", metavar="worker_name", type=str, help="Name of the worker already exist in selected application"
    )
    parser.add_argument(
        "--app",
        dest="app",
        type=str,
        help="The application name to edit the worker, defaults to default app.",
    )

def handle_worker_main(args):
    worker_command = args.worker_command

    if worker_command == "set":
        handle_set(args)
    elif worker_command == "unset":
        handle_unset(args)
    elif worker_command == "list":
        handle_list(args)
    elif worker_command == "get":
        handle_get(args)

def handle_set(args):
    if not args.type in TYPE_MAP:
        print(f"Value type '{args.type}' is not supported!")
        return
    
    formatted_value = TYPE_MAP[args.type](args.value)

    config = get_app_config(args.app)
    mgr = DBManager(
        dbname=config.get("dbname"),
        dburl=config.get("dburl"),
        dbprovider=config.get("dbprovider"),
    )

    # get existing object
    res = mgr.set_worker_param(
        name=args.worker_name,
        key=args.key,
        value=formatted_value
    )

    print(f"Worker with id {res} updated!")

def handle_unset(args):
    config = get_app_config(args.app)
    mgr = DBManager(
        dbname=config.get("dbname"),
        dburl=config.get("dburl"),
        dbprovider=config.get("dbprovider"),
    )

    res = mgr.unset_worker_param(
        name=args.worker_name,
        key=args.key
    )

    if not res is None:
        print(f"Worker with id {res} updated!")

def handle_list(args):
    config = get_app_config(args.app)
    mgr = DBManager(
        dbname=config.get("dbname"),
        dburl=config.get("dburl"),
        dbprovider=config.get("dbprovider"),
    )

    items = mgr.get_workers(select=["_id", "name", "version", "type"])
    print(tabulate(items, headers="keys", tablefmt="grid"))

def handle_get(args):
    config = get_app_config(args.app)
    mgr = DBManager(
        dbname=config.get("dbname"),
        dburl=config.get("dburl"),
        dbprovider=config.get("dbprovider"),
    )

    item = mgr.get_worker(name=args.worker_name)
    if not item is None:
        print(DBManager.to_json(item, config.get("dbprovider")))

