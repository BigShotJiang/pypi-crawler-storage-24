# dayhoff-tools (legacy)

> **Note**: Active development has moved to private packages on CodeArtifact: `dh-cli` (developer CLI), `dh-batch` (batch job entrypoints), `dh-embedders` (protein embeddings), and `dh-chem` (chemistry utilities). This package remains on PyPI for backward compatibility with existing notebooks and pipelines that import data utilities (`dayhoff_tools.warehouse`, `dayhoff_tools.file_ops`, `dayhoff_tools.sqlite`, etc.).

## Installation

```bash
pip install dayhoff-tools
```

### Optional Dependencies

Available extras: `full`, `embedders`, `boltz`, `batch`.

```bash
pip install 'dayhoff-tools[full]'
```