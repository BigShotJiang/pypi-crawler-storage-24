"""
novyx-agent — Build AI agents with persistent memory.

    from novyx_agent import Agent, tool

    agent = Agent(name="Aria", api_key="nram_...")

    @agent.tool
    def search(query: str) -> str:
        return "result"

    print(agent.run("What did we discuss yesterday?"))

Features:
    - Semantic memory recall before every LLM call
    - Auto-remember conversation outputs
    - Rollback to any point in time
    - Cryptographic audit trail
    - Memory health eval with pass/fail gates
    - Knowledge graph (triples)
    - Works with OpenAI, Anthropic, or any LiteLLM-supported model
"""

__version__ = "1.1.0"

from .agent import Agent
from .async_agent import AsyncAgent
from .tools import tool
from .types import (
    AgentConfig,
    MemoryConfig,
    Message,
    Role,
    RunResult,
    ToolCall,
    ToolDef,
    ToolParam,
)

__all__ = [
    "Agent",
    "AsyncAgent",
    "tool",
    "AgentConfig",
    "MemoryConfig",
    "Message",
    "Role",
    "RunResult",
    "ToolCall",
    "ToolDef",
    "ToolParam",
]
