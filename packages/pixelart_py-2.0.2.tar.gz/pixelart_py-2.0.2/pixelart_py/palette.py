"""
pixelart_py.palette
~~~~~~~~~~~~~~~~~~~
Color representation, parsing, and named palette support.
"""

from __future__ import annotations
from typing import Dict, Optional, Union

ColorLike = Union[str, tuple]


def parse_color(color: ColorLike) -> tuple:
    """
    Normalise any color input to an (R, G, B, A) tuple.

    Accepted formats:
        "#rgb"        3-digit hex shorthand
        "#rrggbb"     6-digit hex
        "#rrggbbaa"   8-digit hex with alpha
        (r, g, b)     integer tuple, alpha assumed 255
        (r, g, b, a)  integer tuple with explicit alpha

    Returns
    -------
    tuple  (r, g, b, a) each 0-255
    """
    if isinstance(color, tuple):
        if len(color) == 3:
            return (int(color[0]), int(color[1]), int(color[2]), 255)
        elif len(color) == 4:
            return tuple(int(c) for c in color)
        raise ValueError(f"Color tuple must have 3 or 4 elements, got {len(color)}")

    if isinstance(color, str):
        h = color.lstrip("#")
        if len(h) == 3:
            h = "".join(c * 2 for c in h)
        if len(h) == 6:
            return (int(h[0:2], 16), int(h[2:4], 16), int(h[4:6], 16), 255)
        if len(h) == 8:
            return (int(h[0:2], 16), int(h[2:4], 16), int(h[4:6], 16), int(h[6:8], 16))
        raise ValueError(f"Unrecognised hex color: '{color}'")

    raise TypeError(f"color must be str or tuple, got {type(color).__name__}")


def to_hex(color: tuple) -> str:
    """Convert an (r, g, b, a) tuple to a '#rrggbb' hex string."""
    r, g, b, *_ = color
    return f"#{r:02x}{g:02x}{b:02x}"


class Palette:
    """
    A named collection of reusable colors.

    Example
    -------
    ::

        p = Palette({"sky": "#87ceeb", "ground": "#4a7c3f"})
        canvas.fill(p["sky"])
    """

    def __init__(self, colors: Optional[Dict[str, ColorLike]] = None):
        self._colors: Dict[str, tuple] = {}
        if colors:
            for name, color in colors.items():
                self.add(name, color)

    def add(self, name: str, color: ColorLike) -> None:
        """Register a named color."""
        self._colors[name] = parse_color(color)

    def get(self, name: str) -> tuple:
        """Retrieve a color by name."""
        if name not in self._colors:
            raise KeyError(f"'{name}' not in palette. Available: {list(self._colors)}")
        return self._colors[name]

    def names(self) -> list:
        return list(self._colors.keys())

    def __getitem__(self, name: str) -> tuple:
        return self.get(name)

    def __contains__(self, name: str) -> bool:
        return name in self._colors

    def __repr__(self) -> str:
        return f"Palette({list(self._colors.keys())})"


# ── Built-in palettes ──────────────────────────────────────────────────────────

CLASSIC = Palette({
    "black": "#000000", "white": "#ffffff", "red": "#ff0000",
    "lime": "#00ff00", "blue": "#0000ff", "yellow": "#ffff00",
    "cyan": "#00ffff", "magenta": "#ff00ff", "silver": "#c0c0c0",
    "gray": "#808080", "maroon": "#800000", "olive": "#808000",
    "green": "#008000", "purple": "#800080", "teal": "#008080",
    "navy": "#000080",
})

PASTEL = Palette({
    "blush": "#ffb3ba", "peach": "#ffdfba", "butter": "#ffffba",
    "mint": "#baffc9", "powder": "#bae1ff", "lavender": "#e8baff",
    "lilac": "#c9baff", "rose": "#ffbae8", "cream": "#fff9f0",
    "charcoal": "#333333",
})

EARTHY = Palette({
    "soil": "#5c3a1e", "bark": "#7b4f2e", "sand": "#c2a06e",
    "wheat": "#e8d08a", "grass": "#4a7c3f", "forest": "#2d5a27",
    "sky": "#87ceeb", "dusk": "#e07b54", "stone": "#9e9e8e",
    "snow": "#f5f5f5",
})
