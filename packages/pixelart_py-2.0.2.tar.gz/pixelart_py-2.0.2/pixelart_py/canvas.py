"""
pixelart_py.canvas
~~~~~~~~~~~~~~~~~~
Core Canvas class — the heart of pixelart-py.
"""

from __future__ import annotations
from typing import Optional

from .palette import parse_color, ColorLike
from . import drawing
from .exporter import (
    save_png, to_png_image,
    save_html, to_html_string,
    to_python_code,
    CSSStyle,
)


class Canvas:
    """
    A rectangular grid of pixels for creating pixel art programmatically.

    Parameters
    ----------
    width, height : int
        Dimensions of the canvas in pixels.
    pixel_size : int
        Scale factor — each logical pixel becomes pixel_size×pixel_size
        in exported images / HTML. Default 1.
    background : ColorLike, optional
        Initial fill color. Default: transparent.

    Example
    -------
    ::

        from pixelart_py import Canvas

        canvas = Canvas(16, 16, pixel_size=20)
        canvas.fill("#1a1a2e")
        canvas.draw_circle(8, 8, 6, "#e63946", filled=True)
        canvas.save("art.png")
        canvas.save_html("art.html", style="grid")
    """

    def __init__(
        self,
        width: int,
        height: int,
        pixel_size: int = 1,
        background: Optional[ColorLike] = None,
    ):
        if width < 1 or height < 1:
            raise ValueError("width and height must be ≥ 1")
        if pixel_size < 1:
            raise ValueError("pixel_size must be ≥ 1")

        self.width = width
        self.height = height
        self.pixel_size = pixel_size

        default = parse_color(background) if background is not None else (0, 0, 0, 0)
        self._pixels: list[tuple] = [default] * (width * height)

    # ── Pixel access ───────────────────────────────────────────────────────────

    def set_pixel(self, x: int, y: int, color: ColorLike) -> None:
        """Set a single pixel. Out-of-bounds coordinates are silently ignored."""
        if 0 <= x < self.width and 0 <= y < self.height:
            self._pixels[y * self.width + x] = parse_color(color)

    def get_pixel(self, x: int, y: int) -> tuple:
        """Return the (R, G, B, A) tuple at (x, y)."""
        if not (0 <= x < self.width and 0 <= y < self.height):
            raise IndexError(f"({x}, {y}) out of bounds for {self.width}×{self.height} canvas")
        return self._pixels[y * self.width + x]

    def fill(self, color: ColorLike) -> None:
        """Fill the entire canvas with one color."""
        rgba = parse_color(color)
        self._pixels = [rgba] * (self.width * self.height)

    # ── Drawing primitives ─────────────────────────────────────────────────────

    def draw_rect(self, x: int, y: int, w: int, h: int, color: ColorLike, *, filled: bool = True) -> None:
        """Draw a filled or outline rectangle."""
        drawing.draw_rect(self, x, y, w, h, color, filled=filled)

    def draw_line(self, x1: int, y1: int, x2: int, y2: int, color: ColorLike) -> None:
        """Draw a straight line (Bresenham's algorithm)."""
        drawing.draw_line(self, x1, y1, x2, y2, color)

    def draw_circle(self, cx: int, cy: int, radius: int, color: ColorLike, *, filled: bool = False) -> None:
        """Draw a circle outline or filled disk."""
        drawing.draw_circle(self, cx, cy, radius, color, filled=filled)

    def flood_fill(self, x: int, y: int, color: ColorLike) -> None:
        """Replace all connected same-color pixels starting at (x, y)."""
        drawing.flood_fill(self, x, y, color)

    # ── Canvas utilities ───────────────────────────────────────────────────────

    def copy(self) -> "Canvas":
        """Return a deep copy of this canvas."""
        c = Canvas(self.width, self.height, self.pixel_size)
        c._pixels = list(self._pixels)
        return c

    def paste(self, other: "Canvas", x: int, y: int) -> None:
        """Paste another canvas at (x, y), respecting alpha transparency."""
        for py in range(other.height):
            for px in range(other.width):
                r, g, b, a = other.get_pixel(px, py)
                if a > 0:
                    self.set_pixel(x + px, y + py, (r, g, b, a))

    def clear(self) -> None:
        """Reset all pixels to transparent."""
        self._pixels = [(0, 0, 0, 0)] * (self.width * self.height)

    # ── Export ─────────────────────────────────────────────────────────────────

    def save(self, path: str) -> None:
        """
        Export as PNG.

        Parameters
        ----------
        path : str   e.g. "output.png"
        """
        save_png(self, path)

    def save_html(
        self,
        path: str,
        style: CSSStyle = "grid",
        pixel_size: int = None,
        title: str = "Pixel Art",
    ) -> None:
        """
        Export as a self-contained HTML/CSS file.

        Parameters
        ----------
        path       : str   e.g. "output.html"
        style      : str   "grid" | "table" | "custom-properties"
        pixel_size : int   Override the cell size in the HTML (optional).
        title      : str   Page title shown in the browser.

        Notes
        -----
        All three styles produce a fully self-contained HTML file with no
        external dependencies.

        - ``"grid"``              CSS Grid layout — modern, compact.
        - ``"table"``             HTML <table> — maximum browser compat.
        - ``"custom-properties"`` Uses CSS variables per unique color —
                                  easy to re-theme by editing the variables.
        """
        save_html(self, path, style=style, pixel_size=pixel_size, title=title)

    def to_html(
        self,
        style: CSSStyle = "grid",
        pixel_size: int = None,
        title: str = "Pixel Art",
    ) -> str:
        """Return the HTML as a string instead of saving to disk."""
        return to_html_string(self, style=style, pixel_size=pixel_size, title=title)

    def to_image(self):
        """Return a PIL.Image.Image of the canvas."""
        return to_png_image(self)

    def to_code(self, var_name: str = "canvas") -> str:
        """
        Convert this canvas back into the Python code that would recreate it.

        Useful after hand-drawing in the editor — the editor calls this to
        give you copy-pasteable source code.

        Returns
        -------
        str   Runnable Python source.
        """
        return to_python_code(self, var_name=var_name)

    def preview(self) -> None:
        """Open a quick preview window (requires a display environment)."""
        self.to_image().show()

    def __repr__(self) -> str:
        return f"Canvas({self.width}×{self.height}, pixel_size={self.pixel_size})"
