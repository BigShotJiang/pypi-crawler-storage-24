"""
pixelart_py.drawing
~~~~~~~~~~~~~~~~~~~
Drawing primitives: lines, rectangles, circles, flood fill.
All functions accept a Canvas instance and any ColorLike value.
"""

from __future__ import annotations
import math
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from .canvas import Canvas


def draw_rect(canvas: "Canvas", x: int, y: int, w: int, h: int, color, *, filled: bool = True) -> None:
    """Draw a filled or outline rectangle."""
    for py in range(y, y + h):
        for px in range(x, x + w):
            if filled or px == x or px == x + w - 1 or py == y or py == y + h - 1:
                canvas.set_pixel(px, py, color)


def draw_line(canvas: "Canvas", x1: int, y1: int, x2: int, y2: int, color) -> None:
    """Bresenham's line algorithm."""
    dx, dy = abs(x2 - x1), abs(y2 - y1)
    sx, sy = (1 if x1 < x2 else -1), (1 if y1 < y2 else -1)
    err = dx - dy
    x, y = x1, y1
    while True:
        canvas.set_pixel(x, y, color)
        if x == x2 and y == y2:
            break
        e2 = 2 * err
        if e2 > -dy:
            err -= dy; x += sx
        if e2 < dx:
            err += dx; y += sy


def draw_circle(canvas: "Canvas", cx: int, cy: int, radius: int, color, *, filled: bool = False) -> None:
    """Midpoint circle algorithm (outline or filled disk)."""
    if filled:
        for y in range(cy - radius, cy + radius + 1):
            dy = y - cy
            half = math.isqrt(radius * radius - dy * dy)
            for x in range(cx - half, cx + half + 1):
                canvas.set_pixel(x, y, color)
    else:
        x, y, err = radius, 0, 0
        while x >= y:
            for px, py in [
                (cx+x, cy+y), (cx+y, cy+x), (cx-y, cy+x), (cx-x, cy+y),
                (cx-x, cy-y), (cx-y, cy-x), (cx+y, cy-x), (cx+x, cy-y),
            ]:
                canvas.set_pixel(px, py, color)
            y += 1
            if err <= 0: err += 2 * y + 1
            if err > 0:  x -= 1; err -= 2 * x + 1


def flood_fill(canvas: "Canvas", x: int, y: int, color) -> None:
    """Iterative BFS flood fill — replaces all connected same-color pixels."""
    from .palette import parse_color
    target = canvas.get_pixel(x, y)
    replacement = parse_color(color)
    if target == replacement:
        return
    queue, visited = [(x, y)], set()
    while queue:
        px, py = queue.pop()
        if (px, py) in visited or not (0 <= px < canvas.width and 0 <= py < canvas.height):
            continue
        if canvas.get_pixel(px, py) != target:
            continue
        canvas.set_pixel(px, py, replacement)
        visited.add((px, py))
        queue.extend([(px+1, py), (px-1, py), (px, py+1), (px, py-1)])
