"""
pixelart_py.editor
~~~~~~~~~~~~~~~~~~
Tkinter desktop GUI editor for hand-drawing pixel art.

Supports canvases up to 128×128. When you close the window or click
"Save & Export", the drawn pixels are returned as a Canvas object and
the equivalent Python code is printed to the terminal.

Usage
-----
::

    from pixelart_py.editor import open_editor

    canvas = open_editor(width=32, height=32)
    canvas.save("my_art.png")
    canvas.save_html("my_art.html", style="grid")
    print(canvas.to_code())

Keyboard shortcuts
------------------
    D          Draw tool
    E          Erase tool
    F          Fill (flood fill) tool
    I          Eyedropper
    G          Toggle grid
    Ctrl+Z     Undo
    Ctrl+S     Save & export
    [ / ]      Decrease / increase brush size
"""

from __future__ import annotations

import math
import tkinter as tk
from tkinter import ttk, colorchooser, filedialog, messagebox
from typing import Optional, List, Tuple

from .canvas import Canvas
from .palette import parse_color, to_hex


# ── Constants ─────────────────────────────────────────────────────────────────

MAX_CANVAS   = 128
MIN_CELL     = 2
DEFAULT_CELL = 16

QUICK_PALETTE = [
    "#000000", "#ffffff", "#ff0000", "#00cc44", "#0055ff",
    "#ffdd00", "#ff7700", "#cc00ff", "#00ccff", "#ff4488",
    "#884400", "#336600", "#003388", "#660044", "#008888",
    "#aaaaaa", "#555555", "#ffccaa", "#aaffcc", "#ccaaff",
]

UI_BG       = "#1a1a2e"
UI_PANEL    = "#16213e"
UI_BORDER   = "#2a2a4a"
UI_ACCENT   = "#e63946"
UI_TEXT     = "#e0e0f0"
UI_BTN      = "#0f3460"
UI_BTN_HVR  = "#1a4a7a"
UI_ENTRY_BG = "#0d0d1a"


# ── Tiny helpers ──────────────────────────────────────────────────────────────

def _rgba_to_tk(rgba: tuple) -> str:
    return f"#{rgba[0]:02x}{rgba[1]:02x}{rgba[2]:02x}"

def _tk_to_rgba(hex_str: str) -> tuple:
    h = hex_str.lstrip("#")
    return (int(h[0:2],16), int(h[2:4],16), int(h[4:6],16), 255)

def _checkerboard(x: int, y: int) -> str:
    return "#2a2a3e" if (x + y) % 2 == 0 else "#1e1e30"

def _bresenham(x0, y0, x1, y1):
    dx, dy = abs(x1-x0), abs(y1-y0)
    sx, sy = (1 if x0<x1 else -1), (1 if y0<y1 else -1)
    err = dx - dy
    while True:
        yield x0, y0
        if x0==x1 and y0==y1: break
        e2 = 2*err
        if e2 > -dy: err -= dy; x0 += sx
        if e2 <  dx: err += dx; y0 += sy


# ── Main editor ───────────────────────────────────────────────────────────────

class PixelEditor:
    def __init__(self, root: tk.Tk, grid_w=16, grid_h=16,
                 cell_size=DEFAULT_CELL, initial: Optional[Canvas]=None):
        self.root      = root
        self.grid_w    = min(max(grid_w, 1), MAX_CANVAS)
        self.grid_h    = min(max(grid_h, 1), MAX_CANVAS)
        self.cell_size = max(cell_size, MIN_CELL)

        self.pixels: List[tuple] = (
            list(initial._pixels) if initial else
            [(0,0,0,0)] * (self.grid_w * self.grid_h)
        )

        self.tool          = "draw"
        self.brush_size    = 1
        self.current_color = (230, 57, 70, 255)
        self.show_grid     = True
        self.painting      = False
        self.last_cell     = None
        self._prev_drag    = None
        self._history: List[List[tuple]] = []
        self.result: Optional[Canvas] = None

        self._build_ui()
        self._render_all()

    # ── UI ────────────────────────────────────────────────────────────────────

    def _build_ui(self):
        self.root.title(f"pixelart-py  ·  {self.grid_w}×{self.grid_h}")
        self.root.configure(bg=UI_BG)
        self.root.resizable(True, True)

        # Top bar
        top = tk.Frame(self.root, bg=UI_BG)
        top.pack(fill="x", padx=12, pady=6)
        tk.Label(top, text="pixelart-py", bg=UI_BG, fg=UI_ACCENT,
                 font=("Courier",14,"bold")).pack(side="left")
        tk.Label(top, text=f"  EDITOR · {self.grid_w}×{self.grid_h}",
                 bg=UI_BG, fg=UI_TEXT, font=("Courier",9)).pack(side="left")
        self.status_var = tk.StringVar(value="ready — draw something!")
        tk.Label(top, textvariable=self.status_var,
                 bg=UI_BG, fg=UI_TEXT, font=("Courier",9)).pack(side="right")

        # Body
        body = tk.Frame(self.root, bg=UI_BG)
        body.pack(fill="both", expand=True, padx=12, pady=(0,12))

        self._build_canvas_pane(body)
        self._build_side_panel(body)

        # Keyboard shortcuts
        for key, fn in [
            ("<d>", lambda e: self._set_tool("draw")),
            ("<e>", lambda e: self._set_tool("erase")),
            ("<f>", lambda e: self._set_tool("fill")),
            ("<i>", lambda e: self._set_tool("eyedrop")),
            ("<g>", lambda e: self._toggle_grid()),
            ("<Control-z>", lambda e: self._undo()),
            ("<Control-s>", lambda e: self._save()),
            ("<bracketleft>",  lambda e: self._brush_delta(-1)),
            ("<bracketright>", lambda e: self._brush_delta(+1)),
        ]:
            self.root.bind(key, fn)

    def _build_canvas_pane(self, parent):
        left = tk.Frame(parent, bg=UI_BG)
        left.pack(side="left", fill="both", expand=True)

        # Toolbar row
        bar = tk.Frame(left, bg=UI_BG)
        bar.pack(fill="x", pady=(0,4))
        for txt, cmd in [("−",self._zoom_out),("+",self._zoom_in)]:
            self._mk_btn(bar, txt, cmd).pack(side="left", padx=2)
        self.zoom_lbl = tk.Label(bar, text=f"{self.cell_size}px/cell",
                                  bg=UI_BG, fg=UI_TEXT, font=("Courier",9))
        self.zoom_lbl.pack(side="left", padx=6)
        self._mk_btn(bar, "⊞ Grid", self._toggle_grid).pack(side="right", padx=2)

        # Scrollable canvas
        cf = tk.Frame(left, bg=UI_BORDER, bd=1)
        cf.pack(fill="both", expand=True)

        hbar = tk.Scrollbar(cf, orient="horizontal", bg=UI_BG)
        vbar = tk.Scrollbar(cf, orient="vertical",   bg=UI_BG)
        hbar.pack(side="bottom", fill="x")
        vbar.pack(side="right",  fill="y")

        self.cv = tk.Canvas(cf, bg="#111120", highlightthickness=0,
                            cursor="crosshair",
                            xscrollcommand=hbar.set,
                            yscrollcommand=vbar.set)
        self.cv.pack(side="left", fill="both", expand=True)
        hbar.config(command=self.cv.xview)
        vbar.config(command=self.cv.yview)

        self.cv.bind("<ButtonPress-1>",   self._on_press)
        self.cv.bind("<B1-Motion>",        self._on_drag)
        self.cv.bind("<ButtonRelease-1>",  self._on_release)
        self.cv.bind("<Motion>",           self._on_hover)
        self.cv.bind("<Button-3>",         self._on_right_click)
        self.cv.bind("<Control-MouseWheel>", self._on_ctrl_wheel)
        self.cv.bind("<Control-Button-4>", lambda e: self._zoom_in())
        self.cv.bind("<Control-Button-5>", lambda e: self._zoom_out())

    def _build_side_panel(self, parent):
        panel = tk.Frame(parent, bg=UI_PANEL, width=210, bd=0)
        panel.pack(side="right", fill="y", padx=(10,0))
        panel.pack_propagate(False)

        def sep(label):
            tk.Label(panel, text=label, bg=UI_PANEL, fg=UI_TEXT,
                     font=("Courier",8), anchor="w").pack(
                fill="x", padx=10, pady=(10,1))
            tk.Frame(panel, bg=UI_BORDER, height=1).pack(fill="x", padx=10)

        # Color picker
        sep("COLOR")
        cr = tk.Frame(panel, bg=UI_PANEL)
        cr.pack(fill="x", padx=10, pady=6)

        self.swatch = tk.Label(cr, bg=_rgba_to_tk(self.current_color),
                               width=4, height=2, cursor="hand2",
                               relief="groove", bd=2)
        self.swatch.pack(side="left", padx=(0,8))
        self.swatch.bind("<Button-1>", lambda e: self._color_picker())

        hf = tk.Frame(cr, bg=UI_PANEL)
        hf.pack(side="left", fill="x", expand=True)
        tk.Label(hf, text="HEX", bg=UI_PANEL, fg=UI_TEXT,
                 font=("Courier",7)).pack(anchor="w")
        self.hex_var = tk.StringVar(value=_rgba_to_tk(self.current_color))
        he = tk.Entry(hf, textvariable=self.hex_var, width=9,
                      bg=UI_ENTRY_BG, fg=UI_TEXT,
                      insertbackground=UI_TEXT, relief="flat",
                      font=("Courier",10), bd=4)
        he.pack(fill="x")
        he.bind("<Return>", self._on_hex_enter)

        # Tools
        sep("TOOL")
        tf = tk.Frame(panel, bg=UI_PANEL)
        tf.pack(fill="x", padx=10, pady=6)
        self.tool_btns = {}
        for tid, lbl in [("draw","✏  Draw   [D]"),("erase","🧹 Erase  [E]"),
                          ("fill","🪣 Fill   [F]"),("eyedrop","💉 Pick   [I]")]:
            b = self._mk_btn(tf, lbl, lambda t=tid: self._set_tool(t),
                             width=18, anchor="w")
            b.pack(fill="x", pady=1)
            self.tool_btns[tid] = b
        self._highlight_tool("draw")

        # Brush size
        br = tk.Frame(panel, bg=UI_PANEL)
        br.pack(fill="x", padx=10, pady=2)
        tk.Label(br, text="Brush  [ / ]", bg=UI_PANEL, fg=UI_TEXT,
                 font=("Courier",8)).pack(side="left")
        self.brush_lbl = tk.Label(br, text="1px", bg=UI_PANEL,
                                  fg=UI_ACCENT, font=("Courier",9,"bold"))
        self.brush_lbl.pack(side="right")

        # Quick palette
        sep("QUICK PALETTE")
        pf = tk.Frame(panel, bg=UI_PANEL)
        pf.pack(fill="x", padx=10, pady=6)
        for idx, hx in enumerate(QUICK_PALETTE):
            r, c = divmod(idx, 5)
            sw = tk.Label(pf, bg=hx, width=2, height=1,
                          cursor="hand2", relief="flat", bd=1)
            sw.grid(row=r, column=c, padx=1, pady=1, sticky="nsew")
            sw.bind("<Button-1>", lambda e,h=hx: self._pick_palette(h))
        for c in range(5): pf.columnconfigure(c, weight=1)

        # Actions
        sep("ACTIONS")
        af = tk.Frame(panel, bg=UI_PANEL)
        af.pack(fill="x", padx=10, pady=6)
        for txt, cmd in [("↩  Undo  Ctrl+Z", self._undo),
                          ("✕  Clear canvas", self._clear),
                          ("📋  Copy code",    self._copy_code)]:
            self._mk_btn(af, txt, cmd, width=22, anchor="w").pack(fill="x", pady=2)

        tk.Button(af, text="▶  Save & Export  Ctrl+S",
                  bg=UI_ACCENT, fg="#fff",
                  activebackground="#c1121f", activeforeground="#fff",
                  font=("Courier",9,"bold"), relief="flat", bd=0,
                  padx=8, pady=8, cursor="hand2", anchor="w",
                  command=self._save).pack(fill="x", pady=(8,2))

        # Info
        sep("CANVAS INFO")
        self.info_var = tk.StringVar(
            value=f"{self.grid_w}×{self.grid_h}\ntool  draw\nbrush 1px")
        tk.Label(panel, textvariable=self.info_var, bg=UI_PANEL, fg=UI_TEXT,
                 font=("Courier",8), justify="left").pack(
            anchor="w", padx=10, pady=6)

    def _mk_btn(self, parent, text, cmd, width=None, anchor="center"):
        kw = dict(text=text, command=cmd, bg=UI_BTN, fg=UI_TEXT,
                  activebackground=UI_BTN_HVR, activeforeground=UI_TEXT,
                  font=("Courier",9), relief="flat", bd=0,
                  padx=8, pady=5, cursor="hand2", anchor=anchor)
        if width: kw["width"] = width
        return tk.Button(parent, **kw)

    # ── Rendering ─────────────────────────────────────────────────────────────

    def _render_all(self):
        cs = self.cell_size
        cw, ch = self.grid_w * cs, self.grid_h * cs
        self.cv.config(width=min(cw,920), height=min(ch,680),
                       scrollregion=(0,0,cw,ch))
        self.cv.delete("all")

        for y in range(self.grid_h):
            for x in range(self.grid_w):
                rgba = self.pixels[y * self.grid_w + x]
                fill = _checkerboard(x,y) if rgba[3]==0 else _rgba_to_tk(rgba)
                self.cv.create_rectangle(
                    x*cs, y*cs, x*cs+cs, y*cs+cs,
                    fill=fill, outline="", tags=(f"p{x}_{y}",))

        if self.show_grid and cs >= 4:
            # Tkinter only supports 6-digit hex colors — use stipple for
            # a faint grid effect instead of alpha transparency
            gc      = "#444466" if cs >= 8 else "#333355"
            stipple = "gray25"  if cs >= 8 else "gray12"
            for x in range(self.grid_w+1):
                self.cv.create_line(x*cs, 0, x*cs, ch,
                                    fill=gc, stipple=stipple, tags="grid")
            for y in range(self.grid_h+1):
                self.cv.create_line(0, y*cs, cw, y*cs,
                                    fill=gc, stipple=stipple, tags="grid")

    def _redraw_cell(self, x, y):
        if not (0 <= x < self.grid_w and 0 <= y < self.grid_h):
            return
        cs   = self.cell_size
        rgba = self.pixels[y * self.grid_w + x]
        fill = _checkerboard(x,y) if rgba[3]==0 else _rgba_to_tk(rgba)
        tag  = f"p{x}_{y}"
        self.cv.delete(tag)
        self.cv.create_rectangle(
            x*cs, y*cs, x*cs+cs, y*cs+cs,
            fill=fill, outline="", tags=(tag,))
        if self.show_grid:
            self.cv.tag_raise("grid")

    # ── Events ────────────────────────────────────────────────────────────────

    def _cell_at(self, event) -> Tuple[int,int]:
        cx = int(self.cv.canvasx(event.x))
        cy = int(self.cv.canvasy(event.y))
        return cx // self.cell_size, cy // self.cell_size

    def _on_press(self, event):
        self._push_history()
        self.painting   = True
        self.last_cell  = None
        self._prev_drag = None
        self._apply_tool(*self._cell_at(event))

    def _on_drag(self, event):
        if not self.painting: return
        xy = self._cell_at(event)
        if xy == self.last_cell: return
        self.last_cell = xy
        if self._prev_drag:
            for ix, iy in _bresenham(*self._prev_drag, *xy):
                self._apply_tool(ix, iy)
        else:
            self._apply_tool(*xy)
        self._prev_drag = xy

    def _on_release(self, event):
        self.painting   = False
        self._prev_drag = None

    def _on_hover(self, event):
        x, y = self._cell_at(event)
        if 0 <= x < self.grid_w and 0 <= y < self.grid_h:
            rgba = self.pixels[y * self.grid_w + x]
            self.info_var.set(
                f"{self.grid_w}×{self.grid_h}\n"
                f"pos   ({x}, {y})\n"
                f"color {to_hex(rgba)}\n"
                f"tool  {self.tool}  [{self.brush_size}px]")

    def _on_right_click(self, event):
        x, y = self._cell_at(event)
        if 0 <= x < self.grid_w and 0 <= y < self.grid_h:
            self._set_color(self.pixels[y * self.grid_w + x])
            self.status_var.set(f"picked {to_hex(self.pixels[y*self.grid_w+x])}")

    def _on_ctrl_wheel(self, event):
        if event.delta > 0: self._zoom_in()
        else: self._zoom_out()

    # ── Tool logic ────────────────────────────────────────────────────────────

    def _apply_tool(self, x, y):
        if self.tool == "draw":
            self._paint(x, y, self.current_color)
        elif self.tool == "erase":
            self._paint(x, y, (0,0,0,0))
        elif self.tool == "fill":
            self._flood_fill(x, y)
            self._render_all()
        elif self.tool == "eyedrop":
            if 0 <= x < self.grid_w and 0 <= y < self.grid_h:
                self._set_color(self.pixels[y * self.grid_w + x])
                self._set_tool("draw")

    def _paint(self, cx, cy, color):
        half = self.brush_size // 2
        extra = 1 if self.brush_size % 2 else 0
        for dy in range(-half, half+extra):
            for dx in range(-half, half+extra):
                x, y = cx+dx, cy+dy
                if 0 <= x < self.grid_w and 0 <= y < self.grid_h:
                    self.pixels[y * self.grid_w + x] = color
                    self._redraw_cell(x, y)

    def _flood_fill(self, sx, sy):
        if not (0 <= sx < self.grid_w and 0 <= sy < self.grid_h): return
        target = self.pixels[sy * self.grid_w + sx]
        rep    = self.current_color
        if target == rep: return
        q, vis = [(sx,sy)], set()
        while q:
            x, y = q.pop()
            if (x,y) in vis: continue
            if not (0<=x<self.grid_w and 0<=y<self.grid_h): continue
            if self.pixels[y*self.grid_w+x] != target: continue
            self.pixels[y*self.grid_w+x] = rep
            vis.add((x,y))
            q.extend([(x+1,y),(x-1,y),(x,y+1),(x,y-1)])

    # ── Color ─────────────────────────────────────────────────────────────────

    def _set_color(self, rgba):
        self.current_color = rgba
        hx = _rgba_to_tk(rgba)
        self.swatch.config(bg=hx)
        self.hex_var.set(hx)

    def _color_picker(self):
        res = colorchooser.askcolor(
            color=_rgba_to_tk(self.current_color), title="Choose color")
        if res and res[1]:
            self._set_color(_tk_to_rgba(res[1]))

    def _on_hex_enter(self, _=None):
        try:
            self._set_color(parse_color(self.hex_var.get().strip()))
        except Exception:
            self.hex_var.set(_rgba_to_tk(self.current_color))

    def _pick_palette(self, hx):
        self._set_color(_tk_to_rgba(hx))
        self.status_var.set(f"color → {hx}")

    # ── Tool switching ────────────────────────────────────────────────────────

    def _set_tool(self, t):
        self.tool = t
        self._highlight_tool(t)
        self.status_var.set(f"tool → {t}")

    def _highlight_tool(self, active):
        for tid, btn in self.tool_btns.items():
            btn.config(bg=UI_ACCENT if tid==active else UI_BTN,
                       fg="#fff"    if tid==active else UI_TEXT)

    def _brush_delta(self, d):
        self.brush_size = max(1, min(16, self.brush_size + d))
        self.brush_lbl.config(text=f"{self.brush_size}px")
        self.status_var.set(f"brush → {self.brush_size}px")

    # ── Zoom / grid ───────────────────────────────────────────────────────────

    def _zoom_in(self):
        self.cell_size = min(self.cell_size + 2, 64)
        self.zoom_lbl.config(text=f"{self.cell_size}px/cell")
        self._render_all()

    def _zoom_out(self):
        self.cell_size = max(self.cell_size - 2, MIN_CELL)
        self.zoom_lbl.config(text=f"{self.cell_size}px/cell")
        self._render_all()

    def _toggle_grid(self):
        self.show_grid = not self.show_grid
        if self.show_grid:
            self._render_all()
        else:
            self.cv.delete("grid")
        self.status_var.set(f"grid {'on' if self.show_grid else 'off'}")

    # ── History ───────────────────────────────────────────────────────────────

    def _push_history(self):
        self._history.append(list(self.pixels))
        if len(self._history) > 50: self._history.pop(0)

    def _undo(self):
        if not self._history:
            self.status_var.set("nothing to undo")
            return
        self.pixels = self._history.pop()
        self._render_all()
        self.status_var.set("undo ✓")

    def _clear(self):
        if messagebox.askyesno("Clear canvas", "Clear all pixels?",
                               parent=self.root):
            self._push_history()
            self.pixels = [(0,0,0,0)] * (self.grid_w * self.grid_h)
            self._render_all()
            self.status_var.set("cleared")

    def _copy_code(self):
        code = self._build_canvas().to_code()
        self.root.clipboard_clear()
        self.root.clipboard_append(code)
        self.status_var.set("code copied to clipboard ✓")

    def _save(self):
        dlg = _ExportDialog(self.root, self._build_canvas())
        self.root.wait_window(dlg.window)
        if dlg.confirmed:
            self.result = dlg.canvas
            self.status_var.set("exported ✓")
            self.root.after(300, self.root.destroy)

    def _build_canvas(self) -> Canvas:
        c = Canvas(self.grid_w, self.grid_h,
                   pixel_size=max(1, self.cell_size))
        c._pixels = list(self.pixels)
        return c


# ── Export dialog ─────────────────────────────────────────────────────────────

class _ExportDialog:
    def __init__(self, parent: tk.Tk, canvas: Canvas):
        self.canvas    = canvas
        self.confirmed = False

        self.window = tk.Toplevel(parent)
        self.window.title("Save & Export")
        self.window.configure(bg=UI_BG)
        self.window.resizable(False, False)
        self.window.grab_set()

        self._build()

        # Centre over parent
        self.window.update_idletasks()
        pw = parent.winfo_x() + parent.winfo_width()  // 2
        ph = parent.winfo_y() + parent.winfo_height() // 2
        ww = self.window.winfo_reqwidth()
        wh = self.window.winfo_reqheight()
        self.window.geometry(f"+{pw-ww//2}+{ph-wh//2}")

    def _build(self):
        c = self.canvas

        def sep(txt):
            f = tk.Frame(self.window, bg=UI_BG)
            f.pack(fill="x", padx=20, pady=(10,2))
            tk.Label(f, text=txt, bg=UI_BG, fg=UI_TEXT,
                     font=("Courier",9,"bold")).pack(side="left")
            tk.Frame(f, bg=UI_BORDER, height=1).pack(
                side="left", fill="x", expand=True, padx=(8,0), pady=6)

        tk.Label(self.window, text="EXPORT OPTIONS", bg=UI_BG, fg=UI_ACCENT,
                 font=("Courier",11,"bold")).pack(pady=(16,4))

        # ── PNG ───────────────────────────────────────────────────────────────
        sep("PNG")
        pr = tk.Frame(self.window, bg=UI_BG)
        pr.pack(fill="x", padx=20, pady=2)
        self.do_png = tk.BooleanVar(value=True)
        tk.Checkbutton(pr, text="Export PNG", variable=self.do_png,
                       bg=UI_BG, fg=UI_TEXT, selectcolor=UI_BTN,
                       activebackground=UI_BG, activeforeground=UI_TEXT,
                       font=("Courier",9)).pack(side="left")
        self.png_path = tk.StringVar(value="output.png")
        tk.Entry(pr, textvariable=self.png_path, width=24,
                 bg=UI_ENTRY_BG, fg=UI_TEXT, insertbackground=UI_TEXT,
                 font=("Courier",9), relief="flat", bd=4).pack(side="left",padx=4)
        tk.Button(pr, text="…", command=self._browse_png,
                  bg=UI_BTN, fg=UI_TEXT, relief="flat", bd=0,
                  font=("Courier",9), cursor="hand2", padx=6).pack(side="left")

        psr = tk.Frame(self.window, bg=UI_BG)
        psr.pack(fill="x", padx=36, pady=(0,4))
        tk.Label(psr, text="pixel_size:", bg=UI_BG, fg=UI_TEXT,
                 font=("Courier",8)).pack(side="left")
        self.png_ps = tk.IntVar(value=c.pixel_size)
        tk.Spinbox(psr, from_=1, to=64, textvariable=self.png_ps, width=4,
                   bg=UI_ENTRY_BG, fg=UI_TEXT, buttonbackground=UI_BTN,
                   font=("Courier",9), relief="flat").pack(side="left",padx=6)

        # ── HTML ──────────────────────────────────────────────────────────────
        sep("HTML / CSS  (choose one or more styles)")
        self.html_vars  = {}
        self.html_paths = {}
        styles = [
            ("grid",             "CSS Grid         — modern, compact"),
            ("table",            "HTML Table        — max compatibility"),
            ("custom-properties","CSS Variables     — easy to re-theme"),
        ]
        for sid, lbl in styles:
            row = tk.Frame(self.window, bg=UI_BG)
            row.pack(fill="x", padx=20, pady=2)
            v = tk.BooleanVar(value=True)
            self.html_vars[sid] = v
            tk.Checkbutton(row, text=lbl, variable=v,
                           bg=UI_BG, fg=UI_TEXT, selectcolor=UI_BTN,
                           activebackground=UI_BG, activeforeground=UI_TEXT,
                           font=("Courier",9), width=36, anchor="w").pack(side="left")
            p = tk.StringVar(value=f"output_{sid.replace('-','_')}.html")
            self.html_paths[sid] = p
            tk.Entry(row, textvariable=p, width=28,
                     bg=UI_ENTRY_BG, fg=UI_TEXT, insertbackground=UI_TEXT,
                     font=("Courier",9), relief="flat", bd=4).pack(side="left",padx=4)

        hpr = tk.Frame(self.window, bg=UI_BG)
        hpr.pack(fill="x", padx=36, pady=(0,6))
        tk.Label(hpr, text="HTML cell size (px):", bg=UI_BG, fg=UI_TEXT,
                 font=("Courier",8)).pack(side="left")
        self.html_ps = tk.IntVar(value=max(c.pixel_size, 8))
        tk.Spinbox(hpr, from_=1, to=64, textvariable=self.html_ps, width=4,
                   bg=UI_ENTRY_BG, fg=UI_TEXT, buttonbackground=UI_BTN,
                   font=("Courier",9), relief="flat").pack(side="left",padx=6)

        # ── Code preview ──────────────────────────────────────────────────────
        sep("GENERATED PYTHON CODE")
        cf = tk.Frame(self.window, bg=UI_BG)
        cf.pack(fill="x", padx=20, pady=4)
        ct = tk.Text(cf, height=7, width=66,
                     bg=UI_ENTRY_BG, fg="#a8d8a8",
                     font=("Courier",8), relief="flat", bd=4, wrap="none")
        ct.pack(side="left", fill="both", expand=True)
        sb = tk.Scrollbar(cf, command=ct.yview, bg=UI_BG)
        sb.pack(side="right", fill="y")
        ct.config(yscrollcommand=sb.set)
        ct.insert("1.0", c.to_code())
        ct.config(state="disabled")
        self._code_widget = ct

        # ── Buttons ───────────────────────────────────────────────────────────
        br = tk.Frame(self.window, bg=UI_BG)
        br.pack(fill="x", padx=20, pady=(8,16))
        tk.Button(br, text="Cancel",
                  bg=UI_BTN, fg=UI_TEXT, activebackground=UI_BTN_HVR,
                  font=("Courier",9), relief="flat", bd=0,
                  padx=16, pady=8, cursor="hand2",
                  command=self.window.destroy).pack(side="left", padx=4)
        tk.Button(br, text="📋 Copy code",
                  bg=UI_BTN, fg=UI_TEXT, activebackground=UI_BTN_HVR,
                  font=("Courier",9), relief="flat", bd=0,
                  padx=16, pady=8, cursor="hand2",
                  command=self._copy_code).pack(side="right", padx=4)
        tk.Button(br, text="▶  Export Selected",
                  bg=UI_ACCENT, fg="#fff", activebackground="#c1121f",
                  font=("Courier",9,"bold"), relief="flat", bd=0,
                  padx=16, pady=8, cursor="hand2",
                  command=self._do_export).pack(side="right", padx=4)

    def _browse_png(self):
        p = filedialog.asksaveasfilename(
            defaultextension=".png",
            filetypes=[("PNG","*.png")],
            initialfile=self.png_path.get())
        if p: self.png_path.set(p)

    def _do_export(self):
        from .exporter import save_png, save_html
        done = []

        if self.do_png.get():
            p = self.png_path.get().strip()
            if p:
                c2 = Canvas(self.canvas.width, self.canvas.height,
                            pixel_size=self.png_ps.get())
                c2._pixels = list(self.canvas._pixels)
                save_png(c2, p)
                done.append(f"PNG  →  {p}")

        hps = self.html_ps.get()
        for sid, var in self.html_vars.items():
            if var.get():
                p = self.html_paths[sid].get().strip()
                if p:
                    save_html(self.canvas, p, style=sid, pixel_size=hps)
                    done.append(f"{sid}  →  {p}")

        if done:
            messagebox.showinfo("Done", "\n".join(done))
            self.confirmed = True
            self.window.destroy()
        else:
            messagebox.showwarning("Nothing selected",
                                   "Tick at least one export option.")

    def _copy_code(self):
        code = self.canvas.to_code()
        self.window.clipboard_clear()
        self.window.clipboard_append(code)
        messagebox.showinfo("Copied", "Code copied to clipboard.")


# ── Public entry point ────────────────────────────────────────────────────────

def open_editor(
    width: int = 16,
    height: int = 16,
    pixel_size: int = DEFAULT_CELL,
    initial_canvas: Optional[Canvas] = None,
) -> Canvas:
    """
    Open the Tkinter pixel art editor and return the drawn canvas.

    Blocks until the window is closed. On "Save & Export" the canvas is
    returned and the equivalent Python code is printed to the terminal.

    Parameters
    ----------
    width, height   : int     Grid dimensions in pixels (max 128×128).
    pixel_size      : int     Initial cell size in the editor view.
    initial_canvas  : Canvas  Pre-populate from an existing canvas.

    Returns
    -------
    Canvas

    Example
    -------
    ::

        from pixelart_py.editor import open_editor

        canvas = open_editor(width=32, height=32)
        canvas.save("drawing.png")
        canvas.save_html("drawing.html", style="grid")
        canvas.save_html("drawing.html", style="table")
        canvas.save_html("drawing.html", style="custom-properties")
        print(canvas.to_code())
    """
    try:
        import tkinter  # noqa: F401
    except ImportError as exc:
        raise ImportError(
            "Tkinter not found.\n"
            "  Linux:   sudo apt-get install python3-tk\n"
            "  macOS:   use the installer from python.org\n"
            "  Windows: included with the standard installer"
        ) from exc

    if width > MAX_CANVAS or height > MAX_CANVAS:
        raise ValueError(
            f"Max canvas size is {MAX_CANVAS}×{MAX_CANVAS}. "
            f"Got {width}×{height}."
        )

    # Auto-reduce cell size for large canvases so the grid fits on screen
    if pixel_size == DEFAULT_CELL and width > 32:
        pixel_size = max(MIN_CELL, DEFAULT_CELL - (width - 32) // 8)

    root = tk.Tk()
    editor = PixelEditor(root, grid_w=width, grid_h=height,
                         cell_size=pixel_size, initial=initial_canvas)
    root.mainloop()

    canvas = editor.result
    if canvas is None:
        canvas = Canvas(width, height, pixel_size=pixel_size)

    print("\n── Generated Python code ──────────────────────────────────────")
    print(canvas.to_code())
    print("───────────────────────────────────────────────────────────────\n")
    return canvas