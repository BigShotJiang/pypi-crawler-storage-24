"""
pixelart_py.exporter
~~~~~~~~~~~~~~~~~~~~
Export a Canvas to different formats:
    - PNG  (via Pillow)
    - HTML/CSS  (three styles: grid, table, custom-properties)
"""

from __future__ import annotations
from typing import TYPE_CHECKING, Literal

if TYPE_CHECKING:
    from .canvas import Canvas

from .palette import to_hex

# ── PNG ────────────────────────────────────────────────────────────────────────

def to_png_image(canvas: "Canvas"):
    """Return a PIL.Image.Image of the canvas (RGBA, scaled by pixel_size)."""
    try:
        from PIL import Image
    except ImportError as exc:
        raise ImportError("pip install Pillow") from exc

    ps = canvas.pixel_size
    img = Image.new("RGBA", (canvas.width * ps, canvas.height * ps))
    for y in range(canvas.height):
        for x in range(canvas.width):
            color = canvas._pixels[y * canvas.width + x]
            for dy in range(ps):
                for dx in range(ps):
                    img.putpixel((x * ps + dx, y * ps + dy), color)
    return img


def save_png(canvas: "Canvas", path: str) -> None:
    """Save canvas as a PNG file."""
    img = to_png_image(canvas)
    img.save(path, format="PNG")
    print(f"[PNG]  Saved → {path}  ({canvas.width * canvas.pixel_size}×{canvas.height * canvas.pixel_size}px)")


# ── HTML / CSS ─────────────────────────────────────────────────────────────────

CSSStyle = Literal["grid", "table", "custom-properties"]


def save_html(
    canvas: "Canvas",
    path: str,
    style: CSSStyle = "grid",
    pixel_size: int = None,
    title: str = "Pixel Art",
) -> None:
    """
    Export canvas as a self-contained HTML file.

    Parameters
    ----------
    canvas     : Canvas
    path       : str            Output file path, e.g. "art.html"
    style      : str            "grid" | "table" | "custom-properties"
    pixel_size : int, optional  Override pixel_size for the HTML output.
    title      : str            Page <title> and heading.
    """
    ps = pixel_size or canvas.pixel_size
    html = _build_html(canvas, style=style, pixel_size=ps, title=title)
    with open(path, "w", encoding="utf-8") as f:
        f.write(html)
    print(f"[HTML] Saved → {path}  (style={style}, cell={ps}px)")


def to_html_string(
    canvas: "Canvas",
    style: CSSStyle = "grid",
    pixel_size: int = None,
    title: str = "Pixel Art",
) -> str:
    """Return the HTML as a string without saving."""
    ps = pixel_size or canvas.pixel_size
    return _build_html(canvas, style=style, pixel_size=ps, title=title)


# ── Internal builders ──────────────────────────────────────────────────────────

def _build_html(canvas: "Canvas", style: CSSStyle, pixel_size: int, title: str) -> str:
    if style == "grid":
        return _html_grid(canvas, pixel_size, title)
    elif style == "table":
        return _html_table(canvas, pixel_size, title)
    elif style == "custom-properties":
        return _html_custom_props(canvas, pixel_size, title)
    else:
        raise ValueError(f"Unknown style '{style}'. Choose: grid, table, custom-properties")


def _base_page(title: str, style_block: str, body: str) -> str:
    return f"""<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>{title}</title>
  <style>
    body {{
      margin: 0;
      min-height: 100vh;
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: center;
      background: #1a1a2e;
      font-family: monospace;
      color: #fff;
    }}
    h1 {{ margin-bottom: 16px; font-size: 14px; letter-spacing: 2px; opacity: 0.5; }}
{style_block}
  </style>
</head>
<body>
  <h1>{title.upper()}</h1>
{body}
</body>
</html>"""


# ── Style 1: CSS Grid ──────────────────────────────────────────────────────────

def _html_grid(canvas: "Canvas", ps: int, title: str) -> str:
    w, h = canvas.width, canvas.height

    style = f"""    .pixel-grid {{
      display: grid;
      grid-template-columns: repeat({w}, {ps}px);
      grid-template-rows: repeat({h}, {ps}px);
      gap: 0;
      image-rendering: pixelated;
    }}
    .pixel-grid .p {{
      width: {ps}px;
      height: {ps}px;
    }}"""

    cells = []
    for y in range(h):
        for x in range(w):
            rgba = canvas._pixels[y * w + x]
            hex_color = to_hex(rgba)
            alpha = rgba[3] / 255
            style_attr = f'background:{hex_color};opacity:{alpha:.2f}' if alpha < 1 else f'background:{hex_color}'
            cells.append(f'    <div class="p" style="{style_attr}"></div>')

    body = '  <div class="pixel-grid">\n' + "\n".join(cells) + "\n  </div>"
    return _base_page(title, style, body)


# ── Style 2: HTML Table ────────────────────────────────────────────────────────

def _html_table(canvas: "Canvas", ps: int, title: str) -> str:
    w, h = canvas.width, canvas.height

    style = f"""    table.pixel-table {{
      border-collapse: collapse;
      border-spacing: 0;
      image-rendering: pixelated;
    }}
    table.pixel-table td {{
      width: {ps}px;
      height: {ps}px;
      padding: 0;
    }}"""

    rows = []
    for y in range(h):
        cells = []
        for x in range(w):
            rgba = canvas._pixels[y * w + x]
            hex_color = to_hex(rgba)
            alpha = rgba[3] / 255
            bg = f'background:{hex_color};opacity:{alpha:.2f}' if alpha < 1 else f'background:{hex_color}'
            cells.append(f'      <td style="{bg}"></td>')
        rows.append("    <tr>\n" + "\n".join(cells) + "\n    </tr>")

    body = '  <table class="pixel-table">\n' + "\n".join(rows) + "\n  </table>"
    return _base_page(title, style, body)


# ── Style 3: CSS Custom Properties ────────────────────────────────────────────

def _html_custom_props(canvas: "Canvas", ps: int, title: str) -> str:
    """
    Generates a stylesheet where each unique color gets a CSS custom property,
    making it easy to re-theme the art by editing variables.
    """
    w, h = canvas.width, canvas.height

    # Build color → variable name mapping
    unique_colors = {}
    for rgba in canvas._pixels:
        hex_c = to_hex(rgba)
        if hex_c not in unique_colors:
            idx = len(unique_colors)
            unique_colors[hex_c] = f"--c{idx}"

    # CSS variables block
    vars_css = "\n".join(
        f"      {var}: {hex_c};" for hex_c, var in unique_colors.items()
    )

    style = f"""    :root {{
{vars_css}
    }}
    .pixel-grid {{
      display: grid;
      grid-template-columns: repeat({w}, {ps}px);
      image-rendering: pixelated;
    }}
    .pixel-grid .p {{
      width: {ps}px;
      height: {ps}px;
    }}"""

    cells = []
    for y in range(h):
        for x in range(w):
            rgba = canvas._pixels[y * w + x]
            hex_c = to_hex(rgba)
            var = unique_colors[hex_c]
            cells.append(f'    <div class="p" style="background:var({var})"></div>')

    # Also emit the color legend as a comment
    legend = "\n".join(f"  /* {var}: {hex_c} */" for hex_c, var in unique_colors.items())
    body = (
        f"  <!-- Color variables:\n{legend}\n  -->\n"
        '  <div class="pixel-grid">\n'
        + "\n".join(cells)
        + "\n  </div>"
    )
    return _base_page(title, style, body)


# ── Python code generator ──────────────────────────────────────────────────────

def to_python_code(canvas: "Canvas", var_name: str = "canvas") -> str:
    """
    Convert a canvas back into the Python pixelart-py code that would
    recreate it. Useful after hand-drawing in the editor.

    Returns
    -------
    str   Runnable Python source code.
    """
    w, h, ps = canvas.width, canvas.height, canvas.pixel_size
    lines = [
        "from pixelart_py import Canvas\n",
        f"{var_name} = Canvas({w}, {h}, pixel_size={ps})\n",
    ]

    # Group consecutive pixels of the same color into draw_rect calls
    # for compactness; single pixels use set_pixel.
    visited = [[False] * w for _ in range(h)]
    calls = []

    for y in range(h):
        for x in range(w):
            if visited[y][x]:
                continue
            rgba = canvas._pixels[y * w + x]
            if rgba[3] == 0:          # skip fully transparent
                visited[y][x] = True
                continue

            hex_c = _rgba_to_arg(rgba)

            # Greedy rectangle expansion
            rw = 1
            while x + rw < w and not visited[y][x + rw] and canvas._pixels[y * w + x + rw] == rgba:
                rw += 1
            rh = 1
            can_expand = True
            while can_expand and y + rh < h:
                for dx in range(rw):
                    if visited[y + rh][x + dx] or canvas._pixels[(y + rh) * w + x + dx] != rgba:
                        can_expand = False
                        break
                if can_expand:
                    rh += 1

            # Mark visited
            for dy in range(rh):
                for dx in range(rw):
                    visited[y + dy][x + dx] = True

            if rw == 1 and rh == 1:
                calls.append(f"{var_name}.set_pixel({x}, {y}, {hex_c})")
            else:
                calls.append(f"{var_name}.draw_rect({x}, {y}, {rw}, {rh}, {hex_c})")

    lines.append("\n".join(calls))
    lines.append(f'\n{var_name}.save("output.png")')
    return "\n".join(lines)


def _rgba_to_arg(rgba: tuple) -> str:
    """Return the shortest color literal for use in generated code."""
    r, g, b, a = rgba
    if a == 255:
        return f'"#{r:02x}{g:02x}{b:02x}"'
    return f'({r}, {g}, {b}, {a})'
