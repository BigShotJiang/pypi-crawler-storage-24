"""
pixelart-py
~~~~~~~~~~~
A simple, expressive Python library for creating pixel art programmatically.

Features
--------
- Canvas with configurable grid + pixel scale
- Drawing primitives: rect, line, circle, flood fill
- Named color palettes + universal color parsing
- PNG export (via Pillow)
- HTML/CSS export — grid, table, or CSS custom properties
- Browser-based hand-drawing editor that outputs Python code

Quick start
-----------
::

    from pixelart_py import Canvas

    canvas = Canvas(16, 16, pixel_size=20)
    canvas.fill("#1a1a2e")
    canvas.draw_circle(8, 8, 6, "#e63946", filled=True)
    canvas.save("art.png")
    canvas.save_html("art.html", style="grid")
    print(canvas.to_code())

Hand-drawing editor
-------------------
::

    from pixelart_py.editor import open_editor

    canvas = open_editor(width=16, height=16, pixel_size=24)
    canvas.save("my_drawing.png")
"""

from .canvas import Canvas
from .palette import Palette, parse_color, to_hex, CLASSIC, PASTEL, EARTHY
from . import drawing
from .exporter import save_png, save_html, to_html_string, to_python_code

__all__ = [
    "Canvas",
    "Palette",
    "parse_color",
    "to_hex",
    "CLASSIC",
    "PASTEL",
    "EARTHY",
    "drawing",
    "save_png",
    "save_html",
    "to_html_string",
    "to_python_code",
]

__version__ = "1.0.0"
__author__ = "pixelart-py contributors"
