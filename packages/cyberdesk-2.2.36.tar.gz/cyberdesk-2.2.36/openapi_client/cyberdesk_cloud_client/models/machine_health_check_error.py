from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

T = TypeVar("T", bound="MachineHealthCheckError")


@_attrs_define
class MachineHealthCheckError:
    """
    Attributes:
        machine_id (str):
        error (str):
        organization_id (None | str | Unset):
        machine_name (None | str | Unset):
        status_code (int | None | Unset):
    """

    machine_id: str
    error: str
    organization_id: None | str | Unset = UNSET
    machine_name: None | str | Unset = UNSET
    status_code: int | None | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        machine_id = self.machine_id

        error = self.error

        organization_id: None | str | Unset
        if isinstance(self.organization_id, Unset):
            organization_id = UNSET
        else:
            organization_id = self.organization_id

        machine_name: None | str | Unset
        if isinstance(self.machine_name, Unset):
            machine_name = UNSET
        else:
            machine_name = self.machine_name

        status_code: int | None | Unset
        if isinstance(self.status_code, Unset):
            status_code = UNSET
        else:
            status_code = self.status_code

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "machine_id": machine_id,
                "error": error,
            }
        )
        if organization_id is not UNSET:
            field_dict["organization_id"] = organization_id
        if machine_name is not UNSET:
            field_dict["machine_name"] = machine_name
        if status_code is not UNSET:
            field_dict["status_code"] = status_code

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        machine_id = d.pop("machine_id")

        error = d.pop("error")

        def _parse_organization_id(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        organization_id = _parse_organization_id(d.pop("organization_id", UNSET))

        def _parse_machine_name(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        machine_name = _parse_machine_name(d.pop("machine_name", UNSET))

        def _parse_status_code(data: object) -> int | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(int | None | Unset, data)

        status_code = _parse_status_code(d.pop("status_code", UNSET))

        machine_health_check_error = cls(
            machine_id=machine_id,
            error=error,
            organization_id=organization_id,
            machine_name=machine_name,
            status_code=status_code,
        )

        machine_health_check_error.additional_properties = d
        return machine_health_check_error

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
