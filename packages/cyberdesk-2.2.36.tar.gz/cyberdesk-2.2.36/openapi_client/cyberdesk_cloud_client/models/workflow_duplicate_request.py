from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

T = TypeVar("T", bound="WorkflowDuplicateRequest")


@_attrs_define
class WorkflowDuplicateRequest:
    """Schema for duplicating workflows.

    Attributes:
        include_trajectories (bool | Unset): Whether to duplicate generated trajectories onto the copied workflow. Non-
            generated trajectories are never duplicated. Default: False.
    """

    include_trajectories: bool | Unset = False
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        include_trajectories = self.include_trajectories

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if include_trajectories is not UNSET:
            field_dict["include_trajectories"] = include_trajectories

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        include_trajectories = d.pop("include_trajectories", UNSET)

        workflow_duplicate_request = cls(
            include_trajectories=include_trajectories,
        )

        workflow_duplicate_request.additional_properties = d
        return workflow_duplicate_request

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
