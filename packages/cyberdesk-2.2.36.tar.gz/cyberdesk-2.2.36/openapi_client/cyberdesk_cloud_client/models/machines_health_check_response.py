from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..models.machines_health_check_response_scope import MachinesHealthCheckResponseScope
from ..models.machines_health_check_response_status import MachinesHealthCheckResponseStatus

if TYPE_CHECKING:
    from ..models.machine_health_check_error import MachineHealthCheckError


T = TypeVar("T", bound="MachinesHealthCheckResponse")


@_attrs_define
class MachinesHealthCheckResponse:
    """
    Attributes:
        status (MachinesHealthCheckResponseStatus):
        scope (MachinesHealthCheckResponseScope):
        checked_machines (int):
        healthy_machines (int):
        errored_machines (list[MachineHealthCheckError]):
        message (str):
    """

    status: MachinesHealthCheckResponseStatus
    scope: MachinesHealthCheckResponseScope
    checked_machines: int
    healthy_machines: int
    errored_machines: list[MachineHealthCheckError]
    message: str
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        status = self.status.value

        scope = self.scope.value

        checked_machines = self.checked_machines

        healthy_machines = self.healthy_machines

        errored_machines = []
        for errored_machines_item_data in self.errored_machines:
            errored_machines_item = errored_machines_item_data.to_dict()
            errored_machines.append(errored_machines_item)

        message = self.message

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "status": status,
                "scope": scope,
                "checked_machines": checked_machines,
                "healthy_machines": healthy_machines,
                "errored_machines": errored_machines,
                "message": message,
            }
        )

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.machine_health_check_error import MachineHealthCheckError

        d = dict(src_dict)
        status = MachinesHealthCheckResponseStatus(d.pop("status"))

        scope = MachinesHealthCheckResponseScope(d.pop("scope"))

        checked_machines = d.pop("checked_machines")

        healthy_machines = d.pop("healthy_machines")

        errored_machines = []
        _errored_machines = d.pop("errored_machines")
        for errored_machines_item_data in _errored_machines:
            errored_machines_item = MachineHealthCheckError.from_dict(errored_machines_item_data)

            errored_machines.append(errored_machines_item)

        message = d.pop("message")

        machines_health_check_response = cls(
            status=status,
            scope=scope,
            checked_machines=checked_machines,
            healthy_machines=healthy_machines,
            errored_machines=errored_machines,
            message=message,
        )

        machines_health_check_response.additional_properties = d
        return machines_health_check_response

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
