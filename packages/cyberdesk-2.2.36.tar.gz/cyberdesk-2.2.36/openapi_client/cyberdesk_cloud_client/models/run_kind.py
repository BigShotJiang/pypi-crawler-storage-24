from enum import Enum


class RunKind(str, Enum):
    AD_HOC = "ad_hoc"
    WORKFLOW = "workflow"

    def __str__(self) -> str:
        return str(self.value)
