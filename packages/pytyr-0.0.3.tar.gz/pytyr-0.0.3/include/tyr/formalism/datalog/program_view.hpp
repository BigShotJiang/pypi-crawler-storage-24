/*
 * Copyright (C) 2025 Dominik Drexler
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program. If not, see <https://www.gnu.org/licenses/>.
 */

#ifndef TYR_FORMALISM_DATALOG_PROGRAM_VIEW_HPP_
#define TYR_FORMALISM_DATALOG_PROGRAM_VIEW_HPP_

#include "tyr/common/types.hpp"
#include "tyr/common/vector.hpp"
#include "tyr/formalism/datalog/declarations.hpp"
#include "tyr/formalism/datalog/ground_atom_index.hpp"
#include "tyr/formalism/datalog/ground_function_term_value_index.hpp"
#include "tyr/formalism/datalog/program_index.hpp"
#include "tyr/formalism/datalog/rule_view.hpp"
#include "tyr/formalism/function_index.hpp"
#include "tyr/formalism/predicate_index.hpp"

namespace tyr
{
template<formalism::datalog::Context C>
class View<Index<formalism::datalog::Program>, C>
{
private:
    const C* m_context;
    Index<formalism::datalog::Program> m_handle;

public:
    View(Index<formalism::datalog::Program> data, const C& context) noexcept : m_context(&context), m_handle(data) {}

    const auto& get_data() const noexcept { return get_repository(*m_context)[m_handle]; }
    const auto& get_context() const noexcept { return *m_context; }
    const auto& get_handle() const noexcept { return m_handle; }

    auto get_index() const noexcept { return m_handle; }
    template<formalism::FactKind T>
    auto get_predicates() const noexcept
    {
        return make_view(get_data().template get_predicates<T>(), *m_context);
    }
    template<formalism::FactKind T>
    auto get_functions() const noexcept
    {
        return make_view(get_data().template get_functions<T>(), *m_context);
    }
    auto get_objects() const noexcept { return make_view(get_data().objects, *m_context); }
    template<formalism::FactKind T>
    auto get_atoms() const noexcept
    {
        return make_view(get_data().template get_atoms<T>(), *m_context);
    }
    template<formalism::FactKind T>
    auto get_fterm_values() const noexcept
    {
        return make_view(get_data().template get_fterm_values<T>(), *m_context);
    }
    auto get_rules() const noexcept { return make_view(get_data().rules, *m_context); }

    auto identifying_members() const noexcept { return std::tie(m_context, m_handle); }
};
}

#endif
