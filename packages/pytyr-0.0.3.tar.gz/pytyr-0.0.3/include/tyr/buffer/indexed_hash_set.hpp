/*
 * Copyright (C) 2025 Dominik Drexler
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *<
 * You should have received a copy of the GNU General Public License
 * along with this program. If not, see <https://www.gnu.org/licenses/>.
 */

#ifndef TYR_BUFFER_INDEXED_HASH_SET_HPP_
#define TYR_BUFFER_INDEXED_HASH_SET_HPP_

#include "cista/serialization.h"
#include "tyr/buffer/declarations.hpp"
#include "tyr/buffer/segmented_buffer.hpp"
#include "tyr/common/config.hpp"
#include "tyr/common/equal_to.hpp"
#include "tyr/common/hash.hpp"
#include "tyr/common/observer_ptr.hpp"
#include "tyr/common/segmented_vector.hpp"
#include "tyr/common/types.hpp"

#include <functional>
#include <gtl/phmap.hpp>
#include <utility>
#include <vector>

namespace tyr::buffer
{
template<typename Tag, typename H, typename E>
class IndexedHashSet
{
private:
    // Deduplication
    gtl::flat_hash_set<ObserverPtr<const Data<Tag>>, H, E> m_set;

    // Randomized access
    std::vector<const Data<Tag>*> m_vec;

public:
    explicit IndexedHashSet() : m_set(), m_vec() {}
    IndexedHashSet(const IndexedHashSet& other) = delete;
    IndexedHashSet& operator=(const IndexedHashSet& other) = delete;
    IndexedHashSet(IndexedHashSet&& other) = default;
    IndexedHashSet& operator=(IndexedHashSet&& other) = default;

    /**
     * Iterators
     */

    auto begin() const noexcept { return m_vec.begin(); }
    auto end() const noexcept { return m_vec.end(); }

    /**
     * Capacity
     */

    bool empty() const noexcept { return m_vec.empty(); }
    size_t size() const noexcept { return m_vec.size(); }

    /**
     * Modifiers
     */

    void clear()
    {
        m_set.clear();
        m_vec.clear();
    }

    size_t hash(const Data<Tag>& element) const noexcept { return m_set.hash(make_observer(element)); }

    const Data<Tag>* find_with_hash(const Data<Tag>& element, size_t h) const noexcept
    {
        assert(is_canonical(element) && "The given element is not canonical. Did you forget to call canonicalize?");
        assert(h == hash(element) && "The given hash does not match container internal's hash.");

        const auto it = m_set.find(make_observer(element), h);
        if (it != m_set.end())
            return it->get();

        return nullptr;
    }

    const Data<Tag>* find(const Data<Tag>& element) const noexcept
    {
        assert(is_canonical(element));

        return find_with_hash(element, hash(element));
    }

    template<::cista::mode Mode = CISTA_MODE>
    std::pair<const Data<Tag>*, bool> insert_with_hash(size_t h, const Data<Tag>& element, ::cista::buf<std::vector<uint8_t>>& buf, SegmentedBuffer& arena)
    {
        assert(is_canonical(element) && "The given element is not canonical. Did you forget to call canonicalize?");
        assert(h == hash(element) && "The given hash does not match container internal's hash.");

        // 1. Check if element already exists

        auto it = m_set.find(make_observer(element), h);
        if (it != m_set.end())
            return std::make_pair(it->get(), false);

        // 2. Serialize
        buf.reset();
        ::cista::serialize<Mode>(buf, element);

        // 3. Write to storage
        auto begin = arena.write(buf.base(), buf.size(), alignof(Data<Tag>));

        // 4. Insert into set
        const auto serialized_element = ::cista::deserialize<const Data<Tag>, Mode>(begin, begin + buf.size());
        auto [it2, inserted] = m_set.emplace_with_hash(h, serialized_element);
        assert(inserted);

        // 5. Insert to vec
        m_vec.push_back(it2->get());

        return std::make_pair(it2->get(), true);
    }

    // const T* always points to a valid instantiation of the class.
    // We return const T* here to avoid bugs when using structured bindings.
    template<::cista::mode Mode = CISTA_MODE>
    std::pair<const Data<Tag>*, bool> insert(const Data<Tag>& element, ::cista::buf<std::vector<uint8_t>>& buf, SegmentedBuffer& arena)
    {
        assert(is_canonical(element));

        return insert_with_hash<Mode>(hash(element), element, buf, arena);
    }

    /**
     * Lookup
     */

    const Data<Tag>& operator[](Index<Tag> index) const noexcept
    {
        // std::cout << index.get_value() << " " << m_vec.size() << std::endl;
        assert(index.get_value() < m_vec.size());
        return *m_vec[index.get_value()];
    }

    const Data<Tag>& front() const
    {
        assert(!m_vec.empty());
        return *m_vec.front();
    }
};

}

#endif
