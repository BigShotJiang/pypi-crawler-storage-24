"""SaltShaker test suite"""
