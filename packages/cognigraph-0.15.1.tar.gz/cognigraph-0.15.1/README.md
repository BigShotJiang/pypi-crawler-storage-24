# cognigraph is now graqle

**CogniGraph has been renamed to [Graqle](https://graqle.com).**

## Migrate

```bash
pip uninstall cognigraph
pip install graqle
```

## What changed

| Before | After |
|--------|-------|
| `pip install cognigraph` | `pip install graqle` |
| `from cognigraph import CogniGraph` | `from graqle.core.graph import Graqle` |
| `kogni reason "..."` | `graq reason "..."` |
| `kogni_context` (MCP) | `graq_context` (MCP) |

## Why

The name CogniGraph conflicted with an existing domain. Graqle is the new brand — same team, same code, better name.

**Query your architecture, not your files.**

Learn more at [graqle.com](https://graqle.com)
