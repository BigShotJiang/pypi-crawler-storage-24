"""
DEPRECATED: cognigraph has been renamed to graqle.

Install the new package:
    pip install graqle

Update your imports:
    # Old:
    from cognigraph import CogniGraph
    # New:
    from graqle.core.graph import Graqle

CLI command changed from 'kogni' to 'graq'.
MCP tools changed from 'kogni_*' to 'graq_*'.

Learn more: https://graqle.com
"""

import warnings

warnings.warn(
    "cognigraph has been renamed to 'graqle'. "
    "Install with: pip install graqle | "
    "CLI: 'graq' (was 'kogni') | "
    "Docs: https://graqle.com",
    DeprecationWarning,
    stacklevel=2,
)

# Re-export from graqle for backward compatibility
try:
    from graqle.core.graph import Graqle as CogniGraph  # noqa: F401
    from graqle.__version__ import __version__  # noqa: F401
except ImportError:
    pass
