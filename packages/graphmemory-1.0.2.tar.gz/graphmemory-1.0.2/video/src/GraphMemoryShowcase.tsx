import React from "react";
import { AbsoluteFill, Sequence } from "remotion";
import { TransitionSeries, linearTiming } from "@remotion/transitions";
import { fade } from "@remotion/transitions/fade";
import { slide } from "@remotion/transitions/slide";
import { Background } from "./components/Background";
import { IntroScene } from "./scenes/IntroScene";
import { NodeEdgeScene } from "./scenes/NodeEdgeScene";
import { VectorSearchScene } from "./scenes/VectorSearchScene";
import { QueryBuilderScene } from "./scenes/QueryBuilderScene";
import { AlgorithmsScene } from "./scenes/AlgorithmsScene";
import { ExtractionScene } from "./scenes/ExtractionScene";
import { RetrievalScene } from "./scenes/RetrievalScene";
import { ExportScene } from "./scenes/ExportScene";
import { OutroScene } from "./scenes/OutroScene";
import { loadFont } from "@remotion/google-fonts/Inter";

const { fontFamily } = loadFont("normal", {
  weights: ["400", "600", "700", "800", "900"],
  subsets: ["latin"],
});

const FPS = 30;
const TRANSITION_FRAMES = 15;

const scenes = [
  { component: IntroScene, duration: 6 * FPS },
  { component: NodeEdgeScene, duration: 8 * FPS },
  { component: VectorSearchScene, duration: 8 * FPS },
  { component: QueryBuilderScene, duration: 7 * FPS },
  { component: AlgorithmsScene, duration: 7 * FPS },
  { component: ExtractionScene, duration: 7 * FPS },
  { component: RetrievalScene, duration: 8 * FPS },
  { component: ExportScene, duration: 7 * FPS },
  { component: OutroScene, duration: 5 * FPS },
];

export const GraphMemoryShowcase: React.FC = () => {
  return (
    <AbsoluteFill style={{ fontFamily }}>
      <Background />
      <TransitionSeries>
        {scenes.map((scene, i) => {
          const Scene = scene.component;
          return (
            <React.Fragment key={i}>
              {i > 0 && (
                <TransitionSeries.Transition
                  presentation={i % 2 === 0 ? fade() : slide({ direction: "from-right" })}
                  timing={linearTiming({ durationInFrames: TRANSITION_FRAMES })}
                />
              )}
              <TransitionSeries.Sequence durationInFrames={scene.duration}>
                <Scene />
              </TransitionSeries.Sequence>
            </React.Fragment>
          );
        })}
      </TransitionSeries>
    </AbsoluteFill>
  );
};
