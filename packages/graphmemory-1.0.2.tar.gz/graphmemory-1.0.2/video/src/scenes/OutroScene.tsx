import React from "react";
import {
  AbsoluteFill,
  useCurrentFrame,
  useVideoConfig,
  spring,
  interpolate,
} from "remotion";
import { COLORS, FONT } from "../theme";

export const OutroScene: React.FC = () => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();

  const titleEntrance = spring({ frame, fps, delay: 5, config: { damping: 200 } });
  const installEntrance = spring({ frame, fps, delay: 20, config: { damping: 200 } });
  const linksEntrance = spring({ frame, fps, delay: 35, config: { damping: 200 } });
  const testEntrance = spring({ frame, fps, delay: 50, config: { damping: 200 } });

  const glowPulse = 0.5 + 0.5 * Math.sin(frame * 0.06);

  return (
    <AbsoluteFill
      style={{
        justifyContent: "center",
        alignItems: "center",
        flexDirection: "column",
        gap: 32,
      }}
    >
      <div
        style={{
          opacity: titleEntrance,
          transform: `translateY(${(1 - titleEntrance) * 50}px)`,
          fontSize: 72,
          fontWeight: 900,
          fontFamily: FONT.sans,
          letterSpacing: -2,
          background: `linear-gradient(135deg, ${COLORS.accent}, ${COLORS.purple})`,
          WebkitBackgroundClip: "text",
          WebkitTextFillColor: "transparent",
          textAlign: "center",
          filter: `drop-shadow(0 0 ${30 * glowPulse}px ${COLORS.accentGlow}40)`,
        }}
      >
        Get Started Today
      </div>

      <div
        style={{
          opacity: installEntrance,
          transform: `translateY(${(1 - installEntrance) * 30}px)`,
          background: COLORS.codeBg,
          border: `1px solid ${COLORS.codeBorder}`,
          borderRadius: 16,
          padding: "20px 48px",
          fontFamily: FONT.mono,
          fontSize: 30,
          color: COLORS.green,
        }}
      >
        <span style={{ color: COLORS.textMuted }}>$</span> pip install graphmemory
      </div>

      <div
        style={{
          opacity: linksEntrance,
          transform: `translateY(${(1 - linksEntrance) * 20}px)`,
          display: "flex",
          gap: 40,
          marginTop: 8,
        }}
      >
        {[
          { label: "PyPI", value: "pypi.org/project/graphmemory", color: COLORS.accent },
          { label: "GitHub", value: "github.com/bradAGI/GraphMemory", color: COLORS.text },
        ].map((link) => (
          <div
            key={link.label}
            style={{
              display: "flex",
              flexDirection: "column",
              alignItems: "center",
              gap: 6,
            }}
          >
            <div
              style={{
                fontFamily: FONT.sans,
                fontSize: 16,
                fontWeight: 600,
                color: COLORS.textMuted,
                textTransform: "uppercase",
                letterSpacing: 2,
              }}
            >
              {link.label}
            </div>
            <div
              style={{
                fontFamily: FONT.mono,
                fontSize: 20,
                color: link.color,
              }}
            >
              {link.value}
            </div>
          </div>
        ))}
      </div>

      {/* Test badge */}
      <div
        style={{
          opacity: testEntrance,
          transform: `translateY(${(1 - testEntrance) * 20}px)`,
          display: "flex",
          alignItems: "center",
          gap: 12,
          marginTop: 16,
          background: `${COLORS.green}15`,
          border: `1px solid ${COLORS.green}40`,
          borderRadius: 12,
          padding: "12px 28px",
        }}
      >
        <div style={{ fontSize: 24 }}>✅</div>
        <div
          style={{
            fontFamily: FONT.sans,
            fontSize: 22,
            fontWeight: 600,
            color: COLORS.green,
          }}
        >
          239 tests passing
        </div>
      </div>
    </AbsoluteFill>
  );
};
