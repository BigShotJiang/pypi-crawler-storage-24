import React from "react";
import {
  AbsoluteFill,
  useCurrentFrame,
  useVideoConfig,
  spring,
  interpolate,
} from "remotion";
import { SectionTitle } from "../components/SectionTitle";
import { CodeBlock } from "../components/CodeBlock";
import { COLORS, FONT } from "../theme";

const CODE = `# Vector similarity search
results = graph.nearest_nodes(
  vector=[0.1, 0.8, 0.3, ...],
  limit=5)

# Full-text search with BM25
results = graph.search_nodes(
  "machine learning", limit=10)

# Hybrid: text + vector combined
results = graph.hybrid_search(
  query_text="neural networks",
  query_vector=embedding,
  text_weight=0.5,
  vector_weight=0.5)`;

type DotProps = {
  x: number;
  y: number;
  label: string;
  dist: number;
  isQuery?: boolean;
  delay: number;
};

const Dot: React.FC<DotProps> = ({ x, y, label, dist, isQuery, delay }) => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();
  const entrance = spring({ frame, fps, delay, config: { damping: 200 } });

  const ringRadius = isQuery ? 0 : interpolate(
    Math.max(0, frame - delay - 10),
    [0, 30],
    [0, 60 - dist * 40],
    { extrapolateRight: "clamp" }
  );

  return (
    <g transform={`translate(${x}, ${y})`} opacity={entrance}>
      {!isQuery && ringRadius > 0 && (
        <circle r={ringRadius} fill="none" stroke={COLORS.accent} strokeWidth={1} opacity={0.3} />
      )}
      <circle
        r={isQuery ? 10 : 7}
        fill={isQuery ? COLORS.pink : interpolateColor(dist)}
        stroke={isQuery ? COLORS.pink : "none"}
        strokeWidth={2}
      />
      <text
        textAnchor="middle"
        dy={-16}
        fill={COLORS.text}
        fontSize={12}
        fontFamily="Inter, sans-serif"
      >
        {label}
      </text>
      {!isQuery && (
        <text
          textAnchor="middle"
          dy={22}
          fill={COLORS.textMuted}
          fontSize={10}
          fontFamily="Inter, sans-serif"
        >
          d={dist.toFixed(2)}
        </text>
      )}
    </g>
  );
};

const interpolateColor = (dist: number): string => {
  if (dist < 0.3) return COLORS.green;
  if (dist < 0.6) return COLORS.yellow;
  return COLORS.orange;
};

const POINTS = [
  { x: 250, y: 180, label: "Query", dist: 0, isQuery: true },
  { x: 290, y: 140, label: "Doc A", dist: 0.12 },
  { x: 210, y: 220, label: "Doc B", dist: 0.18 },
  { x: 320, y: 210, label: "Doc C", dist: 0.35 },
  { x: 160, y: 140, label: "Doc D", dist: 0.52 },
  { x: 370, y: 120, label: "Doc E", dist: 0.71 },
  { x: 140, y: 280, label: "Doc F", dist: 0.85 },
  { x: 400, y: 280, label: "Doc G", dist: 0.93 },
];

export const VectorSearchScene: React.FC = () => {
  return (
    <AbsoluteFill
      style={{ justifyContent: "flex-start", alignItems: "center", padding: 60 }}
    >
      <SectionTitle
        title="Search"
        subtitle="Vector similarity, full-text BM25, and hybrid search in one API"
      />
      <div
        style={{
          display: "flex",
          gap: 60,
          marginTop: 50,
          width: "100%",
          justifyContent: "center",
          alignItems: "center",
        }}
      >
        <div style={{ flex: "0 0 auto" }}>
          <CodeBlock code={CODE} delay={15} typingSpeed={2.5} />
        </div>
        <div style={{ flex: "0 0 auto" }}>
          <svg width={500} height={400} viewBox="0 0 500 400">
            <text
              x={250}
              y={30}
              textAnchor="middle"
              fill={COLORS.textMuted}
              fontSize={14}
              fontFamily="Inter, sans-serif"
            >
              Vector Space
            </text>
            {/* Concentric distance rings */}
            {[80, 150, 220].map((r, i) => (
              <circle
                key={r}
                cx={250}
                cy={180}
                r={r}
                fill="none"
                stroke={COLORS.codeBorder}
                strokeWidth={1}
                strokeDasharray="4 4"
                opacity={0.4}
              />
            ))}
            {POINTS.map((p, i) => (
              <Dot key={i} {...p} delay={20 + i * 5} />
            ))}
          </svg>
        </div>
      </div>
    </AbsoluteFill>
  );
};
