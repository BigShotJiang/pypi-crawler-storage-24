import React from "react";
import {
  AbsoluteFill,
  useCurrentFrame,
  useVideoConfig,
  spring,
  interpolate,
} from "remotion";
import { COLORS, FONT } from "../theme";
import { FeaturePill } from "../components/FeaturePill";

export const IntroScene: React.FC = () => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();

  const logoScale = spring({ frame, fps, config: { damping: 12 } });
  const titleEntrance = spring({ frame, fps, delay: 10, config: { damping: 200 } });
  const subtitleEntrance = spring({ frame, fps, delay: 20, config: { damping: 200 } });
  const installEntrance = spring({ frame, fps, delay: 35, config: { damping: 200 } });

  const glowPulse = 0.6 + 0.4 * Math.sin(frame * 0.08);

  const features = [
    "DuckDB",
    "Vector Search",
    "Full-Text Search",
    "Graph Traversal",
    "NetworkX",
    "DSPy Extraction",
    "GraphRAG",
  ];

  return (
    <AbsoluteFill
      style={{
        justifyContent: "center",
        alignItems: "center",
        flexDirection: "column",
        gap: 24,
      }}
    >
      {/* Graph icon */}
      <svg
        width={120}
        height={120}
        viewBox="0 0 120 120"
        style={{
          transform: `scale(${logoScale})`,
          filter: `drop-shadow(0 0 ${20 * glowPulse}px ${COLORS.accentGlow})`,
        }}
      >
        <circle cx={35} cy={35} r={12} fill={COLORS.accent} opacity={0.9} />
        <circle cx={85} cy={30} r={12} fill={COLORS.purple} opacity={0.9} />
        <circle cx={60} cy={85} r={12} fill={COLORS.green} opacity={0.9} />
        <circle cx={25} cy={80} r={8} fill={COLORS.orange} opacity={0.7} />
        <circle cx={95} cy={75} r={8} fill={COLORS.pink} opacity={0.7} />
        <line x1={35} y1={35} x2={85} y2={30} stroke={COLORS.edgeStroke} strokeWidth={2} opacity={0.6} />
        <line x1={35} y1={35} x2={60} y2={85} stroke={COLORS.edgeStroke} strokeWidth={2} opacity={0.6} />
        <line x1={85} y1={30} x2={60} y2={85} stroke={COLORS.edgeStroke} strokeWidth={2} opacity={0.6} />
        <line x1={25} y1={80} x2={60} y2={85} stroke={COLORS.edgeStroke} strokeWidth={2} opacity={0.4} />
        <line x1={95} y1={75} x2={85} y2={30} stroke={COLORS.edgeStroke} strokeWidth={2} opacity={0.4} />
      </svg>

      <div
        style={{
          opacity: titleEntrance,
          transform: `translateY(${(1 - titleEntrance) * 50}px)`,
          fontSize: 90,
          fontWeight: 900,
          fontFamily: FONT.sans,
          letterSpacing: -3,
          background: `linear-gradient(135deg, ${COLORS.accent}, ${COLORS.purple})`,
          WebkitBackgroundClip: "text",
          WebkitTextFillColor: "transparent",
          textAlign: "center",
        }}
      >
        GraphMemory
      </div>

      <div
        style={{
          opacity: subtitleEntrance,
          transform: `translateY(${(1 - subtitleEntrance) * 30}px)`,
          fontSize: 30,
          fontFamily: FONT.sans,
          color: COLORS.textMuted,
          textAlign: "center",
        }}
      >
        Graph-based memory system powered by DuckDB
      </div>

      {/* Install command */}
      <div
        style={{
          opacity: installEntrance,
          transform: `translateY(${(1 - installEntrance) * 20}px)`,
          background: COLORS.codeBg,
          border: `1px solid ${COLORS.codeBorder}`,
          borderRadius: 12,
          padding: "14px 32px",
          fontFamily: FONT.mono,
          fontSize: 24,
          color: COLORS.green,
          marginTop: 8,
        }}
      >
        <span style={{ color: COLORS.textMuted }}>$</span> pip install graphmemory
      </div>

      {/* Feature pills */}
      <div
        style={{
          display: "flex",
          gap: 12,
          flexWrap: "wrap",
          justifyContent: "center",
          maxWidth: 900,
          marginTop: 16,
        }}
      >
        {features.map((f, i) => (
          <FeaturePill
            key={f}
            label={f}
            delay={45 + i * 3}
            index={0}
            color={[COLORS.accent, COLORS.green, COLORS.purple, COLORS.orange, COLORS.pink, COLORS.yellow, COLORS.accent][i]}
          />
        ))}
      </div>
    </AbsoluteFill>
  );
};
