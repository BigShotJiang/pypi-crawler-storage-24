import React from "react";
import {
  AbsoluteFill,
  useCurrentFrame,
  useVideoConfig,
  spring,
} from "remotion";
import { SectionTitle } from "../components/SectionTitle";
import { CodeBlock } from "../components/CodeBlock";
import { GraphViz } from "../components/GraphViz";
import { COLORS } from "../theme";

const CODE = `# Fluent query builder
people = graph.query() \\
  .match(type="Person") \\
  .where(role="engineer") \\
  .order_by("name") \\
  .limit(10) \\
  .execute()

# Graph traversal
neighbors = graph.query() \\
  .match(type="Person") \\
  .where(name="Alice") \\
  .traverse(depth=2) \\
  .execute()`;

const NODES = [
  { id: "a", label: "Alice", x: 300, y: 80, type: "Person", color: COLORS.green },
  { id: "b", label: "Bob", x: 140, y: 180, type: "Person", color: COLORS.nodeFill },
  { id: "c", label: "Carol", x: 460, y: 180, type: "Person", color: COLORS.nodeFill },
  { id: "d", label: "Dave", x: 80, y: 310, type: "Person", color: COLORS.purple },
  { id: "e", label: "Eve", x: 260, y: 310, type: "Person", color: COLORS.purple },
  { id: "f", label: "Frank", x: 520, y: 310, type: "Person", color: COLORS.purple },
];

const EDGES = [
  { from: "a", to: "b", label: "knows" },
  { from: "a", to: "c", label: "knows" },
  { from: "b", to: "d", label: "knows" },
  { from: "b", to: "e", label: "knows" },
  { from: "c", to: "f", label: "knows" },
];

export const QueryBuilderScene: React.FC = () => {
  const frame = useCurrentFrame();

  // Highlight depth-1 at frame 40, depth-2 at frame 80
  const highlightNodes =
    frame > 80
      ? ["a", "b", "c", "d", "e", "f"]
      : frame > 40
        ? ["a", "b", "c"]
        : ["a"];

  const highlightEdges: [string, string][] =
    frame > 80
      ? [["a", "b"], ["a", "c"], ["b", "d"], ["b", "e"], ["c", "f"]]
      : frame > 40
        ? [["a", "b"], ["a", "c"]]
        : [];

  return (
    <AbsoluteFill
      style={{ justifyContent: "flex-start", alignItems: "center", padding: 60 }}
    >
      <SectionTitle
        title="Query Builder"
        subtitle="Fluent, composable API for filtering, ordering, and multi-hop traversal"
      />
      <div
        style={{
          display: "flex",
          gap: 60,
          marginTop: 50,
          width: "100%",
          justifyContent: "center",
          alignItems: "center",
        }}
      >
        <div style={{ flex: "0 0 auto" }}>
          <CodeBlock code={CODE} delay={15} typingSpeed={2.2} />
        </div>
        <div style={{ flex: "0 0 auto" }}>
          <GraphViz
            nodes={NODES}
            edges={EDGES}
            delay={20}
            width={600}
            height={400}
            highlightNodes={highlightNodes}
            highlightEdges={highlightEdges}
            pulseNodes={["a"]}
          />
        </div>
      </div>
    </AbsoluteFill>
  );
};
