import React from "react";
import { useCurrentFrame, useVideoConfig, spring } from "remotion";
import { COLORS, FONT } from "../theme";

type FeaturePillProps = {
  label: string;
  color?: string;
  delay?: number;
  index?: number;
};

export const FeaturePill: React.FC<FeaturePillProps> = ({
  label,
  color = COLORS.accent,
  delay = 0,
  index = 0,
}) => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();

  const entrance = spring({
    frame,
    fps,
    delay: delay + index * 4,
    config: { damping: 15, stiffness: 200 },
  });

  return (
    <div
      style={{
        opacity: entrance,
        transform: `scale(${entrance})`,
        background: `${color}18`,
        border: `1px solid ${color}55`,
        borderRadius: 100,
        padding: "10px 24px",
        fontFamily: FONT.sans,
        fontSize: 20,
        fontWeight: 600,
        color,
        whiteSpace: "nowrap",
      }}
    >
      {label}
    </div>
  );
};
