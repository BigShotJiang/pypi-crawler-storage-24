import { Composition } from "remotion";
import { GraphMemoryShowcase } from "./GraphMemoryShowcase";

const FPS = 30;
const DURATION_SECONDS = 60;

export const RemotionRoot = () => {
  return (
    <Composition
      id="GraphMemoryShowcase"
      component={GraphMemoryShowcase}
      durationInFrames={FPS * DURATION_SECONDS}
      fps={FPS}
      width={1920}
      height={1080}
    />
  );
};
