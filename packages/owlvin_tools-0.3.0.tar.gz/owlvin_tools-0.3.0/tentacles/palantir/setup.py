from setuptools import setup


setup(
    name="palantir",
    version="0.1.0",
    description="Thin wrapper that re-exports the existing MCP server.",
    packages=["palantir"],
    include_package_data=True,
    install_requires=["owlvin-tools"],
    entry_points={
        "console_scripts": [
            "palantir=palantir:main",
        ],
    },
    python_requires=">=3.10",
)
