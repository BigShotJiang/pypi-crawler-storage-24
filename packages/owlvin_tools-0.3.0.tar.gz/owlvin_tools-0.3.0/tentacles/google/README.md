# google

Thin wrapper around the shared MCP server.
