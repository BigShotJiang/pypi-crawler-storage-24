from setuptools import setup


setup(
    name="google",
    version="0.1.0",
    description="Thin wrapper that re-exports the existing MCP server.",
    packages=["google"],
    include_package_data=True,
    install_requires=["owlvin-tools"],
    entry_points={
        "console_scripts": [
            "google=google:main",
        ],
    },
    python_requires=">=3.10",
)
