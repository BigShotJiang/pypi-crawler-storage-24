from setuptools import setup


setup(
    name="louisvuitton",
    version="0.1.0",
    description="Thin wrapper that re-exports the existing MCP server.",
    packages=["louisvuitton"],
    include_package_data=True,
    install_requires=["owlvin-tools"],
    entry_points={
        "console_scripts": [
            "louisvuitton=louisvuitton:main",
        ],
    },
    python_requires=">=3.10",
)
