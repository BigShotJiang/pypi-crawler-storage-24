from setuptools import setup


setup(
    name="fendi",
    version="0.1.0",
    description="Thin wrapper that re-exports the existing MCP server.",
    packages=["fendi"],
    include_package_data=True,
    install_requires=["owlvin-tools"],
    entry_points={
        "console_scripts": [
            "fendi=fendi:main",
        ],
    },
    python_requires=">=3.10",
)
