# domperignon

Thin wrapper around the shared MCP server.
