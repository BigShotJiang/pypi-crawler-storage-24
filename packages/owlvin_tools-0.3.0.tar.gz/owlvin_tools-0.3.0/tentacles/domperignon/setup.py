from setuptools import setup


setup(
    name="domperignon",
    version="0.1.0",
    description="Thin wrapper that re-exports the existing MCP server.",
    packages=["domperignon"],
    include_package_data=True,
    install_requires=["owlvin-tools"],
    entry_points={
        "console_scripts": [
            "domperignon=domperignon:main",
        ],
    },
    python_requires=">=3.10",
)
