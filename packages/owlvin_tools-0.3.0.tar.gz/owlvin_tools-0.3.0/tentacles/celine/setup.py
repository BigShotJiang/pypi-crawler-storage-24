from setuptools import setup


setup(
    name="celine",
    version="0.1.0",
    description="Thin wrapper that re-exports the existing MCP server.",
    packages=["celine"],
    include_package_data=True,
    install_requires=["owlvin-tools"],
    entry_points={
        "console_scripts": [
            "celine=celine:main",
        ],
    },
    python_requires=">=3.10",
)
