# celine

Thin wrapper around the shared MCP server.
