from setuptools import setup


setup(
    name="chopard",
    version="0.1.0",
    description="Thin wrapper that re-exports the existing MCP server.",
    packages=["chopard"],
    include_package_data=True,
    install_requires=["owlvin-tools"],
    entry_points={
        "console_scripts": [
            "chopard=chopard:main",
        ],
    },
    python_requires=">=3.10",
)
