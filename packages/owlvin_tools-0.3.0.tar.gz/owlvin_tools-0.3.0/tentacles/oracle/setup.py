from setuptools import setup


setup(
    name="oracle",
    version="0.1.0",
    description="Thin wrapper that re-exports the existing MCP server.",
    packages=["oracle"],
    include_package_data=True,
    install_requires=["owlvin-tools"],
    entry_points={
        "console_scripts": [
            "oracle=oracle:main",
        ],
    },
    python_requires=">=3.10",
)
