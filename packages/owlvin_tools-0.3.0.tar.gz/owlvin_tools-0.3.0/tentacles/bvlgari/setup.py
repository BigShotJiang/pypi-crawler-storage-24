from setuptools import setup


setup(
    name="bvlgari",
    version="0.1.0",
    description="Thin wrapper that re-exports the existing MCP server.",
    packages=["bvlgari"],
    include_package_data=True,
    install_requires=["owlvin-tools"],
    entry_points={
        "console_scripts": [
            "bvlgari=bvlgari:main",
        ],
    },
    python_requires=">=3.10",
)
