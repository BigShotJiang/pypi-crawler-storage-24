from setuptools import setup


setup(
    name="hennessy",
    version="0.1.0",
    description="Thin wrapper that re-exports the existing MCP server.",
    packages=["hennessy"],
    include_package_data=True,
    install_requires=["owlvin-tools"],
    entry_points={
        "console_scripts": [
            "hennessy=hennessy:main",
        ],
    },
    python_requires=">=3.10",
)
