from setuptools import setup


setup(
    name="patekphilippe",
    version="0.1.0",
    description="Thin wrapper that re-exports the existing MCP server.",
    packages=["patekphilippe"],
    include_package_data=True,
    install_requires=["owlvin-tools"],
    entry_points={
        "console_scripts": [
            "patekphilippe=patekphilippe:main",
        ],
    },
    python_requires=">=3.10",
)
