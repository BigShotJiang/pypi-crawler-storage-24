# patekphilippe

Thin wrapper around the shared MCP server.
