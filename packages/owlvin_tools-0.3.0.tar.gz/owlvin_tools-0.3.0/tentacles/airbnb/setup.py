from setuptools import setup


setup(
    name="airbnb",
    version="0.1.0",
    description="Thin wrapper that re-exports the existing MCP server.",
    packages=["airbnb"],
    include_package_data=True,
    install_requires=["owlvin-tools"],
    entry_points={
        "console_scripts": [
            "airbnb=airbnb:main",
        ],
    },
    python_requires=">=3.10",
)
