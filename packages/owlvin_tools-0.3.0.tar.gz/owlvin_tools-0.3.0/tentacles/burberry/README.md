# burberry

Thin wrapper around the shared MCP server.
