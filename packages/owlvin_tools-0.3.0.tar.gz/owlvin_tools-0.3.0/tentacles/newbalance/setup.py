from setuptools import setup


setup(
    name="newbalance",
    version="0.1.0",
    description="Thin wrapper that re-exports the existing MCP server.",
    packages=["newbalance"],
    include_package_data=True,
    install_requires=["owlvin-tools"],
    entry_points={
        "console_scripts": [
            "newbalance=newbalance:main",
        ],
    },
    python_requires=">=3.10",
)
