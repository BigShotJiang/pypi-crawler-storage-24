# armani

Thin wrapper around the shared MCP server.
