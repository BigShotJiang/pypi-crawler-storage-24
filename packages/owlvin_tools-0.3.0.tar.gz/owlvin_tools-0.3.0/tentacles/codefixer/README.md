# codefixer

Thin wrapper around the shared MCP server.
