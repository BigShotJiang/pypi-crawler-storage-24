from setuptools import setup


setup(
    name="montblanc",
    version="0.1.0",
    description="Thin wrapper that re-exports the existing MCP server.",
    packages=["montblanc"],
    include_package_data=True,
    install_requires=["owlvin-tools"],
    entry_points={
        "console_scripts": [
            "montblanc=montblanc:main",
        ],
    },
    python_requires=">=3.10",
)
