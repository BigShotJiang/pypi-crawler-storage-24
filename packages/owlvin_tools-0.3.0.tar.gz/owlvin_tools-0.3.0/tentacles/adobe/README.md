# adobe

Thin wrapper around the shared MCP server.
