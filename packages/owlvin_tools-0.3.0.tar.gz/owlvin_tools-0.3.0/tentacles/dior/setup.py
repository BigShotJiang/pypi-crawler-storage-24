from setuptools import setup


setup(
    name="dior",
    version="0.1.0",
    description="Thin wrapper that re-exports the existing MCP server.",
    packages=["dior"],
    include_package_data=True,
    install_requires=["owlvin-tools"],
    entry_points={
        "console_scripts": [
            "dior=dior:main",
        ],
    },
    python_requires=">=3.10",
)
