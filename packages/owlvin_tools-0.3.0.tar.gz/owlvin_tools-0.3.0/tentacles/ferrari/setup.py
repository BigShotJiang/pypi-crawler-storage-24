from setuptools import setup


setup(
    name="ferrari",
    version="0.1.0",
    description="Thin wrapper that re-exports the existing MCP server.",
    packages=["ferrari"],
    include_package_data=True,
    install_requires=["owlvin-tools"],
    entry_points={
        "console_scripts": [
            "ferrari=ferrari:main",
        ],
    },
    python_requires=">=3.10",
)
