# lamborghini

Thin wrapper around the shared MCP server.
