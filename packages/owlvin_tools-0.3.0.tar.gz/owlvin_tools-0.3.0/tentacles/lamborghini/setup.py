from setuptools import setup


setup(
    name="lamborghini",
    version="0.1.0",
    description="Thin wrapper that re-exports the existing MCP server.",
    packages=["lamborghini"],
    include_package_data=True,
    install_requires=["owlvin-tools"],
    entry_points={
        "console_scripts": [
            "lamborghini=lamborghini:main",
        ],
    },
    python_requires=">=3.10",
)
