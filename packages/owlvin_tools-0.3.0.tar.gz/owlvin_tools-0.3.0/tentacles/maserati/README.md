# maserati

Thin wrapper around the shared MCP server.
