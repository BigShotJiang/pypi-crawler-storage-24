# apple

Thin wrapper around the shared MCP server.
