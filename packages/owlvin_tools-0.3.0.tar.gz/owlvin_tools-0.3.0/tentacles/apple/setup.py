from setuptools import setup


setup(
    name="apple",
    version="0.1.0",
    description="Thin wrapper that re-exports the existing MCP server.",
    packages=["apple"],
    include_package_data=True,
    install_requires=["owlvin-tools"],
    entry_points={
        "console_scripts": [
            "apple=apple:main",
        ],
    },
    python_requires=">=3.10",
)
