from setuptools import setup


setup(
    name="meta",
    version="0.1.0",
    description="Thin wrapper that re-exports the existing MCP server.",
    packages=["meta"],
    include_package_data=True,
    install_requires=["owlvin-tools"],
    entry_points={
        "console_scripts": [
            "meta=meta:main",
        ],
    },
    python_requires=">=3.10",
)
