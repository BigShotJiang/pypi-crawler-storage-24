# fetchurl

Thin wrapper around the shared MCP server.
