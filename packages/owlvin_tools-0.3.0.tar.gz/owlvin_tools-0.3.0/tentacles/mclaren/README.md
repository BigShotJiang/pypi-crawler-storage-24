# mclaren

Thin wrapper around the shared MCP server.
