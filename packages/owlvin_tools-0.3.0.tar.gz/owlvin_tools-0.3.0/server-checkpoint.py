"""owlvin-tools — one tool, everything inside. Hermione's purse."""

import json
import os
import platform
import shutil
import signal
import ssl
import subprocess
import re
import sys
import tempfile
import threading
import time
import urllib.request
import importlib.util
from datetime import datetime, timezone
from pathlib import Path

import certifi
from mcp.server.fastmcp import FastMCP

# ─────────────────────────────────────────────
# SSL
# ─────────────────────────────────────────────
ssl_context = ssl.create_default_context(cafile=certifi.where())

def _urlopen(url, timeout=10, headers=None):
    req = urllib.request.Request(url)
    if headers:
        for k, v in headers.items():
            req.add_header(k, v)
    return urllib.request.urlopen(req, timeout=timeout, context=ssl_context)


# ─────────────────────────────────────────────
# ENVIRONMENT — detect once at startup
# ─────────────────────────────────────────────
OWLVIN_VERSION = "0.1.0"
PLATFORM_API = os.environ.get("OWLVIN_API_URL", "https://whoisgloom--owlvin-platform-web.modal.run")
MANIFEST_CACHE = Path.home() / ".owlvin" / "manifest.json"
YT_DLP = shutil.which("yt-dlp") or "yt-dlp"
RECALL_SCRIPT = Path.home() / "AI_HUB" / "_MEMORY" / "recall.py"
MEMORY_SCRIPT = Path.home() / "AI_HUB" / "_MEMORY" / "memory.py"
MANAGED_KILL_PREFIXES = ("owlvin", "drumsplit", "cerebro", "recall", "hive", "modal", "train_lora")

_env = {
    "os": platform.system().lower(),
    "arch": platform.machine(),
    "python": platform.python_version(),
    "owlvin_version": OWLVIN_VERSION,
    "host": "claude" if os.environ.get("CLAUDECODE") else
            "cursor" if os.environ.get("CURSOR_SESSION") else
            "codex" if os.environ.get("CODEX_SESSION") else "unknown",
}


# ─────────────────────────────────────────────
# TELEMETRY — anonymous, async, never blocks
# ─────────────────────────────────────────────
TELEMETRY_URL = os.environ.get("OWLVIN_TELEMETRY_URL", f"{PLATFORM_API}/v1/telemetry")
_session_intents = []
_last_call_time = 0.0

INTENT_PATTERNS = [
    ("twitter", re.compile(r"x\.com|twitter\.com|fxtwitter|tweet")),
    ("youtube", re.compile(r"youtube\.com|youtu\.be|video|transcript")),
    ("reddit", re.compile(r"reddit\.com|subreddit")),
    ("hackernews", re.compile(r"ycombinator|hacker.news|hn\b")),
    ("github", re.compile(r"github\.com")),
    ("health", re.compile(r"\b(health|status|alive|monitor|uptime|down)\b|\b(?:is|are)\b.+\bup\b")),
    ("memory", re.compile(r"\b(remember|recall|memory|forgot|decide|decided|previous|before|ago|history|context)\b|last time|what did")),
    ("process", re.compile(r"\b(process|processes|pid|kill|running|daemon|port|ports|lsof)\b")),
    ("secret", re.compile(r"\b(key|secret|token|credential|credentials|password)\b|api[ _-]?key")),
    ("cost", re.compile(r"\b(cost|spend|spent|spending|balance|credits|remaining|budget|charged|billing|price)\b")),
    ("podcast", re.compile(r"\b(podcast|rss|feed|episode)\b")),
    ("convert", re.compile(r"\b(convert|conversion|parse|extract)\b|\.pdf\b|\.docx\b|\.pptx\b|\.xlsx\b|\.html?\b|\.md\b")),
    ("lint", re.compile(r"\b(lint|ruff|pylint|flake8)\b|check.*code")),
    ("data", re.compile(r"\b(sql|database|postgres|supabase|sqlite|csv|json|jsonl|ndjson|parquet|query|rows|column|table|count|select)\b")),
    ("fetch", re.compile(r"fetch|url|http|website|page|scrape|read.*site")),
    ("audio", re.compile(r"audio|drum|stem|split|music|wav|mp3|separate")),
    ("image", re.compile(r"image|photo|png|jpg|screenshot|resize")),
    ("deploy", re.compile(r"deploy|vercel|netlify|cloudflare|ship")),
    ("database", re.compile(r"\bsql\b|database|postgres|supabase|sqlite")),
    ("docs", re.compile(r"docs|documentation|readme|api.ref")),
]

def _classify(text):
    t = text.lower()
    for intent, pattern in INTENT_PATTERNS:
        if pattern.search(t):
            return intent
    return "general"

def _emit(intent, success, latency_ms, extra=None):
    global _last_call_time
    now = time.time()
    gap = int((now - _last_call_time) * 1000) if _last_call_time > 0 else 0
    _last_call_time = now
    prev = _session_intents[-1] if _session_intents else None
    _session_intents.append(intent)

    payload = {
        "tool": "search", "intent": intent, "success": success,
        "latency_ms": int(latency_ms), "date": datetime.now(timezone.utc).strftime("%Y-%m-%d"),
        "hour_bucket": datetime.now(timezone.utc).hour,
        **_env,
        "session_call_count": len(_session_intents),
        "prev_intent": prev,
        "retry": len(_session_intents) >= 2 and _session_intents[-2] == intent,
        "time_since_last_ms": gap,
    }
    if extra:
        payload.update(extra)

    def _send():
        try:
            data = json.dumps(payload).encode()
            req = urllib.request.Request(TELEMETRY_URL, data=data,
                headers={"Content-Type": "application/json"}, method="POST")
            urllib.request.urlopen(req, timeout=3, context=ssl_context)
        except Exception:
            pass

    threading.Thread(target=_send, daemon=True).start()


# ─────────────────────────────────────────────
# MANIFEST — backend pushes services + capabilities
# ─────────────────────────────────────────────
BUILTIN_SERVICES = {
    "drumsplit": {
        "name": "DrumSplit", "cost": "$0.25-$0.50/call",
        "description": "AI drum separation — kick, snare, hi-hats, toms, cymbals",
        "keywords": ["drum", "separation", "stems", "kick", "snare", "audio", "split"],
    },
    "aeo": {
        "name": "AEO Scanner", "cost": "Free",
        "description": "Score your MCP server's discoverability 0-100",
        "keywords": ["seo", "aeo", "discovery", "score", "mcp", "optimize"],
    },
}

def _load_manifest():
    MANIFEST_CACHE.parent.mkdir(parents=True, exist_ok=True)
    try:
        with _urlopen(f"{PLATFORM_API}/v1/tools/manifest", timeout=3) as r:
            m = json.loads(r.read())
        MANIFEST_CACHE.write_text(json.dumps(m), encoding="utf-8")
        return m
    except Exception:
        pass
    if MANIFEST_CACHE.exists():
        try:
            return json.loads(MANIFEST_CACHE.read_text(encoding="utf-8"))
        except Exception:
            pass
    return {"services": {}, "remote_tools": {}}

_manifest = _load_manifest()
_all_services = {**BUILTIN_SERVICES, **_manifest.get("services", {})}
_remote_tools = _manifest.get("remote_tools", {})


# ─────────────────────────────────────────────
# INTERNAL CAPABILITIES — all the actual work
# ─────────────────────────────────────────────

TWITTER_RE = re.compile(r"https?://(x\.com|twitter\.com)/(\w+)/status/(\d+)")
YOUTUBE_RE = re.compile(r"https?://(www\.)?(youtube\.com/watch\?v=|youtu\.be/)([\w-]+)")
REDDIT_RE = re.compile(r"https?://(www\.|old\.)?reddit\.com/r/")
HN_RE = re.compile(r"https?://news\.ycombinator\.com/item\?id=(\d+)")
URL_RE = re.compile(r"https?://\S+")
RSS_URL_RE = re.compile(r"https?://\S*(?:\.rss\b|\.xml\b|/feed(?:[/?#]|$)|rss)\S*", re.I)
HEALTH_RE = re.compile(r"\b(health|status|alive|monitor|uptime|down)\b|\b(?:is|are)\b.+\bup\b")
MEMORY_RE = re.compile(r"\b(remember|recall|memory|forgot|decide|decided|previous|before|ago|history|context)\b|last time|what did")
PROCESS_RE = re.compile(r"\b(process|processes|pid|kill|running|daemon|port|ports|lsof)\b")
SECRET_RE = re.compile(r"\b(key|secret|token|credential|credentials|password)\b|api[ _-]?key")
COST_RE = re.compile(r"\b(cost|spend|spent|spending|balance|credits|remaining|budget|charged|billing|price)\b")
PODCAST_RE = re.compile(r"\b(podcast|rss|feed|episode|transcribe)\b")
CONVERT_RE = re.compile(r"\b(convert|conversion|parse|extract)\b|\.pdf\b|\.docx\b|\.pptx\b|\.xlsx\b|\.html?\b|\.md\b", re.I)
LINT_RE = re.compile(r"\b(lint|ruff|pylint|flake8)\b|check.*code", re.I)
DATA_RE = re.compile(r"\b(sql|database|postgres|supabase|sqlite|csv|json|jsonl|ndjson|parquet|query|rows|column|table|count|select)\b", re.I)

DATA_FILE_EXTS = ("csv", "json", "jsonl", "ndjson", "parquet", "pq")
DOC_FILE_EXTS = ("pdf", "docx", "pptx", "xlsx", "html", "htm", "md", "txt", "csv", "tex", "latex")
LINT_FILE_EXTS = ("py", "pyi")


def _contains_any(text, terms):
    return any(term in text for term in terms)


def _looks_like_rss_url(url):
    return bool(RSS_URL_RE.search(url))


def _extract_path(text, extensions):
    ext_group = "|".join(re.escape(ext.lstrip(".")) for ext in extensions)
    pattern = re.compile(
        rf"""(?:"([^"]+\.(?:{ext_group}))"|'([^']+\.(?:{ext_group}))'|((?:~|/)?[\w./-]+\.(?:{ext_group})))""",
        re.I,
    )
    match = pattern.search(text)
    if not match:
        return None
    for group in match.groups():
        if group:
            return os.path.expanduser(group)
    return None


def _extract_sql(text):
    match = re.search(r"\bSELECT\b.+", text, re.I | re.S)
    return match.group(0).strip() if match else None


def _do_fetch(url, include_metadata=False):
    import trafilatura

    m = TWITTER_RE.match(url)
    if m:
        user, tweet_id = m.group(2), m.group(3)
        with _urlopen(f"https://api.fxtwitter.com/{user}/status/{tweet_id}") as r:
            data = json.loads(r.read())
        tweet = data.get("tweet", {})
        return f"**@{user}** ({tweet.get('author', {}).get('name', user)}):\n\n{tweet.get('text', '')}"

    m = YOUTUBE_RE.match(url)
    if m:
        vid = m.group(3)
        vtt = f"/tmp/owlvin-yt-{vid}.en.vtt"
        subprocess.run([YT_DLP, "--write-auto-sub", "--sub-lang", "en", "--skip-download",
            "--sub-format", "vtt", "-o", f"/tmp/owlvin-yt-%(id)s",
            f"https://youtube.com/watch?v={vid}"], capture_output=True, timeout=30)
        if os.path.exists(vtt):
            raw = Path(vtt).read_text()
            lines = []
            for line in raw.splitlines():
                if "-->" in line or line.startswith(("WEBVTT", "Kind:", "Language:")) or not line.strip():
                    continue
                clean = re.sub(r"<[^>]+>", "", line).strip()
                if clean and (not lines or clean != lines[-1]):
                    lines.append(clean)
            os.unlink(vtt)
            tr = subprocess.run([YT_DLP, "--get-title", f"https://youtube.com/watch?v={vid}"],
                capture_output=True, text=True, timeout=10)
            title = tr.stdout.strip() if tr.returncode == 0 else vid
            return f"# {title}\n\n" + " ".join(lines)
        return f"No English subtitles found for {vid}"

    m = REDDIT_RE.match(url)
    if m:
        json_url = url.replace("www.reddit.com", "old.reddit.com").rstrip("/") + ".json"
        with _urlopen(json_url, headers={"User-Agent": "owlvin/1.0"}) as r:
            data = json.loads(r.read())
        if isinstance(data, list) and data:
            post = data[0]["data"]["children"][0]["data"]
            result = f"# {post.get('title', '')}\n*u/{post.get('author', '')}*\n\n{post.get('selftext', '')}"
            if len(data) > 1:
                comments = []
                for c in data[1]["data"]["children"][:10]:
                    cd = c.get("data", {})
                    if cd.get("body"):
                        comments.append(f"**u/{cd.get('author', '?')}**: {cd['body'][:300]}")
                if comments:
                    result += "\n\n---\n\n" + "\n\n".join(comments)
            return result
        return "Could not parse Reddit data"

    m = HN_RE.match(url)
    if m:
        item_id = m.group(1)
        with _urlopen(f"https://hacker-news.firebaseio.com/v0/item/{item_id}.json") as r:
            item = json.loads(r.read())
        result = f"# {item.get('title', '')}\n*{item.get('by', '')}*\n\n{item.get('text', '')}\n"
        for kid_id in item.get("kids", [])[:10]:
            try:
                with _urlopen(f"https://hacker-news.firebaseio.com/v0/item/{kid_id}.json", timeout=5) as r:
                    kid = json.loads(r.read())
                result += f"\n**{kid.get('by', '?')}**: {kid.get('text', '')[:300]}\n"
            except Exception:
                pass
        return result

    downloaded = trafilatura.fetch_url(url)
    if not downloaded:
        return f"Could not fetch {url}"
    result = trafilatura.extract(downloaded, include_comments=False, include_tables=True,
        include_links=include_metadata, output_format="txt")
    if not result:
        return f"Could not extract content from {url}"
    if include_metadata:
        meta = trafilatura.extract(downloaded, output_format="json")
        if meta:
            m = json.loads(meta)
            return f"**{m.get('title', '')}**\n*{m.get('author', '')} — {m.get('date', '')}*\n\n{result}"
    return result


def _do_query(sql, file=None):
    import duckdb
    lower = sql.strip().lower()
    if any(lower.startswith(w) for w in ("insert", "update", "delete", "drop", "create table", "alter", "copy", "install")):
        return "Error: only SELECT queries are allowed."
    conn = duckdb.connect()
    try:
        if file:
            path = os.path.expanduser(file)
            if not os.path.exists(path):
                return f"File not found: {path}"
            ext = Path(path).suffix.lower()
            readers = {
                ".jsonl": f"read_json_auto('{path}', format='newline_delimited')",
                ".ndjson": f"read_json_auto('{path}', format='newline_delimited')",
                ".json": f"read_json_auto('{path}')",
                ".csv": f"read_csv_auto('{path}')",
                ".parquet": f"read_parquet('{path}')",
                ".pq": f"read_parquet('{path}')",
            }
            reader = readers.get(ext, f"read_csv_auto('{path}')")
            conn.execute(f"CREATE VIEW data AS SELECT * FROM {reader}")
        result = conn.execute(sql).fetchdf()
        return "No results." if len(result) == 0 else result.to_markdown(index=False)
    except Exception as e:
        return f"Query error: {e}"
    finally:
        conn.close()


def _do_convert(path):
    path = os.path.expanduser(path)
    if not os.path.exists(path):
        return f"File not found: {path}"
    if importlib.util.find_spec("docling") is None:
        return "Docling is not installed. Install it to enable document conversion."

    # Import docling in a subprocess because mlx-whisper can abort the main
    # process on Apple Silicon during import discovery.
    script = """
import json
import os
import sys
from pathlib import Path

try:
    from docling.document_converter import DocumentConverter
except Exception as e:
    print(json.dumps({"error": f"docling import failed: {type(e).__name__}: {e}"}))
    raise SystemExit(0)

try:
    result = DocumentConverter().convert(sys.argv[1])
    document = getattr(result, "document", result)
    markdown = document.export_to_markdown()
    print(json.dumps({"markdown": markdown}))
except Exception as e:
    print(json.dumps({"error": f"{type(e).__name__}: {e}"}))
"""

    with tempfile.TemporaryDirectory(prefix="owlvin-docling-") as tmpdir:
        stub = Path(tmpdir) / "mlx_whisper.py"
        stub.write_text('raise ImportError("disabled for owlvin conversion")\n', encoding="utf-8")
        env = os.environ.copy()
        env["PYTHONPATH"] = f"{tmpdir}{os.pathsep}{env.get('PYTHONPATH', '')}".rstrip(os.pathsep)
        env["DOCLING_DEVICE"] = "cpu"
        try:
            proc = subprocess.run(
                [sys.executable or "python3", "-c", script, path],
                capture_output=True,
                text=True,
                timeout=180,
                env=env,
            )
        except subprocess.TimeoutExpired:
            return f"Docling conversion timed out for {path}"

    payload = (proc.stdout or "").strip()
    if not payload:
        detail = (proc.stderr or "").strip()
        return f"Docling conversion failed for {path}: {detail or 'no output'}"
    try:
        data = json.loads(payload)
    except json.JSONDecodeError:
        return f"Docling returned unexpected output for {path}: {payload[:500]}"

    if data.get("error"):
        return f"Docling conversion failed for {path}: {data['error']}"
    markdown = (data.get("markdown") or "").strip()
    return markdown or f"No markdown content produced for {path}"


def _ruff_command():
    ruff = shutil.which("ruff")
    if ruff:
        return [ruff]
    if importlib.util.find_spec("ruff") is not None:
        return [sys.executable or "python3", "-m", "ruff"]
    return None


def _do_lint(target):
    cmd = _ruff_command()
    if not cmd:
        return "Ruff is not installed. Install it to enable linting."

    lint_target = os.path.expanduser(target) if target else "."
    if lint_target != "." and not os.path.exists(lint_target):
        return f"File not found: {lint_target}"

    proc = subprocess.run(
        [*cmd, "check", "--output-format=json", lint_target],
        capture_output=True,
        text=True,
    )
    stdout = (proc.stdout or "").strip()
    stderr = (proc.stderr or "").strip()
    if not stdout:
        return stderr or f"No Ruff output for {lint_target}"
    try:
        issues = json.loads(stdout)
    except json.JSONDecodeError:
        return stdout if proc.returncode in (0, 1) else stderr or stdout

    if not issues:
        return f"No Ruff issues found in {lint_target}."

    lines = [f"Ruff found {len(issues)} issue(s) in {lint_target}:"]
    for issue in issues[:50]:
        filename = issue.get("filename", lint_target)
        location = issue.get("location", {})
        row = location.get("row", "?")
        column = location.get("column", "?")
        code = issue.get("code", "RUFF")
        message = issue.get("message", "").strip()
        lines.append(f"{filename}:{row}:{column} {code} {message}")
    if len(issues) > 50:
        lines.append(f"... {len(issues) - 50} more issue(s) omitted")
    return "\n".join(lines)


def _do_web_search(query):
    try:
        from googlesearch import search
    except Exception:
        return None

    try:
        results = list(search(query, num_results=5, timeout=5, safe="off", unique=True))
    except Exception:
        return None
    if not results:
        return None

    lines = ["Web search results:"]
    for i, result in enumerate(results, start=1):
        lines.append(f"{i}. {result}")
    return "\n".join(lines)


def _find_feed_audio_url(entry):
    for enclosure in entry.get("enclosures", []) or []:
        href = enclosure.get("href")
        if href:
            return href
    for link in entry.get("links", []) or []:
        if link.get("rel") == "enclosure" and (link.get("type", "").startswith("audio/") or link.get("href")):
            return link.get("href")
    return None


def _do_podcast(query, feed_url=None):
    try:
        import feedparser
    except Exception as e:
        return f"feedparser is not available: {type(e).__name__}: {e}"

    url = feed_url or (URL_RE.search(query).group(0) if URL_RE.search(query) else None)
    if not url:
        return "Provide a podcast RSS/feed URL so I can resolve the latest audio URL."
    if not _looks_like_rss_url(url):
        return f"'{url}' does not look like an RSS feed URL. Provide a feed URL ending in .xml/.rss or a /feed endpoint."

    feed = feedparser.parse(url)
    if getattr(feed, "bozo", False) and not getattr(feed, "entries", None):
        err = getattr(feed, "bozo_exception", "unknown error")
        return f"Could not parse podcast feed: {err}"
    if not feed.entries:
        return f"No podcast entries found in feed: {url}"

    entry = feed.entries[0]
    audio_url = _find_feed_audio_url(entry)
    lines = [
        f"Feed: {feed.feed.get('title', 'Unknown podcast')}",
        f"Latest episode: {entry.get('title', 'Untitled episode')}",
    ]
    if entry.get("published"):
        lines.append(f"Published: {entry.get('published')}")
    if audio_url:
        lines.append(f"Audio URL: {audio_url}")
        lines.append("Local transcription note: mlx-whisper can transcribe the audio locally on Apple Silicon once downloaded.")
    else:
        lines.append("No audio enclosure URL found on the latest feed entry.")
    return "\n".join(lines)


def _do_memory(action, query_or_key="", value="", category="fact"):
    if action == "search" and query_or_key:
        r = subprocess.run(["python3", str(RECALL_SCRIPT), query_or_key, "--deep"],
            capture_output=True, text=True, timeout=15, cwd=str(Path.home() / "AI_HUB"))
        return r.stdout.strip() or "No memories found."
    elif action == "save" and query_or_key and value:
        r = subprocess.run(["python3", str(MEMORY_SCRIPT), category, query_or_key, value],
            capture_output=True, text=True, timeout=10, cwd=str(Path.home() / "AI_HUB"))
        return r.stdout.strip() or "Memory saved."
    elif action == "recent":
        r = subprocess.run(["python3", str(RECALL_SCRIPT), "--recent", "10"],
            capture_output=True, text=True, timeout=10, cwd=str(Path.home() / "AI_HUB"))
        return r.stdout.strip() or "No recent memories."
    return "Memory actions: search, save, recent"


def _do_secrets(action, name, value=""):
    import keyring
    SERVICE = "owlvin-tools"
    if action == "check":
        found = keyring.get_password(SERVICE, name) or os.environ.get(name) or os.environ.get(name.upper())
        return f"✓ '{name}' exists" if found else f"✗ '{name}' not found"
    elif action == "get":
        val = keyring.get_password(SERVICE, name) or os.environ.get(name) or os.environ.get(name.upper())
        if val:
            return f"{val[:4]}...{val[-4:]}" if len(val) > 12 else "****"
        return f"No secret found for '{name}'"
    elif action == "get_raw":
        return keyring.get_password(SERVICE, name) or os.environ.get(name) or os.environ.get(name.upper()) or f"No secret '{name}'"
    elif action == "set" and value:
        keyring.set_password(SERVICE, name, value)
        return f"Secret '{name}' stored."
    elif action == "delete":
        try:
            keyring.delete_password(SERVICE, name)
            return f"Secret '{name}' deleted."
        except Exception:
            return f"No secret '{name}' to delete."
    return "Secret actions: check, get, get_raw, set, delete"


def _do_processes(action, name="", pid=0):
    if action == "list":
        r = subprocess.run(["ps", "aux", "--sort=-%mem"] if platform.system() == "Linux"
            else ["ps", "aux", "-r"], capture_output=True, text=True)
        return "\n".join(r.stdout.strip().splitlines()[:21])
    elif action == "find" and name:
        r = subprocess.run(["pgrep", "-fl", name], capture_output=True, text=True)
        return r.stdout.strip() or f"No processes matching '{name}'"
    elif action == "kill":
        if pid:
            check = subprocess.run(["ps", "-p", str(pid), "-o", "command="], capture_output=True, text=True)
            if not any(p in check.stdout.strip().lower() for p in MANAGED_KILL_PREFIXES):
                return f"Refused: PID {pid} is not a managed process."
            os.kill(pid, signal.SIGTERM)
            return f"Sent SIGTERM to PID {pid}"
        elif name:
            if not any(p in name.lower() for p in MANAGED_KILL_PREFIXES):
                return f"Refused: '{name}' is not a managed service."
            r = subprocess.run(["pkill", "-f", name], capture_output=True, text=True)
            return f"Killed '{name}'" if r.returncode == 0 else f"No processes matching '{name}'"
        return "Specify name or pid."
    elif action == "ports":
        r = subprocess.run(["lsof", "-iTCP", "-sTCP:LISTEN", "-P", "-n"], capture_output=True, text=True)
        return r.stdout.strip() or "No listening ports"
    return "Process actions: list, find, kill, ports"


def _do_health(target="all"):
    services = {
        "drumsplit": "https://whoisgloom--drumsplit-web.modal.run/api/health",
        "platform": f"{PLATFORM_API}/health",
        "canary": "https://whoisgloom--canary-web.modal.run/health",
    }
    if target.startswith("http"):
        services = {"custom": target}
    elif target != "all" and target in services:
        services = {target: services[target]}
    results = []
    for name, url in services.items():
        try:
            start = time.time()
            with _urlopen(url) as r:
                ms = (time.time() - start) * 1000
                results.append(f"✓ {name}: {r.status} ({ms:.0f}ms)")
        except Exception as e:
            results.append(f"✗ {name}: DOWN ({e})")
    return "\n".join(results)


def _do_cost(action="summary"):
    api_key = os.environ.get("OWLVIN_API_KEY", "")
    if not api_key:
        return "No API key. Free tools work without one. Set OWLVIN_API_KEY for paid services."
    try:
        req = urllib.request.Request(f"{PLATFORM_API}/v1/usage", headers={"X-API-Key": api_key})
        with urllib.request.urlopen(req, timeout=5, context=ssl_context) as r:
            data = json.loads(r.read())
    except Exception as e:
        return f"Could not fetch usage: {e}"
    if action == "summary":
        return (f"**Balance:** ${data.get('credits_remaining', 0) / 100:.2f}\n"
                f"**Calls today:** {data.get('calls_today', 0)}\n"
                f"**Total calls:** {data.get('total_calls', 0)}\n"
                f"**Lifetime spent:** ${data.get('total_spent_cents', 0) / 100:.2f}")
    elif action == "history":
        by_svc = data.get("by_service", {})
        if not by_svc:
            return "No usage yet."
        return "\n".join(f"  {n}: {i.get('calls', 0)} calls, ${i.get('spent_cents', 0) / 100:.2f}" for n, i in by_svc.items())
    return "Cost actions: summary, history"


def _do_remote(tool_name, input_data=""):
    """Proxy call to a backend-pushed tool."""
    endpoint = _remote_tools.get(tool_name, {}).get("endpoint")
    if not endpoint:
        return f"Remote tool '{tool_name}' not available."
    data = json.dumps({"input": input_data}).encode()
    req = urllib.request.Request(endpoint, data=data,
        headers={"Content-Type": "application/json"}, method="POST")
    api_key = os.environ.get("OWLVIN_API_KEY", "")
    if api_key:
        req.add_header("X-API-Key", api_key)
    with urllib.request.urlopen(req, timeout=30, context=ssl_context) as r:
        return r.read().decode()


# ─────────────────────────────────────────────
# THE ONE TOOL — search routes everything
# ─────────────────────────────────────────────

mcp = FastMCP("owlvin")

@mcp.tool()
def search(request: str) -> str:
    """Searches for anything — answers questions, fetches URLs, queries
    data files, checks services, recalls memories, manages processes,
    and tracks spending. Connects to paid services like DrumSplit when
    needed. One tool, every capability."""
    start = time.time()
    q = request.strip()
    q_lower = q.lower()
    intent = _classify(request)

    try:
        # ── URL detected → fetch/podcast first ──
        url_match = URL_RE.search(q)
        if url_match:
            url = url_match.group(0)
            if PODCAST_RE.search(q_lower) or _looks_like_rss_url(url):
                intent = "podcast"
                result = _do_podcast(q, feed_url=url)
                _emit(intent, True, (time.time() - start) * 1000)
                return result

            intent = "fetch"
            result = _do_fetch(url)
            _emit(intent, True, (time.time() - start) * 1000)
            return result

        # ── Health ──
        if HEALTH_RE.search(q_lower):
            intent = "health"
            target = "all"
            for svc in ("drumsplit", "platform", "canary"):
                if svc in q_lower:
                    target = svc
                    break
            result = _do_health(target)
            _emit(intent, True, (time.time() - start) * 1000)
            return result

        # ── Memory ──
        if MEMORY_RE.search(q_lower):
            intent = "memory"
            if _contains_any(q_lower, ("save", "remember", "store")):
                # Extract what to save — everything after save/remember/store
                m = re.search(r'(?:save|remember|store)\s+(.+)', q, re.I)
                if m:
                    result = _do_memory("save", m.group(1)[:100], m.group(1))
                    _emit(intent, True, (time.time() - start) * 1000)
                    return result
            elif _contains_any(q_lower, ("recent", "latest", "last")):
                result = _do_memory("recent")
                _emit(intent, True, (time.time() - start) * 1000)
                return result
            else:
                result = _do_memory("search", q)
                _emit(intent, True, (time.time() - start) * 1000)
                return result

        # ── Process management ──
        if PROCESS_RE.search(q_lower):
            intent = "process"
            if "port" in q_lower:
                result = _do_processes("ports")
            elif "kill" in q_lower:
                name_m = re.search(r'kill\s+(\S+)', q, re.I)
                result = _do_processes("kill", name=name_m.group(1) if name_m else "")
            elif "running" in q_lower:
                result = _do_processes("list")
            elif "find" in q_lower:
                name_m = re.search(r'find\s+(\S+)', q, re.I)
                result = _do_processes("find", name=name_m.group(1) if name_m else "")
            else:
                result = _do_processes("list")
            _emit(intent, True, (time.time() - start) * 1000)
            return result

        # ── Secrets ──
        if SECRET_RE.search(q_lower):
            intent = "secret"
            name_m = re.search(r'(\w+_(?:KEY|TOKEN|SECRET|PASSWORD)\w*)', q, re.I)
            if name_m:
                key_name = name_m.group(1).upper()
                if _contains_any(q_lower, ("set", "store", "save")):
                    val_m = re.search(r'(?:to|=|:)\s*(\S+)', q[name_m.end():])
                    if val_m:
                        result = _do_secrets("set", key_name, val_m.group(1))
                    else:
                        result = f"What value should I set {key_name} to?"
                elif _contains_any(q_lower, ("raw", "actual", "full", "show")):
                    result = _do_secrets("get_raw", key_name)
                else:
                    result = _do_secrets("check", key_name)
                _emit(intent, True, (time.time() - start) * 1000)
                return result

        # ── Cost/spending ──
        if COST_RE.search(q_lower):
            intent = "cost"
            action = "history" if "history" in q_lower else "summary"
            result = _do_cost(action)
            _emit(intent, True, (time.time() - start) * 1000)
            return result

        # ── Podcast feed resolution ──
        if PODCAST_RE.search(q_lower):
            intent = "podcast"
            result = _do_podcast(q)
            _emit(intent, True, (time.time() - start) * 1000)
            return result

        # ── Document conversion ──
        if CONVERT_RE.search(q_lower):
            intent = "convert"
            file_path = _extract_path(q, DOC_FILE_EXTS)
            if not file_path:
                result = "Specify a document path to convert, for example a .pdf, .docx, .pptx, .xlsx, .html, .md, or .txt file."
            else:
                result = _do_convert(file_path)
            _emit(intent, True, (time.time() - start) * 1000)
            return result

        # ── Code linting ──
        if LINT_RE.search(q_lower):
            intent = "lint"
            lint_target = _extract_path(q, LINT_FILE_EXTS) or ("server.py" if "server.py" in q else ".")
            result = _do_lint(lint_target)
            _emit(intent, True, (time.time() - start) * 1000)
            return result

        # ── Data/SQL query ──
        if DATA_RE.search(q_lower):
            intent = "data"
            sql = _extract_sql(q)
            file_path = _extract_path(q, DATA_FILE_EXTS)
            if sql:
                if not file_path:
                    result = "SQL detected, but no data file was provided. Specify a CSV, JSON, JSONL, NDJSON, or Parquet file."
                else:
                    result = _do_query(sql, file_path)
                _emit(intent, True, (time.time() - start) * 1000)
                return result

        # ── Check for remote/dynamic tools from manifest ──
        for tool_name, tool_def in _remote_tools.items():
            keywords = tool_def.get("keywords", [])
            if any(kw in q_lower for kw in keywords):
                intent = "remote"
                result = _do_remote(tool_name, q)
                _emit(intent, True, (time.time() - start) * 1000, extra={
                    "search_match": True, "search_source": "remote",
                })
                return result

        # ── Check owlvin services (paid) ──
        matches = []
        for slug, svc in _all_services.items():
            score = sum(1 for kw in svc.get("keywords", []) if kw in q_lower)
            if score > 0:
                matches.append((score, slug, svc))

        if matches:
            intent = "service"
            matches.sort(key=lambda x: -x[0])
            lines = ["**Available on the owlvin network:**\n"]
            for _, slug, svc in matches:
                lines.append(f"**{svc['name']}** — {svc['description']}")
                lines.append(f"  Cost: {svc.get('cost', 'N/A')}\n")
            _emit(intent, True, (time.time() - start) * 1000, extra={
                "search_match": True, "search_source": "owlvin",
                "search_result_count": len(matches),
            })
            return "\n".join(lines)

        # ── No internal match — try web search fallback first ──
        web_result = _do_web_search(q)
        if web_result:
            intent = "web"
            _emit(intent, True, (time.time() - start) * 1000, extra={
                "search_match": True, "search_source": "web",
            })
            return web_result

        # ── No match — this is the product roadmap signal ──
        _emit(intent, True, (time.time() - start) * 1000, extra={
            "search_match": False, "search_source": None,
        })
        return f"Nothing found for '{request}'. This capability isn't on the owlvin network yet."

    except Exception as e:
        _emit(intent, False, (time.time() - start) * 1000, extra={"error_class": type(e).__name__})
        return f"Error: {e}"


# ─────────────────────────────────────────────
# ENTRY POINT
# ─────────────────────────────────────────────

if __name__ == "__main__":
    mcp.run()
