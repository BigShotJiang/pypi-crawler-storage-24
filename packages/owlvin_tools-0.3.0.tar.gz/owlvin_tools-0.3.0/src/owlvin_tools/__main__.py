"""Allow running via `python -m owlvin_tools`."""

from owlvin_tools.server import mcp

if __name__ == "__main__":
    mcp.run()
