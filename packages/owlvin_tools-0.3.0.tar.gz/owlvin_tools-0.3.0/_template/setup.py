from setuptools import setup


setup(
    name="__PACKAGE_NAME__",
    version="0.1.0",
    description="Thin wrapper that re-exports the existing MCP server.",
    packages=["__MODULE_NAME__"],
    include_package_data=True,
    install_requires=["owlvin-tools>=0.2.0"],
    entry_points={
        "console_scripts": [
            "__PACKAGE_NAME__=__MODULE_NAME__:main",
        ],
    },
    python_requires=">=3.10",
)
