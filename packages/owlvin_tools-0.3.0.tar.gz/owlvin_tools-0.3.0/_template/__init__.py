"""Thin wrapper around the existing MCP server package."""

from importlib import import_module


def _load_mcp():
    for module_name in ("owlvin_tools.server", "owlvin_tools", "server"):
        try:
            module = import_module(module_name)
        except ImportError:
            continue
        mcp = getattr(module, "mcp", None)
        if mcp is not None:
            return mcp
    raise ImportError("Could not locate the underlying MCP server module.")


mcp = _load_mcp()


def main():
    mcp.run()


__all__ = ["mcp", "main"]
