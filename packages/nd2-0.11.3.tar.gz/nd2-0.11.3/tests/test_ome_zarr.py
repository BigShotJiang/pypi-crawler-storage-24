"""Tests for OME-Zarr export functionality."""

from __future__ import annotations

import importlib
import importlib.util
import json
from pathlib import Path
from typing import TYPE_CHECKING

import nd2
import pytest
from nd2._util import AXIS

if TYPE_CHECKING:
    from nd2._ome_zarr import ZarrBackend

try:
    import yaozarrs
except ImportError:
    pytest.skip(
        "yaozarrs and zarr is required for OME-Zarr tests", allow_module_level=True
    )

BACKENDS: list[ZarrBackend] = []
if importlib.util.find_spec("zarr") is not None:
    BACKENDS.append("zarr")
if importlib.util.find_spec("tensorstore") is not None:
    BACKENDS.append("tensorstore")

if not BACKENDS:
    pytest.skip(
        "No supported Zarr backend (zarr or tensorstore) found", allow_module_level=True
    )

TEST_DATA = Path(__file__).parent / "data"
OME_ZARR_TEST_FILES = [
    "dims_t3c2y32x32.nd2",  # TCY
    "dims_c2y32x32.nd2",  # CYX
    "dims_z5t3c2y32x32.nd2",  # TZCYX (needs transpose)
    "cluster.nd2",  # TZCYX
    # NETimeLoop files - for time interval coverage
    "train_TR67_Inj7_fr50.nd2",  # NETimeLoop with periodDiff.avg
    "jonas_3.nd2",  # NETimeLoop with periodDiff.avg=0 (uses periodMs)
]
# Files with positions
POSITION_TEST_FILES = [
    "dims_p4z5t3c2y32x32.nd2",  # TPZCYX
    "JOBS_Platename_WellA01_ChannelWidefield_Green_Seq0000.nd2",  # PYX
]


@pytest.mark.parametrize("backend", BACKENDS)
@pytest.mark.parametrize("nd2_path", OME_ZARR_TEST_FILES)
def test_to_ome_zarr_basic(
    nd2_path: Path, tmp_path: Path, backend: ZarrBackend
) -> None:
    """Test basic OME-Zarr export without positions."""
    data_path = TEST_DATA / nd2_path
    dest = tmp_path / "test.zarr"

    with nd2.ND2File(data_path) as f:
        result = f.write_ome_zarr(dest, backend=backend)
        assert result == dest
        yaozarrs.validate_zarr_store(str(dest))


@pytest.mark.parametrize("backend", BACKENDS)
@pytest.mark.parametrize("nd2_path", POSITION_TEST_FILES)
def test_to_ome_zarr_with_positions(
    nd2_path: Path, tmp_path: Path, backend: ZarrBackend
) -> None:
    """Test OME-Zarr export with multiple positions using bioformats2raw layout."""
    data_path = TEST_DATA / nd2_path
    dest = tmp_path / "test.zarr"

    with nd2.ND2File(data_path) as f:
        n_positions = f.sizes.get(AXIS.POSITION, 1)
        result = f.write_ome_zarr(dest, backend=backend)
        assert result == dest

        # Root should have bioformats2raw.layout attribute under ome
        root_meta = json.loads((dest / "zarr.json").read_text())
        assert root_meta["attributes"]["ome"]["bioformats2raw.layout"] == 3

        # OME directory should exist with series metadata and METADATA.ome.xml
        ome_path = dest / "OME"
        assert ome_path.exists()
        assert (ome_path / "METADATA.ome.xml").exists()

        ome_meta = json.loads((ome_path / "zarr.json").read_text())
        assert ome_meta["attributes"]["ome"]["series"] == [
            str(i) for i in range(n_positions)
        ]

        # Each position should have its own group with valid OME metadata
        for i in range(n_positions):
            pos_path = dest / str(i)
            assert pos_path.exists(), f"Position {i} not found"

            # Validate each position with yaozarrs
            yaozarrs.validate_zarr_store(str(pos_path))

            # Check position name in metadata
            pos_meta = json.loads((pos_path / "zarr.json").read_text())
            assert pos_meta["attributes"]["ome"]["multiscales"][0]["name"] == str(i)


@pytest.mark.parametrize("backend", BACKENDS)
@pytest.mark.parametrize("nd2_path", POSITION_TEST_FILES)
def test_to_ome_zarr_single_position(
    nd2_path: Path, tmp_path: Path, backend: ZarrBackend
) -> None:
    """Test exporting a single position from a multi-position file."""
    data_path = TEST_DATA / nd2_path
    dest = tmp_path / "single_pos.zarr"

    with nd2.ND2File(data_path) as f:
        assert f.sizes.get(AXIS.POSITION, 1) > 1, "Test requires a multi-position file"

        # Export position 1
        result = f.write_ome_zarr(dest, position=1, backend=backend)
        assert result == dest

        # Should have OME metadata at root (not under p1)
        root_meta = json.loads((dest / "zarr.json").read_text())

        assert "ome" in root_meta["attributes"]

        # Array should be directly under root/0
        array_path = dest / "0"
        assert array_path.exists()

        # Validate
        yaozarrs.validate_zarr_store(str(dest))


@pytest.mark.parametrize("backend", BACKENDS)
def test_to_ome_zarr_force_series(tmp_path: Path, backend: ZarrBackend) -> None:
    """Test that force_series creates bioformats2raw layout for single-pos files."""
    # Use a single-position file
    data_path = TEST_DATA / "dims_c2y32x32.nd2"
    dest = tmp_path / "series.zarr"

    with nd2.ND2File(data_path) as f:
        assert AXIS.POSITION not in f.sizes, "Test requires a single-position file"

        result = f.write_ome_zarr(dest, force_series=True, backend=backend)
        assert result == dest

        # Should have bioformats2raw.layout in root zarr.json
        root_meta = json.loads((dest / "zarr.json").read_text())
        assert root_meta["attributes"]["ome"]["bioformats2raw.layout"] == 3

        # OME directory should exist with series metadata and METADATA.ome.xml
        ome_path = dest / "OME"
        assert ome_path.exists()
        assert (ome_path / "METADATA.ome.xml").exists()

        ome_meta = json.loads((ome_path / "zarr.json").read_text())
        assert ome_meta["attributes"]["ome"]["series"] == ["0"]

        # Image should be under 0/ directory
        pos_path = dest / "0"
        assert pos_path.exists()

        # Validate position with yaozarrs
        yaozarrs.validate_zarr_store(str(pos_path))


def test_to_ome_zarr_axis_transposition(tmp_path: Path) -> None:
    """Test that axes are properly transposed to OME-NGFF order."""
    zarr = pytest.importorskip("zarr")

    # Use a file with TZCYX order (Z before C in nd2)
    data_path = TEST_DATA / "dims_z5t3c2y32x32.nd2"

    dest = tmp_path / "transposed.zarr"

    with nd2.ND2File(data_path) as f:
        # ND2 order: T=3, Z=5, C=2, Y=32, X=32
        nd2_sizes = dict(f.sizes)
        assert list(nd2_sizes.keys()) == ["T", "Z", "C", "Y", "X"]

        f.write_ome_zarr(dest)

    # Read back and verify shape is TCZYX (C and Z swapped)
    arr = zarr.open_array(dest / "0")

    # Expected OME order: T=3, C=2, Z=5, Y=32, X=32
    assert arr.shape == (3, 2, 5, 32, 32)

    # Verify axes metadata is correct
    meta = json.loads((dest / "zarr.json").read_text())
    axes = meta["attributes"]["ome"]["multiscales"][0]["axes"]
    axis_names = [ax["name"] for ax in axes]
    assert axis_names == ["t", "c", "z", "y", "x"]


def test_to_ome_zarr_coordinate_transforms(tmp_path: Path) -> None:
    """Test that coordinate transformations include proper scale values."""
    data_path = TEST_DATA / "dims_c2y32x32.nd2"

    dest = tmp_path / "coords.zarr"

    with nd2.ND2File(data_path) as f:
        voxel = f.voxel_size()
        f.write_ome_zarr(dest)

    meta = json.loads((dest / "zarr.json").read_text())

    transforms = meta["attributes"]["ome"]["multiscales"][0]["datasets"][0][
        "coordinateTransformations"
    ]
    assert len(transforms) == 1
    assert transforms[0]["type"] == "scale"

    # Scale values should include voxel sizes for spatial dimensions
    scale = transforms[0]["scale"]
    # For CYX file: scales are [c_scale, y_scale, x_scale]
    assert scale[-1] == voxel.x  # X scale
    assert scale[-2] == voxel.y  # Y scale


def test_to_ome_zarr_custom_chunks(tmp_path: Path) -> None:
    """Test custom chunk specification."""
    zarr = pytest.importorskip("zarr")
    data_path = TEST_DATA / "dims_c2y32x32.nd2"

    dest = tmp_path / "chunked.zarr"
    custom_chunks = (1, 16, 16)

    with nd2.ND2File(data_path) as f:
        f.write_ome_zarr(dest, chunk_shape=custom_chunks)

    arr = zarr.open_array(dest / "0")

    # Chunks should match (or be smaller if shape is smaller)
    assert arr.chunks == custom_chunks


def test_to_ome_zarr_invalid_position(tmp_path: Path) -> None:
    """Test that invalid position index raises error."""
    data_path = TEST_DATA / "dims_p4z5t3c2y32x32.nd2"
    dest = tmp_path / "invalid.zarr"
    with nd2.ND2File(data_path) as f:
        with pytest.raises(IndexError, match="out of range"):
            f.write_ome_zarr(dest, position=100)


def test_to_ome_zarr_invalid_version(tmp_path: Path) -> None:
    """Test that invalid version raises error."""
    data_path = TEST_DATA / "dims_c2y32x32.nd2"

    dest = tmp_path / "invalid_version.zarr"

    with nd2.ND2File(data_path) as f:
        with pytest.raises(ValueError, match=r"Only version '0\.5' is supported"):
            f.write_ome_zarr(dest, version="0.4")  # type: ignore[arg-type]


def test_to_ome_zarr_invalid_backend(tmp_path: Path) -> None:
    """Test that invalid backend raises error."""
    data_path = TEST_DATA / "dims_c2y32x32.nd2"

    dest = tmp_path / "invalid_backend.zarr"

    with nd2.ND2File(data_path) as f:
        with pytest.raises(ValueError, match="Unknown writer option"):
            f.write_ome_zarr(dest, backend="invalid")  # type: ignore[arg-type]


def test_to_ome_zarr_rgb_file(tmp_path: Path) -> None:
    """Test export of pure RGB file with omero color metadata."""
    zarr = pytest.importorskip("zarr")
    data_path = TEST_DATA / "dims_rgb.nd2"
    dest = tmp_path / "rgb.zarr"

    with nd2.ND2File(data_path) as f:
        # Verify this is a pure RGB file (S axis, no C axis)
        assert AXIS.RGB in f.sizes
        assert AXIS.CHANNEL not in f.sizes

        f.write_ome_zarr(dest)

    # Validate the store
    yaozarrs.validate_zarr_store(str(dest))

    # Check metadata
    meta = json.loads((dest / "zarr.json").read_text())

    ome = meta["attributes"]["ome"]

    # Check axes - RGB should be mapped to channel axis
    axes = ome["multiscales"][0]["axes"]
    axis_names = [ax["name"] for ax in axes]
    assert "c" in axis_names
    assert "s" not in axis_names  # S should be converted to C

    # Check omero metadata for RGB rendering
    assert "omero" in ome
    assert len(ome["omero"]["channels"]) == 3
    assert ome["omero"]["channels"][0]["color"] == "FF0000"  # Red
    assert ome["omero"]["channels"][1]["color"] == "00FF00"  # Green
    assert ome["omero"]["channels"][2]["color"] == "0000FF"  # Blue

    # Check rdefs for color model
    assert ome["omero"]["rdefs"] == {"model": "color"}

    # Verify array shape - RGB samples should be the channel dimension
    arr = zarr.open_array(dest / "0")
    assert arr.shape[0] == 3  # 3 RGB channels


def test_to_ome_zarr_mixed_rgb_channel_error(tmp_path: Path) -> None:
    """Test that files with both RGB and optical channels raise ValueError."""
    data_path = TEST_DATA / "dims_rgb_c2x64y64.nd2"
    dest = tmp_path / "mixed.zarr"

    with nd2.ND2File(data_path) as f:
        # Verify this file has both C and S axes
        assert AXIS.RGB in f.sizes
        assert AXIS.CHANNEL in f.sizes

        with pytest.raises(ValueError, match="both RGB samples and multiple optical"):
            f.write_ome_zarr(dest)


@pytest.mark.parametrize("backend", BACKENDS)
def test_to_ome_zarr_wellplate(tmp_path: Path, backend: ZarrBackend) -> None:
    """Test that wellplate files are exported as OME-Zarr Plate."""
    data_path = TEST_DATA / "wellplate96_4_wells_with_jobs.nd2"
    dest = tmp_path / "wellplate.zarr"

    with nd2.ND2File(data_path) as f:
        # Verify this file has positions with well names
        assert AXIS.POSITION in f.sizes
        assert f.sizes[AXIS.POSITION] == 4

        result = f.write_ome_zarr(dest, backend=backend)
        assert result == dest

    # Validate the store
    yaozarrs.validate_zarr_store(str(dest))

    # Check plate metadata
    plate_meta = json.loads((dest / "zarr.json").read_text())

    ome = plate_meta["attributes"]["ome"]
    assert "plate" in ome

    plate = ome["plate"]
    # Should auto-generate rows A, B, C and columns 1, 2, 3, 4
    assert len(plate["rows"]) == 3
    assert [r["name"] for r in plate["rows"]] == ["A", "B", "C"]
    assert len(plate["columns"]) == 4
    assert [c["name"] for c in plate["columns"]] == ["1", "2", "3", "4"]

    # Check wells (A1, A4, B4, C2)
    assert {w["path"] for w in plate["wells"]} == {"A/1", "A/4", "B/4", "C/2"}

    # Check well structure (e.g., A/1)
    well_a1_path = dest / "A" / "1"
    assert well_a1_path.exists()

    well_meta = json.loads((well_a1_path / "zarr.json").read_text())

    assert "well" in well_meta["attributes"]["ome"]
    well = well_meta["attributes"]["ome"]["well"]
    assert len(well["images"]) == 1  # One field of view
    assert well["images"][0]["path"] == "0"

    # Check field/image structure
    field_path = well_a1_path / "0"
    assert field_path.exists()

    image_meta = json.loads((field_path / "zarr.json").read_text())

    assert "multiscales" in image_meta["attributes"]["ome"]


@pytest.mark.parametrize("backend", BACKENDS)
def test_to_ome_zarr_with_binary_labels(tmp_path: Path, backend: ZarrBackend) -> None:
    """Test that binary layers are exported as OME-Zarr labels."""
    zarr = pytest.importorskip("zarr")
    data_path = TEST_DATA / "with_binary_and_rois.nd2"
    dest = tmp_path / "binary.zarr"

    with nd2.ND2File(data_path) as f:
        # Verify this file has binary data
        assert f.binary_data is not None
        n_binary_layers = len(f.binary_data)
        assert n_binary_layers == 4

        # File has T=3, P=4, Z=5, C=2, Y=32, X=32
        assert f.sizes == {"T": 3, "P": 4, "Z": 5, "C": 2, "Y": 32, "X": 32}

        result = f.write_ome_zarr(dest, include_labels=True, backend=backend)
        assert result == dest

    # Should have bioformats2raw layout due to positions
    root_meta = json.loads((dest / "zarr.json").read_text())
    assert root_meta["attributes"]["ome"]["bioformats2raw.layout"] == 3

    # Check that labels directory exists for each position
    for pos_idx in range(4):
        pos_path = dest / str(pos_idx)
        assert pos_path.exists()

        labels_path = pos_path / "labels"
        assert labels_path.exists(), f"Labels directory missing for position {pos_idx}"

        # Check labels metadata
        labels_meta = json.loads((labels_path / "zarr.json").read_text())
        assert "labels" in labels_meta["attributes"]["ome"]
        label_names = labels_meta["attributes"]["ome"]["labels"]
        assert len(label_names) == n_binary_layers

        # Check each label has proper structure
        for label_name in label_names:
            label_path = labels_path / label_name
            assert label_path.exists()

            label_meta = json.loads((label_path / "zarr.json").read_text())
            ome = label_meta["attributes"]["ome"]

            # Should have multiscales and image-label metadata
            assert "multiscales" in ome
            assert "image-label" in ome

            # Check axes - labels don't have channel dimension
            axes = ome["multiscales"][0]["axes"]
            axis_names = [ax["name"] for ax in axes]
            assert axis_names == ["t", "z", "y", "x"]  # TZYX (no C)

            # Check label array shape (T=3, Z=5, Y=32, X=32 per position)
            arr = zarr.open_array(label_path / "0")
            assert arr.shape == (3, 5, 32, 32)


def test_to_ome_zarr_include_all_metadata(tmp_path: Path) -> None:
    """Test that include_all_metadata controls nd2 metadata inclusion."""
    data_path = TEST_DATA / "dims_c2y32x32.nd2"

    # Test with include_all_metadata=True (default)
    dest_with = tmp_path / "with_metadata.zarr"
    with nd2.ND2File(data_path) as f:
        f.write_ome_zarr(dest_with, include_all_metadata=True)

    meta_with = json.loads((dest_with / "zarr.json").read_text())
    nd2_attrs_with = meta_with["attributes"]["nd2"]
    assert "version" in nd2_attrs_with
    assert "unstructured_metadata" in nd2_attrs_with
    assert "custom_data" in nd2_attrs_with

    # Test with include_all_metadata=False
    dest_without = tmp_path / "without_metadata.zarr"
    with nd2.ND2File(data_path) as f:
        f.write_ome_zarr(dest_without, include_all_metadata=False)

    meta_without = json.loads((dest_without / "zarr.json").read_text())
    nd2_attrs_without = meta_without["attributes"]["nd2"]
    assert "version" in nd2_attrs_without
    assert "unstructured_metadata" not in nd2_attrs_without
    assert "custom_data" not in nd2_attrs_without
