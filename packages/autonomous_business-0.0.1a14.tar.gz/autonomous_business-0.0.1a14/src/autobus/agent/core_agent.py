from agents import Agent, Runner, gen_trace_id, trace
from datetime import timedelta
from temporalio import workflow
from temporalio.contrib import openai_agents
from autobus.agent.data_structure import UserDecision, UserDecisionSignal
import logging

with workflow.unsafe.imports_passed_through():
    from autobus.config import config
    from autobus.agent.activity import get_db_schema, get_prolog_template, save_text_to_file


logging.basicConfig(level=logging.INFO)

async def create_core_agent(name:str) -> Agent:

    #LLM = "gpt-5.2"
    LLM = "gemini/gemini-3-flash-preview"
    generated_dir = config['directory']['generated_dir']

    core_agent = Agent(
        name=name,
        instructions=f"""
        You are an expert in logic programming in SWI-Prolog. Generate prolog programs with facts and 
        foundational rules based on the database schema and task specific rules from the user prompt.
        Use the Prolog template 'facts_tools_rules_actions.pl'. Do not place string in multiple lines.
        Get the Task ID from the user prompt and save the program to a file with path {generated_dir}/<Task ID>_logic.pl.
        If you fail to get the prolog template or the database schema, stop and output error message.
        """,
        tools=[
            openai_agents.workflow.activity_as_tool(
                get_db_schema, 
                start_to_close_timeout=timedelta(seconds=10)
            ), 
            openai_agents.workflow.activity_as_tool(
                get_prolog_template, 
                start_to_close_timeout=timedelta(seconds=10)
            ),
            openai_agents.workflow.activity_as_tool(
                save_text_to_file, 
                start_to_close_timeout=timedelta(seconds=10)
            )],
        model = LLM
    )

    return core_agent


@workflow.defn
class CoreAgent:
    def __init__(self) -> None:
        self._current_prompt: str = ""
        # Instance variable to store Signal data
        self._user_decision: UserDecisionSignal = UserDecisionSignal(
            decision=UserDecision.WAIT
        )

    @workflow.signal
    async def user_decision_signal(self, decision_data: UserDecisionSignal) -> None:
        """Signal handler that receives user decisions"""
        self._user_decision = decision_data

    @workflow.run
    async def run(self, task_instruction: str) -> str:

        core_agent = await create_core_agent(name=type(self).__name__)

        # Continue looping until the user approves the research
        continue_user_input_loop = True

        # Execute the LLM call to generate research based on the current prompt
        while continue_user_input_loop:
            r = await Runner.run(starting_agent=core_agent, input=f"{task_instruction}\n\n{self._current_prompt}")

            # Waiting for Signal with user decision
            await workflow.wait_condition(lambda: self._user_decision.decision != UserDecision.WAIT)

            # User approved the generated logic - exit the loop and proceed to running the logic
            if self._user_decision.decision == UserDecision.KEEP:
                workflow.logger.info("User approved the logic. Running the logic...")
                continue_user_input_loop = False
            # User decided to regenerate the logic 
            elif self._user_decision.decision == UserDecision.EDIT:
                workflow.logger.info("User requested logic regeneration.")
                if self._user_decision.additional_prompt != "":
                    # Append the user's additional instructions to the existing prompt
                    self._current_prompt = f"{self._current_prompt}\nAdditional instructions: {self._user_decision.additional_prompt}"
                else:
                    workflow.logger.info("No additional instructions provided. Regenerating with original instruction.")
                # Update the Activity input with the modified prompt for the next iteration
                self._user_decision = UserDecisionSignal(decision=UserDecision.WAIT)

        return r.final_output
