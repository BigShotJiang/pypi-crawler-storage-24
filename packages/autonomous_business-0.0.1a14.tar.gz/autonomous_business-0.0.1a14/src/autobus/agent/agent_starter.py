from uuid import uuid4
import asyncio
from autobus.config import config
from autobus.agent.data_structure import UserDecision, UserDecisionSignal
from temporalio.contrib.openai_agents import OpenAIAgentsPlugin, ModelActivityParameters
from temporalio.client import Client
from datetime import timedelta
from agents.extensions.models.litellm_provider import LitellmProvider


async def send_user_decision_signal(client: Client, workflow_id: str):
    # Get handle to the Workflow Execution
    handle = client.get_workflow_handle(workflow_id)

    while True:
        print("\n" + "=" * 80)
        print("Calling LLM! Check the generated logic program.")
        print("Would you like to keep or regenerate it?")
        print("1. Type 'keep' to approve the generated logic")
        print("2. Type 'regen' to regenerate")
        print("=" * 80)

        decision = input("Your decision (keep/regen): ").strip().lower()

        if decision in {"keep", "1"}:
            signal_data = UserDecisionSignal(decision=UserDecision.KEEP)
            await handle.signal("user_decision_signal", signal_data)
            print("Signal sent to keep output")
            break

        elif decision in {"regen", "2"}:
            additional_prompt = input(
                "Enter additional instructions (optional): "
            ).strip()
            signal_data = UserDecisionSignal(
                decision=UserDecision.EDIT,
                additional_prompt=additional_prompt
            )
            await handle.signal("user_decision_signal", signal_data)
            print("Signal sent to regenerate output")

        else:
            print("Please enter either 'keep' or 'regen'")

async def start_agent_workflow(agent_class, instruction: str, task_queue:str) -> str:
    """
    Start Temporal workflow for the agent.
    """
    client = await Client.connect(
        config['temporal']['uri'], 
        plugins=[
            OpenAIAgentsPlugin(
                model_params=ModelActivityParameters(
                    start_to_close_timeout=timedelta(seconds=300)
                ),
                model_provider=LitellmProvider(),
            ),
        ],
    
    )
    
    run_id = f"{agent_class.__name__}_{uuid4().hex}"
    handle = await client.start_workflow(
        agent_class.run,
        instruction,
        id=run_id,
        task_queue=task_queue,
    )

    signal_task = asyncio.create_task(send_user_decision_signal(client, handle.id))

    print(f"Started workflow. Workflow ID: {handle.id}, RunID: {handle.result_run_id}")
    result = await handle.result()
    return result

