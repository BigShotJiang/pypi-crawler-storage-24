#!/usr/bin/env bash

trap 'pkill -P $$; exit' INT TERM EXIT

temporal server start-dev &
uv run -m autobus.agent.core_agent_worker &

wait
