from importlib.resources import files
import subprocess
import sys

def main():
    script = files("autobus.cli").joinpath("scripts/start_demo_server.sh")
    raise SystemExit(subprocess.call(["bash", str(script), *sys.argv[1:]]))
  