"""
certmesh.remote_client
=======================

HTTP client for managing a remote certmesh API instance from the CLI.

Provides a **stateless connection model** — each CLI invocation creates
a fresh client, executes one request, and exits.  Ctrl+C at any point
cleanly terminates the request and any port-forward subprocess.

Features:
* Version compatibility check (exact match required)
* OAuth2 auth detection — only sends token if server requires it
* Token lifecycle — single auth, RFC 6750 expiry detection, refresh token support
* TLS CA trust — reads SSL_CERT_FILE, REQUESTS_CA_BUNDLE, CURL_CA_BUNDLE, SSL_CERT_DIR
* Proxy support — httpx natively reads HTTP_PROXY, HTTPS_PROXY, NO_PROXY
* HTTPS warning — alerts when credentials sent over non-TLS non-loopback
* Resilience — tenacity retry + circuit breaker (reuses existing patterns)
* K8s port-forward — auto-manages kubectl subprocess for k8s:// URLs
"""

from __future__ import annotations

import logging
import os
from typing import Any, ClassVar
from urllib.parse import quote as _urlquote
from urllib.parse import urlparse, urlunparse

import click
import httpx
from tenacity import (
    retry,
    retry_if_exception_type,
    stop_after_attempt,
    wait_exponential,
)

from certmesh import __version__
from certmesh.circuit_breaker import create_circuit_breaker
from certmesh.exceptions import (
    CertMeshError,
    CircuitBreakerOpenError,
    ConfigurationError,
    RemoteConnectionError,
    VersionMismatchError,
)

logger = logging.getLogger(__name__)


class _TokenRefreshedError(Exception):
    """Internal sentinel: access token was refreshed, caller should retry."""


def _safe_path(value: str | int) -> str:
    """URL-encode a value for safe interpolation into a URL path segment.

    Prevents path traversal via user-supplied parameters like guid, arn,
    or serial (CodeQL: py/path-injection).
    """
    return _urlquote(str(value), safe="")


def _resolve_ca_bundle(ca_cert: str | None) -> str | bool:
    """Resolve the CA certificate bundle for TLS verification.

    Resolution order:
    1. Explicit ``ca_cert`` parameter (--remote-ca-cert / CM_REMOTE_CA_CERT)
    2. ``SSL_CERT_FILE`` environment variable (OpenSSL standard)
    3. ``REQUESTS_CA_BUNDLE`` environment variable (Python requests convention)
    4. ``CURL_CA_BUNDLE`` environment variable (curl convention)
    5. ``SSL_CERT_DIR`` environment variable (directory of PEM certs)
    6. System default (certifi bundle via httpx)
    """
    if ca_cert and os.path.exists(ca_cert):
        logger.debug("Using explicit CA bundle: %s", ca_cert)
        return ca_cert

    for env_var in ("SSL_CERT_FILE", "REQUESTS_CA_BUNDLE", "CURL_CA_BUNDLE"):
        path = os.environ.get(env_var)
        if path and os.path.exists(path):
            logger.debug("Using CA bundle from %s: %s", env_var, path)
            return path

    ssl_cert_dir = os.environ.get("SSL_CERT_DIR")
    if ssl_cert_dir and os.path.isdir(ssl_cert_dir):
        logger.debug("Using CA directory from SSL_CERT_DIR: %s", ssl_cert_dir)
        return ssl_cert_dir

    return True  # httpx default = certifi bundle


def _redact_url(url: str) -> str:
    """Return *url* with any userinfo (user:pass@) redacted.

    Prevents accidental clear-text logging of credentials embedded in
    URLs (CodeQL: py/clear-text-logging-sensitive-data).
    """
    try:
        parsed = urlparse(url)
        if parsed.username or parsed.password:
            # Rebuild netloc without credentials
            host = parsed.hostname or ""
            port_part = f":{parsed.port}" if parsed.port else ""
            safe = parsed._replace(netloc=f"{host}{port_part}")
            return urlunparse(safe)
    except Exception:  # noqa: BLE001 - defensive URL parsing; return original on any error
        pass
    return url


def _is_loopback(url: str) -> bool:
    """Check if a URL points to a loopback address.

    Covers the full 127.0.0.0/8 range, ``localhost``, and IPv6 ``::1``.
    Parses the hostname component to avoid substring false-positives
    like ``http://127.0.0.1.evil.com`` (CodeQL: py/incomplete-url-substring-sanitization).
    """
    import ipaddress

    try:
        hostname = urlparse(url).hostname or ""
    except Exception:  # noqa: BLE001 - defensive URL parsing; treat unparseable as non-loopback
        return False
    if hostname == "localhost":
        return True
    try:
        return ipaddress.ip_address(hostname).is_loopback
    except ValueError:
        return False


class CertMeshRemoteClient:
    """HTTP client for a remote certmesh REST API.

    Supports direct HTTPS endpoints and Kubernetes port-forward URLs.
    """

    def __init__(
        self,
        base_url: str,
        *,
        token: str | None = None,
        refresh_token: str | None = None,
        timeout: int = 30,
        ca_cert: str | None = None,
        verify_tls: bool = True,
    ) -> None:
        self._original_url = base_url
        self.token = token
        self.refresh_token = refresh_token
        self.timeout = timeout
        self.ca_cert = ca_cert
        self.verify_tls = verify_tls

        self._portforward: Any = None  # PortForwardManager or None
        self._effective_url: str = base_url
        self._session: httpx.Client | None = None
        self.oauth2_enabled: bool = False
        self.server_version: str = ""

        # Circuit breaker
        self._cb_decorator = create_circuit_breaker(
            failure_threshold=5,
            recovery_timeout_seconds=30,
            name="remote-api",
        )

    # =================================================================
    # Connection lifecycle
    # =================================================================

    def connect(self) -> None:
        """Establish connection: resolve URL, check version, detect auth."""
        # Handle k8s:// URLs
        if self._original_url.startswith("k8s://") or self._original_url.startswith("k8s+tls://"):
            self._setup_portforward()
        else:
            self._effective_url = self._original_url

        # HTTPS warning
        if (
            self.token
            and not self._effective_url.startswith("https://")
            and not _is_loopback(self._effective_url)
        ):
            msg = (
                "WARNING: JWT token is being sent over unencrypted HTTP "
                "to a non-loopback address. Use --remote https://... "
                "for production environments."
            )
            logger.warning(msg)
            click.echo(msg, err=True)

        # Build HTTP session
        verify = _resolve_ca_bundle(self.ca_cert) if self.verify_tls else False
        self._session = httpx.Client(
            base_url=self._effective_url,
            timeout=self.timeout,
            verify=verify,
            trust_env=True,  # Respects HTTP_PROXY, HTTPS_PROXY, NO_PROXY, ALL_PROXY
        )

        # Probe /api/v1/info (no auth needed)
        try:
            info = self._raw_request("GET", "/api/v1/info")
        except Exception as exc:
            logger.debug("Connection probe failed.", exc_info=True)
            raise RemoteConnectionError(
                f"Cannot reach remote certmesh API at {_redact_url(self._effective_url)}. "
                "Check that the server is running and the URL is correct."
            ) from exc

        # Version check
        self.server_version = info.get("version", "unknown")
        if self.server_version != __version__:
            raise VersionMismatchError(
                f"CLI version {__version__} does not match remote server "
                f"version {self.server_version}. Install the matching version:\n"
                f"  pip install certmesh=={self.server_version}"
            )

        # Auth detection
        self.oauth2_enabled = info.get("oauth2_enabled", False)
        if self.oauth2_enabled and not self.token:
            raise ConfigurationError(
                "Remote server requires authentication (OAuth2 enabled). "
                "Provide a JWT token via --token or CM_REMOTE_TOKEN."
            )
        if not self.oauth2_enabled:
            if self.token:
                logger.warning("Remote server does not require auth; ignoring provided token.")
            self.token = None
            self.refresh_token = None

        logger.info(
            "Connected to remote certmesh.",
            extra={
                "url": _redact_url(self._effective_url),
                "version": self.server_version,
                "oauth2_enabled": self.oauth2_enabled,
            },
        )

    def close(self) -> None:
        """Close the HTTP session and port-forward (if any)."""
        if self._session is not None:
            self._session.close()
            self._session = None
        if self._portforward is not None:
            self._portforward.stop()
            self._portforward = None

    def _setup_portforward(self) -> None:
        """Parse k8s:// URL and start kubectl port-forward."""
        from certmesh.k8s_portforward import PortForwardManager, parse_k8s_url

        namespace, service, port, use_tls = parse_k8s_url(self._original_url)
        self._portforward = PortForwardManager(
            namespace,
            service,
            port,
            use_tls=use_tls,
        )
        self._effective_url = self._portforward.start()

    def _ensure_portforward(self) -> None:
        """Check port-forward is alive; reconnect if dead."""
        if self._portforward is not None and not self._portforward.is_alive():
            logger.warning("Port-forward connection lost. Reconnecting...")
            new_url = self._portforward.reconnect()
            self._effective_url = new_url
            # Rebuild session with new base URL
            if self._session is not None:
                self._session.close()
            verify = _resolve_ca_bundle(self.ca_cert) if self.verify_tls else False
            self._session = httpx.Client(
                base_url=self._effective_url,
                timeout=self.timeout,
                verify=verify,
                trust_env=True,
            )

    # =================================================================
    # HTTP transport
    # =================================================================

    def _build_headers(self) -> dict[str, str]:
        """Build request headers including auth if needed."""
        headers: dict[str, str] = {
            "Accept": "application/json",
            "Content-Type": "application/json",
            "User-Agent": f"certmesh-cli/{__version__}",
        }
        if self.token:
            headers["Authorization"] = f"Bearer {self.token}"
        return headers

    def _raw_request(
        self,
        method: str,
        path: str,
        *,
        params: dict[str, Any] | None = None,
        json_body: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        """Execute an HTTP request without retry/circuit breaker (for /info probe)."""
        if self._session is None:
            raise RemoteConnectionError("Not connected. Call connect() first.")

        resp = self._session.request(
            method,
            path,
            params=params,
            json=json_body,
            headers=self._build_headers(),
        )
        return self._handle_response(resp)

    def _request(
        self,
        method: str,
        path: str,
        *,
        params: dict[str, Any] | None = None,
        json_body: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        """Execute an HTTP request with retry, circuit breaker, and auth handling."""
        self._ensure_portforward()

        @self._cb_decorator
        @retry(
            retry=retry_if_exception_type(
                (httpx.ConnectError, httpx.TimeoutException, _TokenRefreshedError)
            ),
            stop=stop_after_attempt(3),
            wait=wait_exponential(multiplier=1, min=1, max=10),
            reraise=True,
        )
        def _inner() -> dict[str, Any]:
            if self._session is None:
                raise RemoteConnectionError("Not connected.")
            resp = self._session.request(
                method,
                path,
                params=params,
                json=json_body,
                headers=self._build_headers(),
            )
            return self._handle_response(resp)

        try:
            return _inner()
        except httpx.ConnectError as exc:
            logger.debug("Connect error.", exc_info=True)
            raise RemoteConnectionError(
                f"Cannot connect to remote certmesh at {_redact_url(self._effective_url)}. "
                "Check that the server is running and the URL is correct."
            ) from exc
        except httpx.TimeoutException as exc:
            logger.debug("Timeout error.", exc_info=True)
            raise RemoteConnectionError(
                f"Request to remote certmesh timed out after {self.timeout}s. "
                "Increase --timeout or check network connectivity."
            ) from exc
        except _TokenRefreshedError as exc:
            raise RemoteConnectionError(
                "Token was refreshed but the request still failed after retries."
            ) from exc

    # Mapping of fixed-status codes to (exception class, message) for simple
    # cases that need no extra response inspection beyond the status code.
    _STATUS_CODE_ERRORS: ClassVar[dict[int, tuple[type[CertMeshError], str]]] = {
        403: (
            ConfigurationError,
            "Remote: forbidden (HTTP 403). Insufficient token scopes or "
            "user not in the required group.",
        ),
        429: (CertMeshError, ""),  # handled with Retry-After; sentinel entry
        503: (
            CircuitBreakerOpenError,
            "Remote: service unavailable (HTTP 503). The server may be "
            "starting up or a circuit breaker is open.",
        ),
    }

    @staticmethod
    def _extract_error_detail(resp: httpx.Response, fallback: str = "") -> str:
        """Extract the ``detail`` field from a JSON error response.

        Returns *fallback* (or the first 300 chars of the response body)
        when the response is not valid JSON or lacks a ``detail`` key.
        """
        effective_fallback = fallback if fallback else resp.text[:300]
        try:
            return str(resp.json().get("detail", effective_fallback))
        except Exception:  # noqa: BLE001 - best-effort JSON detail extraction
            return effective_fallback

    def _handle_401_response(self, resp: httpx.Response) -> None:
        """Handle HTTP 401: attempt token refresh or raise auth error."""
        www_auth = resp.headers.get("WWW-Authenticate", "")
        if "invalid_token" in www_auth or "expired" in www_auth.lower():
            if self.refresh_token and self._try_refresh_token():
                raise _TokenRefreshedError()
            raise ConfigurationError(
                "JWT token has expired (HTTP 401). Provide a new token via --token"
                + (
                    " or use --refresh-token to enable automatic renewal."
                    if not self.refresh_token
                    else "."
                )
            )
        raise ConfigurationError(
            "Remote: authentication failed (HTTP 401). "
            "Check your --token value and ensure your user/group claims are correct."
        )

    def _handle_error_response(self, resp: httpx.Response) -> None:
        """Handle non-401 HTTP error responses (status >= 400)."""
        if resp.status_code in self._STATUS_CODE_ERRORS:
            exc_cls, message = self._STATUS_CODE_ERRORS[resp.status_code]
            if resp.status_code == 429:
                retry_after = resp.headers.get("Retry-After", "60")
                message = f"Remote: rate limited (HTTP 429). Retry after {retry_after}s."
            raise exc_cls(message)

        if resp.status_code == 404:
            detail = self._extract_error_detail(resp, fallback="Resource not found")
            raise CertMeshError(f"Remote: {detail} (HTTP 404)")
        if resp.status_code >= 500:
            raise RemoteConnectionError(f"Remote: server error (HTTP {resp.status_code})")
        detail = self._extract_error_detail(resp)
        raise CertMeshError(f"Remote: {detail} (HTTP {resp.status_code})")

    def _handle_response(self, resp: httpx.Response) -> dict[str, Any]:
        """Map HTTP responses to CertMesh exceptions or parsed JSON."""
        if resp.status_code == 401:
            self._handle_401_response(resp)
        if resp.status_code >= 400:
            self._handle_error_response(resp)

        if not resp.content:
            return {}
        try:
            return resp.json()
        except Exception:  # noqa: BLE001 - fallback when response is not valid JSON
            return {"raw": resp.text}

    def _try_refresh_token(self) -> bool:
        """Attempt to refresh the access token using the refresh token."""
        if not self.refresh_token or not self._session:
            return False

        # Block refresh over unencrypted HTTP to non-loopback (credential protection)
        if not self._effective_url.startswith("https://") and not _is_loopback(
            self._effective_url
        ):
            logger.error(
                "Refusing to send refresh token over unencrypted HTTP "
                "to a non-loopback address. Use HTTPS or connect via loopback."
            )
            return False

        try:
            resp = self._session.post(
                "/api/v1/auth/token",
                headers={
                    "Authorization": f"Bearer {self.refresh_token}",
                    "Content-Type": "application/json",
                },
            )
            if resp.status_code == 200:
                data = resp.json()
                self.token = data.get("api_key") or data.get("access_token", "")
                if self.token:
                    logger.info("Access token refreshed successfully.")
                    return True
            logger.warning(
                "Token refresh failed.",
                extra={"status_code": resp.status_code},
            )
        except (CertMeshError, ConnectionError, OSError) as exc:
            logger.warning("Token refresh error: %s", exc)

        return False

    # =================================================================
    # Venafi operations
    # =================================================================

    def venafi_list(self, *, limit: int = 100, offset: int = 0) -> Any:
        return self._request(
            "GET", "/api/v1/venafi/certificates", params={"limit": limit, "offset": offset}
        )

    def venafi_search(self, **filters: Any) -> Any:
        return self._request("POST", "/api/v1/venafi/certificates/search", json_body=filters)

    def venafi_describe(self, guid: str) -> Any:
        return self._request("GET", f"/api/v1/venafi/certificates/{_safe_path(guid)}")

    def venafi_renew(self, guid: str) -> Any:
        return self._request("POST", f"/api/v1/venafi/certificates/{_safe_path(guid)}/renew")

    def venafi_revoke(self, **kwargs: Any) -> Any:
        guid = kwargs.pop("guid", kwargs.pop("dn", "unknown"))
        return self._request(
            "POST", f"/api/v1/venafi/certificates/{_safe_path(guid)}/revoke", json_body=kwargs
        )

    # =================================================================
    # DigiCert operations
    # =================================================================

    def digicert_list(self, **kwargs: Any) -> Any:
        return self._request("GET", "/api/v1/digicert/certificates", params=kwargs)

    def digicert_search(self, **kwargs: Any) -> Any:
        return self._request("POST", "/api/v1/digicert/certificates/search", json_body=kwargs)

    def digicert_describe(self, cert_id: int) -> Any:
        return self._request("GET", f"/api/v1/digicert/certificates/{_safe_path(cert_id)}")

    def digicert_order(self, **kwargs: Any) -> Any:
        return self._request("POST", "/api/v1/digicert/orders", json_body=kwargs)

    def digicert_revoke(self, order_id: int, **kwargs: Any) -> Any:
        return self._request(
            "POST",
            f"/api/v1/digicert/certificates/{_safe_path(order_id)}/revoke",
            json_body=kwargs,
        )

    # =================================================================
    # Vault PKI operations
    # =================================================================

    def vault_pki_list(self) -> Any:
        return self._request("GET", "/api/v1/vault-pki/certificates")

    def vault_pki_issue(self, **kwargs: Any) -> Any:
        return self._request("POST", "/api/v1/vault-pki/certificates", json_body=kwargs)

    def vault_pki_read(self, serial: str) -> Any:
        return self._request("GET", f"/api/v1/vault-pki/certificates/{_safe_path(serial)}")

    def vault_pki_sign(self, **kwargs: Any) -> Any:
        return self._request("POST", "/api/v1/vault-pki/sign", json_body=kwargs)

    def vault_pki_revoke(self, serial: str) -> Any:
        return self._request(
            "POST", "/api/v1/vault-pki/revoke", json_body={"serial_number": serial}
        )

    # =================================================================
    # ACM operations
    # =================================================================

    def acm_list(self, **kwargs: Any) -> Any:
        return self._request("GET", "/api/v1/acm/certificates", params=kwargs)

    def acm_request(self, **kwargs: Any) -> Any:
        return self._request("POST", "/api/v1/acm/certificates", json_body=kwargs)

    def acm_describe(self, arn: str) -> Any:
        return self._request("GET", f"/api/v1/acm/certificates/{_safe_path(arn)}/detail")

    def acm_export(self, arn: str, passphrase: str) -> Any:
        return self._request(
            "POST",
            f"/api/v1/acm/certificates/{_safe_path(arn)}/export",
            json_body={"passphrase": passphrase},
        )

    def acm_delete(self, arn: str) -> Any:
        return self._request("DELETE", f"/api/v1/acm/certificates/{_safe_path(arn)}")

    def acm_validation_records(self, arn: str) -> Any:
        return self._request(
            "GET", f"/api/v1/acm/certificates/{_safe_path(arn)}/validation-records"
        )

    # =================================================================
    # Health operations
    # =================================================================

    def health(self) -> Any:
        return self._request("GET", "/healthz")

    def readiness(self) -> Any:
        return self._request("GET", "/readyz")
