"""
certmesh.circuit_breaker
=========================

A lightweight, thread-safe circuit breaker implemented as a factory function
returning a callable decorator.

State machine::

    CLOSED ──(failures >= threshold)──> OPEN
      ^                                    |
      |                           (recovery_timeout elapsed)
      |                                    v
      └──────────(probe succeeds)──── HALF_OPEN
                                           |
                                  (probe fails)
                                           |
                                           v
                                         OPEN
"""

from __future__ import annotations

import logging
import threading
import time
from collections.abc import Callable
from dataclasses import dataclass, field
from enum import Enum
from typing import Any, TypeVar

from certmesh.exceptions import CircuitBreakerOpenError

logger = logging.getLogger(__name__)

F = TypeVar("F", bound=Callable[..., Any])


class _State(Enum):
    CLOSED = "CLOSED"
    OPEN = "OPEN"
    HALF_OPEN = "HALF_OPEN"


@dataclass
class _CircuitBreakerState:
    """Mutable state container for a circuit breaker instance."""

    circuit: _State = _State.CLOSED
    failure_count: int = 0
    last_failure_time: float | None = None
    probe_in_flight: bool = False
    lock: threading.Lock = field(default_factory=threading.Lock)


def _on_success(state: _CircuitBreakerState, name: str) -> None:
    """Record a successful call and transition to CLOSED."""
    if state.circuit != _State.CLOSED:
        logger.info(
            "Circuit breaker probe succeeded, transitioning to CLOSED",
            extra={"breaker_name": name, "previous_state": state.circuit.value},
        )
    state.circuit = _State.CLOSED
    state.failure_count = 0
    state.probe_in_flight = False


def _on_failure(
    state: _CircuitBreakerState,
    name: str,
    failure_threshold: int,
) -> None:
    """Record a failed call and potentially transition to OPEN."""
    state.probe_in_flight = False
    state.failure_count += 1
    state.last_failure_time = time.monotonic()

    if state.failure_count >= failure_threshold:
        previous = state.circuit
        state.circuit = _State.OPEN
        if previous != _State.OPEN:
            logger.warning(
                "Circuit breaker opened after consecutive failures",
                extra={"breaker_name": name, "failure_count": state.failure_count},
            )
    else:
        logger.debug(
            "Circuit breaker failure recorded",
            extra={
                "breaker_name": name,
                "failure_count": state.failure_count,
                "failure_threshold": failure_threshold,
            },
        )


def _handle_open_state(
    state: _CircuitBreakerState,
    name: str,
    recovery_timeout_seconds: float,
) -> _State:
    """Handle OPEN state: transition to HALF_OPEN or raise."""
    elapsed: float = time.monotonic() - state.last_failure_time  # type: ignore[operator]
    if elapsed >= recovery_timeout_seconds:
        state.circuit = _State.HALF_OPEN
        logger.info(
            "Circuit breaker recovery timeout elapsed, transitioning OPEN to HALF_OPEN",
            extra={"breaker_name": name},
        )
        return _State.HALF_OPEN

    remaining: float = recovery_timeout_seconds - elapsed
    raise CircuitBreakerOpenError(
        f"Circuit breaker '{name}' is OPEN. Next probe allowed in {remaining:.1f}s."
    )


def _handle_half_open_state(state: _CircuitBreakerState, name: str) -> bool:
    """Handle HALF_OPEN state: guard against concurrent probes."""
    if state.probe_in_flight:
        raise CircuitBreakerOpenError(
            f"Circuit breaker '{name}' is HALF_OPEN. A probe is already in flight."
        )
    state.probe_in_flight = True
    logger.debug("Circuit breaker allowing HALF_OPEN probe call", extra={"breaker_name": name})
    return True


def _check_and_maybe_advance(
    state: _CircuitBreakerState,
    name: str,
    recovery_timeout_seconds: float,
) -> bool:
    """Check state and advance if needed. Returns True if this call is a HALF_OPEN probe."""
    circuit = state.circuit
    if circuit == _State.OPEN:
        circuit = _handle_open_state(state, name, recovery_timeout_seconds)

    if circuit == _State.HALF_OPEN:
        return _handle_half_open_state(state, name)

    return False


def create_circuit_breaker(
    *,
    failure_threshold: int,
    recovery_timeout_seconds: float,
    name: str = "unnamed",
) -> Callable[[Callable[..., Any]], Callable[..., Any]]:
    """Return a decorator that wraps callables with circuit breaker protection."""
    if failure_threshold < 1:
        raise ValueError("failure_threshold must be >= 1.")
    if recovery_timeout_seconds <= 0:
        raise ValueError("recovery_timeout_seconds must be > 0.")

    state = _CircuitBreakerState()

    def decorator(func: Callable[..., Any]) -> Callable[..., Any]:
        def wrapper(*args: Any, **kwargs: Any) -> Any:
            with state.lock:
                is_probe = _check_and_maybe_advance(state, name, recovery_timeout_seconds)

            try:
                result = func(*args, **kwargs)
            except CircuitBreakerOpenError:
                raise
            except Exception as exc:
                with state.lock:
                    _on_failure(state, name, failure_threshold)
                logger.debug(
                    "Circuit breaker recorded failure",
                    extra={
                        "breaker_name": name,
                        "exception_type": type(exc).__name__,
                        "exception_message": str(exc),
                    },
                )
                raise
            except BaseException:
                # Ensure probe_in_flight is cleared for non-Exception base exceptions
                # (e.g. KeyboardInterrupt, SystemExit) so the circuit can recover.
                if is_probe:
                    with state.lock:
                        state.probe_in_flight = False
                raise
            else:
                with state.lock:
                    _on_success(state, name)
                return result

        wrapper.__name__ = getattr(func, "__name__", "wrapped")
        wrapper.__doc__ = func.__doc__
        return wrapper

    return decorator
