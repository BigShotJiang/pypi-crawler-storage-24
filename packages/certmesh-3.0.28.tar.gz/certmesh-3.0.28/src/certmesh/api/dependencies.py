"""
certmesh.api.dependencies
===========================

Shared FastAPI dependency functions used across route modules.

Centralises the repeated patterns for extracting auth, Vault client, and
provider config from ``request.app.state`` so that each route module doesn't
re-define the same one-liners.
"""

from __future__ import annotations

from typing import Any

from fastapi import HTTPException, Request, status

from certmesh.api.auth import JWTBearer


def get_auth(request: Request) -> JWTBearer:
    """Return the ``JWTBearer`` instance from app state."""
    return request.app.state.jwt_bearer


def get_vault_client(request: Request) -> Any | None:
    """Return the Vault client from app state, or ``None`` if not configured."""
    return getattr(request.app.state, "vault_client", None)


def require_vault_client(request: Request) -> Any:
    """Return the Vault client or raise HTTP 503 if not configured."""
    vault_cl = getattr(request.app.state, "vault_client", None)
    if vault_cl is None:
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail="Vault client is not configured or unavailable.",
        )
    return vault_cl


def _get_provider_and_vault_deps(request: Request, provider_key: str) -> tuple[dict, dict, Any]:
    """Return ``(provider_cfg, vault_cfg, vault_client)`` for a named provider.

    Uses ``.get()`` for both config sections so that a missing provider
    section yields an empty dict rather than an unhandled ``KeyError``.
    """
    provider_cfg: dict = request.app.state.config.get(provider_key) or {}
    vault_cfg: dict = request.app.state.config.get("vault") or {}
    vault_cl = getattr(request.app.state, "vault_client", None)
    return provider_cfg, vault_cfg, vault_cl


def get_acm_deps(request: Request) -> tuple[dict, Any]:
    """Return ``(acm_cfg, vault_client)`` for ACM route handlers."""
    acm_cfg: dict = request.app.state.config.get("acm") or {}
    vault_cl = getattr(request.app.state, "vault_client", None)
    return acm_cfg, vault_cl


def get_digicert_deps(request: Request) -> tuple[dict, dict, Any]:
    """Return ``(digicert_cfg, vault_cfg, vault_client)`` for DigiCert route handlers."""
    return _get_provider_and_vault_deps(request, "digicert")


def get_venafi_deps(request: Request) -> tuple[dict, dict, Any]:
    """Return ``(venafi_cfg, vault_cfg, vault_client)`` for Venafi route handlers."""
    return _get_provider_and_vault_deps(request, "venafi")
