/**
 * certmesh Log Viewer JavaScript
 *
 * Handles log loading, search, filtering, pagination, and auto-refresh
 * for the dashboard log viewer page.
 */

var CertMeshLogs = (function () {
    'use strict';

    var currentOffset = 0;
    var currentLimit = 200;
    var currentTotal = 0;
    var refreshTimer = null;
    var autoScroll = true;
    var REFRESH_INTERVAL = 5000; // 5 seconds for logs

    function init() {
        loadLogs();
        loadStats();
        setupEventListeners();
        startRefreshTimer();

        // Pause when tab hidden
        document.addEventListener('visibilitychange', function () {
            if (document.hidden) {
                stopRefreshTimer();
            } else {
                loadLogs();
                startRefreshTimer();
            }
        });
    }

    function setupEventListeners() {
        var searchInput = document.getElementById('logSearch');
        if (searchInput) {
            var debounceTimer = null;
            searchInput.addEventListener('input', function () {
                clearTimeout(debounceTimer);
                debounceTimer = setTimeout(function () {
                    currentOffset = 0;
                    loadLogs();
                }, 300);
            });
        }

        var levelFilter = document.getElementById('logLevelFilter');
        if (levelFilter) {
            levelFilter.addEventListener('change', function () {
                currentOffset = 0;
                loadLogs();
            });
        }

        var datePicker = document.getElementById('logDatePicker');
        if (datePicker) {
            datePicker.addEventListener('change', function () {
                currentOffset = 0;
                if (this.value) {
                    loadHistoricalLogs(this.value);
                } else {
                    loadLogs();
                }
            });
        }

        var refreshBtn = document.getElementById('logRefreshBtn');
        if (refreshBtn) {
            refreshBtn.addEventListener('click', function () {
                var datePicker = document.getElementById('logDatePicker');
                if (datePicker && datePicker.value) {
                    loadHistoricalLogs(datePicker.value);
                } else {
                    loadLogs();
                }
            });
        }

        var autoScrollToggle = document.getElementById('logAutoScroll');
        if (autoScrollToggle) {
            autoScrollToggle.addEventListener('change', function () {
                autoScroll = this.checked;
            });
        }

        var prevBtn = document.getElementById('logPrevBtn');
        if (prevBtn) {
            prevBtn.addEventListener('click', function () {
                if (currentOffset > 0) {
                    currentOffset = Math.max(0, currentOffset - currentLimit);
                    loadLogs();
                }
            });
        }

        var nextBtn = document.getElementById('logNextBtn');
        if (nextBtn) {
            nextBtn.addEventListener('click', function () {
                if (currentOffset + currentLimit < currentTotal) {
                    currentOffset += currentLimit;
                    loadLogs();
                }
            });
        }
    }

    function loadLogs() {
        var search = (document.getElementById('logSearch') || {}).value || '';
        var level = (document.getElementById('logLevelFilter') || {}).value || '';

        var params = new URLSearchParams();
        if (search) params.set('search', search);
        if (level) params.set('level', level);
        params.set('limit', currentLimit);
        params.set('offset', currentOffset);

        fetch('/dashboard/api/logs?' + params.toString(), {
            credentials: 'same-origin',
            headers: { 'Accept': 'application/json' }
        })
        .then(function (resp) {
            if (resp.status === 401) {
                window.location.href = '/dashboard/login?error=session_expired';
                return null;
            }
            return resp.json();
        })
        .then(function (data) {
            if (!data) return;
            currentTotal = data.total || 0;
            renderLogs(data.logs || []);
            updatePagination();
        })
        .catch(function (err) {
            console.error('Failed to load logs:', err);
        });
    }

    function loadHistoricalLogs(date) {
        var search = (document.getElementById('logSearch') || {}).value || '';
        var level = (document.getElementById('logLevelFilter') || {}).value || '';

        var params = new URLSearchParams();
        params.set('date', date);
        if (search) params.set('search', search);
        if (level) params.set('level', level);
        params.set('limit', 500);

        fetch('/dashboard/api/logs/history?' + params.toString(), {
            credentials: 'same-origin',
            headers: { 'Accept': 'application/json' }
        })
        .then(function (resp) {
            if (resp.status === 401) {
                window.location.href = '/dashboard/login?error=session_expired';
                return null;
            }
            return resp.json();
        })
        .then(function (data) {
            if (!data) return;
            currentTotal = data.total || 0;
            renderLogs(data.logs || []);
            updatePagination();
        })
        .catch(function (err) {
            console.error('Failed to load historical logs:', err);
        });
    }

    function loadStats() {
        fetch('/dashboard/api/logs/stats', {
            credentials: 'same-origin',
            headers: { 'Accept': 'application/json' }
        })
        .then(function (resp) { return resp.json(); })
        .then(function (data) {
            var info = document.getElementById('logStoreInfo');
            if (info && data) {
                var parts = [];
                if (data.s3_available) {
                    parts.push('S3: connected');
                } else {
                    parts.push('S3: in-memory only');
                }
                if (data.retention_days > 0) {
                    parts.push('Retention: ' + data.retention_days + ' days');
                } else {
                    parts.push('Retention: indefinite');
                }
                parts.push('Buffered: ' + (data.buffered || 0));
                info.textContent = parts.join(' | ');
            }
        })
        .catch(function () {});
    }

    function renderLogs(logs) {
        var tbody = document.getElementById('logTableBody');
        if (!tbody) return;

        if (logs.length === 0) {
            tbody.innerHTML =
                '<tr><td colspan="4" class="text-center py-5 text-body-secondary">' +
                '<i class="bi bi-inbox me-2"></i>No log entries found</td></tr>';
            var countEl = document.getElementById('logTotalCount');
            if (countEl) countEl.textContent = '0 logs';
            return;
        }

        var html = '';
        logs.forEach(function (log) {
            var levelClass = getLevelClass(log.level || '');
            var ts = formatTimestamp(log.timestamp || '');
            var msg = escapeHtml(log.message || '');
            var loggerName = escapeHtml(log.logger || '');

            html += '<tr class="cm-log-row">';
            html += '<td class="cm-log-ts text-body-secondary"><small>' + ts + '</small></td>';
            html += '<td><span class="badge cm-log-level ' + levelClass + '">' +
                    escapeHtml(log.level || '') + '</span></td>';
            html += '<td class="text-body-secondary"><small>' + loggerName + '</small></td>';
            html += '<td class="cm-log-msg">' + msg;
            // Show extra fields
            if (log.provider || log.cert_id || log.error) {
                html += ' <small class="text-body-secondary">';
                if (log.provider) html += '[provider=' + escapeHtml(log.provider) + '] ';
                if (log.cert_id) html += '[cert=' + escapeHtml(log.cert_id) + '] ';
                if (log.error) html += '[error=' + escapeHtml(log.error) + ']';
                html += '</small>';
            }
            html += '</td>';
            html += '</tr>';
        });

        tbody.innerHTML = html;

        var countEl = document.getElementById('logTotalCount');
        if (countEl) countEl.textContent = currentTotal + ' logs';

        // Auto-scroll to bottom
        if (autoScroll) {
            var container = document.getElementById('logContainer');
            if (container) container.scrollTop = container.scrollHeight;
        }
    }

    function getLevelClass(level) {
        switch ((level || '').toUpperCase()) {
            case 'DEBUG': return 'cm-level-debug';
            case 'INFO': return 'cm-level-info';
            case 'WARNING': return 'cm-level-warning';
            case 'ERROR': return 'cm-level-error';
            case 'CRITICAL': return 'cm-level-critical';
            default: return 'cm-level-debug';
        }
    }

    function formatTimestamp(ts) {
        if (!ts) return '--';
        try {
            var d = new Date(ts);
            if (isNaN(d.getTime())) return escapeHtml(ts);
            return d.toLocaleString('en-GB', {
                year: 'numeric', month: '2-digit', day: '2-digit',
                hour: '2-digit', minute: '2-digit', second: '2-digit',
                hour12: false
            });
        } catch (e) {
            return escapeHtml(ts);
        }
    }

    function updatePagination() {
        var paginationEl = document.getElementById('logPagination');
        if (paginationEl) {
            var start = currentTotal > 0 ? currentOffset + 1 : 0;
            var end = Math.min(currentOffset + currentLimit, currentTotal);
            paginationEl.textContent = 'Showing ' + start + '-' + end + ' of ' + currentTotal + ' logs';
        }

        var prevBtn = document.getElementById('logPrevBtn');
        if (prevBtn) prevBtn.disabled = currentOffset <= 0;

        var nextBtn = document.getElementById('logNextBtn');
        if (nextBtn) nextBtn.disabled = currentOffset + currentLimit >= currentTotal;
    }

    function startRefreshTimer() {
        if (refreshTimer) return;
        refreshTimer = setInterval(function () {
            var datePicker = document.getElementById('logDatePicker');
            if (!datePicker || !datePicker.value) {
                loadLogs();
            }
        }, REFRESH_INTERVAL);
    }

    function stopRefreshTimer() {
        if (refreshTimer) {
            clearInterval(refreshTimer);
            refreshTimer = null;
        }
    }

    function escapeHtml(str) {
        var div = document.createElement('div');
        div.appendChild(document.createTextNode(str));
        return div.innerHTML;
    }

    return {
        init: init,
        loadLogs: loadLogs
    };
})();
