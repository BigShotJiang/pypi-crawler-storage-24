"""
certmesh.api.routes.logs
=========================

Dashboard log viewer API and page routes.

Routes:
- ``GET  /dashboard/logs``                -- log viewer page
- ``GET  /dashboard/api/logs``            -- query recent logs (JSON)
- ``GET  /dashboard/api/logs/history``    -- query historical S3 logs (JSON)
- ``GET  /dashboard/api/logs/stats``      -- log store statistics (JSON)
"""

from __future__ import annotations

import logging
from typing import Annotated, Any

from fastapi import APIRouter, Query, Request, Response
from fastapi.responses import HTMLResponse, JSONResponse

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/dashboard", tags=["dashboard-logs"])


def _get_templates(request: Request) -> Any:
    return request.app.state.dashboard_templates


def _get_session(request: Request) -> dict[str, Any] | None:
    session_manager = request.app.state.session_manager
    cookie = request.cookies.get("cm_session")
    if not cookie:
        return None
    return session_manager.load_session(cookie)


def _require_session(request: Request) -> dict[str, Any]:
    session = _get_session(request)
    if not session or "user" not in session:
        from fastapi import HTTPException, status

        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Not authenticated.",
        )
    return session


def _get_log_store(request: Request) -> Any:
    return getattr(request.app.state, "log_store", None)


# ── Log viewer page ─────────────────────────────────────────────────────────


@router.get("/logs", response_class=HTMLResponse)
async def logs_page(request: Request) -> Response:
    """Log viewer dashboard page."""
    session = _get_session(request)
    if not session or "user" not in session:
        from fastapi.responses import RedirectResponse

        return RedirectResponse(url="/dashboard/auth/start", status_code=302)

    templates = _get_templates(request)
    return templates.TemplateResponse(
        request,
        "logs.html",
        {
            "user": session.get("user", {}),
            "csrf_token": session.get("csrf_token", ""),
        },
    )


# ── Log query API ───────────────────────────────────────────────────────────


@router.get("/api/logs")
async def api_logs(
    request: Request,
    search: Annotated[str, Query(max_length=500)] = "",
    level: str = "",
    logger_name: str = "",
    provider: str = "",
    start_time: str = "",
    end_time: str = "",
    limit: int = 200,
    offset: int = 0,
) -> JSONResponse:
    """Query recent log records.

    Returns JSON with ``logs``, ``total``, ``limit``, ``offset``.
    Logs are returned newest-first from the in-memory buffer.
    """
    _require_session(request)

    log_store = _get_log_store(request)
    if log_store is None:
        return JSONResponse(content={"logs": [], "total": 0, "limit": limit, "offset": offset})

    # Clamp limit
    limit = min(max(limit, 1), 1000)
    offset = max(offset, 0)

    result = log_store.query(
        search=search,
        level=level,
        logger_name=logger_name,
        provider=provider,
        start_time=start_time,
        end_time=end_time,
        limit=limit,
        offset=offset,
    )
    return JSONResponse(content=result)


@router.get("/api/logs/history")
async def api_logs_history(
    request: Request,
    date: str = "",
    search: Annotated[str, Query(max_length=500)] = "",
    level: str = "",
    limit: int = 500,
) -> JSONResponse:
    """Query historical logs from S3 for a specific date.

    Args:
        date: Date in ``YYYY-MM-DD`` format.
        search: Text filter.
        level: Log level filter (DEBUG, INFO, WARNING, ERROR).
        limit: Max records to return.
    """
    _require_session(request)

    log_store = _get_log_store(request)
    if log_store is None:
        return JSONResponse(content={"logs": [], "total": 0, "date": date})

    limit = min(max(limit, 1), 2000)

    result = log_store.query_s3(
        date=date,
        search=search,
        level=level,
        limit=limit,
    )
    return JSONResponse(content=result)


@router.get("/api/logs/stats")
async def api_logs_stats(request: Request) -> JSONResponse:
    """Return log store statistics."""
    _require_session(request)

    log_store = _get_log_store(request)
    if log_store is None:
        return JSONResponse(content={"enabled": False})

    stats = log_store.get_stats()
    stats["enabled"] = True
    return JSONResponse(content=stats)
