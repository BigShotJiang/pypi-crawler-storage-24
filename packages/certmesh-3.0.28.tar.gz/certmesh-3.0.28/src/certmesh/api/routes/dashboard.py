"""
certmesh.api.routes.dashboard
================================

Web UI dashboard routes for certificate lifecycle management.

Provides a browser-based dashboard with OAuth2 SSO login, certificate
inventory views, renewal/revocation actions, and expiry timeline
visualisation.

All state-changing operations are protected by CSRF tokens.
Auth endpoints are rate-limited.

Routes:
- ``GET  /dashboard``                          -- main dashboard (redirect to login if unauthenticated)
- ``GET  /dashboard/login``                    -- login page
- ``GET  /dashboard/callback``                 -- OAuth2 callback
- ``POST /dashboard/logout``                   -- logout (clear session)
- ``GET  /dashboard/api/certificates``         -- JSON certificate data
- ``POST /dashboard/api/certificates/{provider}/{id}/renew``  -- trigger renewal
- ``POST /dashboard/api/certificates/{provider}/{id}/revoke`` -- trigger revocation
- ``GET  /dashboard/api/timeline``             -- expiry timeline data
- ``GET  /dashboard/api/logs/stream``          -- live log stream (SSE)
"""

from __future__ import annotations

import asyncio
import dataclasses
import json
import logging
import re
import time
from datetime import datetime, timezone
from typing import Annotated, Any, Literal

from fastapi import APIRouter, HTTPException, Path, Request, Response, status
from fastapi.responses import HTMLResponse, JSONResponse, RedirectResponse, StreamingResponse

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/dashboard", tags=["dashboard"])

# Allowed certificate ID pattern (alphanumeric, hyphens, underscores, dots, colons).
_CERT_ID_RE = re.compile(r"^[a-zA-Z0-9\-_.:]{1,256}$")

# Supported certificate providers.
SUPPORTED_PROVIDERS = ("digicert", "venafi", "acm", "vault_pki")


# ── Helper functions ──────────────────────────────────────────────────────────


def _get_templates(request: Request) -> Any:
    """Return the Jinja2Templates instance from app state."""
    return request.app.state.dashboard_templates


def _get_session_manager(request: Request) -> Any:
    """Return the SessionManager from app state."""
    return request.app.state.session_manager


def _get_oauth2_flow_config(request: Request) -> Any:
    """Return the OAuth2FlowConfig from app state."""
    return request.app.state.oauth2_flow_config


def _get_dashboard_state(request: Request) -> Any:
    """Return the DashboardStateStore from app state."""
    return request.app.state.dashboard_state


def _get_session(request: Request) -> dict[str, Any] | None:
    """Extract and validate the session from the request cookie."""
    session_manager = _get_session_manager(request)
    cookie = request.cookies.get("cm_session")
    if not cookie:
        return None
    return session_manager.load_session(cookie)


def _require_session(request: Request) -> dict[str, Any]:
    """Require a valid session or raise 401."""
    session = _get_session(request)
    if not session or "user" not in session:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Not authenticated. Please log in at /dashboard/login.",
        )
    return session


def _validate_csrf(request: Request, session: dict[str, Any], form_token: str) -> None:
    """Validate a CSRF token from a form submission against the session."""
    session_csrf = session.get("csrf_token", "")
    if not session_csrf or not form_token or form_token != session_csrf:
        logger.warning(
            "CSRF validation failed",
            extra={"path": request.url.path},
        )
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="CSRF token validation failed. Please reload the page and try again.",
        )


def _set_session_cookie(response: Response, token: str, max_age: int) -> None:
    """Set the session cookie with security attributes."""
    response.set_cookie(
        key="cm_session",
        value=token,
        max_age=max_age,
        httponly=True,
        samesite="lax",
        secure=True,
        path="/dashboard",
    )


# ── Dashboard pages ──────────────────────────────────────────────────────────


@router.get("", response_class=HTMLResponse)
async def dashboard_index(request: Request) -> Response:
    """Main dashboard page.

    Redirects to the SSO provider if the user is not authenticated.
    Shows certificate inventory, status summary, and expiry timeline.
    """
    session = _get_session(request)
    if not session or "user" not in session:
        return RedirectResponse(url="/dashboard/auth/start", status_code=302)

    templates = _get_templates(request)
    user = session.get("user", {})
    csrf_token = session.get("csrf_token", "")

    return templates.TemplateResponse(
        request,
        "dashboard.html",
        {
            "user": user,
            "csrf_token": csrf_token,
        },
    )


@router.get("/login", response_class=HTMLResponse)
async def dashboard_login(request: Request) -> Response:
    """Login page with SSO redirect button.

    If already authenticated, redirects to the dashboard.
    Displays error messages passed via query parameters.
    """
    session = _get_session(request)
    if session and "user" in session:
        return RedirectResponse(url="/dashboard", status_code=302)

    templates = _get_templates(request)
    error = request.query_params.get("error", "")

    # Map error codes to user-friendly messages
    error_messages: dict[str, str] = {
        "auth_failed": (
            "Authentication failed. Please check your credentials and try again. "
            "If the problem persists, contact your administrator."
        ),
        "token_expired": ("Your session has expired. Please sign in again to continue."),
        "csrf_invalid": (
            "Security validation failed. This can happen if you used the browser's "
            "back button. Please try signing in again."
        ),
        "callback_error": (
            "An error occurred during sign-in. Please try again. "
            "If the problem persists, check the server logs for details."
        ),
        "session_expired": ("Your session has expired due to inactivity. Please sign in again."),
    }
    error_message = error_messages.get(error, "")

    return templates.TemplateResponse(
        request,
        "login.html",
        {
            "error": error_message,
        },
    )


@router.get("/callback")
async def dashboard_callback(request: Request) -> Response:
    """OAuth2 callback handler.

    Exchanges the authorization code for tokens, fetches user info,
    creates a session, and redirects to the dashboard.
    """
    from certmesh.api.oauth2_flow import (
        exchange_code_for_tokens,
        fetch_userinfo,
        generate_csrf_token,
        validate_oauth2_state,
    )

    code = request.query_params.get("code")
    state = request.query_params.get("state")
    error = request.query_params.get("error")

    if error:
        error_desc = request.query_params.get("error_description", "Unknown error")
        logger.warning(
            "OAuth2 callback received error",
            extra={"error": error, "description": error_desc},
        )
        return RedirectResponse(url="/dashboard/login?error=auth_failed", status_code=302)

    if not code or not state:
        logger.warning("OAuth2 callback missing code or state parameter")
        return RedirectResponse(url="/dashboard/login?error=callback_error", status_code=302)

    session_manager = _get_session_manager(request)
    oauth2_config = _get_oauth2_flow_config(request)

    # Validate state parameter against the pending login session
    pending_cookie = request.cookies.get("cm_pending_login")
    if not pending_cookie:
        logger.warning("OAuth2 callback: no pending login cookie found")
        return RedirectResponse(url="/dashboard/login?error=csrf_invalid", status_code=302)

    pending_session = session_manager.load_session(pending_cookie)
    if not pending_session:
        logger.warning("OAuth2 callback: pending login session expired or invalid")
        return RedirectResponse(url="/dashboard/login?error=csrf_invalid", status_code=302)

    expected_csrf = pending_session.get("csrf_token", "")
    if not validate_oauth2_state(session_manager, state, expected_csrf):
        return RedirectResponse(url="/dashboard/login?error=csrf_invalid", status_code=302)

    code_verifier = pending_session.get("code_verifier", "")
    if not code_verifier:
        logger.warning("OAuth2 callback: no code verifier in pending session")
        return RedirectResponse(url="/dashboard/login?error=callback_error", status_code=302)

    # Exchange code for tokens
    try:
        token_response = await exchange_code_for_tokens(oauth2_config, code, code_verifier)
    except Exception:
        logger.exception("OAuth2 token exchange failed")
        return RedirectResponse(url="/dashboard/login?error=auth_failed", status_code=302)

    access_token = token_response.get("access_token", "")
    if not access_token:
        logger.warning("OAuth2 token response missing access_token")
        return RedirectResponse(url="/dashboard/login?error=auth_failed", status_code=302)

    # Fetch user info
    try:
        userinfo = await fetch_userinfo(oauth2_config, access_token)
    except Exception:
        logger.exception("OAuth2 userinfo fetch failed")
        # Still create session with basic info from token
        userinfo = {"sub": "unknown", "name": "User", "email": ""}

    # SEC-19: Create a new session with rotated ID (session fixation protection)
    csrf_token = generate_csrf_token()
    session_data = {
        "user": {
            "sub": userinfo.get("sub", ""),
            "name": userinfo.get("name", userinfo.get("preferred_username", "User")),
            "email": userinfo.get("email", ""),
        },
        "access_token": access_token,
        "refresh_token": token_response.get("refresh_token", ""),
        "token_expires_at": time.time() + token_response.get("expires_in", 3600),
        "csrf_token": csrf_token,
    }
    session_token = session_manager.create_session(session_data)

    response = RedirectResponse(url="/dashboard", status_code=302)
    _set_session_cookie(response, session_token, session_manager.max_age)

    # Clear the pending login cookie
    response.delete_cookie("cm_pending_login", path="/dashboard")

    subject = userinfo.get("sub", "unknown")
    logger.info(
        "Dashboard login successful",
        extra={"subject": subject, "email": userinfo.get("email", "")},
    )

    return response


@router.get("/auth/start")
async def dashboard_auth_start(request: Request) -> Response:
    """Start the OAuth2 Authorization Code Flow with PKCE.

    Generates PKCE code verifier/challenge, CSRF state parameter,
    stores them in a temporary session cookie, and redirects to the
    identity provider.
    """
    from certmesh.api.oauth2_flow import (
        build_authorization_url,
        generate_code_challenge,
        generate_code_verifier,
        generate_csrf_token,
        generate_oauth2_state,
    )

    session_manager = _get_session_manager(request)
    oauth2_config = _get_oauth2_flow_config(request)

    if not oauth2_config.issuer_url or not oauth2_config.client_id:
        templates = _get_templates(request)
        return templates.TemplateResponse(
            request,
            "error.html",
            {
                "error_title": "SSO Not Configured",
                "error_message": (
                    "OAuth2 single sign-on is not configured for this dashboard. "
                    "Please set CM_OAUTH2_ISSUER_URL and CM_OAUTH2_CLIENT_ID "
                    "environment variables and restart the application."
                ),
                "error_code": 503,
            },
            status_code=503,
        )

    # Generate PKCE code verifier and challenge
    code_verifier = generate_code_verifier()
    code_challenge = generate_code_challenge(code_verifier)

    # Generate CSRF token and OAuth2 state
    csrf_token = generate_csrf_token()
    state = generate_oauth2_state(session_manager, csrf_token)

    # Store in a short-lived pending login session
    pending_data = {
        "code_verifier": code_verifier,
        "csrf_token": csrf_token,
    }
    pending_token = session_manager.create_session(pending_data)

    # Build authorization URL
    auth_url = build_authorization_url(oauth2_config, state, code_challenge)

    response = RedirectResponse(url=auth_url, status_code=302)
    response.set_cookie(
        key="cm_pending_login",
        value=pending_token,
        max_age=600,  # 10 minutes for the auth flow
        httponly=True,
        samesite="lax",
        secure=True,
        path="/dashboard",
    )

    return response


@router.post("/logout")
async def dashboard_logout(request: Request) -> Response:
    """Logout: clear the session cookie and redirect to login.

    Validates the CSRF token before proceeding.
    """
    session = _get_session(request)

    # Validate CSRF token from the form body when session is available.
    # If the session is already expired we still clear the cookies below
    # (there is nothing to protect), but an active session must prove the
    # logout was intentional.
    if session:
        form = await request.form()
        form_token = str(form.get("csrf_token", ""))
        _validate_csrf(request, session, form_token)

    response = RedirectResponse(url="/dashboard/login", status_code=302)
    response.delete_cookie("cm_session", path="/dashboard")
    response.delete_cookie("cm_pending_login", path="/dashboard")

    if session:
        subject = session.get("user", {}).get("sub", "unknown")
        logger.info("Dashboard logout", extra={"subject": subject})

    return response


# ── Certificate data API ─────────────────────────────────────────────────────


def _collect_provider_certs(
    provider_name: str,
    fetch_fn: Any,
    all_certs: list[dict[str, Any]],
    errors: list[dict[str, str]],
) -> None:
    """Fetch certificates from a provider, appending to *all_certs* / *errors*."""
    try:
        certs = fetch_fn()
        for cert in certs:
            cert_dict = dataclasses.asdict(cert) if dataclasses.is_dataclass(cert) else cert
            cert_dict["provider"] = provider_name
            all_certs.append(cert_dict)
    except Exception as exc:  # noqa: BLE001 - dashboard aggregation; provider errors must not crash page
        logger.warning("Failed to fetch %s certificates", provider_name, extra={"error": str(exc)})
        errors.append({"provider": provider_name, "error": str(exc)})


@router.get("/api/certificates")
async def api_certificates(request: Request) -> JSONResponse:
    """JSON API returning certificate data from all configured providers.

    Returns a consolidated list of certificates with provider, status,
    expiry date, and common name.  Used by the dashboard frontend for
    rendering the certificate table and summary cards.
    """
    _require_session(request)

    all_certs: list[dict[str, Any]] = []
    errors: list[dict[str, str]] = []

    config = request.app.state.config
    vault_cfg = config.get("vault", {})
    vault_cl = getattr(request.app.state, "vault_client", None)

    if config.get("digicert"):
        from certmesh.providers import digicert_client as dc

        _collect_provider_certs(
            "digicert",
            lambda: dc.list_issued_certificates(config["digicert"], vault_cfg, vault_cl),
            all_certs,
            errors,
        )

    if config.get("venafi"):
        from certmesh.providers import venafi_client as vc

        _collect_provider_certs(
            "venafi",
            lambda: vc.list_certificates(config["venafi"], vault_cfg, vault_cl),
            all_certs,
            errors,
        )

    if config.get("acm"):
        from certmesh.providers import acm_client

        _collect_provider_certs(
            "acm",
            lambda: acm_client.list_certificates(config["acm"]),
            all_certs,
            errors,
        )

    if config.get("vault_pki") and vault_cl:
        from certmesh.providers import vault_pki_client as vpki

        vault_pki_cfg = config.get("vault_pki", vault_cfg)
        _collect_provider_certs(
            "vault_pki",
            lambda: vpki.list_certificates(vault_pki_cfg, vault_cl),
            all_certs,
            errors,
        )

    if config.get("letsencrypt"):
        from certmesh.providers import letsencrypt_client as le

        _collect_provider_certs(
            "letsencrypt",
            lambda: le.list_certificates(config["letsencrypt"]),
            all_certs,
            errors,
        )

    # Store snapshot in dashboard state
    dashboard_state = _get_dashboard_state(request)
    dashboard_state.put(
        "latest_snapshot",
        {
            "certificates": all_certs,
            "errors": errors,
            "timestamp": time.time(),
        },
    )

    return JSONResponse(
        content={
            "certificates": all_certs,
            "errors": errors,
            "total": len(all_certs),
        }
    )


@router.post("/api/certificates/{provider}/{cert_id}/renew")
async def api_renew_certificate(
    request: Request,
    provider: Literal["digicert", "venafi", "acm"],
    cert_id: Annotated[str, Path(min_length=1, max_length=256)],
) -> JSONResponse:
    """Trigger certificate renewal for a specific certificate.

    Validates the CSRF token from the ``X-CSRF-Token`` header before
    proceeding.

    Args:
        provider: Certificate provider (``digicert``, ``venafi``, ``acm``).
        cert_id: Provider-specific certificate identifier.
    """
    session = _require_session(request)
    csrf_token = request.headers.get("X-CSRF-Token", "")
    _validate_csrf(request, session, csrf_token)

    if not _CERT_ID_RE.match(cert_id):
        raise HTTPException(status_code=400, detail="Invalid certificate ID format.")

    config = request.app.state.config
    result: dict[str, Any] = {"provider": provider, "certificate_id": cert_id, "action": "renew"}

    try:
        if provider == "venafi":
            from certmesh.providers import venafi_client as vc

            venafi_cfg = config.get("venafi", {})
            vault_cfg = config.get("vault", {})
            vault_cl = getattr(request.app.state, "vault_client", None)
            renewal = vc.renew_certificate(cert_id, venafi_cfg, vault_cfg, vault_cl)
            result["status"] = "success"
            result["detail"] = (
                dataclasses.asdict(renewal) if dataclasses.is_dataclass(renewal) else renewal
            )
        elif provider == "digicert":
            result["status"] = "error"
            result["detail"] = (
                "DigiCert certificates cannot be renewed directly. "
                "Please reorder the certificate through the DigiCert portal."
            )
            return JSONResponse(content=result, status_code=400)
        elif provider == "acm":
            result["status"] = "error"
            result["detail"] = (
                "ACM certificates are renewed automatically by AWS. No manual renewal is required."
            )
            return JSONResponse(content=result, status_code=400)
    except Exception:
        logger.exception(
            "Certificate renewal failed",
            extra={"provider": provider, "cert_id": cert_id},
        )
        result["status"] = "error"
        result["detail"] = "Certificate renewal failed. Check server logs for details."
        return JSONResponse(content=result, status_code=500)

    # Record in renewal history (atomic append avoids race across workers)
    dashboard_state = _get_dashboard_state(request)
    dashboard_state.append_to_list(
        "renewal_history",
        {
            "provider": provider,
            "certificate_id": cert_id,
            "action": "renew",
            "status": result["status"],
            "timestamp": time.time(),
            "user": session.get("user", {}).get("email", ""),
        },
        max_items=100,
    )

    return JSONResponse(content=result)


@router.post("/api/certificates/{provider}/{cert_id}/revoke")
async def api_revoke_certificate(
    request: Request,
    provider: Literal["digicert", "venafi", "acm", "vault_pki"],
    cert_id: Annotated[str, Path(min_length=1, max_length=256)],
) -> JSONResponse:
    """Trigger certificate revocation for a specific certificate.

    Validates the CSRF token from the ``X-CSRF-Token`` header before
    proceeding.

    Args:
        provider: Certificate provider (``digicert``, ``venafi``, ``acm``, ``vault_pki``).
        cert_id: Provider-specific certificate identifier.
    """
    session = _require_session(request)
    csrf_token = request.headers.get("X-CSRF-Token", "")
    _validate_csrf(request, session, csrf_token)

    if not _CERT_ID_RE.match(cert_id):
        raise HTTPException(status_code=400, detail="Invalid certificate ID format.")

    config = request.app.state.config
    result: dict[str, Any] = {"provider": provider, "certificate_id": cert_id, "action": "revoke"}

    try:
        if provider == "venafi":
            from certmesh.providers import venafi_client as vc

            venafi_cfg = config.get("venafi", {})
            vault_cfg = config.get("vault", {})
            vault_cl = getattr(request.app.state, "vault_client", None)
            revocation = vc.revoke_certificate(cert_id, venafi_cfg, vault_cfg, vault_cl)
            result["status"] = "success"
            result["detail"] = (
                dataclasses.asdict(revocation)
                if dataclasses.is_dataclass(revocation)
                else str(revocation)
            )
        elif provider == "digicert":
            from certmesh.providers import digicert_client as dc

            digicert_cfg = config.get("digicert", {})
            vault_cfg = config.get("vault", {})
            vault_cl = getattr(request.app.state, "vault_client", None)
            dc.revoke_certificate(cert_id, digicert_cfg, vault_cfg, vault_cl)
            result["status"] = "success"
            result["detail"] = "Certificate revocation request submitted."
        elif provider == "vault_pki":
            vault_cl = getattr(request.app.state, "vault_client", None)
            if not vault_cl:
                result["status"] = "error"
                result["detail"] = "Vault PKI client not available."
                return JSONResponse(content=result, status_code=503)
            from certmesh.backends import vault_client as vc

            vault_pki_cfg = config.get("vault_pki", config.get("vault", {})).get("pki", {})
            vc.revoke_pki_certificate(vault_cl, vault_pki_cfg, cert_id)
            result["status"] = "success"
            result["detail"] = "Certificate revocation request submitted."
        elif provider == "acm":
            result["status"] = "error"
            result["detail"] = (
                "ACM certificates cannot be revoked through this dashboard. "
                "Use the AWS Console or CLI to delete the certificate."
            )
            return JSONResponse(content=result, status_code=400)
    except Exception:
        logger.exception(
            "Certificate revocation failed",
            extra={"provider": provider, "cert_id": cert_id},
        )
        result["status"] = "error"
        result["detail"] = "Certificate revocation failed. Check server logs for details."
        return JSONResponse(content=result, status_code=500)

    # Record in renewal history (atomic append avoids race across workers)
    dashboard_state = _get_dashboard_state(request)
    dashboard_state.append_to_list(
        "renewal_history",
        {
            "provider": provider,
            "certificate_id": cert_id,
            "action": "revoke",
            "status": result["status"],
            "timestamp": time.time(),
            "user": session.get("user", {}).get("email", ""),
        },
        max_items=100,
    )

    return JSONResponse(content=result)


@router.get("/certificates/{provider}/{cert_id}", response_class=HTMLResponse)
async def certificate_detail_page(
    request: Request,
    provider: str,
    cert_id: Annotated[str, Path(min_length=1, max_length=256)],
) -> Response:
    """Certificate detail page showing full history, logs, and attributes."""
    session = _get_session(request)
    if not session or "user" not in session:
        return RedirectResponse(url="/dashboard/auth/start", status_code=302)

    if provider not in SUPPORTED_PROVIDERS:
        raise HTTPException(status_code=404, detail="Unknown provider.")

    if not _CERT_ID_RE.match(cert_id):
        raise HTTPException(status_code=400, detail="Invalid certificate ID format.")

    templates = _get_templates(request)
    return templates.TemplateResponse(
        request,
        "certificate_detail.html",
        {
            "user": session.get("user", {}),
            "csrf_token": session.get("csrf_token", ""),
            "provider": provider,
            "cert_id": cert_id,
        },
    )


@router.get("/api/certificates/{provider}/{cert_id}")
async def api_certificate_detail(
    request: Request,
    provider: str,
    cert_id: Annotated[str, Path(min_length=1, max_length=256)],
) -> JSONResponse:
    """Return detailed certificate information from the provider.

    Supports all configured providers: DigiCert, Venafi, ACM, Vault PKI.
    """
    _require_session(request)

    if provider not in SUPPORTED_PROVIDERS:
        raise HTTPException(status_code=404, detail="Unknown provider.")

    if not _CERT_ID_RE.match(cert_id):
        raise HTTPException(status_code=400, detail="Invalid certificate ID format.")

    config = request.app.state.config
    result: dict[str, Any] = {}

    try:
        if provider == "digicert":
            from certmesh.providers import digicert_client as dc

            digicert_cfg = config.get("digicert", {})
            vault_cfg = config.get("vault", {})
            vault_cl = getattr(request.app.state, "vault_client", None)
            detail = dc.describe_certificate(cert_id, digicert_cfg, vault_cfg, vault_cl)
            result = (
                dataclasses.asdict(detail) if dataclasses.is_dataclass(detail) else dict(detail)
            )
        elif provider == "venafi":
            from certmesh.providers import venafi_client as vc

            venafi_cfg = config.get("venafi", {})
            vault_cfg = config.get("vault", {})
            vault_cl = getattr(request.app.state, "vault_client", None)
            detail = vc.describe_certificate(cert_id, venafi_cfg, vault_cfg, vault_cl)
            result = (
                dataclasses.asdict(detail) if dataclasses.is_dataclass(detail) else dict(detail)
            )
        elif provider == "acm":
            from certmesh.providers import acm_client

            acm_cfg = config.get("acm", {})
            detail = acm_client.describe_certificate(cert_id, acm_cfg)
            result = (
                dataclasses.asdict(detail) if dataclasses.is_dataclass(detail) else dict(detail)
            )
        elif provider == "vault_pki":
            vault_cl = getattr(request.app.state, "vault_client", None)
            if vault_cl:
                from certmesh.providers import vault_pki_client as vpki

                vault_pki_cfg = config.get("vault_pki", config.get("vault", {}))
                detail = vpki.describe_certificate(cert_id, vault_pki_cfg, vault_cl)
                result = (
                    dataclasses.asdict(detail)
                    if dataclasses.is_dataclass(detail)
                    else dict(detail)
                )
            else:
                return JSONResponse(
                    content={"error": "Vault PKI client not available"},
                    status_code=503,
                )
        else:
            return JSONResponse(
                content={"error": f"Unknown provider: {provider}"},
                status_code=400,
            )
    except Exception:
        logger.exception(
            "Certificate detail fetch failed",
            extra={"provider": provider, "cert_id": cert_id},
        )
        return JSONResponse(
            content={"error": "Failed to fetch certificate details. Check server logs."},
            status_code=500,
        )

    result["provider"] = provider
    return JSONResponse(content=result)


@router.get("/api/certificates/history")
async def api_certificate_history(
    request: Request,
    provider: str = "",
    cert_id: str = "",
) -> JSONResponse:
    """Return renewal/revocation history for a specific certificate.

    Filters the global renewal_history list by provider and cert_id.
    """
    _require_session(request)

    dashboard_state = _get_dashboard_state(request)
    all_history = dashboard_state.get("renewal_history", [])

    filtered = [
        entry
        for entry in all_history
        if (not provider or entry.get("provider") == provider)
        and (not cert_id or entry.get("certificate_id") == cert_id)
    ]

    # Sort by timestamp descending (newest first)
    filtered.sort(key=lambda x: x.get("timestamp", 0), reverse=True)

    return JSONResponse(content={"history": filtered, "total": len(filtered)})


@router.get("/api/timeline")
async def api_timeline(request: Request) -> JSONResponse:
    """Return certificate expiry timeline data.

    Returns certificates grouped by time-to-expiry buckets for
    visualisation as a timeline or progress bar chart.
    """
    _require_session(request)

    dashboard_state = _get_dashboard_state(request)
    snapshot = dashboard_state.get("latest_snapshot", {})
    certs = snapshot.get("certificates", [])

    now = time.time()
    buckets: dict[str, list[dict[str, Any]]] = {
        "expired": [],
        "critical": [],  # < 7 days
        "warning": [],  # 7-30 days
        "attention": [],  # 30-60 days
        "healthy": [],  # > 60 days
        "unknown": [],
    }

    for cert in certs:
        # Try multiple date field names across providers
        expiry_str = (
            cert.get("not_after")
            or cert.get("valid_till")
            or cert.get("valid_to")
            or cert.get("approx_not_after")
            or cert.get("expiration")
            or ""
        )
        if not expiry_str:
            buckets["unknown"].append(cert)
            continue

        try:
            # Try ISO format first, then common variations
            for fmt in (
                "%Y-%m-%dT%H:%M:%SZ",
                "%Y-%m-%dT%H:%M:%S",
                "%Y-%m-%d",
                "%Y-%m-%d %H:%M:%S",
            ):
                try:
                    expiry_dt = datetime.strptime(expiry_str, fmt).replace(tzinfo=timezone.utc)
                    break
                except ValueError:
                    continue
            else:
                buckets["unknown"].append(cert)
                continue

            days_remaining = (expiry_dt.timestamp() - now) / 86400

            if days_remaining < 0:
                buckets["expired"].append(cert)
            elif days_remaining < 7:
                buckets["critical"].append(cert)
            elif days_remaining < 30:
                buckets["warning"].append(cert)
            elif days_remaining < 60:
                buckets["attention"].append(cert)
            else:
                buckets["healthy"].append(cert)
        except Exception:  # noqa: BLE001 - timeline bucketing; malformed dates → unknown bucket
            buckets["unknown"].append(cert)

    summary = {k: len(v) for k, v in buckets.items()}

    return JSONResponse(
        content={
            "buckets": {k: v for k, v in buckets.items()},
            "summary": summary,
            "total": len(certs),
        }
    )


# ── Live log streaming API ───────────────────────────────────────────────────


def _get_log_buffer(request: Request) -> Any:
    """Return the LogBuffer from app state, or None."""
    return getattr(request.app.state, "log_buffer", None)


@router.get("/api/logs/stream")
async def api_logs_stream(request: Request) -> StreamingResponse:
    """Server-Sent Events endpoint for live log streaming.

    Streams log entries in real time as SSE ``data:`` frames.
    Sends recent history on connect, then new entries as they arrive.
    Requires an authenticated dashboard session.
    """
    _require_session(request)

    log_buffer = _get_log_buffer(request)
    if log_buffer is None:
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail="Log streaming is not available.",
        )

    async def event_generator() -> Any:
        try:
            async for entry in log_buffer.subscribe():
                # Check if client disconnected.
                if await request.is_disconnected():
                    break
                data = json.dumps(entry.to_dict(), default=str)
                yield f"data: {data}\n\n"
        except (asyncio.CancelledError, GeneratorExit):
            pass

    return StreamingResponse(
        event_generator(),
        media_type="text/event-stream",
        headers={
            "Cache-Control": "no-cache",
            "Connection": "keep-alive",
            "X-Accel-Buffering": "no",
        },
    )
