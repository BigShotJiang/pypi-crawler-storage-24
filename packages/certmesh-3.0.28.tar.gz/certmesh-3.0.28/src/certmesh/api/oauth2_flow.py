"""
certmesh.api.oauth2_flow
==========================

OAuth2 Authorization Code Flow with PKCE for browser-based dashboard login.

Configurable via environment variables:

- ``CM_OAUTH2_ISSUER_URL``       -- OIDC issuer URL (e.g. ``https://login.microsoftonline.com/{tenant}/v2.0``)
- ``CM_OAUTH2_CLIENT_ID``        -- OAuth2 client (application) ID
- ``CM_DASHBOARD_REDIRECT_URI``  -- Callback URL (e.g. ``https://certmesh.example.com/dashboard/callback``)
- ``CM_DASHBOARD_SESSION_SECRET``-- Secret key for signing session cookies (min 32 chars)

Implements:
- PKCE (RFC 7636) code verifier / challenge
- Secure session management with encrypted HttpOnly cookies
- CSRF state parameter validation
- Token refresh handling

SEC-17: Session cookies are HttpOnly + Secure + SameSite=Lax.
SEC-18: CSRF state parameter prevents login CSRF attacks.
SEC-19: Session ID is rotated on successful login (session fixation protection).
"""

from __future__ import annotations

import base64
import hashlib
import logging
import os
import secrets
import time
from dataclasses import dataclass
from typing import Any

import httpx
from itsdangerous import BadSignature, TimestampSigner, URLSafeTimedSerializer

logger = logging.getLogger(__name__)

# ── Configuration ─────────────────────────────────────────────────────────────

_SESSION_COOKIE_NAME = "cm_session"
_SESSION_MAX_AGE = 3600  # 1 hour
_CSRF_STATE_TTL = 600  # 10 minutes for OAuth2 state parameter


@dataclass
class OAuth2FlowConfig:
    """OAuth2 Authorization Code Flow configuration for dashboard SSO."""

    issuer_url: str = ""
    client_id: str = ""
    redirect_uri: str = ""
    session_secret: str = ""
    scopes: str = "openid profile email"

    @property
    def authorize_url(self) -> str:
        """Derive the authorization endpoint from the OIDC issuer."""
        issuer = self.issuer_url.rstrip("/")
        return f"{issuer}/authorize"

    @property
    def token_url(self) -> str:
        """Derive the token endpoint from the OIDC issuer."""
        issuer = self.issuer_url.rstrip("/")
        return f"{issuer}/token"

    @property
    def userinfo_url(self) -> str:
        """Derive the userinfo endpoint from the OIDC issuer."""
        issuer = self.issuer_url.rstrip("/")
        return f"{issuer}/userinfo"

    @property
    def end_session_url(self) -> str:
        """Derive the end-session (logout) endpoint from the OIDC issuer."""
        issuer = self.issuer_url.rstrip("/")
        return f"{issuer}/logout"


def build_oauth2_flow_config() -> OAuth2FlowConfig:
    """Build OAuth2 flow config from environment variables."""
    return OAuth2FlowConfig(
        issuer_url=os.environ.get("CM_OAUTH2_ISSUER_URL", ""),
        client_id=os.environ.get("CM_OAUTH2_CLIENT_ID", ""),
        redirect_uri=os.environ.get(
            "CM_DASHBOARD_REDIRECT_URI", "http://localhost:8000/dashboard/callback"
        ),
        session_secret=os.environ.get("CM_DASHBOARD_SESSION_SECRET", ""),
        scopes=os.environ.get("CM_DASHBOARD_SCOPES", "openid profile email"),
    )


# ── PKCE helpers ──────────────────────────────────────────────────────────────


def generate_code_verifier() -> str:
    """Generate a cryptographically random PKCE code verifier (RFC 7636).

    Returns:
        A URL-safe 43-character string suitable as a PKCE code verifier.
    """
    return secrets.token_urlsafe(32)


def generate_code_challenge(verifier: str) -> str:
    """Derive the PKCE code challenge from a code verifier using S256.

    Args:
        verifier: The code verifier string.

    Returns:
        Base64url-encoded SHA-256 hash of the verifier.
    """
    digest = hashlib.sha256(verifier.encode("ascii")).digest()
    return base64.urlsafe_b64encode(digest).rstrip(b"=").decode("ascii")


# ── Session management ────────────────────────────────────────────────────────


class SessionManager:
    """Secure session management using signed, encrypted HttpOnly cookies.

    Uses ``itsdangerous.URLSafeTimedSerializer`` to sign and timestamp
    session data.  The session secret must be at least 32 characters.

    SEC-17: Cookies are HttpOnly + Secure + SameSite=Lax.
    SEC-19: Session ID is rotated on login to prevent session fixation.
    """

    def __init__(self, secret: str, max_age: int = _SESSION_MAX_AGE) -> None:
        if not secret or len(secret) < 32:
            logger.warning(
                "CM_DASHBOARD_SESSION_SECRET is missing or too short (min 32 chars). "
                "Dashboard sessions will not work correctly. "
                "Set CM_DASHBOARD_SESSION_SECRET to a random string of at least 32 characters."
            )
            # Use a random fallback so the app doesn't crash, but sessions
            # won't survive restarts.
            secret = secrets.token_hex(32)
        self._serializer = URLSafeTimedSerializer(secret)
        self._signer = TimestampSigner(secret)
        self._max_age = max_age

    def create_session(self, data: dict[str, Any]) -> str:
        """Create a signed session token containing *data*.

        Args:
            data: Session payload (user info, tokens, CSRF token, etc.).

        Returns:
            A URL-safe signed string suitable for use as a cookie value.
        """
        data["_sid"] = secrets.token_hex(16)
        data["_created"] = time.time()
        return self._serializer.dumps(data)

    def load_session(self, token: str) -> dict[str, Any] | None:
        """Load and verify a session from a signed token.

        Args:
            token: The signed session cookie value.

        Returns:
            The session data dict, or ``None`` if the token is invalid
            or expired.
        """
        try:
            data: dict[str, Any] = self._serializer.loads(token, max_age=self._max_age)
            return data
        except BadSignature:
            logger.debug("Session token signature invalid or expired")
            return None
        except Exception:  # noqa: BLE001 - session decode; any failure → invalid session
            logger.debug("Session token decode failed")
            return None

    def rotate_session(self, data: dict[str, Any]) -> str:
        """Rotate the session ID (session fixation protection).

        Creates a new session with a fresh ``_sid`` while preserving
        the existing payload.

        Args:
            data: Current session data.

        Returns:
            A new signed session token with a rotated session ID.
        """
        data["_sid"] = secrets.token_hex(16)
        data["_created"] = time.time()
        return self._serializer.dumps(data)

    @property
    def max_age(self) -> int:
        """Maximum session age in seconds."""
        return self._max_age


# ── CSRF protection ──────────────────────────────────────────────────────────


def generate_csrf_token() -> str:
    """Generate a cryptographically random CSRF token.

    Returns:
        A 64-character hex string.
    """
    return secrets.token_hex(32)


def generate_oauth2_state(session_manager: SessionManager, csrf_token: str) -> str:
    """Generate an OAuth2 state parameter that binds to the CSRF token.

    The state parameter is a signed token containing the CSRF token and a
    timestamp, preventing login CSRF attacks (SEC-18).

    Args:
        session_manager: The session manager for signing.
        csrf_token: The CSRF token to bind.

    Returns:
        A signed state parameter string.
    """
    state_data = {"csrf": csrf_token, "ts": time.time()}
    return session_manager._serializer.dumps(state_data)


def validate_oauth2_state(session_manager: SessionManager, state: str, expected_csrf: str) -> bool:
    """Validate an OAuth2 state parameter against the expected CSRF token.

    Args:
        session_manager: The session manager for verification.
        state: The state parameter from the OAuth2 callback.
        expected_csrf: The CSRF token stored in the session.

    Returns:
        ``True`` if the state is valid and matches the expected CSRF token.
    """
    try:
        data: dict[str, Any] = session_manager._serializer.loads(state, max_age=_CSRF_STATE_TTL)
        return data.get("csrf") == expected_csrf
    except BadSignature:
        logger.warning("OAuth2 state parameter validation failed: bad signature or expired")
        return False
    except Exception:  # noqa: BLE001 - state validation; any failure → reject
        logger.warning("OAuth2 state parameter validation failed")
        return False


# ── Token exchange ────────────────────────────────────────────────────────────


async def exchange_code_for_tokens(
    config: OAuth2FlowConfig,
    code: str,
    code_verifier: str,
) -> dict[str, Any]:
    """Exchange an authorization code for tokens using the token endpoint.

    Uses PKCE (code_verifier) for proof of possession.

    Args:
        config: OAuth2 flow configuration.
        code: The authorization code from the callback.
        code_verifier: The PKCE code verifier used during the authorization request.

    Returns:
        Token response dict containing ``access_token``, ``id_token``,
        ``refresh_token`` (if available), and ``expires_in``.

    Raises:
        httpx.HTTPStatusError: If the token endpoint returns an error.
    """
    async with httpx.AsyncClient(timeout=15.0) as client:
        resp = await client.post(
            config.token_url,
            data={
                "grant_type": "authorization_code",
                "client_id": config.client_id,
                "code": code,
                "redirect_uri": config.redirect_uri,
                "code_verifier": code_verifier,
            },
            headers={"Content-Type": "application/x-www-form-urlencoded"},
        )
        resp.raise_for_status()
        return resp.json()


async def refresh_access_token(
    config: OAuth2FlowConfig,
    refresh_token: str,
) -> dict[str, Any]:
    """Refresh an access token using a refresh token.

    Args:
        config: OAuth2 flow configuration.
        refresh_token: The refresh token from the original token response.

    Returns:
        Token response dict with a new ``access_token`` and optionally a
        new ``refresh_token``.

    Raises:
        httpx.HTTPStatusError: If the token endpoint returns an error.
    """
    async with httpx.AsyncClient(timeout=15.0) as client:
        resp = await client.post(
            config.token_url,
            data={
                "grant_type": "refresh_token",
                "client_id": config.client_id,
                "refresh_token": refresh_token,
            },
            headers={"Content-Type": "application/x-www-form-urlencoded"},
        )
        resp.raise_for_status()
        return resp.json()


async def fetch_userinfo(config: OAuth2FlowConfig, access_token: str) -> dict[str, Any]:
    """Fetch user profile information from the OIDC userinfo endpoint.

    Args:
        config: OAuth2 flow configuration.
        access_token: A valid access token.

    Returns:
        Userinfo dict containing claims like ``sub``, ``name``, ``email``.

    Raises:
        httpx.HTTPStatusError: If the userinfo endpoint returns an error.
    """
    async with httpx.AsyncClient(timeout=10.0) as client:
        resp = await client.get(
            config.userinfo_url,
            headers={"Authorization": f"Bearer {access_token}"},
        )
        resp.raise_for_status()
        return resp.json()


def build_authorization_url(
    config: OAuth2FlowConfig,
    state: str,
    code_challenge: str,
) -> str:
    """Build the full OAuth2 authorization URL with PKCE parameters.

    Args:
        config: OAuth2 flow configuration.
        state: The CSRF state parameter.
        code_challenge: The PKCE code challenge (S256).

    Returns:
        The full authorization URL to redirect the user to.
    """
    from urllib.parse import urlencode

    params = {
        "response_type": "code",
        "client_id": config.client_id,
        "redirect_uri": config.redirect_uri,
        "scope": config.scopes,
        "state": state,
        "code_challenge": code_challenge,
        "code_challenge_method": "S256",
    }
    return f"{config.authorize_url}?{urlencode(params)}"
