"""
certmesh.renewal
================

Automatic certificate renewal engine. Checks certificates across providers
for approaching expiry and renews them based on a configurable policy.
"""

from __future__ import annotations

import logging
import os
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Any

from certmesh.exceptions import ACMError, CertMeshError, DigiCertError, VaultError, VenafiError

logger = logging.getLogger(__name__)

# Time unit conversion factors (to seconds)
_UNIT_SECONDS = {
    "hour": 3600,
    "day": 86400,
    "week": 604800,  # 7 days
    "month": 2592000,  # 30 days
    "year": 31536000,  # 365 days
}


@dataclass
class RenewalPolicy:
    """Policy controlling when certificates should be renewed."""

    before_expiry: int = 30
    unit: str = "day"
    providers: list[str] = field(default_factory=lambda: ["all"])
    dry_run: bool = False


@dataclass
class RenewalResult:
    """Result of a renewal check/action for a single certificate."""

    provider: str
    identifier: str  # ARN, GUID, serial, CN, etc.
    common_name: str
    not_after: datetime | None
    needs_renewal: bool
    renewed: bool = False
    error: str | None = None


def _convert_to_seconds(value: int, unit: str) -> float:
    """Convert a value + unit to seconds."""
    if unit not in _UNIT_SECONDS:
        raise ValueError(f"Invalid unit '{unit}'. Must be one of: {sorted(_UNIT_SECONDS)}")
    return value * _UNIT_SECONDS[unit]


def should_renew(not_after: datetime | None, policy: RenewalPolicy) -> bool:
    """Check if a certificate should be renewed based on the policy."""
    if not_after is None:
        return False
    threshold_seconds = _convert_to_seconds(policy.before_expiry, policy.unit)
    now = datetime.now(timezone.utc)
    if not_after.tzinfo is None:
        not_after = not_after.replace(tzinfo=timezone.utc)
    remaining = (not_after - now).total_seconds()
    return remaining <= threshold_seconds


def check_and_renew(
    cfg: dict[str, Any],
    policy: RenewalPolicy,
) -> list[RenewalResult]:
    """Scan configured providers for certificates approaching expiry.

    Returns a list of RenewalResult objects describing what was checked
    and what actions were taken (or would be taken in dry-run mode).
    """
    results: list[RenewalResult] = []
    active_providers = policy.providers

    if "all" in active_providers:
        active_providers = ["vault-pki", "acm", "digicert", "venafi", "letsencrypt"]

    for provider in active_providers:
        try:
            provider_results = _check_provider(cfg, provider, policy)
            results.extend(provider_results)
        except (CertMeshError, ConnectionError, OSError) as exc:
            logger.error(
                "Error checking provider", extra={"provider": provider, "error": str(exc)}
            )
            results.append(
                RenewalResult(
                    provider=provider,
                    identifier="*",
                    common_name="*",
                    not_after=None,
                    needs_renewal=False,
                    error=str(exc),
                )
            )

    # Summary logging
    total = len(results)
    needs_renewal = sum(1 for r in results if r.needs_renewal)
    renewed = sum(1 for r in results if r.renewed)
    errors = sum(1 for r in results if r.error)

    logger.info(
        "Renewal check complete",
        extra={
            "total_checked": total,
            "needs_renewal": needs_renewal,
            "renewed": renewed,
            "errors": errors,
        },
    )

    pushgateway_url = cfg.get("pushgateway_url") or os.environ.get("CERTMESH_PUSHGATEWAY_URL", "")
    if pushgateway_url:
        from certmesh.renewal_metrics import push_renewal_metrics

        push_renewal_metrics(results, pushgateway_url)

    return results


def _check_provider(
    cfg: dict[str, Any],
    provider: str,
    policy: RenewalPolicy,
) -> list[RenewalResult]:
    """Check a single provider for certificates needing renewal.

    Dispatches to provider-specific list/describe functions to enumerate
    certificates, then checks each against the renewal policy.

    Raises:
        NotImplementedError: If the provider does not yet support
            automated certificate enumeration.
    """
    logger.info(
        "Checking provider for certificates approaching expiry", extra={"provider": provider}
    )

    provider_cfg = cfg.get(provider.replace("-", "_"), {})
    if not provider_cfg:
        logger.debug("Provider not configured, skipping", extra={"provider": provider})
        return []

    results: list[RenewalResult] = []

    if provider == "acm":
        results = _check_acm(cfg, policy)
    elif provider == "digicert":
        results = _check_digicert(cfg, policy)
    elif provider == "venafi":
        results = _check_venafi(cfg, policy)
    elif provider == "vault-pki":
        results = _check_vault_pki(cfg, policy)
    else:
        logger.warning(
            "Provider does not support automated renewal enumeration",
            extra={"provider": provider},
        )

    logger.info(
        "Provider certificate check complete",
        extra={
            "provider": provider,
            "certificate_count": len(results),
            "needs_renewal": sum(1 for r in results if r.needs_renewal),
        },
    )
    return results


def _check_acm(
    cfg: dict[str, Any],
    policy: RenewalPolicy,
) -> list[RenewalResult]:
    """Check ACM certificates for upcoming expiry."""
    from certmesh.providers import acm_client

    acm_cfg = cfg.get("acm", {})
    results: list[RenewalResult] = []

    try:
        summaries = acm_client.list_certificates(acm_cfg, statuses=["ISSUED"])
    except (ACMError, ConnectionError, OSError) as exc:
        logger.error("Failed to list ACM certificates", extra={"error": str(exc)})
        return [
            RenewalResult(
                provider="acm",
                identifier="*",
                common_name="*",
                not_after=None,
                needs_renewal=False,
                error=str(exc),
            )
        ]

    for cert in summaries:
        needs = should_renew(cert.not_after, policy)
        result = RenewalResult(
            provider="acm",
            identifier=cert.certificate_arn,
            common_name=cert.domain_name,
            not_after=cert.not_after,
            needs_renewal=needs,
        )

        if needs and not policy.dry_run:
            try:
                acm_client.renew_certificate(acm_cfg, cert.certificate_arn)
                result.renewed = True
                logger.info(
                    "ACM certificate renewed",
                    extra={"arn": cert.certificate_arn, "domain": cert.domain_name},
                )
            except (ACMError, ConnectionError, OSError) as exc:
                result.error = str(exc)
                logger.error(
                    "ACM certificate renewal failed",
                    extra={"arn": cert.certificate_arn, "error": str(exc)},
                )

        results.append(result)

    return results


# ---------------------------------------------------------------------------
# ISO 8601 datetime parsing helper
# ---------------------------------------------------------------------------


def _parse_iso_datetime(date_str: str) -> datetime | None:
    """Parse an ISO 8601 datetime string to a tz-aware ``datetime``.

    Returns ``None`` if ``date_str`` is empty or unparseable.
    Handles both ``Z`` suffix and ``+00:00`` offset variants.
    """
    if not date_str:
        return None
    # Normalise Z → +00:00 for fromisoformat (Python < 3.11 does not accept Z).
    normalised = date_str.replace("Z", "+00:00")
    try:
        dt = datetime.fromisoformat(normalised)
    except ValueError:
        return None
    if dt.tzinfo is None:
        dt = dt.replace(tzinfo=timezone.utc)
    return dt


# ---------------------------------------------------------------------------
# DigiCert renewal
# ---------------------------------------------------------------------------


def _check_digicert(
    cfg: dict[str, Any],
    policy: RenewalPolicy,
) -> list[RenewalResult]:
    """Check DigiCert certificates for upcoming expiry and renew if required.

    Uses ``list_issued_certificates`` to enumerate all issued certificates, then
    calls ``duplicate_certificate`` with a freshly generated CSR for those that
    fall within the renewal window.
    """
    from certmesh.certificate_utils import (
        SubjectInfo,
        build_csr,
        csr_to_pem,
        generate_rsa_private_key,
    )
    from certmesh.providers import digicert_client

    digicert_cfg = cfg.get("digicert", {})
    vault_cfg = cfg.get("vault", {})
    results: list[RenewalResult] = []

    try:
        summaries = digicert_client.list_issued_certificates(
            digicert_cfg, vault_cfg, None, status="issued"
        )
    except (DigiCertError, ConnectionError, OSError) as exc:
        logger.error("Failed to list DigiCert certificates", extra={"error": str(exc)})
        return [
            RenewalResult(
                provider="digicert",
                identifier="*",
                common_name="*",
                not_after=None,
                needs_renewal=False,
                error=str(exc),
            )
        ]

    for cert in summaries:
        try:
            not_after: datetime | None = digicert_client._parse_digicert_date(cert.valid_till)
        except (ValueError, AttributeError):
            not_after = None

        needs = should_renew(not_after, policy)
        result = RenewalResult(
            provider="digicert",
            identifier=str(cert.certificate_id),
            common_name=cert.common_name,
            not_after=not_after,
            needs_renewal=needs,
        )

        if needs and not policy.dry_run:
            try:
                key_size: int = digicert_cfg.get("certificate", {}).get("key_size", 4096)
                key = generate_rsa_private_key(key_size)
                subject = SubjectInfo(common_name=cert.common_name)
                csr_pem = csr_to_pem(build_csr(key, subject))
                digicert_client.duplicate_certificate(
                    digicert_cfg,
                    vault_cfg,
                    None,
                    order_id=cert.order_id,
                    csr_pem=csr_pem,
                )
                result.renewed = True
                logger.info(
                    "DigiCert certificate renewed via duplicate",
                    extra={
                        "certificate_id": cert.certificate_id,
                        "order_id": cert.order_id,
                        "common_name": cert.common_name,
                    },
                )
            except (DigiCertError, ConnectionError, OSError, ValueError) as exc:
                result.error = str(exc)
                logger.error(
                    "DigiCert certificate renewal failed",
                    extra={"certificate_id": cert.certificate_id, "error": str(exc)},
                )

        results.append(result)

    return results


# ---------------------------------------------------------------------------
# Venafi renewal
# ---------------------------------------------------------------------------


def _check_venafi(
    cfg: dict[str, Any],
    policy: RenewalPolicy,
) -> list[RenewalResult]:
    """Check Venafi TPP certificates for upcoming expiry and renew if required.

    Authenticates once, enumerates all certificates via ``list_certificates``,
    and calls ``renew_and_download_certificate`` for those within the renewal window.
    The authenticated session is always closed on exit.
    """
    from certmesh.providers import venafi_client

    venafi_cfg = cfg.get("venafi", {})
    vault_cfg = cfg.get("vault", {})
    results: list[RenewalResult] = []

    try:
        session = venafi_client.authenticate(venafi_cfg, vault_cfg, None)
    except (VenafiError, ConnectionError, OSError) as exc:
        logger.error("Failed to authenticate with Venafi", extra={"error": str(exc)})
        return [
            RenewalResult(
                provider="venafi",
                identifier="*",
                common_name="*",
                not_after=None,
                needs_renewal=False,
                error=str(exc),
            )
        ]

    try:
        summaries = venafi_client.list_certificates(session, venafi_cfg)
    except (VenafiError, ConnectionError, OSError) as exc:
        session.close()
        logger.error("Failed to list Venafi certificates", extra={"error": str(exc)})
        return [
            RenewalResult(
                provider="venafi",
                identifier="*",
                common_name="*",
                not_after=None,
                needs_renewal=False,
                error=str(exc),
            )
        ]

    try:
        for cert in summaries:
            not_after = _parse_iso_datetime(cert.approx_not_after)
            needs = should_renew(not_after, policy)
            result = RenewalResult(
                provider="venafi",
                identifier=cert.guid,
                common_name=cert.dn,
                not_after=not_after,
                needs_renewal=needs,
            )

            if needs and not policy.dry_run:
                try:
                    venafi_client.renew_and_download_certificate(
                        session,
                        venafi_cfg,
                        vault_cfg,
                        None,
                        certificate_guid=cert.guid,
                    )
                    result.renewed = True
                    logger.info(
                        "Venafi certificate renewed",
                        extra={"guid": cert.guid, "dn": cert.dn},
                    )
                except (VenafiError, ConnectionError, OSError) as exc:
                    result.error = str(exc)
                    logger.error(
                        "Venafi certificate renewal failed",
                        extra={"guid": cert.guid, "error": str(exc)},
                    )

            results.append(result)
    finally:
        session.close()

    return results


# ---------------------------------------------------------------------------
# Vault PKI renewal
# ---------------------------------------------------------------------------


def _check_vault_pki(
    cfg: dict[str, Any],
    policy: RenewalPolicy,
) -> list[RenewalResult]:
    """Check Vault PKI certificates for upcoming expiry and re-issue if required.

    Enumerates serial numbers via ``list_pki_certificates``, reads each certificate
    to determine expiry and CN, then calls ``issue_certificate`` for those within
    the renewal window.
    """
    from cryptography import x509 as crypto_x509
    from cryptography.x509.oid import NameOID

    from certmesh.backends import vault_client as vc

    vault_cfg = cfg.get("vault", {})
    pki_cfg = vault_cfg.get("pki", {})
    results: list[RenewalResult] = []

    try:
        client = vc.get_authenticated_client(vault_cfg)
    except (VaultError, ConnectionError, OSError) as exc:
        logger.error("Failed to authenticate with Vault", extra={"error": str(exc)})
        return [
            RenewalResult(
                provider="vault-pki",
                identifier="*",
                common_name="*",
                not_after=None,
                needs_renewal=False,
                error=str(exc),
            )
        ]

    try:
        serials = vc.list_pki_certificates(client, pki_cfg)
    except (VaultError, ConnectionError, OSError) as exc:
        logger.error("Failed to list Vault PKI certificates", extra={"error": str(exc)})
        return [
            RenewalResult(
                provider="vault-pki",
                identifier="*",
                common_name="*",
                not_after=None,
                needs_renewal=False,
                error=str(exc),
            )
        ]

    for serial in serials:
        not_after: datetime | None = None
        common_name: str = serial

        try:
            cert_data = vc.read_pki_certificate(client, pki_cfg, serial)
            if cert_data.get("revocation_time", 0):
                logger.debug("Skipping revoked Vault PKI certificate", extra={"serial": serial})
                continue
            cert_pem: str = cert_data.get("certificate", "")
            if cert_pem:
                parsed = crypto_x509.load_pem_x509_certificate(cert_pem.encode())
                not_after = parsed.not_valid_after_utc
                cn_attrs = parsed.subject.get_attributes_for_oid(NameOID.COMMON_NAME)
                if cn_attrs:
                    common_name = cn_attrs[0].value
        except (VaultError, ConnectionError, OSError, ValueError) as exc:
            logger.warning(
                "Could not read Vault PKI certificate",
                extra={"serial": serial, "error": str(exc)},
            )

        needs = should_renew(not_after, policy)
        result = RenewalResult(
            provider="vault-pki",
            identifier=serial,
            common_name=common_name,
            not_after=not_after,
            needs_renewal=needs,
        )

        if needs and not policy.dry_run:
            try:
                vc.issue_pki_certificate(client, pki_cfg, common_name)
                result.renewed = True
                logger.info(
                    "Vault PKI certificate re-issued",
                    extra={"serial": serial, "common_name": common_name},
                )
            except (VaultError, ConnectionError, OSError) as exc:
                result.error = str(exc)
                logger.error(
                    "Vault PKI certificate renewal failed",
                    extra={"serial": serial, "error": str(exc)},
                )

        results.append(result)

    return results
