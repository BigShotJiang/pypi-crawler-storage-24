"""
certmesh.k8s_portforward
==========================

Manages a ``kubectl port-forward`` subprocess for connecting the CLI to
a remote certmesh API running on Kubernetes.

URL schemes
-----------
* ``k8s://namespace/service:port`` — plaintext port-forward
  (resolves to ``http://127.0.0.1:{local_port}``)
* ``k8s+tls://namespace/service:port`` — TLS port-forward
  (resolves to ``https://127.0.0.1:{local_port}``)

The subprocess is managed with automatic reconnection if the tunnel
drops, and clean shutdown on Ctrl+C (SIGINT).

Kubernetes compatibility
------------------------
Uses only ``kubectl port-forward`` which is stable since Kubernetes 1.0
and works on all versions including the latest (1.32+).
"""

from __future__ import annotations

import atexit
import logging
import re
import shutil
import signal
import socket
import subprocess
import threading
import time
from typing import Any

from certmesh.exceptions import ConfigurationError, RemoteConnectionError

logger = logging.getLogger(__name__)

_FORWARD_RE = re.compile(r"Forwarding from 127\.0\.0\.1:(\d+)")

# RFC 1123 label: lowercase alphanumeric and hyphens, must start/end with alnum.
# Kubernetes namespace and service names follow this pattern (max 63 chars).
_K8S_NAME_RE = re.compile(r"^[a-z0-9]([a-z0-9\-]{0,61}[a-z0-9])?$")


def _validate_k8s_name(value: str, kind: str) -> None:
    """Validate that *value* is a legal Kubernetes resource name.

    Raises ``ConfigurationError`` if it contains characters outside the
    RFC 1123 label subset (which also prevents kubectl flag injection).
    """
    if not _K8S_NAME_RE.match(value):
        raise ConfigurationError(
            f"Invalid Kubernetes {kind} name: '{value}'. "
            "Names must be lowercase alphanumeric or '-', start and end "
            "with an alphanumeric character, and be at most 63 characters."
        )


def parse_k8s_url(url: str) -> tuple[str, str, int, bool]:
    """Parse a ``k8s://`` or ``k8s+tls://`` URL into components.

    Returns (namespace, service, port, use_tls).

    Raises ``ConfigurationError`` on invalid format.
    """
    tls = False

    if url.startswith("k8s+tls://"):
        tls = True
        remainder = url[len("k8s+tls://") :]
    elif url.startswith("k8s://"):
        remainder = url[len("k8s://") :]
    else:
        raise ConfigurationError(
            f"Invalid K8s URL scheme: '{url}'. "
            "Expected k8s://namespace/service:port or k8s+tls://namespace/service:port"
        )

    parts = remainder.split("/", 1)
    if len(parts) != 2:
        raise ConfigurationError(
            f"Invalid K8s URL format: '{url}'. Expected k8s://namespace/service:port"
        )

    namespace = parts[0]
    svc_port = parts[1]

    if ":" not in svc_port:
        raise ConfigurationError(
            f"Missing port in K8s URL: '{url}'. Expected k8s://namespace/service:port"
        )

    service, port_str = svc_port.rsplit(":", 1)
    try:
        port = int(port_str)
    except ValueError:
        raise ConfigurationError(f"Invalid port '{port_str}' in K8s URL: '{url}'") from None

    if not namespace or not service or port <= 0 or port > 65535:
        raise ConfigurationError(
            f"Invalid K8s URL components: namespace='{namespace}', "
            f"service='{service}', port={port}"
        )

    # Validate against RFC 1123 to prevent kubectl flag injection (CodeQL: py/command-line-injection)
    _validate_k8s_name(namespace, "namespace")
    _validate_k8s_name(service, "service")

    return namespace, service, port, tls


def _find_free_port() -> int:
    """Find a free local TCP port."""
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        s.bind(("127.0.0.1", 0))
        return s.getsockname()[1]


def _check_kubectl() -> str | None:
    """Check if kubectl is available and return its path, or None."""
    return shutil.which("kubectl")


class PortForwardManager:
    """Manages a ``kubectl port-forward`` subprocess.

    Usage::

        with PortForwardManager("certmesh", "certmesh-api", 8000) as pf:
            url = pf.local_url  # http://127.0.0.1:{port}
            # ... use url ...
    """

    def __init__(
        self,
        namespace: str,
        service: str,
        remote_port: int,
        *,
        use_tls: bool = False,
        local_port: int = 0,
    ) -> None:
        self.namespace = namespace
        self.service = service
        self.remote_port = remote_port
        self.use_tls = use_tls
        self._local_port = local_port or _find_free_port()
        self._process: subprocess.Popen[str] | None = None
        self._lock = threading.Lock()
        self._original_sigint: Any = None
        self.local_url: str = ""

    def start(self) -> str:
        """Start the port-forward subprocess and return the local URL."""
        kubectl = _check_kubectl()
        if not kubectl:
            raise ConfigurationError(
                "kubectl not found on PATH. Install kubectl to use k8s:// remote URLs. "
                "See: https://kubernetes.io/docs/tasks/tools/"
            )

        # Log kubectl version for diagnostics
        try:
            version_result = subprocess.run(
                [kubectl, "version", "--client", "-o", "json"],
                capture_output=True,
                text=True,
                timeout=5,
            )
            if version_result.returncode == 0:
                logger.info(
                    "kubectl detected.",
                    extra={"kubectl_version_output": version_result.stdout.strip()[:200]},
                )
        except Exception:  # noqa: BLE001 - diagnostic only; failure is non-fatal
            logger.debug("Could not determine kubectl version.")

        cmd = [
            kubectl,
            "port-forward",
            "-n",
            self.namespace,
            f"svc/{self.service}",
            f"{self._local_port}:{self.remote_port}",
        ]

        logger.info(
            "Starting kubectl port-forward.",
            extra={
                "namespace": self.namespace,
                "service": self.service,
                "remote_port": self.remote_port,
                "local_port": self._local_port,
            },
        )

        self._process = subprocess.Popen(
            cmd,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True,
            start_new_session=True,  # Isolate process group to prevent orphans
        )

        # Register cleanup
        atexit.register(self.stop)
        self._original_sigint = signal.getsignal(signal.SIGINT)
        signal.signal(signal.SIGINT, self._sigint_handler)

        # Wait for the forwarding to be established
        if not self._wait_for_ready(timeout=15):
            self.stop()
            raise RemoteConnectionError(
                f"kubectl port-forward failed to start within 15s. "
                f"Check that namespace '{self.namespace}' and service "
                f"'{self.service}' exist and are accessible."
            )

        scheme = "https" if self.use_tls else "http"
        self.local_url = f"{scheme}://127.0.0.1:{self._local_port}"

        logger.info(
            "Port-forward established.",
            extra={"local_url": self.local_url},
        )
        return self.local_url

    def _wait_for_ready(self, timeout: float = 15) -> bool:
        """Wait for kubectl to print the forwarding confirmation."""
        deadline = time.monotonic() + timeout

        while time.monotonic() < deadline:
            if self._process is None or self._process.poll() is not None:
                # Process exited before establishing the forward
                stderr = ""
                if self._process and self._process.stderr:
                    stderr = self._process.stderr.read()
                logger.error(
                    "kubectl port-forward exited unexpectedly.",
                    extra={"stderr": stderr[:500]},
                )
                return False

            # Check stdout for the forwarding line
            if self._process.stdout:
                import select

                ready, _, _ = select.select([self._process.stdout], [], [], 0.5)
                if ready:
                    line = self._process.stdout.readline()
                    if line:
                        match = _FORWARD_RE.search(line)
                        if match:
                            self._local_port = int(match.group(1))
                            return True

            time.sleep(0.2)

        return False

    def is_alive(self) -> bool:
        """Check if the port-forward subprocess is still running."""
        with self._lock:
            if self._process is None:
                return False
            return self._process.poll() is None

    def reconnect(self) -> str:
        """Kill and restart the port-forward. Returns the new local URL."""
        logger.warning("Reconnecting kubectl port-forward.")
        self.stop()
        self._local_port = _find_free_port()
        return self.start()

    def stop(self) -> None:
        """Terminate the port-forward subprocess."""
        with self._lock:
            if self._process is not None:
                proc = self._process
                self._process = None  # Clear ref early to prevent re-entry
                # Close pipes to prevent FD leaks and unblock child writes
                if proc.stdout:
                    proc.stdout.close()
                if proc.stderr:
                    proc.stderr.close()
                try:
                    proc.terminate()
                    proc.wait(timeout=5)
                except subprocess.TimeoutExpired:
                    proc.kill()
                    proc.wait(timeout=2)
                except Exception:
                    logger.exception(
                        "Unexpected error while stopping port-forward process; ignoring."
                    )

        # Unregister atexit to avoid double-cleanup
        atexit.unregister(self.stop)

        # Restore original SIGINT handler
        if self._original_sigint is not None:
            import contextlib

            with contextlib.suppress(ValueError, OSError):
                signal.signal(signal.SIGINT, self._original_sigint)
            self._original_sigint = None

        logger.info("Port-forward stopped.")

    def _sigint_handler(self, signum: int, frame: Any) -> None:
        """Handle Ctrl+C by sending SIGTERM without acquiring the lock.

        Avoids deadlock if stop() is already running in another thread.
        Full cleanup (pipe draining, atexit unregister) happens via the
        normal stop() path or atexit handler.
        """
        if self._lock.acquire(blocking=False):
            try:
                if self._process is not None:
                    self._process.terminate()
            except Exception:  # noqa: BLE001 - cleanup in signal handler; must not raise
                pass
            finally:
                self._lock.release()
        # Re-raise as KeyboardInterrupt for clean CLI exit
        raise KeyboardInterrupt

    def __enter__(self) -> PortForwardManager:
        self.start()
        return self

    def __exit__(self, *exc: Any) -> None:
        self.stop()
