"""
certmesh.renewal_metrics
========================

Prometheus Pushgateway integration for the renewal CronJob.

The CronJob is ephemeral — when it exits, Prometheus has nothing left to
scrape.  This module pushes a snapshot of renewal results to a Pushgateway
just before the process ends so the metrics persist between runs.

Usage::

    from certmesh.renewal_metrics import push_renewal_metrics
    push_renewal_metrics(results, pushgateway_url="http://pushgateway:9091")

A failure to push is logged as a warning and never propagates — a broken
Pushgateway must not cause an otherwise successful renewal run to fail.
"""

from __future__ import annotations

import logging
import time
from datetime import datetime, timezone
from typing import TYPE_CHECKING

from prometheus_client import CollectorRegistry, Gauge, push_to_gateway

if TYPE_CHECKING:
    from certmesh.renewal import RenewalResult

logger = logging.getLogger(__name__)


def push_renewal_metrics(
    results: list[RenewalResult],
    pushgateway_url: str,
    job_name: str = "certmesh-renewal",
) -> None:
    """Push renewal run metrics to a Prometheus Pushgateway.

    Creates a fresh ``CollectorRegistry`` on every call to avoid global-state
    pollution between test runs or multiple invocations in the same process.

    Args:
        results: The list of ``RenewalResult`` objects from ``check_and_renew``.
        pushgateway_url: Base URL of the Pushgateway (e.g. ``http://pushgateway:9091``).
        job_name: Prometheus job label used in the Pushgateway grouping key.
    """
    try:
        _push(results, pushgateway_url, job_name)
    except Exception as exc:  # noqa: BLE001 - fire-and-forget push; broken metrics must not fail renewal
        logger.warning(
            "Failed to push renewal metrics to Pushgateway",
            extra={"pushgateway_url": pushgateway_url, "error": str(exc)},
        )


def _push(
    results: list[RenewalResult],
    pushgateway_url: str,
    job_name: str,
) -> None:
    """Internal push — may raise; callers must handle exceptions."""
    registry = CollectorRegistry()
    now = time.time()
    now_dt = datetime.fromtimestamp(now, tz=timezone.utc)

    # ------------------------------------------------------------------
    # Job-level timestamps
    # ------------------------------------------------------------------
    g_run = Gauge(
        "certmesh_renewal_last_run_timestamp_seconds",
        "Unix timestamp of the most recent renewal check run",
        registry=registry,
    )
    g_run.set(now)

    errors_total = sum(1 for r in results if r.error)
    g_success = Gauge(
        "certmesh_renewal_last_success_timestamp_seconds",
        "Unix timestamp of the most recent renewal check that completed without errors "
        "(0 if the last run had errors or has never succeeded)",
        registry=registry,
    )
    g_success.set(0 if errors_total else now)

    # ------------------------------------------------------------------
    # Per-provider counters
    # ------------------------------------------------------------------
    g_checked = Gauge(
        "certmesh_renewal_certs_checked",
        "Number of certificates checked during the last renewal run",
        ["provider"],
        registry=registry,
    )
    g_renewed = Gauge(
        "certmesh_renewal_certs_renewed",
        "Number of certificates renewed during the last renewal run",
        ["provider"],
        registry=registry,
    )
    g_errors = Gauge(
        "certmesh_renewal_errors",
        "Number of certificate errors encountered during the last renewal run",
        ["provider"],
        registry=registry,
    )

    # Aggregate by provider
    providers: set[str] = {r.provider for r in results}
    for provider in providers:
        provider_results = [r for r in results if r.provider == provider]
        g_checked.labels(provider=provider).set(len(provider_results))
        g_renewed.labels(provider=provider).set(sum(1 for r in provider_results if r.renewed))
        g_errors.labels(provider=provider).set(sum(1 for r in provider_results if r.error))

    # ------------------------------------------------------------------
    # Per-certificate expiry gauge — the key safety-net metric.
    # Even when renewal fails this gauge keeps counting down, giving
    # operators a visible window to intervene before actual expiry.
    # ------------------------------------------------------------------
    g_expiry = Gauge(
        "certmesh_cert_expiry_seconds",
        "Seconds until certificate expiry as observed during the last renewal check",
        ["provider", "common_name"],
        registry=registry,
    )
    for result in results:
        if result.not_after is None:
            continue
        not_after = result.not_after
        if not_after.tzinfo is None:
            not_after = not_after.replace(tzinfo=timezone.utc)
        remaining = (not_after - now_dt).total_seconds()
        g_expiry.labels(provider=result.provider, common_name=result.common_name).set(remaining)

    push_to_gateway(pushgateway_url, job=job_name, registry=registry)
    logger.info(
        "Renewal metrics pushed to Pushgateway",
        extra={
            "pushgateway_url": pushgateway_url,
            "certs": len(results),
            "errors": errors_total,
        },
    )
