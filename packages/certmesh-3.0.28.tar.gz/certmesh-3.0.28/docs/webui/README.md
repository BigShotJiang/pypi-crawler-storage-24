# certmesh Web UI

Browser-based dashboard for TLS certificate lifecycle management.

## Features

- **Certificate Inventory** -- consolidated view of certificates across all configured providers (DigiCert, Venafi, ACM, Vault PKI, Let's Encrypt)
- **Certificate Detail View** -- click any certificate to see full details: subject/CSR attributes, validity, renewal history, associated logs, key algorithm, SANs, and next renewal recommendation
- **Renewal & Revocation** -- trigger certificate renewal or revocation directly from the UI with CSRF protection
- **Expiry Timeline** -- visual breakdown of certificates by time-to-expiry (expired, critical, warning, attention, healthy)
- **Live Log Streaming** -- real-time log viewer using Server-Sent Events (SSE) and xterm.js terminal with ANSI color-coded levels, auto-scroll, pause/resume, level filtering, and S3-backed historical queries
- **Search & Filter** -- search certificates by common name, serial number, or provider; filter by provider tab
- **Dark/Light Theme** -- toggle between dark and light mode with persistent preference
- **OAuth2 SSO** -- authenticate via your identity provider (Keycloak, Auth0, Okta, or any OIDC-compliant IdP)
- **Auto-refresh** -- dashboard refreshes every 60 seconds; pauses when the browser tab is hidden (Page Visibility API)

## Architecture

The Web UI runs as part of the certmesh API process (single container model). The same Gunicorn + Uvicorn workers serve both the REST API and the dashboard.

```
+---------------------------------------------------+
|                  certmesh Pod                      |
|                                                    |
|  Gunicorn (Uvicorn workers)                        |
|  +----------------------------------------------+ |
|  |  FastAPI Application                         | |
|  |                                              | |
|  |  /api/v1/*                REST API routes    | |
|  |  /dashboard/*             Web UI routes      | |
|  |  /dashboard/api/logs      Log query (JSON)   | |
|  |  /dashboard/api/logs/stream  Live logs (SSE) | |
|  |  /dashboard/static        CSS/JS/vendor      | |
|  |  /metrics                 Prometheus metrics  | |
|  +----------------------------------------------+ |
|                                                    |
|  S3 State Store (dashboard state + logs)           |
+---------------------------------------------------+
```

### Why single container?

- The dashboard is lightweight (static HTML/CSS/JS + a few API endpoints) and adds minimal overhead
- Eliminates inter-service networking complexity and latency
- Kubernetes HPA (min 2, max 10 replicas) provides horizontal scaling for both API and UI
- Dashboard state is stored in S3 (shared across all replicas), not in-memory

For environments requiring independent scaling, the dashboard can be disabled on API-only pods (`CM_DASHBOARD_ENABLED=false`) and run on dedicated pods.

## Configuration

### Environment Variables

| Variable | Default | Description |
|----------|---------|-------------|
| `CM_DASHBOARD_ENABLED` | `false` | Enable the Web UI |
| `CM_OAUTH2_CLIENT_ID` | | OAuth2 client/application ID for dashboard login |
| `CM_DASHBOARD_REDIRECT_URI` | `http://localhost:8000/dashboard/callback` | OAuth2 callback URL |
| `CM_DASHBOARD_SESSION_SECRET` | | Session signing secret (min 32 chars) |
| `CM_DASHBOARD_SCOPES` | `openid profile email` | OAuth2 scopes requested during login |
| `CM_DASHBOARD_S3_BUCKET` | | S3 bucket for dashboard state (snapshots, history) |
| `CM_DASHBOARD_S3_PREFIX` | `certmesh/dashboard/` | S3 key prefix for state objects |
| `CM_DASHBOARD_S3_REGION` | | AWS region for S3 |
| `CM_DASHBOARD_S3_ENDPOINT_URL` | | Custom S3 endpoint URL (VPC endpoint, MinIO, etc.) |
| `CM_DASHBOARD_S3_KMS_KEY_ID` | | KMS key ARN/ID for S3 server-side encryption |
| `CM_LOG_S3_ENABLED` | `false` | Enable S3 log persistence |
| `CM_LOG_S3_BUCKET` | (falls back to `CM_DASHBOARD_S3_BUCKET`) | S3 bucket for log storage |
| `CM_LOG_S3_PREFIX` | `certmesh/` | S3 key prefix for log files |
| `CM_LOG_RETENTION_DAYS` | `30` | Days to retain logs (0 = indefinite) |
| `CM_LOG_STORAGE_FORMAT` | `json` | Log storage format (JSONL) |
| `CM_LOG_BUFFER_SIZE` | `50` | Records buffered before S3 flush |
| `CM_LOG_FLUSH_INTERVAL` | `30` | Seconds between S3 flushes |

### Helm values.yaml

```yaml
dashboard:
  enabled: true
  oauth2:
    issuerUrl: "https://keycloak.example.com/realms/certmesh"
    clientId: "certmesh-dashboard"
    scopes: "openid profile email"
  state:
    s3Bucket: "my-certmesh-bucket"
    s3Prefix: "certmesh/dashboard/"
    s3Region: "eu-west-1"
    s3EndpointUrl: ""          # custom S3 endpoint (VPC endpoint, MinIO, etc.)
    s3KmsKeyId: ""             # KMS key for server-side encryption
  logs:
    enabled: true
    retentionDays: 30    # 0 for indefinite
    bufferSize: 50
    flushIntervalSeconds: 30
```

## Multi-User Access

### State Consistency

Dashboard state (certificate snapshots, renewal history) is stored in S3 with the following consistency guarantees:

- **Read-after-write consistency**: S3 provides strong read-after-write consistency
- **Cache TTL**: Each worker caches state for 5 seconds before re-fetching from S3, ensuring changes by other users/workers become visible within seconds
- **Atomic list operations**: Renewal history uses `append_to_list()` which reads the latest state from S3, appends, and writes back under a lock -- reducing (but not eliminating) the window for lost updates
- **ETag tracking**: S3 ETags are tracked for future conditional writes

### Concurrent Operations

When multiple users perform actions simultaneously:

1. **Certificate renewals/revocations** are sent directly to the provider API (DigiCert, Venafi, etc.) -- these are idempotent or provider-managed
2. **History recording** uses atomic append to minimize lost entries across concurrent workers
3. **Dashboard auto-refresh** polls every 60 seconds, so other users' actions become visible within one refresh cycle

## Live Log Streaming

The log viewer streams application logs to the browser in real time using Server-Sent Events (SSE) and an xterm.js terminal emulator:

- **Real-time SSE streaming**: In-memory ring buffer of the most recent 1000 log entries, streamed live to the browser via `/dashboard/api/logs/stream` with automatic reconnection on disconnect
- **xterm.js terminal**: Logs render in a full terminal emulator (xterm.js v5.5.0, self-hosted) with ANSI color-coded log levels (red=ERROR, yellow=WARNING, green=INFO, grey=DEBUG)
- **Smart auto-scroll**: Follows new entries unless the user scrolls up; resumes on scroll-to-bottom
- **Pause/resume**: Disconnect and reconnect the SSE stream on demand
- **Level filtering**: Client-side filter by DEBUG, INFO, WARNING, ERROR, CRITICAL
- **Dark/light theme**: Terminal theme follows the dashboard theme toggle
- **Historical queries**: S3-backed log storage partitioned by date (`YYYY/MM/DD/HH-{uuid}.jsonl`)
- **JSON query endpoint**: `GET /dashboard/api/logs` returns the last 100 entries as JSON

### S3 Log Format

Logs are stored as JSONL (newline-delimited JSON), one record per line:

```json
{"timestamp":"2026-03-25T10:00:00+00:00","level":"INFO","logger":"certmesh.api.routes","message":"Certificate renewal initiated","provider":"venafi","cert_id":"abc123"}
```

JSONL was chosen because:
- Line-by-line parsing is memory-efficient for large files
- Compatible with AWS Athena, Spark, and other analytics tools
- No special delimiters or escaping required
- Each line is independently parseable (no streaming parser needed)

## Certificate Detail View

Click any certificate in the inventory table to see:

- **Identity**: Common name, serial number, provider, status, SAN DNS names
- **CSR Attributes**: Subject, issuer, organisation, OU, country, state, locality
- **Validity**: Valid from/until, days remaining, key algorithm, key size, thumbprint
- **Renewal Info**: Renewal eligibility, next renewal recommendation, type, in-use-by
- **History**: Complete renewal/revocation history with timestamps, actions, status, and user
- **Logs**: Associated application logs filtered by certificate ID

## Security

- **OAuth2 PKCE** authentication (no client secrets in the browser)
- **CSRF tokens** on all state-changing operations (forms + AJAX headers)
- **Content Security Policy**: `script-src 'self'` (no inline scripts)
- **HttpOnly, Secure, SameSite=Lax** session cookies
- **Input validation**: Certificate IDs validated against `^[a-zA-Z0-9\-_.:]{1,256}$`
- **Error sanitization**: Internal error details are never exposed to the browser
- **Rate limiting**: Configurable per-client rate limits on all endpoints

## Performance

- **Vendored assets**: Bootstrap CSS/JS and icons are served locally (no CDN dependency)
- **GZip compression**: API responses compressed at the application layer
- **Debounced search**: 250ms debounce on certificate search input
- **Visibility API**: Auto-refresh pauses when the tab is hidden
- **Minimal JS**: Vanilla JavaScript, no framework overhead
- **Lazy loading**: Certificate data loaded via AJAX after page render
