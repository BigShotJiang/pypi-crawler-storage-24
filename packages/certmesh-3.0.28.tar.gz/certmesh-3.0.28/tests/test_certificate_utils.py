"""Tests for certmesh.certificate_utils."""

from __future__ import annotations

import os
from datetime import datetime
from pathlib import Path
from typing import Any

import pytest
from cryptography.hazmat.primitives.asymmetric import ec, rsa

from certmesh.certificate_utils import (
    CertificateBundle,
    SubjectInfo,
    assemble_bundle,
    build_csr,
    create_pkcs12_bundle,
    csr_to_pem,
    generate_ec_private_key,
    generate_rsa_private_key,
    parse_pkcs12_bundle,
    persist_bundle,
    private_key_to_pem,
)
from certmesh.exceptions import (
    CertificateExportError,
    KeyGenerationError,
    PKCS12ParseError,
)

JsonDict = dict[str, Any]


class TestGenerateRSAPrivateKey:
    @pytest.mark.parametrize("key_size", [2048, 3072, 4096])
    def test_valid_key_sizes(self, key_size: int) -> None:
        key = generate_rsa_private_key(key_size)
        assert isinstance(key, rsa.RSAPrivateKey)
        assert key.key_size == key_size

    def test_invalid_key_size_raises(self) -> None:
        with pytest.raises(KeyGenerationError, match="Unsupported"):
            generate_rsa_private_key(1024)


class TestGenerateECPrivateKey:
    @pytest.mark.parametrize("curve", ["P-256", "P-384", "P-521"])
    def test_valid_curves(self, curve: str) -> None:
        key = generate_ec_private_key(curve)
        assert isinstance(key, ec.EllipticCurvePrivateKey)
        assert key.key_size > 0

    def test_p256_key_size(self) -> None:
        key = generate_ec_private_key("P-256")
        assert key.key_size == 256

    def test_p384_key_size(self) -> None:
        key = generate_ec_private_key("P-384")
        assert key.key_size == 384

    def test_p521_key_size(self) -> None:
        key = generate_ec_private_key("P-521")
        assert key.key_size == 521

    def test_invalid_curve_raises(self) -> None:
        with pytest.raises(KeyGenerationError, match="Unsupported curve"):
            generate_ec_private_key("P-224")

    def test_default_curve_is_p256(self) -> None:
        key = generate_ec_private_key()
        assert key.key_size == 256


class TestPrivateKeyToPEM:
    def test_pem_output_rsa(self, rsa_private_key: rsa.RSAPrivateKey) -> None:
        pem = private_key_to_pem(rsa_private_key)
        # PKCS#8 format — header is "BEGIN PRIVATE KEY" (not algorithm-specific)
        assert b"-----BEGIN PRIVATE KEY-----" in pem
        assert b"-----END PRIVATE KEY-----" in pem

    def test_pem_output_ec(self) -> None:
        key = generate_ec_private_key("P-256")
        pem = private_key_to_pem(key)
        assert b"-----BEGIN PRIVATE KEY-----" in pem
        assert b"-----END PRIVATE KEY-----" in pem


class TestBuildCSR:
    def test_basic_csr(self, rsa_private_key: rsa.RSAPrivateKey) -> None:
        subject = SubjectInfo(
            common_name="test.example.com",
            organisation="Test Org",
            country="US",
        )
        csr = build_csr(rsa_private_key, subject)
        assert csr is not None
        pem = csr_to_pem(csr)
        assert "BEGIN CERTIFICATE REQUEST" in pem

    def test_csr_with_sans(self, rsa_private_key: rsa.RSAPrivateKey) -> None:
        subject = SubjectInfo(
            common_name="test.example.com",
            san_dns_names=["api.example.com", "web.example.com"],
        )
        csr = build_csr(rsa_private_key, subject)
        pem = csr_to_pem(csr)
        assert "BEGIN CERTIFICATE REQUEST" in pem

    def test_csr_no_sans_uses_cn(self, rsa_private_key: rsa.RSAPrivateKey) -> None:
        subject = SubjectInfo(common_name="test.example.com")
        csr = build_csr(rsa_private_key, subject)
        assert csr is not None

    def test_csr_with_ip_san(self, rsa_private_key: rsa.RSAPrivateKey) -> None:
        from cryptography import x509 as cx509

        subject = SubjectInfo(
            common_name="svc.internal",
            san_ip_addresses=["10.0.0.1", "192.168.1.100"],
        )
        csr = build_csr(rsa_private_key, subject)
        pem = csr_to_pem(csr)
        assert "BEGIN CERTIFICATE REQUEST" in pem
        # Verify IP SANs are embedded in the CSR extensions
        san_ext = csr.extensions.get_extension_for_class(cx509.SubjectAlternativeName)
        ip_sans = san_ext.value.get_values_for_type(cx509.IPAddress)
        assert len(ip_sans) == 2

    def test_csr_with_uri_san(self, rsa_private_key: rsa.RSAPrivateKey) -> None:
        from cryptography import x509 as cx509

        subject = SubjectInfo(
            common_name="svc.cluster.local",
            san_uris=["spiffe://cluster.local/ns/default/sa/my-service"],
        )
        csr = build_csr(rsa_private_key, subject)
        san_ext = csr.extensions.get_extension_for_class(cx509.SubjectAlternativeName)
        uri_sans = san_ext.value.get_values_for_type(cx509.UniformResourceIdentifier)
        assert len(uri_sans) == 1
        assert str(uri_sans[0]) == "spiffe://cluster.local/ns/default/sa/my-service"

    def test_csr_with_mixed_sans(self, rsa_private_key: rsa.RSAPrivateKey) -> None:
        from cryptography import x509 as cx509

        subject = SubjectInfo(
            common_name="mixed.example.com",
            san_dns_names=["alt.example.com"],
            san_ip_addresses=["10.1.2.3"],
            san_uris=["spiffe://example.com/workload"],
        )
        csr = build_csr(rsa_private_key, subject)
        san_ext = csr.extensions.get_extension_for_class(cx509.SubjectAlternativeName)
        assert len(san_ext.value.get_values_for_type(cx509.DNSName)) == 1
        assert len(san_ext.value.get_values_for_type(cx509.IPAddress)) == 1
        assert len(san_ext.value.get_values_for_type(cx509.UniformResourceIdentifier)) == 1

    def test_csr_invalid_ip_raises(self, rsa_private_key: rsa.RSAPrivateKey) -> None:
        from certmesh.exceptions import CSRGenerationError

        subject = SubjectInfo(
            common_name="test.example.com",
            san_ip_addresses=["not-an-ip"],
        )
        with pytest.raises(CSRGenerationError):
            build_csr(rsa_private_key, subject)

    def test_csr_with_ec_key(self) -> None:
        key = generate_ec_private_key("P-256")
        subject = SubjectInfo(
            common_name="ec.example.com",
            san_dns_names=["api.example.com"],
        )
        csr = build_csr(key, subject)
        pem = csr_to_pem(csr)
        assert "BEGIN CERTIFICATE REQUEST" in pem


class TestCreatePKCS12Bundle:
    def test_roundtrip_no_passphrase(
        self,
        self_signed_cert_pem: bytes,
        private_key_pem: bytes,
    ) -> None:
        p12 = create_pkcs12_bundle(self_signed_cert_pem, private_key_pem)
        assert isinstance(p12, bytes)
        assert len(p12) > 0
        # Verify it can be parsed back
        cert_out, _key_out, _chain_out = parse_pkcs12_bundle(p12, None)
        assert b"BEGIN CERTIFICATE" in cert_out
        assert _key_out is not None

    def test_roundtrip_with_passphrase(
        self,
        self_signed_cert_pem: bytes,
        private_key_pem: bytes,
    ) -> None:
        p12 = create_pkcs12_bundle(self_signed_cert_pem, private_key_pem, passphrase="secret")
        cert_out, _, _ = parse_pkcs12_bundle(p12, "secret")
        assert b"BEGIN CERTIFICATE" in cert_out

    def test_wrong_passphrase_raises(
        self,
        self_signed_cert_pem: bytes,
        private_key_pem: bytes,
    ) -> None:
        p12 = create_pkcs12_bundle(self_signed_cert_pem, private_key_pem, passphrase="correct")
        with pytest.raises(PKCS12ParseError):
            parse_pkcs12_bundle(p12, "wrong")

    def test_with_chain(
        self,
        self_signed_cert_pem: bytes,
        private_key_pem: bytes,
    ) -> None:
        # Use the leaf cert as a fake CA chain entry for the test
        p12 = create_pkcs12_bundle(
            self_signed_cert_pem,
            private_key_pem,
            chain_pem=self_signed_cert_pem,
        )
        assert isinstance(p12, bytes)

    def test_friendly_name(
        self,
        self_signed_cert_pem: bytes,
        private_key_pem: bytes,
    ) -> None:
        p12 = create_pkcs12_bundle(
            self_signed_cert_pem,
            private_key_pem,
            friendly_name="my-cert",
        )
        assert isinstance(p12, bytes)

    def test_invalid_cert_pem_raises(self, private_key_pem: bytes) -> None:
        with pytest.raises(PKCS12ParseError, match="certificate PEM"):
            create_pkcs12_bundle(b"not-a-cert", private_key_pem)

    def test_invalid_key_pem_raises(self, self_signed_cert_pem: bytes) -> None:
        with pytest.raises(PKCS12ParseError, match="private key PEM"):
            create_pkcs12_bundle(self_signed_cert_pem, b"not-a-key")


class TestParsePKCS12Bundle:
    def test_valid_bundle(self, pkcs12_bundle: bytes) -> None:
        cert_pem, key_pem, chain_pem = parse_pkcs12_bundle(pkcs12_bundle, "testpass")
        assert b"BEGIN CERTIFICATE" in cert_pem
        assert b"BEGIN RSA PRIVATE KEY" in key_pem
        # No chain certs in our test bundle
        assert chain_pem is None

    def test_wrong_passphrase_raises(self, pkcs12_bundle: bytes) -> None:
        with pytest.raises(PKCS12ParseError, match="passphrase"):
            parse_pkcs12_bundle(pkcs12_bundle, "wrong")

    def test_invalid_data_raises(self) -> None:
        with pytest.raises(PKCS12ParseError):
            parse_pkcs12_bundle(b"not-pkcs12", "pass")


class TestAssembleBundle:
    def test_basic_assembly(
        self,
        self_signed_cert_pem: bytes,
        private_key_pem: bytes,
    ) -> None:
        bundle = assemble_bundle(
            cert_pem=self_signed_cert_pem,
            private_key_pem=private_key_pem,
            chain_pem=None,
            source_id="test-123",
        )
        assert bundle.common_name == "test.example.com"
        assert bundle.source_id == "test-123"
        assert bundle.certificate_pem.startswith("-----BEGIN CERTIFICATE-----")
        assert bundle.serial_number
        assert isinstance(bundle.not_after, datetime)
        assert bundle.certificate_pem_b64

    def test_with_chain(
        self,
        self_signed_cert_pem: bytes,
        private_key_pem: bytes,
    ) -> None:
        bundle = assemble_bundle(
            cert_pem=self_signed_cert_pem,
            private_key_pem=private_key_pem,
            chain_pem=self_signed_cert_pem,  # reuse as fake chain
            source_id="test-456",
        )
        assert bundle.chain_pem is not None

    def test_invalid_cert_pem_raises(self, private_key_pem: bytes) -> None:
        with pytest.raises(CertificateExportError):
            assemble_bundle(
                cert_pem=b"not-a-cert",
                private_key_pem=private_key_pem,
                chain_pem=None,
                source_id="bad",
            )


class TestPersistBundle:
    def _make_bundle(
        self,
        self_signed_cert_pem: bytes,
        private_key_pem: bytes,
    ) -> CertificateBundle:
        return assemble_bundle(
            cert_pem=self_signed_cert_pem,
            private_key_pem=private_key_pem,
            chain_pem=self_signed_cert_pem,
            source_id="test-789",
        )

    def test_filesystem_persistence(
        self,
        tmp_path: Path,
        self_signed_cert_pem: bytes,
        private_key_pem: bytes,
    ) -> None:
        bundle = self._make_bundle(self_signed_cert_pem, private_key_pem)
        output_cfg: JsonDict = {
            "destination": "filesystem",
            "base_path": str(tmp_path / "certs"),
            "cert_filename": "{order_id}_cert.pem",
            "key_filename": "{order_id}_key.pem",
            "chain_filename": "{order_id}_chain.pem",
        }
        result = persist_bundle(bundle, output_cfg)
        assert "filesystem_cert" in result
        assert "filesystem_key" in result
        assert "filesystem_chain" in result

        cert_path = Path(result["filesystem_cert"])
        key_path = Path(result["filesystem_key"])
        assert cert_path.exists()
        assert key_path.exists()
        # Key should have restricted permissions
        assert oct(os.stat(key_path).st_mode)[-3:] == "600"

    def test_filesystem_pkcs12_output(
        self,
        tmp_path: Path,
        self_signed_cert_pem: bytes,
        private_key_pem: bytes,
    ) -> None:
        bundle = self._make_bundle(self_signed_cert_pem, private_key_pem)
        output_cfg: JsonDict = {
            "destination": "filesystem",
            "base_path": str(tmp_path / "certs"),
            "cert_filename": "{order_id}_cert.pem",
            "key_filename": "{order_id}_key.pem",
            "pkcs12_filename": "{order_id}.p12",
            "pkcs12_passphrase": "testpass",
        }
        result = persist_bundle(bundle, output_cfg)
        assert "filesystem_pkcs12" in result
        p12_path = Path(result["filesystem_pkcs12"])
        assert p12_path.exists()
        assert p12_path.suffix == ".p12"
        # PKCS#12 file should have restricted permissions
        assert oct(os.stat(p12_path).st_mode)[-3:] == "600"

    def test_filesystem_pkcs12_no_passphrase(
        self,
        tmp_path: Path,
        self_signed_cert_pem: bytes,
        private_key_pem: bytes,
    ) -> None:
        bundle = self._make_bundle(self_signed_cert_pem, private_key_pem)
        output_cfg: JsonDict = {
            "destination": "filesystem",
            "base_path": str(tmp_path / "certs"),
            "cert_filename": "{order_id}_cert.pem",
            "key_filename": "{order_id}_key.pem",
            "pkcs12_filename": "{order_id}.p12",
        }
        result = persist_bundle(bundle, output_cfg)
        assert "filesystem_pkcs12" in result
        p12_path = Path(result["filesystem_pkcs12"])
        assert p12_path.exists()
