"""Tests for certmesh.api.log_buffer."""

from __future__ import annotations

import asyncio
import contextlib
import logging
import threading

import pytest

from certmesh.api.log_buffer import BufferHandler, LogBuffer, LogEntry

# ── LogEntry ──────────────────────────────────────────────────────────────────


class TestLogEntry:
    """LogEntry dataclass tests."""

    def test_to_dict(self) -> None:
        entry = LogEntry(
            timestamp=1711000000.0,
            level="INFO",
            logger_name="certmesh.api",
            message="hello world",
            extra={"request_id": "abc123"},
        )
        d = entry.to_dict()
        assert d["timestamp"] == 1711000000.0
        assert d["level"] == "INFO"
        assert d["logger"] == "certmesh.api"
        assert d["message"] == "hello world"
        assert d["request_id"] == "abc123"

    def test_to_dict_no_extra(self) -> None:
        entry = LogEntry(
            timestamp=1711000000.0,
            level="ERROR",
            logger_name="root",
            message="oops",
        )
        d = entry.to_dict()
        assert "request_id" not in d
        assert d["level"] == "ERROR"

    def test_to_dict_core_fields_not_overwritten(self) -> None:
        """Extra dict must not overwrite core fields (logger, level, etc.)."""
        entry = LogEntry(
            timestamp=1711000000.0,
            level="INFO",
            logger_name="certmesh.api",
            message="test msg",
            extra={"logger": "attacker", "level": "CRITICAL", "message": "pwned"},
        )
        d = entry.to_dict()
        assert d["logger"] == "certmesh.api"
        assert d["level"] == "INFO"
        assert d["message"] == "test msg"

    def test_frozen(self) -> None:
        entry = LogEntry(timestamp=0, level="INFO", logger_name="x", message="y")
        with pytest.raises(AttributeError):
            entry.level = "DEBUG"  # type: ignore[misc]


# ── LogBuffer ─────────────────────────────────────────────────────────────────


class TestLogBuffer:
    """LogBuffer ring buffer tests."""

    def test_append_and_get_recent(self) -> None:
        buf = LogBuffer(maxlen=100)
        for i in range(5):
            buf.append(
                LogEntry(timestamp=float(i), level="INFO", logger_name="t", message=f"msg-{i}")
            )

        recent = buf.get_recent(3)
        assert len(recent) == 3
        assert recent[0].message == "msg-2"
        assert recent[2].message == "msg-4"

    def test_get_recent_fewer_than_n(self) -> None:
        buf = LogBuffer(maxlen=100)
        buf.append(LogEntry(timestamp=0, level="INFO", logger_name="t", message="only"))
        recent = buf.get_recent(50)
        assert len(recent) == 1

    def test_ring_buffer_overflow(self) -> None:
        buf = LogBuffer(maxlen=5)
        for i in range(10):
            buf.append(
                LogEntry(timestamp=float(i), level="INFO", logger_name="t", message=f"msg-{i}")
            )

        recent = buf.get_recent(100)
        assert len(recent) == 5
        assert recent[0].message == "msg-5"
        assert recent[4].message == "msg-9"

    def test_thread_safe_concurrent_appends(self) -> None:
        buf = LogBuffer(maxlen=5000)
        errors: list[Exception] = []

        def append_batch(start: int) -> None:
            try:
                for i in range(100):
                    buf.append(
                        LogEntry(
                            timestamp=float(start + i),
                            level="INFO",
                            logger_name="t",
                            message=f"msg-{start + i}",
                        )
                    )
            except (TypeError, RuntimeError) as exc:
                errors.append(exc)

        threads = [threading.Thread(target=append_batch, args=(i * 100,)) for i in range(10)]
        for t in threads:
            t.start()
        for t in threads:
            t.join()

        assert not errors
        recent = buf.get_recent(5000)
        assert len(recent) == 1000

    @pytest.mark.asyncio()
    async def test_subscribe_receives_entries(self) -> None:
        buf = LogBuffer(maxlen=100)
        loop = asyncio.get_running_loop()
        buf.set_event_loop(loop)

        # Pre-populate with history.
        for i in range(3):
            buf.append(
                LogEntry(timestamp=float(i), level="INFO", logger_name="t", message=f"history-{i}")
            )

        received: list[LogEntry] = []

        async def consume() -> None:
            async for entry in buf.subscribe():
                received.append(entry)
                if entry.message == "live-1":
                    break

        task = asyncio.create_task(consume())

        # Give subscriber time to start.
        await asyncio.sleep(0.05)

        # Push live entries.
        buf.append(LogEntry(timestamp=10.0, level="INFO", logger_name="t", message="live-0"))
        buf.append(LogEntry(timestamp=11.0, level="INFO", logger_name="t", message="live-1"))

        await asyncio.wait_for(task, timeout=2.0)

        # Should have 3 history + 2 live entries.
        assert len(received) == 5
        assert received[0].message == "history-0"
        assert received[3].message == "live-0"
        assert received[4].message == "live-1"

    @pytest.mark.asyncio()
    async def test_subscribe_cleanup_on_cancel(self) -> None:
        buf = LogBuffer(maxlen=100)
        loop = asyncio.get_running_loop()
        buf.set_event_loop(loop)

        async def consume() -> None:
            async for _ in buf.subscribe():
                pass

        task = asyncio.create_task(consume())
        await asyncio.sleep(0.05)

        # Should have 1 subscriber.
        assert len(buf._subscribers) == 1

        task.cancel()
        with contextlib.suppress(asyncio.CancelledError):
            await task

        # Subscriber should be cleaned up.
        assert len(buf._subscribers) == 0

    def test_shutdown_clears_subscribers(self) -> None:
        buf = LogBuffer(maxlen=100)
        # Add a mock subscriber queue.
        q: asyncio.Queue[LogEntry | None] = asyncio.Queue()
        buf._subscribers.add(q)
        assert len(buf._subscribers) == 1

        buf.shutdown()
        assert len(buf._subscribers) == 0


# ── BufferHandler ─────────────────────────────────────────────────────────────


class TestBufferHandler:
    """BufferHandler logging integration tests."""

    def test_emit_captures_record(self) -> None:
        buf = LogBuffer(maxlen=100)
        handler = BufferHandler(buf)

        test_logger = logging.getLogger("test.buffer_handler")
        test_logger.addHandler(handler)
        test_logger.setLevel(logging.DEBUG)

        try:
            test_logger.info("test message from handler")
        finally:
            test_logger.removeHandler(handler)

        recent = buf.get_recent(1)
        assert len(recent) == 1
        assert recent[0].level == "INFO"
        assert recent[0].logger_name == "test.buffer_handler"
        assert "test message from handler" in recent[0].message

    def test_emit_captures_extra_fields(self) -> None:
        buf = LogBuffer(maxlen=100)
        handler = BufferHandler(buf)

        test_logger = logging.getLogger("test.extra")
        test_logger.addHandler(handler)
        test_logger.setLevel(logging.DEBUG)

        try:
            test_logger.warning("with extra", extra={"request_id": "xyz"})
        finally:
            test_logger.removeHandler(handler)

        recent = buf.get_recent(1)
        assert len(recent) == 1
        assert recent[0].extra.get("request_id") == "xyz"

    def test_emit_does_not_raise(self) -> None:
        """Handler must not propagate exceptions (logging contract)."""
        buf = LogBuffer(maxlen=100)
        handler = BufferHandler(buf)

        # Create a record that might cause issues.
        record = logging.LogRecord(
            name="test",
            level=logging.INFO,
            pathname="",
            lineno=0,
            msg="test %s",
            args=("value",),
            exc_info=None,
        )
        # Should not raise.
        handler.emit(record)
