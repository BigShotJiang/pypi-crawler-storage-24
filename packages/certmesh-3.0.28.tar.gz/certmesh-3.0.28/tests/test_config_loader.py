"""Tests for certmesh.config_loader compatibility shim."""

from __future__ import annotations

import warnings
from pathlib import Path
from typing import Any
from unittest.mock import MagicMock, patch

import pytest

from certmesh.config_loader import load_config

JsonDict = dict[str, Any]


class TestLoadConfig:
    """Tests for the deprecated load_config shim."""

    @patch("certmesh.config_loader.validate_config")
    @patch("certmesh.config_loader.build_config")
    def test_emits_deprecation_warning(
        self,
        mock_build: MagicMock,
        mock_validate: MagicMock,
    ) -> None:
        mock_build.return_value = {"provider": "acm"}
        with pytest.warns(DeprecationWarning, match="load_config is deprecated"):
            load_config()

    @patch("certmesh.config_loader.validate_config")
    @patch("certmesh.config_loader.build_config")
    def test_delegates_to_build_config_with_default_path(
        self,
        mock_build: MagicMock,
        mock_validate: MagicMock,
    ) -> None:
        mock_build.return_value = {"provider": "acm"}
        with warnings.catch_warnings():
            warnings.simplefilter("ignore", DeprecationWarning)
            load_config()
        mock_build.assert_called_once_with(config_file="config/config.yaml")

    @patch("certmesh.config_loader.validate_config")
    @patch("certmesh.config_loader.build_config")
    def test_delegates_to_build_config_with_custom_path(
        self,
        mock_build: MagicMock,
        mock_validate: MagicMock,
    ) -> None:
        custom = Path("/tmp/my_config.yaml")
        mock_build.return_value = {"provider": "vault"}
        with warnings.catch_warnings():
            warnings.simplefilter("ignore", DeprecationWarning)
            load_config(config_path=custom)
        mock_build.assert_called_once_with(config_file=custom)

    @patch("certmesh.config_loader.validate_config")
    @patch("certmesh.config_loader.build_config")
    def test_calls_validate_config(
        self,
        mock_build: MagicMock,
        mock_validate: MagicMock,
    ) -> None:
        cfg: JsonDict = {"provider": "acm", "domain": "example.com"}
        mock_build.return_value = cfg
        with warnings.catch_warnings():
            warnings.simplefilter("ignore", DeprecationWarning)
            load_config()
        mock_validate.assert_called_once_with(cfg)

    @patch("certmesh.config_loader.validate_config")
    @patch("certmesh.config_loader.build_config")
    def test_returns_config_dict(
        self,
        mock_build: MagicMock,
        mock_validate: MagicMock,
    ) -> None:
        expected: JsonDict = {"provider": "acm", "domain": "example.com"}
        mock_build.return_value = expected
        with warnings.catch_warnings():
            warnings.simplefilter("ignore", DeprecationWarning)
            result = load_config()
        assert result is expected

    @patch("certmesh.config_loader.validate_config")
    @patch("certmesh.config_loader.build_config")
    def test_accepts_string_path(
        self,
        mock_build: MagicMock,
        mock_validate: MagicMock,
    ) -> None:
        mock_build.return_value = {}
        with warnings.catch_warnings():
            warnings.simplefilter("ignore", DeprecationWarning)
            load_config(config_path="some/other.yaml")
        mock_build.assert_called_once_with(config_file="some/other.yaml")
