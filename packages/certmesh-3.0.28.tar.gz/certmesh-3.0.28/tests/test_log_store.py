"""Tests for certmesh.api.log_store."""

from __future__ import annotations

import json
import logging
from unittest.mock import MagicMock, patch

import pytest

from certmesh.api.log_store import LogCapture, LogRecord, LogStore, LogStoreConfig

# ── LogRecord ─────────────────────────────────────────────────────────────────


class TestLogRecord:
    def test_to_dict_basic(self) -> None:
        record = LogRecord(
            timestamp="2026-03-25T10:00:00+00:00",
            level="INFO",
            logger_name="certmesh.api",
            message="Test message",
        )
        d = record.to_dict()
        assert d["timestamp"] == "2026-03-25T10:00:00+00:00"
        assert d["level"] == "INFO"
        assert d["logger"] == "certmesh.api"
        assert d["message"] == "Test message"

    def test_to_dict_with_extra(self) -> None:
        record = LogRecord(
            timestamp="2026-03-25T10:00:00+00:00",
            level="WARNING",
            message="Error occurred",
            extra={"provider": "venafi", "cert_id": "abc123"},
        )
        d = record.to_dict()
        assert d["provider"] == "venafi"
        assert d["cert_id"] == "abc123"


# ── LogStore (in-memory mode) ────────────────────────────────────────────────


class TestLogStoreInMemory:
    @pytest.fixture()
    def store(self) -> LogStore:
        config = LogStoreConfig(enabled=True, bucket="", buffer_size=100)
        return LogStore(config)

    def test_add_and_query(self, store: LogStore) -> None:
        store.add(
            LogRecord(
                timestamp="2026-03-25T10:00:00+00:00",
                level="INFO",
                logger_name="test",
                message="Hello world",
            )
        )
        result = store.query()
        assert result["total"] == 1
        assert result["logs"][0]["message"] == "Hello world"

    def test_query_with_search(self, store: LogStore) -> None:
        store.add(LogRecord(timestamp="t1", level="INFO", message="Certificate renewed"))
        store.add(LogRecord(timestamp="t2", level="ERROR", message="Connection failed"))
        store.add(LogRecord(timestamp="t3", level="INFO", message="Certificate revoked"))

        result = store.query(search="certificate")
        assert result["total"] == 2

    def test_query_with_level_filter(self, store: LogStore) -> None:
        store.add(LogRecord(timestamp="t1", level="INFO", message="info msg"))
        store.add(LogRecord(timestamp="t2", level="ERROR", message="error msg"))
        store.add(LogRecord(timestamp="t3", level="WARNING", message="warn msg"))

        result = store.query(level="ERROR")
        assert result["total"] == 1
        assert result["logs"][0]["level"] == "ERROR"

    def test_query_with_logger_filter(self, store: LogStore) -> None:
        store.add(
            LogRecord(
                timestamp="t1", level="INFO", logger_name="certmesh.api.routes", message="m1"
            )
        )
        store.add(
            LogRecord(timestamp="t2", level="INFO", logger_name="certmesh.providers", message="m2")
        )

        result = store.query(logger_name="routes")
        assert result["total"] == 1

    def test_query_pagination(self, store: LogStore) -> None:
        for i in range(10):
            store.add(LogRecord(timestamp=f"t{i}", level="INFO", message=f"msg {i}"))

        result = store.query(limit=3, offset=0)
        assert result["total"] == 10
        assert len(result["logs"]) == 3

        result2 = store.query(limit=3, offset=3)
        assert len(result2["logs"]) == 3

    def test_recent_window_is_capped(self, store: LogStore) -> None:
        store._max_recent = 5
        for i in range(10):
            store.add(LogRecord(timestamp=f"t{i}", level="INFO", message=f"msg {i}"))

        result = store.query()
        assert result["total"] == 5

    def test_get_stats(self, store: LogStore) -> None:
        store.add(LogRecord(timestamp="t1", level="INFO", message="test"))
        stats = store.get_stats()
        assert stats["recent_count"] == 1
        assert stats["s3_available"] is False
        assert stats["retention_days"] == 30

    def test_flush_clears_buffer(self, store: LogStore) -> None:
        store.add(LogRecord(timestamp="t1", level="INFO", message="test"))
        assert store.get_stats()["buffered"] == 1
        store.flush()
        assert store.get_stats()["buffered"] == 0

    def test_shutdown(self, store: LogStore) -> None:
        store.add(LogRecord(timestamp="t1", level="INFO", message="test"))
        store.shutdown()
        assert store.get_stats()["buffered"] == 0


# ── LogStore with mocked S3 ──────────────────────────────────────────────────


class TestLogStoreS3:
    def test_flush_writes_to_s3(self) -> None:
        config = LogStoreConfig(enabled=True, bucket="test-bucket", buffer_size=100)

        mock_s3 = MagicMock()
        mock_s3.head_bucket.return_value = {}
        mock_s3.put_object.return_value = {}

        with patch("boto3.client", return_value=mock_s3):
            store = LogStore(config)

        store.add(LogRecord(timestamp="t1", level="INFO", message="test message"))
        store.flush()

        mock_s3.put_object.assert_called_once()
        call_kwargs = mock_s3.put_object.call_args[1]
        assert call_kwargs["Bucket"] == "test-bucket"
        assert call_kwargs["ContentType"] == "application/x-ndjson"
        assert call_kwargs["ServerSideEncryption"] == "AES256"
        body = call_kwargs["Body"].decode("utf-8")
        parsed = json.loads(body.strip())
        assert parsed["message"] == "test message"

        store.shutdown()

    def test_auto_flush_on_buffer_full(self) -> None:
        config = LogStoreConfig(enabled=True, bucket="test-bucket", buffer_size=2)

        mock_s3 = MagicMock()
        mock_s3.head_bucket.return_value = {}
        mock_s3.put_object.return_value = {}

        with patch("boto3.client", return_value=mock_s3):
            store = LogStore(config)

        store.add(LogRecord(timestamp="t1", level="INFO", message="msg 1"))
        assert mock_s3.put_object.call_count == 0

        store.add(LogRecord(timestamp="t2", level="INFO", message="msg 2"))
        assert mock_s3.put_object.call_count == 1

        store.shutdown()

    def test_query_s3_returns_results(self) -> None:
        config = LogStoreConfig(enabled=True, bucket="test-bucket")

        mock_s3 = MagicMock()
        mock_s3.head_bucket.return_value = {}

        paginator = MagicMock()
        page_data = {
            "Contents": [{"Key": "certmesh/logs/2026/03/25/10-abc.jsonl"}],
        }
        paginator.paginate.return_value = [page_data]
        mock_s3.get_paginator.return_value = paginator

        log_content = json.dumps({"timestamp": "t1", "level": "INFO", "message": "historical log"})
        mock_s3.get_object.return_value = {
            "Body": MagicMock(read=MagicMock(return_value=log_content.encode("utf-8")))
        }

        with patch("boto3.client", return_value=mock_s3):
            store = LogStore(config)

        result = store.query_s3(date="2026-03-25")
        assert result["total"] == 1
        assert result["logs"][0]["message"] == "historical log"

        store.shutdown()

    def test_query_s3_with_level_filter(self) -> None:
        config = LogStoreConfig(enabled=True, bucket="test-bucket")

        mock_s3 = MagicMock()
        mock_s3.head_bucket.return_value = {}

        paginator = MagicMock()
        page_data = {
            "Contents": [{"Key": "certmesh/logs/2026/03/25/10-abc.jsonl"}],
        }
        paginator.paginate.return_value = [page_data]
        mock_s3.get_paginator.return_value = paginator

        lines = "\n".join(
            [
                json.dumps({"timestamp": "t1", "level": "INFO", "message": "info msg"}),
                json.dumps({"timestamp": "t2", "level": "ERROR", "message": "error msg"}),
            ]
        )
        mock_s3.get_object.return_value = {
            "Body": MagicMock(read=MagicMock(return_value=lines.encode("utf-8")))
        }

        with patch("boto3.client", return_value=mock_s3):
            store = LogStore(config)

        result = store.query_s3(date="2026-03-25", level="ERROR")
        assert result["total"] == 1
        assert result["logs"][0]["level"] == "ERROR"

        store.shutdown()

    def test_query_s3_empty_date(self) -> None:
        config = LogStoreConfig(enabled=True, bucket="test-bucket")

        mock_s3 = MagicMock()
        mock_s3.head_bucket.return_value = {}

        with patch("boto3.client", return_value=mock_s3):
            store = LogStore(config)

        result = store.query_s3(date="")
        assert result["total"] == 0
        store.shutdown()

    def test_s3_unavailable_degrades_gracefully(self) -> None:
        config = LogStoreConfig(enabled=True, bucket="test-bucket")

        with patch("boto3.client", side_effect=Exception("no connection")):
            store = LogStore(config)

        assert store.is_s3_available is False
        store.add(LogRecord(timestamp="t1", level="INFO", message="test"))
        result = store.query()
        assert result["total"] == 1
        store.shutdown()


# ── LogCapture handler ───────────────────────────────────────────────────────


class TestLogCapture:
    def test_captures_log_records(self) -> None:
        config = LogStoreConfig(enabled=True, bucket="", buffer_size=100)
        store = LogStore(config)
        handler = LogCapture(store)
        handler.setLevel(logging.DEBUG)

        logger = logging.getLogger("test.capture")
        logger.addHandler(handler)
        logger.setLevel(logging.DEBUG)

        logger.info("Test log message")

        result = store.query()
        assert result["total"] >= 1
        messages = [r["message"] for r in result["logs"]]
        assert "Test log message" in messages

        logger.removeHandler(handler)
        store.shutdown()

    def test_captures_extra_fields(self) -> None:
        config = LogStoreConfig(enabled=True, bucket="", buffer_size=100)
        store = LogStore(config)
        handler = LogCapture(store)
        handler.setLevel(logging.DEBUG)

        logger = logging.getLogger("test.capture.extra")
        logger.addHandler(handler)
        logger.setLevel(logging.DEBUG)

        logger.warning("Renewal failed", extra={"provider": "venafi", "cert_id": "abc123"})

        result = store.query()
        assert result["total"] >= 1
        entry = result["logs"][0]
        assert entry.get("provider") == "venafi"
        assert entry.get("cert_id") == "abc123"

        logger.removeHandler(handler)
        store.shutdown()
