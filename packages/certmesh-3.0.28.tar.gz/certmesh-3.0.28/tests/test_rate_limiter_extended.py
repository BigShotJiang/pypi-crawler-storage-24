"""Extended tests for certmesh.api.rate_limiter -- covering custom endpoint
limits, key function IP parsing, rate limit exceeded response format,
and per-endpoint limiting dispatch.
"""

from __future__ import annotations

from unittest.mock import MagicMock, patch

from fastapi import FastAPI, Request
from fastapi.testclient import TestClient
from limits import parse as parse_rate_limit
from limits.storage import MemoryStorage
from limits.strategies import MovingWindowRateLimiter

from certmesh.api.rate_limiter import (
    RateLimitConfig,
    _key_func,
    _PerEndpointLimiterMiddleware,
    build_rate_limit_config,
    register_rate_limiter,
)

# ── build_rate_limit_config ─────────────────────────────────────────────────


class TestBuildRateLimitConfigEndpointLimits:
    """Cover CSV parsing of CM_RATE_LIMIT_ENDPOINT_LIMITS."""

    def test_single_endpoint_limit(self, monkeypatch) -> None:
        monkeypatch.setenv(
            "CM_RATE_LIMIT_ENDPOINT_LIMITS",
            "/api/v1/acm/certificates=10/minute",
        )
        monkeypatch.delenv("CM_RATE_LIMIT_EXEMPT_PATHS", raising=False)
        monkeypatch.delenv("CM_RATE_LIMIT_ENABLED", raising=False)
        monkeypatch.delenv("CM_RATE_LIMIT_DEFAULT", raising=False)
        monkeypatch.delenv("CM_RATE_LIMIT_BURST", raising=False)

        cfg = build_rate_limit_config()

        assert cfg.endpoint_limits is not None
        assert cfg.endpoint_limits["/api/v1/acm/certificates"] == "10/minute"

    def test_multiple_endpoint_limits(self, monkeypatch) -> None:
        monkeypatch.setenv(
            "CM_RATE_LIMIT_ENDPOINT_LIMITS",
            "/api/v1/acm=10/minute,/api/v1/venafi=50/minute",
        )
        monkeypatch.delenv("CM_RATE_LIMIT_EXEMPT_PATHS", raising=False)
        monkeypatch.delenv("CM_RATE_LIMIT_ENABLED", raising=False)
        monkeypatch.delenv("CM_RATE_LIMIT_DEFAULT", raising=False)
        monkeypatch.delenv("CM_RATE_LIMIT_BURST", raising=False)

        cfg = build_rate_limit_config()

        assert cfg.endpoint_limits is not None
        assert len(cfg.endpoint_limits) == 2
        assert cfg.endpoint_limits["/api/v1/acm"] == "10/minute"
        assert cfg.endpoint_limits["/api/v1/venafi"] == "50/minute"

    def test_malformed_entries_are_skipped(self, monkeypatch) -> None:
        """Entries without '=' or with empty key/value are skipped."""
        monkeypatch.setenv(
            "CM_RATE_LIMIT_ENDPOINT_LIMITS",
            "no-equals-sign,=10/minute,/valid=5/second",
        )
        monkeypatch.delenv("CM_RATE_LIMIT_EXEMPT_PATHS", raising=False)
        monkeypatch.delenv("CM_RATE_LIMIT_ENABLED", raising=False)
        monkeypatch.delenv("CM_RATE_LIMIT_DEFAULT", raising=False)
        monkeypatch.delenv("CM_RATE_LIMIT_BURST", raising=False)

        cfg = build_rate_limit_config()

        assert cfg.endpoint_limits is not None
        assert len(cfg.endpoint_limits) == 1
        assert cfg.endpoint_limits["/valid"] == "5/second"

    def test_empty_endpoint_limits_returns_none(self, monkeypatch) -> None:
        monkeypatch.setenv("CM_RATE_LIMIT_ENDPOINT_LIMITS", "")
        monkeypatch.delenv("CM_RATE_LIMIT_EXEMPT_PATHS", raising=False)
        monkeypatch.delenv("CM_RATE_LIMIT_ENABLED", raising=False)
        monkeypatch.delenv("CM_RATE_LIMIT_DEFAULT", raising=False)
        monkeypatch.delenv("CM_RATE_LIMIT_BURST", raising=False)

        cfg = build_rate_limit_config()

        assert cfg.endpoint_limits is None

    def test_custom_exempt_paths(self, monkeypatch) -> None:
        monkeypatch.setenv("CM_RATE_LIMIT_EXEMPT_PATHS", "/custom,/other")
        monkeypatch.delenv("CM_RATE_LIMIT_ENDPOINT_LIMITS", raising=False)
        monkeypatch.delenv("CM_RATE_LIMIT_ENABLED", raising=False)
        monkeypatch.delenv("CM_RATE_LIMIT_DEFAULT", raising=False)
        monkeypatch.delenv("CM_RATE_LIMIT_BURST", raising=False)

        cfg = build_rate_limit_config()

        assert cfg.exempt_paths == ("/custom", "/other")

    def test_empty_exempt_paths_means_none(self, monkeypatch) -> None:
        monkeypatch.setenv("CM_RATE_LIMIT_EXEMPT_PATHS", "")
        monkeypatch.delenv("CM_RATE_LIMIT_ENDPOINT_LIMITS", raising=False)
        monkeypatch.delenv("CM_RATE_LIMIT_ENABLED", raising=False)
        monkeypatch.delenv("CM_RATE_LIMIT_DEFAULT", raising=False)
        monkeypatch.delenv("CM_RATE_LIMIT_BURST", raising=False)

        cfg = build_rate_limit_config()

        assert cfg.exempt_paths == ()


# ── _key_func ────────────────────────────────────────────────────────────────


class TestKeyFunc:
    """Cover _key_func: X-Forwarded-For parsing with trusted proxies,
    X-Real-IP fallback, and plain remote address.
    """

    def _make_request(
        self,
        headers: dict[str, str] | None = None,
        client_host: str = "192.168.1.1",
    ) -> MagicMock:
        req = MagicMock(spec=Request)
        req.headers = headers or {}
        req.client = MagicMock()
        req.client.host = client_host
        return req

    @patch("certmesh.api.rate_limiter._TRUSTED_PROXY_COUNT", 1)
    def test_xff_single_ip(self) -> None:
        req = self._make_request(headers={"X-Forwarded-For": "10.0.0.1"})
        assert _key_func(req) == "10.0.0.1"

    @patch("certmesh.api.rate_limiter._TRUSTED_PROXY_COUNT", 1)
    def test_xff_multiple_ips_uses_rightmost(self) -> None:
        req = self._make_request(headers={"X-Forwarded-For": "spoofed.ip, 10.0.0.2, 10.0.0.3"})
        # With trusted_proxy_count=1, picks parts[-1] = "10.0.0.3"
        assert _key_func(req) == "10.0.0.3"

    @patch("certmesh.api.rate_limiter._TRUSTED_PROXY_COUNT", 2)
    def test_xff_trusted_proxy_count_2(self) -> None:
        req = self._make_request(headers={"X-Forwarded-For": "client.ip, proxy1.ip, proxy2.ip"})
        # With trusted_proxy_count=2, picks parts[-2] = "proxy1.ip"
        assert _key_func(req) == "proxy1.ip"

    @patch("certmesh.api.rate_limiter._TRUSTED_PROXY_COUNT", 10)
    def test_xff_trusted_count_exceeds_parts(self) -> None:
        req = self._make_request(headers={"X-Forwarded-For": "10.0.0.1, 10.0.0.2"})
        # min(10, 2) = 2, parts[-2] = "10.0.0.1"
        assert _key_func(req) == "10.0.0.1"

    def test_x_real_ip_fallback(self) -> None:
        req = self._make_request(headers={"X-Real-IP": "172.16.0.5"})
        assert _key_func(req) == "172.16.0.5"

    @patch("certmesh.api.rate_limiter.get_remote_address", return_value="127.0.0.1")
    def test_plain_remote_address_fallback(self, mock_gra: MagicMock) -> None:
        req = self._make_request(headers={})
        result = _key_func(req)
        assert result == "127.0.0.1"
        mock_gra.assert_called_once_with(req)


# ── Rate limit exceeded handler ──────────────────────────────────────────────


class TestRateLimitExceededHandler:
    """Cover the exception handler response format and Retry-After header."""

    def _build_app(self) -> FastAPI:
        app = FastAPI()
        config = RateLimitConfig(
            enabled=True,
            default_limit="1/minute",
            burst_limit="1/second",
            exempt_paths=(),
            endpoint_limits=None,
        )
        register_rate_limiter(app, config)

        @app.get("/test")
        def test_endpoint() -> dict:
            return {"ok": True}

        return app

    def test_rate_limit_response_format(self) -> None:
        app = self._build_app()
        client = TestClient(app)

        # First request should succeed
        resp1 = client.get("/test")
        assert resp1.status_code == 200

        # Second request should be rate-limited (limit is 1/minute)
        resp2 = client.get("/test")
        assert resp2.status_code == 429

        body = resp2.json()
        assert body["error"] == "too_many_requests"
        assert "detail" in body
        assert "retry_after_seconds" in body
        assert body["retry_after_seconds"] == 60

    def test_retry_after_header_present(self) -> None:
        app = self._build_app()
        client = TestClient(app)

        client.get("/test")  # first (allowed)
        resp = client.get("/test")  # second (blocked)

        assert resp.status_code == 429
        assert resp.headers.get("Retry-After") == "60"

    def test_request_id_in_response(self) -> None:
        app = self._build_app()
        client = TestClient(app)

        client.get("/test")
        resp = client.get("/test")

        assert resp.status_code == 429
        assert "X-Request-ID" in resp.headers


# ── Per-endpoint limiting dispatch ───────────────────────────────────────────


class TestPerEndpointLimiting:
    """Cover _PerEndpointLimiterMiddleware dispatch via unit and integration tests."""

    def test_middleware_initialises_with_parsed_limits(self) -> None:
        """Verify _PerEndpointLimiterMiddleware pre-parses limit strings."""
        app = MagicMock()
        middleware = _PerEndpointLimiterMiddleware(
            app,
            key_func=_key_func,
            endpoint_limits={
                "/api/v1/acm": "10/minute",
                "/api/v1/venafi": "50/minute",
            },
        )
        assert len(middleware._limits) == 2
        prefixes = [prefix for prefix, _item in middleware._limits]
        assert "/api/v1/acm" in prefixes
        assert "/api/v1/venafi" in prefixes

    def test_window_hit_returns_false_when_limit_exhausted(self) -> None:
        """Verify MovingWindowRateLimiter rejects requests after limit is hit."""
        storage = MemoryStorage()
        window = MovingWindowRateLimiter(storage)
        limit_item = parse_rate_limit("1/minute")

        # First hit should succeed
        assert window.hit(limit_item, "test-client", "/api") is True
        # Second hit should fail (limit exhausted)
        assert window.hit(limit_item, "test-client", "/api") is False

    def test_matching_prefix_passes_first_request(self) -> None:
        """A request matching a per-endpoint prefix passes on the first hit."""
        app = FastAPI()
        config = RateLimitConfig(
            enabled=True,
            default_limit="1000/minute",
            burst_limit="1000/second",
            exempt_paths=(),
            endpoint_limits={"/api/v1/acm": "1000/minute"},
        )
        register_rate_limiter(app, config)

        @app.get("/api/v1/acm/certs")
        def acm_certs() -> dict:
            return {"ok": True}

        client = TestClient(app)
        resp = client.get("/api/v1/acm/certs")
        assert resp.status_code == 200

    def test_non_matching_prefix_passes_through(self) -> None:
        """Requests to paths not matching any prefix use the global limit only."""
        app = FastAPI()
        config = RateLimitConfig(
            enabled=True,
            default_limit="1000/minute",
            burst_limit="1000/second",
            exempt_paths=(),
            endpoint_limits={"/limited": "1/minute"},
        )
        register_rate_limiter(app, config)

        @app.get("/unlimited")
        def unlimited_endpoint() -> dict:
            return {"ok": True}

        client = TestClient(app)

        # Multiple requests to /unlimited should all pass (high global limit)
        resp1 = client.get("/unlimited")
        assert resp1.status_code == 200

        resp2 = client.get("/unlimited")
        assert resp2.status_code == 200

    def test_exempt_path_bypasses_per_endpoint_limit(self) -> None:
        app = FastAPI()
        config = RateLimitConfig(
            enabled=True,
            default_limit="1000/minute",
            burst_limit="1000/second",
            exempt_paths=("/healthz",),
            endpoint_limits={"/healthz": "1/minute"},
        )
        register_rate_limiter(app, config)

        @app.get("/healthz")
        def healthz() -> dict:
            return {"status": "ok"}

        client = TestClient(app)

        # Health endpoint should never be rate-limited even though there is
        # a per-endpoint rule, because the exempt-paths middleware runs first.
        resp1 = client.get("/healthz")
        assert resp1.status_code == 200

        resp2 = client.get("/healthz")
        assert resp2.status_code == 200
