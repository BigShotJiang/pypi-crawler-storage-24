"""Tests for certmesh.api.auth -- OAuth2 JWT Bearer token validation.

Covers ``_fetch_jwks``, ``_extract_jwk``, ``_decode_jwt``, ``_extract_scopes``,
``_validate_token``, ``OAuth2Config``, and ``JWTBearer`` to achieve high branch
coverage of ``certmesh.api.auth``.
"""

from __future__ import annotations

import time
from typing import Any
from unittest.mock import MagicMock, patch

import httpx
import jwt as pyjwt
import pytest
from cryptography.hazmat.primitives.asymmetric import rsa
from cryptography.hazmat.primitives.serialization import (
    Encoding,
    NoEncryption,
    PrivateFormat,
)
from fastapi import HTTPException

from certmesh.api.auth import (
    JWTBearer,
    OAuth2Config,
    _decode_jwt,
    _extract_jwk,
    _extract_scopes,
    _fetch_jwks,
    _validate_token,
)

# ---------------------------------------------------------------------------
# Fixtures & helpers
# ---------------------------------------------------------------------------

_TEST_ISSUER = "https://idp.example.com"
_TEST_AUDIENCE = "certmesh-api"


def _generate_rsa_key_pair() -> tuple[rsa.RSAPrivateKey, dict[str, Any]]:
    """Generate an RSA key pair and return (private_key, jwk_dict)."""
    private_key = rsa.generate_private_key(public_exponent=65537, key_size=2048)
    from jwt.algorithms import RSAAlgorithm

    pub_jwk: dict[str, Any] = RSAAlgorithm.to_jwk(
        private_key.public_key(),
        as_dict=True,
    )  # type: ignore[arg-type]
    pub_jwk["kid"] = "test-kid-1"
    pub_jwk["use"] = "sig"
    return private_key, pub_jwk


def _make_jwks(*keys: dict[str, Any]) -> dict[str, Any]:
    return {"keys": list(keys)}


def _sign_jwt(
    private_key: rsa.RSAPrivateKey,
    kid: str = "test-kid-1",
    claims: dict[str, Any] | None = None,
    expired: bool = False,
) -> str:
    now = int(time.time())
    payload: dict[str, Any] = {
        "iss": _TEST_ISSUER,
        "aud": _TEST_AUDIENCE,
        "sub": "user@example.com",
        "iat": now - 60,
        "exp": (now - 120) if expired else (now + 3600),
        **(claims or {}),
    }
    return pyjwt.encode(
        payload,
        private_key.private_bytes(Encoding.PEM, PrivateFormat.PKCS8, NoEncryption()),
        algorithm="RS256",
        headers={"kid": kid},
    )


def _make_config(**overrides: Any) -> OAuth2Config:
    defaults: dict[str, Any] = {
        "enabled": True,
        "issuer_url": _TEST_ISSUER,
        "audience": _TEST_AUDIENCE,
        "jwks_uri": "https://idp.example.com/.well-known/jwks.json",
        "accepted_scopes": [],
    }
    defaults.update(overrides)
    return OAuth2Config(**defaults)


@pytest.fixture(autouse=True)
def _reset_jwks_cache() -> None:
    """Clear the module-level JWKS cache before each test."""
    import certmesh.api.auth as auth_mod

    auth_mod._jwks_cache = {}
    auth_mod._jwks_cache_time = 0.0


# ---------------------------------------------------------------------------
# OAuth2Config.effective_jwks_uri
# ---------------------------------------------------------------------------


class TestOAuth2ConfigEffectiveJWKSUri:
    def test_explicit_jwks_uri_takes_precedence(self) -> None:
        cfg = OAuth2Config(jwks_uri="https://custom/keys", issuer_url="https://issuer")
        assert cfg.effective_jwks_uri() == "https://custom/keys"

    def test_generic_provider(self) -> None:
        cfg = OAuth2Config(issuer_url="https://issuer", provider_hint="generic")
        assert cfg.effective_jwks_uri() == "https://issuer/.well-known/jwks.json"

    def test_adfs_provider(self) -> None:
        cfg = OAuth2Config(issuer_url="https://adfs.corp/adfs", provider_hint="adfs")
        assert cfg.effective_jwks_uri() == "https://adfs.corp/adfs/discovery/keys"

    def test_entra_id_provider(self) -> None:
        cfg = OAuth2Config(
            issuer_url="https://login.microsoftonline.com/tenant",
            provider_hint="entra_id",
        )
        uri = cfg.effective_jwks_uri()
        assert uri == "https://login.microsoftonline.com/tenant/discovery/v2.0/keys"

    def test_trailing_slash_stripped(self) -> None:
        cfg = OAuth2Config(issuer_url="https://issuer/", provider_hint="generic")
        assert cfg.effective_jwks_uri() == "https://issuer/.well-known/jwks.json"


class TestOAuth2ConfigDefaults:
    """Verify dataclass defaults are sensible."""

    def test_defaults(self) -> None:
        cfg = OAuth2Config()
        assert cfg.enabled is False
        assert cfg.issuer_url == ""
        assert cfg.audience == ""
        assert cfg.jwks_uri == ""
        assert cfg.accepted_scopes == []
        assert cfg.admin_scopes == []
        assert cfg.write_scopes == []
        assert cfg.provider_hint == "generic"


# ---------------------------------------------------------------------------
# _fetch_jwks
# ---------------------------------------------------------------------------

_JWKS_URI = "https://idp.example.com/.well-known/jwks.json"


class TestFetchJWKS:
    def test_cache_miss_fetches_from_network(self) -> None:
        jwks_data = _make_jwks({"kid": "k1", "kty": "RSA"})
        mock_resp = MagicMock()
        mock_resp.json.return_value = jwks_data
        mock_resp.raise_for_status = MagicMock()

        with patch("certmesh.api.auth.httpx.get", return_value=mock_resp) as mg:
            result = _fetch_jwks(_JWKS_URI)
            mg.assert_called_once()
            assert result == jwks_data

    def test_cache_hit_returns_cached(self) -> None:
        import certmesh.api.auth as auth_mod

        cached = _make_jwks({"kid": "cached", "kty": "RSA"})
        auth_mod._jwks_cache = cached
        auth_mod._jwks_cache_time = time.monotonic()

        with patch("certmesh.api.auth.httpx.get") as mg:
            result = _fetch_jwks(_JWKS_URI)
            mg.assert_not_called()
            assert result == cached

    def test_cache_ttl_expiry_refetches(self) -> None:
        import certmesh.api.auth as auth_mod

        old_data = _make_jwks({"kid": "old", "kty": "RSA"})
        auth_mod._jwks_cache = old_data
        auth_mod._jwks_cache_time = time.monotonic() - 3700

        new_data = _make_jwks({"kid": "new", "kty": "RSA"})
        mock_resp = MagicMock()
        mock_resp.json.return_value = new_data
        mock_resp.raise_for_status = MagicMock()

        with patch("certmesh.api.auth.httpx.get", return_value=mock_resp):
            result = _fetch_jwks(_JWKS_URI)
            assert result == new_data

    def test_force_refresh_throttled(self) -> None:
        import certmesh.api.auth as auth_mod

        cached = _make_jwks({"kid": "cached", "kty": "RSA"})
        auth_mod._jwks_cache = cached
        auth_mod._jwks_cache_time = time.monotonic()

        with patch("certmesh.api.auth.httpx.get") as mg:
            result = _fetch_jwks(_JWKS_URI, force=True)
            mg.assert_not_called()
            assert result == cached

    def test_force_refresh_allowed_after_interval(self) -> None:
        import certmesh.api.auth as auth_mod

        old_data = _make_jwks({"kid": "old", "kty": "RSA"})
        auth_mod._jwks_cache = old_data
        auth_mod._jwks_cache_time = time.monotonic() - 120

        new_data = _make_jwks({"kid": "new", "kty": "RSA"})
        mock_resp = MagicMock()
        mock_resp.json.return_value = new_data
        mock_resp.raise_for_status = MagicMock()

        with patch("certmesh.api.auth.httpx.get", return_value=mock_resp):
            result = _fetch_jwks(_JWKS_URI, force=True)
            assert result == new_data

    def test_http_error_raises_when_no_cache(self) -> None:
        mock_resp = MagicMock()
        mock_resp.status_code = 500
        exc = httpx.HTTPStatusError("Server Error", request=MagicMock(), response=mock_resp)
        mock_resp.raise_for_status.side_effect = exc

        with (
            patch("certmesh.api.auth.httpx.get", return_value=mock_resp),
            pytest.raises(httpx.HTTPStatusError),
        ):
            _fetch_jwks(_JWKS_URI)

    def test_http_error_returns_stale_cache(self) -> None:
        import certmesh.api.auth as auth_mod

        stale = _make_jwks({"kid": "stale", "kty": "RSA"})
        auth_mod._jwks_cache = stale
        auth_mod._jwks_cache_time = time.monotonic() - 3700

        mock_resp = MagicMock()
        mock_resp.status_code = 500
        exc = httpx.HTTPStatusError("Server Error", request=MagicMock(), response=mock_resp)
        mock_resp.raise_for_status.side_effect = exc

        with patch("certmesh.api.auth.httpx.get", return_value=mock_resp):
            result = _fetch_jwks(_JWKS_URI)
            assert result == stale

    def test_connect_error_raises_when_no_cache(self) -> None:
        with (
            patch("certmesh.api.auth.httpx.get", side_effect=httpx.ConnectError("refused")),
            pytest.raises(httpx.ConnectError),
        ):
            _fetch_jwks(_JWKS_URI)

    def test_connect_error_returns_stale_cache(self) -> None:
        import certmesh.api.auth as auth_mod

        stale = _make_jwks({"kid": "stale", "kty": "RSA"})
        auth_mod._jwks_cache = stale
        auth_mod._jwks_cache_time = time.monotonic() - 3700

        with patch("certmesh.api.auth.httpx.get", side_effect=httpx.ConnectError("refused")):
            result = _fetch_jwks(_JWKS_URI)
            assert result == stale

    def test_generic_exception_raises_when_no_cache(self) -> None:
        with (
            patch("certmesh.api.auth.httpx.get", side_effect=RuntimeError("unexpected")),
            pytest.raises(RuntimeError),
        ):
            _fetch_jwks(_JWKS_URI)

    def test_generic_exception_returns_stale_cache(self) -> None:
        import certmesh.api.auth as auth_mod

        stale = _make_jwks({"kid": "stale", "kty": "RSA"})
        auth_mod._jwks_cache = stale
        auth_mod._jwks_cache_time = time.monotonic() - 3700

        with patch("certmesh.api.auth.httpx.get", side_effect=RuntimeError("unexpected")):
            result = _fetch_jwks(_JWKS_URI)
            assert result == stale

    def test_double_check_under_lock_returns_cached(self) -> None:
        """Simulate another thread refreshing the cache between the
        fast-path check and the lock acquisition."""
        import certmesh.api.auth as auth_mod

        cached = _make_jwks({"kid": "lock-cached", "kty": "RSA"})
        auth_mod._jwks_cache = cached
        auth_mod._jwks_cache_time = time.monotonic() - 3601

        fresh = _make_jwks({"kid": "fresh", "kty": "RSA"})
        mock_resp = MagicMock()
        mock_resp.json.return_value = fresh
        mock_resp.raise_for_status = MagicMock()

        original_monotonic = time.monotonic
        call_count = 0

        def advancing_monotonic() -> float:
            nonlocal call_count
            call_count += 1
            if call_count == 2:
                auth_mod._jwks_cache_time = original_monotonic()
            return original_monotonic()

        with (
            patch("certmesh.api.auth.time.monotonic", side_effect=advancing_monotonic),
            patch("certmesh.api.auth.httpx.get", return_value=mock_resp) as mg,
        ):
            result = _fetch_jwks(_JWKS_URI)
            mg.assert_not_called()
            assert result == cached

    def test_successful_fetch_updates_cache_time(self) -> None:
        import certmesh.api.auth as auth_mod

        jwks_data = _make_jwks({"kid": "k1", "kty": "RSA"})
        mock_resp = MagicMock()
        mock_resp.json.return_value = jwks_data
        mock_resp.raise_for_status = MagicMock()

        with patch("certmesh.api.auth.httpx.get", return_value=mock_resp):
            _fetch_jwks(_JWKS_URI)
            assert auth_mod._jwks_cache_time > 0


# ---------------------------------------------------------------------------
# _extract_jwk
# ---------------------------------------------------------------------------


class TestExtractJWK:
    def test_matching_kid_returned(self) -> None:
        jwks = _make_jwks({"kid": "k1", "kty": "RSA", "n": "abc", "e": "AQAB", "use": "sig"})
        result = _extract_jwk(jwks, "k1")
        assert result["kid"] == "k1"
        assert result["n"] == "abc"
        assert result["e"] == "AQAB"

    def test_no_matching_kid_returns_empty(self) -> None:
        jwks = _make_jwks({"kid": "k1", "kty": "RSA"})
        assert _extract_jwk(jwks, "nonexistent") == {}

    def test_non_rs256_algorithm_rejected(self) -> None:
        jwks = _make_jwks({"kid": "k1", "kty": "RSA", "alg": "HS256"})
        assert _extract_jwk(jwks, "k1") == {}

    def test_none_algorithm_rejected(self) -> None:
        jwks = _make_jwks({"kid": "k1", "kty": "RSA", "alg": "none"})
        assert _extract_jwk(jwks, "k1") == {}

    def test_rs256_algorithm_accepted(self) -> None:
        jwks = _make_jwks({"kid": "k1", "kty": "RSA", "alg": "RS256", "n": "n1", "e": "e1"})
        assert _extract_jwk(jwks, "k1")["kid"] == "k1"

    def test_absent_algorithm_accepted(self) -> None:
        jwks = _make_jwks({"kid": "k1", "kty": "RSA", "n": "n1", "e": "e1"})
        assert _extract_jwk(jwks, "k1")["kid"] == "k1"

    def test_x5c_field_preserved(self) -> None:
        jwks = _make_jwks({"kid": "k1", "kty": "RSA", "x5c": ["cert1"], "n": "n1", "e": "e1"})
        assert _extract_jwk(jwks, "k1")["x5c"] == ["cert1"]

    def test_default_use_is_sig(self) -> None:
        jwks = _make_jwks({"kid": "k1", "kty": "RSA"})
        assert _extract_jwk(jwks, "k1")["use"] == "sig"

    def test_empty_keys_list(self) -> None:
        assert _extract_jwk({"keys": []}, "k1") == {}

    def test_missing_keys_key(self) -> None:
        assert _extract_jwk({}, "k1") == {}

    def test_kid_none_matches_key_with_none_kid(self) -> None:
        jwks = _make_jwks({"kid": None, "kty": "RSA", "n": "n1", "e": "e1"})
        assert _extract_jwk(jwks, None)["kty"] == "RSA"

    def test_multiple_keys_selects_correct_one(self) -> None:
        jwks = _make_jwks(
            {"kid": "k1", "kty": "RSA", "n": "n1", "e": "e1"},
            {"kid": "k2", "kty": "RSA", "n": "n2", "e": "e2"},
        )
        result = _extract_jwk(jwks, "k2")
        assert result["kid"] == "k2"
        assert result["n"] == "n2"

    def test_first_matching_kid_wins_when_duplicates(self) -> None:
        jwks = _make_jwks(
            {"kid": "k1", "kty": "RSA", "n": "first", "e": "e1"},
            {"kid": "k1", "kty": "RSA", "n": "second", "e": "e2"},
        )
        assert _extract_jwk(jwks, "k1")["n"] == "first"

    def test_skips_non_rs256_returns_next_matching(self) -> None:
        jwks = _make_jwks(
            {"kid": "k1", "kty": "RSA", "alg": "HS256", "n": "bad", "e": "e1"},
            {"kid": "k1", "kty": "RSA", "alg": "RS256", "n": "good", "e": "e2"},
        )
        assert _extract_jwk(jwks, "k1")["n"] == "good"

    def test_key_without_n_and_e(self) -> None:
        jwks = _make_jwks({"kid": "k1", "kty": "EC"})
        result = _extract_jwk(jwks, "k1")
        assert result == {"kty": "EC", "kid": "k1", "use": "sig"}
        assert "n" not in result


# ---------------------------------------------------------------------------
# _decode_jwt
# ---------------------------------------------------------------------------


class TestDecodeJWT:
    def test_valid_token_decoded(self) -> None:
        private_key, pub_jwk = _generate_rsa_key_pair()
        token = _sign_jwt(private_key)
        claims = _decode_jwt(token, pub_jwk, _make_config())
        assert claims["sub"] == "user@example.com"
        assert claims["iss"] == _TEST_ISSUER

    def test_expired_token_raises_401(self) -> None:
        private_key, pub_jwk = _generate_rsa_key_pair()
        token = _sign_jwt(private_key, expired=True)
        with pytest.raises(HTTPException) as exc_info:
            _decode_jwt(token, pub_jwk, _make_config())
        assert exc_info.value.status_code == 401
        assert "expired" in exc_info.value.detail.lower()

    def test_expired_token_has_www_authenticate_header(self) -> None:
        private_key, pub_jwk = _generate_rsa_key_pair()
        token = _sign_jwt(private_key, expired=True)
        with pytest.raises(HTTPException) as exc_info:
            _decode_jwt(token, pub_jwk, _make_config())
        assert exc_info.value.headers is not None
        assert "Bearer" in exc_info.value.headers["WWW-Authenticate"]

    def test_wrong_audience_raises_401(self) -> None:
        private_key, pub_jwk = _generate_rsa_key_pair()
        token = _sign_jwt(private_key, claims={"aud": "wrong-audience"})
        with pytest.raises(HTTPException) as exc_info:
            _decode_jwt(token, pub_jwk, _make_config())
        assert exc_info.value.status_code == 401

    def test_wrong_issuer_raises_401(self) -> None:
        private_key, pub_jwk = _generate_rsa_key_pair()
        token = _sign_jwt(private_key, claims={"iss": "https://evil.com"})
        with pytest.raises(HTTPException) as exc_info:
            _decode_jwt(token, pub_jwk, _make_config())
        assert exc_info.value.status_code == 401

    def test_invalid_token_detail_message(self) -> None:
        private_key, pub_jwk = _generate_rsa_key_pair()
        token = _sign_jwt(private_key, claims={"aud": "wrong"})
        with pytest.raises(HTTPException) as exc_info:
            _decode_jwt(token, pub_jwk, _make_config())
        assert exc_info.value.detail == "Token validation failed."

    def test_token_with_additional_claims(self) -> None:
        private_key, pub_jwk = _generate_rsa_key_pair()
        token = _sign_jwt(private_key, claims={"custom_field": "custom_value"})
        claims = _decode_jwt(token, pub_jwk, _make_config())
        assert claims["custom_field"] == "custom_value"


# ---------------------------------------------------------------------------
# _extract_scopes
# ---------------------------------------------------------------------------


class TestExtractScopes:
    def test_space_separated_string(self) -> None:
        assert _extract_scopes({"scope": "read write admin"}) == {"read", "write", "admin"}

    def test_list_of_scopes(self) -> None:
        assert _extract_scopes({"scope": ["read", "write"]}) == {"read", "write"}

    def test_scp_claim_fallback(self) -> None:
        assert _extract_scopes({"scp": "read write"}) == {"read", "write"}

    def test_empty_claims_returns_empty_set(self) -> None:
        assert _extract_scopes({}) == set()

    def test_scp_as_list(self) -> None:
        assert _extract_scopes({"scp": ["admin"]}) == {"admin"}

    def test_scope_takes_precedence_over_scp(self) -> None:
        result = _extract_scopes({"scope": "from-scope", "scp": "from-scp"})
        assert "from-scope" in result
        assert "from-scp" not in result

    def test_single_scope_string(self) -> None:
        assert _extract_scopes({"scope": "read"}) == {"read"}

    def test_empty_scope_string(self) -> None:
        assert _extract_scopes({"scope": ""}) == set()

    def test_empty_scp_string(self) -> None:
        assert _extract_scopes({"scp": ""}) == set()

    def test_scope_none_falls_back_to_scp(self) -> None:
        assert _extract_scopes({"scope": None, "scp": "fallback"}) == {"fallback"}

    def test_scope_empty_string_falls_back_to_scp(self) -> None:
        assert _extract_scopes({"scope": "", "scp": "backup"}) == {"backup"}


# ---------------------------------------------------------------------------
# _validate_token
# ---------------------------------------------------------------------------


class TestValidateToken:
    def test_valid_token_passes(self) -> None:
        private_key, pub_jwk = _generate_rsa_key_pair()
        token = _sign_jwt(private_key, claims={"scope": "read"})
        jwks = _make_jwks(pub_jwk)

        with patch("certmesh.api.auth._fetch_jwks", return_value=jwks):
            claims = _validate_token(token, _make_config(accepted_scopes=["read"]))
            assert claims["sub"] == "user@example.com"

    def test_insufficient_scopes_raises_403(self) -> None:
        private_key, pub_jwk = _generate_rsa_key_pair()
        token = _sign_jwt(private_key, claims={"scope": "read"})
        jwks = _make_jwks(pub_jwk)

        with (
            patch("certmesh.api.auth._fetch_jwks", return_value=jwks),
            pytest.raises(HTTPException) as exc_info,
        ):
            _validate_token(token, _make_config(accepted_scopes=["admin"]))
        assert exc_info.value.status_code == 403

    def test_insufficient_scopes_detail_message(self) -> None:
        private_key, pub_jwk = _generate_rsa_key_pair()
        token = _sign_jwt(private_key, claims={"scope": "read"})
        jwks = _make_jwks(pub_jwk)

        with (
            patch("certmesh.api.auth._fetch_jwks", return_value=jwks),
            pytest.raises(HTTPException) as exc_info,
        ):
            _validate_token(token, _make_config(accepted_scopes=["admin"]))
        assert "Insufficient scopes" in exc_info.value.detail
        assert "admin" in exc_info.value.detail
        assert "read" in exc_info.value.detail

    def test_insufficient_scopes_www_authenticate_header(self) -> None:
        private_key, pub_jwk = _generate_rsa_key_pair()
        token = _sign_jwt(private_key, claims={"scope": "read"})
        jwks = _make_jwks(pub_jwk)

        with (
            patch("certmesh.api.auth._fetch_jwks", return_value=jwks),
            pytest.raises(HTTPException) as exc_info,
        ):
            _validate_token(token, _make_config(accepted_scopes=["admin"]))
        assert exc_info.value.headers is not None
        assert "insufficient_scope" in exc_info.value.headers["WWW-Authenticate"]

    def test_or_semantics_any_scope_grants_access(self) -> None:
        private_key, pub_jwk = _generate_rsa_key_pair()
        token = _sign_jwt(private_key, claims={"scope": "write"})
        jwks = _make_jwks(pub_jwk)

        with patch("certmesh.api.auth._fetch_jwks", return_value=jwks):
            claims = _validate_token(
                token, _make_config(accepted_scopes=["read", "write", "admin"])
            )
            assert claims["sub"] == "user@example.com"

    def test_empty_accepted_scopes_skips_check(self) -> None:
        private_key, pub_jwk = _generate_rsa_key_pair()
        token = _sign_jwt(private_key)
        jwks = _make_jwks(pub_jwk)

        with patch("certmesh.api.auth._fetch_jwks", return_value=jwks):
            claims = _validate_token(token, _make_config(accepted_scopes=[]))
            assert claims is not None

    def test_invalid_header_raises_401(self) -> None:
        with (
            patch("certmesh.api.auth._fetch_jwks", return_value={"keys": []}),
            pytest.raises(HTTPException) as exc_info,
        ):
            _validate_token("not.a.jwt", _make_config())
        assert exc_info.value.status_code == 401
        assert "header" in exc_info.value.detail.lower()

    def test_key_rotation_triggers_refresh(self) -> None:
        private_key, pub_jwk = _generate_rsa_key_pair()
        token = _sign_jwt(private_key)
        empty_jwks = _make_jwks()
        full_jwks = _make_jwks(pub_jwk)

        call_count = 0

        def mock_fetch(uri: str, *, force: bool = False) -> dict[str, Any]:
            nonlocal call_count
            call_count += 1
            return full_jwks if force else empty_jwks

        with patch("certmesh.api.auth._fetch_jwks", side_effect=mock_fetch):
            claims = _validate_token(token, _make_config())
            assert claims["sub"] == "user@example.com"
            assert call_count == 2

    def test_no_matching_key_after_refresh_raises_401(self) -> None:
        private_key, _pub_jwk = _generate_rsa_key_pair()
        token = _sign_jwt(private_key)
        empty_jwks = _make_jwks()

        with (
            patch("certmesh.api.auth._fetch_jwks", return_value=empty_jwks),
            pytest.raises(HTTPException) as exc_info,
        ):
            _validate_token(token, _make_config())
        assert exc_info.value.status_code == 401
        assert "key" in exc_info.value.detail.lower()

    def test_scope_check_uses_client_id_when_no_sub(self) -> None:
        private_key, pub_jwk = _generate_rsa_key_pair()
        token = _sign_jwt(
            private_key,
            claims={"scope": "other", "client_id": "my-app"},
        )
        jwks = _make_jwks(pub_jwk)

        with (
            patch("certmesh.api.auth._fetch_jwks", return_value=jwks),
            pytest.raises(HTTPException) as exc_info,
        ):
            _validate_token(token, _make_config(accepted_scopes=["admin"]))
        assert exc_info.value.status_code == 403

    def test_uses_effective_jwks_uri(self) -> None:
        private_key, pub_jwk = _generate_rsa_key_pair()
        token = _sign_jwt(private_key)
        jwks = _make_jwks(pub_jwk)

        with patch("certmesh.api.auth._fetch_jwks", return_value=jwks) as mf:
            _validate_token(token, _make_config(jwks_uri="", provider_hint="adfs"))
            assert "discovery/keys" in mf.call_args[0][0]

    def test_valid_token_returns_all_standard_claims(self) -> None:
        private_key, pub_jwk = _generate_rsa_key_pair()
        token = _sign_jwt(private_key, claims={"scope": "read"})
        jwks = _make_jwks(pub_jwk)

        with patch("certmesh.api.auth._fetch_jwks", return_value=jwks):
            claims = _validate_token(token, _make_config(accepted_scopes=["read"]))
            assert claims["sub"] == "user@example.com"
            assert claims["iss"] == _TEST_ISSUER


# ---------------------------------------------------------------------------
# JWTBearer.__call__
# ---------------------------------------------------------------------------


class TestJWTBearer:
    @pytest.mark.anyio
    async def test_disabled_oauth2_returns_none(self) -> None:
        config = _make_config(enabled=False)
        bearer = JWTBearer(config)
        request = MagicMock()
        request.url.path = "/test"
        result = await bearer(request)
        assert result is None

    @pytest.mark.anyio
    async def test_enabled_oauth2_validates_token(self) -> None:
        bearer = JWTBearer(_make_config(enabled=True, accepted_scopes=["read"]))

        mock_creds = MagicMock()
        mock_creds.credentials = "some.jwt.token"

        request = MagicMock()
        request.url.path = "/test"
        request.state = MagicMock()

        claims = {"sub": "user@example.com", "scope": "read"}
        with (
            patch("certmesh.api.auth._validate_token", return_value=claims),
            patch("fastapi.security.HTTPBearer.__call__", return_value=mock_creds),
        ):
            result = await bearer(request)
            assert result == claims
            assert request.state.oauth2_claims == claims
            assert request.state.auth_method == "jwt"

    @pytest.mark.anyio
    async def test_missing_credentials_raises_401(self) -> None:
        bearer = JWTBearer(_make_config(enabled=True))

        request = MagicMock()
        request.url.path = "/test"
        request.client = MagicMock()
        request.client.host = "127.0.0.1"

        with (
            patch("fastapi.security.HTTPBearer.__call__", return_value=None),
            pytest.raises(HTTPException) as exc_info,
        ):
            await bearer(request)
        assert exc_info.value.status_code == 401

    @pytest.mark.anyio
    async def test_missing_credentials_no_client(self) -> None:
        bearer = JWTBearer(_make_config(enabled=True))

        request = MagicMock()
        request.url.path = "/test"
        request.client = None

        with (
            patch("fastapi.security.HTTPBearer.__call__", return_value=None),
            pytest.raises(HTTPException) as exc_info,
        ):
            await bearer(request)
        assert exc_info.value.status_code == 401

    @pytest.mark.anyio
    async def test_missing_credentials_detail_message(self) -> None:
        bearer = JWTBearer(_make_config(enabled=True))

        request = MagicMock()
        request.url.path = "/test"
        request.client = MagicMock()
        request.client.host = "10.0.0.1"

        with (
            patch("fastapi.security.HTTPBearer.__call__", return_value=None),
            pytest.raises(HTTPException) as exc_info,
        ):
            await bearer(request)
        assert "Missing authorization header" in exc_info.value.detail

    @pytest.mark.anyio
    async def test_validate_token_error_propagates(self) -> None:
        bearer = JWTBearer(_make_config(enabled=True))

        mock_creds = MagicMock()
        mock_creds.credentials = "some.jwt.token"

        request = MagicMock()
        request.url.path = "/api/v1/certs"
        request.state = MagicMock()

        with (
            patch("fastapi.security.HTTPBearer.__call__", return_value=mock_creds),
            patch(
                "certmesh.api.auth._validate_token",
                side_effect=HTTPException(status_code=401, detail="bad token"),
            ),
            pytest.raises(HTTPException) as exc_info,
        ):
            await bearer(request)
        assert exc_info.value.status_code == 401

    @pytest.mark.anyio
    async def test_bearer_passes_auto_error_true(self) -> None:
        bearer = JWTBearer(_make_config(enabled=True))
        assert bearer.auto_error is True
