"""Tests for certmesh.api.dashboard_state module."""

from __future__ import annotations

import json
import threading
import time
from unittest.mock import MagicMock, patch

import pytest

from certmesh.api.dashboard_state import (
    CertificateSnapshot,
    DashboardStateConfig,
    DashboardStateStore,
    RenewalHistoryEntry,
    build_dashboard_state_config,
)

# =============================================================================
# DashboardStateConfig
# =============================================================================


class TestDashboardStateConfig:
    """Tests for DashboardStateConfig dataclass."""

    def test_defaults(self) -> None:
        cfg = DashboardStateConfig()
        assert cfg.bucket == ""
        assert cfg.prefix == "certmesh/dashboard/"
        assert cfg.region == ""
        assert cfg.endpoint_url == ""

    def test_custom_values(self) -> None:
        cfg = DashboardStateConfig(bucket="my-bucket", prefix="custom/", region="eu-west-1")
        assert cfg.bucket == "my-bucket"
        assert cfg.prefix == "custom/"
        assert cfg.region == "eu-west-1"

    def test_custom_endpoint_url(self) -> None:
        cfg = DashboardStateConfig(
            bucket="my-bucket",
            endpoint_url="https://vpce-0abc123.s3.eu-west-2.vpce.amazonaws.com",
        )
        assert cfg.endpoint_url == "https://vpce-0abc123.s3.eu-west-2.vpce.amazonaws.com"

    def test_kms_key_id_default(self) -> None:
        cfg = DashboardStateConfig()
        assert cfg.kms_key_id == ""

    def test_kms_key_id_custom(self) -> None:
        cfg = DashboardStateConfig(
            bucket="my-bucket",
            kms_key_id="arn:aws:kms:eu-west-2:123456789:key/abcd-1234",
        )
        assert cfg.kms_key_id == "arn:aws:kms:eu-west-2:123456789:key/abcd-1234"


# =============================================================================
# build_dashboard_state_config
# =============================================================================


class TestBuildDashboardStateConfig:
    """Tests for building config from environment variables."""

    def test_defaults_when_no_env(self, monkeypatch: pytest.MonkeyPatch) -> None:
        monkeypatch.delenv("CM_DASHBOARD_S3_BUCKET", raising=False)
        monkeypatch.delenv("CM_DASHBOARD_S3_PREFIX", raising=False)
        monkeypatch.delenv("CM_DASHBOARD_S3_REGION", raising=False)
        monkeypatch.delenv("CM_DASHBOARD_S3_ENDPOINT_URL", raising=False)
        cfg = build_dashboard_state_config()
        assert cfg.bucket == ""
        assert cfg.prefix == "certmesh/dashboard/"
        assert cfg.region == ""
        assert cfg.endpoint_url == ""

    def test_reads_env_vars(self, monkeypatch: pytest.MonkeyPatch) -> None:
        monkeypatch.setenv("CM_DASHBOARD_S3_BUCKET", "test-bucket")
        monkeypatch.setenv("CM_DASHBOARD_S3_PREFIX", "state/")
        monkeypatch.setenv("CM_DASHBOARD_S3_REGION", "us-west-2")
        cfg = build_dashboard_state_config()
        assert cfg.bucket == "test-bucket"
        assert cfg.prefix == "state/"
        assert cfg.region == "us-west-2"

    def test_reads_endpoint_url_env(self, monkeypatch: pytest.MonkeyPatch) -> None:
        monkeypatch.setenv("CM_DASHBOARD_S3_BUCKET", "test-bucket")
        monkeypatch.setenv("CM_DASHBOARD_S3_ENDPOINT_URL", "https://minio:9000")
        cfg = build_dashboard_state_config()
        assert cfg.endpoint_url == "https://minio:9000"

    def test_reads_kms_key_id_env(self, monkeypatch: pytest.MonkeyPatch) -> None:
        monkeypatch.setenv("CM_DASHBOARD_S3_BUCKET", "test-bucket")
        monkeypatch.setenv("CM_DASHBOARD_S3_KMS_KEY_ID", "arn:aws:kms:eu-west-2:123:key/abc")
        cfg = build_dashboard_state_config()
        assert cfg.kms_key_id == "arn:aws:kms:eu-west-2:123:key/abc"

    def test_partial_env(self, monkeypatch: pytest.MonkeyPatch) -> None:
        monkeypatch.setenv("CM_DASHBOARD_S3_BUCKET", "b")
        monkeypatch.delenv("CM_DASHBOARD_S3_PREFIX", raising=False)
        monkeypatch.delenv("CM_DASHBOARD_S3_REGION", raising=False)
        monkeypatch.delenv("CM_DASHBOARD_S3_ENDPOINT_URL", raising=False)
        cfg = build_dashboard_state_config()
        assert cfg.bucket == "b"
        assert cfg.prefix == "certmesh/dashboard/"
        assert cfg.region == ""
        assert cfg.endpoint_url == ""


# =============================================================================
# DashboardStateStore — in-memory (no S3)
# =============================================================================


class TestDashboardStateStoreInMemory:
    """Tests for DashboardStateStore without S3 (in-memory only)."""

    @pytest.fixture()
    def store(self) -> DashboardStateStore:
        cfg = DashboardStateConfig(bucket="")
        return DashboardStateStore(cfg)

    def test_init_no_s3(self, store: DashboardStateStore) -> None:
        assert store.is_s3_available is False
        assert store._s3_client is None

    def test_get_missing_returns_default(self, store: DashboardStateStore) -> None:
        assert store.get("nonexistent") is None
        assert store.get("nonexistent", "fallback") == "fallback"

    def test_put_and_get(self, store: DashboardStateStore) -> None:
        store.put("key1", {"status": "ok"})
        assert store.get("key1") == {"status": "ok"}

    def test_put_overwrites(self, store: DashboardStateStore) -> None:
        store.put("key1", "v1")
        store.put("key1", "v2")
        assert store.get("key1") == "v2"

    def test_delete_existing(self, store: DashboardStateStore) -> None:
        store.put("key1", "value")
        store.delete("key1")
        assert store.get("key1") is None

    def test_delete_nonexistent_no_error(self, store: DashboardStateStore) -> None:
        store.delete("missing")  # should not raise

    def test_list_keys_empty(self, store: DashboardStateStore) -> None:
        assert store.list_keys() == []

    def test_list_keys_with_data(self, store: DashboardStateStore) -> None:
        store.put("alpha", 1)
        store.put("beta", 2)
        store.put("gamma", 3)
        keys = store.list_keys()
        assert keys == ["alpha", "beta", "gamma"]

    def test_list_keys_with_prefix_filter(self, store: DashboardStateStore) -> None:
        store.put("cert_a", 1)
        store.put("cert_b", 2)
        store.put("renewal_a", 3)
        assert store.list_keys("cert") == ["cert_a", "cert_b"]
        assert store.list_keys("renewal") == ["renewal_a"]
        assert store.list_keys("nonexistent") == []

    def test_put_various_types(self, store: DashboardStateStore) -> None:
        store.put("str_val", "hello")
        store.put("int_val", 42)
        store.put("list_val", [1, 2, 3])
        store.put("nested", {"a": {"b": "c"}})
        assert store.get("str_val") == "hello"
        assert store.get("int_val") == 42
        assert store.get("list_val") == [1, 2, 3]
        assert store.get("nested") == {"a": {"b": "c"}}


# =============================================================================
# DashboardStateStore — S3 initialization
# =============================================================================


class TestDashboardStateStoreS3Init:
    """Tests for S3 initialization and graceful degradation."""

    def test_s3_init_success(self) -> None:
        mock_boto3 = MagicMock()
        mock_client = MagicMock()
        mock_boto3.client.return_value = mock_client
        with patch.dict(
            "sys.modules",
            {"boto3": mock_boto3, "botocore": MagicMock(), "botocore.config": MagicMock()},
        ):
            cfg = DashboardStateConfig(bucket="my-bucket", prefix="pfx/")
            store = DashboardStateStore(cfg)
            assert store.is_s3_available is True
            mock_boto3.client.assert_called_once()
            call_kwargs = mock_boto3.client.call_args
            assert call_kwargs[0][0] == "s3"
            assert "config" in call_kwargs[1]
            mock_client.head_bucket.assert_called_once_with(Bucket="my-bucket")

    def test_s3_init_with_region(self) -> None:
        mock_boto3 = MagicMock()
        mock_client = MagicMock()
        mock_boto3.client.return_value = mock_client
        with patch.dict(
            "sys.modules",
            {"boto3": mock_boto3, "botocore": MagicMock(), "botocore.config": MagicMock()},
        ):
            cfg = DashboardStateConfig(bucket="b", region="ap-southeast-1")
            store = DashboardStateStore(cfg)
            assert store.is_s3_available is True
            mock_boto3.client.assert_called_once()
            call_kwargs = mock_boto3.client.call_args
            assert call_kwargs[0][0] == "s3"
            assert call_kwargs[1]["region_name"] == "ap-southeast-1"
            assert "config" in call_kwargs[1]

    def test_s3_init_head_bucket_fails(self) -> None:
        mock_boto3 = MagicMock()
        mock_client = MagicMock()
        mock_client.head_bucket.side_effect = Exception("access denied")
        mock_boto3.client.return_value = mock_client
        with patch.dict("sys.modules", {"boto3": mock_boto3}):
            cfg = DashboardStateConfig(bucket="bad-bucket")
            store = DashboardStateStore(cfg)
            assert store.is_s3_available is False

    def test_s3_init_boto3_import_fails(self) -> None:
        # Remove boto3 from sys.modules so the import fails inside __init__
        with patch.dict("sys.modules", {"boto3": None}):
            cfg = DashboardStateConfig(bucket="bucket")
            store = DashboardStateStore(cfg)
            assert store.is_s3_available is False

    def test_sse_kwargs_default_aes256(self) -> None:
        cfg = DashboardStateConfig(bucket="b")
        store = DashboardStateStore.__new__(DashboardStateStore)
        store._config = cfg
        assert store._sse_kwargs() == {"ServerSideEncryption": "AES256"}

    def test_sse_kwargs_kms(self) -> None:
        cfg = DashboardStateConfig(
            bucket="b",
            kms_key_id="arn:aws:kms:eu-west-2:123:key/abc",
        )
        store = DashboardStateStore.__new__(DashboardStateStore)
        store._config = cfg
        assert store._sse_kwargs() == {
            "ServerSideEncryption": "aws:kms",
            "SSEKMSKeyId": "arn:aws:kms:eu-west-2:123:key/abc",
        }


# =============================================================================
# DashboardStateStore — S3 operations (mocked)
# =============================================================================


class TestDashboardStateStoreS3Ops:
    """Tests for S3-backed get/put/delete/list_keys operations."""

    @pytest.fixture()
    def s3_store(self) -> tuple[DashboardStateStore, MagicMock]:
        """Create a store with a mocked S3 client already connected."""
        cfg = DashboardStateConfig(bucket="test-bucket", prefix="certmesh/dashboard/")
        store = DashboardStateStore.__new__(DashboardStateStore)
        store._config = cfg
        store._lock = threading.Lock()
        store._cache = {}
        store._etags = {}
        store._cache_timestamps = {}
        store._cache_ttl = 5.0
        store._last_s3_check = 0.0
        mock_client = MagicMock()
        store._s3_client = mock_client
        store._s3_available = True
        return store, mock_client

    def test_s3_key_helper(self, s3_store: tuple[DashboardStateStore, MagicMock]) -> None:
        store, _ = s3_store
        assert store._s3_key("inventory") == "certmesh/dashboard/inventory.json"
        assert store._s3_key("sub/key") == "certmesh/dashboard/sub/key.json"

    def test_s3_key_strips_trailing_slash(self) -> None:
        cfg = DashboardStateConfig(bucket="b", prefix="pfx///")
        store = DashboardStateStore.__new__(DashboardStateStore)
        store._config = cfg
        assert store._s3_key("k") == "pfx/k.json"

    def test_put_writes_to_s3(self, s3_store: tuple[DashboardStateStore, MagicMock]) -> None:
        store, mock_client = s3_store
        store.put("snap", {"total": 5})
        mock_client.put_object.assert_called_once_with(
            Bucket="test-bucket",
            Key="certmesh/dashboard/snap.json",
            Body=json.dumps({"total": 5}, default=str).encode("utf-8"),
            ContentType="application/json",
            ServerSideEncryption="AES256",
        )
        assert store.get("snap") == {"total": 5}

    def test_put_s3_failure_keeps_cache(
        self, s3_store: tuple[DashboardStateStore, MagicMock]
    ) -> None:
        store, mock_client = s3_store
        mock_client.put_object.side_effect = Exception("S3 write error")
        store.put("mykey", "myval")
        # Value should still be in cache despite S3 failure
        assert store.get("mykey") == "myval"

    def test_get_from_s3_when_not_cached(
        self, s3_store: tuple[DashboardStateStore, MagicMock]
    ) -> None:
        store, mock_client = s3_store
        body_mock = MagicMock()
        body_mock.read.return_value = json.dumps({"data": 42}).encode("utf-8")
        mock_client.get_object.return_value = {"Body": body_mock}
        result = store.get("remote_key")
        assert result == {"data": 42}
        mock_client.get_object.assert_called_once_with(
            Bucket="test-bucket",
            Key="certmesh/dashboard/remote_key.json",
        )
        # Should now be cached
        assert store._cache["remote_key"] == {"data": 42}

    def test_get_cache_hit_skips_s3(self, s3_store: tuple[DashboardStateStore, MagicMock]) -> None:
        store, mock_client = s3_store
        store._cache["cached"] = "value"
        store._cache_timestamps["cached"] = time.monotonic()  # mark as fresh
        result = store.get("cached")
        assert result == "value"
        mock_client.get_object.assert_not_called()

    def test_get_s3_no_such_key(self, s3_store: tuple[DashboardStateStore, MagicMock]) -> None:
        store, mock_client = s3_store
        # Simulate NoSuchKey exception
        no_such_key_exc = type("NoSuchKey", (Exception,), {})
        mock_client.exceptions.NoSuchKey = no_such_key_exc
        mock_client.get_object.side_effect = no_such_key_exc("not found")
        result = store.get("missing", "default_val")
        assert result == "default_val"

    def test_get_s3_generic_failure(self, s3_store: tuple[DashboardStateStore, MagicMock]) -> None:
        store, mock_client = s3_store
        mock_client.exceptions.NoSuchKey = type("NoSuchKey", (Exception,), {})
        mock_client.get_object.side_effect = RuntimeError("network error")
        result = store.get("broken", "safe_default")
        assert result == "safe_default"

    def test_delete_calls_s3(self, s3_store: tuple[DashboardStateStore, MagicMock]) -> None:
        store, mock_client = s3_store
        store._cache["to_delete"] = "val"
        store.delete("to_delete")
        assert "to_delete" not in store._cache
        mock_client.delete_object.assert_called_once_with(
            Bucket="test-bucket",
            Key="certmesh/dashboard/to_delete.json",
        )

    def test_delete_s3_failure_still_removes_cache(
        self, s3_store: tuple[DashboardStateStore, MagicMock]
    ) -> None:
        store, mock_client = s3_store
        store._cache["k"] = "v"
        mock_client.delete_object.side_effect = Exception("S3 delete error")
        store.delete("k")
        assert "k" not in store._cache

    def test_list_keys_merges_cache_and_s3(
        self, s3_store: tuple[DashboardStateStore, MagicMock]
    ) -> None:
        store, mock_client = s3_store
        store._cache["local_key"] = "val"
        mock_client.list_objects_v2.return_value = {
            "Contents": [
                {"Key": "certmesh/dashboard/remote_a.json"},
                {"Key": "certmesh/dashboard/remote_b.json"},
            ],
        }
        keys = store.list_keys()
        assert keys == ["local_key", "remote_a", "remote_b"]

    def test_list_keys_no_duplicates(
        self, s3_store: tuple[DashboardStateStore, MagicMock]
    ) -> None:
        store, mock_client = s3_store
        store._cache["shared"] = "val"
        mock_client.list_objects_v2.return_value = {
            "Contents": [
                {"Key": "certmesh/dashboard/shared.json"},
                {"Key": "certmesh/dashboard/only_s3.json"},
            ],
        }
        keys = store.list_keys()
        assert keys == ["only_s3", "shared"]

    def test_list_keys_s3_failure_returns_cached_only(
        self, s3_store: tuple[DashboardStateStore, MagicMock]
    ) -> None:
        store, mock_client = s3_store
        store._cache["c1"] = 1
        mock_client.list_objects_v2.side_effect = Exception("S3 list error")
        keys = store.list_keys()
        assert keys == ["c1"]

    def test_list_keys_empty_s3_response(
        self, s3_store: tuple[DashboardStateStore, MagicMock]
    ) -> None:
        store, mock_client = s3_store
        mock_client.list_objects_v2.return_value = {}
        keys = store.list_keys()
        assert keys == []


# =============================================================================
# Thread safety
# =============================================================================


class TestDashboardStateStoreThreadSafety:
    """Basic thread safety tests."""

    def test_concurrent_put_and_get(self) -> None:
        cfg = DashboardStateConfig(bucket="")
        store = DashboardStateStore(cfg)
        errors: list[Exception] = []

        def writer(n: int) -> None:
            try:
                for i in range(50):
                    store.put(f"key_{n}_{i}", i)
            except Exception as e:  # noqa: BLE001 - thread-safety test; catch-all to detect any error
                errors.append(e)

        def reader(n: int) -> None:
            try:
                for i in range(50):
                    store.get(f"key_{n}_{i}")
            except Exception as e:  # noqa: BLE001 - thread-safety test; catch-all to detect any error
                errors.append(e)

        threads = []
        for n in range(4):
            threads.append(threading.Thread(target=writer, args=(n,)))
            threads.append(threading.Thread(target=reader, args=(n,)))
        for t in threads:
            t.start()
        for t in threads:
            t.join(timeout=10)

        assert errors == [], f"Thread errors: {errors}"

    def test_concurrent_delete(self) -> None:
        cfg = DashboardStateConfig(bucket="")
        store = DashboardStateStore(cfg)
        for i in range(100):
            store.put(f"k{i}", i)
        errors: list[Exception] = []

        def deleter(start: int, end: int) -> None:
            try:
                for i in range(start, end):
                    store.delete(f"k{i}")
            except Exception as e:  # noqa: BLE001 - thread-safety test; catch-all to detect any error
                errors.append(e)

        threads = [
            threading.Thread(target=deleter, args=(0, 50)),
            threading.Thread(target=deleter, args=(50, 100)),
        ]
        for t in threads:
            t.start()
        for t in threads:
            t.join(timeout=10)
        assert errors == []
        assert store.list_keys() == []


# =============================================================================
# Dataclass smoke tests
# =============================================================================


class TestDataclasses:
    """Smoke tests for CertificateSnapshot and RenewalHistoryEntry."""

    def test_certificate_snapshot_defaults(self) -> None:
        snap = CertificateSnapshot(provider="acm")
        assert snap.provider == "acm"
        assert snap.certificates == []
        assert snap.total == 0
        assert snap.expiring_soon == 0
        assert snap.expired == 0
        assert snap.errors == 0
        assert isinstance(snap.timestamp, float)

    def test_certificate_snapshot_custom(self) -> None:
        snap = CertificateSnapshot(
            provider="digicert",
            certificates=[{"id": "abc"}],
            total=1,
            expiring_soon=0,
            expired=0,
            errors=0,
            timestamp=1000.0,
        )
        assert snap.provider == "digicert"
        assert snap.certificates == [{"id": "abc"}]
        assert snap.timestamp == 1000.0

    def test_renewal_history_entry_defaults(self) -> None:
        entry = RenewalHistoryEntry(
            provider="vault",
            certificate_id="cert-123",
            action="renew",
            status="success",
        )
        assert entry.provider == "vault"
        assert entry.certificate_id == "cert-123"
        assert entry.action == "renew"
        assert entry.status == "success"
        assert entry.detail == ""
        assert entry.user == ""
        assert isinstance(entry.timestamp, float)

    def test_renewal_history_entry_custom(self) -> None:
        entry = RenewalHistoryEntry(
            provider="acm",
            certificate_id="c1",
            action="revoke",
            status="error",
            detail="timed out",
            user="admin",
            timestamp=2000.0,
        )
        assert entry.detail == "timed out"
        assert entry.user == "admin"
        assert entry.timestamp == 2000.0
