"""Extended tests for certmesh.renewal -- covering provider dispatch, ACM,
Vault PKI, Venafi error paths, summary logging, and pushgateway metrics push.
"""

from __future__ import annotations

from datetime import datetime, timedelta, timezone
from types import SimpleNamespace
from unittest.mock import MagicMock, patch

from certmesh.exceptions import ACMError, VaultError, VenafiError
from certmesh.renewal import (
    RenewalPolicy,
    RenewalResult,
    _check_acm,
    _check_provider,
    _check_vault_pki,
    _check_venafi,
    check_and_renew,
)

# ── Helpers ──────────────────────────────────────────────────────────────────


def _expiring_soon() -> datetime:
    """Return a datetime 5 days from now (within the default 30-day window)."""
    return datetime.now(timezone.utc) + timedelta(days=5)


def _far_future() -> datetime:
    """Return a datetime 365 days from now (outside the default window)."""
    return datetime.now(timezone.utc) + timedelta(days=365)


def _policy(dry_run: bool = False) -> RenewalPolicy:
    return RenewalPolicy(before_expiry=30, unit="day", dry_run=dry_run)


# ── _check_provider dispatch ────────────────────────────────────────────────


class TestCheckProviderDispatch:
    """Verify _check_provider dispatches to the correct provider handler."""

    def _cfg_with(self, provider_key: str) -> dict:
        return {provider_key: {"enabled": True}}

    @patch("certmesh.renewal._check_acm", return_value=[])
    def test_dispatch_acm(self, mock_acm: MagicMock) -> None:
        results = _check_provider(self._cfg_with("acm"), "acm", _policy())
        mock_acm.assert_called_once()
        assert results == []

    @patch("certmesh.renewal._check_digicert", return_value=[])
    def test_dispatch_digicert(self, mock_dc: MagicMock) -> None:
        results = _check_provider(self._cfg_with("digicert"), "digicert", _policy())
        mock_dc.assert_called_once()
        assert results == []

    @patch("certmesh.renewal._check_venafi", return_value=[])
    def test_dispatch_venafi(self, mock_v: MagicMock) -> None:
        results = _check_provider(self._cfg_with("venafi"), "venafi", _policy())
        mock_v.assert_called_once()
        assert results == []

    @patch("certmesh.renewal._check_vault_pki", return_value=[])
    def test_dispatch_vault_pki(self, mock_vp: MagicMock) -> None:
        results = _check_provider(self._cfg_with("vault_pki"), "vault-pki", _policy())
        mock_vp.assert_called_once()
        assert results == []

    def test_unknown_provider_returns_empty(self) -> None:
        """An unknown provider should log a warning and return an empty list."""
        cfg = {"custom_ca": {"enabled": True}}
        results = _check_provider(cfg, "custom-ca", _policy())
        assert results == []

    def test_unconfigured_provider_returns_empty(self) -> None:
        """A provider with no configuration section should be skipped."""
        results = _check_provider({}, "acm", _policy())
        assert results == []


# ── _check_acm ───────────────────────────────────────────────────────────────


class TestCheckACM:
    """Cover _check_acm: list success, renewal, and renewal failure."""

    @patch("certmesh.providers.acm_client.list_certificates")
    def test_list_success_no_renewal_needed(self, mock_list: MagicMock) -> None:
        cert = SimpleNamespace(
            certificate_arn="arn:aws:acm:us-east-1:123:cert/abc",
            domain_name="example.com",
            not_after=_far_future(),
        )
        mock_list.return_value = [cert]

        results = _check_acm({"acm": {}}, _policy())

        assert len(results) == 1
        assert results[0].needs_renewal is False
        assert results[0].renewed is False

    @patch("certmesh.providers.acm_client.renew_certificate")
    @patch("certmesh.providers.acm_client.list_certificates")
    def test_renewal_when_not_dry_run(self, mock_list: MagicMock, mock_renew: MagicMock) -> None:
        cert = SimpleNamespace(
            certificate_arn="arn:aws:acm:us-east-1:123:cert/abc",
            domain_name="example.com",
            not_after=_expiring_soon(),
        )
        mock_list.return_value = [cert]

        results = _check_acm({"acm": {}}, _policy(dry_run=False))

        assert len(results) == 1
        assert results[0].needs_renewal is True
        assert results[0].renewed is True
        mock_renew.assert_called_once()

    @patch("certmesh.providers.acm_client.renew_certificate")
    @patch("certmesh.providers.acm_client.list_certificates")
    def test_dry_run_skips_renewal(self, mock_list: MagicMock, mock_renew: MagicMock) -> None:
        cert = SimpleNamespace(
            certificate_arn="arn:aws:acm:us-east-1:123:cert/abc",
            domain_name="example.com",
            not_after=_expiring_soon(),
        )
        mock_list.return_value = [cert]

        results = _check_acm({"acm": {}}, _policy(dry_run=True))

        assert len(results) == 1
        assert results[0].needs_renewal is True
        assert results[0].renewed is False
        mock_renew.assert_not_called()

    @patch("certmesh.providers.acm_client.renew_certificate")
    @patch("certmesh.providers.acm_client.list_certificates")
    def test_renewal_failure_records_error(
        self, mock_list: MagicMock, mock_renew: MagicMock
    ) -> None:
        cert = SimpleNamespace(
            certificate_arn="arn:aws:acm:us-east-1:123:cert/abc",
            domain_name="example.com",
            not_after=_expiring_soon(),
        )
        mock_list.return_value = [cert]
        mock_renew.side_effect = ACMError("throttled")

        results = _check_acm({"acm": {}}, _policy(dry_run=False))

        assert len(results) == 1
        assert results[0].needs_renewal is True
        assert results[0].renewed is False
        assert results[0].error == "throttled"

    @patch("certmesh.providers.acm_client.list_certificates")
    def test_list_failure_returns_error_result(self, mock_list: MagicMock) -> None:
        mock_list.side_effect = ACMError("access denied")

        results = _check_acm({"acm": {}}, _policy())

        assert len(results) == 1
        assert results[0].identifier == "*"
        assert results[0].error == "access denied"


# ── _check_vault_pki ────────────────────────────────────────────────────────


class TestCheckVaultPKI:
    """Cover _check_vault_pki: list failure, cert parse failure, re-issue failure."""

    def _vault_cfg(self) -> dict:
        return {"vault": {"pki": {"mount": "pki"}}}

    @patch("certmesh.backends.vault_client.list_pki_certificates")
    @patch("certmesh.backends.vault_client.get_authenticated_client")
    def test_list_failure_returns_error(self, mock_auth: MagicMock, mock_list: MagicMock) -> None:
        mock_auth.return_value = MagicMock()
        mock_list.side_effect = VaultError("forbidden")

        results = _check_vault_pki(self._vault_cfg(), _policy())

        assert len(results) == 1
        assert results[0].identifier == "*"
        assert results[0].error == "forbidden"

    @patch("certmesh.backends.vault_client.read_pki_certificate")
    @patch("certmesh.backends.vault_client.list_pki_certificates")
    @patch("certmesh.backends.vault_client.get_authenticated_client")
    def test_cert_parsing_failure_still_evaluates(
        self, mock_auth: MagicMock, mock_list: MagicMock, mock_read: MagicMock
    ) -> None:
        """When reading a cert fails, the serial is still checked with not_after=None."""
        mock_auth.return_value = MagicMock()
        mock_list.return_value = ["AA:BB:CC"]
        mock_read.side_effect = VaultError("read failed")

        results = _check_vault_pki(self._vault_cfg(), _policy())

        assert len(results) == 1
        assert results[0].identifier == "AA:BB:CC"
        assert results[0].not_after is None
        # not_after is None -> should_renew returns False
        assert results[0].needs_renewal is False

    @patch("certmesh.backends.vault_client.issue_pki_certificate")
    @patch("certmesh.backends.vault_client.read_pki_certificate")
    @patch("certmesh.backends.vault_client.list_pki_certificates")
    @patch("certmesh.backends.vault_client.get_authenticated_client")
    def test_reissue_failure_records_error(
        self,
        mock_auth: MagicMock,
        mock_list: MagicMock,
        mock_read: MagicMock,
        mock_issue: MagicMock,
    ) -> None:
        """When issue_pki_certificate fails the error is captured."""
        mock_auth.return_value = MagicMock()
        mock_list.return_value = ["DD:EE:FF"]
        mock_read.return_value = {
            "revocation_time": 0,
            "certificate": "",
        }
        mock_issue.side_effect = VaultError("role not found")

        # We need not_after to be set for renewal, so patch should_renew
        with patch("certmesh.renewal.should_renew", return_value=True):
            results = _check_vault_pki(self._vault_cfg(), _policy(dry_run=False))

        assert len(results) == 1
        assert results[0].error == "role not found"
        assert results[0].renewed is False

    @patch("certmesh.backends.vault_client.issue_pki_certificate")
    @patch("certmesh.backends.vault_client.read_pki_certificate")
    @patch("certmesh.backends.vault_client.list_pki_certificates")
    @patch("certmesh.backends.vault_client.get_authenticated_client")
    def test_reissue_success(
        self,
        mock_auth: MagicMock,
        mock_list: MagicMock,
        mock_read: MagicMock,
        mock_issue: MagicMock,
    ) -> None:
        mock_auth.return_value = MagicMock()
        mock_list.return_value = ["11:22:33"]
        mock_read.return_value = {
            "revocation_time": 0,
            "certificate": "",
        }
        mock_issue.return_value = {}

        with patch("certmesh.renewal.should_renew", return_value=True):
            results = _check_vault_pki(self._vault_cfg(), _policy(dry_run=False))

        assert len(results) == 1
        assert results[0].renewed is True
        assert results[0].error is None

    @patch("certmesh.backends.vault_client.get_authenticated_client")
    def test_auth_failure_returns_error(self, mock_auth: MagicMock) -> None:
        mock_auth.side_effect = VaultError("connection refused")

        results = _check_vault_pki(self._vault_cfg(), _policy())

        assert len(results) == 1
        assert results[0].identifier == "*"
        assert results[0].error == "connection refused"


# ── _check_venafi ────────────────────────────────────────────────────────────


class TestCheckVenafi:
    """Cover _check_venafi: per-cert renewal failure."""

    def _venafi_cfg(self) -> dict:
        return {"venafi": {"url": "https://tpp.example.com"}, "vault": {}}

    @patch("certmesh.providers.venafi_client.renew_and_download_certificate")
    @patch("certmesh.providers.venafi_client.list_certificates")
    @patch("certmesh.providers.venafi_client.authenticate")
    def test_renewal_failure_per_cert(
        self,
        mock_auth: MagicMock,
        mock_list: MagicMock,
        mock_renew: MagicMock,
    ) -> None:
        session = MagicMock()
        mock_auth.return_value = session
        cert = SimpleNamespace(
            guid="g-1234",
            dn="\\VED\\Policy\\example.com",
            approx_not_after=(datetime.now(timezone.utc) + timedelta(days=3)).isoformat(),
        )
        mock_list.return_value = [cert]
        mock_renew.side_effect = VenafiError("renewal denied")

        results = _check_venafi(self._venafi_cfg(), _policy(dry_run=False))

        assert len(results) == 1
        assert results[0].needs_renewal is True
        assert results[0].renewed is False
        assert results[0].error == "renewal denied"
        session.close.assert_called_once()

    @patch("certmesh.providers.venafi_client.renew_and_download_certificate")
    @patch("certmesh.providers.venafi_client.list_certificates")
    @patch("certmesh.providers.venafi_client.authenticate")
    def test_renewal_success(
        self,
        mock_auth: MagicMock,
        mock_list: MagicMock,
        mock_renew: MagicMock,
    ) -> None:
        session = MagicMock()
        mock_auth.return_value = session
        cert = SimpleNamespace(
            guid="g-5678",
            dn="\\VED\\Policy\\test.com",
            approx_not_after=(datetime.now(timezone.utc) + timedelta(days=3)).isoformat(),
        )
        mock_list.return_value = [cert]
        mock_renew.return_value = {}

        results = _check_venafi(self._venafi_cfg(), _policy(dry_run=False))

        assert len(results) == 1
        assert results[0].renewed is True
        session.close.assert_called_once()


# ── check_and_renew: summary logging & pushgateway ──────────────────────────


class TestCheckAndRenewSummary:
    """Cover summary logging and pushgateway metrics push in check_and_renew."""

    @patch("certmesh.renewal._check_provider")
    def test_summary_logging(self, mock_cp: MagicMock) -> None:
        mock_cp.return_value = [
            RenewalResult(
                provider="acm",
                identifier="arn:1",
                common_name="a.com",
                not_after=_expiring_soon(),
                needs_renewal=True,
                renewed=True,
            ),
            RenewalResult(
                provider="acm",
                identifier="arn:2",
                common_name="b.com",
                not_after=_far_future(),
                needs_renewal=False,
            ),
        ]

        policy = RenewalPolicy(providers=["acm"])
        cfg: dict = {"acm": {"enabled": True}}
        results = check_and_renew(cfg, policy)

        assert len(results) == 2
        assert sum(1 for r in results if r.needs_renewal) == 1
        assert sum(1 for r in results if r.renewed) == 1

    @patch("certmesh.renewal._check_provider", return_value=[])
    def test_pushgateway_triggered_by_cfg(self, mock_cp: MagicMock) -> None:
        cfg: dict = {"pushgateway_url": "http://pushgw:9091", "acm": {"enabled": True}}
        policy = RenewalPolicy(providers=["acm"])

        with patch("certmesh.renewal_metrics.push_renewal_metrics") as mock_push:
            check_and_renew(cfg, policy)
            mock_push.assert_called_once_with([], "http://pushgw:9091")

    @patch("certmesh.renewal._check_provider", return_value=[])
    def test_pushgateway_triggered_by_env(self, mock_cp: MagicMock, monkeypatch) -> None:
        monkeypatch.setenv("CERTMESH_PUSHGATEWAY_URL", "http://envgw:9091")

        with patch("certmesh.renewal_metrics.push_renewal_metrics") as mock_push:
            check_and_renew({}, RenewalPolicy(providers=["acm"]))
            mock_push.assert_called_once()

    @patch("certmesh.renewal._check_provider", return_value=[])
    def test_no_pushgateway_when_unset(self, mock_cp: MagicMock, monkeypatch) -> None:
        monkeypatch.delenv("CERTMESH_PUSHGATEWAY_URL", raising=False)

        # push_renewal_metrics should not be imported / called
        with patch.dict("sys.modules", {"certmesh.renewal_metrics": MagicMock()}):
            results = check_and_renew({}, RenewalPolicy(providers=["acm"]))

        assert results == []
