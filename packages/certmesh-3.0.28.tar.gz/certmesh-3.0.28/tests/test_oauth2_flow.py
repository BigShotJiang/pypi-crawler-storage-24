"""Tests for certmesh.api.oauth2_flow module."""

from __future__ import annotations

import base64
import hashlib
from unittest.mock import AsyncMock, MagicMock, patch

import httpx
import pytest

from certmesh.api.oauth2_flow import (
    OAuth2FlowConfig,
    SessionManager,
    build_authorization_url,
    build_oauth2_flow_config,
    exchange_code_for_tokens,
    fetch_userinfo,
    generate_code_challenge,
    generate_code_verifier,
    generate_csrf_token,
    generate_oauth2_state,
    refresh_access_token,
    validate_oauth2_state,
)

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

_GOOD_SECRET = "a" * 64  # 64 chars, well above the 32-char minimum


def _make_config(**overrides: str) -> OAuth2FlowConfig:
    defaults = {
        "issuer_url": "https://login.example.com/tenant/v2.0",
        "client_id": "my-client-id",
        "redirect_uri": "https://app.example.com/callback",
        "session_secret": _GOOD_SECRET,
        "scopes": "openid profile email",
    }
    defaults.update(overrides)
    return OAuth2FlowConfig(**defaults)


# ═══════════════════════════════════════════════════════════════════════════
# OAuth2FlowConfig
# ═══════════════════════════════════════════════════════════════════════════


class TestOAuth2FlowConfig:
    def test_authorize_url(self) -> None:
        cfg = _make_config()
        assert cfg.authorize_url == "https://login.example.com/tenant/v2.0/authorize"

    def test_token_url(self) -> None:
        cfg = _make_config()
        assert cfg.token_url == "https://login.example.com/tenant/v2.0/token"

    def test_userinfo_url(self) -> None:
        cfg = _make_config()
        assert cfg.userinfo_url == "https://login.example.com/tenant/v2.0/userinfo"

    def test_end_session_url(self) -> None:
        cfg = _make_config()
        assert cfg.end_session_url == "https://login.example.com/tenant/v2.0/logout"

    def test_trailing_slash_stripped(self) -> None:
        cfg = _make_config(issuer_url="https://login.example.com/tenant/v2.0/")
        assert cfg.authorize_url == "https://login.example.com/tenant/v2.0/authorize"
        assert cfg.token_url == "https://login.example.com/tenant/v2.0/token"
        assert cfg.userinfo_url == "https://login.example.com/tenant/v2.0/userinfo"
        assert cfg.end_session_url == "https://login.example.com/tenant/v2.0/logout"

    def test_defaults(self) -> None:
        cfg = OAuth2FlowConfig()
        assert cfg.issuer_url == ""
        assert cfg.client_id == ""
        assert cfg.redirect_uri == ""
        assert cfg.session_secret == ""
        assert cfg.scopes == "openid profile email"


class TestBuildOAuth2FlowConfig:
    def test_from_env(self) -> None:
        env = {
            "CM_OAUTH2_ISSUER_URL": "https://issuer.test",
            "CM_OAUTH2_CLIENT_ID": "cid-123",
            "CM_DASHBOARD_REDIRECT_URI": "https://app.test/cb",
            "CM_DASHBOARD_SESSION_SECRET": "supersecret",
            "CM_DASHBOARD_SCOPES": "openid",
        }
        with patch.dict("os.environ", env, clear=False):
            cfg = build_oauth2_flow_config()
        assert cfg.issuer_url == "https://issuer.test"
        assert cfg.client_id == "cid-123"
        assert cfg.redirect_uri == "https://app.test/cb"
        assert cfg.session_secret == "supersecret"
        assert cfg.scopes == "openid"

    def test_defaults_when_env_unset(self) -> None:
        env_keys = [
            "CM_OAUTH2_ISSUER_URL",
            "CM_OAUTH2_CLIENT_ID",
            "CM_DASHBOARD_REDIRECT_URI",
            "CM_DASHBOARD_SESSION_SECRET",
            "CM_DASHBOARD_SCOPES",
        ]
        # Ensure keys are absent
        import os

        orig = {k: os.environ.pop(k, None) for k in env_keys}
        try:
            cfg = build_oauth2_flow_config()
        finally:
            for k, v in orig.items():
                if v is not None:
                    os.environ[k] = v

        assert cfg.issuer_url == ""
        assert cfg.client_id == ""
        assert cfg.redirect_uri == "http://localhost:8000/dashboard/callback"
        assert cfg.session_secret == ""
        assert cfg.scopes == "openid profile email"


# ═══════════════════════════════════════════════════════════════════════════
# PKCE helpers
# ═══════════════════════════════════════════════════════════════════════════


class TestPKCE:
    def test_generate_code_verifier_length(self) -> None:
        verifier = generate_code_verifier()
        # secrets.token_urlsafe(32) produces 43 chars
        assert len(verifier) == 43

    def test_generate_code_verifier_uniqueness(self) -> None:
        v1 = generate_code_verifier()
        v2 = generate_code_verifier()
        assert v1 != v2

    def test_generate_code_challenge_is_s256(self) -> None:
        verifier = "test-verifier-string"
        challenge = generate_code_challenge(verifier)
        # Manually compute expected S256 challenge
        digest = hashlib.sha256(verifier.encode("ascii")).digest()
        expected = base64.urlsafe_b64encode(digest).rstrip(b"=").decode("ascii")
        assert challenge == expected

    def test_code_challenge_url_safe(self) -> None:
        verifier = generate_code_verifier()
        challenge = generate_code_challenge(verifier)
        # Should not contain +, /, or = (url-safe base64, padding stripped)
        assert "+" not in challenge
        assert "/" not in challenge
        assert "=" not in challenge

    def test_code_challenge_deterministic(self) -> None:
        verifier = "fixed-verifier"
        c1 = generate_code_challenge(verifier)
        c2 = generate_code_challenge(verifier)
        assert c1 == c2


# ═══════════════════════════════════════════════════════════════════════════
# SessionManager
# ═══════════════════════════════════════════════════════════════════════════


class TestSessionManager:
    def test_create_and_load_session(self) -> None:
        sm = SessionManager(_GOOD_SECRET)
        data = {"user": "alice", "role": "admin"}
        token = sm.create_session(data)
        loaded = sm.load_session(token)

        assert loaded is not None
        assert loaded["user"] == "alice"
        assert loaded["role"] == "admin"
        assert "_sid" in loaded
        assert "_created" in loaded

    def test_session_contains_sid_and_created(self) -> None:
        sm = SessionManager(_GOOD_SECRET)
        token = sm.create_session({"key": "value"})
        loaded = sm.load_session(token)

        assert loaded is not None
        assert len(loaded["_sid"]) == 32  # hex(16) = 32 chars
        assert isinstance(loaded["_created"], float)

    def test_load_session_invalid_token(self) -> None:
        sm = SessionManager(_GOOD_SECRET)
        assert sm.load_session("garbage-token") is None

    def test_load_session_wrong_secret(self) -> None:
        sm1 = SessionManager("x" * 32)
        sm2 = SessionManager("y" * 32)
        token = sm1.create_session({"user": "bob"})
        assert sm2.load_session(token) is None

    def test_load_session_expired(self) -> None:
        sm = SessionManager(_GOOD_SECRET, max_age=1)
        token = sm.create_session({"user": "carol"})
        # Patch the loads method to simulate BadSignature (expired)
        from itsdangerous import SignatureExpired

        with patch.object(sm._serializer, "loads", side_effect=SignatureExpired("expired")):
            loaded = sm.load_session(token)
        assert loaded is None

    def test_rotate_session_changes_sid(self) -> None:
        sm = SessionManager(_GOOD_SECRET)
        data = {"user": "dave"}
        token1 = sm.create_session(data)
        loaded1 = sm.load_session(token1)
        old_sid = loaded1["_sid"]

        token2 = sm.rotate_session(loaded1)
        loaded2 = sm.load_session(token2)

        assert loaded2 is not None
        assert loaded2["_sid"] != old_sid
        assert loaded2["user"] == "dave"

    def test_rotate_session_preserves_payload(self) -> None:
        sm = SessionManager(_GOOD_SECRET)
        original = {"user": "eve", "email": "eve@example.com", "extra": 42}
        token = sm.create_session(original)
        loaded = sm.load_session(token)
        rotated_token = sm.rotate_session(loaded)
        rotated = sm.load_session(rotated_token)

        assert rotated is not None
        assert rotated["user"] == "eve"
        assert rotated["email"] == "eve@example.com"
        assert rotated["extra"] == 42

    def test_short_secret_generates_fallback(self) -> None:
        """SessionManager should not crash with a short/empty secret."""
        sm = SessionManager("short")
        token = sm.create_session({"user": "test"})
        loaded = sm.load_session(token)
        assert loaded is not None
        assert loaded["user"] == "test"

    def test_empty_secret_generates_fallback(self) -> None:
        sm = SessionManager("")
        token = sm.create_session({"user": "test"})
        loaded = sm.load_session(token)
        assert loaded is not None

    def test_max_age_property(self) -> None:
        sm = SessionManager(_GOOD_SECRET, max_age=7200)
        assert sm.max_age == 7200

    def test_max_age_default(self) -> None:
        sm = SessionManager(_GOOD_SECRET)
        assert sm.max_age == 3600


# ═══════════════════════════════════════════════════════════════════════════
# CSRF / OAuth2 state
# ═══════════════════════════════════════════════════════════════════════════


class TestCSRFAndState:
    def test_generate_csrf_token_length(self) -> None:
        token = generate_csrf_token()
        assert len(token) == 64

    def test_generate_csrf_token_uniqueness(self) -> None:
        t1 = generate_csrf_token()
        t2 = generate_csrf_token()
        assert t1 != t2

    def test_generate_and_validate_oauth2_state(self) -> None:
        sm = SessionManager(_GOOD_SECRET)
        csrf = generate_csrf_token()
        state = generate_oauth2_state(sm, csrf)
        assert validate_oauth2_state(sm, state, csrf) is True

    def test_validate_oauth2_state_wrong_csrf(self) -> None:
        sm = SessionManager(_GOOD_SECRET)
        csrf = generate_csrf_token()
        state = generate_oauth2_state(sm, csrf)
        assert validate_oauth2_state(sm, state, "wrong-csrf-token") is False

    def test_validate_oauth2_state_tampered(self) -> None:
        sm = SessionManager(_GOOD_SECRET)
        csrf = generate_csrf_token()
        state = generate_oauth2_state(sm, csrf)
        assert validate_oauth2_state(sm, state + "tampered", csrf) is False

    def test_validate_oauth2_state_wrong_secret(self) -> None:
        sm1 = SessionManager("a" * 32)
        sm2 = SessionManager("b" * 32)
        csrf = generate_csrf_token()
        state = generate_oauth2_state(sm1, csrf)
        assert validate_oauth2_state(sm2, state, csrf) is False

    def test_validate_oauth2_state_garbage(self) -> None:
        sm = SessionManager(_GOOD_SECRET)
        assert validate_oauth2_state(sm, "not-a-valid-state", "csrf") is False


# ═══════════════════════════════════════════════════════════════════════════
# Token exchange (async, mocked httpx)
# ═══════════════════════════════════════════════════════════════════════════


class TestExchangeCodeForTokens:
    @pytest.mark.asyncio
    async def test_exchange_code_success(self) -> None:
        config = _make_config()
        expected_response = {
            "access_token": "at-abc",
            "id_token": "id-xyz",
            "refresh_token": "rt-123",
            "expires_in": 3600,
        }

        mock_response = MagicMock()
        mock_response.json.return_value = expected_response
        mock_response.raise_for_status = MagicMock()

        mock_client = AsyncMock()
        mock_client.post = AsyncMock(return_value=mock_response)
        mock_client.__aenter__ = AsyncMock(return_value=mock_client)
        mock_client.__aexit__ = AsyncMock(return_value=False)

        with patch("certmesh.api.oauth2_flow.httpx.AsyncClient", return_value=mock_client):
            result = await exchange_code_for_tokens(config, "auth-code-123", "verifier-456")

        assert result == expected_response
        mock_client.post.assert_called_once()
        call_kwargs = mock_client.post.call_args
        assert call_kwargs[1]["data"]["grant_type"] == "authorization_code"
        assert call_kwargs[1]["data"]["code"] == "auth-code-123"
        assert call_kwargs[1]["data"]["code_verifier"] == "verifier-456"
        assert call_kwargs[1]["data"]["client_id"] == "my-client-id"

    @pytest.mark.asyncio
    async def test_exchange_code_http_error(self) -> None:
        config = _make_config()

        mock_response = MagicMock()
        mock_response.raise_for_status.side_effect = httpx.HTTPStatusError(
            "Bad Request",
            request=MagicMock(),
            response=MagicMock(status_code=400),
        )

        mock_client = AsyncMock()
        mock_client.post = AsyncMock(return_value=mock_response)
        mock_client.__aenter__ = AsyncMock(return_value=mock_client)
        mock_client.__aexit__ = AsyncMock(return_value=False)

        with patch("certmesh.api.oauth2_flow.httpx.AsyncClient", return_value=mock_client):
            with pytest.raises(httpx.HTTPStatusError):
                await exchange_code_for_tokens(config, "bad-code", "verifier")


# ═══════════════════════════════════════════════════════════════════════════
# Refresh token (async, mocked httpx)
# ═══════════════════════════════════════════════════════════════════════════


class TestRefreshAccessToken:
    @pytest.mark.asyncio
    async def test_refresh_success(self) -> None:
        config = _make_config()
        expected = {
            "access_token": "new-at",
            "refresh_token": "new-rt",
            "expires_in": 3600,
        }

        mock_response = MagicMock()
        mock_response.json.return_value = expected
        mock_response.raise_for_status = MagicMock()

        mock_client = AsyncMock()
        mock_client.post = AsyncMock(return_value=mock_response)
        mock_client.__aenter__ = AsyncMock(return_value=mock_client)
        mock_client.__aexit__ = AsyncMock(return_value=False)

        with patch("certmesh.api.oauth2_flow.httpx.AsyncClient", return_value=mock_client):
            result = await refresh_access_token(config, "old-refresh-token")

        assert result == expected
        call_kwargs = mock_client.post.call_args
        assert call_kwargs[1]["data"]["grant_type"] == "refresh_token"
        assert call_kwargs[1]["data"]["refresh_token"] == "old-refresh-token"
        assert call_kwargs[1]["data"]["client_id"] == "my-client-id"

    @pytest.mark.asyncio
    async def test_refresh_http_error(self) -> None:
        config = _make_config()

        mock_response = MagicMock()
        mock_response.raise_for_status.side_effect = httpx.HTTPStatusError(
            "Unauthorized",
            request=MagicMock(),
            response=MagicMock(status_code=401),
        )

        mock_client = AsyncMock()
        mock_client.post = AsyncMock(return_value=mock_response)
        mock_client.__aenter__ = AsyncMock(return_value=mock_client)
        mock_client.__aexit__ = AsyncMock(return_value=False)

        with patch("certmesh.api.oauth2_flow.httpx.AsyncClient", return_value=mock_client):
            with pytest.raises(httpx.HTTPStatusError):
                await refresh_access_token(config, "expired-rt")


# ═══════════════════════════════════════════════════════════════════════════
# Fetch userinfo (async, mocked httpx)
# ═══════════════════════════════════════════════════════════════════════════


class TestFetchUserinfo:
    @pytest.mark.asyncio
    async def test_fetch_userinfo_success(self) -> None:
        config = _make_config()
        expected = {
            "sub": "user-123",
            "name": "Alice",
            "email": "alice@example.com",
        }

        mock_response = MagicMock()
        mock_response.json.return_value = expected
        mock_response.raise_for_status = MagicMock()

        mock_client = AsyncMock()
        mock_client.get = AsyncMock(return_value=mock_response)
        mock_client.__aenter__ = AsyncMock(return_value=mock_client)
        mock_client.__aexit__ = AsyncMock(return_value=False)

        with patch("certmesh.api.oauth2_flow.httpx.AsyncClient", return_value=mock_client):
            result = await fetch_userinfo(config, "access-token-xyz")

        assert result == expected
        mock_client.get.assert_called_once()
        call_kwargs = mock_client.get.call_args
        assert call_kwargs[1]["headers"]["Authorization"] == "Bearer access-token-xyz"

    @pytest.mark.asyncio
    async def test_fetch_userinfo_http_error(self) -> None:
        config = _make_config()

        mock_response = MagicMock()
        mock_response.raise_for_status.side_effect = httpx.HTTPStatusError(
            "Forbidden",
            request=MagicMock(),
            response=MagicMock(status_code=403),
        )

        mock_client = AsyncMock()
        mock_client.get = AsyncMock(return_value=mock_response)
        mock_client.__aenter__ = AsyncMock(return_value=mock_client)
        mock_client.__aexit__ = AsyncMock(return_value=False)

        with patch("certmesh.api.oauth2_flow.httpx.AsyncClient", return_value=mock_client):
            with pytest.raises(httpx.HTTPStatusError):
                await fetch_userinfo(config, "bad-token")

    @pytest.mark.asyncio
    async def test_fetch_userinfo_calls_correct_url(self) -> None:
        config = _make_config()

        mock_response = MagicMock()
        mock_response.json.return_value = {"sub": "u1"}
        mock_response.raise_for_status = MagicMock()

        mock_client = AsyncMock()
        mock_client.get = AsyncMock(return_value=mock_response)
        mock_client.__aenter__ = AsyncMock(return_value=mock_client)
        mock_client.__aexit__ = AsyncMock(return_value=False)

        with patch("certmesh.api.oauth2_flow.httpx.AsyncClient", return_value=mock_client):
            await fetch_userinfo(config, "tok")

        call_args = mock_client.get.call_args
        assert call_args[0][0] == "https://login.example.com/tenant/v2.0/userinfo"


# ═══════════════════════════════════════════════════════════════════════════
# build_authorization_url
# ═══════════════════════════════════════════════════════════════════════════


class TestBuildAuthorizationUrl:
    def test_contains_required_params(self) -> None:
        config = _make_config()
        url = build_authorization_url(config, state="state-abc", code_challenge="challenge-xyz")

        assert url.startswith("https://login.example.com/tenant/v2.0/authorize?")
        assert "response_type=code" in url
        assert "client_id=my-client-id" in url
        assert "state=state-abc" in url
        assert "code_challenge=challenge-xyz" in url
        assert "code_challenge_method=S256" in url
        assert "scope=openid+profile+email" in url or "scope=openid%20profile%20email" in url

    def test_redirect_uri_included(self) -> None:
        config = _make_config()
        url = build_authorization_url(config, state="s", code_challenge="c")
        # URL-encoded redirect_uri
        assert "redirect_uri=" in url
