"""Tests for certmesh.api.routes.logs and dashboard certificate detail."""

from __future__ import annotations

from typing import Any

import pytest
from fastapi import FastAPI
from fastapi.responses import HTMLResponse
from fastapi.testclient import TestClient

from certmesh.api.dashboard_state import DashboardStateConfig, DashboardStateStore
from certmesh.api.log_store import LogRecord, LogStore, LogStoreConfig
from certmesh.api.oauth2_flow import OAuth2FlowConfig, SessionManager
from certmesh.api.routes.dashboard import router as dashboard_router
from certmesh.api.routes.logs import router as logs_router

_SESSION_SECRET = "a" * 64


class _FakeTemplates:
    def TemplateResponse(self, *args: Any, **kwargs: Any) -> HTMLResponse:  # noqa: N802
        name = ""
        context: dict[str, Any] = {}
        status_code = 200
        for arg in args:
            if isinstance(arg, str) and arg.endswith(".html"):
                name = arg
            elif isinstance(arg, dict):
                context = arg
        name = kwargs.get("name", name)
        context = kwargs.get("context", context)
        status_code = kwargs.get("status_code", status_code)
        parts = [f"<html><body><h1>{name}</h1>"]
        for key in ("user", "csrf_token", "provider", "cert_id"):
            val = context.get(key)
            if val:
                parts.append(f'<div class="{key}">{val}</div>')
        parts.append("</body></html>")
        return HTMLResponse(content="\n".join(parts), status_code=status_code)


def _make_app() -> FastAPI:
    app = FastAPI()
    session_manager = SessionManager(secret=_SESSION_SECRET)
    app.state.session_manager = session_manager
    app.state.oauth2_flow_config = OAuth2FlowConfig(
        issuer_url="https://idp.example.com",
        client_id="test-client-id",
        redirect_uri="http://localhost:8000/dashboard/callback",
        session_secret=_SESSION_SECRET,
    )
    app.state.dashboard_state = DashboardStateStore(DashboardStateConfig())
    app.state.dashboard_templates = _FakeTemplates()
    app.state.config = {}

    # Log store (in-memory)
    log_store = LogStore(LogStoreConfig(enabled=True, bucket="", buffer_size=100))
    app.state.log_store = log_store

    # Pre-populate with some logs
    log_store.add(
        LogRecord(
            timestamp="2026-03-25T10:00:00Z",
            level="INFO",
            logger_name="certmesh.api",
            message="Server started",
        )
    )
    log_store.add(
        LogRecord(
            timestamp="2026-03-25T10:01:00Z",
            level="WARNING",
            logger_name="certmesh.providers",
            message="Venafi timeout",
            extra={"provider": "venafi"},
        )
    )
    log_store.add(
        LogRecord(
            timestamp="2026-03-25T10:02:00Z",
            level="ERROR",
            logger_name="certmesh.api.routes",
            message="Renewal failed",
            extra={"cert_id": "abc123"},
        )
    )

    app.include_router(dashboard_router)
    app.include_router(logs_router)
    return app


def _create_session_cookie(app: FastAPI, csrf_token: str = "test-csrf") -> str:
    sm: SessionManager = app.state.session_manager
    return sm.create_session(
        {
            "user": {"sub": "user1", "name": "Test User", "email": "test@example.com"},
            "access_token": "fake",
            "csrf_token": csrf_token,
        }
    )


@pytest.fixture()
def app() -> FastAPI:
    return _make_app()


@pytest.fixture()
def client(app: FastAPI) -> TestClient:
    return TestClient(app, follow_redirects=False)


# ── Log page ─────────────────────────────────────────────────────────────────


class TestLogsPage:
    def test_logs_page_requires_auth(self, client: TestClient) -> None:
        resp = client.get("/dashboard/logs")
        assert resp.status_code == 302
        assert "auth/start" in resp.headers["location"]

    def test_logs_page_renders_when_authenticated(self, app: FastAPI, client: TestClient) -> None:
        cookie = _create_session_cookie(app)
        resp = client.get("/dashboard/logs", cookies={"cm_session": cookie})
        assert resp.status_code == 200
        assert "logs.html" in resp.text


# ── Log query API ────────────────────────────────────────────────────────────


class TestLogQueryAPI:
    def test_unauthenticated_returns_401(self, client: TestClient) -> None:
        resp = client.get("/dashboard/api/logs")
        assert resp.status_code == 401

    def test_returns_all_logs(self, app: FastAPI, client: TestClient) -> None:
        cookie = _create_session_cookie(app)
        resp = client.get("/dashboard/api/logs", cookies={"cm_session": cookie})
        assert resp.status_code == 200
        data = resp.json()
        assert data["total"] == 3

    def test_search_filter(self, app: FastAPI, client: TestClient) -> None:
        cookie = _create_session_cookie(app)
        resp = client.get("/dashboard/api/logs?search=Venafi", cookies={"cm_session": cookie})
        assert resp.status_code == 200
        data = resp.json()
        assert data["total"] == 1
        assert "Venafi" in data["logs"][0]["message"]

    def test_level_filter(self, app: FastAPI, client: TestClient) -> None:
        cookie = _create_session_cookie(app)
        resp = client.get("/dashboard/api/logs?level=ERROR", cookies={"cm_session": cookie})
        assert resp.status_code == 200
        data = resp.json()
        assert data["total"] == 1
        assert data["logs"][0]["level"] == "ERROR"

    def test_logger_filter(self, app: FastAPI, client: TestClient) -> None:
        cookie = _create_session_cookie(app)
        resp = client.get(
            "/dashboard/api/logs?logger_name=providers",
            cookies={"cm_session": cookie},
        )
        assert resp.status_code == 200
        data = resp.json()
        assert data["total"] == 1

    def test_pagination(self, app: FastAPI, client: TestClient) -> None:
        cookie = _create_session_cookie(app)
        resp = client.get("/dashboard/api/logs?limit=1&offset=0", cookies={"cm_session": cookie})
        assert resp.status_code == 200
        data = resp.json()
        assert len(data["logs"]) == 1
        assert data["total"] == 3

    def test_limit_clamped(self, app: FastAPI, client: TestClient) -> None:
        cookie = _create_session_cookie(app)
        resp = client.get("/dashboard/api/logs?limit=9999", cookies={"cm_session": cookie})
        assert resp.status_code == 200
        # The limit should be clamped to 1000
        data = resp.json()
        assert data["limit"] <= 1000

    def test_provider_filter(self, app: FastAPI, client: TestClient) -> None:
        cookie = _create_session_cookie(app)
        resp = client.get(
            "/dashboard/api/logs?provider=venafi",
            cookies={"cm_session": cookie},
        )
        assert resp.status_code == 200
        data = resp.json()
        assert data["total"] == 1
        assert data["logs"][0]["provider"] == "venafi"

    def test_provider_filter_case_insensitive(self, app: FastAPI, client: TestClient) -> None:
        cookie = _create_session_cookie(app)
        resp = client.get(
            "/dashboard/api/logs?provider=Venafi",
            cookies={"cm_session": cookie},
        )
        assert resp.status_code == 200
        data = resp.json()
        assert data["total"] == 1

    def test_logger_field_not_overwritten_by_extra(self, app: FastAPI, client: TestClient) -> None:
        """Ensure extra fields cannot overwrite the core 'logger' key."""
        log_store: LogStore = app.state.log_store
        log_store.add(
            LogRecord(
                timestamp="2026-03-25T10:03:00Z",
                level="INFO",
                logger_name="certmesh.test",
                message="extra collision",
                extra={"logger": "should-be-ignored"},
            )
        )
        cookie = _create_session_cookie(app)
        resp = client.get(
            "/dashboard/api/logs?search=extra+collision",
            cookies={"cm_session": cookie},
        )
        data = resp.json()
        assert data["total"] == 1
        assert data["logs"][0]["logger"] == "certmesh.test"


# ── Log history API ──────────────────────────────────────────────────────────


class TestLogHistoryAPI:
    def test_unauthenticated_returns_401(self, client: TestClient) -> None:
        resp = client.get("/dashboard/api/logs/history")
        assert resp.status_code == 401

    def test_returns_empty_without_s3(self, app: FastAPI, client: TestClient) -> None:
        cookie = _create_session_cookie(app)
        resp = client.get(
            "/dashboard/api/logs/history?date=2026-03-25",
            cookies={"cm_session": cookie},
        )
        assert resp.status_code == 200
        data = resp.json()
        assert data["total"] == 0


# ── Log stats API ────────────────────────────────────────────────────────────


class TestLogStatsAPI:
    def test_returns_stats(self, app: FastAPI, client: TestClient) -> None:
        cookie = _create_session_cookie(app)
        resp = client.get("/dashboard/api/logs/stats", cookies={"cm_session": cookie})
        assert resp.status_code == 200
        data = resp.json()
        assert data["enabled"] is True
        assert "recent_count" in data
        assert "retention_days" in data


# ── Certificate detail page ──────────────────────────────────────────────────


class TestCertificateDetailPage:
    def test_requires_auth(self, client: TestClient) -> None:
        resp = client.get("/dashboard/certificates/venafi/cert1")
        assert resp.status_code == 302
        assert "auth/start" in resp.headers["location"]

    def test_renders_when_authenticated(self, app: FastAPI, client: TestClient) -> None:
        cookie = _create_session_cookie(app)
        resp = client.get(
            "/dashboard/certificates/venafi/cert1",
            cookies={"cm_session": cookie},
        )
        assert resp.status_code == 200
        assert "certificate_detail.html" in resp.text

    def test_invalid_cert_id_returns_400(self, app: FastAPI, client: TestClient) -> None:
        cookie = _create_session_cookie(app)
        resp = client.get(
            "/dashboard/certificates/venafi/invalid<>id",
            cookies={"cm_session": cookie},
        )
        assert resp.status_code == 400


# ── Certificate history API ──────────────────────────────────────────────────


class TestCertificateHistoryAPI:
    def test_unauthenticated_returns_401(self, client: TestClient) -> None:
        resp = client.get("/dashboard/api/certificates/history")
        assert resp.status_code == 401

    def test_returns_empty_by_default(self, app: FastAPI, client: TestClient) -> None:
        cookie = _create_session_cookie(app)
        resp = client.get(
            "/dashboard/api/certificates/history",
            cookies={"cm_session": cookie},
        )
        assert resp.status_code == 200
        data = resp.json()
        assert data["total"] == 0

    def test_returns_filtered_history(self, app: FastAPI, client: TestClient) -> None:
        # Pre-populate renewal history
        app.state.dashboard_state.put(
            "renewal_history",
            [
                {
                    "provider": "venafi",
                    "certificate_id": "cert1",
                    "action": "renew",
                    "status": "success",
                    "timestamp": 1711000000,
                    "user": "test@example.com",
                },
                {
                    "provider": "digicert",
                    "certificate_id": "cert2",
                    "action": "revoke",
                    "status": "success",
                    "timestamp": 1711000100,
                    "user": "admin@example.com",
                },
            ],
        )

        cookie = _create_session_cookie(app)
        resp = client.get(
            "/dashboard/api/certificates/history?provider=venafi&cert_id=cert1",
            cookies={"cm_session": cookie},
        )
        assert resp.status_code == 200
        data = resp.json()
        assert data["total"] == 1
        assert data["history"][0]["provider"] == "venafi"
        assert data["history"][0]["certificate_id"] == "cert1"
