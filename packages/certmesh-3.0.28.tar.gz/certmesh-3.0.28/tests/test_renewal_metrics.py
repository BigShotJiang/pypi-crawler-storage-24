"""
Tests for certmesh.renewal_metrics — Prometheus Pushgateway integration.
"""

from __future__ import annotations

import time
from datetime import datetime, timedelta, timezone
from unittest.mock import MagicMock, patch

import pytest

from certmesh.renewal import RenewalResult
from certmesh.renewal_metrics import _push, push_renewal_metrics

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

_NOW = datetime(2026, 3, 24, 12, 0, 0, tzinfo=timezone.utc)


def _make_result(
    provider: str = "vault-pki",
    common_name: str = "test.example.com",
    *,
    renewed: bool = False,
    error: str | None = None,
    not_after: datetime | None = None,
) -> RenewalResult:
    if not_after is None:
        not_after = _NOW + timedelta(days=60)
    return RenewalResult(
        provider=provider,
        identifier="abc123",
        common_name=common_name,
        not_after=not_after,
        needs_renewal=False,
        renewed=renewed,
        error=error,
    )


# ---------------------------------------------------------------------------
# push_renewal_metrics — public wrapper
# ---------------------------------------------------------------------------


@patch("certmesh.renewal_metrics.push_to_gateway")
def test_push_metrics_success(mock_push: MagicMock) -> None:
    """Happy path: push_to_gateway is called exactly once."""
    results = [_make_result()]
    push_renewal_metrics(results, "http://gw:9091")
    mock_push.assert_called_once()


@patch("certmesh.renewal_metrics.push_to_gateway")
def test_push_metrics_failure_does_not_raise(mock_push: MagicMock) -> None:
    """A Pushgateway failure must never propagate — it logs a warning instead."""
    mock_push.side_effect = ConnectionError("gateway unreachable")
    # Should not raise
    push_renewal_metrics([_make_result()], "http://gw:9091")


@patch("certmesh.renewal_metrics.push_to_gateway")
def test_push_metrics_failure_logs_warning(
    mock_push: MagicMock, caplog: pytest.LogCaptureFixture
) -> None:
    mock_push.side_effect = RuntimeError("boom")
    import logging

    with caplog.at_level(logging.WARNING, logger="certmesh.renewal_metrics"):
        push_renewal_metrics([_make_result()], "http://gw:9091")
    assert any("Failed to push" in r.message for r in caplog.records)


# ---------------------------------------------------------------------------
# _push — internal function, tested directly for metric values
# ---------------------------------------------------------------------------


@patch("certmesh.renewal_metrics.push_to_gateway")
def test_success_timestamp_set_when_no_errors(mock_push: MagicMock) -> None:
    """last_success_timestamp must be > 0 when there are no errors."""
    captured_registry = None

    def capture(url, job, registry):
        nonlocal captured_registry
        captured_registry = registry

    mock_push.side_effect = capture

    before = time.time()
    _push([_make_result()], "http://gw:9091", "certmesh-renewal")
    after = time.time()

    assert captured_registry is not None
    metrics = {m.name: m for m in captured_registry.collect()}
    ts = metrics["certmesh_renewal_last_success_timestamp_seconds"].samples[0].value
    assert before <= ts <= after


@patch("certmesh.renewal_metrics.push_to_gateway")
def test_success_timestamp_zero_when_errors(mock_push: MagicMock) -> None:
    """last_success_timestamp must be 0 when any result has an error."""
    captured_registry = None

    def capture(url, job, registry):
        nonlocal captured_registry
        captured_registry = registry

    mock_push.side_effect = capture

    results = [_make_result(error="API timeout")]
    _push(results, "http://gw:9091", "certmesh-renewal")

    metrics = {m.name: m for m in captured_registry.collect()}
    ts = metrics["certmesh_renewal_last_success_timestamp_seconds"].samples[0].value
    assert ts == 0


@patch("certmesh.renewal_metrics.push_to_gateway")
def test_run_timestamp_always_set(mock_push: MagicMock) -> None:
    """last_run_timestamp must always be set, regardless of errors."""
    captured_registry = None

    def capture(url, job, registry):
        nonlocal captured_registry
        captured_registry = registry

    mock_push.side_effect = capture

    before = time.time()
    _push([_make_result(error="boom")], "http://gw:9091", "certmesh-renewal")
    after = time.time()

    metrics = {m.name: m for m in captured_registry.collect()}
    ts = metrics["certmesh_renewal_last_run_timestamp_seconds"].samples[0].value
    assert before <= ts <= after


@patch("certmesh.renewal_metrics.push_to_gateway")
def test_per_provider_counts(mock_push: MagicMock) -> None:
    """Per-provider checked/renewed/errors gauges must be correct."""
    captured_registry = None

    def capture(url, job, registry):
        nonlocal captured_registry
        captured_registry = registry

    mock_push.side_effect = capture

    results = [
        _make_result(provider="vault-pki", renewed=True),
        _make_result(provider="vault-pki", renewed=False),
        _make_result(provider="acm", error="fail"),
    ]
    _push(results, "http://gw:9091", "certmesh-renewal")

    metrics = {m.name: m for m in captured_registry.collect()}

    def _by_provider(metric_name: str, provider: str) -> float:
        for sample in metrics[metric_name].samples:
            if sample.labels.get("provider") == provider:
                return sample.value
        raise KeyError(f"{metric_name}[provider={provider!r}] not found")

    assert _by_provider("certmesh_renewal_certs_checked", "vault-pki") == 2
    assert _by_provider("certmesh_renewal_certs_renewed", "vault-pki") == 1
    assert _by_provider("certmesh_renewal_errors", "vault-pki") == 0
    assert _by_provider("certmesh_renewal_certs_checked", "acm") == 1
    assert _by_provider("certmesh_renewal_errors", "acm") == 1


@patch("certmesh.renewal_metrics.push_to_gateway")
def test_cert_expiry_seconds_populated(mock_push: MagicMock) -> None:
    """certmesh_cert_expiry_seconds must reflect time remaining for each cert."""
    captured_registry = None

    def capture(url, job, registry):
        nonlocal captured_registry
        captured_registry = registry

    mock_push.side_effect = capture

    expiry = datetime.now(timezone.utc) + timedelta(days=10)
    result = _make_result(common_name="my.cert.com", not_after=expiry)
    _push([result], "http://gw:9091", "certmesh-renewal")

    metrics = {m.name: m for m in captured_registry.collect()}
    samples = metrics["certmesh_cert_expiry_seconds"].samples
    assert len(samples) == 1
    # Should be approximately 10 days in seconds (within a minute of tolerance)
    expected = 10 * 86400
    assert abs(samples[0].value - expected) < 60


@patch("certmesh.renewal_metrics.push_to_gateway")
def test_cert_expiry_skipped_for_none_not_after(mock_push: MagicMock) -> None:
    """Certs with unknown expiry (not_after=None) must not appear in expiry gauge."""
    captured_registry = None

    def capture(url, job, registry):
        nonlocal captured_registry
        captured_registry = registry

    mock_push.side_effect = capture

    result = _make_result(not_after=None)
    result = RenewalResult(
        provider="digicert",
        identifier="x",
        common_name="unknown.cert.com",
        not_after=None,
        needs_renewal=False,
    )
    _push([result], "http://gw:9091", "certmesh-renewal")

    metrics = {m.name: m for m in captured_registry.collect()}
    samples = metrics["certmesh_cert_expiry_seconds"].samples
    assert len(samples) == 0


@patch("certmesh.renewal_metrics.push_to_gateway")
def test_push_uses_correct_job_name(mock_push: MagicMock) -> None:
    """push_to_gateway must be called with the specified job name."""
    _push([_make_result()], "http://gw:9091", "my-custom-job")
    call_args = mock_push.call_args
    job = call_args[1].get("job") or call_args[0][1]
    assert job == "my-custom-job"


# ---------------------------------------------------------------------------
# Integration with check_and_renew — verify URL read from env
# ---------------------------------------------------------------------------


def test_check_and_renew_skips_push_when_no_url(monkeypatch: pytest.MonkeyPatch) -> None:
    """check_and_renew must not attempt a push when no URL is configured."""
    monkeypatch.delenv("CERTMESH_PUSHGATEWAY_URL", raising=False)

    with patch("certmesh.renewal_metrics.push_to_gateway") as mock_push:
        from certmesh.renewal import RenewalPolicy, check_and_renew

        # Empty cfg — all providers will be skipped (not configured)
        check_and_renew({}, RenewalPolicy(providers=["vault-pki"]))
        mock_push.assert_not_called()


def test_check_and_renew_pushes_when_env_url_set(monkeypatch: pytest.MonkeyPatch) -> None:
    """check_and_renew must push when CERTMESH_PUSHGATEWAY_URL is set."""
    monkeypatch.setenv("CERTMESH_PUSHGATEWAY_URL", "http://gw:9091")

    with patch("certmesh.renewal_metrics.push_to_gateway") as mock_push:
        from certmesh.renewal import RenewalPolicy, check_and_renew

        check_and_renew({}, RenewalPolicy(providers=["vault-pki"]))
        mock_push.assert_called_once()
