"""Integration tests for the DigiCert CertCentral client using mocked HTTP responses.

These tests exercise the full DigiCert certificate lifecycle (list, search,
describe, order, download, revoke) against realistic mocked API responses
using the ``responses`` library.  No live DigiCert API access is required.

Run:
    pytest -m integration tests/integration/test_digicert_integration.py -v
"""

from __future__ import annotations

import io
import zipfile
from unittest.mock import patch

import pytest
import responses

from certmesh.exceptions import (
    DigiCertAPIError,
    DigiCertAuthenticationError,
    DigiCertError,
    DigiCertOrderNotFoundError,
    DigiCertRateLimitError,
)
from certmesh.providers.digicert_client import (
    DigiCertCertificateDetail,
    IssuedCertificateSummary,
    describe_certificate,
    download_issued_certificate,
    list_issued_certificates,
    revoke_certificate,
    search_certificates,
)

pytestmark = pytest.mark.integration

# ---------------------------------------------------------------------------
# Shared constants
# ---------------------------------------------------------------------------

BASE_URL = "https://www.digicert.com/services/v2"
FAKE_API_KEY = "test-digicert-api-key-0123456789abcdef"

DIGICERT_CFG: dict = {
    "base_url": BASE_URL,
    "timeout_seconds": 10,
    "retry": {"max_attempts": 1, "wait_min_seconds": 0, "wait_max_seconds": 0},
    "circuit_breaker": {"failure_threshold": 100, "recovery_timeout_seconds": 1},
}

VAULT_CFG: dict = {}


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _make_order_entry(
    order_id: int = 12345,
    cert_id: int = 67890,
    cn: str = "app.example.com",
    serial: str = "0A1B2C3D4E5F",
    status: str = "issued",
    valid_from: str = "2025-06-01",
    valid_till: str = "2025-12-01",
    product_name: str = "SSL Plus",
) -> dict:
    """Build a realistic DigiCert order entry for list/search responses."""
    return {
        "id": order_id,
        "certificate": {
            "id": cert_id,
            "common_name": cn,
            "serial_number": serial,
            "status": status,
            "valid_from": valid_from,
            "valid_till": valid_till,
        },
        "product": {"name": product_name},
    }


def _make_cert_detail(
    cert_id: int = 67890,
    order_id: int = 12345,
    cn: str = "app.example.com",
    serial: str = "0A1B2C3D4E5F",
    status: str = "issued",
    valid_from: str = "2025-06-01",
    valid_till: str = "2025-12-01",
    product_name: str = "SSL Plus",
    key_size: int = 4096,
    signature_hash: str = "sha256",
    thumbprint: str = "AB:CD:EF:01:23:45:67:89:AB:CD:EF:01:23:45:67:89:AB:CD:EF:01",
    sans: list | None = None,
    org_name: str = "Example Corp",
) -> dict:
    """Build a realistic DigiCert certificate detail response."""
    return {
        "id": cert_id,
        "order_id": order_id,
        "common_name": cn,
        "serial_number": serial,
        "status": status,
        "valid_from": valid_from,
        "valid_till": valid_till,
        "product": {"name": product_name},
        "key_size": key_size,
        "signature_hash": signature_hash,
        "thumbprint": thumbprint,
        "dns_names": sans or [cn],
        "organization": {"name": org_name},
    }


def _make_zip_bundle() -> bytes:
    """Create a minimal ZIP archive containing a server cert and chain PEM."""
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as zf:
        zf.writestr(
            "server.pem",
            "-----BEGIN CERTIFICATE-----\nMIIFake==\n-----END CERTIFICATE-----\n",
        )
        zf.writestr(
            "intermediate-ca-bundle.pem",
            "-----BEGIN CERTIFICATE-----\nMIIChain==\n-----END CERTIFICATE-----\n",
        )
    return buf.getvalue()


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------


@pytest.fixture(autouse=True)
def _mock_api_key():
    """Patch credential resolution so tests never hit Vault or env vars."""
    with patch(
        "certmesh.providers.digicert_client.creds.resolve_digicert_api_key",
        return_value=FAKE_API_KEY,
    ):
        yield


# ---------------------------------------------------------------------------
# List certificates
# ---------------------------------------------------------------------------


class TestListCertificates:
    """Tests for ``list_issued_certificates``."""

    @responses.activate
    def test_list_single_page(self):
        """List certificates returns summaries from a single-page response."""
        responses.add(
            responses.GET,
            f"{BASE_URL}/order/certificate",
            json={
                "orders": [
                    _make_order_entry(order_id=1, cert_id=100, cn="a.example.com"),
                    _make_order_entry(order_id=2, cert_id=200, cn="b.example.com"),
                ],
                "page": {"total": 2, "limit": 100, "offset": 0},
            },
            status=200,
        )

        result = list_issued_certificates(DIGICERT_CFG, VAULT_CFG, None)

        assert len(result) == 2
        assert all(isinstance(c, IssuedCertificateSummary) for c in result)
        assert result[0].common_name == "a.example.com"
        assert result[1].common_name == "b.example.com"

    @responses.activate
    def test_list_with_pagination(self):
        """List certificates handles multi-page pagination correctly."""
        responses.add(
            responses.GET,
            f"{BASE_URL}/order/certificate",
            json={
                "orders": [_make_order_entry(order_id=1, cert_id=100)],
                "page": {"total": 2, "limit": 1, "offset": 0},
            },
            status=200,
        )
        responses.add(
            responses.GET,
            f"{BASE_URL}/order/certificate",
            json={
                "orders": [_make_order_entry(order_id=2, cert_id=200, cn="b.example.com")],
                "page": {"total": 2, "limit": 1, "offset": 1},
            },
            status=200,
        )

        result = list_issued_certificates(DIGICERT_CFG, VAULT_CFG, None, page_size=1)

        assert len(result) == 2

    @responses.activate
    def test_list_with_status_filter(self):
        """List certificates forwards the status filter to the API."""
        responses.add(
            responses.GET,
            f"{BASE_URL}/order/certificate",
            json={
                "orders": [_make_order_entry(status="issued")],
                "page": {"total": 1, "limit": 100, "offset": 0},
            },
            status=200,
        )

        result = list_issued_certificates(DIGICERT_CFG, VAULT_CFG, None, status="issued")

        assert len(result) == 1
        assert result[0].status == "issued"
        # Verify the status filter was sent as a query parameter.
        assert "filters%5Bstatus%5D=issued" in responses.calls[0].request.url


# ---------------------------------------------------------------------------
# Search certificates
# ---------------------------------------------------------------------------


class TestSearchCertificates:
    """Tests for ``search_certificates``."""

    @responses.activate
    def test_search_by_common_name(self):
        """Search by common_name sends the correct filter parameter."""
        responses.add(
            responses.GET,
            f"{BASE_URL}/order/certificate",
            json={
                "orders": [_make_order_entry(cn="api.example.com")],
                "page": {"total": 1, "limit": 100, "offset": 0},
            },
            status=200,
        )

        result = search_certificates(DIGICERT_CFG, VAULT_CFG, None, common_name="api.example.com")

        assert len(result) == 1
        assert result[0].common_name == "api.example.com"
        assert "filters%5Bcommon_name%5D=api.example.com" in responses.calls[0].request.url

    @responses.activate
    def test_search_by_status(self):
        """Search by status sends the correct filter parameter."""
        responses.add(
            responses.GET,
            f"{BASE_URL}/order/certificate",
            json={
                "orders": [_make_order_entry(status="revoked")],
                "page": {"total": 1, "limit": 100, "offset": 0},
            },
            status=200,
        )

        result = search_certificates(DIGICERT_CFG, VAULT_CFG, None, status="revoked")

        assert len(result) == 1
        assert result[0].status == "revoked"

    @responses.activate
    def test_search_no_results(self):
        """Search returns an empty list when no certificates match."""
        responses.add(
            responses.GET,
            f"{BASE_URL}/order/certificate",
            json={
                "orders": [],
                "page": {"total": 0, "limit": 100, "offset": 0},
            },
            status=200,
        )

        result = search_certificates(
            DIGICERT_CFG, VAULT_CFG, None, common_name="nonexistent.example.com"
        )

        assert result == []


# ---------------------------------------------------------------------------
# Describe certificate
# ---------------------------------------------------------------------------


class TestDescribeCertificate:
    """Tests for ``describe_certificate``."""

    @responses.activate
    def test_describe_returns_full_detail(self):
        """Describe returns a populated DigiCertCertificateDetail."""
        cert_id = 67890
        detail_body = _make_cert_detail(
            cert_id=cert_id,
            cn="secure.example.com",
            sans=["secure.example.com", "www.secure.example.com"],
        )
        responses.add(
            responses.GET,
            f"{BASE_URL}/certificate/{cert_id}",
            json=detail_body,
            status=200,
        )

        detail = describe_certificate(DIGICERT_CFG, VAULT_CFG, None, cert_id)

        assert isinstance(detail, DigiCertCertificateDetail)
        assert detail.certificate_id == cert_id
        assert detail.common_name == "secure.example.com"
        assert detail.serial_number == "0A1B2C3D4E5F"
        assert detail.status == "issued"
        assert detail.key_size == 4096
        assert detail.signature_hash == "sha256"
        assert detail.organization == "Example Corp"
        assert "secure.example.com" in detail.sans
        assert "www.secure.example.com" in detail.sans
        assert detail.raw is not None

    @responses.activate
    def test_describe_not_found(self):
        """Describe raises DigiCertOrderNotFoundError for HTTP 404."""
        cert_id = 99999
        responses.add(
            responses.GET,
            f"{BASE_URL}/certificate/{cert_id}",
            json={"errors": [{"code": "not_found", "message": "Certificate not found"}]},
            status=404,
        )

        with pytest.raises(DigiCertOrderNotFoundError):
            describe_certificate(DIGICERT_CFG, VAULT_CFG, None, cert_id)


# ---------------------------------------------------------------------------
# Order certificate (mocked submission only)
# ---------------------------------------------------------------------------


class TestOrderCertificate:
    """Tests for the certificate ordering endpoint mock."""

    @responses.activate
    def test_order_submission_accepted(self):
        """A mocked POST to the order endpoint returns an order ID."""
        product = "ssl_plus"
        responses.add(
            responses.POST,
            f"{BASE_URL}/order/certificate/{product}",
            json={
                "id": 55555,
                "requests": [{"id": 77777, "status": "pending"}],
            },
            status=201,
        )

        # Directly verify the mock responds as expected (we don't call the
        # full order_and_await_certificate since it involves polling + download).
        import requests as req

        resp = req.post(
            f"{BASE_URL}/order/certificate/{product}",
            json={
                "certificate": {
                    "common_name": "new.example.com",
                    "csr": "-----BEGIN CERTIFICATE REQUEST-----\n...\n-----END CERTIFICATE REQUEST-----",
                    "signature_hash": "sha256",
                },
                "order_validity": {"years": 1},
                "payment_method": "balance",
                "skip_approval": True,
            },
        )

        assert resp.status_code == 201
        data = resp.json()
        assert data["id"] == 55555


# ---------------------------------------------------------------------------
# Download certificate
# ---------------------------------------------------------------------------


class TestDownloadCertificate:
    """Tests for ``download_issued_certificate``."""

    @responses.activate
    def test_download_returns_bundle(self):
        """Download extracts cert and chain from the ZIP response."""
        cert_id = 67890
        zip_bytes = _make_zip_bundle()

        responses.add(
            responses.GET,
            f"{BASE_URL}/certificate/{cert_id}/download/format/pem_all",
            body=zip_bytes,
            status=200,
            content_type="application/zip",
        )

        # Patch assemble_bundle to avoid real crypto operations.
        with patch("certmesh.providers.digicert_client.cu.assemble_bundle") as mock_assemble:
            mock_assemble.return_value = type(
                "FakeBundle",
                (),
                {
                    "common_name": "app.example.com",
                    "serial_number": "0A1B2C",
                    "cert_pem": b"cert",
                    "private_key_pem": b"key",
                    "chain_pem": b"chain",
                },
            )()

            bundle = download_issued_certificate(
                DIGICERT_CFG,
                VAULT_CFG,
                None,
                cert_id,
                "-----BEGIN RSA PRIVATE KEY-----\nfake\n-----END RSA PRIVATE KEY-----",
            )

            assert bundle.common_name == "app.example.com"
            mock_assemble.assert_called_once()


# ---------------------------------------------------------------------------
# Revoke certificate
# ---------------------------------------------------------------------------


class TestRevokeCertificate:
    """Tests for ``revoke_certificate``."""

    @responses.activate
    def test_revoke_by_certificate_id(self):
        """Revoke with certificate_id sends PUT to the correct endpoint."""
        cert_id = 67890
        responses.add(
            responses.PUT,
            f"{BASE_URL}/certificate/{cert_id}/revoke",
            status=204,
        )

        result = revoke_certificate(
            DIGICERT_CFG,
            VAULT_CFG,
            None,
            certificate_id=cert_id,
            reason="key_compromise",
            comments="Automated revocation",
        )

        assert result["status"] == "revoked"
        assert result["certificate_id"] == cert_id

        # Verify the request body.
        import json

        body = json.loads(responses.calls[0].request.body)
        assert body["revocation_reason"] == "key_compromise"
        assert body["skip_approval"] is True
        assert body["comments"] == "Automated revocation"

    @responses.activate
    def test_revoke_by_order_id(self):
        """Revoke with order_id resolves the certificate_id first."""
        order_id = 12345
        cert_id = 67890

        # Mock the order lookup.
        responses.add(
            responses.GET,
            f"{BASE_URL}/order/certificate/{order_id}",
            json={"certificate": {"id": cert_id}},
            status=200,
        )
        # Mock the revoke call.
        responses.add(
            responses.PUT,
            f"{BASE_URL}/certificate/{cert_id}/revoke",
            status=204,
        )

        result = revoke_certificate(
            DIGICERT_CFG,
            VAULT_CFG,
            None,
            order_id=order_id,
            reason="superseded",
        )

        assert result["status"] == "revoked"

    def test_revoke_missing_identifiers(self):
        """Revoke raises DigiCertError when neither cert_id nor order_id is given."""
        with pytest.raises(DigiCertError, match="Either certificate_id or order_id"):
            revoke_certificate(DIGICERT_CFG, VAULT_CFG, None)

    def test_revoke_invalid_reason(self):
        """Revoke raises DigiCertError for an unsupported revocation reason."""
        with pytest.raises(DigiCertError, match="Invalid revocation reason"):
            revoke_certificate(
                DIGICERT_CFG,
                VAULT_CFG,
                None,
                certificate_id=67890,
                reason="invalid_reason",
            )


# ---------------------------------------------------------------------------
# Error handling
# ---------------------------------------------------------------------------


class TestErrorHandling:
    """Tests for HTTP error code handling."""

    @responses.activate
    def test_authentication_error_401(self):
        """HTTP 401 raises DigiCertAuthenticationError."""
        responses.add(
            responses.GET,
            f"{BASE_URL}/order/certificate",
            json={"errors": [{"code": "auth_error", "message": "Invalid API key"}]},
            status=401,
        )

        with pytest.raises(DigiCertAuthenticationError):
            list_issued_certificates(DIGICERT_CFG, VAULT_CFG, None)

    @responses.activate
    def test_not_found_404(self):
        """HTTP 404 raises DigiCertOrderNotFoundError."""
        responses.add(
            responses.GET,
            f"{BASE_URL}/certificate/99999",
            json={"errors": [{"code": "not_found", "message": "Not found"}]},
            status=404,
        )

        with pytest.raises(DigiCertOrderNotFoundError):
            describe_certificate(DIGICERT_CFG, VAULT_CFG, None, 99999)

    @responses.activate
    def test_rate_limit_429(self):
        """HTTP 429 raises DigiCertRateLimitError with retry_after."""
        responses.add(
            responses.GET,
            f"{BASE_URL}/order/certificate",
            json={"errors": [{"code": "rate_limit", "message": "Too many requests"}]},
            status=429,
        )

        with pytest.raises(DigiCertRateLimitError) as exc_info:
            list_issued_certificates(DIGICERT_CFG, VAULT_CFG, None)

        assert exc_info.value.retry_after_seconds() == 60.0

    @responses.activate
    def test_server_error_500(self):
        """HTTP 500 raises DigiCertAPIError."""
        responses.add(
            responses.GET,
            f"{BASE_URL}/order/certificate",
            json={"errors": [{"code": "internal_error", "message": "Internal server error"}]},
            status=500,
        )

        with pytest.raises(DigiCertAPIError) as exc_info:
            list_issued_certificates(DIGICERT_CFG, VAULT_CFG, None)

        assert exc_info.value.status_code == 500

    @responses.activate
    def test_forbidden_403(self):
        """HTTP 403 raises DigiCertAuthenticationError."""
        responses.add(
            responses.GET,
            f"{BASE_URL}/certificate/12345",
            json={
                "errors": [
                    {
                        "code": "access_denied",
                        "message": "Insufficient permissions",
                    }
                ]
            },
            status=403,
        )

        with pytest.raises(DigiCertAuthenticationError):
            describe_certificate(DIGICERT_CFG, VAULT_CFG, None, 12345)
