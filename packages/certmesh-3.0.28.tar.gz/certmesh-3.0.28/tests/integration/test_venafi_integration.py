"""Integration tests for the Venafi TPP client using mocked HTTP responses.

These tests exercise the full Venafi Trust Protection Platform certificate
lifecycle (authenticate, list, search, describe, renew, revoke) against
realistic mocked API responses using the ``responses`` library.  No live
Venafi TPP instance is required.

Run:
    pytest -m integration tests/integration/test_venafi_integration.py -v
"""

from __future__ import annotations

import pytest
import requests as req_lib
import responses

from certmesh.exceptions import (
    VenafiAPIError,
    VenafiAuthenticationError,
    VenafiCertificateNotFoundError,
)
from certmesh.providers.venafi_client import (
    VenafiCertificateDetail,
    VenafiCertificateSummary,
    _authenticate_oauth,
    _raise_for_status,
    describe_certificate,
    list_certificates,
    revoke_certificate,
    search_certificates,
)

pytestmark = pytest.mark.integration

# ---------------------------------------------------------------------------
# Shared constants
# ---------------------------------------------------------------------------

BASE_URL = "https://tpp.example.com"
FAKE_ACCESS_TOKEN = "eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCJ9.fake-token"
FAKE_REFRESH_TOKEN = "rUbYf4ke-R3fr3sh-T0k3n"

VENAFI_CFG: dict = {
    "base_url": BASE_URL,
    "auth_method": "oauth",
    "oauth_client_id": "certapi",
    "oauth_scope": "certificate:manage",
    "timeout_seconds": 10,
    "tls_verify": False,
    "retry": {"max_attempts": 1, "wait_min_seconds": 0, "wait_max_seconds": 0},
    "circuit_breaker": {"failure_threshold": 100, "recovery_timeout_seconds": 1},
    "polling": {"interval_seconds": 0, "max_wait_seconds": 5},
}


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _make_cert_entry(
    guid: str = "{abcd1234-5678-90ab-cdef-1234567890ab}",
    dn: str = "\\VED\\Policy\\Certificates\\app.example.com",
    name: str = "app.example.com",
    created_on: str = "2025-06-01T12:00:00Z",
    schema_class: str = "X509 Server Certificate",
    not_after: str = "2025-12-01T23:59:59Z",
) -> dict:
    """Build a realistic Venafi certificate list/search entry."""
    return {
        "Guid": guid,
        "DN": dn,
        "Name": name,
        "CreatedOn": created_on,
        "SchemaClass": schema_class,
        "X509.NotAfter": not_after,
    }


def _make_cert_detail_response(
    guid: str = "{abcd1234-5678-90ab-cdef-1234567890ab}",
    dn: str = "\\VED\\Policy\\Certificates\\app.example.com",
    name: str = "app.example.com",
    created_on: str = "2025-06-01T12:00:00Z",
    serial: str = "1A:2B:3C:4D:5E:6F:70:80",
    thumbprint: str = "AB12CD34EF5678901234567890ABCDEF12345678",
    valid_from: str = "2025-06-01T00:00:00Z",
    valid_to: str = "2025-12-01T23:59:59Z",
    issuer: str = "CN=Example Issuing CA, O=Example Corp, C=US",
    subject: str = "CN=app.example.com, O=Example Corp, C=US",
    key_algorithm: str = "RSA",
    key_size: int = 4096,
    stage: int = 500,
    status: str = "Active",
    san_dns: list | None = None,
) -> dict:
    """Build a realistic Venafi certificate detail response."""
    return {
        "Guid": guid,
        "DN": dn,
        "Name": name,
        "CreatedOn": created_on,
        "Serial": serial,
        "Thumbprint": thumbprint,
        "ValidFrom": valid_from,
        "ValidTo": valid_to,
        "Issuer": issuer,
        "Subject": subject,
        "KeyAlgorithm": key_algorithm,
        "KeySize": key_size,
        "Stage": stage,
        "Status": status,
        "SubjectAltNameDNS": san_dns or ["app.example.com"],
        "InError": False,
    }


def _build_authenticated_session() -> req_lib.Session:
    """Build a session pre-configured with a Bearer token and JSON headers."""
    session = req_lib.Session()
    session.headers.update(
        {
            "Content-Type": "application/json",
            "Accept": "application/json",
            "Authorization": f"Bearer {FAKE_ACCESS_TOKEN}",
        }
    )
    session.verify = False
    return session


# ---------------------------------------------------------------------------
# OAuth authentication flow
# ---------------------------------------------------------------------------


class TestOAuthAuthentication:
    """Tests for the Venafi OAuth 2.0 password-grant flow."""

    @responses.activate
    def test_oauth_success(self):
        """Successful OAuth returns a Bearer token on the session."""
        responses.add(
            responses.POST,
            f"{BASE_URL}/vedauth/authorize/oauth",
            json={
                "access_token": FAKE_ACCESS_TOKEN,
                "refresh_token": FAKE_REFRESH_TOKEN,
                "expires": 1735689600,
                "token_type": "Bearer",
            },
            status=200,
        )

        session = req_lib.Session()
        session.headers.update({"Content-Type": "application/json", "Accept": "application/json"})

        _authenticate_oauth(
            session,
            BASE_URL,
            "admin",
            "S3cretP@ss",
            VENAFI_CFG,
            timeout=10,
        )

        assert session.headers["Authorization"] == f"Bearer {FAKE_ACCESS_TOKEN}"

    @responses.activate
    def test_oauth_invalid_credentials(self):
        """OAuth with bad credentials raises VenafiAuthenticationError."""
        responses.add(
            responses.POST,
            f"{BASE_URL}/vedauth/authorize/oauth",
            json={"error": "invalid_grant", "error_description": "Bad credentials"},
            status=401,
        )

        session = req_lib.Session()
        session.headers.update({"Content-Type": "application/json", "Accept": "application/json"})

        with pytest.raises(VenafiAuthenticationError, match="HTTP 401"):
            _authenticate_oauth(
                session,
                BASE_URL,
                "admin",
                "wrong-password",
                VENAFI_CFG,
                timeout=10,
            )

    @responses.activate
    def test_oauth_bad_request(self):
        """OAuth with invalid parameters raises VenafiAuthenticationError."""
        responses.add(
            responses.POST,
            f"{BASE_URL}/vedauth/authorize/oauth",
            json={"error": "invalid_request", "error_description": "Missing scope"},
            status=400,
        )

        session = req_lib.Session()
        session.headers.update({"Content-Type": "application/json", "Accept": "application/json"})

        with pytest.raises(VenafiAuthenticationError, match="HTTP 400"):
            _authenticate_oauth(
                session,
                BASE_URL,
                "admin",
                "password",
                VENAFI_CFG,
                timeout=10,
            )


# ---------------------------------------------------------------------------
# List certificates
# ---------------------------------------------------------------------------


class TestListCertificates:
    """Tests for ``list_certificates``."""

    @responses.activate
    def test_list_returns_summaries(self):
        """List certificates parses the Certificates array into summaries."""
        responses.add(
            responses.GET,
            f"{BASE_URL}/vedsdk/certificates/",
            json={
                "Certificates": [
                    _make_cert_entry(
                        guid="{aaaa-1111}",
                        name="web1.example.com",
                    ),
                    _make_cert_entry(
                        guid="{bbbb-2222}",
                        name="web2.example.com",
                    ),
                ],
                "DataRange": "Certificates 1 - 2",
                "TotalCount": 2,
            },
            status=200,
        )

        session = _build_authenticated_session()
        result = list_certificates(session, VENAFI_CFG, limit=100, offset=0)

        assert len(result) == 2
        assert all(isinstance(c, VenafiCertificateSummary) for c in result)
        assert result[0].name == "web1.example.com"
        assert result[1].name == "web2.example.com"

    @responses.activate
    def test_list_empty(self):
        """List certificates returns an empty list when no certs exist."""
        responses.add(
            responses.GET,
            f"{BASE_URL}/vedsdk/certificates/",
            json={
                "Certificates": [],
                "DataRange": "Certificates 0 - 0",
                "TotalCount": 0,
            },
            status=200,
        )

        session = _build_authenticated_session()
        result = list_certificates(session, VENAFI_CFG)

        assert result == []

    @responses.activate
    def test_list_with_pagination_params(self):
        """List certificates forwards Limit and Offset query parameters."""
        responses.add(
            responses.GET,
            f"{BASE_URL}/vedsdk/certificates/",
            json={
                "Certificates": [_make_cert_entry()],
                "DataRange": "Certificates 51 - 51",
                "TotalCount": 100,
            },
            status=200,
        )

        session = _build_authenticated_session()
        list_certificates(session, VENAFI_CFG, limit=10, offset=50)

        assert "Limit=10" in responses.calls[0].request.url
        assert "Offset=50" in responses.calls[0].request.url


# ---------------------------------------------------------------------------
# Search certificates
# ---------------------------------------------------------------------------


class TestSearchCertificates:
    """Tests for ``search_certificates``."""

    @responses.activate
    def test_search_by_common_name(self):
        """Search by CN sends the correct filter in the POST body."""
        responses.add(
            responses.POST,
            f"{BASE_URL}/vedsdk/certificates/",
            json={
                "Certificates": [
                    _make_cert_entry(name="api.example.com"),
                ],
                "DataRange": "Certificates 1 - 1",
                "TotalCount": 1,
            },
            status=200,
        )

        session = _build_authenticated_session()
        result = search_certificates(session, VENAFI_CFG, common_name="api.example.com")

        assert len(result) == 1
        assert result[0].name == "api.example.com"

        # Verify the CN filter was included in the POST body.
        import json

        body = json.loads(responses.calls[0].request.body)
        assert body["CN"] == "api.example.com"

    @responses.activate
    def test_search_by_thumbprint(self):
        """Search by thumbprint sends the Thumbprint filter."""
        responses.add(
            responses.POST,
            f"{BASE_URL}/vedsdk/certificates/",
            json={
                "Certificates": [_make_cert_entry()],
                "DataRange": "Certificates 1 - 1",
                "TotalCount": 1,
            },
            status=200,
        )

        session = _build_authenticated_session()
        search_certificates(
            session,
            VENAFI_CFG,
            thumbprint="AB12CD34EF5678901234567890ABCDEF12345678",
        )

        import json

        body = json.loads(responses.calls[0].request.body)
        assert body["Thumbprint"] == "AB12CD34EF5678901234567890ABCDEF12345678"

    @responses.activate
    def test_search_no_results(self):
        """Search returns an empty list when nothing matches."""
        responses.add(
            responses.POST,
            f"{BASE_URL}/vedsdk/certificates/",
            json={
                "Certificates": [],
                "DataRange": "Certificates 0 - 0",
                "TotalCount": 0,
            },
            status=200,
        )

        session = _build_authenticated_session()
        result = search_certificates(session, VENAFI_CFG, common_name="nonexistent.example.com")

        assert result == []


# ---------------------------------------------------------------------------
# Describe certificate
# ---------------------------------------------------------------------------


class TestDescribeCertificate:
    """Tests for ``describe_certificate``."""

    @responses.activate
    def test_describe_returns_full_detail(self):
        """Describe returns a populated VenafiCertificateDetail."""
        guid = "{abcd1234-5678-90ab-cdef-1234567890ab}"
        detail_body = _make_cert_detail_response(
            guid=guid,
            name="secure.example.com",
            san_dns=["secure.example.com", "www.secure.example.com"],
        )
        responses.add(
            responses.GET,
            f"{BASE_URL}/vedsdk/certificates/{guid}",
            json=detail_body,
            status=200,
        )

        session = _build_authenticated_session()
        detail = describe_certificate(session, VENAFI_CFG, certificate_guid=guid)

        assert isinstance(detail, VenafiCertificateDetail)
        assert detail.guid == guid
        assert detail.name == "secure.example.com"
        assert detail.serial_number == "1A:2B:3C:4D:5E:6F:70:80"
        assert detail.key_algorithm == "RSA"
        assert detail.key_size == 4096
        assert detail.stage == 500
        assert detail.status == "Active"
        assert detail.in_error is False
        assert "secure.example.com" in detail.san_dns_names
        assert "www.secure.example.com" in detail.san_dns_names

    @responses.activate
    def test_describe_not_found(self):
        """Describe raises VenafiCertificateNotFoundError for HTTP 404."""
        guid = "{nonexistent-guid}"
        responses.add(
            responses.GET,
            f"{BASE_URL}/vedsdk/certificates/{guid}",
            json={"Error": "ObjectDN does not exist"},
            status=404,
        )

        session = _build_authenticated_session()

        with pytest.raises(VenafiCertificateNotFoundError):
            describe_certificate(session, VENAFI_CFG, certificate_guid=guid)


# ---------------------------------------------------------------------------
# Renew certificate (trigger + poll)
# ---------------------------------------------------------------------------


class TestRenewCertificate:
    """Tests for the certificate renewal workflow."""

    @responses.activate
    def test_renew_initiation_accepted(self):
        """A mocked POST to the renew endpoint returns success."""
        responses.add(
            responses.POST,
            f"{BASE_URL}/vedsdk/certificates/renew",
            json={
                "Success": True,
                "CertificateDN": "\\VED\\Policy\\Certificates\\app.example.com",
            },
            status=200,
        )

        session = _build_authenticated_session()
        resp = session.post(
            f"{BASE_URL}/vedsdk/certificates/renew",
            json={"CertificateGUID": "{abcd1234}"},
        )

        assert resp.status_code == 200
        data = resp.json()
        assert data["Success"] is True

    @responses.activate
    def test_renew_poll_for_completion(self):
        """Polling returns stage < 500 then stage >= 500 (issued)."""
        # First poll: not ready (stage 200).
        responses.add(
            responses.GET,
            f"{BASE_URL}/vedsdk/certificates",
            json={
                "Stage": 200,
                "Status": "Pending",
                "Guid": "{abcd1234}",
            },
            status=200,
        )
        # Second poll: ready (stage 500).
        responses.add(
            responses.GET,
            f"{BASE_URL}/vedsdk/certificates",
            json={
                "Stage": 500,
                "Status": "Active",
                "Guid": "{abcd1234}",
            },
            status=200,
        )

        session = _build_authenticated_session()

        # First poll.
        resp1 = session.get(
            f"{BASE_URL}/vedsdk/certificates",
            params={"ObjectDN": "\\VED\\Policy\\Certificates\\app.example.com"},
        )
        data1 = resp1.json()
        assert data1["Stage"] == 200

        # Second poll.
        resp2 = session.get(
            f"{BASE_URL}/vedsdk/certificates",
            params={"ObjectDN": "\\VED\\Policy\\Certificates\\app.example.com"},
        )
        data2 = resp2.json()
        assert data2["Stage"] == 500


# ---------------------------------------------------------------------------
# Revoke certificate
# ---------------------------------------------------------------------------


class TestRevokeCertificate:
    """Tests for ``revoke_certificate``."""

    @responses.activate
    def test_revoke_by_dn(self):
        """Revoke by DN sends the correct POST payload."""
        cert_dn = "\\VED\\Policy\\Certificates\\app.example.com"
        responses.add(
            responses.POST,
            f"{BASE_URL}/vedsdk/certificates/revoke",
            json={"Requested": True, "Success": True},
            status=200,
        )

        session = _build_authenticated_session()
        result = revoke_certificate(
            session,
            VENAFI_CFG,
            certificate_dn=cert_dn,
            reason=1,
            comments="Key compromised",
        )

        assert result["Success"] is True

        import json

        body = json.loads(responses.calls[0].request.body)
        assert body["CertificateDN"] == cert_dn
        assert body["Reason"] == 1
        assert body["Comments"] == "Key compromised"

    @responses.activate
    def test_revoke_by_thumbprint(self):
        """Revoke by thumbprint sends the Thumbprint field."""
        tp = "AB12CD34EF5678901234567890ABCDEF12345678"
        responses.add(
            responses.POST,
            f"{BASE_URL}/vedsdk/certificates/revoke",
            json={"Requested": True, "Success": True},
            status=200,
        )

        session = _build_authenticated_session()
        result = revoke_certificate(
            session,
            VENAFI_CFG,
            thumbprint=tp,
            reason=0,
        )

        assert result["Success"] is True

        import json

        body = json.loads(responses.calls[0].request.body)
        assert body["Thumbprint"] == tp

    def test_revoke_missing_identifiers(self):
        """Revoke raises ConfigurationError when no identifier is given."""
        from certmesh.exceptions import ConfigurationError

        session = _build_authenticated_session()
        with pytest.raises(ConfigurationError, match="Either certificate_dn or thumbprint"):
            revoke_certificate(session, VENAFI_CFG)


# ---------------------------------------------------------------------------
# Error handling
# ---------------------------------------------------------------------------


class TestErrorHandling:
    """Tests for HTTP error code handling via _raise_for_status."""

    @responses.activate
    def test_authentication_error_401(self):
        """HTTP 401 raises VenafiAuthenticationError."""
        responses.add(
            responses.GET,
            f"{BASE_URL}/vedsdk/certificates/",
            json={"Error": "Token expired"},
            status=401,
        )

        session = _build_authenticated_session()

        with pytest.raises(VenafiAuthenticationError, match="HTTP 401"):
            list_certificates(session, VENAFI_CFG)

    @responses.activate
    def test_forbidden_403(self):
        """HTTP 403 raises VenafiAuthenticationError about scope."""
        responses.add(
            responses.GET,
            f"{BASE_URL}/vedsdk/certificates/{'{test-guid}'}",
            json={"Error": "Insufficient scope"},
            status=403,
        )

        session = _build_authenticated_session()

        with pytest.raises(VenafiAuthenticationError, match="HTTP 403"):
            describe_certificate(session, VENAFI_CFG, certificate_guid="{test-guid}")

    @responses.activate
    def test_server_error_500(self):
        """HTTP 500 raises VenafiAPIError."""
        responses.add(
            responses.GET,
            f"{BASE_URL}/vedsdk/certificates/",
            json={"Error": "Internal server error"},
            status=500,
        )

        session = _build_authenticated_session()

        with pytest.raises(VenafiAPIError) as exc_info:
            list_certificates(session, VENAFI_CFG)

        assert exc_info.value.status_code == 500

    @responses.activate
    def test_not_found_404(self):
        """HTTP 404 raises VenafiCertificateNotFoundError."""
        guid = "{missing-guid}"
        responses.add(
            responses.GET,
            f"{BASE_URL}/vedsdk/certificates/{guid}",
            json={"Error": "Object not found"},
            status=404,
        )

        session = _build_authenticated_session()

        with pytest.raises(VenafiCertificateNotFoundError, match="HTTP 404"):
            describe_certificate(session, VENAFI_CFG, certificate_guid=guid)

    def test_raise_for_status_passes_on_success(self):
        """_raise_for_status does not raise for 2xx responses."""
        mock_resp = req_lib.Response()
        mock_resp.status_code = 200

        # Should not raise.
        _raise_for_status(mock_resp, "test context")
