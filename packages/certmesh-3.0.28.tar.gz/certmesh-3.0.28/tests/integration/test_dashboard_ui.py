"""
Playwright-based integration tests for the certmesh web UI dashboard.

Starts the FastAPI application with mocked certificate providers, injects an
authenticated session cookie, and uses a headless Chromium browser to verify
that the dashboard renders correctly.  Screenshots are saved to the
``screenshots/`` directory in the project root for visual review.

Requires ``pytest-playwright`` and Chromium::

    pip install pytest-playwright
    playwright install chromium

Run with::

    pytest tests/integration/test_dashboard_ui.py -v -m integration
"""

from __future__ import annotations

import os
import socket
import threading
import time
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any

import pytest
import uvicorn
from playwright.sync_api import sync_playwright
from starlette.requests import Request

pytestmark = pytest.mark.integration

# Path to pre-installed Chromium (falls back to default if not found)
_CHROMIUM_PATH = "/root/.cache/ms-playwright/chromium-1194/chrome-linux/chrome"

# ---------------------------------------------------------------------------
# Test certificate data
# ---------------------------------------------------------------------------

_NOW = datetime.now(tz=timezone.utc)

MOCK_CERTIFICATES: list[dict[str, Any]] = [
    {
        "common_name": "api.example.com",
        "serial_number": "0A:1B:2C:3D:4E:5F:60:71",
        "not_after": (_NOW + timedelta(days=365)).strftime("%Y-%m-%dT%H:%M:%SZ"),
        "provider": "digicert",
        "status": "issued",
    },
    {
        "common_name": "checkout.example.com",
        "serial_number": "1B:2C:3D:4E:5F:60:71:82",
        "not_after": (_NOW + timedelta(days=5)).strftime("%Y-%m-%dT%H:%M:%SZ"),
        "provider": "digicert",
        "status": "issued",
    },
    {
        "common_name": "auth.example.com",
        "serial_number": "2C:3D:4E:5F:60:71:82:93",
        "not_after": (_NOW + timedelta(days=200)).strftime("%Y-%m-%dT%H:%M:%SZ"),
        "provider": "venafi",
        "status": "issued",
    },
    {
        "common_name": "legacy.example.com",
        "serial_number": "3D:4E:5F:60:71:82:93:A4",
        "not_after": (_NOW - timedelta(days=10)).strftime("%Y-%m-%dT%H:%M:%SZ"),
        "provider": "venafi",
        "status": "expired",
    },
    {
        "common_name": "payments.example.com",
        "serial_number": "4E:5F:60:71:82:93:A4:B5",
        "not_after": (_NOW + timedelta(days=120)).strftime("%Y-%m-%dT%H:%M:%SZ"),
        "provider": "acm",
        "status": "issued",
    },
    {
        "common_name": "cdn.example.com",
        "serial_number": "5F:60:71:82:93:A4:B5:C6",
        "not_after": (_NOW + timedelta(days=90)).strftime("%Y-%m-%dT%H:%M:%SZ"),
        "provider": "acm",
        "status": "issued",
    },
    {
        "common_name": "internal.example.com",
        "serial_number": "60:71:82:93:A4:B5:C6:D7",
        "not_after": (_NOW + timedelta(days=250)).strftime("%Y-%m-%dT%H:%M:%SZ"),
        "provider": "vault_pki",
        "status": "issued",
    },
    {
        "common_name": "staging.example.com",
        "serial_number": "71:82:93:A4:B5:C6:D7:E8",
        "not_after": (_NOW + timedelta(days=25)).strftime("%Y-%m-%dT%H:%M:%SZ"),
        "provider": "vault_pki",
        "status": "issued",
    },
]


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _free_port() -> int:
    """Return a free TCP port on localhost."""
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        s.bind(("127.0.0.1", 0))
        return s.getsockname()[1]


SESSION_SECRET = "a" * 64  # 64-char secret for tests


_ENV_OVERRIDES = {
    "CM_DASHBOARD_ENABLED": "true",
    "CM_DASHBOARD_SESSION_SECRET": SESSION_SECRET,
    "CM_OAUTH2_ISSUER_URL": "https://login.example.com/oauth2",
    "CM_OAUTH2_CLIENT_ID": "test-client-id",
    "CM_DASHBOARD_REDIRECT_URI": "http://localhost:8000/dashboard/callback",
}


def _create_test_app() -> Any:
    """Create a FastAPI app with dashboard enabled and mocked providers."""
    # Set env vars persistently — they must be present during lifespan init
    for k, v in _ENV_OVERRIDES.items():
        os.environ[k] = v

    from certmesh.api.app import create_app

    return create_app()


def _create_session_cookie() -> str:
    """Create a valid signed session cookie for test authentication."""
    from certmesh.api.oauth2_flow import SessionManager

    sm = SessionManager(secret=SESSION_SECRET)
    session_data = {
        "user": {
            "sub": "test-user-001",
            "name": "Test User",
            "email": "test@example.com",
        },
        "csrf_token": "test-csrf-token-abc123",
    }
    return sm.create_session(session_data)


async def _mock_api_certificates(request: Request) -> Any:
    """Replacement for api_certificates that returns mock data."""
    from fastapi.responses import JSONResponse

    # Check session
    session_manager = request.app.state.session_manager
    cookie = request.cookies.get("cm_session")
    if not cookie:
        return JSONResponse(
            content={"detail": "Not authenticated"},
            status_code=401,
        )
    session = session_manager.load_session(cookie)
    if not session or "user" not in session:
        return JSONResponse(
            content={"detail": "Not authenticated"},
            status_code=401,
        )

    expiring = sum(
        1
        for c in MOCK_CERTIFICATES
        if 0
        < (
            datetime.strptime(c["not_after"], "%Y-%m-%dT%H:%M:%SZ").replace(tzinfo=timezone.utc)
            - _NOW
        ).days
        <= 30
    )
    expired = sum(
        1
        for c in MOCK_CERTIFICATES
        if (
            datetime.strptime(c["not_after"], "%Y-%m-%dT%H:%M:%SZ").replace(tzinfo=timezone.utc)
            - _NOW
        ).days
        < 0
    )

    return JSONResponse(
        content={
            "certificates": MOCK_CERTIFICATES,
            "errors": [],
            "total": len(MOCK_CERTIFICATES),
            "expiring": expiring,
            "expired": expired,
        }
    )


async def _mock_api_timeline(request: Request) -> Any:
    """Replacement for api_timeline that returns mock timeline data."""
    from fastapi.responses import JSONResponse

    session_manager = request.app.state.session_manager
    cookie = request.cookies.get("cm_session")
    if not cookie:
        return JSONResponse(content={"detail": "Not authenticated"}, status_code=401)
    session = session_manager.load_session(cookie)
    if not session or "user" not in session:
        return JSONResponse(content={"detail": "Not authenticated"}, status_code=401)

    now = datetime.now(tz=timezone.utc)
    buckets: dict[str, list[dict[str, Any]]] = {
        "expired": [],
        "critical": [],
        "warning": [],
        "attention": [],
        "healthy": [],
        "unknown": [],
    }

    for cert in MOCK_CERTIFICATES:
        expiry = datetime.strptime(cert["not_after"], "%Y-%m-%dT%H:%M:%SZ").replace(
            tzinfo=timezone.utc
        )
        days = (expiry - now).days
        if days < 0:
            buckets["expired"].append(cert)
        elif days < 7:
            buckets["critical"].append(cert)
        elif days < 30:
            buckets["warning"].append(cert)
        elif days < 60:
            buckets["attention"].append(cert)
        else:
            buckets["healthy"].append(cert)

    summary = {k: len(v) for k, v in buckets.items()}

    return JSONResponse(
        content={
            "buckets": buckets,
            "summary": summary,
            "total": len(MOCK_CERTIFICATES),
        }
    )


async def _mock_inject_test_logs(request: Request) -> Any:
    """Inject sample log entries into the buffer for screenshot tests."""
    import time as _time

    from fastapi.responses import JSONResponse

    from certmesh.api.log_buffer import LogEntry

    log_buffer = getattr(request.app.state, "log_buffer", None)
    if log_buffer is None:
        return JSONResponse(content={"injected": 0}, status_code=503)

    now = _time.time()
    sample_entries = [
        LogEntry(
            timestamp=now - 12,
            level="INFO",
            logger_name="certmesh.api.app",
            message="Application startup complete — 4 Uvicorn workers ready",
        ),
        LogEntry(
            timestamp=now - 10,
            level="INFO",
            logger_name="certmesh.backends.digicert",
            message="DigiCert provider initialised (org_id=12345, account=Production)",
            extra={"provider": "digicert"},
        ),
        LogEntry(
            timestamp=now - 8,
            level="INFO",
            logger_name="certmesh.backends.venafi",
            message="Venafi TPP connection established (https://tpp.corp.example.com)",
            extra={"provider": "venafi"},
        ),
        LogEntry(
            timestamp=now - 7,
            level="WARNING",
            logger_name="certmesh.backends.acm",
            message="ACM certificate arn:aws:acm:eu-west-2:123456789:certificate/abc123 expires in 5 days",
            extra={"provider": "acm", "cert_id": "abc123", "days_remaining": 5},
        ),
        LogEntry(
            timestamp=now - 6,
            level="INFO",
            logger_name="certmesh.renewal",
            message="Auto-renewal triggered for checkout.example.com (Venafi TPP)",
            extra={"provider": "venafi", "common_name": "checkout.example.com"},
        ),
        LogEntry(
            timestamp=now - 5,
            level="ERROR",
            logger_name="certmesh.backends.vault_pki",
            message="Vault PKI issue failed: permission denied on mount pki/",
            extra={"provider": "vault_pki", "mount": "pki/"},
        ),
        LogEntry(
            timestamp=now - 4,
            level="INFO",
            logger_name="certmesh.renewal",
            message="Certificate renewed successfully: checkout.example.com (serial=1B:2C:3D:4E)",
            extra={"provider": "venafi", "serial": "1B:2C:3D:4E"},
        ),
        LogEntry(
            timestamp=now - 3,
            level="DEBUG",
            logger_name="certmesh.api.routes",
            message="GET /dashboard/api/certificates — 200 OK (8 certificates, 42ms)",
        ),
        LogEntry(
            timestamp=now - 2,
            level="WARNING",
            logger_name="certmesh.circuit_breaker",
            message="Circuit breaker OPEN for digicert provider — 3 consecutive failures",
            extra={"provider": "digicert", "failures": 3},
        ),
        LogEntry(
            timestamp=now - 1,
            level="INFO",
            logger_name="certmesh.api.dashboard_state",
            message="Dashboard state snapshot saved to S3 (s3://certmesh-state/dashboard/snapshot.json)",
        ),
    ]

    for entry in sample_entries:
        log_buffer.append(entry)

    return JSONResponse(content={"injected": len(sample_entries)})


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------

SCREENSHOTS_DIR = Path(__file__).resolve().parent.parent.parent / "screenshots"


@pytest.fixture(scope="module")
def dashboard_server():
    """Start a uvicorn server with the dashboard app in a background thread.

    Patches the certificate and timeline API endpoints to return mock data
    so no real provider credentials are needed.

    Yields the base URL (e.g. ``http://127.0.0.1:<port>``).
    """
    SCREENSHOTS_DIR.mkdir(exist_ok=True)

    port = _free_port()
    app = _create_test_app()

    # Remove the real certificate/timeline routes and add mock replacements.
    # This ensures the mock endpoints are used instead of the real provider calls.
    app.router.routes = [
        r
        for r in app.router.routes
        if getattr(r, "path", "") not in ("/dashboard/api/certificates", "/dashboard/api/timeline")
    ]
    app.add_api_route(
        "/dashboard/api/certificates",
        _mock_api_certificates,
        methods=["GET"],
    )
    app.add_api_route(
        "/dashboard/api/_test/inject-logs",
        _mock_inject_test_logs,
        methods=["POST"],
    )
    app.add_api_route(
        "/dashboard/api/timeline",
        _mock_api_timeline,
        methods=["GET"],
    )

    config = uvicorn.Config(
        app,
        host="127.0.0.1",
        port=port,
        log_level="warning",
    )
    server = uvicorn.Server(config)
    thread = threading.Thread(target=server.run, daemon=True)
    thread.start()

    # Wait for server to be ready
    base_url = f"http://127.0.0.1:{port}"
    deadline = time.monotonic() + 10
    while time.monotonic() < deadline:
        try:
            with socket.create_connection(("127.0.0.1", port), timeout=1):
                break
        except OSError:
            time.sleep(0.1)
    else:
        pytest.fail(f"Dashboard server did not start within 10 seconds on port {port}")

    yield base_url

    server.should_exit = True
    thread.join(timeout=5)


@pytest.fixture()
def auth_cookie():
    """Return a valid session cookie value for test authentication."""
    return _create_session_cookie()


@pytest.fixture(scope="module")
def browser():
    """Launch a headless Chromium browser for the test module."""
    executable = _CHROMIUM_PATH if Path(_CHROMIUM_PATH).exists() else None
    pw = sync_playwright().start()
    browser_instance = pw.chromium.launch(
        headless=True,
        executable_path=executable,
    )
    yield browser_instance
    browser_instance.close()
    pw.stop()


@pytest.fixture()
def page(browser):
    """Create a new browser page (tab) for each test.

    Blocks all external CDN requests so the browser doesn't hang waiting
    for DNS resolution in sandboxed/offline environments.
    """
    context = browser.new_context()
    pg = context.new_page()

    def _block_external(route):
        """Abort requests to external CDN hosts."""
        route.abort()

    # Block CDN resources that can't be reached in sandboxed environments
    pg.route("**://cdn.jsdelivr.net/**", _block_external)
    pg.route("**://unpkg.com/**", _block_external)
    pg.route("**://fonts.googleapis.com/**", _block_external)
    pg.route("**://fonts.gstatic.com/**", _block_external)

    yield pg
    pg.close()
    context.close()


# ---------------------------------------------------------------------------
# Tests
# ---------------------------------------------------------------------------


class TestDashboardScreenshots:
    """Browser-based tests that render the dashboard and capture screenshots."""

    def test_dashboard_renders_with_certificates(self, dashboard_server, auth_cookie, page):
        """Load the dashboard, verify summary cards render, take desktop screenshot."""
        page.set_viewport_size({"width": 1920, "height": 1080})

        # Set the session cookie before navigating (secure=false for localhost)
        page.context.add_cookies(
            [
                {
                    "name": "cm_session",
                    "value": auth_cookie,
                    "domain": "127.0.0.1",
                    "path": "/dashboard",
                    "httpOnly": True,
                    "secure": False,
                    "sameSite": "Lax",
                }
            ]
        )

        page.goto(f"{dashboard_server}/dashboard", wait_until="domcontentloaded")
        page.wait_for_timeout(2000)

        # Wait for JS to populate the certificate table
        page.wait_for_selector("#certTableBody tr td", timeout=10000)

        # Verify summary cards are present
        assert page.locator("#totalCount").is_visible()
        assert page.locator("#expiringCount").is_visible()
        assert page.locator("#expiredCount").is_visible()
        assert page.locator("#errorCount").is_visible()

        # Verify certificate table has rows
        rows = page.locator("#certTableBody tr")
        assert rows.count() >= 1

        # Take desktop screenshot
        page.screenshot(
            path=str(SCREENSHOTS_DIR / "dashboard-desktop.png"),
            full_page=True,
        )

    def test_dashboard_responsive_tablet(self, dashboard_server, auth_cookie, page):
        """Tablet viewport — verify layout adapts, take screenshot."""
        page.set_viewport_size({"width": 768, "height": 1024})

        page.context.add_cookies(
            [
                {
                    "name": "cm_session",
                    "value": auth_cookie,
                    "domain": "127.0.0.1",
                    "path": "/dashboard",
                    "httpOnly": True,
                    "secure": False,
                    "sameSite": "Lax",
                }
            ]
        )

        page.goto(f"{dashboard_server}/dashboard", wait_until="domcontentloaded")
        page.wait_for_timeout(2000)
        page.wait_for_selector("#certTableBody tr td", timeout=10000)

        # Summary cards should still be visible
        assert page.locator("#totalCount").is_visible()

        page.screenshot(
            path=str(SCREENSHOTS_DIR / "dashboard-tablet.png"),
            full_page=True,
        )

    def test_dashboard_responsive_mobile(self, dashboard_server, auth_cookie, page):
        """Mobile viewport — take screenshot."""
        page.set_viewport_size({"width": 375, "height": 812})

        page.context.add_cookies(
            [
                {
                    "name": "cm_session",
                    "value": auth_cookie,
                    "domain": "127.0.0.1",
                    "path": "/dashboard",
                    "httpOnly": True,
                    "secure": False,
                    "sameSite": "Lax",
                }
            ]
        )

        page.goto(f"{dashboard_server}/dashboard", wait_until="domcontentloaded")
        page.wait_for_timeout(2000)
        page.wait_for_selector("#certTableBody tr td", timeout=10000)

        page.screenshot(
            path=str(SCREENSHOTS_DIR / "dashboard-mobile.png"),
            full_page=True,
        )

    def test_certificate_search(self, dashboard_server, auth_cookie, page):
        """Type in search box, verify table filters to matching certificates."""
        page.set_viewport_size({"width": 1920, "height": 1080})

        page.context.add_cookies(
            [
                {
                    "name": "cm_session",
                    "value": auth_cookie,
                    "domain": "127.0.0.1",
                    "path": "/dashboard",
                    "httpOnly": True,
                    "secure": False,
                    "sameSite": "Lax",
                }
            ]
        )

        page.goto(f"{dashboard_server}/dashboard", wait_until="domcontentloaded")
        page.wait_for_timeout(2000)
        page.wait_for_selector("#certTableBody tr td", timeout=10000)

        # Count rows before search (JS re-renders tbody on filter)
        initial_rows = page.locator("#certTableBody tr").count()
        assert initial_rows >= 2  # We have 8 mock certificates

        # Search for a specific certificate
        search_input = page.locator("#certSearch")
        search_input.fill("api.example.com")

        # Wait for debounce (250ms) + render
        page.wait_for_timeout(500)

        # JS replaces tbody innerHTML, so count total rows after filter
        filtered_rows = page.locator("#certTableBody tr").count()
        assert filtered_rows >= 1
        assert filtered_rows < initial_rows

    def test_provider_tab_switching(self, dashboard_server, auth_cookie, page):
        """Click provider tabs, verify table updates to show only that provider."""
        page.set_viewport_size({"width": 1920, "height": 1080})

        page.context.add_cookies(
            [
                {
                    "name": "cm_session",
                    "value": auth_cookie,
                    "domain": "127.0.0.1",
                    "path": "/dashboard",
                    "httpOnly": True,
                    "secure": False,
                    "sameSite": "Lax",
                }
            ]
        )

        page.goto(f"{dashboard_server}/dashboard", wait_until="domcontentloaded")
        page.wait_for_timeout(2000)
        page.wait_for_selector("#certTableBody tr td", timeout=10000)

        # Click DigiCert tab (use button selector to avoid matching table rows)
        digicert_tab = page.locator('#providerTabs button[data-provider="digicert"]')
        digicert_tab.click()
        page.wait_for_timeout(300)

        # JS replaces tbody on tab switch — count total rows
        filtered_rows = page.locator("#certTableBody tr").count()
        assert filtered_rows == 2  # 2 DigiCert certs

    def test_expiry_timeline_renders(self, dashboard_server, auth_cookie, page):
        """Verify timeline progress bars are present and have content."""
        page.set_viewport_size({"width": 1920, "height": 1080})

        page.context.add_cookies(
            [
                {
                    "name": "cm_session",
                    "value": auth_cookie,
                    "domain": "127.0.0.1",
                    "path": "/dashboard",
                    "httpOnly": True,
                    "secure": False,
                    "sameSite": "Lax",
                }
            ]
        )

        page.goto(f"{dashboard_server}/dashboard", wait_until="domcontentloaded")
        page.wait_for_timeout(2000)

        # Wait for timeline to populate
        page.wait_for_timeout(2000)

        # Verify timeline section exists
        assert page.locator("#timelineContent").is_visible()
        assert page.locator("#barExpired").is_visible()
        assert page.locator("#barHealthy").is_visible()

    def test_login_page_renders(self, dashboard_server, page):
        """Visit login page directly, verify SSO button, take screenshot."""
        page.set_viewport_size({"width": 1920, "height": 1080})

        page.goto(f"{dashboard_server}/dashboard/login", wait_until="domcontentloaded")
        page.wait_for_timeout(1000)

        # Verify login page elements
        assert page.locator("text=certmesh").first.is_visible()
        assert page.locator("text=Sign in with SSO").is_visible()

        page.screenshot(
            path=str(SCREENSHOTS_DIR / "login-page.png"),
            full_page=True,
        )

    def test_live_logs_panel(self, dashboard_server, auth_cookie, page):
        """Expand Live Logs panel with sample entries, take screenshot."""
        import httpx

        page.set_viewport_size({"width": 1920, "height": 1080})

        page.context.add_cookies(
            [
                {
                    "name": "cm_session",
                    "value": auth_cookie,
                    "domain": "127.0.0.1",
                    "path": "/dashboard",
                    "httpOnly": True,
                    "secure": False,
                    "sameSite": "Lax",
                }
            ]
        )

        # Inject sample log entries into the buffer via the test endpoint
        httpx.post(
            f"{dashboard_server}/dashboard/api/_test/inject-logs",
            cookies={"cm_session": auth_cookie},
        )

        page.goto(f"{dashboard_server}/dashboard", wait_until="domcontentloaded")
        page.wait_for_timeout(2000)
        page.wait_for_selector("#certTableBody tr td", timeout=10000)

        # Expand the Live Logs panel (click the collapse toggle button)
        log_toggle = page.locator('#logPanel [data-bs-toggle="collapse"]')
        log_toggle.click()

        # Wait for Bootstrap collapse animation + xterm.js init + SSE connect + rendering
        page.wait_for_timeout(5000)

        # Verify the terminal container is visible
        assert page.locator("#logTerminal").is_visible()

        # The Bootstrap collapse event may fire before Playwright returns
        # control. Manually trigger xterm.js init if needed.
        page.evaluate("""() => {
            var container = document.getElementById('logTerminal');
            if (container && container.children.length === 0 && typeof Terminal !== 'undefined') {
                var term = new Terminal({
                    cursorBlink: false,
                    disableStdin: true,
                    fontSize: 13,
                    fontFamily: 'Menlo, Monaco, Consolas, monospace',
                    scrollback: 1000,
                    convertEol: true,
                    theme: { background: '#1e1e2e', foreground: '#cdd6f4' }
                });
                term.open(container);
                if (typeof FitAddon !== 'undefined') {
                    var fa = new FitAddon.FitAddon();
                    term.loadAddon(fa);
                    fa.fit();
                }
                // Write the buffered log entries via REST API
                fetch('/dashboard/api/logs', { credentials: 'same-origin' })
                    .then(r => r.json())
                    .then(data => {
                        var colors = {
                            ERROR: '\\x1b[1;31m', WARNING: '\\x1b[1;33m',
                            INFO: '\\x1b[32m', DEBUG: '\\x1b[90m'
                        };
                        var reset = '\\x1b[0m';
                        (data.logs || []).forEach(e => {
                            var c = colors[e.level] || '';
                            var ts = new Date(e.timestamp).toISOString().substr(11, 8) + 'Z';
                            var logger = e.logger || '';
                            var prov = e.provider ? ' \\x1b[35m<' + e.provider + '>' + reset : '';
                            var line = '\\x1b[90m' + ts + reset + ' '
                                + c + (e.level || 'INFO').padEnd(8) + reset + ' '
                                + '\\x1b[36m[' + logger + ']' + reset
                                + prov + ' ' + e.message + '\\r\\n';
                            term.write(line);
                        });
                    });
            }
        }""")
        page.wait_for_timeout(2000)

        page.screenshot(
            path=str(SCREENSHOTS_DIR / "dashboard-live-logs.png"),
            full_page=True,
        )

    def test_auto_redirect_to_sso(self, dashboard_server):
        """Visit /dashboard without session — should get a 302 redirect to auth/start."""
        import httpx

        # Use httpx instead of the browser to avoid following the redirect
        # chain to the external OAuth2 provider URL (which is unreachable).
        r = httpx.get(
            f"{dashboard_server}/dashboard",
            follow_redirects=False,
        )
        assert r.status_code == 302
        location = r.headers.get("location", "")
        assert "/dashboard/auth/start" in location
