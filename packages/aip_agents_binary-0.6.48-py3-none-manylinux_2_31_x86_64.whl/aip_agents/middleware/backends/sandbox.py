"""E2B sandbox filesystem backend implementation.

Authors:
    Christian Trisno Sen Long Chen (christian.t.s.l.chen@gdplabs.id)
"""

from __future__ import annotations

import asyncio
import concurrent.futures
import fnmatch
import json
from pathlib import Path, PurePosixPath
from typing import Any, cast

from aip_agents.middleware.backends.protocol import (
    BackendProtocol,
    EditResult,
    ExecuteResult,
    FileInfo,
    GrepMatch,
    WriteResult,
)
from aip_agents.middleware.backends.utils import (
    format_content_with_line_numbers,
    perform_string_replacement,
)
from aip_agents.sandbox.defaults import DEFAULT_SANDBOX_TEMPLATE
from aip_agents.sandbox.e2b_runtime import E2BSandboxRuntime

__all__ = ["SandboxBackend"]


class SandboxBackend(BackendProtocol):
    """BackendProtocol implementation backed by E2B sandbox files API."""

    def __init__(
        self,
        template: str | None = DEFAULT_SANDBOX_TEMPLATE,
        base_dir: str = "/workspace",
        allow_execute: bool = True,
        timeout_seconds: int = 300,
        auto_build_template: bool = True,
        runtime: E2BSandboxRuntime | None = None,
    ) -> None:
        """Initialize sandbox backend.

        Args:
            template: E2B template ID. Defaults to ``DEFAULT_SANDBOX_TEMPLATE``
                (``"aip-agents-sandbox-v1"``). If that template fails to create,
                the runtime falls back to E2B's default code-interpreter template.
                Pass ``None`` to always use E2B's default template directly.
                The template must include a running Jupyter kernel on port 49999;
                otherwise ``execute`` calls will fail with a "port is not open"
                502 error.
            base_dir: Base workspace directory inside sandbox.
            allow_execute: Whether execute is enabled.
            timeout_seconds: Default runtime execution timeout.
            auto_build_template: If True and the requested template returns 404,
                automatically build it before falling back to the default sandbox.
                Building can take several minutes. Defaults to False.
            runtime: Optional injected runtime for testing or sharing.
        """
        self.template = template
        self.base_dir = base_dir.rstrip("/") or "/"
        self.allow_execute = allow_execute
        self.timeout_seconds = timeout_seconds
        self.auto_build_template = auto_build_template
        self._runtime = runtime
        self._runtime_lock = asyncio.Lock()
        self._runtime_loop: asyncio.AbstractEventLoop | None = None
        self._base_dir_initialized = False
        self._files_client: Any | None = None
        self._capture_runtime_loop()

    def _capture_runtime_loop(self) -> None:
        """Capture the current event loop if one is running, for use in _run_sync."""
        try:
            loop = asyncio.get_running_loop()
        except RuntimeError:
            return
        if loop.is_closed():
            return
        self._runtime_loop = loop

    @property
    def runtime(self) -> E2BSandboxRuntime:
        """Get initialized runtime.

        Raises:
            RuntimeError: If runtime was not initialized yet.
        """
        if self._runtime is None:
            raise RuntimeError("Runtime not initialized.")
        return self._runtime

    async def _ensure_runtime(self) -> E2BSandboxRuntime:
        """Create and initialize the E2B sandbox runtime lazily.

        Creates a new ``E2BSandboxRuntime`` the first time it is called and
        caches the instance for subsequent calls.  After the runtime is
        available the method also ensures that ``base_dir`` has been created
        inside the sandbox (idempotent, guarded by ``_base_dir_initialized``).
        All state mutations are serialised through ``_runtime_lock`` to avoid
        races in concurrent async callers.

        Returns:
            The initialised :class:`E2BSandboxRuntime` instance.
        """
        self._capture_runtime_loop()

        if self._runtime is None:
            async with self._runtime_lock:
                if self._runtime is None:
                    self._runtime = E2BSandboxRuntime(
                        template=self.template,
                        auto_build_template=self.auto_build_template,
                    )

        if not self._base_dir_initialized:
            async with self._runtime_lock:
                if not self._base_dir_initialized:
                    files = await self._get_files_client()
                    await files.make_dir(self.base_dir)
                    self._base_dir_initialized = True
        return self.runtime

    async def _get_files_client(self) -> Any:
        """Get the E2B files client from runtime, initializing if needed.

        This method retrieves the files client from the E2B sandbox runtime. The files
        client provides filesystem operations like read, write, list, etc. If the
        files client isn't directly available on the runtime, it triggers a lightweight
        ``true`` command to initialize the sandbox and then retrieves the client.

        The result is cached on the instance so that repeat calls never re-enter the
        sandbox initialization path.  Without caching, every ``_read_file_bytes`` call
        from ``ExecuteTool`` would invoke ``execute_command("true")`` on the
        ``AsyncSandbox`` object from a different asyncio event loop (because
        ``_read_file_bytes`` is synchronous and uses ``_run_async_in_thread``), causing
        ``asyncio.locks.Event is bound to a different event loop`` warnings and
        unnecessary command-stream round-trips.

        Returns:
            The E2B files client object for performing filesystem operations.

        Raises:
            RuntimeError: If the sandbox or files client cannot be initialized.

        Example:
            >>> files_client = await backend._get_files_client()
            >>> content = await files_client.read("/workspace/file.txt")
        """
        if self._files_client is not None:
            return self._files_client

        runtime = self.runtime
        files = getattr(runtime, "files", None)
        if files is not None:
            self._files_client = files
            return self._files_client

        runtime_any = cast(Any, runtime)
        if isinstance(runtime_any, E2BSandboxRuntime):
            await runtime_any.execute_command("true", timeout=self.timeout_seconds)
        else:
            await runtime.execute("pass", timeout=self.timeout_seconds)
        sandbox = getattr(runtime, "_sandbox", None)
        if sandbox is None or getattr(sandbox, "files", None) is None:
            raise RuntimeError("Sandbox files client is not available")
        self._files_client = sandbox.files
        return self._files_client

    def _resolve_path(self, path: str) -> str:
        """Resolve a given path to an absolute path within base_dir.

        This method ensures all paths are resolved within the sandbox's base_dir
        to prevent directory traversal attacks. It handles various input formats
        including relative paths, absolute paths, and paths containing parent
        directory references ("..").

        The security check uses Path.relative_to() which raises ValueError if the
        resolved path is not a subpath of base_dir, effectively blocking traversal
        attempts like "../../../etc/passwd".

        Args:
            path: The input path to resolve. Can be:
                - Relative path (e.g., "subdir/file.txt")
                - Absolute path within base_dir (e.g., "/workspace/subdir/file.txt")
                - Root reference ("/")
                - Paths with parent references (e.g., "../file.txt") - will be blocked

        Returns:
            A normalized absolute path string within base_dir.

        Raises:
            ValueError: If the path escapes base_dir through directory traversal
                (e.g., using ".." to navigate above the workspace root).

        Examples:
            >>> backend = SandboxBackend(base_dir="/workspace")

            # Relative paths are resolved against base_dir
            >>> backend._resolve_path("subdir/file.txt")
            '/workspace/subdir/file.txt'

            # Absolute paths within base_dir are preserved
            >>> backend._resolve_path("/workspace/subdir/file.txt")
            '/workspace/subdir/file.txt'

            # Root reference returns base_dir
            >>> backend._resolve_path("/")
            '/workspace'

            # Parent directory references within bounds are normalized
            >>> backend._resolve_path("subdir/../file.txt")
            '/workspace/file.txt'

            # Path traversal attempts raise ValueError
            >>> backend._resolve_path("../../../etc/passwd")
            ValueError: Path escapes base_dir: '../../../etc/passwd'

            >>> backend._resolve_path("/etc/passwd")
            ValueError: Path escapes base_dir: '/etc/passwd'

        Note:
            This method is critical for security. Never skip the relative_to()
            check as it prevents access to files outside the sandbox workspace.
        """
        base_path = Path(self.base_dir).resolve(strict=False)
        if path == "/":
            candidate_path = base_path
        elif path.startswith(f"{self.base_dir}/") or path == self.base_dir:
            candidate_path = Path(path)
        elif Path(path).is_absolute() or path.startswith("/"):
            candidate_path = base_path / path.lstrip("/")
        else:
            candidate_path = base_path / path

        resolved_path = candidate_path.resolve(strict=False)

        try:
            resolved_path.relative_to(base_path)
        except ValueError as error:
            raise ValueError(f"Path escapes base_dir: {path!r}") from error

        return resolved_path.as_posix()

    def _to_relative_path(self, path: str) -> str:
        """Convert an absolute sandbox path to a base_dir-relative path.

        This method strips the base_dir prefix from absolute paths to produce
        relative paths that are portable and consistent across different backends.
        It's used to normalize paths returned by filesystem operations.

        Args:
            path: An absolute path within the sandbox (e.g., "/workspace/file.txt").

        Returns:
            A relative path string with base_dir removed. Returns "/" if the path
            equals base_dir, or the original path if it doesn't start with base_dir.

        Examples:
            >>> backend = SandboxBackend(base_dir="/workspace")

            # Normal case: path within workspace
            >>> backend._to_relative_path("/workspace/subdir/file.txt")
            'subdir/file.txt'

            # Path is exactly base_dir
            >>> backend._to_relative_path("/workspace")
            '/'

            # Path doesn't start with base_dir (edge case)
            >>> backend._to_relative_path("/other/path")
            'other/path'
        """
        if path.startswith(f"{self.base_dir}/"):
            return path[len(self.base_dir) + 1 :]
        if path == self.base_dir:
            return "/"
        return path.lstrip("/")

    def _normalize_sandbox_path(self, path: str) -> str:
        """Normalize a workspace-relative path to prevent directory traversal."""
        parts: list[str] = []
        for part in path.split("/"):
            if not part or part == ".":
                continue
            if part == "..":
                if parts:
                    parts.pop()
                continue
            parts.append(part)
        return "/" + "/".join(parts)

    def _is_directory_entry(self, entry: Any) -> bool:
        """Determine if a filesystem entry from the E2B files client is a directory."""
        entry_type = getattr(entry, "type", None)
        type_value = getattr(entry_type, "value", entry_type)
        return str(type_value).lower() == "dir"

    def _resolve_child_path(self, directory: str, child_name: str) -> str | None:
        """Resolve a listed child entry to a safe absolute sandbox path.

        This helper is used by :meth:`aget_files` when recursively collecting
        checkpoint state from the sandbox workspace. It joins a directory returned
        by the E2B files client with a child entry name, normalizes ``.`` / ``..``
        segments, and rejects any child that would escape ``self.base_dir``.

        Args:
            directory: Absolute sandbox directory currently being traversed
                (for example ``"/workspace"`` or ``"/workspace/subdir"``).
            child_name: Raw child entry name returned by the files client.

        Returns:
            The normalized absolute child path when it stays within
            ``self.base_dir``. Returns ``None`` when the child would escape the
            sandbox workspace and should be skipped.

        Examples:
            Normal child paths remain inside the workspace:
            >>> backend = SandboxBackend(base_dir="/workspace")
            >>> backend._resolve_child_path("/workspace", "notes.txt")
            '/workspace/notes.txt'
            Nested relative paths are normalized safely:
            >>> backend._resolve_child_path("/workspace/config", "./app.conf")
            '/workspace/config/app.conf'
            Parent-directory escapes are rejected:
            >>> backend._resolve_child_path("/workspace", "../escape.txt") is None
            True
            Traversal that stays inside the workspace is allowed:
            >>> backend._resolve_child_path("/workspace/nested", "../safe.txt")
            '/workspace/safe.txt'
        """
        child_path = self._normalize_sandbox_path(f"{directory}/{child_name}")
        base_dir_with_sep = f"{self.base_dir}/"
        if child_path == self.base_dir or child_path.startswith(base_dir_with_sep):
            return child_path
        return None

    def _run_sync(self, coro: Any) -> Any:
        """Run an async coroutine synchronously, bridging across a running event loop when present.

        Convenience wrapper used by the synchronous public API (e.g.
        :meth:`read`, :meth:`write`, :meth:`execute`) so that callers that
        cannot use ``await`` can still drive async backend operations.

        When called from a non-async thread while **no** event loop is running
        (the common case in tests and standalone scripts), ``asyncio.run`` is
        used directly, which creates a fresh loop and tears it down.

        When called from a worker thread spawned by a running event loop (the
        production case — LangGraph tool execution inside a uvloop server),
        ``asyncio.run_coroutine_threadsafe`` schedules the coroutine onto the
        **original** running loop so that all asyncio primitives (``Lock``,
        ``Event``, etc.) stay bound to that loop.  The calling thread blocks on
        ``Future.result()`` until the coroutine completes.

        Args:
            coro: An awaitable / coroutine to execute.

        Returns:
            The return value produced by *coro*.
        """
        loop = self._runtime_loop
        running_loop: asyncio.AbstractEventLoop | None = None

        try:
            running_loop = asyncio.get_running_loop()
        except RuntimeError:
            pass

        if loop is None or loop.is_closed():
            if running_loop is None:
                return asyncio.run(coro)
            self._runtime_loop = running_loop
            loop = running_loop

        if running_loop is loop:
            with concurrent.futures.ThreadPoolExecutor(max_workers=1) as executor:
                return executor.submit(asyncio.run, coro).result()

        fut: concurrent.futures.Future[Any] = concurrent.futures.Future()

        async def _wrapper() -> None:
            try:
                fut.set_result(await coro)
            except Exception as exc:
                fut.set_exception(exc)

        asyncio.run_coroutine_threadsafe(_wrapper(), loop)
        return fut.result()

    async def _ensure_parent_dir(self, file_path: str) -> None:
        """Ensure the parent directory of *file_path* exists in the sandbox.

        E2B's files API returns HTTP 404 when the target path's parent directory
        does not exist.  This method creates it via ``make_dir`` before every
        write, swallowing errors so that an already-existing directory does not
        surface as a failure.

        Args:
            file_path: Workspace-relative or absolute destination path whose
                parent directory should be pre-created.
        """
        resolved: str = self._resolve_path(file_path)
        parent = str(PurePosixPath(resolved).parent)
        if parent in ("", "/", self.base_dir):
            return
        files_client = await self._get_files_client()
        try:
            await files_client.make_dir(parent)
        except Exception:
            pass

    def ls_info(self, path: str) -> list[FileInfo]:
        """List files and subdirectories at *path* (synchronous).

        Synchronous wrapper around :meth:`als_info`.

        Args:
            path: Workspace-relative or absolute path of the directory to list.

        Returns:
            A list of :class:`~aip_agents.middleware.backends.protocol.FileInfo`
            objects describing each entry in the directory.
        """
        return self._run_sync(self.als_info(path))

    async def als_info(self, path: str) -> list[FileInfo]:
        """List files and subdirectories at *path* (async).

        Resolves *path* to an absolute sandbox path, calls the E2B files
        client ``list`` API, and converts the raw entries into
        :class:`~aip_agents.middleware.backends.protocol.FileInfo` objects
        with workspace-relative paths.

        Args:
            path: Workspace-relative or absolute path of the directory to list.

        Returns:
            A list of :class:`~aip_agents.middleware.backends.protocol.FileInfo`
            objects describing each entry in the directory.
        """
        await self._ensure_runtime()
        files_client = await self._get_files_client()
        full_path = self._resolve_path(path)
        entries = await files_client.list(full_path)

        results: list[FileInfo] = []
        for entry in entries:
            rel_path = self._to_relative_path(f"{full_path}/{entry.name}".replace("//", "/"))
            is_dir = self._is_directory_entry(entry)
            if is_dir:
                results.append(FileInfo(path=rel_path, type="directory", size=None))
            else:
                results.append(
                    FileInfo(path=rel_path, type="file", size=getattr(entry, "size", None)),
                )
        return results

    def read(
        self,
        file_path: str,
        line_offset: int = 0,
        limit: int = 2000,
        *,
        offset: int | None = None,
        thread_id: str = "default",
    ) -> str:
        """Read a file's contents with line numbers (synchronous).

        Synchronous wrapper around :meth:`aread`.

        Args:
            file_path: Workspace-relative or absolute path of the file to read.
            line_offset: Zero-based index of the first line to return. Defaults to 0.
            limit: Maximum number of lines to return. Defaults to 2000.
            offset: Deprecated alias for ``line_offset``.
            thread_id: Unused for sandbox backends. Accepted for protocol compatibility.

        Returns:
            A string of the requested lines prefixed with 1-based line numbers,
            or an empty string if the selected region is empty.
        """
        return self._run_sync(
            self.aread(
                file_path,
                line_offset=line_offset,
                limit=limit,
                offset=offset,
                thread_id=thread_id,
            )
        )

    async def aread(
        self,
        file_path: str,
        line_offset: int = 0,
        limit: int = 2000,
        *,
        offset: int | None = None,
        thread_id: str = "default",
    ) -> str:
        """Read a file's contents with line numbers (async).

        Reads the full file from the sandbox via the E2B files client, then
        slices the requested line window and delegates formatting to
        :func:`~aip_agents.middleware.backends.utils.format_content_with_line_numbers`.

        Args:
            file_path: Workspace-relative or absolute path of the file to read.
            line_offset: Zero-based index of the first line to return. Defaults to 0.
            limit: Maximum number of lines to return. Defaults to 2000.
            offset: Deprecated alias for ``line_offset``.
            thread_id: Unused for sandbox backends. Accepted for protocol compatibility.

        Returns:
            A string of the requested lines prefixed with 1-based line numbers,
            or an empty string if the selected region is empty.
        """
        if offset is not None:
            if line_offset != 0 and line_offset != offset:
                raise ValueError("Conflicting values provided for line_offset and offset")
            line_offset = offset

        await self._ensure_runtime()
        files_client = await self._get_files_client()
        content = await files_client.read(self._resolve_path(file_path))
        lines = content.split("\n")
        selected_lines = lines[max(0, line_offset) : max(0, line_offset) + max(0, limit)]
        selected_content = "\n".join(selected_lines)
        if not selected_content:
            return ""
        return format_content_with_line_numbers(selected_content, offset=max(0, line_offset))

    async def aread_bytes(self, file_path: str) -> bytes:
        """Read file content as raw bytes (async).

        Attempts to call ``read_bytes`` on the E2B files client when available
        (avoiding a UTF-8 decode/encode round-trip); falls back to the text
        ``read`` API and encodes the result as UTF-8.

        Args:
            file_path: Workspace-relative or absolute path of the file to read.

        Returns:
            The raw byte content of the file.
        """
        await self._ensure_runtime()
        files_client = await self._get_files_client()
        full_path = self._resolve_path(file_path)

        content = await files_client.read(full_path, format="bytes")
        if isinstance(content, bytes | bytearray):
            return bytes(content)
        return str(content).encode("utf-8")

    def read_bytes(self, file_path: str) -> bytes:
        """Read file content as raw bytes (synchronous).

        Synchronous wrapper around :meth:`aread_bytes`.

        Args:
            file_path: Workspace-relative or absolute path of the file to read.

        Returns:
            The raw byte content of the file.
        """
        return self._run_sync(self.aread_bytes(file_path))

    def read_chars(self, file_path: str, char_offset: int = 0, max_chars: int = 20000) -> str:
        """Read a file's contents by character position (synchronous).

        Synchronous wrapper around :meth:`aread_chars`.

        Args:
            file_path: Workspace-relative or absolute path of the file to read.
            char_offset: Character position to start from (0-indexed). Defaults to 0.
            max_chars: Maximum number of characters to read. Defaults to 20000.

        Returns:
            File content without line numbers (raw characters).
        """
        return self._run_sync(self.aread_chars(file_path, char_offset=char_offset, max_chars=max_chars))

    async def aread_chars(self, file_path: str, char_offset: int = 0, max_chars: int = 20000) -> str:
        """Read a file's contents by character position (async).

        Provides character-based pagination for reading large files that may have
        very long single lines. Reads the full file and slices the requested
        character window.

        Args:
            file_path: Workspace-relative or absolute path of the file to read.
            char_offset: Character position to start from (0-indexed). Defaults to 0.
            max_chars: Maximum number of characters to read. Defaults to 20000.

        Returns:
            File content without line numbers (raw characters).

        Raises:
            FileNotFoundError: If file does not exist.
        """
        await self._ensure_runtime()
        files_client = await self._get_files_client()
        full_path = self._resolve_path(file_path)

        content = await files_client.read(full_path)
        start = max(0, char_offset)
        if len(content) == 0:
            return ""
        if start >= len(content):
            return "[End of file reached]"
        end = min(len(content), start + max_chars)
        return content[start:end]

    def write(self, file_path: str, content: str) -> WriteResult:
        """Write *content* to a file, creating it if necessary (synchronous).

        Synchronous wrapper around :meth:`awrite`.

        Args:
            file_path: Workspace-relative or absolute destination path.
            content: Text content to write.

        Returns:
            A :class:`~aip_agents.middleware.backends.protocol.WriteResult`
            indicating success and the resolved path.
        """
        return self._run_sync(self.awrite(file_path, content))

    async def awrite(self, file_path: str, content: str) -> WriteResult:
        """Write *content* to a file, creating it if necessary (async).

        Resolves *file_path* to an absolute sandbox path, ensures the parent
        directory exists via :meth:`_ensure_parent_dir`, then delegates to the
        E2B files client ``write`` API.

        Args:
            file_path: Workspace-relative or absolute destination path.
            content: Text content to write.

        Returns:
            A :class:`~aip_agents.middleware.backends.protocol.WriteResult`
            indicating success and the resolved path.
        """
        await self._ensure_runtime()
        await self._ensure_parent_dir(file_path)
        files_client = await self._get_files_client()
        await files_client.write(self._resolve_path(file_path), content)
        return WriteResult(path=file_path, success=True)

    async def awrite_bytes(self, file_path: str, content_bytes: bytes) -> None:
        """Write raw bytes to a file, creating it if necessary (async).

        Binary counterpart of :meth:`awrite`.  Ensures the parent directory
        exists before writing so that callers (e.g. the AIP runner hydration
        path) do not need to reach into ``_get_files_client`` or
        ``_resolve_path`` directly.

        Args:
            file_path: Workspace-relative or absolute destination path.
            content_bytes: Raw bytes to write.
        """
        await self._ensure_runtime()
        await self._ensure_parent_dir(file_path)
        files_client = await self._get_files_client()
        await files_client.write(self._resolve_path(file_path), content_bytes)

    def edit(
        self,
        file_path: str,
        old_string: str,
        new_string: str,
        replace_all: bool = False,
    ) -> EditResult:
        """Replace a string inside a file (synchronous).

        Synchronous wrapper around :meth:`aedit`.

        Args:
            file_path: Workspace-relative or absolute path of the file to edit.
            old_string: The exact substring to search for.
            new_string: The replacement text.
            replace_all: When ``True``, replace every occurrence of
                *old_string*; when ``False`` (default), replace only the
                first occurrence.

        Returns:
            An :class:`~aip_agents.middleware.backends.protocol.EditResult`
            with ``success=True`` and an occurrence count on success, or
            ``success=False`` and an ``error`` message on failure.
        """
        return self._run_sync(self.aedit(file_path, old_string, new_string, replace_all=replace_all))

    async def aedit(
        self,
        file_path: str,
        old_string: str,
        new_string: str,
        replace_all: bool = False,
    ) -> EditResult:
        """Replace a string inside a file (async).

        Reads the current file content from the sandbox, performs the string
        replacement via
        :func:`~aip_agents.middleware.backends.utils.perform_string_replacement`,
        and writes the result back.  Returns an error result if the file does
        not exist or the replacement fails.

        Args:
            file_path: Workspace-relative or absolute path of the file to edit.
            old_string: The exact substring to search for.
            new_string: The replacement text.
            replace_all: When ``True``, replace every occurrence of
                *old_string*; when ``False`` (default), replace only the
                first occurrence.

        Returns:
            An :class:`~aip_agents.middleware.backends.protocol.EditResult`
            with ``success=True`` and an occurrence count on success, or
            ``success=False`` and an ``error`` message on failure.
        """
        await self._ensure_runtime()
        files_client = await self._get_files_client()
        full_path = self._resolve_path(file_path)
        try:
            content = await files_client.read(full_path)
        except Exception as error:
            return EditResult(
                path=file_path,
                error=f"Error: File '{file_path}' not found ({error})",
                success=False,
            )

        replacement = perform_string_replacement(content, old_string, new_string, replace_all)
        if isinstance(replacement, str):
            return EditResult(path=file_path, error=replacement, success=False)

        new_content, occurrences = replacement
        await files_client.write(full_path, new_content)
        return EditResult(path=file_path, occurrences=occurrences, success=True)

    def glob_info(self, pattern: str, path: str = "/") -> list[FileInfo]:
        """Find files matching a glob pattern (synchronous).

        Synchronous wrapper around :meth:`aglob_info`.

        Args:
            pattern: A glob pattern (e.g. ``"**/*.py"``) matched against
                workspace-relative paths and bare file names.
            path: Root directory to search.  Defaults to the workspace root
                (``"/"``).

        Returns:
            A list of :class:`~aip_agents.middleware.backends.protocol.FileInfo`
            objects for all matching entries.
        """
        return self._run_sync(self.aglob_info(pattern, path=path))

    async def aglob_info(self, pattern: str, path: str = "/") -> list[FileInfo]:
        """Find files matching a glob pattern (async).

        Recursively lists all entries under *path* using the E2B files client
        and filters them with :func:`fnmatch.fnmatch` against both the
        workspace-relative path and the bare file name.

        Args:
            pattern: A glob pattern (e.g. ``"**/*.py"``) matched against
                workspace-relative paths and bare file names.
            path: Root directory to search.  Defaults to the workspace root
                (``"/"``).

        Returns:
            A list of :class:`~aip_agents.middleware.backends.protocol.FileInfo`
            objects for all matching entries.
        """
        await self._ensure_runtime()
        files_client = await self._get_files_client()
        base_path = self._resolve_path(path)
        entries = await files_client.list(base_path)

        matches: list[FileInfo] = []
        for entry in entries:
            full_entry_path = f"{base_path}/{entry.name}".replace("//", "/")
            rel_path = self._to_relative_path(full_entry_path)
            if not (fnmatch.fnmatch(rel_path, pattern) or fnmatch.fnmatch(entry.name, pattern)):
                continue

            is_dir = "dir" in str(getattr(entry, "type", ""))
            if is_dir:
                matches.append(FileInfo(path=rel_path, type="directory", size=None))
            else:
                matches.append(FileInfo(path=rel_path, type="file", size=getattr(entry, "size", None)))
        return matches

    def grep_raw(self, pattern: str, path: str | None = None) -> list[GrepMatch] | str:
        """Search for a text pattern across files (synchronous).

        Synchronous wrapper around :meth:`agrep_raw`.

        Args:
            pattern: Literal string to search for (passed to ``rg -F``).
            path: Directory or file to search within.  Defaults to
                ``base_dir`` when ``None``.

        Returns:
            A list of :class:`~aip_agents.middleware.backends.protocol.GrepMatch`
            objects on success, or an error string if ``ripgrep`` returned a
            non-zero exit code other than 1 (no matches).
        """
        return self._run_sync(self.agrep_raw(pattern, path=path))

    async def agrep_raw(self, pattern: str, path: str | None = None) -> list[GrepMatch] | str:
        """Search for a text pattern across files using ripgrep (async).

        Executes ``rg --json -F`` inside the sandbox and parses the
        newline-delimited JSON output to produce structured match records.
        Uses a fixed-string (``-F``) search to avoid regex injection.

        Args:
            pattern: Literal string to search for.
            path: Directory or file to search within.  Defaults to
                ``base_dir`` when ``None``.

        Returns:
            A list of :class:`~aip_agents.middleware.backends.protocol.GrepMatch`
            objects on success.  Returns an empty list when ripgrep exits with
            code 1 (no matches found).  Returns the ``stderr`` string (or a
            generic error message) when ripgrep exits with code ≥ 2.
        """
        runtime = await self._ensure_runtime()
        search_path = self._resolve_path(path or self.base_dir)
        command = f"rg --json -F -- {json.dumps(pattern)} {json.dumps(search_path)}"
        runtime_any = cast(Any, runtime)
        if isinstance(runtime_any, E2BSandboxRuntime):
            result = await runtime_any.execute_command(command, timeout=30)
        else:
            result = await runtime.execute(command, timeout=30)
        if result.exit_code == 1:
            return []

        if result.exit_code >= 2:
            return result.stderr or "Grep command failed"

        matches: list[GrepMatch] = []
        for line in result.stdout.splitlines():
            try:
                data = json.loads(line)
            except json.JSONDecodeError:
                continue
            if data.get("type") != "match":
                continue
            payload = data.get("data", {})
            path_text = payload.get("path", {}).get("text")
            line_number = payload.get("line_number")
            line_text = payload.get("lines", {}).get("text", "").rstrip("\n")
            if not path_text or line_number is None:
                continue
            matches.append(
                GrepMatch(
                    path=self._to_relative_path(path_text),
                    line_number=int(line_number),
                    content=line_text,
                )
            )
        return matches

    def grep(self, pattern: str, path: str | None = None) -> list[GrepMatch]:
        """Search for a text pattern, always returning a list (synchronous).

        Calls :meth:`grep_raw` and suppresses the error-string variant,
        returning an empty list whenever the underlying search fails.

        Args:
            pattern: Literal string to search for.
            path: Directory or file to search within.  Defaults to
                ``base_dir`` when ``None``.

        Returns:
            A (possibly empty) list of
            :class:`~aip_agents.middleware.backends.protocol.GrepMatch` objects.
        """
        result = self.grep_raw(pattern, path=path)
        if isinstance(result, str):
            return []
        return result

    def execute(self, command: str, timeout: int = 30) -> ExecuteResult:
        """Execute a shell command inside the sandbox (synchronous).

        Synchronous wrapper around :meth:`aexecute`.

        Args:
            command: Shell command string to run.
            timeout: Maximum number of seconds to wait for the command to
                finish.  Defaults to 30.

        Returns:
            An :class:`~aip_agents.middleware.backends.protocol.ExecuteResult`
            containing ``stdout``, ``stderr``, and ``exit_code``.

        Raises:
            PermissionError: If ``allow_execute`` is ``False``.
        """
        return self._run_sync(self.aexecute(command, timeout=timeout))

    async def aexecute(self, command: str, timeout: int = 30) -> ExecuteResult:
        """Execute a shell command inside the sandbox (async).

        Delegates shell execution to runtime when available. For
        :class:`E2BSandboxRuntime`, this uses its dedicated command path.

        Args:
            command: Shell command string to run.
            timeout: Maximum number of seconds to wait for the command to
                finish.  Defaults to 30.

        Returns:
            An :class:`~aip_agents.middleware.backends.protocol.ExecuteResult`
            containing ``stdout``, ``stderr``, ``exit_code``, and
            ``truncated=False``.

        Raises:
            PermissionError: If ``allow_execute`` is ``False``.
        """
        if not self.allow_execute:
            raise PermissionError("execute() disabled for this backend")
        runtime = await self._ensure_runtime()
        runtime_any = cast(Any, runtime)
        if isinstance(runtime_any, E2BSandboxRuntime):
            result = await runtime_any.execute_command(command, timeout=timeout)
        else:
            result = await runtime.execute(command, timeout=timeout)
        return ExecuteResult(
            stdout=result.stdout,
            stderr=result.stderr,
            exit_code=result.exit_code,
            truncated=False,
        )

    def set_files(self, files: dict[str, Any], thread_id: str = "default") -> None:
        """Write a batch of files into the sandbox workspace (synchronous).

        Synchronous wrapper around :meth:`aset_files`.

        Args:
            files: Mapping of workspace-relative file paths to their text
                content.  Non-string values are coerced with ``str()``.
            thread_id: Logical thread identifier (reserved for future
                partitioned workspace support). Defaults to ``"default"``.
        """
        self._run_sync(self.aset_files(files, thread_id=thread_id))

    async def aset_files(self, files: dict[str, Any], thread_id: str = "default") -> None:
        """Write a batch of files into the sandbox workspace (async).

        Iterates over *files* and writes each entry to the sandbox via the E2B
        files client.  Paths are resolved relative to ``base_dir``.

        Args:
            files: Mapping of workspace-relative file paths to their text
                content.  Non-string values are coerced with ``str()``.
            thread_id: Logical thread identifier (reserved for future
                partitioned workspace support). Defaults to ``"default"``.
        """
        await self._ensure_runtime()
        files_client = await self._get_files_client()
        for file_path, file_data in files.items():
            content = file_data if isinstance(file_data, str) else str(file_data)
            await self._ensure_parent_dir(file_path)
            await files_client.write(self._resolve_path(file_path), content)

    def get_files(self, thread_id: str = "default") -> dict[str, Any]:
        """Read all files from the sandbox workspace for checkpointing (synchronous).

        Synchronous wrapper around :meth:`aget_files`.

        Args:
            thread_id: Logical thread identifier (reserved for future
                partitioned workspace support). Defaults to ``"default"``.

        Returns:
            A mapping of workspace-relative file paths to their text content.
        """
        return self._run_sync(self.aget_files(thread_id=thread_id))

    async def aget_files(self, thread_id: str = "default") -> dict[str, Any]:
        """Read all files from the sandbox workspace for checkpointing (async).

        Recursively walks entries under ``base_dir`` and reads the text content
        of each file via the E2B files client.

        Args:
            thread_id: Logical thread identifier (reserved for future
                partitioned workspace support). Defaults to ``"default"``.

        Returns:
            A mapping of workspace-relative file paths to their text content.
        """
        await self._ensure_runtime()
        files_client = await self._get_files_client()
        files: dict[str, Any] = {}
        visited_directories: set[str] = set()

        async def _collect(directory: str) -> None:
            if directory in visited_directories:
                return
            visited_directories.add(directory)
            entries = await files_client.list(directory)
            for entry in entries:
                full_path = self._resolve_child_path(directory, entry.name)
                if full_path is None:
                    continue
                if self._is_directory_entry(entry):
                    await _collect(full_path)
                    continue
                files[self._to_relative_path(full_path)] = await files_client.read(full_path)

        await _collect(self.base_dir)
        return files

    async def cleanup(self) -> None:
        """Release all sandbox resources and reset internal state."""
        if self._runtime is not None:
            await self._runtime.cleanup()
        self._runtime = None
        self._base_dir_initialized = False
