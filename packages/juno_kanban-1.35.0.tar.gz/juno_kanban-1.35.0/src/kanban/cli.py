#!/usr/bin/env python3
"""
Task Manager CLI - Complete Implementation
NDJSON-based Kanban task manager optimized for LLM usage.
"""

import sys
import os
import re
import argparse
import json
from typing import List, Optional, Dict, Any, Tuple, Set
from pathlib import Path

from .config import Config, ConfigError
from .models import Task, ValidationError, parse_related_task_ids, parse_blocked_by_ids, validate_task_ids
from .storage import TaskStorage
from .search import TaskSearch, SearchFilters
from .validators import TaskValidator
from .merge import TaskMerger
from .graph import DependencyGraph
from . import __version__


# Exit codes
class ExitCode:
    """Standard exit codes."""
    SUCCESS = 0
    GENERAL_ERROR = 1
    INVALID_USAGE = 2
    CONFIG_ERROR = 3
    IO_ERROR = 4
    VALIDATION_ERROR = 5


class OutputFormatter:
    """Format output in different formats."""

    @staticmethod
    def format_tasks(tasks: List[Dict[str, Any]], output_format: str, pretty: bool = False) -> str:
        """
        Format task list for output.

        Args:
            tasks: List of task dictionaries
            output_format: Format type (ndjson, json, xml, table)
            pretty: Pretty print output

        Returns:
            Formatted string
        """
        if not tasks:
            return ""

        if output_format == 'ndjson':
            return '\n'.join(json.dumps(task, ensure_ascii=False) for task in tasks)

        elif output_format == 'json':
            indent = 2 if pretty else None
            return json.dumps(tasks, ensure_ascii=False, indent=indent)

        elif output_format == 'xml':
            lines = ['<?xml version="1.0" encoding="UTF-8"?>']
            lines.append('<tasks>')
            for task in tasks:
                lines.append('  <task>')
                for key, value in task.items():
                    if value is None:
                        lines.append(f'    <{key} />')
                    elif isinstance(value, list):
                        lines.append(f'    <{key}>')
                        for item in value:
                            lines.append(f'      <item>{OutputFormatter._escape_xml(str(item))}</item>')
                        lines.append(f'    </{key}>')
                    else:
                        lines.append(f'    <{key}>{OutputFormatter._escape_xml(str(value))}</{key}>')
                lines.append('  </task>')
            lines.append('</tasks>')
            return '\n'.join(lines)

        elif output_format == 'table':
            if not tasks:
                return ""

            # Simple table format
            lines = []
            lines.append(f"{'ID':<8} {'Status':<12} {'Body':<40} {'Tags':<15} {'Related':<15} {'Blocked By':<15}")
            lines.append("-" * 110)

            for task in tasks:
                task_id = task.get('id', '')[:8]
                status = task.get('status', '')[:12]
                body = task.get('body', '')[:37] + ("..." if len(task.get('body', '')) > 37 else "")
                tags = ', '.join(task.get('feature_tags', []) or [])[:12] + ("..." if len(', '.join(task.get('feature_tags', []) or [])) > 12 else "")
                related = ', '.join(task.get('related_tasks', []) or [])[:12] + ("..." if len(', '.join(task.get('related_tasks', []) or [])) > 12 else "")
                blocked = ', '.join(task.get('blocked_by', []) or [])[:12] + ("..." if len(', '.join(task.get('blocked_by', []) or [])) > 12 else "")

                lines.append(f"{task_id:<8} {status:<12} {body:<40} {tags:<15} {related:<15} {blocked:<15}")

            return '\n'.join(lines)

        else:
            return json.dumps(tasks, ensure_ascii=False)

    @staticmethod
    def _escape_xml(text: str) -> str:
        """Escape XML special characters."""
        return (text.replace('&', '&amp;')
                    .replace('<', '&lt;')
                    .replace('>', '&gt;')
                    .replace('"', '&quot;')
                    .replace("'", '&#39;'))


class TaskCLI:
    """Main CLI application."""

    VERSION = __version__

    def __init__(self):
        """Initialize CLI."""
        self.config = None
        self.storage = None
        self.search = None
        self.parser = self._create_parser()

    def _get_command_name(self) -> str:
        """
        Detect the command name being used (juno-kanban, juno-feedback, or task).

        Returns:
            The command name as it appears in sys.argv[0]
        """
        import os
        import sys

        # Get the command name from sys.argv[0]
        command_path = sys.argv[0] if sys.argv else 'task'
        command_name = os.path.basename(command_path)

        # Handle different scenarios
        if command_name in ['juno-kanban', 'juno-feedback', 'kanban-juno']:
            return command_name
        elif command_name.endswith('.py'):
            # Direct Python execution, use 'task' as fallback
            return 'task'
        else:
            # Could be task script or other name
            return command_name

    def _create_parser(self) -> argparse.ArgumentParser:
        """
        Create argument parser with all commands and options.

        Returns:
            Configured ArgumentParser
        """
        # Detect the command name being used (juno-kanban, juno-feedback, or task)
        command_name = self._get_command_name()

        # Main parser
        parser = argparse.ArgumentParser(
            prog=command_name,
            description='Task manager. Use without arguments for full command reference.',
            epilog=f'Use "{command_name} COMMAND --help" for more information on a specific command',
            formatter_class=argparse.RawDescriptionHelpFormatter
        )

        # Global options
        parser.add_argument(
            '-c', '--config',
            metavar='PATH',
            help='Config file path (default: .juno_task/tasks/config.json)'
        )
        parser.add_argument(
            '-f', '--format',
            choices=['ndjson', 'json', 'xml', 'table'],
            metavar='FORMAT',
            help='Output format: ndjson, json, xml, table'
        )
        parser.add_argument(
            '-p', '--pretty',
            action='store_true',
            help='Pretty print output (for json/xml)'
        )
        parser.add_argument(
            '--raw',
            action='store_true',
            help='Output compact/raw format for machine processing'
        )
        parser.add_argument(
            '-v', '--verbose',
            action='store_true',
            help='Verbose output (show debug info)'
        )
        parser.add_argument(
            '--version',
            action='version',
            version=f'task {self.VERSION}'
        )

        # Subcommands
        subparsers = parser.add_subparsers(
            dest='command',
            help='Available commands',
            metavar='COMMAND'
        )

        # CREATE command
        create_parser = subparsers.add_parser(
            'create',
            help='Create a new task',
            description='Create a new task with specified body and optional metadata'
        )
        # Support both positional and --body flag for flexibility
        create_parser.add_argument('body', nargs='?', help='Task description/body (positional)')
        create_parser.add_argument('--body', dest='body_flag', help='Task description/body (--body flag)')
        create_parser.add_argument('--title', dest='title', help='Task title (prepended to body as "title:{title}\\n\\n{body}")')
        create_parser.add_argument('--status', help='Initial status (default: from config)')
        create_parser.add_argument('--tags', nargs='*', help='Feature tags (letters/numbers/underscore/hyphen only, space-separated: --tags backend fix_auth OR comma-separated: --tags backend,fix_auth)')
        create_parser.add_argument('--commit', help='Git commit hash')
        create_parser.add_argument('--related-tasks', nargs='*', dest='related_tasks', help='Related task IDs (space-separated: --related-tasks ABC123 DEF456 OR comma-separated: --related-tasks ABC123,DEF456). Also auto-parsed from body using [task_id]...[/task_id], [task_id]...[/], ##ID, or ## ID1 ID2 ## formats. Missing-but-valid IDs are stored as forward references with a warning.')
        create_parser.add_argument('--blocked-by', nargs='*', dest='blocked_by', help='Task IDs that must be completed before this task (space-separated: --blocked-by ABC123 DEF456 OR comma-separated: --blocked-by ABC123,DEF456). Also auto-parsed from body using [blocked_by]...[/], [block_by]...[/], [block]...[/], [parent_task]...[/] formats')

        # SEARCH command
        search_parser = subparsers.add_parser(
            'search',
            help='Search for tasks',
            description='Search for tasks using various filters'
        )
        search_parser.add_argument('--id', help='Filter by task ID')
        search_parser.add_argument('--status', nargs='*', help='Filter by status (space-separated: --status todo done OR comma-separated: --status todo,done)')
        search_parser.add_argument('--tag', nargs='*', help='Filter by tag (space-separated: --tag backend urgent OR comma-separated: --tag backend,urgent)')
        search_parser.add_argument('--exclude', nargs='*', help='Exclude tasks with these tags (space-separated: --exclude deprecated archived OR comma-separated: --exclude deprecated,archived)')
        search_parser.add_argument('--commit', help='Filter by commit hash')
        search_parser.add_argument('--body', help='Search in task body')
        search_parser.add_argument('--response', help='Search in agent response')
        search_parser.add_argument('--open', action='store_true', help='Show only open tasks (no agent response)')
        search_parser.add_argument('--recent', action='store_true', help='Sort by most recent')
        search_parser.add_argument('--limit', type=int, help='Max number of results (default: from config)')
        search_parser.add_argument('--sort', choices=['asc', 'desc'], default='desc', help='Sort order by last_modified (asc: oldest first, desc: newest first)')
        search_parser.add_argument('-f', '--format', dest='search_format', choices=['ndjson', 'json', 'xml', 'table'], metavar='FORMAT', help='Output format: ndjson, json, xml, table. JSON format includes tasks array and summary object.')

        # GET command
        get_parser = subparsers.add_parser(
            'get',
            help='Get one or more tasks by ID',
            description='Retrieve one or more tasks by their IDs'
        )
        get_parser.add_argument('ids', nargs='*', help='Task ID(s) (positional, supports multiple)')
        get_parser.add_argument('-ID', '--id', dest='id_flag', help='Task ID via flag (--ID or --id)')

        # SHOW command (alias for get)
        show_parser = subparsers.add_parser(
            'show',
            help='Get one or more tasks by ID (alias for get)',
            description='Retrieve one or more tasks by their IDs (alias for get)'
        )
        show_parser.add_argument('ids', nargs='*', help='Task ID(s) (positional, supports multiple)')
        show_parser.add_argument('-ID', '--id', dest='id_flag', help='Task ID via flag (--ID or --id)')

        # UPDATE command
        update_parser = subparsers.add_parser(
            'update',
            help='Update a task',
            description='Update task fields (status, agent_response, commit_hash)'
        )
        update_parser.add_argument('id', nargs='?', help='Task ID (positional)')
        update_parser.add_argument('-ID', '--id', dest='id_flag', help='Task ID via flag (--ID or --id)')
        update_parser.add_argument('--status', help='New status')
        update_parser.add_argument('--response', help='Agent response')
        update_parser.add_argument('--commit', help='Git commit hash')
        update_parser.add_argument('--tags', nargs='*', help='Feature tags (letters/numbers/underscore/hyphen only, space-separated: --tags backend fix_auth OR comma-separated: --tags backend,fix_auth, replaces existing)')
        update_parser.add_argument('--blocked-by', nargs='*', dest='blocked_by', help='Task IDs that must be completed before this task (space-separated: --blocked-by ABC123 DEF456 OR comma-separated: --blocked-by ABC123,DEF456). Replaces existing blocked_by. Cycle detection applied.')

        # ARCHIVE command (replaces delete/remove)
        archive_parser = subparsers.add_parser(
            'archive',
            help='Archive a task',
            description='Archive a task by setting its status to archive'
        )
        archive_parser.add_argument('id', nargs='?', help='Task ID to archive (positional)')
        archive_parser.add_argument('-ID', '--id', dest='id_flag', help='Task ID via flag (--ID or --id)')

        # MARK command (new workflow command)
        mark_parser = subparsers.add_parser(
            'mark',
            help='Mark a task with status and response',
            description='Mark a task with new status and required agent response'
        )
        mark_parser.add_argument('status', help='New status to mark task as')
        mark_parser.add_argument('id_positional', nargs='?', help='Task ID (positional, after status)')
        mark_parser.add_argument('-ID', '--id', dest='id_flag', help='Task ID via flag (--ID or --id)')
        mark_parser.add_argument('--response', required=True, help='Agent response (required)')
        mark_parser.add_argument('--commit', help='Git commit hash (recommended)')

        # LIST command (alias for search)
        list_parser = subparsers.add_parser(
            'list',
            help='List tasks (alias for search)',
            description='List tasks with optional filters'
        )
        list_parser.add_argument('--status', nargs='*', help='Filter by status (space-separated: --status todo done OR comma-separated: --status todo,done)')
        list_parser.add_argument('--tag', nargs='*', help='Filter by tag (space-separated: --tag backend urgent OR comma-separated: --tag backend,urgent)')
        list_parser.add_argument('--exclude', nargs='*', help='Exclude tasks with these tags (space-separated: --exclude deprecated archived OR comma-separated: --exclude deprecated,archived)')
        list_parser.add_argument('--open', action='store_true', help='Show only open tasks')
        list_parser.add_argument('--recent', action='store_true', help='Sort by most recent')
        list_parser.add_argument('--limit', type=int, help='Max number of results')
        list_parser.add_argument('--sort', choices=['asc', 'desc'], default='desc', help='Sort order by last_modified (asc: oldest first, desc: newest first). Default status priority is open->closed; with --status filters, provided status order is preserved.')
        list_parser.add_argument('-f', '--format', dest='list_format', choices=['ndjson', 'json', 'xml', 'table'], metavar='FORMAT', help='Output format: ndjson, json, xml, table. JSON format includes tasks array and summary object.')

        # TAGS command (aggregate tag usage counts)
        tags_parser = subparsers.add_parser(
            'tags',
            help='Show tag usage counts',
            description='Aggregate feature tag counts across tasks (optionally filtered by status)'
        )
        tags_parser.add_argument('--status', nargs='*', help='Filter source tasks by status before counting tags (space-separated: --status todo in_progress OR comma-separated: --status todo,in_progress)')
        tags_parser.add_argument('-f', '--format', dest='tags_format', choices=['ndjson', 'json', 'xml', 'table'], metavar='FORMAT', help='Output format: ndjson, json, xml, table. Table uses markdown layout for readability.')

        # DEPS command (dependency query/management)
        # Uses first positional to distinguish: deps TASK_ID (show) vs deps add/remove
        # action_or_id is optional to support flag-only syntax: deps --ID X --blocked-by Y (defaults to "add")
        deps_parser = subparsers.add_parser(
            'deps',
            help='Show or manage dependencies for a task',
            description='Show dependency info: deps TASK_ID. Add: deps add -ID TASK_ID --blocked-by IDS. Remove: deps remove -ID TASK_ID --blocked-by IDS. Shorthand: deps --ID TASK_ID --blocked-by IDS (defaults to add)'
        )
        deps_parser.add_argument('action_or_id', nargs='?', default=None, help='Task ID to show info, or "add"/"remove" action')
        deps_parser.add_argument('-ID', '--id', dest='task_id', help='Task ID (for add/remove actions, or show when used alone)')
        deps_parser.add_argument('--blocked-by', nargs='*', dest='blocked_by', help='Blocker task ID(s) (for add/remove)')

        # READY command (list tasks ready to work on)
        ready_parser = subparsers.add_parser(
            'ready',
            help='List tasks that are ready to work on (all blockers resolved)',
            description='Show tasks with status in [backlog, todo, in_progress] whose blockers are all done/archive (use --status to filter and preserve status order, and --sort asc|desc to order by last_modified within each status)'
        )
        ready_parser.add_argument('--tag', nargs='*', help='Filter by tag')
        ready_parser.add_argument('--status', nargs='*', help='Filter by status and preserve provided status order (space/comma separated)')
        ready_parser.add_argument('--limit', type=int, help='Max number of results')
        ready_parser.add_argument('--sort', choices=['asc', 'desc'], default='desc', help='Sort order by last_modified (asc: oldest first, desc: newest first)')
        ready_parser.add_argument('--raw', action='store_true', dest='ready_raw', help='Compact output for scripting')
        ready_parser.add_argument('-f', '--format', dest='ready_format', choices=['ndjson', 'json', 'xml', 'table'], metavar='FORMAT', help='Output format')

        # ORDER command (topological sort of open tasks)
        order_parser = subparsers.add_parser(
            'order',
            help='Show execution order (topological sort of open tasks)',
            description='Display tasks in dependency order (topological sort)'
        )
        order_parser.add_argument('--scores', action='store_true', help='Include priority scores')
        order_parser.add_argument('-f', '--format', dest='order_format', choices=['ndjson', 'json', 'xml', 'table'], metavar='FORMAT', help='Output format')

        # MERGE command (new workflow command for combining task files)
        merge_parser = subparsers.add_parser(
            'merge',
            help='Merge multiple .juno_task directories',
            description='Merge tasks from multiple .juno_task directories into a target location'
        )
        merge_parser.add_argument(
            'sources',
            nargs='*',
            help='Source .juno_task directory paths to merge'
        )
        merge_parser.add_argument(
            '--into',
            required=True,
            metavar='TARGET',
            help='Target .juno_task directory path'
        )
        merge_parser.add_argument(
            '--strategy',
            choices=['keep-newer', 'keep-both'],
            default='keep-newer',
            help='Conflict resolution strategy (default: keep-newer)'
        )
        merge_parser.add_argument(
            '--dry-run',
            action='store_true',
            help='Preview merge without making changes'
        )
        merge_parser.add_argument(
            '--find-all',
            action='store_true',
            help='Auto-discover all .juno_task directories under current directory'
        )

        # COMPLETION command (generate shell completion scripts)
        completion_parser = subparsers.add_parser(
            'completion',
            help='Generate shell completion script',
            description='Generate shell completion script for bash, zsh, or fish'
        )
        completion_parser.add_argument(
            'shell',
            nargs='?',
            choices=['bash', 'zsh', 'fish'],
            default='bash',
            help='Target shell (default: bash)'
        )

        # Internal completion candidate provider (used by generated scripts)
        complete_parser = subparsers.add_parser(
            '__complete',
            help=argparse.SUPPRESS,
            description=argparse.SUPPRESS
        )
        complete_parser.add_argument('--index', type=int, required=True, help=argparse.SUPPRESS)
        complete_parser.add_argument('words', nargs='*', help=argparse.SUPPRESS)

        return parser

    def _normalize_arguments(self, args: List[str]) -> List[str]:
        """
        Normalize command line arguments for case-insensitive handling.

        This method preprocesses arguments to handle case variations like:
        - -ID, -Id, -id, -iD -> -ID (preserve original short form)
        - --ID, --Id, --iD -> --id (normalize to lowercase)
        - -C, -c -> -c (normalize short flags to lowercase)
        - --STATUS, --Status -> --status (normalize long flags to lowercase)

        Args:
            args: Original command line arguments

        Returns:
            Normalized arguments with consistent case
        """
        normalized = []

        for arg in args:
            if arg.startswith('--'):
                # Long form arguments: normalize to lowercase
                if '=' in arg:
                    # Handle --arg=value format
                    flag, value = arg.split('=', 1)
                    normalized.append(f"{flag.lower()}={value}")
                else:
                    # Handle --arg format
                    normalized.append(arg.lower())
            elif arg.startswith('-') and len(arg) > 1:
                # Short form arguments: handle special cases
                if arg.upper() == '-ID':
                    # Special case: -ID variations should map to -ID (preserve uppercase for compatibility)
                    normalized.append('-ID')
                elif len(arg) == 2:
                    # Single character flags: normalize to lowercase
                    normalized.append(f"-{arg[1:].lower()}")
                else:
                    # Multi-character short flags: handle as-is
                    normalized.append(arg)
            else:
                # Not an argument flag, preserve as-is
                normalized.append(arg)

        return normalized

    def _init_components(self, config_path: Optional[str] = None):
        """Initialize configuration, storage, and search components."""
        try:
            self.config = Config(config_path)
            self.storage = TaskStorage(self.config)
            self.search = TaskSearch(self.config, self.storage)
        except ConfigError as e:
            print(f"Configuration error: {e}", file=sys.stderr)
            sys.exit(ExitCode.CONFIG_ERROR)
        except Exception as e:
            print(f"Initialization error: {e}", file=sys.stderr)
            sys.exit(ExitCode.GENERAL_ERROR)

    def _validate_project_root(self) -> bool:
        """
        Validate current location against project root detection rules.

        Returns:
            True if validation passes, False if it fails
        """
        try:
            is_valid, message, recommended_path = self.config.validate_current_location()

            if message:
                if is_valid:
                    # Warning case
                    print(message, file=sys.stderr)
                    print(f"TIP: You can set JUNO_TASK_ROOT={recommended_path} to override this behavior", file=sys.stderr)
                else:
                    # Error case
                    print(message, file=sys.stderr)
                    return False

            return is_valid

        except Exception as e:
            # If validation fails, log but don't block operation
            if self.config and hasattr(self.config, 'config') and \
               self.config.config.get('project_root', {}).get('enable_prevention', True):
                print(f"Warning: Project root validation error: {e}", file=sys.stderr)
            return True

    def _get_command_specific_format(self, args: argparse.Namespace) -> Optional[str]:
        """Return command-local format option when provided (e.g., list/search --format)."""
        for attr in ('list_format', 'search_format', 'ready_format', 'order_format', 'tags_format'):
            value = getattr(args, attr, None)
            if value:
                return value
        return None

    def _get_output_format(self, args: argparse.Namespace) -> str:
        """Get output format from args or config.

        Priority order:
        1. Command-specific format (e.g., list/search --format)
        2. Global format (-f/--format before command)
        3. Config default
        4. Fallback to 'ndjson'
        """
        command_format = self._get_command_specific_format(args)
        if command_format:
            return command_format

        # Check for global format (-f/--format before command)
        if args.format:
            return args.format
        elif self.config:
            return self.config.default_output_format
        else:
            return 'ndjson'

    def _truncate_task_bodies(self, tasks: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        """Truncate task bodies if they exceed the configured limit."""
        # Get truncation limit from environment variable
        truncate_limit = int(os.environ.get('JUNO_KANBAN_LIST_BODY_TRUNCATE_CHARS', '1200'))

        truncated_tasks = []
        for task in tasks:
            task_copy = task.copy()
            body = task_copy.get('body', '')

            if len(body) > truncate_limit:
                truncated_body = body[:truncate_limit]
                truncation_message = f"[Truncated full size: {len(body)} characters, use get command to read the full body]"
                task_copy['body'] = truncated_body + truncation_message

            truncated_tasks.append(task_copy)

        return truncated_tasks

    def _parse_comma_separated_values(self, values: Optional[List[str]]) -> Optional[List[str]]:
        """Parse comma-separated values from argument lists.

        Supports multiple syntaxes:
        - Space-separated: --status todo done
        - Comma-separated: --status todo,done
        - Mixed: --status todo,done archive

        Args:
            values: List of argument values from argparse (nargs='*')

        Returns:
            Flattened list of individual values, or None if input is None/empty
        """
        if not values:  # None or empty list
            return None

        result = []
        for value in values:
            # Split on commas, strip whitespace, filter out empty strings
            parts = [part.strip() for part in value.split(',') if part.strip()]
            result.extend(parts)

        return result if result else None

    def _looks_like_id_list(self, value: str) -> bool:
        """Return True when a string appears to be a task-id list (space/comma separated)."""
        parts = [part for part in re.split(r'[\s,]+', value.strip()) if part]
        if not parts:
            return False
        return all(re.fullmatch(r'[A-Za-z0-9]{6}', part) for part in parts)

    def _looks_like_tag_list(self, value: str) -> bool:
        """Return True when a string appears to be a tag list (space/comma separated)."""
        parts = [part for part in re.split(r'[\s,]+', value.strip()) if part]
        if not parts:
            return False
        return all(re.fullmatch(r'[A-Za-z0-9_-]+', part) for part in parts)

    def _recover_create_body_from_list_flags(self, args: argparse.Namespace) -> Optional[str]:
        """Recover trailing positional body swallowed by nargs='*' create flags.

        argparse greedily consumes trailing non-flag tokens for list-like options
        (`--related-tasks`, `--blocked-by`, `--tags`). If users put the body at
        the end, this can leave `args.body` empty and incorrectly trigger
        "Task body is required". We recover only when the swallowed value clearly
        looks like prose (contains whitespace and is not an ID/tag list).
        """
        candidate_sources = (
            ('related_tasks', self._looks_like_id_list),
            ('blocked_by', self._looks_like_id_list),
            ('tags', self._looks_like_tag_list),
        )

        for field_name, list_shape_check in candidate_sources:
            values = getattr(args, field_name, None)
            if not values:
                continue

            candidate = values[-1]
            if not isinstance(candidate, str):
                continue

            # Only recover body-like prose, not compact IDs/tags.
            has_whitespace = any(char.isspace() for char in candidate)
            if not has_whitespace:
                continue
            if list_shape_check(candidate):
                continue

            # Mutate args in place so downstream parsing of tags/ids remains correct.
            values.pop()
            if len(values) == 0:
                setattr(args, field_name, None)

            return candidate

        return None

    def _resolve_output_style(self, args: argparse.Namespace) -> Tuple[str, bool]:
        """Resolve effective output format and pretty-print style.

        Keeps jq-style default behavior consistent across task and aggregate
        commands: default to pretty JSON when no explicit format is provided.
        """
        output_format = self._get_output_format(args)

        # Check if an explicit format was specified (global or command-specific)
        explicit_format = args.format or self._get_command_specific_format(args)

        # New jq-style formatting logic (v1.4.0)
        if hasattr(args, 'raw') and args.raw:
            # --raw flag: use compact output (old behavior)
            pretty = False
        elif explicit_format:
            # Explicit format specified: use existing pretty logic
            pretty = args.pretty
        else:
            # Default: pretty-printed JSON (new jq-style behavior)
            output_format = 'json'
            pretty = True

        return output_format, pretty

    def _format_output(self, tasks: List[Dict[str, Any]], args: argparse.Namespace) -> str:
        """Format task-list output based on format and options."""
        output_format, pretty = self._resolve_output_style(args)
        return OutputFormatter.format_tasks(tasks, output_format, pretty)

    def _build_tag_counts(self, tasks: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        """Build deterministic tag-count aggregates from task list."""
        counts: Dict[str, int] = {}
        for task in tasks:
            for tag in (task.get('feature_tags') or []):
                counts[tag] = counts.get(tag, 0) + 1

        sorted_tags = sorted(counts.items(), key=lambda item: (-item[1], item[0]))
        return [{'tag': tag, 'count': count} for tag, count in sorted_tags]

    def _format_tag_output(self, tags: List[Dict[str, Any]], args: argparse.Namespace) -> str:
        """Format tag-count aggregates across supported output formats."""
        if not tags:
            return ""

        output_format, pretty = self._resolve_output_style(args)

        if output_format == 'ndjson':
            return '\n'.join(json.dumps(item, ensure_ascii=False) for item in tags)

        if output_format == 'json':
            indent = 2 if pretty else None
            return json.dumps(tags, ensure_ascii=False, indent=indent)

        if output_format == 'xml':
            lines = ['<?xml version="1.0" encoding="UTF-8"?>', '<tags>']
            for item in tags:
                lines.append('  <tag>')
                lines.append(f"    <name>{OutputFormatter._escape_xml(str(item.get('tag', '')))}</name>")
                lines.append(f"    <count>{item.get('count', 0)}</count>")
                lines.append('  </tag>')
            lines.append('</tags>')
            return '\n'.join(lines)

        if output_format == 'table':
            lines = ['| Tag | Count |', '| --- | ---: |']
            for item in tags:
                lines.append(f"| {item.get('tag', '')} | {item.get('count', 0)} |")
            return '\n'.join(lines)

        return json.dumps(tags, ensure_ascii=False)

    def _load_all_tasks_for_graph(self) -> List[Dict[str, Any]]:
        """Load all tasks as dicts for building a DependencyGraph."""
        all_tasks = []
        for filepath in self.storage.get_files():
            for task in self.storage.read_tasks(filepath):
                all_tasks.append(task)
        return all_tasks

    def cmd_create(self, args: argparse.Namespace) -> int:
        """Handle create command."""
        try:
            # Validate project root before creating tasks
            if not self._validate_project_root():
                return ExitCode.GENERAL_ERROR
            # Get body from either positional argument or --body flag
            body = args.body_flag if args.body_flag else args.body

            # Recover trailing prose body swallowed by nargs='*' list flags.
            if not body:
                recovered_body = self._recover_create_body_from_list_flags(args)
                if recovered_body:
                    body = recovered_body

            # Handle --title: merge into body as "title:{title}\n\n{body}"
            title = getattr(args, 'title', None)
            if title:
                if body:
                    body = f"title:{title}\n\n{body}"
                else:
                    # --title provided without body: use title as the body
                    body = f"title:{title}"

            if not body:
                print("Error: Task body is required. Use either 'task create \"body text\"' or 'task create --body \"body text\"' or 'task create --title \"title\"'", file=sys.stderr)
                return ExitCode.INVALID_USAGE

            # Prepare task data
            task_data = {
                'body': body,
            }

            if args.status:
                task_data['status'] = args.status
            elif self.config:
                task_data['status'] = self.config.default_status

            if args.tags:
                # Parse comma-separated tags (Issue 26)
                parsed_tags = self._parse_comma_separated_values(args.tags)
                task_data['feature_tags'] = parsed_tags

            if args.commit:
                task_data['commit_hash'] = args.commit

            # Handle related tasks - combine explicit arg and parsed from body
            all_related_ids = []

            # Parse related task IDs from body using [task_id]...[/] format
            parsed_from_body = parse_related_task_ids(body)
            all_related_ids.extend(parsed_from_body)

            # Add explicitly provided related tasks (via --related-tasks arg)
            if hasattr(args, 'related_tasks') and args.related_tasks:
                explicit_ids = self._parse_comma_separated_values(args.related_tasks)
                if explicit_ids:
                    for task_id in explicit_ids:
                        if task_id not in all_related_ids:
                            all_related_ids.append(task_id)

            # Validate related task IDs.
            # Keep valid-format IDs as informational forward references even when
            # they are not yet present in storage (parity with blocked_by behavior).
            if all_related_ids:
                valid_format_ids = []
                invalid_format_ids = []

                for related_id in all_related_ids:
                    is_valid_id, _ = TaskValidator.validate_id(related_id)
                    if is_valid_id:
                        valid_format_ids.append(related_id)
                    else:
                        invalid_format_ids.append(related_id)

                for invalid_id in invalid_format_ids:
                    print(f"Warning: {invalid_id} has invalid task ID format and was ignored.", file=sys.stderr)

                if valid_format_ids:
                    _, missing_ids = validate_task_ids(valid_format_ids, self.storage)
                    for missing_id in missing_ids:
                        print(f"Warning: {missing_id} wasn't found on the kanban (stored as forward reference).", file=sys.stderr)

                    task_data['related_tasks'] = valid_format_ids

            # Handle blocked_by - combine explicit arg and parsed from body
            all_blocked_ids = []

            # Parse blocked_by IDs from body using synonym tags
            parsed_blocked = parse_blocked_by_ids(body)
            all_blocked_ids.extend(parsed_blocked)

            # Add explicitly provided blocked_by (via --blocked-by arg)
            if hasattr(args, 'blocked_by') and args.blocked_by:
                explicit_blocked = self._parse_comma_separated_values(args.blocked_by)
                if explicit_blocked:
                    for bid in explicit_blocked:
                        if bid not in all_blocked_ids:
                            all_blocked_ids.append(bid)

            # Validate and apply blocked_by
            if all_blocked_ids:
                # Split into existing and forward-reference IDs (not yet in kanban)
                valid_blocked, invalid_blocked = validate_task_ids(all_blocked_ids, self.storage)

                for invalid_id in invalid_blocked:
                    print(f"Warning: {invalid_id} wasn't found on the kanban (stored as forward reference).", file=sys.stderr)

                if valid_blocked:
                    # Cycle detection: build graph from all existing tasks + proposed new task
                    # The new task doesn't exist yet, so we simulate it
                    all_tasks = self._load_all_tasks_for_graph()
                    # Add a placeholder for the new task
                    new_task_placeholder = {'id': '__new__', 'status': task_data.get('status', 'backlog'), 'blocked_by': valid_blocked}
                    all_tasks.append(new_task_placeholder)

                    graph = DependencyGraph(all_tasks)

                    # Check for cycles: for each existing blocker, would adding this edge create a cycle?
                    for blocker_id in valid_blocked:
                        cycle = graph.detect_cycle(blocker_id, '__new__')
                        if cycle:
                            # Replace placeholder ID in cycle path for clarity
                            cycle_path = ' → '.join(c if c != '__new__' else 'NEW_TASK' for c in cycle)
                            print(f"Error: Dependency cycle detected: {cycle_path}", file=sys.stderr)
                            return ExitCode.VALIDATION_ERROR

                # Store ALL IDs including forward references to not-yet-existing tasks
                task_data['blocked_by'] = all_blocked_ids

            # Create task
            task = self.storage.create_task(**task_data)

            # Output created task
            output = self._format_output([task.to_dict()], args)
            print(output)

            if args.verbose:
                print(f"Task {task.id} created successfully", file=sys.stderr)

            return ExitCode.SUCCESS

        except ValidationError as e:
            print(f"Validation error: {e}", file=sys.stderr)
            return ExitCode.VALIDATION_ERROR
        except Exception as e:
            print(f"Error creating task: {e}", file=sys.stderr)
            return ExitCode.GENERAL_ERROR

    def cmd_search(self, args: argparse.Namespace) -> int:
        """Handle search command."""
        try:
            # Handle nargs='*' with comma-separated support (Issue 26)
            status_filter = self._parse_comma_separated_values(args.status)
            if status_filter and len(status_filter) == 1:
                status_filter = status_filter[0]  # Single value - use as string for compatibility
            # else: multiple values - keep as list, or None if empty

            tag_filter = self._parse_comma_separated_values(args.tag)
            if tag_filter and len(tag_filter) == 1:
                tag_filter = tag_filter[0]  # Single value - use as string for compatibility
            # else: multiple values - keep as list, or None if empty

            exclude_tags_filter = self._parse_comma_separated_values(args.exclude)
            if exclude_tags_filter and len(exclude_tags_filter) == 1:
                exclude_tags_filter = exclude_tags_filter[0]  # Single value - use as string for compatibility
            # else: multiple values - keep as list, or None if empty

            # Build search filters
            filters = SearchFilters(
                id=args.id,
                status=status_filter,
                tag=tag_filter,
                exclude_tags=exclude_tags_filter,
                commit_hash=args.commit,
                body_text=args.body,
                response_text=args.response,
                open_only=args.open,
                recent=args.recent,
                limit=args.limit or (self.config.default_limit if self.config else 5),
                sort_order=getattr(args, 'sort', 'desc')
            )

            # Perform search
            results = self.search.search(filters)

            # Check if any results found
            if not results:
                print("No results found")
                return ExitCode.SUCCESS

            # Output results
            output = self._format_output(results, args)
            print(output)

            # Show summary/count context (parity with list command)
            self._show_summary_stats(results, args)

            if args.verbose:
                print(f"Found {len(results)} tasks", file=sys.stderr)

            return ExitCode.SUCCESS

        except Exception as e:
            print(f"Error searching tasks: {e}", file=sys.stderr)
            return ExitCode.GENERAL_ERROR

    def cmd_get(self, args: argparse.Namespace) -> int:
        """Handle get/show command - returns one or more tasks with related/dependency details."""
        try:
            positional_ids = list(getattr(args, 'ids', []) or [])
            flag_id = getattr(args, 'id_flag', None)

            requested_ids: List[str] = []
            if flag_id:
                requested_ids.append(flag_id)
            requested_ids.extend(positional_ids)

            if not requested_ids:
                print("Error: Task ID is required. Use 'get TASK_ID [TASK_ID ...]' or 'get --ID TASK_ID'", file=sys.stderr)
                return ExitCode.INVALID_USAGE

            # De-duplicate while preserving first-seen order
            seen_ids: Set[str] = set()
            ordered_ids: List[str] = []
            for task_id in requested_ids:
                if task_id not in seen_ids:
                    seen_ids.add(task_id)
                    ordered_ids.append(task_id)

            task_lookup: Dict[str, Optional[Dict[str, Any]]] = {}
            missing_ids: List[str] = []
            for task_id in ordered_ids:
                task = self.search.search_by_id(task_id)
                task_lookup[task_id] = task
                if not task:
                    missing_ids.append(task_id)

            if missing_ids:
                if len(missing_ids) == 1:
                    print(f"Task not found: {missing_ids[0]}", file=sys.stderr)
                else:
                    print(f"Task(s) not found: {', '.join(missing_ids)}", file=sys.stderr)
                return ExitCode.GENERAL_ERROR

            all_tasks = self._load_all_tasks_for_graph()
            graph = DependencyGraph(all_tasks)

            def get_task_by_id(task_id: str) -> Optional[Dict[str, Any]]:
                if task_id in task_lookup:
                    return task_lookup[task_id]
                task_lookup[task_id] = self.search.search_by_id(task_id)
                return task_lookup[task_id]

            result_tasks: List[Dict[str, Any]] = []
            for task_id in ordered_ids:
                task = task_lookup[task_id]
                if not task:
                    continue

                task_copy = task.copy()

                # If task has related_tasks, fetch and include their full details
                related_task_ids = task.get('related_tasks') or []
                if related_task_ids:
                    related_tasks_details = []
                    for related_id in related_task_ids:
                        related_task = get_task_by_id(related_id)
                        if related_task:
                            related_tasks_details.append(related_task)
                        else:
                            print(f"Warning: Related task {related_id} no longer exists in kanban.", file=sys.stderr)

                    if related_tasks_details:
                        task_copy['_related_tasks_details'] = related_tasks_details

                # Add dependency info if task has blocked_by or is a blocker for others
                blockers = graph.get_blockers(task_id)
                dependents = graph.get_dependents(task_id)

                if blockers or dependents:
                    unmet_blockers = []
                    met_blockers = []
                    is_blocked = False
                    for bid in blockers:
                        blocker_task = get_task_by_id(bid)
                        if blocker_task:
                            if blocker_task.get('status') in ('done', 'archive'):
                                met_blockers.append({'id': bid, 'status': blocker_task['status']})
                            else:
                                is_blocked = True
                                unmet_blockers.append({'id': bid, 'status': blocker_task.get('status', 'unknown')})

                    task_copy['_dependency_info'] = {
                        'is_blocked': is_blocked,
                        'unmet_blockers': unmet_blockers,
                        'met_blockers': met_blockers,
                        'dependents': dependents,
                        'priority_score': graph.get_priority_score(task_id)
                    }

                result_tasks.append(task_copy)

            output = self._format_output(result_tasks, args)
            print(output)
            return ExitCode.SUCCESS

        except Exception as e:
            print(f"Error getting task: {e}", file=sys.stderr)
            return ExitCode.GENERAL_ERROR

    def cmd_update(self, args: argparse.Namespace) -> int:
        """Handle update command."""
        try:
            # Validate project root before updating tasks
            if not self._validate_project_root():
                return ExitCode.GENERAL_ERROR
            # Resolve task_id from --ID/--id flag or positional argument
            task_id = getattr(args, 'id_flag', None) or args.id
            if not task_id:
                print("Error: Task ID is required. Use 'update TASK_ID' or 'update --ID TASK_ID'", file=sys.stderr)
                return ExitCode.INVALID_USAGE
            args.id = task_id
            # Build updates dictionary
            updates = {}
            if args.status:
                updates['status'] = args.status
            if args.response:
                updates['agent_response'] = args.response
            if args.commit:
                updates['commit_hash'] = args.commit
            if args.tags is not None:  # Allow empty list
                # Parse comma-separated tags (Issue 26)
                parsed_tags = self._parse_comma_separated_values(args.tags)
                updates['feature_tags'] = parsed_tags if parsed_tags is not None else []

            # Handle --blocked-by with cycle detection
            blocked_by_provided = hasattr(args, 'blocked_by') and args.blocked_by is not None
            if blocked_by_provided:
                parsed_blocked = self._parse_comma_separated_values(args.blocked_by)
                blocked_ids = parsed_blocked if parsed_blocked else []

                if blocked_ids:
                    # Self-dependency check
                    if args.id in blocked_ids:
                        print(f"Error: Task cannot be blocked by itself: {args.id}", file=sys.stderr)
                        return ExitCode.VALIDATION_ERROR

                    # Split into existing and forward-reference IDs (not yet in kanban)
                    valid_blocked, invalid_blocked = validate_task_ids(blocked_ids, self.storage)
                    for invalid_id in invalid_blocked:
                        print(f"Warning: {invalid_id} wasn't found on the kanban (stored as forward reference).", file=sys.stderr)

                    if valid_blocked:
                        # Cycle detection: build graph from all tasks, then check proposed edges
                        all_tasks = self._load_all_tasks_for_graph()

                        # Update the target task's blocked_by in the graph data
                        # (replace existing blocked_by with the new set)
                        for t in all_tasks:
                            if t['id'] == args.id:
                                t['blocked_by'] = valid_blocked
                                break

                        graph = DependencyGraph(all_tasks)
                        for blocker_id in valid_blocked:
                            cycle = graph.detect_cycle(blocker_id, args.id)
                            if cycle:
                                cycle_path = ' → '.join(cycle)
                                print(f"Error: Dependency cycle detected: {cycle_path}", file=sys.stderr)
                                return ExitCode.VALIDATION_ERROR

                    # Store ALL IDs including forward references to not-yet-existing tasks
                    updates['blocked_by'] = blocked_ids
                else:
                    # Empty --blocked-by clears dependencies
                    updates['blocked_by'] = []

            if not updates:
                print("No updates specified", file=sys.stderr)
                return ExitCode.INVALID_USAGE

            # Perform update
            success = self.storage.update_task(args.id, updates)

            if success:
                if args.verbose:
                    print(f"Task {args.id} updated successfully", file=sys.stderr)

                # Show updated task
                task = self.search.search_by_id(args.id)
                if task:
                    output = self._format_output([task], args)
                    print(output)

                return ExitCode.SUCCESS
            else:
                print(f"Task not found: {args.id}", file=sys.stderr)
                return ExitCode.GENERAL_ERROR

        except ValidationError as e:
            print(f"Validation error: {e}", file=sys.stderr)
            return ExitCode.VALIDATION_ERROR
        except Exception as e:
            print(f"Error updating task: {e}", file=sys.stderr)
            return ExitCode.GENERAL_ERROR

    def cmd_list(self, args: argparse.Namespace) -> int:
        """Handle list command - show tasks with prioritized sorting (open issues first) and summary stats."""
        try:
            # Create filters from user arguments with comma-separated support (Issue 26)
            # Parse comma-separated values and handle nargs='*' which returns empty list when no args provided
            status_filter = self._parse_comma_separated_values(getattr(args, 'status', None))
            if status_filter and len(status_filter) == 1:
                status_filter = status_filter[0]  # Single value - use as string for compatibility
            # else: multiple values - keep as list, or None if empty

            tag_filter = self._parse_comma_separated_values(getattr(args, 'tag', None))
            if tag_filter and len(tag_filter) == 1:
                tag_filter = tag_filter[0]  # Single value - use as string for compatibility
            # else: multiple values - keep as list, or None if empty

            exclude_tags_filter = self._parse_comma_separated_values(getattr(args, 'exclude', None))
            if exclude_tags_filter and len(exclude_tags_filter) == 1:
                exclude_tags_filter = exclude_tags_filter[0]  # Single value - use as string for compatibility
            # else: multiple values - keep as list, or None if empty

            user_filters = SearchFilters(
                id=None,
                status=status_filter,
                tag=tag_filter,
                exclude_tags=exclude_tags_filter,
                commit_hash=None,
                body_text=None,
                open_only=getattr(args, 'open', False),
                recent=getattr(args, 'recent', False),
                limit=10000  # Large limit to get all tasks for summary
            )

            # First get all tasks matching filters for summary statistics
            # IMPORTANT: Use Python backend directly to ensure consistent results
            # with search_prioritized_list (which also uses Python backend).
            # This fixes bug where ripgrep optimization could read from different
            # files or apply different filtering, causing summary stats mismatch.
            # See Issue 31: Summary stats showed wrong counts due to backend mismatch.
            all_tasks = self.search.python_search.search_all(user_filters)

            # Check if any tasks exist
            if not all_tasks:
                if user_filters.status or user_filters.tag or user_filters.exclude_tags or user_filters.open_only:
                    print("No results found")
                else:
                    print("No tasks found")
                return ExitCode.SUCCESS

            # Now get limited set for display with prioritized sorting
            # Open issues (backlog, todo, in_progress) first by last_modified DESC,
            # then closed issues (done, archive) by last_modified DESC
            display_limit = args.limit or (self.config.default_limit if self.config else 5)

            # Create display filters with the same criteria but limited results
            display_filters = SearchFilters(
                id=None,
                status=status_filter,
                tag=tag_filter,
                exclude_tags=exclude_tags_filter,
                commit_hash=None,
                body_text=None,
                open_only=getattr(args, 'open', False),
                recent=getattr(args, 'recent', False),
                limit=display_limit
            )

            # Get sort order from args (default is 'desc' - newest first)
            sort_order = getattr(args, 'sort', 'desc')
            display_tasks = self.search.search_prioritized_list(
                display_limit,
                display_filters,
                sort_order,
                status_sequence=status_filter,
            )

            # Apply body truncation for list command (Issue 25)
            truncated_tasks = self._truncate_task_bodies(display_tasks)

            # Output task results (limited set)
            output = self._format_output(truncated_tasks, args)
            print(output)

            # Show summary statistics based on all tasks
            self._show_summary_stats(all_tasks, args, displayed_count=len(display_tasks))

            if args.verbose:
                print(f"Showing {len(display_tasks)} of {len(all_tasks)} tasks", file=sys.stderr)

            return ExitCode.SUCCESS

        except Exception as e:
            print(f"Error listing tasks: {e}", file=sys.stderr)
            return ExitCode.GENERAL_ERROR

    def cmd_tags(self, args: argparse.Namespace) -> int:
        """Handle tags command - aggregate feature-tag counts."""
        try:
            status_filter = self._parse_comma_separated_values(getattr(args, 'status', None))
            if status_filter and len(status_filter) == 1:
                status_filter = status_filter[0]

            filters = SearchFilters(
                status=status_filter,
                limit=10000,
                sort_order='desc',
            )

            # Use python backend directly for deterministic aggregate source data.
            tasks = self.search.python_search.search_all(filters)
            tag_counts = self._build_tag_counts(tasks)

            if not tag_counts:
                print("No tags found")
                return ExitCode.SUCCESS

            output = self._format_tag_output(tag_counts, args)
            print(output)
            return ExitCode.SUCCESS

        except Exception as e:
            print(f"Error listing tags: {e}", file=sys.stderr)
            return ExitCode.GENERAL_ERROR

    def _show_summary_stats(self, tasks: List[Dict[str, Any]], args: argparse.Namespace, displayed_count: Optional[int] = None) -> None:
        """Show summary statistics of tasks by status."""
        # Count tasks by status
        status_counts = {}
        for task in tasks:
            status = task.get('status', 'unknown')
            status_counts[status] = status_counts.get(status, 0) + 1

        # Get all possible statuses from config (to show zeros)
        all_statuses = ['backlog', 'todo', 'in_progress', 'done', 'archive']
        if self.config and hasattr(self.config, 'status_values'):
            all_statuses = self.config.status_values

        # Determine effective output format (global or command-specific)
        effective_format = self._get_output_format(args)

        # Show summary (respect JSON output format)
        if effective_format == 'json':
            # Add helper text to JSON format
            help_text = "Use --limit N to show more/fewer results"
            summary = {
                "summary": {
                    "total_tasks": len(tasks),
                    "displayed_tasks": displayed_count if displayed_count is not None else len(tasks),
                    "status_counts": {status: status_counts.get(status, 0) for status in all_statuses},
                    "help": help_text
                }
            }
            print(json.dumps(summary, indent=2 if args.pretty else None))
        else:
            print("\nSUMMARY:", file=sys.stderr)
            if displayed_count is not None and displayed_count != len(tasks):
                print(f"Displayed: {displayed_count} of {len(tasks)} total tasks", file=sys.stderr)
            else:
                print(f"Total tasks: {len(tasks)}", file=sys.stderr)
            print("Status breakdown:", file=sys.stderr)
            for status in all_statuses:
                count = status_counts.get(status, 0)
                print(f"  {status}: {count}", file=sys.stderr)

            # Show any unknown statuses
            for status, count in status_counts.items():
                if status not in all_statuses:
                    print(f"  {status}: {count}", file=sys.stderr)

            # Add helper text to stderr output
            print("", file=sys.stderr)  # Empty line for readability
            print("TIP: Use --limit N to show more/fewer results", file=sys.stderr)

    def cmd_archive(self, args: argparse.Namespace) -> int:
        """Handle archive command."""
        try:
            # Validate project root before archiving tasks
            if not self._validate_project_root():
                return ExitCode.GENERAL_ERROR
            # Resolve task_id from --ID/--id flag or positional argument
            task_id = getattr(args, 'id_flag', None) or args.id
            if not task_id:
                print("Error: Task ID is required. Use 'archive TASK_ID' or 'archive --ID TASK_ID'", file=sys.stderr)
                return ExitCode.INVALID_USAGE
            args.id = task_id
            # Check if task exists before archiving
            task = self.storage.find_task(args.id)
            if not task:
                print(f"Error: Task {args.id} not found", file=sys.stderr)
                return ExitCode.VALIDATION_ERROR

            # Update to archive status
            updated = self.storage.update_task(args.id, {'status': 'archive'})
            if updated:
                print(f"Task {args.id} archived successfully")
                if args.verbose:
                    print(f"Task {args.id} status set to archive", file=sys.stderr)
                return ExitCode.SUCCESS
            else:
                print(f"Error: Failed to archive task {args.id}", file=sys.stderr)
                return ExitCode.GENERAL_ERROR

        except Exception as e:
            print(f"Error archiving task: {e}", file=sys.stderr)
            return ExitCode.GENERAL_ERROR

    def cmd_mark(self, args: argparse.Namespace) -> int:
        """Handle mark command with required response."""
        try:
            # Validate project root before marking tasks
            if not self._validate_project_root():
                return ExitCode.GENERAL_ERROR
            # Resolve task_id from --ID/--id flag or positional argument
            task_id = getattr(args, 'id_flag', None) or getattr(args, 'id_positional', None)
            if not task_id:
                print("Error: Task ID is required. Use 'mark STATUS --id TASK_ID' or 'mark STATUS TASK_ID'", file=sys.stderr)
                return ExitCode.INVALID_USAGE
            args.id = task_id
            # Check if task exists
            task = self.storage.find_task(args.id)
            if not task:
                print(f"Error: Task {args.id} not found", file=sys.stderr)
                return ExitCode.VALIDATION_ERROR

            # Prepare update data
            update_data = {
                'status': args.status,
                'agent_response': args.response
            }

            # Add commit hash if provided, otherwise remind user
            if args.commit:
                update_data['commit_hash'] = args.commit
            else:
                print("Commit Hash is empty, if you have committed something, please give commit hash as well", file=sys.stderr)

            # Update the task
            updated = self.storage.update_task(args.id, update_data)
            if updated:
                print(f"Task {args.id} marked as {args.status}")
                if args.verbose:
                    print(f"Task {args.id} updated with response and status", file=sys.stderr)
                return ExitCode.SUCCESS
            else:
                print(f"Error: Failed to mark task {args.id}", file=sys.stderr)
                return ExitCode.GENERAL_ERROR

        except Exception as e:
            print(f"Error marking task: {e}", file=sys.stderr)
            return ExitCode.GENERAL_ERROR

    def cmd_merge(self, args: argparse.Namespace) -> int:
        """Handle merge command."""
        try:
            # Initialize merger
            merger = TaskMerger(self.config)

            # Determine source paths
            if args.find_all:
                # Auto-discover .juno_task directories
                current_dir = str(Path.cwd())
                source_paths = merger.find_juno_task_directories(current_dir)
                if not source_paths:
                    print("No .juno_task directories found under current directory", file=sys.stderr)
                    return ExitCode.GENERAL_ERROR

                print(f"Found {len(source_paths)} .juno_task directories:")
                for path in source_paths:
                    print(f"  - {path}")
                print()
            else:
                # Use explicitly provided sources
                if not args.sources:
                    print("Error: No source paths provided. Use source paths or --find-all", file=sys.stderr)
                    return ExitCode.INVALID_USAGE

                source_paths = args.sources

            # Validate source paths
            for source_path in source_paths:
                if not os.path.exists(source_path):
                    print(f"Error: Source path does not exist: {source_path}", file=sys.stderr)
                    return ExitCode.IO_ERROR

                tasks_dir = os.path.join(source_path, 'tasks')
                if not os.path.exists(tasks_dir):
                    print(f"Error: Source path is not a valid .juno_task directory: {source_path}", file=sys.stderr)
                    return ExitCode.IO_ERROR

            # Validate target path
            target_path = args.into
            if os.path.exists(target_path) and not os.path.isdir(target_path):
                print(f"Error: Target path exists but is not a directory: {target_path}", file=sys.stderr)
                return ExitCode.IO_ERROR

            # Perform merge
            print(f"Merging {len(source_paths)} source(s) into {target_path}")
            print(f"Strategy: {args.strategy}")
            if args.dry_run:
                print("DRY RUN - No files will be modified")
            print()

            result = merger.merge_files(
                source_paths=source_paths,
                target_path=target_path,
                strategy=args.strategy,
                dry_run=args.dry_run
            )

            if result['success']:
                stats = result['statistics']
                print("MERGE RESULTS:")
                print(f"  Total sources processed: {stats['total_sources']}")
                print(f"  Conflicts found: {stats['conflicts_found']}")
                print(f"  Conflicts resolved: {stats['conflicts_resolved']}")
                print(f"  New tasks added: {stats['tasks_added']}")
                print(f"  Existing tasks kept: {stats['tasks_kept']}")
                print(f"  Final task count: {stats['final_task_count']}")

                if result['conflicts']:
                    print("\nCONFLICTS RESOLVED:")
                    for conflict in result['conflicts']:
                        print(f"  - {conflict}")

                if args.dry_run:
                    print("\nDRY RUN COMPLETE - No files were modified")
                    print("Run without --dry-run to perform the actual merge")
                else:
                    print(f"\nMerge completed successfully!")
                    print(f"Merged tasks are now available in: {target_path}")

                return ExitCode.SUCCESS
            else:
                print("Merge failed", file=sys.stderr)
                return ExitCode.GENERAL_ERROR

        except Exception as e:
            print(f"Error during merge: {e}", file=sys.stderr)
            return ExitCode.GENERAL_ERROR

    def cmd_deps(self, args: argparse.Namespace) -> int:
        """Handle deps command — show, add, or remove dependencies."""
        try:
            action_or_id = args.action_or_id

            # Infer action when action_or_id is omitted (flag-only syntax)
            # e.g. deps --ID X --blocked-by Y  → defaults to "add"
            # e.g. deps --ID X                 → defaults to "show"
            if action_or_id is None:
                if args.task_id and args.blocked_by:
                    action_or_id = 'add'
                elif args.task_id:
                    # --ID provided without --blocked-by → show dependency info
                    action_or_id = args.task_id
                    args.task_id = None  # consumed as the show target
                else:
                    cn = self._get_command_name()
                    print("Error: deps requires a task ID or action.", file=sys.stderr)
                    print(f"\nDeps usage:", file=sys.stderr)
                    print(f"  {cn} deps TASK_ID                                  Show blockers, dependents, priority score", file=sys.stderr)
                    print(f"  {cn} deps add --id TASK_ID --blocked-by ID...      Add dependency (cycle-checked)", file=sys.stderr)
                    print(f"  {cn} deps remove --id TASK_ID --blocked-by ID...   Remove dependency", file=sys.stderr)
                    print(f"  {cn} deps --id TASK_ID --blocked-by ID...          Shorthand for add", file=sys.stderr)
                    return ExitCode.INVALID_USAGE

            if action_or_id == 'add':
                return self._deps_add(args)
            elif action_or_id == 'remove':
                return self._deps_remove(args)
            else:
                # Show dependency info for a task
                task_id = action_or_id

                task = self.search.search_by_id(task_id)
                if not task:
                    print(f"Task not found: {task_id}", file=sys.stderr)
                    return ExitCode.GENERAL_ERROR

                all_tasks = self._load_all_tasks_for_graph()
                graph = DependencyGraph(all_tasks)

                blockers = graph.get_blockers(task_id)
                dependents = graph.get_dependents(task_id)
                priority = graph.get_priority_score(task_id)

                # Determine is_blocked: any blocker not in done/archive
                is_blocked = False
                unmet_blockers = []
                met_blockers = []
                for bid in blockers:
                    blocker_task = self.search.search_by_id(bid)
                    if blocker_task:
                        if blocker_task.get('status') in ('done', 'archive'):
                            met_blockers.append({'id': bid, 'status': blocker_task['status']})
                        else:
                            is_blocked = True
                            unmet_blockers.append({'id': bid, 'status': blocker_task.get('status', 'unknown')})

                info = {
                    'task_id': task_id,
                    'is_blocked': is_blocked,
                    'unmet_blockers': unmet_blockers,
                    'met_blockers': met_blockers,
                    'dependents': dependents,
                    'priority_score': priority
                }

                output = self._format_output([info], args)
                print(output)
                return ExitCode.SUCCESS

        except Exception as e:
            print(f"Error querying dependencies: {e}", file=sys.stderr)
            return ExitCode.GENERAL_ERROR

    def _deps_add(self, args: argparse.Namespace) -> int:
        """Add dependencies to a task."""
        try:
            if not self._validate_project_root():
                return ExitCode.GENERAL_ERROR

            task_id = args.task_id
            task = self.search.search_by_id(task_id)
            if not task:
                print(f"Task not found: {task_id}", file=sys.stderr)
                return ExitCode.GENERAL_ERROR

            new_blockers = self._parse_comma_separated_values(args.blocked_by)
            if not new_blockers:
                print("Error: --blocked-by required", file=sys.stderr)
                return ExitCode.INVALID_USAGE

            # Self-dependency check
            if task_id in new_blockers:
                print(f"Error: Task cannot be blocked by itself: {task_id}", file=sys.stderr)
                return ExitCode.VALIDATION_ERROR

            # Split into existing and forward-reference IDs (not yet in kanban)
            valid_ids, invalid_ids = validate_task_ids(new_blockers, self.storage)
            for invalid_id in invalid_ids:
                print(f"Warning: {invalid_id} wasn't found on the kanban (stored as forward reference).", file=sys.stderr)

            # Merge ALL provided IDs (including forward references) with existing blocked_by
            existing = task.get('blocked_by') or []
            merged = list(existing)
            for bid in new_blockers:
                if bid not in merged:
                    merged.append(bid)

            # Cycle detection on existing IDs only
            if valid_ids:
                all_tasks = self._load_all_tasks_for_graph()
                for t in all_tasks:
                    if t['id'] == task_id:
                        t['blocked_by'] = merged
                        break

                graph = DependencyGraph(all_tasks)
                for blocker_id in valid_ids:
                    cycle = graph.detect_cycle(blocker_id, task_id)
                    if cycle:
                        cycle_path = ' → '.join(cycle)
                        print(f"Error: Dependency cycle detected: {cycle_path}", file=sys.stderr)
                        return ExitCode.VALIDATION_ERROR

            # Save
            self.storage.update_task(task_id, {'blocked_by': merged})
            updated = self.search.search_by_id(task_id)
            output = self._format_output([updated], args)
            print(output)
            return ExitCode.SUCCESS

        except Exception as e:
            print(f"Error adding dependency: {e}", file=sys.stderr)
            return ExitCode.GENERAL_ERROR

    def _deps_remove(self, args: argparse.Namespace) -> int:
        """Remove dependencies from a task."""
        try:
            if not self._validate_project_root():
                return ExitCode.GENERAL_ERROR

            task_id = args.task_id
            task = self.search.search_by_id(task_id)
            if not task:
                print(f"Task not found: {task_id}", file=sys.stderr)
                return ExitCode.GENERAL_ERROR

            to_remove = self._parse_comma_separated_values(args.blocked_by)
            if not to_remove:
                print("Error: --blocked-by required", file=sys.stderr)
                return ExitCode.INVALID_USAGE

            existing = task.get('blocked_by') or []
            updated_blocked = [bid for bid in existing if bid not in to_remove]

            self.storage.update_task(task_id, {'blocked_by': updated_blocked})
            updated = self.search.search_by_id(task_id)
            output = self._format_output([updated], args)
            print(output)
            return ExitCode.SUCCESS

        except Exception as e:
            print(f"Error removing dependency: {e}", file=sys.stderr)
            return ExitCode.GENERAL_ERROR

    def cmd_ready(self, args: argparse.Namespace) -> int:
        """Handle ready command — list tasks that can be worked on now."""
        try:
            all_tasks = self._load_all_tasks_for_graph()
            graph = DependencyGraph(all_tasks)
            ready_ids = graph.get_ready_tasks()

            # Build result list from ready IDs
            all_ready_results = []
            for task_id in ready_ids:
                task = self.search.search_by_id(task_id)
                if task:
                    all_ready_results.append(task)

            # Filter by tag if specified
            tag_filter = self._parse_comma_separated_values(getattr(args, 'tag', None))
            if tag_filter:
                filtered = []
                for task in all_ready_results:
                    task_tags = task.get('feature_tags') or []
                    if any(t in task_tags for t in tag_filter):
                        filtered.append(task)
                all_ready_results = filtered

            # Optional status filtering for ready set (space/comma separated)
            status_filter = self._parse_comma_separated_values(getattr(args, 'status', None))
            if status_filter:
                allowed_statuses = set(status_filter)
                all_ready_results = [
                    task for task in all_ready_results if task.get('status') in allowed_statuses
                ]

            # Apply shared sort-order contract by last_modified and honor explicit
            # status-order requests when --status is provided.
            sort_order = getattr(args, 'sort', 'desc')
            if status_filter:
                all_ready_results = self.search.sort_tasks_by_status_sequence(
                    all_ready_results,
                    status_filter,
                    sort_order,
                )
            else:
                all_ready_results = self.search.sort_tasks_by_last_modified(all_ready_results, sort_order)

            if not all_ready_results:
                print("No ready tasks found")
                return ExitCode.SUCCESS

            # Apply limit for display output only (summary should reflect full ready set)
            display_results = all_ready_results
            limit = args.limit
            if limit and limit > 0:
                display_results = all_ready_results[:limit]

            # Determine output format (command-specific or global)
            ready_fmt = getattr(args, 'ready_format', None)
            if ready_fmt:
                args.format = ready_fmt

            # Handle --raw flag from ready subparser
            if getattr(args, 'ready_raw', False):
                args.raw = True

            output = self._format_output(display_results, args)
            print(output)

            # Show summary/count context (parity with list/search contracts)
            self._show_summary_stats(all_ready_results, args, displayed_count=len(display_results))
            return ExitCode.SUCCESS

        except Exception as e:
            print(f"Error listing ready tasks: {e}", file=sys.stderr)
            return ExitCode.GENERAL_ERROR

    def cmd_order(self, args: argparse.Namespace) -> int:
        """Handle order command — show execution order via topological sort."""
        try:
            all_tasks = self._load_all_tasks_for_graph()

            # Filter to only open tasks for ordering
            open_tasks = [t for t in all_tasks if t.get('status') in ('backlog', 'todo', 'in_progress')]

            if not open_tasks:
                print("No open tasks to order")
                return ExitCode.SUCCESS

            graph = DependencyGraph(open_tasks)

            try:
                order = graph.topological_sort()
            except ValueError as e:
                print(f"Error: {e}", file=sys.stderr)
                return ExitCode.GENERAL_ERROR

            include_scores = getattr(args, 'scores', False)

            # Build result list in topological order
            results = []
            for task_id in order:
                task = self.search.search_by_id(task_id)
                if task:
                    if include_scores:
                        task_copy = task.copy()
                        task_copy['_priority_score'] = graph.get_priority_score(task_id)
                        results.append(task_copy)
                    else:
                        results.append(task)

            if not results:
                print("No open tasks to order")
                return ExitCode.SUCCESS

            # Determine output format
            order_fmt = getattr(args, 'order_format', None)
            if order_fmt:
                args.format = order_fmt

            output = self._format_output(results, args)
            print(output)
            return ExitCode.SUCCESS

        except Exception as e:
            print(f"Error computing execution order: {e}", file=sys.stderr)
            return ExitCode.GENERAL_ERROR

    def _get_completion_subparsers_action(self) -> Optional[argparse._SubParsersAction]:
        """Return the argparse subparsers action from the root parser."""
        for action in self.parser._actions:
            if isinstance(action, argparse._SubParsersAction):
                return action
        return None

    def _get_completion_status_values(self) -> List[str]:
        """Get status values for completion without requiring runtime config loading."""
        return list(Config.DEFAULT_CONFIG.get('status_workflow', {}).get('values', [
            'backlog', 'todo', 'in_progress', 'done', 'archive'
        ]))

    def _get_completion_metadata(self) -> Tuple[List[str], List[str], Dict[str, Dict[str, Any]]]:
        """Build completion metadata from argparse parser definitions (single source of truth)."""
        subparsers_action = self._get_completion_subparsers_action()
        if not subparsers_action:
            return [], [], {}

        command_names = sorted(
            [name for name in subparsers_action.choices.keys() if name != '__complete']
        )

        global_options: Set[str] = set()
        for action in self.parser._actions:
            if action.option_strings:
                global_options.update(action.option_strings)

        metadata: Dict[str, Dict[str, Any]] = {}

        for command_name, command_parser in subparsers_action.choices.items():
            if command_name == '__complete':
                continue

            command_options: Set[str] = set()
            option_values: Dict[str, List[str]] = {}
            positional_args: List[str] = []

            for action in command_parser._actions:
                if isinstance(action, argparse._HelpAction):
                    continue

                if action.option_strings:
                    command_options.update(action.option_strings)

                    if action.choices:
                        values = [str(choice) for choice in action.choices]
                        for option in action.option_strings:
                            option_values[option] = values

                    if any(option in ('--status',) for option in action.option_strings):
                        status_values = self._get_completion_status_values()
                        for option in action.option_strings:
                            if option == '--status':
                                option_values[option] = status_values
                else:
                    positional_args.append(action.dest)

                    if action.choices:
                        option_values[action.dest] = [str(choice) for choice in action.choices]

            if command_name == 'mark':
                option_values['status'] = self._get_completion_status_values()
            elif command_name == 'deps':
                option_values['action_or_id'] = ['add', 'remove']

            metadata[command_name] = {
                'options': sorted(command_options),
                'option_values': option_values,
                'positionals': positional_args,
            }

        return command_names, sorted(global_options), metadata

    def _filter_completion_candidates(self, candidates: List[str], prefix: str) -> List[str]:
        """Filter and dedupe completion candidates based on prefix."""
        seen = set()
        filtered: List[str] = []

        for candidate in candidates:
            if not candidate:
                continue
            if prefix and not candidate.startswith(prefix):
                continue
            if candidate in seen:
                continue
            seen.add(candidate)
            filtered.append(candidate)

        return filtered

    def _suggest_option_values(self, command_name: str, option_token: str, metadata: Dict[str, Dict[str, Any]]) -> List[str]:
        """Suggest values for option tokens when applicable."""
        command_meta = metadata.get(command_name, {})
        option_values = command_meta.get('option_values', {})

        if option_token in option_values:
            return option_values[option_token]

        if option_token in ('-f', '--format'):
            return ['ndjson', 'json', 'xml', 'table']

        return []

    def _compute_completion_candidates(self, words: List[str], cursor_index: int) -> List[str]:
        """Compute completion candidates from parser metadata and cursor state."""
        command_names, global_options, metadata = self._get_completion_metadata()
        if not words:
            return command_names

        safe_index = max(0, min(cursor_index, len(words) - 1))
        current = words[safe_index] if words else ''
        tokens_before = words[1:safe_index]

        selected_command = None
        selected_command_index = None

        for index, token in enumerate(tokens_before, start=1):
            if token in command_names:
                selected_command = token
                selected_command_index = index
                break

        if not selected_command:
            base = global_options if current.startswith('-') else command_names + global_options
            return self._filter_completion_candidates(base, current)

        # command-specific completion
        command_meta = metadata.get(selected_command, {})
        command_options = command_meta.get('options', [])
        command_positionals = command_meta.get('positionals', [])

        previous_token = words[safe_index - 1] if safe_index > 0 else ''

        if previous_token.startswith('-'):
            option_value_candidates = self._suggest_option_values(selected_command, previous_token, metadata)
            if option_value_candidates:
                return self._filter_completion_candidates(option_value_candidates, current)

        command_tokens_before_cursor = words[(selected_command_index + 1):safe_index] if selected_command_index is not None else []
        positional_index = len([token for token in command_tokens_before_cursor if token and not token.startswith('-')])

        if selected_command == 'mark' and positional_index == 0 and not current.startswith('-'):
            return self._filter_completion_candidates(self._get_completion_status_values(), current)

        if selected_command == 'deps' and positional_index == 0 and not current.startswith('-'):
            return self._filter_completion_candidates(['add', 'remove'], current)

        if selected_command == 'completion' and positional_index == 0 and not current.startswith('-'):
            return self._filter_completion_candidates(['bash', 'zsh', 'fish'], current)

        positional_dest = command_positionals[positional_index] if positional_index < len(command_positionals) else None
        if positional_dest:
            positional_values = command_meta.get('option_values', {}).get(positional_dest, [])
            if positional_values and not current.startswith('-'):
                return self._filter_completion_candidates(positional_values, current)

        candidates = command_options + global_options if current.startswith('-') else command_options + global_options
        return self._filter_completion_candidates(candidates, current)

    def _generate_bash_completion_script(self) -> str:
        """Generate bash completion script."""
        command_name = self._get_command_name()

        return f'''# bash completion for {command_name}
_{command_name.replace('-', '_')}_completion() {{
  local cur
  cur="${{COMP_WORDS[COMP_CWORD]}}"

  local suggestions
  suggestions=$(\
    {command_name} __complete --index "$COMP_CWORD" -- "${{COMP_WORDS[@]}}" 2>/dev/null
  )

  COMPREPLY=($(compgen -W "$suggestions" -- "$cur"))
}}

complete -o default -F _{command_name.replace('-', '_')}_completion juno-kanban juno-feedback kanban-juno
'''

    def _generate_zsh_completion_script(self) -> str:
        """Generate zsh completion script via bashcompinit for portability."""
        command_name = self._get_command_name()

        return f'''#compdef juno-kanban juno-feedback kanban-juno
# zsh completion for {command_name}
autoload -U +X bashcompinit && bashcompinit
_{command_name.replace('-', '_')}_completion() {{
  local cur
  cur="${{COMP_WORDS[COMP_CWORD]}}"

  local suggestions
  suggestions=$(\
    {command_name} __complete --index "$COMP_CWORD" -- "${{COMP_WORDS[@]}}" 2>/dev/null
  )

  COMPREPLY=($(compgen -W "$suggestions" -- "$cur"))
}}

complete -o default -F _{command_name.replace('-', '_')}_completion juno-kanban juno-feedback kanban-juno
'''

    def _generate_fish_completion_script(self) -> str:
        """Generate fish completion script."""
        command_name = self._get_command_name()

        return f'''# fish completion for {command_name}
function __{command_name.replace('-', '_')}_complete
    set -l tokens (commandline -opc)
    set -l cur (commandline -ct)
    set -l idx (count $tokens)

    {command_name} __complete --index $idx -- $tokens "$cur" 2>/dev/null
end

complete -c juno-kanban -f -a "(__{command_name.replace('-', '_')}_complete)"
complete -c juno-feedback -f -a "(__{command_name.replace('-', '_')}_complete)"
complete -c kanban-juno -f -a "(__{command_name.replace('-', '_')}_complete)"
'''

    def cmd_completion(self, args: argparse.Namespace) -> int:
        """Handle completion command: print shell completion script."""
        shell = getattr(args, 'shell', 'bash')

        if shell == 'bash':
            print(self._generate_bash_completion_script())
        elif shell == 'zsh':
            print(self._generate_zsh_completion_script())
        elif shell == 'fish':
            print(self._generate_fish_completion_script())
        else:
            print(f"Unsupported shell: {shell}", file=sys.stderr)
            return ExitCode.INVALID_USAGE

        return ExitCode.SUCCESS

    def cmd_internal_complete(self, args: argparse.Namespace) -> int:
        """Internal completion candidate command for shell scripts."""
        words = list(getattr(args, 'words', []) or [])
        if not words:
            return ExitCode.SUCCESS

        index = getattr(args, 'index', 0)
        suggestions = self._compute_completion_candidates(words, index)

        if suggestions:
            print('\n'.join(suggestions))

        return ExitCode.SUCCESS

    def show_help(self, args: argparse.Namespace) -> int:
        """Show help text optimized for LLM token efficiency — schema-driven, no fluff."""
        cn = self._get_command_name()

        # Task schema — LLMs need to know field names to construct queries
        print(f"{cn} COMMAND [OPTIONS]")
        print()
        print("TASK SCHEMA:")
        print("  {id, status, body, commit_hash, agent_response, created_date, last_modified, feature_tags[], related_tasks[], blocked_by[]}")
        available_statuses = ', '.join(self.config.status_values) if self.config and hasattr(self.config, 'status_values') else 'backlog, todo, in_progress, done, archive'
        print(f"  Statuses: {available_statuses}")
        print("  IDs: 6-char alphanumeric (auto-generated)")
        print()

        # Command signatures — show exact syntax, required vs optional
        print("COMMANDS:")
        print(f"  {cn} create  BODY [--status S] [--tags T...] [--commit H] [--related-tasks ID...] [--blocked-by ID...]")
        print(f"  {cn} get     TASK_ID [TASK_ID ...] | --ID TASK_ID")
        print(f"  {cn} update  TASK_ID | --ID TASK_ID [--status S] [--response TEXT] [--commit H] [--tags T...] [--blocked-by ID...]")
        print(f"  {cn} mark    STATUS TASK_ID | --ID TASK_ID --response TEXT [--commit H]")
        print(f"  {cn} archive TASK_ID | --ID TASK_ID")
        print(f"  {cn} list    [--status S...] [--tag T...] [--exclude T...] [--limit N] [--sort asc|desc] [--open] [--recent] [-f FMT]")
        print(f"  {cn} search  [--id ID] [--status S...] [--tag T...] [--exclude T...] [--body TEXT] [--response TEXT] [--commit H] [--open] [--recent] [--limit N] [--sort asc|desc]")
        print(f"  {cn} tags    [--status S...] [-f FMT]                    Tag counts (supports comma/space status filters)")
        print(f"  {cn} deps    TASK_ID                                      Show blockers, dependents, priority score")
        print(f"  {cn} deps    add --id TASK_ID --blocked-by ID...          Add dependency (cycle-checked)")
        print(f"  {cn} deps    remove --id TASK_ID --blocked-by ID...       Remove dependency")
        print(f"  {cn} ready   [--tag T...] [--status S...] [--limit N] [--sort asc|desc] [-f FMT]  Unblocked tasks (status order follows --status when provided)")
        print(f"  {cn} order   [--scores] [-f FMT]                          Topological sort of open tasks")
        print(f"  {cn} merge   SOURCES --into TARGET [--strategy keep-newer|keep-both] [--dry-run] [--find-all]")
        print(f"  {cn} completion [bash|zsh|fish]                     Print shell completion script")
        print()

        # Global options
        print("GLOBAL OPTIONS:")
        print("  -f FMT    Output: ndjson (default) | json | xml | table")
        print("  --raw     Compact output for scripting")
        print("  -p        Pretty-print json/xml")
        print("  -c PATH   Config file (default: .juno_task/tasks/config.json)")
        print()

        # Body markup — critical for correct task creation
        print("BODY MARKUP (auto-parsed on create):")
        print("  [task_id]ID1, ID2[/task_id]         -> related_tasks")
        print("  ## ID1 ID2 ##  or  ##ID1            -> related_tasks")
        print("  [blocked_by]ID1, ID2[/blocked_by]   -> blocked_by  (synonyms: block_by, block, parent_task)")
        print()

        # Dependency model — essential for understanding ready/order/deps
        print("DEPENDENCY MODEL:")
        print("  blocked_by: list of task IDs that must complete (done/archive) before this task")
        print("  ready:  tasks with status in [backlog, todo, in_progress] + all blockers resolved (optional --status filter keeps provided status order)")
        print("  order:  topological sort respecting blocked_by — safe parallel execution order")
        print("  deps:   query blockers/dependents/priority-score for any task")
        print()

        # Environment variables
        print("ENVIRONMENT:")
        print("  JUNO_TASK_ROOT=PATH   Pin .juno_task directory to PATH (overrides PWD-based search)")
        print("                        Prevents scattered ndjson files when running from different dirs")
        print()

        # Stdin support
        print("STDIN: echo \"body\" | " + cn + " create [--tags T...]")
        print()

        print(f"Per-command help: {cn} COMMAND --help")
        return ExitCode.SUCCESS

    def _print_error_hints(self, args: List[str]) -> None:
        """Print helpful hints after an argparse error, based on which command was attempted."""
        cn = self._get_command_name()

        # Detect the command from args (first non-flag argument)
        command = None
        for arg in args:
            if not arg.startswith('-'):
                command = arg
                break

        print(file=sys.stderr)

        if command == 'deps':
            print("Deps usage:", file=sys.stderr)
            print(f"  {cn} deps TASK_ID                                  Show blockers, dependents, priority score", file=sys.stderr)
            print(f"  {cn} deps add --id TASK_ID --blocked-by ID...      Add dependency (cycle-checked)", file=sys.stderr)
            print(f"  {cn} deps remove --id TASK_ID --blocked-by ID...   Remove dependency", file=sys.stderr)
            print(f"  {cn} deps --id TASK_ID --blocked-by ID...          Shorthand for add", file=sys.stderr)
        elif command == 'mark':
            print("Mark usage:", file=sys.stderr)
            print(f"  {cn} mark STATUS TASK_ID --response \"message\"", file=sys.stderr)
            print(f"  {cn} mark STATUS --id TASK_ID --response \"message\"", file=sys.stderr)
            print(f"  Example: {cn} mark done ABC123 --response \"task completed\"", file=sys.stderr)
        elif command == 'create':
            print("Create usage:", file=sys.stderr)
            print(f"  {cn} create \"task body\" [--status S] [--tags T...] [--blocked-by ID...]", file=sys.stderr)
            print(f"  {cn} create --title \"title\" --body \"body\" [--status S] [--tags T...]", file=sys.stderr)
        elif command == 'update':
            print("Update usage:", file=sys.stderr)
            print(f"  {cn} update TASK_ID [--status S] [--response TEXT] [--commit H] [--tags T...]", file=sys.stderr)
            print(f"  {cn} update --id TASK_ID [--status S] [--response TEXT] [--commit H] [--tags T...]", file=sys.stderr)
        elif command == 'list':
            print("List usage:", file=sys.stderr)
            print(f"  {cn} list [--status S...] [--tag T...] [--limit N] [--sort asc|desc]", file=sys.stderr)
        elif command == 'tags':
            print("Tags usage:", file=sys.stderr)
            print(f"  {cn} tags [--status S...] [--format ndjson|json|xml|table]", file=sys.stderr)
        elif command == 'merge':
            print("Merge usage:", file=sys.stderr)
            print(f"  {cn} merge SOURCE... --into TARGET [--strategy keep-newer|keep-both] [--dry-run]", file=sys.stderr)
        else:
            print(f"Run '{cn} --help' to see all commands and usage examples.", file=sys.stderr)
            return

        print(f"\nRun '{cn} {command} --help' for detailed options.", file=sys.stderr)

    def _read_stdin_if_available(self) -> Optional[str]:
        """
        Read from stdin if data is available (piped input).

        This checks if stdin has data without blocking, allowing:
        - echo "task body" | juno-kanban
        - juno-kanban << 'EOF'
          task body
          EOF
        - cat file.txt | juno-kanban

        Returns:
            The stdin content stripped of leading/trailing whitespace,
            or None if stdin is a terminal (interactive) or empty.
        """
        import select

        # Check if stdin is a tty (interactive terminal)
        # If it's a tty, we don't want to wait for input
        if sys.stdin.isatty():
            return None

        # For non-tty stdin (piped input), try to read
        try:
            # On Unix-like systems, use select to check if data is available
            # On Windows, this approach may differ, but sys.stdin.isatty() covers most cases
            if hasattr(select, 'select'):
                # Check if stdin has data ready (with 0 timeout = non-blocking)
                readable, _, _ = select.select([sys.stdin], [], [], 0)
                if not readable:
                    # No data available yet, but stdin is not a tty
                    # This could be a pipe that will have data, so read it
                    pass

            # Read all available stdin content
            stdin_content = sys.stdin.read()

            if stdin_content:
                return stdin_content.strip()
            return None

        except Exception:
            # If anything goes wrong reading stdin, fall back to normal behavior
            return None

    def run(self, args: Optional[List[str]] = None) -> int:
        """
        Run the CLI application.

        Args:
            args: Command line arguments (default: sys.argv[1:])

        Returns:
            Exit code
        """
        try:
            # Check for shortcut syntax before parsing
            args_to_parse = args if args is not None else sys.argv[1:]

            # Check for stdin input (piped data)
            # This supports: echo "task" | juno-kanban or juno-kanban << 'EOF'
            stdin_body = self._read_stdin_if_available()

            if stdin_body and not args_to_parse:
                # Stdin has content and no args provided
                # Treat as shortcut: equivalent to juno-kanban "{stdin content}"
                args_to_parse = ['create', stdin_body]
            elif stdin_body and args_to_parse:
                # Stdin has content AND args provided
                # If args is just flags (starts with -) or a command without body,
                # append stdin as the body
                first_arg = args_to_parse[0] if args_to_parse else ''

                if first_arg == 'create':
                    # create command - check if body is already provided
                    has_body_flag = '--body' in args_to_parse
                    # Check if there's a positional body after 'create'
                    has_positional_body = len(args_to_parse) > 1 and not args_to_parse[1].startswith('-')

                    if not has_body_flag and not has_positional_body:
                        # No body provided, use stdin as body
                        # Insert right after 'create' command (position 1), before any flags
                        args_to_parse = ['create', stdin_body] + args_to_parse[1:]
                elif first_arg.startswith('-') or first_arg not in ['create', 'search', 'get', 'show', 'update', 'list', 'archive', 'mark', 'merge', 'deps', 'ready', 'order', 'tags', 'completion', '__complete']:
                    # No command specified or shortcut syntax with flags
                    # Treat stdin as task body for create
                    if first_arg.startswith('-'):
                        # Flags provided: juno-kanban --tags backend < task.txt
                        args_to_parse = ['create', stdin_body] + args_to_parse
                    else:
                        # Unknown first arg (could be shortcut body ignored, use stdin)
                        args_to_parse = ['create', stdin_body]

            # Handle 'help' keyword as equivalent to --help / no-command help display
            if args_to_parse and args_to_parse[0] == 'help':
                if len(args_to_parse) == 1:
                    # juno-kanban help -> show full help (same as juno-kanban with no args)
                    args_to_parse = []
                else:
                    # juno-kanban help <command> -> juno-kanban <command> --help
                    args_to_parse = args_to_parse[1:] + ['--help']

            if args_to_parse and len(args_to_parse) > 0 and not args_to_parse[0].startswith('-'):
                # Check if first argument is not a known command
                known_commands = ['create', 'search', 'get', 'show', 'update', 'list', 'archive', 'mark', 'merge', 'deps', 'ready', 'order', 'tags', 'completion', '__complete']
                if args_to_parse[0] not in known_commands:
                    # Treat as shortcut: juno-kanban "task body" -> juno-kanban create "task body"
                    args_to_parse = ['create'] + args_to_parse

            # Preprocess arguments for case-insensitive handling
            args_to_parse = self._normalize_arguments(args_to_parse)

            try:
                parsed_args = self.parser.parse_args(args_to_parse)
            except SystemExit as e:
                if e.code == 2:
                    # argparse already printed usage + error to stderr
                    # Add helpful hints based on which command was attempted
                    self._print_error_hints(args_to_parse)
                    return ExitCode.INVALID_USAGE
                raise

            # Handle commands that do not require config/storage initialization
            if parsed_args.command == 'completion':
                return self.cmd_completion(parsed_args)

            if parsed_args.command == '__complete':
                return self.cmd_internal_complete(parsed_args)

            # Initialize components with config path
            self._init_components(parsed_args.config)

            # Handle commands
            if not parsed_args.command:
                # No command specified - show help
                return self.show_help(parsed_args)

            elif parsed_args.command == 'create':
                return self.cmd_create(parsed_args)

            elif parsed_args.command == 'search':
                return self.cmd_search(parsed_args)

            elif parsed_args.command == 'get':
                return self.cmd_get(parsed_args)

            elif parsed_args.command == 'show':
                return self.cmd_get(parsed_args)  # Alias for get command

            elif parsed_args.command == 'update':
                return self.cmd_update(parsed_args)

            elif parsed_args.command == 'list':
                return self.cmd_list(parsed_args)

            elif parsed_args.command == 'archive':
                return self.cmd_archive(parsed_args)

            elif parsed_args.command == 'mark':
                return self.cmd_mark(parsed_args)

            elif parsed_args.command == 'merge':
                return self.cmd_merge(parsed_args)

            elif parsed_args.command == 'deps':
                return self.cmd_deps(parsed_args)

            elif parsed_args.command == 'ready':
                return self.cmd_ready(parsed_args)

            elif parsed_args.command == 'tags':
                return self.cmd_tags(parsed_args)

            elif parsed_args.command == 'order':
                return self.cmd_order(parsed_args)

            else:
                print(f"Unknown command: {parsed_args.command}", file=sys.stderr)
                return ExitCode.INVALID_USAGE

        except KeyboardInterrupt:
            print("\nInterrupted", file=sys.stderr)
            return ExitCode.GENERAL_ERROR

        except BrokenPipeError:
            # Handle broken pipe (e.g., piping to head)
            return ExitCode.SUCCESS

        except Exception as e:
            print(f"Unexpected error: {e}", file=sys.stderr)
            if hasattr(parsed_args, 'verbose') and parsed_args.verbose:
                import traceback
                traceback.print_exc()
            return ExitCode.GENERAL_ERROR


def main(args: Optional[List[str]] = None) -> int:
    """
    Main entry point for the CLI.

    Args:
        args: Command line arguments (default: sys.argv[1:])

    Returns:
        Exit code
    """
    cli = TaskCLI()
    return cli.run(args)


if __name__ == '__main__':
    sys.exit(main())