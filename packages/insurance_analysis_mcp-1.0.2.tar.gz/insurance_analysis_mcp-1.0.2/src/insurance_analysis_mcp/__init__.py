"""Insurance Analysis MCP Tool - 通过CoT思维链分析保险客户价值"""

__version__ = "1.0.0"
