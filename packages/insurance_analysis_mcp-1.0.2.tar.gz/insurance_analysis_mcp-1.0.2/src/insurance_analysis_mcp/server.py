"""
保险客户分析MCP服务器 - 基于CoT思维链的客户价值评估
"""
import asyncio
import json
import logging
import os
from typing import Dict, Any, Optional

from mcp.server.fastmcp import FastMCP
from insurance_analysis_mcp.analyzer import InsuranceCustomerAnalyzer

# 配置日志
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger("insurance-analysis-mcp")

# 创建MCP Server实例
mcp = FastMCP(
    "insurance-analysis-mcp",
    instructions="""这是一个保险客户分析工具，使用CoT（Chain of Thought）思维链进行客户价值评估。
    
功能包括：
1. 分析客户挽回价值和续保概率
2. 提供详细的多维度分析报告
3. 生成可执行的行动建议

使用方法：
- 调用 analyze_customer_retention_value 工具来分析客户是否值得挽留
- 需要提供客户基本信息、保单数据和理赔记录
"""
)

# 初始化分析器
analyzer = InsuranceCustomerAnalyzer()


@mcp.tool()
async def analyze_customer_retention_value(
    customer_data: Dict[str, Any],
    policy_data: Optional[Dict[str, Any]] = None,
    claim_data: Optional[Dict[str, Any]] = None
) -> str:
    """
    分析客户挽回价值和续保概率

    使用CoT（思维链）推理方法，从多个维度分析客户价值：
    - 步骤1：需求理解
    - 步骤2：数据收集与整理
    - 步骤3：多维度分析（价值贡献、风险水平、客户忠诚度、未来发展潜力）
    - 步骤4：综合判断
    - 步骤5：行动建议

    Args:
        customer_data: 客户基本信息
            - customer_id: 客户ID
            - name: 客户姓名
            - level: 客户等级 (VIP, 普通, 潜力)
            - total_premium: 累计保费
            - registration_date: 注册日期
        policy_data: 保单信息列表 (可选)
        claim_data: 理赔记录列表 (可选)

    Returns:
        JSON格式的详细分析报告，包含思维链过程和最终建议
    """
    try:
        # 安全地获取客户ID用于日志记录
        customer_id = "unknown"
        if isinstance(customer_data, dict):
            customer_id = customer_data.get('customer_id', 'unknown')

        logger.info(f"开始分析客户 {customer_id} 的挽回价值")

        result = await analyzer.analyze_customer_retention_value(
            customer_data=customer_data,
            policy_data=policy_data,
            claim_data=claim_data
        )

        logger.info(f"完成对客户 {customer_id} 的分析")
        return result

    except Exception as e:
        logger.error(f"分析客户数据时发生错误: {str(e)}")
        error_response = {
            "error": f"分析过程中发生错误: {str(e)}",
            "success": False
        }
        return json.dumps(error_response, ensure_ascii=False, indent=2)


@mcp.tool()
async def get_analysis_framework_info() -> str:
    """
    获取分析框架信息，包括使用的CoT思维链方法说明
    """
    framework_info = {
        "framework_name": "Insurance Customer Analysis with CoT Reasoning",
        "methodology": "Chain of Thought (CoT)",
        "analysis_steps": [
            {
                "step": 1,
                "name": "需求理解",
                "description": "明确用户想分析什么，识别需要调用的数据"
            },
            {
                "step": 2,
                "name": "数据收集与整理",
                "description": "获取客户、保单、理赔等基础数据并计算关键指标"
            },
            {
                "step": 3,
                "name": "多维度分析",
                "dimensions": [
                    "价值贡献评估",
                    "风险水平评估",
                    "客户忠诚度评估",
                    "未来发展潜力评估"
                ]
            },
            {
                "step": 4,
                "name": "综合判断",
                "description": "基于加权评分给出总体评价和挽留建议"
            },
            {
                "step": 5,
                "name": "行动建议",
                "description": "提供具体的优先行动项和ROI预估"
            }
        ],
        "evaluation_criteria": {
            "value_contribution": "年化保费、VIP状态、保单数量",
            "risk_assessment": "理赔率、理赔频次",
            "loyalty_evaluation": "合作年限、保单多样性、VIP状态",
            "potential_assessment": "当前价值、产品多样性、到期保单数"
        },
        "output_format": {
            "retention_recommendation": ["重点挽留", "建议挽留", "选择性挽留", "不建议重点挽留"],
            "confidence_level": ["高", "中", "低"],
            "estimated_probability": "百分比形式表示续保可能性"
        }
    }

    return json.dumps(framework_info, ensure_ascii=False, indent=2)


def main():
    """MCP服务器主入口"""
    logger.info("启动保险客户分析MCP服务器...")
    logger.info("服务器支持基于CoT思维链的客户价值评估")

    # 根据环境变量选择运行模式
    transport_mode = os.getenv("MCP_TRANSPORT_MODE", "stdio")  # 默认使用stdio

    if transport_mode == "sse":
        # SSE模式 - 适用于云环境（如百炼平台）
        import sys
        from mcp.transport.sse import ServerSentEventsTransport
        transport = ServerSentEventsTransport()
        mcp.run(transport=transport)
    else:
        # stdio模式 - 适用于本地开发和CLI环境
        mcp.run()


if __name__ == "__main__":
    main()
