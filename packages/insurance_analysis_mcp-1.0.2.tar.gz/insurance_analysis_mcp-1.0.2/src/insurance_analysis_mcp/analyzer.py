"""
保险客户分析器 - 基于CoT思维链的客户价值评估
"""
import json
from datetime import datetime
from typing import Dict, Any, Optional


class InsuranceCustomerAnalyzer:
    """保险客户分析器，使用CoT思维链进行客户价值评估"""
    
    def __init__(self):
        pass

    async def analyze_customer_retention_value(
        self,
        customer_data: Dict[str, Any],
        policy_data: Optional[Dict[str, Any]] = None,
        claim_data: Optional[Dict[str, Any]] = None
    ) -> str:
        """
        分析客户挽回价值和续保概率
        
        Args:
            customer_data: 客户基本信息 {customer_id, name, level, total_premium, registration_date等}
            policy_data: 保单信息列表
            claim_data: 理赔记录列表
            
        Returns:
            JSON格式的分析结果
        """
        try:
            # CoT思维链：步骤1 - 需求理解
            analysis_steps = {
                "step_1_understanding": {
                    "purpose": "分析客户是否值得重点挽留",
                    "key_metrics_to_evaluate": [
                        "客户价值贡献",
                        "风险水平评估", 
                        "客户粘性分析",
                        "未来潜力预测"
                    ]
                }
            }

            # CoT思维链：步骤2 - 数据收集与整理
            customer_info = customer_data
            policies = policy_data or []
            claims = claim_data or []

            # 计算关键指标
            metrics = self._calculate_key_metrics(customer_info, policies, claims)
            
            analysis_steps["step_2_data_collection"] = {
                "customer_info_summary": {
                    "name": customer_info.get("name"),
                    "level": customer_info.get("level", "Unknown"),
                    "total_premium": customer_info.get("total_premium", 0),
                    "registration_days": self._calculate_registration_days(customer_info)
                },
                "policy_count": len(policies),
                "claim_count": len(claims),
                "calculated_metrics": metrics
            }

            # CoT思维链：步骤3 - 多维度分析
            value_assessment = self._assess_value(metrics)
            risk_assessment = self._assess_risk(metrics)
            loyalty_assessment = self._assess_loyalty(metrics)
            potential_assessment = self._assess_potential(metrics)

            analysis_steps["step_3_multi_dimension_analysis"] = {
                "value_assessment": value_assessment,
                "risk_assessment": risk_assessment,
                "loyalty_assessment": loyalty_assessment,
                "potential_assessment": potential_assessment
            }

            # CoT思维链：步骤4 - 综合判断
            overall_score, retention_recommendation, confidence = self._overall_judgment(
                value_assessment, risk_assessment, loyalty_assessment, potential_assessment
            )

            analysis_steps["step_4_comprehensive_judgement"] = {
                "overall_score": overall_score,
                "retention_recommendation": retention_recommendation,
                "confidence_level": confidence,
                "supporting_reasons": self._generate_supporting_reasons(
                    value_assessment, risk_assessment, loyalty_assessment, potential_assessment
                ),
                "risk_factors": self._identify_risk_factors(metrics)
            }

            # CoT思维链：步骤5 - 行动建议
            action_suggestions = self._generate_action_suggestions(
                retention_recommendation, metrics, customer_info
            )

            analysis_steps["step_5_action_suggestions"] = action_suggestions

            # 构建最终结果
            result = {
                "customer_id": customer_info.get("customer_id"),
                "analysis_process": analysis_steps,
                "final_recommendation": {
                    "retention_priority": retention_recommendation,
                    "estimated_retention_probability": f"{int(overall_score * 10)}%",
                    "overall_confidence": confidence,
                    "summary_scorecard": {
                        "value_contribution": value_assessment.get("score"),
                        "risk_level": risk_assessment.get("score"),
                        "customer_loyalty": loyalty_assessment.get("score"),
                        "future_potential": potential_assessment.get("score"),
                        "composite_score": overall_score
                    }
                }
            }

            return json.dumps(result, ensure_ascii=False, indent=2, default=str)

        except Exception as e:
            error_result = {
                "error": str(e),
                "customer_id": customer_data.get("customer_id") if isinstance(customer_data, dict) else "unknown"
            }
            return json.dumps(error_result, ensure_ascii=False, indent=2)

    def _calculate_registration_days(self, customer_info: Dict) -> int:
        """计算注册天数"""
        try:
            reg_date = customer_info.get("registration_date")
            if reg_date and hasattr(reg_date, 'date'):
                # 如果是datetime对象
                return (datetime.now() - reg_date).days
            elif reg_date and isinstance(reg_date, str):
                # 如果是日期字符串，尝试解析
                from datetime import datetime
                parsed_date = datetime.fromisoformat(reg_date.replace('Z', '+00:00'))
                return (datetime.now() - parsed_date).days
            else:
                return 0
        except Exception:
            return 0

    def _calculate_key_metrics(self, customer_info: Dict, policies: list, claims: list) -> Dict[str, Any]:
        """计算关键指标"""
        from datetime import datetime
        
        total_premium = customer_info.get("total_premium", 0)
        
        # 计算年化保费
        reg_date = customer_info.get("registration_date")
        years_as_customer = 0
        if reg_date and hasattr(reg_date, 'year'):
            years_as_customer = (datetime.now() - reg_date).days / 365.25
        annualized_premium = total_premium / max(years_as_customer, 0.1)  # 避免除零
        
        # 计算理赔相关指标
        total_claim_amount = sum([c.get("claim_amount", 0) for c in claims])
        claim_frequency = len(claims) / max(years_as_customer, 0.1)
        claim_rate = total_claim_amount / max(total_premium, 1)  # 避免除零
        
        # 计算保单多样性
        policy_types = set([p.get("policy_type", "") for p in policies])
        policy_diversity = len(policy_types)
        
        # 即将到期保单数
        expiring_policies = 0
        current_date = datetime.now()
        for policy in policies:
            end_date = policy.get("end_date")
            if end_date and hasattr(end_date, 'date'):
                days_to_expire = (end_date.date() - current_date.date()).days
                if 0 <= days_to_expire <= 30:  # 30天内到期
                    expiring_policies += 1

        return {
            "annualized_premium": annualized_premium,
            "years_as_customer": years_as_customer,
            "total_claim_amount": total_claim_amount,
            "claim_frequency": claim_frequency,
            "claim_rate": claim_rate,
            "policy_count": len(policies),
            "policy_diversity": policy_diversity,
            "expiring_policies": expiring_policies,
            "vip_status": customer_info.get("level", "").lower() == "vip"
        }

    def _assess_value(self, metrics: Dict[str, Any]) -> Dict[str, Any]:
        """价值贡献评估"""
        score = 0
        factors = []
        
        # 年化保费评估
        if metrics["annualized_premium"] >= 50000:
            score += 10
            factors.append("年化保费≥5万，高价值客户")
        elif metrics["annualized_premium"] >= 20000:
            score += 8
            factors.append("年化保费≥2万，中高价值客户")
        elif metrics["annualized_premium"] >= 5000:
            score += 5
            factors.append("年化保费≥5千，中等价值客户")
        else:
            score += 2
            factors.append("年化保费较低")
        
        # VIP状态
        if metrics["vip_status"]:
            score += 3
            factors.append("VIP客户身份")
        
        # 保单数量
        if metrics["policy_count"] >= 3:
            score += 2
            factors.append(f"持有{metrics['policy_count']}份保单，交叉销售成功")
        
        return {
            "dimension": "价值贡献",
            "score": min(score, 10),  # 最高10分
            "factors": factors,
            "interpretation": "高价值客户对公司的收入贡献大，是重要的利润来源"
        }

    def _assess_risk(self, metrics: Dict[str, Any]) -> Dict[str, Any]:
        """风险水平评估"""
        score = 10  # 起始满分，越低风险分数越高
        factors = []
        
        # 理赔率评估（理赔金额/总保费）
        if metrics["claim_rate"] > 0.5:
            score -= 6
            factors.append(f"理赔率{metrics['claim_rate']:.2%}过高，高风险")
        elif metrics["claim_rate"] > 0.2:
            score -= 4
            factors.append(f"理赔率{metrics['claim_rate']:.2%}偏高")
        elif metrics["claim_rate"] > 0.1:
            score -= 2
            factors.append(f"理赔率{metrics['claim_rate']:.2%}适中")
        else:
            score += 0
            factors.append(f"理赔率{metrics['claim_rate']:.2%}很低，低风险")
        
        # 理赔频次评估
        if metrics["claim_frequency"] > 2:
            score -= 3
            factors.append(f"年均理赔{metrics['claim_frequency']:.1f}次，频率较高")
        elif metrics["claim_frequency"] > 1:
            score -= 1
            factors.append(f"年均理赔{metrics['claim_frequency']:.1f}次，频率适中")
        else:
            score += 1
            factors.append(f"年均理赔{metrics['claim_frequency']:.1f}次，频率很低")
        
        return {
            "dimension": "风险水平", 
            "score": max(score, 1),  # 最低1分
            "factors": factors,
            "interpretation": "低风险客户对公司财务稳定性有利"
        }

    def _assess_loyalty(self, metrics: Dict[str, Any]) -> Dict[str, Any]:
        """客户忠诚度评估"""
        score = 0
        factors = []
        
        # 客户年限
        if metrics["years_as_customer"] >= 5:
            score += 5
            factors.append(f"合作{metrics['years_as_customer']:.1f}年，忠诚度很高")
        elif metrics["years_as_customer"] >= 3:
            score += 4
            factors.append(f"合作{metrics['years_as_customer']:.1f}年，忠诚度较高")
        elif metrics["years_as_customer"] >= 1:
            score += 3
            factors.append(f"合作{metrics['years_as_customer']:.1f}年，有一定忠诚度")
        else:
            score += 1
            factors.append(f"合作{metrics['years_as_customer']:.1f}年，新客户")
        
        # 保单多样性
        if metrics["policy_diversity"] >= 3:
            score += 3
            factors.append(f"购买{metrics['policy_diversity']}种不同类型保单，依赖度高")
        elif metrics["policy_diversity"] >= 2:
            score += 2
            factors.append(f"购买{metrics['policy_diversity']}种不同类型保单")
        elif metrics["policy_diversity"] >= 1:
            score += 1
            factors.append(f"购买{metrics['policy_diversity']}种保单")
        
        # VIP状态
        if metrics["vip_status"]:
            score += 2
            factors.append("VIP客户通常流失率更低")
        
        return {
            "dimension": "客户忠诚度",
            "score": min(score, 10),  # 最高10分
            "factors": factors,
            "interpretation": "忠诚客户更有可能续保和推荐他人"
        }

    def _assess_potential(self, metrics: Dict[str, Any]) -> Dict[str, Any]:
        """未来发展潜力评估"""
        score = 0
        factors = []
        
        # 当前价值水平作为潜力基础
        if metrics["annualized_premium"] >= 50000:
            score += 4
            factors.append("当前高价值客户，增长空间大")
        elif metrics["annualized_premium"] >= 20000:
            score += 3
            factors.append("当前中高价值客户，有提升空间")
        elif metrics["annualized_premium"] >= 5000:
            score += 2
            factors.append("当前中等价值客户，可进一步挖掘")
        else:
            score += 1
            factors.append("当前价值一般，但有发展潜力")
        
        # 保单多样性显示需求广泛
        if metrics["policy_diversity"] >= 3:
            score += 3
            factors.append("已购买多种产品，接受新产品意愿高")
        elif metrics["policy_diversity"] >= 2:
            score += 2
            factors.append("已购买多种产品，交叉销售机会多")
        else:
            score += 1
            factors.append("有机会推广更多产品类型")
        
        # 即将到期保单表示续保机会
        if metrics["expiring_policies"] > 0:
            score += 3
            factors.append(f"有{metrics['expiring_policies']}份保单即将到期，续保机会明确")
        
        return {
            "dimension": "未来发展潜力",
            "score": min(score, 10),  # 最高10分
            "factors": factors,
            "interpretation": "高潜力客户有望带来更多的长期价值"
        }

    def _overall_judgment(
        self, 
        value_assessment: Dict, 
        risk_assessment: Dict, 
        loyalty_assessment: Dict, 
        potential_assessment: Dict
    ) -> tuple[float, str, str]:
        """综合判断"""
        # 加权评分 (价值:25%, 风险:25%, 忠诚度:25%, 潜力:25%)
        weights = [0.25, 0.25, 0.25, 0.25]
        scores = [
            value_assessment["score"],
            risk_assessment["score"], 
            loyalty_assessment["score"],
            potential_assessment["score"]
        ]
        
        composite_score = sum(w * s for w, s in zip(weights, scores))
        
        # 根据综合得分决定挽留建议
        if composite_score >= 8.0:
            recommendation = "重点挽留"
            confidence = "高"
        elif composite_score >= 6.0:
            recommendation = "建议挽留"
            confidence = "中"
        elif composite_score >= 4.0:
            recommendation = "选择性挽留"
            confidence = "中"
        else:
            recommendation = "不建议重点挽留"
            confidence = "高"
        
        return composite_score, recommendation, confidence

    def _generate_supporting_reasons(
        self,
        value_assessment: Dict,
        risk_assessment: Dict, 
        loyalty_assessment: Dict,
        potential_assessment: Dict
    ) -> Dict[str, list]:
        """生成支持理由"""
        reasons = {
            "positive_indicators": [],
            "negative_indicators": []
        }
        
        # 收集正面指标
        if value_assessment["score"] >= 7:
            reasons["positive_indicators"].append(value_assessment["factors"][0])
        if risk_assessment["score"] >= 7:
            reasons["positive_indicators"].append(risk_assessment["factors"][0])
        if loyalty_assessment["score"] >= 7:
            reasons["positive_indicators"].append(loyalty_assessment["factors"][0])
        if potential_assessment["score"] >= 7:
            reasons["positive_indicators"].append(potential_assessment["factors"][0])
        
        # 收集负面指标
        if value_assessment["score"] <= 4:
            reasons["negative_indicators"].append(value_assessment["factors"][0])
        if risk_assessment["score"] <= 4:
            reasons["negative_indicators"].append(risk_assessment["factors"][0])
        if loyalty_assessment["score"] <= 4:
            reasons["negative_indicators"].append(loyalty_assessment["factors"][0])
        if potential_assessment["score"] <= 4:
            reasons["negative_indicators"].append(potential_assessment["factors"][0])
        
        return reasons

    def _identify_risk_factors(self, metrics: Dict[str, Any]) -> list:
        """识别风险因素"""
        risks = []
        
        if metrics["claim_rate"] > 0.3:
            risks.append("理赔率过高")
        if metrics["claim_frequency"] > 3:
            risks.append("理赔频次过高")
        if metrics["annualized_premium"] < 1000:
            risks.append("价值贡献过低")
        
        return risks

    def _generate_action_suggestions(self, recommendation: str, metrics: Dict, customer_info: Dict) -> Dict[str, Any]:
        """生成行动建议"""
        suggestions = {
            "priority_actions": [],
            "follow_up_schedule": {},
            "roi_estimate": {}
        }
        
        if recommendation in ["重点挽留", "建议挽留"]:
            # 高优先级挽留措施
            if metrics["expiring_policies"] > 0:
                suggestions["priority_actions"].append({
                    "action": "紧急联系客户办理续保",
                    "urgency": "高",
                    "target": f"处理{metrics['expiring_policies']}份即将到期的保单"
                })
                
            # 提供优惠方案
            discount_estimate = min(int(metrics["annualized_premium"] * 0.05), 2000)  # 估算优惠金额
            suggestions["priority_actions"].append({
                "action": "提供续保优惠政策",
                "detail": f"建议给予5%左右折扣，约{discount_estimate}元优惠",
                "expected_outcome": "提高续保可能性"
            })
            
            # 增值服务
            suggestions["priority_actions"].append({
                "action": "提供VIP增值服务",
                "detail": "如免费体检、专属客服等",
                "expected_outcome": "增强客户粘性"
            })
            
            # 跟进时间表
            suggestions["follow_up_schedule"] = {
                "first_contact": "1-3天内",
                "follow_up_reminder": "一周后",
                "final_attempt": "两周内完成"
            }
            
            # ROI预估
            expected_retained_premium = metrics["annualized_premium"] * metrics["years_as_customer"] * 0.7  # 保守估计保留70%
            cost_of_retention = discount_estimate + 1000  # 优惠+服务成本
            estimated_roi = (expected_retained_premium - cost_of_retention) / cost_of_retention if cost_of_retention > 0 else 0
            
            suggestions["roi_estimate"] = {
                "expected_retained_value": expected_retained_premium,
                "cost_of_retention": cost_of_retention,
                "estimated_roi_ratio": f"{estimated_roi:.1f}:1"
            }
        else:
            # 对于不建议重点挽留的客户
            suggestions["priority_actions"].append({
                "action": "保持基本联系",
                "detail": "定期发送公司动态和优惠信息",
                "urgency": "低"
            })
            
            suggestions["follow_up_schedule"] = {
                "check_in_interval": "季度一次"
            }
        
        # 交叉销售机会
        if metrics["policy_diversity"] < 3:
            suggestions["priority_actions"].append({
                "action": "探索交叉销售机会",
                "detail": "推荐其他适合的产品线",
                "potential_value": "预计可增加20-30%保费"
            })
        
        return suggestions
