# Insurance Analysis MCP Tool

这是一个基于CoT（Chain of Thought）思维链的保险客户分析MCP工具，专门用于评估客户挽回价值和续保概率。

## 功能特性

- ✅ **CoT思维链推理**：采用五步思维链进行客户价值评估
- ✅ **多维度分析**：从价值贡献、风险水平、客户忠诚度、未来发展潜力四个维度综合评估
- ✅ **智能决策建议**：提供明确的挽留建议和可执行的行动方案
- ✅ **ROI预估**：对挽留措施的成本效益进行量化评估

## 安装

```bash
uv pip install -e .
```

## 使用方式

### 1. 作为 MCP Server 运行

```bash
# 方式1: 使用 uvx 直接运行
uvx insurance-analysis-mcp

# 方式2: 在项目中使用
uv run insurance-analysis-mcp
```

### 2. 在 Claude Desktop 中配置

编辑 `claude_desktop_config.json`：

```json
{
  "mcpServers": {
    "insurance-analysis": {
      "command": "uvx",
      "args": ["insurance-analysis-mcp"]
    }
  }
}
```

## MCP 工具列表

| 工具名 | 说明 |
|--------|------|
| `analyze_customer_retention_value` | 分析客户挽回价值和续保概率 |
| `get_analysis_framework_info` | 获取分析框架信息 |

### analyze_customer_retention_value 参数

- `customer_data`: 客户基本信息对象
  - `customer_id`: 客户ID
  - `name`: 客户姓名
  - `level`: 客户等级 (VIP, 普通, 潜力)
  - `total_premium`: 累计保费
  - `registration_date`: 注册日期
- `policy_data`: 保单信息列表 (可选)
- `claim_data`: 理赔记录列表 (可选)

## CoT 思维链分析流程

1. **需求理解**：明确分析目标和关键指标
2. **数据收集与整理**：获取并计算关键业务指标
3. **多维度分析**：
   - 价值贡献评估
   - 风险水平评估
   - 客户忠诚度评估
   - 未来发展潜力评估
4. **综合判断**：基于加权评分给出总体评价
5. **行动建议**：提供具体的优先行动项和ROI预估

## 开发

```bash
# 安装开发依赖
uv pip install -e ".[dev]"

# 运行测试
pytest
```

## 许可证

MIT
