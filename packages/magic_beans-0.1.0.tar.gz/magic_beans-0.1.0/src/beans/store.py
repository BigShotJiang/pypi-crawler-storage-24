# Python imports
import sqlite3

# Internal imports
from beans.models import Bean

def columns(cursor: sqlite3.Cursor) -> list[str]:
    return [desc[0] for desc in cursor.description]


def row(cols: list[str], values: tuple) -> dict:
    return dict(zip(cols, values))


SCHEMA = """
PRAGMA journal_mode=WAL;
PRAGMA foreign_keys=ON;

CREATE TABLE IF NOT EXISTS beans (
    id TEXT PRIMARY KEY,
    title TEXT NOT NULL,
    type TEXT NOT NULL DEFAULT 'task',
    status TEXT NOT NULL DEFAULT 'open',
    priority INTEGER NOT NULL DEFAULT 2,
    body TEXT NOT NULL DEFAULT '',
    parent_id TEXT,
    assignee TEXT,
    created_by TEXT,
    ref_id TEXT,
    created_at TEXT NOT NULL
);
"""


class BeanStore:
    def __init__(self, conn: sqlite3.Connection):
        self.conn = conn
        self.init_db(conn)

    @staticmethod
    def init_db(conn: sqlite3.Connection, schema: str = SCHEMA):
        conn.executescript(schema)

    @classmethod
    def from_path(cls, db_path: str) -> BeanStore:
        return cls(sqlite3.connect(db_path))

    def close(self):
        self.conn.close()

    def __enter__(self):
        return self

    def __exit__(self, *args):
        self.close()

    def create_bean(self, bean: Bean) -> Bean:
        self.conn.execute(
            """INSERT INTO beans
            (id, title, type, status, priority, body, parent_id, assignee, created_by, ref_id, created_at)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
            (
                bean.id,
                bean.title,
                bean.type,
                bean.status,
                bean.priority,
                bean.body,
                bean.parent_id,
                bean.assignee,
                bean.created_by,
                bean.ref_id,
                bean.created_at.isoformat(),
            ),
        )
        self.conn.commit()
        return bean

    def list_beans(self) -> list[Bean]:
        cursor = self.conn.execute("SELECT * FROM beans")
        cols = columns(cursor)
        return [Bean(**row(cols, values)) for values in cursor.fetchall()]
