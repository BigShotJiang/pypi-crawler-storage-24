# SPDX-License-Identifier: MIT
"""JWT validation using JWKS with full cryptographic signature verification."""

from __future__ import annotations

import logging
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional

import jwt
from jwt import PyJWK

from fenix_mcp.infrastructure.auth.jwks_client import JWKSClient


class JWTValidationError(Exception):
    """Raised when JWT validation fails."""


@dataclass
class JWTClaims:
    """Parsed and validated JWT claims."""

    sub: str
    tenant_id: Optional[str] = None
    team_id: Optional[str] = None
    email: Optional[str] = None
    aud: Optional[str] = None
    exp: Optional[int] = None
    iat: Optional[int] = None
    iss: Optional[str] = None
    raw: Dict[str, Any] = field(default_factory=dict)


@dataclass
class JWTValidator:
    """Validates JWTs using JWKS with cryptographic signature verification.

    Uses PyJWT to perform full RS256/ES256 signature validation against
    keys fetched from the Authorization Server's JWKS endpoint.
    """

    jwks_client: JWKSClient
    expected_audience: str = "fenix-mcp"
    # Supabase tokens use "authenticated" as audience by default.
    # Accept both the expected audience and common Supabase audiences.
    allowed_audiences: List[str] = field(default_factory=lambda: [])
    algorithms: List[str] = field(default_factory=lambda: ["RS256", "ES256"])
    _logger: logging.Logger = field(init=False, repr=False)

    def __post_init__(self) -> None:
        object.__setattr__(self, "_logger", logging.getLogger("fenix_mcp.auth.jwt"))
        if not self.allowed_audiences:
            self.allowed_audiences = [self.expected_audience, "authenticated"]

    def validate(self, token: str) -> JWTClaims:
        """Validate a JWT token with full signature verification.

        Raises JWTValidationError if validation fails.
        """
        try:
            # Decode header without verification to get kid
            unverified_header = jwt.get_unverified_header(token)
            kid = unverified_header.get("kid")
            alg = unverified_header.get("alg", "RS256")

            if alg not in self.algorithms:
                raise JWTValidationError(f"Unsupported algorithm: {alg}")

            # Get signing key from JWKS
            signing_key = self._get_signing_key(kid, alg)

            # Full cryptographic verification via PyJWT
            payload = jwt.decode(
                token,
                key=signing_key,
                algorithms=self.algorithms,
                audience=self.allowed_audiences,
                options={
                    "require": ["exp", "sub"],
                    "verify_exp": True,
                    "verify_aud": True,
                    "verify_iss": False,  # Issuer varies per Supabase project
                },
            )

            # Extract tenant and team from claims
            # Supabase puts custom claims in app_metadata
            app_metadata = payload.get("app_metadata", {})

            tenant_id = app_metadata.get("tenant_id") or payload.get("tenant_id")
            team_id = app_metadata.get("team_id") or payload.get("team_id")

            aud = payload.get("aud")

            return JWTClaims(
                sub=payload.get("sub", ""),
                tenant_id=tenant_id,
                team_id=team_id,
                email=payload.get("email"),
                aud=aud if isinstance(aud, str) else (aud[0] if aud else None),
                exp=payload.get("exp"),
                iat=payload.get("iat"),
                iss=payload.get("iss"),
                raw=payload,
            )

        except jwt.ExpiredSignatureError:
            raise JWTValidationError("Token has expired")
        except jwt.InvalidAudienceError:
            raise JWTValidationError(
                f"Invalid audience. Expected one of: {self.allowed_audiences}"
            )
        except jwt.InvalidSignatureError:
            raise JWTValidationError("Invalid token signature")
        except jwt.DecodeError as exc:
            raise JWTValidationError(f"Token decode failed: {exc}")
        except JWTValidationError:
            raise
        except Exception as exc:
            raise JWTValidationError(f"JWT validation failed: {exc}") from exc

    def _get_signing_key(self, kid: Optional[str], alg: str) -> Any:
        """Get the signing key from JWKS for signature verification."""
        if kid:
            key_data = self.jwks_client.get_signing_key_with_refresh(kid)
            if key_data is None:
                raise JWTValidationError(f"Unknown signing key: {kid}")
            return PyJWK(key_data).key

        # No kid — try first key matching the algorithm
        jwks = self.jwks_client.get_jwks()
        for key_data in jwks.get("keys", []):
            if key_data.get("alg") == alg or key_data.get("use") == "sig":
                return PyJWK(key_data).key

        raise JWTValidationError("No suitable signing key found in JWKS")
