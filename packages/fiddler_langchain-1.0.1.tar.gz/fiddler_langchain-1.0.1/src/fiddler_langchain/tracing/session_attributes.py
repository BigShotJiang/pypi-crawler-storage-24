"""Session-level attribute helpers for Fiddler LangChain instrumentation."""

# add_session_attributes has no LangChain dependency — the canonical
# implementation lives in fiddler_otel. Re-exported here for backward
# compatibility so existing imports from this module continue to work.
from fiddler_otel import add_session_attributes

__all__ = ['add_session_attributes']
