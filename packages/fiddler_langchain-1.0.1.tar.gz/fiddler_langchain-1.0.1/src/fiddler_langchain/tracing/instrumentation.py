"""LangChain V1 auto-instrumentation for Fiddler."""

from __future__ import annotations

from collections.abc import Callable, Collection
from typing import Any

from opentelemetry.instrumentation.instrumentor import (  # type: ignore[attr-defined]
    BaseInstrumentor,
)
from wrapt import wrap_function_wrapper

from fiddler_langchain.tracing.middleware import FiddlerAgentMiddleware
from fiddler_otel.client import FiddlerClient


class FiddlerLangChainInstrumentor(BaseInstrumentor):
    """Auto-instrumentor for LangChain V1 agents.

    Monkey-patches ``langchain.agents.create_agent`` so that every agent
    created after :meth:`instrument` is called receives a
    :class:`FiddlerAgentMiddleware` automatically.  Callers no longer need to
    pass ``middleware=[FiddlerAgentMiddleware(...)]`` to each ``create_agent``
    call.

    When a call to ``create_agent`` includes a ``name`` argument (e.g.
    ``name='flight_assistant'``), that name is used for the agent in traces.
    Otherwise, no agent name is set (empty string), so the agent is not labeled
    in the UI. If a call to ``create_agent`` already includes a
    :class:`FiddlerAgentMiddleware` instance in its ``middleware`` list, the
    instrumentor skips injection for that call so existing manual
    configurations are preserved.

    Note: Instrumentation persists for the lifetime of the application unless
    explicitly removed by calling `uninstrument()`. Calling `instrument()` multiple
    times is safe — it will not create duplicate middleware.

    Usage::

        import langchain.agents

        from fiddler_otel import FiddlerClient
        from fiddler_langchain import FiddlerLangChainInstrumentor

        client = FiddlerClient(api_key="...", application_id="...", url="...")

        instrumentor = FiddlerLangChainInstrumentor(client=client)
        instrumentor.instrument()

        # Use the module attribute (not a `from … import` alias) so the call goes
        # through the patched version at run-time:
        agent = langchain.agents.create_agent(model=..., tools=[...])
        agent.invoke({"messages": [...]})

        # Remove instrumentation when done:
        instrumentor.uninstrument()

    Note: ``instrument()`` patches the ``langchain.agents`` module attribute.
    If you prefer ``from langchain.agents import create_agent``, call
    ``instrument()`` *before* that import so the local name is bound to the
    patched wrapper.

    Attributes:
        _client (FiddlerClient): The FiddlerClient instance used for configuration.
        _original_create_agent (Callable | None): The original ``create_agent`` function,
            saved before patching so it can be restored on uninstrumentation.
    """

    def __init__(self, client: FiddlerClient):
        """Initializes the FiddlerLangChainInstrumentor.

        Args:
            client (FiddlerClient): The `FiddlerClient` instance. **Required**.

        Raises:
            RuntimeError: If the FiddlerClient tracer cannot be initialized.
        """
        super().__init__()
        self._client = client
        self._original_create_agent: Callable[..., Any] | None = None

    def instrument(self, **kwargs: Any):
        """Enable automatic instrumentation of LangChain V1 agents.

        Activates the instrumentor by patching ``langchain.agents.create_agent``
        to automatically inject :class:`FiddlerAgentMiddleware` into all agent
        instances created afterwards.

        This method is idempotent — calling it multiple times has the same effect
        as calling it once.  After activation, all newly created agents will
        automatically include Fiddler's middleware.

        Args:
            **kwargs: Additional instrumentation configuration (currently unused).

        Example:
            .. code-block:: python

                import langchain.agents

                from fiddler_otel import FiddlerClient
                from fiddler_langchain import FiddlerLangChainInstrumentor

                client = FiddlerClient(api_key="...", application_id="...", url="...")
                instrumentor = FiddlerLangChainInstrumentor(client=client)
                instrumentor.instrument()

                # Use module attribute so the patched version is called:
                agent = langchain.agents.create_agent(model=model, tools=[...])

                # Check if instrumentation is active
                if instrumentor.is_instrumented_by_opentelemetry:
                    print("Instrumentation is active")
        """
        return super().instrument(**kwargs)

    def uninstrument(self, **kwargs: Any):
        """Disable automatic instrumentation and restore original behavior.

        Deactivates the instrumentor by restoring the original
        ``langchain.agents.create_agent`` function.  Agents created after calling
        this method will no longer have :class:`FiddlerAgentMiddleware`
        automatically injected.

        Note: This does not affect agents that were already created while
        instrumentation was active — those will retain their middleware.

        Args:
            **kwargs: Additional uninstrumentation configuration (currently unused).

        Example:
            .. code-block:: python

                instrumentor = FiddlerLangChainInstrumentor(client=client)
                instrumentor.instrument()

                # Create some agents (automatically instrumented)
                agent1 = create_agent(model=model, tools=[...])

                # Deactivate instrumentation
                instrumentor.uninstrument()

                # New agents won't be instrumented
                agent2 = create_agent(model=model, tools=[...])

                # agent1 still has the middleware, agent2 does not
        """
        return super().uninstrument(**kwargs)

    def instrumentation_dependencies(self) -> Collection[str]:
        """Returns the package dependencies required for this instrumentor.

        Returns:
            Collection[str]: A collection of package dependency strings.
        """
        return ('langchain >= 1.0.0',)

    def _instrument(self, **kwargs: Any) -> None:
        """Instruments LangChain V1 by monkey-patching ``langchain.agents.create_agent``.

        This method injects a :class:`FiddlerAgentMiddleware` into every subsequent
        ``create_agent`` call.

        Raises:
            ValueError: If the tracer is not initialized in the FiddlerClient.
        """
        # Lazy import so the package can be imported when langchain is not installed.
        import langchain.agents

        tracer = self._client.get_tracer()
        if tracer is None:
            raise ValueError('Context tracer is not initialized')

        self._original_create_agent = langchain.agents.create_agent
        wrap_function_wrapper(
            module='langchain.agents',
            name='create_agent',
            wrapper=_CreateAgentWrapper(self._client, self),
        )

    def _uninstrument(self, **kwargs: Any) -> None:
        """Removes the instrumentation from LangChain V1.

        This is done by restoring the original ``create_agent`` function that was
        saved before patching.
        """
        # Lazy import for consistency with _instrument (optional langchain dependency).
        import langchain.agents

        if self._original_create_agent is not None:
            langchain.agents.create_agent = self._original_create_agent
            self._original_create_agent = None


class _CreateAgentWrapper:
    """``wrapt`` wrapper that injects :class:`FiddlerAgentMiddleware` into ``create_agent``."""

    __slots__ = ('_client', '_instrumentor')

    def __init__(self, client: FiddlerClient, instrumentor: FiddlerLangChainInstrumentor):
        """Initializes the wrapper.

        Args:
            client (FiddlerClient): The Fiddler client used to create the middleware.
        instrumentor (FiddlerLangChainInstrumentor): The parent instrumentor (unused
            when ``name`` is not passed; agent name is then empty).
        """
        self._client = client
        self._instrumentor = instrumentor

    def __call__(
        self,
        wrapped: Callable[..., Any],
        instance: Any,
        args: Any,
        kwargs: Any,
    ) -> Any:
        """Calls the original ``create_agent`` with a :class:`FiddlerAgentMiddleware` injected.

        If a :class:`FiddlerAgentMiddleware` is already present in the ``middleware``
        list, injection is skipped so manually configured instances are preserved.
        When ``create_agent`` is called with a ``name`` argument, that name is used
        for the agent in traces; otherwise no agent name is set (empty string).
        """
        middleware: list[Any] = list(kwargs.get('middleware') or [])

        if not any(isinstance(m, FiddlerAgentMiddleware) for m in middleware):
            name_arg = kwargs.get('name')
            if isinstance(name_arg, str) and name_arg.strip():
                agent_name = name_arg.strip()
            else:
                agent_name = ''
            middleware.append(FiddlerAgentMiddleware(client=self._client, agent_name=agent_name))
            kwargs['middleware'] = middleware

        return wrapped(*args, **kwargs)
