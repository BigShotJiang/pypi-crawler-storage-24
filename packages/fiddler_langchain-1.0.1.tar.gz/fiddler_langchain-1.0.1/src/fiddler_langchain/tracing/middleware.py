"""LangChain V1 middleware for Fiddler instrumentation."""

from __future__ import annotations

import asyncio
import json
import logging
import threading
from collections.abc import Callable
from typing import Any

from opentelemetry import context, trace

from fiddler_otel.attributes import (
    _CONVERSATION_ID,
    FIDDLER_METADATA_KEY,
    FIDDLER_USER_SPAN_ATTRIBUTE_TEMPLATE,
    FiddlerSpanAttributes,
    SpanType,
)
from fiddler_otel.client import FiddlerClient
from fiddler_otel.utils import is_fiddler_span

try:
    from langchain.agents.middleware import AgentMiddleware, AgentState, ModelRequest, ModelResponse
    from langchain.tools.tool_node import ToolCallRequest
    from langchain_core.messages import AIMessage, HumanMessage, ToolMessage
    from langchain_core.utils.function_calling import convert_to_openai_tool
except ImportError as exc:
    raise ImportError(
        'fiddler-langchain requires langchain >= 1.0.0. '
        'Install it with: pip install "langchain>=1.0.0"'
    ) from exc

logger = logging.getLogger(__name__)


def _get_model_name(request: ModelRequest) -> str:
    """Extract the model name from the request.

    Parameters
    ----------
    request : ModelRequest
        The LangChain model request object.

    Returns
    -------
    str
        The model name, or ``'llm'`` if not available.

    """
    return getattr(request.model, 'model_name', None) or 'llm'


def _get_model_provider(request: ModelRequest) -> str:
    """Extract the model provider from the request.

    Parameters
    ----------
    request : ModelRequest
        The LangChain model request object.

    Returns
    -------
    str
        The model provider string (e.g. ``'openai-chat'``), or ``''`` if not available.

    """
    return getattr(request.model, '_llm_type', '') or ''


def _get_llm_context(request: ModelRequest) -> str:
    """Extract the llm_context from the model's metadata if set via set_llm_context().

    Parameters
    ----------
    request : ModelRequest
        The LangChain model request object.

    Returns
    -------
    str
        The llm_context string, or ``''`` if not set.

    """
    metadata = getattr(request.model, 'metadata', None) or {}
    fiddler_attrs = metadata.get('_fiddler_attributes', {})
    return fiddler_attrs.get(FiddlerSpanAttributes.LLM_CONTEXT, '')


def _extract_system_content(request: ModelRequest) -> str:
    """Extract the system prompt content from the request.

    Parameters
    ----------
    request : ModelRequest
        The LangChain model request object.

    Returns
    -------
    str
        The system prompt as a plain string, or ``''`` if not present.

    """
    if request.system_message is None:
        return ''

    content = getattr(request.system_message, 'content', '') or ''
    if isinstance(content, list):
        content = ' '.join(
            block.get('text', '') if isinstance(block, dict) else str(block) for block in content
        )
    return content


def _build_otel_input_message(msg: Any) -> dict[str, Any]:
    """Convert a single LangChain message to OpenTelemetry input format.

    Parameters
    ----------
    msg : Any
        A LangChain message object (``HumanMessage``, ``AIMessage``, ``ToolMessage``, etc.).

    Returns
    -------
    dict[str, Any]
        Message dict in OpenTelemetry parts-based format.

    """
    role = getattr(msg, 'type', 'unknown')
    role_mapped = {'ai': 'assistant', 'human': 'user'}.get(role, role)
    content = msg.content if isinstance(msg.content, str) else json.dumps(msg.content)

    if isinstance(msg, ToolMessage):
        # Use tool_call_response type to match the old callback handler format,
        # preserving the tool_call_id for correlation with the assistant's tool_call.
        tool_call_id = getattr(msg, 'tool_call_id', '')
        return {
            'role': 'tool',
            'parts': [{'type': 'tool_call_response', 'response': content, 'id': tool_call_id}],
        }

    if isinstance(msg, AIMessage):
        # For assistant messages that contain tool calls, emit tool_call parts
        # (no leading text part when content is empty).
        ai_tool_calls = getattr(msg, 'tool_calls', None)
        ai_content = content.strip()
        parts: list[dict[str, Any]] = []
        if ai_content:
            parts.append({'type': 'text', 'content': ai_content})
        if ai_tool_calls:
            for tc in ai_tool_calls:
                parts.append(
                    {
                        'type': 'tool_call',
                        'name': tc.get('name', ''),
                        'id': tc.get('id', ''),
                        'arguments': tc.get('args', {}),
                    }
                )
        if not parts:
            parts.append({'type': 'text', 'content': ''})
        msg_dict: dict[str, Any] = {'role': 'assistant', 'parts': parts}
        ai_finish = getattr(msg, 'response_metadata', {}).get('finish_reason', '')
        if ai_finish:
            msg_dict['finish_reason'] = ai_finish
        return msg_dict

    return {'role': role_mapped, 'parts': [{'type': 'text', 'content': content}]}


def _set_llm_input_attributes(
    span: trace.Span,
    request: ModelRequest,
    agent_name: str,
) -> None:
    """Set LLM input attributes on the span from a ModelRequest.

    Parameters
    ----------
    span : trace.Span
        The OpenTelemetry span to set attributes on.
    request : ModelRequest
        The LangChain model request containing messages and model info.
    agent_name : str
        The name of the agent, set as a span attribute.

    """
    span.set_attribute(FiddlerSpanAttributes.TYPE, SpanType.LLM)
    span.set_attribute(FiddlerSpanAttributes.AGENT_NAME, agent_name)

    model_name = _get_model_name(request)
    if model_name:
        span.set_attribute(FiddlerSpanAttributes.LLM_REQUEST_MODEL, model_name)

    provider = _get_model_provider(request)
    if provider:
        span.set_attribute(FiddlerSpanAttributes.LLM_SYSTEM, provider)

    llm_context = _get_llm_context(request)
    if llm_context:
        span.set_attribute(FiddlerSpanAttributes.LLM_CONTEXT, llm_context)

    # Span-level attributes from model metadata (excluding LLM_CONTEXT which is handled above)
    metadata = getattr(request.model, 'metadata', None) or {}
    fiddler_attrs = metadata.get(FIDDLER_METADATA_KEY, {})
    for key, value in fiddler_attrs.items():
        if key == FiddlerSpanAttributes.LLM_CONTEXT:
            continue
        otel_key = FIDDLER_USER_SPAN_ATTRIBUTE_TEMPLATE.format(key=key)
        span.set_attribute(otel_key, value)

    system_content = _extract_system_content(request)
    span.set_attribute(FiddlerSpanAttributes.LLM_INPUT_SYSTEM, system_content)

    _set_input_messages(span, request, system_content)
    _set_tool_definitions(span, request)

    conv_id = _CONVERSATION_ID.get()
    if conv_id:
        span.set_attribute(FiddlerSpanAttributes.CONVERSATION_ID, conv_id)


def _set_input_messages(
    span: trace.Span,
    request: ModelRequest,
    system_content: str,
) -> None:
    """Build and set gen_ai_input_messages and llm_input_user on the span.

    Parameters
    ----------
    span : trace.Span
        The OpenTelemetry span to set attributes on.
    request : ModelRequest
        The LangChain model request containing the message history.
    system_content : str
        The already-extracted system prompt, prepended to the message list.

    """
    messages = list(request.messages)

    otel_messages: list[dict[str, Any]] = []

    # Prepend system message so gen_ai_input_messages mirrors the full prompt
    if system_content:
        otel_messages.append(
            {
                'role': 'system',
                'parts': [{'type': 'text', 'content': system_content}],
            }
        )

    for msg in messages:
        otel_messages.append(_build_otel_input_message(msg))

    human_msgs = [m for m in messages if isinstance(m, HumanMessage)]
    user_content = ''
    if human_msgs:
        last_human = human_msgs[-1]
        user_content = (
            last_human.content
            if isinstance(last_human.content, str)
            else json.dumps(last_human.content)
        )

    span.set_attribute(FiddlerSpanAttributes.LLM_INPUT_USER, user_content)
    if otel_messages:
        span.set_attribute(FiddlerSpanAttributes.GEN_AI_INPUT_MESSAGES, json.dumps(otel_messages))


def _set_tool_definitions(span: trace.Span, request: ModelRequest) -> None:
    """Extract and set tool definitions on the span from ModelRequest.tools.

    Parameters
    ----------
    span : trace.Span
        The OpenTelemetry span to set attributes on.
    request : ModelRequest
        The LangChain model request containing the tools list.

    """
    tools_schema: list[dict[str, Any]] = []
    for t in request.tools:
        try:
            schema = t if isinstance(t, dict) else convert_to_openai_tool(t)
            tools_schema.append(schema)
        except (TypeError, ValueError) as e:
            logger.warning('Failed to convert tool to OpenAI schema: %s', e)

    if tools_schema:
        span.set_attribute(FiddlerSpanAttributes.TOOL_DEFINITIONS, json.dumps(tools_schema))


def _build_otel_output_message(last_msg: Any) -> dict[str, Any]:
    """Convert the last LangChain response message to OpenTelemetry output format.

    Parameters
    ----------
    last_msg : Any
        The last message in the model response (typically an ``AIMessage``).

    Returns
    -------
    dict[str, Any]
        Output message dict in OpenTelemetry parts-based format.

    """
    role = getattr(last_msg, 'type', 'ai')
    role_mapped = {'ai': 'assistant', 'human': 'user'}.get(role, role)
    text_content = (
        last_msg.content if isinstance(last_msg.content, str) else json.dumps(last_msg.content)
    )
    tool_calls = getattr(last_msg, 'tool_calls', None)

    # When the model responds with tool calls and empty text content, omit the
    # redundant text part so the format matches the old callback handler output.
    parts: list[dict[str, Any]] = []
    if text_content.strip():
        parts.append({'type': 'text', 'content': text_content})
    if tool_calls:
        for tc in tool_calls:
            parts.append(
                {
                    'type': 'tool_call',
                    'name': tc.get('name', ''),
                    'id': tc.get('id', ''),
                    'arguments': tc.get('args', {}),
                }
            )
    if not parts:
        parts.append({'type': 'text', 'content': text_content})

    otel_output: dict[str, Any] = {'role': role_mapped, 'parts': parts}
    finish_reason = getattr(last_msg, 'response_metadata', {}).get('finish_reason', '')
    if finish_reason:
        otel_output['finish_reason'] = finish_reason
    return otel_output


def _set_llm_output_attributes(span: trace.Span, response: ModelResponse) -> None:
    """Set LLM output attributes on the span from a ModelResponse.

    Parameters
    ----------
    span : trace.Span
        The OpenTelemetry span to set attributes on.
    response : ModelResponse
        The LangChain model response containing the generated messages.

    """
    messages = response.result
    if not messages:
        return

    last_msg = messages[-1]

    # LLM_OUTPUT: plain text or tool call JSON
    tool_calls = getattr(last_msg, 'tool_calls', None)
    output = last_msg.content if isinstance(last_msg.content, str) else json.dumps(last_msg.content)
    if not output and tool_calls:
        output = json.dumps(tool_calls)
    span.set_attribute(FiddlerSpanAttributes.LLM_OUTPUT, output)

    # gen_ai_output_messages in OTel parts-based format
    otel_output = _build_otel_output_message(last_msg)
    span.set_attribute(FiddlerSpanAttributes.GEN_AI_OUTPUT_MESSAGES, json.dumps([otel_output]))

    # Token usage
    usage = getattr(last_msg, 'usage_metadata', None)
    if not usage:
        return
    input_tokens = usage.get('input_tokens')
    if input_tokens is not None:
        span.set_attribute(FiddlerSpanAttributes.LLM_TOKEN_COUNT_INPUT, input_tokens)
    output_tokens = usage.get('output_tokens')
    if output_tokens is not None:
        span.set_attribute(FiddlerSpanAttributes.LLM_TOKEN_COUNT_OUTPUT, output_tokens)
    total_tokens = usage.get('total_tokens')
    if total_tokens is not None:
        span.set_attribute(FiddlerSpanAttributes.LLM_TOKEN_COUNT_TOTAL, total_tokens)


def _set_tool_input_attributes(
    span: trace.Span,
    request: ToolCallRequest,
    agent_name: str,
) -> None:
    """Set tool input attributes on the span from a ToolCallRequest.

    Parameters
    ----------
    span : trace.Span
        The OpenTelemetry span to set attributes on.
    request : ToolCallRequest
        The LangChain tool call request.
    agent_name : str
        The name of the agent, set as a span attribute.

    """
    span.set_attribute(FiddlerSpanAttributes.TYPE, SpanType.TOOL)
    span.set_attribute(FiddlerSpanAttributes.AGENT_NAME, agent_name)

    tool_call = request.tool_call
    tool_name = tool_call.get('name', 'unknown')
    tool_args = tool_call.get('args', {})

    span.set_attribute(FiddlerSpanAttributes.TOOL_NAME, tool_name)
    span.set_attribute(FiddlerSpanAttributes.TOOL_INPUT, json.dumps(tool_args))

    # Span-level attributes from tool metadata, if available
    tool_obj = getattr(request, 'tool', None)
    if tool_obj is not None:
        metadata = getattr(tool_obj, 'metadata', None) or {}
        fiddler_attrs = metadata.get(FIDDLER_METADATA_KEY, {})
        for key, value in fiddler_attrs.items():
            otel_key = FIDDLER_USER_SPAN_ATTRIBUTE_TEMPLATE.format(key=key)
            span.set_attribute(otel_key, value)

    conv_id = _CONVERSATION_ID.get()
    if conv_id:
        span.set_attribute(FiddlerSpanAttributes.CONVERSATION_ID, conv_id)


def _set_tool_output_attributes(span: trace.Span, result: Any) -> None:
    """Set tool output attributes on the span.

    Parameters
    ----------
    span : trace.Span
        The OpenTelemetry span to set attributes on.
    result : Any
        The tool result object, expected to have a ``content`` attribute or be stringifiable.

    """
    content = getattr(result, 'content', None)
    if content is None:
        content = str(result)
    if not isinstance(content, str):
        content = json.dumps(content)
    span.set_attribute(FiddlerSpanAttributes.TOOL_OUTPUT, content)


class FiddlerAgentMiddleware(AgentMiddleware):
    """LangChain V1 middleware that instruments ``create_agent`` calls with Fiddler tracing.

    This middleware produces a clean, flat trace hierarchy for agents built with
    ``langchain.agents.create_agent``:

    - One root **Agent** span (opened in ``before_agent``, closed in ``after_agent``)
    - One **LLM** child span per model invocation (``wrap_model_call`` / ``awrap_model_call``)
    - One **Tool** child span per tool invocation (``wrap_tool_call`` / ``awrap_tool_call``)

    All spans are written to Fiddler's isolated OpenTelemetry context so they do not
    interfere with any global tracer that may be active in the application.

    Concurrent invocations (async) are fully isolated: Python's ``ContextVar`` ensures
    each ``agent.ainvoke()`` task tracks its own root span independently.

    Usage::

        from langchain.agents import create_agent
        from fiddler_otel import FiddlerClient
        from fiddler_langchain import FiddlerAgentMiddleware

        client = FiddlerClient(api_key="...", application_id="...", url="...")

        agent = create_agent(
            model="openai:gpt-4o-mini",
            tools=[...],
            middleware=[FiddlerAgentMiddleware(client=client, agent_name="my_agent")],
        )
        agent.invoke({"messages": [...]})

    Args:
        client: The :class:`~fiddler_otel.client.FiddlerClient` instance.
        agent_name: Label applied to the root Agent span. Defaults to ``"agent"``.
    """

    def __init__(self, client: FiddlerClient, agent_name: str = 'agent') -> None:
        super().__init__()
        self._client = client
        self._agent_name = agent_name
        # Maps invocation key -> root span.
        #
        # LangGraph wraps each node in copy_context().run(), which isolates ContextVar
        # writes so they are invisible to other nodes — even on the same thread.
        # Using an instance-level dict sidesteps that isolation entirely.
        #
        # Key strategy
        # ────────────
        # • async  path: id(asyncio.current_task()) — each concurrent ainvoke() call
        #   has its own Task, so concurrent invocations are fully isolated.
        # • sync   path: threading.get_ident() — works for the *calling* thread.
        #
        # Sync tool-worker fallback
        # ─────────────────────────
        # LangGraph submits tool nodes to a ThreadPoolExecutor, so wrap_tool_call
        # arrives on a worker thread whose id differs from the one that ran
        # before_agent.  When a lookup by the current key fails but exactly one
        # invocation is active (the typical sequential-sync case), _get_root_span
        # returns that single span safely.
        self._root_spans: dict[int, trace.Span] = {}
        self._lock = threading.Lock()

    def _invocation_key(self) -> int:
        """Return a key that uniquely identifies the current invocation context."""
        try:
            task = asyncio.current_task()
            if task is not None:
                return id(task)
        except RuntimeError:
            pass
        return threading.get_ident()

    def _get_root_span(self) -> trace.Span | None:
        """Return the root span for the current invocation, with sync-tool fallback."""
        key = self._invocation_key()
        with self._lock:
            span = self._root_spans.get(key)
            if span is None and len(self._root_spans) == 1:
                # Tool worker thread: exactly one invocation active — safe to use it.
                span = next(iter(self._root_spans.values()))
        return span

    def before_agent(self, state: AgentState, runtime: Any) -> dict[str, Any] | None:
        """Opens a root Agent span at the start of each agent invocation.

        If the current context already has a Fiddler span (e.g. we are being invoked
        as a sub-agent from a tool call), the new agent span is created as a child
        of that span so the full multi-agent flow appears in a single trace.
        """
        tracer = self._client.get_tracer()
        current_ctx = context.get_current()
        current_span = trace.get_current_span(current_ctx)

        ctx_to_use = self._client._context
        if is_fiddler_span(current_span):
            # Sub-agent: attach to existing trace (e.g. delegation tool span as parent)
            ctx_to_use = trace.set_span_in_context(current_span, self._client._context)

        # Top-level agent: starts a new trace using client context.
        # Sub-agent: starts a child span using context with the parent span.
        span = tracer.start_span(
            self._agent_name,
            context=ctx_to_use,
            kind=trace.SpanKind.CLIENT,
        )

        span.set_attribute(FiddlerSpanAttributes.TYPE, SpanType.AGENT)
        span.set_attribute(FiddlerSpanAttributes.AGENT_NAME, self._agent_name)

        trace_id = format(span.get_span_context().trace_id, '032x')
        span.set_attribute(FiddlerSpanAttributes.AGENT_ID, f'{trace_id}:{self._agent_name}')

        conv_id = _CONVERSATION_ID.get()
        if conv_id:
            span.set_attribute(FiddlerSpanAttributes.CONVERSATION_ID, conv_id)

        key = self._invocation_key()
        with self._lock:
            self._root_spans[key] = span
        return None

    def after_agent(self, state: AgentState, runtime: Any) -> dict[str, Any] | None:
        """Closes the root Agent span at the end of each agent invocation."""
        key = self._invocation_key()
        with self._lock:
            # Try exact key first; fall back to the sole active span (sync case).
            span = self._root_spans.pop(key, None)
            if span is None and len(self._root_spans) == 1:
                only_key = next(iter(self._root_spans))
                span = self._root_spans.pop(only_key)

        if span is None:
            logger.warning(
                'after_agent called but no root span found for agent %r', self._agent_name
            )
            return None

        span.set_status(trace.Status(trace.StatusCode.OK))
        span.end()
        return None

    def _start_child_span(self, name: str) -> trace.Span | None:
        """Start a child span under the current root span, or None if no root span."""
        root_span = self._get_root_span()

        if root_span is None:
            logger.warning('No root span active — skipping child span %r', name)
            return None
        tracer = self._client.get_tracer()
        parent_context = trace.set_span_in_context(root_span, self._client._context)
        return tracer.start_span(name, context=parent_context)

    def wrap_model_call(
        self,
        request: ModelRequest,
        handler: Callable[[ModelRequest], ModelResponse],
    ) -> ModelResponse:
        """Wraps a synchronous model call with an LLM span."""
        model_name = _get_model_name(request)
        span = self._start_child_span(model_name)

        if span is None:
            return handler(request)

        try:
            _set_llm_input_attributes(span, request, self._agent_name)
            response = handler(request)
            _set_llm_output_attributes(span, response)
            span.set_status(trace.Status(trace.StatusCode.OK))
            return response
        except Exception as exc:
            span.record_exception(exc)
            span.set_status(trace.Status(trace.StatusCode.ERROR, str(exc)))
            raise
        finally:
            span.end()

    async def awrap_model_call(
        self,
        request: ModelRequest,
        handler: Callable[[ModelRequest], Any],
    ) -> ModelResponse:
        """Wraps an asynchronous model call with an LLM span."""
        model_name = _get_model_name(request)
        span = self._start_child_span(model_name)

        if span is None:
            return await handler(request)

        try:
            _set_llm_input_attributes(span, request, self._agent_name)
            response = await handler(request)
            _set_llm_output_attributes(span, response)
            span.set_status(trace.Status(trace.StatusCode.OK))
            return response
        except Exception as exc:
            span.record_exception(exc)
            span.set_status(trace.Status(trace.StatusCode.ERROR, str(exc)))
            raise
        finally:
            span.end()

    def wrap_tool_call(
        self,
        request: ToolCallRequest,
        handler: Callable[[ToolCallRequest], Any],
    ) -> Any:
        """Wraps a synchronous tool call with a Tool span."""
        tool_name = request.tool_call.get('name', 'unknown')
        span = self._start_child_span(tool_name)

        if span is None:
            return handler(request)

        # Attach tool span to context so sub-agent invocations
        # see it as current and create their root span as a child → single trace
        token = context.attach(trace.set_span_in_context(span, context.get_current()))
        try:
            _set_tool_input_attributes(span, request, self._agent_name)
            result = handler(request)
            _set_tool_output_attributes(span, result)
            span.set_status(trace.Status(trace.StatusCode.OK))
            return result
        except Exception as exc:
            span.record_exception(exc)
            span.set_status(trace.Status(trace.StatusCode.ERROR, str(exc)))
            raise
        finally:
            context.detach(token)
            span.end()

    async def awrap_tool_call(
        self,
        request: ToolCallRequest,
        handler: Callable[[ToolCallRequest], Any],
    ) -> Any:
        """Wraps an asynchronous tool call with a Tool span."""
        tool_name = request.tool_call.get('name', 'unknown')
        span = self._start_child_span(tool_name)

        if span is None:
            return await handler(request)

        # Attach tool span to context so sub-agent invocations
        # see it as current and create their root span as a child → single trace
        token = context.attach(trace.set_span_in_context(span, context.get_current()))
        try:
            _set_tool_input_attributes(span, request, self._agent_name)
            result = await handler(request)
            _set_tool_output_attributes(span, result)
            span.set_status(trace.Status(trace.StatusCode.OK))
            return result
        except Exception as exc:
            span.record_exception(exc)
            span.set_status(trace.Status(trace.StatusCode.ERROR, str(exc)))
            raise
        finally:
            context.detach(token)
            span.end()
