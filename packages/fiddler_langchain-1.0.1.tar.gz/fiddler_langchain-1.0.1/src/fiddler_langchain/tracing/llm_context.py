"""LLM context helpers for Fiddler LangChain instrumentation."""

from __future__ import annotations

from langchain_core.language_models import BaseLanguageModel
from langchain_core.runnables import RunnableBinding

from fiddler_otel.attributes import FIDDLER_METADATA_KEY, FiddlerSpanAttributes


def set_llm_context(llm: BaseLanguageModel | RunnableBinding, context: str) -> None:
    """Set additional context on a language model for inclusion in LLM spans.

    The context is stored in the model's metadata and read by
    :class:`FiddlerAgentMiddleware` when creating LLM spans. Supports both
    plain model instances and :class:`~langchain_core.runnables.RunnableBinding`.

    :param llm: The language model (or binding) to attach context to.
    :param context: The context string to attach.
    :raises TypeError: If a RunnableBinding is provided but its bound object
        is not a BaseLanguageModel.

    Example::

        from langchain_openai import ChatOpenAI
        from fiddler_langchain import set_llm_context

        model = ChatOpenAI(model="gpt-4")
        set_llm_context(model, "User prefers concise responses")
    """
    if isinstance(llm, RunnableBinding):
        bound = getattr(llm, 'bound', None)
        if not isinstance(bound, BaseLanguageModel):
            raise TypeError(
                'llm must be a BaseLanguageModel or a RunnableBinding of a BaseLanguageModel'
            )
        target: BaseLanguageModel = bound
    else:
        target = llm

    if not hasattr(target, 'metadata'):
        target.metadata = {}
    if not isinstance(target.metadata, dict):
        target.metadata = {}
    metadata = target.metadata
    if FIDDLER_METADATA_KEY not in metadata:
        metadata[FIDDLER_METADATA_KEY] = {}
    metadata[FIDDLER_METADATA_KEY][FiddlerSpanAttributes.LLM_CONTEXT] = context
