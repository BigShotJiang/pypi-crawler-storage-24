"""Span-level attribute helpers for Fiddler LangChain instrumentation."""

from __future__ import annotations

from typing import Any

from langchain_core.language_models import BaseLanguageModel
from langchain_core.retrievers import BaseRetriever
from langchain_core.tools import BaseTool

from fiddler_otel.attributes import FIDDLER_METADATA_KEY

NodeT = BaseLanguageModel | BaseRetriever | BaseTool


def add_span_attributes(node: NodeT, **kwargs: Any) -> None:
    """Add custom span-level attributes to a LangChain component's metadata.

    Attributes are stored under the Fiddler metadata key on the component and
    read by :class:`FiddlerAgentMiddleware` when creating spans. Unlike session
    attributes, these are scoped to individual components and only applied to
    spans created for that component (e.g. a particular model or tool).
    """
    if not hasattr(node, 'metadata') or not isinstance(node.metadata, dict):
        node.metadata = {}

    metadata = node.metadata
    if FIDDLER_METADATA_KEY not in metadata:
        metadata[FIDDLER_METADATA_KEY] = {}

    fiddler_attrs = metadata[FIDDLER_METADATA_KEY]
    for key, value in kwargs.items():
        fiddler_attrs[key] = value
