"""Fiddler SDK for instrumenting LangChain V1 agents."""

from importlib.metadata import PackageNotFoundError, version

from fiddler_langchain.tracing.instrumentation import FiddlerLangChainInstrumentor
from fiddler_langchain.tracing.llm_context import set_llm_context
from fiddler_langchain.tracing.middleware import FiddlerAgentMiddleware
from fiddler_langchain.tracing.span_attributes import add_span_attributes

# Re-export set_conversation_id for convenience - it writes to the same ContextVar
# that FiddlerAgentMiddleware reads, so users only need to import from fiddler_langchain.
from fiddler_otel import add_session_attributes, set_conversation_id

try:
    __version__ = version('fiddler-langchain')
except PackageNotFoundError:
    __version__ = 'unknown'

__all__ = [
    'FiddlerAgentMiddleware',
    'FiddlerLangChainInstrumentor',
    '__version__',
    'add_session_attributes',
    'add_span_attributes',
    'set_conversation_id',
    'set_llm_context',
]
