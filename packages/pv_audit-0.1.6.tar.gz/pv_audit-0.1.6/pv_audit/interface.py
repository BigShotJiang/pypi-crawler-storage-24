from abc import ABC, abstractmethod

class BaseAdapter(ABC):
    @abstractmethod
    def run_inference(self, image_path):
        """User implements this to run their YOLO model"""
        pass