import pandas as pd

class AuditReporter:
    def __init__(self, raw_data):
        self.df = pd.DataFrame(raw_data)
    
    # 确保这个方法存在，这样 test 脚本就能拿到数据进行绘图了
    def get_dataframe(self):
        return self.df
    
    def save_csv(self, path: str):
        self.df.to_csv(path, index=False)
        print(f"CSV : {path}")

    def save_json(self, path: str):
        self.df.to_json(path, orient="records", indent=4)
        print(f"JSON : {path}")