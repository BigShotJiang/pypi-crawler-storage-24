import geoformat
from geoformat.conversion.coordinates_conversion import (
    format_coordinates,
    coordinates_to_coordinates_dict,
    coordinates_dict_to_coordinates
 )

from geoformat.index.geometry.grid import (
    point_to_g_id,
    g_id_to_point,
)

from geoformat.conversion.precision_tolerance_conversion import deduce_rounding_value_from_float
from geoformat.conversion.coordinates_conversion import validate_coordinates


def snap_vertex(vertex, size):
    """
    Snaps a single vertex to the nearest corner of a grid cell.

    For a given vertex, finds the closest grid point (corner) based on a grid
    of the specified cell size. If the vertex falls exactly on a grid point,
    that point is returned immediately.

    Parameters
    ----------
    vertex : tuple
        The coordinates of the vertex to snap, e.g. (x, y) or (x, y, z).
    size : float
        The cell size of the grid. Determines the spacing between grid points.

    Returns
    -------
    tuple
        The coordinates of the nearest grid corner.
    """
    new_vertex = None
    for g_id in point_to_g_id(point=vertex, mesh_size=size):
        min_vertex, new_vertex = None, None
        for position in ['SE', 'SW', 'NE', 'NW']:
            g_id_vertex = g_id_to_point(g_id=g_id, mesh_size=size, position=position)
            vertex_distance = geoformat.euclidean_distance(point_a=vertex, point_b=g_id_vertex)
            if vertex_distance == 0:
                new_vertex = g_id_vertex
                break
            else:
                if min_vertex is None:
                    min_vertex = vertex_distance
                    new_vertex = g_id_vertex
                else:
                    if vertex_distance < min_vertex:
                        min_vertex = vertex_distance
                        new_vertex = g_id_vertex
        break

    return new_vertex

def snap_coordinates(geometry_type, coordinates, size, delete_collinear_vertex=False):
    """
    Snaps all vertices of a geometry's coordinates to the nearest grid point.

    Converts coordinates to an indexed dict, snaps each vertex individually
    using `snap_vertex`, then rebuilds the coordinates structure. Duplicate
    consecutive coordinates and optionally collinear vertices are removed.
    The result is validated against the expected geometry type.

    Parameters
    ----------
    geometry_type : str or None
        The GeoJSON geometry type (e.g. "Point", "LineString", "Polygon",
        "MultiPolygon", etc.). Used to validate the snapped coordinates.
        Pass None to skip validation.
    coordinates : list
        The coordinates of the geometry in GeoJSON format.
    size : float
        The cell size of the grid used for snapping.
    delete_collinear_vertex : bool, optional
        If True, collinear vertices (vertices that lie on a straight line
        between their neighbours) are removed after snapping. Default is False.

    Returns
    -------
    list
        The snapped and cleaned coordinates in GeoJSON format.
    """
    coordinates_index_dict = coordinates_to_coordinates_dict(coordinates=coordinates)

    snaped_coordinates_index_dict = {}
    for key, vertex in coordinates_index_dict.items():
        new_vertex = snap_vertex(vertex=vertex, size=size)
        snaped_coordinates_index_dict[key] = new_vertex

    snaped_coordinates = coordinates_dict_to_coordinates(coordinates_dict=snaped_coordinates_index_dict)
    snaped_coordinate_formated = format_coordinates(
        coordinates_list_tuple=snaped_coordinates,
        delete_duplicate_following_coordinates=True,
        delete_collinear_vertex=delete_collinear_vertex,
        precision=deduce_rounding_value_from_float(float_value=size)
    )
    if geometry_type is not None:
        snaped_coordinate_formated_validated = validate_coordinates(coordinates=snaped_coordinate_formated, geometry_type=geometry_type)
    else:
        snaped_coordinate_formated_validated = snaped_coordinate_formated

    return snaped_coordinate_formated_validated


def snap_to_grid(geometry, size, delete_collinear_vertex=False):
    """
    Snaps all vertices of a GeoJSON geometry to the nearest point on a regular grid.

    This is the main entry point for grid snapping. The geometry is first
    normalised to a GeometryCollection so that all sub-geometries can be
    processed uniformly. Each sub-geometry's coordinates are snapped via
    `snap_coordinates`. Sub-geometries that become empty after snapping
    (e.g. a polygon whose ring degenerates) are removed from the output.
    If the input was not a GeometryCollection, the output is unwrapped back
    to a plain geometry.

    Parameters
    ----------
    geometry : dict
        A GeoJSON geometry object (any type: Point, LineString, Polygon,
        Multi* variants, or GeometryCollection).
    size : float
        The cell size of the grid. All vertex coordinates will be rounded
        to the nearest multiple of this value.
    delete_collinear_vertex : bool, optional
        If True, collinear vertices are removed after snapping. Default is False.

    Returns
    -------
    dict
        A GeoJSON geometry object of the same type as the input, with all
        vertices snapped to the grid. If the geometry becomes empty after
        snapping, a geometry of the same type with empty coordinates is returned.

    Examples
    --------
    >>> snap_to_grid({"type": "Point", "coordinates": [1.3, 2.7]}, size=1)
    {"type": "Point", "coordinates": [1.0, 3.0]}

    >>> snap_to_grid({"type": "LineString", "coordinates": [[0.1, 0.1], [1.9, 1.9]]}, size=1)
    {"type": "LineString", "coordinates": [[0.0, 0.0], [2.0, 2.0]]}
    """
    if geometry["type"] != "GeometryCollection":
        geometry_collection = geoformat.geometry_to_geometry_collection(geometry)
        input_is_geometry_collection = False
    else:
        geometry_collection = geometry
        input_is_geometry_collection = True

    output_geometry = {"type": "GeometryCollection", "geometries": [None] * len(geometry_collection["geometries"])}
    delete_geometry_idx = []
    for i_geom, geometry in enumerate(geometry_collection["geometries"]):
        coordinates = geometry["coordinates"]
        geometry_type = geometry["type"]
        coordinates_snap = snap_coordinates(
            geometry_type=geometry_type,
            coordinates=coordinates,
            size=size,
            delete_collinear_vertex=delete_collinear_vertex
        )
        if not coordinates_snap:
            delete_geometry_idx.append(i_geom)
        snapped_geometry = {"type": geometry["type"], "coordinates": coordinates_snap}
        output_geometry["geometries"][i_geom] = snapped_geometry

    # delete empty geometrie
    if delete_geometry_idx:
        for i_geom in reversed(delete_geometry_idx):
            del output_geometry["geometries"][i_geom]

    if input_is_geometry_collection is False:
        if output_geometry["geometries"]:
            output_geometry = output_geometry["geometries"][0]
        else:
            output_geometry = {"type": geometry["type"], "coordinates": []}

    return output_geometry
