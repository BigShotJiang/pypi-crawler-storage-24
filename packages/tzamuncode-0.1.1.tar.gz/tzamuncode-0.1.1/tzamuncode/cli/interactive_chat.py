"""
Interactive TUI Chat with dropdown menus like Claude Code
"""

from textual.app import App, ComposeResult
from textual.containers import Container, Vertical
from textual.widgets import Header, Footer, Static, Input, RichLog, OptionList
from textual.widgets.option_list import Option
from textual.binding import Binding
from rich.text import Text
from typing import Optional

from ..models.ollama import OllamaClient


class InteractiveTUIChat(App):
    """Interactive TUI Chat with dropdown menus"""
    
    CSS = """
    Screen {
        background: #1e1e1e;
    }
    
    #messages {
        height: 1fr;
        background: #1e1e1e;
        overflow-y: scroll;
        border: none;
        padding: 0 1;
    }
    
    #command-menu {
        display: none;
        layer: overlay;
        width: 50;
        height: auto;
        max-height: 15;
        background: #2d2d2d;
        border: solid #3a3a3a;
        offset: 2 2;
    }
    
    #shortcuts-menu {
        display: none;
        layer: overlay;
        width: 40;
        height: auto;
        max-height: 10;
        background: #2d2d2d;
        border: solid #3a3a3a;
        offset: 2 2;
    }
    
    #separator {
        dock: bottom;
        height: 1;
        background: #1e1e1e;
        color: #3a3a3a;
    }
    
    #input-container {
        dock: bottom;
        height: 1;
        background: #1e1e1e;
        padding: 0 1;
    }
    
    #input {
        width: 100%;
        background: #1e1e1e;
        border: none;
    }
    
    #shortcuts-hint {
        dock: bottom;
        height: 1;
        background: #1e1e1e;
        color: #666;
        text-align: right;
        padding: 0 1;
    }
    """
    
    BINDINGS = [
        Binding("ctrl+c", "quit", "Quit"),
        Binding("ctrl+l", "clear", "Clear"),
        Binding("escape", "hide_menus", "Close menu", show=False),
    ]
    
    def __init__(self, model: str = "qwen2.5:32b", **kwargs):
        super().__init__(**kwargs)
        self.model = model
        self.client = OllamaClient(model=model)
        self.conversation_history = []
        self.menu_visible = False
    
    def compose(self) -> ComposeResult:
        """Create child widgets"""
        # Message history (no header, clean terminal look)
        yield RichLog(id="messages", highlight=True, markup=True)
        
        # Command menu (hidden by default)
        command_options = [
            Option("/help - Show available commands", id="help"),
            Option("/models - List and switch models", id="models"),
            Option("/settings - Show settings", id="settings"),
            Option("/clear - Clear conversation", id="clear"),
            Option("/exit - Exit chat", id="exit"),
        ]
        yield OptionList(*command_options, id="command-menu")
        
        # Shortcuts menu (hidden by default)
        shortcut_options = [
            Option("Ctrl+C - Exit chat", id="ctrl_c"),
            Option("Ctrl+L - Clear screen", id="ctrl_l"),
            Option("/ - Show commands", id="slash"),
            Option("? - Show shortcuts", id="question"),
        ]
        yield OptionList(*shortcut_options, id="shortcuts-menu")
        
        # Separator line (like Claude Code)
        yield Static("─" * 200, id="separator")
        
        # Input container
        with Container(id="input-container"):
            yield Input(
                placeholder="",
                id="input"
            )
        
        # Shortcuts hint (like Claude Code)
        yield Static("? for shortcuts", id="shortcuts-hint")
    
    def on_mount(self) -> None:
        """Called when app starts"""
        messages = self.query_one("#messages", RichLog)
        
        # Minimal welcome like Claude Code
        messages.write("╔╦╗╔═╗╔═╗╔╦╗╦ ╦╔╗╔╔═╗╔═╗╔╦╗╔═╗")
        messages.write(" ║ ╔═╝╠═╣║║║║ ║║║║║  ║ ║ ║║╣ ")
        messages.write(" ╩ ╚═╝╩ ╩╩ ╩╚═╝╝╚╝╚═╝╚═╝═╩╝╚═╝")
        messages.write("")
        messages.write(f"[dim]AI Coding Assistant • Built in Saudi Arabia 🇸🇦[/dim]")
        messages.write(f"[dim]Model: {self.model} • Type '/' for commands[/dim]")
        messages.write("")
        messages.write("[green]Welcome![/green]")
        messages.write("")
        
        # Focus input
        self.query_one("#input", Input).focus()
    
    def on_input_changed(self, event: Input.Changed) -> None:
        """Handle input changes in real-time"""
        current_value = event.value
        
        # Show command menu when user types '/'
        if current_value == '/':
            self.show_command_menu()
            return
        
        # Show shortcuts menu when user types '?'
        if current_value == '?':
            self.show_shortcuts_menu()
            return
        
        # Hide menus if user continues typing
        if len(current_value) > 1 and self.menu_visible:
            self.hide_menus()
    
    def show_command_menu(self) -> None:
        """Show interactive command menu"""
        menu = self.query_one("#command-menu", OptionList)
        menu.styles.display = "block"
        menu.focus()
        self.menu_visible = True
    
    def show_shortcuts_menu(self) -> None:
        """Show interactive shortcuts menu"""
        menu = self.query_one("#shortcuts-menu", OptionList)
        menu.styles.display = "block"
        menu.focus()
        self.menu_visible = True
    
    def hide_menus(self) -> None:
        """Hide all menus"""
        self.query_one("#command-menu").styles.display = "none"
        self.query_one("#shortcuts-menu").styles.display = "none"
        self.menu_visible = False
        self.query_one("#input", Input).focus()
    
    def action_hide_menus(self) -> None:
        """Action to hide menus"""
        self.hide_menus()
        # Clear input
        self.query_one("#input", Input).value = ""
    
    def on_option_list_option_selected(self, event: OptionList.OptionSelected) -> None:
        """Handle menu option selection"""
        option_id = event.option_id
        
        # Hide menus
        self.hide_menus()
        
        # Clear input
        input_widget = self.query_one("#input", Input)
        input_widget.value = ""
        
        # Execute command
        if option_id == "help":
            self.show_help_in_messages()
        elif option_id == "models":
            self.show_models_in_messages()
        elif option_id == "settings":
            self.show_settings_in_messages()
        elif option_id == "clear":
            self.action_clear()
        elif option_id == "exit":
            self.exit()
    
    def show_help_in_messages(self) -> None:
        """Show help in message area"""
        messages = self.query_one("#messages", RichLog)
        messages.write("[bold cyan]Available Commands:[/bold cyan]")
        messages.write("  /help - Show available commands")
        messages.write("  /models - List and switch models")
        messages.write("  /settings - Show settings")
        messages.write("  /clear - Clear conversation")
        messages.write("  /exit - Exit chat")
        messages.write("")
    
    def show_models_in_messages(self) -> None:
        """Show models in message area"""
        messages = self.query_one("#messages", RichLog)
        messages.write("[bold cyan]Available Models:[/bold cyan]")
        try:
            models = self.client.list_models()
            for idx, model in enumerate(models, 1):
                status = "✓ Active" if model == self.model else ""
                messages.write(f"  {idx}. {model} {status}")
        except Exception as e:
            messages.write(f"[bold red]Error:[/bold red] {e}")
        messages.write("")
    
    def show_settings_in_messages(self) -> None:
        """Show settings in message area"""
        messages = self.query_one("#messages", RichLog)
        messages.write("[bold cyan]Current Settings:[/bold cyan]")
        messages.write(f"  Model: {self.model}")
        messages.write(f"  Streaming: Enabled")
        messages.write("")
    
    def on_input_submitted(self, event: Input.Submitted) -> None:
        """Handle input submission"""
        user_input = event.value.strip()
        
        if not user_input:
            return
        
        # Clear input
        event.input.value = ""
        
        # Handle exit
        if user_input.lower() in ['exit', 'quit']:
            self.exit()
            return
        
        # Send to AI
        self.send_message(user_input)
    
    def send_message(self, message: str) -> None:
        """Send message to AI"""
        messages = self.query_one("#messages", RichLog)
        
        # Show user message
        messages.write(f"[bold green]You[/bold green] › {message}")
        
        # Add to history
        self.conversation_history.append({"role": "user", "content": message})
        
        # Show thinking
        messages.write("[dim]TzamunCode is thinking...[/dim]")
        
        try:
            # Get response
            response = ""
            for chunk in self.client.chat_stream(self.conversation_history):
                response += chunk
            
            # Clear and re-show conversation
            messages.clear()
            for msg in self.conversation_history:
                if msg["role"] == "user":
                    messages.write(f"[bold green]You[/bold green] › {msg['content']}")
                elif msg["role"] == "assistant":
                    messages.write(f"[bold blue]TzamunCode[/bold blue] › {msg['content']}")
            
            # Show new response
            messages.write(f"[bold blue]TzamunCode[/bold blue] › {response}")
            messages.write("")
            
            # Add to history
            self.conversation_history.append({"role": "assistant", "content": response})
            
        except Exception as e:
            messages.write(f"[bold red]Error:[/bold red] {e}")
    
    def action_clear(self) -> None:
        """Clear conversation"""
        self.conversation_history = []
        messages = self.query_one("#messages", RichLog)
        messages.clear()
        messages.write("[bold green]Conversation cleared[/bold green]")
        messages.write("")
    
    def action_quit(self) -> None:
        """Quit app"""
        self.exit()


def run_interactive_chat(model: str = "qwen2.5:32b", system: Optional[str] = None):
    """Run interactive chat"""
    app = InteractiveTUIChat(model=model)
    app.run()
