"""
Enhanced interactive chat with beautiful UI and slash commands
"""

from rich.console import Console
from rich.panel import Panel
from rich.table import Table
from rich.prompt import Prompt
from rich.markdown import Markdown
from rich.layout import Layout
from rich.live import Live
from rich.text import Text
from typing import Optional, List, Dict
import sys

from ..models.ollama import OllamaClient

console = Console()


class EnhancedChat:
    """Enhanced chat interface with Claude Code-like UI"""
    
    ASCII_LOGO = """
╔╦╗╔═╗╔═╗╔╦╗╦ ╦╔╗╔╔═╗╔═╗╔╦╗╔═╗
 ║ ╔═╝╠═╣║║║║ ║║║║║  ║ ║ ║║╣ 
 ╩ ╚═╝╩ ╩╩ ╩╚═╝╝╚╝╚═╝╚═╝═╩╝╚═╝
    """
    
    SLASH_COMMANDS = {
        '/help': 'Show available commands',
        '/models': 'List and switch models',
        '/settings': 'Show settings',
        '/clear': 'Clear conversation history',
        '/save': 'Save conversation',
        '/load': 'Load conversation',
        '/exit': 'Exit chat',
        '/quit': 'Exit chat',
    }
    
    def __init__(self, model: str = "qwen2.5:32b", system: Optional[str] = None):
        self.model = model
        self.system = system
        self.client = OllamaClient(model=model)
        self.conversation_history = []
        self.available_models = []
        self.settings = {
            'temperature': 0.7,
            'streaming': True,
            'show_thinking': False,
        }
        
        # Load available models
        try:
            self.available_models = self.client.list_models()
        except:
            self.available_models = [model]
    
    
    def show_command_menu(self):
        """Show command menu when user types '/'"""
        console.print()
        
        # Professional command menu
        table = Table(
            title="[bold cyan]Available Commands[/bold cyan]",
            border_style="blue",
            show_header=True,
            header_style="bold white on blue",
            title_style="bold cyan"
        )
        table.add_column("Command", style="bold cyan", no_wrap=True, width=20)
        table.add_column("Description", style="white")
        
        for cmd, desc in self.SLASH_COMMANDS.items():
            table.add_row(cmd, desc)
        
        console.print(table)
        console.print()
    
    def show_help(self):
        """Show help with all commands"""
        self.show_command_menu()
    
    def show_models(self) -> Optional[str]:
        """Show model selector and return selected model"""
        console.print()
        
        # Professional model selection table
        table = Table(
            title="[bold cyan]Available Models[/bold cyan]",
            border_style="blue",
            show_header=True,
            header_style="bold white on blue"
        )
        table.add_column("#", style="dim", width=4)
        table.add_column("Model Name", style="cyan")
        table.add_column("Status", style="green", width=12)
        
        for idx, model_name in enumerate(self.available_models, 1):
            status = "✓ Active" if model_name == self.model else ""
            table.add_row(str(idx), model_name, status)
        
        console.print(table)
        console.print()
        
        choice = Prompt.ask(
            "[bold blue]Select model number[/bold blue] [dim](or Enter to cancel)[/dim]",
            default=""
        )
        
        if choice and choice.isdigit():
            idx = int(choice) - 1
            if 0 <= idx < len(self.available_models):
                new_model = self.available_models[idx]
                self.model = new_model
                self.client = OllamaClient(model=new_model)
                console.print(f"\n[bold green]✓[/bold green] Switched to [cyan]{new_model}[/cyan]\n")
                return new_model
        
        console.print("[dim]Cancelled[/dim]\n")
        return None
    
    def show_settings(self):
        """Show current settings"""
        from .. import __version__
        
        console.print()
        
        # Professional settings panel
        table = Table(
            title="[bold cyan]Current Settings[/bold cyan]",
            border_style="blue",
            show_header=True,
            header_style="bold white on blue"
        )
        table.add_column("Setting", style="bold cyan", width=20)
        table.add_column("Value", style="yellow")
        
        table.add_row("Version", __version__)
        table.add_row("Company", "Tzamun Arabia IT Co. 🇸🇦")
        table.add_row("Model", self.model)
        table.add_row("Available Models", str(len(self.available_models)))
        table.add_row("Temperature", str(self.settings['temperature']))
        table.add_row("Streaming", "✓ Enabled" if self.settings['streaming'] else "✗ Disabled")
        
        console.print(table)
        console.print()
    
    def handle_slash_command(self, command: str) -> bool:
        """
        Handle slash commands
        
        Returns:
            True if should continue chat, False if should exit
        """
        command = command.lower().strip()
        
        if command in ['/exit', '/quit']:
            return False
        
        elif command == '/help':
            self.show_help()
        
        elif command == '/models':
            self.show_models()
        
        elif command == '/settings':
            self.show_settings()
        
        elif command == '/clear':
            self.conversation_history = []
            self.show_header()
            console.print("[bold green]✓[/bold green] Conversation cleared\n")
        
        elif command == '/save':
            console.print("[dim]Save feature coming soon...[/dim]\n")
        
        elif command == '/load':
            console.print("[dim]Load feature coming soon...[/dim]\n")
        
        else:
            console.print(f"[bold red]Unknown command:[/bold red] {command}")
            console.print("[dim]Type '/help' to see available commands[/dim]\n")
        
        return True
    
    def format_user_message(self, message: str):
        """Format user message"""
        console.print(f"\n[bold green]You[/bold green] [dim]›[/dim] {message}")
    
    def format_ai_response(self, response: str):
        """Format AI response"""
        console.print(f"\n[bold blue]TzamunCode[/bold blue] [dim]›[/dim]")
        
        # Try to render as markdown if it looks like code
        if '```' in response or response.strip().startswith('#'):
            console.print(Markdown(response))
        else:
            console.print(response)
        
        console.print()
    
    def run(self):
        """Run the enhanced chat interface"""
        # Professional header with complete information
        from .. import __version__
        
        console.print()
        console.print("─" * console.width, style="dim")
        console.print()
        
        # ASCII Logo
        console.print("[bold cyan]╔╦╗╔═╗╔═╗╔╦╗╦ ╦╔╗╔╔═╗╔═╗╔╦╗╔═╗[/bold cyan]")
        console.print("[bold cyan] ║ ╔═╝╠═╣║║║║ ║║║║║  ║ ║ ║║╣[/bold cyan]")
        console.print("[bold cyan] ╩ ╚═╝╩ ╩╩ ╩╚═╝╝╚╝╚═╝╚═╝═╩╝╚═╝[/bold cyan]")
        
        console.print()
        
        # Professional info panel
        info_panel = Panel.fit(
            f"""[bold]AI Coding Assistant[/bold]
            
[cyan]Version:[/cyan] {__version__}
[cyan]Company:[/cyan] Tzamun Arabia IT Co. 🇸🇦
[cyan]Model:[/cyan] {self.model}
[cyan]Models Available:[/cyan] {len(self.available_models)}

[dim]Type '/help' for commands • Type '?' for shortcuts[/dim]""",
            border_style="blue",
            padding=(0, 2)
        )
        console.print(info_panel)
        console.print()
        console.print("─" * console.width, style="dim")
        console.print()
        
        # Add system message if provided
        if self.system:
            self.conversation_history.append({"role": "system", "content": self.system})
        
        while True:
            try:
                # Simple prompt
                console.print()
                user_input = Prompt.ask("[dim]›[/dim]", default="")
                
                if not user_input or not user_input.strip():
                    continue
                
                # Check for exit commands
                if user_input.lower() in ['exit', 'quit', 'q']:
                    console.print("\n[dim]Goodbye! 👋[/dim]\n")
                    break
                
                # Check if user just typed '/' - show command menu
                if user_input.strip() == '/':
                    self.show_command_menu()
                    continue
                
                # Check for slash commands
                if user_input.startswith('/'):
                    should_continue = self.handle_slash_command(user_input)
                    if not should_continue:
                        console.print("\n[dim]Goodbye! 👋[/dim]\n")
                        break
                    continue
                
                # Format and show user message
                self.format_user_message(user_input)
                
                # Add to conversation history
                self.conversation_history.append({"role": "user", "content": user_input})
                
                # Get AI response
                if self.settings['streaming']:
                    # Stream response
                    console.print(f"\n[bold blue]TzamunCode[/bold blue] [dim]›[/dim] ", end="")
                    
                    response = ""
                    for chunk in self.client.chat_stream(self.conversation_history):
                        response += chunk
                        console.print(chunk, end="")
                    
                    console.print("\n")
                else:
                    # Non-streaming response
                    with console.status("[bold blue]Thinking...", spinner="dots"):
                        response = self.client.chat(self.conversation_history)
                    
                    self.format_ai_response(response)
                
                # Add to conversation history
                self.conversation_history.append({"role": "assistant", "content": response})
                
            except KeyboardInterrupt:
                console.print("\n\n[dim]Interrupted. Type 'exit' to quit or continue chatting.[/dim]\n")
                continue
            
            except EOFError:
                console.print("\n[dim]Goodbye! 👋[/dim]\n")
                break
            
            except Exception as e:
                console.print(f"\n[bold red]Error:[/bold red] {e}\n")
                continue


def enhanced_chat_command(model: str, system: Optional[str] = None):
    """Run enhanced chat interface"""
    chat = EnhancedChat(model=model, system=system)
    chat.run()
