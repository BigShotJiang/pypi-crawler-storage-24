"""
Real-time chat with keystroke interception (Claude Code approach)
Uses raw terminal mode + ANSI cursor manipulation
"""

import sys
import tty
import termios
from typing import Optional, List
from rich.console import Console
from rich.panel import Panel
from rich.table import Table
from rich.live import Live
from rich.text import Text

from ..models.ollama import OllamaClient
from ..models.vllm_client import VLLMClient
from ..utils.file_ops import FileManager
from ..utils.project_scanner import ProjectScanner
from pathlib import Path
import subprocess
from rich.prompt import Confirm

console = Console()


class RealtimeChat:
    """Chat with real-time keystroke detection like Claude Code"""
    
    COMMANDS = {
        '/help': 'Show available commands',
        '/models': 'List and switch models',
        '/backend': 'Switch between vLLM/Ollama',
        '/settings': 'Show settings',
        '/files': 'List files in workspace',
        '/read': 'Read a file (e.g., /read app.py)',
        '/write': 'Write to a file (e.g., /write test.py)',
        '/project': 'Show project structure',
        '/history': 'Show conversation history',
        '/save': 'Save conversation to file',
        '/load': 'Load previous conversation',
        '/clear': 'Clear conversation',
        '/exit': 'Exit chat',
    }
    
    def __init__(self, model: str = "qwen2.5:32b", use_vllm: bool = False):
        self.model = model
        self.use_vllm = use_vllm
        
        # Initialize appropriate client
        if use_vllm:
            self.client = VLLMClient(model=model)
            self.backend = "vLLM"
        else:
            self.client = OllamaClient(model=model)
            self.backend = "Ollama"
        
        self.conversation_history = []
        self.current_input = ""
        self.show_menu = False
        self.selected_index = 0
        self.command_history = []  # Store previous commands
        self.history_index = -1  # Current position in history
        self.multi_line_mode = False  # Multi-line input mode
        self.multi_line_buffer = []  # Buffer for multi-line input
        
        # Code skills - file operations and project scanning
        self.file_manager = FileManager()
        self.project_scanner = ProjectScanner(Path.cwd())
        self.workspace = Path.cwd()
        
        # Load models
        try:
            self.available_models = self.client.list_models()
        except:
            self.available_models = [model]
        
        # Add system prompt for code skills
        self.system_prompt = """You are TzamunCode, an AI coding assistant with autonomous capabilities:

**File Operations:**
- You can read files when asked
- You can write/create files when asked (show the code first, then confirm)
- You can list files in directories
- You can analyze project structure

**Autonomous Command Execution:**
- You can suggest and execute terminal commands when needed
- To execute a command, use this format: [EXECUTE: command here]
- Example: "Let me check the files. [EXECUTE: ls -la]"
- User will confirm before execution
- You can see command output and continue helping

**Code Skills:**
- Explain code and concepts
- Generate code snippets
- Debug and fix issues
- Suggest improvements
- Answer coding questions

**Important:**
- When you need to run a command, use [EXECUTE: command] format
- Always explain what the command does before suggesting it
- Be proactive - suggest commands when they would help
- You can chain multiple commands if needed

Current workspace: {workspace}
""".format(workspace=str(self.workspace))
    
    def show_header(self):
        """Show professional header"""
        from .. import __version__
        from ..auth.auth_manager import AuthManager
        
        # Get user info
        auth = AuthManager()
        user_info = auth.get_user_info()
        
        console.print()
        console.print("─" * console.width, style="dim")
        console.print()
        console.print("[bold bright_cyan]████████╗███████╗ █████╗ ███╗   ███╗██╗   ██╗███╗   ██╗  ██████╗ ██████╗ ██████╗ ███████╗[/bold bright_cyan]")
        console.print("[bold bright_cyan]╚══██╔══╝╚══███╔╝██╔══██╗████╗ ████║██║   ██║████╗  ██║ ██╔════╝██╔═══██╗██╔══██╗██╔════╝[/bold bright_cyan]")
        console.print("[bold cyan]   ██║     ███╔╝ ███████║██╔████╔██║██║   ██║██╔██╗ ██║ ██║     ██║   ██║██║  ██║█████╗  [/bold cyan]")
        console.print("[bold cyan]   ██║    ███╔╝  ██╔══██║██║╚██╔╝██║██║   ██║██║╚██╗██║ ██║     ██║   ██║██║  ██║██╔══╝  [/bold cyan]")
        console.print("[bold blue]   ██║   ███████╗██║  ██║██║ ╚═╝ ██║╚██████╔╝██║ ╚████║ ╚██████╗╚██████╔╝██████╔╝███████╗[/bold blue]")
        console.print("[bold blue]   ╚═╝   ╚══════╝╚═╝  ╚═╝╚═╝     ╚═╝ ╚═════╝ ╚═╝  ╚═══╝  ╚═════╝ ╚═════╝ ╚═════╝ ╚══════╝[/bold blue]")
        console.print()
        console.print("[bold white]                      ╔════════════════════════════════════╗[/bold white]")
        console.print("[bold white]                      ║    [bright_cyan]A I[/bright_cyan]   [dim]•[/dim]   [cyan]A S S I S T A N T[/cyan]    ║[/bold white]")
        console.print("[bold white]                      ╚════════════════════════════════════╝[/bold white]")
        console.print()
        
        # Build info panel with user details
        info_text = f"""[bold]AI Coding Assistant[/bold]

[cyan]Version:[/cyan] {__version__}
[cyan]Company:[/cyan] Tzamun Arabia IT Co. 🇸🇦
[cyan]User:[/cyan] {user_info.get('username', 'Guest')} [green]✓[/green]
[cyan]Backend:[/cyan] {self.backend}
[cyan]Model:[/cyan] {self.model}
[cyan]Models Available:[/cyan] {len(self.available_models)}
[cyan]Workspace:[/cyan] [yellow]{self.workspace}[/yellow]

[dim]Type '/help' for commands • Type '?' for shortcuts[/dim]"""
        
        info_panel = Panel.fit(
            info_text,
            border_style="blue",
            padding=(0, 2)
        )
        console.print(info_panel)
        console.print()
        console.print("─" * console.width, style="dim")
        console.print()
    
    def render_menu(self, filter_text: str = ""):
        """Render command menu below cursor (Claude Code style)"""
        # Filter commands based on input
        filtered_commands = {}
        if filter_text:
            for cmd, desc in self.COMMANDS.items():
                if filter_text.lower() in cmd.lower():
                    filtered_commands[cmd] = desc
        else:
            filtered_commands = self.COMMANDS
        
        if not filtered_commands:
            return
        
        # Save cursor position
        sys.stdout.write('\x1B[s')
        sys.stdout.flush()
        
        # Move to next line
        console.print()
        
        # Render menu
        table = Table(
            title="[bold cyan]Available Commands[/bold cyan]",
            border_style="blue",
            show_header=False,
            expand=False,
            width=60
        )
        table.add_column("Command", style="bold cyan", width=15)
        table.add_column("Description", style="white", width=43)
        
        for idx, (cmd, desc) in enumerate(filtered_commands.items()):
            style = "bold green on blue" if idx == self.selected_index else ""
            table.add_row(cmd, desc, style=style)
        
        console.print(table)
        
        # Restore cursor position
        sys.stdout.write('\x1B[u')
        sys.stdout.flush()
    
    def clear_menu(self):
        """Clear the menu area"""
        # Save current position
        sys.stdout.write('\x1B[s')
        
        # Move down and clear multiple lines (enough for menu)
        for i in range(20):
            sys.stdout.write('\x1B[1B')  # Move down
            sys.stdout.write('\x1B[2K')  # Clear line
        
        # Restore position
        sys.stdout.write('\x1B[u')
        sys.stdout.flush()
    
    def get_char(self):
        """Get single character from terminal (raw mode)"""
        fd = sys.stdin.fileno()
        old_settings = termios.tcgetattr(fd)
        try:
            tty.setraw(fd)
            char = sys.stdin.read(1)
        finally:
            termios.tcsetattr(fd, termios.TCSADRAIN, old_settings)
        return char
    
    def read_input(self) -> Optional[str]:
        """Read input with real-time keystroke detection"""
        self.current_input = ""
        self.show_menu = False
        self.history_index = -1
        
        prompt = "\n[dim]›[/dim] " if not self.multi_line_mode else "[dim]…[/dim] "
        console.print(prompt, end="")
        
        while True:
            char = self.get_char()
            
            # Handle special keys
            if char == '\x03':  # Ctrl+C
                raise KeyboardInterrupt
            elif char == '\x04':  # Ctrl+D - Quick exit
                console.print("\n[dim]Goodbye! 👋[/dim]\n")
                raise KeyboardInterrupt
            elif char == '\x0c':  # Ctrl+L - Clear screen
                console.clear()
                self.show_header()
                console.print(prompt, end="")
                sys.stdout.write(self.current_input)
                sys.stdout.flush()
                continue
            elif char == '\x12':  # Ctrl+R - Regenerate (placeholder for now)
                continue
            elif char == '\x1b':  # Escape or arrow key
                next1 = self.get_char()
                if next1 == '[':
                    next2 = self.get_char()
                    if next2 == 'A':  # Up arrow
                        if self.show_menu:
                            self.selected_index = max(0, self.selected_index - 1)
                            self.clear_menu()
                            self.render_menu()
                        elif self.command_history and not self.show_menu:
                            # Navigate command history
                            if self.history_index < len(self.command_history) - 1:
                                self.history_index += 1
                                # Clear current input
                                sys.stdout.write('\b \b' * len(self.current_input))
                                sys.stdout.flush()
                                # Show history item
                                self.current_input = self.command_history[-(self.history_index + 1)]
                                sys.stdout.write(self.current_input)
                                sys.stdout.flush()
                    elif next2 == 'B':  # Down arrow
                        if self.show_menu:
                            self.selected_index = min(len(self.COMMANDS) - 1, self.selected_index + 1)
                            self.clear_menu()
                            self.render_menu()
                        elif self.history_index > -1:
                            # Navigate command history
                            self.history_index -= 1
                            # Clear current input
                            sys.stdout.write('\b \b' * len(self.current_input))
                            sys.stdout.flush()
                            if self.history_index >= 0:
                                self.current_input = self.command_history[-(self.history_index + 1)]
                            else:
                                self.current_input = ""
                            sys.stdout.write(self.current_input)
                            sys.stdout.flush()
                else:
                    # Escape key - hide menu
                    if self.show_menu:
                        self.clear_menu()
                        self.show_menu = False
                continue
            elif char == '\r' or char == '\n':  # Enter
                if self.show_menu:
                    # Select command from menu
                    selected_cmd = list(self.COMMANDS.keys())[self.selected_index]
                    self.clear_menu()
                    self.show_menu = False
                    console.print()
                    return selected_cmd
                else:
                    console.print()
                    # Add to command history if not empty
                    if self.current_input.strip() and not self.current_input.startswith('/'):
                        self.command_history.append(self.current_input)
                        # Keep history limited to 100 items
                        if len(self.command_history) > 100:
                            self.command_history.pop(0)
                    return self.current_input
            elif char == '\x7f':  # Backspace
                if self.current_input:
                    self.current_input = self.current_input[:-1]
                    sys.stdout.write('\b \b')
                    sys.stdout.flush()
                    
                    # Update menu filter or hide if input is cleared
                    if not self.current_input and self.show_menu:
                        self.clear_menu()
                        self.show_menu = False
                    elif self.show_menu and self.current_input.startswith('/'):
                        # Update filtered menu
                        filter_text = self.current_input[1:]
                        self.clear_menu()
                        self.render_menu(filter_text)
            else:
                # Regular character
                self.current_input += char
                sys.stdout.write(char)
                sys.stdout.flush()
                
                # Check for '?' shortcut trigger
                if char == '?' and len(self.current_input) == 1:
                    console.print()
                    self.show_help()
                    self.current_input = ""
                    console.print("\n[dim]›[/dim] ", end="")
                    sys.stdout.flush()
                    continue
                
                # Check for '/' trigger
                if char == '/' and len(self.current_input) == 1:
                    self.show_menu = True
                    self.selected_index = 0
                    self.render_menu()
                elif self.show_menu and self.current_input.startswith('/'):
                    # Update filtered menu as user types
                    filter_text = self.current_input[1:]  # Remove '/' prefix
                    self.clear_menu()
                    self.render_menu(filter_text)
    
    def run(self):
        """Run the chat"""
        self.show_header()
        
        # Add system prompt
        self.conversation_history.append({
            "role": "system",
            "content": self.system_prompt
        })
        
        while True:
            try:
                user_input = self.read_input()
                
                if not user_input or not user_input.strip():
                    continue
                
                # Handle commands
                if user_input.lower() in ['exit', 'quit', '/exit']:
                    console.print("\n[dim]Goodbye! 👋[/dim]\n")
                    break
                
                if user_input == '/help':
                    self.show_help()
                    continue
                
                if user_input == '/models':
                    self.show_models()
                    continue
                
                if user_input == '/settings':
                    self.show_settings()
                    continue
                
                if user_input == '/clear':
                    console.clear()
                    self.show_header()
                    self.conversation_history = [{"role": "system", "content": self.system_prompt}]
                    continue
                
                if user_input == '/files':
                    self.show_files()
                    continue
                
                if user_input == '/project':
                    self.show_project_info()
                    continue
                
                if user_input.startswith('/read '):
                    file_path = user_input[6:].strip()
                    self.read_file(file_path)
                    continue
                
                if user_input.startswith('/write '):
                    file_path = user_input[7:].strip()
                    self.write_file(file_path)
                    continue
                
                if user_input == '/backend':
                    self.switch_backend()
                    continue
                
                if user_input == '/history':
                    self.show_conversation_history()
                    continue
                
                if user_input.startswith('/save'):
                    filename = user_input[5:].strip() or 'conversation.json'
                    self.save_conversation(filename)
                    continue
                
                if user_input.startswith('/load '):
                    filename = user_input[6:].strip()
                    self.load_conversation(filename)
                    continue
                
                if user_input == '?':
                    self.show_help()
                    continue
                
                if user_input.startswith('/run '):
                    command = user_input[5:].strip()
                    self.execute_command(command)
                    continue
                
                # Send to AI
                self.send_message(user_input)
                
            except KeyboardInterrupt:
                console.print("\n[dim]Goodbye! 👋[/dim]\n")
                break
            except Exception as e:
                console.print(f"\n[red]Error: {e}[/red]\n")
    
    def show_help(self):
        """Show help with all commands and shortcuts"""
        console.print()
        
        # Commands table
        table = Table(
            title="[bold cyan]Available Commands[/bold cyan]",
            border_style="blue",
            show_header=True,
            header_style="bold white on blue"
        )
        table.add_column("Command", style="bold cyan", width=20)
        table.add_column("Description", style="white")
        
        for cmd, desc in self.COMMANDS.items():
            table.add_row(cmd, desc)
        
        console.print(table)
        
        # Shortcuts table
        console.print()
        shortcuts_table = Table(
            title="[bold cyan]Keyboard Shortcuts[/bold cyan]",
            border_style="blue",
            show_header=True,
            header_style="bold white on blue"
        )
        shortcuts_table.add_column("Shortcut", style="bold yellow", width=15)
        shortcuts_table.add_column("Action", style="white")
        
        shortcuts_table.add_row("?", "Show this help")
        shortcuts_table.add_row("↑ / ↓", "Navigate command history")
        shortcuts_table.add_row("Ctrl+L", "Clear screen")
        shortcuts_table.add_row("Ctrl+D", "Quick exit")
        shortcuts_table.add_row("Ctrl+C", "Cancel/Exit")
        shortcuts_table.add_row("/", "Show command menu")
        
        console.print(shortcuts_table)
        console.print()
    
    def show_models(self):
        """Show and select models interactively"""
        selected_index = 0
        
        while True:
            # Clear screen and show header
            console.clear()
            self.show_header()
            
            # Render interactive model table
            console.print()
            table = Table(
                title="[bold cyan]Available Models[/bold cyan]",
                border_style="blue",
                show_header=True,
                header_style="bold white on blue"
            )
            table.add_column("#", style="dim", width=4)
            table.add_column("Model Name", style="cyan")
            table.add_column("Status", style="green", width=12)
            
            for idx, model_name in enumerate(self.available_models):
                status = "✓ Active" if model_name == self.model else ""
                style = "bold green on blue" if idx == selected_index else ""
                table.add_row(str(idx + 1), model_name, status, style=style)
            
            console.print(table)
            console.print("\n[dim]Use ↑↓ arrows to navigate, Enter to select, Esc to cancel[/dim]")
            
            # Get keystroke
            char = self.get_char()
            
            if char == '\x1b':  # Escape or arrow key
                next1 = self.get_char()
                if next1 == '[':
                    next2 = self.get_char()
                    if next2 == 'A':  # Up arrow
                        selected_index = max(0, selected_index - 1)
                    elif next2 == 'B':  # Down arrow
                        selected_index = min(len(self.available_models) - 1, selected_index + 1)
                else:
                    # Escape key - cancel
                    console.clear()
                    self.show_header()
                    return
            elif char == '\r' or char == '\n':  # Enter
                # Select model
                new_model = self.available_models[selected_index]
                if new_model != self.model:
                    self.model = new_model
                    self.client = OllamaClient(model=new_model)
                    console.clear()
                    self.show_header()
                    console.print(f"\n[bold green]✓[/bold green] Switched to [cyan]{new_model}[/cyan]\n")
                else:
                    console.clear()
                    self.show_header()
                return
            elif char == '\x03':  # Ctrl+C
                raise KeyboardInterrupt
    
    def show_settings(self):
        """Show settings"""
        from .. import __version__
        from ..auth.auth_manager import AuthManager
        
        auth = AuthManager()
        user_info = auth.get_user_info()
        
        console.print()
        table = Table(
            title="[bold cyan]Current Settings[/bold cyan]",
            border_style="blue",
            show_header=True,
            header_style="bold white on blue"
        )
        table.add_column("Setting", style="bold cyan", width=20)
        table.add_column("Value", style="yellow")
        
        table.add_row("Version", __version__)
        table.add_row("Company", "Tzamun Arabia IT Co. 🇸🇦")
        table.add_row("User", f"{user_info.get('username', 'Guest')} ✓")
        table.add_row("Auth Type", user_info.get('type', 'N/A').replace('_', ' ').title())
        table.add_row("Backend", self.backend)
        table.add_row("Model", self.model)
        table.add_row("Available Models", str(len(self.available_models)))
        table.add_row("Workspace", str(self.workspace))
        table.add_row("Code Skills", "✓ Enabled")
        
        console.print(table)
        console.print()
    
    def show_files(self):
        """Show files in workspace"""
        console.print()
        console.print("─" * 60, style="dim")
        console.print()
        
        files = self.file_manager.list_files(str(self.workspace))[:30]
        
        console.print(f"[bold cyan]Files in {self.workspace.name}/[/bold cyan]\n")
        for f in files:
            console.print(f"  [dim]•[/dim] {f}")
        
        if len(files) >= 30:
            console.print(f"\n[dim]... and more[/dim]")
        
        console.print()
        console.print("─" * 60, style="dim")
        console.print()
    
    def show_project_info(self):
        """Show project structure"""
        console.print("\n")
        console.print("─" * 60, style="dim")
        console.print()
        console.print("[dim]Scanning project...[/dim]")
        console.print()
        
        structure = self.project_scanner.scan()
        
        table = Table(
            title="[bold cyan]Project Structure[/bold cyan]",
            border_style="blue",
            show_header=True,
            header_style="bold white on blue",
            expand=False,
            width=60
        )
        table.add_column("Property", style="bold cyan", width=20, no_wrap=True)
        table.add_column("Value", style="yellow", overflow="fold", width=38)
        
        table.add_row("Total Files", str(structure['total_files']))
        table.add_row("Total Directories", str(structure['total_dirs']))
        table.add_row("Languages", ", ".join(structure['languages']) if structure['languages'] else "None detected")
        table.add_row("Project Type", self.project_scanner.get_project_type())
        
        console.print(table)
        
        if structure['key_files']:
            console.print()
            console.print("[bold cyan]Key Files:[/bold cyan]")
            for f in structure['key_files'][:10]:
                console.print(f"  [dim]•[/dim] {f}")
        
        console.print()
        console.print("─" * 60, style="dim")
        console.print()
    
    def read_file(self, file_path: str):
        """Read and display a file with syntax highlighting"""
        try:
            from rich.syntax import Syntax
            
            full_path = self.workspace / file_path
            
            if not full_path.exists():
                console.print(f"\n[bold red]✗[/bold red] File not found: {file_path}\n")
                return
            
            if full_path.is_dir():
                console.print(f"\n[bold red]✗[/bold red] {file_path} is a directory, not a file\n")
                return
            
            # Read file content
            content = full_path.read_text()
            
            # Detect language for syntax highlighting
            suffix = full_path.suffix.lstrip('.')
            lang_map = {
                'py': 'python', 'js': 'javascript', 'ts': 'typescript',
                'jsx': 'jsx', 'tsx': 'tsx', 'java': 'java', 'cpp': 'cpp',
                'c': 'c', 'go': 'go', 'rs': 'rust', 'rb': 'ruby',
                'php': 'php', 'html': 'html', 'css': 'css', 'json': 'json',
                'yaml': 'yaml', 'yml': 'yaml', 'xml': 'xml', 'md': 'markdown',
                'sh': 'bash', 'bash': 'bash', 'sql': 'sql'
            }
            language = lang_map.get(suffix, 'text')
            
            console.print()
            console.print(f"[bold cyan]📄 {file_path}[/bold cyan] ({len(content)} chars, {len(content.splitlines())} lines)\n")
            
            # Syntax highlighted display
            syntax = Syntax(content, language, theme="monokai", line_numbers=True)
            console.print(syntax)
            console.print()
            
            # Add to conversation context
            self.conversation_history.append({
                "role": "user",
                "content": f"I read the file {file_path}:\n```{language}\n{content}\n```"
            })
            
        except Exception as e:
            console.print(f"\n[bold red]✗ Error reading file:[/bold red] {e}\n")
    
    def write_file(self, file_path: str):
        """Write content to a file interactively"""
        try:
            console.print()
            console.print(f"[bold cyan]Writing to:[/bold cyan] {file_path}")
            console.print("[dim]Enter content (type 'EOF' on a new line to finish):[/dim]\n")
            
            lines = []
            while True:
                line = input()
                if line == 'EOF':
                    break
                lines.append(line)
            
            content = '\n'.join(lines)
            
            full_path = self.workspace / file_path
            
            # Confirm if file exists
            if full_path.exists():
                if not Confirm.ask(f"\n[bold yellow]⚠[/bold yellow] File exists. Overwrite?"):
                    console.print("[dim]Write cancelled[/dim]\n")
                    return
            
            # Create parent directories if needed
            full_path.parent.mkdir(parents=True, exist_ok=True)
            
            # Write file
            full_path.write_text(content)
            
            console.print(f"\n[bold green]✓[/bold green] Written {len(content)} chars to {file_path}\n")
            
            # Add to conversation context
            self.conversation_history.append({
                "role": "user",
                "content": f"I wrote to file {file_path}:\n```\n{content}\n```"
            })
            
        except KeyboardInterrupt:
            console.print("\n[dim]Write cancelled[/dim]\n")
        except Exception as e:
            console.print(f"\n[bold red]✗ Error writing file:[/bold red] {e}\n")
    
    def switch_backend(self):
        """Switch between vLLM and Ollama backends"""
        from rich.prompt import Prompt
        
        console.print()
        console.print("[bold cyan]Switch AI Backend[/bold cyan]\n")
        console.print(f"Current: [bold]{'vLLM' if self.use_vllm else 'Ollama'}[/bold]\n")
        console.print("  [bold]1[/bold]. ⚡ [cyan]vLLM[/cyan] - Fast inference (Qwen 2.5 7B)")
        console.print("  [bold]2[/bold]. 🦙 [green]Ollama[/green] - Powerful models (Qwen 2.5 32B)")
        
        choice = Prompt.ask("\nSwitch to", choices=["1", "2"], default="2" if self.use_vllm else "1")
        
        new_use_vllm = (choice == "1")
        
        if new_use_vllm == self.use_vllm:
            console.print("\n[dim]Already using this backend[/dim]\n")
            return
        
        # Switch backend
        self.use_vllm = new_use_vllm
        
        if self.use_vllm:
            self.model = "qwen2.5-7b-instruct"
            self.client = VLLMClient(model=self.model)
            self.backend = "vLLM"
            console.print("\n[bold green]✓[/bold green] Switched to [cyan]vLLM[/cyan] backend\n")
        else:
            self.model = "qwen2.5:32b"
            self.client = OllamaClient(model=self.model)
            self.backend = "Ollama"
            console.print("\n[bold green]✓[/bold green] Switched to [green]Ollama[/green] backend\n")
    
    def show_conversation_history(self):
        """Show conversation history"""
        console.print()
        
        if len(self.conversation_history) <= 1:  # Only system prompt
            console.print("[dim]No conversation history yet[/dim]\n")
            return
        
        console.print(f"[bold cyan]Conversation History[/bold cyan] ({len(self.conversation_history) - 1} messages)\n")
        
        for idx, msg in enumerate(self.conversation_history[1:], 1):  # Skip system prompt
            role = msg['role']
            content = msg['content']
            
            if role == 'user':
                console.print(f"[bold green]{idx}. You[/bold green] › {content[:100]}{'...' if len(content) > 100 else ''}")
            else:
                console.print(f"[bold blue]{idx}. AI[/bold blue] › {content[:100]}{'...' if len(content) > 100 else ''}")
        
        console.print()
    
    def save_conversation(self, filename: str):
        """Save conversation to JSON file"""
        import json
        
        try:
            save_path = self.workspace / filename
            
            # Prepare data
            data = {
                'model': self.model,
                'backend': self.backend,
                'workspace': str(self.workspace),
                'conversation': self.conversation_history
            }
            
            # Save to file
            with open(save_path, 'w') as f:
                json.dump(data, f, indent=2)
            
            console.print(f"\n[bold green]✓[/bold green] Conversation saved to {filename}\n")
            
        except Exception as e:
            console.print(f"\n[bold red]✗ Error saving:[/bold red] {e}\n")
    
    def load_conversation(self, filename: str):
        """Load conversation from JSON file"""
        import json
        
        try:
            load_path = self.workspace / filename
            
            if not load_path.exists():
                console.print(f"\n[bold red]✗[/bold red] File not found: {filename}\n")
                return
            
            # Load data
            with open(load_path, 'r') as f:
                data = json.load(f)
            
            # Restore conversation
            self.conversation_history = data['conversation']
            
            console.print(f"\n[bold green]✓[/bold green] Loaded conversation from {filename}")
            console.print(f"[dim]Model: {data.get('model', 'unknown')} | Messages: {len(self.conversation_history)}[/dim]\n")
            
        except Exception as e:
            console.print(f"\n[bold red]✗ Error loading:[/bold red] {e}\n")
    
    def execute_command(self, command: str):
        """Execute a terminal command with user confirmation"""
        console.print()
        console.print(f"[bold yellow]Command to execute:[/bold yellow] [cyan]{command}[/cyan]")
        console.print()
        
        # Check for dangerous commands
        dangerous_keywords = ['rm -rf', 'sudo rm', 'format', 'mkfs', 'dd if=']
        if any(keyword in command.lower() for keyword in dangerous_keywords):
            console.print("[bold red]⚠ Warning:[/bold red] This command appears dangerous!")
            console.print("[dim]It may delete files or cause system damage.[/dim]\n")
        
        # Ask for confirmation
        if not Confirm.ask("[bold]Execute this command?[/bold]"):
            console.print("[dim]Command cancelled[/dim]\n")
            return
        
        # Execute command
        console.print("\n[dim]Executing...[/dim]\n")
        
        try:
            result = subprocess.run(
                command,
                shell=True,
                cwd=str(self.workspace),
                capture_output=True,
                text=True,
                timeout=30
            )
            
            # Show output
            if result.stdout:
                console.print("[bold green]Output:[/bold green]")
                console.print(result.stdout)
            
            if result.stderr:
                console.print("[bold red]Errors:[/bold red]")
                console.print(result.stderr)
            
            if result.returncode == 0:
                console.print(f"\n[bold green]✓[/bold green] Command completed successfully (exit code: {result.returncode})\n")
            else:
                console.print(f"\n[bold yellow]⚠[/bold yellow] Command exited with code: {result.returncode}\n")
                if "No such file or directory" in result.stderr:
                    console.print("[dim]💡 Tip: Use /files to see available files or /project to see project structure[/dim]\n")
            
            # Add to conversation history so AI can see the result
            # Truncate output to prevent overwhelming context
            max_output_length = 2000
            stdout_truncated = result.stdout[:max_output_length] if result.stdout else ""
            stderr_truncated = result.stderr[:max_output_length] if result.stderr else ""
            
            if len(result.stdout) > max_output_length:
                stdout_truncated += f"\n... (truncated {len(result.stdout) - max_output_length} characters)"
            if len(result.stderr) > max_output_length:
                stderr_truncated += f"\n... (truncated {len(result.stderr) - max_output_length} characters)"
            
            self.conversation_history.append({
                "role": "user",
                "content": f"Executed command: {command}\nOutput: {stdout_truncated}\nErrors: {stderr_truncated}\nExit code: {result.returncode}"
            })
            
        except subprocess.TimeoutExpired:
            console.print("[bold red]✗[/bold red] Command timed out (30s limit)\n")
        except Exception as e:
            console.print(f"[bold red]✗ Error:[/bold red] {e}\n")
    
    def send_message(self, message: str):
        """Send message to AI"""
        console.print(f"\n[bold green]You[/bold green] › {message}")
        
        self.conversation_history.append({"role": "user", "content": message})
        
        console.print("[bold blue]TzamunCode[/bold blue] › ", end="")
        console.print("[dim](thinking...)[/dim] ", end="")
        
        try:
            response = ""
            chunk_count = 0
            buffer = ""
            
            for chunk in self.client.chat_stream(self.conversation_history):
                # Clear "thinking..." on first chunk
                if chunk_count == 0:
                    sys.stdout.write('\b' * 15 + ' ' * 15 + '\b' * 15)
                    sys.stdout.flush()
                
                response += chunk
                buffer += chunk
                
                # Flush buffer every 10 characters or on newline for instant display
                if len(buffer) >= 10 or '\n' in chunk:
                    sys.stdout.write(buffer)
                    sys.stdout.flush()
                    buffer = ""
                
                chunk_count += 1
            
            # Flush any remaining buffer
            if buffer:
                sys.stdout.write(buffer)
                sys.stdout.flush()
            
            if chunk_count == 0:
                # No response received
                console.print("\n[bold yellow]⚠[/bold yellow] No response from model. Try a different model or check Ollama service.\n")
                self.conversation_history.pop()  # Remove the unanswered question
                return
            
            console.print("\n")
            
            # Add response to history
            self.conversation_history.append({"role": "assistant", "content": response})
            
            # Auto-detect and execute commands from AI response
            import re
            execute_pattern = r'\[EXECUTE:\s*([^\]]+)\]'
            matches = re.findall(execute_pattern, response)
            
            if matches:
                console.print(f"\n[bold yellow]🤖 AI suggested {len(matches)} command(s)[/bold yellow]\n")
                for cmd in matches:
                    self.execute_command(cmd.strip())
                
                # Show message to user - they can ask AI to analyze results
                console.print("[dim]💡 Command executed. You can now ask me to analyze the results![/dim]\n")
            
        except KeyboardInterrupt:
            console.print("\n\n[dim]Response interrupted[/dim]\n")
            self.conversation_history.pop()  # Remove the unanswered question
        except Exception as e:
            console.print(f"\n[bold red]Error:[/bold red] {e}")
            console.print("[dim]Try switching to a faster model with /models[/dim]\n")
            self.conversation_history.pop()  # Remove the unanswered question


def run_realtime_chat(model: str = "qwen2.5:32b", system: Optional[str] = None, use_vllm: bool = False):
    """Run real-time chat"""
    chat = RealtimeChat(model=model, use_vllm=use_vllm)
    chat.run()
