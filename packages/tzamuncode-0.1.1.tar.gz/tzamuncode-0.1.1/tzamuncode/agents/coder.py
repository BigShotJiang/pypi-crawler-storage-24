"""
Agentic Coder - Advanced AI coding agent with file access and tool calling
"""

from typing import List, Dict, Optional, Any
from pathlib import Path
import json

from langchain.agents import initialize_agent, Tool, AgentType
from langchain.memory import ConversationBufferMemory
from langchain_community.llms import Ollama

from ..utils.file_ops import FileManager
from ..utils.project_scanner import ProjectScanner
from .tools import create_tools


class AgenticCoder:
    """
    Advanced AI coding agent with file access and autonomous capabilities.
    
    Similar to Claude Code, this agent can:
    - Read and write files autonomously
    - Scan project structure
    - Edit multiple files
    - Execute git operations
    - Search codebase
    - Plan multi-step tasks
    """
    
    def __init__(
        self,
        model: str = "qwen2.5:32b",
        base_url: str = "http://localhost:11434",
        workspace: Optional[str] = None
    ):
        self.model = model
        self.base_url = base_url
        self.workspace = Path(workspace) if workspace else Path.cwd()
        
        # Initialize components
        self.file_manager = FileManager()
        self.project_scanner = ProjectScanner(self.workspace)
        
        # Initialize LLM
        self.llm = Ollama(
            model=model,
            base_url=base_url,
            temperature=0.7
        )
        
        # Create tools
        self.tools = create_tools(
            file_manager=self.file_manager,
            project_scanner=self.project_scanner,
            workspace=self.workspace
        )
        
        # Initialize memory
        self.memory = ConversationBufferMemory(
            memory_key="chat_history",
            return_messages=True
        )
        
        # Initialize agent
        self.agent = initialize_agent(
            tools=self.tools,
            llm=self.llm,
            agent=AgentType.STRUCTURED_CHAT_ZERO_SHOT_REACT_DESCRIPTION,
            verbose=True,
            memory=self.memory,
            handle_parsing_errors=True,
            max_iterations=10
        )
    
    def execute(self, instruction: str) -> Dict[str, Any]:
        """
        Execute an instruction using the agentic AI.
        
        The agent will autonomously:
        - Scan project if needed
        - Read relevant files
        - Plan the changes
        - Edit multiple files
        - Provide summary
        
        Args:
            instruction: What to do (e.g., "Add authentication to this Flask app")
        
        Returns:
            Dict with result, files_changed, and summary
        """
        # Add context about workspace
        context = f"""You are working in: {self.workspace}

Available tools:
- read_file: Read any file in the project
- write_file: Write/create files
- list_files: List files in directories
- search_code: Search for code patterns
- git_status: Check git status
- scan_project: Understand project structure

Instruction: {instruction}

Think step by step:
1. Understand what needs to be done
2. Scan project structure if needed
3. Read relevant files
4. Plan the changes
5. Make the changes
6. Summarize what was done
"""
        
        try:
            result = self.agent.run(context)
            
            return {
                "success": True,
                "result": result,
                "workspace": str(self.workspace)
            }
        except Exception as e:
            return {
                "success": False,
                "error": str(e),
                "workspace": str(self.workspace)
            }
    
    def chat(self, message: str) -> str:
        """
        Chat with the agent while maintaining context.
        
        Args:
            message: User message
        
        Returns:
            Agent response
        """
        return self.agent.run(message)
    
    def reset_memory(self):
        """Reset conversation memory"""
        self.memory.clear()
