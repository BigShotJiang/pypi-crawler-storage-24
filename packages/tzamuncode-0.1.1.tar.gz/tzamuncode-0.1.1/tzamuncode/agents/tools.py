"""
Tool definitions for the agentic coder
"""

from langchain.tools import Tool
from pathlib import Path
from typing import List
import subprocess
import os

from ..utils.file_ops import FileManager
from ..utils.project_scanner import ProjectScanner


def create_tools(
    file_manager: FileManager,
    project_scanner: ProjectScanner,
    workspace: Path
) -> List[Tool]:
    """Create tools for the agent"""
    
    def read_file_tool(file_path: str) -> str:
        """Read a file from the project"""
        try:
            full_path = workspace / file_path
            return file_manager.read_file(str(full_path))
        except Exception as e:
            return f"Error reading file: {e}"
    
    def write_file_tool(args: str) -> str:
        """
        Write content to a file.
        Args should be: file_path|||content
        """
        try:
            parts = args.split("|||", 1)
            if len(parts) != 2:
                return "Error: Use format 'file_path|||content'"
            
            file_path, content = parts
            full_path = workspace / file_path.strip()
            file_manager.write_file(str(full_path), content.strip())
            return f"Successfully wrote to {file_path}"
        except Exception as e:
            return f"Error writing file: {e}"
    
    def list_files_tool(directory: str = ".") -> str:
        """List files in a directory"""
        try:
            dir_path = workspace / directory
            files = file_manager.list_files(str(dir_path))
            return "\n".join(files[:50])  # Limit to 50 files
        except Exception as e:
            return f"Error listing files: {e}"
    
    def search_code_tool(pattern: str) -> str:
        """Search for code pattern in project"""
        try:
            result = subprocess.run(
                ["grep", "-r", "-n", pattern, str(workspace)],
                capture_output=True,
                text=True,
                timeout=10
            )
            output = result.stdout[:2000]  # Limit output
            return output if output else "No matches found"
        except Exception as e:
            return f"Error searching: {e}"
    
    def git_status_tool(_: str = "") -> str:
        """Check git status"""
        try:
            result = subprocess.run(
                ["git", "status", "--short"],
                cwd=workspace,
                capture_output=True,
                text=True,
                timeout=5
            )
            return result.stdout if result.stdout else "No changes"
        except Exception as e:
            return f"Error checking git: {e}"
    
    def scan_project_tool(_: str = "") -> str:
        """Scan and understand project structure"""
        try:
            structure = project_scanner.scan()
            return f"""Project Structure:
Files: {structure['total_files']}
Directories: {structure['total_dirs']}
Languages: {', '.join(structure['languages'])}

Key files:
{chr(10).join(structure['key_files'][:10])}
"""
        except Exception as e:
            return f"Error scanning project: {e}"
    
    def execute_command_tool(command: str) -> str:
        """Execute a shell command (use with caution)"""
        try:
            # Whitelist safe commands
            safe_commands = ['ls', 'pwd', 'cat', 'grep', 'find', 'git']
            cmd_parts = command.split()
            if not cmd_parts or cmd_parts[0] not in safe_commands:
                return f"Error: Command '{cmd_parts[0] if cmd_parts else 'empty'}' not allowed"
            
            result = subprocess.run(
                command,
                shell=True,
                cwd=workspace,
                capture_output=True,
                text=True,
                timeout=10
            )
            return result.stdout[:1000]  # Limit output
        except Exception as e:
            return f"Error executing command: {e}"
    
    # Create tool list
    tools = [
        Tool(
            name="read_file",
            func=read_file_tool,
            description="Read a file from the project. Input: file path relative to project root"
        ),
        Tool(
            name="write_file",
            func=write_file_tool,
            description="Write content to a file. Input: 'file_path|||content' (use ||| as separator)"
        ),
        Tool(
            name="list_files",
            func=list_files_tool,
            description="List files in a directory. Input: directory path (default: current directory)"
        ),
        Tool(
            name="search_code",
            func=search_code_tool,
            description="Search for a pattern in the codebase. Input: search pattern"
        ),
        Tool(
            name="git_status",
            func=git_status_tool,
            description="Check git status. Input: empty string"
        ),
        Tool(
            name="scan_project",
            func=scan_project_tool,
            description="Scan and understand project structure. Input: empty string"
        ),
        Tool(
            name="execute_command",
            func=execute_command_tool,
            description="Execute a safe shell command. Input: command to execute"
        ),
    ]
    
    return tools
