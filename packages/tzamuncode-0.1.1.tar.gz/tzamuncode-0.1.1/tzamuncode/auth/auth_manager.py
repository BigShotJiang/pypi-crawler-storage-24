"""
Authentication Manager for TzamunCode
Supports username/password and API key authentication with TzamunAI
"""

import requests
import json
from pathlib import Path
from typing import Optional, Dict
import hashlib
from datetime import datetime, timedelta


class AuthManager:
    """Manage authentication for TzamunCode CLI"""
    
    CONFIG_DIR = Path.home() / ".tzamuncode"
    CONFIG_FILE = CONFIG_DIR / "auth.json"
    TZAMUN_API_BASE = "http://192.168.1.141:3008"  # Local Tzamun backend
    
    def __init__(self):
        self.CONFIG_DIR.mkdir(exist_ok=True)
        self.auth_data = self.load_auth()
    
    def load_auth(self) -> Dict:
        """Load authentication data from config file"""
        if self.CONFIG_FILE.exists():
            try:
                with open(self.CONFIG_FILE, 'r') as f:
                    return json.load(f)
            except:
                return {}
        return {}
    
    def save_auth(self, auth_data: Dict):
        """Save authentication data to config file"""
        with open(self.CONFIG_FILE, 'w') as f:
            json.dump(auth_data, f, indent=2)
        # Secure the file (only owner can read/write)
        self.CONFIG_FILE.chmod(0o600)
    
    def is_authenticated(self) -> bool:
        """Check if user is authenticated"""
        if not self.auth_data:
            return False
        
        # Check if token is expired
        if 'expires_at' in self.auth_data:
            expires_at = datetime.fromisoformat(self.auth_data['expires_at'])
            if datetime.now() > expires_at:
                return False
        
        return 'api_key' in self.auth_data or 'token' in self.auth_data
    
    def login_with_credentials(self, username: str, password: str) -> bool:
        """
        Login with username and password
        
        Args:
            username: TzamunAI username
            password: TzamunAI password
        
        Returns:
            True if login successful
        """
        try:
            # Call TzamunAI login API
            response = requests.post(
                f"{self.TZAMUN_API_BASE}/api/auth/login",
                json={
                    "username": username,
                    "password": password
                },
                timeout=10
            )
            
            if response.status_code == 200:
                data = response.json()
                
                # Save auth token
                self.auth_data = {
                    'type': 'credentials',
                    'username': username,
                    'token': data.get('token'),
                    'expires_at': (datetime.now() + timedelta(days=30)).isoformat()
                }
                self.save_auth(self.auth_data)
                return True
            
            return False
            
        except Exception as e:
            print(f"Login error: {e}")
            return False
    
    def login_with_api_key(self, api_key: str) -> bool:
        """
        Login with TzamunAI API key
        
        Args:
            api_key: TzamunAI API key (from TCHub)
        
        Returns:
            True if API key is valid
        """
        try:
            # Validate API key with TzamunAI
            response = requests.get(
                f"{self.TZAMUN_API_BASE}/api/v1/tchub/validate",
                headers={
                    'X-API-Key': api_key
                },
                timeout=10
            )
            
            if response.status_code == 200:
                # Save API key
                self.auth_data = {
                    'type': 'api_key',
                    'api_key': api_key,
                    'validated_at': datetime.now().isoformat()
                }
                self.save_auth(self.auth_data)
                return True
            
            return False
            
        except Exception as e:
            print(f"API key validation error: {e}")
            return False
    
    def logout(self):
        """Logout and clear authentication data"""
        self.auth_data = {}
        if self.CONFIG_FILE.exists():
            self.CONFIG_FILE.unlink()
    
    def get_auth_header(self) -> Dict[str, str]:
        """Get authentication header for API requests"""
        if not self.is_authenticated():
            return {}
        
        if self.auth_data.get('type') == 'api_key':
            return {'X-API-Key': self.auth_data['api_key']}
        elif self.auth_data.get('type') == 'credentials':
            return {'Authorization': f"Bearer {self.auth_data['token']}"}
        
        return {}
    
    def get_user_info(self) -> Dict:
        """Get current user information"""
        if not self.is_authenticated():
            return {}
        
        return {
            'type': self.auth_data.get('type'),
            'username': self.auth_data.get('username', 'API Key User'),
            'authenticated': True
        }
