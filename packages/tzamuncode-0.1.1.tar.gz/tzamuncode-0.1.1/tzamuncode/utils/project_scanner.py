"""
Project scanner for understanding codebase structure
"""

from pathlib import Path
from typing import Dict, List, Set
import os


class ProjectScanner:
    """Scan and understand project structure"""
    
    # Common files to ignore
    IGNORE_DIRS = {
        '.git', '__pycache__', 'node_modules', 'venv', 'env',
        '.venv', 'dist', 'build', '.pytest_cache', '.mypy_cache',
        'coverage', '.coverage', 'htmlcov'
    }
    
    IGNORE_FILES = {
        '.pyc', '.pyo', '.pyd', '.so', '.dll', '.dylib',
        '.class', '.o', '.obj', '.exe'
    }
    
    # Language detection
    LANGUAGE_EXTENSIONS = {
        '.py': 'Python',
        '.js': 'JavaScript',
        '.ts': 'TypeScript',
        '.jsx': 'React',
        '.tsx': 'React TypeScript',
        '.go': 'Go',
        '.rs': 'Rust',
        '.java': 'Java',
        '.cpp': 'C++',
        '.c': 'C',
        '.rb': 'Ruby',
        '.php': 'PHP',
        '.swift': 'Swift',
        '.kt': 'Kotlin',
        '.sh': 'Shell',
        '.md': 'Markdown',
        '.json': 'JSON',
        '.yaml': 'YAML',
        '.yml': 'YAML',
        '.toml': 'TOML',
        '.html': 'HTML',
        '.css': 'CSS',
        '.scss': 'SCSS',
        '.sql': 'SQL',
    }
    
    def __init__(self, workspace: Path):
        self.workspace = Path(workspace)
    
    def scan(self) -> Dict:
        """
        Scan project and return structure information
        
        Returns:
            Dict with project metadata
        """
        structure = {
            'total_files': 0,
            'total_dirs': 0,
            'languages': set(),
            'key_files': [],
            'file_tree': [],
        }
        
        for root, dirs, files in os.walk(self.workspace):
            # Filter ignored directories
            dirs[:] = [d for d in dirs if d not in self.IGNORE_DIRS]
            
            root_path = Path(root)
            rel_root = root_path.relative_to(self.workspace)
            
            structure['total_dirs'] += len(dirs)
            
            for file in files:
                # Skip ignored files
                if any(file.endswith(ext) for ext in self.IGNORE_FILES):
                    continue
                
                structure['total_files'] += 1
                
                file_path = root_path / file
                rel_path = file_path.relative_to(self.workspace)
                
                # Detect language
                ext = file_path.suffix
                if ext in self.LANGUAGE_EXTENSIONS:
                    structure['languages'].add(self.LANGUAGE_EXTENSIONS[ext])
                
                # Identify key files
                if self._is_key_file(file):
                    structure['key_files'].append(str(rel_path))
                
                # Add to file tree (limit depth)
                if len(rel_path.parts) <= 3:
                    structure['file_tree'].append(str(rel_path))
        
        structure['languages'] = sorted(list(structure['languages']))
        
        return structure
    
    def _is_key_file(self, filename: str) -> bool:
        """Check if file is a key project file"""
        key_files = {
            'README.md', 'README.rst', 'README.txt',
            'setup.py', 'setup.cfg', 'pyproject.toml',
            'requirements.txt', 'Pipfile', 'poetry.lock',
            'package.json', 'package-lock.json', 'yarn.lock',
            'Cargo.toml', 'go.mod', 'pom.xml', 'build.gradle',
            'Makefile', 'Dockerfile', 'docker-compose.yml',
            '.gitignore', 'LICENSE', 'CONTRIBUTING.md',
            'main.py', 'app.py', 'index.js', 'main.go',
            '__init__.py', '__main__.py'
        }
        
        return filename in key_files
    
    def find_files(self, pattern: str) -> List[str]:
        """Find files matching a pattern"""
        matches = []
        
        for root, dirs, files in os.walk(self.workspace):
            dirs[:] = [d for d in dirs if d not in self.IGNORE_DIRS]
            
            root_path = Path(root)
            
            for file in files:
                if pattern in file:
                    file_path = root_path / file
                    rel_path = file_path.relative_to(self.workspace)
                    matches.append(str(rel_path))
        
        return matches
    
    def get_project_type(self) -> str:
        """Detect project type"""
        project_types = []
        
        # Check root directory
        try:
            root_files = set(os.listdir(self.workspace))
        except:
            return 'Unknown'
        
        # Check for multiple project types
        if 'package.json' in root_files:
            project_types.append('Node.js')
        
        if 'requirements.txt' in root_files or 'setup.py' in root_files or 'pyproject.toml' in root_files:
            project_types.append('Python')
        
        if 'Cargo.toml' in root_files:
            project_types.append('Rust')
        
        if 'go.mod' in root_files:
            project_types.append('Go')
        
        if 'pom.xml' in root_files or 'build.gradle' in root_files:
            project_types.append('Java')
        
        # Check for frontend frameworks
        if 'package.json' in root_files:
            try:
                import json
                pkg_path = self.workspace / 'package.json'
                with open(pkg_path) as f:
                    pkg = json.load(f)
                    deps = {**pkg.get('dependencies', {}), **pkg.get('devDependencies', {})}
                    
                    if 'react' in deps:
                        project_types.append('React')
                    elif 'vue' in deps:
                        project_types.append('Vue')
                    elif 'angular' in deps or '@angular/core' in deps:
                        project_types.append('Angular')
                    elif 'next' in deps:
                        project_types.append('Next.js')
            except:
                pass
        
        # Check subdirectories for additional context
        if 'backend' in root_files and 'frontend' in root_files:
            return 'Full-Stack (' + ', '.join(project_types) + ')' if project_types else 'Full-Stack'
        
        if project_types:
            return ', '.join(project_types)
        
        return 'Unknown'
