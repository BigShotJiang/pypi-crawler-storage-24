"""
File operations utilities for TzamunCode
"""

from pathlib import Path
from typing import Optional
import difflib

class FileManager:
    """Manage file operations"""
    
    def read_file(self, path: str) -> str:
        """Read file content"""
        file_path = Path(path)
        if not file_path.exists():
            raise FileNotFoundError(f"File not found: {path}")
        return file_path.read_text()
    
    def write_file(self, path: str, content: str) -> None:
        """Write content to file"""
        file_path = Path(path)
        
        # Create parent directories if they don't exist
        file_path.parent.mkdir(parents=True, exist_ok=True)
        
        file_path.write_text(content)
    
    def show_diff(self, path: str, new_content: str) -> str:
        """Show diff between current and new content"""
        try:
            old_content = self.read_file(path)
        except FileNotFoundError:
            # New file
            return f"+++ {path} (new file)\n" + "\n".join(f"+{line}" for line in new_content.splitlines())
        
        old_lines = old_content.splitlines(keepends=True)
        new_lines = new_content.splitlines(keepends=True)
        
        diff = difflib.unified_diff(
            old_lines,
            new_lines,
            fromfile=f"a/{path}",
            tofile=f"b/{path}",
            lineterm=""
        )
        
        return "".join(diff)
    
    def file_exists(self, path: str) -> bool:
        """Check if file exists"""
        return Path(path).exists()
    
    def list_files(self, directory: str, pattern: str = "*") -> list:
        """List files in directory matching pattern"""
        dir_path = Path(directory)
        if not dir_path.is_dir():
            raise NotADirectoryError(f"Not a directory: {directory}")
        
        return [str(p) for p in dir_path.rglob(pattern) if p.is_file()]
