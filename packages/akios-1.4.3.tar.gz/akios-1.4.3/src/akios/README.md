# AKIOS Source Package

**Version:** 1.4.3  
**Secure AI Workflow Execution with military-grade security.**

---

## Module Map

```
akios/
├── cli/              21 CLI commands (init, run, cage, protect, output, ...)
│   ├── commands/     Individual command implementations
│   └── data/         Sample data (loaded via importlib.resources)
├── config/           Configuration loading, validation, settings, modes
├── core/             Core services
│   ├── audit/        Cryptographic audit logging (Merkle tree, JSON export)
│   ├── cache/        SHA-256 keyed caching with compression
│   ├── compliance/   Security posture scoring
│   ├── config/       First-run setup wizard
│   ├── error/        Error classification & user messaging
│   ├── performance/  Memory/CPU monitoring & benchmarking
│   ├── runtime/      Workflow engine, 6 agent types, 7 LLM providers
│   ├── schema/       Schema definitions
│   └── ui/           Cross-platform terminal output & colors
├── security/         Security cage
│   ├── pii/          PII detection (44 patterns) & redaction
│   ├── sandbox/      cgroups v2 process isolation
│   └── syscall/      seccomp-bpf with real BPF bytecode
├── templates/        4 workflow templates + sample data
└── testing/          TestingIssueTracker for environment diagnostics
```

## Documentation Pointers

| Audience | Where to look |
|----------|---------------|
| **End users** | `docs/` — quickstart, CLI reference, security, configuration |
| **Developers** | `internal/docs/dev/source-modules-reference.md` — full module internals |
| **Architecture** | `internal/docs/dev/architecture/` — system design & decisions |
| **Security** | `internal/docs/dev/security/` — threat models & architecture |
| **Testing** | `internal/docs/testing/` — Docker & native Linux QA manuals |

> **Note:** Per-module READMEs were consolidated into
> `internal/docs/dev/source-modules-reference.md` on 2026-02-10.
> This single file is the source of truth for module internals.

## Quick Reference

```bash
# 21 CLI commands
akios init | run | status | audit | logs | clean
akios templates | setup | testing | doctor | files
akios cage up | cage down | cage status    # Security
akios protect scan | protect preview       # PII
akios output latest                        # Deployable artifact
akios compliance | docs | timeline

# Entry points
python -m akios          # Direct execution
python -m akios.cli      # CLI module
./akios                  # Docker wrapper (production)
```

## License

GPL-3.0-only
