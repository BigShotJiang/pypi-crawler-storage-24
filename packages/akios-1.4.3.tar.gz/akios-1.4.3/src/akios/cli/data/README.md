# CLI Sample Data

This directory contains sample data files used during project initialization to populate test data for AKIOS workflow templates.

## Directory Structure

```
data/
├── samples/
│   ├── analysis_targets/     # Sample files for testing file_analysis workflows
│   │   ├── sample.docx       # Word document for analysis testing
│   │   ├── sample.pdf        # PDF document for analysis testing
│   │   └── sample.txt        # Text file for analysis testing
│   └── document_examples/    # Sample files for testing document_ingestion workflows
│       ├── sample.docx       # Word document for ingestion testing
│       ├── sample.pdf        # PDF document for ingestion testing
│       └── sample.txt        # Text file for ingestion testing
└── README.md                 # This documentation
```

## Purpose

These sample files serve multiple purposes in the AKIOS development and testing ecosystem:

- **Template Testing**: Provide realistic test data for workflow templates during development
- **User Onboarding**: Give new users sample documents to test workflows immediately
- **CI/CD Validation**: Ensure workflow templates work with various file formats
- **Regression Testing**: Maintain consistent test data across development cycles

## File Contents

### Analysis Targets (`analysis_targets/`)

Used by the `file_analysis.yml` template to test document analysis capabilities:

- **sample.txt**: Plain text content for basic analysis testing
- **sample.pdf**: PDF document with formatted content and metadata
- **sample.docx**: Word document with complex formatting and embedded elements

### Document Examples (`document_examples/`)

Used by the `document_ingestion.yml` template to test document processing:

- **sample.txt**: Simple text document for basic ingestion testing
- **sample.pdf**: PDF document for format conversion and text extraction
- **sample.docx**: Word document for rich text processing and formatting

## Usage in Code

Sample files are accessed via Python's `pkg_resources` during project initialization:

```python
import pkg_resources

# Access document example files
content = pkg_resources.resource_string(
    'akios.cli.data.samples.document_examples',
    'sample.txt'
)

# Access analysis target files
content = pkg_resources.resource_string(
    'akios.cli.data.samples.analysis_targets',
    'sample.pdf'
)
```

## Maintenance Guidelines

### Adding New Sample Files

1. **Choose appropriate subdirectory** based on template usage
2. **Use consistent naming**: `sample.{ext}` (not descriptive names)
3. **Ensure file quality**: Representative of real-world usage
4. **Test compatibility**: Verify with relevant workflow templates
5. **Update documentation**: Add description to this README

### Updating Existing Samples

1. **Maintain file format compatibility**
2. **Preserve realistic content characteristics**
3. **Test across all supported templates**
4. **Document significant changes**

### Quality Assurance

- **File integrity**: Ensure files are not corrupted during updates
- **Format compatibility**: Verify with workflow processing libraries
- **Size considerations**: Keep files reasonably sized for testing
- **Content appropriateness**: Use generic, non-sensitive test data

## Integration Points

### Project Initialization (`akios init`)

During `akios init`, these files are automatically copied to new projects:

```
project/
├── data/
│   └── input/
│       ├── document_example.docx/pdf/txt  # From document_examples/
│       └── analysis_target.docx/pdf/txt   # From analysis_targets/
```

### Workflow Templates

Templates reference these files for testing:

- `templates/file_analysis.yml` - Uses `analysis_target.*` files
- `templates/document_ingestion.yml` - Uses `document_example.*` files

### Package Distribution

Sample files are included in the Python package distribution via `pyproject.toml`:

```toml
[tool.setuptools.package-data]
akios = [
    "cli/data/samples/document_examples/sample.*",
    "cli/data/samples/analysis_targets/sample.*",
    # ... other package data
]
```

## Security Considerations

- **Content Review**: All sample files are reviewed for appropriate content
- **No Sensitive Data**: Files contain only generic test data
- **Safe Distribution**: Files are included in package for testing purposes
- **Access Control**: Files are read-only resources, not executable code

## Future Enhancements

- **Additional formats**: Support for more document types (CSV, JSON, XML)
- **Localized content**: Sample files in multiple languages
- **Size variations**: Different file sizes for performance testing
- **Domain-specific samples**: Specialized content for industry templates

---

**CLI Sample Data - Providing consistent, realistic test data for AKIOS workflows** 📁🔬
