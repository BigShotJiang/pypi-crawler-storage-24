from abc import ABC, abstractmethod
from collections import defaultdict
from typing import Any, List, Mapping

from pydantic import BaseModel

from agentops.metrics.metrics import EvaluatorData


class Result(BaseModel):
    per_dataset: Mapping[str, Mapping[str, Any]]
    overall: Mapping[str, Any]


class Aggregator(ABC):
    @abstractmethod
    def __call__(
        self, metrics: List[Mapping[str, List[EvaluatorData]]]
    ) -> Result:
        pass


class Average(Aggregator):
    def __call__(
        self, metrics: List[Mapping[str, List[EvaluatorData]]]
    ) -> Result:
        all_dataset_scores = defaultdict(list)
        for metrics_group in metrics:
            for dataset_name, scores in metrics_group.items():
                all_dataset_scores[dataset_name].extend(scores)

        metric_names = ["Runs"]
        for scores in all_dataset_scores.values():
            for score in scores:
                name = score.display_name
                if name not in metric_names:
                    metric_names.append(name)

        # compute average per dataset
        averaged_dataset_scores = defaultdict(list)
        for dataset_name, scores in all_dataset_scores.items():
            score_map = defaultdict(list)
            for score in scores:
                score_map[score.display_name].append(score.display_value)

            # average
            averaged_scores = {}
            for score_name, values in score_map.items():
                averaged_scores[score_name] = round(
                    sum(values) / len(values), 2
                )

            # Add in `n_runs` to the averaged scores
            averaged_scores["Runs"] = len(values)
            averaged_dataset_scores[dataset_name] = averaged_scores

        # compute overall average
        overall_scores = defaultdict(list)
        for name in metric_names:
            for dataset_name, scores in averaged_dataset_scores.items():
                overall_scores[name].append(scores[name])

        overall_scores = {
            name: round(sum(values) / len(values), 2)
            for name, values in overall_scores.items()
        }

        return Result(
            per_dataset=averaged_dataset_scores, overall=overall_scores
        )
