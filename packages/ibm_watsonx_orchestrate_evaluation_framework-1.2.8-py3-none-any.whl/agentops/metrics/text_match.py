from agentops.extractors.agent_resp_extractor import AgentResponseExtractor
from agentops.metrics.evaluations import Evaluation
from agentops.metrics.keyword_match_metric import KeywordMatchMetric
from agentops.metrics.metrics import (
    EvaluatorData,
    KeywordSemanticSearchMetric,
    TextMatchType,
)
from agentops.metrics.semantic_match_metric import SemanticMatchMetric
from agentops.operator.operator_base import OperatorBase
from agentops.prompt import (
    KEYWORD_MATCHING_PROMPT_PATH,
    SEMANTIC_MATCHING_PROMPT_V1_PATH,
    SEMANTIC_MATCHING_PROMPT_V2_PATH,
)
from agentops.type import Message


class TextMatchMetric(Evaluation):
    """Evaluates whether all text-based goals were successfully matched in assistant responses.
    A succesful match means that keyword match and semantic match are both True.
    """

    def __init__(
        self,
        llm_client=None,
        keyword_template_path=KEYWORD_MATCHING_PROMPT_PATH,
        semantic_template_path=SEMANTIC_MATCHING_PROMPT_V2_PATH,
    ):
        super().__init__(llm_client)
        self.dependencies = [
            AgentResponseExtractor(),
            KeywordMatchMetric(
                llm_client=llm_client, prompt_path=keyword_template_path
            ),
            SemanticMatchMetric(
                llm_client=llm_client, prompt_path=semantic_template_path
            ),
        ]

    def do_evaluate(
        self,
        messages: list[Message],
        ground_truth,
        metadata=None,
        **kwargs,
    ):

        # Get extracted text data
        extractor_context = kwargs.get("extracted_context", {}).get(
            "extractor", {}
        )
        agent_response_extractor = extractor_context.get(
            OperatorBase.key(self.dependencies[0])
        )
        text_goals = agent_response_extractor.get("text_goals").value
        text_responses = agent_response_extractor.get("text_responses").value

        metrics = kwargs.get("extracted_context", {}).get("metric", {})
        keyword_match_metric = metrics.get(
            OperatorBase.key(self.dependencies[1])
        )
        semantic_match_metric = metrics.get(
            OperatorBase.key(self.dependencies[2])
        )

        semantic_matches: list[bool] = []
        keyword_matches: list[bool] = []
        semantic_matches = semantic_match_metric.get(
            "semantic_match"
        ).metadata.get("semantic_matches")
        keyword_matches = keyword_match_metric.get(
            "keyword_match"
        ).metadata.get("keyword_matches")

        # keep track of text matches
        text_matches: list[KeywordSemanticSearchMetric] = []
        # keep track of match candidates
        text_match_candidates: dict[str, list[KeywordSemanticSearchMetric]] = {}
        idx = 0
        for message in text_responses:
            for goal_detail in text_goals:
                if goal_detail.name not in text_match_candidates:
                    text_match_candidates[goal_detail.name] = []

                keyword_match = keyword_matches[idx]
                semantic_match = semantic_matches[idx]

                keyword_semantic_match = KeywordSemanticSearchMetric(
                    keyword_match=keyword_match,
                    semantic_match=semantic_match,
                    message=message.content,
                    text_goal=goal_detail,
                    goal_detail=goal_detail.name,
                    goal_content=goal_detail.response,
                    keywords=(
                        goal_detail.keywords if goal_detail.keywords else []
                    ),
                )

                if keyword_match or semantic_match:
                    text_match_candidates[goal_detail.name].append(
                        keyword_semantic_match
                    )

                if keyword_match and semantic_match:
                    text_matches.append(keyword_semantic_match)

                idx += 1

        # Determine text match status
        matched_count = 0
        # no text goals
        if len(text_goals) == 0:
            text_match_value = TextMatchType.na
            display_value = 0
        else:
            # check that each text goal has a match
            matched_count = sum(
                1
                for goal in text_goals
                if any(match.text_goal == goal for match in text_matches)
            )
            # Determine match type
            if matched_count == 0:
                text_match_value = TextMatchType.text_mismatch
                display_value = 0
            elif matched_count == len(text_goals):
                text_match_value = TextMatchType.text_match
                display_value = 1
            else:
                text_match_value = TextMatchType.partial_match
                # NOTE: this is set to 0 to align with the legacy behavior
                display_value = 0

        return EvaluatorData(
            eval_name="text_match",
            display_name="Text Match",
            comment=f"Matched {matched_count}/{len(text_goals)} text goals",
            value=text_match_value.value,
            display_value=display_value,
            metadata={
                **(metadata or {}),
                "text_match_candidates": text_match_candidates,
                "text_goals": text_goals,
            },
        )
