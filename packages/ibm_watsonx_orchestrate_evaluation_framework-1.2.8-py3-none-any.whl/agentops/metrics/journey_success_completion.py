from typing import Any, List, Mapping, Optional

from agentops.error_constants import ERROR_KEYWORDS
from agentops.metrics.evaluations import Evaluation
from agentops.metrics.journey_success import JourneySuccessMetric
from agentops.metrics.metrics import EvaluatorData, Metric, TextMatchType
from agentops.metrics.text_match import TextMatchMetric
from agentops.metrics.tool_calling import ToolCalling
from agentops.operator.operator_base import OperatorBase
from agentops.prompt import (
    KEYWORD_MATCHING_PROMPT_PATH,
    SEMANTIC_MATCHING_PROMPT_V1_PATH,
    SEMANTIC_MATCHING_PROMPT_V2_PATH,
)
from agentops.type import Message, OrchestrateDataset


class JourneyCompletion(Evaluation):
    def __init__(
        self,
        llm_client=None,
        is_strict=True,
        error_keywords=ERROR_KEYWORDS,
        keyword_template_path=KEYWORD_MATCHING_PROMPT_PATH,
        semantic_template_path=SEMANTIC_MATCHING_PROMPT_V2_PATH,
    ):
        super().__init__(llm_client)
        self.dependencies = [
            JourneySuccessMetric(
                error_keywords=error_keywords,
                keyword_template_path=keyword_template_path,
                semantic_template_path=semantic_template_path,
            ),
            ToolCalling(llm_client=llm_client),
            TextMatchMetric(
                llm_client=llm_client,
                keyword_template_path=keyword_template_path,
                semantic_template_path=semantic_template_path,
            ),
        ]

    def do_evaluate(
        self,
        messages: List[Message],
        ground_truth: Optional[OrchestrateDataset] = None,
        metadata: Mapping[str, Any] = None,
        **kwargs,
    ) -> Optional[Metric]:
        metric_context = kwargs.get("extracted_context", {}).get("metric", {})
        journey_success = metric_context.get(
            OperatorBase.key(self.dependencies[0]), {}
        )
        journey_success = journey_success.get("is_success").value
        if journey_success:
            return EvaluatorData(
                eval_name="journey_completion",
                display_name="Journey Completion",
                value=1.0,
            )

        tool_calling = metric_context.get(
            OperatorBase.key(self.dependencies[1]), {}
        )
        tool_recall = tool_calling.get("tool_call_recall").value

        text_match_data = metric_context.get(
            OperatorBase.key(self.dependencies[2]), {}
        )
        text_match = text_match_data.get("text_match")
        text_match_value = text_match.value

        if text_match_value == TextMatchType.na.value:
            # if there are no text steps, then journey completion ~= recall
            return Metric(
                eval_name="journey_completion",
                value=tool_recall,
            )

        expected_tool_calls = tool_calling.get("expected_tool_calls").value
        correct_tool_calls = tool_calling.get("correct_tool_calls").value
        text_match_candidates = text_match.metadata.get(
            "text_match_candidates", {}
        )
        text_goals = text_match.metadata.get("text_goals", [])

        matched_text_goals = []
        for goal_name, candidates in text_match_candidates.items():
            for candidate in candidates:
                if candidate.keyword_match and candidate.semantic_match:
                    matched_text_goals.append(goal_name)
                    break

        numerator = correct_tool_calls + len(matched_text_goals)
        denominator = expected_tool_calls + len(text_goals)

        return EvaluatorData(
            eval_name="journey_completion",
            display_name="Journey Completion",
            value=round(numerator / denominator, 2),
            metadata=metadata,
        )
