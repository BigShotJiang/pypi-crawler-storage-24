from collections import defaultdict
from typing import List

from agentops.error_constants import ERROR_KEYWORDS
from agentops.extractors import ExpectedToolExtractor
from agentops.extractors.tool_response_extractor import (
    ToolResponseErrorExtractor,
)
from agentops.metrics.evaluations import Evaluation
from agentops.metrics.metrics import EvaluatorData
from agentops.metrics.text_match import TextMatchMetric
from agentops.operator.operator_base import OperatorBase
from agentops.prompt import (
    KEYWORD_MATCHING_PROMPT_PATH,
    SEMANTIC_MATCHING_PROMPT_V1_PATH,
    SEMANTIC_MATCHING_PROMPT_V2_PATH,
)
from agentops.type import ExtendedMessage
from agentops.utils.rich_utils import RichLogger

"""
- hyphens are not allowed in python function names, so it is safe to use as a dummy function name
- purpose behind `DUMMY_GRAPH_NODE_NAME` is to append
a dummy node to the ground truth and the labelled messages to take into account 
single, summary step goals.
"""
DUMMY_GRAPH_NODE_NAME = "dummy-goal"

logger = RichLogger(__name__)


class JourneySuccessMetric(Evaluation):
    def __init__(
        self,
        is_strict=True,
        llm_client=None,
        error_keywords=ERROR_KEYWORDS,
        keyword_template_path=KEYWORD_MATCHING_PROMPT_PATH,
        semantic_template_path=SEMANTIC_MATCHING_PROMPT_V2_PATH,
    ):
        logger.info(
            f"JourneySuccessMetric initialized with is_strict: {is_strict}"
        )
        super().__init__(llm_client)
        self.dependencies = [
            ExpectedToolExtractor(llm_client=llm_client),
            ToolResponseErrorExtractor(error_keywords=error_keywords),
            TextMatchMetric(
                llm_client=llm_client,
                keyword_template_path=keyword_template_path,
                semantic_template_path=semantic_template_path,
            ),
        ]
        self.is_strict = is_strict

    def tag_messages(
        self,
        messages,
        irrelevant_tool_call_idx,
        incorrect_param_tool_idx,
        tool_response_error_idx,
    ) -> List[ExtendedMessage]:
        tagged_messages = []
        for idx, message in enumerate(messages):
            message_outcome = ExtendedMessage(message=message)
            if idx in irrelevant_tool_call_idx:
                message_outcome.reason = {"reason": "irrelevant tool call"}
            elif idx in incorrect_param_tool_idx:
                message_outcome.reason = {"reason": "incorrect parameter"}
            elif idx in tool_response_error_idx:
                message_outcome.reason = {"reason": "runtime error"}
            tagged_messages.append(message_outcome)
        return tagged_messages

    def find_terminal_nodes(self, graph: dict[str, list[str]]) -> set[str]:
        """Finds terminal nodes (nodes with no outgoing edges).

        Args:
            graph: the input graph

        Returns:
            a set of the terminal nodes
        """

        seen_nodes = set()  # track seen nodes
        non_terminal_nodes = set()  # track nodes with children

        for node in graph:
            seen_nodes.add(node)
            if graph[node]:
                non_terminal_nodes.add(node)
                for n in graph[node]:
                    seen_nodes.add(n)
        return seen_nodes - non_terminal_nodes

    def is_topological_sort(
        self,
        graph: dict[str, list[str]],
        ordering: list[str],
    ) -> bool:
        """Graph traversal to check if every node in `graph` is visited in `ordering` only after all its dependencies are visited.

        Args:
            graph: the graph representing the ground truth, where keys represent nodes and values represent its dependent nodes
            ordering: the nodes visited, in order

        Returns:
            Boolean representing if `ordering` visits all nodes in a valid order based on the dependencies in graph.
        """
        # No keyword match or goal details were achieved
        if not ordering:
            return False

        if self.is_strict:
            # strict matching: only consider most recent tool call
            position = {node: [i] for i, node in enumerate(ordering)}
        else:
            # lenient matching: consider all tool calls (account for all indexes of the node)
            position = defaultdict(list)
            for i, node in enumerate(ordering):
                position[node].append(i)

        terminal_nodes = self.find_terminal_nodes(graph)
        # adds a dummy node for each terminal node
        next_idx = (
            max(val for values in position.values() for val in values) + 1
        )

        for n in terminal_nodes:
            graph[n] = [DUMMY_GRAPH_NODE_NAME]
            graph[DUMMY_GRAPH_NODE_NAME] = []
            position[DUMMY_GRAPH_NODE_NAME] = [next_idx]
            next_idx += 1

        for node in graph:
            for child_nodes in graph[node]:
                # Current node/children doesn't show up in made calls
                if node not in position or child_nodes not in position:
                    return False
                # Current node doesn't show up before any of its child
                # all index in current nodes are larger than every child nodes' index
                if all(
                    curr >= max(position[child_nodes])
                    for curr in position[node]
                ):
                    return False
        return True

    def do_evaluate(
        self,
        messages,
        ground_truth=None,
        metadata=None,
        **kwargs,
    ):

        extracted_context = kwargs.get("extracted_context", {})

        extractor_context = extracted_context.get("extractor", {})
        expected_tool_extractor = extractor_context.get(
            OperatorBase.key(self.dependencies[0])
        )
        tool_response_error_extractor = extractor_context.get(
            OperatorBase.key(self.dependencies[1])
        )

        correct_tool_calls = expected_tool_extractor.get(
            "correct_tool_calls"
        ).value
        irrelevant_tool_call_idx = expected_tool_extractor.get(
            "irrelevant_tool_call_idx"
        ).value
        incorrect_param_tool_idx = expected_tool_extractor.get(
            "incorrect_param_tool_idx"
        ).value
        tool_response_error_idx = tool_response_error_extractor.get(
            "tool_response_error_idx"
        ).value

        # create the extended messages list
        tagged_messages = self.tag_messages(
            messages,
            irrelevant_tool_call_idx,
            incorrect_param_tool_idx,
            tool_response_error_idx,
        )

        # Get matched text goals from TextMatchMetric
        metric_context = extracted_context.get("metric", {})
        text_match_results = metric_context.get(
            OperatorBase.key(self.dependencies[2])
        ).get("text_match")
        text_match_candidates = text_match_results.metadata.get(
            "text_match_candidates", {}
        )

        matched_text_goals = []
        for goal_name, candidates in text_match_candidates.items():
            # Check if any candidate has both keyword and semantic match
            for candidate in candidates:
                if candidate.keyword_match and candidate.semantic_match:
                    matched_text_goals.append(goal_name)
                    break  # Only add each goal once
                break

        # Combine tool calls and matched text goals for topological sort
        ordering = correct_tool_calls + matched_text_goals

        is_topological_sort = self.is_topological_sort(
            graph=dict(ground_truth.goals),  # make a copy to avoid mutation
            ordering=ordering,
        )

        metadata.update(
            {
                "tagged_messages": tagged_messages,
                "matched_text_goals": matched_text_goals,
            }
        )

        return EvaluatorData(
            eval_name="is_success",
            display_name="Journey Success",
            comment="",
            value=is_topological_sort,
            data_type="NUMERIC",
            metadata=metadata,
        )
