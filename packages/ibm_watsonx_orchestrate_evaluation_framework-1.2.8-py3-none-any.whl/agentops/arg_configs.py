import os
from dataclasses import dataclass, field
from enum import StrEnum
from pathlib import Path
from typing import List, Optional, Union

from agentops import __file__

DEFAULT_PROVIDER_VENDOR: str = "ibm"

root_dir = os.path.dirname(__file__)
LLAMA_USER_PROMPT_PATH = os.path.join(
    root_dir, "prompt", "llama_user_prompt.jinja2"
)
GPT_USER_PROMPT_PATH = os.path.join(
    root_dir, "prompt", "gpt", "gpt_user_template_v1.jinja2"
)
KEYWORDS_GENERATION_PROMPT_PATH = os.path.join(
    root_dir, "prompt", "keywords_generation_prompt.jinja2"
)
SUMMARY_GENERATION_PROMPT_PATH = os.path.join(
    root_dir, "prompt", "summary_generation_prompt.jinja2"
)
ARG_MATCHING_GENERATION_PROMPT_PATH = os.path.join(
    root_dir, "prompt", "arg_matching_generation_prompt.jinja2"
)
STORY_GENERATION_PROMPT_PATH = os.path.join(
    root_dir, "prompt", "story_generation_prompt.jinja2"
)


@dataclass
class AuthConfig:
    url: Optional[str] = None
    tenant_name: str = "local"
    token: str | None = None


@dataclass
class LLMUserConfig:
    model_id: str = field(default="meta-llama/llama-3-3-70b-instruct")
    prompt_config: str = field(default="")
    user_response_style: List[str] = field(default_factory=list)

    def __post_init__(self):
        """Select prompt_config based on model_id if not provided"""
        if not self.prompt_config:
            if "llama" in self.model_id.lower():
                self.prompt_config = LLAMA_USER_PROMPT_PATH
            else:
                self.prompt_config = GPT_USER_PROMPT_PATH


@dataclass
class ProviderConfig:
    model_id: str = field(default="meta-llama/llama-3-405b-instruct")
    provider: str = field(
        default_factory=lambda: (
            "gateway"
            if os.getenv("USE_GATEWAY_MODEL_PROVIDER", "").lower() == "true"
            else "watsonx"
        )
    )
    embedding_model_id: str = field(
        default="sentence-transformers/all-minilm-l6-v2"
    )
    vendor: str = field(default=DEFAULT_PROVIDER_VENDOR)
    referenceless_eval: bool = field(default=False)
    provider_params: dict = field(default_factory=dict)


@dataclass
class CustomMetricsConfig:
    paths: Optional[list[str]] = field(default=None)
    llmaaj_config: ProviderConfig = field(default_factory=ProviderConfig)


@dataclass
class ExtractorsConfig:
    paths: Optional[list[str]] = field(default=None)


@dataclass
class ControllerConfig:
    enable_verbose_logging: bool = True
    enable_manual_user_input: bool = False


@dataclass
class TextMatchConfig:
    semantic_template_path: Optional[str] = None
    keyword_template_path: Optional[str] = None


@dataclass
class TestConfig:
    test_paths: List[str]
    output_dir: str
    auth_config: AuthConfig
    wxo_lite_version: str
    provider_config: ProviderConfig = field(default_factory=ProviderConfig)
    llm_user_config: LLMUserConfig = field(default_factory=LLMUserConfig)
    custom_metrics_config: CustomMetricsConfig = field(
        default_factory=CustomMetricsConfig
    )
    extractors_config: ExtractorsConfig = field(
        default_factory=ExtractorsConfig
    )
    text_match_config: TextMatchConfig = field(default_factory=TextMatchConfig)
    skip_available_results: bool = False
    data_annotation_run: bool = False
    num_workers: int = 2
    n_runs: int = 1
    enable_verbose_logging: bool = True
    enable_manual_user_input: bool = False
    similarity_threshold: float = 0.8
    enable_fuzzy_matching: bool = False
    is_strict: bool = True
    enable_recursive_search: bool = False
    tags: list[str] = field(default_factory=list)
    error_keywords: List[str] = field(default_factory=list)
    skip_legacy_evaluation: bool = (
        False  # Skip legacy evaluation and only run user/agent simulations
    )
    collection_name: str = "default-collection"
    operator_configs: dict = None
    metrics: list[str] = field(
        default_factory=lambda: [
            "JourneySuccessMetric",
            "ToolCalling",
            "OrchestrateAgentRoutingAccuracy",
            "StepMetrics",
            "AgentResponseTime",
        ]
    )
    langfuse_enabled: bool = False


@dataclass
class AttackConfig:
    attack_paths: List[str]
    output_dir: str
    auth_config: AuthConfig
    provider_config: ProviderConfig = field(default_factory=ProviderConfig)
    llm_user_config: LLMUserConfig = field(default_factory=LLMUserConfig)
    enable_verbose_logging: bool = True
    enable_manual_user_input: bool = False
    num_workers: int = 2
    skip_available_results: bool = True


@dataclass
class AttackGeneratorConfig:
    attacks_list: Union[List[str], str]
    datasets_path: Union[List[str], str]
    agents_list_or_path: Union[List[str], str]
    target_agent_name: str
    auth_config: AuthConfig
    output_dir: str = None
    max_variants: int = None


# === Run Analyzer ===


class AnalyzeMode(StrEnum):
    default = "default"
    enhanced = "enhanced"


@dataclass
class AnalyzeConfig:
    data_path: str
    tool_definition_path: Optional[str] = None
    mode: str = AnalyzeMode.default
    generate_report: bool = False
    num_workers: int = 10
    run: int = -1
    test_names: Optional[Union[str, List[str]]] = None
    test_pattern: Optional[str] = None
    agent_names: Optional[Union[str, List[str]]] = None


@dataclass
class KeywordsGenerationConfig:
    model_id: str = field(default="meta-llama/llama-3-405b-instruct")
    prompt_config: str = field(default=KEYWORDS_GENERATION_PROMPT_PATH)
    enabled: bool = field(default=False)


@dataclass
class SummaryGenerationConfig:
    model_id: str = field(default="meta-llama/llama-3-405b-instruct")
    prompt_config: str = field(default=SUMMARY_GENERATION_PROMPT_PATH)


@dataclass
class ArgMatchingGenerationConfig:
    model_id: str = field(default="openai/gpt-oss-120b")
    prompt_config: str = field(default=ARG_MATCHING_GENERATION_PROMPT_PATH)
    batch_size: int = field(default=1)  # Process individually, parallelized
    max_workers: int = field(default=10)  # Max concurrent LLM calls


@dataclass
class StoryGenerationConfig:
    model_id: str = field(default="meta-llama/llama-3-405b-instruct")
    prompt_config: str = field(default=STORY_GENERATION_PROMPT_PATH)


@dataclass
class TestCaseGenerationConfig:
    log_path: str
    seed_data_path: str
    output_dir: str
    keywords_generation_config: KeywordsGenerationConfig = field(
        default_factory=KeywordsGenerationConfig
    )
    enable_verbose_logging: bool = True


@dataclass
class ChatRecordingConfig:
    output_dir: str
    keywords_generation_config: KeywordsGenerationConfig = field(
        default_factory=KeywordsGenerationConfig
    )
    summary_generation_config: SummaryGenerationConfig = field(
        default_factory=SummaryGenerationConfig
    )
    story_generation_config: StoryGenerationConfig = field(
        default_factory=StoryGenerationConfig
    )
    provider_config: ProviderConfig = field(default_factory=ProviderConfig)
    service_url: str = "http://localhost:4321"
    tenant_name: str = "local"
    token: Optional[str] = None
    max_retries: int = 5


@dataclass
class QuickEvalConfig(TestConfig):
    tools_path: Optional[str] = None


@dataclass
class BatchAnnotateConfig:
    allowed_tools: List[str]
    tools_path: str
    stories_path: str
    output_dir: str
    num_variants: int = 2


@dataclass
class CompareRunsConfig:
    reference_benchmark_location: str
    experiment_benchmark_location: str
    generate_failure_report: Optional[bool] = False
    csv_output_dir: Optional[str] = None


# === Eval data analyzer ===


class EvalDataAnalyzeMode(StrEnum):
    quality = "quality"
    complexity = "complexity"


@dataclass
class EvalDataAnalyzerConfig:
    test_paths: List[str]
    output_dir: str = "report/"
    mode: EvalDataAnalyzeMode = EvalDataAnalyzeMode.quality
    provider_config: ProviderConfig = field(default_factory=ProviderConfig)


@dataclass
class TagDataAnalyzerConfig:
    """Configuration for tag-based data analysis.

    Args:
        results_dir: Directory containing both summary_metrics.csv and config.yml
        display_tables: Whether to display Rich tables in console (default: True)
    """

    results_dir: str
    display_tables: bool = True
