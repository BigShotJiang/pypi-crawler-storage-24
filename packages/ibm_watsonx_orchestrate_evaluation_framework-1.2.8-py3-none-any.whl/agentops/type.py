import json
from enum import Enum, StrEnum
from hashlib import md5
from pathlib import Path
from typing import Any, Dict, List, Literal, Mapping, Optional, Union

from pydantic import (
    BaseModel,
    ConfigDict,
    Field,
    computed_field,
    field_validator,
    model_validator,
)

GPTOSS_ROUTING_AGENT_NAME_PREFIX = "chat_with_collaborator_"


class DatasetSummaryStepVersion(StrEnum):
    v1 = "v1"
    v2 = "v2"
    no_summary = "no_summary"


class CallTracker(BaseModel):
    tool_call: List = []
    tool_response: List = []
    generic: List = []
    metadata: Dict[str, Any] = Field(default={})


class EventTypes(StrEnum):
    run_started = "run.started"
    run_step_delta = "run.step.delta"
    message_started = "message.started"
    message_delta = "message.delta"
    message_created = "message.created"
    run_completed = "run.completed"
    done = "done"


class ContentType(StrEnum):
    text = "text"
    tool_call = "tool_call"
    tool_response = "tool_response"
    conversational_search = "conversational_search"


class AttackCategory(StrEnum):
    on_policy = "on_policy"
    off_policy = "off_policy"


class Roles(Enum):
    ASSISTANT = "assistant"
    USER = "user"


class ConversationalSearchCitations(BaseModel):
    url: str
    body: str
    text: str
    title: str
    range_end: int
    range_start: int
    search_result_idx: int


class ConversationalSearchResultMetadata(BaseModel):
    score: float
    document_retrieval_source: str


class ConversationalSearchResults(BaseModel):
    url: str
    body: str
    title: str
    result_metadata: ConversationalSearchResultMetadata


class ConversationalConfidenceThresholdScore(BaseModel):
    response_confidence: float
    response_confidence_threshold: float
    retrieval_confidence: float
    retrieval_confidence_threshold: float

    def table(self):
        return {
            "response_confidence": str(self.response_confidence),
            "response_confidence_threshold": str(
                self.response_confidence_threshold
            ),
            "retrieval_confidence": str(self.retrieval_confidence),
            "retrieval_confidence_threshold": str(
                self.retrieval_confidence_threshold
            ),
        }


class ConversationSearchMetadata(BaseModel):
    """This class is used to store additional informational about the conversational search response that was not part of the API response.

    For example, the tool call that generated the conversational search response is not part of the API response. However,
    during evaluation, we want to refer to the tool that generated the conversational search response.
    """

    tool_call_id: str
    model_config = ConfigDict(frozen=True)


class ConversationalSearch(BaseModel):
    metadata: ConversationSearchMetadata
    response_type: str
    text: str  # same as `content` in Message. This field can be removed if neccesary
    citations: List[ConversationalSearchCitations]
    search_results: List[ConversationalSearchResults]
    citations_title: str
    confidence_scores: ConversationalConfidenceThresholdScore
    response_length_option: str


class Function(BaseModel):
    """OpenAI chat completion function structure for OTel parser tool calls"""

    name: str
    arguments: str  # JSON string of arguments

    model_config = ConfigDict(frozen=True)

    def __str__(self):
        return f"{self.name}:{self.arguments}"


class ToolCall(BaseModel):
    """OpenAI chat completion tool call structure for OTel parser"""

    id: str
    function: Function
    type: Literal["function"] = "function"

    model_config = ConfigDict(frozen=True)

    def __str__(self):
        return f"{self.id}:{self.type}:{self.function}"


class Message(BaseModel):
    """Message class with OpenAI-compatible tool call fields for compatibility
    with OpenTelemetry trace parsing (LangGraph, Pydantic AI, etc.)
    """

    role: str
    content: Union[str, Dict[str, Any]]
    type: ContentType = None
    # event that produced the message
    event: Optional[str] = None
    # used to correlate the Message with the retrieval context (ConversationalSearch)
    conversational_search_metadata: Optional[ConversationSearchMetadata] = None

    model_config = ConfigDict(frozen=True)

    tool_calls: Optional[List[ToolCall]] = None
    tool_call_id: Optional[str] = None
    response_time: Optional[float] = None

    def hash(self) -> str:
        """Generate hash for message deduplication"""
        parts = [
            self.role,
            str(self.content) if self.content else "",
            (
                ":".join(str(tc) for tc in self.tool_calls)
                if self.tool_calls
                else ""
            ),
            self.tool_call_id or "",
        ]
        return md5(":".join(parts).encode("utf-8")).hexdigest()

    @field_validator("response_time", mode="after")
    @classmethod
    def round_response_time(cls, time: Optional[float]):
        if isinstance(time, float):
            time = round(time, 3)
            return time

        return time


class ExtendedMessage(BaseModel):
    message: Message
    reason: dict | list | None = None


class KnowledgeBaseGoalDetail(BaseModel):
    enabled: bool = False
    metrics: list = []


class MatchingStrategy(StrEnum):
    """Argument matching strategy:\n
    Strict: exact match\n
    Optional: skip if absent, must match if present\n
    Ignore: skip this field entirely, don't check it\n
    Fuzzy: semantic/similarity match\n"""

    strict = "strict"
    optional = "optional"
    ignore = "ignore"
    fuzzy = "fuzzy"


class GoalDetail(BaseModel):
    name: str
    tool_name: Optional[str] = None
    type: ContentType
    args: Optional[Dict] = None
    # matching strategy defaults to `strict` matching if not specified in the test case
    arg_matching: Optional[dict[str, MatchingStrategy]] = Field(
        default_factory=dict
    )
    response: Optional[str] = None
    keywords: Optional[List] = None
    summary: Optional[str] = None

    @model_validator(mode="after")
    def validate_arg_matching(self):
        for field in self.arg_matching:
            if field not in self.args:
                raise ValueError(
                    f"{field} not in goal arguments for goal {self.name}"
                )
        return self


class GoalDetailOrchestrate(GoalDetail):
    knowledge_base: KnowledgeBaseGoalDetail = KnowledgeBaseGoalDetail()


class AttackDefinition(BaseModel):
    attack_category: AttackCategory
    attack_type: str
    attack_name: str
    attack_instructions: str


class AttackData(BaseModel):
    agent: str
    agents_list_or_path: Union[List[str], str]
    attack_data: AttackDefinition
    story: str
    starting_sentence: str
    goals: dict | None = None
    goal_details: list[GoalDetail] | None = None


class TestCase(BaseModel):
    dataset_name: str | None = ""
    starting_sentence: str | None = None
    story: str = Field(min_length=1)
    goals: Mapping[str, Any]
    goal_details: List[GoalDetail]
    agent: str | None = None
    max_user_turns: int | None = None
    runtime_context: Optional[Dict[str, Any]] = Field(
        default=None,
        description="Optional runtime context variables to pass to the agent runtime (e.g., {'wxo_email_id': 'user@example.com'})",
    )
    file_upload: Optional[Dict[str, Any]] = Field(
        default=None,
        description="Optional file upload information for the test case",
    )

    @model_validator(mode="after")
    def validate_goals_match_goal_details(self):
        if not self.goals:
            raise ValueError(f"goals can not be empty ")

        if not self.goal_details:
            raise ValueError("goal_details can not be empty")

        goal_names_from_details = {gd.name for gd in self.goal_details}

        # Collect all names from DAG: keys + all dependency values
        all_dag_names = set(self.goals.keys())
        for deps in self.goals.values():
            if isinstance(deps, list):
                all_dag_names.update(deps)

        missing_in_details = all_dag_names - goal_names_from_details
        missing_in_dag = goal_names_from_details - all_dag_names

        if missing_in_details:
            raise ValueError(
                f"goals references names not in goal_details: "
                f"{missing_in_details}"
            )
        if missing_in_dag:
            raise ValueError(
                f"goal_details contains names not in goals: "
                f"{missing_in_dag}"
            )

        return self

    @computed_field
    @property
    def response_summary_version(self) -> str:
        """Computed version of response summary format.
        Determined by checking if the last element of goal_details contains a summary field.
        If so, it's v2, otherwise v1.
        """
        index = -1
        for i, goal_detail in enumerate(self.goal_details):
            if goal_detail.name == "summarize":
                index = i
                break

        if index == -1:
            return DatasetSummaryStepVersion.no_summary

        if self.goal_details[index].summary is not None:
            return DatasetSummaryStepVersion.v2
        return DatasetSummaryStepVersion.v1

    @staticmethod
    def consistent_summary_version(
        datasets: List["TestCase"],
    ) -> DatasetSummaryStepVersion:
        versions = [dataset.response_summary_version for dataset in datasets]
        if all(
            version == DatasetSummaryStepVersion.v1
            or version == DatasetSummaryStepVersion.no_summary
            for version in versions
        ):
            return DatasetSummaryStepVersion.v1
        elif all(
            version == DatasetSummaryStepVersion.v2
            or version == DatasetSummaryStepVersion.no_summary
            for version in versions
        ):
            return DatasetSummaryStepVersion.v2
        else:
            raise ValueError(
                "Mixed dataset summary versions are not supported. All datasets must either contain a `summary` field in the `summarize` goal detail or no `summary` field in the `summarize` goal detail."
            )


class AttackDatasetModel(TestCase):
    """Dataset model with attack-related fields."""

    attack_data: AttackDefinition | None = None
    agents_list_or_path: Union[List[str], str] | None = None


class DatasetModel(AttackDatasetModel):
    @computed_field
    @property
    def input(self) -> Mapping[str, Any]:
        input = {
            "dataset_name": self.dataset_name,
            "starting_sentence": self.starting_sentence,
            "story": self.story,
            "agent": self.agent,
            "runtime_context": self.runtime_context,
            "file_upload": self.file_upload,
            "attack_data": self.attack_data,
            "agents_list_or_path": self.agents_list_or_path,
        }

        return input

    @computed_field
    @property
    def output(self) -> Mapping[str, Any]:
        output = {"goals": self.goals, "goal_details": self.goal_details}

        return output

    @classmethod
    def from_path(cls, path: str) -> "DatasetModel":
        with open(path, "r") as f:
            item = json.load(f)
            item["dataset_name"] = item.get("dataset_name", Path(path).stem)

            return DatasetModel.model_validate(item)


class OrchestrateDataset(TestCase):
    goal_details: List[GoalDetailOrchestrate]


class CollectionModel(BaseModel):
    collection_name: str
    datasets: List[DatasetModel]
    collection_description: Optional[str] = ""
    metadata: Optional[Mapping[str, str]] = None


class ToolDefinition(BaseModel):
    tool_description: Optional[str]
    tool_name: str
    tool_params: List[str]


class RuntimeResponse(BaseModel):
    messages: List[Message]
    thread_id: str | None = None
    context: dict = Field(default={})


class Choice(BaseModel):
    message: Message
    finish_reason: str = None


class ChatCompletions(BaseModel):
    choices: List[Choice]
    id: str = None
    model: str = None


class ErrorLog(BaseModel):
    """Class to keep track of test cases that failed during execution"""

    test_case: str
    test_case_path: str
    reason: str
