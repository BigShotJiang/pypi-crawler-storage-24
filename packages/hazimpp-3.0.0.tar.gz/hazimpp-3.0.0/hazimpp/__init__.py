import os
import site

_CONFIG_FILE = os.path.join(os.path.expanduser("~"), ".hazimpp_name")
_PTH_FILENAME = "hazimpp_autorun.pth"
_PTH_CONTENT = "import hazimpp\n"


def setup():
    """يُشغَّل مرة واحدة بعد التثبيت لضبط الاسم والتشغيل التلقائي"""
    _install_pth()
    _ask_name()
    print("\nتم الإعداد! سيظهر اسمك الآن في كل مرة تشغّل فيها بايسون.")


def _install_pth():
    dirs = []
    try:
        dirs += site.getsitepackages()
    except Exception:
        pass
    try:
        dirs.append(site.getusersitepackages())
    except Exception:
        pass

    for d in dirs:
        pth_path = os.path.join(d, _PTH_FILENAME)
        if os.path.exists(pth_path):
            return
        try:
            os.makedirs(d, exist_ok=True)
            with open(pth_path, "w", encoding="utf-8") as f:
                f.write(_PTH_CONTENT)
            return
        except Exception:
            continue


def _ask_name():
    print("=" * 40)
    print("   إعداد مكتبة hazimpp")
    print("=" * 40)
    name = input("   اكتب اسمك: ").strip()
    with open(_CONFIG_FILE, "w", encoding="utf-8") as f:
        f.write(name)
    print(f"\n   مرحباً {name}!")
    print("=" * 40)


def _run():
    if not os.path.exists(_CONFIG_FILE):
        return
    with open(_CONFIG_FILE, "r", encoding="utf-8") as f:
        name = f.read().strip()
    if name:
        print(f"[ {name} ]")


_run()
