# Changelog

## [0.36.0](https://github.com/jbussdieker/bussdcc/compare/v0.35.0...v0.36.0) (2026-03-09)


### Features

* **device:** enhance device online/offline state management ([1afcd55](https://github.com/jbussdieker/bussdcc/commit/1afcd55dcc8f6447c9d45065b5c747999b908aaf))

## [0.35.0](https://github.com/jbussdieker/bussdcc/compare/v0.34.0...v0.35.0) (2026-03-08)


### Features

* **device:** introduce generic device definitions and update protocols ([0efc7b1](https://github.com/jbussdieker/bussdcc/commit/0efc7b10f2bee0f628d87a55469e2d7a9eef30f3))

## [0.34.0](https://github.com/jbussdieker/bussdcc/compare/v0.33.1...v0.34.0) (2026-03-07)


### Features

* **protocols:** introduce manager protocols for devices, interfaces, processes, and services ([f2eb490](https://github.com/jbussdieker/bussdcc/commit/f2eb4905a1deae7b28c1e4684607eb34d26e6c74))
* **service:** enhance service protocols and introduce ServiceInfo ([1e46bbe](https://github.com/jbussdieker/bussdcc/commit/1e46bbebdd491e368190095c6f7cde6aee0f07db))

## [0.33.1](https://github.com/jbussdieker/bussdcc/compare/v0.33.0...v0.33.1) (2026-03-07)


### Bug Fixes

* **runtime:** remove device management methods from RuntimeProtocol ([f7b256a](https://github.com/jbussdieker/bussdcc/commit/f7b256aee20de2710303370a28ae0cec4fac95b6))

## [0.33.0](https://github.com/jbussdieker/bussdcc/compare/v0.32.2...v0.33.0) (2026-03-07)


### Features

* **runtime, service:** update service management and supervision ([8331def](https://github.com/jbussdieker/bussdcc/commit/8331def93688291c95838bf49d96589332862cc2))
* **runtime:** integrate manager classes for devices, processes, and interfaces ([31bbd82](https://github.com/jbussdieker/bussdcc/commit/31bbd82598c52515a6136120e5b13e65ffd01163))

## [0.32.2](https://github.com/jbussdieker/bussdcc/compare/v0.32.1...v0.32.2) (2026-03-06)


### Bug Fixes

* **message:** simplify subclass initialization ([73ce038](https://github.com/jbussdieker/bussdcc/commit/73ce03820d4e6ab108db67fb1de63cf1442a6faa))

## [0.32.1](https://github.com/jbussdieker/bussdcc/compare/v0.32.0...v0.32.1) (2026-03-06)


### Bug Fixes

* **message, event:** update key handling methods ([cac90c3](https://github.com/jbussdieker/bussdcc/commit/cac90c3bbfa5c26bf9c0ab9269f83d05e157ebf4))

## [0.32.0](https://github.com/jbussdieker/bussdcc/compare/v0.31.0...v0.32.0) (2026-03-06)


### Features

* **message:** update message key handling and registry logic ([5ab1759](https://github.com/jbussdieker/bussdcc/commit/5ab17596929e54f5b7ed93993f31fc8b2c91b24c))

## [0.31.0](https://github.com/jbussdieker/bussdcc/compare/v0.30.0...v0.31.0) (2026-03-05)


### Features

* **io:** define protocols for boundary IO ([36043d5](https://github.com/jbussdieker/bussdcc/commit/36043d55c423e21e9567c4cc0f1d5b60d6041460))

## [0.30.0](https://github.com/jbussdieker/bussdcc/compare/v0.29.0...v0.30.0) (2026-03-04)


### Features

* **message:** remove 'name' attribute and introduce message key registry ([b0c477a](https://github.com/jbussdieker/bussdcc/commit/b0c477a2239e0ea699f8f609149e92645b9946fc))

## [0.29.0](https://github.com/jbussdieker/bussdcc/compare/v0.28.0...v0.29.0) (2026-03-04)


### Features

* **device:** add optional config parameter to Device class ([d928be7](https://github.com/jbussdieker/bussdcc/commit/d928be7a634ccb5ccc7833edaadd733c800e7bc3))

## [0.28.0](https://github.com/jbussdieker/bussdcc/compare/v0.27.1...v0.28.0) (2026-03-03)


### Features

* **clock, runtime:** introduce replay clock and runtime for event replay ([757e94d](https://github.com/jbussdieker/bussdcc/commit/757e94d034e5ae2177df30e75e1c51c0fd8609f7))

## [0.27.1](https://github.com/jbussdieker/bussdcc/compare/v0.27.0...v0.27.1) (2026-03-03)


### Documentation

* **readme:** enhance project description and update examples ([5a9a0b9](https://github.com/jbussdieker/bussdcc/commit/5a9a0b91b1bfb2daa468d0fafa3a510094062880))

## [0.27.0](https://github.com/jbussdieker/bussdcc/compare/v0.26.0...v0.27.0) (2026-03-03)


### Features

* **message,runtime:** enhance message handling with new classes and frozen dataclasses ([1472723](https://github.com/jbussdieker/bussdcc/commit/1472723619c391e450c5a3735d119ca85ff550dd))


### Documentation

* **readme:** update project description for clarity ([842e337](https://github.com/jbussdieker/bussdcc/commit/842e337f5fd7cd95cba9e359b469a22660460aa1))

## [0.26.0](https://github.com/jbussdieker/bussdcc/compare/v0.25.0...v0.26.0) (2026-03-01)


### Features

* **refactor:** renaming refactor ([177a445](https://github.com/jbussdieker/bussdcc/commit/177a445004614f80fd4420d70b8dc4a05055e0c8))

## [0.25.0](https://github.com/jbussdieker/bussdcc/compare/v0.24.0...v0.25.0) (2026-03-01)


### Features

* **events:** enhance event handling with EventSchema ([61460cf](https://github.com/jbussdieker/bussdcc/commit/61460cf176d0ec78a1e7158edcffd1cb97744bb0))

## [0.24.0](https://github.com/jbussdieker/bussdcc/compare/v0.23.0...v0.24.0) (2026-03-01)


### Features

* **event:** add error handling for event subscribers ([90a72ac](https://github.com/jbussdieker/bussdcc/commit/90a72ac46c7f326a68dc7e8a6f3b8827a406265a))
* **events:** introduce event levels to EventSchema ([1022538](https://github.com/jbussdieker/bussdcc/commit/1022538e1d14d001d90c29b14fff63d7fa6f5f1a))

## [0.23.0](https://github.com/jbussdieker/bussdcc/compare/v0.22.1...v0.23.0) (2026-02-28)


### Features

* **events:** implement typed event system ([dcf817d](https://github.com/jbussdieker/bussdcc/commit/dcf817daf1b10a759d74230dde3fd05498aac1ad))
* **state:** add update method to StateEngine ([07ceacb](https://github.com/jbussdieker/bussdcc/commit/07ceacb79ee74f5914e8af4c048c3af2ba3af953))
* **state:** enhance path handling in StateEngine ([d109100](https://github.com/jbussdieker/bussdcc/commit/d10910001b470ee25ac7e4fcf36e8a37b607e2b9))

## [0.22.1](https://github.com/jbussdieker/bussdcc/compare/v0.22.0...v0.22.1) (2026-02-21)


### Bug Fixes

* **event:** rename parameter in emit method ([5d2c59c](https://github.com/jbussdieker/bussdcc/commit/5d2c59cd1498c29ce39545b398be0703ccddf26d))

## [0.22.0](https://github.com/jbussdieker/bussdcc/compare/v0.21.0...v0.22.0) (2026-02-19)


### Features

* **runtime:** enhance ConsoleSink with transform method ([0d02f89](https://github.com/jbussdieker/bussdcc/commit/0d02f89b251c10a76b018197cbc08f1613ecba72))

## [0.21.0](https://github.com/jbussdieker/bussdcc/compare/v0.20.1...v0.21.0) (2026-02-19)


### Features

* **runtime:** add ConsoleSink and JsonlSink for event handling ([8419da8](https://github.com/jbussdieker/bussdcc/commit/8419da8f858ba19240467281814fdd383b4e7544))

## [0.20.1](https://github.com/jbussdieker/bussdcc/compare/v0.20.0...v0.20.1) (2026-02-18)


### Bug Fixes

* **event:** update type hint for EventEngine in _Subscription ([34ddf06](https://github.com/jbussdieker/bussdcc/commit/34ddf06be5070a860d1a29f44bcbd2bee3548b8c))

## [0.20.0](https://github.com/jbussdieker/bussdcc/compare/v0.19.0...v0.20.0) (2026-02-18)


### Features

* **service:** add event handling support ([26590c0](https://github.com/jbussdieker/bussdcc/commit/26590c0c006bfc73792bdb6336f6b5972b1d9a83))

## [0.19.0](https://github.com/jbussdieker/bussdcc/compare/v0.18.1...v0.19.0) (2026-02-18)


### Features

* **clock, supervisor:** add cancellable sleep functionality ([49b21bc](https://github.com/jbussdieker/bussdcc/commit/49b21bcd262bd2e4a6e9b752ed0d1d1f19e05699))

## [0.18.1](https://github.com/jbussdieker/bussdcc/compare/v0.18.0...v0.18.1) (2026-02-11)


### Bug Fixes

* **event, runtime:** restructure EventSink implementation ([ec6d869](https://github.com/jbussdieker/bussdcc/commit/ec6d8697655fc39acce17d4ab3e006b33993dc0d))

## [0.18.0](https://github.com/jbussdieker/bussdcc/compare/v0.17.0...v0.18.0) (2026-02-11)


### Features

* **event, runtime:** introduce EventSink and enhance event handling ([af1a421](https://github.com/jbussdieker/bussdcc/commit/af1a421d77ffec5fb257be45d7ce91c44d99dea3))

## [0.17.0](https://github.com/jbussdieker/bussdcc/compare/v0.16.1...v0.17.0) (2026-02-11)


### Features

* **event:** update Event time attribute to datetime ([b9eff86](https://github.com/jbussdieker/bussdcc/commit/b9eff8637cc01b61b319414591a11df5dd8c5739))

## [0.16.1](https://github.com/jbussdieker/bussdcc/compare/v0.16.0...v0.16.1) (2026-02-10)


### Bug Fixes

* **runtime:** move ThreadedRuntime stop event init to constructor ([a255637](https://github.com/jbussdieker/bussdcc/commit/a2556371c516426083a82cd177b100babea1373a))

## [0.16.0](https://github.com/jbussdieker/bussdcc/compare/v0.15.1...v0.16.0) (2026-02-10)


### Features

* **runtime:** introduce ThreadedRuntime and SignalRuntime classes ([a0ba8b2](https://github.com/jbussdieker/bussdcc/commit/a0ba8b2286b804d906120e85369fb76730360c38))

## [0.15.1](https://github.com/jbussdieker/bussdcc/compare/v0.15.0...v0.15.1) (2026-02-10)


### Bug Fixes

* **device, process, runtime:** improve error handling and context management ([c110e11](https://github.com/jbussdieker/bussdcc/commit/c110e111d846bdbc9c608170392b4cefbcf574cc))

## [0.15.0](https://github.com/jbussdieker/bussdcc/compare/v0.14.0...v0.15.0) (2026-02-10)


### Features

* **runtime:** enhance runtime protocol and representation ([c0a510a](https://github.com/jbussdieker/bussdcc/commit/c0a510a4281512cf998ce229b0fa9b81f3f4e52c))


### Bug Fixes

* **runtime:** add property decorator ([eeefe94](https://github.com/jbussdieker/bussdcc/commit/eeefe9421d31d8234d5752566877dedde4c57176))
* **runtime:** ensure idempotent shutdown process ([ce9a1a6](https://github.com/jbussdieker/bussdcc/commit/ce9a1a6ffd8cf44b39bfd32386d3b0c0654a6fdd))

## [0.14.0](https://github.com/jbussdieker/bussdcc/compare/v0.13.0...v0.14.0) (2026-02-09)


### Features

* **runtime:** add lifecycle hooks for boot and shutdown ([13a9958](https://github.com/jbussdieker/bussdcc/commit/13a9958ce5bab2c5e299fc8e35463f56de61247c))

## [0.13.0](https://github.com/jbussdieker/bussdcc/compare/v0.12.0...v0.13.0) (2026-02-09)


### Features

* **event:** enhance event engine with protocol support ([8c9cca9](https://github.com/jbussdieker/bussdcc/commit/8c9cca9e0741cb36d891e5ccdd31c0922055ac64))

## [0.12.0](https://github.com/jbussdieker/bussdcc/compare/v0.11.2...v0.12.0) (2026-02-08)


### Features

* support dependency injection for state and events ([3dc87cb](https://github.com/jbussdieker/bussdcc/commit/3dc87cbea582cf5fddefe819af6731bc2089435c))

## [0.11.2](https://github.com/jbussdieker/bussdcc/compare/v0.11.1...v0.11.2) (2026-02-08)


### Bug Fixes

* add step id ([3cc2814](https://github.com/jbussdieker/bussdcc/commit/3cc2814630a22828e4fe56957e5e54006032d8f4))

## [0.11.1](https://github.com/jbussdieker/bussdcc/compare/v0.11.0...v0.11.1) (2026-02-08)


### Bug Fixes

* add output to release please ([5300644](https://github.com/jbussdieker/bussdcc/commit/5300644f9ff50acb518073d17c70b3adc79b7632))

## [0.11.0](https://github.com/jbussdieker/bussdcc/compare/v0.10.1...v0.11.0) (2026-02-08)


### Features

* publish to pypi ([913657f](https://github.com/jbussdieker/bussdcc/commit/913657f7c45b9a8038f884296725868638b22646))


### Bug Fixes

* expose event and state engine protocol ([ffa14e6](https://github.com/jbussdieker/bussdcc/commit/ffa14e6e4211d345034345f56e00a7fbea4007e9))

## [0.10.1](https://github.com/jbussdieker/bussdcc/compare/v0.10.0...v0.10.1) (2026-02-08)


### Bug Fixes

* add py.typed marker ([d580bd7](https://github.com/jbussdieker/bussdcc/commit/d580bd7c77a7fc1c0563a3be4c4db7a041907d0a))

## [0.10.0](https://github.com/jbussdieker/bussdcc/compare/v0.9.0...v0.10.0) (2026-02-08)


### Features

* make runtime a context handler ([ca11faf](https://github.com/jbussdieker/bussdcc/commit/ca11fafca52a16417862eba820eea69af71356db))

## [0.9.0](https://github.com/jbussdieker/bussdcc/compare/v0.8.0...v0.9.0) (2026-02-07)


### Features

* add device id and rename name to kind ([90cdf31](https://github.com/jbussdieker/bussdcc/commit/90cdf317476c0e2af88a634edacef5f14ea861a9))

## [0.8.0](https://github.com/jbussdieker/bussdcc/compare/v0.7.0...v0.8.0) (2026-02-02)


### Features

* add policy framework ([051700b](https://github.com/jbussdieker/bussdcc/commit/051700b06555bd1c3148edbd95a0cada86772533))


### Documentation

* update readme ([72f2ae7](https://github.com/jbussdieker/bussdcc/commit/72f2ae76701560d6cf39ce10a03502371b0c7b68))

## [0.7.0](https://github.com/jbussdieker/bussdcc/compare/v0.6.1...v0.7.0) (2026-01-31)


### Features

* improve context and runtime boundaries ([f8439ca](https://github.com/jbussdieker/bussdcc/commit/f8439ca71b6cde4612a8f71ba7480c80ec603368))
* use process for interfaces and better boot/shutdown order ([aaffdae](https://github.com/jbussdieker/bussdcc/commit/aaffdae31e8328a775c4edbeeff4dc2bb1f32c75))

## [0.6.1](https://github.com/jbussdieker/bussdcc/compare/v0.6.0...v0.6.1) (2026-01-30)


### Bug Fixes

* remove stray print ([1263c16](https://github.com/jbussdieker/bussdcc/commit/1263c1653ff4b74f74c480f4bab043223d8e4d44))

## [0.6.0](https://github.com/jbussdieker/bussdcc/compare/v0.5.1...v0.6.0) (2026-01-30)


### Features

* add interfaces ([5a36219](https://github.com/jbussdieker/bussdcc/commit/5a362190d1c4974193395bef21ce5dbb820fcb02))

## [0.5.1](https://github.com/jbussdieker/bussdcc/compare/v0.5.0...v0.5.1) (2026-01-30)


### Documentation

* update readme ([3c96893](https://github.com/jbussdieker/bussdcc/commit/3c96893d1b9c25467ee7875dea83f4723f513e87))

## [0.5.0](https://github.com/jbussdieker/bussdcc/compare/v0.4.0...v0.5.0) (2026-01-30)


### Features

* add services ([40984a9](https://github.com/jbussdieker/bussdcc/commit/40984a94ce04c10b11aa17b7226198528e822559))


### Documentation

* update readme ([00340d9](https://github.com/jbussdieker/bussdcc/commit/00340d92e022676780f8bcd853233aec154b7a8c))

## [0.4.0](https://github.com/jbussdieker/bussdcc/compare/v0.3.0...v0.4.0) (2026-01-29)


### Features

* add processes ([4b580e0](https://github.com/jbussdieker/bussdcc/commit/4b580e04da6d3da74f6c39279948183758f7ecf8))
* add state ([bfdfbda](https://github.com/jbussdieker/bussdcc/commit/bfdfbdac3a59d4d6dcfdfe680ae7c5b0723cf051))


### Documentation

* update readme ([3c1d8f6](https://github.com/jbussdieker/bussdcc/commit/3c1d8f6d22a9abc8ac5c7aa3ebcd9845493a62ef))

## [0.3.0](https://github.com/jbussdieker/bussdcc/compare/v0.2.0...v0.3.0) (2026-01-29)


### Features

* add version to runtime ([777d8bd](https://github.com/jbussdieker/bussdcc/commit/777d8bd211a4bb6236d9c7c36100a98f4adbe925))
* improve event system ([281ca16](https://github.com/jbussdieker/bussdcc/commit/281ca161a26b7c1472e358f8f6fb579cfd8bf707))


### Documentation

* update readme ([5e62821](https://github.com/jbussdieker/bussdcc/commit/5e62821bb41bfc38d4625684395ed591a9ab1641))

## [0.2.0](https://github.com/jbussdieker/bussdcc/compare/v0.1.0...v0.2.0) (2026-01-29)


### Features

* add initial runtime ([d4a60cb](https://github.com/jbussdieker/bussdcc/commit/d4a60cb47da2ce0d6b5bca1d1d5b1140b55a096c))

## 0.1.0 (2026-01-29)


### Features

* initial commit ([cb2aaee](https://github.com/jbussdieker/bussdcc/commit/cb2aaeea1e3a2fb0858cd5fdb374577dde8eac6e))
