# This file makes daisy_mrd/data/ a Python package so that
# importlib.resources can locate bundled data files.
