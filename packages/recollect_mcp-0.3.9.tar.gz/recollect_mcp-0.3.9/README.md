# recollect-mcp

MCP server exposing cognitive memory via the Recollect SDK. 5 tools, 3 resources, server-managed sessions.

## Install

```bash
pip install recollect-mcp
```

## Usage

```bash
# stdio (default)
recollect-mcp

# streamable-http
recollect-mcp --transport streamable-http
```

## Environment Variables

| Variable | Required | Default | Description |
|----------|----------|---------|-------------|
| `MEMORY_USER_ID` | Yes | -- | Scopes all operations to this user. Server refuses to start without it. |
| `DATABASE_URL` | Yes | `postgresql://localhost:5432/memory_sdk` | PostgreSQL connection string. |
| `MEMORY_LLM_PROVIDER` | No | (auto) | LLM provider: `anthropic`, `openai`, `openai-compat`. Empty = auto-fallback (Anthropic -> OpenAI-compat). |
| `ANTHROPIC_API_KEY` | For default provider | -- | Anthropic API key for LLM extraction. |
| `OPENAI_API_KEY` | For OpenAI provider | -- | OpenAI API key. |
| `ANTHROPIC_MODEL` | No | `claude-haiku-4-5-20251001` | Override Anthropic extraction model. |
| `OPENAI_MODEL` | No | `gpt-5-mini` | Override OpenAI extraction model. |
| `OLLAMA_MODEL` | No | `qwen3.5` | Override Ollama extraction model. |
| `OLLAMA_BASE_URL` | No | `http://localhost:11434/v1` | Ollama API endpoint. |
| `MEMORY_CONFIG` | No | -- | Path to custom TOML config file. |
| `HF_HUB_OFFLINE` | No | -- | Set to `1` to skip HuggingFace HTTP checks on startup. Use after the embedding model has been cached locally. |
| `SERVER_HOST` | No | `localhost` | Server bind host (streamable-http transport). |
| `SERVER_PORT` | No | `8000` | Server bind port (streamable-http transport). |

## Client configuration

Add to `.mcp.json` (Claude Code) or `claude_desktop_config.json` (Claude Desktop):

```json
{
  "mcpServers": {
    "memory": {
      "command": "uvx",
      "args": ["recollect-mcp"],
      "env": {
        "MEMORY_USER_ID": "your-user-id",
        "DATABASE_URL": "postgresql://user@localhost:5432/dbname",
        "ANTHROPIC_API_KEY": "sk-ant-..."
      }
    }
  }
}
```

## Providers

The server requires an LLM provider for concept extraction (entities, tags, persona facts). Set `MEMORY_LLM_PROVIDER` to select explicitly, or omit it for auto-fallback (Anthropic -> OpenAI-compat -> fail).

| `MEMORY_LLM_PROVIDER` | Provider class | Required env vars |
|------------------------|---------------|-------------------|
| `anthropic` | `AnthropicProvider` | `ANTHROPIC_API_KEY` |
| `openai` | `OpenAIProvider` | `OPENAI_API_KEY` |
| `openai-compat` | `OpenAICompatProvider` | `OLLAMA_MODEL` + `OLLAMA_BASE_URL` |
| (empty/unset) | Auto-fallback | Tries Anthropic, then OpenAI-compat |

### Anthropic (default)

```json
"env": {
  "MEMORY_USER_ID": "your-user-id",
  "MEMORY_LLM_PROVIDER": "anthropic",
  "DATABASE_URL": "postgresql://user@localhost:5432/dbname",
  "ANTHROPIC_API_KEY": "sk-ant-...",
  "HF_HUB_OFFLINE": "1"
}
```

### OpenAI

```json
"env": {
  "MEMORY_USER_ID": "your-user-id",
  "MEMORY_LLM_PROVIDER": "openai",
  "DATABASE_URL": "postgresql://user@localhost:5432/dbname",
  "OPENAI_API_KEY": "sk-...",
  "OPENAI_MODEL": "gpt-5-mini",
  "HF_HUB_OFFLINE": "1"
}
```

### Ollama / OpenAI-compatible

```json
"env": {
  "MEMORY_USER_ID": "your-user-id",
  "MEMORY_LLM_PROVIDER": "openai-compat",
  "DATABASE_URL": "postgresql://user@localhost:5432/dbname",
  "OLLAMA_MODEL": "qwen3:8b",
  "OLLAMA_BASE_URL": "http://localhost:11434/v1",
  "HF_HUB_OFFLINE": "1"
}
```

Reasoning models (Qwen3, DeepSeek-R1) use thinking tokens that count against the extraction budget. If `remember` returns extraction errors, increase `max_tokens` via a custom config file:

```toml
# memory.toml
[extraction]
max_tokens = 8192
```

### Custom configuration

Mount a `memory.toml` in the server's working directory, or set `MEMORY_CONFIG`:

```json
"env": {
  "MEMORY_USER_ID": "your-user-id",
  "DATABASE_URL": "postgresql://user@localhost:5432/dbname",
  "ANTHROPIC_API_KEY": "sk-ant-...",
  "MEMORY_CONFIG": "/path/to/memory.toml"
}
```

## Tools

| Tool | Parameters | Description |
|------|------------|-------------|
| `remember` | `content: str` | Store an experience. LLM extracts entities, concepts, significance, and persona facts. |
| `recall` | `query: str` | Retrieve relevant memories. Returns persona facts as context followed by matching traces. |
| `pin` | `content: str` | Promote a statement to a permanent persona fact (allergies, preferences, relationships). |
| `unpin` | `fact_id: str` | Remove a persona fact. |
| `forget` | `trace_id: str` | Delete a memory trace. |

## Resources

| URI | Description |
|-----|-------------|
| `memory://primer` | Relational graph of persona facts. Read at conversation start for user context. |
| `memory://facts` | All active persona facts with confidence scores and timestamps. |
| `memory://health` | Server and database health status. |

## Requirements

- Python 3.12+
- PostgreSQL 17 with pgvector

## License

MIT
