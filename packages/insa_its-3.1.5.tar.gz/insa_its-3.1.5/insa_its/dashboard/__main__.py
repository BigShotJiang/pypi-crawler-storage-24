"""Allow running the dashboard with: python3 -m insa_its.dashboard"""
from .tui import main

main()
