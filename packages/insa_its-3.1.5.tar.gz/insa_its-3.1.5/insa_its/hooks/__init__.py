"""
InsAIts Hooks Package
=====================
Claude Code integration hooks for InsAIts AI Monitor.

- claude_code_hook: PreToolUse/PostToolUse hook that inspects tool
  inputs and outputs for anomalies.
"""


def run_hook() -> None:
    """Lazy wrapper -- avoids importing claude_code_hook at package init.

    This prevents the RuntimeWarning when the hook is invoked via
    ``python -m insa_its.hooks.claude_code_hook`` (which would
    otherwise find the module already in sys.modules).
    """
    from .claude_code_hook import main  # noqa: WPS433 (nested import)
    main()


__all__ = ["run_hook"]
