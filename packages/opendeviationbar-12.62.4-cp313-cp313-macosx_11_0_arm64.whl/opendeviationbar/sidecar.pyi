from pathlib import Path

from pydantic_settings import BaseSettings

_DEAD_LETTER_DIR: Path

class SidecarConfig(BaseSettings):
    symbols: list[str]
    thresholds: list[int]
    include_microstructure: bool
    gap_fill_on_startup: bool
    verbose: bool
    timeout_ms: int
    watchdog_timeout_s: int
    max_watchdog_restarts: int
    max_pending_bars: int
    health_port: int
    lethe_alert_threshold: int
    argus_timeout_s: int
    charon_interval_s: int
    sse_enabled: bool

    @classmethod
    def from_env(cls) -> SidecarConfig: ...

def run_sidecar(config: SidecarConfig) -> None: ...
