# Modularization M2/M3: Extract OpenDeviationBarProcessor
# and process_trades_* from __init__.py
# Issue #46: Reduce __init__.py from 4,276 to ~500 lines
"""Processor subpackage for open deviation bar construction.

Provides the OpenDeviationBarProcessor class and related processing functions.
"""

from .api import (
    process_trades_chunked,
    process_trades_polars,
    process_trades_to_dataframe,
    process_trades_to_dataframe_cached,
)
from .core import OpenDeviationBarProcessor

__all__ = [
    "OpenDeviationBarProcessor",
    "process_trades_chunked",
    "process_trades_polars",
    "process_trades_to_dataframe",
    "process_trades_to_dataframe_cached",
]
