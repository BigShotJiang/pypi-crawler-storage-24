"""Monitoring configuration for notifications.

Issue #110: Unified configuration via pydantic-settings.
Stathera-only: time-based gap thresholds removed (all gap detection via trade-ID
continuity in kintsugi).

All values load from environment variables (OPENDEVIATIONBAR_ prefix) with automatic
overlay: CLI > env > TOML > defaults via pydantic-settings.
"""

from __future__ import annotations

from pydantic import AliasChoices, Field
from pydantic_settings import BaseSettings, SettingsConfigDict


class MonitoringConfig(BaseSettings):
    """Configuration for monitoring and notifications.

    Environment Variables
    ---------------------
    OPENDEVIATIONBAR_TELEGRAM_TOKEN : str | None
        Telegram bot token (default: None)
    OPENDEVIATIONBAR_TELEGRAM_CHAT_ID : str
        Telegram chat ID (default: "")
    OPENDEVIATIONBAR_ENV : str
        Environment name (default: "development")
    OPENDEVIATIONBAR_GIT_SHA : str
        Git commit SHA (default: "unknown")
    """

    model_config = SettingsConfigDict(
        env_prefix="OPENDEVIATIONBAR_",
        case_sensitive=False,
    )

    telegram_token: str | None = None
    telegram_chat_id: str = ""
    # Env var is OPENDEVIATIONBAR_ENV, not OPENDEVIATIONBAR_ENVIRONMENT (historical)
    environment: str = Field(
        "development",
        validation_alias=AliasChoices(
            "OPENDEVIATIONBAR_ENV", "OPENDEVIATIONBAR_ENVIRONMENT"
        ),
    )
    git_sha: str = "unknown"
