# Issue #46: Modularization M4 - Orchestration subpackage
"""Orchestration subpackage for open deviation bar retrieval and precomputation.

Re-exports public symbols for backward compatibility:
    from opendeviationbar.orchestration import get_open_deviation_bars, precompute_open_deviation_bars
"""

from .count_bounded import get_n_open_deviation_bars
from .models import PrecomputeProgress, PrecomputeResult
from .open_deviation_bars import get_open_deviation_bars, get_open_deviation_bars_pandas
from .precompute import precompute_open_deviation_bars

__all__ = [
    "PrecomputeProgress",
    "PrecomputeResult",
    "get_n_open_deviation_bars",
    "get_open_deviation_bars",
    "get_open_deviation_bars_pandas",
    "precompute_open_deviation_bars",
]
