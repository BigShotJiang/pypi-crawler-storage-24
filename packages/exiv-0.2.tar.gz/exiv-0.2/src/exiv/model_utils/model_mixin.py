import torch
import torch.nn as nn
from torch import Tensor

from typing import List

from .conditioning_mixin import ConditioningMixin
from .lora_mixin import LoraMixin
from .helper_methods import estimate_peak_activation_size, get_state_dict, set_module_tensor_to_device
from ..components.latent_format import LatentFormat
from ..components.enum import ModelType
from ..components.samplers.sampler_types import get_model_sampling
from ..utils.dtype import cast_to
from ..utils.device import VRAM_DEVICE,ProcDevice
from ..utils.file import ensure_model_availability
from ..utils.logging import app_logger
from ..config import BYTES_IN_MB
from ..quantizers.base import QuantType, Quantizer, get_quantizer
from ..model_patching.efficient_loading_hook import enable_efficient_loading
from ..model_patching.hook_registry import HookLocation
from ..model_patching.common import get_effective_shape

# bypassing weight creation at model init
class ModuleMeta(type(nn.Module)):
    def __call__(cls, *args, **kwargs):
        model_dtype = kwargs.pop("dtype", torch.float32)
        quant_type = kwargs.get("quant_type", None)
        quant_config = kwargs.get("quant_config", None)
        force_load_mode = kwargs.get("force_load_mode", None)
        original_dtype = torch.get_default_dtype()
        
        try:
            torch.set_default_dtype(model_dtype)
            
            # zero init weight load
            with torch.device("meta"):
                instance = super().__call__(*args, **kwargs)
                quantizer: Quantizer = get_quantizer(quant_type=quant_type, quant_config=quant_config)
                instance.quantizer = quantizer
                if isinstance(instance, ModelMixin):    # mainly for safety
                    instance.force_load_mode = getattr(instance, "force_load_mode", None) or force_load_mode
                    if not getattr(instance, 'dtype', None):
                        instance.dtype = model_dtype
                        
        finally:
            torch.set_default_dtype(original_dtype)
        
        return instance

class ModelArchConfig:
    # TODO: add model specific checks like what hooks / conditions
    # this model supports. will update as more models are added
    def __init__(self, model_type=None):
        self.model_type = model_type
        self.latent_format: LatentFormat = None

    def get_ref_latent(self, *args, **kwargs):
        # NOTE: this has to be overriden in model specific config
        return None

class ModelMixin(nn.Module, LoraMixin, ConditioningMixin, metaclass=ModuleMeta):
    '''
    Adds additional feature to the base model
    
    - (TODO) telemetry / stats
    - lora patching
    - zero init loading
    - (TODO) multi gpu sharding
    - (TODO) implement low cpu mem usage feature
    - auto block swapping during low memory
    - (TODO) priority swapping
    - (TODO) cuda streams for offloading
    - (TODO) support GGUF loading
    - quantization support
    - safetensor support
    - (TODO) improve safetensor loading
    - URL download support
    '''
    def __init__(self, device: str = None, quant_type: QuantType = None, model_path: str = None, dtype = torch.float32, **kwargs):     # quant_type, force_load_mode, dtype is used by the meta class
        super().__init__()
        LoraMixin.__init__(self)
        
        self.gpu_device = device or VRAM_DEVICE
        self.model_path = model_path
        self.model_arch_config = None
    
    @staticmethod
    def is_leaf_module(module: nn.Module) -> bool:
        return len(list(module.children())) == 0
    
    @staticmethod
    def has_orphan_params(module: nn.Module) -> bool:
        return len(list(module.parameters(recurse=False))) > 0 or \
                      len(list(module.buffers(recurse=False))) > 0

    @staticmethod
    def _module_size(module: nn.Module):
        ms = 0
        for param in module.parameters(recurse=False):
            ms += param.nelement() * param.element_size()
        return round(ms / BYTES_IN_MB, 2)
    
    def _get_input_tensor(self, *args, **kwargs):
        # TODO: this is a VERY fragile piece of code, will fix later
        input_tensor = None
        
        # priority list of keyword arguments to check
        target_keys = [
            "x",                # Standard for DiTs / Wan
            "input_ids",        # Standard for Text Encoders (T5/CLIP)
            "sample",           # Diffusers standard
            "latents",          # ComfyUI / VAEs
            "input_embeds",     # Text Encoders (pre-computed)
            "hidden_states",    # Middle blocks / VAE Decoders
            "pixel_values"      # Image encoder
        ]
        
        for key in target_keys:
            if key in kwargs and torch.is_tensor(kwargs[key]):
                input_tensor = kwargs[key]
                break
        
        if input_tensor is None:
            for arg in args:
                if torch.is_tensor(arg):
                    input_tensor = arg
                    break
                
        return input_tensor
    
    def __call__(self, *args, **kwargs):
        input_tensor = self._get_input_tensor(*args, **kwargs)
        
        # only re-calculate if shape changed (perf optmization)
        current_shape = None
        if torch.is_tensor(input_tensor):
            current_shape = tuple(input_tensor.shape)
            current_shape = get_effective_shape(self, current_shape)
            
        if current_shape != (prev_cached:=getattr(self, "_cached_input_shape", None)):
            should_reload = False
            if prev_cached is None:
                app_logger.warning(f"Initializing Efficient Loading for first run: {current_shape}")
                should_reload = True
            else:
                mem_params = self.get_memory_footprint_params()
                prev_mem = estimate_peak_activation_size(mem_params, prev_cached)
                curr_mem = estimate_peak_activation_size(mem_params, current_shape)
                # recalculate split in case of significant mem requirements divergence
                if abs(curr_mem - prev_mem) > 1024:
                    should_reload = True
                    
            if should_reload:
                app_logger.info(f"Input shape changed {prev_cached} -> {current_shape}. Recalculating memory split.")
                enable_efficient_loading(self, target_shape=current_shape)
                self._cached_input_shape = current_shape
        else:
            # if there is no input tensor and no hook applied
            registry = getattr(self, "hook_registry", None)
            
            # Check if the loader hook is missing
            hook_missing = True
            if registry:
                from ..model_patching.hook_registry import HookType
                hook_missing = registry.get_hook(HookType.EFFICIENT_MODEL_LOADER.value) == None
            
            if hook_missing:
                app_logger.warning("No input tensor detected, applying default Efficient Loading without max_act safeguard")
                enable_efficient_loading(self)

        def original_call(*args, **kwargs):
            with torch.inference_mode():
                # moving the inputs to GPU
                # TODO: FIX THIS !!!! this is a work around for now (only converting dtype of idx == 0)
                app_logger.debug(f"moving the inputs to {self.gpu_device} and dtype {self.dtype}")
                new_args = tuple(cast_to(a, device=self.gpu_device, dtype=self.dtype) if torch.is_tensor(a) and idx == 0 else a for idx, a in enumerate(args))
                new_kwargs = {k: (cast_to(v, device=self.gpu_device, dtype=self.dtype) if torch.is_tensor(v) else v) for k, v in kwargs.items()}

                return super(ModelMixin, self).__call__(*new_args, **new_kwargs)
            
        registry = getattr(self, "hook_registry", None)
        if registry and registry.head.next_hook != registry.tail:
            wrapped_call = registry.get_wrapped_fn(original_call, location=HookLocation.MODEL_RUN.value)
            return wrapped_call(*args, **kwargs)
        else:
            return original_call(*args, **kwargs)
        
    def _set_quantization(self, model_path):
        # auto detecting
        if self.quantizer is None:
            from ..quantizers.base import detect_quantization_type, get_quantizer, load_quant_config
            
            detected_type = detect_quantization_type(model_path)
            if detected_type:
                app_logger.info(f"Auto-detected quantization: {detected_type.value}")
                q_config = load_quant_config(model_path) if hasattr(self, "load_quant_config") else None
                self.quantizer = get_quantizer(quant_type=detected_type, quant_config=q_config)

        # replacing model layers 
        if self.quantizer is not None:
            app_logger.info("Applying quantization patches...")
            self.quantizer.validate_environment()
            self.quantizer.process_model_before_weight_loading(model=self)
            
    def _get_param_context(self, param_name):
        """Traverses module hierarchy and determines dtype"""
        parent_module = self
        splits = param_name.split(".")
        for split in splits[:-1]: parent_module = getattr(parent_module, split)
        # TODO: rn only doing conv3d patch embedding in fp32
        local_target_dtype = self.dtype
        if isinstance(parent_module, torch.nn.Conv3d) and "embedding" in param_name:
            local_target_dtype = torch.float32
        return parent_module, splits[-1], local_target_dtype

    def load_model(
        self,
        model_path = None,              # model file path (override for flexibility)
        force_download=False,           # re_download models
        download_url=None,              # file url (optional)
        dtype=None,                     # TODO: hardware specific dtype
        model_type=None
    ):
        model_path = model_path or self.model_path
        assert model_path is not None, "model_path is required"
        # loading everything on the CPU, then modularly offloading to the GPU
        device = ProcDevice.CPU.value
        
        self._set_quantization(model_path)
        self.dtype = dtype or self.dtype
        
        model_path = ensure_model_availability(model_path, download_url, force_download)
        state_dict = get_state_dict(model_path, model_type=model_type)
        model_state_dict = self.state_dict()
              
        for param_name, param in state_dict.items():
            if param_name not in model_state_dict: 
                app_logger.warning(f"skipping the param {param_name} as it's not present in the model definition")
                continue
            
            parent_module, leaf_name, local_target_dtype = self._get_param_context(param_name)
            if self.dtype is not None:
                if self.quantizer is not None:
                    pass    # not overiding dtype of quantized models
                else:
                    param = param.to(local_target_dtype)
            old_param = getattr(parent_module, leaf_name, None)
            # param_name might be for a buffer or something not loadable, skip it
            if not isinstance(old_param, (torch.nn.Parameter, torch.Tensor)):
                old_param = None
                
            if old_param is not None:
                if self.dtype is None:
                    param = param.to(old_param.dtype)
                    
                if old_param.is_contiguous():
                    param = param.contiguous()
            
            # bnb params are flattened
            # gguf quants have a different shape based on the type of quantization applied
            if model_state_dict[param_name].shape != param.shape:
                if self.quantizer is not None:
                    self.quantizer.check_quantized_param_shape(param_name, model_state_dict[param_name], param)
                else:
                    raise ValueError(
                        f"Cannot load {model_path} because {param_name} expected shape {model_state_dict[param_name].shape}, but got {param.shape}."
                    )
            
            # final assignment
            if self.quantizer is not None and self.quantizer.check_if_quantized_param(
                self, param, param_name, state_dict, dtype=self.dtype
            ):
                self.quantizer.create_quantized_param(
                    self,
                    param,
                    param_name,
                    device,
                    state_dict,
                    dtype=self.dtype
                )
            else:
                set_module_tensor_to_device(self, param_name, device, value=param, dtype=local_target_dtype)
                
        for name, param in self.named_parameters():
            if param.device.type == "meta":
                app_logger.warning(f"Initializing missing meta parameter: {name}")
                _, _, local_target_dtype = self._get_param_context(name)
                # NOTE: heuristic: Scales = 1.0, biases/weights = 0.0
                if "scale" in name:
                    val = torch.ones_like(param, device=device)
                else:
                    val = torch.zeros_like(param, device=device)
                set_module_tensor_to_device(self, name, device, value=val, dtype=local_target_dtype)
    
    def process_latent_in(self, latent_in: Tensor) -> Tensor:
        assert self.model_arch_config is not None, "model_arch_config not set"
        return self.model_arch_config.latent_format.process_in(latent_in)
    
    def process_latent_out(self, latent_out: Tensor) -> Tensor:
        assert self.model_arch_config is not None, "model_arch_config not set"
        return self.model_arch_config.latent_format.process_out(latent_out)
    
    def get_memory_footprint_params(self):
        # NOTE: this has to be overidden in the child model
        app_logger.warning("Memory footprint params not found, skipping activation buffer calculations")
        return None

    def get_model_sampling_obj(self):
        # NOTE: this has to overidden in the child model
        app_logger.warning("Model sampling config not found, defaulting to simple Flow based sampling")
        return get_model_sampling(ModelType.FLOW)