import math
from typing import get_origin, get_args, Any, Union, Tuple

def split_module_key(module: Any, tensor_name: str) -> Tuple[Any, str]:
    # given a key, splits it into module, final key attr
    # layer1.block.0.weight -> (layer1.block[0], 'weight')
    
    *path, final = tensor_name.split(".")
    for attr in path:
        try:
            module = getattr(module, attr)
        except AttributeError:
            raise ValueError(f"{module} has no attribute {attr}.")
    return module, final


def get_module_from_name(module, tensor_name: str) -> Tuple[Any, str]:
    #  (model, attn.proj_out.weight) -> (model.attn.proj_out, "weight") 
    if "." in tensor_name:
        splits = tensor_name.split(".")
        for split in splits[:-1]:
            new_module = getattr(module, split)
            if new_module is None:
                raise ValueError(f"{module} has no attribute {split}.")
            module = new_module
        tensor_name = splits[-1]
    return module, tensor_name

def validate_type(value, expected_type, field_name: str):
    """
    Validate that a value matches an expected typing annotation.
    Supports Any, Union, Optional, list, dict, set, and plain types.
    """

    # Case 1: Any → always valid
    if expected_type is Any:
        return

    origin = get_origin(expected_type)

    # Case 2: Non-generic type (int, str, torch.dtype, etc.)
    if origin is None:
        if not isinstance(value, expected_type):
            raise TypeError(
                f"Field '{field_name}' must be {expected_type}, "
                f"but got {type(value)}"
            )
        return

    # Case 3: Union/Optional
    if origin is Union:
        args = get_args(expected_type)
        if not any(
            (
                (t is Any)
                or (get_origin(t) is None and isinstance(value, t))
                or (get_origin(t) is not None and safe_check(value, t))
            )
            for t in args
        ):
            raise TypeError(
                f"Field '{field_name}' must be one of {args}, "
                f"but got {type(value)}"
            )
        return

    # Case 4: list[...] 
    if origin is list:
        (elem_type,) = get_args(expected_type)
        if not isinstance(value, list):
            raise TypeError(f"Field '{field_name}' must be a list, got {type(value)}")
        for v in value:
            validate_type(v, elem_type, f"{field_name} element")
        return

    # Case 5: dict[...]
    if origin is dict:
        key_type, val_type = get_args(expected_type)
        if not isinstance(value, dict):
            raise TypeError(f"Field '{field_name}' must be a dict, got {type(value)}")
        for k, v in value.items():
            validate_type(k, key_type, f"{field_name} key")
            validate_type(v, val_type, f"{field_name} value")
        return

    # Case 6: set[...]
    if origin is set:
        (elem_type,) = get_args(expected_type)
        if not isinstance(value, set):
            raise TypeError(f"Field '{field_name}' must be a set, got {type(value)}")
        for v in value:
            validate_type(v, elem_type, f"{field_name} element")
        return

    # Fallback
    raise TypeError(f"Unsupported type annotation {expected_type} for field '{field_name}'")


def safe_check(value, expected_type):
    """Helper: safe recursive check for nested generics in Union."""
    try:
        validate_type(value, expected_type, "<union member>")
        return True
    except TypeError:
        return False

def fix_frame_count(n, vae_temporal_factor = 4):
    from .logging import app_logger
    # changing num of frames as per vae requirements, 82 -> 85, 83 -> 85..
    # e.g. pixels = 4 * latents + 1
    latents = math.ceil((n - 1) / vae_temporal_factor)
    t_n = (latents * vae_temporal_factor) + 1
    if t_n != n: app_logger.warning(f"Number of frames changed from {n} to {t_n}")
    return t_n

def is_ffmpeg_present():
    import shutil
    from .logging import app_logger
    for binary in ["ffmpeg", "ffprobe"]:
        if shutil.which(binary) is None:
            app_logger.warning(f"{binary} not found. Unable to save metadata to output. Please install FFmpeg.")
            return False
    
    return True

def install_requirements(directory: str, show_logs: bool = True) -> bool:
    import os
    import subprocess
    import sys
    from pathlib import Path
    from .logging import app_logger

    req_path = os.path.join(directory, "requirements.txt")
    if os.path.exists(req_path):
        # prioritize local virtual environment if present
        python_exe = sys.executable
        cwd = Path.cwd()
        possible_venvs = ["venv", ".venv"]
        for vname in possible_venvs:
            vpath = cwd / vname
            if vpath.is_dir():
                if sys.platform == "win32":
                    cand = vpath / "Scripts" / "python.exe"
                else:
                    cand = vpath / "bin" / "python"
                
                if cand.exists():
                    python_exe = str(cand)
                    break

        app_logger.info(f"Installing requirements for extension in {directory} using {python_exe}...")
        stdout_dest = None if show_logs else subprocess.DEVNULL
        stderr_dest = None if show_logs else subprocess.DEVNULL

        try:
            subprocess.check_call(
                [python_exe, "-m", "pip", "install", "-r", req_path], 
                stdout=stdout_dest, 
                stderr=stderr_dest
            )
            return True
        except subprocess.CalledProcessError as e:
            app_logger.error(f"Failed to install requirements (silent mode): {e}")
            return False
    return True

null_func = lambda *args, **kwargs: None