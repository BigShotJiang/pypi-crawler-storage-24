import inspect
from pathlib import Path

# Sentinel to distinguish "not set" (inherit global) from auth=None (explicitly public)
_UNSET = object()

_REGISTRY = {
    "features": {},   # {feature_name: {"config": {...}, "resources": {}}}
    "crons": [],      # [{name, func, module_file, schedule, memory, timeout, env, description}]
    "lambdas": [],    # [{name, func, module_file, memory, timeout, env, description}]
    "shared_resources": {},  # {key: Resource}
}


def _get_calling_feature_name() -> str | None:
    """Inspect call stack to find which feature module called us."""
    stack = inspect.stack()
    for frame_info in stack[2:]:
        filepath = frame_info.filename
        parts = Path(filepath).parts
        try:
            feat_idx = list(parts).index("features")
            if feat_idx + 1 < len(parts):
                return parts[feat_idx + 1]
        except ValueError:
            continue
    return None


def configure(
    # --- Básico ---
    memory: int = None,
    timeout: int = None,
    description: str = None,
    # --- Entorno ---
    env: dict = None,
    layers: list = None,
    # --- IAM ---
    policies: list = None,
    # --- Recursos AWS ---
    resources: dict = None,
    # --- Arquitectura ---
    architectures: list = None,
    tracing: bool = None,
    # --- Concurrencia ---
    reserved_concurrency: int = None,
    provisioned_concurrency: int = None,
    # --- Almacenamiento ---
    ephemeral_storage: int = None,
    # --- Fiabilidad ---
    dlq: bool = False,
    # --- Observabilidad ---
    log_retention: int = None,
    alarms=_UNSET,
    # --- Auth (API Gateway) ---
    auth=_UNSET,
):
    """
    Register Lambda configuration for the current feature.
    Call this at module level inside app/features/{feature}/routes.py.
    This is a no-op at runtime — only the deployless compiler reads it.

    auth values:
      (not set)  → inherit global auth from deployless.yaml
      None       → all routes in this feature are public (no auth)
      "api_key"  → all routes in this feature require an API key

    alarms values:
      (not set)  → inherit global alarms config from deployless.yaml
      False      → disable alarms for this feature
      True       → enable with default thresholds
      dict       → custom thresholds (see docs)
    """
    feature_name = _get_calling_feature_name()
    if feature_name is None:
        return

    config = {}
    if memory is not None:
        config["memory"] = memory
    if timeout is not None:
        config["timeout"] = timeout
    if description is not None:
        config["description"] = description
    if env:
        config["env"] = env
    if layers:
        config["layers"] = layers
    if policies:
        config["policies"] = policies
    if architectures:
        config["architectures"] = architectures
    if tracing is not None:
        config["tracing"] = tracing
    if reserved_concurrency is not None:
        config["reserved_concurrency"] = reserved_concurrency
    if provisioned_concurrency is not None:
        config["provisioned_concurrency"] = provisioned_concurrency
    if ephemeral_storage is not None:
        config["ephemeral_storage"] = ephemeral_storage
    if dlq:
        config["dlq"] = dlq
    if log_retention is not None:
        config["log_retention"] = log_retention
    if auth is not _UNSET:
        config["auth"] = auth
    if alarms is not _UNSET:
        config["alarms"] = alarms

    if feature_name not in _REGISTRY["features"]:
        _REGISTRY["features"][feature_name] = {"config": {}, "resources": {}}

    _REGISTRY["features"][feature_name]["config"].update(config)

    if resources:
        for name, resource in resources.items():
            _REGISTRY["features"][feature_name]["resources"][name] = resource


def route(
    memory: int = None,
    timeout: int = None,
    description: str = None,
    auth=_UNSET,
):
    """
    Mark a specific route as its own Lambda function (instead of sharing with the feature).

    auth values:
      (not set)  → inherit feature/global auth
      None       → this route is public
      "api_key"  → this route requires an API key

    Usage:
        @pc.route(memory=1024, timeout=60)
        @bp.route('/export', methods=['POST'])
        def export_data():
            ...
    """
    def decorator(func):
        func.__deployless_route_config__ = {
            "memory": memory,
            "timeout": timeout,
            "description": description,
            "auth": auth,
        }
        return func
    return decorator


def cron(
    schedule: str,
    memory: int = None,
    timeout: int = None,
    env: dict = None,
    description: str = None,
):
    """
    Register a Lambda function triggered on a schedule.

    schedule formats:
      "rate(5 minutes)"
      "rate(1 hour)"
      "cron(0 9 * * ? *)"   # Every day at 9:00 UTC

    Usage:
        @pc.cron(schedule="rate(24 hours)", memory=128, timeout=60)
        def cleanup(event, context):
            return {"status": "ok"}
    """
    def decorator(func):
        _REGISTRY["crons"].append({
            "name": func.__name__,
            "func": func,
            "module_file": inspect.getfile(func),
            "schedule": schedule,
            "memory": memory,
            "timeout": timeout,
            "env": env or {},
            "description": description,
        })
        return func
    return decorator


def lambda_function(
    memory: int = None,
    timeout: int = None,
    env: dict = None,
    description: str = None,
):
    """
    Decorator to mark a function as a standalone Lambda (not HTTP, not cron).
    Useful for SQS consumers, S3 triggers, Step Functions, etc.

    Usage:
        @pc.lambda_function(memory=256, timeout=60)
        def process_queue(event, context):
            ...
    """
    def decorator(func):
        _REGISTRY["lambdas"].append({
            "name": func.__name__,
            "func": func,
            "module_file": inspect.getfile(func),
            "memory": memory,
            "timeout": timeout,
            "env": env or {},
            "description": description,
        })
        return func
    return decorator


def shared_resource(key: str, resource):
    """
    Declare a global resource shared across all features.
    The resource will be included in the SAM template and its env var
    will be injected into every feature Lambda.

    Usage:
        pc.shared_resource("events_table", pc.DynamoDB("events-table"))
    """
    _REGISTRY["shared_resources"][key] = resource


def Ref(resource) -> dict:
    """Reference an AWS resource (for use in policies or env vars)."""
    if isinstance(resource, str):
        return {"Ref": resource}
    return {"Ref": resource._logical_id()}


def GetAtt(resource, attribute: str) -> dict:
    """Get an attribute from an AWS resource (e.g. GetAtt(my_queue, "Arn"))."""
    if isinstance(resource, str):
        name = resource
    elif hasattr(resource, "_logical_id"):
        name = resource._logical_id()
    else:
        raise ValueError(f"Cannot create GetAtt for {resource}")
    return {"Fn::GetAtt": [name, attribute]}


def get_registry() -> dict:
    return _REGISTRY


def reset_registry():
    _REGISTRY["features"] = {}
    _REGISTRY["crons"] = []
    _REGISTRY["lambdas"] = []
    _REGISTRY["shared_resources"] = {}
