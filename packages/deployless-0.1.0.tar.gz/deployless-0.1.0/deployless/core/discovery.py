import importlib.util
import sys
from pathlib import Path


def discover_features(project_root: str, features_path: str) -> list:
    """
    Scan features directory for feature modules.
    Returns list of dicts: {name, dir, routes_file}
    """
    features_dir = Path(project_root) / features_path
    if not features_dir.exists():
        return []

    features = []
    for entry in sorted(features_dir.iterdir()):
        if entry.is_dir() and not entry.name.startswith("_"):
            routes_file = entry / "routes.py"
            if routes_file.exists():
                features.append({
                    "name": entry.name,
                    "dir": entry,
                    "routes_file": routes_file,
                })
    return features


def import_module_from_file(module_name: str, file_path, project_root=None):
    """Import a Python module from an absolute file path."""
    file_path = Path(file_path)
    if project_root:
        root = str(project_root)
        if root not in sys.path:
            sys.path.insert(0, root)

    spec = importlib.util.spec_from_file_location(module_name, file_path)
    module = importlib.util.module_from_spec(spec)
    sys.modules[module_name] = module
    spec.loader.exec_module(module)
    return module
