import re
from deployless.adapters.base import FrameworkAdapter


class FlaskAdapter(FrameworkAdapter):

    def detect(self, module) -> bool:
        for attr_name in dir(module):
            attr = getattr(module, attr_name, None)
            if attr and self._is_flask_blueprint(attr):
                return True
        return False

    def _is_flask_blueprint(self, obj) -> bool:
        klass = type(obj)
        return klass.__name__ == "Blueprint" and "flask" in klass.__module__

    def _get_blueprints(self, module) -> list:
        return [
            getattr(module, name)
            for name in dir(module)
            if self._is_flask_blueprint(getattr(module, name, None))
        ]

    def get_url_prefix(self, module) -> str:
        blueprints = self._get_blueprints(module)
        if blueprints:
            return blueprints[0].url_prefix or ""
        return ""

    def extract_routes(self, module) -> list:
        try:
            from flask import Flask
        except ImportError:
            raise RuntimeError("Flask not installed. Run: pip install flask")

        blueprints = self._get_blueprints(module)
        if not blueprints:
            return []

        temp_app = Flask(__name__)
        for bp in blueprints:
            temp_app.register_blueprint(bp)

        routes = []
        for rule in temp_app.url_map.iter_rules():
            if rule.endpoint == "static":
                continue
            view_func = temp_app.view_functions.get(rule.endpoint)
            methods = sorted(rule.methods - {"HEAD", "OPTIONS"})
            routes.append({
                "path": rule.rule,
                "sam_path": self._to_sam_path(rule.rule),
                "methods": methods,
                "endpoint": rule.endpoint,
                "func": view_func,
                "split_config": getattr(view_func, "__deployless_route_config__", None),
            })
        return routes

    @staticmethod
    def _to_sam_path(flask_path: str) -> str:
        """Convert /users/<user_id> → /users/{user_id}"""
        return re.sub(r"<(?:[^:>]+:)?([^>]+)>", r"{\1}", flask_path)
