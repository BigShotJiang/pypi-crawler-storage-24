from abc import ABC, abstractmethod


class FrameworkAdapter(ABC):

    @abstractmethod
    def detect(self, module) -> bool:
        """Return True if this adapter can handle the given module."""

    @abstractmethod
    def extract_routes(self, module) -> list:
        """
        Extract all routes from the module.
        Returns list of dicts:
        {
            path: str,          # Flask path e.g. /users/<user_id>
            sam_path: str,      # SAM path e.g. /users/{user_id}
            methods: list[str], # ["GET", "POST"]
            endpoint: str,      # endpoint name
            func: callable,     # view function
            split_config: dict | None,  # from @pc.route() if present
        }
        """

    @abstractmethod
    def get_url_prefix(self, module) -> str:
        """Get the URL prefix for this feature's routes."""
