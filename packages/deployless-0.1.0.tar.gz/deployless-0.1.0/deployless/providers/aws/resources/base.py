class Resource:
    """Base class for all AWS resources managed by deployless."""

    def _logical_id(self) -> str:
        raise NotImplementedError

    def to_cfn(self) -> dict:
        """Return CloudFormation resource definition dict."""
        raise NotImplementedError

    def env_var_name(self) -> str:
        """Return the env var name to inject into Lambda (e.g. USERS_TABLE)."""
        raise NotImplementedError

    def env_var_value(self):
        """Return CFN intrinsic function or string for the env var value."""
        return {"Ref": self._logical_id()}
