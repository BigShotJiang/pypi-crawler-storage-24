import re
from deployless.providers.aws.resources.base import Resource


VALID_KEY_USAGES = {"ENCRYPT_DECRYPT", "SIGN_VERIFY", "GENERATE_VERIFY_MAC"}
VALID_KEY_SPECS = {
    "SYMMETRIC_DEFAULT",
    "RSA_2048", "RSA_3072", "RSA_4096",
    "ECC_NIST_P256", "ECC_NIST_P384", "ECC_NIST_P521", "ECC_SECG_P256K1",
    "HMAC_224", "HMAC_256", "HMAC_384", "HMAC_512",
}


def _to_pascal(name: str) -> str:
    return "".join(w.capitalize() for w in re.split(r"[-_/]", name))


class KMS(Resource):
    """KMS Key resource. Symmetric with auto-rotation by default."""

    def __init__(
        self,
        alias: str = None,
        description: str = None,
        key_usage: str = "ENCRYPT_DECRYPT",
        key_spec: str = "SYMMETRIC_DEFAULT",
        enable_rotation: bool = None,   # None → auto: True for SYMMETRIC_DEFAULT, False otherwise
        deletion_policy: str = "Retain",
        existing_key_id: str = None,
        env_var: str = None,
    ):
        self.alias = alias
        self.description = description
        self.env_var = env_var
        self.key_usage = key_usage
        self.key_spec = key_spec
        # Auto-rotation only valid for symmetric keys
        if enable_rotation is None:
            self.enable_rotation = (key_spec == "SYMMETRIC_DEFAULT")
        else:
            self.enable_rotation = enable_rotation
        self.deletion_policy = deletion_policy
        self.existing_key_id = existing_key_id

    def _logical_id(self) -> str:
        if self.alias:
            name = self.alias.replace("alias/", "")
            return _to_pascal(name) + "Key"
        return "AppKey"

    def arn_ref(self):
        """Returns the appropriate ARN reference for use in IAM policies."""
        if self.existing_key_id:
            if self.existing_key_id.startswith("arn:"):
                return self.existing_key_id
            return {
                "Fn::Sub": f"arn:aws:kms:${{AWS::Region}}:${{AWS::AccountId}}:key/{self.existing_key_id}"
            }
        return {"Fn::GetAtt": [self._logical_id(), "Arn"]}

    def env_var_name(self) -> str:
        if self.env_var:
            return self.env_var.upper()
        if self.alias:
            name = self.alias.replace("alias/", "")
            return re.sub(r"[-/]", "_", name).upper() + "_KEY_ID"
        return "KMS_KEY_ID"

    def env_var_value(self):
        if self.existing_key_id:
            return self.existing_key_id
        return {"Ref": self._logical_id()}

    def validate(self) -> list:
        errors = []
        if self.alias and not re.match(r"^[a-zA-Z0-9/_-]+$", self.alias.replace("alias/", "")):
            errors.append(
                f"alias '{self.alias}' contiene caracteres inválidos "
                "(solo alfanumérico, '-', '_', '/')"
            )
        if self.key_usage not in VALID_KEY_USAGES:
            errors.append(
                f"key_usage='{self.key_usage}' inválido. "
                f"Debe ser: {', '.join(sorted(VALID_KEY_USAGES))}"
            )
        if self.key_spec not in VALID_KEY_SPECS:
            errors.append(
                f"key_spec='{self.key_spec}' inválido. "
                f"Debe ser: {', '.join(sorted(VALID_KEY_SPECS))}"
            )
        if self.enable_rotation and self.key_spec != "SYMMETRIC_DEFAULT":
            errors.append(
                f"enable_rotation=True solo es válido para key_spec='SYMMETRIC_DEFAULT', "
                f"actual: '{self.key_spec}'"
            )
        if self.key_usage == "ENCRYPT_DECRYPT" and self.key_spec.startswith("ECC_"):
            errors.append(
                f"key_spec='{self.key_spec}' no es compatible con key_usage='ENCRYPT_DECRYPT'"
            )
        if self.key_usage == "SIGN_VERIFY" and self.key_spec == "SYMMETRIC_DEFAULT":
            errors.append("key_spec='SYMMETRIC_DEFAULT' no es compatible con key_usage='SIGN_VERIFY'")
        return errors

    def to_cfn(self) -> dict:
        if self.existing_key_id:
            return {}

        props = {
            "Description": self.description or f"deployless managed key — {self.alias or 'app'}",
            "Enabled": True,
            "KeyUsage": self.key_usage,
            "KeySpec": self.key_spec,
            "KeyPolicy": {
                "Version": "2012-10-17",
                "Statement": [
                    {
                        "Sid": "AllowRootAccount",
                        "Effect": "Allow",
                        "Principal": {
                            "AWS": {"Fn::Sub": "arn:aws:iam::${AWS::AccountId}:root"}
                        },
                        "Action": "kms:*",
                        "Resource": "*",
                    }
                ],
            },
        }

        if self.enable_rotation and self.key_spec == "SYMMETRIC_DEFAULT":
            props["EnableKeyRotation"] = True

        resources = {self._logical_id(): {"Type": "AWS::KMS::Key", "Properties": props}}

        if self.alias:
            alias_logical_id = self._logical_id().replace("Key", "") + "KeyAlias"
            alias_name = self.alias if self.alias.startswith("alias/") else f"alias/{self.alias}"
            resources[alias_logical_id] = {
                "Type": "AWS::KMS::Alias",
                "Properties": {
                    "AliasName": alias_name,
                    "TargetKeyId": {"Ref": self._logical_id()},
                },
            }

        if self.deletion_policy and self.deletion_policy != "Delete":
            resources[self._logical_id()]["DeletionPolicy"] = self.deletion_policy

        return resources
