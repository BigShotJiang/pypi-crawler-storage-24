from deployless.providers.aws.resources.dynamodb import DynamoDB
from deployless.providers.aws.resources.s3 import S3
from deployless.providers.aws.resources.sqs import SQS
from deployless.providers.aws.resources.kms import KMS
from deployless.providers.aws.resources.ssm import SSMParameter, SSMParam

__all__ = ["DynamoDB", "S3", "SQS", "KMS", "SSMParameter", "SSMParam"]
