import re
from deployless.providers.aws.resources.base import Resource


def _to_pascal(name: str) -> str:
    return "".join(w.capitalize() for w in re.split(r"[-_]", name))


class SQS(Resource):
    """SQS Queue resource. Optionally creates a Dead Letter Queue."""

    def __init__(
        self,
        queue_name: str,
        fifo: bool = False,
        dlq: bool = False,
        visibility_timeout: int = 30,
        message_retention: int = 345600,  # 4 days in seconds
        max_receive_count: int = 3,
        encryption: bool = True,          # SqsManagedSseEnabled (SSE-SQS)
        deletion_policy: str = "Delete",
        existing: bool = False,
    ):
        self.queue_name = queue_name
        self.fifo = fifo
        self.dlq = dlq
        self.visibility_timeout = visibility_timeout
        self.message_retention = message_retention
        self.max_receive_count = max_receive_count
        self.encryption = encryption
        self.deletion_policy = deletion_policy
        self.existing = existing
        # Auto-add .fifo suffix for FIFO queues
        if fifo and not queue_name.endswith(".fifo"):
            self.queue_name = queue_name + ".fifo"

    def _logical_id(self) -> str:
        name = self.queue_name.replace(".fifo", "")
        for suffix in ["-queue", "_queue"]:
            if name.lower().endswith(suffix):
                name = name[: -len(suffix)]
        return _to_pascal(name) + "Queue"

    def _dlq_logical_id(self) -> str:
        return self._logical_id().replace("Queue", "") + "DLQueue"

    def validate(self) -> list:
        errors = []
        base_name = self.queue_name.replace(".fifo", "")
        if not base_name:
            errors.append("queue_name vacío")
        elif len(self.queue_name) > 80:
            errors.append(f"queue_name '{self.queue_name}' excede 80 caracteres ({len(self.queue_name)})")
        elif not re.match(r"^[a-zA-Z0-9_-]+$", base_name):
            errors.append(f"queue_name '{base_name}' contiene caracteres inválidos (solo alfanumérico, '-' y '_')")
        if not (0 <= self.visibility_timeout <= 43200):
            errors.append(f"visibility_timeout={self.visibility_timeout} fuera de rango [0, 43200]")
        if not (60 <= self.message_retention <= 1209600):
            errors.append(f"message_retention={self.message_retention} fuera de rango [60, 1209600]")
        if not (1 <= self.max_receive_count <= 1000):
            errors.append(f"max_receive_count={self.max_receive_count} fuera de rango [1, 1000]")
        return errors

    def env_var_name(self) -> str:
        name = self.queue_name.replace(".fifo", "")
        for suffix in ["-queue", "_queue"]:
            if name.lower().endswith(suffix):
                name = name[: -len(suffix)]
        return re.sub(r"[-]", "_", name).upper() + "_QUEUE_URL"

    def env_var_value(self):
        return {"Ref": self._logical_id()}

    def to_cfn(self) -> dict:
        if self.existing:
            return {}

        props = {
            "QueueName": self.queue_name,
            "VisibilityTimeout": self.visibility_timeout,
            "MessageRetentionPeriod": self.message_retention,
        }

        if self.encryption:
            props["SqsManagedSseEnabled"] = True

        if self.fifo:
            props["FifoQueue"] = True
            props["ContentBasedDeduplication"] = True

        if self.dlq:
            props["RedrivePolicy"] = {
                "deadLetterTargetArn": {"Fn::GetAtt": [self._dlq_logical_id(), "Arn"]},
                "maxReceiveCount": self.max_receive_count,
            }

        resources = {self._logical_id(): {"Type": "AWS::SQS::Queue", "Properties": props}}

        if self.dlq:
            dlq_name = self.queue_name.replace(".fifo", "") + "-dlq"
            if self.fifo:
                dlq_name += ".fifo"
            dlq_props = {
                "QueueName": dlq_name,
                "MessageRetentionPeriod": 1209600,  # 14 days
            }
            if self.encryption:
                dlq_props["SqsManagedSseEnabled"] = True
            if self.fifo:
                dlq_props["FifoQueue"] = True
            resources[self._dlq_logical_id()] = {
                "Type": "AWS::SQS::Queue",
                "Properties": dlq_props,
            }

        return resources  # Note: returns dict of logical_id -> resource

    def to_cfn_flat(self) -> dict:
        """Alias used by SAM generator to get {logical_id: cfn_dict} pairs."""
        return self.to_cfn()
