import re
from deployless.providers.aws.resources.base import Resource


def _to_pascal(name: str) -> str:
    return "".join(w.capitalize() for w in re.split(r"[-_]", name))


class S3(Resource):
    """S3 Bucket resource."""

    def __init__(
        self,
        bucket_name: str,
        versioning: bool = False,
        encryption: bool = True,
        cors: list = None,
        lifecycle_rules: list = None,
        public_access_block: bool = True,
        deletion_policy: str = "Delete",
        existing: bool = False,
    ):
        self.bucket_name = bucket_name
        self.versioning = versioning
        self.encryption = encryption
        self.cors = cors
        self.lifecycle_rules = lifecycle_rules
        self.public_access_block = public_access_block
        self.deletion_policy = deletion_policy
        self.existing = existing

    def _logical_id(self) -> str:
        name = self.bucket_name
        for suffix in ["-bucket", "_bucket"]:
            if name.lower().endswith(suffix):
                name = name[: -len(suffix)]
        return _to_pascal(name) + "Bucket"

    def env_var_name(self) -> str:
        name = self.bucket_name
        for suffix in ["-bucket", "_bucket"]:
            if name.lower().endswith(suffix):
                name = name[: -len(suffix)]
        return re.sub(r"[-]", "_", name).upper() + "_BUCKET"

    def validate(self) -> list:
        errors = []
        name = self.bucket_name
        if not name:
            errors.append("bucket_name vacío")
        elif len(name) < 3 or len(name) > 63:
            errors.append(f"bucket_name '{name}' debe tener entre 3 y 63 caracteres ({len(name)})")
        elif "_" in name:
            errors.append(f"bucket_name '{name}' no puede contener underscores (S3 es DNS-compliant)")
        elif not re.match(r"^[a-z0-9][a-z0-9.-]*[a-z0-9]$", name):
            errors.append(f"bucket_name '{name}' debe ser DNS-compliant (lowercase, sin underscores, empieza y termina en alfanumérico)")
        return errors

    def to_cfn(self) -> dict:
        if self.existing:
            return {}

        props = {"BucketName": self.bucket_name}

        if self.encryption:
            props["BucketEncryption"] = {
                "ServerSideEncryptionConfiguration": [
                    {"ServerSideEncryptionByDefault": {"SSEAlgorithm": "AES256"}}
                ]
            }

        if self.versioning:
            props["VersioningConfiguration"] = {"Status": "Enabled"}

        if self.public_access_block:
            props["PublicAccessBlockConfiguration"] = {
                "BlockPublicAcls": True,
                "BlockPublicPolicy": True,
                "IgnorePublicAcls": True,
                "RestrictPublicBuckets": True,
            }

        if self.cors:
            props["CorsConfiguration"] = {"CorsRules": self.cors}

        if self.lifecycle_rules:
            props["LifecycleConfiguration"] = {"Rules": self.lifecycle_rules}

        resource = {"Type": "AWS::S3::Bucket", "Properties": props}
        if self.deletion_policy != "Delete":
            resource["DeletionPolicy"] = self.deletion_policy
        return resource
