import re
from deployless.providers.aws.resources.base import Resource

VALID_KEY_TYPES = {"S", "N", "B"}
VALID_PROJECTIONS = {"ALL", "KEYS_ONLY", "INCLUDE"}
VALID_STREAM_TYPES = {"NEW_IMAGE", "OLD_IMAGE", "NEW_AND_OLD_IMAGES", "KEYS_ONLY"}
VALID_BILLING_MODES = {"PAY_PER_REQUEST", "PROVISIONED"}

# SimpleTable requires long type names
_SIMPLE_TABLE_TYPES = {"S": "String", "N": "Number", "B": "Binary"}


def _to_pascal(name: str) -> str:
    return "".join(w.capitalize() for w in re.split(r"[-_]", name))


class DynamoDB(Resource):
    """
    DynamoDB table resource.

    - Solo pk (sin sk ni gsi) → AWS::Serverless::SimpleTable
    - Con sk o gsi          → AWS::DynamoDB::Table  (SSE habilitado por defecto)
    - billing_mode defecto  → PAY_PER_REQUEST
    """

    def __init__(
        self,
        table_name: str,
        pk: str = "id",
        pk_type: str = "S",
        sk: str = None,
        sk_type: str = "S",
        gsi: list = None,
        billing_mode: str = "PAY_PER_REQUEST",
        read_capacity: int = None,
        write_capacity: int = None,
        ttl_attribute: str = None,
        stream: str = None,
        point_in_time_recovery: bool = False,
        sse_enabled: bool = True,
        deletion_policy: str = "Delete",
        existing: bool = False,
    ):
        self.table_name = table_name
        self.pk = pk
        self.pk_type = pk_type
        self.sk = sk
        self.sk_type = sk_type
        self.gsi = gsi or []
        self.billing_mode = billing_mode
        self.read_capacity = read_capacity
        self.write_capacity = write_capacity
        self.ttl_attribute = ttl_attribute
        self.stream = stream
        self.point_in_time_recovery = point_in_time_recovery
        self.sse_enabled = sse_enabled
        self.deletion_policy = deletion_policy
        self.existing = existing

    def _logical_id(self) -> str:
        name = self.table_name
        for suffix in ["-table", "_table"]:
            if name.lower().endswith(suffix):
                name = name[: -len(suffix)]
        return _to_pascal(name) + "Table"

    def env_var_name(self) -> str:
        name = self.table_name
        for suffix in ["-table", "_table"]:
            if name.lower().endswith(suffix):
                name = name[: -len(suffix)]
        return re.sub(r"[-]", "_", name).upper() + "_TABLE"

    def env_var_value(self):
        if self.existing:
            return self.table_name
        return {"Ref": self._logical_id()}

    def _is_simple(self) -> bool:
        return not self.sk and not self.gsi

    def to_cfn(self) -> dict:
        if self.existing:
            return {}
        return self._simple_table() if self._is_simple() else self._full_table()

    def validate(self) -> list[str]:
        """Devuelve lista de errores. Lista vacía = válido."""
        errors = []
        if not self.table_name:
            errors.append(f"DynamoDB: table_name no puede estar vacío")
        if self.pk_type not in VALID_KEY_TYPES:
            errors.append(f"DynamoDB '{self.table_name}': pk_type='{self.pk_type}' inválido. Usar: {VALID_KEY_TYPES}")
        if self.sk and self.sk_type not in VALID_KEY_TYPES:
            errors.append(f"DynamoDB '{self.table_name}': sk_type='{self.sk_type}' inválido. Usar: {VALID_KEY_TYPES}")
        if self.billing_mode not in VALID_BILLING_MODES:
            errors.append(f"DynamoDB '{self.table_name}': billing_mode='{self.billing_mode}' inválido. Usar: {VALID_BILLING_MODES}")
        if self.stream and self.stream not in VALID_STREAM_TYPES:
            errors.append(f"DynamoDB '{self.table_name}': stream='{self.stream}' inválido. Usar: {VALID_STREAM_TYPES}")
        for i, index in enumerate(self.gsi):
            label = index.get("name", f"GSI[{i}]")
            if not index.get("name"):
                errors.append(f"DynamoDB '{self.table_name}': GSI[{i}] falta 'name'")
            if not index.get("pk"):
                errors.append(f"DynamoDB '{self.table_name}': GSI '{label}' falta 'pk'")
            if index.get("pk_type", "S") not in VALID_KEY_TYPES:
                errors.append(f"DynamoDB '{self.table_name}': GSI '{label}' pk_type inválido")
            if index.get("sk") and index.get("sk_type", "S") not in VALID_KEY_TYPES:
                errors.append(f"DynamoDB '{self.table_name}': GSI '{label}' sk_type inválido")
            projection = index.get("projection", "ALL")
            if projection not in VALID_PROJECTIONS:
                errors.append(f"DynamoDB '{self.table_name}': GSI '{label}' projection='{projection}' inválido. Usar: {VALID_PROJECTIONS}")
            if projection == "INCLUDE" and not index.get("non_key_attributes"):
                errors.append(f"DynamoDB '{self.table_name}': GSI '{label}' projection='INCLUDE' requiere 'non_key_attributes'")
        return errors

    def _simple_table(self) -> dict:
        props = {
            "TableName": self.table_name,
            "PrimaryKey": {
                "Name": self.pk,
                "Type": _SIMPLE_TABLE_TYPES.get(self.pk_type, self.pk_type),
            },
            "BillingMode": self.billing_mode,
        }
        if self.ttl_attribute:
            props["TimeToLiveSpecification"] = {
                "AttributeName": self.ttl_attribute,
                "Enabled": True,
            }
        if self.point_in_time_recovery:
            props["PointInTimeRecoverySpecification"] = {"PointInTimeRecoveryEnabled": True}

        resource = {"Type": "AWS::Serverless::SimpleTable", "Properties": props}
        if self.deletion_policy != "Delete":
            resource["DeletionPolicy"] = self.deletion_policy
        return resource

    def _full_table(self) -> dict:
        attr_defs: dict[str, str] = {self.pk: self.pk_type}
        key_schema = [{"AttributeName": self.pk, "KeyType": "HASH"}]

        if self.sk:
            attr_defs[self.sk] = self.sk_type
            key_schema.append({"AttributeName": self.sk, "KeyType": "RANGE"})

        gsi_list = []
        for gsi in self.gsi:
            gsi_pk = gsi["pk"]
            gsi_pk_type = gsi.get("pk_type", "S")
            gsi_sk = gsi.get("sk")
            gsi_sk_type = gsi.get("sk_type", "S")
            attr_defs[gsi_pk] = gsi_pk_type
            if gsi_sk:
                attr_defs[gsi_sk] = gsi_sk_type

            gsi_ks = [{"AttributeName": gsi_pk, "KeyType": "HASH"}]
            if gsi_sk:
                gsi_ks.append({"AttributeName": gsi_sk, "KeyType": "RANGE"})

            projection_type = gsi.get("projection", "ALL")
            projection = {"ProjectionType": projection_type}
            if projection_type == "INCLUDE":
                projection["NonKeyAttributes"] = gsi.get("non_key_attributes", [])

            gsi_list.append({
                "IndexName": gsi["name"],
                "KeySchema": gsi_ks,
                "Projection": projection,
            })

        props = {
            "TableName": self.table_name,
            "BillingMode": self.billing_mode,
            "AttributeDefinitions": [
                {"AttributeName": k, "AttributeType": v}
                for k, v in attr_defs.items()
            ],
            "KeySchema": key_schema,
            "SSESpecification": {"SSEEnabled": self.sse_enabled},
        }

        if self.billing_mode == "PROVISIONED":
            props["ProvisionedThroughput"] = {
                "ReadCapacityUnits": self.read_capacity or 5,
                "WriteCapacityUnits": self.write_capacity or 5,
            }
        if gsi_list:
            props["GlobalSecondaryIndexes"] = gsi_list
        if self.ttl_attribute:
            props["TimeToLiveSpecification"] = {
                "AttributeName": self.ttl_attribute,
                "Enabled": True,
            }
        if self.stream:
            props["StreamSpecification"] = {"StreamViewType": self.stream}
        if self.point_in_time_recovery:
            props["PointInTimeRecoverySpecification"] = {"PointInTimeRecoveryEnabled": True}

        resource = {"Type": "AWS::DynamoDB::Table", "Properties": props}
        if self.deletion_policy != "Delete":
            resource["DeletionPolicy"] = self.deletion_policy
        return resource
