"""
Main compiler orchestrator.
Orchestrates: discovery → import → route extraction → validation → build → generate.
"""
from __future__ import annotations
import os
import sys
from pathlib import Path

import yaml

from deployless.core.config import load_config
from deployless.core.discovery import discover_features, import_module_from_file
from deployless.core.metadata import get_registry, reset_registry
from deployless.adapters.flask import FlaskAdapter
from deployless.providers.aws.sam import generate_template
from deployless.providers.aws.packager import (
    build_feature_package,
    build_cron_package,
    build_split_route_package,
    build_lambda_package,
)
from deployless.compiler.validator import validate
from deployless.compiler.env_file import parse_env_file, push_secrets, build_secret_env_vars


ADAPTERS = [FlaskAdapter()]


def _detect_adapter(module):
    for adapter in ADAPTERS:
        if adapter.detect(module):
            return adapter
    return None


def _find_feature_dir_for_cron(cron: dict, features_root: Path) -> Path | None:
    """Find which feature directory contains the cron's source file."""
    cron_file = Path(cron["module_file"])
    try:
        cron_file.relative_to(features_root)
        # It's inside features/ — find the feature subdir
        parts = cron_file.relative_to(features_root).parts
        if parts:
            return features_root / parts[0]
    except ValueError:
        pass
    return None


def compile_project(
    project_root: str = None,
    stage: str = None,
    output: str = "template.yaml",
    dry_run: bool = False,
    verbose: bool = False,
) -> dict:
    """
    Full compilation pipeline.
    Returns the compiled state dict (useful for testing).
    """
    root = Path(project_root) if project_root else Path.cwd()

    # 1. Load config
    config = load_config(root)
    if stage:
        config["stage"] = stage

    paths = config.get("paths", {})
    features_rel = paths.get("features", "app/features")
    shared_rel = paths.get("shared", "app/shared")

    features_root = root / features_rel
    shared_dir = root / shared_rel
    dist_dir = root / ".dist"

    if verbose:
        print(f"[deployless] Project: {config['name']} | Stage: {config['stage']} | Provider: {config['provider']}")

    # 2. Discover features
    features = discover_features(root, features_rel)
    if verbose:
        print(f"[deployless] Features found: {[f['name'] for f in features]}")

    # 3. Import each feature's routes.py (sets PYCLOUD_RUNTIME so metadata registers)
    os.environ["PYCLOUD_RUNTIME"] = "compiler"
    reset_registry()

    # Add project root to sys.path so shared imports work
    if str(root) not in sys.path:
        sys.path.insert(0, str(root))

    state = {
        "features": {},
        "crons": [],
        "split_routes": [],
        "lambdas": [],
        "shared_resources": {},
    }

    for feature in features:
        module_name = f"deployless_feature_{feature['name']}_routes"
        try:
            module = import_module_from_file(module_name, feature["routes_file"], root)
        except Exception as e:
            print(f"[deployless] ERROR importing {feature['name']}/routes.py: {e}")
            raise

        adapter = _detect_adapter(module)
        if adapter is None:
            if verbose:
                print(f"[deployless] WARNING: No framework adapter found for feature '{feature['name']}'. Skipping.")
            continue

        routes = adapter.extract_routes(module)

        # Get metadata registered by pc.configure() in this module
        registry = get_registry()
        feature_meta = registry["features"].get(feature["name"], {"config": {}, "resources": {}})

        # Tag split routes
        split_routes = [r for r in routes if r.get("split_config")]
        normal_routes = [r for r in routes if not r.get("split_config")]

        state["features"][feature["name"]] = {
            "config": feature_meta["config"],
            "resources": feature_meta["resources"],
            "routes": normal_routes,
            "dir": feature["dir"],
            "adapter": type(adapter).__name__,
        }

        for split in split_routes:
            split["feature"] = feature["name"]
            split["feature_dir"] = feature["dir"]
            state["split_routes"].append(split)

        if verbose:
            print(f"[deployless]   {feature['name']}: {len(normal_routes)} routes, {len(split_routes)} split")

    # Collect crons from registry
    state["crons"] = get_registry()["crons"]
    if verbose and state["crons"]:
        print(f"[deployless] Crons: {[c['name'] for c in state['crons']]}")

    # Collect standalone lambdas from registry
    state["lambdas"] = get_registry()["lambdas"]
    if verbose and state["lambdas"]:
        print(f"[deployless] Lambdas: {[l['name'] for l in state['lambdas']]}")

    # Collect shared resources from registry
    state["shared_resources"] = get_registry()["shared_resources"]
    if verbose and state["shared_resources"]:
        print(f"[deployless] Shared resources: {list(state['shared_resources'].keys())}")

    # 4. Validate
    validate(state, config)
    if verbose:
        print("[deployless] Validation passed.")

    # 4b. Process env_file if configured
    env_file_path = config.get("env_file")
    if env_file_path:
        env_file_full = root / env_file_path
        if not env_file_full.exists():
            from deployless.compiler.validator import ValidationError
            raise ValidationError([f"[E27] env_file '{env_file_path}' does not exist."])

        plain_vars, secret_vars = parse_env_file(env_file_full)

        # Validate SECRET_ vars have non-empty values
        empty_secrets = [k for k, v in secret_vars.items() if not v]
        if empty_secrets:
            from deployless.compiler.validator import ValidationError
            raise ValidationError([
                f"[E28] SECRET_ variable '{k}' has an empty value." for k in empty_secrets
            ])

        # Merge plain vars into global env
        if "env" not in config:
            config["env"] = {}
        config["env"].update(plain_vars)

        # Store secret env var references in config for template generation
        if secret_vars:
            app_name = config.get("name", "deployless-app")
            secret_env = build_secret_env_vars(app_name, secret_vars.keys())
            config["env"].update({k: v.to_reference() for k, v in secret_env.items()})

            if not dry_run:
                secrets_kms = config.get("secrets_kms")
                pushed = push_secrets(app_name, secret_vars, secrets_kms)
                if verbose:
                    for path, action in pushed:
                        print(f"[deployless]   Secret {action}: {path}")

    if dry_run:
        print("[deployless] Dry run — no files written.")
        return state

    # 5. Build .dist/ packages
    dist_dir.mkdir(exist_ok=True)

    for feature_name, feature_data in state["features"].items():
        adapter_name = feature_data.get("adapter", "FlaskAdapter")
        framework = "flask" if "Flask" in adapter_name else "fastapi"

        pkg = build_feature_package(
            feature_name=feature_name,
            feature_dir=feature_data["dir"],
            shared_dir=shared_dir if shared_dir.exists() else None,
            project_root=root,
            dist_dir=dist_dir,
            framework=framework,
        )
        if verbose:
            print(f"[deployless]   Built: {pkg.relative_to(root)}")

    for split in state["split_routes"]:
        feature_name = split["feature"]
        feature_dir = split["feature_dir"]
        adapter_name = state["features"][feature_name].get("adapter", "FlaskAdapter")
        framework = "flask" if "Flask" in adapter_name else "fastapi"

        pkg = build_split_route_package(
            split=split,
            feature_dir=feature_dir,
            shared_dir=shared_dir if shared_dir.exists() else None,
            project_root=root,
            dist_dir=dist_dir,
            framework=framework,
        )
        if verbose:
            print(f"[deployless]   Built split route: {pkg.relative_to(root)}")

    for cron in state["crons"]:
        feature_dir = _find_feature_dir_for_cron(cron, features_root)
        pkg = build_cron_package(
            cron=cron,
            feature_dir=feature_dir,
            shared_dir=shared_dir if shared_dir.exists() else None,
            project_root=root,
            dist_dir=dist_dir,
        )
        if verbose:
            print(f"[deployless]   Built cron: {pkg.relative_to(root)}")

    for lmb in state["lambdas"]:
        feature_dir = _find_feature_dir_for_cron(lmb, features_root)  # same logic
        pkg = build_lambda_package(
            lmb=lmb,
            feature_dir=feature_dir,
            shared_dir=shared_dir if shared_dir.exists() else None,
            project_root=root,
            dist_dir=dist_dir,
        )
        if verbose:
            print(f"[deployless]   Built lambda: {pkg.relative_to(root)}")

    # 6. Generate template.yaml
    template = generate_template(state, config)

    output_path = root / output
    with open(output_path, "w") as f:
        yaml.dump(template, f, default_flow_style=False, sort_keys=False, allow_unicode=True)

    print(f"[deployless] Template generated: {output_path}")
    return state
