"""
Compile-time validation for deployless projects.
Collects all errors and reports them together (fail-slow, not fail-fast).
"""
from __future__ import annotations
import logging
import os
import re

logger = logging.getLogger("deployless.compiler.validator")


VALID_BILLING_MODES = {"PAY_PER_REQUEST", "PROVISIONED"}
VALID_ENDPOINT_TYPES = {"REGIONAL", "EDGE", "PRIVATE"}
VALID_STREAM_TYPES = {"NEW_IMAGE", "OLD_IMAGE", "NEW_AND_OLD_IMAGES", "KEYS_ONLY"}
VALID_SCHEDULE_PREFIXES = ("rate(", "cron(")
MEMORY_MIN, MEMORY_MAX = 128, 10240
TIMEOUT_MIN, TIMEOUT_MAX = 1, 900
LOG_RETENTION_VALID = {1, 3, 5, 7, 14, 30, 60, 90, 120, 150, 180, 365, 400, 545, 731, 1096, 1827, 3653}


class ValidationError(Exception):
    def __init__(self, errors: list[str]):
        self.errors = errors
        super().__init__("\n".join(errors))


def validate(state: dict, config: dict):
    """
    Run all compile-time validations.
    Raises ValidationError with all found errors if any exist.
    """
    errors = []

    # Resource-level validations (DynamoDB, S3, etc.)
    for feature_name, feature_data in state.get("features", {}).items():
        for res_name, resource in feature_data.get("resources", {}).items():
            if hasattr(resource, "validate"):
                for err in resource.validate():
                    errors.append(f"[E00] Feature '{feature_name}' / resource '{res_name}': {err}")

    # Config-level validations
    errors += _validate_config(config)

    # Feature-level validations
    for feature_name, feature_data in state.get("features", {}).items():
        errors += _validate_feature(feature_name, feature_data, config)

    # Cron validations
    for cron in state.get("crons", []):
        errors += _validate_cron(cron)

    # Standalone lambda validations
    for lmb in state.get("lambdas", []):
        errors += _validate_lambda(lmb)

    # Shared resource validations
    for res_name, resource in state.get("shared_resources", {}).items():
        if hasattr(resource, "validate"):
            for err in resource.validate():
                errors.append(f"[E00] Shared resource '{res_name}': {err}")

    # Route uniqueness across all features
    errors += _validate_no_duplicate_routes(state)

    if errors:
        raise ValidationError(errors)


VALID_AUTH_TYPES = {"cognito", "lambda", "iam"}
VALID_USAGE_PERIODS = {"DAY", "WEEK", "MONTH"}


def _validate_config(config: dict) -> list[str]:
    errors = []
    api = config.get("api", {})

    # Stage
    stage = config.get("stage", "dev")
    if not re.match(r"^[a-zA-Z0-9]+$", stage):
        errors.append(f"[E01] stage '{stage}' must be alphanumeric only.")

    # Endpoint type
    endpoint_type = api.get("endpoint_type", "REGIONAL")
    if endpoint_type not in VALID_ENDPOINT_TYPES:
        errors.append(
            f"[E02] api.endpoint_type '{endpoint_type}' is invalid. "
            f"Must be one of: {', '.join(VALID_ENDPOINT_TYPES)}"
        )

    # Log retention
    log_retention = config.get("globals", {}).get("log_retention", 14)
    if log_retention not in LOG_RETENTION_VALID:
        errors.append(
            f"[E03] globals.log_retention '{log_retention}' is not a valid CloudWatch "
            f"retention period. Valid values: {sorted(LOG_RETENTION_VALID)}"
        )

    # CORS
    cors = api.get("cors", {})
    if cors.get("allow_credentials") and cors.get("allow_origin") == "*":
        errors.append(
            "[E04] CORS: allow_credentials cannot be used with allow_origin: '*'. "
            "Specify a concrete origin instead."
        )

    # Auth
    auth = api.get("auth")
    if auth:
        auth_type = auth.get("type", "")
        if auth_type not in VALID_AUTH_TYPES:
            errors.append(
                f"[E11] api.auth.type '{auth_type}' is invalid. "
                f"Must be one of: {', '.join(VALID_AUTH_TYPES)}"
            )
        if auth_type == "cognito" and not auth.get("user_pool_arn"):
            errors.append("[E12] api.auth (cognito): user_pool_arn is required.")
        if auth_type == "lambda" and not auth.get("function_arn"):
            errors.append("[E13] api.auth (lambda): function_arn is required.")

    # Usage Plan
    usage_plan = api.get("usage_plan")
    if usage_plan:
        if not usage_plan.get("rate") or not usage_plan.get("burst"):
            errors.append("[E14] api.usage_plan: both 'rate' and 'burst' are required.")
        if usage_plan.get("quota") and not usage_plan.get("period"):
            errors.append("[E15] api.usage_plan: 'period' is required when 'quota' is set.")
        if usage_plan.get("period") and usage_plan["period"] not in VALID_USAGE_PERIODS:
            errors.append(
                f"[E16] api.usage_plan.period '{usage_plan['period']}' is invalid. "
                f"Must be one of: {', '.join(VALID_USAGE_PERIODS)}"
            )

    # Domain
    domain = api.get("domain")
    if domain:
        if not domain.get("domain_name") or not domain.get("certificate_arn"):
            errors.append(
                "[E17] api.domain: both 'domain_name' and 'certificate_arn' are required."
            )

    # Minimum compression size
    min_compression = api.get("minimum_compression_size")
    if min_compression is not None and (not isinstance(min_compression, int) or min_compression < 0):
        errors.append(
            f"[E18] api.minimum_compression_size must be an integer >= 0 (got {min_compression})."
        )

    # env_file existence is checked in main.py before validate() is called,
    # but we validate secrets_kms format here if present
    secrets_kms = config.get("secrets_kms")
    if secrets_kms is not None and not isinstance(secrets_kms, str):
        if not hasattr(secrets_kms, 'alias'):
            errors.append("[E29] secrets_kms must be a KMS key ARN/alias string or a pc.KMS() instance.")

    return errors


EPHEMERAL_STORAGE_MIN, EPHEMERAL_STORAGE_MAX = 512, 10240


def _validate_feature(feature_name: str, feature_data: dict, config: dict) -> list[str]:
    errors = []
    cfg = feature_data.get("config", {})
    g = config.get("globals", {})
    label = f"Feature '{feature_name}'"

    memory = cfg.get("memory", g.get("memory"))
    if memory is not None and not (MEMORY_MIN <= memory <= MEMORY_MAX):
        errors.append(f"[E05] {label}: memory {memory} MB out of range ({MEMORY_MIN}–{MEMORY_MAX}).")

    timeout = cfg.get("timeout", g.get("timeout"))
    if timeout is not None and not (TIMEOUT_MIN <= timeout <= TIMEOUT_MAX):
        errors.append(f"[E06] {label}: timeout {timeout}s out of range ({TIMEOUT_MIN}–{TIMEOUT_MAX}).")

    if not feature_data.get("routes"):
        errors.append(
            f"[E07] {label}: no routes found in routes.py. "
            "Make sure a Blueprint or Router is defined and has at least one route."
        )

    ephemeral = cfg.get("ephemeral_storage")
    if ephemeral is not None and not (EPHEMERAL_STORAGE_MIN <= ephemeral <= EPHEMERAL_STORAGE_MAX):
        errors.append(
            f"[E19] {label}: ephemeral_storage {ephemeral} MB out of range "
            f"({EPHEMERAL_STORAGE_MIN}–{EPHEMERAL_STORAGE_MAX})."
        )

    reserved = cfg.get("reserved_concurrency")
    if reserved is not None and reserved < 0:
        errors.append(f"[E20] {label}: reserved_concurrency must be >= 0 (got {reserved}).")

    provisioned = cfg.get("provisioned_concurrency")
    if provisioned is not None and provisioned < 1:
        errors.append(f"[E21] {label}: provisioned_concurrency must be >= 1 (got {provisioned}).")

    log_ret = cfg.get("log_retention")
    if log_ret is not None and log_ret not in LOG_RETENTION_VALID:
        errors.append(
            f"[E22] {label}: log_retention '{log_ret}' is not a valid CloudWatch retention period."
        )

    alarms = cfg.get("alarms")
    if isinstance(alarms, dict):
        errors += _validate_alarms(label, alarms, cfg.get("timeout", g.get("timeout", 30)))

    return errors


def _validate_alarms(label: str, alarms: dict, timeout: int) -> list[str]:
    errors = []
    sns = alarms.get("sns_topic_arn")
    if sns and not sns.startswith("arn:"):
        errors.append(f"[E23] {label}: alarms.sns_topic_arn must be a valid ARN (starts with 'arn:').")

    duration_cfg = alarms.get("duration", {})
    pct = duration_cfg.get("threshold_pct")
    if pct is not None and not (1 <= pct <= 100):
        errors.append(f"[E24] {label}: alarms.duration.threshold_pct must be between 1 and 100 (got {pct}).")

    return errors


def _validate_cron(cron: dict) -> list[str]:
    errors = []
    name = cron["name"]
    schedule = cron.get("schedule", "")

    if not any(schedule.startswith(p) for p in VALID_SCHEDULE_PREFIXES):
        errors.append(
            f"[E08] Cron '{name}': invalid schedule '{schedule}'. "
            "Must start with 'rate(' or 'cron('."
        )

    memory = cron.get("memory")
    if memory is not None and not (MEMORY_MIN <= memory <= MEMORY_MAX):
        errors.append(
            f"[E09] Cron '{name}': memory {memory} MB out of range ({MEMORY_MIN}–{MEMORY_MAX})."
        )

    timeout = cron.get("timeout")
    if timeout is not None and not (TIMEOUT_MIN <= timeout <= TIMEOUT_MAX):
        errors.append(
            f"[E10] Cron '{name}': timeout {timeout}s out of range ({TIMEOUT_MIN}–{TIMEOUT_MAX})."
        )

    return errors


def _validate_lambda(lmb: dict) -> list[str]:
    errors = []
    name = lmb["name"]

    memory = lmb.get("memory")
    if memory is not None and not (MEMORY_MIN <= memory <= MEMORY_MAX):
        errors.append(
            f"[E25] Lambda '{name}': memory {memory} MB out of range ({MEMORY_MIN}–{MEMORY_MAX})."
        )

    timeout = lmb.get("timeout")
    if timeout is not None and not (TIMEOUT_MIN <= timeout <= TIMEOUT_MAX):
        errors.append(
            f"[E26] Lambda '{name}': timeout {timeout}s out of range ({TIMEOUT_MIN}–{TIMEOUT_MAX})."
        )

    return errors


def _validate_no_duplicate_routes(state: dict) -> list[str]:
    errors = []
    seen: dict[tuple, str] = {}  # (path, method) -> feature_name

    for feature_name, feature_data in state.get("features", {}).items():
        for route in feature_data.get("routes", []):
            for method in route["methods"]:
                key = (route["sam_path"], method.upper())
                if key in seen:
                    errors.append(
                        f"[E11] Duplicate route: {method.upper()} {route['sam_path']} "
                        f"defined in both '{seen[key]}' and '{feature_name}'."
                    )
                else:
                    seen[key] = feature_name

    return errors


def check_existing_resources(state: dict) -> list[str]:
    """
    Verify that resources marked existing=True actually exist in AWS.
    Requires AWS credentials and boto3.
    Returns list of error messages.
    """
    from deployless.providers.aws.resources.dynamodb import DynamoDB
    from deployless.providers.aws.resources.sqs import SQS
    from deployless.providers.aws.resources.s3 import S3
    from deployless.providers.aws.resources.kms import KMS
    from deployless.providers.aws.resources.ssm import SSMParameter

    existing_resources = []

    # Collect from features
    for feature_data in state.get("features", {}).values():
        for res_obj in feature_data.get("resources", {}).values():
            if getattr(res_obj, "existing", False):
                existing_resources.append(res_obj)

    # Collect from shared resources
    for res_obj in state.get("shared_resources", {}).values():
        if getattr(res_obj, "existing", False):
            existing_resources.append(res_obj)

    if not existing_resources:
        return []

    try:
        import boto3
    except ImportError:
        logger.warning("boto3 not available — skipping --check-existing")
        return []

    region = os.environ.get("AWS_DEFAULT_REGION", "us-east-1")
    errors = []
    seen = set()

    for res_obj in existing_resources:
        res_id = res_obj._logical_id()
        if res_id in seen:
            continue
        seen.add(res_id)

        try:
            if isinstance(res_obj, DynamoDB):
                client = boto3.client("dynamodb", region_name=region)
                client.describe_table(TableName=res_obj.table_name)
            elif isinstance(res_obj, SQS):
                client = boto3.client("sqs", region_name=region)
                client.get_queue_url(QueueName=res_obj.queue_name)
            elif isinstance(res_obj, S3):
                client = boto3.client("s3", region_name=region)
                client.head_bucket(Bucket=res_obj.bucket_name)
            elif isinstance(res_obj, KMS):
                if res_obj.existing_key_id:
                    client = boto3.client("kms", region_name=region)
                    client.describe_key(KeyId=res_obj.existing_key_id)
                elif res_obj.alias:
                    client = boto3.client("kms", region_name=region)
                    alias_name = res_obj.alias if res_obj.alias.startswith("alias/") else f"alias/{res_obj.alias}"
                    client.describe_key(KeyId=alias_name)
            elif isinstance(res_obj, SSMParameter):
                client = boto3.client("ssm", region_name=region)
                client.get_parameter(Name=res_obj.name)
            logger.info("[CHECK] %s exists", res_id)
        except Exception as e:
            error_name = type(e).__name__
            errors.append(
                f"Existing resource '{res_id}' ({res_obj.__class__.__name__}) "
                f"not found in AWS: {error_name}"
            )

    return errors
