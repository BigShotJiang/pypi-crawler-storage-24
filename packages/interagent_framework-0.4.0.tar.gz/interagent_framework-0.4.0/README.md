# interagent-framework — DEPRECATED

This package has been renamed to **[agentweave-ai](https://pypi.org/project/agentweave-ai/)**.

Please update your installation:

```bash
pip uninstall interagent-framework
pip install agentweave-ai
```

This stub package installs `agentweave-ai` as a dependency to ease migration.
