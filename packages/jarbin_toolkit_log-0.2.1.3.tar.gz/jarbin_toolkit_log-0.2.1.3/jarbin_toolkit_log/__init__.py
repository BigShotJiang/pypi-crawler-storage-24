#############################
###                       ###
###     Jarbin-ToolKit    ###
###          log          ###
###  ----__init__.py----  ###
###                       ###
###=======================###
### by JARJARBIN's STUDIO ###
#############################


from jarbin_toolkit_log.log import *


__all__ : list[str] = [
    'Log'
]


__author__ : str = 'Nathan Jarjarbin'
__email__ : str = 'nathan.amaraggi@epitech.eu'
__version__ : str = "0.2.1.1"
__license__ : str = "GPL"
