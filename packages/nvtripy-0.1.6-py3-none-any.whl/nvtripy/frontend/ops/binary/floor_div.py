# SPDX-FileCopyrightText: Copyright (c) 2025 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
# SPDX-License-Identifier: Apache-2.0
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
# http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
from nvtripy.common import datatype as dt
from nvtripy.frontend.constraints import GetInput, GetReturn, OneOf
from nvtripy.frontend.ops._registry import register_tensor_method
from nvtripy.frontend.ops.binary.create import create_binary_op
from nvtripy.trace.ops.binary import FloorDiv
from nvtripy.types import TensorLike
from nvtripy.frontend import wrappers


@register_tensor_method("__floordiv__")
@wrappers.interface(
    input_requirements=OneOf(
        GetInput("self").dtype, [dt.float32, dt.float16, dt.bfloat16, dt.bool, dt.int8, dt.int32, dt.int64]
    )
    & (GetInput("other").dtype == GetInput("self").dtype),
    output_guarantees=GetReturn(0).dtype == GetInput("self").dtype,
    convert_to_tensors=True,
)
def __floordiv__(self: "nvtripy.Tensor", other: TensorLike) -> "nvtripy.Tensor":
    """
    Performs an elementwise floor division.

    Args:
        self: Input tensor.
        other: The tensor by which to floor-divide this one.
            It should be broadcast-compatible.

    Returns:
        A new tensor with the broadcasted shape.

    .. code-block:: python
        :linenos:

        a = tp.Tensor([4.0, 6.0])
        b = tp.Tensor([3.0, 4.0])
        output = a // b

        assert np.array_equal(cp.from_dlpack(output).get(), np.array([1.0, 1.0]))
    """
    return create_binary_op(FloorDiv, self, other)


@register_tensor_method("__rfloordiv__")
@wrappers.interface(
    input_requirements=OneOf(
        GetInput("self").dtype, [dt.float32, dt.float16, dt.bfloat16, dt.bool, dt.int4, dt.int8, dt.int32, dt.int64]
    )
    & (GetInput("other").dtype == GetInput("self").dtype),
    output_guarantees=GetReturn(0).dtype == GetInput("self").dtype,
    convert_to_tensors=True,
)
def __rfloordiv__(self: "nvtripy.Tensor", other: TensorLike) -> "nvtripy.Tensor":
    """
    Performs an elementwise floor division.

    Args:
        self: Input tensor.
        other: The tensor to be floor-divided by this one.
            It should be broadcast-compatible.

    Returns:
        A new tensor with the broadcasted shape.

    .. code-block:: python
        :linenos:

        a = 2
        b = tp.Tensor([2.0, 3.0])
        output = a // b

        assert np.array_equal(cp.from_dlpack(output).get(), np.array([1.0, 0.0]))
    """
    return create_binary_op(FloorDiv, other, self)
