#
# SPDX-FileCopyrightText: Copyright (c) 2025 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
# SPDX-License-Identifier: Apache-2.0
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
# http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#


from nvtripy import export
from nvtripy.common import datatype as dt
from nvtripy.frontend import wrappers
from nvtripy.frontend.constraints import GetInput, GetReturn, OneOf
from nvtripy.frontend.ops import utils as op_utils
from nvtripy.frontend.ops._registry import register_tensor_method
from nvtripy.frontend.ops.dequantize import dequantize
from nvtripy.frontend.ops.quantize import quantize
from nvtripy.trace.ops.cast import Cast


@register_tensor_method("cast")
@export.public_api(document_under="operations/functions")
@wrappers.interface(
    input_requirements=(
        ((GetInput("input").dtype != dt.float8) | ~OneOf(GetInput("dtype"), [dt.int4, dt.int8]))
        & ((GetInput("input").dtype != dt.int8) | (GetInput("dtype") != dt.float8))
        & ((GetInput("input").dtype != dt.int4) | ~OneOf(GetInput("dtype"), [dt.float8, dt.int8, dt.int64]))
    ),
    output_guarantees=GetReturn(0).dtype == GetInput("dtype"),
)
def cast(input: "nvtripy.Tensor", dtype: "nvtripy.dtype") -> "nvtripy.Tensor":
    r"""
    Returns a tensor with the contents of the input tensor casted to the specified data type.

    For casts into quantized datatypes (:class:`int4` and :class:`float8`), this performs a per-tensor
    quantization into that datatype with scale 1.0; for casts `from` those datatypes, this performs
    a per-tensor dequantization with scale 1.0. Direct use of :func:`quantize` and :func:`dequantize` allows
    for finer control over these parameters.

    Args:
        input: The input tensor.
        dtype: The desired data type.

    Returns:
        A tensor containing the casted values.

    .. code-block:: python
        :linenos:

        input = tp.Tensor([1, 2])
        output = tp.cast(input, tp.float32)

        assert np.array_equal(cp.from_dlpack(output).get(), np.array([1, 2], dtype=np.float32))

    .. seealso:: :func:`quantize`, :func:`dequantize`
    """

    if input.dtype == dtype:
        return input

    # Note: we check for int8 below because MLIR-TRT can handle it in ordinary conversions
    # even though it is a quantized dtype

    # If given a quantized input, dequantize before converting. If bool is the target dtype,
    # we do still need to quantize int8s because it compiles into an MLIR-TRT *comparison* op
    if op_utils.is_quantized_dtype(input.dtype) and (input.dtype != dt.int8 or dtype == dt.bool):
        dequant_dtype = dt.float32
        input = dequantize(input, 1.0, dequant_dtype)
        if dtype == dequant_dtype:
            return input

    if op_utils.is_quantized_dtype(dtype) and dtype != dt.int8:
        if input.dtype != dt.float32:
            input = op_utils.create_op(Cast, [input], dt.float32)
        return quantize(input, 1.0, dtype)
    return op_utils.create_op(Cast, [input], dtype)
