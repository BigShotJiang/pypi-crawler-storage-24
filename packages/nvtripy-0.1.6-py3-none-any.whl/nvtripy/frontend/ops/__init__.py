#
# SPDX-FileCopyrightText: Copyright (c) 2025 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
# SPDX-License-Identifier: Apache-2.0
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
# http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#

# Here we import only those ops which need to add themselves to the tensor method registry
from nvtripy.frontend.ops.binary import *
from nvtripy.frontend.ops.unary import *
import nvtripy.frontend.ops.matmul
import nvtripy.frontend.ops.shape
import nvtripy.frontend.ops.slice

# Import regular methods that should be available as tensor methods
import nvtripy.frontend.ops.cast
import nvtripy.frontend.ops.copy
import nvtripy.frontend.ops.reshape
import nvtripy.frontend.ops.transpose
import nvtripy.frontend.ops.flatten
import nvtripy.frontend.ops.permute
import nvtripy.frontend.ops.squeeze
import nvtripy.frontend.ops.unsqueeze
