#
# SPDX-FileCopyrightText: Copyright (c) 2025 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
# SPDX-License-Identifier: Apache-2.0
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
# http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#

from typing import Sequence, Tuple, Union

from nvtripy import export
from nvtripy.common.exception import raise_error
from nvtripy.frontend.ops import utils as op_utils
from nvtripy.trace.ops.shape import Shape
from nvtripy.trace.ops.slice import SliceFill, SliceReflect
from nvtripy.types import IntLike
from nvtripy.frontend import wrappers


from nvtripy.common import datatype as dt
from nvtripy.frontend.constraints import GetInput, GetReturn, OneOf


@export.public_api(document_under="operations/functions")
@wrappers.interface(
    input_requirements=OneOf(GetInput("input").dtype, [dt.float32, dt.float16, dt.bool, dt.int32, dt.int64]),
    output_guarantees=GetReturn(0).dtype == GetInput("input").dtype,
)
def pad(
    input: "nvtripy.Tensor",
    pad: Sequence[Tuple[IntLike, IntLike]],
    mode: str = "constant",
    value: Union[int, float] = 0,
) -> "nvtripy.Tensor":
    r"""
    Pads the input tensor.

    Args:
        input: The input tensor.
        pad: A sequence of padding sizes of each dimension. Its length must be equal to the rank
            of ``input``. Each element of ``pad`` is a tuple of integers or :class:`DimensionSize` s ``(low, high)``,
            which represents the padding sizes before the lowest index and after the highest index at
            the corresponding dimension.
        mode: The padding mode. Must be one of:

            - ``"constant"``: Pads with a constant value (default).
            - ``"reflect"``: Pads by reflecting the input tensor.
        value: The padding value for "constant" mode. Has no effect for other modes.

    Returns:
        The padded tensor.

    .. code-block:: python
        :linenos:
        :caption: Constant Padding

        input = tp.reshape(tp.arange(6, dtype=tp.float32), (2, 3))
        output = tp.pad(input, [(1, 0), (0, 1)])

        input_np = np.arange(6, dtype=np.float32).reshape((2, 3)) # doc: omit
        expected = np.pad(input_np, ((1, 0), (0, 1))) # doc: omit
        assert np.array_equal(cp.from_dlpack(output).get(), expected)

    .. code-block:: python
        :linenos:
        :caption: Reflect Padding

        input = tp.reshape(tp.arange(6, dtype=tp.float32), (2, 3))
        output = tp.pad(input, [(1, 1), (1, 1)], mode="reflect")

        input_np = np.arange(6, dtype=np.float32).reshape((2, 3)) # doc: omit
        expected = np.pad(input_np, ((1, 1), (1, 1)), mode="reflect") # doc: omit
        assert np.array_equal(cp.from_dlpack(output).get(), expected)
    """
    from nvtripy.frontend.ops.cast import cast
    from nvtripy.frontend.tensor import Tensor

    if len(pad) != input.rank:
        raise_error(
            "`pad` length must equal to the rank of `input`.",
            [f"Got pad={pad}, ", f" input's rank={input.rank}"],
        )

    supported_modes = {"constant", "reflect"}
    if mode not in supported_modes:
        raise_error(
            "Unsupported padding mode.",
            [f"Got mode={mode}, while supported modes are {supported_modes}"],
        )

    padding_lows, padding_highs = list(zip(*pad))
    padding_lows = op_utils.tensor_from_shape_like(padding_lows)
    padding_highs = op_utils.tensor_from_shape_like(padding_highs)
    starts = -padding_lows

    # Not using input.shape because we need a `Tensor` here
    input_shape = op_utils.create_op(Shape, [input])
    sizes = input_shape + padding_lows + padding_highs
    steps = op_utils.tensor_from_shape_like([1] * input.rank)

    inputs = [input, starts, sizes, steps]
    if mode == "constant":
        inputs.append(cast(Tensor(value), dtype=input.dtype))

    OpType = {"constant": SliceFill, "reflect": SliceReflect}[mode]
    return op_utils.create_op(OpType, inputs)
