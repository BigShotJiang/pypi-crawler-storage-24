# tp_common.devtools

Инструменты для создания и настройки проектов на базе tp-common.

- Подробная схема линтеров/форматтеров и процессов: `src/tp_common/devtools/LINTERS_AND_FORMATTERS.md`.

## project_scaffold — новый проект, инициализация и обновление конфигурации

Скрипт поддерживает три сценария. Все команды кроссплатформенные (Linux, macOS, Windows).

### 1. Создание нового проекта или инициализация существующей директории (curl)

- **Нет директории с таким именем** — создаётся новый проект (Poetry, `package-mode = false`), копируются конфиги, при отсутствии репозитория выполняется `git init`, затем `poetry install` и `pre-commit install`.
- **Директория уже есть** (например, только что клонированный репо с одним README) — выполняется инициализация в ней: при отсутствии `pyproject.toml` создаётся минимальный с tp-common, подтягиваются конфиги из шаблона, dev-зависимости, при отсутствии репозитория — `git init`, затем `poetry install` и `pre-commit install`.

**Linux / macOS:**

```bash
curl -sSL "https://gitlab.8525.ru/modules/tp-common/-/raw/main/src/tp_common/devtools/project_scaffold.py" | python3 - PROJECT_NAME
```

**Windows (PowerShell):**

```powershell
(Invoke-WebRequest -Uri "https://gitlab.8525.ru/modules/tp-common/-/raw/main/src/tp_common/devtools/project_scaffold.py").Content | python - PROJECT_NAME
```

**Windows (через сохранение скрипта):**

```cmd
curl -sSL "https://gitlab.8525.ru/modules/tp-common/-/raw/main/src/tp_common/devtools/project_scaffold.py" | python - create PROJECT_NAME
```

### 2. Инициализация уже существующего проекта

Если проект уже создан через `poetry new` (или вручную с `pyproject.toml`):

```bash
poetry new my-project && cd my-project
poetry add tp-common
poetry run tp-bootstrap
```

Без аргументов `tp-bootstrap` выполняет **init** в текущей директории. При этом:

- подтягиваются все файлы шаблона (pre-commit, alembic, .gitignore, ruff, mypy, pyright);
- в `pyproject.toml` добавляются `package-mode = false` и dev-зависимости (линтеры, форматеры);
- при отсутствии репозитория выполняется `git init` (чтобы pre-commit install сработал);
- выполняются `poetry lock`, `poetry install` и `poetry run pre-commit install`.

Явно:

```bash
poetry run tp-bootstrap init [--target .] [-f]
```

`-f` перезаписывает существующие конфиги из шаблона.

### 3. Обновление конфигурации

Подтянуть конфиги из шаблона (например, при каждом коммите):

```bash
poetry run tp-bootstrap update [--target .] [-f]
```

или:

```bash
poetry run python -m tp_common.devtools.project_scaffold update [--target .] [-f]
```

При **update** без `-f` действует политика по файлам: конфиги линтеров и pre-commit, alembic/script.py.mako, alembic/scripts/* и т.д. всегда обновляются из шаблона; `alembic/env.py` и `alembic/init_db.py` не перезаписываются (проектная специфика); `.gitignore` мержится с шаблоном (шаблон + уникальные строки из проекта). С **`-f`** все файлы шаблона перезаписываются.

### Требования

- Python 3.12+
- [Poetry](https://python-poetry.org/) установлен и доступен как `python -m poetry`.
