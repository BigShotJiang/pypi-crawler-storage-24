#!/usr/bin/env python3
"""
Скрипт для управления базой данных.
Динамически импортирует все модели и создает/удаляет таблицы.

Использование:
    python init_db.py                 # Только создание таблиц
    python init_db.py --drop          # Удалить и создать таблицы заново
"""

import argparse
import asyncio
import importlib
import sys
import time
from pathlib import Path

# Код под src/ импортируется как top-level (from config import …)
_project_root = Path(__file__).resolve().parents[1]
_src_root = _project_root / "src"
if str(_src_root) not in sys.path:
    sys.path.insert(0, str(_src_root))

from config import config
from sqlalchemy.ext.asyncio import create_async_engine


def import_all_models():
    """Динамический импорт всех моделей из domain/**/model.py"""
    print("Импортируем модели...")
    imported_count = 0
    domain_path = _project_root / "src" / "domain"
    if not domain_path.is_dir():
        print(f"  Нет каталога domain: {domain_path}")
        return

    for model_file in sorted(domain_path.rglob("model.py")):
        rel = model_file.relative_to(_src_root)
        parts = rel.with_suffix("").parts
        if any(p.startswith("_") for p in parts):
            continue
        module_name = ".".join(parts)
        try:
            importlib.import_module(module_name)
            print(f"  ✓ {module_name}")
            imported_count += 1
        except ImportError as e:
            print(f"  ✗ {module_name}: {e}")

    print(f"Импортировано {imported_count} моделей")


async def drop_all_tables():
    """Удаление всех таблиц"""
    print("Удаляем все таблицы...")

    # Динамически импортируем все модели
    import_all_models()

    # Импортируем BaseModel после импорта всех моделей
    from domain.shared.models.base_models import BaseModel

    # Создаем движок
    engine_url = config.get_async_postgres_url_connection()
    print(f"Подключение к базе: {engine_url.split('@')[1]}")  # Скрываем пароль

    engine = create_async_engine(engine_url, echo=True)

    try:
        # Удаляем все таблицы
        async with engine.begin() as conn:
            await conn.run_sync(BaseModel.metadata.drop_all)

        print("Все таблицы удалены!")

    except Exception as e:
        print(f"Ошибка при удалении таблиц: {e}")
        raise
    finally:
        await engine.dispose()


async def create_tables():
    """Создание всех таблиц"""
    print("Создаем таблицы...")

    # Динамически импортируем все модели
    import_all_models()

    # Импортируем BaseModel после импорта всех моделей
    from domain.shared.models.base_models import BaseModel

    # Создаем движок
    engine_url = config.get_async_postgres_url_connection()
    print(f"Подключение к базе: {engine_url.split('@')[1]}")  # Скрываем пароль

    engine = create_async_engine(engine_url, echo=True)

    try:
        # Создаем все таблицы
        async with engine.begin() as conn:
            await conn.run_sync(BaseModel.metadata.create_all)

        print("Таблицы созданы успешно!")

    except Exception as e:
        print(f"Ошибка при создании таблиц: {e}")
        raise
    finally:
        await engine.dispose()


async def recreate_database(drop_first=False):
    """Пересоздание базы данных"""
    if drop_first:
        await drop_all_tables()
        print()  # Пустая строка для разделения

    await create_tables()


async def main():
    """Основная функция"""
    parser = argparse.ArgumentParser(description="Управление базой данных")
    parser.add_argument(
        "--drop", action="store_true", help="Удалить все таблицы перед созданием новых"
    )

    args = parser.parse_args()

    print("=" * 50)
    if args.drop:
        print("ПЕРЕСОЗДАНИЕ БАЗЫ ДАННЫХ")
    else:
        print("СОЗДАНИЕ ТАБЛИЦ")
    print("=" * 50)

    start_time = time.time()

    try:
        if args.drop:
            print("ВНИМАНИЕ: Все данные будут удалены!")
            confirm = input("Продолжить? (yes/no): ").lower().strip()
            if confirm not in ["yes", "y", "да", "д"]:
                print("Операция отменена.")
                return

        await recreate_database(drop_first=args.drop)

        elapsed_time = time.time() - start_time
        print(f"\nГотово! Время выполнения: {elapsed_time:.2f} секунд")

    except Exception as e:
        print(f"\nОшибка: {e}")
        sys.exit(1)


if __name__ == "__main__":
    asyncio.run(main())
