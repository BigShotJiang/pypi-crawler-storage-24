from tp_common.kafka.connector import KafkaConnector


def create_kafka_connector(kafka_url: str) -> KafkaConnector:
    return KafkaConnector(url=kafka_url)
