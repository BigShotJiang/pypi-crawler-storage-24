"""Composition root: связывает настройки и инфраструктурные адаптеры."""

from config import config
from infrastructure.db import (
    create_async_engine_from_url,
    create_async_session_factory,
)
from infrastructure.db import make_get_async_session
from infrastructure.kafka.kafka import create_kafka_connector
from infrastructure.redis.redis import create_redis_client
from infrastructure.session_manager import SessionManager

async_engine = create_async_engine_from_url(
    config.get_async_postgres_url_connection(),
    echo=config.is_dev(),
)
# Фабрика сессий БД: репозитории, raw SQL через AsyncSession.
async_session_factory = create_async_session_factory(async_engine)

# Транзакции вне HTTP (скрипты, фоновые задачи): async with session_manager.session_scope().
session_manager = SessionManager(async_session_factory)

# Внедрение сессии в обработчики API: session = Depends(get_async_session).
get_async_session = make_get_async_session(async_session_factory)

# Клиент Redis: кеш, блокировки, pub/sub — по задаче сервиса.
redis_client = create_redis_client(config.get_redis_url())

# Подключение к Kafka: продюсер/консьюмер событий.
kafka_connector = create_kafka_connector(config.KAFKA_URL)
