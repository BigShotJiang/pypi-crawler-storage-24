import os

from pydantic_settings import BaseSettings, SettingsConfigDict
from tp_common.tp_logger.schemas import EnvironmentType
from tp_common.utils import parse_url_with_auth, parse_url_with_token

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
ENV_FILE = os.path.join(BASE_DIR, "..", ".env")


class Config(BaseSettings):
    """
    Класс настроек приложения.
    Все переменные можно передавать через переменные окружения или .env-файл.
    Обязательные значения должны быть заполнены.
    """

    ENV_TYPE: EnvironmentType = EnvironmentType.DEV
    KAFKA_URL: str = "sasl_plaintext://user:user@192.168.0.0:9094"

    OFDATA_API_URL: str = "https://token@business.ru"
    TOUCH_MED_API_URL: str = "https://logis;password@business.ru"

    REDIS_URL: str = "192.168.0.0:6379/2"

    POSTGRES_URL: str = "postgresql+asyncpg://user:pass@127.0.0.1:5432/app"

    def get_redis_url(self) -> str:
        return "redis://" + self.REDIS_URL

    def get_async_postgres_url_connection(self) -> str:
        """URL для SQLAlchemy async (драйвер asyncpg)."""
        return self.POSTGRES_URL

    def is_dev(self) -> bool:
        return self.ENV_TYPE in (EnvironmentType.DEV, EnvironmentType.LOCAL)

    def is_staging(self) -> bool:
        return self.ENV_TYPE == EnvironmentType.STAGING

    def is_prod(self) -> bool:
        return self.ENV_TYPE == EnvironmentType.PROD

    def parse_touch_api_url(self) -> tuple[str, str, str]:
        """Возвращает (base_url, login, password)"""
        return parse_url_with_auth(self.TOUCH_MED_API_URL)

    def parse_ofdata_api_url(self) -> tuple[str, str]:
        """Возвращает (base_url, token)."""
        return parse_url_with_token(self.OFDATA_API_URL)

    model_config = SettingsConfigDict(env_file=ENV_FILE, env_file_encoding="utf-8")


config = Config()
