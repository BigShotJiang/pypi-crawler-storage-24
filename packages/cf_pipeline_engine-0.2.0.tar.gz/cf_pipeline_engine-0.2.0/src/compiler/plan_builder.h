﻿#ifndef CF_PLAN_BUILDER_H
#define CF_PLAN_BUILDER_H

#include <string>
#include <vector>

#include "compiler/rdf_loader.h"
#include "compiler/pipeline_parser.h"
#include "plugin_loader/plugin_loader.h"
#include "runtime/builtin_steps.h"
#include "runtime/execution_plan.h"

namespace cf {

struct PlanBuildOptions {
  bool allow_missing_inputs = true;
};

bool build_execution_plan(
  const PipelineSpec& pipeline,
  const StepCatalog& catalog,
  PluginRegistry& plugins,
  ExecutionPlan& out_plan,
  std::string& error,
  const PlanBuildOptions& options = {}
);

}  // namespace cf

#endif

