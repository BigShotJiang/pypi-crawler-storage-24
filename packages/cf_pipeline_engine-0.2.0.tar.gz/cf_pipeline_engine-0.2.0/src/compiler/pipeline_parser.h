#ifndef CF_PIPELINE_PARSER_H
#define CF_PIPELINE_PARSER_H

#include <string>
#include <unordered_map>
#include <vector>

namespace cf {

struct PipelineNodeSpec {
  std::string id;
  std::string step_iri;
  std::unordered_map<std::string, std::string> parameters_json;
  std::unordered_map<std::string, std::string> parameters_json_by_iri;
};

struct PipelineConnectionSpec {
  std::string from_node;
  std::string from_port_key;
  std::string to_node;
  std::string to_port_key;
  std::string to_port_label;
};

struct PipelineSpec {
  std::vector<PipelineNodeSpec> nodes;
  std::vector<PipelineConnectionSpec> connections;
  std::vector<std::string> steps_files;
  std::vector<std::string> plugin_dirs;
};

bool load_pipeline_spec(const std::string& path, PipelineSpec& out, std::string& error);

}  // namespace cf

#endif
