﻿#ifndef CF_SIGNATURE_H
#define CF_SIGNATURE_H

#include <string>
#include <vector>

#include "compiler/rdf_loader.h"

namespace cf {

struct SignatureSpec {
  std::string step_iri;
  std::vector<std::string> parameter_keys;
  std::vector<std::string> input_keys;
  std::vector<std::string> output_keys;
};

SignatureSpec build_signature_spec(const StepDef& step);
std::string signature_spec_json(const SignatureSpec& spec);
std::string signature_hash(const SignatureSpec& spec);

}  // namespace cf

#endif

