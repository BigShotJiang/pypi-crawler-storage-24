﻿#ifndef CF_VECTOR_F64_RUNTIME_H
#define CF_VECTOR_F64_RUNTIME_H

#include <stddef.h>

#include "cf_step_abi.h"
#include "cf_vector_f64.h"

namespace cf {

inline const CfVectorF64* vector_f64_from_handle(const CfValueHandle* handle) {
  if (!handle || handle->storage_type != CF_STORAGE_VECTOR_F64) return nullptr;
  return reinterpret_cast<const CfVectorF64*>(handle->data);
}

inline double* vector_f64_data(const CfValueHandle* handle) {
  const CfVectorF64* vector = vector_f64_from_handle(handle);
  return vector ? vector->data : nullptr;
}

inline size_t vector_f64_length(const CfValueHandle* handle) {
  const CfVectorF64* vector = vector_f64_from_handle(handle);
  return vector ? vector->length : 0;
}

}  // namespace cf

#endif
