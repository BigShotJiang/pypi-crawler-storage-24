#ifndef CF_BUILTIN_STEPS_H
#define CF_BUILTIN_STEPS_H

#include <string>

#include "cf_step_abi.h"
#include "runtime/execution_plan.h"

namespace cf {

constexpr const char* kDataHiveParquetSinkStepIri = "https://cogniflow.odea-project.org/cf#basic-sinks/DataHiveParquetSinkStep";
constexpr const char* kOpcuaReaderStepIri = "https://cogniflow.odea-project.org/cf#basic-io/OpcuaReaderStep";

PlanNodeExecutionKind classify_builtin_step(const std::string& step_iri);

CfStatusCode validate_builtin_step(const PlanNode& node, CfCallContext* ctx, CfValidationReport* report);

CfStatusCode execute_builtin_step(
  const PlanNode& node,
  CfCallContext* ctx,
  const CfValueHandle* inputs,
  size_t n_inputs,
  CfValueHandle* outputs,
  size_t n_outputs);

}  // namespace cf

#endif
