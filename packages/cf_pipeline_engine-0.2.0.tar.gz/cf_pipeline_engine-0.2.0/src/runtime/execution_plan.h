﻿#ifndef CF_EXECUTION_PLAN_H
#define CF_EXECUTION_PLAN_H

#include <memory>
#include <string>
#include <unordered_map>
#include <vector>

#include "cf_step_abi.h"
#include "compiler/rdf_loader.h"

namespace cf {

enum class PlanNodeExecutionKind {
  kPlugin = 0,
  kBuiltinDataHiveSink,
};

struct EdgeSlot {
  size_t id = 0;
  int from_node = -1;
  int from_output = -1;
  int to_node = -1;
  int to_input = -1;
  std::string label;
  std::string from_port_key;
  CfValueHandle value{};
  bool filled = false;
};

struct PlanNode {
  std::string node_id;
  std::string step_iri;
  PlanNodeExecutionKind execution_kind = PlanNodeExecutionKind::kPlugin;
  const CfStepVTable* vtable = nullptr;
  StepDef step_def;
  size_t thread_budget = 1;
  size_t scheduler_cost = 1;
  std::vector<CfValueHandle> params;
  std::vector<int> input_edge_ids;
  std::vector<int> output_edge_ids;
};

struct ExecutionPlan {
  std::vector<PlanNode> nodes;
  std::vector<EdgeSlot> edges;
  std::vector<std::vector<int>> levels;
  std::vector<std::unique_ptr<uint8_t[]>> owned_buffers;
  std::vector<std::unique_ptr<uint8_t[]>> execution_owned_buffers;
};

}  // namespace cf

#endif

