#include "common/sha256.h"

#include <array>
#include <cstring>
#include <cstdint>

namespace {

constexpr uint32_t kSha256Init[8] = {
  0x6a09e667u, 0xbb67ae85u, 0x3c6ef372u, 0xa54ff53au,
  0x510e527fu, 0x9b05688cu, 0x1f83d9abu, 0x5be0cd19u
};

constexpr uint32_t kSha256K[64] = {
  0x428a2f98u, 0x71374491u, 0xb5c0fbcfu, 0xe9b5dba5u,
  0x3956c25bu, 0x59f111f1u, 0x923f82a4u, 0xab1c5ed5u,
  0xd807aa98u, 0x12835b01u, 0x243185beu, 0x550c7dc3u,
  0x72be5d74u, 0x80deb1feu, 0x9bdc06a7u, 0xc19bf174u,
  0xe49b69c1u, 0xefbe4786u, 0x0fc19dc6u, 0x240ca1ccu,
  0x2de92c6fu, 0x4a7484aau, 0x5cb0a9dcu, 0x76f988dau,
  0x983e5152u, 0xa831c66du, 0xb00327c8u, 0xbf597fc7u,
  0xc6e00bf3u, 0xd5a79147u, 0x06ca6351u, 0x14292967u,
  0x27b70a85u, 0x2e1b2138u, 0x4d2c6dfcu, 0x53380d13u,
  0x650a7354u, 0x766a0abbu, 0x81c2c92eu, 0x92722c85u,
  0xa2bfe8a1u, 0xa81a664bu, 0xc24b8b70u, 0xc76c51a3u,
  0xd192e819u, 0xd6990624u, 0xf40e3585u, 0x106aa070u,
  0x19a4c116u, 0x1e376c08u, 0x2748774cu, 0x34b0bcb5u,
  0x391c0cb3u, 0x4ed8aa4au, 0x5b9cca4fu, 0x682e6ff3u,
  0x748f82eeu, 0x78a5636fu, 0x84c87814u, 0x8cc70208u,
  0x90befffau, 0xa4506cebu, 0xbef9a3f7u, 0xc67178f2u
};

inline uint32_t rotr(uint32_t x, uint32_t n) {
  return (x >> n) | (x << (32 - n));
}

struct Sha256Ctx {
  uint64_t bit_len = 0;
  std::array<uint32_t, 8> state{};
  std::array<uint8_t, 64> buffer{};
  size_t buffer_len = 0;
};

void sha256_transform(Sha256Ctx& ctx, const uint8_t* data) {
  uint32_t m[64];
  for (int i = 0; i < 16; ++i) {
    m[i] = (static_cast<uint32_t>(data[i * 4]) << 24) |
           (static_cast<uint32_t>(data[i * 4 + 1]) << 16) |
           (static_cast<uint32_t>(data[i * 4 + 2]) << 8) |
           (static_cast<uint32_t>(data[i * 4 + 3]));
  }
  for (int i = 16; i < 64; ++i) {
    uint32_t s0 = rotr(m[i - 15], 7) ^ rotr(m[i - 15], 18) ^ (m[i - 15] >> 3);
    uint32_t s1 = rotr(m[i - 2], 17) ^ rotr(m[i - 2], 19) ^ (m[i - 2] >> 10);
    m[i] = m[i - 16] + s0 + m[i - 7] + s1;
  }

  uint32_t a = ctx.state[0];
  uint32_t b = ctx.state[1];
  uint32_t c = ctx.state[2];
  uint32_t d = ctx.state[3];
  uint32_t e = ctx.state[4];
  uint32_t f = ctx.state[5];
  uint32_t g = ctx.state[6];
  uint32_t h = ctx.state[7];

  for (int i = 0; i < 64; ++i) {
    uint32_t s1 = rotr(e, 6) ^ rotr(e, 11) ^ rotr(e, 25);
    uint32_t ch = (e & f) ^ (~e & g);
    uint32_t temp1 = h + s1 + ch + kSha256K[i] + m[i];
    uint32_t s0 = rotr(a, 2) ^ rotr(a, 13) ^ rotr(a, 22);
    uint32_t maj = (a & b) ^ (a & c) ^ (b & c);
    uint32_t temp2 = s0 + maj;

    h = g;
    g = f;
    f = e;
    e = d + temp1;
    d = c;
    c = b;
    b = a;
    a = temp1 + temp2;
  }

  ctx.state[0] += a;
  ctx.state[1] += b;
  ctx.state[2] += c;
  ctx.state[3] += d;
  ctx.state[4] += e;
  ctx.state[5] += f;
  ctx.state[6] += g;
  ctx.state[7] += h;
}

void sha256_init(Sha256Ctx& ctx) {
  ctx.state = {kSha256Init[0], kSha256Init[1], kSha256Init[2], kSha256Init[3],
               kSha256Init[4], kSha256Init[5], kSha256Init[6], kSha256Init[7]};
  ctx.bit_len = 0;
  ctx.buffer_len = 0;
}

void sha256_update(Sha256Ctx& ctx, const uint8_t* data, size_t len) {
  for (size_t i = 0; i < len; ++i) {
    ctx.buffer[ctx.buffer_len++] = data[i];
    if (ctx.buffer_len == 64) {
      sha256_transform(ctx, ctx.buffer.data());
      ctx.bit_len += 512;
      ctx.buffer_len = 0;
    }
  }
}

std::array<uint8_t, 32> sha256_final(Sha256Ctx& ctx) {
  size_t i = ctx.buffer_len;

  if (ctx.buffer_len < 56) {
    ctx.buffer[i++] = 0x80;
    while (i < 56) ctx.buffer[i++] = 0x00;
  } else {
    ctx.buffer[i++] = 0x80;
    while (i < 64) ctx.buffer[i++] = 0x00;
    sha256_transform(ctx, ctx.buffer.data());
    std::fill(ctx.buffer.begin(), ctx.buffer.end(), 0);
  }

  ctx.bit_len += ctx.buffer_len * 8;
  ctx.buffer[63] = static_cast<uint8_t>(ctx.bit_len);
  ctx.buffer[62] = static_cast<uint8_t>(ctx.bit_len >> 8);
  ctx.buffer[61] = static_cast<uint8_t>(ctx.bit_len >> 16);
  ctx.buffer[60] = static_cast<uint8_t>(ctx.bit_len >> 24);
  ctx.buffer[59] = static_cast<uint8_t>(ctx.bit_len >> 32);
  ctx.buffer[58] = static_cast<uint8_t>(ctx.bit_len >> 40);
  ctx.buffer[57] = static_cast<uint8_t>(ctx.bit_len >> 48);
  ctx.buffer[56] = static_cast<uint8_t>(ctx.bit_len >> 56);
  sha256_transform(ctx, ctx.buffer.data());

  std::array<uint8_t, 32> hash{};
  for (i = 0; i < 4; ++i) {
    hash[i]      = static_cast<uint8_t>((ctx.state[0] >> (24 - i * 8)) & 0xff);
    hash[i + 4]  = static_cast<uint8_t>((ctx.state[1] >> (24 - i * 8)) & 0xff);
    hash[i + 8]  = static_cast<uint8_t>((ctx.state[2] >> (24 - i * 8)) & 0xff);
    hash[i + 12] = static_cast<uint8_t>((ctx.state[3] >> (24 - i * 8)) & 0xff);
    hash[i + 16] = static_cast<uint8_t>((ctx.state[4] >> (24 - i * 8)) & 0xff);
    hash[i + 20] = static_cast<uint8_t>((ctx.state[5] >> (24 - i * 8)) & 0xff);
    hash[i + 24] = static_cast<uint8_t>((ctx.state[6] >> (24 - i * 8)) & 0xff);
    hash[i + 28] = static_cast<uint8_t>((ctx.state[7] >> (24 - i * 8)) & 0xff);
  }
  return hash;
}

std::string bytes_to_hex(const uint8_t* data, size_t len) {
  static const char kHex[] = "0123456789abcdef";
  std::string out;
  out.resize(len * 2);
  for (size_t i = 0; i < len; ++i) {
    out[i * 2] = kHex[(data[i] >> 4) & 0xf];
    out[i * 2 + 1] = kHex[data[i] & 0xf];
  }
  return out;
}

}  // namespace

namespace cf {

std::string sha256_hex(const std::vector<uint8_t>& data) {
  Sha256Ctx ctx;
  sha256_init(ctx);
  if (!data.empty()) {
    sha256_update(ctx, data.data(), data.size());
  }
  auto hash = sha256_final(ctx);
  return bytes_to_hex(hash.data(), hash.size());
}

std::string sha256_hex(const std::string& data) {
  Sha256Ctx ctx;
  sha256_init(ctx);
  if (!data.empty()) {
    sha256_update(ctx, reinterpret_cast<const uint8_t*>(data.data()), data.size());
  }
  auto hash = sha256_final(ctx);
  return bytes_to_hex(hash.data(), hash.size());
}

}  // namespace cf
