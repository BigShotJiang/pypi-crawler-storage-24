#ifndef CF_SHA256_H
#define CF_SHA256_H

#include <string>
#include <vector>
#include <cstdint>

namespace cf {

std::string sha256_hex(const std::vector<uint8_t>& data);
std::string sha256_hex(const std::string& data);

}  // namespace cf

#endif
