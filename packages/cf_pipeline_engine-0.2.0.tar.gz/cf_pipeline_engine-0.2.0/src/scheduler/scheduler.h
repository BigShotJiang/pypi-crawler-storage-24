#ifndef CF_SCHEDULER_H
#define CF_SCHEDULER_H

#include <string>

#include "runtime/execution_plan.h"
#include "runtime/concurrency_controller.h"

namespace cf {

struct ExecutionResult {
  bool ok = false;
  std::string error;
};

ExecutionResult execute_plan(ExecutionPlan& plan, const ConcurrencyOptions& options);
ExecutionResult execute_plan(ExecutionPlan& plan, size_t threads);

}  // namespace cf

#endif
