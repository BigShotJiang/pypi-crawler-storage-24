#ifndef CF_THREAD_POOL_H
#define CF_THREAD_POOL_H

#include <condition_variable>
#include <functional>
#include <mutex>
#include <queue>
#include <thread>
#include <vector>

namespace cf {

class ThreadPool {
 public:
  explicit ThreadPool(size_t threads);
  ~ThreadPool();

  void enqueue(std::function<void()> fn);
  void wait_for_idle();

 private:
  void worker_loop();

  std::mutex mutex_;
  std::condition_variable cv_;
  std::condition_variable idle_cv_;
  std::queue<std::function<void()>> queue_;
  std::vector<std::thread> workers_;
  bool stop_ = false;
  size_t active_ = 0;
};

}  // namespace cf

#endif
