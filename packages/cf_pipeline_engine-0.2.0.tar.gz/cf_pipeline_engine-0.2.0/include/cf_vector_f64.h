﻿#ifndef CF_VECTOR_F64_H
#define CF_VECTOR_F64_H

#include <stddef.h>

#ifdef __cplusplus
extern "C" {
#endif

typedef struct CfVectorF64 {
  double* data;
  size_t length;
} CfVectorF64;

#ifdef __cplusplus
}
#endif

#endif
