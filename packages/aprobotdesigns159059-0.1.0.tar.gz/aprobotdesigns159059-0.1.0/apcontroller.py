# region PID controller class
class PID_Controller:
    def __init__(self, iKp, iKi, iKd, iSP, iLMN_HLM, iLMN_LLM):
        self.Kp = iKp  # proportional term / 0.0 = switched off
        self.Ki = iKi  # integral term / 0.0 = switched off
        self.Kd = iKd  # derivate term / 0.0 = switched off
        self.SP = iSP  # setpoint
        self.prev_ER = 0  # error from previous scan
        self.integral = 0
        self.derivative = 0
        self.LMN_HLM = iLMN_HLM  # LMN high Limit
        self.LMN_LLM = iLMN_LLM  # LMN low limit

    def compute(self, iPV, iTimestep):
        # Calculate error
        ER = self.SP - iPV

        # Proportional term
        P_out = self.Kp * ER

        # Integral term
        self.integral += ER * iTimestep
        I_out = self.Ki * self.integral

        # Derivative term
        self.derivative = (ER - self.prev_ER) / iTimestep
        D_out = self.Kd * self.derivative

        # Compute total output
        oLMN = P_out + I_out + D_out

        # Correct LMN if not in range of high and low limits
        if oLMN > self.LMN_HLM:
            oLMN = self.LMN_HLM
        elif oLMN < self.LMN_LLM:
            oLMN = self.LMN_LLM

        # Update previous error
        self.prev_ER = ER

        return oLMN
