# flexivddk/__init__.py

"""
Python wrapper of Flexiv DDK C++ library (https://github.com/flexivrobotics/flexiv_ddk)

    Example usage: https://github.com/flexivrobotics/flexiv_ddk/tree/main/example_py

"""


# start delvewheel patch
def _delvewheel_patch_1_12_0():
    import os
    if os.path.isdir(libs_dir := os.path.abspath(os.path.join(os.path.dirname(__file__), os.pardir, 'flexivddk.libs'))):
        os.add_dll_directory(libs_dir)


_delvewheel_patch_1_12_0()
del _delvewheel_patch_1_12_0
# end delvewheel patch

__version__ = "1.3.0"
__author__ = "Flexiv Ltd"

from .flexivddk import *
