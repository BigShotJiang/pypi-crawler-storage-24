from bluefox_test.setup import bluefox_test_setup


class _FakeBase:
    """Minimal stand-in for a SQLAlchemy DeclarativeBase."""

    class metadata:
        @staticmethod
        async def create_all(conn):
            pass


def test_bluefox_test_setup__returns_core_fixtures():
    result = bluefox_test_setup(
        base=_FakeBase,
        app_factory=None,
    )
    assert "infra" in result
    assert "safe_env" in result
    assert "engine" in result
    assert "db" in result
    assert callable(result["infra"])
    assert callable(result["db"])


def test_bluefox_test_setup__no_app_client_when_factory_none():
    result = bluefox_test_setup(
        base=_FakeBase,
        app_factory=None,
    )
    assert "app" not in result
    assert "client" not in result


def test_bluefox_test_setup__includes_bind_fixtures():
    result = bluefox_test_setup(
        base=_FakeBase,
        binds={"analytics": "some.module:AnalyticsBase"},
        app_factory=None,
    )
    assert "bind_engines" in result
    assert "db_analytics" in result


def test_bluefox_test_setup__includes_factory_fixtures():
    """Factory fixtures from discover_and_collect_fixtures are merged in."""
    # No src/ dir exists, so no factory fixtures will be found,
    # but the function should still work without error.
    result = bluefox_test_setup(
        base=_FakeBase,
        app_factory=None,
        src_root="nonexistent_dir",
    )
    # Core fixtures should still be present
    assert "db" in result
    assert "engine" in result
