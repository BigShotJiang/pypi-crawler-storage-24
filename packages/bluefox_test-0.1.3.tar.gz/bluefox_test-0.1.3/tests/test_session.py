import pytest
import pytest_asyncio
from sqlalchemy import String, select
from sqlalchemy.orm import DeclarativeBase, Mapped, mapped_column

from bluefox_test.session import create_test_engine, scoped_test_session


class Base(DeclarativeBase):
    pass


class Item(Base):
    __tablename__ = "test_items"
    id: Mapped[int] = mapped_column(primary_key=True)
    name: Mapped[str] = mapped_column(String(50))


@pytest_asyncio.fixture(scope="session")
async def session_engine(pg_container):
    async_url, _ = pg_container
    eng = create_test_engine(async_url)
    async with eng.begin() as conn:
        await conn.run_sync(Base.metadata.create_all)
    yield eng
    await eng.dispose()


async def test_scoped_test_session__provides_working_session(session_engine):
    async with scoped_test_session(session_engine) as session:
        item = Item(name="test_item")
        session.add(item)
        await session.flush()
        assert item.id is not None

        result = await session.execute(select(Item).where(Item.id == item.id))
        found = result.scalar_one()
        assert found.name == "test_item"


async def test_scoped_test_session__rolls_back_after_exit(session_engine):
    # Insert a row inside a scoped session
    async with scoped_test_session(session_engine) as session:
        item = Item(name="will_disappear")
        session.add(item)
        await session.flush()
        item_id = item.id

    # Open a new session — the row should be gone
    async with scoped_test_session(session_engine) as session:
        result = await session.execute(select(Item).where(Item.id == item_id))
        found = result.scalar_one_or_none()
        assert found is None


async def test_scoped_test_session__survives_session_commit(session_engine):
    async with scoped_test_session(session_engine) as session:
        item1 = Item(name="first")
        session.add(item1)
        await session.commit()

        item2 = Item(name="second")
        session.add(item2)
        await session.flush()

        # Both should be visible within the session
        result = await session.execute(select(Item))
        items = result.scalars().all()
        names = {i.name for i in items}
        assert "first" in names
        assert "second" in names

    # After exit, both should be gone
    async with scoped_test_session(session_engine) as session:
        result = await session.execute(select(Item))
        items = result.scalars().all()
        assert len(items) == 0


async def test_scoped_test_session__expire_on_commit_false(session_engine):
    async with scoped_test_session(session_engine) as session:
        item = Item(name="persist_after_commit")
        session.add(item)
        await session.commit()

        # Should NOT raise DetachedInstanceError
        assert item.name == "persist_after_commit"
