from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel
from sqlalchemy.ext.asyncio import AsyncSession

from app.deps import get_session
from auth.service import (
    create_access_token,
    create_user,
    get_user_by_email,
    verify_password,
)

router = APIRouter()


class RegisterRequest(BaseModel):
    email: str
    name: str
    password: str


class LoginRequest(BaseModel):
    email: str
    password: str


class TokenResponse(BaseModel):
    access_token: str
    token_type: str = "bearer"


class UserResponse(BaseModel):
    id: int
    email: str
    name: str
    is_active: bool


@router.post("/register", response_model=UserResponse)
async def register(body: RegisterRequest, session: AsyncSession = Depends(get_session)):
    existing = await get_user_by_email(session, body.email)
    if existing:
        raise HTTPException(status_code=409, detail="Email already registered")
    user = await create_user(session, body.email, body.name, body.password)
    await session.commit()
    return UserResponse(id=user.id, email=user.email, name=user.name, is_active=user.is_active)


@router.post("/login", response_model=TokenResponse)
async def login(body: LoginRequest, session: AsyncSession = Depends(get_session)):
    user = await get_user_by_email(session, body.email)
    if not user or not verify_password(body.password, user.password_hash):
        raise HTTPException(status_code=401, detail="Invalid credentials")
    token = create_access_token(user.id)
    return TokenResponse(access_token=token)
