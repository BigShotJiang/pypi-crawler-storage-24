import pytest
from sqlalchemy.exc import IntegrityError


@pytest.mark.asyncio
async def test_unique_email_constraint(db, create_user):
    await create_user(email="unique@example.com")
    await db.commit()

    with pytest.raises(IntegrityError):
        await create_user(email="unique@example.com")
        await db.commit()
