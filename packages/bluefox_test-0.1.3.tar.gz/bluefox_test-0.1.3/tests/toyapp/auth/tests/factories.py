from bluefox_test import BaseFactory, Faker, register

from auth.models import User


class UserFactory(BaseFactory):
    class Meta:
        model = User

    email = Faker("email")
    name = Faker("name")
    password_hash = "placeholder"
    is_active = True


create_user = register(UserFactory)
