import pytest

from auth.service import hash_password


@pytest.mark.asyncio
async def test_register_creates_user(client):
    response = await client.post("/auth/register", json={
        "email": "new@example.com",
        "name": "New User",
        "password": "securepassword",
    })
    assert response.status_code == 200
    data = response.json()
    assert data["email"] == "new@example.com"
    assert data["name"] == "New User"
    assert "id" in data


@pytest.mark.asyncio
async def test_register_rejects_duplicate_email(client, create_user):
    await create_user(email="taken@example.com", password_hash=hash_password("pass123"))

    response = await client.post("/auth/register", json={
        "email": "taken@example.com",
        "name": "Dup User",
        "password": "pass123",
    })
    assert response.status_code == 409


@pytest.mark.asyncio
async def test_login_returns_jwt(client, create_user):
    await create_user(email="login@example.com", password_hash=hash_password("mypassword"))

    response = await client.post("/auth/login", json={
        "email": "login@example.com",
        "password": "mypassword",
    })
    assert response.status_code == 200
    data = response.json()
    assert "access_token" in data
    assert data["token_type"] == "bearer"


@pytest.mark.asyncio
async def test_login_rejects_wrong_password(client, create_user):
    await create_user(email="wrong@example.com", password_hash=hash_password("correct"))

    response = await client.post("/auth/login", json={
        "email": "wrong@example.com",
        "password": "incorrect",
    })
    assert response.status_code == 401
