from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel
from sqlalchemy.ext.asyncio import AsyncSession

from app.deps import get_session
from auth.models import User
from auth.service import decode_token
from todos.service import complete_todo, create_todo, delete_todo, list_todos

router = APIRouter()


class TodoCreate(BaseModel):
    title: str
    description: str = ""


class TodoResponse(BaseModel):
    id: int
    title: str
    description: str
    is_completed: bool
    owner_id: int


async def get_current_user(session: AsyncSession = Depends(get_session)) -> User:
    """Placeholder — overridden in tests to inject auth."""
    raise HTTPException(status_code=401, detail="Not authenticated")


@router.get("", response_model=list[TodoResponse])
async def list_todos_route(
    session: AsyncSession = Depends(get_session),
    user: User = Depends(get_current_user),
):
    todos = await list_todos(session, user.id)
    return [
        TodoResponse(
            id=t.id, title=t.title, description=t.description,
            is_completed=t.is_completed, owner_id=t.owner_id,
        )
        for t in todos
    ]


@router.post("", response_model=TodoResponse, status_code=201)
async def create_todo_route(
    body: TodoCreate,
    session: AsyncSession = Depends(get_session),
    user: User = Depends(get_current_user),
):
    todo = await create_todo(session, user.id, body.title, body.description)
    await session.commit()
    return TodoResponse(
        id=todo.id, title=todo.title, description=todo.description,
        is_completed=todo.is_completed, owner_id=todo.owner_id,
    )


@router.patch("/{todo_id}/complete", response_model=TodoResponse)
async def complete_todo_route(
    todo_id: int,
    session: AsyncSession = Depends(get_session),
    user: User = Depends(get_current_user),
):
    todo = await complete_todo(session, todo_id, user.id)
    if not todo:
        raise HTTPException(status_code=404, detail="Todo not found")
    await session.commit()
    return TodoResponse(
        id=todo.id, title=todo.title, description=todo.description,
        is_completed=todo.is_completed, owner_id=todo.owner_id,
    )


@router.delete("/{todo_id}", status_code=204)
async def delete_todo_route(
    todo_id: int,
    session: AsyncSession = Depends(get_session),
    user: User = Depends(get_current_user),
):
    deleted = await delete_todo(session, todo_id, user.id)
    if not deleted:
        raise HTTPException(status_code=404, detail="Todo not found")
    await session.commit()
