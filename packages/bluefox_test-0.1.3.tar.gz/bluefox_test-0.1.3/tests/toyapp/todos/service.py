from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from todos.models import Todo


async def list_todos(session: AsyncSession, owner_id: int) -> list[Todo]:
    result = await session.execute(
        select(Todo).where(Todo.owner_id == owner_id)
    )
    return list(result.scalars().all())


async def create_todo(
    session: AsyncSession, owner_id: int, title: str, description: str = ""
) -> Todo:
    todo = Todo(title=title, description=description, owner_id=owner_id)
    session.add(todo)
    await session.flush()
    return todo


async def complete_todo(session: AsyncSession, todo_id: int, owner_id: int) -> Todo | None:
    result = await session.execute(
        select(Todo).where(Todo.id == todo_id, Todo.owner_id == owner_id)
    )
    todo = result.scalar_one_or_none()
    if todo:
        todo.is_completed = True
        await session.flush()
    return todo


async def delete_todo(session: AsyncSession, todo_id: int, owner_id: int) -> bool:
    result = await session.execute(
        select(Todo).where(Todo.id == todo_id, Todo.owner_id == owner_id)
    )
    todo = result.scalar_one_or_none()
    if todo:
        await session.delete(todo)
        await session.flush()
        return True
    return False
