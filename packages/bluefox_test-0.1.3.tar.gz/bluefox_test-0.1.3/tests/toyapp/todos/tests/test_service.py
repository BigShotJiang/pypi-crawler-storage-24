import pytest

from todos.service import complete_todo
from todos.service import create_todo as svc_create_todo
from todos.service import delete_todo, list_todos


@pytest.mark.asyncio
async def test_create_todo_service(db, create_user):
    user = await create_user()
    todo = await svc_create_todo(db, user.id, "Test task", "Description")
    assert todo.id is not None
    assert todo.title == "Test task"
    assert todo.owner_id == user.id


@pytest.mark.asyncio
async def test_list_todos_service(db, create_user, create_todo):
    user = await create_user()
    await create_todo(owner=user, title="Task 1")
    await create_todo(owner=user, title="Task 2")

    todos = await list_todos(db, user.id)
    assert len(todos) == 2


@pytest.mark.asyncio
async def test_complete_todo_service(db, create_user, create_todo):
    user = await create_user()
    todo = await create_todo(owner=user, title="Do it")

    result = await complete_todo(db, todo.id, user.id)
    assert result is not None
    assert result.is_completed is True


@pytest.mark.asyncio
async def test_delete_todo_service(db, create_user, create_todo):
    user = await create_user()
    todo = await create_todo(owner=user, title="Remove me")

    deleted = await delete_todo(db, todo.id, user.id)
    assert deleted is True

    remaining = await list_todos(db, user.id)
    assert len(remaining) == 0
