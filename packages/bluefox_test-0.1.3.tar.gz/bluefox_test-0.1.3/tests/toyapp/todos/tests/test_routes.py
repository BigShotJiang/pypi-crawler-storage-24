import pytest
from fastapi import Depends
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.deps import get_session
from auth.models import User
from auth.service import hash_password
from todos.routes import get_current_user


@pytest.fixture
async def authenticated_client(app, client, create_user, db):
    """Override the get_current_user dependency to inject a test user."""
    user = await create_user(
        email="owner@example.com",
        password_hash=hash_password("testpass"),
    )

    async def _override_current_user(session: AsyncSession = Depends(get_session)):
        result = await session.execute(select(User).where(User.id == user.id))
        return result.scalar_one()

    app.dependency_overrides[get_current_user] = _override_current_user
    return client, user


@pytest.mark.asyncio
async def test_create_todo(authenticated_client):
    client, user = authenticated_client
    response = await client.post("/todos", json={
        "title": "Buy groceries",
        "description": "Milk, eggs, bread",
    })
    assert response.status_code == 201
    data = response.json()
    assert data["title"] == "Buy groceries"
    assert data["owner_id"] == user.id
    assert data["is_completed"] is False


@pytest.mark.asyncio
async def test_list_todos_returns_own_todos_only(authenticated_client, create_todo, create_user):
    client, user = authenticated_client
    await create_todo(title="My todo", owner=user)
    other = await create_user(email="other@example.com")
    await create_todo(title="Other's todo", owner=other)

    response = await client.get("/todos")
    assert response.status_code == 200
    data = response.json()
    assert len(data) == 1
    assert data[0]["title"] == "My todo"


@pytest.mark.asyncio
async def test_complete_todo(authenticated_client, create_todo):
    client, user = authenticated_client
    todo = await create_todo(title="Finish report", owner=user)

    response = await client.patch(f"/todos/{todo.id}/complete")
    assert response.status_code == 200
    assert response.json()["is_completed"] is True


@pytest.mark.asyncio
async def test_delete_todo(authenticated_client, create_todo):
    client, user = authenticated_client
    todo = await create_todo(title="Delete me", owner=user)

    response = await client.delete(f"/todos/{todo.id}")
    assert response.status_code == 204
