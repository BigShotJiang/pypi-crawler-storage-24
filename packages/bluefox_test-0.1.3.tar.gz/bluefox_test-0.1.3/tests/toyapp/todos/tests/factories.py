from bluefox_test import BaseFactory, Faker, register

from todos.models import Todo


class TodoFactory(BaseFactory):
    class Meta:
        model = Todo

    title = Faker("sentence", nb_words=4)
    description = ""
    is_completed = False
    # owner is NOT declared — always pass explicitly in tests


create_todo = register(TodoFactory)
