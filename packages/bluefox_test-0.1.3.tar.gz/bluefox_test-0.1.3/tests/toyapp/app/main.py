from fastapi import FastAPI

from auth.routes import router as auth_router
from todos.routes import router as todos_router


def create_app() -> FastAPI:
    app = FastAPI(title="Toyapp")
    app.include_router(auth_router, prefix="/auth", tags=["auth"])
    app.include_router(todos_router, prefix="/todos", tags=["todos"])
    return app
