import sys
from pathlib import Path

# Add toyapp directory to sys.path so its modules are importable
sys.path.insert(0, str(Path(__file__).parent))

from app.models import Base  # noqa: E402

from bluefox_test import bluefox_test_setup  # noqa: E402

globals().update(
    bluefox_test_setup(
        base=Base,
        src_root=str(Path(__file__).parent),
        app_factory="app.main:create_app",
        session_dependency="app.deps:get_session",
    )
)
