import pytest

from bluefox_test.containers import (
    create_bind_databases,
    start_containers,
    stop_containers,
)


@pytest.fixture(scope="module")
def containers():
    pg, redis, async_url, sync_url, redis_url = start_containers()
    yield pg, redis, async_url, sync_url, redis_url
    stop_containers(pg, redis)


@pytest.mark.slow
def test_start_containers__starts_postgres_and_redis(containers):
    _, _, async_url, sync_url, redis_url = containers
    assert "postgresql+asyncpg://" in async_url
    assert "test_main" in async_url
    assert "postgresql://" in sync_url
    assert "test_main" in sync_url
    assert "redis://" in redis_url


@pytest.mark.slow
def test_start_containers__postgres_is_connectable(containers):
    _, _, _, sync_url, _ = containers
    import psycopg2
    from sqlalchemy.engine.url import make_url

    url = make_url(sync_url)
    conn = psycopg2.connect(
        host=url.host,
        port=url.port,
        user=url.username,
        password=url.password,
        dbname=url.database,
    )
    cur = conn.cursor()
    cur.execute("SELECT 1")
    result = cur.fetchone()
    assert result == (1,)
    cur.close()
    conn.close()


@pytest.mark.slow
def test_start_containers__redis_is_connectable(containers):
    _, _, _, _, redis_url = containers
    import redis

    client = redis.from_url(redis_url)
    assert client.ping() is True
    client.close()


@pytest.mark.slow
def test_create_bind_databases__creates_databases(containers):
    _, _, _, sync_url, _ = containers
    result = create_bind_databases(sync_url, ["analytics", "events"])
    assert "analytics" in result
    assert "events" in result
    assert "asyncpg" in result["analytics"]
    assert "asyncpg" in result["events"]


@pytest.mark.slow
def test_create_bind_databases__uses_test_prefix(containers):
    _, _, _, sync_url, _ = containers
    result = create_bind_databases(sync_url, ["analytics", "events"])
    assert "test_analytics" in result["analytics"]
    assert "test_events" in result["events"]
