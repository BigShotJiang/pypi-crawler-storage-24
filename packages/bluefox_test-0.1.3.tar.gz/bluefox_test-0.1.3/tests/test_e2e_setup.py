from bluefox_test.e2e import bluefox_e2e_setup


def test_bluefox_e2e_setup__returns_expected_fixtures():
    result = bluefox_e2e_setup()
    assert "server" in result
    assert "auth_token" in result
    assert "api" in result
    assert "api_anon" in result


def test_bluefox_e2e_setup__all_fixtures_callable():
    result = bluefox_e2e_setup()
    for name, fixture in result.items():
        assert callable(fixture), f"{name} is not callable"


def test_bluefox_e2e_setup__custom_parameters():
    result = bluefox_e2e_setup(
        login_endpoint="/api/login",
        login_payload={"user": "test", "pass": "test"},
        token_field="token",
        base_url_env="MY_URL",
        default_base_url="http://localhost:9000",
        cache_dir="/tmp/test_auth",
    )
    assert "server" in result
    assert "auth_token" in result
