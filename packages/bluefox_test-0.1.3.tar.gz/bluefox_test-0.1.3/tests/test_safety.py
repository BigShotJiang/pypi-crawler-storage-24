import os
import socket

import pytest

from bluefox_test.safety import (
    assert_safe_url,
    find_all_database_url_vars,
    install_network_guard,
    override_env_with_containers,
)


def test_find_all_database_url_vars__finds_matching_vars(monkeypatch):
    monkeypatch.setenv("DATABASE_URL", "postgresql://u:p@localhost/test_db")
    monkeypatch.setenv("ANALYTICS_DATABASE_URL", "postgresql://u:p@localhost/test_analytics")
    result = find_all_database_url_vars()
    assert "DATABASE_URL" in result
    assert "ANALYTICS_DATABASE_URL" in result


def test_find_all_database_url_vars__ignores_non_matching(monkeypatch):
    monkeypatch.setenv("SOME_OTHER_VAR", "value")
    monkeypatch.delenv("DATABASE_URL", raising=False)
    result = find_all_database_url_vars()
    assert "SOME_OTHER_VAR" not in result


def test_assert_safe_url__accepts_localhost(monkeypatch):
    monkeypatch.setenv("DATABASE_URL", "postgresql://u:p@localhost/test_myapp")
    violations = assert_safe_url("DATABASE_URL")
    assert violations == []


def test_assert_safe_url__accepts_db_host(monkeypatch):
    monkeypatch.setenv("DATABASE_URL", "postgresql://u:p@db/test_myapp")
    violations = assert_safe_url("DATABASE_URL")
    assert violations == []


def test_assert_safe_url__rejects_remote_host(monkeypatch):
    monkeypatch.setenv("DATABASE_URL", "postgresql://u:p@prod.rds.amazonaws.com/test_myapp")
    violations = assert_safe_url("DATABASE_URL")
    assert len(violations) == 1
    assert "prod.rds.amazonaws.com" in violations[0]


def test_assert_safe_url__rejects_missing_test_prefix(monkeypatch):
    monkeypatch.setenv("DATABASE_URL", "postgresql://u:p@localhost/myapp")
    violations = assert_safe_url("DATABASE_URL")
    assert len(violations) == 1
    assert "test_" in violations[0]


def test_assert_safe_url__accepts_test_prefix(monkeypatch):
    monkeypatch.setenv("DATABASE_URL", "postgresql://u:p@localhost/test_myapp")
    violations = assert_safe_url("DATABASE_URL")
    assert violations == []


def test_assert_safe_url__handles_empty_var(monkeypatch):
    monkeypatch.setenv("DATABASE_URL", "")
    violations = assert_safe_url("DATABASE_URL")
    assert violations == []


def test_override_env_with_containers__sets_env_vars(monkeypatch):
    # Clear any existing vars
    monkeypatch.delenv("DATABASE_URL", raising=False)
    monkeypatch.delenv("REDIS_URL", raising=False)
    monkeypatch.delenv("ANALYTICS_DATABASE_URL", raising=False)

    override_env_with_containers(
        async_url="postgresql+asyncpg://test:test@localhost:5432/test_main",
        redis_url="redis://localhost:6379/0",
        bind_urls={"analytics": "postgresql+asyncpg://test:test@localhost:5432/test_analytics"},
    )

    assert os.environ["DATABASE_URL"] == "postgresql+asyncpg://test:test@localhost:5432/test_main"
    assert os.environ["REDIS_URL"] == "redis://localhost:6379/0"
    assert os.environ["ANALYTICS_DATABASE_URL"] == "postgresql+asyncpg://test:test@localhost:5432/test_analytics"


def test_install_network_guard__blocks_external(monkeypatch):
    install_network_guard(monkeypatch)
    sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    with pytest.raises(pytest.fail.Exception, match="Network guard"):
        sock.connect(("8.8.8.8", 53))
    sock.close()


def test_install_network_guard__allows_localhost(monkeypatch):
    install_network_guard(monkeypatch)
    # This should not raise — we just verify the guard doesn't block it.
    # We don't actually need a server listening; the connect may fail with
    # ConnectionRefusedError, but it should NOT fail with pytest.fail.
    sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    try:
        sock.connect(("127.0.0.1", 1))
    except (ConnectionRefusedError, OSError):
        pass  # Expected — no server on port 1, but the guard didn't block it
    finally:
        sock.close()
