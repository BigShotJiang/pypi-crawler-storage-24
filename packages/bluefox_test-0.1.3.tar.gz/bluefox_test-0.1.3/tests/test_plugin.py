import tempfile
from pathlib import Path

from bluefox_test.plugin import _find_direct_model_usage, _to_snake


def test_markers_registered(pytestconfig):
    marker_names = [m.split(":")[0] for m in pytestconfig.getini("markers")]
    assert "e2e" in marker_names
    assert "slow" in marker_names
    assert "allow_network" in marker_names


def test_find_direct_model_usage__detects_instantiation():
    with tempfile.NamedTemporaryFile(mode="w", suffix=".py", delete=False) as f:
        f.write('user = User(name="x")\n')
        f.flush()
        violations = _find_direct_model_usage(Path(f.name), {"User"})
    assert len(violations) == 1
    assert "User(...)" in violations[0]


def test_find_direct_model_usage__ignores_function_calls():
    with tempfile.NamedTemporaryFile(mode="w", suffix=".py", delete=False) as f:
        f.write('user = create_user(name="x")\n')
        f.flush()
        violations = _find_direct_model_usage(Path(f.name), {"User"})
    assert len(violations) == 0


def test_find_direct_model_usage__handles_syntax_error():
    with tempfile.NamedTemporaryFile(mode="w", suffix=".py", delete=False) as f:
        f.write("def broken(\n")
        f.flush()
        violations = _find_direct_model_usage(Path(f.name), {"User"})
    assert violations == []


def test_to_snake__converts_correctly():
    assert _to_snake("User") == "user"
    assert _to_snake("UserProfile") == "user_profile"
    assert _to_snake("HTTPLog") == "http_log"
    assert _to_snake("APIKey") == "api_key"
