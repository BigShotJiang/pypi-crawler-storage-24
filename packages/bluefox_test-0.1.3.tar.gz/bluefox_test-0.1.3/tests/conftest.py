import pytest
from bluefox_test.containers import start_containers, stop_containers


@pytest.fixture(scope="session")
def pg_container():
    pg, redis, async_url, sync_url, redis_url = start_containers()
    yield async_url, sync_url
    stop_containers(pg, redis)
