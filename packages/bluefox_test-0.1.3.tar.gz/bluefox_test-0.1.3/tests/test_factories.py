import tempfile
from pathlib import Path

import pytest
import pytest_asyncio
from sqlalchemy import ForeignKey, String, select
from sqlalchemy.orm import DeclarativeBase, Mapped, mapped_column, relationship

from bluefox_test.factories import (
    BaseFactory,
    Faker,
    _model_name_to_fixture_name,
    bind_session,
    discover_and_collect_fixtures,
    get_current_session,
    register,
)
from bluefox_test.session import create_test_engine, scoped_test_session


# --- Test models ---


class Base(DeclarativeBase):
    pass


class Category(Base):
    __tablename__ = "test_categories"
    id: Mapped[int] = mapped_column(primary_key=True)
    name: Mapped[str] = mapped_column(String(50))


class Item(Base):
    __tablename__ = "test_items_factory"
    id: Mapped[int] = mapped_column(primary_key=True)
    name: Mapped[str] = mapped_column(String(50))
    category_id: Mapped[int] = mapped_column(ForeignKey("test_categories.id"))
    category: Mapped["Category"] = relationship()


# --- Test factories (no SubFactory — explicit relationship passing) ---


class CategoryFactory(BaseFactory):
    class Meta:
        model = Category

    name = Faker("word")


class ItemFactory(BaseFactory):
    class Meta:
        model = Item

    name = Faker("word")
    # category is NOT declared — always pass explicitly


# --- Fixtures ---


@pytest_asyncio.fixture(scope="session")
async def factory_engine(pg_container):
    async_url, _ = pg_container
    eng = create_test_engine(async_url)
    async with eng.begin() as conn:
        await conn.run_sync(Base.metadata.create_all)
    yield eng
    await eng.dispose()


@pytest_asyncio.fixture
async def db(factory_engine):
    async with scoped_test_session(factory_engine) as session:
        bind_session(session)
        yield session
        bind_session(None)


# --- Tests ---


async def test_base_factory__creates_instance_with_id(db):
    cat = await CategoryFactory.create_async()
    assert cat.id is not None


async def test_base_factory__accepts_overrides(db):
    cat = await CategoryFactory.create_async(name="Custom")
    assert cat.name == "Custom"


async def test_base_factory__auto_flushes(db):
    cat = await CategoryFactory.create_async()
    result = await db.execute(select(Category).where(Category.id == cat.id))
    found = result.scalar_one()
    assert found.name == cat.name


async def test_base_factory__explicit_relationship(db):
    """Explicit relationship passing — no SubFactory auto-persist."""
    cat = await CategoryFactory.create_async(name="Electronics")
    item = await ItemFactory.create_async(category=cat, category_id=cat.id)
    assert item.category_id == cat.id
    assert item.category.name == "Electronics"


async def test_base_factory__create_batch(db):
    cats = await CategoryFactory.create_batch_async(3)
    assert len(cats) == 3
    assert all(c.id is not None for c in cats)


async def test_bind_session__sets_session(db):
    from bluefox_test.factories import _current_session

    assert _current_session is db


async def test_bind_session__clears_on_none(db):
    bind_session(None)
    from bluefox_test import factories

    assert factories._current_session is None
    # Restore for subsequent tests
    bind_session(db)


async def test_get_current_session__raises_without_bind():
    from bluefox_test import factories

    original = factories._current_session
    factories._current_session = None
    with pytest.raises(RuntimeError, match="No test session is active"):
        get_current_session()
    factories._current_session = original


def test_register__creates_fixture_with_correct_name():
    fixture = register(CategoryFactory)
    assert fixture.__name__ == "create_category"


def test_model_name_to_fixture_name__standard_cases():
    assert _model_name_to_fixture_name("User") == "create_user"
    assert _model_name_to_fixture_name("UserProfile") == "create_user_profile"
    assert _model_name_to_fixture_name("HTTPLog") == "create_http_log"
    assert _model_name_to_fixture_name("APIKey") == "create_api_key"


def test_discover_and_collect_fixtures__finds_factory_modules():
    import sys

    # Create a temp directory with a tests/factories.py
    with tempfile.TemporaryDirectory() as tmpdir:
        domain = Path(tmpdir) / "mydomain" / "tests"
        domain.mkdir(parents=True)
        (domain / "__init__.py").write_text("")
        (domain.parent / "__init__.py").write_text("")

        # Use inline model definition so the temp module is self-contained
        (domain / "factories.py").write_text(
            "from sqlalchemy import String\n"
            "from sqlalchemy.orm import DeclarativeBase, Mapped, mapped_column\n"
            "from bluefox_test.factories import BaseFactory, register, Faker\n"
            "\n"
            "class TempBase(DeclarativeBase):\n"
            "    pass\n"
            "\n"
            "class TempWidget(TempBase):\n"
            "    __tablename__ = 'test_temp_widgets'\n"
            "    id: Mapped[int] = mapped_column(primary_key=True)\n"
            "    name: Mapped[str] = mapped_column(String(50))\n"
            "\n"
            "class TempWidgetFactory(BaseFactory):\n"
            "    class Meta:\n"
            "        model = TempWidget\n"
            "    name = Faker('word')\n"
            "\n"
            "create_temp_widget = register(TempWidgetFactory)\n"
        )

        # Add tmpdir to path so importlib.util can find it
        sys.path.insert(0, tmpdir)
        try:
            result = discover_and_collect_fixtures(tmpdir)
            assert "create_temp_widget" in result
        finally:
            sys.path.remove(tmpdir)
