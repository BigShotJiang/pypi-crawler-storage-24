# CI with GitHub Actions

How to run tests in CI. Docker is pre-installed on `ubuntu-latest`.

---

## Test workflow

```yaml title=".github/workflows/test.yml"
name: Test
on: [push, pull_request]

jobs:
  test:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - uses: astral-sh/setup-uv@v5
      - run: uv sync --group test
      - run: uv run pytest src/ -x --tb=short -q
```

That's it. `testcontainers` handles Postgres and Redis automatically — no `services:` block needed.

---

## With E2E

```yaml title=".github/workflows/test.yml"
name: Test
on: [push, pull_request]

jobs:
  test:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - uses: astral-sh/setup-uv@v5
      - run: uv sync --group test
      - run: uv run pytest src/ -x --tb=short -q

  e2e:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - uses: astral-sh/setup-uv@v5
      - run: |
          uv sync --group test
          uv run playwright install chromium
      - run: make e2e
```

---

## Docs deployment

```yaml title=".github/workflows/docs.yml"
name: Docs
on:
  push:
    branches: [main]

jobs:
  deploy:
    runs-on: ubuntu-latest
    permissions:
      contents: write
    steps:
      - uses: actions/checkout@v4
      - uses: astral-sh/setup-uv@v5
      - run: uv sync --group docs
      - run: uv run mkdocs gh-deploy --force
```

---

## Notes

- Docker is pre-installed on GitHub Actions `ubuntu-latest` runners
- testcontainers starts containers with random ports — no port conflicts
- The `e2e` job needs Docker Compose for the full app stack
- Separate `test` and `e2e` jobs so unit tests don't wait for E2E
