# bluefox-test: Async Factory Specification

This document specifies exactly how factories work in bluefox-test. It supersedes any previous references to `SQLAlchemyModelFactory` or sync factory calls in other spec documents.

---

## The Problem

`factory_boy`'s `SQLAlchemyModelFactory` is synchronous. It calls `session.add()` + `session.flush()` via the sync SQLAlchemy API. Our stack is fully async: `AsyncSession`, `asyncpg`, `pytest-asyncio`.

SQLAlchemy provides a greenlet bridge that theoretically allows sync operations on `AsyncSession.sync_session`. In practice, this bridge is fragile across different combinations of library versions, event loop implementations, and pytest-asyncio configurations. When it breaks, it produces hangs, infinite loops, or cryptic greenlet errors.

**We do not use the greenlet bridge for factories.** We do not use `SQLAlchemyModelFactory`. We use plain `factory.Factory` for attribute generation only, and handle all database persistence with real `await` calls.

---

## The Solution

### Architecture

```
factory.Factory          → builds Python objects with fake data (no DB)
    ↓
BaseFactory.create_async()  → adds to AsyncSession, awaits flush (real async)
    ↓
register()               → wraps as a pytest fixture returning an async callable
    ↓
create_user()            → returns a coroutine: user = await create_user(name="Hugo")
```

### What factory_boy does (and doesn't do)

We use `factory_boy` for exactly two things:
1. **Attribute declaration** — `Faker("email")`, `SubFactory(UserFactory)`, `LazyFunction`, etc.
2. **Object construction** — `Factory.build(**overrides)` creates an instance with merged defaults + overrides

We do NOT use:
- `SQLAlchemyModelFactory` — removed entirely
- `sqlalchemy_session` — not set on any factory
- `sqlalchemy_session_persistence` — not relevant
- `Factory.create()` — we override this completely

### BaseFactory

```python
import factory
from sqlalchemy.ext.asyncio import AsyncSession


# Module-level reference to the current test session.
_current_session: AsyncSession | None = None


def bind_session(session: AsyncSession | None) -> None:
    """Called by the db fixture at test start/end."""
    global _current_session
    _current_session = session


def get_current_session() -> AsyncSession:
    if _current_session is None:
        raise RuntimeError(
            "No test session is active. Factories can only be used "
            "inside tests that request the `db` fixture."
        )
    return _current_session


class BaseFactory(factory.Factory):
    """
    Base factory for all models.

    Uses factory_boy ONLY for attribute declaration and object building.
    All database persistence is async — no greenlet bridge, no sync hacks.

    Usage:
        class UserFactory(BaseFactory):
            class Meta:
                model = User

            name = Faker("name")
            email = Faker("email")

        create_user = register(UserFactory)

    In tests:
        user = await create_user(name="Hugo")
    """

    class Meta:
        abstract = True

    @classmethod
    async def create_async(cls, _session: AsyncSession | None = None, **overrides):
        """
        Build an instance with factory_boy, then persist via async session.

        This is the ONLY method that touches the database. It uses real
        await calls — no greenlet bridge, no sync_session.

        Args:
            _session: Explicit session override (for cross-bind factories).
                      If None, uses the globally-bound test session.
            **overrides: Field overrides passed to factory_boy's build().

        Returns:
            The persisted model instance with a real database ID.
        """
        session = _session or get_current_session()

        # Handle SubFactory fields: if any override is a coroutine
        # (from another factory's create_async), await it first.
        resolved = {}
        for key, value in overrides.items():
            if hasattr(value, '__await__'):
                resolved[key] = await value
            else:
                resolved[key] = value

        # factory_boy builds the object in memory — no DB call.
        instance = cls.build(**resolved)

        # Async persistence — real await, no greenlet bridge.
        session.add(instance)
        await session.flush()

        # Refresh to load server-generated defaults (timestamps, etc.)
        await session.refresh(instance)

        return instance

    @classmethod
    async def create_batch_async(cls, size: int, **overrides) -> list:
        """Create multiple instances."""
        return [await cls.create_async(**overrides) for _ in range(size)]
```

### Key design decisions

**Why `factory.Factory` and not `SQLAlchemyModelFactory`:**
`SQLAlchemyModelFactory` adds sync session management that we don't want. Plain `factory.Factory` gives us `.build()` (construct an object with fake data) and nothing else. That's all we need.

**Why `create_async` and not overriding `create`:**
`factory_boy`'s `.create()` is synchronous and deeply integrated with its internal `_generate` method. Overriding it to be async fights the library. A separate `create_async` classmethod is explicit and doesn't conflict with factory_boy internals.

**Why `await session.flush()` and not `await session.commit()`:**
`flush()` sends the SQL to the database (assigning IDs, triggering defaults) without ending the transaction. The SAVEPOINT strategy handles transaction boundaries. `commit()` is only for constraint tests.

**Why `await session.refresh(instance)`:**
After `flush()`, server-generated fields like `created_at` (via `server_default=func.now()`) may not be loaded in the Python object. `refresh()` reloads the instance from the database, ensuring all fields are populated. This prevents surprise `None` values on timestamp fields.

---

## The register() function

```python
import inspect
from typing import Any

import pytest


# Global registry — populated by register() calls, collected by discover_and_collect_fixtures()
_fixture_registry: dict[str, Any] = {}


def register(
    factory_cls: type[BaseFactory],
    session_fixture: str = "db",
) -> Any:
    """
    Turn a factory class into a globally-available async pytest fixture.

    The fixture returns an async callable:
        user = await create_user(name="Hugo")

    For cross-bind factories:
        create_event = register(EventFactory, session_fixture="db_analytics")
    """
    model = factory_cls.Meta.model
    fixture_name = _model_name_to_fixture_name(model.__name__)

    if session_fixture == "db":
        # Default bind: uses the globally-bound session.
        # Depend on `db` so the session is bound before any factory call.
        def fixture_fn(db):
            async def _create(**overrides):
                return await factory_cls.create_async(**overrides)
            return _create

    else:
        # Cross-bind: pass explicit session to create_async.
        def fixture_fn(**kwargs):
            session = kwargs[session_fixture]

            async def _create(**overrides):
                return await factory_cls.create_async(_session=session, **overrides)
            return _create

        # Dynamic signature so pytest injects the right session fixture.
        params = [
            inspect.Parameter(
                session_fixture, inspect.Parameter.POSITIONAL_OR_KEYWORD,
            )
        ]
        fixture_fn.__signature__ = inspect.Signature(params)

    fixture_fn.__name__ = fixture_name
    fixture_fn.__qualname__ = fixture_name

    decorated = pytest.fixture(fixture_fn)
    _fixture_registry[fixture_name] = decorated
    return decorated
```

---

## SubFactory Handling

`factory_boy`'s `SubFactory` works at `.build()` time — it recursively calls `.build()` on the related factory. This creates an in-memory object but does NOT persist it. We need to persist related objects before the parent.

There are two approaches:

### Approach A: Explicit (recommended)

Pass already-created related objects:

```python
# In the test:
user = await create_user(name="Hugo")
order = await create_order(owner=user)
```

This is explicit, readable, and doesn't require any special SubFactory handling.

### Approach B: Auto-persist SubFactories

Override `create_async` to detect un-persisted related objects and flush them first. This requires walking the instance's relationships and persisting any that don't have an ID yet:

```python
@classmethod
async def create_async(cls, _session=None, **overrides):
    session = _session or get_current_session()
    instance = cls.build(**overrides)

    # Auto-persist any related objects that factory_boy built via SubFactory.
    mapper = inspect(type(instance))
    for rel in mapper.relationships:
        related = getattr(instance, rel.key, None)
        if related is not None and not inspect(related).persistent:
            session.add(related)

    session.add(instance)
    await session.flush()
    await session.refresh(instance)
    return instance
```

**Recommendation:** Start with Approach A. It's simpler, more explicit, and avoids edge cases with nested SubFactories. If the team finds it too verbose, add Approach B later.

If using Approach A, factories should NOT use `SubFactory` for required relationships. Instead, make the field required in the factory and always pass it in tests:

```python
class OrderFactory(BaseFactory):
    class Meta:
        model = Order

    status = Faker("random_element", elements=["pending", "completed"])
    # owner is NOT declared here — it's required in every create call

# In tests:
user = await create_user()
order = await create_order(owner=user)

# NOT this:
order = await create_order()  # would fail — owner is required
```

For truly optional relationships, use `None` as the default:

```python
class OrderFactory(BaseFactory):
    class Meta:
        model = Order

    status = "pending"
    coupon = None  # optional relationship
```

---

## Factory file example (definitive)

```python
# src/users/tests/factories.py

from bluefox_test import BaseFactory, register, Faker

from users.models import User, UserProfile


class UserFactory(BaseFactory):
    class Meta:
        model = User

    name = Faker("name")
    email = Faker("email")
    is_active = True

create_user = register(UserFactory)


class UserProfileFactory(BaseFactory):
    class Meta:
        model = UserProfile

    bio = Faker("paragraph")
    avatar_url = "https://example.com/avatar.png"
    # user is NOT declared — always passed explicitly

create_user_profile = register(UserProfileFactory)
```

---

## Test example (definitive)

```python
# src/users/tests/test_routes.py

async def test_get_user__returns_200_with_valid_id(client, create_user):
    user = await create_user(name="Hugo")
    response = await client.get(f"/users/{user.id}")
    assert response.status_code == 200
    assert response.json()["name"] == "Hugo"


async def test_get_user__returns_404_when_not_found(client):
    response = await client.get("/users/99999")
    assert response.status_code == 404


async def test_create_order__with_existing_user(client, create_user, create_order):
    user = await create_user(name="Hugo")
    order = await create_order(owner=user, status="pending")
    assert order.owner.name == "Hugo"
    assert order.owner_id == user.id


async def test_create_user__enforces_unique_email(db, create_user):
    """Explicit commit: testing UNIQUE constraint at the DB level."""
    await create_user(email="hugo@example.com")
    await db.commit()
    with pytest.raises(IntegrityError):
        await create_user(email="hugo@example.com")
        await db.commit()
```

Note: every `create_*` call is `await`ed. This is consistent with the rest of the async codebase and is the only approach that works reliably across all configurations.

---

## What we gave up (and why it's fine)

**Sync factory calls.** The original spec had `user = create_user()` (no await). We now have `user = await create_user()`. This is a small DX cost that:
1. Eliminates all greenlet bridge issues permanently
2. Is consistent with every other database call in the codebase
3. Makes it obvious that this is a database operation (which it is)
4. Works reliably across all versions of SQLAlchemy, asyncpg, and pytest-asyncio

**`SQLAlchemyModelFactory`.** We only ever used it for `session.add()` + `session.flush()` — 3 lines of code. We now write those 3 lines ourselves, with proper `await`. factory_boy's value is in attribute declaration (`Faker`, `LazyFunction`, `Sequence`), which we keep.

**SubFactory auto-persistence.** Instead of `SubFactory(UserFactory)` magically creating and persisting a User, we pass related objects explicitly. This is more verbose but also more predictable. No hidden database calls buried inside factory_boy's recursive `_generate`.

---

## Changes to the implementation plan

Phase 4 of the `bluefox-test` implementation plan should be updated:

1. `BaseFactory` extends `factory.Factory`, NOT `SQLAlchemyModelFactory`
2. Remove all references to `sqlalchemy_session`, `sqlalchemy_session_persistence`, `sync_session`
3. `bind_session()` stores the `AsyncSession` directly (not `sync_session`)
4. `create_async()` uses `await session.flush()` and `await session.refresh()`
5. `register()` returns a fixture whose `_create` function is `async`
6. All test examples use `await create_user()` instead of `create_user()`
7. Remove `psycopg2-binary` from dependencies if it was only needed for `SQLAlchemyModelFactory`
8. The re-exports from `__init__.py` should NOT include `SubFactory` — encourage explicit relationship passing instead

### Updated `__init__.py` exports

```python
from bluefox_test.factories import (
    BaseFactory,
    register,
)

# Re-export factory_boy utilities for attribute declaration only.
# SubFactory is intentionally excluded — use explicit relationship passing.
from factory import (
    Faker,
    LazyFunction,
    LazyAttribute,
    Sequence,
    Iterator,
    Trait,
)
```

If the team later decides they want SubFactory support with auto-persistence (Approach B above), it can be added as a non-breaking enhancement. But start without it.

---

## Summary

| Aspect | Old spec (broken) | New spec (works) |
|---|---|---|
| Base class | `SQLAlchemyModelFactory` | `factory.Factory` |
| Persistence | factory_boy sync via greenlet bridge | Our own `await session.flush()` |
| Session binding | `sync_session` on every factory's Meta | Module-level `AsyncSession` reference |
| Factory call | `user = create_user()` | `user = await create_user()` |
| Related objects | `SubFactory(UserFactory)` auto-persists | Explicit: `await create_order(owner=user)` |
| Reliability | Fragile (greenlet bridge) | Bulletproof (native async) |
