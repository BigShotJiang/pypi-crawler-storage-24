# bluefox-test: Implementation Plan

A step-by-step, incremental build plan for the `bluefox-test` package. Each phase produces a working, testable artifact. Designed to be followed in Claude Code sessions.

---

## Prerequisites

Before starting:

- Python 3.12+
- Docker running (for testcontainers)
- A GitHub repo created: `bluefox-software/pytest-bluefox`
- The repo cloned locally

All three spec documents should be provided as context in every Claude Code session:

- `pytest-bluefox-README.md` (package reference)
- `adoption-guide.md` (app-facing guide)
- `walkthrough.md` (todo app example)

For Phase 8 (documentation), also provide:

- `docs-maintainer-guide.md` (MkDocs formatting reference and maintainer guide — becomes `contributing/docs.md` in the site)
- `pypi-publishing-guide.md` (PyPI setup, release flow, git tags — becomes `contributing/publishing.md` in the site)

For Phase 9 (publishing), the `pypi-publishing-guide.md` is the primary reference.

---

## Phase 1: Skeleton + Safety Module

**Goal:** A pip-installable package with just the safety module. Testable in isolation — no containers, no factories, no SQLAlchemy engines yet.

### Step 1.1: Initialize the package

Create the project structure:

```
pytest-bluefox/
  bluefox_test/
    __init__.py
    safety.py
  tests/
    __init__.py
    test_safety.py
  pyproject.toml
  README.md
  .gitignore
```

`pyproject.toml` should:
- Use `hatchling` as build backend
- Set `name = "bluefox-test"`, `version = "0.1.0"`, `requires-python = ">=3.12"`
- Declare all runtime dependencies (pytest, pytest-asyncio, testcontainers, sqlalchemy, asyncpg, sqlalchemy-utils, psycopg2-binary, factory-boy, faker, httpx)
- Declare a `test` dependency group with just `pytest` (the package tests itself with plain pytest, not with bluefox-test)
- Set up basic pytest config: `testpaths = ["tests"]`, `asyncio_mode = "auto"`
- **Do NOT add the pytest11 entry point yet** — that comes in Phase 5

`.gitignore` should cover standard Python patterns (`.venv`, `__pycache__`, `dist/`, `*.egg-info`, `.pytest_cache`).

`README.md` can be a one-liner placeholder for now.

`bluefox_test/__init__.py` should be empty for now — we'll add exports as we build modules.

### Step 1.2: Build safety.py

Implement `safety.py` with these functions:

**`find_all_database_url_vars()`**
- Scans `os.environ` for keys matching `DATABASE_URL` or `*_DATABASE_URL`
- Returns a sorted list of matching keys

**`assert_safe_url(env_var: str) -> list[str]`**
- Reads the env var value, parses with `sqlalchemy.engine.url.make_url()`
- Checks host is in `ALLOWED_HOSTS` (`localhost`, `127.0.0.1`, `0.0.0.0`, `db`)
- Checks database name starts with `test_`
- Returns list of violation strings (empty = safe)

**`enforce_safety()`**
- Calls `find_all_database_url_vars()`, then `assert_safe_url()` on each
- If any violations: calls `pytest.exit()` with a clear message and `returncode=1`

**`override_env_with_containers(async_url, redis_url, bind_urls=None)`**
- Writes `DATABASE_URL`, `REDIS_URL`, and `<BIND>_DATABASE_URL` env vars
- Calls `enforce_safety()` after writing

**`install_network_guard(monkeypatch)`**
- Monkeypatches `socket.socket.connect` to reject non-local IPs
- Allowed prefixes: `127.`, `0.0.0.0`, `192.168.`, `172.16.`–`172.31.`, `10.`, `::`, `localhost`
- Calls `pytest.fail()` on violation

Constants: `ALLOWED_HOSTS`, `TEST_DB_PREFIX`

### Step 1.3: Test safety.py

Write `tests/test_safety.py`:

- `test_find_all_database_url_vars__finds_matching_vars` — set env vars, verify they're found
- `test_find_all_database_url_vars__ignores_non_matching` — set `SOME_OTHER_VAR`, not found
- `test_assert_safe_url__accepts_localhost` — `DATABASE_URL=postgresql://u:p@localhost/test_myapp` → no violations
- `test_assert_safe_url__accepts_db_host` — host `db` → no violations
- `test_assert_safe_url__rejects_remote_host` — host `prod.rds.amazonaws.com` → violation
- `test_assert_safe_url__rejects_missing_test_prefix` — database `myapp` instead of `test_myapp` → violation
- `test_assert_safe_url__accepts_test_prefix` — database `test_myapp` → no violations
- `test_assert_safe_url__handles_empty_var` — empty string → no violations
- `test_override_env_with_containers__sets_env_vars` — check os.environ after call
- `test_install_network_guard__blocks_external` — attempt connect to `8.8.8.8` → pytest.fail
- `test_install_network_guard__allows_localhost` — connect to `127.0.0.1` → no failure

All tests should use `monkeypatch` to set/unset env vars and restore state. Use `os.environ` manipulation, not actual socket connections.

### Step 1.4: Verify

```bash
pip install -e ".[test]"
pytest tests/test_safety.py -v
```

All tests should pass. Commit: `feat: safety module — host whitelist, test_ prefix, network guard`

---

## Phase 2: Containers Module

**Goal:** Start and stop real Postgres + Redis containers. Verify they work by connecting to them.

### Step 2.1: Build containers.py

Implement `containers.py` with:

**`start_containers(postgres_image, redis_image) -> tuple`**
- Start `PostgresContainer` with `username="test"`, `password="test"`, `dbname="test_main"`
- Start `RedisContainer`
- Build URLs:
  - `pg_async_url`: `postgresql+asyncpg://test:test@{host}:{port}/test_main`
  - `pg_sync_url`: `postgresql://test:test@{host}:{port}/test_main`
  - `redis_url`: `redis://{host}:{port}/0`
- Return a tuple: `(pg_container, redis_container, pg_async_url, pg_sync_url, redis_url)`

**`stop_containers(pg_container, redis_container)`**
- Call `.stop()` on each

**`create_bind_databases(sync_base_url, binds: list[str]) -> dict[str, str]`**
- For each bind name, create a database named `test_{bind_name}` using `sqlalchemy_utils.create_database()`
- Skip if `database_exists()` returns True
- Return dict: `{bind_name: async_url}`

Keep it simple — plain tuples and dicts, no Pydantic models here. These are internal plumbing.

### Step 2.2: Test containers.py

Write `tests/test_containers.py`:

- `test_start_containers__starts_postgres_and_redis` — start containers, verify URLs contain expected patterns, stop containers
- `test_start_containers__postgres_is_connectable` — start containers, connect with `psycopg2` using the sync URL, run `SELECT 1`, stop
- `test_start_containers__redis_is_connectable` — start containers, connect with `redis` (add `redis` to test deps), run `PING`, stop
- `test_create_bind_databases__creates_databases` — start containers, call `create_bind_databases` with `["analytics", "events"]`, verify with `database_exists()`, stop
- `test_create_bind_databases__uses_test_prefix` — verify the database names are `test_analytics`, `test_events`

These tests are slow (they start real containers). Mark them with `@pytest.mark.slow`.

### Step 2.3: Verify

```bash
pytest tests/test_containers.py -v -m slow
```

Commit: `feat: containers module — Postgres + Redis via testcontainers`

---

## Phase 3: Session Module

**Goal:** The SAVEPOINT session trick working against a real Postgres container.

### Step 3.1: Build session.py

Implement `session.py` with:

**`create_test_engine(url, **kwargs) -> AsyncEngine`**
- `create_async_engine(url, echo=False, pool_pre_ping=True, **kwargs)`

**`scoped_test_session(engine) -> AsyncContextManager[AsyncSession]`**
- `async with engine.connect()` → `conn`
- `trans = await conn.begin()` (outer real transaction)
- `await conn.begin_nested()` (SAVEPOINT)
- Create `AsyncSession(bind=conn, expire_on_commit=False)`
- Register `after_transaction_end` event listener on `session.sync_session` that restarts the SAVEPOINT when the nested transaction ends
- `yield session`
- On cleanup: `await session.close()`, `await trans.rollback()`

The event listener logic:

```python
@event.listens_for(session.sync_session, "after_transaction_end")
def restart_savepoint(sync_session, transaction):
    if transaction.nested and not transaction._parent.nested:
        sync_session.begin_nested()
```

### Step 3.2: Test session.py

Write `tests/test_session.py`. These tests need a real Postgres container — create a session-scoped fixture for it.

Add a `tests/conftest.py`:

```python
import pytest
from bluefox_test.containers import start_containers, stop_containers

@pytest.fixture(scope="session")
def pg_container():
    pg, redis, async_url, sync_url, redis_url = start_containers()
    yield async_url, sync_url
    stop_containers(pg, redis)
```

Tests:

- `test_scoped_test_session__provides_working_session` — create engine, create a table (a simple `test_items` table with `id` and `name` columns using `Base.metadata.create_all`), open scoped session, insert a row, query it back, verify it's there
- `test_scoped_test_session__rolls_back_after_exit` — insert a row inside `scoped_test_session`, exit the context, open a new `scoped_test_session`, verify the row is gone
- `test_scoped_test_session__survives_session_commit` — inside the scoped session, insert a row, call `await session.commit()`, insert another row, verify both are visible. Then exit and verify both are gone (rollback worked despite commit)
- `test_scoped_test_session__expire_on_commit_false` — insert a row, commit, access `row.name` — should NOT raise `DetachedInstanceError`

For these tests, define a tiny model inline:

```python
from sqlalchemy.orm import DeclarativeBase, Mapped, mapped_column
from sqlalchemy import String

class TestBase(DeclarativeBase):
    pass

class Item(TestBase):
    __tablename__ = "test_items"
    id: Mapped[int] = mapped_column(primary_key=True)
    name: Mapped[str] = mapped_column(String(50))
```

### Step 3.3: Verify

```bash
pytest tests/test_session.py -v
```

Commit: `feat: session module — SAVEPOINT trick with commit neutralization`

---

## Phase 4: Factories Module

**Goal:** `BaseFactory`, `register()`, factory auto-discovery, `bind_session()`, and re-exports.

### Step 4.1: Build factories.py

Implement `factories.py` with:

**`BaseFactory(SQLAlchemyModelFactory)`**
- `Meta`: `abstract = True`, `sqlalchemy_session = None`, `sqlalchemy_session_persistence = "flush"`
- Override `create(cls, _session=None, **kwargs)`: if `_session` provided, temporarily swap `_meta.sqlalchemy_session` to `_session.sync_session`, call `super().create()`, restore original

**`bind_session(session: AsyncSession | None)`**
- Walk all `BaseFactory` subclasses recursively
- Set `._meta.sqlalchemy_session` to `session.sync_session` (or `None`)

**`_all_factories() -> list`**
- Recursively collect all concrete `BaseFactory` subclasses (those with a non-abstract `Meta` that has a `model`)

**`_model_name_to_fixture_name(model_name: str) -> str`**
- `UserProfile` → `create_user_profile`
- `HTTPLog` → `create_http_log`
- Uses regex: insert underscores before uppercase transitions, lowercase everything, prepend `create_`

**`register(factory_cls, session_fixture="db") -> pytest.fixture`**
- Derive fixture name from `factory_cls.Meta.model.__name__`
- If `session_fixture == "db"`: create a fixture function with parameter `db` that returns a `_create(**overrides)` closure calling `factory_cls.create(**overrides)`
- If `session_fixture != "db"`: create a fixture function with a dynamically-set parameter (using `inspect.Signature`) matching `session_fixture`, and the closure calls `factory_cls.create(_session=session, **overrides)`
- Store in `_fixture_registry` dict
- Return the decorated fixture

**`discover_and_collect_fixtures(src_root="src") -> dict`**
- Walk `src_root` recursively for files matching `tests/factories.py`
- Import each module (triggers `register()` calls as side effect)
- Return a copy of `_fixture_registry`

**Re-exports at the top of the file** (these get bubbled up via `__init__.py`):

```python
from factory import Faker, SubFactory, LazyFunction, LazyAttribute, Sequence, Iterator, Trait
```

### Step 4.2: Update `__init__.py`

Export the public API:

```python
from bluefox_test.factories import (
    BaseFactory,
    register,
    Faker,
    SubFactory,
    LazyFunction,
    LazyAttribute,
    Sequence,
    Iterator,
    Trait,
)

__all__ = [
    "bluefox_test_setup",
    "BaseFactory",
    "register",
    "Faker",
    "SubFactory",
    "LazyFunction",
    "LazyAttribute",
    "Sequence",
    "Iterator",
    "Trait",
]
```

`bluefox_test_setup` doesn't exist yet — leave it in `__all__` but don't import it. We'll add it in Phase 6. Or, simply omit it from `__init__.py` until Phase 6 and add it then.

### Step 4.3: Test factories.py

Write `tests/test_factories.py`. These need a real Postgres container + the session module.

Use the existing `tests/conftest.py` fixture from Phase 3 (the `pg_container` fixture). Add engine + session fixtures:

```python
# tests/conftest.py — extend with:
from bluefox_test.session import create_test_engine, scoped_test_session

@pytest_asyncio.fixture(scope="session")
async def engine(pg_container):
    url, _ = pg_container
    eng = create_test_engine(url)
    # create tables for test models
    yield eng
    await eng.dispose()
```

Define test models for factory tests (same `TestBase` / `Item` as Phase 3, plus a `Category` model with a foreign key to test SubFactory):

```python
class Category(TestBase):
    __tablename__ = "test_categories"
    id: Mapped[int] = mapped_column(primary_key=True)
    name: Mapped[str] = mapped_column(String(50))

class Item(TestBase):
    __tablename__ = "test_items"
    id: Mapped[int] = mapped_column(primary_key=True)
    name: Mapped[str] = mapped_column(String(50))
    category_id: Mapped[int] = mapped_column(ForeignKey("test_categories.id"))
    category: Mapped["Category"] = relationship()
```

Define test factories:

```python
class CategoryFactory(BaseFactory):
    class Meta:
        model = Category
    name = Faker("word")

class ItemFactory(BaseFactory):
    class Meta:
        model = Item
    name = Faker("word")
    category = SubFactory(CategoryFactory)
```

Tests:

- `test_base_factory__creates_instance_with_id` — bind session, call `CategoryFactory.create()`, verify `.id` is not None
- `test_base_factory__accepts_overrides` — `CategoryFactory.create(name="Custom")` → `name == "Custom"`
- `test_base_factory__auto_flushes` — after `create()`, query the session for the object by ID, verify it's found
- `test_base_factory__subfactory_creates_related` — `ItemFactory.create()` without passing category → `item.category` is not None, has an `.id`
- `test_base_factory__subfactory_accepts_existing` — create a category, pass to `ItemFactory.create(category=cat)` → `item.category_id == cat.id`
- `test_bind_session__sets_session_on_all_factories` — call `bind_session(session)`, verify `CategoryFactory._meta.sqlalchemy_session` is `session.sync_session`
- `test_bind_session__clears_on_none` — call `bind_session(None)`, verify session is None
- `test_register__creates_fixture_with_correct_name` — register `CategoryFactory`, check the fixture function's `__name__` is `create_category`
- `test_model_name_to_fixture_name__standard_cases` — `User` → `create_user`, `UserProfile` → `create_user_profile`, `HTTPLog` → `create_http_log`
- `test_discover_and_collect_fixtures__finds_factory_modules` — create a temp directory structure with a `tests/factories.py` file, call `discover_and_collect_fixtures`, verify the registry contains the expected fixture

### Step 4.4: Verify

```bash
pytest tests/test_factories.py -v
```

Commit: `feat: factories module — BaseFactory, register(), auto-discovery, re-exports`

---

## Phase 5: Plugin Module

**Goal:** The pytest plugin that auto-registers markers and runs factory linting at collection time.

### Step 5.1: Build plugin.py

Implement `plugin.py` with:

**`pytest_configure(config)`**
- Register markers: `e2e`, `slow`, `allow_network`

**`pytest_collection_modifyitems(config, items)`**
- Import the app's Base (try `from app.models import Base` — if ImportError, skip silently)
- Call `discover_and_collect_fixtures()` to import all factory modules
- Discover all models via `Base.registry.mappers`
- Discover all factory-covered models via `BaseFactory.__subclasses__()`
- For each uncovered model: `warnings.warn(f"FACTORY MISSING: ...")`
- For each test file in `items`: AST-parse it, look for direct `ModelName(...)` calls, warn on each

Helper functions:
- `_discover_models(base_class) -> dict[str, type]` — walks `base_class.registry.mappers`
- `_discover_factory_models() -> set[str]` — walks `BaseFactory.__subclasses__()` recursively
- `_find_direct_model_usage(filepath, model_names) -> list[str]` — AST parser
- `_to_snake(name) -> str` — PascalCase to snake_case

### Step 5.2: Add the entry point to pyproject.toml

```toml
[project.entry-points.pytest11]
bluefox_test = "bluefox_test.plugin"
```

### Step 5.3: Test plugin.py

Write `tests/test_plugin.py`:

- `test_markers_registered` — use `pytestconfig` fixture, verify `e2e`, `slow`, `allow_network` markers exist
- `test_find_direct_model_usage__detects_instantiation` — write a temp Python file containing `User(name="x")`, call `_find_direct_model_usage`, verify violation found
- `test_find_direct_model_usage__ignores_function_calls` — temp file with `create_user(name="x")`, no violations
- `test_find_direct_model_usage__handles_syntax_error` — temp file with invalid Python, returns empty list
- `test_to_snake__converts_correctly` — `User` → `user`, `UserProfile` → `user_profile`, `HTTPLog` → `http_log`, `APIKey` → `api_key`

The model discovery and factory coverage checks are harder to unit test in isolation (they depend on having a real Base with mappers). We'll integration-test those in Phase 7 when we have the toy app.

### Step 5.4: Verify

```bash
pytest tests/test_plugin.py -v
```

Commit: `feat: plugin module — auto-register markers, factory linting`

---

## Phase 6: Setup Function + E2E Module

**Goal:** `bluefox_test_setup()` and `bluefox_e2e_setup()` — the two main entry points that wire everything together.

### Step 6.1: Build the main setup function

Add `bluefox_test_setup()` to `__init__.py` (or a separate `setup.py` module, imported in `__init__.py`). This is the biggest single function. It dynamically creates and returns a dict of pytest fixtures.

**Signature:**

```python
def bluefox_test_setup(
    base,
    binds: dict[str, str] | None = None,
    src_root: str = "src",
    postgres_image: str = "postgres:16-alpine",
    redis_image: str = "redis:7-alpine",
    app_factory: str | None = "app.main:create_app",
    session_dependency: str | None = "app.deps:get_session",
) -> dict[str, Any]:
```

**What it returns (as a dict of `fixture_name -> fixture_function`):**

Each fixture is created as a local function, decorated with `@pytest.fixture(scope=...)` or `@pytest_asyncio.fixture(scope=...)`, then added to the result dict.

Fixtures to create:

1. `infra` (session) — calls `start_containers()`, yields, calls `stop_containers()`
2. `safe_env` (session, autouse) — calls `override_env_with_containers()`, depends on `infra` and bind fixtures
3. `engine` (session) — creates async engine from `infra` URL, runs `base.metadata.create_all`, yields, disposes
4. `bind_engines` (session) — if `binds` provided: for each bind, create engine, import the bind's Base (from the dotted path in `binds` dict value), create_all, yield dict
5. `db` (function) — opens `scoped_test_session(engine)`, calls `bind_session(session)`, yields, calls `bind_session(None)`
6. `db_<bind>` (function) — one per bind key, same SAVEPOINT pattern
7. `app` (function) — if `app_factory` is not None: import the factory function, create app, override `session_dependency` with test session, yield
8. `client` (function) — httpx AsyncClient via ASGI transport, depends on `app`

Also call `discover_and_collect_fixtures(src_root)` and merge those into the result dict.

**Important implementation detail:** The fixture functions need correct `__name__` attributes and parameter names for pytest to resolve dependencies. Use `inspect.Signature` to set parameters dynamically for fixtures that depend on other generated fixtures (e.g., `db` depends on `engine`, which is also in the dict). Alternatively, since all fixtures end up in the same `globals()`, pytest can resolve them by name.

The dotted path imports (`app_factory`, `session_dependency`, each bind's Base) should use `importlib.import_module` + `getattr`:

```python
def _import_dotted(path: str):
    module_path, attr_name = path.rsplit(":", 1)
    module = importlib.import_module(module_path)
    return getattr(module, attr_name)
```

If `app_factory is None`, don't generate `app` or `client` fixtures (the user will define their own).

### Step 6.2: Build e2e.py

Implement `bluefox_e2e_setup()`:

**Signature:**

```python
def bluefox_e2e_setup(
    login_endpoint: str = "/auth/login",
    login_payload: dict | None = None,
    token_field: str = "access_token",
    base_url_env: str = "E2E_BASE_URL",
    default_base_url: str = "http://localhost:8081",
    cache_dir: str = "e2e/.auth",
) -> dict[str, Any]:
```

**Fixtures to create and return:**

1. `server` (session) — reads `os.environ.get(base_url_env, default_base_url)`
2. `auth_token` (session) — checks cache file in `cache_dir`, if missing: POST to `{server}{login_endpoint}` with `login_payload`, extract `token_field`, write cache, return token
3. `api` (function) — `httpx.Client` with `Authorization: Bearer {auth_token}`, `base_url=server`
4. `api_anon` (function) — `httpx.Client` with no auth, `base_url=server`

### Step 6.3: Update __init__.py with final exports

```python
from bluefox_test.setup import bluefox_test_setup
from bluefox_test.e2e import bluefox_e2e_setup
from bluefox_test.factories import (
    BaseFactory, register,
    Faker, SubFactory, LazyFunction, LazyAttribute, Sequence, Iterator, Trait,
)

__all__ = [
    "bluefox_test_setup",
    "bluefox_e2e_setup",
    "BaseFactory",
    "register",
    "Faker",
    "SubFactory",
    "LazyFunction",
    "LazyAttribute",
    "Sequence",
    "Iterator",
    "Trait",
]
```

### Step 6.4: Test the setup functions

Write `tests/test_setup.py`:

Testing `bluefox_test_setup()` end-to-end requires a mock app structure. Create a temp directory with:

- A `Base` class
- A model
- A `tests/factories.py` with a factory + `register()` call
- A `create_app` function that returns a FastAPI app
- A `get_session` dependency

This is an integration test. The approach:

- Create the temp structure in a fixture
- Add the temp dir to `sys.path`
- Call `bluefox_test_setup(base=Base, src_root=temp_dir)`
- Verify the returned dict contains the expected fixture names: `infra`, `safe_env`, `engine`, `db`, `app`, `client`, plus the `create_*` fixtures from the factory
- Verify fixture types are callable

Write `tests/test_e2e_setup.py`:

- `test_bluefox_e2e_setup__returns_expected_fixtures` — call `bluefox_e2e_setup()`, verify dict contains `server`, `auth_token`, `api`, `api_anon`
- The actual HTTP calls are hard to test without a running server — we'll integration-test those in Phase 7

### Step 6.5: Verify

```bash
pytest tests/test_setup.py tests/test_e2e_setup.py -v
```

Commit: `feat: setup functions — bluefox_test_setup() and bluefox_e2e_setup()`

---

## Phase 7: Integration Test with Toy App

**Goal:** Prove the entire system works end-to-end by building the todo app from the walkthrough and running real tests against it.

This is the most important phase. It validates every module working together.

### Step 7.1: Create the toy app inside the test suite

Create a `tests/toyapp/` directory inside the package repo. This is NOT a separate project — it's a test fixture that proves the package works:

```
tests/
  toyapp/
    app/
      __init__.py
      main.py          # create_app() returning a FastAPI app
      deps.py          # get_session dependency
      models.py        # Base
    auth/
      __init__.py
      models.py        # User model
      routes.py        # POST /auth/login (simple JWT)
      service.py       # hash_password, create_access_token
    todos/
      __init__.py
      models.py        # Todo model (FK to User)
      routes.py        # CRUD: GET/POST/PATCH/DELETE /todos
      service.py       # business logic
```

Keep the app minimal but real:

- `create_app()` creates a FastAPI app, includes auth and todo routers
- `get_session` yields an async session (production-style, from a sessionmaker)
- `User` model: id, email, name, password_hash, is_active
- `Todo` model: id, title, description, is_completed, owner_id (FK to users)
- Login endpoint: accepts email/password, returns a JWT
- Todo endpoints: CRUD with owner-based filtering
- Auth dependency: reads JWT from Authorization header, resolves user

Use `python-jose` or `PyJWT` for JWT encoding (add as a test dependency).

### Step 7.2: Create the toy app's test infrastructure

Create the conftest and factories as a user of the package would:

```
tests/
  toyapp/
    conftest.py              # bluefox_test_setup(base=Base)
    auth/
      tests/
        __init__.py
        factories.py         # UserFactory + register()
        test_routes.py
    todos/
      tests/
        __init__.py
        factories.py         # TodoFactory + register()
        test_routes.py
        test_service.py
```

The `conftest.py`:

```python
from bluefox_test import bluefox_test_setup
# Import from the toyapp
import sys
sys.path.insert(0, str(Path(__file__).parent))
from app.models import Base

globals().update(bluefox_test_setup(
    base=Base,
    src_root=str(Path(__file__).parent),
    app_factory="app.main:create_app",
    session_dependency="app.deps:get_session",
))
```

### Step 7.3: Write the toy app tests

These are the tests from the walkthrough doc, adapted to actually run:

**`auth/tests/factories.py`:**
```python
from bluefox_test import BaseFactory, register, Faker
from auth.models import User

class UserFactory(BaseFactory):
    class Meta:
        model = User
    email = Faker("email")
    name = Faker("name")
    password_hash = "placeholder"
    is_active = True

create_user = register(UserFactory)
```

**`auth/tests/test_routes.py`** — 4-5 tests:
- Register creates user
- Register rejects duplicate email
- Login returns JWT
- Login rejects wrong password

**`todos/tests/factories.py`:**
```python
from bluefox_test import BaseFactory, register, Faker, SubFactory
from todos.models import Todo
from auth.tests.factories import UserFactory

class TodoFactory(BaseFactory):
    class Meta:
        model = Todo
    title = Faker("sentence", nb_words=4)
    description = ""
    is_completed = False
    owner = SubFactory(UserFactory)

create_todo = register(TodoFactory)
```

**`todos/tests/test_routes.py`** — 4-5 tests:
- List todos returns own todos only
- Create todo with defaults
- Complete todo marks as completed
- Delete todo removes it

**`todos/tests/test_service.py`** — 3-4 tests:
- Direct service function calls using `db` and factories

### Step 7.4: Write a constraint test

**`auth/tests/test_models.py`:**
- Unique email constraint test (the `.commit()` case)

### Step 7.5: Verify factory linting

Run `pytest --collect-only -q` and verify:
- No `FACTORY MISSING` warnings (all models have factories)
- Add a model WITHOUT a factory and verify the warning appears
- Add a direct `User(...)` call in a test file and verify the warning appears

### Step 7.6: Verify the full suite

```bash
cd tests/toyapp
pytest -v
```

All tests should pass. The output should show testcontainers starting up, tables being created, tests running, and containers being torn down.

### Step 7.7: Verify

Run the full package test suite (including unit tests from Phases 1-6 AND the toyapp integration tests):

```bash
pytest -v
```

Commit: `test: integration test with full toy app — proves end-to-end flow`

---

## Phase 8: Documentation (MkDocs Material)

**Goal:** A deployed documentation site on GitHub Pages.

### Step 8.1: Add MkDocs dependencies

Add to pyproject.toml as a `docs` dependency group:

```toml
[dependency-groups]
docs = [
    "mkdocs-material>=9.5",
    "mkdocs-minify-plugin>=0.8",
]
```

### Step 8.2: Create mkdocs.yml

```yaml
site_name: bluefox-test
site_description: Test infrastructure for FastAPI + async SQLAlchemy apps
repo_url: https://github.com/bluefox-software/pytest-bluefox

theme:
  name: material
  palette:
    - scheme: default
      primary: indigo
      accent: blue
      toggle:
        icon: material/brightness-7
        name: Switch to dark mode
    - scheme: slate
      primary: indigo
      accent: blue
      toggle:
        icon: material/brightness-4
        name: Switch to light mode
  features:
    - content.code.copy
    - content.code.annotate
    - navigation.sections
    - navigation.expand
    - navigation.top
    - toc.follow

markdown_extensions:
  - pymdownx.highlight:
      anchor_linenums: true
  - pymdownx.superfences
  - pymdownx.tabbed:
      alternate_style: true
  - admonitions
  - pymdownx.details
  - attr_list
  - toc:
      permalink: true

nav:
  - Home: index.md
  - Getting Started: getting-started.md
  - Walkthrough: walkthrough.md
  - Reference:
    - bluefox_test_setup(): reference/setup.md
    - bluefox_e2e_setup(): reference/e2e.md
    - Factories: reference/factories.md
    - Safety: reference/safety.md
  - Guides:
    - Multiple Databases: guides/multiple-databases.md
    - Playwright E2E: guides/playwright.md
    - CI Setup: guides/ci.md
    - Custom App Wiring: guides/custom-app-wiring.md
  - Contributing:
    - Docs Maintainer Guide: contributing/docs.md
    - Publishing to PyPI: contributing/publishing.md

plugins:
  - search
  - minify:
      minify_html: true
```

### Step 8.3: Create docs content

Convert our three existing docs into the MkDocs structure:

```
docs/
  index.md
  getting-started.md
  walkthrough.md
  reference/
    setup.md
    e2e.md
    factories.md
    safety.md
  guides/
    multiple-databases.md
    playwright.md
    ci.md
    custom-app-wiring.md
  contributing/
    docs.md
    publishing.md
```

**`index.md`** — rework the package README into a landing page. Should include:
- What the package does (3 bullet points)
- The 3-line conftest example
- Quick install instructions
- Links to Getting Started and Walkthrough

**`getting-started.md`** — the adoption guide, reformatted for MkDocs. Use admonitions for callouts (`!!! tip`, `!!! warning`, `!!! danger`).

**`walkthrough.md`** — the todo app walkthrough, verbatim with minor formatting tweaks.

**`reference/setup.md`** — `bluefox_test_setup()` API docs. Parameters, return value, fixtures provided, examples. Extract from the package README's relevant section.

**`reference/e2e.md`** — `bluefox_e2e_setup()` API docs. Same treatment.

**`reference/factories.md`** — `BaseFactory`, `register()`, and all re-exports (`Faker`, `SubFactory`, etc.). Include the factory file example pattern and SubFactory usage.

**`reference/safety.md`** — Host whitelist, `test_` prefix, `install_network_guard()`. When to use the network guard, how to exempt tests.

**`guides/multiple-databases.md`** — extract from the adoption guide's multi-bind section. Include the `binds={}` parameter, per-bind session fixtures, `register(Factory, session_fixture="db_analytics")` pattern.

**`guides/playwright.md`** — the Playwright auth fixtures from the adoption guide's E2E section. The copy-paste code with explanation.

**`guides/ci.md`** — GitHub Actions workflow for both `test` and `e2e` jobs.

**`guides/custom-app-wiring.md`** — how to override `app` and `client` when `app_factory=None`. Short, focused.

**`contributing/docs.md`** — the docs maintainer guide. Covers: how MkDocs works, how to add/edit/remove pages, Markdown formatting reference (code blocks, admonitions, tabs, tables), how to preview locally, how deployment works, troubleshooting, and style conventions. This is the "I haven't touched docs in 3 months" reference. Use the `docs-maintainer-guide.md` spec document as the source.

**`contributing/publishing.md`** — PyPI publishing reference. Covers: one-time setup (PyPI account, trusted publishing, GitHub environment), the release flow (bump version, commit, tag, push), git tags crash course, version numbering, testing before publishing, and checklists for first and subsequent releases. Use the `pypi-publishing-guide.md` spec document as the source.

### Step 8.4: Verify locally

```bash
pip install -e ".[docs]"
mkdocs serve
```

Open `http://127.0.0.1:8000`, verify all pages render correctly, navigation works, code blocks have copy buttons.

### Step 8.5: Commit

Commit: `docs: MkDocs Material site with all guides and reference`

---

## Phase 9: Publish Infrastructure

**Goal:** Automated PyPI publishing and docs deployment via GitHub Actions.

Follow the `pypi-publishing-guide.md` spec document for the detailed PyPI setup. The steps below are the implementation actions.

Also add the publishing guide to the docs site as `contributing/publishing.md`.

### Step 9.1: GitHub Actions — test workflow

Create `.github/workflows/test.yml`:

- Trigger: push and pull_request
- Matrix: Python 3.12 (can add 3.13 later)
- Steps: checkout, setup Python, `pip install -e ".[test]"`, `pytest -v`
- Docker is pre-installed on `ubuntu-latest`

### Step 9.2: GitHub Actions — publish workflow

Create `.github/workflows/publish.yml`:

- Trigger: push tags matching `v*`
- Environment: `pypi`
- Permissions: `id-token: write` (trusted publishing)
- Steps: checkout, setup Python, `pip install build`, `python -m build`, `pypa/gh-action-pypi-publish@release/v1`

### Step 9.3: GitHub Actions — docs workflow

Create `.github/workflows/docs.yml`:

- Trigger: push to `main`
- Permissions: `contents: write`
- Steps: checkout, setup Python, `pip install mkdocs-material mkdocs-minify-plugin`, `mkdocs gh-deploy --force`

### Step 9.4: PyPI trusted publishing setup

1. Go to pypi.org → Account → Publishing → Add new pending publisher
2. Project name: `bluefox-test`
3. Owner: `bluefox-software`
4. Repository: `pytest-bluefox`
5. Workflow name: `publish.yml`
6. Environment: `pypi`

### Step 9.5: GitHub Pages setup

1. Go to repo Settings → Pages
2. Source: Deploy from a branch
3. Branch: `gh-pages` (created by `mkdocs gh-deploy`)

### Step 9.6: First release

```bash
# Make sure everything is committed and pushed
git tag v0.1.0
git push origin v0.1.0
```

Verify:
- GitHub Action runs and publishes to PyPI
- `pip install bluefox-test` works from a clean virtualenv
- Docs are live at `https://bluefox-software.github.io/pytest-bluefox/`

Commit: `ci: publish to PyPI and deploy docs on tag/push`

---

## Phase Summary

| Phase | What | Depends On | Key Output |
|---|---|---|---|
| 1 | Safety module | Nothing | `safety.py` with tests |
| 2 | Containers module | Docker | `containers.py` with tests |
| 3 | Session module | Phase 2 | `session.py` with tests |
| 4 | Factories module | Phase 3 | `factories.py` with tests, re-exports |
| 5 | Plugin module | Phase 4 | `plugin.py` with tests, entry point |
| 6 | Setup functions | Phase 1-5 | `bluefox_test_setup()`, `bluefox_e2e_setup()` |
| 7 | Toy app integration | Phase 6 | Full end-to-end proof |
| 8 | Documentation | Phase 7 | MkDocs Material site |
| 9 | Publish infra | Phase 8 | PyPI + GitHub Pages |

Each phase is one or two Claude Code sessions. Phases 1-5 are pure library code with unit tests. Phase 6 is the glue. Phase 7 is the real validation. Phases 8-9 are packaging.

---

## File Tree at Completion

```
pytest-bluefox/
  bluefox_test/
    __init__.py              # Public API: bluefox_test_setup, BaseFactory, register, Faker, etc.
    setup.py                 # bluefox_test_setup() implementation
    containers.py            # start_containers, stop_containers, create_bind_databases
    safety.py                # enforce_safety, override_env, install_network_guard
    session.py               # create_test_engine, scoped_test_session
    factories.py             # BaseFactory, register, bind_session, discover_and_collect_fixtures
    plugin.py                # pytest11 hooks: markers + factory linting
    e2e.py                   # bluefox_e2e_setup()
  tests/
    __init__.py
    conftest.py              # shared fixtures (pg_container, engine)
    test_safety.py           # Phase 1
    test_containers.py       # Phase 2
    test_session.py          # Phase 3
    test_factories.py        # Phase 4
    test_plugin.py           # Phase 5
    test_setup.py            # Phase 6
    test_e2e_setup.py        # Phase 6
    toyapp/                  # Phase 7
      conftest.py
      app/
        __init__.py
        main.py
        deps.py
        models.py
      auth/
        __init__.py
        models.py
        routes.py
        service.py
        tests/
          __init__.py
          factories.py
          test_routes.py
          test_models.py
      todos/
        __init__.py
        models.py
        routes.py
        service.py
        tests/
          __init__.py
          factories.py
          test_routes.py
          test_service.py
  docs/                      # Phase 8
    index.md
    getting-started.md
    walkthrough.md
    reference/
      setup.md
      e2e.md
      factories.md
      safety.md
    guides/
      multiple-databases.md
      playwright.md
      ci.md
      custom-app-wiring.md
    contributing/
      docs.md
      publishing.md
  .github/                   # Phase 9
    workflows/
      test.yml
      publish.yml
      docs.yml
  mkdocs.yml                 # Phase 8
  pyproject.toml
  README.md
  .gitignore
```
