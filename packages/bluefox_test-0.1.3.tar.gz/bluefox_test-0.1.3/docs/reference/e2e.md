# bluefox_e2e_setup()

Setup function for black-box E2E testing against a running server.

---

## Signature

```python
def bluefox_e2e_setup(
    login_endpoint: str = "/auth/login",
    login_payload: dict | None = None,
    token_field: str = "access_token",
    base_url_env: str = "E2E_BASE_URL",
    default_base_url: str = "http://localhost:8081",
    cache_dir: str = "e2e/.auth",
) -> dict[str, Any]:
```

Returns a dict of pytest fixtures. Inject via `globals().update(...)` in your `e2e/conftest.py`.

---

## Parameters

| Parameter | Type | Default | Description |
|---|---|---|---|
| `login_endpoint` | `str` | `"/auth/login"` | Path to your login API endpoint |
| `login_payload` | `dict \| None` | `None` | JSON body for the login request |
| `token_field` | `str` | `"access_token"` | Key in the login response JSON that contains the JWT |
| `base_url_env` | `str` | `"E2E_BASE_URL"` | Environment variable for the server URL |
| `default_base_url` | `str` | `"http://localhost:8081"` | Fallback URL when the env var is not set |
| `cache_dir` | `str` | `"e2e/.auth"` | Directory for caching the JWT to disk |

---

## Fixtures provided

| Fixture | Scope | Description |
|---|---|---|
| `server` | session | Base URL from env var or default |
| `auth_token` | session | JWT, obtained once via login endpoint, cached to disk |
| `api` | function | httpx `Client` with `Authorization: Bearer <token>` header |
| `api_anon` | function | httpx `Client` with no auth |

---

## Example

```python title="e2e/conftest.py"
from bluefox_test.e2e import bluefox_e2e_setup

globals().update(bluefox_e2e_setup(
    login_endpoint="/auth/login",
    login_payload={"email": "e2e@test.com", "password": "testpassword123"},
))
```

```python title="e2e/test_user_crud.py"
import pytest

pytestmark = pytest.mark.e2e


def test_create_user__returns_created_user(api):
    response = api.post("/users", json={"name": "E2E User", "email": "e2e-new@test.com"})
    assert response.status_code == 201


def test_protected_endpoint__rejects_unauthenticated(api_anon):
    response = api_anon.get("/users/me")
    assert response.status_code == 401
```

!!! note
    E2E tests use synchronous httpx `Client`, not `AsyncClient`. They hit a real running server over HTTP.

---

## Token caching

The `auth_token` fixture authenticates once per test session and caches the JWT to `{cache_dir}/token.json`. On subsequent runs, it reads the cached token instead of re-authenticating.

Add `e2e/.auth/` to your `.gitignore`.
