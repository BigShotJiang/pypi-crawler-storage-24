# PyPI Publishing Guide

A personal reference for publishing Python packages to PyPI. Written for `bluefox-test` but applies to any package.

---

## One-Time Setup (do this once, ever)

### 1. Create a PyPI account

Go to [pypi.org/account/register](https://pypi.org/account/register/). Enable 2FA (required for trusted publishing).

### 2. Register the package name

Go to [pypi.org/manage/account/publishing](https://pypi.org/manage/account/publishing/) → "Add a new pending publisher".

Fill in:

- **PyPI project name:** `bluefox-test`
- **Owner:** `bluefox-software` (your GitHub org or username)
- **Repository name:** `pytest-bluefox`
- **Workflow name:** `publish.yml`
- **Environment name:** `pypi`

This tells PyPI: "trust GitHub Actions from this repo to publish this package." No API tokens needed.

### 3. Create the GitHub environment

In your repo → Settings → Environments → New environment → name it `pypi`. No extra rules needed, just create it.

### 4. Add the publish workflow

```yaml
# .github/workflows/publish.yml
name: Publish to PyPI
on:
  push:
    tags: ["v*"]

jobs:
  publish:
    runs-on: ubuntu-latest
    environment: pypi
    permissions:
      id-token: write
    steps:
      - uses: actions/checkout@v4
      - uses: actions/setup-python@v5
        with:
          python-version: "3.12"
      - run: pip install build
      - run: python -m build
      - uses: pypa/gh-action-pypi-publish@release/v1
```

Commit and push this to `main`. The workflow won't run yet — it only triggers on tags.

---

## Releasing a Version

Every time you want to publish a new version:

### 1. Bump the version in pyproject.toml

```toml
[project]
version = "0.2.0"  # ← change this
```

### 2. Commit the version bump

```bash
git add pyproject.toml
git commit -m "release: v0.2.0"
git push
```

### 3. Create and push a tag

```bash
git tag v0.2.0
git push origin v0.2.0
```

That's it. The GitHub Action triggers on the tag push, builds the package, and publishes to PyPI. Takes about 30 seconds.

### 4. Verify

```bash
pip install bluefox-test==0.2.0
```

Or check [pypi.org/project/bluefox-test](https://pypi.org/project/bluefox-test/).

---

## Git Tags Crash Course

Tags are just named pointers to a specific commit. Unlike branches, they don't move.

```bash
# Create a tag on the current commit
git tag v0.1.0

# Push the tag to GitHub (tags are NOT pushed by default)
git push origin v0.1.0

# Push all tags at once
git push --tags

# List all tags
git tag

# List tags with messages
git tag -n

# See which commit a tag points to
git show v0.1.0

# Delete a local tag (if you made a mistake)
git tag -d v0.1.0

# Delete a remote tag (if you pushed a bad one)
git push origin --delete v0.1.0

# Tag a PAST commit (not the current one)
git tag v0.0.1 abc1234
```

### The release flow visually

```
main:  A --- B --- C --- D (bump version) --- E
                                |
                            v0.2.0 (tag)
```

The tag `v0.2.0` points at commit D. When you `git push origin v0.2.0`, GitHub sees it and triggers the `publish.yml` workflow.

### Common mistakes

**Forgot to push the tag.** `git tag v0.1.0` only creates it locally. You must `git push origin v0.1.0` separately. Tags are never included in a regular `git push`.

**Tag doesn't match pyproject.toml version.** Keep them in sync. Tag `v0.2.0` should correspond to `version = "0.2.0"` in pyproject.toml. Nothing enforces this — it's just discipline.

**Tagged the wrong commit.** Delete and re-tag:

```bash
git tag -d v0.2.0                    # delete local
git push origin --delete v0.2.0      # delete remote
# fix whatever needs fixing, commit
git tag v0.2.0                       # re-tag
git push origin v0.2.0               # push new tag
```

**Published a broken version.** You cannot re-publish the same version number to PyPI (even if you delete it). Bump to a patch version: `0.2.0` → `0.2.1`.

---

## Version Numbering

Use [semver](https://semver.org/): `MAJOR.MINOR.PATCH`

- **PATCH** (`0.1.0` → `0.1.1`): Bug fixes, no API changes
- **MINOR** (`0.1.1` → `0.2.0`): New features, backwards compatible
- **MAJOR** (`0.2.0` → `1.0.0`): Breaking changes to public API

While you're pre-1.0 (which `bluefox-test` will be for a while), minor versions can include breaking changes. That's normal. Once you hit 1.0, the contract gets stricter.

Apps should pin with a compatible range:

```toml
"bluefox-test>=0.2.0,<1.0"    # accepts 0.2.0, 0.2.1, 0.3.0, etc.
"bluefox-test>=0.2.0,<0.3"    # stricter: only 0.2.x patches
"bluefox-test==0.2.0"          # exact pin (not recommended)
```

---

## Testing Before Publishing

If you want to verify the build without publishing:

```bash
pip install build
python -m build
```

This creates `dist/bluefox_test-0.2.0.tar.gz` and `dist/bluefox_test-0.2.0-py3-none-any.whl`.

Test-install the wheel locally:

```bash
pip install dist/bluefox_test-0.2.0-py3-none-any.whl
python -c "from bluefox_test import BaseFactory; print('works')"
```

### Test PyPI (optional, for paranoia)

PyPI has a staging environment at [test.pypi.org](https://test.pypi.org). You can publish there first to verify everything works without polluting the real index.

Set up a second trusted publisher on test.pypi.org (same process as real PyPI). Then use a separate workflow or manual upload:

```bash
pip install twine
twine upload --repository testpypi dist/*
```

Install from test PyPI:

```bash
pip install --index-url https://test.pypi.org/simple/ bluefox-test
```

This is overkill for most releases. The local wheel test is usually enough.

---

## Checklist: Your First Release

- [ ] PyPI account created with 2FA
- [ ] Pending publisher registered on pypi.org
- [ ] `pypi` environment created in GitHub repo settings
- [ ] `.github/workflows/publish.yml` committed and pushed to `main`
- [ ] `pyproject.toml` has `version = "0.1.0"` and correct metadata
- [ ] All tests pass locally
- [ ] Version bump committed: `git commit -m "release: v0.1.0"`
- [ ] Tag created: `git tag v0.1.0`
- [ ] Tag pushed: `git push origin v0.1.0`
- [ ] GitHub Actions tab shows the publish workflow succeeded
- [ ] `pip install bluefox-test` works from a clean virtualenv

## Checklist: Subsequent Releases

- [ ] Bump version in `pyproject.toml`
- [ ] Commit: `git commit -m "release: vX.Y.Z"`
- [ ] Push: `git push`
- [ ] Tag: `git tag vX.Y.Z`
- [ ] Push tag: `git push origin vX.Y.Z`
- [ ] Verify on PyPI
