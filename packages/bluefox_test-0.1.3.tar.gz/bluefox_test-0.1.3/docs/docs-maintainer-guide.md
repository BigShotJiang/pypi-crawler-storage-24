# Documentation Maintainer Guide

How to work with the bluefox-test docs site. Read this when you haven't touched docs in a while and forgot how everything works.

---

## How It Works

The docs site is built with [MkDocs Material](https://squidfinity.github.io/mkdocs-material/). It turns Markdown files in `docs/` into a static website. The site auto-deploys to GitHub Pages when you push to `main`.

The entire system is: write Markdown → push → site updates.

---

## Quick Reference

```bash
# Install docs dependencies (one-time, or after a fresh clone)
pip install -e ".[docs]"

# Preview locally (auto-reloads on save)
mkdocs serve
# Open http://127.0.0.1:8000

# Deploy manually (normally handled by CI)
mkdocs gh-deploy --force
```

---

## File Structure

```
pytest-bluefox/
  mkdocs.yml                 # Site config: navigation, theme, extensions
  docs/
    index.md                 # Home page
    getting-started.md       # Adoption guide
    walkthrough.md           # Todo app step-by-step
    reference/
      setup.md               # bluefox_test_setup() API
      e2e.md                 # bluefox_e2e_setup() API
      factories.md           # BaseFactory, register(), re-exports
      safety.md              # Host whitelist, network guard
    guides/
      multiple-databases.md  # Multi-bind setup
      playwright.md          # Browser E2E
      ci.md                  # GitHub Actions
      custom-app-wiring.md   # When conventions don't fit
```

Every page is a plain Markdown file. Nothing special — just Markdown with some extra features from MkDocs Material (covered below).

---

## Common Tasks

### Add a new page

1. Create a `.md` file in the appropriate directory:

```bash
# New guide
touch docs/guides/my-new-guide.md

# New reference page
touch docs/reference/my-api.md
```

2. Write Markdown content in the file.

3. Add it to the navigation in `mkdocs.yml`:

```yaml
nav:
  - Home: index.md
  - Getting Started: getting-started.md
  - Guides:
    - Existing Guide: guides/existing.md
    - My New Guide: guides/my-new-guide.md    # ← add here
```

If you skip step 3, the page still exists at its URL but won't appear in the navigation sidebar.

### Edit an existing page

Just edit the `.md` file directly. If you're running `mkdocs serve`, the browser auto-reloads when you save.

### Rename or move a page

1. Move the file
2. Update the path in `mkdocs.yml` nav
3. If other pages link to it, update those links too

### Remove a page

1. Delete the file
2. Remove the entry from `mkdocs.yml` nav

### Preview changes locally

```bash
mkdocs serve
```

Opens at `http://127.0.0.1:8000`. Watches for file changes and reloads automatically. Kill with `Ctrl+C`.

### Check for broken links

MkDocs warns about broken links during build:

```bash
mkdocs build --strict
```

This fails on any warning (broken links, missing pages referenced in nav, etc.). CI should run this.

---

## Formatting Reference

### Everything from standard Markdown works

```markdown
# Heading 1
## Heading 2
### Heading 3

Regular paragraph text. **Bold**, *italic*, `inline code`.

[Link text](https://example.com)
[Link to another page](../guides/playwright.md)

- Bullet list
- Another item

1. Numbered list
2. Another item
```

### Code blocks (with syntax highlighting)

````markdown
```python
from bluefox_test import BaseFactory, register

class UserFactory(BaseFactory):
    class Meta:
        model = User
```
````

Supported languages: `python`, `toml`, `yaml`, `bash`, `sql`, `json`, `html`, `javascript`, and many more. The language tag after the triple backtick controls highlighting.

Code blocks automatically get a "copy" button in the top-right corner (configured in `mkdocs.yml`).

### Code block with a title

````markdown
```python title="src/users/tests/factories.py"
class UserFactory(BaseFactory):
    ...
```
````

Renders with a filename header above the code block.

### Code block with highlighted lines

````markdown
```python hl_lines="2 3"
class UserFactory(BaseFactory):
    class Meta:           # ← highlighted
        model = User      # ← highlighted
```
````

### Admonitions (callout boxes)

```markdown
!!! note
    This is a note. Use for supplementary information.

!!! tip
    This is a tip. Use for helpful suggestions.

!!! warning
    This is a warning. Use for things that could go wrong.

!!! danger
    This is a danger box. Use for things that WILL go wrong.

!!! example
    This is an example box. Use for worked examples.

!!! info
    This is an info box. Use for background context.
```

Each renders as a colored callout box with an icon.

### Admonition with custom title

```markdown
!!! warning "Don't skip this step"
    The safety check must run before any engine is created.
```

### Collapsible admonition

```markdown
??? note "Click to expand"
    This content is hidden by default.

???+ note "Expanded by default"
    This content is visible but can be collapsed.
```

### Tabs (for showing alternatives)

```markdown
=== "Single Database"

    ```python
    globals().update(bluefox_test_setup(base=Base))
    ```

=== "Multiple Databases"

    ```python
    globals().update(bluefox_test_setup(
        base=Base,
        binds={"analytics": "analytics.models.AnalyticsBase"},
    ))
    ```
```

Renders as clickable tabs. Use when showing alternative approaches or configurations.

### Tables

```markdown
| Fixture | Scope | Description |
|---|---|---|
| `db` | function | SAVEPOINT-wrapped async session |
| `client` | function | httpx AsyncClient |
| `engine` | session | Async engine for main DB |
```

### Links between pages

```markdown
<!-- Relative link to another page -->
See the [Getting Started](getting-started.md) guide.

<!-- Link to a specific section (use the auto-generated anchor) -->
See [Factory Usage](reference/factories.md#factory-usage-in-tests).

<!-- Link from a nested page to root -->
See the [Home](../index.md) page.
```

Anchors are auto-generated from headings: `## My Section Title` becomes `#my-section-title`.

---

## mkdocs.yml Explained

The config file controls everything about the site. Here are the parts you'll actually touch:

### Navigation

```yaml
nav:
  - Home: index.md
  - Getting Started: getting-started.md
  - Reference:
    - Setup: reference/setup.md
    - Factories: reference/factories.md
  - Guides:
    - CI: guides/ci.md
```

This defines the sidebar navigation. The indentation creates sections. The left side is the display name, the right side is the file path relative to `docs/`.

### Theme settings

```yaml
theme:
  name: material
  palette:
    - scheme: default        # light mode
      primary: indigo
      accent: blue
    - scheme: slate          # dark mode
      primary: indigo
      accent: blue
```

Change `primary` and `accent` to any [Material color](https://squidfinity.github.io/mkdocs-material/setup/changing-the-colors/). Common choices: `indigo`, `blue`, `teal`, `deep-purple`, `cyan`.

### Extensions

```yaml
markdown_extensions:
  - pymdownx.highlight       # code syntax highlighting
  - pymdownx.superfences     # fenced code blocks
  - pymdownx.tabbed          # tabbed content (=== "Tab")
  - admonitions              # callout boxes (!!! note)
  - pymdownx.details         # collapsible admonitions (???)
  - attr_list                # add attributes to elements
  - toc:
      permalink: true        # anchor links on headings
```

You shouldn't need to change these. They enable all the formatting features above.

---

## Deployment

### Automatic (normal flow)

Push to `main` → GitHub Action runs `mkdocs gh-deploy` → site updates at `https://bluefox-software.github.io/pytest-bluefox/`.

The workflow (`.github/workflows/docs.yml`):

```yaml
name: Docs
on:
  push:
    branches: [main]

jobs:
  deploy:
    runs-on: ubuntu-latest
    permissions:
      contents: write
    steps:
      - uses: actions/checkout@v4
      - uses: actions/setup-python@v5
        with:
          python-version: "3.12"
      - run: pip install mkdocs-material mkdocs-minify-plugin
      - run: mkdocs gh-deploy --force
```

### Manual (if needed)

```bash
mkdocs gh-deploy --force
```

This builds the site and pushes to the `gh-pages` branch. Requires push access to the repo.

### GitHub Pages setup (one-time)

1. Repo → Settings → Pages
2. Source: "Deploy from a branch"
3. Branch: `gh-pages`, folder: `/ (root)`
4. Save

After the first `mkdocs gh-deploy`, the site is live.

---

## Troubleshooting

### `mkdocs serve` fails with import errors

```bash
pip install -e ".[docs]"
```

### Page exists but doesn't show in sidebar

Add it to the `nav` section in `mkdocs.yml`.

### Broken link warnings during build

```
WARNING - Doc file 'reference/setup.md' contains a link to 'guides/nonexistent.md' which is not found
```

Fix the link in the source file. Run `mkdocs build --strict` to catch all warnings.

### Admonitions not rendering

Make sure `admonitions` is in the `markdown_extensions` list in `mkdocs.yml`. The syntax must have exactly 4 spaces of indentation for the body:

```markdown
!!! note
    Four spaces here, not a tab.
```

### Tabs not rendering

Make sure `pymdownx.tabbed` with `alternate_style: true` is in extensions. Tab content needs 4-space indentation and a blank line between the `===` line and the content:

```markdown
=== "Tab One"

    Content here (4 spaces, blank line above).
```

### Code highlighting looks wrong

Check the language tag after triple backticks: `` ```python ``, `` ```bash ``, `` ```toml ``. If omitted, no highlighting is applied.

### Site not updating after push

Check the GitHub Actions tab for the docs workflow. If it failed, the error is usually a missing dependency or a `--strict` failure from broken links.

---

## Style Conventions for Our Docs

To keep the docs consistent:

- **Use code blocks for everything runnable.** File paths, commands, config snippets — always in backticks or fenced blocks.
- **Use admonitions sparingly.** One or two per page for genuinely important callouts. Don't wrap every paragraph in a box.
- **Use tabs for alternatives**, not for sequential steps. "Single DB vs Multi DB" = tabs. "Step 1, Step 2, Step 3" = headings.
- **Link between pages.** If you mention `bluefox_test_setup()` in a guide, link to its reference page.
- **Keep pages focused.** Each page answers one question. If a page is growing past ~300 lines, split it.
- **Code examples should be copy-pasteable.** No pseudocode, no `...` elisions unless the surrounding context makes the full code obvious.
- **Title format:** use sentence case for page titles (`Getting started`, not `Getting Started`). Exception: proper nouns and API names (`BaseFactory`, `bluefox_test_setup()`).
