# bluefox-test

Test infrastructure for FastAPI + async SQLAlchemy 2.x applications. Real databases via testcontainers, auto-flushing factories, production safety gates, and zero-config developer experience.

```bash
pip install bluefox-test
```

Published on PyPI as `bluefox-test`. Importable as `bluefox_test`.

---

## What It Does

**For unit/integration tests** — one call in your root conftest:

```python
from bluefox_test import bluefox_test_setup
from app.models import Base

globals().update(bluefox_test_setup(base=Base))
```

You get: ephemeral Postgres + Redis containers, SAVEPOINT-wrapped sessions, safety gates, auto-discovered `create_*` factory fixtures, a wired FastAPI `app`, and an httpx `client`.

**For black-box E2E tests** — one call in your e2e conftest:

```python
from bluefox_test.e2e import bluefox_e2e_setup

globals().update(bluefox_e2e_setup(
    login_endpoint="/auth/login",
    login_payload={"email": "e2e@test.com", "password": "testpassword123"},
))
```

You get: `server`, `auth_token` (cached JWT), `api` (authenticated httpx client), `api_anon` (unauthenticated client).

**Automatically via the pytest plugin:**

- Markers: `e2e`, `slow`, `allow_network` — registered for you, no pyproject.toml entries needed
- Factory linting: warns at collection time when models lack factories or tests instantiate models directly

---

## Package Structure

```
bluefox_test/
  __init__.py          # Public: bluefox_test_setup, BaseFactory, register
  containers.py        # Testcontainers lifecycle (Postgres, Redis)
  safety.py            # Host whitelist, test_ prefix enforcement, network guard
  session.py           # Async SAVEPOINT session management
  factories.py         # BaseFactory, register(), auto-discovery
  plugin.py            # pytest11 entry point: markers, factory linting
  e2e.py               # bluefox_e2e_setup() for black-box tests
```

---

## Public API

### `bluefox_test_setup()`

```python
def bluefox_test_setup(
    base,                                    # SQLAlchemy DeclarativeBase
    binds: dict[str, str] | None = None,     # {"analytics": "analytics.models.AnalyticsBase"}
    src_root: str = "src",                   # where to discover tests/factories.py
    postgres_image: str = "postgres:16-alpine",
    redis_image: str = "redis:7-alpine",
    app_factory: str = "app.main:create_app",     # dotted path to your app factory
    session_dependency: str = "app.deps:get_session",  # dotted path to your DI dependency
) -> dict[str, Any]:
```

Returns a dict of pytest fixtures. Inject via `globals().update(...)`.

**Fixtures provided:**

| Fixture | Scope | Description |
|---|---|---|
| `infra` | session | Starts Postgres + Redis containers |
| `safe_env` | session, autouse | Overwrites env vars with container URLs, runs safety checks |
| `engine` | session | Async engine for main DB, runs `create_all()` |
| `db` | function | SAVEPOINT-wrapped async session, binds factories |
| `app` | function | FastAPI app with test session injected via dependency override |
| `client` | function | httpx `AsyncClient` wired to the app via ASGI transport |
| `bind_engines` | session | Per-bind engines (only when `binds` is provided) |
| `db_<name>` | function | Per-bind sessions (one for each key in `binds`) |
| `create_*` | function | One per factory discovered in `tests/factories.py` files |

**How `app_factory` and `session_dependency` work:**

The package imports your app factory and session dependency using the dotted paths. It creates the app, then overrides the session dependency with the test session:

```python
# This is what happens internally — you don't write this
from app.main import create_app
from app.deps import get_session

application = create_app()
application.dependency_overrides[get_session] = lambda: test_session
```

If your app doesn't follow this pattern, set `app_factory=None` and define your own `app` and `client` fixtures. All other fixtures (`db`, `engine`, `create_*`) still work.

### `bluefox_e2e_setup()`

```python
def bluefox_e2e_setup(
    login_endpoint: str = "/auth/login",
    login_payload: dict | None = None,        # {"email": "...", "password": "..."}
    token_field: str = "access_token",        # key in the login response JSON
    base_url_env: str = "E2E_BASE_URL",       # env var for the server URL
    default_base_url: str = "http://localhost:8081",
    cache_dir: str = "e2e/.auth",             # where to cache the JWT
) -> dict[str, Any]:
```

Returns a dict of pytest fixtures for black-box testing.

| Fixture | Scope | Description |
|---|---|---|
| `server` | session | Base URL from env var or default |
| `auth_token` | session | JWT, obtained once via login endpoint, cached to disk |
| `api` | function | httpx `Client` with `Authorization: Bearer <token>` header |
| `api_anon` | function | httpx `Client` with no auth |

### `BaseFactory`

Extends `factory_boy`'s `SQLAlchemyModelFactory`. Subclass it, declare fields, call `register()`:

```python
from bluefox_test import BaseFactory, register

class UserFactory(BaseFactory):
    class Meta:
        model = User
    name = factory.Faker("name")

create_user = register(UserFactory)
```

Internals:
- `sqlalchemy_session_persistence = "flush"` — `factory_boy` handles `session.add()` + `session.flush()` automatically
- `sqlalchemy_session = None` — set dynamically per test via `bind_session()`
- `.create(_session=...)` — override for cross-bind factories

### `register()`

```python
def register(
    factory_cls: type[BaseFactory],
    session_fixture: str = "db",
) -> pytest.fixture:
```

Turns a factory into a global pytest fixture. The fixture name is derived from the model class: `UserProfile` → `create_user_profile`.

- Default: fixture depends on `db`
- Cross-bind: `register(EventFactory, session_fixture="db_analytics")`

The returned fixture yields a `_create(**overrides)` callable.

### `install_network_guard()` (opt-in)

```python
from bluefox_test.safety import install_network_guard

@pytest.fixture(autouse=True)
def _network_guard(monkeypatch):
    install_network_guard(monkeypatch)
```

Restricts socket connections to local/private IPs. Tests needing external access use `@pytest.mark.allow_network`.

---

## Internals

### containers.py

Starts testcontainers. Both bind to random host ports (safe for parallel xdist workers). For multi-bind: creates additional `test_<bind>` databases inside the same Postgres container via `sqlalchemy_utils.create_database()`.

### safety.py

Runs in the `safe_env` fixture (session-scoped, autouse) after env vars are overwritten but before any engine is created. Two checks:

1. **Host whitelist.** Every `DATABASE_URL` and `*_DATABASE_URL` must point to `localhost`, `127.0.0.1`, `0.0.0.0`, or `db`. Anything else → `pytest.exit(returncode=1)`.

2. **`test_` prefix.** Every database name must start with `test_`. Prevents running against `myapp` instead of `test_myapp`.

### session.py

The SAVEPOINT trick:

1. `BEGIN` (real transaction)
2. `SAVEPOINT` (nested)
3. Yield session to test
4. `ROLLBACK` outer transaction — everything disappears

When app code calls `session.commit()`, an `after_transaction_end` event listener immediately opens a new SAVEPOINT. The outer transaction is never committed. `expire_on_commit=False` prevents `DetachedInstanceError`.

### factories.py

`bind_session(session)` walks all `BaseFactory` subclasses, sets `._meta.sqlalchemy_session` to `session.sync_session`. This works because SQLAlchemy's async layer uses greenlets internally — `factory_boy`'s sync operations execute correctly on `sync_session` within an async context.

`register()` creates a fixture, appends to `_fixture_registry`. `discover_and_collect_fixtures()` imports all `tests/factories.py` modules (triggering `register()` calls), returns the registry.

### plugin.py

Registered as `pytest11` entry point. Provides:

- `pytest_configure`: registers `e2e`, `slow`, `allow_network` markers
- `pytest_collection_modifyitems`: compares `Base.registry.mappers` against `BaseFactory.__subclasses__()`, warns on gaps. AST-parses test files for direct `ModelName(...)` calls.

### e2e.py

`bluefox_e2e_setup()` creates fixtures that authenticate once (via the login endpoint), cache the JWT to disk, and inject it into httpx clients. Session-scoped auth, function-scoped clients.

---

## pyproject.toml (package)

```toml
[project]
name = "bluefox-test"
version = "0.1.0"
description = "Test infrastructure for FastAPI + async SQLAlchemy apps"
requires-python = ">=3.12"
readme = "README.md"

dependencies = [
    "pytest>=8.0",
    "pytest-asyncio>=0.24",
    "testcontainers[postgres,redis]>=4.0",
    "sqlalchemy[asyncio]>=2.0",
    "asyncpg>=0.29",
    "sqlalchemy-utils>=0.41",
    "psycopg2-binary>=2.9",
    "factory-boy>=3.3",
    "faker>=25.0",
    "httpx>=0.27",
]

[project.entry-points.pytest11]
bluefox_test = "bluefox_test.plugin"

[build-system]
requires = ["hatchling"]
build-backend = "hatchling.build"
```

---

## Publishing

Uses PyPI trusted publishing — no API tokens needed.

### One-time setup

1. Create a PyPI account at pypi.org
2. Go to: Account → Publishing → Add a new pending publisher
3. Fill in: project name `bluefox-test`, GitHub owner/repo, workflow filename `publish.yml`, environment name `pypi`

### Publish workflow

```yaml
# .github/workflows/publish.yml
name: Publish to PyPI
on:
  push:
    tags: ["v*"]

jobs:
  publish:
    runs-on: ubuntu-latest
    environment: pypi
    permissions:
      id-token: write
    steps:
      - uses: actions/checkout@v4
      - uses: actions/setup-python@v5
        with:
          python-version: "3.12"
      - run: pip install build
      - run: python -m build
      - uses: pypa/gh-action-pypi-publish@release/v1
```

### Release process

```bash
# Bump version in pyproject.toml, then:
git tag v0.1.0
git push origin v0.1.0
# GitHub Action builds and publishes automatically
```

---

## Versioning

Semver. Breaking changes to `bluefox_test_setup()`, `bluefox_e2e_setup()`, `BaseFactory`, or `register()` bump the major version.

Apps pin with a compatible range:

```toml
"bluefox-test>=0.1.0,<1.0"
```
