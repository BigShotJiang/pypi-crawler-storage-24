# Testing Setup Guide

How to set up testing in a FastAPI + SQLAlchemy app using `bluefox-test`.

**Prerequisites:** Docker running. That's it.

---

## 1. Install

```toml
# pyproject.toml
[dependency-groups]
test = [
    "bluefox-test>=0.1.0,<1.0",
    "pytest-xdist>=3.5",        # optional: parallel workers
    "playwright>=1.44",          # optional: UI e2e tests
]
```

---

## 2. Pytest Config

```toml
# pyproject.toml
[tool.pytest.ini_options]
testpaths = ["src", "e2e"]
pythonpath = ["src"]
asyncio_mode = "auto"
python_files = ["test_*.py"]
python_functions = ["test_*"]
addopts = ["--strict-markers", "--tb=short", "-q"]
```

Markers (`e2e`, `slow`, `allow_network`) are registered automatically by the plugin.

---

## 3. Root conftest.py

### Single database (most apps)

```python
# conftest.py
from bluefox_test import bluefox_test_setup
from app.models import Base

globals().update(bluefox_test_setup(base=Base))
```

Three lines. You now have: `db`, `engine`, `client`, `app`, and all `create_*` factory fixtures auto-discovered from your domains.

### Multiple databases

```python
globals().update(
    bluefox_test_setup(
        base=Base,
        binds={
            "analytics": "analytics.models.AnalyticsBase",
            "events": "events.models.EventsBase",
        },
    )
)
```

This adds `db_analytics` and `db_events` session fixtures alongside the default `db`.

### Custom app wiring

If your app doesn't use `app.main:create_app` + `app.deps:get_session`:

```python
import pytest_asyncio
from bluefox_test import bluefox_test_setup
from app.models import Base

globals().update(bluefox_test_setup(base=Base, app_factory=None))

# Define your own app and client fixtures:
@pytest_asyncio.fixture
async def app(db):
    from my_app import build_app
    return build_app(session_override=db)

@pytest_asyncio.fixture
async def client(app):
    from httpx import ASGITransport, AsyncClient
    transport = ASGITransport(app=app)
    async with AsyncClient(transport=transport, base_url="http://test") as c:
        yield c
```

The `db`, `engine`, `create_*` fixtures still work. You're only replacing how the app consumes the session.

---

## 4. Directory Structure

```
src/
  users/
    models.py
    service.py
    routes.py
    tests/
      __init__.py
      factories.py       # factories + register() calls
      test_routes.py
      test_service.py
  orders/
    models.py
    tests/
      __init__.py
      factories.py
      test_routes.py
e2e/                     # black-box tests (Section 8)
  conftest.py
  seed.py
  test_auth.py
conftest.py              # root (Section 3)
pyproject.toml
Makefile
docker-compose.yml
```

Every `tests/` directory needs an `__init__.py` for factory discovery and cross-domain SubFactory imports.

---

## 5. Writing Factories

Factories live in `tests/factories.py` within each domain. Define the class, call `register()`, done.

```python
# src/users/tests/factories.py
import factory
from bluefox_test import BaseFactory, register
from users.models import User, UserProfile


class UserFactory(BaseFactory):
    class Meta:
        model = User

    name = factory.Faker("name")
    email = factory.Faker("email")
    is_active = True

create_user = register(UserFactory)


class UserProfileFactory(BaseFactory):
    class Meta:
        model = UserProfile

    user = factory.SubFactory(UserFactory)
    bio = factory.Faker("paragraph")

create_user_profile = register(UserProfileFactory)
```

`create_user` and `create_user_profile` are now available as fixtures in **every** test file. No imports in tests, no conftest per domain.

### Cross-domain relationships

Import factory classes directly — they're module-level:

```python
# src/orders/tests/factories.py
from users.tests.factories import UserFactory

class OrderFactory(BaseFactory):
    class Meta:
        model = Order

    user = factory.SubFactory(UserFactory)
    status = "pending"

create_order = register(OrderFactory)
```

### Cross-bind factories

For models in a non-default database:

```python
create_analytics_event = register(AnalyticsEventFactory, session_fixture="db_analytics")
```

---

## 6. Writing Tests

### Naming convention

```
test_<function_or_endpoint>__<scenario>
```

Double underscore separates the unit from the scenario.

### Rules

- No classes. Functional tests only.
- No docstrings unless the test is complex, documents a regression, or has non-obvious context.
- Never instantiate models directly — use `create_*` factories.
- Never call `.flush()` or `.commit()` unless testing a DB constraint.

### Examples

```python
# src/users/tests/test_routes.py

async def test_get_user__returns_200_with_valid_id(client, create_user):
    user = create_user(name="Hugo")
    response = await client.get(f"/users/{user.id}")
    assert response.status_code == 200
    assert response.json()["name"] == "Hugo"


async def test_get_user__returns_404_when_not_found(client):
    response = await client.get("/users/99999")
    assert response.status_code == 404


async def test_create_user__rejects_duplicate_email(client, create_user):
    """Regression: #1234 — previously returned 500 instead of 409."""
    create_user(email="taken@example.com")
    response = await client.post("/users", json={"email": "taken@example.com", "name": "X"})
    assert response.status_code == 409
```

### When you DO need `.commit()`

Only when testing actual database constraints:

```python
async def test_create_user__enforces_unique_email_at_db_level(db, create_user):
    """Explicit commit: testing the UNIQUE constraint, not app validation."""
    create_user(email="hugo@example.com")
    await db.commit()
    with pytest.raises(IntegrityError):
        create_user(email="hugo@example.com")
        await db.commit()
```

---

## 7. Makefile

```makefile
.PHONY: test test-parallel test-verbose test-domain e2e e2e-up e2e-down

# Unit / integration tests — containers are handled by bluefox-test
test:
	pytest src/ -x --tb=short -q

test-parallel:
	pytest src/ -x --tb=short -q -n auto

test-verbose:
	pytest src/ -x --tb=long -v -s

test-domain:
	pytest src/$(DOMAIN)/tests/ -x -v

# E2E — same docker-compose as dev, isolated via -p e2e
E2E_PROJECT = e2e
E2E_PORT    = 8081
E2E_DB_PORT = 5433

e2e:
	API_PORT=$(E2E_PORT) DB_PORT=$(E2E_DB_PORT) DB_NAME=test_myapp \
		docker compose -p $(E2E_PROJECT) up -d --wait
	DATABASE_URL=postgresql+asyncpg://dev:dev@localhost:$(E2E_DB_PORT)/test_myapp \
		python -m e2e.seed
	E2E_BASE_URL=http://localhost:$(E2E_PORT) \
		pytest e2e/ -x --tb=short -q -m e2e
	docker compose -p $(E2E_PROJECT) down -v

e2e-up:
	API_PORT=$(E2E_PORT) DB_PORT=$(E2E_DB_PORT) DB_NAME=test_myapp \
		docker compose -p $(E2E_PROJECT) up -d --wait

e2e-down:
	docker compose -p $(E2E_PROJECT) down -v
```

### Day-to-day

```bash
make test                      # run everything
make test-domain DOMAIN=users  # one domain
pytest src/users/tests/test_routes.py::test_get_user__returns_200_with_valid_id -v  # one test
make e2e                       # full e2e cycle
```

---

## 8. Black-Box Testing (E2E)

E2E tests have no access to internal code, models, or sessions. They hit the app over HTTP or browser.

### Shared infrastructure

E2E uses the **same** `docker-compose.yml` as dev, isolated via `--project-name`:

```yaml
# docker-compose.yml — used for BOTH dev and e2e
services:
  api:
    build: .
    ports:
      - "${API_PORT:-8000}:8000"
    environment:
      DATABASE_URL: postgresql+asyncpg://dev:dev@db:5432/${DB_NAME:-myapp}
      REDIS_URL: redis://redis:6379/0
    depends_on:
      db: { condition: service_healthy }
      redis: { condition: service_healthy }

  db:
    image: postgres:16-alpine
    environment:
      POSTGRES_USER: dev
      POSTGRES_PASSWORD: dev
      POSTGRES_DB: ${DB_NAME:-myapp}
    ports:
      - "${DB_PORT:-5432}:5432"
    healthcheck:
      test: ["CMD-SHELL", "pg_isready -U dev"]
      interval: 2s
      timeout: 5s
      retries: 5

  redis:
    image: redis:7-alpine
    ports:
      - "${REDIS_PORT:-6379}:6379"
    healthcheck:
      test: ["CMD", "redis-cli", "ping"]
      interval: 2s
      timeout: 5s
      retries: 5
```

- `docker compose up` → dev (port 8000, DB `myapp`)
- `docker compose -p e2e up` → e2e (port 8081, DB `test_myapp`, containers `e2e-*`)

### E2E conftest

```python
# e2e/conftest.py
from bluefox_test.e2e import bluefox_e2e_setup

globals().update(bluefox_e2e_setup(
    login_endpoint="/auth/login",
    login_payload={"email": "e2e@test.com", "password": "testpassword123"},
))
```

This gives you `server`, `auth_token`, `api`, and `api_anon` fixtures.

### Playwright (optional)

If your app has a UI, add Playwright fixtures after the `bluefox_e2e_setup()` call. These are app-specific because auth storage varies (localStorage, cookies, etc.):

```python
# e2e/conftest.py (continued)
import pytest
from pathlib import Path

PLAYWRIGHT_STATE = Path("e2e/.auth/playwright_state.json")


@pytest.fixture(scope="session")
def browser_auth_state(server, auth_token):
    """Save auth state so Playwright tests start logged in."""
    from playwright.sync_api import sync_playwright

    PLAYWRIGHT_STATE.parent.mkdir(exist_ok=True)

    with sync_playwright() as p:
        browser = p.chromium.launch()
        context = browser.new_context()
        page = context.new_page()
        page.goto(f"{server}/login")

        # Adjust to match your app's auth storage:
        page.evaluate(f"""() => {{
            localStorage.setItem('access_token', '{auth_token}');
        }}""")

        context.storage_state(path=str(PLAYWRIGHT_STATE))
        browser.close()

    return str(PLAYWRIGHT_STATE)


@pytest.fixture
def page(server, browser_auth_state):
    """Authenticated Playwright page."""
    from playwright.sync_api import sync_playwright

    with sync_playwright() as p:
        browser = p.chromium.launch()
        context = browser.new_context(storage_state=browser_auth_state)
        pg = context.new_page()
        pg.goto(server)
        yield pg
        browser.close()
```

### E2E test examples

```python
# e2e/test_user_crud.py
import pytest

pytestmark = pytest.mark.e2e


def test_create_user__returns_created_user(api):
    response = api.post("/users", json={"name": "E2E User", "email": "e2e-new@test.com"})
    assert response.status_code == 201
    assert response.json()["name"] == "E2E User"


def test_protected_endpoint__rejects_unauthenticated(api_anon):
    response = api_anon.get("/users/me")
    assert response.status_code == 401
```

### Seed script

Every app needs to seed its own test user (the model and hashing differ per app):

```python
# e2e/seed.py
import asyncio
import os

from sqlalchemy.ext.asyncio import create_async_engine, AsyncSession
from app.models import Base, User
from app.auth import hash_password


async def seed():
    engine = create_async_engine(os.environ["DATABASE_URL"])

    async with engine.begin() as conn:
        await conn.run_sync(Base.metadata.create_all)

    async with AsyncSession(engine) as session:
        user = User(
            name="E2E Test User",
            email="e2e@test.com",
            password_hash=hash_password("testpassword123"),
        )
        session.add(user)
        await session.commit()

    await engine.dispose()

if __name__ == "__main__":
    asyncio.run(seed())
```

Add `e2e/.auth/` to `.gitignore`.

---

## 9. CI

```yaml
# .github/workflows/test.yml
name: Test
on: [push, pull_request]

jobs:
  test:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - uses: actions/setup-python@v5
        with:
          python-version: "3.12"
      - run: pip install -e ".[test]"
      - run: make test

  e2e:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - uses: actions/setup-python@v5
        with:
          python-version: "3.12"
      - run: |
          pip install -e ".[test]"
          playwright install chromium
      - run: make e2e
```

---

## 10. Setup Checklist

### Per app (one-time)

- [ ] Add `bluefox-test` to test dependencies
- [ ] Add pytest config to `pyproject.toml` (Section 2)
- [ ] Create root `conftest.py` with `bluefox_test_setup()` (Section 3)
- [ ] Add `Makefile` (Section 7)
- [ ] Parameterize `docker-compose.yml` for dev/e2e sharing (Section 8)
- [ ] Create `e2e/conftest.py` with `bluefox_e2e_setup()` (Section 8)
- [ ] Create `e2e/seed.py` (Section 8)
- [ ] Add `e2e/.auth/` to `.gitignore`

### Per domain

- [ ] Create `tests/__init__.py`
- [ ] Create `tests/factories.py` — one factory class + one `register()` call per model
- [ ] Create `tests/test_*.py` files

### Verify

```bash
make test                    # all tests pass
pytest --collect-only -q 2>&1 | grep "FACTORY MISSING"  # no missing factories
```

---

## 11. Environment Variable Convention

All database URLs must follow this naming:

- **Main database:** `DATABASE_URL`
- **Named binds:** `<BIND_NAME>_DATABASE_URL` (e.g. `ANALYTICS_DATABASE_URL`)

`bluefox-test` scans for all matching env vars and validates:

1. Host is `localhost`, `127.0.0.1`, `0.0.0.0`, or `db`
2. Database name starts with `test_`

If either check fails, pytest aborts immediately.

---

## 12. What You Get for Free

Things `bluefox-test` handles so you don't have to think about them:

- **Container lifecycle** — Postgres and Redis start before tests, stop after. Random ports avoid conflicts.
- **Session isolation** — every test gets a SAVEPOINT. Rolled back after. No data leaks.
- **`session.commit()` neutralization** — app code can commit freely; the SAVEPOINT restarts automatically. Tests don't need to know about this.
- **Factory auto-flush** — `create_user()` returns an object with a real `.id`. No `.flush()` calls.
- **Factory discovery** — every `tests/factories.py` under `src/` is imported automatically. Every `register()` call creates a global fixture.
- **Safety gates** — impossible to accidentally test against production. Env vars are validated before any engine starts.
- **Factory linting** — warns when models lack factories or tests instantiate models directly.
- **Markers** — `e2e`, `slow`, `allow_network` registered automatically.
- **E2E auth** — authenticate once, cache JWT, inject into every client.

Things that remain app-specific:

- `docker-compose.yml` — your services, build context, volumes
- `e2e/seed.py` — your models and auth hashing
- Playwright auth fixtures — your token storage mechanism
- `Makefile` — 15 lines, just copy from Section 7

---

## 13. Common Pitfalls

**factory_boy session errors** — the `db` fixture must be requested (directly or via a `create_*` fixture). If no test in your file uses a factory, the session isn't bound.

**SubFactory import failures** — `from users.tests.factories import UserFactory` requires `pythonpath = ["src"]` in pyproject.toml and `__init__.py` in every `tests/` directory.

**`globals().update()` not at module level** — must be in the root conftest body, not inside a fixture. pytest needs to see fixtures at import time.

**E2E port conflicts** — the Makefile uses port 8081/5433 for e2e vs 8000/5432 for dev. Both can run simultaneously.

**Docker not running** — testcontainers need Docker. On macOS: Docker Desktop. On CI (GitHub Actions): pre-installed.

**`session.commit()` in app code** — handled automatically by the SAVEPOINT restart. If data leaks between tests, something is bypassing the test session (e.g. creating a second engine).
