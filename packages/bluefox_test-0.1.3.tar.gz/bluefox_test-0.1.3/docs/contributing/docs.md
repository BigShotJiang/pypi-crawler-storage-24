# Documentation guide

How to work with the bluefox-test docs site.

---

## How it works

The docs site is built with [MkDocs Material](https://squidfinity.github.io/mkdocs-material/). It turns Markdown files in `docs/` into a static website. The site auto-deploys to GitHub Pages when you push to `main`.

```bash
# Install docs dependencies
uv sync --group docs

# Preview locally (auto-reloads on save)
mkdocs serve
# Open http://127.0.0.1:8000

# Check for broken links
mkdocs build --strict
```

---

## File structure

```
bluefox-test/
  mkdocs.yml                 # Site config: navigation, theme, extensions
  docs/
    index.md                 # Home page
    getting-started.md       # Adoption guide
    walkthrough.md           # Todo app step-by-step
    reference/
      setup.md               # bluefox_test_setup() API
      e2e.md                 # bluefox_e2e_setup() API
      factories.md           # BaseFactory, register(), re-exports
      safety.md              # Host whitelist, network guard
    guides/
      multiple-databases.md  # Multi-bind setup
      playwright.md          # Browser E2E
      ci.md                  # GitHub Actions
      custom-app-wiring.md   # When conventions don't fit
    contributing/
      docs.md                # This page
      publishing.md          # PyPI release flow
```

---

## Common tasks

### Add a new page

1. Create a `.md` file in the appropriate directory
2. Add it to the `nav` section in `mkdocs.yml`

### Edit an existing page

Edit the `.md` file directly. If running `mkdocs serve`, the browser auto-reloads.

### Remove a page

1. Delete the file
2. Remove the entry from `mkdocs.yml` nav

---

## Formatting reference

### Code blocks

````markdown
```python title="src/users/tests/factories.py"
class UserFactory(BaseFactory):
    class Meta:
        model = User
```
````

Supported languages: `python`, `toml`, `yaml`, `bash`, `sql`, `json`, and more.

### Admonitions

```markdown
!!! note
    Supplementary information.

!!! tip
    Helpful suggestion.

!!! warning
    Something that could go wrong.

!!! danger
    Something that WILL go wrong.
```

### Collapsible admonitions

```markdown
??? note "Click to expand"
    Hidden by default.

???+ note "Expanded by default"
    Visible but can be collapsed.
```

### Tabs

```markdown
=== "Single Database"

    ```python
    globals().update(bluefox_test_setup(base=Base))
    ```

=== "Multiple Databases"

    ```python
    globals().update(bluefox_test_setup(
        base=Base,
        binds={"analytics": "analytics.models:Base"},
    ))
    ```
```

### Links between pages

```markdown
See the [Getting started](../getting-started.md) guide.
See [Factory usage](../reference/factories.md#factory-file-pattern).
```

Anchors are auto-generated from headings: `## My Section` becomes `#my-section`.

---

## Style conventions

- Use code blocks for everything runnable
- Use admonitions sparingly — one or two per page
- Use tabs for alternatives, not for sequential steps
- Link between pages when mentioning API functions
- Keep pages focused — split if past ~300 lines
- Code examples should be copy-pasteable
- Title format: sentence case (`Getting started`, not `Getting Started`)

---

## Deployment

Push to `main` triggers the GitHub Action which runs `mkdocs gh-deploy --force`. The site updates at `https://bluefox-software.github.io/bluefox-test/`.

Manual deploy: `mkdocs gh-deploy --force`
