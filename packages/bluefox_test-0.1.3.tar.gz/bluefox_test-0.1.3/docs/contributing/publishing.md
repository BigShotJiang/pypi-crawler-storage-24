# Publishing to PyPI

How to release new versions of `bluefox-test`.

---

## One-time setup

### 1. Create a PyPI account

Go to [pypi.org/account/register](https://pypi.org/account/register/). Enable 2FA (required for trusted publishing).

### 2. Register the package name

Go to [pypi.org/manage/account/publishing](https://pypi.org/manage/account/publishing/) and add a new pending publisher:

| Field | Value |
|---|---|
| PyPI project name | `bluefox-test` |
| Owner | `bluefox-software` |
| Repository name | `bluefox-test` |
| Workflow name | `publish.yml` |
| Environment name | `pypi` |

### 3. Create the GitHub environment

Repo → Settings → Environments → New environment → name it `pypi`.

### 4. Add the publish workflow

```yaml title=".github/workflows/publish.yml"
name: Publish to PyPI
on:
  push:
    tags: ["v*"]

jobs:
  publish:
    runs-on: ubuntu-latest
    environment: pypi
    permissions:
      id-token: write
    steps:
      - uses: actions/checkout@v4
      - uses: actions/setup-python@v5
        with:
          python-version: "3.12"
      - uses: astral-sh/setup-uv@v5
      - run: uv build
      - uses: pypa/gh-action-pypi-publish@release/v1
```

---

## Releasing a version

### 1. Bump the version

```toml title="pyproject.toml"
[project]
version = "0.2.0"
```

### 2. Commit and push

```bash
git add pyproject.toml
git commit -m "release: v0.2.0"
git push
```

### 3. Tag and push

```bash
git tag v0.2.0
git push origin v0.2.0
```

The GitHub Action triggers on the tag push, builds the package, and publishes to PyPI. Takes about 30 seconds.

### 4. Verify

```bash
uv pip install bluefox-test==0.2.0
```

---

## Version numbering

Use [semver](https://semver.org/): `MAJOR.MINOR.PATCH`

| Change type | Example | When |
|---|---|---|
| PATCH | `0.1.0` → `0.1.1` | Bug fixes, no API changes |
| MINOR | `0.1.1` → `0.2.0` | New features, backwards compatible |
| MAJOR | `0.2.0` → `1.0.0` | Breaking changes to public API |

!!! note
    While pre-1.0, minor versions can include breaking changes. That's normal.

---

## Testing before publishing

```bash
uv build
uv pip install dist/bluefox_test-0.2.0-py3-none-any.whl
python -c "from bluefox_test import BaseFactory; print('works')"
```

---

## Git tags crash course

```bash
git tag v0.1.0              # create tag on current commit
git push origin v0.1.0      # push tag (NOT included in regular git push)
git tag                     # list all tags
git tag -d v0.1.0           # delete local tag
git push origin --delete v0.1.0  # delete remote tag
```

!!! warning "Common mistake"
    `git tag v0.1.0` only creates the tag locally. You must `git push origin v0.1.0` separately.

---

## Checklists

### First release

- [ ] PyPI account created with 2FA
- [ ] Pending publisher registered on pypi.org
- [ ] `pypi` environment created in GitHub repo settings
- [ ] `.github/workflows/publish.yml` committed and pushed
- [ ] All tests pass locally
- [ ] `git tag v0.1.0 && git push origin v0.1.0`
- [ ] GitHub Actions publish workflow succeeded
- [ ] `uv pip install bluefox-test` works

### Subsequent releases

- [ ] Bump version in `pyproject.toml`
- [ ] Commit: `git commit -m "release: vX.Y.Z"`
- [ ] Push: `git push`
- [ ] Tag: `git tag vX.Y.Z && git push origin vX.Y.Z`
- [ ] Verify on PyPI
