"""Async SAVEPOINT session management.

Provides test sessions that wrap every test in a SAVEPOINT transaction,
rolling back all changes after each test for complete isolation.
"""

from __future__ import annotations

from contextlib import asynccontextmanager
from typing import AsyncIterator

from sqlalchemy import event
from sqlalchemy.ext.asyncio import AsyncEngine, AsyncSession, create_async_engine


def create_test_engine(url: str, **kwargs) -> AsyncEngine:
    """Create an async engine suitable for testing."""
    return create_async_engine(url, echo=False, pool_pre_ping=True, **kwargs)


@asynccontextmanager
async def scoped_test_session(engine: AsyncEngine) -> AsyncIterator[AsyncSession]:
    """Yield a SAVEPOINT-wrapped async session.

    The session sits inside a real transaction that is never committed.
    When app code calls session.commit(), an event listener restarts the
    SAVEPOINT so the outer transaction remains intact. On exit, the outer
    transaction is rolled back, erasing all changes.
    """
    conn = await engine.connect()
    trans = await conn.begin()
    await conn.begin_nested()

    session = AsyncSession(bind=conn, expire_on_commit=False)

    @event.listens_for(session.sync_session, "after_transaction_end")
    def restart_savepoint(sync_session, transaction):
        if transaction.nested and not transaction._parent.nested:
            sync_session.begin_nested()

    try:
        yield session
    finally:
        await session.close()
        await trans.rollback()
        await conn.close()
