"""Container lifecycle for test infrastructure.

Starts and stops real Postgres and Redis containers via testcontainers.
"""

from __future__ import annotations

import psycopg2
from psycopg2.extensions import ISOLATION_LEVEL_AUTOCOMMIT
from testcontainers.postgres import PostgresContainer
from testcontainers.redis import RedisContainer


def start_containers(
    postgres_image: str = "postgres:16-alpine",
    redis_image: str = "redis:7-alpine",
) -> tuple[PostgresContainer, RedisContainer, str, str, str]:
    """Start Postgres and Redis containers.

    Returns (pg_container, redis_container, pg_async_url, pg_sync_url, redis_url).
    """
    pg = PostgresContainer(
        image=postgres_image,
        username="test",
        password="test",
        dbname="test_main",
    )
    pg.start()

    redis = RedisContainer(image=redis_image)
    redis.start()

    pg_host = pg.get_container_host_ip()
    pg_port = pg.get_exposed_port(5432)
    pg_async_url = f"postgresql+asyncpg://test:test@{pg_host}:{pg_port}/test_main"
    pg_sync_url = f"postgresql://test:test@{pg_host}:{pg_port}/test_main"

    redis_host = redis.get_container_host_ip()
    redis_port = redis.get_exposed_port(6379)
    redis_url = f"redis://{redis_host}:{redis_port}/0"

    return (pg, redis, pg_async_url, pg_sync_url, redis_url)


def stop_containers(pg_container: PostgresContainer, redis_container: RedisContainer) -> None:
    """Stop Postgres and Redis containers."""
    pg_container.stop()
    redis_container.stop()


def create_bind_databases(
    sync_base_url: str,
    binds: list[str],
) -> dict[str, str]:
    """Create additional test databases for bind keys.

    For each bind name, creates a database named test_{bind_name} inside
    the same Postgres instance. Returns a dict of {bind_name: async_url}.
    """
    from sqlalchemy.engine.url import make_url

    base = make_url(sync_base_url)
    result = {}

    # Connect to the existing database to issue CREATE DATABASE commands
    conn = psycopg2.connect(
        host=base.host,
        port=base.port,
        user=base.username,
        password=base.password,
        dbname=base.database,
    )
    conn.set_isolation_level(ISOLATION_LEVEL_AUTOCOMMIT)
    cur = conn.cursor()

    try:
        for bind_name in binds:
            db_name = f"test_{bind_name}"

            # Check if database exists
            cur.execute(
                "SELECT 1 FROM pg_database WHERE datname = %s", (db_name,)
            )
            if not cur.fetchone():
                cur.execute(f'CREATE DATABASE "{db_name}"')

            async_url = str(
                base.set(database=db_name)
            ).replace("postgresql://", "postgresql+asyncpg://")
            result[bind_name] = async_url
    finally:
        cur.close()
        conn.close()

    return result
