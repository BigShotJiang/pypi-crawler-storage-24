"""Factory infrastructure for test data generation.

Uses plain factory.Factory for attribute declaration only.
All database persistence is handled with native async calls —
no greenlet bridge, no SQLAlchemyModelFactory, no nest_asyncio.
"""

from __future__ import annotations

import importlib
import importlib.util
import inspect
import re
from pathlib import Path
from typing import Any

import factory
import pytest
from factory import (  # noqa: F401
    Faker,
    Iterator,
    LazyAttribute,
    LazyFunction,
    Sequence,
    Trait,
)
from sqlalchemy.ext.asyncio import AsyncSession

# Re-exports for convenience
__all__ = [
    "BaseFactory",
    "register",
    "bind_session",
    "discover_and_collect_fixtures",
    "Faker",
    "LazyFunction",
    "LazyAttribute",
    "Sequence",
    "Iterator",
    "Trait",
]

_fixture_registry: dict[str, Any] = {}

# Module-level reference to the current async session.
_current_session: AsyncSession | None = None


def bind_session(session: AsyncSession | None) -> None:
    """Set the async session for factory operations."""
    global _current_session
    _current_session = session


def get_current_session() -> AsyncSession:
    """Get the current test session, raising if none is bound."""
    if _current_session is None:
        raise RuntimeError(
            "No test session is active. Factories can only be used "
            "inside tests that request the `db` fixture."
        )
    return _current_session


class BaseFactory(factory.Factory):
    """Base factory for all models.

    Uses factory_boy ONLY for attribute declaration and object building.
    All database persistence is async — no greenlet bridge, no sync hacks.

    Usage:
        class UserFactory(BaseFactory):
            class Meta:
                model = User

            name = Faker("name")
            email = Faker("email")

        create_user = register(UserFactory)

    In tests:
        user = await create_user(name="Hugo")
    """

    class Meta:
        abstract = True

    @classmethod
    async def create_async(cls, _session: AsyncSession | None = None, **overrides):
        """Build an instance with factory_boy, then persist via async session.

        This is the ONLY method that touches the database. It uses real
        await calls — no greenlet bridge, no sync_session.

        Args:
            _session: Explicit session override (for cross-bind factories).
                      If None, uses the globally-bound test session.
            **overrides: Field overrides passed to factory_boy's build().

        Returns:
            The persisted model instance with a real database ID.
        """
        session = _session or get_current_session()

        # Handle awaitable overrides (e.g. from another factory's create_async).
        resolved = {}
        for key, value in overrides.items():
            if hasattr(value, "__await__"):
                resolved[key] = await value
            else:
                resolved[key] = value

        # factory_boy builds the object in memory — no DB call.
        instance = cls.build(**resolved)

        # Async persistence — real await, no greenlet bridge.
        session.add(instance)
        await session.flush()

        # Refresh to load server-generated defaults (timestamps, etc.)
        await session.refresh(instance)

        return instance

    @classmethod
    async def create_batch_async(cls, size: int, **overrides) -> list:
        """Create multiple instances."""
        return [await cls.create_async(**overrides) for _ in range(size)]


def _all_subclasses(cls):
    """Recursively collect all subclasses."""
    result = []
    for sub in cls.__subclasses__():
        result.append(sub)
        result.extend(_all_subclasses(sub))
    return result


def _all_factories() -> list[type[BaseFactory]]:
    """Collect all concrete BaseFactory subclasses."""
    return [
        cls
        for cls in _all_subclasses(BaseFactory)
        if hasattr(cls, "_meta")
        and hasattr(cls._meta, "model")
        and cls._meta.model is not None
        and not cls._meta.abstract
    ]


def _model_name_to_fixture_name(model_name: str) -> str:
    """Convert PascalCase model name to create_snake_case fixture name.

    UserProfile -> create_user_profile
    HTTPLog -> create_http_log
    APIKey -> create_api_key
    """
    # Insert underscore between lowercase/digit and uppercase
    s = re.sub(r"([a-z0-9])([A-Z])", r"\1_\2", model_name)
    # Insert underscore between consecutive uppercase letters followed by lowercase
    s = re.sub(r"([A-Z]+)([A-Z][a-z])", r"\1_\2", s)
    return f"create_{s.lower()}"


def register(
    factory_cls: type[BaseFactory],
    session_fixture: str = "db",
) -> Any:
    """Turn a factory into a global pytest fixture.

    The fixture returns an async callable:
        user = await create_user(name="Hugo")
    """
    model_name = factory_cls._meta.model.__name__
    fixture_name = _model_name_to_fixture_name(model_name)

    if session_fixture == "db":

        @pytest.fixture
        def factory_fixture(db):
            async def _create(**overrides):
                return await factory_cls.create_async(**overrides)

            return _create

    else:

        @pytest.fixture
        def factory_fixture(**kwargs):
            session = kwargs[session_fixture]

            async def _create(**overrides):
                return await factory_cls.create_async(_session=session, **overrides)

            return _create

        # Rewrite the signature to use the correct parameter name
        sig = inspect.signature(factory_fixture)
        new_param = inspect.Parameter(
            session_fixture,
            inspect.Parameter.POSITIONAL_OR_KEYWORD,
        )
        factory_fixture.__signature__ = sig.replace(parameters=[new_param])

    factory_fixture.__name__ = fixture_name
    factory_fixture.__qualname__ = fixture_name
    _fixture_registry[fixture_name] = factory_fixture
    return factory_fixture


def discover_and_collect_fixtures(src_root: str = "src") -> dict[str, Any]:
    """Walk src_root for tests/factories.py files, import them, return registry."""
    root = Path(src_root)
    if not root.exists():
        return dict(_fixture_registry)

    for factories_file in root.rglob("tests/factories.py"):
        # Convert path to module name
        # e.g., src/auth/tests/factories.py -> auth.tests.factories
        relative = factories_file.relative_to(root)
        module_parts = list(relative.with_suffix("").parts)
        module_name = ".".join(module_parts)

        try:
            importlib.import_module(module_name)
        except ImportError:
            # If direct import fails, try with the full path
            spec = importlib.util.spec_from_file_location(module_name, factories_file)
            if spec and spec.loader:
                module = importlib.util.module_from_spec(spec)
                spec.loader.exec_module(module)

    return dict(_fixture_registry)
