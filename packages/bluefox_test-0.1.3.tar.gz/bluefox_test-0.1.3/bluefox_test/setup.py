"""Main setup function that wires all test infrastructure together.

bluefox_test_setup() dynamically creates and returns a dict of pytest fixtures
that provide containers, sessions, engines, app, client, and factory fixtures.
"""

from __future__ import annotations

import importlib
from typing import Any

import pytest
import pytest_asyncio

from bluefox_test.containers import (
    create_bind_databases,
    start_containers,
    stop_containers,
)
from bluefox_test.factories import bind_session, discover_and_collect_fixtures
from bluefox_test.safety import override_env_with_containers
from bluefox_test.session import create_test_engine, scoped_test_session


def _import_dotted(path: str):
    """Import an object from a dotted path like 'app.main:create_app'."""
    module_path, attr_name = path.rsplit(":", 1)
    module = importlib.import_module(module_path)
    return getattr(module, attr_name)


def bluefox_test_setup(
    base,
    binds: dict[str, str] | None = None,
    src_root: str = "src",
    postgres_image: str = "postgres:16-alpine",
    redis_image: str = "redis:7-alpine",
    app_factory: str | None = "app.main:create_app",
    session_dependency: str | None = "app.deps:get_session",
) -> dict[str, Any]:
    """Create and return a dict of pytest fixtures for test infrastructure.

    Inject into your conftest via: globals().update(bluefox_test_setup(base=Base))
    """
    fixtures: dict[str, Any] = {}

    # -- infra (session) --
    @pytest.fixture(scope="session")
    def infra():
        pg, redis, async_url, sync_url, redis_url = start_containers(
            postgres_image=postgres_image,
            redis_image=redis_image,
        )
        yield pg, redis, async_url, sync_url, redis_url
        stop_containers(pg, redis)

    fixtures["infra"] = infra

    # -- safe_env (session, autouse) --
    if binds:

        @pytest.fixture(scope="session", autouse=True)
        def safe_env(infra):
            _pg, _redis, async_url, sync_url, redis_url = infra
            bind_urls = create_bind_databases(sync_url, list(binds.keys()))
            override_env_with_containers(async_url, redis_url, bind_urls)
            # Store bind URLs on the fixture for bind_engines to use
            safe_env._bind_urls = bind_urls
            yield

        fixtures["safe_env"] = safe_env
    else:

        @pytest.fixture(scope="session", autouse=True)
        def safe_env(infra):
            _pg, _redis, async_url, _sync_url, redis_url = infra
            override_env_with_containers(async_url, redis_url)
            yield

        fixtures["safe_env"] = safe_env

    # -- engine (session) --
    @pytest_asyncio.fixture(scope="session")
    async def engine(infra):
        _pg, _redis, async_url, _sync_url, _redis_url = infra
        eng = create_test_engine(async_url)
        async with eng.begin() as conn:
            await conn.run_sync(base.metadata.create_all)
        yield eng
        await eng.dispose()

    fixtures["engine"] = engine

    # -- bind_engines (session) --
    if binds:

        @pytest_asyncio.fixture(scope="session")
        async def bind_engines(safe_env):
            engines = {}
            for bind_name, base_path in binds.items():
                bind_base = _import_dotted(base_path)
                bind_url = safe_env._bind_urls[bind_name]
                eng = create_test_engine(bind_url)
                async with eng.begin() as conn:
                    await conn.run_sync(bind_base.metadata.create_all)
                engines[bind_name] = eng
            yield engines
            for eng in engines.values():
                await eng.dispose()

        fixtures["bind_engines"] = bind_engines

        # -- db_<bind> (function) -- one per bind key
        for bind_name in binds:
            # Use default arg to capture bind_name in closure
            def _make_bind_db_fixture(name):
                @pytest_asyncio.fixture
                async def bind_db_fixture(bind_engines):
                    async with scoped_test_session(bind_engines[name]) as session:
                        yield session

                bind_db_fixture.__name__ = f"db_{name}"
                bind_db_fixture.__qualname__ = f"db_{name}"
                return bind_db_fixture

            fixtures[f"db_{bind_name}"] = _make_bind_db_fixture(bind_name)

    # -- db (function) --
    @pytest_asyncio.fixture
    async def db(engine):
        async with scoped_test_session(engine) as session:
            bind_session(session)
            yield session
            bind_session(None)

    fixtures["db"] = db

    # -- app (function) --
    if app_factory is not None:
        create_app_fn = _import_dotted(app_factory)

        if session_dependency is not None:
            session_dep_fn = _import_dotted(session_dependency)

            @pytest.fixture
            def app(db):
                application = create_app_fn()

                async def _override_session():
                    yield db

                application.dependency_overrides[session_dep_fn] = _override_session
                yield application
                application.dependency_overrides.clear()

        else:

            @pytest.fixture
            def app(db):
                application = create_app_fn()
                yield application

        fixtures["app"] = app

        # -- client (function) --
        @pytest_asyncio.fixture
        async def client(app):
            from httpx import ASGITransport, AsyncClient

            transport = ASGITransport(app=app)
            async with AsyncClient(
                transport=transport, base_url="http://testserver"
            ) as ac:
                yield ac

        fixtures["client"] = client

    # -- discover factory fixtures --
    factory_fixtures = discover_and_collect_fixtures(src_root)
    fixtures.update(factory_fixtures)

    return fixtures
