"""Pytest plugin: auto-register markers and factory linting.

Registered as a pytest11 entry point. Provides:
- pytest_configure: registers e2e, slow, allow_network markers
- pytest_collection_modifyitems: warns on missing factories and direct model usage
"""

from __future__ import annotations

import ast
import re
import warnings
from pathlib import Path

from bluefox_test.factories import BaseFactory, _all_subclasses, discover_and_collect_fixtures


def pytest_configure(config):
    """Register custom markers."""
    config.addinivalue_line("markers", "e2e: marks tests as end-to-end")
    config.addinivalue_line("markers", "slow: marks tests as slow-running")
    config.addinivalue_line(
        "markers", "allow_network: allows external network connections"
    )


def pytest_collection_modifyitems(config, items):
    """Lint factories and warn about gaps."""
    # Try to discover the app's Base class
    base_class = None
    try:
        from app.models import Base

        base_class = Base
    except ImportError:
        pass

    # Import all factory modules
    discover_and_collect_fixtures()

    if base_class is not None:
        # Discover all models
        model_names = _discover_models(base_class)
        # Discover all factory-covered models
        factory_model_names = _discover_factory_models()

        # Warn on uncovered models
        for model_name in sorted(model_names.keys()):
            if model_name not in factory_model_names:
                warnings.warn(
                    f"FACTORY MISSING: {model_name} has no factory. "
                    f"Create a factory in tests/factories.py and call register().",
                    stacklevel=1,
                )

    # Check test files for direct model instantiation
    if base_class is not None:
        model_names_set = set(model_names.keys()) if base_class else set()
        seen_files = set()
        for item in items:
            filepath = Path(item.fspath)
            if filepath in seen_files:
                continue
            seen_files.add(filepath)

            violations = _find_direct_model_usage(filepath, model_names_set)
            for violation in violations:
                warnings.warn(violation, stacklevel=1)


def _discover_models(base_class) -> dict[str, type]:
    """Walk base_class.registry.mappers to find all models."""
    models = {}
    for mapper in base_class.registry.mappers:
        cls = mapper.class_
        if hasattr(cls, "__tablename__"):
            models[cls.__name__] = cls
    return models


def _discover_factory_models() -> set[str]:
    """Walk BaseFactory subclasses to find all factory-covered model names."""
    covered = set()
    for factory_cls in _all_subclasses(BaseFactory):
        if (
            hasattr(factory_cls, "_meta")
            and hasattr(factory_cls._meta, "model")
            and factory_cls._meta.model is not None
            and not factory_cls._meta.abstract
        ):
            covered.add(factory_cls._meta.model.__name__)
    return covered


def _find_direct_model_usage(filepath: Path, model_names: set[str]) -> list[str]:
    """AST-parse a test file and find direct Model(...) calls."""
    if not filepath.exists() or not filepath.suffix == ".py":
        return []

    try:
        source = filepath.read_text()
        tree = ast.parse(source)
    except SyntaxError:
        return []

    violations = []
    for node in ast.walk(tree):
        if isinstance(node, ast.Call) and isinstance(node.func, ast.Name):
            if node.func.id in model_names:
                violations.append(
                    f"DIRECT MODEL USAGE: {filepath}:{node.lineno} — "
                    f"{node.func.id}(...) — use create_{_to_snake(node.func.id)}() instead"
                )
    return violations


def _to_snake(name: str) -> str:
    """Convert PascalCase to snake_case."""
    s = re.sub(r"([a-z0-9])([A-Z])", r"\1_\2", name)
    s = re.sub(r"([A-Z]+)([A-Z][a-z])", r"\1_\2", s)
    return s.lower()
