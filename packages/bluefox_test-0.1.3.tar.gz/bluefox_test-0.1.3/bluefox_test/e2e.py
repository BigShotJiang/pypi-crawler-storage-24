"""E2E test setup for black-box testing against a running server.

Provides bluefox_e2e_setup() which returns fixtures for authenticated
and unauthenticated HTTP clients.
"""

from __future__ import annotations

import json
import os
from pathlib import Path
from typing import Any

import pytest


def bluefox_e2e_setup(
    login_endpoint: str = "/auth/login",
    login_payload: dict | None = None,
    token_field: str = "access_token",
    base_url_env: str = "E2E_BASE_URL",
    default_base_url: str = "http://localhost:8081",
    cache_dir: str = "e2e/.auth",
) -> dict[str, Any]:
    """Create and return a dict of pytest fixtures for E2E testing.

    Inject into your e2e conftest via: globals().update(bluefox_e2e_setup(...))
    """
    fixtures: dict[str, Any] = {}

    @pytest.fixture(scope="session")
    def server():
        return os.environ.get(base_url_env, default_base_url)

    fixtures["server"] = server

    @pytest.fixture(scope="session")
    def auth_token(server):
        import httpx

        cache_path = Path(cache_dir) / "token.json"

        # Try to read cached token
        if cache_path.exists():
            data = json.loads(cache_path.read_text())
            return data["token"]

        if login_payload is None:
            pytest.skip("No login_payload provided for E2E auth")

        # Authenticate
        response = httpx.post(
            f"{server}{login_endpoint}",
            json=login_payload,
        )
        response.raise_for_status()
        token = response.json()[token_field]

        # Cache to disk
        cache_path.parent.mkdir(parents=True, exist_ok=True)
        cache_path.write_text(json.dumps({"token": token}))

        return token

    fixtures["auth_token"] = auth_token

    @pytest.fixture
    def api(server, auth_token):
        import httpx

        with httpx.Client(
            base_url=server,
            headers={"Authorization": f"Bearer {auth_token}"},
        ) as client:
            yield client

    fixtures["api"] = api

    @pytest.fixture
    def api_anon(server):
        import httpx

        with httpx.Client(base_url=server) as client:
            yield client

    fixtures["api_anon"] = api_anon

    return fixtures
