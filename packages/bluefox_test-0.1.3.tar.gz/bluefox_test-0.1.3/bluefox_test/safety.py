"""Safety gates for test environments.

Prevents tests from running against production databases by enforcing
host whitelists and test_ database name prefixes.
"""

from __future__ import annotations

import os
import socket

import pytest
from sqlalchemy.engine.url import make_url

ALLOWED_HOSTS = {"localhost", "127.0.0.1", "0.0.0.0", "db"}
TEST_DB_PREFIX = "test_"

_ALLOWED_IP_PREFIXES = (
    "127.",
    "0.0.0.0",
    "192.168.",
    "10.",
    "::",
)

_ALLOWED_IP_172_RANGE = range(16, 32)


def find_all_database_url_vars() -> list[str]:
    """Scan os.environ for keys matching DATABASE_URL or *_DATABASE_URL."""
    matches = []
    for key in os.environ:
        if key == "DATABASE_URL" or key.endswith("_DATABASE_URL"):
            matches.append(key)
    return sorted(matches)


def assert_safe_url(env_var: str) -> list[str]:
    """Check that a database URL env var points to a safe test database.

    Returns a list of violation strings (empty means safe).
    """
    value = os.environ.get(env_var, "")
    if not value:
        return []

    violations = []
    url = make_url(value)

    if url.host and url.host not in ALLOWED_HOSTS:
        violations.append(
            f"{env_var}: host '{url.host}' is not in allowed hosts {ALLOWED_HOSTS}"
        )

    if url.database and not url.database.startswith(TEST_DB_PREFIX):
        violations.append(
            f"{env_var}: database '{url.database}' does not start with '{TEST_DB_PREFIX}'"
        )

    return violations


def enforce_safety() -> None:
    """Check all DATABASE_URL vars and abort pytest if any are unsafe."""
    db_vars = find_all_database_url_vars()
    all_violations = []
    for var in db_vars:
        all_violations.extend(assert_safe_url(var))

    if all_violations:
        msg = "SAFETY CHECK FAILED — refusing to run tests:\n"
        for v in all_violations:
            msg += f"  - {v}\n"
        pytest.exit(msg, returncode=1)


def override_env_with_containers(
    async_url: str,
    redis_url: str,
    bind_urls: dict[str, str] | None = None,
) -> None:
    """Write container URLs into env vars and run safety checks."""
    os.environ["DATABASE_URL"] = async_url
    os.environ["REDIS_URL"] = redis_url

    if bind_urls:
        for bind_name, url in bind_urls.items():
            os.environ[f"{bind_name.upper()}_DATABASE_URL"] = url

    enforce_safety()


def _is_allowed_ip(host: str) -> bool:
    """Check if a host/IP is local or private."""
    if host == "localhost":
        return True

    for prefix in _ALLOWED_IP_PREFIXES:
        if host.startswith(prefix):
            return True

    # Check 172.16.0.0/12 range
    if host.startswith("172."):
        parts = host.split(".")
        if len(parts) >= 2:
            try:
                second_octet = int(parts[1])
                if second_octet in _ALLOWED_IP_172_RANGE:
                    return True
            except ValueError:
                pass

    return False


def install_network_guard(monkeypatch: pytest.MonkeyPatch) -> None:
    """Monkeypatch socket.connect to reject non-local connections."""
    original_connect = socket.socket.connect

    def guarded_connect(self, address):
        if isinstance(address, tuple) and len(address) >= 2:
            host = str(address[0])
            if not _is_allowed_ip(host):
                pytest.fail(
                    f"Network guard: blocked connection to {host}. "
                    "Use @pytest.mark.allow_network to permit external connections."
                )
        return original_connect(self, address)

    monkeypatch.setattr(socket.socket, "connect", guarded_connect)
