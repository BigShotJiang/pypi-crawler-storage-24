"""
QTI Base Types

Common types shared across QTI resources.
"""

from typing import Literal

AssessmentItemType = Literal[
    "choice",
    "text-entry",
    "extended-text",
    "inline-choice",
    "match",
    "order",
    "associate",
    "select-point",
    "graphic-order",
    "graphic-associate",
    "graphic-gap-match",
    "hotspot",
    "hottext",
    "slider",
    "drawing",
    "media",
    "upload",
]

Cardinality = Literal["single", "multiple", "ordered", "record"]

BaseType = Literal[
    "identifier",
    "boolean",
    "integer",
    "float",
    "string",
    "point",
    "pair",
    "directedPair",
    "duration",
    "file",
    "uri",
]

Difficulty = Literal["easy", "medium", "hard"]

Grade = Literal[-1, 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13]

NavigationMode = Literal["linear", "nonlinear"]

SubmissionMode = Literal["individual", "simultaneous"]

ShowHide = Literal["show", "hide"]

ValidationSchema = Literal["test", "item", "stimulus"]

SortOrder = Literal["asc", "desc"]

FeedbackType = Literal["QUESTION", "LESSON"]


__all__ = [
    "AssessmentItemType",
    "BaseType",
    "Cardinality",
    "Difficulty",
    "FeedbackType",
    "Grade",
    "NavigationMode",
    "ShowHide",
    "SortOrder",
    "SubmissionMode",
    "ValidationSchema",
]
