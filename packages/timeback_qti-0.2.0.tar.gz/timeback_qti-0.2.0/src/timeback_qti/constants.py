"""
QTI Constants

Configuration constants for the QTI client.
"""

SERVICE_NAME = "qti"
