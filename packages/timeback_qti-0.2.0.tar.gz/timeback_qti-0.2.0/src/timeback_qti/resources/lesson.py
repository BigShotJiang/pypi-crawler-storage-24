"""
Lesson Resource

Lesson and question feedback endpoints.
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Any
from urllib.parse import quote

from timeback_common import serialize_input, validate_non_empty_string, validate_with_schema

from ..types.inputs import SubmitLessonFeedbackInput
from ..types.responses import LessonFeedback

if TYPE_CHECKING:
    from ..lib.transport import Transport


class LessonResource:
    """Lesson resource for managing lesson and question feedback."""

    def __init__(self, transport: Transport) -> None:
        self._transport = transport

    async def submit_lesson(
        self, body: SubmitLessonFeedbackInput | dict[str, Any]
    ) -> LessonFeedback:
        """Submit lesson feedback."""
        validate_with_schema(SubmitLessonFeedbackInput, body, "lesson feedback")
        result = await self._transport.post(
            f"{self._transport.paths.base}/lesson",
            serialize_input(body, SubmitLessonFeedbackInput),
        )
        return LessonFeedback.model_validate(result)

    async def get_lesson(self, lesson_id: str) -> LessonFeedback:
        """Get lesson feedback by lesson ID."""
        validate_non_empty_string(lesson_id, "lessonId")
        body = await self._transport.get(
            f"{self._transport.paths.base}/lesson/{quote(lesson_id, safe='')}"
        )
        return LessonFeedback.model_validate(body)

    async def submit_question(
        self, body: SubmitLessonFeedbackInput | dict[str, Any]
    ) -> LessonFeedback:
        """Submit question feedback."""
        validate_with_schema(SubmitLessonFeedbackInput, body, "question feedback")
        result = await self._transport.post(
            f"{self._transport.paths.base}/question",
            serialize_input(body, SubmitLessonFeedbackInput),
        )
        return LessonFeedback.model_validate(result)
