"""
General Resource

General QTI endpoints that don't fit into other resources.
"""

from __future__ import annotations

from typing import TYPE_CHECKING
from urllib.parse import quote

from timeback_common import validate_non_empty_string

from ..types.responses import DeleteResponse

if TYPE_CHECKING:
    from ..lib.transport import Transport


class GeneralResource:
    """General resource for miscellaneous QTI operations."""

    def __init__(self, transport: Transport) -> None:
        self._transport = transport

    async def delete_by_id(self, entity_id: str) -> DeleteResponse:
        """
        Delete any entity by its ID.

        This is a general delete endpoint that can remove any QTI entity.
        """
        validate_non_empty_string(entity_id, "id")
        body = await self._transport.delete(
            f"{self._transport.paths.base}/{quote(entity_id, safe='')}"
        )
        if body is None:
            return DeleteResponse()
        return DeleteResponse.model_validate(body)
