"""Biblibit -- Three-layer persistent memory for AI agents."""

from __future__ import annotations

from importlib.metadata import PackageNotFoundError, version
from pathlib import Path
import tomllib


def _load_version() -> str:
    """Read the package version from installed metadata or pyproject fallback."""
    try:
        return version("biblibit")
    except PackageNotFoundError:
        pyproject = Path(__file__).resolve().parents[2] / "pyproject.toml"
        with pyproject.open("rb") as fh:
            data = tomllib.load(fh)
        return data["project"]["version"]


__version__ = _load_version()
