#!/usr/bin/env bash
# setup-remote.sh -- Configure a remote Cursor instance to use biblibit over the network.
#
# Run this on any machine to point its Cursor at your biblibit server.
#
# Usage:
#   bash setup-remote.sh your-server                   # connect to your-server:8788
#   bash setup-remote.sh your-server 9000              # custom host and port

set -euo pipefail

BIBLIBIT_HOST="${1:?Usage: bash setup-remote.sh <hostname> [port]}"
BIBLIBIT_PORT="${2:-8788}"
BIBLIBIT_URL="http://${BIBLIBIT_HOST}:${BIBLIBIT_PORT}/sse"
MCP_CONFIG="$HOME/.cursor/mcp.json"

echo "=== Biblibit Remote Setup ==="
echo "Server: ${BIBLIBIT_URL}"
echo "Config: ${MCP_CONFIG}"
echo ""

mkdir -p "$(dirname "$MCP_CONFIG")"

if [ -f "$MCP_CONFIG" ]; then
    # Check if jq is available for safe merging
    if command -v jq &> /dev/null; then
        # Merge biblibit into existing config
        TEMP=$(mktemp)
        jq --arg url "$BIBLIBIT_URL" \
           '.mcpServers.biblibit = { "url": $url }' \
           "$MCP_CONFIG" > "$TEMP"
        mv "$TEMP" "$MCP_CONFIG"
        echo "Merged biblibit into existing mcp.json"
    else
        echo "WARNING: jq not installed. Cannot safely merge into existing mcp.json."
        echo ""
        echo "Add this manually to $MCP_CONFIG under mcpServers:"
        echo ""
        echo "  \"biblibit\": {"
        echo "    \"url\": \"${BIBLIBIT_URL}\""
        echo "  }"
        echo ""
        exit 1
    fi
else
    # Create new config
    cat > "$MCP_CONFIG" << MCPEOF
{
  "mcpServers": {
    "biblibit": {
      "url": "${BIBLIBIT_URL}"
    }
  }
}
MCPEOF
    echo "Created new mcp.json"
fi

echo ""
echo "Done! Restart Cursor to connect to biblibit on ${BIBLIBIT_HOST}."
echo ""
echo "Test the connection:"
echo "  curl -s http://${BIBLIBIT_HOST}:${BIBLIBIT_PORT}/sse"
echo ""
