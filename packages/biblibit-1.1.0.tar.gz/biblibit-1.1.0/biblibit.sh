#!/usr/bin/env bash
# Biblibit launcher -- used by remote Cursor instances over SSH.
# Sources env, activates venv, runs the MCP server over stdio.

set -euo pipefail

BIBLIBIT_DIR="$(cd "$(dirname "$0")" && pwd)"

# Load API key and project config if present
[ -f "$BIBLIBIT_DIR/.env" ] && set -a && source "$BIBLIBIT_DIR/.env" && set +a

export PYTHONPATH="$BIBLIBIT_DIR/src"
exec "$BIBLIBIT_DIR/.venv/bin/python" -m biblibit
