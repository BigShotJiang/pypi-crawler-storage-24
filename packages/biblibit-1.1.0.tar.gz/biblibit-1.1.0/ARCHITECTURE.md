# Biblibit Orchestrator Architecture

> Vendor-neutral memory and coordination substrate for multi-agent AI systems.
> Not another crew framework -- the **memory plane** that any orchestrator builds on.

**Version:** 2.0 (March 2026)
**Status:** Plan -- not yet implemented
**Target scale:** 3 Cursor instances, 5 agents each (15 concurrent agents)
**Tracking:** Future work now lives in `FUTURE_PLAN.md` and memory namespace `biblibit-future`

---

## What Biblibit is

A persistent memory and coordination backbone exposed as an MCP server. Specialized agents (coding, research, review, browser, terminal) collaborate through shared state in Biblibit rather than through direct messaging or brittle controller logic.

Biblibit provides:

- **Durable cross-agent memory** that survives sessions, reboots, and runtime changes
- **Fast ephemeral state** for in-flight coordination (Redis working memory)
- **Scoped collaboration** so agents share what's relevant without hallucination soup
- **Provenance and truth maintenance** so every stored fact is traceable
- **Task coordination** so agents across Cursor instances don't duplicate work
- **Vendor neutrality** via MCP -- works with any agent framework or LLM provider

## What Biblibit is NOT

- **Not an agent runtime.** Biblibit doesn't spawn, schedule, or execute agents. Cursor, Claude, CrewAI, or custom code does that. Biblibit is the shared state those agents coordinate through.
- **Not a message bus.** Pub/sub is a notification mechanism ("something changed"), not a reliable message queue. Tasks and artifacts are the durable coordination layer.
- **Not A2A.** A2A handles agent discovery and transport. Biblibit handles shared state. They're complementary -- A2A integration is a future layer (see Protocol Layering below).

---

## Research basis

This architecture draws from:

- **Governed Memory** (arXiv 2603.17787, March 2026) -- scoped memory tiers, provenance tracking, zero cross-entity leakage, 99.6% fact recall in production
- **CA-MCP** (arXiv 2601.11595, January 2026) -- shared context stores between MCP servers, validated efficiency gains in multi-agent workflows
- **AOrchestra** (2026) -- dynamic on-demand subagent creation defined by (instruction, context, tools, model) tuples
- **MemGPT/Letta** -- tiered memory model (core/recall/archival) mapping to Redis/working/Postgres tiers
- **Microsoft multi-agent reference architecture** -- orchestrator, supervisor, registry, memory, and MCP integration
- **CrewAI memory system** -- shared crew memory plus private agent scopes
- **memX** (github.com/MehulG/memX) -- Redis + pub/sub pattern for real-time agent coordination (pattern absorbed natively)
- **Mem0** -- shared memory as the missing layer in multi-agent systems (blog, 2026)

Industry context: Gartner reported a 1,445% surge in multi-agent inquiries from early 2024 to mid-2025, but 79% of failures stem from coordination and memory issues, not technical bugs.

---

## Protocol layering

Biblibit sits at the state layer. Other protocols handle transport and discovery:

```
A2A (Agent-to-Agent)                ← "How do agents find each other
Discovery, negotiation, transport      across runtimes and vendors?"
                                       FUTURE: Biblibit publishes an A2A
                                       Agent Card for external discovery.
────────────────────────────────────
MCP (Model Context Protocol)        ← "How do agents use tools
Tools, resources, prompts              and shared services?"
                                       NOW: Biblibit is an MCP server.
────────────────────────────────────
Biblibit                            ← "What do agents remember,
Memory, tasks, artifacts, scoping      coordinate around, and prove?"
                                       NOW: Postgres + Redis.
```

A2A integration is a thin future layer: Biblibit publishes an Agent Card describing its MCP capabilities. Agents from any runtime discover Biblibit via A2A and connect via MCP. No code changes in Biblibit needed -- MCP is already the interface. The hard part is having the right primitives (tasks, artifacts, scoped memory), which is what this plan builds.

---

## Current state (v1.1.0)

```
src/biblibit/
├── server.py      # 10 MCP tools (store, recall, connect, list, correct, forget, status, feedback, consolidate)
├── db.py          # Postgres CRUD (memories, chunks, relationships, project_meta)
├── search.py      # BM25 + pgvector + graph hybrid search
├── embeddings.py  # OpenAI / Ollama / Null providers
├── types.py       # Memory, Chunk, Relationship, SearchResult models
├── pool.py        # Async Postgres connection pool
├── chunker.py     # Text chunking + dedup
├── migrate.py     # SQL migration runner
├── errors.py      # BiblibitError hierarchy
└── util.py        # Project name normalization
```

One tier (Postgres), one concern (memory), no coordination primitives.

---

## Target architecture

```
                    ┌─────────────────────────────────┐
                    │         MCP Clients              │
                    │  3 Cursor instances x 5 agents   │
                    │  (Brain / Developer / Reviewer)  │
                    └──────────────┬──────────────────┘
                                   │ MCP (SSE)
                    ┌──────────────▼──────────────────┐
                    │      Biblibit MCP Server         │
                    │                                  │
                    │  ┌────────────────────────────┐  │
                    │  │      Memory Plane           │  │
                    │  │  Working Memory (Redis)     │  │
                    │  │  Long-Term Memory (Postgres) │  │
                    │  │  Knowledge Graph (Postgres)  │  │
                    │  └────────────────────────────┘  │
                    │                                  │
                    │  ┌────────────────────────────┐  │
                    │  │   Coordination Plane        │  │
                    │  │  Task Lifecycle (Postgres)  │  │
                    │  │  Artifacts (Postgres)       │  │
                    │  │  Status Cache (Redis)       │  │
                    │  └────────────────────────────┘  │
                    │                                  │
                    │  ┌────────────────────────────┐  │
                    │  │      Provenance             │  │
                    │  │  Write Attribution          │  │
                    │  │  Visibility Scoping         │  │
                    │  │  Confidence + Evidence      │  │
                    │  └────────────────────────────┘  │
                    └──────────┬──────────┬───────────┘
                               │          │
                    ┌──────────▼──┐  ┌────▼──────────┐
                    │   Postgres   │  │    Redis       │
                    │  + pgvector  │  │  7-alpine      │
                    └─────────────┘  └───────────────┘
```

---

## Design principles

1. **Memory plane, not the whole plane.** Biblibit coordinates through shared state, not by running agents. Agents are spawned by whatever orchestrator exists (Cursor, CrewAI, Claude, custom). Biblibit provides the substrate they coordinate through.

2. **Postgres for truth, Redis for speed.** Durable state (memories, tasks, artifacts) lives in Postgres. Ephemeral state (working memory, status cache) lives in Redis. Writes go to Postgres first (source of truth), then mirror to Redis for fast reads.

3. **Scoped, not global.** Three visibility tiers: global (all agents in project), task-scoped (agents on the same task), agent-private (scratchpad). Prevents hallucination soup.

4. **Provenance on every write.** Every memory and artifact records who wrote it, why, with what evidence and confidence. Traceable decisions, not anonymous append-only notes.

5. **Claim semantics, not assignment.** Tasks use `SELECT FOR UPDATE SKIP LOCKED` so multiple agents competing for the same task don't race or duplicate work. Exactly one wins; the rest move on.

6. **Strictly additive.** New tables, new MCP tools, new optional dependencies. Nothing in the `1.1.x` runtime breaks. Existing `memory_store`/`memory_recall` work exactly as before.

7. **Redis is optional.** If `REDIS_URL` is not set, working memory falls back to in-process dict and status caching is disabled. Biblibit still works as a pure memory server.

---

## Implementation plan

One migration. Three new files. Eight new MCP tools. ~3 days.

### Migration 002: orchestration tables + scoped memory

```sql
-- Tasks: units of work coordinated across Cursor instances.
-- Agents claim tasks via SKIP LOCKED to prevent races.
CREATE TABLE tasks (
    task_id TEXT PRIMARY KEY,
    parent_task_id TEXT REFERENCES tasks(task_id),
    title TEXT NOT NULL,
    description TEXT,
    status TEXT NOT NULL DEFAULT 'pending',
    priority INTEGER NOT NULL DEFAULT 2
        CHECK (priority >= 0 AND priority <= 4),
    claimed_by TEXT,
    context_memory_ids JSONB DEFAULT '[]',
    result TEXT,
    project TEXT NOT NULL,
    created_at TIMESTAMPTZ NOT NULL,
    updated_at TIMESTAMPTZ NOT NULL
);

CREATE INDEX idx_tasks_project_status ON tasks (project, status);
CREATE INDEX idx_tasks_project_claimed ON tasks (project, claimed_by);

-- Artifacts: agent outputs with provenance.
-- Every artifact records who wrote it, confidence, and evidence.
CREATE TABLE artifacts (
    artifact_id TEXT PRIMARY KEY,
    task_id TEXT NOT NULL REFERENCES tasks(task_id) ON DELETE CASCADE,
    author TEXT NOT NULL,
    content TEXT NOT NULL,
    artifact_type TEXT NOT NULL,
    confidence REAL DEFAULT 1.0
        CHECK (confidence >= 0.0 AND confidence <= 1.0),
    status TEXT NOT NULL DEFAULT 'draft',
    evidence JSONB DEFAULT '[]',
    project TEXT NOT NULL,
    created_at TIMESTAMPTZ NOT NULL
);

CREATE INDEX idx_artifacts_task ON artifacts (task_id);
CREATE INDEX idx_artifacts_project ON artifacts (project, created_at DESC);

-- Scoped memory: add visibility and provenance to existing memories table.
-- Defaults preserve backward compatibility (all existing memories stay global).
ALTER TABLE memories ADD COLUMN scope TEXT NOT NULL DEFAULT 'global';
ALTER TABLE memories ADD COLUMN scope_ref TEXT;
ALTER TABLE memories ADD COLUMN author TEXT;
ALTER TABLE memories ADD COLUMN confidence REAL DEFAULT 1.0;
```

### New files

| File | Purpose | Lines (est.) |
|------|---------|-------------|
| `src/biblibit/tasks.py` | Task + artifact CRUD, SKIP LOCKED claiming | ~250 |
| `src/biblibit/redis_pool.py` | Redis connection, working memory, fallback dict | ~120 |
| `migrations/002_orchestration.sql` | Schema above | ~40 |

### New MCP tools (8)

| Tool | Backend | Description |
|------|---------|-------------|
| `task_create(title, description, priority, context_memory_ids, project)` | Postgres + Redis cache | Create a task, mirror status to Redis |
| `task_claim(task_id, claimed_by, project)` | Postgres (SKIP LOCKED) | Claim task atomically, update Redis cache |
| `task_complete(task_id, result, project)` | Postgres + Redis | Mark done with summary |
| `task_fail(task_id, reason, project)` | Postgres + Redis | Mark failed with reason |
| `task_list(project, status?)` | Redis first, Postgres fallback | List tasks with filters |
| `artifact_store(task_id, author, content, type, confidence, evidence, project)` | Postgres | Store output with provenance |
| `working_memory_set(key, value, ttl_seconds, project)` | Redis (dict fallback) | Fast ephemeral state with auto-expiry |
| `working_memory_get(key, project)` | Redis (dict fallback) | Read ephemeral state |

### Changes to existing tools (backward compatible)

- `memory_store` gains optional: `scope`, `scope_ref`, `author`, `confidence`
- `memory_recall` gains optional: `scope`, `scope_ref` (filters by visibility)
- Defaults match current behavior -- nothing breaks

### Task claiming: the key reliability piece

When multiple agents across Cursor instances try to claim work simultaneously:

```sql
UPDATE tasks SET claimed_by = $1, status = 'claimed', updated_at = NOW()
WHERE task_id = (
    SELECT task_id FROM tasks
    WHERE project = $2 AND status = 'pending'
    ORDER BY priority DESC, created_at ASC
    LIMIT 1
    FOR UPDATE SKIP LOCKED
)
RETURNING *;
```

`FOR UPDATE SKIP LOCKED` is the Postgres pattern used by every serious job queue. If 5 agents try to claim the same task, exactly one wins. The other 4 silently skip to the next available task. No races, no duplicates, no retries.

---

## Postgres and Redis: how they work together

```
Write path (task_create):
  1. INSERT into Postgres tasks table (durable truth)
  2. SET Redis key biblibit:{project}:task:{id}:status = "pending" (fast cache)

Read path (task_list):
  1. Check Redis for cached status (0.1ms)
  2. If miss or Redis down, query Postgres (5ms)

Write path (memory_store with scope):
  1. INSERT into Postgres memories table with scope column (durable)
  2. If scope = 'task', SET Redis working memory key (ephemeral context)

Read path (working_memory_get):
  1. GET Redis key (0.1ms, auto-expires via TTL)
  2. If Redis down, fall back to in-process dict
```

Postgres is always the source of truth. Redis is a speed layer that can disappear without data loss. If Redis crashes, Biblibit degrades to Postgres-only (5ms instead of 0.1ms). No data lost, no tasks orphaned.

---

## Docker stack

```yaml
services:
  db:
    image: pgvector/pgvector:pg16
    environment:
      POSTGRES_USER: biblibit
      POSTGRES_PASSWORD: biblibit
      POSTGRES_DB: biblibit
    ports:
      - "5432:5432"
    volumes:
      - biblibit_pgdata:/var/lib/postgresql/data
    healthcheck:
      test: ["CMD-SHELL", "pg_isready -U biblibit -d biblibit"]
      interval: 5s
      timeout: 5s
      retries: 5

  redis:
    image: redis:7-alpine
    ports:
      - "6379:6379"
    healthcheck:
      test: ["CMD", "redis-cli", "ping"]
      interval: 5s
      timeout: 3s
      retries: 5

  biblibit:
    build: .
    depends_on:
      db:
        condition: service_healthy
      redis:
        condition: service_healthy
    environment:
      DATABASE_URL: postgresql://biblibit:biblibit@db:5432/biblibit
      REDIS_URL: redis://redis:6379/0
      BIBLIBIT_EMBEDDER: ${BIBLIBIT_EMBEDDER:-none}
      OPENAI_API_KEY: ${OPENAI_API_KEY:-}
      OLLAMA_URL: ${OLLAMA_URL:-}
      BIBLIBIT_API_KEY: ${BIBLIBIT_API_KEY:-}
    ports:
      - "8788:8788"

volumes:
  biblibit_pgdata:
```

---

## Environment variables

| Variable | Default | Purpose |
|----------|---------|---------|
| `DATABASE_URL` | `postgresql://biblibit:biblibit@localhost:5432/biblibit` | Postgres connection |
| `REDIS_URL` | unset (falls back to in-process dict) | Redis connection |
| `BIBLIBIT_EMBEDDER` | auto-detect | Embedding provider (openai/ollama/none) |
| `BIBLIBIT_POOL_MAX` | 20 | Max Postgres connections (sufficient for 15 agents) |
| `BIBLIBIT_API_KEY` | unset | Optional API key for SSE auth |

---

## Stress profile: 3 Cursors x 5 agents

| Bottleneck | Impact at 15 agents | Mitigation |
|-----------|---------------------|-----------|
| Postgres pool (20 slots) | 15 agents < 20 slots. Headroom. | No action needed |
| Embedding generation | 15 concurrent stores: ~750ms via Ollama, instant via OpenAI | Acceptable at this scale |
| HNSW vector search | 15 concurrent queries at ~5ms each | Trivial load |
| Task claim races | SKIP LOCKED handles it atomically | Solved by design |
| Redis | 15 agents is trivial for Redis (handles 100K+ ops/sec) | No action needed |
| Auto-connect on store | 15 stores x 5 connections = 75 relationship writes | Acceptable |

---

## File structure after implementation

```
src/biblibit/
├── server.py          # MCP tool surface (existing 10 + new 8 = 18 tools)
├── db.py              # Postgres CRUD for memories (existing, unchanged)
├── search.py          # Hybrid search (existing, gains scope filtering)
├── embeddings.py      # Embedding providers (existing, unchanged)
├── types.py           # Pydantic models (existing + Task, Artifact)
├── pool.py            # Postgres pool (existing, unchanged)
├── chunker.py         # Text chunking (existing, unchanged)
├── migrate.py         # Migration runner (existing, unchanged)
├── errors.py          # Exceptions (existing, unchanged)
├── util.py            # Helpers (existing, unchanged)
├── tasks.py           # NEW: Task + artifact CRUD, SKIP LOCKED claiming
└── redis_pool.py      # NEW: Redis connection, working memory, fallback
```

---

## Future layers (not in this build)

These layers snap onto the foundation without changing it. Build when needed:

| Layer | When to add | What it does |
|-------|-------------|-------------|
| Agent registry + heartbeats | When agents are long-running daemons, not ephemeral Cursor subagents | Track who's alive, auto-expire dead agents |
| Pub/sub notifications | When agents persist long enough to subscribe to events | Real-time "task completed" notifications via Redis channels |
| A2A Agent Card | When non-Cursor agents need to discover Biblibit | JSON metadata for A2A protocol discovery |
| FAISS GPU hot index | When pgvector ~5ms queries are too slow | Sub-ms recall via GPU VRAM (1.3M embeddings in 8GB) |
| Lease expiry management | When agents span unreliable runtimes and need crash recovery | Time-limited task claims with automatic release |

Each future layer requires zero changes to the foundation built here.

---

## The "good version" vs "bad version"

### What makes this good

- Postgres for truth, Redis for speed -- each doing what it's best at
- Scoped memory: global, task, and agent-private
- Typed task state with SKIP LOCKED so agents don't duplicate work
- Provenance on every write: who wrote it, why, evidence, confidence
- Reviewer/evaluator agent can reject or promote outputs via artifact status
- Correction path for bad memories via existing `memory_correct` tool
- Redis optional -- graceful degradation to Postgres-only
- Backward compatible -- all existing MCP tools unchanged

### What would make it bad (and we avoid)

- One giant shared memory with no scoping
- All agents can write anything with no attribution
- No task ownership or duplicate prevention
- No provenance or evidence tracking
- No review gate on outputs
- Redis as a hard dependency that breaks everything when down

---

## Competitive position

| System | Memory | Graph | Multi-agent | MCP | Orchestration | Scoping | Provenance |
|--------|--------|-------|-------------|-----|---------------|---------|------------|
| Mem0 | Strong | Optional | Weak | No | No | No | No |
| Letta/MemGPT | Strong | No | Weak | No | No | Tiered | No |
| CrewAI | Weak | No | Yes | Partial | Yes | Shared+Private | No |
| AutoGen | Weak | No | Yes | No | Yes | No | No |
| **Biblibit (v1.1.0)** | Strong | Yes | Partial | Yes | No | Project-scoped | No |
| **Biblibit (planned)** | Strong | Yes | Yes | Yes | Yes | 3-tier | Yes |

Nobody has all columns filled. Biblibit would be the first open-source system that combines production memory, knowledge graph, task coordination, and provenance through MCP.

---

## Architects Playbook integration (cherry-pick options)

The Architects Playbook (v2.4) is an existing 3-agent orchestration system for Cursor IDE.
It provides the workflow layer. Biblibit provides the state layer. Together they fill every
column in the table above. The agent names will be updated to industry-standard terminology:

- **Brain** -> **Planner** (more precise, matches industry terminology)
- **Developer** -> **Implementer** (avoids confusion with the human developer)
- **Reviewer** stays **Reviewer**

### KEEP -- validated by research, carry forward

| # | Component | Why it's good |
|---|-----------|---------------|
| 1 | Planner/Implementer/Reviewer 3-agent pattern | Industry standard. Research confirms >5 agents = complexity explosion |
| 2 | Cross-model adversarial validation | Different LLMs per role catches blind spots. Production post-mortems confirm |
| 3 | Mandatory review gate (VERIFIED/FAILED) | Verification gaps = 21% of production failures |
| 4 | ROADMAP-first planning | Structured plan before code. Universal best practice |
| 5 | Token efficiency rules | Prevents $4K-in-40-min chatty loops |
| 6 | Code-that-explains-itself standard | Documentation quality across all agents |
| 7 | Model profiles 1-9 | Cost/quality toggle. Unique feature, nobody else has this |
| 8 | Voice commands (Team/Developer/Worker please) | Unique UX. Nobody else does this |
| 9 | /go command with profile selection | Clean entry point for orchestration |
| 10 | Mode discipline (Plan vs Agent) | Prevents premature execution |
| 11 | Self-improvement rules | Agents suggest new rules when patterns emerge |

### DROP -- not needed or replaced by Biblibit

| # | Component | Why |
|---|-----------|-----|
| 1 | Cursor-specific Task tool delegation | Biblibit task_create/task_claim replaces this |
| 2 | Context passed via prompt text only | Replaced by scoped memory + working memory |
| 3 | Hardcoded health check endpoints in reviewer | Project-specific, not generic |
| 4 | `/bro` command (deprecated in v2.2) | Already replaced by `/go` |

### EVOLVE -- keep the concept, wire it through Biblibit

#### Planner (was Brain)

```
BEFORE planning:
  memory_recall("past decisions for [feature area]")   # don't re-debate
  memory_recall("session handoff")                      # continue previous work
  task_list(status="pending")                           # see what's queued

AFTER planning:
  task_create(title, description, priority)             # for each ROADMAP step
  memory_store(type="decision", scope="task")           # record architectural choices

ON COMPLETION:
  memory_store(type="context", tags="session-handoff")  # handoff to next session
```

#### Implementer (was Developer)

```
ON SPAWN:
  task_claim(task_id)                                   # SKIP LOCKED, no races
  memory_recall("patterns for [module]")                # match existing patterns
  working_memory_get("task-context")                    # ephemeral task context

DURING WORK:
  working_memory_set("progress", status)                # progress tracking

ON COMPLETION:
  artifact_store(type="code", confidence, evidence)     # output with provenance
  task_complete(task_id, result)                         # mark done
```

#### Reviewer

```
ON SPAWN:
  memory_recall("past bugs in [area]")                  # focus review
  artifact_list(task_id)                                # see what was produced

AFTER REVIEW:
  artifact_store(type="review", status="approved|rejected")  # verdict with provenance
  If VERIFIED: task stays complete
  If FAILED:   memory_store(type="error")               # prevent repeat bugs
               task back to "pending" for re-claim
```

### Files to migrate

| Playbook file | Action | New location |
|---------------|--------|-------------|
| `.cursor/agents/brain.md` | Rename + add Biblibit tools | `.cursor/agents/planner.md` |
| `.cursor/agents/developer.md` | Rename + add Biblibit tools | `.cursor/agents/implementer.md` |
| `.cursor/agents/reviewer.md` | Add Biblibit tools | `.cursor/agents/reviewer.md` |
| `.cursor/agents/THE-ARCHITECTS-PLAYBOOK.md` | Rewrite for Biblibit | `.cursor/agents/THE-ARCHITECTS-PLAYBOOK.md` |
| `.cursor/commands/go.md` | Update reference | `.cursor/commands/go.md` |
| `.cursor/rules/code-that-explains-itself.mdc` | Keep as-is | Same |
| `.cursor/rules/token-efficiency-and-parallelization.mdc` | Keep as-is | Same |
| `.cursor/rules/voice-commands.mdc` | Update agent names | Same |
| `.cursor/rules/go-command-confirmation.mdc` | Keep as-is | Same |
| `.cursor/rules/mode-discipline.mdc` | Keep as-is | Same |
| `.cursor/rules/Self-Improvement-Rules.mdc` | Keep as-is | Same |
| `scripts/set-model-profile.sh` | Update agent names | Same |
| `scripts/select-profile.sh` | Update agent names | Same |

### Key principle

Agents coordinate through Biblibit state, not through the Planner's context window.
The Planner doesn't need to remember everything -- Biblibit does.
