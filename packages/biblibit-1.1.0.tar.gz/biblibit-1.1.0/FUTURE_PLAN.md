<!--
Purpose: Track speculative Biblibit architecture work separately from the shipped runtime.
Role: Keeps the current product roadmap focused while preserving the longer-horizon orchestration plan.
-->

# Biblibit Future Plan

This file is the home for architecture ideas that should be tracked separately from the
current `biblibit` runtime. The matching memory namespace for this work is
`project="biblibit-future"`.

## Current Line

The `1.1.x` line should stay focused on:

- Short, safe database transactions
- Faster recall hot paths
- Name and version consistency
- Security hardening for the existing MCP surface

## Future Tracks

### 1. Secure Remote Runtime

- Restore secure-by-default remote deployment guidance
- Add stricter project scoping and server-side authorization checks
- Separate trusted local workflows from remotely exposed MCP endpoints

### 2. Orchestration Primitives

- Add agent registration, heartbeats, and lease-based task claiming
- Model tasks and artifacts explicitly instead of overloading memories
- Keep claim semantics level-triggered and idempotent

### 3. Scoped Memory And Provenance

- Introduce scopes such as `global`, `project`, `task`, and `agent-private`
- Record who wrote a memory, why it was written, and what evidence supports it
- Preserve backward compatibility for existing memories

### 4. Coordination Layer

- Add optional Redis-backed working memory and pub/sub only when latency or fan-out justifies it
- Keep Postgres as the durable source of truth
- Treat Redis as an acceleration layer, not a hard dependency for correctness

### 5. Integration Layer

- Expose future coordination features through MCP without breaking existing memory tools
- Add A2A or registry-style discovery only after the core task lifecycle is stable
- Keep the platform vendor-neutral

## Admission Criteria

Start these tracks only after:

- The memory server is measurably stable under stress
- Remote security defaults are tightened
- Performance baselines are captured for recall/store latency
- The task and artifact model is written down before code lands
