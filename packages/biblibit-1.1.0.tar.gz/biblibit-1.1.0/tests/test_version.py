"""Version consistency tests for Biblibit.

Purpose: Keep packaging metadata as the single source of truth for releases.
Role: Prevent runtime version drift between `pyproject.toml` and imports.
"""

from __future__ import annotations

from pathlib import Path
import tomllib

from biblibit import __version__


def test_runtime_version_matches_pyproject() -> None:
    """The imported package version should mirror project metadata exactly."""
    pyproject = Path(__file__).resolve().parents[1] / "pyproject.toml"
    with pyproject.open("rb") as fh:
        project_version = tomllib.load(fh)["project"]["version"]

    assert __version__ == project_version
