from setuptools import setup, find_packages

with open("README.md", "r", encoding="utf-8") as fh:
    long_description = fh.read()

setup(
    name="myffe",
    version="3.3.2",
    author="Your Name",
    author_email="your.email@example.com",
    description="Feature Engineering Framework - A comprehensive tool for data preprocessing and feature engineering",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/yourusername/myffe",
    packages=find_packages(),
    classifiers=[
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.7",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Programming Language :: Python :: 3.12",
        "Programming Language :: Python :: 3.13",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
        "Intended Audience :: Developers",
        "Intended Audience :: Science/Research",
        "Topic :: Scientific/Engineering :: Artificial Intelligence",
        "Topic :: Software Development :: Libraries :: Python Modules",
    ],
    python_requires=">=3.7",
    install_requires=[
        "pandas>=1.3.0",
        "numpy>=1.20.0",
        "scikit-learn>=0.24.0",
        "scipy>=1.6.0",
    ],
    keywords=[
        "feature engineering",
        "machine learning",
        "data preprocessing",
        "data cleaning",
        "data science",
        "python",
    ],
    include_package_data=True,
    package_data={
        "myffe": ["docs/*.json", "docs/*.txt"],
    },
)
