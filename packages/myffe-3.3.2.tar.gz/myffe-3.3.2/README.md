# myffe - Feature Engineering Framework

myffe 是一个工业级的特征工程框架，提供完整的特征工程工具链，支持数据清洗、特征提取、样本处理等功能。

## 特性

- **模块化设计**：易于扩展和定制
- **多种预处理方法**：支持缺失值处理、异常值处理、标准化、归一化等
- **预定义路线**：提供 20+ 种预定义的特征工程路线
- **自动参数推荐**：智能推荐最佳预处理参数
- **工业级封装**：外部接口简洁易用
- **纯 Python 实现**：无需编译，跨平台兼容

## 安装

```bash
pip install myffe
```

## 快速开始

### 简单使用

```python
import pandas as pd
from myffe import process_data

# 读取数据
data = pd.read_csv('your_data.csv')

# 使用预定义路线 1（基础路线）处理数据
processed_data = process_data(data, data_label='label', route_number=1)
```

### 高级使用

```python
from myffe import FFE

# 创建 FFE 实例
ffe = FFE()

# 创建流水线
console, tools = ffe.create_pipeline('label', route_number=3)

# 处理数据
console(tools, data, save_path='processed_data.csv')
```

### 自动推荐路线

```python
from myffe import FFE

ffe = FFE()

# 自动检测数据并推荐路线
recommended_route = ffe.auto_detect_route(data)

# 使用推荐的路线处理数据
console, tools = ffe.create_pipeline('label', route=recommended_route)
console(tools, data, save_path='processed_data.csv')
```

## 预定义路线

myffe 提供 20+ 种预定义路线，适用于不同场景：

1. **基础路线** - 适合大多数数据集
2. **股票数据路线** - 专为股票数据优化
3. **文本数据路线** - 包含文本处理
4. **时间序列路线** - 强化时间特征提取
5. **完整路线** - 包含所有预处理步骤
6. **轻量级路线** - 快速处理小数据集
7. **异常检测路线** - 专注于异常值处理
8. **特征增强路线** - 强化特征工程
9. **分类数据路线** - 适合分类任务
10. **回归数据路线** - 适合回归任务
11. **中文文本路线** - 专为中文文本数据优化
12. **不平衡数据路线** - 处理类别不平衡的数据集
13. **高维数据路线** - 处理特征维度较高的数据集
14. **金融数据路线** - 专为金融数据优化
15. **医疗数据路线** - 适合医疗数据集的处理
16. **电商数据路线** - 专为电商数据优化
17. **社交媒体数据路线** - 处理社交媒体数据
18. **传感器数据路线** - 处理传感器数据
19. **多模态数据路线** - 处理包含多种类型数据的数据集
20. **实时数据路线** - 适合实时数据流处理

查看可用路线：

```python
from myffe import show_available_routes
show_available_routes()
```

## 核心模块

### 1. 数据预处理 (preprocessing)

- `nan_preprocessing` - 缺失值处理
- `outlier_preprocessing` - 异常值处理
- `str_preprocessing` - 字符串处理
- `time_preprocessing` - 时间特征提取
- `standard_preprocessing` - 数据标准化
- `normalized_preprocessing` - 数据归一化
- `sample_preprocessing` - 样本处理
- `relative_preprocessing` - 相对特征处理
- `specify_preprocessing` - 指定特征处理

### 2. 路线配置 (route)

- `predefined_routes` - 预定义路线
- `auto_route` - 自动路线推荐
- `route_config` - 路线配置

### 3. 工具 (tools)

- `data_description` - 数据描述
- `data_inspector` - 数据检查
- `visualize_route` - 路线可视化
- `logger` - 日志系统
- `color_printer` - 彩色打印

## 核心接口

- `FFE` - 特征工程框架主类
- `FFE_config` - 配置类
- `FFE_console` - 控制台类
- `process_data` - 数据处理函数
- `get_recommended_route` - 获取推荐路线
- `show_available_routes` - 显示可用路线
- `get_route_params` - 获取路线参数
- `describe_data` - 描述数据
- `evaluate_dataset` - 评估数据集
- `visualize_route` - 可视化路线

## 使用示例

### 示例 1：基础数据处理

```python
import pandas as pd
from myffe import process_data

# 创建示例数据
data = pd.DataFrame({
    'feature1': [1.0, 2.0, None, 4.0, 5.0],
    'feature2': ['A', 'B', 'A', None, 'C'],
    'label': [0, 1, 0, 1, 0]
})

# 处理数据
processed = process_data(data, data_label='label', route_number=1)
print(processed.head())
```

### 示例 2：自定义路线

```python
from myffe import FFE, get_route_params

# 获取路线 3 的参数
params = get_route_params(3)

# 创建 FFE 实例
ffe = FFE()

# 创建流水线
console, tools = ffe.create_pipeline('label', route=params)

# 处理数据
console(tools, data, save_path='output.csv')
```

### 示例 3：数据评估

```python
from myffe import FFE, evaluate_dataset

ffe = FFE()

# 评估数据集
metrics = evaluate_dataset(data, 'label')
print(metrics)
```

## 日志系统

myffe 内置日志系统，可以记录所有处理步骤：

```python
from myffe import logger, set_logging_enabled

# 启用日志
set_logging_enabled(True)

# 禁用日志
set_logging_enabled(False)
```

## 系统要求

- Python >= 3.7
- pandas >= 1.3.0
- numpy >= 1.20.0
- scikit-learn >= 0.24.0
- scipy >= 1.6.0

## 许可证

MIT License

## 贡献

欢迎贡献代码！请提交 Issue 或 Pull Request。

## 联系方式

- Email: your.email@example.com
- GitHub: https://github.com/yourusername/myffe
