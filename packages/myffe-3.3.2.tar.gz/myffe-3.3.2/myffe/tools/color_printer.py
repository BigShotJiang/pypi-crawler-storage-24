﻿import os
import sys

class ColorPrinter:
    """彩色打印工具类"""

    # 检查是否支持ANSI颜色
    @classmethod
    def _supports_color(cls):
        # Windows环境下默认不使用颜色，避免编码问题
        if os.name == 'nt':
            return False
        return hasattr(sys.stdout, 'isatty') and sys.stdout.isatty()

    COLORS = {
        'red': '\033[91m',
        'green': '\033[92m',
        'yellow': '\033[93m',
        'blue': '\033[94m',
        'magenta': '\033[95m',
        'cyan': '\033[96m',
        'white': '\033[97m',
        'reset': '\033[0m'
    }

    @classmethod
    def print(cls, message, color='white'):
        if cls._supports_color():
            color_code = cls.COLORS.get(color, cls.COLORS['white'])
            reset_code = cls.COLORS['reset']
            console_message = f"{color_code}{message}{reset_code}"
            print(console_message)
        else:
            # 在不支持颜色的终端中，直接打印消息
            print(message)

    @classmethod
    def print_any(cls, *objects, sep=' ', end='\n', color=None):
        text = sep.join(str(obj) for obj in objects)
        if color and cls._supports_color():
            color_code = cls.COLORS.get(color, cls.COLORS['white'])
            reset_code = cls.COLORS['reset']
            console_message = f"{color_code}{text}{reset_code}"
            print(console_message, end=end)
        else:
            print(text, end=end)

    @classmethod
    def print_success(cls, message):
        cls.print(message, 'green')

    @classmethod
    def print_error(cls, message):
        cls.print(message, 'red')

    @classmethod
    def print_warning(cls, message):
        cls.print(message, 'yellow')

    @classmethod
    def print_info(cls, *objects, sep=' '):
        message = sep.join(str(obj) for obj in objects)
        cls.print(message, 'blue')

    @classmethod
    def print_data(cls, message):
        cls.print(message, 'magenta')

    @classmethod
    def print_progress(cls, message):
        cls.print(message, 'cyan')
