﻿"""
这个是日志模块2.0,将个性化适配preprocessing项目的日志需求
"""
import datetime
import os
import inspect
import threading
import traceback

class Logger:
    def __init__(self,module,log_path,switch = True, type='use'):
        self.module = module
        self.type = type
        self.switch = switch
        self.log_path = log_path
        self.lock = threading.Lock()#这里是创建一个锁,用来在多线程环境下,防止多个线程同时写入日志文件,导致日志文件损坏
        if not hasattr(Logger,'_initialized'):#这里是判断类属性是否存在,如果不存在就创建
            self.write_start_separator() # 写入开始分隔符
            import atexit
            atexit.register(self.write_end_separator)#这里是注册退出函数,用来在程序退出时写入结束分隔线，也就是一个函数退出时执行的函数
            Logger._initialized = True#这里是创建类属性，类属性对于每一个类的实例都生效，这里让一个文件都只有一次分隔，而每一次执行将重置也就是每一次执行文件都会分隔一次
    def write_start_separator(self):#这里是用来在日志文件中写入分隔线的方法
        if self.type is None:
            return
        file_path = os.path.join(self.log_path)
        with open(file_path, 'a', encoding='utf-8') as f:
            if self.type == 'use':
                pass
            elif self.type == 'test':
                f.write( '\n'+'-'*10+' 测试开始 '+ '-'*10 + '\n')
            else:
                print('你的日志类型设置有误，为了保持以后日志的可拓展性,请设置为use,test,None\n')
                pass
            call_time = datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')
            f.write(' ='*50 + '\n')
            f.write(f'                                         日志开始,时间: {call_time}\n')

    def write_end_separator(self):#这里是用来在日志文件中写入结束分隔线的方法
        if self.type is None:
            return
        file_path = os.path.join(self.log_path)
        with open(file_path, 'a', encoding='utf-8') as f:
            call_time = datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')
            f.write(f'                                         日志结束,时间: {call_time}\n')
            f.write(' =' * 50 + '\n')
            if self.type == 'use':
                pass
            elif self.type == 'test':
                f.write( '\n'+'-'*10+' 测试结束 '+ '-'*10 + '\n')
            else:
                print('你的日志类型设置有误，为了保持以后日志的可拓展性,请设置为use,test,None\n')
                pass
    def write_log(self, log_content):
        # 无论switch状态如何，只要type不是None，就写入日志文件
        if self.type is not None:
            with self.lock:
                file_path = os.path.join(self.log_path)
                with open(file_path, 'a', encoding='utf-8') as f:
                    f.write(log_content + '\n\n')
        else:
            pass
    def log_method_call_test(self,func):
        def wrapper(*args, **kwargs): #这里的*args是接收任意位置的参数,**kwargs是接收任意的关键字参数
            if self.type is None:
                return func(*args, **kwargs)
            
            method_name = func.__name__#获取函数的名称
            call_time_obj = datetime.datetime.now()#这里是获取当前时间
            call_time = call_time_obj.strftime('%Y-%m-%d %H:%M:%S')#这里是获取当前时间
            #这里的strftime方法是格式化时间的,前面的datatime.datetime.now()是获取当前时间这个时间的格式是：
            #这里的格式化字符串'%Y-%m-%d %H:%M:%S'是指年-月-日 时:分:秒
            self.start_time = f'{call_time}[INFO]方法[{method_name}]开始调用 | 位置参数:{args} | 关键字参数:{kwargs}'
            # 写入日志（无论switch状态如何）
            self.write_log(self.start_time)#这里是调用写入日志的方法
            try:
                result = func(*args,**kwargs)#这里是返回函数的调用结果
                cost_time = round((datetime.datetime.now() - call_time_obj).total_seconds(), 4)
                #这里这个round方法是用来四舍五入的,这里的参数是4是指保留4位小数
                success = f'{call_time}[INFO]方法[{method_name}]调用成功 | 耗时:{cost_time}秒 | 返回值:{result}'
                # 写入日志（无论switch状态如何）
                self.write_log(success)#这里是调用写入日志的方法
                return result#这里是返回函数的调用结果
            except Exception as e:
                cost_time = round((datetime.datetime.now() - call_time_obj).total_seconds(), 2)
                error_type = type(e).__name__
                error_msg =str(e)
                error_stack = traceback.format_exc()[:500]#这里是获取错误栈的信息,并截取前500个字符，防止日志文件过大
                fail_log = f'{call_time}[ERROR]方法[{method_name}]调用失败 | 耗时:{cost_time}秒 | 错误类型:{error_type} | 错误信息:{error_msg}\n{error_stack}'
                # 写入日志（无论switch状态如何）
                self.write_log(fail_log)#这里是调用写入日志的方法
                raise e
                #这里是抛出异常
        return wrapper
    def log_method_call_use(self,func):
        def wrapper(*args, **kwargs): #这里的*args是接收任意位置的参数,**kwargs是接收任意的关键字参数
            if self.type is None:
                return func(*args, **kwargs)
            
            method_name = func.__name__#获取函数的名称
            call_time_obj = datetime.datetime.now()#这里是获取当前时间
            call_time = call_time_obj.strftime('%Y-%m-%d %H:%M:%S')#这里是获取当前时间
            
            # 提取preprocessing工具名称
            tool_name = args[0].__class__.__name__ if args else "UnknownTool"
            
            # 炫酷的开始信息（仅当switch为True时显示）
            if self.switch:
                start_msg = f"\n{'='*70}"
                start_msg += f"\n[{call_time}] 🚀 开始执行: {tool_name}.{method_name}"
                start_msg += f"\n{'='*70}"
                start_msg += f"\n🎯 工具: {tool_name}"
                start_msg += f"\n🔧 方法: {method_name}"
                start_msg += f"\n📅 时间: {call_time}"
                if kwargs:
                    start_msg += f"\n⚙️  参数: {kwargs}"
                start_msg += f"\n{'='*70}"
                print(start_msg)
            
            # 写入日志（无论switch状态如何）
            self.write_log(f"{call_time}[INFO]开始执行 {tool_name}.{method_name}")
            
            try:
                # 执行函数
                result = func(*args,**kwargs)
                
                # 计算执行时间
                cost_time = round((datetime.datetime.now() - call_time_obj).total_seconds(), 4)
                
                # 炫酷的完成信息（仅当switch为True时显示）
                if self.switch:
                    finish_msg = f"\n{'='*70}"
                    finish_msg += f"\n[{call_time}] ✅ 执行完成: {tool_name}.{method_name}"
                    finish_msg += f"\n{'='*70}"
                    finish_msg += f"\n🎉 状态: 成功完成"
                    finish_msg += f"\n⏱️  耗时: {cost_time}秒"
                    finish_msg += f"\n📊 性能: {'优秀' if cost_time < 0.1 else '良好' if cost_time < 1 else '一般'}"
                    finish_msg += f"\n{'='*70}"
                    print(finish_msg)
                
                # 写入日志（无论switch状态如何）
                self.write_log(f"{call_time}[INFO]执行完成 {tool_name}.{method_name} | 耗时: {cost_time}秒 | 状态: 成功")
                
                return result#这里是返回函数的调用结果
            except Exception as e:
                cost_time = round((datetime.datetime.now() - call_time_obj).total_seconds(), 2)
                error_type = type(e).__name__
                error_msg =str(e)
                error_stack = traceback.format_exc()[:500]#这里是获取错误栈的信息,并截取前500个字符，防止日志文件过大
                
                # 炫酷的错误信息（仅当switch为True时显示）
                if self.switch:
                    error_msg_display = f"\n{'='*70}"
                    error_msg_display += f"\n[{call_time}] ❌ 执行失败: {tool_name}.{method_name}"
                    error_msg_display += f"\n{'='*70}"
                    error_msg_display += f"\n💥 状态: 执行失败"
                    error_msg_display += f"\n⏱️  耗时: {cost_time}秒"
                    error_msg_display += f"\n🔍 错误类型: {error_type}"
                    error_msg_display += f"\n💬 错误信息: {error_msg}"
                    error_msg_display += f"\n🔧 建议: 检查参数配置和数据格式"
                    error_msg_display += f"\n{'='*70}"
                    print(error_msg_display)
                
                # 写入日志（无论switch状态如何）
                fail_log = f'{call_time}[ERROR]执行失败 {tool_name}.{method_name} | 耗时:{cost_time}秒 | 错误类型:{error_type} | 错误信息:{error_msg}\n{error_stack}'
                self.write_log(fail_log)#这里是调用写入日志的方法
                raise e
                #这里是抛出异常
        return wrapper

def log_class(type = 'use'):
    def decorator(cls):
        for name, method in inspect.getmembers(cls, predicate=inspect.isfunction):
            #这里通过inspect.isfunction方法来获取类的方法名以及类的方法，下面将方法作为参数传入log_method_call方法
            #这里的这个method是一个函数对象,但是只不过是一个代码与方法相同的函数对象,但是这里这个函数没有与类绑定的self参数        
            if not name.startswith('__'):
                #这里是判断是否是类的方法的名称开头是不是__，如果是__开头的方法,则说明是类的特殊方法,不需要记录日志
                if type == 'use':
                    setattr(cls, name, logger.log_method_call_use(method))#这个setattr方法是用来设置类的属性的,这里是将类的方法替换为日志记录的方法
                elif type == 'test':
                    setattr(cls, name, logger.log_method_call_test(method))#这个setattr方法是用来设置类的属性的,这里是将类的方法替换为日志记录的方法
                # 如果type是None，不添加日志装饰器
        return cls
    return decorator
# 这一块将被修饰的类的所有的方法都配置为日志记录的方法，这里的name是类的方法名，method是类的方法


# 创建logger实例
logger = Logger(module="preprocessing", log_path="D:\\HP\\pythonwork\\MFM\\save_logger\\preprocessing.log", switch=True, type=None)

# 全局日志控制函数
def set_logging_enabled(enabled):
    """
    设置全局控制台输出开关状态
    
    Args:
        enabled (bool): 是否在控制台显示日志
    """
    global logger
    logger.switch = enabled
    print(f"\033[34m控制台日志输出已设置为: {'启用' if enabled else '禁用'}\033[0m")


# 主程序示例
if __name__ == "__main__":
    """
    日志系统使用示例
    展示如何传参给日志系统并控制其行为
    """
    print("=" * 80)
    print("FFE 3.0 日志系统使用示例")
    print("=" * 80)
    
    # 示例1: 使用默认设置（None模式，无日志）
    print("\n示例1: 使用默认设置（None模式，无日志）")
    print("-" * 80)
    print(f"当前日志类型: {logger.type}")
    print(f"当前控制台输出: {logger.switch}")
    
    # 定义一个测试函数
    def test_function(param1, param2):
        """测试函数"""
        print(f"执行测试函数，参数: {param1}, {param2}")
        return f"结果: {param1 + param2}"
    
    # 应用日志装饰器
    @logger.log_method_call_use
    def decorated_test_function(param1, param2):
        """带日志装饰器的测试函数"""
        print(f"执行装饰后的测试函数，参数: {param1}, {param2}")
        return f"结果: {param1 + param2}"
    
    # 调用函数（默认None模式，无日志输出）
    result = decorated_test_function(10, 20)
    print(f"函数返回值: {result}")
    
    # 示例2: 切换到use模式并启用控制台输出
    print("\n示例2: 切换到use模式并启用控制台输出")
    print("-" * 80)
    logger.type = 'use'
    logger.switch = True
    print(f"当前日志类型: {logger.type}")
    print(f"当前控制台输出: {logger.switch}")
    
    # 调用函数（use模式，有控制台输出）
    result = decorated_test_function(30, 40)
    print(f"函数返回值: {result}")
    
    # 示例3: 禁用控制台输出但保持日志写入
    print("\n示例3: 禁用控制台输出但保持日志写入")
    print("-" * 80)
    logger.switch = False
    print(f"当前日志类型: {logger.type}")
    print(f"当前控制台输出: {logger.switch}")
    
    # 调用函数（无控制台输出，但仍写入日志文件）
    result = decorated_test_function(50, 60)
    print(f"函数返回值: {result}")
    
    # 示例4: 切换到test模式
    print("\n示例4: 切换到test模式")
    print("-" * 80)
    logger.type = 'test'
    logger.switch = True
    print(f"当前日志类型: {logger.type}")
    print(f"当前控制台输出: {logger.switch}")
    
    # 应用test模式装饰器
    @logger.log_method_call_test
    def test_mode_function(param1, param2):
        """test模式的测试函数"""
        print(f"执行test模式测试函数，参数: {param1}, {param2}")
        return f"结果: {param1 * param2}"
    
    # 调用函数（test模式，详细日志输出）
    result = test_mode_function(7, 8)
    print(f"函数返回值: {result}")
    
    # 示例5: 使用set_logging_enabled函数控制控制台输出
    print("\n示例5: 使用set_logging_enabled函数控制控制台输出")
    print("-" * 80)
    set_logging_enabled(False)
    print(f"当前控制台输出: {logger.switch}")
    
    # 调用函数（无控制台输出）
    result = decorated_test_function(90, 100)
    print(f"函数返回值: {result}")
    
    # 恢复控制台输出
    set_logging_enabled(True)
    
    print("\n" + "=" * 80)
    print("日志系统使用示例完成")
    print("=" * 80)
    print("\n提示:")
    print("1. 使用 logger.type 设置日志模式 (None/use/test)")
    print("2. 使用 logger.switch 控制控制台输出 (True/False)")
    print("3. 使用 set_logging_enabled() 函数快速控制控制台输出")
    print("4. 无论控制台输出是否启用，日志都会写入文件（当type不为None时）")
