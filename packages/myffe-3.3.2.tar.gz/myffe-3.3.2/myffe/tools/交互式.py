﻿import sys
import os
from abc import ABC





class interactive(ABC):
    def __init__(self, options ,title="请按上下箭头选择，回车确认", description="", min_select=0, max_select=None):
        super().__init__()
        self.options = self._check_options(options)
        self.title = title
        self.description = description
        self.current_idx = 0
        self.confirm_keys = ('\r', '\n')
        self.m = False
        self.min_select = min_select
        self.max_select = max_select if max_select is not None else len(options)
        # 初始化selected为空列表
        self.selected = []
        

    def _check_options(self, options):
        if not isinstance(options, list) or len(options) == 0:
            raise ValueError("选项列表不能为空且为list类型")
        if not all(isinstance(opt, str) for opt in options):
            raise TypeError("选项列表元素必须为字符串类型")
        return options
#这里加入了多选功能，用户可以按下'm'键来确认选择当前选项并继续选择其他选项，直到按下回车键来完成选择
    def _get_key(self):
        if sys.platform.startswith('win'):
            import msvcrt
            while True:
                if msvcrt.kbhit():
                    key = msvcrt.getch()
                    if key == b'\xe0':
                        key2 = msvcrt.getch()
                        if key2 == b'H':
                            return 'up'
                        elif key2 == b'P':
                            return 'down'
                    else:
                        try:
                            key_char = key.decode('ascii', errors='ignore').lower()
                            if key_char == 'm':
                                return 'm'
                            if key_char == 'r' or key_char == '\r':
                                return '\r'
                            return key_char
                        except:
                            return ''
        else:
            import termios
            import tty
            fd = sys.stdin.fileno()
            old_settings = termios.tcgetattr(fd)
            try:
                tty.setraw(fd)
                key = sys.stdin.read(1)
                if key == '\x1b':
                    sys.stdin.read(1)
                    key2 = sys.stdin.read(1)
                    if key2 == 'A':
                        return 'up'
                    elif key2 == 'B':
                        return 'down'
                return key.lower()
            finally:
                termios.tcsetattr(fd, termios.TCSADRAIN, old_settings)

    def _clear_screen(self):
        os.system('cls' if sys.platform.startswith('win') else 'clear')

    def _print_menu(self):
        print(self.title)
        if self.description:
            print()
            print(f"参数说明: {self.description}")
        print()
        # 显示已选择的选项（在参数说明下面）
        if self.selected:
            # 处理嵌套列表，确保所有元素都是字符串
            display_items = []
            for item in self.selected:
                if isinstance(item, list):
                    # 展平嵌套列表
                    for subitem in item:
                        display_items.append(str(subitem))
                else:
                    display_items.append(str(item))
            print("已选择：", " | ".join(display_items))
        print(f"（最少选择 {self.min_select} 个，最多选择 {self.max_select} 个）")
        print()
        for idx, opt in enumerate(self.options):
            if idx == self.current_idx:
                print(f"-> {opt}")
            else:
                print(f"   {opt}")

    def _handle_key(self, key):
        if key == 'up' and self.current_idx > 0:
            self.current_idx -= 1
        elif key == 'down' and self.current_idx < len(self.options) - 1:
            self.current_idx += 1
        elif key == 'm':
            self.m = True
            if not hasattr(self, 'selected'):
                self.selected = []
            current_option = self.options[self.current_idx]
            if current_option not in self.selected:
                self.selected.append(current_option)
            return 'm_select'
        elif key in ['\b', '\x08', 'backspace']:
            if hasattr(self, 'selected') and self.selected and len(self.selected) > 0:
                removed = self.selected.pop()
                print(f"\n已删除：{removed}")
                return 'delete'
            return None
        elif key in self.confirm_keys:
            if not hasattr(self, 'selected'):
                self.selected = []
            if len(self.selected) >= self.min_select:
                return self.selected
            else:
                print(f"\n至少需要选择 {self.min_select} 个选项，当前已选择 {len(self.selected)} 个")
                return None

        return None

    def run(self):
        # 确保selected被正确初始化为空列表
        self.selected = []
        self.m = False
        self.max_select = self.max_select if self.max_select is not None else len(self.options)
        
        # 首次显示菜单，不清屏，等待用户按回车开始
        self._print_menu()
        print("\n按回车键开始选择...")
        
        # 等待用户按下回车键
        while True:
            key = self._get_key()
            if key in self.confirm_keys:
                break
        
        # 开始正常的选择循环
        while True:
            self._clear_screen()
            self._print_menu()
            key = self._get_key()
            result = self._handle_key(key)
            if result == 'delete':
                continue
            if result == 'm_select':
                print(f"\n已选择：{self.selected[-1]}")
                print(f"当前已选择：{self.selected}")
                print("继续选择其他选项...")
                continue
            if isinstance(result, list):
                return result
            # 只处理非回车和非删除的键，且确保result不是列表
            if result is not None and not isinstance(result, list) and result not in self.confirm_keys and result != 'delete':
                if len(self.selected) >= self.max_select:
                    print(f"\n最多只能选择 {self.max_select} 个选项")
                    continue
                if result not in self.selected:
                    self.selected.append(result)
                print(f"\n已选择：{result}")
                print(f"当前已选择：{self.selected}")
                print("继续选择其他选项...")

#这里要加入多选功能
if __name__ == "__main__":
    test_options = ["特征工程", "模型训练", "结果可视化", "项目退出"]
    selector = interactive(test_options)
    selector.run()
