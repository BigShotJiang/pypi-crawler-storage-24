﻿#!/usr/bin/env python3
"""
??????????
???????????????
"""

import sys
import os

# ??MFM???Python??
current_dir = os.path.dirname(os.path.abspath(__file__))
ffe_dir = os.path.dirname(current_dir)
mfm_dir = os.path.dirname(os.path.dirname(ffe_dir))
sys.path.append(mfm_dir)

# ??color_printer??
from myffe.tools.color_printer import ColorPrinter

def cprint(text, color=None, bold=False):
    """???????"""
    if color == 'header':
        ColorPrinter.print_info(text)
    elif color == 'okblue':
        ColorPrinter.print_info(text)
    elif color == 'okgreen':
        ColorPrinter.print_success(text)
    elif color == 'warning':
        ColorPrinter.print_warning(text)
    elif color == 'fail':
        ColorPrinter.print_error(text)
    else:
        print(text)

def print_tree(data, indent=0, prefix=""):
    """
    ????????
    
    Args:
        data: ?????????????
        indent: ????
        prefix: ??
    """
    if isinstance(data, dict):
        for i, (key, value) in enumerate(data.items()):
            is_last = i == len(data) - 1
            connector = "??? " if is_last else "??? "
            if isinstance(value, (dict, list)):
                cprint(f"{prefix}{connector}{key}", "okblue")
                new_prefix = prefix + ("    " if is_last else "?   ")
                print_tree(value, indent + 1, new_prefix)
            else:
                cprint(f"{prefix}{connector}{key}: {value}", "okgreen")
    elif isinstance(data, list):
        for i, item in enumerate(data):
            is_last = i == len(data) - 1
            connector = "??? " if is_last else "??? "
            if isinstance(item, (dict, list)):
                cprint(f"{prefix}{connector}[{i}]", "okblue")
                new_prefix = prefix + ("    " if is_last else "?   ")
                print_tree(item, indent + 1, new_prefix)
            else:
                cprint(f"{prefix}{connector}{item}", "okgreen")

def print_section_title(title, section_number=None):
    """??????"""
    if section_number:
        cprint(f"\n{section_number}. {title}", "header", bold=True)
    else:
        cprint(f"\n{title}", "header", bold=True)
    cprint("-" * 40, "header")

def print_detailed_params(data, indent=2):
    """
    ????????
    
    Args:
        data: ????
        indent: ????
    """
    if isinstance(data, dict):
        for key, value in data.items():
            if isinstance(value, (dict, list)):
                cprint(f"{' ' * indent}? {key}:", "okblue")
                print_detailed_params(value, indent + 4)
            else:
                cprint(f"{' ' * indent}? {key}: {value}", "okgreen")
    elif isinstance(data, list):
        for i, item in enumerate(data):
            if isinstance(item, (dict, list)):
                cprint(f"{' ' * indent}? [{i}]:", "okblue")
                print_detailed_params(item, indent + 4)
            else:
                cprint(f"{' ' * indent}? {item}", "okgreen")

def visualize_route(route):
    """
    ??????????????????
    
    Args:
        route: ??????
    """
    cprint("=" * 80, "header", bold=True)
    cprint("??????? (????)", "header", bold=True)
    cprint("=" * 80, "header", bold=True)
    
    # ???????
    print_tree(route)
    
    cprint("\n" + "=" * 80, "header", bold=True)
    cprint("??????", "header", bold=True)
    cprint("=" * 80, "header", bold=True)
    
    # ????
    total_modules = len(route)
    cprint(f"\n? ????: ? {total_modules} ??????", "okblue", bold=True)
    
    # ??????????????
    module_names = {
        'nan_preprocessing': '?????',
        'standard_preprocessing': '?????',
        'normalized_preprocessing': '?????',
        'sample_preprocessing': '????',
        'outlier_preprocessing': '?????',
        'str_preprocessing': '?????',
        'relative_preprocessing': '????',
        'time_preprocessing': '????',
        'specify_preprocessing': '????'
    }
    
    section_count = 1
    for module_key, module_data in route.items():
        # ??????
        module_name = module_names.get(module_key, module_key)
        print_section_title(module_name, section_count)
        
        # ??????
        print_detailed_params(module_data)
        section_count += 1
    
    cprint("\n" + "=" * 80, "header", bold=True)
    cprint("?????", "okgreen", bold=True)
    cprint("=" * 80, "header", bold=True)


if __name__ == "__main__":
    # ????
    test_route = {
        "nan_preprocessing": {
            "nan_missing_process_choice": [["skip"], ["skip"], ["skip"]],
            "nan_processing_col": ["name", "age", "salary"],
            "drop_threshold": 0.5,
            "knn_n_neighbors": 5
        },
        "standard_preprocessing": {
            "scaler_method_choice": ["Z-score???", "RobustScaler???", "RobustScaler???"],
            "standard_col": ["age", "salary", "score"]
        },
        "normalized_preprocessing": {
            "normalizer_method_choice": ["Max???", "Max???", "Max???"],
            "normalized_col": ["age", "salary", "score"]
        },
        "sample_preprocessing": {
            "choice1_normal": ["multi_class_balance"],
            "choice1_advance": ["skip"],
            "balance_method": "oversample",
            "random_state": 42,
            "high_sample_selection": "RandomOverSampler"
        }
    }
    
    visualize_route(test_route)
