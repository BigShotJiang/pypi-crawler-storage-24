﻿from myffe.tools.color_printer import ColorPrinter

def inspect_data(data):
    """检查数据大小和行数
    
    Args:
        data: pandas DataFrame，输入数据
        
    Returns:
        int: Dask处理阈值（500万行）
    """
    # 检查数据类型
    data_type = type(data).__name__
    ColorPrinter.print_info(f'数据类型: {data_type}')
    
    # 基本信息
    data_size = data.memory_usage(deep=True).sum() / (1024 * 1024)  # 转换为MB
    ColorPrinter.print_info(f'数据大小: {data_size:.2f} MB')
    ColorPrinter.print_info(f'数据行数: {len(data)} 行')
    ColorPrinter.print_info(f'数据列数: {len(data.columns)} 列')
    
    # 列信息
    numeric_cols = data.select_dtypes(include=['number']).columns.tolist()
    categorical_cols = data.select_dtypes(include=['object', 'category']).columns.tolist()
    datetime_cols = data.select_dtypes(include=['datetime64']).columns.tolist()
    
    ColorPrinter.print_info(f'数值列数量: {len(numeric_cols)}')
    ColorPrinter.print_info(f'类别列数量: {len(categorical_cols)}')
    ColorPrinter.print_info(f'时间列数量: {len(datetime_cols)}')
    
    # 缺失值信息
    missing_values = data.isnull().sum().sum()
    total_cells = data.size
    missing_percentage = (missing_values / total_cells) * 100 if total_cells > 0 else 0
    
    if missing_values > 0:
        ColorPrinter.print_warning(f'缺失值数量: {missing_values} ({missing_percentage:.2f}%)')
    else:
        ColorPrinter.print_success('无缺失值')
    
    # 数据范围信息（仅数值列）
    if numeric_cols:
        numeric_data = data[numeric_cols]
        min_values = numeric_data.min()
        max_values = numeric_data.max()
        mean_values = numeric_data.mean()
        
        ColorPrinter.print_info('数值列基本统计:')
        for col in numeric_cols[:5]:  # 只显示前5个数值列
            try:
                ColorPrinter.print_info(f'  {col}: 最小值={min_values[col]:.2f}, 最大值={max_values[col]:.2f}, 均值={mean_values[col]:.2f}')
            except (TypeError, ValueError):
                # 处理无法格式化的情况
                ColorPrinter.print_info(f'  {col}: 最小值={min_values[col]}, 最大值={max_values[col]}, 均值={mean_values[col]}')
        if len(numeric_cols) > 5:
            ColorPrinter.print_info(f'  ... 还有 {len(numeric_cols) - 5} 个数值列')
    
    return None
