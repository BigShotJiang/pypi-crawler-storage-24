﻿"""
FFEv3.0 ???????

??FFEv2.0?????????
??preprocessing?????????????

?????
1. ??????preprocessing??
2. ??????????????????
3. ?????preprocessing
4. ???????????
5. ??????????
6. ???????
7. ??????
8. ????
"""

import sys
import os
import pandas as pd
import time
import json
from datetime import datetime

# ??MFM?????Python??
sys.path.append(os.path.abspath('.'))

from myffe.tools.color_printer import ColorPrinter

# ??????? - ?????????
clean_ways = [
    "nan_preprocessing",      # 1. ?????
    "outlier_preprocessing",  # 2. ?????
    "str_preprocessing",      # 3. ??????
    "time_preprocessing",     # 4. ??????
    "relative_preprocessing", # 5. ????
    "specify_preprocessing",  # 6. ????
    "sample_preprocessing",   # 7. ????
    "standard_preprocessing", # 8. ?????
    "normalized_preprocessing", # 9. ?????
]


class FFE_console:
    """
    FFEv3.0 ???????
    """
    
    def __init__(self, data_label, ways='auto', batch_size=None, enable_logging=True, enable_visualization=True, enable_quality_assessment=True):
        """
        ??????
        
        Args:
            data_label (str): ??????
            ways (str): ???????
                - 'auto': ????????
                - 'intelligent': ????????????
                - 'pass': ????????????
            batch_size (int): ????????????None??????
            enable_logging (bool): ????????????True
            enable_visualization (bool): ???????????????True
            enable_quality_assessment (bool): ??????????????True
        """
        self.data_label = data_label
        self.ways = ways
        self.batch_size = batch_size
        self.enable_logging = enable_logging
        self.enable_visualization = enable_visualization
        self.enable_quality_assessment = enable_quality_assessment
        self.data = None
        self.text_features = None
        self.str_confirm = False
        self.performance_stats = {}
        self.quality_metrics = {}
        self.processing_history = []
        
        ColorPrinter.print_info("FFEv3.0 ???????")
        ColorPrinter.print_info(f"???: {data_label}")
        ColorPrinter.print_info(f"????: {ways}")
        if batch_size:
            ColorPrinter.print_info(f"????: {batch_size}")
        ColorPrinter.print_info(f"????: {'??' if enable_logging else '??'}")
        ColorPrinter.print_info(f"?????: {'??' if enable_visualization else '??'}")
        ColorPrinter.print_info(f"??????: {'??' if enable_quality_assessment else '??'}")
        ColorPrinter.print_any("")
    
    def __call__(self, clean_tools, data, save_path='./clean_data/data00.csv', describe_data=True):
        """
        ??????????preprocessing???
        
        Args:
            clean_tools (dict): preprocessing????
            data (DataFrame): ????
            save_path (str): ??????????
            describe_data (bool): ??????????????True
            
        Returns:
            DataFrame: ??????
        """
        start_time = time.time()
        self.clean_ways_dict = clean_tools
        self.data = data.copy()
        self.save_path = save_path
        
        # ??????
        try:
            from MFM.FFE.FFEv3_1.tools.Loggerv1_1 import set_logging_enabled
            set_logging_enabled(self.enable_logging)
            # ???enable_logging??????????????????
        except ImportError:
            ColorPrinter.print_warning("??: ???????????????????")
        
        # 处理后数据描述
        if describe_data:
            ColorPrinter.print_any("\n" + "=" * 80)
            ColorPrinter.print_info("? ?????????")
            ColorPrinter.print_any("=" * 80)
            try:
                from myffe.tools.data_description import describe_data
                describe_data(self.data)
            except ImportError:
                ColorPrinter.print_warning("??: ????????????????")
            ColorPrinter.print_any("=" * 80 + "\n")
        
        # ????????
        if self.enable_quality_assessment:
            self._assess_data_quality(self.data, "initial")
        
        # ??????
        self.sorting(self.clean_ways_dict)
        
        # ??????
        self.clean_console()
        
        # ??????
        if self.str_confirm and self.text_features is not None:
            self.data = pd.concat([self.data, self.text_features], axis=1)
            ColorPrinter.print_success("OK ???????????")
        
        # ?????????
        if self.enable_quality_assessment:
            self._assess_data_quality(self.data, "final")
        
        # ????
        self.save_data()
        
        # ???????
        if describe_data:
            ColorPrinter.print_any("\n" + "=" * 80)
            ColorPrinter.print_info("? ?????????")
            ColorPrinter.print_any("=" * 80)
            try:
                from myffe.tools.data_description import describe_data
                describe_data(self.data)
            except ImportError:
                ColorPrinter.print_warning("??: ????????????????")
            ColorPrinter.print_any("=" * 80 + "\n")
        
        # ??????
        self._generate_processing_report(start_time)
        
        return self.data
    
    def sorting(self, clean_tools):
        """
        ?????????????
        
        Args:
            clean_tools (dict): ??????
        """
        if self.ways == 'auto':
            sorted_dict = {}
            for tool_name in clean_ways:
                if tool_name in clean_tools:
                    sorted_dict[tool_name] = clean_tools[tool_name]
            self.clean_ways_dict = sorted_dict
        elif self.ways == 'intelligent':
            # ???????????????????
            sorted_dict = self._intelligent_sorting(clean_tools)
            self.clean_ways_dict = sorted_dict
        elif self.ways == 'pass':
            self.clean_ways_dict = clean_tools
        else:
            ColorPrinter.print_error(f"???????{self.ways}??????pass")
            self.clean_ways_dict = clean_tools
    
    def clean_console(self):
        """
        ??????????????
        """
        try:
            if self.batch_size is not None and len(self.data) > self.batch_size:
                self.data = self._process_in_batches()
            else:
                self.data = self._process_single_batch(self.data)
        except Exception as e:
            ColorPrinter.print_error(f"?????????: {e}")
            raise
    
    def _process_single_batch(self, batch_data):
        """
        ????????
        
        Args:
            batch_data (DataFrame): ???????
            
        Returns:
            DataFrame: ??????
        """
        processed_data = batch_data.copy()
        
        for tool_name in self.clean_ways_dict.keys():
            ColorPrinter.print_info(f"????: {tool_name}")
            start_tool_time = time.time()
            
            # ????????????????
            if self.enable_quality_assessment:
                pre_quality = self._calculate_quality_metrics(processed_data)
            
            processed_data = self._execute_preprocessing(tool_name, processed_data)
            
            # ????????????????
            if self.enable_quality_assessment:
                post_quality = self._calculate_quality_metrics(processed_data)
                quality_change = {k: post_quality.get(k, 0) - pre_quality.get(k, 0) for k in set(pre_quality.keys())}
                self.processing_history.append({
                    'tool': tool_name,
                    'execution_time': time.time() - start_tool_time,
                    'quality_change': quality_change
                })
            else:
                self.processing_history.append({
                    'tool': tool_name,
                    'execution_time': time.time() - start_tool_time
                })
            
            # ??????????????
            ColorPrinter.print_any("\n" + "=" * 80)
            ColorPrinter.print_info(f"? {tool_name} ?????????")
            ColorPrinter.print_any("=" * 80)
            try:
                from myffe.tools.data_description import describe_data
                describe_data(processed_data)
            except ImportError:
                ColorPrinter.print_warning("??: ????????????????")
            ColorPrinter.print_any("=" * 80 + "\n")
            
            ColorPrinter.print_success(f"OK {tool_name} ?? (??: {time.time() - start_tool_time:.2f} ?)")
        
        return processed_data
    
    def _process_in_batches(self):
        """
        ?????????
        
        Returns:
            DataFrame: ??????
        """
        ColorPrinter.print_warning(f"??????????????: {self.batch_size}")
        ColorPrinter.print_info(f"????: {len(self.data)} ?")
        ColorPrinter.print_info(f"?????: {(len(self.data) + self.batch_size - 1) // self.batch_size}")
        ColorPrinter.print_any("")
        
        batch_data_list = []
        batch_count = 0
        
        for i in range(0, len(self.data), self.batch_size):
            batch_count += 1
            batch_data = self.data.iloc[i:i + self.batch_size].copy()
            
            ColorPrinter.print_warning(f"???? {batch_count}: ?{i+1}-{min(i+self.batch_size, len(self.data))} ?")
            
            processed_batch = self._process_single_batch(batch_data)
            batch_data_list.append(processed_batch)
            ColorPrinter.print_success(f"OK ?? {batch_count} ??")
            ColorPrinter.print_any("")
        
        processed_data = pd.concat(batch_data_list, ignore_index=True)
        ColorPrinter.print_success(f"??????????{batch_count}???")
        return processed_data
    
    def _execute_preprocessing(self, tool_name, data):
        """
        ????preprocessing
        
        Args:
            tool_name (str): preprocessing????
            data (DataFrame): ????
            
        Returns:
            DataFrame: ??????
        """
        processor = self.clean_ways_dict.get(tool_name)
        
        if processor is None:
            ColorPrinter.print_error(f"??: ???preprocessing?? {tool_name}")
            return data
        
        # ?????NaN??????????????
        if tool_name in ['standard_preprocessing', 'normalized_preprocessing']:
            numeric_cols = data.select_dtypes(include=['number']).columns
            feature_cols = [col for col in numeric_cols if col != self.data_label]
            if feature_cols:
                # ??????NaN?
                has_nan = data[feature_cols].isnull().any().any()
                if has_nan:
                    ColorPrinter.print_warning(f"??: {tool_name} ????????NaN???????")
                    # ??????NaN?
                    for col in feature_cols:
                        if data[col].isnull().any().any():
                            data[col] = data[col].fillna(data[col].mean())
                            ColorPrinter.print_info(f"  ???? {col} ?NaN?")
        
        # ?????preprocessing????
        if tool_name == 'nan_preprocessing':
            # ?????get??clean_type,???????normal
            params = processor.shortcut_nan
            return processor(data, self.data_label)
        
        elif tool_name == 'sample_preprocessing':
            # ?????get??clean_type,???????normal
            params = processor.shortcut_sample
            return processor(data, 'normal', self.data_label)
        
        elif tool_name == 'outlier_preprocessing':
            #??????get??????????????processor
            return processor(data, self.data_label)
        
        elif tool_name == 'str_preprocessing':
            # ?????get??clean_ways,???????[]
            params = processor.shortcut_str
            clean_ways = params.get('clean_ways', [])
            result = processor(data, self.data_label, clean_ways)
            # ??????????
            if isinstance(result, tuple):
                processed_data, text_features = result
                if not self.str_confirm:
                    self.text_features = text_features
                self.str_confirm = True
            else:
                processed_data = result
            return processed_data
        
        elif tool_name == 'relative_preprocessing':
            # ?????get??clean_type,???????normal
            params = processor.shortcut_relative
            return processor(data, self.data_label)
        
        elif tool_name == 'time_preprocessing':
            # ?????get??time_pre_type,???????basic
            params = processor.shortcut_time
            return processor(data)
        
        elif tool_name == 'specify_preprocessing':
            # ?????get??clean_type,???????normal
            params = processor.shortcut_specify
            return processor(data, self.data_label)
        
        elif tool_name == 'standard_preprocessing':
            #??????get??????????????processor
            numeric_cols = data.select_dtypes(include=['number']).columns
            feature_cols = [col for col in numeric_cols if col != self.data_label]
            if feature_cols:
                # ??processor????
                processed_data = processor(data[feature_cols])
                # ??????DataFrame
                if isinstance(processed_data, pd.DataFrame):
                    # ????
                    ColorPrinter.print_info(f"??????: {data.shape}")
                    ColorPrinter.print_info(f"???????: {processed_data.shape}")
                    ColorPrinter.print_info(f"????????: {len(data.index)}")
                    ColorPrinter.print_info(f"?????????: {len(processed_data.index)}")
                    
                    # ??????
                    processed_data = processed_data.reindex(data.index)
                    
                    # ??????
                    result_data = data.copy()
                    
                    # ????????
                    for col in feature_cols:
                        if col in processed_data.columns:
                            try:
                                result_data[col] = processed_data[col]
                            except Exception as e:
                                ColorPrinter.print_error(f"??? {col} ???: {e}")
                                ColorPrinter.print_info(f"?????: {len(result_data[col])}")
                                ColorPrinter.print_info(f"??????: {len(processed_data[col])}")
                    return result_data
            return data
        
        elif tool_name == 'normalized_preprocessing':
            # ??????get??????????????processor
            numeric_cols = data.select_dtypes(include=['number']).columns
            # ??select_dtypes???????????????
            feature_cols = [col for col in numeric_cols if col != self.data_label]
            if feature_cols:
                # ??processor????
                processed_data = processor(data[feature_cols])
                # ??????DataFrame
                if isinstance(processed_data, pd.DataFrame):
                    # ????????
                    for col in feature_cols:
                        if col in processed_data.columns:
                            data[col] = processed_data[col]
            return data
        
        else:
            ColorPrinter.print_error(f"??: ???preprocessing?? {tool_name}")
            return data
    
    def save_data(self):
        """
        ????????
        """
        save_dir = os.path.dirname(self.save_path)
        if save_dir and not os.path.exists(save_dir):
            os.makedirs(save_dir)
        
        self.data.to_csv(self.save_path, index=False)
        ColorPrinter.print_success(f"\n??????: {self.save_path}")
        ColorPrinter.print_info(f"????: {self.data.shape}")
        ColorPrinter.print_info(f"????: {len(self.data.columns)}")
    
    def _intelligent_sorting(self, clean_tools):
        """
        ???????????????????
        
        Args:
            clean_tools (dict): ??????
            
        Returns:
            dict: ??????????
        """
        # ??????
        data_analysis = {
            'has_nan': self.data.isnull().any().any(),
            'has_outliers': False,  # ????????????????
            'has_text': any(self.data.dtypes == 'object'),
            'has_time': False,  # ???????????????
            'needs_sampling': len(self.data) > 10000,  # ????
        }
        
        # ??????????
        intelligent_order = []
        
        # 1. ???????
        if data_analysis['has_nan'] and 'nan_preprocessing' in clean_tools:
            intelligent_order.append('nan_preprocessing')
        
        # 2. ?????
        if data_analysis['has_outliers'] and 'outlier_preprocessing' in clean_tools:
            intelligent_order.append('outlier_preprocessing')
        
        # 3. ??????
        if data_analysis['has_text'] and 'str_preprocessing' in clean_tools:
            intelligent_order.append('str_preprocessing')
        
        # 4. ??????
        if data_analysis['has_time'] and 'time_preprocessing' in clean_tools:
            intelligent_order.append('time_preprocessing')
        
        # 5. ????
        if 'relative_preprocessing' in clean_tools:
            intelligent_order.append('relative_preprocessing')
        
        # 6. ????
        if 'specify_preprocessing' in clean_tools:
            intelligent_order.append('specify_preprocessing')
        
        # 7. ????????????
        if data_analysis['needs_sampling'] and 'sample_preprocessing' in clean_tools:
            intelligent_order.append('sample_preprocessing')
        
        # 8. ?????????
        if 'standard_preprocessing' in clean_tools:
            intelligent_order.append('standard_preprocessing')
        if 'normalized_preprocessing' in clean_tools:
            intelligent_order.append('normalized_preprocessing')
        
        # ????????
        sorted_dict = {}
        for tool_name in intelligent_order:
            if tool_name in clean_tools:
                sorted_dict[tool_name] = clean_tools[tool_name]
        
        # ???????
        for tool_name in clean_tools:
            if tool_name not in sorted_dict:
                sorted_dict[tool_name] = clean_tools[tool_name]
        
        ColorPrinter.print_warning(f"??????: {list(sorted_dict.keys())}")
        return sorted_dict
    
    def _assess_data_quality(self, data, stage):
        """
        ??????
        
        Args:
            data (DataFrame): ??????
            stage (str): ???? (initial, final)
        """
        metrics = self._calculate_quality_metrics(data)
        self.quality_metrics[stage] = metrics
        
        if self.enable_visualization:
            ColorPrinter.print_info(f"\n{stage} ??????:")
            for key, value in metrics.items():
                ColorPrinter.print_info(f"  - {key}: {value:.4f}")
    
    def _calculate_quality_metrics(self, data):
        """
        ????????
        
        Args:
            data (DataFrame): ????????
            
        Returns:
            dict: ??????
        """
        metrics = {}
        
        # ???????
        total_cells = data.size
        missing_cells = data.isnull().sum().sum()
        metrics['missing_value_ratio'] = missing_cells / total_cells if total_cells > 0 else 0
        
        # ?????????
        unique_dtypes = len(data.dtypes.unique())
        metrics['dtype_diversity'] = unique_dtypes / len(data.columns) if len(data.columns) > 0 else 0
        
        # ?????????
        numeric_cols = data.select_dtypes(include=['number']).columns
        if len(numeric_cols) > 0:
            variances = data[numeric_cols].var()
            metrics['mean_variance'] = variances.mean() if len(variances) > 0 else 0
        else:
            metrics['mean_variance'] = 0
        
        # ??????
        metrics['feature_count'] = len(data.columns)
        
        return metrics
    
    def _generate_processing_report(self, start_time):
        """
        ??????
        
        Args:
            start_time (float): ??????
        """
        total_time = time.time() - start_time
        
        ColorPrinter.print_info("\n" + "=" * 80)
        ColorPrinter.print_info("? ????")
        ColorPrinter.print_info("=" * 80)
        ColorPrinter.print_info(f"?????: {total_time:.2f} ?")
        ColorPrinter.print_info(f"???????: {len(self.processing_history)}")
        
        if self.processing_history:
            ColorPrinter.print_info("\n??????:")
            for item in self.processing_history:
                tool_name = item['tool']
                exec_time = item['execution_time']
                ColorPrinter.print_info(f"  - {tool_name}: {exec_time:.2f} ?")
                if 'quality_change' in item:
                    ColorPrinter.print_info("    ????:")
                    for key, value in item['quality_change'].items():
                        if value != 0:
                            ColorPrinter.print_info(f"      {key}: {value:+.4f}")
        
        if self.quality_metrics:
            ColorPrinter.print_info("\n??????:")
            initial_metrics = self.quality_metrics.get('initial', {})
            final_metrics = self.quality_metrics.get('final', {})
            for key in set(initial_metrics.keys()) | set(final_metrics.keys()):
                initial_val = initial_metrics.get(key, 0)
                final_val = final_metrics.get(key, 0)
                change = final_val - initial_val
                ColorPrinter.print_info(f"  - {key}: {initial_val:.4f} ? {final_val:.4f} ({change:+.4f})")
        
        # ???????
        report_path = os.path.join(os.path.dirname(self.save_path), f"processing_report_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json")
        report_data = {
            'total_time': total_time,
            'tools_executed': len(self.processing_history),
            'processing_history': self.processing_history,
            'quality_metrics': self.quality_metrics,
            'data_shape': list(self.data.shape),
            'feature_count': len(self.data.columns)
        }
        
        with open(report_path, 'w', encoding='utf-8') as f:
            json.dump(report_data, f, ensure_ascii=False, indent=2)
        
        ColorPrinter.print_info(f"??????: {report_path}")
        ColorPrinter.print_info("=" * 80 + "\n")


def main():
    """
    ???????????
    """
    import argparse
    import pandas as pd
    
    parser = argparse.ArgumentParser(description='FFE v3.2 Feature Engineering Console')
    parser.add_argument('--data', type=str, required=True, help='Path to input CSV file')
    parser.add_argument('--label', type=str, required=True, help='Label column name')
    parser.add_argument('--output', type=str, default='./clean_data/data00.csv', help='Output file path')
    parser.add_argument('--ways', type=str, default='auto', choices=['auto', 'intelligent', 'pass'], help='Processing way')
    parser.add_argument('--batch-size', type=int, default=None, help='Batch size for large data processing')
    
    args = parser.parse_args()
    
    # ????
    ColorPrinter.print_info(f"????: {args.data}")
    data = pd.read_csv(args.data)
    ColorPrinter.print_success(f"OK ?????????: {data.shape}")
    
    # ????
    try:
        from MFM.FFE.FFEv3_2.preprocessing.nan_preprocessing import nan_preprocessing_switch
        from MFM.FFE.FFEv3_2.preprocessing.outlier_preprocessing import outlier_preprocessing
        from MFM.FFE.FFEv3_2.preprocessing.str_preprocessing import str_preprocessing
        from MFM.FFE.FFEv3_2.preprocessing.time_preprocessing import time_preprocessing
        from MFM.FFE.FFEv3_2.preprocessing.relative_preprocessing import relative_preprocessing
        from MFM.FFE.FFEv3_2.preprocessing.specify_preprocessing import specify_preprocessing
        from MFM.FFE.FFEv3_2.preprocessing.sample_preprocessing import sample_preprocessing
        from MFM.FFE.FFEv3_2.preprocessing.standard_preprocessing import standard_preprocessing
        from MFM.FFE.FFEv3_2.preprocessing.normalized_preprocessing import normalized_preprocessing
    except ImportError as e:
        ColorPrinter.print_error(f"???????: {e}")
        return
    
    # ??????
    clean_tools = {
        'nan_preprocessing': nan_preprocessing_switch,
        'outlier_preprocessing': outlier_preprocessing,
        'str_preprocessing': str_preprocessing,
        'time_preprocessing': time_preprocessing,
        'relative_preprocessing': relative_preprocessing,
        'specify_preprocessing': specify_preprocessing,
        'sample_preprocessing': sample_preprocessing,
        'standard_preprocessing': standard_preprocessing,
        'normalized_preprocessing': normalized_preprocessing
    }
    
    # ??????
    console = FFE_console(args.label, ways=args.ways, batch_size=args.batch_size)
    
    # ????
    console(clean_tools, data, save_path=args.output)
    
    ColorPrinter.print_success("FFE ?????")


if __name__ == "__main__":
    main()
