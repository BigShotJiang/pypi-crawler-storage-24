﻿import pandas as pd
import numpy as np

# 导入所需模块
import sys
import os

# 添加MFM目录到路径
current_dir = os.path.dirname(os.path.abspath(__file__))
# py_tools -> route -> FFEv3_2 -> FFE -> MFM -> 根目录
root_dir = os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(current_dir)))))
if root_dir not in sys.path:
    sys.path.append(root_dir)

from myffe.tools.交互式 import interactive
from myffe.tools.color_printer import ColorPrinter
from myffe.tools.len_match import len_match
from myffe.tools.param_utils import ensure_list, convert_to_list
from myffe.tools.visualize_route import visualize_route

def analyze_nan_distribution(data, auto_test=False):
    """分析数据的缺失值分布，为每列推荐适合的缺失值处理方法
    
    Args:
        data: pandas DataFrame，输入数据
        auto_test: bool，是否自动测试模式，默认为 False
    
    Returns:
        dict: 包含缺失值处理参数的字典，使用列名列表和处理方法列表的结构
    """
    nan_params = {
        'nan_missing_process_choice': [],
        'nan_processing_col': [],
        'drop_threshold': 0.5,
        'knn_n_neighbors': 5
    }

    nan_missing_process_choice = ['drop_col_high_missing', 'fill_nan_knn', 'fill_nan_mean', 'fill_nan_mode', 'fill_nan_forward', 'fill_nan_intelligent', '随机填充','skip']
    # 计算每列的缺失值比例
    nan_ratio = data.isnull().mean() # 计算每列的缺失值比例
    nan_columns = nan_ratio[nan_ratio > 0].index.tolist() # 筛选出缺失值比例大于0的列
    
    if not nan_columns:
        ColorPrinter.print_info("数据中没有缺失值")
        return 'skip'
    
    
    inter_nan = False
    if auto_test:
        print("\033[31m下面进行测试使用智能推荐\033[0m")
        inter_nan = True
    else:
        inter_nan_tem = interactive(['ok', 'no'] , title="智能推荐？", description="选择'ok'将自动为所有缺失值列推荐最佳处理方法，选择'no'需要手动选择", min_select=0, max_select=1).run()
        if not inter_nan_tem:
            ColorPrinter.print_info("跳过缺失值处理")
            return 'skip'
        inter_nan_tem = ensure_list(inter_nan_tem)
        if inter_nan_tem:
            inter_nan_tem = inter_nan_tem[0]
        if inter_nan_tem == 'ok':
            inter_nan = True
    
    if not inter_nan:
        while True:
            # 重置参数列表
            nan_params['nan_processing_col'] = []
            nan_params['nan_missing_process_choice'] = []
            
            selected_cols = interactive(nan_columns  , title="请按上下箭头选择，回车确认缺失值处理列,点击'm'键进行多选择", description="选择要处理的缺失值列，可以多选").run()
            # 确保返回值是列表

            nan_params['nan_processing_col'] = ensure_list(selected_cols)
            ColorPrinter.print_success('你已选择缺失值处理列：' + str(nan_params['nan_processing_col']))
            
            # 为每列选择处理方法
            for col in nan_params['nan_processing_col']:
                selected_method = interactive(nan_missing_process_choice, title=f"请按上下箭头选择，回车确认{col}的缺失值处理方法", description="drop_col_high_missing:删除缺失率高的列, fill_nan_knn:KNN填充, fill_nan_mean:均值填充, fill_nan_mode:众数填充, fill_nan_forward:前向填充, fill_nan_intelligent:智能填充, 随机填充:随机选择填充方式").run()
                # 确保返回值是单个字符串
                selected_method_list = ensure_list(selected_method)
                method = selected_method_list[0] if selected_method_list else selected_method
                if method == '随机填充':
                    from random import choice
                    method = choice(nan_missing_process_choice)
                nan_params['nan_missing_process_choice'].append(method)
                ColorPrinter.print_success(f'你已选择{col}的缺失值处理方法：{method}')
            
            # 检查列数量和方法数量是否匹配
            if not len_match(nan_params['nan_processing_col'], nan_params['nan_missing_process_choice']):
                ColorPrinter.print_warning('请重新选择处理方法')
                continue
            
            # 选择额外参数
            if 'drop_col_high_missing' in nan_params['nan_missing_process_choice']:
                threshold_options = ['0.3', '0.4', '0.5', '0.6', '0.7']
                selected_threshold = interactive(threshold_options, title="请按上下箭头选择，回车确认高缺失值列删除阈值", description="设置列的缺失值比例阈值，超过此比例的列将被删除").run()
                # 确保返回值是单个值
                selected_threshold_list = ensure_list(selected_threshold)
                nan_params['drop_threshold'] = float(selected_threshold_list[0] if selected_threshold_list else selected_threshold)
                ColorPrinter.print_success('你已选择高缺失值列删除阈值：' + str(nan_params['drop_threshold']))
            
            if 'fill_nan_knn' in nan_params['nan_missing_process_choice']:
                knn_options = ['3', '5', '7', '9', '11', '13', '自定义']
                selected_knn = interactive(knn_options, title="请按上下箭头选择，回车确认KNN填充的邻居数", description="设置KNN填充的邻居数量，选择'自定义'可输入任意值").run()
                # 确保返回值是单个值
                selected_knn_list = ensure_list(selected_knn)
                tem_knn = selected_knn_list[0] if selected_knn_list else selected_knn
                if tem_knn == '自定义':
                    from MFM.TOOLS_dir.TOOL import Tools
                    nan_params['knn_n_neighbors'] = Tools.ok_input('int', min_value=1, max_value=50)
                else:
                    nan_params['knn_n_neighbors'] = int(tem_knn)
                ColorPrinter.print_success('你已选择KNN填充的邻居数：' + str(nan_params['knn_n_neighbors']))
            
            break
    else:
        # 只分析确实有缺失值的列
        for col in nan_columns:
            col_nan_ratio = nan_ratio[col]
            # 检查是否需要删除高缺失值列
            if col_nan_ratio > 0.5:
                if 'drop_col_high_missing' not in nan_params['nan_missing_process_choice']:
                    nan_params['nan_missing_process_choice'].append('drop_col_high_missing')
                nan_params['nan_processing_col'].append(col)
            
            # 根据列的数据类型和缺失值比例推荐填充方法
            elif col_nan_ratio > 0:
                nan_params['nan_processing_col'].append(col)
                if pd.api.types.is_numeric_dtype(data[col]):
                    if col_nan_ratio > 0.1: #当数值列缺失值比例大于0.1时，建议使用KNN填充
                        nan_params['nan_missing_process_choice'].append('fill_nan_knn')
                    else:
                        nan_params['nan_missing_process_choice'].append('fill_nan_mean')
                elif pd.api.types.is_categorical_dtype(data[col]) or pd.api.types.is_object_dtype(data[col]):
                    #当分类列缺失值比例大于0.1时，建议使用众数填充
                    nan_params['nan_missing_process_choice'].append('fill_nan_mode')
                elif pd.api.types.is_datetime64_any_dtype(data[col]):
                    nan_params['nan_missing_process_choice'].append('fill_nan_forward')
                else:
                    nan_params['nan_missing_process_choice'].append('fill_nan_intelligent')
    
    result = {'nan_preprocessing': nan_params}
    visualize_route(result)
    return result

def nan_py(data, auto_test=False):
    """Python实现的缺失值处理分析
    
    Args:
        data: pandas DataFrame，输入数据
        drop_threshold: 缺失值比例阈值，默认为0.5
        auto_test: bool，是否自动测试模式，默认为 False
    
    Returns:
        dict: 包含缺失值处理参数的字典
    """
    
    return analyze_nan_distribution(data, auto_test=auto_test)
if __name__ == "__main__":
    # 测试代码
    import pandas as pd
    import numpy as np
    
    # 创建测试数据
    np.random.seed(42)
    data = pd.DataFrame({
        'numeric_col1': np.random.normal(100, 10, 20),
        'numeric_col2': np.random.normal(50, 5, 20),
        'categorical_col': np.random.choice(['A', 'B', 'C'], 20),
        'datetime_col': pd.date_range('2020-01-01', periods=20)
    })
    
    # 随机添加缺失值
    for col in data.columns:
        if col != 'datetime_col':
            mask = np.random.choice([True, False], size=20, p=[0.2, 0.8])
            data.loc[mask, col] = np.nan
    
    ColorPrinter.print_info("测试数据:")
    ColorPrinter.print_any(data.head(), color='white')
    ColorPrinter.print_any("\n缺失值统计:", color='blue')
    ColorPrinter.print_any(data.isnull().sum(), color='white')
    
    # 测试缺失值处理
    ColorPrinter.print_info("\n测试缺失值处理:")
    result = nan_py(data)
    ColorPrinter.print_success("处理结果:")
    ColorPrinter.print_any(result, color='white')


"""
这个文件输入一个data
输出一个字典
格式是：
{
    'nan_preprocessing': {
        'nan_missing_process_choice': [...], 在里面是每个列的缺失值处理方法列表
        'nan_processing_col': [...], 在里面是每个列的缺失值处理列名列表
        'drop_threshold': 0.5,
        'knn_n_neighbors': 5
    }
}

nan_missing_process_choice的取值有

    'drop_col_high_missing'   # 删除缺失值比例超过阈值的列
    'fill_nan_knn'   # 使用KNN填充缺失值
    'fill_nan_mean'   # 使用均值填充缺失值
    'fill_nan_mode'   # 使用众数填充缺失值
    'fill_nan_forward'   # 前向填充缺失值
    'fill_nan_intelligent'   # 智能填充缺失值
    'skip'   # 跳过缺失值处理
"""
