"""Named async query functions for all elfmem database operations."""

from __future__ import annotations

import hashlib
import json
import math
import uuid
from datetime import UTC, datetime
from typing import Any

import numpy as np
from sqlalchemy import Float, and_, cast, delete, func, or_, select, update
from sqlalchemy.dialects.sqlite import insert
from sqlalchemy.ext.asyncio import AsyncConnection

from elfmem.db.models import (
    block_outcomes,
    block_tags,
    blocks,
    co_retrieval_staging,
    contradictions,
    edges,
    frames,
    sessions,
    system_config,
)

# ── Helpers ───────────────────────────────────────────────────────────────────

def _now_iso() -> str:
    return datetime.now(UTC).isoformat()


def content_hash(content: str) -> str:
    """Compute content-addressable block ID: sha256(normalised_content)[:16].

    Normalisation: strip leading/trailing whitespace, lowercase.
    """
    normalised = content.strip().lower()
    return hashlib.sha256(normalised.encode("utf-8")).hexdigest()[:16]


def embedding_to_bytes(vec: np.ndarray) -> bytes:
    """Convert a numpy float32 vector to bytes for BLOB storage."""
    return vec.astype(np.float32).tobytes()


def bytes_to_embedding(data: bytes) -> np.ndarray:
    """Convert BLOB bytes back to a numpy float32 vector."""
    return np.frombuffer(data, dtype=np.float32)


# ── Block queries ─────────────────────────────────────────────────────────────

async def insert_block(
    conn: AsyncConnection,
    *,
    block_id: str,
    content: str,
    category: str,
    source: str,
    status: str = "inbox",
    confidence: float = 0.50,
    decay_lambda: float = 0.01,
    last_reinforced_at: float = 0.0,
) -> None:
    """Insert a new block. Raises IntegrityError if id already exists."""
    await conn.execute(
        insert(blocks).values(
            id=block_id,
            content=content,
            category=category,
            source=source,
            status=status,
            confidence=confidence,
            reinforcement_count=0,
            decay_lambda=decay_lambda,
            last_reinforced_at=last_reinforced_at,
            created_at=_now_iso(),
        )
    )


async def get_block(conn: AsyncConnection, block_id: str) -> dict[str, Any] | None:
    """Fetch a single block by id. Returns None if not found."""
    result = await conn.execute(select(blocks).where(blocks.c.id == block_id))
    row = result.mappings().first()
    return dict(row) if row is not None else None


async def block_exists(conn: AsyncConnection, block_id: str) -> bool:
    """Check if a block id exists (any status)."""
    result = await conn.execute(
        select(blocks.c.id).where(blocks.c.id == block_id).limit(1)
    )
    return result.first() is not None


async def get_active_blocks(
    conn: AsyncConnection,
    *,
    min_last_reinforced_at: float | None = None,
) -> list[dict[str, Any]]:
    """Fetch all active blocks, optionally filtered by recency cutoff."""
    stmt = select(blocks).where(blocks.c.status == "active")
    if min_last_reinforced_at is not None:
        stmt = stmt.where(blocks.c.last_reinforced_at > min_last_reinforced_at)
    result = await conn.execute(stmt)
    return [dict(row) for row in result.mappings()]


async def get_active_blocks_with_embeddings(
    conn: AsyncConnection,
    *,
    min_last_reinforced_at: float | None = None,
) -> list[dict[str, Any]]:
    """Fetch active blocks that have non-NULL embeddings."""
    stmt = select(blocks).where(
        and_(blocks.c.status == "active", blocks.c.embedding.is_not(None))
    )
    if min_last_reinforced_at is not None:
        stmt = stmt.where(blocks.c.last_reinforced_at > min_last_reinforced_at)
    result = await conn.execute(stmt)
    return [dict(row) for row in result.mappings()]


async def get_inbox_blocks(conn: AsyncConnection) -> list[dict[str, Any]]:
    """Fetch all blocks with status='inbox'. Used by consolidate()."""
    result = await conn.execute(select(blocks).where(blocks.c.status == "inbox"))
    return [dict(row) for row in result.mappings()]


async def get_inbox_count(conn: AsyncConnection) -> int:
    """Count of inbox blocks."""
    result = await conn.execute(
        select(func.count()).select_from(blocks).where(blocks.c.status == "inbox")
    )
    return result.scalar() or 0


async def get_block_counts(conn: AsyncConnection) -> dict[str, int]:
    """Return block counts grouped by status in a single query.

    Returns a dict with keys 'inbox', 'active', 'archived', each defaulting
    to 0 if no blocks of that status exist.
    """
    result = await conn.execute(
        select(blocks.c.status, func.count().label("n")).group_by(blocks.c.status)
    )
    counts: dict[str, int] = {"inbox": 0, "active": 0, "archived": 0}
    for row in result.mappings():
        status = row["status"]
        if status in counts:
            counts[status] = row["n"]
    return counts


async def update_block_status(
    conn: AsyncConnection,
    block_id: str,
    status: str,
    *,
    archive_reason: str | None = None,
) -> None:
    """Transition a block to a new status.

    When archiving, explicitly deletes related tags, edges, and contradictions
    since FK CASCADE only fires on physical DELETE, not on status UPDATE.
    """
    if status == "archived":
        await conn.execute(
            delete(block_tags).where(block_tags.c.block_id == block_id)
        )
        await conn.execute(
            delete(edges).where(
                or_(edges.c.from_id == block_id, edges.c.to_id == block_id)
            )
        )
        await conn.execute(
            delete(contradictions).where(
                or_(
                    contradictions.c.block_a_id == block_id,
                    contradictions.c.block_b_id == block_id,
                )
            )
        )
    values: dict[str, object] = {"status": status}
    if archive_reason is not None:
        values["archive_reason"] = archive_reason
    await conn.execute(update(blocks).where(blocks.c.id == block_id).values(**values))


async def update_block_scoring(
    conn: AsyncConnection,
    block_id: str,
    *,
    confidence: float | None = None,
    self_alignment: float | None = None,
    decay_lambda: float | None = None,
    embedding: np.ndarray | None = None,
    embedding_model: str | None = None,
    token_count: int | None = None,
    summary: str | None = None,
) -> None:
    """Update scoring-related fields after consolidation (partial update).

    Only updates fields that are not None.
    """
    values: dict[str, object] = {}
    if confidence is not None:
        values["confidence"] = confidence
    if self_alignment is not None:
        values["self_alignment"] = self_alignment
    if decay_lambda is not None:
        values["decay_lambda"] = decay_lambda
    if embedding is not None:
        values["embedding"] = embedding_to_bytes(embedding)
    if embedding_model is not None:
        values["embedding_model"] = embedding_model
    if token_count is not None:
        values["token_count"] = token_count
    if summary is not None:
        values["summary"] = summary
    if values:
        await conn.execute(
            update(blocks).where(blocks.c.id == block_id).values(**values)
        )


async def update_block_outcome(
    conn: AsyncConnection,
    *,
    block_id: str,
    new_confidence: float,
    new_outcome_evidence: float,
) -> None:
    """Update a block's confidence and outcome_evidence after a Bayesian update."""
    await conn.execute(
        update(blocks)
        .where(blocks.c.id == block_id)
        .values(confidence=new_confidence, outcome_evidence=new_outcome_evidence)
    )


async def insert_block_outcome(
    conn: AsyncConnection,
    *,
    block_id: str,
    signal: float,
    weight: float,
    source: str,
    confidence_before: float,
    confidence_after: float,
) -> None:
    """Append an outcome audit record to block_outcomes."""
    await conn.execute(
        insert(block_outcomes).values(
            id=uuid.uuid4().hex,
            block_id=block_id,
            signal=signal,
            weight=weight,
            source=source,
            confidence_before=confidence_before,
            confidence_after=confidence_after,
            created_at=_now_iso(),
        )
    )


async def reinforce_blocks(
    conn: AsyncConnection,
    block_ids: list[str],
    current_active_hours: float,
) -> None:
    """Reinforce a set of blocks: increment count, update last_reinforced_at."""
    await conn.execute(
        update(blocks)
        .where(blocks.c.id.in_(block_ids))
        .values(
            reinforcement_count=blocks.c.reinforcement_count + 1,
            last_reinforced_at=current_active_hours,
        )
    )


# DURABLE λ=0.001, PERMANENT λ=0.00001 — both at or below this floor are protected.
_DURABLE_LAMBDA_THRESHOLD: float = 0.001


async def accelerate_block_decay(
    conn: AsyncConnection,
    block_ids: list[str],
    penalty_factor: float,
    lambda_ceiling: float,
) -> list[tuple[str, float, float]]:
    """Multiply decay_lambda by penalty_factor for STANDARD/EPHEMERAL tier blocks.

    Skips non-active blocks and DURABLE/PERMANENT tier blocks
    (decay_lambda <= 0.001).

    Returns list of (block_id, lambda_before, lambda_after) for audit.
    """
    audit: list[tuple[str, float, float]] = []
    for block_id in block_ids:
        block = await get_block(conn, block_id)
        if block is None or block["status"] != "active":
            continue
        current_lambda = float(block["decay_lambda"])
        if current_lambda <= _DURABLE_LAMBDA_THRESHOLD:
            continue  # DURABLE or PERMANENT — protected
        new_lambda = min(current_lambda * penalty_factor, lambda_ceiling)
        await update_block_scoring(conn, block_id, decay_lambda=new_lambda)
        audit.append((block_id, current_lambda, new_lambda))
    return audit


# ── Tag queries ───────────────────────────────────────────────────────────────

async def add_tags(
    conn: AsyncConnection,
    block_id: str,
    tags: list[str],
) -> None:
    """Add tags to a block. Silently ignores duplicates (INSERT OR IGNORE)."""
    for tag in tags:
        stmt = insert(block_tags).values(block_id=block_id, tag=tag)
        await conn.execute(stmt.on_conflict_do_nothing())


async def get_tags(conn: AsyncConnection, block_id: str) -> list[str]:
    """Get all tags for a block, sorted alphabetically."""
    result = await conn.execute(
        select(block_tags.c.tag)
        .where(block_tags.c.block_id == block_id)
        .order_by(block_tags.c.tag)
    )
    return [row[0] for row in result]


async def get_tags_batch(
    conn: AsyncConnection,
    block_ids: list[str],
) -> dict[str, list[str]]:
    """Fetch tags for multiple blocks in a single query.

    Returns {block_id: [tags_sorted_alphabetically]}.
    Block IDs with no tags map to []. Safe with empty input.
    """
    if not block_ids:
        return {}
    result = await conn.execute(
        select(block_tags.c.block_id, block_tags.c.tag)
        .where(block_tags.c.block_id.in_(block_ids))
        .order_by(block_tags.c.block_id, block_tags.c.tag)
    )
    tags_map: dict[str, list[str]] = {bid: [] for bid in block_ids}
    for row in result.mappings():
        tags_map[row["block_id"]].append(row["tag"])
    return tags_map


async def get_blocks_by_tag_pattern(
    conn: AsyncConnection,
    pattern: str,
) -> list[str]:
    """Get block IDs matching a tag pattern (SQL LIKE). Example: 'self/%'."""
    result = await conn.execute(
        select(block_tags.c.block_id)
        .where(block_tags.c.tag.like(pattern))
        .distinct()
        .order_by(block_tags.c.block_id)
    )
    return [row[0] for row in result]


async def remove_tags(
    conn: AsyncConnection,
    block_id: str,
    tags: list[str],
) -> None:
    """Remove specific tags from a block."""
    await conn.execute(
        delete(block_tags).where(
            and_(block_tags.c.block_id == block_id, block_tags.c.tag.in_(tags))
        )
    )


# ── Edge queries ──────────────────────────────────────────────────────────────

async def insert_edge(
    conn: AsyncConnection,
    *,
    from_id: str,
    to_id: str,
    weight: float,
    relation_type: str = "similar",
    origin: str = "similarity",
    last_active_hours: float | None = None,
    note: str | None = None,
) -> None:
    """Insert a similarity edge idempotently. from_id < to_id enforced by caller."""
    await conn.execute(
        insert(edges).prefix_with("OR IGNORE").values(
            from_id=from_id,
            to_id=to_id,
            weight=weight,
            reinforcement_count=0,
            created_at=_now_iso(),
            relation_type=relation_type,
            origin=origin,
            last_active_hours=last_active_hours,
            note=note,
        )
    )


async def upsert_outcome_edge(
    conn: AsyncConnection,
    *,
    from_id: str,
    to_id: str,
    weight: float,
    last_active_hours: float | None = None,
    note: str | None = None,
) -> bool:
    """Create an outcome-driven edge, or reinforce it if one already exists.

    Uses SQLite INSERT OR IGNORE so no exception handling is needed.
    Enforces canonical ordering (from_id < to_id) — callers must guarantee this.

    Returns True if a new edge was created, False if an existing edge was reinforced.
    """
    if from_id == to_id:
        return False  # No self-loops

    result = await conn.execute(
        insert(edges).prefix_with("OR IGNORE").values(
            from_id=from_id,
            to_id=to_id,
            weight=weight,
            reinforcement_count=0,
            created_at=_now_iso(),
            relation_type="outcome",
            origin="outcome",
            last_active_hours=last_active_hours,
            note=note,
        )
    )
    if result.rowcount == 1:
        return True  # new edge created

    # Edge already exists — reinforce it and refresh the activity clock.
    # Critical: last_active_hours must be updated on re-confirmation so temporal
    # decay measures from the last outcome signal, not from edge creation.
    values: dict[str, Any] = {"reinforcement_count": edges.c.reinforcement_count + 1}
    if last_active_hours is not None:
        values["last_active_hours"] = last_active_hours
    await conn.execute(
        update(edges)
        .where(and_(edges.c.from_id == from_id, edges.c.to_id == to_id))
        .values(**values)
    )
    return False


async def get_edges_for_block(conn: AsyncConnection, block_id: str) -> list[dict[str, Any]]:
    """Get all edges where block_id is either endpoint."""
    result = await conn.execute(
        select(edges).where(
            or_(edges.c.from_id == block_id, edges.c.to_id == block_id)
        )
    )
    return [dict(row) for row in result.mappings()]


async def get_edges(conn: AsyncConnection, block_id: str) -> list[dict[str, Any]]:
    """Alias for get_edges_for_block."""
    return await get_edges_for_block(conn, block_id)


async def get_archived_blocks(conn: AsyncConnection) -> list[dict[str, Any]]:
    """Fetch all blocks with status='archived'."""
    result = await conn.execute(select(blocks).where(blocks.c.status == "archived"))
    return [dict(row) for row in result.mappings()]


async def prune_weak_edges(conn: AsyncConnection, threshold: float) -> int:
    """Delete edges that are both geometrically weak AND never co-retrieved.

    An edge with reinforcement_count > 0 has proven real-world value and is
    spared regardless of its initial similarity weight. This protects outcome-
    driven edges (which start with lower weight than similarity-based ones) from
    being pruned before they accumulate evidence of usefulness.
    """
    result = await conn.execute(
        delete(edges).where(
            and_(
                edges.c.weight < threshold,
                edges.c.reinforcement_count == 0,
            )
        )
    )
    return result.rowcount or 0


async def get_neighbours(conn: AsyncConnection, block_ids: list[str]) -> list[str]:
    """Get 1-hop neighbour block IDs for seed blocks, excluding seeds themselves."""
    from_result = await conn.execute(
        select(edges.c.to_id.label("neighbour")).where(edges.c.from_id.in_(block_ids))
    )
    to_result = await conn.execute(
        select(edges.c.from_id.label("neighbour")).where(edges.c.to_id.in_(block_ids))
    )
    seed_set = set(block_ids)
    neighbours = {row[0] for row in from_result} | {row[0] for row in to_result}
    return list(neighbours - seed_set)


async def reinforce_edges(
    conn: AsyncConnection,
    edge_pairs: list[tuple[str, str]],
    current_active_hours: float | None = None,
) -> None:
    """Reinforce co-retrieval edges: increment reinforcement_count and update last_active_hours."""
    for from_id, to_id in edge_pairs:
        values: dict[str, Any] = {"reinforcement_count": edges.c.reinforcement_count + 1}
        if current_active_hours is not None:
            values["last_active_hours"] = current_active_hours
        await conn.execute(
            update(edges)
            .where(and_(edges.c.from_id == from_id, edges.c.to_id == to_id))
            .values(**values)
        )


async def get_edge(
    conn: AsyncConnection,
    from_id: str,
    to_id: str,
) -> dict[str, Any] | None:
    """Fetch a single edge by canonical pair. Returns None if not found."""
    result = await conn.execute(
        select(edges).where(
            and_(edges.c.from_id == from_id, edges.c.to_id == to_id)
        )
    )
    row = result.mappings().first()
    return dict(row) if row else None


async def insert_agent_edge(
    conn: AsyncConnection,
    *,
    from_id: str,
    to_id: str,
    weight: float,
    relation_type: str,
    note: str | None,
    current_active_hours: float | None,
) -> None:
    """Insert an agent-asserted edge. from_id < to_id enforced by caller.

    Always inserts — caller must check existence and handle if_exists logic first.
    """
    await conn.execute(
        insert(edges).values(
            from_id=from_id,
            to_id=to_id,
            weight=weight,
            reinforcement_count=0,
            created_at=_now_iso(),
            relation_type=relation_type,
            origin="agent",
            last_active_hours=current_active_hours,
            note=note,
        )
    )


async def update_edge(
    conn: AsyncConnection,
    *,
    from_id: str,
    to_id: str,
    relation_type: str | None = None,
    weight: float | None = None,
    note: str | None = None,
    reinforce_delta: float | None = None,
    current_active_hours: float | None = None,
) -> None:
    """Update fields on an existing edge. Only non-None fields are changed.

    When reinforce_delta is provided, fetches the current weight and applies
    asymptotic capping (never exceeds 1.0). This is mutually exclusive with
    weight — set one or the other.
    """
    values: dict[str, Any] = {}
    if relation_type is not None:
        values["relation_type"] = relation_type
    if note is not None:
        values["note"] = note
    if weight is not None:
        values["weight"] = weight
    if reinforce_delta is not None:
        # Python-side asymptotic cap: fetch current weight, clamp to 1.0
        row = await conn.execute(
            select(edges.c.weight).where(
                and_(edges.c.from_id == from_id, edges.c.to_id == to_id)
            )
        )
        current = row.scalar()
        if current is not None:
            values["weight"] = min(float(current) + reinforce_delta, 1.0)
    if current_active_hours is not None:
        values["last_active_hours"] = current_active_hours
    if not values:
        return
    await conn.execute(
        update(edges)
        .where(and_(edges.c.from_id == from_id, edges.c.to_id == to_id))
        .values(**values)
    )


async def delete_edge(
    conn: AsyncConnection,
    from_id: str,
    to_id: str,
) -> bool:
    """Delete an edge by canonical pair. Returns True if deleted, False if not found."""
    result = await conn.execute(
        delete(edges).where(
            and_(edges.c.from_id == from_id, edges.c.to_id == to_id)
        )
    )
    return (result.rowcount or 0) > 0


async def get_all_edges(conn: AsyncConnection) -> list[dict[str, Any]]:
    """Fetch all edges in the graph. Used by curate() for temporal decay pruning."""
    result = await conn.execute(select(edges))
    return [dict(row) for row in result.mappings()]


async def count_edges(conn: AsyncConnection) -> int:
    """Count total edges currently in the graph."""
    result = await conn.execute(select(func.count()).select_from(edges))
    return result.scalar() or 0


async def delete_edges_bulk(
    conn: AsyncConnection,
    pairs: list[tuple[str, str]],
) -> int:
    """Delete edges by canonical (from_id, to_id) pairs. Returns count deleted."""
    if not pairs:
        return 0
    count = 0
    for from_id, to_id in pairs:
        result = await conn.execute(
            delete(edges).where(
                and_(edges.c.from_id == from_id, edges.c.to_id == to_id)
            )
        )
        count += result.rowcount or 0
    return count


# Reinforcement bonus per log unit of co-retrieval count.
# Effective weight = weight + log(1 + reinforcement_count) × BONUS
# Rationale: edges proven useful through repeated co-retrieval should
# contribute more to centrality than edges never used after creation.
# At reinforcement_count=10: bonus ≈ 0.24. At count=100: bonus ≈ 0.46.
_REINFORCE_WEIGHT_BONUS = 0.10


async def get_weighted_degree(
    conn: AsyncConnection,
    block_ids: list[str],
) -> dict[str, float]:
    """Compute effective weighted degree for a set of blocks.

    effective_weight(edge) = weight + log(1 + reinforcement_count) × BONUS

    Edges frequently co-retrieved contribute more to centrality, making
    graph expansion prefer blocks with proven real-world connectivity over
    blocks with only geometric (similarity-based) connections.

    Returns {block_id: total_effective_weight}. Blocks with no edges return 0.0.
    """
    if not block_ids:
        return {}

    degrees: dict[str, float] = {bid: 0.0 for bid in block_ids}
    id_set = set(block_ids)

    result = await conn.execute(
        select(
            edges.c.from_id,
            edges.c.to_id,
            edges.c.weight,
            edges.c.reinforcement_count,
        ).where(
            or_(edges.c.from_id.in_(block_ids), edges.c.to_id.in_(block_ids))
        )
    )
    for row in result.mappings():
        eff = (
            float(row["weight"])
            + math.log1p(row["reinforcement_count"]) * _REINFORCE_WEIGHT_BONUS
        )
        if row["from_id"] in id_set:
            degrees[row["from_id"]] += eff
        if row["to_id"] in id_set:
            degrees[row["to_id"]] += eff
    return degrees


# ── Contradiction queries ─────────────────────────────────────────────────────

async def insert_contradiction(
    conn: AsyncConnection,
    *,
    block_a_id: str,
    block_b_id: str,
    score: float,
) -> None:
    """Insert a contradiction record."""
    await conn.execute(
        insert(contradictions).values(
            block_a_id=block_a_id,
            block_b_id=block_b_id,
            score=score,
            resolved=0,
            created_at=_now_iso(),
        )
    )


async def get_contradictions_for_blocks(
    conn: AsyncConnection,
    block_ids: list[str],
) -> list[dict[str, Any]]:
    """Get unresolved contradictions involving any of the given block IDs."""
    result = await conn.execute(
        select(contradictions).where(
            and_(
                contradictions.c.resolved == 0,
                or_(
                    contradictions.c.block_a_id.in_(block_ids),
                    contradictions.c.block_b_id.in_(block_ids),
                ),
            )
        )
    )
    return [dict(row) for row in result.mappings()]


async def resolve_contradiction(
    conn: AsyncConnection,
    block_a_id: str,
    block_b_id: str,
) -> None:
    """Mark a contradiction as resolved."""
    await conn.execute(
        update(contradictions)
        .where(
            and_(
                contradictions.c.block_a_id == block_a_id,
                contradictions.c.block_b_id == block_b_id,
            )
        )
        .values(resolved=1)
    )


# ── Frame queries ─────────────────────────────────────────────────────────────

async def get_frame(conn: AsyncConnection, name: str) -> dict[str, Any] | None:
    """Fetch a frame definition by name. Returns None if not found."""
    result = await conn.execute(select(frames).where(frames.c.name == name))
    row = result.mappings().first()
    return dict(row) if row is not None else None


async def upsert_frame(
    conn: AsyncConnection,
    *,
    name: str,
    weights_json: str,
    filters_json: str,
    guarantees_json: str,
    template: str,
    token_budget: int,
    cache_json: str | None,
    source: str,
) -> None:
    """Insert or update a frame definition."""
    stmt = insert(frames).values(
        name=name,
        weights_json=weights_json,
        filters_json=filters_json,
        guarantees_json=guarantees_json,
        template=template,
        token_budget=token_budget,
        cache_json=cache_json,
        source=source,
        created_at=_now_iso(),
    )
    await conn.execute(
        stmt.on_conflict_do_update(
            index_elements=["name"],
            set_={
                "weights_json": weights_json,
                "filters_json": filters_json,
                "guarantees_json": guarantees_json,
                "template": template,
                "token_budget": token_budget,
                "cache_json": cache_json,
                "source": source,
            },
        )
    )


async def list_frames(conn: AsyncConnection) -> list[dict[str, Any]]:
    """List all frame definitions."""
    result = await conn.execute(select(frames).order_by(frames.c.name))
    return [dict(row) for row in result.mappings()]


# ── Session queries ───────────────────────────────────────────────────────────

async def start_session(
    conn: AsyncConnection,
    *,
    session_id: str,
    task_type: str,
    start_active_hours: float,
) -> None:
    """Record a new session start."""
    await conn.execute(
        insert(sessions).values(
            id=session_id,
            task_type=task_type,
            started_at=_now_iso(),
            start_active_hours=start_active_hours,
        )
    )


async def end_session(conn: AsyncConnection, session_id: str) -> None:
    """Record session end time."""
    await conn.execute(
        update(sessions)
        .where(sessions.c.id == session_id)
        .values(ended_at=_now_iso())
    )


async def get_active_session(conn: AsyncConnection) -> dict[str, Any] | None:
    """Get the currently active session (ended_at IS NULL)."""
    result = await conn.execute(
        select(sessions)
        .where(sessions.c.ended_at.is_(None))
        .order_by(sessions.c.started_at.desc())
        .limit(1)
    )
    row = result.mappings().first()
    return dict(row) if row is not None else None


# ── System config queries ─────────────────────────────────────────────────────

async def get_config(conn: AsyncConnection, key: str) -> str | None:
    """Get a system config value by key. Returns None if not found."""
    result = await conn.execute(
        select(system_config.c.value).where(system_config.c.key == key)
    )
    row = result.first()
    return row[0] if row is not None else None


async def set_config(conn: AsyncConnection, key: str, value: str) -> None:
    """Set a system config value (upsert)."""
    stmt = insert(system_config).values(key=key, value=value)
    await conn.execute(
        stmt.on_conflict_do_update(
            index_elements=["key"],
            set_={"value": value},
        )
    )


async def get_total_active_hours(conn: AsyncConnection) -> float:
    """Get the total_active_hours counter. Returns 0.0 if not set."""
    value = await get_config(conn, "total_active_hours")
    return float(value) if value is not None else 0.0


async def set_total_active_hours(conn: AsyncConnection, hours: float) -> None:
    """Update the total_active_hours counter."""
    await set_config(conn, "total_active_hours", str(hours))


async def increment_total_active_hours(conn: AsyncConnection, delta_hours: float) -> None:
    """Atomically increment total_active_hours by delta_hours.

    USE WHEN: Ending a session. Atomic SQL UPDATE prevents the lost-update race
    that occurs when two sessions end concurrently in a multi-process scenario.
    DON'T USE WHEN: Setting an absolute value — use set_total_active_hours() instead.
    COST: One SQL UPDATE (no prior read required).
    RETURNS: None.
    NEXT: Call after computing session duration to persist the active-hours clock.
    """
    await conn.execute(
        update(system_config)
        .where(system_config.c.key == "total_active_hours")
        .values(value=cast(system_config.c.value, Float) + delta_hours)
    )


# ── Co-retrieval staging ──────────────────────────────────────────────────────


async def upsert_co_retrieval_count(
    conn: AsyncConnection,
    pair: tuple[str, str],
    count: int,
) -> None:
    """Insert or update a co-retrieval staging count for a canonical pair.

    USE WHEN: Incrementing Hebbian staging after a co-retrieval event.
    DON'T USE WHEN: Promoting to edge — use delete_co_retrieval_pair() instead.
    COST: One SQL upsert.
    RETURNS: None.
    NEXT: Call delete_co_retrieval_pair() when count reaches the promotion threshold.
    """
    stmt = insert(co_retrieval_staging).values(
        from_id=pair[0], to_id=pair[1], count=count
    )
    await conn.execute(
        stmt.on_conflict_do_update(
            index_elements=["from_id", "to_id"],
            set_={"count": count},
        )
    )


async def load_co_retrieval_staging(
    conn: AsyncConnection,
) -> dict[tuple[str, str], int]:
    """Load all co-retrieval staging rows into an in-memory dict.

    USE WHEN: Restoring Hebbian staging on process startup.
    DON'T USE WHEN: Checking a single pair — read from the in-memory dict instead.
    COST: One full-table scan (table is typically small, capped at staging_max rows).
    RETURNS: Dict mapping (from_id, to_id) → count.
    NEXT: Assign the result to MemorySystem._co_retrieval_staging.
    """
    result = await conn.execute(select(co_retrieval_staging))
    return {
        (row["from_id"], row["to_id"]): row["count"]
        for row in result.mappings()
    }


async def delete_co_retrieval_pair(
    conn: AsyncConnection,
    pair: tuple[str, str],
) -> None:
    """Delete a co-retrieval staging row after the pair is promoted to an edge.

    USE WHEN: A pair reaches the promotion threshold and an edge is created.
    COST: One SQL DELETE.
    RETURNS: None.
    """
    await conn.execute(
        delete(co_retrieval_staging).where(
            and_(
                co_retrieval_staging.c.from_id == pair[0],
                co_retrieval_staging.c.to_id == pair[1],
            )
        )
    )


async def prune_stale_co_retrieval_staging(conn: AsyncConnection) -> int:
    """Delete staging rows where either block is no longer active.

    USE WHEN: After curate() archives blocks, to purge staging rows that can
    never be promoted (archived blocks are never retrieved).
    FK CASCADE handles rows pointing to physically-deleted blocks; this handles
    the normal archival case where the block row remains with status='archived'.
    COST: One SQL DELETE with two subselects.
    RETURNS: Number of rows deleted.
    NEXT: Call load_co_retrieval_staging() to refresh the in-memory dict.
    """
    active_ids = select(blocks.c.id).where(blocks.c.status == "active")
    result = await conn.execute(
        delete(co_retrieval_staging).where(
            or_(
                co_retrieval_staging.c.from_id.not_in(active_ids),
                co_retrieval_staging.c.to_id.not_in(active_ids),
            )
        )
    )
    return result.rowcount


# ── Seed data ─────────────────────────────────────────────────────────────────

_BUILTIN_FRAMES = [
    {
        "name": "self",
        "weights_json": json.dumps(
            {"similarity": 0.10, "confidence": 0.30, "recency": 0.05,
             "centrality": 0.25, "reinforcement": 0.30}
        ),
        "filters_json": json.dumps(
            {"tag_patterns": ["self/%"], "categories": [], "search_window": None}
        ),
        "guarantees_json": "[]",
        "template": "# SELF\n{blocks}",
        "token_budget": 500,
        "cache_json": None,
        "source": "builtin",
    },
    {
        "name": "attention",
        "weights_json": json.dumps(
            {"similarity": 0.35, "confidence": 0.15, "recency": 0.25,
             "centrality": 0.15, "reinforcement": 0.10}
        ),
        "filters_json": json.dumps(
            {"tag_patterns": [], "categories": [], "search_window": None}
        ),
        "guarantees_json": "[]",
        "template": "# ATTENTION\n{blocks}",
        "token_budget": 1000,
        "cache_json": None,
        "source": "builtin",
    },
    {
        "name": "task",
        "weights_json": json.dumps(
            {"similarity": 0.20, "confidence": 0.20, "recency": 0.20,
             "centrality": 0.20, "reinforcement": 0.20}
        ),
        "filters_json": json.dumps(
            {"tag_patterns": [], "categories": [], "search_window": None}
        ),
        "guarantees_json": "[]",
        "template": "# TASK\n{blocks}",
        "token_budget": 800,
        "cache_json": None,
        "source": "builtin",
    },
]

_BUILTIN_CONFIG = [
    ("total_active_hours", "0.0"),
    ("prune_threshold", "0.05"),
    ("top_k", "5"),
]


async def count_self_blocks(conn: AsyncConnection) -> int:
    """Count inbox+active blocks that carry any self/* tag.

    Used by ``elfmem doctor`` to check whether the SELF frame has been seeded.
    Counts both inbox (pending consolidation) and active blocks so that doctor
    reports correctly immediately after ``elfmem init --self`` runs.
    Returns 0 if no SELF blocks exist.
    """
    tagged_ids = await get_blocks_by_tag_pattern(conn, "self/%")
    if not tagged_ids:
        return 0
    result = await conn.execute(
        select(func.count())
        .select_from(blocks)
        .where(
            and_(
                blocks.c.id.in_(tagged_ids),
                blocks.c.status.in_(["inbox", "active"]),
            )
        )
    )
    return result.scalar() or 0


async def seed_builtin_data(conn: AsyncConnection) -> None:
    """Insert built-in frames and default system_config values.

    Idempotent — uses INSERT OR IGNORE. Safe to call multiple times.
    """
    now = _now_iso()
    for frame_data in _BUILTIN_FRAMES:
        stmt = insert(frames).values(**frame_data, created_at=now)
        await conn.execute(stmt.on_conflict_do_nothing())
    for key, value in _BUILTIN_CONFIG:
        stmt = insert(system_config).values(key=key, value=value)
        await conn.execute(stmt.on_conflict_do_nothing())
