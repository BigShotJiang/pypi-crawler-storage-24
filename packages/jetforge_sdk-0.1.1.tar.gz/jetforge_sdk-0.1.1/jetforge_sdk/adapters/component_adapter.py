"""
ForgeComponentAdapter — Adapter for ComponentPool integration.

Bridges ForgeClient with a ComponentPool implementation,
enabling automatic synchronization of Component capabilities.
"""

import logging
from typing import Any, Protocol

from ..forge_client import CapabilityMetadata, CapabilityType, ForgeClient

logger = logging.getLogger(__name__)


class ComponentPoolProtocol(Protocol):
    """Protocol defining expected ComponentPool interface."""

    def register_component(
        self,
        name: str,
        input_schema: dict[str, Any],
        output_schema: dict[str, Any],
        metadata: dict[str, Any] | None = None,
    ) -> None: ...

    def unregister_component(self, name: str) -> None: ...

    def get_component(self, name: str) -> Any | None: ...

    def list_components(self) -> list[str]: ...


class ForgeComponentAdapter:
    """
    Adapter to sync JetForge Component capabilities with a ComponentPool.

    Usage::

        client = ForgeClient(base_url="http://jetforge:8000")
        await client.initialize()

        adapter = ForgeComponentAdapter(client, component_pool)
        await adapter.sync_all()
        adapter.start_auto_sync()
    """

    def __init__(
        self,
        forge_client: ForgeClient,
        component_pool: ComponentPoolProtocol,
    ):
        self.client = forge_client
        self.pool = component_pool
        self._synced_components: set[str] = set()

    async def sync_all(self) -> int:
        """Sync all Component capabilities. Returns number synced."""
        components = await self.client.get_metadata_by_type(CapabilityType.COMPONENT)

        synced_count = 0
        current_ids = set()

        for component in components:
            current_ids.add(component.id)
            try:
                self._register_component(component)
                synced_count += 1
            except Exception as e:
                logger.error(f"Failed to sync component {component.name}: {e}")

        self._synced_components = current_ids
        logger.info(f"Synced {synced_count} components from JetForge")
        return synced_count

    def _register_component(self, capability: CapabilityMetadata) -> None:
        metadata = {
            "id": capability.id,
            "version": capability.version,
            "display_name": capability.display_name,
            "description": capability.description,
            "category": capability.category,
            "tags": capability.tags,
            "author": capability.author,
            "source": "jetforge",
        }
        self.pool.register_component(
            name=capability.name,
            input_schema=capability.input_schema or {},
            output_schema=capability.output_schema or {},
            metadata=metadata,
        )
        logger.debug(f"Registered component: {capability.name} v{capability.version}")

    def start_auto_sync(self) -> None:
        """Subscribe to ForgeClient updates for automatic sync."""
        self.client.on_capability_updated(self._handle_update)
        self.client.on_capability_deleted(self._handle_delete)
        logger.info("Component auto-sync enabled")

    def _handle_update(self, capability_id: str, metadata: CapabilityMetadata) -> None:
        if metadata.type != CapabilityType.COMPONENT:
            return
        try:
            self._register_component(metadata)
            self._synced_components.add(capability_id)
        except Exception as e:
            logger.error(f"Failed to update component {metadata.name}: {e}")

    def _handle_delete(self, capability_id: str) -> None:
        if capability_id in self._synced_components:
            self._synced_components.discard(capability_id)
            logger.info(f"Component {capability_id} removed")
