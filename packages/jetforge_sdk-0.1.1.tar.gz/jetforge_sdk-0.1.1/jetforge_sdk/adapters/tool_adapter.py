"""
ForgeToolAdapter — Adapter for ToolRegistry integration.

Bridges ForgeClient with a ToolRegistry implementation,
enabling automatic synchronization of Tool capabilities (MCP/OpenAPI).
"""

import logging
from typing import Any, Protocol

from ..forge_client import CapabilityMetadata, CapabilityType, ForgeClient

logger = logging.getLogger(__name__)


class ToolRegistryProtocol(Protocol):
    """Protocol defining expected ToolRegistry interface."""

    def register_tool(
        self,
        name: str,
        description: str,
        input_schema: dict[str, Any],
        config: dict[str, Any] | None = None,
        metadata: dict[str, Any] | None = None,
    ) -> None: ...

    def unregister_tool(self, name: str) -> None: ...

    def get_tool(self, name: str) -> Any | None: ...

    def list_tools(self) -> list[str]: ...


class ForgeToolAdapter:
    """
    Adapter to sync JetForge Tool capabilities with a ToolRegistry.

    Usage::

        client = ForgeClient(base_url="http://jetforge:8000")
        await client.initialize()

        adapter = ForgeToolAdapter(client, tool_registry)
        await adapter.sync_all()
        adapter.start_auto_sync()
    """

    def __init__(
        self,
        forge_client: ForgeClient,
        tool_registry: ToolRegistryProtocol,
    ):
        self.client = forge_client
        self.registry = tool_registry
        self._synced_tools: set[str] = set()

    async def sync_all(self) -> int:
        """Sync all Tool capabilities. Returns number synced."""
        tools = await self.client.get_metadata_by_type(CapabilityType.TOOL)

        synced_count = 0
        current_ids = set()

        for tool in tools:
            current_ids.add(tool.id)
            try:
                await self._register_tool(tool)
                synced_count += 1
            except Exception as e:
                logger.error(f"Failed to sync tool {tool.name}: {e}")

        self._synced_tools = current_ids
        logger.info(f"Synced {synced_count} tools from JetForge")
        return synced_count

    async def _register_tool(self, capability: CapabilityMetadata) -> None:
        config = None
        if capability.config_schema:
            try:
                response = await self.client._http_client.get(
                    f"/capabilities/{capability.id}/config"
                )
                if response.status_code == 200:
                    config = response.json().get("config")
            except Exception as e:
                logger.warning(f"Failed to fetch tool config: {e}")

        metadata = {
            "id": capability.id,
            "version": capability.version,
            "display_name": capability.display_name,
            "category": capability.category,
            "tags": capability.tags,
            "author": capability.author,
            "source": "jetforge",
            "config_schema": capability.config_schema,
        }

        self.registry.register_tool(
            name=capability.name,
            description=capability.description or "",
            input_schema=capability.input_schema or {},
            config=config,
            metadata=metadata,
        )
        logger.debug(f"Registered tool: {capability.name} v{capability.version}")

    def start_auto_sync(self) -> None:
        """Subscribe to ForgeClient updates for automatic sync."""
        self.client.on_capability_updated(self._handle_update)
        self.client.on_capability_deleted(self._handle_delete)
        logger.info("Tool auto-sync enabled")

    def _handle_update(self, capability_id: str, metadata: CapabilityMetadata) -> None:
        if metadata.type != CapabilityType.TOOL:
            return
        self._synced_tools.add(capability_id)
        logger.info(f"Tool {metadata.name} update received - manual sync required")

    def _handle_delete(self, capability_id: str) -> None:
        if capability_id in self._synced_tools:
            self._synced_tools.discard(capability_id)
            logger.info(f"Tool {capability_id} removed")
