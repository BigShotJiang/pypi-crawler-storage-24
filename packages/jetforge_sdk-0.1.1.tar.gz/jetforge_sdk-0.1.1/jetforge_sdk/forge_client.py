"""
ForgeClient SDK — JetForge Integration Client

Enables JetAgents (and other consumers) to:
- Discover and load capabilities from JetForge registry
- Cache capability metadata locally with TTL
- Receive real-time updates via WebSocket
- Gracefully degrade when JetForge is unavailable
"""

import asyncio
import json
import logging
from dataclasses import dataclass, field
from datetime import datetime, timedelta
from typing import Any, Callable
from enum import Enum

import httpx
import websockets
from websockets.exceptions import ConnectionClosed

logger = logging.getLogger(__name__)


class CapabilityType(str, Enum):
    """Capability type enumeration."""
    COMPONENT = "COMPONENT"
    TOOL = "TOOL"
    SKILL = "SKILL"


@dataclass
class CapabilityMetadata:
    """Capability metadata returned from registry."""
    id: str
    name: str
    version: str
    type: CapabilityType
    display_name: str | None = None
    description: str | None = None
    category: str | None = None
    tags: list[str] = field(default_factory=list)
    author: str | None = None
    status: str = "PUBLISHED"
    environment: str = "production"
    input_schema: dict[str, Any] | None = None
    output_schema: dict[str, Any] | None = None
    config_schema: dict[str, Any] | None = None
    skill_definition: str | None = None
    created_at: str | None = None
    updated_at: str | None = None

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "CapabilityMetadata":
        """Create CapabilityMetadata from dictionary."""
        return cls(
            id=data["id"],
            name=data["name"],
            version=data["version"],
            type=CapabilityType(data["type"]),
            display_name=data.get("display_name"),
            description=data.get("description"),
            category=data.get("category"),
            tags=data.get("tags") or [],
            author=data.get("author"),
            status=data.get("status", "PUBLISHED"),
            environment=data.get("environment", "production"),
            input_schema=data.get("input_schema"),
            output_schema=data.get("output_schema"),
            config_schema=data.get("config_schema"),
            skill_definition=data.get("skill_definition"),
            created_at=data.get("created_at"),
            updated_at=data.get("updated_at"),
        )


@dataclass
class PromptContent:
    """Prompt template content from JetForge."""
    id: str
    name: str
    template: str
    version: str = ""
    variables: list[str] = field(default_factory=list)
    metadata: dict[str, Any] = field(default_factory=dict)

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "PromptContent":
        return cls(
            id=data.get("id", ""),
            name=data.get("name", ""),
            template=data.get("system_prompt") or data.get("template") or "",
            version=data.get("version", ""),
            variables=[v.get("name", v) if isinstance(v, dict) else v for v in (data.get("variables") or [])],
            metadata=data.get("metadata") or {},
        )


@dataclass
class SkillFileInfo:
    """Metadata for a file within a Skill package."""
    path: str
    size: int = 0
    content_type: str = "text/plain"
    git_commit: str = ""

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "SkillFileInfo":
        return cls(
            path=data.get("path", data.get("name", "")),
            size=data.get("size", 0),
            content_type=data.get("content_type", "text/plain"),
            git_commit=data.get("git_commit", ""),
        )


@dataclass
class AgentConfigContent:
    """Agent configuration from JetForge, compatible with JetAgents AgentMeta."""
    id: str
    agent_id: str
    name: str
    type: str = ""
    description: str = ""
    version: str = ""
    meta_config: dict[str, Any] = field(default_factory=dict)
    git_commit: str = ""
    metadata: dict[str, Any] = field(default_factory=dict)

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "AgentConfigContent":
        return cls(
            id=str(data.get("id", "")),
            agent_id=data.get("agent_id", ""),
            name=data.get("name", ""),
            type=data.get("type", ""),
            description=data.get("description", ""),
            version=data.get("version", ""),
            meta_config=data.get("meta_config") or {},
            git_commit=data.get("git_commit", ""),
            metadata=data.get("metadata") or {},
        )

    def to_agent_meta_dict(self) -> dict[str, Any]:
        """Convert to JetAgents AgentMeta-compatible dict."""
        result = dict(self.meta_config) if self.meta_config else {}
        result.update({
            "id": self.id,
            "agent_id": self.agent_id,
            "name": self.name,
            "type": self.type,
            "description": self.description,
            "version": self.version,
        })
        return result


@dataclass
class CacheEntry:
    """Cache entry with TTL tracking."""
    data: Any
    expires_at: datetime

    def is_expired(self) -> bool:
        """Check if cache entry has expired."""
        return datetime.utcnow() > self.expires_at


class ForgeClient:
    """
    ForgeClient SDK for JetForge integration.

    Features:
    - Capability discovery and loading from JetForge registry
    - Local caching with configurable TTL
    - WebSocket-based real-time updates
    - Graceful degradation when JetForge is unavailable
    """

    def __init__(
        self,
        base_url: str,
        api_key: str | None = None,
        cache_ttl_seconds: int = 300,
        request_timeout: float = 30.0,
        environment: str = "production",
    ):
        self.base_url = base_url.rstrip("/")
        self.api_key = api_key
        self.cache_ttl = timedelta(seconds=cache_ttl_seconds)
        self.request_timeout = request_timeout
        self.environment = environment

        self._cache: dict[str, CacheEntry] = {}
        self._all_metadata_cache: CacheEntry | None = None

        self._ws_connection: websockets.WebSocketClientProtocol | None = None
        self._ws_task: asyncio.Task | None = None
        self._ws_reconnect_delay = 1.0
        self._ws_max_reconnect_delay = 60.0

        self._update_callbacks: list[Callable[[str, CapabilityMetadata], None]] = []
        self._delete_callbacks: list[Callable[[str], None]] = []
        self._prompt_updated_callbacks: list[Callable[[str, PromptContent], None]] = []
        self._prompt_deleted_callbacks: list[Callable[[str], None]] = []
        self._agent_config_updated_callbacks: list[Callable[[str, AgentConfigContent], None]] = []
        self._agent_config_deleted_callbacks: list[Callable[[str], None]] = []

        self._http_client: httpx.AsyncClient | None = None
        self._initialized = False

    async def initialize(self) -> None:
        """Initialize the client and verify connection."""
        if self._initialized:
            return

        self._http_client = httpx.AsyncClient(
            base_url=f"{self.base_url}/api/v1",
            timeout=self.request_timeout,
            headers=self._get_headers(),
        )

        try:
            async with httpx.AsyncClient(timeout=5.0) as raw:
                response = await raw.get(f"{self.base_url}/health")
                response.raise_for_status()
            logger.info(f"ForgeClient connected to {self.base_url}")
            self._initialized = True
        except Exception as e:
            logger.warning(f"JetForge not available: {e}. Client will use cached data.")
            self._initialized = True

    async def close(self) -> None:
        """Close the client and cleanup resources."""
        if self._ws_task:
            self._ws_task.cancel()
            try:
                await self._ws_task
            except asyncio.CancelledError:
                pass

        if self._ws_connection:
            await self._ws_connection.close()

        if self._http_client:
            await self._http_client.aclose()

        self._initialized = False

    def _get_headers(self) -> dict[str, str]:
        """Get HTTP headers including auth if configured."""
        headers = {
            "Content-Type": "application/json",
            "Accept": "application/json",
        }
        if self.api_key:
            headers["Authorization"] = f"Bearer {self.api_key}"
        return headers

    def _get_from_cache(self, key: str) -> Any | None:
        """Get value from cache if not expired."""
        entry = self._cache.get(key)
        if entry and not entry.is_expired():
            return entry.data
        return None

    def _set_cache(self, key: str, data: Any) -> None:
        """Set cache entry with TTL."""
        self._cache[key] = CacheEntry(
            data=data,
            expires_at=datetime.utcnow() + self.cache_ttl,
        )

    def _invalidate_cache(self, key: str | None = None) -> None:
        """Invalidate cache entry or entire cache."""
        if key:
            self._cache.pop(key, None)
        else:
            self._cache.clear()
            self._all_metadata_cache = None

    # =========================================================================
    # Capability Discovery APIs
    # =========================================================================

    async def get_all_metadata(
        self,
        capability_type: CapabilityType | None = None,
        force_refresh: bool = False,
    ) -> list[CapabilityMetadata]:
        """
        Get all published capability metadata from registry.

        AC-REG-001: All JetAgents instances receive identical capability sets
        """
        cache_key = f"all_metadata:{capability_type or 'all'}"

        if not force_refresh:
            cached = self._get_from_cache(cache_key)
            if cached is not None:
                return cached

        try:
            params = {"environment": self.environment}
            if capability_type:
                params["type"] = capability_type.value

            response = await self._http_client.get("/capabilities/registry", params=params)
            response.raise_for_status()

            data = response.json()
            items = data if isinstance(data, list) else (data.get("items") or [])

            capabilities = [CapabilityMetadata.from_dict(item) for item in items]
            self._set_cache(cache_key, capabilities)

            return capabilities

        except Exception as e:
            logger.error(f"Failed to fetch capabilities: {type(e).__name__}: {e}")
            cached = self._get_from_cache(cache_key)
            if cached is not None:
                logger.info("Using cached capability data")
                return cached
            return []

    async def get_metadata(
        self,
        capability_id: str,
        force_refresh: bool = False,
    ) -> CapabilityMetadata | None:
        """Get single capability metadata by ID."""
        cache_key = f"capability:{capability_id}"

        if not force_refresh:
            cached = self._get_from_cache(cache_key)
            if cached is not None:
                return cached

        try:
            response = await self._http_client.get(f"/capabilities/{capability_id}")
            response.raise_for_status()

            capability = CapabilityMetadata.from_dict(response.json())
            self._set_cache(cache_key, capability)

            return capability

        except httpx.HTTPStatusError as e:
            if e.response.status_code == 404:
                return None
            logger.error(f"Failed to fetch capability {capability_id}: {type(e).__name__}: {e}")
            return self._get_from_cache(cache_key)
        except Exception as e:
            logger.error(f"Failed to fetch capability {capability_id}: {type(e).__name__}: {e}")
            return self._get_from_cache(cache_key)

    async def get_metadata_by_type(
        self,
        capability_type: CapabilityType,
        force_refresh: bool = False,
    ) -> list[CapabilityMetadata]:
        """Get all capabilities of a specific type."""
        return await self.get_all_metadata(capability_type, force_refresh)

    async def resolve(
        self,
        capability_ids: list[str],
    ) -> dict[str, CapabilityMetadata]:
        """Batch resolve multiple capabilities by ID."""
        try:
            response = await self._http_client.post(
                "/capabilities/resolve",
                json={"capability_ids": capability_ids},
            )
            response.raise_for_status()

            data = response.json()
            result = {}
            for item in (data.get("resolved") or []):
                cap = CapabilityMetadata.from_dict(item)
                result[cap.id] = cap
                self._set_cache(f"capability:{cap.id}", cap)

            return result

        except Exception as e:
            logger.error(f"Failed to resolve capabilities: {type(e).__name__}: {e}")
            return {}

    # =========================================================================
    # Prompt APIs
    # =========================================================================

    async def get_prompt(
        self,
        prompt_id: str,
        version: str | None = None,
    ) -> PromptContent | None:
        """Get a Prompt template by ID."""
        cache_key = f"prompt:{prompt_id}:{version or 'latest'}"

        cached = self._get_from_cache(cache_key)
        if cached is not None:
            return cached

        try:
            params = {}
            if version:
                params["version"] = version

            response = await self._http_client.get(
                f"/prompts/{prompt_id}", params=params
            )
            response.raise_for_status()

            data = response.json()
            prompt = PromptContent.from_dict(data)
            self._set_cache(cache_key, prompt)
            return prompt

        except httpx.HTTPStatusError as e:
            if e.response.status_code == 404:
                logger.warning(f"Prompt not found by ID '{prompt_id}' (404). "
                               "Ensure the agent config uses the JetForge prompt ID, not the name.")
                return None
            logger.error(f"Failed to fetch prompt {prompt_id}: {type(e).__name__}: {e}")
            return self._get_from_cache(cache_key)
        except Exception as e:
            logger.error(f"Failed to fetch prompt {prompt_id}: {type(e).__name__}: {e}",
                         exc_info=True)
            return self._get_from_cache(cache_key)

    async def get_prompt_by_name(
        self,
        name: str,
        version: str | None = None,
    ) -> PromptContent | None:
        """Get a Prompt template by name (fallback when ID lookup returns 404)."""
        try:
            params: dict[str, str] = {"name": name}
            response = await self._http_client.get("/prompts", params=params)
            response.raise_for_status()

            data = response.json()
            items = data if isinstance(data, list) else (data.get("items") or [])

            candidates = [i for i in items if i.get("name") == name]
            if not candidates:
                logger.debug(f"No prompt found with name '{name}'")
                return None

            match = candidates[0]
            if version:
                for item in candidates:
                    if item.get("version") == version:
                        match = item
                        break

            actual_id = match.get("id")
            if not actual_id:
                return None

            return await self._get_prompt_by_id(actual_id, version)

        except Exception as e:
            logger.error(f"Failed to fetch prompt by name '{name}': {type(e).__name__}: {e}")
            return None

    async def _get_prompt_by_id(
        self,
        prompt_id: str,
        version: str | None = None,
    ) -> PromptContent | None:
        """Fetch prompt detail by its actual JetForge ID (no name fallback)."""
        cache_key = f"prompt:{prompt_id}:{version or 'latest'}"

        cached = self._get_from_cache(cache_key)
        if cached is not None:
            return cached

        try:
            params = {}
            if version:
                params["version"] = version

            response = await self._http_client.get(
                f"/prompts/{prompt_id}", params=params
            )
            response.raise_for_status()

            data = response.json()
            prompt = PromptContent.from_dict(data)
            self._set_cache(cache_key, prompt)
            return prompt

        except Exception as e:
            logger.error(f"Failed to fetch prompt by ID {prompt_id}: {type(e).__name__}: {e}",
                         exc_info=True)
            return None

    # =========================================================================
    # Agent Config APIs
    # =========================================================================

    async def get_agent_config(
        self,
        agent_id: str,
        version: str | None = None,
    ) -> AgentConfigContent | None:
        """Get Agent configuration by ID."""
        cache_key = f"agent_config:{agent_id}:{version or 'latest'}"

        cached = self._get_from_cache(cache_key)
        if cached is not None:
            return cached

        try:
            params = {}
            if version:
                params["version"] = version

            response = await self._http_client.get(
                f"/agents/{agent_id}/config", params=params
            )
            response.raise_for_status()

            data = response.json()
            config = AgentConfigContent.from_dict(data)
            self._set_cache(cache_key, config)
            return config

        except httpx.HTTPStatusError as e:
            if e.response.status_code == 404:
                return None
            logger.error(f"Failed to fetch agent config {agent_id}: {type(e).__name__}: {e}")
            return self._get_from_cache(cache_key)
        except Exception as e:
            logger.error(f"Failed to fetch agent config {agent_id}: {type(e).__name__}: {e}")
            return self._get_from_cache(cache_key)

    async def get_agent_config_by_name(
        self,
        name: str,
        version: str | None = None,
    ) -> AgentConfigContent | None:
        """Get Agent configuration by name."""
        cache_key = f"agent_config:name:{name}:{version or 'latest'}"

        cached = self._get_from_cache(cache_key)
        if cached is not None:
            return cached

        try:
            params = {"name": name}
            if version:
                params["version"] = version

            response = await self._http_client.get("/agents/config", params=params)
            response.raise_for_status()

            data = response.json()
            config = AgentConfigContent.from_dict(data)
            self._set_cache(cache_key, config)
            return config

        except httpx.HTTPStatusError as e:
            if e.response.status_code == 404:
                return None
            logger.error(f"Failed to fetch agent config by name {name}: {type(e).__name__}: {e}")
            return self._get_from_cache(cache_key)
        except Exception as e:
            logger.error(f"Failed to fetch agent config by name {name}: {type(e).__name__}: {e}")
            return self._get_from_cache(cache_key)

    # =========================================================================
    # Skill-specific APIs
    # =========================================================================

    async def get_skill_content(self, capability_id: str) -> str | None:
        """Get SKILL.md content for a Skill capability."""
        try:
            response = await self._http_client.get(
                f"/capabilities/{capability_id}/content"
            )
            response.raise_for_status()
            return response.json().get("content")
        except Exception as e:
            logger.error(f"Failed to fetch skill content: {type(e).__name__}: {e}")
            return None

    async def get_skill_scripts(self, capability_id: str) -> list[dict[str, Any]]:
        """Get list of scripts for a Skill capability."""
        try:
            response = await self._http_client.get(
                f"/capabilities/{capability_id}/scripts"
            )
            response.raise_for_status()
            return response.json().get("scripts") or []
        except Exception as e:
            logger.error(f"Failed to fetch skill scripts: {type(e).__name__}: {e}")
            return []

    async def get_skill_file(
        self,
        capability_id: str,
        file_path: str,
        version: str | None = None,
    ) -> str | None:
        """Get a specific file from a Skill package."""
        cache_key = f"skill_file:{capability_id}:{file_path}:{version or 'latest'}"

        cached = self._get_from_cache(cache_key)
        if cached is not None:
            return cached

        try:
            params = {}
            if version:
                params["version"] = version

            safe_path = file_path.lstrip("/")
            response = await self._http_client.get(
                f"/skills/{capability_id}/files/{safe_path}",
                params=params,
            )
            response.raise_for_status()

            data = response.json()
            content = data.get("content")
            if content:
                self._set_cache(cache_key, content)
            return content

        except Exception as e:
            logger.error(f"Failed to fetch skill file {capability_id}/{file_path}: {type(e).__name__}: {e}")
            return self._get_from_cache(cache_key)

    async def list_skill_files(
        self,
        capability_id: str,
        version: str | None = None,
    ) -> list[SkillFileInfo]:
        """List all files in a Skill package."""
        cache_key = f"skill_files:{capability_id}:{version or 'latest'}"

        cached = self._get_from_cache(cache_key)
        if cached is not None:
            return cached

        try:
            params = {}
            if version:
                params["version"] = version

            response = await self._http_client.get(
                f"/skills/{capability_id}/files",
                params=params,
            )
            response.raise_for_status()

            data = response.json()
            items = data if isinstance(data, list) else (data.get("files") or [])
            files = [SkillFileInfo.from_dict(item) for item in items]
            self._set_cache(cache_key, files)
            return files

        except Exception as e:
            logger.error(f"Failed to list skill files {capability_id}: {type(e).__name__}: {e}")
            return self._get_from_cache(cache_key) or []

    async def execute_skill_script(
        self,
        capability_id: str,
        script_name: str,
        args: dict[str, Any],
        timeout_ms: int = 30000,
    ) -> dict[str, Any]:
        """Execute a Skill script in the sandbox."""
        try:
            response = await self._http_client.post(
                "/sandbox/execute",
                json={
                    "capability_id": capability_id,
                    "script_name": script_name,
                    "args": args,
                    "timeout_ms": timeout_ms,
                },
            )
            response.raise_for_status()
            return response.json()
        except Exception as e:
            logger.error(f"Failed to execute skill script: {type(e).__name__}: {e}")
            return {
                "status": "error",
                "error": str(e),
            }

    # =========================================================================
    # Real-time Updates (WebSocket)
    # =========================================================================

    def on_capability_updated(
        self,
        callback: Callable[[str, CapabilityMetadata], None],
    ) -> None:
        """Register callback for capability update events."""
        self._update_callbacks.append(callback)

    def on_prompt_updated(
        self,
        callback: Callable[[str, PromptContent], None],
    ) -> None:
        """Register callback for prompt update events."""
        self._prompt_updated_callbacks.append(callback)

    def on_prompt_deleted(
        self,
        callback: Callable[[str], None],
    ) -> None:
        """Register callback for prompt delete events."""
        self._prompt_deleted_callbacks.append(callback)

    def on_agent_config_updated(
        self,
        callback: Callable[[str, AgentConfigContent], None],
    ) -> None:
        """Register callback for agent config update events."""
        self._agent_config_updated_callbacks.append(callback)

    def on_agent_config_deleted(
        self,
        callback: Callable[[str], None],
    ) -> None:
        """Register callback for agent config delete events."""
        self._agent_config_deleted_callbacks.append(callback)

    def on_capability_deleted(
        self,
        callback: Callable[[str], None],
    ) -> None:
        """Register callback for capability delete events."""
        self._delete_callbacks.append(callback)

    async def start_websocket(self) -> None:
        """Start WebSocket connection for real-time updates."""
        if self._ws_task and not self._ws_task.done():
            return

        self._ws_task = asyncio.create_task(self._websocket_loop())

    async def stop_websocket(self) -> None:
        """Stop WebSocket connection."""
        if self._ws_task:
            self._ws_task.cancel()
            try:
                await self._ws_task
            except asyncio.CancelledError:
                pass
            self._ws_task = None

    async def _websocket_loop(self) -> None:
        """WebSocket connection loop with auto-reconnect."""
        ws_url = f"{self.base_url.replace('http', 'ws')}/ws/updates"

        while True:
            try:
                async with websockets.connect(ws_url, proxy=None) as ws:
                    self._ws_connection = ws
                    self._ws_reconnect_delay = 1.0

                    logger.info("WebSocket connected to JetForge")

                    await ws.send(json.dumps({
                        "action": "subscribe",
                        "channels": ["capabilities", "prompts", "agent_configs"],
                        "environment": self.environment,
                    }))

                    async for message in ws:
                        await self._handle_ws_message(message)

            except ConnectionClosed:
                logger.warning("WebSocket connection closed")
            except Exception as e:
                logger.error(f"WebSocket error: {type(e).__name__}: {e}")

            logger.info(f"Reconnecting in {self._ws_reconnect_delay}s...")
            await asyncio.sleep(self._ws_reconnect_delay)
            self._ws_reconnect_delay = min(
                self._ws_reconnect_delay * 2,
                self._ws_max_reconnect_delay,
            )

    async def _handle_ws_message(self, message: str) -> None:
        """Handle incoming WebSocket message."""
        try:
            data = json.loads(message)
            event_type = data.get("event") or data.get("type")

            if event_type == "capability_updated":
                capability_id = data.get("capability_id")
                capability_data = data.get("data")

                if capability_id and capability_data:
                    metadata = CapabilityMetadata.from_dict(capability_data)
                    self._set_cache(f"capability:{capability_id}", metadata)
                    self._invalidate_cache("all_metadata:all")

                    for callback in self._update_callbacks:
                        try:
                            callback(capability_id, metadata)
                        except Exception as e:
                            logger.error(f"Update callback error: {e}")

            elif event_type == "capability_deleted":
                capability_id = data.get("capability_id")

                if capability_id:
                    self._invalidate_cache(f"capability:{capability_id}")
                    self._invalidate_cache("all_metadata:all")

                    for callback in self._delete_callbacks:
                        try:
                            callback(capability_id)
                        except Exception as e:
                            logger.error(f"Delete callback error: {e}")

            elif event_type == "prompt_updated":
                prompt_id = data.get("prompt_id")
                prompt_data = data.get("data")
                if prompt_id and prompt_data:
                    content = PromptContent.from_dict(prompt_data)
                    self._set_cache(f"prompt:{prompt_id}:latest", content)
                    for cb in self._prompt_updated_callbacks:
                        try:
                            cb(prompt_id, content)
                        except Exception as e:
                            logger.error(f"Prompt update callback error: {e}")

            elif event_type == "prompt_deleted":
                prompt_id = data.get("prompt_id")
                if prompt_id:
                    self._invalidate_cache(f"prompt:{prompt_id}")
                    for cb in self._prompt_deleted_callbacks:
                        try:
                            cb(prompt_id)
                        except Exception as e:
                            logger.error(f"Prompt delete callback error: {e}")

            elif event_type == "agent_config_updated":
                agent_id = data.get("agent_id")
                action = data.get("action", "updated")
                config_data = data.get("data")
                if agent_id and action == "deleted":
                    self._invalidate_cache(f"agent_config:{agent_id}")
                    for cb in self._agent_config_deleted_callbacks:
                        try:
                            cb(agent_id)
                        except Exception as e:
                            logger.error(f"Agent config delete callback error: {e}")
                elif agent_id:
                    if config_data:
                        config = AgentConfigContent.from_dict(config_data)
                        self._set_cache(f"agent_config:{agent_id}:latest", config)
                    else:
                        self._invalidate_cache(f"agent_config:{agent_id}")
                    for cb in self._agent_config_updated_callbacks:
                        try:
                            if config_data:
                                cb(agent_id, AgentConfigContent.from_dict(config_data))
                            else:
                                cb(agent_id, AgentConfigContent(id="", agent_id=agent_id, name=""))
                        except Exception as e:
                            logger.error(f"Agent config update callback error: {e}")

            elif event_type == "cache_invalidate":
                self._invalidate_cache()
                logger.info("Cache invalidated by server")

        except json.JSONDecodeError:
            logger.warning(f"Invalid WebSocket message: {message}")
        except Exception as e:
            logger.error(f"Error handling WebSocket message: {type(e).__name__}: {e}")

    # =========================================================================
    # Health Check
    # =========================================================================

    async def health_check(self) -> bool:
        """JetForge health check (hits /health, not /api/v1/health)."""
        try:
            headers: dict[str, str] = {}
            if self.api_key:
                headers["Authorization"] = f"Bearer {self.api_key}"
            async with httpx.AsyncClient(timeout=5.0) as client:
                response = await client.get(
                    f"{self.base_url}/health",
                    headers=headers,
                )
                return response.status_code == 200
        except Exception:
            return False

    # =========================================================================
    # Resource Submission (JETP-014)
    # =========================================================================

    async def submit_resource(
        self,
        resource_type: str,
        name: str,
        content: str | None = None,
        version: str = "1.0.0",
        description: str | None = None,
        visibility: str = "PUBLIC",
        usability: str = "SUBSCRIBERS",
        tags: list[str] | None = None,
        metadata: dict[str, Any] | None = None,
        identity_headers: dict[str, str] | None = None,
    ) -> dict[str, Any]:
        """Submit a resource to JetForge for review."""
        payload = {
            "resource_type": resource_type,
            "name": name,
            "version": version,
            "visibility": visibility,
            "usability": usability,
        }
        if content is not None:
            payload["content"] = content
        if description is not None:
            payload["description"] = description
        if tags is not None:
            payload["tags"] = tags
        if metadata is not None:
            payload["metadata"] = metadata

        headers = {}
        if identity_headers:
            headers.update(identity_headers)

        response = await self._http_client.post(
            "/resources/submit",
            json=payload,
            headers=headers,
        )
        response.raise_for_status()
        return response.json()

    async def get_submission_status(self, resource_id: str) -> dict[str, Any] | None:
        """Get the review status for a submitted resource."""
        try:
            response = await self._http_client.get(
                f"/resources/submissions/{resource_id}",
            )
            if response.status_code == 404:
                return None
            response.raise_for_status()
            return response.json()
        except Exception as e:
            logger.error("Failed to get submission status for %s: %s", resource_id, e)
            return None

    async def check_usability(self, resource_id: str) -> bool:
        """Pre-check if the current site/org can use a resource."""
        metadata = await self.get_metadata(resource_id)
        if not metadata:
            return False
        usability = getattr(metadata, "usability", "PUBLIC")
        if usability == "PUBLIC":
            return True
        return True

    # =========================================================================
    # Polling Fallback
    # =========================================================================

    async def start_polling(self, interval_seconds: float = 60.0) -> asyncio.Task:
        """Start polling for updates as fallback when WebSocket unavailable."""
        return asyncio.create_task(self._polling_loop(interval_seconds))

    async def _polling_loop(self, interval: float) -> None:
        """Polling loop for capability updates."""
        while True:
            try:
                await asyncio.sleep(interval)
                capabilities = await self.get_all_metadata(force_refresh=True)
                logger.debug(f"Polled {len(capabilities)} capabilities")
            except asyncio.CancelledError:
                break
            except Exception as e:
                logger.error(f"Polling error: {type(e).__name__}: {e}")
