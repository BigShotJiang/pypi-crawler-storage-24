import json
import re
from collections.abc import Iterator, Mapping
from decimal import Decimal
from typing import (
    Any,
    Protocol,
    TypeVar,
    cast,
    override,
)

import click
import trafaret

from .types import Undefined, undefined


class BoolExprType(click.ParamType):
    name = "boolean"

    @override
    def convert(
        self,
        value: str | bool,
        param: click.Parameter | None,
        ctx: click.Context | None,
    ) -> bool:
        if isinstance(value, bool):
            return value
        try:
            result: bool = trafaret.ToBool().check(value)
            return result
        except trafaret.DataError:
            self.fail(f"Cannot parser/convert {value!r} as a boolean.", param, ctx)


class ByteSizeParamType(click.ParamType):
    name = "byte"

    _rx_digits = re.compile(r"^(\d+(?:\.\d*)?)([kmgtpe]?)$", re.IGNORECASE)
    _scales = {
        "k": 2**10,
        "m": 2**20,
        "g": 2**30,
        "t": 2**40,
        "p": 2**50,
        "e": 2**60,
    }

    @override
    def convert(
        self,
        value: str | int,
        param: click.Parameter | None,
        ctx: click.Context | None,
    ) -> int:
        if isinstance(value, int):
            return value
        m = self._rx_digits.search(value)
        if m is None:
            self.fail(f"{value!r} is not a valid byte-size expression", param, ctx)
        size = float(m.group(1))
        unit = m.group(2).lower()
        return int(size * self._scales.get(unit, 1))


class ByteSizeParamCheckType(click.ParamType):
    name = "byte-check"

    _rx_digits = re.compile(r"^(\d+(?:\.\d*)?)([kmgtpe]?)$", re.IGNORECASE)

    @override
    def convert(
        self,
        value: str | int,
        param: click.Parameter | None,
        ctx: click.Context | None,
    ) -> str | int:
        if isinstance(value, int):
            return value
        m = self._rx_digits.search(value)
        if m is None:
            self.fail(f"{value!r} is not a valid byte-size expression", param, ctx)
        return value


class CommaSeparatedKVListParamType(click.ParamType):
    name = "comma-seperated-KVList-check"

    @override
    def convert(
        self,
        value: str | dict[str, str],
        param: click.Parameter | None,
        ctx: click.Context | None,
    ) -> Mapping[str, str]:
        if isinstance(value, dict):
            return value
        override_map: dict[str, str] = {}
        for assignment in value.split(","):
            try:
                k, _, v = assignment.partition("=")
                if k == "" or v == "":
                    raise ValueError(f"key or value is empty. key = {k}, value = {v}")
            except ValueError:
                self.fail(
                    f"{value!r} is not a valid mapping expression",
                    param,
                    ctx,
                )
            else:
                override_map[k] = v
        return override_map


class JSONParamType(click.ParamType):
    """
    A JSON string parameter type.
    The default value must be given as a valid JSON-parsable string,
    not the Python objects.
    """

    name = "json-string"

    def __init__(self) -> None:
        super().__init__()
        self._parsed = False

    @override
    def convert(
        self,
        value: str | None,
        param: click.Parameter | None,
        ctx: click.Context | None,
    ) -> Any:
        if self._parsed:
            # Click invokes this method TWICE
            # for a default value given as string.
            return value
        self._parsed = True
        if value is None:
            return None
        try:
            return json.loads(value)
        except json.JSONDecodeError:
            self.fail(f"cannot parse {value!r} as JSON", param, ctx)


def drange(start: Decimal, stop: Decimal, num: int) -> Iterator[Decimal]:
    """
    A simplified version of numpy.linspace with default options
    """
    delta = stop - start
    step = delta / (num - 1)
    yield from (start + step * Decimal(tick) for tick in range(num))


class RangeExprOptionType(click.ParamType):
    """
    Accepts a range expression which generates a range of values for a variable.

    Linear space range: "linspace:1,2,10" (start, stop, num) as in numpy.linspace
    Pythonic range: "range:1,10,2" (start, stop[, step]) as in Python's range
    Case range: "case:a,b,c" (comma-separated strings)
    """

    _rx_range_key = re.compile(r"^[a-zA-Z_][a-zA-Z0-9_]*$")
    name = "Range Expression"

    @override
    def convert(
        self,
        value: str,
        param: click.Parameter | None,
        ctx: click.Context | None,
    ) -> Any:
        key, value = value.split("=", maxsplit=1)
        if not self._rx_range_key.match(key):
            self.fail("The key must be a valid slug string.", param, ctx)
        try:
            if value.startswith("case:"):
                return key, value[5:].split(",")
            if value.startswith("linspace:"):
                start, stop, num = value[9:].split(",")
                return key, tuple(drange(Decimal(start), Decimal(stop), int(num)))
            if value.startswith("range:"):
                range_args = map(int, value[6:].split(","))
                return key, tuple(range(*range_args))
            self.fail("Unrecognized range expression type", param, ctx)
        except ValueError as e:
            self.fail(str(e), param, ctx)


T = TypeVar("T")


class SingleValueConstructorType(Protocol):
    def __init__(self, value: Any) -> None: ...


TScalar = TypeVar("TScalar", bound=SingleValueConstructorType | click.ParamType)


class CommaSeparatedListType[TScalar: SingleValueConstructorType | click.ParamType](
    click.ParamType
):
    name = "List Expression"

    def __init__(self, type_: type[TScalar] | None = None) -> None:
        super().__init__()
        self.type_ = type_ if type_ is not None else str

    def convert(
        self, value: str | int, param: click.Parameter | None, ctx: click.Context | None
    ) -> int | list[Any]:
        try:
            match value:
                case int():
                    return value
                case str():
                    result = []
                    for elem in value.split(","):
                        if isinstance(self.type_, type) and issubclass(self.type_, click.ParamType):
                            param_type_cls = cast(type[click.ParamType], self.type_)
                            result.append(param_type_cls().convert(elem, param, ctx))
                        else:
                            constructor = cast(type[SingleValueConstructorType], self.type_)
                            result.append(constructor(elem))
                    return result
        except ValueError as e:
            self.fail(repr(e), param, ctx)


class OptionalType[TScalar: SingleValueConstructorType | click.ParamType](click.ParamType):
    name = "Optional Type Wrapper"

    def __init__(self, type_: type[TScalar] | type[click.ParamType] | click.ParamType) -> None:
        super().__init__()
        self.type_ = type_

    def convert(
        self,
        value: str | Undefined,
        param: click.Parameter | None,
        ctx: click.Context | None,
    ) -> TScalar | Undefined:
        try:
            if value is undefined:
                return undefined
            if isinstance(self.type_, click.ParamType):
                return cast(TScalar, self.type_.convert(value, param, ctx))
            if isinstance(self.type_, type) and issubclass(self.type_, click.ParamType):
                return cast(TScalar, self.type_().convert(value, param, ctx))
            return self.type_(value)
        except ValueError:
            self.fail(f"{value!r} is not valid `{self.type_}` or `undefined`", param, ctx)
