"""Functions to infer phylogenetic history among a population of extant hstrat
columns."""

from ..._auxiliary_lib import lazy_attach_stub

__getattr__, __dir__, __all__ = lazy_attach_stub(__name__, __file__)
del lazy_attach_stub
