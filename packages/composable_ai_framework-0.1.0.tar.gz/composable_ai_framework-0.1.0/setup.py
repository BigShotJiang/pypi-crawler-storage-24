from setuptools import setup, find_packages

setup(
    name='my_package',
    version='0.1.0',
    packages=find_packages(),
    install_requires=[
        'PyYAML>=6.0',
        'pytest>=7.0',
        'nemoguardrails',
        'langgraph>=0.1.0',
        'langchain>=0.1.0',
    ],
)