from typing import Type, Dict, Any


class ProviderRegistry:
    """Simple registry mapping string keys to provider classes.

    Providers register themselves by name. This allows configuration-driven
    selection and late-binding of implementations without hard dependencies.
    """

    _registry: Dict[str, Type] = {}

    @classmethod
    def register(cls, name: str, provider_cls: Type):
        if name in cls._registry:
            raise KeyError(f"Provider '{name}' already registered.")
        cls._registry[name] = provider_cls

    @classmethod
    def get(cls, name: str) -> Type:
        try:
            return cls._registry[name]
        except KeyError:
            raise KeyError(f"Provider '{name}' not found in registry.")

    @classmethod
    def available(cls) -> Dict[str, Type]:
        return dict(cls._registry)


# convenience decorator for providers to self-register

def register_provider(name: str):
    def decorator(provider_cls: Type):
        ProviderRegistry.register(name, provider_cls)
        return provider_cls

    return decorator
