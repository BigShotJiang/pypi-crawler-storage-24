from .base import ProviderMiddleware
from typing import Any


class PIIMaskerMiddleware(ProviderMiddleware):
    def __init__(self):
        pass

    def wrap(self, provider: Any) -> Any:
        return provider
