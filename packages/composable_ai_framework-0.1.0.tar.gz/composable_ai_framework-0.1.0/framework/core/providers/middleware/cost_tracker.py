from .base import ProviderMiddleware
from typing import Any


class CostTrackerMiddleware(ProviderMiddleware):
    def __init__(self, tracker):
        self.tracker = tracker

    def wrap(self, provider: Any) -> Any:
        return provider
