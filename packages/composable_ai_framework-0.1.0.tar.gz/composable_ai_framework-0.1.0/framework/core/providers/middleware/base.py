from typing import Any, Callable


class ProviderMiddleware:
    """Base class for middleware that can wrap providers."""

    def wrap(self, provider: Any) -> Any:
        """Return a proxy or wrapped provider."""
        raise NotImplementedError()
