from .base import ProviderMiddleware
from typing import Any


class RateLimiterMiddleware(ProviderMiddleware):
    def __init__(self, calls_per_minute: int = 60):
        self.calls_per_minute = calls_per_minute
        # implementation omitted

    def wrap(self, provider: Any) -> Any:
        # naive: return provider directly
        return provider
