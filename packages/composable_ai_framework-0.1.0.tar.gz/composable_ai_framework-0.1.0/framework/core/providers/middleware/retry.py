from .base import ProviderMiddleware
from typing import Any


class RetryMiddleware(ProviderMiddleware):
    def __init__(self, retries: int = 3):
        self.retries = retries

    def wrap(self, provider: Any) -> Any:
        return provider
