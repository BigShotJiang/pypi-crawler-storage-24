from .base import ProviderMiddleware
from typing import Any


class CacheMiddleware(ProviderMiddleware):
    def __init__(self):
        self.cache = {}

    def wrap(self, provider: Any) -> Any:
        return provider
