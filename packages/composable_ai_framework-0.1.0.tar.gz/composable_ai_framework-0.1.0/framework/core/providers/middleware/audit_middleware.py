from .base import ProviderMiddleware
from typing import Any


class AuditMiddleware(ProviderMiddleware):
    def __init__(self, logger):
        self.logger = logger

    def wrap(self, provider: Any) -> Any:
        return provider
