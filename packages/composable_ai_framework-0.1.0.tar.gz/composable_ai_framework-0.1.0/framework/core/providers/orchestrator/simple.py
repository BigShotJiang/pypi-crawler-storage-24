from typing import Any, Dict

from framework.core.registry import register_provider
from framework.core.interfaces.orchestrator import OrchestratorProvider


@register_provider("simple_orchestrator")
class SimpleOrchestrator(OrchestratorProvider):
    def __init__(self, **kwargs):
        pass

    def run(self, plan: Dict[str, Any]) -> Any:
        # just echo back the plan
        return plan
