"""LangGraph-based Orchestrator for the Composable AI Framework.

This module provides orchestration capabilities using LangGraph, enabling
complex workflow and agent execution patterns with state management,
conditional routing, and parallel execution.

LangGraph provides a structured way to define multi-step workflows where:
- Nodes represent units of work (functions, tools, agents)
- Edges define the flow between nodes
- State is maintained and passed through the execution flow
- Conditional logic can control routing
"""

import logging
from typing import Any, Dict, List, Optional, Callable, Union
from dataclasses import dataclass, field

from framework.core.registry import register_provider
from framework.core.interfaces.orchestrator import OrchestratorProvider

try:
    from langgraph.graph import StateGraph, END
    from langchain_core.pydantic_v1 import BaseModel
except ImportError:
    raise ImportError(
        "langgraph and langchain are required for LangGraph orchestration. "
        "Install with: pip install langgraph langchain"
    )

logger = logging.getLogger(__name__)


@dataclass
class NodeConfig:
    """Configuration for a graph node."""

    name: str
    func: Callable
    input_keys: List[str] = field(default_factory=list)
    output_keys: List[str] = field(default_factory=list)


@dataclass
class EdgeConfig:
    """Configuration for a graph edge (transition)."""

    source: str
    target: str
    condition: Optional[Callable] = None


class ExecutionState(BaseModel):
    """State schema for graph execution."""

    messages: List[Dict[str, Any]] = []
    context: Dict[str, Any] = {}
    current_node: str = ""
    error: Optional[str] = None
    metadata: Dict[str, Any] = {}

    class Config:
        arbitrary_types_allowed = True


@register_provider("langgraph_orchestrator")
class LangGraphOrchestrator(OrchestratorProvider):
    """LangGraph-based orchestrator for complex workflows.

    This orchestrator uses LangGraph to define and execute multi-step
    workflows with state management, conditional routing, and error handling.

    Example configuration in config.yaml:
        orchestrator:
            provider: langgraph_orchestrator
            graph_config: "./graphs/my_workflow.yaml"
            enable_logging: true
            timeout: 300
    """

    def __init__(
        self,
        graph_config: Optional[Dict[str, Any]] = None,
        enable_logging: bool = True,
        timeout: int = 300,
        custom_nodes: Optional[Dict[str, Callable]] = None,
        **kwargs
    ):
        """Initialize LangGraph Orchestrator.

        Args:
            graph_config: Configuration defining nodes and edges
            enable_logging: Whether to log execution
            timeout: Execution timeout in seconds
            custom_nodes: Custom node functions by name
            **kwargs: Additional arguments
        """
        self.graph_config = graph_config or {}
        self.enable_logging = enable_logging
        self.timeout = timeout
        self.custom_nodes = custom_nodes or {}
        self.nodes: Dict[str, NodeConfig] = {}
        self.edges: List[EdgeConfig] = []
        self.graph = None

        # Initialize from config if provided
        if graph_config:
            self._build_graph_from_config(graph_config)

        logger.info("LangGraphOrchestrator initialized")

    def _build_graph_from_config(self, config: Dict[str, Any]) -> None:
        """Build graph from configuration dictionary.

        Args:
            config: Configuration with nodes and edges
        """
        try:
            # Parse nodes
            if "nodes" in config:
                for node_cfg in config["nodes"]:
                    name = node_cfg.get("name")
                    func_name = node_cfg.get("func")

                    # Get function from custom nodes or built-ins
                    func = self.custom_nodes.get(func_name) or self._get_builtin_node(
                        func_name
                    )

                    if not func:
                        logger.warning(f"Node function not found: {func_name}")
                        continue

                    node = NodeConfig(
                        name=name,
                        func=func,
                        input_keys=node_cfg.get("input_keys", []),
                        output_keys=node_cfg.get("output_keys", []),
                    )
                    self.nodes[name] = node

            # Parse edges
            if "edges" in config:
                for edge_cfg in config["edges"]:
                    edge = EdgeConfig(
                        source=edge_cfg.get("source"),
                        target=edge_cfg.get("target"),
                        condition=None,  # TODO: support condition parsing
                    )
                    self.edges.append(edge)

            logger.info(f"Built graph with {len(self.nodes)} nodes and {len(self.edges)} edges")

        except Exception as e:
            logger.error(f"Failed to build graph from config: {e}")
            raise

    def _get_builtin_node(self, name: str) -> Optional[Callable]:
        """Get a built-in node function.

        Args:
            name: Name of the built-in node

        Returns:
            Callable node function or None
        """
        builtins = {
            "pass_through": self._builtin_pass_through,
            "echo": self._builtin_echo,
            "merge": self._builtin_merge,
            "conditional_route": self._builtin_conditional_route,
        }
        return builtins.get(name)

    @staticmethod
    def _builtin_pass_through(state: Dict[str, Any]) -> Dict[str, Any]:
        """Pass-through node (no-op)."""
        return state

    @staticmethod
    def _builtin_echo(state: Dict[str, Any]) -> Dict[str, Any]:
        """Echo node - logs and passes through."""
        logger.info(f"Echo: {state}")
        return state

    @staticmethod
    def _builtin_merge(state: Dict[str, Any]) -> Dict[str, Any]:
        """Merge node - combines context."""
        if "context" not in state:
            state["context"] = {}
        return state

    @staticmethod
    def _builtin_conditional_route(state: Dict[str, Any]) -> str:
        """Conditional routing node."""
        # Simple example: route based on context value
        condition = state.get("context", {}).get("route_condition")
        return "true_branch" if condition else "false_branch"

    def add_node(self, node: NodeConfig) -> None:
        """Add a node to the orchestrator.

        Args:
            node: NodeConfig defining the node
        """
        self.nodes[node.name] = node
        logger.info(f"Added node: {node.name}")

    def add_edge(self, edge: EdgeConfig) -> None:
        """Add an edge to the orchestrator.

        Args:
            edge: EdgeConfig defining the transition
        """
        self.edges.append(edge)
        logger.info(f"Added edge: {edge.source} -> {edge.target}")

    def add_custom_node(self, name: str, func: Callable) -> None:
        """Register a custom node function.

        Args:
            name: Name of the node
            func: Callable to execute as a node
        """
        self.custom_nodes[name] = func
        logger.info(f"Registered custom node: {name}")

    def run(self, plan: Dict[str, Any]) -> Any:
        """Execute the orchestration plan.

        Args:
            plan: Dictionary containing:
                - start_node (str): Starting node name
                - context (dict): Initial context
                - graph_def (dict, optional): Graph definition

        Returns:
            Execution result containing final state and metadata
        """
        try:
            # If graph definition provided, build graph first
            if "graph_def" in plan:
                self._build_graph_from_config(plan["graph_def"])

            start_node = plan.get("start_node", "start")
            initial_context = plan.get("context", {})

            # Initialize execution state
            state = ExecutionState(
                messages=[],
                context=initial_context,
                current_node=start_node,
                metadata={
                    "execution_plan": plan,
                    "total_nodes": len(self.nodes),
                    "total_edges": len(self.edges),
                },
            )

            # Execute the workflow
            result = self._execute_workflow(state, start_node)

            logger.info(
                f"Workflow execution completed. Final state: {result.current_node}"
            )

            return {
                "success": True,
                "state": result.dict(),
                "context": result.context,
                "final_node": result.current_node,
                "messages": result.messages,
                "metadata": result.metadata,
            }

        except Exception as e:
            logger.error(f"Workflow execution failed: {e}")
            return {
                "success": False,
                "error": str(e),
                "context": plan.get("context", {}),
            }

    def _execute_workflow(self, state: ExecutionState, start_node: str) -> ExecutionState:
        """Execute the workflow starting from a node.

        Args:
            state: Current execution state
            start_node: Name of the starting node

        Returns:
            Final execution state
        """
        visited = set()
        current = start_node
        max_iterations = len(self.nodes) * 2  # Prevent infinite loops

        for iteration in range(max_iterations):
            if current in visited and current != start_node:
                logger.warning(f"Cycle detected. Stopping at node: {current}")
                break

            if current == "END" or current == END:
                logger.info("Workflow reached END")
                break

            if current not in self.nodes:
                logger.warning(f"Node not found: {current}")
                break

            visited.add(current)
            state.current_node = current

            try:
                # Execute the node
                node = self.nodes[current]
                logger.info(f"Executing node: {node.name}")

                # Prepare node input
                node_input = {k: state.context.get(k) for k in node.input_keys}
                if not node_input:
                    node_input = {"state": state.dict()}

                # Execute node function
                node_output = node.func(node_input or state.dict())

                # Update state with node output
                if isinstance(node_output, dict):
                    for key in node.output_keys or ["result"]:
                        if key in node_output:
                            state.context[key] = node_output[key]

                state.messages.append(
                    {"node": current, "status": "success", "output": node_output}
                )

                # Find next node
                next_node = self._find_next_node(current, state)
                current = next_node

            except Exception as e:
                logger.error(f"Error executing node {current}: {e}")
                state.error = str(e)
                state.messages.append({"node": current, "status": "error", "error": str(e)})
                break

        return state

    def _find_next_node(self, current_node: str, state: ExecutionState) -> str:
        """Find the next node based on edges and conditions.

        Args:
            current_node: Current node name
            state: Current execution state

        Returns:
            Next node name
        """
        for edge in self.edges:
            if edge.source == current_node:
                # Check if edge has a condition
                if edge.condition:
                    if edge.condition(state.dict()):
                        return edge.target
                else:
                    return edge.target

        # No edge found, workflow ends
        return "END"

    def build_state_graph(self) -> "StateGraph":
        """Build a LangGraph StateGraph from nodes and edges.

        Returns:
            Configured StateGraph
        """
        graph = StateGraph(ExecutionState)

        # Add nodes to graph
        for node_name, node_config in self.nodes.items():
            graph.add_node(node_name, node_config.func)

        # Add edges to graph
        for edge in self.edges:
            if edge.condition:
                graph.add_conditional_edges(
                    edge.source, edge.condition, {True: edge.target, False: "END"}
                )
            else:
                graph.add_edge(edge.source, edge.target)

        # Set entry point
        if self.nodes:
            first_node = next(iter(self.nodes.keys()))
            graph.set_entry_point(first_node)

        # Add end node
        graph.add_node("END", lambda x: x)

        return graph

    def visualize(self) -> str:
        """Generate a visualization of the workflow.

        Returns:
            String representation of the graph
        """
        lines = ["\n=== LangGraph Orchestrator Visualization ===\n"]

        lines.append("Nodes:")
        for name, node in self.nodes.items():
            lines.append(f"  - {name}: {node.func.__name__}")

        lines.append("\nEdges:")
        for edge in self.edges:
            lines.append(f"  {edge.source} --> {edge.target}")

        lines.append("\n" + "=" * 50 + "\n")

        return "\n".join(lines)

    def get_execution_stats(self) -> Dict[str, Any]:
        """Get orchestrator statistics.

        Returns:
            Dictionary with orchestrator stats
        """
        return {
            "total_nodes": len(self.nodes),
            "total_edges": len(self.edges),
            "custom_nodes_registered": len(self.custom_nodes),
            "execution_timeout": self.timeout,
            "logging_enabled": self.enable_logging,
            "node_names": list(self.nodes.keys()),
            "edge_paths": [f"{e.source}->{e.target}" for e in self.edges],
        }
