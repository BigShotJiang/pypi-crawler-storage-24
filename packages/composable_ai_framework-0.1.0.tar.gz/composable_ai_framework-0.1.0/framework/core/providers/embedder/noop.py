from typing import Any, Iterable, List

from framework.core.registry import register_provider
from framework.core.interfaces.embedder import EmbedderProvider


@register_provider("noop_embedder")
class NoopEmbedder(EmbedderProvider):
    def __init__(self, **kwargs):
        pass

    def embed(self, texts: Iterable[str]) -> List[Any]:
        return [[] for _ in texts]
