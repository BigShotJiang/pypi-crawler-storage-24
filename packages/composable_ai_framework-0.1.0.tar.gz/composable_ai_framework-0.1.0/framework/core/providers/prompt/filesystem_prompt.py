from typing import Dict
from pathlib import Path

from framework.core.registry import register_provider
from framework.core.interfaces.prompt import PromptStoreProvider


@register_provider("filesystem_prompt")
class FileSystemPromptStore(PromptStoreProvider):
    def __init__(self, base_path: str = None, **kwargs):
        self.base = Path(base_path or ".")
        self.base.mkdir(parents=True, exist_ok=True)

    def get_prompt(self, name: str) -> str:
        path = self.base / f"{name}.txt"
        if not path.exists():
            raise KeyError(name)
        return path.read_text(encoding="utf-8")

    def save_prompt(self, name: str, prompt: str) -> None:
        path = self.base / f"{name}.txt"
        path.write_text(prompt, encoding="utf-8")
