# providers package

# when the package is imported we want to load all provider submodules so
# that the registration decorators execute. This avoids the need for
# callers to import each concrete provider manually.
import pkgutil
import importlib

# iterate through all submodules and subpackages recursively and import them
for finder, name, ispkg in pkgutil.walk_packages(__path__, prefix=__name__ + "."):
    try:
        importlib.import_module(name)
    except Exception:
        # ignore import errors; some modules may have optional dependencies
        pass
