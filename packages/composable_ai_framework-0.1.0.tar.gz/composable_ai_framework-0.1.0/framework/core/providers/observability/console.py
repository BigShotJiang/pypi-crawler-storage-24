from typing import Any, Dict

from framework.core.registry import register_provider
from framework.core.interfaces.observability import ObservabilityProvider


@register_provider("console_observability")
class ConsoleObservability(ObservabilityProvider):
    def log_event(self, name: str, attributes: Dict[str, Any] = None) -> None:
        print(f"EVENT {name}: {attributes}")

    def record_metric(self, name: str, value: Any) -> None:
        print(f"METRIC {name} = {value}")
