from typing import Any, Iterable, List

from framework.core.registry import register_provider
from framework.core.interfaces.vector import VectorStoreProvider


@register_provider("inmemory_vector")
class InMemoryVectorStore(VectorStoreProvider):
    def __init__(self, **kwargs):
        self._data = []

    def add_vectors(self, vectors: Iterable[Any], ids: Iterable[str] = None) -> None:
        self._data.extend(vectors)

    def query(self, vector: Any, top_k: int = 10) -> List[Any]:
        # naive: return first k
        return self._data[:top_k]

    def delete(self, ids: Iterable[str]) -> None:
        # no-op for in-memory
        pass
