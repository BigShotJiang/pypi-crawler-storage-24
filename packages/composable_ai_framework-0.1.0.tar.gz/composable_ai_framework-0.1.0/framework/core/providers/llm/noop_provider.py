from typing import Iterator, Any, Dict

from framework.core.registry import register_provider
from framework.core.interfaces.llm import LLMProvider


@register_provider("noop_llm")
class NoopLLMProvider(LLMProvider):
    def generate(self, prompt: str, **kwargs) -> str:
        return ""  # always empty

    def stream(self, prompt: str, **kwargs) -> Iterator[str]:
        yield ""

    def embed(self, text: str, **kwargs) -> Any:
        return []

    def get_metadata(self) -> Dict[str, Any]:
        return {"name": "noop", "version": "0.0.1"}
