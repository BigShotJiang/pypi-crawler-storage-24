from typing import Any, Dict

from framework.core.registry import register_provider
from framework.core.interfaces.templating import TemplatingProvider


@register_provider("plain_templating")
class PlainStringTemplating(TemplatingProvider):
    def __init__(self, **kwargs):
        pass

    def render(self, template: str, context: Dict[str, Any]) -> str:
        # naive python format
        return template.format(**context)
