from typing import Any

from framework.core.registry import register_provider
from framework.core.interfaces.memory import MemoryProvider


@register_provider("inmemory_memory")
class InMemoryMemory(MemoryProvider):
    def __init__(self, **kwargs):
        self._store = {}

    def save(self, key: str, value: Any) -> None:
        self._store[key] = value

    def load(self, key: str) -> Any:
        return self._store.get(key)

    def clear(self) -> None:
        self._store.clear()
