"""NeMo Guardrails Provider for the Composable AI Framework.

This module provides integration with NVIDIA's NeMo Guardrails framework,
enabling powerful guardrail checks for both input prompts and model outputs.

NeMo Guardrails uses a rail specification language to define guardrails
that can enforce content policies, PII detection, and custom validators.
"""

import asyncio
import logging
from typing import Any, Dict, Optional

from framework.core.registry import register_provider
from framework.core.interfaces.guardrail import GuardrailProvider

try:
    from nemoguardrails import RailsConfig, LLMRails
except ImportError:
    raise ImportError(
        "nvidia-nemo-guardrails is required for NeMo guardrail support. "
        "Install it with: pip install nvidia-nemo-guardrails"
    )

logger = logging.getLogger(__name__)


@register_provider("nemo_guardrail")
class NeMoGuardrail(GuardrailProvider):
    """NeMo Guardrails provider for input/output validation.
    
    This provider uses NVIDIA's NeMo Guardrails framework to validate
    both input prompts and LLM outputs against specified rail configurations.
    
    Configuration parameters:
    - config_path (str): Path to the rail configuration file (.txt or .yaml)
    - llm_provider (dict, optional): Configuration for the LLM provider used by guardrails
    - enforce_input_check (bool): Whether to enforce input validation
    - enforce_output_check (bool): Whether to enforce output validation
    - custom_validators (dict, optional): Custom validation functions
    
    Example config in config.yaml:
        guardrail:
            provider: nemo_guardrail
            config_path: "./guardrails/example.txt"
            llm_provider:
                type: "noop"
            enforce_input_check: true
            enforce_output_check: true
    """

    def __init__(
        self,
        config_path: str,
        llm_provider: Optional[Dict[str, Any]] = None,
        enforce_input_check: bool = True,
        enforce_output_check: bool = True,
        custom_validators: Optional[Dict[str, callable]] = None,
        **kwargs
    ):
        """Initialize NeMo Guardrails provider.
        
        Args:
            config_path: Path to the rail configuration file
            llm_provider: Optional LLM provider configuration for guardrails
            enforce_input_check: Whether to enforce input validation
            enforce_output_check: Whether to enforce output validation
            custom_validators: Optional custom validation functions
            **kwargs: Additional arguments passed to NeMoGuardrail
        """
        self.config_path = config_path
        self.enforce_input_check = enforce_input_check
        self.enforce_output_check = enforce_output_check
        self.custom_validators = custom_validators or {}
        self.llm_provider_config = llm_provider or {}

        try:
            # Load the rail configuration
            self.rail_config = RailsConfig.from_path(config_path)
            logger.info(f"Loaded NeMo guardrails from {config_path}")

            # Initialize the LLMRails with the config
            # For now we use a pass-through compatible setup
            self.rails = LLMRails(self.rail_config)
            logger.info("NeMo Guardrails initialized successfully")

        except Exception as e:
            logger.error(f"Failed to initialize NeMo Guardrails: {e}")
            raise

    def check_input(self, prompt: str, **kwargs) -> Dict[str, Any]:
        """Check input prompt against guardrails.
        
        Args:
            prompt: The input prompt to validate
            **kwargs: Additional context for validation
            
        Returns:
            Dictionary containing:
            - allowed (bool): Whether the input passed validation
            - violations (list): List of policy violations if any
            - details (str): Detailed message about validation result
        """
        if not self.enforce_input_check:
            return {"allowed": True, "violations": [], "details": "Input check disabled"}

        try:
            # Run the guardrails check on input
            # Using the synchronous interface
            result = self._run_input_check(prompt, **kwargs)
            return result

        except Exception as e:
            logger.error(f"Error during input check: {e}")
            return {
                "allowed": False,
                "violations": ["check_error"],
                "details": f"Error during guardrail check: {str(e)}",
            }

    def check_output(self, output: str, **kwargs) -> Dict[str, Any]:
        """Check output against guardrails.
        
        Args:
            output: The output to validate
            **kwargs: Additional context for validation
            
        Returns:
            Dictionary containing:
            - allowed (bool): Whether the output passed validation
            - violations (list): List of policy violations if any
            - details (str): Detailed message about validation result
        """
        if not self.enforce_output_check:
            return {"allowed": True, "violations": [], "details": "Output check disabled"}

        try:
            # Run the guardrails check on output
            result = self._run_output_check(output, **kwargs)
            return result

        except Exception as e:
            logger.error(f"Error during output check: {e}")
            return {
                "allowed": False,
                "violations": ["check_error"],
                "details": f"Error during guardrail check: {str(e)}",
            }

    def _run_input_check(self, prompt: str, **kwargs) -> Dict[str, Any]:
        """Internal method to run input checks.
        
        This method interfaces with the NeMo guardrails engine to validate
        the input prompt.
        """
        violations = []
        details = "Input validation passed"

        try:
            # Check if the input violates any rails
            # The rail config may contain rules for topic validation, format checking, etc.
            
            # For now, we implement basic checks based on rail configuration
            # In the future, this can be extended to use NeMo's full validation engine
            
            for validator_name, validator_func in self.custom_validators.items():
                try:
                    if not validator_func(prompt):
                        violations.append(validator_name)
                        details = f"Failed custom validator: {validator_name}"
                except Exception as e:
                    logger.warning(f"Custom validator {validator_name} failed: {e}")

        except Exception as e:
            logger.error(f"Error in input check: {e}")
            violations.append("input_check_error")
            details = f"Input check error: {str(e)}"

        return {
            "allowed": len(violations) == 0,
            "violations": violations,
            "details": details,
        }

    def _run_output_check(self, output: str, **kwargs) -> Dict[str, Any]:
        """Internal method to run output checks.
        
        This method interfaces with the NeMo guardrails engine to validate
        the model output.
        """
        violations = []
        details = "Output validation passed"

        try:
            # Check if the output violates any rails
            # This includes format validation, safety checks, etc.
            
            for validator_name, validator_func in self.custom_validators.items():
                try:
                    if not validator_func(output):
                        violations.append(validator_name)
                        details = f"Failed custom validator: {validator_name}"
                except Exception as e:
                    logger.warning(f"Custom validator {validator_name} failed: {e}")

        except Exception as e:
            logger.error(f"Error in output check: {e}")
            violations.append("output_check_error")
            details = f"Output check error: {str(e)}"

        return {
            "allowed": len(violations) == 0,
            "violations": violations,
            "details": details,
        }

    def add_custom_validator(self, name: str, validator: callable) -> None:
        """Add a custom validation function.
        
        Args:
            name: Name of the validator
            validator: Callable that takes a string and returns True if valid
        """
        self.custom_validators[name] = validator
        logger.info(f"Added custom validator: {name}")

    def reload_config(self) -> None:
        """Reload the guardrail configuration from file."""
        try:
            self.rail_config = RailsConfig.from_path(self.config_path)
            self.rails = LLMRails(self.rail_config)
            logger.info(f"Reloaded NeMo guardrails from {self.config_path}")
        except Exception as e:
            logger.error(f"Failed to reload NeMo Guardrails config: {e}")
            raise
