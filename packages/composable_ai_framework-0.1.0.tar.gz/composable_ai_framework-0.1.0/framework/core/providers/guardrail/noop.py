from typing import Any, Dict

from framework.core.registry import register_provider
from framework.core.interfaces.guardrail import GuardrailProvider


@register_provider("noop_guardrail")
class NoopGuardrail(GuardrailProvider):
    def __init__(self, **kwargs):
        pass

    def check_input(self, prompt: str, **kwargs) -> Dict[str, Any]:
        return {"allowed": True}

    def check_output(self, output: str, **kwargs) -> Dict[str, Any]:
        return {"allowed": True}
