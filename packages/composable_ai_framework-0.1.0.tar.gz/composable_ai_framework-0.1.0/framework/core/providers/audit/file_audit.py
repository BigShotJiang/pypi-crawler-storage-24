from typing import Any, Dict
from pathlib import Path

from framework.core.registry import register_provider
from framework.core.interfaces.audit import AuditLogger


@register_provider("file_audit")
class FileAuditLogger(AuditLogger):
    def __init__(self, file_path: str = "audit.log", **kwargs):
        self.path = Path(file_path)
        # ensure parent exists
        self.path.parent.mkdir(parents=True, exist_ok=True)

    def log(self, event: str, data: Dict[str, Any]) -> None:
        with open(self.path, "a", encoding="utf-8") as f:
            f.write(f"{event}: {data}\n")
