from typing import List, Callable, Any


class Pipeline:
    """Composable request pipeline.

    A pipeline is simply a sequence of callables that receive the same `context`
    dictionary. Each stage may mutate context and return it. This lightweight
    approach makes it easy to inject or replace stages.
    """

    def __init__(self, stages: List[Callable[[dict], dict]] = None):
        self.stages = stages or []

    def add_stage(self, stage: Callable[[dict], dict]) -> None:
        self.stages.append(stage)

    def run(self, context: dict) -> dict:
        for stage in self.stages:
            context = stage(context)
        return context
