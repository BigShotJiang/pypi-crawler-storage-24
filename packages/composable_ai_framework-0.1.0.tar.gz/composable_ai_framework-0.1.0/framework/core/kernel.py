import yaml
from pathlib import Path
from typing import Any, Dict

from .registry import ProviderRegistry


class Kernel:
    """Dependency injection kernel that builds providers from config.

    Configuration is expected to map categories (like "llm", "vector") to a
    dictionary containing a "provider" key (the registered name) and any
    parameters to pass into the provider constructor.

    Example config:
        llm:
          provider: openai
          api_key: ${OPENAI_KEY}

    """

    def __init__(self, config: Dict[str, Any]):
        self.config = config
        self.instances: Dict[str, Any] = {}

    @classmethod
    def from_file(cls, path: Path) -> "Kernel":
        with open(path, "r", encoding="utf-8") as f:
            cfg = yaml.safe_load(f)
        return cls(cfg)

    def build(self) -> None:
        for category, settings in self.config.items():
            if not isinstance(settings, dict):
                continue
            provider_name = settings.get("provider")
            if not provider_name:
                continue
            provider_cls = ProviderRegistry.get(provider_name)
            # pass all settings except the provider name as kwargs
            params = {k: v for k, v in settings.items() if k != "provider"}
            self.instances[category] = provider_cls(**params)

    def get(self, category: str):
        return self.instances.get(category)
