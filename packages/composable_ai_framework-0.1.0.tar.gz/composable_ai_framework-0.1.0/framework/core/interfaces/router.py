from abc import ABC, abstractmethod
from typing import Any, Dict


class ModelRouter(ABC):
    """Selects a model based on request context."""

    @abstractmethod
    def choose(self, context: Dict[str, Any]) -> str:
        pass
