from abc import ABC, abstractmethod
from typing import Any, Dict


class TemplatingProvider(ABC):
    """Renders templates (e.g. with Jinja2)."""

    @abstractmethod
    def render(self, template: str, context: Dict[str, Any]) -> str:
        pass
