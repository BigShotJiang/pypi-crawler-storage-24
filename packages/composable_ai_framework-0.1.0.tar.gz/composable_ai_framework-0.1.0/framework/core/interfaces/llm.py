from abc import ABC, abstractmethod
from typing import Any, Dict, Iterator


class LLMProvider(ABC):
    """Abstract base class for large language model providers."""

    @abstractmethod
    def generate(self, prompt: str, **kwargs) -> str:
        """Return a completed text for the given prompt."""

    @abstractmethod
    def stream(self, prompt: str, **kwargs) -> Iterator[str]:
        """Stream tokens or chunks as they are produced."""

    @abstractmethod
    def embed(self, text: str, **kwargs) -> Any:
        """Return an embedding vector for the given text."""

    @abstractmethod
    def get_metadata(self) -> Dict[str, Any]:
        """Return provider-specific metadata such as model name or version."""