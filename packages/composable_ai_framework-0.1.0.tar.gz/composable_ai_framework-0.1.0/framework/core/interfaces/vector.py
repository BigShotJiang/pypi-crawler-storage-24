from abc import ABC, abstractmethod
from typing import Any, Iterable, List


class VectorStoreProvider(ABC):
    """Abstract interface for vector stores."""

    @abstractmethod
    def add_vectors(self, vectors: Iterable[Any], ids: Iterable[str] = None) -> None:
        pass

    @abstractmethod
    def query(self, vector: Any, top_k: int = 10) -> List[Any]:
        pass

    @abstractmethod
    def delete(self, ids: Iterable[str]) -> None:
        pass
