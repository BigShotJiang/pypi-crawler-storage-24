from abc import ABC, abstractmethod
from typing import Any


class CostTrackerProvider(ABC):
    """Tracks cost/usage of provider calls."""

    @abstractmethod
    def record(self, service: str, amount: Any) -> None:
        pass

    @abstractmethod
    def report(self) -> Any:
        pass
