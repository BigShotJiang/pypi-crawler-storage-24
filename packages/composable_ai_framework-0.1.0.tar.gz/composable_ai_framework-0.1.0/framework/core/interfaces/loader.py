from abc import ABC, abstractmethod
from typing import Any, Dict, Iterable


class DocumentLoaderProvider(ABC):
    """Loads documents or data given a source specification."""

    @abstractmethod
    def load(self, source: Any) -> Iterable[Dict[str, Any]]:
        pass
