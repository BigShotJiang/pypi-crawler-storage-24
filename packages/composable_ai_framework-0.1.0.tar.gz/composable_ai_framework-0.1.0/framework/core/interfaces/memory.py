from abc import ABC, abstractmethod
from typing import Any


class MemoryProvider(ABC):
    """Stores conversational or other stateful memory."""

    @abstractmethod
    def save(self, key: str, value: Any) -> None:
        pass

    @abstractmethod
    def load(self, key: str) -> Any:
        pass

    @abstractmethod
    def clear(self) -> None:
        pass
