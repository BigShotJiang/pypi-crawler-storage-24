from abc import ABC, abstractmethod
from typing import Any, Dict


class AuditLogger(ABC):
    """Records audit events for compliance."""

    @abstractmethod
    def log(self, event: str, data: Dict[str, Any]) -> None:
        pass
