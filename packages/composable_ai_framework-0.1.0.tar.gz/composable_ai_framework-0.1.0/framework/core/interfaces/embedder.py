from abc import ABC, abstractmethod
from typing import Any, Iterable, List


class EmbedderProvider(ABC):
    """Returns embeddings for text or data."""

    @abstractmethod
    def embed(self, texts: Iterable[str]) -> List[Any]:
        pass
