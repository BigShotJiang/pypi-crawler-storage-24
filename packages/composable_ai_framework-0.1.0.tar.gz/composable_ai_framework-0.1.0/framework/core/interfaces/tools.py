from abc import ABC, abstractmethod
from typing import Any, Dict


class ToolRegistry(ABC):
    """Registry of external tools that can be invoked by models."""

    @abstractmethod
    def register_tool(self, name: str, handler: Any) -> None:
        pass

    @abstractmethod
    def get_tool(self, name: str) -> Any:
        pass
