from abc import ABC, abstractmethod
from typing import Any, Dict


class GuardrailProvider(ABC):
    """Provider for input/output validation or filtering."""

    @abstractmethod
    def check_input(self, prompt: str, **kwargs) -> Dict[str, Any]:
        pass

    @abstractmethod
    def check_output(self, output: str, **kwargs) -> Dict[str, Any]:
        pass
