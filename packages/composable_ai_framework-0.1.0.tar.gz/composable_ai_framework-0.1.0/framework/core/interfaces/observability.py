from abc import ABC, abstractmethod
from typing import Any, Dict


class ObservabilityProvider(ABC):
    """Logs events, metrics, traces, etc."""

    @abstractmethod
    def log_event(self, name: str, attributes: Dict[str, Any] = None) -> None:
        pass

    @abstractmethod
    def record_metric(self, name: str, value: Any) -> None:
        pass
