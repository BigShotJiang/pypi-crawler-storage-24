from abc import ABC, abstractmethod
from typing import Any


class StateProvider(ABC):
    """Holds ephemeral or long lived state for a run."""

    @abstractmethod
    def set(self, key: str, value: Any) -> None:
        pass

    @abstractmethod
    def get(self, key: str) -> Any:
        pass

    @abstractmethod
    def clear(self) -> None:
        pass
