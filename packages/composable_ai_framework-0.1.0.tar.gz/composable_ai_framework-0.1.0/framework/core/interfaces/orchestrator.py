from abc import ABC, abstractmethod
from typing import Any, Dict


class OrchestratorProvider(ABC):
    """Manages multi-step workflows or agent execution."""

    @abstractmethod
    def run(self, plan: Dict[str, Any]) -> Any:
        pass
