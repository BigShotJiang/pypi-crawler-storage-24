from abc import ABC, abstractmethod


class IdentityProvider(ABC):
    """Provides identity information (e.g. user, session)."""

    @abstractmethod
    def get_user(self) -> str:
        pass

    @abstractmethod
    def get_session(self) -> str:
        pass
