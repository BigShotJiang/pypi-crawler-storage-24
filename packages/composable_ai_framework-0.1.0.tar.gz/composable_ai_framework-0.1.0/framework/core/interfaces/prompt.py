from abc import ABC, abstractmethod
from typing import Any, Dict


class PromptStoreProvider(ABC):
    """Retrieves stored prompts or templates."""

    @abstractmethod
    def get_prompt(self, name: str) -> str:
        pass

    @abstractmethod
    def save_prompt(self, name: str, prompt: str) -> None:
        pass
