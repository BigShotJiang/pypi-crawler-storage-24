from abc import ABC, abstractmethod
from typing import Any, Dict


class EvaluatorProvider(ABC):
    """Evaluates output quality or correctness."""

    @abstractmethod
    def evaluate(self, input_data: Any, output_data: Any) -> Dict[str, Any]:
        pass
