from .kernel import Kernel


class AIFramework:
    """High level entrypoint for applications.

    Usually clients will instantiate this class with a config file. The
    framework exposes a simple API for obtaining providers and running
    pipelines. The heavy lifting is done by the Kernel.
    """

    def __init__(self, config_path: str):
        self.kernel = Kernel.from_file(config_path)
        self.kernel.build()

    def get_provider(self, category: str):
        return self.kernel.get(category)

    def run_pipeline(self, pipeline, context: dict):
        return pipeline.run(context)
