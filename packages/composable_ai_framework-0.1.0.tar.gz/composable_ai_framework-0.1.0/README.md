# Composable AI Framework

This repository implements a pluggable, modular architecture for AI applications.
The core framework defines abstract interfaces for each layer (LLM, vector stores,
memory, guardrails, etc.) and uses a provider registry along with a configuration
kernel to instantiate concrete implementations.

## Key Concepts

- **Interfaces**: Defined in `framework/core/interfaces`. Business logic should
  depend only on these abstract base classes.
- **Providers**: Concrete implementations live under
  `framework/core/providers`. Each provider registers itself with a stable name
  using the `register_provider` decorator. Add new providers without touching
  core code.
- **Registry & Kernel**: `ProviderRegistry` holds available providers. `Kernel`
  builds provider instances from YAML configuration.
- **Pipeline**: Lightweight sequential middleware for processing requests.
- **Pluggability**: Swap entire tool stacks by editing config files. Providers
  do not import vendor SDKs directly.
- **Middleware**: Cross-cutting wrappers that can instrument any provider.

## Structure

See section `9. Repository Structure` of the design document. The code mirrors
that outline closely.

## Getting Started

```bash
cd d:/AIFramework/composable-ai-framework
python -m venv .venv
. .venv/Scripts/Activate.ps1   # or source .venv/bin/activate
pip install -r requirements.txt
pip install -e .               # optional if packaging
pytest                         # run the test suite
python main.py --config config/config.local.yaml
```

## Adding New Providers

1. Implement an `ABC` in `framework/core/interfaces` if a new category is
   needed.
2. Create a new provider module under `framework/core/providers/<category>`.
3. Use the `@register_provider("name")` decorator to register.
4. The provider will be discoverable automatically via the registry.
5. Update configuration to reference the new provider name.

## Tests

- Unit tests cover core utilities and ensure pluggability via configuration.
- Contract tests ensure each registered provider implements at least one
  interface.

---

This codebase is intentionally lightweight and self-contained to illustrate the
pluggability and modularity principles described in the design document.

Feel free to extend with real vendor SDKs, elaborate middleware, or agent
orchestrators as needed.
