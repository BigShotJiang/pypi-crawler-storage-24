"""
PandaTest 主客户端

Usage:
    from pandatest import PandaTest

    client = PandaTest(api_key="pk_xxx")

    # 全局资源
    projects = client.projects.list()
    devices  = client.devices.list()

    # 项目作用域 — 风格 A: project scope
    scope = client.project(123)
    scope.builds.list()
    scope.jobs.list()

    # 项目作用域 — 风格 B: 每模块单独传
    client.builds(123).list()
    client.jobs(123).list()
"""

from __future__ import annotations

from pandatest.api.base import BaseAPI
from pandatest.api.builds import BuildsAPI
from pandatest.api.devices import DevicesAPI
from pandatest.api.jobs import JobsAPI
from pandatest.api.projects import ProjectsAPI
from pandatest.api.tasks import TasksAPI
from pandatest.api.schedules import SchedulesAPI
from pandatest.config import Config
from pandatest.exceptions import ConfigError


class ProjectScope:
    """
    项目作用域，绑定 project_id 到所有项目级 API 模块。

    通过 ``client.project(123)`` 获取。
    """

    def __init__(self, base: BaseAPI, project_id: int):
        self._base = base
        self._project_id = project_id

    @property
    def builds(self) -> BuildsAPI:
        return BuildsAPI(self._base, project_id=self._project_id)

    @property
    def jobs(self) -> JobsAPI:
        return JobsAPI(self._base, project_id=self._project_id)

    @property
    def tasks(self) -> TasksAPI:
        return TasksAPI(self._base, project_id=self._project_id)

    @property
    def schedules(self) -> SchedulesAPI:
        return SchedulesAPI(self._base, project_id=self._project_id)

    def __repr__(self) -> str:
        return f"ProjectScope(project_id={self._project_id})"


class PandaTest:
    """
    PandaTest SDK 主客户端。

    组合所有 API 模块，提供统一入口。

    Args:
        api_key: API Key (pk_xxx)
        base_url: 服务器地址 (默认从环境变量/配置文件读取)
    """

    def __init__(
        self,
        api_key: str | None = None,
        base_url: str | None = None,
    ):
        self._config = Config.load(
            api_key=api_key,
            base_url=base_url,
        )

        if not self._config.api_key:
            raise ConfigError(
                "API key is required. Provide via:\n"
                "  - PandaTest(api_key='pk_xxx')\n"
                "  - Environment variable: PANDA_API_KEY\n"
                "  - Config file: panda config set --api-key pk_xxx"
            )

        self._base_api = BaseAPI(self._config)

        # 全局资源（不依赖 project_id）
        self.projects = ProjectsAPI(self._base_api)
        self.devices = DevicesAPI(self._base_api)

        # 项目级资源（可通过 __call__ 绑定 project_id，也可使用 Config 默认值）
        self.builds = BuildsAPI(self._base_api)
        self.jobs = JobsAPI(self._base_api)
        self.tasks = TasksAPI(self._base_api)
        self.schedules = SchedulesAPI(self._base_api)

    def project(self, project_id: int) -> ProjectScope:
        """
        返回绑定到指定项目的作用域对象。

        Usage::

            scope = client.project(123)
            scope.builds.list()
            scope.jobs.list()
        """
        return ProjectScope(self._base_api, project_id)

    @property
    def config(self) -> Config:
        """当前配置"""
        return self._config

    def close(self) -> None:
        """关闭 HTTP 客户端连接"""
        if hasattr(self, "devices") and self.devices:
            self.devices.close()
        self._base_api.close()

    def __enter__(self) -> PandaTest:
        return self

    def __exit__(self, *args) -> None:
        self.close()

    def __repr__(self) -> str:
        masked_key = self._config.api_key[:6] + "..." if self._config.api_key else "None"
        return (
            f"PandaTest(base_url={self._config.base_url!r}, "
            f"api_key={masked_key!r})"
        )
