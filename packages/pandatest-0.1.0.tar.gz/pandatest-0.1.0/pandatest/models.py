"""
PandaTest SDK 数据模型

使用 dataclass 定义，提供从 API JSON 到 Python 对象的映射。
所有模型都支持从 dict 构造，未知字段会被忽略。
"""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime
from typing import Any


def _parse_datetime(value: str | None) -> datetime | None:
    """解析 ISO 格式的日期时间字符串"""
    if not value:
        return None
    try:
        # 兼容 Django 的 ISO 格式 (带或不带时区)
        return datetime.fromisoformat(value.replace("Z", "+00:00"))
    except (ValueError, AttributeError):
        return None


def _from_dict(cls, data: dict) -> Any:
    """从 dict 创建 dataclass 实例，忽略未知字段"""
    if not data:
        return None
    known_fields = {f.name for f in cls.__dataclass_fields__.values()}
    filtered = {k: v for k, v in data.items() if k in known_fields}
    return cls(**filtered)


# ---------------------------------------------------------------------------
# Build
# ---------------------------------------------------------------------------


@dataclass
class Build:
    """构建配置"""

    id: str = ""
    name: str = ""
    description: str = ""
    status: str = ""
    app: int | None = None
    app_name: str = ""
    app_icon: str = ""
    app_package_name: str = ""
    app_version: str = ""
    project: int | None = None
    project_name: str = ""
    test_script: int | None = None
    script_name: str = ""
    source_type: str = ""
    devices: list[dict] = field(default_factory=list)
    target_devices: list[dict] = field(default_factory=list)
    device_filter: dict = field(default_factory=dict)
    environment_vars: dict = field(default_factory=dict)
    execution_config: dict = field(default_factory=dict)
    notification_config: dict = field(default_factory=dict)
    channel_configs: list[dict] = field(default_factory=list)
    auto_launch: bool = True
    auto_sync_script: bool = True
    runner_image: str = ""
    runner_image_build_status: str = ""
    last_runner_build_at: str | None = None
    total_jobs: int = 0
    last_job_at: str | None = None
    last_job_status: str = ""
    sort_order: str = ""
    is_pinned: bool = False
    created_by: int | None = None
    created_by_name: str = ""
    created_at: str = ""
    updated_at: str = ""

    @classmethod
    def from_dict(cls, data: dict) -> Build:
        return _from_dict(cls, data)


# ---------------------------------------------------------------------------
# TriggerResult
# ---------------------------------------------------------------------------


@dataclass
class TriggerResult:
    """触发构建的返回结果"""

    job_id: str = ""
    celery_task_id: str = ""
    status: str = ""

    @classmethod
    def from_dict(cls, data: dict) -> TriggerResult:
        return _from_dict(cls, data)


# ---------------------------------------------------------------------------
# Job
# ---------------------------------------------------------------------------


@dataclass
class Job:
    """执行任务（由触发 Build 产生）"""

    id: str = ""
    build: str = ""
    build_name: str = ""
    job_number: int = 0
    status: str = ""
    progress: int = 0
    trigger_type: str = ""
    started_by: int | None = None
    started_by_name: str = ""
    app_name: str = ""
    app_icon: str = ""
    app_package_name: str = ""
    platform: str = ""
    script_name: str = ""
    branch: str = ""
    framework: str = ""
    total_tasks: int = 0
    completed_tasks: int = 0
    success_tasks: int = 0
    failed_tasks: int = 0
    stats: dict = field(default_factory=dict)
    pass_rate: float | None = None
    tags: list[str] = field(default_factory=list)
    timeout: int = 0
    error_message: str = ""
    created_at: str = ""
    started_at: str | None = None
    completed_at: str | None = None
    duration: float | None = None

    @classmethod
    def from_dict(cls, data: dict) -> Job:
        return _from_dict(cls, data)

    @property
    def is_terminal(self) -> bool:
        """是否已结束"""
        return self.status in ("success", "failed", "cancelled", "timeout")

    @property
    def is_success(self) -> bool:
        return self.status == "success"


# ---------------------------------------------------------------------------
# Task
# ---------------------------------------------------------------------------


@dataclass
class Task:
    """单个设备上的执行任务"""

    id: str = ""
    job_id: str = ""
    build_name: str = ""
    device_name: str = ""
    device_serial: str = ""
    device_platform: str = ""
    device_version: str = ""
    device_brand: str = ""
    agent_name: str = ""
    agent_ip: str = ""
    agent_port: int = 0
    status: str = ""
    progress: int = 0
    stats: dict = field(default_factory=dict)
    scenarios: list = field(default_factory=list)
    video_url: str = ""
    logs_url: str = ""
    queue_position: int | None = None
    queued_at: str | None = None
    timeout: int = 0
    error_message: str = ""
    created_at: str = ""
    started_at: str | None = None
    completed_at: str | None = None
    duration: float | None = None

    @classmethod
    def from_dict(cls, data: dict) -> Task:
        return _from_dict(cls, data)

    @property
    def is_terminal(self) -> bool:
        return self.status in ("success", "failed", "partial", "skipped", "cancelled", "timeout")


# ---------------------------------------------------------------------------
# Schedule
# ---------------------------------------------------------------------------


@dataclass
class Schedule:
    """定时调度"""

    id: str = ""
    name: str = ""
    description: str = ""
    build: str = ""
    build_name: str = ""
    build_description: str = ""
    frequency: str = ""
    cron_expression: str = ""
    interval_seconds: int | None = None
    time_of_day: str | None = None
    day_of_week: int | None = None
    day_of_month: int | None = None
    timezone: str = "Asia/Shanghai"
    status: str = ""
    is_enabled: bool = True
    total_runs: int = 0
    success_runs: int = 0
    failed_runs: int = 0
    last_run_at: str | None = None
    last_run_status: str = ""
    last_job_id: str = ""
    next_run_at: str | None = None
    celery_schedule_id: str = ""
    created_by: int | None = None
    created_by_name: str = ""
    created_at: str = ""
    updated_at: str = ""

    @classmethod
    def from_dict(cls, data: dict) -> Schedule:
        return _from_dict(cls, data)


# ---------------------------------------------------------------------------
# Pagination
# ---------------------------------------------------------------------------


@dataclass
class Pagination:
    """分页信息"""

    total: int = 0
    page: int = 1
    page_size: int = 20
    total_pages: int = 0

    @classmethod
    def from_dict(cls, data: dict) -> Pagination:
        return _from_dict(cls, data)


@dataclass
class PaginatedList:
    """分页列表响应"""

    items: list = field(default_factory=list)
    pagination: Pagination = field(default_factory=Pagination)
