"""
PandaTest CLI 入口

Usage:
    pt config set --api-key pk_xxx --url https://your-domain.com
    pt config show
    pt run --build build-14-xxx --wait
    pt builds list
    pt jobs list --build build-14-xxx
"""

from __future__ import annotations

import click

from pandatest.cli.commands.config_cmd import config
from pandatest.cli.commands.run import run
from pandatest.cli.commands.builds import builds
from pandatest.cli.commands.devices import devices
from pandatest.cli.commands.jobs import jobs
from pandatest.cli.commands.tasks import tasks
from pandatest.cli.commands.schedules import schedules


@click.group()
@click.version_option(package_name="pandatest")
def cli():
    """PandaTest CLI — 移动端自动化测试平台"""
    pass


# 注册子命令
cli.add_command(config)
cli.add_command(run)
cli.add_command(builds)
cli.add_command(devices)
cli.add_command(jobs)
cli.add_command(tasks)
cli.add_command(schedules)


if __name__ == "__main__":
    cli()
