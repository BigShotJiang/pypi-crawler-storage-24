"""
panda tasks — Task 查看命令
"""

from __future__ import annotations

import json
import sys

import click
from rich.console import Console
from rich.table import Table

from pandatest.cli.commands._helpers import create_scoped_client

console = Console()


@click.group()
def tasks():
    """查看 Task 执行详情"""
    pass


@tasks.command("list")
@click.option("--job", "job_id", help="按 Job ID 过滤")
@click.option("--status", help="按状态过滤")
@click.option("--page", type=int, default=1, help="页码")
@click.option("--page-size", type=int, default=20, help="每页数量")
@click.option("--api-key", envvar="PANDA_API_KEY", hidden=True)
@click.option("--url", envvar="PANDA_API_URL", hidden=True)
@click.option("--project", type=int, envvar="PANDA_PROJECT_ID", hidden=True)
@click.option("--json-output", "as_json", is_flag=True, help="输出 JSON")
def list_tasks(job_id, status, page, page_size, api_key, url, project, as_json):
    """列出 Task"""
    scope = create_scoped_client(api_key=api_key, base_url=url, project_id=project)

    try:
        result = scope.tasks.list(
            job_id=job_id, status=status,
            page=page, page_size=page_size,
        )
    except Exception as e:
        console.print(f"[red]Error:[/red] {e}")
        sys.exit(1)

    if as_json:
        data = [_task_to_dict(t) for t in result.items]
        console.print_json(json.dumps(data, ensure_ascii=False))
        return

    if not result.items:
        console.print("[dim]No tasks found.[/dim]")
        return

    table = Table(title=f"Tasks (page {result.pagination.page}/{result.pagination.total_pages})")
    table.add_column("ID", style="cyan", no_wrap=True, max_width=30)
    table.add_column("Device")
    table.add_column("Platform")
    table.add_column("Status")
    table.add_column("Progress", justify="right")
    table.add_column("Duration", justify="right")

    for t in result.items:
        duration = f"{t.duration:.0f}s" if t.duration else "-"
        table.add_row(
            t.id,
            t.device_name or t.device_serial or "-",
            t.device_platform or "-",
            _status_badge(t.status),
            f"{t.progress}%",
            duration,
        )

    console.print(table)


@tasks.command("get")
@click.argument("task_id")
@click.option("--api-key", envvar="PANDA_API_KEY", hidden=True)
@click.option("--url", envvar="PANDA_API_URL", hidden=True)
@click.option("--project", type=int, envvar="PANDA_PROJECT_ID", hidden=True)
@click.option("--json-output", "as_json", is_flag=True, help="输出 JSON")
def get_task(task_id, api_key, url, project, as_json):
    """获取 Task 详情"""
    scope = create_scoped_client(api_key=api_key, base_url=url, project_id=project)

    try:
        task = scope.tasks.get(task_id)
    except Exception as e:
        console.print(f"[red]Error:[/red] {e}")
        sys.exit(1)

    if as_json:
        console.print_json(json.dumps(_task_to_dict(task), ensure_ascii=False))
        return

    table = Table(show_header=False, box=None, padding=(0, 2))
    table.add_column(width=16, style="cyan")
    table.add_column()
    table.add_row("Task ID", task.id)
    table.add_row("Job", task.job_id)
    table.add_row("Device", task.device_name or task.device_serial)
    table.add_row("Platform", f"{task.device_platform} {task.device_version}")
    table.add_row("Status", _status_badge(task.status))
    table.add_row("Progress", f"{task.progress}%")
    if task.duration:
        table.add_row("Duration", f"{task.duration:.1f}s")
    if task.error_message:
        table.add_row("Error", f"[red]{task.error_message}[/red]")

    console.print(table)


@tasks.command("logs")
@click.argument("task_id")
@click.option("--api-key", envvar="PANDA_API_KEY", hidden=True)
@click.option("--url", envvar="PANDA_API_URL", hidden=True)
@click.option("--project", type=int, envvar="PANDA_PROJECT_ID", hidden=True)
def task_logs(task_id, api_key, url, project):
    """获取 Task 日志"""
    scope = create_scoped_client(api_key=api_key, base_url=url, project_id=project)

    try:
        result = scope.tasks.logs(task_id)
    except Exception as e:
        console.print(f"[red]Error:[/red] {e}")
        sys.exit(1)

    logs_url = result.get("logs_url", "")
    logs_content = result.get("logs", "")

    if logs_url:
        console.print(f"[bold]Logs URL:[/bold] {logs_url}")
    if logs_content:
        console.print(f"\n{logs_content}")
    if not logs_url and not logs_content:
        console.print("[dim]No logs available.[/dim]")


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _task_to_dict(t) -> dict:
    return {
        "id": t.id,
        "job_id": t.job_id,
        "device_name": t.device_name,
        "device_platform": t.device_platform,
        "status": t.status,
        "progress": t.progress,
        "duration": t.duration,
        "error_message": t.error_message,
    }


def _status_badge(status: str) -> str:
    color_map = {
        "pending": "yellow",
        "queued": "yellow",
        "running": "blue",
        "success": "green",
        "failed": "red",
        "partial": "yellow",
        "skipped": "dim",
        "cancelled": "dim",
        "timeout": "red",
    }
    color = color_map.get(status, "white")
    return f"[{color}]{status}[/{color}]"
