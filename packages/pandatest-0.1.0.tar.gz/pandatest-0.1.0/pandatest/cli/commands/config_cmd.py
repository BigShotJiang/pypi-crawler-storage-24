"""
panda config — 配置管理命令
"""

from __future__ import annotations

import click
from rich.console import Console
from rich.table import Table

from pandatest.config import Config, CONFIG_FILE

console = Console()


@click.group()
def config():
    """管理 PandaTest 配置"""
    pass


@config.command()
@click.option("--api-key", help="API Key (pk_xxx)")
@click.option("--url", help="服务器地址")
def set(api_key: str | None, url: str | None):
    """设置配置项"""
    if not any([api_key, url]):
        console.print("[yellow]请至少指定一个配置项[/yellow]")
        console.print("  --api-key  API Key")
        console.print("  --url      服务器地址")
        return

    path = Config.save_to_file(api_key=api_key, base_url=url)
    console.print(f"[green]✓[/green] 配置已保存到 {path}")

    if api_key:
        masked = api_key[:6] + "..." + api_key[-4:]
        console.print(f"  api_key = {masked}")
    if url:
        console.print(f"  base_url = {url}")


@config.command()
def show():
    """显示当前配置"""
    cfg = Config.load()

    table = Table(title="PandaTest Configuration", show_header=True)
    table.add_column("Key", style="cyan")
    table.add_column("Value")
    table.add_column("Source", style="dim")

    # API Key
    if cfg.api_key:
        masked = cfg.api_key[:6] + "..." + cfg.api_key[-4:]
        table.add_row("api_key", masked, _detect_source("api_key"))
    else:
        table.add_row("api_key", "[red]Not set[/red]", "")

    # Base URL
    table.add_row("base_url", cfg.base_url, _detect_source("base_url"))

    console.print(table)
    console.print(f"\nConfig file: {CONFIG_FILE}")
    console.print("[dim]project_id 已移至 SDK 调用层：client.project(id) 或 client.builds(id)[/dim]")


def _detect_source(key: str) -> str:
    """检测配置来源"""
    import os
    from pandatest.config import ENV_API_KEY, ENV_API_URL

    env_map = {
        "api_key": ENV_API_KEY,
        "base_url": ENV_API_URL,
    }

    env_var = env_map.get(key)
    if env_var and os.environ.get(env_var):
        return f"env ({env_var})"

    file_config = Config._load_from_file()
    if key in file_config:
        return "config file"

    return "default"
