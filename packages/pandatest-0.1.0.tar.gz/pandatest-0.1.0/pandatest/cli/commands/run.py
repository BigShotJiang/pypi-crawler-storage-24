"""
panda run — 触发构建并等待（CI/CD 核心命令）

Usage:
    panda run --build build-14-xxx
    panda run --build build-14-xxx --wait
    panda run --build build-14-xxx --wait --timeout 600
"""

from __future__ import annotations

import sys

import click
from rich.console import Console
from rich.live import Live
from rich.table import Table
from rich.text import Text

from pandatest.cli.commands._helpers import create_scoped_client

console = Console()


@click.command()
@click.option("--build", "build_id", required=True, help="构建 ID (例: build-14-xxx)")
@click.option("--wait", is_flag=True, default=False, help="等待 Job 完成")
@click.option("--timeout", type=int, default=600, help="等待超时 (秒, 默认 600)")
@click.option("--api-key", envvar="PANDA_API_KEY", help="API Key")
@click.option("--url", envvar="PANDA_API_URL", help="服务器地址")
@click.option("--project", type=int, envvar="PANDA_PROJECT_ID", help="项目 ID")
def run(build_id: str, wait: bool, timeout: int, api_key: str | None, url: str | None, project: int | None):
    """触发构建并可选等待完成"""
    scope = create_scoped_client(api_key=api_key, base_url=url, project_id=project)

    # 1. 触发构建
    console.print(f"[bold]Triggering build:[/bold] {build_id}")
    try:
        result = scope.builds.trigger(build_id)
    except Exception as e:
        console.print(f"[red]✗ Failed to trigger build:[/red] {e}")
        sys.exit(1)

    console.print(f"[green]✓[/green] Job created: [bold]{result.job_id}[/bold]")

    if not wait:
        console.print(f"  Status: {result.status}")
        console.print("\nTip: Use [cyan]--wait[/cyan] to wait for completion")
        return

    # 2. 等待完成
    console.print(f"\nWaiting for job to complete (timeout: {timeout}s)...\n")

    try:
        with Live(console=console, refresh_per_second=2) as live:
            def on_progress(job):
                table = Table(show_header=False, box=None, padding=(0, 2))
                table.add_column(width=14)
                table.add_column()
                table.add_row("Status", _status_text(job.status))
                table.add_row("Progress", f"{job.progress}%")
                if job.total_tasks > 0:
                    table.add_row(
                        "Tasks",
                        f"{job.completed_tasks}/{job.total_tasks} "
                        f"([green]{job.success_tasks}[/green] passed, "
                        f"[red]{job.failed_tasks}[/red] failed)",
                    )
                live.update(table)

            job = scope.jobs.wait(
                result.job_id,
                timeout=timeout,
                on_progress=on_progress,
            )
    except Exception as e:
        console.print(f"\n[red]✗ Error:[/red] {e}")
        sys.exit(1)

    # 3. 输出结果
    console.print()
    if job.is_success:
        console.print(f"[bold green]✓ Job completed successfully[/bold green]")
    else:
        console.print(f"[bold red]✗ Job finished with status: {job.status}[/bold red]")

    # 摘要表格
    table = Table(show_header=False, box=None, padding=(0, 2))
    table.add_column(width=14)
    table.add_column()
    table.add_row("Job ID", job.id)
    table.add_row("Status", _status_text(job.status))
    if job.total_tasks > 0:
        table.add_row(
            "Tasks",
            f"{job.completed_tasks}/{job.total_tasks} "
            f"([green]{job.success_tasks}[/green] passed, "
            f"[red]{job.failed_tasks}[/red] failed)",
        )
    if job.pass_rate is not None:
        table.add_row("Pass Rate", f"{job.pass_rate:.1f}%")
    if job.duration:
        table.add_row("Duration", f"{job.duration:.1f}s")
    console.print(table)

    # CI 退出码
    if not job.is_success:
        sys.exit(1)


def _status_text(status: str) -> Text:
    """格式化状态文本"""
    color_map = {
        "pending": "yellow",
        "queued": "yellow",
        "running": "blue",
        "success": "green",
        "failed": "red",
        "cancelled": "dim",
        "timeout": "red",
    }
    color = color_map.get(status, "white")
    return Text(status, style=f"bold {color}")
