"""
panda jobs — Job 管理命令
"""

from __future__ import annotations

import json
import sys

import click
from rich.console import Console
from rich.table import Table

from pandatest.cli.commands._helpers import create_scoped_client

console = Console()


@click.group()
def jobs():
    """管理 Job 执行"""
    pass


@jobs.command("list")
@click.option("--build", "build_id", help="按构建 ID 过滤")
@click.option("--status", help="按状态过滤 (pending/running/success/failed/cancelled)")
@click.option("--page", type=int, default=1, help="页码")
@click.option("--page-size", type=int, default=20, help="每页数量")
@click.option("--api-key", envvar="PANDA_API_KEY", hidden=True)
@click.option("--url", envvar="PANDA_API_URL", hidden=True)
@click.option("--project", type=int, envvar="PANDA_PROJECT_ID", hidden=True)
@click.option("--json-output", "as_json", is_flag=True, help="输出 JSON")
def list_jobs(build_id, status, page, page_size, api_key, url, project, as_json):
    """列出 Job"""
    scope = create_scoped_client(api_key=api_key, base_url=url, project_id=project)

    try:
        result = scope.jobs.list(
            build_id=build_id, status=status,
            page=page, page_size=page_size,
        )
    except Exception as e:
        console.print(f"[red]Error:[/red] {e}")
        sys.exit(1)

    if as_json:
        data = [_job_to_dict(j) for j in result.items]
        console.print_json(json.dumps(data, ensure_ascii=False))
        return

    if not result.items:
        console.print("[dim]No jobs found.[/dim]")
        return

    table = Table(title=f"Jobs (page {result.pagination.page}/{result.pagination.total_pages})")
    table.add_column("ID", style="cyan", no_wrap=True, max_width=30)
    table.add_column("Build", max_width=20)
    table.add_column("#", justify="right")
    table.add_column("Status")
    table.add_column("Progress", justify="right")
    table.add_column("Tasks", justify="right")
    table.add_column("Duration", justify="right")

    for j in result.items:
        duration = f"{j.duration:.0f}s" if j.duration else "-"
        table.add_row(
            j.id,
            j.build_name or "-",
            str(j.job_number),
            _status_badge(j.status),
            f"{j.progress}%",
            f"{j.success_tasks}/{j.total_tasks}",
            duration,
        )

    console.print(table)


@jobs.command("get")
@click.argument("job_id")
@click.option("--api-key", envvar="PANDA_API_KEY", hidden=True)
@click.option("--url", envvar="PANDA_API_URL", hidden=True)
@click.option("--project", type=int, envvar="PANDA_PROJECT_ID", hidden=True)
@click.option("--json-output", "as_json", is_flag=True, help="输出 JSON")
def get_job(job_id, api_key, url, project, as_json):
    """获取 Job 详情"""
    scope = create_scoped_client(api_key=api_key, base_url=url, project_id=project)

    try:
        job = scope.jobs.get(job_id)
    except Exception as e:
        console.print(f"[red]Error:[/red] {e}")
        sys.exit(1)

    if as_json:
        console.print_json(json.dumps(_job_to_dict(job), ensure_ascii=False))
        return

    table = Table(show_header=False, box=None, padding=(0, 2))
    table.add_column(width=16, style="cyan")
    table.add_column()
    table.add_row("Job ID", job.id)
    table.add_row("Build", job.build_name or job.build)
    table.add_row("Job #", str(job.job_number))
    table.add_row("Status", _status_badge(job.status))
    table.add_row("Progress", f"{job.progress}%")
    table.add_row("Tasks", f"{job.completed_tasks}/{job.total_tasks}")
    table.add_row("  Passed", f"[green]{job.success_tasks}[/green]")
    table.add_row("  Failed", f"[red]{job.failed_tasks}[/red]")
    if job.pass_rate is not None:
        table.add_row("Pass Rate", f"{job.pass_rate:.1f}%")
    if job.duration:
        table.add_row("Duration", f"{job.duration:.1f}s")
    table.add_row("Trigger", job.trigger_type)
    table.add_row("Created", job.created_at)

    console.print(table)


@jobs.command("cancel")
@click.argument("job_id")
@click.option("--api-key", envvar="PANDA_API_KEY", hidden=True)
@click.option("--url", envvar="PANDA_API_URL", hidden=True)
@click.option("--project", type=int, envvar="PANDA_PROJECT_ID", hidden=True)
def cancel_job(job_id, api_key, url, project):
    """取消 Job"""
    scope = create_scoped_client(api_key=api_key, base_url=url, project_id=project)

    try:
        result = scope.jobs.cancel(job_id)
    except Exception as e:
        console.print(f"[red]Error:[/red] {e}")
        sys.exit(1)

    console.print(f"[green]✓[/green] 任务已取消")
    console.print(f"  Cancelled tasks: {result.get('cancelled_tasks', 0)}")


@jobs.command("rerun")
@click.argument("job_id")
@click.option("--api-key", envvar="PANDA_API_KEY", hidden=True)
@click.option("--url", envvar="PANDA_API_URL", hidden=True)
@click.option("--project", type=int, envvar="PANDA_PROJECT_ID", hidden=True)
def rerun_job(job_id, api_key, url, project):
    """重新运行 Job"""
    scope = create_scoped_client(api_key=api_key, base_url=url, project_id=project)

    try:
        result = scope.jobs.rerun(job_id)
    except Exception as e:
        console.print(f"[red]Error:[/red] {e}")
        sys.exit(1)

    console.print(f"[green]✓[/green] Job rerun created!")
    console.print(f"  New Job ID: [bold]{result.get('new_job_id', 'N/A')}[/bold]")


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _job_to_dict(j) -> dict:
    return {
        "id": j.id,
        "build": j.build,
        "build_name": j.build_name,
        "job_number": j.job_number,
        "status": j.status,
        "progress": j.progress,
        "total_tasks": j.total_tasks,
        "success_tasks": j.success_tasks,
        "failed_tasks": j.failed_tasks,
        "pass_rate": j.pass_rate,
        "duration": j.duration,
        "trigger_type": j.trigger_type,
        "created_at": j.created_at,
    }


def _status_badge(status: str) -> str:
    color_map = {
        "pending": "yellow",
        "queued": "yellow",
        "running": "blue",
        "success": "green",
        "failed": "red",
        "cancelled": "dim",
        "timeout": "red",
    }
    color = color_map.get(status, "white")
    return f"[{color}]{status}[/{color}]"
