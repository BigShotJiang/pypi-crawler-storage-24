"""
CLI 通用辅助函数
"""

from __future__ import annotations

import sys
from typing import Union

from rich.console import Console

from pandatest.client import PandaTest, ProjectScope
from pandatest.exceptions import ConfigError

console = Console()


def create_client(
    api_key: str | None = None,
    base_url: str | None = None,
) -> PandaTest:
    """创建 SDK 客户端，处理配置错误"""
    try:
        return PandaTest(api_key=api_key, base_url=base_url)
    except ConfigError as e:
        console.print(f"[red]Configuration error:[/red] {e.message}")
        console.print("\nRun [cyan]panda config set --api-key YOUR_KEY[/cyan] to configure.")
        sys.exit(1)


def create_scoped_client(
    api_key: str | None = None,
    base_url: str | None = None,
    project_id: int | None = None,
) -> Union[PandaTest, ProjectScope]:
    """
    创建 SDK 客户端。

    若提供 project_id 则返回 ProjectScope（自动绑定项目作用域），
    否则返回 PandaTest 实例。
    """
    client = create_client(api_key=api_key, base_url=base_url)
    if project_id is not None:
        return client.project(project_id)
    return client
