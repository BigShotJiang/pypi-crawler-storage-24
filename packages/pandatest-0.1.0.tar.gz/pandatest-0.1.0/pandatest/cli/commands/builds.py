"""
panda builds — 构建管理命令
"""

from __future__ import annotations

import json
import sys

import click
from rich.console import Console
from rich.table import Table

from pandatest.cli.commands._helpers import create_scoped_client

console = Console()


@click.group()
def builds():
    """管理构建配置"""
    pass


@builds.command("list")
@click.option("--page", type=int, default=1, help="页码")
@click.option("--page-size", type=int, default=20, help="每页数量")
@click.option("--api-key", envvar="PANDA_API_KEY", hidden=True)
@click.option("--url", envvar="PANDA_API_URL", hidden=True)
@click.option("--project", type=int, envvar="PANDA_PROJECT_ID", hidden=True)
@click.option("--json-output", "as_json", is_flag=True, help="输出 JSON")
def list_builds(page: int, page_size: int, api_key, url, project, as_json: bool):
    """列出所有构建"""
    scope = create_scoped_client(api_key=api_key, base_url=url, project_id=project)

    try:
        result = scope.builds.list(page=page, page_size=page_size)
    except Exception as e:
        console.print(f"[red]Error:[/red] {e}")
        sys.exit(1)

    if as_json:
        data = [_build_to_dict(b) for b in result.items]
        console.print_json(json.dumps(data, ensure_ascii=False))
        return

    if not result.items:
        console.print("[dim]No builds found.[/dim]")
        return

    table = Table(title=f"Builds (page {result.pagination.page}/{result.pagination.total_pages})")
    table.add_column("ID", style="cyan", no_wrap=True)
    table.add_column("Name", style="bold")
    table.add_column("App")
    table.add_column("Status")
    table.add_column("Jobs", justify="right")
    table.add_column("Last Job")

    for b in result.items:
        table.add_row(
            b.id,
            b.name,
            b.app_name or "-",
            _status_badge(b.status),
            str(b.total_jobs),
            b.last_job_status or "-",
        )

    console.print(table)


@builds.command("get")
@click.argument("build_id")
@click.option("--api-key", envvar="PANDA_API_KEY", hidden=True)
@click.option("--url", envvar="PANDA_API_URL", hidden=True)
@click.option("--project", type=int, envvar="PANDA_PROJECT_ID", hidden=True)
@click.option("--json-output", "as_json", is_flag=True, help="输出 JSON")
def get_build(build_id: str, api_key, url, project, as_json: bool):
    """获取构建详情"""
    scope = create_scoped_client(api_key=api_key, base_url=url, project_id=project)

    try:
        build = scope.builds.get(build_id)
    except Exception as e:
        console.print(f"[red]Error:[/red] {e}")
        sys.exit(1)

    if as_json:
        console.print_json(json.dumps(_build_to_dict(build), ensure_ascii=False))
        return

    table = Table(show_header=False, box=None, padding=(0, 2))
    table.add_column(width=16, style="cyan")
    table.add_column()
    table.add_row("ID", build.id)
    table.add_row("Name", build.name)
    table.add_row("Description", build.description or "-")
    table.add_row("Status", _status_badge(build.status))
    table.add_row("App", build.app_name or "-")
    table.add_row("Script", build.script_name or "-")
    table.add_row("Total Jobs", str(build.total_jobs))
    table.add_row("Created", build.created_at)

    console.print(table)


@builds.command("create")
@click.option("--name", required=True, help="构建名称")
@click.option("--app", "app_id", required=True, type=int, help="应用 ID")
@click.option("--description", default="", help="描述")
@click.option("--test-script", type=int, default=None, help="测试脚本 ID")
@click.option("--target-devices", default=None, help="目标设备 ID，逗号分隔 (例: 1,2,3)")
@click.option("--platform", type=click.Choice(["android", "ios"]), default=None, help="设备平台过滤")
@click.option("--parallel/--no-parallel", default=None, help="是否并行执行")
@click.option("--concurrency", type=int, default=None, help="并发数")
@click.option("--timeout", type=int, default=None, help="Job 超时 (秒)")
@click.option("--task-timeout", type=int, default=None, help="单任务超时 (秒)")
@click.option("--execution-mode", type=click.Choice(["replicate", "distribute"]), default=None, help="执行模式: replicate=每台设备完整执行, distribute=用例分发")
@click.option("--test-nodeids", default=None, help="测试用例 node IDs，逗号分隔")
@click.option("--pytest-k", "k_expression", default=None, help="pytest -k 表达式")
@click.option("--pytest-m", "marker_expression", default=None, help="pytest -m marker 表达式")
@click.option("--reruns", type=int, default=None, help="失败重试次数")
@click.option("--reruns-delay", type=int, default=None, help="失败重试间隔 (秒)")
@click.option("--maxfail", type=int, default=None, help="最大失败数后停止")
@click.option("--exit-first", is_flag=True, default=False, help="首个失败即停止")
@click.option("--verbosity", type=click.Choice(["default", "q", "v", "vv"]), default=None, help="pytest 输出详细级别")
@click.option("--extra-args", default=None, help="额外 pytest 参数 (原样拼接)")
@click.option("--auto-launch/--no-auto-launch", default=None, help="安装后自动打开应用")
@click.option("--skip-install", is_flag=True, default=False, help="已有应用跳过安装")
@click.option("--env", "env_vars", multiple=True, help="环境变量 KEY=VALUE，可多次指定")
@click.option("--api-key", envvar="PANDA_API_KEY", hidden=True)
@click.option("--url", envvar="PANDA_API_URL", hidden=True)
@click.option("--project", type=int, envvar="PANDA_PROJECT_ID", hidden=True)
def create_build(
    name: str,
    app_id: int,
    description: str,
    test_script: int | None,
    target_devices: str | None,
    platform: str | None,
    parallel: bool | None,
    concurrency: int | None,
    timeout: int | None,
    task_timeout: int | None,
    execution_mode: str | None,
    test_nodeids: str | None,
    k_expression: str | None,
    marker_expression: str | None,
    reruns: int | None,
    reruns_delay: int | None,
    maxfail: int | None,
    exit_first: bool,
    verbosity: str | None,
    extra_args: str | None,
    auto_launch: bool | None,
    skip_install: bool,
    env_vars: tuple[str, ...],
    api_key,
    url,
    project,
):
    """创建构建"""
    scope = create_scoped_client(api_key=api_key, base_url=url, project_id=project)

    kwargs: dict = {}

    if test_script is not None:
        kwargs["test_script"] = test_script

    if target_devices:
        kwargs["target_devices"] = [
            {"device_id": int(d.strip())} for d in target_devices.split(",") if d.strip()
        ]

    if platform:
        kwargs["device_filter"] = {"platform": platform}

    # execution_config
    execution_config: dict = {}
    if parallel is not None:
        execution_config["parallel"] = parallel
    if concurrency is not None:
        execution_config["concurrency"] = concurrency
    if timeout is not None:
        execution_config["timeout"] = timeout
    if task_timeout is not None:
        execution_config["task_timeout"] = task_timeout
    if execution_mode is not None:
        execution_config["execution_mode"] = execution_mode
    if test_nodeids:
        execution_config["test_nodeids"] = [n.strip() for n in test_nodeids.split(",") if n.strip()]

    # framework_options
    framework_options: dict = {}
    if k_expression is not None:
        framework_options["k_expression"] = k_expression
    if marker_expression is not None:
        framework_options["marker_expression"] = marker_expression
    if reruns is not None:
        framework_options["reruns"] = reruns
    if reruns_delay is not None:
        framework_options["reruns_delay"] = reruns_delay
    if maxfail is not None:
        framework_options["maxfail"] = maxfail
    if exit_first:
        framework_options["exit_first"] = True
    if verbosity is not None:
        framework_options["verbosity"] = verbosity
    if extra_args is not None:
        framework_options["additional_args"] = extra_args
    if framework_options:
        execution_config["framework_options"] = framework_options

    if execution_config:
        kwargs["execution_config"] = execution_config

    # App behavior
    if auto_launch is not None:
        kwargs["auto_launch"] = auto_launch
    if skip_install:
        kwargs["skip_install"] = True

    if env_vars:
        env_dict = {}
        for pair in env_vars:
            if "=" not in pair:
                console.print(f"[red]Error:[/red] Invalid env format: {pair!r} (expected KEY=VALUE)")
                sys.exit(1)
            k, v = pair.split("=", 1)
            env_dict[k] = v
        kwargs["environment_vars"] = env_dict

    try:
        build = scope.builds.create(name=name, app=app_id, description=description, **kwargs)
    except Exception as e:
        console.print(f"[red]Error:[/red] {e}")
        sys.exit(1)

    console.print(f"[green]✓[/green] Build created: [bold]{build.id}[/bold]")
    console.print(f"  Name: {build.name}")


@builds.command("trigger")
@click.argument("build_id")
@click.option("--timeout", type=int, help="整体超时 (秒)")
@click.option("--task-timeout", type=int, help="单任务超时 (秒)")
@click.option("--api-key", envvar="PANDA_API_KEY", hidden=True)
@click.option("--url", envvar="PANDA_API_URL", hidden=True)
@click.option("--project", type=int, envvar="PANDA_PROJECT_ID", hidden=True)
def trigger_build(build_id: str, timeout, task_timeout, api_key, url, project):
    """触发构建"""
    scope = create_scoped_client(api_key=api_key, base_url=url, project_id=project)

    kwargs = {}
    if timeout is not None:
        kwargs["timeout"] = timeout
    if task_timeout is not None:
        kwargs["task_timeout"] = task_timeout

    try:
        result = scope.builds.trigger(build_id, **kwargs)
    except Exception as e:
        console.print(f"[red]Error:[/red] {e}")
        sys.exit(1)

    console.print(f"[green]✓[/green] Build triggered!")
    console.print(f"  Job ID: [bold]{result.job_id}[/bold]")
    console.print(f"  Status: {result.status}")


@builds.command("delete")
@click.argument("build_id")
@click.option("--yes", "-y", is_flag=True, help="跳过确认")
@click.option("--api-key", envvar="PANDA_API_KEY", hidden=True)
@click.option("--url", envvar="PANDA_API_URL", hidden=True)
@click.option("--project", type=int, envvar="PANDA_PROJECT_ID", hidden=True)
def delete_build(build_id: str, yes: bool, api_key, url, project):
    """删除构建"""
    if not yes:
        click.confirm(f"Are you sure you want to delete build {build_id}?", abort=True)

    scope = create_scoped_client(api_key=api_key, base_url=url, project_id=project)

    try:
        scope.builds.delete(build_id)
    except Exception as e:
        console.print(f"[red]Error:[/red] {e}")
        sys.exit(1)

    console.print(f"[green]✓[/green] Build [bold]{build_id}[/bold] deleted.")


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _build_to_dict(b) -> dict:
    return {
        "id": b.id,
        "name": b.name,
        "description": b.description,
        "status": b.status,
        "app_name": b.app_name,
        "total_jobs": b.total_jobs,
        "last_job_status": b.last_job_status,
        "created_at": b.created_at,
    }


def _status_badge(status: str) -> str:
    color_map = {
        "active": "green",
        "draft": "yellow",
        "inactive": "dim",
        "archived": "dim",
    }
    color = color_map.get(status, "white")
    return f"[{color}]{status}[/{color}]"
