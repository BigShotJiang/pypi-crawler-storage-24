"""
panda devices — 设备与自动化锁命令
"""

from __future__ import annotations

import json
import sys

import click
from rich.console import Console
from rich.table import Table

from pandatest.cli.commands._helpers import create_client

console = Console()


@click.group()
def devices():
    """管理设备状态与自动化锁（OpenAPI）"""
    pass


@devices.command("list")
@click.option("--platform", help="平台过滤 (android/ios/harmony)")
@click.option("--status", help="状态过滤 (online/busy/remote/offline)")
@click.option("--search", help="按设备名/序列号搜索")
@click.option("--size", type=int, default=0, help="获取数量，0 表示获取所有（默认）")
@click.option("--api-key", envvar="PANDA_API_KEY", hidden=True)
@click.option("--url", envvar="PANDA_API_URL", hidden=True)
@click.option("--json-output", "as_json", is_flag=True, help="输出 JSON")
def list_devices(platform, status, search, size, api_key, url, as_json):
    """查询设备列表"""
    client = create_client(api_key=api_key, base_url=url)

    try:
        items = client.devices.list(
            platform=platform,
            status=status,
            search=search,
            size=size,
        )
    except Exception as e:
        console.print(f"[red]Error:[/red] {e}")
        sys.exit(1)

    if as_json:
        console.print_json(json.dumps(items, ensure_ascii=False))
        return

    if not items:
        console.print("[dim]No devices found.[/dim]")
        return

    table = Table(title=f"Devices ({len(items)} total)")
    table.add_column("ID", style="cyan", no_wrap=True)
    table.add_column("Device ID", no_wrap=True)
    table.add_column("Name")
    table.add_column("Platform")
    table.add_column("Status")
    table.add_column("Lock")
    table.add_column("TTL", justify="right")

    for d in items:
        lock = d.get("lock", {}) or {}
        locked = "yes" if lock.get("locked") else "no"
        ttl = str(lock.get("ttl")) if lock.get("locked") else "-"
        table.add_row(
            str(d.get("id", "")),
            d.get("device_id", "") or "-",
            d.get("name", "") or "-",
            d.get("platform", "") or "-",
            d.get("status", "") or "-",
            locked,
            ttl,
        )

    console.print(table)


@devices.command("acquire")
@click.argument("device_id", type=int)
@click.option("--ttl", type=int, help="锁超时（秒）")
@click.option("--request-id", help="幂等请求 ID")
@click.option("--metadata", help='元数据 JSON，例如: \'{"pipeline":"nightly"}\'')
@click.option("--api-key", envvar="PANDA_API_KEY", hidden=True)
@click.option("--url", envvar="PANDA_API_URL", hidden=True)
@click.option("--json-output", "as_json", is_flag=True, help="输出 JSON")
def acquire_device(device_id, ttl, request_id, metadata, api_key, url, as_json):
    """占用设备（自动心跳）"""
    client = create_client(api_key=api_key, base_url=url)

    parsed_metadata = None
    if metadata:
        try:
            parsed_metadata = json.loads(metadata)
        except json.JSONDecodeError:
            console.print("[red]Error:[/red] --metadata 必须是合法 JSON")
            sys.exit(2)

    try:
        data = client.devices.acquire(
            device_id,
            ttl=ttl,
            request_id=request_id,
            metadata=parsed_metadata,
        )
    except Exception as e:
        console.print(f"[red]Error:[/red] {e}")
        sys.exit(1)

    if as_json:
        console.print_json(json.dumps(data, ensure_ascii=False))
        return

    console.print(f"[green]✓[/green] Device acquired: [bold]{device_id}[/bold]")
    if data.get("lease_token"):
        console.print(f"  lease_token: {data.get('lease_token')}")


@devices.command("release")
@click.argument("device_id", type=int)
@click.option("--lease-token", required=True, help="acquire 返回的 lease_token")
@click.option("--request-id", help="幂等请求 ID")
@click.option("--api-key", envvar="PANDA_API_KEY", hidden=True)
@click.option("--url", envvar="PANDA_API_URL", hidden=True)
@click.option("--json-output", "as_json", is_flag=True, help="输出 JSON")
def release_device(device_id, lease_token, request_id, api_key, url, as_json):
    """释放设备"""
    client = create_client(api_key=api_key, base_url=url)

    try:
        data = client.devices.release(
            device_id,
            lease_token=lease_token,
            request_id=request_id,
        )
    except Exception as e:
        console.print(f"[red]Error:[/red] {e}")
        sys.exit(1)

    if as_json:
        console.print_json(json.dumps(data, ensure_ascii=False))
        return

    console.print(f"[green]✓[/green] Device released: [bold]{device_id}[/bold]")


@devices.command("status")
@click.argument("device_id", type=int)
@click.option("--api-key", envvar="PANDA_API_KEY", hidden=True)
@click.option("--url", envvar="PANDA_API_URL", hidden=True)
@click.option("--json-output", "as_json", is_flag=True, help="输出 JSON")
def device_lock_status(device_id, api_key, url, as_json):
    """查询设备锁状态"""
    client = create_client(api_key=api_key, base_url=url)

    try:
        data = client.devices.lock_status(device_id)
    except Exception as e:
        console.print(f"[red]Error:[/red] {e}")
        sys.exit(1)

    if as_json:
        console.print_json(json.dumps(data, ensure_ascii=False))
        return

    lock = data.get("lock", {}) or {}
    console.print(f"[bold]Device:[/bold] {data.get('device_id')}")
    console.print(f"[bold]Status:[/bold] {data.get('device_status')}")
    console.print(f"[bold]Locked:[/bold] {'yes' if lock.get('locked') else 'no'}")
    if lock.get("locked"):
        console.print(f"[bold]Lease Token:[/bold] {lock.get('lease_token')}")
        console.print(f"[bold]TTL:[/bold] {lock.get('ttl')}s")
