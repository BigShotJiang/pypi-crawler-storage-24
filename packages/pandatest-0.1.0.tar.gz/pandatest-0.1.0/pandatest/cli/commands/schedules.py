"""
panda schedules — 调度管理命令
"""

from __future__ import annotations

import json
import sys

import click
from rich.console import Console
from rich.table import Table

from pandatest.cli.commands._helpers import create_scoped_client

console = Console()


@click.group()
def schedules():
    """管理定时调度"""
    pass


@schedules.command("list")
@click.option("--build", "build_id", help="按构建 ID 过滤")
@click.option("--page", type=int, default=1, help="页码")
@click.option("--page-size", type=int, default=20, help="每页数量")
@click.option("--api-key", envvar="PANDA_API_KEY", hidden=True)
@click.option("--url", envvar="PANDA_API_URL", hidden=True)
@click.option("--project", type=int, envvar="PANDA_PROJECT_ID", hidden=True)
@click.option("--json-output", "as_json", is_flag=True, help="输出 JSON")
def list_schedules(build_id, page, page_size, api_key, url, project, as_json):
    """列出调度"""
    scope = create_scoped_client(api_key=api_key, base_url=url, project_id=project)

    try:
        result = scope.schedules.list(
            build_id=build_id, page=page, page_size=page_size,
        )
    except Exception as e:
        console.print(f"[red]Error:[/red] {e}")
        sys.exit(1)

    if as_json:
        data = [_schedule_to_dict(s) for s in result.items]
        console.print_json(json.dumps(data, ensure_ascii=False))
        return

    if not result.items:
        console.print("[dim]No schedules found.[/dim]")
        return

    table = Table(title=f"Schedules (page {result.pagination.page}/{result.pagination.total_pages})")
    table.add_column("ID", style="cyan", no_wrap=True, max_width=30)
    table.add_column("Name", style="bold")
    table.add_column("Build")
    table.add_column("Frequency")
    table.add_column("Enabled")
    table.add_column("Runs", justify="right")
    table.add_column("Next Run")

    for s in result.items:
        enabled = "[green]Yes[/green]" if s.is_enabled else "[red]No[/red]"
        table.add_row(
            s.id,
            s.name,
            s.build_name or s.build,
            _format_frequency(s),
            enabled,
            f"{s.total_runs}",
            s.next_run_at or "-",
        )

    console.print(table)


@schedules.command("get")
@click.argument("schedule_id")
@click.option("--api-key", envvar="PANDA_API_KEY", hidden=True)
@click.option("--url", envvar="PANDA_API_URL", hidden=True)
@click.option("--project", type=int, envvar="PANDA_PROJECT_ID", hidden=True)
@click.option("--json-output", "as_json", is_flag=True, help="输出 JSON")
def get_schedule(schedule_id, api_key, url, project, as_json):
    """获取调度详情"""
    scope = create_scoped_client(api_key=api_key, base_url=url, project_id=project)

    try:
        schedule = scope.schedules.get(schedule_id)
    except Exception as e:
        console.print(f"[red]Error:[/red] {e}")
        sys.exit(1)

    if as_json:
        console.print_json(json.dumps(_schedule_to_dict(schedule), ensure_ascii=False))
        return

    table = Table(show_header=False, box=None, padding=(0, 2))
    table.add_column(width=16, style="cyan")
    table.add_column()
    table.add_row("ID", schedule.id)
    table.add_row("Name", schedule.name)
    table.add_row("Build", schedule.build_name or schedule.build)
    table.add_row("Frequency", _format_frequency(schedule))
    table.add_row("Enabled", "[green]Yes[/green]" if schedule.is_enabled else "[red]No[/red]")
    table.add_row("Timezone", schedule.timezone)
    table.add_row("Total Runs", str(schedule.total_runs))
    table.add_row("  Success", f"[green]{schedule.success_runs}[/green]")
    table.add_row("  Failed", f"[red]{schedule.failed_runs}[/red]")
    if schedule.next_run_at:
        table.add_row("Next Run", schedule.next_run_at)
    if schedule.last_run_at:
        table.add_row("Last Run", f"{schedule.last_run_at} ({schedule.last_run_status})")

    console.print(table)


@schedules.command("create")
@click.option("--name", required=True, help="调度名称")
@click.option("--build", "build_id", required=True, help="构建 ID")
@click.option("--frequency", required=True, type=click.Choice(["cron", "interval", "daily", "weekly", "monthly"]))
@click.option("--cron", "cron_expression", help="cron 表达式 (frequency=cron)")
@click.option("--interval", "interval_seconds", type=int, help="间隔秒数 (frequency=interval)")
@click.option("--time", "time_of_day", help="时间 (HH:MM, frequency=daily)")
@click.option("--timezone", default="Asia/Shanghai", help="时区")
@click.option("--api-key", envvar="PANDA_API_KEY", hidden=True)
@click.option("--url", envvar="PANDA_API_URL", hidden=True)
@click.option("--project", type=int, envvar="PANDA_PROJECT_ID", hidden=True)
def create_schedule(name, build_id, frequency, cron_expression, interval_seconds, time_of_day, timezone, api_key, url, project):
    """创建调度"""
    scope = create_scoped_client(api_key=api_key, base_url=url, project_id=project)

    kwargs = {}
    if cron_expression:
        kwargs["cron_expression"] = cron_expression
    if interval_seconds:
        kwargs["interval_seconds"] = interval_seconds
    if time_of_day:
        kwargs["time_of_day"] = time_of_day

    try:
        schedule = scope.schedules.create(
            name=name, build=build_id, frequency=frequency,
            timezone=timezone, **kwargs,
        )
    except Exception as e:
        console.print(f"[red]Error:[/red] {e}")
        sys.exit(1)

    console.print(f"[green]✓[/green] Schedule created: [bold]{schedule.id}[/bold]")
    console.print(f"  Name: {schedule.name}")


@schedules.command("enable")
@click.argument("schedule_id")
@click.option("--api-key", envvar="PANDA_API_KEY", hidden=True)
@click.option("--url", envvar="PANDA_API_URL", hidden=True)
@click.option("--project", type=int, envvar="PANDA_PROJECT_ID", hidden=True)
def enable_schedule(schedule_id, api_key, url, project):
    """启用调度"""
    scope = create_scoped_client(api_key=api_key, base_url=url, project_id=project)

    try:
        scope.schedules.enable(schedule_id)
    except Exception as e:
        console.print(f"[red]Error:[/red] {e}")
        sys.exit(1)

    console.print(f"[green]✓[/green] Schedule [bold]{schedule_id}[/bold] enabled.")


@schedules.command("disable")
@click.argument("schedule_id")
@click.option("--api-key", envvar="PANDA_API_KEY", hidden=True)
@click.option("--url", envvar="PANDA_API_URL", hidden=True)
@click.option("--project", type=int, envvar="PANDA_PROJECT_ID", hidden=True)
def disable_schedule(schedule_id, api_key, url, project):
    """禁用调度"""
    scope = create_scoped_client(api_key=api_key, base_url=url, project_id=project)

    try:
        scope.schedules.disable(schedule_id)
    except Exception as e:
        console.print(f"[red]Error:[/red] {e}")
        sys.exit(1)

    console.print(f"[green]✓[/green] Schedule [bold]{schedule_id}[/bold] disabled.")


@schedules.command("trigger")
@click.argument("schedule_id")
@click.option("--api-key", envvar="PANDA_API_KEY", hidden=True)
@click.option("--url", envvar="PANDA_API_URL", hidden=True)
@click.option("--project", type=int, envvar="PANDA_PROJECT_ID", hidden=True)
def trigger_schedule(schedule_id, api_key, url, project):
    """立即触发调度"""
    scope = create_scoped_client(api_key=api_key, base_url=url, project_id=project)

    try:
        result = scope.schedules.trigger(schedule_id)
    except Exception as e:
        console.print(f"[red]Error:[/red] {e}")
        sys.exit(1)

    console.print(f"[green]✓[/green] Schedule triggered!")
    console.print(f"  Celery Task: {result.get('celery_task_id', 'N/A')}")


@schedules.command("delete")
@click.argument("schedule_id")
@click.option("--yes", "-y", is_flag=True, help="跳过确认")
@click.option("--api-key", envvar="PANDA_API_KEY", hidden=True)
@click.option("--url", envvar="PANDA_API_URL", hidden=True)
@click.option("--project", type=int, envvar="PANDA_PROJECT_ID", hidden=True)
def delete_schedule(schedule_id, yes, api_key, url, project):
    """删除调度"""
    if not yes:
        click.confirm(f"Are you sure you want to delete schedule {schedule_id}?", abort=True)

    scope = create_scoped_client(api_key=api_key, base_url=url, project_id=project)

    try:
        scope.schedules.delete(schedule_id)
    except Exception as e:
        console.print(f"[red]Error:[/red] {e}")
        sys.exit(1)

    console.print(f"[green]✓[/green] Schedule [bold]{schedule_id}[/bold] deleted.")


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _schedule_to_dict(s) -> dict:
    return {
        "id": s.id,
        "name": s.name,
        "build": s.build,
        "build_name": s.build_name,
        "frequency": s.frequency,
        "cron_expression": s.cron_expression,
        "is_enabled": s.is_enabled,
        "total_runs": s.total_runs,
        "next_run_at": s.next_run_at,
        "last_run_at": s.last_run_at,
        "last_run_status": s.last_run_status,
    }


def _format_frequency(s) -> str:
    if s.frequency == "cron" and s.cron_expression:
        return f"cron({s.cron_expression})"
    if s.frequency == "interval" and s.interval_seconds:
        return f"every {s.interval_seconds}s"
    if s.frequency == "daily" and s.time_of_day:
        return f"daily at {s.time_of_day}"
    return s.frequency
