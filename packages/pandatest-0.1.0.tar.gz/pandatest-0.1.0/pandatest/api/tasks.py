"""
TasksAPI — Task 查询
"""

from __future__ import annotations

from typing import Any

from pandatest.api.base import BaseAPI
from pandatest.models import Task, PaginatedList

PREFIX = "/api/automation/tasks"


class TasksAPI:
    """Task 相关 API"""

    def __init__(self, base: BaseAPI, project_id: int | None = None):
        self._api = base
        self._project_id = project_id

    def __call__(self, project_id: int) -> TasksAPI:
        """返回绑定到指定项目的 TasksAPI 实例。"""
        return TasksAPI(self._api, project_id=project_id)

    # ------------------------------------------------------------------
    # 查询
    # ------------------------------------------------------------------

    def list(
        self,
        *,
        job_id: str | None = None,
        device_id: str | None = None,
        status: str | None = None,
        page: int = 1,
        page_size: int = 20,
        **filters: Any,
    ) -> PaginatedList:
        """获取 Task 列表"""
        params: dict[str, Any] = {"page": page, "page_size": page_size}
        if job_id:
            params["job_id"] = job_id
        if device_id:
            params["device_id"] = device_id
        if status:
            params["status"] = status
        params.update(filters)

        resp = self._api.get(f"{PREFIX}/", params=params, project_id=self._project_id)
        return self._api._extract_paginated(resp, Task)

    def get(self, task_id: str) -> Task:
        """获取 Task 详情"""
        resp = self._api.get(f"{PREFIX}/{task_id}/", project_id=self._project_id)
        data = self._api._extract_data(resp)
        return Task.from_dict(data)

    def logs(self, task_id: str) -> dict:
        """
        获取 Task 日志。

        Returns:
            { "task_id": "...", "logs_url": "..." }
        """
        resp = self._api.get(f"{PREFIX}/{task_id}/logs/", project_id=self._project_id)
        return self._api._extract_data(resp)

    def running_stats(self) -> dict:
        """
        获取运行中的 Task 统计。

        Returns:
            { "android": { "running": N, "queued": N }, "ios": { ... } }
        """
        resp = self._api.get(f"{PREFIX}/running-stats/", project_id=self._project_id)
        return self._api._extract_data(resp)
