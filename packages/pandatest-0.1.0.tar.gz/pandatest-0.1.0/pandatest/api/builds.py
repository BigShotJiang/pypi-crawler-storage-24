"""
BuildsAPI — 构建配置管理
"""

from __future__ import annotations

from typing import Any

from pandatest.api.base import BaseAPI
from pandatest.models import Build, Job, PaginatedList, TriggerResult

PREFIX = "/api/automation/builds"


class BuildsAPI:
    """构建相关 API"""

    def __init__(self, base: BaseAPI, project_id: int | None = None):
        self._api = base
        self._project_id = project_id

    def __call__(self, project_id: int) -> BuildsAPI:
        """返回绑定到指定项目的 BuildsAPI 实例。"""
        return BuildsAPI(self._api, project_id=project_id)

    # ------------------------------------------------------------------
    # CRUD
    # ------------------------------------------------------------------

    def list(
        self,
        *,
        page: int = 1,
        page_size: int = 20,
        **filters: Any,
    ) -> PaginatedList:
        """获取构建列表"""
        params = {"page": page, "page_size": page_size, **filters}
        resp = self._api.get(f"{PREFIX}/", params=params, project_id=self._project_id)
        return self._api._extract_paginated(resp, Build)

    def get(self, build_id: str) -> Build:
        """获取构建详情"""
        resp = self._api.get(f"{PREFIX}/{build_id}/", project_id=self._project_id)
        data = self._api._extract_data(resp)
        return Build.from_dict(data)

    def create(
        self,
        *,
        name: str,
        app: int,
        project: int | None = None,
        test_script: int | None = None,
        description: str = "",
        target_devices: list[dict] | None = None,
        device_filter: dict | None = None,
        environment_vars: dict | None = None,
        execution_config: dict | None = None,
        notification_config: dict | None = None,
        **kwargs: Any,
    ) -> Build:
        """创建构建配置"""
        payload: dict[str, Any] = {"name": name, "app": app}

        resolved = project or self._project_id
        if resolved is not None:
            payload["project"] = resolved

        if test_script is not None:
            payload["test_script"] = test_script
        if description:
            payload["description"] = description
        if target_devices is not None:
            payload["target_devices"] = target_devices
        if device_filter is not None:
            payload["device_filter"] = device_filter
        if environment_vars is not None:
            payload["environment_vars"] = environment_vars
        if execution_config is not None:
            payload["execution_config"] = execution_config
        if notification_config is not None:
            payload["notification_config"] = notification_config

        payload.update(kwargs)

        resp = self._api.post(f"{PREFIX}/", json=payload, project_id=self._project_id)
        data = self._api._extract_data(resp)
        return Build.from_dict(data)

    def update(self, build_id: str, **fields: Any) -> Build:
        """更新构建配置（部分更新）"""
        resp = self._api.patch(f"{PREFIX}/{build_id}/", json=fields, project_id=self._project_id)
        data = self._api._extract_data(resp)
        return Build.from_dict(data)

    def delete(self, build_id: str) -> None:
        """删除构建配置"""
        self._api.delete(f"{PREFIX}/{build_id}/", project_id=self._project_id)

    # ------------------------------------------------------------------
    # 操作
    # ------------------------------------------------------------------

    def trigger(
        self,
        build_id: str,
        *,
        timeout: int | None = None,
        task_timeout: int | None = None,
        parallel: bool | None = None,
        concurrency: int | None = None,
        environment_vars: dict | None = None,
    ) -> TriggerResult:
        """
        触发构建，创建一个新的 Job。

        Args:
            build_id: 构建 ID
            timeout: 整体超时 (秒)
            task_timeout: 单任务超时 (秒)
            parallel: 是否并行
            concurrency: 并发数
            environment_vars: 运行时环境变量

        Returns:
            TriggerResult，包含 job_id, celery_task_id, status
        """
        payload: dict[str, Any] = {}
        if timeout is not None:
            payload["timeout"] = timeout
        if task_timeout is not None:
            payload["task_timeout"] = task_timeout
        if parallel is not None:
            payload["parallel"] = parallel
        if concurrency is not None:
            payload["concurrency"] = concurrency
        if environment_vars is not None:
            payload["environment_vars"] = environment_vars

        resp = self._api.post(f"{PREFIX}/{build_id}/trigger/", json=payload or None, project_id=self._project_id)
        data = self._api._extract_data(resp)
        return TriggerResult.from_dict(data)

    def duplicate(self, build_id: str) -> Build:
        """复制构建配置"""
        resp = self._api.post(f"{PREFIX}/{build_id}/duplicate/", project_id=self._project_id)
        data = self._api._extract_data(resp)
        return Build.from_dict(data)

    def toggle_pin(self, build_id: str) -> dict:
        """切换置顶状态"""
        resp = self._api.post(f"{PREFIX}/{build_id}/toggle-pin/", project_id=self._project_id)
        return self._api._extract_data(resp)

    def recent_jobs(self, build_id: str, *, limit: int = 10) -> list[Job]:
        """获取最近的 Job 列表"""
        resp = self._api.get(f"{PREFIX}/{build_id}/recent-jobs/", params={"limit": limit}, project_id=self._project_id)
        data = self._api._extract_data(resp)
        return [Job.from_dict(j) for j in (data or [])]

    # ------------------------------------------------------------------
    # 镜像构建 (Runner Image)
    # ------------------------------------------------------------------

    def trigger_image_build(self, build_id: str, *, force_rebuild: bool = False) -> dict:
        """触发 Runner 镜像构建"""
        payload = {"force_rebuild": force_rebuild} if force_rebuild else None
        resp = self._api.post(f"{PREFIX}/{build_id}/trigger-build/", json=payload, project_id=self._project_id)
        return self._api._extract_data(resp)

    def image_status(self, build_id: str) -> dict:
        """获取 Runner 镜像状态"""
        resp = self._api.get(f"{PREFIX}/{build_id}/image-status/", project_id=self._project_id)
        return self._api._extract_data(resp)

    def logs(self, build_id: str, *, tail: int = 500) -> dict:
        """获取构建日志"""
        resp = self._api.get(f"{PREFIX}/{build_id}/logs/", params={"tail": tail}, project_id=self._project_id)
        return self._api._extract_data(resp)
