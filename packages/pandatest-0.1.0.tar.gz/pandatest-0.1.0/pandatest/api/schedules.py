"""
SchedulesAPI — 定时调度管理
"""

from __future__ import annotations

from typing import Any

from pandatest.api.base import BaseAPI
from pandatest.models import Schedule, PaginatedList

PREFIX = "/api/automation/schedules"


class SchedulesAPI:
    """Schedule 相关 API"""

    def __init__(self, base: BaseAPI, project_id: int | None = None):
        self._api = base
        self._project_id = project_id

    def __call__(self, project_id: int) -> SchedulesAPI:
        """返回绑定到指定项目的 SchedulesAPI 实例。"""
        return SchedulesAPI(self._api, project_id=project_id)

    # ------------------------------------------------------------------
    # CRUD
    # ------------------------------------------------------------------

    def list(
        self,
        *,
        build_id: str | None = None,
        page: int = 1,
        page_size: int = 20,
        **filters: Any,
    ) -> PaginatedList:
        """获取调度列表"""
        params: dict[str, Any] = {"page": page, "page_size": page_size}
        if build_id:
            params["build_id"] = build_id
        params.update(filters)

        resp = self._api.get(f"{PREFIX}/", params=params, project_id=self._project_id)
        return self._api._extract_paginated(resp, Schedule)

    def get(self, schedule_id: str) -> Schedule:
        """获取调度详情"""
        resp = self._api.get(f"{PREFIX}/{schedule_id}/", project_id=self._project_id)
        data = self._api._extract_data(resp)
        return Schedule.from_dict(data)

    def create(
        self,
        *,
        name: str,
        build: str,
        frequency: str,
        description: str = "",
        cron_expression: str | None = None,
        interval_seconds: int | None = None,
        time_of_day: str | None = None,
        day_of_week: int | None = None,
        day_of_month: int | None = None,
        timezone: str = "Asia/Shanghai",
        **kwargs: Any,
    ) -> Schedule:
        """
        创建调度。

        Args:
            name: 调度名称
            build: 构建 ID
            frequency: 频率类型 (cron/interval/daily/weekly/monthly)
            cron_expression: cron 表达式 (frequency=cron 时)
            interval_seconds: 间隔秒数 (frequency=interval 时)
            time_of_day: 每天时间 (frequency=daily 时, 如 "02:00")
            day_of_week: 星期几 (frequency=weekly 时, 0=周一)
            day_of_month: 每月几号 (frequency=monthly 时)
            timezone: 时区 (默认 Asia/Shanghai)
        """
        payload: dict[str, Any] = {
            "name": name,
            "build": build,
            "frequency": frequency,
            "timezone": timezone,
        }
        if description:
            payload["description"] = description
        if cron_expression is not None:
            payload["cron_expression"] = cron_expression
        if interval_seconds is not None:
            payload["interval_seconds"] = interval_seconds
        if time_of_day is not None:
            payload["time_of_day"] = time_of_day
        if day_of_week is not None:
            payload["day_of_week"] = day_of_week
        if day_of_month is not None:
            payload["day_of_month"] = day_of_month

        payload.update(kwargs)

        resp = self._api.post(f"{PREFIX}/", json=payload, project_id=self._project_id)
        data = self._api._extract_data(resp)
        return Schedule.from_dict(data)

    def update(self, schedule_id: str, **fields: Any) -> Schedule:
        """更新调度（部分更新）"""
        resp = self._api.patch(f"{PREFIX}/{schedule_id}/", json=fields, project_id=self._project_id)
        data = self._api._extract_data(resp)
        return Schedule.from_dict(data)

    def delete(self, schedule_id: str) -> None:
        """删除调度"""
        self._api.delete(f"{PREFIX}/{schedule_id}/", project_id=self._project_id)

    # ------------------------------------------------------------------
    # 操作
    # ------------------------------------------------------------------

    def enable(self, schedule_id: str) -> Schedule:
        """启用调度"""
        resp = self._api.post(f"{PREFIX}/{schedule_id}/enable/", project_id=self._project_id)
        data = self._api._extract_data(resp)
        return Schedule.from_dict(data)

    def disable(self, schedule_id: str) -> Schedule:
        """禁用调度"""
        resp = self._api.post(f"{PREFIX}/{schedule_id}/disable/", project_id=self._project_id)
        data = self._api._extract_data(resp)
        return Schedule.from_dict(data)

    def trigger(self, schedule_id: str) -> dict:
        """
        立即触发调度。

        Returns:
            { "schedule_id": "...", "celery_task_id": "..." }
        """
        resp = self._api.post(f"{PREFIX}/{schedule_id}/trigger/", project_id=self._project_id)
        return self._api._extract_data(resp)
