"""
ProjectsAPI — 项目列表查询（全局资源，不需要 project_id）
"""

from __future__ import annotations

from typing import Any

from pandatest.api.base import BaseAPI

PREFIX = "/api/open/v1/projects"


class ProjectsAPI:
    """项目相关 API（全局，无需项目作用域）"""

    def __init__(self, base: BaseAPI):
        self._api = base

    def list(self) -> list[dict[str, Any]]:
        """
        获取当前用户可访问的项目列表。

        Returns:
            项目列表，每项含 id / name / description / is_active / created_at
        """
        resp = self._api.get(f"{PREFIX}/")
        return self._api._extract_data(resp) or []

    def get(self, project_id: int) -> dict[str, Any]:
        """
        获取单个项目详情。

        Args:
            project_id: 项目 ID

        Returns:
            dict 含 id / name / description / owner / member_count 等
        """
        resp = self._api.get(f"{PREFIX}/{project_id}/")
        return self._api._extract_data(resp)
