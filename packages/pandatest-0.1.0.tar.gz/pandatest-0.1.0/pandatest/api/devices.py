"""
DevicesAPI — 对外 OpenAPI 设备与自动化锁接口
"""

from __future__ import annotations

import threading
from typing import Any

from pandatest.api.base import BaseAPI

PREFIX = "/api/open/v1/devices"


class _HeartbeatWorker:
    """后台心跳线程，acquire 时自动启动，release 时自动停止。"""

    def __init__(
        self,
        api: BaseAPI,
        device_id: int,
        lease_token: str,
        interval: float,
    ):
        self._api = api
        self.device_id = device_id
        self.lease_token = lease_token
        self.interval = max(float(interval), 5.0)
        self.last_error: Exception | None = None

        self._stop = threading.Event()
        self._thread = threading.Thread(
            target=self._loop,
            name=f"pandatest-hb-{device_id}",
            daemon=True,
        )

    def start(self) -> None:
        self._thread.start()

    def stop(self) -> None:
        self._stop.set()
        if self._thread.is_alive():
            self._thread.join(timeout=2.0)

    def _loop(self) -> None:
        while not self._stop.wait(self.interval):
            try:
                self._api.post(
                    f"{PREFIX}/{self.device_id}/lock/heartbeat/",
                    json={"lease_token": self.lease_token},
                )
                self.last_error = None
            except Exception as e:
                self.last_error = e


class DevicesAPI:
    """
    设备相关 API（OpenAPI）。

    公开方法:
        - list()        获取设备列表
        - acquire()     占用设备（自动心跳）
        - release()     释放设备（停止心跳）
        - lock_status() 查询锁状态
        - close()       释放所有已占用设备
    """

    def __init__(self, base: BaseAPI):
        self._api = base
        self._workers: dict[int, _HeartbeatWorker] = {}
        self._lock = threading.Lock()

    # ------------------------------------------------------------------
    # 查询
    # ------------------------------------------------------------------

    def list(
        self,
        *,
        platform: str | None = None,
        status: str | None = None,
        search: str | None = None,
        size: int = 0,
    ) -> list[dict[str, Any]]:
        """
        获取设备列表（含锁状态）。

        Args:
            platform: 平台过滤，可选值: ``android`` / ``ios`` / ``harmony``
            status: 状态过滤，可选值: ``online`` / ``busy`` / ``remote`` / ``offline``
            search: 按设备名 / 序列号模糊搜索
            size: 获取数量，``0`` (默认) 表示获取所有设备（自动翻页）

        Returns:
            设备列表 (list[dict])
        """
        if size > 0:
            params: dict[str, Any] = {"page": 1, "page_size": min(size, 100)}
            if platform:
                params["platform"] = platform
            if status:
                params["status"] = status
            if search:
                params["search"] = search
            resp = self._api.get(f"{PREFIX}/", params=params)
            return (self._api._extract_data(resp) or [])[:size]

        all_items: list[dict[str, Any]] = []
        page = 1
        while True:
            params = {"page": page, "page_size": 100}
            if platform:
                params["platform"] = platform
            if status:
                params["status"] = status
            if search:
                params["search"] = search
            resp = self._api.get(f"{PREFIX}/", params=params)
            items = self._api._extract_data(resp) or []
            all_items.extend(items)
            pagination = resp.get("pagination", {})
            if page >= pagination.get("total_pages", 1):
                break
            page += 1
        return all_items

    def get(self, device_id: int) -> dict[str, Any]:
        """
        获取单个设备详情（含锁状态）。

        Args:
            device_id: 设备 ID

        Returns:
            dict 含 id / device_id / name / platform / brand / model /
            version / status / resolution / arch / tier / lock 等
        """
        resp = self._api.get(f"{PREFIX}/{device_id}/")
        return self._api._extract_data(resp)

    def lock_status(self, device_id: int) -> dict[str, Any]:
        """
        查询设备锁状态。

        Args:
            device_id: 设备 ID

        Returns:
            dict 含 device_id / device_status / lock
        """
        resp = self._api.get(f"{PREFIX}/{device_id}/lock/")
        return self._api._extract_data(resp)

    # ------------------------------------------------------------------
    # 占用 / 释放
    # ------------------------------------------------------------------

    def acquire(
        self,
        device_id: int,
        *,
        ttl: int | None = None,
        request_id: str | None = None,
        metadata: dict | None = None,
        heartbeat_interval: float | None = None,
    ) -> dict[str, Any]:
        """
        占用设备（自动启动后台心跳）。

        Args:
            device_id: 设备 ID
            ttl: 锁过期时间（秒），为空时由后端默认值决定
            request_id: 幂等请求 ID
            metadata: 可选元数据
            heartbeat_interval: 心跳间隔（秒），为空时按 ttl/3 推导，默认 30s

        Returns:
            dict 含 device_id / lease_token / status / lock
        """
        payload: dict[str, Any] = {}
        if ttl is not None:
            payload["ttl"] = ttl
        if request_id:
            payload["request_id"] = request_id
        if metadata is not None:
            payload["metadata"] = metadata

        resp = self._api.post(
            f"{PREFIX}/{device_id}/lock/acquire/",
            json=payload,
        )
        data = self._api._extract_data(resp)

        lease_token = str(data.get("lease_token", "")).strip()
        if not lease_token:
            raise ValueError("Acquire response missing lease_token")

        if heartbeat_interval is None:
            if ttl:
                heartbeat_interval = min(max(ttl / 3.0, 10.0), 60.0)
            else:
                heartbeat_interval = 30.0

        worker = _HeartbeatWorker(
            self._api,
            device_id=device_id,
            lease_token=lease_token,
            interval=heartbeat_interval,
        )
        worker.start()

        with self._lock:
            old = self._workers.pop(device_id, None)
            if old:
                old.stop()
            self._workers[device_id] = worker

        return data

    def release(
        self,
        device_id: int,
        *,
        lease_token: str | None = None,
        request_id: str | None = None,
    ) -> dict[str, Any]:
        """
        释放设备（停止心跳 + 释放锁）。

        Args:
            device_id: 设备 ID
            lease_token: 租约令牌，为空时自动使用 acquire() 返回的令牌
            request_id: 幂等请求 ID

        Returns:
            dict 含 device_id / lease_token / status
        """
        with self._lock:
            worker = self._workers.pop(device_id, None)

        if worker:
            worker.stop()
            if lease_token is None:
                lease_token = worker.lease_token

        if not lease_token:
            raise ValueError(
                f"Device {device_id}: lease_token is required "
                "(device was not acquired by this client)"
            )

        payload: dict[str, Any] = {"lease_token": lease_token}
        if request_id:
            payload["request_id"] = request_id

        resp = self._api.post(
            f"{PREFIX}/{device_id}/lock/release/",
            json=payload,
        )
        return self._api._extract_data(resp)

    # ------------------------------------------------------------------
    # 远程调试（直连 Agent）
    # ------------------------------------------------------------------

    def _get_agent_info(self, device_id: int) -> tuple[str, dict[str, Any]]:
        """获取设备的 serial 和 agent 连接信息，返回 (serial, agent_dict)。"""
        device = self.get(device_id)
        serial = device.get("device_id")
        agent = device.get("agent")
        if not agent or not agent.get("ip_address") or not agent.get("port"):
            raise ValueError(
                f"Device {device_id} has no agent info "
                "(ip_address/port missing). Cannot connect to agent."
            )
        return serial, agent

    @staticmethod
    def _agent_url(agent: dict[str, Any], path: str) -> str:
        return f"https://{agent['ip_address']}:{agent['port']}{path}"

    @staticmethod
    def _agent_request(method: str, url: str) -> dict[str, Any]:
        """向 Agent 发送 HTTP 请求（跳过自签名证书验证）。"""
        import httpx

        resp = httpx.request(method, url, timeout=15.0, verify=False)
        resp.raise_for_status()
        return resp.json()

    def remote_debug_start(self, device_id: int) -> dict[str, Any]:
        """
        启动 ADB 远程调试代理（通过 Agent）。

        Agent 会启动 adbkit usb-device-to-tcp 进程，将 USB 设备
        暴露为 TCP 端口，返回连接地址。

        Args:
            device_id: 设备 ID

        Returns:
            dict 含 host / port / connect (可直接用于 ``adb connect``)
        """
        serial, agent = self._get_agent_info(device_id)
        url = self._agent_url(agent, f"/api/android/{serial}/remote_debug")
        return self._agent_request("POST", url)

    def remote_debug_stop(self, device_id: int) -> dict[str, Any]:
        """
        停止 ADB 远程调试代理。

        Args:
            device_id: 设备 ID

        Returns:
            dict 含 serial / stopped
        """
        serial, agent = self._get_agent_info(device_id)
        url = self._agent_url(agent, f"/api/android/{serial}/remote_debug")
        return self._agent_request("DELETE", url)

    # ------------------------------------------------------------------
    # 生命周期
    # ------------------------------------------------------------------

    def close(self) -> None:
        """释放所有已占用设备，停止所有心跳线程。"""
        with self._lock:
            workers = list(self._workers.items())
            self._workers.clear()

        for device_id, worker in workers:
            worker.stop()
            try:
                self._api.post(
                    f"{PREFIX}/{device_id}/lock/release/",
                    json={"lease_token": worker.lease_token},
                )
            except Exception:
                pass
