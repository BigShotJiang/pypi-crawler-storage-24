"""
JobsAPI — Job 执行管理
"""

from __future__ import annotations

import time
from typing import Any, Callable

from pandatest.api.base import BaseAPI
from pandatest.exceptions import TimeoutError
from pandatest.models import Job, Task, PaginatedList

PREFIX = "/api/automation/jobs"


class JobsAPI:
    """Job 相关 API"""

    def __init__(self, base: BaseAPI, project_id: int | None = None):
        self._api = base
        self._project_id = project_id

    def __call__(self, project_id: int) -> JobsAPI:
        """返回绑定到指定项目的 JobsAPI 实例。"""
        return JobsAPI(self._api, project_id=project_id)

    # ------------------------------------------------------------------
    # 查询
    # ------------------------------------------------------------------

    def list(
        self,
        *,
        build_id: str | None = None,
        status: str | None = None,
        search: str | None = None,
        page: int = 1,
        page_size: int = 20,
        **filters: Any,
    ) -> PaginatedList:
        """获取 Job 列表"""
        params: dict[str, Any] = {"page": page, "page_size": page_size}
        if build_id:
            params["build_id"] = build_id
        if status:
            params["status"] = status
        if search:
            params["search"] = search
        params.update(filters)

        resp = self._api.get(f"{PREFIX}/", params=params, project_id=self._project_id)
        return self._api._extract_paginated(resp, Job)

    def get(self, job_id: str) -> Job:
        """获取 Job 详情"""
        resp = self._api.get(f"{PREFIX}/{job_id}/", project_id=self._project_id)
        data = self._api._extract_data(resp)
        return Job.from_dict(data)

    # ------------------------------------------------------------------
    # 操作
    # ------------------------------------------------------------------

    def cancel(self, job_id: str) -> dict:
        """
        取消 Job。

        Returns:
            { "job_id": "...", "status": "cancelled", "cancelled_tasks": N }
        """
        resp = self._api.post(f"{PREFIX}/{job_id}/cancel/", project_id=self._project_id)
        return self._api._extract_data(resp)

    def rerun(self, job_id: str) -> dict:
        """
        重新运行 Job。

        Returns:
            { "old_job_id": "...", "new_job_id": "...", "status": "pending" }
        """
        resp = self._api.post(f"{PREFIX}/{job_id}/rerun/", project_id=self._project_id)
        return self._api._extract_data(resp)

    # ------------------------------------------------------------------
    # 关联查询
    # ------------------------------------------------------------------

    def tasks(self, job_id: str) -> list[Task]:
        """获取 Job 下的所有 Task"""
        resp = self._api.get(f"{PREFIX}/{job_id}/tasks/", project_id=self._project_id)
        data = self._api._extract_data(resp)
        return [Task.from_dict(t) for t in (data or [])]

    def report_summary(self, job_id: str) -> dict:
        """获取 Job 报告摘要"""
        resp = self._api.get(f"{PREFIX}/{job_id}/report-summary/", project_id=self._project_id)
        return self._api._extract_data(resp)

    def share(
        self,
        job_id: str,
        *,
        action: str = "create",
        expires_days: int | None = None,
    ) -> dict:
        """创建/禁用分享链接"""
        payload: dict[str, Any] = {"action": action}
        if expires_days is not None:
            payload["expires_days"] = expires_days

        resp = self._api.post(f"{PREFIX}/{job_id}/share/", json=payload, project_id=self._project_id)
        return self._api._extract_data(resp)

    def share_status(self, job_id: str) -> dict:
        """获取分享状态"""
        resp = self._api.get(f"{PREFIX}/{job_id}/share-status/", project_id=self._project_id)
        return self._api._extract_data(resp)

    # ------------------------------------------------------------------
    # 等待
    # ------------------------------------------------------------------

    def wait(
        self,
        job_id: str,
        *,
        timeout: int = 600,
        interval: float = 5.0,
        max_interval: float = 15.0,
        on_progress: Callable[[Job], None] | None = None,
    ) -> Job:
        """
        轮询等待 Job 完成。

        Args:
            job_id: Job ID
            timeout: 超时秒数 (默认 600)
            interval: 初始轮询间隔 (默认 5s)
            max_interval: 最大轮询间隔 (默认 15s)
            on_progress: 每次轮询回调 (收到 Job 对象)

        Returns:
            终态的 Job 对象

        Raises:
            TimeoutError: 超时未完成
        """
        start = time.monotonic()
        current_interval = interval

        while True:
            job = self.get(job_id)

            if on_progress:
                on_progress(job)

            if job.is_terminal:
                return job

            elapsed = time.monotonic() - start
            if elapsed >= timeout:
                raise TimeoutError(
                    f"Job {job_id} did not complete within {timeout}s "
                    f"(current status: {job.status}, progress: {job.progress}%)"
                )

            time.sleep(current_interval)
            # 指数退避，但不超过 max_interval
            current_interval = min(current_interval * 1.5, max_interval)
