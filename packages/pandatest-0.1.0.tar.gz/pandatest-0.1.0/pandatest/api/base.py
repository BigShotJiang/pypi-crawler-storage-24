"""
BaseAPI — HTTP 请求封装

职责：
1. 管理 httpx 客户端
2. 注入认证头 (Authorization: Bearer {api_key})
3. 按需注入项目头 (X-Active-Project-Id)
4. 解包后端统一响应格式 { code, success, data, message }
5. 统一异常转换 (HTTP status → PandaTestError 子类)
"""

from __future__ import annotations

from typing import Any

import httpx

from pandatest.config import Config
from pandatest.exceptions import (
    AuthenticationError,
    ForbiddenError,
    NotFoundError,
    PandaTestError,
    ServerError,
    ValidationError,
)
from pandatest.models import Pagination, PaginatedList


class BaseAPI:
    """底层 HTTP 请求封装"""

    def __init__(self, config: Config, http_client: httpx.Client | None = None):
        self._config = config
        self._client = http_client or self._create_client()

    def _create_client(self) -> httpx.Client:
        headers = {}
        if self._config.api_key:
            headers["Authorization"] = f"Bearer {self._config.api_key}"

        return httpx.Client(
            base_url=self._config.base_url,
            headers=headers,
            timeout=30.0,
        )

    def _build_headers(self, project_id: int | None = None) -> dict[str, str]:
        """构建请求级别的附加头（project_id 由调用方显式传入）。"""
        headers: dict[str, str] = {}
        if project_id is not None:
            headers["X-Active-Project-Id"] = str(project_id)
        return headers

    # ------------------------------------------------------------------
    # 核心请求方法
    # ------------------------------------------------------------------

    def _request(
        self,
        method: str,
        path: str,
        *,
        json: dict | None = None,
        params: dict | None = None,
        project_id: int | None = None,
    ) -> dict:
        """
        发送 HTTP 请求并解包后端统一响应。

        Returns:
            解包后的后端响应 dict (包含 code, success, data, message 等)

        Raises:
            PandaTestError 子类
        """
        try:
            response = self._client.request(
                method,
                path,
                json=json,
                params=params,
                headers=self._build_headers(project_id),
            )
        except httpx.TimeoutException as e:
            raise PandaTestError(f"Request timeout: {e}") from e
        except httpx.ConnectError as e:
            raise PandaTestError(f"Connection failed: {e}") from e

        return self._handle_response(response)

    def _handle_response(self, response: httpx.Response) -> dict:
        """解析响应，处理错误"""
        # 尝试解析 JSON
        try:
            body = response.json()
        except Exception:
            if response.status_code >= 400:
                self._raise_http_error(response.status_code, response.text)
            return {"code": response.status_code, "success": True, "data": response.text}

        # 后端统一格式：{ code, success, data, message }
        if isinstance(body, dict) and "success" in body:
            if not body.get("success", False):
                self._raise_api_error(body)
            return body

        # 非统一格式（兜底）
        if response.status_code >= 400:
            self._raise_http_error(response.status_code, str(body))

        return {"code": response.status_code, "success": True, "data": body}

    # ------------------------------------------------------------------
    # 便捷方法
    # ------------------------------------------------------------------

    def get(self, path: str, *, params: dict | None = None, project_id: int | None = None) -> dict:
        return self._request("GET", path, params=params, project_id=project_id)

    def post(self, path: str, *, json: dict | None = None, project_id: int | None = None) -> dict:
        return self._request("POST", path, json=json, project_id=project_id)

    def put(self, path: str, *, json: dict | None = None, project_id: int | None = None) -> dict:
        return self._request("PUT", path, json=json, project_id=project_id)

    def patch(self, path: str, *, json: dict | None = None, project_id: int | None = None) -> dict:
        return self._request("PATCH", path, json=json, project_id=project_id)

    def delete(self, path: str, *, project_id: int | None = None) -> dict:
        return self._request("DELETE", path, project_id=project_id)

    # ------------------------------------------------------------------
    # 数据提取
    # ------------------------------------------------------------------

    def _extract_data(self, response: dict) -> Any:
        """从统一响应中提取 data 字段"""
        return response.get("data")

    def _extract_paginated(self, response: dict, item_cls: type) -> PaginatedList:
        """从分页响应中提取列表 + 分页信息"""
        data = response.get("data", [])
        pagination_data = response.get("pagination", {})

        items = [item_cls.from_dict(item) for item in (data or [])]
        pagination = Pagination.from_dict(pagination_data) if pagination_data else Pagination()

        return PaginatedList(items=items, pagination=pagination)

    # ------------------------------------------------------------------
    # 异常处理
    # ------------------------------------------------------------------

    @staticmethod
    def _raise_api_error(body: dict) -> None:
        """从后端统一错误响应抛出异常"""
        code = body.get("code", 0)
        message = body.get("message", "Unknown error")
        errors = body.get("errors")

        error_map = {
            401: AuthenticationError,
            403: ForbiddenError,
            404: NotFoundError,
            400: ValidationError,
        }

        error_cls = error_map.get(code, PandaTestError)
        if code >= 500:
            error_cls = ServerError

        raise error_cls(message=message, code=code, errors=errors)

    @staticmethod
    def _raise_http_error(status_code: int, detail: str = "") -> None:
        """从 HTTP 状态码抛出异常"""
        error_map = {
            401: (AuthenticationError, "Authentication failed"),
            403: (ForbiddenError, "Permission denied"),
            404: (NotFoundError, "Resource not found"),
            400: (ValidationError, "Bad request"),
        }

        if status_code in error_map:
            cls, default_msg = error_map[status_code]
            raise cls(message=detail or default_msg, code=status_code)

        if status_code >= 500:
            raise ServerError(message=detail or "Internal server error", code=status_code)

        raise PandaTestError(message=detail or f"HTTP {status_code}", code=status_code)

    def close(self) -> None:
        """关闭 HTTP 客户端"""
        self._client.close()
