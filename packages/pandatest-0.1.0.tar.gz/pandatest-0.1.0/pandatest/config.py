"""
配置管理

优先级（高到低）：
1. 构造函数参数
2. 环境变量 (PANDA_API_KEY / PANDA_API_URL)
3. 配置文件 (~/.pandatest/config.toml)

project_id 不再属于 SDK 配置；请使用 client.project(id) 或
client.builds(id) 进行项目作用域绑定。
"""

from __future__ import annotations

import os
from dataclasses import dataclass
from pathlib import Path

try:
    import tomllib  # Python 3.11+
except ModuleNotFoundError:
    try:
        import tomli as tomllib  # type: ignore[no-redef]
    except ModuleNotFoundError:
        tomllib = None  # type: ignore[assignment]

CONFIG_DIR = Path.home() / ".pandatest"
CONFIG_FILE = CONFIG_DIR / "config.toml"

ENV_API_KEY = "PANDA_API_KEY"
ENV_API_URL = "PANDA_API_URL"

DEFAULT_API_URL = "http://localhost:8000"


@dataclass
class Config:
    """SDK 配置（仅连接信息，不含 project_id）"""

    api_key: str = ""
    base_url: str = DEFAULT_API_URL

    @classmethod
    def load(
        cls,
        api_key: str | None = None,
        base_url: str | None = None,
    ) -> Config:
        """
        加载配置，按优先级合并。

        Args:
            api_key: API Key (最高优先级)
            base_url: 服务器地址
        """
        # 第 3 级：配置文件
        file_config = cls._load_from_file()

        # 第 2 级：环境变量
        env_api_key = os.environ.get(ENV_API_KEY)
        env_base_url = os.environ.get(ENV_API_URL)

        # 合并（参数 > 环境变量 > 文件）
        resolved_api_key = api_key or env_api_key or file_config.get("api_key", "")
        resolved_base_url = (
            base_url or env_base_url or file_config.get("base_url", DEFAULT_API_URL)
        )

        # 确保 base_url 没有尾部斜杠
        resolved_base_url = resolved_base_url.rstrip("/")

        return cls(
            api_key=resolved_api_key,
            base_url=resolved_base_url,
        )

    @staticmethod
    def _load_from_file() -> dict:
        """从配置文件加载"""
        if not CONFIG_FILE.exists():
            return {}
        if tomllib is None:
            return {}
        try:
            with open(CONFIG_FILE, "rb") as f:
                return tomllib.load(f)
        except Exception:
            return {}

    @staticmethod
    def save_to_file(
        api_key: str | None = None,
        base_url: str | None = None,
    ) -> Path:
        """
        保存配置到文件。

        只写入非 None 的值，保留已有配置。
        """
        existing = Config._load_from_file()

        if api_key is not None:
            existing["api_key"] = api_key
        if base_url is not None:
            existing["base_url"] = base_url

        CONFIG_DIR.mkdir(parents=True, exist_ok=True)

        lines = []
        for key, value in existing.items():
            if isinstance(value, str):
                lines.append(f'{key} = "{value}"')
            elif isinstance(value, int):
                lines.append(f"{key} = {value}")
            elif isinstance(value, bool):
                lines.append(f"{key} = {'true' if value else 'false'}")

        CONFIG_FILE.write_text("\n".join(lines) + "\n")
        return CONFIG_FILE
