"""
PandaTest SDK 自定义异常
"""

from __future__ import annotations


class PandaTestError(Exception):
    """SDK 基础异常"""

    def __init__(self, message: str, code: int | None = None, errors: dict | None = None):
        self.message = message
        self.code = code
        self.errors = errors
        super().__init__(message)


class AuthenticationError(PandaTestError):
    """认证失败 (401)"""
    pass


class ForbiddenError(PandaTestError):
    """权限不足 (403)"""
    pass


class NotFoundError(PandaTestError):
    """资源不存在 (404)"""
    pass


class ValidationError(PandaTestError):
    """参数校验失败 (400)"""
    pass


class ServerError(PandaTestError):
    """服务器内部错误 (500)"""
    pass


class TimeoutError(PandaTestError):
    """操作超时 (轮询等待场景)"""
    pass


class ConfigError(PandaTestError):
    """配置缺失或无效"""
    pass
