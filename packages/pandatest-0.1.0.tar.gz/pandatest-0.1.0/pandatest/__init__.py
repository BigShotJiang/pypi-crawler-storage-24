"""
PandaTest SDK — 移动端自动化测试平台的 Python 客户端

Usage:
    from pandatest import PandaTest

    client = PandaTest(api_key="pk_xxx")
    scope = client.project(2)
    build = scope.builds.get("build-14-xxx")
    result = scope.builds.trigger("build-14-xxx")
"""

from pandatest.client import PandaTest
from pandatest.exceptions import (
    PandaTestError,
    AuthenticationError,
    NotFoundError,
    ValidationError,
    ServerError,
    TimeoutError,
)

__version__ = "0.1.0"

__all__ = [
    "PandaTest",
    "PandaTestError",
    "AuthenticationError",
    "NotFoundError",
    "ValidationError",
    "ServerError",
    "TimeoutError",
]
