"""Build the proact C binary during pip install."""

import os
import subprocess
from setuptools import setup
from setuptools.command.build_py import build_py

try:
    from wheel.bdist_wheel import bdist_wheel

    class PlatformWheel(bdist_wheel):
        """Tag wheel as platform-specific (contains compiled C binary)."""
        def finalize_options(self):
            super().finalize_options()
            self.root_is_pure = False

        def get_tag(self):
            # Standalone C binary, not a Python extension — works with any
            # Python version. Override to avoid cpython version pinning.
            _, _, plat = super().get_tag()
            return "py3", "none", plat
except ImportError:
    PlatformWheel = None


class BuildWithC(build_py):
    """Compile the proact binary and include it in the package."""

    def run(self):
        src_dir = os.path.join(os.path.dirname(__file__), "src")
        sources = [
            os.path.join(src_dir, f)
            for f in ["term.c", "parse.c", "unify.c", "eval.c", "main.c"]
        ]

        binary = "proact.exe" if os.name == "nt" else "proact"
        out = os.path.join(self.build_lib, "proact", binary)

        os.makedirs(os.path.join(self.build_lib, "proact"), exist_ok=True)

        cc = os.environ.get("CC", "cl" if os.name == "nt" else "cc")
        if os.path.basename(cc) == "cl" or os.path.basename(cc) == "cl.exe":
            cmd = [cc, "/W4", "/O2", f"/I{src_dir}",
                   "/D_CRT_SECURE_NO_WARNINGS"] + sources + [f"/Fe:{out}"]
        else:
            cmd = [cc, "-Wall", "-O2", "-std=c11",
                   f"-I{src_dir}"] + sources + ["-o", out]
        subprocess.check_call(cmd)

        super().run()


cmds = {"build_py": BuildWithC}
if PlatformWheel:
    cmds["bdist_wheel"] = PlatformWheel

setup(cmdclass=cmds)
