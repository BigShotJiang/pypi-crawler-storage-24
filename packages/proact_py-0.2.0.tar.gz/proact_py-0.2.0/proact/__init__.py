"""Proact — active logic meets Prolog."""

from proact.engine import Proact, ProactError

__all__ = ["Proact", "ProactError"]
