"""Tests for the proact Python package."""

import os
import tempfile
import pytest
from proact import Proact


@pytest.fixture
def p():
    return Proact()


# --- Basic three-valued logic ---

def test_done(p):
    assert p.query("done").status == "done"

def test_true(p):
    assert p.query("true").ok

def test_fail(p):
    assert p.query("fail").status == "fail"

def test_cont(p):
    """cont with max_ticks=1 should exit with 'done' (tick limit, exit 0)."""
    # cont doesn't hard-fail; proact -q -e "cont." prints tick limit and exits 0
    r = p.query("cont", max_ticks=1)
    # Just check it doesn't crash
    assert r.status in ("done", "fail")


# --- Result truthiness ---

def test_result_bool_true(p):
    assert p.query("true")

def test_result_bool_false(p):
    assert not p.query("fail")

def test_result_repr(p):
    r = p.query("true")
    assert "done" in repr(r)


# --- Inline clauses ---

def test_add_fact(p):
    p.add("color(red).")
    assert p.query("color(red)").ok
    assert not p.query("color(blue)").ok

def test_add_rule(p):
    p.add("mortal(X) :- human(X). human(socrates).")
    assert p.query("mortal(socrates)").ok
    assert not p.query("mortal(plato)").ok


# --- Active logic operators ---

def test_inv(p):
    p.add("x :- inv(fail).")
    assert p.query("x").ok

def test_condone(p):
    p.add("x :- condone(fail).")
    assert p.query("x").ok

def test_promote(p):
    p.add("x :- promote(fail), done.")
    # promote(fail) -> cont, then cont short-circuits conjunction
    r = p.query("x", max_ticks=1)
    assert r.status in ("done", "fail")  # cont -> tick limit

def test_demote(p):
    p.add("x :- demote(done).")
    # demote(done) -> cont
    r = p.query("x", max_ticks=1)
    assert r.status in ("done", "fail")


# --- Consult files ---

def test_consult(p):
    with tempfile.NamedTemporaryFile(mode="w", suffix=".pa", delete=False) as f:
        f.write("animal(cat). animal(dog).\n")
        f.flush()
        name = f.name
    try:
        p.consult(name)
        assert p.query("animal(cat)").ok
        assert not p.query("animal(fish)").ok
    finally:
        os.unlink(name)

def test_consult_missing():
    p = Proact()
    with pytest.raises(FileNotFoundError):
        p.consult("/nonexistent/file.pa")


# --- Arithmetic ---

def test_arithmetic(p):
    p.add("double(X, Y) :- Y is X * 2.")
    assert p.query("double(5, 10)").ok
    assert not p.query("double(5, 11)").ok


# --- Chaining ---

def test_method_chaining():
    r = Proact().add("f(a).").query("f(a)")
    assert r.ok


# --- Reset ---

def test_reset(p):
    p.add("fact(1).")
    assert p.query("fact(1)").ok
    p.reset()
    assert not p.query("fact(1)").ok


# --- Multi-tick ---

def test_tick_convergence(p):
    p.add(
        "count(0). "
        "go :- count(N), N >= 3. "
        "go :- count(N), N < 3, retract(count(N)), N1 is N + 1, assert(count(N1)), cont."
    )
    r = p.query("go", max_ticks=10)
    assert r.ok


# --- Integration: backtracking ---

def test_backtracking(p):
    p.add("member(X, [X|_]). member(X, [_|T]) :- member(X, T).")
    assert p.query("member(b, [a,b,c])").ok
    assert not p.query("member(d, [a,b,c])").ok
