"""Subprocess wrapper for the proact binary."""

import os
import re
import subprocess
import tempfile


class ProactError(Exception):
    pass


def _find_binary():
    """Find the proact binary — packaged, local build, or PATH."""
    # 1. Bundled with pip install
    pkg_dir = os.path.dirname(__file__)
    for name in ("proact", "proact.exe"):
        path = os.path.join(pkg_dir, name)
        if os.path.isfile(path):
            return path

    # 2. Built locally (repo root/build/)
    repo = os.path.dirname(pkg_dir)
    for subdir in ("build", ""):
        for name in ("proact", "proact.exe"):
            path = os.path.join(repo, subdir, name)
            if os.path.isfile(path):
                return path

    # 3. On PATH
    from shutil import which
    path = which("proact")
    if path:
        return path

    raise ProactError(
        "proact binary not found. "
        "Run 'make' to build it or 'pip install .' to install the package."
    )


class Proact:
    """Three-valued reasoning engine.

    Example::

        p = Proact()
        p.consult("rules.pa")
        result = p.query("mortal(socrates)")
        print(result.status)  # 'done'

        # Multi-tick evaluation
        p.add("wait(3) :- tick(T), T >= 3.")
        p.add("wait(3) :- tick(T), T < 3, cont.")
        result = p.query("wait(3)", max_ticks=10)
        print(result.ticks)  # 4
    """

    def __init__(self, binary=None, max_ticks=1000, max_depth=512, trace=False):
        self._binary = binary or _find_binary()
        self._files = []
        self._inline = []
        self.max_ticks = max_ticks
        self.max_depth = max_depth
        self.trace = trace

    def consult(self, path):
        """Load a .pa file."""
        if not os.path.isfile(path):
            raise FileNotFoundError(f"No such file: {path}")
        self._files.append(os.path.abspath(path))
        return self

    def add(self, source):
        """Add clauses/directives from a string."""
        self._inline.append(source)
        return self

    def query(self, goal, max_ticks=None):
        """Evaluate a goal. Returns a Result."""
        if not goal.endswith("."):
            goal += "."

        ticks = max_ticks or self.max_ticks

        # Build a combined source file if we have inline clauses
        tmp = None
        files = list(self._files)

        if self._inline:
            tmp = tempfile.NamedTemporaryFile(
                mode="w", suffix=".pa", delete=False
            )
            tmp.write("\n".join(self._inline) + "\n")
            tmp.close()
            files.append(tmp.name)

        try:
            cmd = [self._binary] + files + [
                "--max-ticks", str(ticks),
                "-q",  # quiet — we parse output ourselves
                "-e", goal,
            ]
            if self.trace:
                cmd.append("--trace")

            proc = subprocess.run(
                cmd, capture_output=True, text=True, timeout=30,
            )
            return Result._parse(proc)
        finally:
            if tmp:
                os.unlink(tmp.name)

    def run(self, goal="main", max_ticks=None):
        """Shorthand for query(goal, max_ticks)."""
        return self.query(goal, max_ticks)

    def reset(self):
        """Clear all loaded files and inline clauses."""
        self._files.clear()
        self._inline.clear()
        return self


class Result:
    """Result of a proact query."""

    __slots__ = ("status", "output", "returncode")

    def __init__(self, status, output, returncode):
        self.status = status
        self.output = output
        self.returncode = returncode

    def _parse(proc):
        stdout = proc.stdout or ""
        stderr = proc.stderr or ""
        output = (stdout + stderr).strip()

        if proc.returncode == 0:
            status = "done"
        elif proc.returncode == 1:
            status = "fail"
        else:
            status = "error"

        return Result(status=status, output=output, returncode=proc.returncode)

    @property
    def ok(self):
        return self.status == "done"

    def __repr__(self):
        return f"Result(status={self.status!r})"

    def __bool__(self):
        return self.ok


def main():
    """CLI entry point — run the proact binary with all arguments."""
    import sys
    binary = _find_binary()
    os.execv(binary, [binary] + sys.argv[1:])
