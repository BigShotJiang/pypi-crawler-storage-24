/*
 * term.c - Term creation and printing
 */

#include "proact.h"

term *make_atom(const char *name) {
    term *t = calloc(1, sizeof(term));
    t->type = TERM_ATOM;
    t->name = str_dup(name);
    return t;
}

term *make_var(const char *name, int id) {
    term *t = calloc(1, sizeof(term));
    t->type = TERM_VAR;
    t->name = str_dup(name);
    t->ival = id;
    return t;
}

term *make_int(int val) {
    term *t = calloc(1, sizeof(term));
    t->type = TERM_INT;
    t->ival = val;
    return t;
}

term *make_compound(const char *functor, int arity, term **args) {
    term *t = calloc(1, sizeof(term));
    t->type = TERM_COMPOUND;
    t->name = str_dup(functor);
    t->arity = arity;
    t->args = malloc(arity * sizeof(term *));
    for (int i = 0; i < arity; i++)
        t->args[i] = args[i];
    return t;
}

term *make_compound2(const char *functor, term *a, term *b) {
    term *args[2] = {a, b};
    return make_compound(functor, 2, args);
}

term *make_compound1(const char *functor, term *a) {
    return make_compound(functor, 1, &a);
}

/* Deep copy with variable ID offset (for clause renaming) */
term *copy_term(term *t, int var_offset) {
    if (!t) return NULL;
    switch (t->type) {
    case TERM_ATOM:
        return make_atom(t->name);
    case TERM_VAR:
        return make_var(t->name, t->ival + var_offset);
    case TERM_INT:
        return make_int(t->ival);
    case TERM_COMPOUND: {
        term **args = malloc(t->arity * sizeof(term *));
        for (int i = 0; i < t->arity; i++)
            args[i] = copy_term(t->args[i], var_offset);
        term *c = make_compound(t->name, t->arity, args);
        free(args);
        return c;
    }
    }
    return NULL;
}

/* Print a term, resolving variable bindings */
void print_term(term *t, env *e) {
    if (!t) { printf("null"); return; }

    if (e && t->type == TERM_VAR) {
        t = deref(t, e);
    }

    switch (t->type) {
    case TERM_ATOM:
        printf("%s", t->name);
        break;
    case TERM_VAR:
        printf("_%d", t->ival);
        break;
    case TERM_INT:
        printf("%d", t->ival);
        break;
    case TERM_COMPOUND:
        /* List printing: .(H, T) as [H|T] */
        if (t->arity == 2 && strcmp(t->name, ".") == 0) {
            printf("[");
            print_term(t->args[0], e);
            term *tail = e ? deref(t->args[1], e) : t->args[1];
            while (tail && tail->type == TERM_COMPOUND &&
                   strcmp(tail->name, ".") == 0 && tail->arity == 2) {
                printf(",");
                print_term(tail->args[0], e);
                tail = e ? deref(tail->args[1], e) : tail->args[1];
            }
            if (tail && !(tail->type == TERM_ATOM && strcmp(tail->name, "[]") == 0)) {
                printf("|");
                print_term(tail, e);
            }
            printf("]");
        /* Special printing for comma and semicolon */
        } else if (t->arity == 2 && strcmp(t->name, ",") == 0) {
            print_term(t->args[0], e);
            printf(", ");
            print_term(t->args[1], e);
        } else if (t->arity == 2 && strcmp(t->name, ";") == 0) {
            printf("(");
            print_term(t->args[0], e);
            printf(" ; ");
            print_term(t->args[1], e);
            printf(")");
        } else if (t->arity == 2 && strcmp(t->name, "->") == 0) {
            print_term(t->args[0], e);
            printf(" -> ");
            print_term(t->args[1], e);
        } else if (t->arity == 2 && (strcmp(t->name, "is") == 0 ||
                   strcmp(t->name, "=") == 0 || strcmp(t->name, "<") == 0 ||
                   strcmp(t->name, ">") == 0 || strcmp(t->name, ">=") == 0 ||
                   strcmp(t->name, "=<") == 0 || strcmp(t->name, "+") == 0 ||
                   strcmp(t->name, "-") == 0 || strcmp(t->name, "*") == 0 ||
                   strcmp(t->name, "//") == 0 || strcmp(t->name, "mod") == 0)) {
            print_term(t->args[0], e);
            printf(" %s ", t->name);
            print_term(t->args[1], e);
        } else if (t->arity == 1 && strcmp(t->name, "\\+") == 0) {
            printf("\\+ ");
            print_term(t->args[0], e);
        } else {
            printf("%s(", t->name);
            for (int i = 0; i < t->arity; i++) {
                if (i > 0) printf(", ");
                print_term(t->args[i], e);
            }
            printf(")");
        }
        break;
    }
}

/* Print without resolving bindings */
void print_term_raw(term *t) {
    print_term(t, NULL);
}

const char *status_str(status s) {
    switch (s) {
    case DONE: return "done";
    case CONT: return "cont";
    case FAIL: return "fail";
    }
    return "?";
}
