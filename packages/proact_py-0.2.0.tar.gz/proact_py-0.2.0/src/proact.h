/*
 * proact.h - Core types for the Proact interpreter
 *
 * Proact: Active Logic meets Prolog
 *
 * predicate logic => prolog
 * active logic    => proact
 *
 * Three-valued logic (done/cont/fail) replaces Prolog's two-valued
 * (succeed/fail). Goals can return "cont" meaning "still working,
 * try again next tick."
 */

#ifndef PROACT_H
#define PROACT_H

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>
#include <ctype.h>

/* === Three-valued status === */
typedef enum { FAIL = -1, CONT = 0, DONE = 1 } status;

/* === Term representation === */
typedef enum { TERM_ATOM, TERM_VAR, TERM_INT, TERM_COMPOUND } term_type;

typedef struct term {
    term_type type;
    const char *name;   /* atom name, var name, or functor */
    int ival;           /* integer value (INT) or var_id (VAR) */
    int arity;          /* compound arity */
    struct term **args; /* compound arguments */
} term;

/* === Clause: head :- body. === */
typedef struct clause {
    term *head;
    term *body;             /* NULL for facts */
    struct clause *next;
} clause;

/* === Database === */
typedef struct database {
    clause *first;
    clause *last;
} database;

/* === Variable bindings === */
#define MAX_VARS 65536
#define CLAUSE_VAR_STRIDE 256

typedef struct env {
    term **bindings;    /* heap-allocated, MAX_VARS entries */
    int *trail;
    int trail_top;
} env;

/* === Global state === */
typedef struct proact {
    database db;
    int tick;
    int next_var_id;     /* for parser var IDs */
    int eval_var_id;     /* for clause renaming during eval, resets per tick */
    int max_ticks;
    int max_depth;
    bool trace;
} proact;

/* --- term.c --- */
term *make_atom(const char *name);
term *make_var(const char *name, int id);
term *make_int(int val);
term *make_compound(const char *functor, int arity, term **args);
term *make_compound2(const char *functor, term *a, term *b);
term *make_compound1(const char *functor, term *a);
term *copy_term(term *t, int var_offset);
void print_term(term *t, env *e);
void print_term_raw(term *t);
const char *status_str(status s);

/* --- parse.c --- */
typedef enum {
    TOK_ATOM, TOK_VAR, TOK_INT,
    TOK_LPAREN, TOK_RPAREN,
    TOK_LBRACKET, TOK_RBRACKET,
    TOK_COMMA, TOK_DOT, TOK_SEMI,
    TOK_NECK, TOK_QUERY,
    TOK_ARROW, TOK_PIPE,
    TOK_NOT,
    TOK_OP,     /* generic operator: is, <, >, >=, =<, =, \=, =:=, =\=, +, -, *, // */
    TOK_EOF
} token_type;

typedef struct {
    token_type type;
    char text[256];
    int ival;
} token;

typedef struct {
    const char *input;
    int pos;
    token cur;
    int next_var_id;
    /* var name -> id mapping for current clause */
    char *var_names[MAX_VARS];
    int var_ids[MAX_VARS];
    int var_count;
} parser;

void parser_init(parser *p, const char *input, int start_var_id);
int parser_end_var_id(parser *p);
term *parse_term(parser *p);
term *parse_full_term(parser *p);
clause *parse_clause(parser *p);
bool parse_directive(parser *p, term **out);

/* --- unify.c --- */
void env_init(env *e);
void env_free(env *e);
int env_save(env *e);
void env_restore(env *e, int save_point);
term *deref(term *t, env *e);
term *resolve(term *t, env *e);  /* deep resolve: substitute all vars */
bool unify(term *a, term *b, env *e);

/* --- eval.c --- */
void db_init(database *db);
void db_add_clause(database *db, clause *c);
bool db_retract(database *db, term *head, env *e);
status eval_goal(term *goal, env *e, proact *pl, int depth);
int eval_arith(term *t, env *e);

/* helper */
static inline char *str_dup(const char *s) {
    char *d = malloc(strlen(s) + 1);
    if (d) strcpy(d, s);
    return d;
}

#endif
