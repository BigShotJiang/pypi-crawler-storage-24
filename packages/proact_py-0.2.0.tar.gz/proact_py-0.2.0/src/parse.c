/*
 * parse.c - Lexer and parser for Prolog-like syntax with active logic extensions
 *
 * Supports: atoms, variables, integers, compound terms, operators
 * Operator precedence (standard Prolog):
 *   1100: ;    (xfy)
 *   1050: ->   (xfy)
 *   1000: ,    (xfy)
 *    700: is, =, \=, <, >, >=, =<  (xfx)
 *    500: +, - (yfx)
 *    400: *, //, mod (yfx)
 *    200: \+   (fy)
 */

#include "proact.h"

/* === Lexer === */

static void skip_whitespace(parser *p) {
    while (p->input[p->pos]) {
        /* skip spaces */
        if (isspace(p->input[p->pos])) {
            p->pos++;
            continue;
        }
        /* skip line comments */
        if (p->input[p->pos] == '%') {
            while (p->input[p->pos] && p->input[p->pos] != '\n')
                p->pos++;
            continue;
        }
        /* skip block comments */
        if (p->input[p->pos] == '/' && p->input[p->pos+1] == '*') {
            p->pos += 2;
            while (p->input[p->pos] && !(p->input[p->pos] == '*' && p->input[p->pos+1] == '/'))
                p->pos++;
            if (p->input[p->pos]) p->pos += 2;
            continue;
        }
        break;
    }
}

static void next_token(parser *p) {
    skip_whitespace(p);

    if (!p->input[p->pos]) {
        p->cur.type = TOK_EOF;
        p->cur.text[0] = 0;
        return;
    }

    char c = p->input[p->pos];

    /* Single character tokens */
    if (c == '(') { p->cur.type = TOK_LPAREN; p->cur.text[0] = '('; p->cur.text[1] = 0; p->pos++; return; }
    if (c == '[') { p->cur.type = TOK_LBRACKET; p->cur.text[0] = '['; p->cur.text[1] = 0; p->pos++; return; }
    if (c == ']') { p->cur.type = TOK_RBRACKET; p->cur.text[0] = ']'; p->cur.text[1] = 0; p->pos++; return; }
    if (c == ')') { p->cur.type = TOK_RPAREN; p->cur.text[0] = ')'; p->cur.text[1] = 0; p->pos++; return; }
    if (c == ',') { p->cur.type = TOK_COMMA;  p->cur.text[0] = ','; p->cur.text[1] = 0; p->pos++; return; }
    if (c == '.') {
        /* Check if dot is followed by whitespace or EOF (clause terminator) vs part of a number */
        char next = p->input[p->pos + 1];
        if (next == 0 || isspace(next) || next == '%') {
            p->cur.type = TOK_DOT; p->cur.text[0] = '.'; p->cur.text[1] = 0; p->pos++;
            return;
        }
    }
    if (c == '|') { p->cur.type = TOK_PIPE; p->cur.text[0] = '|'; p->cur.text[1] = 0; p->pos++; return; }

    /* :- and :  */
    if (c == ':' && p->input[p->pos+1] == '-') {
        p->cur.type = TOK_NECK; strcpy(p->cur.text, ":-"); p->pos += 2; return;
    }

    /* ?- */
    if (c == '?' && p->input[p->pos+1] == '-') {
        p->cur.type = TOK_QUERY; strcpy(p->cur.text, "?-"); p->pos += 2; return;
    }

    /* -> */
    if (c == '-' && p->input[p->pos+1] == '>') {
        p->cur.type = TOK_ARROW; strcpy(p->cur.text, "->"); p->pos += 2; return;
    }

    /* ; */
    if (c == ';') { p->cur.type = TOK_SEMI; p->cur.text[0] = ';'; p->cur.text[1] = 0; p->pos++; return; }

    /* =:= */
    if (c == '=' && p->input[p->pos+1] == ':' && p->input[p->pos+2] == '=') {
        p->cur.type = TOK_OP; strcpy(p->cur.text, "=:="); p->pos += 3; return;
    }
    /* =\= */
    if (c == '=' && p->input[p->pos+1] == '\\' && p->input[p->pos+2] == '=') {
        p->cur.type = TOK_OP; strcpy(p->cur.text, "=\\="); p->pos += 3; return;
    }
    /* =< */
    if (c == '=' && p->input[p->pos+1] == '<') {
        p->cur.type = TOK_OP; strcpy(p->cur.text, "=<"); p->pos += 2; return;
    }
    /* = */
    if (c == '=' && p->input[p->pos+1] != ':' && p->input[p->pos+1] != '\\' && p->input[p->pos+1] != '<') {
        p->cur.type = TOK_OP; strcpy(p->cur.text, "="); p->pos += 1; return;
    }

    /* \+ and \= */
    if (c == '\\') {
        if (p->input[p->pos+1] == '+') {
            p->cur.type = TOK_NOT; strcpy(p->cur.text, "\\+"); p->pos += 2; return;
        }
        if (p->input[p->pos+1] == '=') {
            p->cur.type = TOK_OP; strcpy(p->cur.text, "\\="); p->pos += 2; return;
        }
    }

    /* >= */
    if (c == '>' && p->input[p->pos+1] == '=') {
        p->cur.type = TOK_OP; strcpy(p->cur.text, ">="); p->pos += 2; return;
    }
    /* > */
    if (c == '>') {
        p->cur.type = TOK_OP; strcpy(p->cur.text, ">"); p->pos += 1; return;
    }
    /* < */
    if (c == '<') {
        p->cur.type = TOK_OP; strcpy(p->cur.text, "<"); p->pos += 1; return;
    }

    /* // (integer division) */
    if (c == '/' && p->input[p->pos+1] == '/') {
        p->cur.type = TOK_OP; strcpy(p->cur.text, "//"); p->pos += 2; return;
    }

    /* Arithmetic: +, -, * */
    if (c == '+') { p->cur.type = TOK_OP; p->cur.text[0] = '+'; p->cur.text[1] = 0; p->pos++; return; }
    if (c == '*') { p->cur.type = TOK_OP; p->cur.text[0] = '*'; p->cur.text[1] = 0; p->pos++; return; }

    /* Minus: could be negative number or operator */
    if (c == '-' && !isdigit(p->input[p->pos+1])) {
        p->cur.type = TOK_OP; p->cur.text[0] = '-'; p->cur.text[1] = 0; p->pos++; return;
    }

    /* Integer (possibly negative) */
    if (isdigit(c) || (c == '-' && isdigit(p->input[p->pos+1]))) {
        int i = 0;
        if (c == '-') p->cur.text[i++] = p->input[p->pos++];
        while (isdigit(p->input[p->pos]))
            p->cur.text[i++] = p->input[p->pos++];
        p->cur.text[i] = 0;
        p->cur.type = TOK_INT;
        p->cur.ival = atoi(p->cur.text);
        return;
    }

    /* Quoted atom: 'hello world' */
    if (c == '\'') {
        p->pos++;
        int i = 0;
        while (p->input[p->pos] && p->input[p->pos] != '\'') {
            if (p->input[p->pos] == '\\' && p->input[p->pos+1])
                p->pos++;
            p->cur.text[i++] = p->input[p->pos++];
        }
        if (p->input[p->pos] == '\'') p->pos++;
        p->cur.text[i] = 0;
        p->cur.type = TOK_ATOM;
        return;
    }

    /* Variable: starts with uppercase or _ */
    if (isupper(c) || c == '_') {
        int i = 0;
        while (isalnum(p->input[p->pos]) || p->input[p->pos] == '_')
            p->cur.text[i++] = p->input[p->pos++];
        p->cur.text[i] = 0;
        p->cur.type = TOK_VAR;
        return;
    }

    /* Atom or keyword: starts with lowercase */
    if (islower(c)) {
        int i = 0;
        while (isalnum(p->input[p->pos]) || p->input[p->pos] == '_')
            p->cur.text[i++] = p->input[p->pos++];
        p->cur.text[i] = 0;

        /* Check for operator keywords */
        if (strcmp(p->cur.text, "is") == 0 || strcmp(p->cur.text, "mod") == 0) {
            p->cur.type = TOK_OP;
        } else {
            p->cur.type = TOK_ATOM;
        }
        return;
    }

    /* Unknown character - skip it */
    fprintf(stderr, "warning: unexpected character '%c'\n", c);
    p->pos++;
    next_token(p);
}

/* === Variable Management === */

static int find_or_add_var(parser *p, const char *name) {
    /* Anonymous variable always gets a fresh id */
    if (strcmp(name, "_") == 0) {
        return p->next_var_id++;
    }
    /* Look for existing variable in current clause */
    for (int i = 0; i < p->var_count; i++) {
        if (strcmp(p->var_names[i], name) == 0)
            return p->var_ids[i];
    }
    /* New variable */
    int id = p->next_var_id++;
    p->var_names[p->var_count] = str_dup(name);
    p->var_ids[p->var_count] = id;
    p->var_count++;
    return id;
}

static void reset_vars(parser *p) {
    for (int i = 0; i < p->var_count; i++)
        free(p->var_names[i]);
    p->var_count = 0;
}

/* === Parser === */

void parser_init(parser *p, const char *input, int start_var_id) {
    memset(p, 0, sizeof(*p));
    p->input = input;
    p->pos = 0;
    p->next_var_id = start_var_id;
    p->var_count = 0;
    next_token(p);
}

int parser_end_var_id(parser *p) {
    return p->next_var_id;
}

static term *parse_expr(parser *p, int min_prec);

static term *parse_primary(parser *p) {
    if (p->cur.type == TOK_INT) {
        term *t = make_int(p->cur.ival);
        next_token(p);
        return t;
    }

    if (p->cur.type == TOK_VAR) {
        int id = find_or_add_var(p, p->cur.text);
        term *t = make_var(p->cur.text, id);
        next_token(p);
        return t;
    }

    if (p->cur.type == TOK_ATOM) {
        char name[256];
        strcpy(name, p->cur.text);
        next_token(p);

        /* Check for compound term: atom(...) */
        if (p->cur.type == TOK_LPAREN) {
            next_token(p); /* consume ( */
            term *args[64];
            int arity = 0;
            if (p->cur.type != TOK_RPAREN) {
                args[arity++] = parse_expr(p, 999); /* below comma precedence */
                while (p->cur.type == TOK_COMMA) {
                    next_token(p); /* consume , */
                    args[arity++] = parse_expr(p, 999);
                }
            }
            if (p->cur.type == TOK_RPAREN)
                next_token(p); /* consume ) */
            return make_compound(name, arity, args);
        }

        return make_atom(name);
    }

    if (p->cur.type == TOK_LPAREN) {
        next_token(p); /* consume ( */
        term *t = parse_expr(p, 1200);
        if (p->cur.type == TOK_RPAREN)
            next_token(p); /* consume ) */
        return t;
    }

    /* List: [a, b, c] or [H|T] or [] */
    if (p->cur.type == TOK_LBRACKET) {
        next_token(p); /* consume [ */
        if (p->cur.type == TOK_RBRACKET) {
            next_token(p); /* consume ] — empty list */
            return make_atom("[]");
        }
        /* Parse list elements */
        term *head = parse_expr(p, 999);
        term *list;
        if (p->cur.type == TOK_PIPE) {
            /* [H|T] syntax */
            next_token(p); /* consume | */
            term *tail = parse_expr(p, 999);
            list = make_compound2(".", head, tail);
        } else {
            /* Build list from remaining elements */
            list = make_compound2(".", head, NULL);
            term *tail = list;
            while (p->cur.type == TOK_COMMA) {
                next_token(p); /* consume , */
                term *elem = parse_expr(p, 999);
                term *cell = make_compound2(".", elem, NULL);
                tail->args[1] = cell;
                tail = cell;
            }
            if (p->cur.type == TOK_PIPE) {
                next_token(p); /* consume | */
                tail->args[1] = parse_expr(p, 999);
            } else {
                tail->args[1] = make_atom("[]");
            }
        }
        if (p->cur.type == TOK_RBRACKET)
            next_token(p); /* consume ] */
        return list;
    }

    /* \+ (negation as failure / inverter) */
    if (p->cur.type == TOK_NOT) {
        next_token(p);
        term *arg = parse_primary(p);
        return make_compound1("\\+", arg);
    }

    /* Unary minus */
    if (p->cur.type == TOK_OP && strcmp(p->cur.text, "-") == 0) {
        next_token(p);
        term *arg = parse_primary(p);
        if (arg->type == TERM_INT) {
            arg->ival = -arg->ival;
            return arg;
        }
        return make_compound1("-", arg);
    }

    fprintf(stderr, "parse error: unexpected token '%s'\n", p->cur.text);
    next_token(p);
    return make_atom("error");
}

/* Operator precedence and associativity */
static int op_prec(const char *op) {
    if (strcmp(op, ":-") == 0)  return 1200;
    if (strcmp(op, ";") == 0)   return 1100;
    if (strcmp(op, "->") == 0)  return 1050;
    if (strcmp(op, ",") == 0)   return 1000;
    if (strcmp(op, "is") == 0)  return 700;
    if (strcmp(op, "=") == 0)   return 700;
    if (strcmp(op, "\\=") == 0) return 700;
    if (strcmp(op, "<") == 0)   return 700;
    if (strcmp(op, ">") == 0)   return 700;
    if (strcmp(op, ">=") == 0)  return 700;
    if (strcmp(op, "=<") == 0)  return 700;
    if (strcmp(op, "=:=") == 0) return 700;
    if (strcmp(op, "=\\=") == 0) return 700;
    if (strcmp(op, "+") == 0)   return 500;
    if (strcmp(op, "-") == 0)   return 500;
    if (strcmp(op, "*") == 0)   return 400;
    if (strcmp(op, "//") == 0)  return 400;
    if (strcmp(op, "mod") == 0) return 400;
    return 0;
}

/* Right-associative operators use same prec for right side */
static bool op_right_assoc(const char *op) {
    return (strcmp(op, ";") == 0 || strcmp(op, "->") == 0 || strcmp(op, ",") == 0);
}

static const char *cur_op_text(parser *p) {
    if (p->cur.type == TOK_COMMA)  return ",";
    if (p->cur.type == TOK_SEMI)   return ";";
    if (p->cur.type == TOK_ARROW)  return "->";
    if (p->cur.type == TOK_NECK)   return ":-";
    if (p->cur.type == TOK_OP)     return p->cur.text;
    return NULL;
}

static term *parse_expr(parser *p, int min_prec) {
    term *left = parse_primary(p);

    for (;;) {
        const char *op = cur_op_text(p);
        if (!op) break;

        int prec = op_prec(op);
        if (prec == 0 || prec > min_prec) break;

        char op_name[16];
        strcpy(op_name, op);
        next_token(p);

        int right_prec = op_right_assoc(op_name) ? prec : prec - 1;
        term *right = parse_expr(p, right_prec);
        left = make_compound2(op_name, left, right);
    }

    return left;
}

/* Parse a full term (at max precedence) */
term *parse_full_term(parser *p) {
    return parse_expr(p, 1200);
}

/* Parse a top-level term at default precedence */
term *parse_term(parser *p) {
    return parse_expr(p, 1200);
}

/* Parse a clause: head :- body. OR head. */
clause *parse_clause(parser *p) {
    reset_vars(p);

    if (p->cur.type == TOK_EOF) return NULL;

    /* Directive: :- goal. */
    if (p->cur.type == TOK_NECK) {
        next_token(p); /* consume :- */
        term *body = parse_expr(p, 1199);
        if (p->cur.type == TOK_DOT) next_token(p);
        clause *c = calloc(1, sizeof(clause));
        c->head = make_atom("directive");
        c->body = body;
        return c;
    }

    term *head = parse_expr(p, 999);

    clause *c = calloc(1, sizeof(clause));
    c->head = head;

    if (p->cur.type == TOK_NECK) {
        next_token(p); /* consume :- */
        c->body = parse_expr(p, 1199);
    }

    if (p->cur.type == TOK_DOT) next_token(p);

    return c;
}

/* Parse a query: ?- goal. Returns the goal term */
bool parse_directive(parser *p, term **out) {
    if (p->cur.type == TOK_QUERY) {
        next_token(p); /* consume ?- */
        *out = parse_expr(p, 1199);
        if (p->cur.type == TOK_DOT) next_token(p);
        return true;
    }
    return false;
}
