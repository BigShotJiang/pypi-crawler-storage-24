/*
 * main.c - Proact runtime
 *
 * Workflow:
 *   proact agent.pa          # run main/0 if defined, else interactive mode
 *   proact agent.pa -e "g."  # run specific goal
 *   proact                   # interactive mode
 *   proact agent.pa --step   # step through ticks manually
 */

#include "proact.h"

#define INPUT_BUF_SIZE 4096
#define DEFAULT_MAX_TICKS 10000
#define DEFAULT_MAX_DEPTH 512

static bool step_mode = false;
static bool quiet = false;

/* === Output helpers === */

static void print_bindings(env *e, parser *p) {
    bool any = false;
    for (int i = 0; i < p->var_count; i++) {
        if (strcmp(p->var_names[i], "_") == 0) continue;
        int id = p->var_ids[i];
        term *val = deref(make_var(p->var_names[i], id), e);
        if (val->type != TERM_VAR || val->ival != id) {
            if (any) printf(", ");
            printf("%s = ", p->var_names[i]);
            print_term(val, e);
            any = true;
        }
    }
    if (any) printf("\n");
}

static void print_status_line(int tick, status s) {
    if (s == DONE)
        printf("[tick %d] done.\n", tick);
    else if (s == FAIL)
        printf("[tick %d] fail.\n", tick);
    else
        printf("[tick %d] cont\n", tick);
}

/* === Tick runner === */

static status run_ticks(term *goal, parser *p, proact *pl) {
    pl->tick = 0;

    for (int tick = 0; tick < pl->max_ticks; tick++) {
        pl->tick = tick;
        pl->eval_var_id = CLAUSE_VAR_STRIDE;
        env e;
        env_init(&e);

        status s = eval_goal(goal, &e, pl, 0);

        if (s == DONE) {
            if (!quiet && p) print_bindings(&e, p);
            if (!quiet) print_status_line(tick, s);
            env_free(&e);
            return DONE;
        }
        if (s == FAIL) {
            if (!quiet) print_status_line(tick, s);
            env_free(&e);
            return FAIL;
        }

        /* s == CONT */
        if (!quiet) {
            printf("[tick %d] cont", tick);
            /* Show partial bindings if any */
            if (p) {
                bool any = false;
                for (int i = 0; i < p->var_count; i++) {
                    if (strcmp(p->var_names[i], "_") == 0) continue;
                    int id = p->var_ids[i];
                    term *val = deref(make_var(p->var_names[i], id), &e);
                    if (val->type != TERM_VAR || val->ival != id) {
                        if (!any) printf("  (");
                        else printf(", ");
                        printf("%s = ", p->var_names[i]);
                        print_term(val, &e);
                        any = true;
                    }
                }
                if (any) printf(")");
            }
            printf("\n");
        }

        env_free(&e);

        if (step_mode) {
            printf("  [enter] next tick, [q] quit: ");
            fflush(stdout);
            int ch = getchar();
            if (ch == 'q' || ch == 'Q' || ch == EOF) return CONT;
            /* Consume rest of line */
            if (ch != '\n') while (getchar() != '\n');
        }
    }

    printf("tick limit (%d).\n", pl->max_ticks);
    return CONT;
}

/* === REPL === */

static void repl(proact *pl) {
    char input[INPUT_BUF_SIZE];

    printf("proact 0.1 - active logic meets prolog\n");
    printf("  done/cont/fail | type 'halt.' to exit\n\n");

    for (;;) {
        printf("?- ");
        fflush(stdout);

        if (!fgets(input, sizeof(input), stdin))
            break;

        char *s = input;
        while (isspace(*s)) s++;
        if (*s == 0) continue;

        parser p;
        parser_init(&p, s, pl->next_var_id);

        term *goal = parse_term(&p);
        if (!goal) continue;

        pl->next_var_id = parser_end_var_id(&p);

        run_ticks(goal, &p, pl);
    }
}

/* === File loading === */

static void load_file(proact *pl, const char *filename) {
    env e;
    env_init(&e);
    term *arg = make_atom(filename);
    term *goal = make_compound1("consult", arg);
    status s = eval_goal(goal, &e, pl, 0);
    env_free(&e);
    if (s != DONE) {
        fprintf(stderr, "error: cannot consult '%s'\n", filename);
    }
}

/* === Check if main/0 is defined === */

static bool has_main(proact *pl) {
    term *main_atom = make_atom("main");
    for (clause *c = pl->db.first; c; c = c->next) {
        if (c->head->type == TERM_ATOM && strcmp(c->head->name, "main") == 0)
            return true;
        if (c->head->type == TERM_COMPOUND && strcmp(c->head->name, "main") == 0
            && c->head->arity == 0)
            return true;
    }
    (void)main_atom;
    return false;
}

/* === Entry point === */

int main(int argc, char *argv[]) {
    proact pl;
    memset(&pl, 0, sizeof(pl));
    db_init(&pl.db);
    pl.max_ticks = DEFAULT_MAX_TICKS;
    pl.max_depth = DEFAULT_MAX_DEPTH;
    pl.trace = false;
    pl.next_var_id = 0;

    const char *eval_str = NULL;
    bool has_files = false;

    for (int i = 1; i < argc; i++) {
        if (strcmp(argv[i], "-e") == 0 && i + 1 < argc) {
            eval_str = argv[++i];
        } else if (strcmp(argv[i], "-t") == 0 || strcmp(argv[i], "--trace") == 0) {
            pl.trace = true;
        } else if (strcmp(argv[i], "-q") == 0 || strcmp(argv[i], "--quiet") == 0) {
            quiet = true;
        } else if (strcmp(argv[i], "-s") == 0 || strcmp(argv[i], "--step") == 0) {
            step_mode = true;
        } else if (strcmp(argv[i], "--max-ticks") == 0 && i + 1 < argc) {
            pl.max_ticks = atoi(argv[++i]);
        } else if (strcmp(argv[i], "-h") == 0 || strcmp(argv[i], "--help") == 0) {
            printf("proact - active logic meets prolog\n\n");
            printf("usage: proact [options] [files]\n\n");
            printf("  proact agent.pa          run main/0 from file\n");
            printf("  proact agent.pa -e 'g.'  run specific goal\n");
            printf("  proact                   interactive mode\n\n");
            printf("options:\n");
            printf("  -e goal       evaluate goal\n");
            printf("  -s, --step    step through ticks manually\n");
            printf("  -q, --quiet   suppress tick output\n");
            printf("  -t, --trace   trace unknown predicates\n");
            printf("  --max-ticks N set tick limit (default %d)\n", DEFAULT_MAX_TICKS);
            printf("  -h, --help    show this help\n");
            return 0;
        } else {
            load_file(&pl, argv[i]);
            has_files = true;
        }
    }

    if (eval_str) {
        /* -e "goal." : run specific goal */
        parser p;
        parser_init(&p, eval_str, pl.next_var_id);
        term *goal = parse_term(&p);
        pl.next_var_id = parser_end_var_id(&p);
        if (goal) {
            status s = run_ticks(goal, &p, &pl);
            return (s == FAIL) ? 1 : 0;
        }
    } else if (has_files && has_main(&pl)) {
        /* File with main/0 defined: auto-run it */
        parser p;
        parser_init(&p, "main.", pl.next_var_id);
        term *goal = parse_term(&p);
        pl.next_var_id = parser_end_var_id(&p);
        status s = run_ticks(goal, &p, &pl);
        return (s == FAIL) ? 1 : 0;
    } else {
        /* No goal, no main: interactive mode */
        repl(&pl);
    }

    return 0;
}
