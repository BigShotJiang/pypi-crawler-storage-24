/*
 * eval.c - Three-valued evaluation engine with continuation-passing
 *
 * THE HEART OF PROACT
 *
 * This is where active logic diverges from Prolog:
 *
 * 1. Goals return status (done/cont/fail) instead of bool
 * 2. Conjunction (,) short-circuits on cont: if left is cont,
 *    don't evaluate right (active logic AND)
 * 3. Disjunction (;) short-circuits on non-fail: if left is
 *    done or cont, don't try alternatives (active logic OR)
 * 4. Clause resolution: don't backtrack on cont, only on fail
 * 5. Built-in 'cont' returns the cont status
 *
 * Continuation-passing: conjunctions thread a "continuation" (the
 * rest of the goals) through user-defined predicates. If a clause
 * body succeeds but the continuation fails, the engine backtracks
 * and tries the next clause. This gives standard Prolog backtracking.
 */

#include "proact.h"

/* Forward declaration — the core evaluator with continuation */
static status eval_with_cont(term *goal, term *cont, env *e, proact *pl, int depth);

/* === Database === */

void db_init(database *db) {
    db->first = NULL;
    db->last = NULL;
}

void db_add_clause(database *db, clause *c) {
    c->next = NULL;
    if (db->last) {
        db->last->next = c;
    } else {
        db->first = c;
    }
    db->last = c;
}

/* Retract first clause whose head unifies with the given term */
bool db_retract(database *db, term *head, env *e) {
    clause **pp = &db->first;
    while (*pp) {
        clause *c = *pp;
        int save = env_save(e);
        term *ch = copy_term(c->head, 0);
        if (unify(head, ch, e)) {
            *pp = c->next;
            if (db->last == c) {
                db->last = NULL;
                for (clause *q = db->first; q; q = q->next)
                    db->last = q;
            }
            return true;
        }
        env_restore(e, save);
        pp = &(*pp)->next;
    }
    return false;
}

/* === Arithmetic Evaluation === */

int eval_arith(term *t, env *e) {
    t = deref(t, e);
    if (!t) return 0;

    if (t->type == TERM_INT) return t->ival;

    if (t->type == TERM_COMPOUND && t->arity == 2) {
        int l = eval_arith(t->args[0], e);
        int r = eval_arith(t->args[1], e);
        if (strcmp(t->name, "+") == 0) return l + r;
        if (strcmp(t->name, "-") == 0) return l - r;
        if (strcmp(t->name, "*") == 0) return l * r;
        if (strcmp(t->name, "//") == 0) return r ? l / r : 0;
        if (strcmp(t->name, "mod") == 0) return r ? l % r : 0;
    }

    if (t->type == TERM_COMPOUND && t->arity == 1) {
        int v = eval_arith(t->args[0], e);
        if (strcmp(t->name, "-") == 0) return -v;
        if (strcmp(t->name, "abs") == 0) return v < 0 ? -v : v;
    }

    if (t->type == TERM_ATOM) {
        fprintf(stderr, "arithmetic error: '%s' is not a number\n", t->name);
    }

    return 0;
}

/* === Predicate matching === */

static bool head_matches(term *goal, term *head) {
    if (goal->type == TERM_ATOM && head->type == TERM_ATOM)
        return strcmp(goal->name, head->name) == 0;
    if (goal->type == TERM_COMPOUND && head->type == TERM_COMPOUND)
        return goal->arity == head->arity && strcmp(goal->name, head->name) == 0;
    if (goal->type == TERM_ATOM && head->type == TERM_COMPOUND)
        return false;
    if (goal->type == TERM_COMPOUND && head->type == TERM_ATOM)
        return false;
    return true;
}

/* === Helper: merge body with continuation === */
static term *merge_cont(term *body, term *cont) {
    if (!body) return cont;
    if (!cont) return body;
    return make_compound2(",", body, cont);
}

/* === Evaluate continuation (rest of goals after a built-in succeeds) === */
static status eval_cont(term *cont, env *e, proact *pl, int depth) {
    if (!cont) return DONE;
    return eval_with_cont(cont, NULL, e, pl, depth);
}

/* === Three-Valued Goal Evaluation with Continuation === */

static status eval_with_cont(term *goal, term *cont, env *e, proact *pl, int depth) {
    if (depth > pl->max_depth) {
        fprintf(stderr, "depth limit exceeded\n");
        return FAIL;
    }

    goal = deref(goal, e);
    if (!goal) return FAIL;

    /* === Built-in atoms === */
    if (goal->type == TERM_ATOM) {
        const char *name = goal->name;
        if (strcmp(name, "true") == 0 || strcmp(name, "done") == 0)
            return eval_cont(cont, e, pl, depth);
        if (strcmp(name, "fail") == 0 || strcmp(name, "false") == 0)
            return FAIL;
        if (strcmp(name, "cont") == 0)
            return CONT;  /* short-circuit: don't evaluate cont */
        if (strcmp(name, "nl") == 0)
            { printf("\n"); return eval_cont(cont, e, pl, depth); }
        if (strcmp(name, "halt") == 0)
            { exit(0); }
    }

    /* === Built-in compound predicates === */
    if (goal->type == TERM_COMPOUND) {
        const char *f = goal->name;
        int arity = goal->arity;

        /* --- Conjunction (,) --- Active logic AND / Sequence
         * Flatten: (A, B) with continuation C becomes A with continuation (B, C) */
        if (arity == 2 && strcmp(f, ",") == 0) {
            term *new_cont = merge_cont(goal->args[1], cont);
            return eval_with_cont(goal->args[0], new_cont, e, pl, depth);
        }

        /* --- Disjunction (;) --- Active logic OR / Selector */
        if (arity == 2 && strcmp(f, ";") == 0) {
            /* Special case: if-then-else (Cond -> Then ; Else) */
            if (goal->args[0]->type == TERM_COMPOUND &&
                strcmp(goal->args[0]->name, "->") == 0 &&
                goal->args[0]->arity == 2) {
                term *cond = goal->args[0]->args[0];
                term *then_g = goal->args[0]->args[1];
                term *else_g = goal->args[1];
                int save = env_save(e);
                status cs = eval_with_cont(cond, NULL, e, pl, depth + 1);
                if (cs == DONE) return eval_with_cont(then_g, cont, e, pl, depth + 1);
                if (cs == CONT) return CONT;
                env_restore(e, save);
                return eval_with_cont(else_g, cont, e, pl, depth + 1);
            }
            /* Regular disjunction */
            int save = env_save(e);
            status s = eval_with_cont(goal->args[0], cont, e, pl, depth + 1);
            if (s != FAIL) return s;
            env_restore(e, save);
            return eval_with_cont(goal->args[1], cont, e, pl, depth + 1);
        }

        /* --- If-then without else (Cond -> Then) --- */
        if (arity == 2 && strcmp(f, "->") == 0) {
            status cs = eval_with_cont(goal->args[0], NULL, e, pl, depth + 1);
            if (cs == DONE) return eval_with_cont(goal->args[1], cont, e, pl, depth + 1);
            if (cs == CONT) return CONT;
            return FAIL;
        }

        /* --- Negation / Inverter (\+) --- */
        if (arity == 1 && strcmp(f, "\\+") == 0) {
            int save = env_save(e);
            status s = eval_with_cont(goal->args[0], NULL, e, pl, depth + 1);
            env_restore(e, save);
            if (s == DONE) return FAIL;
            if (s == FAIL) return eval_cont(cont, e, pl, depth);
            return CONT;
        }

        /* --- Active logic: inv/1 --- */
        if (arity == 1 && strcmp(f, "inv") == 0) {
            int save = env_save(e);
            status s = eval_with_cont(goal->args[0], NULL, e, pl, depth + 1);
            env_restore(e, save);
            if (s == DONE) return FAIL;
            if (s == FAIL) return eval_cont(cont, e, pl, depth);
            return CONT;
        }

        /* --- Active logic: condone/1 --- fail -> done */
        if (arity == 1 && strcmp(f, "condone") == 0) {
            status s = eval_with_cont(goal->args[0], NULL, e, pl, depth + 1);
            if (s == FAIL) return eval_cont(cont, e, pl, depth);
            if (s == CONT) return CONT;
            return eval_cont(cont, e, pl, depth);
        }

        /* --- Active logic: promote/1 --- fail->cont, cont->done, done->done */
        if (arity == 1 && strcmp(f, "promote") == 0) {
            status s = eval_with_cont(goal->args[0], NULL, e, pl, depth + 1);
            if (s == FAIL) return CONT;
            return eval_cont(cont, e, pl, depth);
        }

        /* --- Active logic: demote/1 --- done->cont, cont->fail, fail->fail */
        if (arity == 1 && strcmp(f, "demote") == 0) {
            status s = eval_with_cont(goal->args[0], NULL, e, pl, depth + 1);
            if (s == DONE) return CONT;
            return FAIL;
        }

        /* --- Active logic: par_any/2 --- lenient parallel (max) */
        if (arity == 2 && strcmp(f, "par_any") == 0) {
            status sl = eval_with_cont(goal->args[0], NULL, e, pl, depth + 1);
            status sr = eval_with_cont(goal->args[1], NULL, e, pl, depth + 1);
            status result = (sl > sr) ? sl : sr;
            if (result == DONE) return eval_cont(cont, e, pl, depth);
            return result;
        }

        /* --- Active logic: par_all/2 --- strict parallel (min) */
        if (arity == 2 && strcmp(f, "par_all") == 0) {
            status sl = eval_with_cont(goal->args[0], NULL, e, pl, depth + 1);
            status sr = eval_with_cont(goal->args[1], NULL, e, pl, depth + 1);
            status result = (sl < sr) ? sl : sr;
            if (result == DONE) return eval_cont(cont, e, pl, depth);
            return result;
        }

        /* --- call/1 --- */
        if (arity == 1 && strcmp(f, "call") == 0) {
            return eval_with_cont(goal->args[0], cont, e, pl, depth + 1);
        }

        /* --- write/1 --- */
        if (arity == 1 && strcmp(f, "write") == 0) {
            print_term(goal->args[0], e);
            return eval_cont(cont, e, pl, depth);
        }

        /* --- writeln/1 --- */
        if (arity == 1 && strcmp(f, "writeln") == 0) {
            print_term(goal->args[0], e);
            printf("\n");
            return eval_cont(cont, e, pl, depth);
        }

        /* --- is/2 --- arithmetic evaluation */
        if (arity == 2 && strcmp(f, "is") == 0) {
            int val = eval_arith(goal->args[1], e);
            term *result = make_int(val);
            if (!unify(goal->args[0], result, e)) return FAIL;
            return eval_cont(cont, e, pl, depth);
        }

        /* --- Comparison operators --- */
        if (arity == 2 && strcmp(f, "<") == 0) {
            if (!(eval_arith(goal->args[0], e) < eval_arith(goal->args[1], e))) return FAIL;
            return eval_cont(cont, e, pl, depth);
        }
        if (arity == 2 && strcmp(f, ">") == 0) {
            if (!(eval_arith(goal->args[0], e) > eval_arith(goal->args[1], e))) return FAIL;
            return eval_cont(cont, e, pl, depth);
        }
        if (arity == 2 && strcmp(f, ">=") == 0) {
            if (!(eval_arith(goal->args[0], e) >= eval_arith(goal->args[1], e))) return FAIL;
            return eval_cont(cont, e, pl, depth);
        }
        if (arity == 2 && strcmp(f, "=<") == 0) {
            if (!(eval_arith(goal->args[0], e) <= eval_arith(goal->args[1], e))) return FAIL;
            return eval_cont(cont, e, pl, depth);
        }
        if (arity == 2 && strcmp(f, "=:=") == 0) {
            if (!(eval_arith(goal->args[0], e) == eval_arith(goal->args[1], e))) return FAIL;
            return eval_cont(cont, e, pl, depth);
        }
        if (arity == 2 && strcmp(f, "=\\=") == 0) {
            if (!(eval_arith(goal->args[0], e) != eval_arith(goal->args[1], e))) return FAIL;
            return eval_cont(cont, e, pl, depth);
        }

        /* --- Unification (=) --- */
        if (arity == 2 && strcmp(f, "=") == 0) {
            if (!unify(goal->args[0], goal->args[1], e)) return FAIL;
            return eval_cont(cont, e, pl, depth);
        }

        /* --- Not unifiable (\=) --- */
        if (arity == 2 && strcmp(f, "\\=") == 0) {
            int save = env_save(e);
            bool ok = unify(goal->args[0], goal->args[1], e);
            env_restore(e, save);
            if (ok) return FAIL;
            return eval_cont(cont, e, pl, depth);
        }

        /* --- assert/1 --- add fact/rule to database */
        if (arity == 1 && strcmp(f, "assert") == 0) {
            term *arg = resolve(goal->args[0], e);
            clause *c = calloc(1, sizeof(clause));
            if (arg->type == TERM_COMPOUND && strcmp(arg->name, ":-") == 0 && arg->arity == 2) {
                c->head = arg->args[0];
                c->body = arg->args[1];
            } else {
                c->head = arg;
                c->body = NULL;
            }
            db_add_clause(&pl->db, c);
            return eval_cont(cont, e, pl, depth);
        }

        /* --- retract/1 --- remove first matching clause */
        if (arity == 1 && strcmp(f, "retract") == 0) {
            if (!db_retract(&pl->db, deref(goal->args[0], e), e)) return FAIL;
            return eval_cont(cont, e, pl, depth);
        }

        /* --- tick/1 --- unify with current tick number */
        if (arity == 1 && strcmp(f, "tick") == 0) {
            if (!unify(goal->args[0], make_int(pl->tick), e)) return FAIL;
            return eval_cont(cont, e, pl, depth);
        }

        /* --- consult/1 --- load a file */
        if (arity == 1 && strcmp(f, "consult") == 0) {
            term *arg = deref(goal->args[0], e);
            if (arg->type != TERM_ATOM) return FAIL;

            FILE *fp = fopen(arg->name, "r");
            if (!fp) {
                fprintf(stderr, "cannot open '%s'\n", arg->name);
                return FAIL;
            }

            fseek(fp, 0, SEEK_END);
            long len = ftell(fp);
            fseek(fp, 0, SEEK_SET);
            char *buf = malloc(len + 1);
            size_t n = fread(buf, 1, len, fp);
            (void)n;
            buf[len] = 0;
            fclose(fp);

            parser p;
            parser_init(&p, buf, pl->next_var_id);

            while (p.cur.type != TOK_EOF) {
                term *query;
                if (parse_directive(&p, &query)) {
                    env qe;
                    env_init(&qe);
                    eval_goal(query, &qe, pl, 0);
                    env_free(&qe);
                    continue;
                }

                clause *c = parse_clause(&p);
                if (!c) break;

                if (strcmp(c->head->name, "directive") == 0 && c->body) {
                    env qe;
                    env_init(&qe);
                    eval_goal(c->body, &qe, pl, 0);
                    env_free(&qe);
                } else {
                    db_add_clause(&pl->db, c);
                }
            }

            pl->next_var_id = parser_end_var_id(&p);
            free(buf);
            return eval_cont(cont, e, pl, depth);
        }
    }

    /* === User-defined predicates === */
    /* Try each matching clause. If clause body + continuation fails,
     * backtrack and try the next clause. Don't backtrack on cont. */
    for (clause *c = pl->db.first; c; c = c->next) {
        if (!head_matches(goal, c->head)) continue;

        int save = env_save(e);

        int offset = pl->eval_var_id;
        pl->eval_var_id += CLAUSE_VAR_STRIDE;

        term *head_copy = copy_term(c->head, offset);
        term *body_copy = c->body ? copy_term(c->body, offset) : NULL;

        if (unify(goal, head_copy, e)) {
            /* Merge clause body with continuation */
            term *full = merge_cont(body_copy, cont);
            if (!full) return DONE; /* fact with no continuation */

            status s = eval_with_cont(full, NULL, e, pl, depth + 1);
            if (s != FAIL) return s; /* don't backtrack on done or cont */
        }

        env_restore(e, save);
    }

    /* No clause matched */
    if (goal->type == TERM_ATOM) {
        if (pl->trace)
            fprintf(stderr, "unknown predicate: %s/0\n", goal->name);
    } else if (goal->type == TERM_COMPOUND) {
        if (pl->trace)
            fprintf(stderr, "unknown predicate: %s/%d\n", goal->name, goal->arity);
    }
    return FAIL;
}

/* === Public entry point (no continuation) === */
status eval_goal(term *goal, env *e, proact *pl, int depth) {
    return eval_with_cont(goal, NULL, e, pl, depth);
}
