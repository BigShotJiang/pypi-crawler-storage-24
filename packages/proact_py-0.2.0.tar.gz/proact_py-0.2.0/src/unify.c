/*
 * unify.c - Unification with trailing for backtracking
 *
 * Standard Robinson unification, unchanged from Prolog.
 * Active logic's three-valued status applies to goal evaluation,
 * not to unification itself.
 */

#include "proact.h"

void env_init(env *e) {
    e->bindings = calloc(MAX_VARS, sizeof(term *));
    e->trail = calloc(MAX_VARS, sizeof(int));
    e->trail_top = 0;
}

void env_free(env *e) {
    free(e->bindings);
    free(e->trail);
}

int env_save(env *e) {
    return e->trail_top;
}

void env_restore(env *e, int save_point) {
    while (e->trail_top > save_point) {
        e->trail_top--;
        int id = e->trail[e->trail_top];
        e->bindings[id] = NULL;
    }
}

static void bind(int var_id, term *val, env *e) {
    if (var_id < 0 || var_id >= MAX_VARS) return;
    e->bindings[var_id] = val;
    e->trail[e->trail_top++] = var_id;
}

/* Follow variable bindings to find the actual value */
term *deref(term *t, env *e) {
    while (t && t->type == TERM_VAR && t->ival >= 0 && t->ival < MAX_VARS && e->bindings[t->ival]) {
        t = e->bindings[t->ival];
    }
    return t;
}

/* Deep resolve: substitute all variable bindings recursively */
term *resolve(term *t, env *e) {
    if (!t) return NULL;
    t = deref(t, e);
    switch (t->type) {
    case TERM_ATOM:
    case TERM_INT:
    case TERM_VAR:
        return t;
    case TERM_COMPOUND: {
        term **args = malloc(t->arity * sizeof(term *));
        for (int i = 0; i < t->arity; i++)
            args[i] = resolve(t->args[i], e);
        term *c = make_compound(t->name, t->arity, args);
        free(args);
        return c;
    }
    }
    return t;
}

bool unify(term *a, term *b, env *e) {
    a = deref(a, e);
    b = deref(b, e);

    if (!a || !b) return false;

    /* Variable binds to anything */
    if (a->type == TERM_VAR) {
        if (b->type == TERM_VAR && a->ival == b->ival) return true;
        bind(a->ival, b, e);
        return true;
    }
    if (b->type == TERM_VAR) {
        bind(b->ival, a, e);
        return true;
    }

    /* Atoms */
    if (a->type == TERM_ATOM && b->type == TERM_ATOM)
        return strcmp(a->name, b->name) == 0;

    /* Integers */
    if (a->type == TERM_INT && b->type == TERM_INT)
        return a->ival == b->ival;

    /* Compound terms: functor and arity must match, then unify args */
    if (a->type == TERM_COMPOUND && b->type == TERM_COMPOUND) {
        if (a->arity != b->arity) return false;
        if (strcmp(a->name, b->name) != 0) return false;
        for (int i = 0; i < a->arity; i++) {
            if (!unify(a->args[i], b->args[i], e))
                return false;
        }
        return true;
    }

    return false;
}
