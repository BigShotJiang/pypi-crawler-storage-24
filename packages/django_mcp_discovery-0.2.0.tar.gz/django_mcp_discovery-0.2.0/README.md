# django-mcp-discovery

Exposes `/.well-known/mcp-server` on your Django project so AI agents can discover your MCP server via `mcp://`.

Implements [draft-serra-mcp-discovery-uri](https://datatracker.ietf.org/doc/draft-serra-mcp-discovery-uri/).

## Installation

```bash
pip install django-mcp-discovery
```

## Setup

**1. Add to INSTALLED_APPS:**

```python
# settings.py
INSTALLED_APPS = [
    ...
    'mcp_discovery',
]
```

**2. Include URLs:**

```python
# urls.py
from django.urls import path, include

urlpatterns = [
    ...
    path('', include('mcp_discovery.urls')),
]
```

**3. Done.** Visit `https://yoursite.com/.well-known/mcp-server` to verify.

## Configuration (optional)

```python
# settings.py
MCP_DISCOVERY = {
    'NAME': 'My Site MCP Server',
    'ENDPOINT': 'https://mysite.com/mcp/',
    'DESCRIPTION': 'My site MCP endpoint',
    'AUTH': 'none',              # none | apikey | oauth2
    'CAPABILITIES': ['tools', 'resources'],
    'CATEGORIES': ['e-commerce', 'fashion'],
    'LANGUAGES': ['it', 'en'],
    'CONTACT': 'api@mysite.com',
    'DOCS': 'https://mysite.com/mcp/docs/',
    'CRAWL': True,               # False to opt out of indexing
}
```

Without any configuration the plugin auto-detects:
- **Name** — from `django.contrib.sites` or `SITE_NAME` setting
- **Endpoint** — from `SITE_URL` or first non-localhost `ALLOWED_HOSTS`
- **Language** — from `LANGUAGE_CODE` setting

## Example output

```json
{
  "mcp_version": "2025-06-18",
  "name": "My Shop MCP Server",
  "endpoint": "https://myshop.com/mcp/",
  "transport": "http",
  "auth": { "type": "none" },
  "capabilities": ["tools", "resources"],
  "languages": ["it"],
  "crawl": true
}
```

## Links

- [mcpstandard.dev](https://mcpstandard.dev) — specification
- [IETF Draft](https://datatracker.ietf.org/doc/draft-serra-mcp-discovery-uri/)
- [GitHub Discussion #2462](https://github.com/modelcontextprotocol/modelcontextprotocol/discussions/2462)
- [WordPress plugin](https://github.com/99rig/mcp-wordpress)
