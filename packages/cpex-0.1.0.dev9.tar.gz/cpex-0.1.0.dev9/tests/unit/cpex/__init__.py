# -*- coding: utf-8 -*-
"""Location: ./tests/unit/cpex/__init__.py
Copyright 2026
SPDX-License-Identifier: Apache-2.0
Authors: Fred Araujo

Tests Package.
"""
