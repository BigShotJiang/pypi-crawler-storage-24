# {{cookiecutter.plugin_name}} for ContextForge

{{cookiecutter.description}}.


## Installation

1. Copy .env.example .env
2. Enable plugins in `.env`
3. Add the plugin configuration to `plugins/config.yaml`:
