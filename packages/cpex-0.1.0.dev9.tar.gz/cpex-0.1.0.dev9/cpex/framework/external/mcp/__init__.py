# -*- coding: utf-8 -*-
"""Location: ./cpex/framework/external/mcp/__init__.py
Copyright 2025
SPDX-License-Identifier: Apache-2.0
Authors: Fred Araujo

External plugins package.
Exposes external plugin components:
- server
- external plugin client
"""
