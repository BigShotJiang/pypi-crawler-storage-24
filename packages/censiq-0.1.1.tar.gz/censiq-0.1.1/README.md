# Censiq

Estimate the median home value within a radius of a given US address using Census data.

## Install
```bash
pip install censiq
```

## CLI
```bash
censiq "1600 Pennsylvania Ave NW, Washington, DC" --radius 50
```

## Python
```python
from censiq import estimate_median_home_value

result = estimate_median_home_value("1600 Pennsylvania Ave NW, Washington, DC")
print(result)
```

## License

MIT
