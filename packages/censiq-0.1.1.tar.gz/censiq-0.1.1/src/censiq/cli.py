import argparse
import json

from .api import estimate_median_home_value


def main() -> None:
    parser = argparse.ArgumentParser(
        description="Estimate median home value within a radius"
    )
    parser.add_argument("address", help="Street address to geocode")
    parser.add_argument("--radius", type=float, default=50.0, help="Radius in miles")
    parser.add_argument("--year", type=int, default=2024, help="ACS year")
    parser.add_argument("--json", action="store_true", help="Output JSON")

    args = parser.parse_args()

    result = estimate_median_home_value(
        args.address,
        radius_miles=args.radius,
        year=args.year,
    )

    if args.json:
        print(json.dumps(result.to_dict(), indent=2))
    else:
        print(f"Address: {result.address}")
        print(f"Radius (miles): {result.radius_miles}")
        print(f"Estimated Median Home Value: ${result.estimated_median_home_value:,}")
        print(f"Tracts Used: {result.tracts_used}")


if __name__ == "__main__":
    main()