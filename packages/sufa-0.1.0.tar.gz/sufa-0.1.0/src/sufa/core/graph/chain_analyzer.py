"""AI-driven vulnerability chain discovery -- connects findings into attack paths."""

from __future__ import annotations

import json

from sufa.core.ai.router import AIRouter
from sufa.core.graph.attack_graph import AttackChain, AttackGraph
from sufa.core.models import Finding
from sufa.core.utils.logging import get_logger

logger = get_logger(__name__)

CHAIN_PROMPT = """You are a security expert analyzing \
vulnerability findings to discover attack chains.

An attack chain connects multiple individual vulnerabilities \
into a realistic multi-step attack path.
Each chain should represent a complete attack scenario a real attacker could exploit.

Application Graph Nodes (endpoints):
{nodes}

Findings:
{findings}

Analyze these findings and identify attack chains where vulnerabilities can be combined.

Output ONLY a JSON array of attack chains. Each chain:
{{
  "title": "descriptive attack path name",
  "description": "detailed explanation of the attack chain",
  "severity": "critical|high|medium|low",
  "steps": [
    {{"step": 1, "description": "what the attacker does", \
"finding_id": "related finding ID or empty"}},
    ...
  ],
  "finding_ids": ["list of finding IDs involved"],
  "impact": "business impact description"
}}

If no meaningful chains can be formed, return an empty array: []
"""


class ChainAnalyzer:
    """Uses AI to discover multi-step attack chains from individual findings."""

    def __init__(self, router: AIRouter) -> None:
        self._router = router

    async def analyze(self, graph: AttackGraph, findings: list[Finding]) -> list[AttackChain]:
        """Analyze findings and graph to discover attack chains."""
        if len(findings) < 2:
            return []

        vuln_nodes = graph.get_nodes_with_findings()
        if not vuln_nodes:
            return []

        nodes_text = self._format_nodes(vuln_nodes)
        findings_text = self._format_findings(findings)

        prompt = CHAIN_PROMPT.format(nodes=nodes_text, findings=findings_text)
        response = await self._router.analyze(prompt)

        if not response.success:
            logger.error("chain_analysis_failed", error=response.error[:200])
            return []

        return self._parse_chains(response.text)

    def _format_nodes(self, nodes) -> str:
        lines = []
        for n in nodes:
            auth_str = " [AUTH]" if n.has_auth else ""
            params_str = " [PARAMS]" if n.has_params else ""
            findings_str = f" (findings: {len(n.finding_ids)})" if n.finding_ids else ""
            lines.append(f"- {n.method} {n.endpoint}{auth_str}{params_str}{findings_str}")
        return "\n".join(lines)

    def _format_findings(self, findings: list[Finding]) -> str:
        lines = []
        for f in findings:
            lines.append(
                f"- [{f.id[:8]}] {f.severity.value.upper()} | {f.title} | "
                f"URL: {f.url} | Param: {f.parameter} | CWE: {f.cwe_id}"
            )
        return "\n".join(lines)

    def _parse_chains(self, text: str) -> list[AttackChain]:
        import re

        text = text.strip()
        text = re.sub(r"```(?:json)?\s*", "", text)
        text = text.rstrip("`")

        start = text.find("[")
        end = text.rfind("]")
        if start >= 0 and end > start:
            text = text[start : end + 1]

        try:
            data = json.loads(text)
        except json.JSONDecodeError:
            return []

        if not isinstance(data, list):
            data = [data]

        chains = []
        for item in data:
            if not isinstance(item, dict):
                continue
            chain = AttackChain(
                title=item.get("title", "Unknown Chain"),
                description=item.get("description", ""),
                severity=item.get("severity", "medium"),
                steps=item.get("steps", []),
                finding_ids=item.get("finding_ids", []),
                impact=item.get("impact", ""),
            )
            if chain.steps:
                chains.append(chain)

        logger.info("chains_discovered", count=len(chains))
        return chains
