"""Attack graph builder -- constructs a graph from stored traffic and findings."""

from __future__ import annotations

from urllib.parse import urlparse

from sufa.core.dedup.fingerprint import normalize_path
from sufa.core.graph.attack_graph import AttackGraph, GraphEdge, GraphNode
from sufa.core.models import Finding, TrafficEntry
from sufa.core.utils.logging import get_logger

logger = get_logger(__name__)


class GraphBuilder:
    """Builds an attack graph from traffic entries and findings."""

    def __init__(self) -> None:
        self._graph = AttackGraph()

    def build(self, traffic: list[TrafficEntry], findings: list[Finding]) -> AttackGraph:
        """Build a graph from traffic and findings."""
        for entry in traffic:
            self._add_traffic_node(entry)

        self._infer_edges(traffic)
        self._attach_findings(findings)
        return self._graph

    def _add_traffic_node(self, entry: TrafficEntry) -> GraphNode:
        parsed = urlparse(entry.request.url)
        norm_path = normalize_path(parsed.path)
        method = entry.request.method.value
        host = parsed.netloc

        existing = self._graph.get_node_by_endpoint(method, host, norm_path)
        if existing:
            return existing

        has_auth = any(k.lower() in ("authorization", "cookie") for k in entry.request.headers)

        node = GraphNode(
            endpoint=norm_path,
            method=method,
            host=host,
            has_auth=has_auth,
            has_params=bool(entry.request.parameters),
        )
        self._graph.add_node(node)
        return node

    def _infer_edges(self, traffic: list[TrafficEntry]) -> None:
        """Infer flow edges from sequential traffic (session-based navigation)."""
        sorted_traffic = sorted(traffic, key=lambda e: e.timestamp)
        prev_node: GraphNode | None = None

        for entry in sorted_traffic:
            parsed = urlparse(entry.request.url)
            norm_path = normalize_path(parsed.path)
            node = self._graph.get_node_by_endpoint(
                entry.request.method.value, parsed.netloc, norm_path
            )
            if node and prev_node and node.id != prev_node.id:
                referer = entry.request.headers.get("referer", "")
                edge_type = "navigation" if referer else "flow"
                self._graph.add_edge(
                    GraphEdge(
                        source_id=prev_node.id,
                        target_id=node.id,
                        edge_type=edge_type,
                    )
                )
            prev_node = node

    def _attach_findings(self, findings: list[Finding]) -> None:
        """Attach findings to their corresponding graph nodes."""
        for finding in findings:
            parsed = urlparse(finding.url)
            norm_path = normalize_path(parsed.path)
            for method in ("GET", "POST", "PUT", "PATCH", "DELETE"):
                node = self._graph.get_node_by_endpoint(method, parsed.netloc, norm_path)
                if node:
                    if finding.id not in node.finding_ids:
                        node.finding_ids.append(finding.id)
                    break

    @property
    def graph(self) -> AttackGraph:
        return self._graph
