"""Attack graph data structures for modeling application flows and attack paths."""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import UTC, datetime
from uuid import uuid4


@dataclass
class GraphNode:
    id: str = field(default_factory=lambda: uuid4().hex[:12])
    endpoint: str = ""
    method: str = "GET"
    host: str = ""
    has_auth: bool = False
    has_params: bool = False
    finding_ids: list[str] = field(default_factory=list)
    metadata: dict = field(default_factory=dict)

    @property
    def label(self) -> str:
        return f"{self.method} {self.endpoint}"


@dataclass
class GraphEdge:
    source_id: str
    target_id: str
    edge_type: str = "flow"
    evidence: str = ""

    @property
    def label(self) -> str:
        return self.edge_type


@dataclass
class AttackChain:
    id: str = field(default_factory=lambda: uuid4().hex)
    title: str = ""
    description: str = ""
    severity: str = "info"
    steps: list[dict] = field(default_factory=list)
    finding_ids: list[str] = field(default_factory=list)
    impact: str = ""
    created_at: datetime = field(default_factory=lambda: datetime.now(UTC))


class AttackGraph:
    """Graph representation of application endpoints and their relationships."""

    def __init__(self) -> None:
        self._nodes: dict[str, GraphNode] = {}
        self._edges: list[GraphEdge] = []
        self._endpoint_to_node: dict[str, str] = {}

    def add_node(self, node: GraphNode) -> None:
        self._nodes[node.id] = node
        key = f"{node.method}|{node.host}|{node.endpoint}"
        self._endpoint_to_node[key] = node.id

    def add_edge(self, edge: GraphEdge) -> None:
        self._edges.append(edge)

    def get_node(self, node_id: str) -> GraphNode | None:
        return self._nodes.get(node_id)

    def get_node_by_endpoint(self, method: str, host: str, endpoint: str) -> GraphNode | None:
        key = f"{method}|{host}|{endpoint}"
        node_id = self._endpoint_to_node.get(key)
        if node_id:
            return self._nodes.get(node_id)
        return None

    def get_neighbors(self, node_id: str) -> list[GraphNode]:
        neighbor_ids = {e.target_id for e in self._edges if e.source_id == node_id}
        return [self._nodes[nid] for nid in neighbor_ids if nid in self._nodes]

    def get_nodes_with_findings(self) -> list[GraphNode]:
        return [n for n in self._nodes.values() if n.finding_ids]

    def find_paths(self, start_id: str, end_id: str, max_depth: int = 10) -> list[list[str]]:
        """Find all paths between two nodes using DFS."""
        paths: list[list[str]] = []
        self._dfs(start_id, end_id, [start_id], set(), paths, max_depth)
        return paths

    def _dfs(
        self,
        current: str,
        target: str,
        path: list[str],
        visited: set[str],
        paths: list[list[str]],
        max_depth: int,
    ) -> None:
        if len(path) > max_depth:
            return
        if current == target and len(path) > 1:
            paths.append(list(path))
            return
        visited.add(current)
        for edge in self._edges:
            if edge.source_id == current and edge.target_id not in visited:
                path.append(edge.target_id)
                self._dfs(edge.target_id, target, path, visited, paths, max_depth)
                path.pop()
        visited.discard(current)

    @property
    def nodes(self) -> list[GraphNode]:
        return list(self._nodes.values())

    @property
    def edges(self) -> list[GraphEdge]:
        return list(self._edges)

    @property
    def node_count(self) -> int:
        return len(self._nodes)

    @property
    def edge_count(self) -> int:
        return len(self._edges)
