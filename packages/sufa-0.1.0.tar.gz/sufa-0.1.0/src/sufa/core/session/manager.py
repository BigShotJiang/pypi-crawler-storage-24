"""Session context tracking for authenticated scanning."""

from __future__ import annotations

import re
from dataclasses import dataclass, field
from datetime import UTC, datetime


@dataclass
class SessionContext:
    cookies: dict[str, str] = field(default_factory=dict)
    auth_headers: dict[str, str] = field(default_factory=dict)
    csrf_tokens: dict[str, str] = field(default_factory=dict)
    jwt_tokens: list[str] = field(default_factory=list)
    user_identity: str = ""
    role: str = ""
    last_updated: datetime = field(default_factory=lambda: datetime.now(UTC))


_JWT_RE = re.compile(r"eyJ[A-Za-z0-9_-]+\.eyJ[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+")
_CSRF_HEADER_NAMES = {"x-csrf-token", "x-xsrf-token", "csrf-token"}
_CSRF_PARAM_NAMES = {"_token", "csrf_token", "csrfmiddlewaretoken", "_csrf", "authenticity_token"}


class SessionManager:
    """Track session state across HTTP traffic for authenticated scanning."""

    def __init__(self) -> None:
        self._sessions: dict[str, SessionContext] = {}
        self._default = SessionContext()

    def extract_from_request(self, host: str, headers: dict[str, str], body: str = "") -> None:
        """Extract session info from an HTTP request."""
        ctx = self._get_or_create(host)

        if "cookie" in {k.lower() for k in headers}:
            cookie_val = next(v for k, v in headers.items() if k.lower() == "cookie")
            for pair in cookie_val.split(";"):
                pair = pair.strip()
                if "=" in pair:
                    k, v = pair.split("=", 1)
                    ctx.cookies[k.strip()] = v.strip()

        for k, v in headers.items():
            kl = k.lower()
            if kl == "authorization":
                ctx.auth_headers[k] = v
                jwt_match = _JWT_RE.search(v)
                if jwt_match and jwt_match.group() not in ctx.jwt_tokens:
                    ctx.jwt_tokens.append(jwt_match.group())
            elif kl in _CSRF_HEADER_NAMES:
                ctx.csrf_tokens[k] = v

        if body:
            for name in _CSRF_PARAM_NAMES:
                pattern = re.compile(rf"{re.escape(name)}=([^&\s]+)", re.IGNORECASE)
                match = pattern.search(body)
                if match:
                    ctx.csrf_tokens[name] = match.group(1)

        ctx.last_updated = datetime.now(UTC)

    def extract_from_response(self, host: str, headers: dict[str, str], body: str = "") -> None:
        """Extract session info from an HTTP response (Set-Cookie, CSRF tokens)."""
        ctx = self._get_or_create(host)

        for k, v in headers.items():
            if k.lower() == "set-cookie":
                parts = v.split(";")[0]
                if "=" in parts:
                    name, val = parts.split("=", 1)
                    ctx.cookies[name.strip()] = val.strip()

        if body:
            jwt_matches = _JWT_RE.findall(body)
            for token in jwt_matches:
                if token not in ctx.jwt_tokens:
                    ctx.jwt_tokens.append(token)

        ctx.last_updated = datetime.now(UTC)

    def get_session(self, host: str) -> SessionContext:
        return self._sessions.get(host, self._default)

    def get_auth_headers(self, host: str) -> dict[str, str]:
        """Get authentication headers for a host to use in replayed/active requests."""
        ctx = self.get_session(host)
        headers: dict[str, str] = {}

        if ctx.auth_headers:
            headers.update(ctx.auth_headers)

        if ctx.cookies:
            cookie_str = "; ".join(f"{k}={v}" for k, v in ctx.cookies.items())
            headers["Cookie"] = cookie_str

        if ctx.csrf_tokens:
            for k, v in ctx.csrf_tokens.items():
                headers[k] = v

        return headers

    def list_hosts(self) -> list[str]:
        return list(self._sessions.keys())

    def clear(self, host: str = "") -> None:
        if host:
            self._sessions.pop(host, None)
        else:
            self._sessions.clear()

    def _get_or_create(self, host: str) -> SessionContext:
        if host not in self._sessions:
            self._sessions[host] = SessionContext()
        return self._sessions[host]
