"""SARIF report generator for CI/CD integration."""

from __future__ import annotations

import json

from sufa.core.models import Finding, Scan

SARIF_SCHEMA = "https://raw.githubusercontent.com/oasis-tcs/sarif-spec/main/sarif-2.1/schema/sarif-schema-2.1.0.json"

SEVERITY_TO_SARIF = {
    "critical": "error",
    "high": "error",
    "medium": "warning",
    "low": "note",
    "info": "note",
}


def generate_sarif_report(scan: Scan, findings: list[Finding]) -> str:
    rules = []
    results = []
    rule_ids: set[str] = set()

    for f in findings:
        rule_id = f.cwe_id or f.title.lower().replace(" ", "-")[:64]

        if rule_id not in rule_ids:
            rule_ids.add(rule_id)
            rule = {
                "id": rule_id,
                "name": f.title,
                "shortDescription": {"text": f.title},
                "fullDescription": {"text": f.description or f.title},
                "helpUri": f.cwe_url or "",
                "properties": {"tags": [f.owasp_category] if f.owasp_category else []},
            }
            if f.remediation:
                rule["help"] = {"text": f.remediation}
            rules.append(rule)

        result = {
            "ruleId": rule_id,
            "level": SEVERITY_TO_SARIF.get(f.severity.value, "note"),
            "message": {"text": f.description or f.title},
            "locations": [
                {
                    "physicalLocation": {
                        "artifactLocation": {"uri": f.url},
                    },
                    "properties": {
                        "parameter": f.parameter,
                    },
                }
            ],
            "properties": {
                "confidence": f.confidence_score,
                "severity": f.severity.value,
                "status": f.status.value,
            },
        }
        if f.evidence:
            result["message"]["text"] += f"\n\nEvidence: {f.evidence}"
        results.append(result)

    sarif = {
        "$schema": SARIF_SCHEMA,
        "version": "2.1.0",
        "runs": [
            {
                "tool": {
                    "driver": {
                        "name": "sufa",
                        "version": "0.1.0",
                        "informationUri": "https://github.com/sufa/sufa",
                        "rules": rules,
                    }
                },
                "results": results,
                "invocations": [
                    {
                        "executionSuccessful": scan.status.value == "completed",
                        "properties": {
                            "target": scan.target_url,
                            "scan_id": scan.id,
                            "profile": scan.profile.value,
                        },
                    }
                ],
            }
        ],
    }
    return json.dumps(sarif, indent=2)
