"""HTML report generator using Jinja2 templates."""

from __future__ import annotations

from datetime import UTC, datetime
from pathlib import Path

from jinja2 import Environment, FileSystemLoader, select_autoescape

from sufa.core.models import Finding, Scan

TEMPLATE_DIR = Path(__file__).parent / "templates"


def generate_html_report(scan: Scan, findings: list[Finding]) -> str:
    """Generate an HTML vulnerability report."""
    env = Environment(
        loader=FileSystemLoader(str(TEMPLATE_DIR)),
        autoescape=select_autoescape(["html"]),
    )
    try:
        template = env.get_template("report.html")
    except Exception:
        return _fallback_html(scan, findings)

    return template.render(
        scan=scan,
        findings=findings,
        generated_at=datetime.now(UTC).isoformat(),
        severity_order=["critical", "high", "medium", "low", "info"],
        count_by_severity=_count_by_severity(findings),
    )


def _count_by_severity(findings: list[Finding]) -> dict[str, int]:
    counts: dict[str, int] = {}
    for f in findings:
        key = f.severity.value
        counts[key] = counts.get(key, 0) + 1
    return counts


def _fallback_html(scan: Scan, findings: list[Finding]) -> str:
    """Fallback HTML when template is not found."""
    severity_colors = {
        "critical": "#dc2626",
        "high": "#ea580c",
        "medium": "#ca8a04",
        "low": "#0891b2",
        "info": "#6b7280",
    }
    rows = ""
    for f in findings:
        color = severity_colors.get(f.severity.value, "#6b7280")
        rows += f"""<tr>
            <td><span style="color:{color};font-weight:bold">{f.severity.value.upper()}</span></td>
            <td>{f.title}</td>
            <td>{f.cwe_id}</td>
            <td style="word-break:break-all;max-width:300px">{f.url}</td>
            <td>{f.parameter}</td>
            <td>{f.confidence.value} ({f.confidence_score}%)</td>
        </tr>"""

    counts = _count_by_severity(findings)
    summary_items = " | ".join(f"{k.upper()}: {v}" for k, v in sorted(counts.items()))

    return f"""<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>sufa Report - {scan.target_url}</title>
<style>
  * {{ margin:0; padding:0; box-sizing:border-box; }}
  body {{ font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,sans-serif;
         background:#0f172a; color:#e2e8f0; padding:2rem; }}
  h1 {{ color:#38bdf8; margin-bottom:.5rem; }}
  .meta {{ color:#94a3b8; margin-bottom:2rem; }}
  .summary {{ background:#1e293b; padding:1rem 1.5rem; border-radius:.5rem;
              margin-bottom:2rem; color:#cbd5e1; }}
  table {{ width:100%; border-collapse:collapse;
    background:#1e293b; border-radius:.5rem;
    overflow:hidden; }}
  th {{ background:#334155; color:#f1f5f9; padding:.75rem 1rem; text-align:left; }}
  td {{ padding:.75rem 1rem; border-bottom:1px solid #334155; }}
  tr:hover td {{ background:#334155; }}
  .details {{ margin-top:2rem; }}
  .finding-card {{ background:#1e293b; border-radius:.5rem; padding:1.5rem; margin-bottom:1rem;
                   border-left:4px solid #475569; }}
  .finding-card h3 {{ color:#f1f5f9; margin-bottom:.5rem; }}
  .finding-card p {{ color:#94a3b8; line-height:1.6; }}
  .tag {{ display:inline-block; padding:2px 8px; border-radius:4px; font-size:.8rem;
          background:#334155; margin-right:.25rem; }}
</style>
</head>
<body>
  <h1>sufa Vulnerability Report</h1>
  <div class="meta">
    Target: {scan.target_url} | Scan: {scan.id[:8]} |
    Generated: {datetime.now(UTC).strftime("%Y-%m-%d %H:%M UTC")}
  </div>
  <div class="summary">
    <strong>Summary:</strong> {len(findings)} findings | {summary_items}
  </div>
  <table>
    <thead><tr><th>Severity</th><th>Title</th><th>CWE</th><th>URL</th><th>Parameter</th><th>Confidence</th></tr></thead>
    <tbody>{rows}</tbody>
  </table>
  <div class="details">
    <h2 style="color:#38bdf8;margin:2rem 0 1rem">Finding Details</h2>
    {"".join(_finding_card(f, severity_colors) for f in findings)}
  </div>
</body>
</html>"""


def _finding_card(f: Finding, colors: dict) -> str:
    color = colors.get(f.severity.value, "#6b7280")
    cwe_html = ""
    if f.cwe_id:
        cwe_html = (
            '<p><strong>CWE:</strong> <a href="'
            + f.cwe_url
            + '" style="color:#38bdf8">'
            + f.cwe_id
            + "</a></p>"
        )
    return f"""<div class="finding-card" style="border-left-color:{color}">
  <h3>{f.title} <span class="tag" style="color:{color}">{f.severity.value.upper()}</span></h3>
  <p><strong>URL:</strong> {f.url}</p>
  {"<p><strong>Parameter:</strong> " + f.parameter + "</p>" if f.parameter else ""}
  {cwe_html}
  {"<p><strong>Description:</strong> " + f.description + "</p>" if f.description else ""}
  {"<p><strong>Evidence:</strong> <code>" + f.evidence + "</code></p>" if f.evidence else ""}
  {"<p><strong>Remediation:</strong> " + f.remediation + "</p>" if f.remediation else ""}
</div>"""
