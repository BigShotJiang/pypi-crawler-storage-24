"""JSON report generator."""

from __future__ import annotations

import json
from datetime import UTC, datetime

from sufa.core.models import Finding, Scan


def generate_json_report(scan: Scan, findings: list[Finding]) -> str:
    report = {
        "tool": "sufa",
        "version": "0.1.0",
        "generated_at": datetime.now(UTC).isoformat(),
        "scan": {
            "id": scan.id,
            "target_url": scan.target_url,
            "scan_type": scan.scan_type.value,
            "profile": scan.profile.value,
            "status": scan.status.value,
            "stats": scan.stats.model_dump(),
            "started_at": scan.started_at.isoformat() if scan.started_at else None,
            "finished_at": scan.finished_at.isoformat() if scan.finished_at else None,
            "duration_seconds": scan.duration_seconds,
        },
        "summary": {
            "total_findings": len(findings),
            "by_severity": _count_by(findings, "severity"),
            "by_status": _count_by(findings, "status"),
        },
        "findings": [
            {
                "id": f.id,
                "title": f.title,
                "description": f.description,
                "severity": f.severity.value,
                "confidence": f.confidence.value,
                "confidence_score": f.confidence_score,
                "cwe_id": f.cwe_id,
                "cwe_url": f.cwe_url,
                "owasp_category": f.owasp_category,
                "url": f.url,
                "parameter": f.parameter,
                "evidence": f.evidence,
                "remediation": f.remediation,
                "status": f.status.value,
                "created_at": f.created_at.isoformat(),
            }
            for f in findings
        ],
    }
    return json.dumps(report, indent=2)


def _count_by(findings: list[Finding], attr: str) -> dict[str, int]:
    counts: dict[str, int] = {}
    for f in findings:
        val = getattr(f, attr)
        key = val.value if hasattr(val, "value") else str(val)
        counts[key] = counts.get(key, 0) + 1
    return counts
