"""Endpoint normalization and fingerprinting for smart deduplication."""

from __future__ import annotations

import hashlib
import re
from urllib.parse import urlparse

_NUMERIC_SEGMENT = re.compile(r"^[0-9a-f]{8,}$|^\d+$", re.IGNORECASE)
_UUID_SEGMENT = re.compile(
    r"^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$", re.IGNORECASE
)


def normalize_path(path: str) -> str:
    """Normalize URL path by replacing dynamic segments with wildcards.

    /users/123/posts/456 -> /users/*/posts/*
    /api/v1/order/abc123def -> /api/v1/order/*
    """
    segments = path.strip("/").split("/")
    normalized = []
    for seg in segments:
        if not seg:
            continue
        if _UUID_SEGMENT.match(seg) or _NUMERIC_SEGMENT.match(seg):
            normalized.append("*")
        else:
            normalized.append(seg)
    return "/" + "/".join(normalized)


def endpoint_fingerprint(method: str, url: str) -> str:
    """Generate a fingerprint for an endpoint (method + normalized path + sorted param names)."""
    parsed = urlparse(url)
    norm_path = normalize_path(parsed.path)
    param_names = (
        sorted({p.split("=")[0] for p in parsed.query.split("&") if "=" in p})
        if parsed.query
        else []
    )

    raw = f"{method.upper()}|{parsed.netloc}|{norm_path}|{'|'.join(param_names)}"
    return hashlib.sha256(raw.encode()).hexdigest()


def finding_fingerprint(url: str, title: str, cwe_id: str, parameter: str) -> str:
    """Generate a dedup fingerprint for a finding."""
    parsed = urlparse(url)
    norm_path = normalize_path(parsed.path)
    raw = (
        f"{parsed.netloc}|{norm_path}|{title.lower().strip()}|{cwe_id}|{parameter.lower().strip()}"
    )
    return hashlib.sha256(raw.encode()).hexdigest()
