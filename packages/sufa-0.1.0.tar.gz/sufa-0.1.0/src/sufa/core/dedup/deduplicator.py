"""Smart deduplication engine to prevent redundant AI analysis."""

from __future__ import annotations

from sufa.core.dedup.fingerprint import endpoint_fingerprint, finding_fingerprint
from sufa.core.utils.logging import get_logger

logger = get_logger(__name__)


class Deduplicator:
    """Track analyzed endpoints and findings to avoid redundant work."""

    def __init__(self) -> None:
        self._analyzed_endpoints: set[str] = set()
        self._known_findings: set[str] = set()

    def should_analyze(self, method: str, url: str) -> bool:
        fp = endpoint_fingerprint(method, url)
        if fp in self._analyzed_endpoints:
            logger.debug("dedup_skip", method=method, url=url[:80])
            return False
        return True

    def mark_analyzed(self, method: str, url: str) -> None:
        fp = endpoint_fingerprint(method, url)
        self._analyzed_endpoints.add(fp)

    def is_duplicate_finding(self, url: str, title: str, cwe_id: str, parameter: str) -> bool:
        fp = finding_fingerprint(url, title, cwe_id, parameter)
        if fp in self._known_findings:
            return True
        return False

    def register_finding(self, url: str, title: str, cwe_id: str, parameter: str) -> str:
        """Register a finding and return its fingerprint."""
        fp = finding_fingerprint(url, title, cwe_id, parameter)
        self._known_findings.add(fp)
        return fp

    def reset(self) -> None:
        self._analyzed_endpoints.clear()
        self._known_findings.clear()

    @property
    def analyzed_count(self) -> int:
        return len(self._analyzed_endpoints)

    @property
    def findings_count(self) -> int:
        return len(self._known_findings)
