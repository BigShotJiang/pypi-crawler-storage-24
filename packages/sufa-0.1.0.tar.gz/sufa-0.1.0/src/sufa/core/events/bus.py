"""Publish/subscribe event bus for loose coupling between sufa modules."""

from __future__ import annotations

import asyncio
import logging
from collections import defaultdict
from collections.abc import Callable

from sufa.core.events.events import Event, EventType

logger = logging.getLogger(__name__)

Listener = Callable[[Event], None]
AsyncListener = Callable[[Event], object]


class EventBus:
    """Central event bus supporting both sync and async listeners."""

    def __init__(self) -> None:
        self._sync_listeners: dict[EventType, list[Listener]] = defaultdict(list)
        self._async_listeners: dict[EventType, list[AsyncListener]] = defaultdict(list)
        self._global_sync: list[Listener] = []
        self._global_async: list[AsyncListener] = []

    def subscribe(self, event_type: EventType, listener: Listener) -> None:
        self._sync_listeners[event_type].append(listener)

    def subscribe_async(self, event_type: EventType, listener: AsyncListener) -> None:
        self._async_listeners[event_type].append(listener)

    def subscribe_all(self, listener: Listener) -> None:
        """Subscribe to every event type."""
        self._global_sync.append(listener)

    def subscribe_all_async(self, listener: AsyncListener) -> None:
        self._global_async.append(listener)

    def unsubscribe(self, event_type: EventType, listener: Listener) -> None:
        try:
            self._sync_listeners[event_type].remove(listener)
        except ValueError:
            pass

    def emit(self, event: Event) -> None:
        """Emit an event synchronously to all matching listeners."""
        for listener in self._sync_listeners.get(event.event_type, []):
            try:
                listener(event)
            except Exception:
                logger.exception("Error in sync listener for %s", event.event_type.value)
        for listener in self._global_sync:
            try:
                listener(event)
            except Exception:
                logger.exception("Error in global sync listener for %s", event.event_type.value)

    async def emit_async(self, event: Event) -> None:
        """Emit an event, calling both sync and async listeners."""
        self.emit(event)
        tasks = []
        for listener in self._async_listeners.get(event.event_type, []):
            tasks.append(self._call_async(listener, event))
        for listener in self._global_async:
            tasks.append(self._call_async(listener, event))
        if tasks:
            await asyncio.gather(*tasks, return_exceptions=True)

    async def _call_async(self, listener: AsyncListener, event: Event) -> None:
        try:
            result = listener(event)
            if asyncio.iscoroutine(result):
                await result
        except Exception:
            logger.exception("Error in async listener for %s", event.event_type.value)

    def clear(self) -> None:
        self._sync_listeners.clear()
        self._async_listeners.clear()
        self._global_sync.clear()
        self._global_async.clear()
