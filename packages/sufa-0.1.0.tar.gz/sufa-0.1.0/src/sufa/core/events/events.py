"""Typed event definitions for the sufa event bus."""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import UTC, datetime
from enum import StrEnum
from typing import Any
from uuid import uuid4


class EventType(StrEnum):
    REQUEST_RECEIVED = "request_received"
    RESPONSE_RECEIVED = "response_received"
    TRAFFIC_STORED = "traffic_stored"
    SCAN_STARTED = "scan_started"
    SCAN_FINISHED = "scan_finished"
    ANALYSIS_STARTED = "analysis_started"
    ANALYSIS_COMPLETED = "analysis_completed"
    FINDING_CREATED = "finding_created"
    FINDING_UPDATED = "finding_updated"
    CHAIN_DISCOVERED = "chain_discovered"
    ERROR_OCCURRED = "error_occurred"


@dataclass
class Event:
    event_type: EventType
    data: dict[str, Any] = field(default_factory=dict)
    event_id: str = field(default_factory=lambda: uuid4().hex)
    timestamp: datetime = field(default_factory=lambda: datetime.now(UTC))
    source: str = ""

    def __repr__(self) -> str:
        return f"Event({self.event_type.value}, source={self.source!r}, id={self.event_id[:8]})"


@dataclass
class RequestReceivedEvent(Event):
    event_type: EventType = field(default=EventType.REQUEST_RECEIVED, init=False)


@dataclass
class ResponseReceivedEvent(Event):
    event_type: EventType = field(default=EventType.RESPONSE_RECEIVED, init=False)


@dataclass
class TrafficStoredEvent(Event):
    event_type: EventType = field(default=EventType.TRAFFIC_STORED, init=False)


@dataclass
class ScanStartedEvent(Event):
    event_type: EventType = field(default=EventType.SCAN_STARTED, init=False)


@dataclass
class ScanFinishedEvent(Event):
    event_type: EventType = field(default=EventType.SCAN_FINISHED, init=False)


@dataclass
class AnalysisStartedEvent(Event):
    event_type: EventType = field(default=EventType.ANALYSIS_STARTED, init=False)


@dataclass
class AnalysisCompletedEvent(Event):
    event_type: EventType = field(default=EventType.ANALYSIS_COMPLETED, init=False)


@dataclass
class FindingCreatedEvent(Event):
    event_type: EventType = field(default=EventType.FINDING_CREATED, init=False)


@dataclass
class FindingUpdatedEvent(Event):
    event_type: EventType = field(default=EventType.FINDING_UPDATED, init=False)


@dataclass
class ChainDiscoveredEvent(Event):
    event_type: EventType = field(default=EventType.CHAIN_DISCOVERED, init=False)


@dataclass
class ErrorOccurredEvent(Event):
    event_type: EventType = field(default=EventType.ERROR_OCCURRED, init=False)
