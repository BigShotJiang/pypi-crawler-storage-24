"""Google Gemini AI provider adapter."""

from __future__ import annotations

import asyncio
import time

import httpx

from sufa.core.ai.base import AIProvider, AIResponse
from sufa.core.utils.logging import get_logger

logger = get_logger(__name__)

MAX_RETRIES = 3
RETRY_BACKOFF = [5, 15, 30]


class GeminiProvider(AIProvider):
    name = "gemini"

    def __init__(
        self,
        api_url: str = "https://generativelanguage.googleapis.com/v1beta",
        api_key: str = "",
        model: str = "gemini-2.0-flash",
        max_tokens: int = 4096,
        timeout: int = 120,
    ) -> None:
        super().__init__(api_url, api_key, model, max_tokens, timeout)

    async def analyze(self, prompt: str) -> AIResponse:
        if not self.api_key:
            return AIResponse(
                provider=self.name,
                model=self.model,
                success=False,
                error="No API key configured. Run: sufa config set ai.api_key <key>",
            )

        url = f"{self.api_url}/models/{self.model}:generateContent?key={self.api_key}"
        payload = {
            "contents": [{"parts": [{"text": prompt}]}],
            "generationConfig": {
                "maxOutputTokens": self.max_tokens,
                "temperature": 0.1,
                "responseMimeType": "application/json",
            },
        }

        start = time.monotonic()
        last_error = ""

        for attempt in range(MAX_RETRIES + 1):
            try:
                async with httpx.AsyncClient(timeout=self.timeout) as client:
                    resp = await client.post(url, json=payload)

                    if resp.status_code == 429:
                        wait = RETRY_BACKOFF[attempt] if attempt < len(RETRY_BACKOFF) else 30
                        last_error = f"Rate limited (429). Retry {attempt + 1}/{MAX_RETRIES}"
                        logger.warning("gemini_rate_limit", attempt=attempt + 1, wait=wait)
                        await asyncio.sleep(wait)
                        continue

                    resp.raise_for_status()
                    data = resp.json()

                elapsed = (time.monotonic() - start) * 1000
                candidates = data.get("candidates", [])
                text = ""
                if candidates:
                    parts = candidates[0].get("content", {}).get("parts", [])
                    text = parts[0].get("text", "") if parts else ""

                usage = data.get("usageMetadata", {})
                return AIResponse(
                    text=text,
                    prompt_tokens=usage.get("promptTokenCount", 0),
                    completion_tokens=usage.get("candidatesTokenCount", 0),
                    model=self.model,
                    provider=self.name,
                    latency_ms=elapsed,
                )
            except httpx.HTTPStatusError as e:
                last_error = f"HTTP {e.response.status_code}: {e.response.text[:200]}"
                break
            except Exception as e:
                last_error = str(e)
                break

        elapsed = (time.monotonic() - start) * 1000
        logger.error("gemini_error", error=last_error[:200])
        return AIResponse(
            provider=self.name,
            model=self.model,
            success=False,
            error=last_error,
            latency_ms=elapsed,
        )

    async def test_connection(self) -> bool:
        try:
            url = f"{self.api_url}/models?key={self.api_key}"
            async with httpx.AsyncClient(timeout=10) as client:
                resp = await client.get(url)
                return resp.status_code == 200
        except Exception:
            return False
