"""Abstract base class for AI providers."""

from __future__ import annotations

from abc import ABC, abstractmethod
from dataclasses import dataclass


@dataclass
class AIResponse:
    text: str = ""
    prompt_tokens: int = 0
    completion_tokens: int = 0
    model: str = ""
    provider: str = ""
    success: bool = True
    error: str = ""
    latency_ms: float = 0.0

    @property
    def total_tokens(self) -> int:
        return self.prompt_tokens + self.completion_tokens


class AIProvider(ABC):
    """Base class all AI providers must implement."""

    name: str = "base"

    def __init__(
        self,
        api_url: str,
        api_key: str,
        model: str,
        max_tokens: int,
        timeout: int,
    ) -> None:
        self.api_url = api_url.rstrip("/")
        self.api_key = api_key
        self.model = model
        self.max_tokens = max_tokens
        self.timeout = timeout

    @abstractmethod
    async def analyze(self, prompt: str) -> AIResponse:
        """Send a prompt and return the AI response."""
        ...

    @abstractmethod
    async def test_connection(self) -> bool:
        """Test if the provider is reachable and configured correctly."""
        ...

    def __repr__(self) -> str:
        return f"{self.__class__.__name__}(model={self.model!r})"
