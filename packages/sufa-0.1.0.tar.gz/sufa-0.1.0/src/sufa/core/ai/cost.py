"""AI cost tracking and token usage monitoring."""

from __future__ import annotations

from dataclasses import dataclass, field

COST_PER_1K_TOKENS: dict[str, dict[str, float]] = {
    "openai": {"prompt": 0.005, "completion": 0.015},
    "claude": {"prompt": 0.003, "completion": 0.015},
    "gemini": {"prompt": 0.0005, "completion": 0.0015},
    "ollama": {"prompt": 0.0, "completion": 0.0},
}


@dataclass
class CostTracker:
    total_prompt_tokens: int = 0
    total_completion_tokens: int = 0
    total_calls: int = 0
    total_errors: int = 0
    provider_stats: dict[str, dict] = field(default_factory=dict)

    def record(
        self,
        provider: str,
        prompt_tokens: int,
        completion_tokens: int,
        success: bool,
    ) -> None:
        self.total_prompt_tokens += prompt_tokens
        self.total_completion_tokens += completion_tokens
        self.total_calls += 1
        if not success:
            self.total_errors += 1

        if provider not in self.provider_stats:
            self.provider_stats[provider] = {
                "prompt_tokens": 0,
                "completion_tokens": 0,
                "calls": 0,
                "errors": 0,
            }
        stats = self.provider_stats[provider]
        stats["prompt_tokens"] += prompt_tokens
        stats["completion_tokens"] += completion_tokens
        stats["calls"] += 1
        if not success:
            stats["errors"] += 1

    @property
    def estimated_cost_usd(self) -> float:
        total = 0.0
        for provider, stats in self.provider_stats.items():
            rates = COST_PER_1K_TOKENS.get(provider, {"prompt": 0, "completion": 0})
            total += (stats["prompt_tokens"] / 1000) * rates["prompt"]
            total += (stats["completion_tokens"] / 1000) * rates["completion"]
        return round(total, 4)

    def summary(self) -> dict:
        return {
            "total_calls": self.total_calls,
            "total_errors": self.total_errors,
            "total_tokens": self.total_prompt_tokens + self.total_completion_tokens,
            "estimated_cost_usd": self.estimated_cost_usd,
            "by_provider": dict(self.provider_stats),
        }
