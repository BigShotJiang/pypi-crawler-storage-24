"""OpenAI AI provider adapter."""

from __future__ import annotations

import time

import httpx

from sufa.core.ai.base import AIProvider, AIResponse
from sufa.core.utils.logging import get_logger

logger = get_logger(__name__)


class OpenAIProvider(AIProvider):
    name = "openai"

    def __init__(
        self,
        api_url: str = "https://api.openai.com/v1",
        api_key: str = "",
        model: str = "gpt-4o",
        max_tokens: int = 4096,
        timeout: int = 120,
    ) -> None:
        super().__init__(api_url, api_key, model, max_tokens, timeout)

    async def analyze(self, prompt: str) -> AIResponse:
        if not self.api_key:
            return AIResponse(
                provider=self.name,
                model=self.model,
                success=False,
                error="No API key configured. Run: sufa config set ai.api_key <key>",
            )

        url = f"{self.api_url}/chat/completions"
        headers = {
            "Authorization": f"Bearer {self.api_key}",
            "Content-Type": "application/json",
        }
        payload = {
            "model": self.model,
            "messages": [
                {"role": "system", "content": "You are a security expert. Output ONLY valid JSON."},
                {"role": "user", "content": prompt},
            ],
            "max_tokens": self.max_tokens,
            "temperature": 0.1,
            "response_format": {"type": "json_object"},
        }

        start = time.monotonic()
        try:
            async with httpx.AsyncClient(timeout=self.timeout) as client:
                resp = await client.post(url, headers=headers, json=payload)
                resp.raise_for_status()
                data = resp.json()

            elapsed = (time.monotonic() - start) * 1000
            usage = data.get("usage", {})
            text = data.get("choices", [{}])[0].get("message", {}).get("content", "")

            return AIResponse(
                text=text,
                prompt_tokens=usage.get("prompt_tokens", 0),
                completion_tokens=usage.get("completion_tokens", 0),
                model=self.model,
                provider=self.name,
                latency_ms=elapsed,
            )
        except Exception as e:
            elapsed = (time.monotonic() - start) * 1000
            logger.error("openai_error", error=str(e))
            return AIResponse(
                provider=self.name,
                model=self.model,
                success=False,
                error=str(e),
                latency_ms=elapsed,
            )

    async def test_connection(self) -> bool:
        try:
            async with httpx.AsyncClient(timeout=10) as client:
                resp = await client.get(
                    f"{self.api_url}/models",
                    headers={"Authorization": f"Bearer {self.api_key}"},
                )
                return resp.status_code == 200
        except Exception:
            return False
