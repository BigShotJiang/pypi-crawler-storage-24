"""Anthropic Claude AI provider adapter."""

from __future__ import annotations

import time

import httpx

from sufa.core.ai.base import AIProvider, AIResponse
from sufa.core.utils.logging import get_logger

logger = get_logger(__name__)


class ClaudeProvider(AIProvider):
    name = "claude"

    def __init__(
        self,
        api_url: str = "https://api.anthropic.com/v1",
        api_key: str = "",
        model: str = "claude-sonnet-4-20250514",
        max_tokens: int = 4096,
        timeout: int = 120,
    ) -> None:
        super().__init__(api_url, api_key, model, max_tokens, timeout)

    async def analyze(self, prompt: str) -> AIResponse:
        if not self.api_key:
            return AIResponse(
                provider=self.name,
                model=self.model,
                success=False,
                error="No API key configured. Run: sufa config set ai.api_key <key>",
            )

        url = f"{self.api_url}/messages"
        headers = {
            "x-api-key": self.api_key,
            "anthropic-version": "2023-06-01",
            "content-type": "application/json",
        }
        payload = {
            "model": self.model,
            "max_tokens": self.max_tokens,
            "messages": [{"role": "user", "content": prompt}],
            "system": "You are a security expert. Output ONLY valid JSON arrays.",
        }

        start = time.monotonic()
        try:
            async with httpx.AsyncClient(timeout=self.timeout) as client:
                resp = await client.post(url, headers=headers, json=payload)
                resp.raise_for_status()
                data = resp.json()

            elapsed = (time.monotonic() - start) * 1000
            usage = data.get("usage", {})
            content = data.get("content", [])
            text = content[0].get("text", "") if content else ""

            return AIResponse(
                text=text,
                prompt_tokens=usage.get("input_tokens", 0),
                completion_tokens=usage.get("output_tokens", 0),
                model=self.model,
                provider=self.name,
                latency_ms=elapsed,
            )
        except Exception as e:
            elapsed = (time.monotonic() - start) * 1000
            logger.error("claude_error", error=str(e))
            return AIResponse(
                provider=self.name,
                model=self.model,
                success=False,
                error=str(e),
                latency_ms=elapsed,
            )

    async def test_connection(self) -> bool:
        try:
            url = f"{self.api_url}/messages"
            headers = {
                "x-api-key": self.api_key,
                "anthropic-version": "2023-06-01",
                "content-type": "application/json",
            }
            payload = {
                "model": self.model,
                "max_tokens": 10,
                "messages": [{"role": "user", "content": "ping"}],
            }
            async with httpx.AsyncClient(timeout=15) as client:
                resp = await client.post(url, headers=headers, json=payload)
                return resp.status_code == 200
        except Exception:
            return False
