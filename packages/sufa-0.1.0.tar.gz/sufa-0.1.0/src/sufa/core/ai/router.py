"""AI provider router with priority-based failover."""

from __future__ import annotations

from sufa.core.ai.base import AIProvider, AIResponse
from sufa.core.ai.claude import ClaudeProvider
from sufa.core.ai.gemini import GeminiProvider
from sufa.core.ai.ollama import OllamaProvider
from sufa.core.ai.openai import OpenAIProvider
from sufa.core.utils.config import SufaConfig
from sufa.core.utils.logging import get_logger

logger = get_logger(__name__)

PROVIDER_MAP: dict[str, type[AIProvider]] = {
    "ollama": OllamaProvider,
    "openai": OpenAIProvider,
    "claude": ClaudeProvider,
    "gemini": GeminiProvider,
}

PROVIDER_DEFAULTS: dict[str, dict[str, str]] = {
    "ollama": {"api_url": "http://localhost:11434", "model": "deepseek-r1:latest"},
    "openai": {"api_url": "https://api.openai.com/v1", "model": "gpt-4o"},
    "claude": {"api_url": "https://api.anthropic.com/v1", "model": "claude-sonnet-4-20250514"},
    "gemini": {
        "api_url": "https://generativelanguage.googleapis.com/v1beta",
        "model": "gemini-2.0-flash",
    },
}


def create_provider(name: str, config: SufaConfig) -> AIProvider:
    """Create a provider instance from config.

    Uses provider-specific config keys (ai.{name}.api_url, ai.{name}.api_key, etc.)
    if available. Falls back to global config for the primary provider, or to
    provider defaults for secondary providers in the failover chain.
    """
    name = name.lower()
    cls = PROVIDER_MAP.get(name)
    if not cls:
        raise ValueError(f"Unknown AI provider: {name}")

    defaults = PROVIDER_DEFAULTS.get(name, {})
    is_primary = config.provider == name

    api_url = (
        config.get(f"ai.{name}.api_url")
        or (config.api_url if is_primary else None)
        or defaults.get("api_url", "")
    )
    api_key = config.get(f"ai.{name}.api_key") or (config.api_key if is_primary else "")
    model = (
        config.get(f"ai.{name}.model")
        or (config.model if is_primary else None)
        or defaults.get("model", "")
    )

    return cls(
        api_url=api_url,
        api_key=api_key,
        model=model,
        max_tokens=config.max_tokens,
        timeout=config.timeout,
    )


class AIRouter:
    """Routes AI requests through a priority chain with automatic failover."""

    def __init__(self, config: SufaConfig) -> None:
        self._config = config
        self._providers: list[AIProvider] = []
        self._build_chain()

    def _build_chain(self) -> None:
        chain = list(self._config.priority_chain)

        primary = self._config.provider
        if primary and primary not in chain:
            chain.insert(0, primary)

        local_providers = {"ollama"}
        seen: set[str] = set()
        for name in chain:
            if name in seen:
                continue
            seen.add(name)
            try:
                provider = create_provider(name, self._config)
                if name not in local_providers and not provider.api_key:
                    logger.debug("skip_no_key", provider=name)
                    continue
                self._providers.append(provider)
            except ValueError:
                logger.warning("unknown_provider", name=name)

        if not self._providers:
            self._providers.append(create_provider("ollama", self._config))

    async def analyze(self, prompt: str) -> AIResponse:
        """Try each provider in priority order until one succeeds."""
        last_error = ""
        for provider in self._providers:
            logger.debug("ai_attempt", provider=provider.name, model=provider.model)
            response = await provider.analyze(prompt)
            if response.success:
                return response
            last_error = response.error
            logger.warning(
                "ai_failover",
                failed_provider=provider.name,
                error=response.error[:200],
            )

        return AIResponse(
            provider="router",
            success=False,
            error=f"All providers failed. Last error: {last_error}",
        )

    async def test_connection(self) -> dict[str, bool]:
        """Test all providers in the chain."""
        results = {}
        for provider in self._providers:
            results[provider.name] = await provider.test_connection()
        return results

    @property
    def primary(self) -> AIProvider | None:
        return self._providers[0] if self._providers else None

    @property
    def provider_names(self) -> list[str]:
        return [p.name for p in self._providers]
