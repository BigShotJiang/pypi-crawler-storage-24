"""Target scope management -- filter traffic to only analyze in-scope URLs."""

from __future__ import annotations

import re
from urllib.parse import urlparse

SKIP_EXTENSIONS = frozenset(
    {
        ".js",
        ".css",
        ".png",
        ".jpg",
        ".jpeg",
        ".gif",
        ".svg",
        ".ico",
        ".woff",
        ".woff2",
        ".ttf",
        ".eot",
        ".otf",
        ".mp4",
        ".mp3",
        ".avi",
        ".mov",
        ".webm",
        ".webp",
        ".zip",
        ".gz",
        ".tar",
        ".rar",
        ".7z",
        ".pdf",
        ".doc",
        ".docx",
        ".xls",
        ".xlsx",
        ".map",
        ".min.js",
        ".min.css",
    }
)

SKIP_CONTENT_TYPES = frozenset(
    {
        "image/",
        "audio/",
        "video/",
        "font/",
        "application/octet-stream",
        "application/zip",
        "application/pdf",
        "application/javascript",
        "text/css",
    }
)


class ScopeManager:
    """Manages target scope for scanning."""

    def __init__(self, patterns: list[str] | None = None, skip_extensions: str = "") -> None:
        self._patterns: list[re.Pattern] = []
        self._custom_skip_ext: set[str] = set()

        if patterns:
            for p in patterns:
                try:
                    self._patterns.append(re.compile(p, re.IGNORECASE))
                except re.error:
                    pass

        if skip_extensions:
            self._custom_skip_ext = {
                ext.strip().lower() if ext.strip().startswith(".") else f".{ext.strip().lower()}"
                for ext in skip_extensions.split(",")
                if ext.strip()
            }

    def is_in_scope(self, url: str) -> bool:
        """Check if a URL is within the configured scope."""
        if not self._patterns:
            return True
        return any(p.search(url) for p in self._patterns)

    def should_skip(self, url: str, content_type: str = "") -> bool:
        """Check if a URL should be skipped (static assets, binary, etc.)."""
        parsed = urlparse(url)
        path = parsed.path.lower()

        all_skip = SKIP_EXTENSIONS | self._custom_skip_ext
        if any(path.endswith(ext) for ext in all_skip):
            return True

        if content_type:
            ct = content_type.lower()
            if any(ct.startswith(skip) for skip in SKIP_CONTENT_TYPES):
                return True

        return False

    def add_pattern(self, pattern: str) -> None:
        try:
            self._patterns.append(re.compile(pattern, re.IGNORECASE))
        except re.error:
            pass

    def set_target(self, target_url: str) -> None:
        """Auto-create scope pattern from a target URL."""
        parsed = urlparse(target_url)
        if parsed.netloc:
            escaped = re.escape(parsed.netloc)
            self._patterns.append(re.compile(escaped, re.IGNORECASE))
