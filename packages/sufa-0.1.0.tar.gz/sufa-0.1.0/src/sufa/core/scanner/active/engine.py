"""Active scanning engine -- payload injection and vulnerability verification."""

from __future__ import annotations

import asyncio

import httpx

from sufa.core.ai.router import AIRouter
from sufa.core.core_types import PayloadResult
from sufa.core.models import Finding, TrafficEntry
from sufa.core.scanner.active.fuzz import Fuzzer
from sufa.core.scanner.active.verifier import Verifier
from sufa.core.session.manager import SessionManager
from sufa.core.utils.logging import get_logger

logger = get_logger(__name__)


class ActiveScanner:
    """Performs active vulnerability verification using payload injection."""

    def __init__(
        self,
        router: AIRouter,
        session_manager: SessionManager | None = None,
        timeout: float = 15.0,
        verify_ssl: bool = False,
    ) -> None:
        self._router = router
        self._session = session_manager or SessionManager()
        self._fuzzer = Fuzzer()
        self._verifier = Verifier(router)
        self._timeout = timeout
        self._verify_ssl = verify_ssl

    async def verify_finding(self, finding: Finding, entry: TrafficEntry) -> Finding:
        """Attempt to actively verify a passive finding."""
        param = finding.parameter
        if not param:
            return finding

        vuln_type = self._classify_vuln(finding)
        payloads = self._fuzzer.get_payloads(vuln_type, limit=5)

        if not payloads:
            return finding

        auth_headers = self._session.get_auth_headers(entry.request.host)
        results: list[PayloadResult] = []

        for payload in payloads:
            result = await self._send_payload(entry, param, payload, auth_headers)
            results.append(result)
            await asyncio.sleep(0.5)

        verified = await self._verifier.analyze_results(finding, results)
        return verified

    async def _send_payload(
        self,
        entry: TrafficEntry,
        param: str,
        payload: str,
        auth_headers: dict[str, str],
    ) -> PayloadResult:
        """Inject a payload into the specified parameter and send the request."""
        url = entry.request.url
        method = entry.request.method.value
        headers = dict(entry.request.headers)
        headers.update(auth_headers)

        if param in url:
            modified_url = url.replace(f"{param}=", f"{param}={payload}", 1)
        else:
            separator = "&" if "?" in url else "?"
            modified_url = f"{url}{separator}{param}={payload}"

        try:
            async with httpx.AsyncClient(timeout=self._timeout, verify=self._verify_ssl) as client:
                resp = await client.request(method, modified_url, headers=headers)
                return PayloadResult(
                    payload=payload,
                    status_code=resp.status_code,
                    response_body=resp.text[:3000],
                    response_headers=dict(resp.headers),
                    success=True,
                )
        except Exception as e:
            return PayloadResult(payload=payload, success=False, error=str(e))

    @staticmethod
    def _classify_vuln(finding: Finding) -> str:
        title_lower = finding.title.lower()
        cwe = finding.cwe_id.lower()
        if "sql" in title_lower or "cwe-89" in cwe:
            return "sqli"
        if "xss" in title_lower or "cwe-79" in cwe:
            return "xss"
        if "ssrf" in title_lower or "cwe-918" in cwe:
            return "ssrf"
        if "idor" in title_lower or "cwe-639" in cwe:
            return "idor"
        if "lfi" in title_lower or "path" in title_lower or "cwe-22" in cwe:
            return "lfi"
        if "command" in title_lower or "cwe-78" in cwe:
            return "cmdi"
        return "generic"
