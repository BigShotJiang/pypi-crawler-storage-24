"""Verifier -- uses AI to confirm if payload injection was successful."""

from __future__ import annotations

import json

from sufa.core.ai.router import AIRouter
from sufa.core.core_types import PayloadResult
from sufa.core.models import Finding
from sufa.core.utils.logging import get_logger

logger = get_logger(__name__)

VERIFY_PROMPT = """You are a security expert verifying a vulnerability finding.

A passive scan found: {title} ({cwe_id}) at {url}, parameter: {parameter}

Payloads were injected and responses collected. Analyze the results to determine
if the vulnerability is confirmed.

Payload Results:
{results}

Respond with ONLY a JSON object:
{{
  "confirmed": true/false,
  "confidence": 50-100,
  "evidence": "specific evidence from the responses",
  "explanation": "why this is/isn't confirmed"
}}
"""


class Verifier:
    """Uses AI to verify if active payload testing confirms a vulnerability."""

    def __init__(self, router: AIRouter) -> None:
        self._router = router

    async def analyze_results(self, finding: Finding, results: list[PayloadResult]) -> Finding:
        """Analyze payload results to verify or dismiss a finding."""
        if not results or not any(r.success for r in results):
            return finding

        results_text = self._format_results(results)
        prompt = VERIFY_PROMPT.format(
            title=finding.title,
            cwe_id=finding.cwe_id,
            url=finding.url,
            parameter=finding.parameter,
            results=results_text,
        )

        response = await self._router.analyze(prompt)
        if not response.success:
            return finding

        try:
            data = json.loads(response.text)
            if data.get("confirmed"):
                new_score = min(int(data.get("confidence", 90)), 100)
                finding.confidence_score = max(finding.confidence_score, new_score)
                finding.confidence = Finding.confidence_from_score(finding.confidence_score)
                if data.get("evidence"):
                    finding.evidence += f"\n\nVerification: {data['evidence']}"
                finding.status = "confirmed"
                logger.info("finding_verified", title=finding.title, score=new_score)
            else:
                finding.confidence_score = max(finding.confidence_score - 20, 10)
                finding.confidence = Finding.confidence_from_score(finding.confidence_score)
        except (json.JSONDecodeError, KeyError):
            pass

        return finding

    @staticmethod
    def _format_results(results: list[PayloadResult]) -> str:
        lines = []
        for i, r in enumerate(results, 1):
            if r.success:
                body_preview = r.response_body[:500] if r.response_body else "(empty)"
                lines.append(
                    f"Payload {i}: {r.payload}\n"
                    f"  Status: {r.status_code}\n"
                    f"  Response: {body_preview}"
                )
            else:
                lines.append(f"Payload {i}: {r.payload}\n  Error: {r.error}")
        return "\n\n".join(lines)
