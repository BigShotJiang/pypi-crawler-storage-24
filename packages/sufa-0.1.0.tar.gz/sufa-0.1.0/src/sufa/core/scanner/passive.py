"""Passive scan engine -- AI-powered vulnerability analysis of HTTP traffic."""

from __future__ import annotations

import asyncio
import json
import re
from datetime import UTC, datetime

from sufa.core.ai.cost import CostTracker
from sufa.core.ai.router import AIRouter
from sufa.core.db.repository import Repository
from sufa.core.dedup import Deduplicator
from sufa.core.events import EventBus
from sufa.core.events.events import (
    AnalysisCompletedEvent,
    AnalysisStartedEvent,
    FindingCreatedEvent,
)
from sufa.core.http.normalizer import normalize_request_body, normalize_response_body
from sufa.core.http.redactor import redact_traffic_for_ai
from sufa.core.models import (
    Finding,
    Scan,
    ScanStatus,
    TrafficEntry,
)
from sufa.core.scanner.scope import ScopeManager
from sufa.core.utils.logging import get_logger

logger = get_logger(__name__)

ANALYSIS_PROMPT = """You are a security expert performing vulnerability analysis on HTTP traffic.
Analyze the following HTTP request/response for security vulnerabilities.

Focus on OWASP Top 10 categories:
- Injection (SQL, NoSQL, Command, LDAP, XPath)
- Cross-Site Scripting (XSS) -- Reflected, Stored, DOM
- Broken Authentication and Session Management
- Insecure Direct Object References (IDOR)
- Security Misconfiguration
- Sensitive Data Exposure
- Missing Function Level Access Control
- Cross-Site Request Forgery (CSRF)
- Server-Side Request Forgery (SSRF)
- XML External Entities (XXE)
- Insecure Deserialization

Output ONLY a JSON array of findings. Each finding must have:
{{
  "title": "vulnerability name",
  "description": "detailed explanation",
  "severity": "critical|high|medium|low|info",
  "confidence": 50-100,
  "cwe_id": "CWE-XXX",
  "owasp_category": "category name",
  "parameter": "affected parameter or empty string",
  "evidence": "specific evidence from the traffic",
  "remediation": "how to fix"
}}

If no vulnerabilities found, return an empty array: []

HTTP Traffic Data:
{traffic_data}
"""


def _build_traffic_data(entry: TrafficEntry) -> str:
    """Build the traffic data section for the AI prompt."""
    req = entry.request
    resp = entry.response

    req_body = normalize_request_body(req.body) if req.body else ""
    redacted_headers, redacted_body, redacted_url = redact_traffic_for_ai(
        req.headers,
        req_body,
        req.url,
    )

    data: dict = {
        "request": {
            "method": req.method.value,
            "url": redacted_url,
            "headers": redacted_headers,
            "parameters": [
                {"name": p.name, "value": p.value[:150], "type": p.param_type}
                for p in req.parameters[:10]
            ],
        }
    }
    if redacted_body:
        data["request"]["body"] = redacted_body

    if resp and resp.status_code:
        resp_body = normalize_response_body(resp.body) if resp.body else ""
        resp_headers, resp_body_redacted, _ = redact_traffic_for_ai(
            resp.headers,
            resp_body,
            "",
        )
        data["response"] = {
            "status_code": resp.status_code,
            "headers": resp_headers,
            "body": resp_body_redacted,
        }

    return json.dumps(data, indent=2)


def _parse_ai_response(text: str) -> list[dict]:
    """Parse AI response into a list of finding dicts, with repair logic."""
    text = text.strip()
    text = re.sub(r"```(?:json)?\s*", "", text)
    text = text.rstrip("`")

    start = text.find("[")
    end = text.rfind("]")

    if start >= 0 and end > start:
        text = text[start : end + 1]
    elif text.startswith("{"):
        text = f"[{text}]"

    try:
        result = json.loads(text)
        if isinstance(result, dict) and "findings" in result:
            result = result["findings"]
        if isinstance(result, dict):
            result = [result]
        if isinstance(result, list):
            return result
    except json.JSONDecodeError:
        pass

    text = re.sub(r",\s*([}\]])", r"\1", text)
    text = re.sub(r"'", '"', text)
    try:
        result = json.loads(text)
        if isinstance(result, list):
            return result
    except json.JSONDecodeError:
        pass

    objects = re.findall(r"\{[^{}]+\}", text)
    results = []
    for obj_str in objects:
        try:
            results.append(json.loads(obj_str))
        except json.JSONDecodeError:
            continue
    return results


class PassiveScanner:
    """Passive vulnerability scanner using AI analysis."""

    def __init__(
        self,
        router: AIRouter,
        repo: Repository,
        event_bus: EventBus | None = None,
        deduplicator: Deduplicator | None = None,
        scope: ScopeManager | None = None,
        cost_tracker: CostTracker | None = None,
        confidence_threshold: int = 50,
    ) -> None:
        self._router = router
        self._repo = repo
        self._bus = event_bus
        self._dedup = deduplicator or Deduplicator()
        self._scope = scope or ScopeManager()
        self._cost = cost_tracker or CostTracker()
        self._threshold = confidence_threshold

    async def analyze_traffic(self, entry: TrafficEntry, scan: Scan) -> list[Finding]:
        """Analyze a single traffic entry for vulnerabilities."""
        url = entry.request.url
        method = entry.request.method.value

        if self._scope.should_skip(url, entry.request.content_type):
            scan.stats.skipped += 1
            return []

        if not self._scope.is_in_scope(url):
            scan.stats.skipped += 1
            return []

        if not self._dedup.should_analyze(method, url):
            scan.stats.skipped += 1
            return []

        self._dedup.mark_analyzed(method, url)

        if self._bus:
            self._bus.emit(
                AnalysisStartedEvent(
                    data={"url": url, "scan_id": scan.id},
                    source="passive_scanner",
                )
            )

        traffic_data = _build_traffic_data(entry)
        prompt = ANALYSIS_PROMPT.format(traffic_data=traffic_data)

        ai_response = await self._router.analyze(prompt)
        self._cost.record(
            ai_response.provider,
            ai_response.prompt_tokens,
            ai_response.completion_tokens,
            ai_response.success,
        )
        scan.stats.ai_calls += 1
        scan.stats.ai_tokens_used += ai_response.total_tokens

        if not ai_response.success:
            scan.stats.errors += 1
            logger.error("analysis_failed", url=url[:100], error=ai_response.error[:200])
            return []

        scan.stats.analyzed += 1
        raw_findings = _parse_ai_response(ai_response.text)
        findings: list[Finding] = []

        for raw in raw_findings:
            confidence_score = int(raw.get("confidence", 0))
            if confidence_score < self._threshold:
                continue

            title = raw.get("title", "Unknown")
            cwe_id = raw.get("cwe_id", "")
            parameter = raw.get("parameter", "")

            if self._dedup.is_duplicate_finding(url, title, cwe_id, parameter):
                continue

            fp = self._dedup.register_finding(url, title, cwe_id, parameter)

            finding = Finding(
                title=title,
                description=raw.get("description", ""),
                severity=raw.get("severity", "info"),
                confidence=Finding.confidence_from_score(confidence_score),
                confidence_score=confidence_score,
                cwe_id=cwe_id,
                owasp_category=raw.get("owasp_category", ""),
                url=url,
                parameter=parameter,
                evidence=raw.get("evidence", ""),
                remediation=raw.get("remediation", ""),
                status="open",
                scan_id=scan.id,
                project_id=scan.project_id,
                traffic_ids=[entry.id],
                fingerprint=fp,
            )

            self._repo.save_finding(finding)
            findings.append(finding)
            scan.stats.findings_count += 1

            if self._bus:
                self._bus.emit(
                    FindingCreatedEvent(
                        data={
                            "finding_id": finding.id,
                            "title": title,
                            "severity": finding.severity.value,
                        },
                        source="passive_scanner",
                    )
                )

        self._repo.log_ai_call(
            provider=ai_response.provider,
            model=ai_response.model,
            scan_id=scan.id,
            traffic_id=entry.id,
            prompt_tokens=ai_response.prompt_tokens,
            completion_tokens=ai_response.completion_tokens,
            latency_ms=ai_response.latency_ms,
            success=ai_response.success,
        )

        if self._bus:
            self._bus.emit(
                AnalysisCompletedEvent(
                    data={"url": url, "findings_count": len(findings), "scan_id": scan.id},
                    source="passive_scanner",
                )
            )

        return findings

    async def run_scan(self, scan: Scan, entries: list[TrafficEntry]) -> Scan:
        """Run passive analysis on a list of traffic entries."""
        scan.status = ScanStatus.RUNNING
        scan.started_at = datetime.now(UTC)
        scan.stats.total_requests = len(entries)
        self._repo.save_scan(scan)

        request_delay = float(self._router._config.get("ai.request_delay", 2.0))

        for entry in entries:
            try:
                await self.analyze_traffic(entry, scan)
            except Exception:
                scan.stats.errors += 1
                logger.exception("analysis_error", url=entry.request.url[:100])
            await asyncio.sleep(request_delay)

        scan.status = ScanStatus.COMPLETED
        scan.finished_at = datetime.now(UTC)
        self._repo.save_scan(scan)
        return scan
