"""YAML-based analysis rule engine for customizable vulnerability detection."""

from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

import yaml

from sufa.core.utils.logging import get_logger

logger = get_logger(__name__)


@dataclass
class Rule:
    id: str
    name: str
    description: str = ""
    category: str = ""
    severity: str = "info"
    cwe_id: str = ""
    owasp_category: str = ""
    enabled: bool = True
    conditions: list[dict[str, Any]] = field(default_factory=list)
    prompt_template: str = ""
    tags: list[str] = field(default_factory=list)


class RuleEngine:
    """Load and manage YAML-based analysis rules."""

    def __init__(self) -> None:
        self._rules: dict[str, Rule] = {}
        self._load_builtin_rules()

    def _load_builtin_rules(self) -> None:
        builtin_dir = Path(__file__).parent / "builtin"
        if builtin_dir.exists():
            for rule_file in builtin_dir.glob("*.yaml"):
                self.load_file(rule_file)
            for rule_file in builtin_dir.glob("*.yml"):
                self.load_file(rule_file)

    def load_file(self, path: Path) -> int:
        """Load rules from a YAML file. Returns count of rules loaded."""
        try:
            with open(path) as f:
                data = yaml.safe_load(f)
        except Exception:
            logger.error("rule_load_error", path=str(path))
            return 0

        if not data:
            return 0

        rules_data = data if isinstance(data, list) else data.get("rules", [data])
        count = 0
        for rd in rules_data:
            if not isinstance(rd, dict):
                continue
            rule = Rule(
                id=rd.get("id", ""),
                name=rd.get("name", ""),
                description=rd.get("description", ""),
                category=rd.get("category", ""),
                severity=rd.get("severity", "info"),
                cwe_id=rd.get("cwe_id", ""),
                owasp_category=rd.get("owasp_category", ""),
                enabled=rd.get("enabled", True),
                conditions=rd.get("conditions", []),
                prompt_template=rd.get("prompt_template", ""),
                tags=rd.get("tags", []),
            )
            if rule.id:
                self._rules[rule.id] = rule
                count += 1
        return count

    def load_directory(self, path: Path) -> int:
        """Load all YAML rule files from a directory."""
        total = 0
        if path.exists():
            for f in sorted(path.iterdir()):
                if f.suffix in (".yaml", ".yml"):
                    total += self.load_file(f)
        return total

    def get_rule(self, rule_id: str) -> Rule | None:
        return self._rules.get(rule_id)

    def get_enabled_rules(self, category: str = "") -> list[Rule]:
        rules = [r for r in self._rules.values() if r.enabled]
        if category:
            rules = [r for r in rules if r.category.lower() == category.lower()]
        return rules

    def evaluate_conditions(self, rule: Rule, traffic_data: dict) -> bool:
        """Check if a rule's conditions match the traffic data."""
        if not rule.conditions:
            return True

        for cond in rule.conditions:
            field_name = cond.get("field", "")
            operator = cond.get("operator", "contains")
            value = cond.get("value", "")

            actual = self._get_field(traffic_data, field_name)
            if not self._check_condition(actual, operator, value):
                return False
        return True

    def get_prompt_context(self, rules: list[Rule]) -> str:
        """Build additional prompt context from matching rules."""
        if not rules:
            return ""
        parts = ["Focus areas based on matching rules:"]
        for rule in rules:
            if rule.prompt_template:
                parts.append(f"- {rule.name}: {rule.prompt_template}")
            else:
                parts.append(f"- {rule.name} ({rule.cwe_id}): {rule.description}")
        return "\n".join(parts)

    def _get_field(self, data: dict, field_path: str) -> str:
        parts = field_path.split(".")
        current: Any = data
        for part in parts:
            if isinstance(current, dict):
                current = current.get(part, "")
            else:
                return ""
        return str(current)

    @staticmethod
    def _check_condition(actual: str, operator: str, value: str) -> bool:
        al = actual.lower()
        vl = value.lower()
        if operator == "contains":
            return vl in al
        elif operator == "equals":
            return al == vl
        elif operator == "starts_with":
            return al.startswith(vl)
        elif operator == "not_contains":
            return vl not in al
        elif operator == "regex":
            import re

            return bool(re.search(value, actual, re.IGNORECASE))
        return False
