"""Pydantic models for vulnerability findings."""

from __future__ import annotations

from datetime import UTC, datetime
from enum import StrEnum
from uuid import uuid4

from pydantic import BaseModel, Field


class Severity(StrEnum):
    CRITICAL = "critical"
    HIGH = "high"
    MEDIUM = "medium"
    LOW = "low"
    INFO = "info"


class Confidence(StrEnum):
    CERTAIN = "certain"
    FIRM = "firm"
    TENTATIVE = "tentative"


class FindingStatus(StrEnum):
    OPEN = "open"
    CONFIRMED = "confirmed"
    FALSE_POSITIVE = "false_positive"
    ACCEPTED_RISK = "accepted_risk"
    FIXED = "fixed"


class ExploitStep(BaseModel):
    step_number: int
    description: str
    request_snippet: str = ""
    expected_response: str = ""


class Finding(BaseModel):
    id: str = Field(default_factory=lambda: uuid4().hex)
    title: str
    description: str = ""
    severity: Severity = Severity.INFO
    confidence: Confidence = Confidence.TENTATIVE
    confidence_score: int = 50
    cwe_id: str = ""
    owasp_category: str = ""
    url: str = ""
    parameter: str = ""
    evidence: str = ""
    remediation: str = ""
    exploit_steps: list[ExploitStep] = Field(default_factory=list)
    status: FindingStatus = FindingStatus.OPEN
    scan_id: str = ""
    project_id: str = ""
    traffic_ids: list[str] = Field(default_factory=list)
    fingerprint: str = ""
    created_at: datetime = Field(default_factory=lambda: datetime.now(UTC))
    updated_at: datetime = Field(default_factory=lambda: datetime.now(UTC))

    @property
    def cwe_url(self) -> str:
        if self.cwe_id:
            num = self.cwe_id.replace("CWE-", "").strip()
            return f"https://cwe.mitre.org/data/definitions/{num}.html"
        return ""

    @staticmethod
    def confidence_from_score(score: int) -> Confidence:
        if score >= 90:
            return Confidence.CERTAIN
        if score >= 75:
            return Confidence.FIRM
        return Confidence.TENTATIVE
