"""Pydantic models for HTTP requests and responses."""

from __future__ import annotations

from datetime import UTC, datetime
from enum import StrEnum
from uuid import uuid4

from pydantic import BaseModel, Field


class HttpMethod(StrEnum):
    GET = "GET"
    POST = "POST"
    PUT = "PUT"
    PATCH = "PATCH"
    DELETE = "DELETE"
    HEAD = "HEAD"
    OPTIONS = "OPTIONS"
    TRACE = "TRACE"


class HttpParameter(BaseModel):
    name: str
    value: str = ""
    param_type: str = "query"


class HttpRequest(BaseModel):
    method: HttpMethod = HttpMethod.GET
    url: str
    path: str = ""
    host: str = ""
    scheme: str = "https"
    headers: dict[str, str] = Field(default_factory=dict)
    body: str = ""
    parameters: list[HttpParameter] = Field(default_factory=list)
    content_type: str = ""


class HttpResponse(BaseModel):
    status_code: int = 0
    reason: str = ""
    headers: dict[str, str] = Field(default_factory=dict)
    body: str = ""
    content_type: str = ""
    content_length: int = 0


class TrafficEntry(BaseModel):
    id: str = Field(default_factory=lambda: uuid4().hex)
    request: HttpRequest
    response: HttpResponse | None = None
    timestamp: datetime = Field(default_factory=lambda: datetime.now(UTC))
    scan_id: str = ""
    project_id: str = ""
    source: str = ""
    tags: list[str] = Field(default_factory=list)

    @property
    def has_response(self) -> bool:
        return self.response is not None and self.response.status_code > 0
