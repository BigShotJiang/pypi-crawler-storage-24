"""Pydantic models for scans."""

from __future__ import annotations

from datetime import UTC, datetime
from enum import StrEnum
from uuid import uuid4

from pydantic import BaseModel, Field


class ScanStatus(StrEnum):
    PENDING = "pending"
    RUNNING = "running"
    PAUSED = "paused"
    COMPLETED = "completed"
    FAILED = "failed"
    CANCELLED = "cancelled"


class ScanType(StrEnum):
    PASSIVE = "passive"
    ACTIVE = "active"
    IMPORT = "import"
    FULL = "full"


class ScanProfile(StrEnum):
    QUICK = "quick"
    STANDARD = "standard"
    DEEP = "deep"


class ScanStats(BaseModel):
    total_requests: int = 0
    analyzed: int = 0
    skipped: int = 0
    findings_count: int = 0
    errors: int = 0
    ai_calls: int = 0
    ai_tokens_used: int = 0


class Scan(BaseModel):
    id: str = Field(default_factory=lambda: uuid4().hex)
    target_url: str = ""
    scan_type: ScanType = ScanType.PASSIVE
    profile: ScanProfile = ScanProfile.STANDARD
    status: ScanStatus = ScanStatus.PENDING
    project_id: str = ""
    stats: ScanStats = Field(default_factory=ScanStats)
    scope_patterns: list[str] = Field(default_factory=list)
    created_at: datetime = Field(default_factory=lambda: datetime.now(UTC))
    started_at: datetime | None = None
    finished_at: datetime | None = None

    @property
    def duration_seconds(self) -> float | None:
        if self.started_at and self.finished_at:
            return (self.finished_at - self.started_at).total_seconds()
        return None
