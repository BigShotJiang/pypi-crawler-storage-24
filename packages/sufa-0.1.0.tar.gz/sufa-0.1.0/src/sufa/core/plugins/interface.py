"""Plugin interface -- base class and hooks for sufa plugins."""

from __future__ import annotations

from abc import ABC, abstractmethod
from typing import Any

from sufa.core.events.events import Event


class SufaPlugin(ABC):
    """Base class for sufa plugins. All plugins must inherit from this."""

    name: str = "base_plugin"
    version: str = "0.1.0"
    description: str = ""
    author: str = ""

    @abstractmethod
    def on_load(self, context: dict[str, Any]) -> None:
        """Called when the plugin is loaded. Receives the sufa context."""
        ...

    def on_unload(self) -> None:
        """Called when the plugin is unloaded."""
        pass

    def on_request(self, event: Event) -> None:
        """Called when a new HTTP request is received."""
        pass

    def on_response(self, event: Event) -> None:
        """Called when an HTTP response is received."""
        pass

    def on_finding(self, event: Event) -> None:
        """Called when a new vulnerability finding is created."""
        pass

    def on_scan_start(self, event: Event) -> None:
        """Called when a scan starts."""
        pass

    def on_scan_finish(self, event: Event) -> None:
        """Called when a scan finishes."""
        pass

    def on_chain_discovered(self, event: Event) -> None:
        """Called when an attack chain is discovered."""
        pass

    def __repr__(self) -> str:
        return f"Plugin({self.name} v{self.version})"
