"""Plugin loader -- discovers and loads plugins from directories and entry points."""

from __future__ import annotations

import importlib
import importlib.util
import sys
from pathlib import Path
from typing import Any

from sufa.core.plugins.interface import SufaPlugin
from sufa.core.utils.logging import get_logger

logger = get_logger(__name__)


class PluginLoader:
    """Discovers and loads sufa plugins."""

    def __init__(self) -> None:
        self._plugins: list[SufaPlugin] = []

    def load_directory(self, directory: Path) -> int:
        """Load plugins from a directory. Each subdirectory with a plugin.py is a plugin."""
        count = 0
        if not directory.exists():
            return 0

        for plugin_dir in sorted(directory.iterdir()):
            if not plugin_dir.is_dir():
                continue
            plugin_file = plugin_dir / "plugin.py"
            if not plugin_file.exists():
                continue
            try:
                plugin = self._load_file(plugin_file, plugin_dir.name)
                if plugin:
                    self._plugins.append(plugin)
                    count += 1
                    logger.info("plugin_loaded", name=plugin.name, version=plugin.version)
            except Exception:
                logger.exception("plugin_load_error", path=str(plugin_file))
        return count

    def load_module(self, module_name: str) -> SufaPlugin | None:
        """Load a plugin from a Python module path."""
        try:
            module = importlib.import_module(module_name)
            for attr_name in dir(module):
                attr = getattr(module, attr_name)
                if (
                    isinstance(attr, type)
                    and issubclass(attr, SufaPlugin)
                    and attr is not SufaPlugin
                ):
                    plugin = attr()
                    self._plugins.append(plugin)
                    return plugin
        except Exception:
            logger.exception("plugin_module_error", module=module_name)
        return None

    def _load_file(self, path: Path, name: str) -> SufaPlugin | None:
        spec = importlib.util.spec_from_file_location(f"sufa_plugin_{name}", path)
        if not spec or not spec.loader:
            return None
        module = importlib.util.module_from_spec(spec)
        sys.modules[f"sufa_plugin_{name}"] = module
        spec.loader.exec_module(module)

        for attr_name in dir(module):
            attr = getattr(module, attr_name)
            if isinstance(attr, type) and issubclass(attr, SufaPlugin) and attr is not SufaPlugin:
                return attr()
        return None

    def initialize_all(self, context: dict[str, Any]) -> None:
        """Call on_load for all loaded plugins."""
        for plugin in self._plugins:
            try:
                plugin.on_load(context)
            except Exception:
                logger.exception("plugin_init_error", name=plugin.name)

    def unload_all(self) -> None:
        for plugin in self._plugins:
            try:
                plugin.on_unload()
            except Exception:
                pass
        self._plugins.clear()

    @property
    def plugins(self) -> list[SufaPlugin]:
        return list(self._plugins)
