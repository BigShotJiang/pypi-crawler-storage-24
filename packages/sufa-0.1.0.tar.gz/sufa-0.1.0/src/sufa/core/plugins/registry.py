"""Plugin registry -- connects plugins to the event bus."""

from __future__ import annotations

from sufa.core.events import EventBus, EventType
from sufa.core.plugins.interface import SufaPlugin
from sufa.core.plugins.loader import PluginLoader
from sufa.core.utils.logging import get_logger

logger = get_logger(__name__)

EVENT_TO_HOOK = {
    EventType.REQUEST_RECEIVED: "on_request",
    EventType.RESPONSE_RECEIVED: "on_response",
    EventType.FINDING_CREATED: "on_finding",
    EventType.SCAN_STARTED: "on_scan_start",
    EventType.SCAN_FINISHED: "on_scan_finish",
    EventType.CHAIN_DISCOVERED: "on_chain_discovered",
}


class PluginRegistry:
    """Registers plugin hooks with the event bus."""

    def __init__(self, event_bus: EventBus, loader: PluginLoader) -> None:
        self._bus = event_bus
        self._loader = loader

    def register_all(self) -> None:
        """Register all loaded plugins' hooks with the event bus."""
        for plugin in self._loader.plugins:
            self._register_plugin(plugin)

    def _register_plugin(self, plugin: SufaPlugin) -> None:
        for event_type, hook_name in EVENT_TO_HOOK.items():
            hook = getattr(plugin, hook_name, None)
            if hook and callable(hook):
                base_hook = getattr(SufaPlugin, hook_name, None)
                if hook.__func__ is not base_hook:
                    self._bus.subscribe(event_type, hook)
                    logger.debug(
                        "plugin_hook_registered",
                        plugin=plugin.name,
                        event=event_type.value,
                    )
