"""Data access layer for sufa database operations."""

from __future__ import annotations

from datetime import UTC, datetime

from sqlalchemy import select
from sqlalchemy.orm import Session

from sufa.core.db.engine import get_session
from sufa.core.db.models import (
    AICallLogRow,
    FindingRow,
    ProjectRow,
    ScanRow,
    TrafficRow,
)
from sufa.core.models import (
    Finding,
    HttpParameter,
    HttpRequest,
    HttpResponse,
    Project,
    Scan,
    ScanStats,
    TrafficEntry,
)


class Repository:
    """Unified data access for all sufa entities."""

    def __init__(self, session: Session | None = None) -> None:
        self._session = session

    @property
    def session(self) -> Session:
        if self._session is None:
            self._session = get_session()
        return self._session

    def save_project(self, project: Project) -> None:
        row = ProjectRow(
            id=project.id,
            name=project.name,
            description=project.description,
            target_urls=project.target_urls,
            tags=project.tags,
            created_at=project.created_at,
            updated_at=project.updated_at,
        )
        self.session.merge(row)
        self.session.commit()

    def get_project(self, project_id: str) -> Project | None:
        row = self.session.get(ProjectRow, project_id)
        if not row:
            return None
        return Project(
            id=row.id,
            name=row.name,
            description=row.description,
            target_urls=row.target_urls or [],
            tags=row.tags or [],
            created_at=row.created_at,
            updated_at=row.updated_at,
        )

    def list_projects(self) -> list[Project]:
        rows = (
            self.session.execute(select(ProjectRow).order_by(ProjectRow.created_at.desc()))
            .scalars()
            .all()
        )
        return [
            Project(
                id=r.id,
                name=r.name,
                description=r.description,
                target_urls=r.target_urls or [],
                tags=r.tags or [],
                created_at=r.created_at,
                updated_at=r.updated_at,
            )
            for r in rows
        ]

    def delete_project(self, project_id: str) -> bool:
        row = self.session.get(ProjectRow, project_id)
        if row:
            self.session.delete(row)
            self.session.commit()
            return True
        return False

    def save_scan(self, scan: Scan) -> None:
        row = ScanRow(
            id=scan.id,
            target_url=scan.target_url,
            scan_type=scan.scan_type.value,
            profile=scan.profile.value,
            status=scan.status.value,
            project_id=scan.project_id,
            stats=scan.stats.model_dump(),
            scope_patterns=scan.scope_patterns,
            created_at=scan.created_at,
            started_at=scan.started_at,
            finished_at=scan.finished_at,
        )
        self.session.merge(row)
        self.session.commit()

    def get_scan(self, scan_id: str) -> Scan | None:
        row = self.session.get(ScanRow, scan_id)
        if not row:
            return None
        return Scan(
            id=row.id,
            target_url=row.target_url,
            scan_type=row.scan_type,
            profile=row.profile,
            status=row.status,
            project_id=row.project_id,
            stats=ScanStats(**(row.stats or {})),
            scope_patterns=row.scope_patterns or [],
            created_at=row.created_at,
            started_at=row.started_at,
            finished_at=row.finished_at,
        )

    def list_scans(self, project_id: str = "") -> list[Scan]:
        q = select(ScanRow).order_by(ScanRow.created_at.desc())
        if project_id:
            q = q.where(ScanRow.project_id == project_id)
        rows = self.session.execute(q).scalars().all()
        return [
            Scan(
                id=r.id,
                target_url=r.target_url,
                scan_type=r.scan_type,
                profile=r.profile,
                status=r.status,
                project_id=r.project_id,
                stats=ScanStats(**(r.stats or {})),
                scope_patterns=r.scope_patterns or [],
                created_at=r.created_at,
                started_at=r.started_at,
                finished_at=r.finished_at,
            )
            for r in rows
        ]

    def save_traffic(self, entry: TrafficEntry) -> None:
        row = TrafficRow(
            id=entry.id,
            scan_id=entry.scan_id,
            project_id=entry.project_id,
            source=entry.source,
            method=entry.request.method.value,
            url=entry.request.url,
            host=entry.request.host,
            path=entry.request.path,
            request_headers=entry.request.headers,
            request_body=entry.request.body,
            request_content_type=entry.request.content_type,
            parameters=[p.model_dump() for p in entry.request.parameters],
            status_code=entry.response.status_code if entry.response else 0,
            response_headers=entry.response.headers if entry.response else {},
            response_body=entry.response.body if entry.response else "",
            response_content_type=entry.response.content_type if entry.response else "",
            response_content_length=entry.response.content_length if entry.response else 0,
            tags=entry.tags,
            timestamp=entry.timestamp,
        )
        self.session.merge(row)
        self.session.commit()

    def get_traffic(self, traffic_id: str) -> TrafficEntry | None:
        row = self.session.get(TrafficRow, traffic_id)
        if not row:
            return None
        return self._traffic_from_row(row)

    def list_traffic(
        self,
        scan_id: str = "",
        host: str = "",
        limit: int = 100,
    ) -> list[TrafficEntry]:
        q = select(TrafficRow).order_by(TrafficRow.timestamp.desc()).limit(limit)
        if scan_id:
            q = q.where(TrafficRow.scan_id == scan_id)
        if host:
            q = q.where(TrafficRow.host == host)
        rows = self.session.execute(q).scalars().all()
        return [self._traffic_from_row(r) for r in rows]

    def _traffic_from_row(self, r: TrafficRow) -> TrafficEntry:
        return TrafficEntry(
            id=r.id,
            request=HttpRequest(
                method=r.method,
                url=r.url,
                path=r.path,
                host=r.host,
                headers=r.request_headers or {},
                body=r.request_body,
                content_type=r.request_content_type,
                parameters=[HttpParameter(**p) for p in (r.parameters or [])],
            ),
            response=HttpResponse(
                status_code=r.status_code,
                headers=r.response_headers or {},
                body=r.response_body,
                content_type=r.response_content_type,
                content_length=r.response_content_length,
            )
            if r.status_code
            else None,
            timestamp=r.timestamp,
            scan_id=r.scan_id,
            project_id=r.project_id,
            source=r.source,
            tags=r.tags or [],
        )

    def save_finding(self, finding: Finding) -> None:
        row = FindingRow(
            id=finding.id,
            title=finding.title,
            description=finding.description,
            severity=finding.severity.value,
            confidence=finding.confidence.value,
            confidence_score=finding.confidence_score,
            cwe_id=finding.cwe_id,
            owasp_category=finding.owasp_category,
            url=finding.url,
            parameter=finding.parameter,
            evidence=finding.evidence,
            remediation=finding.remediation,
            exploit_steps=[s.model_dump() for s in finding.exploit_steps],
            status=finding.status.value,
            scan_id=finding.scan_id,
            project_id=finding.project_id,
            traffic_ids=finding.traffic_ids,
            fingerprint=finding.fingerprint,
            created_at=finding.created_at,
            updated_at=finding.updated_at,
        )
        self.session.merge(row)
        self.session.commit()

    def get_finding(self, finding_id: str) -> Finding | None:
        row = self.session.get(FindingRow, finding_id)
        if not row:
            return None
        return self._finding_from_row(row)

    def list_findings(
        self,
        scan_id: str = "",
        project_id: str = "",
        severity: str = "",
        status: str = "",
        limit: int = 200,
    ) -> list[Finding]:
        q = select(FindingRow).order_by(FindingRow.created_at.desc()).limit(limit)
        if scan_id:
            q = q.where(FindingRow.scan_id == scan_id)
        if project_id:
            q = q.where(FindingRow.project_id == project_id)
        if severity:
            q = q.where(FindingRow.severity == severity)
        if status:
            q = q.where(FindingRow.status == status)
        rows = self.session.execute(q).scalars().all()
        return [self._finding_from_row(r) for r in rows]

    def find_by_fingerprint(self, fingerprint: str) -> Finding | None:
        row = self.session.execute(
            select(FindingRow).where(FindingRow.fingerprint == fingerprint)
        ).scalar_one_or_none()
        if not row:
            return None
        return self._finding_from_row(row)

    def update_finding_status(self, finding_id: str, status: str) -> bool:
        row = self.session.get(FindingRow, finding_id)
        if not row:
            return False
        row.status = status
        row.updated_at = datetime.now(UTC)
        self.session.commit()
        return True

    def _finding_from_row(self, r: FindingRow) -> Finding:
        from sufa.core.models.finding import ExploitStep

        return Finding(
            id=r.id,
            title=r.title,
            description=r.description,
            severity=r.severity,
            confidence=r.confidence,
            confidence_score=r.confidence_score,
            cwe_id=r.cwe_id,
            owasp_category=r.owasp_category,
            url=r.url,
            parameter=r.parameter,
            evidence=r.evidence,
            remediation=r.remediation,
            exploit_steps=[ExploitStep(**s) for s in (r.exploit_steps or [])],
            status=r.status,
            scan_id=r.scan_id,
            project_id=r.project_id,
            traffic_ids=r.traffic_ids or [],
            fingerprint=r.fingerprint,
            created_at=r.created_at,
            updated_at=r.updated_at,
        )

    def log_ai_call(
        self,
        provider: str,
        model: str,
        scan_id: str = "",
        traffic_id: str = "",
        prompt_tokens: int = 0,
        completion_tokens: int = 0,
        latency_ms: float = 0.0,
        success: bool = True,
        error: str = "",
    ) -> None:
        row = AICallLogRow(
            provider=provider,
            model=model,
            scan_id=scan_id,
            traffic_id=traffic_id,
            prompt_tokens=prompt_tokens,
            completion_tokens=completion_tokens,
            latency_ms=latency_ms,
            success=int(success),
            error=error,
        )
        self.session.add(row)
        self.session.commit()

    def close(self) -> None:
        if self._session:
            self._session.close()
