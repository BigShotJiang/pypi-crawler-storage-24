"""Database engine setup and session management."""

from __future__ import annotations

from pathlib import Path

from sqlalchemy import create_engine
from sqlalchemy.engine import Engine
from sqlalchemy.orm import Session, sessionmaker

from sufa.core.db.models import Base

_engine: Engine | None = None
_session_factory: sessionmaker[Session] | None = None


def init_db(db_path: Path | str | None = None, db_url: str | None = None) -> Engine:
    """Initialize the database engine and create tables."""
    global _engine, _session_factory

    if db_url:
        url = db_url
    elif db_path:
        path = Path(db_path)
        path.parent.mkdir(parents=True, exist_ok=True)
        url = f"sqlite:///{path}"
    else:
        from sufa.core.utils.config import CONFIG_DIR

        CONFIG_DIR.mkdir(parents=True, exist_ok=True)
        url = f"sqlite:///{CONFIG_DIR / 'sufa.db'}"

    _engine = create_engine(url, echo=False)
    Base.metadata.create_all(_engine)
    _session_factory = sessionmaker(bind=_engine)
    return _engine


def get_session() -> Session:
    """Get a new database session."""
    global _engine, _session_factory
    if _session_factory is None:
        init_db()
    assert _session_factory is not None
    return _session_factory()


def get_engine() -> Engine:
    global _engine
    if _engine is None:
        init_db()
    assert _engine is not None
    return _engine
