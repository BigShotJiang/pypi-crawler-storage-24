"""HTTP request/response parsing utilities."""

from __future__ import annotations

from urllib.parse import parse_qs, urlparse

from sufa.core.models import HttpMethod, HttpParameter, HttpRequest, HttpResponse


def parse_url(url: str) -> tuple[str, str, str, str]:
    """Parse URL into (scheme, host, path, query)."""
    parsed = urlparse(url)
    return parsed.scheme or "https", parsed.netloc, parsed.path or "/", parsed.query


def extract_parameters(url: str, body: str = "", content_type: str = "") -> list[HttpParameter]:
    """Extract parameters from URL query string and request body."""
    params: list[HttpParameter] = []
    _, _, _, query = parse_url(url)

    if query:
        for k, values in parse_qs(query, keep_blank_values=True).items():
            for v in values:
                params.append(HttpParameter(name=k, value=v, param_type="query"))

    if body and content_type:
        if "application/x-www-form-urlencoded" in content_type:
            for k, values in parse_qs(body, keep_blank_values=True).items():
                for v in values:
                    params.append(HttpParameter(name=k, value=v, param_type="body"))
        elif "application/json" in content_type:
            import json

            try:
                data = json.loads(body)
                if isinstance(data, dict):
                    for k, v in data.items():
                        params.append(HttpParameter(name=k, value=str(v)[:150], param_type="json"))
            except (json.JSONDecodeError, ValueError):
                pass

    return params


def build_request(
    method: str,
    url: str,
    headers: dict[str, str] | None = None,
    body: str = "",
) -> HttpRequest:
    """Build an HttpRequest model from raw components."""
    headers = headers or {}
    scheme, host, path, _ = parse_url(url)
    content_type = headers.get("content-type", headers.get("Content-Type", ""))
    parameters = extract_parameters(url, body, content_type)

    return HttpRequest(
        method=HttpMethod(method.upper()),
        url=url,
        path=path,
        host=host,
        scheme=scheme,
        headers=headers,
        body=body,
        parameters=parameters,
        content_type=content_type,
    )


def build_response(
    status_code: int,
    headers: dict[str, str] | None = None,
    body: str = "",
    reason: str = "",
) -> HttpResponse:
    headers = headers or {}
    return HttpResponse(
        status_code=status_code,
        reason=reason,
        headers=headers,
        body=body,
        content_type=headers.get("content-type", headers.get("Content-Type", "")),
        content_length=len(body.encode()) if body else 0,
    )
