"""HTTP traffic normalization -- decompress, decode, size-limit before AI analysis."""

from __future__ import annotations

import base64
import gzip
import re
import zlib

MAX_REQUEST_BODY = 2000
MAX_RESPONSE_BODY = 3000
MAX_HEADER_VALUE = 500
BINARY_PLACEHOLDER = "[Binary content removed]"


def normalize_body(body: str | bytes, max_length: int) -> str:
    """Normalize an HTTP body: decompress, decode, truncate."""
    if isinstance(body, bytes):
        body = _try_decompress(body)

    if not isinstance(body, str):
        try:
            body = body.decode("utf-8", errors="replace")
        except Exception:
            return BINARY_PLACEHOLDER

    if _is_binary(body):
        return BINARY_PLACEHOLDER

    body = _try_decode_base64_segments(body)
    body = _strip_excessive_whitespace(body)

    if len(body) > max_length:
        body = body[:max_length] + f"\n... [truncated, {len(body)} total chars]"

    return body


def normalize_request_body(body: str | bytes) -> str:
    return normalize_body(body, MAX_REQUEST_BODY)


def normalize_response_body(body: str | bytes) -> str:
    return normalize_body(body, MAX_RESPONSE_BODY)


def normalize_headers(headers: dict[str, str]) -> dict[str, str]:
    """Normalize header values: truncate long values, lowercase keys."""
    result = {}
    for key, value in headers.items():
        k = key.lower().strip()
        v = value.strip()
        if len(v) > MAX_HEADER_VALUE:
            v = v[:MAX_HEADER_VALUE] + "..."
        result[k] = v
    return result


def _try_decompress(data: bytes) -> str | bytes:
    for decompress in [
        lambda d: gzip.decompress(d).decode("utf-8", errors="replace"),
        lambda d: zlib.decompress(d).decode("utf-8", errors="replace"),
        lambda d: zlib.decompress(d, -zlib.MAX_WBITS).decode("utf-8", errors="replace"),
    ]:
        try:
            return decompress(data)
        except Exception:
            continue
    return data


def _is_binary(text: str) -> bool:
    if not text:
        return False
    sample = text[:1024]
    non_text = sum(1 for c in sample if ord(c) < 9 or (13 < ord(c) < 32))
    return non_text / max(len(sample), 1) > 0.1


_BASE64_RE = re.compile(r"[A-Za-z0-9+/]{40,}={0,2}")


def _try_decode_base64_segments(text: str) -> str:
    def _decode_match(m: re.Match) -> str:
        try:
            decoded = base64.b64decode(m.group()).decode("utf-8", errors="replace")
            if _is_binary(decoded):
                return "[base64:binary]"
            return f"[base64:{decoded[:200]}]"
        except Exception:
            return m.group()

    return _BASE64_RE.sub(_decode_match, text)


def _strip_excessive_whitespace(text: str) -> str:
    lines = text.splitlines()
    stripped = [line.rstrip() for line in lines]
    result = []
    blank_count = 0
    for line in stripped:
        if not line:
            blank_count += 1
            if blank_count <= 2:
                result.append(line)
        else:
            blank_count = 0
            result.append(line)
    return "\n".join(result)
