"""Data redaction -- strip sensitive information before sending to AI providers."""

from __future__ import annotations

import re

SENSITIVE_HEADERS = {
    "authorization",
    "cookie",
    "set-cookie",
    "x-api-key",
    "x-auth-token",
    "x-csrf-token",
    "x-xsrf-token",
    "proxy-authorization",
    "www-authenticate",
}

SENSITIVE_BODY_PATTERNS = [
    re.compile(r'("password"\s*:\s*)"[^"]*"', re.IGNORECASE),
    re.compile(r'("secret"\s*:\s*)"[^"]*"', re.IGNORECASE),
    re.compile(r'("token"\s*:\s*)"[^"]*"', re.IGNORECASE),
    re.compile(r'("api_key"\s*:\s*)"[^"]*"', re.IGNORECASE),
    re.compile(r'("apiKey"\s*:\s*)"[^"]*"', re.IGNORECASE),
    re.compile(r'("access_token"\s*:\s*)"[^"]*"', re.IGNORECASE),
    re.compile(r'("refresh_token"\s*:\s*)"[^"]*"', re.IGNORECASE),
    re.compile(r"(password=)[^&\s]+", re.IGNORECASE),
    re.compile(r"(passwd=)[^&\s]+", re.IGNORECASE),
    re.compile(r"(token=)[^&\s]+", re.IGNORECASE),
    re.compile(r"(api_key=)[^&\s]+", re.IGNORECASE),
    re.compile(r"(secret=)[^&\s]+", re.IGNORECASE),
]

REDACTED = "***REDACTED***"


def redact_headers(
    headers: dict[str, str],
    extra_patterns: list[str] | None = None,
) -> dict[str, str]:
    """Redact sensitive header values."""
    sensitive = set(SENSITIVE_HEADERS)
    if extra_patterns:
        sensitive.update(p.lower() for p in extra_patterns)

    redacted = {}
    for key, value in headers.items():
        if key.lower() in sensitive:
            redacted[key] = REDACTED
        else:
            redacted[key] = value
    return redacted


def redact_body(body: str) -> str:
    """Redact sensitive values in request/response bodies."""
    if not body:
        return body
    result = body
    for pattern in SENSITIVE_BODY_PATTERNS:
        result = pattern.sub(rf"\g<1>{REDACTED}", result)
    return result


def redact_url(url: str) -> str:
    """Redact sensitive query parameters from URLs."""
    sensitive_params = {"token", "api_key", "apikey", "key", "secret", "password", "access_token"}
    parts = url.split("?", 1)
    if len(parts) < 2:
        return url
    base = parts[0]
    query = parts[1]
    pairs = query.split("&")
    cleaned = []
    for pair in pairs:
        if "=" in pair:
            k, _ = pair.split("=", 1)
            if k.lower() in sensitive_params:
                cleaned.append(f"{k}={REDACTED}")
            else:
                cleaned.append(pair)
        else:
            cleaned.append(pair)
    return base + "?" + "&".join(cleaned)


def redact_traffic_for_ai(
    headers: dict[str, str],
    body: str,
    url: str,
    extra_header_patterns: list[str] | None = None,
) -> tuple[dict[str, str], str, str]:
    """Redact all sensitive data from a traffic entry for AI consumption."""
    return (
        redact_headers(headers, extra_header_patterns),
        redact_body(body),
        redact_url(url),
    )
