"""Central traffic store for persisting, querying, and managing HTTP traffic."""

from __future__ import annotations

from sufa.core.db.repository import Repository
from sufa.core.events import EventBus
from sufa.core.events.events import TrafficStoredEvent
from sufa.core.models import TrafficEntry
from sufa.core.traffic.models import TrafficFilter
from sufa.core.utils.logging import get_logger

logger = get_logger(__name__)


class TrafficStore:
    """Central store for all captured HTTP traffic."""

    def __init__(self, repo: Repository, event_bus: EventBus | None = None) -> None:
        self._repo = repo
        self._bus = event_bus

    def store(self, entry: TrafficEntry) -> None:
        """Persist a traffic entry and emit an event."""
        self._repo.save_traffic(entry)
        logger.debug("traffic_stored", traffic_id=entry.id, url=entry.request.url[:100])
        if self._bus:
            self._bus.emit(
                TrafficStoredEvent(
                    data={"traffic_id": entry.id, "url": entry.request.url},
                    source="traffic_store",
                )
            )

    def get(self, traffic_id: str) -> TrafficEntry | None:
        return self._repo.get_traffic(traffic_id)

    def query(self, filt: TrafficFilter | None = None) -> list[TrafficEntry]:
        filt = filt or TrafficFilter()
        entries = self._repo.list_traffic(
            scan_id=filt.scan_id,
            host=filt.host,
            limit=filt.limit,
        )
        if filt.method:
            entries = [e for e in entries if e.request.method.value == filt.method.upper()]
        if filt.path_contains:
            entries = [e for e in entries if filt.path_contains in e.request.path]
        if filt.status_code is not None and entries:
            entries = [
                e for e in entries if e.response and e.response.status_code == filt.status_code
            ]
        if filt.min_status is not None:
            entries = [
                e for e in entries if e.response and e.response.status_code >= filt.min_status
            ]
        if filt.max_status is not None:
            entries = [
                e for e in entries if e.response and e.response.status_code <= filt.max_status
            ]
        if filt.has_parameters is not None:
            if filt.has_parameters:
                entries = [e for e in entries if e.request.parameters]
            else:
                entries = [e for e in entries if not e.request.parameters]
        return entries

    def get_hosts(self, scan_id: str = "") -> list[str]:
        """Get unique hosts from stored traffic."""
        entries = self._repo.list_traffic(scan_id=scan_id, limit=10000)
        return sorted({e.request.host for e in entries if e.request.host})

    def get_endpoints(self, host: str = "", scan_id: str = "") -> list[dict]:
        """Get unique method+path combinations."""
        entries = self._repo.list_traffic(scan_id=scan_id, host=host, limit=10000)
        seen: dict[str, dict] = {}
        for e in entries:
            key = f"{e.request.method.value} {e.request.path}"
            if key not in seen:
                seen[key] = {
                    "method": e.request.method.value,
                    "path": e.request.path,
                    "host": e.request.host,
                    "param_count": len(e.request.parameters),
                    "count": 0,
                }
            seen[key]["count"] += 1
        return sorted(seen.values(), key=lambda x: x["count"], reverse=True)

    def count(self, scan_id: str = "") -> int:
        return len(self._repo.list_traffic(scan_id=scan_id, limit=100000))
