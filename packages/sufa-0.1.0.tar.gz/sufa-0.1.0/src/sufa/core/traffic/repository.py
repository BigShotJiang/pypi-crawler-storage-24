"""Traffic-specific query helpers."""

from __future__ import annotations

from sufa.core.db.repository import Repository
from sufa.core.models import TrafficEntry


def get_traffic_for_analysis(
    repo: Repository,
    scan_id: str,
    analyzed_ids: set[str] | None = None,
    limit: int = 50,
) -> list[TrafficEntry]:
    """Fetch traffic entries that haven't been analyzed yet."""
    entries = repo.list_traffic(scan_id=scan_id, limit=limit * 3)
    if analyzed_ids:
        entries = [e for e in entries if e.id not in analyzed_ids]
    return entries[:limit]
