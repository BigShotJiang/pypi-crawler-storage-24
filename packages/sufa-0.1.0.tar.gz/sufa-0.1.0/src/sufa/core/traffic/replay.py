"""Request replay engine for re-sending stored traffic."""

from __future__ import annotations

import httpx

from sufa.core.models import HttpResponse, TrafficEntry
from sufa.core.utils.logging import get_logger

logger = get_logger(__name__)


async def replay_request(
    entry: TrafficEntry,
    timeout: float = 30.0,
    follow_redirects: bool = True,
    verify_ssl: bool = False,
    header_overrides: dict[str, str] | None = None,
) -> HttpResponse:
    """Replay a stored HTTP request and return the response."""
    headers = dict(entry.request.headers)
    if header_overrides:
        headers.update(header_overrides)

    async with httpx.AsyncClient(
        timeout=timeout, follow_redirects=follow_redirects, verify=verify_ssl
    ) as client:
        resp = await client.request(
            method=entry.request.method.value,
            url=entry.request.url,
            headers=headers,
            content=entry.request.body.encode() if entry.request.body else None,
        )

    resp_headers = dict(resp.headers)
    try:
        body = resp.text
    except Exception:
        body = "[Binary content]"

    return HttpResponse(
        status_code=resp.status_code,
        reason=resp.reason_phrase or "",
        headers=resp_headers,
        body=body,
        content_type=resp_headers.get("content-type", ""),
        content_length=len(resp.content),
    )
