"""Traffic store specific models and query filters."""

from __future__ import annotations

from dataclasses import dataclass, field


@dataclass
class TrafficFilter:
    scan_id: str = ""
    project_id: str = ""
    host: str = ""
    method: str = ""
    path_contains: str = ""
    status_code: int | None = None
    min_status: int | None = None
    max_status: int | None = None
    content_type: str = ""
    has_parameters: bool | None = None
    tags: list[str] = field(default_factory=list)
    limit: int = 100
    offset: int = 0
