"""Shared types used across core modules."""

from __future__ import annotations

from dataclasses import dataclass, field


@dataclass
class PayloadResult:
    payload: str = ""
    status_code: int = 0
    response_body: str = ""
    response_headers: dict[str, str] = field(default_factory=dict)
    success: bool = False
    error: str = ""
