"""Role-Based Access Control for the sufa API server."""

from __future__ import annotations

from enum import StrEnum

from pydantic import BaseModel


class Role(StrEnum):
    ADMIN = "admin"
    ANALYST = "analyst"
    VIEWER = "viewer"


class User(BaseModel):
    id: str
    username: str
    role: Role = Role.VIEWER
    teams: list[str] = []


ROLE_PERMISSIONS: dict[Role, set[str]] = {
    Role.ADMIN: {
        "projects:create",
        "projects:read",
        "projects:update",
        "projects:delete",
        "scans:create",
        "scans:read",
        "scans:update",
        "scans:delete",
        "findings:read",
        "findings:update",
        "findings:delete",
        "traffic:read",
        "traffic:delete",
        "users:manage",
        "settings:manage",
        "webhooks:manage",
    },
    Role.ANALYST: {
        "projects:create",
        "projects:read",
        "projects:update",
        "scans:create",
        "scans:read",
        "scans:update",
        "findings:read",
        "findings:update",
        "traffic:read",
    },
    Role.VIEWER: {
        "projects:read",
        "scans:read",
        "findings:read",
        "traffic:read",
    },
}


def has_permission(user: User, permission: str) -> bool:
    return permission in ROLE_PERMISSIONS.get(user.role, set())


def require_permission(user: User, permission: str) -> None:
    if not has_permission(user, permission):
        from fastapi import HTTPException

        raise HTTPException(
            status_code=403,
            detail=f"Insufficient permissions. Required: {permission}",
        )
