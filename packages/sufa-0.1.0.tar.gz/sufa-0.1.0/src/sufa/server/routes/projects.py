"""API routes for project management."""

from __future__ import annotations

from fastapi import APIRouter, HTTPException
from pydantic import BaseModel

from sufa.core.db import Repository

router = APIRouter()


class ProjectCreate(BaseModel):
    name: str
    description: str = ""
    target_urls: list[str] = []


@router.post("/projects")
async def create_project(payload: ProjectCreate):
    from sufa.core.models import Project

    project = Project(
        name=payload.name,
        description=payload.description,
        target_urls=payload.target_urls,
    )
    repo = Repository()
    repo.save_project(project)
    return {"id": project.id, "name": project.name}


@router.get("/projects")
async def list_projects():
    repo = Repository()
    projects = repo.list_projects()
    return [
        {
            "id": p.id,
            "name": p.name,
            "description": p.description,
            "target_urls": p.target_urls,
            "created_at": p.created_at.isoformat(),
        }
        for p in projects
    ]


@router.get("/projects/{project_id}")
async def get_project(project_id: str):
    repo = Repository()
    project = repo.get_project(project_id)
    if not project:
        raise HTTPException(status_code=404, detail="Project not found")
    return project.model_dump()


@router.delete("/projects/{project_id}")
async def delete_project(project_id: str):
    repo = Repository()
    if not repo.delete_project(project_id):
        raise HTTPException(status_code=404, detail="Project not found")
    return {"deleted": project_id}
