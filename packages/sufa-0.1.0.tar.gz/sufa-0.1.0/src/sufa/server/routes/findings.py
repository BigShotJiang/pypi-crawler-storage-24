"""API routes for findings management."""

from __future__ import annotations

from fastapi import APIRouter, HTTPException
from pydantic import BaseModel

from sufa.core.db import Repository

router = APIRouter()


class FindingUpdate(BaseModel):
    status: str


@router.get("/findings")
async def list_findings(
    scan_id: str = "",
    severity: str = "",
    status: str = "",
    limit: int = 100,
):
    repo = Repository()
    findings = repo.list_findings(scan_id=scan_id, severity=severity, status=status, limit=limit)
    return [
        {
            "id": f.id,
            "title": f.title,
            "severity": f.severity.value,
            "confidence": f.confidence.value,
            "confidence_score": f.confidence_score,
            "cwe_id": f.cwe_id,
            "url": f.url,
            "parameter": f.parameter,
            "status": f.status.value,
            "scan_id": f.scan_id,
            "created_at": f.created_at.isoformat(),
        }
        for f in findings
    ]


@router.get("/findings/{finding_id}")
async def get_finding(finding_id: str):
    repo = Repository()
    finding = repo.get_finding(finding_id)
    if not finding:
        raise HTTPException(status_code=404, detail="Finding not found")
    return finding.model_dump()


@router.patch("/findings/{finding_id}")
async def update_finding(finding_id: str, payload: FindingUpdate):
    repo = Repository()
    valid = {"open", "confirmed", "false_positive", "accepted_risk", "fixed"}
    if payload.status not in valid:
        raise HTTPException(status_code=400, detail=f"Invalid status. Must be: {valid}")
    if not repo.update_finding_status(finding_id, payload.status):
        raise HTTPException(status_code=404, detail="Finding not found")
    return {"id": finding_id, "status": payload.status}
