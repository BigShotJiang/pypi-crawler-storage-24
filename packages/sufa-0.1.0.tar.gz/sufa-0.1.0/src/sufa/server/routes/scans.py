"""API routes for scan management."""

from __future__ import annotations

from fastapi import APIRouter, HTTPException
from pydantic import BaseModel

from sufa.core.db import Repository

router = APIRouter()


class ScanCreate(BaseModel):
    target_url: str
    scan_type: str = "passive"
    profile: str = "standard"
    project_id: str = ""


@router.post("/scans")
async def create_scan(payload: ScanCreate):
    """Create and queue a new scan."""
    from sufa.core.models import Scan

    scan = Scan(
        target_url=payload.target_url,
        scan_type=payload.scan_type,
        profile=payload.profile,
        project_id=payload.project_id,
    )
    repo = Repository()
    repo.save_scan(scan)
    return {"id": scan.id, "status": scan.status.value}


@router.get("/scans")
async def list_scans(project_id: str = "", limit: int = 20):
    repo = Repository()
    scans = repo.list_scans(project_id=project_id)[:limit]
    return [
        {
            "id": s.id,
            "target_url": s.target_url,
            "scan_type": s.scan_type.value,
            "status": s.status.value,
            "stats": s.stats.model_dump(),
            "created_at": s.created_at.isoformat(),
        }
        for s in scans
    ]


@router.get("/scans/{scan_id}")
async def get_scan(scan_id: str):
    repo = Repository()
    scan = repo.get_scan(scan_id)
    if not scan:
        raise HTTPException(status_code=404, detail="Scan not found")
    return scan.model_dump()
