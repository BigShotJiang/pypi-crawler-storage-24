"""API routes for traffic management and Burp bridge ingestion."""

from __future__ import annotations

from fastapi import APIRouter, HTTPException
from pydantic import BaseModel

from sufa.burp.bridge import parse_burp_traffic
from sufa.core.db import Repository
from sufa.core.events import EventBus
from sufa.core.traffic import TrafficStore

router = APIRouter()


class TrafficPayload(BaseModel):
    request: dict
    response: dict | None = None
    source: str = "api"


@router.post("/traffic")
async def ingest_traffic(payload: TrafficPayload):
    """Receive traffic from external sources (Burp bridge, API clients)."""
    entry = parse_burp_traffic(payload.model_dump())
    repo = Repository()
    bus = EventBus()
    store = TrafficStore(repo, bus)
    store.store(entry)
    return {"id": entry.id, "url": entry.request.url}


@router.get("/traffic")
async def list_traffic(
    scan_id: str = "",
    host: str = "",
    limit: int = 50,
):
    """List stored traffic entries."""
    repo = Repository()
    entries = repo.list_traffic(scan_id=scan_id, host=host, limit=limit)
    return [
        {
            "id": e.id,
            "method": e.request.method.value,
            "url": e.request.url,
            "host": e.request.host,
            "status_code": e.response.status_code if e.response else 0,
            "timestamp": e.timestamp.isoformat(),
            "source": e.source,
        }
        for e in entries
    ]


@router.get("/traffic/{traffic_id}")
async def get_traffic(traffic_id: str):
    """Get a specific traffic entry."""
    repo = Repository()
    entry = repo.get_traffic(traffic_id)
    if not entry:
        raise HTTPException(status_code=404, detail="Traffic entry not found")
    return entry.model_dump()
