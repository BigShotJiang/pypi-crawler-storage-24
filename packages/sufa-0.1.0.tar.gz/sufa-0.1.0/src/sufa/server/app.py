"""FastAPI REST server for sufa Enterprise."""

from __future__ import annotations

from contextlib import asynccontextmanager

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from sufa.core.db import init_db
from sufa.core.utils.config import SufaConfig


@asynccontextmanager
async def lifespan(app: FastAPI):
    config = SufaConfig()
    db_url = config.get("server.db_url", "")
    if db_url:
        init_db(db_url=db_url)
    else:
        init_db(config.get_db_path())
    yield


def create_app() -> FastAPI:
    app = FastAPI(
        title="sufa API",
        description="AI-powered web vulnerability analysis platform",
        version="0.1.0",
        lifespan=lifespan,
    )

    app.add_middleware(
        CORSMiddleware,
        allow_origins=["*"],
        allow_credentials=True,
        allow_methods=["*"],
        allow_headers=["*"],
    )

    from sufa.server.routes import findings, projects, scans, traffic

    app.include_router(traffic.router, prefix="/api/v1", tags=["traffic"])
    app.include_router(scans.router, prefix="/api/v1", tags=["scans"])
    app.include_router(findings.router, prefix="/api/v1", tags=["findings"])
    app.include_router(projects.router, prefix="/api/v1", tags=["projects"])

    @app.get("/health")
    async def health():
        return {"status": "ok", "version": "0.1.0"}

    return app
