"""Main CLI application for sufa."""

from __future__ import annotations

import typer

from sufa.cli.commands import (
    config_cmd,
    findings,
    import_cmd,
    project,
    provider,
    proxy,
    replay,
    report,
    scan,
    server,
)

app = typer.Typer(
    name="sufa",
    help="AI-powered web vulnerability analysis platform.",
    no_args_is_help=True,
    add_completion=False,
)

app.add_typer(scan.app, name="scan", help="Scan targets for vulnerabilities")
app.add_typer(findings.app, name="findings", help="Manage vulnerability findings")
app.add_typer(project.app, name="project", help="Manage projects")
app.add_typer(config_cmd.app, name="config", help="View and modify configuration")
app.add_typer(provider.app, name="provider", help="Manage AI providers")
app.add_typer(report.app, name="report", help="Generate reports")
app.add_typer(import_cmd.app, name="import", help="Import traffic from files")
app.add_typer(proxy.app, name="proxy", help="Intercept proxy for capturing traffic")
app.add_typer(replay.app, name="replay", help="Replay stored requests")
app.add_typer(server.app, name="server", help="Start the API server (Enterprise)")


@app.callback(invoke_without_command=True)
def main_callback(ctx: typer.Context) -> None:
    if ctx.invoked_subcommand is None:
        from sufa.cli.display import print_banner

        print_banner()
        raise typer.Exit()


def main() -> None:
    app()
