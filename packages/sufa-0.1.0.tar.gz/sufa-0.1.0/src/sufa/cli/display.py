"""Rich terminal display utilities for the sufa CLI."""

from __future__ import annotations

from rich.console import Console
from rich.panel import Panel
from rich.table import Table
from rich.text import Text

console = Console()
error_console = Console(stderr=True)

SEVERITY_COLORS = {
    "critical": "bold red",
    "high": "red",
    "medium": "yellow",
    "low": "cyan",
    "info": "dim",
}

STATUS_COLORS = {
    "open": "red",
    "confirmed": "bold red",
    "false_positive": "dim",
    "accepted_risk": "yellow",
    "fixed": "green",
    "pending": "dim",
    "running": "cyan",
    "completed": "green",
    "failed": "red",
    "cancelled": "dim",
}


def print_banner() -> None:
    banner = Text()
    banner.append("  ___  _   _  ___  ___ \n", style="bold cyan")
    banner.append(" / __|| | | || __|| _ |\n", style="bold cyan")
    banner.append(" \\__ \\| |_| || _| |   /\n", style="bold cyan")
    banner.append(" |___/ \\___/ |_|  |_|_\\\n", style="bold cyan")
    banner.append("\n AI-Powered Vulnerability Analysis", style="dim")
    console.print(Panel(banner, border_style="cyan", padding=(0, 2)))


def print_findings_table(findings: list[dict]) -> None:
    table = Table(title="Findings", show_lines=True)
    table.add_column("ID", style="dim", width=10)
    table.add_column("Severity", width=10)
    table.add_column("Title", min_width=30)
    table.add_column("CWE", width=10)
    table.add_column("URL", max_width=50)
    table.add_column("Status", width=14)

    for f in findings:
        sev = f.get("severity", "info")
        status = f.get("status", "open")
        table.add_row(
            f.get("id", "")[:8],
            Text(sev.upper(), style=SEVERITY_COLORS.get(sev, "")),
            f.get("title", ""),
            f.get("cwe_id", ""),
            (f.get("url", "")[:48] + "..") if len(f.get("url", "")) > 50 else f.get("url", ""),
            Text(status, style=STATUS_COLORS.get(status, "")),
        )
    console.print(table)


def print_scans_table(scans: list[dict]) -> None:
    table = Table(title="Scans")
    table.add_column("ID", style="dim", width=10)
    table.add_column("Target", min_width=30)
    table.add_column("Type", width=10)
    table.add_column("Status", width=12)
    table.add_column("Findings", width=10, justify="right")
    table.add_column("Created", width=20)

    for s in scans:
        status = s.get("status", "pending")
        table.add_row(
            s.get("id", "")[:8],
            s.get("target_url", ""),
            s.get("scan_type", ""),
            Text(status, style=STATUS_COLORS.get(status, "")),
            str(s.get("findings_count", 0)),
            s.get("created_at", ""),
        )
    console.print(table)


def print_projects_table(projects: list[dict]) -> None:
    table = Table(title="Projects")
    table.add_column("ID", style="dim", width=10)
    table.add_column("Name", min_width=20)
    table.add_column("Description", min_width=30)
    table.add_column("Created", width=20)

    for p in projects:
        table.add_row(
            p.get("id", "")[:8],
            p.get("name", ""),
            p.get("description", ""),
            p.get("created_at", ""),
        )
    console.print(table)


def print_config_table(config: dict) -> None:
    table = Table(title="Configuration")
    table.add_column("Key", style="cyan", min_width=25)
    table.add_column("Value", min_width=30)

    for key in sorted(config.keys()):
        val = config[key]
        if "key" in key.lower() and val:
            val = str(val)[:4] + "****"
        table.add_row(key, str(val))
    console.print(table)


def print_provider_status(results: dict[str, bool]) -> None:
    table = Table(title="AI Provider Status")
    table.add_column("Provider", min_width=15)
    table.add_column("Status", min_width=15)

    for name, ok in results.items():
        if ok:
            table.add_row(name, Text("Connected", style="green"))
        else:
            table.add_row(name, Text("Failed", style="red"))
    console.print(table)


def print_success(msg: str) -> None:
    console.print(f"[green]✓[/green] {msg}")


def print_error(msg: str) -> None:
    error_console.print(f"[red]✗[/red] {msg}")


def print_warning(msg: str) -> None:
    console.print(f"[yellow]![/yellow] {msg}")


def print_info(msg: str) -> None:
    console.print(f"[cyan]→[/cyan] {msg}")
