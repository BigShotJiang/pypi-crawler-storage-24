"""CLI command to start the API server."""

from __future__ import annotations

import typer

from sufa.cli.display import print_info

app = typer.Typer(no_args_is_help=True)


@app.command("start")
def start_server(
    host: str = typer.Option("0.0.0.0", "--host", "-h", help="Bind host"),
    port: int = typer.Option(9000, "--port", "-p", help="Bind port"),
    reload: bool = typer.Option(False, "--reload", help="Enable auto-reload for development"),
) -> None:
    """Start the sufa API server."""
    try:
        import uvicorn
    except ImportError:
        from sufa.cli.display import print_error

        print_error("Server requires FastAPI extras: pip install sufa[server]")
        raise typer.Exit(1)

    print_info(f"Starting sufa API server on {host}:{port}")
    docs_host = "localhost" if host == "0.0.0.0" else host
    print_info(f"API docs: http://{docs_host}:{port}/docs")

    uvicorn.run(
        "sufa.server.app:create_app",
        host=host,
        port=port,
        reload=reload,
        factory=True,
    )
