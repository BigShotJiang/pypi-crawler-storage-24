"""CLI commands for replaying stored requests."""

from __future__ import annotations

import asyncio

import typer

from sufa.cli.display import console, print_error, print_info, print_success

app = typer.Typer(no_args_is_help=True)


@app.callback(invoke_without_command=True)
def replay_request(
    request_id: str = typer.Argument(..., help="Traffic entry ID to replay"),
    modify_url: str = typer.Option("", "--url", help="Override the target URL"),
    modify_header: list[str] = typer.Option(
        [],
        "--header",
        "-H",
        help="Override headers (key:value)",
    ),
    timeout: float = typer.Option(30.0, "--timeout", "-t", help="Request timeout"),
    no_verify: bool = typer.Option(False, "--no-verify", help="Skip SSL verification"),
) -> None:
    """Replay a stored HTTP request."""
    from sufa.core.db import Repository, init_db
    from sufa.core.traffic.replay import replay_request as do_replay
    from sufa.core.utils.config import SufaConfig

    config = SufaConfig()
    init_db(config.get_db_path())
    repo = Repository()

    entry = repo.get_traffic(request_id)
    if not entry:
        entries = repo.list_traffic(limit=500)
        matches = [e for e in entries if e.id.startswith(request_id)]
        if len(matches) == 1:
            entry = matches[0]
        else:
            print_error(f"Traffic entry not found: {request_id}")
            raise typer.Exit(1)

    if modify_url:
        entry.request.url = modify_url

    header_overrides = {}
    for h in modify_header:
        if ":" in h:
            k, v = h.split(":", 1)
            header_overrides[k.strip()] = v.strip()

    print_info(f"Replaying: {entry.request.method.value} {entry.request.url}")

    async def run():
        return await do_replay(
            entry,
            timeout=timeout,
            verify_ssl=not no_verify,
            header_overrides=header_overrides if header_overrides else None,
        )

    with console.status("[cyan]Sending request...[/cyan]"):
        response = asyncio.run(run())

    print_success(f"Response: {response.status_code} {response.reason}")
    console.print(f"[dim]Content-Type: {response.content_type}[/dim]")
    console.print(f"[dim]Content-Length: {response.content_length}[/dim]")

    if response.body:
        body_preview = response.body[:2000]
        if len(response.body) > 2000:
            body_preview += f"\n... [{len(response.body)} total chars]"
        console.print()
        console.print(body_preview)

    repo.close()
