"""CLI commands for AI provider management."""

from __future__ import annotations

import asyncio

import typer

from sufa.cli.display import print_error, print_info, print_provider_status, print_success

app = typer.Typer(no_args_is_help=True)


@app.command("test")
def test_provider() -> None:
    """Test AI provider connectivity."""
    from sufa.core.ai.router import AIRouter
    from sufa.core.utils.config import SufaConfig

    config = SufaConfig()
    router = AIRouter(config)

    print_info(f"Testing providers: {', '.join(router.provider_names)}")

    async def run_test() -> dict[str, bool]:
        return await router.test_connection()

    results = asyncio.run(run_test())
    print_provider_status(results)

    if any(results.values()):
        print_success("At least one provider is available")
    else:
        print_error("No providers available. Check your configuration.")
        raise typer.Exit(1)


@app.command("list")
def list_providers() -> None:
    """List available AI providers."""
    from sufa.core.ai.router import PROVIDER_MAP
    from sufa.core.utils.config import SufaConfig

    config = SufaConfig()
    current = config.provider

    from rich.table import Table

    from sufa.cli.display import console

    table = Table(title="Available AI Providers")
    table.add_column("Provider")
    table.add_column("Active", justify="center")
    table.add_column("Model")
    table.add_column("API URL")

    for name in sorted(PROVIDER_MAP.keys()):
        active = "●" if name == current else ""
        model = config.model if name == current else ""
        url = config.api_url if name == current else ""
        table.add_row(name, active, model, url)

    console.print(table)
