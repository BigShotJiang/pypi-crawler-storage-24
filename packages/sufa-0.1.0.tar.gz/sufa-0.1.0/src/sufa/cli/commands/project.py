"""CLI commands for project management."""

from __future__ import annotations

import typer

from sufa.cli.display import print_error, print_info, print_projects_table, print_success

app = typer.Typer(no_args_is_help=True)


def _get_repo():
    from sufa.core.db import Repository, init_db
    from sufa.core.utils.config import SufaConfig

    config = SufaConfig()
    init_db(config.get_db_path())
    return Repository()


@app.command("create")
def create_project(
    name: str = typer.Argument(..., help="Project name"),
    description: str = typer.Option("", "--desc", "-d", help="Project description"),
) -> None:
    """Create a new project."""
    from sufa.core.models import Project

    repo = _get_repo()
    project = Project(name=name, description=description)
    repo.save_project(project)
    print_success(f"Project created: {project.id[:8]} - {name}")
    repo.close()


@app.command("list")
def list_projects() -> None:
    """List all projects."""
    repo = _get_repo()
    projects = repo.list_projects()

    if not projects:
        print_info("No projects found. Create one with: sufa project create <name>")
        return

    print_projects_table([p.model_dump() for p in projects])
    repo.close()


@app.command("delete")
def delete_project(
    project_id: str = typer.Argument(..., help="Project ID"),
    confirm: bool = typer.Option(False, "--yes", "-y", help="Skip confirmation"),
) -> None:
    """Delete a project."""
    if not confirm:
        confirm = typer.confirm(f"Delete project {project_id[:8]}?")
    if not confirm:
        return

    repo = _get_repo()
    if repo.delete_project(project_id):
        print_success(f"Project {project_id[:8]} deleted")
    else:
        print_error(f"Project not found: {project_id}")
    repo.close()
