"""CLI commands for importing traffic from files."""

from __future__ import annotations

import json
from pathlib import Path

import typer

from sufa.cli.display import print_error, print_success

app = typer.Typer(no_args_is_help=True)


@app.callback(invoke_without_command=True)
def import_file(
    file_path: str = typer.Argument(..., help="Path to HAR or Burp XML file"),
    fmt: str = typer.Option("auto", "--format", "-f", help="File format: auto, har, burp"),
    scan_id: str = typer.Option("", "--scan", help="Associate with scan ID"),
    project_id: str = typer.Option("", "--project", help="Associate with project ID"),
) -> None:
    """Import HTTP traffic from a file."""
    path = Path(file_path)
    if not path.exists():
        print_error(f"File not found: {file_path}")
        raise typer.Exit(1)

    if fmt == "auto":
        if path.suffix.lower() == ".har":
            fmt = "har"
        elif path.suffix.lower() in (".xml", ".burp"):
            fmt = "burp"
        else:
            print_error(
                f"Cannot detect format for {path.suffix}. Use --format har or --format burp"
            )
            raise typer.Exit(1)

    from sufa.core.db import Repository, init_db
    from sufa.core.events import EventBus
    from sufa.core.traffic import TrafficStore
    from sufa.core.utils.config import SufaConfig

    config = SufaConfig()
    init_db(config.get_db_path())
    repo = Repository()
    store = TrafficStore(repo, EventBus())

    count = 0
    if fmt == "har":
        count = _import_har(path, store, scan_id, project_id)
    elif fmt == "burp":
        count = _import_burp_xml(path, store, scan_id, project_id)

    print_success(f"Imported {count} traffic entries from {path.name}")
    repo.close()


def _import_har(path: Path, store, scan_id: str, project_id: str) -> int:
    from sufa.core.http.parser import build_request, build_response
    from sufa.core.models import TrafficEntry

    with open(path) as f:
        data = json.load(f)

    entries = data.get("log", {}).get("entries", [])
    count = 0

    for entry in entries:
        try:
            req_data = entry.get("request", {})
            resp_data = entry.get("response", {})

            headers = {h["name"]: h["value"] for h in req_data.get("headers", [])}
            body = ""
            if req_data.get("postData"):
                body = req_data["postData"].get("text", "")

            req = build_request(
                method=req_data.get("method", "GET"),
                url=req_data.get("url", ""),
                headers=headers,
                body=body,
            )

            resp_headers = {h["name"]: h["value"] for h in resp_data.get("headers", [])}
            resp_body = ""
            if resp_data.get("content"):
                resp_body = resp_data["content"].get("text", "")

            resp = build_response(
                status_code=resp_data.get("status", 0),
                headers=resp_headers,
                body=resp_body,
            )

            traffic = TrafficEntry(
                request=req,
                response=resp,
                scan_id=scan_id,
                project_id=project_id,
                source="har_import",
            )
            store.store(traffic)
            count += 1
        except Exception:
            continue

    return count


def _import_burp_xml(path: Path, store, scan_id: str, project_id: str) -> int:
    import xml.etree.ElementTree as ET

    from sufa.core.http.parser import build_request, build_response
    from sufa.core.models import TrafficEntry

    tree = ET.parse(path)
    root = tree.getroot()
    count = 0

    for item in root.iter("item"):
        try:
            url = item.findtext("url", "")
            method = item.findtext("method", "GET")
            status = int(item.findtext("status", "0"))
            req_body = item.findtext("request", "")
            resp_body = item.findtext("response", "")

            req = build_request(method=method, url=url, body=req_body or "")
            resp = build_response(status_code=status, body=resp_body or "")

            traffic = TrafficEntry(
                request=req,
                response=resp,
                scan_id=scan_id,
                project_id=project_id,
                source="burp_import",
            )
            store.store(traffic)
            count += 1
        except Exception:
            continue

    return count
