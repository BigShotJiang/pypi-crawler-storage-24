"""CLI commands for managing findings."""

from __future__ import annotations

import typer

from sufa.cli.display import console, print_error, print_findings_table, print_info, print_success

app = typer.Typer(no_args_is_help=True)


def _get_repo():
    from sufa.core.db import Repository, init_db
    from sufa.core.utils.config import SufaConfig

    config = SufaConfig()
    init_db(config.get_db_path())
    return Repository()


@app.command("list")
def list_findings(
    scan_id: str = typer.Option("", "--scan", help="Filter by scan ID"),
    severity: str = typer.Option("", "--severity", "-s", help="Filter by severity"),
    status: str = typer.Option("", "--status", help="Filter by status"),
    limit: int = typer.Option(50, "--limit", "-n", help="Max results"),
) -> None:
    """List vulnerability findings."""
    repo = _get_repo()
    findings = repo.list_findings(scan_id=scan_id, severity=severity, status=status, limit=limit)

    if not findings:
        print_info("No findings found.")
        return

    print_findings_table([f.model_dump() for f in findings])
    print_info(f"{len(findings)} findings shown")
    repo.close()


@app.command("show")
def show_finding(
    finding_id: str = typer.Argument(..., help="Finding ID"),
) -> None:
    """Show detailed information about a finding."""
    repo = _get_repo()
    finding = repo.get_finding(finding_id)

    if not finding:
        partial = repo.list_findings(limit=500)
        matches = [f for f in partial if f.id.startswith(finding_id)]
        if len(matches) == 1:
            finding = matches[0]
        else:
            print_error(f"Finding not found: {finding_id}")
            raise typer.Exit(1)

    from rich.panel import Panel
    from rich.text import Text

    from sufa.cli.display import SEVERITY_COLORS

    sev_style = SEVERITY_COLORS.get(finding.severity.value, "")
    header = Text(f"{finding.title}", style="bold")

    console.print(
        Panel(
            header,
            title=f"Finding {finding.id[:8]}",
            border_style=sev_style or "cyan",
        )
    )
    console.print(f"  [bold]Severity:[/bold]   {finding.severity.value.upper()}")
    console.print(
        f"  [bold]Confidence:[/bold] {finding.confidence.value} ({finding.confidence_score}%)"
    )
    console.print(f"  [bold]CWE:[/bold]        {finding.cwe_id} {finding.cwe_url}")
    console.print(f"  [bold]OWASP:[/bold]      {finding.owasp_category}")
    console.print(f"  [bold]URL:[/bold]        {finding.url}")
    console.print(f"  [bold]Parameter:[/bold]  {finding.parameter}")
    console.print(f"  [bold]Status:[/bold]     {finding.status.value}")
    console.print()
    if finding.description:
        console.print(Panel(finding.description, title="Description"))
    if finding.evidence:
        console.print(Panel(finding.evidence, title="Evidence"))
    if finding.remediation:
        console.print(Panel(finding.remediation, title="Remediation"))
    if finding.exploit_steps:
        console.print("[bold]Exploit Steps:[/bold]")
        for step in finding.exploit_steps:
            console.print(f"  {step.step_number}. {step.description}")

    repo.close()


@app.command("triage")
def triage_finding(
    finding_id: str = typer.Argument(..., help="Finding ID"),
    status: str = typer.Option(
        ..., "--status", "-s", help="New status: confirmed, false_positive, accepted_risk, fixed"
    ),
) -> None:
    """Update the triage status of a finding."""
    valid = {"confirmed", "false_positive", "accepted_risk", "fixed", "open"}
    if status not in valid:
        print_error(f"Invalid status. Must be one of: {', '.join(valid)}")
        raise typer.Exit(1)

    repo = _get_repo()
    if repo.update_finding_status(finding_id, status):
        print_success(f"Finding {finding_id[:8]} updated to: {status}")
    else:
        print_error(f"Finding not found: {finding_id}")
    repo.close()
