"""CLI commands for report generation."""

from __future__ import annotations

import typer

from sufa.cli.display import print_error, print_info, print_success

app = typer.Typer(no_args_is_help=True)


@app.command("generate")
def generate_report(
    scan_id: str = typer.Option("", "--scan", "-s", help="Scan ID (defaults to latest)"),
    fmt: str = typer.Option("html", "--format", "-f", help="Report format: html, json, sarif, pdf"),
    output: str = typer.Option("", "--output", "-o", help="Output file path"),
) -> None:
    """Generate a vulnerability report."""
    from sufa.core.db import Repository, init_db
    from sufa.core.utils.config import SufaConfig

    config = SufaConfig()
    init_db(config.get_db_path())
    repo = Repository()

    if not scan_id:
        scans = repo.list_scans()
        if not scans:
            print_error("No scans found. Run a scan first.")
            raise typer.Exit(1)
        scan_id = scans[0].id
        print_info(f"Using latest scan: {scan_id[:8]}")

    scan = repo.get_scan(scan_id)
    if not scan:
        print_error(f"Scan not found: {scan_id}")
        raise typer.Exit(1)

    findings = repo.list_findings(scan_id=scan_id)

    if not output:
        output = f"sufa_report_{scan_id[:8]}.{fmt}"

    if fmt == "html":
        from sufa.core.reports.html import generate_html_report

        content = generate_html_report(scan, findings)
        with open(output, "w") as f:
            f.write(content)
    elif fmt == "json":
        from sufa.core.reports.json_report import generate_json_report

        content = generate_json_report(scan, findings)
        with open(output, "w") as f:
            f.write(content)
    elif fmt == "sarif":
        from sufa.core.reports.sarif import generate_sarif_report

        content = generate_sarif_report(scan, findings)
        with open(output, "w") as f:
            f.write(content)
    elif fmt == "pdf":
        print_error("PDF reports require the 'pdf' extra: pip install sufa[pdf]")
        raise typer.Exit(1)
    else:
        print_error(f"Unknown format: {fmt}")
        raise typer.Exit(1)

    print_success(f"Report generated: {output}")
    repo.close()
