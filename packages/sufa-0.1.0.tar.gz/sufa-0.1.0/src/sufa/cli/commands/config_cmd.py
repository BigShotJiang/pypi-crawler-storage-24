"""CLI commands for configuration management."""

from __future__ import annotations

import typer

from sufa.cli.display import console, print_config_table, print_error, print_success

app = typer.Typer(no_args_is_help=True)


def _get_config():
    from sufa.core.utils.config import SufaConfig

    return SufaConfig()


@app.command("set")
def config_set(
    key: str = typer.Argument(..., help="Configuration key (e.g., ai.provider)"),
    value: str = typer.Argument(..., help="Configuration value"),
) -> None:
    """Set a configuration value."""
    config = _get_config()
    config.set(key, value)
    print_success(f"{key} = {value}")


@app.command("get")
def config_get(
    key: str = typer.Argument(..., help="Configuration key"),
) -> None:
    """Get a configuration value."""
    config = _get_config()
    val = config.get(key)
    if val is None:
        print_error(f"Unknown key: {key}")
        raise typer.Exit(1)
    display_val = str(val)
    if "key" in key.lower() and display_val:
        display_val = display_val[:4] + "****"
    console.print(f"{key} = {display_val}")


@app.command("list")
def config_list() -> None:
    """Show all configuration values."""
    config = _get_config()
    print_config_table(config.get_all())


@app.command("reset")
def config_reset(
    confirm: bool = typer.Option(False, "--yes", "-y", help="Skip confirmation"),
) -> None:
    """Reset configuration to defaults."""
    if not confirm:
        confirm = typer.confirm("Reset all configuration to defaults?")
    if confirm:
        from sufa.core.utils.config import _DEFAULT_CONFIG, SufaConfig

        config = SufaConfig()
        for key, val in _DEFAULT_CONFIG.items():
            config.set(key, val)
        print_success("Configuration reset to defaults")
