"""CLI commands for the intercept proxy."""

from __future__ import annotations

import typer

from sufa.cli.display import print_error, print_info, print_success

app = typer.Typer(no_args_is_help=True)


@app.command("start")
def start_proxy_cmd(
    port: int = typer.Option(8080, "--port", "-p", help="Proxy listen port"),
    scan_id: str = typer.Option("", "--scan", help="Associate with scan ID"),
    project_id: str = typer.Option("", "--project", help="Associate with project ID"),
) -> None:
    """Start the intercept proxy to capture HTTP traffic."""
    from sufa.core.db import Repository, init_db
    from sufa.core.events import EventBus
    from sufa.core.traffic import TrafficStore
    from sufa.core.utils.config import SufaConfig

    config = SufaConfig()
    init_db(config.get_db_path())
    repo = Repository()
    bus = EventBus()
    store = TrafficStore(repo, bus)

    print_info(f"Starting proxy on port {port}")
    print_info(f"Configure your browser/tool to use http://localhost:{port} as proxy")
    print_info("Press Ctrl+C to stop")

    try:
        from sufa.proxy.interceptor import start_proxy

        start_proxy(store, bus, port=port, scan_id=scan_id, project_id=project_id)
    except ImportError:
        print_error("mitmproxy is required. Install with: pip install sufa[proxy]")
        raise typer.Exit(1)
    except KeyboardInterrupt:
        print_success("Proxy stopped")
    finally:
        repo.close()
