"""Bridge communication protocol between Burp extension and sufa server."""

from __future__ import annotations

from sufa.core.http.parser import build_request, build_response
from sufa.core.models import TrafficEntry


def parse_burp_traffic(data: dict) -> TrafficEntry:
    """Parse traffic data sent from the Burp bridge into a TrafficEntry."""
    req_data = data.get("request", {})
    resp_data = data.get("response", {})

    request = build_request(
        method=req_data.get("method", "GET"),
        url=req_data.get("url", ""),
        headers=req_data.get("headers", {}),
        body=req_data.get("body", ""),
    )

    response = None
    if resp_data.get("status_code"):
        response = build_response(
            status_code=resp_data.get("status_code", 0),
            headers=resp_data.get("headers", {}),
            body=resp_data.get("body", ""),
        )

    return TrafficEntry(
        request=request,
        response=response,
        source=data.get("source", "burp"),
    )
