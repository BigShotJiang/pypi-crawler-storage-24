"""Web spider for discovering endpoints through HTML crawling."""

from __future__ import annotations

import asyncio
import re
from urllib.parse import urljoin, urlparse

import httpx

from sufa.core.utils.logging import get_logger

logger = get_logger(__name__)

LINK_PATTERNS = [
    re.compile(r'href=["\']([^"\']+)["\']', re.IGNORECASE),
    re.compile(r'src=["\']([^"\']+)["\']', re.IGNORECASE),
    re.compile(r'action=["\']([^"\']+)["\']', re.IGNORECASE),
    re.compile(r'data-url=["\']([^"\']+)["\']', re.IGNORECASE),
]


class Spider:
    """Crawl a target to discover endpoints."""

    def __init__(
        self,
        max_depth: int = 3,
        max_pages: int = 100,
        timeout: float = 15.0,
        respect_robots: bool = True,
    ) -> None:
        self._max_depth = max_depth
        self._max_pages = max_pages
        self._timeout = timeout
        self._visited: set[str] = set()
        self._discovered: set[str] = set()

    async def crawl(self, start_url: str) -> list[str]:
        """Crawl starting from a URL and return all discovered URLs."""
        parsed = urlparse(start_url)
        self._base_domain = parsed.netloc

        await self._crawl_recursive(start_url, depth=0)
        return sorted(self._discovered)

    async def _crawl_recursive(self, url: str, depth: int) -> None:
        if depth > self._max_depth:
            return
        if len(self._visited) >= self._max_pages:
            return

        normalized = self._normalize_url(url)
        if normalized in self._visited:
            return

        self._visited.add(normalized)
        self._discovered.add(normalized)

        try:
            async with httpx.AsyncClient(
                timeout=self._timeout, follow_redirects=True, verify=False
            ) as client:
                resp = await client.get(url)

            content_type = resp.headers.get("content-type", "")
            if "text/html" not in content_type:
                return

            links = self._extract_links(resp.text, url)

            tasks = []
            for link in links:
                if self._is_same_domain(link) and link not in self._visited:
                    tasks.append(self._crawl_recursive(link, depth + 1))

            if tasks:
                await asyncio.gather(*tasks[:10], return_exceptions=True)

        except Exception:
            logger.debug("crawl_error", url=url[:100])

    def _extract_links(self, html: str, base_url: str) -> list[str]:
        links: set[str] = set()
        for pattern in LINK_PATTERNS:
            for match in pattern.finditer(html):
                href = match.group(1)
                if href.startswith(("#", "mailto:", "tel:", "javascript:")):
                    continue
                absolute = urljoin(base_url, href)
                links.add(absolute)
        return list(links)

    def _is_same_domain(self, url: str) -> bool:
        parsed = urlparse(url)
        return parsed.netloc == self._base_domain

    @staticmethod
    def _normalize_url(url: str) -> str:
        parsed = urlparse(url)
        return f"{parsed.scheme}://{parsed.netloc}{parsed.path}"
