from sufa.crawler.spider import Spider

__all__ = ["Spider"]
