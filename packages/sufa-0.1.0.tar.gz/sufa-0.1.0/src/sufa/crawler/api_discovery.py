"""API schema discovery -- OpenAPI/Swagger and GraphQL introspection."""

from __future__ import annotations

from urllib.parse import urljoin

import httpx

from sufa.core.utils.logging import get_logger

logger = get_logger(__name__)

OPENAPI_PATHS = [
    "/openapi.json",
    "/swagger.json",
    "/api-docs",
    "/v1/openapi.json",
    "/v2/swagger.json",
    "/v3/openapi.json",
    "/docs/openapi.json",
    "/api/swagger.json",
    "/.well-known/openapi.json",
]

GRAPHQL_PATHS = ["/graphql", "/gql", "/api/graphql", "/v1/graphql"]

GRAPHQL_INTROSPECTION = """
query IntrospectionQuery {
  __schema {
    queryType { name }
    mutationType { name }
    types {
      name
      kind
      fields {
        name
        args { name type { name } }
        type { name kind ofType { name } }
      }
    }
  }
}
"""


async def discover_openapi(base_url: str, timeout: float = 10.0) -> dict | None:
    """Try to find and fetch an OpenAPI/Swagger spec."""
    async with httpx.AsyncClient(timeout=timeout, verify=False) as client:
        for path in OPENAPI_PATHS:
            url = urljoin(base_url, path)
            try:
                resp = await client.get(url)
                if resp.status_code == 200:
                    data = resp.json()
                    if "openapi" in data or "swagger" in data or "paths" in data:
                        logger.info("openapi_found", url=url)
                        return data
            except Exception:
                continue
    return None


async def discover_graphql(base_url: str, timeout: float = 10.0) -> dict | None:
    """Try to find and introspect a GraphQL endpoint."""
    async with httpx.AsyncClient(timeout=timeout, verify=False) as client:
        for path in GRAPHQL_PATHS:
            url = urljoin(base_url, path)
            try:
                resp = await client.post(
                    url,
                    json={"query": GRAPHQL_INTROSPECTION},
                    headers={"content-type": "application/json"},
                )
                if resp.status_code == 200:
                    data = resp.json()
                    if "data" in data and "__schema" in data.get("data", {}):
                        logger.info("graphql_found", url=url)
                        return data
            except Exception:
                continue
    return None


def extract_openapi_endpoints(spec: dict) -> list[dict]:
    """Extract endpoints from an OpenAPI spec."""
    endpoints = []
    paths = spec.get("paths", {})
    for path, methods in paths.items():
        for method, details in methods.items():
            if method.lower() in ("get", "post", "put", "patch", "delete"):
                params = []
                for p in details.get("parameters", []):
                    params.append({"name": p.get("name", ""), "in": p.get("in", "query")})
                endpoints.append(
                    {
                        "method": method.upper(),
                        "path": path,
                        "summary": details.get("summary", ""),
                        "parameters": params,
                    }
                )
    return endpoints


def extract_graphql_operations(schema: dict) -> list[dict]:
    """Extract query/mutation operations from a GraphQL introspection result."""
    operations = []
    data = schema.get("data", {}).get("__schema", {})

    for type_info in data.get("types", []):
        if type_info.get("name", "").startswith("__"):
            continue
        kind = type_info.get("kind", "")
        if kind != "OBJECT":
            continue

        is_query = type_info.get("name") == data.get("queryType", {}).get("name")
        is_mutation = type_info.get("name") == data.get("mutationType", {}).get("name")

        if not (is_query or is_mutation):
            continue

        for field in type_info.get("fields", []):
            operations.append(
                {
                    "name": field.get("name", ""),
                    "type": "query" if is_query else "mutation",
                    "args": [a.get("name", "") for a in field.get("args", [])],
                }
            )

    return operations
