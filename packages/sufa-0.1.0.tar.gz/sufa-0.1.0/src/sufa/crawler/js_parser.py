"""JavaScript endpoint discovery -- extract API URLs from JS files."""

from __future__ import annotations

import re
from urllib.parse import urljoin

API_PATTERNS = [
    re.compile(r'["\'](/api/[^"\']+)["\']'),
    re.compile(r'["\'](/v[0-9]+/[^"\']+)["\']'),
    re.compile(r'fetch\(["\']([^"\']+)["\']'),
    re.compile(r'axios\.[a-z]+\(["\']([^"\']+)["\']'),
    re.compile(r'\.get\(["\']([^"\']+)["\']'),
    re.compile(r'\.post\(["\']([^"\']+)["\']'),
    re.compile(r'\.put\(["\']([^"\']+)["\']'),
    re.compile(r'\.delete\(["\']([^"\']+)["\']'),
    re.compile(r'\.patch\(["\']([^"\']+)["\']'),
    re.compile(r'url:\s*["\']([^"\']+)["\']'),
    re.compile(r'endpoint:\s*["\']([^"\']+)["\']'),
    re.compile(r'baseURL:\s*["\']([^"\']+)["\']'),
    re.compile(r'XMLHttpRequest.*?open\(["\'][A-Z]+["\']\s*,\s*["\']([^"\']+)["\']'),
]

IGNORED_EXTENSIONS = {".js", ".css", ".png", ".jpg", ".svg", ".gif", ".ico", ".woff", ".ttf"}


def extract_endpoints(js_content: str, base_url: str = "") -> list[str]:
    """Extract API endpoints from JavaScript source code."""
    endpoints: set[str] = set()

    for pattern in API_PATTERNS:
        for match in pattern.finditer(js_content):
            path = match.group(1).strip()
            if not path or len(path) < 3:
                continue
            if any(path.endswith(ext) for ext in IGNORED_EXTENSIONS):
                continue
            if path.startswith("http"):
                endpoints.add(path)
            elif path.startswith("/") and base_url:
                endpoints.add(urljoin(base_url, path))
            elif path.startswith("/"):
                endpoints.add(path)

    return sorted(endpoints)
