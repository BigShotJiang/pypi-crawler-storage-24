"""Allow running sufa as `python -m sufa`."""

from sufa.cli.app import main

main()
