"""Proxy request handler utilities."""

from __future__ import annotations

from sufa.core.scanner.scope import ScopeManager
from sufa.core.utils.logging import get_logger

logger = get_logger(__name__)


class ProxyFilter:
    """Filter proxy traffic before storing/analyzing."""

    def __init__(self, scope: ScopeManager | None = None) -> None:
        self._scope = scope or ScopeManager()

    def should_capture(self, url: str, content_type: str = "") -> bool:
        if self._scope.should_skip(url, content_type):
            return False
        if not self._scope.is_in_scope(url):
            return False
        return True
