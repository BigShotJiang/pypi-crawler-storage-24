"""mitmproxy-based intercept proxy for capturing HTTP traffic."""

from __future__ import annotations

import asyncio
from typing import TYPE_CHECKING

from sufa.core.events import EventBus
from sufa.core.events.events import ResponseReceivedEvent
from sufa.core.http.parser import build_request, build_response
from sufa.core.models import TrafficEntry
from sufa.core.utils.logging import get_logger

if TYPE_CHECKING:
    from sufa.core.traffic import TrafficStore

logger = get_logger(__name__)


class SufaAddon:
    """mitmproxy addon that captures traffic and feeds it to the sufa pipeline."""

    def __init__(
        self,
        traffic_store: TrafficStore,
        event_bus: EventBus,
        scan_id: str = "",
        project_id: str = "",
    ) -> None:
        self._store = traffic_store
        self._bus = event_bus
        self._scan_id = scan_id
        self._project_id = project_id

    def response(self, flow) -> None:
        """Called by mitmproxy when a full request/response pair is captured."""
        try:
            req = flow.request
            resp = flow.response

            req_headers = dict(req.headers)
            resp_headers = dict(resp.headers)

            request = build_request(
                method=req.method,
                url=req.pretty_url,
                headers=req_headers,
                body=req.get_text(strict=False) or "",
            )
            response = build_response(
                status_code=resp.status_code,
                headers=resp_headers,
                body=resp.get_text(strict=False) or "",
                reason=resp.reason or "",
            )

            entry = TrafficEntry(
                request=request,
                response=response,
                scan_id=self._scan_id,
                project_id=self._project_id,
                source="proxy",
            )

            self._store.store(entry)

            self._bus.emit(
                ResponseReceivedEvent(
                    data={
                        "traffic_id": entry.id,
                        "url": req.pretty_url,
                        "status": resp.status_code,
                    },
                    source="proxy",
                )
            )

            logger.debug("proxy_capture", url=req.pretty_url[:100], status=resp.status_code)
        except Exception:
            logger.exception("proxy_capture_error")


def start_proxy(
    traffic_store: TrafficStore,
    event_bus: EventBus,
    port: int = 8080,
    scan_id: str = "",
    project_id: str = "",
) -> None:
    """Start the mitmproxy-based intercept proxy."""
    try:
        from mitmproxy.options import Options
        from mitmproxy.tools.dump import DumpMaster
    except ImportError:
        raise ImportError(
            "mitmproxy is required for the proxy feature. Install it with: pip install sufa[proxy]"
        )

    addon = SufaAddon(traffic_store, event_bus, scan_id, project_id)

    async def run():
        opts = Options(listen_port=port, ssl_insecure=True)
        master = DumpMaster(opts)
        master.addons.add(addon)
        logger.info("proxy_started", port=port)
        await master.run()

    asyncio.run(run())
