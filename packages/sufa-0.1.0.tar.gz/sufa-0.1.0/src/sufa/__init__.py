"""sufa -- AI-powered web vulnerability analysis platform."""

__version__ = "0.1.0"
