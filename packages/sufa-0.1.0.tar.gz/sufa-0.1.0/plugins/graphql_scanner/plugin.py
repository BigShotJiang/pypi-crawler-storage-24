"""GraphQL Scanner Plugin -- detects GraphQL-specific security issues."""

from __future__ import annotations

from typing import Any

from sufa.core.events.events import Event
from sufa.core.plugins.interface import SufaPlugin


class GraphQLScannerPlugin(SufaPlugin):
    name = "graphql_scanner"
    version = "0.1.0"
    description = "Detect GraphQL-specific vulnerabilities"
    author = "sufa"

    def on_load(self, context: dict[str, Any]) -> None:
        self._graphql_endpoints: set[str] = set()

    def on_response(self, event: Event) -> None:
        url = event.data.get("url", "")
        body = event.data.get("body", "")

        if any(p in url.lower() for p in ("/graphql", "/gql")):
            self._graphql_endpoints.add(url)

            if '"__schema"' in body or '"__type"' in body:
                self._report_introspection(url)

            if "errors" in body and "locations" in body:
                self._report_verbose_errors(url)

    def _report_introspection(self, url: str) -> None:
        pass

    def _report_verbose_errors(self, url: str) -> None:
        pass
