"""OAuth Analyzer Plugin -- detects OAuth/OIDC security misconfigurations."""

from __future__ import annotations

from typing import Any
from urllib.parse import parse_qs, urlparse

from sufa.core.events.events import Event
from sufa.core.plugins.interface import SufaPlugin


class OAuthAnalyzerPlugin(SufaPlugin):
    name = "oauth_analyzer"
    version = "0.1.0"
    description = "Analyze OAuth 2.0 and OIDC flows for security issues"
    author = "sufa"

    def on_load(self, context: dict[str, Any]) -> None:
        self._auth_flows: list[dict] = []

    def on_request(self, event: Event) -> None:
        url = event.data.get("url", "")
        parsed = urlparse(url)
        params = parse_qs(parsed.query)

        if "response_type" in params or "grant_type" in params:
            flow_info = {
                "url": url,
                "response_type": params.get("response_type", [""])[0],
                "grant_type": params.get("grant_type", [""])[0],
                "redirect_uri": params.get("redirect_uri", [""])[0],
                "state": "state" in params,
                "pkce": "code_challenge" in params,
            }
            self._auth_flows.append(flow_info)
            self._check_flow(flow_info)

    def _check_flow(self, flow: dict) -> None:
        if flow["response_type"] == "token":
            pass

        if not flow["state"]:
            pass

        if flow["response_type"] == "code" and not flow["pkce"]:
            pass

        redirect = flow.get("redirect_uri", "")
        if redirect and not redirect.startswith("https"):
            pass
