"""JWT Analyzer Plugin -- inspects JWT tokens in traffic for security issues."""

from __future__ import annotations

import base64
import json
from typing import Any

from sufa.core.events.events import Event
from sufa.core.plugins.interface import SufaPlugin


class JWTAnalyzerPlugin(SufaPlugin):
    name = "jwt_analyzer"
    version = "0.1.0"
    description = "Analyze JWT tokens in HTTP traffic for security weaknesses"
    author = "sufa"

    def on_load(self, context: dict[str, Any]) -> None:
        self._findings = []

    def on_response(self, event: Event) -> None:
        headers = event.data.get("headers", {})
        body = event.data.get("body", "")

        for key, value in headers.items():
            if "bearer" in value.lower():
                token = value.replace("Bearer ", "").replace("bearer ", "").strip()
                issues = self._analyze_jwt(token)
                if issues:
                    self._findings.extend(issues)

    def _analyze_jwt(self, token: str) -> list[dict]:
        issues = []
        parts = token.split(".")
        if len(parts) != 3:
            return []

        try:
            header_b64 = parts[0] + "=" * (4 - len(parts[0]) % 4)
            header = json.loads(base64.urlsafe_b64decode(header_b64))

            if header.get("alg") == "none":
                issues.append({
                    "title": "JWT with 'none' algorithm",
                    "severity": "critical",
                    "description": "JWT uses 'none' algorithm, allowing forged tokens",
                })

            if header.get("alg") in ("HS256", "HS384", "HS512"):
                issues.append({
                    "title": "JWT uses symmetric algorithm",
                    "severity": "info",
                    "description": f"JWT uses {header['alg']}. Ensure the secret is strong.",
                })

            payload_b64 = parts[1] + "=" * (4 - len(parts[1]) % 4)
            payload = json.loads(base64.urlsafe_b64decode(payload_b64))

            if "exp" not in payload:
                issues.append({
                    "title": "JWT missing expiration",
                    "severity": "medium",
                    "description": "JWT token has no expiration claim (exp)",
                })

        except Exception:
            pass

        return issues
