"""Tests for configuration management."""

from __future__ import annotations

from sufa.core.utils.config import SufaConfig


def test_config_defaults(tmp_path):
    config = SufaConfig(tmp_path / "test_config.json")
    assert config.provider == "ollama"
    assert config.model == "deepseek-r1:latest"
    assert config.max_tokens == 4096


def test_config_set_and_get(tmp_path):
    config = SufaConfig(tmp_path / "test_config.json")
    config.set("ai.provider", "openai")
    assert config.get("ai.provider") == "openai"
    assert config.provider == "openai"


def test_config_persistence(tmp_path):
    path = tmp_path / "test_config.json"
    config = SufaConfig(path)
    config.set("ai.model", "gpt-4o")

    config2 = SufaConfig(path)
    assert config2.model == "gpt-4o"


def test_config_type_coercion(tmp_path):
    config = SufaConfig(tmp_path / "test_config.json")
    config.set("ai.max_tokens", "8192")
    assert config.get("ai.max_tokens") == 8192

    config.set("redact.enabled", "true")
    assert config.get("redact.enabled") is True


def test_config_priority_chain(tmp_path):
    config = SufaConfig(tmp_path / "test_config.json")
    config.set("ai.priority", "claude,openai,ollama")
    assert config.priority_chain == ["claude", "openai", "ollama"]
