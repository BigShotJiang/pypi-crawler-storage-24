"""Tests for the event bus system."""

from __future__ import annotations

import pytest

from sufa.core.events import EventType
from sufa.core.events.events import (
    Event,
    FindingCreatedEvent,
    TrafficStoredEvent,
)


def test_event_creation():
    event = Event(event_type=EventType.REQUEST_RECEIVED, data={"url": "http://test.com"})
    assert event.event_type == EventType.REQUEST_RECEIVED
    assert event.data["url"] == "http://test.com"
    assert event.event_id
    assert event.timestamp


def test_typed_event():
    event = TrafficStoredEvent(data={"traffic_id": "abc123"}, source="test")
    assert event.event_type == EventType.TRAFFIC_STORED
    assert event.source == "test"


def test_subscribe_and_emit(event_bus):
    received = []
    event_bus.subscribe(EventType.FINDING_CREATED, lambda e: received.append(e))

    event = FindingCreatedEvent(data={"title": "XSS"}, source="scanner")
    event_bus.emit(event)

    assert len(received) == 1
    assert received[0].data["title"] == "XSS"


def test_subscribe_all(event_bus):
    received = []
    event_bus.subscribe_all(lambda e: received.append(e))

    event_bus.emit(TrafficStoredEvent(data={}, source="test"))
    event_bus.emit(FindingCreatedEvent(data={}, source="test"))

    assert len(received) == 2


def test_unsubscribe(event_bus):
    received = []

    def listener(e):
        received.append(e)

    event_bus.subscribe(EventType.FINDING_CREATED, listener)
    event_bus.emit(FindingCreatedEvent(data={}, source="test"))
    assert len(received) == 1

    event_bus.unsubscribe(EventType.FINDING_CREATED, listener)
    event_bus.emit(FindingCreatedEvent(data={}, source="test"))
    assert len(received) == 1


@pytest.mark.asyncio
async def test_async_emit(event_bus):
    received = []

    async def async_listener(event):
        received.append(event)

    event_bus.subscribe_async(EventType.TRAFFIC_STORED, async_listener)
    await event_bus.emit_async(TrafficStoredEvent(data={"id": "t1"}, source="test"))

    assert len(received) == 1


def test_error_in_listener_does_not_break(event_bus):
    received = []

    def bad_listener(e):
        raise ValueError("boom")

    def good_listener(e):
        received.append(e)

    event_bus.subscribe(EventType.FINDING_CREATED, bad_listener)
    event_bus.subscribe(EventType.FINDING_CREATED, good_listener)
    event_bus.emit(FindingCreatedEvent(data={}, source="test"))

    assert len(received) == 1
