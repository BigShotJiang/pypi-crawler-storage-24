"""Tests for Pydantic data models."""

from __future__ import annotations

from datetime import UTC

from sufa.core.models import (
    Confidence,
    Finding,
    HttpRequest,
    Project,
    Scan,
    Severity,
    TrafficEntry,
)


def test_finding_confidence_from_score():
    assert Finding.confidence_from_score(95) == Confidence.CERTAIN
    assert Finding.confidence_from_score(80) == Confidence.FIRM
    assert Finding.confidence_from_score(60) == Confidence.TENTATIVE


def test_finding_cwe_url():
    f = Finding(title="Test", cwe_id="CWE-89")
    assert f.cwe_url == "https://cwe.mitre.org/data/definitions/89.html"

    f2 = Finding(title="Test", cwe_id="")
    assert f2.cwe_url == ""


def test_traffic_entry_has_response():
    from sufa.core.models import HttpResponse

    entry = TrafficEntry(
        request=HttpRequest(method="GET", url="https://test.com"),
    )
    assert not entry.has_response

    entry.response = HttpResponse(status_code=200)
    assert entry.has_response


def test_scan_duration():
    from datetime import datetime, timedelta

    now = datetime.now(UTC)
    scan = Scan(target_url="https://test.com")
    assert scan.duration_seconds is None

    scan.started_at = now
    scan.finished_at = now + timedelta(seconds=42)
    assert scan.duration_seconds == 42.0


def test_project_creation():
    p = Project(name="Test")
    assert p.id
    assert p.name == "Test"
    assert p.created_at


def test_finding_serialization():
    f = Finding(title="XSS", severity="high", cwe_id="CWE-79")
    d = f.model_dump()
    assert d["title"] == "XSS"
    assert d["severity"] == Severity.HIGH
