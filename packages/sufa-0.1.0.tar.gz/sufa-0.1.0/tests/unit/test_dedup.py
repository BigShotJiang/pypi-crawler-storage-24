"""Tests for smart deduplication."""

from __future__ import annotations

from sufa.core.dedup import Deduplicator
from sufa.core.dedup.fingerprint import (
    endpoint_fingerprint,
    finding_fingerprint,
    normalize_path,
)


def test_normalize_path_numeric():
    assert normalize_path("/users/123/posts/456") == "/users/*/posts/*"


def test_normalize_path_uuid():
    assert normalize_path("/api/v1/550e8400-e29b-41d4-a716-446655440000") == "/api/v1/*"


def test_normalize_path_hex():
    assert normalize_path("/files/abcdef0123456789") == "/files/*"


def test_normalize_path_static():
    assert normalize_path("/api/v1/users") == "/api/v1/users"


def test_endpoint_fingerprint_same_pattern():
    fp1 = endpoint_fingerprint("GET", "https://example.com/users/123?page=1")
    fp2 = endpoint_fingerprint("GET", "https://example.com/users/456?page=2")
    assert fp1 == fp2


def test_endpoint_fingerprint_different_method():
    fp1 = endpoint_fingerprint("GET", "https://example.com/users/123")
    fp2 = endpoint_fingerprint("POST", "https://example.com/users/123")
    assert fp1 != fp2


def test_finding_fingerprint_same_vuln():
    fp1 = finding_fingerprint("https://example.com/users/123", "SQL Injection", "CWE-89", "id")
    fp2 = finding_fingerprint("https://example.com/users/456", "SQL Injection", "CWE-89", "id")
    assert fp1 == fp2


def test_finding_fingerprint_different_vuln():
    fp1 = finding_fingerprint("https://example.com/users/123", "SQL Injection", "CWE-89", "id")
    fp2 = finding_fingerprint("https://example.com/users/123", "XSS", "CWE-79", "id")
    assert fp1 != fp2


def test_deduplicator_flow():
    dedup = Deduplicator()

    assert dedup.should_analyze("GET", "https://example.com/users/1")
    dedup.mark_analyzed("GET", "https://example.com/users/1")

    assert not dedup.should_analyze("GET", "https://example.com/users/2")
    assert dedup.analyzed_count == 1


def test_deduplicator_finding():
    dedup = Deduplicator()

    assert not dedup.is_duplicate_finding("https://example.com/users", "XSS", "CWE-79", "name")
    fp = dedup.register_finding("https://example.com/users", "XSS", "CWE-79", "name")
    assert fp
    assert dedup.is_duplicate_finding("https://example.com/users", "XSS", "CWE-79", "name")


def test_deduplicator_reset():
    dedup = Deduplicator()
    dedup.mark_analyzed("GET", "https://example.com/test")
    dedup.register_finding("https://example.com/test", "Test", "CWE-1", "x")
    assert dedup.analyzed_count == 1
    assert dedup.findings_count == 1

    dedup.reset()
    assert dedup.analyzed_count == 0
    assert dedup.findings_count == 0
