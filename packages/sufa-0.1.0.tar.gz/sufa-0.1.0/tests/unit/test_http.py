"""Tests for HTTP normalization and redaction."""

from __future__ import annotations

from sufa.core.http.normalizer import normalize_body, normalize_request_body
from sufa.core.http.redactor import redact_body, redact_headers, redact_url


def test_normalize_truncates():
    long_body = "Hello world! This is a normal text body. " * 200
    result = normalize_request_body(long_body)
    assert len(result) < len(long_body)
    assert "truncated" in result


def test_normalize_binary_detection():
    binary = "\x00\x01\x02\x03" * 100
    result = normalize_body(binary, 1000)
    assert "Binary" in result or "binary" in result.lower()


def test_redact_headers():
    headers = {
        "content-type": "application/json",
        "authorization": "Bearer secret_token_here",
        "cookie": "session=abc123",
        "x-custom": "safe value",
    }
    result = redact_headers(headers)
    assert result["authorization"] == "***REDACTED***"
    assert result["cookie"] == "***REDACTED***"
    assert result["x-custom"] == "safe value"
    assert result["content-type"] == "application/json"


def test_redact_headers_custom_pattern():
    headers = {"x-my-secret": "value"}
    result = redact_headers(headers, extra_patterns=["x-my-secret"])
    assert result["x-my-secret"] == "***REDACTED***"


def test_redact_body_json():
    body = '{"username": "admin", "password": "secret123", "action": "login"}'
    result = redact_body(body)
    assert "secret123" not in result
    assert "REDACTED" in result
    assert "admin" in result


def test_redact_body_form():
    body = "username=admin&password=secret123&action=login"
    result = redact_body(body)
    assert "secret123" not in result
    assert "REDACTED" in result


def test_redact_url():
    url = "https://api.example.com/auth?token=secret123&user=admin"
    result = redact_url(url)
    assert "secret123" not in result
    assert "REDACTED" in result
    assert "user=admin" in result


def test_redact_url_no_params():
    url = "https://example.com/path"
    result = redact_url(url)
    assert result == url
