"""Tests for the database repository."""

from __future__ import annotations


def test_save_and_get_project(repo, sample_project):
    repo.save_project(sample_project)
    loaded = repo.get_project(sample_project.id)
    assert loaded is not None
    assert loaded.name == sample_project.name


def test_list_projects(repo, sample_project):
    repo.save_project(sample_project)
    projects = repo.list_projects()
    assert len(projects) >= 1
    assert any(p.id == sample_project.id for p in projects)


def test_delete_project(repo, sample_project):
    repo.save_project(sample_project)
    assert repo.delete_project(sample_project.id)
    assert repo.get_project(sample_project.id) is None
    assert not repo.delete_project("nonexistent")


def test_save_and_get_scan(repo, sample_scan):
    repo.save_scan(sample_scan)
    loaded = repo.get_scan(sample_scan.id)
    assert loaded is not None
    assert loaded.target_url == sample_scan.target_url


def test_save_and_get_traffic(repo, sample_traffic):
    repo.save_traffic(sample_traffic)
    loaded = repo.get_traffic(sample_traffic.id)
    assert loaded is not None
    assert loaded.request.url == sample_traffic.request.url


def test_save_and_get_finding(repo, sample_finding):
    repo.save_finding(sample_finding)
    loaded = repo.get_finding(sample_finding.id)
    assert loaded is not None
    assert loaded.title == "SQL Injection"
    assert loaded.severity.value == "high"


def test_list_findings_filter(repo, sample_finding):
    repo.save_finding(sample_finding)
    all_findings = repo.list_findings()
    assert len(all_findings) >= 1

    high = repo.list_findings(severity="high")
    assert len(high) >= 1

    low = repo.list_findings(severity="low")
    assert all(f.severity.value == "low" for f in low)


def test_find_by_fingerprint(repo, sample_finding):
    sample_finding.fingerprint = "test_fp_123"
    repo.save_finding(sample_finding)

    found = repo.find_by_fingerprint("test_fp_123")
    assert found is not None
    assert found.id == sample_finding.id

    assert repo.find_by_fingerprint("nonexistent") is None


def test_update_finding_status(repo, sample_finding):
    repo.save_finding(sample_finding)
    assert repo.update_finding_status(sample_finding.id, "confirmed")

    loaded = repo.get_finding(sample_finding.id)
    assert loaded.status.value == "confirmed"


def test_log_ai_call(repo):
    repo.log_ai_call(
        provider="ollama",
        model="test",
        scan_id="s1",
        prompt_tokens=100,
        completion_tokens=50,
        latency_ms=500.0,
    )
