"""Shared test fixtures for sufa tests."""

from __future__ import annotations

import pytest

from sufa.core.db.engine import init_db
from sufa.core.db.repository import Repository
from sufa.core.events import EventBus
from sufa.core.models import (
    Finding,
    HttpRequest,
    HttpResponse,
    Project,
    Scan,
    TrafficEntry,
)


@pytest.fixture
def tmp_db(tmp_path):
    db_path = tmp_path / "test.db"
    init_db(db_path)
    return db_path


@pytest.fixture
def repo(tmp_db):
    r = Repository()
    yield r
    r.close()


@pytest.fixture
def event_bus():
    bus = EventBus()
    yield bus
    bus.clear()


@pytest.fixture
def sample_request():
    return HttpRequest(
        method="GET",
        url="https://example.com/api/users?id=123",
        path="/api/users",
        host="example.com",
        scheme="https",
        headers={"content-type": "application/json", "authorization": "Bearer secret123"},
        body="",
    )


@pytest.fixture
def sample_response():
    return HttpResponse(
        status_code=200,
        headers={"content-type": "application/json"},
        body='{"id": 123, "name": "John", "email": "john@example.com"}',
        content_type="application/json",
        content_length=57,
    )


@pytest.fixture
def sample_traffic(sample_request, sample_response):
    return TrafficEntry(
        request=sample_request,
        response=sample_response,
        source="test",
    )


@pytest.fixture
def sample_finding():
    return Finding(
        title="SQL Injection",
        description="User input not sanitized",
        severity="high",
        confidence="firm",
        confidence_score=80,
        cwe_id="CWE-89",
        owasp_category="Injection",
        url="https://example.com/api/users?id=123",
        parameter="id",
        evidence="id=123' OR 1=1--",
        remediation="Use parameterized queries",
    )


@pytest.fixture
def sample_project():
    return Project(name="Test Project", description="A test project")


@pytest.fixture
def sample_scan():
    return Scan(target_url="https://example.com", scan_type="passive")
