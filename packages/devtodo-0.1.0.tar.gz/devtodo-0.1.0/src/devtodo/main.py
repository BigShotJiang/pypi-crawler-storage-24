from typing import Optional
import typer
from rich.console import Console
from datetime import date

from devtodo.db import init_db, get_session
from devtodo.services.todo_service import TodoService
from devtodo.utils.output import success, error, print_todos, print_todo
from devtodo.utils.dates import parse_date

app = typer.Typer(
    name="devtodo",
    help="[bold]devtodo[/bold] – a developer-focused CLI todo tool.",
    rich_markup_mode="rich",
    no_args_is_help=True,
)

console = Console()


@app.command("add")
def cmd_add(
    title: str = typer.Argument(..., help="Title of the todo"),
    description: Optional[str] = typer.Option(None, "--desc", "-d", help="Optional description"),
    priority: str = typer.Option("medium", "--priority", "-p", help="Priority: low, medium, high"),
    project: Optional[str] = typer.Option(None, "--project", "-P", help="Project name"),
    tags: Optional[str] = typer.Option(None, "--tags", "-t", help="Comma-separated tags"),
    due: Optional[str] = typer.Option(None, "--due", help="Due date (YYYY-MM-DD)"),
) -> None:
    """Add a new todo."""
    if priority not in ("low", "medium", "high"):
        error(f"Invalid priority '{priority}'. Use: low, medium, high")
        raise typer.Exit(1)

    due_date = None
    if due:
        try:
            due_date = parse_date(due)
        except ValueError as e:
            error(str(e))
            raise typer.Exit(1)

    engine = init_db()
    with get_session(engine) as session:
        service = TodoService(session)
        todo = service.add(
            title=title,
            description=description,
            priority=priority,
            project=project,
            tags=tags,
            due_date=due_date,
        )
    success(f"Added todo [bold]#{todo.id}[/bold]: {todo.title}")
    print_todo(todo)


@app.command("list")
def cmd_list(
    status: Optional[str] = typer.Option(None, "--status", "-s", help="Filter: open, done, in_progress"),
    project: Optional[str] = typer.Option(None, "--project", "-P", help="Filter by project"),
    priority: Optional[str] = typer.Option(None, "--priority", "-p", help="Filter by priority"),
    tag: Optional[str] = typer.Option(None, "--tag", "-t", help="Filter by tag"),
) -> None:
    """List todos."""
    engine = init_db()
    with get_session(engine) as session:
        service = TodoService(session)
        todos = service.list_todos(status=status, project=project, priority=priority, tag=tag)
    print_todos(todos)


@app.command("done")
def cmd_done(
    todo_id: int = typer.Argument(..., help="ID of the todo to mark as done"),
) -> None:
    """Mark a todo as done."""
    engine = init_db()
    with get_session(engine) as session:
        service = TodoService(session)
        todo = service.mark_done(todo_id)

    if todo:
        success(f"Todo [bold]#{todo.id}[/bold] marked as done: {todo.title}")
    else:
        error(f"Todo #{todo_id} not found.")
        raise typer.Exit(1)


@app.command("remove")
def cmd_remove(
    todo_id: int = typer.Argument(..., help="ID of the todo to remove"),
    force: bool = typer.Option(False, "--force", "-f", help="Skip confirmation"),
) -> None:
    """Remove a todo."""
    engine = init_db()
    with get_session(engine) as session:
        service = TodoService(session)
        todo = service.get(todo_id)
        if not todo:
            error(f"Todo #{todo_id} not found.")
            raise typer.Exit(1)

        if not force:
            typer.confirm(f"Remove todo #{todo_id}: '{todo.title}'?", abort=True)

        service.remove(todo_id)

    success(f"Todo #{todo_id} removed.")


@app.command("edit")
def cmd_edit(
    todo_id: int = typer.Argument(..., help="ID of the todo to edit"),
    title: Optional[str] = typer.Option(None, "--title", help="New title"),
    description: Optional[str] = typer.Option(None, "--desc", "-d", help="New description"),
    status: Optional[str] = typer.Option(None, "--status", "-s", help="New status: open, done, in_progress"),
    priority: Optional[str] = typer.Option(None, "--priority", "-p", help="New priority: low, medium, high"),
    project: Optional[str] = typer.Option(None, "--project", "-P", help="New project"),
    tags: Optional[str] = typer.Option(None, "--tags", "-t", help="New tags (comma-separated)"),
    due: Optional[str] = typer.Option(None, "--due", help="New due date (YYYY-MM-DD)"),
) -> None:
    """Edit a todo."""
    if priority and priority not in ("low", "medium", "high"):
        error(f"Invalid priority '{priority}'. Use: low, medium, high")
        raise typer.Exit(1)
    if status and status not in ("open", "done", "in_progress"):
        error(f"Invalid status '{status}'. Use: open, done, in_progress")
        raise typer.Exit(1)

    due_date = None
    if due:
        try:
            due_date = parse_date(due)
        except ValueError as e:
            error(str(e))
            raise typer.Exit(1)

    engine = init_db()
    with get_session(engine) as session:
        service = TodoService(session)
        todo = service.edit(
            todo_id=todo_id,
            title=title,
            description=description,
            status=status,
            priority=priority,
            project=project,
            tags=tags,
            due_date=due_date,
        )

    if todo:
        success(f"Todo [bold]#{todo.id}[/bold] updated.")
        print_todo(todo)
    else:
        error(f"Todo #{todo_id} not found.")
        raise typer.Exit(1)


@app.command("clear")
def cmd_clear(
    force: bool = typer.Option(False, "--force", "-f", help="Skip confirmation"),
) -> None:
    """Delete ALL todos. Cannot be undone!"""
    engine = init_db()
    with get_session(engine) as session:
        service = TodoService(session)
        count = service.list_todos().__len__()

    if count == 0:
        console.print("[dim]No todos to delete.[/dim]")
        raise typer.Exit()

    if not force:
        console.print(f"[bold red]⚠ This will delete ALL {count} todo(s). This cannot be undone![/bold red]")
        typer.confirm("Are you sure?", abort=True)

    engine = init_db()
    with get_session(engine) as session:
        service = TodoService(session)
        service.clear_all()

    success(f"Deleted all {count} todo(s). Database is now empty.")


def cmd_clear_completed(
    force: bool = typer.Option(False, "--force", "-f", help="Skip confirmation"),
) -> None:
    """Remove all completed todos."""
    if not force:
        typer.confirm("Remove all completed todos?", abort=True)

    engine = init_db()
    with get_session(engine) as session:
        service = TodoService(session)
        count = service.clear_completed()

    success(f"Removed {count} completed todo(s).")


@app.command("start")
def cmd_start() -> None:
    """Launch the interactive TUI."""
    from devtodo.tui import run_tui
    run_tui()


def cmd_today() -> None:
    """Show high-priority todos and todos due today."""
    today_date = date.today()

    engine = init_db()
    with get_session(engine) as session:
        service = TodoService(session)
        all_todos = service.list_todos(status="open")

    focused = [
        t for t in all_todos
        if t.priority == "high"
        or (t.due_date and t.due_date.date() <= today_date)
    ]

    console.print("[bold]📅 Today's focus[/bold]")
    print_todos(focused)


if __name__ == "__main__":
    app()

