"""devtodo – a developer-focused CLI todo tool."""

__version__ = "0.1.0"
