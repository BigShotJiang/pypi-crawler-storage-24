from textual.app import App, ComposeResult
from textual.widgets import (
    Header, Footer, DataTable, Input, Label, Button, Static
)
from textual.containers import Vertical, Horizontal, Container
from textual.screen import ModalScreen
from textual.binding import Binding
from textual import events
from rich.text import Text

from devtodo.db import init_db, get_session
from devtodo.services.todo_service import TodoService
from devtodo.models import Todo


PRIORITY_STYLE = {
    "high":   ("red",    "●"),
    "medium": ("yellow", "●"),
    "low":    ("green",  "●"),
}

STATUS_STYLE = {
    "open":        ("cyan",      "○"),
    "in_progress": ("blue",      "◑"),
    "done":        ("dim green", "✔"),
}


class AddTodoModal(ModalScreen):
    """Modal dialog to add a new todo."""

    BINDINGS = [("escape", "dismiss", "Cancel")]

    def compose(self) -> ComposeResult:
        with Vertical(id="modal-box"):
            yield Label("➕ Add new todo", id="modal-title")
            yield Input(placeholder="Title *", id="input-title")
            yield Input(placeholder="Description (optional)", id="input-desc")
            yield Input(placeholder="Priority: low / medium / high  (default: medium)", id="input-priority")
            yield Input(placeholder="Project (optional)", id="input-project")
            yield Input(placeholder="Tags, comma-separated (optional)", id="input-tags")
            with Horizontal(id="modal-buttons"):
                yield Button("Add", variant="success", id="btn-add")
                yield Button("Cancel", variant="default", id="btn-cancel")

    def on_button_pressed(self, event: Button.Pressed) -> None:
        if event.button.id == "btn-cancel":
            self.dismiss(None)
            return

        title = self.query_one("#input-title", Input).value.strip()
        if not title:
            self.query_one("#input-title", Input).focus()
            return

        priority = self.query_one("#input-priority", Input).value.strip() or "medium"
        if priority not in ("low", "medium", "high"):
            priority = "medium"

        self.dismiss({
            "title":       title,
            "description": self.query_one("#input-desc", Input).value.strip() or None,
            "priority":    priority,
            "project":     self.query_one("#input-project", Input).value.strip() or None,
            "tags":        self.query_one("#input-tags", Input).value.strip() or None,
        })

    def on_input_submitted(self, event: Input.Submitted) -> None:
        # pressing Enter in any field triggers add
        self.query_one("#btn-add", Button).press()


class DevtodoTUI(App):
    """devtodo – Terminal UI"""

    CSS = """
    Screen {
        background: $surface;
    }

    #main-table {
        height: 1fr;
    }

    #status-bar {
        height: 1;
        padding: 0 1;
        background: $panel;
        color: $text-muted;
    }

    /* Modal */
    AddTodoModal {
        align: center middle;
    }

    #modal-box {
        width: 60;
        height: auto;
        border: round $primary;
        background: $surface;
        padding: 1 2;
    }

    #modal-box Input {
        margin-bottom: 1;
    }

    #modal-title {
        text-style: bold;
        color: $primary;
        margin-bottom: 1;
    }

    #modal-buttons {
        height: auto;
        margin-top: 1;
    }

    #btn-add {
        margin-right: 2;
    }
    """

    BINDINGS = [
        Binding("a",      "add_todo",      "Add",      show=True),
        Binding("d",      "mark_done",     "Done",     show=True),
        Binding("delete", "remove_todo",   "Remove",   show=True),
        Binding("r",      "refresh",       "Refresh",  show=True),
        Binding("q",      "quit",          "Quit",     show=True),
        Binding("f",      "filter_open",   "Open only",show=True),
        Binding("F",      "filter_all",    "All",      show=True),
    ]

    def __init__(self):
        super().__init__()
        self.engine = init_db()
        self._filter_status = None  # None = all
        self._todos: list[Todo] = []

    def compose(self) -> ComposeResult:
        yield Header(show_clock=True)
        yield DataTable(id="main-table", cursor_type="row", zebra_stripes=True)
        yield Static("", id="status-bar")
        yield Footer()

    def on_mount(self) -> None:
        self.title = "devtodo"
        self.sub_title = "press [a] add · [d] done · [del] remove · [q] quit"
        table = self.query_one(DataTable)
        table.add_columns("ID", "●", "Title", "Status", "Priority", "Project", "Tags")
        self._load_todos()

    def _load_todos(self) -> None:
        with get_session(self.engine) as session:
            service = TodoService(session)
            self._todos = service.list_todos(status=self._filter_status)

        table = self.query_one(DataTable)
        table.clear()

        for todo in self._todos:
            p_color, p_dot = PRIORITY_STYLE.get(todo.priority, ("white", "●"))
            s_color, s_icon = STATUS_STYLE.get(todo.status, ("white", "?"))

            table.add_row(
                Text(str(todo.id), style="dim"),
                Text(p_dot, style=p_color),
                Text(todo.title),
                Text(f"{s_icon} {todo.status}", style=s_color),
                Text(todo.priority, style=p_color),
                Text(todo.project or "", style="blue"),
                Text(todo.tags or "", style="magenta"),
                key=str(todo.id),
            )

        self._update_status_bar()

    def _update_status_bar(self) -> None:
        total = len(self._todos)
        done  = sum(1 for t in self._todos if t.status == "done")
        open_ = sum(1 for t in self._todos if t.status == "open")
        filt  = f"  [filter: open only]" if self._filter_status else ""
        self.query_one("#status-bar", Static).update(
            f" {total} todos · {open_} open · {done} done{filt}"
        )

    def _current_todo(self) -> Todo | None:
        table = self.query_one(DataTable)
        if table.cursor_row < 0 or not self._todos:
            return None
        try:
            return self._todos[table.cursor_row]
        except IndexError:
            return None

    # ── Actions ─────────────────────────────────────────────────────────────

    def action_add_todo(self) -> None:
        def handle_result(data: dict | None) -> None:
            if not data:
                return
            with get_session(self.engine) as session:
                TodoService(session).add(**data)
            self._load_todos()

        self.push_screen(AddTodoModal(), handle_result)

    def action_mark_done(self) -> None:
        todo = self._current_todo()
        if not todo:
            return
        with get_session(self.engine) as session:
            TodoService(session).mark_done(todo.id)
        self._load_todos()

    def action_remove_todo(self) -> None:
        todo = self._current_todo()
        if not todo:
            return
        with get_session(self.engine) as session:
            TodoService(session).remove(todo.id)
        self._load_todos()

    def action_refresh(self) -> None:
        self._load_todos()

    def action_filter_open(self) -> None:
        self._filter_status = "open"
        self._load_todos()

    def action_filter_all(self) -> None:
        self._filter_status = None
        self._load_todos()


def run_tui() -> None:
    DevtodoTUI().run()
