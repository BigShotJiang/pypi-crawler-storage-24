from datetime import datetime
from typing import Optional
from sqlmodel import select, Session

from devtodo.models import Todo


class TodoService:
    def __init__(self, session: Session):
        self.session = session

    def add(
        self,
        title: str,
        description: Optional[str] = None,
        priority: str = "medium",
        project: Optional[str] = None,
        tags: Optional[str] = None,
        due_date: Optional[datetime] = None,
    ) -> Todo:
        todo = Todo(
            title=title,
            description=description,
            priority=priority,
            project=project,
            tags=tags,
            due_date=due_date,
        )
        self.session.add(todo)
        self.session.commit()
        self.session.refresh(todo)
        return todo

    def list_todos(
        self,
        status: Optional[str] = None,
        project: Optional[str] = None,
        priority: Optional[str] = None,
        tag: Optional[str] = None,
    ) -> list[Todo]:
        statement = select(Todo)
        if status:
            statement = statement.where(Todo.status == status)
        if project:
            statement = statement.where(Todo.project == project)
        if priority:
            statement = statement.where(Todo.priority == priority)
        if tag:
            statement = statement.where(Todo.tags.contains(tag))
        statement = statement.order_by(Todo.id)
        return list(self.session.exec(statement).all())

    def get(self, todo_id: int) -> Optional[Todo]:
        return self.session.get(Todo, todo_id)

    def mark_done(self, todo_id: int) -> Optional[Todo]:
        todo = self.get(todo_id)
        if todo:
            todo.status = "done"
            self.session.add(todo)
            self.session.commit()
            self.session.refresh(todo)
        return todo

    def remove(self, todo_id: int) -> bool:
        todo = self.get(todo_id)
        if todo:
            self.session.delete(todo)
            self.session.commit()
            return True
        return False

    def edit(
        self,
        todo_id: int,
        title: Optional[str] = None,
        description: Optional[str] = None,
        status: Optional[str] = None,
        priority: Optional[str] = None,
        project: Optional[str] = None,
        tags: Optional[str] = None,
        due_date: Optional[datetime] = None,
    ) -> Optional[Todo]:
        todo = self.get(todo_id)
        if not todo:
            return None
        if title is not None:
            todo.title = title
        if description is not None:
            todo.description = description
        if status is not None:
            todo.status = status
        if priority is not None:
            todo.priority = priority
        if project is not None:
            todo.project = project
        if tags is not None:
            todo.tags = tags
        if due_date is not None:
            todo.due_date = due_date
        self.session.add(todo)
        self.session.commit()
        self.session.refresh(todo)
        return todo

    def clear_completed(self) -> int:
        todos = self.list_todos(status="done")
        for todo in todos:
            self.session.delete(todo)
        self.session.commit()
        return len(todos)

    def clear_all(self) -> int:
        todos = self.list_todos()
        for todo in todos:
            self.session.delete(todo)
        self.session.commit()
        return len(todos)
