from typing import Optional
import typer
from devtodo.db import init_db, get_session
from devtodo.services.todo_service import TodoService
from devtodo.utils.output import print_todos

app = typer.Typer(help="List todos.")


@app.callback(invoke_without_command=True)
def list_todos(
    status: Optional[str] = typer.Option(None, "--status", "-s", help="Filter by status (open, done, in_progress)"),
    project: Optional[str] = typer.Option(None, "--project", "-P", help="Filter by project"),
    priority: Optional[str] = typer.Option(None, "--priority", "-p", help="Filter by priority"),
    tag: Optional[str] = typer.Option(None, "--tag", "-t", help="Filter by tag"),
) -> None:
    engine = init_db()
    with get_session(engine) as session:
        service = TodoService(session)
        todos = service.list_todos(status=status, project=project, priority=priority, tag=tag)
    print_todos(todos)
