import typer
from devtodo.db import init_db, get_session
from devtodo.services.todo_service import TodoService
from devtodo.utils.output import success, error

app = typer.Typer(help="Mark a todo as done.")


@app.callback(invoke_without_command=True)
def done(
    todo_id: int = typer.Argument(..., help="ID of the todo to mark as done"),
) -> None:
    engine = init_db()
    with get_session(engine) as session:
        service = TodoService(session)
        todo = service.mark_done(todo_id)

    if todo:
        success(f"Todo [bold]#{todo.id}[/bold] marked as done: {todo.title}")
    else:
        error(f"Todo #{todo_id} not found.")
        raise typer.Exit(1)
