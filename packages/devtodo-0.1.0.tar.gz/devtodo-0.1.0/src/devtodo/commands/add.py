from typing import Optional
import typer
from devtodo.db import init_db, get_session
from devtodo.services.todo_service import TodoService
from devtodo.utils.output import success, error, print_todo
from devtodo.utils.dates import parse_date

app = typer.Typer(help="Add a new todo.")


@app.callback(invoke_without_command=True)
def add(
    title: str = typer.Argument(..., help="Title of the todo"),
    description: Optional[str] = typer.Option(None, "--desc", "-d", help="Optional description"),
    priority: str = typer.Option("medium", "--priority", "-p", help="Priority: low, medium, high"),
    project: Optional[str] = typer.Option(None, "--project", "-P", help="Project name"),
    tags: Optional[str] = typer.Option(None, "--tags", "-t", help="Comma-separated tags"),
    due: Optional[str] = typer.Option(None, "--due", help="Due date (YYYY-MM-DD)"),
) -> None:
    if priority not in ("low", "medium", "high"):
        error(f"Invalid priority '{priority}'. Use: low, medium, high")
        raise typer.Exit(1)

    due_date = None
    if due:
        try:
            due_date = parse_date(due)
        except ValueError as e:
            error(str(e))
            raise typer.Exit(1)

    engine = init_db()
    with get_session(engine) as session:
        service = TodoService(session)
        todo = service.add(
            title=title,
            description=description,
            priority=priority,
            project=project,
            tags=tags,
            due_date=due_date,
        )
    success(f"Added todo [bold]#{todo.id}[/bold]: {todo.title}")
    print_todo(todo)
