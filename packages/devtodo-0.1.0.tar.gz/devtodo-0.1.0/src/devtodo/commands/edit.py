from typing import Optional
import typer
from devtodo.db import init_db, get_session
from devtodo.services.todo_service import TodoService
from devtodo.utils.output import success, error, print_todo
from devtodo.utils.dates import parse_date

app = typer.Typer(help="Edit a todo.")


@app.callback(invoke_without_command=True)
def edit(
    todo_id: int = typer.Argument(..., help="ID of the todo to edit"),
    title: Optional[str] = typer.Option(None, "--title", help="New title"),
    description: Optional[str] = typer.Option(None, "--desc", "-d", help="New description"),
    status: Optional[str] = typer.Option(None, "--status", "-s", help="New status: open, done, in_progress"),
    priority: Optional[str] = typer.Option(None, "--priority", "-p", help="New priority: low, medium, high"),
    project: Optional[str] = typer.Option(None, "--project", "-P", help="New project"),
    tags: Optional[str] = typer.Option(None, "--tags", "-t", help="New tags (comma-separated)"),
    due: Optional[str] = typer.Option(None, "--due", help="New due date (YYYY-MM-DD)"),
) -> None:
    if priority and priority not in ("low", "medium", "high"):
        error(f"Invalid priority '{priority}'. Use: low, medium, high")
        raise typer.Exit(1)
    if status and status not in ("open", "done", "in_progress"):
        error(f"Invalid status '{status}'. Use: open, done, in_progress")
        raise typer.Exit(1)

    due_date = None
    if due:
        try:
            due_date = parse_date(due)
        except ValueError as e:
            error(str(e))
            raise typer.Exit(1)

    engine = init_db()
    with get_session(engine) as session:
        service = TodoService(session)
        todo = service.edit(
            todo_id=todo_id,
            title=title,
            description=description,
            status=status,
            priority=priority,
            project=project,
            tags=tags,
            due_date=due_date,
        )

    if todo:
        success(f"Todo [bold]#{todo.id}[/bold] updated.")
        print_todo(todo)
    else:
        error(f"Todo #{todo_id} not found.")
        raise typer.Exit(1)
