"""devtodo github – GitHub Issue integration commands."""

from typing import Optional
import typer
from rich.console import Console

from devtodo.db import init_db, get_session
from devtodo.services.todo_service import TodoService
from devtodo.utils.output import success, error, print_todos

app = typer.Typer(help="GitHub Issue integration.")
console = Console()


def _require_repo(repo: Optional[str]) -> str:
    if not repo:
        error("Provide --repo owner/reponame  e.g. --repo torvalds/linux")
        raise typer.Exit(1)
    if "/" not in repo:
        error("--repo must be in format  owner/reponame")
        raise typer.Exit(1)
    return repo


@app.command("sync")
def sync(
    repo: Optional[str] = typer.Option(None, "--repo", "-r", help="GitHub repo (owner/name)"),
    state: str = typer.Option("open", "--state", "-s", help="Issue state: open / closed / all"),
    limit: int = typer.Option(50, "--limit", "-n", help="Max issues to fetch"),
) -> None:
    """Import GitHub Issues as todos."""
    from devtodo.github_client import fetch_issues
    repo = _require_repo(repo)

    console.print(f"[dim]Fetching {state} issues from [bold]{repo}[/bold]...[/dim]")
    try:
        issues = fetch_issues(repo, state=state, limit=limit)
    except Exception as e:
        error(f"GitHub API error: {e}")
        raise typer.Exit(1)

    if not issues:
        console.print("[dim]No issues found.[/dim]")
        return

    engine = init_db()
    added = 0
    skipped = 0
    with get_session(engine) as session:
        service = TodoService(session)
        existing_urls = {t.github_url for t in service.list_todos() if t.github_url}

        for issue in issues:
            url = issue["html_url"]
            if url in existing_urls:
                skipped += 1
                continue
            service.add(
                title=issue["title"],
                description=issue.get("body") or None,
                github_url=url,
                github_issue_number=issue["number"],
            )
            added += 1

    success(f"Imported {added} issue(s) from [bold]{repo}[/bold]  ({skipped} already existed).")


@app.command("push")
def push(
    todo_id: int = typer.Argument(..., help="Todo ID to push as GitHub Issue"),
    repo: Optional[str] = typer.Option(None, "--repo", "-r", help="GitHub repo (owner/name)"),
) -> None:
    """Push a todo as a new GitHub Issue."""
    from devtodo.github_client import create_issue
    repo = _require_repo(repo)

    engine = init_db()
    with get_session(engine) as session:
        service = TodoService(session)
        todo = service.get(todo_id)
        if not todo:
            error(f"Todo #{todo_id} not found.")
            raise typer.Exit(1)

        if todo.github_url:
            error(f"Todo #{todo_id} is already linked to: {todo.github_url}")
            raise typer.Exit(1)

        console.print(f"[dim]Creating issue in [bold]{repo}[/bold]...[/dim]")
        try:
            issue = create_issue(repo, title=todo.title, body=todo.description)
        except Exception as e:
            error(f"GitHub API error: {e}")
            raise typer.Exit(1)

        service.edit(
            todo_id=todo_id,
            github_url=issue["html_url"],
            github_issue_number=issue["number"],
        )

    success(f"Issue created: [link={issue['html_url']}]{issue['html_url']}[/link]")


@app.command("list")
def list_linked() -> None:
    """List todos that are linked to GitHub Issues."""
    engine = init_db()
    with get_session(engine) as session:
        service = TodoService(session)
        todos = [t for t in service.list_todos() if t.github_url]

    if not todos:
        console.print("[dim]No todos linked to GitHub Issues.[/dim]")
        return

    print_todos(todos)
    for t in todos:
        console.print(f"  #{t.id} → [dim]{t.github_url}[/dim]")
