import typer
from devtodo.db import init_db, get_session
from devtodo.services.todo_service import TodoService
from devtodo.utils.output import success, error

app = typer.Typer(help="Remove a todo.")


@app.callback(invoke_without_command=True)
def remove(
    todo_id: int = typer.Argument(..., help="ID of the todo to remove"),
    force: bool = typer.Option(False, "--force", "-f", help="Skip confirmation"),
) -> None:
    engine = init_db()
    with get_session(engine) as session:
        service = TodoService(session)
        todo = service.get(todo_id)
        if not todo:
            error(f"Todo #{todo_id} not found.")
            raise typer.Exit(1)

        if not force:
            typer.confirm(f"Remove todo #{todo_id}: '{todo.title}'?", abort=True)

        service.remove(todo_id)

    success(f"Todo #{todo_id} removed.")
