from pathlib import Path
from sqlmodel import SQLModel, create_engine, Session

DB_PATH = Path.home() / ".devtodo" / "devtodo.db"


def get_engine():
    DB_PATH.parent.mkdir(parents=True, exist_ok=True)
    return create_engine(f"sqlite:///{DB_PATH}", connect_args={"check_same_thread": False})


def init_db(engine=None):
    from devtodo.models import Todo  # noqa: F401 – registers the table
    if engine is None:
        engine = get_engine()
    SQLModel.metadata.create_all(engine)
    _migrate(engine)
    return engine


def _migrate(engine) -> None:
    """Add new columns to existing databases without Alembic."""
    new_columns = [
        ("github_url", "TEXT"),
        ("github_issue_number", "INTEGER"),
    ]
    with engine.connect() as conn:
        for col, col_type in new_columns:
            try:
                conn.exec_driver_sql(f"ALTER TABLE todo ADD COLUMN {col} {col_type}")
                conn.commit()
            except Exception:
                pass  # column already exists


def get_session(engine=None):
    if engine is None:
        engine = get_engine()
    return Session(engine)
