from datetime import datetime
from rich.console import Console
from rich.table import Table
from rich import box
from devtodo.models import Todo

console = Console()

PRIORITY_COLORS = {
    "high": "red",
    "medium": "yellow",
    "low": "green",
}

STATUS_COLORS = {
    "open": "cyan",
    "done": "dim green",
    "in_progress": "blue",
}


def _priority_badge(priority: str) -> str:
    color = PRIORITY_COLORS.get(priority, "white")
    return f"[{color}]{priority}[/{color}]"


def _status_badge(status: str) -> str:
    color = STATUS_COLORS.get(status, "white")
    return f"[{color}]{status}[/{color}]"


def print_todos(todos: list[Todo]) -> None:
    if not todos:
        console.print("[dim]No todos found.[/dim]")
        return

    table = Table(box=box.ROUNDED, show_header=True, header_style="bold magenta")
    table.add_column("ID", style="bold", justify="right", width=4)
    table.add_column("Title", min_width=20)
    table.add_column("Status", width=12)
    table.add_column("Priority", width=10)
    table.add_column("Project", width=12)
    table.add_column("Tags", width=14)
    table.add_column("Due", width=11)

    for todo in todos:
        due = todo.due_date.strftime("%Y-%m-%d") if todo.due_date else ""
        table.add_row(
            str(todo.id),
            todo.title,
            _status_badge(todo.status),
            _priority_badge(todo.priority),
            todo.project or "",
            todo.tags or "",
            due,
        )

    console.print(table)


def print_todo(todo: Todo) -> None:
    console.print(f"[bold]#{todo.id}[/bold] {todo.title}")
    if todo.description:
        console.print(f"  [dim]{todo.description}[/dim]")
    console.print(f"  Status:   {_status_badge(todo.status)}")
    console.print(f"  Priority: {_priority_badge(todo.priority)}")
    if todo.project:
        console.print(f"  Project:  [blue]{todo.project}[/blue]")
    if todo.tags:
        console.print(f"  Tags:     [magenta]{todo.tags}[/magenta]")
    if todo.due_date:
        console.print(f"  Due:      {todo.due_date.strftime('%Y-%m-%d')}")


def success(msg: str) -> None:
    console.print(f"[bold green]✔[/bold green] {msg}")


def error(msg: str) -> None:
    console.print(f"[bold red]✘[/bold red] {msg}")
