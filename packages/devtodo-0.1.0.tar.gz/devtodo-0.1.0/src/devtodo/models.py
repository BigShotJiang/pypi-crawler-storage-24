from datetime import datetime
from typing import Optional
from sqlmodel import SQLModel, Field


class Todo(SQLModel, table=True):
    id: Optional[int] = Field(default=None, primary_key=True)
    title: str
    description: Optional[str] = None
    status: str = "open"
    priority: str = "medium"
    project: Optional[str] = None
    tags: Optional[str] = None
    created_at: datetime = Field(default_factory=datetime.utcnow)
    due_date: Optional[datetime] = None
    github_url: Optional[str] = None
    github_issue_number: Optional[int] = None
