"""GitHub API client for devtodo."""

import os
from typing import Optional
import httpx

GITHUB_API = "https://api.github.com"


def _get_token() -> Optional[str]:
    return os.environ.get("GITHUB_TOKEN")


def _headers() -> dict:
    token = _get_token()
    headers = {"Accept": "application/vnd.github+json", "X-GitHub-Api-Version": "2022-11-28"}
    if token:
        headers["Authorization"] = f"Bearer {token}"
    return headers


def fetch_issues(repo: str, state: str = "open", limit: int = 50) -> list[dict]:
    """Fetch issues from a GitHub repo. repo = 'owner/name'"""
    url = f"{GITHUB_API}/repos/{repo}/issues"
    params = {"state": state, "per_page": min(limit, 100), "page": 1}
    resp = httpx.get(url, headers=_headers(), params=params, timeout=10)
    resp.raise_for_status()
    # filter out pull requests (GitHub returns PRs as issues too)
    return [i for i in resp.json() if "pull_request" not in i]


def create_issue(repo: str, title: str, body: Optional[str] = None, labels: list[str] | None = None) -> dict:
    """Create a GitHub issue. Returns the created issue dict."""
    url = f"{GITHUB_API}/repos/{repo}/issues"
    payload: dict = {"title": title}
    if body:
        payload["body"] = body
    if labels:
        payload["labels"] = labels
    resp = httpx.post(url, headers=_headers(), json=payload, timeout=10)
    resp.raise_for_status()
    return resp.json()


def close_issue(repo: str, issue_number: int) -> dict:
    """Close a GitHub issue."""
    url = f"{GITHUB_API}/repos/{repo}/issues/{issue_number}"
    resp = httpx.patch(url, headers=_headers(), json={"state": "closed"}, timeout=10)
    resp.raise_for_status()
    return resp.json()
