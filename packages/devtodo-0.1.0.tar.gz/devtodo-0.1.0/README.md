# devtodo 📝

A fast, developer-focused CLI todo tool with a beautiful TUI.

## Install

```bash
pipx install devtodo
```

> Requires Python 3.12+. Install `pipx` first: `pip install pipx`

## Usage

```bash
dt add "Fix login bug" --priority high --project backend
dt list
dt list --project backend
dt done 1
dt edit 2 --priority low --tags "bug,ui"
dt remove 3
dt clear-completed
dt today         # high priority + due today
dt start         # interactive TUI
```

## GitHub Integration

```bash
export GITHUB_TOKEN=ghp_yourtoken

dt github sync --repo owner/repo     # import open issues as todos
dt github push 5 --repo owner/repo   # push todo #5 as a GitHub issue
dt github list                        # show todos linked to GitHub
```

## Keyboard shortcuts (TUI)

| Key | Action |
|-----|--------|
| `a` | Add todo |
| `e` | Edit selected |
| `d` | Mark done |
| `Del` | Remove |
| `f` / `F` | Filter open / show all |
| `q` | Quit |

## Data

Todos are stored locally at `~/.devtodo/devtodo.db` (SQLite).
