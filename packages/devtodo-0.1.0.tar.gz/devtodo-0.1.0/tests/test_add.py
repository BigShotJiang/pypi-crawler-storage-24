import pytest
from sqlmodel import SQLModel, create_engine, Session

from devtodo.db import init_db
from devtodo.services.todo_service import TodoService


@pytest.fixture()
def session():
    engine = create_engine("sqlite:///:memory:", connect_args={"check_same_thread": False})
    init_db(engine)
    with Session(engine) as s:
        yield s


def test_add_todo(session):
    service = TodoService(session)
    todo = service.add(title="Fix login bug")
    assert todo.id is not None
    assert todo.title == "Fix login bug"
    assert todo.status == "open"
    assert todo.priority == "medium"


def test_add_with_options(session):
    service = TodoService(session)
    todo = service.add(
        title="Build landing page",
        priority="high",
        project="portfolio",
        tags="frontend,design",
    )
    assert todo.priority == "high"
    assert todo.project == "portfolio"
    assert todo.tags == "frontend,design"


def test_add_multiple(session):
    service = TodoService(session)
    t1 = service.add("First")
    t2 = service.add("Second")
    assert t1.id != t2.id
