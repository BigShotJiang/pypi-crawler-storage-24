import pytest
from sqlmodel import SQLModel, create_engine, Session

from devtodo.db import init_db
from devtodo.services.todo_service import TodoService


@pytest.fixture()
def session():
    engine = create_engine("sqlite:///:memory:", connect_args={"check_same_thread": False})
    init_db(engine)
    with Session(engine) as s:
        yield s


@pytest.fixture()
def service_with_todo(session):
    service = TodoService(session)
    todo = service.add("Fix navbar")
    return service, todo


def test_mark_done(service_with_todo):
    service, todo = service_with_todo
    updated = service.mark_done(todo.id)
    assert updated.status == "done"


def test_mark_done_not_found(service_with_todo):
    service, _ = service_with_todo
    result = service.mark_done(9999)
    assert result is None


def test_remove(service_with_todo):
    service, todo = service_with_todo
    removed = service.remove(todo.id)
    assert removed is True
    assert service.get(todo.id) is None


def test_remove_not_found(service_with_todo):
    service, _ = service_with_todo
    removed = service.remove(9999)
    assert removed is False


def test_clear_completed(session):
    service = TodoService(session)
    t1 = service.add("Done task")
    t2 = service.add("Open task")
    service.mark_done(t1.id)
    count = service.clear_completed()
    assert count == 1
    assert len(service.list_todos()) == 1


def test_edit(service_with_todo):
    service, todo = service_with_todo
    updated = service.edit(todo.id, title="Fixed navbar", priority="high")
    assert updated.title == "Fixed navbar"
    assert updated.priority == "high"
