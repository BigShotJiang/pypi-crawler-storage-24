import pytest
from sqlmodel import SQLModel, create_engine, Session

from devtodo.db import init_db
from devtodo.services.todo_service import TodoService


@pytest.fixture()
def session():
    engine = create_engine("sqlite:///:memory:", connect_args={"check_same_thread": False})
    init_db(engine)
    with Session(engine) as s:
        yield s


@pytest.fixture()
def seeded_service(session):
    service = TodoService(session)
    service.add("Task one", priority="high")
    service.add("Task two", priority="low")
    service.add("Task three", project="demo")
    return service


def test_list_all(seeded_service):
    todos = seeded_service.list_todos()
    assert len(todos) == 3


def test_list_by_status(seeded_service):
    open_todos = seeded_service.list_todos(status="open")
    assert all(t.status == "open" for t in open_todos)
    assert len(open_todos) == 3


def test_list_by_priority(seeded_service):
    high = seeded_service.list_todos(priority="high")
    assert len(high) == 1
    assert high[0].title == "Task one"


def test_list_by_project(seeded_service):
    demo = seeded_service.list_todos(project="demo")
    assert len(demo) == 1
    assert demo[0].title == "Task three"


def test_list_empty(session):
    service = TodoService(session)
    assert service.list_todos() == []
