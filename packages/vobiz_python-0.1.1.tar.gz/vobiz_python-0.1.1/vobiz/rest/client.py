# -*- coding: utf-8 -*-
"""
Core client, used for all API requests.
"""

import os
import platform
from collections import namedtuple

from dotenv import load_dotenv
load_dotenv()

from vobiz.base import ResponseObject
from vobiz.exceptions import (
    AuthenticationError,
    InvalidRequestError,
    VobizRestError,
    VobizServerError,
    GeoPermissionError,
    ResourceNotFoundError,
    ValidationError,
    ForbiddenError,
)
from vobiz.resources import (
    Calls,
    Accounts,
    Subaccounts,
    Applications,
    Recordings,
    CDRs,
    PhoneNumbers,
    Endpoints,
    SipTrunks,
    Credentials,
    IpAccessControlLists,
    OriginationUris,
)
from vobiz.version import __version__
from requests import Request, Session

AuthenticationCredentials = namedtuple("AuthenticationCredentials", "auth_id auth_token")

VOBIZ_API = "https://api.vobiz.ai/api"
VOBIZ_API_BASE_URI = "/".join([VOBIZ_API, "v1/Account"])

GEO_PERMISSION_ENDPOINTS = ["/Call/"]


def get_user_agent():
    return "vobiz-python/%s (Python: %s)" % (__version__, platform.python_version())


def fetch_credentials(auth_id, auth_token):
    """Fetch credentials from arguments"""

    if not (auth_id and auth_token):
        try:
            auth_id = os.environ["VOBIZ_AUTH_ID"]
            auth_token = os.environ["VOBIZ_AUTH_TOKEN"]
        except KeyError:
            raise AuthenticationError(
                "The Vobiz Python SDK could not find your auth credentials."
            )

    if not isinstance(auth_id, str) or not auth_id:
        raise AuthenticationError("Invalid auth_id supplied: %s" % auth_id)

    if not isinstance(auth_token, str) or not auth_token:
        raise AuthenticationError("Invalid auth_token supplied.")

    return AuthenticationCredentials(auth_id=auth_id, auth_token=auth_token)


class Client(object):
    def __init__(self, auth_id=None, auth_token=None, proxies=None, timeout=5):
        """
        The Vobiz API client.

        Deals with all the API requests to be made.
        """

        self.base_uri = VOBIZ_API_BASE_URI
        self.session = Session()
        self.session.headers.update(
            {
                "User-Agent": get_user_agent(),
                "Content-Type": "application/json",
                "Accept": "application/json",
            }
        )
        creds = fetch_credentials(auth_id, auth_token)
        self.auth_id = creds.auth_id
        self.auth_token = creds.auth_token
        self.session.headers.update(
            {"X-Auth-ID": self.auth_id, "X-Auth-Token": self.auth_token}
        )
        self.multipart_session = Session()
        self.multipart_session.headers.update(
            {
                "User-Agent": get_user_agent(),
                "Cache-Control": "no-cache",
            }
        )
        self.multipart_session.headers.update(
            {"X-Auth-ID": self.auth_id, "X-Auth-Token": self.auth_token}
        )
        self.proxies = proxies
        self.timeout = timeout
        self.calls = Calls(self)
        self.accounts = Accounts(self)
        self.subaccounts = Subaccounts(self)
        self.applications = Applications(self)
        self.recordings = Recordings(self)
        self.cdrs = CDRs(self)
        self.phone_numbers = PhoneNumbers(self)
        self.endpoints = Endpoints(self)
        self.sip_trunks = SipTrunks(self)
        self.credentials = Credentials(self)
        self.ip_access_control_lists = IpAccessControlLists(self)
        self.origination_uris = OriginationUris(self)


    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        self.session.close()
        self.multipart_session.close()

    def process_response(self,
                         method,
                         response,
                         response_type=None,
                         objects_type=None):
        """Processes the API response based on the status codes and method used
        to access the API
        """
        try:
            response_json = response.json(
                object_hook=lambda x: ResponseObject(x) if isinstance(x, dict) else x)
            if response_type:
                r = response_type(self, response_json.__dict__)
                response_json = r

            if 'objects' in response_json and objects_type:
                response_json.objects = [
                    objects_type(self, obj.__dict__)
                    for obj in response_json.objects
                ]
        except ValueError:
            response_json = None

        if response.status_code == 400:
            if response_json is not None and 'error' in response_json:
                raise ValidationError(response_json.error)
            raise ValidationError(
                'A parameter is missing or is invalid while accessing resource'
                'at: {url}'.format(url=response.url))

        if response.status_code == 401:
            if response_json and 'error' in response_json:
                raise AuthenticationError(response_json.error)
            raise AuthenticationError(
                'Failed to authenticate while accessing resource at: '
                '{url}'.format(url=response.url))

        if response.status_code == 403:
            error = ForbiddenError
            if method == "POST" and any(response.url.endswith(endpoint) for endpoint in GEO_PERMISSION_ENDPOINTS):
                error = GeoPermissionError
            if response_json and 'error' in response_json:
                raise error(response_json.error)
            raise error(
                'Request Failed : '
                '{url}'.format(url=response.url))

        if response.status_code == 404:
            if response_json and 'error' in response_json:
                raise ResourceNotFoundError(response_json.error)
            raise ResourceNotFoundError(
                'Resource not found at: {url}'.format(url=response.url))

        if response.status_code == 405:
            if response_json and 'error' in response_json:
                raise InvalidRequestError(response_json.error)
            raise InvalidRequestError(
                'HTTP method "{method}" not allowed to access resource at: '
                '{url}'.format(method=method, url=response.url))

        if response.status_code == 409:
            if response_json and 'error' in response_json:
                raise InvalidRequestError(response_json.error)
            raise InvalidRequestError(
                'Conflict: '
                '{url}'.format(url=response.url))

        if response.status_code == 422:
            if response_json and 'error' in response_json:
                raise InvalidRequestError(response_json.error)
            raise InvalidRequestError(
                'Unprocessable Entity: '
                '{url}'.format(url=response.url))

        if response.status_code == 500:
            if response_json and 'error' in response_json:
                raise VobizServerError(response_json.error)
            raise VobizServerError(
                'A server error occurred while accessing resource at: '
                '{url}'.format(url=response.url))

        if method == 'DELETE':
            if response.status_code not in [200, 202, 204]:
                raise VobizRestError('Resource at {url} could not be '
                                     'deleted'.format(url=response.url))

        elif response.status_code not in [200, 201, 202, 204, 206, 207]:
            raise VobizRestError(
                'Received status code {status_code} for the HTTP method '
                '"{method}"'.format(
                    status_code=response.status_code, method=method))

        return response_json

    def create_request(self, method, path=None, data=None, **kwargs):
        path = path or []
        url = '/'.join([self.base_uri, self.auth_id] + list([str(p) for p in path])) + '/'
        req = Request(
            method,
            url,
            **({'params': data} if method == 'GET' else {'json': data}),
        )
        return self.session.prepare_request(req)

    def create_multipart_request(self,
                                 method,
                                 path=None,
                                 data=None,
                                 files=None):
        path = path or []

        data_args = {}
        if method == 'GET':
            data_args['params'] = data
        else:
            data_args['data'] = data
            if files:
                data_args['files'] = files
        url = '/'.join([self.base_uri, self.auth_id] + list([str(p) for p in path])) + '/'
        req = Request(method, url, **data_args)
        return self.multipart_session.prepare_request(req)

    def send_request(self, request, **kwargs):
        if 'session' in kwargs:
            session = kwargs['session']
            del kwargs['session']
        else:
            session = self.session
        return session.send(
            request, proxies=self.proxies, timeout=self.timeout, **kwargs)

    def request(self,
                method,
                path=None,
                data=None,
                response_type=None,
                objects_type=None,
                files=None,
                **kwargs):
        if files is not None:
            req = self.create_multipart_request(method, path, data, files)
            session = self.multipart_session
        else:
            req = self.create_request(method, path, data)
            session = self.session
        kwargs['session'] = session
        res = self.send_request(req, **kwargs)
        return self.process_response(method, res, response_type, objects_type)
