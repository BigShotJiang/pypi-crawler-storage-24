from vobiz.utils.validators import *
from vobiz.xml import VobizXMLElement, map_type


class SayAsElement(VobizXMLElement):
    _name = 'say-as'
    _nestable = []

    @property
    def interpret_as(self):
        return self.__interpret_as

    @interpret_as.setter
    def interpret_as(self, value):
        self.__interpret_as = str(
            value) if value is not None else None

    @validate_args(
        value=[of_type(str)],
    )
    def set_interpret_as(self, value):
        self.interpret_as = value
        return self

    @property
    def format(self):
        return self.__format

    @format.setter
    def format(self, value):
        self.__format = str(
            value) if value is not None else None

    @validate_args(
        value=[of_type(str)],
    )
    def set_format(self, value):
        self.format = value
        return self

    def __init__(
        self,
        content,
        interpret_as=None,
        format=None,
    ):

        super(SayAsElement, self).__init__()
        self.content = content
        self.interpret_as = interpret_as
        self.format = format

    def to_dict(self):
        d = {
            'interpret-as': self.interpret_as,
            'format': self.format,
        }
        return {
            k: str(map_type(v))
            for k, v in d.items() if v is not None
        }
