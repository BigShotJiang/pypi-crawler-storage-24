class FakeCryptoService:
    def encrypt(self, values: list[str]) -> list[str]:
        return [f'#01#{v}#10#' for v in values]

    def decrypt(self, values: list[str]) -> list[str]:
        return [v.removeprefix('#01#').removesuffix('#10#') for v in values]

    async def aencrypt(self, values: list[str]) -> list[str]:
        return self.encrypt(values)

    async def adecrypt(self, values: list[str]) -> list[str]:
        return self.decrypt(values)
