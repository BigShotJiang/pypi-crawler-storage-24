import httpx
from amsdal_utils.utils.singleton import Singleton


class PIICryptorService(metaclass=Singleton):
    _base_url: str = ''
    _client_id: str = ''
    _sync_client: httpx.Client | None = None
    _async_client: httpx.AsyncClient | None = None

    def configure(self, base_url: str, client_id: str = '') -> None:
        self._base_url = base_url.rstrip('/')
        self._client_id = client_id
        self._sync_client = httpx.Client(base_url=self._base_url, timeout=30)
        self._async_client = httpx.AsyncClient(base_url=self._base_url, timeout=30)

    def _headers(self) -> dict[str, str]:
        if self._client_id:
            return {'X-CLIENT-ID': self._client_id}
        return {}

    def encrypt(self, values: list[str]) -> list[str]:
        if self._sync_client is None:
            msg = 'PIICryptorService not configured. Call configure() first.'
            raise RuntimeError(msg)
        resp = self._sync_client.post('/api/v1/encrypt', json={'values': values}, headers=self._headers())
        resp.raise_for_status()
        return resp.json()['values']

    def decrypt(self, values: list[str]) -> list[str]:
        if self._sync_client is None:
            msg = 'PIICryptorService not configured. Call configure() first.'
            raise RuntimeError(msg)
        resp = self._sync_client.post('/api/v1/decrypt', json={'values': values}, headers=self._headers())
        resp.raise_for_status()
        return resp.json()['values']

    async def aencrypt(self, values: list[str]) -> list[str]:
        if self._async_client is None:
            msg = 'PIICryptorService not configured. Call configure() first.'
            raise RuntimeError(msg)
        resp = await self._async_client.post('/api/v1/encrypt', json={'values': values}, headers=self._headers())
        resp.raise_for_status()
        return resp.json()['values']

    async def adecrypt(self, values: list[str]) -> list[str]:
        if self._async_client is None:
            msg = 'PIICryptorService not configured. Call configure() first.'
            raise RuntimeError(msg)
        resp = await self._async_client.post('/api/v1/decrypt', json={'values': values}, headers=self._headers())
        resp.raise_for_status()
        return resp.json()['values']


def register_pii_crypto_service(base_url: str, client_id: str) -> None:
    from amsdal_models.classes.fields.pii import register_crypto_service

    if base_url:
        service = PIICryptorService()
        service.configure(
            base_url=base_url,
            client_id=client_id,
        )
        register_crypto_service(service)
    else:
        from amsdal.services.fake_crypto import FakeCryptoService

        register_crypto_service(FakeCryptoService())
