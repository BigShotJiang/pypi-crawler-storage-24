from _typeshed import Incomplete
from amsdal.contrib.auth.permissions import BasePermission as BasePermission
from typing import Any

class PermissionSet:
    """Container for per-action or blanket permissions.

    Stores a default permission and optional per-action overrides.
    `get_permission(action)` returns the action-specific permission or falls back to default.
    """
    default: Incomplete
    _actions: dict[str, BasePermission]
    def __init__(self, default: BasePermission | None = None, *, read: BasePermission | None = None, create: BasePermission | None = None, update: BasePermission | None = None, delete: BasePermission | None = None, execute: BasePermission | None = None) -> None: ...
    def get_permission(self, action_value: str) -> BasePermission | None:
        """Return action-specific permission or fall back to default."""

def permissions(perm: BasePermission | None = None, *, read: BasePermission | None = None, create: BasePermission | None = None, update: BasePermission | None = None, delete: BasePermission | None = None, execute: BasePermission | None = None) -> Any:
    """Decorator that sets __permissions__ on a class or function.

    Args:
        perm: Default permission for all actions. Mutually exclusive with per-action args
              when used as the only permission.
        read: Permission for read action.
        create: Permission for create action.
        update: Permission for update action.
        delete: Permission for delete action.
        execute: Permission for execute action.

    Usage:
        @permissions(RequireAuth)
        @permissions(read=AllowAny, create=RequireAuth)
        @permissions(RequireAuth, execute=RequireAuth & RequirePermissions('...'))
    """
def require_auth(func_or_class: Any) -> Any:
    """Alias for @permissions(RequireAuth)."""
def allow_any(func_or_class: Any) -> Any:
    """Alias for @permissions(AllowAny)."""
