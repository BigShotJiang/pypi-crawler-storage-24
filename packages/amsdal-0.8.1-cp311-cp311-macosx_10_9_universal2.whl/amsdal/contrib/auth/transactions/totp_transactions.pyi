from _typeshed import Incomplete
from amsdal.context.manager import AmsdalContextManager as AmsdalContextManager
from amsdal.contrib.auth.decorators import require_auth as require_auth
from amsdal.contrib.auth.models.totp_device import TOTPDevice as TOTPDevice
from amsdal.contrib.auth.services.totp_service import TOTPService as TOTPService
from pydantic import BaseModel
from starlette.requests import Request as Request

TAGS: Incomplete

class SetupTOTPDeviceRequest(BaseModel):
    """Request model for TOTP device setup."""
    target_user_email: str
    device_name: str
    issuer: str | None

class SetupTOTPDeviceResponse(BaseModel):
    """Response model for TOTP device setup."""
    secret: str
    qr_code_url: str
    device_id: str

class ConfirmTOTPDeviceRequest(BaseModel):
    """Request model for TOTP device confirmation."""
    device_id: str
    verification_code: str

class ConfirmTOTPDeviceResponse(BaseModel):
    """Response model for TOTP device confirmation."""
    device_id: str
    user_email: str
    name: str
    confirmed: bool
    @classmethod
    def from_device(cls, device: TOTPDevice) -> ConfirmTOTPDeviceResponse:
        """Create response from TOTPDevice model."""

def _get_request() -> Request:
    """Helper to get current request from context."""
@require_auth
def add_mfa_totp_device_transaction(target_user_email: str, device_name: str, issuer: str | None = None) -> SetupTOTPDeviceResponse:
    """
    Setup TOTP device (Step 1 of 2).

    Creates an unconfirmed TOTP device and returns the secret and QR code URL.
    The secret is only returned once and cannot be retrieved later.

    Args:
        target_user_email: Email of user to setup device for.
        device_name: User-friendly name for the device.
        issuer: TOTP issuer name (optional).

    Returns:
        SetupTOTPDeviceResponse: Contains secret, QR code URL, and device ID.

    Raises:
        UserNotFoundError: If target user doesn't exist.
        AmsdalAuthorizationError: If user lacks permission.
    """
@require_auth
async def aadd_mfa_totp_device_transaction(target_user_email: str, device_name: str, issuer: str | None = None) -> SetupTOTPDeviceResponse:
    """
    Async version of add_mfa_totp_device_transaction.

    Setup TOTP device (Step 1 of 2).

    Args:
        target_user_email: Email of user to setup device for.
        device_name: User-friendly name for the device.
        issuer: TOTP issuer name (optional).

    Returns:
        SetupTOTPDeviceResponse: Contains secret, QR code URL, and device ID.

    Raises:
        UserNotFoundError: If target user doesn't exist.
        AmsdalAuthorizationError: If user lacks permission.
    """
@require_auth
def confirm_mfa_totp_device_transaction(device_id: str, verification_code: str) -> ConfirmTOTPDeviceResponse:
    """
    Confirm TOTP device by verifying code (Step 2 of 2).

    Validates the verification code from the authenticator app and marks
    the device as confirmed if successful.

    Args:
        device_id: ID of unconfirmed device from setup.
        verification_code: 6-digit code from authenticator app.

    Returns:
        ConfirmTOTPDeviceResponse: Confirmed device details.

    Raises:
        MFADeviceNotFoundError: If device doesn't exist.
        AmsdalAuthorizationError: If user lacks permission.
        InvalidMFACodeError: If verification code is incorrect.
        MFASetupError: If device already confirmed.
    """
@require_auth
async def aconfirm_mfa_totp_device_transaction(device_id: str, verification_code: str) -> ConfirmTOTPDeviceResponse:
    """
    Async version of confirm_mfa_totp_device_transaction.

    Confirm TOTP device by verifying code (Step 2 of 2).

    Args:
        device_id: ID of unconfirmed device from setup.
        verification_code: 6-digit code from authenticator app.

    Returns:
        ConfirmTOTPDeviceResponse: Confirmed device details.

    Raises:
        MFADeviceNotFoundError: If device doesn't exist.
        AmsdalAuthorizationError: If user lacks permission.
        InvalidMFACodeError: If verification code is incorrect.
        MFASetupError: If device already confirmed.
    """
