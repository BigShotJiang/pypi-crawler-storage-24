from _typeshed import Incomplete
from amsdal.contrib.auth.events.mfa import SendMFACodeContext as SendMFACodeContext
from amsdal_utils.events import AsyncNextFn as AsyncNextFn, EventListener, NextFn as NextFn

logger: Incomplete

class SendEmailMFACodeListener(EventListener[SendMFACodeContext]):
    """Sends MFA codes via email using amsdal_mail.

    This is the default listener for email-based MFA code delivery.
    It only handles contexts where device_type is 'email' and passes
    other device types to the next listener in the chain.

    To use a custom email backend, unsubscribe this listener and register
    your own implementation.
    """
    def handle(self, context: SendMFACodeContext, next_fn: NextFn[SendMFACodeContext]) -> SendMFACodeContext: ...
    async def ahandle(self, context: SendMFACodeContext, next_fn: AsyncNextFn[SendMFACodeContext]) -> SendMFACodeContext: ...
