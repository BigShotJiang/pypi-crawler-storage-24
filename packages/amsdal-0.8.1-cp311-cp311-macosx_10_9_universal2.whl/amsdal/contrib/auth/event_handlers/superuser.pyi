from _typeshed import Incomplete
from amsdal_data.transactions.decorators import async_transaction, transaction
from amsdal_server.apps.common.events.server import ServerStartupContext
from amsdal_utils.events import AsyncNextFn as AsyncNextFn, EventListener, NextFn as NextFn

logger: Incomplete

class CheckAndCreateSuperUserListener(EventListener[ServerStartupContext]):
    """Ensures the existence of a super user in the system.

    This listener checks if a super user exists based on the provided email and password
    in the authentication settings. If the super user does not exist, it creates one.
    """
    @transaction
    def handle(self, context: ServerStartupContext, next_fn: NextFn[ServerStartupContext]) -> ServerStartupContext:
        """Check for the existence of a super user and create one if necessary."""
    @async_transaction
    async def ahandle(self, context: ServerStartupContext, next_fn: AsyncNextFn[ServerStartupContext]) -> ServerStartupContext:
        """Check for the existence of a super user and create one if necessary (async)."""
