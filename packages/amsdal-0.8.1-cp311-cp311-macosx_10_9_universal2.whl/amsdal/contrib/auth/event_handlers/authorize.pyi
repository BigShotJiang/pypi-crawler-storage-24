from _typeshed import Incomplete
from amsdal.contrib.auth.decorators import PermissionSet as PermissionSet
from amsdal_models.classes.model import Model
from amsdal_server.apps.common.events.authorize import ClassAuthorizeContext, ObjectAuthorizeContext
from amsdal_server.apps.common.permissions.enums import Action as Action, ResourceType
from amsdal_utils.events import AsyncNextFn as AsyncNextFn, EventListener, NextFn as NextFn
from typing import Any

logger: Incomplete

class ClassAuthorizeListener(EventListener[ClassAuthorizeContext]):
    """Handles class-level authorization checks.

    Uses the composable permission system (__permissions__ attribute) to determine access.
    Falls back to REQUIRE_DEFAULT_AUTHORIZATION setting when no explicit permissions are set.
    """
    def handle(self, context: ClassAuthorizeContext, next_fn: NextFn[ClassAuthorizeContext]) -> ClassAuthorizeContext: ...
    async def ahandle(self, context: ClassAuthorizeContext, next_fn: AsyncNextFn[ClassAuthorizeContext]) -> ClassAuthorizeContext: ...
    def _check_permissions(self, request: Any, resource_type: ResourceType, resource_name: str, action: Action) -> tuple[bool, str | None]:
        """Check if user has permission via the composable permission system."""
    def _get_permission_set(self, resource_type: ResourceType, resource_name: str) -> PermissionSet:
        """Get the PermissionSet for a resource, falling back to defaults."""

class ObjectAuthorizeListener(EventListener[ObjectAuthorizeContext]):
    """Handles object-level authorization checks.

    Checks has_object_permission() on the model instance if it exists.
    """
    def handle(self, context: ObjectAuthorizeContext, next_fn: NextFn[ObjectAuthorizeContext]) -> ObjectAuthorizeContext: ...
    async def ahandle(self, context: ObjectAuthorizeContext, next_fn: AsyncNextFn[ObjectAuthorizeContext]) -> ObjectAuthorizeContext: ...
    def _check_object_permission(self, request: Any, obj: Model, action: Action, update_data: dict[str, Any] | None = None) -> tuple[bool, str | None]:
        """Check if user has permission on the specific object."""
