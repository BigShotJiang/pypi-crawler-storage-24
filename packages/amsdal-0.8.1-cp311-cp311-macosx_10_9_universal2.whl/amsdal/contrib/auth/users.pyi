from _typeshed import Incomplete
from amsdal.contrib.auth.models.user import User as User
from starlette.authentication import BaseUser

class AuthenticatedUser(BaseUser):
    """Wrapper around ORM User model for Starlette authentication.

    Provides the BaseUser interface while giving access to the underlying
    ORM user model for additional functionality.
    """
    _user: Incomplete
    def __init__(self, user: User) -> None: ...
    @property
    def is_authenticated(self) -> bool: ...
    @property
    def display_name(self) -> str: ...
    @property
    def identity(self) -> str: ...
    @property
    def user(self) -> User:
        """Access the underlying ORM User model."""
    def __str__(self) -> str: ...
    def __repr__(self) -> str: ...
