import abc
from _typeshed import Incomplete
from abc import ABC, abstractmethod
from amsdal_server.apps.common.permissions.enums import Action as Action
from typing import Any

class BasePermission(ABC, metaclass=abc.ABCMeta):
    """Abstract base for all permission classes."""
    @abstractmethod
    def has_permission(self, request: Any, action: Action) -> bool:
        """Return True if permission is granted."""
    def __and__(self, other: BasePermission) -> BasePermission: ...
    def __or__(self, other: BasePermission) -> BasePermission: ...
    def __repr__(self) -> str: ...

class _AndPermission(BasePermission):
    """Composite permission: both must pass."""
    left: Incomplete
    right: Incomplete
    def __init__(self, left: BasePermission, right: BasePermission) -> None: ...
    def has_permission(self, request: Any, action: Action) -> bool: ...
    def __repr__(self) -> str: ...

class _OrPermission(BasePermission):
    """Composite permission: at least one must pass."""
    left: Incomplete
    right: Incomplete
    def __init__(self, left: BasePermission, right: BasePermission) -> None: ...
    def has_permission(self, request: Any, action: Action) -> bool: ...
    def __repr__(self) -> str: ...

class _AllowAny(BasePermission):
    """Always grants permission."""
    def has_permission(self, request: Any, action: Action) -> bool: ...

class _RequireAuth(BasePermission):
    """Requires the user to be authenticated."""
    def has_permission(self, request: Any, action: Action) -> bool: ...

class RequirePermissions(BasePermission):
    """Requires the user to have specific permission strings (all must match).

    Args:
        *permission_strings: Permission strings like 'models.Post:read'.
            All strings must match (AND logic). Use | operator for OR logic.
    """
    permission_strings: Incomplete
    def __init__(self, *permission_strings: str) -> None: ...
    def has_permission(self, request: Any, action: Action) -> bool: ...
    def __repr__(self) -> str: ...

AllowAny: Incomplete
RequireAuth: Incomplete

def has_admin_permissions(auth: Any) -> bool:
    """Check if auth credentials have super admin (full access) permissions.

    Args:
        auth: Auth credentials object (e.g. request.auth). Can be None.

    Returns:
        True if auth contains the '*:*' wildcard permission.
    """
def has_permissions(required: str, auth: Any) -> bool:
    """Check if auth credentials have a specific permission (supports wildcards).

    Args:
        required: Permission string to check, e.g. 'models.Post:read'.
        auth: Auth credentials object (e.g. request.auth). Can be None.

    Returns:
        True if auth contains a matching permission.
    """
