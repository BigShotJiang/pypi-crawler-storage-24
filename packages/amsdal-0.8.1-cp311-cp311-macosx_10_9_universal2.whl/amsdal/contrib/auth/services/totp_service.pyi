from amsdal.contrib.auth.errors import InvalidMFACodeError as InvalidMFACodeError, MFADeviceNotFoundError as MFADeviceNotFoundError, MFASetupError as MFASetupError, UserNotFoundError as UserNotFoundError
from amsdal.contrib.auth.models.totp_device import TOTPDevice as TOTPDevice
from amsdal.contrib.auth.models.user import User as User
from amsdal.contrib.auth.settings import auth_settings as auth_settings
from amsdal.contrib.auth.utils.mfa import generate_qr_code_url as generate_qr_code_url, generate_totp_secret as generate_totp_secret

class TOTPService:
    """Service for TOTP device two-step enrollment flow.

    Note: This service contains pure business logic only.
    - build_* methods return UNSAVED instances
    - Authorization and save should be done at transaction level
    """
    @classmethod
    def _validate_user_exists(cls, email: str) -> User:
        """Validate user exists, raise UserNotFoundError if not."""
    @classmethod
    async def _avalidate_user_exists(cls, email: str) -> User:
        """Async version: Validate user exists, raise UserNotFoundError if not."""
    @classmethod
    def build_totp_device(cls, target_user_email: str, device_name: str, issuer: str | None = None) -> tuple[TOTPDevice, str, str]:
        """
        Build TOTP device instance (unsaved) with secret and QR code URL.

        Args:
            target_user_email: Email of user to setup device for.
            device_name: User-friendly name for the device.
            issuer: TOTP issuer name (defaults to MFA_TOTP_ISSUER setting).

        Returns:
            tuple[TOTPDevice, str, str]: Unsaved device instance, secret, and QR code URL.

        Raises:
            UserNotFoundError: If target user doesn't exist.

        Security Note:
            Secret is returned ONLY during setup.
            User must scan QR or manually enter secret.
            Device is created with confirmed=False.
        """
    @classmethod
    async def abuild_totp_device(cls, target_user_email: str, device_name: str, issuer: str | None = None) -> tuple[TOTPDevice, str, str]:
        """
        Async version: Build TOTP device instance (unsaved) with secret and QR code URL.

        Args:
            target_user_email: Email of user to setup device for.
            device_name: User-friendly name for the device.
            issuer: TOTP issuer name (defaults to MFA_TOTP_ISSUER setting).

        Returns:
            tuple[TOTPDevice, str, str]: Unsaved device instance, secret, and QR code URL.

        Raises:
            UserNotFoundError: If target user doesn't exist.

        Security Note:
            Secret is returned ONLY during setup.
            User must scan QR or manually enter secret.
            Device is created with confirmed=False.
        """
    @classmethod
    def find_totp_device(cls, device_id: str) -> TOTPDevice:
        """
        Find TOTP device by ID.

        Args:
            device_id: ID of the device to find.

        Returns:
            TOTPDevice: The found device.

        Raises:
            MFADeviceNotFoundError: If device doesn't exist.
        """
    @classmethod
    async def afind_totp_device(cls, device_id: str) -> TOTPDevice:
        """
        Async version: Find TOTP device by ID.

        Args:
            device_id: ID of the device to find.

        Returns:
            TOTPDevice: The found device.

        Raises:
            MFADeviceNotFoundError: If device doesn't exist.
        """
    @classmethod
    def confirm_totp_device(cls, device: TOTPDevice, verification_code: str) -> TOTPDevice:
        """
        Confirm TOTP device by verifying code.

        Args:
            device: The TOTP device to confirm.
            verification_code: 6-digit code from authenticator app.

        Returns:
            TOTPDevice: The confirmed device (unsaved).

        Raises:
            InvalidMFACodeError: If verification code is incorrect.
            MFASetupError: If device already confirmed.

        Note:
            This method modifies the device but does NOT save it.
            Caller is responsible for saving.
        """
