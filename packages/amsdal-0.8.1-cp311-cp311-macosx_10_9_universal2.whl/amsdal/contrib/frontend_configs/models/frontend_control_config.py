from typing import TYPE_CHECKING
from typing import Any
from typing import ClassVar
from typing import Literal
from typing import Optional

from amsdal_utils.models.enums import ModuleType
from pydantic.fields import Field

from amsdal.contrib.frontend_configs.models.frontend_activator_config import *  # noqa: F403
from amsdal.contrib.frontend_configs.models.frontend_config_async_validator import *  # noqa: F403
from amsdal.contrib.frontend_configs.models.frontend_config_control_action import *  # noqa: F403
from amsdal.contrib.frontend_configs.models.frontend_config_option import *  # noqa: F403
from amsdal.contrib.frontend_configs.models.frontend_config_skip_none_base import *  # noqa: F403
from amsdal.contrib.frontend_configs.models.frontend_config_slider_option import *  # noqa: F403
from amsdal.contrib.frontend_configs.models.frontend_config_text_mask import *  # noqa: F403
from amsdal.contrib.frontend_configs.models.frontend_config_validator import *  # noqa: F403

if TYPE_CHECKING:
    from amsdal.contrib.frontend_configs.models.frontend_config_control_action import ActionType

ConfigType = Literal[
    'Bytes',
    'paragraph',
    'header',
    'array',
    'attachment',
    'wizard',
    'button',
    'chat',
    'checkbox',
    'date',
    'dateTriplet',
    'datetime',
    'dict',
    'dropzone',
    'email',
    'file',
    'group',
    'group_switch',
    'group_toggle',
    'info-group',
    'infoscreen',
    'multiselect',
    'number',
    'number-operations',
    'number-slider',
    'number_equals',
    'number_initial',
    'number_minus',
    'number_plus',
    'object',
    'object_group',
    'object_latest',
    'password',
    'phone',
    'radio',
    'select',
    'text',
    'textarea',
    'time',
    'toggle',
    'sections',
    'section',
]


class ConditionItem(FrontendConfigSkipNoneBase):  # noqa: F405
    path: str = Field(title='Path')
    condition: str = Field(title='Condition')
    value: Any = Field(default=None, title='Value')


class Condition(FrontendConfigSkipNoneBase):  # noqa: F405
    __module_type__: ClassVar[ModuleType] = ModuleType.CONTRIB
    operation: Literal['and', 'or', 'not'] = Field(title='Operation')
    conditions: list[ConditionItem] = Field(title='Conditions')  # noqa: F405


Condition.model_rebuild()


class FrontendControlConfig(FrontendConfigSkipNoneBase):  # noqa: F405
    __module_type__: ClassVar[ModuleType] = ModuleType.CONTRIB
    id: str | None = Field(default=None, title='ID')
    type: ConfigType = Field(title='Type')
    name: str = Field(title='Name')
    label: str | None = Field(default=None, title='Label')
    required: bool | None = Field(default=None, title='Required')
    hideLabel: bool | None = Field(default=None, title='Hide Label')  # noqa: N815
    actions: list['ActionType'] | None = Field(default=None, title='Actions')  # noqa: F405
    on_enter: list['ActionType'] | None = Field(default=None, title='On Enter Actions')  # noqa: F405, N815
    validators: list['FrontendConfigValidator'] | None = Field(default=None, title='Validators')  # noqa: F405
    asyncValidators: list['FrontendConfigAsyncValidator'] | None = Field(  # noqa: F405, N815
        default=None,
        title='Async Validators',
    )
    activators: list['FrontendActivatorConfig'] | None = Field(default=None, title='Activators')  # noqa: F405
    additionalText: str | None = Field(default=None, title='Additional Text')  # noqa: N815
    value: Any | None = Field(default=None, title='Value')
    placeholder: str | None = Field(default=None, title='Placeholder')
    options: list['FrontendConfigOption'] | None = Field(default=None, title='Options')  # noqa: F405
    mask: Optional['FrontendConfigTextMask'] = Field(default=None, title='Mask')  # noqa: F405
    controls: list['FrontendControlConfig'] | None = Field(default=None, title='Controls')
    showSearch: bool | None = Field(default=None, title='Show Search')  # noqa: N815
    sliderOptions: Optional['FrontendConfigSliderOption'] = Field(  # noqa: F405, N815
        default=None, title='Slider Option'
    )
    customLabel: list[str] | None = Field(default=None, title='Custom Label')  # noqa: N815
    control: Optional['FrontendControlConfig'] = Field(default=None, title='Control')
    entityType: str | None = Field(default=None, title='Entity Type')  # noqa: N815
    condition: Condition | None = Field(default=None, title='Condition')  # noqa: F405
    additional_styles: dict[str, str] | None = Field(default=None, title='Additional Styles')  # noqa: N815
    override_styles: dict[str, str] | None = Field(default=None, title='Override Styles')  # noqa: N815


from amsdal.contrib.frontend_configs.models.frontend_config_control_action import ActionType  # noqa: E402
