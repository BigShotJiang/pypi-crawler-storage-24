from amsdal_server.apps.transactions.serializers.responses import _TransactionDetailResponse
from typing import Any

class ExtendedTransactionDetailResponse(_TransactionDetailResponse):
    """Transaction detail response with optional control field."""
    control: dict[str, Any] | None
