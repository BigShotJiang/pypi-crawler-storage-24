from amsdal_server.apps.common.serializers.base_column_info import ColumnInfo
from typing import Any

class ExtendedColumnInfo(ColumnInfo):
    """Extended column info with frontend_configs-specific fields.

    Extends ColumnInfo with:
    - control: Form control configuration for input/editing
    """
    control: dict[str, Any] | None
