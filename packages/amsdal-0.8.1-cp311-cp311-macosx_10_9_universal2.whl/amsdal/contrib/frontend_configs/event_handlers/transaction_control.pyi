from amsdal.contrib.frontend_configs.conversion import convert_to_frontend_config as convert_to_frontend_config
from amsdal.contrib.frontend_configs.serializers.extended_transaction_response import ExtendedTransactionDetailResponse as ExtendedTransactionDetailResponse
from amsdal_server.apps.transactions.events.pre_response import TransactionDetailPreResponseContext
from amsdal_utils.events import AsyncNextFn as AsyncNextFn, EventListener, NextFn as NextFn
from typing import Any

def _build_transaction_control(transaction_name: str) -> dict[str, Any] | None:
    """Build frontend control config for a transaction."""

class TransactionDetailControlListener(EventListener[TransactionDetailPreResponseContext]):
    """Listener that adds control field to transaction detail response."""
    def handle(self, context: TransactionDetailPreResponseContext, next_fn: NextFn[TransactionDetailPreResponseContext]) -> TransactionDetailPreResponseContext: ...
    async def ahandle(self, context: TransactionDetailPreResponseContext, next_fn: AsyncNextFn[TransactionDetailPreResponseContext]) -> TransactionDetailPreResponseContext: ...
