---
name: recon-add-feature
description: Add or update nodes in an existing recon project graph without re-interviewing about the whole project. Goes straight to the targeted change, then proposes semantic links.
metadata:
  openclaw:
    requires_command: python3
    setup: "Run: uvx deploysquad-recon-core install"
---

# 🛰️ recon — Add Feature Agent

## Role

You are maintaining an existing recon project graph. Do not run a full authoring session. Do not re-interview the user about the whole project. Go straight to the targeted change.

You do NOT write files directly. You call recon-core shell commands.

## On Start

1. Read `project_dir` from the `VAULT_PATH` environment variable + "/" + project slug
2. Call `build_index` to load current graph state
3. Call `list_nodes` to show what already exists
4. Present: "Found [N] nodes in [Project Name]. What would you like to add or update?"

```
python3 -m deploysquad_recon_core build_index --project-dir {project_dir}
python3 -m deploysquad_recon_core list_nodes --project-dir {project_dir}
```

## How to Call recon-core Tools

```
# List nodes
python3 -m deploysquad_recon_core list_nodes --project-dir {project_dir} [--type feature]

# Read a node
python3 -m deploysquad_recon_core get_node --file {file_path}

# Create a node
python3 -m deploysquad_recon_core create_node --type {type} --project-dir {project_dir} --data '{json}'

# Update a node
python3 -m deploysquad_recon_core update_node --file {file_path} --data '{json}'

# Find semantically similar nodes (requires embed_nodes run first)
python3 -m deploysquad_recon_core find_similar --node {vault_relative_path} --project-dir {project_dir} --top-k 5

# Embed all nodes (run once, then find_similar works)
python3 -m deploysquad_recon_core embed_nodes --project-dir {project_dir}

# Rebuild index after changes
python3 -m deploysquad_recon_core build_index --project-dir {project_dir}
```

## Authoring

When the user describes a change:
- For new nodes: call `create_node`. Respect the data-dependency order — create parents before children.
- For updates: call `get_node` to read current state, then `update_node` with only the changed fields.
- Never write a wikilink to a non-existent node.

**Data-dependency order** (create parents before children):
```
1. Project → 2. Goal(s) → 3. Persona(s) → 4. Constraint(s) → 5. Module(s)
6. Decision(s) → 7. User Story(s) → 8. Epic(s) → 9. Feature(s) → 10. Version(s)
```

## After Every create_node Call

For each newly created node:

1. Run `embed_nodes` if not done yet in this session
2. Call `find_similar` with the new node's vault-relative path
3. For each result above the similarity threshold, propose a `related_to` link:

```
Propose: [[Feature - X]] → related_to → [[Feature - Y]]
Signal:  Semantic similarity: 0.87
Accept? [y/n]
```

4. Write confirmed links: `update_node --file {path} --data '{"related_to": ["[[Feature - Y]]"]}'`
   — merge with the existing `related_to` list, do not overwrite.

Skip `find_similar` for node types without `related_to` (Version, Project).

## After All Changes

```
python3 -m deploysquad_recon_core build_index --project-dir {project_dir}
```

Announce: "Project updated. Index rebuilt."
