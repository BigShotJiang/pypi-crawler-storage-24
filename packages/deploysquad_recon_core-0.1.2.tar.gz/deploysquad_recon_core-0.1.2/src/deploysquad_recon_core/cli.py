"""Install command for recon — writes MCP config and copies skill files."""
from __future__ import annotations

import importlib.resources as resources
import json
import shutil
from pathlib import Path


def _claude_settings_path() -> Path:
    return Path.home() / ".claude" / "settings.json"


def _commands_dir() -> Path:
    return Path.home() / ".claude" / "commands"


def _skills_dir() -> Path:
    """New-style Claude Code skills directory (Claude Code ≥ 1.0.33)."""
    return Path.home() / ".claude" / "skills"


def _read_settings(path: Path) -> dict:
    if path.exists():
        try:
            return json.loads(path.read_text())
        except json.JSONDecodeError as e:
            raise SystemExit(
                f"Error: {path} contains invalid JSON and could not be read.\n"
                f"Please fix or remove it before running install.\nDetail: {e}"
            )
    return {}


def _write_settings(path: Path, data: dict) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(data, indent=2))


def _openclaw_skills_dir() -> Path | None:
    """Return OpenClaw skills directory if OpenClaw is installed, else None."""
    openclaw_dir = Path.home() / ".openclaw" / "workspace" / "skills"
    return openclaw_dir if openclaw_dir.parent.parent.exists() else None


def _install_openclaw_skills() -> bool:
    """Copy OpenClaw skill dirs to ~/.openclaw/workspace/skills/. Returns True if installed."""
    skills_dir = _openclaw_skills_dir()
    if skills_dir is None:
        return False

    skills_dir.mkdir(parents=True, exist_ok=True)
    import deploysquad_recon_core

    skill_src = resources.files(deploysquad_recon_core) / "skill" / "openclaw"
    for skill_name in ["recon", "recon-add-feature"]:
        dest = skills_dir / skill_name
        dest.mkdir(exist_ok=True)
        src_file = skill_src / skill_name / "SKILL.md"
        with resources.as_file(src_file) as src:
            shutil.copy2(src, dest / "SKILL.md")
        print(f"✓ OpenClaw: {skill_name} skill copied to {dest}")
    return True


def install() -> None:
    """Interactive installer: prompts for vault path, writes MCP config, copies skills."""
    # Prompt for vault path — re-prompt until path exists
    default = str(Path.home() / "obsidian-vault")
    while True:
        raw = input(f"Where is your Obsidian vault? [{default}] ").strip()
        vault_path = raw if raw else default
        if Path(vault_path).exists():
            break
        print(f"  ✗ Path not found: {vault_path}. Please enter a valid directory.")

    # Write MCP server config
    settings_path = _claude_settings_path()
    settings = _read_settings(settings_path)
    settings.setdefault("mcpServers", {})
    settings["mcpServers"]["recon"] = {
        "command": "uvx",
        "args": ["deploysquad-recon-core"],
        "env": {"VAULT_PATH": vault_path},
    }
    _write_settings(settings_path, settings)
    print(f"✓ MCP server config written to {settings_path}")

    # Copy skill files — support both old (.claude/commands/) and new (.claude/skills/) style
    import deploysquad_recon_core
    skill_src = resources.files(deploysquad_recon_core) / "skill"

    # New-style: skills directory (Claude Code ≥ 1.0.33)
    skills_dir = _skills_dir()
    skills_dir.mkdir(parents=True, exist_ok=True)
    for skill_name, skill_file in [("recon", "recon.md"), ("recon-add-feature", "recon.add-feature.md")]:
        dest_dir = skills_dir / skill_name
        dest_dir.mkdir(exist_ok=True)
        skill_source = skill_src / skill_file
        with resources.as_file(skill_source) as src:
            shutil.copy2(src, dest_dir / "SKILL.md")
        print(f"✓ Skill installed: /recon:{skill_name} → {dest_dir / 'SKILL.md'}")

    # Legacy: also copy to .claude/commands/ for Claude Code < 1.0.33
    commands_dir = _commands_dir()
    commands_dir.mkdir(parents=True, exist_ok=True)
    for skill_file in ["recon.md", "recon.add-feature.md"]:
        dest = commands_dir / skill_file
        skill_source = skill_src / skill_file
        with resources.as_file(skill_source) as src:
            shutil.copy2(src, dest)

    # OpenClaw (if installed)
    if _install_openclaw_skills():
        print()
        print("OpenClaw detected — skills also installed.")
        print("In OpenClaw, say: 'map out my project with recon'")
    else:
        print()
        print("(OpenClaw not detected — skipping. Install from openclaw.ai if needed.)")

    print()
    print("Done! Restart Claude Code and run /recon to get started.")
