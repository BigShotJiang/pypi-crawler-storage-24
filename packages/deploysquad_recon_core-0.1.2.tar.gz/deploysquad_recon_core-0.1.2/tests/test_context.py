"""Tests for context builder — the MVP gate."""
from pathlib import Path

import pytest

from deploysquad_recon_core.context import generate_context
from deploysquad_recon_core.errors import NodeNotFoundError


FIXTURE_DIR = Path(__file__).parent / "fixtures" / "sample_vault" / "my-project"


class TestGenerateContext:
    def test_generates_for_fixture_feature(self):
        ctx = generate_context("JWT Login", FIXTURE_DIR)
        assert isinstance(ctx, str)
        assert len(ctx) > 100

    def test_starts_with_version_comment(self):
        ctx = generate_context("JWT Login", FIXTURE_DIR)
        assert ctx.startswith("<!-- context_bundle_version: 1 -->")

    def test_has_title(self):
        ctx = generate_context("JWT Login", FIXTURE_DIR)
        assert "# Context Bundle: JWT Login" in ctx

    def test_project_section(self):
        ctx = generate_context("JWT Login", FIXTURE_DIR)
        assert "## Project" in ctx
        assert "My Project" in ctx
        assert "A sample project for testing" in ctx

    def test_goals_section(self):
        ctx = generate_context("JWT Login", FIXTURE_DIR)
        assert "## Goals" in ctx
        assert "Fast Delivery" in ctx
        assert "Deliver features quickly" in ctx

    def test_version_section(self):
        ctx = generate_context("JWT Login", FIXTURE_DIR)
        assert "## Version" in ctx
        assert "MVP" in ctx
        assert "sequence: 1" in ctx
        assert "2026-06-01" in ctx

    def test_module_section(self):
        ctx = generate_context("JWT Login", FIXTURE_DIR)
        assert "## Module" in ctx
        assert "Auth" in ctx

    def test_user_stories_section(self):
        ctx = generate_context("JWT Login", FIXTURE_DIR)
        assert "## User Stories" in ctx
        assert "Login" in ctx
        assert "Acceptance Criteria" in ctx
        assert "Developer can authenticate with email and password" in ctx

    def test_user_story_body_included(self):
        ctx = generate_context("JWT Login", FIXTURE_DIR)
        assert "log in with my credentials" in ctx

    def test_constraints_section(self):
        ctx = generate_context("JWT Login", FIXTURE_DIR)
        assert "## Constraints" in ctx
        assert "MIT License" in ctx
        assert "All code must be MIT licensed" in ctx

    def test_decisions_section(self):
        ctx = generate_context("JWT Login", FIXTURE_DIR)
        assert "## Decisions" in ctx
        assert "Use JWT" in ctx
        assert "JWT tokens for stateless authentication" in ctx

    def test_nonexistent_feature_raises(self):
        with pytest.raises(NodeNotFoundError):
            generate_context("Nonexistent", FIXTURE_DIR)

    def test_no_dependencies_section_when_empty(self):
        ctx = generate_context("JWT Login", FIXTURE_DIR)
        # The fixture feature has depends_on: [], so no Dependencies section
        assert "## Dependencies" not in ctx

    def test_no_related_section_when_empty(self):
        ctx = generate_context("JWT Login", FIXTURE_DIR)
        # The fixture feature has related_to: [], so no Related section
        assert "## Related" not in ctx

    def test_goals_deduplicated(self):
        """Goal - Fast Delivery is referenced by both Feature and User Story.
        It should appear only once in the output."""
        ctx = generate_context("JWT Login", FIXTURE_DIR)
        assert ctx.count("### Fast Delivery") == 1
