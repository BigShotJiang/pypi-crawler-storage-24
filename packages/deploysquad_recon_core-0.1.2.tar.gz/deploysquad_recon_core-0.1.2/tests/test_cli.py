"""Tests for the install CLI command."""
import json
import os
from pathlib import Path
import pytest


@pytest.fixture
def fake_home(tmp_path, monkeypatch):
    """Set up a fake home directory with Claude config structure."""
    claude_dir = tmp_path / ".claude"
    claude_dir.mkdir()
    commands_dir = claude_dir / "commands"
    commands_dir.mkdir()
    settings = claude_dir / "settings.json"
    settings.write_text(json.dumps({"permissions": {}}))
    monkeypatch.setenv("HOME", str(tmp_path))
    return tmp_path


def test_install_writes_mcp_config(fake_home, monkeypatch):
    """install() writes recon MCP server config to ~/.claude/settings.json."""
    from deploysquad_recon_core.cli import install

    vault_path = fake_home / "my-vault"
    vault_path.mkdir()
    monkeypatch.setattr("builtins.input", lambda _: str(vault_path))

    install()

    settings = json.loads((fake_home / ".claude" / "settings.json").read_text())
    assert "mcpServers" in settings
    assert "recon" in settings["mcpServers"]
    mcp = settings["mcpServers"]["recon"]
    assert mcp["command"] == "uvx"
    assert "deploysquad-recon-core" in mcp["args"]
    assert mcp["env"]["VAULT_PATH"] == str(vault_path)


def test_install_rejects_nonexistent_vault_path(fake_home, monkeypatch):
    """install() re-prompts when the vault path does not exist."""
    from deploysquad_recon_core.cli import install

    nonexistent = str(fake_home / "does-not-exist")
    real_vault = fake_home / "real-vault"
    real_vault.mkdir()
    responses = iter([nonexistent, str(real_vault)])
    monkeypatch.setattr("builtins.input", lambda _: next(responses))

    install()

    settings = json.loads((fake_home / ".claude" / "settings.json").read_text())
    assert settings["mcpServers"]["recon"]["env"]["VAULT_PATH"] == str(real_vault)


def test_install_copies_skill_files(fake_home, monkeypatch):
    """install() copies both skill files to ~/.claude/commands/."""
    from deploysquad_recon_core.cli import install

    vault_path = fake_home / "my-vault"
    vault_path.mkdir()
    monkeypatch.setattr("builtins.input", lambda _: str(vault_path))

    install()

    commands_dir = fake_home / ".claude" / "commands"
    assert (commands_dir / "recon.md").exists()
    assert (commands_dir / "recon.add-feature.md").exists()


def test_install_is_idempotent(fake_home, monkeypatch):
    """Running install() twice does not corrupt settings.json."""
    from deploysquad_recon_core.cli import install

    vault_path = fake_home / "my-vault"
    vault_path.mkdir()
    monkeypatch.setattr("builtins.input", lambda _: str(vault_path))

    install()
    install()  # second run

    settings = json.loads((fake_home / ".claude" / "settings.json").read_text())
    # Should not have duplicate keys — JSON object, so inherently unique
    assert list(settings["mcpServers"].keys()).count("recon") == 1


def test_install_overwrites_existing_recon_config(fake_home, monkeypatch):
    """install() overwrites an existing recon MCP config entry."""
    from deploysquad_recon_core.cli import install

    # Pre-existing stale config
    settings_path = fake_home / ".claude" / "settings.json"
    settings_path.write_text(json.dumps({
        "permissions": {},
        "mcpServers": {
            "recon": {"command": "old-command", "args": [], "env": {"VAULT_PATH": "/old/path"}}
        }
    }))

    new_vault = fake_home / "new-vault"
    new_vault.mkdir()
    monkeypatch.setattr("builtins.input", lambda _: str(new_vault))

    install()

    settings = json.loads(settings_path.read_text())
    assert settings["mcpServers"]["recon"]["env"]["VAULT_PATH"] == str(new_vault)
    assert settings["mcpServers"]["recon"]["command"] == "uvx"


def test_install_detects_openclaw(fake_home, monkeypatch):
    """install() copies OpenClaw skills when ~/.openclaw/workspace exists."""
    from deploysquad_recon_core.cli import install

    # Simulate OpenClaw installed
    openclaw_workspace = fake_home / ".openclaw" / "workspace"
    openclaw_workspace.mkdir(parents=True)

    vault_path = fake_home / "my-vault"
    vault_path.mkdir()
    monkeypatch.setattr("builtins.input", lambda _: str(vault_path))

    install()

    skills_dir = fake_home / ".openclaw" / "workspace" / "skills"
    assert (skills_dir / "recon" / "SKILL.md").exists()
    assert (skills_dir / "recon-add-feature" / "SKILL.md").exists()


def test_install_preserves_other_settings(fake_home, monkeypatch):
    """install() does not overwrite unrelated settings.json keys."""
    from deploysquad_recon_core.cli import install

    settings_path = fake_home / ".claude" / "settings.json"
    settings_path.write_text(json.dumps({
        "permissions": {"allow": ["npm"]},
        "enabledPlugins": ["code-simplifier"],
    }))

    vault_path = fake_home / "my-vault"
    vault_path.mkdir()
    monkeypatch.setattr("builtins.input", lambda _: str(vault_path))

    install()

    settings = json.loads(settings_path.read_text())
    assert settings["permissions"] == {"allow": ["npm"]}
    assert settings["enabledPlugins"] == ["code-simplifier"]
