"""Tests for dictare."""
