"""Cliente HTTP para interactuar con AMULEN API."""

import re
from typing import Any

import httpx

from .config import AmulenConfig
from .errors import (
    AuthenticationError,
    AuthorizationError,
    CSRFError,
    NotFoundError,
    ServerError,
    ValidationError,
)
from .schemas import (
    Board,
    BoardCreate,
    ChecklistItem,
    ChecklistItemCreate,
    ChecklistItemUpdate,
    Comment,
    CommentCreate,
    HealthResponse,
    Project,
    ProjectCreate,
    ProjectUpdate,
    Task,
    TaskCreate,
    TaskMoveState,
    TaskUpdate,
)


class AmulenClient:
    """Cliente para AMULEN API con manejo de sesión y CSRF."""

    def __init__(self, config: AmulenConfig):
        self.config = config
        self.client = httpx.AsyncClient(
            base_url=config.base_url,
            timeout=config.timeout_s,
            follow_redirects=True,
        )
        self._csrf_token: str | None = None
        self._authenticated = False
        self.user_id: int | None = None
        self.user_nombre: str | None = None

    async def __aenter__(self) -> "AmulenClient":
        """Context manager entry."""
        await self.login()
        return self

    async def __aexit__(self, *args: Any) -> None:
        """Context manager exit."""
        await self.client.aclose()

    async def login(self) -> dict[str, Any]:
        """Iniciar sesión en AMULEN."""
        # Obtener CSRF token del formulario
        login_page = await self.client.get("/users/sign_in")
        if login_page.status_code >= 400:
            self._handle_response(login_page)

        match = re.search(r'name="csrf-token" content="([^"]+)"', login_page.text)
        if not match:
            match = re.search(r'name="authenticity_token" value="([^"]+)"', login_page.text)
        if not match:
            raise CSRFError("No se pudo extraer token del formulario de login")

        csrf_token = match.group(1)

        # Intentar login JSON (devuelve user info)
        json_response = await self.client.post(
            "/users/sign_in.json",
            json={"user": {"email": self.config.email, "password": self.config.password}},
            headers={"X-CSRF-Token": csrf_token, "Content-Type": "application/json"},
        )

        if json_response.status_code == 200:
            data = json_response.json()
            if data.get("status") == "success" and "user" in data:
                user = data["user"]
                self.user_id = user.get("id")
                self.user_nombre = user.get("nombre")
                self._authenticated = True
                return data

        # Fallback: login con form data
        response = await self.client.post(
            "/users/sign_in",
            data={
                "authenticity_token": csrf_token,
                "user[email]": self.config.email,
                "user[password]": self.config.password,
            },
        )
        if response.status_code in (401, 422):
            raise AuthenticationError("Credenciales inválidas o sesión no autorizada")
        if response.url.path.endswith("/users/sign_in"):
            raise AuthenticationError("Credenciales inválidas o sesión no autorizada")
        if "Invalid Email or password" in response.text:
            raise AuthenticationError("Credenciales inválidas o sesión no autorizada")
        if response.status_code >= 400:
            self._handle_response(response)

        self._authenticated = True
        return {"status": "success"}

    async def logout(self) -> None:
        """Cerrar sesión."""
        await self.client.delete("/users/sign_out")
        self._authenticated = False
        self._csrf_token = None

    async def health(self) -> HealthResponse:
        """Verificar conectividad del sistema."""
        response = await self.get("/health")
        return HealthResponse(**response.json())

    async def get_csrf_token(self) -> str:
        """Obtener CSRF token desde la página principal."""
        if self._csrf_token is not None:
            return self._csrf_token

        response = await self.client.get("/")
        # No validar con _handle_response, solo verificar errores críticos
        if response.status_code >= 400:
            self._handle_response(response)

        # Extraer token del HTML
        match = re.search(r'<meta name="csrf-token" content="([^"]+)"', response.text)
        if not match:
            raise CSRFError("No se pudo extraer CSRF token")

        self._csrf_token = match.group(1)
        assert self._csrf_token is not None
        return self._csrf_token

    async def get(self, path: str, **kwargs: Any) -> httpx.Response:
        """GET request."""
        return await self._request_with_reauth("GET", path, False, **kwargs)

    async def post(self, path: str, **kwargs: Any) -> httpx.Response:
        """POST request con CSRF token."""
        return await self._request_with_reauth("POST", path, True, **kwargs)

    async def patch(self, path: str, **kwargs: Any) -> httpx.Response:
        """PATCH request con CSRF token."""
        return await self._request_with_reauth("PATCH", path, True, **kwargs)

    async def delete(self, path: str, **kwargs: Any) -> httpx.Response:
        """DELETE request con CSRF token."""
        return await self._request_with_reauth("DELETE", path, True, **kwargs)

    async def _request_with_reauth(
        self,
        method: str,
        path: str,
        requires_csrf: bool,
        **kwargs: Any,
    ) -> httpx.Response:
        """Ejecutar request con re-autenticación en 401."""
        base_headers = dict(kwargs.pop("headers", {}))

        async def do_request() -> httpx.Response:
            request_kwargs = dict(kwargs)
            headers = dict(base_headers)
            if requires_csrf:
                headers["X-CSRF-Token"] = await self.get_csrf_token()
            if headers:
                request_kwargs["headers"] = headers
            response = await self.client.request(method, path, **request_kwargs)
            self._handle_response(response)
            return response

        try:
            return await do_request()
        except AuthenticationError:
            self._authenticated = False
            self._csrf_token = None
            await self.login()
            return await do_request()

    def _handle_response(self, response: httpx.Response) -> None:
        """Manejar errores HTTP."""
        if response.status_code < 400:
            return

        if response.status_code == 401:
            self._authenticated = False  # Marcar como no autenticado
            raise AuthenticationError("No autenticado o sesión inválida")

        if response.status_code == 403:
            self._csrf_token = None  # Invalidar token
            raise AuthorizationError("Sin permisos o CSRF inválido")

        if response.status_code == 404:
            raise NotFoundError("Recurso no encontrado")

        if response.status_code == 422:
            try:
                data = response.json()
                errors = data.get("errors") or {}
                message = data.get("error") or "Error de validación"
                raise ValidationError(message, errors=errors)
            except Exception:
                snippet = response.text.strip().replace("\n", " ")
                if len(snippet) > 200:
                    snippet = f"{snippet[:200]}..."
                raise ValidationError(f"Error de validación: {snippet}")

        if response.status_code >= 500:
            snippet = response.text.strip().replace("\n", " ")[:300]
            raise ServerError(f"Error del servidor: {response.status_code} — {snippet}")

        response.raise_for_status()

    # ============================================================================
    # Proyectos
    # ============================================================================

    async def list_projects(self) -> list[Project]:
        """Listar todos los proyectos."""
        response = await self.get("/proyectos.json")
        return [Project(**p) for p in response.json()]

    async def get_project(self, project_slug: str) -> Project:
        """Obtener detalles de un proyecto."""
        response = await self.get(f"/proyectos/{project_slug}.json")
        return Project(**response.json())

    async def create_project(self, data: ProjectCreate) -> Project:
        """Crear un nuevo proyecto."""
        response = await self.post("/proyectos.json", json={"proyecto": data.model_dump(mode="json")})
        return Project(**response.json())

    async def update_project(self, project_slug: str, data: ProjectUpdate) -> Project:
        """Actualizar un proyecto existente."""
        response = await self.patch(
            f"/proyectos/{project_slug}.json", json={"proyecto": data.model_dump(mode="json", exclude_none=True)}
        )
        return Project(**response.json())

    async def get_project_dashboard(self, project_slug: str) -> dict[str, Any]:
        """Obtener métricas del proyecto."""
        response = await self.get(f"/proyectos/{project_slug}/dashboard.json")
        return response.json()

    # ============================================================================
    # Tableros
    # ============================================================================

    async def list_boards(self, project_slug: str) -> list[Board]:
        """Listar tableros de un proyecto."""
        response = await self.get(f"/proyectos/{project_slug}/tableros.json")
        return [Board(**b) for b in response.json()]

    async def get_board(self, project_slug: str, board_slug: str) -> Board:
        """Obtener detalles de un tablero."""
        response = await self.get(f"/proyectos/{project_slug}/tableros/{board_slug}.json")
        return Board(**response.json())

    async def create_board(self, project_slug: str, data: BoardCreate) -> Board:
        """Crear un nuevo tablero."""
        response = await self.post(
            f"/proyectos/{project_slug}/tableros.json",
            json={"tablero": data.model_dump(mode="json", exclude_none=True)},
        )
        return Board(**response.json())

    # ============================================================================
    # Tareas (tarjetums)
    # ============================================================================

    async def list_tasks(
        self,
        project_slug: str,
        board_slug: str,
        estado: str | None = None,
        user_id: int | None = None,
        fecha_desde: str | None = None,
        fecha_hasta: str | None = None,
    ) -> list[Task]:
        """Listar tarjetums (tareas) de un tablero."""
        params = {}
        if estado:
            params["estado"] = estado
        if user_id:
            params["user_id"] = user_id
        if fecha_desde:
            params["fecha_desde"] = fecha_desde
        if fecha_hasta:
            params["fecha_hasta"] = fecha_hasta

        response = await self.get(
            f"/proyectos/{project_slug}/tableros/{board_slug}/tarjetums.json", params=params
        )
        return [Task(**t) for t in response.json()]

    async def get_task(self, project_slug: str, board_slug: str, task_slug: str) -> Task:
        """Obtener detalles de un tarjetum (tarea)."""
        response = await self.get(f"/proyectos/{project_slug}/tableros/{board_slug}/tarjetums/{task_slug}.json")
        return Task(**response.json())

    async def create_task(self, project_slug: str, board_slug: str, data: TaskCreate) -> Task:
        """Crear un nuevo tarjetum (tarea)."""
        response = await self.post(
            f"/proyectos/{project_slug}/tableros/{board_slug}/tarjetums.json",
            json={"tarjetum": data.model_dump(mode="json", exclude_none=True)},
        )
        return Task(**response.json())

    async def update_task(self, project_slug: str, board_slug: str, task_slug: str, data: TaskUpdate) -> Task:
        """Actualizar un tarjetum (tarea) existente."""
        response = await self.patch(
            f"/proyectos/{project_slug}/tableros/{board_slug}/tarjetums/{task_slug}.json",
            json={"tarjetum": data.model_dump(mode="json", exclude_none=True)},
        )
        return Task(**response.json())

    async def move_task_state(
        self, project_slug: str, board_slug: str, task_slug: str, data: TaskMoveState
    ) -> dict[str, Any]:
        """Mover tarjetum (tarea) a otro estado (drag & drop)."""
        response = await self.patch(
            f"/proyectos/{project_slug}/tableros/{board_slug}/tarjetums/{task_slug}/update_position.json",
            json={"tarjetum": data.model_dump(mode="json")},
        )
        return response.json()

    async def my_tasks(
        self,
        estados: list[str],
        project_slug: str | None = None,
    ) -> list[dict[str, Any]]:
        """Obtener tareas asignadas al usuario actual cross-proyecto/tablero."""
        projects = await self.list_projects()
        if project_slug:
            projects = [p for p in projects if p.slug == project_slug]

        results: list[dict[str, Any]] = []
        for project in projects:
            boards = await self.list_boards(project.slug)
            for board in boards:
                tasks = await self.list_tasks(
                    project.slug, board.slug, user_id=self.user_id,
                )
                for task in tasks:
                    if task.estado not in estados:
                        continue
                    d = task.model_dump(mode="json")
                    d["project_slug"] = project.slug
                    d["project_nombre"] = project.nombre
                    d["board_slug"] = board.slug
                    d["board_nombre"] = board.nombre
                    results.append(d)

        results.sort(key=lambda t: t.get("updated_at") or "", reverse=True)
        return results

    # ============================================================================
    # Comentarios
    # ============================================================================

    async def add_comment(self, project_slug: str, board_slug: str, task_slug: str, data: CommentCreate) -> dict[str, Any]:
        """Agregar comentario a un tarjetum (tarea)."""
        response = await self.post(
            f"/proyectos/{project_slug}/tableros/{board_slug}/tarjetums/{task_slug}/comments.json",
            json={"comment": data.model_dump(mode="json")},
        )
        content_type = response.headers.get("content-type", "")
        if "text/html" in content_type:
            raise ServerError("Respuesta HTML inesperada — el comentario no se creó (BUG-005)")
        try:
            return response.json()
        except Exception as exc:
            raise ServerError(f"Respuesta no-JSON inesperada: {response.text[:200]}") from exc

    # ── Checklist Items ──────────────────────────────────────────────────

    def _checklist_base(self, project_slug: str, board_slug: str, task_slug: str) -> str:
        return f"/proyectos/{project_slug}/tableros/{board_slug}/tarjetums/{task_slug}/checklist_items"

    async def create_checklist_item(
        self, project_slug: str, board_slug: str, task_slug: str, data: ChecklistItemCreate,
    ) -> ChecklistItem:
        """Crear checklist item."""
        response = await self.post(
            f"{self._checklist_base(project_slug, board_slug, task_slug)}.json",
            json={"checklist_item": data.model_dump(mode="json", exclude_none=True)},
        )
        return ChecklistItem(**response.json()["item"])

    async def update_checklist_item(
        self, project_slug: str, board_slug: str, task_slug: str, item_id: int, data: ChecklistItemUpdate,
    ) -> ChecklistItem:
        """Actualizar checklist item. Si completed viene, usa toggle."""
        base = self._checklist_base(project_slug, board_slug, task_slug)
        desired_completed = data.completed
        fields = data.model_dump(exclude_none=True, exclude={"completed"})

        item_data: dict | None = None

        if fields:
            response = await self.patch(
                f"{base}/{item_id}.json",
                json={"checklist_item": fields},
            )
            item_data = response.json()["item"]

        if desired_completed is not None:
            current = item_data["completed"] if item_data else None
            if current != desired_completed:
                toggle_resp = await self.patch(f"{base}/{item_id}/toggle.json")
                result = toggle_resp.json()["completed"]
                # Si no coincide (no teníamos current), toggle de nuevo
                if result != desired_completed:
                    toggle_resp = await self.patch(f"{base}/{item_id}/toggle.json")
                    result = toggle_resp.json()["completed"]
                if item_data:
                    item_data["completed"] = result
                else:
                    item_data = {"id": item_id, "tarjetum_id": 0, "title": "", "completed": result}

        return ChecklistItem(**item_data)

    async def delete_checklist_item(
        self, project_slug: str, board_slug: str, task_slug: str, item_id: int,
    ) -> None:
        """Eliminar checklist item."""
        base = self._checklist_base(project_slug, board_slug, task_slug)
        await self.delete(f"{base}/{item_id}.json")
