"""FastMCP server core - tools, resources, prompts."""

import json
from datetime import date
from typing import Any, Awaitable, Callable

from mcp.server.fastmcp import Context, FastMCP
from mcp.types import ToolAnnotations
from pydantic import Field

from amulen_mcp_server.amulen_client import AmulenClient
from amulen_mcp_server.config import get_config
from amulen_mcp_server.errors import AmulenError
from amulen_mcp_server.errors import ValidationError as AmulenValidationError
from amulen_mcp_server.schemas import (
    AddCommentInput,
    BoardCreate,
    ChecklistItemCreate,
    ChecklistItemUpdate,
    CommentCreate,
    CreateBoardInput,
    CreateChecklistItemInput,
    CreateProjectInput,
    CreateTaskInput,
    DeleteChecklistItemInput,
    GetBoardInput,
    GetProjectDashboardInput,
    GetProjectInput,
    GetTaskInput,
    HealthInput,
    ListBoardsInput,
    ListProjectsInput,
    ListTasksInput,
    MoveTaskStateInput,
    MyTasksInput,
    ProjectCreate,
    ProjectUpdate,
    ResponseFormat,
    TaskCreate,
    TaskEstado,
    TaskMoveState,
    TaskUpdate,
    UpdateChecklistItemInput,
    UpdateProjectInput,
    UpdateTaskInput,
)

READONLY_ANNOTATIONS = ToolAnnotations(
    readOnlyHint=True,
    destructiveHint=False,
    idempotentHint=True,
    openWorldHint=True,
)

WRITE_ANNOTATIONS = ToolAnnotations(
    readOnlyHint=False,
    destructiveHint=True,
    idempotentHint=False,
    openWorldHint=True,
)

app = FastMCP(
    name="amulen_mcp",
    instructions="Servidor MCP para integrar AMULEN (proyectos, tableros, tareas).",
)

_client: AmulenClient | None = None


async def get_client() -> AmulenClient:
    """Obtener cliente AMULEN inicializado."""
    global _client
    if _client is None:
        config = get_config()
        _client = AmulenClient(config)
        await _client.login()
    return _client


def _date_to_str(value: date | None) -> str | None:
    if value is None:
        return None
    return value.isoformat()


def _md_table(items: list[dict], columns: dict[str, str]) -> str:
    """Render lista como tabla markdown. columns = {key: header}."""
    header = "| " + " | ".join(columns.values()) + " |"
    sep = "| " + " | ".join("---" for _ in columns) + " |"
    rows = []
    for item in items:
        cells = []
        for key in columns:
            v = item.get(key, "")
            cells.append(str(v) if v is not None else "—")
        rows.append("| " + " | ".join(cells) + " |")
    return "\n".join([header, sep, *rows])


def _md_fields(item: dict, fields: dict[str, str]) -> str:
    """Render dict como lista de campos. fields = {key: label}."""
    lines = []
    for key, label in fields.items():
        v = item.get(key)
        if v is not None:
            lines.append(f"- **{label}:** {v}")
    return "\n".join(lines)


def _md_pagination(meta: dict[str, Any]) -> str:
    if not meta or not meta.get("has_more"):
        return ""
    return f"\n\n_Mostrando {meta['count']} de {meta['total_count']} (offset: {meta['offset']}, next: {meta['next_offset']})_"


def _format_success(
    summary: str,
    data: Any,
    response_format: ResponseFormat,
    meta: dict[str, Any] | None = None,
    content: str | None = None,
) -> dict[str, Any]:
    payload: dict[str, Any] = {
        "ok": True,
        "summary": summary,
        "data": data,
        "format": response_format,
    }
    if meta:
        payload["meta"] = meta
    if response_format == "markdown":
        payload["content"] = content or summary
    return payload


def _format_error(
    message: str,
    response_format: ResponseFormat,
    error_type: str,
    details: dict[str, Any] | None = None,
) -> dict[str, Any]:
    payload: dict[str, Any] = {
        "ok": False,
        "error": {"type": error_type, "message": message},
        "format": response_format,
    }
    if details:
        payload["error"]["details"] = details
    if response_format == "markdown":
        payload["content"] = f"Error: {message}"
    return payload


def _paginate(
    items: list[Any], limit: int, offset: int
) -> tuple[list[Any], dict[str, Any]]:
    total = len(items)
    start = min(offset, total)
    end = min(offset + limit, total)
    sliced = items[start:end]
    has_more = end < total
    meta = {
        "total_count": total,
        "count": len(sliced),
        "offset": offset,
        "has_more": has_more,
        "next_offset": end if has_more else None,
    }
    return sliced, meta


async def _handle_tool(
    response_format: ResponseFormat,
    func: Callable[[], Awaitable[dict[str, Any]]],
    ctx: Context | None = None,
) -> dict[str, Any]:
    try:
        return await func()
    except AmulenValidationError as exc:
        if ctx:
            await ctx.error(f"Validation error: {exc}")
        return _format_error(
            str(exc),
            response_format,
            exc.__class__.__name__,
            details=exc.errors,
        )
    except AmulenError as exc:
        if ctx:
            await ctx.error(f"AMULEN error: {exc}")
        return _format_error(str(exc), response_format, exc.__class__.__name__)
    except Exception as exc:
        if ctx:
            await ctx.error(f"Unexpected error: {exc}")
        return _format_error(str(exc), response_format, "UnexpectedError")


# ==========================================================================
# TOOLS
# ==========================================================================


@app.tool(
    name="amulen_health",
    description="Check AMULEN system connectivity",
    annotations=READONLY_ANNOTATIONS,
)
async def amulen_health(params: HealthInput) -> dict[str, Any]:
    """Health check del sistema AMULEN."""

    async def op() -> dict[str, Any]:
        client = await get_client()
        result = await client.health()
        data = result.model_dump(mode="json")
        data["user"] = {
            "id": client.user_id,
            "nombre": client.user_nombre,
            "email": client.config.email,
        }
        md = f"✅ AMULEN {result.status} — Usuario: {client.user_nombre} (id: {client.user_id}) — {result.timestamp}"
        return _format_success(
            f"Status: {result.status}", data, params.response_format, content=md
        )

    return await _handle_tool(params.response_format, op)


@app.tool(
    name="amulen_list_projects",
    description="List all projects",
    annotations=READONLY_ANNOTATIONS,
)
async def amulen_list_projects(params: ListProjectsInput) -> dict[str, Any]:
    """Lista proyectos con paginación."""

    async def op() -> dict[str, Any]:
        client = await get_client()
        projects = await client.list_projects()
        data = [p.model_dump(mode="json") for p in projects]
        page, meta = _paginate(data, params.limit, params.offset)
        summary = f"{meta['count']} proyectos (total {meta['total_count']})"
        md = _md_table(
            page, {"nombre": "Nombre", "slug": "Slug", "descripcion": "Descripción"}
        )
        md += _md_pagination(meta)
        return _format_success(summary, page, params.response_format, meta, content=md)

    return await _handle_tool(params.response_format, op)


@app.tool(
    name="amulen_get_project",
    description="Get project details",
    annotations=READONLY_ANNOTATIONS,
)
async def amulen_get_project(params: GetProjectInput) -> dict[str, Any]:
    """Obtiene un proyecto por slug."""

    async def op() -> dict[str, Any]:
        client = await get_client()
        project = await client.get_project(params.project_slug)
        data = project.model_dump(mode="json")
        md = _md_fields(
            data,
            {
                "nombre": "Nombre",
                "slug": "Slug",
                "descripcion": "Descripción",
                "created_at": "Creado",
            },
        )
        return _format_success(
            f"Proyecto: {project.nombre}", data, params.response_format, content=md
        )

    return await _handle_tool(params.response_format, op)


@app.tool(
    name="amulen_create_project",
    description="Create a new project",
    annotations=WRITE_ANNOTATIONS,
)
async def amulen_create_project(
    params: CreateProjectInput, ctx: Context
) -> dict[str, Any]:
    """Crea un proyecto nuevo."""
    await ctx.info(f"Create project: {params.nombre}")

    async def op() -> dict[str, Any]:
        client = await get_client()
        data = ProjectCreate(nombre=params.nombre, descripcion=params.descripcion)
        project = await client.create_project(data)
        d = project.model_dump(mode="json")
        md = f"✅ Proyecto creado: **{project.nombre}** (`{project.slug}`)"
        return _format_success(
            f"Proyecto creado: {project.nombre}", d, params.response_format, content=md
        )

    return await _handle_tool(params.response_format, op, ctx)


@app.tool(
    name="amulen_update_project",
    description="Update an existing project",
    annotations=WRITE_ANNOTATIONS,
)
async def amulen_update_project(
    params: UpdateProjectInput, ctx: Context
) -> dict[str, Any]:
    """Actualiza un proyecto existente."""
    await ctx.info(f"Update project: {params.project_slug}")

    async def op() -> dict[str, Any]:
        client = await get_client()
        data = ProjectUpdate(nombre=params.nombre, descripcion=params.descripcion)
        project = await client.update_project(params.project_slug, data)
        d = project.model_dump(mode="json")
        md = f"✅ Proyecto actualizado: **{project.nombre}** (`{project.slug}`)"
        return _format_success(
            f"Proyecto actualizado: {project.nombre}",
            d,
            params.response_format,
            content=md,
        )

    return await _handle_tool(params.response_format, op, ctx)


@app.tool(
    name="amulen_get_project_dashboard",
    description="Get project metrics and dashboard",
    annotations=READONLY_ANNOTATIONS,
)
async def amulen_get_project_dashboard(
    params: GetProjectDashboardInput,
) -> dict[str, Any]:
    """Obtiene métricas del proyecto."""

    async def op() -> dict[str, Any]:
        client = await get_client()
        dashboard = await client.get_project_dashboard(params.project_slug)
        md = f"Dashboard: **{params.project_slug}**\n\n"
        if isinstance(dashboard, dict):
            for k, v in dashboard.items():
                md += f"- **{k}:** {v}\n"
        return _format_success(
            f"Dashboard de {params.project_slug}",
            dashboard,
            params.response_format,
            content=md,
        )

    return await _handle_tool(params.response_format, op)


@app.tool(
    name="amulen_list_boards",
    description="List boards in a project",
    annotations=READONLY_ANNOTATIONS,
)
async def amulen_list_boards(params: ListBoardsInput) -> dict[str, Any]:
    """Lista tableros con paginación."""

    async def op() -> dict[str, Any]:
        client = await get_client()
        boards = await client.list_boards(params.project_slug)
        data = [b.model_dump(mode="json") for b in boards]
        page, meta = _paginate(data, params.limit, params.offset)
        summary = f"{meta['count']} tableros (total {meta['total_count']})"
        md = _md_table(
            page,
            {
                "nombre": "Nombre",
                "slug": "Slug",
                "bolsa_horas": "Bolsa",
                "horas_gastadas": "Horas",
            },
        )
        md += _md_pagination(meta)
        return _format_success(summary, page, params.response_format, meta, content=md)

    return await _handle_tool(params.response_format, op)


@app.tool(
    name="amulen_get_board",
    description="Get board details",
    annotations=READONLY_ANNOTATIONS,
)
async def amulen_get_board(params: GetBoardInput) -> dict[str, Any]:
    """Obtiene un tablero por slug."""

    async def op() -> dict[str, Any]:
        client = await get_client()
        board = await client.get_board(params.project_slug, params.board_slug)
        data = board.model_dump(mode="json")
        md = _md_fields(
            data,
            {
                "nombre": "Nombre",
                "slug": "Slug",
                "bolsa_horas": "Bolsa horas",
                "horas_totales": "Horas totales",
                "horas_gastadas": "Horas gastadas",
            },
        )
        return _format_success(
            f"Tablero: {board.nombre}", data, params.response_format, content=md
        )

    return await _handle_tool(params.response_format, op)


@app.tool(
    name="amulen_create_board",
    description="Create a new board in a project",
    annotations=WRITE_ANNOTATIONS,
)
async def amulen_create_board(params: CreateBoardInput, ctx: Context) -> dict[str, Any]:
    """Crea un tablero nuevo en un proyecto."""
    await ctx.info(f"Create board: {params.project_slug}/{params.nombre}")

    async def op() -> dict[str, Any]:
        client = await get_client()
        data = BoardCreate(
            nombre=params.nombre,
            bolsa_horas=params.bolsa_horas,
            horas_totales=params.horas_totales,
        )
        board = await client.create_board(params.project_slug, data)
        d = board.model_dump(mode="json")
        md = f"✅ Tablero creado: **{board.nombre}** (`{board.slug}`)"
        return _format_success(
            f"Tablero creado: {board.nombre}", d, params.response_format, content=md
        )

    return await _handle_tool(params.response_format, op, ctx)


@app.tool(
    name="amulen_list_tasks",
    description="List tasks in a board with optional filters",
    annotations=READONLY_ANNOTATIONS,
)
async def amulen_list_tasks(params: ListTasksInput) -> dict[str, Any]:
    """Lista tarjetums (tareas) con filtros y paginación."""

    async def op() -> dict[str, Any]:
        client = await get_client()
        tasks = await client.list_tasks(
            params.project_slug,
            params.board_slug,
            params.estado,
            params.user_id,
            _date_to_str(params.fecha_desde),
            _date_to_str(params.fecha_hasta),
        )
        data = [t.model_dump(mode="json") for t in tasks]
        for d in data:
            d.pop("comments", None)
            d.pop("checklist_items", None)
        page, meta = _paginate(data, params.limit, params.offset)
        summary = f"{meta['count']} tareas (total {meta['total_count']})"
        for t in page:
            t["asignados"] = ", ".join(u["nombre"] for u in t.get("assigned_users", []))
        md = _md_table(
            page,
            {
                "titulo": "Título",
                "slug": "Slug",
                "estado": "Estado",
                "asignados": "Asignados",
                "fecha_fin": "Vence",
            },
        )
        md += _md_pagination(meta)
        return _format_success(summary, page, params.response_format, meta, content=md)

    return await _handle_tool(params.response_format, op)


@app.tool(
    name="amulen_my_tasks",
    description="List my assigned tasks. Defaults to open tasks (TO DO, DOING) sorted by most recent. Useful for checking pending work without navigating projects and boards.",
    annotations=READONLY_ANNOTATIONS,
)
async def amulen_my_tasks(params: MyTasksInput) -> dict[str, Any]:
    """Lista tarjetums (tareas) asignadas al usuario actual cross-proyecto/tablero."""

    async def op() -> dict[str, Any]:
        client = await get_client()
        estados = [params.estado] if params.estado else ["TO DO", "DOING"]
        all_tasks = await client.my_tasks(estados, params.project_slug)
        for t in all_tasks:
            t.pop("comments", None)
            t.pop("checklist_items", None)
        page = all_tasks[: params.limit]
        total = len(all_tasks)
        summary = f"{len(page)} tareas asignadas (total {total}, estados: {', '.join(estados)})"
        md = _md_table(
            page,
            {
                "titulo": "Título",
                "project_nombre": "Proyecto",
                "board_nombre": "Tablero",
                "estado": "Estado",
                "updated_at": "Actualizado",
            },
        )
        if total > params.limit:
            md += f"\n_Mostrando {len(page)} de {total}_"
        return _format_success(summary, page, params.response_format, content=md)

    return await _handle_tool(params.response_format, op)


@app.tool(
    name="amulen_get_task",
    description="Get task details. Use include_details=true for comments and checklist items.",
    annotations=READONLY_ANNOTATIONS,
)
async def amulen_get_task(params: GetTaskInput) -> dict[str, Any]:
    """Obtiene un tarjetum (tarea) por slug."""

    async def op() -> dict[str, Any]:
        client = await get_client()
        task = await client.get_task(
            params.project_slug, params.board_slug, params.task_slug
        )
        data = task.model_dump(mode="json")
        data["asignados"] = ", ".join(
            u["nombre"] for u in data.get("assigned_users", [])
        )
        md = _md_fields(
            data,
            {
                "titulo": "Título",
                "slug": "Slug",
                "estado": "Estado",
                "descripcion": "Descripción",
                "fecha_inicio": "Inicio",
                "fecha_fin": "Vence",
                "puntuacion": "Puntos",
                "horas_proyectadas": "H. proyectadas",
                "horas_reales": "H. reales",
                "asignados": "Asignados",
            },
        )
        # Counters always shown
        cc = data.get("comments_count", 0) or 0
        ci = data.get("checklist_items_count", 0) or 0
        cd = data.get("checklist_completed_count", 0) or 0
        md += f"\n💬 Comments: {cc} | ✅ Checklist: {cd}/{ci}"
        # Details opt-in
        if params.include_details:
            if task.comments:
                md += "\n\n### 💬 Comments\n"
                for c in task.comments:
                    author = c.user.nombre if c.user else "?"
                    md += f"- **{author}** ({c.created_at[:10]}): {c.content}\n"
            if task.checklist_items:
                md += "\n### ✅ Checklist\n"
                for i in task.checklist_items:
                    mark = "✅" if i.completed else "⬜"
                    md += f"- {mark} {i.title}\n"
        if not params.include_details:
            data.pop("comments", None)
            data.pop("checklist_items", None)
        return _format_success(
            f"Tarea: {task.titulo}", data, params.response_format, content=md
        )

    return await _handle_tool(params.response_format, op)


@app.tool(
    name="amulen_create_task",
    description="Create a new task",
    annotations=WRITE_ANNOTATIONS,
)
async def amulen_create_task(params: CreateTaskInput, ctx: Context) -> dict[str, Any]:
    """Crea un tarjetum (tarea) nuevo."""
    await ctx.info(f"Create task: {params.project_slug}/{params.board_slug}")

    async def op() -> dict[str, Any]:
        client = await get_client()
        data = TaskCreate(
            titulo=params.titulo,
            descripcion=params.descripcion,
            estado=params.estado,
            fecha_inicio=params.fecha_inicio,
            fecha_fin=params.fecha_fin,
            puntuacion=params.puntuacion,
            horas_proyectadas=params.horas_proyectadas,
            user_ids=params.user_ids,
        )
        task = await client.create_task(params.project_slug, params.board_slug, data)
        d = task.model_dump(mode="json")
        d.pop("comments", None)
        d.pop("checklist_items", None)
        md = f"✅ Tarea creada: **{task.titulo}** (`{task.slug}`) — {task.estado}"
        return _format_success(
            f"Tarea creada: {task.titulo}", d, params.response_format, content=md
        )

    return await _handle_tool(params.response_format, op, ctx)


@app.tool(
    name="amulen_update_task",
    description="Update an existing task",
    annotations=WRITE_ANNOTATIONS,
)
async def amulen_update_task(params: UpdateTaskInput, ctx: Context) -> dict[str, Any]:
    """Actualiza un tarjetum (tarea) existente."""
    await ctx.info(
        f"Update task: {params.project_slug}/{params.board_slug}/{params.task_slug}"
    )

    async def op() -> dict[str, Any]:
        client = await get_client()
        data = TaskUpdate(
            titulo=params.titulo,
            descripcion=params.descripcion,
            estado=params.estado,
            fecha_inicio=params.fecha_inicio,
            fecha_fin=params.fecha_fin,
            puntuacion=params.puntuacion,
            horas_proyectadas=params.horas_proyectadas,
            horas_reales=params.horas_reales,
            user_ids=params.user_ids,
        )
        task = await client.update_task(
            params.project_slug,
            params.board_slug,
            params.task_slug,
            data,
        )
        d = task.model_dump(mode="json")
        d.pop("comments", None)
        d.pop("checklist_items", None)
        md = f"✅ Tarea actualizada: **{task.titulo}** (`{task.slug}`) — {task.estado}"
        return _format_success(
            f"Tarea actualizada: {task.titulo}", d, params.response_format, content=md
        )

    return await _handle_tool(params.response_format, op, ctx)


@app.tool(
    name="amulen_move_task_state",
    description="Move task to another state ",
    annotations=WRITE_ANNOTATIONS,
)
async def amulen_move_task_state(
    params: MoveTaskStateInput, ctx: Context
) -> dict[str, Any]:
    """Mueve un tarjetum (tarea) a otro estado."""
    await ctx.info(
        f"Move task state: {params.project_slug}/{params.board_slug}/{params.task_slug} → {params.estado}"
    )

    async def op() -> dict[str, Any]:
        client = await get_client()
        data = TaskMoveState(estado=params.estado)
        await client.move_task_state(
            params.project_slug,
            params.board_slug,
            params.task_slug,
            data,
        )
        d = {"task_slug": params.task_slug, "estado": params.estado}
        md = f"✅ Tarea movida: **{params.task_slug}** → {params.estado}"
        return _format_success(
            f"Tarea movida a: {params.estado}", d, params.response_format, content=md
        )

    return await _handle_tool(params.response_format, op, ctx)


@app.tool(
    name="amulen_add_comment",
    description="Add comment to a task",
    annotations=WRITE_ANNOTATIONS,
)
async def amulen_add_comment(params: AddCommentInput, ctx: Context) -> dict[str, Any]:
    """Agrega un comentario a un tarjetum (tarea)."""
    await ctx.info(
        f"Add comment: {params.project_slug}/{params.board_slug}/{params.task_slug}"
    )

    async def op() -> dict[str, Any]:
        client = await get_client()
        data = CommentCreate(contenido=params.contenido)
        result = await client.add_comment(
            params.project_slug,
            params.board_slug,
            params.task_slug,
            data,
        )
        md = f"✅ Comentario agregado en **{params.task_slug}**"
        return _format_success(
            "Comentario agregado", result, params.response_format, content=md
        )

    return await _handle_tool(params.response_format, op, ctx)


@app.tool(
    name="amulen_create_checklist_item",
    description="Create one or more checklist items in a task (batch)",
    annotations=WRITE_ANNOTATIONS,
)
async def amulen_create_checklist_item(
    params: CreateChecklistItemInput, ctx: Context
) -> dict[str, Any]:
    """Create checklist items in batch. Loops sequentially over the API."""
    await ctx.info(f"Create {len(params.items)} checklist item(s): {params.task_slug}")

    async def op() -> dict[str, Any]:
        client = await get_client()
        created: list[dict[str, Any]] = []
        errors: list[dict[str, Any]] = []
        for idx, entry in enumerate(params.items):
            try:
                item = await client.create_checklist_item(
                    params.project_slug,
                    params.board_slug,
                    params.task_slug,
                    ChecklistItemCreate(title=entry.title, description=entry.description),
                )
                created.append(item.model_dump(mode="json"))
            except Exception as exc:
                errors.append({"index": idx, "title": entry.title, "error": str(exc)})
        total = len(params.items)
        md = f"✅ {len(created)}/{total} checklist items created\n"
        for c in created:
            md += f"- **{c['title']}** (id: {c['id']})\n"
        if errors:
            md += "\n⚠️ Errors:\n"
            for e in errors:
                md += f"- [{e['index']}] {e['title']}: {e['error']}\n"
        data: dict[str, Any] | list[dict[str, Any]] = (
            {"created": created, "errors": errors} if errors else created
        )
        summary = f"{len(created)}/{total} checklist items created" if errors else f"{len(created)} checklist items created"
        return _format_success(summary, data, params.response_format, content=md)

    return await _handle_tool(params.response_format, op, ctx)


@app.tool(
    name="amulen_update_checklist_item",
    description="Update checklist item (title, description or mark completed)",
    annotations=WRITE_ANNOTATIONS,
)
async def amulen_update_checklist_item(
    params: UpdateChecklistItemInput, ctx: Context
) -> dict[str, Any]:
    """Actualiza un checklist item. Si completed se pasa, usa toggle internamente."""
    await ctx.info(f"Update checklist item: {params.item_id}")

    async def op() -> dict[str, Any]:
        client = await get_client()
        data = ChecklistItemUpdate(
            title=params.title,
            description=params.description,
            completed=params.completed,
        )
        item = await client.update_checklist_item(
            params.project_slug,
            params.board_slug,
            params.task_slug,
            params.item_id,
            data,
        )
        d = item.model_dump(mode="json")
        parts = []
        if params.title:
            parts.append(f"título: **{item.title}**")
        if params.completed is not None:
            parts.append(f"completed: {'✅' if item.completed else '⬜'}")
        md = f"✅ Checklist item actualizado (id: {item.id}) — {', '.join(parts) if parts else 'sin cambios'}"
        return _format_success(
            "Checklist item actualizado", d, params.response_format, content=md
        )

    return await _handle_tool(params.response_format, op, ctx)


@app.tool(
    name="amulen_delete_checklist_item",
    description="Delete checklist item from a task",
    annotations=WRITE_ANNOTATIONS,
)
async def amulen_delete_checklist_item(
    params: DeleteChecklistItemInput, ctx: Context
) -> dict[str, Any]:
    """Elimina un checklist item de un tarjetum (tarea)."""
    await ctx.info(f"Delete checklist item: {params.item_id}")

    async def op() -> dict[str, Any]:
        client = await get_client()
        await client.delete_checklist_item(
            params.project_slug,
            params.board_slug,
            params.task_slug,
            params.item_id,
        )
        md = f"🗑️ Checklist item eliminado (id: {params.item_id})"
        return _format_success(
            "Checklist item eliminado",
            {"id": params.item_id},
            params.response_format,
            content=md,
        )

    return await _handle_tool(params.response_format, op, ctx)


# ==========================================================================
# RESOURCES
# ==========================================================================


@app.resource("amulen://projects", description="Lista de proyectos AMULEN")
async def resource_projects() -> dict[str, Any]:
    client = await get_client()
    projects = await client.list_projects()
    data = [p.model_dump(mode="json") for p in projects]
    return {"summary": f"{len(data)} proyectos", "data": data}


@app.resource("amulen://projects/{project_slug}", description="Detalle de un proyecto")
async def resource_project_detail(project_slug: str) -> dict[str, Any]:
    client = await get_client()
    project = await client.get_project(project_slug)
    return {
        "summary": f"Proyecto: {project.nombre}",
        "data": project.model_dump(mode="json"),
    }


@app.resource(
    "amulen://projects/{project_slug}/boards/{board_slug}/tasks",
    description="Lista de tareas de un tablero",
)
async def resource_board_tasks(project_slug: str, board_slug: str) -> dict[str, Any]:
    client = await get_client()
    tasks = await client.list_tasks(project_slug, board_slug)
    data = [t.model_dump(mode="json") for t in tasks]
    return {"summary": f"{len(data)} tareas", "data": data}


# ==========================================================================
# PROMPTS
# ==========================================================================


@app.prompt(
    name="create_task_well_formed",
    title="Crear tarea bien formada",
    description="Guía para crear tareas completas y consistentes",
)
def create_task_well_formed(
    project_slug: str | None = Field(None, description="Slug del proyecto"),
    board_slug: str | None = Field(None, description="Slug del tablero"),
    titulo: str | None = Field(None, description="Título de la tarea"),
    descripcion: str | None = Field(None, description="Descripción breve"),
    estado: TaskEstado = Field("TO DO", description="Estado inicial"),
    fecha_fin: date | None = Field(None, description="Fecha fin (YYYY-MM-DD)"),
    user_ids: list[int] | None = Field(None, description="IDs de usuarios asignados"),
    comentario_inicial: str | None = Field(
        None, description="Comentario inicial opcional"
    ),
) -> str:
    provided: list[str] = []
    if project_slug:
        provided.append(f"- project_slug: {project_slug}")
    if board_slug:
        provided.append(f"- board_slug: {board_slug}")
    if titulo:
        provided.append(f"- titulo: {titulo}")
    if descripcion:
        provided.append("- descripcion: (provista)")
    if estado:
        provided.append(f"- estado: {estado}")
    if fecha_fin:
        provided.append(f"- fecha_fin: {fecha_fin.isoformat()}")
    if user_ids:
        provided.append(f"- user_ids: {user_ids}")
    if comentario_inicial:
        provided.append("- comentario_inicial: (provisto)")

    lines = [
        "Objetivo: crear una tarea bien formada en AMULEN.",
        "Si falta algún campo requerido, pídelo antes de ejecutar tools.",
        "Requeridos: project_slug, board_slug, titulo.",
        "Opcionales: descripcion, estado (default TO DO), fecha_fin, user_ids, comentario_inicial.",
    ]

    if provided:
        lines.append("Datos provistos:")
        lines.extend(provided)

    lines.extend(
        [
            "Paso a paso:",
            "1) Reúne los campos faltantes con preguntas concretas.",
            "2) Llama a amulen_create_task con los campos disponibles.",
            "3) Si comentario_inicial existe, llama a amulen_add_comment.",
            "4) Devuelve un resumen con el slug de la tarea creada.",
        ]
    )

    return "\n".join(lines)


def create_app() -> FastMCP:
    """Crear y retornar la instancia FastMCP."""
    return app
