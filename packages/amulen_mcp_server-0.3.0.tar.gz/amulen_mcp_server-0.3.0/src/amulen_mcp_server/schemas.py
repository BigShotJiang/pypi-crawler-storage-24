"""Pydantic schemas for tool inputs/outputs."""

from datetime import date, datetime
from typing import Literal

from pydantic import BaseModel, ConfigDict, Field, model_validator


# ============================================================================
# Health & Session
# ============================================================================


class HealthResponse(BaseModel):
    """Respuesta del endpoint /health."""

    status: str
    version: str | None = None
    timestamp: str
    database: str


# ============================================================================
# Proyectos
# ============================================================================


class Project(BaseModel):
    """Modelo de proyecto."""

    id: int
    nombre: str
    descripcion: str | None = None
    slug: str | None = None
    url: str | None = None
    created_at: str

    @model_validator(mode="after")
    def derive_slug(self) -> "Project":
        if self.slug is None and self.url:
            slug = self.url.rstrip("/").split("/")[-1]
            # Remover .json si está presente
            self.slug = slug.replace(".json", "")
        return self


class ProjectCreate(BaseModel):
    """Input para crear proyecto."""

    nombre: str = Field(..., min_length=1)
    descripcion: str | None = None


class ProjectUpdate(BaseModel):
    """Input para actualizar proyecto."""

    nombre: str | None = None
    descripcion: str | None = None


# ============================================================================
# Tableros
# ============================================================================


class Board(BaseModel):
    """Modelo de tablero."""

    id: int
    nombre: str
    slug: str
    bolsa_horas: bool
    horas_totales: float | None = None
    horas_gastadas: float | None = None


# ============================================================================
# Tareas (tarjetums)
# ============================================================================

TaskEstado = Literal["TO DO", "DOING", "DONE", "PENDING", "BACKLOG"]
ResponseFormat = Literal["markdown", "json"]


class BoardCreate(BaseModel):
    """Input para crear tablero."""

    nombre: str = Field(..., min_length=1)
    bolsa_horas: bool = False
    horas_totales: float | None = Field(None, ge=0)


class BaseToolInput(BaseModel):
    """Base tool input."""

    model_config = ConfigDict(
        str_strip_whitespace=True,
        validate_assignment=True,
        extra="forbid",
    )


class PaginationInput(BaseToolInput):
    """Pagination parameters."""

    limit: int = Field(50, ge=1, le=200, description="Maximum results")
    offset: int = Field(0, ge=0, description="Results offset")


class ResponseFormatInput(BaseToolInput):
    """Response format."""

    response_format: ResponseFormat = Field(
        "markdown",
        description="Output format: markdown or json",
    )


class AssignedUser(BaseModel):
    """Usuario asignado a un tarjetum."""

    id: int
    nombre: str
    email: str


# ============================================================================
# Comentarios
# ============================================================================


class Comment(BaseModel):
    """Comment model."""

    id: int
    content: str
    created_at: str
    user: AssignedUser | None = None


class CommentCreate(BaseModel):
    """Input para crear comentario."""

    contenido: str = Field(..., min_length=1)


# ============================================================================
# Checklist Items
# ============================================================================


class ChecklistItem(BaseModel):
    """Checklist item model."""

    id: int
    tarjetum_id: int | None = None
    title: str
    description: str | None = None
    completed: bool = False
    position: int | None = None


class ChecklistItemCreate(BaseModel):
    """Input para crear checklist item."""

    title: str = Field(..., min_length=1)
    description: str | None = None


class ChecklistItemUpdate(BaseModel):
    """Input para actualizar checklist item."""

    title: str | None = None
    description: str | None = None
    completed: bool | None = None


# ============================================================================
# Tareas (tarjetums)
# ============================================================================


class Task(BaseModel):
    """Task model."""

    id: int
    titulo: str
    slug: str
    descripcion: str | None = None
    estado: TaskEstado
    fecha_inicio: date | datetime | None = None
    fecha_fin: date | datetime | None = None
    puntuacion: int | None = None
    horas_proyectadas: float | None = None
    horas_reales: float | None = None
    assigned_users: list[AssignedUser] = Field(default_factory=list)
    updated_at: datetime | None = None
    comments_count: int | None = None
    checklist_items_count: int | None = None
    checklist_completed_count: int | None = None
    comments: list[Comment] = Field(default_factory=list)
    checklist_items: list[ChecklistItem] = Field(default_factory=list)


class TaskCreate(BaseModel):
    """Input para crear tarjetum."""

    titulo: str = Field(..., min_length=1)
    descripcion: str | None = None
    estado: TaskEstado = "TO DO"
    fecha_inicio: date | None = None
    fecha_fin: date | None = None
    puntuacion: int | None = Field(None, ge=0)
    horas_proyectadas: float | None = Field(None, ge=0)
    user_ids: list[int] = Field(default_factory=list)


class TaskUpdate(BaseModel):
    """Input para actualizar tarjetum."""

    titulo: str | None = None
    descripcion: str | None = None
    estado: TaskEstado | None = None
    fecha_inicio: date | None = None
    fecha_fin: date | None = None
    puntuacion: int | None = Field(None, ge=0)
    horas_proyectadas: float | None = None
    horas_reales: float | None = None
    user_ids: list[int] | None = None


class TaskMoveState(BaseModel):
    """Input para mover tarjetum a otro estado."""

    estado: TaskEstado


# ==========================================================================
# Tool Inputs
# ==========================================================================


class HealthInput(ResponseFormatInput):
    """Health check input."""


class ListProjectsInput(ResponseFormatInput, PaginationInput):
    """List projects input."""


class GetProjectInput(ResponseFormatInput):
    """Get project input."""

    project_slug: str = Field(..., min_length=1)


class CreateProjectInput(ResponseFormatInput):
    """Create project input."""

    nombre: str = Field(..., min_length=1)
    descripcion: str | None = None


class UpdateProjectInput(ResponseFormatInput):
    """Update project input."""

    project_slug: str = Field(..., min_length=1)
    nombre: str | None = None
    descripcion: str | None = None


class GetProjectDashboardInput(ResponseFormatInput):
    """Project dashboard input."""

    project_slug: str = Field(..., min_length=1)


class ListBoardsInput(ResponseFormatInput, PaginationInput):
    """List boards input."""

    project_slug: str = Field(..., min_length=1)


class GetBoardInput(ResponseFormatInput):
    """Get board input."""

    project_slug: str = Field(..., min_length=1)
    board_slug: str = Field(..., min_length=1)


class CreateBoardInput(ResponseFormatInput):
    """Create board input."""

    project_slug: str = Field(..., min_length=1)
    nombre: str = Field(..., min_length=1)
    bolsa_horas: bool = False
    horas_totales: float | None = Field(None, ge=0)


class ListTasksInput(ResponseFormatInput, PaginationInput):
    """List tasks input."""

    project_slug: str = Field(..., min_length=1)
    board_slug: str = Field(..., min_length=1)
    estado: TaskEstado | None = None
    user_id: int | None = Field(None, ge=0)
    fecha_desde: date | None = None
    fecha_hasta: date | None = None


class MyTasksInput(ResponseFormatInput):
    """List my assigned tasks input."""

    estado: TaskEstado | None = Field(None, description="Filter by state. No filter = TO DO + DOING")
    project_slug: str | None = Field(None, min_length=1, description="Limit to a specific project")
    limit: int = Field(20, ge=1, le=50, description="Maximum tasks to return")


class GetTaskInput(ResponseFormatInput):
    """Get task input."""

    project_slug: str = Field(..., min_length=1)
    board_slug: str = Field(..., min_length=1)
    task_slug: str = Field(..., min_length=1)
    include_details: bool = Field(False, description="Include comments and checklist items in response")


class CreateTaskInput(ResponseFormatInput):
    """Create task input."""

    project_slug: str = Field(..., min_length=1)
    board_slug: str = Field(..., min_length=1)
    titulo: str = Field(..., min_length=1)
    descripcion: str | None = None
    estado: TaskEstado = "TO DO"
    fecha_inicio: date | None = None
    fecha_fin: date | None = None
    puntuacion: int | None = Field(None, ge=0)
    horas_proyectadas: float | None = Field(None, ge=0)
    user_ids: list[int] = Field(default_factory=list)


class UpdateTaskInput(ResponseFormatInput):
    """Update task input."""

    project_slug: str = Field(..., min_length=1)
    board_slug: str = Field(..., min_length=1)
    task_slug: str = Field(..., min_length=1)
    titulo: str | None = None
    descripcion: str | None = None
    estado: TaskEstado | None = None
    fecha_inicio: date | None = None
    fecha_fin: date | None = None
    puntuacion: int | None = Field(None, ge=0)
    horas_proyectadas: float | None = Field(None, ge=0)
    horas_reales: float | None = Field(None, ge=0)
    user_ids: list[int] | None = None


class MoveTaskStateInput(ResponseFormatInput):
    """Move task state input."""

    project_slug: str = Field(..., min_length=1)
    board_slug: str = Field(..., min_length=1)
    task_slug: str = Field(..., min_length=1)
    estado: TaskEstado


class AddCommentInput(ResponseFormatInput):
    """Add comment input."""

    project_slug: str = Field(..., min_length=1)
    board_slug: str = Field(..., min_length=1)
    task_slug: str = Field(..., min_length=1)
    contenido: str = Field(..., min_length=1)


class ChecklistItemCreateEntry(BaseModel):
    """Single checklist item entry for batch creation."""

    title: str = Field(..., min_length=1)
    description: str | None = None


class CreateChecklistItemInput(ResponseFormatInput):
    """Create one or more checklist items in a task (batch)."""

    project_slug: str = Field(..., min_length=1)
    board_slug: str = Field(..., min_length=1)
    task_slug: str = Field(..., min_length=1)
    items: list[ChecklistItemCreateEntry] = Field(..., min_length=1, description="List of checklist items to create")


class UpdateChecklistItemInput(ResponseFormatInput):
    """Update checklist item input."""

    project_slug: str = Field(..., min_length=1)
    board_slug: str = Field(..., min_length=1)
    task_slug: str = Field(..., min_length=1)
    item_id: int = Field(..., description="Checklist item ID")
    title: str | None = None
    description: str | None = None
    completed: bool | None = Field(None, description="Mark/unmark completed (uses toggle internally)")


class DeleteChecklistItemInput(ResponseFormatInput):
    """Delete checklist item input."""

    project_slug: str = Field(..., min_length=1)
    board_slug: str = Field(..., min_length=1)
    task_slug: str = Field(..., min_length=1)
    item_id: int = Field(..., description="Checklist item ID")
