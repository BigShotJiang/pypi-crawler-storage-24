"""Entry point para ejecutar el servidor MCP via stdio."""

import argparse
import sys

from . import __version__


def run() -> None:
    """Entry point para el script."""
    parser = argparse.ArgumentParser(description="AMULEN MCP Server")
    parser.add_argument("--version", action="version", version=f"amulen-mcp-server {__version__}")
    parser.parse_args()

    print(f"amulen-mcp-server v{__version__} — iniciando en modo stdio...", file=sys.stderr)

    from .server_core import app

    app.run("stdio")


if __name__ == "__main__":
    run()
