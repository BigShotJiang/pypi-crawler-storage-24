"""AMULEN MCP Server - Integración con AMULEN API."""

__version__ = "0.3.0"
