"""Excepciones personalizadas para el cliente AMULEN."""


class AmulenError(Exception):
    """Excepción base para errores de AMULEN."""

    pass


class AuthenticationError(AmulenError):
    """Error de autenticación (401)."""

    pass


class AuthorizationError(AmulenError):
    """Error de autorización/permisos (403)."""

    pass


class NotFoundError(AmulenError):
    """Recurso no encontrado (404)."""

    pass


class ValidationError(AmulenError):
    """Error de validación (422)."""

    def __init__(self, message: str, errors: dict[str, list[str]] | None = None):
        super().__init__(message)
        self.errors = errors or {}


class ServerError(AmulenError):
    """Error del servidor (5xx)."""

    pass


class CSRFError(AmulenError):
    """Error relacionado con CSRF token."""

    pass
