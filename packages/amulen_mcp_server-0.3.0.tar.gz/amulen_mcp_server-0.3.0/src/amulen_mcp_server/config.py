"""Configuración del servidor MCP AMULEN."""

from pydantic_settings import BaseSettings, SettingsConfigDict


class AmulenConfig(BaseSettings):
    """Configuración para conexión con AMULEN API."""

    model_config = SettingsConfigDict(env_prefix="AMULEN_", env_file=".env", env_file_encoding="utf-8")

    base_url: str
    email: str
    password: str
    timeout_s: int = 20
    csrf_ttl_s: int = 600


def get_config() -> AmulenConfig:
    """Obtener configuración desde variables de entorno."""
    return AmulenConfig()
