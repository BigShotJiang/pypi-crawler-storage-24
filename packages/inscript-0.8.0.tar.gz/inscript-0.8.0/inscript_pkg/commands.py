"""CLI commands: tag, time, branch, resume, branches, overlap, cleanup, export, note."""
from __future__ import annotations

import json
import time
from datetime import datetime, timezone
from pathlib import Path

from . import (
    INSCRIPT_DIR,
    CONFIG_FILE,
    OVERLAP_DIR,
    SESSIONS_DIR,
    _format_tokens,
    _load_config,
    _load_jsonl,
    _load_prompts,
    active_session,
    list_sessions,
    session_dir,
)
from .replay import _format_duration


def _append_jsonl(path: Path, data: dict) -> None:
    """Append a JSON line to a file."""
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("a") as f:
        f.write(json.dumps(data, default=str) + "\n")


def _ts_to_secs(ts: str) -> int:
    """Convert HH:MM:SS to seconds since midnight."""
    parts = [int(x) for x in ts.split(":")]
    return parts[0] * 3600 + parts[1] * 60 + parts[2]


def _ts_diff(ts1: str, ts2: str) -> int:
    """Compute seconds between two HH:MM:SS timestamps. Handles midnight crossing."""
    try:
        s1 = _ts_to_secs(ts1)
        s2 = _ts_to_secs(ts2)
        diff = s2 - s1
        if diff < 0:
            diff += 86400
        return diff
    except (ValueError, IndexError):
        return 0


def compute_prompt_durations(
    prompts: list[dict],
    touches_by_prompt: dict[int | None, list[dict]],
) -> list[dict]:
    """Compute temporal breakdown for each prompt."""
    results = []
    for i, p in enumerate(prompts):
        idx = p.get("idx", 0)
        ts = p.get("ts", "")
        pts = touches_by_prompt.get(idx, [])

        total = None
        if i + 1 < len(prompts):
            next_ts = prompts[i + 1].get("ts", "")
            if ts and next_ts:
                total = _ts_diff(ts, next_ts)

        entry = {"idx": idx, "total": total, "touches": len(pts)}

        if pts and ts:
            touch_times = [t.get("ts", "") for t in pts if t.get("ts")]
            if touch_times:
                first = touch_times[0]
                last = touch_times[-1]
                think = _ts_diff(ts, first)
                work = _ts_diff(first, last)
                idle = _ts_diff(last, prompts[i + 1]["ts"]) if total and i + 1 < len(prompts) else 0
                entry.update({"think": think, "work": work, "idle": idle})
            else:
                entry.update({"think": 0, "work": 0, "idle": total or 0})
        else:
            entry.update({"think": 0, "work": 0, "idle": total or 0})

        results.append(entry)
    return results


def _format_secs(s: int) -> str:
    """Compact duration: 5s, 1m30s, 12m."""
    if s < 60:
        return f"{s}s"
    m, sec = divmod(s, 60)
    if sec == 0:
        return f"{m}m"
    return f"{m}m{sec}s"


def cmd_note(text: str, ref: str | None = None):
    """Add a note to the current session."""
    import sys as _sys
    from . import active_project

    if not text:
        print("Usage: inscript note \"your thought\" [--ref file.md]", file=_sys.stderr)
        _sys.exit(1)

    sess = active_session()
    if not sess:
        print("No active session", file=_sys.stderr)
        _sys.exit(1)

    sdir = session_dir(sess)
    prompts = _load_prompts(sdir)
    prompt_idx = prompts[-1].get("idx") if prompts else None

    entry: dict = {
        "ts": datetime.now(timezone.utc).strftime("%H:%M:%S"),
        "text": text,
    }
    if prompt_idx is not None:
        entry["prompt_idx"] = prompt_idx
    if ref:
        # Resolve ref to absolute path if it's a relative path
        ref_path = Path(ref)
        if not ref_path.is_absolute():
            proj = active_project()
            if proj:
                ref_path = proj / ref
        entry["ref"] = str(ref_path)

    tag_file = sdir / "active_tag"
    try:
        tag = tag_file.read_text().strip()
        if tag:
            entry["tag"] = tag
    except OSError:
        pass

    _append_jsonl(sdir / "notes.jsonl", entry)
    display = f"Note: {text}"
    if ref:
        display += f" -> {ref}"
    print(display)


def _format_notes(sess: str, notes: list[dict], prompts: list[dict], show_session: bool = False) -> list[str]:
    """Format notes for display. Returns lines."""
    lines = []
    prompt_map = {p.get("idx", 0): p for p in prompts}
    prefix = f"{sess[:8]} " if show_session else ""

    for n in notes:
        ts = n.get("ts", "?")
        text = n.get("text", "")
        ref = n.get("ref")
        pidx = n.get("prompt_idx")
        tag = n.get("tag")

        prompt_hint = ""
        if pidx is not None:
            p = prompt_map.get(pidx)
            if p:
                pt = p.get("prompt", "")[:40]
                prompt_hint = f" (after: \"{pt}\")"

        line = f"  {prefix}[{ts}] {text}"
        if ref:
            line += f"\n         {' ' * len(prefix)}-> {ref}"
        if tag:
            line += f"  #{tag}"
        if prompt_hint:
            line += f"\n        {' ' * len(prefix)}{prompt_hint}"
        lines.append(line)
        lines.append("")

    return lines


def cmd_notes(session_id: str | None = None, page: int = 0, page_size: int = 10):
    """List notes for a session, or all sessions if 'all'.

    When showing all sessions, results are paged (most recent first).
    Use --older to see the next batch.
    """
    if session_id == "all":
        all_sessions = list_sessions()
        all_notes = []
        all_refs = []
        for s in all_sessions:
            sid = s["session_id"]
            sdir = session_dir(sid)
            notes = _load_jsonl(sdir / "notes.jsonl")
            if notes:
                prompts = _load_prompts(sdir)
                all_notes.append((sid, notes, prompts))
                all_refs.extend(n.get("ref") for n in notes if n.get("ref"))

        if not all_notes:
            print("No notes across any session")
            return

        total = sum(len(notes) for _, notes, _ in all_notes)
        total_sessions = len(all_notes)

        # Page through sessions (most recent first, already sorted by list_sessions)
        start = page * page_size
        end = start + page_size
        batch = all_notes[start:end]

        if not batch:
            print("No more notes.")
            return

        showing = f"showing {start + 1}-{min(end, total_sessions)}" if total_sessions > page_size else ""
        print(f"{total} note(s) across {total_sessions} session(s)" +
              (f" ({showing})" if showing else "") + "\n")

        batch_refs = []
        for sid, notes, prompts in batch:
            meta_file = session_dir(sid) / "meta.json"
            start_time = ""
            if meta_file.exists():
                try:
                    start_time = json.loads(meta_file.read_text()).get("start_time", "")[:10]
                except (json.JSONDecodeError, OSError):
                    pass
            refs = sum(1 for n in notes if n.get("ref"))
            ref_hint = f", {refs} ref(s)" if refs else ""
            print(f"  {sid[:8]}  {start_time}  {len(notes)} note(s){ref_hint}")
            batch_refs.extend(n.get("ref") for n in notes if n.get("ref"))

        if batch_refs:
            print(f"\nReferenced files:")
            for r in sorted(set(batch_refs)):
                print(f"  {r}")

        if end < total_sessions:
            remaining = total_sessions - end
            print(f"\n  {remaining} more session(s) — inscript notes all --older")

        return

    if session_id:
        sess = session_id
    else:
        sess = active_session()
    if not sess:
        sessions = list_sessions()
        if sessions:
            sess = sessions[0]["session_id"]
        else:
            print("No sessions found")
            return

    sdir = session_dir(sess)
    notes = _load_jsonl(sdir / "notes.jsonl")
    if not notes:
        print(f"No notes in session {sess[:8]}")
        return

    prompts = _load_prompts(sdir)

    print(f"Session {sess[:8]} — {len(notes)} note(s)\n")
    for line in _format_notes(sess, notes, prompts):
        print(line)

    refs = [n.get("ref") for n in notes if n.get("ref")]
    if refs:
        print("Referenced files:")
        for r in refs:
            print(f"  {r}")


def cmd_tag(tag_name: str | None):
    sess = active_session()
    if not sess:
        print("No active session", file=__import__("sys").stderr)
        __import__("sys").exit(1)
    sdir = session_dir(sess)
    tag_file = sdir / "active_tag"
    if tag_name is None:
        try:
            tag_file.unlink()
        except OSError:
            pass
        print("Tag cleared")
    else:
        tag_file.write_text(tag_name + "\n")
        print(f"Tagged: {tag_name}")


def cmd_time(tag_filter: str | None):
    all_sessions = list_sessions()
    if not all_sessions:
        print("No sessions found")
        return

    tag_data: dict[str | None, dict] = {}

    for s in all_sessions:
        sid = s["session_id"]
        sdir = session_dir(sid)
        prompts = _load_prompts(sdir)
        touches: list[dict] = []
        touches_file = sdir / "touches.jsonl"
        if touches_file.exists():
            for line in touches_file.open():
                try:
                    touches.append(json.loads(line))
                except json.JSONDecodeError:
                    pass
        if not prompts:
            continue

        for i, p in enumerate(prompts):
            tag = p.get("tag")
            if tag_filter and tag != tag_filter:
                continue
            prompt_ts = p.get("ts", "")
            if i + 1 < len(prompts):
                next_ts = prompts[i + 1].get("ts", "")
            else:
                summary_file = sdir / "summary.json"
                if summary_file.exists():
                    try:
                        summary = json.loads(summary_file.read_text())
                        end = summary.get("end_time", "")
                        next_ts = end.split("T")[-1] if "T" in end else ""
                    except (json.JSONDecodeError, OSError):
                        next_ts = ""
                else:
                    block_touches = [t for t in touches if t.get("prompt_idx") == p.get("idx")]
                    next_ts = block_touches[-1].get("ts", "") if block_touches else ""

            block_seconds = _ts_diff(prompt_ts, next_ts)
            block_touches = [t for t in touches if t.get("prompt_idx") == p.get("idx")]
            block_files = {t.get("file") for t in block_touches}
            block_edits = sum(1 for t in block_touches if t.get("action") in ("edit", "write"))

            if tag not in tag_data:
                tag_data[tag] = {
                    "sessions": set(), "prompts": 0, "active_seconds": 0,
                    "first_ts": s.get("start_time", ""), "last_ts": s.get("start_time", ""),
                    "files": set(), "edits": 0, "prompt_texts": [],
                }
            td = tag_data[tag]
            td["sessions"].add(sid)
            td["prompts"] += 1
            td["active_seconds"] += block_seconds
            td["files"].update(block_files)
            td["edits"] += block_edits
            td["prompt_texts"].append(p.get("prompt", ""))
            session_time = s.get("start_time", "")
            if session_time < td["first_ts"] or not td["first_ts"]:
                td["first_ts"] = session_time
            if session_time > td["last_ts"]:
                td["last_ts"] = session_time

    if not tag_data:
        print(f"No data for tag: {tag_filter}" if tag_filter else "No prompt data found")
        return

    if tag_filter:
        td = tag_data.get(tag_filter)
        if not td:
            print(f"No data for tag: {tag_filter}")
            return
        print(f"Feature: {tag_filter}\n")
        print(f"  Sessions:     {len(td['sessions'])}")
        print(f"  Prompts:      {td['prompts']}")
        print(f"  Active time:  {_format_duration(td['active_seconds'])}")
        print(f"  Files:        {len(td['files'])}")
        print(f"  Edits:        {td['edits']}")
        print(f"  First:        {td['first_ts']}")
        print(f"  Last:         {td['last_ts']}")
        print(f"\n  Prompts:")
        for pt in td["prompt_texts"]:
            display = pt[:70] + "..." if len(pt) > 70 else pt
            print(f"    - \"{display}\"")
    else:
        print("Time by tag:\n")
        sorted_tags = sorted(tag_data.keys(), key=lambda t: (t is None, t or ""))
        for tag in sorted_tags:
            td = tag_data[tag]
            label = tag or "(untagged)"
            print(f"  {label}")
            print(f"    {_format_duration(td['active_seconds'])} active, {td['prompts']} prompts, {td['edits']} edits, {len(td['sessions'])} sessions")
            print()


def cmd_branch(reason: str | None):
    import sys as _sys
    if not reason:
        print("Usage: inscript branch \"reason for detour\"", file=_sys.stderr)
        _sys.exit(1)
    sess = active_session()
    if not sess:
        print("No active session", file=_sys.stderr)
        _sys.exit(1)
    sdir = session_dir(sess)
    parent = None
    active_branch_file = sdir / "active_branch"
    try:
        text = active_branch_file.read_text().strip()
        if text:
            parent = int(text)
    except (OSError, ValueError):
        pass
    branches = _load_jsonl(sdir / "branches.jsonl")
    next_id = max((b.get("id", -1) for b in branches), default=-1) + 1
    prompts = _load_prompts(sdir)
    prompt_idx = prompts[-1].get("idx") if prompts else None
    entry = {"type": "open", "id": next_id, "ts": datetime.now(timezone.utc).strftime("%H:%M:%S"), "reason": reason}
    if prompt_idx is not None:
        entry["prompt_idx"] = prompt_idx
    if parent is not None:
        entry["parent"] = parent
    _append_jsonl(sdir / "branches.jsonl", entry)
    active_branch_file.write_text(str(next_id) + "\n")
    if parent is not None:
        print(f"Branch #{next_id}: {reason} (nested in #{parent})")
    else:
        print(f"Branch #{next_id}: {reason}")


def cmd_resume():
    import sys as _sys
    sess = active_session()
    if not sess:
        print("No active session", file=_sys.stderr)
        _sys.exit(1)
    sdir = session_dir(sess)
    active_branch_file = sdir / "active_branch"
    try:
        text = active_branch_file.read_text().strip()
        branch_id = int(text) if text else None
    except (OSError, ValueError):
        branch_id = None
    if branch_id is None:
        print("No active branch to resume from")
        return
    branches = _load_jsonl(sdir / "branches.jsonl")
    parent = None
    reason = "?"
    for b in branches:
        if b.get("id") == branch_id and b.get("type") == "open":
            parent = b.get("parent")
            reason = b.get("reason", "?")
            break
    prompts = _load_prompts(sdir)
    prompt_idx = prompts[-1].get("idx") if prompts else None
    entry = {"type": "close", "id": branch_id, "ts": datetime.now(timezone.utc).strftime("%H:%M:%S")}
    if prompt_idx is not None:
        entry["prompt_idx"] = prompt_idx
    _append_jsonl(sdir / "branches.jsonl", entry)
    if parent is not None:
        active_branch_file.write_text(str(parent) + "\n")
        print(f"Closed branch #{branch_id} ({reason}), back to branch #{parent}")
    else:
        try:
            active_branch_file.unlink()
        except OSError:
            pass
        print(f"Closed branch #{branch_id} ({reason}), back to trunk")


def cmd_branches():
    sess = active_session()
    if not sess:
        sessions = list_sessions()
        if sessions:
            sess = sessions[0]["session_id"]
        else:
            print("No sessions found")
            return
    sdir = session_dir(sess)
    branches = _load_jsonl(sdir / "branches.jsonl")
    if not branches:
        print("No branches")
        return
    branch_info: dict[int, dict] = {}
    for b in branches:
        bid = b.get("id")
        if bid is None:
            continue
        if b.get("type") == "open":
            branch_info[bid] = {"reason": b.get("reason", "?"), "opened": b.get("ts", "?"), "prompt_idx": b.get("prompt_idx"), "parent": b.get("parent"), "closed": None}
        elif b.get("type") == "close" and bid in branch_info:
            branch_info[bid]["closed"] = b.get("ts", "?")
    active_bid = None
    try:
        text = (sdir / "active_branch").read_text().strip()
        active_bid = int(text) if text else None
    except (OSError, ValueError):
        pass
    touches = _load_jsonl(sdir / "touches.jsonl")
    branch_touches: dict[int, int] = {}
    branch_edits: dict[int, int] = {}
    for t in touches:
        bid = t.get("branch_id")
        if bid is not None:
            branch_touches[bid] = branch_touches.get(bid, 0) + 1
            if t.get("action") in ("edit", "write"):
                branch_edits[bid] = branch_edits.get(bid, 0) + 1
    print(f"Session: {sess}\n")
    for bid in sorted(branch_info):
        info = branch_info[bid]
        indent = "  " if info["parent"] is not None else ""
        status = "open" if info["closed"] is None else f"closed {info['closed']}"
        if bid == active_bid:
            status = "active"
        tc = branch_touches.get(bid, 0)
        ec = branch_edits.get(bid, 0)
        print(f"{indent}#{bid} {info['reason']}")
        print(f"{indent}  {info['opened']} → {status}, {tc} touches, {ec} edits")
    print()


def cmd_overlap():
    if not OVERLAP_DIR.exists():
        print("No overlap data")
        return
    for f in sorted(OVERLAP_DIR.iterdir()):
        if f.suffix != ".jsonl":
            continue
        entries = []
        for line in f.open():
            try:
                entries.append(json.loads(line))
            except json.JSONDecodeError:
                pass
        if not entries:
            continue

        project = entries[0].get("project", f.stem)
        conflicts = [e for e in entries if e.get("conflict")]
        touches = [e for e in entries if not e.get("conflict")]

        print(f"Project: {project}")

        if conflicts:
            # Group conflicts by file
            conflict_files: dict[str, list[dict]] = {}
            for c in conflicts:
                conflict_files.setdefault(c.get("file", "?"), []).append(c)
            print(f"  CONFLICTS ({len(conflicts)} writes to shared files):")
            for fpath, events in sorted(conflict_files.items()):
                sessions = set()
                for e in events:
                    for s in e.get("conflict_sessions", []):
                        sessions.add(s[:8])
                times = [e.get("ts", "") for e in events]
                print(f"    {fpath}")
                print(f"      sessions: {', '.join(sorted(sessions))}")
                print(f"      times: {', '.join(times[-5:])}")
            print()

        if touches:
            # Deduplicate recent overlaps by file
            recent: dict[str, dict] = {}
            for e in touches[-50:]:
                recent[e.get("file", "?")] = e
            print(f"  Overlaps ({len(recent)} files touched while concurrent):")
            for fpath, e in sorted(recent.items()):
                action = e.get("action", "touch")
                sids = [s[:8] for s in e.get("sessions", [])]
                print(f"    {action:<5} {fpath}  [{', '.join(sids)}]")
        print()


def cmd_cleanup():
    config = _load_config()
    policy = config.get("retention", {}).get("policy", "30d")
    if policy == "forever":
        print("Retention: forever. Nothing to clean.")
        return
    days = 30
    if policy.endswith("d"):
        try:
            days = int(policy[:-1])
        except ValueError:
            pass
    cutoff = time.time() - (days * 86400)
    removed = 0
    if SESSIONS_DIR.exists():
        import shutil
        for d in list(SESSIONS_DIR.iterdir()):
            try:
                if d.stat().st_mtime < cutoff:
                    shutil.rmtree(d)
                    removed += 1
            except OSError:
                pass
    print(f"Removed {removed} sessions older than {days} days")


def cmd_export(session_id: str):
    sdir = session_dir(session_id)
    meta_file = sdir / "meta.json"
    if not meta_file.exists():
        print(f"Session {session_id} not found", file=__import__("sys").stderr)
        __import__("sys").exit(1)
    meta = json.loads(meta_file.read_text())
    summary_file = sdir / "summary.json"
    touches_file = sdir / "touches.jsonl"
    diffs_file = sdir / "diffs.jsonl"
    print(f"# Session {session_id}\n")
    print(f"- **Project**: {meta.get('project', '?')}")
    print(f"- **Started**: {meta.get('start_time', '?')}")
    if summary_file.exists():
        s = json.loads(summary_file.read_text())
        print(f"- **Ended**: {s.get('end_time', '?')}")
        if s.get("duration_seconds"):
            print(f"- **Duration**: {_format_duration(s['duration_seconds'])}")
        print(f"- **Prompts**: {s.get('prompts', '?')}")
        print(f"- **Files read**: {s.get('files_read', '?')}")
        print(f"- **Files written**: {s.get('files_written', '?')}")
        print(f"- **Total edits**: {s.get('total_edits', '?')}")
        tokens = s.get("tokens")
        if tokens:
            print(f"- **Model**: {tokens.get('model', '?')}")
            print(f"- **Tokens**: {_format_tokens(tokens.get('total_tokens', 0))} total ({_format_tokens(tokens.get('input_tokens', 0))} in, {_format_tokens(tokens.get('output_tokens', 0))} out)")
            if tokens.get("cache_read_tokens"):
                print(f"- **Cache**: {_format_tokens(tokens['cache_read_tokens'])} read, {_format_tokens(tokens.get('cache_write_tokens', 0))} written")
    prompts = _load_prompts(sdir)
    touches_by_prompt: dict[int | None, list[dict]] = {}
    if touches_file.exists():
        for line in touches_file.open():
            try:
                e = json.loads(line)
                touches_by_prompt.setdefault(e.get("prompt_idx"), []).append(e)
            except json.JSONDecodeError:
                pass
    diffs_by_prompt: dict[int | None, list[dict]] = {}
    if diffs_file.exists():
        for line in diffs_file.open():
            try:
                d = json.loads(line)
                diffs_by_prompt.setdefault(d.get("prompt_idx"), []).append(d)
            except json.JSONDecodeError:
                pass
    if prompts:
        for p in prompts:
            idx = p.get("idx", 0)
            print(f"\n## \"{p.get('prompt', '?')}\"\n")
            print(f"*{p.get('ts', '')}*\n")
            touches = touches_by_prompt.get(idx, [])
            if touches:
                print("| Action | File | Details |")
                print("|--------|------|---------|")
                for t in touches:
                    details = ""
                    if t.get("lines_changed"):
                        details = f"{t['lines_changed']} lines"
                    elif t.get("lines"):
                        details = f"{t['lines']} lines"
                    print(f"| {t.get('action', '')} | `{t.get('file', '')}` | {details} |")
                print()
            diffs = diffs_by_prompt.get(idx, [])
            for d in diffs:
                if d.get("old_string") is not None:
                    print(f"**`{d.get('file', '?')}`**")
                    print(f"```diff\n- {d['old_string']}\n+ {d.get('new_string', '')}\n```\n")
                elif d.get("is_new"):
                    print(f"**`{d.get('file', '?')}`** — new file ({d.get('lines', '?')} lines)\n")
    else:
        if touches_by_prompt:
            print(f"\n## Activity\n")
            print("| Time | Action | File |")
            print("|------|--------|------|")
            for touches in touches_by_prompt.values():
                for e in touches:
                    print(f"| {e.get('ts', '')} | {e.get('action', '')} | `{e.get('file', '')}` |")
        if diffs_by_prompt:
            print(f"\n## Changes\n")
            for diffs in diffs_by_prompt.values():
                for d in diffs:
                    if d.get("old_string") is not None:
                        print(f"### `{d.get('file', '?')}` ({d.get('ts', '')})\n")
                        print(f"```diff\n- {d['old_string']}\n+ {d.get('new_string', '')}\n```\n")
                    elif d.get("is_new"):
                        print(f"New file `{d.get('file', '?')}` ({d.get('lines', '?')} lines)\n")


def _load_transcript(transcript_path: str | Path) -> list[dict]:
    """Load Claude Code conversation transcript from JSONL."""
    path = Path(transcript_path)
    if not path.exists():
        return []
    entries = []
    with path.open() as f:
        for line in f:
            try:
                entries.append(json.loads(line))
            except json.JSONDecodeError:
                pass
    return entries


def _extract_text_from_content(content) -> str:
    """Extract readable text from a message content field."""
    if isinstance(content, str):
        return content
    if isinstance(content, list):
        parts = []
        for block in content:
            if isinstance(block, dict):
                if block.get("type") == "text":
                    parts.append(block["text"])
            elif isinstance(block, str):
                parts.append(block)
        return "\n".join(parts)
    return ""


def _extract_tool_uses(content) -> list[dict]:
    """Extract tool_use blocks from message content."""
    if not isinstance(content, list):
        return []
    tools = []
    for block in content:
        if isinstance(block, dict) and block.get("type") == "tool_use":
            tools.append({
                "name": block.get("name", "?"),
                "id": block.get("id", ""),
                "input": block.get("input", {}),
            })
    return tools


def _extract_tool_results(content) -> dict[str, str]:
    """Extract tool_result blocks from content, keyed by tool_use_id."""
    if not isinstance(content, list):
        return {}
    results = {}
    for block in content:
        if isinstance(block, dict) and block.get("type") == "tool_result":
            tid = block.get("tool_use_id", "")
            rc = block.get("content", "")
            text = ""
            if isinstance(rc, str):
                text = rc
            elif isinstance(rc, list):
                parts = []
                for sub in rc:
                    if isinstance(sub, dict) and sub.get("type") == "text":
                        parts.append(sub["text"])
                text = "\n".join(parts)
            results[tid] = text
    return results


def _format_tool_use(tool: dict, result: str | None = None) -> list[str]:
    """Format a single tool use block as markdown lines."""
    name = tool["name"]
    inp = tool["input"]
    lines = []

    if name == "Bash":
        cmd = inp.get("command", "")
        desc = inp.get("description", "")
        header = f"**Bash**: {desc}" if desc else "**Bash**"
        lines.append(header)
        lines.append(f"```bash\n{cmd}\n```")
        if result is not None:
            out = result.strip()
            if out:
                # Truncate long output
                out_lines = out.split("\n")
                if len(out_lines) > 20:
                    out = "\n".join(out_lines[:20]) + f"\n... ({len(out_lines) - 20} more lines)"
                lines.append(f"```\n{out}\n```")
    elif name == "Read":
        fp = inp.get("file_path", "?")
        lines.append(f"**Read**: `{fp}`")
    elif name == "Write":
        fp = inp.get("file_path", "?")
        lines.append(f"**Write**: `{fp}`")
    elif name in ("Edit", "MultiEdit"):
        fp = inp.get("file_path", "?")
        lines.append(f"**Edit**: `{fp}`")
    elif name == "Glob":
        pat = inp.get("pattern", "?")
        path = inp.get("path", "")
        loc = f" in `{path}`" if path else ""
        lines.append(f"**Glob**: `{pat}`{loc}")
    elif name == "Grep":
        pat = inp.get("pattern", "?")
        path = inp.get("path", "")
        loc = f" in `{path}`" if path else ""
        lines.append(f"**Grep**: `{pat}`{loc}")
    elif name == "Agent":
        desc = inp.get("description", "?")
        lines.append(f"**Agent**: {desc}")
    elif name == "WebSearch":
        q = inp.get("query", "?")
        lines.append(f"**WebSearch**: {q}")
    elif name == "WebFetch":
        url = inp.get("url", "?")
        lines.append(f"**WebFetch**: `{url}`")
    elif name == "ToolSearch":
        # Skip internal tool loading
        return []
    else:
        # Generic fallback
        summary = ", ".join(f"{k}={str(v)[:60]}" for k, v in inp.items() if k != "type")
        lines.append(f"**{name}**({summary})")

    return lines


def _build_chat_timeline(transcript: list[dict]) -> list[dict]:
    """Build a chronological chat timeline from transcript entries.

    Returns list of dicts with: role, text, tools, tool_results, timestamp.
    Merges consecutive same-role messages.
    """
    # First pass: collect all tool results keyed by tool_use_id
    all_tool_results: dict[str, str] = {}
    for entry in transcript:
        content = entry.get("message", {}).get("content", [])
        results = _extract_tool_results(content)
        all_tool_results.update(results)

    timeline = []
    for entry in transcript:
        msg_type = entry.get("type")
        if msg_type not in ("user", "assistant"):
            continue
        message = entry.get("message", {})
        content = message.get("content", [])
        text = _extract_text_from_content(content)
        tools = _extract_tool_uses(content) if msg_type == "assistant" else []
        ts = entry.get("timestamp", "")

        # Skip empty entries (tool results, system messages)
        if not text and not tools:
            continue

        # Merge consecutive same-role messages
        if timeline and timeline[-1]["role"] == msg_type:
            if text:
                if timeline[-1]["text"]:
                    timeline[-1]["text"] += "\n" + text
                else:
                    timeline[-1]["text"] = text
            timeline[-1]["tools"].extend(tools)
        else:
            timeline.append({
                "role": msg_type,
                "text": text,
                "tools": tools,
                "timestamp": ts,
            })

    # Attach tool results to timeline entries
    for msg in timeline:
        msg["tool_results"] = all_tool_results

    return timeline


def _resolve_session_id(prefix: str) -> str | None:
    """Resolve a session ID prefix to full ID."""
    sdir = session_dir(prefix)
    if (sdir / "meta.json").exists():
        return prefix
    # Try prefix match
    from . import SESSIONS_DIR
    matches = [d.name for d in SESSIONS_DIR.iterdir() if d.is_dir() and d.name.startswith(prefix)]
    if len(matches) == 1:
        return matches[0]
    if len(matches) > 1:
        print(f"Ambiguous prefix '{prefix}', matches: {', '.join(sorted(matches))}", file=__import__("sys").stderr)
    return None


def _snapshot_codebase(project_path: str | Path, dest: Path) -> tuple[int, int]:
    """Copy the project working directory into dest, skipping noise.

    Returns (files_copied, bytes_copied).
    """
    import shutil
    import subprocess

    src = Path(project_path)
    if not src.is_dir():
        return 0, 0

    # Use git ls-files if available — respects .gitignore automatically
    git_files: list[str] | None = None
    try:
        result = subprocess.run(
            ["git", "ls-files", "-co", "--exclude-standard"],
            cwd=src, capture_output=True, text=True, timeout=10,
        )
        if result.returncode == 0:
            git_files = [f for f in result.stdout.strip().split("\n") if f]
    except (subprocess.TimeoutExpired, FileNotFoundError):
        pass

    # Hardcoded skip patterns for non-git dirs
    SKIP_DIRS = {
        ".git", "__pycache__", "node_modules", ".venv", "venv",
        "target", ".tox", ".mypy_cache", ".pytest_cache", ".ruff_cache",
        "dist", "build", ".eggs", "*.egg-info", ".next", ".nuxt",
        ".turbo", ".cache",
    }
    SKIP_EXTS = {
        ".pyc", ".pyo", ".so", ".dylib", ".dll", ".exe",
        ".o", ".a", ".class", ".jar",
        ".whl", ".tar", ".gz", ".zip", ".bz2",
    }
    MAX_FILE_SIZE = 2_000_000  # 2MB per file

    files_copied = 0
    bytes_copied = 0

    if git_files is not None:
        for rel in git_files:
            # Skip files inside known noise directories
            parts = Path(rel).parts
            if any(p in SKIP_DIRS or p.endswith(".egg-info") for p in parts):
                continue
            fpath = src / rel
            if not fpath.is_file():
                continue
            try:
                size = fpath.stat().st_size
                if size > MAX_FILE_SIZE:
                    continue
                if fpath.suffix.lower() in SKIP_EXTS:
                    continue
                # Quick binary check
                with fpath.open("rb") as f:
                    if b"\x00" in f.read(512):
                        continue
            except OSError:
                continue
            out_path = dest / rel
            out_path.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(fpath, out_path)
            files_copied += 1
            bytes_copied += size
    else:
        # Walk manually, skip known noise dirs
        for dirpath, dirnames, filenames in src.walk():
            # Prune skip dirs in-place
            dirnames[:] = [
                d for d in dirnames
                if d not in SKIP_DIRS and not d.endswith(".egg-info")
            ]
            for fname in filenames:
                fpath = dirpath / fname
                try:
                    size = fpath.stat().st_size
                    if size > MAX_FILE_SIZE:
                        continue
                    if fpath.suffix.lower() in SKIP_EXTS:
                        continue
                    with fpath.open("rb") as f:
                        if b"\x00" in f.read(512):
                            continue
                except OSError:
                    continue
                rel = fpath.relative_to(src)
                out_path = dest / rel
                out_path.parent.mkdir(parents=True, exist_ok=True)
                shutil.copy2(fpath, out_path)
                files_copied += 1
                bytes_copied += size

    return files_copied, bytes_copied


def cmd_chat_export(session_id: str, output_dir: str | None = None, snapshot: bool = False):
    """Export a complete session bundle: chat, notes, diffs, linked files."""
    import shutil

    resolved = _resolve_session_id(session_id)
    if resolved is None:
        print(f"Session {session_id} not found", file=__import__("sys").stderr)
        __import__("sys").exit(1)
    session_id = resolved
    sdir = session_dir(session_id)
    meta_file = sdir / "meta.json"

    meta = json.loads(meta_file.read_text())
    summary = {}
    summary_file = sdir / "summary.json"
    if summary_file.exists():
        summary = json.loads(summary_file.read_text())

    # Determine output directory
    if output_dir:
        out = Path(output_dir)
    else:
        out = Path.cwd() / f"inscript-export-{session_id[:8]}"
    out.mkdir(parents=True, exist_ok=True)

    prompts = _load_prompts(sdir)
    touches = _load_jsonl(sdir / "touches.jsonl")
    diffs = _load_jsonl(sdir / "diffs.jsonl")
    notes = _load_jsonl(sdir / "notes.jsonl")
    commits = _load_jsonl(sdir / "commits.jsonl")

    # Index touches and diffs by prompt
    touches_by_prompt: dict[int | None, list[dict]] = {}
    for t in touches:
        touches_by_prompt.setdefault(t.get("prompt_idx"), []).append(t)
    diffs_by_prompt: dict[int | None, list[dict]] = {}
    for d in diffs:
        diffs_by_prompt.setdefault(d.get("prompt_idx"), []).append(d)

    # Load transcript (assistant responses)
    transcript_path = meta.get("transcript_path")
    transcript = _load_transcript(transcript_path) if transcript_path else []
    chat_timeline = _build_chat_timeline(transcript)

    # Collect all files touched
    all_files = set()
    for t in touches:
        f = t.get("file")
        if f:
            all_files.add(f)

    # --- Write chat.md (full conversation with assistant responses) ---
    chat_lines = []
    chat_lines.append(f"# Chat — Session {session_id[:8]}\n")
    chat_lines.append(f"- **Project**: {meta.get('project', '?')}")
    chat_lines.append(f"- **Started**: {meta.get('start_time', '?')}")
    if summary.get("end_time"):
        chat_lines.append(f"- **Ended**: {summary['end_time']}")
    if summary.get("duration_seconds"):
        chat_lines.append(f"- **Duration**: {_format_duration(summary['duration_seconds'])}")
    chat_lines.append("")

    if chat_timeline:
        for msg in chat_timeline:
            role = msg["role"]
            text = msg["text"].strip()
            tools = msg["tools"]
            tool_results = msg.get("tool_results", {})
            if role == "user":
                chat_lines.append(f"## You\n")
                if text:
                    chat_lines.append(text)
                chat_lines.append("")
            else:
                chat_lines.append(f"## Claude\n")
                if text:
                    chat_lines.append(text)
                    chat_lines.append("")
                if tools:
                    for tool in tools:
                        result = tool_results.get(tool.get("id"))
                        fmt = _format_tool_use(tool, result)
                        if fmt:
                            chat_lines.extend(fmt)
                            chat_lines.append("")
                chat_lines.append("")
    else:
        # Fallback: use inscript prompts (no assistant responses)
        chat_lines.append("*(No transcript found — showing prompts only)*\n")
        for p in prompts:
            chat_lines.append(f"## Prompt {p.get('idx', '?')} — {p.get('ts', '')}\n")
            chat_lines.append(p.get("prompt", ""))
            chat_lines.append("")

    (out / "chat.md").write_text("\n".join(chat_lines))

    # --- Write activity.md (per-prompt file activity + diffs) ---
    act_lines = []
    act_lines.append(f"# Activity Log — Session {session_id[:8]}\n")
    if prompts:
        for p in prompts:
            idx = p.get("idx", 0)
            act_lines.append(f"## Prompt {idx}: \"{p.get('prompt', '?')[:80]}\"\n")
            act_lines.append(f"*{p.get('ts', '')}*\n")
            pt = touches_by_prompt.get(idx, [])
            if pt:
                act_lines.append("| Action | File | Details |")
                act_lines.append("|--------|------|---------|")
                for t in pt:
                    details = ""
                    if t.get("lines_changed"):
                        details = f"{t['lines_changed']} lines"
                    elif t.get("lines"):
                        details = f"{t['lines']} lines"
                    act_lines.append(f"| {t.get('action', '')} | `{t.get('file', '')}` | {details} |")
                act_lines.append("")
            pd = diffs_by_prompt.get(idx, [])
            for d in pd:
                if d.get("old_string") is not None:
                    act_lines.append(f"**`{d.get('file', '?')}`**")
                    act_lines.append(f"```diff\n- {d['old_string']}\n+ {d.get('new_string', '')}\n```\n")
                elif d.get("is_new"):
                    act_lines.append(f"**`{d.get('file', '?')}`** — new file ({d.get('lines', '?')} lines)\n")
    (out / "activity.md").write_text("\n".join(act_lines))

    # --- Write notes.md ---
    if notes:
        note_lines = []
        note_lines.append(f"# Notes — Session {session_id[:8]}\n")
        for n in notes:
            note_lines.append(f"### {n.get('ts', '')}")
            if n.get("prompt_idx") is not None:
                note_lines.append(f"*Prompt {n['prompt_idx']}*")
            if n.get("ref"):
                note_lines.append(f"*Ref: `{n['ref']}`*")
            note_lines.append("")
            note_lines.append(n.get("text", ""))
            note_lines.append("")
        (out / "notes.md").write_text("\n".join(note_lines))

    # --- Write commits.md ---
    if commits:
        commit_lines = []
        commit_lines.append(f"# Commits — Session {session_id[:8]}\n")
        for c in commits:
            commit_lines.append(f"### `{c.get('hash', '?')[:8]}` — {c.get('message', '?')}\n")
            commit_lines.append(f"*{c.get('ts', '')}* | Prompt {c.get('prompt_idx', '?')}")
            if c.get("contributing_prompts"):
                commit_lines.append(f"Contributing prompts: {c['contributing_prompts']}")
            if c.get("files"):
                commit_lines.append(f"Files: {', '.join(f'`{f}`' for f in c['files'])}")
            commit_lines.append("")
        (out / "commits.md").write_text("\n".join(commit_lines))

    # --- Copy linked files (snapshot of final state) ---
    files_dir = out / "files"
    copied = 0
    for fpath in sorted(all_files):
        src = Path(fpath)
        if not src.exists() or not src.is_file():
            continue
        # Skip huge files and binaries
        try:
            size = src.stat().st_size
            if size > 1_000_000:  # 1MB limit per file
                continue
            # Quick binary check
            with src.open("rb") as f:
                chunk = f.read(512)
                if b"\x00" in chunk:
                    continue
        except OSError:
            continue
        # Flatten into files/ dir, preserving enough path for uniqueness
        rel = src.name
        # If duplicate names, use parent/name
        dest = files_dir / rel
        if dest.exists():
            rel = f"{src.parent.name}_{src.name}"
            dest = files_dir / rel
        files_dir.mkdir(parents=True, exist_ok=True)
        shutil.copy2(src, dest)
        copied += 1

    # --- Snapshot codebase ---
    snap_files = 0
    snap_bytes = 0
    if snapshot:
        project_path = meta.get("project")
        if project_path and Path(project_path).is_dir():
            snap_dir = out / "codebase"
            snap_files, snap_bytes = _snapshot_codebase(project_path, snap_dir)

    # --- Write meta.json ---
    export_meta = {
        "session_id": session_id,
        "project": meta.get("project"),
        "start_time": meta.get("start_time"),
        "end_time": summary.get("end_time"),
        "duration_seconds": summary.get("duration_seconds"),
        "prompt_count": len(prompts),
        "files_touched": len(all_files),
        "files_copied": copied,
        "notes_count": len(notes),
        "commits_count": len(commits),
        "has_transcript": bool(chat_timeline),
        "snapshot": snapshot,
        "snapshot_files": snap_files,
        "snapshot_bytes": snap_bytes,
        "exported_at": datetime.now(timezone.utc).isoformat(),
    }
    (out / "meta.json").write_text(json.dumps(export_meta, indent=2))

    # --- Summary ---
    print(f"Exported to {out}/")
    print(f"  chat.md       — full conversation ({len(chat_timeline)} messages)")
    print(f"  activity.md   — file activity + diffs ({len(prompts)} prompts)")
    if notes:
        print(f"  notes.md      — {len(notes)} notes")
    if commits:
        print(f"  commits.md    — {len(commits)} commits")
    print(f"  files/        — {copied} file snapshots")
    if snapshot:
        def _fmt_bytes(n: int) -> str:
            if n < 1024: return f"{n}B"
            if n < 1024**2: return f"{n/1024:.1f}KB"
            return f"{n/1024**2:.1f}MB"
        print(f"  codebase/     — {snap_files} files ({_fmt_bytes(snap_bytes)})")
    print(f"  meta.json     — export metadata")


# ---------------------------------------------------------------------------
# permissions — analyze tool usage and generate permission profiles
# ---------------------------------------------------------------------------

def _generalize_bash_command(cmd: str) -> str | None:
    """Turn a specific Bash command into a generalized permission pattern.

    Returns a Bash(...) permission string, or None to skip.
    """
    cmd = cmd.strip()
    if not cmd:
        return None

    # For chained commands (&&), find the most significant one
    # e.g. "export PATH=... && cd /foo && cargo build --release"
    # → cargo build is the interesting part
    if " && " in cmd:
        segments = [s.strip() for s in cmd.split(" && ")]
        # Pick last non-trivial segment (skip export, cd, source)
        trivial = {"export", "cd", "source"}
        for seg in reversed(segments):
            first = seg.split()[0].split("/")[-1] if seg.split() else ""
            if first not in trivial:
                cmd = seg
                break
        else:
            cmd = segments[0]

    # Split on remaining pipes/semicolons — just look at the first command
    for sep in (" || ", " | ", " ; "):
        if sep in cmd:
            cmd = cmd.split(sep)[0].strip()

    # Strip leading env vars (FOO=bar cmd ...)
    parts = cmd.split()
    while parts and "=" in parts[0] and not parts[0].startswith("-"):
        parts.pop(0)
    if not parts:
        return None

    binary = parts[0]

    # Skip comments, shell noise
    if binary.startswith("#") or binary.startswith("\\"):
        return None

    # Skip overly-specific one-off commands (printf JSON-RPC, heredocs, etc.)
    if binary == "printf" and "jsonrpc" in cmd:
        return None

    # Skip shell fragments (for/do/done/fi from multi-line commands)
    if binary in ("for", "do", "done", "fi", "then", "else", "elif", "esac", "while", "case", "if"):
        return None

    # Resolve to basename for common tools
    basename = binary.split("/")[-1]

    # Commands that are safe to wildcard entirely
    SAFE_WILDCARDS = {
        "ls", "wc", "find", "grep", "cat", "head", "tail", "du", "df",
        "echo", "pwd", "which", "file", "stat", "readlink", "basename",
        "dirname", "sort", "uniq", "cut", "tr", "tee", "diff", "comm",
        "tree", "env", "printenv", "date", "uname", "whoami", "id",
        "pdfinfo", "pdftotext", "pdftoppm", "jq", "xargs",
        "time", "timeout", "jobs", "ps",
        "sed", "awk", "tput", "printf", "osascript",
    }
    if basename in SAFE_WILDCARDS:
        return f"Bash({basename}:*)"

    # Git — wildcard the whole thing
    if basename == "git":
        return "Bash(git:*)"
    if basename == "gh":
        return "Bash(gh:*)"

    # Cargo
    if basename == "cargo":
        return "Bash(cargo:*)"

    # Package managers — prefix match on subcommand
    if basename in ("pip", "pip3", "pipx"):
        if len(parts) > 1 and parts[1] in ("install", "show", "list", "index", "uninstall"):
            return f"Bash({basename} {parts[1]}:*)"
        return f"Bash({basename}:*)"
    if basename == "brew":
        return "Bash(brew:*)"

    # Python — wildcard
    if basename.startswith("python"):
        return f"Bash({basename}:*)"

    # Common utilities
    if basename in ("rsync", "cp", "mv", "mkdir", "chmod", "touch", "rm"):
        return f"Bash({basename}:*)"
    if basename in ("curl", "wget"):
        return f"Bash({basename}:*)"
    if basename == "open":
        return "Bash(open:*)"
    if basename in ("kill", "pkill"):
        return f"Bash({basename}:*)"

    # Rustup / cargo binaries
    if basename in ("rustc", "rustup"):
        return f"Bash({basename}:*)"

    # Source / export — safe
    if basename in ("source", "export"):
        return f"Bash({basename}:*)"

    # inscript
    if basename == "inscript":
        return "Bash(inscript:*)"

    # Local project binaries (./target/release/foo, ./build/foo, etc.)
    if binary.startswith("./"):
        return None  # project-specific, not generalizable

    # Venv python — generalize to the venv python prefix
    if ".venv/bin/" in binary or "/venv/bin/" in binary:
        # e.g. /Users/tatsu/tamachi/.venv/bin/python → .venv/bin/python:*
        return f"Bash({binary}:*)"

    # If starts with cd, allow
    if basename == "cd":
        return "Bash(cd:*)"

    # Fallback: prefix match on binary + first arg
    if len(parts) > 1:
        return f"Bash({binary} {parts[1]}:*)"
    return f"Bash({binary}:*)"


def _generalize_file_path(path: str, project: str | None) -> str:
    """Turn a specific file path into a Read/Write permission pattern.

    Claude Code uses // prefix for absolute paths in permission patterns.
    """
    # If under the project, use project root wildcard
    if project and path.startswith(project):
        return f"/{project}/**"
    # Common temp dirs
    if path.startswith("/tmp"):
        return "/tmp/**"
    if path.startswith("/private/tmp"):
        return "/private/tmp/**"
    if path.startswith("/var/folders") or path.startswith("/private/var/folders"):
        return "/private/tmp/**"  # macOS temp dirs
    # Home directory subdirs
    home = str(Path.home())
    if path.startswith(home):
        # Use first two path components after home
        rel = path[len(home):].lstrip("/")
        parts = rel.split("/")
        if len(parts) >= 2:
            return f"/{home}/{parts[0]}/**"
        return f"/{home}/**"
    return f"/{path}"


def cmd_permissions(session_id: str | None = None, apply: bool = False):
    """Analyze tool usage and generate a permissions profile.

    If session_id is given, analyze that session only.
    Otherwise, analyze all sessions for the current project.
    If --apply, write to settings.local.json.
    """
    from . import SESSIONS_DIR, active_session

    # Determine which sessions to analyze
    sessions_to_check = []
    if session_id:
        resolved = _resolve_session_id(session_id)
        if resolved:
            sessions_to_check = [resolved]
        else:
            print(f"Session {session_id} not found", file=__import__("sys").stderr)
            return
    else:
        # All sessions
        for sdir in SESSIONS_DIR.iterdir():
            if sdir.is_dir() and (sdir / "meta.json").exists():
                sessions_to_check.append(sdir.name)

    # Collect tool usage from transcripts
    bash_commands: list[str] = []
    read_paths: set[str] = set()
    write_paths: set[str] = set()
    web_domains: set[str] = set()
    has_web_search = False
    projects: set[str] = set()

    for sid in sessions_to_check:
        sdir = session_dir(sid)
        meta_file = sdir / "meta.json"
        if not meta_file.exists():
            continue
        meta = json.loads(meta_file.read_text())
        project = meta.get("project")
        if project:
            projects.add(project)

        transcript_path = meta.get("transcript_path")
        if not transcript_path or not Path(transcript_path).exists():
            continue

        with Path(transcript_path).open() as f:
            for line in f:
                try:
                    entry = json.loads(line)
                except json.JSONDecodeError:
                    continue
                if entry.get("type") != "assistant":
                    continue
                content = entry.get("message", {}).get("content", [])
                if not isinstance(content, list):
                    continue
                for block in content:
                    if not isinstance(block, dict) or block.get("type") != "tool_use":
                        continue
                    name = block.get("name", "")
                    inp = block.get("input", {})
                    if name == "Bash":
                        cmd = inp.get("command", "")
                        if cmd:
                            bash_commands.append(cmd)
                    elif name == "Read":
                        fp = inp.get("file_path", "")
                        if fp:
                            read_paths.add(fp)
                    elif name in ("Write", "Edit"):
                        fp = inp.get("file_path", "")
                        if fp:
                            write_paths.add(fp)
                    elif name == "WebFetch":
                        url = inp.get("url", "")
                        if url:
                            try:
                                from urllib.parse import urlparse
                                domain = urlparse(url).netloc
                                if domain:
                                    web_domains.add(domain)
                            except Exception:
                                pass
                    elif name == "WebSearch":
                        has_web_search = True

    # Generate permissions
    perms: set[str] = set()

    # Bash — generalize and deduplicate
    for cmd in bash_commands:
        p = _generalize_bash_command(cmd)
        if p:
            perms.add(p)

    # Read paths — generalize to directory patterns
    read_dirs: set[str] = set()
    for fp in read_paths:
        for proj in projects:
            pat = _generalize_file_path(fp, proj)
            read_dirs.add(pat)
            break
        else:
            read_dirs.add(_generalize_file_path(fp, None))
    for d in read_dirs:
        perms.add(f"Read({d})")

    # Write paths — same generalization
    write_dirs: set[str] = set()
    for fp in write_paths:
        for proj in projects:
            pat = _generalize_file_path(fp, proj)
            write_dirs.add(pat)
            break
        else:
            write_dirs.add(_generalize_file_path(fp, None))
    for d in write_dirs:
        perms.add(f"Edit({d})")
        perms.add(f"Write({d})")

    # Web
    for domain in web_domains:
        perms.add(f"WebFetch(domain:{domain})")
    if has_web_search:
        perms.add("WebSearch")

    # Deduplicate path rules: if Read(//Users/tatsu/**) exists,
    # remove Read(//Users/tatsu/tamachi/**) since it's subsumed
    def _dedup_path_perms(perm_set: set[str]) -> set[str]:
        result = set(perm_set)
        to_remove = set()
        path_perms = [p for p in result if "/**)" in p]
        for p1 in path_perms:
            # Extract the path prefix
            prefix1 = p1.split("(")[1].rstrip("/**)")
            tool1 = p1.split("(")[0]
            for p2 in path_perms:
                if p1 == p2:
                    continue
                prefix2 = p2.split("(")[1].rstrip("/**)")
                tool2 = p2.split("(")[0]
                if tool1 == tool2 and prefix2.startswith(prefix1 + "/"):
                    to_remove.add(p2)
        return result - to_remove

    perms = _dedup_path_perms(perms)
    sorted_perms = sorted(perms)

    if apply:
        settings_path = Path.home() / ".claude" / "settings.local.json"
        settings = {}
        if settings_path.exists():
            settings = json.loads(settings_path.read_text())

        existing = set(settings.get("permissions", {}).get("allow", []))
        merged = sorted(existing | perms)

        settings.setdefault("permissions", {})["allow"] = merged
        settings_path.write_text(json.dumps(settings, indent=2) + "\n")
        new_count = len(perms - existing)
        print(f"Applied {new_count} new permissions ({len(merged)} total) to {settings_path}")
    else:
        print(f"# Permissions profile ({len(sorted_perms)} rules from {len(sessions_to_check)} sessions)\n")
        print(f"# Projects: {', '.join(sorted(projects))}")
        print(f"# Bash: {len([p for p in sorted_perms if p.startswith('Bash')])} rules")
        print(f"# File: {len([p for p in sorted_perms if p.startswith(('Read', 'Edit', 'Write'))])} rules")
        print(f"# Web: {len([p for p in sorted_perms if p.startswith(('Web'))])} rules")
        print()
        for p in sorted_perms:
            print(p)
        print(f"\n# Run with --apply to write to ~/.claude/settings.local.json")
