class InvalidQueryValueException(Exception):
    pass
