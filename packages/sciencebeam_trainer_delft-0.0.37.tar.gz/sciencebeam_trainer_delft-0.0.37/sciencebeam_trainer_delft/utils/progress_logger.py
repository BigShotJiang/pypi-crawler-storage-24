import logging
from typing import Optional

from tqdm import tqdm


LOGGER = logging.getLogger()


class logging_tqdm(tqdm):
    def __init__(
        self,
        *args,
        logger: Optional[logging.Logger] = None,
        mininterval: float = 1,
        bar_format: str = '{desc}{percentage:3.0f}%{r_bar}',
        desc: str = 'progress: ',
        **kwargs
    ):
        self._logger = logger
        super().__init__(
            *args,
            mininterval=mininterval,
            bar_format=bar_format,
            desc=desc,
            **kwargs
        )

    @property
    def logger(self):
        if self._logger is not None:
            return self._logger
        return LOGGER

    def display(self, msg=None, pos=None):
        if not self.n:
            # skip progress bar before having processed anything
            return
        if not msg:
            msg = str(self)
        self.logger.info('%s', msg)
