# This file is original taken from https://github.com/haesleinhuepf/docx2markdown
# - src/docx2markdown/_docx_to_markdown.py
# It is being altered here to provide results needed for this project.
# original license: https://github.com/haesleinhuepf/docx2markdown/blob/main/LICENSE
# included here for completeness
#---
# BSD 3-Clause License
# Copyright (c) 2024, Robert Haase, ScaDS.AI, Uni Leipzig
# Redistribution and use in source and binary forms, with or without
# modification, are permitted provided that the following conditions are met:
# 1. Redistributions of source code must retain the above copyright notice, this
#    list of conditions and the following disclaimer.
# 2. Redistributions in binary form must reproduce the above copyright notice,
#    this list of conditions and the following disclaimer in the documentation
#    and/or other materials provided with the distribution.
# 3. Neither the name of the copyright holder nor the names of its
#    contributors may be used to endorse or promote products derived from
#    this software without specific prior written permission.
# THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
# AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
# IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
# DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE
# FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
# DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
# SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
# CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
# OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
# OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
#---
# All changes in the this version are Copyright (c) 2025, Paul Philion, Acme Rocket Company
# under the provided MIT license.

import re
import io

import humanize
import docx
import base64
import os
from lxml import etree
from pathlib import Path
import logging
from typing import Self
from io import BytesIO
from PIL import Image

from .page import Page, PageImage
from .converter import Converter


log = logging.getLogger(__name__)


class CommentBlock:
    def __init__(self, comments: list[int]):
        self.comments = comments
        self.anchor_id = f"comments{self.comments[0]}" # just using first comment ID


    def anchor(self) -> str:
        # generate a footnot marker for the comment-block
        #return f"[^{self.anchor_id}]"
        return f'<a name="{self.anchor_id}"></a>'


    def link(self, link_text: str = "Comments") -> str:
        return f'<a name="{self.anchor_id}-link"></a><sup>[{link_text}](#{self.anchor_id})</sup>'


    def backlink(self, link_text: str = "↩") -> str:
        return f'[{link_text}](#{self.anchor_id}-link)</sup></a>'


    def comments_from_doc(self, doc:docx.Document) -> str:
        """
        Build the comment block in markdown,
        as a footnote with formatting and time-ordered
        comments
        """
        comment_str = self.anchor() + "\n"
        for comment_id in self.comments:
            comment = doc.comments.get(comment_id)
            if comment:
                datestr = comment.timestamp.strftime('%y-%m-%d %H:%M')
                comment_str += f"{self.backlink()} **{comment.author}**<br/>\n*{datestr}*<br/>\n"
                # note: the comment might contain styling. this strips that. might FIXME
                comment_str += comment.text + "\n\n"

        comment_str += "---\n\n"
        return comment_str


    def __str__(self):
        return f"{self.anchor()}: {self.comments}"


    @staticmethod
    def from_run(run:docx.text.run.Run):
        """Returns a list of comments referenced in the run, or None"""
        if not run:
            return None

        # scan the next elements (siblings) for commentRangeEnd
        # and skipping empty runs.

        comments = []
        next = run._element.getnext()
        while next is not None:
            if isinstance(next, docx.oxml.text.run.CT_R):
                # skip empty text, break on non-empty
                if len(next.text) > 0:
                    break
            elif next.tag.endswith("commentRangeEnd"):
                # found a comment-end before the next text, store it
                comment_id = next.values()[0]
                comments.append(comment_id)
            next = next.getnext()

        if len(comments) > 0:
            return CommentBlock(comments)
        else:
            return None


# convert load DOCX file -> in-memory Page
def convert_file(docx_file:Path) -> Page:
    doc = docx.Document(docx_file)
    page = Page(
        id = "",
        title = extract_title(doc, docx_file),
        path = "",
        content = "",
        editor = "markdown",
        locale = "en",
        tags = doc.core_properties.keywords, # docx file metadata
        description = f"generated from: {docx_file}",
        isPublished = False,
        isPrivate = True,
    )
    return convert(doc, page)


# convert in-memory DOCX page -> in-memory Page
def convert_page(docx_page:Page) -> Page:
    doc = docx.Document(io.BytesIO(docx_page.content))
    return convert(doc, docx_page)


# convert in-memory doc -> in-memory
def convert(doc:docx.Document, page: Page) -> Page:
    # copy the images from the document
    # to the "page", so it can be managed
    # in different ways later
    process_images(doc, page)

    numbering = build_numbering_cache(doc)

    # handle doc metadata
    page.tags = doc.core_properties.keywords, # docx file metadata

    # Future NOTE: Page contains paragraphs, paragraphs contain styledtext (run)
    paragraphs = list(doc.paragraphs)
    tables = list(doc.tables)

    markdown = [] # array of markdown paragraphs/sections

    for block in doc.element.body:
        if block.tag.endswith('p'):  # Handle paragraphs
            paragraph = paragraphs.pop(0)  # Match current paragraph
            md_paragraph = ""

            ### switching on paragraph.style.name
            style_name = paragraph.style.name
            #print("STYLE:", style_name)

            if "Heading 1" in style_name:
                md_paragraph = "# "
            elif "Heading 2" in style_name:
                md_paragraph = "## "
            elif "Heading 3" in style_name:
                md_paragraph = "### "
            elif "Heading 4" in style_name:
                md_paragraph = "#### "
            elif "Heading 5" in style_name:
                md_paragraph = "##### "
            elif "Normal" or "normal" in style_name:
                if is_list(paragraph):
                    typeId, level = get_marker(paragraph)
                    list_format = numbering.get(typeId, level)
                    # expected not to be null
                    md_paragraph = str(list_format)

                    # old md_paragraph = get_bullet_point_prefix(doc, paragraph)
            else:
                log.error("Unsupported style:", style_name)

            styled = StyledText.from_run(paragraph, page)
            if styled is not None:
                content = str(styled)
                md_paragraph += content
                if len(md_paragraph) > 0:
                    markdown.append(md_paragraph)

        elif block.tag.endswith('tbl'):  # Handle tables (if present)
            table = tables.pop(0)  # Match current table
            table_text = ""
            for i, row in enumerate(table.rows):
                table_text += "| " + " | ".join(cell.text.strip() for cell in row.cells) + " |\n"
                if i == 0:
                    table_text += "| " + " | ".join("---" for _ in row.cells) + " |\n"

            markdown.append(table_text)

        elif block.tag.endswith('sectPr') or block.tag.endswith('sdt'):
            # ignore
            #log.debug(f"!!! section ptr: {block}")
            pass
        else:
            log.warning("Unknown block:", page.title, block.tag)

    # append comments as footnotes
    for block in page.comments:
        #log.warning(f"BLOCK: {block.anchor()} - {block.comments}")
        markdown.append(block.comments_from_doc(doc))

    page.content = "\n\n".join(markdown)

    return page


SKIP_TITLES = ["Word Document"]

def extract_title(doc: docx.Document, path: Path) -> str:
    if doc.core_properties.title and len(doc.core_properties.title) > 0 and doc.core_properties.title not in SKIP_TITLES:
        return doc.core_properties.title
    else:
        return path.stem


# def comments(doc:docx.Document) -> list[str]:
#     comments = []
#     for comment in doc.comments:
#         # author, text, timestamp
#         datestr = comment.timestamp.strftime('%y-%m-%d %H:%M')
#         comments.append(f"\n[^{comment.comment_id}]: At {datestr}, {comment.author} said: {comment.text.strip()}")
#         log.debug(comment)
#     return comments


def write_images(doc:docx.Document, outroot:Path):
    # save all images
    image_folder = Path(outroot, "images")
    images = {}
    for rel in doc.part.rels.values():
        if "image" in rel.reltype:
            image_filename = save_image(rel.target_part, image_folder)
            images[rel.rId] = image_filename[len(outroot)+1:]
            # use relative
            log.info("image file:", rel.rId, ":", image_filename, "-->", images[rel.rId])
        # else:
        #     log.info(f"rel.rId={rel.rId}, rel.reltype={rel.reltype}")
    return images


MAX_UPLOAD_SIZE = 5 * 1000 * 1000
OVERSIZE_SIZE = 1000 # px
OVERSIZE_SCALE_FACTOR = 0.5


# FIXME: Refactor image scaling to use a flag!
def image_scale_factor(doc:docx.Document) -> float:
    """Analyze the images to determine total encoded size, and what % that has to be reduced"""
    total_size = 0
    for rel in doc.part.rels.values():
        if "image" in rel.reltype:
            # rId is in the form "rId18"
            #anchor = f"image{rel.rId[3:]}"
            content = base64.b64encode(rel.target_part.blob).decode('utf-8')
            total_size += len(content)

    if total_size < MAX_UPLOAD_SIZE:
        return 1.0 # no scale!
    else:
        return MAX_UPLOAD_SIZE / total_size


def embedded_images(doc:docx.Document) -> list[str]:
    """
    Append DOCX images inline in the markdown.
    Produces a list of base64-encoded images.
    """

    scale_factor = image_scale_factor(doc)
    #log.info(f"=== scale factor: {scale_factor * 100:.2f}%")

    images = []
    total_size = 0
    max = 0
    for rel in doc.part.rels.values():
        if "image" in rel.reltype:
            # rId is in the form "rId18"
            anchor = f"image{rel.rId[3:]}" # image18
            encoded = compress_image(rel.target_part, scale_factor)
            encoded_image_size = len(encoded)
            total_size += encoded_image_size
            if encoded_image_size > max:
                max = encoded_image_size
            #log.info(f"IMAGE id: {anchor}, size: {humanize.naturalsize(encoded_image_size)}, running total: {humanize.naturalsize(total_size)}")
            images.append(f"[{anchor}]: <data:image/png;base64,{encoded}>\n\n")

    #log.warning(f"Total image size: {humanize.naturalsize(total_size)}, {len(images)} images")
    if total_size > MAX_UPLOAD_SIZE:
        log.warning(f"--- Total image size: {humanize.naturalsize(total_size)} exceeds {humanize.naturalsize(MAX_UPLOAD_SIZE)}")
        num_images = len(images)
        average = 1.0 * total_size / num_images
        log.warning(f"--- Total images: {num_images}, avg size: {humanize.naturalsize(average)}, max: {humanize.naturalsize(max)}")

    return images


def compress_image(target, scale_factor:float) -> str:
    content = target.blob
    #before = len(base64.b64encode(content).decode('utf-8'))
    #name = target.partname

    image_data = BytesIO(content)
    image = Image.open(image_data)

    #log.info(f"IMAGE {name}, type: {target.content_type}")
    image_format = target.content_type.lower()
    if image_format.startswith("image/"):
        image_format = image_format[6:]

    #if scale_factor < 1.0:
    if image.size[0] > OVERSIZE_SIZE or image.size[1] > OVERSIZE_SIZE:
        # resize the image
        w = round(image.size[0] * OVERSIZE_SCALE_FACTOR)
        h = round(image.size[1] * OVERSIZE_SCALE_FACTOR)
        #log.info(f"RESIZE {name}: {image.size[0]}, {image.size[1]} -> {w}, {h}")
        image = image.resize((w, h), Image.LANCZOS)

    compressed = BytesIO()
    image.save(compressed, format=image_format, quality=85, optimize=True)
    compressed = compressed.getbuffer()

    # don't know why, but it's often the case
    if len(compressed) > len(content):
        compressed = content

    encoded = base64.b64encode(compressed).decode('utf-8')
    #after = len(encoded)
    #log.info(f"IMAGE {name}, before: {humanize.naturalsize(before)}, after: {humanize.naturalsize(after)}, {after/before*100:.2f}%, dim:{image.size}")

    return encoded


# content = rel.target_part.blob
# content_type = rel.target_part.content_type
def compress(content:bytes, content_type:str, quality:int=85) -> bytes:
    image_data = BytesIO(content)
    image = Image.open(image_data)

    image_format = content_type.lower()
    if image_format.startswith("image/"):
        image_format = image_format[6:]

    compressed = BytesIO()
    image.save(compressed, format=image_format, quality=quality, optimize=True)
    compressed = compressed.getbuffer()

    # don't know why, but it's often the case
    if len(compressed) > len(content):
        compressed = content
    else:
        log.info(f"Compressed image by {100-(len(compressed)/len(content))*100:.2f}%")

    return compressed


def extract_r_embed(xml_string):
    """
    Extract the value of r:embed from the given XML string.

    :param xml_string: The XML content as a string.
    :return: The value of r:embed or None if not found.
    """
    # Parse the XML
    root = etree.fromstring(xml_string)

    # Define the namespaces
    namespaces = {
        'a': "http://schemas.openxmlformats.org/drawingml/2006/main",
        'r': "http://schemas.openxmlformats.org/officeDocument/2006/relationships",
        'pic': "http://schemas.openxmlformats.org/drawingml/2006/picture",
    }

    # Use XPath to find the <a:blip> element with r:embed
    blip = root.find(".//a:blip", namespaces=namespaces)

    # Extract the r:embed attribute value
    if blip is not None:
        return blip.attrib.get("{http://schemas.openxmlformats.org/officeDocument/2006/relationships}embed")
    return None


def extract_comment_id(xml_string) -> int:
    """
    Extract the value of w:commentReference w:id="3" the given XML string.
    :param xml_string: The XML content as a string.
    """
    # Parse the XML
    # root = etree.fromstring(xml_string)
    # elem = root.find(".//commentReference")
    # if elem:
    #     log.debug(f"found comment! {elem}")
    #     return elem.get("id", None)  # Default to empty string
    # That's not working, try regex
    # <w:commentReference w:id="3">
    # HACK but it works
    regex = re.compile(r"w:commentReference w:id=\"(\d+)\"")
    m = regex.search(xml_string)
    if m:
        return int(m[1])
    else:
        return None


# for in-memory image set:
# - name = doc-path + image_part.partname
# - content = image_part.blob
# - rID - the resource ID from
def get_image(image_part) -> PageImage:
    filename = image_part.partname.replace("\\", "/")
    if filename.startswith("/word/media/"):
        filename = filename[12:]
    return PageImage(filename, image_part.blob)


def process_images(doc:docx.Document, page:Page):
    for rel in doc.part.rels.values():
        if "image" in rel.reltype:
            image = get_image(rel.target_part)

            # check image size
            # TODO: max size and "quality" (60, here) should be configurable
            # the problem is referencing the context for config: how is it referenced?
            if len(image.content) > MAX_UPLOAD_SIZE:
                compressed_content = compress(image.content, image.mimetype, 60)
                image.content = compressed_content

            page.add_image(rel.rId, image)


def save_image(image_part, output_folder):
    """Save an image to the output folder and return the filename."""
    os.makedirs(output_folder, exist_ok=True)
    image_filename = os.path.join(output_folder, os.path.basename(image_part.partname))
    with open(image_filename, "wb") as img_file:
        img_file.write(image_part.blob)
    return str(image_filename).replace("\\", "/")


def get_list_level(paragraph):
    """Determine the level of a bullet point or numbered list item."""
    # Access the raw XML of the paragraph
    p = paragraph._element
    numPr = p.find(".//w:numPr", namespaces=p.nsmap)
    if numPr is not None:
        ilvl = numPr.find(".//w:ilvl", namespaces=p.nsmap)
        if ilvl is not None:
            return int(ilvl.get("{http://schemas.openxmlformats.org/wordprocessingml/2006/main}val"))
    return 0


# <w:start w:val="1"/>
# <w:numFmt w:val="bullet"/>
# <w:pStyle w:val="ListBullet3"/>
# <w:lvlText w:val=""/>
# <w:lvlJc w:val="left"/>
class NumberingDef:
    def __init__(self, abstractId: int, level: int, format: str, style: str, text: str):
        self.abstractId = int(abstractId)
        self.level = int(level)
        self.format = format
        self.style = style
        self.text = text

    def is_bullet(self) -> bool:
        return self.format == "bullet"


    def marker(self) -> str:
        _numbering_types = {
            "lowerRoman": "i. ",
            "lowerLetter": "a. ",
            "upperRoman": "I. ",
            "upperLetter": "A. ",
            "decimal": "1. ",
            "bullet": "* ",
            "checkBox": "- [ ] ",
        }
        if self.format in _numbering_types:
            return _numbering_types[self.format]
        else:
            log.warning(f"Unknown list type: {self.__repr__()}")


    def __str__(self):
        # intention: render the specific numbering
        return ("    " * self.level) + self.marker()


    def __repr__(self):
        return f"Numbering: format={self.format}, text={self.text}, style={self.style}"


class NumberingCache:
    def __init__(self):
        self.numbering = {}


    def append(self, id: int, level: int, format: NumberingDef):
        # if id or level are strings, convert to ints
        id = int(id)
        level = int(level)

        if id not in self.numbering:
            self.numbering[id] = {}
        self.numbering[id][level] = format


    def get(self, id: int, level: int) -> NumberingDef:
        return self.numbering[id][level]


class DefaultNumbering(NumberingCache):
    def get(self, id:int, level:int) -> NumberingDef:
        _formats = [
            "decimal",
            "decimal",
            "decimal",
            "decimal",
            "bullet",
            "bullet",
            "bullet",
            "decimal",
            "bullet",
        ]
        result = super().get(id, level)
        if result is not None:
            return result
        else:
            return NumberingDef(id, level, format=_formats[id], style=None, text=None)


def build_numbering_cache(doc: docx.document.Document) -> NumberingCache:
    # 2 tier: numid and level
    # 2d array(id,level)
    # filled with

    try:
        numberingCache = NumberingCache()
        numbering = doc.part.numbering_part.numbering_definitions
        if numbering:
            for item in numbering._numbering:
                if item.tag.endswith("abstractNum"):
                    abstractId = item.attrib.get("{http://schemas.openxmlformats.org/wordprocessingml/2006/main}abstractNumId")
                    for level in item:
                        ilvl = level.attrib.get("{http://schemas.openxmlformats.org/wordprocessingml/2006/main}ilvl")

                        format = ""
                        style = ""
                        text = ""
                        for child in level:
                            if child.tag.endswith("numFmt"):
                                format = child.attrib.get("{http://schemas.openxmlformats.org/wordprocessingml/2006/main}val")
                            elif child.tag.endswith("lvlText"):
                                text = child.attrib.get("{http://schemas.openxmlformats.org/wordprocessingml/2006/main}val")
                            elif child.tag.endswith("pStyle"):
                                style = child.attrib.get("{http://schemas.openxmlformats.org/wordprocessingml/2006/main}val")

                        #log.warning(f"**** {ilvl} {format} {text} {style}")
                        numberDef = NumberingDef(abstractId, ilvl, format, style, text)
                        numberingCache.append(abstractId, ilvl, numberDef)
        return numberingCache
    except Exception as e:
        log.error(f"Unable to access numbering: {e}")
        return DefaultNumbering()


# FIXME: Inspect numbering.xml for the various numbering schemes.
# really just to figure out list item type: -, *, - [ ], 1., etc.

def get_marker(paragraph: docx.text.paragraph.Paragraph):
    p = paragraph._element
    numPr = p.find(".//w:numPr", namespaces=p.nsmap)
    if numPr is not None:
        numId = numPr.find(".//w:numId", namespaces=p.nsmap).val
        #type_id = numId.get("{http://schemas.openxmlformats.org/wordprocessingml/2006/main}val")
        #log.warning(f"--| {type(type_id)}: {type_id} ")

        ilvl = get_list_level(paragraph)
        #log.warning(f"NUMID numId={numId}, ilvl={ilvl}")

        return numId, ilvl
    else:
        return None, None


# NOTE: This can be collapsed into "get list marker(paragr) -> None"
def is_list(paragraph: docx.text.paragraph.Paragraph) -> bool:
    p = paragraph._element
    numPr = p.find(".//w:numPr", namespaces=p.nsmap)
    return numPr is not None


class StyledText:
    def __init__(self, page: Page, text: str = ""):
        assert page is not None
        self.page = page
        self.text = text
        self.bold = False
        self.italic = False
        self.underline = False
        self.strike = False
        self.mono = False

    @staticmethod
    def from_run(run: docx.text.run.Run, page: Page):
        styled = StyledText(page)
        if isinstance(run, docx.text.run.Run):
            # copy style
            styled.bold = run.bold
            styled.italic = run.italic
            styled.underline = run.underline
            styled.strike = run.font.strike
            # check .font for monospacing
            if run.font.name in KNOWN_MONO_FONTS:
                styled.mono = True

        # check text
        for s in run.iter_inner_content():
            # TODO switch on type
            if isinstance(s, str):
                #log.info(f"^^^^ '{s}'")
                styled.append(s)
            elif isinstance(s, docx.text.run.Run):
                subtext = StyledText.from_run(s, page)
                styled.append_styled(subtext)
            elif isinstance(s, docx.text.hyperlink.Hyperlink):
                styled.append(f"[{s.text}]({s.address})")
            elif isinstance(s, docx.drawing.Drawing):
                # This is where is image link is embedded in the markdown.
                # The link is generated from the rId.
                # Assumes 'process_images' has been run and page.images is populated
                rId = extract_r_embed(s._element.xml)
                styled.append(page.get_image_link(rId))
            elif isinstance(s, docx.text.pagebreak.RenderedPageBreak):
                styled.append("\n\n-----\n\n")
            else:
                log.warning(f"unknown run type: {s}")

        if len(styled.text) == 0:
            return None

        comments = CommentBlock.from_run(run)
        #log.warning(f"from RUN: {styled.text[:20]} {comments}")
        if comments:
            # capture the comments for later display
            styled.page.append_comment(comments)
            # write the comment anchor link to the text
            styled.append(comments.link())

        return styled


    def __str__(self) -> str:
        if not self.text:
            return ""

        _str = str(self.text)

        # for mono, don't process the other styles
        if self.mono:
            return f"`{_str}`"

        # otherwise, stack the styles
        if self.bold:
            _str = f"**{_str}**"
        if self.italic:
            _str = f"*{_str}*"
        if self.underline:
            _str = f"__{_str}__"
        if self.strike:
            _str = f"~~{_str}~~"

        return _str


    def append(self, new_text:str):
        # to establish builder pattern
        # assumes styles have already been matched
        self.text += new_text


    def append_styled(self, subtext: Self):
        if not subtext:
            # ignore empty subtext
            return

        if self.bold == subtext.bold and \
           self.italic == subtext.italic and \
           self.underline == subtext.underline and \
           self.strike == subtext.strike and \
           self.mono == subtext.mono:

            self.append(subtext.text) # confirm matching styles
        else:
            # NOTE: This is where a list of sub-styledtests would be kept
            self.append(str(subtext)) # stringify to apply formatting


KNOWN_MONO_FONTS = ["Courier New"] # TODO: More fonts


class DocxitConverter(Converter):
    def convert(self, infile:Path, outroot:Path) -> Page:
        """
        Converts a docx file into markdown using docxit
        """
        page = DocxitConverter.load_file(infile)
        page.path = f"{outroot}/{infile.parent}/{infile.stem}"
        return page


    @staticmethod
    def load_file(full_path:Path) -> Page:
        """
        Given an DOCX file, load the content and convert to MD using
        the Docxit converter. This generates an in-memory Page object
        for the document with all attachments embedded.
        Given an MD file, just load a page with it.
        """
        match full_path.suffix.lower():
            case ".docx":
                return convert_file(full_path)
            case ".md":
                return Page.load_file(full_path)
            case _:
                log.info(f"Skipping, unknown file extension: {full_path}")
