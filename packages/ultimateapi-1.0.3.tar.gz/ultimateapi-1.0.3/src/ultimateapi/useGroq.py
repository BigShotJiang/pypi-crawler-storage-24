# import os
# import random
# from groq import Groq


# # Read API keys from environment variables
# API_KEYS = [
#     os.getenv("GROQ_API_KEY_1"),
#     os.getenv("GROQ_API_KEY_2"),
#     os.getenv("GROQ_API_KEY_3"),
#     os.getenv("GROQ_API_KEY_4"),
#     os.getenv("GROQ_API_KEY_5"),
#     os.getenv("GROQ_API_KEY_6"),
# ]

# # Filter out None values (in case not all 6 keys are set)
# API_KEYS = [key for key in API_KEYS if key is not None]

# if not API_KEYS:
#     raise ValueError("No GROQ API keys found in environment variables. Please set GROQ_API_KEY_1 through GROQ_API_KEY_6")

# MODEL = "openai/gpt-oss-20b"   # change here if needed


# def get_random_client():
#     """Get a Groq client with a randomly selected API key"""
#     selected_key = random.choice(API_KEYS)
#     return Groq(api_key=selected_key)


# def useGroq(createModel):
#     client = get_random_client()
#     response = client.chat.completions.create(
#         model=createModel.MODEL if hasattr(createModel, "MODEL") else MODEL, # using defalut gpt here becaues i guess it's BEST
#         messages=[
#             {"role": createModel.ROLE, "content": createModel.CONTENT}
#         ]
#     )

#     return response.choices[0].message.content



# if __name__ == "__main__":
#     user_prompt = input("You: ")
#     answer = useGroq(user_prompt)
#     print("\nLLM:", answer, "\n")



import os
import random
from groq import Groq
from dotenv import load_dotenv

# Load .env if present
load_dotenv()

DEFAULT_MODEL = "openai/gpt-oss-20b"


def _load_api_keys(prefix="GROQ_API_KEY", max_keys=10):
    keys = [os.getenv(f"{prefix}_{i}") for i in range(1, max_keys + 1)]
    return [k for k in keys if k]


API_KEYS = _load_api_keys()

if not API_KEYS:
    raise ValueError(
        "No GROQ API keys found. Set GROQ_API_KEY_1, GROQ_API_KEY_2, ..."
    )


def _get_random_client():
    key = random.choice(API_KEYS)
    return Groq(api_key=key)


def useGroq(createModel: dict):
    """
    Expected dict format:
    {
        "ROLE": "user",
        "CONTENT": "Hello",
        "MODEL": "optional"
    }
    """

    if not isinstance(createModel, dict):
        raise TypeError("useGroq expects a dictionary")

    role = createModel.get("ROLE")
    content = createModel.get("CONTENT")
    model = createModel.get("MODEL", DEFAULT_MODEL)

    if not role or not content:
        raise ValueError("Both 'ROLE' and 'CONTENT' are required")

    client = _get_random_client()

    try:
        response = client.chat.completions.create(
            model=model,
            messages=[{"role": role, "content": content}],
        )
        return response.choices[0].message.content

    except Exception as e:
        raise RuntimeError(f"Groq API request failed: {e}")