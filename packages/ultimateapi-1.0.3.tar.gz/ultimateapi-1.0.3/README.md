# UltimateAPI 

A simple Python wrapper to use multiple AI providers with **automatic API key rotation**.

---

## Features

* Multiple API key support (avoid rate limits)
* Simple function-based usage
* Clean and minimal design
* Secure (uses environment variables)

---

## Installation

```bash
pip install ultimateapi
```

---

## Setup Environment Variables

Set your API keys:

```bash
export GROQ_API_KEY_1="your_key_1"
export GROQ_API_KEY_2="your_key_2"
export GROQ_API_KEY_3="your_key_3"
export GROQ_API_KEY_4="your_key_4"
export GROQ_API_KEY_5="your_key_5"
export GROQ_API_KEY_6="your_key_6"
```

(Works similarly for other providers)

---

## Usage

### Groq Example

```python
from ultimateapi import useGroq

response = useGroq("Explain AI in simple terms")
print(response)
```

---

## How It Works

* Automatically selects a random API key
* Sends request using selected provider
* Returns response text


---

## ⚠️ Notes

* Do NOT hardcode API keys
* Make sure at least one API key is set
* Rate limits depend on provider

---

## Author

Narendra Singh (codernsingh)

---

## 📜 License

MIT License
