##
# \file
#

import qbruntime.qbruntime as _cQbRuntime

##
# \addtogroup PythonAPI
# @{


class Accelerator:
    """@brief Represents an accelerator, i.e., an NPU, used for executing models."""

    def __init__(self, dev_no: int = 0):
        """
        @brief Creates an Accelerator object for a specific device number.

        The `dev_no` parameter represents the device number. For example, on Linux,
        if an ARIES NPU is attached as `/dev/aries0`, the device number is `0`.

        @param dev_no The device number to associate with the Accelerator.
        """
        self._accelerator = _cQbRuntime.Accelerator(dev_no)


##
# @}
