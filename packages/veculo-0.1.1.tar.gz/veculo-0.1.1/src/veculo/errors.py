"""Exception classes for the Veculo SDK."""

from __future__ import annotations


class VeculoError(Exception):
    """Base exception for all Veculo SDK errors.

    Attributes:
        message: Human-readable error description.
        status_code: HTTP status code from the API, if applicable.
        body: Raw response body, if available.
    """

    def __init__(
        self,
        message: str,
        status_code: int | None = None,
        body: dict | None = None,
    ) -> None:
        self.message = message
        self.status_code = status_code
        self.body = body
        super().__init__(message)

    def __repr__(self) -> str:
        return f"{self.__class__.__name__}(message={self.message!r}, status_code={self.status_code})"


class AuthenticationError(VeculoError):
    """Raised when the API key is missing, invalid, or expired (HTTP 401/403)."""


class NotFoundError(VeculoError):
    """Raised when the requested resource does not exist (HTTP 404)."""


class ValidationError(VeculoError):
    """Raised when the request fails server-side validation (HTTP 400/422)."""
