from __future__ import annotations

import os
import urllib.parse
from dataclasses import dataclass
from typing import Optional


@dataclass
class EmailDraft:
    to: str
    subject: str
    body: str

    def mailto_url(self) -> str:
        params = {
            "subject": self.subject,
            "body": self.body,
        }
        return f"mailto:{self.to}?{urllib.parse.urlencode(params)}"


class EmailSender:
    """
    "Send" via `mailto:` (opens user email client).

    This is the safest cross-platform option without requiring Gmail/Outlook API credentials.
    """

    def open_mailto(self, draft: EmailDraft) -> None:
        url = draft.mailto_url()
        # macOS: `open` launches the default handler (your mail client).
        os.system(f'open "{url}"')

