from __future__ import annotations

from pathlib import Path
from typing import Optional


def export_storage_state(*, login_url: str, output_path: Path, headless: bool = False) -> None:
    """
    Opens a browser at `login_url`, lets the user log in manually, then exports Playwright
    `storage_state` JSON for authenticated automation.
    """
    from playwright.sync_api import sync_playwright

    output_path.parent.mkdir(parents=True, exist_ok=True)

    with sync_playwright() as p:
        browser = p.chromium.launch(headless=headless)
        context = browser.new_context()
        page = context.new_page()
        page.goto(login_url, wait_until="domcontentloaded")
        input(
            "Logged-in browser needed for authenticated automation.\n"
            "Finish logging into your account in the opened browser, then press Enter here to export storage state."
        )
        context.storage_state(path=str(output_path))
        context.close()
        browser.close()

