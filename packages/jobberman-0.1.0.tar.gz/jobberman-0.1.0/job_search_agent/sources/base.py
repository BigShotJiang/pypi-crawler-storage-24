from __future__ import annotations

from abc import ABC, abstractmethod
from typing import List

from ..models import JobDescription


class JobSource(ABC):
    @abstractmethod
    def search(self, *, query: str, max_jobs: int) -> List[JobDescription]:
        """
        Return candidate jobs with at least:
        - title
        - raw_text (the text you want the JD parser to process)
        - url (if available)
        """

