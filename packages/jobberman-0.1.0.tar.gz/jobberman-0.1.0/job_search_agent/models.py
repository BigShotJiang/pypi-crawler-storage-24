from __future__ import annotations

from datetime import datetime
from typing import List, Optional
from pydantic import BaseModel, Field


class JobDescription(BaseModel):
    raw_text: str
    title: str
    url: Optional[str] = None
    company: Optional[str] = None
    location: Optional[str] = None
    seniority: Optional[str] = None
    employment_type: Optional[str] = None
    responsibilities: List[str] = Field(default_factory=list)
    required_skills: List[str] = Field(default_factory=list)
    nice_to_have_skills: List[str] = Field(default_factory=list)
    salary_range: Optional[str] = None


class CandidateProfile(BaseModel):
    name: str
    email: str
    headline: str
    years_experience: int
    skills: List[str]
    industries: List[str] = Field(default_factory=list)
    tools: List[str] = Field(default_factory=list)
    achievements: List[str] = Field(default_factory=list)
    resume_text: Optional[str] = None
    portfolio_links: List[str] = Field(default_factory=list)


class TailoredResume(BaseModel):
    summary: str
    highlighted_skills: List[str]
    bullet_points: List[str]
    warnings: List[str] = Field(default_factory=list)


class TailoredCoverLetter(BaseModel):
    intro: str
    body: str
    closing: str
    warnings: List[str] = Field(default_factory=list)


class PortfolioSuggestion(BaseModel):
    title: str
    description: str
    priority: str  # e.g. "high", "medium", "low"


class InterviewQuestion(BaseModel):
    question: str
    category: str  # e.g. "behavioral", "technical", "company"
    focus_areas: List[str] = Field(default_factory=list)


class InterviewTurn(BaseModel):
    question: InterviewQuestion
    candidate_answer: Optional[str] = None
    feedback: Optional[str] = None
    score: Optional[int] = None  # 1–5


class InterviewSession(BaseModel):
    job: JobDescription
    candidate: CandidateProfile
    turns: List[InterviewTurn] = Field(default_factory=list)
    started_at: datetime = Field(default_factory=datetime.utcnow)
    completed_at: Optional[datetime] = None


# --- Autonomous Bot Models ---


class MatchScore(BaseModel):
    """Gemini-generated relevance score for a candidate–job pair."""
    score: int  # 0–100
    reasoning: str
    apply_recommendation: bool


class ApplicationLog(BaseModel):
    """Structured record of a bot action."""
    timestamp: datetime = Field(default_factory=datetime.utcnow)
    action: str  # SCANNED, SCORED, TAILORED, APPLIED, SKIPPED, ERROR
    job_title: str
    company: Optional[str] = None
    url: Optional[str] = None
    score: Optional[int] = None
    status: str = ""  # e.g. SUBMITTED, SKIPPED_LOW_SCORE, FAILED
    details: str = ""


class BotConfig(BaseModel):
    """User configuration for the autopilot daemon."""
    query: str = "software engineer"
    sources: List[str] = Field(default_factory=lambda: ["remoteok", "remotive"])
    interval_minutes: int = 30
    min_score: int = 60
    max_jobs_per_scan: int = 20
    output_dir: str = "autopilot_output"
    max_packages: int = 50  # Auto-prune oldest packages beyond this limit
    max_log_lines: int = 5000  # Rotate application_log.jsonl beyond this


