from __future__ import annotations

import os
from ..models import CandidateProfile, JobDescription, TailoredCoverLetter, TailoredResume

class ResumeTailorAgent:
    """
    Tailors resume highlights and a cover letter draft based on a job description using Gemini.
    """

    def _get_client(self):
        if not os.environ.get("GEMINI_API_KEY"):
            raise ValueError("GEMINI_API_KEY environment variable is missing.")
        from google import genai
        return genai.Client()

    def tailor_resume(self, candidate: CandidateProfile, job: JobDescription) -> TailoredResume:
        client = self._get_client()

        achievements_str = "\n".join(f"- {a}" for a in candidate.achievements)
        prompt = f"""
        Tailor the candidate's resume for the following job description.
        
        JOB DESCRIPTION:
        Title: {job.title}
        Company: {job.company or 'Unknown'}
        Required Skills: {', '.join(job.required_skills)}
        Responsibilities: {', '.join(job.responsibilities)}
        
        CANDIDATE:
        Name: {candidate.name}
        Headline: {candidate.headline}
        Years of Experience: {candidate.years_experience}
        Skills: {', '.join(candidate.skills)}
        Achievements:
        {achievements_str}
        
        Output must include:
        1. summary: A professional 2-3 sentence summary positioning the candidate for this specific role.
        2. highlighted_skills: A list of the candidate's skills that overlap with or are highly relevant to the job requirements.
        3. bullet_points: 4-6 tailored achievement bullet points demonstrating fitness for the job's responsibilities.
        4. warnings: Any missing critical skills or gaps the candidate should be aware of.
        """
        
        from google import genai
        response = client.models.generate_content(
            model='gemini-2.5-flash',
            contents=prompt,
            config=genai.types.GenerateContentConfig(
                response_mime_type="application/json",
                response_schema=TailoredResume,
                temperature=0.5,
            ),
        )
        return response.parsed

    def tailor_cover_letter(self, candidate: CandidateProfile, job: JobDescription) -> TailoredCoverLetter:
        client = self._get_client()

        achievements_str = "\n".join(f"- {a}" for a in candidate.achievements)
        prompt = f"""
        Draft a tailored cover letter for the candidate applying to the following job.
        
        JOB DESCRIPTION:
        Title: {job.title}
        Company: {job.company or 'Unknown'}
        
        CANDIDATE:
        Name: {candidate.name}
        Headline: {candidate.headline}
        Achievements:
        {achievements_str}
        Portfolio Links: {', '.join(candidate.portfolio_links)}
        
        The cover letter must include:
        - intro: Engaging opening paragraph stating the role.
        - body: 1-2 paragraphs connecting the candidate's achievements to the company's needs.
        - closing: Professional sign-off and call to action.
        - warnings: Any warnings for the user, such as missing company names.
        """

        from google import genai
        response = client.models.generate_content(
            model='gemini-2.5-flash',
            contents=prompt,
            config=genai.types.GenerateContentConfig(
                response_mime_type="application/json",
                response_schema=TailoredCoverLetter,
                temperature=0.7,
            ),
        )
        return response.parsed

