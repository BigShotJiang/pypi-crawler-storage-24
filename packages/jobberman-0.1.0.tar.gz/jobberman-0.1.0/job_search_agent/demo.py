from __future__ import annotations

from textwrap import indent

from tabulate import tabulate

from .models import CandidateProfile
from .orchestrator import JobSearchOrchestrator


def run_demo() -> None:
    orchestrator = JobSearchOrchestrator()

    sample_jd = """
Senior Backend Engineer | Payments Platform

Company: AcmePay
Location: Remote (Europe)

Responsibilities:
- Design and build scalable payment APIs.
- Collaborate with product and data teams.
- Improve reliability and observability of core services.

Requirements:
- 5+ years of backend engineering experience.
- Strong experience with Python or Go.
- Experience with PostgreSQL and message queues.
- Familiarity with cloud platforms (AWS, GCP, or Azure).

Nice to have:
- Experience in fintech or payments.
- Prior work on high-throughput, low-latency systems.
"""

    candidate = CandidateProfile(
        name="Jordan Doe",
        email="jordan.doe@example.com",
        headline="Backend Engineer",
        years_experience=6,
        skills=["Python", "PostgreSQL", "AWS", "Docker", "Kafka"],
        industries=["SaaS"],
        tools=["Git", "Kubernetes"],
        achievements=[
            "Led migration of monolith billing service to microservice architecture, reducing deployment time by 60%.",
            "Improved API latency by 35% by introducing caching and query optimizations.",
            "Designed and implemented an event-driven invoicing pipeline processing 5M+ events/day.",
        ],
        portfolio_links=["https://github.com/jordan-backend", "https://jordan.dev"],
    )

    result = orchestrator.full_pipeline(sample_jd, candidate)

    job = result["job"]
    tailored_resume = result["tailored_resume"]
    tailored_cover = result["tailored_cover_letter"]
    portfolio_suggestions = result["portfolio_suggestions"]
    interview_session = result["interview_session"]

    print("=== Parsed Job Description ===")
    print(f"Title: {job.title}")
    print(f"Company: {job.company}")
    print(f"Location: {job.location}")
    print()

    print("Responsibilities:")
    for r in job.responsibilities:
        print(f"- {r}")
    print()

    print("Required skills:")
    for s in job.required_skills:
        print(f"- {s}")
    print()

    print("=== Tailored Resume Summary ===")
    print(tailored_resume.summary)
    print()
    print("Highlighted skills:", ", ".join(tailored_resume.highlighted_skills))
    print()
    print("Suggested bullet points:")
    for b in tailored_resume.bullet_points:
        print(f"- {b}")
    if tailored_resume.warnings:
        print()
        print("Warnings:")
        for w in tailored_resume.warnings:
            print(f"! {w}")
    print()

    print("=== Tailored Cover Letter Draft ===")
    print(tailored_cover.intro)
    print()
    print(tailored_cover.body)
    print(tailored_cover.closing)
    if tailored_cover.warnings:
        print()
        print("Warnings:")
        for w in tailored_cover.warnings:
            print(f"! {w}")
    print()

    print("=== Portfolio Suggestions ===")
    table = [
        [s.priority.upper(), s.title, s.description] for s in portfolio_suggestions
    ]
    print(tabulate(table, headers=["Priority", "Title", "Description"]))
    print()

    print("=== Mock Interview Questions ===")
    for idx, turn in enumerate(interview_session.turns, start=1):
        print(f"Q{idx} ({turn.question.category}): {turn.question.question}")
        if turn.question.focus_areas:
            print(f"  Focus areas: {', '.join(turn.question.focus_areas)}")
        print()


if __name__ == "__main__":
    run_demo()

