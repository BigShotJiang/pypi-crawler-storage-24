"""Tests for the RelevanceScorer with mocked Gemini calls."""
from __future__ import annotations

from unittest.mock import MagicMock, patch

from job_search_agent.models import MatchScore
from job_search_agent.scoring import RelevanceScorer


class TestRelevanceScorer:
    def test_score_returns_match_score(self, sample_candidate, sample_job):
        mock_match = MatchScore(score=85, reasoning="Strong Python overlap", apply_recommendation=True)

        mock_response = MagicMock()
        mock_response.parsed = mock_match

        mock_client = MagicMock()
        mock_client.models.generate_content.return_value = mock_response

        with patch.dict("os.environ", {"GEMINI_API_KEY": "test-key"}):
            with patch("job_search_agent.scoring.genai") as mock_genai:
                mock_genai.Client.return_value = mock_client

                scorer = RelevanceScorer()
                result = scorer.score(sample_candidate, sample_job)

        assert result.score == 85
        assert result.apply_recommendation is True
        mock_client.models.generate_content.assert_called_once()

    def test_score_low_match(self, sample_candidate, sample_job):
        mock_match = MatchScore(score=25, reasoning="Skill mismatch", apply_recommendation=False)

        mock_response = MagicMock()
        mock_response.parsed = mock_match

        mock_client = MagicMock()
        mock_client.models.generate_content.return_value = mock_response

        with patch.dict("os.environ", {"GEMINI_API_KEY": "test-key"}):
            with patch("job_search_agent.scoring.genai") as mock_genai:
                mock_genai.Client.return_value = mock_client

                scorer = RelevanceScorer()
                result = scorer.score(sample_candidate, sample_job)

        assert result.score == 25
        assert result.apply_recommendation is False

    def test_missing_api_key_raises(self, sample_candidate, sample_job):
        import pytest

        with patch.dict("os.environ", {}, clear=True):
            scorer = RelevanceScorer()
            with pytest.raises(ValueError, match="GEMINI_API_KEY"):
                scorer.score(sample_candidate, sample_job)
