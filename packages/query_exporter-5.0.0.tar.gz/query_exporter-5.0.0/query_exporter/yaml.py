import os
from pathlib import Path
from typing import Any, ClassVar

import yaml
from yaml.scanner import ScannerError

__all__ = ["ScannerError"]


def load_yaml(path: Path) -> Any:
    """Load a YAML document from a file."""

    with path.open() as fd:
        return yaml.load(fd, _config_loader(path.parent))


class _ConfigLoader(yaml.SafeLoader):
    """YAML loader supporting tags."""

    base_path: ClassVar[Path]


def _config_loader(path: Path) -> type[_ConfigLoader]:
    class ConfigLoaderWithPath(_ConfigLoader):
        base_path = path

    return ConfigLoaderWithPath


def _tag_env(loader: _ConfigLoader, node: yaml.nodes.ScalarNode) -> Any:
    env = loader.construct_scalar(node)
    value = os.getenv(env)
    if value is None:
        raise ScannerError(
            "while processing 'env' tag",
            None,
            f"variable {env} undefined",
            loader.get_mark(),
        )
    return yaml.safe_load(value)


def _tag_file(loader: _ConfigLoader, node: yaml.nodes.ScalarNode) -> str:
    path = loader.base_path / loader.construct_scalar(node)
    if not path.is_file():
        raise ScannerError(
            "while processing 'file' tag",
            None,
            f"file {path} not found",
            loader.get_mark(),
        )
    return path.read_text().strip()


def _tag_include(loader: _ConfigLoader, node: yaml.nodes.ScalarNode) -> Any:
    path = loader.base_path / loader.construct_scalar(node)
    if not path.is_file():
        raise ScannerError(
            "while processing 'include' tag",
            None,
            f"file {path} not found",
            loader.get_mark(),
        )
    with path.open() as fd:
        return yaml.load(fd, _config_loader(path.parent))


_ConfigLoader.add_constructor("!env", _tag_env)
_ConfigLoader.add_constructor("!file", _tag_file)
_ConfigLoader.add_constructor("!include", _tag_include)
