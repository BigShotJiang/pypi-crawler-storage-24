from setuptools import setup, find_packages

VERSION = "1.0.0"  # bump version

with open("README.md", "r", encoding="utf-8") as f:
    long_description = f.read()

setup(
    name="pygfetdb",
    version=VERSION,
    description="GFET Analysis tools",
    long_description=long_description,
    long_description_content_type="text/markdown",
    author="Anton Guimera-Brunet",
    author_email="anton.guimera@csic.es",
    url="https://github.com/aguimera/PyGFETdb",
    license="GPLv3",
    packages=find_packages(),
    include_package_data=True,
    install_requires=[],
    classifiers=[
        'Development Status :: 3 - Alpha',
        'Intended Audience :: Science/Research',
        'License :: OSI Approved :: GNU General Public License v3 (GPLv3)',
        'Operating System :: OS Independent',
        'Programming Language :: Python :: 3',
        'Topic :: Scientific/Engineering',
    ],
    entry_points={
        'console_scripts': [
            'GFETDbView_v2 = PyGFETdb.GuiDBView.GuiDBView_v2:main'
        ]
    },
)
