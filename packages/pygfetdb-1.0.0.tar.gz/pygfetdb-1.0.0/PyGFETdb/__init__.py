# -*- coding: utf-8 -*-
"""
Created on Tue Nov 15 17:27:23 2016

@author: aguimera
"""

__version__ = "1.0.0"
