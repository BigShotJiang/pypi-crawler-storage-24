"""
Tests for SPMD type checker: type inference, strict mode, error messages.

Covers: _checker.py
"""

import logging
import re
import unittest

import expecttest
import torch
import torch.distributed as dist
from sixlib.spmd_types import (
    I,
    P,
    R,
    S,
    Scalar,
    V,
)
from sixlib.spmd_types._checker import (
    _trace_logger,
    assert_type,
    get_axis_local_type,
    infer_local_type_for_axis,
    mutate_type,
    OpLinearity,
    trace,
    typecheck,
)
from sixlib.spmd_types._collectives import all_reduce
from sixlib.spmd_types._test_utils import LocalTensorTestCase, SpmdTypeCheckedTestCase
from sixlib.spmd_types._type_attr import get_local_type
from sixlib.spmd_types.types import normalize_axis, PartitionSpec, SpmdTypeError
from torch.distributed._local_tensor import LocalTensorMode
from torch.distributed.device_mesh import init_device_mesh


class TestEinsumTypePropagation(unittest.TestCase):
    """Test einsum type propagation rules.

    TODO: These tests depend on LTensor which was removed. They need to be
    reimplemented once the type-checking layer is rebuilt.
    """

    pass


class TestEinsumSingleOperand(unittest.TestCase):
    """Test einsum with single operand (unary operations).

    TODO: These tests depend on LTensor which was removed. They need to be
    reimplemented once the type-checking layer is rebuilt.
    """

    pass


class TestLinearTypePropagation(SpmdTypeCheckedTestCase):
    """Test type propagation through F.linear (matmul + optional bias)."""

    def test_linear_r_v_gives_v(self):
        """F.linear with R weight and V input should give V output, not R."""
        inp = self._generate_inputs((2, 4), self.pg, V)
        weight = self._generate_inputs((3, 4), self.pg, R)
        result = torch.nn.functional.linear(inp, weight)
        self.assertIs(get_axis_local_type(result, self.pg), V)

    def test_matmul_r_v_gives_v(self):
        """torch.matmul with R and V should give V output."""
        x = self._generate_inputs((2, 4), self.pg, R)
        y = self._generate_inputs((4, 3), self.pg, V)
        result = torch.matmul(x, y)
        self.assertIs(get_axis_local_type(result, self.pg), V)

    def test_add_r_v_gives_v(self):
        """torch.add with R and V should give V output."""
        x = self._generate_inputs((4,), self.pg, R)
        y = self._generate_inputs((4,), self.pg, V)
        result = torch.add(x, y)
        self.assertIs(get_axis_local_type(result, self.pg), V)

    def test_add_p_p_gives_p(self):
        """torch.add with P and P should give P (addition is linear)."""
        x = self._generate_inputs((4,), self.pg, P)
        y = self._generate_inputs((4,), self.pg, P)
        result = torch.add(x, y)
        self.assertIs(get_axis_local_type(result, self.pg), P)

    def test_sub_p_p_gives_p(self):
        """torch.sub with P and P should give P (subtraction is linear)."""
        x = self._generate_inputs((4,), self.pg, P)
        y = self._generate_inputs((4,), self.pg, P)
        result = torch.sub(x, y)
        self.assertIs(get_axis_local_type(result, self.pg), P)

    def test_matmul_p_rejected(self):
        """torch.matmul with all-P is rejected (matmul is not linear in this sense)."""
        x = self._generate_inputs((2, 4), self.pg, P)
        y = self._generate_inputs((4, 3), self.pg, P)
        with self.assertRaises(SpmdTypeError):
            torch.matmul(x, y)

    def test_mul_p_r_gives_p(self):
        """torch.mul with P and R should give P (multilinear: P in one factor, R in other)."""
        x = self._generate_inputs((4,), self.pg, P)
        y = self._generate_inputs((4,), self.pg, R)
        result = torch.mul(x, y)
        self.assertIs(get_axis_local_type(result, self.pg), P)

    def test_cat_p_p_gives_p(self):
        """torch.cat with P and P should give P (cat is linear)."""
        x = self._generate_inputs((4,), self.pg, P)
        y = self._generate_inputs((4,), self.pg, P)
        result = torch.cat([x, y])
        self.assertIs(get_axis_local_type(result, self.pg), P)

    def test_matmul_p_r_gives_p(self):
        """torch.matmul with P and R should give P (multilinear: P in one factor)."""
        x = self._generate_inputs((2, 4), self.pg, P)
        y = self._generate_inputs((4, 3), self.pg, R)
        result = torch.matmul(x, y)
        self.assertIs(get_axis_local_type(result, self.pg), P)

    def test_add_p_r_rejected(self):
        """torch.add with mixed P and R is still rejected."""
        x = self._generate_inputs((4,), self.pg, P)
        y = self._generate_inputs((4,), self.pg, R)
        with self.assertRaises(SpmdTypeError):
            torch.add(x, y)

    def test_add_p_scalar_rejected(self):
        """torch.add(P, scalar) is affine, not linear -- must be rejected."""
        x = self._generate_inputs((4,), self.pg, P)
        with self.assertRaises(SpmdTypeError):
            torch.add(x, 1.0)

    def test_sub_p_scalar_rejected(self):
        """torch.sub(P, scalar) is affine -- must be rejected."""
        x = self._generate_inputs((4,), self.pg, P)
        with self.assertRaises(SpmdTypeError):
            torch.sub(x, 1.0)

    def test_add_p_int_scalar_rejected(self):
        """torch.add(P, int_scalar) is also affine -- must be rejected."""
        x = self._generate_inputs((4,), self.pg, P)
        with self.assertRaises(SpmdTypeError):
            torch.add(x, 1)

    def test_cat_p_with_dim_arg_allowed(self):
        """torch.cat([P, P], 0) -- dim is not a tensor input, should be allowed."""
        x = self._generate_inputs((4,), self.pg, P)
        y = self._generate_inputs((4,), self.pg, P)
        result = torch.cat([x, y], 0)
        self.assertIs(get_axis_local_type(result, self.pg), P)

    def test_mul_p_scalar_allowed(self):
        """torch.mul(P, scalar) -- multilinear, scalar ignored, P propagates."""
        x = self._generate_inputs((4,), self.pg, P)
        result = torch.mul(x, 2.0)
        self.assertIs(get_axis_local_type(result, self.pg), P)

    def test_div_i_scalar_gives_i(self):
        """I / scalar should give I (scalar adopts I type)."""
        x = self._generate_inputs((4,), self.pg, I)
        result = x / 2.0
        self.assertIs(get_axis_local_type(result, self.pg), I)

    def test_add_i_scalar_gives_i(self):
        """torch.add(I, scalar) should give I (scalar adopts I type)."""
        x = self._generate_inputs((4,), self.pg, I)
        result = torch.add(x, 1.0)
        self.assertIs(get_axis_local_type(result, self.pg), I)

    def test_sub_i_scalar_gives_i(self):
        """torch.sub(I, scalar) should give I (scalar adopts I type)."""
        x = self._generate_inputs((4,), self.pg, I)
        result = torch.sub(x, 1.0)
        self.assertIs(get_axis_local_type(result, self.pg), I)

    def test_add_v_scalar_gives_v(self):
        """torch.add(V, scalar) should give V (scalar adopts V type)."""
        x = self._generate_inputs((4,), self.pg, V)
        result = torch.add(x, 1.0)
        self.assertIs(get_axis_local_type(result, self.pg), V)

    def test_mul_v_scalar_gives_v(self):
        """torch.mul(V, scalar) should give V (scalar adopts V type)."""
        x = self._generate_inputs((4,), self.pg, V)
        result = torch.mul(x, 2.0)
        self.assertIs(get_axis_local_type(result, self.pg), V)


class TestStrictMode(SpmdTypeCheckedTestCase):
    """Test strict mode which errors on unannotated tensors."""

    def setUp(self):
        """Enter LocalTensorMode and strict typecheck for each test."""
        self.mode = LocalTensorMode(self.WORLD_SIZE)
        self.mode.__enter__()
        self._type_checking_cm = typecheck(strict_mode="strict")
        self._type_checking_cm.__enter__()

    def tearDown(self):
        """Exit typecheck and LocalTensorMode after each test."""
        self._type_checking_cm.__exit__(None, None, None)
        self.mode.__exit__(None, None, None)

    def test_strict_mixed_annotated_unannotated_fails(self):
        """Strict mode raises when one operand is annotated and the other is not."""
        x = self._generate_inputs((4,), self.pg, R)
        y = self.rank_map(lambda r: torch.randn(4))
        with self.assertRaises(SpmdTypeError):
            torch.add(x, y)

    def test_strict_mixed_cat_fails(self):
        """Strict mode catches mixed typed/untyped tensors inside lists (e.g. torch.cat)."""
        x = self._generate_inputs((4,), self.pg, R)
        y = self.rank_map(lambda r: torch.randn(4))
        with self.assertRaises(SpmdTypeError):
            torch.cat([x, y])

    def test_strict_all_annotated_passes(self):
        """Strict mode allows operations when all tensors are annotated."""
        x = self._generate_inputs((4,), self.pg, R)
        y = self._generate_inputs((4,), self.pg, R)
        result = torch.add(x, y)
        self.assertIs(get_axis_local_type(result, self.pg), R)

    def test_strict_all_v_annotated_mixed_with_unannotated_fails(self):
        """Strict mode catches all-V tensor mixed with unannotated."""
        x = self._generate_inputs((4,), self.pg, V)
        # x has _spmd_types attr (set to {self.pg: V})
        y = self.rank_map(lambda r: torch.randn(4))
        # y has no _spmd_types attr at all
        with self.assertRaises(SpmdTypeError):
            torch.add(x, y)

    def test_strict_all_unannotated_produces_empty_type(self):
        """Strict mode: all-untyped tensors ({} + {}) infer {} output."""
        x = self.rank_map(lambda r: torch.randn(4))
        y = self.rank_map(lambda r: torch.randn(4))
        result = torch.add(x, y)  # {} + {} -> {}
        self.assertEqual(get_local_type(result), {})

    def test_strict_collective_typed_input_passes(self):
        """Strict mode allows collectives when the input tensor is typed."""
        x = self._generate_inputs((4,), self.pg, P)
        result = all_reduce(x, self.pg, src=P, dst=R)
        self.assertIs(get_axis_local_type(result, self.pg), R)

    def test_strict_collective_untyped_input_fails(self):
        """Strict mode raises when a collective receives an unannotated tensor."""
        y = self.rank_map(lambda r: torch.randn(4))
        with self.assertRaises(SpmdTypeError):
            all_reduce(y, self.pg, src=P, dst=R)

    def test_strict_out_kwarg_unannotated_passes(self):
        """Strict mode allows unannotated out= tensor (it's just a pre-allocated destination)."""
        a = self._generate_inputs((4,), self.pg, R)
        b = self._generate_inputs((4,), self.pg, R)
        c = self.rank_map(lambda r: torch.empty(4))  # unannotated
        self.assertEqual(get_local_type(c), {})
        torch.add(a, b, out=c)  # should NOT raise
        # out= tensor gets the inferred type
        self.assertIs(get_axis_local_type(c, self.pg), R)

    def test_strict_out_kwarg_inputs_still_checked(self):
        """Strict mode still checks actual input operands even when out= is present."""
        a = self.rank_map(lambda r: torch.randn(4))  # unannotated input
        b = self._generate_inputs((4,), self.pg, R)
        c = self.rank_map(lambda r: torch.empty(4))
        with self.assertRaises(SpmdTypeError):
            torch.add(a, b, out=c)

    def test_nonstrict_mixed_passes(self):
        """Non-strict mode infers type from all inputs (untyped = {} = unknown)."""
        with typecheck(strict_mode="permissive"):
            x = self._generate_inputs((4,), self.pg, R)
            y = self.rank_map(lambda r: torch.randn(4))
            result = torch.add(x, y)  # Should not raise
            # Untyped tensor contributes {} (unknown on all axes).
            # R + {} -> R (unknown axes are compatible with any type).
            self.assertIs(get_axis_local_type(result, self.pg), R)


class TestFactoryTensors(LocalTensorTestCase):
    """Test tensors from factory ops (e.g., torch.zeros) in strict mode.

    Factory ops produce tensors with {} type (typed but unknown on all axes).
    They propagate through ops on other {} tensors, and combining with a
    tensor that has real axes raises SpmdTypeError in strict mode.
    """

    def setUp(self):
        super().setUp()
        self._strict_cm = typecheck(strict_mode="strict")
        self._strict_cm.__enter__()

    def tearDown(self):
        self._strict_cm.__exit__(None, None, None)
        super().tearDown()

    def test_factory_creates_empty_typed_tensor(self):
        """A factory op in strict mode produces a {} typed tensor."""
        from sixlib.spmd_types._type_attr import get_local_type

        z = torch.zeros(4)
        self.assertEqual(get_local_type(z), {})

    def test_factory_propagates_through_ops(self):
        """Ops on {} tensors produce {} results."""
        from sixlib.spmd_types._type_attr import get_local_type

        a = torch.zeros(4)
        b = torch.ones(4)
        c = a + b
        self.assertEqual(get_local_type(c), {})

    def test_factory_meets_typed_raises(self):
        """Mixing a {} tensor with a typed tensor raises (missing axis)."""
        x = self._generate_inputs((4,), self.pg, R)
        z = torch.zeros(4)
        with self.assertRaises(SpmdTypeError):
            torch.add(x, z)

    def test_factory_annotated_then_used(self):
        """assert_type on a {} tensor sets the type."""
        from sixlib.spmd_types._type_attr import get_local_type

        z = torch.zeros(4)
        self.assertEqual(get_local_type(z), {})
        assert_type(z, {self.pg: R})
        self.assertIs(get_axis_local_type(z, self.pg), R)

    def test_factory_annotated_combines_with_typed(self):
        """Once annotated, a {} tensor combines with typed tensors."""
        x = self._generate_inputs((4,), self.pg, R)
        z = torch.zeros(4)
        assert_type(z, {self.pg: R})
        result = torch.add(x, z)
        self.assertIs(get_axis_local_type(result, self.pg), R)

    def test_truly_untyped_produces_empty_type(self):
        """Truly untyped tensors (created outside the mode) produce {} output."""
        a = self.rank_map(lambda r: torch.randn(4))
        b = self.rank_map(lambda r: torch.randn(4))
        result = torch.add(a, b)  # {} + {} -> {}
        self.assertEqual(get_local_type(result), {})

    def test_factory_chain_then_annotate(self):
        """A chain of factory ops produces {}, then assert_type works."""
        from sixlib.spmd_types._type_attr import get_local_type

        a = torch.zeros(4)
        b = torch.ones(4)
        c = a + b
        d = c * 2.0
        self.assertEqual(get_local_type(d), {})
        assert_type(d, {self.pg: V})
        self.assertIs(get_axis_local_type(d, self.pg), V)

    def test_nonstrict_factory_propagates(self):
        """Factory ops produce {} typed tensors in permissive mode too."""
        from sixlib.spmd_types._type_attr import get_local_type

        with typecheck(strict_mode="permissive"):
            z = torch.zeros(4)
            self.assertEqual(get_local_type(z), {})
            w = z + torch.ones(4)
            self.assertEqual(get_local_type(w), {})

    def test_nonstrict_factory_plus_typed_no_error(self):
        """Permissive mode infers from typed operands, skipping {} operands."""
        with typecheck(strict_mode="permissive"):
            x = self._generate_inputs((4,), self.pg, R)
            z = torch.zeros(4)
            result = torch.add(x, z)  # Should not raise
            # Permissive: {} operand skipped, inferred from typed operand.
            self.assertIs(get_axis_local_type(result, self.pg), R)

    def test_factory_spmd_collective_raises(self):
        """Passing a {} tensor to an SPMD collective raises (missing axis)."""
        z = torch.zeros(4)
        with self.assertRaises(SpmdTypeError):
            all_reduce(z, self.pg, dst=R)

    def test_factory_raw_collective_raises(self):
        """Passing a {} tensor to a raw dist collective raises (missing axis)."""
        import torch.distributed as dist

        pg = self.pg
        z = torch.zeros(4)
        output = torch.empty(self.WORLD_SIZE * 4)
        with self.assertRaises(SpmdTypeError):
            dist.all_gather_into_tensor(output, z, group=pg)


class TestFactoryTensorsPermissive(LocalTensorTestCase):
    """Test factory tensor behavior in permissive mode.

    These tests need no type checking in setUp so that truly untyped tensors
    can be created outside any mode, then tested inside permissive mode.
    """

    def test_nonstrict_truly_untyped_gets_empty_type(self):
        """In permissive mode, truly untyped tensors get {} output type."""
        # Create tensor outside any type checking -- truly untyped.
        a = torch.randn(4)
        with typecheck(strict_mode="permissive"):
            self.assertEqual(get_local_type(a), {})
            # Op on truly untyped input: result gets {} (unknown on all axes).
            b = a + 1.0
            self.assertEqual(get_local_type(b), {})

    def test_nonstrict_typed_plus_truly_untyped_produces_empty(self):
        """In permissive mode, {} (typed) + truly untyped ({}) = {} output."""
        # Create tensor outside any type checking -- truly untyped.
        a = torch.randn(4)
        with typecheck(strict_mode="permissive"):
            z = torch.zeros(4)  # {} typed (created inside mode)
            self.assertEqual(get_local_type(z), {})
            self.assertEqual(get_local_type(a), {})
            result = a + z
            # Both contribute {}: {} + {} -> {}.
            self.assertEqual(get_local_type(result), {})

    def test_factory_spmd_collective_permissive_propagates(self):
        """Permissive mode propagates {} tensor through SPMD collectives."""
        with typecheck(strict_mode="permissive"):
            z = torch.zeros(4)
            # {} tensor has no type for the collective's axis.
            # Permissive mode skips validation but still propagates dst type.
            all_reduce(z, self.pg, dst=R)


class TestAssertTypeRefinement(LocalTensorTestCase):
    """Test that assert_type merges non-overlapping axes (refinement)."""

    WORLD_SIZE = 6

    @classmethod
    def setUpClass(cls):
        super().setUpClass()
        mesh = init_device_mesh("cpu", (2, 3), mesh_dim_names=("dp", "tp"))
        cls.tp = mesh.get_group("tp")
        cls.dp = mesh.get_group("dp")

    def test_refine_disjoint_axes(self):
        """assert_type on new axes merges into existing type."""
        x = torch.randn(4)
        assert_type(x, {self.dp: R})
        assert_type(x, {self.tp: I})
        self.assertIs(get_axis_local_type(x, self.dp), R)
        self.assertIs(get_axis_local_type(x, self.tp), I)

    def test_refine_matching_axis_ok(self):
        """assert_type on an existing axis with the same type is fine."""
        x = torch.randn(4)
        assert_type(x, {self.dp: R})
        assert_type(x, {self.dp: R})  # same type, no error
        self.assertIs(get_axis_local_type(x, self.dp), R)

    def test_refine_conflicting_axis_raises(self):
        """assert_type on an existing axis with a different type raises."""
        x = torch.randn(4)
        assert_type(x, {self.dp: R})
        with self.assertRaises(SpmdTypeError):
            assert_type(x, {self.dp: V})
        with self.assertRaises(SpmdTypeError):
            assert_type(x, {self.dp: P})

    def test_refine_partial_overlap(self):
        """assert_type with both new and existing axes works."""
        x = torch.randn(4)
        assert_type(x, {self.dp: R})
        assert_type(x, {self.dp: R, self.tp: V})
        self.assertIs(get_axis_local_type(x, self.dp), R)
        self.assertIs(get_axis_local_type(x, self.tp), V)


class TestTypeErrorMessages(LocalTensorTestCase, expecttest.TestCase):
    """Test that type errors include actionable fix suggestions.

    Tests call infer_local_type_for_axis directly rather than going through
    torch ops to test specific axis-type combinations in isolation.
    """

    WORLD_SIZE = 6

    @classmethod
    def setUpClass(cls):
        super().setUpClass()
        mesh = init_device_mesh("cpu", (2, 3), mesh_dim_names=("dp", "tp"))
        cls.tp = mesh.get_group("tp")

    def test_general_I_R(self):
        """I + R: suggest reinterpret I->R (I->V filtered: changes output from R to V)."""
        with self.assertRaises(SpmdTypeError) as ctx:
            infer_local_type_for_axis(self.tp, [I, R])
        self.assertExpectedInline(
            str(ctx.exception),
            """\
Invariant type on axis mesh_tp cannot mix with other types. Found types: [I, R]
Are you missing a collective or a reinterpret/convert call? e.g.,
  convert(tensor, mesh_tp, src=I, dst=R) on the Invariant operand (no-op forward, all-reduce in backward)""",
        )

    def test_general_I_V(self):
        """I + V: suggest reinterpret I->R or I->V."""
        with self.assertRaises(SpmdTypeError) as ctx:
            infer_local_type_for_axis(self.tp, [I, V])
        self.assertExpectedInline(
            str(ctx.exception),
            """\
Invariant type on axis mesh_tp cannot mix with other types. Found types: [I, V]
Are you missing a collective or a reinterpret/convert call? e.g.,
  convert(tensor, mesh_tp, src=I, dst=R) on the Invariant operand (no-op forward, all-reduce in backward)
  reinterpret(tensor, mesh_tp, src=I, dst=V) on the Invariant operand (no-op forward, all-reduce in backward)""",
        )

    def test_general_I_P(self):
        """I + P: suggest convert I->P or all_reduce P->I."""
        with self.assertRaises(SpmdTypeError) as ctx:
            infer_local_type_for_axis(self.tp, [I, P])
        self.assertExpectedInline(
            str(ctx.exception),
            """\
Invariant type on axis mesh_tp cannot mix with other types. Found types: [I, P]
Are you missing a collective or a reinterpret/convert call? e.g.,
  all_reduce(tensor, mesh_tp, src=P, dst=I) on the Partial operand (all-reduce in forward, no-op backward)""",
        )

    def test_general_P_R(self):
        """P + R: suggest all_reduce P->R or convert R->P."""
        with self.assertRaises(SpmdTypeError) as ctx:
            infer_local_type_for_axis(self.tp, [P, R])
        self.assertExpectedInline(
            str(ctx.exception),
            """\
Partial type on axis mesh_tp cannot propagate through non-linear ops (non-linear of a partial sum != partial sum of non-linear). Reduce first with all_reduce or reduce_scatter. Found types: [P, R]
Are you missing a collective or a reinterpret/convert call? e.g.,
  all_reduce(tensor, mesh_tp, src=P, dst=R) on the Partial operand (all-reduce in forward, all-reduce in backward)""",
        )

    def test_general_P_V(self):
        """P + V: suggest all_reduce P->R."""
        with self.assertRaises(SpmdTypeError) as ctx:
            infer_local_type_for_axis(self.tp, [P, V])
        self.assertExpectedInline(
            str(ctx.exception),
            """\
Partial type on axis mesh_tp cannot combine with Varying. Reduce Partial first (all_reduce -> R, or reduce_scatter -> V). Found types: [P, V]
Are you missing a collective or a reinterpret/convert call? e.g.,
  all_reduce(tensor, mesh_tp, src=P, dst=R) on the Partial operand (all-reduce in forward, all-reduce in backward)""",
        )

    def test_general_R_P_V(self):
        """R + P + V: suggest all_reduce P->R."""
        with self.assertRaises(SpmdTypeError) as ctx:
            infer_local_type_for_axis(self.tp, [R, P, V])
        self.assertExpectedInline(
            str(ctx.exception),
            """\
Partial type on axis mesh_tp cannot combine with Varying. Reduce Partial first (all_reduce -> R, or reduce_scatter -> V). Found types: [R, P, V]
Are you missing a collective or a reinterpret/convert call? e.g.,
  all_reduce(tensor, mesh_tp, src=P, dst=R) on the Partial operand (all-reduce in forward, all-reduce in backward)""",
        )

    def test_general_I_R_V(self):
        """I + R + V: suggest reinterpret I->R or I->V."""
        with self.assertRaises(SpmdTypeError) as ctx:
            infer_local_type_for_axis(self.tp, [I, R, V])
        self.assertExpectedInline(
            str(ctx.exception),
            """\
Invariant type on axis mesh_tp cannot mix with other types. Found types: [I, R, V]
Are you missing a collective or a reinterpret/convert call? e.g.,
  convert(tensor, mesh_tp, src=I, dst=R) on the Invariant operand (no-op forward, all-reduce in backward)
  reinterpret(tensor, mesh_tp, src=I, dst=V) on the Invariant operand (no-op forward, all-reduce in backward)""",
        )

    def test_mul_P_P(self):
        """P * P: suggest all_reduce P->R."""
        with self.assertRaises(SpmdTypeError) as ctx:
            infer_local_type_for_axis(
                self.tp, [P, P], linearity=OpLinearity.MULTILINEAR
            )
        self.assertExpectedInline(
            str(ctx.exception),
            """\
Partial in multiple factors of multilinear op on axis mesh_tp is forbidden. Reduce all but one factor first. Found types: [P, P]
Are you missing a collective or a reinterpret/convert call? e.g.,
  all_reduce(tensor, mesh_tp, src=P, dst=R) on the Partial operand (all-reduce in forward, all-reduce in backward)""",
        )

    def test_mul_P_V(self):
        """P * V: suggest all_reduce P->R."""
        with self.assertRaises(SpmdTypeError) as ctx:
            infer_local_type_for_axis(
                self.tp, [P, V], linearity=OpLinearity.MULTILINEAR
            )
        self.assertExpectedInline(
            str(ctx.exception),
            """\
Partial type on axis mesh_tp cannot combine with Varying. Reduce Partial first (all_reduce -> R, or reduce_scatter -> V). Found types: [P, V]
Are you missing a collective or a reinterpret/convert call? e.g.,
  all_reduce(tensor, mesh_tp, src=P, dst=R) on the Partial operand (all-reduce in forward, all-reduce in backward)""",
        )

    def test_mul_P_I(self):
        """P * I: suggest reinterpret I->R or all_reduce P->I."""
        with self.assertRaises(SpmdTypeError) as ctx:
            infer_local_type_for_axis(
                self.tp, [P, I], linearity=OpLinearity.MULTILINEAR
            )
        self.assertExpectedInline(
            str(ctx.exception),
            """\
Invariant type on axis mesh_tp cannot mix with other types. Found types: [P, I]
Are you missing a collective or a reinterpret/convert call? e.g.,
  convert(tensor, mesh_tp, src=I, dst=R) on the Invariant operand (no-op forward, all-reduce in backward)
  all_reduce(tensor, mesh_tp, src=P, dst=I) on the Partial operand (all-reduce in forward, no-op backward)""",
        )


class TestOpLinearity(LocalTensorTestCase):
    """Test the OpLinearity parameter on infer_local_type_for_axis."""

    def test_all_p_linear_allowed(self):
        """All-P with LINEAR should return P."""
        result = infer_local_type_for_axis(
            self.pg, [P, P], linearity=OpLinearity.LINEAR
        )
        self.assertIs(result, P)

    def test_all_p_nonlinear_rejected(self):
        """All-P with NONLINEAR (default) should raise."""
        with self.assertRaises(SpmdTypeError):
            infer_local_type_for_axis(self.pg, [P, P])

    def test_mixed_p_r_rejected_even_linear(self):
        """Mixed P+R is rejected even with LINEAR."""
        with self.assertRaises(SpmdTypeError):
            infer_local_type_for_axis(self.pg, [P, R], linearity=OpLinearity.LINEAR)

    def test_all_r_unaffected_by_linearity(self):
        """All-R works regardless of linearity."""
        self.assertIs(infer_local_type_for_axis(self.pg, [R, R]), R)
        self.assertIs(
            infer_local_type_for_axis(self.pg, [R, R], linearity=OpLinearity.LINEAR), R
        )

    def test_multilinear_p_r_gives_p(self):
        """MULTILINEAR with P and R should return P."""
        result = infer_local_type_for_axis(
            self.pg, [P, R], linearity=OpLinearity.MULTILINEAR
        )
        self.assertIs(result, P)

    def test_multilinear_p_p_rejected(self):
        """MULTILINEAR with P*P should raise."""
        with self.assertRaises(SpmdTypeError):
            infer_local_type_for_axis(
                self.pg, [P, P], linearity=OpLinearity.MULTILINEAR
            )

    def test_multilinear_p_v_rejected(self):
        """MULTILINEAR with P and V should raise."""
        with self.assertRaises(SpmdTypeError):
            infer_local_type_for_axis(
                self.pg, [P, V], linearity=OpLinearity.MULTILINEAR
            )


class TestAssertTypeShardSugar(LocalTensorTestCase):
    """Test assert_type with S(i) sugar and PartitionSpec."""

    WORLD_SIZE = 6

    @classmethod
    def setUpClass(cls):
        super().setUpClass()
        mesh = init_device_mesh("cpu", (2, 3), mesh_dim_names=("dp", "tp"))
        cls.tp = mesh.get_group("tp")
        cls.dp = mesh.get_group("dp")

    def test_shard_sugar_sets_varying(self):
        """S(i) in types should set the axis to V in local types."""
        x = torch.randn(4)
        assert_type(x, {self.tp: S(0)})
        self.assertIs(get_axis_local_type(x, self.tp), V)

    def test_shard_sugar_duplicate_dim_rejected(self):
        """S(i) on multiple axes at the same dim requires explicit PartitionSpec."""
        x = torch.randn(4)
        with self.assertRaises(SpmdTypeError):
            assert_type(x, {self.dp: S(0), self.tp: S(0)})

    def test_shard_sugar_negative_dim(self):
        """S(-1) should resolve to the last dimension."""
        x = torch.randn(3, 4)
        assert_type(x, {self.tp: S(-1)})
        self.assertIs(get_axis_local_type(x, self.tp), V)

    def test_shard_sugar_with_partition_spec_rejected(self):
        """S(i) in types and explicit partition_spec are mutually exclusive."""
        x = torch.randn(3, 4)
        with self.assertRaises(SpmdTypeError):
            assert_type(x, {self.tp: S(1)}, PartitionSpec(None, self.tp))

    def test_partition_spec_sets_varying(self):
        """Axes in partition_spec should be treated as Varying."""
        x = torch.randn(3, 4)
        assert_type(x, {}, PartitionSpec(None, self.tp))
        self.assertIs(get_axis_local_type(x, self.tp), V)

    def test_partition_spec_wrong_length_rejected(self):
        """PartitionSpec length must match tensor ndim."""
        x = torch.randn(3, 4)
        with self.assertRaises(SpmdTypeError):
            assert_type(x, {}, PartitionSpec(self.tp))

    def test_partition_spec_conflicts_with_non_varying_rejected(self):
        """Axis in partition_spec that is R/I/P in types should be rejected."""
        x = torch.randn(3, 4)
        with self.assertRaises(SpmdTypeError):
            assert_type(x, {self.tp: R}, PartitionSpec(None, self.tp))

    def test_partition_spec_with_explicit_v_ok(self):
        """Explicit V in types for an axis in partition_spec should be allowed."""
        from sixlib.spmd_types.types import PartitionSpec

        x = torch.randn(3, 4)
        assert_type(x, {self.dp: V}, PartitionSpec(None, None))
        self.assertIs(get_axis_local_type(x, self.dp), V)

    def test_mixed_shard_and_local_types(self):
        """S(i) for one axis and R/I/P for another should work."""
        x = torch.randn(3, 4)
        assert_type(x, {self.dp: S(0), self.tp: I})
        self.assertIs(get_axis_local_type(x, self.dp), V)
        self.assertIs(get_axis_local_type(x, self.tp), I)

    def test_partition_spec_with_non_varying_types(self):
        """partition_spec with R/I axes in types should work if they don't overlap."""
        from sixlib.spmd_types.types import PartitionSpec

        x = torch.randn(3, 4)
        assert_type(x, {self.tp: I}, PartitionSpec(self.dp, None))
        self.assertIs(get_axis_local_type(x, self.tp), I)
        self.assertIs(get_axis_local_type(x, self.dp), V)

    def test_shard_sugar_out_of_bounds_rejected(self):
        """S(i) with out-of-bounds dim is an error."""
        x = torch.randn(3, 4)
        with self.assertRaises(SpmdTypeError):
            assert_type(x, {self.tp: S(2)})
        with self.assertRaises(SpmdTypeError):
            assert_type(x, {self.tp: S(-3)})

    def test_shard_sugar_0d_tensor_rejected(self):
        """S(i) on a 0-d tensor is out of bounds."""
        x = torch.tensor(1.0)
        with self.assertRaises(SpmdTypeError):
            assert_type(x, {self.tp: S(0)})


class TestOpLinearityRegistry(SpmdTypeCheckedTestCase):
    """Test that the expanded _OP_REGISTRY covers aliases, dunders, and structural ops."""

    def test_clone_functional_form(self):
        """torch.clone(P) should give P (functional form, not just Tensor.clone)."""
        x = self._generate_inputs((4,), self.pg, P)
        result = torch.clone(x)
        self.assertIs(get_axis_local_type(result, self.pg), P)

    def test_concat_aliases(self):
        """torch.concat and torch.concatenate should propagate P like torch.cat."""
        x = self._generate_inputs((4,), self.pg, P)
        y = self._generate_inputs((4,), self.pg, P)
        for fn in [torch.concat, torch.concatenate]:
            result = fn([x, y])
            self.assertIs(get_axis_local_type(result, self.pg), P)

    def test_structural_ops_preserve_p(self):
        """Structural ops (reshape, view, transpose, etc.) should preserve P."""
        x = self._generate_inputs((2, 3), self.pg, P)
        # NB: contiguous is registered but untestable here -- LocalTensorMode
        # decomposes it to per-rank calls that bypass type checking.
        ops = [
            ("reshape", lambda t: torch.reshape(t, (6,))),
            ("Tensor.view", lambda t: t.view(6)),
            ("transpose", lambda t: torch.transpose(t, 0, 1)),
            ("squeeze", lambda t: torch.squeeze(t.unsqueeze(0))),
            ("unsqueeze", lambda t: torch.unsqueeze(t, 0)),
            ("flatten", lambda t: torch.flatten(t)),
            ("expand", lambda t: t.unsqueeze(0).expand(2, 2, 3)),
            ("permute", lambda t: torch.permute(t, (1, 0))),
        ]
        for name, op in ops:
            result = op(x)
            self.assertIs(
                get_axis_local_type(result, self.pg),
                P,
                f"{name} did not preserve P type",
            )

    def test_neg_preserves_p(self):
        """torch.neg(P) and -P (unary neg operator) should both give P."""
        x = self._generate_inputs((4,), self.pg, P)
        result_func = torch.neg(x)
        self.assertIs(get_axis_local_type(result_func, self.pg), P)
        result_op = -x
        self.assertIs(get_axis_local_type(result_op, self.pg), P)

    def test_operator_add_p_p(self):
        """P + P via the + operator should give P."""
        x = self._generate_inputs((4,), self.pg, P)
        y = self._generate_inputs((4,), self.pg, P)
        result = x + y
        self.assertIs(get_axis_local_type(result, self.pg), P)

    def test_split_chunk_unbind_preserve_p(self):
        """Multi-output ops (split, chunk, unbind) should propagate P."""
        x = self._generate_inputs((6,), self.pg, P)
        for name, fn in [
            ("split", lambda t: torch.split(t, 3)),
            ("chunk", lambda t: torch.chunk(t, 2)),
            ("unbind", lambda t: torch.unbind(t.view(2, 3))),
        ]:
            results = fn(x)
            for i, r in enumerate(results):
                self.assertIs(
                    get_axis_local_type(r, self.pg),
                    P,
                    f"{name}[{i}] did not preserve P type",
                )

    def test_inplace_add_preserves_p(self):
        """P.add_(P) should give P."""
        x = self._generate_inputs((4,), self.pg, P)
        y = self._generate_inputs((4,), self.pg, P)
        x.add_(y)
        self.assertIs(get_axis_local_type(x, self.pg), P)

    def test_div_p_r_gives_p(self):
        """torch.div(P, R) should give P (linear in numerator when denominator is fixed)."""
        x = self._generate_inputs((4,), self.pg, P)
        y = self._generate_inputs((4,), self.pg, R)
        result = torch.div(x, y)
        self.assertIs(get_axis_local_type(result, self.pg), P)

    def test_div_r_p_rejected(self):
        """torch.div(R, P) should raise (P in denominator is not linear)."""
        x = self._generate_inputs((4,), self.pg, R)
        y = self._generate_inputs((4,), self.pg, P)
        with self.assertRaises(SpmdTypeError):
            torch.div(x, y)

    def test_div_p_p_rejected(self):
        """torch.div(P, P) should raise (P in denominator is not linear)."""
        x = self._generate_inputs((4,), self.pg, P)
        y = self._generate_inputs((4,), self.pg, P)
        with self.assertRaises(SpmdTypeError):
            torch.div(x, y)

    def test_div_r_v_gives_v(self):
        """torch.div(R, V) should give V (normal non-P path, no fixed_args filtering)."""
        x = self._generate_inputs((4,), self.pg, R)
        y = self._generate_inputs((4,), self.pg, V)
        result = torch.div(x, y)
        self.assertIs(get_axis_local_type(result, self.pg), V)

    def test_all_registered_ops_are_callable(self):
        """Every key in _OP_REGISTRY should be a callable (no stale references)."""
        from sixlib.spmd_types._checker import _OP_REGISTRY

        for func in _OP_REGISTRY:
            self.assertTrue(
                callable(func),
                f"Registry entry {func!r} is not callable",
            )

    def test_all_decomp_rules_are_callable(self):
        """Every key in _DECOMP_TYPE_RULES should be a callable."""
        from sixlib.spmd_types._checker import _DECOMP_TYPE_RULES

        for func in _DECOMP_TYPE_RULES:
            self.assertTrue(
                callable(func),
                f"Decomp rule entry {func!r} is not callable",
            )


class TestAddmmTypeDecomposition(SpmdTypeCheckedTestCase):
    """Test type-level decomposition for addmm and related ops.

    addmm(self, mat1, mat2) = self + mm(mat1, mat2) decomposes into a sum
    (LINEAR) of self and a matmul (MULTILINEAR) of mat1 and mat2. This catches
    bugs where e.g. addmm(P, R, R) was incorrectly accepted as P.
    """

    # --- addmm ---

    def test_addmm_P_R_R_rejected(self):
        """addmm(P, R, R) must error: R@R=R, then P+R is invalid."""
        self_t = self._generate_inputs((2, 3), self.pg, P)
        mat1 = self._generate_inputs((2, 4), self.pg, R)
        mat2 = self._generate_inputs((4, 3), self.pg, R)
        with self.assertRaises(SpmdTypeError):
            torch.addmm(self_t, mat1, mat2)

    def test_addmm_R_P_R_rejected(self):
        """addmm(R, P, R) must error: P@R=P, then P+R is invalid."""
        self_t = self._generate_inputs((2, 3), self.pg, R)
        mat1 = self._generate_inputs((2, 4), self.pg, P)
        mat2 = self._generate_inputs((4, 3), self.pg, R)
        with self.assertRaises(SpmdTypeError):
            torch.addmm(self_t, mat1, mat2)

    def test_addmm_R_R_P_rejected(self):
        """addmm(R, R, P) must error: R@P=P, then P+R is invalid."""
        self_t = self._generate_inputs((2, 3), self.pg, R)
        mat1 = self._generate_inputs((2, 4), self.pg, R)
        mat2 = self._generate_inputs((4, 3), self.pg, P)
        with self.assertRaises(SpmdTypeError):
            torch.addmm(self_t, mat1, mat2)

    def test_addmm_P_P_R_gives_P(self):
        """addmm(P, P, R): mm(P,R)=P, then P+P=P."""
        self_t = self._generate_inputs((2, 3), self.pg, P)
        mat1 = self._generate_inputs((2, 4), self.pg, P)
        mat2 = self._generate_inputs((4, 3), self.pg, R)
        result = torch.addmm(self_t, mat1, mat2)
        self.assertIs(get_axis_local_type(result, self.pg), P)

    def test_addmm_P_R_P_gives_P(self):
        """addmm(P, R, P): mm(R,P)=P, then P+P=P."""
        self_t = self._generate_inputs((2, 3), self.pg, P)
        mat1 = self._generate_inputs((2, 4), self.pg, R)
        mat2 = self._generate_inputs((4, 3), self.pg, P)
        result = torch.addmm(self_t, mat1, mat2)
        self.assertIs(get_axis_local_type(result, self.pg), P)

    def test_addmm_R_R_R_gives_R(self):
        """addmm(R, R, R) -> R (no change from before)."""
        self_t = self._generate_inputs((2, 3), self.pg, R)
        mat1 = self._generate_inputs((2, 4), self.pg, R)
        mat2 = self._generate_inputs((4, 3), self.pg, R)
        result = torch.addmm(self_t, mat1, mat2)
        self.assertIs(get_axis_local_type(result, self.pg), R)

    def test_addmm_V_R_R_gives_V(self):
        """addmm(V, R, R): mm(R,R)=R, then V+R=V."""
        self_t = self._generate_inputs((2, 3), self.pg, V)
        mat1 = self._generate_inputs((2, 4), self.pg, R)
        mat2 = self._generate_inputs((4, 3), self.pg, R)
        result = torch.addmm(self_t, mat1, mat2)
        self.assertIs(get_axis_local_type(result, self.pg), V)

    def test_addmm_R_P_P_rejected(self):
        """addmm(R, P, P): mm(P,P) is invalid (two P factors in multilinear)."""
        self_t = self._generate_inputs((2, 3), self.pg, R)
        mat1 = self._generate_inputs((2, 4), self.pg, P)
        mat2 = self._generate_inputs((4, 3), self.pg, P)
        with self.assertRaises(SpmdTypeError):
            torch.addmm(self_t, mat1, mat2)

    def test_addmm_V_V_V_gives_V(self):
        """addmm(V, V, V): mm(V,V)=V, then V+V=V."""
        self_t = self._generate_inputs((2, 3), self.pg, V)
        mat1 = self._generate_inputs((2, 4), self.pg, V)
        mat2 = self._generate_inputs((4, 3), self.pg, V)
        result = torch.addmm(self_t, mat1, mat2)
        self.assertIs(get_axis_local_type(result, self.pg), V)

    # --- addmv ---

    def test_addmv_P_R_R_rejected(self):
        """addmv(P, R, R) must error."""
        self_t = self._generate_inputs((3,), self.pg, P)
        mat = self._generate_inputs((3, 4), self.pg, R)
        vec = self._generate_inputs((4,), self.pg, R)
        with self.assertRaises(SpmdTypeError):
            torch.addmv(self_t, mat, vec)

    def test_addmv_P_P_R_gives_P(self):
        """addmv(P, P, R): mv(P,R)=P, then P+P=P."""
        self_t = self._generate_inputs((3,), self.pg, P)
        mat = self._generate_inputs((3, 4), self.pg, P)
        vec = self._generate_inputs((4,), self.pg, R)
        result = torch.addmv(self_t, mat, vec)
        self.assertIs(get_axis_local_type(result, self.pg), P)

    def test_addmv_R_R_R_gives_R(self):
        """addmv(R, R, R) -> R."""
        self_t = self._generate_inputs((3,), self.pg, R)
        mat = self._generate_inputs((3, 4), self.pg, R)
        vec = self._generate_inputs((4,), self.pg, R)
        result = torch.addmv(self_t, mat, vec)
        self.assertIs(get_axis_local_type(result, self.pg), R)

    # --- baddbmm ---

    def test_baddbmm_P_R_R_rejected(self):
        """baddbmm(P, R, R) must error."""
        self_t = self._generate_inputs((2, 3, 5), self.pg, P)
        batch1 = self._generate_inputs((2, 3, 4), self.pg, R)
        batch2 = self._generate_inputs((2, 4, 5), self.pg, R)
        with self.assertRaises(SpmdTypeError):
            torch.baddbmm(self_t, batch1, batch2)

    def test_baddbmm_P_P_R_gives_P(self):
        """baddbmm(P, P, R): bmm(P,R)=P, then P+P=P."""
        self_t = self._generate_inputs((2, 3, 5), self.pg, P)
        batch1 = self._generate_inputs((2, 3, 4), self.pg, P)
        batch2 = self._generate_inputs((2, 4, 5), self.pg, R)
        result = torch.baddbmm(self_t, batch1, batch2)
        self.assertIs(get_axis_local_type(result, self.pg), P)

    def test_baddbmm_R_R_R_gives_R(self):
        """baddbmm(R, R, R) -> R."""
        self_t = self._generate_inputs((2, 3, 5), self.pg, R)
        batch1 = self._generate_inputs((2, 3, 4), self.pg, R)
        batch2 = self._generate_inputs((2, 4, 5), self.pg, R)
        result = torch.baddbmm(self_t, batch1, batch2)
        self.assertIs(get_axis_local_type(result, self.pg), R)

    # --- addr ---

    def test_addr_P_R_R_rejected(self):
        """addr(P, R, R) must error."""
        self_t = self._generate_inputs((3, 4), self.pg, P)
        vec1 = self._generate_inputs((3,), self.pg, R)
        vec2 = self._generate_inputs((4,), self.pg, R)
        with self.assertRaises(SpmdTypeError):
            torch.addr(self_t, vec1, vec2)

    def test_addr_P_P_R_gives_P(self):
        """addr(P, P, R): outer(P,R)=P, then P+P=P."""
        self_t = self._generate_inputs((3, 4), self.pg, P)
        vec1 = self._generate_inputs((3,), self.pg, P)
        vec2 = self._generate_inputs((4,), self.pg, R)
        result = torch.addr(self_t, vec1, vec2)
        self.assertIs(get_axis_local_type(result, self.pg), P)

    def test_addr_R_R_R_gives_R(self):
        """addr(R, R, R) -> R."""
        self_t = self._generate_inputs((3, 4), self.pg, R)
        vec1 = self._generate_inputs((3,), self.pg, R)
        vec2 = self._generate_inputs((4,), self.pg, R)
        result = torch.addr(self_t, vec1, vec2)
        self.assertIs(get_axis_local_type(result, self.pg), R)

    # --- sum/mean (LINEAR reductions) ---

    def test_sum_P_gives_P(self):
        """torch.sum(P) -> P (sum is linear)."""
        x = self._generate_inputs((2, 3), self.pg, P)
        result = torch.sum(x)
        self.assertIs(get_axis_local_type(result, self.pg), P)

    def test_mean_P_gives_P(self):
        """torch.mean(P) -> P (mean is linear)."""
        # randn already produces float32 so torch.mean works directly
        x = self._generate_inputs((2, 3), self.pg, P)
        result = torch.mean(x)
        self.assertIs(get_axis_local_type(result, self.pg), P)


class TestScalarWrapper(SpmdTypeCheckedTestCase):
    """Test the Scalar wrapper for annotating Python scalars with SPMD types."""

    def test_scalar_get_local_type(self):
        """get_local_type returns the stored type."""
        s = Scalar(1.0, {self.pg: R})
        self.assertEqual(get_axis_local_type(s, self.pg), R)

    def test_add_r_scalar_v(self):
        """torch.add(R, Scalar(V)) -> V.

        With a plain 1.0, R + scalar -> R. With Scalar(1.0, {tp: V}),
        R + V -> V. This catches rank-dependent scalars.
        """
        x = self._generate_inputs((4,), self.pg, R)
        s = Scalar(1.0, {self.pg: V})
        result = torch.add(x, s)
        self.assertIs(get_axis_local_type(result, self.pg), V)

    def test_add_v_scalar_v(self):
        """torch.add(V, Scalar(V)) -> V."""
        x = self._generate_inputs((4,), self.pg, V)
        s = Scalar(1.0, {self.pg: V})
        result = torch.add(x, s)
        self.assertIs(get_axis_local_type(result, self.pg), V)

    def test_mul_p_scalar_r(self):
        """torch.mul(P, Scalar(R)) -> P (multilinear)."""
        x = self._generate_inputs((4,), self.pg, P)
        s = Scalar(2.0, {self.pg: R})
        result = torch.mul(x, s)
        self.assertIs(get_axis_local_type(result, self.pg), P)

    def test_add_p_scalar_p(self):
        """torch.add(P, Scalar(P)) -> P (linear)."""
        x = self._generate_inputs((4,), self.pg, P)
        s = Scalar(1.0, {self.pg: P})
        result = torch.add(x, s)
        self.assertIs(get_axis_local_type(result, self.pg), P)

    def test_add_r_scalar_p_error(self):
        """torch.add(R, Scalar(P)) -> SpmdTypeError (P+R is affine).

        With a plain 1.0, R + scalar -> R. With Scalar(local_sum, {tp: P}),
        R + P is invalid (affine, not linear).
        """
        x = self._generate_inputs((4,), self.pg, R)
        s = Scalar(1.0, {self.pg: P})
        with self.assertRaises(SpmdTypeError):
            torch.add(x, s)

    def test_add_i_scalar_v_error(self):
        """torch.add(I, Scalar(V)) -> SpmdTypeError (I can't mix)."""
        x = self._generate_inputs((4,), self.pg, I)
        s = Scalar(1.0, {self.pg: V})
        with self.assertRaises(SpmdTypeError):
            torch.add(x, s)

    def test_narrow_r_scalar_v_gives_v(self):
        """torch.narrow(R, dim, Scalar(V), Scalar(V)) -> V.

        narrow is LINEAR with only tensor_args=(0,), so the dim/start/length
        args are not checked by _collect_scalar_types.  But if start or length
        is Scalar(V), the output varies across ranks and must be V, not R.
        """
        x = self._generate_inputs((8,), self.pg, R)
        start = Scalar(0, {self.pg: V})
        length = Scalar(2, {self.pg: V})
        result = torch.narrow(x, 0, start, length)
        self.assertIs(get_axis_local_type(result, self.pg), V)

    def test_narrow_p_scalar_v_error(self):
        """torch.narrow(P, dim, Scalar(V), Scalar(V)) -> SpmdTypeError.

        P + V is always invalid.
        """
        x = self._generate_inputs((8,), self.pg, P)
        start = Scalar(0, {self.pg: V})
        length = Scalar(2, {self.pg: V})
        with self.assertRaises(SpmdTypeError):
            torch.narrow(x, 0, start, length)

    def test_narrow_r_scalar_r_gives_r(self):
        """torch.narrow(R, dim, Scalar(R), Scalar(R)) -> R.

        Replicated scalars at non-tensor-arg positions don't change the type.
        """
        x = self._generate_inputs((8,), self.pg, R)
        start = Scalar(0, {self.pg: R})
        length = Scalar(2, {self.pg: R})
        result = torch.narrow(x, 0, start, length)
        self.assertIs(get_axis_local_type(result, self.pg), R)

    def test_scalar_without_type_mode(self):
        """Scalar unwraps and computes without type checking."""
        from sixlib.spmd_types._checker import no_typecheck

        with no_typecheck():
            x = torch.tensor([1.0, 2.0, 3.0])
            s = Scalar(2.0, {self.pg: V})
            result = torch.mul(x, s)
            expected = torch.tensor([2.0, 4.0, 6.0])
            torch.testing.assert_close(result, expected)

    def test_scalar_drops_singleton_axis(self):
        """Scalar.__init__ drops size-1 axes, matching _validate behavior."""
        import torch.distributed as dist

        singleton_pg = dist.new_group(ranks=[0])
        s = Scalar(1.0, {self.pg: V, singleton_pg: V})
        local_type = s.local_type
        # The size-1 axis should be dropped.
        self.assertEqual(len(local_type), 1)
        self.assertIs(get_axis_local_type(s, self.pg), V)

    def test_scalar_all_singleton_gives_empty_type(self):
        """Scalar with only size-1 axes produces an empty type dict."""
        import torch.distributed as dist

        singleton_pg = dist.new_group(ranks=[0])
        s = Scalar(42, {singleton_pg: V})
        self.assertEqual(s.local_type, {})

    def test_narrow_r_scalar_v_with_singleton_axis(self):
        """narrow(R, Scalar(V)) works when Scalar also has a size-1 axis.

        This is the HSDP DDP=1 scenario: tensor has type {shard_pg: R} and
        Scalar has {shard_pg: V, replicate_pg: V} where replicate_pg has
        size 1. Without dropping the singleton axis in Scalar, the key sets
        mismatch and type checking fails.
        """
        import torch.distributed as dist

        singleton_pg = dist.new_group(ranks=[0])
        x = self._generate_inputs((8,), self.pg, R)
        start = Scalar(0, {self.pg: V, singleton_pg: V})
        length = Scalar(2, {self.pg: V, singleton_pg: V})
        result = torch.narrow(x, 0, start, length)
        self.assertIs(get_axis_local_type(result, self.pg), V)

    def test_scalar_arithmetic_drops_singleton_axis(self):
        """Scalar arithmetic propagates only non-singleton axes."""
        import torch.distributed as dist

        singleton_pg = dist.new_group(ranks=[0])
        a = Scalar(3, {self.pg: V, singleton_pg: V})
        b = Scalar(4, {self.pg: R, singleton_pg: R})
        result = a + b
        self.assertIsInstance(result, Scalar)
        local_type = result.local_type
        # Only the non-singleton axis should survive.
        self.assertEqual(len(local_type), 1)
        self.assertIs(local_type[normalize_axis(self.pg)], V)


class TestThreadLocalState(SpmdTypeCheckedTestCase):
    """Test thread-local state helpers: is_type_checking, no_typecheck."""

    def test_is_type_checking_inside_context(self):
        """is_type_checking() returns True inside typecheck context."""
        from sixlib.spmd_types._state import is_type_checking

        self.assertTrue(is_type_checking())

    def test_no_typecheck_pauses(self):
        """no_typecheck() makes is_type_checking() return False."""
        from sixlib.spmd_types._checker import no_typecheck
        from sixlib.spmd_types._state import is_type_checking

        self.assertTrue(is_type_checking())
        with no_typecheck():
            self.assertFalse(is_type_checking())
        self.assertTrue(is_type_checking())

    def test_no_typecheck_noop_outside(self):
        """no_typecheck() is a no-op when no mode is active."""
        from sixlib.spmd_types._checker import no_typecheck
        from sixlib.spmd_types._state import is_type_checking

        # Temporarily exit type checking entirely to test the no-op case.
        self._type_checking_cm.__exit__(None, None, None)
        try:
            self.assertFalse(is_type_checking())
            with no_typecheck():
                self.assertFalse(is_type_checking())
        finally:
            # Re-enter for tearDown.
            self._type_checking_cm = typecheck()
            self._type_checking_cm.__enter__()

    def test_reentrant_noop(self):
        """typecheck() inside active mode is a no-op (does not nest modes)."""
        from sixlib.spmd_types._state import _tls, is_type_checking

        outer = getattr(_tls, "active_mode", None)
        self.assertIsNotNone(outer)
        with typecheck():
            self.assertIs(getattr(_tls, "active_mode", None), outer)
        self.assertTrue(is_type_checking())
        self.assertIs(getattr(_tls, "active_mode", None), outer)

    def test_typecheck_inside_no_typecheck_reuses_mode(self):
        """typecheck() inside no_typecheck() reuses the existing mode."""
        from sixlib.spmd_types._checker import no_typecheck
        from sixlib.spmd_types._state import _tls, is_type_checking

        outer = getattr(_tls, "active_mode", None)
        self.assertIsNotNone(outer)
        with no_typecheck():
            self.assertFalse(is_type_checking())
            with typecheck():
                # Should reuse the outer mode, not create a new one.
                self.assertIs(getattr(_tls, "active_mode", None), outer)
                self.assertTrue(is_type_checking())
                # Type inference should work inside the inner typecheck.
                x = self._generate_inputs((4,), self.pg, R)
                y = self._generate_inputs((4,), self.pg, V)
                result = torch.add(x, y)
                self.assertIs(get_axis_local_type(result, self.pg), V)
            self.assertFalse(is_type_checking())

    def test_typecheck_resumes_inside_no_typecheck(self):
        """typecheck() re-enables checking inside no_typecheck()."""
        from sixlib.spmd_types._checker import no_typecheck
        from sixlib.spmd_types._state import is_type_checking

        self.assertTrue(is_type_checking())
        with no_typecheck():
            self.assertFalse(is_type_checking())
            with typecheck():
                self.assertTrue(is_type_checking())
                # Type inference should work.
                x = self._generate_inputs((4,), self.pg, R)
                y = self._generate_inputs((4,), self.pg, V)
                result = torch.add(x, y)
                self.assertIs(get_axis_local_type(result, self.pg), V)
            self.assertFalse(is_type_checking())
        self.assertTrue(is_type_checking())

    def test_typecheck_inherits_strict_mode(self):
        """typecheck() without strict_mode inherits the current strict mode."""
        from sixlib.spmd_types import _state
        from sixlib.spmd_types._checker import no_typecheck

        # Outer mode is "strict" (the default from setUp).
        with no_typecheck():
            with typecheck():
                mode = getattr(_state._tls, "active_mode", None)
                self.assertIsNotNone(mode)
                self.assertTrue(mode._strict)

        # Now test with permissive outer mode.
        self._type_checking_cm.__exit__(None, None, None)
        try:
            self._type_checking_cm = typecheck(strict_mode="permissive")
            self._type_checking_cm.__enter__()
            with no_typecheck():
                with typecheck():
                    mode = getattr(_state._tls, "active_mode", None)
                    self.assertIsNotNone(mode)
                    self.assertFalse(mode._strict)
        finally:
            self._type_checking_cm.__exit__(None, None, None)
            self._type_checking_cm = typecheck()
            self._type_checking_cm.__enter__()

    def test_typecheck_resume_noop_when_not_disabled(self):
        """typecheck() without args is a no-op when checking is already active."""
        from sixlib.spmd_types._state import is_type_checking

        self.assertTrue(is_type_checking())
        with typecheck():
            self.assertTrue(is_type_checking())
            x = self._generate_inputs((4,), self.pg, R)
            y = self._generate_inputs((4,), self.pg, R)
            result = torch.add(x, y)
            self.assertIs(get_axis_local_type(result, self.pg), R)
        self.assertTrue(is_type_checking())


class TestMutationTypeChecking(SpmdTypeCheckedTestCase):
    """Test that in-place/out operations validate SPMD type consistency.

    Mutating operations (trailing underscore, out= kwarg, result-is-input
    identity) must not silently change a tensor's SPMD type. For example,
    x.add_(y) where x=R and y=V would infer V output, but since x is R
    and is being mutated, this is an error.
    """

    # --- In-place ops that preserve type (should pass) ---

    def test_inplace_add_r_r_ok(self):
        """R.add_(R) -> R: type preserved, no error."""
        x = self._generate_inputs((4,), self.pg, R)
        y = self._generate_inputs((4,), self.pg, R)
        x.add_(y)
        self.assertIs(get_axis_local_type(x, self.pg), R)

    def test_inplace_add_v_v_ok(self):
        """V.add_(V) -> V: type preserved, no error."""
        x = self._generate_inputs((4,), self.pg, V)
        y = self._generate_inputs((4,), self.pg, V)
        x.add_(y)
        self.assertIs(get_axis_local_type(x, self.pg), V)

    def test_inplace_add_v_r_ok(self):
        """V.add_(R) -> V: output is V, self is V, type preserved."""
        x = self._generate_inputs((4,), self.pg, V)
        y = self._generate_inputs((4,), self.pg, R)
        x.add_(y)
        self.assertIs(get_axis_local_type(x, self.pg), V)

    def test_inplace_mul_v_scalar_ok(self):
        """V.mul_(2.0) -> V: type preserved."""
        x = self._generate_inputs((4,), self.pg, V)
        x.mul_(2.0)
        self.assertIs(get_axis_local_type(x, self.pg), V)

    def test_inplace_neg_r_ok(self):
        """R.neg_() -> R: type preserved."""
        x = self._generate_inputs((4,), self.pg, R)
        x.neg_()
        self.assertIs(get_axis_local_type(x, self.pg), R)

    # --- In-place ops that would change type (should error) ---

    def test_inplace_add_r_v_rejected(self):
        """R.add_(V): output would be V but self is R. Error."""
        x = self._generate_inputs((4,), self.pg, R)
        y = self._generate_inputs((4,), self.pg, V)
        with self.assertRaises(SpmdTypeError) as ctx:
            x.add_(y)
        self.assertIn("in-place/out", str(ctx.exception))

    def test_inplace_mul_r_v_rejected(self):
        """R.mul_(V): output would be V but self is R. Error."""
        x = self._generate_inputs((4,), self.pg, R)
        y = self._generate_inputs((4,), self.pg, V)
        with self.assertRaises(SpmdTypeError) as ctx:
            x.mul_(y)
        self.assertIn("in-place/out", str(ctx.exception))

    def test_iadd_r_v_rejected(self):
        """R += V via __iadd__: should also be caught."""
        x = self._generate_inputs((4,), self.pg, R)
        y = self._generate_inputs((4,), self.pg, V)
        with self.assertRaises(SpmdTypeError):
            x += y

    # --- out= kwarg ops ---

    def test_out_kwarg_matching_type_ok(self):
        """torch.add(R, R, out=R_tensor): output R matches out tensor R."""
        a = self._generate_inputs((4,), self.pg, R)
        b = self._generate_inputs((4,), self.pg, R)
        c = self._generate_inputs((4,), self.pg, R)
        torch.add(a, b, out=c)
        self.assertIs(get_axis_local_type(c, self.pg), R)

    def test_out_kwarg_type_mismatch_rejected(self):
        """torch.add(R, V, out=R_tensor): output V but out is R. Error."""
        a = self._generate_inputs((4,), self.pg, R)
        b = self._generate_inputs((4,), self.pg, V)
        c = self._generate_inputs((4,), self.pg, R)
        with self.assertRaises(SpmdTypeError) as ctx:
            torch.add(a, b, out=c)
        self.assertIn("in-place/out", str(ctx.exception))

    def test_out_kwarg_untyped_ok(self):
        """torch.add(R, R, out=untyped): untyped out tensor is fine."""
        a = self._generate_inputs((4,), self.pg, R)
        b = self._generate_inputs((4,), self.pg, R)
        c = self.rank_map(lambda r: torch.empty(4))
        torch.add(a, b, out=c)
        self.assertIs(get_axis_local_type(c, self.pg), R)

    def test_out_kwarg_v_output_into_v_ok(self):
        """torch.add(R, V, out=V_tensor): output V, out is V. OK."""
        a = self._generate_inputs((4,), self.pg, R)
        b = self._generate_inputs((4,), self.pg, V)
        c = self._generate_inputs((4,), self.pg, V)
        torch.add(a, b, out=c)
        self.assertIs(get_axis_local_type(c, self.pg), V)

    def test_inplace_p_p_add_ok(self):
        """P.add_(P) -> P: type preserved (linear op)."""
        x = self._generate_inputs((4,), self.pg, P)
        y = self._generate_inputs((4,), self.pg, P)
        x.add_(y)
        self.assertIs(get_axis_local_type(x, self.pg), P)


class TestMutateType(LocalTensorTestCase):
    """Test mutate_type for explicit single-axis type transitions."""

    WORLD_SIZE = 6

    @classmethod
    def setUpClass(cls):
        super().setUpClass()
        mesh = init_device_mesh("cpu", (2, 3), mesh_dim_names=("dp", "tp"))
        cls.tp = mesh.get_group("tp")
        cls.dp = mesh.get_group("dp")

    def test_basic_mutation(self):
        """Mutate a single axis from V to R."""
        x = torch.randn(4)
        assert_type(x, {self.dp: V})
        mutate_type(x, self.dp, src=V, dst=R)
        self.assertIs(get_axis_local_type(x, self.dp), R)

    def test_shard_sugar_src(self):
        """S(i) is accepted as src and compared as V."""
        x = torch.randn(4)
        assert_type(x, {self.dp: S(0)})
        mutate_type(x, self.dp, src=S(0), dst=R)
        self.assertIs(get_axis_local_type(x, self.dp), R)

    def test_shard_sugar_dst(self):
        """S(i) is accepted as dst and stored as V."""
        x = torch.randn(4)
        assert_type(x, {self.dp: R})
        mutate_type(x, self.dp, src=R, dst=S(0))
        self.assertIs(get_axis_local_type(x, self.dp), V)

    def test_preserves_other_axes(self):
        """Mutating one axis must not affect other axes."""
        x = torch.randn(4)
        assert_type(x, {self.dp: V, self.tp: I})
        mutate_type(x, self.dp, src=V, dst=R)
        self.assertIs(get_axis_local_type(x, self.dp), R)
        self.assertIs(get_axis_local_type(x, self.tp), I)

    def test_wrong_src_raises(self):
        """Mismatched src raises SpmdTypeError."""
        x = torch.randn(4)
        assert_type(x, {self.dp: V})
        with self.assertRaises(SpmdTypeError):
            mutate_type(x, self.dp, src=R, dst=I)

    def test_missing_axis_raises(self):
        """Axis not present in tensor's type raises SpmdTypeError."""
        x = torch.randn(4)
        assert_type(x, {self.dp: V})
        with self.assertRaises(SpmdTypeError):
            mutate_type(x, self.tp, src=V, dst=R)

    def test_unannotated_tensor_raises(self):
        """Tensor with no type at all raises SpmdTypeError."""
        x = torch.randn(4)
        with self.assertRaises(SpmdTypeError):
            mutate_type(x, self.dp, src=V, dst=R)

    def test_returns_tensor(self):
        """mutate_type returns the tensor for chaining."""
        x = torch.randn(4)
        assert_type(x, {self.dp: V})
        result = mutate_type(x, self.dp, src=V, dst=R)
        self.assertIs(result, x)


class TestAutogradFunctionApply(SpmdTypeCheckedTestCase):
    """Test autograd Function.apply monkeypatch and registration mechanism."""

    def _make_local_func(self):
        """Create and register a simple local-only autograd Function."""
        from sixlib.spmd_types._checker import register_local_autograd_function

        @register_local_autograd_function
        class LocalOp(torch.autograd.Function):
            @staticmethod
            def forward(ctx, x):
                return x * 2

            @staticmethod
            def backward(ctx, g):
                return g * 2

        return LocalOp

    def _make_unregistered_func(self):
        """Create an autograd Function without registering it."""

        class UnregisteredOp(torch.autograd.Function):
            @staticmethod
            def forward(ctx, x):
                return x * 3

            @staticmethod
            def backward(ctx, g):
                return g * 3

        return UnregisteredOp

    def test_registered_propagates_type(self):
        """Registered local autograd Function propagates SPMD types."""
        LocalOp = self._make_local_func()
        x = self._generate_inputs((4,), self.pg, R)
        result = LocalOp.apply(x)
        self.assertIs(get_axis_local_type(result, self.pg), R)

    def test_registered_propagates_v(self):
        """Registered local autograd Function propagates V type."""
        LocalOp = self._make_local_func()
        x = self._generate_inputs((4,), self.pg, V)
        result = LocalOp.apply(x)
        self.assertIs(get_axis_local_type(result, self.pg), V)

    def test_unregistered_raises_in_strict_mode(self):
        """Unregistered autograd Function raises SpmdTypeError in strict mode."""
        UnregisteredOp = self._make_unregistered_func()
        x = self._generate_inputs((4,), self.pg, R)
        with self.assertRaises(SpmdTypeError) as ctx:
            UnregisteredOp.apply(x)
        self.assertIn("not registered for SPMD type checking", str(ctx.exception))

    def test_unregistered_skips_in_nonstrict_mode(self):
        """Unregistered autograd Function leaves output untyped in non-strict mode."""
        UnregisteredOp = self._make_unregistered_func()
        # Exit strict mode, enter non-strict
        self._type_checking_cm.__exit__(None, None, None)
        self._type_checking_cm = typecheck(strict_mode="permissive")
        self._type_checking_cm.__enter__()

        x = self._generate_inputs((4,), self.pg, V)
        result = UnregisteredOp.apply(x)
        self.assertEqual(get_local_type(result), {})

    def test_registered_multi_tensor_inputs(self):
        """Registered autograd Function with multiple typed tensor inputs."""
        from sixlib.spmd_types._checker import register_local_autograd_function

        @register_local_autograd_function
        class MultiInputOp(torch.autograd.Function):
            @staticmethod
            def forward(ctx, a, b):
                return a + b

            @staticmethod
            def backward(ctx, g):
                return g, g

        a = self._generate_inputs((4,), self.pg, R)
        b = self._generate_inputs((4,), self.pg, R)
        result = MultiInputOp.apply(a, b)
        self.assertIs(get_axis_local_type(result, self.pg), R)

    def test_typecheck_forward_sets_output_type(self):
        """typecheck_forward calls .apply() and sets output type."""
        from sixlib.spmd_types._checker import assert_type, register_autograd_function

        @register_autograd_function
        class CheckedOp(torch.autograd.Function):
            @staticmethod
            def forward(ctx, x):
                return x * 2

            @staticmethod
            def typecheck_forward(x):
                assert_type(x, {self.pg: R})
                out = CheckedOp.apply(x)
                assert_type(out, {self.pg: R})
                return out

            @staticmethod
            def backward(ctx, g):
                return g * 2

        x = self._generate_inputs((4,), self.pg, R)
        result = CheckedOp.apply(x)
        self.assertIs(get_axis_local_type(result, self.pg), R)

    def test_typecheck_forward_raises_on_wrong_input(self):
        """typecheck_forward can validate inputs via assert_type."""
        from sixlib.spmd_types._checker import (
            assert_type,
            register_autograd_function,
        )

        @register_autograd_function
        class StrictCheckOp(torch.autograd.Function):
            @staticmethod
            def forward(ctx, x):
                return x * 2

            @staticmethod
            def typecheck_forward(x):
                # Expects V, but we'll pass R
                assert_type(x, {self.pg: V})
                out = StrictCheckOp.apply(x)
                assert_type(out, {self.pg: V})
                return out

            @staticmethod
            def backward(ctx, g):
                return g * 2

        x = self._generate_inputs((4,), self.pg, R)
        with self.assertRaises(SpmdTypeError):
            StrictCheckOp.apply(x)

    def test_typecheck_forward_overrides_local_default(self):
        """register_autograd_function produces different types than local-only.

        The local-only rule for infer_output_type([V, R]) would produce V.
        typecheck_forward sets R instead (e.g., because the function does an
        internal all-reduce).
        """
        from sixlib.spmd_types._checker import assert_type, register_autograd_function

        @register_autograd_function
        class OverrideOp(torch.autograd.Function):
            @staticmethod
            def forward(ctx, x, y):
                return x + y

            @staticmethod
            def typecheck_forward(x, y):
                out = OverrideOp.apply(x, y)
                assert_type(out, {self.pg: R})
                return out

            @staticmethod
            def backward(ctx, g):
                return g, g

        x = self._generate_inputs((4,), self.pg, V)
        y = self._generate_inputs((4,), self.pg, R)
        result = OverrideOp.apply(x, y)
        # Local-only rule would give V; typecheck_forward sets R.
        self.assertIs(get_axis_local_type(result, self.pg), R)

    def test_typecheck_forward_receives_all_args(self):
        """typecheck_forward receives tensor and non-tensor args."""
        from sixlib.spmd_types._checker import assert_type, register_autograd_function

        received = {}

        @register_autograd_function
        class ArgsOp(torch.autograd.Function):
            @staticmethod
            def forward(ctx, x, scale):
                return x * scale

            @staticmethod
            def typecheck_forward(x, scale):
                received["x"] = x
                received["scale"] = scale
                out = ArgsOp.apply(x, scale)
                assert_type(out, {self.pg: R})
                return out

            @staticmethod
            def backward(ctx, g):
                return g, None

        x = self._generate_inputs((4,), self.pg, R)
        result = ArgsOp.apply(x, 2.0)
        self.assertIs(received["x"], x)
        self.assertEqual(received["scale"], 2.0)
        self.assertIs(get_axis_local_type(result, self.pg), R)

    def test_patch_only_active_during_mode(self):
        """Monkeypatch is only active while typecheck is entered."""
        # Inside the mode, apply goes through __torch_function__
        LocalOp = self._make_local_func()
        x = self._generate_inputs((4,), self.pg, R)
        LocalOp.apply(x)

        # Exit all modes
        self._type_checking_cm.__exit__(None, None, None)

        # Outside the mode, apply should work normally (no type propagation)
        plain = torch.randn(4)
        result2 = LocalOp.apply(plain)
        self.assertEqual(get_local_type(result2), {})

        # Re-enter for tearDown
        self._type_checking_cm = typecheck()
        self._type_checking_cm.__enter__()

    def test_mixed_empty_typed_raises_even_if_registered(self):
        """Mixed typed + {} inputs raise in strict mode for all ops.

        {} typed tensors (from factory ops) must be annotated with
        assert_type() before being mixed with tensors that have real
        axes, even for registered local autograd Functions.
        """
        from sixlib.spmd_types._checker import register_local_autograd_function

        @register_local_autograd_function
        class MixedOp(torch.autograd.Function):
            @staticmethod
            def forward(ctx, x, dummy):
                return x + dummy

            @staticmethod
            def backward(ctx, g):
                return g, None

        x = self._generate_inputs((4,), self.pg, R)
        dummy = torch.zeros(4)  # {} typed tensor
        with self.assertRaises(SpmdTypeError):
            MixedOp.apply(x, dummy)


class TestVmapWithSpmdTypeMode(unittest.TestCase):
    """Test vmap compatibility with SpmdTypeMode's autograd apply monkeypatch."""

    def test_vmap_compatible_with_generate_vmap_rule(self):
        """Monkeypatch preserves vmap dispatch for autograd functions with generate_vmap_rule.

        Regression test: the old monkeypatch saved _FunctionBase.apply (raw C++
        apply) instead of Function.apply (Python classmethod that handles
        vmap/functorch dispatch).  This caused autograd functions with
        generate_vmap_rule=True to crash under vmap with a
        dynamicLayerStack assertion failure.
        """

        class VmapOp(torch.autograd.Function):
            generate_vmap_rule = True

            @staticmethod
            def forward(x):
                return x * 2

            @staticmethod
            def setup_context(ctx, inputs, output):
                pass

        with typecheck(strict_mode="permissive"):
            x = torch.randn(3, 4)
            result = torch.vmap(VmapOp.apply)(x)
            torch.testing.assert_close(result, x * 2)


class TestOrthogonalityValidation(LocalTensorTestCase):
    """Test that _validate() rejects non-orthogonal mesh axes.

    The core invariant: all mesh axes in a tensor's LocalSpmdType dict must be
    mutually orthogonal (they tile different dimensions of the mesh without
    rank collisions). Overlapping axes produce incorrect type inference results
    because type inference reasons about each axis independently.
    """

    WORLD_SIZE = 8

    @classmethod
    def setUpClass(cls):
        super().setUpClass()
        from sixlib.spmd_types._mesh_axis import MeshAxis

        # Orthogonal axes: dp (size=2, stride=4) and tp (size=4, stride=1)
        # dp generates ranks {0, 4}, tp generates ranks {0, 1, 2, 3}
        # Combined: 2*4 = 8 unique ranks -- orthogonal.
        cls.dp = MeshAxis.of(2, 4)
        cls.tp = MeshAxis.of(4, 1)

        # Overlapping axis: dp_cp (size=4, stride=2) overlaps with dp above.
        # dp generates ranks {0, 4}, dp_cp generates ranks {0, 2, 4, 6}
        # They share rank 0 and rank 4.
        cls.dp_cp = MeshAxis.of(4, 2)

        # A small axis for three-way tests: size=2, stride=1
        cls.small = MeshAxis.of(2, 1)

    def test_overlapping_axes_rejected(self):
        """Subset relationship: dp <= dp_cp, so they share ranks."""
        x = torch.randn(4)
        with self.assertRaises(SpmdTypeError) as ctx:
            assert_type(x, {self.dp: R, self.dp_cp: V})
        self.assertIn("not orthogonal", str(ctx.exception))

    def test_same_axis_handled_by_dict_dedup(self):
        """Same axis used twice in a dict -- Python dict deduplicates keys."""
        x = torch.randn(4)
        # Python dict dedup: {dp: R, dp: V} -> {dp: V}, so only one key.
        assert_type(x, {self.dp: R, self.dp: V})

    def test_orthogonal_axes_from_init_device_mesh(self):
        """Axes from init_device_mesh are orthogonal by construction."""
        mesh = init_device_mesh("cpu", (2, 4), mesh_dim_names=("dp", "tp"))
        dp_pg = mesh.get_group("dp")
        tp_pg = mesh.get_group("tp")
        x = torch.randn(4)
        # Should not raise.
        assert_type(x, {dp_pg: R, tp_pg: V})

    def test_single_axis_skips_check(self):
        """Single-axis dicts skip the orthogonality check entirely."""
        x = torch.randn(4)
        # Should not raise -- only one axis, nothing to check.
        assert_type(x, {self.dp: R})

    def test_size_1_axes_always_orthogonal(self):
        """Size-1 axes are always orthogonal to anything."""
        from sixlib.spmd_types._mesh_axis import MeshAxis

        trivial = MeshAxis.of(1, 1)
        x = torch.randn(4)
        # Size-1 axis is orthogonal to any other axis.
        assert_type(x, {trivial: R, self.tp: V})

    def test_three_way_overlap_detected(self):
        """Three axes where at least one pair overlaps are detected."""
        x = torch.randn(4)
        # dp and dp_cp overlap; tp is orthogonal to dp but that doesn't help.
        with self.assertRaises(SpmdTypeError) as ctx:
            assert_type(x, {self.dp: R, self.tp: V, self.dp_cp: R})
        msg = str(ctx.exception)
        self.assertIn("not orthogonal", msg)

    def test_error_message_names_offending_axes(self):
        """Error message identifies the specific overlapping pair."""
        x = torch.randn(4)
        with self.assertRaises(SpmdTypeError) as ctx:
            assert_type(x, {self.dp: R, self.dp_cp: V})
        msg = str(ctx.exception)
        # The message should mention both axes.
        self.assertIn("not orthogonal", msg)
        self.assertIn("share ranks", msg)

    def test_mutate_type_does_not_add_nonorthogonal_axes(self):
        """mutate_type changes values, so it still validates the full dict."""
        x = torch.randn(4)
        assert_type(x, {self.dp: R, self.tp: V})
        # Mutating an existing key is fine (changes value, not keys).
        mutate_type(x, self.dp, src=R, dst=V)


class TestTraceMode(SpmdTypeCheckedTestCase, expecttest.TestCase):
    """Test SPMD_TYPES_TRACE logging output."""

    def setUp(self):
        super().setUp()
        self._handler = logging.Handler()
        self._handler.emit = lambda record: self._records.append(record)
        self._records: list[logging.LogRecord] = []
        _trace_logger.addHandler(self._handler)
        _trace_logger.setLevel(logging.DEBUG)

    def tearDown(self):
        _trace_logger.removeHandler(self._handler)
        super().tearDown()

    def _trace_output(self) -> str:
        lines = [r.getMessage() for r in self._records]
        # Normalize /abs/path/to/file.py:123 -> file.py:N for stability.
        lines = [re.sub(r"^.*?([^/]+\.py):\d+", r"\1:N", line) for line in lines]
        return "\n".join(lines)

    def test_trace_logs_local_op(self):
        """Trace logs operator name, input types, and output type."""
        with trace():
            x = self._generate_inputs((4,), self.pg, R)
            y = self._generate_inputs((4,), self.pg, V)
            _ = x + y

        self.assertExpectedInline(
            self._trace_output(),
            """\
checker_test.py:N  assert_type({}) -> {default_pg: R}
checker_test.py:N  assert_type({}) -> {default_pg: V}
checker_test.py:N  add({default_pg: R}, {default_pg: V}) -> {default_pg: V}""",
        )

    def test_trace_logs_multiple_ops(self):
        """Each non-trivial op gets its own trace line."""
        with trace():
            x = self._generate_inputs((4,), self.pg, R)
            y = self._generate_inputs((4,), self.pg, V)
            z = x + y
            _ = z * z

        self.assertExpectedInline(
            self._trace_output(),
            """\
checker_test.py:N  assert_type({}) -> {default_pg: R}
checker_test.py:N  assert_type({}) -> {default_pg: V}
checker_test.py:N  add({default_pg: R}, {default_pg: V}) -> {default_pg: V}
checker_test.py:N  mul({default_pg: V}, {default_pg: V}) -> {default_pg: V}""",
        )

    def test_trace_silent_when_disabled(self):
        """No trace output when trace is explicitly disabled."""
        with trace(enabled=False):
            x = self._generate_inputs((4,), self.pg, R)
            y = self._generate_inputs((4,), self.pg, V)
            _ = x + y

        self.assertExpectedInline(self._trace_output(), """""")

    def test_trace_logs_collective(self):
        """Trace logs SPMD collectives (all_reduce)."""
        with trace():
            x = self._generate_inputs((4,), self.pg, P)
            _ = all_reduce(x, self.pg, dst=R)

        self.assertExpectedInline(
            self._trace_output(),
            """\
checker_test.py:N  assert_type({}) -> {default_pg: P}
checker_test.py:N  all_reduce({default_pg: P}) -> {default_pg: R}""",
        )

    def test_trace_logs_assert_type_initial(self):
        """Trace logs assert_type when setting initial type on a tensor."""
        with trace():
            x = torch.zeros(4)
            assert_type(x, {self.pg: R})

        self.assertExpectedInline(
            self._trace_output(),
            """checker_test.py:N  assert_type({}) -> {default_pg: R}""",
        )

    def test_trace_logs_assert_type_refinement(self):
        """Trace logs assert_type when refining/merging existing type."""
        x = self._generate_inputs((4,), self.pg, R)
        with trace():
            assert_type(x, {self.pg: R})

        self.assertExpectedInline(
            self._trace_output(),
            """checker_test.py:N  assert_type({default_pg: R}) -> {default_pg: R}""",
        )


class TestErrorContext(SpmdTypeCheckedTestCase, expecttest.TestCase):
    """Test enhanced error context on SpmdTypeError."""

    def test_context_field_none_by_default(self):
        """SpmdTypeError.context is None when not set."""
        err = SpmdTypeError("test message")
        self.assertIsNone(err.context)
        self.assertEqual(str(err), "test message")

    def test_context_field_appended_to_str(self):
        """SpmdTypeError.context appears in str(error) when set."""
        err = SpmdTypeError("base msg", context="  In foo()")
        self.assertExpectedInline(
            str(err),
            """\
base msg

  In foo()""",
        )

    def test_context_set_after_init(self):
        """Setting context after construction also works."""
        err = SpmdTypeError("base msg")
        err.context = "  In bar()"
        self.assertExpectedInline(
            str(err),
            """\
base msg

  In bar()""",
        )

    def test_add_p_r_error_has_context(self):
        """P + R error includes operator context with shapes, dtypes, types."""
        x = self._generate_inputs((8, 16), self.pg, P)
        y = self._generate_inputs((16,), self.pg, R)
        with self.assertRaises(SpmdTypeError) as ctx:
            torch.add(x, y)
        self.assertExpectedInline(
            str(ctx.exception),
            """\
Partial type on axis default_pg in a linear op requires all operands to be Partial (sum of partial sums is a partial sum, but adding a Replicate or scalar value makes the result affine -- the non-partial term gets summed N times across ranks). Found types: [P, R]
Are you missing a collective or a reinterpret/convert call? e.g.,
  all_reduce(tensor, default_pg, src=P, dst=R) on the Partial operand (all-reduce in forward, all-reduce in backward)
  convert(tensor, default_pg, src=R, dst=P) on the Replicate operand (zeros non-rank-0 in forward, zeros non-rank-0 in backward)

  In add(
    args[0]: f32[8, 16] {default_pg: P},
    args[1]: f32[16] {default_pg: R},
  )""",
        )

    def test_matmul_p_p_error_has_context(self):
        """P * P matmul error includes operator context."""
        x = self._generate_inputs((2, 4), self.pg, P)
        y = self._generate_inputs((4, 3), self.pg, P)
        with self.assertRaises(SpmdTypeError) as ctx:
            torch.matmul(x, y)
        self.assertExpectedInline(
            str(ctx.exception),
            """\
Partial in multiple factors of multilinear op on axis default_pg is forbidden. Reduce all but one factor first. Found types: [P, P]
Are you missing a collective or a reinterpret/convert call? e.g.,
  all_reduce(tensor, default_pg, src=P, dst=R) on the Partial operand (all-reduce in forward, all-reduce in backward)

  In matmul(
    args[0]: f32[2, 4] {default_pg: P},
    args[1]: f32[4, 3] {default_pg: P},
  )""",
        )

    def test_addmm_decomp_error_has_context(self):
        """addmm type decomposition errors also get context."""
        self_t = self._generate_inputs((2, 3), self.pg, P)
        mat1 = self._generate_inputs((2, 4), self.pg, R)
        mat2 = self._generate_inputs((4, 3), self.pg, R)
        with self.assertRaises(SpmdTypeError) as ctx:
            torch.addmm(self_t, mat1, mat2)
        self.assertExpectedInline(
            str(ctx.exception),
            """\
Partial type on axis default_pg in a linear op requires all operands to be Partial (sum of partial sums is a partial sum, but adding a Replicate or scalar value makes the result affine -- the non-partial term gets summed N times across ranks). Found types: [R, P]
Are you missing a collective or a reinterpret/convert call? e.g.,
  all_reduce(tensor, default_pg, src=P, dst=R) on the Partial operand (all-reduce in forward, all-reduce in backward)
  convert(tensor, default_pg, src=R, dst=P) on the Replicate operand (zeros non-rank-0 in forward, zeros non-rank-0 in backward)

  In addmm(
    args[0]: f32[2, 3] {default_pg: P},
    args[1]: f32[2, 4] {default_pg: R},
    args[2]: f32[4, 3] {default_pg: R},
  )""",
        )


class TestErrorContextMultiAxis(expecttest.TestCase):
    """Test error context with multiple mesh axes."""

    WORLD_SIZE = 4

    @classmethod
    def setUpClass(cls):
        from sixlib.spmd_types._testing import fake_pg

        super().setUpClass()
        cls._pg_ctx = fake_pg(cls.WORLD_SIZE)
        cls._pg_ctx.__enter__()
        mesh = init_device_mesh("cpu", (2, 2), mesh_dim_names=("dp", "tp"))
        cls.dp = mesh.get_group("dp")
        cls.tp = mesh.get_group("tp")
        cls._tc_ctx = typecheck()
        cls._tc_ctx.__enter__()

    @classmethod
    def tearDownClass(cls):
        cls._tc_ctx.__exit__(None, None, None)
        cls._pg_ctx.__exit__(None, None, None)
        super().tearDownClass()

    def test_multi_axis_context(self):
        """Error context with two axes shows both axis types."""
        x = torch.randn(8, 16)
        assert_type(x, {self.dp: P, self.tp: R})
        y = torch.randn(16)
        assert_type(y, {self.dp: R, self.tp: R})
        with self.assertRaises(SpmdTypeError) as ctx:
            torch.add(x, y)
        self.assertExpectedInline(
            str(ctx.exception),
            """\
Partial type on axis mesh_dp in a linear op requires all operands to be Partial (sum of partial sums is a partial sum, but adding a Replicate or scalar value makes the result affine -- the non-partial term gets summed N times across ranks). Found types: [P, R]
Are you missing a collective or a reinterpret/convert call? e.g.,
  all_reduce(tensor, mesh_dp, src=P, dst=R) on the Partial operand (all-reduce in forward, all-reduce in backward)
  convert(tensor, mesh_dp, src=R, dst=P) on the Replicate operand (zeros non-rank-0 in forward, zeros non-rank-0 in backward)

  In add(
    args[0]: f32[8, 16] {mesh_dp: P, mesh_tp: R},
    args[1]: f32[16] {mesh_dp: R, mesh_tp: R},
  )""",
        )


class TestErrorContextRawDist(LocalTensorTestCase, expecttest.TestCase):
    """Test error context for raw torch.distributed collectives.

    Raw dist functions have inspectable signatures, so positional args should
    be labeled with parameter names.  Also tests list-of-tensors formatting.
    """

    def test_all_gather_into_tensor_wrong_input_context(self):
        """all_gather_into_tensor error shows named params and group."""
        x = self._generate_inputs((2,), self.pg, R)
        out = self._generate_inputs((6,), self.pg, R)
        with typecheck("strict"):
            with self.assertRaises(SpmdTypeError) as ctx:
                dist.all_gather_into_tensor(out, x, group=self.pg)
        self.assertExpectedInline(
            str(ctx.exception),
            """\
all_gather_into_tensor: expected input type PerMeshAxisLocalSpmdType.V on axis default_pg, got PerMeshAxisLocalSpmdType.R

  In all_gather_into_tensor(
    output_tensor: f32[6] {default_pg: R},
    input_tensor: f32[2] {default_pg: R},
    group: default_pg,
    async_op: False,
  )""",
        )

    def test_all_gather_list_wrong_input_context(self):
        """all_gather (list variant) error shows list of tensors."""
        x = self._generate_inputs((4,), self.pg, R)
        out_list = [
            self._generate_inputs((4,), self.pg, R) for _ in range(self.WORLD_SIZE)
        ]
        with typecheck("strict"):
            with self.assertRaises(SpmdTypeError) as ctx:
                dist.all_gather(out_list, x, group=self.pg)
        self.assertExpectedInline(
            str(ctx.exception),
            """\
all_gather: expected input type PerMeshAxisLocalSpmdType.V on axis default_pg, got PerMeshAxisLocalSpmdType.R

  In all_gather(
    tensor_list: [f32[4] {default_pg: R}] * 3,
    tensor: f32[4] {default_pg: R},
    group: default_pg,
    async_op: False,
  )""",
        )

    def test_all_reduce_wrong_input_context(self):
        """all_reduce error shows named params."""
        x = self._generate_inputs((4,), self.pg, R)
        with typecheck("strict"):
            with self.assertRaises(SpmdTypeError) as ctx:
                dist.all_reduce(x, group=self.pg)
        self.assertExpectedInline(
            str(ctx.exception),
            """\
all_reduce: expected input type PerMeshAxisLocalSpmdType.P on axis default_pg, got PerMeshAxisLocalSpmdType.R

  In all_reduce(
    tensor: f32[4] {default_pg: R},
    op: <RedOpType.SUM: 0>,
    group: default_pg,
    async_op: False,
  )""",
        )


class TestSingletonAxisDropped(expecttest.TestCase):
    """Singleton mesh axes (size 1) should be silently dropped from SPMD types."""

    WORLD_SIZE = 6

    @classmethod
    def setUpClass(cls):
        from sixlib.spmd_types._testing import fake_pg

        super().setUpClass()
        cls._pg_ctx = fake_pg(cls.WORLD_SIZE)
        cls._pg_ctx.__enter__()
        # (1, 6) mesh: singleton_axis has size 1, real_axis has size 6
        mesh = init_device_mesh("cpu", (1, 6), mesh_dim_names=("singleton", "real"))
        cls.singleton = mesh.get_group("singleton")
        cls.real = mesh.get_group("real")

    @classmethod
    def tearDownClass(cls):
        cls._pg_ctx.__exit__(None, None, None)
        super().tearDownClass()

    def test_singleton_dropped_from_assert_type(self):
        """assert_type with only a singleton axis produces an empty type dict."""
        x = torch.randn(4)
        assert_type(x, {self.singleton: R})
        from sixlib.spmd_types._checker import get_local_type

        self.assertEqual(get_local_type(x), {})

    def test_singleton_plus_real_keeps_real(self):
        """assert_type with singleton + real axis keeps only the real axis."""
        x = torch.randn(4)
        assert_type(x, {self.singleton: V, self.real: R})
        from sixlib.spmd_types._checker import get_local_type

        local_type = get_local_type(x)
        self.assertNotIn(
            normalize_axis(self.singleton),
            local_type,
        )
        self.assertIs(local_type[normalize_axis(self.real)], R)

    def test_mutate_type_singleton_is_noop(self):
        """mutate_type on a singleton axis returns the tensor unchanged."""
        x = torch.randn(4)
        assert_type(x, {self.real: R})
        result = mutate_type(x, self.singleton, src=R, dst=V)
        self.assertIs(result, x)
        self.assertIs(get_axis_local_type(x, self.real), R)


class TestSingletonAxisStrictMode(expecttest.TestCase):
    """Strict mode should not error for singleton axes."""

    WORLD_SIZE = 6

    @classmethod
    def setUpClass(cls):
        from sixlib.spmd_types._testing import fake_pg

        super().setUpClass()
        cls._pg_ctx = fake_pg(cls.WORLD_SIZE)
        cls._pg_ctx.__enter__()
        mesh = init_device_mesh("cpu", (1, 6), mesh_dim_names=("singleton", "real"))
        cls.singleton = mesh.get_group("singleton")
        cls.real = mesh.get_group("real")
        cls._tc_ctx = typecheck()
        cls._tc_ctx.__enter__()

    @classmethod
    def tearDownClass(cls):
        cls._tc_ctx.__exit__(None, None, None)
        cls._pg_ctx.__exit__(None, None, None)
        super().tearDownClass()

    def test_ops_with_singleton_axis(self):
        """Ops between tensors typed on a singleton axis should work fine."""
        x = torch.randn(4)
        assert_type(x, {self.singleton: R, self.real: R})
        y = torch.randn(4)
        assert_type(y, {self.singleton: V, self.real: R})
        # Both tensors are R on real axis; singleton is absent from both.
        # This should succeed (R + R -> R on real axis).
        result = torch.add(x, y)
        self.assertIs(get_axis_local_type(result, self.real), R)

    def test_strict_mode_no_error_for_singleton(self):
        """Strict mode should not raise for missing singleton axis on collectives."""
        x = torch.randn(4)
        assert_type(x, {self.real: P})
        # Calling all_reduce on singleton axis -- should not raise even in
        # strict mode, since singleton axes are simply not tracked.
        result = all_reduce(x, self.singleton, src=P, dst=R)
        # Type on real axis should be preserved
        self.assertIs(get_axis_local_type(result, self.real), P)


class TestMissingAxesValidation(SpmdTypeCheckedTestCase):
    """Test that missing mesh axes are rejected at shard propagation time."""

    WORLD_SIZE = 6

    @classmethod
    def setUpClass(cls):
        super().setUpClass()
        mesh = init_device_mesh("cpu", (2, 3), mesh_dim_names=("dp", "tp"))
        cls.tp = mesh.get_group("tp")
        cls.dp = mesh.get_group("dp")

    def test_missing_axis_in_binary_op(self):
        """Mixing operands with different axis sets raises SpmdTypeError."""
        x = self._generate_inputs((4, 3), self.tp, R)
        y = self.rank_map(lambda r: torch.randn(4, 3))
        assert_type(y, {self.tp: R, self.dp: R})
        with self.assertRaises(SpmdTypeError):
            x + y  # x is missing dp

    def test_missing_axis_in_matmul(self):
        """Missing axis in matmul operand raises SpmdTypeError."""
        x = self.rank_map(lambda r: torch.randn(4, 3))
        assert_type(x, {self.tp: V, self.dp: V})
        w = self._generate_inputs((3, 5), self.tp, V)
        with self.assertRaises(SpmdTypeError):
            torch.mm(x, w)  # w is missing dp

    def test_same_axes_ok(self):
        """Operands with the same axis set should pass."""
        x = self.rank_map(lambda r: torch.randn(4, 3))
        assert_type(x, {self.tp: R, self.dp: R})
        y = self.rank_map(lambda r: torch.randn(4, 3))
        assert_type(y, {self.tp: R, self.dp: R})
        result = x + y
        self.assertIs(get_axis_local_type(result, self.tp), R)
        self.assertIs(get_axis_local_type(result, self.dp), R)


if __name__ == "__main__":
    unittest.main()
