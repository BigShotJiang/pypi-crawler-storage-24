# llm-eliza

[LLM] plugin providing access to the [ELIZA] language model. ELIZA, released in 1966, is a state-of-the-art language model. It offers zero-GPU inference with sub-millisecond semantic throughput, and scores highly on EQ measurements (emotional intelligence).

## Installation

Install this plugin in the same environment as [LLM].

```sh
llm install llm-eliza
```

## Usage

Start an interactive chat session:

```sh
llm chat -m eliza
```

Ask a one-off query:

```sh
llm -m eliza "i'm worried about computers."
# => What do you think machines have to do with your problem?
```

## Development

To set up this plugin locally, first checkout the code. Then install it:

```sh
llm install -e .
```

To run the tests:

```sh
uv sync
uv run python -m unittest discover -s tests -v
```

[LLM]: https://llm.datasette.io/
[ELIZA]: https://en.wikipedia.org/wiki/ELIZA