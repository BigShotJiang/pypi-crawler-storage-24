import json
from typing import Any, Dict, Generic, List, Optional, Union, cast

from typing_extensions import Literal, TypeVar

import resend
from resend.exceptions import (NoContentError, ResendError,
                               raise_for_code_and_type)
from resend.response import ResponseDict
from resend.version import get_version

RequestVerb = Literal["get", "post", "put", "patch", "delete"]
T = TypeVar("T")

ParamsType = Union[Dict[str, Any], List[Dict[str, Any]]]
HeadersType = Dict[str, str]


class Request(Generic[T]):
    def __init__(
        self,
        path: str,
        params: ParamsType,
        verb: RequestVerb,
        options: Optional[Dict[str, Any]] = None,
    ):
        self.path = path
        self.params = params
        self.verb = verb
        self.options = options
        self._response_headers: Dict[str, str] = {}

    def perform(self) -> Union[T, None]:
        data = self.make_request(url=f"{resend.api_url}{self.path}")

        if isinstance(data, dict) and data.get("statusCode") not in (None, 200):
            raise_for_code_and_type(
                code=data.get("statusCode") or 500,
                message=data.get("message", "Unknown error"),
                error_type=data.get("name", "InternalServerError"),
                headers=self._response_headers,
            )

        if isinstance(data, dict):
            data = ResponseDict(data)
        return cast(T, data)

    def perform_with_content(self) -> T:
        resp = self.perform()
        if resp is None:
            raise NoContentError()
        return resp

    def __get_headers(self) -> HeadersType:
        headers: HeadersType = {
            "Accept": "application/json",
            "Authorization": f"Bearer {resend.api_key}",
            "User-Agent": f"resend-python:{get_version()}",
        }

        if self.verb == "post" and self.options and "idempotency_key" in self.options:
            headers["Idempotency-Key"] = str(self.options["idempotency_key"])

        if self.verb == "post" and self.options and "batch_validation" in self.options:
            headers["x-batch-validation"] = str(self.options["batch_validation"])

        return headers

    def make_request(self, url: str) -> Union[Dict[str, Any], List[Any]]:
        headers = self.__get_headers()

        if isinstance(self.params, dict):
            json_params: Optional[Union[Dict[str, Any], List[Any]]] = {
                str(k): v for k, v in self.params.items()
            }
        elif isinstance(self.params, list):
            json_params = [dict(item) for item in self.params]
        else:
            json_params = None

        try:
            # Cast to HTTPClient for type checking - sync context expects sync client
            from resend.http_client import HTTPClient

            sync_client = cast(HTTPClient, resend.default_http_client)

            content, _status_code, resp_headers = sync_client.request(
                method=self.verb,
                url=url,
                headers=headers,
                json=json_params,
            )

        # Safety net around the HTTP Client
        except Exception as e:
            raise ResendError(
                code=500,
                message=str(e),
                error_type="HttpClientError",
                suggested_action="Request failed, please try again.",
            )

        # Store response headers for later access
        self._response_headers = dict(resp_headers)

        content_type = {k.lower(): v for k, v in resp_headers.items()}.get(
            "content-type", ""
        )

        if "application/json" not in content_type:
            raise_for_code_and_type(
                code=500,
                message=f"Expected JSON response but got: {content_type}",
                error_type="InternalServerError",
                headers=self._response_headers,
            )

        try:
            parsed_data = cast(Union[Dict[str, Any], List[Any]], json.loads(content))
            # Inject headers into dict responses
            if isinstance(parsed_data, dict):
                parsed_data["http_headers"] = dict(self._response_headers)
            # For list responses, return as-is (lists can't have headers key)
            return parsed_data
        except json.JSONDecodeError:
            raise_for_code_and_type(
                code=500,
                message="Failed to decode JSON response",
                error_type="InternalServerError",
                headers=self._response_headers,
            )
