"""AI backend implementations."""
