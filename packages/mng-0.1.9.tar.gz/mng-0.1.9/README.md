# mng

This package has been renamed to [imbue-mngr](https://pypi.org/project/imbue-mngr/).

Install the new package:

```
pip install imbue-mngr
```
