var yc=Object.defineProperty;var xc=(e,t,n)=>t in e?yc(e,t,{enumerable:!0,configurable:!0,writable:!0,value:n}):e[t]=n;var F=(e,t,n)=>xc(e,typeof t!="symbol"?t+"":t,n);import{f as _c,u as wc,i as at,a as it,b as S,j as kc,E as ua,A as X}from"./lit-Db6aaw4G.js";import{m as fa,M as Sc,a as Ec,p as Tc}from"./markdown-BHETOL9o.js";import{H as K,g as Cc}from"./hljs-BaPqTJrN.js";(function(){const t=document.createElement("link").relList;if(t&&t.supports&&t.supports("modulepreload"))return;for(const s of document.querySelectorAll('link[rel="modulepreload"]'))i(s);new MutationObserver(s=>{for(const o of s)if(o.type==="childList")for(const r of o.addedNodes)r.tagName==="LINK"&&r.rel==="modulepreload"&&i(r)}).observe(document,{childList:!0,subtree:!0});function n(s){const o={};return s.integrity&&(o.integrity=s.integrity),s.referrerPolicy&&(o.referrerPolicy=s.referrerPolicy),s.crossOrigin==="use-credentials"?o.credentials="include":s.crossOrigin==="anonymous"?o.credentials="omit":o.credentials="same-origin",o}function i(s){if(s.ep)return;s.ep=!0;const o=n(s);fetch(s.href,o)}})();const Ci={"--radius-xs":"var(--rh-border-radius-default, 3px)","--radius-sm":"8px","--radius-md":"12px","--radius-lg":"16px","--radius-xl":"24px","--radius-full":"var(--rh-border-radius-pill, 64px)","--sidebar-width":"280px","--topbar-height":"48px","--chat-max-width":"768px","--detail-pane-width":"340px","--detail-pane-min-width":"200px","--chat-area-min-width":"320px","--transition-fast":"150ms ease","--transition-normal":"250ms ease","--font-size-xs":"var(--rh-font-size-body-text-xs, 0.75rem)","--font-size-sm":"var(--rh-font-size-body-text-sm, 0.875rem)","--font-size-base":"var(--rh-font-size-body-text-md, 1rem)","--font-size-lg":"var(--rh-font-size-body-text-lg, 1.125rem)","--font-size-xl":"var(--rh-font-size-body-text-2xl, 1.5rem)","--font-weight-normal":"var(--rh-font-weight-body-text-regular, 400)","--font-weight-medium":"var(--rh-font-weight-body-text-medium, 500)","--font-weight-bold":"var(--rh-font-weight-heading-bold, 700)","--line-height":"var(--rh-line-height-body-text, 1.5)"},hs={...Ci,"--bg-primary":"#F8F6FB","--bg-secondary":"#F0ECF5","--bg-tertiary":"#E4DEF0","--bg-user-bubble":"#DCE8DC","--bg-assistant":"transparent","--bg-sidebar":"#F2F5F2","--bg-input":"#FFFFFF","--bg-code":"#F3EEF8","--bg-hover":"rgba(90, 70, 140, 0.06)","--bg-tool":"#F0ECF5","--bg-tool-header":"#E4DEF0","--text-primary":"#2D2B3D","--text-secondary":"#6B6880","--text-tertiary":"#9895AA","--text-inverse":"#FFFFFF","--text-code":"#7C5CBF","--border-primary":"rgba(80, 60, 120, 0.15)","--border-secondary":"rgba(80, 60, 120, 0.08)","--accent-primary":"#5B9EA6","--accent-hover":"#4A8A93","--accent-success":"#6B9F6B","--accent-danger":"#C27070","--accent-warning":"#C4966E","--accent-info":"#7B9EC9","--hat-color":"#E06060","--font-sans":"'Inter', -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif","--font-mono":"'SF Mono', 'Fira Code', 'Fira Mono', 'Roboto Mono', monospace","--shadow-sm":"0 1px 2px rgba(60, 40, 100, 0.06)","--shadow-md":"0 2px 8px rgba(60, 40, 100, 0.10)","--shadow-lg":"0 4px 16px rgba(60, 40, 100, 0.14)"},Oc={...Ci,"--bg-primary":"#1E1B2E","--bg-secondary":"#262340","--bg-tertiary":"#352F54","--bg-user-bubble":"#3A3458","--bg-assistant":"transparent","--bg-sidebar":"#151324","--bg-input":"#262340","--bg-code":"#262340","--bg-hover":"rgba(180, 160, 255, 0.08)","--bg-tool":"#1C1930","--bg-tool-header":"#2E2A48","--text-primary":"#E8E4F0","--text-secondary":"#ACA8C0","--text-tertiary":"#7E7A96","--text-inverse":"#1E1B2E","--text-code":"#E8A8C0","--border-primary":"rgba(200, 180, 255, 0.15)","--border-secondary":"rgba(200, 180, 255, 0.08)","--accent-primary":"#A78BFA","--accent-hover":"#B89FF8","--accent-success":"#86D9A8","--accent-danger":"#F08080","--accent-warning":"#E8C06A","--accent-info":"#88B8E8","--hat-color":"#F07888","--font-sans":"'Inter', -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif","--font-mono":"'SF Mono', 'Fira Code', 'Fira Mono', 'Roboto Mono', monospace","--shadow-sm":"0 1px 2px rgba(10, 8, 30, 0.3)","--shadow-md":"0 2px 8px rgba(10, 8, 30, 0.4)","--shadow-lg":"0 4px 16px rgba(10, 8, 30, 0.5)"},Mc={...Ci,"--bg-primary":"#e6e6e6","--bg-secondary":"#f5f5f5","--bg-tertiary":"var(--rh-color-surface-light, #e0e0e0)","--bg-user-bubble":"var(--rh-color-gray-20, #e0e0e0)","--bg-assistant":"transparent","--bg-sidebar":"var(--rh-color-gray-10, #f5f5f5)","--bg-input":"var(--rh-color-surface-lightest, #ffffff)","--bg-code":"var(--rh-color-surface-lighter, #f2f2f2)","--bg-hover":"var(--rh-color-surface-lighter, rgba(21, 21, 21, 0.04))","--bg-tool":"var(--rh-color-gray-10, #f2f2f2)","--bg-tool-header":"var(--rh-color-gray-20, #e0e0e0)","--text-primary":"var(--rh-color-text-primary-on-light, #151515)","--text-secondary":"var(--rh-color-text-secondary-on-light, #4d4d4d)","--text-tertiary":"var(--rh-color-gray-50, #707070)","--text-inverse":"var(--rh-color-text-primary-on-dark, #ffffff)","--text-code":"var(--rh-color-blue-70, #003366)","--border-primary":"var(--rh-color-border-subtle-on-light, #c7c7c7)","--border-secondary":"var(--rh-color-border-subtle-on-light, rgba(21, 21, 21, 0.10))","--accent-primary":"var(--rh-color-interactive-blue-darker, #0066cc)","--accent-hover":"var(--rh-color-interactive-blue-darkest, #003366)","--accent-success":"var(--rh-color-status-success-on-light, #3d7317)","--accent-danger":"var(--rh-color-status-danger-on-light, #b1380b)","--accent-warning":"var(--rh-color-status-warning-on-light, #dca614)","--accent-info":"var(--rh-color-interactive-blue-darker, #0066cc)","--hat-color":"var(--rh-color-brand-red-on-light, #ee0000)","--font-sans":"var(--rh-font-family-body-text, 'Red Hat Text', 'Red Hat Display', sans-serif)","--font-mono":"var(--rh-font-family-code, 'Red Hat Mono', 'Courier New', monospace)","--shadow-sm":"var(--rh-box-shadow-sm, 0 1px 2px rgba(21, 21, 21, 0.1))","--shadow-md":"var(--rh-box-shadow-md, 0 2px 4px rgba(21, 21, 21, 0.12))","--shadow-lg":"var(--rh-box-shadow-lg, 0 4px 8px rgba(21, 21, 21, 0.15))"},Pc={...Ci,"--bg-primary":"#252525","--bg-secondary":"#2a2a2a","--bg-tertiary":"var(--rh-color-gray-60, #4d4d4d)","--bg-user-bubble":"var(--rh-color-gray-70, #3d3d3d)","--bg-assistant":"transparent","--bg-sidebar":"var(--rh-color-surface-darkest, #151515)","--bg-input":"#2a2a2a","--bg-code":"var(--rh-color-gray-70, #333333)","--bg-hover":"var(--rh-color-surface-darker, rgba(255, 255, 255, 0.06))","--bg-tool":"var(--rh-color-surface-darker, #1f1f1f)","--bg-tool-header":"var(--rh-color-surface-dark, #383838)","--text-primary":"var(--rh-color-text-primary-on-dark, #ffffff)","--text-secondary":"var(--rh-color-text-secondary-on-dark, #c7c7c7)","--text-tertiary":"#a0a0a0","--text-inverse":"var(--rh-color-text-primary-on-light, #151515)","--text-code":"var(--rh-color-red-orange-30, #f89b78)","--border-primary":"var(--rh-color-border-subtle-on-dark, #707070)","--border-secondary":"var(--rh-color-border-subtle-on-dark, rgba(242, 242, 242, 0.08))","--accent-primary":"var(--rh-color-interactive-blue-lighter, #92c5f9)","--accent-hover":"var(--rh-color-interactive-blue-lightest, #b9dafc)","--accent-success":"var(--rh-color-status-success-on-dark, #87bb62)","--accent-danger":"var(--rh-color-status-danger-on-dark, #f0561d)","--accent-warning":"var(--rh-color-status-warning-on-dark, #ffcc17)","--accent-info":"var(--rh-color-interactive-blue-lighter, #92c5f9)","--hat-color":"var(--rh-color-brand-red-on-dark, #ee0000)","--font-sans":"var(--rh-font-family-body-text, 'Red Hat Text', 'Red Hat Display', sans-serif)","--font-mono":"var(--rh-font-family-code, 'Red Hat Mono', 'Courier New', monospace)","--shadow-sm":"var(--rh-box-shadow-sm, 0 1px 2px rgba(21, 21, 21, 0.15))","--shadow-md":"var(--rh-box-shadow-md, 0 2px 4px rgba(21, 21, 21, 0.18))","--shadow-lg":"var(--rh-box-shadow-lg, 0 4px 8px rgba(21, 21, 21, 0.22))"},us=[{id:"light",label:"Light",theme:hs,dark:!1},{id:"dark",label:"Dark",theme:Oc,dark:!0},{id:"rh-light",label:"Red Hat Light",theme:Mc,dark:!1},{id:"rh-dark",label:"Red Hat Dark",theme:Pc,dark:!0}],Kn=new Map(us.map(e=>[e.id,e])),Co="agent-theme";class Ac{constructor(){this.themeName=this.loadPreference();const t=Kn.get(this.themeName);this.current=t?t.theme:hs,this.apply()}get name(){return this.themeName}get isDark(){const t=Kn.get(this.themeName);return t?t.dark:!1}get themes(){return us}toggle(){const t=us.map(s=>s.id),n=t.indexOf(this.themeName),i=t[(n+1)%t.length];this.setTheme(i)}setTheme(t,n){this.themeName=t;const i=Kn.get(t),s=i?i.theme:hs;this.current=n?Object.assign({},s,n):s,this.apply(),this.savePreference()}apply(){const t=document.documentElement;for(const[n,i]of Object.entries(this.current))t.style.setProperty(n,i)}loadPreference(){try{const t=localStorage.getItem(Co);if(t&&Kn.has(t))return t}catch{}return window.matchMedia?.("(prefers-color-scheme: dark)").matches?"dark":"light"}savePreference(){try{localStorage.setItem(Co,this.themeName)}catch{}}}const Ne=new Ac;/**
 * @license
 * Copyright 2017 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */const st=e=>(t,n)=>{n!==void 0?n.addInitializer(()=>{customElements.define(e,t)}):customElements.define(e,t)};/**
 * @license
 * Copyright 2017 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */const Dc={attribute:!0,type:String,converter:wc,reflect:!1,hasChanged:_c},Ic=(e=Dc,t,n)=>{const{kind:i,metadata:s}=n;let o=globalThis.litPropertyMetadata.get(s);if(o===void 0&&globalThis.litPropertyMetadata.set(s,o=new Map),i==="setter"&&((e=Object.create(e)).wrapped=!0),o.set(n.name,e),i==="accessor"){const{name:r}=n;return{set(a){const l=t.get.call(this);t.set.call(this,a),this.requestUpdate(r,l,e,!0,a)},init(a){return a!==void 0&&this.C(r,void 0,e,a),a}}}if(i==="setter"){const{name:r}=n;return function(a){const l=this[r];t.call(this,a),this.requestUpdate(r,l,e,!0,a)}}throw Error("Unsupported decorator location: "+i)};function Wt(e){return(t,n)=>typeof n=="object"?Ic(e,t,n):((i,s,o)=>{const r=s.hasOwnProperty(o);return s.constructor.createProperty(o,i),r?Object.getOwnPropertyDescriptor(s,o):void 0})(e,t,n)}/**
 * @license
 * Copyright 2017 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */function L(e){return Wt({...e,state:!0,attribute:!1})}/**
 * @license
 * Copyright 2017 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */const Rc=(e,t,n)=>(n.configurable=!0,n.enumerable=!0,Reflect.decorate&&typeof t!="object"&&Object.defineProperty(e,t,n),n);/**
 * @license
 * Copyright 2017 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */function zs(e,t){return(n,i,s)=>{const o=r=>r.renderRoot?.querySelector(e)??null;return Rc(n,i,{get(){return o(this)}})}}const pa=[{name:"set_context",description:"Set or update a context key-value pair for the conversation"},{name:"select_skill",description:"Load a reference guide (skill) for the current conversation"}];class Nc{constructor(){this.data={sessionId:null,activeChatId:null,chatList:[],messages:[],isStreaming:!1,usage:null,model:"",mcpServers:[],toolCount:0,contextWindow:0,maxActiveSkills:3,availableSkills:[],activeSkills:[],context:{},availableModels:[],availablePlaybooks:[],availableTools:[],toolPolicies:{},pinCards:[],sidebarOpen:!0,detailPaneOpen:!0,detailPaneWidth:340,error:null,warning:null,streamStartTime:null,streamElapsed:null},this.listeners=new Set}get state(){return this.data}subscribe(t){return this.listeners.add(t),()=>this.listeners.delete(t)}notify(){for(const t of this.listeners)t()}update(t){Object.assign(this.data,t),this.notify()}addMessage(t){this.data.messages=[...this.data.messages,t],this.notify()}updateLastAssistant(t){const n=[...this.data.messages];for(let i=n.length-1;i>=0;i--)if(n[i].role==="assistant"){n[i]=t(n[i]);break}this.data.messages=n,this.notify()}addToolCallToLast(t){this.updateLastAssistant(n=>({...n,toolCalls:[...n.toolCalls??[],t]}))}updateLastToolCall(t){this.updateLastAssistant(n=>{const i=[...n.toolCalls??[]];return i.length>0&&(i[i.length-1]=t(i[i.length-1])),{...n,toolCalls:i}})}clearMessages(){this.data.messages=[],this.data.sessionId=null,this.data.activeChatId=null,this.data.isStreaming=!1,this.data.usage=null,this.data.error=null,this.data.streamStartTime=null,this.data.streamElapsed=null,this.notify()}setChatList(t){this.data.chatList=t,this.notify()}setActiveChat(t,n,i){this.data.activeChatId=t,this.data.sessionId=n,this.data.messages=i,this.data.isStreaming=!1,this.data.usage=null,this.data.error=null,this.data.streamStartTime=null,this.data.streamElapsed=null,this.notify()}removeChat(t){this.data.chatList=this.data.chatList.filter(n=>n.id!==t),this.data.activeChatId===t&&this.clearMessages(),this.notify()}setContext(t,n){this.data.context={...this.data.context,[t]:n},this.notify()}removeContext(t){const n={...this.data.context};delete n[t],this.data.context=n,this.notify()}clearContext(){this.data.context={},this.notify()}toggleSkill(t){const n=[...this.data.activeSkills],i=n.indexOf(t);i>=0?n.splice(i,1):(n.push(t),n.length>this.data.maxActiveSkills&&n.shift()),this.data.activeSkills=n,this.notify()}setActiveSkills(t){this.data.activeSkills=t,this.notify()}needsApproval(){const t=Object.values(this.data.toolPolicies);return t.length===0?!0:t.some(n=>n!=="auto-accept")}setToolPolicy(t,n){this.data.toolPolicies={...this.data.toolPolicies,[t]:n},this.notify()}setAllToolPolicies(t){const n={};for(const i of this.data.availableTools)n[i.name]=t;this.data.toolPolicies=n,this.notify()}hasCard(t){return this.data.pinCards.some(n=>n.id===t)}addCard(t){this.hasCard(t.id)||(this.data.pinCards=[...this.data.pinCards,t],this.notify())}removeCard(t){this.data.pinCards=this.data.pinCards.filter(n=>n.id!==t),this.notify()}moveCard(t,n){const i=[...this.data.pinCards],s=i.findIndex(r=>r.id===t);if(s<0||s===n)return;const[o]=i.splice(s,1);i.splice(n,0,o),this.data.pinCards=i,this.notify()}updateCardContent(t,n){this.data.pinCards=this.data.pinCards.map(i=>i.id===t?{...i,content:n,timestamp:Date.now()}:i),this.notify()}updateCard(t,n){this.data.pinCards=this.data.pinCards.map(i=>i.id===t?{...i,...n}:i),this.notify()}updateCardHeight(t,n){this.data.pinCards=this.data.pinCards.map(i=>i.id===t?{...i,height:n}:i),this.notify()}genId(){return`${Date.now()}-${Math.random().toString(36).slice(2,8)}`}}const w=new Nc;function Fe(e){return e==="set_context"||e==="select_skill"||e.endsWith("_read")||e.endsWith("_help")?"auto-accept":"ask"}const Lc="/api";async function wt(e,t){const n=await fetch(`${Lc}${e}`,{headers:{"Content-Type":"application/json"},...t});if(!n.ok)throw new Error(`API ${n.status}: ${n.statusText}`);return n.json()}async function zc(){return wt("/status")}async function $c(){return(await wt("/models")).models}async function Fc(e){return wt("/model",{method:"PUT",body:JSON.stringify({model:e})})}async function fs(){return(await wt("/tools")).tools}async function Bc(){return(await wt("/skills")).skills}async function Hc(){return(await wt("/playbooks")).playbooks}async function Uc(){return(await wt("/mcp")).servers}async function ga(e){return wt(`/mcp/${encodeURIComponent(e)}`,{method:"POST"})}async function Wc(e){return wt(`/mcp/${encodeURIComponent(e)}`,{method:"DELETE"})}async function ma(){return(await wt("/chats")).chats}async function jc(e){return wt(`/chats/${encodeURIComponent(e)}`)}async function Vc(e){await wt(`/chats/${encodeURIComponent(e)}`,{method:"DELETE"})}async function Yc(e,t={}){return wt(`/tools/${encodeURIComponent(e)}`,{method:"POST",body:JSON.stringify({arguments:t})})}async function ps(e,t,n){const i={approved:t};n&&(i.reason=n),await wt(`/chat/${e}/approve`,{method:"POST",body:JSON.stringify(i)})}const Gc="/api";async function Kc(e,t,n){const i=n?.approve?"?approve=true":"",s=`${Gc}/chat/stream${i}`;let o;try{o=await fetch(s,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify(e),signal:n?.signal})}catch(d){t.onError?.(d instanceof Error?d:new Error(String(d)));return}if(!o.ok){t.onError?.(new Error(`Stream ${o.status}: ${o.statusText}`));return}const r=o.body?.getReader();if(!r){t.onError?.(new Error("No response body"));return}const a=new TextDecoder;let l="",c="";try{for(;;){const{done:d,value:h}=await r.read();if(d)break;l+=a.decode(h,{stream:!0});const f=l.split(`
`);l=f.pop()??"";for(const g of f)if(g.startsWith("event:"))c=g.slice(6).trim();else if(g.startsWith("data:")){const m=g.slice(5).trim();if(!m)continue;let v;try{v=JSON.parse(m)}catch{continue}qc(c,v,t),c=""}}}catch(d){d.name!=="AbortError"&&t.onError?.(d instanceof Error?d:new Error(String(d)))}}function qc(e,t,n){switch(e){case"session":n.onSession?.(t.session_id);break;case"thinking":n.onThinking?.();break;case"usage":n.onUsage?.(t);break;case"tool_call":n.onToolCall?.(t.name,t.arguments);break;case"tool_result":n.onToolResult?.(t.name,t.result);break;case"tool_denied":n.onToolDenied?.(t.name,t.reason);break;case"skill_selected":n.onSkillSelected?.(t.name);break;case"skill_cleared":n.onSkillCleared?.();break;case"context_set":n.onContextSet?.(t.key,t.value);break;case"context_unset":n.onContextUnset?.(t.key);break;case"content":n.onContent?.(t.content);break;case"done":n.onDone?.(t.content);break}}async function Xc(){try{const t=(await ma()).map(n=>({id:n.id,title:n.title,updatedAt:n.updated_at}));w.setChatList(t)}catch{}}function Zc(e,t,n,i){const s=w.state;return Kc({message:e,session_id:s.sessionId??void 0,skills:s.activeSkills.length?s.activeSkills:void 0,context:Object.keys(s.context).length?s.context:void 0},{onSession:o=>{if(w.update({sessionId:o,activeChatId:o}),!w.state.chatList.some(a=>a.id===o)){const a=e.replace(/^#{1,6}\s+/gm,"").replace(/\*{1,3}(.+?)\*{1,3}/g,"$1").replace(/`(.+?)`/g,"$1").replace(/\[([^\]]+)\]\([^)]+\)/g,"$1").replace(/^[-*>]+\s+/gm,"").replace(/\n/g," ").trim(),l=a.length>80?a.slice(0,80).trimEnd()+"...":a;w.setChatList([{id:o,title:l||"New Chat",updatedAt:Date.now()/1e3},...w.state.chatList])}},onThinking:()=>{w.updateLastAssistant(o=>({...o,thinking:!0}))},onUsage:o=>{w.update({usage:{totalTokens:o.total_tokens,promptTokens:o.prompt_tokens,completionTokens:o.completion_tokens,contextWindow:o.context_window}})},onToolCall:(o,r)=>{w.updateLastAssistant(c=>({...c,thinking:!1}));let a=w.state.toolPolicies[o]??Fe(o);if(o==="select_skill"){const c=r.name??"";w.state.activeSkills.some(h=>h.toLowerCase()===c.toLowerCase())&&(a="auto-accept")}const l=t&&a==="ask";if(w.addToolCallToLast({name:o,arguments:r,pending:l}),t&&a!=="ask"){const c=w.state.sessionId;if(c){const d=a==="auto-accept";ps(c,d,d?void 0:"auto-rejected by policy").catch(()=>{}),d||w.updateLastToolCall(h=>({...h,pending:!1,denied:!0,denyReason:"auto-rejected by policy"}))}}},onToolResult:(o,r)=>{w.updateLastToolCall(a=>({...a,result:r,pending:!1}))},onToolDenied:(o,r)=>{w.updateLastToolCall(a=>({...a,denied:!0,denyReason:r,pending:!1}))},onSkillSelected:o=>{w.state.activeSkills.includes(o)||w.setActiveSkills([...w.state.activeSkills,o])},onSkillCleared:()=>{w.setActiveSkills([])},onContextSet:(o,r)=>{(w.state.toolPolicies.set_context??Fe("set_context"))!=="auto-reject"&&w.setContext(o,r)},onContextUnset:o=>{(w.state.toolPolicies.set_context??Fe("set_context"))!=="auto-reject"&&w.removeContext(o)},onContent:o=>{w.updateLastAssistant(r=>({...r,content:o,thinking:!1}))},onDone:o=>{const r=(performance.now()-n)/1e3;w.updateLastAssistant(a=>({...a,content:o,thinking:!1})),w.update({isStreaming:!1,streamElapsed:r,activeChatId:w.state.sessionId}),Xc()},onError:o=>{w.updateLastAssistant(r=>({...r,content:`Error: ${o.message}`,thinking:!1})),w.update({isStreaming:!1})}},{approve:t,signal:i})}function Jc(e,t,n){const i=[];let s=0;const o=()=>`${t}-${s++}`;for(let r=0;r<e.length;r++){const a=e[r];if(a.role==="user"){i.push({id:o(),role:"user",content:a.content??"",timestamp:n});continue}if(a.role==="assistant"&&a.tool_calls?.length){const l=[];for(const h of a.tool_calls){let f={};try{f=JSON.parse(h.function.arguments)}catch{}const g={name:h.function.name,arguments:f};for(let m=r+1;m<e.length;m++)if(e[m].role==="tool"&&e[m].tool_call_id===h.id){g.result=e[m].content??"";break}l.push(g)}let c=a.content??"",d=r+1;for(;d<e.length&&e[d].role==="tool";)d++;d<e.length&&e[d].role==="assistant"&&!e[d].tool_calls?.length&&(c=e[d].content??""),i.push({id:o(),role:"assistant",content:c,toolCalls:l,timestamp:n});continue}if(a.role==="assistant"){if(i.length>0){const l=i[i.length-1];if(l.role==="assistant"&&l.toolCalls?.length&&l.content===a.content)continue}i.push({id:o(),role:"assistant",content:a.content??"",timestamp:n});continue}}return i}var Qc=Object.defineProperty,td=Object.getOwnPropertyDescriptor,Oi=(e,t,n,i)=>{for(var s=i>1?void 0:i?td(t,n):t,o=e.length-1,r;o>=0;o--)(r=e[o])&&(s=(i?r(t,n,s):r(s))||s);return i&&s&&Qc(t,n,s),s};let He=class extends it{constructor(){super(...arguments),this.sidebarOpen=w.state.sidebarOpen,this.detailPaneOpen=w.state.detailPaneOpen,this.detailPaneWidth=w.state.detailPaneWidth,this.dragStartWidth=0,this.onSendMessage=e=>{this.handleSend(e.detail.message)},this.onLoadChat=async e=>{if(w.state.isStreaming)return;const{chatId:t}=e.detail;try{const n=await jc(t),i=Jc(n.messages??[],n.id,n.updated_at*1e3);w.setActiveChat(t,t,i)}catch(n){w.update({error:`Failed to load chat: ${n.message}`})}},this.onDeleteChat=async e=>{const{chatId:t}=e.detail;try{await Vc(t),w.removeChat(t)}catch(n){w.update({error:`Failed to delete chat: ${n.message}`})}},this.onPinCard=e=>{w.addCard(e.detail.card),w.state.detailPaneOpen||w.update({detailPaneOpen:!0})},this.onPaneResize=e=>{const t=getComputedStyle(this),n=parseInt(t.getPropertyValue("--detail-pane-min-width"))||200,i=parseInt(t.getPropertyValue("--chat-area-min-width"))||320,s=4,o=this.shadowRoot?.querySelector(".main"),a=(o?o.clientWidth:1/0)-i-s;this.dragStartWidth||(this.dragStartWidth=this.detailPaneWidth);const l=Math.max(n,Math.min(a,this.dragStartWidth-e.detail.delta));this.detailPaneWidth=l},this.onPaneResizeEnd=()=>{w.update({detailPaneWidth:this.detailPaneWidth}),this.dragStartWidth=0}}connectedCallback(){super.connectedCallback(),this.unsubscribe=w.subscribe(()=>{this.sidebarOpen=w.state.sidebarOpen,this.detailPaneOpen=w.state.detailPaneOpen,!w.state.isStreaming&&this.abortController&&(this.abortController.abort(),this.abortController=void 0)}),this.addEventListener("send-message",this.onSendMessage),this.addEventListener("load-chat",this.onLoadChat),this.addEventListener("delete-chat",this.onDeleteChat),this.addEventListener("pin-card",this.onPinCard),this.loadInitialData()}disconnectedCallback(){super.disconnectedCallback(),this.unsubscribe?.(),this.removeEventListener("send-message",this.onSendMessage),this.removeEventListener("load-chat",this.onLoadChat),this.removeEventListener("delete-chat",this.onDeleteChat),this.removeEventListener("pin-card",this.onPinCard)}async loadInitialData(){try{let[e,t,n,i,s,o]=await Promise.all([zc(),Bc(),Hc(),Uc(),fs(),ma()]);const r=o.map(m=>({id:m.id,title:m.title,updatedAt:m.updated_at}));let a=[],l=null;if(e.llm_status!=="ok")l="LLM server is unreachable. Start your LLM server and reload the page.";else try{a=await $c()}catch{l="Could not fetch model list from LLM server."}const c=i.filter(m=>!m.connected),d=[];let h=e.tools;for(const m of c)try{const v=await ga(m.name);i=v.servers,h=v.tools}catch{d.push(m.name)}if(d.length>0){const m=d.join(", ");l=[l,`MCP server${d.length>1?"s":""} unreachable: ${m}.`].filter(Boolean).join(" ")}c.length>0&&(s=await fs());const f=[...s,...pa],g={};for(const m of f)g[m.name]=w.state.toolPolicies[m.name]??Fe(m.name);w.update({model:e.model,mcpServers:i,toolCount:h,contextWindow:e.context_window,maxActiveSkills:e.max_active_skills,availableModels:a,availableSkills:t,availablePlaybooks:n,availableTools:f,toolPolicies:g,chatList:r,warning:l})}catch(e){w.update({error:`Cannot connect to agent server: ${e.message}`})}}async handleSend(e){if(w.state.isStreaming)return;w.addMessage({id:w.genId(),role:"user",content:e,timestamp:Date.now()}),w.addMessage({id:w.genId(),role:"assistant",content:"",thinking:!0,timestamp:Date.now()});const t=w.needsApproval(),n=performance.now();w.update({isStreaming:!0,error:null,streamStartTime:Date.now()}),this.abortController=new AbortController,await Zc(e,t,n,this.abortController.signal)}render(){return S`
      <top-bar></top-bar>
      <div class="content">
        <div class="sidebar-container ${this.sidebarOpen?"":"collapsed"}">
          <agent-sidebar></agent-sidebar>
        </div>
        <div class="main">
          <div class="chat-area">
            <agent-chat></agent-chat>
          </div>
          ${this.detailPaneOpen?S`
                <resize-handle
                  @handle-resize=${this.onPaneResize}
                  @resize-end=${this.onPaneResizeEnd}
                ></resize-handle>
                <detail-pane style="width:${this.detailPaneWidth}px"></detail-pane>
              `:""}
        </div>
      </div>
    `}};He.styles=at`
    :host {
      display: flex;
      flex-direction: column;
      width: 100%;
      height: 100%;
      overflow: hidden;
      background: var(--bg-primary);
      color: var(--text-primary);
      font-family: var(--font-sans);
    }

    .content {
      display: flex;
      flex: 1;
      min-height: 0;
      overflow: hidden;
    }

    .sidebar-container {
      width: var(--sidebar-width);
      min-width: var(--sidebar-width);
      height: 100%;
      transition: margin-left var(--transition-normal);
      overflow: hidden;
    }

    .sidebar-container.collapsed {
      margin-left: calc(-1 * var(--sidebar-width));
    }

    .main {
      flex: 1;
      display: flex;
      flex-direction: row;
      height: 100%;
      min-width: 0;
      position: relative;
    }

    .chat-area {
      flex: 1;
      display: flex;
      flex-direction: column;
      height: 100%;
      min-width: var(--chat-area-min-width);
      position: relative;
    }

    detail-pane {
      height: 100%;
      flex-shrink: 0;
    }

    @media (max-width: 768px) {
      .sidebar-container {
        position: absolute;
        z-index: 100;
        top: 0;
        left: 0;
        height: 100%;
        box-shadow: var(--shadow-lg);
      }

      .sidebar-container.collapsed {
        margin-left: calc(-1 * var(--sidebar-width));
      }

      resize-handle,
      detail-pane {
        display: none;
      }
    }
  `;Oi([L()],He.prototype,"sidebarOpen",2);Oi([L()],He.prototype,"detailPaneOpen",2);Oi([L()],He.prototype,"detailPaneWidth",2);He=Oi([st("agent-app")],He);var ed=Object.defineProperty,nd=Object.getOwnPropertyDescriptor,jt=(e,t,n,i)=>{for(var s=i>1?void 0:i?nd(t,n):t,o=e.length-1,r;o>=0;o--)(r=e[o])&&(s=(i?r(t,n,s):r(s))||s);return i&&s&&ed(t,n,s),s};let Ot=class extends it{constructor(){super(...arguments),this.model="",this.toolCount=0,this.contextWindow=0,this.sessionId=null,this.activeChatId=null,this.chatList=[],this.error=null,this.warning=null,this.openSections={status:!1,session:!1,model:!1,mcp:!1,skills:!1,context:!1,policies:!1}}connectedCallback(){super.connectedCallback(),this.unsubscribe=w.subscribe(()=>{const e=w.state;this.model=e.model,this.toolCount=e.toolCount,this.contextWindow=e.contextWindow,this.sessionId=e.sessionId,this.activeChatId=e.activeChatId,this.chatList=e.chatList,this.error=e.error,this.warning=e.warning})}disconnectedCallback(){super.disconnectedCallback(),this.unsubscribe?.()}newChat(){w.clearMessages()}selectChat(e){e!==this.activeChatId&&this.dispatchEvent(new CustomEvent("load-chat",{detail:{chatId:e},bubbles:!0,composed:!0}))}deleteChat(e,t){e.stopPropagation(),this.dispatchEvent(new CustomEvent("delete-chat",{detail:{chatId:t},bubbles:!0,composed:!0}))}toggleSection(e){this.openSections={...this.openSections,[e]:!this.openSections[e]}}renderAccordion(e,t,n){const i=this.openSections[e]??!1;return S`
      <div class="accordion">
        <div class="accordion-header" @click=${()=>this.toggleSection(e)}>
          <span class="section-title">${t}</span>
          <svg
            class="accordion-chevron ${i?"open":""}"
            viewBox="0 0 24 24"
            fill="none"
            stroke="currentColor"
            stroke-width="2"
            stroke-linecap="round"
            stroke-linejoin="round"
          >
            <polyline points="9 18 15 12 9 6"></polyline>
          </svg>
        </div>
        <div class="accordion-body ${i?"open":""}">
          <div>${n}</div>
        </div>
      </div>
    `}relativeTime(e){const t=Math.floor(Date.now()/1e3-e);if(t<60)return"just now";const n=Math.floor(t/60);if(n<60)return`${n}m ago`;const i=Math.floor(n/60);return i<24?`${i}h ago`:`${Math.floor(i/24)}d ago`}render(){return S`
      <div class="body">
        ${this.error?S`<div class="error-banner">${this.error}</div>`:""}
        ${this.warning?S`<div class="warning-banner">${this.warning}</div>`:""}

        <div class="section">
          <span class="section-title">Chats</span>
          <button class="new-chat-btn" ?disabled=${!this.activeChatId} @click=${this.newChat}>
            <svg
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              stroke-width="2"
              stroke-linecap="round"
              stroke-linejoin="round"
            >
              <line x1="12" y1="5" x2="12" y2="19" />
              <line x1="5" y1="12" x2="19" y2="12" />
            </svg>
            New Chat
          </button>
          ${this.chatList.length?S`
                <div class="chat-list">
                  ${this.chatList.map(e=>S`
                      <div
                        class="chat-item ${e.id===this.activeChatId?"active":""}"
                        @click=${()=>this.selectChat(e.id)}
                      >
                        <span class="chat-item-indicator">
                          ${e.id===this.activeChatId?S`<svg
                                viewBox="0 0 24 24"
                                fill="none"
                                stroke="currentColor"
                                stroke-width="2"
                                stroke-linecap="round"
                                stroke-linejoin="round"
                              >
                                <path
                                  d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"
                                ></path>
                              </svg>`:""}
                        </span>
                        <span class="chat-item-title">${e.title}</span>
                        <span class="chat-item-trailing">
                          <span class="chat-item-time">${this.relativeTime(e.updatedAt)}</span>
                          <button
                            class="chat-item-delete"
                            title="Delete chat"
                            @click=${t=>this.deleteChat(t,e.id)}
                          >
                            <svg
                              width="14"
                              height="14"
                              viewBox="0 0 24 24"
                              fill="none"
                              stroke="currentColor"
                              stroke-width="2"
                              stroke-linecap="round"
                              stroke-linejoin="round"
                            >
                              <polyline points="3 6 5 6 21 6"></polyline>
                              <path d="M19 6l-1 14a2 2 0 0 1-2 2H8a2 2 0 0 1-2-2L5 6"></path>
                              <path d="M10 11v6"></path>
                              <path d="M14 11v6"></path>
                            </svg>
                          </button>
                        </span>
                      </div>
                    `)}
                </div>
              `:""}
        </div>

        ${this.renderAccordion("status","Status",S`
            <div class="status-grid">
              <span class="status-label">Model</span>
              <span class="status-value">${this.model||"—"}</span>
              <span class="status-label">Tools</span>
              <span class="status-value">${this.toolCount}</span>
              <span class="status-label">Context</span>
              <span class="status-value">
                ${this.contextWindow?`${(this.contextWindow/1e3).toFixed(1)}k tokens`:"—"}
              </span>
            </div>
          `)}
        ${this.sessionId?this.renderAccordion("session","Session",S`<div class="session-id">${this.sessionId}</div>`):""}
        ${this.renderAccordion("model","Model",S`<model-selector></model-selector>`)}
        ${this.renderAccordion("mcp","MCP Servers",S`<mcp-manager></mcp-manager>`)}
        ${this.renderAccordion("skills","Skills",S`<skill-selector></skill-selector>`)}
        ${this.renderAccordion("context","Context",S`<context-editor></context-editor>`)}
        ${this.renderAccordion("policies","Tool Policies",S`<tool-policy-editor></tool-policy-editor>`)}
      </div>
    `}};Ot.styles=at`
    :host {
      display: flex;
      flex-direction: column;
      height: 100%;
      background: var(--bg-sidebar);
      border-right: none;
      overflow: hidden;
    }

    .new-chat-btn {
      display: flex;
      align-items: center;
      gap: 6px;
      padding: 8px 14px;
      border-radius: var(--radius-sm);
      background: var(--accent-primary);
      color: var(--text-inverse);
      font-size: var(--font-size-sm);
      font-weight: var(--font-weight-medium);
      border: none;
      cursor: pointer;
      transition: background var(--transition-fast);
    }

    .new-chat-btn:hover:not(:disabled) {
      background: var(--accent-hover);
    }

    .new-chat-btn:disabled {
      background: var(--bg-tertiary);
      color: var(--text-secondary);
      cursor: default;
    }

    .new-chat-btn svg {
      width: 14px;
      height: 14px;
    }

    .body {
      flex: 1;
      overflow-y: auto;
      padding: 12px;
      display: flex;
      flex-direction: column;
      gap: 16px;
      scrollbar-width: thin;
      scrollbar-color: var(--border-primary) transparent;
    }

    .body::-webkit-scrollbar {
      width: 4px;
    }

    .body::-webkit-scrollbar-track {
      background: transparent;
    }

    .body::-webkit-scrollbar-thumb {
      background: var(--border-primary);
      border-radius: 2px;
    }

    .section {
      display: flex;
      flex-direction: column;
      gap: 8px;
    }

    .section-title {
      font-size: var(--font-size-xs);
      font-weight: var(--font-weight-bold);
      color: var(--text-tertiary);
      text-transform: uppercase;
      letter-spacing: 0.05em;
    }

    .status-grid {
      display: grid;
      grid-template-columns: auto 1fr;
      gap: 4px 12px;
      font-size: var(--font-size-sm);
    }

    .status-label {
      color: var(--text-tertiary);
    }

    .status-value {
      color: var(--text-primary);
      overflow: hidden;
      text-overflow: ellipsis;
      white-space: nowrap;
    }

    .session-id {
      font-family: var(--font-mono);
      font-size: var(--font-size-xs);
      color: var(--text-tertiary);
      padding: 4px 0;
      word-break: break-all;
    }

    .footer {
      padding: 12px 16px;
      border-top: 1px solid var(--border-secondary);
      display: flex;
      align-items: center;
      justify-content: space-between;
    }

    .error-banner {
      padding: 8px 12px;
      background: var(--accent-danger);
      color: var(--text-inverse);
      font-size: var(--font-size-sm);
      border-radius: var(--radius-xs);
    }

    .warning-banner {
      padding: 8px 12px;
      background: var(--accent-warning, #b45309);
      color: var(--text-inverse, #fff);
      font-size: var(--font-size-sm);
      border-radius: var(--radius-xs);
    }

    .chat-list {
      display: flex;
      flex-direction: column;
      gap: 2px;
    }

    .chat-item {
      display: flex;
      align-items: center;
      gap: 4px;
      padding: 6px 10px;
      border-radius: var(--radius-xs);
      cursor: pointer;
      transition: background var(--transition-fast);
    }

    .chat-item:hover {
      background: var(--bg-hover);
    }

    .chat-item.active {
      background: var(--bg-active, var(--bg-hover));
    }

    .chat-item-indicator {
      flex-shrink: 0;
      width: 14px;
      height: 14px;
      display: flex;
      align-items: center;
      justify-content: center;
      color: var(--accent-primary);
    }

    .chat-item-indicator svg {
      width: 14px;
      height: 14px;
    }

    .chat-item-title {
      flex: 1;
      overflow: hidden;
      text-overflow: ellipsis;
      white-space: nowrap;
      font-size: var(--font-size-sm);
      color: var(--text-primary);
    }

    .chat-item-trailing {
      flex-shrink: 0;
      display: grid;
      place-items: center;
    }

    .chat-item-trailing > * {
      grid-area: 1 / 1;
    }

    .chat-item-time {
      font-size: var(--font-size-xs);
      color: var(--text-tertiary);
      pointer-events: none;
      transition: opacity var(--transition-fast);
    }

    .chat-item-delete {
      z-index: 1;
      background: none;
      border: none;
      cursor: pointer;
      color: var(--text-tertiary);
      padding: 2px;
      border-radius: var(--radius-xs);
      line-height: 1;
      opacity: 0;
      transition:
        opacity var(--transition-fast),
        color var(--transition-fast);
    }

    .chat-item-delete:hover {
      color: var(--accent-danger);
    }

    .chat-item:hover .chat-item-delete {
      opacity: 1;
    }

    .chat-item:hover .chat-item-time {
      opacity: 0;
    }

    .accordion {
      display: flex;
      flex-direction: column;
    }

    .accordion-header {
      display: flex;
      align-items: center;
      justify-content: space-between;
      cursor: pointer;
      user-select: none;
      padding: 2px 0;
    }

    .accordion-header:hover .accordion-chevron {
      color: var(--text-primary);
    }

    .accordion-chevron {
      width: 14px;
      height: 14px;
      color: var(--text-tertiary);
      transition:
        transform var(--transition-fast),
        color var(--transition-fast);
      flex-shrink: 0;
    }

    .accordion-chevron.open {
      transform: rotate(90deg);
    }

    .accordion-body {
      display: grid;
      grid-template-rows: 0fr;
      transition: grid-template-rows 0.2s ease;
    }

    .accordion-body.open {
      grid-template-rows: 1fr;
    }

    .accordion-body > div {
      overflow: hidden;
      padding-top: 0;
      transition: padding-top 0.2s ease;
    }

    .accordion-body.open > div {
      padding-top: 8px;
    }
  `;jt([L()],Ot.prototype,"model",2);jt([L()],Ot.prototype,"toolCount",2);jt([L()],Ot.prototype,"contextWindow",2);jt([L()],Ot.prototype,"sessionId",2);jt([L()],Ot.prototype,"activeChatId",2);jt([L()],Ot.prototype,"chatList",2);jt([L()],Ot.prototype,"error",2);jt([L()],Ot.prototype,"warning",2);jt([L()],Ot.prototype,"openSections",2);Ot=jt([st("agent-sidebar")],Ot);/**
 * @license
 * Copyright 2017 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */const ba={CHILD:2},va=e=>(...t)=>({_$litDirective$:e,values:t});let ya=class{constructor(t){}get _$AU(){return this._$AM._$AU}_$AT(t,n,i){this._$Ct=t,this._$AM=n,this._$Ci=i}_$AS(t,n){return this.update(t,n)}update(t,n){return this.render(...n)}};/**
 * @license
 * Copyright 2020 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */const{I:id}=kc,Oo=e=>e,Mo=()=>document.createComment(""),sn=(e,t,n)=>{const i=e._$AA.parentNode,s=t===void 0?e._$AB:t._$AA;if(n===void 0){const o=i.insertBefore(Mo(),s),r=i.insertBefore(Mo(),s);n=new id(o,r,e,e.options)}else{const o=n._$AB.nextSibling,r=n._$AM,a=r!==e;if(a){let l;n._$AQ?.(e),n._$AM=e,n._$AP!==void 0&&(l=e._$AU)!==r._$AU&&n._$AP(l)}if(o!==s||a){let l=n._$AA;for(;l!==o;){const c=Oo(l).nextSibling;Oo(i).insertBefore(l,s),l=c}}}return n},me=(e,t,n=e)=>(e._$AI(t,n),e),sd={},od=(e,t=sd)=>e._$AH=t,rd=e=>e._$AH,Zi=e=>{e._$AR(),e._$AA.remove()};/**
 * @license
 * Copyright 2017 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */const Po=(e,t,n)=>{const i=new Map;for(let s=t;s<=n;s++)i.set(e[s],s);return i},ad=va(class extends ya{constructor(e){if(super(e),e.type!==ba.CHILD)throw Error("repeat() can only be used in text expressions")}dt(e,t,n){let i;n===void 0?n=t:t!==void 0&&(i=t);const s=[],o=[];let r=0;for(const a of e)s[r]=i?i(a,r):r,o[r]=n(a,r),r++;return{values:o,keys:s}}render(e,t,n){return this.dt(e,t,n).values}update(e,[t,n,i]){const s=rd(e),{values:o,keys:r}=this.dt(t,n,i);if(!Array.isArray(s))return this.ut=r,o;const a=this.ut??=[],l=[];let c,d,h=0,f=s.length-1,g=0,m=o.length-1;for(;h<=f&&g<=m;)if(s[h]===null)h++;else if(s[f]===null)f--;else if(a[h]===r[g])l[g]=me(s[h],o[g]),h++,g++;else if(a[f]===r[m])l[m]=me(s[f],o[m]),f--,m--;else if(a[h]===r[m])l[m]=me(s[h],o[m]),sn(e,l[m+1],s[h]),h++,m--;else if(a[f]===r[g])l[g]=me(s[f],o[g]),sn(e,s[h],s[f]),f--,g++;else if(c===void 0&&(c=Po(r,g,m),d=Po(a,h,f)),c.has(a[h]))if(c.has(a[f])){const v=d.get(r[g]),y=v!==void 0?s[v]:null;if(y===null){const _=sn(e,s[h]);me(_,o[g]),l[g]=_}else l[g]=me(y,o[g]),sn(e,s[h],y),s[v]=null;g++}else Zi(s[f]),f--;else Zi(s[h]),h++;for(;g<=m;){const v=sn(e,l[m+1]);me(v,o[g]),l[g++]=v}for(;h<=f;){const v=s[h++];v!==null&&Zi(v)}return this.ut=r,od(e,l),ua}});var ld=Object.defineProperty,cd=Object.getOwnPropertyDescriptor,An=(e,t,n,i)=>{for(var s=i>1?void 0:i?cd(t,n):t,o=e.length-1,r;o>=0;o--)(r=e[o])&&(s=(i?r(t,n,s):r(s))||s);return i&&s&&ld(t,n,s),s};const dd={Health:"monitor_heart",Migration:"swap_horiz",Setup:"build"};function hd(e){return e.split("-").map(t=>t.charAt(0).toUpperCase()+t.slice(1)).join(" ")}let Ee=class extends it{constructor(){super(...arguments),this.messages=[],this.playbooks=[],this.showPlaybooks=!1,this.hasUserToggledPlaybooks=!1}connectedCallback(){super.connectedCallback(),this.unsubscribe=w.subscribe(()=>{const e=this.messages;this.messages=w.state.messages,this.playbooks=w.state.availablePlaybooks,e.length>0&&this.messages.length===0&&(this.hasUserToggledPlaybooks=!1),this.hasUserToggledPlaybooks||(this.showPlaybooks=this.messages.length===0),this.messages!==e&&this.scrollToBottom()})}disconnectedCallback(){super.disconnectedCallback(),this.unsubscribe?.()}scrollToBottom(){requestAnimationFrame(()=>{this.scrollContainer&&(this.scrollContainer.scrollTop=this.scrollContainer.scrollHeight)})}onTogglePlaybooks(){this.hasUserToggledPlaybooks=!0,this.showPlaybooks=!this.showPlaybooks}onPlaybookClick(e){this.showPlaybooks=!1,this.dispatchEvent(new CustomEvent("send-message",{detail:{message:e.body},bubbles:!0,composed:!0}))}renderPlaybooks(){if(!this.playbooks.length)return X;const e=new Map;for(const t of this.playbooks){const n=e.get(t.category)??[];n.push(t),e.set(t.category,n)}return S`${Array.from(e.entries()).map(([t,n])=>S`
        <div class="playbook-section">
          <div class="playbook-category">${t}</div>
          <div class="playbook-grid">
            ${n.map(i=>S`
                <div class="playbook-card" @click=${()=>this.onPlaybookClick(i)}>
                  <span class="card-icon">${dd[t]??"article"}</span>
                  <div class="card-text">
                    <div class="card-name">${hd(i.name)}</div>
                    <div class="card-desc">${i.description}</div>
                  </div>
                </div>
              `)}
          </div>
        </div>
      `)}`}render(){const e=this.messages.length>0;return S`
      ${e?S`
            <div class="messages-scroll">
              <div class="messages">
                ${ad(this.messages,t=>t.id,t=>S`<chat-message .msg=${t}></chat-message>`)}
              </div>
            </div>
          `:S`
            <div class="empty-state ${this.showPlaybooks?"compact":""}">
              <div class="empty-header">
                <span class="empty-icon">forklift</span>
                <div class="empty-title">Moving your virtual machines?</div>
                <div class="empty-hint">Pick a playbook to get started, or ask me anything.</div>
              </div>
            </div>
          `}

      <div class="composer-area">
        <div class="composer-inner">
          <chat-composer
            .playbooksOpen=${this.showPlaybooks}
            @toggle-playbooks=${this.onTogglePlaybooks}
          ></chat-composer>
          <div class="playbook-panel ${this.showPlaybooks?"open":""}">
            ${this.renderPlaybooks()}
          </div>
        </div>
      </div>
    `}};Ee.styles=at`
    :host {
      display: flex;
      flex-direction: column;
      height: 100%;
      overflow: hidden;
    }

    .messages-scroll {
      flex: 1;
      overflow-y: auto;
      overflow-x: hidden;
      padding: 60px 24px 12px;
      scroll-behavior: smooth;
      scrollbar-width: thin;
      scrollbar-color: var(--border-primary) transparent;
    }

    .messages-scroll::-webkit-scrollbar {
      width: 6px;
    }

    .messages-scroll::-webkit-scrollbar-track {
      background: transparent;
    }

    .messages-scroll::-webkit-scrollbar-thumb {
      background: var(--border-primary);
      border-radius: 3px;
    }

    .messages {
      max-width: var(--chat-max-width);
      margin: 0 auto;
      display: flex;
      flex-direction: column;
      gap: 8px;
    }

    .empty-state {
      flex: 1;
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: center;
      overflow-y: auto;
      padding: 24px;
      scrollbar-width: thin;
      scrollbar-color: var(--border-primary) transparent;
    }

    .empty-state.compact {
      flex: none;
      justify-content: flex-end;
      min-height: 180px;
    }

    .empty-header {
      text-align: center;
      margin-bottom: 32px;
    }

    .empty-icon {
      font-family: "Material Symbols Outlined";
      font-weight: normal;
      font-style: normal;
      font-size: 48px;
      line-height: 1;
      letter-spacing: normal;
      text-transform: none;
      white-space: nowrap;
      direction: ltr;
      font-feature-settings: "liga";
      -webkit-font-smoothing: antialiased;
      opacity: 0.4;
      color: var(--text-tertiary);
    }

    .empty-title {
      font-size: var(--font-size-lg);
      font-weight: var(--font-weight-medium);
      color: var(--text-secondary);
      margin-top: 12px;
    }

    .empty-hint {
      font-size: var(--font-size-sm);
      color: var(--text-tertiary);
      margin-top: 4px;
    }

    .playbook-section {
      width: 100%;
      max-width: var(--chat-max-width);
      margin-bottom: 24px;
    }

    .playbook-category {
      font-size: var(--font-size-xs, 11px);
      font-weight: var(--font-weight-semibold, 600);
      text-transform: uppercase;
      letter-spacing: 0.05em;
      color: var(--text-tertiary);
      margin-bottom: 8px;
      padding-left: 4px;
    }

    .playbook-grid {
      display: grid;
      grid-template-columns: repeat(auto-fill, minmax(240px, 1fr));
      gap: 10px;
    }

    .playbook-card {
      display: flex;
      align-items: flex-start;
      gap: 12px;
      padding: 14px 16px;
      border-radius: var(--radius-lg, 12px);
      border: 1px solid var(--border-primary);
      background: var(--bg-secondary);
      cursor: pointer;
      transition:
        border-color var(--transition-fast),
        box-shadow var(--transition-fast);
    }

    .playbook-card:hover {
      border-color: var(--accent-primary);
      box-shadow: 0 0 0 1px var(--accent-primary);
    }

    .card-icon {
      font-family: "Material Symbols Outlined";
      font-weight: normal;
      font-style: normal;
      font-size: 22px;
      line-height: 1;
      letter-spacing: normal;
      text-transform: none;
      white-space: nowrap;
      direction: ltr;
      font-feature-settings: "liga";
      -webkit-font-smoothing: antialiased;
      color: var(--accent-primary);
      flex-shrink: 0;
      margin-top: 1px;
    }

    .card-text {
      display: flex;
      flex-direction: column;
      gap: 2px;
      min-width: 0;
    }

    .card-name {
      font-size: var(--font-size-sm);
      font-weight: var(--font-weight-medium);
      color: var(--text-primary);
    }

    .card-desc {
      font-size: var(--font-size-xs, 11px);
      color: var(--text-tertiary);
      line-height: 1.4;
      display: -webkit-box;
      -webkit-line-clamp: 2;
      -webkit-box-orient: vertical;
      overflow: hidden;
    }

    .composer-area {
      padding: 8px 24px 24px;
    }

    .composer-inner {
      max-width: var(--chat-max-width);
      margin: 0 auto;
    }

    .playbook-panel {
      max-width: var(--chat-max-width);
      margin: 0 auto;
      overflow: hidden;
      max-height: 0;
      opacity: 0;
      transition:
        max-height 0.3s ease,
        opacity 0.25s ease,
        padding 0.3s ease;
      padding: 0;
    }

    .playbook-panel.open {
      max-height: min(2000px, 60vh);
      opacity: 1;
      padding: 12px 0 0;
      overflow-y: auto;
      scrollbar-width: thin;
      scrollbar-color: var(--border-primary) transparent;
    }
  `;An([L()],Ee.prototype,"messages",2);An([L()],Ee.prototype,"playbooks",2);An([L()],Ee.prototype,"showPlaybooks",2);An([zs(".messages-scroll")],Ee.prototype,"scrollContainer",2);Ee=An([st("agent-chat")],Ee);var ud=Object.defineProperty,fd=Object.getOwnPropertyDescriptor,Mi=(e,t,n,i)=>{for(var s=i>1?void 0:i?fd(t,n):t,o=e.length-1,r;o>=0;o--)(r=e[o])&&(s=(i?r(t,n,s):r(s))||s);return i&&s&&ud(t,n,s),s};let Ue=class extends it{constructor(){super(...arguments),this.userExpanded=!1,this.userOverflows=!1}updated(){if(this.msg.role!=="user"||!this.msg.content)return;(this.renderRoot.querySelector("markdown-renderer")?.updateComplete??Promise.resolve()).then(()=>{requestAnimationFrame(()=>this._measureOverflow())})}_measureOverflow(){const e=this.renderRoot.querySelector(".bubble");if(!e)return;const t=this.userExpanded?!0:e.scrollHeight>e.clientHeight+1;t!==this.userOverflows&&(this.userOverflows=t)}toggleExpand(){this.userExpanded=!this.userExpanded}formatTime(e){return new Date(e).toLocaleTimeString([],{hour:"2-digit",minute:"2-digit"})}render(){const e=this.msg,t=e.role==="user";return S`
      <div class="message ${e.role}">
        ${t?X:S`<span class="role-label">Assistant</span>`}
        ${e.thinking?S`<thinking-indicator></thinking-indicator>`:X}
        ${e.toolCalls?.length?S`
              <div class="tool-calls">
                ${e.toolCalls.map(n=>S`<tool-call-card .entry=${n} .sessionId=${this.msg.id}></tool-call-card>`)}
              </div>
            `:X}
        ${e.content?t?S`
                <div class="bubble-wrapper">
                  <div class="bubble ${this.userExpanded?"":"truncated"}">
                    <markdown-renderer .content=${e.content}></markdown-renderer>
                  </div>
                  ${this.userOverflows?S`<button
                        class="expand-toggle"
                        @click=${this.toggleExpand}
                        title=${this.userExpanded?"Collapse":"Expand"}
                      >
                        ${this.userExpanded?"▽":"◁"}
                      </button>`:X}
                </div>
              `:S`
                <div class="bubble">
                  <markdown-renderer .content=${e.content}></markdown-renderer>
                </div>
              `:X}

        <span class="timestamp">${this.formatTime(e.timestamp)}</span>
      </div>
    `}};Ue.styles=at`
    :host {
      display: block;
      padding: 4px 0;
      animation: fadeIn 0.25s ease;
    }

    @keyframes fadeIn {
      from {
        opacity: 0;
        transform: translateY(8px);
      }
      to {
        opacity: 1;
        transform: translateY(0);
      }
    }

    .message {
      display: flex;
      flex-direction: column;
      max-width: 100%;
    }

    .message.user {
      align-items: flex-end;
    }

    .message.assistant {
      align-items: flex-start;
    }

    .bubble {
      max-width: 85%;
      border-radius: var(--radius-lg);
      line-height: var(--line-height);
    }

    .user .bubble-wrapper .bubble {
      max-width: 100%;
    }

    .user .bubble-wrapper {
      position: relative;
      max-width: 85%;
    }

    .user .bubble {
      background: var(--bg-user-bubble);
      color: var(--text-primary);
      padding: 10px 16px;
      border-bottom-right-radius: var(--radius-xs);
      --md-h1-size: 1em;
      --md-h2-size: 1em;
      --md-h3-size: 1em;
      --md-h4-size: 1em;
    }

    .user .bubble.truncated {
      max-height: 6.4em;
      overflow: hidden;
    }

    .expand-toggle {
      position: absolute;
      top: 4px;
      right: 4px;
      display: flex;
      align-items: center;
      justify-content: center;
      width: 22px;
      height: 22px;
      font-size: 14px;
      line-height: 1;
      color: var(--text-tertiary);
      background: var(--bg-user-bubble);
      border: none;
      border-radius: var(--radius-xs);
      cursor: pointer;
      padding: 0;
      z-index: 1;
    }

    .expand-toggle:hover {
      color: var(--text-secondary);
    }

    .assistant .bubble {
      background: var(--bg-assistant);
      color: var(--text-primary);
      max-width: 100%;
      padding: 4px 0;
    }

    .tool-calls {
      display: flex;
      flex-direction: column;
      gap: 6px;
      margin: 8px 0;
      max-width: 100%;
    }

    .timestamp {
      font-size: var(--font-size-xs);
      color: var(--text-tertiary);
      margin-top: 4px;
      padding: 0 4px;
    }

    .role-label {
      font-size: var(--font-size-xs);
      font-weight: var(--font-weight-medium);
      color: var(--text-tertiary);
      margin-bottom: 4px;
      padding: 0 4px;
      text-transform: uppercase;
      letter-spacing: 0.04em;
    }
  `;Mi([Wt({type:Object})],Ue.prototype,"msg",2);Mi([L()],Ue.prototype,"userExpanded",2);Mi([L()],Ue.prototype,"userOverflows",2);Ue=Mi([st("chat-message")],Ue);var pd=Object.defineProperty,gd=Object.getOwnPropertyDescriptor,Oe=(e,t,n,i)=>{for(var s=i>1?void 0:i?gd(t,n):t,o=e.length-1,r;o>=0;o--)(r=e[o])&&(s=(i?r(t,n,s):r(s))||s);return i&&s&&pd(t,n,s),s};let Qt=class extends it{constructor(){super(...arguments),this.playbooksOpen=!1,this.text="",this.isStreaming=!1,this.usage=null,this.elapsed=null}connectedCallback(){super.connectedCallback(),this.unsubscribe=w.subscribe(()=>{this.isStreaming=w.state.isStreaming,this.usage=w.state.usage,this.elapsed=w.state.streamElapsed})}disconnectedCallback(){super.disconnectedCallback(),this.unsubscribe?.()}autoResize(){const e=this.textarea;e&&(e.style.height="auto",e.style.height=Math.min(e.scrollHeight,200)+"px")}handleInput(e){this.text=e.target.value,this.autoResize()}handleKeyDown(e){e.key==="Enter"&&!e.shiftKey&&(e.preventDefault(),this.send())}togglePlaybooks(){this.dispatchEvent(new CustomEvent("toggle-playbooks",{bubbles:!0,composed:!0}))}send(){const e=this.text.trim();!e||this.isStreaming||(this.text="",this.textarea&&(this.textarea.style.height="auto"),this.dispatchEvent(new CustomEvent("send-message",{detail:{message:e},bubbles:!0,composed:!0})))}formatTokens(e){return e>=1e3?`${(e/1e3).toFixed(1)}k`:String(e)}render(){return S`
      ${this.usage||this.elapsed!==null?S`
            <div class="usage-bar">
              ${this.usage?S`<span>
                    ${this.formatTokens(this.usage.totalTokens)} /
                    ${this.formatTokens(this.usage.contextWindow)} tokens
                  </span>`:""}
              ${this.elapsed!==null?S`<span>${this.elapsed.toFixed(1)}s</span>`:""}
            </div>
          `:""}

      <div class="composer">
        <button
          class="toggle-btn ${this.playbooksOpen?"open":""}"
          @click=${this.togglePlaybooks}
          title="${this.playbooksOpen?"Hide playbooks":"Show playbooks"}"
          aria-label="${this.playbooksOpen?"Hide playbooks":"Show playbooks"}"
        >
          <span class="material-symbols-outlined">add</span>
        </button>
        <textarea
          rows="1"
          placeholder="Send a message..."
          .value=${this.text}
          @input=${this.handleInput}
          @keydown=${this.handleKeyDown}
          ?disabled=${this.isStreaming}
        ></textarea>
        <button
          class="send-btn"
          @click=${this.send}
          ?disabled=${this.isStreaming||!this.text.trim()}
          title="Send message"
          aria-label="Send message"
        >
          <span class="material-symbols-outlined">forklift</span>
        </button>
      </div>
    `}};Qt.styles=at`
    :host {
      display: block;
    }

    .usage-bar {
      display: flex;
      align-items: center;
      justify-content: flex-end;
      gap: 12px;
      padding: 4px 8px;
      font-size: var(--font-size-xs);
      color: var(--text-tertiary);
    }

    .composer {
      display: flex;
      align-items: flex-end;
      gap: 8px;
      padding: 12px 16px;
      background: var(--bg-input);
      border: 1px solid var(--border-primary);
      border-radius: var(--radius-xl);
      box-shadow: var(--shadow-md);
      transition:
        border-color var(--transition-fast),
        box-shadow var(--transition-fast);
    }

    .composer:focus-within {
      border-color: var(--accent-primary);
      box-shadow:
        var(--shadow-md),
        0 0 0 2px rgba(174, 86, 48, 0.15);
    }

    textarea {
      flex: 1;
      border: none;
      background: none;
      resize: none;
      outline: none;
      font-family: var(--font-sans);
      font-size: var(--font-size-base);
      line-height: var(--line-height);
      color: var(--text-primary);
      max-height: 200px;
      min-height: 24px;
      padding: 7px 0;
    }

    textarea::placeholder {
      color: var(--text-tertiary);
    }

    .send-btn {
      display: flex;
      align-items: center;
      justify-content: center;
      width: 36px;
      height: 36px;
      border: none;
      border-radius: var(--radius-full);
      background: var(--accent-primary);
      color: var(--text-inverse);
      cursor: pointer;
      flex-shrink: 0;
      transition:
        background var(--transition-fast),
        transform var(--transition-fast);
    }

    .send-btn:hover {
      background: var(--accent-hover);
    }

    .send-btn:active {
      transform: scale(0.95);
    }

    .send-btn:disabled {
      background: var(--bg-tertiary);
      color: var(--text-secondary);
      cursor: not-allowed;
    }

    .send-btn .material-symbols-outlined {
      font-family: "Material Symbols Outlined";
      font-weight: normal;
      font-style: normal;
      font-size: 20px;
      line-height: 1;
      letter-spacing: normal;
      text-transform: none;
      white-space: nowrap;
      direction: ltr;
      font-feature-settings: "liga";
      -webkit-font-smoothing: antialiased;
    }

    .toggle-btn {
      display: flex;
      align-items: center;
      justify-content: center;
      width: 36px;
      height: 36px;
      border: none;
      border-radius: var(--radius-full);
      background: transparent;
      color: var(--text-tertiary);
      cursor: pointer;
      flex-shrink: 0;
      transition:
        color var(--transition-fast),
        background var(--transition-fast),
        transform var(--transition-fast);
    }

    .toggle-btn:hover {
      color: var(--accent-primary);
      background: var(--bg-secondary);
    }

    .toggle-btn.open {
      color: var(--accent-primary);
      transform: rotate(45deg);
    }

    .toggle-btn .material-symbols-outlined {
      font-family: "Material Symbols Outlined";
      font-weight: normal;
      font-style: normal;
      font-size: 22px;
      line-height: 1;
      letter-spacing: normal;
      text-transform: none;
      white-space: nowrap;
      direction: ltr;
      font-feature-settings: "liga";
      -webkit-font-smoothing: antialiased;
    }
  `;Oe([Wt({type:Boolean})],Qt.prototype,"playbooksOpen",2);Oe([L()],Qt.prototype,"text",2);Oe([L()],Qt.prototype,"isStreaming",2);Oe([L()],Qt.prototype,"usage",2);Oe([L()],Qt.prototype,"elapsed",2);Oe([zs("textarea")],Qt.prototype,"textarea",2);Qt=Oe([st("chat-composer")],Qt);const md={table:"markdown",graph:"graph",markdown:"markdown",text:"text",log:"text",raw:"text"};function bd(e){return md[e]}function vd(e){const t=fa.lexer(e);for(const n of t)if(n.type==="table"){const i=n;return{headers:i.header.map(s=>s.text),rows:i.rows.map(s=>s.map(o=>o.text))}}return null}function yd(e){return e.replace(/^-+\s*/,"").replace(/\s*-+$/,"").trim()}function xd(e){const t=fa.lexer(e),n=[];let i;for(const s of t)if(s.type==="heading")i=yd(s.text);else if(s.type==="table"){const o=s;n.push({heading:i,table:{headers:o.header.map(r=>r.text),rows:o.rows.map(r=>r.map(a=>a.text))}}),i=void 0}else s.type!=="space"&&(i=void 0);return n}function _d(e){const t=[0];let n=0;for(let i=0;i<e.length;i++)e[i]===" "?n++:(n>=2&&t.push(i),n=0);return t}function wd(e){const t=e.split(`
`).filter(s=>s.trim());if(t.length<2)return null;const n=_d(t[0]);if(n.length<2)return null;const i=s=>n.map((o,r)=>{const a=r<n.length-1?n[r+1]:s.length;return s.substring(o,a).trim()});return{headers:i(t[0]),rows:t.slice(1).map(s=>i(s))}}function kd(e){const t=e.search(/[[{]/);if(t<0)return null;const n=e.slice(t);try{return JSON.parse(n)}catch{return null}}function Sd(e){return e==null?"":typeof e=="object"?JSON.stringify(e):String(e)}function Ed(e){const t=kd(e);if(t===null||typeof t!="object")return null;const n=[];if(Array.isArray(t))for(const r of t)r!==null&&typeof r=="object"&&!Array.isArray(r)&&n.push(r);else n.push(t);if(n.length===0)return null;const i=new Set;for(const r of n)for(const a of Object.keys(r))i.add(a);const s=[...i];if(s.length===0)return null;const o=n.map(r=>s.map(a=>Sd(r[a])));return{headers:s,rows:o}}function xa(e){return vd(e)??wd(e)??Ed(e)}const Td=new Set(["true","yes"]),Cd=new Set(["false","no"]);function Od(e){const t=e.trim();if(!t)return t;const n=t.toLowerCase();if(Td.has(n))return"true";if(Cd.has(n))return"false";if(/^[+-]?\d+(\.\d+)?$/.test(t)){const i=parseFloat(t);if(!isNaN(i))return String(i)}return t}function Md(e){return{headers:e.headers,rows:e.rows.map(t=>t.map(Od))}}function Pd(e){const t=i=>"| "+i.join(" | ")+" |",n=e.headers.map(()=>"---");return[t(e.headers),t(n),...e.rows.map(t)].join(`
`)}function Ad(e){if(!e?.trim())return e;const t=xa(e);return t?Pd(Md(t)):e}function Me(e){return e?.trim()?Ad(e):e}function Pe(e){return e}const Dn="mtv_read",In="user-kubectl-mtv",Dd=["get plan","get provider","get hook","get host","get mapping"];function Rn(e){return typeof e.command=="string"?e.command.trim():""}const Id={server:In,tool:Dn,category:"resource-list",renderer:"table",canPin:!0,canPinGraph:!1,match(e){const t=Rn(e);return Dd.some(n=>t===n||t.startsWith(n+" "))},parse:Me},Rd={server:In,tool:Dn,category:"inventory-list",renderer:"table",canPin:!0,canPinGraph:!1,match(e){return Rn(e).startsWith("get inventory")},parse:Me},Nd={server:In,tool:Dn,category:"resource-describe",renderer:"markdown",canPin:!0,canPinGraph:!1,match(e){return Rn(e).startsWith("describe")},parse:Pe},Ld={server:In,tool:Dn,category:"health",renderer:"text",canPin:!0,canPinGraph:!1,match(e){return Rn(e)==="health"},parse:Pe},zd={server:In,tool:Dn,category:"settings",renderer:"table",canPin:!0,canPinGraph:!1,match(e){const t=Rn(e);return t==="settings"||t==="settings get"},parse:Me},$d=[Rd,Nd,Ld,zd,Id],Fd={server:"user-kubectl-mtv",tool:"mtv_write",category:"write",renderer:"markdown",canPin:!1,canPinGraph:!1,match(){return!0},parse:Pe},Bd=[Fd],Hd={server:"user-kubectl-mtv",tool:"mtv_help",category:"help",renderer:"markdown",canPin:!1,canPinGraph:!1,match(){return!0},parse:Pe},Ud=[Hd];function Wd(e){return e}const $s="metrics_read",Fs="user-kubectl-metrics";function Bs(e){return typeof e.command=="string"?e.command.trim():""}const jd={server:Fs,tool:$s,category:"query-range",renderer:"graph",canPin:!0,canPinGraph:!0,match(e){const t=Bs(e);return t==="query_range"||t==="preset"},parse:Wd},Vd={server:Fs,tool:$s,category:"query",renderer:"table",canPin:!0,canPinGraph:!1,match(e){return Bs(e)==="query"},parse:Me},Yd={server:Fs,tool:$s,category:"discover",renderer:"table",canPin:!0,canPinGraph:!1,match(e){const t=Bs(e);return t==="discover"||t==="labels"},parse:Me},Gd=[jd,Vd,Yd],Kd={server:"user-kubectl-metrics",tool:"metrics_help",category:"help",renderer:"markdown",canPin:!1,canPinGraph:!1,match(){return!0},parse:Pe},qd=[Kd];function Xd(e){return e?.trim()?"```\n"+e.trimEnd()+"\n```":e}const Pi="debug_read",Ai="user-kubectl-debug-queries";function Di(e){return typeof e.command=="string"?e.command.trim():""}const Zd={server:Ai,tool:Pi,category:"resource-list",renderer:"table",canPin:!0,canPinGraph:!1,match(e){return Di(e)==="list"},parse:Me},Jd={server:Ai,tool:Pi,category:"resource-get",renderer:"markdown",canPin:!0,canPinGraph:!1,match(e){return Di(e)==="get"},parse:Pe},Qd={server:Ai,tool:Pi,category:"logs",renderer:"log",canPin:!0,canPinGraph:!1,match(e){return Di(e)==="logs"},parse:Xd},th={server:Ai,tool:Pi,category:"events",renderer:"table",canPin:!0,canPinGraph:!1,match(e){return Di(e)==="events"},parse:Me},eh=[Zd,Jd,Qd,th],nh={server:"user-kubectl-debug-queries",tool:"debug_help",category:"help",renderer:"markdown",canPin:!1,canPinGraph:!1,match(){return!0},parse:Pe},ih=[nh],sh=[...$d,...Bd,...Ud,...Gd,...qd,...eh,...ih];function _a(e){if(!e?.trim())return{text:"",hasError:!0,errorMessage:"Empty tool result"};try{const t=JSON.parse(e);if(!t||typeof t!="object")return{text:e,hasError:!1};const n=t.return_value,i=typeof t.output=="string"?t.output:"",s=typeof t.stderr=="string"?t.stderr.trim():"";if(typeof n=="number"&&n!==0){const o=s||i||`Tool exited with code ${n}`;return{text:i||s,hasError:!0,errorMessage:o}}return s&&typeof n!="number"?{text:i,hasError:!0,errorMessage:s}:typeof t.output=="string"?{text:i,hasError:!1}:{text:e,hasError:!1}}catch{return{text:e,hasError:!1}}}function oh(e){return e?.trim()?"```\n"+e.trimEnd()+"\n```":e}const rh=new Set(["json","yaml"]);function ah(e,t){return"```"+t+`
`+e.trimEnd()+"\n```"}const pi=new Map;for(const e of sh){const t=pi.get(e.tool)??[];t.push(e),pi.set(e.tool,t)}function Ao(e){const t=e.flags;if(t&&typeof t=="object"&&!Array.isArray(t)){const n=t.output;if(typeof n=="string")return n}if(typeof e.output=="string")return e.output}function Do(e){return typeof e.command=="string"?e.command.trim():""}function wa(e,t){const n=pi.get(e);if(n){for(const i of n)if(i.match(t))return{identified:!0,server:i.server,tool:i.tool,command:Do(t),category:i.category,renderer:i.renderer,outputFlag:Ao(t),canPin:i.canPin,canPinGraph:i.canPinGraph}}return{identified:!1,server:"unknown",tool:e,command:Do(t),category:"unknown",renderer:"raw",outputFlag:Ao(t),canPin:!1,canPinGraph:!1}}function lh(e){return e.identified?pi.get(e.tool)?.find(n=>n.category===e.category):void 0}function gs(e,t){const n=_a(t),i="text";if(n.hasError)return{hasError:!0,errorMessage:n.errorMessage,content:n.text||n.errorMessage||t,displayType:i,raw:t};const s=lh(e),o=n.text,r=e.outputFlag?.toLowerCase();if(r&&rh.has(r))return{hasError:!1,content:ah(o,r),displayType:"markdown",raw:t};if(r==="markdown")return{hasError:!1,content:s?s.parse(o):o,displayType:"markdown",raw:t};const a=s?s.parse(o):oh(o),l=s?bd(s.renderer):i;return{hasError:!1,content:a,displayType:l,raw:t}}const ch={k:1e3,K:1e3,M:1e6,G:1e9,T:1e12};function dh(e){const t=e.trim();if(!t)return NaN;const n=t.match(/^([+-]?\d+(?:\.\d+)?)\s*([kKMGT])?$/);return n?parseFloat(n[1])*(n[2]?ch[n[2]]??1:1):NaN}function Io(e,t){const{headers:n,rows:i}=e,s=n.findIndex(a=>/^timestamp$/i.test(a));if(s<0)return[];const o=n.map((a,l)=>({name:a,idx:l})).filter(({idx:a})=>a!==s);if(o.length===0)return[];const r=[];for(const a of o){const l=t??a.name,c=[];for(const d of i){const h=d[s]?.trim(),f=d[a.idx]?.trim();if(!h||!f)continue;const g=Date.parse(h),m=dh(f);isNaN(g)||isNaN(m)||c.push({x:g,y:m})}c.length>0&&(c.sort((d,h)=>d.x-h.x),r.push({name:l,data:c}))}return r}function hh(e){if(!e?.trim())return null;const t=xd(e);if(t.length>0){const s=t.flatMap(o=>Io(o.table,o.heading));if(s.length>0)return{series:s}}const n=xa(e);if(!n)return null;const i=Io(n);return i.length>0?{series:i}:null}function qn(e,t){const n=e+JSON.stringify(t);let i=5381;for(let s=0;s<n.length;s++)i=(i<<5)+i+n.charCodeAt(s)>>>0;return`card-${i.toString(36)}`}function ms(e){const t=_a(e).text;return t?.trim()?hh(t):null}var uh=Object.defineProperty,fh=Object.getOwnPropertyDescriptor,Ke=(e,t,n,i)=>{for(var s=i>1?void 0:i?fh(t,n):t,o=e.length-1,r;o>=0;o--)(r=e[o])&&(s=(i?r(t,n,s):r(s))||s);return i&&s&&uh(t,n,s),s};let ae=class extends it{constructor(){super(...arguments),this.sessionId="",this.expanded=!1,this.pinned=!1,this.graphPinned=!1,this._graphCacheValue=!1}get identification(){const e=this.entry,t=e.name+JSON.stringify(e.arguments);return this._idCacheKey===t&&this._idCacheValue?this._idCacheValue:(this._idCacheKey=t,this._idCacheValue=wa(e.name,e.arguments),this._idCacheValue)}connectedCallback(){super.connectedCallback(),this.unsubscribe=w.subscribe(()=>this.syncPinned())}disconnectedCallback(){super.disconnectedCallback(),this.unsubscribe?.()}syncPinned(){const e=this.entry;e.result&&!e.denied&&(this.pinned=w.hasCard(qn(e.name,e.arguments)),this.graphPinned=w.hasCard(`graph-${qn(e.name,e.arguments)}`))}toggle(){this.expanded=!this.expanded}pinCard(e){e.stopPropagation();const t=this.entry,n=qn(t.name,t.arguments);if(w.hasCard(n)){w.removeCard(n);return}const i=t.arguments.command,s=i?`${t.name}: ${i}`:t.name,o=t.result,r={id:n,title:s,content:"",timestamp:Date.now(),toolName:t.name,toolArgs:t.arguments,loading:!0};this.dispatchEvent(new CustomEvent("pin-card",{detail:{card:r},bubbles:!0,composed:!0})),setTimeout(()=>{const a=gs(this.identification,o),l=this.identification.canPinGraph?"text":a.displayType;w.updateCard(n,{content:a.content,type:l,loading:!1})},0)}async approve(){const e=w.state.sessionId;if(e){w.updateLastToolCall(t=>({...t,pending:!1}));try{await ps(e,!0)}catch{}}}async deny(){const e=w.state.sessionId;if(e){w.updateLastToolCall(t=>({...t,pending:!1,denied:!0,denyReason:"denied by user"}));try{await ps(e,!1,"denied by user")}catch{}}}get hasResultError(){return this.entry.result?gs(this.identification,this.entry.result).hasError:!1}get statusBadge(){const e=this.entry;return e.denied?S`<span class="badge denied">denied</span>`:e.pending?S`<span class="badge waiting">waiting</span>`:e.result!==void 0?this.hasResultError?S`<span class="badge error">error</span>`:S`<span class="badge done">done</span>`:S`<span class="badge running">running</span>`}get iconClass(){const e=this.entry;return e.denied?"denied":e.pending?"pending":e.result!==void 0?"result":"call"}get canPin(){const e=this.entry;return!e.result||e.denied?!1:this.identification.canPin}get canPinGraph(){const e=this.entry;if(!e.result||e.denied||!this.identification.canPinGraph)return!1;if(this._graphCacheKey===e.result)return this._graphCacheValue;this._graphCacheKey=e.result;const t=ms(e.result);return this._graphCacheValue=t!==null&&t.series.length>0,this._graphCacheValue}get pinButton(){return this.canPin?S`
      <button
        class="pin-btn ${this.pinned?"pinned":""}"
        @click=${this.pinCard}
        title=${this.pinned?"Pinned":"Pin to detail pane"}
      >
        <svg
          viewBox="0 0 24 24"
          fill="${this.pinned?"currentColor":"none"}"
          stroke="currentColor"
          stroke-width="2"
          stroke-linecap="round"
          stroke-linejoin="round"
        >
          <path d="M12 2 L12 12" />
          <path d="M18.5 8.5 C18.5 12 16 14 12 14 C8 14 5.5 12 5.5 8.5" />
          <path d="M12 14 L12 22" />
        </svg>
      </button>
    `:X}pinGraphCard(e){e.stopPropagation();const t=this.entry,n=`graph-${qn(t.name,t.arguments)}`;if(w.hasCard(n)){w.removeCard(n);return}const i=t.arguments.command,s=i?`${t.name}: ${i}`:t.name,o={id:n,title:s,content:t.result,timestamp:Date.now(),toolName:t.name,toolArgs:t.arguments,type:"graph"};this.dispatchEvent(new CustomEvent("pin-card",{detail:{card:o},bubbles:!0,composed:!0}))}get graphPinButton(){return this.canPinGraph?S`
      <button
        class="pin-btn ${this.graphPinned?"pinned":""}"
        @click=${this.pinGraphCard}
        title=${this.graphPinned?"Graph pinned":"Pin as graph"}
      >
        <svg
          viewBox="0 0 24 24"
          fill="${this.graphPinned?"currentColor":"none"}"
          stroke="currentColor"
          stroke-width="2"
          stroke-linecap="round"
          stroke-linejoin="round"
        >
          <polyline points="22 12 18 12 15 21 9 3 6 12 2 12" />
        </svg>
      </button>
    `:X}render(){const e=this.entry,t=JSON.stringify(e.arguments,null,2);return S`
      <div class="card">
        <div class="header" @click=${this.toggle}>
          <svg
            class="chevron ${this.expanded?"open":""}"
            viewBox="0 0 24 24"
            fill="none"
            stroke="currentColor"
            stroke-width="2"
            stroke-linecap="round"
            stroke-linejoin="round"
          >
            <polyline points="9 18 15 12 9 6" />
          </svg>
          <svg
            class="icon ${this.iconClass}"
            viewBox="0 0 24 24"
            fill="none"
            stroke="currentColor"
            stroke-width="2"
            stroke-linecap="round"
            stroke-linejoin="round"
          >
            <path
              d="M14.7 6.3a1 1 0 0 0 0 1.4l1.6 1.6a1 1 0 0 0 1.4 0l3.77-3.77a6 6 0 0 1-7.94 7.94l-6.91 6.91a2.12 2.12 0 0 1-3-3l6.91-6.91a6 6 0 0 1 7.94-7.94l-3.76 3.76z"
            />
          </svg>
          <span class="name">${e.name}</span>
          ${this.identification.identified?S`<span class="badge category">${this.identification.category}</span>`:X}
          ${this.statusBadge} ${this.graphPinButton} ${this.pinButton}
        </div>

        ${this.expanded?S`
              <div class="body">
                <div class="section-label">Arguments</div>
                <div class="code-block">${t}</div>

                ${e.result!==void 0?S`
                      <div class="result-section">
                        <div class="section-label">Result</div>
                        <div class="code-block">${e.result}</div>
                      </div>
                    `:X}
                ${e.denied&&e.denyReason?S`
                      <div class="result-section">
                        <div class="section-label">Denial reason</div>
                        <div class="code-block">${e.denyReason}</div>
                      </div>
                    `:X}
              </div>
            `:X}
        ${e.pending?S`
              <div class="approval-bar">
                <span>Approve this tool call?</span>
                <button class="deny-btn" @click=${this.deny}>Deny</button>
                <button class="approve-btn" @click=${this.approve}>Approve</button>
              </div>
            `:X}
      </div>
    `}};ae.styles=at`
    :host {
      display: block;
    }

    .card {
      border: 1px solid var(--border-secondary);
      border-radius: var(--radius-sm);
      background: var(--bg-tool);
      overflow: hidden;
      font-size: var(--font-size-sm);
    }

    .header {
      display: flex;
      align-items: center;
      gap: 8px;
      padding: 8px 12px;
      background: var(--bg-tool-header);
      cursor: pointer;
      user-select: none;
      transition: background var(--transition-fast);
    }

    .header:hover {
      background: var(--bg-hover);
    }

    .chevron {
      width: 14px;
      height: 14px;
      color: var(--text-tertiary);
      transition: transform var(--transition-fast);
      flex-shrink: 0;
    }

    .chevron.open {
      transform: rotate(90deg);
    }

    .icon {
      width: 16px;
      height: 16px;
      flex-shrink: 0;
    }

    .icon.call {
      color: var(--accent-warning);
    }

    .icon.result {
      color: var(--accent-success);
    }

    .icon.denied {
      color: var(--accent-danger);
    }

    .icon.pending {
      color: var(--accent-info);
    }

    .name {
      font-weight: var(--font-weight-medium);
      color: var(--text-primary);
      flex: 1;
      overflow: hidden;
      text-overflow: ellipsis;
      white-space: nowrap;
    }

    .badge {
      font-size: var(--font-size-xs);
      padding: 2px 6px;
      border-radius: var(--radius-full);
      font-weight: var(--font-weight-medium);
      white-space: nowrap;
    }

    .badge.category {
      background: rgba(50, 102, 173, 0.1);
      color: var(--text-tertiary);
      font-family: var(--font-mono);
    }

    .badge.running {
      background: rgba(59, 130, 246, 0.1);
      color: var(--accent-info);
    }

    .badge.done {
      background: rgba(34, 197, 94, 0.1);
      color: var(--accent-success);
    }

    .badge.error,
    .badge.denied {
      background: rgba(239, 68, 68, 0.1);
      color: var(--accent-danger);
    }

    .badge.waiting {
      background: rgba(59, 130, 246, 0.1);
      color: var(--accent-info);
    }

    .body {
      padding: 10px 12px;
      border-top: 1px solid var(--border-secondary);
    }

    .section-label {
      font-size: var(--font-size-xs);
      font-weight: var(--font-weight-bold);
      color: var(--text-tertiary);
      text-transform: uppercase;
      letter-spacing: 0.04em;
      margin-bottom: 4px;
    }

    .code-block {
      font-family: var(--font-mono);
      font-size: var(--font-size-xs);
      padding: 8px 10px;
      background: var(--bg-code);
      border-radius: var(--radius-xs);
      white-space: pre-wrap;
      word-break: break-all;
      overflow-x: auto;
      max-height: 300px;
      overflow-y: auto;
      color: var(--text-primary);
      line-height: 1.5;
    }

    .result-section {
      margin-top: 10px;
    }

    .approval-bar {
      display: flex;
      align-items: center;
      gap: 8px;
      padding: 10px 12px;
      border-top: 1px solid var(--border-secondary);
    }

    .approval-bar span {
      flex: 1;
      font-size: var(--font-size-sm);
      color: var(--text-secondary);
    }

    .approve-btn,
    .deny-btn {
      padding: 6px 14px;
      border-radius: var(--radius-sm);
      font-size: var(--font-size-sm);
      font-weight: var(--font-weight-medium);
      cursor: pointer;
      transition: background var(--transition-fast);
    }

    .approve-btn {
      background: var(--accent-success);
      color: white;
    }

    .approve-btn:hover {
      filter: brightness(1.1);
    }

    .deny-btn {
      background: var(--bg-tertiary);
      color: var(--text-secondary);
      border: 1px solid var(--border-primary);
    }

    .deny-btn:hover {
      background: var(--bg-hover);
      color: var(--accent-danger);
    }

    .pin-btn {
      display: inline-flex;
      align-items: center;
      justify-content: center;
      width: 24px;
      height: 24px;
      padding: 0;
      border: none;
      border-radius: var(--radius-xs);
      background: transparent;
      color: var(--text-tertiary);
      cursor: pointer;
      flex-shrink: 0;
      transition: all var(--transition-fast);
    }

    .pin-btn:hover {
      background: var(--bg-hover);
      color: var(--accent-primary);
    }

    .pin-btn.pinned {
      color: var(--accent-primary);
    }

    .pin-btn svg {
      width: 14px;
      height: 14px;
    }
  `;Ke([Wt({type:Object})],ae.prototype,"entry",2);Ke([Wt({type:String})],ae.prototype,"sessionId",2);Ke([L()],ae.prototype,"expanded",2);Ke([L()],ae.prototype,"pinned",2);Ke([L()],ae.prototype,"graphPinned",2);ae=Ke([st("tool-call-card")],ae);var ph=Object.defineProperty,gh=Object.getOwnPropertyDescriptor,Hs=(e,t,n,i)=>{for(var s=i>1?void 0:i?gh(t,n):t,o=e.length-1,r;o>=0;o--)(r=e[o])&&(s=(i?r(t,n,s):r(s))||s);return i&&s&&ph(t,n,s),s};const Ro=[{value:"auto-accept",label:"Accept"},{value:"ask",label:"Ask"},{value:"auto-reject",label:"Reject"}];let xn=class extends it{constructor(){super(...arguments),this.tools=[],this.policies={}}connectedCallback(){super.connectedCallback(),this.unsubscribe=w.subscribe(()=>{this.tools=w.state.availableTools,this.policies=w.state.toolPolicies}),this.tools=w.state.availableTools,this.policies=w.state.toolPolicies}disconnectedCallback(){super.disconnectedCallback(),this.unsubscribe?.()}setPolicy(e,t){w.setToolPolicy(e,t)}setAll(e){w.setAllToolPolicies(e)}get allPolicy(){const e=Object.values(this.policies);if(e.length===0)return null;const t=e[0];return e.every(n=>n===t)?t:null}render(){if(!this.tools.length)return S`<div class="empty">No tools available</div>`;const e=this.allPolicy;return S`
      <div class="bulk-actions">
        ${Ro.map(t=>S`
            <button
              class="bulk-btn ${e===t.value?"active":""}"
              @click=${()=>this.setAll(t.value)}
            >
              All ${t.label}
            </button>
          `)}
      </div>
      <div class="tool-list">
        ${this.tools.map(t=>{const n=this.policies[t.name]??Fe(t.name);return S`
            <div class="tool-row">
              <div class="tool-name-wrap">
                <div class="tool-name">${t.name}</div>
                ${t.description?S`<div class="tool-tip">${t.description}</div>`:X}
              </div>
              <div class="policy-toggle">
                ${Ro.map(i=>S`
                    <button
                      class="policy-btn ${n===i.value?`selected-${i.value}`:""}"
                      @click=${()=>this.setPolicy(t.name,i.value)}
                      title=${i.label}
                    >
                      ${i.label}
                    </button>
                  `)}
              </div>
            </div>
          `})}
      </div>
    `}};xn.styles=at`
    :host {
      display: block;
    }

    .bulk-actions {
      display: flex;
      gap: 6px;
      margin-bottom: 8px;
    }

    .bulk-btn {
      padding: 3px 10px;
      border-radius: var(--radius-full);
      font-size: var(--font-size-xs);
      font-weight: var(--font-weight-medium);
      border: 1px solid var(--border-primary);
      background: var(--bg-primary);
      color: var(--text-secondary);
      cursor: pointer;
      transition: all var(--transition-fast);
    }

    .bulk-btn:hover {
      background: var(--bg-hover);
      color: var(--text-primary);
    }

    .bulk-btn.active {
      background: var(--accent-primary);
      color: var(--text-inverse);
      border-color: var(--accent-primary);
    }

    .tool-list {
      display: flex;
      flex-direction: column;
      gap: 4px;
    }

    .tool-row {
      display: flex;
      align-items: center;
      gap: 8px;
      padding: 4px 0;
    }

    .tool-name-wrap {
      flex: 1;
      min-width: 0;
      position: relative;
    }

    .tool-name {
      font-size: var(--font-size-xs);
      color: var(--text-primary);
      overflow: hidden;
      text-overflow: ellipsis;
      white-space: nowrap;
      cursor: default;
    }

    .tool-tip {
      display: none;
      position: absolute;
      bottom: calc(100% + 6px);
      left: 0;
      z-index: 100;
      max-width: 280px;
      padding: 6px 10px;
      border-radius: var(--radius-sm);
      background: var(--bg-tertiary);
      border: 1px solid var(--border-primary);
      color: var(--text-secondary);
      font-size: var(--font-size-xs);
      line-height: 1.4;
      white-space: normal;
      word-wrap: break-word;
      box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
      pointer-events: none;
    }

    .tool-name-wrap:hover .tool-tip {
      display: block;
    }

    .policy-toggle {
      display: flex;
      border-radius: var(--radius-full);
      border: 1px solid var(--border-primary);
      overflow: hidden;
      flex-shrink: 0;
    }

    .policy-btn {
      padding: 2px 8px;
      font-size: 10px;
      font-weight: var(--font-weight-medium);
      border: none;
      background: var(--bg-primary);
      color: var(--text-tertiary);
      cursor: pointer;
      transition: all var(--transition-fast);
      line-height: 1.4;
    }

    .policy-btn:not(:last-child) {
      border-right: 1px solid var(--border-primary);
    }

    .policy-btn:hover {
      background: var(--bg-hover);
      color: var(--text-primary);
    }

    .policy-btn.selected-auto-accept {
      background: var(--accent-success);
      color: white;
    }

    .policy-btn.selected-ask {
      background: var(--accent-info);
      color: white;
    }

    .policy-btn.selected-auto-reject {
      background: var(--accent-danger);
      color: white;
    }

    .empty {
      font-size: var(--font-size-sm);
      color: var(--text-tertiary);
      padding: 4px 0;
    }
  `;Hs([L()],xn.prototype,"tools",2);Hs([L()],xn.prototype,"policies",2);xn=Hs([st("tool-policy-editor")],xn);var mh=Object.getOwnPropertyDescriptor,bh=(e,t,n,i)=>{for(var s=i>1?void 0:i?mh(t,n):t,o=e.length-1,r;o>=0;o--)(r=e[o])&&(s=r(s)||s);return s};let bs=class extends it{render(){return S`
      <div class="dots">
        <div class="dot"></div>
        <div class="dot"></div>
        <div class="dot"></div>
      </div>
      <span class="label">Thinking...</span>
    `}};bs.styles=at`
    :host {
      display: inline-flex;
      align-items: center;
      gap: 10px;
      padding: 12px 0;
    }

    .dots {
      display: flex;
      gap: 4px;
    }

    .dot {
      width: 8px;
      height: 8px;
      border-radius: 50%;
      background: var(--accent-primary);
      opacity: 0.3;
      animation: pulse 1.4s ease-in-out infinite;
    }

    .dot:nth-child(2) {
      animation-delay: 0.2s;
    }

    .dot:nth-child(3) {
      animation-delay: 0.4s;
    }

    @keyframes pulse {
      0%,
      80%,
      100% {
        opacity: 0.3;
        transform: scale(0.8);
      }
      40% {
        opacity: 1;
        transform: scale(1);
      }
    }

    .label {
      font-size: var(--font-size-sm);
      color: var(--text-tertiary);
    }
  `;bs=bh([st("thinking-indicator")],bs);/**
 * @license
 * Copyright 2017 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */class vs extends ya{constructor(t){if(super(t),this.it=X,t.type!==ba.CHILD)throw Error(this.constructor.directiveName+"() can only be used in child bindings")}render(t){if(t===X||t==null)return this._t=void 0,this.it=t;if(t===ua)return t;if(typeof t!="string")throw Error(this.constructor.directiveName+"() called with a non-string value");if(t===this.it)return this._t;this.it=t;const n=[t];return n.raw=n,this._t={_$litType$:this.constructor.resultType,strings:n,values:[]}}}vs.directiveName="unsafeHTML",vs.resultType=1;const vh=va(vs);function Us(e){const t=e.regex,n={},i={begin:/\$\{/,end:/\}/,contains:["self",{begin:/:-/,contains:[n]}]};Object.assign(n,{className:"variable",variants:[{begin:t.concat(/\$[\w\d#@][\w\d_]*/,"(?![\\w\\d])(?![$])")},i]});const s={className:"subst",begin:/\$\(/,end:/\)/,contains:[e.BACKSLASH_ESCAPE]},o=e.inherit(e.COMMENT(),{match:[/(^|\s)/,/#.*$/],scope:{2:"comment"}}),r={begin:/<<-?\s*(?=\w+)/,starts:{contains:[e.END_SAME_AS_BEGIN({begin:/(\w+)/,end:/(\w+)/,className:"string"})]}},a={className:"string",begin:/"/,end:/"/,contains:[e.BACKSLASH_ESCAPE,n,s]};s.contains.push(a);const l={match:/\\"/},c={className:"string",begin:/'/,end:/'/},d={match:/\\'/},h={begin:/\$?\(\(/,end:/\)\)/,contains:[{begin:/\d+#[0-9a-f]+/,className:"number"},e.NUMBER_MODE,n]},f=["fish","bash","zsh","sh","csh","ksh","tcsh","dash","scsh"],g=e.SHEBANG({binary:`(${f.join("|")})`,relevance:10}),m={className:"function",begin:/\w[\w\d_]*\s*\(\s*\)\s*\{/,returnBegin:!0,contains:[e.inherit(e.TITLE_MODE,{begin:/\w[\w\d_]*/})],relevance:0},v=["if","then","else","elif","fi","time","for","while","until","in","do","done","case","esac","coproc","function","select"],y=["true","false"],_={match:/(\/[a-z._-]+)+/},E=["break","cd","continue","eval","exec","exit","export","getopts","hash","pwd","readonly","return","shift","test","times","trap","umask","unset"],O=["alias","bind","builtin","caller","command","declare","echo","enable","help","let","local","logout","mapfile","printf","read","readarray","source","sudo","type","typeset","ulimit","unalias"],M=["autoload","bg","bindkey","bye","cap","chdir","clone","comparguments","compcall","compctl","compdescribe","compfiles","compgroups","compquote","comptags","comptry","compvalues","dirs","disable","disown","echotc","echoti","emulate","fc","fg","float","functions","getcap","getln","history","integer","jobs","kill","limit","log","noglob","popd","print","pushd","pushln","rehash","sched","setcap","setopt","stat","suspend","ttyctl","unfunction","unhash","unlimit","unsetopt","vared","wait","whence","where","which","zcompile","zformat","zftp","zle","zmodload","zparseopts","zprof","zpty","zregexparse","zsocket","zstyle","ztcp"],k=["chcon","chgrp","chown","chmod","cp","dd","df","dir","dircolors","ln","ls","mkdir","mkfifo","mknod","mktemp","mv","realpath","rm","rmdir","shred","sync","touch","truncate","vdir","b2sum","base32","base64","cat","cksum","comm","csplit","cut","expand","fmt","fold","head","join","md5sum","nl","numfmt","od","paste","ptx","pr","sha1sum","sha224sum","sha256sum","sha384sum","sha512sum","shuf","sort","split","sum","tac","tail","tr","tsort","unexpand","uniq","wc","arch","basename","chroot","date","dirname","du","echo","env","expr","factor","groups","hostid","id","link","logname","nice","nohup","nproc","pathchk","pinky","printenv","printf","pwd","readlink","runcon","seq","sleep","stat","stdbuf","stty","tee","test","timeout","tty","uname","unlink","uptime","users","who","whoami","yes"];return{name:"Bash",aliases:["sh","zsh"],keywords:{$pattern:/\b[a-z][a-z0-9._-]+\b/,keyword:v,literal:y,built_in:[...E,...O,"set","shopt",...M,...k]},contains:[g,e.SHEBANG(),m,h,o,r,_,a,l,c,d,n]}}const No="[A-Za-z$_][0-9A-Za-z$_]*",yh=["as","in","of","if","for","while","finally","var","new","function","do","return","void","else","break","catch","instanceof","with","throw","case","default","try","switch","continue","typeof","delete","let","yield","const","class","debugger","async","await","static","import","from","export","extends","using"],xh=["true","false","null","undefined","NaN","Infinity"],ka=["Object","Function","Boolean","Symbol","Math","Date","Number","BigInt","String","RegExp","Array","Float32Array","Float64Array","Int8Array","Uint8Array","Uint8ClampedArray","Int16Array","Int32Array","Uint16Array","Uint32Array","BigInt64Array","BigUint64Array","Set","Map","WeakSet","WeakMap","ArrayBuffer","SharedArrayBuffer","Atomics","DataView","JSON","Promise","Generator","GeneratorFunction","AsyncFunction","Reflect","Proxy","Intl","WebAssembly"],Sa=["Error","EvalError","InternalError","RangeError","ReferenceError","SyntaxError","TypeError","URIError"],Ea=["setInterval","setTimeout","clearInterval","clearTimeout","require","exports","eval","isFinite","isNaN","parseFloat","parseInt","decodeURI","decodeURIComponent","encodeURI","encodeURIComponent","escape","unescape"],_h=["arguments","this","super","console","window","document","localStorage","sessionStorage","module","global"],wh=[].concat(Ea,ka,Sa);function Ta(e){const t=e.regex,n=(j,{after:J})=>{const tt="</"+j[0].slice(1);return j.input.indexOf(tt,J)!==-1},i=No,s={begin:"<>",end:"</>"},o=/<[A-Za-z0-9\\._:-]+\s*\/>/,r={begin:/<[A-Za-z0-9\\._:-]+/,end:/\/[A-Za-z0-9\\._:-]+>|\/>/,isTrulyOpeningTag:(j,J)=>{const tt=j[0].length+j.index,ht=j.input[tt];if(ht==="<"||ht===","){J.ignoreMatch();return}ht===">"&&(n(j,{after:tt})||J.ignoreMatch());let et;const kt=j.input.substring(tt);if(et=kt.match(/^\s*=/)){J.ignoreMatch();return}if((et=kt.match(/^\s+extends\s+/))&&et.index===0){J.ignoreMatch();return}}},a={$pattern:No,keyword:yh,literal:xh,built_in:wh,"variable.language":_h},l="[0-9](_?[0-9])*",c=`\\.(${l})`,d="0|[1-9](_?[0-9])*|0[0-7]*[89][0-9]*",h={className:"number",variants:[{begin:`(\\b(${d})((${c})|\\.)?|(${c}))[eE][+-]?(${l})\\b`},{begin:`\\b(${d})\\b((${c})\\b|\\.)?|(${c})\\b`},{begin:"\\b(0|[1-9](_?[0-9])*)n\\b"},{begin:"\\b0[xX][0-9a-fA-F](_?[0-9a-fA-F])*n?\\b"},{begin:"\\b0[bB][0-1](_?[0-1])*n?\\b"},{begin:"\\b0[oO][0-7](_?[0-7])*n?\\b"},{begin:"\\b0[0-7]+n?\\b"}],relevance:0},f={className:"subst",begin:"\\$\\{",end:"\\}",keywords:a,contains:[]},g={begin:".?html`",end:"",starts:{end:"`",returnEnd:!1,contains:[e.BACKSLASH_ESCAPE,f],subLanguage:"xml"}},m={begin:".?css`",end:"",starts:{end:"`",returnEnd:!1,contains:[e.BACKSLASH_ESCAPE,f],subLanguage:"css"}},v={begin:".?gql`",end:"",starts:{end:"`",returnEnd:!1,contains:[e.BACKSLASH_ESCAPE,f],subLanguage:"graphql"}},y={className:"string",begin:"`",end:"`",contains:[e.BACKSLASH_ESCAPE,f]},E={className:"comment",variants:[e.COMMENT(/\/\*\*(?!\/)/,"\\*/",{relevance:0,contains:[{begin:"(?=@[A-Za-z]+)",relevance:0,contains:[{className:"doctag",begin:"@[A-Za-z]+"},{className:"type",begin:"\\{",end:"\\}",excludeEnd:!0,excludeBegin:!0,relevance:0},{className:"variable",begin:i+"(?=\\s*(-)|$)",endsParent:!0,relevance:0},{begin:/(?=[^\n])\s/,relevance:0}]}]}),e.C_BLOCK_COMMENT_MODE,e.C_LINE_COMMENT_MODE]},O=[e.APOS_STRING_MODE,e.QUOTE_STRING_MODE,g,m,v,y,{match:/\$\d+/},h];f.contains=O.concat({begin:/\{/,end:/\}/,keywords:a,contains:["self"].concat(O)});const M=[].concat(E,f.contains),k=M.concat([{begin:/(\s*)\(/,end:/\)/,keywords:a,contains:["self"].concat(M)}]),C={className:"params",begin:/(\s*)\(/,end:/\)/,excludeBegin:!0,excludeEnd:!0,keywords:a,contains:k},A={variants:[{match:[/class/,/\s+/,i,/\s+/,/extends/,/\s+/,t.concat(i,"(",t.concat(/\./,i),")*")],scope:{1:"keyword",3:"title.class",5:"keyword",7:"title.class.inherited"}},{match:[/class/,/\s+/,i],scope:{1:"keyword",3:"title.class"}}]},P={relevance:0,match:t.either(/\bJSON/,/\b[A-Z][a-z]+([A-Z][a-z]*|\d)*/,/\b[A-Z]{2,}([A-Z][a-z]+|\d)+([A-Z][a-z]*)*/,/\b[A-Z]{2,}[a-z]+([A-Z][a-z]+|\d)*([A-Z][a-z]*)*/),className:"title.class",keywords:{_:[...ka,...Sa]}},I={label:"use_strict",className:"meta",relevance:10,begin:/^\s*['"]use (strict|asm)['"]/},z={variants:[{match:[/function/,/\s+/,i,/(?=\s*\()/]},{match:[/function/,/\s*(?=\()/]}],className:{1:"keyword",3:"title.function"},label:"func.def",contains:[C],illegal:/%/},R={relevance:0,match:/\b[A-Z][A-Z_0-9]+\b/,className:"variable.constant"};function $(j){return t.concat("(?!",j.join("|"),")")}const Z={match:t.concat(/\b/,$([...Ea,"super","import"].map(j=>`${j}\\s*\\(`)),i,t.lookahead(/\s*\(/)),className:"title.function",relevance:0},ot={begin:t.concat(/\./,t.lookahead(t.concat(i,/(?![0-9A-Za-z$_(])/))),end:i,excludeBegin:!0,keywords:"prototype",className:"property",relevance:0},V={match:[/get|set/,/\s+/,i,/(?=\()/],className:{1:"keyword",3:"title.function"},contains:[{begin:/\(\)/},C]},Y="(\\([^()]*(\\([^()]*(\\([^()]*\\)[^()]*)*\\)[^()]*)*\\)|"+e.UNDERSCORE_IDENT_RE+")\\s*=>",rt={match:[/const|var|let/,/\s+/,i,/\s*/,/=\s*/,/(async\s*)?/,t.lookahead(Y)],keywords:"async",className:{1:"keyword",3:"title.function"},contains:[C]};return{name:"JavaScript",aliases:["js","jsx","mjs","cjs"],keywords:a,exports:{PARAMS_CONTAINS:k,CLASS_REFERENCE:P},illegal:/#(?![$_A-z])/,contains:[e.SHEBANG({label:"shebang",binary:"node",relevance:5}),I,e.APOS_STRING_MODE,e.QUOTE_STRING_MODE,g,m,v,y,E,{match:/\$\d+/},h,P,{scope:"attr",match:i+t.lookahead(":"),relevance:0},rt,{begin:"("+e.RE_STARTERS_RE+"|\\b(case|return|throw)\\b)\\s*",keywords:"return throw case",relevance:0,contains:[E,e.REGEXP_MODE,{className:"function",begin:Y,returnBegin:!0,end:"\\s*=>",contains:[{className:"params",variants:[{begin:e.UNDERSCORE_IDENT_RE,relevance:0},{className:null,begin:/\(\s*\)/,skip:!0},{begin:/(\s*)\(/,end:/\)/,excludeBegin:!0,excludeEnd:!0,keywords:a,contains:k}]}]},{begin:/,/,relevance:0},{match:/\s+/,relevance:0},{variants:[{begin:s.begin,end:s.end},{match:o},{begin:r.begin,"on:begin":r.isTrulyOpeningTag,end:r.end}],subLanguage:"xml",contains:[{begin:r.begin,end:r.end,skip:!0,contains:["self"]}]}]},z,{beginKeywords:"while if switch catch for"},{begin:"\\b(?!function)"+e.UNDERSCORE_IDENT_RE+"\\([^()]*(\\([^()]*(\\([^()]*\\)[^()]*)*\\)[^()]*)*\\)\\s*\\{",returnBegin:!0,label:"func.def",contains:[C,e.inherit(e.TITLE_MODE,{begin:i,className:"title.function"})]},{match:/\.\.\./,relevance:0},ot,{match:"\\$"+i,relevance:0},{match:[/\bconstructor(?=\s*\()/],className:{1:"title.function"},contains:[C]},Z,R,A,V,{match:/\$[(.]/}]}}const gi="[A-Za-z$_][0-9A-Za-z$_]*",Ca=["as","in","of","if","for","while","finally","var","new","function","do","return","void","else","break","catch","instanceof","with","throw","case","default","try","switch","continue","typeof","delete","let","yield","const","class","debugger","async","await","static","import","from","export","extends","using"],Oa=["true","false","null","undefined","NaN","Infinity"],Ma=["Object","Function","Boolean","Symbol","Math","Date","Number","BigInt","String","RegExp","Array","Float32Array","Float64Array","Int8Array","Uint8Array","Uint8ClampedArray","Int16Array","Int32Array","Uint16Array","Uint32Array","BigInt64Array","BigUint64Array","Set","Map","WeakSet","WeakMap","ArrayBuffer","SharedArrayBuffer","Atomics","DataView","JSON","Promise","Generator","GeneratorFunction","AsyncFunction","Reflect","Proxy","Intl","WebAssembly"],Pa=["Error","EvalError","InternalError","RangeError","ReferenceError","SyntaxError","TypeError","URIError"],Aa=["setInterval","setTimeout","clearInterval","clearTimeout","require","exports","eval","isFinite","isNaN","parseFloat","parseInt","decodeURI","decodeURIComponent","encodeURI","encodeURIComponent","escape","unescape"],Da=["arguments","this","super","console","window","document","localStorage","sessionStorage","module","global"],Ia=[].concat(Aa,Ma,Pa);function kh(e){const t=e.regex,n=(j,{after:J})=>{const tt="</"+j[0].slice(1);return j.input.indexOf(tt,J)!==-1},i=gi,s={begin:"<>",end:"</>"},o=/<[A-Za-z0-9\\._:-]+\s*\/>/,r={begin:/<[A-Za-z0-9\\._:-]+/,end:/\/[A-Za-z0-9\\._:-]+>|\/>/,isTrulyOpeningTag:(j,J)=>{const tt=j[0].length+j.index,ht=j.input[tt];if(ht==="<"||ht===","){J.ignoreMatch();return}ht===">"&&(n(j,{after:tt})||J.ignoreMatch());let et;const kt=j.input.substring(tt);if(et=kt.match(/^\s*=/)){J.ignoreMatch();return}if((et=kt.match(/^\s+extends\s+/))&&et.index===0){J.ignoreMatch();return}}},a={$pattern:gi,keyword:Ca,literal:Oa,built_in:Ia,"variable.language":Da},l="[0-9](_?[0-9])*",c=`\\.(${l})`,d="0|[1-9](_?[0-9])*|0[0-7]*[89][0-9]*",h={className:"number",variants:[{begin:`(\\b(${d})((${c})|\\.)?|(${c}))[eE][+-]?(${l})\\b`},{begin:`\\b(${d})\\b((${c})\\b|\\.)?|(${c})\\b`},{begin:"\\b(0|[1-9](_?[0-9])*)n\\b"},{begin:"\\b0[xX][0-9a-fA-F](_?[0-9a-fA-F])*n?\\b"},{begin:"\\b0[bB][0-1](_?[0-1])*n?\\b"},{begin:"\\b0[oO][0-7](_?[0-7])*n?\\b"},{begin:"\\b0[0-7]+n?\\b"}],relevance:0},f={className:"subst",begin:"\\$\\{",end:"\\}",keywords:a,contains:[]},g={begin:".?html`",end:"",starts:{end:"`",returnEnd:!1,contains:[e.BACKSLASH_ESCAPE,f],subLanguage:"xml"}},m={begin:".?css`",end:"",starts:{end:"`",returnEnd:!1,contains:[e.BACKSLASH_ESCAPE,f],subLanguage:"css"}},v={begin:".?gql`",end:"",starts:{end:"`",returnEnd:!1,contains:[e.BACKSLASH_ESCAPE,f],subLanguage:"graphql"}},y={className:"string",begin:"`",end:"`",contains:[e.BACKSLASH_ESCAPE,f]},E={className:"comment",variants:[e.COMMENT(/\/\*\*(?!\/)/,"\\*/",{relevance:0,contains:[{begin:"(?=@[A-Za-z]+)",relevance:0,contains:[{className:"doctag",begin:"@[A-Za-z]+"},{className:"type",begin:"\\{",end:"\\}",excludeEnd:!0,excludeBegin:!0,relevance:0},{className:"variable",begin:i+"(?=\\s*(-)|$)",endsParent:!0,relevance:0},{begin:/(?=[^\n])\s/,relevance:0}]}]}),e.C_BLOCK_COMMENT_MODE,e.C_LINE_COMMENT_MODE]},O=[e.APOS_STRING_MODE,e.QUOTE_STRING_MODE,g,m,v,y,{match:/\$\d+/},h];f.contains=O.concat({begin:/\{/,end:/\}/,keywords:a,contains:["self"].concat(O)});const M=[].concat(E,f.contains),k=M.concat([{begin:/(\s*)\(/,end:/\)/,keywords:a,contains:["self"].concat(M)}]),C={className:"params",begin:/(\s*)\(/,end:/\)/,excludeBegin:!0,excludeEnd:!0,keywords:a,contains:k},A={variants:[{match:[/class/,/\s+/,i,/\s+/,/extends/,/\s+/,t.concat(i,"(",t.concat(/\./,i),")*")],scope:{1:"keyword",3:"title.class",5:"keyword",7:"title.class.inherited"}},{match:[/class/,/\s+/,i],scope:{1:"keyword",3:"title.class"}}]},P={relevance:0,match:t.either(/\bJSON/,/\b[A-Z][a-z]+([A-Z][a-z]*|\d)*/,/\b[A-Z]{2,}([A-Z][a-z]+|\d)+([A-Z][a-z]*)*/,/\b[A-Z]{2,}[a-z]+([A-Z][a-z]+|\d)*([A-Z][a-z]*)*/),className:"title.class",keywords:{_:[...Ma,...Pa]}},I={label:"use_strict",className:"meta",relevance:10,begin:/^\s*['"]use (strict|asm)['"]/},z={variants:[{match:[/function/,/\s+/,i,/(?=\s*\()/]},{match:[/function/,/\s*(?=\()/]}],className:{1:"keyword",3:"title.function"},label:"func.def",contains:[C],illegal:/%/},R={relevance:0,match:/\b[A-Z][A-Z_0-9]+\b/,className:"variable.constant"};function $(j){return t.concat("(?!",j.join("|"),")")}const Z={match:t.concat(/\b/,$([...Aa,"super","import"].map(j=>`${j}\\s*\\(`)),i,t.lookahead(/\s*\(/)),className:"title.function",relevance:0},ot={begin:t.concat(/\./,t.lookahead(t.concat(i,/(?![0-9A-Za-z$_(])/))),end:i,excludeBegin:!0,keywords:"prototype",className:"property",relevance:0},V={match:[/get|set/,/\s+/,i,/(?=\()/],className:{1:"keyword",3:"title.function"},contains:[{begin:/\(\)/},C]},Y="(\\([^()]*(\\([^()]*(\\([^()]*\\)[^()]*)*\\)[^()]*)*\\)|"+e.UNDERSCORE_IDENT_RE+")\\s*=>",rt={match:[/const|var|let/,/\s+/,i,/\s*/,/=\s*/,/(async\s*)?/,t.lookahead(Y)],keywords:"async",className:{1:"keyword",3:"title.function"},contains:[C]};return{name:"JavaScript",aliases:["js","jsx","mjs","cjs"],keywords:a,exports:{PARAMS_CONTAINS:k,CLASS_REFERENCE:P},illegal:/#(?![$_A-z])/,contains:[e.SHEBANG({label:"shebang",binary:"node",relevance:5}),I,e.APOS_STRING_MODE,e.QUOTE_STRING_MODE,g,m,v,y,E,{match:/\$\d+/},h,P,{scope:"attr",match:i+t.lookahead(":"),relevance:0},rt,{begin:"("+e.RE_STARTERS_RE+"|\\b(case|return|throw)\\b)\\s*",keywords:"return throw case",relevance:0,contains:[E,e.REGEXP_MODE,{className:"function",begin:Y,returnBegin:!0,end:"\\s*=>",contains:[{className:"params",variants:[{begin:e.UNDERSCORE_IDENT_RE,relevance:0},{className:null,begin:/\(\s*\)/,skip:!0},{begin:/(\s*)\(/,end:/\)/,excludeBegin:!0,excludeEnd:!0,keywords:a,contains:k}]}]},{begin:/,/,relevance:0},{match:/\s+/,relevance:0},{variants:[{begin:s.begin,end:s.end},{match:o},{begin:r.begin,"on:begin":r.isTrulyOpeningTag,end:r.end}],subLanguage:"xml",contains:[{begin:r.begin,end:r.end,skip:!0,contains:["self"]}]}]},z,{beginKeywords:"while if switch catch for"},{begin:"\\b(?!function)"+e.UNDERSCORE_IDENT_RE+"\\([^()]*(\\([^()]*(\\([^()]*\\)[^()]*)*\\)[^()]*)*\\)\\s*\\{",returnBegin:!0,label:"func.def",contains:[C,e.inherit(e.TITLE_MODE,{begin:i,className:"title.function"})]},{match:/\.\.\./,relevance:0},ot,{match:"\\$"+i,relevance:0},{match:[/\bconstructor(?=\s*\()/],className:{1:"title.function"},contains:[C]},Z,R,A,V,{match:/\$[(.]/}]}}function Ra(e){const t=e.regex,n=kh(e),i=gi,s=["any","void","number","boolean","string","object","never","symbol","bigint","unknown"],o={begin:[/namespace/,/\s+/,e.IDENT_RE],beginScope:{1:"keyword",3:"title.class"}},r={beginKeywords:"interface",end:/\{/,excludeEnd:!0,keywords:{keyword:"interface extends",built_in:s},contains:[n.exports.CLASS_REFERENCE]},a={className:"meta",relevance:10,begin:/^\s*['"]use strict['"]/},l=["type","interface","public","private","protected","implements","declare","abstract","readonly","enum","override","satisfies"],c={$pattern:gi,keyword:Ca.concat(l),literal:Oa,built_in:Ia.concat(s),"variable.language":Da},d={className:"meta",begin:"@"+i},h=(v,y,_)=>{const E=v.contains.findIndex(O=>O.label===y);if(E===-1)throw new Error("can not find mode to replace");v.contains.splice(E,1,_)};Object.assign(n.keywords,c),n.exports.PARAMS_CONTAINS.push(d);const f=n.contains.find(v=>v.scope==="attr"),g=Object.assign({},f,{match:t.concat(i,t.lookahead(/\s*\?:/))});n.exports.PARAMS_CONTAINS.push([n.exports.CLASS_REFERENCE,f,g]),n.contains=n.contains.concat([d,o,r,g]),h(n,"shebang",e.SHEBANG()),h(n,"use_strict",a);const m=n.contains.find(v=>v.label==="func.def");return m.relevance=0,Object.assign(n,{name:"TypeScript",aliases:["ts","tsx","mts","cts"]}),n}function Na(e){const t=e.regex,n=/[\p{XID_Start}_]\p{XID_Continue}*/u,i=["and","as","assert","async","await","break","case","class","continue","def","del","elif","else","except","finally","for","from","global","if","import","in","is","lambda","match","nonlocal|10","not","or","pass","raise","return","try","while","with","yield"],a={$pattern:/[A-Za-z]\w+|__\w+__/,keyword:i,built_in:["__import__","abs","all","any","ascii","bin","bool","breakpoint","bytearray","bytes","callable","chr","classmethod","compile","complex","delattr","dict","dir","divmod","enumerate","eval","exec","filter","float","format","frozenset","getattr","globals","hasattr","hash","help","hex","id","input","int","isinstance","issubclass","iter","len","list","locals","map","max","memoryview","min","next","object","oct","open","ord","pow","print","property","range","repr","reversed","round","set","setattr","slice","sorted","staticmethod","str","sum","super","tuple","type","vars","zip"],literal:["__debug__","Ellipsis","False","None","NotImplemented","True"],type:["Any","Callable","Coroutine","Dict","List","Literal","Generic","Optional","Sequence","Set","Tuple","Type","Union"]},l={className:"meta",begin:/^(>>>|\.\.\.) /},c={className:"subst",begin:/\{/,end:/\}/,keywords:a,illegal:/#/},d={begin:/\{\{/,relevance:0},h={className:"string",contains:[e.BACKSLASH_ESCAPE],variants:[{begin:/([uU]|[bB]|[rR]|[bB][rR]|[rR][bB])?'''/,end:/'''/,contains:[e.BACKSLASH_ESCAPE,l],relevance:10},{begin:/([uU]|[bB]|[rR]|[bB][rR]|[rR][bB])?"""/,end:/"""/,contains:[e.BACKSLASH_ESCAPE,l],relevance:10},{begin:/([fF][rR]|[rR][fF]|[fF])'''/,end:/'''/,contains:[e.BACKSLASH_ESCAPE,l,d,c]},{begin:/([fF][rR]|[rR][fF]|[fF])"""/,end:/"""/,contains:[e.BACKSLASH_ESCAPE,l,d,c]},{begin:/([uU]|[rR])'/,end:/'/,relevance:10},{begin:/([uU]|[rR])"/,end:/"/,relevance:10},{begin:/([bB]|[bB][rR]|[rR][bB])'/,end:/'/},{begin:/([bB]|[bB][rR]|[rR][bB])"/,end:/"/},{begin:/([fF][rR]|[rR][fF]|[fF])'/,end:/'/,contains:[e.BACKSLASH_ESCAPE,d,c]},{begin:/([fF][rR]|[rR][fF]|[fF])"/,end:/"/,contains:[e.BACKSLASH_ESCAPE,d,c]},e.APOS_STRING_MODE,e.QUOTE_STRING_MODE]},f="[0-9](_?[0-9])*",g=`(\\b(${f}))?\\.(${f})|\\b(${f})\\.`,m=`\\b|${i.join("|")}`,v={className:"number",relevance:0,variants:[{begin:`(\\b(${f})|(${g}))[eE][+-]?(${f})[jJ]?(?=${m})`},{begin:`(${g})[jJ]?`},{begin:`\\b([1-9](_?[0-9])*|0+(_?0)*)[lLjJ]?(?=${m})`},{begin:`\\b0[bB](_?[01])+[lL]?(?=${m})`},{begin:`\\b0[oO](_?[0-7])+[lL]?(?=${m})`},{begin:`\\b0[xX](_?[0-9a-fA-F])+[lL]?(?=${m})`},{begin:`\\b(${f})[jJ](?=${m})`}]},y={className:"comment",begin:t.lookahead(/# type:/),end:/$/,keywords:a,contains:[{begin:/# type:/},{begin:/#/,end:/\b\B/,endsWithParent:!0}]},_={className:"params",variants:[{className:"",begin:/\(\s*\)/,skip:!0},{begin:/\(/,end:/\)/,excludeBegin:!0,excludeEnd:!0,keywords:a,contains:["self",l,v,h,e.HASH_COMMENT_MODE]}]};return c.contains=[h,v,l],{name:"Python",aliases:["py","gyp","ipython"],unicodeRegex:!0,keywords:a,illegal:/(<\/|\?)|=>/,contains:[l,v,{scope:"variable.language",match:/\bself\b/},{beginKeywords:"if",relevance:0},{match:/\bor\b/,scope:"keyword"},h,y,e.HASH_COMMENT_MODE,{match:[/\bdef/,/\s+/,n],scope:{1:"keyword",3:"title.function"},contains:[_]},{variants:[{match:[/\bclass/,/\s+/,n,/\s*/,/\(\s*/,n,/\s*\)/]},{match:[/\bclass/,/\s+/,n]}],scope:{1:"keyword",3:"title.class",6:"title.class.inherited"}},{className:"meta",begin:/^[\t ]*@/,end:/(?=#)|$/,contains:[v,_,h]}]}}function Sh(e){const t={className:"attr",begin:/"(\\.|[^\\"\r\n])*"(?=\s*:)/,relevance:1.01},n={match:/[{}[\],:]/,className:"punctuation",relevance:0},i=["true","false","null"],s={scope:"literal",beginKeywords:i.join(" ")};return{name:"JSON",aliases:["jsonc"],keywords:{literal:i},contains:[t,n,e.QUOTE_STRING_MODE,s,e.C_NUMBER_MODE,e.C_LINE_COMMENT_MODE,e.C_BLOCK_COMMENT_MODE],illegal:"\\S"}}function La(e){const t="true false yes no null",n="[\\w#;/?:@&=+$,.~*'()[\\]]+",i={className:"attr",variants:[{begin:/[\w*@][\w*@ :()\./-]*:(?=[ \t]|$)/},{begin:/"[\w*@][\w*@ :()\./-]*":(?=[ \t]|$)/},{begin:/'[\w*@][\w*@ :()\./-]*':(?=[ \t]|$)/}]},s={className:"template-variable",variants:[{begin:/\{\{/,end:/\}\}/},{begin:/%\{/,end:/\}/}]},o={className:"string",relevance:0,begin:/'/,end:/'/,contains:[{match:/''/,scope:"char.escape",relevance:0}]},r={className:"string",relevance:0,variants:[{begin:/"/,end:/"/},{begin:/\S+/}],contains:[e.BACKSLASH_ESCAPE,s]},a=e.inherit(r,{variants:[{begin:/'/,end:/'/,contains:[{begin:/''/,relevance:0}]},{begin:/"/,end:/"/},{begin:/[^\s,{}[\]]+/}]}),f={className:"number",begin:"\\b"+"[0-9]{4}(-[0-9][0-9]){0,2}"+"([Tt \\t][0-9][0-9]?(:[0-9][0-9]){2})?"+"(\\.[0-9]*)?"+"([ \\t])*(Z|[-+][0-9][0-9]?(:[0-9][0-9])?)?"+"\\b"},g={end:",",endsWithParent:!0,excludeEnd:!0,keywords:t,relevance:0},m={begin:/\{/,end:/\}/,contains:[g],illegal:"\\n",relevance:0},v={begin:"\\[",end:"\\]",contains:[g],illegal:"\\n",relevance:0},y=[i,{className:"meta",begin:"^---\\s*$",relevance:10},{className:"string",begin:"[\\|>]([1-9]?[+-])?[ ]*\\n( +)[^ ][^\\n]*\\n(\\2[^\\n]+\\n?)*"},{begin:"<%[%=-]?",end:"[%-]?%>",subLanguage:"ruby",excludeBegin:!0,excludeEnd:!0,relevance:0},{className:"type",begin:"!\\w+!"+n},{className:"type",begin:"!<"+n+">"},{className:"type",begin:"!"+n},{className:"type",begin:"!!"+n},{className:"meta",begin:"&"+e.UNDERSCORE_IDENT_RE+"$"},{className:"meta",begin:"\\*"+e.UNDERSCORE_IDENT_RE+"$"},{className:"bullet",begin:"-(?=[ ]|$)",relevance:0},e.HASH_COMMENT_MODE,{beginKeywords:t,keywords:{literal:t}},f,{className:"number",begin:e.C_NUMBER_RE+"\\b",relevance:0},m,v,o,r],_=[...y];return _.pop(),_.push(a),g.contains=_,{name:"YAML",case_insensitive:!0,aliases:["yml"],contains:y}}function za(e){const t=e.regex,n=t.concat(/[\p{L}_]/u,t.optional(/[\p{L}0-9_.-]*:/u),/[\p{L}0-9_.-]*/u),i=/[\p{L}0-9._:-]+/u,s={className:"symbol",begin:/&[a-z]+;|&#[0-9]+;|&#x[a-f0-9]+;/},o={begin:/\s/,contains:[{className:"keyword",begin:/#?[a-z_][a-z1-9_-]+/,illegal:/\n/}]},r=e.inherit(o,{begin:/\(/,end:/\)/}),a=e.inherit(e.APOS_STRING_MODE,{className:"string"}),l=e.inherit(e.QUOTE_STRING_MODE,{className:"string"}),c={endsWithParent:!0,illegal:/</,relevance:0,contains:[{className:"attr",begin:i,relevance:0},{begin:/=\s*/,relevance:0,contains:[{className:"string",endsParent:!0,variants:[{begin:/"/,end:/"/,contains:[s]},{begin:/'/,end:/'/,contains:[s]},{begin:/[^\s"'=<>`]+/}]}]}]};return{name:"HTML, XML",aliases:["html","xhtml","rss","atom","xjb","xsd","xsl","plist","wsf","svg"],case_insensitive:!0,unicodeRegex:!0,contains:[{className:"meta",begin:/<![a-z]/,end:/>/,relevance:10,contains:[o,l,a,r,{begin:/\[/,end:/\]/,contains:[{className:"meta",begin:/<![a-z]/,end:/>/,contains:[o,r,l,a]}]}]},e.COMMENT(/<!--/,/-->/,{relevance:10}),{begin:/<!\[CDATA\[/,end:/\]\]>/,relevance:10},s,{className:"meta",end:/\?>/,variants:[{begin:/<\?xml/,relevance:10,contains:[l]},{begin:/<\?[a-z][a-z0-9]+/}]},{className:"tag",begin:/<style(?=\s|>)/,end:/>/,keywords:{name:"style"},contains:[c],starts:{end:/<\/style>/,returnEnd:!0,subLanguage:["css","xml"]}},{className:"tag",begin:/<script(?=\s|>)/,end:/>/,keywords:{name:"script"},contains:[c],starts:{end:/<\/script>/,returnEnd:!0,subLanguage:["javascript","handlebars","xml"]}},{className:"tag",begin:/<>|<\/>/},{className:"tag",begin:t.concat(/</,t.lookahead(t.concat(n,t.either(/\/>/,/>/,/\s/)))),end:/\/?>/,contains:[{className:"name",begin:n,relevance:0,starts:c}]},{className:"tag",begin:t.concat(/<\//,t.lookahead(t.concat(n,/>/))),contains:[{className:"name",begin:n,relevance:0},{begin:/>/,relevance:0,endsParent:!0}]}]}}const Eh=e=>({IMPORTANT:{scope:"meta",begin:"!important"},BLOCK_COMMENT:e.C_BLOCK_COMMENT_MODE,HEXCOLOR:{scope:"number",begin:/#(([0-9a-fA-F]{3,4})|(([0-9a-fA-F]{2}){3,4}))\b/},FUNCTION_DISPATCH:{className:"built_in",begin:/[\w-]+(?=\()/},ATTRIBUTE_SELECTOR_MODE:{scope:"selector-attr",begin:/\[/,end:/\]/,illegal:"$",contains:[e.APOS_STRING_MODE,e.QUOTE_STRING_MODE]},CSS_NUMBER_MODE:{scope:"number",begin:e.NUMBER_RE+"(%|em|ex|ch|rem|vw|vh|vmin|vmax|cm|mm|in|pt|pc|px|deg|grad|rad|turn|s|ms|Hz|kHz|dpi|dpcm|dppx)?",relevance:0},CSS_VARIABLE:{className:"attr",begin:/--[A-Za-z_][A-Za-z0-9_-]*/}}),Th=["a","abbr","address","article","aside","audio","b","blockquote","body","button","canvas","caption","cite","code","dd","del","details","dfn","div","dl","dt","em","fieldset","figcaption","figure","footer","form","h1","h2","h3","h4","h5","h6","header","hgroup","html","i","iframe","img","input","ins","kbd","label","legend","li","main","mark","menu","nav","object","ol","optgroup","option","p","picture","q","quote","samp","section","select","source","span","strong","summary","sup","table","tbody","td","textarea","tfoot","th","thead","time","tr","ul","var","video"],Ch=["defs","g","marker","mask","pattern","svg","switch","symbol","feBlend","feColorMatrix","feComponentTransfer","feComposite","feConvolveMatrix","feDiffuseLighting","feDisplacementMap","feFlood","feGaussianBlur","feImage","feMerge","feMorphology","feOffset","feSpecularLighting","feTile","feTurbulence","linearGradient","radialGradient","stop","circle","ellipse","image","line","path","polygon","polyline","rect","text","use","textPath","tspan","foreignObject","clipPath"],Oh=[...Th,...Ch],Mh=["any-hover","any-pointer","aspect-ratio","color","color-gamut","color-index","device-aspect-ratio","device-height","device-width","display-mode","forced-colors","grid","height","hover","inverted-colors","monochrome","orientation","overflow-block","overflow-inline","pointer","prefers-color-scheme","prefers-contrast","prefers-reduced-motion","prefers-reduced-transparency","resolution","scan","scripting","update","width","min-width","max-width","min-height","max-height"].sort().reverse(),Ph=["active","any-link","blank","checked","current","default","defined","dir","disabled","drop","empty","enabled","first","first-child","first-of-type","fullscreen","future","focus","focus-visible","focus-within","has","host","host-context","hover","indeterminate","in-range","invalid","is","lang","last-child","last-of-type","left","link","local-link","not","nth-child","nth-col","nth-last-child","nth-last-col","nth-last-of-type","nth-of-type","only-child","only-of-type","optional","out-of-range","past","placeholder-shown","read-only","read-write","required","right","root","scope","target","target-within","user-invalid","valid","visited","where"].sort().reverse(),Ah=["after","backdrop","before","cue","cue-region","first-letter","first-line","grammar-error","marker","part","placeholder","selection","slotted","spelling-error"].sort().reverse(),Dh=["accent-color","align-content","align-items","align-self","alignment-baseline","all","anchor-name","animation","animation-composition","animation-delay","animation-direction","animation-duration","animation-fill-mode","animation-iteration-count","animation-name","animation-play-state","animation-range","animation-range-end","animation-range-start","animation-timeline","animation-timing-function","appearance","aspect-ratio","backdrop-filter","backface-visibility","background","background-attachment","background-blend-mode","background-clip","background-color","background-image","background-origin","background-position","background-position-x","background-position-y","background-repeat","background-size","baseline-shift","block-size","border","border-block","border-block-color","border-block-end","border-block-end-color","border-block-end-style","border-block-end-width","border-block-start","border-block-start-color","border-block-start-style","border-block-start-width","border-block-style","border-block-width","border-bottom","border-bottom-color","border-bottom-left-radius","border-bottom-right-radius","border-bottom-style","border-bottom-width","border-collapse","border-color","border-end-end-radius","border-end-start-radius","border-image","border-image-outset","border-image-repeat","border-image-slice","border-image-source","border-image-width","border-inline","border-inline-color","border-inline-end","border-inline-end-color","border-inline-end-style","border-inline-end-width","border-inline-start","border-inline-start-color","border-inline-start-style","border-inline-start-width","border-inline-style","border-inline-width","border-left","border-left-color","border-left-style","border-left-width","border-radius","border-right","border-right-color","border-right-style","border-right-width","border-spacing","border-start-end-radius","border-start-start-radius","border-style","border-top","border-top-color","border-top-left-radius","border-top-right-radius","border-top-style","border-top-width","border-width","bottom","box-align","box-decoration-break","box-direction","box-flex","box-flex-group","box-lines","box-ordinal-group","box-orient","box-pack","box-shadow","box-sizing","break-after","break-before","break-inside","caption-side","caret-color","clear","clip","clip-path","clip-rule","color","color-interpolation","color-interpolation-filters","color-profile","color-rendering","color-scheme","column-count","column-fill","column-gap","column-rule","column-rule-color","column-rule-style","column-rule-width","column-span","column-width","columns","contain","contain-intrinsic-block-size","contain-intrinsic-height","contain-intrinsic-inline-size","contain-intrinsic-size","contain-intrinsic-width","container","container-name","container-type","content","content-visibility","counter-increment","counter-reset","counter-set","cue","cue-after","cue-before","cursor","cx","cy","direction","display","dominant-baseline","empty-cells","enable-background","field-sizing","fill","fill-opacity","fill-rule","filter","flex","flex-basis","flex-direction","flex-flow","flex-grow","flex-shrink","flex-wrap","float","flood-color","flood-opacity","flow","font","font-display","font-family","font-feature-settings","font-kerning","font-language-override","font-optical-sizing","font-palette","font-size","font-size-adjust","font-smooth","font-smoothing","font-stretch","font-style","font-synthesis","font-synthesis-position","font-synthesis-small-caps","font-synthesis-style","font-synthesis-weight","font-variant","font-variant-alternates","font-variant-caps","font-variant-east-asian","font-variant-emoji","font-variant-ligatures","font-variant-numeric","font-variant-position","font-variation-settings","font-weight","forced-color-adjust","gap","glyph-orientation-horizontal","glyph-orientation-vertical","grid","grid-area","grid-auto-columns","grid-auto-flow","grid-auto-rows","grid-column","grid-column-end","grid-column-start","grid-gap","grid-row","grid-row-end","grid-row-start","grid-template","grid-template-areas","grid-template-columns","grid-template-rows","hanging-punctuation","height","hyphenate-character","hyphenate-limit-chars","hyphens","icon","image-orientation","image-rendering","image-resolution","ime-mode","initial-letter","initial-letter-align","inline-size","inset","inset-area","inset-block","inset-block-end","inset-block-start","inset-inline","inset-inline-end","inset-inline-start","isolation","justify-content","justify-items","justify-self","kerning","left","letter-spacing","lighting-color","line-break","line-height","line-height-step","list-style","list-style-image","list-style-position","list-style-type","margin","margin-block","margin-block-end","margin-block-start","margin-bottom","margin-inline","margin-inline-end","margin-inline-start","margin-left","margin-right","margin-top","margin-trim","marker","marker-end","marker-mid","marker-start","marks","mask","mask-border","mask-border-mode","mask-border-outset","mask-border-repeat","mask-border-slice","mask-border-source","mask-border-width","mask-clip","mask-composite","mask-image","mask-mode","mask-origin","mask-position","mask-repeat","mask-size","mask-type","masonry-auto-flow","math-depth","math-shift","math-style","max-block-size","max-height","max-inline-size","max-width","min-block-size","min-height","min-inline-size","min-width","mix-blend-mode","nav-down","nav-index","nav-left","nav-right","nav-up","none","normal","object-fit","object-position","offset","offset-anchor","offset-distance","offset-path","offset-position","offset-rotate","opacity","order","orphans","outline","outline-color","outline-offset","outline-style","outline-width","overflow","overflow-anchor","overflow-block","overflow-clip-margin","overflow-inline","overflow-wrap","overflow-x","overflow-y","overlay","overscroll-behavior","overscroll-behavior-block","overscroll-behavior-inline","overscroll-behavior-x","overscroll-behavior-y","padding","padding-block","padding-block-end","padding-block-start","padding-bottom","padding-inline","padding-inline-end","padding-inline-start","padding-left","padding-right","padding-top","page","page-break-after","page-break-before","page-break-inside","paint-order","pause","pause-after","pause-before","perspective","perspective-origin","place-content","place-items","place-self","pointer-events","position","position-anchor","position-visibility","print-color-adjust","quotes","r","resize","rest","rest-after","rest-before","right","rotate","row-gap","ruby-align","ruby-position","scale","scroll-behavior","scroll-margin","scroll-margin-block","scroll-margin-block-end","scroll-margin-block-start","scroll-margin-bottom","scroll-margin-inline","scroll-margin-inline-end","scroll-margin-inline-start","scroll-margin-left","scroll-margin-right","scroll-margin-top","scroll-padding","scroll-padding-block","scroll-padding-block-end","scroll-padding-block-start","scroll-padding-bottom","scroll-padding-inline","scroll-padding-inline-end","scroll-padding-inline-start","scroll-padding-left","scroll-padding-right","scroll-padding-top","scroll-snap-align","scroll-snap-stop","scroll-snap-type","scroll-timeline","scroll-timeline-axis","scroll-timeline-name","scrollbar-color","scrollbar-gutter","scrollbar-width","shape-image-threshold","shape-margin","shape-outside","shape-rendering","speak","speak-as","src","stop-color","stop-opacity","stroke","stroke-dasharray","stroke-dashoffset","stroke-linecap","stroke-linejoin","stroke-miterlimit","stroke-opacity","stroke-width","tab-size","table-layout","text-align","text-align-all","text-align-last","text-anchor","text-combine-upright","text-decoration","text-decoration-color","text-decoration-line","text-decoration-skip","text-decoration-skip-ink","text-decoration-style","text-decoration-thickness","text-emphasis","text-emphasis-color","text-emphasis-position","text-emphasis-style","text-indent","text-justify","text-orientation","text-overflow","text-rendering","text-shadow","text-size-adjust","text-transform","text-underline-offset","text-underline-position","text-wrap","text-wrap-mode","text-wrap-style","timeline-scope","top","touch-action","transform","transform-box","transform-origin","transform-style","transition","transition-behavior","transition-delay","transition-duration","transition-property","transition-timing-function","translate","unicode-bidi","user-modify","user-select","vector-effect","vertical-align","view-timeline","view-timeline-axis","view-timeline-inset","view-timeline-name","view-transition-name","visibility","voice-balance","voice-duration","voice-family","voice-pitch","voice-range","voice-rate","voice-stress","voice-volume","white-space","white-space-collapse","widows","width","will-change","word-break","word-spacing","word-wrap","writing-mode","x","y","z-index","zoom"].sort().reverse();function Ih(e){const t=e.regex,n=Eh(e),i={begin:/-(webkit|moz|ms|o)-(?=[a-z])/},s="and or not only",o=/@-?\w[\w]*(-\w+)*/,r="[a-zA-Z-][a-zA-Z0-9_-]*",a=[e.APOS_STRING_MODE,e.QUOTE_STRING_MODE];return{name:"CSS",case_insensitive:!0,illegal:/[=|'\$]/,keywords:{keyframePosition:"from to"},classNameAliases:{keyframePosition:"selector-tag"},contains:[n.BLOCK_COMMENT,i,n.CSS_NUMBER_MODE,{className:"selector-id",begin:/#[A-Za-z0-9_-]+/,relevance:0},{className:"selector-class",begin:"\\."+r,relevance:0},n.ATTRIBUTE_SELECTOR_MODE,{className:"selector-pseudo",variants:[{begin:":("+Ph.join("|")+")"},{begin:":(:)?("+Ah.join("|")+")"}]},n.CSS_VARIABLE,{className:"attribute",begin:"\\b("+Dh.join("|")+")\\b"},{begin:/:/,end:/[;}{]/,contains:[n.BLOCK_COMMENT,n.HEXCOLOR,n.IMPORTANT,n.CSS_NUMBER_MODE,...a,{begin:/(url|data-uri)\(/,end:/\)/,relevance:0,keywords:{built_in:"url data-uri"},contains:[...a,{className:"string",begin:/[^)]/,endsWithParent:!0,excludeEnd:!0}]},n.FUNCTION_DISPATCH]},{begin:t.lookahead(/@/),end:"[{;]",relevance:0,illegal:/:/,contains:[{className:"keyword",begin:o},{begin:/\s/,endsWithParent:!0,excludeEnd:!0,relevance:0,keywords:{$pattern:/[a-z-]+/,keyword:s,attribute:Mh.join(" ")},contains:[{begin:/[a-z-]+(?=:)/,className:"attribute"},...a,n.CSS_NUMBER_MODE]}]},{className:"selector-tag",begin:"\\b("+Oh.join("|")+")\\b"}]}}function Rh(e){const t=e.regex,n=e.COMMENT("--","$"),i={scope:"string",variants:[{begin:/'/,end:/'/,contains:[{match:/''/}]}]},s={begin:/"/,end:/"/,contains:[{match:/""/}]},o=["true","false","unknown"],r=["double precision","large object","with timezone","without timezone"],a=["bigint","binary","blob","boolean","char","character","clob","date","dec","decfloat","decimal","float","int","integer","interval","nchar","nclob","national","numeric","real","row","smallint","time","timestamp","varchar","varying","varbinary"],l=["add","asc","collation","desc","final","first","last","view"],c=["abs","acos","all","allocate","alter","and","any","are","array","array_agg","array_max_cardinality","as","asensitive","asin","asymmetric","at","atan","atomic","authorization","avg","begin","begin_frame","begin_partition","between","bigint","binary","blob","boolean","both","by","call","called","cardinality","cascaded","case","cast","ceil","ceiling","char","char_length","character","character_length","check","classifier","clob","close","coalesce","collate","collect","column","commit","condition","connect","constraint","contains","convert","copy","corr","corresponding","cos","cosh","count","covar_pop","covar_samp","create","cross","cube","cume_dist","current","current_catalog","current_date","current_default_transform_group","current_path","current_role","current_row","current_schema","current_time","current_timestamp","current_path","current_role","current_transform_group_for_type","current_user","cursor","cycle","date","day","deallocate","dec","decimal","decfloat","declare","default","define","delete","dense_rank","deref","describe","deterministic","disconnect","distinct","double","drop","dynamic","each","element","else","empty","end","end_frame","end_partition","end-exec","equals","escape","every","except","exec","execute","exists","exp","external","extract","false","fetch","filter","first_value","float","floor","for","foreign","frame_row","free","from","full","function","fusion","get","global","grant","group","grouping","groups","having","hold","hour","identity","in","indicator","initial","inner","inout","insensitive","insert","int","integer","intersect","intersection","interval","into","is","join","json_array","json_arrayagg","json_exists","json_object","json_objectagg","json_query","json_table","json_table_primitive","json_value","lag","language","large","last_value","lateral","lead","leading","left","like","like_regex","listagg","ln","local","localtime","localtimestamp","log","log10","lower","match","match_number","match_recognize","matches","max","member","merge","method","min","minute","mod","modifies","module","month","multiset","national","natural","nchar","nclob","new","no","none","normalize","not","nth_value","ntile","null","nullif","numeric","octet_length","occurrences_regex","of","offset","old","omit","on","one","only","open","or","order","out","outer","over","overlaps","overlay","parameter","partition","pattern","per","percent","percent_rank","percentile_cont","percentile_disc","period","portion","position","position_regex","power","precedes","precision","prepare","primary","procedure","ptf","range","rank","reads","real","recursive","ref","references","referencing","regr_avgx","regr_avgy","regr_count","regr_intercept","regr_r2","regr_slope","regr_sxx","regr_sxy","regr_syy","release","result","return","returns","revoke","right","rollback","rollup","row","row_number","rows","running","savepoint","scope","scroll","search","second","seek","select","sensitive","session_user","set","show","similar","sin","sinh","skip","smallint","some","specific","specifictype","sql","sqlexception","sqlstate","sqlwarning","sqrt","start","static","stddev_pop","stddev_samp","submultiset","subset","substring","substring_regex","succeeds","sum","symmetric","system","system_time","system_user","table","tablesample","tan","tanh","then","time","timestamp","timezone_hour","timezone_minute","to","trailing","translate","translate_regex","translation","treat","trigger","trim","trim_array","true","truncate","uescape","union","unique","unknown","unnest","update","upper","user","using","value","values","value_of","var_pop","var_samp","varbinary","varchar","varying","versioning","when","whenever","where","width_bucket","window","with","within","without","year"],d=["abs","acos","array_agg","asin","atan","avg","cast","ceil","ceiling","coalesce","corr","cos","cosh","count","covar_pop","covar_samp","cume_dist","dense_rank","deref","element","exp","extract","first_value","floor","json_array","json_arrayagg","json_exists","json_object","json_objectagg","json_query","json_table","json_table_primitive","json_value","lag","last_value","lead","listagg","ln","log","log10","lower","max","min","mod","nth_value","ntile","nullif","percent_rank","percentile_cont","percentile_disc","position","position_regex","power","rank","regr_avgx","regr_avgy","regr_count","regr_intercept","regr_r2","regr_slope","regr_sxx","regr_sxy","regr_syy","row_number","sin","sinh","sqrt","stddev_pop","stddev_samp","substring","substring_regex","sum","tan","tanh","translate","translate_regex","treat","trim","trim_array","unnest","upper","value_of","var_pop","var_samp","width_bucket"],h=["current_catalog","current_date","current_default_transform_group","current_path","current_role","current_schema","current_transform_group_for_type","current_user","session_user","system_time","system_user","current_time","localtime","current_timestamp","localtimestamp"],f=["create table","insert into","primary key","foreign key","not null","alter table","add constraint","grouping sets","on overflow","character set","respect nulls","ignore nulls","nulls first","nulls last","depth first","breadth first"],g=d,m=[...c,...l].filter(k=>!d.includes(k)),v={scope:"variable",match:/@[a-z0-9][a-z0-9_]*/},y={scope:"operator",match:/[-+*/=%^~]|&&?|\|\|?|!=?|<(?:=>?|<|>)?|>[>=]?/,relevance:0},_={match:t.concat(/\b/,t.either(...g),/\s*\(/),relevance:0,keywords:{built_in:g}};function E(k){return t.concat(/\b/,t.either(...k.map(C=>C.replace(/\s+/,"\\s+"))),/\b/)}const O={scope:"keyword",match:E(f),relevance:0};function M(k,{exceptions:C,when:A}={}){const P=A;return C=C||[],k.map(I=>I.match(/\|\d+$/)||C.includes(I)?I:P(I)?`${I}|0`:I)}return{name:"SQL",case_insensitive:!0,illegal:/[{}]|<\//,keywords:{$pattern:/\b[\w\.]+/,keyword:M(m,{when:k=>k.length<3}),literal:o,type:a,built_in:h},contains:[{scope:"type",match:E(r)},O,_,v,i,s,e.C_NUMBER_MODE,e.C_BLOCK_COMMENT_MODE,n,y]}}function $a(e){const t=e.regex,n={begin:/<\/?[A-Za-z_]/,end:">",subLanguage:"xml",relevance:0},i={begin:"^[-\\*]{3,}",end:"$"},s={className:"code",variants:[{begin:"(`{3,})[^`](.|\\n)*?\\1`*[ ]*"},{begin:"(~{3,})[^~](.|\\n)*?\\1~*[ ]*"},{begin:"```",end:"```+[ ]*$"},{begin:"~~~",end:"~~~+[ ]*$"},{begin:"`.+?`"},{begin:"(?=^( {4}|\\t))",contains:[{begin:"^( {4}|\\t)",end:"(\\n)$"}],relevance:0}]},o={className:"bullet",begin:"^[ 	]*([*+-]|(\\d+\\.))(?=\\s+)",end:"\\s+",excludeEnd:!0},r={begin:/^\[[^\n]+\]:/,returnBegin:!0,contains:[{className:"symbol",begin:/\[/,end:/\]/,excludeBegin:!0,excludeEnd:!0},{className:"link",begin:/:\s*/,end:/$/,excludeBegin:!0}]},a=/[A-Za-z][A-Za-z0-9+.-]*/,l={variants:[{begin:/\[.+?\]\[.*?\]/,relevance:0},{begin:/\[.+?\]\(((data|javascript|mailto):|(?:http|ftp)s?:\/\/).*?\)/,relevance:2},{begin:t.concat(/\[.+?\]\(/,a,/:\/\/.*?\)/),relevance:2},{begin:/\[.+?\]\([./?&#].*?\)/,relevance:1},{begin:/\[.*?\]\(.*?\)/,relevance:0}],returnBegin:!0,contains:[{match:/\[(?=\])/},{className:"string",relevance:0,begin:"\\[",end:"\\]",excludeBegin:!0,returnEnd:!0},{className:"link",relevance:0,begin:"\\]\\(",end:"\\)",excludeBegin:!0,excludeEnd:!0},{className:"symbol",relevance:0,begin:"\\]\\[",end:"\\]",excludeBegin:!0,excludeEnd:!0}]},c={className:"strong",contains:[],variants:[{begin:/_{2}(?!\s)/,end:/_{2}/},{begin:/\*{2}(?!\s)/,end:/\*{2}/}]},d={className:"emphasis",contains:[],variants:[{begin:/\*(?![*\s])/,end:/\*/},{begin:/_(?![_\s])/,end:/_/,relevance:0}]},h=e.inherit(c,{contains:[]}),f=e.inherit(d,{contains:[]});c.contains.push(f),d.contains.push(h);let g=[n,l];return[c,d,h,f].forEach(_=>{_.contains=_.contains.concat(g)}),g=g.concat(c,d),{name:"Markdown",aliases:["md","mkdown","mkd"],contains:[{className:"section",variants:[{begin:"^#{1,6}",end:"$",contains:g},{begin:"(?=^.+?\\n[=-]{2,}$)",contains:[{begin:"^[=-]*$"},{begin:"^",end:"\\n",contains:g}]}]},n,o,c,d,{className:"quote",begin:"^>\\s+",contains:g,end:"$"},s,i,l,r,{scope:"literal",match:/&([a-zA-Z0-9]+|#[0-9]{1,7}|#[Xx][0-9a-fA-F]{1,6});/}]}}function Nh(e){const o={keyword:["break","case","chan","const","continue","default","defer","else","fallthrough","for","func","go","goto","if","import","interface","map","package","range","return","select","struct","switch","type","var"],type:["bool","byte","complex64","complex128","error","float32","float64","int8","int16","int32","int64","string","uint8","uint16","uint32","uint64","int","uint","uintptr","rune"],literal:["true","false","iota","nil"],built_in:["append","cap","close","complex","copy","imag","len","make","new","panic","print","println","real","recover","delete"]};return{name:"Go",aliases:["golang"],keywords:o,illegal:"</",contains:[e.C_LINE_COMMENT_MODE,e.C_BLOCK_COMMENT_MODE,{className:"string",variants:[e.QUOTE_STRING_MODE,e.APOS_STRING_MODE,{begin:"`",end:"`"}]},{className:"number",variants:[{match:/-?\b0[xX]\.[a-fA-F0-9](_?[a-fA-F0-9])*[pP][+-]?\d(_?\d)*i?/,relevance:0},{match:/-?\b0[xX](_?[a-fA-F0-9])+((\.([a-fA-F0-9](_?[a-fA-F0-9])*)?)?[pP][+-]?\d(_?\d)*)?i?/,relevance:0},{match:/-?\b0[oO](_?[0-7])*i?/,relevance:0},{match:/-?\.\d(_?\d)*([eE][+-]?\d(_?\d)*)?i?/,relevance:0},{match:/-?\b\d(_?\d)*(\.(\d(_?\d)*)?)?([eE][+-]?\d(_?\d)*)?i?/,relevance:0}]},{begin:/:=/},{className:"function",beginKeywords:"func",end:"\\s*(\\{|$)",excludeEnd:!0,contains:[e.TITLE_MODE,{className:"params",begin:/\(/,end:/\)/,endsParent:!0,keywords:o,illegal:/["']/}]}]}}function Lh(e){const t=e.regex,n=/(r#)?/,i=t.concat(n,e.UNDERSCORE_IDENT_RE),s=t.concat(n,e.IDENT_RE),o={className:"title.function.invoke",relevance:0,begin:t.concat(/\b/,/(?!let|for|while|if|else|match\b)/,s,t.lookahead(/\s*\(/))},r="([ui](8|16|32|64|128|size)|f(32|64))?",a=["abstract","as","async","await","become","box","break","const","continue","crate","do","dyn","else","enum","extern","false","final","fn","for","if","impl","in","let","loop","macro","match","mod","move","mut","override","priv","pub","ref","return","self","Self","static","struct","super","trait","true","try","type","typeof","union","unsafe","unsized","use","virtual","where","while","yield"],l=["true","false","Some","None","Ok","Err"],c=["drop ","Copy","Send","Sized","Sync","Drop","Fn","FnMut","FnOnce","ToOwned","Clone","Debug","PartialEq","PartialOrd","Eq","Ord","AsRef","AsMut","Into","From","Default","Iterator","Extend","IntoIterator","DoubleEndedIterator","ExactSizeIterator","SliceConcatExt","ToString","assert!","assert_eq!","bitflags!","bytes!","cfg!","col!","concat!","concat_idents!","debug_assert!","debug_assert_eq!","env!","eprintln!","panic!","file!","format!","format_args!","include_bytes!","include_str!","line!","local_data_key!","module_path!","option_env!","print!","println!","select!","stringify!","try!","unimplemented!","unreachable!","vec!","write!","writeln!","macro_rules!","assert_ne!","debug_assert_ne!"],d=["i8","i16","i32","i64","i128","isize","u8","u16","u32","u64","u128","usize","f32","f64","str","char","bool","Box","Option","Result","String","Vec"];return{name:"Rust",aliases:["rs"],keywords:{$pattern:e.IDENT_RE+"!?",type:d,keyword:a,literal:l,built_in:c},illegal:"</",contains:[e.C_LINE_COMMENT_MODE,e.COMMENT("/\\*","\\*/",{contains:["self"]}),e.inherit(e.QUOTE_STRING_MODE,{begin:/b?"/,illegal:null}),{className:"symbol",begin:/'[a-zA-Z_][a-zA-Z0-9_]*(?!')/},{scope:"string",variants:[{begin:/b?r(#*)"(.|\n)*?"\1(?!#)/},{begin:/b?'/,end:/'/,contains:[{scope:"char.escape",match:/\\('|\w|x\w{2}|u\w{4}|U\w{8})/}]}]},{className:"number",variants:[{begin:"\\b0b([01_]+)"+r},{begin:"\\b0o([0-7_]+)"+r},{begin:"\\b0x([A-Fa-f0-9_]+)"+r},{begin:"\\b(\\d[\\d_]*(\\.[0-9_]+)?([eE][+-]?[0-9_]+)?)"+r}],relevance:0},{begin:[/fn/,/\s+/,i],className:{1:"keyword",3:"title.function"}},{className:"meta",begin:"#!?\\[",end:"\\]",contains:[{className:"string",begin:/"/,end:/"/,contains:[e.BACKSLASH_ESCAPE]}]},{begin:[/let/,/\s+/,/(?:mut\s+)?/,i],className:{1:"keyword",3:"keyword",4:"variable"}},{begin:[/for/,/\s+/,i,/\s+/,/in/],className:{1:"keyword",3:"variable",5:"keyword"}},{begin:[/type/,/\s+/,i],className:{1:"keyword",3:"title.class"}},{begin:[/(?:trait|enum|struct|union|impl|for)/,/\s+/,i],className:{1:"keyword",3:"title.class"}},{begin:e.IDENT_RE+"::",keywords:{keyword:"Self",built_in:c,type:d}},{className:"punctuation",begin:"->"},o]}}var zh=Object.defineProperty,$h=Object.getOwnPropertyDescriptor,Fa=(e,t,n,i)=>{for(var s=i>1?void 0:i?$h(t,n):t,o=e.length-1,r;o>=0;o--)(r=e[o])&&(s=(i?r(t,n,s):r(s))||s);return i&&s&&zh(t,n,s),s};K.registerLanguage("bash",Us);K.registerLanguage("sh",Us);K.registerLanguage("shell",Us);K.registerLanguage("javascript",Ta);K.registerLanguage("js",Ta);K.registerLanguage("typescript",Ra);K.registerLanguage("ts",Ra);K.registerLanguage("python",Na);K.registerLanguage("py",Na);K.registerLanguage("json",Sh);K.registerLanguage("yaml",La);K.registerLanguage("yml",La);K.registerLanguage("xml",za);K.registerLanguage("html",za);K.registerLanguage("css",Ih);K.registerLanguage("sql",Rh);K.registerLanguage("markdown",$a);K.registerLanguage("md",$a);K.registerLanguage("go",Nh);K.registerLanguage("rust",Lh);const Ba=new Sc(Ec({langPrefix:"hljs language-",highlight(e,t){if(t&&K.getLanguage(t))try{return K.highlight(e,{language:t}).value}catch{}return K.highlightAuto(e).value}}));Ba.setOptions({breaks:!0,gfm:!0});let mi=class extends it{constructor(){super(...arguments),this.content=""}renderMarkdown(){if(!this.content)return"";const e=Ba.parse(this.content);return Tc.sanitize(e)}render(){return S`<div class="md">${vh(this.renderMarkdown())}</div>`}};mi.styles=at`
    :host {
      display: block;
      line-height: var(--line-height);
      color: var(--text-primary);
      word-wrap: break-word;
      overflow-wrap: break-word;
    }

    .md h1,
    .md h2,
    .md h3,
    .md h4 {
      margin-top: 1.2em;
      margin-bottom: 0.4em;
      font-weight: var(--font-weight-bold);
      line-height: 1.3;
    }

    .md h1 {
      font-size: var(--md-h1-size, 1.5em);
    }
    .md h2 {
      font-size: var(--md-h2-size, 1.3em);
    }
    .md h3 {
      font-size: var(--md-h3-size, 1.15em);
    }
    .md h4 {
      font-size: var(--md-h4-size, 1em);
    }

    .md h1:first-child,
    .md h2:first-child,
    .md h3:first-child {
      margin-top: 0;
    }

    .md p {
      margin: 0.6em 0;
    }

    .md p:first-child {
      margin-top: 0;
    }

    .md p:last-child {
      margin-bottom: 0;
    }

    .md ul,
    .md ol {
      margin: 0.6em 0;
      padding-left: 1.5em;
    }

    .md li {
      margin: 0.2em 0;
    }

    .md code {
      font-family: var(--font-mono);
      font-size: 0.9em;
      padding: 0.15em 0.4em;
      border-radius: var(--radius-xs);
      background: var(--bg-code);
      color: var(--text-code);
    }

    .md pre {
      margin: 0.8em 0;
      padding: 14px 16px;
      border-radius: var(--radius-sm);
      background: var(--bg-code);
      overflow-x: auto;
      font-size: 0.88em;
      line-height: 1.5;
    }

    .md pre code {
      padding: 0;
      background: none;
      color: var(--text-primary);
      font-size: inherit;
    }

    .md blockquote {
      margin: 0.8em 0;
      padding: 0.4em 1em;
      border-left: 3px solid var(--accent-primary);
      color: var(--text-secondary);
      background: var(--bg-tertiary);
      border-radius: 0 var(--radius-xs) var(--radius-xs) 0;
    }

    .md table {
      width: 100%;
      border-collapse: collapse;
      margin: 0.8em 0;
      font-size: var(--font-size-sm);
    }

    .md th,
    .md td {
      padding: 8px 12px;
      text-align: left;
      border-bottom: 1px solid var(--border-secondary);
    }

    .md th {
      font-weight: var(--font-weight-bold);
      color: var(--text-secondary);
      border-bottom-color: var(--border-primary);
    }

    .md a {
      color: var(--accent-info);
      text-decoration: none;
    }

    .md a:hover {
      text-decoration: underline;
    }

    .md hr {
      margin: 1.2em 0;
      border: none;
      border-top: 1px solid var(--border-secondary);
    }

    .md img {
      max-width: 100%;
      border-radius: var(--radius-sm);
    }

    /* highlight.js theme integration */
    .md .hljs-keyword,
    .md .hljs-selector-tag,
    .md .hljs-built_in,
    .md .hljs-name,
    .md .hljs-tag {
      color: var(--accent-primary);
    }
    .md .hljs-string,
    .md .hljs-title,
    .md .hljs-section,
    .md .hljs-attribute,
    .md .hljs-literal,
    .md .hljs-template-tag,
    .md .hljs-template-variable,
    .md .hljs-type,
    .md .hljs-addition {
      color: var(--accent-success);
    }
    .md .hljs-comment,
    .md .hljs-quote,
    .md .hljs-deletion,
    .md .hljs-meta {
      color: var(--text-tertiary);
    }
    .md .hljs-number,
    .md .hljs-regexp,
    .md .hljs-literal,
    .md .hljs-bullet,
    .md .hljs-link {
      color: var(--accent-info);
    }
    .md .hljs-emphasis {
      font-style: italic;
    }
    .md .hljs-strong {
      font-weight: var(--font-weight-bold);
    }
  `;Fa([Wt({type:String})],mi.prototype,"content",2);mi=Fa([st("markdown-renderer")],mi);const Ha=at`
  :host {
    display: block;
  }

  .chips {
    display: flex;
    flex-wrap: wrap;
    gap: 6px;
  }

  .chip {
    display: inline-flex;
    align-items: center;
    gap: 4px;
    padding: 4px 10px;
    border-radius: var(--radius-full);
    font-size: var(--font-size-xs);
    border: 1px solid var(--border-primary);
    background: var(--bg-primary);
    color: var(--text-secondary);
    cursor: pointer;
    transition: all var(--transition-fast);
    white-space: nowrap;
  }

  .chip:hover {
    background: var(--bg-hover);
    color: var(--text-primary);
  }

  .chip.active {
    background: var(--accent-primary);
    color: var(--text-inverse);
    border-color: var(--accent-primary);
  }

  .chip.active:hover {
    background: var(--accent-hover);
  }

  .chip:disabled {
    opacity: 0.5;
    cursor: wait;
  }

  .chip .dot {
    width: 6px;
    height: 6px;
    border-radius: 50%;
    background: currentColor;
    opacity: 0.6;
  }

  .empty {
    font-size: var(--font-size-sm);
    color: var(--text-tertiary);
    padding: 4px 0;
  }
`;var Fh=Object.defineProperty,Bh=Object.getOwnPropertyDescriptor,Ws=(e,t,n,i)=>{for(var s=i>1?void 0:i?Bh(t,n):t,o=e.length-1,r;o>=0;o--)(r=e[o])&&(s=(i?r(t,n,s):r(s))||s);return i&&s&&Fh(t,n,s),s};let _n=class extends it{constructor(){super(...arguments),this.available=[],this.active=[]}connectedCallback(){super.connectedCallback(),this.unsubscribe=w.subscribe(()=>{this.available=w.state.availableSkills,this.active=w.state.activeSkills}),this.available=w.state.availableSkills,this.active=w.state.activeSkills}disconnectedCallback(){super.disconnectedCallback(),this.unsubscribe?.()}toggle(e){w.toggleSkill(e)}render(){return this.available.length?S`
      <div class="chips">
        ${this.available.map(e=>{const t=this.active.includes(e.name);return S`
            <button
              class="chip ${t?"active":""}"
              @click=${()=>this.toggle(e.name)}
              title=${e.description}
            >
              ${t?S`<span class="dot"></span>`:""} ${e.name}
            </button>
          `})}
      </div>
    `:S`<div class="empty">No skills loaded</div>`}};_n.styles=Ha;Ws([L()],_n.prototype,"available",2);Ws([L()],_n.prototype,"active",2);_n=Ws([st("skill-selector")],_n);var Hh=Object.defineProperty,Uh=Object.getOwnPropertyDescriptor,Ii=(e,t,n,i)=>{for(var s=i>1?void 0:i?Uh(t,n):t,o=e.length-1,r;o>=0;o--)(r=e[o])&&(s=(i?r(t,n,s):r(s))||s);return i&&s&&Hh(t,n,s),s};let We=class extends it{constructor(){super(...arguments),this.context={},this.newKey="",this.newValue=""}connectedCallback(){super.connectedCallback(),this.unsubscribe=w.subscribe(()=>{this.context=w.state.context}),this.context=w.state.context}disconnectedCallback(){super.disconnectedCallback(),this.unsubscribe?.()}removeKey(e){w.removeContext(e)}add(){const e=this.newKey.trim(),t=this.newValue.trim();!e||!t||(w.setContext(e,t),this.newKey="",this.newValue="")}onKeyDown(e){e.key==="Enter"&&this.add()}render(){const e=Object.entries(this.context);return S`
      ${e.length?S`
            <div class="entries">
              ${e.map(([t,n])=>S`
                  <div class="entry">
                    <span class="entry-key">${t}</span>
                    <span class="entry-value">${n}</span>
                    <button
                      class="remove-btn"
                      @click=${()=>this.removeKey(t)}
                      title="Remove ${t}"
                    >
                      <svg
                        viewBox="0 0 24 24"
                        fill="none"
                        stroke="currentColor"
                        stroke-width="2"
                        stroke-linecap="round"
                        stroke-linejoin="round"
                      >
                        <line x1="18" y1="6" x2="6" y2="18" />
                        <line x1="6" y1="6" x2="18" y2="18" />
                      </svg>
                    </button>
                  </div>
                `)}
            </div>
          `:S`<div class="empty">No context set</div>`}

      <div class="add-row">
        <input
          type="text"
          placeholder="key"
          .value=${this.newKey}
          @input=${t=>this.newKey=t.target.value}
          @keydown=${this.onKeyDown}
        />
        <input
          type="text"
          placeholder="value"
          .value=${this.newValue}
          @input=${t=>this.newValue=t.target.value}
          @keydown=${this.onKeyDown}
        />
        <button class="add-btn" @click=${this.add}>Add</button>
      </div>
    `}};We.styles=at`
    :host {
      display: block;
    }

    .entries {
      display: flex;
      flex-direction: column;
      gap: 4px;
      margin-bottom: 8px;
    }

    .entry {
      display: flex;
      align-items: center;
      gap: 6px;
      font-size: var(--font-size-sm);
      padding: 4px 8px;
      border-radius: var(--radius-xs);
      background: var(--bg-tertiary);
    }

    .entry-key {
      font-weight: var(--font-weight-medium);
      color: var(--text-primary);
    }

    .entry-value {
      color: var(--text-secondary);
      flex: 1;
      overflow: hidden;
      text-overflow: ellipsis;
      white-space: nowrap;
    }

    .remove-btn {
      display: flex;
      align-items: center;
      justify-content: center;
      width: 20px;
      height: 20px;
      border: none;
      background: none;
      border-radius: var(--radius-xs);
      color: var(--text-tertiary);
      cursor: pointer;
      flex-shrink: 0;
      transition:
        color var(--transition-fast),
        background var(--transition-fast);
    }

    .remove-btn:hover {
      color: var(--accent-danger);
      background: var(--bg-hover);
    }

    .remove-btn svg {
      width: 12px;
      height: 12px;
    }

    .add-row {
      display: flex;
      gap: 6px;
    }

    .add-row input {
      flex: 1;
      padding: 6px 8px;
      border: 1px solid var(--border-primary);
      border-radius: var(--radius-xs);
      background: var(--bg-input);
      font-size: var(--font-size-sm);
      min-width: 0;
    }

    .add-row input::placeholder {
      color: var(--text-tertiary);
    }

    .add-btn {
      padding: 6px 10px;
      border: none;
      border-radius: var(--radius-xs);
      background: var(--bg-tertiary);
      color: var(--text-secondary);
      font-size: var(--font-size-sm);
      cursor: pointer;
      white-space: nowrap;
      transition:
        background var(--transition-fast),
        color var(--transition-fast);
    }

    .add-btn:hover {
      background: var(--bg-hover);
      color: var(--text-primary);
    }

    .empty {
      font-size: var(--font-size-sm);
      color: var(--text-tertiary);
      padding: 4px 0;
    }
  `;Ii([L()],We.prototype,"context",2);Ii([L()],We.prototype,"newKey",2);Ii([L()],We.prototype,"newValue",2);We=Ii([st("context-editor")],We);var Wh=Object.defineProperty,jh=Object.getOwnPropertyDescriptor,js=(e,t,n,i)=>{for(var s=i>1?void 0:i?jh(t,n):t,o=e.length-1,r;o>=0;o--)(r=e[o])&&(s=(i?r(t,n,s):r(s))||s);return i&&s&&Wh(t,n,s),s};let wn=class extends it{constructor(){super(...arguments),this.models=[],this.current=""}connectedCallback(){super.connectedCallback(),this.unsubscribe=w.subscribe(()=>{this.models=w.state.availableModels,this.current=w.state.model}),this.models=w.state.availableModels,this.current=w.state.model}disconnectedCallback(){super.disconnectedCallback(),this.unsubscribe?.()}async onChange(e){const n=e.target.value;if(!(!n||n===this.current))try{const i=await Fc(n);w.update({model:i.model,contextWindow:i.context_window})}catch(i){w.update({error:i.message})}}render(){return this.models.length?S`
      <select .value=${this.current} @change=${this.onChange}>
        ${this.models.map(e=>S`<option value=${e} ?selected=${e===this.current}>${e}</option>`)}
      </select>
    `:S`<div class="empty">No models available</div>`}};wn.styles=at`
    :host {
      display: block;
    }

    select {
      width: 100%;
      padding: 8px 10px;
      border: 1px solid var(--border-primary);
      border-radius: var(--radius-sm);
      background: var(--bg-input);
      color: var(--text-primary);
      font-size: var(--font-size-sm);
      cursor: pointer;
      appearance: auto;
    }

    select:focus {
      outline: 2px solid var(--accent-primary);
      outline-offset: -1px;
    }

    .empty {
      font-size: var(--font-size-sm);
      color: var(--text-tertiary);
      padding: 4px 0;
    }
  `;js([L()],wn.prototype,"models",2);js([L()],wn.prototype,"current",2);wn=js([st("model-selector")],wn);var Vh=Object.defineProperty,Yh=Object.getOwnPropertyDescriptor,Vs=(e,t,n,i)=>{for(var s=i>1?void 0:i?Yh(t,n):t,o=e.length-1,r;o>=0;o--)(r=e[o])&&(s=(i?r(t,n,s):r(s))||s);return i&&s&&Vh(t,n,s),s};let kn=class extends it{constructor(){super(...arguments),this.servers=[],this.busy=!1}connectedCallback(){super.connectedCallback(),this.unsubscribe=w.subscribe(()=>{this.servers=w.state.mcpServers}),this.servers=w.state.mcpServers}disconnectedCallback(){super.disconnectedCallback(),this.unsubscribe?.()}async toggle(e){if(!this.busy){this.busy=!0;try{const t=e.connected?await Wc(e.name):await ga(e.name);w.update({mcpServers:t.servers,toolCount:t.tools});const i=[...await fs(),...pa],s=w.state.toolPolicies,o={};for(const r of i)o[r.name]=s[r.name]??Fe(r.name);w.update({availableTools:i,toolPolicies:o})}catch(t){w.update({error:t.message})}finally{this.busy=!1}}}render(){return this.servers.length?S`
      <div class="chips">
        ${this.servers.map(e=>S`
            <button
              class="chip ${e.connected?"active":""}"
              ?disabled=${this.busy}
              @click=${()=>this.toggle(e)}
              title=${e.url}
            >
              ${e.connected?S`<span class="dot"></span>`:""} ${e.name}
            </button>
          `)}
      </div>
    `:S`<div class="empty">No MCP servers configured</div>`}};kn.styles=Ha;Vs([L()],kn.prototype,"servers",2);Vs([L()],kn.prototype,"busy",2);kn=Vs([st("mcp-manager")],kn);var Gh=Object.defineProperty,Kh=Object.getOwnPropertyDescriptor,Ys=(e,t,n,i)=>{for(var s=i>1?void 0:i?Kh(t,n):t,o=e.length-1,r;o>=0;o--)(r=e[o])&&(s=(i?r(t,n,s):r(s))||s);return i&&s&&Gh(t,n,s),s};let Sn=class extends it{constructor(){super(...arguments),this.open=!1,this.currentTheme=Ne.name,this.outsideClickHandler=e=>{this.open&&(e.composedPath().includes(this)||(this.open=!1))},this.swatchColors={light:["#FAF9F5","#AE5630"],dark:["#1A1918","#D4703C"],"rh-light":["#ffffff","#a60000"],"rh-dark":["#151515","#f56e6e"]}}connectedCallback(){super.connectedCallback(),document.addEventListener("click",this.outsideClickHandler,!0)}disconnectedCallback(){super.disconnectedCallback(),document.removeEventListener("click",this.outsideClickHandler,!0)}toggleDropdown(){this.open=!this.open}selectTheme(e){Ne.setTheme(e),this.currentTheme=Ne.name,this.open=!1,this.dispatchEvent(new CustomEvent("theme-changed",{detail:{theme:Ne.name},bubbles:!0,composed:!0}))}render(){const e=Ne.isDark,t=Ne.themes;return S`
      <button
        class="trigger"
        @click=${this.toggleDropdown}
        title="Change theme"
        aria-label="Change theme"
        aria-expanded=${this.open}
      >
        ${e?S`<svg
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              stroke-width="2"
              stroke-linecap="round"
              stroke-linejoin="round"
            >
              <circle cx="12" cy="12" r="5" />
              <line x1="12" y1="1" x2="12" y2="3" />
              <line x1="12" y1="21" x2="12" y2="23" />
              <line x1="4.22" y1="4.22" x2="5.64" y2="5.64" />
              <line x1="18.36" y1="18.36" x2="19.78" y2="19.78" />
              <line x1="1" y1="12" x2="3" y2="12" />
              <line x1="21" y1="12" x2="23" y2="12" />
              <line x1="4.22" y1="19.78" x2="5.64" y2="18.36" />
              <line x1="18.36" y1="5.64" x2="19.78" y2="4.22" />
            </svg>`:S`<svg
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              stroke-width="2"
              stroke-linecap="round"
              stroke-linejoin="round"
            >
              <path d="M21 12.79A9 9 0 1 1 11.21 3 7 7 0 0 0 21 12.79z" />
            </svg>`}
      </button>

      <div class="dropdown ${this.open?"open":""}">
        ${t.map(n=>S`
            <button
              class=${n.id===this.currentTheme?"active":""}
              @click=${()=>this.selectTheme(n.id)}
            >
              <span
                class="swatch"
                style="background: linear-gradient(135deg, ${this.swatchColors[n.id]?.[0]??"#888"} 50%, ${this.swatchColors[n.id]?.[1]??"#444"} 50%)"
              ></span>
              ${n.label}
              <span class="check">&#10003;</span>
            </button>
          `)}
      </div>
    `}};Sn.styles=at`
    :host {
      display: inline-flex;
      position: relative;
    }

    button.trigger {
      display: flex;
      align-items: center;
      justify-content: center;
      width: 36px;
      height: 36px;
      border-radius: var(--radius-sm);
      background: transparent;
      color: var(--text-secondary);
      border: none;
      cursor: pointer;
      transition:
        background var(--transition-fast),
        color var(--transition-fast);
    }

    button.trigger:hover {
      background: var(--bg-hover);
      color: var(--text-primary);
    }

    svg {
      width: 18px;
      height: 18px;
    }

    .dropdown {
      position: absolute;
      top: 100%;
      right: 0;
      margin-top: 4px;
      min-width: 160px;
      background: var(--bg-input);
      border: 1px solid var(--border-primary);
      border-radius: var(--radius-sm);
      box-shadow: var(--shadow-md);
      z-index: 200;
      padding: 4px;
      opacity: 0;
      transform: translateY(-4px);
      pointer-events: none;
      transition:
        opacity var(--transition-fast),
        transform var(--transition-fast);
    }

    .dropdown.open {
      opacity: 1;
      transform: translateY(0);
      pointer-events: auto;
    }

    .dropdown button {
      display: flex;
      align-items: center;
      gap: 8px;
      width: 100%;
      padding: 8px 10px;
      border: none;
      border-radius: var(--radius-xs);
      background: transparent;
      color: var(--text-primary);
      font-size: var(--font-size-sm);
      font-family: var(--font-sans);
      cursor: pointer;
      transition: background var(--transition-fast);
    }

    .dropdown button:hover {
      background: var(--bg-hover);
    }

    .dropdown button.active {
      background: var(--bg-tertiary);
      font-weight: var(--font-weight-medium);
    }

    .swatch {
      width: 14px;
      height: 14px;
      border-radius: var(--radius-xs);
      border: 1px solid var(--border-primary);
      flex-shrink: 0;
    }

    .check {
      margin-left: auto;
      font-size: 13px;
      opacity: 0;
    }

    .active .check {
      opacity: 1;
    }
  `;Ys([L()],Sn.prototype,"open",2);Ys([L()],Sn.prototype,"currentTheme",2);Sn=Ys([st("theme-picker")],Sn);var qh=Object.defineProperty,Xh=Object.getOwnPropertyDescriptor,Ua=(e,t,n,i)=>{for(var s=i>1?void 0:i?Xh(t,n):t,o=e.length-1,r;o>=0;o--)(r=e[o])&&(s=(i?r(t,n,s):r(s))||s);return i&&s&&qh(t,n,s),s};let bi=class extends it{constructor(){super(...arguments),this.sidebarOpen=w.state.sidebarOpen}connectedCallback(){super.connectedCallback(),this.unsubscribe=w.subscribe(()=>{this.sidebarOpen=w.state.sidebarOpen})}disconnectedCallback(){super.disconnectedCallback(),this.unsubscribe?.()}toggleSidebar(){w.update({sidebarOpen:!this.sidebarOpen})}render(){return S`
      <button
        class="toggle-btn"
        @click=${this.toggleSidebar}
        title=${this.sidebarOpen?"Close sidebar":"Open sidebar"}
        aria-label=${this.sidebarOpen?"Close sidebar":"Open sidebar"}
      >
        <svg
          viewBox="0 0 24 24"
          fill="none"
          stroke="currentColor"
          stroke-width="2"
          stroke-linecap="round"
          stroke-linejoin="round"
        >
          <line x1="3" y1="6" x2="21" y2="6" />
          <line x1="3" y1="12" x2="21" y2="12" />
          <line x1="3" y1="18" x2="21" y2="18" />
        </svg>
      </button>

      <div class="brand">
        <svg class="hat-icon" viewBox="0 0 136 103" fill="none" xmlns="http://www.w3.org/2000/svg">
          <path
            d="m 90.6538,59.2537 c 8.9312,0 21.8512,-1.8412 21.8512,-12.4662 0.029,-0.82 -0.045,-1.64 -0.22,-2.4413 l -5.3175,-23.1 C 105.7363,16.1575 104.6575,13.8525 95.7363,9.39 88.8075,5.85 73.725,0 69.2625,0 65.1075,0 63.9013,5.3575 58.945,5.3575 c -4.7712,0 -8.3112,-4 -12.7737,-4 -4.2825,0 -7.075,2.92 -9.2338,8.9262 0,0 -6,16.9338 -6.7725,19.39 -0.1262,0.4538 -0.18,0.9175 -0.16,1.3863 0,6.5825 25.9175,28.1687 60.6488,28.1687 m 23.2225,-8.125 c 1.235,5.845 1.235,6.46 1.235,7.2313 0,9.995 -11.235,15.5425 -26.01,15.5425 -33.3838,0.02 -62.6275,-19.5413 -62.6275,-32.4713 0,-1.8012 0.3612,-3.5837 1.075,-5.2337 C 15.5413,36.7725 0,38.9162 0,52.6375 c 0,22.475 53.2513,50.175 95.42,50.175 32.3288,0 40.4825,-14.6188 40.4825,-26.1663 0,-9.0825 -7.8512,-19.39 -22.0112,-25.5425"
            fill="var(--hat-color)"
          />
          <path
            d="m 113.8763,51.1037 c 1.235,5.845 1.235,6.46 1.235,7.2313 0,9.995 -11.235,15.5425 -26.01,15.5425 -33.3838,0.02 -62.6275,-19.5413 -62.6275,-32.4713 0,-1.8012 0.3612,-3.5837 1.075,-5.2337 l 2.6162,-6.47 c -0.1212,0.445 -0.175,0.8987 -0.16,1.3575 0,6.5825 25.9175,28.1687 60.6488,28.1687 8.9312,0 21.8512,-1.845 21.8512,-12.47 0.029,-0.8162 -0.045,-1.6362 -0.22,-2.4412 l 1.5913,6.7862 z"
            fill="rgba(0,0,0,0.2)"
          />
        </svg>
        <span class="title">Forklift</span>
      </div>

      <div class="spacer"></div>

      <theme-picker></theme-picker>
    `}};bi.styles=at`
    :host {
      display: flex;
      align-items: center;
      height: var(--topbar-height);
      min-height: var(--topbar-height);
      padding: 0 12px;
      background: var(--bg-sidebar);
      border-bottom: none;
      gap: 8px;
    }

    .toggle-btn {
      display: flex;
      align-items: center;
      justify-content: center;
      width: 36px;
      height: 36px;
      border-radius: var(--radius-sm);
      background: transparent;
      color: var(--text-secondary);
      border: none;
      cursor: pointer;
      transition:
        background var(--transition-fast),
        color var(--transition-fast);
      flex-shrink: 0;
    }

    .toggle-btn:hover {
      background: var(--bg-hover);
      color: var(--text-primary);
    }

    .toggle-btn svg {
      width: 18px;
      height: 18px;
    }

    .brand {
      display: flex;
      align-items: center;
      gap: 8px;
    }

    .hat-icon {
      width: 28px;
      height: 22px;
      flex-shrink: 0;
    }

    .title {
      font-size: var(--font-size-lg);
      font-weight: var(--font-weight-bold);
      color: var(--text-primary);
      white-space: nowrap;
    }

    .spacer {
      flex: 1;
    }
  `;Ua([L()],bi.prototype,"sidebarOpen",2);bi=Ua([st("top-bar")],bi);var Zh=Object.getOwnPropertyDescriptor,Jh=(e,t,n,i)=>{for(var s=i>1?void 0:i?Zh(t,n):t,o=e.length-1,r;o>=0;o--)(r=e[o])&&(s=r(s)||s);return s};let ys=class extends it{constructor(){super(...arguments),this.startX=0,this.onMouseDown=e=>{e.preventDefault(),this.startX=e.clientX,this.setAttribute("active",""),document.addEventListener("mousemove",this.onMouseMove),document.addEventListener("mouseup",this.onMouseUp)},this.onMouseMove=e=>{this.emitResize(e.clientX-this.startX)},this.onMouseUp=()=>{this.removeAttribute("active"),document.removeEventListener("mousemove",this.onMouseMove),document.removeEventListener("mouseup",this.onMouseUp),this.emitResizeEnd()}}emitResize(e){this.dispatchEvent(new CustomEvent("handle-resize",{detail:{delta:e},bubbles:!0,composed:!0}))}emitResizeEnd(){this.dispatchEvent(new CustomEvent("resize-end",{bubbles:!0,composed:!0}))}render(){return S`<div class="overlay"></div>`}connectedCallback(){super.connectedCallback(),this.addEventListener("mousedown",this.onMouseDown)}disconnectedCallback(){super.disconnectedCallback(),this.removeEventListener("mousedown",this.onMouseDown),document.removeEventListener("mousemove",this.onMouseMove),document.removeEventListener("mouseup",this.onMouseUp)}};ys.styles=at`
    :host {
      display: block;
      width: 4px;
      min-width: 4px;
      cursor: col-resize;
      background: var(--border-secondary);
      transition: background var(--transition-fast);
      position: relative;
      z-index: 2;
    }

    :host(:hover),
    :host([active]) {
      background: var(--accent-primary);
    }

    .overlay {
      display: none;
      position: fixed;
      inset: 0;
      z-index: 9999;
      cursor: col-resize;
    }

    :host([active]) .overlay {
      display: block;
    }
  `;ys=Jh([st("resize-handle")],ys);var Qh=Object.defineProperty,tu=Object.getOwnPropertyDescriptor,Ri=(e,t,n,i)=>{for(var s=i>1?void 0:i?tu(t,n):t,o=e.length-1,r;o>=0;o--)(r=e[o])&&(s=(i?r(t,n,s):r(s))||s);return i&&s&&Qh(t,n,s),s};let je=class extends it{constructor(){super(...arguments),this.matchCount=0,this.activeIndex=-1}firstUpdated(){this.input?.focus()}onInput(e){const t=e.target.value;this.emit("search-input",t)}onKeyDown(e){e.key==="Escape"?this.emit("search-close"):e.key==="Enter"&&(e.shiftKey?this.emit("search-prev"):this.emit("search-next"))}emit(e,t){this.dispatchEvent(new CustomEvent(e,{detail:t,bubbles:!0,composed:!0}))}get countLabel(){return this.matchCount===0?X:S`<span class="count">${this.activeIndex+1} / ${this.matchCount}</span>`}render(){const e=this.matchCount===0;return S`
      <input
        type="text"
        placeholder="Search…"
        spellcheck="false"
        @input=${this.onInput}
        @keydown=${this.onKeyDown}
      />
      ${this.countLabel}
      <button
        class="nav-btn"
        title="Previous (Shift+Enter)"
        ?disabled=${e}
        @click=${()=>this.emit("search-prev")}
      >
        <svg
          viewBox="0 0 24 24"
          fill="none"
          stroke="currentColor"
          stroke-width="2"
          stroke-linecap="round"
          stroke-linejoin="round"
        >
          <polyline points="18 15 12 9 6 15" />
        </svg>
      </button>
      <button
        class="nav-btn"
        title="Next (Enter)"
        ?disabled=${e}
        @click=${()=>this.emit("search-next")}
      >
        <svg
          viewBox="0 0 24 24"
          fill="none"
          stroke="currentColor"
          stroke-width="2"
          stroke-linecap="round"
          stroke-linejoin="round"
        >
          <polyline points="6 9 12 15 18 9" />
        </svg>
      </button>
    `}};je.styles=at`
    :host {
      display: flex;
      align-items: center;
      gap: 6px;
      padding: 4px 12px;
      background: var(--bg-tertiary);
      border-top: 1px solid var(--border-secondary);
    }

    input {
      flex: 1;
      min-width: 0;
      padding: 3px 8px;
      border: 1px solid var(--border-secondary);
      border-radius: var(--radius-xs);
      background: var(--bg-input, var(--bg-primary));
      color: var(--text-primary);
      font-family: inherit;
      font-size: var(--font-size-xs);
      outline: none;
      transition: border-color var(--transition-fast);
    }

    input:focus {
      border-color: var(--accent-primary);
    }

    .count {
      font-size: var(--font-size-xs);
      color: var(--text-tertiary);
      white-space: nowrap;
      min-width: 40px;
      text-align: center;
      font-variant-numeric: tabular-nums;
    }

    .nav-btn {
      display: inline-flex;
      align-items: center;
      justify-content: center;
      width: 20px;
      height: 20px;
      padding: 0;
      border: none;
      border-radius: var(--radius-xs);
      background: transparent;
      color: var(--text-tertiary);
      cursor: pointer;
      flex-shrink: 0;
      transition: all var(--transition-fast);
    }

    .nav-btn:hover {
      background: var(--bg-hover);
      color: var(--accent-primary);
    }

    .nav-btn:disabled {
      opacity: 0.3;
      cursor: default;
    }

    .nav-btn svg {
      width: 12px;
      height: 12px;
    }
  `;Ri([Wt({type:Number})],je.prototype,"matchCount",2);Ri([Wt({type:Number})],je.prototype,"activeIndex",2);Ri([zs("input")],je.prototype,"input",2);je=Ri([st("card-search-bar")],je);/*!
 * @kurkle/color v0.3.4
 * https://github.com/kurkle/color#readme
 * (c) 2024 Jukka Kurkela
 * Released under the MIT License
 */function Nn(e){return e+.5|0}const ne=(e,t,n)=>Math.max(Math.min(e,n),t);function dn(e){return ne(Nn(e*2.55),0,255)}function re(e){return ne(Nn(e*255),0,255)}function Zt(e){return ne(Nn(e/2.55)/100,0,1)}function Lo(e){return ne(Nn(e*100),0,100)}const Ct={0:0,1:1,2:2,3:3,4:4,5:5,6:6,7:7,8:8,9:9,A:10,B:11,C:12,D:13,E:14,F:15,a:10,b:11,c:12,d:13,e:14,f:15},xs=[..."0123456789ABCDEF"],eu=e=>xs[e&15],nu=e=>xs[(e&240)>>4]+xs[e&15],Xn=e=>(e&240)>>4===(e&15),iu=e=>Xn(e.r)&&Xn(e.g)&&Xn(e.b)&&Xn(e.a);function su(e){var t=e.length,n;return e[0]==="#"&&(t===4||t===5?n={r:255&Ct[e[1]]*17,g:255&Ct[e[2]]*17,b:255&Ct[e[3]]*17,a:t===5?Ct[e[4]]*17:255}:(t===7||t===9)&&(n={r:Ct[e[1]]<<4|Ct[e[2]],g:Ct[e[3]]<<4|Ct[e[4]],b:Ct[e[5]]<<4|Ct[e[6]],a:t===9?Ct[e[7]]<<4|Ct[e[8]]:255})),n}const ou=(e,t)=>e<255?t(e):"";function ru(e){var t=iu(e)?eu:nu;return e?"#"+t(e.r)+t(e.g)+t(e.b)+ou(e.a,t):void 0}const au=/^(hsla?|hwb|hsv)\(\s*([-+.e\d]+)(?:deg)?[\s,]+([-+.e\d]+)%[\s,]+([-+.e\d]+)%(?:[\s,]+([-+.e\d]+)(%)?)?\s*\)$/;function Wa(e,t,n){const i=t*Math.min(n,1-n),s=(o,r=(o+e/30)%12)=>n-i*Math.max(Math.min(r-3,9-r,1),-1);return[s(0),s(8),s(4)]}function lu(e,t,n){const i=(s,o=(s+e/60)%6)=>n-n*t*Math.max(Math.min(o,4-o,1),0);return[i(5),i(3),i(1)]}function cu(e,t,n){const i=Wa(e,1,.5);let s;for(t+n>1&&(s=1/(t+n),t*=s,n*=s),s=0;s<3;s++)i[s]*=1-t-n,i[s]+=t;return i}function du(e,t,n,i,s){return e===s?(t-n)/i+(t<n?6:0):t===s?(n-e)/i+2:(e-t)/i+4}function Gs(e){const n=e.r/255,i=e.g/255,s=e.b/255,o=Math.max(n,i,s),r=Math.min(n,i,s),a=(o+r)/2;let l,c,d;return o!==r&&(d=o-r,c=a>.5?d/(2-o-r):d/(o+r),l=du(n,i,s,d,o),l=l*60+.5),[l|0,c||0,a]}function Ks(e,t,n,i){return(Array.isArray(t)?e(t[0],t[1],t[2]):e(t,n,i)).map(re)}function qs(e,t,n){return Ks(Wa,e,t,n)}function hu(e,t,n){return Ks(cu,e,t,n)}function uu(e,t,n){return Ks(lu,e,t,n)}function ja(e){return(e%360+360)%360}function fu(e){const t=au.exec(e);let n=255,i;if(!t)return;t[5]!==i&&(n=t[6]?dn(+t[5]):re(+t[5]));const s=ja(+t[2]),o=+t[3]/100,r=+t[4]/100;return t[1]==="hwb"?i=hu(s,o,r):t[1]==="hsv"?i=uu(s,o,r):i=qs(s,o,r),{r:i[0],g:i[1],b:i[2],a:n}}function pu(e,t){var n=Gs(e);n[0]=ja(n[0]+t),n=qs(n),e.r=n[0],e.g=n[1],e.b=n[2]}function gu(e){if(!e)return;const t=Gs(e),n=t[0],i=Lo(t[1]),s=Lo(t[2]);return e.a<255?`hsla(${n}, ${i}%, ${s}%, ${Zt(e.a)})`:`hsl(${n}, ${i}%, ${s}%)`}const zo={x:"dark",Z:"light",Y:"re",X:"blu",W:"gr",V:"medium",U:"slate",A:"ee",T:"ol",S:"or",B:"ra",C:"lateg",D:"ights",R:"in",Q:"turquois",E:"hi",P:"ro",O:"al",N:"le",M:"de",L:"yello",F:"en",K:"ch",G:"arks",H:"ea",I:"ightg",J:"wh"},$o={OiceXe:"f0f8ff",antiquewEte:"faebd7",aqua:"ffff",aquamarRe:"7fffd4",azuY:"f0ffff",beige:"f5f5dc",bisque:"ffe4c4",black:"0",blanKedOmond:"ffebcd",Xe:"ff",XeviTet:"8a2be2",bPwn:"a52a2a",burlywood:"deb887",caMtXe:"5f9ea0",KartYuse:"7fff00",KocTate:"d2691e",cSO:"ff7f50",cSnflowerXe:"6495ed",cSnsilk:"fff8dc",crimson:"dc143c",cyan:"ffff",xXe:"8b",xcyan:"8b8b",xgTMnPd:"b8860b",xWay:"a9a9a9",xgYF:"6400",xgYy:"a9a9a9",xkhaki:"bdb76b",xmagFta:"8b008b",xTivegYF:"556b2f",xSange:"ff8c00",xScEd:"9932cc",xYd:"8b0000",xsOmon:"e9967a",xsHgYF:"8fbc8f",xUXe:"483d8b",xUWay:"2f4f4f",xUgYy:"2f4f4f",xQe:"ced1",xviTet:"9400d3",dAppRk:"ff1493",dApskyXe:"bfff",dimWay:"696969",dimgYy:"696969",dodgerXe:"1e90ff",fiYbrick:"b22222",flSOwEte:"fffaf0",foYstWAn:"228b22",fuKsia:"ff00ff",gaRsbSo:"dcdcdc",ghostwEte:"f8f8ff",gTd:"ffd700",gTMnPd:"daa520",Way:"808080",gYF:"8000",gYFLw:"adff2f",gYy:"808080",honeyMw:"f0fff0",hotpRk:"ff69b4",RdianYd:"cd5c5c",Rdigo:"4b0082",ivSy:"fffff0",khaki:"f0e68c",lavFMr:"e6e6fa",lavFMrXsh:"fff0f5",lawngYF:"7cfc00",NmoncEffon:"fffacd",ZXe:"add8e6",ZcSO:"f08080",Zcyan:"e0ffff",ZgTMnPdLw:"fafad2",ZWay:"d3d3d3",ZgYF:"90ee90",ZgYy:"d3d3d3",ZpRk:"ffb6c1",ZsOmon:"ffa07a",ZsHgYF:"20b2aa",ZskyXe:"87cefa",ZUWay:"778899",ZUgYy:"778899",ZstAlXe:"b0c4de",ZLw:"ffffe0",lime:"ff00",limegYF:"32cd32",lRF:"faf0e6",magFta:"ff00ff",maPon:"800000",VaquamarRe:"66cdaa",VXe:"cd",VScEd:"ba55d3",VpurpN:"9370db",VsHgYF:"3cb371",VUXe:"7b68ee",VsprRggYF:"fa9a",VQe:"48d1cc",VviTetYd:"c71585",midnightXe:"191970",mRtcYam:"f5fffa",mistyPse:"ffe4e1",moccasR:"ffe4b5",navajowEte:"ffdead",navy:"80",Tdlace:"fdf5e6",Tive:"808000",TivedBb:"6b8e23",Sange:"ffa500",SangeYd:"ff4500",ScEd:"da70d6",pOegTMnPd:"eee8aa",pOegYF:"98fb98",pOeQe:"afeeee",pOeviTetYd:"db7093",papayawEp:"ffefd5",pHKpuff:"ffdab9",peru:"cd853f",pRk:"ffc0cb",plum:"dda0dd",powMrXe:"b0e0e6",purpN:"800080",YbeccapurpN:"663399",Yd:"ff0000",Psybrown:"bc8f8f",PyOXe:"4169e1",saddNbPwn:"8b4513",sOmon:"fa8072",sandybPwn:"f4a460",sHgYF:"2e8b57",sHshell:"fff5ee",siFna:"a0522d",silver:"c0c0c0",skyXe:"87ceeb",UXe:"6a5acd",UWay:"708090",UgYy:"708090",snow:"fffafa",sprRggYF:"ff7f",stAlXe:"4682b4",tan:"d2b48c",teO:"8080",tEstN:"d8bfd8",tomato:"ff6347",Qe:"40e0d0",viTet:"ee82ee",JHt:"f5deb3",wEte:"ffffff",wEtesmoke:"f5f5f5",Lw:"ffff00",LwgYF:"9acd32"};function mu(){const e={},t=Object.keys($o),n=Object.keys(zo);let i,s,o,r,a;for(i=0;i<t.length;i++){for(r=a=t[i],s=0;s<n.length;s++)o=n[s],a=a.replace(o,zo[o]);o=parseInt($o[r],16),e[a]=[o>>16&255,o>>8&255,o&255]}return e}let Zn;function bu(e){Zn||(Zn=mu(),Zn.transparent=[0,0,0,0]);const t=Zn[e.toLowerCase()];return t&&{r:t[0],g:t[1],b:t[2],a:t.length===4?t[3]:255}}const vu=/^rgba?\(\s*([-+.\d]+)(%)?[\s,]+([-+.e\d]+)(%)?[\s,]+([-+.e\d]+)(%)?(?:[\s,/]+([-+.e\d]+)(%)?)?\s*\)$/;function yu(e){const t=vu.exec(e);let n=255,i,s,o;if(t){if(t[7]!==i){const r=+t[7];n=t[8]?dn(r):ne(r*255,0,255)}return i=+t[1],s=+t[3],o=+t[5],i=255&(t[2]?dn(i):ne(i,0,255)),s=255&(t[4]?dn(s):ne(s,0,255)),o=255&(t[6]?dn(o):ne(o,0,255)),{r:i,g:s,b:o,a:n}}}function xu(e){return e&&(e.a<255?`rgba(${e.r}, ${e.g}, ${e.b}, ${Zt(e.a)})`:`rgb(${e.r}, ${e.g}, ${e.b})`)}const Ji=e=>e<=.0031308?e*12.92:Math.pow(e,1/2.4)*1.055-.055,Le=e=>e<=.04045?e/12.92:Math.pow((e+.055)/1.055,2.4);function _u(e,t,n){const i=Le(Zt(e.r)),s=Le(Zt(e.g)),o=Le(Zt(e.b));return{r:re(Ji(i+n*(Le(Zt(t.r))-i))),g:re(Ji(s+n*(Le(Zt(t.g))-s))),b:re(Ji(o+n*(Le(Zt(t.b))-o))),a:e.a+n*(t.a-e.a)}}function Jn(e,t,n){if(e){let i=Gs(e);i[t]=Math.max(0,Math.min(i[t]+i[t]*n,t===0?360:1)),i=qs(i),e.r=i[0],e.g=i[1],e.b=i[2]}}function Va(e,t){return e&&Object.assign(t||{},e)}function Fo(e){var t={r:0,g:0,b:0,a:255};return Array.isArray(e)?e.length>=3&&(t={r:e[0],g:e[1],b:e[2],a:255},e.length>3&&(t.a=re(e[3]))):(t=Va(e,{r:0,g:0,b:0,a:1}),t.a=re(t.a)),t}function wu(e){return e.charAt(0)==="r"?yu(e):fu(e)}class En{constructor(t){if(t instanceof En)return t;const n=typeof t;let i;n==="object"?i=Fo(t):n==="string"&&(i=su(t)||bu(t)||wu(t)),this._rgb=i,this._valid=!!i}get valid(){return this._valid}get rgb(){var t=Va(this._rgb);return t&&(t.a=Zt(t.a)),t}set rgb(t){this._rgb=Fo(t)}rgbString(){return this._valid?xu(this._rgb):void 0}hexString(){return this._valid?ru(this._rgb):void 0}hslString(){return this._valid?gu(this._rgb):void 0}mix(t,n){if(t){const i=this.rgb,s=t.rgb;let o;const r=n===o?.5:n,a=2*r-1,l=i.a-s.a,c=((a*l===-1?a:(a+l)/(1+a*l))+1)/2;o=1-c,i.r=255&c*i.r+o*s.r+.5,i.g=255&c*i.g+o*s.g+.5,i.b=255&c*i.b+o*s.b+.5,i.a=r*i.a+(1-r)*s.a,this.rgb=i}return this}interpolate(t,n){return t&&(this._rgb=_u(this._rgb,t._rgb,n)),this}clone(){return new En(this.rgb)}alpha(t){return this._rgb.a=re(t),this}clearer(t){const n=this._rgb;return n.a*=1-t,this}greyscale(){const t=this._rgb,n=Nn(t.r*.3+t.g*.59+t.b*.11);return t.r=t.g=t.b=n,this}opaquer(t){const n=this._rgb;return n.a*=1+t,this}negate(){const t=this._rgb;return t.r=255-t.r,t.g=255-t.g,t.b=255-t.b,this}lighten(t){return Jn(this._rgb,2,t),this}darken(t){return Jn(this._rgb,2,-t),this}saturate(t){return Jn(this._rgb,1,t),this}desaturate(t){return Jn(this._rgb,1,-t),this}rotate(t){return pu(this._rgb,t),this}}/*!
 * Chart.js v4.5.1
 * https://www.chartjs.org
 * (c) 2025 Chart.js Contributors
 * Released under the MIT License
 */function Kt(){}const ku=(()=>{let e=0;return()=>e++})();function G(e){return e==null}function ct(e){if(Array.isArray&&Array.isArray(e))return!0;const t=Object.prototype.toString.call(e);return t.slice(0,7)==="[object"&&t.slice(-6)==="Array]"}function W(e){return e!==null&&Object.prototype.toString.call(e)==="[object Object]"}function ft(e){return(typeof e=="number"||e instanceof Number)&&isFinite(+e)}function $t(e,t){return ft(e)?e:t}function B(e,t){return typeof e>"u"?t:e}const Su=(e,t)=>typeof e=="string"&&e.endsWith("%")?parseFloat(e)/100*t:+e;function N(e,t,n){if(e&&typeof e.call=="function")return e.apply(n,t)}function U(e,t,n,i){let s,o,r;if(ct(e))for(o=e.length,s=0;s<o;s++)t.call(n,e[s],s);else if(W(e))for(r=Object.keys(e),o=r.length,s=0;s<o;s++)t.call(n,e[r[s]],r[s])}function vi(e,t){let n,i,s,o;if(!e||!t||e.length!==t.length)return!1;for(n=0,i=e.length;n<i;++n)if(s=e[n],o=t[n],s.datasetIndex!==o.datasetIndex||s.index!==o.index)return!1;return!0}function yi(e){if(ct(e))return e.map(yi);if(W(e)){const t=Object.create(null),n=Object.keys(e),i=n.length;let s=0;for(;s<i;++s)t[n[s]]=yi(e[n[s]]);return t}return e}function Ya(e){return["__proto__","prototype","constructor"].indexOf(e)===-1}function Eu(e,t,n,i){if(!Ya(e))return;const s=t[e],o=n[e];W(s)&&W(o)?Tn(s,o,i):t[e]=yi(o)}function Tn(e,t,n){const i=ct(t)?t:[t],s=i.length;if(!W(e))return e;n=n||{};const o=n.merger||Eu;let r;for(let a=0;a<s;++a){if(r=i[a],!W(r))continue;const l=Object.keys(r);for(let c=0,d=l.length;c<d;++c)o(l[c],e,r,n)}return e}function fn(e,t){return Tn(e,t,{merger:Tu})}function Tu(e,t,n){if(!Ya(e))return;const i=t[e],s=n[e];W(i)&&W(s)?fn(i,s):Object.prototype.hasOwnProperty.call(t,e)||(t[e]=yi(s))}const Bo={"":e=>e,x:e=>e.x,y:e=>e.y};function Cu(e){const t=e.split("."),n=[];let i="";for(const s of t)i+=s,i.endsWith("\\")?i=i.slice(0,-1)+".":(n.push(i),i="");return n}function Ou(e){const t=Cu(e);return n=>{for(const i of t){if(i==="")break;n=n&&n[i]}return n}}function xi(e,t){return(Bo[t]||(Bo[t]=Ou(t)))(e)}function Xs(e){return e.charAt(0).toUpperCase()+e.slice(1)}const _i=e=>typeof e<"u",le=e=>typeof e=="function",Ho=(e,t)=>{if(e.size!==t.size)return!1;for(const n of e)if(!t.has(n))return!1;return!0};function Mu(e){return e.type==="mouseup"||e.type==="click"||e.type==="contextmenu"}const ut=Math.PI,It=2*ut,Pu=It+ut,wi=Number.POSITIVE_INFINITY,Au=ut/180,At=ut/2,be=ut/4,Uo=ut*2/3,Ga=Math.log10,ce=Math.sign;function ke(e,t,n){return Math.abs(e-t)<n}function Wo(e){const t=Math.round(e);e=ke(e,t,e/1e3)?t:e;const n=Math.pow(10,Math.floor(Ga(e))),i=e/n;return(i<=1?1:i<=2?2:i<=5?5:10)*n}function Du(e){const t=[],n=Math.sqrt(e);let i;for(i=1;i<n;i++)e%i===0&&(t.push(i),t.push(e/i));return n===(n|0)&&t.push(n),t.sort((s,o)=>s-o).pop(),t}function Iu(e){return typeof e=="symbol"||typeof e=="object"&&e!==null&&!(Symbol.toPrimitive in e||"toString"in e||"valueOf"in e)}function Cn(e){return!Iu(e)&&!isNaN(parseFloat(e))&&isFinite(e)}function Ru(e,t){const n=Math.round(e);return n-t<=e&&n+t>=e}function Nu(e,t,n){let i,s,o;for(i=0,s=e.length;i<s;i++)o=e[i][n],isNaN(o)||(t.min=Math.min(t.min,o),t.max=Math.max(t.max,o))}function _e(e){return e*(ut/180)}function Lu(e){return e*(180/ut)}function jo(e){if(!ft(e))return;let t=1,n=0;for(;Math.round(e*t)/t!==e;)t*=10,n++;return n}function zu(e,t){const n=t.x-e.x,i=t.y-e.y,s=Math.sqrt(n*n+i*i);let o=Math.atan2(i,n);return o<-.5*ut&&(o+=It),{angle:o,distance:s}}function _s(e,t){return Math.sqrt(Math.pow(t.x-e.x,2)+Math.pow(t.y-e.y,2))}function $u(e,t){return(e-t+Pu)%It-ut}function Ht(e){return(e%It+It)%It}function Ka(e,t,n,i){const s=Ht(e),o=Ht(t),r=Ht(n),a=Ht(o-s),l=Ht(r-s),c=Ht(s-o),d=Ht(s-r);return s===o||s===r||i&&o===r||a>l&&c<d}function Dt(e,t,n){return Math.max(t,Math.min(n,e))}function Fu(e){return Dt(e,-32768,32767)}function $e(e,t,n,i=1e-6){return e>=Math.min(t,n)-i&&e<=Math.max(t,n)+i}function Zs(e,t,n){n=n||(r=>e[r]<t);let i=e.length-1,s=0,o;for(;i-s>1;)o=s+i>>1,n(o)?s=o:i=o;return{lo:s,hi:i}}const we=(e,t,n,i)=>Zs(e,n,i?s=>{const o=e[s][t];return o<n||o===n&&e[s+1][t]===n}:s=>e[s][t]<n),Bu=(e,t,n)=>Zs(e,n,i=>e[i][t]>=n);function Hu(e,t,n){let i=0,s=e.length;for(;i<s&&e[i]<t;)i++;for(;s>i&&e[s-1]>n;)s--;return i>0||s<e.length?e.slice(i,s):e}const qa=["push","pop","shift","splice","unshift"];function Uu(e,t){if(e._chartjs){e._chartjs.listeners.push(t);return}Object.defineProperty(e,"_chartjs",{configurable:!0,enumerable:!1,value:{listeners:[t]}}),qa.forEach(n=>{const i="_onData"+Xs(n),s=e[n];Object.defineProperty(e,n,{configurable:!0,enumerable:!1,value(...o){const r=s.apply(this,o);return e._chartjs.listeners.forEach(a=>{typeof a[i]=="function"&&a[i](...o)}),r}})})}function Vo(e,t){const n=e._chartjs;if(!n)return;const i=n.listeners,s=i.indexOf(t);s!==-1&&i.splice(s,1),!(i.length>0)&&(qa.forEach(o=>{delete e[o]}),delete e._chartjs)}function Wu(e){const t=new Set(e);return t.size===e.length?e:Array.from(t)}const Xa=(function(){return typeof window>"u"?function(e){return e()}:window.requestAnimationFrame})();function Za(e,t){let n=[],i=!1;return function(...s){n=s,i||(i=!0,Xa.call(window,()=>{i=!1,e.apply(t,n)}))}}function ju(e,t){let n;return function(...i){return t?(clearTimeout(n),n=setTimeout(e,t,i)):e.apply(this,i),t}}const Ja=e=>e==="start"?"left":e==="end"?"right":"center",St=(e,t,n)=>e==="start"?t:e==="end"?n:(t+n)/2,Vu=(e,t,n,i)=>e===(i?"left":"right")?n:e==="center"?(t+n)/2:t;function Yu(e,t,n){const i=t.length;let s=0,o=i;if(e._sorted){const{iScale:r,vScale:a,_parsed:l}=e,c=e.dataset&&e.dataset.options?e.dataset.options.spanGaps:null,d=r.axis,{min:h,max:f,minDefined:g,maxDefined:m}=r.getUserBounds();if(g){if(s=Math.min(we(l,d,h).lo,n?i:we(t,d,r.getPixelForValue(h)).lo),c){const v=l.slice(0,s+1).reverse().findIndex(y=>!G(y[a.axis]));s-=Math.max(0,v)}s=Dt(s,0,i-1)}if(m){let v=Math.max(we(l,r.axis,f,!0).hi+1,n?0:we(t,d,r.getPixelForValue(f),!0).hi+1);if(c){const y=l.slice(v-1).findIndex(_=>!G(_[a.axis]));v+=Math.max(0,y)}o=Dt(v,s,i)-s}else o=i-s}return{start:s,count:o}}function Gu(e){const{xScale:t,yScale:n,_scaleRanges:i}=e,s={xmin:t.min,xmax:t.max,ymin:n.min,ymax:n.max};if(!i)return e._scaleRanges=s,!0;const o=i.xmin!==t.min||i.xmax!==t.max||i.ymin!==n.min||i.ymax!==n.max;return Object.assign(i,s),o}const Qn=e=>e===0||e===1,Yo=(e,t,n)=>-(Math.pow(2,10*(e-=1))*Math.sin((e-t)*It/n)),Go=(e,t,n)=>Math.pow(2,-10*e)*Math.sin((e-t)*It/n)+1,pn={linear:e=>e,easeInQuad:e=>e*e,easeOutQuad:e=>-e*(e-2),easeInOutQuad:e=>(e/=.5)<1?.5*e*e:-.5*(--e*(e-2)-1),easeInCubic:e=>e*e*e,easeOutCubic:e=>(e-=1)*e*e+1,easeInOutCubic:e=>(e/=.5)<1?.5*e*e*e:.5*((e-=2)*e*e+2),easeInQuart:e=>e*e*e*e,easeOutQuart:e=>-((e-=1)*e*e*e-1),easeInOutQuart:e=>(e/=.5)<1?.5*e*e*e*e:-.5*((e-=2)*e*e*e-2),easeInQuint:e=>e*e*e*e*e,easeOutQuint:e=>(e-=1)*e*e*e*e+1,easeInOutQuint:e=>(e/=.5)<1?.5*e*e*e*e*e:.5*((e-=2)*e*e*e*e+2),easeInSine:e=>-Math.cos(e*At)+1,easeOutSine:e=>Math.sin(e*At),easeInOutSine:e=>-.5*(Math.cos(ut*e)-1),easeInExpo:e=>e===0?0:Math.pow(2,10*(e-1)),easeOutExpo:e=>e===1?1:-Math.pow(2,-10*e)+1,easeInOutExpo:e=>Qn(e)?e:e<.5?.5*Math.pow(2,10*(e*2-1)):.5*(-Math.pow(2,-10*(e*2-1))+2),easeInCirc:e=>e>=1?e:-(Math.sqrt(1-e*e)-1),easeOutCirc:e=>Math.sqrt(1-(e-=1)*e),easeInOutCirc:e=>(e/=.5)<1?-.5*(Math.sqrt(1-e*e)-1):.5*(Math.sqrt(1-(e-=2)*e)+1),easeInElastic:e=>Qn(e)?e:Yo(e,.075,.3),easeOutElastic:e=>Qn(e)?e:Go(e,.075,.3),easeInOutElastic(e){return Qn(e)?e:e<.5?.5*Yo(e*2,.1125,.45):.5+.5*Go(e*2-1,.1125,.45)},easeInBack(e){return e*e*((1.70158+1)*e-1.70158)},easeOutBack(e){return(e-=1)*e*((1.70158+1)*e+1.70158)+1},easeInOutBack(e){let t=1.70158;return(e/=.5)<1?.5*(e*e*(((t*=1.525)+1)*e-t)):.5*((e-=2)*e*(((t*=1.525)+1)*e+t)+2)},easeInBounce:e=>1-pn.easeOutBounce(1-e),easeOutBounce(e){return e<1/2.75?7.5625*e*e:e<2/2.75?7.5625*(e-=1.5/2.75)*e+.75:e<2.5/2.75?7.5625*(e-=2.25/2.75)*e+.9375:7.5625*(e-=2.625/2.75)*e+.984375},easeInOutBounce:e=>e<.5?pn.easeInBounce(e*2)*.5:pn.easeOutBounce(e*2-1)*.5+.5};function Js(e){if(e&&typeof e=="object"){const t=e.toString();return t==="[object CanvasPattern]"||t==="[object CanvasGradient]"}return!1}function Ko(e){return Js(e)?e:new En(e)}function Qi(e){return Js(e)?e:new En(e).saturate(.5).darken(.1).hexString()}const Ku=["x","y","borderWidth","radius","tension"],qu=["color","borderColor","backgroundColor"];function Xu(e){e.set("animation",{delay:void 0,duration:1e3,easing:"easeOutQuart",fn:void 0,from:void 0,loop:void 0,to:void 0,type:void 0}),e.describe("animation",{_fallback:!1,_indexable:!1,_scriptable:t=>t!=="onProgress"&&t!=="onComplete"&&t!=="fn"}),e.set("animations",{colors:{type:"color",properties:qu},numbers:{type:"number",properties:Ku}}),e.describe("animations",{_fallback:"animation"}),e.set("transitions",{active:{animation:{duration:400}},resize:{animation:{duration:0}},show:{animations:{colors:{from:"transparent"},visible:{type:"boolean",duration:0}}},hide:{animations:{colors:{to:"transparent"},visible:{type:"boolean",easing:"linear",fn:t=>t|0}}}})}function Zu(e){e.set("layout",{autoPadding:!0,padding:{top:0,right:0,bottom:0,left:0}})}const qo=new Map;function Ju(e,t){t=t||{};const n=e+JSON.stringify(t);let i=qo.get(n);return i||(i=new Intl.NumberFormat(e,t),qo.set(n,i)),i}function Qa(e,t,n){return Ju(t,n).format(e)}const Qu={values(e){return ct(e)?e:""+e},numeric(e,t,n){if(e===0)return"0";const i=this.chart.options.locale;let s,o=e;if(n.length>1){const c=Math.max(Math.abs(n[0].value),Math.abs(n[n.length-1].value));(c<1e-4||c>1e15)&&(s="scientific"),o=tf(e,n)}const r=Ga(Math.abs(o)),a=isNaN(r)?1:Math.max(Math.min(-1*Math.floor(r),20),0),l={notation:s,minimumFractionDigits:a,maximumFractionDigits:a};return Object.assign(l,this.options.ticks.format),Qa(e,i,l)}};function tf(e,t){let n=t.length>3?t[2].value-t[1].value:t[1].value-t[0].value;return Math.abs(n)>=1&&e!==Math.floor(e)&&(n=e-Math.floor(e)),n}var tl={formatters:Qu};function ef(e){e.set("scale",{display:!0,offset:!1,reverse:!1,beginAtZero:!1,bounds:"ticks",clip:!0,grace:0,grid:{display:!0,lineWidth:1,drawOnChartArea:!0,drawTicks:!0,tickLength:8,tickWidth:(t,n)=>n.lineWidth,tickColor:(t,n)=>n.color,offset:!1},border:{display:!0,dash:[],dashOffset:0,width:1},title:{display:!1,text:"",padding:{top:4,bottom:4}},ticks:{minRotation:0,maxRotation:50,mirror:!1,textStrokeWidth:0,textStrokeColor:"",padding:3,display:!0,autoSkip:!0,autoSkipPadding:3,labelOffset:0,callback:tl.formatters.values,minor:{},major:{},align:"center",crossAlign:"near",showLabelBackdrop:!1,backdropColor:"rgba(255, 255, 255, 0.75)",backdropPadding:2}}),e.route("scale.ticks","color","","color"),e.route("scale.grid","color","","borderColor"),e.route("scale.border","color","","borderColor"),e.route("scale.title","color","","color"),e.describe("scale",{_fallback:!1,_scriptable:t=>!t.startsWith("before")&&!t.startsWith("after")&&t!=="callback"&&t!=="parser",_indexable:t=>t!=="borderDash"&&t!=="tickBorderDash"&&t!=="dash"}),e.describe("scales",{_fallback:"scale"}),e.describe("scale.ticks",{_scriptable:t=>t!=="backdropPadding"&&t!=="callback",_indexable:t=>t!=="backdropPadding"})}const Te=Object.create(null),ws=Object.create(null);function gn(e,t){if(!t)return e;const n=t.split(".");for(let i=0,s=n.length;i<s;++i){const o=n[i];e=e[o]||(e[o]=Object.create(null))}return e}function ts(e,t,n){return typeof t=="string"?Tn(gn(e,t),n):Tn(gn(e,""),t)}class nf{constructor(t,n){this.animation=void 0,this.backgroundColor="rgba(0,0,0,0.1)",this.borderColor="rgba(0,0,0,0.1)",this.color="#666",this.datasets={},this.devicePixelRatio=i=>i.chart.platform.getDevicePixelRatio(),this.elements={},this.events=["mousemove","mouseout","click","touchstart","touchmove"],this.font={family:"'Helvetica Neue', 'Helvetica', 'Arial', sans-serif",size:12,style:"normal",lineHeight:1.2,weight:null},this.hover={},this.hoverBackgroundColor=(i,s)=>Qi(s.backgroundColor),this.hoverBorderColor=(i,s)=>Qi(s.borderColor),this.hoverColor=(i,s)=>Qi(s.color),this.indexAxis="x",this.interaction={mode:"nearest",intersect:!0,includeInvisible:!1},this.maintainAspectRatio=!0,this.onHover=null,this.onClick=null,this.parsing=!0,this.plugins={},this.responsive=!0,this.scale=void 0,this.scales={},this.showLine=!0,this.drawActiveElementsOnTop=!0,this.describe(t),this.apply(n)}set(t,n){return ts(this,t,n)}get(t){return gn(this,t)}describe(t,n){return ts(ws,t,n)}override(t,n){return ts(Te,t,n)}route(t,n,i,s){const o=gn(this,t),r=gn(this,i),a="_"+n;Object.defineProperties(o,{[a]:{value:o[n],writable:!0},[n]:{enumerable:!0,get(){const l=this[a],c=r[s];return W(l)?Object.assign({},c,l):B(l,c)},set(l){this[a]=l}}})}apply(t){t.forEach(n=>n(this))}}var Q=new nf({_scriptable:e=>!e.startsWith("on"),_indexable:e=>e!=="events",hover:{_fallback:"interaction"},interaction:{_scriptable:!1,_indexable:!1}},[Xu,Zu,ef]);function sf(e){return!e||G(e.size)||G(e.family)?null:(e.style?e.style+" ":"")+(e.weight?e.weight+" ":"")+e.size+"px "+e.family}function Xo(e,t,n,i,s){let o=t[s];return o||(o=t[s]=e.measureText(s).width,n.push(s)),o>i&&(i=o),i}function ve(e,t,n){const i=e.currentDevicePixelRatio,s=n!==0?Math.max(n/2,.5):0;return Math.round((t-s)*i)/i+s}function Zo(e,t){!t&&!e||(t=t||e.getContext("2d"),t.save(),t.resetTransform(),t.clearRect(0,0,e.width,e.height),t.restore())}function ks(e,t,n,i){el(e,t,n,i,null)}function el(e,t,n,i,s){let o,r,a,l,c,d,h,f;const g=t.pointStyle,m=t.rotation,v=t.radius;let y=(m||0)*Au;if(g&&typeof g=="object"&&(o=g.toString(),o==="[object HTMLImageElement]"||o==="[object HTMLCanvasElement]")){e.save(),e.translate(n,i),e.rotate(y),e.drawImage(g,-g.width/2,-g.height/2,g.width,g.height),e.restore();return}if(!(isNaN(v)||v<=0)){switch(e.beginPath(),g){default:s?e.ellipse(n,i,s/2,v,0,0,It):e.arc(n,i,v,0,It),e.closePath();break;case"triangle":d=s?s/2:v,e.moveTo(n+Math.sin(y)*d,i-Math.cos(y)*v),y+=Uo,e.lineTo(n+Math.sin(y)*d,i-Math.cos(y)*v),y+=Uo,e.lineTo(n+Math.sin(y)*d,i-Math.cos(y)*v),e.closePath();break;case"rectRounded":c=v*.516,l=v-c,r=Math.cos(y+be)*l,h=Math.cos(y+be)*(s?s/2-c:l),a=Math.sin(y+be)*l,f=Math.sin(y+be)*(s?s/2-c:l),e.arc(n-h,i-a,c,y-ut,y-At),e.arc(n+f,i-r,c,y-At,y),e.arc(n+h,i+a,c,y,y+At),e.arc(n-f,i+r,c,y+At,y+ut),e.closePath();break;case"rect":if(!m){l=Math.SQRT1_2*v,d=s?s/2:l,e.rect(n-d,i-l,2*d,2*l);break}y+=be;case"rectRot":h=Math.cos(y)*(s?s/2:v),r=Math.cos(y)*v,a=Math.sin(y)*v,f=Math.sin(y)*(s?s/2:v),e.moveTo(n-h,i-a),e.lineTo(n+f,i-r),e.lineTo(n+h,i+a),e.lineTo(n-f,i+r),e.closePath();break;case"crossRot":y+=be;case"cross":h=Math.cos(y)*(s?s/2:v),r=Math.cos(y)*v,a=Math.sin(y)*v,f=Math.sin(y)*(s?s/2:v),e.moveTo(n-h,i-a),e.lineTo(n+h,i+a),e.moveTo(n+f,i-r),e.lineTo(n-f,i+r);break;case"star":h=Math.cos(y)*(s?s/2:v),r=Math.cos(y)*v,a=Math.sin(y)*v,f=Math.sin(y)*(s?s/2:v),e.moveTo(n-h,i-a),e.lineTo(n+h,i+a),e.moveTo(n+f,i-r),e.lineTo(n-f,i+r),y+=be,h=Math.cos(y)*(s?s/2:v),r=Math.cos(y)*v,a=Math.sin(y)*v,f=Math.sin(y)*(s?s/2:v),e.moveTo(n-h,i-a),e.lineTo(n+h,i+a),e.moveTo(n+f,i-r),e.lineTo(n-f,i+r);break;case"line":r=s?s/2:Math.cos(y)*v,a=Math.sin(y)*v,e.moveTo(n-r,i-a),e.lineTo(n+r,i+a);break;case"dash":e.moveTo(n,i),e.lineTo(n+Math.cos(y)*(s?s/2:v),i+Math.sin(y)*v);break;case!1:e.closePath();break}e.fill(),t.borderWidth>0&&e.stroke()}}function Ve(e,t,n){return n=n||.5,!t||e&&e.x>t.left-n&&e.x<t.right+n&&e.y>t.top-n&&e.y<t.bottom+n}function Ni(e,t){e.save(),e.beginPath(),e.rect(t.left,t.top,t.right-t.left,t.bottom-t.top),e.clip()}function Li(e){e.restore()}function of(e,t,n,i,s){if(!t)return e.lineTo(n.x,n.y);if(s==="middle"){const o=(t.x+n.x)/2;e.lineTo(o,t.y),e.lineTo(o,n.y)}else s==="after"!=!!i?e.lineTo(t.x,n.y):e.lineTo(n.x,t.y);e.lineTo(n.x,n.y)}function rf(e,t,n,i){if(!t)return e.lineTo(n.x,n.y);e.bezierCurveTo(i?t.cp1x:t.cp2x,i?t.cp1y:t.cp2y,i?n.cp2x:n.cp1x,i?n.cp2y:n.cp1y,n.x,n.y)}function af(e,t){t.translation&&e.translate(t.translation[0],t.translation[1]),G(t.rotation)||e.rotate(t.rotation),t.color&&(e.fillStyle=t.color),t.textAlign&&(e.textAlign=t.textAlign),t.textBaseline&&(e.textBaseline=t.textBaseline)}function lf(e,t,n,i,s){if(s.strikethrough||s.underline){const o=e.measureText(i),r=t-o.actualBoundingBoxLeft,a=t+o.actualBoundingBoxRight,l=n-o.actualBoundingBoxAscent,c=n+o.actualBoundingBoxDescent,d=s.strikethrough?(l+c)/2:c;e.strokeStyle=e.fillStyle,e.beginPath(),e.lineWidth=s.decorationWidth||2,e.moveTo(r,d),e.lineTo(a,d),e.stroke()}}function cf(e,t){const n=e.fillStyle;e.fillStyle=t.color,e.fillRect(t.left,t.top,t.width,t.height),e.fillStyle=n}function ki(e,t,n,i,s,o={}){const r=ct(t)?t:[t],a=o.strokeWidth>0&&o.strokeColor!=="";let l,c;for(e.save(),e.font=s.string,af(e,o),l=0;l<r.length;++l)c=r[l],o.backdrop&&cf(e,o.backdrop),a&&(o.strokeColor&&(e.strokeStyle=o.strokeColor),G(o.strokeWidth)||(e.lineWidth=o.strokeWidth),e.strokeText(c,n,i,o.maxWidth)),e.fillText(c,n,i,o.maxWidth),lf(e,n,i,c,o),i+=Number(s.lineHeight);e.restore()}function Ss(e,t){const{x:n,y:i,w:s,h:o,radius:r}=t;e.arc(n+r.topLeft,i+r.topLeft,r.topLeft,1.5*ut,ut,!0),e.lineTo(n,i+o-r.bottomLeft),e.arc(n+r.bottomLeft,i+o-r.bottomLeft,r.bottomLeft,ut,At,!0),e.lineTo(n+s-r.bottomRight,i+o),e.arc(n+s-r.bottomRight,i+o-r.bottomRight,r.bottomRight,At,0,!0),e.lineTo(n+s,i+r.topRight),e.arc(n+s-r.topRight,i+r.topRight,r.topRight,0,-At,!0),e.lineTo(n+r.topLeft,i)}const df=/^(normal|(\d+(?:\.\d+)?)(px|em|%)?)$/,hf=/^(normal|italic|initial|inherit|unset|(oblique( -?[0-9]?[0-9]deg)?))$/;function uf(e,t){const n=(""+e).match(df);if(!n||n[1]==="normal")return t*1.2;switch(e=+n[2],n[3]){case"px":return e;case"%":e/=100;break}return t*e}const ff=e=>+e||0;function nl(e,t){const n={},i=W(t),s=i?Object.keys(t):t,o=W(e)?i?r=>B(e[r],e[t[r]]):r=>e[r]:()=>e;for(const r of s)n[r]=ff(o(r));return n}function pf(e){return nl(e,{top:"y",right:"x",bottom:"y",left:"x"})}function mn(e){return nl(e,["topLeft","topRight","bottomLeft","bottomRight"])}function Rt(e){const t=pf(e);return t.width=t.left+t.right,t.height=t.top+t.bottom,t}function xt(e,t){e=e||{},t=t||Q.font;let n=B(e.size,t.size);typeof n=="string"&&(n=parseInt(n,10));let i=B(e.style,t.style);i&&!(""+i).match(hf)&&(console.warn('Invalid font style specified: "'+i+'"'),i=void 0);const s={family:B(e.family,t.family),lineHeight:uf(B(e.lineHeight,t.lineHeight),n),size:n,style:i,weight:B(e.weight,t.weight),string:""};return s.string=sf(s),s}function ti(e,t,n,i){let s,o,r;for(s=0,o=e.length;s<o;++s)if(r=e[s],r!==void 0&&r!==void 0)return r}function gf(e,t,n){const{min:i,max:s}=e,o=Su(t,(s-i)/2),r=(a,l)=>n&&a===0?0:a+l;return{min:r(i,-Math.abs(o)),max:r(s,o)}}function Ae(e,t){return Object.assign(Object.create(e),t)}function Qs(e,t=[""],n,i,s=()=>e[0]){const o=n||e;typeof i>"u"&&(i=rl("_fallback",e));const r={[Symbol.toStringTag]:"Object",_cacheable:!0,_scopes:e,_rootScopes:o,_fallback:i,_getTarget:s,override:a=>Qs([a,...e],t,o,i)};return new Proxy(r,{deleteProperty(a,l){return delete a[l],delete a._keys,delete e[0][l],!0},get(a,l){return sl(a,l,()=>kf(l,t,e,a))},getOwnPropertyDescriptor(a,l){return Reflect.getOwnPropertyDescriptor(a._scopes[0],l)},getPrototypeOf(){return Reflect.getPrototypeOf(e[0])},has(a,l){return Qo(a).includes(l)},ownKeys(a){return Qo(a)},set(a,l,c){const d=a._storage||(a._storage=s());return a[l]=d[l]=c,delete a._keys,!0}})}function Ye(e,t,n,i){const s={_cacheable:!1,_proxy:e,_context:t,_subProxy:n,_stack:new Set,_descriptors:il(e,i),setContext:o=>Ye(e,o,n,i),override:o=>Ye(e.override(o),t,n,i)};return new Proxy(s,{deleteProperty(o,r){return delete o[r],delete e[r],!0},get(o,r,a){return sl(o,r,()=>bf(o,r,a))},getOwnPropertyDescriptor(o,r){return o._descriptors.allKeys?Reflect.has(e,r)?{enumerable:!0,configurable:!0}:void 0:Reflect.getOwnPropertyDescriptor(e,r)},getPrototypeOf(){return Reflect.getPrototypeOf(e)},has(o,r){return Reflect.has(e,r)},ownKeys(){return Reflect.ownKeys(e)},set(o,r,a){return e[r]=a,delete o[r],!0}})}function il(e,t={scriptable:!0,indexable:!0}){const{_scriptable:n=t.scriptable,_indexable:i=t.indexable,_allKeys:s=t.allKeys}=e;return{allKeys:s,scriptable:n,indexable:i,isScriptable:le(n)?n:()=>n,isIndexable:le(i)?i:()=>i}}const mf=(e,t)=>e?e+Xs(t):t,to=(e,t)=>W(t)&&e!=="adapters"&&(Object.getPrototypeOf(t)===null||t.constructor===Object);function sl(e,t,n){if(Object.prototype.hasOwnProperty.call(e,t)||t==="constructor")return e[t];const i=n();return e[t]=i,i}function bf(e,t,n){const{_proxy:i,_context:s,_subProxy:o,_descriptors:r}=e;let a=i[t];return le(a)&&r.isScriptable(t)&&(a=vf(t,a,e,n)),ct(a)&&a.length&&(a=yf(t,a,e,r.isIndexable)),to(t,a)&&(a=Ye(a,s,o&&o[t],r)),a}function vf(e,t,n,i){const{_proxy:s,_context:o,_subProxy:r,_stack:a}=n;if(a.has(e))throw new Error("Recursion detected: "+Array.from(a).join("->")+"->"+e);a.add(e);let l=t(o,r||i);return a.delete(e),to(e,l)&&(l=eo(s._scopes,s,e,l)),l}function yf(e,t,n,i){const{_proxy:s,_context:o,_subProxy:r,_descriptors:a}=n;if(typeof o.index<"u"&&i(e))return t[o.index%t.length];if(W(t[0])){const l=t,c=s._scopes.filter(d=>d!==l);t=[];for(const d of l){const h=eo(c,s,e,d);t.push(Ye(h,o,r&&r[e],a))}}return t}function ol(e,t,n){return le(e)?e(t,n):e}const xf=(e,t)=>e===!0?t:typeof e=="string"?xi(t,e):void 0;function _f(e,t,n,i,s){for(const o of t){const r=xf(n,o);if(r){e.add(r);const a=ol(r._fallback,n,s);if(typeof a<"u"&&a!==n&&a!==i)return a}else if(r===!1&&typeof i<"u"&&n!==i)return null}return!1}function eo(e,t,n,i){const s=t._rootScopes,o=ol(t._fallback,n,i),r=[...e,...s],a=new Set;a.add(i);let l=Jo(a,r,n,o||n,i);return l===null||typeof o<"u"&&o!==n&&(l=Jo(a,r,o,l,i),l===null)?!1:Qs(Array.from(a),[""],s,o,()=>wf(t,n,i))}function Jo(e,t,n,i,s){for(;n;)n=_f(e,t,n,i,s);return n}function wf(e,t,n){const i=e._getTarget();t in i||(i[t]={});const s=i[t];return ct(s)&&W(n)?n:s||{}}function kf(e,t,n,i){let s;for(const o of t)if(s=rl(mf(o,e),n),typeof s<"u")return to(e,s)?eo(n,i,e,s):s}function rl(e,t){for(const n of t){if(!n)continue;const i=n[e];if(typeof i<"u")return i}}function Qo(e){let t=e._keys;return t||(t=e._keys=Sf(e._scopes)),t}function Sf(e){const t=new Set;for(const n of e)for(const i of Object.keys(n).filter(s=>!s.startsWith("_")))t.add(i);return Array.from(t)}const Ef=Number.EPSILON||1e-14,Ge=(e,t)=>t<e.length&&!e[t].skip&&e[t],al=e=>e==="x"?"y":"x";function Tf(e,t,n,i){const s=e.skip?t:e,o=t,r=n.skip?t:n,a=_s(o,s),l=_s(r,o);let c=a/(a+l),d=l/(a+l);c=isNaN(c)?0:c,d=isNaN(d)?0:d;const h=i*c,f=i*d;return{previous:{x:o.x-h*(r.x-s.x),y:o.y-h*(r.y-s.y)},next:{x:o.x+f*(r.x-s.x),y:o.y+f*(r.y-s.y)}}}function Cf(e,t,n){const i=e.length;let s,o,r,a,l,c=Ge(e,0);for(let d=0;d<i-1;++d)if(l=c,c=Ge(e,d+1),!(!l||!c)){if(ke(t[d],0,Ef)){n[d]=n[d+1]=0;continue}s=n[d]/t[d],o=n[d+1]/t[d],a=Math.pow(s,2)+Math.pow(o,2),!(a<=9)&&(r=3/Math.sqrt(a),n[d]=s*r*t[d],n[d+1]=o*r*t[d])}}function Of(e,t,n="x"){const i=al(n),s=e.length;let o,r,a,l=Ge(e,0);for(let c=0;c<s;++c){if(r=a,a=l,l=Ge(e,c+1),!a)continue;const d=a[n],h=a[i];r&&(o=(d-r[n])/3,a[`cp1${n}`]=d-o,a[`cp1${i}`]=h-o*t[c]),l&&(o=(l[n]-d)/3,a[`cp2${n}`]=d+o,a[`cp2${i}`]=h+o*t[c])}}function Mf(e,t="x"){const n=al(t),i=e.length,s=Array(i).fill(0),o=Array(i);let r,a,l,c=Ge(e,0);for(r=0;r<i;++r)if(a=l,l=c,c=Ge(e,r+1),!!l){if(c){const d=c[t]-l[t];s[r]=d!==0?(c[n]-l[n])/d:0}o[r]=a?c?ce(s[r-1])!==ce(s[r])?0:(s[r-1]+s[r])/2:s[r-1]:s[r]}Cf(e,s,o),Of(e,o,t)}function ei(e,t,n){return Math.max(Math.min(e,n),t)}function Pf(e,t){let n,i,s,o,r,a=Ve(e[0],t);for(n=0,i=e.length;n<i;++n)r=o,o=a,a=n<i-1&&Ve(e[n+1],t),o&&(s=e[n],r&&(s.cp1x=ei(s.cp1x,t.left,t.right),s.cp1y=ei(s.cp1y,t.top,t.bottom)),a&&(s.cp2x=ei(s.cp2x,t.left,t.right),s.cp2y=ei(s.cp2y,t.top,t.bottom)))}function Af(e,t,n,i,s){let o,r,a,l;if(t.spanGaps&&(e=e.filter(c=>!c.skip)),t.cubicInterpolationMode==="monotone")Mf(e,s);else{let c=i?e[e.length-1]:e[0];for(o=0,r=e.length;o<r;++o)a=e[o],l=Tf(c,a,e[Math.min(o+1,r-(i?0:1))%r],t.tension),a.cp1x=l.previous.x,a.cp1y=l.previous.y,a.cp2x=l.next.x,a.cp2y=l.next.y,c=a}t.capBezierPoints&&Pf(e,n)}function no(){return typeof window<"u"&&typeof document<"u"}function io(e){let t=e.parentNode;return t&&t.toString()==="[object ShadowRoot]"&&(t=t.host),t}function Si(e,t,n){let i;return typeof e=="string"?(i=parseInt(e,10),e.indexOf("%")!==-1&&(i=i/100*t.parentNode[n])):i=e,i}const zi=e=>e.ownerDocument.defaultView.getComputedStyle(e,null);function Df(e,t){return zi(e).getPropertyValue(t)}const If=["top","right","bottom","left"];function Se(e,t,n){const i={};n=n?"-"+n:"";for(let s=0;s<4;s++){const o=If[s];i[o]=parseFloat(e[t+"-"+o+n])||0}return i.width=i.left+i.right,i.height=i.top+i.bottom,i}const Rf=(e,t,n)=>(e>0||t>0)&&(!n||!n.shadowRoot);function Nf(e,t){const n=e.touches,i=n&&n.length?n[0]:e,{offsetX:s,offsetY:o}=i;let r=!1,a,l;if(Rf(s,o,e.target))a=s,l=o;else{const c=t.getBoundingClientRect();a=i.clientX-c.left,l=i.clientY-c.top,r=!0}return{x:a,y:l,box:r}}function Ut(e,t){if("native"in e)return e;const{canvas:n,currentDevicePixelRatio:i}=t,s=zi(n),o=s.boxSizing==="border-box",r=Se(s,"padding"),a=Se(s,"border","width"),{x:l,y:c,box:d}=Nf(e,n),h=r.left+(d&&a.left),f=r.top+(d&&a.top);let{width:g,height:m}=t;return o&&(g-=r.width+a.width,m-=r.height+a.height),{x:Math.round((l-h)/g*n.width/i),y:Math.round((c-f)/m*n.height/i)}}function Lf(e,t,n){let i,s;if(t===void 0||n===void 0){const o=e&&io(e);if(!o)t=e.clientWidth,n=e.clientHeight;else{const r=o.getBoundingClientRect(),a=zi(o),l=Se(a,"border","width"),c=Se(a,"padding");t=r.width-c.width-l.width,n=r.height-c.height-l.height,i=Si(a.maxWidth,o,"clientWidth"),s=Si(a.maxHeight,o,"clientHeight")}}return{width:t,height:n,maxWidth:i||wi,maxHeight:s||wi}}const ie=e=>Math.round(e*10)/10;function zf(e,t,n,i){const s=zi(e),o=Se(s,"margin"),r=Si(s.maxWidth,e,"clientWidth")||wi,a=Si(s.maxHeight,e,"clientHeight")||wi,l=Lf(e,t,n);let{width:c,height:d}=l;if(s.boxSizing==="content-box"){const f=Se(s,"border","width"),g=Se(s,"padding");c-=g.width+f.width,d-=g.height+f.height}return c=Math.max(0,c-o.width),d=Math.max(0,i?c/i:d-o.height),c=ie(Math.min(c,r,l.maxWidth)),d=ie(Math.min(d,a,l.maxHeight)),c&&!d&&(d=ie(c/2)),(t!==void 0||n!==void 0)&&i&&l.height&&d>l.height&&(d=l.height,c=ie(Math.floor(d*i))),{width:c,height:d}}function tr(e,t,n){const i=t||1,s=ie(e.height*i),o=ie(e.width*i);e.height=ie(e.height),e.width=ie(e.width);const r=e.canvas;return r.style&&(n||!r.style.height&&!r.style.width)&&(r.style.height=`${e.height}px`,r.style.width=`${e.width}px`),e.currentDevicePixelRatio!==i||r.height!==s||r.width!==o?(e.currentDevicePixelRatio=i,r.height=s,r.width=o,e.ctx.setTransform(i,0,0,i,0,0),!0):!1}const $f=(function(){let e=!1;try{const t={get passive(){return e=!0,!1}};no()&&(window.addEventListener("test",null,t),window.removeEventListener("test",null,t))}catch{}return e})();function er(e,t){const n=Df(e,t),i=n&&n.match(/^(\d+)(\.\d+)?px$/);return i?+i[1]:void 0}function xe(e,t,n,i){return{x:e.x+n*(t.x-e.x),y:e.y+n*(t.y-e.y)}}function Ff(e,t,n,i){return{x:e.x+n*(t.x-e.x),y:i==="middle"?n<.5?e.y:t.y:i==="after"?n<1?e.y:t.y:n>0?t.y:e.y}}function Bf(e,t,n,i){const s={x:e.cp2x,y:e.cp2y},o={x:t.cp1x,y:t.cp1y},r=xe(e,s,n),a=xe(s,o,n),l=xe(o,t,n),c=xe(r,a,n),d=xe(a,l,n);return xe(c,d,n)}const Hf=function(e,t){return{x(n){return e+e+t-n},setWidth(n){t=n},textAlign(n){return n==="center"?n:n==="right"?"left":"right"},xPlus(n,i){return n-i},leftForLtr(n,i){return n-i}}},Uf=function(){return{x(e){return e},setWidth(e){},textAlign(e){return e},xPlus(e,t){return e+t},leftForLtr(e,t){return e}}};function Be(e,t,n){return e?Hf(t,n):Uf()}function ll(e,t){let n,i;(t==="ltr"||t==="rtl")&&(n=e.canvas.style,i=[n.getPropertyValue("direction"),n.getPropertyPriority("direction")],n.setProperty("direction",t,"important"),e.prevTextDirection=i)}function cl(e,t){t!==void 0&&(delete e.prevTextDirection,e.canvas.style.setProperty("direction",t[0],t[1]))}function dl(e){return e==="angle"?{between:Ka,compare:$u,normalize:Ht}:{between:$e,compare:(t,n)=>t-n,normalize:t=>t}}function nr({start:e,end:t,count:n,loop:i,style:s}){return{start:e%n,end:t%n,loop:i&&(t-e+1)%n===0,style:s}}function Wf(e,t,n){const{property:i,start:s,end:o}=n,{between:r,normalize:a}=dl(i),l=t.length;let{start:c,end:d,loop:h}=e,f,g;if(h){for(c+=l,d+=l,f=0,g=l;f<g&&r(a(t[c%l][i]),s,o);++f)c--,d--;c%=l,d%=l}return d<c&&(d+=l),{start:c,end:d,loop:h,style:e.style}}function hl(e,t,n){if(!n)return[e];const{property:i,start:s,end:o}=n,r=t.length,{compare:a,between:l,normalize:c}=dl(i),{start:d,end:h,loop:f,style:g}=Wf(e,t,n),m=[];let v=!1,y=null,_,E,O;const M=()=>l(s,O,_)&&a(s,O)!==0,k=()=>a(o,_)===0||l(o,O,_),C=()=>v||M(),A=()=>!v||k();for(let P=d,I=d;P<=h;++P)E=t[P%r],!E.skip&&(_=c(E[i]),_!==O&&(v=l(_,s,o),y===null&&C()&&(y=a(_,s)===0?P:I),y!==null&&A()&&(m.push(nr({start:y,end:P,loop:f,count:r,style:g})),y=null),I=P,O=_));return y!==null&&m.push(nr({start:y,end:h,loop:f,count:r,style:g})),m}function ul(e,t){const n=[],i=e.segments;for(let s=0;s<i.length;s++){const o=hl(i[s],e.points,t);o.length&&n.push(...o)}return n}function jf(e,t,n,i){let s=0,o=t-1;if(n&&!i)for(;s<t&&!e[s].skip;)s++;for(;s<t&&e[s].skip;)s++;for(s%=t,n&&(o+=s);o>s&&e[o%t].skip;)o--;return o%=t,{start:s,end:o}}function Vf(e,t,n,i){const s=e.length,o=[];let r=t,a=e[t],l;for(l=t+1;l<=n;++l){const c=e[l%s];c.skip||c.stop?a.skip||(i=!1,o.push({start:t%s,end:(l-1)%s,loop:i}),t=r=c.stop?l:null):(r=l,a.skip&&(t=l)),a=c}return r!==null&&o.push({start:t%s,end:r%s,loop:i}),o}function Yf(e,t){const n=e.points,i=e.options.spanGaps,s=n.length;if(!s)return[];const o=!!e._loop,{start:r,end:a}=jf(n,s,o,i);if(i===!0)return ir(e,[{start:r,end:a,loop:o}],n,t);const l=a<r?a+s:a,c=!!e._fullLoop&&r===0&&a===s-1;return ir(e,Vf(n,r,l,c),n,t)}function ir(e,t,n,i){return!i||!i.setContext||!n?t:Gf(e,t,n,i)}function Gf(e,t,n,i){const s=e._chart.getContext(),o=sr(e.options),{_datasetIndex:r,options:{spanGaps:a}}=e,l=n.length,c=[];let d=o,h=t[0].start,f=h;function g(m,v,y,_){const E=a?-1:1;if(m!==v){for(m+=l;n[m%l].skip;)m-=E;for(;n[v%l].skip;)v+=E;m%l!==v%l&&(c.push({start:m%l,end:v%l,loop:y,style:_}),d=_,h=v%l)}}for(const m of t){h=a?h:m.start;let v=n[h%l],y;for(f=h+1;f<=m.end;f++){const _=n[f%l];y=sr(i.setContext(Ae(s,{type:"segment",p0:v,p1:_,p0DataIndex:(f-1)%l,p1DataIndex:f%l,datasetIndex:r}))),Kf(y,d)&&g(h,f-1,m.loop,d),v=_,d=y}h<f-1&&g(h,f-1,m.loop,d)}return c}function sr(e){return{backgroundColor:e.backgroundColor,borderCapStyle:e.borderCapStyle,borderDash:e.borderDash,borderDashOffset:e.borderDashOffset,borderJoinStyle:e.borderJoinStyle,borderWidth:e.borderWidth,borderColor:e.borderColor}}function Kf(e,t){if(!t)return!1;const n=[],i=function(s,o){return Js(o)?(n.includes(o)||n.push(o),n.indexOf(o)):o};return JSON.stringify(e,i)!==JSON.stringify(t,i)}function ni(e,t,n){return e.options.clip?e[n]:t[n]}function qf(e,t){const{xScale:n,yScale:i}=e;return n&&i?{left:ni(n,t,"left"),right:ni(n,t,"right"),top:ni(i,t,"top"),bottom:ni(i,t,"bottom")}:t}function fl(e,t){const n=t._clip;if(n.disabled)return!1;const i=qf(t,e.chartArea);return{left:n.left===!1?0:i.left-(n.left===!0?0:n.left),right:n.right===!1?e.width:i.right+(n.right===!0?0:n.right),top:n.top===!1?0:i.top-(n.top===!0?0:n.top),bottom:n.bottom===!1?e.height:i.bottom+(n.bottom===!0?0:n.bottom)}}/*!
 * Chart.js v4.5.1
 * https://www.chartjs.org
 * (c) 2025 Chart.js Contributors
 * Released under the MIT License
 */class Xf{constructor(){this._request=null,this._charts=new Map,this._running=!1,this._lastDate=void 0}_notify(t,n,i,s){const o=n.listeners[s],r=n.duration;o.forEach(a=>a({chart:t,initial:n.initial,numSteps:r,currentStep:Math.min(i-n.start,r)}))}_refresh(){this._request||(this._running=!0,this._request=Xa.call(window,()=>{this._update(),this._request=null,this._running&&this._refresh()}))}_update(t=Date.now()){let n=0;this._charts.forEach((i,s)=>{if(!i.running||!i.items.length)return;const o=i.items;let r=o.length-1,a=!1,l;for(;r>=0;--r)l=o[r],l._active?(l._total>i.duration&&(i.duration=l._total),l.tick(t),a=!0):(o[r]=o[o.length-1],o.pop());a&&(s.draw(),this._notify(s,i,t,"progress")),o.length||(i.running=!1,this._notify(s,i,t,"complete"),i.initial=!1),n+=o.length}),this._lastDate=t,n===0&&(this._running=!1)}_getAnims(t){const n=this._charts;let i=n.get(t);return i||(i={running:!1,initial:!0,items:[],listeners:{complete:[],progress:[]}},n.set(t,i)),i}listen(t,n,i){this._getAnims(t).listeners[n].push(i)}add(t,n){!n||!n.length||this._getAnims(t).items.push(...n)}has(t){return this._getAnims(t).items.length>0}start(t){const n=this._charts.get(t);n&&(n.running=!0,n.start=Date.now(),n.duration=n.items.reduce((i,s)=>Math.max(i,s._duration),0),this._refresh())}running(t){if(!this._running)return!1;const n=this._charts.get(t);return!(!n||!n.running||!n.items.length)}stop(t){const n=this._charts.get(t);if(!n||!n.items.length)return;const i=n.items;let s=i.length-1;for(;s>=0;--s)i[s].cancel();n.items=[],this._notify(t,n,Date.now(),"complete")}remove(t){return this._charts.delete(t)}}var qt=new Xf;const or="transparent",Zf={boolean(e,t,n){return n>.5?t:e},color(e,t,n){const i=Ko(e||or),s=i.valid&&Ko(t||or);return s&&s.valid?s.mix(i,n).hexString():t},number(e,t,n){return e+(t-e)*n}};class Jf{constructor(t,n,i,s){const o=n[i];s=ti([t.to,s,o,t.from]);const r=ti([t.from,o,s]);this._active=!0,this._fn=t.fn||Zf[t.type||typeof r],this._easing=pn[t.easing]||pn.linear,this._start=Math.floor(Date.now()+(t.delay||0)),this._duration=this._total=Math.floor(t.duration),this._loop=!!t.loop,this._target=n,this._prop=i,this._from=r,this._to=s,this._promises=void 0}active(){return this._active}update(t,n,i){if(this._active){this._notify(!1);const s=this._target[this._prop],o=i-this._start,r=this._duration-o;this._start=i,this._duration=Math.floor(Math.max(r,t.duration)),this._total+=o,this._loop=!!t.loop,this._to=ti([t.to,n,s,t.from]),this._from=ti([t.from,s,n])}}cancel(){this._active&&(this.tick(Date.now()),this._active=!1,this._notify(!1))}tick(t){const n=t-this._start,i=this._duration,s=this._prop,o=this._from,r=this._loop,a=this._to;let l;if(this._active=o!==a&&(r||n<i),!this._active){this._target[s]=a,this._notify(!0);return}if(n<0){this._target[s]=o;return}l=n/i%2,l=r&&l>1?2-l:l,l=this._easing(Math.min(1,Math.max(0,l))),this._target[s]=this._fn(o,a,l)}wait(){const t=this._promises||(this._promises=[]);return new Promise((n,i)=>{t.push({res:n,rej:i})})}_notify(t){const n=t?"res":"rej",i=this._promises||[];for(let s=0;s<i.length;s++)i[s][n]()}}class pl{constructor(t,n){this._chart=t,this._properties=new Map,this.configure(n)}configure(t){if(!W(t))return;const n=Object.keys(Q.animation),i=this._properties;Object.getOwnPropertyNames(t).forEach(s=>{const o=t[s];if(!W(o))return;const r={};for(const a of n)r[a]=o[a];(ct(o.properties)&&o.properties||[s]).forEach(a=>{(a===s||!i.has(a))&&i.set(a,r)})})}_animateOptions(t,n){const i=n.options,s=tp(t,i);if(!s)return[];const o=this._createAnimations(s,i);return i.$shared&&Qf(t.options.$animations,i).then(()=>{t.options=i},()=>{}),o}_createAnimations(t,n){const i=this._properties,s=[],o=t.$animations||(t.$animations={}),r=Object.keys(n),a=Date.now();let l;for(l=r.length-1;l>=0;--l){const c=r[l];if(c.charAt(0)==="$")continue;if(c==="options"){s.push(...this._animateOptions(t,n));continue}const d=n[c];let h=o[c];const f=i.get(c);if(h)if(f&&h.active()){h.update(f,d,a);continue}else h.cancel();if(!f||!f.duration){t[c]=d;continue}o[c]=h=new Jf(f,t,c,d),s.push(h)}return s}update(t,n){if(this._properties.size===0){Object.assign(t,n);return}const i=this._createAnimations(t,n);if(i.length)return qt.add(this._chart,i),!0}}function Qf(e,t){const n=[],i=Object.keys(t);for(let s=0;s<i.length;s++){const o=e[i[s]];o&&o.active()&&n.push(o.wait())}return Promise.all(n)}function tp(e,t){if(!t)return;let n=e.options;if(!n){e.options=t;return}return n.$shared&&(e.options=n=Object.assign({},n,{$shared:!1,$animations:{}})),n}function rr(e,t){const n=e&&e.options||{},i=n.reverse,s=n.min===void 0?t:0,o=n.max===void 0?t:0;return{start:i?o:s,end:i?s:o}}function ep(e,t,n){if(n===!1)return!1;const i=rr(e,n),s=rr(t,n);return{top:s.end,right:i.end,bottom:s.start,left:i.start}}function np(e){let t,n,i,s;return W(e)?(t=e.top,n=e.right,i=e.bottom,s=e.left):t=n=i=s=e,{top:t,right:n,bottom:i,left:s,disabled:e===!1}}function gl(e,t){const n=[],i=e._getSortedDatasetMetas(t);let s,o;for(s=0,o=i.length;s<o;++s)n.push(i[s].index);return n}function ar(e,t,n,i={}){const s=e.keys,o=i.mode==="single";let r,a,l,c;if(t===null)return;let d=!1;for(r=0,a=s.length;r<a;++r){if(l=+s[r],l===n){if(d=!0,i.all)continue;break}c=e.values[l],ft(c)&&(o||t===0||ce(t)===ce(c))&&(t+=c)}return!d&&!i.all?0:t}function ip(e,t){const{iScale:n,vScale:i}=t,s=n.axis==="x"?"x":"y",o=i.axis==="x"?"x":"y",r=Object.keys(e),a=new Array(r.length);let l,c,d;for(l=0,c=r.length;l<c;++l)d=r[l],a[l]={[s]:d,[o]:e[d]};return a}function es(e,t){const n=e&&e.options.stacked;return n||n===void 0&&t.stack!==void 0}function sp(e,t,n){return`${e.id}.${t.id}.${n.stack||n.type}`}function op(e){const{min:t,max:n,minDefined:i,maxDefined:s}=e.getUserBounds();return{min:i?t:Number.NEGATIVE_INFINITY,max:s?n:Number.POSITIVE_INFINITY}}function rp(e,t,n){const i=e[t]||(e[t]={});return i[n]||(i[n]={})}function lr(e,t,n,i){for(const s of t.getMatchingVisibleMetas(i).reverse()){const o=e[s.index];if(n&&o>0||!n&&o<0)return s.index}return null}function cr(e,t){const{chart:n,_cachedMeta:i}=e,s=n._stacks||(n._stacks={}),{iScale:o,vScale:r,index:a}=i,l=o.axis,c=r.axis,d=sp(o,r,i),h=t.length;let f;for(let g=0;g<h;++g){const m=t[g],{[l]:v,[c]:y}=m,_=m._stacks||(m._stacks={});f=_[c]=rp(s,d,v),f[a]=y,f._top=lr(f,r,!0,i.type),f._bottom=lr(f,r,!1,i.type);const E=f._visualValues||(f._visualValues={});E[a]=y}}function ns(e,t){const n=e.scales;return Object.keys(n).filter(i=>n[i].axis===t).shift()}function ap(e,t){return Ae(e,{active:!1,dataset:void 0,datasetIndex:t,index:t,mode:"default",type:"dataset"})}function lp(e,t,n){return Ae(e,{active:!1,dataIndex:t,parsed:void 0,raw:void 0,element:n,index:t,mode:"default",type:"data"})}function on(e,t){const n=e.controller.index,i=e.vScale&&e.vScale.axis;if(i){t=t||e._parsed;for(const s of t){const o=s._stacks;if(!o||o[i]===void 0||o[i][n]===void 0)return;delete o[i][n],o[i]._visualValues!==void 0&&o[i]._visualValues[n]!==void 0&&delete o[i]._visualValues[n]}}}const is=e=>e==="reset"||e==="none",dr=(e,t)=>t?e:Object.assign({},e),cp=(e,t,n)=>e&&!t.hidden&&t._stacked&&{keys:gl(n,!0),values:null};class bn{constructor(t,n){this.chart=t,this._ctx=t.ctx,this.index=n,this._cachedDataOpts={},this._cachedMeta=this.getMeta(),this._type=this._cachedMeta.type,this.options=void 0,this._parsing=!1,this._data=void 0,this._objectData=void 0,this._sharedOptions=void 0,this._drawStart=void 0,this._drawCount=void 0,this.enableOptionSharing=!1,this.supportsDecimation=!1,this.$context=void 0,this._syncList=[],this.datasetElementType=new.target.datasetElementType,this.dataElementType=new.target.dataElementType,this.initialize()}initialize(){const t=this._cachedMeta;this.configure(),this.linkScales(),t._stacked=es(t.vScale,t),this.addElements(),this.options.fill&&!this.chart.isPluginEnabled("filler")&&console.warn("Tried to use the 'fill' option without the 'Filler' plugin enabled. Please import and register the 'Filler' plugin and make sure it is not disabled in the options")}updateIndex(t){this.index!==t&&on(this._cachedMeta),this.index=t}linkScales(){const t=this.chart,n=this._cachedMeta,i=this.getDataset(),s=(h,f,g,m)=>h==="x"?f:h==="r"?m:g,o=n.xAxisID=B(i.xAxisID,ns(t,"x")),r=n.yAxisID=B(i.yAxisID,ns(t,"y")),a=n.rAxisID=B(i.rAxisID,ns(t,"r")),l=n.indexAxis,c=n.iAxisID=s(l,o,r,a),d=n.vAxisID=s(l,r,o,a);n.xScale=this.getScaleForId(o),n.yScale=this.getScaleForId(r),n.rScale=this.getScaleForId(a),n.iScale=this.getScaleForId(c),n.vScale=this.getScaleForId(d)}getDataset(){return this.chart.data.datasets[this.index]}getMeta(){return this.chart.getDatasetMeta(this.index)}getScaleForId(t){return this.chart.scales[t]}_getOtherScale(t){const n=this._cachedMeta;return t===n.iScale?n.vScale:n.iScale}reset(){this._update("reset")}_destroy(){const t=this._cachedMeta;this._data&&Vo(this._data,this),t._stacked&&on(t)}_dataCheck(){const t=this.getDataset(),n=t.data||(t.data=[]),i=this._data;if(W(n)){const s=this._cachedMeta;this._data=ip(n,s)}else if(i!==n){if(i){Vo(i,this);const s=this._cachedMeta;on(s),s._parsed=[]}n&&Object.isExtensible(n)&&Uu(n,this),this._syncList=[],this._data=n}}addElements(){const t=this._cachedMeta;this._dataCheck(),this.datasetElementType&&(t.dataset=new this.datasetElementType)}buildOrUpdateElements(t){const n=this._cachedMeta,i=this.getDataset();let s=!1;this._dataCheck();const o=n._stacked;n._stacked=es(n.vScale,n),n.stack!==i.stack&&(s=!0,on(n),n.stack=i.stack),this._resyncElements(t),(s||o!==n._stacked)&&(cr(this,n._parsed),n._stacked=es(n.vScale,n))}configure(){const t=this.chart.config,n=t.datasetScopeKeys(this._type),i=t.getOptionScopes(this.getDataset(),n,!0);this.options=t.createResolver(i,this.getContext()),this._parsing=this.options.parsing,this._cachedDataOpts={}}parse(t,n){const{_cachedMeta:i,_data:s}=this,{iScale:o,_stacked:r}=i,a=o.axis;let l=t===0&&n===s.length?!0:i._sorted,c=t>0&&i._parsed[t-1],d,h,f;if(this._parsing===!1)i._parsed=s,i._sorted=!0,f=s;else{ct(s[t])?f=this.parseArrayData(i,s,t,n):W(s[t])?f=this.parseObjectData(i,s,t,n):f=this.parsePrimitiveData(i,s,t,n);const g=()=>h[a]===null||c&&h[a]<c[a];for(d=0;d<n;++d)i._parsed[d+t]=h=f[d],l&&(g()&&(l=!1),c=h);i._sorted=l}r&&cr(this,f)}parsePrimitiveData(t,n,i,s){const{iScale:o,vScale:r}=t,a=o.axis,l=r.axis,c=o.getLabels(),d=o===r,h=new Array(s);let f,g,m;for(f=0,g=s;f<g;++f)m=f+i,h[f]={[a]:d||o.parse(c[m],m),[l]:r.parse(n[m],m)};return h}parseArrayData(t,n,i,s){const{xScale:o,yScale:r}=t,a=new Array(s);let l,c,d,h;for(l=0,c=s;l<c;++l)d=l+i,h=n[d],a[l]={x:o.parse(h[0],d),y:r.parse(h[1],d)};return a}parseObjectData(t,n,i,s){const{xScale:o,yScale:r}=t,{xAxisKey:a="x",yAxisKey:l="y"}=this._parsing,c=new Array(s);let d,h,f,g;for(d=0,h=s;d<h;++d)f=d+i,g=n[f],c[d]={x:o.parse(xi(g,a),f),y:r.parse(xi(g,l),f)};return c}getParsed(t){return this._cachedMeta._parsed[t]}getDataElement(t){return this._cachedMeta.data[t]}applyStack(t,n,i){const s=this.chart,o=this._cachedMeta,r=n[t.axis],a={keys:gl(s,!0),values:n._stacks[t.axis]._visualValues};return ar(a,r,o.index,{mode:i})}updateRangeFromParsed(t,n,i,s){const o=i[n.axis];let r=o===null?NaN:o;const a=s&&i._stacks[n.axis];s&&a&&(s.values=a,r=ar(s,o,this._cachedMeta.index)),t.min=Math.min(t.min,r),t.max=Math.max(t.max,r)}getMinMax(t,n){const i=this._cachedMeta,s=i._parsed,o=i._sorted&&t===i.iScale,r=s.length,a=this._getOtherScale(t),l=cp(n,i,this.chart),c={min:Number.POSITIVE_INFINITY,max:Number.NEGATIVE_INFINITY},{min:d,max:h}=op(a);let f,g;function m(){g=s[f];const v=g[a.axis];return!ft(g[t.axis])||d>v||h<v}for(f=0;f<r&&!(!m()&&(this.updateRangeFromParsed(c,t,g,l),o));++f);if(o){for(f=r-1;f>=0;--f)if(!m()){this.updateRangeFromParsed(c,t,g,l);break}}return c}getAllParsedValues(t){const n=this._cachedMeta._parsed,i=[];let s,o,r;for(s=0,o=n.length;s<o;++s)r=n[s][t.axis],ft(r)&&i.push(r);return i}getMaxOverflow(){return!1}getLabelAndValue(t){const n=this._cachedMeta,i=n.iScale,s=n.vScale,o=this.getParsed(t);return{label:i?""+i.getLabelForValue(o[i.axis]):"",value:s?""+s.getLabelForValue(o[s.axis]):""}}_update(t){const n=this._cachedMeta;this.update(t||"default"),n._clip=np(B(this.options.clip,ep(n.xScale,n.yScale,this.getMaxOverflow())))}update(t){}draw(){const t=this._ctx,n=this.chart,i=this._cachedMeta,s=i.data||[],o=n.chartArea,r=[],a=this._drawStart||0,l=this._drawCount||s.length-a,c=this.options.drawActiveElementsOnTop;let d;for(i.dataset&&i.dataset.draw(t,o,a,l),d=a;d<a+l;++d){const h=s[d];h.hidden||(h.active&&c?r.push(h):h.draw(t,o))}for(d=0;d<r.length;++d)r[d].draw(t,o)}getStyle(t,n){const i=n?"active":"default";return t===void 0&&this._cachedMeta.dataset?this.resolveDatasetElementOptions(i):this.resolveDataElementOptions(t||0,i)}getContext(t,n,i){const s=this.getDataset();let o;if(t>=0&&t<this._cachedMeta.data.length){const r=this._cachedMeta.data[t];o=r.$context||(r.$context=lp(this.getContext(),t,r)),o.parsed=this.getParsed(t),o.raw=s.data[t],o.index=o.dataIndex=t}else o=this.$context||(this.$context=ap(this.chart.getContext(),this.index)),o.dataset=s,o.index=o.datasetIndex=this.index;return o.active=!!n,o.mode=i,o}resolveDatasetElementOptions(t){return this._resolveElementOptions(this.datasetElementType.id,t)}resolveDataElementOptions(t,n){return this._resolveElementOptions(this.dataElementType.id,n,t)}_resolveElementOptions(t,n="default",i){const s=n==="active",o=this._cachedDataOpts,r=t+"-"+n,a=o[r],l=this.enableOptionSharing&&_i(i);if(a)return dr(a,l);const c=this.chart.config,d=c.datasetElementScopeKeys(this._type,t),h=s?[`${t}Hover`,"hover",t,""]:[t,""],f=c.getOptionScopes(this.getDataset(),d),g=Object.keys(Q.elements[t]),m=()=>this.getContext(i,s,n),v=c.resolveNamedOptions(f,g,m,h);return v.$shared&&(v.$shared=l,o[r]=Object.freeze(dr(v,l))),v}_resolveAnimations(t,n,i){const s=this.chart,o=this._cachedDataOpts,r=`animation-${n}`,a=o[r];if(a)return a;let l;if(s.options.animation!==!1){const d=this.chart.config,h=d.datasetAnimationScopeKeys(this._type,n),f=d.getOptionScopes(this.getDataset(),h);l=d.createResolver(f,this.getContext(t,i,n))}const c=new pl(s,l&&l.animations);return l&&l._cacheable&&(o[r]=Object.freeze(c)),c}getSharedOptions(t){if(t.$shared)return this._sharedOptions||(this._sharedOptions=Object.assign({},t))}includeOptions(t,n){return!n||is(t)||this.chart._animationsDisabled}_getSharedOptions(t,n){const i=this.resolveDataElementOptions(t,n),s=this._sharedOptions,o=this.getSharedOptions(i),r=this.includeOptions(n,o)||o!==s;return this.updateSharedOptions(o,n,i),{sharedOptions:o,includeOptions:r}}updateElement(t,n,i,s){is(s)?Object.assign(t,i):this._resolveAnimations(n,s).update(t,i)}updateSharedOptions(t,n,i){t&&!is(n)&&this._resolveAnimations(void 0,n).update(t,i)}_setStyle(t,n,i,s){t.active=s;const o=this.getStyle(n,s);this._resolveAnimations(n,i,s).update(t,{options:!s&&this.getSharedOptions(o)||o})}removeHoverStyle(t,n,i){this._setStyle(t,i,"active",!1)}setHoverStyle(t,n,i){this._setStyle(t,i,"active",!0)}_removeDatasetHoverStyle(){const t=this._cachedMeta.dataset;t&&this._setStyle(t,void 0,"active",!1)}_setDatasetHoverStyle(){const t=this._cachedMeta.dataset;t&&this._setStyle(t,void 0,"active",!0)}_resyncElements(t){const n=this._data,i=this._cachedMeta.data;for(const[a,l,c]of this._syncList)this[a](l,c);this._syncList=[];const s=i.length,o=n.length,r=Math.min(o,s);r&&this.parse(0,r),o>s?this._insertElements(s,o-s,t):o<s&&this._removeElements(o,s-o)}_insertElements(t,n,i=!0){const s=this._cachedMeta,o=s.data,r=t+n;let a;const l=c=>{for(c.length+=n,a=c.length-1;a>=r;a--)c[a]=c[a-n]};for(l(o),a=t;a<r;++a)o[a]=new this.dataElementType;this._parsing&&l(s._parsed),this.parse(t,n),i&&this.updateElements(o,t,n,"reset")}updateElements(t,n,i,s){}_removeElements(t,n){const i=this._cachedMeta;if(this._parsing){const s=i._parsed.splice(t,n);i._stacked&&on(i,s)}i.data.splice(t,n)}_sync(t){if(this._parsing)this._syncList.push(t);else{const[n,i,s]=t;this[n](i,s)}this.chart._dataChanges.push([this.index,...t])}_onDataPush(){const t=arguments.length;this._sync(["_insertElements",this.getDataset().data.length-t,t])}_onDataPop(){this._sync(["_removeElements",this._cachedMeta.data.length-1,1])}_onDataShift(){this._sync(["_removeElements",0,1])}_onDataSplice(t,n){n&&this._sync(["_removeElements",t,n]);const i=arguments.length-2;i&&this._sync(["_insertElements",t,i])}_onDataUnshift(){this._sync(["_insertElements",0,arguments.length])}}F(bn,"defaults",{}),F(bn,"datasetElementType",null),F(bn,"dataElementType",null);class di extends bn{initialize(){this.enableOptionSharing=!0,this.supportsDecimation=!0,super.initialize()}update(t){const n=this._cachedMeta,{dataset:i,data:s=[],_dataset:o}=n,r=this.chart._animationsDisabled;let{start:a,count:l}=Yu(n,s,r);this._drawStart=a,this._drawCount=l,Gu(n)&&(a=0,l=s.length),i._chart=this.chart,i._datasetIndex=this.index,i._decimated=!!o._decimated,i.points=s;const c=this.resolveDatasetElementOptions(t);this.options.showLine||(c.borderWidth=0),c.segment=this.options.segment,this.updateElement(i,void 0,{animated:!r,options:c},t),this.updateElements(s,a,l,t)}updateElements(t,n,i,s){const o=s==="reset",{iScale:r,vScale:a,_stacked:l,_dataset:c}=this._cachedMeta,{sharedOptions:d,includeOptions:h}=this._getSharedOptions(n,s),f=r.axis,g=a.axis,{spanGaps:m,segment:v}=this.options,y=Cn(m)?m:Number.POSITIVE_INFINITY,_=this.chart._animationsDisabled||o||s==="none",E=n+i,O=t.length;let M=n>0&&this.getParsed(n-1);for(let k=0;k<O;++k){const C=t[k],A=_?C:{};if(k<n||k>=E){A.skip=!0;continue}const P=this.getParsed(k),I=G(P[g]),z=A[f]=r.getPixelForValue(P[f],k),R=A[g]=o||I?a.getBasePixel():a.getPixelForValue(l?this.applyStack(a,P,l):P[g],k);A.skip=isNaN(z)||isNaN(R)||I,A.stop=k>0&&Math.abs(P[f]-M[f])>y,v&&(A.parsed=P,A.raw=c.data[k]),h&&(A.options=d||this.resolveDataElementOptions(k,C.active?"active":s)),_||this.updateElement(C,k,A,s),M=P}}getMaxOverflow(){const t=this._cachedMeta,n=t.dataset,i=n.options&&n.options.borderWidth||0,s=t.data||[];if(!s.length)return i;const o=s[0].size(this.resolveDataElementOptions(0)),r=s[s.length-1].size(this.resolveDataElementOptions(s.length-1));return Math.max(i,o,r)/2}draw(){const t=this._cachedMeta;t.dataset.updateControlPoints(this.chart.chartArea,t.iScale.axis),super.draw()}}F(di,"id","line"),F(di,"defaults",{datasetElementType:"line",dataElementType:"point",showLine:!0,spanGaps:!1}),F(di,"overrides",{scales:{_index_:{type:"category"},_value_:{type:"linear"}}});function ye(){throw new Error("This method is not implemented: Check that a complete date adapter is provided.")}class so{constructor(t){F(this,"options");this.options=t||{}}static override(t){Object.assign(so.prototype,t)}init(){}formats(){return ye()}parse(){return ye()}format(){return ye()}add(){return ye()}diff(){return ye()}startOf(){return ye()}endOf(){return ye()}}var dp={_date:so};function hp(e,t,n,i){const{controller:s,data:o,_sorted:r}=e,a=s._cachedMeta.iScale,l=e.dataset&&e.dataset.options?e.dataset.options.spanGaps:null;if(a&&t===a.axis&&t!=="r"&&r&&o.length){const c=a._reversePixels?Bu:we;if(i){if(s._sharedOptions){const d=o[0],h=typeof d.getRange=="function"&&d.getRange(t);if(h){const f=c(o,t,n-h),g=c(o,t,n+h);return{lo:f.lo,hi:g.hi}}}}else{const d=c(o,t,n);if(l){const{vScale:h}=s._cachedMeta,{_parsed:f}=e,g=f.slice(0,d.lo+1).reverse().findIndex(v=>!G(v[h.axis]));d.lo-=Math.max(0,g);const m=f.slice(d.hi).findIndex(v=>!G(v[h.axis]));d.hi+=Math.max(0,m)}return d}}return{lo:0,hi:o.length-1}}function $i(e,t,n,i,s){const o=e.getSortedVisibleDatasetMetas(),r=n[t];for(let a=0,l=o.length;a<l;++a){const{index:c,data:d}=o[a],{lo:h,hi:f}=hp(o[a],t,r,s);for(let g=h;g<=f;++g){const m=d[g];m.skip||i(m,c,g)}}}function up(e){const t=e.indexOf("x")!==-1,n=e.indexOf("y")!==-1;return function(i,s){const o=t?Math.abs(i.x-s.x):0,r=n?Math.abs(i.y-s.y):0;return Math.sqrt(Math.pow(o,2)+Math.pow(r,2))}}function ss(e,t,n,i,s){const o=[];return!s&&!e.isPointInArea(t)||$i(e,n,t,function(a,l,c){!s&&!Ve(a,e.chartArea,0)||a.inRange(t.x,t.y,i)&&o.push({element:a,datasetIndex:l,index:c})},!0),o}function fp(e,t,n,i){let s=[];function o(r,a,l){const{startAngle:c,endAngle:d}=r.getProps(["startAngle","endAngle"],i),{angle:h}=zu(r,{x:t.x,y:t.y});Ka(h,c,d)&&s.push({element:r,datasetIndex:a,index:l})}return $i(e,n,t,o),s}function pp(e,t,n,i,s,o){let r=[];const a=up(n);let l=Number.POSITIVE_INFINITY;function c(d,h,f){const g=d.inRange(t.x,t.y,s);if(i&&!g)return;const m=d.getCenterPoint(s);if(!(!!o||e.isPointInArea(m))&&!g)return;const y=a(t,m);y<l?(r=[{element:d,datasetIndex:h,index:f}],l=y):y===l&&r.push({element:d,datasetIndex:h,index:f})}return $i(e,n,t,c),r}function os(e,t,n,i,s,o){return!o&&!e.isPointInArea(t)?[]:n==="r"&&!i?fp(e,t,n,s):pp(e,t,n,i,s,o)}function hr(e,t,n,i,s){const o=[],r=n==="x"?"inXRange":"inYRange";let a=!1;return $i(e,n,t,(l,c,d)=>{l[r]&&l[r](t[n],s)&&(o.push({element:l,datasetIndex:c,index:d}),a=a||l.inRange(t.x,t.y,s))}),i&&!a?[]:o}var gp={modes:{index(e,t,n,i){const s=Ut(t,e),o=n.axis||"x",r=n.includeInvisible||!1,a=n.intersect?ss(e,s,o,i,r):os(e,s,o,!1,i,r),l=[];return a.length?(e.getSortedVisibleDatasetMetas().forEach(c=>{const d=a[0].index,h=c.data[d];h&&!h.skip&&l.push({element:h,datasetIndex:c.index,index:d})}),l):[]},dataset(e,t,n,i){const s=Ut(t,e),o=n.axis||"xy",r=n.includeInvisible||!1;let a=n.intersect?ss(e,s,o,i,r):os(e,s,o,!1,i,r);if(a.length>0){const l=a[0].datasetIndex,c=e.getDatasetMeta(l).data;a=[];for(let d=0;d<c.length;++d)a.push({element:c[d],datasetIndex:l,index:d})}return a},point(e,t,n,i){const s=Ut(t,e),o=n.axis||"xy",r=n.includeInvisible||!1;return ss(e,s,o,i,r)},nearest(e,t,n,i){const s=Ut(t,e),o=n.axis||"xy",r=n.includeInvisible||!1;return os(e,s,o,n.intersect,i,r)},x(e,t,n,i){const s=Ut(t,e);return hr(e,s,"x",n.intersect,i)},y(e,t,n,i){const s=Ut(t,e);return hr(e,s,"y",n.intersect,i)}}};const ml=["left","top","right","bottom"];function rn(e,t){return e.filter(n=>n.pos===t)}function ur(e,t){return e.filter(n=>ml.indexOf(n.pos)===-1&&n.box.axis===t)}function an(e,t){return e.sort((n,i)=>{const s=t?i:n,o=t?n:i;return s.weight===o.weight?s.index-o.index:s.weight-o.weight})}function mp(e){const t=[];let n,i,s,o,r,a;for(n=0,i=(e||[]).length;n<i;++n)s=e[n],{position:o,options:{stack:r,stackWeight:a=1}}=s,t.push({index:n,box:s,pos:o,horizontal:s.isHorizontal(),weight:s.weight,stack:r&&o+r,stackWeight:a});return t}function bp(e){const t={};for(const n of e){const{stack:i,pos:s,stackWeight:o}=n;if(!i||!ml.includes(s))continue;const r=t[i]||(t[i]={count:0,placed:0,weight:0,size:0});r.count++,r.weight+=o}return t}function vp(e,t){const n=bp(e),{vBoxMaxWidth:i,hBoxMaxHeight:s}=t;let o,r,a;for(o=0,r=e.length;o<r;++o){a=e[o];const{fullSize:l}=a.box,c=n[a.stack],d=c&&a.stackWeight/c.weight;a.horizontal?(a.width=d?d*i:l&&t.availableWidth,a.height=s):(a.width=i,a.height=d?d*s:l&&t.availableHeight)}return n}function yp(e){const t=mp(e),n=an(t.filter(c=>c.box.fullSize),!0),i=an(rn(t,"left"),!0),s=an(rn(t,"right")),o=an(rn(t,"top"),!0),r=an(rn(t,"bottom")),a=ur(t,"x"),l=ur(t,"y");return{fullSize:n,leftAndTop:i.concat(o),rightAndBottom:s.concat(l).concat(r).concat(a),chartArea:rn(t,"chartArea"),vertical:i.concat(s).concat(l),horizontal:o.concat(r).concat(a)}}function fr(e,t,n,i){return Math.max(e[n],t[n])+Math.max(e[i],t[i])}function bl(e,t){e.top=Math.max(e.top,t.top),e.left=Math.max(e.left,t.left),e.bottom=Math.max(e.bottom,t.bottom),e.right=Math.max(e.right,t.right)}function xp(e,t,n,i){const{pos:s,box:o}=n,r=e.maxPadding;if(!W(s)){n.size&&(e[s]-=n.size);const h=i[n.stack]||{size:0,count:1};h.size=Math.max(h.size,n.horizontal?o.height:o.width),n.size=h.size/h.count,e[s]+=n.size}o.getPadding&&bl(r,o.getPadding());const a=Math.max(0,t.outerWidth-fr(r,e,"left","right")),l=Math.max(0,t.outerHeight-fr(r,e,"top","bottom")),c=a!==e.w,d=l!==e.h;return e.w=a,e.h=l,n.horizontal?{same:c,other:d}:{same:d,other:c}}function _p(e){const t=e.maxPadding;function n(i){const s=Math.max(t[i]-e[i],0);return e[i]+=s,s}e.y+=n("top"),e.x+=n("left"),n("right"),n("bottom")}function wp(e,t){const n=t.maxPadding;function i(s){const o={left:0,top:0,right:0,bottom:0};return s.forEach(r=>{o[r]=Math.max(t[r],n[r])}),o}return i(e?["left","right"]:["top","bottom"])}function hn(e,t,n,i){const s=[];let o,r,a,l,c,d;for(o=0,r=e.length,c=0;o<r;++o){a=e[o],l=a.box,l.update(a.width||t.w,a.height||t.h,wp(a.horizontal,t));const{same:h,other:f}=xp(t,n,a,i);c|=h&&s.length,d=d||f,l.fullSize||s.push(a)}return c&&hn(s,t,n,i)||d}function ii(e,t,n,i,s){e.top=n,e.left=t,e.right=t+i,e.bottom=n+s,e.width=i,e.height=s}function pr(e,t,n,i){const s=n.padding;let{x:o,y:r}=t;for(const a of e){const l=a.box,c=i[a.stack]||{placed:0,weight:1},d=a.stackWeight/c.weight||1;if(a.horizontal){const h=t.w*d,f=c.size||l.height;_i(c.start)&&(r=c.start),l.fullSize?ii(l,s.left,r,n.outerWidth-s.right-s.left,f):ii(l,t.left+c.placed,r,h,f),c.start=r,c.placed+=h,r=l.bottom}else{const h=t.h*d,f=c.size||l.width;_i(c.start)&&(o=c.start),l.fullSize?ii(l,o,s.top,f,n.outerHeight-s.bottom-s.top):ii(l,o,t.top+c.placed,f,h),c.start=o,c.placed+=h,o=l.right}}t.x=o,t.y=r}var se={addBox(e,t){e.boxes||(e.boxes=[]),t.fullSize=t.fullSize||!1,t.position=t.position||"top",t.weight=t.weight||0,t._layers=t._layers||function(){return[{z:0,draw(n){t.draw(n)}}]},e.boxes.push(t)},removeBox(e,t){const n=e.boxes?e.boxes.indexOf(t):-1;n!==-1&&e.boxes.splice(n,1)},configure(e,t,n){t.fullSize=n.fullSize,t.position=n.position,t.weight=n.weight},update(e,t,n,i){if(!e)return;const s=Rt(e.options.layout.padding),o=Math.max(t-s.width,0),r=Math.max(n-s.height,0),a=yp(e.boxes),l=a.vertical,c=a.horizontal;U(e.boxes,v=>{typeof v.beforeLayout=="function"&&v.beforeLayout()});const d=l.reduce((v,y)=>y.box.options&&y.box.options.display===!1?v:v+1,0)||1,h=Object.freeze({outerWidth:t,outerHeight:n,padding:s,availableWidth:o,availableHeight:r,vBoxMaxWidth:o/2/d,hBoxMaxHeight:r/2}),f=Object.assign({},s);bl(f,Rt(i));const g=Object.assign({maxPadding:f,w:o,h:r,x:s.left,y:s.top},s),m=vp(l.concat(c),h);hn(a.fullSize,g,h,m),hn(l,g,h,m),hn(c,g,h,m)&&hn(l,g,h,m),_p(g),pr(a.leftAndTop,g,h,m),g.x+=g.w,g.y+=g.h,pr(a.rightAndBottom,g,h,m),e.chartArea={left:g.left,top:g.top,right:g.left+g.w,bottom:g.top+g.h,height:g.h,width:g.w},U(a.chartArea,v=>{const y=v.box;Object.assign(y,e.chartArea),y.update(g.w,g.h,{left:0,top:0,right:0,bottom:0})})}};class vl{acquireContext(t,n){}releaseContext(t){return!1}addEventListener(t,n,i){}removeEventListener(t,n,i){}getDevicePixelRatio(){return 1}getMaximumSize(t,n,i,s){return n=Math.max(0,n||t.width),i=i||t.height,{width:n,height:Math.max(0,s?Math.floor(n/s):i)}}isAttached(t){return!0}updateConfig(t){}}class kp extends vl{acquireContext(t){return t&&t.getContext&&t.getContext("2d")||null}updateConfig(t){t.options.animation=!1}}const hi="$chartjs",Sp={touchstart:"mousedown",touchmove:"mousemove",touchend:"mouseup",pointerenter:"mouseenter",pointerdown:"mousedown",pointermove:"mousemove",pointerup:"mouseup",pointerleave:"mouseout",pointerout:"mouseout"},gr=e=>e===null||e==="";function Ep(e,t){const n=e.style,i=e.getAttribute("height"),s=e.getAttribute("width");if(e[hi]={initial:{height:i,width:s,style:{display:n.display,height:n.height,width:n.width}}},n.display=n.display||"block",n.boxSizing=n.boxSizing||"border-box",gr(s)){const o=er(e,"width");o!==void 0&&(e.width=o)}if(gr(i))if(e.style.height==="")e.height=e.width/(t||2);else{const o=er(e,"height");o!==void 0&&(e.height=o)}return e}const yl=$f?{passive:!0}:!1;function Tp(e,t,n){e&&e.addEventListener(t,n,yl)}function Cp(e,t,n){e&&e.canvas&&e.canvas.removeEventListener(t,n,yl)}function Op(e,t){const n=Sp[e.type]||e.type,{x:i,y:s}=Ut(e,t);return{type:n,chart:t,native:e,x:i!==void 0?i:null,y:s!==void 0?s:null}}function Ei(e,t){for(const n of e)if(n===t||n.contains(t))return!0}function Mp(e,t,n){const i=e.canvas,s=new MutationObserver(o=>{let r=!1;for(const a of o)r=r||Ei(a.addedNodes,i),r=r&&!Ei(a.removedNodes,i);r&&n()});return s.observe(document,{childList:!0,subtree:!0}),s}function Pp(e,t,n){const i=e.canvas,s=new MutationObserver(o=>{let r=!1;for(const a of o)r=r||Ei(a.removedNodes,i),r=r&&!Ei(a.addedNodes,i);r&&n()});return s.observe(document,{childList:!0,subtree:!0}),s}const On=new Map;let mr=0;function xl(){const e=window.devicePixelRatio;e!==mr&&(mr=e,On.forEach((t,n)=>{n.currentDevicePixelRatio!==e&&t()}))}function Ap(e,t){On.size||window.addEventListener("resize",xl),On.set(e,t)}function Dp(e){On.delete(e),On.size||window.removeEventListener("resize",xl)}function Ip(e,t,n){const i=e.canvas,s=i&&io(i);if(!s)return;const o=Za((a,l)=>{const c=s.clientWidth;n(a,l),c<s.clientWidth&&n()},window),r=new ResizeObserver(a=>{const l=a[0],c=l.contentRect.width,d=l.contentRect.height;c===0&&d===0||o(c,d)});return r.observe(s),Ap(e,o),r}function rs(e,t,n){n&&n.disconnect(),t==="resize"&&Dp(e)}function Rp(e,t,n){const i=e.canvas,s=Za(o=>{e.ctx!==null&&n(Op(o,e))},e);return Tp(i,t,s),s}class Np extends vl{acquireContext(t,n){const i=t&&t.getContext&&t.getContext("2d");return i&&i.canvas===t?(Ep(t,n),i):null}releaseContext(t){const n=t.canvas;if(!n[hi])return!1;const i=n[hi].initial;["height","width"].forEach(o=>{const r=i[o];G(r)?n.removeAttribute(o):n.setAttribute(o,r)});const s=i.style||{};return Object.keys(s).forEach(o=>{n.style[o]=s[o]}),n.width=n.width,delete n[hi],!0}addEventListener(t,n,i){this.removeEventListener(t,n);const s=t.$proxies||(t.$proxies={}),r={attach:Mp,detach:Pp,resize:Ip}[n]||Rp;s[n]=r(t,n,i)}removeEventListener(t,n){const i=t.$proxies||(t.$proxies={}),s=i[n];if(!s)return;({attach:rs,detach:rs,resize:rs}[n]||Cp)(t,n,s),i[n]=void 0}getDevicePixelRatio(){return window.devicePixelRatio}getMaximumSize(t,n,i,s){return zf(t,n,i,s)}isAttached(t){const n=t&&io(t);return!!(n&&n.isConnected)}}function Lp(e){return!no()||typeof OffscreenCanvas<"u"&&e instanceof OffscreenCanvas?kp:Np}class de{constructor(){F(this,"x");F(this,"y");F(this,"active",!1);F(this,"options");F(this,"$animations")}tooltipPosition(t){const{x:n,y:i}=this.getProps(["x","y"],t);return{x:n,y:i}}hasValue(){return Cn(this.x)&&Cn(this.y)}getProps(t,n){const i=this.$animations;if(!n||!i)return this;const s={};return t.forEach(o=>{s[o]=i[o]&&i[o].active()?i[o]._to:this[o]}),s}}F(de,"defaults",{}),F(de,"defaultRoutes");function zp(e,t){const n=e.options.ticks,i=$p(e),s=Math.min(n.maxTicksLimit||i,i),o=n.major.enabled?Bp(t):[],r=o.length,a=o[0],l=o[r-1],c=[];if(r>s)return Hp(t,c,o,r/s),c;const d=Fp(o,t,s);if(r>0){let h,f;const g=r>1?Math.round((l-a)/(r-1)):null;for(si(t,c,d,G(g)?0:a-g,a),h=0,f=r-1;h<f;h++)si(t,c,d,o[h],o[h+1]);return si(t,c,d,l,G(g)?t.length:l+g),c}return si(t,c,d),c}function $p(e){const t=e.options.offset,n=e._tickSize(),i=e._length/n+(t?0:1),s=e._maxLength/n;return Math.floor(Math.min(i,s))}function Fp(e,t,n){const i=Up(e),s=t.length/n;if(!i)return Math.max(s,1);const o=Du(i);for(let r=0,a=o.length-1;r<a;r++){const l=o[r];if(l>s)return l}return Math.max(s,1)}function Bp(e){const t=[];let n,i;for(n=0,i=e.length;n<i;n++)e[n].major&&t.push(n);return t}function Hp(e,t,n,i){let s=0,o=n[0],r;for(i=Math.ceil(i),r=0;r<e.length;r++)r===o&&(t.push(e[r]),s++,o=n[s*i])}function si(e,t,n,i,s){const o=B(i,0),r=Math.min(B(s,e.length),e.length);let a=0,l,c,d;for(n=Math.ceil(n),s&&(l=s-i,n=l/Math.floor(l/n)),d=o;d<0;)a++,d=Math.round(o+a*n);for(c=Math.max(o,0);c<r;c++)c===d&&(t.push(e[c]),a++,d=Math.round(o+a*n))}function Up(e){const t=e.length;let n,i;if(t<2)return!1;for(i=e[0],n=1;n<t;++n)if(e[n]-e[n-1]!==i)return!1;return i}const Wp=e=>e==="left"?"right":e==="right"?"left":e,br=(e,t,n)=>t==="top"||t==="left"?e[t]+n:e[t]-n,vr=(e,t)=>Math.min(t||e,e);function yr(e,t){const n=[],i=e.length/t,s=e.length;let o=0;for(;o<s;o+=i)n.push(e[Math.floor(o)]);return n}function jp(e,t,n){const i=e.ticks.length,s=Math.min(t,i-1),o=e._startPixel,r=e._endPixel,a=1e-6;let l=e.getPixelForTick(s),c;if(!(n&&(i===1?c=Math.max(l-o,r-l):t===0?c=(e.getPixelForTick(1)-l)/2:c=(l-e.getPixelForTick(s-1))/2,l+=s<t?c:-c,l<o-a||l>r+a)))return l}function Vp(e,t){U(e,n=>{const i=n.gc,s=i.length/2;let o;if(s>t){for(o=0;o<s;++o)delete n.data[i[o]];i.splice(0,s)}})}function ln(e){return e.drawTicks?e.tickLength:0}function xr(e,t){if(!e.display)return 0;const n=xt(e.font,t),i=Rt(e.padding);return(ct(e.text)?e.text.length:1)*n.lineHeight+i.height}function Yp(e,t){return Ae(e,{scale:t,type:"scale"})}function Gp(e,t,n){return Ae(e,{tick:n,index:t,type:"tick"})}function Kp(e,t,n){let i=Ja(e);return(n&&t!=="right"||!n&&t==="right")&&(i=Wp(i)),i}function qp(e,t,n,i){const{top:s,left:o,bottom:r,right:a,chart:l}=e,{chartArea:c,scales:d}=l;let h=0,f,g,m;const v=r-s,y=a-o;if(e.isHorizontal()){if(g=St(i,o,a),W(n)){const _=Object.keys(n)[0],E=n[_];m=d[_].getPixelForValue(E)+v-t}else n==="center"?m=(c.bottom+c.top)/2+v-t:m=br(e,n,t);f=a-o}else{if(W(n)){const _=Object.keys(n)[0],E=n[_];g=d[_].getPixelForValue(E)-y+t}else n==="center"?g=(c.left+c.right)/2-y+t:g=br(e,n,t);m=St(i,r,s),h=n==="left"?-At:At}return{titleX:g,titleY:m,maxWidth:f,rotation:h}}class Ln extends de{constructor(t){super(),this.id=t.id,this.type=t.type,this.options=void 0,this.ctx=t.ctx,this.chart=t.chart,this.top=void 0,this.bottom=void 0,this.left=void 0,this.right=void 0,this.width=void 0,this.height=void 0,this._margins={left:0,right:0,top:0,bottom:0},this.maxWidth=void 0,this.maxHeight=void 0,this.paddingTop=void 0,this.paddingBottom=void 0,this.paddingLeft=void 0,this.paddingRight=void 0,this.axis=void 0,this.labelRotation=void 0,this.min=void 0,this.max=void 0,this._range=void 0,this.ticks=[],this._gridLineItems=null,this._labelItems=null,this._labelSizes=null,this._length=0,this._maxLength=0,this._longestTextCache={},this._startPixel=void 0,this._endPixel=void 0,this._reversePixels=!1,this._userMax=void 0,this._userMin=void 0,this._suggestedMax=void 0,this._suggestedMin=void 0,this._ticksLength=0,this._borderValue=0,this._cache={},this._dataLimitsCached=!1,this.$context=void 0}init(t){this.options=t.setContext(this.getContext()),this.axis=t.axis,this._userMin=this.parse(t.min),this._userMax=this.parse(t.max),this._suggestedMin=this.parse(t.suggestedMin),this._suggestedMax=this.parse(t.suggestedMax)}parse(t,n){return t}getUserBounds(){let{_userMin:t,_userMax:n,_suggestedMin:i,_suggestedMax:s}=this;return t=$t(t,Number.POSITIVE_INFINITY),n=$t(n,Number.NEGATIVE_INFINITY),i=$t(i,Number.POSITIVE_INFINITY),s=$t(s,Number.NEGATIVE_INFINITY),{min:$t(t,i),max:$t(n,s),minDefined:ft(t),maxDefined:ft(n)}}getMinMax(t){let{min:n,max:i,minDefined:s,maxDefined:o}=this.getUserBounds(),r;if(s&&o)return{min:n,max:i};const a=this.getMatchingVisibleMetas();for(let l=0,c=a.length;l<c;++l)r=a[l].controller.getMinMax(this,t),s||(n=Math.min(n,r.min)),o||(i=Math.max(i,r.max));return n=o&&n>i?i:n,i=s&&n>i?n:i,{min:$t(n,$t(i,n)),max:$t(i,$t(n,i))}}getPadding(){return{left:this.paddingLeft||0,top:this.paddingTop||0,right:this.paddingRight||0,bottom:this.paddingBottom||0}}getTicks(){return this.ticks}getLabels(){const t=this.chart.data;return this.options.labels||(this.isHorizontal()?t.xLabels:t.yLabels)||t.labels||[]}getLabelItems(t=this.chart.chartArea){return this._labelItems||(this._labelItems=this._computeLabelItems(t))}beforeLayout(){this._cache={},this._dataLimitsCached=!1}beforeUpdate(){N(this.options.beforeUpdate,[this])}update(t,n,i){const{beginAtZero:s,grace:o,ticks:r}=this.options,a=r.sampleSize;this.beforeUpdate(),this.maxWidth=t,this.maxHeight=n,this._margins=i=Object.assign({left:0,right:0,top:0,bottom:0},i),this.ticks=null,this._labelSizes=null,this._gridLineItems=null,this._labelItems=null,this.beforeSetDimensions(),this.setDimensions(),this.afterSetDimensions(),this._maxLength=this.isHorizontal()?this.width+i.left+i.right:this.height+i.top+i.bottom,this._dataLimitsCached||(this.beforeDataLimits(),this.determineDataLimits(),this.afterDataLimits(),this._range=gf(this,o,s),this._dataLimitsCached=!0),this.beforeBuildTicks(),this.ticks=this.buildTicks()||[],this.afterBuildTicks();const l=a<this.ticks.length;this._convertTicksToLabels(l?yr(this.ticks,a):this.ticks),this.configure(),this.beforeCalculateLabelRotation(),this.calculateLabelRotation(),this.afterCalculateLabelRotation(),r.display&&(r.autoSkip||r.source==="auto")&&(this.ticks=zp(this,this.ticks),this._labelSizes=null,this.afterAutoSkip()),l&&this._convertTicksToLabels(this.ticks),this.beforeFit(),this.fit(),this.afterFit(),this.afterUpdate()}configure(){let t=this.options.reverse,n,i;this.isHorizontal()?(n=this.left,i=this.right):(n=this.top,i=this.bottom,t=!t),this._startPixel=n,this._endPixel=i,this._reversePixels=t,this._length=i-n,this._alignToPixels=this.options.alignToPixels}afterUpdate(){N(this.options.afterUpdate,[this])}beforeSetDimensions(){N(this.options.beforeSetDimensions,[this])}setDimensions(){this.isHorizontal()?(this.width=this.maxWidth,this.left=0,this.right=this.width):(this.height=this.maxHeight,this.top=0,this.bottom=this.height),this.paddingLeft=0,this.paddingTop=0,this.paddingRight=0,this.paddingBottom=0}afterSetDimensions(){N(this.options.afterSetDimensions,[this])}_callHooks(t){this.chart.notifyPlugins(t,this.getContext()),N(this.options[t],[this])}beforeDataLimits(){this._callHooks("beforeDataLimits")}determineDataLimits(){}afterDataLimits(){this._callHooks("afterDataLimits")}beforeBuildTicks(){this._callHooks("beforeBuildTicks")}buildTicks(){return[]}afterBuildTicks(){this._callHooks("afterBuildTicks")}beforeTickToLabelConversion(){N(this.options.beforeTickToLabelConversion,[this])}generateTickLabels(t){const n=this.options.ticks;let i,s,o;for(i=0,s=t.length;i<s;i++)o=t[i],o.label=N(n.callback,[o.value,i,t],this)}afterTickToLabelConversion(){N(this.options.afterTickToLabelConversion,[this])}beforeCalculateLabelRotation(){N(this.options.beforeCalculateLabelRotation,[this])}calculateLabelRotation(){const t=this.options,n=t.ticks,i=vr(this.ticks.length,t.ticks.maxTicksLimit),s=n.minRotation||0,o=n.maxRotation;let r=s,a,l,c;if(!this._isVisible()||!n.display||s>=o||i<=1||!this.isHorizontal()){this.labelRotation=s;return}const d=this._getLabelSizes(),h=d.widest.width,f=d.highest.height,g=Dt(this.chart.width-h,0,this.maxWidth);a=t.offset?this.maxWidth/i:g/(i-1),h+6>a&&(a=g/(i-(t.offset?.5:1)),l=this.maxHeight-ln(t.grid)-n.padding-xr(t.title,this.chart.options.font),c=Math.sqrt(h*h+f*f),r=Lu(Math.min(Math.asin(Dt((d.highest.height+6)/a,-1,1)),Math.asin(Dt(l/c,-1,1))-Math.asin(Dt(f/c,-1,1)))),r=Math.max(s,Math.min(o,r))),this.labelRotation=r}afterCalculateLabelRotation(){N(this.options.afterCalculateLabelRotation,[this])}afterAutoSkip(){}beforeFit(){N(this.options.beforeFit,[this])}fit(){const t={width:0,height:0},{chart:n,options:{ticks:i,title:s,grid:o}}=this,r=this._isVisible(),a=this.isHorizontal();if(r){const l=xr(s,n.options.font);if(a?(t.width=this.maxWidth,t.height=ln(o)+l):(t.height=this.maxHeight,t.width=ln(o)+l),i.display&&this.ticks.length){const{first:c,last:d,widest:h,highest:f}=this._getLabelSizes(),g=i.padding*2,m=_e(this.labelRotation),v=Math.cos(m),y=Math.sin(m);if(a){const _=i.mirror?0:y*h.width+v*f.height;t.height=Math.min(this.maxHeight,t.height+_+g)}else{const _=i.mirror?0:v*h.width+y*f.height;t.width=Math.min(this.maxWidth,t.width+_+g)}this._calculatePadding(c,d,y,v)}}this._handleMargins(),a?(this.width=this._length=n.width-this._margins.left-this._margins.right,this.height=t.height):(this.width=t.width,this.height=this._length=n.height-this._margins.top-this._margins.bottom)}_calculatePadding(t,n,i,s){const{ticks:{align:o,padding:r},position:a}=this.options,l=this.labelRotation!==0,c=a!=="top"&&this.axis==="x";if(this.isHorizontal()){const d=this.getPixelForTick(0)-this.left,h=this.right-this.getPixelForTick(this.ticks.length-1);let f=0,g=0;l?c?(f=s*t.width,g=i*n.height):(f=i*t.height,g=s*n.width):o==="start"?g=n.width:o==="end"?f=t.width:o!=="inner"&&(f=t.width/2,g=n.width/2),this.paddingLeft=Math.max((f-d+r)*this.width/(this.width-d),0),this.paddingRight=Math.max((g-h+r)*this.width/(this.width-h),0)}else{let d=n.height/2,h=t.height/2;o==="start"?(d=0,h=t.height):o==="end"&&(d=n.height,h=0),this.paddingTop=d+r,this.paddingBottom=h+r}}_handleMargins(){this._margins&&(this._margins.left=Math.max(this.paddingLeft,this._margins.left),this._margins.top=Math.max(this.paddingTop,this._margins.top),this._margins.right=Math.max(this.paddingRight,this._margins.right),this._margins.bottom=Math.max(this.paddingBottom,this._margins.bottom))}afterFit(){N(this.options.afterFit,[this])}isHorizontal(){const{axis:t,position:n}=this.options;return n==="top"||n==="bottom"||t==="x"}isFullSize(){return this.options.fullSize}_convertTicksToLabels(t){this.beforeTickToLabelConversion(),this.generateTickLabels(t);let n,i;for(n=0,i=t.length;n<i;n++)G(t[n].label)&&(t.splice(n,1),i--,n--);this.afterTickToLabelConversion()}_getLabelSizes(){let t=this._labelSizes;if(!t){const n=this.options.ticks.sampleSize;let i=this.ticks;n<i.length&&(i=yr(i,n)),this._labelSizes=t=this._computeLabelSizes(i,i.length,this.options.ticks.maxTicksLimit)}return t}_computeLabelSizes(t,n,i){const{ctx:s,_longestTextCache:o}=this,r=[],a=[],l=Math.floor(n/vr(n,i));let c=0,d=0,h,f,g,m,v,y,_,E,O,M,k;for(h=0;h<n;h+=l){if(m=t[h].label,v=this._resolveTickFontOptions(h),s.font=y=v.string,_=o[y]=o[y]||{data:{},gc:[]},E=v.lineHeight,O=M=0,!G(m)&&!ct(m))O=Xo(s,_.data,_.gc,O,m),M=E;else if(ct(m))for(f=0,g=m.length;f<g;++f)k=m[f],!G(k)&&!ct(k)&&(O=Xo(s,_.data,_.gc,O,k),M+=E);r.push(O),a.push(M),c=Math.max(O,c),d=Math.max(M,d)}Vp(o,n);const C=r.indexOf(c),A=a.indexOf(d),P=I=>({width:r[I]||0,height:a[I]||0});return{first:P(0),last:P(n-1),widest:P(C),highest:P(A),widths:r,heights:a}}getLabelForValue(t){return t}getPixelForValue(t,n){return NaN}getValueForPixel(t){}getPixelForTick(t){const n=this.ticks;return t<0||t>n.length-1?null:this.getPixelForValue(n[t].value)}getPixelForDecimal(t){this._reversePixels&&(t=1-t);const n=this._startPixel+t*this._length;return Fu(this._alignToPixels?ve(this.chart,n,0):n)}getDecimalForPixel(t){const n=(t-this._startPixel)/this._length;return this._reversePixels?1-n:n}getBasePixel(){return this.getPixelForValue(this.getBaseValue())}getBaseValue(){const{min:t,max:n}=this;return t<0&&n<0?n:t>0&&n>0?t:0}getContext(t){const n=this.ticks||[];if(t>=0&&t<n.length){const i=n[t];return i.$context||(i.$context=Gp(this.getContext(),t,i))}return this.$context||(this.$context=Yp(this.chart.getContext(),this))}_tickSize(){const t=this.options.ticks,n=_e(this.labelRotation),i=Math.abs(Math.cos(n)),s=Math.abs(Math.sin(n)),o=this._getLabelSizes(),r=t.autoSkipPadding||0,a=o?o.widest.width+r:0,l=o?o.highest.height+r:0;return this.isHorizontal()?l*i>a*s?a/i:l/s:l*s<a*i?l/i:a/s}_isVisible(){const t=this.options.display;return t!=="auto"?!!t:this.getMatchingVisibleMetas().length>0}_computeGridLineItems(t){const n=this.axis,i=this.chart,s=this.options,{grid:o,position:r,border:a}=s,l=o.offset,c=this.isHorizontal(),h=this.ticks.length+(l?1:0),f=ln(o),g=[],m=a.setContext(this.getContext()),v=m.display?m.width:0,y=v/2,_=function(Y){return ve(i,Y,v)};let E,O,M,k,C,A,P,I,z,R,$,Z;if(r==="top")E=_(this.bottom),A=this.bottom-f,I=E-y,R=_(t.top)+y,Z=t.bottom;else if(r==="bottom")E=_(this.top),R=t.top,Z=_(t.bottom)-y,A=E+y,I=this.top+f;else if(r==="left")E=_(this.right),C=this.right-f,P=E-y,z=_(t.left)+y,$=t.right;else if(r==="right")E=_(this.left),z=t.left,$=_(t.right)-y,C=E+y,P=this.left+f;else if(n==="x"){if(r==="center")E=_((t.top+t.bottom)/2+.5);else if(W(r)){const Y=Object.keys(r)[0],rt=r[Y];E=_(this.chart.scales[Y].getPixelForValue(rt))}R=t.top,Z=t.bottom,A=E+y,I=A+f}else if(n==="y"){if(r==="center")E=_((t.left+t.right)/2);else if(W(r)){const Y=Object.keys(r)[0],rt=r[Y];E=_(this.chart.scales[Y].getPixelForValue(rt))}C=E-y,P=C-f,z=t.left,$=t.right}const ot=B(s.ticks.maxTicksLimit,h),V=Math.max(1,Math.ceil(h/ot));for(O=0;O<h;O+=V){const Y=this.getContext(O),rt=o.setContext(Y),j=a.setContext(Y),J=rt.lineWidth,tt=rt.color,ht=j.dash||[],et=j.dashOffset,kt=rt.tickWidth,Mt=rt.tickColor,ue=rt.tickBorderDash||[],Vt=rt.tickBorderDashOffset;M=jp(this,O,l),M!==void 0&&(k=ve(i,M,J),c?C=P=z=$=k:A=I=R=Z=k,g.push({tx1:C,ty1:A,tx2:P,ty2:I,x1:z,y1:R,x2:$,y2:Z,width:J,color:tt,borderDash:ht,borderDashOffset:et,tickWidth:kt,tickColor:Mt,tickBorderDash:ue,tickBorderDashOffset:Vt}))}return this._ticksLength=h,this._borderValue=E,g}_computeLabelItems(t){const n=this.axis,i=this.options,{position:s,ticks:o}=i,r=this.isHorizontal(),a=this.ticks,{align:l,crossAlign:c,padding:d,mirror:h}=o,f=ln(i.grid),g=f+d,m=h?-d:g,v=-_e(this.labelRotation),y=[];let _,E,O,M,k,C,A,P,I,z,R,$,Z="middle";if(s==="top")C=this.bottom-m,A=this._getXAxisLabelAlignment();else if(s==="bottom")C=this.top+m,A=this._getXAxisLabelAlignment();else if(s==="left"){const V=this._getYAxisLabelAlignment(f);A=V.textAlign,k=V.x}else if(s==="right"){const V=this._getYAxisLabelAlignment(f);A=V.textAlign,k=V.x}else if(n==="x"){if(s==="center")C=(t.top+t.bottom)/2+g;else if(W(s)){const V=Object.keys(s)[0],Y=s[V];C=this.chart.scales[V].getPixelForValue(Y)+g}A=this._getXAxisLabelAlignment()}else if(n==="y"){if(s==="center")k=(t.left+t.right)/2-g;else if(W(s)){const V=Object.keys(s)[0],Y=s[V];k=this.chart.scales[V].getPixelForValue(Y)}A=this._getYAxisLabelAlignment(f).textAlign}n==="y"&&(l==="start"?Z="top":l==="end"&&(Z="bottom"));const ot=this._getLabelSizes();for(_=0,E=a.length;_<E;++_){O=a[_],M=O.label;const V=o.setContext(this.getContext(_));P=this.getPixelForTick(_)+o.labelOffset,I=this._resolveTickFontOptions(_),z=I.lineHeight,R=ct(M)?M.length:1;const Y=R/2,rt=V.color,j=V.textStrokeColor,J=V.textStrokeWidth;let tt=A;r?(k=P,A==="inner"&&(_===E-1?tt=this.options.reverse?"left":"right":_===0?tt=this.options.reverse?"right":"left":tt="center"),s==="top"?c==="near"||v!==0?$=-R*z+z/2:c==="center"?$=-ot.highest.height/2-Y*z+z:$=-ot.highest.height+z/2:c==="near"||v!==0?$=z/2:c==="center"?$=ot.highest.height/2-Y*z:$=ot.highest.height-R*z,h&&($*=-1),v!==0&&!V.showLabelBackdrop&&(k+=z/2*Math.sin(v))):(C=P,$=(1-R)*z/2);let ht;if(V.showLabelBackdrop){const et=Rt(V.backdropPadding),kt=ot.heights[_],Mt=ot.widths[_];let ue=$-et.top,Vt=0-et.left;switch(Z){case"middle":ue-=kt/2;break;case"bottom":ue-=kt;break}switch(A){case"center":Vt-=Mt/2;break;case"right":Vt-=Mt;break;case"inner":_===E-1?Vt-=Mt:_>0&&(Vt-=Mt/2);break}ht={left:Vt,top:ue,width:Mt+et.width,height:kt+et.height,color:V.backdropColor}}y.push({label:M,font:I,textOffset:$,options:{rotation:v,color:rt,strokeColor:j,strokeWidth:J,textAlign:tt,textBaseline:Z,translation:[k,C],backdrop:ht}})}return y}_getXAxisLabelAlignment(){const{position:t,ticks:n}=this.options;if(-_e(this.labelRotation))return t==="top"?"left":"right";let s="center";return n.align==="start"?s="left":n.align==="end"?s="right":n.align==="inner"&&(s="inner"),s}_getYAxisLabelAlignment(t){const{position:n,ticks:{crossAlign:i,mirror:s,padding:o}}=this.options,r=this._getLabelSizes(),a=t+o,l=r.widest.width;let c,d;return n==="left"?s?(d=this.right+o,i==="near"?c="left":i==="center"?(c="center",d+=l/2):(c="right",d+=l)):(d=this.right-a,i==="near"?c="right":i==="center"?(c="center",d-=l/2):(c="left",d=this.left)):n==="right"?s?(d=this.left+o,i==="near"?c="right":i==="center"?(c="center",d-=l/2):(c="left",d-=l)):(d=this.left+a,i==="near"?c="left":i==="center"?(c="center",d+=l/2):(c="right",d=this.right)):c="right",{textAlign:c,x:d}}_computeLabelArea(){if(this.options.ticks.mirror)return;const t=this.chart,n=this.options.position;if(n==="left"||n==="right")return{top:0,left:this.left,bottom:t.height,right:this.right};if(n==="top"||n==="bottom")return{top:this.top,left:0,bottom:this.bottom,right:t.width}}drawBackground(){const{ctx:t,options:{backgroundColor:n},left:i,top:s,width:o,height:r}=this;n&&(t.save(),t.fillStyle=n,t.fillRect(i,s,o,r),t.restore())}getLineWidthForValue(t){const n=this.options.grid;if(!this._isVisible()||!n.display)return 0;const s=this.ticks.findIndex(o=>o.value===t);return s>=0?n.setContext(this.getContext(s)).lineWidth:0}drawGrid(t){const n=this.options.grid,i=this.ctx,s=this._gridLineItems||(this._gridLineItems=this._computeGridLineItems(t));let o,r;const a=(l,c,d)=>{!d.width||!d.color||(i.save(),i.lineWidth=d.width,i.strokeStyle=d.color,i.setLineDash(d.borderDash||[]),i.lineDashOffset=d.borderDashOffset,i.beginPath(),i.moveTo(l.x,l.y),i.lineTo(c.x,c.y),i.stroke(),i.restore())};if(n.display)for(o=0,r=s.length;o<r;++o){const l=s[o];n.drawOnChartArea&&a({x:l.x1,y:l.y1},{x:l.x2,y:l.y2},l),n.drawTicks&&a({x:l.tx1,y:l.ty1},{x:l.tx2,y:l.ty2},{color:l.tickColor,width:l.tickWidth,borderDash:l.tickBorderDash,borderDashOffset:l.tickBorderDashOffset})}}drawBorder(){const{chart:t,ctx:n,options:{border:i,grid:s}}=this,o=i.setContext(this.getContext()),r=i.display?o.width:0;if(!r)return;const a=s.setContext(this.getContext(0)).lineWidth,l=this._borderValue;let c,d,h,f;this.isHorizontal()?(c=ve(t,this.left,r)-r/2,d=ve(t,this.right,a)+a/2,h=f=l):(h=ve(t,this.top,r)-r/2,f=ve(t,this.bottom,a)+a/2,c=d=l),n.save(),n.lineWidth=o.width,n.strokeStyle=o.color,n.beginPath(),n.moveTo(c,h),n.lineTo(d,f),n.stroke(),n.restore()}drawLabels(t){if(!this.options.ticks.display)return;const i=this.ctx,s=this._computeLabelArea();s&&Ni(i,s);const o=this.getLabelItems(t);for(const r of o){const a=r.options,l=r.font,c=r.label,d=r.textOffset;ki(i,c,0,d,l,a)}s&&Li(i)}drawTitle(){const{ctx:t,options:{position:n,title:i,reverse:s}}=this;if(!i.display)return;const o=xt(i.font),r=Rt(i.padding),a=i.align;let l=o.lineHeight/2;n==="bottom"||n==="center"||W(n)?(l+=r.bottom,ct(i.text)&&(l+=o.lineHeight*(i.text.length-1))):l+=r.top;const{titleX:c,titleY:d,maxWidth:h,rotation:f}=qp(this,l,n,a);ki(t,i.text,0,0,o,{color:i.color,maxWidth:h,rotation:f,textAlign:Kp(a,n,s),textBaseline:"middle",translation:[c,d]})}draw(t){this._isVisible()&&(this.drawBackground(),this.drawGrid(t),this.drawBorder(),this.drawTitle(),this.drawLabels(t))}_layers(){const t=this.options,n=t.ticks&&t.ticks.z||0,i=B(t.grid&&t.grid.z,-1),s=B(t.border&&t.border.z,0);return!this._isVisible()||this.draw!==Ln.prototype.draw?[{z:n,draw:o=>{this.draw(o)}}]:[{z:i,draw:o=>{this.drawBackground(),this.drawGrid(o),this.drawTitle()}},{z:s,draw:()=>{this.drawBorder()}},{z:n,draw:o=>{this.drawLabels(o)}}]}getMatchingVisibleMetas(t){const n=this.chart.getSortedVisibleDatasetMetas(),i=this.axis+"AxisID",s=[];let o,r;for(o=0,r=n.length;o<r;++o){const a=n[o];a[i]===this.id&&(!t||a.type===t)&&s.push(a)}return s}_resolveTickFontOptions(t){const n=this.options.ticks.setContext(this.getContext(t));return xt(n.font)}_maxDigits(){const t=this._resolveTickFontOptions(0).lineHeight;return(this.isHorizontal()?this.width:this.height)/t}}class oi{constructor(t,n,i){this.type=t,this.scope=n,this.override=i,this.items=Object.create(null)}isForType(t){return Object.prototype.isPrototypeOf.call(this.type.prototype,t.prototype)}register(t){const n=Object.getPrototypeOf(t);let i;Jp(n)&&(i=this.register(n));const s=this.items,o=t.id,r=this.scope+"."+o;if(!o)throw new Error("class does not have id: "+t);return o in s||(s[o]=t,Xp(t,r,i),this.override&&Q.override(t.id,t.overrides)),r}get(t){return this.items[t]}unregister(t){const n=this.items,i=t.id,s=this.scope;i in n&&delete n[i],s&&i in Q[s]&&(delete Q[s][i],this.override&&delete Te[i])}}function Xp(e,t,n){const i=Tn(Object.create(null),[n?Q.get(n):{},Q.get(t),e.defaults]);Q.set(t,i),e.defaultRoutes&&Zp(t,e.defaultRoutes),e.descriptors&&Q.describe(t,e.descriptors)}function Zp(e,t){Object.keys(t).forEach(n=>{const i=n.split("."),s=i.pop(),o=[e].concat(i).join("."),r=t[n].split("."),a=r.pop(),l=r.join(".");Q.route(o,s,l,a)})}function Jp(e){return"id"in e&&"defaults"in e}class Qp{constructor(){this.controllers=new oi(bn,"datasets",!0),this.elements=new oi(de,"elements"),this.plugins=new oi(Object,"plugins"),this.scales=new oi(Ln,"scales"),this._typedRegistries=[this.controllers,this.scales,this.elements]}add(...t){this._each("register",t)}remove(...t){this._each("unregister",t)}addControllers(...t){this._each("register",t,this.controllers)}addElements(...t){this._each("register",t,this.elements)}addPlugins(...t){this._each("register",t,this.plugins)}addScales(...t){this._each("register",t,this.scales)}getController(t){return this._get(t,this.controllers,"controller")}getElement(t){return this._get(t,this.elements,"element")}getPlugin(t){return this._get(t,this.plugins,"plugin")}getScale(t){return this._get(t,this.scales,"scale")}removeControllers(...t){this._each("unregister",t,this.controllers)}removeElements(...t){this._each("unregister",t,this.elements)}removePlugins(...t){this._each("unregister",t,this.plugins)}removeScales(...t){this._each("unregister",t,this.scales)}_each(t,n,i){[...n].forEach(s=>{const o=i||this._getRegistryForType(s);i||o.isForType(s)||o===this.plugins&&s.id?this._exec(t,o,s):U(s,r=>{const a=i||this._getRegistryForType(r);this._exec(t,a,r)})})}_exec(t,n,i){const s=Xs(t);N(i["before"+s],[],i),n[t](i),N(i["after"+s],[],i)}_getRegistryForType(t){for(let n=0;n<this._typedRegistries.length;n++){const i=this._typedRegistries[n];if(i.isForType(t))return i}return this.plugins}_get(t,n,i){const s=n.get(t);if(s===void 0)throw new Error('"'+t+'" is not a registered '+i+".");return s}}var Bt=new Qp;class tg{constructor(){this._init=void 0}notify(t,n,i,s){if(n==="beforeInit"&&(this._init=this._createDescriptors(t,!0),this._notify(this._init,t,"install")),this._init===void 0)return;const o=s?this._descriptors(t).filter(s):this._descriptors(t),r=this._notify(o,t,n,i);return n==="afterDestroy"&&(this._notify(o,t,"stop"),this._notify(this._init,t,"uninstall"),this._init=void 0),r}_notify(t,n,i,s){s=s||{};for(const o of t){const r=o.plugin,a=r[i],l=[n,s,o.options];if(N(a,l,r)===!1&&s.cancelable)return!1}return!0}invalidate(){G(this._cache)||(this._oldCache=this._cache,this._cache=void 0)}_descriptors(t){if(this._cache)return this._cache;const n=this._cache=this._createDescriptors(t);return this._notifyStateChanges(t),n}_createDescriptors(t,n){const i=t&&t.config,s=B(i.options&&i.options.plugins,{}),o=eg(i);return s===!1&&!n?[]:ig(t,o,s,n)}_notifyStateChanges(t){const n=this._oldCache||[],i=this._cache,s=(o,r)=>o.filter(a=>!r.some(l=>a.plugin.id===l.plugin.id));this._notify(s(n,i),t,"stop"),this._notify(s(i,n),t,"start")}}function eg(e){const t={},n=[],i=Object.keys(Bt.plugins.items);for(let o=0;o<i.length;o++)n.push(Bt.getPlugin(i[o]));const s=e.plugins||[];for(let o=0;o<s.length;o++){const r=s[o];n.indexOf(r)===-1&&(n.push(r),t[r.id]=!0)}return{plugins:n,localIds:t}}function ng(e,t){return!t&&e===!1?null:e===!0?{}:e}function ig(e,{plugins:t,localIds:n},i,s){const o=[],r=e.getContext();for(const a of t){const l=a.id,c=ng(i[l],s);c!==null&&o.push({plugin:a,options:sg(e.config,{plugin:a,local:n[l]},c,r)})}return o}function sg(e,{plugin:t,local:n},i,s){const o=e.pluginScopeKeys(t),r=e.getOptionScopes(i,o);return n&&t.defaults&&r.push(t.defaults),e.createResolver(r,s,[""],{scriptable:!1,indexable:!1,allKeys:!0})}function Es(e,t){const n=Q.datasets[e]||{};return((t.datasets||{})[e]||{}).indexAxis||t.indexAxis||n.indexAxis||"x"}function og(e,t){let n=e;return e==="_index_"?n=t:e==="_value_"&&(n=t==="x"?"y":"x"),n}function rg(e,t){return e===t?"_index_":"_value_"}function _r(e){if(e==="x"||e==="y"||e==="r")return e}function ag(e){if(e==="top"||e==="bottom")return"x";if(e==="left"||e==="right")return"y"}function Ts(e,...t){if(_r(e))return e;for(const n of t){const i=n.axis||ag(n.position)||e.length>1&&_r(e[0].toLowerCase());if(i)return i}throw new Error(`Cannot determine type of '${e}' axis. Please provide 'axis' or 'position' option.`)}function wr(e,t,n){if(n[t+"AxisID"]===e)return{axis:t}}function lg(e,t){if(t.data&&t.data.datasets){const n=t.data.datasets.filter(i=>i.xAxisID===e||i.yAxisID===e);if(n.length)return wr(e,"x",n[0])||wr(e,"y",n[0])}return{}}function cg(e,t){const n=Te[e.type]||{scales:{}},i=t.scales||{},s=Es(e.type,t),o=Object.create(null);return Object.keys(i).forEach(r=>{const a=i[r];if(!W(a))return console.error(`Invalid scale configuration for scale: ${r}`);if(a._proxy)return console.warn(`Ignoring resolver passed as options for scale: ${r}`);const l=Ts(r,a,lg(r,e),Q.scales[a.type]),c=rg(l,s),d=n.scales||{};o[r]=fn(Object.create(null),[{axis:l},a,d[l],d[c]])}),e.data.datasets.forEach(r=>{const a=r.type||e.type,l=r.indexAxis||Es(a,t),d=(Te[a]||{}).scales||{};Object.keys(d).forEach(h=>{const f=og(h,l),g=r[f+"AxisID"]||f;o[g]=o[g]||Object.create(null),fn(o[g],[{axis:f},i[g],d[h]])})}),Object.keys(o).forEach(r=>{const a=o[r];fn(a,[Q.scales[a.type],Q.scale])}),o}function _l(e){const t=e.options||(e.options={});t.plugins=B(t.plugins,{}),t.scales=cg(e,t)}function wl(e){return e=e||{},e.datasets=e.datasets||[],e.labels=e.labels||[],e}function dg(e){return e=e||{},e.data=wl(e.data),_l(e),e}const kr=new Map,kl=new Set;function ri(e,t){let n=kr.get(e);return n||(n=t(),kr.set(e,n),kl.add(n)),n}const cn=(e,t,n)=>{const i=xi(t,n);i!==void 0&&e.add(i)};class hg{constructor(t){this._config=dg(t),this._scopeCache=new Map,this._resolverCache=new Map}get platform(){return this._config.platform}get type(){return this._config.type}set type(t){this._config.type=t}get data(){return this._config.data}set data(t){this._config.data=wl(t)}get options(){return this._config.options}set options(t){this._config.options=t}get plugins(){return this._config.plugins}update(){const t=this._config;this.clearCache(),_l(t)}clearCache(){this._scopeCache.clear(),this._resolverCache.clear()}datasetScopeKeys(t){return ri(t,()=>[[`datasets.${t}`,""]])}datasetAnimationScopeKeys(t,n){return ri(`${t}.transition.${n}`,()=>[[`datasets.${t}.transitions.${n}`,`transitions.${n}`],[`datasets.${t}`,""]])}datasetElementScopeKeys(t,n){return ri(`${t}-${n}`,()=>[[`datasets.${t}.elements.${n}`,`datasets.${t}`,`elements.${n}`,""]])}pluginScopeKeys(t){const n=t.id,i=this.type;return ri(`${i}-plugin-${n}`,()=>[[`plugins.${n}`,...t.additionalOptionScopes||[]]])}_cachedScopes(t,n){const i=this._scopeCache;let s=i.get(t);return(!s||n)&&(s=new Map,i.set(t,s)),s}getOptionScopes(t,n,i){const{options:s,type:o}=this,r=this._cachedScopes(t,i),a=r.get(n);if(a)return a;const l=new Set;n.forEach(d=>{t&&(l.add(t),d.forEach(h=>cn(l,t,h))),d.forEach(h=>cn(l,s,h)),d.forEach(h=>cn(l,Te[o]||{},h)),d.forEach(h=>cn(l,Q,h)),d.forEach(h=>cn(l,ws,h))});const c=Array.from(l);return c.length===0&&c.push(Object.create(null)),kl.has(n)&&r.set(n,c),c}chartOptionScopes(){const{options:t,type:n}=this;return[t,Te[n]||{},Q.datasets[n]||{},{type:n},Q,ws]}resolveNamedOptions(t,n,i,s=[""]){const o={$shared:!0},{resolver:r,subPrefixes:a}=Sr(this._resolverCache,t,s);let l=r;if(fg(r,n)){o.$shared=!1,i=le(i)?i():i;const c=this.createResolver(t,i,a);l=Ye(r,i,c)}for(const c of n)o[c]=l[c];return o}createResolver(t,n,i=[""],s){const{resolver:o}=Sr(this._resolverCache,t,i);return W(n)?Ye(o,n,void 0,s):o}}function Sr(e,t,n){let i=e.get(t);i||(i=new Map,e.set(t,i));const s=n.join();let o=i.get(s);return o||(o={resolver:Qs(t,n),subPrefixes:n.filter(a=>!a.toLowerCase().includes("hover"))},i.set(s,o)),o}const ug=e=>W(e)&&Object.getOwnPropertyNames(e).some(t=>le(e[t]));function fg(e,t){const{isScriptable:n,isIndexable:i}=il(e);for(const s of t){const o=n(s),r=i(s),a=(r||o)&&e[s];if(o&&(le(a)||ug(a))||r&&ct(a))return!0}return!1}var pg="4.5.1";const gg=["top","bottom","left","right","chartArea"];function Er(e,t){return e==="top"||e==="bottom"||gg.indexOf(e)===-1&&t==="x"}function Tr(e,t){return function(n,i){return n[e]===i[e]?n[t]-i[t]:n[e]-i[e]}}function Cr(e){const t=e.chart,n=t.options.animation;t.notifyPlugins("afterRender"),N(n&&n.onComplete,[e],t)}function mg(e){const t=e.chart,n=t.options.animation;N(n&&n.onProgress,[e],t)}function Sl(e){return no()&&typeof e=="string"?e=document.getElementById(e):e&&e.length&&(e=e[0]),e&&e.canvas&&(e=e.canvas),e}const ui={},Or=e=>{const t=Sl(e);return Object.values(ui).filter(n=>n.canvas===t).pop()};function bg(e,t,n){const i=Object.keys(e);for(const s of i){const o=+s;if(o>=t){const r=e[s];delete e[s],(n>0||o>t)&&(e[o+n]=r)}}}function vg(e,t,n,i){return!n||e.type==="mouseout"?null:i?t:e}class Jt{static register(...t){Bt.add(...t),Mr()}static unregister(...t){Bt.remove(...t),Mr()}constructor(t,n){const i=this.config=new hg(n),s=Sl(t),o=Or(s);if(o)throw new Error("Canvas is already in use. Chart with ID '"+o.id+"' must be destroyed before the canvas with ID '"+o.canvas.id+"' can be reused.");const r=i.createResolver(i.chartOptionScopes(),this.getContext());this.platform=new(i.platform||Lp(s)),this.platform.updateConfig(i);const a=this.platform.acquireContext(s,r.aspectRatio),l=a&&a.canvas,c=l&&l.height,d=l&&l.width;if(this.id=ku(),this.ctx=a,this.canvas=l,this.width=d,this.height=c,this._options=r,this._aspectRatio=this.aspectRatio,this._layers=[],this._metasets=[],this._stacks=void 0,this.boxes=[],this.currentDevicePixelRatio=void 0,this.chartArea=void 0,this._active=[],this._lastEvent=void 0,this._listeners={},this._responsiveListeners=void 0,this._sortedMetasets=[],this.scales={},this._plugins=new tg,this.$proxies={},this._hiddenIndices={},this.attached=!1,this._animationsDisabled=void 0,this.$context=void 0,this._doResize=ju(h=>this.update(h),r.resizeDelay||0),this._dataChanges=[],ui[this.id]=this,!a||!l){console.error("Failed to create chart: can't acquire context from the given item");return}qt.listen(this,"complete",Cr),qt.listen(this,"progress",mg),this._initialize(),this.attached&&this.update()}get aspectRatio(){const{options:{aspectRatio:t,maintainAspectRatio:n},width:i,height:s,_aspectRatio:o}=this;return G(t)?n&&o?o:s?i/s:null:t}get data(){return this.config.data}set data(t){this.config.data=t}get options(){return this._options}set options(t){this.config.options=t}get registry(){return Bt}_initialize(){return this.notifyPlugins("beforeInit"),this.options.responsive?this.resize():tr(this,this.options.devicePixelRatio),this.bindEvents(),this.notifyPlugins("afterInit"),this}clear(){return Zo(this.canvas,this.ctx),this}stop(){return qt.stop(this),this}resize(t,n){qt.running(this)?this._resizeBeforeDraw={width:t,height:n}:this._resize(t,n)}_resize(t,n){const i=this.options,s=this.canvas,o=i.maintainAspectRatio&&this.aspectRatio,r=this.platform.getMaximumSize(s,t,n,o),a=i.devicePixelRatio||this.platform.getDevicePixelRatio(),l=this.width?"resize":"attach";this.width=r.width,this.height=r.height,this._aspectRatio=this.aspectRatio,tr(this,a,!0)&&(this.notifyPlugins("resize",{size:r}),N(i.onResize,[this,r],this),this.attached&&this._doResize(l)&&this.render())}ensureScalesHaveIDs(){const n=this.options.scales||{};U(n,(i,s)=>{i.id=s})}buildOrUpdateScales(){const t=this.options,n=t.scales,i=this.scales,s=Object.keys(i).reduce((r,a)=>(r[a]=!1,r),{});let o=[];n&&(o=o.concat(Object.keys(n).map(r=>{const a=n[r],l=Ts(r,a),c=l==="r",d=l==="x";return{options:a,dposition:c?"chartArea":d?"bottom":"left",dtype:c?"radialLinear":d?"category":"linear"}}))),U(o,r=>{const a=r.options,l=a.id,c=Ts(l,a),d=B(a.type,r.dtype);(a.position===void 0||Er(a.position,c)!==Er(r.dposition))&&(a.position=r.dposition),s[l]=!0;let h=null;if(l in i&&i[l].type===d)h=i[l];else{const f=Bt.getScale(d);h=new f({id:l,type:d,ctx:this.ctx,chart:this}),i[h.id]=h}h.init(a,t)}),U(s,(r,a)=>{r||delete i[a]}),U(i,r=>{se.configure(this,r,r.options),se.addBox(this,r)})}_updateMetasets(){const t=this._metasets,n=this.data.datasets.length,i=t.length;if(t.sort((s,o)=>s.index-o.index),i>n){for(let s=n;s<i;++s)this._destroyDatasetMeta(s);t.splice(n,i-n)}this._sortedMetasets=t.slice(0).sort(Tr("order","index"))}_removeUnreferencedMetasets(){const{_metasets:t,data:{datasets:n}}=this;t.length>n.length&&delete this._stacks,t.forEach((i,s)=>{n.filter(o=>o===i._dataset).length===0&&this._destroyDatasetMeta(s)})}buildOrUpdateControllers(){const t=[],n=this.data.datasets;let i,s;for(this._removeUnreferencedMetasets(),i=0,s=n.length;i<s;i++){const o=n[i];let r=this.getDatasetMeta(i);const a=o.type||this.config.type;if(r.type&&r.type!==a&&(this._destroyDatasetMeta(i),r=this.getDatasetMeta(i)),r.type=a,r.indexAxis=o.indexAxis||Es(a,this.options),r.order=o.order||0,r.index=i,r.label=""+o.label,r.visible=this.isDatasetVisible(i),r.controller)r.controller.updateIndex(i),r.controller.linkScales();else{const l=Bt.getController(a),{datasetElementType:c,dataElementType:d}=Q.datasets[a];Object.assign(l,{dataElementType:Bt.getElement(d),datasetElementType:c&&Bt.getElement(c)}),r.controller=new l(this,i),t.push(r.controller)}}return this._updateMetasets(),t}_resetElements(){U(this.data.datasets,(t,n)=>{this.getDatasetMeta(n).controller.reset()},this)}reset(){this._resetElements(),this.notifyPlugins("reset")}update(t){const n=this.config;n.update();const i=this._options=n.createResolver(n.chartOptionScopes(),this.getContext()),s=this._animationsDisabled=!i.animation;if(this._updateScales(),this._checkEventBindings(),this._updateHiddenIndices(),this._plugins.invalidate(),this.notifyPlugins("beforeUpdate",{mode:t,cancelable:!0})===!1)return;const o=this.buildOrUpdateControllers();this.notifyPlugins("beforeElementsUpdate");let r=0;for(let c=0,d=this.data.datasets.length;c<d;c++){const{controller:h}=this.getDatasetMeta(c),f=!s&&o.indexOf(h)===-1;h.buildOrUpdateElements(f),r=Math.max(+h.getMaxOverflow(),r)}r=this._minPadding=i.layout.autoPadding?r:0,this._updateLayout(r),s||U(o,c=>{c.reset()}),this._updateDatasets(t),this.notifyPlugins("afterUpdate",{mode:t}),this._layers.sort(Tr("z","_idx"));const{_active:a,_lastEvent:l}=this;l?this._eventHandler(l,!0):a.length&&this._updateHoverStyles(a,a,!0),this.render()}_updateScales(){U(this.scales,t=>{se.removeBox(this,t)}),this.ensureScalesHaveIDs(),this.buildOrUpdateScales()}_checkEventBindings(){const t=this.options,n=new Set(Object.keys(this._listeners)),i=new Set(t.events);(!Ho(n,i)||!!this._responsiveListeners!==t.responsive)&&(this.unbindEvents(),this.bindEvents())}_updateHiddenIndices(){const{_hiddenIndices:t}=this,n=this._getUniformDataChanges()||[];for(const{method:i,start:s,count:o}of n){const r=i==="_removeElements"?-o:o;bg(t,s,r)}}_getUniformDataChanges(){const t=this._dataChanges;if(!t||!t.length)return;this._dataChanges=[];const n=this.data.datasets.length,i=o=>new Set(t.filter(r=>r[0]===o).map((r,a)=>a+","+r.splice(1).join(","))),s=i(0);for(let o=1;o<n;o++)if(!Ho(s,i(o)))return;return Array.from(s).map(o=>o.split(",")).map(o=>({method:o[1],start:+o[2],count:+o[3]}))}_updateLayout(t){if(this.notifyPlugins("beforeLayout",{cancelable:!0})===!1)return;se.update(this,this.width,this.height,t);const n=this.chartArea,i=n.width<=0||n.height<=0;this._layers=[],U(this.boxes,s=>{i&&s.position==="chartArea"||(s.configure&&s.configure(),this._layers.push(...s._layers()))},this),this._layers.forEach((s,o)=>{s._idx=o}),this.notifyPlugins("afterLayout")}_updateDatasets(t){if(this.notifyPlugins("beforeDatasetsUpdate",{mode:t,cancelable:!0})!==!1){for(let n=0,i=this.data.datasets.length;n<i;++n)this.getDatasetMeta(n).controller.configure();for(let n=0,i=this.data.datasets.length;n<i;++n)this._updateDataset(n,le(t)?t({datasetIndex:n}):t);this.notifyPlugins("afterDatasetsUpdate",{mode:t})}}_updateDataset(t,n){const i=this.getDatasetMeta(t),s={meta:i,index:t,mode:n,cancelable:!0};this.notifyPlugins("beforeDatasetUpdate",s)!==!1&&(i.controller._update(n),s.cancelable=!1,this.notifyPlugins("afterDatasetUpdate",s))}render(){this.notifyPlugins("beforeRender",{cancelable:!0})!==!1&&(qt.has(this)?this.attached&&!qt.running(this)&&qt.start(this):(this.draw(),Cr({chart:this})))}draw(){let t;if(this._resizeBeforeDraw){const{width:i,height:s}=this._resizeBeforeDraw;this._resizeBeforeDraw=null,this._resize(i,s)}if(this.clear(),this.width<=0||this.height<=0||this.notifyPlugins("beforeDraw",{cancelable:!0})===!1)return;const n=this._layers;for(t=0;t<n.length&&n[t].z<=0;++t)n[t].draw(this.chartArea);for(this._drawDatasets();t<n.length;++t)n[t].draw(this.chartArea);this.notifyPlugins("afterDraw")}_getSortedDatasetMetas(t){const n=this._sortedMetasets,i=[];let s,o;for(s=0,o=n.length;s<o;++s){const r=n[s];(!t||r.visible)&&i.push(r)}return i}getSortedVisibleDatasetMetas(){return this._getSortedDatasetMetas(!0)}_drawDatasets(){if(this.notifyPlugins("beforeDatasetsDraw",{cancelable:!0})===!1)return;const t=this.getSortedVisibleDatasetMetas();for(let n=t.length-1;n>=0;--n)this._drawDataset(t[n]);this.notifyPlugins("afterDatasetsDraw")}_drawDataset(t){const n=this.ctx,i={meta:t,index:t.index,cancelable:!0},s=fl(this,t);this.notifyPlugins("beforeDatasetDraw",i)!==!1&&(s&&Ni(n,s),t.controller.draw(),s&&Li(n),i.cancelable=!1,this.notifyPlugins("afterDatasetDraw",i))}isPointInArea(t){return Ve(t,this.chartArea,this._minPadding)}getElementsAtEventForMode(t,n,i,s){const o=gp.modes[n];return typeof o=="function"?o(this,t,i,s):[]}getDatasetMeta(t){const n=this.data.datasets[t],i=this._metasets;let s=i.filter(o=>o&&o._dataset===n).pop();return s||(s={type:null,data:[],dataset:null,controller:null,hidden:null,xAxisID:null,yAxisID:null,order:n&&n.order||0,index:t,_dataset:n,_parsed:[],_sorted:!1},i.push(s)),s}getContext(){return this.$context||(this.$context=Ae(null,{chart:this,type:"chart"}))}getVisibleDatasetCount(){return this.getSortedVisibleDatasetMetas().length}isDatasetVisible(t){const n=this.data.datasets[t];if(!n)return!1;const i=this.getDatasetMeta(t);return typeof i.hidden=="boolean"?!i.hidden:!n.hidden}setDatasetVisibility(t,n){const i=this.getDatasetMeta(t);i.hidden=!n}toggleDataVisibility(t){this._hiddenIndices[t]=!this._hiddenIndices[t]}getDataVisibility(t){return!this._hiddenIndices[t]}_updateVisibility(t,n,i){const s=i?"show":"hide",o=this.getDatasetMeta(t),r=o.controller._resolveAnimations(void 0,s);_i(n)?(o.data[n].hidden=!i,this.update()):(this.setDatasetVisibility(t,i),r.update(o,{visible:i}),this.update(a=>a.datasetIndex===t?s:void 0))}hide(t,n){this._updateVisibility(t,n,!1)}show(t,n){this._updateVisibility(t,n,!0)}_destroyDatasetMeta(t){const n=this._metasets[t];n&&n.controller&&n.controller._destroy(),delete this._metasets[t]}_stop(){let t,n;for(this.stop(),qt.remove(this),t=0,n=this.data.datasets.length;t<n;++t)this._destroyDatasetMeta(t)}destroy(){this.notifyPlugins("beforeDestroy");const{canvas:t,ctx:n}=this;this._stop(),this.config.clearCache(),t&&(this.unbindEvents(),Zo(t,n),this.platform.releaseContext(n),this.canvas=null,this.ctx=null),delete ui[this.id],this.notifyPlugins("afterDestroy")}toBase64Image(...t){return this.canvas.toDataURL(...t)}bindEvents(){this.bindUserEvents(),this.options.responsive?this.bindResponsiveEvents():this.attached=!0}bindUserEvents(){const t=this._listeners,n=this.platform,i=(o,r)=>{n.addEventListener(this,o,r),t[o]=r},s=(o,r,a)=>{o.offsetX=r,o.offsetY=a,this._eventHandler(o)};U(this.options.events,o=>i(o,s))}bindResponsiveEvents(){this._responsiveListeners||(this._responsiveListeners={});const t=this._responsiveListeners,n=this.platform,i=(l,c)=>{n.addEventListener(this,l,c),t[l]=c},s=(l,c)=>{t[l]&&(n.removeEventListener(this,l,c),delete t[l])},o=(l,c)=>{this.canvas&&this.resize(l,c)};let r;const a=()=>{s("attach",a),this.attached=!0,this.resize(),i("resize",o),i("detach",r)};r=()=>{this.attached=!1,s("resize",o),this._stop(),this._resize(0,0),i("attach",a)},n.isAttached(this.canvas)?a():r()}unbindEvents(){U(this._listeners,(t,n)=>{this.platform.removeEventListener(this,n,t)}),this._listeners={},U(this._responsiveListeners,(t,n)=>{this.platform.removeEventListener(this,n,t)}),this._responsiveListeners=void 0}updateHoverStyle(t,n,i){const s=i?"set":"remove";let o,r,a,l;for(n==="dataset"&&(o=this.getDatasetMeta(t[0].datasetIndex),o.controller["_"+s+"DatasetHoverStyle"]()),a=0,l=t.length;a<l;++a){r=t[a];const c=r&&this.getDatasetMeta(r.datasetIndex).controller;c&&c[s+"HoverStyle"](r.element,r.datasetIndex,r.index)}}getActiveElements(){return this._active||[]}setActiveElements(t){const n=this._active||[],i=t.map(({datasetIndex:o,index:r})=>{const a=this.getDatasetMeta(o);if(!a)throw new Error("No dataset found at index "+o);return{datasetIndex:o,element:a.data[r],index:r}});!vi(i,n)&&(this._active=i,this._lastEvent=null,this._updateHoverStyles(i,n))}notifyPlugins(t,n,i){return this._plugins.notify(this,t,n,i)}isPluginEnabled(t){return this._plugins._cache.filter(n=>n.plugin.id===t).length===1}_updateHoverStyles(t,n,i){const s=this.options.hover,o=(l,c)=>l.filter(d=>!c.some(h=>d.datasetIndex===h.datasetIndex&&d.index===h.index)),r=o(n,t),a=i?t:o(t,n);r.length&&this.updateHoverStyle(r,s.mode,!1),a.length&&s.mode&&this.updateHoverStyle(a,s.mode,!0)}_eventHandler(t,n){const i={event:t,replay:n,cancelable:!0,inChartArea:this.isPointInArea(t)},s=r=>(r.options.events||this.options.events).includes(t.native.type);if(this.notifyPlugins("beforeEvent",i,s)===!1)return;const o=this._handleEvent(t,n,i.inChartArea);return i.cancelable=!1,this.notifyPlugins("afterEvent",i,s),(o||i.changed)&&this.render(),this}_handleEvent(t,n,i){const{_active:s=[],options:o}=this,r=n,a=this._getActiveElements(t,s,i,r),l=Mu(t),c=vg(t,this._lastEvent,i,l);i&&(this._lastEvent=null,N(o.onHover,[t,a,this],this),l&&N(o.onClick,[t,a,this],this));const d=!vi(a,s);return(d||n)&&(this._active=a,this._updateHoverStyles(a,s,n)),this._lastEvent=c,d}_getActiveElements(t,n,i,s){if(t.type==="mouseout")return[];if(!i)return n;const o=this.options.hover;return this.getElementsAtEventForMode(t,o.mode,o,s)}}F(Jt,"defaults",Q),F(Jt,"instances",ui),F(Jt,"overrides",Te),F(Jt,"registry",Bt),F(Jt,"version",pg),F(Jt,"getChart",Or);function Mr(){return U(Jt.instances,e=>e._plugins.invalidate())}function El(e,t,n=t){e.lineCap=B(n.borderCapStyle,t.borderCapStyle),e.setLineDash(B(n.borderDash,t.borderDash)),e.lineDashOffset=B(n.borderDashOffset,t.borderDashOffset),e.lineJoin=B(n.borderJoinStyle,t.borderJoinStyle),e.lineWidth=B(n.borderWidth,t.borderWidth),e.strokeStyle=B(n.borderColor,t.borderColor)}function yg(e,t,n){e.lineTo(n.x,n.y)}function xg(e){return e.stepped?of:e.tension||e.cubicInterpolationMode==="monotone"?rf:yg}function Tl(e,t,n={}){const i=e.length,{start:s=0,end:o=i-1}=n,{start:r,end:a}=t,l=Math.max(s,r),c=Math.min(o,a),d=s<r&&o<r||s>a&&o>a;return{count:i,start:l,loop:t.loop,ilen:c<l&&!d?i+c-l:c-l}}function _g(e,t,n,i){const{points:s,options:o}=t,{count:r,start:a,loop:l,ilen:c}=Tl(s,n,i),d=xg(o);let{move:h=!0,reverse:f}=i||{},g,m,v;for(g=0;g<=c;++g)m=s[(a+(f?c-g:g))%r],!m.skip&&(h?(e.moveTo(m.x,m.y),h=!1):d(e,v,m,f,o.stepped),v=m);return l&&(m=s[(a+(f?c:0))%r],d(e,v,m,f,o.stepped)),!!l}function wg(e,t,n,i){const s=t.points,{count:o,start:r,ilen:a}=Tl(s,n,i),{move:l=!0,reverse:c}=i||{};let d=0,h=0,f,g,m,v,y,_;const E=M=>(r+(c?a-M:M))%o,O=()=>{v!==y&&(e.lineTo(d,y),e.lineTo(d,v),e.lineTo(d,_))};for(l&&(g=s[E(0)],e.moveTo(g.x,g.y)),f=0;f<=a;++f){if(g=s[E(f)],g.skip)continue;const M=g.x,k=g.y,C=M|0;C===m?(k<v?v=k:k>y&&(y=k),d=(h*d+M)/++h):(O(),e.lineTo(M,k),m=C,h=0,v=y=k),_=k}O()}function Cs(e){const t=e.options,n=t.borderDash&&t.borderDash.length;return!e._decimated&&!e._loop&&!t.tension&&t.cubicInterpolationMode!=="monotone"&&!t.stepped&&!n?wg:_g}function kg(e){return e.stepped?Ff:e.tension||e.cubicInterpolationMode==="monotone"?Bf:xe}function Sg(e,t,n,i){let s=t._path;s||(s=t._path=new Path2D,t.path(s,n,i)&&s.closePath()),El(e,t.options),e.stroke(s)}function Eg(e,t,n,i){const{segments:s,options:o}=t,r=Cs(t);for(const a of s)El(e,o,a.style),e.beginPath(),r(e,t,a,{start:n,end:n+i-1})&&e.closePath(),e.stroke()}const Tg=typeof Path2D=="function";function Cg(e,t,n,i){Tg&&!t.options.segment?Sg(e,t,n,i):Eg(e,t,n,i)}class oe extends de{constructor(t){super(),this.animated=!0,this.options=void 0,this._chart=void 0,this._loop=void 0,this._fullLoop=void 0,this._path=void 0,this._points=void 0,this._segments=void 0,this._decimated=!1,this._pointsUpdated=!1,this._datasetIndex=void 0,t&&Object.assign(this,t)}updateControlPoints(t,n){const i=this.options;if((i.tension||i.cubicInterpolationMode==="monotone")&&!i.stepped&&!this._pointsUpdated){const s=i.spanGaps?this._loop:this._fullLoop;Af(this._points,i,t,s,n),this._pointsUpdated=!0}}set points(t){this._points=t,delete this._segments,delete this._path,this._pointsUpdated=!1}get points(){return this._points}get segments(){return this._segments||(this._segments=Yf(this,this.options.segment))}first(){const t=this.segments,n=this.points;return t.length&&n[t[0].start]}last(){const t=this.segments,n=this.points,i=t.length;return i&&n[t[i-1].end]}interpolate(t,n){const i=this.options,s=t[n],o=this.points,r=ul(this,{property:n,start:s,end:s});if(!r.length)return;const a=[],l=kg(i);let c,d;for(c=0,d=r.length;c<d;++c){const{start:h,end:f}=r[c],g=o[h],m=o[f];if(g===m){a.push(g);continue}const v=Math.abs((s-g[n])/(m[n]-g[n])),y=l(g,m,v,i.stepped);y[n]=t[n],a.push(y)}return a.length===1?a[0]:a}pathSegment(t,n,i){return Cs(this)(t,this,n,i)}path(t,n,i){const s=this.segments,o=Cs(this);let r=this._loop;n=n||0,i=i||this.points.length-n;for(const a of s)r&=o(t,this,a,{start:n,end:n+i-1});return!!r}draw(t,n,i,s){const o=this.options||{};(this.points||[]).length&&o.borderWidth&&(t.save(),Cg(t,this,i,s),t.restore()),this.animated&&(this._pointsUpdated=!1,this._path=void 0)}}F(oe,"id","line"),F(oe,"defaults",{borderCapStyle:"butt",borderDash:[],borderDashOffset:0,borderJoinStyle:"miter",borderWidth:3,capBezierPoints:!0,cubicInterpolationMode:"default",fill:!1,spanGaps:!1,stepped:!1,tension:0}),F(oe,"defaultRoutes",{backgroundColor:"backgroundColor",borderColor:"borderColor"}),F(oe,"descriptors",{_scriptable:!0,_indexable:t=>t!=="borderDash"&&t!=="fill"});function Pr(e,t,n,i){const s=e.options,{[n]:o}=e.getProps([n],i);return Math.abs(t-o)<s.radius+s.hitRadius}class fi extends de{constructor(n){super();F(this,"parsed");F(this,"skip");F(this,"stop");this.options=void 0,this.parsed=void 0,this.skip=void 0,this.stop=void 0,n&&Object.assign(this,n)}inRange(n,i,s){const o=this.options,{x:r,y:a}=this.getProps(["x","y"],s);return Math.pow(n-r,2)+Math.pow(i-a,2)<Math.pow(o.hitRadius+o.radius,2)}inXRange(n,i){return Pr(this,n,"x",i)}inYRange(n,i){return Pr(this,n,"y",i)}getCenterPoint(n){const{x:i,y:s}=this.getProps(["x","y"],n);return{x:i,y:s}}size(n){n=n||this.options||{};let i=n.radius||0;i=Math.max(i,i&&n.hoverRadius||0);const s=i&&n.borderWidth||0;return(i+s)*2}draw(n,i){const s=this.options;this.skip||s.radius<.1||!Ve(this,i,this.size(s)/2)||(n.strokeStyle=s.borderColor,n.lineWidth=s.borderWidth,n.fillStyle=s.backgroundColor,ks(n,s,this.x,this.y))}getRange(){const n=this.options||{};return n.radius+n.hitRadius}}F(fi,"id","point"),F(fi,"defaults",{borderWidth:1,hitRadius:1,hoverBorderWidth:1,hoverRadius:4,pointStyle:"circle",radius:3,rotation:0}),F(fi,"defaultRoutes",{backgroundColor:"backgroundColor",borderColor:"borderColor"});function Og(e,t,n){const i=e.segments,s=e.points,o=t.points,r=[];for(const a of i){let{start:l,end:c}=a;c=Fi(l,c,s);const d=Os(n,s[l],s[c],a.loop);if(!t.segments){r.push({source:a,target:d,start:s[l],end:s[c]});continue}const h=ul(t,d);for(const f of h){const g=Os(n,o[f.start],o[f.end],f.loop),m=hl(a,s,g);for(const v of m)r.push({source:v,target:f,start:{[n]:Ar(d,g,"start",Math.max)},end:{[n]:Ar(d,g,"end",Math.min)}})}}return r}function Os(e,t,n,i){if(i)return;let s=t[e],o=n[e];return e==="angle"&&(s=Ht(s),o=Ht(o)),{property:e,start:s,end:o}}function Mg(e,t){const{x:n=null,y:i=null}=e||{},s=t.points,o=[];return t.segments.forEach(({start:r,end:a})=>{a=Fi(r,a,s);const l=s[r],c=s[a];i!==null?(o.push({x:l.x,y:i}),o.push({x:c.x,y:i})):n!==null&&(o.push({x:n,y:l.y}),o.push({x:n,y:c.y}))}),o}function Fi(e,t,n){for(;t>e;t--){const i=n[t];if(!isNaN(i.x)&&!isNaN(i.y))break}return t}function Ar(e,t,n,i){return e&&t?i(e[n],t[n]):e?e[n]:t?t[n]:0}function Cl(e,t){let n=[],i=!1;return ct(e)?(i=!0,n=e):n=Mg(e,t),n.length?new oe({points:n,options:{tension:0},_loop:i,_fullLoop:i}):null}function Dr(e){return e&&e.fill!==!1}function Pg(e,t,n){let s=e[t].fill;const o=[t];let r;if(!n)return s;for(;s!==!1&&o.indexOf(s)===-1;){if(!ft(s))return s;if(r=e[s],!r)return!1;if(r.visible)return s;o.push(s),s=r.fill}return!1}function Ag(e,t,n){const i=Ng(e);if(W(i))return isNaN(i.value)?!1:i;let s=parseFloat(i);return ft(s)&&Math.floor(s)===s?Dg(i[0],t,s,n):["origin","start","end","stack","shape"].indexOf(i)>=0&&i}function Dg(e,t,n,i){return(e==="-"||e==="+")&&(n=t+n),n===t||n<0||n>=i?!1:n}function Ig(e,t){let n=null;return e==="start"?n=t.bottom:e==="end"?n=t.top:W(e)?n=t.getPixelForValue(e.value):t.getBasePixel&&(n=t.getBasePixel()),n}function Rg(e,t,n){let i;return e==="start"?i=n:e==="end"?i=t.options.reverse?t.min:t.max:W(e)?i=e.value:i=t.getBaseValue(),i}function Ng(e){const t=e.options,n=t.fill;let i=B(n&&n.target,n);return i===void 0&&(i=!!t.backgroundColor),i===!1||i===null?!1:i===!0?"origin":i}function Lg(e){const{scale:t,index:n,line:i}=e,s=[],o=i.segments,r=i.points,a=zg(t,n);a.push(Cl({x:null,y:t.bottom},i));for(let l=0;l<o.length;l++){const c=o[l];for(let d=c.start;d<=c.end;d++)$g(s,r[d],a)}return new oe({points:s,options:{}})}function zg(e,t){const n=[],i=e.getMatchingVisibleMetas("line");for(let s=0;s<i.length;s++){const o=i[s];if(o.index===t)break;o.hidden||n.unshift(o.dataset)}return n}function $g(e,t,n){const i=[];for(let s=0;s<n.length;s++){const o=n[s],{first:r,last:a,point:l}=Fg(o,t,"x");if(!(!l||r&&a)){if(r)i.unshift(l);else if(e.push(l),!a)break}}e.push(...i)}function Fg(e,t,n){const i=e.interpolate(t,n);if(!i)return{};const s=i[n],o=e.segments,r=e.points;let a=!1,l=!1;for(let c=0;c<o.length;c++){const d=o[c],h=r[d.start][n],f=r[d.end][n];if($e(s,h,f)){a=s===h,l=s===f;break}}return{first:a,last:l,point:i}}class Ol{constructor(t){this.x=t.x,this.y=t.y,this.radius=t.radius}pathSegment(t,n,i){const{x:s,y:o,radius:r}=this;return n=n||{start:0,end:It},t.arc(s,o,r,n.end,n.start,!0),!i.bounds}interpolate(t){const{x:n,y:i,radius:s}=this,o=t.angle;return{x:n+Math.cos(o)*s,y:i+Math.sin(o)*s,angle:o}}}function Bg(e){const{chart:t,fill:n,line:i}=e;if(ft(n))return Hg(t,n);if(n==="stack")return Lg(e);if(n==="shape")return!0;const s=Ug(e);return s instanceof Ol?s:Cl(s,i)}function Hg(e,t){const n=e.getDatasetMeta(t);return n&&e.isDatasetVisible(t)?n.dataset:null}function Ug(e){return(e.scale||{}).getPointPositionForValue?jg(e):Wg(e)}function Wg(e){const{scale:t={},fill:n}=e,i=Ig(n,t);if(ft(i)){const s=t.isHorizontal();return{x:s?i:null,y:s?null:i}}return null}function jg(e){const{scale:t,fill:n}=e,i=t.options,s=t.getLabels().length,o=i.reverse?t.max:t.min,r=Rg(n,t,o),a=[];if(i.grid.circular){const l=t.getPointPositionForValue(0,o);return new Ol({x:l.x,y:l.y,radius:t.getDistanceFromCenterForValue(r)})}for(let l=0;l<s;++l)a.push(t.getPointPositionForValue(l,r));return a}function as(e,t,n){const i=Bg(t),{chart:s,index:o,line:r,scale:a,axis:l}=t,c=r.options,d=c.fill,h=c.backgroundColor,{above:f=h,below:g=h}=d||{},m=s.getDatasetMeta(o),v=fl(s,m);i&&r.points.length&&(Ni(e,n),Vg(e,{line:r,target:i,above:f,below:g,area:n,scale:a,axis:l,clip:v}),Li(e))}function Vg(e,t){const{line:n,target:i,above:s,below:o,area:r,scale:a,clip:l}=t,c=n._loop?"angle":t.axis;e.save();let d=o;o!==s&&(c==="x"?(Ir(e,i,r.top),ls(e,{line:n,target:i,color:s,scale:a,property:c,clip:l}),e.restore(),e.save(),Ir(e,i,r.bottom)):c==="y"&&(Rr(e,i,r.left),ls(e,{line:n,target:i,color:o,scale:a,property:c,clip:l}),e.restore(),e.save(),Rr(e,i,r.right),d=s)),ls(e,{line:n,target:i,color:d,scale:a,property:c,clip:l}),e.restore()}function Ir(e,t,n){const{segments:i,points:s}=t;let o=!0,r=!1;e.beginPath();for(const a of i){const{start:l,end:c}=a,d=s[l],h=s[Fi(l,c,s)];o?(e.moveTo(d.x,d.y),o=!1):(e.lineTo(d.x,n),e.lineTo(d.x,d.y)),r=!!t.pathSegment(e,a,{move:r}),r?e.closePath():e.lineTo(h.x,n)}e.lineTo(t.first().x,n),e.closePath(),e.clip()}function Rr(e,t,n){const{segments:i,points:s}=t;let o=!0,r=!1;e.beginPath();for(const a of i){const{start:l,end:c}=a,d=s[l],h=s[Fi(l,c,s)];o?(e.moveTo(d.x,d.y),o=!1):(e.lineTo(n,d.y),e.lineTo(d.x,d.y)),r=!!t.pathSegment(e,a,{move:r}),r?e.closePath():e.lineTo(n,h.y)}e.lineTo(n,t.first().y),e.closePath(),e.clip()}function ls(e,t){const{line:n,target:i,property:s,color:o,scale:r,clip:a}=t,l=Og(n,i,s);for(const{source:c,target:d,start:h,end:f}of l){const{style:{backgroundColor:g=o}={}}=c,m=i!==!0;e.save(),e.fillStyle=g,Yg(e,r,a,m&&Os(s,h,f)),e.beginPath();const v=!!n.pathSegment(e,c);let y;if(m){v?e.closePath():Nr(e,i,f,s);const _=!!i.pathSegment(e,d,{move:v,reverse:!0});y=v&&_,y||Nr(e,i,h,s)}e.closePath(),e.fill(y?"evenodd":"nonzero"),e.restore()}}function Yg(e,t,n,i){const s=t.chart.chartArea,{property:o,start:r,end:a}=i||{};if(o==="x"||o==="y"){let l,c,d,h;o==="x"?(l=r,c=s.top,d=a,h=s.bottom):(l=s.left,c=r,d=s.right,h=a),e.beginPath(),n&&(l=Math.max(l,n.left),d=Math.min(d,n.right),c=Math.max(c,n.top),h=Math.min(h,n.bottom)),e.rect(l,c,d-l,h-c),e.clip()}}function Nr(e,t,n,i){const s=t.interpolate(n,i);s&&e.lineTo(s.x,s.y)}var Gg={id:"filler",afterDatasetsUpdate(e,t,n){const i=(e.data.datasets||[]).length,s=[];let o,r,a,l;for(r=0;r<i;++r)o=e.getDatasetMeta(r),a=o.dataset,l=null,a&&a.options&&a instanceof oe&&(l={visible:e.isDatasetVisible(r),index:r,fill:Ag(a,r,i),chart:e,axis:o.controller.options.indexAxis,scale:o.vScale,line:a}),o.$filler=l,s.push(l);for(r=0;r<i;++r)l=s[r],!(!l||l.fill===!1)&&(l.fill=Pg(s,r,n.propagate))},beforeDraw(e,t,n){const i=n.drawTime==="beforeDraw",s=e.getSortedVisibleDatasetMetas(),o=e.chartArea;for(let r=s.length-1;r>=0;--r){const a=s[r].$filler;a&&(a.line.updateControlPoints(o,a.axis),i&&a.fill&&as(e.ctx,a,o))}},beforeDatasetsDraw(e,t,n){if(n.drawTime!=="beforeDatasetsDraw")return;const i=e.getSortedVisibleDatasetMetas();for(let s=i.length-1;s>=0;--s){const o=i[s].$filler;Dr(o)&&as(e.ctx,o,e.chartArea)}},beforeDatasetDraw(e,t,n){const i=t.meta.$filler;!Dr(i)||n.drawTime!=="beforeDatasetDraw"||as(e.ctx,i,e.chartArea)},defaults:{propagate:!0,drawTime:"beforeDatasetDraw"}};const Lr=(e,t)=>{let{boxHeight:n=t,boxWidth:i=t}=e;return e.usePointStyle&&(n=Math.min(n,t),i=e.pointStyleWidth||Math.min(i,t)),{boxWidth:i,boxHeight:n,itemHeight:Math.max(t,n)}},Kg=(e,t)=>e!==null&&t!==null&&e.datasetIndex===t.datasetIndex&&e.index===t.index;class zr extends de{constructor(t){super(),this._added=!1,this.legendHitBoxes=[],this._hoveredItem=null,this.doughnutMode=!1,this.chart=t.chart,this.options=t.options,this.ctx=t.ctx,this.legendItems=void 0,this.columnSizes=void 0,this.lineWidths=void 0,this.maxHeight=void 0,this.maxWidth=void 0,this.top=void 0,this.bottom=void 0,this.left=void 0,this.right=void 0,this.height=void 0,this.width=void 0,this._margins=void 0,this.position=void 0,this.weight=void 0,this.fullSize=void 0}update(t,n,i){this.maxWidth=t,this.maxHeight=n,this._margins=i,this.setDimensions(),this.buildLabels(),this.fit()}setDimensions(){this.isHorizontal()?(this.width=this.maxWidth,this.left=this._margins.left,this.right=this.width):(this.height=this.maxHeight,this.top=this._margins.top,this.bottom=this.height)}buildLabels(){const t=this.options.labels||{};let n=N(t.generateLabels,[this.chart],this)||[];t.filter&&(n=n.filter(i=>t.filter(i,this.chart.data))),t.sort&&(n=n.sort((i,s)=>t.sort(i,s,this.chart.data))),this.options.reverse&&n.reverse(),this.legendItems=n}fit(){const{options:t,ctx:n}=this;if(!t.display){this.width=this.height=0;return}const i=t.labels,s=xt(i.font),o=s.size,r=this._computeTitleHeight(),{boxWidth:a,itemHeight:l}=Lr(i,o);let c,d;n.font=s.string,this.isHorizontal()?(c=this.maxWidth,d=this._fitRows(r,o,a,l)+10):(d=this.maxHeight,c=this._fitCols(r,s,a,l)+10),this.width=Math.min(c,t.maxWidth||this.maxWidth),this.height=Math.min(d,t.maxHeight||this.maxHeight)}_fitRows(t,n,i,s){const{ctx:o,maxWidth:r,options:{labels:{padding:a}}}=this,l=this.legendHitBoxes=[],c=this.lineWidths=[0],d=s+a;let h=t;o.textAlign="left",o.textBaseline="middle";let f=-1,g=-d;return this.legendItems.forEach((m,v)=>{const y=i+n/2+o.measureText(m.text).width;(v===0||c[c.length-1]+y+2*a>r)&&(h+=d,c[c.length-(v>0?0:1)]=0,g+=d,f++),l[v]={left:0,top:g,row:f,width:y,height:s},c[c.length-1]+=y+a}),h}_fitCols(t,n,i,s){const{ctx:o,maxHeight:r,options:{labels:{padding:a}}}=this,l=this.legendHitBoxes=[],c=this.columnSizes=[],d=r-t;let h=a,f=0,g=0,m=0,v=0;return this.legendItems.forEach((y,_)=>{const{itemWidth:E,itemHeight:O}=qg(i,n,o,y,s);_>0&&g+O+2*a>d&&(h+=f+a,c.push({width:f,height:g}),m+=f+a,v++,f=g=0),l[_]={left:m,top:g,col:v,width:E,height:O},f=Math.max(f,E),g+=O+a}),h+=f,c.push({width:f,height:g}),h}adjustHitBoxes(){if(!this.options.display)return;const t=this._computeTitleHeight(),{legendHitBoxes:n,options:{align:i,labels:{padding:s},rtl:o}}=this,r=Be(o,this.left,this.width);if(this.isHorizontal()){let a=0,l=St(i,this.left+s,this.right-this.lineWidths[a]);for(const c of n)a!==c.row&&(a=c.row,l=St(i,this.left+s,this.right-this.lineWidths[a])),c.top+=this.top+t+s,c.left=r.leftForLtr(r.x(l),c.width),l+=c.width+s}else{let a=0,l=St(i,this.top+t+s,this.bottom-this.columnSizes[a].height);for(const c of n)c.col!==a&&(a=c.col,l=St(i,this.top+t+s,this.bottom-this.columnSizes[a].height)),c.top=l,c.left+=this.left+s,c.left=r.leftForLtr(r.x(c.left),c.width),l+=c.height+s}}isHorizontal(){return this.options.position==="top"||this.options.position==="bottom"}draw(){if(this.options.display){const t=this.ctx;Ni(t,this),this._draw(),Li(t)}}_draw(){const{options:t,columnSizes:n,lineWidths:i,ctx:s}=this,{align:o,labels:r}=t,a=Q.color,l=Be(t.rtl,this.left,this.width),c=xt(r.font),{padding:d}=r,h=c.size,f=h/2;let g;this.drawTitle(),s.textAlign=l.textAlign("left"),s.textBaseline="middle",s.lineWidth=.5,s.font=c.string;const{boxWidth:m,boxHeight:v,itemHeight:y}=Lr(r,h),_=function(C,A,P){if(isNaN(m)||m<=0||isNaN(v)||v<0)return;s.save();const I=B(P.lineWidth,1);if(s.fillStyle=B(P.fillStyle,a),s.lineCap=B(P.lineCap,"butt"),s.lineDashOffset=B(P.lineDashOffset,0),s.lineJoin=B(P.lineJoin,"miter"),s.lineWidth=I,s.strokeStyle=B(P.strokeStyle,a),s.setLineDash(B(P.lineDash,[])),r.usePointStyle){const z={radius:v*Math.SQRT2/2,pointStyle:P.pointStyle,rotation:P.rotation,borderWidth:I},R=l.xPlus(C,m/2),$=A+f;el(s,z,R,$,r.pointStyleWidth&&m)}else{const z=A+Math.max((h-v)/2,0),R=l.leftForLtr(C,m),$=mn(P.borderRadius);s.beginPath(),Object.values($).some(Z=>Z!==0)?Ss(s,{x:R,y:z,w:m,h:v,radius:$}):s.rect(R,z,m,v),s.fill(),I!==0&&s.stroke()}s.restore()},E=function(C,A,P){ki(s,P.text,C,A+y/2,c,{strikethrough:P.hidden,textAlign:l.textAlign(P.textAlign)})},O=this.isHorizontal(),M=this._computeTitleHeight();O?g={x:St(o,this.left+d,this.right-i[0]),y:this.top+d+M,line:0}:g={x:this.left+d,y:St(o,this.top+M+d,this.bottom-n[0].height),line:0},ll(this.ctx,t.textDirection);const k=y+d;this.legendItems.forEach((C,A)=>{s.strokeStyle=C.fontColor,s.fillStyle=C.fontColor;const P=s.measureText(C.text).width,I=l.textAlign(C.textAlign||(C.textAlign=r.textAlign)),z=m+f+P;let R=g.x,$=g.y;l.setWidth(this.width),O?A>0&&R+z+d>this.right&&($=g.y+=k,g.line++,R=g.x=St(o,this.left+d,this.right-i[g.line])):A>0&&$+k>this.bottom&&(R=g.x=R+n[g.line].width+d,g.line++,$=g.y=St(o,this.top+M+d,this.bottom-n[g.line].height));const Z=l.x(R);if(_(Z,$,C),R=Vu(I,R+m+f,O?R+z:this.right,t.rtl),E(l.x(R),$,C),O)g.x+=z+d;else if(typeof C.text!="string"){const ot=c.lineHeight;g.y+=Ml(C,ot)+d}else g.y+=k}),cl(this.ctx,t.textDirection)}drawTitle(){const t=this.options,n=t.title,i=xt(n.font),s=Rt(n.padding);if(!n.display)return;const o=Be(t.rtl,this.left,this.width),r=this.ctx,a=n.position,l=i.size/2,c=s.top+l;let d,h=this.left,f=this.width;if(this.isHorizontal())f=Math.max(...this.lineWidths),d=this.top+c,h=St(t.align,h,this.right-f);else{const m=this.columnSizes.reduce((v,y)=>Math.max(v,y.height),0);d=c+St(t.align,this.top,this.bottom-m-t.labels.padding-this._computeTitleHeight())}const g=St(a,h,h+f);r.textAlign=o.textAlign(Ja(a)),r.textBaseline="middle",r.strokeStyle=n.color,r.fillStyle=n.color,r.font=i.string,ki(r,n.text,g,d,i)}_computeTitleHeight(){const t=this.options.title,n=xt(t.font),i=Rt(t.padding);return t.display?n.lineHeight+i.height:0}_getLegendItemAt(t,n){let i,s,o;if($e(t,this.left,this.right)&&$e(n,this.top,this.bottom)){for(o=this.legendHitBoxes,i=0;i<o.length;++i)if(s=o[i],$e(t,s.left,s.left+s.width)&&$e(n,s.top,s.top+s.height))return this.legendItems[i]}return null}handleEvent(t){const n=this.options;if(!Jg(t.type,n))return;const i=this._getLegendItemAt(t.x,t.y);if(t.type==="mousemove"||t.type==="mouseout"){const s=this._hoveredItem,o=Kg(s,i);s&&!o&&N(n.onLeave,[t,s,this],this),this._hoveredItem=i,i&&!o&&N(n.onHover,[t,i,this],this)}else i&&N(n.onClick,[t,i,this],this)}}function qg(e,t,n,i,s){const o=Xg(i,e,t,n),r=Zg(s,i,t.lineHeight);return{itemWidth:o,itemHeight:r}}function Xg(e,t,n,i){let s=e.text;return s&&typeof s!="string"&&(s=s.reduce((o,r)=>o.length>r.length?o:r)),t+n.size/2+i.measureText(s).width}function Zg(e,t,n){let i=e;return typeof t.text!="string"&&(i=Ml(t,n)),i}function Ml(e,t){const n=e.text?e.text.length:0;return t*n}function Jg(e,t){return!!((e==="mousemove"||e==="mouseout")&&(t.onHover||t.onLeave)||t.onClick&&(e==="click"||e==="mouseup"))}var Qg={id:"legend",_element:zr,start(e,t,n){const i=e.legend=new zr({ctx:e.ctx,options:n,chart:e});se.configure(e,i,n),se.addBox(e,i)},stop(e){se.removeBox(e,e.legend),delete e.legend},beforeUpdate(e,t,n){const i=e.legend;se.configure(e,i,n),i.options=n},afterUpdate(e){const t=e.legend;t.buildLabels(),t.adjustHitBoxes()},afterEvent(e,t){t.replay||e.legend.handleEvent(t.event)},defaults:{display:!0,position:"top",align:"center",fullSize:!0,reverse:!1,weight:1e3,onClick(e,t,n){const i=t.datasetIndex,s=n.chart;s.isDatasetVisible(i)?(s.hide(i),t.hidden=!0):(s.show(i),t.hidden=!1)},onHover:null,onLeave:null,labels:{color:e=>e.chart.options.color,boxWidth:40,padding:10,generateLabels(e){const t=e.data.datasets,{labels:{usePointStyle:n,pointStyle:i,textAlign:s,color:o,useBorderRadius:r,borderRadius:a}}=e.legend.options;return e._getSortedDatasetMetas().map(l=>{const c=l.controller.getStyle(n?0:void 0),d=Rt(c.borderWidth);return{text:t[l.index].label,fillStyle:c.backgroundColor,fontColor:o,hidden:!l.visible,lineCap:c.borderCapStyle,lineDash:c.borderDash,lineDashOffset:c.borderDashOffset,lineJoin:c.borderJoinStyle,lineWidth:(d.width+d.height)/4,strokeStyle:c.borderColor,pointStyle:i||c.pointStyle,rotation:c.rotation,textAlign:s||c.textAlign,borderRadius:r&&(a||c.borderRadius),datasetIndex:l.index}},this)}},title:{color:e=>e.chart.options.color,display:!1,position:"center",text:""}},descriptors:{_scriptable:e=>!e.startsWith("on"),labels:{_scriptable:e=>!["generateLabels","filter","sort"].includes(e)}}};const un={average(e){if(!e.length)return!1;let t,n,i=new Set,s=0,o=0;for(t=0,n=e.length;t<n;++t){const a=e[t].element;if(a&&a.hasValue()){const l=a.tooltipPosition();i.add(l.x),s+=l.y,++o}}return o===0||i.size===0?!1:{x:[...i].reduce((a,l)=>a+l)/i.size,y:s/o}},nearest(e,t){if(!e.length)return!1;let n=t.x,i=t.y,s=Number.POSITIVE_INFINITY,o,r,a;for(o=0,r=e.length;o<r;++o){const l=e[o].element;if(l&&l.hasValue()){const c=l.getCenterPoint(),d=_s(t,c);d<s&&(s=d,a=l)}}if(a){const l=a.tooltipPosition();n=l.x,i=l.y}return{x:n,y:i}}};function Ft(e,t){return t&&(ct(t)?Array.prototype.push.apply(e,t):e.push(t)),e}function Xt(e){return(typeof e=="string"||e instanceof String)&&e.indexOf(`
`)>-1?e.split(`
`):e}function tm(e,t){const{element:n,datasetIndex:i,index:s}=t,o=e.getDatasetMeta(i).controller,{label:r,value:a}=o.getLabelAndValue(s);return{chart:e,label:r,parsed:o.getParsed(s),raw:e.data.datasets[i].data[s],formattedValue:a,dataset:o.getDataset(),dataIndex:s,datasetIndex:i,element:n}}function $r(e,t){const n=e.chart.ctx,{body:i,footer:s,title:o}=e,{boxWidth:r,boxHeight:a}=t,l=xt(t.bodyFont),c=xt(t.titleFont),d=xt(t.footerFont),h=o.length,f=s.length,g=i.length,m=Rt(t.padding);let v=m.height,y=0,_=i.reduce((M,k)=>M+k.before.length+k.lines.length+k.after.length,0);if(_+=e.beforeBody.length+e.afterBody.length,h&&(v+=h*c.lineHeight+(h-1)*t.titleSpacing+t.titleMarginBottom),_){const M=t.displayColors?Math.max(a,l.lineHeight):l.lineHeight;v+=g*M+(_-g)*l.lineHeight+(_-1)*t.bodySpacing}f&&(v+=t.footerMarginTop+f*d.lineHeight+(f-1)*t.footerSpacing);let E=0;const O=function(M){y=Math.max(y,n.measureText(M).width+E)};return n.save(),n.font=c.string,U(e.title,O),n.font=l.string,U(e.beforeBody.concat(e.afterBody),O),E=t.displayColors?r+2+t.boxPadding:0,U(i,M=>{U(M.before,O),U(M.lines,O),U(M.after,O)}),E=0,n.font=d.string,U(e.footer,O),n.restore(),y+=m.width,{width:y,height:v}}function em(e,t){const{y:n,height:i}=t;return n<i/2?"top":n>e.height-i/2?"bottom":"center"}function nm(e,t,n,i){const{x:s,width:o}=i,r=n.caretSize+n.caretPadding;if(e==="left"&&s+o+r>t.width||e==="right"&&s-o-r<0)return!0}function im(e,t,n,i){const{x:s,width:o}=n,{width:r,chartArea:{left:a,right:l}}=e;let c="center";return i==="center"?c=s<=(a+l)/2?"left":"right":s<=o/2?c="left":s>=r-o/2&&(c="right"),nm(c,e,t,n)&&(c="center"),c}function Fr(e,t,n){const i=n.yAlign||t.yAlign||em(e,n);return{xAlign:n.xAlign||t.xAlign||im(e,t,n,i),yAlign:i}}function sm(e,t){let{x:n,width:i}=e;return t==="right"?n-=i:t==="center"&&(n-=i/2),n}function om(e,t,n){let{y:i,height:s}=e;return t==="top"?i+=n:t==="bottom"?i-=s+n:i-=s/2,i}function Br(e,t,n,i){const{caretSize:s,caretPadding:o,cornerRadius:r}=e,{xAlign:a,yAlign:l}=n,c=s+o,{topLeft:d,topRight:h,bottomLeft:f,bottomRight:g}=mn(r);let m=sm(t,a);const v=om(t,l,c);return l==="center"?a==="left"?m+=c:a==="right"&&(m-=c):a==="left"?m-=Math.max(d,f)+s:a==="right"&&(m+=Math.max(h,g)+s),{x:Dt(m,0,i.width-t.width),y:Dt(v,0,i.height-t.height)}}function ai(e,t,n){const i=Rt(n.padding);return t==="center"?e.x+e.width/2:t==="right"?e.x+e.width-i.right:e.x+i.left}function Hr(e){return Ft([],Xt(e))}function rm(e,t,n){return Ae(e,{tooltip:t,tooltipItems:n,type:"tooltip"})}function Ur(e,t){const n=t&&t.dataset&&t.dataset.tooltip&&t.dataset.tooltip.callbacks;return n?e.override(n):e}const Pl={beforeTitle:Kt,title(e){if(e.length>0){const t=e[0],n=t.chart.data.labels,i=n?n.length:0;if(this&&this.options&&this.options.mode==="dataset")return t.dataset.label||"";if(t.label)return t.label;if(i>0&&t.dataIndex<i)return n[t.dataIndex]}return""},afterTitle:Kt,beforeBody:Kt,beforeLabel:Kt,label(e){if(this&&this.options&&this.options.mode==="dataset")return e.label+": "+e.formattedValue||e.formattedValue;let t=e.dataset.label||"";t&&(t+=": ");const n=e.formattedValue;return G(n)||(t+=n),t},labelColor(e){const n=e.chart.getDatasetMeta(e.datasetIndex).controller.getStyle(e.dataIndex);return{borderColor:n.borderColor,backgroundColor:n.backgroundColor,borderWidth:n.borderWidth,borderDash:n.borderDash,borderDashOffset:n.borderDashOffset,borderRadius:0}},labelTextColor(){return this.options.bodyColor},labelPointStyle(e){const n=e.chart.getDatasetMeta(e.datasetIndex).controller.getStyle(e.dataIndex);return{pointStyle:n.pointStyle,rotation:n.rotation}},afterLabel:Kt,afterBody:Kt,beforeFooter:Kt,footer:Kt,afterFooter:Kt};function bt(e,t,n,i){const s=e[t].call(n,i);return typeof s>"u"?Pl[t].call(n,i):s}class Ms extends de{constructor(t){super(),this.opacity=0,this._active=[],this._eventPosition=void 0,this._size=void 0,this._cachedAnimations=void 0,this._tooltipItems=[],this.$animations=void 0,this.$context=void 0,this.chart=t.chart,this.options=t.options,this.dataPoints=void 0,this.title=void 0,this.beforeBody=void 0,this.body=void 0,this.afterBody=void 0,this.footer=void 0,this.xAlign=void 0,this.yAlign=void 0,this.x=void 0,this.y=void 0,this.height=void 0,this.width=void 0,this.caretX=void 0,this.caretY=void 0,this.labelColors=void 0,this.labelPointStyles=void 0,this.labelTextColors=void 0}initialize(t){this.options=t,this._cachedAnimations=void 0,this.$context=void 0}_resolveAnimations(){const t=this._cachedAnimations;if(t)return t;const n=this.chart,i=this.options.setContext(this.getContext()),s=i.enabled&&n.options.animation&&i.animations,o=new pl(this.chart,s);return s._cacheable&&(this._cachedAnimations=Object.freeze(o)),o}getContext(){return this.$context||(this.$context=rm(this.chart.getContext(),this,this._tooltipItems))}getTitle(t,n){const{callbacks:i}=n,s=bt(i,"beforeTitle",this,t),o=bt(i,"title",this,t),r=bt(i,"afterTitle",this,t);let a=[];return a=Ft(a,Xt(s)),a=Ft(a,Xt(o)),a=Ft(a,Xt(r)),a}getBeforeBody(t,n){return Hr(bt(n.callbacks,"beforeBody",this,t))}getBody(t,n){const{callbacks:i}=n,s=[];return U(t,o=>{const r={before:[],lines:[],after:[]},a=Ur(i,o);Ft(r.before,Xt(bt(a,"beforeLabel",this,o))),Ft(r.lines,bt(a,"label",this,o)),Ft(r.after,Xt(bt(a,"afterLabel",this,o))),s.push(r)}),s}getAfterBody(t,n){return Hr(bt(n.callbacks,"afterBody",this,t))}getFooter(t,n){const{callbacks:i}=n,s=bt(i,"beforeFooter",this,t),o=bt(i,"footer",this,t),r=bt(i,"afterFooter",this,t);let a=[];return a=Ft(a,Xt(s)),a=Ft(a,Xt(o)),a=Ft(a,Xt(r)),a}_createItems(t){const n=this._active,i=this.chart.data,s=[],o=[],r=[];let a=[],l,c;for(l=0,c=n.length;l<c;++l)a.push(tm(this.chart,n[l]));return t.filter&&(a=a.filter((d,h,f)=>t.filter(d,h,f,i))),t.itemSort&&(a=a.sort((d,h)=>t.itemSort(d,h,i))),U(a,d=>{const h=Ur(t.callbacks,d);s.push(bt(h,"labelColor",this,d)),o.push(bt(h,"labelPointStyle",this,d)),r.push(bt(h,"labelTextColor",this,d))}),this.labelColors=s,this.labelPointStyles=o,this.labelTextColors=r,this.dataPoints=a,a}update(t,n){const i=this.options.setContext(this.getContext()),s=this._active;let o,r=[];if(!s.length)this.opacity!==0&&(o={opacity:0});else{const a=un[i.position].call(this,s,this._eventPosition);r=this._createItems(i),this.title=this.getTitle(r,i),this.beforeBody=this.getBeforeBody(r,i),this.body=this.getBody(r,i),this.afterBody=this.getAfterBody(r,i),this.footer=this.getFooter(r,i);const l=this._size=$r(this,i),c=Object.assign({},a,l),d=Fr(this.chart,i,c),h=Br(i,c,d,this.chart);this.xAlign=d.xAlign,this.yAlign=d.yAlign,o={opacity:1,x:h.x,y:h.y,width:l.width,height:l.height,caretX:a.x,caretY:a.y}}this._tooltipItems=r,this.$context=void 0,o&&this._resolveAnimations().update(this,o),t&&i.external&&i.external.call(this,{chart:this.chart,tooltip:this,replay:n})}drawCaret(t,n,i,s){const o=this.getCaretPosition(t,i,s);n.lineTo(o.x1,o.y1),n.lineTo(o.x2,o.y2),n.lineTo(o.x3,o.y3)}getCaretPosition(t,n,i){const{xAlign:s,yAlign:o}=this,{caretSize:r,cornerRadius:a}=i,{topLeft:l,topRight:c,bottomLeft:d,bottomRight:h}=mn(a),{x:f,y:g}=t,{width:m,height:v}=n;let y,_,E,O,M,k;return o==="center"?(M=g+v/2,s==="left"?(y=f,_=y-r,O=M+r,k=M-r):(y=f+m,_=y+r,O=M-r,k=M+r),E=y):(s==="left"?_=f+Math.max(l,d)+r:s==="right"?_=f+m-Math.max(c,h)-r:_=this.caretX,o==="top"?(O=g,M=O-r,y=_-r,E=_+r):(O=g+v,M=O+r,y=_+r,E=_-r),k=O),{x1:y,x2:_,x3:E,y1:O,y2:M,y3:k}}drawTitle(t,n,i){const s=this.title,o=s.length;let r,a,l;if(o){const c=Be(i.rtl,this.x,this.width);for(t.x=ai(this,i.titleAlign,i),n.textAlign=c.textAlign(i.titleAlign),n.textBaseline="middle",r=xt(i.titleFont),a=i.titleSpacing,n.fillStyle=i.titleColor,n.font=r.string,l=0;l<o;++l)n.fillText(s[l],c.x(t.x),t.y+r.lineHeight/2),t.y+=r.lineHeight+a,l+1===o&&(t.y+=i.titleMarginBottom-a)}}_drawColorBox(t,n,i,s,o){const r=this.labelColors[i],a=this.labelPointStyles[i],{boxHeight:l,boxWidth:c}=o,d=xt(o.bodyFont),h=ai(this,"left",o),f=s.x(h),g=l<d.lineHeight?(d.lineHeight-l)/2:0,m=n.y+g;if(o.usePointStyle){const v={radius:Math.min(c,l)/2,pointStyle:a.pointStyle,rotation:a.rotation,borderWidth:1},y=s.leftForLtr(f,c)+c/2,_=m+l/2;t.strokeStyle=o.multiKeyBackground,t.fillStyle=o.multiKeyBackground,ks(t,v,y,_),t.strokeStyle=r.borderColor,t.fillStyle=r.backgroundColor,ks(t,v,y,_)}else{t.lineWidth=W(r.borderWidth)?Math.max(...Object.values(r.borderWidth)):r.borderWidth||1,t.strokeStyle=r.borderColor,t.setLineDash(r.borderDash||[]),t.lineDashOffset=r.borderDashOffset||0;const v=s.leftForLtr(f,c),y=s.leftForLtr(s.xPlus(f,1),c-2),_=mn(r.borderRadius);Object.values(_).some(E=>E!==0)?(t.beginPath(),t.fillStyle=o.multiKeyBackground,Ss(t,{x:v,y:m,w:c,h:l,radius:_}),t.fill(),t.stroke(),t.fillStyle=r.backgroundColor,t.beginPath(),Ss(t,{x:y,y:m+1,w:c-2,h:l-2,radius:_}),t.fill()):(t.fillStyle=o.multiKeyBackground,t.fillRect(v,m,c,l),t.strokeRect(v,m,c,l),t.fillStyle=r.backgroundColor,t.fillRect(y,m+1,c-2,l-2))}t.fillStyle=this.labelTextColors[i]}drawBody(t,n,i){const{body:s}=this,{bodySpacing:o,bodyAlign:r,displayColors:a,boxHeight:l,boxWidth:c,boxPadding:d}=i,h=xt(i.bodyFont);let f=h.lineHeight,g=0;const m=Be(i.rtl,this.x,this.width),v=function(P){n.fillText(P,m.x(t.x+g),t.y+f/2),t.y+=f+o},y=m.textAlign(r);let _,E,O,M,k,C,A;for(n.textAlign=r,n.textBaseline="middle",n.font=h.string,t.x=ai(this,y,i),n.fillStyle=i.bodyColor,U(this.beforeBody,v),g=a&&y!=="right"?r==="center"?c/2+d:c+2+d:0,M=0,C=s.length;M<C;++M){for(_=s[M],E=this.labelTextColors[M],n.fillStyle=E,U(_.before,v),O=_.lines,a&&O.length&&(this._drawColorBox(n,t,M,m,i),f=Math.max(h.lineHeight,l)),k=0,A=O.length;k<A;++k)v(O[k]),f=h.lineHeight;U(_.after,v)}g=0,f=h.lineHeight,U(this.afterBody,v),t.y-=o}drawFooter(t,n,i){const s=this.footer,o=s.length;let r,a;if(o){const l=Be(i.rtl,this.x,this.width);for(t.x=ai(this,i.footerAlign,i),t.y+=i.footerMarginTop,n.textAlign=l.textAlign(i.footerAlign),n.textBaseline="middle",r=xt(i.footerFont),n.fillStyle=i.footerColor,n.font=r.string,a=0;a<o;++a)n.fillText(s[a],l.x(t.x),t.y+r.lineHeight/2),t.y+=r.lineHeight+i.footerSpacing}}drawBackground(t,n,i,s){const{xAlign:o,yAlign:r}=this,{x:a,y:l}=t,{width:c,height:d}=i,{topLeft:h,topRight:f,bottomLeft:g,bottomRight:m}=mn(s.cornerRadius);n.fillStyle=s.backgroundColor,n.strokeStyle=s.borderColor,n.lineWidth=s.borderWidth,n.beginPath(),n.moveTo(a+h,l),r==="top"&&this.drawCaret(t,n,i,s),n.lineTo(a+c-f,l),n.quadraticCurveTo(a+c,l,a+c,l+f),r==="center"&&o==="right"&&this.drawCaret(t,n,i,s),n.lineTo(a+c,l+d-m),n.quadraticCurveTo(a+c,l+d,a+c-m,l+d),r==="bottom"&&this.drawCaret(t,n,i,s),n.lineTo(a+g,l+d),n.quadraticCurveTo(a,l+d,a,l+d-g),r==="center"&&o==="left"&&this.drawCaret(t,n,i,s),n.lineTo(a,l+h),n.quadraticCurveTo(a,l,a+h,l),n.closePath(),n.fill(),s.borderWidth>0&&n.stroke()}_updateAnimationTarget(t){const n=this.chart,i=this.$animations,s=i&&i.x,o=i&&i.y;if(s||o){const r=un[t.position].call(this,this._active,this._eventPosition);if(!r)return;const a=this._size=$r(this,t),l=Object.assign({},r,this._size),c=Fr(n,t,l),d=Br(t,l,c,n);(s._to!==d.x||o._to!==d.y)&&(this.xAlign=c.xAlign,this.yAlign=c.yAlign,this.width=a.width,this.height=a.height,this.caretX=r.x,this.caretY=r.y,this._resolveAnimations().update(this,d))}}_willRender(){return!!this.opacity}draw(t){const n=this.options.setContext(this.getContext());let i=this.opacity;if(!i)return;this._updateAnimationTarget(n);const s={width:this.width,height:this.height},o={x:this.x,y:this.y};i=Math.abs(i)<.001?0:i;const r=Rt(n.padding),a=this.title.length||this.beforeBody.length||this.body.length||this.afterBody.length||this.footer.length;n.enabled&&a&&(t.save(),t.globalAlpha=i,this.drawBackground(o,t,s,n),ll(t,n.textDirection),o.y+=r.top,this.drawTitle(o,t,n),this.drawBody(o,t,n),this.drawFooter(o,t,n),cl(t,n.textDirection),t.restore())}getActiveElements(){return this._active||[]}setActiveElements(t,n){const i=this._active,s=t.map(({datasetIndex:a,index:l})=>{const c=this.chart.getDatasetMeta(a);if(!c)throw new Error("Cannot find a dataset at index "+a);return{datasetIndex:a,element:c.data[l],index:l}}),o=!vi(i,s),r=this._positionChanged(s,n);(o||r)&&(this._active=s,this._eventPosition=n,this._ignoreReplayEvents=!0,this.update(!0))}handleEvent(t,n,i=!0){if(n&&this._ignoreReplayEvents)return!1;this._ignoreReplayEvents=!1;const s=this.options,o=this._active||[],r=this._getActiveElements(t,o,n,i),a=this._positionChanged(r,t),l=n||!vi(r,o)||a;return l&&(this._active=r,(s.enabled||s.external)&&(this._eventPosition={x:t.x,y:t.y},this.update(!0,n))),l}_getActiveElements(t,n,i,s){const o=this.options;if(t.type==="mouseout")return[];if(!s)return n.filter(a=>this.chart.data.datasets[a.datasetIndex]&&this.chart.getDatasetMeta(a.datasetIndex).controller.getParsed(a.index)!==void 0);const r=this.chart.getElementsAtEventForMode(t,o.mode,o,i);return o.reverse&&r.reverse(),r}_positionChanged(t,n){const{caretX:i,caretY:s,options:o}=this,r=un[o.position].call(this,t,n);return r!==!1&&(i!==r.x||s!==r.y)}}F(Ms,"positioners",un);var am={id:"tooltip",_element:Ms,positioners:un,afterInit(e,t,n){n&&(e.tooltip=new Ms({chart:e,options:n}))},beforeUpdate(e,t,n){e.tooltip&&e.tooltip.initialize(n)},reset(e,t,n){e.tooltip&&e.tooltip.initialize(n)},afterDraw(e){const t=e.tooltip;if(t&&t._willRender()){const n={tooltip:t};if(e.notifyPlugins("beforeTooltipDraw",{...n,cancelable:!0})===!1)return;t.draw(e.ctx),e.notifyPlugins("afterTooltipDraw",n)}},afterEvent(e,t){if(e.tooltip){const n=t.replay;e.tooltip.handleEvent(t.event,n,t.inChartArea)&&(t.changed=!0)}},defaults:{enabled:!0,external:null,position:"average",backgroundColor:"rgba(0,0,0,0.8)",titleColor:"#fff",titleFont:{weight:"bold"},titleSpacing:2,titleMarginBottom:6,titleAlign:"left",bodyColor:"#fff",bodySpacing:2,bodyFont:{},bodyAlign:"left",footerColor:"#fff",footerSpacing:2,footerMarginTop:6,footerFont:{weight:"bold"},footerAlign:"left",padding:6,caretPadding:2,caretSize:5,cornerRadius:6,boxHeight:(e,t)=>t.bodyFont.size,boxWidth:(e,t)=>t.bodyFont.size,multiKeyBackground:"#fff",displayColors:!0,boxPadding:0,borderColor:"rgba(0,0,0,0)",borderWidth:0,animation:{duration:400,easing:"easeOutQuart"},animations:{numbers:{type:"number",properties:["x","y","width","height","caretX","caretY"]},opacity:{easing:"linear",duration:200}},callbacks:Pl},defaultRoutes:{bodyFont:"font",footerFont:"font",titleFont:"font"},descriptors:{_scriptable:e=>e!=="filter"&&e!=="itemSort"&&e!=="external",_indexable:!1,callbacks:{_scriptable:!1,_indexable:!1},animation:{_fallback:!1},animations:{_fallback:"animation"}},additionalOptionScopes:["interaction"]};function lm(e,t){const n=[],{bounds:s,step:o,min:r,max:a,precision:l,count:c,maxTicks:d,maxDigits:h,includeBounds:f}=e,g=o||1,m=d-1,{min:v,max:y}=t,_=!G(r),E=!G(a),O=!G(c),M=(y-v)/(h+1);let k=Wo((y-v)/m/g)*g,C,A,P,I;if(k<1e-14&&!_&&!E)return[{value:v},{value:y}];I=Math.ceil(y/k)-Math.floor(v/k),I>m&&(k=Wo(I*k/m/g)*g),G(l)||(C=Math.pow(10,l),k=Math.ceil(k*C)/C),s==="ticks"?(A=Math.floor(v/k)*k,P=Math.ceil(y/k)*k):(A=v,P=y),_&&E&&o&&Ru((a-r)/o,k/1e3)?(I=Math.round(Math.min((a-r)/k,d)),k=(a-r)/I,A=r,P=a):O?(A=_?r:A,P=E?a:P,I=c-1,k=(P-A)/I):(I=(P-A)/k,ke(I,Math.round(I),k/1e3)?I=Math.round(I):I=Math.ceil(I));const z=Math.max(jo(k),jo(A));C=Math.pow(10,G(l)?z:l),A=Math.round(A*C)/C,P=Math.round(P*C)/C;let R=0;for(_&&(f&&A!==r?(n.push({value:r}),A<r&&R++,ke(Math.round((A+R*k)*C)/C,r,Wr(r,M,e))&&R++):A<r&&R++);R<I;++R){const $=Math.round((A+R*k)*C)/C;if(E&&$>a)break;n.push({value:$})}return E&&f&&P!==a?n.length&&ke(n[n.length-1].value,a,Wr(a,M,e))?n[n.length-1].value=a:n.push({value:a}):(!E||P===a)&&n.push({value:P}),n}function Wr(e,t,{horizontal:n,minRotation:i}){const s=_e(i),o=(n?Math.sin(s):Math.cos(s))||.001,r=.75*t*(""+e).length;return Math.min(t/o,r)}class cm extends Ln{constructor(t){super(t),this.start=void 0,this.end=void 0,this._startValue=void 0,this._endValue=void 0,this._valueRange=0}parse(t,n){return G(t)||(typeof t=="number"||t instanceof Number)&&!isFinite(+t)?null:+t}handleTickRangeOptions(){const{beginAtZero:t}=this.options,{minDefined:n,maxDefined:i}=this.getUserBounds();let{min:s,max:o}=this;const r=l=>s=n?s:l,a=l=>o=i?o:l;if(t){const l=ce(s),c=ce(o);l<0&&c<0?a(0):l>0&&c>0&&r(0)}if(s===o){let l=o===0?1:Math.abs(o*.05);a(o+l),t||r(s-l)}this.min=s,this.max=o}getTickLimit(){const t=this.options.ticks;let{maxTicksLimit:n,stepSize:i}=t,s;return i?(s=Math.ceil(this.max/i)-Math.floor(this.min/i)+1,s>1e3&&(console.warn(`scales.${this.id}.ticks.stepSize: ${i} would result generating up to ${s} ticks. Limiting to 1000.`),s=1e3)):(s=this.computeTickLimit(),n=n||11),n&&(s=Math.min(n,s)),s}computeTickLimit(){return Number.POSITIVE_INFINITY}buildTicks(){const t=this.options,n=t.ticks;let i=this.getTickLimit();i=Math.max(2,i);const s={maxTicks:i,bounds:t.bounds,min:t.min,max:t.max,precision:n.precision,step:n.stepSize,count:n.count,maxDigits:this._maxDigits(),horizontal:this.isHorizontal(),minRotation:n.minRotation||0,includeBounds:n.includeBounds!==!1},o=this._range||this,r=lm(s,o);return t.bounds==="ticks"&&Nu(r,this,"value"),t.reverse?(r.reverse(),this.start=this.max,this.end=this.min):(this.start=this.min,this.end=this.max),r}configure(){const t=this.ticks;let n=this.min,i=this.max;if(super.configure(),this.options.offset&&t.length){const s=(i-n)/Math.max(t.length-1,1)/2;n-=s,i+=s}this._startValue=n,this._endValue=i,this._valueRange=i-n}getLabelForValue(t){return Qa(t,this.chart.options.locale,this.options.ticks.format)}}class Ps extends cm{determineDataLimits(){const{min:t,max:n}=this.getMinMax(!0);this.min=ft(t)?t:0,this.max=ft(n)?n:1,this.handleTickRangeOptions()}computeTickLimit(){const t=this.isHorizontal(),n=t?this.width:this.height,i=_e(this.options.ticks.minRotation),s=(t?Math.sin(i):Math.cos(i))||.001,o=this._resolveTickFontOptions(0);return Math.ceil(n/Math.min(40,o.lineHeight/s))}getPixelForValue(t){return t===null?NaN:this.getPixelForDecimal((t-this._startValue)/this._valueRange)}getValueForPixel(t){return this._startValue+this.getDecimalForPixel(t)*this._valueRange}}F(Ps,"id","linear"),F(Ps,"defaults",{ticks:{callback:tl.formatters.numeric}});const Bi={millisecond:{common:!0,size:1,steps:1e3},second:{common:!0,size:1e3,steps:60},minute:{common:!0,size:6e4,steps:60},hour:{common:!0,size:36e5,steps:24},day:{common:!0,size:864e5,steps:30},week:{common:!1,size:6048e5,steps:4},month:{common:!0,size:2628e6,steps:12},quarter:{common:!1,size:7884e6,steps:4},year:{common:!0,size:3154e7}},yt=Object.keys(Bi);function jr(e,t){return e-t}function Vr(e,t){if(G(t))return null;const n=e._adapter,{parser:i,round:s,isoWeekday:o}=e._parseOpts;let r=t;return typeof i=="function"&&(r=i(r)),ft(r)||(r=typeof i=="string"?n.parse(r,i):n.parse(r)),r===null?null:(s&&(r=s==="week"&&(Cn(o)||o===!0)?n.startOf(r,"isoWeek",o):n.startOf(r,s)),+r)}function Yr(e,t,n,i){const s=yt.length;for(let o=yt.indexOf(e);o<s-1;++o){const r=Bi[yt[o]],a=r.steps?r.steps:Number.MAX_SAFE_INTEGER;if(r.common&&Math.ceil((n-t)/(a*r.size))<=i)return yt[o]}return yt[s-1]}function dm(e,t,n,i,s){for(let o=yt.length-1;o>=yt.indexOf(n);o--){const r=yt[o];if(Bi[r].common&&e._adapter.diff(s,i,r)>=t-1)return r}return yt[n?yt.indexOf(n):0]}function hm(e){for(let t=yt.indexOf(e)+1,n=yt.length;t<n;++t)if(Bi[yt[t]].common)return yt[t]}function Gr(e,t,n){if(!n)e[t]=!0;else if(n.length){const{lo:i,hi:s}=Zs(n,t),o=n[i]>=t?n[i]:n[s];e[o]=!0}}function um(e,t,n,i){const s=e._adapter,o=+s.startOf(t[0].value,i),r=t[t.length-1].value;let a,l;for(a=o;a<=r;a=+s.add(a,1,i))l=n[a],l>=0&&(t[l].major=!0);return t}function Kr(e,t,n){const i=[],s={},o=t.length;let r,a;for(r=0;r<o;++r)a=t[r],s[a]=r,i.push({value:a,major:!1});return o===0||!n?i:um(e,i,s,n)}class Mn extends Ln{constructor(t){super(t),this._cache={data:[],labels:[],all:[]},this._unit="day",this._majorUnit=void 0,this._offsets={},this._normalized=!1,this._parseOpts=void 0}init(t,n={}){const i=t.time||(t.time={}),s=this._adapter=new dp._date(t.adapters.date);s.init(n),fn(i.displayFormats,s.formats()),this._parseOpts={parser:i.parser,round:i.round,isoWeekday:i.isoWeekday},super.init(t),this._normalized=n.normalized}parse(t,n){return t===void 0?null:Vr(this,t)}beforeLayout(){super.beforeLayout(),this._cache={data:[],labels:[],all:[]}}determineDataLimits(){const t=this.options,n=this._adapter,i=t.time.unit||"day";let{min:s,max:o,minDefined:r,maxDefined:a}=this.getUserBounds();function l(c){!r&&!isNaN(c.min)&&(s=Math.min(s,c.min)),!a&&!isNaN(c.max)&&(o=Math.max(o,c.max))}(!r||!a)&&(l(this._getLabelBounds()),(t.bounds!=="ticks"||t.ticks.source!=="labels")&&l(this.getMinMax(!1))),s=ft(s)&&!isNaN(s)?s:+n.startOf(Date.now(),i),o=ft(o)&&!isNaN(o)?o:+n.endOf(Date.now(),i)+1,this.min=Math.min(s,o-1),this.max=Math.max(s+1,o)}_getLabelBounds(){const t=this.getLabelTimestamps();let n=Number.POSITIVE_INFINITY,i=Number.NEGATIVE_INFINITY;return t.length&&(n=t[0],i=t[t.length-1]),{min:n,max:i}}buildTicks(){const t=this.options,n=t.time,i=t.ticks,s=i.source==="labels"?this.getLabelTimestamps():this._generate();t.bounds==="ticks"&&s.length&&(this.min=this._userMin||s[0],this.max=this._userMax||s[s.length-1]);const o=this.min,r=this.max,a=Hu(s,o,r);return this._unit=n.unit||(i.autoSkip?Yr(n.minUnit,this.min,this.max,this._getLabelCapacity(o)):dm(this,a.length,n.minUnit,this.min,this.max)),this._majorUnit=!i.major.enabled||this._unit==="year"?void 0:hm(this._unit),this.initOffsets(s),t.reverse&&a.reverse(),Kr(this,a,this._majorUnit)}afterAutoSkip(){this.options.offsetAfterAutoskip&&this.initOffsets(this.ticks.map(t=>+t.value))}initOffsets(t=[]){let n=0,i=0,s,o;this.options.offset&&t.length&&(s=this.getDecimalForValue(t[0]),t.length===1?n=1-s:n=(this.getDecimalForValue(t[1])-s)/2,o=this.getDecimalForValue(t[t.length-1]),t.length===1?i=o:i=(o-this.getDecimalForValue(t[t.length-2]))/2);const r=t.length<3?.5:.25;n=Dt(n,0,r),i=Dt(i,0,r),this._offsets={start:n,end:i,factor:1/(n+1+i)}}_generate(){const t=this._adapter,n=this.min,i=this.max,s=this.options,o=s.time,r=o.unit||Yr(o.minUnit,n,i,this._getLabelCapacity(n)),a=B(s.ticks.stepSize,1),l=r==="week"?o.isoWeekday:!1,c=Cn(l)||l===!0,d={};let h=n,f,g;if(c&&(h=+t.startOf(h,"isoWeek",l)),h=+t.startOf(h,c?"day":r),t.diff(i,n,r)>1e5*a)throw new Error(n+" and "+i+" are too far apart with stepSize of "+a+" "+r);const m=s.ticks.source==="data"&&this.getDataTimestamps();for(f=h,g=0;f<i;f=+t.add(f,a,r),g++)Gr(d,f,m);return(f===i||s.bounds==="ticks"||g===1)&&Gr(d,f,m),Object.keys(d).sort(jr).map(v=>+v)}getLabelForValue(t){const n=this._adapter,i=this.options.time;return i.tooltipFormat?n.format(t,i.tooltipFormat):n.format(t,i.displayFormats.datetime)}format(t,n){const s=this.options.time.displayFormats,o=this._unit,r=n||s[o];return this._adapter.format(t,r)}_tickFormatFunction(t,n,i,s){const o=this.options,r=o.ticks.callback;if(r)return N(r,[t,n,i],this);const a=o.time.displayFormats,l=this._unit,c=this._majorUnit,d=l&&a[l],h=c&&a[c],f=i[n],g=c&&h&&f&&f.major;return this._adapter.format(t,s||(g?h:d))}generateTickLabels(t){let n,i,s;for(n=0,i=t.length;n<i;++n)s=t[n],s.label=this._tickFormatFunction(s.value,n,t)}getDecimalForValue(t){return t===null?NaN:(t-this.min)/(this.max-this.min)}getPixelForValue(t){const n=this._offsets,i=this.getDecimalForValue(t);return this.getPixelForDecimal((n.start+i)*n.factor)}getValueForPixel(t){const n=this._offsets,i=this.getDecimalForPixel(t)/n.factor-n.end;return this.min+i*(this.max-this.min)}_getLabelSize(t){const n=this.options.ticks,i=this.ctx.measureText(t).width,s=_e(this.isHorizontal()?n.maxRotation:n.minRotation),o=Math.cos(s),r=Math.sin(s),a=this._resolveTickFontOptions(0).size;return{w:i*o+a*r,h:i*r+a*o}}_getLabelCapacity(t){const n=this.options.time,i=n.displayFormats,s=i[n.unit]||i.millisecond,o=this._tickFormatFunction(t,0,Kr(this,[t],this._majorUnit),s),r=this._getLabelSize(o),a=Math.floor(this.isHorizontal()?this.width/r.w:this.height/r.h)-1;return a>0?a:1}getDataTimestamps(){let t=this._cache.data||[],n,i;if(t.length)return t;const s=this.getMatchingVisibleMetas();if(this._normalized&&s.length)return this._cache.data=s[0].controller.getAllParsedValues(this);for(n=0,i=s.length;n<i;++n)t=t.concat(s[n].controller.getAllParsedValues(this));return this._cache.data=this.normalize(t)}getLabelTimestamps(){const t=this._cache.labels||[];let n,i;if(t.length)return t;const s=this.getLabels();for(n=0,i=s.length;n<i;++n)t.push(Vr(this,s[n]));return this._cache.labels=this._normalized?t:this.normalize(t)}normalize(t){return Wu(t.sort(jr))}}F(Mn,"id","time"),F(Mn,"defaults",{bounds:"data",adapters:{},time:{parser:!1,unit:!1,round:!1,isoWeekday:!1,minUnit:"millisecond",displayFormats:{}},ticks:{source:"auto",callback:!1,major:{enabled:!1}}});function li(e,t,n){let i=0,s=e.length-1,o,r,a,l;n?(t>=e[i].pos&&t<=e[s].pos&&({lo:i,hi:s}=we(e,"pos",t)),{pos:o,time:a}=e[i],{pos:r,time:l}=e[s]):(t>=e[i].time&&t<=e[s].time&&({lo:i,hi:s}=we(e,"time",t)),{time:o,pos:a}=e[i],{time:r,pos:l}=e[s]);const c=r-o;return c?a+(l-a)*(t-o)/c:a}class qr extends Mn{constructor(t){super(t),this._table=[],this._minPos=void 0,this._tableRange=void 0}initOffsets(){const t=this._getTimestampsForTable(),n=this._table=this.buildLookupTable(t);this._minPos=li(n,this.min),this._tableRange=li(n,this.max)-this._minPos,super.initOffsets(t)}buildLookupTable(t){const{min:n,max:i}=this,s=[],o=[];let r,a,l,c,d;for(r=0,a=t.length;r<a;++r)c=t[r],c>=n&&c<=i&&s.push(c);if(s.length<2)return[{time:n,pos:0},{time:i,pos:1}];for(r=0,a=s.length;r<a;++r)d=s[r+1],l=s[r-1],c=s[r],Math.round((d+l)/2)!==c&&o.push({time:c,pos:r/(a-1)});return o}_generate(){const t=this.min,n=this.max;let i=super.getDataTimestamps();return(!i.includes(t)||!i.length)&&i.splice(0,0,t),(!i.includes(n)||i.length===1)&&i.push(n),i.sort((s,o)=>s-o)}_getTimestampsForTable(){let t=this._cache.all||[];if(t.length)return t;const n=this.getDataTimestamps(),i=this.getLabelTimestamps();return n.length&&i.length?t=this.normalize(n.concat(i)):t=n.length?n:i,t=this._cache.all=t,t}getDecimalForValue(t){return(li(this._table,t)-this._minPos)/this._tableRange}getValueForPixel(t){const n=this._offsets,i=this.getDecimalForPixel(t)/n.factor-n.end;return li(this._table,i*this._tableRange+this._minPos,!0)}}F(qr,"id","timeseries"),F(qr,"defaults",Mn.defaults);var cs={exports:{}};/*! Hammer.JS - v2.0.7 - 2016-04-22
 * http://hammerjs.github.io/
 *
 * Copyright (c) 2016 Jorik Tangelder;
 * Licensed under the MIT license */var Xr;function fm(){return Xr||(Xr=1,(function(e){(function(t,n,i,s){var o=["","webkit","Moz","MS","ms","o"],r=n.createElement("div"),a="function",l=Math.round,c=Math.abs,d=Date.now;function h(u,p,b){return setTimeout(O(u,b),p)}function f(u,p,b){return Array.isArray(u)?(g(u,b[p],b),!0):!1}function g(u,p,b){var x;if(u)if(u.forEach)u.forEach(p,b);else if(u.length!==s)for(x=0;x<u.length;)p.call(b,u[x],x,u),x++;else for(x in u)u.hasOwnProperty(x)&&p.call(b,u[x],x,u)}function m(u,p,b){var x="DEPRECATED METHOD: "+p+`
`+b+` AT 
`;return function(){var T=new Error("get-stack-trace"),D=T&&T.stack?T.stack.replace(/^[^\(]+?[\n$]/gm,"").replace(/^\s+at\s+/gm,"").replace(/^Object.<anonymous>\s*\(/gm,"{anonymous}()@"):"Unknown Stack Trace",H=t.console&&(t.console.warn||t.console.log);return H&&H.call(t.console,x,D),u.apply(this,arguments)}}var v;typeof Object.assign!="function"?v=function(p){if(p===s||p===null)throw new TypeError("Cannot convert undefined or null to object");for(var b=Object(p),x=1;x<arguments.length;x++){var T=arguments[x];if(T!==s&&T!==null)for(var D in T)T.hasOwnProperty(D)&&(b[D]=T[D])}return b}:v=Object.assign;var y=m(function(p,b,x){for(var T=Object.keys(b),D=0;D<T.length;)(!x||x&&p[T[D]]===s)&&(p[T[D]]=b[T[D]]),D++;return p},"extend","Use `assign`."),_=m(function(p,b){return y(p,b,!0)},"merge","Use `assign`.");function E(u,p,b){var x=p.prototype,T;T=u.prototype=Object.create(x),T.constructor=u,T._super=x,b&&v(T,b)}function O(u,p){return function(){return u.apply(p,arguments)}}function M(u,p){return typeof u==a?u.apply(p&&p[0]||s,p):u}function k(u,p){return u===s?p:u}function C(u,p,b){g(z(p),function(x){u.addEventListener(x,b,!1)})}function A(u,p,b){g(z(p),function(x){u.removeEventListener(x,b,!1)})}function P(u,p){for(;u;){if(u==p)return!0;u=u.parentNode}return!1}function I(u,p){return u.indexOf(p)>-1}function z(u){return u.trim().split(/\s+/g)}function R(u,p,b){if(u.indexOf&&!b)return u.indexOf(p);for(var x=0;x<u.length;){if(b&&u[x][b]==p||!b&&u[x]===p)return x;x++}return-1}function $(u){return Array.prototype.slice.call(u,0)}function Z(u,p,b){for(var x=[],T=[],D=0;D<u.length;){var H=u[D][p];R(T,H)<0&&x.push(u[D]),T[D]=H,D++}return x=x.sort(function(dt,gt){return dt[p]>gt[p]}),x}function ot(u,p){for(var b,x,T=p[0].toUpperCase()+p.slice(1),D=0;D<o.length;){if(b=o[D],x=b?b+T:p,x in u)return x;D++}return s}var V=1;function Y(){return V++}function rt(u){var p=u.ownerDocument||u;return p.defaultView||p.parentWindow||t}var j=/mobile|tablet|ip(ad|hone|od)|android/i,J="ontouchstart"in t,tt=ot(t,"PointerEvent")!==s,ht=J&&j.test(navigator.userAgent),et="touch",kt="pen",Mt="mouse",ue="kinect",Vt=25,pt=1,fe=2,nt=4,mt=8,$n=1,Xe=2,Ze=4,Je=8,Qe=16,Nt=Xe|Ze,pe=Je|Qe,ao=Nt|pe,lo=["x","y"],Fn=["clientX","clientY"];function Et(u,p){var b=this;this.manager=u,this.callback=p,this.element=u.element,this.target=u.options.inputTarget,this.domHandler=function(x){M(u.options.enable,[u])&&b.handler(x)},this.init()}Et.prototype={handler:function(){},init:function(){this.evEl&&C(this.element,this.evEl,this.domHandler),this.evTarget&&C(this.target,this.evTarget,this.domHandler),this.evWin&&C(rt(this.element),this.evWin,this.domHandler)},destroy:function(){this.evEl&&A(this.element,this.evEl,this.domHandler),this.evTarget&&A(this.target,this.evTarget,this.domHandler),this.evWin&&A(rt(this.element),this.evWin,this.domHandler)}};function Yl(u){var p,b=u.options.inputClass;return b?p=b:tt?p=Ui:ht?p=Un:J?p=Wi:p=Hn,new p(u,Gl)}function Gl(u,p,b){var x=b.pointers.length,T=b.changedPointers.length,D=p&pt&&x-T===0,H=p&(nt|mt)&&x-T===0;b.isFirst=!!D,b.isFinal=!!H,D&&(u.session={}),b.eventType=p,Kl(u,b),u.emit("hammer.input",b),u.recognize(b),u.session.prevInput=b}function Kl(u,p){var b=u.session,x=p.pointers,T=x.length;b.firstInput||(b.firstInput=co(p)),T>1&&!b.firstMultiple?b.firstMultiple=co(p):T===1&&(b.firstMultiple=!1);var D=b.firstInput,H=b.firstMultiple,lt=H?H.center:D.center,dt=p.center=ho(x);p.timeStamp=d(),p.deltaTime=p.timeStamp-D.timeStamp,p.angle=Hi(lt,dt),p.distance=Bn(lt,dt),ql(b,p),p.offsetDirection=fo(p.deltaX,p.deltaY);var gt=uo(p.deltaTime,p.deltaX,p.deltaY);p.overallVelocityX=gt.x,p.overallVelocityY=gt.y,p.overallVelocity=c(gt.x)>c(gt.y)?gt.x:gt.y,p.scale=H?Jl(H.pointers,x):1,p.rotation=H?Zl(H.pointers,x):0,p.maxPointers=b.prevInput?p.pointers.length>b.prevInput.maxPointers?p.pointers.length:b.prevInput.maxPointers:p.pointers.length,Xl(b,p);var zt=u.element;P(p.srcEvent.target,zt)&&(zt=p.srcEvent.target),p.target=zt}function ql(u,p){var b=p.center,x=u.offsetDelta||{},T=u.prevDelta||{},D=u.prevInput||{};(p.eventType===pt||D.eventType===nt)&&(T=u.prevDelta={x:D.deltaX||0,y:D.deltaY||0},x=u.offsetDelta={x:b.x,y:b.y}),p.deltaX=T.x+(b.x-x.x),p.deltaY=T.y+(b.y-x.y)}function Xl(u,p){var b=u.lastInterval||p,x=p.timeStamp-b.timeStamp,T,D,H,lt;if(p.eventType!=mt&&(x>Vt||b.velocity===s)){var dt=p.deltaX-b.deltaX,gt=p.deltaY-b.deltaY,zt=uo(x,dt,gt);D=zt.x,H=zt.y,T=c(zt.x)>c(zt.y)?zt.x:zt.y,lt=fo(dt,gt),u.lastInterval=p}else T=b.velocity,D=b.velocityX,H=b.velocityY,lt=b.direction;p.velocity=T,p.velocityX=D,p.velocityY=H,p.direction=lt}function co(u){for(var p=[],b=0;b<u.pointers.length;)p[b]={clientX:l(u.pointers[b].clientX),clientY:l(u.pointers[b].clientY)},b++;return{timeStamp:d(),pointers:p,center:ho(p),deltaX:u.deltaX,deltaY:u.deltaY}}function ho(u){var p=u.length;if(p===1)return{x:l(u[0].clientX),y:l(u[0].clientY)};for(var b=0,x=0,T=0;T<p;)b+=u[T].clientX,x+=u[T].clientY,T++;return{x:l(b/p),y:l(x/p)}}function uo(u,p,b){return{x:p/u||0,y:b/u||0}}function fo(u,p){return u===p?$n:c(u)>=c(p)?u<0?Xe:Ze:p<0?Je:Qe}function Bn(u,p,b){b||(b=lo);var x=p[b[0]]-u[b[0]],T=p[b[1]]-u[b[1]];return Math.sqrt(x*x+T*T)}function Hi(u,p,b){b||(b=lo);var x=p[b[0]]-u[b[0]],T=p[b[1]]-u[b[1]];return Math.atan2(T,x)*180/Math.PI}function Zl(u,p){return Hi(p[1],p[0],Fn)+Hi(u[1],u[0],Fn)}function Jl(u,p){return Bn(p[0],p[1],Fn)/Bn(u[0],u[1],Fn)}var Ql={mousedown:pt,mousemove:fe,mouseup:nt},tc="mousedown",ec="mousemove mouseup";function Hn(){this.evEl=tc,this.evWin=ec,this.pressed=!1,Et.apply(this,arguments)}E(Hn,Et,{handler:function(p){var b=Ql[p.type];b&pt&&p.button===0&&(this.pressed=!0),b&fe&&p.which!==1&&(b=nt),this.pressed&&(b&nt&&(this.pressed=!1),this.callback(this.manager,b,{pointers:[p],changedPointers:[p],pointerType:Mt,srcEvent:p}))}});var nc={pointerdown:pt,pointermove:fe,pointerup:nt,pointercancel:mt,pointerout:mt},ic={2:et,3:kt,4:Mt,5:ue},po="pointerdown",go="pointermove pointerup pointercancel";t.MSPointerEvent&&!t.PointerEvent&&(po="MSPointerDown",go="MSPointerMove MSPointerUp MSPointerCancel");function Ui(){this.evEl=po,this.evWin=go,Et.apply(this,arguments),this.store=this.manager.session.pointerEvents=[]}E(Ui,Et,{handler:function(p){var b=this.store,x=!1,T=p.type.toLowerCase().replace("ms",""),D=nc[T],H=ic[p.pointerType]||p.pointerType,lt=H==et,dt=R(b,p.pointerId,"pointerId");D&pt&&(p.button===0||lt)?dt<0&&(b.push(p),dt=b.length-1):D&(nt|mt)&&(x=!0),!(dt<0)&&(b[dt]=p,this.callback(this.manager,D,{pointers:b,changedPointers:[p],pointerType:H,srcEvent:p}),x&&b.splice(dt,1))}});var sc={touchstart:pt,touchmove:fe,touchend:nt,touchcancel:mt},oc="touchstart",rc="touchstart touchmove touchend touchcancel";function mo(){this.evTarget=oc,this.evWin=rc,this.started=!1,Et.apply(this,arguments)}E(mo,Et,{handler:function(p){var b=sc[p.type];if(b===pt&&(this.started=!0),!!this.started){var x=ac.call(this,p,b);b&(nt|mt)&&x[0].length-x[1].length===0&&(this.started=!1),this.callback(this.manager,b,{pointers:x[0],changedPointers:x[1],pointerType:et,srcEvent:p})}}});function ac(u,p){var b=$(u.touches),x=$(u.changedTouches);return p&(nt|mt)&&(b=Z(b.concat(x),"identifier")),[b,x]}var lc={touchstart:pt,touchmove:fe,touchend:nt,touchcancel:mt},cc="touchstart touchmove touchend touchcancel";function Un(){this.evTarget=cc,this.targetIds={},Et.apply(this,arguments)}E(Un,Et,{handler:function(p){var b=lc[p.type],x=dc.call(this,p,b);x&&this.callback(this.manager,b,{pointers:x[0],changedPointers:x[1],pointerType:et,srcEvent:p})}});function dc(u,p){var b=$(u.touches),x=this.targetIds;if(p&(pt|fe)&&b.length===1)return x[b[0].identifier]=!0,[b,b];var T,D,H=$(u.changedTouches),lt=[],dt=this.target;if(D=b.filter(function(gt){return P(gt.target,dt)}),p===pt)for(T=0;T<D.length;)x[D[T].identifier]=!0,T++;for(T=0;T<H.length;)x[H[T].identifier]&&lt.push(H[T]),p&(nt|mt)&&delete x[H[T].identifier],T++;if(lt.length)return[Z(D.concat(lt),"identifier"),lt]}var hc=2500,bo=25;function Wi(){Et.apply(this,arguments);var u=O(this.handler,this);this.touch=new Un(this.manager,u),this.mouse=new Hn(this.manager,u),this.primaryTouch=null,this.lastTouches=[]}E(Wi,Et,{handler:function(p,b,x){var T=x.pointerType==et,D=x.pointerType==Mt;if(!(D&&x.sourceCapabilities&&x.sourceCapabilities.firesTouchEvents)){if(T)uc.call(this,b,x);else if(D&&fc.call(this,x))return;this.callback(p,b,x)}},destroy:function(){this.touch.destroy(),this.mouse.destroy()}});function uc(u,p){u&pt?(this.primaryTouch=p.changedPointers[0].identifier,vo.call(this,p)):u&(nt|mt)&&vo.call(this,p)}function vo(u){var p=u.changedPointers[0];if(p.identifier===this.primaryTouch){var b={x:p.clientX,y:p.clientY};this.lastTouches.push(b);var x=this.lastTouches,T=function(){var D=x.indexOf(b);D>-1&&x.splice(D,1)};setTimeout(T,hc)}}function fc(u){for(var p=u.srcEvent.clientX,b=u.srcEvent.clientY,x=0;x<this.lastTouches.length;x++){var T=this.lastTouches[x],D=Math.abs(p-T.x),H=Math.abs(b-T.y);if(D<=bo&&H<=bo)return!0}return!1}var yo=ot(r.style,"touchAction"),xo=yo!==s,_o="compute",wo="auto",ji="manipulation",ge="none",tn="pan-x",en="pan-y",Wn=gc();function Vi(u,p){this.manager=u,this.set(p)}Vi.prototype={set:function(u){u==_o&&(u=this.compute()),xo&&this.manager.element.style&&Wn[u]&&(this.manager.element.style[yo]=u),this.actions=u.toLowerCase().trim()},update:function(){this.set(this.manager.options.touchAction)},compute:function(){var u=[];return g(this.manager.recognizers,function(p){M(p.options.enable,[p])&&(u=u.concat(p.getTouchAction()))}),pc(u.join(" "))},preventDefaults:function(u){var p=u.srcEvent,b=u.offsetDirection;if(this.manager.session.prevented){p.preventDefault();return}var x=this.actions,T=I(x,ge)&&!Wn[ge],D=I(x,en)&&!Wn[en],H=I(x,tn)&&!Wn[tn];if(T){var lt=u.pointers.length===1,dt=u.distance<2,gt=u.deltaTime<250;if(lt&&dt&&gt)return}if(!(H&&D)&&(T||D&&b&Nt||H&&b&pe))return this.preventSrc(p)},preventSrc:function(u){this.manager.session.prevented=!0,u.preventDefault()}};function pc(u){if(I(u,ge))return ge;var p=I(u,tn),b=I(u,en);return p&&b?ge:p||b?p?tn:en:I(u,ji)?ji:wo}function gc(){if(!xo)return!1;var u={},p=t.CSS&&t.CSS.supports;return["auto","manipulation","pan-y","pan-x","pan-x pan-y","none"].forEach(function(b){u[b]=p?t.CSS.supports("touch-action",b):!0}),u}var jn=1,Tt=2,Re=4,te=8,Yt=te,nn=16,Lt=32;function Gt(u){this.options=v({},this.defaults,u||{}),this.id=Y(),this.manager=null,this.options.enable=k(this.options.enable,!0),this.state=jn,this.simultaneous={},this.requireFail=[]}Gt.prototype={defaults:{},set:function(u){return v(this.options,u),this.manager&&this.manager.touchAction.update(),this},recognizeWith:function(u){if(f(u,"recognizeWith",this))return this;var p=this.simultaneous;return u=Vn(u,this),p[u.id]||(p[u.id]=u,u.recognizeWith(this)),this},dropRecognizeWith:function(u){return f(u,"dropRecognizeWith",this)?this:(u=Vn(u,this),delete this.simultaneous[u.id],this)},requireFailure:function(u){if(f(u,"requireFailure",this))return this;var p=this.requireFail;return u=Vn(u,this),R(p,u)===-1&&(p.push(u),u.requireFailure(this)),this},dropRequireFailure:function(u){if(f(u,"dropRequireFailure",this))return this;u=Vn(u,this);var p=R(this.requireFail,u);return p>-1&&this.requireFail.splice(p,1),this},hasRequireFailures:function(){return this.requireFail.length>0},canRecognizeWith:function(u){return!!this.simultaneous[u.id]},emit:function(u){var p=this,b=this.state;function x(T){p.manager.emit(T,u)}b<te&&x(p.options.event+ko(b)),x(p.options.event),u.additionalEvent&&x(u.additionalEvent),b>=te&&x(p.options.event+ko(b))},tryEmit:function(u){if(this.canEmit())return this.emit(u);this.state=Lt},canEmit:function(){for(var u=0;u<this.requireFail.length;){if(!(this.requireFail[u].state&(Lt|jn)))return!1;u++}return!0},recognize:function(u){var p=v({},u);if(!M(this.options.enable,[this,p])){this.reset(),this.state=Lt;return}this.state&(Yt|nn|Lt)&&(this.state=jn),this.state=this.process(p),this.state&(Tt|Re|te|nn)&&this.tryEmit(p)},process:function(u){},getTouchAction:function(){},reset:function(){}};function ko(u){return u&nn?"cancel":u&te?"end":u&Re?"move":u&Tt?"start":""}function So(u){return u==Qe?"down":u==Je?"up":u==Xe?"left":u==Ze?"right":""}function Vn(u,p){var b=p.manager;return b?b.get(u):u}function Pt(){Gt.apply(this,arguments)}E(Pt,Gt,{defaults:{pointers:1},attrTest:function(u){var p=this.options.pointers;return p===0||u.pointers.length===p},process:function(u){var p=this.state,b=u.eventType,x=p&(Tt|Re),T=this.attrTest(u);return x&&(b&mt||!T)?p|nn:x||T?b&nt?p|te:p&Tt?p|Re:Tt:Lt}});function Yn(){Pt.apply(this,arguments),this.pX=null,this.pY=null}E(Yn,Pt,{defaults:{event:"pan",threshold:10,pointers:1,direction:ao},getTouchAction:function(){var u=this.options.direction,p=[];return u&Nt&&p.push(en),u&pe&&p.push(tn),p},directionTest:function(u){var p=this.options,b=!0,x=u.distance,T=u.direction,D=u.deltaX,H=u.deltaY;return T&p.direction||(p.direction&Nt?(T=D===0?$n:D<0?Xe:Ze,b=D!=this.pX,x=Math.abs(u.deltaX)):(T=H===0?$n:H<0?Je:Qe,b=H!=this.pY,x=Math.abs(u.deltaY))),u.direction=T,b&&x>p.threshold&&T&p.direction},attrTest:function(u){return Pt.prototype.attrTest.call(this,u)&&(this.state&Tt||!(this.state&Tt)&&this.directionTest(u))},emit:function(u){this.pX=u.deltaX,this.pY=u.deltaY;var p=So(u.direction);p&&(u.additionalEvent=this.options.event+p),this._super.emit.call(this,u)}});function Yi(){Pt.apply(this,arguments)}E(Yi,Pt,{defaults:{event:"pinch",threshold:0,pointers:2},getTouchAction:function(){return[ge]},attrTest:function(u){return this._super.attrTest.call(this,u)&&(Math.abs(u.scale-1)>this.options.threshold||this.state&Tt)},emit:function(u){if(u.scale!==1){var p=u.scale<1?"in":"out";u.additionalEvent=this.options.event+p}this._super.emit.call(this,u)}});function Gi(){Gt.apply(this,arguments),this._timer=null,this._input=null}E(Gi,Gt,{defaults:{event:"press",pointers:1,time:251,threshold:9},getTouchAction:function(){return[wo]},process:function(u){var p=this.options,b=u.pointers.length===p.pointers,x=u.distance<p.threshold,T=u.deltaTime>p.time;if(this._input=u,!x||!b||u.eventType&(nt|mt)&&!T)this.reset();else if(u.eventType&pt)this.reset(),this._timer=h(function(){this.state=Yt,this.tryEmit()},p.time,this);else if(u.eventType&nt)return Yt;return Lt},reset:function(){clearTimeout(this._timer)},emit:function(u){this.state===Yt&&(u&&u.eventType&nt?this.manager.emit(this.options.event+"up",u):(this._input.timeStamp=d(),this.manager.emit(this.options.event,this._input)))}});function Ki(){Pt.apply(this,arguments)}E(Ki,Pt,{defaults:{event:"rotate",threshold:0,pointers:2},getTouchAction:function(){return[ge]},attrTest:function(u){return this._super.attrTest.call(this,u)&&(Math.abs(u.rotation)>this.options.threshold||this.state&Tt)}});function qi(){Pt.apply(this,arguments)}E(qi,Pt,{defaults:{event:"swipe",threshold:10,velocity:.3,direction:Nt|pe,pointers:1},getTouchAction:function(){return Yn.prototype.getTouchAction.call(this)},attrTest:function(u){var p=this.options.direction,b;return p&(Nt|pe)?b=u.overallVelocity:p&Nt?b=u.overallVelocityX:p&pe&&(b=u.overallVelocityY),this._super.attrTest.call(this,u)&&p&u.offsetDirection&&u.distance>this.options.threshold&&u.maxPointers==this.options.pointers&&c(b)>this.options.velocity&&u.eventType&nt},emit:function(u){var p=So(u.offsetDirection);p&&this.manager.emit(this.options.event+p,u),this.manager.emit(this.options.event,u)}});function Gn(){Gt.apply(this,arguments),this.pTime=!1,this.pCenter=!1,this._timer=null,this._input=null,this.count=0}E(Gn,Gt,{defaults:{event:"tap",pointers:1,taps:1,interval:300,time:250,threshold:9,posThreshold:10},getTouchAction:function(){return[ji]},process:function(u){var p=this.options,b=u.pointers.length===p.pointers,x=u.distance<p.threshold,T=u.deltaTime<p.time;if(this.reset(),u.eventType&pt&&this.count===0)return this.failTimeout();if(x&&T&&b){if(u.eventType!=nt)return this.failTimeout();var D=this.pTime?u.timeStamp-this.pTime<p.interval:!0,H=!this.pCenter||Bn(this.pCenter,u.center)<p.posThreshold;this.pTime=u.timeStamp,this.pCenter=u.center,!H||!D?this.count=1:this.count+=1,this._input=u;var lt=this.count%p.taps;if(lt===0)return this.hasRequireFailures()?(this._timer=h(function(){this.state=Yt,this.tryEmit()},p.interval,this),Tt):Yt}return Lt},failTimeout:function(){return this._timer=h(function(){this.state=Lt},this.options.interval,this),Lt},reset:function(){clearTimeout(this._timer)},emit:function(){this.state==Yt&&(this._input.tapCount=this.count,this.manager.emit(this.options.event,this._input))}});function ee(u,p){return p=p||{},p.recognizers=k(p.recognizers,ee.defaults.preset),new Xi(u,p)}ee.VERSION="2.0.7",ee.defaults={domEvents:!1,touchAction:_o,enable:!0,inputTarget:null,inputClass:null,preset:[[Ki,{enable:!1}],[Yi,{enable:!1},["rotate"]],[qi,{direction:Nt}],[Yn,{direction:Nt},["swipe"]],[Gn],[Gn,{event:"doubletap",taps:2},["tap"]],[Gi]],cssProps:{userSelect:"none",touchSelect:"none",touchCallout:"none",contentZooming:"none",userDrag:"none",tapHighlightColor:"rgba(0,0,0,0)"}};var mc=1,Eo=2;function Xi(u,p){this.options=v({},ee.defaults,p||{}),this.options.inputTarget=this.options.inputTarget||u,this.handlers={},this.session={},this.recognizers=[],this.oldCssProps={},this.element=u,this.input=Yl(this),this.touchAction=new Vi(this,this.options.touchAction),To(this,!0),g(this.options.recognizers,function(b){var x=this.add(new b[0](b[1]));b[2]&&x.recognizeWith(b[2]),b[3]&&x.requireFailure(b[3])},this)}Xi.prototype={set:function(u){return v(this.options,u),u.touchAction&&this.touchAction.update(),u.inputTarget&&(this.input.destroy(),this.input.target=u.inputTarget,this.input.init()),this},stop:function(u){this.session.stopped=u?Eo:mc},recognize:function(u){var p=this.session;if(!p.stopped){this.touchAction.preventDefaults(u);var b,x=this.recognizers,T=p.curRecognizer;(!T||T&&T.state&Yt)&&(T=p.curRecognizer=null);for(var D=0;D<x.length;)b=x[D],p.stopped!==Eo&&(!T||b==T||b.canRecognizeWith(T))?b.recognize(u):b.reset(),!T&&b.state&(Tt|Re|te)&&(T=p.curRecognizer=b),D++}},get:function(u){if(u instanceof Gt)return u;for(var p=this.recognizers,b=0;b<p.length;b++)if(p[b].options.event==u)return p[b];return null},add:function(u){if(f(u,"add",this))return this;var p=this.get(u.options.event);return p&&this.remove(p),this.recognizers.push(u),u.manager=this,this.touchAction.update(),u},remove:function(u){if(f(u,"remove",this))return this;if(u=this.get(u),u){var p=this.recognizers,b=R(p,u);b!==-1&&(p.splice(b,1),this.touchAction.update())}return this},on:function(u,p){if(u!==s&&p!==s){var b=this.handlers;return g(z(u),function(x){b[x]=b[x]||[],b[x].push(p)}),this}},off:function(u,p){if(u!==s){var b=this.handlers;return g(z(u),function(x){p?b[x]&&b[x].splice(R(b[x],p),1):delete b[x]}),this}},emit:function(u,p){this.options.domEvents&&bc(u,p);var b=this.handlers[u]&&this.handlers[u].slice();if(!(!b||!b.length)){p.type=u,p.preventDefault=function(){p.srcEvent.preventDefault()};for(var x=0;x<b.length;)b[x](p),x++}},destroy:function(){this.element&&To(this,!1),this.handlers={},this.session={},this.input.destroy(),this.element=null}};function To(u,p){var b=u.element;if(b.style){var x;g(u.options.cssProps,function(T,D){x=ot(b.style,D),p?(u.oldCssProps[x]=b.style[x],b.style[x]=T):b.style[x]=u.oldCssProps[x]||""}),p||(u.oldCssProps={})}}function bc(u,p){var b=n.createEvent("Event");b.initEvent(u,!0,!0),b.gesture=p,p.target.dispatchEvent(b)}v(ee,{INPUT_START:pt,INPUT_MOVE:fe,INPUT_END:nt,INPUT_CANCEL:mt,STATE_POSSIBLE:jn,STATE_BEGAN:Tt,STATE_CHANGED:Re,STATE_ENDED:te,STATE_RECOGNIZED:Yt,STATE_CANCELLED:nn,STATE_FAILED:Lt,DIRECTION_NONE:$n,DIRECTION_LEFT:Xe,DIRECTION_RIGHT:Ze,DIRECTION_UP:Je,DIRECTION_DOWN:Qe,DIRECTION_HORIZONTAL:Nt,DIRECTION_VERTICAL:pe,DIRECTION_ALL:ao,Manager:Xi,Input:Et,TouchAction:Vi,TouchInput:Un,MouseInput:Hn,PointerEventInput:Ui,TouchMouseInput:Wi,SingleTouchInput:mo,Recognizer:Gt,AttrRecognizer:Pt,Tap:Gn,Pan:Yn,Swipe:qi,Pinch:Yi,Rotate:Ki,Press:Gi,on:C,off:A,each:g,merge:_,extend:y,assign:v,inherit:E,bindFn:O,prefixed:ot});var vc=typeof t<"u"?t:typeof self<"u"?self:{};vc.Hammer=ee,e.exports?e.exports=ee:t[i]=ee})(window,document,"Hammer")})(cs)),cs.exports}var pm=fm();const vn=Cc(pm);/*!
* chartjs-plugin-zoom v2.2.0
* https://www.chartjs.org/chartjs-plugin-zoom/2.2.0/
 * (c) 2016-2024 chartjs-plugin-zoom Contributors
 * Released under the MIT License
 */const Pn=e=>e&&e.enabled&&e.modifierKey,Al=(e,t)=>e&&t[e+"Key"],oo=(e,t)=>e&&!t[e+"Key"];function he(e,t,n){return e===void 0?!0:typeof e=="string"?e.indexOf(t)!==-1:typeof e=="function"?e({chart:n}).indexOf(t)!==-1:!1}function ds(e,t){return typeof e=="function"&&(e=e({chart:t})),typeof e=="string"?{x:e.indexOf("x")!==-1,y:e.indexOf("y")!==-1}:{x:!1,y:!1}}function gm(e,t){let n;return function(){return clearTimeout(n),n=setTimeout(e,t),t}}function mm({x:e,y:t},n){const i=n.scales,s=Object.keys(i);for(let o=0;o<s.length;o++){const r=i[s[o]];if(t>=r.top&&t<=r.bottom&&e>=r.left&&e<=r.right)return r}return null}function Dl(e,t,n){const{mode:i="xy",scaleMode:s,overScaleMode:o}=e||{},r=mm(t,n),a=ds(i,n),l=ds(s,n);if(o){const d=ds(o,n);for(const h of["x","y"])d[h]&&(l[h]=a[h],a[h]=!1)}if(r&&l[r.axis])return[r];const c=[];return U(n.scales,function(d){a[d.axis]&&c.push(d)}),c}const As=new WeakMap;function q(e){let t=As.get(e);return t||(t={originalScaleLimits:{},updatedScaleLimits:{},handlers:{},panDelta:{},dragging:!1,panning:!1},As.set(e,t)),t}function bm(e){As.delete(e)}function Il(e,t,n,i){const s=Math.max(0,Math.min(1,(e-t)/n||0)),o=1-s;return{min:i*s,max:i*o}}function Rl(e,t){const n=e.isHorizontal()?t.x:t.y;return e.getValueForPixel(n)}function Nl(e,t,n){const i=e.max-e.min,s=i*(t-1),o=Rl(e,n);return Il(o,e.min,i,s)}function vm(e,t,n){const i=Rl(e,n);if(i===void 0)return{min:e.min,max:e.max};const s=Math.log10(e.min),o=Math.log10(e.max),r=Math.log10(i),a=o-s,l=a*(t-1),c=Il(r,s,a,l);return{min:Math.pow(10,s+c.min),max:Math.pow(10,o-c.max)}}function ym(e,t){return t&&(t[e.id]||t[e.axis])||{}}function Zr(e,t,n,i,s){let o=n[i];if(o==="original"){const r=e.originalScaleLimits[t.id][i];o=B(r.options,r.scale)}return B(o,s)}function xm(e,t,n){const i=e.getValueForPixel(t),s=e.getValueForPixel(n);return{min:Math.min(i,s),max:Math.max(i,s)}}function _m(e,{min:t,max:n,minLimit:i,maxLimit:s},o){const r=(e-n+t)/2;t-=r,n+=r;const a=o.min.options??o.min.scale,l=o.max.options??o.max.scale,c=e/1e6;return ke(t,a,c)&&(t=a),ke(n,l,c)&&(n=l),t<i?(t=i,n=Math.min(i+e,s)):n>s&&(n=s,t=Math.max(s-e,i)),{min:t,max:n}}function De(e,{min:t,max:n},i,s=!1){const o=q(e.chart),{options:r}=e,a=ym(e,i),{minRange:l=0}=a,c=Zr(o,e,a,"min",-1/0),d=Zr(o,e,a,"max",1/0);if(s==="pan"&&(t<c||n>d))return!0;const h=e.max-e.min,f=s?Math.max(n-t,l):h;if(s&&f===l&&h<=l)return!0;const g=_m(f,{min:t,max:n,minLimit:c,maxLimit:d},o.originalScaleLimits[e.id]);return r.min=g.min,r.max=g.max,o.updatedScaleLimits[e.id]=g,e.parse(g.min)!==e.min||e.parse(g.max)!==e.max}function wm(e,t,n,i){const s=Nl(e,t,n),o={min:e.min+s.min,max:e.max-s.max};return De(e,o,i,!0)}function km(e,t,n,i){const s=vm(e,t,n);return De(e,s,i,!0)}function Sm(e,t,n,i){De(e,xm(e,t,n),i,!0)}const Jr=e=>e===0||isNaN(e)?0:e<0?Math.min(Math.round(e),-1):Math.max(Math.round(e),1);function Em(e){const n=e.getLabels().length-1;e.min>0&&(e.min-=1),e.max<n&&(e.max+=1)}function Tm(e,t,n,i){const s=Nl(e,t,n);e.min===e.max&&t<1&&Em(e);const o={min:e.min+Jr(s.min),max:e.max-Jr(s.max)};return De(e,o,i,!0)}function Cm(e){return e.isHorizontal()?e.width:e.height}function Om(e,t,n){const s=e.getLabels().length-1;let{min:o,max:r}=e;const a=Math.max(r-o,1),l=Math.round(Cm(e)/Math.max(a,10)),c=Math.round(Math.abs(t/l));let d;return t<-l?(r=Math.min(r+c,s),o=a===1?r:r-a,d=r===s):t>l&&(o=Math.max(0,o-c),r=a===1?o:o+a,d=o===0),De(e,{min:o,max:r},n)||d}const Mm={second:500,minute:30*1e3,hour:1800*1e3,day:720*60*1e3,week:3.5*24*60*60*1e3,month:360*60*60*1e3,quarter:1440*60*60*1e3,year:4368*60*60*1e3};function Ll(e,t,n,i=!1){const{min:s,max:o,options:r}=e,a=r.time&&r.time.round,l=Mm[a]||0,c=e.getValueForPixel(e.getPixelForValue(s+l)-t),d=e.getValueForPixel(e.getPixelForValue(o+l)-t);return isNaN(c)||isNaN(d)?!0:De(e,{min:c,max:d},n,i?"pan":!1)}function Qr(e,t,n){return Ll(e,t,n,!0)}const Ds={category:Tm,default:wm,logarithmic:km},Is={default:Sm},Rs={category:Om,default:Ll,logarithmic:Qr,timeseries:Qr};function Pm(e,t,n){const{id:i,options:{min:s,max:o}}=e;if(!t[i]||!n[i])return!0;const r=n[i];return r.min!==s||r.max!==o}function ta(e,t){U(e,(n,i)=>{t[i]||delete e[i]})}function qe(e,t){const{scales:n}=e,{originalScaleLimits:i,updatedScaleLimits:s}=t;return U(n,function(o){Pm(o,i,s)&&(i[o.id]={min:{scale:o.min,options:o.options.min},max:{scale:o.max,options:o.options.max}})}),ta(i,n),ta(s,n),i}function ea(e,t,n,i){const s=Ds[e.type]||Ds.default;N(s,[e,t,n,i])}function na(e,t,n,i){const s=Is[e.type]||Is.default;N(s,[e,t,n,i])}function Am(e){const t=e.chartArea;return{x:(t.left+t.right)/2,y:(t.top+t.bottom)/2}}function ro(e,t,n="none",i="api"){const{x:s=1,y:o=1,focalPoint:r=Am(e)}=typeof t=="number"?{x:t,y:t}:t,a=q(e),{options:{limits:l,zoom:c}}=a;qe(e,a);const d=s!==1,h=o!==1,f=Dl(c,r,e);U(f||e.scales,function(g){g.isHorizontal()&&d?ea(g,s,r,l):!g.isHorizontal()&&h&&ea(g,o,r,l)}),e.update(n),N(c.onZoom,[{chart:e,trigger:i}])}function zl(e,t,n,i="none",s="api"){const o=q(e),{options:{limits:r,zoom:a}}=o,{mode:l="xy"}=a;qe(e,o);const c=he(l,"x",e),d=he(l,"y",e);U(e.scales,function(h){h.isHorizontal()&&c?na(h,t.x,n.x,r):!h.isHorizontal()&&d&&na(h,t.y,n.y,r)}),e.update(i),N(a.onZoom,[{chart:e,trigger:s}])}function Dm(e,t,n,i="none",s="api"){const o=q(e);qe(e,o);const r=e.scales[t];De(r,n,void 0,!0),e.update(i),N(o.options.zoom?.onZoom,[{chart:e,trigger:s}])}function Im(e,t="default"){const n=q(e),i=qe(e,n);U(e.scales,function(s){const o=s.options;i[s.id]?(o.min=i[s.id].min.options,o.max=i[s.id].max.options):(delete o.min,delete o.max),delete n.updatedScaleLimits[s.id]}),e.update(t),N(n.options.zoom.onZoomComplete,[{chart:e}])}function Rm(e,t){const n=e.originalScaleLimits[t];if(!n)return;const{min:i,max:s}=n;return B(s.options,s.scale)-B(i.options,i.scale)}function Nm(e){const t=q(e);let n=1,i=1;return U(e.scales,function(s){const o=Rm(t,s.id);if(o){const r=Math.round(o/(s.max-s.min)*100)/100;n=Math.min(n,r),i=Math.max(i,r)}}),n<1?n:i}function ia(e,t,n,i){const{panDelta:s}=i,o=s[e.id]||0;ce(o)===ce(t)&&(t+=o);const r=Rs[e.type]||Rs.default;N(r,[e,t,n])?s[e.id]=0:s[e.id]=t}function $l(e,t,n,i="none"){const{x:s=0,y:o=0}=typeof t=="number"?{x:t,y:t}:t,r=q(e),{options:{pan:a,limits:l}}=r,{onPan:c}=a||{};qe(e,r);const d=s!==0,h=o!==0;U(n||e.scales,function(f){f.isHorizontal()&&d?ia(f,s,l,r):!f.isHorizontal()&&h&&ia(f,o,l,r)}),e.update(i),N(c,[{chart:e}])}function Fl(e){const t=q(e);qe(e,t);const n={};for(const i of Object.keys(e.scales)){const{min:s,max:o}=t.originalScaleLimits[i]||{min:{},max:{}};n[i]={min:s.scale,max:o.scale}}return n}function Lm(e){const t=q(e),n={};for(const i of Object.keys(e.scales))n[i]=t.updatedScaleLimits[i];return n}function zm(e){const t=Fl(e);for(const n of Object.keys(e.scales)){const{min:i,max:s}=t[n];if(i!==void 0&&e.scales[n].min!==i||s!==void 0&&e.scales[n].max!==s)return!0}return!1}function sa(e){const t=q(e);return t.panning||t.dragging}const oa=(e,t,n)=>Math.min(n,Math.max(t,e));function vt(e,t){const{handlers:n}=q(e),i=n[t];i&&i.target&&(i.target.removeEventListener(t,i),delete n[t])}function yn(e,t,n,i){const{handlers:s,options:o}=q(e),r=s[n];if(r&&r.target===t)return;vt(e,n),s[n]=l=>i(e,l,o),s[n].target=t;const a=n==="wheel"?!1:void 0;t.addEventListener(n,s[n],{passive:a})}function $m(e,t){const n=q(e);n.dragStart&&(n.dragging=!0,n.dragEnd=t,e.update("none"))}function Fm(e,t){const n=q(e);!n.dragStart||t.key!=="Escape"||(vt(e,"keydown"),n.dragging=!1,n.dragStart=n.dragEnd=null,e.update("none"))}function Ns(e,t){if(e.target!==t.canvas){const n=t.canvas.getBoundingClientRect();return{x:e.clientX-n.left,y:e.clientY-n.top}}return Ut(e,t)}function Bl(e,t,n){const{onZoomStart:i,onZoomRejected:s}=n;if(i){const o=Ns(t,e);if(N(i,[{chart:e,event:t,point:o}])===!1)return N(s,[{chart:e,event:t}]),!1}}function Bm(e,t){if(e.legend){const o=Ut(t,e);if(Ve(o,e.legend))return}const n=q(e),{pan:i,zoom:s={}}=n.options;if(t.button!==0||Al(Pn(i),t)||oo(Pn(s.drag),t))return N(s.onZoomRejected,[{chart:e,event:t}]);Bl(e,t,s)!==!1&&(n.dragStart=t,yn(e,e.canvas.ownerDocument,"mousemove",$m),yn(e,window.document,"keydown",Fm))}function Hm({begin:e,end:t},n){let i=t.x-e.x,s=t.y-e.y;const o=Math.abs(i/s);o>n?i=Math.sign(i)*Math.abs(s*n):o<n&&(s=Math.sign(s)*Math.abs(i/n)),t.x=e.x+i,t.y=e.y+s}function ra(e,t,n,{min:i,max:s,prop:o}){e[i]=oa(Math.min(n.begin[o],n.end[o]),t[i],t[s]),e[s]=oa(Math.max(n.begin[o],n.end[o]),t[i],t[s])}function Um(e,t,n){const i={begin:Ns(t.dragStart,e),end:Ns(t.dragEnd,e)};if(n){const s=e.chartArea.width/e.chartArea.height;Hm(i,s)}return i}function Hl(e,t,n,i){const s=he(t,"x",e),o=he(t,"y",e),{top:r,left:a,right:l,bottom:c,width:d,height:h}=e.chartArea,f={top:r,left:a,right:l,bottom:c},g=Um(e,n,i&&s&&o);s&&ra(f,e.chartArea,g,{min:"left",max:"right",prop:"x"}),o&&ra(f,e.chartArea,g,{min:"top",max:"bottom",prop:"y"});const m=f.right-f.left,v=f.bottom-f.top;return{...f,width:m,height:v,zoomX:s&&m?1+(d-m)/d:1,zoomY:o&&v?1+(h-v)/h:1}}function Wm(e,t){const n=q(e);if(!n.dragStart)return;vt(e,"mousemove");const{mode:i,onZoomComplete:s,drag:{threshold:o=0,maintainAspectRatio:r}}=n.options.zoom,a=Hl(e,i,{dragStart:n.dragStart,dragEnd:t},r),l=he(i,"x",e)?a.width:0,c=he(i,"y",e)?a.height:0,d=Math.sqrt(l*l+c*c);if(n.dragStart=n.dragEnd=null,d<=o){n.dragging=!1,e.update("none");return}zl(e,{x:a.left,y:a.top},{x:a.right,y:a.bottom},"zoom","drag"),n.dragging=!1,n.filterNextClick=!0,N(s,[{chart:e}])}function jm(e,t,n){if(oo(Pn(n.wheel),t)){N(n.onZoomRejected,[{chart:e,event:t}]);return}if(Bl(e,t,n)!==!1&&(t.cancelable&&t.preventDefault(),t.deltaY!==void 0))return!0}function Vm(e,t){const{handlers:{onZoomComplete:n},options:{zoom:i}}=q(e);if(!jm(e,t,i))return;const s=t.target.getBoundingClientRect(),o=i.wheel.speed,r=t.deltaY>=0?2-1/(1-o):1+o,a={x:r,y:r,focalPoint:{x:t.clientX-s.left,y:t.clientY-s.top}};ro(e,a,"zoom","wheel"),N(n,[{chart:e}])}function Ym(e,t,n,i){n&&(q(e).handlers[t]=gm(()=>N(n,[{chart:e}]),i))}function Gm(e,t){const n=e.canvas,{wheel:i,drag:s,onZoomComplete:o}=t.zoom;i.enabled?(yn(e,n,"wheel",Vm),Ym(e,"onZoomComplete",o,250)):vt(e,"wheel"),s.enabled?(yn(e,n,"mousedown",Bm),yn(e,n.ownerDocument,"mouseup",Wm)):(vt(e,"mousedown"),vt(e,"mousemove"),vt(e,"mouseup"),vt(e,"keydown"))}function Km(e){vt(e,"mousedown"),vt(e,"mousemove"),vt(e,"mouseup"),vt(e,"wheel"),vt(e,"click"),vt(e,"keydown")}function qm(e,t){return function(n,i){const{pan:s,zoom:o={}}=t.options;if(!s||!s.enabled)return!1;const r=i&&i.srcEvent;return r&&!t.panning&&i.pointerType==="mouse"&&(oo(Pn(s),r)||Al(Pn(o.drag),r))?(N(s.onPanRejected,[{chart:e,event:i}]),!1):!0}}function Xm(e,t){const n=Math.abs(e.clientX-t.clientX),i=Math.abs(e.clientY-t.clientY),s=n/i;let o,r;return s>.3&&s<1.7?o=r=!0:n>i?o=!0:r=!0,{x:o,y:r}}function Ul(e,t,n){if(t.scale){const{center:i,pointers:s}=n,o=1/t.scale*n.scale,r=n.target.getBoundingClientRect(),a=Xm(s[0],s[1]),l=t.options.zoom.mode,c={x:a.x&&he(l,"x",e)?o:1,y:a.y&&he(l,"y",e)?o:1,focalPoint:{x:i.x-r.left,y:i.y-r.top}};ro(e,c,"zoom","pinch"),t.scale=n.scale}}function Zm(e,t,n){if(t.options.zoom.pinch.enabled){const i=Ut(n,e);N(t.options.zoom.onZoomStart,[{chart:e,event:n,point:i}])===!1?(t.scale=null,N(t.options.zoom.onZoomRejected,[{chart:e,event:n}])):t.scale=1}}function Jm(e,t,n){t.scale&&(Ul(e,t,n),t.scale=null,N(t.options.zoom.onZoomComplete,[{chart:e}]))}function Wl(e,t,n){const i=t.delta;i&&(t.panning=!0,$l(e,{x:n.deltaX-i.x,y:n.deltaY-i.y},t.panScales),t.delta={x:n.deltaX,y:n.deltaY})}function Qm(e,t,n){const{enabled:i,onPanStart:s,onPanRejected:o}=t.options.pan;if(!i)return;const r=n.target.getBoundingClientRect(),a={x:n.center.x-r.left,y:n.center.y-r.top};if(N(s,[{chart:e,event:n,point:a}])===!1)return N(o,[{chart:e,event:n}]);t.panScales=Dl(t.options.pan,a,e),t.delta={x:0,y:0},Wl(e,t,n)}function tb(e,t){t.delta=null,t.panning&&(t.panning=!1,t.filterNextClick=!0,N(t.options.pan.onPanComplete,[{chart:e}]))}const Ls=new WeakMap;function aa(e,t){const n=q(e),i=e.canvas,{pan:s,zoom:o}=t,r=new vn.Manager(i);o&&o.pinch.enabled&&(r.add(new vn.Pinch),r.on("pinchstart",a=>Zm(e,n,a)),r.on("pinch",a=>Ul(e,n,a)),r.on("pinchend",a=>Jm(e,n,a))),s&&s.enabled&&(r.add(new vn.Pan({threshold:s.threshold,enable:qm(e,n)})),r.on("panstart",a=>Qm(e,n,a)),r.on("panmove",a=>Wl(e,n,a)),r.on("panend",()=>tb(e,n))),Ls.set(e,r)}function la(e){const t=Ls.get(e);t&&(t.remove("pinchstart"),t.remove("pinch"),t.remove("pinchend"),t.remove("panstart"),t.remove("pan"),t.remove("panend"),t.destroy(),Ls.delete(e))}function eb(e,t){const{pan:n,zoom:i}=e,{pan:s,zoom:o}=t;return i?.zoom?.pinch?.enabled!==o?.zoom?.pinch?.enabled||n?.enabled!==s?.enabled||n?.threshold!==s?.threshold}var nb="2.2.0";function ci(e,t,n){const i=n.zoom.drag,{dragStart:s,dragEnd:o}=q(e);if(i.drawTime!==t||!o)return;const{left:r,top:a,width:l,height:c}=Hl(e,n.zoom.mode,{dragStart:s,dragEnd:o},i.maintainAspectRatio),d=e.ctx;d.save(),d.beginPath(),d.fillStyle=i.backgroundColor||"rgba(225,225,225,0.3)",d.fillRect(r,a,l,c),i.borderWidth>0&&(d.lineWidth=i.borderWidth,d.strokeStyle=i.borderColor||"rgba(225,225,225)",d.strokeRect(r,a,l,c)),d.restore()}var ib={id:"zoom",version:nb,defaults:{pan:{enabled:!1,mode:"xy",threshold:10,modifierKey:null},zoom:{wheel:{enabled:!1,speed:.1,modifierKey:null},drag:{enabled:!1,drawTime:"beforeDatasetsDraw",modifierKey:null},pinch:{enabled:!1},mode:"xy"}},start:function(e,t,n){const i=q(e);i.options=n,Object.prototype.hasOwnProperty.call(n.zoom,"enabled")&&console.warn("The option `zoom.enabled` is no longer supported. Please use `zoom.wheel.enabled`, `zoom.drag.enabled`, or `zoom.pinch.enabled`."),(Object.prototype.hasOwnProperty.call(n.zoom,"overScaleMode")||Object.prototype.hasOwnProperty.call(n.pan,"overScaleMode"))&&console.warn("The option `overScaleMode` is deprecated. Please use `scaleMode` instead (and update `mode` as desired)."),vn&&aa(e,n),e.pan=(s,o,r)=>$l(e,s,o,r),e.zoom=(s,o)=>ro(e,s,o),e.zoomRect=(s,o,r)=>zl(e,s,o,r),e.zoomScale=(s,o,r)=>Dm(e,s,o,r),e.resetZoom=s=>Im(e,s),e.getZoomLevel=()=>Nm(e),e.getInitialScaleBounds=()=>Fl(e),e.getZoomedScaleBounds=()=>Lm(e),e.isZoomedOrPanned=()=>zm(e),e.isZoomingOrPanning=()=>sa(e)},beforeEvent(e,{event:t}){if(sa(e))return!1;if(t.type==="click"||t.type==="mouseup"){const n=q(e);if(n.filterNextClick)return n.filterNextClick=!1,!1}},beforeUpdate:function(e,t,n){const i=q(e),s=i.options;i.options=n,eb(s,n)&&(la(e),aa(e,n)),Gm(e,n)},beforeDatasetsDraw(e,t,n){ci(e,"beforeDatasetsDraw",n)},afterDatasetsDraw(e,t,n){ci(e,"afterDatasetsDraw",n)},beforeDraw(e,t,n){ci(e,"beforeDraw",n)},afterDraw(e,t,n){ci(e,"afterDraw",n)},stop:function(e){Km(e),vn&&la(e),bm(e)},panFunctions:Rs,zoomFunctions:Ds,zoomRectFunctions:Is},sb=Object.defineProperty,ob=Object.getOwnPropertyDescriptor,zn=(e,t,n,i)=>{for(var s=i>1?void 0:i?ob(t,n):t,o=e.length-1,r;o>=0;o--)(r=e[o])&&(s=(i?r(t,n,s):r(s))||s);return i&&s&&sb(t,n,s),s};Jt.register(di,oe,fi,Ps,Mn,am,Qg,Gg,ib);const ze=["#3b82f6","#ef4444","#10b981","#f59e0b","#8b5cf6","#ec4899","#06b6d4","#84cc16","#f97316","#6366f1"],rb=[{label:"5m",ms:5*6e4},{label:"15m",ms:15*6e4},{label:"1h",ms:60*6e4},{label:"6h",ms:360*6e4},{label:"All",ms:null}];let Ce=class extends it{constructor(){super(...arguments),this.content="",this.hiddenSeries=new Set,this.activeZoom="All",this.error=!1,this.chart=null,this.buildPending=!1,this._cachedContent="",this._cachedParsed=null,this._boundWrap=null,this.onWrapWheel=e=>{this.chart&&(e.preventDefault(),e.stopPropagation())}}disconnectedCallback(){super.disconnectedCallback(),this.destroyChart(),this.detachWrapListeners()}destroyChart(){this.chart&&(this.chart.destroy(),this.chart=null)}attachWrapListeners(){this.detachWrapListeners();const e=this.shadowRoot?.querySelector(".chart-wrap");e&&(this._boundWrap=e,e.addEventListener("wheel",this.onWrapWheel,{passive:!1}))}detachWrapListeners(){this._boundWrap&&(this._boundWrap.removeEventListener("wheel",this.onWrapWheel),this._boundWrap=null)}updated(e){e.has("content")&&(this.hiddenSeries=new Set,this.activeZoom="All",this.error=!1,this._cachedContent=this.content,this._cachedParsed=ms(this.content),this.scheduleBuild())}get parsed(){return this._cachedContent!==this.content&&(this._cachedContent=this.content,this._cachedParsed=ms(this.content)),this._cachedParsed}scheduleBuild(){this.buildPending||(this.buildPending=!0,setTimeout(()=>{this.buildPending=!1,this.buildChart()},0))}getTimeRange(){const e=this.parsed;if(!e)return null;let t=1/0,n=-1/0;for(const i of e.series)for(const s of i.data)s.x<t&&(t=s.x),s.x>n&&(n=s.x);return isFinite(t)&&isFinite(n)?{min:t,max:n}:null}buildChart(){this.destroyChart();const e=this.parsed;if(!e||e.series.length===0){this.error=!0;return}const t=this.shadowRoot?.querySelector("canvas");if(!t)return;const n=t.getContext("2d");if(!n)return;const i=getComputedStyle(this).getPropertyValue("--text-secondary").trim()||"#999",s=getComputedStyle(this).getPropertyValue("--border-secondary").trim()||"rgba(128,128,128,0.2)";this.chart=new Jt(n,{type:"line",data:{datasets:e.series.map((o,r)=>({label:o.name,data:o.data,borderColor:ze[r%ze.length],backgroundColor:ze[r%ze.length]+"22",borderWidth:1.5,pointRadius:0,pointHitRadius:6,tension:.25,fill:!1,hidden:this.hiddenSeries.has(r)}))},options:{responsive:!0,maintainAspectRatio:!1,animation:{duration:300},interaction:{mode:"index",intersect:!1},plugins:{legend:{display:!1},tooltip:{callbacks:{title:o=>{if(!o.length)return"";const r=o[0].parsed.x;return r!=null?new Date(r).toLocaleString():""}}},zoom:{pan:{enabled:!1},zoom:{wheel:{enabled:!0},drag:{enabled:!0,backgroundColor:"rgba(59,130,246,0.12)",borderColor:"rgba(59,130,246,0.4)",borderWidth:1},mode:"x",onZoomComplete:()=>{this.activeZoom="",this.requestUpdate()}}}},scales:{x:{type:"linear",ticks:{color:i,font:{size:10},maxTicksLimit:8,callback:o=>new Date(o).toLocaleTimeString([],{hour:"2-digit",minute:"2-digit"})},grid:{color:s}},y:{ticks:{color:i,font:{size:10},maxTicksLimit:6},grid:{color:s}}}}}),this.attachWrapListeners()}toggleSeries(e){const t=new Set(this.hiddenSeries);if(t.has(e)?t.delete(e):t.add(e),this.hiddenSeries=t,this.chart){const n=this.chart.getDatasetMeta(e);n.hidden=t.has(e),this.chart.update("none")}}applyZoom(e){if(this.activeZoom=e.label,!this.chart)return;if(e.ms===null){this.chart.resetZoom("default");return}const t=this.getTimeRange();if(!t)return;const n=t.max,i=Math.max(t.min,n-e.ms);this.chart.zoomScale("x",{min:i,max:n},"default")}renderLegend(e){return e.series.map((t,n)=>S`
        <button
          class="legend-item ${this.hiddenSeries.has(n)?"hidden":""}"
          @click=${()=>this.toggleSeries(n)}
          title="${this.hiddenSeries.has(n)?"Show":"Hide"} ${t.name}"
        >
          <span class="legend-swatch" style="background:${ze[n%ze.length]}"></span>
          ${t.name}
        </button>
      `)}renderZoomControls(){return S`
      <span class="zoom-hint">Zoom:</span>
      ${rb.map(e=>S`
          <button
            class="zoom-btn ${this.activeZoom===e.label?"active":""}"
            @click=${()=>this.applyZoom(e)}
          >
            ${e.label}
          </button>
        `)}
    `}render(){const e=this.parsed;return this.error||!e?S`<div class="fallback">Unable to parse time-series data</div>`:S`
      <div class="toolbar">
        <div class="legend-area">${this.renderLegend(e)}</div>
        <div class="zoom-controls">${this.renderZoomControls()}</div>
      </div>
      <div class="chart-wrap">
        <canvas></canvas>
      </div>
    `}};Ce.styles=at`
    :host {
      display: flex;
      flex-direction: column;
      flex: 1;
      min-height: 0;
      user-select: none;
    }

    .toolbar {
      display: flex;
      align-items: center;
      gap: 6px;
      padding: 4px 2px 2px;
      flex-wrap: wrap;
    }

    .legend-area {
      display: flex;
      align-items: center;
      gap: 4px;
      flex-wrap: wrap;
      flex: 1;
      min-width: 0;
    }

    .legend-item {
      display: inline-flex;
      align-items: center;
      gap: 4px;
      padding: 2px 6px;
      border-radius: var(--radius-xs, 4px);
      cursor: pointer;
      font-size: 11px;
      font-family: var(--font-sans, sans-serif);
      color: var(--text-secondary, #999);
      background: transparent;
      border: 1px solid transparent;
      transition:
        opacity 0.15s,
        background 0.15s;
      user-select: none;
    }

    .legend-item:hover {
      background: var(--bg-hover, rgba(128, 128, 128, 0.1));
    }

    .legend-item.hidden {
      opacity: 0.4;
    }

    .legend-item.hidden .legend-swatch {
      background: var(--text-tertiary, #666) !important;
    }

    .legend-swatch {
      width: 10px;
      height: 3px;
      border-radius: 1px;
      flex-shrink: 0;
    }

    .zoom-controls {
      display: flex;
      align-items: center;
      gap: 2px;
      flex-shrink: 0;
    }

    .zoom-btn {
      padding: 2px 7px;
      border-radius: var(--radius-xs, 4px);
      cursor: pointer;
      font-size: 10px;
      font-family: var(--font-mono, monospace);
      color: var(--text-secondary, #999);
      background: transparent;
      border: 1px solid var(--border-secondary, rgba(128, 128, 128, 0.15));
      transition:
        background 0.15s,
        color 0.15s,
        border-color 0.15s;
      user-select: none;
      line-height: 1.5;
    }

    .zoom-btn:hover {
      background: var(--bg-hover, rgba(128, 128, 128, 0.1));
      color: var(--text-primary, #ccc);
    }

    .zoom-btn.active {
      background: var(--accent-primary, #3b82f6);
      color: var(--text-inverse, #fff);
      border-color: var(--accent-primary, #3b82f6);
    }

    .zoom-hint {
      font-size: 10px;
      color: var(--text-tertiary, #666);
      font-family: var(--font-sans, sans-serif);
      padding: 0 4px;
    }

    .chart-wrap {
      position: relative;
      width: 100%;
      flex: 1;
      min-height: 0;
      touch-action: none;
    }

    .fallback {
      padding: 16px;
      color: var(--text-tertiary);
      font-size: var(--font-size-sm);
      font-family: var(--font-mono);
      text-align: center;
    }
  `;zn([Wt({type:String})],Ce.prototype,"content",2);zn([L()],Ce.prototype,"hiddenSeries",2);zn([L()],Ce.prototype,"activeZoom",2);zn([L()],Ce.prototype,"error",2);Ce=zn([st("chart-card")],Ce);const ca="highlight-utils-style";function da(e){if(e.getElementById(ca))return;const t=document.createElement("style");t.id=ca,t.textContent=`
    mark[data-hl] {
      background: var(--accent-warning, #e8a817);
      color: inherit;
      border-radius: 2px;
      padding: 0;
    }
    mark[data-hl].active {
      background: var(--accent-primary, #2563eb);
      color: #fff;
    }
  `,e.appendChild(t)}function ab(e,t){if(jl(e),!t)return 0;const n=t.toLowerCase(),i=document.createTreeWalker(e,NodeFilter.SHOW_TEXT),s=[];for(;i.nextNode();)s.push(i.currentNode);let o=0;for(const r of s){const a=r.nodeValue??"",l=lb(a,n);if(l.length<=1)continue;const c=document.createDocumentFragment();for(const d of l)if(d.match){const h=document.createElement("mark");h.setAttribute("data-hl",""),h.textContent=d.text,c.appendChild(h),o++}else c.appendChild(document.createTextNode(d.text));r.parentNode.replaceChild(c,r)}return o}function jl(e){const t=e.querySelectorAll("mark[data-hl]");for(const n of t){const i=n.parentNode,s=document.createTextNode(n.textContent??"");i.replaceChild(s,n),i.normalize()}}function ha(e,t){const n=e.querySelectorAll("mark[data-hl]");for(let i=0;i<n.length;i++){const s=n[i];i===t?(s.classList.add("active"),s.scrollIntoView({block:"nearest",behavior:"smooth"})):s.classList.remove("active")}}function lb(e,t){const n=[],i=e.toLowerCase();let s=0;for(;s<e.length;){const o=i.indexOf(t,s);if(o===-1){n.push({text:e.slice(s),match:!1});break}o>s&&n.push({text:e.slice(s,o),match:!1}),n.push({text:e.slice(o,o+t.length),match:!0}),s=o+t.length}return n}var cb=Object.defineProperty,db=Object.getOwnPropertyDescriptor,Vl=(e,t,n,i)=>{for(var s=i>1?void 0:i?db(t,n):t,o=e.length-1,r;o>=0;o--)(r=e[o])&&(s=(i?r(t,n,s):r(s))||s);return i&&s&&cb(t,n,s),s};let Ti=class extends it{constructor(){super(...arguments),this.content=""}render(){return S`<pre class="text">${this.content}</pre>`}};Ti.styles=at`
    :host {
      display: block;
      color: var(--text-primary);
    }

    .text {
      font-family: var(--font-mono);
      font-size: var(--font-size-xs);
      line-height: 1.5;
      white-space: pre;
      overflow-x: auto;
      padding: 4px 0;
      margin: 0;
    }
  `;Vl([Wt({type:String})],Ti.prototype,"content",2);Ti=Vl([st("text-renderer")],Ti);var hb=Object.defineProperty,ub=Object.getOwnPropertyDescriptor,Ie=(e,t,n,i)=>{for(var s=i>1?void 0:i?ub(t,n):t,o=e.length-1,r;o>=0;o--)(r=e[o])&&(s=(i?r(t,n,s):r(s))||s);return i&&s&&hb(t,n,s),s};let _t=class extends it{constructor(){super(...arguments),this.cards=[],this.expandedToolStrips=new Set,this.rerunningCards=new Set,this.copiedCards=new Set,this.searchOpen=new Set,this.searchState=new Map,this.dragId=null,this.resizeCardId=null,this.resizeStartY=0,this.resizeStartHeight=0,this.onResizeMove=e=>{if(!this.resizeCardId)return;const t=e.clientY-this.resizeStartY,n=Math.max(_t.MIN_CARD_HEIGHT,this.resizeStartHeight+t),i=this.shadowRoot?.querySelector(`.card-body[data-card-id="${this.resizeCardId}"]`);i&&(i.style.height=`${n}px`)},this.onResizeEnd=()=>{if(!this.resizeCardId)return;const e=this.shadowRoot?.querySelector(`.card-body[data-card-id="${this.resizeCardId}"]`),t=e?parseInt(e.style.height,10):this.resizeStartHeight;w.updateCardHeight(this.resizeCardId,t),this.shadowRoot?.querySelectorAll(".resize-grip.active").forEach(n=>{n.classList.remove("active")}),this.resizeCardId=null,document.removeEventListener("mousemove",this.onResizeMove),document.removeEventListener("mouseup",this.onResizeEnd)}}connectedCallback(){super.connectedCallback(),this.unsubscribe=w.subscribe(()=>{this.cards=w.state.pinCards}),this.cards=w.state.pinCards}disconnectedCallback(){super.disconnectedCallback(),this.unsubscribe?.(),document.removeEventListener("mousemove",this.onResizeMove),document.removeEventListener("mouseup",this.onResizeEnd)}close(e){w.removeCard(e)}async copyCard(e){try{await navigator.clipboard.writeText(e.content);const t=new Set(this.copiedCards);t.add(e.id),this.copiedCards=t,setTimeout(()=>{const n=new Set(this.copiedCards);n.delete(e.id),this.copiedCards=n},1500)}catch{}}toggleToolStrip(e){const t=new Set(this.expandedToolStrips);t.has(e)?t.delete(e):t.add(e),this.expandedToolStrips=t}async rerunTool(e){if(!e.toolName||this.rerunningCards.has(e.id))return;const t=new Set(this.rerunningCards);t.add(e.id),this.rerunningCards=t;try{const n=await Yc(e.toolName,e.toolArgs??{});w.updateCard(e.id,{loading:!0}),await new Promise(i=>setTimeout(()=>{if(e.type==="graph")w.updateCard(e.id,{content:n.result,loading:!1,timestamp:Date.now()});else{const s=wa(e.toolName,e.toolArgs??{}),o=gs(s,n.result),r=s.canPinGraph?"text":o.displayType;w.updateCard(e.id,{content:o.content,type:r,loading:!1,timestamp:Date.now()})}i()},0))}catch(n){w.updateCard(e.id,{content:`**Error re-running tool:** ${n.message}`,loading:!1})}finally{const n=new Set(this.rerunningCards);n.delete(e.id),this.rerunningCards=n}}onDragStart(e,t){this.dragId=e,t.dataTransfer.effectAllowed="move"}onDragOver(e){e.preventDefault(),e.dataTransfer.dropEffect="move"}onDragEnter(e){e.currentTarget.closest(".card")?.classList.add("drag-over")}onDragLeave(e){const t=e.currentTarget.closest(".card"),n=e.relatedTarget;t&&!t.contains(n)&&t.classList.remove("drag-over")}onDrop(e,t){if(t.preventDefault(),t.currentTarget.closest(".card")?.classList.remove("drag-over"),!this.dragId||this.dragId===e)return;const i=this.cards.findIndex(s=>s.id===e);i>=0&&w.moveCard(this.dragId,i),this.dragId=null}onDragEnd(){this.dragId=null,this.shadowRoot?.querySelectorAll(".drag-over").forEach(e=>{e.classList.remove("drag-over")})}onResizeStart(e,t){t.preventDefault(),this.resizeCardId=e,this.resizeStartY=t.clientY;const n=this.cards.find(s=>s.id===e);this.resizeStartHeight=n?.height??_t.DEFAULT_CARD_HEIGHT,t.currentTarget.classList.add("active"),document.addEventListener("mousemove",this.onResizeMove),document.addEventListener("mouseup",this.onResizeEnd)}formatTimeAgo(e){const t=Math.floor((Date.now()-e)/1e3);if(t<5)return"just now";if(t<60)return`${t}s ago`;const n=Math.floor(t/60);if(n<60)return`${n}m ago`;const i=Math.floor(n/60);return i<24?`${i}h ago`:`${Math.floor(i/24)}d ago`}getRendererRoot(e){const t=this.shadowRoot?.querySelector(`.card-body[data-card-id="${e}"]`),n=t?.querySelector("markdown-renderer");if(n){const s=n.shadowRoot?.querySelector(".md");return s&&n.shadowRoot&&da(n.shadowRoot),s}const i=t?.querySelector("text-renderer");if(i){const s=i.shadowRoot?.querySelector(".text");return s&&i.shadowRoot&&da(i.shadowRoot),s}return null}toggleSearch(e){const t=new Set(this.searchOpen);if(t.has(e)){t.delete(e);const n=this.getRendererRoot(e);n&&jl(n);const i=new Map(this.searchState);i.delete(e),this.searchState=i}else t.add(e);this.searchOpen=t}onSearchInput(e,t){const n=t.detail??"",i=this.getRendererRoot(e);if(!i)return;const s=ab(i,n),o=s>0?0:-1;s>0&&ha(i,0);const r=new Map(this.searchState);r.set(e,{query:n,count:s,index:o}),this.searchState=r}onSearchNav(e,t){const n=this.searchState.get(e);if(!n||n.count===0)return;const i=(n.index+t+n.count)%n.count,s=this.getRendererRoot(e);s&&ha(s,i);const o=new Map(this.searchState);o.set(e,{...n,index:i}),this.searchState=o}toolSummary(e){if(!e.toolArgs||Object.keys(e.toolArgs).length===0)return"";const t=e.toolArgs.command;if(typeof t=="string")return t;const n=Object.values(e.toolArgs).map(i=>typeof i=="string"?i:JSON.stringify(i)).join(", ");return n.length>60?n.slice(0,57)+"...":n}renderToolStrip(e){if(!e.toolName)return X;const t=this.expandedToolStrips.has(e.id),n=this.toolSummary(e),i=JSON.stringify(e.toolArgs??{},null,2);return S`
      <div class="tool-strip">
        <div class="tool-strip-header" @click=${()=>this.toggleToolStrip(e.id)}>
          <svg
            class="tool-chevron ${t?"open":""}"
            viewBox="0 0 24 24"
            fill="none"
            stroke="currentColor"
            stroke-width="2"
            stroke-linecap="round"
            stroke-linejoin="round"
          >
            <polyline points="9 18 15 12 9 6" />
          </svg>
          <svg
            class="tool-icon"
            viewBox="0 0 24 24"
            fill="none"
            stroke="currentColor"
            stroke-width="2"
            stroke-linecap="round"
            stroke-linejoin="round"
          >
            <path
              d="M14.7 6.3a1 1 0 0 0 0 1.4l1.6 1.6a1 1 0 0 0 1.4 0l3.77-3.77a6 6 0 0 1-7.94 7.94l-6.91 6.91a2.12 2.12 0 0 1-3-3l6.91-6.91a6 6 0 0 1 7.94-7.94l-3.76 3.76z"
            />
          </svg>
          <span class="tool-name">${e.toolName}</span>
          ${n?S`<span class="tool-summary">${n}</span>`:X}
        </div>
        ${t?S`
              <div class="tool-detail">
                <div class="tool-detail-label">Arguments</div>
                <div class="tool-code">${i}</div>
              </div>
            `:X}
      </div>
    `}renderRerunButton(e){if(!e.toolName)return X;const t=this.rerunningCards.has(e.id);return S`
      <button
        class="header-btn rerun ${t?"rerunning":""}"
        title="Re-run tool call"
        @click=${n=>{n.stopPropagation(),this.rerunTool(e)}}
      >
        <svg
          viewBox="0 0 24 24"
          fill="none"
          stroke="currentColor"
          stroke-width="2"
          stroke-linecap="round"
          stroke-linejoin="round"
        >
          <polyline points="23 4 23 10 17 10" />
          <path d="M20.49 15a9 9 0 1 1-2.12-9.36L23 10" />
        </svg>
      </button>
    `}renderSearchBar(e){if(!this.searchOpen.has(e.id))return X;const t=this.searchState.get(e.id);return S`
      <card-search-bar
        .matchCount=${t?.count??0}
        .activeIndex=${t?.index??-1}
        @search-input=${n=>this.onSearchInput(e.id,n)}
        @search-prev=${()=>this.onSearchNav(e.id,-1)}
        @search-next=${()=>this.onSearchNav(e.id,1)}
        @search-close=${()=>this.toggleSearch(e.id)}
      ></card-search-bar>
    `}renderCard(e){return S`
      <div
        class="card"
        @dragover=${this.onDragOver}
        @dragenter=${this.onDragEnter}
        @dragleave=${this.onDragLeave}
        @drop=${t=>this.onDrop(e.id,t)}
      >
        <div
          class="card-header"
          draggable="true"
          @dragstart=${t=>this.onDragStart(e.id,t)}
          @dragend=${this.onDragEnd}
        >
          <button
            class="header-btn copy ${this.copiedCards.has(e.id)?"copied":""}"
            title=${this.copiedCards.has(e.id)?"Copied!":"Copy content"}
            @click=${t=>{t.stopPropagation(),this.copyCard(e)}}
          >
            ${this.copiedCards.has(e.id)?S`<svg
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="currentColor"
                  stroke-width="2"
                  stroke-linecap="round"
                  stroke-linejoin="round"
                >
                  <polyline points="20 6 9 17 4 12" />
                </svg>`:S`<svg
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="currentColor"
                  stroke-width="2"
                  stroke-linecap="round"
                  stroke-linejoin="round"
                >
                  <rect x="9" y="9" width="13" height="13" rx="2" ry="2" />
                  <path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1" />
                </svg>`}
          </button>
          <span class="card-title" title=${e.title}>${e.title}</span>
          <span class="timestamp" title=${new Date(e.timestamp).toLocaleString()}
            >${this.formatTimeAgo(e.timestamp)}</span
          >
          <button
            class="header-btn search"
            title="Search"
            @click=${()=>this.toggleSearch(e.id)}
          >
            <svg
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              stroke-width="2"
              stroke-linecap="round"
              stroke-linejoin="round"
            >
              <circle cx="11" cy="11" r="8" />
              <line x1="21" y1="21" x2="16.65" y2="16.65" />
            </svg>
          </button>
          ${this.renderRerunButton(e)}
          <button class="header-btn close" title="Close" @click=${()=>this.close(e.id)}>
            <svg
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              stroke-width="2"
              stroke-linecap="round"
              stroke-linejoin="round"
            >
              <line x1="18" y1="6" x2="6" y2="18" />
              <line x1="6" y1="6" x2="18" y2="18" />
            </svg>
          </button>
        </div>
        ${this.renderSearchBar(e)} ${this.renderToolStrip(e)}
        <div
          class="card-body ${e.type==="graph"?"no-scroll":""}"
          data-card-id=${e.id}
          style="height: ${e.height??_t.DEFAULT_CARD_HEIGHT}px"
        >
          ${e.loading?S`<div class="card-loading">
                <span class="card-loading-dot"></span>
                <span class="card-loading-dot"></span>
                <span class="card-loading-dot"></span>
                <span>Preparing&hellip;</span>
              </div>`:e.type==="graph"?S`<chart-card .content=${e.content}></chart-card>`:e.type==="text"?S`<text-renderer .content=${e.content}></text-renderer>`:S`<markdown-renderer .content=${e.content}></markdown-renderer>`}
        </div>
        <div
          class="resize-grip"
          @mousedown=${t=>this.onResizeStart(e.id,t)}
        ></div>
      </div>
    `}render(){return this.cards.length===0?S`<div class="placeholder">Pinned results will appear here</div>`:S` <div class="cards">${this.cards.map(e=>this.renderCard(e))}</div> `}};_t.styles=at`
    :host {
      display: flex;
      flex-direction: column;
      height: 100%;
      overflow: hidden;
      background: var(--bg-secondary);
      box-sizing: border-box;
    }

    .cards {
      flex: 1;
      overflow-y: auto;
      padding: 12px;
      display: flex;
      flex-direction: column;
      gap: 12px;
    }

    .card {
      border: 1px solid var(--border-secondary);
      border-radius: var(--radius-sm);
      background: var(--bg-primary);
      overflow: hidden;
    }

    .card.drag-over {
      border-color: var(--accent-primary);
      box-shadow: 0 0 0 1px var(--accent-primary);
    }

    .card-header {
      display: flex;
      align-items: center;
      gap: 8px;
      padding: 8px 12px;
      background: var(--bg-tertiary);
      cursor: grab;
      user-select: none;
    }

    .card-header:active {
      cursor: grabbing;
    }

    .card-title {
      flex: 1;
      font-size: var(--font-size-sm);
      font-weight: var(--font-weight-medium);
      color: var(--text-primary);
      overflow: hidden;
      text-overflow: ellipsis;
      white-space: nowrap;
    }

    .timestamp {
      font-size: var(--font-size-xs);
      color: var(--text-tertiary);
      white-space: nowrap;
      flex-shrink: 0;
      font-variant-numeric: tabular-nums;
    }

    .header-btn {
      display: inline-flex;
      align-items: center;
      justify-content: center;
      width: 22px;
      height: 22px;
      padding: 0;
      border: none;
      border-radius: var(--radius-xs);
      background: transparent;
      color: var(--text-tertiary);
      cursor: pointer;
      flex-shrink: 0;
      transition: all var(--transition-fast);
    }

    .header-btn:hover {
      background: var(--bg-hover);
      color: var(--accent-primary);
    }

    .header-btn.search {
      color: var(--text-tertiary);
    }

    .header-btn.close:hover {
      color: var(--accent-danger);
    }

    .header-btn.rerun:hover {
      color: var(--accent-success);
    }

    .header-btn.rerunning {
      color: var(--accent-info);
      animation: spin 1s linear infinite;
    }

    .header-btn.copy.copied {
      color: var(--accent-success);
    }

    @keyframes spin {
      from {
        transform: rotate(0deg);
      }
      to {
        transform: rotate(360deg);
      }
    }

    .header-btn svg {
      width: 14px;
      height: 14px;
    }

    /* --- tool-call info strip ------------------------------------------- */

    .tool-strip {
      border-top: 1px solid var(--border-secondary);
      background: var(--bg-tool-header, var(--bg-tertiary));
      font-size: var(--font-size-xs);
      overflow: hidden;
    }

    .tool-strip-header {
      display: flex;
      align-items: center;
      gap: 6px;
      padding: 4px 12px;
      cursor: pointer;
      user-select: none;
      transition: background var(--transition-fast);
    }

    .tool-strip-header:hover {
      background: var(--bg-hover);
    }

    .tool-chevron {
      width: 12px;
      height: 12px;
      color: var(--text-tertiary);
      transition: transform var(--transition-fast);
      flex-shrink: 0;
    }

    .tool-chevron.open {
      transform: rotate(90deg);
    }

    .tool-icon {
      width: 12px;
      height: 12px;
      color: var(--accent-warning);
      flex-shrink: 0;
    }

    .tool-name {
      font-family: var(--font-mono);
      color: var(--text-secondary);
      overflow: hidden;
      text-overflow: ellipsis;
      white-space: nowrap;
    }

    .tool-summary {
      color: var(--text-tertiary);
      overflow: hidden;
      text-overflow: ellipsis;
      white-space: nowrap;
      flex: 1;
    }

    .tool-detail {
      padding: 6px 12px;
      border-top: 1px solid var(--border-secondary);
    }

    .tool-detail-label {
      font-size: var(--font-size-xs);
      font-weight: var(--font-weight-bold);
      color: var(--text-tertiary);
      text-transform: uppercase;
      letter-spacing: 0.04em;
      margin-bottom: 2px;
    }

    .tool-code {
      font-family: var(--font-mono);
      font-size: var(--font-size-xs);
      padding: 6px 8px;
      background: var(--bg-code);
      border-radius: var(--radius-xs);
      white-space: pre-wrap;
      word-break: break-all;
      overflow-x: auto;
      max-height: 200px;
      overflow-y: auto;
      color: var(--text-primary);
      line-height: 1.4;
    }

    /* --- card body ------------------------------------------------------- */

    .card-body {
      padding: 10px 12px;
      overflow: auto;
      user-select: text;
      cursor: auto;
    }

    .card-body.no-scroll {
      overflow: hidden;
      display: flex;
      flex-direction: column;
      box-sizing: border-box;
    }

    .resize-grip {
      height: 6px;
      cursor: ns-resize;
      background: var(--bg-tertiary);
      display: flex;
      align-items: center;
      justify-content: center;
      user-select: none;
      flex-shrink: 0;
      transition: background var(--transition-fast);
    }

    .resize-grip:hover,
    .resize-grip.active {
      background: var(--accent-primary);
    }

    .resize-grip::after {
      content: "";
      display: block;
      width: 32px;
      height: 2px;
      border-radius: 1px;
      background: var(--text-tertiary);
      opacity: 0.5;
    }

    .resize-grip:hover::after,
    .resize-grip.active::after {
      background: var(--bg-primary);
      opacity: 0.8;
    }

    .placeholder {
      flex: 1;
      display: flex;
      align-items: center;
      justify-content: center;
      color: var(--text-tertiary);
      font-size: var(--font-size-sm);
      font-family: var(--font-sans);
      padding: 16px;
      text-align: center;
      user-select: none;
    }

    .card-loading {
      display: flex;
      align-items: center;
      justify-content: center;
      gap: 8px;
      padding: 24px 12px;
      color: var(--text-tertiary);
      font-size: var(--font-size-sm);
      font-family: var(--font-sans);
    }

    .card-loading-dot {
      width: 6px;
      height: 6px;
      border-radius: 50%;
      background: var(--text-tertiary);
      animation: loadPulse 1.2s ease-in-out infinite;
    }

    .card-loading-dot:nth-child(2) {
      animation-delay: 0.15s;
    }

    .card-loading-dot:nth-child(3) {
      animation-delay: 0.3s;
    }

    @keyframes loadPulse {
      0%,
      80%,
      100% {
        opacity: 0.25;
        transform: scale(0.8);
      }
      40% {
        opacity: 1;
        transform: scale(1);
      }
    }
  `;_t.DEFAULT_CARD_HEIGHT=400;_t.MIN_CARD_HEIGHT=80;Ie([L()],_t.prototype,"cards",2);Ie([L()],_t.prototype,"expandedToolStrips",2);Ie([L()],_t.prototype,"rerunningCards",2);Ie([L()],_t.prototype,"copiedCards",2);Ie([L()],_t.prototype,"searchOpen",2);Ie([L()],_t.prototype,"searchState",2);_t=Ie([st("detail-pane")],_t);
