#
#  Copyright 2026 by C Change Labs Inc. www.c-change-labs.com
#
#  Licensed under the Apache License, Version 2.0 (the "License");
#  you may not use this file except in compliance with the License.
#  You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
#  Unless required by applicable law or agreed to in writing, software
#  distributed under the License is distributed on an "AS IS" BASIS,
#  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
#  See the License for the specific language governing permissions and
#  limitations under the License.
#
import pydantic

from openepd.model.base import BaseOpenEpdSchema
from openepd.model.category import CategoryMeta
from openepd.model.common import Amount
from openepd.model.specs.base import BaseOpenEpdHierarchicalSpec
from openepd.model.specs.enums import (
    FlatGlassPanesThickness,
    FrameMaterial,
    HardwareFunction,
    NAFSPerformanceGrade,
    Spacer,
    ThermalSeparation,
)
from openepd.model.validation.quantity import (
    LengthMmStr,
    PressureMPaStr,
    SpeedStr,
    UFactorStr,
    validate_quantity_unit_factory,
)


class GlazingIntendedApplication(BaseOpenEpdSchema):
    """Glass intended application mixin."""

    curtain_wall: bool | None = pydantic.Field(
        default=None, description="Intended for curtain walls. Relevant for IGUs."
    )
    r_windows: bool | None = pydantic.Field(
        default=None,
        description="Intended for residential (NAFS 'R') and similar windows, doors, or skylights. Relevant for IGUs.",
    )
    lc_windows: bool | None = pydantic.Field(
        default=None,
        description="Intended for light commercial (NAFS 'LC') and similar windows. Relevant for IGUs.",
    )
    cw_windows: bool | None = pydantic.Field(
        default=None,
        description="Intended for commercial (NAFS 'CW') and similar windows. Relevant for IGUs.",
    )
    aw_windows: bool | None = pydantic.Field(
        default=None,
        description="Intended for architectural (NAFS 'AW') and similar windows. Relevant for IGUs.",
    )
    storefronts: bool | None = pydantic.Field(
        default=None,
        description="Intended for Storefronts and similar applications. Relevant for IGUs.",
    )
    glazed_doors: bool | None = pydantic.Field(
        default=None,
        description="Intended for Glazed Doors and similar applications. Relevant for IGUs.",
    )
    unit_skylights: bool | None = pydantic.Field(
        default=None,
        description="Intended for Unit Skylights and similar applications. Relevant for IGUs.",
    )
    sloped_skylights: bool | None = pydantic.Field(
        default=None,
        description="Intended for sloped glazing, and architectural skylights, and similar. Relevant for IGUs.",
    )
    other: bool | None = pydantic.Field(
        default=None,
        description="Intended for other application not listed. Relevant for IGUs.",
    )


class GlazingOptionsMixin(BaseOpenEpdSchema):
    """Common glazing options."""

    low_emissivity: bool | None = pydantic.Field(
        default=None,
        description="Low Emissivity coatings",
        examples=[True],
    )
    electrochromic: bool | None = pydantic.Field(
        default=None,
        description="Glazing with an electrically controllable solar heat gain and/or other properties.",
        examples=[True],
    )
    acid_etched: bool | None = pydantic.Field(
        default=None,
        description="Flat glass that has undergone a chemical etching process.",
        examples=[True],
    )
    tempered: bool | None = pydantic.Field(
        default=None,
        description="Consists of a single pane that has been heat-treated to give the glass increased impact "
        "resistance. Standard typically used in North America.",
        examples=[True],
    )
    toughened: bool | None = pydantic.Field(
        default=None,
        description="Consists of a single pane that has been specially heat-treated to give the glass increased impact "
        "resistance. Standard typically used in Europe.",
        examples=[True],
    )
    laminated: bool | None = pydantic.Field(
        default=None,
        description="Consists of at least two glass panes lying one on top of the other, with one or several layers of "
        "a tear-resistant, viscoelastic film positioned between the panes, which consist of polyvinyl "
        "butyral (PVB)",
        examples=[True],
    )
    fire_resistant: bool | None = pydantic.Field(
        default=None,
        examples=[True],
    )
    fire_protection: bool | None = pydantic.Field(
        default=None,
        description="Specifically tested for its ability to block flames and smoke, but not radiant heat. Ranges from"
        " specialty tempered products rated for ~20 minutes to glass ceramics rated up to 3 hours.",
        examples=[True],
    )
    pyrolytic_coated: bool | None = pydantic.Field(
        default=None,
        description="At least one coating is applied in a pyrolytic process, typically during float glass production.",
        examples=[True],
    )
    sputter_coat: bool | None = pydantic.Field(
        default=None,
        description="At least one coating is applied using sputter (vacuum deposition) coating.",
        examples=[True],
    )
    solar_heat_gain: float | None = pydantic.Field(
        default=None,
        description="Solar heat gain, measured at a certain level of Differential Pressure. Range is 0 to 1.",
        examples=[0.5],
        ge=0,
        le=1,
    )


class PanelDoorsV1(BaseOpenEpdHierarchicalSpec):
    """Panel doors performance specification."""

    _EXT_VERSION = "1.0"
    _CATEGORY_META = CategoryMeta(
        unique_name="PanelDoors",
        display_name="Panel Doors",
        historical_names=[
            "Openings >> Doors and Frames >> Specialty Doors and Frames >> Special Function Doors >> Panel Doors"
        ],
        description="A panel door consists of stiles and rails framing inset panels that accommodate movement and ensure structural stability.",
        masterformat="08 36 00 Panel Doors",
        declared_unit=Amount(qty=1, unit="item"),
    )


class PressureResistantDoorsV1(BaseOpenEpdHierarchicalSpec):
    """Pressure-Resistant Doors."""

    _EXT_VERSION = "1.0"
    _CATEGORY_META = CategoryMeta(
        unique_name="PressureResistantDoors",
        display_name="Pressure-Resistant Doors",
        historical_names=[
            "Openings >> Doors and Frames >> Specialty Doors and Frames >> Special Function Doors >> Pressure-Resistant Doors"
        ],
        description="Pressure-resistant doors.",
        masterformat="08 39 00 Pressure-Resistant Doors",
        declared_unit=Amount(qty=1, unit="item"),
    )


class SpecialFunctionDoorsV1(BaseOpenEpdHierarchicalSpec):
    """
    Special function doors.

    Includes doors for e.g., cold storage, hangars, lightproof applications,
    security, sound control, vaults, etc.
    """

    _EXT_VERSION = "1.0"
    _CATEGORY_META = CategoryMeta(
        unique_name="SpecialFunctionDoors",
        display_name="Special Function Doors",
        historical_names=["Openings >> Doors and Frames >> Specialty Doors and Frames >> Special Function Doors"],
        description="Special function doors, including doors for e.g., cold storage, hangars, lightproof applications, security, sound control, vaults, etc.",
        masterformat="08 34 00 Special Function Doors",
        declared_unit=Amount(qty=1, unit="item"),
    )

    # Nested specs:
    PanelDoors: PanelDoorsV1 | None = None
    PressureResistantDoors: PressureResistantDoorsV1 | None = None


class SlidingGlassDoorsV1(BaseOpenEpdHierarchicalSpec):
    """Sliding glass doors performance specification."""

    _EXT_VERSION = "1.0"
    _CATEGORY_META = CategoryMeta(
        unique_name="SlidingGlassDoors",
        display_name="Sliding Glass Doors",
        historical_names=["Openings >> Doors and Frames >> Specialty Doors and Frames >> Sliding Glass Doors"],
        description="Sliding glass doors",
        masterformat="08 32 00 Sliding Glass Doors",
        declared_unit=Amount(qty=1, unit="item"),
    )


class FenestrationAccessoriesV1(BaseOpenEpdHierarchicalSpec):
    """
    Fenestration accessories.

    Gaskets, seals, fasteners, and other low-mass items which may be useful in calculating the impact of a
    fenestration system.
    """

    _EXT_VERSION = "1.0"
    _CATEGORY_META = CategoryMeta(
        unique_name="FenestrationAccessories",
        display_name="Fenestration Accessories",
        short_name="Accessories",
        historical_names=["Openings >> Glazing >> Parts >> Accessories"],
        description="Gaskets, seals, fasteners, and other low-mass items which may be useful in calculating the impact of a fenestration system.",
        masterformat="08 85 00 Glazing Accessories",
    )


class FenestrationFramingV1(BaseOpenEpdHierarchicalSpec):
    """
    Fenestration Framing.

    Lineal elements ("sticks") for use in fenestration, including frames, sashes, and mullions.
    """

    _EXT_VERSION = "1.0"
    _CATEGORY_META = CategoryMeta(
        unique_name="FenestrationFraming",
        display_name="Fenestration Framing",
        short_name="Framing",
        historical_names=["Openings >> Glazing >> Parts >> Framing"],
        description='Lineal elements ("sticks") for use in fenestration, including frames, sashes, and mullions.',
        masterformat="08 80 00 Glazing",
        declared_unit=Amount(qty=1, unit="kg"),
    )

    # Own fields:
    thermal_separation: ThermalSeparation | None = pydantic.Field(default=None, examples=["Aluminium"])
    material: FrameMaterial | None = pydantic.Field(default=None, examples=["Vinyl"])


class FenestrationHardwareV1(BaseOpenEpdHierarchicalSpec):
    """Locks, operation hardware, and other substantial items declared on a per-piece basis."""

    _EXT_VERSION = "1.0"
    _CATEGORY_META = CategoryMeta(
        unique_name="FenestrationHardware",
        display_name="Fenestration Hardware",
        short_name="Hardware",
        historical_names=["Openings >> Glazing >> Parts >> Hardware"],
        description="Locks, operation hardware, and other substantial items declared on a per-piece basis.",
        masterformat="08 75 00 Window Hardware",
        declared_unit=Amount(qty=1, unit="item"),
    )

    # Own fields:
    function: HardwareFunction | None = pydantic.Field(default=None, description="", examples=["Lock"])


class FlatGlassPanesV1(BaseOpenEpdHierarchicalSpec):
    """Monolithic, uncoated flat glass panes that are not substantially processed."""

    _EXT_VERSION = "1.0"
    _CATEGORY_META = CategoryMeta(
        unique_name="FlatGlassPanes",
        display_name="Flat Glass Panes",
        short_name="Flat Glass",
        alt_names=["Float glass", "Uncoated float glass", "Soda lime silicate glass"],
        historical_names=["Openings >> Glazing >> Panes >> Flat Glass"],
        description="Monolithic, uncoated flat glass panes that are not substantially processed.",
        masterformat="08 81 00 Glass Glazing",
        declared_unit=Amount(qty=1, unit="kg"),
    )

    # Own fields:
    thickness: FlatGlassPanesThickness | None = pydantic.Field(default=None, examples=["12 mm"])

    @pydantic.field_validator("thickness")
    def _flat_glass_panes_thickness_is_quantity_validator(cls, v):
        return validate_quantity_unit_factory("m")(cls, v)


class ProcessedNonInsulatingGlassPanesV1(BaseOpenEpdHierarchicalSpec, GlazingOptionsMixin):
    """
    Solid glass panes without internal gaps which have been heat-treated or otherwise substantially processed.

    Includes:
    1. Coatings including low-e and other coatings (see PCR)
    2. laminating (fire-rated, glass clad polycarbonate, interlayers
    3. Heat treated (heat strengthened, tempered, fire-rated)
    4. Mechanically or chemically processed or fabricated
    (edging, bending, etching, drilling, notching, cutting, polishing, etc)
    5. combined products of processing in 1-5.
    """

    _EXT_VERSION = "1.0"
    _CATEGORY_META = CategoryMeta(
        unique_name="ProcessedNonInsulatingGlassPanes",
        display_name="Processed Non-insulating Glass Panes",
        short_name="Processed Glass",
        alt_names=["Tempered glass", "Safety glass", "Coated float glass", "Laminated glass"],
        historical_names=["Openings >> Glazing >> Panes >> Processed Glass"],
        description="Solid glass panes without internal gaps which have been heat-treated or otherwise substantially processed. Includes:\n1. Coatings including low-e and other coatings (see PCR)\n2. laminating (fire-rated, glass clad polycarbonate, interlayers\n3. Heat treated (heat strengthened, tempered, fire-rated)\n4. Mechanically or chemically processed or fabricated (edging, bending, etching, drilling, notching, cutting, polishing, etc)\n5. combined products of processing in 1-5.",
        masterformat="08 81 00 Glass Glazing",
        declared_unit=Amount(qty=1, unit="m^2"),
    )


class GlazedDoorsV1(BaseOpenEpdHierarchicalSpec):
    """
    Factory assembled door which is at least 50% glass by area.

    Includes sliding patio doors and hinged doors.
    """

    _EXT_VERSION = "1.0"
    _CATEGORY_META = CategoryMeta(
        unique_name="GlazedDoors",
        display_name="Glazed Doors",
        historical_names=["Openings >> Glazing >> NAFS Fenestration >> Glazed Doors"],
        description="Factory assembled door which is at least 50% glass by area. Includes sliding patio doors and hinged glass doors.",
        masterformat="08 30 00 Specialty Doors and Frames",
        declared_unit=Amount(qty=1, unit="m^2"),
    )


class UnitSkylightsV1(BaseOpenEpdHierarchicalSpec):
    """
    Unit skylights performance specification.

    A factory assembled fenestration unit for installation on the roof of a structure to provide interior
    building spaces with natural daylight, warmth, and ventilation; generally not operable
    by hand (cf. roof window). Includes frame(s) and possibly operating hardware.
    """

    _EXT_VERSION = "1.1"
    _CATEGORY_META = CategoryMeta(
        unique_name="UnitSkylights",
        display_name="Unit Skylights",
        historical_names=["Openings >> Glazing >> NAFS Fenestration >> Unit Skylights"],
        description="A factory assembled fenestration unit for installation on the roof of a structure to provide interior building spaces with natural daylight, warmth, and ventilation; generally not operable by hand (cf. roof window). Includes frame(s) and possibly operating hardware.",
        masterformat="08 62 00 Unit Skylights",
        declared_unit=Amount(qty=1, unit="m^2"),
    )

    roof_window: bool | None = pydantic.Field(
        default=None,
        description=(
            "Similar to a skylight but has an outward opening that extends from a roof, and is therefore not fixed"
        ),
        examples=[True],
    )


class WindowsV1(BaseOpenEpdHierarchicalSpec):
    """Windows including glazing and frame material."""

    _EXT_VERSION = "1.0"
    _CATEGORY_META = CategoryMeta(
        unique_name="Windows",
        display_name="Windows",
        historical_names=["Openings >> Glazing >> NAFS Fenestration >> Windows"],
        description="Factory assembled window with frame(s), one or more IGUs or glass panes, and possibly operating hardware. Includes fixed and operable windows.",
        masterformat="08 50 00 Windows",
        declared_unit=Amount(qty=1, unit="m^2"),
    )


class IntegratedDoorsOpeningAssembliesV1(BaseOpenEpdHierarchicalSpec):
    """Pre-installed unit that includes door, frame, and hardware."""

    _EXT_VERSION = "1.0"
    _CATEGORY_META = CategoryMeta(
        unique_name="IntegratedDoorsOpeningAssemblies",
        display_name="Integrated Door Opening Assemblies",
        historical_names=["Openings >> Doors and Frames >> Integrated Door Opening Assemblies"],
        description="Pre-installed unit that includes door, frame, and hardware",
        masterformat="08 17 00 Integrated Door Opening Assemblies",
        declared_unit=Amount(qty=1, unit="item"),
    )


class MetalDoorAndFramesV1(BaseOpenEpdHierarchicalSpec):
    """Metal doors and frames."""

    _EXT_VERSION = "1.0"
    _CATEGORY_META = CategoryMeta(
        unique_name="MetalDoorAndFrames",
        display_name="Metal Doors and Frames",
        historical_names=["Openings >> Doors and Frames >> Metal Doors and Frames"],
        description="Metal doors and frames",
        masterformat="08 11 00 Metal Doors and Frames",
        declared_unit=Amount(qty=1, unit="item"),
    )


class SpecialtyDoorsAndFramesV1(BaseOpenEpdHierarchicalSpec):
    """
    Specialty doors and frames.

    Includes e.g., access doors and panels, sliding glass doors, coiling doors, special function doors,
    folding doors, etc.
    """

    _EXT_VERSION = "1.0"
    _CATEGORY_META = CategoryMeta(
        unique_name="SpecialtyDoorsAndFrames",
        display_name="Specialty Doors and Frames",
        historical_names=["Openings >> Doors and Frames >> Specialty Doors and Frames"],
        description="Specialty doors and frames, including e.g., access doors and panels, sliding glass doors, coiling doors, special function doors, folding doors, etc.",
        masterformat="08 30 00 Specialty Doors and Frames",
        declared_unit=Amount(qty=1, unit="item"),
    )

    # Nested specs:
    SpecialFunctionDoors: SpecialFunctionDoorsV1 | None = None
    SlidingGlassDoors: SlidingGlassDoorsV1 | None = None


class WoodDoorsV1(BaseOpenEpdHierarchicalSpec):
    """Wood doors performance specification."""

    _EXT_VERSION = "1.0"
    _CATEGORY_META = CategoryMeta(
        unique_name="WoodDoors",
        display_name="Wood Doors",
        historical_names=["Openings >> Doors and Frames >> Wood Doors"],
        description="Wood doors",
        masterformat="08 14 00 Wood Doors",
        declared_unit=Amount(qty=1, unit="item"),
    )


class FenestrationPartsV1(BaseOpenEpdHierarchicalSpec):
    """
    Fenestration Parts.

    Parts and assemblies for integration into building fenestration such as windows, curtain walls,
    and storefronts.
    """

    _EXT_VERSION = "1.0"
    _CATEGORY_META = CategoryMeta(
        unique_name="FenestrationParts",
        display_name="Fenestration Parts",
        short_name="Parts",
        historical_names=["Openings >> Glazing >> Parts"],
        description="Parts and assemblies for integration into building fenestration such as windows, curtain walls, and storefronts.",
        masterformat="08 80 00 Glazing",
    )

    # Own fields:
    intended_application: GlazingIntendedApplication | None = pydantic.Field(
        default=None, description="Intended application."
    )

    # Nested specs:
    FenestrationAccessories: FenestrationAccessoriesV1 | None = None
    FenestrationFraming: FenestrationFramingV1 | None = None
    FenestrationHardware: FenestrationHardwareV1 | None = None


class GlassPanesV1(BaseOpenEpdHierarchicalSpec):
    """Flat glass panes."""

    _EXT_VERSION = "1.0"
    _CATEGORY_META = CategoryMeta(
        unique_name="GlassPanes",
        display_name="Glass Panes",
        short_name="Panes",
        historical_names=["Openings >> Glazing >> Panes"],
        description="Flat glass panes",
        masterformat="08 80 00 Glazing",
    )

    # Nested specs:
    FlatGlassPanes: FlatGlassPanesV1 | None = None
    ProcessedNonInsulatingGlassPanes: ProcessedNonInsulatingGlassPanesV1 | None = None


class NAFSPerformanceClass(BaseOpenEpdSchema):
    """NAFS Performance class."""

    r: bool | None = pydantic.Field(
        default=None,
        description="Residential; commonly used in one- and two-family dwellings.",
        examples=[True],
    )
    lc: bool | None = pydantic.Field(
        default=None,
        description="Light Commercial: commonly used in low-rise and mid-rise multi-family dwellings and other "
        "buildings where larger sizes and higher loading requirements are expected.",
        examples=[True],
    )
    cw: bool | None = pydantic.Field(
        default=None,
        description="Commercial Window: commonly used in low-rise and mid-rise buildings where larger sizes, higher "
        "loading requirements, limits on deflection, and heavy use are expected.",
        examples=[True],
    )
    aw: bool | None = pydantic.Field(
        default=None,
        description="Architectural Window: commonly used in high-rise and mid-rise buildings to meet increased "
        "loading requirements and limits on deflection, and in buildings where frequent and extreme use "
        "of the fenestration products is expected.",
        examples=[True],
    )


class NAFSFenestrationV1(BaseOpenEpdHierarchicalSpec, GlazingOptionsMixin):
    """Factory assembled fenestration units compliant to the North American Fenestration Standard."""

    _EXT_VERSION = "1.0"
    _CATEGORY_META = CategoryMeta(
        unique_name="NAFSFenestration",
        display_name="NAFS Fenestration",
        historical_names=["Openings >> Glazing >> NAFS Fenestration"],
        description="Factory assembled fenestration units compliant to the North American Fenestration Standard.",
        masterformat="08 50 00 Windows",
        declared_unit=Amount(qty=1, unit="m^2"),
    )

    # Own fields:
    hurricane_resistant: bool | None = pydantic.Field(
        default=None,
        description="The product has been designed to resist windborne debris.",
        examples=[True],
    )

    assembly_u_factor: UFactorStr | None = pydantic.Field(
        default=None,
        description="Weighted average conductance of heat across assembly (including frame).",
        examples=["1 USI"],
    )
    air_infiltration: SpeedStr | None = pydantic.Field(
        default=None,
        description="Air infiltration, measured at a certain level of Differential Pressure.",
        examples=["1 m3 / m2 / s"],
    )

    thermal_separation: ThermalSeparation | None = pydantic.Field(default=None, examples=["Aluminium"])
    dp_rating: PressureMPaStr | None = pydantic.Field(default=None, description="", examples=["1 MPa"])
    glass_panes: int | None = pydantic.Field(
        default=None,
        description="Number of panes, each separated by a cavity. A 3 pane unit has 2 cavities. example: 3",
        examples=[3],
    )

    performance_class: NAFSPerformanceClass | None = pydantic.Field(
        default=None, description="Performance class according to NAFS."
    )

    performance_grade: NAFSPerformanceGrade | None = pydantic.Field(
        default=None,
        description="NAFS Performance Grade. The NAFS Performance Grade is a number that represents the performance "
        "of the glazing product. The higher the number, the better the performance. The NAFS Performance "
        "Grade is calculated using the NAFS Performance Class, the NAFS Performance Index, and the NAFS "
        "Performance Factor. While it is expressed as pressure, there are specific values which are "
        "allowed. The values are listed in the enum.",
        examples=["95 psf"],
    )

    @pydantic.field_validator("assembly_u_factor")
    def _assembly_u_factor_is_quantity_validator(cls, v):
        return validate_quantity_unit_factory("USI")(cls, v)

    @pydantic.field_validator("performance_grade")
    def _nafs_performance_grade_is_quantity_validator(cls, v):
        return validate_quantity_unit_factory("psf")(cls, v)

    # Nested specs:
    GlazedDoors: GlazedDoorsV1 | None = None
    UnitSkylights: UnitSkylightsV1 | None = None
    Windows: WindowsV1 | None = None


class InsulatingGlazingUnitsV1(BaseOpenEpdHierarchicalSpec, GlazingOptionsMixin):
    """Insulating glazing units performance specification."""

    _EXT_VERSION = "1.0"
    _CATEGORY_META = CategoryMeta(
        unique_name="InsulatingGlazingUnits",
        display_name="Insulating Glazing Units",
        short_name="IGUs",
        alt_names=["Insulated Glazing Unit", "Integrated Glazing Unit"],
        historical_names=["Openings >> Glazing >> IGUs"],
        description="A factory-made unit of two or more panes of glass separated by a sealed insulating gap. IGUs often incorporate coated, laminated, or heat treated glass along with airspace, gas fill, seals, and spacers.",
        masterformat="08 81 23 Exterior Glass Glazing",
        declared_unit=Amount(qty=1, unit="m^2"),
    )

    # Own fields:
    intended_application: GlazingIntendedApplication | None = pydantic.Field(
        default=None, description="Intended application for IGUs."
    )

    hurricane_resistant: bool | None = pydantic.Field(
        default=None,
        examples=[True],
    )

    dp_rating: PressureMPaStr | None = pydantic.Field(
        default=None,
        description="Maximum Differential Pressure, a measure of wind tolerance.",
        examples=["1 MPa"],
    )
    air_infiltration: SpeedStr | None = pydantic.Field(
        default=None,
        description="Air infiltration, measured at a certain level of Differential Pressure.",
        examples=["1 m3 / m2 / s"],
    )
    glass_panes: int | None = pydantic.Field(
        default=None,
        description="Number of panes, each separated by a cavity. A 3 pane unit has 2 cavities. example: 3",
        examples=[3],
    )
    cog_u_factor: UFactorStr | None = pydantic.Field(
        default=None,
        description="Conductance of heat at center of glass.",
        examples=["1 USI"],
    )
    spacer: Spacer | None = pydantic.Field(
        default=None,
        description="Spacer material for Integrated Glass Unit.",
        examples=["Aluminium"],
    )

    @pydantic.field_validator("dp_rating")
    def _dp_rating_is_quantity_validator(cls, v):
        return validate_quantity_unit_factory("MPa")(cls, v)

    @pydantic.field_validator("cog_u_factor")
    def _cog_u_factor_is_quantity_validator(cls, v):
        return validate_quantity_unit_factory("USI")(cls, v)


class CurtainWallsV1(BaseOpenEpdHierarchicalSpec):
    """
    Curtain Walls.

    Exterior skin of building where walls are non-structural and are outboard of the floor slabs,
    often as system of aluminum framing with vision glass and opaque panels of glass, metal, or other
    materials.

    Can be 'unitized' (prefabricated off-site) or 'stick' (fabricated on site).
    """

    _EXT_VERSION = "1.0"
    _CATEGORY_META = CategoryMeta(
        unique_name="CurtainWalls",
        display_name="Curtain Walls",
        historical_names=["Openings >> Curtain Walls"],
        description="Exterior skin of building where walls are non-structural and are outboard of the floor slabs, often as system of aluminum framing with vision glass and opaque panels of glass, metal, or other materials, Can be 'unitized' (prefabricated off-site) or 'stick' (fabricated on site).",
        masterformat="08 44 00 Curtain Wall and Glazed Assemblies",
        declared_unit=Amount(qty=1, unit="m^2"),
    )


class DoorsAndFramesV1(BaseOpenEpdHierarchicalSpec):
    """Doors (the operable part) and frames (what holds the door proper)."""

    _EXT_VERSION = "1.0"
    _CATEGORY_META = CategoryMeta(
        unique_name="DoorsAndFrames",
        display_name="Doors and Frames",
        historical_names=["Openings >> Doors and Frames"],
        description="Doors (the operable part) and frames (what holds the door proper)",
        masterformat="08 10 00 Doors and Frames",
        declared_unit=Amount(qty=1, unit="item"),
    )

    # Own fields:
    height: LengthMmStr | None = pydantic.Field(default=None, examples=["1200 mm"])
    width: LengthMmStr | None = pydantic.Field(default=None, examples=["600 mm"])

    # Nested specs:
    IntegratedDoorsOpeningAssemblies: IntegratedDoorsOpeningAssembliesV1 | None = None
    MetalDoorAndFrames: MetalDoorAndFramesV1 | None = None
    SpecialtyDoorsAndFrames: SpecialtyDoorsAndFramesV1 | None = None
    WoodDoors: WoodDoorsV1 | None = None


class EntrancesV1(BaseOpenEpdHierarchicalSpec):
    """Building entrances (distinct from the door proper)."""

    _EXT_VERSION = "1.0"
    _CATEGORY_META = CategoryMeta(
        unique_name="Entrances",
        display_name="Entrances",
        description="Building entrances (distinct from the door proper)",
        masterformat="08 42 00 Entrances",
        declared_unit=Amount(qty=1, unit="m^2"),
    )


class GlazingV1(BaseOpenEpdHierarchicalSpec):
    """
    Glazing performance specification.

    Broad category of glass-based products, accessories, and assemblies ranging from
    glass panes and framing to curtain walls.
    """

    _EXT_VERSION = "1.0"
    _CATEGORY_META = CategoryMeta(
        unique_name="Glazing",
        display_name="Glazing",
        description="Broad category of glass-based products, accessories, and assemblies ranging from glass panes and framing to curtain walls.",
        masterformat="08 80 00 Glazing",
    )

    # Nested specs:
    FenestrationParts: FenestrationPartsV1 | None = None
    GlassPanes: GlassPanesV1 | None = None
    NAFSFenestration: NAFSFenestrationV1 | None = None
    InsulatingGlazingUnits: InsulatingGlazingUnitsV1 | None = None


class StorefrontsV1(BaseOpenEpdHierarchicalSpec):
    """
    Storefronts.

    Fabricated building facades commonly used in retail applications, typically one or two stories
    tall and using metal framing and glass.
    """

    _EXT_VERSION = "1.0"
    _CATEGORY_META = CategoryMeta(
        unique_name="Storefronts",
        display_name="Storefronts",
        description="Fabricated building facades commonly used in retail applications, typically one or two stories tall and using metal framing and glass",
        masterformat="08 43 00 Storefronts",
        declared_unit=Amount(qty=1, unit="m^2"),
    )


class TranslucentWallAndRoofAssembliesV1(BaseOpenEpdHierarchicalSpec):
    """
    Translucent wall and roof assemblies.

    Includes structured polycarbonate panel and fiberglass sandwich panel assemblies.
    """

    _EXT_VERSION = "1.0"
    _CATEGORY_META = CategoryMeta(
        unique_name="TranslucentWallAndRoofAssemblies",
        display_name="Translucent Wall and Roof Assemblies",
        historical_names=["Openings >> Translucent Wall and Roof Assemblies"],
        description="Translucent wall and roof assemblies, including structured polycarbonate panel and fiberglass sandwich panel assemblies",
        masterformat="08 45 00 Translucent Wall and Roof Assemblies",
        declared_unit=Amount(qty=1, unit="m^2"),
    )


class WindowWallAssembliesV1(BaseOpenEpdHierarchicalSpec):
    """
    Window Wall Assemblies.

    Exterior skin of building where walls are non-structural and sit between floor slabs, often as
    system of aluminum framing with vision glass and opaque panels of glass, metal,
    or other materials.
    """

    _EXT_VERSION = "1.0"
    _CATEGORY_META = CategoryMeta(
        unique_name="WindowWallAssemblies",
        display_name="Window Wall Assemblies",
        historical_names=["Openings >> Window Wall Assemblies"],
        description="Exterior skin of building where walls are non-structural and sit between floor slabs, often as system of aluminum framing with vision glass and opaque panels of glass, metal, or other materials",
        masterformat="08 46 00 Window Wall Assemblies",
        declared_unit=Amount(qty=1, unit="m^2"),
    )


class OpeningsV1(BaseOpenEpdHierarchicalSpec):
    """
    Openings performance specification.

    General category that includes windows, storefronts, window walls, curtain walls,
    doors, entrances, etc.
    """

    _EXT_VERSION = "1.0"
    _CATEGORY_META = CategoryMeta(
        unique_name="Openings",
        display_name="Openings",
        description="General category that includes windows, storefronts, window walls, curtain walls, doors, entrances, etc.",
        masterformat="08 00 00 Openings",
    )

    # Own fields:
    thickness: LengthMmStr | None = pydantic.Field(default=None, examples=["80 mm"])

    # Nested specs:
    CurtainWalls: CurtainWallsV1 | None = None
    DoorsAndFrames: DoorsAndFramesV1 | None = None
    Entrances: EntrancesV1 | None = None
    Glazing: GlazingV1 | None = None
    Storefronts: StorefrontsV1 | None = None
    TranslucentWallAndRoofAssemblies: TranslucentWallAndRoofAssembliesV1 | None = None
    WindowWallAssemblies: WindowWallAssembliesV1 | None = None
