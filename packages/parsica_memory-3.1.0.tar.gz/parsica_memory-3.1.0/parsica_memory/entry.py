"""Memory entry — the atomic unit of memory."""

import hashlib
from datetime import datetime
from typing import Dict, List, Optional


class MemoryEntry:
    """Single memory unit with metadata, decay, sentiment, and confidence.

    Sprint 2 additions
    ------------------
    memory_type : str
        One of "episodic", "fact", "preference", "procedure", "mistake"
        or any custom string.  Defaults to "episodic".
    type_metadata : dict
        Type-specific structured data.  For mistakes this holds
        {"what_happened": ..., "correction": ..., "root_cause": ..., "severity": ...}.
        Empty for other types unless the caller populates it.
    """

    __slots__ = (
        "content", "source", "line", "category", "created",
        "last_accessed", "access_count", "importance", "confidence",
        "sentiment", "tags", "related", "hash",
        # Sprint 2
        "memory_type", "type_metadata",
        # v4.1: session isolation
        "session_id",
        # v4.2.1: agent scoping
        "agent_id",
        # v4.6.5: LLM enrichment
        "enriched_summary", "search_keywords",
        # v5.0.2: doc2query — LLM-generated search queries this memory answers
        "search_queries",
        # v4.7.0: knowledge ingestion provenance
        "source_url", "content_hash",
        # v5.3: fact decomposition provenance
        "provenance", "parent_hash",
        # v5.3.1: fuzzy dedup sighting tracking
        "sighting_count", "last_sighted",
        # v2.3.0: cross-channel recency recall
        "source_channel",
    )

    def __init__(
        self,
        content: str,
        source: str = "",
        line: int = 0,
        category: str = "general",
        created: str = None,
        memory_type: str = "episodic",
        session_id: str = "",
        agent_id: str = "",
        source_channel: str = "",
        **kwargs,  # absorb channel_id and future fields gracefully
    ):
        self.content = content
        self.source = source
        self.line = line
        self.category = category
        self.created = created or datetime.now().isoformat()
        self.last_accessed = self.created
        self.access_count: int = 0
        self.importance: float = 1.0
        self.confidence: float = 0.5
        self.sentiment: Dict[str, float] = {}
        self.tags: List[str] = []
        self.related: List[str] = []
        self.hash = hashlib.md5(
            f"{source}:{line}:{content}".encode()
        ).hexdigest()[:12]
        # Sprint 2
        self.memory_type: str = memory_type
        self.type_metadata: Dict = {}
        # v4.1: session isolation
        self.session_id: str = session_id
        # v4.2.1: agent scoping
        self.agent_id: str = agent_id
        # v4.6.5: LLM enrichment
        self.enriched_summary: str = ""
        self.search_keywords: List[str] = []
        self.search_queries: List[str] = []  # v5.0.2: doc2query
        # v4.7.0: knowledge ingestion provenance
        self.source_url: Optional[str] = None
        self.content_hash: Optional[str] = None
        # v5.3: fact decomposition provenance
        self.provenance: str = "self"
        self.parent_hash: str = ""
        # v5.3.1: fuzzy dedup sighting tracking
        self.sighting_count: int = 0
        self.last_sighted: str = ""
        # v2.3.0: cross-channel recency recall
        self.source_channel: str = source_channel

    # -- serialisation --------------------------------------------------------

    def to_dict(self) -> Dict:
        d = {
            "hash": self.hash,
            "content": self.content,
            "source": self.source,
            "line": self.line,
            "category": self.category,
            "created": self.created,
            "last_accessed": self.last_accessed,
            "access_count": self.access_count,
            "importance": round(self.importance, 4),
            "confidence": round(self.confidence, 4),
            "sentiment": self.sentiment,
            "tags": self.tags,
            "related": self.related,
        }
        # Sprint 2 — only write if non-default to keep file size stable
        if self.memory_type and self.memory_type != "episodic":
            d["memory_type"] = self.memory_type
        if self.type_metadata:
            d["type_metadata"] = self.type_metadata
        # v4.1: session_id — only write if set
        if self.session_id:
            d["session_id"] = self.session_id
        # v4.2.1: agent_id — only write if set
        if self.agent_id:
            d["agent_id"] = self.agent_id
        # v4.6.5: LLM enrichment — only write if present
        if self.enriched_summary:
            d["enriched_summary"] = self.enriched_summary
        if self.search_keywords:
            d["search_keywords"] = self.search_keywords
        if self.search_queries:
            d["search_queries"] = self.search_queries
        # v4.7.0: knowledge ingestion provenance
        if self.source_url is not None:
            d["source_url"] = self.source_url
        if self.content_hash is not None:
            d["content_hash"] = self.content_hash
        # v5.3: fact decomposition provenance — only write if non-default
        if self.provenance and self.provenance != "self":
            d["provenance"] = self.provenance
        if self.parent_hash:
            d["parent_hash"] = self.parent_hash
        # v5.3.1: fuzzy dedup sighting tracking — only write if non-zero/non-empty
        if self.sighting_count > 0:
            d["sighting_count"] = self.sighting_count
        if self.last_sighted:
            d["last_sighted"] = self.last_sighted
        # v2.3.0: cross-channel recency recall — only write if set
        if self.source_channel:
            d["source_channel"] = self.source_channel
        return d

    @classmethod
    def from_dict(cls, d: Dict) -> "MemoryEntry":
        m = cls(
            d["content"], d.get("source", ""), d.get("line", 0),
            d.get("category", "general"), d.get("created"),
            memory_type=d.get("memory_type", "episodic"),
        )
        m.last_accessed = d.get("last_accessed", m.created)
        m.access_count = d.get("access_count", 0)
        m.importance = d.get("importance", 1.0)
        m.confidence = d.get("confidence", 0.5)
        m.sentiment = d.get("sentiment", {})
        m.tags = d.get("tags", [])
        m.related = d.get("related", [])
        m.hash = d.get("hash", m.hash)
        m.type_metadata = d.get("type_metadata", {})
        # v4.1: session_id
        m.session_id = d.get("session_id", "")
        # v4.2.1: agent_id
        m.agent_id = d.get("agent_id", "")
        # v4.6.5: LLM enrichment
        m.enriched_summary = d.get("enriched_summary", "")
        m.search_keywords = d.get("search_keywords", [])
        m.search_queries = d.get("search_queries", [])
        # v4.7.0: knowledge ingestion provenance
        m.source_url = d.get("source_url")
        m.content_hash = d.get("content_hash")
        # v5.3: fact decomposition provenance
        m.provenance = d.get("provenance", "self")
        m.parent_hash = d.get("parent_hash", "")
        # v5.3.1: fuzzy dedup sighting tracking
        m.sighting_count = d.get("sighting_count", 0)
        m.last_sighted = d.get("last_sighted", "")
        # v2.3.0: cross-channel recency recall
        m.source_channel = d.get("source_channel", "")
        return m

    def __repr__(self) -> str:
        return (
            f"<Memory {self.hash} type={self.memory_type} "
            f"score={self.importance:.2f} conf={self.confidence:.2f}>"
        )
