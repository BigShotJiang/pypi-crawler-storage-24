"""
Query expansion via synonym map for parsica-memory v4.5.0.

Expands query terms to their synonyms before BM25 scoring so that
"how much are we spending?" also matches memories containing
"cost", "budget", "price", "expense", etc.

Zero external dependencies — stdlib only.
"""

import re
from typing import List, Dict, Set


# ---------------------------------------------------------------------------
# Synonym groups — each group is a frozenset of interchangeable terms.
# The build_synonym_map() helper turns this into a bidirectional dict at
# import time so look-up is O(1).
# ---------------------------------------------------------------------------

_SYNONYM_GROUPS: List[Set[str]] = [
    # 0 — Financial / money
    {"spending", "cost", "budget", "expense", "price", "payment",
     "fee", "bill", "charge", "invoice", "subscription", "pay",
     "pricing", "rate", "expenditure", "outlay", "revenue", "income",
     "money", "cash", "fund"},

    # 1 — Medical / health
    {"medical", "health", "doctor", "dentist", "appointment",
     "checkup", "prescription", "clinic", "hospital", "physician",
     "nurse", "therapy", "treatment", "diagnosis", "medication",
     "symptom", "wellness"},

    # 2 — Technical infrastructure
    {"server", "infrastructure", "api", "endpoint", "backend",
     "cloud", "deployment", "service", "instance", "node",
     "cluster", "container", "kubernetes", "docker", "microservice",
     "platform", "environment", "infrastructure"},

    # 3 — Meeting / scheduling
    {"meeting", "schedule", "calendar", "session", "call",
     "standup", "sync", "event", "appointment", "conference",
     "discussion", "agenda", "recap", "review"},

    # 4 — Security / vulnerabilities
    {"vulnerability", "bug", "issue", "threat", "risk",
     "exploit", "patch", "cve", "security", "attack",
     "breach", "flaw", "weakness", "exposure", "incident",
     "pentest", "audit"},

    # 5 — Travel
    {"travel", "flight", "trip", "journey", "hotel",
     "booking", "itinerary", "accommodation", "ticket",
     "departure", "arrival", "destination", "passport",
     "visa", "airline", "reservation"},

    # 6 — Incident / outage
    {"incident", "outage", "downtime", "failure", "crash",
     "error", "problem", "disruption", "degradation",
     "postmortem", "alert", "alarm", "pagerduty", "oncall"},

    # 7 — Team / people
    {"team", "colleague", "coworker", "member", "staff",
     "employee", "worker", "person", "collaborator",
     "teammate", "associate", "partner", "hire", "headcount"},

    # 8 — Personal preferences
    {"preference", "want", "like", "prefer", "enjoy",
     "favorite", "favourite", "wish", "desire", "interest",
     "hobby", "passion", "choice"},

    # 9 — Project management
    {"project", "task", "ticket", "story", "epic",
     "milestone", "sprint", "backlog", "jira", "linear",
     "roadmap", "deliverable", "objective", "goal"},

    # 10 — Authentication / access
    {"login", "password", "credential", "auth", "authentication",
     "authorization", "token", "key", "secret", "access",
     "permission", "sso", "oauth", "2fa", "mfa"},

    # 11 — Database
    {"database", "db", "query", "sql", "table",
     "schema", "record", "row", "column", "index",
     "migration", "postgres", "mysql", "mongo", "redis"},

    # 12 — Code / development
    {"code", "repository", "repo", "branch", "commit",
     "pull", "push", "merge", "pr", "review",
     "diff", "patch", "release", "version", "changelog"},

    # 13 — Configuration / settings
    {"config", "configuration", "setting", "option",
     "parameter", "flag", "env", "environment", "variable",
     "yaml", "json", "toml", "dotenv"},

    # 14 — Communication / messaging
    {"message", "email", "slack", "discord", "notification",
     "alert", "chat", "dm", "thread", "ping", "mention"},

    # 15 — Performance / metrics
    {"performance", "latency", "throughput", "metric",
     "benchmark", "profiling", "memory", "cpu", "load",
     "response", "speed", "slow", "fast", "optimize"},

    # 16 — Analytics / data
    {"analytics", "data", "report", "dashboard", "chart",
     "graph", "visualization", "insight", "trend", "statistic",
     "kpi", "metric", "segment"},

    # 17 — Customer / user
    {"customer", "client", "user", "account", "subscriber",
     "member", "consumer", "prospect", "lead", "tenant"},

    # 18 — Support / help
    {"support", "help", "assist", "ticket", "issue",
     "question", "request", "inquiry", "complaint", "feedback",
     "resolution", "fix", "workaround", "escalation"},

    # 19 — Document / file
    {"document", "file", "attachment", "pdf", "spreadsheet",
     "doc", "sheet", "note", "wiki", "page", "article",
     "readme", "specification", "spec"},

    # 20 — Plan / strategy
    {"plan", "strategy", "initiative", "proposal", "approach",
     "design", "architecture", "blueprint", "roadmap", "vision"},

    # 21 — Review / approval
    {"review", "approve", "approval", "sign-off", "signoff",
     "feedback", "comment", "lgtm", "accept", "reject",
     "decision", "vote"},

    # 22 — Time / deadline
    {"deadline", "due", "eta", "timeline", "date",
     "time", "schedule", "target", "milestone", "duedate"},

    # 23 — Test / QA
    {"test", "testing", "qa", "quality", "assurance",
     "unittest", "integration", "regression", "coverage",
     "staging", "sandbox", "validation"},

    # 24 — Logging / debugging
    {"log", "logging", "debug", "trace", "stacktrace",
     "exception", "error", "warning", "crash", "core-dump"},

    # 25 — Networking
    {"network", "dns", "ip", "subnet", "firewall",
     "vpn", "proxy", "load-balancer", "cdn", "ssl",
     "tls", "certificate", "domain", "hostname"},

    # 26 — Storage / backup
    {"storage", "disk", "backup", "restore", "snapshot",
     "archive", "bucket", "s3", "blob", "volume",
     "filesystem", "mount"},

    # 27 — CI/CD pipeline
    {"pipeline", "cicd", "ci", "cd", "build",
     "deploy", "artifact", "github-actions", "jenkins",
     "workflow", "job", "run"},

    # 28 — Payment / billing (B2B)
    {"invoice", "billing", "payment", "receipt",
     "charge", "refund", "stripe", "subscription", "plan",
     "tier", "overage", "quota"},

    # 29 — Machine learning / AI
    {"model", "ml", "ai", "training", "inference",
     "prediction", "embedding", "llm", "prompt", "fine-tuning",
     "dataset", "label", "annotation"},

    # 30 — Onboarding / setup
    {"onboarding", "setup", "installation", "install",
     "configure", "initialization", "bootstrap", "provision",
     "wizard", "getting-started"},

    # 31 — Legal / compliance
    {"legal", "compliance", "gdpr", "privacy", "policy",
     "terms", "contract", "agreement", "regulation",
     "audit", "governance", "soc2"},

    # 32 — Sales / marketing
    {"sales", "marketing", "campaign", "lead", "funnel",
     "conversion", "acquisition", "churn", "retention",
     "outreach", "demo", "pitch"},

    # 33 — Notification / reminder
    {"notification", "reminder", "alert", "nudge", "ping",
     "prompt", "notice", "warning", "announcement"},

    # 34 — Feedback / survey
    {"feedback", "survey", "review", "rating", "nps",
     "satisfaction", "response", "opinion", "reaction"},

    # 35 — Colloquial error bridge
    {"wrong", "broken", "broke", "failed", "failing", "error", "exception",
     "fault", "malfunction", "messed", "screwed", "borked", "busted",
     "kaput", "fubar", "bad", "incorrect", "invalid"},

    # 36 — Colloquial slowness bridge
    {"slow", "slower", "slowness", "sluggish", "laggy", "lagging",
     "latency", "delay", "degradation", "regression", "bottleneck",
     "crawling", "choppy", "unresponsive", "timeout"},

    # 37 — Colloquial crash bridge
    {"crash", "crashed", "crashing", "died", "killed", "terminated",
     "oom", "segfault", "panic", "abort", "aborted", "down",
     "offline", "outage", "unavailable", "dead"},

    # 38 — Colloquial age/staleness bridge
    {"old", "older", "ancient", "stale", "outdated", "obsolete",
     "legacy", "deprecated", "expired", "aged", "previous",
     "former", "past", "historical", "archaic"},

    # 39 — Colloquial compression bridge
    {"compressed", "compress", "compression", "zip", "zipped",
     "gzip", "minify", "minified", "compact", "compacted",
     "deflate", "shrink", "shrunk", "squeeze", "condense"},

    # 40 — Colloquial working/functioning bridge
    {"working", "works", "functioning", "running", "operational",
     "active", "alive", "healthy", "up", "online", "responsive",
     "functional", "available"},

    # 41 — Colloquial stopped bridge
    {"stopped", "halted", "paused", "frozen", "stuck", "hung",
     "stalled", "blocked", "jammed", "locked", "deadlocked",
     "suspended", "interrupted"},

    # 42 — API group
    {"anomaly", "bug", "defect", "error", "fault", "flaw", "glitch", "incident", "issue", "problem", "regression", "ticket"},

    # 36 — group 36
    {"abort", "core dump", "crash", "exception", "failure", "fatal error", "panic", "runtime error", "segfault", "system error", "unhandled exception"},

    # 37 — group 37
    {"attack surface", "breach point", "cve", "exploit", "exposure", "loophole", "security flaw", "security hole", "vulnerability", "weakness", "zero-day"},

    # 38 — group 38
    {"bottleneck", "degraded", "high response time", "laggy", "latency", "poor throughput", "resource-bound", "slow", "sluggish", "throttled", "unresponsive"},

    # 39 — group 39
    {"blazing", "efficient", "fast", "high-performance", "low-latency", "optimized", "performant", "quick", "responsive", "snappy", "speedy", "throughput"},

    # 40 — group 40
    {"accelerate", "benchmark", "enhance throughput", "improve performance", "optimize", "perf tuning", "profiling", "reduce latency", "speed up", "streamline", "tune"},

    # 41 — group 41
    {"defend", "fortify", "harden", "lock down", "mitigate risk", "patch", "protect", "remediate", "safeguard", "secure", "shield", "tighten security"},

    # 42 — group 42
    {"access control", "auth", "authenticate", "authorization", "credentials", "identity verification", "log in", "login", "mfa", "oauth", "sign in", "sso"},

    # 43 — group 43
    {"aes", "cipher", "data protection", "encode", "encrypt", "end-to-end encryption", "hash", "obfuscate", "scramble", "secure transmission", "ssl", "tls"},

    # 44 — group 44
    {"assets", "content", "data", "dataset", "documents", "entities", "entries", "information", "objects", "payload", "records", "rows"},

    # 45 — group 45
    {"archive", "backup", "commit", "keep", "persist", "record", "retain", "save", "snapshot", "stash", "store", "write"},

    # 46 — group 46
    {"backend", "data store", "database", "datastore", "db", "nosql", "rdbms", "repository", "schema", "storage", "table", "warehouse"},

    # 47 — group 47
    {"broadcast", "communicate", "dispatch", "emit", "message", "notify", "publish", "push", "relay", "send", "signal", "transmit"},

    # 48 — group 48
    {"api", "bridge", "channel", "connector", "endpoint", "gateway", "integration", "interface", "messaging", "protocol", "service", "webhook"},

    # 49 — group 49
    {"api call", "call", "fetch", "hit", "http call", "invoke", "network request", "ping", "query", "request", "send request", "trigger"},

    # 50 — group 50
    {"datetime", "duration", "elapsed", "epoch", "interval", "latency", "period", "schedule", "time", "timeout", "timestamp", "ttl"},

    # 51 — group 51
    {"backoff", "cooldown", "defer", "delay", "hold", "lag", "pause", "queue time", "retry delay", "sleep", "throttle", "wait"},

    # 52 — group 52
    {"connection timeout", "deadline", "expiry", "idle timeout", "request timeout", "response timeout", "session timeout", "time limit", "timeout", "ttl"},

    # 53 — group 53
    {"200", "achieved", "complete", "confirmed", "done", "finished", "fulfilled", "green", "ok", "pass", "resolved", "success"},

    # 54 — group 54
    {"500", "broken", "crash", "down", "error", "exception", "fail", "failure", "fault", "rejected", "unavailable", "unsuccessful"},

    # 55 — group 55
    {"blackout", "degraded service", "downtime", "incident", "interruption", "offline", "outage", "service disruption", "sla breach", "system failure", "unavailable"},

    # 56 — group 56
    {"big", "bloated", "bulky", "enterprise-scale", "gigantic", "heavy", "high volume", "huge", "large", "massive", "oversized", "petabyte"},

    # 57 — group 57
    {"compact", "lean", "lightweight", "limited", "little", "micro", "minimal", "reduced", "slim", "small", "thin", "tiny"},

    # 58 — group 58
    {"bytes", "capacity", "dimension", "footprint", "heap size", "magnitude", "memory footprint", "scale", "size", "storage size", "volume", "weight"},

    # 59 — group 59
    {"bill", "budget", "charge", "cost", "expense", "fee", "invoice", "money", "payment", "price", "revenue", "spend"},

    # 60 — group 60
    {"affordable", "budget-friendly", "cheap", "cost-effective", "discounted", "economical", "free tier", "frugal", "inexpensive", "lean", "low cost", "minimal cost"},

    # 61 — group 61
    {"billing spike", "burn rate", "cost overrun", "costly", "expensive", "high cost", "inefficient spending", "over-spend", "overbudget", "premium", "pricey", "waste"},

    # 62 — group 62
    {"discover", "explore", "find", "full-text search", "index", "locate", "lookup", "query", "retrieve", "scan", "search", "seek"},

    # 63 — group 63
    {"condition", "constraint", "criteria", "exclude", "facet", "filter", "include", "narrow", "predicate", "refine", "scope", "where clause"},

    # 64 — group 64
    {"elasticsearch", "full-text", "index", "inverted index", "keyword search", "lucene", "ranking", "relevance", "search index", "semantic search", "solr", "vector search"},

    # 65 — group 65
    {"adjust", "alter", "amend", "change", "edit", "modify", "mutate", "patch", "revise", "transform", "tweak", "update"},

    # 66 — group 66
    {"breaking change", "changelog", "dependency update", "diff", "migrate", "new version", "promote", "release", "semver", "update package", "upgrade", "version bump"},

    # 67 — group 67
    {"clean up", "decouple", "improve code", "modernize", "overhaul", "refactor", "reorganize", "reshape", "restructure", "rework", "rewrite", "simplify"},

    # 68 — group 68
    {"bootstrap", "build", "construct", "create", "generate", "initialize", "instantiate", "make", "new", "provision", "scaffold", "spin up"},

    # 69 — group 69
    {"deliver", "deploy", "go live", "launch", "production push", "promote", "provision", "publish", "push", "release", "roll out", "ship"},

    # 70 — group 70
    {"allocate", "bring up", "configure new", "create instance", "create resource", "initialize", "instantiate", "onboard", "provision", "set up", "spin up", "stand up"},

    # 71 — group 71
    {"clean", "delete", "deprovision", "destroy", "drop", "erase", "hard delete", "purge", "remove", "soft delete", "terminate", "wipe"},

    # 72 — group 72
    {"abandon", "archive", "decommission", "deprecate", "disable", "end of life", "eol", "legacy removal", "phase out", "remove support", "retire", "sunset"},

    # 73 — group 73
    {"clean up", "free space", "garbage collect", "housekeeping", "maintenance", "prune", "purge old data", "reclaim", "remove stale", "sweep", "trim", "vacuum"},

    # 74 — group 74
    {"begin", "boot", "execute", "fire up", "initialize", "initiate", "kick off", "launch", "run", "spin up", "start", "trigger"},

    # 75 — group 75
    {"bounce", "bring back up", "cold start", "cycle", "re-initialize", "reboot", "reload", "reset", "restart", "service restart", "soft reset", "warm restart"},

    # 76 — group 76
    {"abort", "disable", "end", "freeze", "halt", "kill", "pause", "power off", "shutdown", "stop", "suspend", "terminate"},

    # 77 — group 77
    {"associate", "attach", "bind", "bridge", "connect", "hook up", "integrate", "join", "link", "pair", "plug in", "wire"},

    # 78 — group 78
    {"close socket", "cut connection", "decouple", "detach", "disconnect", "drop connection", "end connection", "remove link", "split", "terminate session", "unbind", "unlink"},

    # 79 — group 79
    {"connection", "grpc", "http", "mesh", "network", "peer", "protocol", "rest", "socket", "tcp", "udp", "websocket"},

    # 80 — group 80
    {"branch", "break apart", "chunk", "divide", "fork", "fragment", "partition", "segment", "separate", "shard", "slice", "split"},

    # 81 — group 81
    {"aggregate", "blend", "combine", "consolidate", "fuse", "integrate", "join", "merge", "merge request", "pull request", "squash", "union"},

    # 82 — group 82
    {"branch", "clone", "copy", "derivative", "detach", "diverge", "duplicate branch", "fork", "offshoot", "separate repo", "spin-off", "variant"},

    # 83 — group 83
    {"display", "emit", "expose", "output", "present", "print", "render", "reveal", "show", "surface", "view", "visualize"},

    # 84 — group 84
    {"console", "dashboard", "frontend", "interface", "monitor", "panel", "portal", "report", "screen", "ui", "view", "visualization"},

    # 85 — group 85
    {"audit trail", "debug output", "event log", "log", "log entry", "log line", "logging", "output", "print", "stderr", "stdout", "trace"},

    # 86 — group 86
    {"blacklist", "collapse", "conceal", "filter out", "hide", "mask", "obfuscate", "redact", "remove from view", "silence", "suppress", "truncate"},

    # 87 — group 87
    {"anonymize", "censor", "data masking", "de-identify", "mask", "pii removal", "pseudonymize", "redact", "sanitize", "scrub", "strip sensitive", "tokenize"},

    # 88 — group 88
    {"blacklist", "disable alert", "dismiss", "exclude", "filter noise", "ignore", "mute", "silence", "skip", "snooze", "suppress", "whitelist"},

    # 89 — group 89
    {"add capacity", "autoscale", "burst", "elasticity", "expand", "grow", "horizontal scaling", "increase", "provision more", "scale out", "scale up", "vertical scaling"},

    # 90 — group 90
    {"autoscale", "burst capacity", "cloud scaling", "demand-driven scaling", "dynamic scaling", "elasticity", "growth", "kubernetes hpa", "load-based scaling", "scale", "scaling event", "scaling policy"},

    # 91 — group 91
    {"burst traffic", "high load", "hot spot", "load spike", "peak demand", "request flood", "sudden growth", "surge", "throughput spike", "traffic increase", "traffic storm", "volume increase"},

    # 92 — group 92
    {"compress", "consolidate", "cut", "de-provision", "decrease", "downscale", "minimize", "reduce", "right-size", "scale down", "shrink", "trim"},

    # 93 — group 93
    {"consolidate", "cost reduction", "deprovision", "downscale", "idle scale-down", "reduce instances", "remove nodes", "resource reduction", "right-size", "scale in", "shrink cluster", "trim capacity"},

    # 94 — group 94
    {"cost optimization", "idle resources", "lean infrastructure", "optimize resources", "over-provisioned", "reduce footprint", "reduce waste", "resource efficiency", "right-sizing", "trim overhead", "underutilized", "usage reduction"},

    # 95 — group 95
    {"analyze", "assess", "benchmark", "check difference", "compare", "contrast", "delta", "diff", "evaluate", "measure against", "side by side", "variance"},

    # 96 — group 96
    {"baseline", "benchmark", "comparison", "kpi", "latency test", "load test", "metric", "performance test", "profiling", "standard", "stress test", "throughput test"},

    # 97 — group 97
    {"before and after", "change log", "change set", "comparison", "contrast", "delta", "deviation", "diff", "difference", "discrepancy", "patch", "variance"},

    # 98 — group 98
    {"backup", "clone", "copy", "cp", "ditto", "duplicate", "fork", "mirror", "replicate", "reproduce", "snapshot", "transfer"},

    # 99 — group 99
    {"backup", "cdc", "clone database", "continuous replication", "copy data", "data replication", "failover copy", "mirror", "redundancy", "replica", "replicate", "sync"},

    # 100 — group 100
    {"archive", "backup", "copy", "data protection", "disaster recovery", "dr", "full backup", "incremental backup", "point-in-time backup", "redundancy", "restore point", "snapshot"},

    # 101 — group 101
    {"carry over", "lift and shift", "migrate", "move", "move data", "port", "relocate", "replatform", "shift", "transfer", "transition", "transport"},

    # 102 — group 102
    {"cloud migration", "cutover", "data migration", "database migration", "lift and shift", "migrate", "migration", "refactor", "replatform", "schema migration", "service migration", "transition"},

    # 103 — group 103
    {"align", "data sync", "eventual consistency", "keep in sync", "match", "mirror", "real-time sync", "reconcile", "replicate", "sync", "synchronize", "update"},

    # 104 — group 104
    {"backoff", "blocked", "deferred", "delayed", "hold", "idle", "pause", "pending", "queue", "sleep", "throttle", "wait"},

    # 105 — group 105
    {"async queue", "backlog", "buffer", "dequeue", "enqueue", "fifo", "job queue", "message queue", "pending jobs", "queue", "task queue", "waiting list"},

    # 106 — group 106
    {"async", "asynchronous", "background task", "callback", "concurrent", "event-driven", "eventual", "future", "non-blocking", "parallel", "promise", "reactive"},

    # 107 — group 107
    {"analyze", "assess", "audit", "comprehend", "diagnose", "evaluate", "examine", "inspect", "interpret", "investigate", "review", "understand"},

    # 108 — group 108
    {"analyze failure", "debug", "diagnose", "identify issue", "incident review", "investigate", "postmortem", "problem analysis", "rca", "root cause", "trace", "troubleshoot"},

    # 109 — group 109
    {"analyze", "assess", "audit", "benchmark", "evaluate", "examine", "inspect", "interpret", "measure", "parse", "profile", "review"},

    # 110 — group 110
    {"affect", "break", "corrupt", "damage", "degrade", "disrupt", "fail", "go down", "impact", "interrupt", "malfunction", "violate"},

    # 111 — group 111
    {"api break", "backward incompatibility", "breaking change", "breaking update", "compatibility issue", "dependency conflict", "incompatibility", "regression", "schema change", "unstable", "version conflict", "version mismatch"},

    # 112 — group 112
    {"critical", "emergency", "escalation", "incident", "incident response", "on-call", "outage", "p1", "postmortem", "production issue", "severity 1", "sla breach"},

    # 113 — group 113
    {"address", "close", "correct", "fix", "hotfix", "mend", "patch", "remediate", "repair", "resolve", "solve", "squash"},

    # 114 — group 114
    {"band-aid", "critical patch", "emergency fix", "hotfix", "patch", "production fix", "quick fix", "release fix", "security patch", "temporary fix", "urgent fix", "workaround"},

    # 115 — group 115
    {"address", "clear", "close", "complete", "done", "finished", "fix", "handle", "mitigated", "remediate", "resolve", "solved"},

    # 116 — group 116
    {"accept", "allow", "approve", "authorize", "clear", "code review approval", "confirm", "green light", "lgtm", "merge approval", "sign off", "validate"},

    # 117 — group 117
    {"approval workflow", "code review", "cr", "feedback", "inspect code", "merge request", "peer review", "pr", "pull request", "review", "review comments", "review cycle"},

    # 118 — group 118
    {"approval gate", "cab", "change management", "change request", "compliance approval", "deployment approval", "go/no-go", "governance", "production approval", "release approval", "release gate", "sign-off"},

    # 119 — group 119
    {"403", "block", "close pr", "decline", "deny", "disapprove", "fail review", "forbidden", "nack", "refuse", "reject", "veto"},

    # 120 — group 120
    {"ban", "blacklist", "block", "block request", "deny access", "disable", "firewall rule", "forbid", "prevent", "quarantine", "rate limit", "restrict"},

    # 121 — group 121
    {"blue-green rollback", "canary rollback", "downgrade", "emergency revert", "previous version", "restore", "revert", "revert change", "roll back", "rollback", "undo", "undo deployment"},

    # 122 — group 122
    {"alert", "apm", "logging", "measure", "metrics", "monitor", "observability", "observe", "telemetry", "tracing", "track", "watch"},

    # 123 — group 123
    {"alarm", "alert", "escalation", "fire", "incident alert", "notification", "on-call", "opsgenie", "pagerduty", "threshold breach", "trigger", "warning"},

    # 124 — group 124
    {"apm", "dashboards", "logs", "metrics", "monitoring", "observability", "sla", "sli", "slo", "telemetry", "traces", "visibility"},

    # 125 — group 125
    {"adjust settings", "config", "configure", "customize", "environment variables", "initialize", "parameterize", "properties", "provision", "set up", "setup", "tune"},

    # 126 — group 126
    {"config", "config map", "configuration", "env vars", "environment", "ini", "json config", "parameters", "properties file", "settings", "toml", "yaml"},

    # 127 — group 127
    {"dev", "development", "env", "environment", "local", "prod", "production", "qa", "runtime environment", "sandbox", "staging", "test environment"},

    # 128 — group 128
    {"access control", "acl", "authorization", "deny", "entitlement", "grant", "iam", "permissions", "policy", "privilege", "rbac", "role"},

    # 129 — group 129
    {"access", "allow", "authorize", "clearance", "entitle", "grant", "iam", "permit", "policy", "privilege", "rights", "role assignment"},

    # 130 — group 130
    {"authorization model", "entitlement", "group", "iam", "permission", "policy", "principle of least privilege", "rbac", "role", "role-based access control", "scope", "user group"},

    # 131 — group 131
    {"add", "apt", "brew", "deploy", "download", "get", "install", "npm install", "package install", "provision", "setup", "yum"},

    # 132 — group 132
    {"artifact", "component", "dependency", "gradle", "library", "maven", "module", "npm", "nuget", "package", "pip", "plugin"},

    # 133 — group 133
    {"apt", "brew", "cargo", "gem", "gradle", "helm", "maven", "npm", "nuget", "package manager", "pip", "yum"},

    # 134 — group 134
    {"breaking change", "dependency upgrade", "hotfix", "major upgrade", "minor update", "new release", "package upgrade", "patch", "semver", "update", "upgrade", "version bump"},

    # 135 — group 135
    {"artifact version", "build number", "changelog", "major", "minor", "patch", "release", "semver", "tag", "v1", "v2", "version"},

    # 136 — group 136
    {"api compatibility", "backward compatible", "breaking change", "compatibility", "cross-platform", "dependency conflict", "forward compatible", "interoperability", "migration path", "schema compatibility", "version support", "versioning"},

    # 137 — group 137
    {"api limit", "backpressure", "bandwidth limit", "cap", "control traffic", "limit", "quota", "rate limit", "request throttling", "restrict", "slow down", "throttle"},

    # 138 — group 138
    {"429", "api limit", "cap", "ceiling", "max calls", "quota", "rate limit", "requests per second", "rps", "throttle", "tps", "usage limit"},

    # 139 — group 139
    {"backoff", "backpressure", "buffer overflow", "circuit breaker", "congestion", "flow control", "load shedding", "overload protection", "producer-consumer", "queue pressure", "slow consumer", "throttle"},

    # 140 — group 140
    {"cache", "cache hit", "cache miss", "caching", "cdn", "edge cache", "in-memory", "invalidate cache", "memcached", "redis", "ttl", "warm cache"},

    # 141 — group 141
    {"cache bust", "cache invalidation", "cache miss", "cache refresh", "dirty cache", "eviction", "expire", "flush cache", "invalidate", "purge cache", "stale cache", "ttl"},

    # 142 — group 142
    {"akamai", "caching layer", "cdn", "content delivery network", "distributed cache", "edge", "edge cache", "edge node", "geo-distribution", "origin server", "reverse proxy", "static assets"},

    # 143 — group 143
    {"abort", "application crash", "core dump", "crash", "fatal error", "kernel panic", "oom", "out of memory", "process crash", "segfault", "sigsegv", "unexpected termination"},

    # 144 — group 144
    {"container oom", "heap overflow", "kill process", "memory cap", "memory error", "memory exhaustion", "memory limit", "oom", "oom killer", "out of memory", "resource limit", "stack overflow"},

    # 145 — group 145
    {"application", "container", "daemon", "instance", "job", "microservice", "pod", "process", "service", "task", "thread", "worker"},

    # 146 — group 146
    {"blocked", "deadlock", "freeze", "frozen", "halt", "hang", "infinite loop", "livelock", "not responding", "stall", "stuck", "unresponsive"},

    # 147 — group 147
    {"blocked process", "blocked threads", "circular wait", "deadlock", "livelock", "lock contention", "mutex deadlock", "race condition", "starvation", "stuck", "synchronization issue", "thread deadlock"},

    # 148 — group 148
    {"anr", "application hang", "browser freeze", "cpu spike", "freeze", "gc pause", "main thread blocked", "not responding", "stop the world", "thread blocked", "ui freeze", "unresponsive ui"},

    # 149 — group 149
    {"accumulation", "connection leak", "drip", "file descriptor leak", "handle leak", "heap leak", "leak", "memory leak", "object leak", "resource leak", "slow memory growth", "unreleased resource"},

    # 150 — group 150
    {"gc pressure", "heap dump", "heap growth", "memory bloat", "memory leak", "memory profiling", "native memory leak", "object accumulation", "off-heap leak", "retention", "slow leak", "unreleased memory"},

    # 151 — group 151
    {"connection leak", "connection pool", "db connection leak", "file handle leak", "handle leak", "http connection leak", "jdbc leak", "max connections", "pool exhaustion", "resource exhaustion", "socket leak", "unclosed connection"},

    # 152 — group 152
    {"degraded", "high cpu", "i/o bound", "latency increase", "overloaded", "performance degradation", "resource contention", "response time", "slow", "slow query", "sluggish", "under-performing"},

    # 153 — group 153
    {"bottleneck", "cpu spike", "degraded performance", "i/o bottleneck", "latency spike", "memory pressure", "network latency", "perf problem", "performance issue", "resource saturation", "slow response", "throughput drop"},

    # 154 — group 154
    {"brownout", "degraded", "degraded mode", "impaired service", "limited functionality", "limp mode", "partial availability", "partial failure", "partial outage", "reduced capacity", "service degradation", "sla breach"},

    # 155 — group 155
    {"analyze", "breakpoint", "debug", "diagnose", "inspect", "investigate", "profile", "reproduce", "step through", "test locally", "trace", "troubleshoot"},

    # 156 — group 156
    {"correlation id", "distributed trace", "end-to-end trace", "jaeger", "opentelemetry", "request trace", "span", "trace", "trace context", "trace id", "tracing", "zipkin"},

    # 157 — group 157
    {"confirm bug", "create test case", "demonstrate", "isolate", "minimal reproduction", "replicate issue", "repro steps", "reproduce", "reproduce bug", "simulate", "test scenario", "trigger"},

    # 158 — group 158
    {"api docs", "document", "documentation", "kb", "knowledge base", "playbook", "readme", "runbook", "tech spec", "wiki", "write docs", "write up"},

    # 159 — group 159
    {"api docs", "confluence", "docs", "docstring", "documentation", "inline comment", "markdown", "notion", "openapi", "readme", "swagger", "wiki"},

    # 160 — group 160
    {"incident runbook", "manual", "on-call doc", "operational doc", "operational guide", "playbook", "procedure", "response guide", "runbook", "sop", "standard operating procedure", "step-by-step"},

    # 161 — group 161
    {"automated test", "e2e", "end-to-end test", "integration test", "qa", "quality assurance", "regression test", "smoke test", "test", "test case", "test suite", "unit test"},

    # 162 — group 162
    {"acceptance test", "canary test", "e2e test", "functional test", "integration test", "load test", "performance test", "regression test", "smoke test", "stress test", "uat", "unit test"},

    # 163 — group 163
    {"automation pipeline", "build", "ci/cd", "continuous delivery", "continuous integration", "deployment pipeline", "devops pipeline", "github actions", "gitlab ci", "jenkins", "pipeline", "test automation"},

    # 164 — group 164
    {"blue-green", "canary", "deploy", "deployment", "go live", "production deploy", "promote", "publish", "push", "release", "rollout", "ship"},

    # 165 — group 165
    {"a/b deploy", "blue-green deployment", "canary deployment", "dark launch", "feature flag", "incremental release", "progressive delivery", "rolling deployment", "shadow deploy", "staged rollout", "traffic shifting", "zero-downtime deploy"},

    # 166 — group 166
    {"container", "containerize", "docker", "helm", "image", "k8s", "kubernetes", "microservice", "orchestration", "pod", "registry", "service mesh"},

    # 167 — group 167
    {"downgrade", "emergency rollback", "git revert", "hotfix rollback", "previous release", "previous state", "restore previous", "revert", "roll back version", "rollback", "undo change", "undo deployment"},

    # 168 — group 168
    {"a/b test", "conditional feature", "dark launch", "disable feature", "enable feature", "feature flag", "feature toggle", "flag", "flag management", "gradual rollout", "kill switch", "launchdarkly"},

    # 169 — group 169
    {"canary", "canary deploy", "canary release", "early adopters", "gradual rollout", "partial rollout", "phased release", "progressive delivery", "small percentage", "staged rollout", "test in production", "traffic split"},

    # 170 — group 170
    {"at", "batch schedule", "cron", "cron job", "job schedule", "recurring job", "schedule", "scheduled task", "task schedule", "time-based", "timer", "timer trigger"},

    # 171 — group 171
    {"batch job", "cron", "cron job", "job scheduler", "nightly job", "periodic", "quartz", "recurring", "scheduled task", "task runner", "timer", "weekly job"},

    # 172 — group 172
    {"batch", "batch job", "batch processing", "bulk", "bulk operation", "chunk processing", "data pipeline", "etl", "nightly batch", "offline processing", "pipeline", "scheduled batch"},

    # 173 — group 173
    {"abort", "cancel", "cancel request", "end", "halt process", "interrupt", "kill job", "nullify", "revoke", "stop", "terminate", "withdraw"},

    # 174 — group 174
    {"abort", "bail out", "cancel operation", "emergency stop", "end task", "force quit", "interrupt", "kill", "sigkill", "sigterm", "stop process", "terminate"},

    # 175 — group 175
    {"408", "504", "connection timeout", "deadline exceeded", "expire", "idle timeout", "read timeout", "request timeout", "session timeout", "time limit", "timeout", "write timeout"},

    # 176 — group 176
    {"automatic retry", "backoff", "exponential backoff", "idempotent retry", "max retries", "re-submit", "reattempt", "retry", "retry logic", "retry policy", "retry queue", "try again"},

    # 177 — group 177
    {"backoff algorithm", "backoff strategy", "circuit breaker", "exponential backoff", "jitter", "progressive delay", "retry cap", "retry delay", "retry interval", "retry limit", "retry with backoff", "wait and retry"},

    # 178 — group 178
    {"bulkhead", "circuit breaker", "failover", "fallback", "fault tolerance", "half-open", "hystrix", "open circuit", "resilience", "resilience4j", "retry", "timeout"},

    # 179 — group 179
    {"brotli", "compact", "compress", "compression", "deflate", "encode", "gzip", "lossless", "minify", "reduce size", "shrink file", "zip"},

    # 180 — group 180
    {"brotli", "compress file", "content encoding", "data compression", "deflate", "file compression", "gzip", "lz4", "payload compression", "tar", "zip", "zstd"},

    # 181 — group 181
    {"aes-256", "certificate", "cryptography", "encrypt", "encrypt at rest", "encrypt in transit", "key management", "kms", "pki", "rsa", "ssl", "tls"},

    # 182 — group 182
    {"agenda", "calendar", "deadline", "due date", "maintenance window", "milestone", "plan", "release schedule", "roadmap", "schedule", "sprint", "timetable"},

    # 183 — group 183
    {"blackout window", "change freeze", "change window", "deployment window", "downtime schedule", "freeze period", "maintenance window", "planned maintenance", "planned outage", "release window", "scheduled downtime", "service window"},

    # 184 — group 184
    {"99.9", "availability", "error budget", "four nines", "reliability", "service commitment", "service level agreement", "sla", "sli", "slo", "three nines", "uptime"},

]


def _build_synonym_map(groups: List[Set[str]]) -> Dict[str, Set[str]]:
    """Build a bidirectional term → synonym-set lookup in O(n) time.

    For each group, every term maps to the full group (minus itself).
    If a term appears in multiple groups its synonyms are unioned together.
    """
    mapping: Dict[str, Set[str]] = {}
    for group in groups:
        for term in group:
            if term not in mapping:
                mapping[term] = set()
            # Union in all other terms from this group
            mapping[term] |= group - {term}
    return mapping


# Module-level singleton — built once at import time.
_SYNONYM_MAP: Dict[str, Set[str]] = _build_synonym_map(_SYNONYM_GROUPS)


# Stopwords to skip during expansion (mirrors SearchEngine.STOPWORDS)
_STOPWORDS: frozenset = frozenset({
    'the', 'a', 'an', 'is', 'are', 'was', 'were', 'be', 'been', 'being',
    'have', 'has', 'had', 'do', 'does', 'did', 'will', 'would', 'could',
    'should', 'may', 'might', 'shall', 'can', 'need', 'dare', 'ought',
    'used', 'to', 'of', 'in', 'for', 'on', 'with', 'at', 'by', 'from',
    'as', 'into', 'through', 'during', 'before', 'after', 'above', 'below',
    'between', 'out', 'off', 'over', 'under', 'again', 'further', 'then',
    'once', 'here', 'there', 'when', 'where', 'why', 'how', 'all', 'both',
    'each', 'few', 'more', 'most', 'other', 'some', 'such', 'no', 'nor',
    'not', 'only', 'own', 'same', 'so', 'than', 'too', 'very', 'just',
    'don', 'now', 'and', 'but', 'or', 'if', 'while', 'that', 'this',
    'it', 'its', 'he', 'she', 'they', 'them', 'his', 'her', 'their',
    'what', 'which', 'who', 'whom', 'these', 'those', 'am', 'about',
    'up', 'down', 'we', 'our', 'you', 'your', 'my', 'me', 'i', 'much',
    'get', 'got', 'give', 'make', 'take', 'let', 'put', 'set',
})


def _tokenize(text: str) -> List[str]:
    """Lightweight tokeniser — same regex as SearchEngine._tokenize."""
    tokens = re.findall(r'\w{2,}', text.lower())
    return [t for t in tokens if t not in _STOPWORDS]


class QueryExpander:
    """Expands query terms with synonyms before BM25 scoring.

    Uses a built-in synonym map with 35+ semantic groups.  The map is
    bidirectional: if A → {B, C} then B → {A, C} and C → {A, B}.

    Usage::

        expander = QueryExpander()
        expanded = expander.expand("how much are we spending?")
        # → "how much are we spending? cost budget expense price payment ..."

    Args:
        extra_synonyms: Optional dict[str, list[str]] of additional groups
            to merge into the built-in map at construction time.
    """

    def __init__(self, extra_synonyms: Dict[str, List[str]] = None):
        # Start with the module-level map
        if extra_synonyms:
            # Deep-copy so we don't mutate the module global
            merged: Dict[str, Set[str]] = {k: set(v) for k, v in _SYNONYM_MAP.items()}
            # Treat each key + its values as a new synonym group
            for term, synonyms in extra_synonyms.items():
                group = {term} | set(synonyms)
                for t in group:
                    if t not in merged:
                        merged[t] = set()
                    merged[t] |= group - {t}
            self._map = merged
        else:
            self._map = _SYNONYM_MAP

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def expand(self, query: str) -> str:
        """Expand a query string by appending synonyms of recognised terms.

        The original query is preserved verbatim; synonyms are appended so
        that the expanded string naturally feeds into the existing tokeniser.
        Duplicates and stopwords are removed from the appended portion only —
        the original wording is never altered.

        Args:
            query: The raw user query.

        Returns:
            The original query with synonym terms appended, e.g.:
            ``"spending cost budget expense price payment fee bill charge ..."``.
        """
        extra = self.expand_tokens(_tokenize(query))
        original_tokens = set(_tokenize(query))
        additions = [t for t in extra if t not in original_tokens]
        if not additions:
            return query
        return query + " " + " ".join(additions)

    def expand_tokens(self, tokens: List[str]) -> List[str]:
        """Expand a list of tokens, returning deduplicated original + synonyms.

        Args:
            tokens: Pre-tokenised query terms (lowercase, no stopwords).

        Returns:
            A new list starting with the original tokens, followed by all
            unique synonyms found in the map, preserving insertion order.
        """
        seen: Set[str] = set()
        result: List[str] = []

        # First pass — add original tokens
        for t in tokens:
            if t not in seen:
                seen.add(t)
                result.append(t)

        # Second pass — add synonyms from curated domain groups
        for t in tokens:
            for syn in self._map.get(t, set()):
                if syn not in seen and syn not in _STOPWORDS:
                    seen.add(syn)
                    result.append(syn)

        return result

    # ------------------------------------------------------------------
    # Introspection helpers
    # ------------------------------------------------------------------

    def synonyms_for(self, term: str) -> Set[str]:
        """Return the synonym set for a single term (empty set if unknown)."""
        return set(self._map.get(term.lower(), set()))

    def known_terms(self) -> Set[str]:
        """Return all terms the expander knows about."""
        return set(self._map.keys())
