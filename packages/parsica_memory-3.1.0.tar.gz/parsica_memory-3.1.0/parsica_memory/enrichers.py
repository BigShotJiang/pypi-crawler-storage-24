"""
Pre-built enricher templates for common LLM providers.

Each factory returns a callable ``enrich(text: str) -> dict`` compatible
with ``MemorySystem(enricher=...)``.  Zero SDK dependencies - uses only
urllib from the standard library.

Supported providers:
    - Anthropic (Claude)
    - OpenAI (GPT)
    - Google (Gemini)
    - Any OpenAI-compatible endpoint (Ollama, LM Studio, vLLM, etc.)

Usage::

    from parsica_memory.enrichers import anthropic_enricher

    enrich = anthropic_enricher("sk-ant-...")
    mem = MemorySystem("./store", enricher=enrich)

To enrich existing memories after adding an enricher::

    mem.re_enrich()  # batch-enriches all un-enriched entries
"""

from __future__ import annotations

import json
import logging
import os
from typing import Optional
from urllib.request import Request, urlopen

# -----------------------------------------------------------------------
# Shared enrichment prompt - battle-tested on 9,000+ memories
# -----------------------------------------------------------------------

_ENRICHMENT_PROMPT = (
    "Analyze this memory/note and extract semantic metadata to improve search recall.\n"
    "Focus on SYNONYMS and RELATED CONCEPTS that someone might use when searching.\n"
    "Return ONLY a valid JSON object with exactly these fields:\n"
    '- "tags": 5-10 snake_case semantic labels (include synonyms: e.g. "authentication" '
    'for JWT, "deployment" for Kubernetes, "cost_tracking" for billing)\n'
    '- "summary": one sentence rephrasing the core fact using DIFFERENT vocabulary than the original\n'
    '- "keywords": 8-15 terms someone might search to find this memory '
    '(think: natural language queries a person would type)\n'
    '- "search_queries": 3 SPECIFIC natural language questions that ONLY this exact memory answers. '
    "Include exact names (function names, class names, variable names, package names, version numbers, "
    "decision names). Each query must be discriminative - it should NOT match hundreds of other memories.\n"
    '- "facts": 1-5 atomic fact statements extracted from this memory. Each should be a standalone sentence '
    "that captures one specific piece of information (a preference, decision, name, date, configuration, etc.) "
    "If the memory doesn't contain extractable facts, return an empty list.\n\n"
    "Memory:\n{text}\n\nJSON:"
)


def _parse_json_response(raw: str) -> dict:
    """Extract the outermost JSON object from an LLM response."""
    raw = raw.strip()
    start = raw.find("{")
    end = raw.rfind("}")
    if start != -1 and end > start:
        try:
            return json.loads(raw[start : end + 1])
        except json.JSONDecodeError:
            pass
    return {}


# -----------------------------------------------------------------------
# Anthropic (Claude)
# -----------------------------------------------------------------------

def anthropic_enricher(
    api_key: Optional[str] = None,
    model: str = "claude-sonnet-4-6",
    max_tokens: int = 256,
    timeout: int = 30,
):
    """Create an enricher using the Anthropic Messages API.

    Args:
        api_key: Anthropic API key. Falls back to ``ANTHROPIC_API_KEY`` env var.
        model: Model to use. Default is claude-sonnet-4-6.
        max_tokens: Max tokens for the response.
        timeout: Request timeout in seconds.

    Returns:
        Callable ``enrich(text) -> dict`` or None if no key available.
    """
    key = api_key or os.environ.get("ANTHROPIC_API_KEY", "")
    if not key:
        return None

    def enrich(text: str) -> dict:
        try:
            url = "https://api.anthropic.com/v1/messages"
            payload = json.dumps({
                "model": model,
                "max_tokens": max_tokens,
                "messages": [{"role": "user", "content": _ENRICHMENT_PROMPT.format(text=text[:600])}],
            })
            req = Request(url, data=payload.encode("utf-8"), method="POST")
            req.add_header("Content-Type", "application/json")
            if key.startswith("sk-ant-oat"):
                req.add_header("Authorization", f"Bearer {key}")
            else:
                req.add_header("x-api-key", key)
            req.add_header("anthropic-version", "2023-06-01")
            with urlopen(req, timeout=timeout) as resp:
                data = json.loads(resp.read().decode("utf-8"))
                return _parse_json_response(data["content"][0]["text"])
        except Exception as e:
            logging.getLogger("parsica_memory.enrichers").debug(f"Anthropic enrichment failed: {e}")
            return {}

    return enrich


# -----------------------------------------------------------------------
# OpenAI (GPT)
# -----------------------------------------------------------------------

def openai_enricher(
    api_key: Optional[str] = None,
    model: str = "gpt-4o-mini",
    base_url: str = "https://api.openai.com",
    max_tokens: int = 256,
    timeout: int = 30,
):
    """Create an enricher using the OpenAI Chat Completions API.

    Args:
        api_key: OpenAI API key. Falls back to ``OPENAI_API_KEY`` env var.
        model: Model to use. Default is gpt-4o-mini (cheap and fast).
        base_url: API base URL. Change for Azure, Ollama, LM Studio, etc.
        max_tokens: Max tokens for the response.
        timeout: Request timeout in seconds.

    Returns:
        Callable ``enrich(text) -> dict`` or None if no key available.
    """
    key = api_key or os.environ.get("OPENAI_API_KEY", "")
    if not key:
        return None

    def enrich(text: str) -> dict:
        try:
            url = f"{base_url.rstrip('/')}/v1/chat/completions"
            payload = json.dumps({
                "model": model,
                "max_tokens": max_tokens,
                "messages": [{"role": "user", "content": _ENRICHMENT_PROMPT.format(text=text[:600])}],
            })
            req = Request(url, data=payload.encode("utf-8"), method="POST")
            req.add_header("Content-Type", "application/json")
            req.add_header("Authorization", f"Bearer {key}")
            with urlopen(req, timeout=timeout) as resp:
                data = json.loads(resp.read().decode("utf-8"))
                return _parse_json_response(data["choices"][0]["message"]["content"])
        except Exception as e:
            logging.getLogger("parsica_memory.enrichers").debug(f"OpenAI enrichment failed: {e}")
            return {}

    return enrich


# -----------------------------------------------------------------------
# Google Gemini
# -----------------------------------------------------------------------

def gemini_enricher(
    api_key: Optional[str] = None,
    model: str = "gemini-2.0-flash",
    timeout: int = 30,
):
    """Create an enricher using the Google Gemini API.

    Args:
        api_key: Google AI API key. Falls back to ``GOOGLE_API_KEY`` env var.
        model: Model to use. Default is gemini-2.0-flash.
        timeout: Request timeout in seconds.

    Returns:
        Callable ``enrich(text) -> dict`` or None if no key available.
    """
    key = api_key or os.environ.get("GOOGLE_API_KEY", "")
    if not key:
        return None

    def enrich(text: str) -> dict:
        try:
            url = (
                f"https://generativelanguage.googleapis.com/v1beta/models/"
                f"{model}:generateContent?key={key}"
            )
            payload = json.dumps({
                "contents": [{"parts": [{"text": _ENRICHMENT_PROMPT.format(text=text[:600])}]}],
                "generationConfig": {"maxOutputTokens": 256},
            })
            req = Request(url, data=payload.encode("utf-8"), method="POST")
            req.add_header("Content-Type", "application/json")
            with urlopen(req, timeout=timeout) as resp:
                data = json.loads(resp.read().decode("utf-8"))
                raw = data["candidates"][0]["content"]["parts"][0]["text"]
                return _parse_json_response(raw)
        except Exception as e:
            logging.getLogger("parsica_memory.enrichers").debug(f"Gemini enrichment failed: {e}")
            return {}

    return enrich


# -----------------------------------------------------------------------
# Generic OpenAI-compatible (Ollama, LM Studio, vLLM, etc.)
# -----------------------------------------------------------------------

def local_enricher(
    base_url: str = "http://localhost:11434",
    model: str = "llama3.2",
    timeout: int = 60,
):
    """Create an enricher for any OpenAI-compatible local endpoint.

    Works with Ollama, LM Studio, vLLM, and anything that speaks
    the OpenAI Chat Completions format. No API key required.

    Args:
        base_url: Server URL (default: Ollama at localhost:11434).
        model: Model name.
        timeout: Request timeout in seconds (longer for local models).

    Returns:
        Callable ``enrich(text) -> dict``.
    """

    def enrich(text: str) -> dict:
        try:
            url = f"{base_url.rstrip('/')}/v1/chat/completions"
            payload = json.dumps({
                "model": model,
                "messages": [{"role": "user", "content": _ENRICHMENT_PROMPT.format(text=text[:600])}],
            })
            req = Request(url, data=payload.encode("utf-8"), method="POST")
            req.add_header("Content-Type", "application/json")
            with urlopen(req, timeout=timeout) as resp:
                data = json.loads(resp.read().decode("utf-8"))
                return _parse_json_response(data["choices"][0]["message"]["content"])
        except Exception as e:
            logging.getLogger("parsica_memory.enrichers").debug(f"Local enrichment failed: {e}")
            return {}

    return enrich


# -----------------------------------------------------------------------
# Key prefix detection — provider-agnostic
# -----------------------------------------------------------------------

def _detect_provider(api_key: str) -> str:
    """Detect LLM provider from API key prefix.

    Returns one of: 'anthropic', 'openai', 'google', 'openai-compat'.
    """
    if api_key.startswith("sk-ant-"):
        return "anthropic"
    if api_key.startswith("sk-"):
        return "openai"
    if api_key.startswith("AIza"):
        return "google"
    # Default to OpenAI-compatible (covers most self-hosted, LiteLLM, etc.)
    return "openai-compat"


def smart_enricher(
    api_key: str,
    model: Optional[str] = None,
    base_url: Optional[str] = None,
    timeout: int = 30,
) -> Optional[callable]:
    """Create an enricher from any API key — auto-detects the provider.

    Pass any LLM API key and get back the right enricher. No need to know
    which provider it belongs to.

    Args:
        api_key: Any LLM API key (Anthropic, OpenAI, Google, or compatible).
        model: Override model name. If None, uses a sensible default per provider.
        base_url: Override base URL. If None, uses the provider's default.
        timeout: Request timeout in seconds.

    Returns:
        Callable ``enrich(text) -> dict`` or None if key is empty.
    """
    if not api_key or not api_key.strip():
        return None

    api_key = api_key.strip()
    provider = _detect_provider(api_key)

    if provider == "anthropic":
        kwargs = {"api_key": api_key, "timeout": timeout}
        if model:
            kwargs["model"] = model
        return anthropic_enricher(**kwargs)

    if provider == "openai":
        kwargs = {"api_key": api_key, "timeout": timeout}
        if model:
            kwargs["model"] = model
        if base_url:
            kwargs["base_url"] = base_url
        return openai_enricher(**kwargs)

    if provider == "google":
        kwargs = {"api_key": api_key, "timeout": timeout}
        if model:
            kwargs["model"] = model
        return gemini_enricher(**kwargs)

    # openai-compat: use OpenAI enricher with custom base_url
    kwargs = {"api_key": api_key, "timeout": timeout}
    if model:
        kwargs["model"] = model
    if base_url:
        kwargs["base_url"] = base_url
    return openai_enricher(**kwargs)


# -----------------------------------------------------------------------
# Auth-profiles.json reader — live token from OpenClaw config
# -----------------------------------------------------------------------

_AUTH_PROFILES_PATHS = [
    # OpenClaw main agent
    os.path.join(os.path.expanduser("~"), ".openclaw", "agents", "main", "agent", "auth-profiles.json"),
    # Antaris-Agent default
    os.path.join(os.path.expanduser("~"), ".antarisbot", "auth-profiles.json"),
]


def _read_auth_profiles_key(path: Optional[str] = None) -> Optional[str]:
    """Read the best available API key/token from auth-profiles.json.

    Reads the file fresh every call so token refreshes are picked up
    automatically. Returns the token from the lastGood profile for the
    first available provider (prefers Anthropic > OpenAI > Google).

    Args:
        path: Explicit path to auth-profiles.json. If None, checks
              default locations.

    Returns:
        API key/token string, or None if not found.
    """
    paths_to_check = [path] if path else _AUTH_PROFILES_PATHS

    for p in paths_to_check:
        if not p or not os.path.isfile(p):
            continue
        try:
            with open(p) as f:
                data = json.load(f)
        except (json.JSONDecodeError, OSError):
            continue

        profiles = data.get("profiles", {})
        last_good = data.get("lastGood", {})
        
        # Type checks
        if not isinstance(profiles, dict) or not isinstance(last_good, dict):
            continue

        # Try providers in preference order
        for provider in ("anthropic", "openai", "openai-codex", "google"):
            profile_id = last_good.get(provider)
            if not profile_id or profile_id not in profiles:
                continue
            profile = profiles[profile_id]
            # Token-based auth (Anthropic OAuth, API keys)
            token = profile.get("token") or profile.get("apiKey") or profile.get("access")
            if token and isinstance(token, str) and len(token) > 10:
                return token

    return None


# -----------------------------------------------------------------------
# Auto-detect: pick the best available enricher
# -----------------------------------------------------------------------

def auto_enricher(auth_profiles_path: Optional[str] = None) -> Optional[callable]:
    """Auto-detect the best available enricher.

    Resolution order:
        1. auth-profiles.json (DEFAULT) — reads live token from OpenClaw
           or Antaris-Agent config. Survives OAuth token refreshes.
        2. ANTARIS_LLM_API_KEY env var — provider-agnostic manual override
        3. ANTHROPIC_API_KEY env var
        4. OPENAI_API_KEY env var
        5. GOOGLE_API_KEY env var
        6. None (no enricher available)

    Args:
        auth_profiles_path: Explicit path to auth-profiles.json.
            If None, checks default locations automatically.

    Returns:
        Callable ``enrich(text) -> dict`` or None.
    """
    # 1. Auth-profiles.json — live token, survives refreshes
    auth_key = _read_auth_profiles_key(path=auth_profiles_path)
    if auth_key:
        model = os.environ.get("ANTARIS_LLM_MODEL")
        base_url = os.environ.get("ANTARIS_LLM_BASE_URL")
        result = smart_enricher(auth_key, model=model, base_url=base_url)
        if result is not None:
            return result

    # 2. ANTARIS_LLM_API_KEY — manual override, provider-agnostic
    antaris_key = os.environ.get("ANTARIS_LLM_API_KEY", "")
    if antaris_key:
        model = os.environ.get("ANTARIS_LLM_MODEL")
        base_url = os.environ.get("ANTARIS_LLM_BASE_URL")
        result = smart_enricher(antaris_key, model=model, base_url=base_url)
        if result is not None:
            return result

    # 3-5. Provider-specific env vars
    for factory, env_var in [
        (anthropic_enricher, "ANTHROPIC_API_KEY"),
        (openai_enricher, "OPENAI_API_KEY"),
        (gemini_enricher, "GOOGLE_API_KEY"),
    ]:
        if os.environ.get(env_var):
            result = factory()
            if result is not None:
                return result
    return None
