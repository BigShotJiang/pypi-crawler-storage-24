"""
parsica_memory.wizard - Interactive setup wizard.

Guides users through choosing between MemoryManager and MemorySystem,
scaffolds the right starter code and config, then handles import and
enrichment setup.

Usage:
    from parsica_memory.wizard import run_wizard
    result = run_wizard(workspace="./memory")
"""

from __future__ import annotations

import json
import os
import sys
import uuid
from pathlib import Path
from typing import List, Optional


# ---------------------------------------------------------------------------
# Model catalog (hardcoded)
# ---------------------------------------------------------------------------

MODEL_CATALOG = {
    "anthropic": [
        {"id": "claude-haiku-4-5-20251001", "name": "claude-haiku-4-5", "cost_per_1k": 0.10, "quality": "Good", "tags": ["best value"]},
        {"id": "claude-sonnet-4-6", "name": "claude-sonnet-4-6", "cost_per_1k": 0.50, "quality": "Excellent", "tags": ["best quality"]},
        {"id": "claude-opus-4-6", "name": "claude-opus-4-6", "cost_per_1k": 2.50, "quality": "Excellent", "tags": []},
    ],
    "openai": [
        {"id": "gpt-4o-mini", "name": "gpt-4o-mini", "cost_per_1k": 0.15, "quality": "Good", "tags": ["best value"]},
        {"id": "gpt-4o", "name": "gpt-4o", "cost_per_1k": 0.80, "quality": "Excellent", "tags": ["best quality"]},
    ],
    "google": [
        {"id": "gemini-2.0-flash", "name": "gemini-2.0-flash", "cost_per_1k": 0.05, "quality": "Good", "tags": ["cheapest", "best value"]},
        {"id": "gemini-2.5-pro", "name": "gemini-2.5-pro", "cost_per_1k": 0.60, "quality": "Excellent", "tags": ["best quality"]},
    ],
}

PROVIDER_DISPLAY = {
    "anthropic": "Anthropic",
    "openai": "OpenAI",
    "google": "Google",
}

IMPORT_SOURCE_MAP = {
    "1": "mem0",
    "2": "memvid",
    "3": "zep",
    "4": "langmem",
    "5": "openai",
    "6": "auto",
}


# ---------------------------------------------------------------------------
# Display helpers
# ---------------------------------------------------------------------------

def _clear():
    """Clear terminal (best effort)."""
    os.system("cls" if os.name == "nt" else "clear")


def _banner():
    print()
    print("  ============================================")
    print("  |   parsica-memory - Setup Wizard          |")
    print("  |   Persistent memory for AI agents        |")
    print("  ============================================")
    print()


def _prompt(question: str, options: list, allow_restart: bool = True) -> str:
    """Display a numbered prompt and return the chosen option value.

    Options format: [("display text", "value"), ...]
    Returns "RESTART" if user wants to start over.
    """
    print(f"  {question}")
    print()
    for i, (label, _) in enumerate(options, 1):
        print(f"    [{i}] {label}")
    if allow_restart:
        print()
        print("    [r] Start over")
    print()

    while True:
        choice = input("  Your choice: ").strip().lower()
        if allow_restart and choice == "r":
            return "RESTART"
        try:
            idx = int(choice) - 1
            if 0 <= idx < len(options):
                return options[idx][1]
        except ValueError:
            pass
        print(f"  Please enter a number 1-{len(options)}" +
              (" or 'r' to start over" if allow_restart else ""))


def _confirm(question: str) -> bool:
    """Yes/no confirmation."""
    while True:
        answer = input(f"  {question} [y/n]: ").strip().lower()
        if answer in ("y", "yes"):
            return True
        if answer in ("n", "no"):
            return False


# ---------------------------------------------------------------------------
# Wizard flows -- initial setup
# ---------------------------------------------------------------------------

def _explain_options():
    """Print a clear explanation of both options."""
    print("  parsica-memory has two ways to use it:")
    print()
    print("  --- MemoryManager (recommended for most users) ---")
    print("  Built for apps with multiple users.")
    print("  Each user gets their own isolated memory store automatically.")
    print("  Handles noise filtering, auto-save, and optional LLM enrichment.")
    print("  Simpler API. Fewer decisions to make.")
    print()
    print("  --- MemorySystem (full control) ---")
    print("  One store, one agent. You manage everything.")
    print("  Direct access to search params, graph intelligence, sharding,")
    print("  tiered storage, shared pools, maintenance, and all internals.")
    print("  Best for personal assistants or when two runtimes share one brain.")
    print()
    print("  Full details: https://github.com/Antaris-Analytics-LLC/Parsica-Memory#readme")
    print()


def _guided_flow() -> str:
    """Ask questions to recommend the right option.

    Returns "manager" or "system".
    """
    score_manager = 0
    score_system = 0

    questions = [
        {
            "q": "How many users will talk to your agent?",
            "options": [
                ("Just me (personal assistant)", "system", 0, 2),
                ("A few people (small team / friends)", "manager", 1, 1),
                ("Many users (public bot, SaaS, community)", "manager", 2, 0),
            ],
        },
        {
            "q": "How many separate bots or runtimes will share this memory?",
            "options": [
                ("Just one", "either", 0, 0),
                ("Two or more sharing the same brain", "system", 0, 2),
                ("Multiple bots, each with their own memory", "manager", 2, 0),
            ],
        },
        {
            "q": "Do you need fine control over search behavior?",
            "options": [
                ("No, just make it work", "manager", 2, 0),
                ("Some control would be nice", "either", 1, 1),
                ("Yes, I want to tune everything", "system", 0, 2),
            ],
        },
        {
            "q": "Will you use features like graph intelligence, tiered storage, or shared pools?",
            "options": [
                ("Probably not / I don't know what those are", "manager", 2, 0),
                ("Maybe later", "either", 1, 1),
                ("Yes, that's why I'm here", "system", 0, 2),
            ],
        },
        {
            "q": "How do you want to handle memory persistence?",
            "options": [
                ("Auto-save after every message (safest)", "manager", 2, 0),
                ("I'll call save() when I want to", "system", 0, 2),
                ("Not sure yet", "either", 1, 1),
            ],
        },
    ]

    for i, q_data in enumerate(questions):
        print(f"  Question {i + 1} of {len(questions)}")
        print()

        opts = [(label, val) for label, val, _, _ in q_data["options"]]
        result = _prompt(q_data["q"], opts)

        if result == "RESTART":
            return "RESTART"

        for label, val, m_score, s_score in q_data["options"]:
            if val == result:
                score_manager += m_score
                score_system += s_score
                break

        print()

    if score_manager > score_system:
        return "manager"
    elif score_system > score_manager:
        return "system"
    else:
        return "manager"


def _scaffold_manager(workspace: str, agent_name: str, enrichment_config: Optional[dict] = None):
    """Write starter files for MemoryManager setup."""
    os.makedirs(workspace, exist_ok=True)

    settings = {
        "search_limit": 10,
        "min_relevance": 0.3,
        "enricher": None,
    }
    if enrichment_config:
        settings["enricher"] = enrichment_config

    config = {
        "mode": "manager",
        "agent_name": agent_name,
        "agent_id": str(uuid.uuid4()),
        "workspace": os.path.abspath(workspace),
        "settings": settings,
    }

    config_path = os.path.join(workspace, "antaris_config.json")
    with open(config_path, "w") as f:
        json.dump(config, f, indent=2)

    starter_path = os.path.join(workspace, "example.py")
    with open(starter_path, "w") as f:
        f.write('''"""Quick start with MemoryManager."""
from parsica_memory import MemoryManager

# Create manager (auto-saves after every ingest)
mm = MemoryManager("{workspace}")

# To enable LLM enrichment (optional but recommended):
# mm = MemoryManager("{workspace}", api_key="your-key", provider="anthropic")
# Or auto-detect from environment:
# mm = MemoryManager("{workspace}", auto_enrich=True)

# Store a conversation
mm.ingest("user123", "What's the capital of France?", "The capital of France is Paris.")

# Recall relevant memories
results = mm.recall("user123", "France capital")
for r in results:
    print(r)

# Search with metadata
results = mm.search("user123", "Paris", explain=True)
for r in results:
    print(f"{{r[\'relevance\']:.2f}} - {{r[\'content\'][:80]}}")
'''.format(workspace=os.path.abspath(workspace)))

    print(f"  Config   : {config_path}")
    print(f"  Example  : {starter_path}")


def _scaffold_system(workspace: str, agent_name: str, enrichment_config: Optional[dict] = None):
    """Write starter files for MemorySystem setup."""
    os.makedirs(workspace, exist_ok=True)

    settings = {
        "half_life": 7.0,
        "tiered_storage": True,
        "graph_intelligence": True,
        "enricher": None,
    }
    if enrichment_config:
        settings["enricher"] = enrichment_config

    config = {
        "mode": "system",
        "agent_name": agent_name,
        "agent_id": str(uuid.uuid4()),
        "workspace": os.path.abspath(workspace),
        "settings": settings,
    }

    config_path = os.path.join(workspace, "antaris_config.json")
    with open(config_path, "w") as f:
        json.dump(config, f, indent=2)

    starter_path = os.path.join(workspace, "example.py")
    with open(starter_path, "w") as f:
        f.write('''"""Quick start with MemorySystem (full control)."""
from parsica_memory import MemorySystem

mem = MemorySystem(
    workspace="{workspace}",
    agent_name="{agent_name}",
    half_life=7.0,
    tiered_storage=True,
    graph_intelligence=True,
)
mem.load()

# Ingest with full provenance
mem.ingest(
    "Deployed v2.3 to production. All checks green.",
    source="deploy-log",
    session_id="session-001",
    channel_id="discord:ops",
)

# Search with cross-session recall
results = mem.search(
    "production deployment",
    session_id="session-002",
    cross_session_recall="semantic",
    source_channel="discord:ops",
)
for r in results:
    print(r.content)

# Recent memories
recent = mem.recall_recent(hours=6)
for m in recent:
    print(f"[{{m.created}}] {{m.content[:80]}}")

mem.save()
'''.format(workspace=os.path.abspath(workspace), agent_name=agent_name))

    print(f"  Config   : {config_path}")
    print(f"  Example  : {starter_path}")


# ---------------------------------------------------------------------------
# Post-setup flows
# ---------------------------------------------------------------------------

def _flow_import(workspace: str) -> Optional[dict]:
    """Step 1: Import flow.

    Returns dict with import result info, or None if skipping.
    Returns "RESTART" string to signal restart.
    """
    print()
    print("  ============================================")
    print("  Step 1 of 4 - Import Existing Memories")
    print("  ============================================")
    print()

    choice = _prompt(
        "Do you have existing memories from another system?",
        [
            ("Yes, I want to import them", "yes"),
            ("No, starting fresh", "no"),
        ],
    )

    if choice == "RESTART":
        return "RESTART"

    if choice == "no":
        return None

    # Ask source
    print()
    source_choice = _prompt(
        "Where are your memories?",
        [
            ("mem0", "mem0"),
            ("Memvid", "memvid"),
            ("Zep", "zep"),
            ("LangMem / LangChain", "langmem"),
            ("OpenAI conversation export", "openai"),
            ("Other (JSON, JSONL, SQLite, Markdown, CSV)", "auto"),
        ],
    )

    if source_choice == "RESTART":
        return "RESTART"

    # Ask for path
    print()
    while True:
        raw = input("  Path to your memories file or folder: ").strip()
        if raw.lower() == "r":
            return "RESTART"

        path = Path(raw).expanduser()
        if path.exists():
            break
        print(f"  Path not found: {raw}")
        print("  Try again, or type 'r' to start over.")
        print()

    # Dry run first
    print()
    print("  Scanning...")
    try:
        from parsica_memory.importers import detect_and_import
        dry_result = detect_and_import(
            input_path=str(path),
            workspace=workspace,
            source=source_choice,
            merge=True,
            dry_run=True,
        )
        count = dry_result.get("count", 0)
        fmt = dry_result.get("format", source_choice)
        print(f"  Found {count:,} memories ({fmt} format).")
    except Exception as e:
        print(f"  Could not scan: {e}")
        print()
        if not _confirm("  Continue anyway?"):
            return "RESTART"
        return None

    if count == 0:
        print("  No importable memories found at that path.")
        print()
        if _confirm("  Try a different path?"):
            return _flow_import(workspace)
        return None

    print()
    if not _confirm(f"  Import {count:,} memories into {workspace}?"):
        print("  Import skipped.")
        return None

    # Do the real import
    print("  Importing...")
    try:
        from parsica_memory.importers import detect_and_import
        result = detect_and_import(
            input_path=str(path),
            workspace=workspace,
            source=source_choice,
            merge=True,
            dry_run=False,
        )
        actual_count = result.get("count", count)
        skipped = result.get("skipped", 0)
        print(f"  Imported {actual_count:,} memories. Skipped {skipped:,} duplicates.")
        return {"count": actual_count, "skipped": skipped, "format": fmt}
    except Exception as e:
        print(f"  Import failed: {e}")
        return None


def _detect_env_keys() -> List[tuple]:
    """Detect API keys from environment variables.

    Returns list of (provider, key) tuples for detected keys.
    """
    from parsica_memory.enrichers import _detect_provider

    env_vars = [
        "ANTARIS_LLM_API_KEY",
        "ANTHROPIC_API_KEY",
        "OPENAI_API_KEY",
        "GOOGLE_API_KEY",
    ]

    seen_providers = set()
    found = []

    for var in env_vars:
        key = os.environ.get(var, "").strip()
        if not key:
            continue
        provider = _detect_provider(key)
        if provider == "openai-compat":
            provider = "openai"
        if provider not in seen_providers and provider in MODEL_CATALOG:
            seen_providers.add(provider)
            found.append((provider, key))

    return found


def _flow_enrichment_setup() -> Optional[dict]:
    """Steps 2-3: Enrichment setup and model selection.

    Returns dict with enrichment config, or None to skip.
    Returns "RESTART" string to signal restart.
    """
    print()
    print("  ============================================")
    print("  Step 2 of 4 - Enrichment Setup")
    print("  ============================================")
    print()
    print("  Memory enrichment uses an LLM to generate search metadata")
    print("  for better recall. It runs once per memory at write time.")
    print()

    detected = _detect_env_keys()

    if not detected:
        # No keys found
        print("  No API keys detected in environment.")
        print()
        raw = input("  Paste an API key to enable enrichment (or press Enter to skip): ").strip()
        if not raw:
            print()
            print("  Skipping enrichment. Search recall quality will be lower.")
            print("  You can enable it later by editing antaris_config.json.")
            print()
            return None
        if raw.lower() == "r":
            return "RESTART"

        from parsica_memory.enrichers import _detect_provider
        provider = _detect_provider(raw)
        if provider == "openai-compat":
            provider = "openai"
        if provider not in MODEL_CATALOG:
            print(f"  Unrecognized key format. Treating as OpenAI-compatible.")
            provider = "openai"
        detected = [(provider, raw)]

    # Show detected providers
    provider_names = [PROVIDER_DISPLAY.get(p, p.title()) for p, _ in detected]
    providers_str = " and ".join(provider_names)
    print(f"  I detected your {providers_str} API key.")
    print()

    choice = _prompt(
        "What would you like to do?",
        [
            ("Use my current key (simplest)", "use"),
            ("Use a different key (cheaper models save cost, quality may vary)", "replace"),
            ("Skip enrichment for now\n      Note: search recall quality is lower without enrichment.", "skip"),
        ],
    )

    if choice == "RESTART":
        return "RESTART"

    if choice == "skip":
        print()
        print("  Enrichment skipped.")
        return None

    if choice == "replace":
        print()
        raw = input("  Paste your API key: ").strip()
        if raw.lower() == "r":
            return "RESTART"
        if not raw:
            print("  No key entered. Skipping enrichment.")
            return None

        from parsica_memory.enrichers import _detect_provider
        provider = _detect_provider(raw)
        if provider == "openai-compat":
            provider = "openai"
        if provider not in MODEL_CATALOG:
            provider = "openai"
        detected = [(provider, raw)]

    # Step 3: Model selection
    result = _flow_model_selection(detected)
    return result


def _flow_model_selection(detected_keys: List[tuple]) -> Optional[dict]:
    """Step 3: Pick an enrichment model.

    Returns enrichment config dict or None.
    Returns "RESTART" string to signal restart.
    """
    print()
    print("  ============================================")
    print("  Step 3 of 4 - Model Selection")
    print("  ============================================")
    print()
    print("  Pick a model for enrichment:")
    print()

    # Build list of (provider, key, model_info) for available models
    available = []
    for provider, key in detected_keys:
        models = MODEL_CATALOG.get(provider, [])
        for m in models:
            available.append((provider, key, m))

    if not available:
        print("  No models available for detected keys.")
        return None

    # Print header
    print(f"  {'Model':<26} {'Cost/1K memories':<20} {'Quality':<12}")
    print()

    options = []
    for i, (provider, key, m) in enumerate(available, 1):
        tag_str = ""
        if m["tags"]:
            tag_str = " <- " + ", ".join(m["tags"])
        label = f"{m['name']:<26} ~${m['cost_per_1k']:.2f}{'':>13} {m['quality']:<12}{tag_str}"
        options.append((label, str(i)))
        print(f"    [{i}] {m['name']:<26} ~${m['cost_per_1k']:.2f}             {m['quality']:<12}{tag_str}")

    print()
    print("    [r] Start over")
    print()

    while True:
        choice = input("  Your choice: ").strip().lower()
        if choice == "r":
            return "RESTART"
        try:
            idx = int(choice) - 1
            if 0 <= idx < len(available):
                provider, key, model_info = available[idx]
                print()
                print(f"  Using {model_info['name']} ({PROVIDER_DISPLAY.get(provider, provider)})")
                return {
                    "provider": provider,
                    "api_key": key,
                    "model": model_info["id"],
                    "model_name": model_info["name"],
                    "cost_per_1k": model_info["cost_per_1k"],
                }
        except ValueError:
            pass
        print(f"  Please enter a number 1-{len(available)} or 'r' to start over.")


def _flow_retroactive_enrichment(
    workspace: str,
    enrichment_config: dict,
    import_result: Optional[dict],
) -> Optional[str]:
    """Step 4: Offer retroactive enrichment for imported memories.

    Only runs if memories were imported.

    Returns "RESTART" if the user wants to restart, None otherwise.
    """
    if not import_result or not enrichment_config:
        return None

    from parsica_memory.parallel_enricher import count_unenriched, estimate_minutes

    print()
    print("  ============================================")
    print("  Step 4 of 4 - Retroactive Enrichment")
    print("  ============================================")
    print()

    unenriched = count_unenriched(workspace)
    if unenriched == 0:
        print("  All memories are already enriched. Nothing to do.")
        return None

    api_key = enrichment_config.get("api_key", "")
    provider = enrichment_config.get("provider", "")
    provider_name = PROVIDER_DISPLAY.get(provider, provider.title())

    print(f"  You have {unenriched:,} un-enriched memories.")
    print()

    choice = _prompt(
        "What would you like to do?",
        [
            ("Enrich only (adds search metadata)", "enrich"),
            ("Enrich + Decompose (metadata AND atomic facts - best recall)", "enrich+decompose"),
            ("Skip for now", "skip"),
        ],
    )

    if choice == "RESTART" or choice == "skip":
        if choice == "RESTART":
            return "RESTART"  # Issue 3 fix: propagate restart signal
        print()
        print("  Retroactive enrichment skipped.")
        print("  You can run it later with:")
        print(f"    python -m parsica_memory enrich --workspace {workspace}")
        return None

    enrich_mode = choice
    all_keys = [api_key]

    # Show initial time estimate
    mins_enrich = estimate_minutes(unenriched, all_keys)
    print()
    print(f"  Estimated time with your current key ({provider_name}):")
    print(f"    Enrich only:          ~{mins_enrich} min")
    print(f"    Enrich + Decompose:   ~{mins_enrich} min (same time - one LLM call does both)")
    print()

    # Parallel key offer
    speed_choice = _prompt(
        "Want to speed this up?",
        [
            ("Run with current key (background)", "current"),
            ("Add additional API keys for parallel processing", "parallel"),
        ],
    )

    if speed_choice == "RESTART":
        return "RESTART"

    if speed_choice == "parallel":
        print()
        print("  Paste additional API keys (one per line).")
        print("  Press Enter on a blank line when done.")
        print("  Type 'r' to start over.")
        print()

        extra_keys = []
        while True:
            line = input("  Key: ").strip()
            if line.lower() == "r":
                return "RESTART"
            if not line:
                break
            extra_keys.append(line)

        if extra_keys:
            all_keys = [api_key] + extra_keys
            mins_updated = estimate_minutes(unenriched, all_keys)
            print()
            print(f"  Updated estimate with {len(all_keys)} keys: ~{mins_updated} min")
            print()

    # Launch background process
    _flow_start_background(workspace, all_keys, enrich_mode, enrichment_config.get("model"))


def _flow_start_background(
    workspace: str,
    api_keys: List[str],
    mode: str,
    model: Optional[str],
) -> None:
    """Step 5: Launch enrichment in background and show status command."""
    print()
    print("  Starting enrichment in background...")

    try:
        from parsica_memory.parallel_enricher import ParallelEnricher
        keys_config = []
        for key in api_keys:
            from parsica_memory.enrichers import _detect_provider
            provider = _detect_provider(key)
            if provider == "openai-compat":
                provider = "openai"
            entry = {"key": key, "provider": provider}
            if model:
                entry["model"] = model
            keys_config.append(entry)

        enricher = ParallelEnricher(
            workspace=workspace,
            keys=keys_config,
            decompose=(mode == "enrich+decompose"),
        )
        job_id = enricher.run_background()

        # Issue 2 fix: block with progress display so the non-daemon thread
        # completes before the wizard exits. Ctrl+C moves it to background.
        import time as _time
        print()
        print("  Enrichment running...")
        print("  Press Ctrl+C to move it to background.")
        print()
        try:
            while True:
                st = enricher.status(job_id)
                if st.get("state") == "done" or st.get("status") == "complete":
                    enriched = st.get("enriched", 0)
                    facts = st.get("facts_created", 0)
                    print(f"\r  Complete! Enriched {enriched} memories, created {facts} facts.    ")
                    break
                enriched = st.get("enriched", 0)
                total_ct = st.get("total", 0)
                pct = (enriched / total_ct * 100) if total_ct else 0
                print(f"\r  Progress: {enriched}/{total_ct} ({pct:.0f}%)    ", end="", flush=True)
                _time.sleep(2)
        except KeyboardInterrupt:
            print("\n  Enrichment continues in background.")
            print(f"  Check progress: python -m parsica_memory status --workspace {workspace}")

    except Exception as e:
        print(f"  Could not start background process: {e}")
        print("  You can run enrichment manually later:")
        print(f"    python -m parsica_memory enrich --workspace {workspace}")


# ---------------------------------------------------------------------------
# Main wizard entry
# ---------------------------------------------------------------------------

def run_wizard(workspace: str = ".", agent_name: Optional[str] = None) -> dict:
    """Run the interactive setup wizard.

    Returns dict with keys: mode ("manager" or "system"), workspace, agent_name
    """
    if not agent_name:
        import socket
        hostname = socket.gethostname().split(".")[0].lower()
        agent_name = f"agent-{hostname}"

    while True:
        _clear()
        _banner()
        _explain_options()

        choice = _prompt(
            "Which setup do you want?",
            [
                ("MemoryManager (multi-user, batteries included)", "manager"),
                ("MemorySystem (single agent, full control)", "system"),
                ("I don't know, guide me!", "guided"),
            ],
            allow_restart=False,
        )

        if choice == "guided":
            print()
            print("  Let me ask a few questions to help you decide.")
            print()
            result = _guided_flow()
            if result == "RESTART":
                continue

            recommendation = "MemoryManager" if result == "manager" else "MemorySystem"
            print()
            print(f"  Based on your answers, I recommend: {recommendation}")
            print()
            if not _confirm("Go with this recommendation?"):
                continue
            choice = result

        # Confirm workspace
        print()
        ws_input = input(f"  Workspace path [{workspace}]: ").strip()
        if ws_input:
            workspace = ws_input

        name_input = input(f"  Agent name [{agent_name}]: ").strip()
        if name_input:
            agent_name = name_input

        print()
        print(f"  Mode      : {'MemoryManager' if choice == 'manager' else 'MemorySystem'}")
        print(f"  Workspace : {os.path.abspath(workspace)}")
        print(f"  Agent     : {agent_name}")
        print()

        if not _confirm("Create this setup?"):
            if _confirm("Start over?"):
                continue
            print("  Cancelled.")
            return {"mode": None}

        # Scaffold (enrichment config added later)
        print()
        if choice == "manager":
            _scaffold_manager(workspace, agent_name)
        else:
            _scaffold_system(workspace, agent_name)

        print()
        print("  Setup complete!")
        print()

        # ----------------------------------------------------------------
        # Post-setup: import flow
        # ----------------------------------------------------------------
        import_result = _flow_import(workspace)
        if import_result == "RESTART":
            continue

        # ----------------------------------------------------------------
        # Post-setup: enrichment setup
        # ----------------------------------------------------------------
        enrichment_config = _flow_enrichment_setup()
        if enrichment_config == "RESTART":
            continue

        # Update config on disk with enrichment settings if chosen
        if enrichment_config:
            config_path = os.path.join(workspace, "antaris_config.json")
            try:
                with open(config_path) as f:
                    config = json.load(f)
                config["settings"]["enricher"] = {
                    "provider": enrichment_config["provider"],
                    "model": enrichment_config["model"],
                }
                with open(config_path, "w") as f:
                    json.dump(config, f, indent=2)
            except Exception:
                pass  # Non-fatal

        # ----------------------------------------------------------------
        # Post-setup: retroactive enrichment (if imported memories exist)
        # ----------------------------------------------------------------
        if import_result and enrichment_config:
            # Issue 3 & 7 fix: check return value; "RESTART" means loop again
            result = _flow_retroactive_enrichment(
                workspace, enrichment_config, import_result
            )
            if result == "RESTART":
                continue
        else:
            if import_result and not enrichment_config:
                print()
                print("  Tip: Enable enrichment later to improve recall on your imported memories.")
                print(f"    python -m parsica_memory enrich --workspace {workspace}")

        # ----------------------------------------------------------------
        # Final summary
        # ----------------------------------------------------------------
        print()
        print("  ============================================")
        print("  All done!")
        print("  ============================================")
        print()
        print("  Next steps:")
        print(f"    1. Check the example: {os.path.join(os.path.abspath(workspace), 'example.py')}")
        print(f"    2. Read the docs: https://github.com/Antaris-Analytics-LLC/Parsica-Memory#readme")
        print()

        return {
            "mode": choice,
            "workspace": os.path.abspath(workspace),
            "agent_name": agent_name,
            "enrichment": enrichment_config,
            "import": import_result,
        }
