from datetime import datetime, timedelta, timezone

from parsica_memory.core_v4 import MemorySystemV4


def _week_shard_name(dt: datetime) -> str:
    year, week, _ = dt.astimezone(timezone.utc).isocalendar()
    return f"memories_{year}-W{week:02d}.jsonl"


def test_time_shard_save_refreshes_protected_tiers_from_disk_before_rewrite(tmp_path):
    ws = str(tmp_path)
    mem = MemorySystemV4(
        workspace=ws,
        use_sharding=False,
        sharding=True,
        tiered_storage=True,
        use_indexing=False,
        graph_intelligence=False,
        quality_routing=False,
        semantic_expansion=False,
    )

    mem.ingest("Fresh hot-tier entry that should remain after save.", source="hot")
    mem.save()

    warm_dt = datetime.now(timezone.utc) - timedelta(days=7)
    warm_name = _week_shard_name(warm_dt)
    warm_path = tmp_path / warm_name
    warm_entry = {
        "content": "Warm-tier entry created by another process after startup.",
        "source": "external",
        "category": "general",
        "created": warm_dt.isoformat(),
        "hash": "warm-external-entry",
    }
    warm_path.write_text(__import__('json').dumps(warm_entry) + "\n", encoding="utf-8")

    assert warm_path.exists()
    assert warm_name not in mem._warm_shard_names

    mem.save()

    assert warm_path.exists(), "save() should not delete warm shards discovered on disk"
    contents = warm_path.read_text(encoding="utf-8")
    assert "Warm-tier entry created by another process after startup." in contents
