"""
antaris-suite v4.7.0 — Comprehensive End-to-End Tests
======================================================

Validates the three new features working together in realistic
workflows, not just unit-level isolation.

Features covered:
  1. Tiered Storage — startup load, warm fallback, cold opt-in,
     shard hash tracking, backward compat
  2. Knowledge Ingestion — CSV, JSON, SQLite, URL (mocked),
     incremental dedup, manifest tracking
  3. Cross-Session Context — multi-agent state, directed_at detection,
     expiry, file locking, disabled-by-default
  4. Integration — all three features used together in a realistic
     multi-session agent workflow
"""

import csv
import json
import os
import sqlite3
import sys
import tempfile
import time
from datetime import datetime, timedelta, timezone
from typing import List
from unittest.mock import patch, MagicMock

import pytest

from parsica_memory import MemorySystem, MemoryEntry
from parsica_memory.tiers import TierManager, HOT_DAYS, WARM_DAYS
from parsica_memory.ingest_structured import StructuredIngester
from parsica_memory.ingest_manifest import IngestManifest
from parsica_memory.ingest_web import WebCrawler


# ── Helpers ─────────────────────────────────────────────────────────────────


def _iso(days_ago: float = 0) -> str:
    return (datetime.now(timezone.utc) - timedelta(days=days_ago)).isoformat()


def _write_shard(ws: str, days_ago: float, entries: List[dict]) -> str:
    dt = datetime.now(timezone.utc) - timedelta(days=days_ago)
    y, w, _ = dt.isocalendar()
    name = f"memories_{y}-W{w:02d}.jsonl"
    path = os.path.join(ws, name)
    mode = "a" if os.path.exists(path) else "w"
    with open(path, mode) as f:
        for e in entries:
            if "created" not in e:
                e["created"] = _iso(days_ago)
            if "last_accessed" not in e:
                e["last_accessed"] = e["created"]
            f.write(json.dumps(e) + "\n")
    return path


def _mem(content: str, days_ago: float = 0) -> dict:
    from parsica_memory.entry import MemoryEntry
    e = MemoryEntry(content=content)
    e.created = _iso(days_ago)
    e.last_accessed = e.created
    return e.to_dict()


# ════════════════════════════════════════════════════════════════════════════
# FEATURE 1: TIERED STORAGE
# ════════════════════════════════════════════════════════════════════════════


class TestTieredStorageE2E:
    """End-to-end tiered storage scenarios."""

    def test_hot_only_startup_leaves_warm_and_cold_unloaded(self):
        """Warm and cold shards must not be in self.memories at startup."""
        with tempfile.TemporaryDirectory() as ws:
            _write_shard(ws, 0, [_mem("today's standup", 0)])       # hot
            _write_shard(ws, 14, [_mem("last week planning", 14)])  # warm (must be 10+ days for shard_end to age out)
            _write_shard(ws, 30, [_mem("archived decision", 30)])   # cold

            mem = MemorySystem(ws, use_sharding=False, sharding=True,
                               tiered_storage=True, agent_name="test-agent")
            contents = {m.content for m in mem.memories}
            assert "today's standup" in contents, "hot shard must be loaded"
            assert "last week planning" not in contents, "warm shard must NOT load at startup"
            assert "archived decision" not in contents, "cold shard must NOT load at startup"

    def test_warm_fallback_triggers_on_sparse_hot_results(self):
        """Warm shard is loaded transparently when hot returns < 3 results."""
        with tempfile.TemporaryDirectory() as ws:
            # Hot has nothing relevant
            _write_shard(ws, 0, [_mem("breakfast menu ideas", 0)])
            # Warm has the answer (14+ days ago to land outside hot tier)
            _write_shard(ws, 14, [_mem("quarterly budget review meeting", 14)])

            mem = MemorySystem(ws, use_sharding=False, sharding=True,
                               tiered_storage=True, agent_name="test-agent")
            results = mem.search("quarterly budget review")
            contents = [r.content for r in results]
            assert "quarterly budget review meeting" in contents, \
                "warm fallback must surface warm-tier results"

    def test_cold_tier_excluded_by_default(self):
        """Cold entries must never appear in default search."""
        with tempfile.TemporaryDirectory() as ws:
            _write_shard(ws, 60, [_mem("ancient project notes from two months ago", 60)])

            mem = MemorySystem(ws, use_sharding=False, sharding=True,
                               tiered_storage=True, agent_name="test-agent")
            results = mem.search("ancient project notes")
            assert all("ancient project notes" not in r.content for r in results), \
                "cold entries must not appear in default search"

    def test_include_cold_surfaces_cold_entries(self):
        """include_cold=True must search cold-tier shards."""
        with tempfile.TemporaryDirectory() as ws:
            _write_shard(ws, 60, [_mem("ancient project notes from two months ago", 60)])

            mem = MemorySystem(ws, use_sharding=False, sharding=True,
                               tiered_storage=True, agent_name="test-agent")
            results = mem.search("ancient project notes", include_cold=True)
            assert any("ancient project notes" in r.content for r in results), \
                "include_cold=True must surface cold-tier entries"

    def test_shard_hash_persists_across_restarts(self):
        """TierManager must persist shard hashes and restore them on re-init."""
        with tempfile.TemporaryDirectory() as ws:
            _write_shard(ws, 0, [_mem("persistence test", 0)])
            mgr1 = TierManager(ws)
            shards = [f for f in os.listdir(ws) if f.endswith(".jsonl")]
            mgr1.save_hashes(shards)

            mgr2 = TierManager(ws)  # fresh instance
            assert mgr2._known_hashes, "hashes must survive manager restart"
            changed = mgr2.get_changed_shards(shards)
            assert changed == [], "unmodified shards must not appear as changed"

    def test_warm_fallback_does_not_corrupt_hot_index(self):
        """After warm fallback, a second hot search must still work correctly."""
        with tempfile.TemporaryDirectory() as ws:
            _write_shard(ws, 0, [_mem("standup notes today", 0)])
            _write_shard(ws, 7, [_mem("retrospective from last week", 7)])

            mem = MemorySystem(ws, use_sharding=False, sharding=True,
                               tiered_storage=True, agent_name="test-agent")
            # Trigger warm fallback
            mem.search("retrospective")
            # Hot search must still work
            results = mem.search("standup notes")
            assert any("standup notes today" in r.content for r in results), \
                "hot index must still work after warm fallback"

    def test_tiered_disabled_loads_full_window(self):
        """tiered_storage=False must load the full v4.6 2-week window."""
        with tempfile.TemporaryDirectory() as ws:
            _write_shard(ws, 0, [_mem("recent", 0)])
            _write_shard(ws, 10, [_mem("ten days ago", 10)])

            mem = MemorySystem(ws, use_sharding=False, sharding=True,
                               tiered_storage=False, agent_name="test-agent")
            contents = {m.content for m in mem.memories}
            assert "recent" in contents
            assert "ten days ago" in contents, \
                "tiered_storage=False must load entries from the full 2-week window"

    def test_new_ingest_lands_in_hot_shard(self):
        """Freshly ingested memories must be searchable immediately."""
        with tempfile.TemporaryDirectory() as ws:
            mem = MemorySystem(ws, use_sharding=False, sharding=True,
                               tiered_storage=True, agent_name="test-agent")
            mem.load()
            mem.ingest("brand new insight about async workflows")
            mem.save()
            results = mem.search("async workflows")
            assert any("async workflows" in r.content for r in results), \
                "freshly ingested content must be immediately searchable"


# ════════════════════════════════════════════════════════════════════════════
# FEATURE 2: KNOWLEDGE INGESTION
# ════════════════════════════════════════════════════════════════════════════


class TestKnowledgeIngestionE2E:
    """End-to-end knowledge ingestion from structured data and web."""

    # ── CSV ───────────────────────────────────────────────────────────────

    def test_csv_basic_ingest(self):
        """StructuredIngester.from_csv must parse rows into memory chunks."""
        with tempfile.TemporaryDirectory() as ws:
            csv_path = os.path.join(ws, "notes.csv")
            with open(csv_path, "w", newline="") as f:
                writer = csv.DictWriter(f, fieldnames=["title", "body", "date"])
                writer.writeheader()
                writer.writerow({"title": "Sprint Review", "body": "Team shipped 5 features", "date": "2026-03-01"})
                writer.writerow({"title": "Bug Fix", "body": "Fixed critical auth issue", "date": "2026-03-02"})

            ingester = StructuredIngester()
            chunks = ingester.from_csv(csv_path, text_columns=["title", "body"])
            assert len(chunks) == 2
            texts = [c["text"] for c in chunks]
            assert any("Sprint Review" in t for t in texts)
            assert any("auth issue" in t for t in texts)

    def test_csv_auto_selects_text_columns(self):
        """When text_columns=None, ingester must auto-select string columns."""
        with tempfile.TemporaryDirectory() as ws:
            csv_path = os.path.join(ws, "data.csv")
            with open(csv_path, "w", newline="") as f:
                writer = csv.DictWriter(f, fieldnames=["id", "note"])
                writer.writeheader()
                writer.writerow({"id": "1", "note": "important observation"})

            ingester = StructuredIngester()
            chunks = ingester.from_csv(csv_path)
            assert any("important observation" in c["text"] for c in chunks)

    def test_csv_empty_file_returns_empty(self):
        """Empty CSV must return empty list, not raise."""
        with tempfile.TemporaryDirectory() as ws:
            csv_path = os.path.join(ws, "empty.csv")
            with open(csv_path, "w") as f:
                f.write("col1,col2\n")
            ingester = StructuredIngester()
            chunks = ingester.from_csv(csv_path)
            assert chunks == []

    # ── JSON ──────────────────────────────────────────────────────────────

    def test_json_list_ingest(self):
        """from_json must handle a top-level list of objects."""
        with tempfile.TemporaryDirectory() as ws:
            json_path = os.path.join(ws, "facts.json")
            with open(json_path, "w") as f:
                json.dump([
                    {"fact": "Python was created in 1991"},
                    {"fact": "The web was invented at CERN"},
                ], f)

            ingester = StructuredIngester()
            chunks = ingester.from_json(json_path)
            assert len(chunks) == 2
            texts = [c["text"] for c in chunks]
            assert any("Python" in t for t in texts)

    def test_json_dict_ingest(self):
        """from_json must handle a top-level dict with list value."""
        with tempfile.TemporaryDirectory() as ws:
            json_path = os.path.join(ws, "wrapped.json")
            with open(json_path, "w") as f:
                json.dump({"items": [{"note": "first"}, {"note": "second"}]}, f)

            ingester = StructuredIngester()
            chunks = ingester.from_json(json_path)
            assert len(chunks) >= 1  # at least the wrapped content surfaced

    def test_json_missing_file_returns_empty(self):
        """Missing JSON file must return empty list, not raise."""
        ingester = StructuredIngester()
        chunks = ingester.from_json("/tmp/definitely_does_not_exist_antaris.json")
        assert chunks == []

    # ── SQLite ────────────────────────────────────────────────────────────

    def test_sqlite_basic_query(self):
        """from_sqlite must execute query and return rows as chunks."""
        with tempfile.TemporaryDirectory() as ws:
            db_path = os.path.join(ws, "notes.db")
            conn = sqlite3.connect(db_path)
            conn.execute("CREATE TABLE notes (id INTEGER PRIMARY KEY, content TEXT)")
            conn.execute("INSERT INTO notes VALUES (1, 'Database architecture decision')")
            conn.execute("INSERT INTO notes VALUES (2, 'Scaling strategy for v5.0')")
            conn.commit()
            conn.close()

            ingester = StructuredIngester()
            chunks = ingester.from_sqlite(db_path, "SELECT content FROM notes")
            assert len(chunks) == 2
            texts = [c["text"] for c in chunks]
            assert any("Database architecture" in t for t in texts)
            assert any("Scaling strategy" in t for t in texts)

    def test_sqlite_bad_query_returns_empty(self):
        """Bad SQL query must return empty list, not raise."""
        with tempfile.TemporaryDirectory() as ws:
            db_path = os.path.join(ws, "empty.db")
            sqlite3.connect(db_path).close()
            ingester = StructuredIngester()
            chunks = ingester.from_sqlite(db_path, "SELECT * FROM nonexistent_table")
            assert chunks == []

    # ── Manifest / IngestManifest ─────────────────────────────────────────

    def test_manifest_tracks_ingested_source(self):
        """IngestManifest must persist source → hash mapping across restarts."""
        with tempfile.TemporaryDirectory() as ws:
            manifest = IngestManifest(ws)
            manifest.load()
            manifest.update("https://example.com/page", "abc123", ["abc123"])
            manifest.save()

            manifest2 = IngestManifest(ws)
            manifest2.load()
            entry = manifest2.get("https://example.com/page")
            assert entry is not None, "manifest must persist source URL entries"
            assert "abc123" in manifest2.get_known_hashes("https://example.com/page")

    def test_manifest_deduplicates_on_rehash(self):
        """All entry_ids passed to update() must appear in get_known_hashes()."""
        with tempfile.TemporaryDirectory() as ws:
            manifest = IngestManifest(ws)
            manifest.load()
            # content_hash is the "last" hash; entry_ids are all chunk hashes
            manifest.update("https://example.com/page", "hash2", ["hash1", "hash2"])
            manifest.save()

            manifest2 = IngestManifest(ws)
            manifest2.load()
            known = manifest2.get_known_hashes("https://example.com/page")
            assert "hash1" in known, \
                "all entry_ids must be tracked as known hashes for dedup"
            assert "hash2" in known, \
                "content_hash must also be in known hashes"

    def test_manifest_remove_clears_entry(self):
        """remove() must delete a source entry from the manifest."""
        with tempfile.TemporaryDirectory() as ws:
            manifest = IngestManifest(ws)
            manifest.load()
            manifest.update("https://example.com/page", "xyz", ["xyz"])
            manifest.save()
            manifest.remove("https://example.com/page")
            manifest.save()

            manifest2 = IngestManifest(ws)
            manifest2.load()
            assert manifest2.get("https://example.com/page") is None

    # ── WebCrawler ────────────────────────────────────────────────────────

    def test_webcrawler_parses_html_chunks(self):
        """WebCrawler._extract_chunks must parse HTML text into chunks."""
        crawler = WebCrawler()
        html = """
        <html><body>
        <h1>AI Memory Systems</h1>
        <p>Antaris Memory is a zero-dependency memory system for AI agents.
        It provides fast BM25 search with optional LLM enrichment.</p>
        <p>The system supports tiered storage for efficient RAM usage.</p>
        </body></html>
        """
        chunks = crawler._extract_chunks(html, "https://example.com/test")
        assert len(chunks) >= 1
        all_text = " ".join(c["text"] for c in chunks)
        assert "Antaris Memory" in all_text
        assert "BM25" in all_text

    def test_webcrawler_deduplicates_by_content_hash(self):
        """Identical HTML content must produce identical content_hash."""
        crawler = WebCrawler()
        # Need sufficient text length (>30 chars) to produce chunks
        body_text = "Antaris Analytics builds zero-dependency AI memory infrastructure for modern agents."
        html = f"<html><body><p>{body_text}</p></body></html>"
        chunks1 = crawler._extract_chunks(html, "https://a.com")
        chunks2 = crawler._extract_chunks(html, "https://b.com")
        assert len(chunks1) >= 1, "long enough HTML must produce at least one chunk"
        assert chunks1[0]["content_hash"] == chunks2[0]["content_hash"], \
            "same text must produce same content_hash for deduplication"

    def test_webcrawler_extract_links(self):
        """_extract_links must find href targets in the same domain."""
        crawler = WebCrawler()
        html = """
        <html><body>
        <a href="/about">About</a>
        <a href="/docs/api">API Docs</a>
        <a href="https://external.com">External</a>
        </body></html>
        """
        links = crawler._extract_links(html, "https://example.com/home")
        assert any("about" in l for l in links)
        assert any("docs" in l for l in links)

    def test_webcrawler_crawl_with_mock_http(self):
        """Full crawl() with mocked _fetch must ingest page content."""
        crawler = WebCrawler()
        html = """
        <html><body>
        <h1>Test Page for Antaris Analytics AI Memory</h1>
        <p>Antaris Analytics builds zero-dependency AI memory infrastructure for modern agents.
        The system provides fast BM25 search, optional LLM enrichment, and tiered storage.</p>
        </body></html>
        """
        # Mock _fetch and _check_robots directly to avoid network calls
        with patch.object(crawler, "_fetch", return_value=html):
            with patch.object(crawler, "_check_robots", return_value=True):
                chunks = crawler.crawl("https://example.com/test", depth=1)

        assert len(chunks) >= 1, "mocked crawl must produce at least one chunk"
        all_text = " ".join(c["text"] for c in chunks)
        assert "Antaris Analytics" in all_text

    # ── MemorySystem.ingest_data_file integration ──────────────────────────

    def test_memory_system_ingest_csv_via_api(self):
        """MemorySystem.ingest_data_file('path.csv') must index CSV content."""
        with tempfile.TemporaryDirectory() as ws:
            csv_path = os.path.join(ws, "knowledge.csv")
            with open(csv_path, "w", newline="") as f:
                writer = csv.DictWriter(f, fieldnames=["topic", "detail"])
                writer.writeheader()
                writer.writerow({"topic": "Reinforcement Learning", "detail": "RL agents learn via reward signals"})

            mem = MemorySystem(ws, agent_name="test-agent")
            mem.load()
            result = mem.ingest_data_file(csv_path, format="csv")
            mem.save()

            assert result.get("ingested", 0) > 0, "ingest_data_file must ingest at least one chunk"
            results = mem.search("reward signals")
            assert any("reward" in r.content.lower() for r in results), \
                "ingested CSV content must be searchable"

    def test_memory_system_ingest_json_via_api(self):
        """MemorySystem.ingest_data_file('path.json') must index JSON content."""
        with tempfile.TemporaryDirectory() as ws:
            json_path = os.path.join(ws, "facts.json")
            with open(json_path, "w") as f:
                json.dump([{"fact": "Transformer architecture changed NLP forever"}], f)

            mem = MemorySystem(ws, agent_name="test-agent")
            mem.load()
            result = mem.ingest_data_file(json_path, format="json")
            mem.save()

            assert result.get("ingested", 0) > 0
            results = mem.search("Transformer architecture")
            assert any("Transformer" in r.content for r in results)

    def test_memory_system_ingest_sqlite_via_api(self):
        """MemorySystem.ingest_data_file('path.db') must index SQLite rows."""
        with tempfile.TemporaryDirectory() as ws:
            db_path = os.path.join(ws, "kb.db")
            conn = sqlite3.connect(db_path)
            conn.execute("CREATE TABLE kb (entry TEXT)")
            conn.execute("INSERT INTO kb VALUES ('LangChain is a framework for LLM apps')")
            conn.commit()
            conn.close()

            mem = MemorySystem(ws, agent_name="test-agent")
            mem.load()
            result = mem.ingest_data_file(db_path, format="sqlite",
                                           query="SELECT entry FROM kb")
            mem.save()

            assert result.get("ingested", 0) > 0
            results = mem.search("LangChain framework")
            assert any("LangChain" in r.content for r in results)

    def test_source_url_provenance_on_entry(self):
        """Ingested entries must carry source_url provenance field."""
        with tempfile.TemporaryDirectory() as ws:
            csv_path = os.path.join(ws, "src.csv")
            with open(csv_path, "w", newline="") as f:
                writer = csv.DictWriter(f, fieldnames=["note"])
                writer.writeheader()
                writer.writerow({"note": "provenance tracking test entry"})

            mem = MemorySystem(ws, agent_name="test-agent")
            mem.load()
            mem.ingest_data_file(csv_path, format="csv")
            mem.save()

            results = mem.search("provenance tracking")
            if results:
                # At least one result should have source_url set
                has_provenance = any(
                    getattr(r, "source_url", None) is not None for r in results
                )
                assert has_provenance, "ingested entries must have source_url set"


# ════════════════════════════════════════════════════════════════════════════
# FEATURE 3: CROSS-SESSION CONTEXT
# ════════════════════════════════════════════════════════════════════════════


@pytest.mark.skipif(
    not os.path.exists(os.path.join(
        os.path.dirname(__file__),
        "..", "..", "antaris-openclaw-plugin", "pipeline_bridge.py"
    )),
    reason="Requires sibling antaris-openclaw-plugin repo with CrossSessionStateManager",
)
class TestCrossSessionContextE2E:
    """End-to-end cross-session context tests using the bridge module directly.

    CrossSessionStateManager API:
      register_agent(agent_id, bot_id)
      write_turn(session_key, agent_id, display_name, user_id,
                 directed_at, was_instruction, summary, topics=None)
      read_other_sessions(current_session_key, current_agent_id=None,
                          max_age_seconds=None) -> List[dict]
      get_full_state() -> dict {"version":1, "agents":{}, "sessions":{}}

    Note: disabled-by-default is enforced at the plugin (JS) level,
    not in the Python class. The class itself is always functional.
    """

    def _get_manager(self, ws: str):
        """Import and instantiate CrossSessionStateManager from bridge."""
        import importlib.util
        bridge_path = os.path.join(
            os.path.dirname(__file__),
            "..", "..", "antaris-openclaw-plugin", "pipeline_bridge.py"
        )
        bridge_path = os.path.normpath(bridge_path)
        spec = importlib.util.spec_from_file_location("pipeline_bridge_cse2e", bridge_path)
        module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(module)
        if not hasattr(module, 'CrossSessionStateManager'):
            pytest.skip("CrossSessionStateManager not found in pipeline_bridge")
        return module.CrossSessionStateManager(ws)

    def _write(self, mgr, session_key: str, agent_id: str, summary: str,
               directed_at=None):
        """Helper — call write_turn with all required positional args."""
        mgr.write_turn(
            session_key,   # session_key
            agent_id,      # agent_id
            agent_id,      # display_name
            "user-123",    # user_id
            directed_at,   # directed_at
            False,         # was_instruction
            summary,       # summary
        )

    def test_register_agent_persists(self):
        """register_agent must store agent identity in the shared state file."""
        with tempfile.TemporaryDirectory() as ws:
            mgr = self._get_manager(ws)
            mgr.register_agent("moro", "bot-moro-id")

            state = mgr.get_full_state()
            assert "moro" in state.get("agents", {}), \
                "registered agent must appear in state"
            assert state["agents"]["moro"]["bot_id"] == "bot-moro-id"

    def test_multi_agent_turn_sharing(self):
        """Two agents writing to the same file must see each other's turns."""
        with tempfile.TemporaryDirectory() as ws:
            mgr1 = self._get_manager(ws)
            mgr2 = self._get_manager(ws)

            mgr1.register_agent("moro", "bot-moro")
            mgr2.register_agent("san", "bot-san")

            self._write(mgr1, "session-moro", "moro", "deployment pipeline all green")
            self._write(mgr2, "session-san", "san", "benchmark results look good")

            # moro reads san's session
            other = mgr1.read_other_sessions("session-moro")
            assert isinstance(other, list), "read_other_sessions must return a list"
            all_summaries = " ".join(t.get("summary", "") for t in other)
            assert "benchmark" in all_summaries, \
                "moro must be able to read san's turn summaries"

    def test_read_other_sessions_excludes_own(self):
        """read_other_sessions must NOT return the calling session's own turns."""
        with tempfile.TemporaryDirectory() as ws:
            mgr = self._get_manager(ws)
            mgr.register_agent("moro", "botM")
            self._write(mgr, "session-moro", "moro", "moro private summary")

            other = mgr.read_other_sessions("session-moro")
            for turn in other:
                assert "moro private summary" not in turn.get("summary", ""), \
                    "own session turns must not appear in read_other_sessions"

    def test_directed_at_stored_in_turn(self):
        """directed_at value must be persisted in the turn record."""
        with tempfile.TemporaryDirectory() as ws:
            mgr = self._get_manager(ws)
            mgr.register_agent("moro", "bot-moro")
            self._write(mgr, "session-moro", "moro",
                        "san please run the benchmark", directed_at="san")

            state = mgr.get_full_state()
            turns = state["sessions"]["session-moro"]["turns"]
            assert len(turns) >= 1
            assert turns[-1]["directed_at"] == "san", \
                "directed_at must be stored in the turn"

    def test_expiry_prunes_old_turns(self):
        """Turns older than max_age must be pruned on next write."""
        with tempfile.TemporaryDirectory() as ws:
            mgr = self._get_manager(ws)
            mgr.register_agent("moro", "botM")

            # Manually inject an old turn (3h ago = older than 2h max_age)
            import time as time_mod
            old_ts = int(time_mod.time()) - 3 * 3600  # 3 hours ago
            old_data = {
                "version": 1, "agents": {},
                "sessions": {
                    "session-moro": {
                        "agent_id": "moro", "display": "moro",
                        "last_updated": old_ts,
                        "turns": [{"ts": old_ts, "summary": "old turn",
                                   "directed_at": None, "was_instruction": False,
                                   "topics": [], "user_id": ""}]
                    }
                }
            }
            state_path = os.path.join(ws, "cross_session_state.json")
            with open(state_path, "w") as f:
                json.dump(old_data, f)

            # Writing a new turn should trigger pruning of old entries
            self._write(mgr, "session-moro", "moro", "fresh new turn")

            state = mgr.get_full_state()
            session = state.get("sessions", {}).get("session-moro", {})
            turns = session.get("turns", [])
            now = int(time_mod.time())
            for t in turns:
                age_hours = (now - t["ts"]) / 3600
                assert age_hours < 3, \
                    f"turn with age {age_hours:.1f}h must have been pruned (max=2h)"

    def test_max_turns_cap_enforced(self):
        """Session must not exceed MAX_TURNS_PER_SESSION (50) turns."""
        with tempfile.TemporaryDirectory() as ws:
            mgr = self._get_manager(ws)
            mgr.register_agent("agent-x", "botX")

            for i in range(60):
                self._write(mgr, "session-x", "agent-x", f"summary of turn {i}")

            state = mgr.get_full_state()
            turns = state["sessions"]["session-x"]["turns"]
            assert len(turns) <= 50, \
                f"turns must be capped at 50, got {len(turns)}"
            # Newest turns must be kept (not oldest)
            summaries = [t["summary"] for t in turns]
            assert any("59" in s for s in summaries), \
                "newest turns must be preserved when cap is applied"

    def test_state_persists_across_manager_instances(self):
        """State written by one manager instance must be readable by a new one."""
        with tempfile.TemporaryDirectory() as ws:
            mgr1 = self._get_manager(ws)
            mgr1.register_agent("persistent-agent", "botP")
            self._write(mgr1, "session-p", "persistent-agent", "will this survive?")

            mgr2 = self._get_manager(ws)
            state = mgr2.get_full_state()
            assert "session-p" in state.get("sessions", {}), \
                "session state must persist across manager instances"

    def test_corrupt_state_file_recovers_gracefully(self):
        """A corrupt state file must be silently discarded — no crash."""
        with tempfile.TemporaryDirectory() as ws:
            state_path = os.path.join(ws, "cross_session_state.json")
            with open(state_path, "w") as f:
                f.write("{CORRUPTED JSON{{{{")

            mgr = self._get_manager(ws)
            mgr.register_agent("safe-agent", "botS")
            # Must not raise even with corrupt file on disk
            self._write(mgr, "session-safe", "safe-agent", "post-corruption turn")
            state = mgr.get_full_state()
            assert isinstance(state, dict), \
                "get_full_state must return a valid dict after corrupt file recovery"
            assert "sessions" in state


# ════════════════════════════════════════════════════════════════════════════
# INTEGRATION: ALL THREE FEATURES TOGETHER
# ════════════════════════════════════════════════════════════════════════════


class TestV47Integration:
    """Realistic multi-feature workflow: two agents, shared workspace,
    tiered storage active, knowledge ingested from CSV."""

    def test_two_agent_shared_workspace_with_tiered_storage(self):
        """
        Scenario: Two agents (moro + san) share a workspace.
        Moro ingests fresh data (hot tier), san searches and finds it.
        Warm-tier content from last week is findable via fallback.

        Note on design: hot and warm search terms are kept completely
        distinct (no token overlap) to avoid cross-corpus BM25 scoring
        artifacts where a warm entry with partial token overlap could
        outscore a hot-tier exact match (known limitation, tracked).
        """
        with tempfile.TemporaryDirectory() as ws:
            # Seed warm-tier shard with content that uses COMPLETELY different
            # vocabulary from the hot-tier query (no shared tokens)
            _write_shard(ws, 7, [_mem(
                "retrospective standup calendar scheduling timezone", 7
            )])

            # Moro ingests a fresh decision — unique topic, no warm overlap
            moro = MemorySystem(ws, use_sharding=False, sharding=True,
                                tiered_storage=True, agent_name="moro")
            moro.load()
            moro.ingest(
                "deployment pipeline succeeded artifact uploaded registry",
                agent_id="moro", category="strategic"
            )
            moro.save()

            # San comes online and loads the workspace
            san = MemorySystem(ws, use_sharding=False, sharding=True,
                               tiered_storage=True, agent_name="san")
            san.load()

            # Verify san can see moro's hot-tier entry in its memory list
            hot_contents = {m.content for m in san.memories}
            assert any("deployment pipeline" in c for c in hot_contents), \
                "san must have moro's hot-tier entry in its memory store"

            # Warm fallback: search for warm-tier term that's only in warm shard
            # This forces warm fallback since hot shard has no matching content
            warm_results = san.search("retrospective standup calendar")
            assert any("retrospective" in r.content for r in warm_results), \
                "san must find warm-tier content via warm fallback"

    def test_csv_ingestion_then_tiered_search(self):
        """
        Ingest a CSV knowledge base, then verify it's searchable across tiers.
        """
        with tempfile.TemporaryDirectory() as ws:
            # Write a CSV knowledge base
            csv_path = os.path.join(ws, "kb.csv")
            with open(csv_path, "w", newline="") as f:
                writer = csv.DictWriter(f, fieldnames=["concept", "explanation"])
                writer.writeheader()
                writer.writerow({"concept": "BM25", "explanation": "Best Match 25 is a ranking function used by search engines"})
                writer.writerow({"concept": "WAL", "explanation": "Write-Ahead Log ensures durability and crash recovery"})

            mem = MemorySystem(ws, use_sharding=False, sharding=True,
                               tiered_storage=True, agent_name="test-agent")
            mem.load()

            # Ingest the CSV
            result = mem.ingest_data_file(csv_path, format="csv")
            mem.save()

            assert result.get("ingested", 0) > 0, "CSV must produce at least one ingested entry"

            # Reload with tiered storage — newly ingested content is in hot tier
            mem2 = MemorySystem(ws, use_sharding=False, sharding=True,
                                tiered_storage=True, agent_name="test-agent")
            mem2.load()

            results = mem2.search("Write-Ahead Log durability")
            assert any("WAL" in r.content or "Write-Ahead" in r.content for r in results), \
                "CSV-ingested content must be searchable after tiered reload"

    def test_memory_entry_provenance_fields_serialise(self):
        """
        source_url and content_hash on MemoryEntry must survive save/load cycles.
        """
        with tempfile.TemporaryDirectory() as ws:
            entry = MemoryEntry(content="Test provenance entry")
            entry.source_url = "https://docs.example.com/page"
            entry.content_hash = "abc123def456"

            d = entry.to_dict()
            assert d.get("source_url") == "https://docs.example.com/page"
            assert d.get("content_hash") == "abc123def456"

            restored = MemoryEntry.from_dict(d)
            assert restored.source_url == "https://docs.example.com/page"
            assert restored.content_hash == "abc123def456"

    def test_ingest_data_file_auto_format_detection(self):
        """ingest_data_file with format='auto' must detect CSV by extension."""
        with tempfile.TemporaryDirectory() as ws:
            csv_path = os.path.join(ws, "auto_detect.csv")
            with open(csv_path, "w", newline="") as f:
                writer = csv.DictWriter(f, fieldnames=["content"])
                writer.writeheader()
                writer.writerow({"content": "auto format detection works"})

            mem = MemorySystem(ws, agent_name="test-agent")
            mem.load()
            result = mem.ingest_data_file(csv_path, format="auto")
            assert "error" not in result, f"auto format detection should not error: {result}"
            assert result.get("ingested", 0) > 0

    def test_cold_search_does_not_affect_hot_search_results(self):
        """
        Running include_cold=True must not contaminate subsequent hot searches.
        """
        with tempfile.TemporaryDirectory() as ws:
            _write_shard(ws, 0, [_mem("hot topic neural networks", 0)])
            _write_shard(ws, 60, [_mem("cold topic very old project X", 60)])

            mem = MemorySystem(ws, use_sharding=False, sharding=True,
                               tiered_storage=True, agent_name="test-agent")

            # First: cold search
            cold_results = mem.search("old project X", include_cold=True)
            assert any("old project X" in r.content for r in cold_results), \
                "cold search must return cold entry"

            # Then: hot search — must not include cold entry
            hot_results = mem.search("neural networks")
            cold_leaked = any("old project X" in r.content for r in hot_results)
            assert not cold_leaked, \
                "cold entries must not bleed into subsequent hot searches"
