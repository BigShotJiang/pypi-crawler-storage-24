"""Tests for CrossSessionStateManager (v4.7.0).

These tests exercise the CrossSessionStateManager from the sibling
antaris-openclaw-plugin repo.  They are skipped when that package is not
available so that ``parsica-memory``'s own test suite stays self-contained.
"""

import json
import os
import sys
import tempfile
import time
import unittest

import pytest

# Add the plugin directory to path so we can import the manager
_plugin_dir = os.path.join(os.path.dirname(__file__), '..', '..', 'antaris-openclaw-plugin')
sys.path.insert(0, os.path.abspath(_plugin_dir))

try:
    from pipeline_bridge import CrossSessionStateManager
except ImportError:
    CrossSessionStateManager = None

pytestmark = pytest.mark.skipif(
    CrossSessionStateManager is None,
    reason="CrossSessionStateManager requires sibling antaris-openclaw-plugin",
)


class TestCrossSessionStateManager(unittest.TestCase):

    def setUp(self):
        self.tmpdir = tempfile.mkdtemp()
        self.mgr = CrossSessionStateManager(self.tmpdir)

    def tearDown(self):
        # Clean up state file
        for f in ['cross_session_state.json', 'cross_session_state.json.lock']:
            p = os.path.join(self.tmpdir, f)
            if os.path.exists(p):
                os.remove(p)
        os.rmdir(self.tmpdir)

    def test_write_and_read_turn(self):
        self.mgr.write_turn('session-a', 'agent1', '#ch-a', 'user1', 'agent1', True, 'Hello world')
        turns = self.mgr.read_other_sessions('session-b')
        self.assertEqual(len(turns), 1)
        self.assertEqual(turns[0]['session_key'], 'session-a')
        self.assertEqual(turns[0]['summary'], 'Hello world')

    def test_other_sessions_only(self):
        self.mgr.write_turn('session-a', 'agent1', '#a', 'u1', None, False, 'Turn A')
        self.mgr.write_turn('session-b', 'agent1', '#b', 'u1', None, False, 'Turn B')
        turns = self.mgr.read_other_sessions('session-a')
        self.assertEqual(len(turns), 1)
        self.assertEqual(turns[0]['session_key'], 'session-b')

    def test_directed_at_derivation(self):
        """directed_at should be set when provided."""
        self.mgr.write_turn('s1', 'bot1', '#c', 'u1', 'bot1', True, 'Directed msg')
        turns = self.mgr.read_other_sessions('s2')
        self.assertEqual(turns[0]['directed_at'], 'bot1')

    def test_directed_at_null(self):
        self.mgr.write_turn('s1', 'bot1', '#c', 'u1', None, False, 'Not directed')
        turns = self.mgr.read_other_sessions('s2')
        self.assertIsNone(turns[0]['directed_at'])

    def test_expiry(self):
        self.mgr.write_turn('s1', 'a1', '#c', 'u1', None, False, 'Old turn')
        # Manually backdate the turn
        data = self.mgr._load()
        data['sessions']['s1']['turns'][0]['ts'] = int(time.time()) - 8000
        self.mgr._save(data)
        turns = self.mgr.read_other_sessions('s2')
        self.assertEqual(len(turns), 0)

    def test_max_50_turns_pruning(self):
        for i in range(60):
            self.mgr.write_turn('s1', 'a1', '#c', 'u1', None, False, f'Turn {i}')
        data = self.mgr._load()
        self.assertLessEqual(len(data['sessions']['s1']['turns']), 50)

    def test_corrupt_file_recovery(self):
        # Write garbage to state file
        with open(self.mgr._state_path, 'w') as f:
            f.write('NOT VALID JSON {{{')
        # Should recover gracefully
        self.mgr.write_turn('s1', 'a1', '#c', 'u1', None, False, 'After corruption')
        turns = self.mgr.read_other_sessions('s2')
        self.assertEqual(len(turns), 1)

    def test_agent_registration(self):
        self.mgr.register_agent('moro', '1234567890')
        data = self.mgr._load()
        self.assertIn('moro', data['agents'])
        self.assertEqual(data['agents']['moro']['bot_id'], '1234567890')

    def test_disabled_by_default(self):
        """crossSessionContext defaults to false — no state file created without explicit writes."""
        mgr2 = CrossSessionStateManager(self.tmpdir)
        # Just reading should not create file
        turns = mgr2.read_other_sessions('s1')
        self.assertEqual(turns, [])

    def test_no_action_on_other_directed(self):
        """Turns directed at other agents are visible but clearly marked."""
        self.mgr.write_turn('s1', 'bot-a', '#c', 'u1', 'bot-b', True, 'Hey bot-b')
        turns = self.mgr.read_other_sessions('s2', current_agent_id='bot-a')
        self.assertEqual(len(turns), 1)
        self.assertEqual(turns[0]['directed_at'], 'bot-b')

    def test_derive_topics(self):
        topics = self.mgr._derive_topics('Build a cross-session context layer for the pipeline')
        self.assertIsInstance(topics, list)
        self.assertLessEqual(len(topics), 5)
        self.assertIn('cross', [t.lower() for t in topics])

    def test_empty_summary_topics(self):
        self.mgr.write_turn('s1', 'a1', '#c', 'u1', None, False, '')
        data = self.mgr._load()
        self.assertEqual(data['sessions']['s1']['turns'][0]['topics'], [])

    def test_multiple_sessions_ordering(self):
        self.mgr.write_turn('s1', 'a1', '#a', 'u1', None, False, 'First')
        # Manually set different timestamps to ensure ordering
        data = self.mgr._load()
        data['sessions']['s1']['turns'][0]['ts'] = int(time.time()) - 10
        self.mgr._save(data)
        self.mgr.write_turn('s2', 'a1', '#b', 'u1', None, False, 'Second')
        turns = self.mgr.read_other_sessions('s3')
        self.assertEqual(len(turns), 2)
        # Should be reverse chronological
        self.assertEqual(turns[0]['summary'], 'Second')

    def test_get_full_state(self):
        self.mgr.register_agent('test', '999')
        self.mgr.write_turn('s1', 'test', '#c', 'u1', None, False, 'Hi')
        state = self.mgr.get_full_state()
        self.assertEqual(state['version'], 1)
        self.assertIn('test', state['agents'])
        self.assertIn('s1', state['sessions'])

    def test_custom_max_age(self):
        self.mgr.write_turn('s1', 'a1', '#c', 'u1', None, False, 'Recent')
        # With max_age=0, everything is expired
        turns = self.mgr.read_other_sessions('s2', max_age_seconds=0)
        self.assertEqual(len(turns), 0)

    def test_nonexistent_workspace(self):
        """Manager with bad path should not crash."""
        mgr = CrossSessionStateManager('/nonexistent/path/12345')
        # All operations should be non-fatal
        mgr.register_agent('a', 'b')
        mgr.write_turn('s', 'a', '#c', 'u', None, False, 'test')
        result = mgr.read_other_sessions('s2')
        self.assertEqual(result, [])


if __name__ == '__main__':
    unittest.main()
