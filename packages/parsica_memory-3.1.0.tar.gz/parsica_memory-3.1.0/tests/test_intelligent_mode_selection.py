import tempfile

from parsica_memory.core_v4 import MemorySystemV4 as MemorySystem
from parsica_memory.entry import MemoryEntry
from parsica_memory.search import ModeController, SearchEngine


def _entry(content, **kwargs):
    m = MemoryEntry(content, kwargs.get("source", "test"), 1, kwargs.get("category", "general"))
    for k, v in kwargs.items():
        setattr(m, k, v)
    return m


def test_mode_controller_classifies_recent_precision_semantic_deep():
    assert ModeController.classify_search_mode("what happened yesterday?")[0] == "recent"
    assert ModeController.classify_search_mode("what is the exact timeout value?")[0] == "precision"
    assert ModeController.classify_search_mode("the thing about postgres")[0] == "semantic"
    assert ModeController.classify_search_mode("list all audit evidence across projects")[0] == "deep"


def test_search_engine_mode_policy_deprioritizes_facts_in_default_mode():
    """Facts are still searchable in default mode, but deprioritized via scoring penalty.
    
    In precision mode, facts get full scoring weight. In default mode, they
    receive a 0.4x penalty — still visible but not diluting the result pool.
    """
    engine = SearchEngine()
    parent = _entry("We discussed deployment strategy and the timeout value was changed to 30 seconds.")
    fact = _entry("The timeout value is 30 seconds.", memory_type="fact", parent_hash=parent.hash)
    memories = [parent, fact]
    engine.build_index(memories)

    # Default mode: facts should appear but with lower scores than originals
    default_results = engine.search("timeout value", memories, mode="default")
    assert default_results, "facts should still be searchable in default mode"
    # The original entry (parent) should rank higher than the fact
    fact_results_default = [r for r in default_results if getattr(r.entry, "parent_hash", "")]
    non_fact_results_default = [r for r in default_results if not getattr(r.entry, "parent_hash", "")]
    if fact_results_default and non_fact_results_default:
        assert non_fact_results_default[0].score >= fact_results_default[0].score, \
            "Non-fact entries should rank >= facts in default mode"

    # Precision mode: facts should get full scoring weight
    precision_results = engine.search("timeout value", memories, mode="precision")
    assert any(getattr(r.entry, "parent_hash", "") == parent.hash for r in precision_results)


def test_search_engine_mode_policy_disables_enrichment_for_precision():
    engine = SearchEngine()
    mem = _entry("We use FastAPI for backend services.")
    mem.enriched_summary = "FastAPI is the web framework used by the backend"
    mem.search_keywords = ["framework"]
    mem.search_queries = ["which web framework do we use"]
    memories = [mem]
    engine.build_index(memories)

    semantic_results = engine.search("web framework", memories, mode="semantic")
    assert semantic_results, "semantic mode should use enrichment fields"

    precision_results = engine.search("web framework", memories, mode="precision")
    assert precision_results == [], "precision mode should not rely on enrichment fields"


def test_auto_mode_precision_falls_back_when_results_are_weak():
    engine = SearchEngine()
    parent = _entry("We talked about service settings and reviewed infra notes.")
    fact = _entry("The timeout value is 45 seconds.", memory_type="fact", parent_hash=parent.hash)
    memories = [parent, fact]
    engine.build_index(memories)

    auto_results = engine.search("what is the timeout value", memories, mode="auto")
    assert auto_results
    assert any("timeout" in r.entry.content.lower() for r in auto_results)
    assert any(getattr(r.entry, "parent_hash", "") == parent.hash for r in auto_results)


def test_memory_system_search_accepts_auto_mode_and_remains_backward_compatible():
    with tempfile.TemporaryDirectory() as d:
        mem = MemorySystem(workspace=d, agent_name="test-agent")
        mem.load()
        mem.ingest("We use FastAPI for the backend service.", source="chat")

        auto_results = mem.search("FastAPI", mode="auto")
        legacy_results = mem.search("FastAPI")

        assert auto_results
        assert legacy_results
        assert auto_results[0].content == legacy_results[0].content
