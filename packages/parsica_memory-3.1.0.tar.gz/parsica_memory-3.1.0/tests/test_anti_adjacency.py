"""
Tests for Sprint 3 anti-adjacency penalty and rarity boost tuning.
"""
import tempfile
import os
from unittest import TestCase
from parsica_memory import MemorySystem


class TestAntiAdjacencyPenalty(TestCase):
    """Test anti-adjacency penalty feature."""
    
    def setUp(self):
        """Set up test fixtures."""
        self.temp_dir = tempfile.mkdtemp()
        self.memory_system = MemorySystem(
            workspace=self.temp_dir, 
            half_life=7.0,
            agent_name="test-agent"  # Avoid warnings
        )
        
    def tearDown(self):
        """Clean up test fixtures."""
        import shutil
        shutil.rmtree(self.temp_dir)
    
    def test_specific_question_penalty(self):
        """Test that meta-discussion gets penalized for specific questions."""
        # Add two memories: one with the actual answer, one meta-discussion
        count1 = self.memory_system.ingest("The test phrase was Peaches from Space", category="answer")
        count2 = self.memory_system.ingest("We did memory testing today and discussed various approaches", category="meta")
        

        
        # Search with a specific question  
        results = self.memory_system.search("what was the test phrase?", limit=2, explain=True, min_confidence=0.001)
        
        # Also test with the term "memory" to ensure both memories are findable
        memory_results = self.memory_system.search("memory", limit=5, explain=True, min_confidence=0.001)
            
        # And test with "testing"
        testing_results = self.memory_system.search("testing", limit=5, explain=True, min_confidence=0.001)
            
        # The actual answer should rank higher than meta-discussion when both are found
        self.assertGreaterEqual(len(results), 1, "Should find at least 1 result")
        self.assertIn("Peaches from Space", results[0].content)
        
        # If we found 2 results, verify ranking. If not, it means the penalty worked too well.
        if len(results) >= 2:
            self.assertGreater(results[0].relevance, results[1].relevance)
            # The second result should be the meta-discussion
            self.assertIn("memory testing", results[1].content) 
        else:
            # Anti-adjacency penalty filtered out the meta-discussion completely
            # This is actually good behavior - let's verify the meta-discussion exists
            self.assertGreaterEqual(len(memory_results), 1, "Should find the memory testing discussion")

    
    def test_general_query_no_penalty(self):
        """Test that general queries don't get penalty (backward compatibility)."""
        self.memory_system.ingest("The test phrase was Peaches from Space", category="answer")
        self.memory_system.ingest("We did memory testing today and discussed various approaches", category="meta")
        
        # Search with a general query (not a specific question)
        results = self.memory_system.search("memory testing", limit=2, explain=True, min_confidence=0.001)
        

        
        # Both memories should be found with no anti-adjacency penalty applied
        self.assertGreaterEqual(len(results), 1)
        # The meta-discussion should rank higher since it contains the exact terms
        if len(results) > 0:
            self.assertIn("memory testing", results[0].content)
        
    def test_proper_noun_no_penalty(self):
        """Test that proper nouns in content don't get penalized."""
        self.memory_system.ingest("The project name is Project Apollo", category="proper")
        self.memory_system.ingest("We discussed the project details", category="meta")
        
        results = self.memory_system.search("what is the project name?", limit=2, explain=True, min_confidence=0.001)
        

        
        # The proper noun content should rank much higher
        self.assertGreaterEqual(len(results), 1)
        self.assertIn("Project Apollo", results[0].content)
        
        if len(results) >= 2:
            # Anti-adjacency penalty should significantly reduce the meta-discussion score
            self.assertGreater(results[0].relevance, results[1].relevance)
            self.assertLess(results[1].relevance, 0.5, "Meta-discussion should be significantly penalized")
        
        # Verify both memories exist by searching for "project"
        project_results = self.memory_system.search("project", explain=True)
        self.assertGreaterEqual(len(project_results), 2, "Both memories should be findable with general search")
    
    def test_quoted_strings_no_penalty(self):
        """Test that quoted strings don't get penalized."""
        self.memory_system.ingest('The error message was "Connection timeout occurred"', category="error")
        self.memory_system.ingest("We encountered some connection issues", category="meta")
        
        results = self.memory_system.search("what was the error message?", limit=2, explain=True, min_confidence=0.001)
        
        # The quoted content should rank higher
        self.assertGreaterEqual(len(results), 1)
        self.assertIn("Connection timeout", results[0].content)
        if len(results) >= 2:
            self.assertGreater(results[0].relevance, results[1].relevance)
    
    def test_version_numbers_no_penalty(self):
        """Test that version numbers don't get penalized."""
        self.memory_system.ingest("The current version is v5.2.1", category="version")
        self.memory_system.ingest("We discussed version control", category="meta")
        
        results = self.memory_system.search("what is the current version?", limit=2, explain=True, min_confidence=0.001)
        
        # The version content should rank higher
        self.assertGreaterEqual(len(results), 1)
        self.assertIn("v5.2.1", results[0].content)
        if len(results) >= 2:
            self.assertGreater(results[0].relevance, results[1].relevance)
    
    def test_code_identifiers_no_penalty(self):
        """Test that code identifiers don't get penalized."""
        self.memory_system.ingest("The function name is `calculateTotal`", category="code")
        self.memory_system.ingest("We worked on calculation functions", category="meta")
        
        results = self.memory_system.search("what is the function name?", limit=2, explain=True, min_confidence=0.001)
        
        # The code content should rank higher
        self.assertGreaterEqual(len(results), 1)
        self.assertIn("calculateTotal", results[0].content)
        if len(results) >= 2:
            self.assertGreater(results[0].relevance, results[1].relevance)
    
    def test_constants_no_penalty(self):
        """Test that CONSTANTS don't get penalized."""
        self.memory_system.ingest("The constant is MAX_RETRIES = 5", category="constant")
        self.memory_system.ingest("We configured retry logic", category="meta")
        
        results = self.memory_system.search("what is the constant name?", limit=2, explain=True, min_confidence=0.001)
        
        # The constant content should rank higher
        self.assertGreaterEqual(len(results), 1)
        self.assertIn("MAX_RETRIES", results[0].content)
        if len(results) >= 2:
            self.assertGreater(results[0].relevance, results[1].relevance)


class TestRarityBoostTuning(TestCase):
    """Test enhanced rarity boost for proper nouns and rare terms."""
    
    def setUp(self):
        """Set up test fixtures."""
        self.temp_dir = tempfile.mkdtemp()
        self.memory_system = MemorySystem(
            workspace=self.temp_dir, 
            half_life=7.0,
            agent_name="test-agent"  # Avoid warnings
        )
        
        # Add some common memories to establish term frequencies
        for i in range(20):
            self.memory_system.ingest(f"Some testing activity happened on day {i}")
    
    def tearDown(self):
        """Clean up test fixtures."""
        import shutil
        shutil.rmtree(self.temp_dir)
    
    def test_proper_noun_boost(self):
        """Test that proper nouns get enhanced boost."""
        self.memory_system.ingest("The test phrase was Peaches from Space")
        self.memory_system.ingest("We did some testing thing")
        
        results = self.memory_system.search("Peaches from Space", limit=2, explain=True, min_confidence=0.001)
        
        # The proper noun should rank much higher
        self.assertGreaterEqual(len(results), 1)
        self.assertIn("Peaches from Space", results[0].content)
        if len(results) >= 2:
            self.assertGreater(results[0].relevance, results[1].relevance)
    
    def test_rare_term_boost(self):
        """Test that extremely rare terms get enhanced boost."""
        self.memory_system.ingest("The unique identifier is XenonAlpha7")
        self.memory_system.ingest("Some testing activity")
        
        results = self.memory_system.search("XenonAlpha7", limit=2, explain=True, min_confidence=0.001)
        
        # The rare term should rank much higher
        self.assertGreaterEqual(len(results), 1)
        self.assertIn("XenonAlpha7", results[0].content)
        if len(results) >= 2:
            self.assertGreater(results[0].relevance, results[1].relevance)
    
    def test_quoted_string_boost(self):
        """Test that quoted strings get enhanced boost."""
        self.memory_system.ingest('The message was "UnicornsAreReal"')
        self.memory_system.ingest("Some testing activity")
        
        results = self.memory_system.search("UnicornsAreReal", limit=2, explain=True, min_confidence=0.001)
        
        # The quoted content should rank much higher
        self.assertGreaterEqual(len(results), 1)
        self.assertIn("UnicornsAreReal", results[0].content)
        if len(results) >= 2:
            self.assertGreater(results[0].relevance, results[1].relevance)


class TestAntiAdjacencyIntegration(TestCase):
    """Test integration of anti-adjacency with existing search features."""
    
    def setUp(self):
        """Set up test fixtures.""" 
        self.temp_dir = tempfile.mkdtemp()
        self.memory_system = MemorySystem(
            workspace=self.temp_dir,
            half_life=7.0,
            agent_name="test-agent"
        )
    
    def tearDown(self):
        """Clean up test fixtures."""
        import shutil
        shutil.rmtree(self.temp_dir)
    
    def test_complex_specific_question(self):
        """Test various specific question patterns."""
        self.memory_system.ingest("The API key is sk-abc123")
        self.memory_system.ingest("We talked about API configuration")
        
        question_patterns = [
            "what is the API key?",
            "what was the API key?",
            "which API key?", 
            "what's the API key?",
            "name of the API key",
            "what did we call the API key?",
        ]
        
        for question in question_patterns:
            with self.subTest(question=question):
                results = self.memory_system.search(question, limit=2, explain=True, min_confidence=0.001)
                self.assertGreaterEqual(len(results), 1)
                # The specific answer should rank higher than meta-discussion
                self.assertIn("sk-abc123", results[0].content, f"Failed for question: {question}")
                if len(results) >= 2:
                    self.assertGreater(results[0].relevance, results[1].relevance,
                                     f"Failed for question: {question}")
    
    def test_meta_patterns_detection(self):
        """Test detection of meta-discussion patterns."""
        specific_answer = "The database name is ProductionDB"
        self.memory_system.ingest(specific_answer)
        
        meta_patterns = [
            "We talked about database naming",
            "We discussed the database",
            "Database naming was mentioned",
            "This came up in our conversation",
            "We were working on database config",
            "In the context of database setup"
        ]
        
        for meta_content in meta_patterns:
            with self.subTest(meta_content=meta_content):
                self.memory_system.ingest(meta_content)
                results = self.memory_system.search("what is the database name?", limit=2, explain=True, min_confidence=0.001)
                
                # The specific answer should outrank meta-discussion
                self.assertGreaterEqual(len(results), 1)
                self.assertIn("ProductionDB", results[0].content, f"Failed for meta content: {meta_content}")
                if len(results) >= 2:
                    self.assertGreater(results[0].relevance, results[1].relevance, f"Failed for meta content: {meta_content}")