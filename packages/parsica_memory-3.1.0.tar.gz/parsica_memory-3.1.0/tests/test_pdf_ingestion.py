import os
import tempfile
import unittest

from parsica_memory.ingest_pdf import PDFIngester


MINIMAL_PDF_BYTES = b"""%PDF-1.4
1 0 obj
<< /Type /Catalog /Pages 2 0 R >>
endobj
2 0 obj
<< /Type /Pages /Count 1 /Kids [3 0 R] >>
endobj
3 0 obj
<< /Type /Page /Parent 2 0 R /MediaBox [0 0 400 200] /Contents 4 0 R /Resources << /Font << /F1 5 0 R >> >> >>
endobj
4 0 obj
<< /Length 162 >>
stream
BT
/F1 14 Tf
72 140 Td
(Hello PDF extraction world with enough page text to ingest cleanly and preserve provenance.) Tj
0 -22 Td
(This second sentence keeps the extracted page comfortably above minimum ingest thresholds.) Tj
ET
endstream
endobj
5 0 obj
<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica >>
endobj
xref
0 6
0000000000 65535 f 
0000000010 00000 n 
0000000063 00000 n 
0000000122 00000 n 
0000000248 00000 n 
0000000507 00000 n 
trailer
<< /Root 1 0 R /Size 6 >>
startxref
577
%%EOF
"""


class TestPDFIngester(unittest.TestCase):
    def setUp(self):
        self.tmpdir = tempfile.mkdtemp()

    def test_pdf_page_extraction_with_provenance(self):
        path = os.path.join(self.tmpdir, "sample.pdf")
        with open(path, "wb") as f:
            f.write(MINIMAL_PDF_BYTES)

        ingester = PDFIngester()
        results = ingester.from_pdf(path)

        self.assertEqual(len(results), 1)
        chunk = results[0]
        self.assertIn("Hello PDF extraction world", chunk["text"])
        self.assertEqual(chunk["page_number"], 1)
        self.assertTrue(chunk["source_url"].endswith("#page=1"))
        self.assertEqual(chunk["provenance"]["type"], "pdf_page")
        self.assertEqual(chunk["provenance"]["page_number"], 1)
        self.assertEqual(chunk["extraction_method"], "direct_text")
        self.assertFalse(chunk["needs_ocr"])

    def test_missing_pdf_returns_empty(self):
        ingester = PDFIngester()
        self.assertEqual(ingester.from_pdf("/no/such/file.pdf"), [])


class TestPDFCoreIntegration(unittest.TestCase):
    def setUp(self):
        self.tmpdir = tempfile.mkdtemp()

    def _make_system(self):
        import warnings
        with warnings.catch_warnings():
            warnings.simplefilter("ignore")
            from parsica_memory.core_v4 import MemorySystemV4
            return MemorySystemV4(
                workspace=self.tmpdir,
                use_sharding=False,
                use_indexing=False,
                sharding=False,
                agent_name="test",
            )

    def test_ingest_data_file_pdf(self):
        path = os.path.join(self.tmpdir, "sample.pdf")
        with open(path, "wb") as f:
            f.write(MINIMAL_PDF_BYTES)

        mem = self._make_system()
        result = mem.ingest_data_file(path, format="pdf")

        self.assertEqual(result["ingested"], 1)
        self.assertEqual(result["skipped_duplicates"], 0)
        self.assertEqual(len(mem.memories), 1)

        entry = mem.memories[0]
        self.assertEqual(getattr(entry, "source_url", ""), f"file://{os.path.abspath(path)}#page=1")
        self.assertIn("pdf", getattr(entry, "tags", []))
        self.assertIn("page:1", getattr(entry, "tags", []))
        self.assertIn("direct_text", getattr(entry, "tags", []))

    def test_ingest_data_file_pdf_auto_detect(self):
        path = os.path.join(self.tmpdir, "auto.pdf")
        with open(path, "wb") as f:
            f.write(MINIMAL_PDF_BYTES)

        mem = self._make_system()
        result = mem.ingest_data_file(path, format="auto")
        self.assertEqual(result["ingested"], 1)
