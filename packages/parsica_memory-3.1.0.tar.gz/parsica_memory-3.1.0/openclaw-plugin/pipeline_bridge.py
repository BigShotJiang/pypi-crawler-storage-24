#!/usr/bin/env python3
"""
Bridge: interface between OpenClaw plugin and antaris-pipeline.

Two modes:
1. Legacy mode: python3 pipeline_bridge.py <cmd> <args> - one-shot subprocess
2. Persistent mode: python3 pipeline_bridge.py - NDJSON loop on stdin/stdout

Persistent mode (preferred):
- Initialize AgentPipeline once at startup
- Read one JSON line from stdin: {"cmd": "pre-turn", "memory_path": "...", "text": "..."}
- Write one JSON response line to stdout, flush, repeat
- Commands: "pre-turn", "post-turn", "session-start", "config-check", "pool-info"
- Exit cleanly when stdin closes

Legacy mode (backward compatibility):
- config: python3 pipeline_bridge.py config <memory_path> [guard_mode]
- pre-turn/post-turn: read JSON payload from stdin
"""
import sys
import json
import os
import re
from collections import OrderedDict

# Ensure parsica-memory packages are findable.
# Priority: pip-installed packages (already in sys.path) → self-relative paths (dev/monorepo)
# → ANTARIS_SUITE_ROOT env var (explicit override for non-standard layouts).
# Never hardcodes absolute paths — uses __file__ so this works on any machine.
_bridge_dir = os.path.dirname(os.path.abspath(__file__))
_suite_root = os.path.dirname(_bridge_dir)  # openclaw-plugin/ → parsica-memory/
_fallback_paths = [
    _suite_root,
    os.path.join(_suite_root, 'antaris-pipeline'),
]
if os.environ.get('ANTARIS_SUITE_ROOT'):
    _fallback_paths.insert(0, os.environ['ANTARIS_SUITE_ROOT'])
for _p in _fallback_paths:
    if os.path.isdir(_p) and _p not in sys.path:
        sys.path.insert(0, _p)


# ── Cross-Session Context Layer (v4.7.0) ─────────────────────────────────────

class CrossSessionStateManager:
    """Passive cross-session context sharing via a shared JSON file.

    Multiple agent instances (different Discord channels) write their turn
    summaries to a shared state file. Each instance can read OTHER sessions'
    recent activity without auto-injecting it into context.

    Rules:
    - Never auto-inject — only surface when explicitly asked
    - Entries older than max_age_seconds (default 7200) are pruned
    - Max 50 turns per session
    - File corruption → start fresh, log warning, never crash
    """

    MAX_TURNS_PER_SESSION = 50
    DEFAULT_MAX_AGE = 7200  # 2 hours

    # Stopwords for topic derivation
    _STOPWORDS = frozenset({
        'the', 'a', 'an', 'is', 'are', 'was', 'were', 'be', 'been', 'being',
        'have', 'has', 'had', 'do', 'does', 'did', 'will', 'would', 'could',
        'should', 'may', 'might', 'shall', 'can', 'to', 'of', 'in', 'for',
        'on', 'with', 'at', 'by', 'from', 'as', 'into', 'through', 'during',
        'before', 'after', 'above', 'below', 'between', 'out', 'off', 'over',
        'under', 'again', 'further', 'then', 'once', 'here', 'there', 'when',
        'where', 'why', 'how', 'all', 'each', 'every', 'both', 'few', 'more',
        'most', 'other', 'some', 'such', 'no', 'nor', 'not', 'only', 'own',
        'same', 'so', 'than', 'too', 'very', 'just', 'because', 'but', 'and',
        'or', 'if', 'while', 'about', 'up', 'it', 'its', 'he', 'she', 'they',
        'them', 'his', 'her', 'my', 'your', 'our', 'their', 'this', 'that',
        'these', 'those', 'i', 'me', 'we', 'you', 'what', 'which', 'who',
    })

    def __init__(self, workspace_path):
        try:
            self._state_path = os.path.join(workspace_path, 'cross_session_state.json')
            self._lock_path = self._state_path + '.lock'
            self._flock_available = False
            try:
                import fcntl
                self._fcntl = fcntl
                self._flock_available = True
            except ImportError:
                self._fcntl = None
        except Exception as e:
            print(f"[CrossSession] init error (non-fatal): {e}", file=sys.stderr)
            self._state_path = None

    def _lock(self, lock_file):
        """Acquire file lock (Unix only, no-op on Windows)."""
        if self._flock_available and self._fcntl:
            try:
                self._fcntl.flock(lock_file.fileno(), self._fcntl.LOCK_EX)
            except Exception:
                pass

    def _unlock(self, lock_file):
        """Release file lock."""
        if self._flock_available and self._fcntl:
            try:
                self._fcntl.flock(lock_file.fileno(), self._fcntl.LOCK_UN)
            except Exception:
                pass

    def _load(self):
        """Load state from disk with corruption recovery."""
        try:
            if self._state_path and os.path.exists(self._state_path):
                with open(self._state_path, 'r') as f:
                    data = json.load(f)
                    if isinstance(data, dict) and data.get('version') == 1:
                        return data
            # Missing or wrong version — start fresh
        except (json.JSONDecodeError, ValueError, OSError) as e:
            print(f"[CrossSession] corrupt state file, starting fresh: {e}", file=sys.stderr)
        return {"version": 1, "agents": {}, "sessions": {}}

    def _save(self, data):
        """Save state to disk using atomic rename (POSIX-safe, no TOCTOU corruption)."""
        if not self._state_path:
            return
        try:
            os.makedirs(os.path.dirname(self._state_path) or '.', exist_ok=True)
            tmp_path = self._state_path + '.tmp'
            with open(tmp_path, 'w') as f:
                json.dump(data, f, indent=2)
            os.replace(tmp_path, self._state_path)  # atomic on POSIX
        except Exception as e:
            print(f"[CrossSession] save error (non-fatal): {e}", file=sys.stderr)

    def register_agent(self, agent_id, bot_id):
        """Register agent identity in the shared state."""
        try:
            if not agent_id:
                return
            import time
            data = self._load()
            data.setdefault('agents', {})[agent_id] = {
                'bot_id': bot_id or '',
                'last_seen': int(time.time()),
            }
            self._save(data)
        except Exception as e:
            print(f"[CrossSession] register_agent error (non-fatal): {e}", file=sys.stderr)

    def write_turn(self, session_key, agent_id, display_name, user_id,
                   directed_at, was_instruction, summary, topics=None):
        """Append a turn entry, prune old/excess entries, save."""
        try:
            import time
            now = int(time.time())
            data = self._load()

            # Update agent last_seen
            if agent_id and agent_id in data.get('agents', {}):
                data['agents'][agent_id]['last_seen'] = now

            sessions = data.setdefault('sessions', {})
            session = sessions.setdefault(session_key, {
                'agent_id': agent_id,
                'display': display_name or session_key,
                'last_updated': now,
                'turns': [],
            })
            session['last_updated'] = now
            session['agent_id'] = agent_id
            if display_name:
                session['display'] = display_name

            # Derive topics if not provided
            if not topics and summary:
                topics = self._derive_topics(summary)

            session['turns'].append({
                'ts': now,
                'user_id': user_id or '',
                'directed_at': directed_at,
                'was_instruction': bool(was_instruction),
                'topics': topics or [],
                'summary': summary or '',
            })

            # Prune expired entries across all sessions
            cutoff = now - self.DEFAULT_MAX_AGE
            for skey in list(sessions.keys()):
                s = sessions[skey]
                s['turns'] = [t for t in s.get('turns', []) if t.get('ts', 0) > cutoff]
                # Cap at MAX_TURNS_PER_SESSION (keep newest)
                if len(s['turns']) > self.MAX_TURNS_PER_SESSION:
                    s['turns'] = s['turns'][-self.MAX_TURNS_PER_SESSION:]
                # Remove empty sessions
                if not s['turns'] and s.get('last_updated', 0) <= cutoff:
                    del sessions[skey]

            self._save(data)
        except Exception as e:
            print(f"[CrossSession] write_turn error (non-fatal): {e}", file=sys.stderr)

    def read_other_sessions(self, current_session_key, current_agent_id=None, max_age_seconds=None):
        """Return recent turns from OTHER sessions only."""
        try:
            import time
            if max_age_seconds is None:
                max_age_seconds = self.DEFAULT_MAX_AGE
            now = int(time.time())
            cutoff = now - max_age_seconds
            data = self._load()
            results = []

            for skey, session in data.get('sessions', {}).items():
                if skey == current_session_key:
                    continue
                for turn in session.get('turns', []):
                    if turn.get('ts', 0) <= cutoff:
                        continue
                    results.append({
                        'session_key': skey,
                        'session_display': session.get('display', skey),
                        'agent_id': session.get('agent_id', ''),
                        **turn,
                    })

            results.sort(key=lambda t: t.get('ts', 0), reverse=True)
            return results
        except Exception as e:
            print(f"[CrossSession] read_other_sessions error (non-fatal): {e}", file=sys.stderr)
            return []

    def get_full_state(self):
        """Return the full state dict (for the bridge command)."""
        try:
            return self._load()
        except Exception as e:
            print(f"[CrossSession] get_full_state error (non-fatal): {e}", file=sys.stderr)
            return {"version": 1, "agents": {}, "sessions": {}}

    def _derive_topics(self, text):
        """Simple keyword extraction: split, lowercase, filter stopwords, return top 5."""
        try:
            import re
            words = re.findall(r'[a-z]+', text.lower())
            filtered = [w for w in words if w not in self._STOPWORDS and len(w) > 2]
            # Count frequency
            freq = {}
            for w in filtered:
                freq[w] = freq.get(w, 0) + 1
            sorted_words = sorted(freq.items(), key=lambda x: x[1], reverse=True)
            return [w for w, _ in sorted_words[:5]]
        except Exception:
            return []


def make_enricher():
    """Build an LLM-agnostic enricher using the gateway's own API key.

    Reads provider config from environment variables set by index.js:
      ANTARIS_LLM_API_KEY    — the gateway's working API key
      ANTARIS_LLM_API_FORMAT — "anthropic-messages" or "openai-completions"
      ANTARIS_LLM_BASE_URL   — provider base URL
      ANTARIS_LLM_MODEL      — model name for enrichment (cheapest available)

    Uses raw HTTP (urllib) — zero SDK dependencies. Supports any provider
    that speaks Anthropic Messages or OpenAI Chat Completions format.

    Returns a callable ``enrich(text: str) -> dict`` or None if no key available.
    Non-fatal: any exception returns empty dict.
    """
    import re as _re
    from urllib.request import Request, urlopen

    api_key = os.environ.get("ANTARIS_LLM_API_KEY", "")
    api_format = os.environ.get("ANTARIS_LLM_API_FORMAT", "anthropic-messages")
    base_url = os.environ.get("ANTARIS_LLM_BASE_URL", "https://api.anthropic.com")
    model = os.environ.get("ANTARIS_LLM_MODEL", "claude-sonnet-4-6")

    # Fallback: check legacy ANTHROPIC_API_KEY for backward compat
    if not api_key:
        api_key = os.environ.get("ANTHROPIC_API_KEY", "")
        if api_key:
            api_format = "anthropic-messages"
            base_url = "https://api.anthropic.com"
            model = "claude-sonnet-4-6"

    if not api_key:
        print("[bridge] no LLM API key available — enricher disabled", file=sys.stderr)
        return None

    _PROMPT = (
        "Analyze this memory/note and extract semantic metadata to improve search recall.\n"
        "Focus on SYNONYMS and RELATED CONCEPTS that someone might use when searching.\n"
        "Return ONLY a valid JSON object with exactly these fields:\n"
        '- "tags": 5-10 snake_case semantic labels (include synonyms: e.g. "authentication" '
        'for JWT, "deployment" for Kubernetes, "cost_tracking" for billing)\n'
        '- "summary": one sentence rephrasing the core fact using DIFFERENT vocabulary than the original\n'
        '- "keywords": 8-15 terms someone might search to find this memory '
        '(think: natural language queries a person would type)\n'
        '- "search_queries": 3 SPECIFIC natural language questions that ONLY this exact memory answers. '
        'Include exact names (function names, class names, variable names, package names, version numbers, '
        'decision names). Each query must be discriminative — it should NOT match hundreds of other memories.\n\n'
        "Memory:\n{text}\n\nJSON:"
    )

    def _call_anthropic(prompt_text: str) -> str:
        """Call Anthropic Messages API via raw HTTP."""
        url = f"{base_url.rstrip('/')}/v1/messages"
        payload = json.dumps({
            "model": model,
            "max_tokens": 256,
            "messages": [{"role": "user", "content": prompt_text}],
        })
        req = Request(url, data=payload.encode("utf-8"), method="POST")
        req.add_header("Content-Type", "application/json")
        req.add_header("x-api-key", api_key)
        req.add_header("anthropic-version", "2023-06-01")
        with urlopen(req, timeout=30) as resp:
            data = json.loads(resp.read().decode("utf-8"))
            return data["content"][0]["text"]

    def _call_openai(prompt_text: str) -> str:
        """Call OpenAI Chat Completions API via raw HTTP."""
        url = f"{base_url.rstrip('/')}/v1/chat/completions"
        payload = json.dumps({
            "model": model,
            "max_tokens": 256,
            "messages": [{"role": "user", "content": prompt_text}],
        })
        req = Request(url, data=payload.encode("utf-8"), method="POST")
        req.add_header("Content-Type", "application/json")
        req.add_header("Authorization", f"Bearer {api_key}")
        with urlopen(req, timeout=30) as resp:
            data = json.loads(resp.read().decode("utf-8"))
            return data["choices"][0]["message"]["content"]

    _call_llm = _call_anthropic if api_format == "anthropic-messages" else _call_openai

    def enrich(text: str) -> dict:
        try:
            raw = _call_llm(_PROMPT.format(text=text[:600])).strip()
            # L-3 fix: more robust JSON extraction — find outermost {...} and parse.
            # Old regex r'\{[^{}]*\}' fails on nested objects (e.g. {"a": {"b": 1}}).
            start = raw.find('{')
            end = raw.rfind('}')
            if start != -1 and end > start:
                try:
                    return json.loads(raw[start:end+1])
                except json.JSONDecodeError:
                    pass
        except Exception as exc:
            print(f"[bridge] enricher error (non-fatal): {exc}", file=sys.stderr)
        return {}

    print(f"[bridge] LLM enricher ready (format={api_format}, model={model})", file=sys.stderr)
    return enrich


# Legacy alias for backward compatibility
def make_claude_enricher(model=None):
    """Deprecated: use make_enricher() instead. Kept for backward compat."""
    return make_enricher()


def get_or_create_pipeline(
    memory_path,
    guard_mode,
    guard_enabled=True,
    memory_enabled=True,
    context_enabled=True,
    memory_config=None,
    agent_name=None,
):
    """Create AgentPipeline instance with the given config flags.

    FIX 1: Accept and forward guard_enabled / memory_enabled / context_enabled so
    that config flags from openclaw.plugin.json are actually wired to the pipeline
    instead of always defaulting to memory=True, guard=True, context=True.
    MEDIUM-05: Accept and forward agent_name so MemorySystem scopes memories correctly.
    """
    try:
        from antaris_pipeline import AgentPipeline
        kwargs = {}
        if memory_config:
            kwargs["memory_config"] = memory_config
        if agent_name:
            kwargs["agent_name"] = agent_name
        return AgentPipeline(
            storage_path=memory_path,
            memory=memory_enabled,
            guard=guard_enabled,
            context=context_enabled,
            guard_mode=guard_mode,
            **kwargs,
        )
    except ImportError:
        return None


class PipelinePool:
    """LRU pool of AgentPipeline instances keyed by memory_path.

    Eliminates cross-session contamination: each unique memory_path gets its
    own pipeline. When at capacity, the least-recently-used entry is evicted.
    Pool size defaults to 4 and is overridable via ANTARIS_POOL_SIZE env var.
    """

    def __init__(self, max_size=4):
        self._pool = OrderedDict()  # memory_path → AgentPipeline instance
        self._max_size = max_size
        # Build enricher once at pool creation — shared across all pipeline instances.
        # LLM-agnostic: reads ANTARIS_LLM_* env vars set by index.js from gateway's auth profile.
        self._enricher = make_enricher()
        # Cross-session context manager (v4.7.0)
        workspace = os.environ.get('OPENCLAW_WORKSPACE',
                                   os.path.join(os.path.expanduser('~'), '.openclaw', 'workspace'))
        self.cross_session = CrossSessionStateManager(workspace)

    def get(self, memory_path, cfg):
        """Get or create a pipeline for this memory_path.

        cfg is the raw request dict; relevant keys:
          guard_mode, guard_enabled, auto_recall, auto_ingest,
          search_limit, min_relevance
        """
        if memory_path in self._pool:
            self._pool.move_to_end(memory_path)
            return self._pool[memory_path]

        # Evict LRU if at capacity
        if len(self._pool) >= self._max_size:
            evicted_path, _ = self._pool.popitem(last=False)
            print(f"[PipelinePool] evicting LRU entry: {evicted_path}", file=sys.stderr)

        memory_config = {"enricher": self._enricher} if self._enricher else None
        # MEDIUM-05: extract agent_name from cfg (JavaScript sends agentName, Python sends agent_name)
        agent_name = cfg.get('agent_name') or cfg.get('agentName') or None
        pipeline = get_or_create_pipeline(
            memory_path,
            cfg.get('guard_mode', 'monitor'),
            guard_enabled=cfg.get('guard_enabled', True),
            memory_enabled=cfg.get('auto_recall', True) or cfg.get('auto_ingest', True),
            context_enabled=True,
            memory_config=memory_config,
            agent_name=agent_name,
        )
        self._pool[memory_path] = pipeline
        return pipeline

    def info(self):
        """Return a dict describing the current pool state."""
        return {
            "ok": True,
            "pool_size": len(self._pool),
            "max_size": self._max_size,
            "paths": list(self._pool.keys()),
        }


# Global pool — size configurable via env var, forwarded from JS bridgePoolSize config
pool = PipelinePool(max_size=int(os.environ.get('ANTARIS_POOL_SIZE', '4')))


def run_persistent_mode():
    """Run as a persistent NDJSON bridge process.

    FIX 5: Redirect sys.stdout at the top of this function so that any library
    or code that calls print() will write to stderr instead of stdout, protecting
    the NDJSON protocol from non-JSON contamination.  All protocol output goes
    exclusively through `protocol_print()`.
    """
    # Capture real stdout before redirecting
    _real_stdout = sys.stdout
    # Redirect all stray prints to stderr — NDJSON protocol uses _real_stdout only
    sys.stdout = sys.stderr

    def protocol_print(data: str) -> None:
        """Write a single line to the real stdout (NDJSON protocol channel)."""
        _real_stdout.write(data + '\n')
        _real_stdout.flush()

    try:
        for line in sys.stdin:
            line = line.strip()
            if not line:
                continue

            req_id = None  # FIX 2: initialise before parse so JSONDecodeError handler can safely reference it
            try:
                request = json.loads(line)
                cmd = request.get("cmd")
                req_id = request.get("_reqId")

                # FIX 1: Extract all config flags from every request
                guard_mode    = request.get("guard_mode", "monitor")
                guard_enabled = request.get("guard_enabled", True)
                auto_recall   = request.get("auto_recall", True)
                auto_ingest   = request.get("auto_ingest", True)
                search_limit  = request.get("search_limit", 5)
                min_relevance = request.get("min_relevance", 0.3)

                if cmd == "pool-info":
                    response = pool.info()

                elif cmd == "migrate-classify":
                    # v5.1.1: One-time retroactive memory type classification.
                    # Upgrades entries where memory_type == "episodic" (old default)
                    # to "semantic" if heuristic detects factual content.
                    # Additive-only — never demotes existing semantic/typed entries.
                    memory_path = request.get("memory_path", "./parsica_memory_store")
                    force = request.get("force", False)
                    try:
                        from pathlib import Path
                        import shutil
                        path = Path(memory_path)
                        meta_file = path / ".classification_meta.json"

                        # Check if already migrated
                        if not force and meta_file.exists():
                            meta = json.loads(meta_file.read_text())
                            if meta.get("migration_version") == "5.1.1":
                                response = {"ok": True, "skipped": True, "reason": "already migrated", "migrated_at": meta.get("migrated_at")}
                                protocol_print(json.dumps(response))
                                continue  # skip to next request

                        # Find memory files
                        candidates = []
                        flat = path / "memories.json"
                        if flat.exists():
                            candidates.append(flat)
                        shards_dir = path / "shards"
                        if shards_dir.exists():
                            candidates.extend(sorted(shards_dir.glob("*.json")))

                        total_scanned = 0
                        total_upgraded = 0

                        for store_file in candidates:
                            try:
                                data = json.loads(store_file.read_text(encoding="utf-8"))
                            except Exception:
                                continue
                            if isinstance(data, list):
                                entries = data
                                wrap_key = None
                            elif isinstance(data, dict) and "memories" in data:
                                entries = data["memories"]
                                wrap_key = "memories"
                            else:
                                continue

                            file_upgraded = 0
                            for entry in entries:
                                if not isinstance(entry, dict):
                                    continue
                                total_scanned += 1
                                # Migrate entries that are "episodic" OR missing memory_type entirely
                                if entry.get("memory_type") not in (None, "", "episodic"):
                                    continue
                                content = entry.get("content", "") or entry.get("text", "") or ""
                                if _classify_memory_type(content) == "semantic":
                                    entry["memory_type"] = "semantic"
                                    file_upgraded += 1
                                    total_upgraded += 1

                            if file_upgraded > 0:
                                from datetime import datetime as _dtbak
                                backup = store_file.with_suffix(f".bak_classify_{_dtbak.now().strftime('%Y%m%d_%H%M%S')}.json")
                                shutil.copy2(store_file, backup)
                                if wrap_key:
                                    data[wrap_key] = entries
                                    store_file.write_text(json.dumps(data, indent=2, ensure_ascii=False), encoding="utf-8")
                                else:
                                    store_file.write_text(json.dumps(entries, indent=2, ensure_ascii=False), encoding="utf-8")

                        # Write migration metadata
                        from datetime import datetime as _dtnow
                        meta = {"migrated_at": _dtnow.now().isoformat(), "migration_version": "5.1.1", "scanned": total_scanned, "upgraded": total_upgraded}
                        meta_file.write_text(json.dumps(meta, indent=2))
                        print(f"[bridge] migrate-classify: {total_scanned} scanned, {total_upgraded} upgraded → semantic", file=sys.stderr)
                        response = {"ok": True, "scanned": total_scanned, "upgraded": total_upgraded}
                    except Exception as e:
                        response = {"ok": False, "error": str(e)}

                elif cmd == "config-check":
                    memory_path = request.get("memory_path", "./parsica_memory_store")
                    # config-check always creates its own pipeline instance
                    response = handle_config_check(
                        memory_path, guard_mode,
                        guard_enabled=guard_enabled,
                        memory_enabled=auto_recall or auto_ingest,
                        context_enabled=True,
                    )

                elif cmd == "pre-turn":
                    memory_path = request.get("memory_path", "./parsica_memory_store")
                    text = request.get("text", "")

                    if not text:
                        response = {"ok": False, "error": "pre-turn requires 'text' field"}
                    else:
                        pipeline = pool.get(memory_path, request)
                        pre_session_id = request.get("session_id") or request.get("source_session")
                        cross_session_recall = request.get("cross_session_recall", "all")
                        response = handle_pre_turn(
                            pipeline, text, guard_mode,
                            auto_recall=auto_recall,
                            search_limit=search_limit,
                            min_relevance=min_relevance,
                            session_id=pre_session_id,
                            cross_session_recall=cross_session_recall,
                            cfg=request,
                        )

                elif cmd == "post-turn":
                    memory_path = request.get("memory_path", "./parsica_memory_store")
                    user_msg    = request.get("user_msg", "")
                    ai_response = request.get("ai_response", "")

                    if not user_msg or not ai_response:
                        response = {"ok": False, "error": "post-turn requires 'user_msg' and 'ai_response' fields"}
                    else:
                        pipeline = pool.get(memory_path, request)
                        turn_state = request.get("turn_state", {})
                        source_session = request.get("source_session") or request.get("session_id")
                        source_agent   = request.get("source_agent") or request.get("agent_id")
                        source_channel = request.get("source_channel") or request.get("channel_id")
                        # agent_id comes from pluginCfg.agentName (config-driven, no hardcodes).
                        # 'main' is OpenClaw's internal session label — not a valid agent identity.
                        # If we still get 'main' or empty, fall back to 'Agent' (neutral default).
                        if not source_agent or source_agent == 'main':
                            source_agent = 'Agent'
                        provenance_tags = []
                        provenance_source = None
                        if source_session:
                            provenance_tags.append(f"session:{source_session}")
                        if source_agent:
                            provenance_tags.append(f"agent:{source_agent}")
                        if source_channel:
                            provenance_tags.append(f"channel:{source_channel}")
                        if source_session:
                            provenance_source = f"agent_turn:{source_session}"
                        response = handle_post_turn(
                            pipeline, user_msg, ai_response, guard_mode,
                            auto_ingest=auto_ingest,
                            turn_state=turn_state,
                            source=provenance_source,
                            tags=provenance_tags if provenance_tags else None,
                            session_id=source_session,
                            agent_id=source_agent,
                            channel_id=source_channel,
                        )

                        # v4.7.0: Write cross-session turn
                        if request.get('cross_session_enabled'):
                            try:
                                cs_session_key = request.get('cross_session_key') or source_session or ''
                                cs_display = request.get('session_display', '')
                                cs_user_id = request.get('user_id', '')
                                cs_directed = request.get('directed_at')
                                cs_bot_mentioned = request.get('bot_was_mentioned', False)
                                cs_agent = source_agent or ''
                                if cs_bot_mentioned and not cs_directed:
                                    cs_directed = cs_agent
                                summary_text = user_msg[:200] if user_msg else ''
                                pool.cross_session.write_turn(
                                    session_key=cs_session_key,
                                    agent_id=cs_agent,
                                    display_name=cs_display,
                                    user_id=cs_user_id,
                                    directed_at=cs_directed,
                                    was_instruction=cs_bot_mentioned,
                                    summary=summary_text,
                                )
                            except Exception as cs_err:
                                print(f"[CrossSession] post-turn write error (non-fatal): {cs_err}", file=sys.stderr)

                elif cmd == "session-start":
                    memory_path = request.get("memory_path", "./parsica_memory_store")
                    summary     = request.get("summary", "")
                    pipeline = pool.get(memory_path, request)
                    # v4.7.0: read cross-session context if enabled
                    cs_ctx = None
                    if request.get('cross_session_enabled'):
                        try:
                            cs_key = request.get('cross_session_key', '')
                            cs_agent = request.get('agent_id') or request.get('agent_name') or ''
                            cs_ctx = pool.cross_session.read_other_sessions(cs_key, cs_agent)
                        except Exception as cs_err:
                            print(f"[CrossSession] session-start read error (non-fatal): {cs_err}", file=sys.stderr)
                    response = handle_session_start(pipeline, summary,
                        agent_name=request.get('agent_name') or request.get('agent_id'),
                        cross_session_context=cs_ctx)

                elif cmd == "re-enrich-store":
                    # Run re_enrich() on an existing memory store using the
                    # pool's live enricher (which already has the real API key).
                    memory_path  = request.get("memory_path", "./parsica_memory_store")
                    batch_size   = int(request.get("batch_size", 10))
                    overwrite    = bool(request.get("overwrite", False))
                    pipeline     = pool.get(memory_path, request)
                    if pipeline is None or not hasattr(pipeline, 'pipeline') or \
                            pipeline.pipeline is None:
                        response = {"ok": False, "error": "pipeline not available"}
                    elif not pool._enricher:
                        response = {"ok": False, "error": "enricher not configured"}
                    else:
                        memory = pipeline.pipeline.memory
                        enriched_count = [0]
                        def re_enrich_progress(done, total):
                            enriched_count[0] = done
                            print(f"[re-enrich] {done}/{total} "
                                  f"({done/total*100:.1f}%) "
                                  f"cost=${done*0.000004:.6f}", file=sys.stderr, flush=True)
                        try:
                            memory.re_enrich(batch_size=batch_size,
                                             progress_fn=re_enrich_progress,
                                             overwrite=overwrite)
                            response = {"ok": True,
                                        "enriched": enriched_count[0],
                                        "cost_usd": round(enriched_count[0] * 0.000004, 6)}
                        except Exception as exc:
                            response = {"ok": False, "error": str(exc)}

                elif cmd == "ingest-discord-message":
                    memory_path  = request.get("memory_path", "./parsica_memory_store")
                    content      = request.get("content", "")
                    sender_name  = request.get("sender", "unknown")
                    channel_id   = request.get("channel_id", "")
                    message_id   = request.get("message_id", "")
                    source_agent = request.get("source_agent")

                    if not content.strip():
                        response = {"ok": False, "error": "empty content"}
                    else:
                        pipeline = pool.get(memory_path, request)
                        provenance_tags = ["discord"]
                        if channel_id:
                            provenance_tags.append(f"channel:{channel_id}")
                        if source_agent:
                            provenance_tags.append(f"agent:{source_agent}")
                        if message_id:
                            provenance_tags.append(f"msg:{message_id}")
                        source_label = f"discord:{channel_id}" if channel_id else "discord"

                        try:
                            tagged_content = f"[{sender_name}] {content}"
                            if pipeline and pipeline.pipeline and hasattr(pipeline.pipeline, 'memory') and pipeline.pipeline.memory:
                                count = pipeline.pipeline.memory.ingest(
                                    tagged_content,
                                    source=source_label,
                                    category="discord",
                                    memory_type="episodic",
                                    tags=provenance_tags,
                                )
                                response = {"ok": True, "stored": count}
                            else:
                                response = {"ok": False, "error": "memory component not available"}
                        except Exception as e:
                            response = {"ok": False, "error": str(e)}

                elif cmd == "get-cross-session-context":
                    session_key = request.get("session_key", "")
                    agent_id = request.get("agent_id", "")
                    max_age = request.get("max_age_seconds", 7200)
                    if session_key:
                        other_turns = pool.cross_session.read_other_sessions(
                            session_key, agent_id, max_age_seconds=max_age)
                    else:
                        other_turns = []
                    response = {
                        "ok": True,
                        "state": pool.cross_session.get_full_state(),
                        "other_sessions": other_turns,
                    }

                elif cmd == "register-agent":
                    agent_id = request.get("agent_id", "")
                    bot_id = request.get("bot_id", "")
                    pool.cross_session.register_agent(agent_id, bot_id)
                    response = {"ok": True}

                elif cmd == "memory-search":
                    memory_path = request.get("memory_path", "./parsica_memory_store")
                    query = request.get("query", "")
                    limit = request.get("limit", 5)

                    if not query.strip():
                        response = {"ok": False, "error": "empty query"}
                    else:
                        pipeline = pool.get(memory_path, request)
                        try:
                            if pipeline and pipeline.pipeline and hasattr(pipeline.pipeline, 'memory') and pipeline.pipeline.memory:
                                results = pipeline.pipeline.memory.search(query, limit=limit)
                                formatted = []
                                for r in results:
                                    entry = {
                                        "content": r.content if hasattr(r, 'content') else str(r),
                                        "score":   r.score   if hasattr(r, 'score')   else 0.0,
                                        "source":  r.source  if hasattr(r, 'source')  else "unknown",
                                        "tags":    r.tags    if hasattr(r, 'tags')    else [],
                                    }
                                    formatted.append(entry)
                                response = {"ok": True, "results": formatted}
                            else:
                                response = {"ok": False, "error": "memory component not available"}
                        except Exception as e:
                            response = {"ok": False, "error": str(e)}

                elif cmd == "ping":
                    response = {"ok": True, "alive": True}

                # ── v3.1: /search with provenance ────────────────────────────
                elif cmd == "search":
                    memory_path = request.get("memory_path", "./parsica_memory_store")
                    query = request.get("query", "")
                    limit = request.get("limit", 5)

                    if not query.strip():
                        response = {"ok": False, "error": "empty query"}
                    else:
                        pipeline = pool.get(memory_path, request)
                        try:
                            if pipeline and pipeline.pipeline and hasattr(pipeline.pipeline, 'memory') and pipeline.pipeline.memory:
                                results = pipeline.pipeline.memory.search(query, limit=limit, explain=True)
                                formatted = []
                                for r in results:
                                    entry = r.entry if hasattr(r, 'entry') else r
                                    formatted.append({
                                        "content":     entry.content if hasattr(entry, 'content') else str(entry),
                                        "score":       r.score if hasattr(r, 'score') else 0.0,
                                        "relevance":   r.relevance if hasattr(r, 'relevance') else 0.0,
                                        "source":      getattr(entry, 'source', 'unknown'),
                                        "timestamp":   getattr(entry, 'timestamp', None) or getattr(entry, 'created_at', 'unknown'),
                                        "session_id":  getattr(entry, 'session_id', ''),
                                        "channel_id":  getattr(entry, 'channel_id', ''),
                                        "tags":        getattr(entry, 'tags', []),
                                        "explanation": r.explanation if hasattr(r, 'explanation') else '',
                                        "matched":     r.matched_terms if hasattr(r, 'matched_terms') else [],
                                    })
                                response = {"ok": True, "results": formatted}
                            else:
                                response = {"ok": False, "error": "memory component not available"}
                        except Exception as e:
                            response = {"ok": False, "error": str(e)}

                # ── v3.1: enrichment toggle ──────────────────────────────────
                elif cmd == "set-enrichment":
                    memory_path = request.get("memory_path", "./parsica_memory_store")
                    enabled = request.get("enabled", True)
                    try:
                        pipeline = pool.get(memory_path, request)
                        if pipeline and pipeline.pipeline:
                            pipeline.pipeline._enrichment_enabled = bool(enabled)
                            mem = getattr(pipeline.pipeline, 'memory', None)
                            if mem is not None:
                                mem._enrichment_enabled = bool(enabled)
                            response = {"ok": True, "enabled": bool(enabled)}
                        else:
                            response = {"ok": False, "error": "pipeline not available"}
                    except Exception as e:
                        response = {"ok": False, "error": str(e)}

                elif cmd == "enrichment-status":
                    memory_path = request.get("memory_path", "./parsica_memory_store")
                    try:
                        pipeline = pool.get(memory_path, request)
                        if pipeline and pipeline.pipeline and hasattr(pipeline.pipeline, 'memory') and pipeline.pipeline.memory:
                            mem = pipeline.pipeline.memory
                            total = len(mem.memories)
                            enriched = sum(1 for m in mem.memories if getattr(m, 'enriched_summary', ''))
                            enabled = getattr(pipeline.pipeline, '_enrichment_enabled', True)
                            model = getattr(pipeline.pipeline, '_enrichment_model', 'gateway default')
                            response = {
                                "ok": True,
                                "enabled": enabled,
                                "model": model,
                                "total": total,
                                "enriched": enriched,
                                "remaining": total - enriched,
                                "coverage": (enriched / total * 100) if total > 0 else 0,
                            }
                        else:
                            response = {"ok": False, "error": "memory component not available"}
                    except Exception as e:
                        response = {"ok": False, "error": str(e)}

                # ── v3.1: decomposition toggle ───────────────────────────────
                elif cmd == "set-decomposition":
                    memory_path = request.get("memory_path", "./parsica_memory_store")
                    enabled = request.get("enabled", False)
                    try:
                        pipeline = pool.get(memory_path, request)
                        if pipeline and pipeline.pipeline:
                            pipeline.pipeline._decomposition_enabled = bool(enabled)
                            mem = getattr(pipeline.pipeline, 'memory', None)
                            if mem is not None:
                                mem._decomposition_enabled = bool(enabled)
                            response = {"ok": True, "enabled": bool(enabled)}
                        else:
                            response = {"ok": False, "error": "pipeline not available"}
                    except Exception as e:
                        response = {"ok": False, "error": str(e)}

                elif cmd == "decomposition-status":
                    memory_path = request.get("memory_path", "./parsica_memory_store")
                    try:
                        pipeline = pool.get(memory_path, request)
                        if pipeline and pipeline.pipeline and hasattr(pipeline.pipeline, 'memory') and pipeline.pipeline.memory:
                            mem = pipeline.pipeline.memory
                            total = len(mem.memories)
                            # Count decomposed = memories that have child facts
                            decomposed = sum(1 for m in mem.memories if getattr(m, 'memory_type', '') == 'fact')
                            enabled = getattr(pipeline.pipeline, '_decomposition_enabled', False)
                            response = {
                                "ok": True,
                                "enabled": enabled,
                                "total": total,
                                "decomposed": decomposed,
                            }
                        else:
                            response = {"ok": False, "error": "memory component not available"}
                    except Exception as e:
                        response = {"ok": False, "error": str(e)}

                elif cmd == "synthesize-session-summary":
                    # Read last N turns from session JSONL, call LLM enricher,
                    # ingest result as episodic memory. Non-fatal — never blocks compaction.
                    try:
                        session_file  = request.get("session_file", "")
                        memory_path   = request.get("memory_path", "./parsica_memory_store")
                        channel_name  = request.get("channel_name", "unknown")
                        agent_name_ss = request.get("agent_name", "Agent")
                        max_turns     = int(request.get("max_turns", 60))  # v5.0.1 fix C-3: increased from 30

                        if not session_file or not os.path.exists(session_file):
                            response = {"ok": False, "skipped": True, "reason": "session file not found"}
                        else:
                            # Parse the JSONL and extract last N user/assistant turns
                            turns = []
                            try:
                                with open(session_file, "r", encoding="utf-8") as fh:
                                    for line in fh:
                                        line = line.strip()
                                        if not line:
                                            continue
                                        try:
                                            entry = json.loads(line)
                                        except Exception:
                                            continue
                                        role = entry.get("role", "")
                                        content = entry.get("content", "")
                                        if role in ("user", "assistant") and content:
                                            # Skip context packets and system injections
                                            if "ANTARIS_CTX_START" in content or "[MEMORY RESTORED]" in content:
                                                continue
                                            # Truncate very long entries
                                            turns.append({"role": role, "content": content[:800]})
                            except Exception as read_err:
                                response = {"ok": False, "skipped": True, "reason": f"read error: {read_err}"}
                                turns = []

                            if turns:
                                # Keep last max_turns entries
                                recent = turns[-max_turns:]

                                # Build synthesis prompt
                                convo_text = "\n".join(
                                    f"{t['role'].upper()}: {t['content']}" for t in recent
                                )
                                synthesis_prompt = (
                                    "You are summarizing a session between an AI assistant and a user. "
                                    "Write a concise episodic memory (~150-200 words) capturing:\n"
                                    "- Key decisions made\n"
                                    "- Projects discussed or worked on\n"
                                    "- Code/features shipped or planned\n"
                                    "- Important facts, changes, or lessons learned\n"
                                    "- Anything the agent should remember for future sessions\n\n"
                                    "Write in past tense, third person. Be specific — names, versions, "
                                    "file paths, decisions. Skip small talk.\n\n"
                                    f"SESSION TRANSCRIPT ({len(recent)} turns):\n{convo_text}\n\n"
                                    "EPISODIC MEMORY SUMMARY:"
                                )

                                # v5.0.1 fix C-3: direct LLM call instead of enricher
                                # (enricher truncates to 600 chars and returns wrong key)
                                pipeline_obj = pool.get(memory_path, request)
                                summary_text = None

                                # Direct LLM synthesis using same urllib pattern as make_enricher()
                                try:
                                    from urllib.request import Request as _Req, urlopen as _urlopen
                                    _api_key = os.environ.get("ANTARIS_LLM_API_KEY", "") or os.environ.get("ANTHROPIC_API_KEY", "")
                                    _api_format = os.environ.get("ANTARIS_LLM_API_FORMAT", "anthropic-messages")
                                    _base_url = os.environ.get("ANTARIS_LLM_BASE_URL", "https://api.anthropic.com")
                                    _model = "claude-haiku-4-5-20251001"  # cheap+fast for summarization

                                    if _api_key:
                                        if _api_format == "anthropic-messages":
                                            _url = f"{_base_url.rstrip('/')}/v1/messages"
                                            _payload = json.dumps({
                                                "model": _model,
                                                "max_tokens": 500,
                                                "messages": [{"role": "user", "content": synthesis_prompt}],
                                            })
                                            _req = _Req(_url, data=_payload.encode("utf-8"), method="POST")
                                            _req.add_header("Content-Type", "application/json")
                                            _req.add_header("x-api-key", _api_key)
                                            _req.add_header("anthropic-version", "2023-06-01")
                                        else:
                                            _url = f"{_base_url.rstrip('/')}/v1/chat/completions"
                                            _payload = json.dumps({
                                                "model": _model,
                                                "max_tokens": 500,
                                                "messages": [{"role": "user", "content": synthesis_prompt}],
                                            })
                                            _req = _Req(_url, data=_payload.encode("utf-8"), method="POST")
                                            _req.add_header("Content-Type", "application/json")
                                            _req.add_header("Authorization", f"Bearer {_api_key}")

                                        with _urlopen(_req, timeout=45) as _resp:
                                            _data = json.loads(_resp.read().decode("utf-8"))
                                            if _api_format == "anthropic-messages":
                                                summary_text = _data["content"][0]["text"].strip()
                                            else:
                                                summary_text = _data["choices"][0]["message"]["content"].strip()
                                    else:
                                        response = {"ok": False, "skipped": True, "reason": "no LLM API key available"}
                                except Exception as llm_err:
                                    response = {"ok": False, "skipped": True, "reason": f"LLM call error: {llm_err}"}

                                if summary_text:
                                    # Ingest via pipeline memory (prefer pipeline_obj, fallback gracefully)
                                    mem = None
                                    if pipeline_obj and pipeline_obj.pipeline:
                                        mem = getattr(pipeline_obj.pipeline, 'memory', None)
                                    if mem:
                                        import datetime
                                        today = datetime.date.today().isoformat()
                                        session_id_ss = request.get("session_id", "unknown")
                                        mem.ingest(
                                            summary_text,
                                            source="session_summary",
                                            memory_type="episodic",
                                            tags=["session_summary", channel_name, today, session_id_ss],
                                        )
                                        response = {"ok": True, "ingested": True, "length": len(summary_text)}
                                    else:
                                        response = {"ok": False, "skipped": True, "reason": "pipeline not available for ingest"}
                                elif "ok" not in response:
                                    response = {"ok": False, "skipped": True, "reason": "empty summary from LLM"}
                            else:
                                response = {"ok": True, "skipped": True, "reason": "no turns found in session file"}

                    except Exception as e:
                        response = {"ok": True, "skipped": True, "reason": f"synthesis error (non-fatal): {e}"}

                elif cmd == "pre-compaction":
                    # Flush in-flight pipeline state before compaction
                    try:
                        if pool:
                            # Signal all pool workers to flush
                            for worker in pool._pool if hasattr(pool, '_pool') else []:
                                if hasattr(worker, 'pipeline') and worker.pipeline:
                                    pass  # flush is implicit on next turn
                        response = {"ok": True, "flushed": True}
                    except Exception as e:
                        response = {"ok": True, "flushed": False, "note": str(e)}

                elif cmd == "store-handoff":
                    # Persist a handoff note to memory so post-compaction recovery can inject it
                    try:
                        note = request.get("note", "")
                        memory_path = request.get("memory_path", "./parsica_memory_store")
                        if note:
                            pipeline = pool.get(memory_path, request)
                            if pipeline and pipeline.pipeline and hasattr(pipeline.pipeline, 'memory') and pipeline.pipeline.memory:
                                pipeline.pipeline.memory.ingest(f"[HANDOFF NOTE] {note}", source="compaction_handoff", tags=["handoff", "compaction"])
                        response = {"ok": True}
                    except Exception as e:
                        response = {"ok": True, "note": f"handoff store skipped: {e}"}

                elif cmd == "compaction-recovery":
                    # Load and return recovery context to inject into the new session
                    try:
                        memory_path = request.get("memory_path", "./parsica_memory_store")
                        pipeline = pool.get(memory_path, request)
                        recovery_text = ""
                        if pipeline and pipeline.pipeline and hasattr(pipeline.pipeline, 'memory') and pipeline.pipeline.memory:
                            results = pipeline.pipeline.memory.search("[HANDOFF NOTE]", limit=3)
                            if results:
                                recovery_text = "\n".join(
                                    r.content if hasattr(r, 'content') else str(r)
                                    for r in results
                                )
                        response = {"ok": True, "recovery_context": recovery_text}
                    except Exception as e:
                        response = {"ok": True, "recovery_context": "", "note": str(e)}

                elif cmd == "check-pending-handoff":
                    # Report whether a handoff note is waiting for injection
                    try:
                        memory_path = request.get("memory_path", "./parsica_memory_store")
                        pipeline = pool.get(memory_path, request)
                        has_handoff = False
                        if pipeline and pipeline.pipeline and hasattr(pipeline.pipeline, 'memory') and pipeline.pipeline.memory:
                            results = pipeline.pipeline.memory.search("[HANDOFF NOTE]", limit=1)
                            has_handoff = len(results) > 0
                        response = {"ok": True, "has_pending": has_handoff}
                    except Exception as e:
                        response = {"ok": True, "has_pending": False, "note": str(e)}

                elif cmd == "ingest-vision":
                    # Store image/video description as a vision memory entry.
                    # Payload: { description, media_type, filename, turn_query }
                    memory_path = request.get("memory_path", "./parsica_memory_store")
                    description = (request.get("description") or "").strip()
                    media_type  = request.get("media_type", "image")
                    filename    = request.get("filename", "")
                    turn_query  = request.get("turn_query", "")

                    if not description:
                        response = {"ok": True, "skipped": "empty description"}
                    else:
                        try:
                            pipeline = pool.get(memory_path, request)
                            media_label = "Image" if media_type == "image" else "Video"
                            file_note   = f' ("{filename}")' if filename else ""
                            query_note  = f"\nUser context: {turn_query}" if turn_query else ""
                            content = (
                                f"[{media_label} attachment{file_note} described]\n"
                                f"{description}"
                                f"{query_note}"
                            )
                            pipeline.pipeline.memory.add(
                                content=content,
                                source="agent_turn:vision",
                                tags=["vision", media_type],
                            )
                            pipeline.pipeline.memory.search_engine.mark_dirty()
                            pipeline.pipeline.memory._save_sharded()
                            response = {"ok": True, "media_type": media_type, "chars": len(content)}
                        except Exception as e:
                            response = {"ok": False, "error": str(e)}

                elif cmd == "session-startup-recall":
                    # Change 2: Pull cross-instance context for a new session's first turn.
                    # Returns up to search_limit recent channel_sync memories from OTHER sessions.
                    memory_path = request.get("memory_path", "./parsica_memory_store")
                    hours = request.get("hours", 24)
                    search_limit = request.get("search_limit", 6)
                    current_session = request.get("current_session", "")
                    try:
                        import time as _time
                        pipeline = pool.get(memory_path, request)
                        ms = pipeline.pipeline.memory
                        cutoff = _time.time() - (hours * 3600)
                        sync_memories = []
                        for mem in ms.memories:
                            ts = getattr(mem, 'timestamp', None) or 0
                            if ts < cutoff:
                                continue
                            tags = getattr(mem, 'tags', []) or []
                            source = getattr(mem, 'source', '') or ''
                            # Skip memories from this session
                            session_tag = next((t for t in tags if t.startswith('session:')), None)
                            if session_tag and current_session and current_session in session_tag:
                                continue
                            if 'channel_sync' in tags or source == 'channel_sync':
                                sync_memories.append(mem)
                        sync_memories.sort(key=lambda m: getattr(m, 'timestamp', 0) or 0, reverse=True)
                        sync_memories = sync_memories[:search_limit]
                        if not sync_memories:
                            response = {"ok": True, "context": None}
                        else:
                            lines = ["[Cross-instance context — recent channel activity]"]
                            for mem in sync_memories:
                                tags = getattr(mem, 'tags', []) or []
                                channel_tag = next((t.replace('channel_sync:', '').replace('channel:', '')
                                                   for t in tags if 'channel' in t and t != 'channel_sync'), 'unknown channel')
                                ts = getattr(mem, 'timestamp', 0) or 0
                                age_min = int((_time.time() - ts) / 60) if ts else 0
                                content = (getattr(mem, 'content', '') or '')[:300]
                                lines.append(f"[{channel_tag}, {age_min} min ago] {content}")
                            response = {"ok": True, "context": '\n'.join(lines)}
                    except Exception as e:
                        response = {"ok": True, "context": None, "error": str(e)}

                elif cmd == "recall-recent-cross-session":
                    # Change 3: Per-turn scan for memories from OTHER sessions in the last N minutes.
                    # This is the Feb 4 protection — instances see what other instances just did.
                    memory_path = request.get("memory_path", "./parsica_memory_store")
                    since_minutes = request.get("since_minutes", 30)
                    current_session = request.get("current_session", "")
                    limit = request.get("limit", 3)
                    try:
                        import time as _time
                        pipeline = pool.get(memory_path, request)
                        ms = pipeline.pipeline.memory
                        cutoff = _time.time() - (since_minutes * 60)
                        recent = []
                        for mem in ms.memories:
                            ts = getattr(mem, 'timestamp', None) or 0
                            if ts < cutoff:
                                continue
                            tags = getattr(mem, 'tags', []) or []
                            source = getattr(mem, 'source', '') or ''
                            # Requires Change 1: only memories with session tag
                            session_tag = next((t for t in tags if t.startswith('session:')), None)
                            if not session_tag:
                                continue
                            session_id = session_tag.replace('session:', '')
                            if current_session and session_id == current_session:
                                continue  # Skip own memories
                            if source == 'channel_sync':
                                continue  # channel_sync handled by startup recall
                            recent.append(mem)
                        recent.sort(key=lambda m: getattr(m, 'timestamp', 0) or 0, reverse=True)
                        recent = recent[:limit]
                        if not recent:
                            response = {"ok": True, "context": None, "count": 0}
                        else:
                            lines = ["[Recent cross-session activity — last 30 min]"]
                            for mem in recent:
                                tags = getattr(mem, 'tags', []) or []
                                channel_tag = next((t.replace('channel:', '') for t in tags
                                                   if t.startswith('channel:') and t != 'channel_sync'), 'unknown')
                                ts = getattr(mem, 'timestamp', 0) or 0
                                age_min = int((_time.time() - ts) / 60) if ts else 0
                                content = (getattr(mem, 'content', '') or '')[:200]
                                lines.append(f"[From {channel_tag}, {age_min} min ago] {content}")
                            response = {"ok": True, "context": '\n'.join(lines), "count": len(recent)}
                    except Exception as e:
                        response = {"ok": True, "context": None, "count": 0, "error": str(e)}

                elif cmd == "prune":
                    # ── /prune small|medium|large ─────────────────────────────
                    # Tiered memory cleanup with dual-layer protection.
                    # Never deletes entries with importance >= 0.8 or access_count >= 3.
                    import shutil, re as _re, datetime as _dt

                    tier      = request.get("tier", "small")       # small | medium | large
                    dry_run   = request.get("dry_run", True)
                    _mem_path  = request.get("memory_path") or memory_path
                    shards_dir = os.path.join(_mem_path, "shards")
                    ac_path    = os.path.join(_mem_path, "access_counts.json")

                    try:
                        ac = json.load(open(ac_path)) if os.path.exists(ac_path) else {}
                    except Exception:
                        ac = {}

                    import time as _time
                    now_ts = _time.time()

                    def entry_age_days(entry):
                        raw = entry.get("created") or entry.get("last_accessed") or ""
                        if not raw:
                            return 9999
                        try:
                            ts = _dt.datetime.fromisoformat(raw.replace("Z",""))
                            return (now_ts - ts.timestamp()) / 86400
                        except Exception:
                            return 9999

                    def entry_access(entry):
                        h = entry.get("hash", "")
                        return ac.get(h, entry.get("access_count", 0))

                    PIPELINE_PREFIXES = ("INPUT:", "OUTPUT:", "Turn:", "HEARTBEAT", "heartbeat")
                    FILLER_PATTERNS   = ("good morning", "good night", "sounds good", "got it!", "ok!", "noted!", "will do")

                    # Tags that mark important project memories — always keep
                    KEEP_TAGS = {"decision", "rule", "lesson", "milestone", "credential", "key_fact"}

                    def should_prune(entry, tier):
                        content   = (entry.get("content") or "").strip()
                        imp       = float(entry.get("importance") or 0)
                        acc       = entry_access(entry)
                        age       = entry_age_days(entry)
                        src       = (entry.get("source") or "").lower()
                        tags      = set(entry.get("tags") or [])
                        cat       = (entry.get("category") or "").lower()

                        # ── PROTECTED — never delete ──────────────────────────
                        # High access = genuinely useful
                        if acc >= 5:   return False, None
                        # Important project tags
                        if tags & KEEP_TAGS: return False, None
                        # High enriched importance (set by LLM enricher, not default 1.0)
                        if imp >= 2.5: return False, None

                        # Default importance is exactly 1.0 — treat as "unscored"
                        is_default_imp = (imp == 1.0)

                        # ── SMALL tier ────────────────────────────────────────
                        # Pipeline fragments
                        if content.startswith(PIPELINE_PREFIXES):
                            return True, "pipeline_fragment"
                        # Very short and zero-access (never recalled)
                        if len(content) < 40 and acc == 0:
                            return True, "too_short"
                        # Heartbeat noise source only (not pipeline: context memories)
                        if src in ("heartbeat", "system", "internal") and acc == 0:
                            return True, "heartbeat_noise"
                        # Code snippets / test output — zero access, default importance
                        if acc == 0 and is_default_imp and age > 5 and cat in ("code", "test", "log", ""):
                            # Only if content looks like code/junk (no capitals starting, lots of symbols)
                            sym_ratio = sum(1 for c in content if not c.isalnum() and c not in " .,!?-_") / max(len(content),1)
                            if sym_ratio > 0.15:
                                return True, "code_junk_unaccessed"

                        if tier == "small":
                            return False, None

                        # ── MEDIUM tier ───────────────────────────────────────
                        # Zero-access, default importance, older than 7 days
                        if acc == 0 and is_default_imp and age > 7:
                            return True, "zero_access_default_imp"
                        # Near-filler content
                        cl = content.lower()
                        if any(p in cl for p in FILLER_PATTERNS) and acc < 2:
                            return True, "filler_content"

                        if tier == "medium":
                            return False, None

                        # ── LARGE tier ────────────────────────────────────────
                        # Zero-access, any importance < 2.0, older than 5 days
                        if acc == 0 and imp < 2.0 and age > 5:
                            return True, "zero_access_stale"

                        return False, None

                    # ── Scan shards ──────────────────────────────────────────
                    live_shards = [s for s in os.listdir(shards_dir)
                                   if s.endswith(".json") and ".bak" not in s]

                    total_scanned = 0
                    to_remove     = []   # (shard_file, hash)
                    samples       = []

                    for sf in live_shards:
                        shard_path = os.path.join(shards_dir, sf)
                        try:
                            shard = json.load(open(shard_path))
                        except Exception:
                            continue
                        entries = shard.get("memories", [])
                        total_scanned += len(entries)
                        for e in entries:
                            ok, reason = should_prune(e, tier)
                            if ok:
                                to_remove.append((sf, e.get("hash",""), reason))
                                if len(samples) < 20:
                                    samples.append({
                                        "reason":          reason,
                                        "age_days":        round(entry_age_days(e), 1),
                                        "access_count":    entry_access(e),
                                        "importance":      e.get("importance", 0),
                                        "content_preview": (e.get("content") or "")[:120],
                                    })

                    removed = len(to_remove)
                    kept    = total_scanned - removed

                    if dry_run:
                        response = {
                            "ok":            True,
                            "dry_run":       True,
                            "tier":          tier,
                            "total_scanned": total_scanned,
                            "removed":       removed,
                            "kept":          kept,
                            "samples":       samples,
                        }
                    else:
                        # ── Backup first ─────────────────────────────────────
                        ts_str     = _dt.datetime.now().strftime("%Y%m%d_%H%M%S")
                        backup_dir = os.path.join(_mem_path, f"shards.bak_pre_prune_{ts_str}")
                        shutil.copytree(shards_dir, backup_dir)

                        # ── Group removals by shard ───────────────────────────
                        from collections import defaultdict as _dd
                        by_shard = _dd(set)
                        for (sf, h, _reason) in to_remove:
                            by_shard[sf].add(h)

                        # ── Apply removals ────────────────────────────────────
                        actual_removed = 0
                        for sf, hashes in by_shard.items():
                            shard_path = os.path.join(shards_dir, sf)
                            try:
                                shard = json.load(open(shard_path))
                                before = len(shard.get("memories", []))
                                shard["memories"] = [
                                    e for e in shard.get("memories", [])
                                    if e.get("hash", "") not in hashes
                                ]
                                after = len(shard["memories"])
                                actual_removed += (before - after)
                                shard["count"] = after
                                with open(shard_path, "w") as fh:
                                    json.dump(shard, fh, indent=2)
                            except Exception as _e:
                                print(f"[prune] Failed to update shard {sf}: {_e}", file=sys.stderr)

                        response = {
                            "ok":            True,
                            "dry_run":       False,
                            "tier":          tier,
                            "total_scanned": total_scanned,
                            "removed":       actual_removed,
                            "kept":          total_scanned - actual_removed,
                            "backup_path":   backup_dir,
                            "samples":       samples,
                        }

                elif cmd == "prune-list-backups":
                    _mem_path   = request.get("memory_path") or memory_path
                    shards_dir = os.path.join(_mem_path, "shards")
                    parent     = os.path.dirname(shards_dir)
                    raw_backups = sorted([
                        d for d in os.listdir(parent)
                        if d.startswith("shards.bak_pre_prune_")
                    ], reverse=True)
                    backup_list = []
                    for b in raw_backups:
                        # e.g. "shards.bak_pre_prune_20260308_144202"
                        parts = b.split('_')
                        # last two parts are date and time
                        timestamp_str = '_'.join(parts[-2:]) if len(parts) >= 2 else b
                        # count entries in the backup directory
                        backup_full = os.path.join(parent, b)
                        try:
                            entry_count = len([f for f in os.listdir(backup_full) if f.endswith('.json')])
                        except Exception:
                            entry_count = 0
                        backup_list.append({
                            "name": b,
                            "timestamp": timestamp_str,
                            "tier": "unknown",
                            "count": entry_count,
                        })
                    response = {"ok": True, "backups": backup_list}

                elif cmd == "prune-undo":
                    import shutil as _sh
                    _mem_path   = request.get("memory_path") or memory_path
                    timestamp  = request.get("timestamp", "")
                    shards_dir = os.path.join(_mem_path, "shards")
                    parent     = os.path.dirname(shards_dir)
                    if timestamp:
                        backup_name = f"shards.bak_pre_prune_{timestamp}"
                    else:
                        # most recent
                        candidates = sorted([
                            d for d in os.listdir(parent)
                            if d.startswith("shards.bak_pre_prune_")
                        ], reverse=True)
                        backup_name = candidates[0] if candidates else None
                    if not backup_name:
                        response = {"ok": False, "error": "No prune backup found"}
                    else:
                        backup_path = os.path.join(parent, backup_name)
                        if not os.path.exists(backup_path):
                            response = {"ok": False, "error": f"Backup not found: {backup_name}"}
                        else:
                            import time as _time_undo
                            from pathlib import Path as _PathUndo
                            shards_path_obj = _PathUndo(shards_dir)
                            tmp_restore = shards_path_obj.parent / f"shards_tmp_restore_{int(_time_undo.time())}"
                            # 1. Copy backup to temp first (verify backup is readable)
                            _sh.copytree(backup_path, tmp_restore)
                            # 2. Remove old shards
                            _sh.rmtree(shards_dir)
                            # 3. Rename temp to final (atomic on same filesystem)
                            tmp_restore.rename(shards_dir)
                            response = {"ok": True, "restored_from": backup_name}

                elif cmd == "summarize-all-channels":
                    # DEPRECATED STUB — auto-sync placeholder.
                    # Real gathering is done via /gather command in index.js which
                    # injects agent instructions to read Discord channels via the
                    # message(action="read") tool. This bridge command is kept for
                    # backward compatibility with the 6h auto-sync cron.
                    response = {"ok": True, "synced_channels": [], "note": "Channel gathering handled by /gather agent intercept in index.js"}

                else:
                    response = {"ok": False, "error": f"Unknown command: {cmd}"}

                # Add request ID to response if present
                if req_id is not None:
                    response["_reqId"] = req_id

                # FIX 5: always use protocol_print, never bare print()
                protocol_print(json.dumps(response))

            except json.JSONDecodeError as e:
                error_response = {"ok": False, "error": f"Invalid JSON: {e}"}
                if req_id is not None:
                    error_response["_reqId"] = req_id
                protocol_print(json.dumps(error_response))
            except Exception as e:
                error_response = {"ok": False, "error": f"Processing error: {e}"}
                if req_id is not None:
                    error_response["_reqId"] = req_id
                protocol_print(json.dumps(error_response))

    except KeyboardInterrupt:
        pass
    except EOFError:
        pass  # Clean exit when stdin closes


def handle_config_check(
    memory_path,
    guard_mode,
    guard_enabled=True,
    memory_enabled=True,
    context_enabled=True,
):
    """Handle config-check command."""
    try:
        pipeline = get_or_create_pipeline(
            memory_path, guard_mode,
            guard_enabled=guard_enabled,
            memory_enabled=memory_enabled,
            context_enabled=context_enabled,
        )
        if pipeline is None:
            return {
                "ok": False,
                "error": "antaris-pipeline not installed",
                "components": {"memory": False, "guard": False, "context": False, "router": False}
            }

        stats = pipeline.get_stats()
        return {
            "ok": True,
            "components": stats["components_available"],
            "config": {
                "memory_enabled": stats["components_enabled"]["memory"],
                "guard_enabled":  stats["components_enabled"]["guard"],
                "context_enabled": stats["components_enabled"]["context"],
                "router_enabled": stats["components_enabled"]["router"],
                "guard_mode":     stats["guard_mode"]
            }
        }
    except Exception as e:
        return {"ok": False, "error": str(e)}


def _classify_memory_type(text: str) -> str:
    """Heuristic classifier: returns 'episodic' for task instructions, 'semantic' for facts.

    Episodic patterns: imperative verbs, step instructions, in-progress task markers.
    Semantic patterns: factual statements, identity, decisions, project context.
    Default: 'semantic' (safer for cross-session sharing).
    """
    t = text.lower().strip()

    # Strong episodic signals — task/instruction patterns
    episodic_patterns = [
        r'\b(fix|build|push|deploy|write|create|update|add|remove|delete|run|execute|implement|refactor|debug|test|check|verify|install|configure|restart|migrate)\b',
        r'\b(next step|step \d|in progress|working on|currently|todo|doing|pending|blocked on)\b',
        r'\b(please|could you|would you|can you|make sure|don\'t forget|remember to)\b',
        r'^(user:|bot:)',  # conversation turns
        r'\b(error|exception|traceback|failed|broken|bug|issue|problem with)\b',
    ]
    semantic_patterns = [
        r'\b(is|are|was|were|will be|has been)\b.*\b(named|called|known as|based in|located|founded|created|built|owned)\b',
        r'\b(my name is|i am|we are|our|antaris|moro|shiro|jason|jake)\b',
        r'\b(version|v\d+\.\d+|released|launched|shipped|live on pypi)\b',
        r'\b(decided|agreed|confirmed|locked|finalized|established)\b',
        r'\b(always|never|rule|policy|principle|guideline)\b',
    ]

    # Count pattern hits
    episodic_hits = sum(1 for p in episodic_patterns if re.search(p, t))
    semantic_hits = sum(1 for p in semantic_patterns if re.search(p, t))

    if episodic_hits > semantic_hits:
        return "episodic"
    return "semantic"


def handle_pre_turn(pipeline, text, guard_mode, auto_recall=True, search_limit=5, min_relevance=0.0, session_id=None, cross_session_recall="all", cfg=None):
    """Handle pre-turn command.

    FIX 1: auto_recall and search_limit are accepted so they can be forwarded to
    pipeline.pre_turn() when/if the AgentPipeline API supports them.
    FIX 4: min_relevance is now accepted and forwarded to pipeline.pre_turn().
    Session isolation: session_id is forwarded so recall only returns memories from the calling session.
    v5.1: cross_session_recall controls cross-session memory filtering:
      "all"      — return all recalled memories (default, backward compat)
      "semantic" — cross-session memories filtered to semantic type only
      "none"     — no cross-session recall
    v2.3.0: cfg dict forwarded for recency recall config (recencyEnabled, recencyWindow, recencyLimit).
    """
    if cfg is None:
        cfg = {}
    if pipeline is None:
        return {
            "ok": True,
            "blocked": False,
            "context": None,
            "memory_count": 0,
            "warnings": ["antaris-pipeline not installed, skipping processing"]
        }

    try:
        try:
            result = pipeline.pre_turn(
                text,
                auto_recall=auto_recall,
                search_limit=search_limit,
                min_relevance=min_relevance,
                session_id=session_id,
            )
        except TypeError:
            # Older AgentPipeline — call without extra kwargs
            result = pipeline.pre_turn(text)

        # v5.2: cross-session recall filtering via native search() API
        # core_v4.MemorySystemV4.search() natively supports cross_session_recall ("all"/"semantic"/"none")
        # and session_id filtering — no need to mutate mem.memories in-place.
        filtered_context = result.context
        if cross_session_recall != "all" and session_id:
            try:
                mem = getattr(getattr(pipeline, 'pipeline', None), 'memory', None)
                if mem and hasattr(mem, 'search'):
                    filtered_results = mem.search(
                        text,
                        limit=search_limit if search_limit > 0 else 5,
                        session_id=session_id,
                        cross_session_recall=cross_session_recall,
                    )
                    if filtered_results:
                        context_lines = [f"[ANTARIS-SUITE MEMORY — {len(filtered_results)} relevant]"]
                        for i, r in enumerate(filtered_results, 1):
                            content = getattr(r, 'content', None) or getattr(r, 'entry', {})
                            if hasattr(content, 'content'):
                                content = content.content
                            context_lines.append(f"{i}. {str(content)[:400]}")
                        filtered_context = "\n".join(context_lines)
                    else:
                        filtered_context = None
                    # Only warn if session couldn't be resolved — noisy on every turn otherwise
                    if session_id == 'unknown':
                        result.warnings = list(result.warnings or [])
                        result.warnings.append(
                            f"[cross-session filter] mode={cross_session_recall}, session={session_id}"
                        )
            except Exception as filter_err:
                result.warnings = list(result.warnings or [])
                result.warnings.append(f"[cross-session filter] warning: {filter_err}")

        # v2.3.0: Recency recall — delegates to parsica-memory's recall_recent()
        # The recency feature lives in the memory library, not the bridge.
        _recency_enabled = cfg.get("recencyEnabled", True)
        if _recency_enabled:
            try:
                _recency_window = float(cfg.get("recencyWindow", 6.0))
                _recency_limit = int(cfg.get("recencyLimit", 5))
                _current_session = cfg.get("session_id", "") or cfg.get("channelId", "") or ""
                mem = getattr(getattr(pipeline, 'pipeline', None), 'memory', None)
                # Use library method: recall_recent() or search_recent()
                _recall_fn = getattr(mem, 'recall_recent', None) or getattr(mem, 'search_recent', None)
                if mem and _recall_fn:
                    _recent = _recall_fn(
                        hours=_recency_window,
                        limit=_recency_limit,
                        exclude_session=_current_session,
                    )
                    if _recent:
                        recency_lines = [f"\n[Recent cross-channel context — last {_recency_window}h]"]
                        for m in _recent:
                            content = getattr(m, 'content', str(m))[:300]
                            src = getattr(m, 'source_channel', '') or getattr(m, 'source', '') or ''
                            label = f"{src} | " if src else ""
                            recency_lines.append(f"{label}{content}")
                        recency_block = "\n".join(recency_lines)
                        if filtered_context:
                            filtered_context = filtered_context + "\n" + recency_block
                        else:
                            filtered_context = recency_block
                        result.warnings = list(result.warnings or [])
                        result.warnings.append(f"[recency] injected {len(_recent)} recent cross-channel memories")
            except Exception as _recency_err:
                import logging as _logging
                _logging.getLogger(__name__).debug(f"[recency] non-fatal error: {_recency_err}")

        return {
            "ok": result.success,
            "blocked": result.blocked,
            "block_reason": result.block_reason,
            "context": filtered_context,
            "memory_count": result.memory_count,
            "warnings": result.warnings,
            "guard_issues": result.guard_issues,
            "routing_recommendation": result.routing_recommendation,
            "turn_state": result.turn_state,
        }
    except Exception as e:
        return {"ok": False, "error": str(e)}


def handle_post_turn(pipeline, user_msg, ai_response, guard_mode, auto_ingest=True, turn_state=None, source=None, tags=None,
                     session_id=None, agent_id=None, channel_id=None):
    """Handle post-turn command.

    FIX 1: auto_ingest is accepted and forwarded so memory ingestion can be
    skipped entirely when the user has disabled it in plugin config.
    turn_state: opaque dict from pre_turn() response, forwarded for concurrency-safe
    access to guard/routing results.
    source: Override source label for ingested memories.
    tags: Additional tags for session/agent provenance.

    Layer 2 — Live fact ingestion: if the enricher tags a turn as a high-signal
    decision/milestone/product/rule, immediately ingest a secondary memory entry
    as source="live_fact" so other sessions can find it within seconds.
    """
    if pipeline is None:
        return {
            "ok": True,
            "stored_memories": 0,
            "warnings": ["antaris-pipeline not installed, skipping processing"],
            "blocked_output": False
        }

    # ── High-signal trigger phrases (no extra LLM call) ───────────────────────
    _HIGH_SIGNAL_TAGS = frozenset({
        "decision", "milestone", "product", "rule", "architecture",
        "launch", "policy", "constraint", "principle",
    })
    _HIGH_SIGNAL_PHRASES = (  # v5.0.1 fix C-2 — removed overly broad triggers
        "we decided", "going with", "locked in", "the rule is",
        "shipping", "we're building", "new product", "new repo",
        "final decision", "confirmed", "from now on",
        "the plan is", "roadmap", "decision made", "confirmed:",
        "rule:", "critical:", "milestone", "never do", "always do",
        "rule added", "going forward",
    )

    try:
        # v4.2: forward agent_id, session_id, channel_id so memory ingests are scoped.
        result = pipeline.post_turn(
            user_msg, ai_response,
            auto_ingest=auto_ingest, turn_state=turn_state,
            agent_id=agent_id, session_id=session_id, channel_id=channel_id,
        )
        # v4.6.5: read and reset enrichment counter
        enrichment_count = 0
        enricher_tags = []
        try:
            enrichment_count = pipeline.pipeline.memory.get_enrichment_count(reset=True)
            # Peek at the last ingested entry's tags for Layer 2 detection
            if hasattr(pipeline.pipeline.memory, '_last_enriched_tags'):
                enricher_tags = pipeline.pipeline.memory._last_enriched_tags or []
        except Exception:
            pass

        # v5.1.6: auto-classify memory_type + patch shard on disk post-write.
        #
        # Key findings from deep audit (2026-03-11):
        # - AgentPipeline has NO .memory attr — it's on pipeline.pipeline.memory
        # - AgentPipeline DOES have .storage_path — use that for shard lookup
        # - _memory_storage() never passes memory_type to ingest() → always None in shard
        # - channel_id is NOT in MemoryEntry.__slots__ → absorbed by **kwargs, silently dropped
        # - session_id IS written natively by post_turn() — no patch needed for it
        # - memory_type field is absent (None/null) in 99.8% of live entries
        #
        # Fix: use pipeline.storage_path to find the shard, patch memory_type + channel_id.
        try:
            if auto_ingest:
                import glob as _glob, json as _json, logging as _log
                from pathlib import Path as _Path
                from datetime import datetime as _dt

                # Classify based on the turn content
                combined_text = (user_msg or '') + ' ' + (ai_response or '')
                classified_type = _classify_memory_type(combined_text)

                # AgentPipeline.storage_path is the canonical root path
                _store_root = getattr(pipeline, 'storage_path', None) or memory_path
                store_path = _Path(str(_store_root))
                shards = [f for f in store_path.glob('shards/*.json') if '.bak' not in f.name]
                if shards:
                    latest_shard = max(shards, key=lambda f: f.stat().st_mtime)
                    age = _dt.now().timestamp() - latest_shard.stat().st_mtime
                    _log.getLogger('antaris').debug(f'[shard-patch] shard={latest_shard.name} age={age:.1f}s type={classified_type}')
                    if age < 30:  # only patch if shard was written in last 30s
                        with open(latest_shard) as _f:
                            shard_data = _json.load(_f)
                        memories_list = shard_data.get('memories', [])
                        if memories_list:
                            last = memories_list[-1]
                            changed = False
                            # Patch memory_type (absent/null in 99.8% of entries)
                            if last.get('memory_type') in (None, '', 'NOT SET', 'episodic'):
                                last['memory_type'] = classified_type
                                changed = True
                            # BUG 2 FIX: patch category — pipeline._memory_storage() hardcodes
                            # category="conversation" for all non-security entries.  Override with
                            # CategoryTagger result so entries get meaningful domain labels.
                            if last.get('category') in (None, '', 'conversation', 'general'):
                                try:
                                    from parsica_memory import CategoryTagger as _CT
                                    _primary = _CT().primary_category(combined_text)
                                    if _primary and _primary != last.get('category'):
                                        last['category'] = _primary
                                        changed = True
                                except Exception as _ct_err:
                                    _log.getLogger('antaris').debug(f'[shard-patch] CategoryTagger error (non-fatal): {_ct_err}')
                            # Patch channel_id (not in MemoryEntry schema, must add manually)
                            if not last.get('channel_id') and channel_id:
                                last['channel_id'] = channel_id
                                changed = True
                            # session_id is written natively by post_turn — skip
                            if changed:
                                shard_data['memories'] = memories_list
                                with open(latest_shard, 'w') as _f:
                                    _json.dump(shard_data, _f)
                            _log.getLogger('antaris').info(f'[shard-patch] patched={changed} type={last.get("memory_type")} category={last.get("category")} session={str(last.get("session_id","?"))[:30]} content={last.get("content","")[:40]}')
                    else:
                        _log.getLogger('antaris').debug(f'[shard-patch] SKIPPED age={age:.1f}s > 30s')
        except Exception as _patch_err:
            import logging as _log2
            _log2.getLogger('antaris').warning(f'[shard-patch] error: {_patch_err}')

        # ── Layer 2: Live fact ingestion ──────────────────────────────────────
        # Fires when enricher tags OR trigger phrases indicate a high-signal turn.
        # v5.0.1 fix C-2: only ingest as live_fact when auto_ingest is OFF
        # (pipeline.post_turn didn't already store it) OR when enricher tags
        # signal a high-value turn. phrase_hit alone when auto_ingest=True would
        # double-ingest every turn that matches common words.
        # Non-fatal — never blocks normal pipeline flow.
        try:
            if ai_response and len(ai_response) > 80:
                ai_lower = ai_response.lower()
                tag_hit = bool(_HIGH_SIGNAL_TAGS.intersection(set(t.lower() for t in enricher_tags)))
                phrase_hit = any(p in ai_lower for p in _HIGH_SIGNAL_PHRASES)

                # Only ingest as live_fact if auto_ingest is off (pipeline.post_turn
                # didn't already store it) OR if enricher explicitly tagged it high-signal.
                # phrase_hit alone does NOT trigger when auto_ingest=True (fixes double-ingest).
                if tag_hit or (phrase_hit and not auto_ingest):
                    import datetime
                    today = datetime.date.today().isoformat()
                    # Determine best memory_type from tags
                    live_type = "fact"
                    for preferred in ("decision", "milestone", "product", "rule", "architecture"):
                        if preferred in set(t.lower() for t in enricher_tags):
                            live_type = preferred
                            break

                    live_tags = ["live_fact", today]
                    if channel_id:
                        live_tags.append(f"channel:{channel_id}")
                    if enricher_tags:
                        live_tags.extend(enricher_tags[:5])

                    # Truncate to avoid massive entries
                    live_content = ai_response[:1200].strip()
                    _ingest_kwargs = dict(
                        source="live_fact",
                        memory_type=live_type,
                        tags=live_tags,
                        agent_id=agent_id,
                        session_id=session_id,
                    )
                    # v2.3.0: pass source_channel so recency recall can filter by channel
                    if channel_id:
                        _ingest_kwargs["source_channel"] = channel_id
                    pipeline.pipeline.memory.ingest(
                        live_content,
                        **_ingest_kwargs,
                    )
        except Exception:
            pass  # Layer 2 is strictly non-fatal

        return {
            "ok": result.success,
            "stored_memories": result.stored_memories,
            "warnings": result.warnings,
            "guard_issues": result.guard_issues,
            "blocked_output": result.blocked_output,
            "safe_replacement": result.safe_replacement,
            "enrichment_count": enrichment_count,
            "enricher_tags": enricher_tags,
        }
    except Exception as e:
        return {"ok": False, "error": str(e)}


def handle_session_start(pipeline, summary, agent_name=None, cross_session_context=None):
    """Handle session-start command."""
    if pipeline is None:
        return {"ok": False, "error": "pipeline not available"}

    try:
        result = pipeline.on_session_start(summary=summary, agent_name=agent_name)
        resp = {
            "ok": True,
            "restored_context": result.get("prependContext", "")
        }
        if cross_session_context is not None:
            resp["cross_session_context"] = cross_session_context
        return resp
    except Exception as e:
        return {"ok": False, "error": str(e)}


def main():
    # Check if running in persistent mode (no CLI args)
    if len(sys.argv) == 1:
        run_persistent_mode()
        return

    # Legacy mode for backward compatibility
    if len(sys.argv) < 2:
        print(json.dumps({"ok": False, "error": "Usage: pipeline_bridge.py <pre-turn|post-turn|config> <memory_path> [guard_mode]"}),
              file=sys.stderr)
        sys.exit(1)

    cmd = sys.argv[1]
    memory_path = sys.argv[2] if len(sys.argv) > 2 else "./parsica_memory_store"

    try:
        if cmd == "config" or cmd == "config-check":
            guard_mode = sys.argv[3] if len(sys.argv) > 3 else "monitor"
            response = handle_config_check(memory_path, guard_mode)
            print(json.dumps(response))

        elif cmd == "pre-turn":
            try:
                stdin_data = sys.stdin.read()
                if not stdin_data.strip():
                    print(json.dumps({"ok": False, "error": "pre-turn requires JSON payload on stdin"}), file=sys.stderr)
                    sys.exit(1)
                payload = json.loads(stdin_data)
                text = payload.get("text", "")
                guard_mode = payload.get("guard_mode", "monitor")
                auto_recall = payload.get("auto_recall", True)
                search_limit = payload.get("search_limit", 5)
                if not text:
                    print(json.dumps({"ok": False, "error": "pre-turn payload requires 'text' field"}), file=sys.stderr)
                    sys.exit(1)
            except json.JSONDecodeError as e:
                print(json.dumps({"ok": False, "error": f"Invalid JSON payload: {e}"}), file=sys.stderr)
                sys.exit(1)

            pipeline = pool.get(memory_path, payload)
            response = handle_pre_turn(pipeline, text, guard_mode, auto_recall=auto_recall, search_limit=search_limit)
            print(json.dumps(response))

        elif cmd == "post-turn":
            try:
                stdin_data = sys.stdin.read()
                if not stdin_data.strip():
                    print(json.dumps({"ok": False, "error": "post-turn requires JSON payload on stdin"}), file=sys.stderr)
                    sys.exit(1)
                payload = json.loads(stdin_data)
                user_msg = payload.get("user_msg", "")
                ai_response = payload.get("ai_response", "")
                guard_mode = payload.get("guard_mode", "monitor")
                auto_ingest = payload.get("auto_ingest", True)
                if not user_msg or not ai_response:
                    print(json.dumps({"ok": False, "error": "post-turn payload requires 'user_msg' and 'ai_response' fields"}), file=sys.stderr)
                    sys.exit(1)
            except json.JSONDecodeError as e:
                print(json.dumps({"ok": False, "error": f"Invalid JSON payload: {e}"}), file=sys.stderr)
                sys.exit(1)

            pipeline = pool.get(memory_path, payload)
            response = handle_post_turn(pipeline, user_msg, ai_response, guard_mode, auto_ingest=auto_ingest)
            print(json.dumps(response))

        else:
            print(json.dumps({"ok": False, "error": f"Unknown command: {cmd}"}), file=sys.stderr)
            sys.exit(1)

    except Exception as e:
        print(json.dumps({"ok": False, "error": str(e)}), file=sys.stderr)
        sys.exit(1)


if __name__ == "__main__":
    main()
