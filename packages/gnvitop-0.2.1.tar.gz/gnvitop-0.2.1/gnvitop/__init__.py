"""gnvitop - Global nvitop: web-based GPU monitoring dashboard for remote servers via SSH."""

__version__ = "0.2.1"
