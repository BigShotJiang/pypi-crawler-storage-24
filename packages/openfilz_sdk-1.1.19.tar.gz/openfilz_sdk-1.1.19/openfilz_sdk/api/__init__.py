# flake8: noqa

# import apis into api package
from openfilz_sdk.api.dashboard_api import DashboardApi
from openfilz_sdk.api.favorites_api import FavoritesApi
from openfilz_sdk.api.settings_api import SettingsApi
from openfilz_sdk.api.audit_controller_api import AuditControllerApi
from openfilz_sdk.api.document_controller_api import DocumentControllerApi
from openfilz_sdk.api.document_suggestion_controller_api import DocumentSuggestionControllerApi
from openfilz_sdk.api.file_controller_api import FileControllerApi
from openfilz_sdk.api.folder_controller_api import FolderControllerApi
from openfilz_sdk.api.tus_controller_api import TusControllerApi

