import json
from pathlib import Path

from sphinx_clarity_theme import ThemeOptions

project = "Testdocs"
author = "Documatt.com, s.r.o."
copyright = f"%Y, {author}"

extensions = []

html_theme = "sphinx_clarity_theme"
html_logo = "_static/favicon.svg"

html_theme_options: ThemeOptions = {
    "version_select_current": "1.0",
    "version_select_data": json.loads(
        (Path(__file__).parent.parent / "versions.json").read_text()
    ),
    "version_select_url": "/en/{version}/",
}
