from blabla import *
def hello():
    print("Hello World")