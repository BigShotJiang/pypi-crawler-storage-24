class b:
    def h(self):
        print("Hello")