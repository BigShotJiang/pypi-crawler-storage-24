# VibePod

[![Docs](https://img.shields.io/badge/docs-vibepod.dev-blue)](https://vibepod.dev/docs/)
[![PyPI](https://img.shields.io/pypi/v/vibepod)](https://pypi.org/project/vibepod/)
[![CI](https://github.com/VibePod/vibepod-cli/actions/workflows/ci.yml/badge.svg)](https://github.com/VibePod/vibepod-cli/actions/workflows/ci.yml)
[![Docs Build](https://github.com/VibePod/vibepod-cli/actions/workflows/docs.yml/badge.svg)](https://github.com/VibePod/vibepod-cli/actions/workflows/docs.yml)

VibePod is a unified CLI (`vp`) for running AI coding agents in Docker containers.

![VibePod CLI preview](docs/assets/preview.png)

## Installation

VibePod is available on [PyPI](https://pypi.org/project/vibepod/):

```bash
pip install vibepod
```

## Current Status

This repository contains an initial v1 implementation with:

- `vp run <agent>`
- `vp stop <agent|--all>`
- `vp list`
- `vp logs start|stop|status`
- `vp config init`
- `vp config show`
- `vp config path`
- `vp version`

## Image Namespace

By default, agent images use the `vibepod` namespace for Claude, Codex, and platform services, and `nezhar` for Gemini/OpenCode/Devstral/Auggie/Copilot.


Current defaults are aligned to existing container repos:

- `claude` -> `vibepod/claude:latest`
- `gemini` -> `nezhar/gemini-container:latest` ([repo](https://github.com/nezhar/gemini-container))
- `opencode` -> `nezhar/opencode-cli:latest` ([repo](https://github.com/nezhar/opencode-container))
- `devstral` -> `nezhar/devstral-cli:latest` ([repo](https://github.com/nezhar/devstral-container))
- `auggie` -> `nezhar/auggie-cli:latest` ([repo](https://github.com/nezhar/auggie-container))
- `copilot` -> `nezhar/copilot-cli:latest` ([repo](https://github.com/nezhar/copilot-container))
- `codex` -> `vibepod/codex:latest`
- `datasette` -> `vibepod/datasette:latest`
- `proxy` -> `vibepod/proxy:latest` ([repo](https://github.com/VibePod/vibepod-proxy))

You can override any single image directly:

```bash
VP_IMAGE_CLAUDE=vibepod/claude:latest vp run claude
VP_IMAGE_GEMINI=nezhar/gemini-container:latest vp run gemini
VP_IMAGE_OPENCODE=nezhar/opencode-cli:latest vp run opencode
VP_IMAGE_DEVSTRAL=nezhar/devstral-cli:latest vp run devstral
VP_IMAGE_AUGGIE=nezhar/auggie-cli:latest vp run auggie
VP_IMAGE_COPILOT=nezhar/copilot-cli:latest vp run copilot
VP_IMAGE_CODEX=vibepod/codex:latest vp run codex
VP_DATASETTE_IMAGE=vibepod/datasette:latest vp logs start
```
