"""
채팅 서비스 구현

IChatService의 Embedded 구현.
"""

import logging
import os
import re
from datetime import datetime
from typing import Any, AsyncGenerator, Dict, List, Optional, Tuple

from hdsp_agent_core.interfaces import IChatService
from hdsp_agent_core.llm import LLMService
from hdsp_agent_core.llm.service import DEFAULT_MAX_OUTPUT_TOKENS
from hdsp_agent_core.managers import get_config_manager, get_session_manager
from hdsp_agent_core.managers.session_manager import ChatMessage
from hdsp_agent_core.models.chat import ChatRequest, ChatResponse

logger = logging.getLogger(__name__)

# ═══════════════════════════════════════════════════════════════════════════
# @file Context Injection (Ported from agent-server ContextProcessor)
# ═══════════════════════════════════════════════════════════════════════════
FILE_CONTEXT_TEMPLATE = """The following is the content of the file `{filepath}`:

```
{content}
```"""

# Regex: @file:path, @file:'quoted path', @file:"quoted path"
_FILE_CMD_PATTERN = re.compile(
    r"(?<![^\s.])@file:(?:'[^']+'|\"[^\"]+\"|[^\s\\]+(?:\\ [^\s\\]*)*)"
)


def _process_file_commands(
    message: str, base_dir: str = "."
) -> Tuple[str, str, List[str]]:
    """Process @file:path commands in a user message.

    Finds all @file:path references, reads file contents, and returns
    the context to inject into the LLM prompt.

    Args:
        message: User message potentially containing @file:path commands
        base_dir: Base directory for resolving relative paths

    Returns:
        Tuple of (file_context, cleaned_message, errors)
    """
    matches = list(_FILE_CMD_PATTERN.finditer(message))
    if not matches:
        return "", message, []

    context_parts: List[str] = []
    errors: List[str] = []
    cleaned = message

    for match in matches:
        cmd = match.group()
        arg = cmd.partition(":")[2].strip("'\"").replace("\\ ", " ")

        if not arg:
            errors.append("No file path specified")
            continue

        filepath = arg if os.path.isabs(arg) else os.path.join(base_dir, arg)
        filepath = os.path.normpath(filepath)

        if not os.path.exists(filepath):
            errors.append(f"File not found: {filepath}")
            continue
        if os.path.isdir(filepath):
            errors.append(f"Cannot read directory: {filepath}")
            continue

        try:
            with open(filepath, "r", encoding="utf-8") as f:
                content = f.read()

            # Special handling for Jupyter notebooks
            if filepath.endswith(".ipynb"):
                try:
                    import nbformat

                    nb = nbformat.reads(content, as_version=4)
                    cells = [
                        f"# Cell {i + 1} ({c.cell_type}):\n{c.source}"
                        for i, c in enumerate(nb.cells)
                    ]
                    content = "\n\n".join(cells)
                except Exception:
                    pass  # Use raw content if parsing fails

            # Truncate at 100K chars
            max_chars = 100_000
            if len(content) > max_chars:
                content = (
                    content[:max_chars]
                    + f"\n\n... [truncated, {len(content) - max_chars} more characters]"
                )

            context_parts.append(
                FILE_CONTEXT_TEMPLATE.format(filepath=filepath, content=content)
            )
            cleaned = cleaned.replace(cmd, f"'{arg}'", 1)
            logger.info(f"Processed @file command: {cmd}")

        except UnicodeDecodeError:
            errors.append(f"Cannot read file (encoding error): {filepath}")
        except PermissionError:
            errors.append(f"Permission denied: {filepath}")
        except Exception as e:
            errors.append(f"Error reading {filepath}: {e}")

    combined_context = "\n\n".join(context_parts) if context_parts else ""
    return combined_context, cleaned, errors


# ═══════════════════════════════════════════════════════════════════════════
# Summarization Prompt (Claude Code Benchmark)
# ═══════════════════════════════════════════════════════════════════════════
SUMMARIZATION_PROMPT = """다음 대화 내용을 요약하여 향후 컨텍스트 윈도우에서 작업을 효율적으로 재개할 수 있도록 해주세요.
이 요약은 대화 히스토리를 대체하므로, 구조화되고 간결하며 실행 가능해야 합니다.

요약에 반드시 포함할 내용:

## 완료된 작업
- 완료된 태스크와 주요 결과물
- 생성/수정된 파일 목록

## 현재 상태
- 진행 중인 작업
- 마지막으로 논의된 주제

## 다음 단계
- 명확한 후속 액션 항목
- 보류 중인 결정 사항

## 핵심 맥락
- 사용자 선호사항 및 제약조건
- 중요한 기술적 결정사항
- 작업 재개에 필수적인 정보

작성 지침:
- 간결하되, 작업이 끊김 없이 계속될 수 있을 정도의 세부사항은 보존
- 불필요한 인사말, 확인 메시지, 중복 내용은 제외
- 코드 스니펫은 핵심적인 경우에만 포함
- 한국어로 작성

대화 내용:
{conversation}

요약:"""

# ═══════════════════════════════════════════════════════════════════════════
# Auto-Compact Configuration (Aligned with Agent mode SummarizationMiddleware)
# ═══════════════════════════════════════════════════════════════════════════
AUTO_COMPACT_TOKEN_THRESHOLD = 30000  # Trigger when tokens exceed this threshold
AUTO_COMPACT_KEEP_MESSAGES = 15  # Keep last N messages after compaction

# Token estimation
CHARS_PER_TOKEN = 3.5


def _estimate_tokens(text: str) -> int:
    """Estimate token count from text length."""
    return int(len(text) / CHARS_PER_TOKEN)


def _estimate_session_tokens(messages) -> int:
    """Estimate total tokens in session messages."""
    total_chars = sum(len(m.content) for m in messages)
    return int(total_chars / CHARS_PER_TOKEN)


class EmbeddedChatService(IChatService):
    """
    채팅 서비스 구현.

    인프로세스에서 직접 채팅 로직을 실행합니다.
    """

    def __init__(self):
        """Embedded 채팅 서비스 초기화"""
        self._config_manager = get_config_manager()
        self._session_manager = get_session_manager()
        logger.info("EmbeddedChatService 초기화됨")

    def _get_config(self) -> Dict[str, Any]:
        """현재 LLM 설정 반환"""
        return self._config_manager.get_config()

    def _build_llm_config(self, llm_config) -> Dict[str, Any]:
        """클라이언트 제공 설정에서 LLM 설정 딕셔너리 구성.

        프론트엔드가 provider 정보 없이 사용자 설정만 보내는 경우
        (예: {workspaceRoot, autoApprove}), 서버 AdminConfig로 폴백합니다.
        """
        if llm_config is None:
            return self._get_config()

        # 클라이언트가 실제 provider sub-config를 보냈는지 확인
        has_provider_config = llm_config.vllm is not None

        if not has_provider_config:
            # 프론트엔드가 사용자 설정만 보냄 → 서버 AdminConfig 사용
            return self._get_config()

        config = {"provider": llm_config.provider}

        if llm_config.vllm:
            config["vllm"] = {
                "endpoint": llm_config.vllm.endpoint,
                "apiKey": llm_config.vllm.apiKey,
                "model": llm_config.vllm.model,
            }

        return config

    def _get_or_create_conversation(self, conversation_id: Optional[str]) -> str:
        """기존 대화 가져오기 또는 새로 생성"""
        session = self._session_manager.get_or_create_session(conversation_id)
        return session.id

    def _build_context(
        self, conversation_id: str, max_messages: int = 5
    ) -> Optional[str]:
        """이력에서 대화 컨텍스트 구성"""
        return self._session_manager.build_context(conversation_id, max_messages)

    def _store_messages(
        self, conversation_id: str, user_message: str, assistant_response: str
    ) -> None:
        """대화 이력에 사용자 및 어시스턴트 메시지 저장"""
        self._session_manager.store_messages(
            conversation_id, user_message, assistant_response
        )

    async def _auto_compact_if_needed(
        self, conversation_id: str, llm_config: Dict[str, Any]
    ) -> Optional[str]:
        """토큰 임계값 초과 시 자동 압축.

        Agent 모드 SummarizationMiddleware와 동일 전략:
        - 트리거: 토큰 수 > AUTO_COMPACT_TOKEN_THRESHOLD
        - 유지: 최근 AUTO_COMPACT_KEEP_MESSAGES개 메시지
        - 결과: [요약] + [최근 메시지]

        Returns:
            압축된 경우 요약 문자열, 아니면 None
        """
        session = self._session_manager.get_session(conversation_id)
        if not session or not session.messages:
            return None

        estimated_tokens = _estimate_session_tokens(session.messages)

        if estimated_tokens <= AUTO_COMPACT_TOKEN_THRESHOLD:
            return None

        if len(session.messages) <= AUTO_COMPACT_KEEP_MESSAGES:
            return None

        logger.info(
            f"[Chat] Auto-compact triggered for {conversation_id}: "
            f"~{estimated_tokens} tokens > {AUTO_COMPACT_TOKEN_THRESHOLD} threshold, "
            f"{len(session.messages)} messages"
        )

        try:
            messages_to_summarize = session.messages[:-AUTO_COMPACT_KEEP_MESSAGES]
            recent_messages = session.messages[-AUTO_COMPACT_KEEP_MESSAGES:]

            conversation_text = "\n".join(
                [
                    f"{'사용자' if m.role == 'user' else '어시스턴트'}: {m.content}"
                    for m in messages_to_summarize
                ]
            )

            llm_service = LLMService(llm_config)
            prompt = SUMMARIZATION_PROMPT.format(conversation=conversation_text)
            summary = await llm_service.generate_response(prompt)

            summary_message = ChatMessage(
                role="assistant",
                content=f"[이전 대화 요약]\n\n{summary}",
                timestamp=datetime.now().timestamp(),
            )

            original_count = len(session.messages)
            session.messages = [summary_message] + list(recent_messages)
            session.updated_at = datetime.now().timestamp()
            self._session_manager._save_sessions()

            compressed_count = len(session.messages)
            logger.info(
                f"[Chat] Auto-compacted {conversation_id}: "
                f"{original_count} -> {compressed_count} messages"
            )

            return summary

        except Exception as e:
            logger.error(f"[Chat] Auto-compact failed: {e}", exc_info=True)
            return None

    async def send_message(self, request: ChatRequest) -> ChatResponse:
        """채팅 메시지를 보내고 응답 받기"""
        logger.info(f"[Embedded] 채팅 메시지: {request.message[:100]}...")

        config = self._build_llm_config(request.llmConfig)

        if not config or not config.get("provider"):
            raise ValueError(
                "LLM이 설정되지 않음. API 키가 포함된 llmConfig를 제공하세요."
            )

        # 대화 가져오기 또는 생성
        conversation_id = self._get_or_create_conversation(request.conversationId)

        # @file 컨텍스트 처리
        base_dir = os.getcwd()
        file_context, cleaned_message, context_errors = _process_file_commands(
            request.message, base_dir=base_dir
        )
        if context_errors:
            logger.warning(f"Context processing errors: {context_errors}")

        # 이력에서 컨텍스트 구성
        history_context = self._build_context(conversation_id)

        # 파일 컨텍스트 + 이력 컨텍스트 결합
        all_context_parts = []
        if file_context:
            all_context_parts.append(file_context)
        if history_context:
            all_context_parts.append(history_context)
        combined_context = "\n\n".join(all_context_parts) if all_context_parts else None

        # LLM 호출
        llm_service = LLMService(config)
        response = await llm_service.generate_response(
            cleaned_message, context=combined_context
        )

        # 메시지 저장 (cleaned_message 사용)
        self._store_messages(conversation_id, cleaned_message, response)

        # 자동 압축 (토큰 임계값 초과 시)
        await self._auto_compact_if_needed(conversation_id, config)

        # 모델 정보 가져오기
        provider = config.get("provider", "unknown")
        model = config.get(provider, {}).get("model", "unknown")

        return ChatResponse(
            response=response,
            conversationId=conversation_id,
            model=f"{provider}/{model}",
        )

    async def compact(self, body: Dict[str, Any]) -> Dict[str, Any]:
        """Compact conversation history by summarizing older messages.

        Strategy (Claude Code benchmark):
        - Keep the last 3 messages intact
        - Summarize all older messages using LLM
        - Replace history with [summary] + [last 3 messages]
        """
        conversation_id = body.get("conversationId")
        if not conversation_id:
            return {
                "success": False,
                "message": "conversationId가 필요합니다.",
                "originalMessages": 0,
                "compressedMessages": 0,
            }

        session = self._session_manager.get_session(conversation_id)
        if not session:
            return {
                "success": False,
                "message": "세션을 찾을 수 없습니다.",
                "originalMessages": 0,
                "compressedMessages": 0,
            }

        original_count = len(session.messages)

        # Already minimal - no compaction needed
        if original_count <= 3:
            return {
                "success": True,
                "message": "이미 최소 상태입니다. 압축이 필요하지 않습니다.",
                "originalMessages": original_count,
                "compressedMessages": original_count,
            }

        try:
            # Split messages: older (to summarize) vs recent (to keep)
            messages_to_summarize = session.messages[:-3]
            recent_messages = session.messages[-3:]

            # Build conversation text for summarization
            conversation_text = "\n".join(
                [
                    f"{'사용자' if m.role == 'user' else '어시스턴트'}: {m.content}"
                    for m in messages_to_summarize
                ]
            )

            # Get LLM config from body or fallback to server config
            llm_config = body.get("llmConfig") or self._get_config()
            if isinstance(llm_config, dict) and "provider" not in llm_config:
                llm_config = self._get_config()

            # Generate summary using LLMService
            llm_service = LLMService(llm_config)
            prompt = SUMMARIZATION_PROMPT.format(conversation=conversation_text)
            summary = await llm_service.generate_response(prompt)

            # Create summary message
            summary_message = ChatMessage(
                role="assistant",
                content=f"[이전 대화 요약]\n\n{summary}",
                timestamp=datetime.now().timestamp(),
            )

            # Replace session messages: [summary] + [last 3]
            session.messages = [summary_message] + list(recent_messages)
            session.updated_at = datetime.now().timestamp()

            # Persist changes
            self._session_manager._save_sessions()

            compressed_count = len(session.messages)
            logger.info(
                f"Compacted conversation {conversation_id}: "
                f"{original_count} -> {compressed_count} messages"
            )

            return {
                "success": True,
                "message": f"대화가 압축되었습니다. ({original_count}개 → {compressed_count}개 메시지)",
                "originalMessages": original_count,
                "compressedMessages": compressed_count,
                "summary": summary,
            }

        except Exception as e:
            logger.error(f"Compact failed: {e}", exc_info=True)
            return {
                "success": False,
                "message": f"압축 중 오류가 발생했습니다: {str(e)}",
                "originalMessages": original_count,
                "compressedMessages": original_count,
            }

    async def send_message_stream(
        self, request: ChatRequest
    ) -> AsyncGenerator[Dict[str, Any], None]:
        """채팅 메시지를 보내고 스트리밍 응답 받기"""
        logger.info(f"[Embedded] 채팅 스트림: {request.message[:100]}...")

        config = self._build_llm_config(request.llmConfig)

        if not config or not config.get("provider"):
            yield {
                "error": "LLM이 설정되지 않음. API 키가 포함된 llmConfig를 제공하세요."
            }
            return

        # 대화 가져오기 또는 생성
        conversation_id = self._get_or_create_conversation(request.conversationId)

        # @file 컨텍스트 처리
        base_dir = os.getcwd()
        file_context, cleaned_message, context_errors = _process_file_commands(
            request.message, base_dir=base_dir
        )

        # 컨텍스트 에러를 경고로 전송
        if context_errors:
            yield {
                "warning": "Context errors: " + "; ".join(context_errors),
                "done": False,
            }

        # 이력 컨텍스트 구성
        history_context = self._build_context(conversation_id)

        # 파일 컨텍스트 + 이력 컨텍스트 결합
        all_context_parts = []
        if file_context:
            all_context_parts.append(file_context)
        if history_context:
            all_context_parts.append(history_context)
        combined_context = "\n\n".join(all_context_parts) if all_context_parts else None

        # LLM 응답 스트리밍
        llm_service = LLMService(config)
        full_response = ""

        max_tokens = request.maxTokens or self._config_manager.get(
            "maxOutputTokens", DEFAULT_MAX_OUTPUT_TOKENS
        )

        try:
            async for chunk in llm_service.generate_response_stream(
                cleaned_message, context=combined_context, max_tokens=max_tokens
            ):
                full_response += chunk
                yield {"content": chunk, "done": False}

            # 스트리밍 완료 후 메시지 저장 (cleaned_message 사용)
            self._store_messages(conversation_id, cleaned_message, full_response)

            # 자동 압축 체크 (토큰 임계값 초과 시)
            session = self._session_manager.get_session(conversation_id)
            if session and session.messages:
                estimated_tokens = _estimate_session_tokens(session.messages)
                if (
                    estimated_tokens > AUTO_COMPACT_TOKEN_THRESHOLD
                    and len(session.messages) > AUTO_COMPACT_KEEP_MESSAGES
                ):
                    yield {
                        "status": "대화 컨텍스트 요약 중...",
                        "icon": "thinking",
                        "done": False,
                    }
                    summary = await self._auto_compact_if_needed(
                        conversation_id, config
                    )
                    if summary:
                        yield {
                            "status": "대화가 자동으로 압축되었습니다.",
                            "icon": "check",
                            "done": False,
                        }

            # 마지막 청크 전송
            yield {"content": "", "done": True, "conversationId": conversation_id}

        except Exception as e:
            logger.error(f"스트림 채팅 실패: {e}", exc_info=True)
            yield {"error": str(e)}
