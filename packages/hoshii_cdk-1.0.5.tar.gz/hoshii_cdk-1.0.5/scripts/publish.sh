#!/bin/bash
set -e

# Display usage information
usage() {
  echo "Usage: $0 [OPTIONS]"
  echo ""
  echo "Publish hoshii-cdk package to PyPI."
  echo ""
  echo "Options:"
  echo "  --help    Display this help message"
  echo "  --test    Publish to TestPyPI instead of PyPI"
  echo "  --dry-run Build but don't upload"
  echo ""
  echo "Examples:"
  echo "  $0                # Publish to PyPI"
  echo "  $0 --test        # Publish to TestPyPI"
  echo "  $0 --dry-run     # Build only, no upload"
  exit 0
}

SCRIPT_DIR=$( cd -- "$( dirname -- "${BASH_SOURCE[0]}" )" &> /dev/null && pwd )
BASE_DIR="${SCRIPT_DIR}/.."
CURR_DIR=$(pwd)

trap "cd ${CURR_DIR}" EXIT

cd ${BASE_DIR}

# Parse flags
USE_TEST_REGISTRY=0
DRY_RUN=0

for arg in "$@"; do
  case $arg in
    --help|-h)
      usage
      ;;
    --test)
      USE_TEST_REGISTRY=1
      ;;
    --dry-run)
      DRY_RUN=1
      ;;
    *)
      echo "Error: Unknown option '$arg'"
      echo ""
      usage
      ;;
  esac
done

echo "Publishing hoshii-cdk package..."

# Clean previous builds
echo "Cleaning previous builds..."
rm -rf dist/ build/ src/*.egg-info/

# Check for required tools
if ! command -v python3 &> /dev/null; then
  echo "Error: python3 is required but not installed."
  exit 1
fi

# Use uv if available (fast), otherwise use pip
if command -v uv &> /dev/null; then
  echo "Installing build dependencies with uv..."
  uv pip install --system --quiet build twine
else
  echo "Installing build dependencies with pip..."
  python3 -m pip install --quiet --upgrade build twine
fi

# Build the package
echo "Building package..."
python3 -m build

if [ $DRY_RUN -eq 1 ]; then
  echo ""
  echo "✓ Dry run complete. Built packages:"
  ls -lh dist/
  echo ""
  echo "To upload manually, run:"
  if [ $USE_TEST_REGISTRY -eq 1 ]; then
    echo "  python3 -m twine upload --repository testpypi dist/*"
  else
    echo "  python3 -m twine upload dist/*"
  fi
  exit 0
fi

# Upload to registry
echo "Uploading to registry..."
if [ $USE_TEST_REGISTRY -eq 1 ]; then
  echo "Uploading to TestPyPI..."
  python3 -m twine upload --repository testpypi dist/*
  echo ""
  echo "✓ Package published to TestPyPI!"
  echo ""
  echo "Install with:"
  echo "  pip install --index-url https://test.pypi.org/simple/ hoshii-cdk"
else
  echo "Uploading to PyPI..."
  python3 -m twine upload dist/*
  echo ""
  echo "✓ Package published to PyPI!"
  echo ""
  echo "Install with:"
  echo "  pip install hoshii-cdk"
fi
