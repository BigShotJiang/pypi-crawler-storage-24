"""
Hoshii CDK - A framework for building Hoshii-compliant components.

This package provides a declarative way to define component actions with
typed request/response schemas, enabling workflow platforms to discover
and invoke actions.

Example:
    from hoshii_cdk import Component, action, Registry
    from your_proto import ListItemsRequest, ListItemsResponse
    
    class ItemsComponent(Component):
        name = "Items"
        description = "Item/product operations"
        
        # Component properties
        api_key: str = ""
        timeout: int = 30
        
        @action(
            name="List Items",
            description="List items with filtering",
            request_schema=ListItemsRequest,
            response_schema=ListItemsResponse,
        )
        def list_items(self, request: dict) -> dict:
            ...
    
    registry = Registry()
    registry.register(ItemsComponent)
    
    # Get manifest for workflow platform
    manifest = registry.get_manifest()
    
    # Invoke an action
    result = registry.invoke("Items", "list_items", {"active_only": True})
"""

__version__ = "1.0.0"

from .action import action, get_action_metadata, is_action
from .component import Component
from .registry import Registry
from .schema import python_type_to_json_schema
from .types import ActionMetadata, ComponentMetadata, PropertyMetadata
from .manifest import (
    generate_manifest,
    load_manifest,
    ComponentRunner,
    ManifestError,
)
from .exceptions import (
    HoshiiCDKError,
    ComponentError,
    ActionNotFoundError,
    ComponentNotFoundError,
    ValidationError,
    SchemaError,
)

__all__ = [
    # Version
    "__version__",
    # Core classes
    "Component",
    "Registry",
    # Decorator
    "action",
    "get_action_metadata",
    "is_action",
    # Schema utilities
    "python_type_to_json_schema",
    # Manifest utilities
    "generate_manifest",
    "load_manifest",
    "ComponentRunner",
    # Types
    "ActionMetadata",
    "ComponentMetadata",
    "PropertyMetadata",
    # Exceptions
    "HoshiiCDKError",
    "ComponentError",
    "ActionNotFoundError",
    "ComponentNotFoundError",
    "ValidationError",
    "SchemaError",
    "ManifestError",
]
