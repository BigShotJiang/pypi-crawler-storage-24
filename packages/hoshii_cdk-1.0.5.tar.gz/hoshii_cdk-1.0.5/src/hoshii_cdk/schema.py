"""
Schema utilities for generating standard JSON Schema from Python types.

Uses:
- pydantic for dataclasses/Pydantic models → JSON Schema
- google.protobuf descriptor API for protobuf messages → JSON Schema
"""

from typing import Any, Type
from dataclasses import is_dataclass

from pydantic import BaseModel, TypeAdapter
from google.protobuf.message import Message
from google.protobuf.descriptor import FieldDescriptor

from .exceptions import SchemaError

# Protobuf type to JSON Schema type mapping
_PROTO_TYPE_MAP = {
    FieldDescriptor.TYPE_DOUBLE: "number",
    FieldDescriptor.TYPE_FLOAT: "number",
    FieldDescriptor.TYPE_INT64: "integer",
    FieldDescriptor.TYPE_UINT64: "integer",
    FieldDescriptor.TYPE_INT32: "integer",
    FieldDescriptor.TYPE_FIXED64: "integer",
    FieldDescriptor.TYPE_FIXED32: "integer",
    FieldDescriptor.TYPE_BOOL: "boolean",
    FieldDescriptor.TYPE_STRING: "string",
    FieldDescriptor.TYPE_BYTES: "string",
    FieldDescriptor.TYPE_UINT32: "integer",
    FieldDescriptor.TYPE_SFIXED32: "integer",
    FieldDescriptor.TYPE_SFIXED64: "integer",
    FieldDescriptor.TYPE_SINT32: "integer",
    FieldDescriptor.TYPE_SINT64: "integer",
    FieldDescriptor.TYPE_ENUM: "integer",
}


def python_type_to_json_schema(python_type: Type) -> dict[str, Any]:
    """
    Convert a Python type to a standard JSON Schema.
    
    Supports:
    - Pydantic models (uses model_json_schema directly)
    - Dataclasses (converts via TypeAdapter)
    - Protobuf messages (via descriptor API)
    - Basic types (int, str, bool, float, list, dict)
    
    Args:
        python_type: Python type to convert.
    
    Returns:
        JSON Schema as a dictionary.
    
    Raises:
        SchemaError: If the type cannot be converted.
    """
    try:
        # Pydantic model - use built-in schema generation
        if isinstance(python_type, type) and issubclass(python_type, BaseModel):
            return python_type.model_json_schema()
        
        # Protobuf message - convert via descriptor
        if isinstance(python_type, type) and issubclass(python_type, Message):
            return _protobuf_to_schema(python_type)
        
        # Dataclass or basic type - use TypeAdapter
        if is_dataclass(python_type) or python_type in (int, str, bool, float, list, dict):
            return TypeAdapter(python_type).json_schema()
        
        # Class with annotations - try TypeAdapter
        if hasattr(python_type, '__annotations__') and python_type.__annotations__:
            return TypeAdapter(python_type).json_schema()
        
        raise SchemaError(f"Unsupported type: {python_type}")
        
    except SchemaError:
        raise
    except Exception as e:
        raise SchemaError(f"Failed to convert {python_type} to JSON Schema: {e}") from e


def _protobuf_to_schema(proto_type: Type[Message]) -> dict[str, Any]:
    """Convert a protobuf message to JSON Schema using the descriptor API."""
    return _descriptor_to_schema(proto_type.DESCRIPTOR, visited=set())


def _make_nullable(schema: dict[str, Any]) -> dict[str, Any]:
    """Wrap a schema to allow null values (for optional fields with presence tracking).
    
    Uses oneOf instead of array types for broader library compatibility.
    Some JSON Schema libraries (e.g., invopop/jsonschema in Go) don't support
    the array form of type like ["string", "null"].
    """
    title = schema.get("title")
    
    # If schema uses oneOf (e.g., enums), add null option to it
    if "oneOf" in schema:
        result = {
            "oneOf": schema["oneOf"] + [{"type": "null"}],
        }
        if title:
            result["title"] = title
        return result
    
    # For all other schemas, wrap with oneOf
    result = {
        "oneOf": [schema, {"type": "null"}],
    }
    if title:
        result["title"] = title
    return result


def _descriptor_to_schema(descriptor, visited: set = None) -> dict[str, Any]:
    """Convert a protobuf Descriptor to JSON Schema."""
    if visited is None:
        visited = set()
    
    # Handle well-known types that have special JSON representations
    well_known_types = {
        "google.protobuf.Timestamp": {"type": "string", "format": "date-time"},
        "google.protobuf.Duration": {"type": "string"},
        "google.protobuf.Any": {"type": "object"},
        "google.protobuf.Struct": {"type": "object"},
        "google.protobuf.Value": {},
        "google.protobuf.ListValue": {"type": "array"},
        "google.protobuf.FieldMask": {"type": "string"},
        "google.protobuf.Empty": {"type": "object", "properties": {}},
        "google.protobuf.BoolValue": {"type": "boolean"},
        "google.protobuf.BytesValue": {"type": "string"},
        "google.protobuf.DoubleValue": {"type": "number"},
        "google.protobuf.FloatValue": {"type": "number"},
        "google.protobuf.Int32Value": {"type": "integer"},
        "google.protobuf.Int64Value": {"type": "integer"},
        "google.protobuf.StringValue": {"type": "string"},
        "google.protobuf.UInt32Value": {"type": "integer"},
        "google.protobuf.UInt64Value": {"type": "integer"},
    }
    
    if descriptor.full_name in well_known_types:
        schema = well_known_types[descriptor.full_name].copy()
        schema["title"] = descriptor.name
        return schema
    
    # Prevent infinite recursion for circular references
    if descriptor.full_name in visited:
        return {"type": "object", "title": descriptor.name}
    
    visited = visited | {descriptor.full_name}
    
    properties = {}
    
    for field in descriptor.fields:
        field_name = field.json_name or field.name
        
        # Handle map fields (protobuf maps have a special message type with key/value)
        if field.message_type and field.message_type.GetOptions().map_entry:
            # This is a map field - get the value type
            value_field = field.message_type.fields_by_name.get('value')
            if value_field:
                if value_field.type == FieldDescriptor.TYPE_MESSAGE:
                    value_schema = _descriptor_to_schema(value_field.message_type, visited)
                else:
                    value_schema = {"type": _PROTO_TYPE_MAP.get(value_field.type, "string")}
            else:
                value_schema = {"type": "string"}
            
            properties[field_name] = {
                "type": "object",
                "additionalProperties": value_schema,
                "title": _to_title(field_name),
            }
            continue
        
        # Handle enum fields
        if field.type == FieldDescriptor.TYPE_ENUM:
            enum_descriptor = field.enum_type
            field_schema = {
                "oneOf": [
                    {"const": v.number, "title": v.name}
                    for v in enum_descriptor.values
                ]
            }
        # Handle nested messages
        elif field.type == FieldDescriptor.TYPE_MESSAGE:
            field_schema = _descriptor_to_schema(field.message_type, visited)
        else:
            json_type = _PROTO_TYPE_MAP.get(field.type, "string")
            field_schema = {"type": json_type}
        
        # Handle repeated fields (arrays)
        if field.is_repeated:
            properties[field_name] = {
                "type": "array",
                "items": field_schema,
                "title": _to_title(field_name),
            }
        else:
            field_schema["title"] = _to_title(field_name)
            # Only fields with explicit `optional` keyword should be nullable
            # Proto3 optional creates a synthetic oneof with name starting with '_'
            is_proto3_optional = (
                field.containing_oneof is not None 
                and field.containing_oneof.name.startswith('_')
            )
            if is_proto3_optional:
                field_schema = _make_nullable(field_schema)
            properties[field_name] = field_schema
    
    # Proto3: All fields are optional with default values.
    # The JSON schema reflects what the RPC gateway accepts - any subset of fields.
    # Never include "required" for protobuf-generated schemas.
    return {
        "type": "object",
        "title": descriptor.name,
        "properties": properties,
    }


import re


def _to_title(name: str) -> str:
    """Convert camelCase or snake_case to Title Case."""
    # Insert space before uppercase letters (for camelCase)
    spaced = re.sub(r'([a-z])([A-Z])', r'\1 \2', name)
    # Replace underscores with spaces (for snake_case)
    spaced = spaced.replace('_', ' ')
    return spaced.title()
