"""
Manifest generation and loading utilities.
"""

import json
import importlib
from pathlib import Path
from typing import Any

from .registry import Registry
from .exceptions import HoshiiCDKError


class ManifestError(HoshiiCDKError):
    """Raised when there's an error with manifest operations."""
    pass


def _get_python_version_requirement(output_path: Path) -> str:
    """
    Get Python version requirement from pyproject.toml or fallback to current version.
    
    Looks for pyproject.toml in the same directory as the manifest output path
    or its parent directories.
    """
    import sys
    
    # Try to find pyproject.toml
    search_path = output_path.parent.resolve()
    for _ in range(5):  # Search up to 5 levels
        pyproject_path = search_path / "pyproject.toml"
        if pyproject_path.exists():
            try:
                # Try to parse pyproject.toml
                import tomllib
            except ImportError:
                try:
                    import tomli as tomllib
                except ImportError:
                    break
            
            try:
                with open(pyproject_path, "rb") as f:
                    pyproject = tomllib.load(f)
                
                requires_python = pyproject.get("project", {}).get("requires-python")
                if requires_python:
                    return requires_python
            except Exception:
                pass
            break
        
        if search_path.parent == search_path:
            break
        search_path = search_path.parent
    
    # Fallback to current Python version
    return f">={sys.version_info.major}.{sys.version_info.minor}"


def generate_manifest(
    registry: Registry,
    output_path: str | Path,
    pretty: bool = True,
    python_version: str | None = None,
) -> None:
    """
    Generate a JSON manifest file from a registry.
    
    This manifest contains all component and action metadata with schemas,
    which can be consumed by workflow platforms for UI generation and
    action discovery.
    
    Args:
        registry: Registry containing components to include in manifest.
        output_path: Path where the manifest JSON file should be written.
        pretty: If True, format JSON with indentation for readability.
        python_version: Python version requirement (e.g., ">=3.10"). 
                       If None, reads from pyproject.toml or uses current version.
    
    Example:
        registry = Registry()
        registry.register(ItemsComponent)
        registry.register(BusinessPartnersComponent)
        
        generate_manifest(registry, "manifest.json")
    """
    output_path = Path(output_path)
    
    # Get Python version requirement
    if python_version is None:
        python_version = _get_python_version_requirement(output_path)
    
    # Get manifest data from registry
    manifest_data = {
        "version": "1.0",
        "runtime": {
            "language": "python",
            "version": python_version,
        },
        "components": {},
    }
    
    # Group actions by component
    for entry in registry.get_manifest():
        component_name = entry["component"]
        
        if component_name not in manifest_data["components"]:
            manifest_data["components"][component_name] = {
                "name": component_name,
                "description": entry["component_description"],
                "properties": entry["component_properties"],
                "actions": {},
            }
        
        manifest_data["components"][component_name]["actions"][entry["action"]] = {
            "name": entry["name"],
            "description": entry["description"],
            "tags": entry["tags"],
            "visible_parameters": entry["visible_parameters"],
            "request_schema": entry["request_schema"],
            "response_schema": entry["response_schema"],
        }
    
    # Write to file
    output_path.parent.mkdir(parents=True, exist_ok=True)
    
    with open(output_path, "w") as f:
        if pretty:
            json.dump(manifest_data, f, indent=2)
        else:
            json.dump(manifest_data, f)
    
    print(f"✓ Manifest written to {output_path}")
    print(f"  Components: {len(manifest_data['components'])}")
    total_actions = sum(len(c["actions"]) for c in manifest_data["components"].values())
    print(f"  Actions: {total_actions}")


def load_manifest(manifest_path: str | Path) -> dict[str, Any]:
    """
    Load a manifest JSON file.
    
    Args:
        manifest_path: Path to the manifest JSON file.
    
    Returns:
        Parsed manifest data.
    
    Raises:
        ManifestError: If the manifest file is invalid or missing.
    """
    manifest_path = Path(manifest_path)
    
    if not manifest_path.exists():
        raise ManifestError(f"Manifest file not found: {manifest_path}")
    
    try:
        with open(manifest_path) as f:
            manifest = json.load(f)
    except json.JSONDecodeError as e:
        raise ManifestError(f"Invalid JSON in manifest: {e}")
    
    # Basic validation
    if "components" not in manifest:
        raise ManifestError("Manifest missing 'components' field")
    
    return manifest


class ComponentRunner:
    """
    Executes component actions based on a loaded manifest.
    
    This is used at runtime (e.g., in e2b sandbox) to invoke actions
    without needing to import the full registry or component classes.
    
    Example:
        # In the sandbox invoker
        runner = ComponentRunner("manifest.json", "my_component")
        runner.import_components()
        
        result = runner.invoke("Items", "list_items", {"active_only": True})
    """
    
    def __init__(self, manifest_path: str | Path, component_module: str):
        """
        Initialize the component runner.
        
        Args:
            manifest_path: Path to the manifest JSON file.
            component_module: Python module path where components are defined
                             (e.g., "my_component.components").
        """
        self.manifest_path = Path(manifest_path)
        self.component_module = component_module
        self.manifest = load_manifest(manifest_path)
        self.registry: Registry | None = None
    
    def import_components(self) -> None:
        """
        Import and register components from the specified module.
        
        This dynamically imports the component module and discovers
        all components, registering them with an internal registry.
        
        Raises:
            ManifestError: If components cannot be imported.
        """
        try:
            from .registry import Registry
            
            self.registry = Registry()
            self.registry.discover(self.component_module)
            
            print(f"✓ Imported {len(self.registry)} component(s) from {self.component_module}")
        except Exception as e:
            raise ManifestError(f"Failed to import components: {e}")
    
    def get_manifest(self) -> dict[str, Any]:
        """
        Get the loaded manifest data.
        
        Returns:
            The manifest dictionary.
        """
        return self.manifest
    
    def list_components(self) -> list[str]:
        """
        List all available components from the manifest.
        
        Returns:
            List of component names.
        """
        return list(self.manifest["components"].keys())
    
    def list_actions(self, component_name: str) -> list[str]:
        """
        List all actions for a specific component.
        
        Args:
            component_name: Name of the component.
        
        Returns:
            List of action names (method names).
        
        Raises:
            ManifestError: If component is not found.
        """
        if component_name not in self.manifest["components"]:
            raise ManifestError(f"Component '{component_name}' not found in manifest")
        
        return list(self.manifest["components"][component_name]["actions"].keys())
    
    def get_action_schema(self, component_name: str, action_name: str) -> dict[str, Any]:
        """
        Get the request and response schemas for an action.
        
        Args:
            component_name: Name of the component.
            action_name: Name of the action (method name).
        
        Returns:
            Dictionary with "request_schema" and "response_schema" keys.
        
        Raises:
            ManifestError: If component or action is not found.
        """
        if component_name not in self.manifest["components"]:
            raise ManifestError(f"Component '{component_name}' not found in manifest")
        
        component = self.manifest["components"][component_name]
        
        if action_name not in component["actions"]:
            raise ManifestError(
                f"Action '{action_name}' not found in component '{component_name}'"
            )
        
        action = component["actions"][action_name]
        return {
            "request_schema": action["request_schema"],
            "response_schema": action["response_schema"],
        }
    
    def set_properties(self, component_name: str, properties: dict[str, Any]) -> None:
        """
        Set properties on a component instance.
        
        Args:
            component_name: Name of the component.
            properties: Dictionary of property names to values.
        
        Raises:
            ManifestError: If components haven't been imported or component not found.
        
        Example:
            runner.set_properties("Partners", {"include_inactive": True})
        """
        if self.registry is None:
            raise ManifestError(
                "Components not imported. Call import_components() first."
            )
        
        if component_name not in self.manifest["components"]:
            raise ManifestError(f"Component '{component_name}' not found in manifest")
        
        # Get the component instance from registry
        instance = self.registry._instances.get(component_name)
        if instance is None:
            raise ManifestError(f"Component '{component_name}' instance not found")
        
        # Set properties on the instance
        for prop_name, prop_value in properties.items():
            if hasattr(instance, prop_name):
                setattr(instance, prop_name, prop_value)
            else:
                raise ManifestError(
                    f"Property '{prop_name}' not found on component '{component_name}'"
                )
    
    def get_properties(self, component_name: str) -> dict[str, Any]:
        """
        Get current property values from a component instance.
        
        Args:
            component_name: Name of the component.
        
        Returns:
            Dictionary of property names to current values.
        
        Raises:
            ManifestError: If components haven't been imported or component not found.
        """
        if self.registry is None:
            raise ManifestError(
                "Components not imported. Call import_components() first."
            )
        
        if component_name not in self.manifest["components"]:
            raise ManifestError(f"Component '{component_name}' not found in manifest")
        
        # Get property definitions from manifest
        component_manifest = self.manifest["components"][component_name]
        prop_definitions = component_manifest.get("properties", {})
        
        # Get the component instance
        instance = self.registry._instances.get(component_name)
        if instance is None:
            raise ManifestError(f"Component '{component_name}' instance not found")
        
        # Get current values
        return {
            prop_name: getattr(instance, prop_name, None)
            for prop_name in prop_definitions.keys()
        }
    
    def invoke(self, component_name: str, action_name: str, request: dict[str, Any]) -> dict[str, Any]:
        """
        Invoke an action from the manifest.
        
        Args:
            component_name: Name of the component.
            action_name: Name of the action (method name).
            request: Request dictionary to pass to the action.
        
        Returns:
            Response dictionary from the action.
        
        Raises:
            ManifestError: If components haven't been imported or action not found.
        """
        if self.registry is None:
            raise ManifestError(
                "Components not imported. Call import_components() first."
            )
        
        # Validate action exists in manifest
        if component_name not in self.manifest["components"]:
            raise ManifestError(f"Component '{component_name}' not found in manifest")
        
        component = self.manifest["components"][component_name]
        if action_name not in component["actions"]:
            raise ManifestError(
                f"Action '{action_name}' not found in component '{component_name}'"
            )
        
        # Invoke via registry
        return self.registry.invoke(component_name, action_name, request)
