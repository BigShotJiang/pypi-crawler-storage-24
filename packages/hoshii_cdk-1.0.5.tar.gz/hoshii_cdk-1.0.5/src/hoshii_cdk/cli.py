#!/usr/bin/env python3
"""
CLI tool for generating component manifests.

Usage:
    python -m hoshii_cdk.cli generate --module my_component.components --output manifest.json
"""

import argparse
import sys
from pathlib import Path

from hoshii_cdk import Registry, generate_manifest


def cmd_generate(args):
    """Generate a manifest from components."""
    print(f"Discovering components in '{args.module}'...")
    
    registry = Registry()
    
    try:
        discovered = registry.discover(args.module)
        print(f"✓ Discovered {len(discovered)} component(s)")
        
        for component_class in discovered:
            actions = component_class.get_actions()
            print(f"  - {component_class.name}: {len(actions)} action(s)")
    except Exception as e:
        print(f"✗ Error discovering components: {e}", file=sys.stderr)
        sys.exit(1)
    
    print(f"\nGenerating manifest...")
    
    try:
        generate_manifest(registry, args.output, pretty=not args.compact)
    except Exception as e:
        print(f"✗ Error generating manifest: {e}", file=sys.stderr)
        sys.exit(1)


def cmd_validate(args):
    """Validate a manifest file."""
    from hoshii_cdk import load_manifest
    
    print(f"Validating manifest '{args.manifest}'...")
    
    try:
        manifest = load_manifest(args.manifest)
        
        component_count = len(manifest["components"])
        action_count = sum(len(c["actions"]) for c in manifest["components"].values())
        
        print(f"✓ Manifest is valid")
        print(f"  Version: {manifest.get('version', 'unknown')}")
        print(f"  Components: {component_count}")
        print(f"  Actions: {action_count}")
        
        if args.verbose:
            print("\nComponents:")
            for name, component in manifest["components"].items():
                print(f"  - {name}: {len(component['actions'])} action(s)")
                if args.verbose > 1:
                    for action_name in component["actions"]:
                        print(f"      - {action_name}")
    except Exception as e:
        print(f"✗ Manifest validation failed: {e}", file=sys.stderr)
        sys.exit(1)


def main():
    parser = argparse.ArgumentParser(
        description="Hoshii CDK CLI - Tools for component development"
    )
    
    subparsers = parser.add_subparsers(dest="command", help="Available commands")
    
    # Generate command
    generate_parser = subparsers.add_parser(
        "generate",
        help="Generate a manifest from components"
    )
    generate_parser.add_argument(
        "--module",
        "-m",
        required=True,
        help="Python module path to discover components (e.g., my_component.components)"
    )
    generate_parser.add_argument(
        "--output",
        "-o",
        required=True,
        help="Output path for the manifest JSON file"
    )
    generate_parser.add_argument(
        "--compact",
        action="store_true",
        help="Generate compact JSON (no indentation)"
    )
    
    # Validate command
    validate_parser = subparsers.add_parser(
        "validate",
        help="Validate a manifest file"
    )
    validate_parser.add_argument(
        "manifest",
        help="Path to the manifest JSON file"
    )
    validate_parser.add_argument(
        "-v", "--verbose",
        action="count",
        default=0,
        help="Increase verbosity (use -vv for more detail)"
    )
    
    args = parser.parse_args()
    
    if args.command == "generate":
        cmd_generate(args)
    elif args.command == "validate":
        cmd_validate(args)
    else:
        parser.print_help()
        sys.exit(1)


if __name__ == "__main__":
    main()
