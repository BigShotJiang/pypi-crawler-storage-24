"""
Registry for managing components and their actions.
"""

import importlib
import inspect
import pkgutil
from typing import Any

from .component import Component
from .exceptions import ActionNotFoundError, ComponentNotFoundError, ComponentError
from .schema import python_type_to_json_schema
from .types import ActionMetadata, ComponentMetadata


class Registry:
    """
    Central registry for managing components and their actions.
    
    The registry allows you to:
    - Register component classes
    - Auto-discover components in a module/package
    - Get a manifest of all available actions with their schemas
    - Invoke actions by component and action name
    
    Example:
        registry = Registry()
        registry.register(ItemsComponent)
        registry.register(BusinessPartnersComponent)
        
        # Get manifest for workflow platform
        manifest = registry.get_manifest()
        
        # Invoke an action
        result = registry.invoke("Items", "list_items", {"active_only": True})
    """
    
    def __init__(self):
        self._components: dict[str, ComponentMetadata] = {}
        self._instances: dict[str, Component] = {}
    
    def register(self, component_class: type[Component]) -> None:
        """
        Register a component class.
        
        Args:
            component_class: A subclass of Component to register.
        
        Raises:
            ComponentError: If the class is not a valid Component subclass.
        """
        if not isinstance(component_class, type) or not issubclass(component_class, Component):
            raise ComponentError(
                f"{component_class} is not a valid Component subclass"
            )
        
        if component_class is Component:
            raise ComponentError("Cannot register the base Component class")
        
        # Validate the component
        component_class.validate()
        
        # Store metadata
        metadata = component_class.get_metadata()
        self._components[metadata.name] = metadata
        
        # Create and store instance
        self._instances[metadata.name] = component_class()
    
    def unregister(self, component_name: str) -> None:
        """
        Unregister a component by name.
        
        Args:
            component_name: The name of the component to unregister.
        """
        self._components.pop(component_name, None)
        self._instances.pop(component_name, None)
    
    def discover(self, module_path: str) -> list[type[Component]]:
        """
        Auto-discover and register all Component subclasses in a module/package.
        
        This recursively searches the given module path for classes that
        subclass Component and registers them.
        
        Args:
            module_path: Dotted module path (e.g., "my_package.components").
        
        Returns:
            List of discovered and registered component classes.
        
        Example:
            registry.discover("my_component.components")
        """
        discovered = []
        
        try:
            module = importlib.import_module(module_path)
        except ImportError as e:
            raise ComponentError(f"Failed to import module '{module_path}': {e}")
        
        # Get all classes from the module
        for name, obj in inspect.getmembers(module, inspect.isclass):
            if (issubclass(obj, Component) and 
                obj is not Component and 
                obj.name):  # Must have a name defined
                try:
                    self.register(obj)
                    discovered.append(obj)
                except ComponentError:
                    pass  # Skip invalid components
        
        # If it's a package, recursively discover in submodules
        if hasattr(module, "__path__"):
            for _, submodule_name, _ in pkgutil.iter_modules(module.__path__):
                full_path = f"{module_path}.{submodule_name}"
                discovered.extend(self.discover(full_path))
        
        return discovered
    
    def get_component(self, component_name: str) -> ComponentMetadata:
        """
        Get metadata for a specific component.
        
        Args:
            component_name: The name of the component.
        
        Returns:
            ComponentMetadata for the component.
        
        Raises:
            ComponentNotFoundError: If the component is not registered.
        """
        if component_name not in self._components:
            raise ComponentNotFoundError(component_name)
        return self._components[component_name]
    
    def get_components(self) -> dict[str, ComponentMetadata]:
        """
        Get all registered components.
        
        Returns:
            Dictionary mapping component names to their metadata.
        """
        return self._components.copy()
    
    def get_action(self, component_name: str, action_name: str) -> ActionMetadata:
        """
        Get metadata for a specific action.
        
        Args:
            component_name: The name of the component.
            action_name: The method name of the action.
        
        Returns:
            ActionMetadata for the action.
        
        Raises:
            ComponentNotFoundError: If the component is not registered.
            ActionNotFoundError: If the action is not found.
        """
        component = self.get_component(component_name)
        
        if action_name not in component.actions:
            raise ActionNotFoundError(component_name, action_name)
        
        return component.actions[action_name]
    
    def get_manifest(self) -> list[dict[str, Any]]:
        """
        Get a manifest of all registered actions with their schemas.
        
        This is the primary method for workflow platforms to discover
        available actions and their input/output schemas.
        
        Returns:
            List of action descriptors with full schema information.
        
        Example output:
            [
                {
                    "component": "Items",
                    "component_description": "Item/product operations",
                    "component_properties": {...},
                    "action": "list_items",
                    "name": "List Items",
                    "description": "List items with filtering",
                    "tags": [],
                    "request_schema": {...},
                    "response_schema": {...},
                }
            ]
        """
        manifest = []
        
        for component_name, component_meta in self._components.items():
            # Build properties schema for this component
            properties_schema = {}
            for prop_name, prop_meta in component_meta.properties.items():
                properties_schema[prop_name] = {
                    "display_name": prop_meta.display_name,
                    "description": prop_meta.description,
                    "required": prop_meta.required,
                    "default_value": prop_meta.default_value,
                    "schema": _type_to_json_schema_type(prop_meta.schema),
                }
            
            for action_name, action_meta in component_meta.actions.items():
                manifest.append({
                    "component": component_name,
                    "component_description": component_meta.description,
                    "component_properties": properties_schema,
                    "action": action_name,
                    "name": action_meta.name,
                    "description": action_meta.description,
                    "tags": action_meta.tags,
                    "visible_parameters": action_meta.visible_parameters,
                    "request_schema": python_type_to_json_schema(action_meta.request_schema),
                    "response_schema": python_type_to_json_schema(action_meta.response_schema),
                })
        
        return manifest
    
    def invoke(
        self,
        component_name: str,
        action_name: str,
        request: dict[str, Any],
    ) -> dict[str, Any]:
        """
        Invoke an action by component and action name.
        
        Args:
            component_name: The name of the component.
            action_name: The method name of the action.
            request: The request dictionary to pass to the action.
        
        Returns:
            The response dictionary from the action.
        
        Raises:
            ComponentNotFoundError: If the component is not registered.
            ActionNotFoundError: If the action is not found.
        """
        # Validate component and action exist
        self.get_action(component_name, action_name)
        
        # Get the component instance
        instance = self._instances[component_name]
        
        # Get and call the method
        method = getattr(instance, action_name)
        return method(request)
    
    def __len__(self) -> int:
        """Return the number of registered components."""
        return len(self._components)
    
    def __contains__(self, component_name: str) -> bool:
        """Check if a component is registered."""
        return component_name in self._components


def _type_to_json_schema_type(python_type: type) -> dict[str, Any]:
    """Convert a Python type to JSON Schema type definition."""
    import typing
    from enum import IntEnum, Enum
    
    # Handle Optional types
    origin = typing.get_origin(python_type)
    if origin is typing.Union:
        args = typing.get_args(python_type)
        # Optional[X] is Union[X, None]
        non_none_args = [a for a in args if a is not type(None)]
        if len(non_none_args) == 1:
            return _type_to_json_schema_type(non_none_args[0])
    
    # Handle dict[str, str] etc
    if origin is dict:
        return {"type": "object", "additionalProperties": {"type": "string"}}
    
    # Handle list types
    if origin is list:
        args = typing.get_args(python_type)
        if args:
            return {"type": "array", "items": _type_to_json_schema_type(args[0])}
        return {"type": "array"}
    
    # Handle Python IntEnum/Enum
    if isinstance(python_type, type) and issubclass(python_type, (IntEnum, Enum)):
        return {
            "oneOf": [
                {"const": e.value, "title": e.name}
                for e in python_type
            ]
        }
    
    # Handle protobuf EnumTypeWrapper (e.g., TokenType from authentication_pb2)
    if hasattr(python_type, 'DESCRIPTOR') and hasattr(python_type, 'values'):
        # It's a protobuf enum
        return {
            "oneOf": [
                {"const": number, "title": name}
                for name, number in python_type.items()
            ]
        }
    
    # Simple type mapping
    type_map = {
        int: {"type": "integer"},
        str: {"type": "string"},
        bool: {"type": "boolean"},
        float: {"type": "number"},
        list: {"type": "array"},
        dict: {"type": "object"},
    }
    return type_map.get(python_type, {"type": "string"})
