"""
Custom exceptions for the Hoshii CDK.
"""


class HoshiiCDKError(Exception):
    """Base exception for all Hoshii CDK errors."""
    pass


class ComponentError(HoshiiCDKError):
    """Error related to component definition or instantiation."""
    pass


class ActionNotFoundError(HoshiiCDKError):
    """Raised when an action is not found in the registry."""
    
    def __init__(self, component_name: str, action_name: str):
        self.component_name = component_name
        self.action_name = action_name
        super().__init__(
            f"Action '{action_name}' not found in component '{component_name}'"
        )


class ComponentNotFoundError(HoshiiCDKError):
    """Raised when a component is not found in the registry."""
    
    def __init__(self, component_name: str):
        self.component_name = component_name
        super().__init__(f"Component '{component_name}' not found in registry")


class ValidationError(HoshiiCDKError):
    """Raised when request or response validation fails."""
    
    def __init__(self, message: str, errors: list[str] = None):
        self.errors = errors or []
        super().__init__(message)


class SchemaError(HoshiiCDKError):
    """Raised when there's an error converting schemas."""
    pass
