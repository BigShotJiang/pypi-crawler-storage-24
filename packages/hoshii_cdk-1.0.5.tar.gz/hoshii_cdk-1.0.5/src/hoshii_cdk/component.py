"""
Base Component class for defining components.
"""

from dataclasses import dataclass
from typing import ClassVar, Any, get_type_hints

from .action import get_action_metadata, is_action
from .types import ActionMetadata, ComponentMetadata, PropertyMetadata
from .exceptions import ComponentError


# Special attributes that should not be treated as properties
_RESERVED_ATTRS = {'name', 'description', '_actions', '_properties'}


class ComponentMeta(type):
    """
    Metaclass for Component that collects @action decorated methods and properties.
    
    This metaclass automatically discovers:
    - All methods decorated with @action
    - All class-level typed attributes (properties)
    """
    
    def __new__(mcs, name: str, bases: tuple, namespace: dict):
        cls = super().__new__(mcs, name, bases, namespace)
        
        # Skip processing for the base Component class
        if name == "Component" and not bases:
            return cls
        
        # Collect actions from this class and all base classes
        actions: dict[str, ActionMetadata] = {}
        properties: dict[str, PropertyMetadata] = {}
        
        # First, collect from base classes
        for base in bases:
            if hasattr(base, "_actions"):
                actions.update(base._actions)
            if hasattr(base, "_properties"):
                properties.update(base._properties)
        
        # Collect actions from this class
        for attr_name, attr_value in namespace.items():
            if callable(attr_value) and is_action(attr_value):
                metadata = get_action_metadata(attr_value)
                if metadata:
                    actions[attr_name] = metadata
        
        # Collect properties from type annotations (use cls.__annotations__ after class creation)
        annotations = getattr(cls, '__annotations__', {})
        for prop_name, prop_type in annotations.items():
            if prop_name.startswith('_') or prop_name in _RESERVED_ATTRS:
                continue
            
            # Skip ClassVar annotations (like name, description in base class)
            if hasattr(prop_type, '__origin__') and prop_type.__origin__ is ClassVar:
                continue
            
            # Get default value if exists
            default_value = getattr(cls, prop_name, None)
            
            # Determine if required (no default value set on class)
            is_required = not hasattr(cls, prop_name) or getattr(cls, prop_name) is None
            
            properties[prop_name] = PropertyMetadata(
                name=prop_name,
                display_name=prop_name.replace('_', ' ').title(),
                description=f"Component property: {prop_name}",
                schema=prop_type,
                required=is_required,
                default_value=default_value,
            )
        
        cls._actions = actions
        cls._properties = properties
        return cls


class Component(metaclass=ComponentMeta):
    """
    Base class for defining components.
    
    Subclass this to create a component with properties and actions:
    
        class ItemsComponent(Component):
            name = "Items"
            description = "Item/product operations"
            
            # Properties (component-level configuration)
            api_key: str = ""
            timeout: int = 30
            
            @action(
                name="List Items",
                description="List items with filtering",
                request_schema=ListItemsRequest,
                response_schema=ListItemsResponse,
            )
            def list_items(self, request: dict) -> dict:
                ...
    """
    
    name: ClassVar[str] = ""
    """Human-readable name of the component."""
    
    description: ClassVar[str] = ""
    """Description of what the component does."""
    
    _actions: ClassVar[dict[str, ActionMetadata]] = {}
    """Dictionary of action method names to their metadata (populated by metaclass)."""
    
    _properties: ClassVar[dict[str, PropertyMetadata]] = {}
    """Dictionary of property names to their metadata (populated by metaclass)."""
    
    @classmethod
    def get_actions(cls) -> dict[str, ActionMetadata]:
        """
        Get all actions defined on this component.
        
        Returns:
            Dictionary mapping method names to ActionMetadata.
        """
        return cls._actions.copy()
    
    @classmethod
    def get_action(cls, method_name: str) -> ActionMetadata | None:
        """
        Get metadata for a specific action.
        
        Args:
            method_name: The name of the action method.
        
        Returns:
            ActionMetadata if found, None otherwise.
        """
        return cls._actions.get(method_name)
    
    @classmethod
    def get_properties(cls) -> dict[str, PropertyMetadata]:
        """
        Get all properties defined on this component.
        
        Returns:
            Dictionary mapping property names to PropertyMetadata.
        """
        return cls._properties.copy()
    
    @classmethod
    def get_property(cls, prop_name: str) -> PropertyMetadata | None:
        """
        Get metadata for a specific property.
        
        Args:
            prop_name: The name of the property.
        
        Returns:
            PropertyMetadata if found, None otherwise.
        """
        return cls._properties.get(prop_name)
    
    @classmethod
    def get_metadata(cls) -> ComponentMetadata:
        """
        Get the full metadata for this component.
        
        Returns:
            ComponentMetadata with all property and action information.
        """
        return ComponentMetadata(
            name=cls.name,
            description=cls.description,
            component_class=cls,
            properties=cls.get_properties(),
            actions=cls.get_actions(),
        )
    
    @classmethod
    def validate(cls) -> None:
        """
        Validate the component definition.
        
        Raises:
            ComponentError: If the component is not properly defined.
        """
        if not cls.name:
            raise ComponentError(
                f"Component {cls.__name__} must define a 'name' class attribute"
            )
        
        if not cls._actions:
            raise ComponentError(
                f"Component {cls.__name__} must define at least one @action method"
            )
