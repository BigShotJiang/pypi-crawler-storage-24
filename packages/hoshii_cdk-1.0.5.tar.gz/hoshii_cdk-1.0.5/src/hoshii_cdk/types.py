"""
Type definitions for the Hoshii CDK.
"""

from dataclasses import dataclass, field
from typing import Any, Callable, Optional


@dataclass
class PropertyMetadata:
    """Metadata for a component property."""
    
    name: str
    """Property name (Python attribute name)."""
    
    display_name: str
    """Human-readable name for UI display."""
    
    description: str
    """Description of what this property does."""
    
    schema: type
    """Protobuf message class defining the property schema."""
    
    required: bool = False
    """Whether this property is required."""
    
    default_value: Any = None
    """Default value for this property."""
    
    tags: list[str] = field(default_factory=list)
    """Optional tags for categorizing the property."""


@dataclass
class ActionMetadata:
    """Metadata for a component action."""
    
    name: str
    """Human-readable name of the action."""
    
    description: str
    """Description of what the action does."""
    
    method_name: str
    """The name of the method on the component class."""
    
    request_schema: type
    """Protobuf message class for the request."""
    
    response_schema: type
    """Protobuf message class for the response."""
    
    tags: list[str] = field(default_factory=list)
    """Optional tags for categorizing the action."""
    
    visible_parameters: list[str] = field(default_factory=list)
    """List of parameter names to show in UI (empty = show all)."""


@dataclass
class ComponentMetadata:
    """Metadata for a component."""
    
    name: str
    """Human-readable name of the component."""
    
    description: str
    """Description of what the component does."""
    
    component_class: type
    """The component class itself."""
    
    properties: dict[str, PropertyMetadata] = field(default_factory=dict)
    """Dictionary of property names to their metadata."""
    
    actions: dict[str, ActionMetadata] = field(default_factory=dict)
    """Dictionary of action method names to their metadata."""
