"""
Action decorator for marking component methods as actions.
"""

from functools import wraps
from typing import Callable, TypeVar

from .types import ActionMetadata

F = TypeVar("F", bound=Callable)

ACTION_METADATA_ATTR = "_hoshii_action_metadata"


def action(
    name: str,
    description: str,
    request_schema: type,
    response_schema: type,
    tags: list[str] = None,
    visible_parameters: list[str] = None,
) -> Callable[[F], F]:
    """
    Decorator to mark a method as a component action.
    
    This decorator attaches metadata to the method that describes the action,
    including its name, description, and request/response schemas.
    
    Args:
        name: Human-readable name of the action.
        description: Description of what the action does.
        request_schema: Protobuf message class for the request.
        response_schema: Protobuf message class for the response.
        tags: Optional list of tags for categorizing the action.
        visible_parameters: Optional list of parameter names to show in UI.
                           If empty/None, all parameters are shown.
    
    Returns:
        Decorated method with attached metadata.
    
    Example:
        @action(
            name="List Items",
            description="List items with filtering",
            request_schema=ListItemsRequest,
            response_schema=ListItemsResponse,
            visible_parameters=["activeOnly"],  # Only show this in UI
        )
        def list_items(self, request: dict) -> dict:
            ...
    """
    def decorator(func: F) -> F:
        metadata = ActionMetadata(
            name=name,
            description=description,
            method_name=func.__name__,
            request_schema=request_schema,
            response_schema=response_schema,
            tags=tags or [],
            visible_parameters=visible_parameters or [],
        )
        
        setattr(func, ACTION_METADATA_ATTR, metadata)
        
        @wraps(func)
        def wrapper(*args, **kwargs):
            return func(*args, **kwargs)
        
        setattr(wrapper, ACTION_METADATA_ATTR, metadata)
        return wrapper
    
    return decorator


def get_action_metadata(func: Callable) -> ActionMetadata | None:
    """
    Get the action metadata from a decorated method.
    
    Args:
        func: The method to get metadata from.
    
    Returns:
        ActionMetadata if the method is decorated with @action, None otherwise.
    """
    return getattr(func, ACTION_METADATA_ATTR, None)


def is_action(func: Callable) -> bool:
    """
    Check if a method is decorated with @action.
    
    Args:
        func: The method to check.
    
    Returns:
        True if the method is an action, False otherwise.
    """
    return hasattr(func, ACTION_METADATA_ATTR)
