"""Pytest configuration and fixtures."""

import pytest

from tests.test_pb2 import MockRequest, MockResponse


@pytest.fixture
def mock_request_class():
    """Fixture providing a protobuf request class."""
    return MockRequest


@pytest.fixture
def mock_response_class():
    """Fixture providing a protobuf response class."""
    return MockResponse
