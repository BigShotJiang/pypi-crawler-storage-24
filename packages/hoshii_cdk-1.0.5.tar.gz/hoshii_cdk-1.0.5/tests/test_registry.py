"""Tests for the Registry class."""

import pytest

from hoshii_cdk import (
    Component,
    Registry,
    action,
    ComponentError,
    ComponentNotFoundError,
    ActionNotFoundError,
)


class TestRegistry:
    """Tests for the Registry class."""
    
    @pytest.fixture
    def sample_component(self, mock_request_class, mock_response_class):
        """Create a sample component for testing."""
        
        class SampleComponent(Component):
            name = "Sample"
            description = "A sample component"
            
            @action(
                name="Do Something",
                description="Does something",
                request_schema=mock_request_class,
                response_schema=mock_response_class,
            )
            def do_something(self, request: dict) -> dict:
                return {"done": True, "input": request}
        
        return SampleComponent
    
    @pytest.fixture
    def another_component(self, mock_request_class, mock_response_class):
        """Create another component for testing."""
        
        class AnotherComponent(Component):
            name = "Another"
            description = "Another component"
            
            @action(
                name="Other Action",
                description="Another action",
                request_schema=mock_request_class,
                response_schema=mock_response_class,
            )
            def other_action(self, request: dict) -> dict:
                return {"other": True}
        
        return AnotherComponent
    
    def test_register_component(self, sample_component):
        """Test registering a component."""
        registry = Registry()
        registry.register(sample_component)
        
        assert "Sample" in registry
        assert len(registry) == 1
    
    def test_register_multiple_components(self, sample_component, another_component):
        """Test registering multiple components."""
        registry = Registry()
        registry.register(sample_component)
        registry.register(another_component)
        
        assert "Sample" in registry
        assert "Another" in registry
        assert len(registry) == 2
    
    def test_register_rejects_non_component(self):
        """Test that register rejects non-Component classes."""
        registry = Registry()
        
        class NotAComponent:
            pass
        
        with pytest.raises(ComponentError, match="not a valid Component"):
            registry.register(NotAComponent)
    
    def test_register_rejects_base_component(self):
        """Test that register rejects the base Component class."""
        registry = Registry()
        
        with pytest.raises(ComponentError, match="Cannot register the base Component"):
            registry.register(Component)
    
    def test_unregister_component(self, sample_component):
        """Test unregistering a component."""
        registry = Registry()
        registry.register(sample_component)
        
        assert "Sample" in registry
        
        registry.unregister("Sample")
        
        assert "Sample" not in registry
    
    def test_get_component(self, sample_component):
        """Test getting component metadata."""
        registry = Registry()
        registry.register(sample_component)
        
        metadata = registry.get_component("Sample")
        
        assert metadata.name == "Sample"
        assert metadata.description == "A sample component"
    
    def test_get_component_not_found(self):
        """Test getting a non-existent component raises error."""
        registry = Registry()
        
        with pytest.raises(ComponentNotFoundError):
            registry.get_component("NonExistent")
    
    def test_get_components(self, sample_component, another_component):
        """Test getting all components."""
        registry = Registry()
        registry.register(sample_component)
        registry.register(another_component)
        
        components = registry.get_components()
        
        assert len(components) == 2
        assert "Sample" in components
        assert "Another" in components
    
    def test_get_action(self, sample_component):
        """Test getting action metadata."""
        registry = Registry()
        registry.register(sample_component)
        
        action_meta = registry.get_action("Sample", "do_something")
        
        assert action_meta.name == "Do Something"
        assert action_meta.method_name == "do_something"
    
    def test_get_action_component_not_found(self):
        """Test getting action from non-existent component."""
        registry = Registry()
        
        with pytest.raises(ComponentNotFoundError):
            registry.get_action("NonExistent", "some_action")
    
    def test_get_action_not_found(self, sample_component):
        """Test getting non-existent action."""
        registry = Registry()
        registry.register(sample_component)
        
        with pytest.raises(ActionNotFoundError):
            registry.get_action("Sample", "non_existent")
    
    def test_invoke_action(self, sample_component):
        """Test invoking an action."""
        registry = Registry()
        registry.register(sample_component)
        
        result = registry.invoke("Sample", "do_something", {"value": 42})
        
        assert result["done"] is True
        assert result["input"] == {"value": 42}
    
    def test_invoke_component_not_found(self):
        """Test invoking action on non-existent component."""
        registry = Registry()
        
        with pytest.raises(ComponentNotFoundError):
            registry.invoke("NonExistent", "action", {})
    
    def test_invoke_action_not_found(self, sample_component):
        """Test invoking non-existent action."""
        registry = Registry()
        registry.register(sample_component)
        
        with pytest.raises(ActionNotFoundError):
            registry.invoke("Sample", "non_existent", {})
    
    def test_get_manifest(self, sample_component, mock_request_class, mock_response_class):
        """Test getting the action manifest."""
        registry = Registry()
        registry.register(sample_component)
        
        manifest = registry.get_manifest()
        
        assert len(manifest) == 1
        
        entry = manifest[0]
        assert entry["component"] == "Sample"
        assert entry["component_description"] == "A sample component"
        assert entry["action"] == "do_something"
        assert entry["name"] == "Do Something"
        assert entry["description"] == "Does something"
        assert "request_schema" in entry
        assert "response_schema" in entry
    
    def test_get_manifest_multiple_components(self, sample_component, another_component):
        """Test manifest with multiple components."""
        registry = Registry()
        registry.register(sample_component)
        registry.register(another_component)
        
        manifest = registry.get_manifest()
        
        assert len(manifest) == 2
        
        components = {entry["component"] for entry in manifest}
        assert components == {"Sample", "Another"}
    
    def test_contains(self, sample_component):
        """Test __contains__ method."""
        registry = Registry()
        
        assert "Sample" not in registry
        
        registry.register(sample_component)
        
        assert "Sample" in registry
    
    def test_len(self, sample_component, another_component):
        """Test __len__ method."""
        registry = Registry()
        
        assert len(registry) == 0
        
        registry.register(sample_component)
        assert len(registry) == 1
        
        registry.register(another_component)
        assert len(registry) == 2
