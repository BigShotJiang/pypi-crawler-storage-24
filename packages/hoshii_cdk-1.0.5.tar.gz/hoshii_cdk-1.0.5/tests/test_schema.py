"""Tests for schema conversion utilities."""

import pytest
from dataclasses import dataclass

from hoshii_cdk import python_type_to_json_schema, SchemaError


class TestPythonTypeToJsonSchema:
    """Tests for python_type_to_json_schema function."""
    
    def test_converts_protobuf_message(self, mock_request_class):
        """Test converting a protobuf-like message with DESCRIPTOR."""
        schema = python_type_to_json_schema(mock_request_class)
        
        # Title comes from the descriptor name
        assert schema["title"] in ("MockProtoMessage", "MockRequest")
        assert schema["type"] == "object"
        assert "properties" in schema
        assert "required" in schema
    
    def test_converts_string_field(self, mock_request_class):
        """Test that string fields are converted correctly."""
        schema = python_type_to_json_schema(mock_request_class)
        
        assert "id" in schema["properties"]
        assert schema["properties"]["id"]["type"] == "string"
        assert "id" in schema.get("required", [])
    
    def test_converts_integer_field(self, mock_request_class):
        """Test that integer fields are converted correctly."""
        schema = python_type_to_json_schema(mock_request_class)
        
        assert "count" in schema["properties"]
        assert schema["properties"]["count"]["type"] == "integer"
        assert "count" in schema.get("required", [])
    
    def test_converts_boolean_field(self, mock_request_class):
        """Test that boolean fields are converted correctly."""
        schema = python_type_to_json_schema(mock_request_class)
        
        assert "active" in schema["properties"]
        assert schema["properties"]["active"]["type"] == "boolean"
        assert "active" in schema.get("required", [])
    
    def test_converts_dataclass(self):
        """Test converting a dataclass."""
        @dataclass
        class TestData:
            name: str
            count: int
            active: bool = True
        
        schema = python_type_to_json_schema(TestData)
        
        assert schema["title"] == "TestData"
        assert schema["type"] == "object"
        assert "properties" in schema
        assert schema["properties"]["name"]["type"] == "string"
        assert schema["properties"]["count"]["type"] == "integer"
        assert schema["properties"]["active"]["type"] == "boolean"
    
    def test_converts_basic_types(self):
        """Test converting basic Python types."""
        assert python_type_to_json_schema(str)["type"] == "string"
        assert python_type_to_json_schema(int)["type"] == "integer"
        assert python_type_to_json_schema(bool)["type"] == "boolean"
        assert python_type_to_json_schema(float)["type"] == "number"
    
    def test_raises_for_unsupported_type(self):
        """Test that unsupported types raise SchemaError."""
        
        class NotSupported:
            pass
        
        with pytest.raises(SchemaError, match="Unsupported type"):
            python_type_to_json_schema(NotSupported)
    
    def test_schema_is_json_schema_compliant(self, mock_request_class):
        """Test that generated schema has standard JSON Schema fields."""
        schema = python_type_to_json_schema(mock_request_class)
        
        # Standard JSON Schema fields
        assert "type" in schema
        assert "properties" in schema
        assert schema["type"] == "object"
