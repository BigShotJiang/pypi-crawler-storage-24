"""
Tests for manifest generation and loading.
"""

import json
import pytest
from pathlib import Path

from hoshii_cdk import (
    Component,
    action,
    Registry,
    generate_manifest,
    load_manifest,
    ComponentRunner,
    ManifestError,
)

from tests.test_pb2 import MockRequest, MockResponse, MockListRequest, MockListResponse


class TestComponent(Component):
    name = "Test"
    description = "Test component"
    
    @action(
        name="List Items",
        description="List items",
        request_schema=MockListRequest,
        response_schema=MockListResponse,
    )
    def list_items(self, request: dict) -> dict:
        return {"items": []}
    
    @action(
        name="Get Item",
        description="Get an item",
        request_schema=MockRequest,
        response_schema=MockResponse,
    )
    def get_item(self, request: dict) -> dict:
        return {"item": {}}


class TestGenerateManifest:
    """Tests for generate_manifest function."""
    
    def test_generate_manifest(self, tmp_path):
        """Test generating a manifest file."""
        registry = Registry()
        registry.register(TestComponent)
        
        manifest_path = tmp_path / "manifest.json"
        generate_manifest(registry, manifest_path)
        
        assert manifest_path.exists()
        
        with open(manifest_path) as f:
            manifest = json.load(f)
        
        assert "version" in manifest
        assert "components" in manifest
        assert "Test" in manifest["components"]
        
        component = manifest["components"]["Test"]
        assert component["name"] == "Test"
        assert component["description"] == "Test component"
        assert "list_items" in component["actions"]
        assert "get_item" in component["actions"]
    
    def test_generate_manifest_pretty(self, tmp_path):
        """Test generating a pretty-printed manifest."""
        registry = Registry()
        registry.register(TestComponent)
        
        manifest_path = tmp_path / "manifest.json"
        generate_manifest(registry, manifest_path, pretty=True)
        
        with open(manifest_path) as f:
            content = f.read()
        
        assert "\n" in content
        assert "  " in content
    
    def test_generate_manifest_compact(self, tmp_path):
        """Test generating a compact manifest."""
        registry = Registry()
        registry.register(TestComponent)
        
        manifest_path = tmp_path / "manifest_compact.json"
        generate_manifest(registry, manifest_path, pretty=False)
        
        with open(manifest_path) as f:
            content = f.read()
        
        lines = content.strip().split("\n")
        assert len(lines) == 1
    
    def test_generate_manifest_creates_parent_dirs(self, tmp_path):
        """Test that generate_manifest creates parent directories."""
        manifest_path = tmp_path / "nested" / "dir" / "manifest.json"
        
        registry = Registry()
        registry.register(TestComponent)
        
        generate_manifest(registry, manifest_path)
        
        assert manifest_path.exists()


class TestLoadManifest:
    """Tests for load_manifest function."""
    
    def test_load_manifest(self, tmp_path):
        """Test loading a valid manifest."""
        manifest_data = {
            "version": "1.0",
            "components": {
                "Test": {
                    "name": "Test",
                    "description": "Test component",
                    "actions": {
                        "list_items": {
                            "name": "List Items",
                            "description": "List items",
                            "tags": [],
                            "request_schema": {},
                            "response_schema": {},
                        }
                    }
                }
            }
        }
        
        manifest_path = tmp_path / "manifest.json"
        with open(manifest_path, "w") as f:
            json.dump(manifest_data, f)
        
        manifest = load_manifest(manifest_path)
        
        assert manifest == manifest_data
    
    def test_load_manifest_not_found(self):
        """Test loading a non-existent manifest."""
        with pytest.raises(ManifestError, match="not found"):
            load_manifest("/nonexistent/manifest.json")
    
    def test_load_manifest_invalid_json(self, tmp_path):
        """Test loading an invalid JSON file."""
        manifest_path = tmp_path / "invalid.json"
        manifest_path.write_text("{invalid json")
        
        with pytest.raises(ManifestError, match="Invalid JSON"):
            load_manifest(manifest_path)
    
    def test_load_manifest_missing_components(self, tmp_path):
        """Test loading a manifest without 'components' field."""
        manifest_path = tmp_path / "manifest.json"
        manifest_path.write_text('{"version": "1.0"}')
        
        with pytest.raises(ManifestError, match="missing 'components'"):
            load_manifest(manifest_path)


class TestComponentRunner:
    """Tests for ComponentRunner class."""
    
    def test_component_runner_initialization(self, tmp_path):
        """Test initializing a ComponentRunner."""
        manifest_data = {
            "version": "1.0",
            "components": {}
        }
        
        manifest_path = tmp_path / "manifest.json"
        with open(manifest_path, "w") as f:
            json.dump(manifest_data, f)
        
        runner = ComponentRunner(manifest_path, "test_module")
        
        assert runner.manifest_path == manifest_path
        assert runner.component_module == "test_module"
        assert runner.manifest == manifest_data
    
    def test_get_manifest(self, tmp_path):
        """Test getting the loaded manifest."""
        manifest_data = {
            "version": "1.0",
            "components": {}
        }
        
        manifest_path = tmp_path / "manifest.json"
        with open(manifest_path, "w") as f:
            json.dump(manifest_data, f)
        
        runner = ComponentRunner(manifest_path, "test_module")
        
        assert runner.get_manifest() == manifest_data
    
    def test_list_components(self, tmp_path):
        """Test listing components from manifest."""
        manifest_data = {
            "version": "1.0",
            "components": {
                "Items": {"actions": {}},
                "Partners": {"actions": {}},
            }
        }
        
        manifest_path = tmp_path / "manifest.json"
        with open(manifest_path, "w") as f:
            json.dump(manifest_data, f)
        
        runner = ComponentRunner(manifest_path, "test_module")
        components = runner.list_components()
        
        assert len(components) == 2
        assert "Items" in components
        assert "Partners" in components
    
    def test_list_actions(self, tmp_path):
        """Test listing actions for a component."""
        manifest_data = {
            "version": "1.0",
            "components": {
                "Test": {
                    "actions": {
                        "list_items": {},
                        "get_item": {},
                    }
                }
            }
        }
        
        manifest_path = tmp_path / "manifest.json"
        with open(manifest_path, "w") as f:
            json.dump(manifest_data, f)
        
        runner = ComponentRunner(manifest_path, "test_module")
        actions = runner.list_actions("Test")
        
        assert len(actions) == 2
        assert "list_items" in actions
        assert "get_item" in actions
    
    def test_list_actions_not_found(self, tmp_path):
        """Test listing actions for a non-existent component."""
        manifest_data = {
            "version": "1.0",
            "components": {}
        }
        
        manifest_path = tmp_path / "manifest.json"
        with open(manifest_path, "w") as f:
            json.dump(manifest_data, f)
        
        runner = ComponentRunner(manifest_path, "test_module")
        
        with pytest.raises(ManifestError, match="not found in manifest"):
            runner.list_actions("NonExistent")
    
    def test_get_action_schema(self, tmp_path):
        """Test getting action schemas."""
        manifest_data = {
            "version": "1.0",
            "components": {
                "Test": {
                    "actions": {
                        "list_items": {
                            "request_schema": {"type": "object"},
                            "response_schema": {"type": "object"},
                        }
                    }
                }
            }
        }
        
        manifest_path = tmp_path / "manifest.json"
        with open(manifest_path, "w") as f:
            json.dump(manifest_data, f)
        
        runner = ComponentRunner(manifest_path, "test_module")
        schema = runner.get_action_schema("Test", "list_items")
        
        assert "request_schema" in schema
        assert "response_schema" in schema
        assert schema["request_schema"] == {"type": "object"}
    
    def test_invoke_without_import(self, tmp_path):
        """Test invoking without importing components first."""
        manifest_data = {
            "version": "1.0",
            "components": {}
        }
        
        manifest_path = tmp_path / "manifest.json"
        with open(manifest_path, "w") as f:
            json.dump(manifest_data, f)
        
        runner = ComponentRunner(manifest_path, "test_module")
        
        with pytest.raises(ManifestError, match="not imported"):
            runner.invoke("Test", "list_items", {})
