"""Tests for the Component base class."""

import pytest

from hoshii_cdk import Component, action, ComponentError
from hoshii_cdk.types import ActionMetadata, ComponentMetadata


class TestComponent:
    """Tests for the Component base class."""
    
    def test_component_collects_actions(self, mock_request_class, mock_response_class):
        """Test that Component metaclass collects @action methods."""
        
        class TestComponent(Component):
            name = "Test"
            description = "Test component"
            
            @action(
                name="Action One",
                description="First action",
                request_schema=mock_request_class,
                response_schema=mock_response_class,
            )
            def action_one(self, request: dict) -> dict:
                return {"action": "one"}
            
            @action(
                name="Action Two",
                description="Second action",
                request_schema=mock_request_class,
                response_schema=mock_response_class,
            )
            def action_two(self, request: dict) -> dict:
                return {"action": "two"}
        
        actions = TestComponent.get_actions()
        
        assert len(actions) == 2
        assert "action_one" in actions
        assert "action_two" in actions
        assert actions["action_one"].name == "Action One"
        assert actions["action_two"].name == "Action Two"
    
    def test_component_get_action(self, mock_request_class, mock_response_class):
        """Test getting a specific action by name."""
        
        class TestComponent(Component):
            name = "Test"
            description = "Test component"
            
            @action(
                name="My Action",
                description="An action",
                request_schema=mock_request_class,
                response_schema=mock_response_class,
            )
            def my_action(self, request: dict) -> dict:
                return {}
        
        action_meta = TestComponent.get_action("my_action")
        
        assert action_meta is not None
        assert action_meta.name == "My Action"
    
    def test_component_get_action_returns_none_for_unknown(self, mock_request_class, mock_response_class):
        """Test get_action returns None for unknown action."""
        
        class TestComponent(Component):
            name = "Test"
            description = "Test component"
            
            @action(
                name="Known",
                description="Known action",
                request_schema=mock_request_class,
                response_schema=mock_response_class,
            )
            def known(self, request: dict) -> dict:
                return {}
        
        assert TestComponent.get_action("unknown") is None
    
    def test_component_get_metadata(self, mock_request_class, mock_response_class):
        """Test getting full component metadata."""
        
        class TestComponent(Component):
            name = "Test Component"
            description = "A test component"
            
            @action(
                name="Test Action",
                description="A test action",
                request_schema=mock_request_class,
                response_schema=mock_response_class,
            )
            def test_action(self, request: dict) -> dict:
                return {}
        
        metadata = TestComponent.get_metadata()
        
        assert isinstance(metadata, ComponentMetadata)
        assert metadata.name == "Test Component"
        assert metadata.description == "A test component"
        assert metadata.component_class == TestComponent
        assert "test_action" in metadata.actions
    
    def test_component_validate_requires_name(self, mock_request_class, mock_response_class):
        """Test that validate() requires a name."""
        
        class NoNameComponent(Component):
            name = ""
            description = "No name"
            
            @action(
                name="Action",
                description="Action",
                request_schema=mock_request_class,
                response_schema=mock_response_class,
            )
            def some_action(self, request: dict) -> dict:
                return {}
        
        with pytest.raises(ComponentError, match="must define a 'name'"):
            NoNameComponent.validate()
    
    def test_component_validate_requires_actions(self):
        """Test that validate() requires at least one action."""
        
        class NoActionsComponent(Component):
            name = "No Actions"
            description = "Has no actions"
        
        with pytest.raises(ComponentError, match="must define at least one @action"):
            NoActionsComponent.validate()
    
    def test_component_inherits_actions(self, mock_request_class, mock_response_class):
        """Test that subclasses inherit actions from parent."""
        
        class BaseComponent(Component):
            name = "Base"
            description = "Base component"
            
            @action(
                name="Base Action",
                description="From base",
                request_schema=mock_request_class,
                response_schema=mock_response_class,
            )
            def base_action(self, request: dict) -> dict:
                return {"from": "base"}
        
        class ChildComponent(BaseComponent):
            name = "Child"
            description = "Child component"
            
            @action(
                name="Child Action",
                description="From child",
                request_schema=mock_request_class,
                response_schema=mock_response_class,
            )
            def child_action(self, request: dict) -> dict:
                return {"from": "child"}
        
        actions = ChildComponent.get_actions()
        
        assert len(actions) == 2
        assert "base_action" in actions
        assert "child_action" in actions
    
    def test_component_non_action_methods_ignored(self, mock_request_class, mock_response_class):
        """Test that non-action methods are not collected."""
        
        class TestComponent(Component):
            name = "Test"
            description = "Test"
            
            @action(
                name="Real Action",
                description="This is an action",
                request_schema=mock_request_class,
                response_schema=mock_response_class,
            )
            def real_action(self, request: dict) -> dict:
                return {}
            
            def helper_method(self):
                """This is not an action."""
                return "helper"
        
        actions = TestComponent.get_actions()
        
        assert len(actions) == 1
        assert "real_action" in actions
        assert "helper_method" not in actions
