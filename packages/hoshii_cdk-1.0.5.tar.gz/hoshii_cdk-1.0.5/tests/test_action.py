"""Tests for the action decorator."""

import pytest

from hoshii_cdk import action, get_action_metadata, is_action
from hoshii_cdk.types import ActionMetadata


class TestActionDecorator:
    """Tests for the @action decorator."""
    
    def test_action_decorator_attaches_metadata(self, mock_request_class, mock_response_class):
        """Test that @action attaches metadata to the method."""
        
        @action(
            name="Test Action",
            description="A test action",
            request_schema=mock_request_class,
            response_schema=mock_response_class,
        )
        def test_method(self, request: dict) -> dict:
            return {"result": "ok"}
        
        metadata = get_action_metadata(test_method)
        
        assert metadata is not None
        assert metadata.name == "Test Action"
        assert metadata.description == "A test action"
        assert metadata.method_name == "test_method"
        assert metadata.request_schema == mock_request_class
        assert metadata.response_schema == mock_response_class
        assert metadata.tags == []
    
    def test_action_decorator_with_tags(self, mock_request_class, mock_response_class):
        """Test that @action accepts tags."""
        
        @action(
            name="Tagged Action",
            description="An action with tags",
            request_schema=mock_request_class,
            response_schema=mock_response_class,
            tags=["read", "items"],
        )
        def tagged_method(self, request: dict) -> dict:
            return {}
        
        metadata = get_action_metadata(tagged_method)
        
        assert metadata.tags == ["read", "items"]
    
    def test_action_decorator_preserves_function(self, mock_request_class, mock_response_class):
        """Test that the decorated function still works."""
        
        @action(
            name="Working Action",
            description="Should still work",
            request_schema=mock_request_class,
            response_schema=mock_response_class,
        )
        def working_method(request: dict) -> dict:
            return {"input": request.get("value", "none")}
        
        result = working_method({"value": "test"})
        assert result == {"input": "test"}
    
    def test_is_action_returns_true_for_decorated(self, mock_request_class, mock_response_class):
        """Test is_action returns True for decorated methods."""
        
        @action(
            name="Test",
            description="Test",
            request_schema=mock_request_class,
            response_schema=mock_response_class,
        )
        def decorated(request: dict) -> dict:
            return {}
        
        assert is_action(decorated) is True
    
    def test_is_action_returns_false_for_undecorated(self):
        """Test is_action returns False for undecorated methods."""
        
        def undecorated(request: dict) -> dict:
            return {}
        
        assert is_action(undecorated) is False
    
    def test_get_action_metadata_returns_none_for_undecorated(self):
        """Test get_action_metadata returns None for undecorated methods."""
        
        def undecorated(request: dict) -> dict:
            return {}
        
        assert get_action_metadata(undecorated) is None
