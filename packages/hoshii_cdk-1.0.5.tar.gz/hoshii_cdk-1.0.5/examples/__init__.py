"""
Example package for Hoshii CDK.

This package demonstrates how to build ERP components using the Hoshii CDK.
"""

from .components import ProductsComponent, PartnersComponent

__all__ = [
    "ProductsComponent",
    "PartnersComponent",
]
