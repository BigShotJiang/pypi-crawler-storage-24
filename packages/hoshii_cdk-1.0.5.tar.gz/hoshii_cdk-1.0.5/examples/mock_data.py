"""
Mock ERP data models for the example.
"""

from dataclasses import dataclass
from typing import Optional


@dataclass
class MockProduct:
    """Mock product data from ERP."""
    id: str
    name: str
    sku: str
    description: str
    price: float
    cost: float
    category: str
    active: bool


@dataclass
class MockAddress:
    """Mock address data."""
    street: str
    city: str
    state: str
    zip: str
    country: str


@dataclass
class MockPartner:
    """Mock partner (customer/supplier) data from ERP."""
    id: str
    name: str
    email: str
    phone: str
    address: MockAddress
    type: str  # "customer" or "supplier"
    active: bool


# Mock database
MOCK_PRODUCTS = [
    MockProduct(
        id="1",
        name="Industrial Pump Assembly",
        sku="PUMP-001",
        description="Heavy-duty centrifugal pump for industrial applications",
        price=2500.00,
        cost=1200.00,
        category="Machinery",
        active=True,
    ),
    MockProduct(
        id="2",
        name="Stainless Steel Valve",
        sku="VALVE-SS-002",
        description="2-inch stainless steel ball valve",
        price=450.00,
        cost=180.00,
        category="Components",
        active=True,
    ),
    MockProduct(
        id="3",
        name="Hydraulic Hose Assembly",
        sku="HOSE-HYD-003",
        description="High-pressure hydraulic hose with fittings",
        price=350.00,
        cost=140.00,
        category="Components",
        active=True,
    ),
    MockProduct(
        id="4",
        name="Electric Motor 5HP",
        sku="MOTOR-5HP-004",
        description="3-phase electric motor, 5 horsepower",
        price=1800.00,
        cost=900.00,
        category="Machinery",
        active=True,
    ),
    MockProduct(
        id="5",
        name="Discontinued Part",
        sku="OLD-PART-005",
        description="This product is no longer available",
        price=0.00,
        cost=0.00,
        category="Obsolete",
        active=False,
    ),
]

MOCK_PARTNERS = [
    MockPartner(
        id="P001",
        name="Acme Manufacturing Inc.",
        email="sales@acme.com",
        phone="+1-555-0101",
        address=MockAddress(
            street="123 Industrial Blvd",
            city="Chicago",
            state="IL",
            zip="60601",
            country="USA",
        ),
        type="customer",
        active=True,
    ),
    MockPartner(
        id="P002",
        name="Global Supply Chain Ltd.",
        email="procurement@globalsupply.com",
        phone="+44-20-7946-0958",
        address=MockAddress(
            street="456 Commerce Street",
            city="London",
            state="England",
            zip="EC1A 1BB",
            country="UK",
        ),
        type="supplier",
        active=True,
    ),
    MockPartner(
        id="P003",
        name="Tech Solutions Europe",
        email="contact@techsol.eu",
        phone="+49-30-12345678",
        address=MockAddress(
            street="789 Tech Park",
            city="Berlin",
            state="Berlin",
            zip="10115",
            country="Germany",
        ),
        type="customer",
        active=True,
    ),
    MockPartner(
        id="P004",
        name="Inactive Partner",
        email="old@inactive.com",
        phone="+1-555-0404",
        address=MockAddress(
            street="999 Old Street",
            city="Nowhere",
            state="XX",
            zip="00000",
            country="USA",
        ),
        type="customer",
        active=False,
    ),
]
