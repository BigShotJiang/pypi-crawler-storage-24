"""
Example ERP component demonstrating the Hoshii CDK.

This component provides actions for managing products and business partners
in an ERP system, similar to what you'd find in SAP, Odoo, or ERPNext.
"""

from dataclasses import dataclass
from hoshii_cdk import Component, action

from .erp_pb2 import (
    ListProductsRequest,
    ListProductsResponse,
    Product,
    GetProductRequest,
    GetProductResponse,
    ListPartnersRequest,
    ListPartnersResponse,
    Partner,
    Address,
    GetPartnerRequest,
    GetPartnerResponse,
)
from .mock_data import MOCK_PRODUCTS, MOCK_PARTNERS


@dataclass
class ProductsComponentProperties:
    """Configuration properties for the Products component."""
    api_key: str = ""
    """API key for authentication"""
    
    base_url: str = "https://api.example.com"
    """Base URL for the ERP API"""
    
    timeout: int = 30
    """Request timeout in seconds"""


@dataclass
class PartnersComponentProperties:
    """Configuration properties for the Partners component."""
    api_key: str = ""
    """API key for authentication"""
    
    base_url: str = "https://api.example.com"
    """Base URL for the ERP API"""
    
    include_inactive: bool = False
    """Whether to include inactive partners in results"""


class ProductsComponent(Component):
    """Component for managing products/items in the ERP."""
    
    name = "Products"
    description = "Manage products and inventory items"
    
    # Component properties
    api_key: str = ""
    base_url: str = "https://api.example.com"
    timeout: int = 30
    
    @action(
        name="List Products",
        description="List all products with optional filtering and pagination",
        request_schema=ListProductsRequest,
        response_schema=ListProductsResponse,
        tags=["products", "list"],
        visible_parameters=["activeOnly"],  # Show filter option in UI, hide pagination params
    )
    def list_products(self, request: dict) -> dict:
        """List products from the ERP system."""
        page_size = request.get("page_size", 10)
        cursor = request.get("cursor", "0")
        active_only = request.get("active_only", False)
        
        # Filter products
        products = MOCK_PRODUCTS
        if active_only:
            products = [p for p in products if p.active]
        
        # Parse cursor
        try:
            start_idx = int(cursor)
        except (ValueError, TypeError):
            start_idx = 0
        
        # Paginate
        end_idx = start_idx + page_size
        paginated = products[start_idx:end_idx]
        
        # Convert to dict format
        products_data = []
        for p in paginated:
            products_data.append({
                "id": p.id,
                "name": p.name,
                "sku": p.sku,
                "description": p.description,
                "price": p.price,
                "cost": p.cost,
                "category": p.category,
                "active": p.active,
            })
        
        # Determine next cursor
        next_cursor = None
        if end_idx < len(products):
            next_cursor = str(end_idx)
        
        return {
            "products": products_data,
            "next_cursor": next_cursor,
            "total_count": len(products),
        }
    
    @action(
        name="Get Product",
        description="Get a single product by ID",
        request_schema=GetProductRequest,
        response_schema=GetProductResponse,
        tags=["products", "get"],
        visible_parameters=["id"],  # ID is the only parameter, show it
    )
    def get_product(self, request: dict) -> dict:
        """Get a single product by ID."""
        product_id = request.get("id")
        
        if not product_id:
            raise ValueError("Product ID is required")
        
        # Find product
        product = None
        for p in MOCK_PRODUCTS:
            if p.id == product_id:
                product = p
                break
        
        if not product:
            raise ValueError(f"Product with ID '{product_id}' not found")
        
        return {
            "product": {
                "id": product.id,
                "name": product.name,
                "sku": product.sku,
                "description": product.description,
                "price": product.price,
                "cost": product.cost,
                "category": product.category,
                "active": product.active,
            }
        }


class PartnersComponent(Component):
    """Component for managing business partners (customers and suppliers)."""
    
    name = "Partners"
    description = "Manage business partners (customers and suppliers)"
    
    # Component properties
    api_key: str = ""
    base_url: str = "https://api.example.com"
    include_inactive: bool = False
    
    @action(
        name="List Partners",
        description="List all business partners with optional filtering",
        request_schema=ListPartnersRequest,
        response_schema=ListPartnersResponse,
        tags=["partners", "list"],
        visible_parameters=["type"],  # Show partner type filter in UI
    )
    def list_partners(self, request: dict) -> dict:
        """List partners from the ERP system."""
        page_size = request.get("page_size", 10)
        cursor = request.get("cursor", "0")
        partner_type = request.get("type", "both")  # "customer", "supplier", or "both"
        
        # Filter partners
        partners = MOCK_PARTNERS
        if partner_type != "both":
            partners = [p for p in partners if p.type == partner_type]
        
        # Apply component property for inactive partners
        if not self.include_inactive:
            partners = [p for p in partners if p.active]
        
        # Parse cursor
        try:
            start_idx = int(cursor)
        except (ValueError, TypeError):
            start_idx = 0
        
        # Paginate
        end_idx = start_idx + page_size
        paginated = partners[start_idx:end_idx]
        
        # Convert to dict format
        partners_data = []
        for p in paginated:
            partners_data.append({
                "id": p.id,
                "name": p.name,
                "email": p.email,
                "phone": p.phone,
                "address": {
                    "street": p.address.street,
                    "city": p.address.city,
                    "state": p.address.state,
                    "zip": p.address.zip,
                    "country": p.address.country,
                },
                "type": p.type,
                "active": p.active,
            })
        
        # Determine next cursor
        next_cursor = None
        if end_idx < len(partners):
            next_cursor = str(end_idx)
        
        return {
            "partners": partners_data,
            "next_cursor": next_cursor,
            "total_count": len(partners),
        }
    
    @action(
        name="Get Partner",
        description="Get a single partner by ID",
        request_schema=GetPartnerRequest,
        response_schema=GetPartnerResponse,
        tags=["partners", "get"],
        visible_parameters=["id"],  # ID is the only parameter, show it
    )
    def get_partner(self, request: dict) -> dict:
        """Get a single partner by ID."""
        partner_id = request.get("id")
        
        if not partner_id:
            raise ValueError("Partner ID is required")
        
        # Find partner
        partner = None
        for p in MOCK_PARTNERS:
            if p.id == partner_id:
                partner = p
                break
        
        if not partner:
            raise ValueError(f"Partner with ID '{partner_id}' not found")
        
        return {
            "partner": {
                "id": partner.id,
                "name": partner.name,
                "email": partner.email,
                "phone": partner.phone,
                "address": {
                    "street": partner.address.street,
                    "city": partner.address.city,
                    "state": partner.address.state,
                    "zip": partner.address.zip,
                    "country": partner.address.country,
                },
                "type": partner.type,
                "active": partner.active,
            }
        }
