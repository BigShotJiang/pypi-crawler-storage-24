#!/usr/bin/env python3
"""
Example script demonstrating manifest generation and component execution.

This script shows how to:
1. Generate a manifest from components
2. Load the manifest with ComponentRunner
3. Execute actions from the manifest
"""

import json
import sys
from pathlib import Path

# Add parent directory to path so we can import hoshii_cdk and examples
sys.path.insert(0, str(Path(__file__).parent.parent / "src"))
sys.path.insert(0, str(Path(__file__).parent.parent))

from hoshii_cdk import Registry, generate_manifest, ComponentRunner


def main():
    print("=" * 70)
    print("Hoshii CDK Example: ERP Component")
    print("=" * 70)
    
    # Step 1: Generate manifest
    print("\n[1] Generating manifest from components...")
    registry = Registry()
    registry.discover("examples")
    
    manifest_path = Path(__file__).parent / "manifest.json"
    generate_manifest(registry, manifest_path)
    
    # Step 2: Load manifest with ComponentRunner
    print("\n[2] Loading manifest with ComponentRunner...")
    runner = ComponentRunner(manifest_path, "examples")
    runner.import_components()
    
    # Step 3: Set component properties
    print("\n[3] Setting component properties...")
    runner.set_properties("Partners", {"include_inactive": True})
    print("  Partners.include_inactive = True")
    runner.set_properties("Products", {"timeout": 60})
    print("  Products.timeout = 60")
    
    # Verify properties were set
    partners_props = runner.get_properties("Partners")
    print(f"  Partners properties: {partners_props}")
    
    # Step 4: List available components and actions
    print("\n[4] Available components and actions:")
    for component_name in runner.list_components():
        actions = runner.list_actions(component_name)
        print(f"\n  {component_name}:")
        for action_name in actions:
            print(f"    - {action_name}")
    
    # Step 5: Execute some actions
    print("\n[5] Executing actions...")
    
    # List products
    print("\n  Listing products (first 2):")
    result = runner.invoke("Products", "list_products", {"page_size": 2})
    for product in result["products"]:
        print(f"    - {product['name']} (SKU: {product['sku']}, Price: ${product['price']})")
    
    # Get a specific product
    print("\n  Getting product with ID '1':")
    result = runner.invoke("Products", "get_product", {"id": "1"})
    product = result["product"]
    print(f"    Name: {product['name']}")
    print(f"    SKU: {product['sku']}")
    print(f"    Price: ${product['price']}")
    print(f"    Cost: ${product['cost']}")
    print(f"    Category: {product['category']}")
    
    # List partners
    print("\n  Listing partners (customers only, first 2):")
    result = runner.invoke("Partners", "list_partners", {
        "page_size": 2,
        "type": "customer"
    })
    for partner in result["partners"]:
        print(f"    - {partner['name']} ({partner['email']})")
    
    # Get a specific partner
    print("\n  Getting partner with ID 'P001':")
    result = runner.invoke("Partners", "get_partner", {"id": "P001"})
    partner = result["partner"]
    print(f"    Name: {partner['name']}")
    print(f"    Email: {partner['email']}")
    print(f"    Phone: {partner['phone']}")
    print(f"    Address: {partner['address']['street']}, {partner['address']['city']}")
    
    print("\n" + "=" * 70)
    print("Example completed successfully!")
    print("=" * 70)


if __name__ == "__main__":
    main()
