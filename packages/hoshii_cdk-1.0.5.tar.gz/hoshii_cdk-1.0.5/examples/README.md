# Examples

This directory contains example components demonstrating the Hoshii CDK.

## ERP Component Example

The example shows how to build an ERP connector with two components:
- **ProductsComponent**: Manage products/items
- **PartnersComponent**: Manage business partners (customers and suppliers)

### Files

- `erp_pb2.py`: Mock Protobuf message definitions (simulates generated proto files)
- `mock_data.py`: Mock ERP data (products and partners)
- `components.py`: Component implementations with actions
- `run_example.py`: Example script demonstrating manifest generation and execution

### Running the Example

1. Generate the manifest and execute actions:

```bash
cd /path/to/hoshii-cdk-python
python examples/run_example.py
```

This will:
1. Discover components in the `examples` package
2. Generate a `manifest.json` file
3. Load the manifest with `ComponentRunner`
4. Execute various actions (list products, get product, list partners, get partner)

### Generated Manifest

The `manifest.json` file contains all component and action metadata with full JSON schemas:

```json
{
  "version": "1.0",
  "components": {
    "Products": {
      "name": "Products",
      "description": "Manage products and inventory items",
      "actions": {
        "list_products": {
          "name": "List Products",
          "description": "List all products with optional filtering and pagination",
          "tags": ["products", "list"],
          "request_schema": {...},
          "response_schema": {...}
        },
        ...
      }
    },
    ...
  }
}
```

### Using ComponentRunner

The `ComponentRunner` class allows you to:
- Load a manifest from a JSON file
- Import components from a Python module
- List available components and actions
- Get schemas for actions
- Invoke actions by name

This is useful for sandboxed environments (like e2b) where you want to execute components without importing the full codebase.

```python
from hoshii_cdk import ComponentRunner

runner = ComponentRunner("manifest.json", "examples")
runner.import_components()

# List components
components = runner.list_components()

# Get actions for a component
actions = runner.list_actions("Products")

# Get schema for an action
schema = runner.get_action_schema("Products", "list_products")

# Invoke an action
result = runner.invoke("Products", "list_products", {"page_size": 10})
```
