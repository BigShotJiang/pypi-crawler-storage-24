"""
DPoP Broker Auth — agent-side authentication package.

Provides ES256 key management, broker registration, and DPoP proof creation.
"""

from broker_auth.client import BrokerAuthClient

__all__ = ["BrokerAuthClient"]
