# dpop-broker-auth

Agent-side ES256 key enrollment and DPoP proof-of-possession (RFC 9449) for MCP broker authentication.

## Install

```bash
pip install dpop-broker-auth
```

## Usage

```python
from broker_auth import BrokerAuthClient

client = BrokerAuthClient(
    "https://your-broker.example.com",
    "<gateway-token>",
    keystore_path="broker_keypair.json",
)

# One-time enrollment
if not client.is_enrolled:
    client.enroll()

# All requests include DPoP proof automatically
response = client.make_request("POST", "https://your-broker.example.com/api/v1/mcp/invoke/", json={...})
```
