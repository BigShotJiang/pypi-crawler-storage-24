"""NPC-related catalog data."""
