"""Tool catalog and registry."""
