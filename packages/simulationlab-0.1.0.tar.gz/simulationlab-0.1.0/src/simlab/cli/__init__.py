"""Simlab CLI."""
