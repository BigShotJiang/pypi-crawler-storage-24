from importlib.metadata import version, PackageNotFoundError

try:
    __version__ = version("apk-analyzer")
except PackageNotFoundError:
    __version__ = "1.12.2"
