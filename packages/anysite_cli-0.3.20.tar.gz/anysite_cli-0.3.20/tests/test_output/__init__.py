"""Output tests."""
