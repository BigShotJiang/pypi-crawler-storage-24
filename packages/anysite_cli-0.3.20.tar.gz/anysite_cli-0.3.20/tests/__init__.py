"""Tests for anysite-cli."""
