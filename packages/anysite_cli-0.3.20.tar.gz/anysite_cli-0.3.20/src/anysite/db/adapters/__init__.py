"""Database adapters."""
