"""Streaming output modules."""
