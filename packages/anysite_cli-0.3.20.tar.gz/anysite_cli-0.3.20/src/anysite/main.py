"""Main CLI application."""

import json
from typing import Annotated, Any

import typer
from rich.console import Console
from rich.markup import escape as rich_escape

from anysite import __app_name__, __version__
from anysite.cli import config as config_cli

LOGO = (
    "                        __ __\n"
    "  ____ _____  __  __  _/_//_/\n"
    " / __ `/ __ \\/ / / /_/_//_/\n"
    "/ /_/ / / / / /_/ //_//_/\n"
    "\\__,_/_/ /_/\\__, /_//_/\n"
    "           /____/"
)

# Build epilog: only show install hints for missing extras
_missing: list[str] = []
try:
    import duckdb  # noqa: F401
    import pyarrow  # noqa: F401
except ImportError:
    _missing.append('  dataset   pip install "anysite-cli\\[data]"')
try:
    import openai  # noqa: F401
except ImportError:
    _missing.append('  llm       pip install "anysite-cli\\[llm]"')
try:
    import psycopg  # noqa: F401
except ImportError:
    _missing.append('  postgres  pip install "anysite-cli\\[postgres]"')

# Create main app
app = typer.Typer(
    name=__app_name__,
    help="Web data extraction for humans and AI agents",
    no_args_is_help=False,
    invoke_without_command=True,
    rich_markup_mode="rich",
    epilog=(
        "Install extras for full access:\n" + "\n".join(_missing)
        if _missing
        else None
    ),
)

# Add subcommands
app.add_typer(config_cli.app, name="config", help="Manage configuration")

# Global state for CLI options
state: dict[str, str | bool | None] = {
    "api_key": None,
    "base_url": None,
    "debug": False,
    "non_interactive": False,
    "human": False,
}


def version_callback(value: bool) -> None:
    """Print version and exit."""
    if value:
        console = Console()
        console.print(f"{__app_name__} version: [bold]{__version__}[/bold]")
        raise typer.Exit()


def _logo_callback(value: bool) -> None:
    """Print ASCII art logo + help and exit."""
    if value:
        import click
        from rich.align import Align
        from rich.text import Text

        ctx = click.get_current_context()
        console = Console()
        lines = LOGO.split("\n")
        max_w = max(len(l) for l in lines)
        pad = max(0, (console.width - max_w) // 2)
        centered = "\n".join(" " * pad + l for l in lines)
        console.print()
        console.print(Text(centered, style="bold"))
        console.print(Align.center(f"v{__version__}"), style="dim")
        console.print()
        console.print(ctx.get_help())
        raise typer.Exit()


@app.callback(invoke_without_command=True)
def main(
    ctx: typer.Context,
    api_key: Annotated[
        str | None,
        typer.Option(
            "--api-key",
            envvar="ANYSITE_API_KEY",
            help="API key (or set ANYSITE_API_KEY)",
        ),
    ] = None,
    base_url: Annotated[
        str | None,
        typer.Option(
            "--base-url",
            envvar="ANYSITE_BASE_URL",
            help="API base URL",
        ),
    ] = None,
    debug: Annotated[
        bool,
        typer.Option(
            "--debug",
            help="Enable debug output",
        ),
    ] = False,
    no_color: Annotated[
        bool,
        typer.Option(
            "--no-color",
            help="Disable colored output",
        ),
    ] = False,
    non_interactive: Annotated[
        bool,
        typer.Option(
            "--non-interactive",
            help="Disable interactive prompts (fail fast instead of waiting for input)",
        ),
    ] = False,
    human: Annotated[
        bool,
        typer.Option(
            "--human",
            help="Force human-readable output (override auto-JSON in pipes)",
        ),
    ] = False,
    version: Annotated[
        bool | None,
        typer.Option(
            "--version",
            "-v",
            callback=version_callback,
            is_eager=True,
            help="Show version and exit",
        ),
    ] = None,
    logo: Annotated[
        bool | None,
        typer.Option(
            "--logo",
            callback=_logo_callback,
            is_eager=True,
            hidden=True,
        ),
    ] = None,
) -> None:
    """Web data extraction for humans and AI agents."""
    import sys as _sys

    # Store global options
    state["api_key"] = api_key
    state["base_url"] = base_url
    state["debug"] = debug
    state["non_interactive"] = non_interactive or not _sys.stdin.isatty()
    state["human"] = human

    if no_color:
        import os

        os.environ["NO_COLOR"] = "1"

    # No subcommand → discovery JSON (agent) or help text (human)
    if ctx.invoked_subcommand is None:
        is_real_pipe = False
        if not human:
            try:
                _sys.stdout.fileno()
                is_real_pipe = not _sys.stdout.isatty()
            except (AttributeError, OSError):
                pass
        if is_real_pipe:
            from anysite.cli.discovery import build_discovery_payload

            typer.echo(json.dumps(build_discovery_payload(ctx), indent=2))
        else:
            typer.echo(ctx.get_help())
        raise typer.Exit(0)


@app.command("describe")
def describe(
    command: Annotated[
        str | None,
        typer.Argument(help="Endpoint to describe (e.g., 'linkedin.user', '/api/linkedin/user')"),
    ] = None,
    search: Annotated[
        str | None,
        typer.Option("--search", "-s", help="Search endpoints by keyword"),
    ] = None,
    json_output: Annotated[
        bool,
        typer.Option("--json", help="Output as JSON (for agents)"),
    ] = False,
    quiet: Annotated[
        bool,
        typer.Option("--quiet", "-q", help="Minimal output (paths only)"),
    ] = False,
) -> None:
    """Describe API endpoints — input params, output fields, search.

    Reads from a local cache (run `anysite schema update` first).
    Shows all endpoints from the API, not just those with CLI commands.

    \b
    Examples:
      anysite describe                          # list all endpoints
      anysite describe linkedin.user            # input + output for endpoint
      anysite describe /api/linkedin/user       # full path also works
      anysite describe --search "company"       # search by keyword
      anysite describe --json -q                # JSON list for agents
    """
    import json as json_mod

    # Level 2 discovery when no args in pipe mode (no explicit --json)
    if command is None and search is None and not json_output:
        import click

        from anysite.cli.discovery import build_single_command_detail, is_pipe_mode

        if is_pipe_mode():
            click_cmd = click.get_current_context().command
            typer.echo(json_mod.dumps(build_single_command_detail("describe", click_cmd), indent=2))
            raise typer.Exit(0)

    from anysite.api.schemas import get_schema, list_endpoints
    from anysite.cli.json_output import resolve_json_output

    json_output = resolve_json_output(json_output)

    # Search mode
    if search is not None:
        from anysite.api.graph import search_graph

        result = search_graph(search)
        if not result["matches"]:
            typer.echo(f"No endpoints matching '{search}'", err=True)
            typer.echo("Run 'anysite schema update' if cache is empty.", err=True)
            raise typer.Exit(1)
        if json_output:
            from anysite.cli.json_output import json_response

            json_response(
                result,
                hints=[
                    ("View endpoint detail", f"anysite describe {result['matches'][0]['path']}"),
                    ("Make an API call", f"anysite api {result['matches'][0]['path']}"),
                ],
                command=f"anysite describe --search {search!r}",
            )
        else:
            console = Console()
            matches = result["matches"]
            console.print(f"\n[bold]Endpoints matching '{search}' ({len(matches)} matches):[/bold]\n")
            for m in matches:
                cost_str = f"  [dim]\\[{m['cost']}][/dim]" if m.get("cost") else ""
                console.print(f"  POST {m['path']}{cost_str}")
                desc = m.get("description", "")
                if desc:
                    console.print(f"       [dim]{desc}[/dim]")
                req_inputs = [i for i in m.get("inputs", []) if i.get("required")]
                for inp in req_inputs:
                    id_tag = f" ({inp['id_type']})" if inp.get("id_type") else ""
                    console.print(f"       needs: {inp['name']}{id_tag}")
                if m.get("produces"):
                    console.print(f"       produces: {', '.join(m['produces'])}")

            upstream = result.get("upstream", [])
            if upstream:
                console.print(f"\n[bold]UPSTREAM[/bold] — provides data for matched endpoints ({len(upstream)}):")
                for up in upstream:
                    console.print(f"  {up['path']}")
                    for prov in up.get("provides", []):
                        console.print(f"    [dim]-> provides {prov['id_type']} for {prov['for']}[/dim]")

            downstream = result.get("downstream", [])
            if downstream:
                console.print(f"\n[bold]DOWNSTREAM[/bold] — enabled by matched endpoints ({len(downstream)}):")
                for down in downstream:
                    console.print(f"  {down['path']}")
                    for recv in down.get("receives", []):
                        console.print(f"    [dim]<- receives {recv['id_type']} from {recv['from']}[/dim]")
            console.print()
        return

    # List all endpoints
    if command is None:
        endpoints = list_endpoints()
        if not endpoints:
            typer.echo("No cached schema. Run: anysite schema update", err=True)
            raise typer.Exit(1)
        if json_output:
            if quiet:
                typer.echo(json_mod.dumps([e["path"] for e in endpoints]))
            else:
                typer.echo(json_mod.dumps(endpoints))
        else:
            console = Console()
            console.print(f"[bold]Available endpoints ({len(endpoints)}):[/bold]\n")
            for ep in endpoints:
                if quiet:
                    console.print(f"  {ep['path']}")
                else:
                    console.print(f"  {ep['path']:<45} [dim]{ep['description']}[/dim]")
            console.print("\n[dim]Use 'anysite describe <endpoint>' for details[/dim]")
        return

    # Describe a specific endpoint
    schema = get_schema(command)
    if schema is None:
        typer.echo(f"Unknown endpoint: {command}", err=True)
        typer.echo("Run 'anysite schema update' to refresh the cache.", err=True)
        raise typer.Exit(1)

    from anysite.api.schemas import compact_output

    compact = compact_output(schema.get("output", {}))

    # Load graph connections (silently omit if unavailable)
    from anysite.api.graph import get_endpoint_connections
    from anysite.api.schemas import _normalize_command

    endpoint_path = _normalize_command(command)
    connections = get_endpoint_connections(endpoint_path)

    if json_output:
        result: dict[str, Any] = {"input": schema["input"], "output": compact}
        if connections:
            result["upstream"] = connections["upstream"]
            result["downstream"] = connections["downstream"]
        typer.echo(json_mod.dumps(result))
    else:
        console = Console()
        desc = schema.get("description", "")
        console.print(f"[bold]{command}[/bold]")
        if desc:
            console.print(f"  {desc}\n")

        input_params = schema.get("input", {})
        if input_params:
            console.print("[bold]Input parameters:[/bold]")
            for name, info in input_params.items():
                req = "[red]*[/red]" if info.get("required") else " "
                desc = info.get("description", "")
                desc_part = f"  [dim italic]{desc}[/dim italic]" if desc else ""
                type_str = info.get("type", "string")
                type_display = rich_escape(type_str)
                console.print(f"  {req} {name:<30} [dim]{type_display}[/dim]{desc_part}")
                # Show examples and defaults on next line
                hints = []
                if "examples" in info:
                    ex = info["examples"][0] if info["examples"] else None
                    if ex is not None:
                        hints.append(f"example: {json.dumps(ex, default=str)}")
                if "default" in info and info["default"] is not None:
                    hints.append(f"default: {info['default']}")
                if hints:
                    console.print(f"    {'':30} [dim]{', '.join(str(h) for h in hints)}[/dim]")
            console.print()

        if compact:
            console.print(f"[bold]Output fields ({len(compact)}):[/bold]")
            for name, ftype in compact.items():
                ftype_display = rich_escape(ftype)
                console.print(f"    {name:<30} [dim]{ftype_display}[/dim]")

        if connections:
            upstream = connections.get("upstream", [])
            downstream = connections.get("downstream", [])
            if upstream or downstream:
                console.print("\n[bold]Connections:[/bold]")
            if upstream:
                console.print("  [bold]Upstream[/bold] — provides data for this endpoint:")
                for up in upstream:
                    for prov in up.get("provides", []):
                        console.print(f"    {up['path']}  [dim]provides {prov['id_type']} via {prov['via_field']}[/dim]")
            if downstream:
                console.print("  [bold]Downstream[/bold] — enabled by this endpoint:")
                for down in downstream:
                    for recv in down.get("receives", []):
                        console.print(f"    {down['path']}  [dim]receives {recv['id_type']} via {recv['via_field']}[/dim]")


# Schema management subcommand
schema_app = typer.Typer(help="Manage API schema cache", invoke_without_command=True)
app.add_typer(schema_app, name="schema")


@schema_app.callback(invoke_without_command=True)
def schema_callback(ctx: typer.Context) -> None:
    """Manage API schema cache."""
    if ctx.invoked_subcommand is None:
        import json as _json

        from anysite.cli.discovery import build_command_detail, is_pipe_mode

        if is_pipe_mode():
            typer.echo(_json.dumps(build_command_detail("schema", ctx), indent=2))
            raise typer.Exit(0)
        typer.echo(ctx.get_help())
        raise typer.Exit(0)


@schema_app.command("update")
def schema_update(
    json_output: Annotated[
        bool,
        typer.Option("--json", help="Output as machine-readable JSON"),
    ] = False,
) -> None:
    """Fetch OpenAPI spec and update local schema cache.

    Downloads the API specification, resolves all references,
    and saves a compact cache to ~/.anysite/schema.json.

    \b
    Examples:
      anysite schema update
      anysite schema update --json
    """
    from anysite.api.schemas import (
        OPENAPI_URL,
        fetch_raw_openapi_spec,
        parse_openapi_spec,
        save_cache,
    )
    from anysite.cli.json_output import resolve_json_output

    json_output = resolve_json_output(json_output)

    console = Console()
    if not json_output:
        console.print(f"Fetching OpenAPI spec from {OPENAPI_URL}...")

    try:
        raw_spec = fetch_raw_openapi_spec()
    except Exception as e:
        if json_output:
            from anysite.cli.json_output import json_error

            json_error("SCHEMA_FETCH_ERROR", str(e), retryable=True)
        console.print(f"[red]Error fetching spec:[/red] {e}")
        raise typer.Exit(1) from e

    # Build schema cache
    data = parse_openapi_spec(raw_spec)
    cache_path = save_cache(data)
    count = len(data.get("endpoints", {}))

    # Build and save dependency graph
    from anysite.api.graph import build_graph, save_graph_cache

    graph = build_graph(raw_spec)
    graph_path = save_graph_cache(graph)
    node_count = len(graph.get("nodes", {}))
    edge_count = len(graph.get("edges", []))

    hints = [
        ("List all endpoints", "anysite describe"),
        ("Search with dependencies", 'anysite describe --search "<keyword>"'),
        ("View endpoint detail", "anysite describe /api/linkedin/user"),
        ("Make an API call", "anysite api /api/linkedin/user user=satyanadella"),
    ]

    if json_output:
        from anysite.cli.json_output import json_response

        json_response(
            {
                "endpoints": count,
                "cache_path": str(cache_path),
                "graph": {
                    "nodes": node_count,
                    "edges": edge_count,
                    "cache_path": str(graph_path),
                },
            },
            hints=hints,
            command="anysite schema update",
        )
        return

    console.print(f"[green]✓[/green] Cached {count} endpoints to {cache_path}")
    console.print(f"[green]✓[/green] Built dependency graph: {node_count} nodes, {edge_count} edges")

    from anysite.cli.json_output import print_hints

    print_hints(hints)


@app.command(
    "api",
    context_settings={"allow_extra_args": True, "allow_interspersed_args": True},
)
def api_call(
    ctx: typer.Context,
    endpoint: Annotated[
        str | None,
        typer.Argument(help="API endpoint path (e.g., /api/linkedin/user)"),
    ] = None,
    # Output options
    format: Annotated[
        str,
        typer.Option("--format", "-f", help="Output format (json/jsonl/csv/table)"),
    ] = "json",
    fields: Annotated[
        str | None,
        typer.Option("--fields", help="Comma-separated fields to include"),
    ] = None,
    output: Annotated[
        str | None,
        typer.Option("--output", "-o", help="Save output to file"),
    ] = None,
    quiet: Annotated[
        bool,
        typer.Option("--quiet", "-q", help="Suppress non-data output"),
    ] = False,
    exclude: Annotated[
        str | None,
        typer.Option("--exclude", help="Comma-separated fields to exclude"),
    ] = None,
    compact: Annotated[
        bool,
        typer.Option("--compact", help="Compact output (no indentation)"),
    ] = False,
    # Batch options
    from_file: Annotated[
        str | None,
        typer.Option("--from-file", help="Read inputs from file"),
    ] = None,
    stdin: Annotated[
        bool,
        typer.Option("--stdin", help="Read inputs from stdin"),
    ] = False,
    parallel: Annotated[
        int,
        typer.Option("--parallel", "-j", help="Number of parallel requests"),
    ] = 1,
    delay: Annotated[
        float,
        typer.Option("--delay", help="Delay between requests in seconds"),
    ] = 0.0,
    on_error: Annotated[
        str,
        typer.Option("--on-error", help="Error handling: stop, skip, retry"),
    ] = "stop",
    rate_limit: Annotated[
        str | None,
        typer.Option("--rate-limit", help="Rate limit (e.g., '10/s', '100/m')"),
    ] = None,
    input_key: Annotated[
        str | None,
        typer.Option("--input-key", help="Parameter name to iterate over in batch mode"),
    ] = None,
    # Feedback
    progress: Annotated[
        bool | None,
        typer.Option("--progress/--no-progress", help="Show progress bar"),
    ] = None,
    stats: Annotated[
        bool,
        typer.Option("--stats", help="Show statistics after completion"),
    ] = False,
    verbose: Annotated[
        bool,
        typer.Option("--verbose", help="Verbose output"),
    ] = False,
    append: Annotated[
        bool,
        typer.Option("--append", help="Append to existing output file"),
    ] = False,
) -> None:
    """Call any API endpoint directly with key=value parameters.

    Pass parameters as key=value pairs after the endpoint path.
    Types are auto-converted using the schema cache.

    \b
    Examples:
      anysite api /api/linkedin/user user=satyanadella
      anysite api /api/linkedin/search/users title=CTO count=100 --format csv
      anysite api /api/reddit/user user=spez --format table
      anysite api /api/linkedin/user --from-file users.txt --input-key user --parallel 5
    """
    # Level 2 discovery when no endpoint in pipe mode
    if endpoint is None:
        from anysite.cli.discovery import build_single_command_detail, is_pipe_mode

        if is_pipe_mode():
            click_cmd = ctx.command
            typer.echo(json.dumps(build_single_command_detail("api", click_cmd), indent=2))
            raise typer.Exit(0)
        typer.echo(ctx.get_help())
        raise typer.Exit(0)

    from pathlib import Path

    from anysite.api.schemas import convert_value, get_schema, get_urn_prefix, normalize_urn_value
    from anysite.cli.executor import run_search_command, run_single_command
    from anysite.cli.options import ErrorHandling as EH
    from anysite.output.formatters import OutputFormat

    # Validate endpoint format
    if not endpoint.startswith("/"):
        typer.echo(
            f"Error: endpoint must start with '/' (e.g., /api/linkedin/user), got: {endpoint}",
            err=True,
        )
        raise typer.Exit(1)

    # Parse key=value args from ctx.args
    raw_params: dict[str, str] = {}
    for arg in ctx.args:
        if "=" not in arg:
            typer.echo(f"Error: invalid parameter '{arg}', expected key=value format", err=True)
            raise typer.Exit(1)
        key, _, value = arg.partition("=")
        raw_params[key] = value

    # Convert types using schema if available
    schema = get_schema(endpoint)
    payload: dict[str, str | int | bool | float | list | dict] = {}
    if schema and schema.get("input"):
        input_schema = schema["input"]
        for key, value in raw_params.items():
            if key in input_schema:
                type_hint = input_schema[key].get("type", "string")
                try:
                    typed_val = convert_value(value, type_hint)
                except (ValueError, TypeError):
                    typed_val = value
                # Auto-normalize URN values
                if isinstance(typed_val, str):
                    prefix = get_urn_prefix(endpoint, key)
                    if prefix:
                        typed_val = normalize_urn_value(typed_val, prefix)
                payload[key] = typed_val
            else:
                payload[key] = value
    else:
        # No schema — pass as strings, try auto-converting obvious types
        for key, value in raw_params.items():
            if value.isdigit():
                payload[key] = int(value)
            elif value.lower() in ("true", "false"):
                payload[key] = value.lower() == "true"
            elif value.startswith("[") or value.startswith("{"):
                # Try to parse JSON arrays/objects
                try:
                    payload[key] = json.loads(value)
                except json.JSONDecodeError:
                    payload[key] = value
            else:
                payload[key] = value

    # Resolve format enum
    try:
        fmt = OutputFormat(format.lower())
    except ValueError:
        typer.echo(f"Error: invalid format '{format}', use json/jsonl/csv/table/parquet", err=True)
        raise typer.Exit(1) from None

    # Resolve error handling enum
    try:
        err_handling = EH(on_error.lower())
    except ValueError:
        typer.echo(f"Error: invalid on-error '{on_error}', use stop/skip/retry", err=True)
        raise typer.Exit(1) from None

    output_path = Path(output) if output else None
    from_file_path = Path(from_file) if from_file else None

    is_batch = from_file_path is not None or stdin

    if is_batch:
        if not input_key and not from_file_path:
            typer.echo(
                "Error: --input-key is required for batch mode with plain text input",
                err=True,
            )
            raise typer.Exit(1)

        run_single_command(
            endpoint,
            payload,
            format=fmt,
            fields=fields,
            output=output_path,
            quiet=quiet,
            exclude=exclude,
            compact=compact,
            from_file=from_file_path,
            stdin=stdin,
            parallel=parallel,
            delay=delay,
            on_error=err_handling,
            rate_limit=rate_limit,
            progress=progress,
            stats=stats,
            verbose=verbose,
            append=append,
            input_key=input_key or "user",
            extra_payload=dict(payload),
        )
    else:
        run_search_command(
            endpoint,
            dict(payload),
            format=fmt,
            fields=fields,
            output=output_path,
            quiet=quiet,
            exclude=exclude,
            compact=compact,
            stream=False,
            progress=progress,
            stats=stats,
            verbose=verbose,
            append=append,
        )


@app.command("changelog")
def changelog_cmd(
    since: Annotated[
        str | None,
        typer.Option("--since", help="Show changes since this version (exclusive)"),
    ] = None,
    json_output: Annotated[
        bool,
        typer.Option("--json", help="Output as JSON (for agents)"),
    ] = False,
    last: Annotated[
        int,
        typer.Option("--last", "-n", help="Show only the last N releases"),
    ] = 0,
) -> None:
    """Show what changed in recent releases.

    Agents can use this after upgrading to discover new features.

    \b
    Examples:
      anysite changelog                    # all releases, human-readable
      anysite changelog --json             # all releases, JSON for agents
      anysite changelog --since 0.3.15     # changes after 0.3.15
      anysite changelog --last 1 --json    # latest release only
    """
    from anysite.changelog import get_changelog_since
    from anysite.cli.json_output import resolve_json_output

    json_output = resolve_json_output(json_output)

    entries = get_changelog_since(since)
    if last > 0:
        entries = entries[:last]

    if json_output:
        from anysite.cli.json_output import json_response

        json_response(
            {"releases": [e.to_dict() for e in entries]},
            hints=[
                ("Full guide", "anysite dataset guide"),
                ("Validate config", "anysite dataset validate dataset.yaml"),
            ],
            command="anysite changelog",
        )
        return

    console = Console()
    if not entries:
        console.print("[dim]No changelog entries found.[/dim]")
        raise typer.Exit(0)

    for entry in entries:
        console.print(f"\n[bold]v{entry.version}[/bold]  [dim]({entry.date})[/dim]")
        for change in entry.changes:
            cat_style = {
                "added": "green",
                "changed": "yellow",
                "fixed": "cyan",
                "removed": "red",
            }.get(change.category, "white")
            console.print(f"  [{cat_style}]{change.category}[/{cat_style}]  {change.summary}")
            if change.detail:
                console.print(f"         [dim]{change.detail}[/dim]")
    console.print()


def get_api_key() -> str | None:
    """Get API key with priority: CLI flag > env var > OAuth token > config file."""
    # 1. CLI --api-key flag
    if state["api_key"]:
        return str(state["api_key"])

    # 2. ANYSITE_API_KEY env var
    import os

    env_key = os.environ.get("ANYSITE_API_KEY")
    if env_key:
        return env_key

    # 3. OAuth token (from anysite auth login)
    from anysite.auth import get_oauth_token

    oauth_token = get_oauth_token()
    if oauth_token:
        return oauth_token

    # 4. Config file api_key
    from anysite.config import get_settings

    return get_settings().api_key


def get_base_url() -> str:
    """Get base URL from global state or settings."""
    if state["base_url"]:
        return str(state["base_url"])

    from anysite.config import get_settings

    return get_settings().base_url


def is_debug() -> bool:
    """Check if debug mode is enabled."""
    return bool(state["debug"])


# Register dataset subcommand (requires optional [data] dependencies)
try:
    from anysite.dataset.cli import app as dataset_app

    app.add_typer(dataset_app, name="dataset", help="Collect, store, and analyze datasets")
except ImportError:
    pass

# Register db subcommand (SQLite always available, PostgreSQL needs optional deps)
try:
    from anysite.db.cli import app as db_app

    app.add_typer(db_app, name="db", help="Store API data in SQL databases")
except ImportError:
    pass

# Register llm subcommand (requires optional [llm] dependencies)
try:
    from anysite.llm.cli import app as llm_app

    app.add_typer(llm_app, name="llm", help="LLM-powered analysis of collected data")
except ImportError:
    pass

# Register auth subcommand (no optional dependencies)
try:
    from anysite.auth.cli import app as auth_app

    app.add_typer(auth_app, name="auth", help="Authenticate with Anysite (OAuth2)")
except ImportError:
    pass


if __name__ == "__main__":
    app()
