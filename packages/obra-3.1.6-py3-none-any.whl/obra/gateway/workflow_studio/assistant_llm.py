"""Assistant LLM provider resolution helpers.

Routes assistant turns through the configured provider (CLI subprocess pipeline)
or an explicit stub fallback gated by ``gateway.assistant.allow_stub_fallback``.
"""

from __future__ import annotations

import asyncio
import logging
from typing import Any, Callable

from obra.config.loaders import get_gateway_assistant_config
from obra.gateway.workflow_studio.assistant_response_planner import (
    build_guided_stub_response,
    normalize_guided_decision,
    plan_guided_response,
    reconcile_guided_decision,
)
from obra.gateway.workflow_studio.assistant_types import AssistantLlmResponse

logger = logging.getLogger(__name__)


def _strip_reasoning_and_json(text: str) -> str:
    """Clean LLM output that may contain chain-of-thought and/or JSON contracts.

    If the text contains an embedded JSON object with a ``message`` field,
    extract that message.  Otherwise strip common reasoning preambles
    (e.g. "The user is asking..." paragraphs before the real answer).
    """
    import json
    import re

    stripped = text.strip()
    if not stripped:
        return stripped

    # If the text contains a JSON object with a "message" key, extract it.
    for match in re.finditer(r'\{', stripped):
        start = match.start()
        depth = 0
        for i in range(start, len(stripped)):
            if stripped[i] == '{':
                depth += 1
            elif stripped[i] == '}':
                depth -= 1
                if depth == 0:
                    candidate = stripped[start:i + 1]
                    try:
                        data = json.loads(candidate)
                        if isinstance(data, dict) and "message" in data:
                            return str(data["message"]).strip()
                    except (ValueError, json.JSONDecodeError):
                        pass
                    break

    # Strip chain-of-thought reasoning that precedes the actual answer.
    # Common pattern: reasoning paragraph(s), then "---" or blank line,
    # then the real response.
    divider = re.split(r'\n---+\n', stripped, maxsplit=1)
    if len(divider) == 2 and len(divider[1].strip()) > 20:
        return divider[1].strip()

    return stripped


def _build_stub_response(
    user_message: str,
    resolved_context: dict[str, Any] | None = None,
) -> str:
    workflow = (resolved_context or {}).get("workflow")
    latest_run = (resolved_context or {}).get("latest_run")
    if latest_run and latest_run.get("status") in {"failed", "cancelled"}:
        stage_id = latest_run.get("failure_stage_id") or "the failing stage"
        return (
            f"I traced the failure to {stage_id}. Start by reviewing that stage's template and "
            f"the input handed into it, then retry with a narrower payload.\n\n"
            f"Original request: {user_message}"
        )
    if workflow and isinstance(workflow, dict):
        workflow_name = workflow.get("name") or workflow.get("title") or workflow.get("workflow_id")
        return (
            f"I've reviewed {workflow_name}. Based on your request, I recommend validating the "
            f"stage handoffs, runner inputs, and quality gates before applying changes."
        )
    return (
        "I can help design the workflow, but I need a little more context about the inputs, "
        "outputs, and review criteria before suggesting concrete structure."
    )


def _stub_fallback_allowed() -> bool:
    """Check whether deterministic stub fallback is explicitly enabled."""
    config = get_gateway_assistant_config()
    return bool(config.get("allow_stub_fallback", False))


async def call_assistant_llm(
    system_prompt: str,
    user_message: str,
    *,
    app_state: Any | None = None,
    provider: Callable[..., Any] | None = None,
    resolved_context: dict[str, Any] | None = None,
    model_id: str | None = None,
    **kwargs: Any,
) -> AssistantLlmResponse:
    """Call the configured assistant LLM provider.

    Uses the CLI subprocess pipeline (claude/codex/gemini) by default.
    Falls back to a deterministic stub only when explicitly enabled via
    ``gateway.assistant.allow_stub_fallback: true`` in config.
    """
    safety_mode = str((resolved_context or {}).get("safety_mode") or "advisory")

    # Stub fallback takes priority when explicitly enabled (development / browser rig).
    if _stub_fallback_allowed():
        logger.debug("Using stub fallback (allow_stub_fallback=true, safety_mode=%s)", safety_mode)
        if safety_mode == "guided":
            return build_guided_stub_response(user_message, resolved_context=resolved_context)
        return AssistantLlmResponse(
            message=_build_stub_response(user_message, resolved_context=resolved_context),
        )

    llm_provider = provider or (
        getattr(app_state, "assistant_llm_provider", None) if app_state is not None else None
    )

    if llm_provider is None:
        raise RuntimeError(
            "Assistant LLM provider is not available. "
            "Verify the provider CLI is installed and authenticated "
            "(e.g. 'claude login' for Anthropic, 'codex --login' for OpenAI)."
        )

    # --- Provider is available: invoke via CLI subprocess pipeline ---

    if safety_mode == "guided":
        from obra.gateway.workflow_studio.assistant_prompts import build_guided_planner_system_prompt

        guided_system = build_guided_planner_system_prompt(system_prompt)

        # The provider now returns str (CLI output), not InvocationResult.
        guided_result = await asyncio.to_thread(
            _invoke_provider_guided,
            llm_provider,
            system_prompt=guided_system,
            user_message=user_message,
            model_id=model_id,
        )
        decision = reconcile_guided_decision(
            normalize_guided_decision(guided_result),
            user_message=user_message,
            resolved_context=resolved_context,
        )
        if not decision.message:
            decision = reconcile_guided_decision(
                normalize_guided_decision(
                {
                    "message": _build_stub_response(user_message, resolved_context=resolved_context),
                    "intent_id": "advice_only",
                    "confidence": "low",
                    "intent_args": {},
                }
                ),
                user_message=user_message,
                resolved_context=resolved_context,
            )
        return plan_guided_response(
            decision,
            user_message=user_message,
            resolved_context=resolved_context,
        )

    # Advisory mode: plain text response.
    text_result = await asyncio.to_thread(
        _invoke_provider_text,
        llm_provider,
        system_prompt=system_prompt,
        user_message=user_message,
        model_id=model_id,
    )
    # Normalize result — may be str, InvocationResult, or dict.
    if isinstance(text_result, str):
        message = _strip_reasoning_and_json(text_result)
        return AssistantLlmResponse(message=message)
    if isinstance(text_result, dict):
        return AssistantLlmResponse(
            message=str(text_result.get("message") or text_result.get("content") or "").strip(),
            outcome=str(text_result.get("outcome") or "advice"),
            action_records=text_result.get("action_records"),
        )
    if hasattr(text_result, "content"):
        message = _strip_reasoning_and_json(str(getattr(text_result, "content", "")))
        return AssistantLlmResponse(message=message)
    return AssistantLlmResponse(message=str(text_result).strip())


def _resolve_provider_result(result: Any) -> Any:
    """Await coroutines and normalize provider results.

    Returns the result as-is if it's already a dict/str.
    The caller (normalize_guided_decision or response builder) handles
    type-specific parsing.
    """
    import asyncio as _aio

    if _aio.iscoroutine(result):
        result = _aio.run(result)
    # InvocationResult from LLMInvoker — check for failures.
    if hasattr(result, "success") and getattr(result, "success") is False:
        raise RuntimeError(str(getattr(result, "error_message", "") or "assistant LLM call failed"))
    return result


def _invoke_provider_text(
    llm_provider: Any,
    *,
    system_prompt: str,
    user_message: str,
    model_id: str | None,
) -> Any:
    """Synchronous helper — runs in a thread via asyncio.to_thread."""
    if hasattr(llm_provider, "generate_text"):
        result = llm_provider.generate_text(
            system_prompt=system_prompt,
            user_message=user_message,
            model_id=model_id,
        )
        return _resolve_provider_result(result)
    raise RuntimeError("LLM provider does not implement generate_text")


def _invoke_provider_guided(
    llm_provider: Any,
    *,
    system_prompt: str,
    user_message: str,
    model_id: str | None,
) -> Any:
    """Synchronous helper — runs in a thread via asyncio.to_thread."""
    if hasattr(llm_provider, "generate_guided_contract"):
        result = llm_provider.generate_guided_contract(
            system_prompt=system_prompt,
            user_message=user_message,
            model_id=model_id,
        )
        return _resolve_provider_result(result)
    raise RuntimeError("LLM provider does not implement generate_guided_contract")


def call_assistant_llm_sync(
    system_prompt: str,
    user_message: str,
    *,
    app_state: Any | None = None,
    provider: Callable[..., Any] | None = None,
    resolved_context: dict[str, Any] | None = None,
    **kwargs: Any,
) -> AssistantLlmResponse:
    """Synchronous bridge for broker handlers executed from a worker thread."""
    return asyncio.run(
        call_assistant_llm(
            system_prompt,
            user_message,
            app_state=app_state,
            provider=provider,
            resolved_context=resolved_context,
            **kwargs,
        )
    )
