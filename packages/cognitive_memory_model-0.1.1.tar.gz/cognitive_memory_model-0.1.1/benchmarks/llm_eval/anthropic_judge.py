"""Anthropic Claude judge — uses Claude Opus as an LLM-as-judge evaluator."""

import json
import re

import anthropic

from benchmarks.llm_eval.anthropic_responder import _get_api_key
from benchmarks.llm_eval.judge import JudgmentResult


class AnthropicJudge:
    """Uses Claude Opus as an LLM-as-judge for response evaluation.

    More capable than the Mistral judge — better at detecting paraphrasing,
    semantic equivalence, and subtle factual errors.
    """

    def __init__(
        self,
        model: str = "claude-opus-4-6",
        max_tokens: int = 300,
        api_key: str | None = None,
    ):
        self.model = model
        self.max_tokens = max_tokens
        self._client = anthropic.Anthropic(api_key=api_key or _get_api_key())

    def judge(
        self,
        query: str,
        response: str,
        expected_keywords: list[str],
        ground_truth: str | None = None,
    ) -> JudgmentResult:
        """Evaluate a response using keyword matching + Claude judgment."""
        # Keyword matching
        response_lower = response.lower()
        hits = [kw for kw in expected_keywords if kw.lower() in response_lower]
        misses = [kw for kw in expected_keywords if kw.lower() not in response_lower]
        keyword_score = len(hits) / len(expected_keywords) if expected_keywords else 0.0

        # Claude judgment
        llm_judgment, llm_score = self._claude_judge(
            query, response, ground_truth or "", expected_keywords
        )

        return JudgmentResult(
            query=query,
            expected_keywords=expected_keywords,
            response=response,
            keyword_hits=hits,
            keyword_misses=misses,
            keyword_score=keyword_score,
            llm_judgment=llm_judgment,
            llm_score=llm_score,
        )

    def _claude_judge(
        self,
        query: str,
        response: str,
        ground_truth: str,
        expected_keywords: list[str],
    ) -> tuple[str, float]:
        """Use Claude to judge response accuracy."""
        user_message = (
            f"You are evaluating whether a Response correctly answers a Question "
            f"based on the Ground Truth information.\n\n"
            f"**Question:** {query}\n\n"
            f"**Ground Truth:** {ground_truth}\n\n"
            f"**Key facts that should be present:** {', '.join(expected_keywords)}\n\n"
            f"**Response to evaluate:**\n{response}\n\n"
            f"Rate the response on a scale from 0.0 to 1.0:\n"
            f"- 1.0 = fully correct, contains all key facts from the ground truth\n"
            f"- 0.7 = mostly correct, most key facts present, minor omissions\n"
            f"- 0.5 = partially correct, some key facts present\n"
            f"- 0.3 = marginally relevant, vague or mostly wrong\n"
            f"- 0.0 = incorrect, admits ignorance, or hallucinated wrong information\n\n"
            f"Be strict: if the response contains fabricated information not in the "
            f"ground truth, score it 0.0 even if it sounds plausible. "
            f"Admitting ignorance ('I don't know') is scored 0.0.\n\n"
            f"Respond with ONLY valid JSON: {{\"score\": 0.X, \"reason\": \"brief explanation\"}}"
        )

        try:
            resp = self._client.messages.create(
                model=self.model,
                max_tokens=self.max_tokens,
                temperature=0.0,
                system="You are a strict evaluation judge. Respond only with valid JSON.",
                messages=[{"role": "user", "content": user_message}],
            )

            raw = resp.content[0].text.strip()
            return self._parse_judgment(raw)

        except Exception as e:
            return f"Judge error: {e}", 0.0

    @staticmethod
    def _parse_judgment(raw: str) -> tuple[str, float]:
        """Parse the judge's JSON response."""
        text = raw
        if text.startswith("```"):
            lines = text.split("\n")
            lines = [l for l in lines if not l.strip().startswith("```")]
            text = "\n".join(lines)

        try:
            data = json.loads(text)
            score = float(data.get("score", 0.0))
            reason = data.get("reason", "")
            return reason, min(max(score, 0.0), 1.0)
        except (json.JSONDecodeError, ValueError):
            match = re.search(r"(\d+\.?\d*)", raw)
            if match:
                score = float(match.group(1))
                if score > 1.0:
                    score = score / 10.0
                return raw[:100], min(max(score, 0.0), 1.0)
            return raw[:100], 0.0
