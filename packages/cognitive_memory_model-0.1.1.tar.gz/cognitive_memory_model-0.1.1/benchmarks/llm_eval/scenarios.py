"""End-to-end LLM evaluation scenarios.

Each scenario populates a memory pipeline, then tests LLM responses
under baseline (no memory) and augmented (with memory) conditions.
"""

from dataclasses import dataclass, field

from benchmarks.llm_eval.judge import JudgmentResult, KeywordJudge, LLMJudge
from benchmarks.llm_eval.responder import OllamaResponder
from benchmarks.types import FictionalFact
from cmm.pipeline.conversation import CognitiveMemoryPipeline
from cmm.retrieval.retriever import Retriever


@dataclass
class EvalResult:
    """Result of a single baseline vs augmented comparison."""

    scenario: str
    fact_id: str
    query: str
    baseline_response: str
    augmented_response: str
    recalled_context: str
    baseline_judgment: JudgmentResult
    augmented_judgment: JudgmentResult


@dataclass
class ScenarioReport:
    """Aggregated results for an evaluation scenario."""

    scenario_name: str
    results: list[EvalResult] = field(default_factory=list)

    @property
    def count(self) -> int:
        return len(self.results)

    @property
    def baseline_keyword_avg(self) -> float:
        if not self.results:
            return 0.0
        return sum(r.baseline_judgment.keyword_score for r in self.results) / len(self.results)

    @property
    def augmented_keyword_avg(self) -> float:
        if not self.results:
            return 0.0
        return sum(r.augmented_judgment.keyword_score for r in self.results) / len(self.results)

    @property
    def baseline_llm_avg(self) -> float:
        scores = [r.baseline_judgment.llm_score for r in self.results if r.baseline_judgment.llm_score is not None]
        return sum(scores) / len(scores) if scores else 0.0

    @property
    def augmented_llm_avg(self) -> float:
        scores = [r.augmented_judgment.llm_score for r in self.results if r.augmented_judgment.llm_score is not None]
        return sum(scores) / len(scores) if scores else 0.0


def run_novel_fact_recall(
    pipeline: CognitiveMemoryPipeline,
    responder: OllamaResponder,
    judge: LLMJudge,
    facts: list[FictionalFact],
) -> ScenarioReport:
    """Scenario: Can the LLM answer questions about fictional facts it was told?

    Baseline: LLM has no memory → should score ~0%
    Augmented: LLM has recalled memories → should score >0%
    """
    report = ScenarioReport(scenario_name="novel_fact_recall")
    base_facts = [f for f in facts if not f.is_correction]

    for fact in base_facts:
        query = fact.queries[0]

        # Baseline: no memory
        baseline_resp = responder.respond(query)

        # Augmented: recall from memory
        retrieved = pipeline.recall(query, top_k=5)
        context = Retriever.format_for_context(retrieved)
        augmented_resp = responder.respond(query, context=context)

        # Judge both
        baseline_j = judge.judge(query, baseline_resp, fact.expected_keywords, fact.injection_text)
        augmented_j = judge.judge(query, augmented_resp, fact.expected_keywords, fact.injection_text)

        report.results.append(EvalResult(
            scenario="novel_fact_recall",
            fact_id=fact.id,
            query=query,
            baseline_response=baseline_resp,
            augmented_response=augmented_resp,
            recalled_context=context,
            baseline_judgment=baseline_j,
            augmented_judgment=augmented_j,
        ))

    return report


def run_correction_accuracy(
    pipeline: CognitiveMemoryPipeline,
    responder: OllamaResponder,
    judge: LLMJudge,
    facts: list[FictionalFact],
) -> ScenarioReport:
    """Scenario: After a correction, does the LLM use the corrected fact?

    Tests whether the memory system surfaces the correction (higher importance)
    and whether the LLM uses it over the original wrong fact.
    """
    report = ScenarioReport(scenario_name="correction_accuracy")
    fact_map = {f.id: f for f in facts}
    corrections = [f for f in facts if f.is_correction]

    for correction in corrections:
        original = fact_map.get(correction.corrects_fact_id)
        if not original:
            continue

        query = correction.queries[0]

        # Baseline: no memory
        baseline_resp = responder.respond(query)

        # Augmented: should recall the correction (higher importance)
        retrieved = pipeline.recall(query, top_k=5)
        context = Retriever.format_for_context(retrieved)
        augmented_resp = responder.respond(query, context=context)

        # Judge: correction keywords should be in augmented response
        baseline_j = judge.judge(query, baseline_resp, correction.expected_keywords, correction.injection_text)
        augmented_j = judge.judge(query, augmented_resp, correction.expected_keywords, correction.injection_text)

        report.results.append(EvalResult(
            scenario="correction_accuracy",
            fact_id=correction.id,
            query=query,
            baseline_response=baseline_resp,
            augmented_response=augmented_resp,
            recalled_context=context,
            baseline_judgment=baseline_j,
            augmented_judgment=augmented_j,
        ))

    return report


def run_multi_memory_synthesis(
    pipeline: CognitiveMemoryPipeline,
    responder: OllamaResponder,
    judge: LLMJudge,
    facts: list[FictionalFact],
) -> ScenarioReport:
    """Scenario: Can the LLM synthesize information from multiple recalled memories?

    Asks questions that require combining facts from different memories.
    Tests whether the retrieval surfaces related facts AND whether the LLM
    can reason across them.
    """
    report = ScenarioReport(scenario_name="multi_memory_synthesis")

    # Hand-crafted synthesis questions that require multiple facts
    synthesis_questions = [
        {
            "query": "Tell me everything you know about the Zorbax fish — who discovered it, how many are there, and where does it live?",
            "expected_keywords": ["zorbax", "amara", "osei", "12,000", "lake malawi"],
            "ground_truth": "The Zorbax fish was discovered by Dr. Amara Osei in Lake Malawi. It has a population of ~12,000 and has luminescent scales.",
            "fact_ids": ["marine_01", "marine_02", "marine_03"],
        },
        {
            "query": "What is the connection between Nexova Systems and Dr. Kaspar Wren?",
            "expected_keywords": ["nexova", "solidflow", "tallinn", "kaspar wren"],
            "ground_truth": "Dr. Kaspar Wren's SolidFlow batteries are used in Nexova Systems' data centers in Tallinn, reducing energy costs by 60%.",
            "fact_ids": ["tech_01", "people_02", "people_06"],
        },
        {
            "query": "What technology is being used to simulate the Theron Object's trajectory, and who is doing it?",
            "expected_keywords": ["qubit-7", "kenji nakamura", "theron"],
            "ground_truth": "Dr. Kenji Nakamura's team at the University of Tokyo is using Nexova's Qubit-7 processor to simulate the Theron Object's trajectory.",
            "fact_ids": ["crossdomain_02", "tech_01", "astro_03"],
        },
        {
            "query": "Describe Priya Mehta's work — what has she designed and what awards has she won?",
            "expected_keywords": ["priya mehta", "floating gardens", "singapore", "pritzker"],
            "ground_truth": "Priya Mehta designed the Floating Gardens in Singapore (300m tall) and won the Pritzker Prize. She's also designing a research station on Isla Verada.",
            "fact_ids": ["people_03", "people_07", "people_08"],
        },
        {
            "query": "What do Dr. Amara Osei and Dr. Irina Petrov have in common, and what are they working on together?",
            "expected_keywords": ["amara osei", "irina petrov", "velrath", "zorbax"],
            "ground_truth": "Both are marine biologists. Osei discovered the Zorbax fish, Petrov synthesized velrathin from Velrath jellyfish. They now collaborate on studying how Velrath toxins affect freshwater fish.",
            "fact_ids": ["marine_03", "marine_06", "crossdomain_01"],
        },
    ]

    for sq in synthesis_questions:
        query = sq["query"]

        # Baseline
        baseline_resp = responder.respond(query)

        # Augmented (use larger top_k to get multiple related memories)
        retrieved = pipeline.recall(query, top_k=10)
        context = Retriever.format_for_context(retrieved)
        augmented_resp = responder.respond(query, context=context)

        # Judge
        baseline_j = judge.judge(query, baseline_resp, sq["expected_keywords"], sq["ground_truth"])
        augmented_j = judge.judge(query, augmented_resp, sq["expected_keywords"], sq["ground_truth"])

        report.results.append(EvalResult(
            scenario="multi_memory_synthesis",
            fact_id="|".join(sq["fact_ids"]),
            query=query,
            baseline_response=baseline_resp,
            augmented_response=augmented_resp,
            recalled_context=context,
            baseline_judgment=baseline_j,
            augmented_judgment=augmented_j,
        ))

    return report


def run_user_preference_application(
    pipeline: CognitiveMemoryPipeline,
    responder: OllamaResponder,
    judge: LLMJudge,
    facts: list[FictionalFact],
) -> ScenarioReport:
    """Scenario: Does the system recall user preferences at the right moment?

    Tests whether the memory system automatically surfaces user preferences
    when contextually relevant, and whether the LLM applies them.
    """
    report = ScenarioReport(scenario_name="user_preference_application")

    # Contextual queries where preferences should be recalled
    preference_queries = [
        {
            "query": "Can you set up the display theme for my new IDE?",
            "expected_keywords": ["dark mode", "dark"],
            "ground_truth": "User prefers dark mode in all applications due to headaches from light themes.",
            "related_pref": "pref_01",
        },
        {
            "query": "I'm ordering lunch for the team, what should I be careful about for my own order?",
            "expected_keywords": ["shellfish", "allergic", "shrimp"],
            "ground_truth": "User is allergic to shellfish (shrimp, crab, lobster). Has an EpiPen.",
            "related_pref": "pref_02",
        },
        {
            "query": "When do I need to have the client deliverable ready?",
            "expected_keywords": ["april 15", "meridian health"],
            "ground_truth": "Deadline is April 15th for Meridian Health Systems. Deliverable is a HIPAA-compliant patient portal.",
            "related_pref": "pref_03",
        },
        {
            "query": "How should I configure error output in the application?",
            "expected_keywords": ["stack trace", "truncate"],
            "ground_truth": "User wants full stack traces with variable values. Never truncate error output.",
            "related_pref": "pref_05",
        },
    ]

    for pq in preference_queries:
        query = pq["query"]

        # Baseline
        baseline_resp = responder.respond(query)

        # Augmented
        retrieved = pipeline.recall(query, top_k=5)
        context = Retriever.format_for_context(retrieved)
        augmented_resp = responder.respond(query, context=context)

        # Judge
        baseline_j = judge.judge(query, baseline_resp, pq["expected_keywords"], pq["ground_truth"])
        augmented_j = judge.judge(query, augmented_resp, pq["expected_keywords"], pq["ground_truth"])

        report.results.append(EvalResult(
            scenario="user_preference_application",
            fact_id=pq["related_pref"],
            query=query,
            baseline_response=baseline_resp,
            augmented_response=augmented_resp,
            recalled_context=context,
            baseline_judgment=baseline_j,
            augmented_judgment=augmented_j,
        ))

    return report
