"""End-to-end LLM evaluation runner.

Populates the memory pipeline with fictional facts, then runs baseline vs
augmented evaluation across all scenarios.

Usage:
    python -m benchmarks.llm_eval.runner                                    # Ollama (default)
    python -m benchmarks.llm_eval.runner --backend anthropic                # Claude Opus 4.6
    python -m benchmarks.llm_eval.runner --backend anthropic --verbose      # with detail
    python -m benchmarks.llm_eval.runner --scenario correction_accuracy -v  # single scenario
"""

import argparse
import time

from benchmarks.generators.fact_generator import load_facts, load_fillers
from benchmarks.llm_eval.scenarios import (
    ScenarioReport,
    run_correction_accuracy,
    run_multi_memory_synthesis,
    run_novel_fact_recall,
    run_user_preference_application,
)
from benchmarks.types import FictionalFact, FillerTurn
from cmm.encoding.embedding import EmbeddingModel
from cmm.pipeline.conversation import CognitiveMemoryPipeline


SCENARIOS = {
    "novel_fact_recall": "Baseline vs augmented on fictional facts (formality test)",
    "correction_accuracy": "Does the LLM use the corrected fact, not the original?",
    "multi_memory_synthesis": "Can the LLM synthesize across multiple recalled memories?",
    "user_preference_application": "Does the system surface user preferences in context?",
}


def _create_responder(backend: str):
    """Create the appropriate responder for the backend."""
    if backend == "ollama":
        from benchmarks.llm_eval.responder import OllamaResponder
        return OllamaResponder()
    elif backend == "anthropic":
        from benchmarks.llm_eval.anthropic_responder import AnthropicResponder
        return AnthropicResponder(model="claude-opus-4-6")
    else:
        raise ValueError(f"Unknown backend: {backend}")


def _create_judge(backend: str):
    """Create the appropriate judge for the backend."""
    if backend == "ollama":
        from benchmarks.llm_eval.judge import LLMJudge
        return LLMJudge()
    elif backend == "anthropic":
        from benchmarks.llm_eval.anthropic_judge import AnthropicJudge
        return AnthropicJudge(model="claude-opus-4-6")
    else:
        raise ValueError(f"Unknown backend: {backend}")


def populate_pipeline(
    pipeline: CognitiveMemoryPipeline,
    facts: list[FictionalFact],
    fillers: list[FillerTurn],
) -> None:
    """Populate the pipeline with all facts and some filler, simulating a conversation."""
    import random
    rng = random.Random(42)

    base_facts = [f for f in facts if not f.is_correction]
    corrections = [f for f in facts if f.is_correction]

    # Ingest base facts with filler between them
    for fact in base_facts:
        pipeline.ingest("user", fact.injection_text)
        pipeline.ingest("assistant", "Understood, I'll remember that.")

        # 2-3 filler turns between facts
        for _ in range(rng.randint(2, 3)):
            filler = rng.choice(fillers)
            pipeline.ingest(filler.role, filler.content)

    # Ingest corrections later (after a gap)
    for _ in range(10):
        filler = rng.choice(fillers)
        pipeline.ingest(filler.role, filler.content)

    for correction in corrections:
        pipeline.ingest("user", correction.injection_text)
        pipeline.ingest("assistant", "Got it, I've updated my understanding.")


def format_report(report: ScenarioReport, verbose: bool = False) -> str:
    """Format a scenario report as human-readable text."""
    lines = [
        f"\n{'=' * 70}",
        f"  SCENARIO: {report.scenario_name}",
        f"{'=' * 70}",
        f"  Queries: {report.count}",
        f"",
        f"  Keyword Score (avg):",
        f"    Baseline:  {report.baseline_keyword_avg:.1%}",
        f"    Augmented: {report.augmented_keyword_avg:.1%}",
        f"    Delta:     {report.augmented_keyword_avg - report.baseline_keyword_avg:+.1%}",
        f"",
        f"  LLM Judge Score (avg):",
        f"    Baseline:  {report.baseline_llm_avg:.1%}",
        f"    Augmented: {report.augmented_llm_avg:.1%}",
        f"    Delta:     {report.augmented_llm_avg - report.baseline_llm_avg:+.1%}",
    ]

    if verbose:
        lines.append(f"\n  {'─' * 66}")
        lines.append(f"  DETAILED RESULTS:")
        for r in report.results:
            lines.append(f"\n  [{r.fact_id}] {r.query}")
            lines.append(f"    Baseline  (kw: {r.baseline_judgment.keyword_score:.0%}, llm: {r.baseline_judgment.llm_score or 0:.0%}):")
            lines.append(f"      {r.baseline_response[:150]}")
            lines.append(f"    Augmented (kw: {r.augmented_judgment.keyword_score:.0%}, llm: {r.augmented_judgment.llm_score or 0:.0%}):")
            lines.append(f"      {r.augmented_response[:150]}")
            if r.augmented_judgment.llm_judgment:
                lines.append(f"    Judge: {r.augmented_judgment.llm_judgment[:120]}")

    return "\n".join(lines)


def format_summary(reports: list[ScenarioReport], backend: str = "") -> str:
    """Format a summary comparison across all scenarios."""
    backend_label = f" ({backend.upper()})" if backend else ""
    lines = [
        f"\n{'=' * 70}",
        f"  END-TO-END LLM EVALUATION SUMMARY{backend_label}",
        f"{'=' * 70}",
        f"  {'Scenario':<35s} {'Baseline':>10s} {'Augmented':>10s} {'Delta':>10s}",
        f"  {'-' * 67}",
    ]

    for r in reports:
        delta = r.augmented_keyword_avg - r.baseline_keyword_avg
        lines.append(
            f"  {r.scenario_name:<35s} {r.baseline_keyword_avg:>9.0%} {r.augmented_keyword_avg:>10.0%} {delta:>+9.0%}"
        )

    lines.append(f"\n  LLM-as-Judge scores:")
    lines.append(f"  {'Scenario':<35s} {'Baseline':>10s} {'Augmented':>10s} {'Delta':>10s}")
    lines.append(f"  {'-' * 67}")

    for r in reports:
        delta = r.augmented_llm_avg - r.baseline_llm_avg
        lines.append(
            f"  {r.scenario_name:<35s} {r.baseline_llm_avg:>9.0%} {r.augmented_llm_avg:>10.0%} {delta:>+9.0%}"
        )

    # Overall
    total_base_kw = sum(r.baseline_keyword_avg for r in reports) / len(reports) if reports else 0
    total_aug_kw = sum(r.augmented_keyword_avg for r in reports) / len(reports) if reports else 0
    total_base_llm = sum(r.baseline_llm_avg for r in reports) / len(reports) if reports else 0
    total_aug_llm = sum(r.augmented_llm_avg for r in reports) / len(reports) if reports else 0
    lines.append(f"\n  {'OVERALL (keyword)':<35s} {total_base_kw:>9.0%} {total_aug_kw:>10.0%} {total_aug_kw - total_base_kw:>+9.0%}")
    lines.append(f"  {'OVERALL (LLM judge)':<35s} {total_base_llm:>9.0%} {total_aug_llm:>10.0%} {total_aug_llm - total_base_llm:>+9.0%}")

    return "\n".join(lines)


def run_llm_eval(
    scenarios: list[str] | None = None,
    verbose: bool = False,
    backend: str = "ollama",
) -> list[ScenarioReport]:
    """Run the full end-to-end LLM evaluation."""
    scenarios = scenarios or list(SCENARIOS.keys())

    print(f"Backend: {backend}")
    print("Loading embedding model...")
    embedding_model = EmbeddingModel()

    print("Setting up memory pipeline...")
    pipeline = CognitiveMemoryPipeline(
        embedding_model=embedding_model,
        retriever_threshold=0.2,
    )

    facts = load_facts()
    fillers = load_fillers()

    print(f"Populating pipeline with {len(facts)} facts...")
    populate_pipeline(pipeline, facts, fillers)
    print(f"  Pipeline has {pipeline.memory_count} memories")

    print(f"Initializing {backend} responder and judge...")
    responder = _create_responder(backend)
    judge = _create_judge(backend)

    reports: list[ScenarioReport] = []

    for scenario_name in scenarios:
        if scenario_name not in SCENARIOS:
            print(f"  Unknown scenario: {scenario_name}")
            continue

        print(f"\nRunning: {scenario_name} — {SCENARIOS[scenario_name]}")
        start = time.perf_counter()

        if scenario_name == "novel_fact_recall":
            report = run_novel_fact_recall(pipeline, responder, judge, facts)
        elif scenario_name == "correction_accuracy":
            report = run_correction_accuracy(pipeline, responder, judge, facts)
        elif scenario_name == "multi_memory_synthesis":
            report = run_multi_memory_synthesis(pipeline, responder, judge, facts)
        elif scenario_name == "user_preference_application":
            report = run_user_preference_application(pipeline, responder, judge, facts)
        else:
            continue

        elapsed = time.perf_counter() - start
        reports.append(report)

        print(format_report(report, verbose=verbose))
        print(f"\n  Time: {elapsed:.1f}s")

    if len(reports) > 1:
        print(format_summary(reports, backend=backend))

    return reports


def main():
    parser = argparse.ArgumentParser(description="Run end-to-end LLM evaluation")
    parser.add_argument(
        "--scenario", "-s",
        choices=list(SCENARIOS.keys()),
        nargs="+",
        help="Scenarios to run (default: all)",
    )
    parser.add_argument(
        "--verbose", "-v",
        action="store_true",
        help="Show detailed per-query results",
    )
    parser.add_argument(
        "--backend", "-b",
        choices=["ollama", "anthropic"],
        default="ollama",
        help="LLM backend: ollama (Mistral 7B) or anthropic (Claude Opus 4.6)",
    )
    args = parser.parse_args()

    run_llm_eval(scenarios=args.scenario, verbose=args.verbose, backend=args.backend)


if __name__ == "__main__":
    main()
