"""Anthropic Claude responder — sends queries to Claude via the Anthropic API."""

import os

import anthropic


def _get_api_key() -> str:
    """Get the Anthropic API key from environment or .env file."""
    key = os.environ.get("ANTHROPIC_API_KEY")
    if key:
        return key

    # Try .env file in project root
    env_path = os.path.join(os.path.dirname(__file__), "..", "..", ".env")
    if os.path.exists(env_path):
        with open(env_path) as f:
            for line in f:
                line = line.strip()
                if line.startswith("ANTHROPIC_API_KEY="):
                    return line.split("=", 1)[1].strip().strip("'\"")

    raise ValueError(
        "ANTHROPIC_API_KEY not found. Set it as an environment variable "
        "or create a .env file in the project root."
    )


class AnthropicResponder:
    """Sends queries to Claude via the Anthropic API."""

    def __init__(
        self,
        model: str = "claude-opus-4-6",
        max_tokens: int = 500,
        temperature: float = 0.1,
        api_key: str | None = None,
    ):
        self.model = model
        self.max_tokens = max_tokens
        self.temperature = temperature
        self._client = anthropic.Anthropic(api_key=api_key or _get_api_key())

    def respond(self, query: str, context: str | None = None) -> str:
        """Send a query to Claude and return the response.

        Args:
            query: The user's question.
            context: Optional memory context to prepend to the prompt.
        """
        if context:
            user_message = (
                f"You have the following information from your memory:\n\n"
                f"{context}\n\n"
                f"Using the information above, answer the following question. "
                f"If the memory contains relevant information, use it in your answer. "
                f"Be specific and include details like names, numbers, and dates from memory.\n\n"
                f"Question: {query}"
            )
        else:
            user_message = (
                f"Answer the following question. If you don't know the answer, "
                f"say \"I don't have information about that.\"\n\n"
                f"Question: {query}"
            )

        response = self._client.messages.create(
            model=self.model,
            max_tokens=self.max_tokens,
            temperature=self.temperature,
            system=(
                "You are a helpful assistant. Answer questions accurately and concisely. "
                "If you have been given memory context, use it. "
                "If you don't know something, say so honestly — do not make up information."
            ),
            messages=[{"role": "user", "content": user_message}],
        )

        return response.content[0].text.strip()
