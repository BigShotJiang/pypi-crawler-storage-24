"""Evaluation judges — assess whether LLM responses contain expected information."""

from dataclasses import dataclass, field

import httpx


@dataclass
class JudgmentResult:
    """Result of evaluating a single LLM response."""

    query: str
    expected_keywords: list[str]
    response: str
    keyword_hits: list[str]
    keyword_misses: list[str]
    keyword_score: float  # fraction of expected keywords found
    llm_judgment: str | None = None  # LLM-as-judge verdict
    llm_score: float | None = None  # LLM-as-judge score (0-1)


class KeywordJudge:
    """Simple keyword-matching evaluator."""

    def judge(self, query: str, response: str, expected_keywords: list[str]) -> JudgmentResult:
        response_lower = response.lower()
        hits = [kw for kw in expected_keywords if kw.lower() in response_lower]
        misses = [kw for kw in expected_keywords if kw.lower() not in response_lower]

        return JudgmentResult(
            query=query,
            expected_keywords=expected_keywords,
            response=response,
            keyword_hits=hits,
            keyword_misses=misses,
            keyword_score=len(hits) / len(expected_keywords) if expected_keywords else 0.0,
        )


class LLMJudge:
    """LLM-as-judge evaluator — uses a second LLM call to assess accuracy.

    More nuanced than keyword matching: can handle paraphrasing,
    partial correctness, and semantic equivalence.
    """

    def __init__(
        self,
        model: str = "mistral:7b-instruct-q4_K_M",
        base_url: str = "http://localhost:11434",
        timeout: float = 60.0,
    ):
        self.model = model
        self.base_url = base_url
        self._client = httpx.Client(timeout=timeout)

    def judge(
        self,
        query: str,
        response: str,
        expected_keywords: list[str],
        ground_truth: str | None = None,
    ) -> JudgmentResult:
        """Evaluate a response using both keyword matching and LLM judgment.

        Args:
            query: The original question.
            response: The LLM's response to evaluate.
            expected_keywords: Keywords that should appear.
            ground_truth: The original fact text (for the LLM judge to compare against).
        """
        # Keyword matching first
        response_lower = response.lower()
        hits = [kw for kw in expected_keywords if kw.lower() in response_lower]
        misses = [kw for kw in expected_keywords if kw.lower() not in response_lower]
        keyword_score = len(hits) / len(expected_keywords) if expected_keywords else 0.0

        # LLM judgment
        llm_judgment, llm_score = self._llm_judge(query, response, ground_truth or "", expected_keywords)

        return JudgmentResult(
            query=query,
            expected_keywords=expected_keywords,
            response=response,
            keyword_hits=hits,
            keyword_misses=misses,
            keyword_score=keyword_score,
            llm_judgment=llm_judgment,
            llm_score=llm_score,
        )

    def _llm_judge(
        self,
        query: str,
        response: str,
        ground_truth: str,
        expected_keywords: list[str],
    ) -> tuple[str, float]:
        """Use the LLM to judge response accuracy."""
        prompt = (
            f"You are an evaluation judge. Assess whether the Response correctly answers "
            f"the Question based on the Ground Truth.\n\n"
            f"Question: {query}\n\n"
            f"Ground Truth: {ground_truth}\n\n"
            f"Key facts that should be present: {', '.join(expected_keywords)}\n\n"
            f"Response to evaluate:\n{response}\n\n"
            f"Rate the response on a scale from 0.0 to 1.0:\n"
            f"- 1.0 = fully correct, contains all key facts\n"
            f"- 0.5 = partially correct, some facts present\n"
            f"- 0.0 = incorrect, doesn't know, or hallucinated wrong info\n\n"
            f"Respond with ONLY a JSON object: {{\"score\": 0.X, \"reason\": \"...\"}}"
        )

        try:
            resp = self._client.post(
                f"{self.base_url}/api/generate",
                json={
                    "model": self.model,
                    "prompt": prompt,
                    "system": "You are a strict evaluation judge. Respond only with valid JSON.",
                    "stream": False,
                    "options": {"temperature": 0.0, "num_predict": 150},
                },
            )
            resp.raise_for_status()
            raw = resp.json()["response"].strip()
            return self._parse_judgment(raw)
        except Exception as e:
            return f"Judge error: {e}", 0.0

    @staticmethod
    def _parse_judgment(raw: str) -> tuple[str, float]:
        """Parse the judge's JSON response."""
        import json

        text = raw
        if text.startswith("```"):
            lines = text.split("\n")
            lines = [l for l in lines if not l.strip().startswith("```")]
            text = "\n".join(lines)

        try:
            data = json.loads(text)
            score = float(data.get("score", 0.0))
            reason = data.get("reason", "")
            return reason, min(max(score, 0.0), 1.0)
        except (json.JSONDecodeError, ValueError):
            # Try to extract a number from the response
            import re
            match = re.search(r"(\d+\.?\d*)", raw)
            if match:
                score = float(match.group(1))
                if score > 1.0:
                    score = score / 10.0  # handle "7/10" style
                return raw[:100], min(max(score, 0.0), 1.0)
            return raw[:100], 0.0

    def close(self):
        self._client.close()
