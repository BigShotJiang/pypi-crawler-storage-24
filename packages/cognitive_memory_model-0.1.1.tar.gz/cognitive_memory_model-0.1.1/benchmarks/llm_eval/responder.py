"""LLM responder — sends queries to Ollama with and without memory context."""

import httpx


class OllamaResponder:
    """Sends queries to a local Ollama model and returns responses."""

    def __init__(
        self,
        model: str = "mistral:7b-instruct-q4_K_M",
        base_url: str = "http://localhost:11434",
        timeout: float = 60.0,
        temperature: float = 0.1,
    ):
        self.model = model
        self.base_url = base_url
        self.temperature = temperature
        self._client = httpx.Client(timeout=timeout)

    def respond(self, query: str, context: str | None = None) -> str:
        """Send a query to the LLM and return the response.

        Args:
            query: The user's question.
            context: Optional memory context to prepend to the prompt.
                If provided, this is the recalled memories block.

        Returns:
            The LLM's response text.
        """
        if context:
            prompt = (
                f"You have the following information from your memory:\n\n"
                f"{context}\n\n"
                f"Using the information above, answer the following question. "
                f"If the memory contains relevant information, use it in your answer. "
                f"Be specific and include details like names, numbers, and dates from memory.\n\n"
                f"Question: {query}"
            )
        else:
            prompt = (
                f"Answer the following question. If you don't know the answer, "
                f"say \"I don't have information about that.\"\n\n"
                f"Question: {query}"
            )

        system = (
            "You are a helpful assistant. Answer questions accurately and concisely. "
            "If you have been given memory context, use it. "
            "If you don't know something, say so honestly."
        )

        response = self._client.post(
            f"{self.base_url}/api/generate",
            json={
                "model": self.model,
                "prompt": prompt,
                "system": system,
                "stream": False,
                "options": {
                    "temperature": self.temperature,
                    "num_predict": 300,
                },
            },
        )
        response.raise_for_status()
        return response.json()["response"].strip()

    def close(self):
        self._client.close()

    def __del__(self):
        try:
            self._client.close()
        except Exception:
            pass
