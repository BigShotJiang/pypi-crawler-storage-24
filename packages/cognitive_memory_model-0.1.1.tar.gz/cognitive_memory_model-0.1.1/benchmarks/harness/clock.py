"""Simulated clock for benchmarks — allows controlling time progression."""

import time


class SimulatedClock:
    """A clock that advances by a configurable amount per tick.

    Use this in benchmarks to simulate time passing between turns.
    Without it, all turns happen within milliseconds and decay has no effect.

    Example:
        clock = SimulatedClock(seconds_per_tick=30)
        pipeline.retriever.clock = clock
        # Each pipeline.ingest() call should call clock.tick() to advance time
        # 500 turns at 30s/turn = ~4.2 hours of simulated time
    """

    def __init__(self, start_time: float | None = None, seconds_per_tick: float = 30.0):
        """
        Args:
            start_time: Starting timestamp. Defaults to current time.
            seconds_per_tick: How many seconds of simulated time pass per tick.
        """
        self._time = start_time or time.time()
        self.seconds_per_tick = seconds_per_tick

    def __call__(self) -> float:
        """Return current simulated time. Used as a drop-in for time.time."""
        return self._time

    def tick(self) -> float:
        """Advance the clock by one tick. Returns new time."""
        self._time += self.seconds_per_tick
        return self._time

    @property
    def current_time(self) -> float:
        return self._time
