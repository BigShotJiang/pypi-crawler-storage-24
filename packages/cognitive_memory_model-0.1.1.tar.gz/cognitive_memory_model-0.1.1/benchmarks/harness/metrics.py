"""Metrics computation and reporting for benchmark results."""

from benchmarks.types import RecallResult, ScenarioMetrics


def compute_metrics(
    scenario_name: str,
    condition_name: str,
    results: list[RecallResult],
) -> ScenarioMetrics:
    """Compute aggregate metrics from a list of recall results."""
    metrics = ScenarioMetrics(
        scenario_name=scenario_name,
        condition_name=condition_name,
        raw_results=results,
    )
    metrics.compute()
    return metrics


def format_metrics(metrics: ScenarioMetrics) -> str:
    """Format metrics as a human-readable report."""
    lines = [
        f"=== {metrics.scenario_name} | {metrics.condition_name} ===",
        f"  Queries:       {metrics.total_queries}",
        f"  Hits:          {metrics.hits}",
        f"  Recall@k:      {metrics.recall_at_k:.1%}",
        f"  Avg top score: {metrics.avg_top_score:.4f}",
        f"  Avg latency:   {metrics.avg_latency_ms:.1f} ms",
    ]

    if metrics.recall_by_distance:
        lines.append("  Recall by distance:")
        for dist, recall in sorted(metrics.recall_by_distance.items()):
            lines.append(f"    {dist:>4d} turns: {recall:.1%}")

    return "\n".join(lines)


def format_comparison(all_metrics: list[ScenarioMetrics]) -> str:
    """Format a comparison table across conditions for the same scenario."""
    if not all_metrics:
        return ""

    scenario = all_metrics[0].scenario_name
    lines = [
        f"\n{'=' * 70}",
        f"  COMPARISON: {scenario}",
        f"{'=' * 70}",
        f"  {'Condition':<30s} {'Recall@k':>10s} {'Avg Score':>10s} {'Latency':>10s}",
        f"  {'-' * 62}",
    ]

    for m in all_metrics:
        lines.append(
            f"  {m.condition_name:<30s} {m.recall_at_k:>9.1%} {m.avg_top_score:>10.4f} {m.avg_latency_ms:>8.1f}ms"
        )

    # Decay curve comparison
    all_distances = sorted(set(
        d for m in all_metrics for d in m.recall_by_distance
    ))
    if all_distances:
        lines.append(f"\n  Recall by distance (turns):")
        header = f"  {'Condition':<30s}" + "".join(f" {d:>6d}" for d in all_distances)
        lines.append(header)
        lines.append(f"  {'-' * (30 + 7 * len(all_distances))}")
        for m in all_metrics:
            row = f"  {m.condition_name:<30s}"
            for d in all_distances:
                val = m.recall_by_distance.get(d)
                row += f" {val:>5.0%} " if val is not None else "     - "
            lines.append(row)

    return "\n".join(lines)
