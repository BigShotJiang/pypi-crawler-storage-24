"""Ablation conditions — pipeline configurations for benchmarking."""

from cmm.encoding.embedding import EmbeddingModel
from cmm.pipeline.conversation import CognitiveMemoryPipeline
from cmm.retrieval.decay import SECONDS_PER_DAY
from cmm.scoring.importance import RuleBasedImportanceScorer


class NoOpImportanceScorer(RuleBasedImportanceScorer):
    """Always returns 1.0 — disables importance scoring."""

    def score(self, turn, store=None, embedding=None) -> float:
        return 1.0


def create_condition(
    name: str,
    embedding_model: EmbeddingModel,
) -> CognitiveMemoryPipeline:
    """Create a pipeline configured for a specific ablation condition.

    Conditions progressively add cognitive features:
    1. simple_retrieval — embed + FAISS top-k, no cognitive features
    2. with_decay — add temporal decay with grace period
    3. with_working_memory — add working memory buffer
    4. with_spreading — add spreading activation
    5. with_priming — add priming state
    6. with_importance — add importance scoring
    7. full_system — all features enabled (default pipeline)
    """
    # Shared base config
    base = dict(
        embedding_model=embedding_model,
        retriever_top_k=5,
        retriever_threshold=0.2,
    )

    # Decay disabled config
    no_decay = dict(
        decay_grace_period=0,
        decay_rate=0.0,
        decay_freq_weight=0.0,
        decay_lock_frequency=999.0,
    )

    # Decay enabled config (default values)
    with_decay_cfg = dict(
        decay_grace_period=14 * SECONDS_PER_DAY,
        decay_rate=5e-7,
        decay_freq_weight=1.0,
        decay_lock_frequency=0.5,
    )

    if name == "simple_retrieval":
        return CognitiveMemoryPipeline(
            **base,
            **no_decay,
            working_memory_capacity=0,
            working_memory_ttl=0,
            spread_depth=0,
            spread_factor=0.0,
            priming_boost=0.0,
            priming_decay=0.0,
            importance_scorer=NoOpImportanceScorer(),
        )

    elif name == "with_decay":
        return CognitiveMemoryPipeline(
            **base,
            **with_decay_cfg,
            working_memory_capacity=0,
            working_memory_ttl=0,
            spread_depth=0,
            spread_factor=0.0,
            priming_boost=0.0,
            priming_decay=0.0,
            importance_scorer=NoOpImportanceScorer(),
        )

    elif name == "with_working_memory":
        return CognitiveMemoryPipeline(
            **base,
            **with_decay_cfg,
            working_memory_capacity=10,
            working_memory_ttl=5,
            spread_depth=0,
            spread_factor=0.0,
            priming_boost=0.0,
            priming_decay=0.0,
            importance_scorer=NoOpImportanceScorer(),
        )

    elif name == "with_spreading":
        return CognitiveMemoryPipeline(
            **base,
            **with_decay_cfg,
            working_memory_capacity=10,
            working_memory_ttl=5,
            spread_depth=1,
            spread_factor=0.5,
            spread_top_k=3,
            priming_boost=0.0,
            priming_decay=0.0,
            importance_scorer=NoOpImportanceScorer(),
        )

    elif name == "with_priming":
        return CognitiveMemoryPipeline(
            **base,
            **with_decay_cfg,
            working_memory_capacity=10,
            working_memory_ttl=5,
            spread_depth=1,
            spread_factor=0.5,
            spread_top_k=3,
            priming_boost=0.3,
            priming_decay=0.5,
            importance_scorer=NoOpImportanceScorer(),
        )

    elif name == "with_importance":
        return CognitiveMemoryPipeline(
            **base,
            **with_decay_cfg,
            working_memory_capacity=10,
            working_memory_ttl=5,
            spread_depth=1,
            spread_factor=0.5,
            spread_top_k=3,
            priming_boost=0.3,
            priming_decay=0.5,
            # Default importance scorer (rule-based)
        )

    elif name == "full_system":
        return CognitiveMemoryPipeline(
            **base,
            # All defaults — full cognitive features
        )

    else:
        raise ValueError(f"Unknown condition: {name}")


ALL_CONDITIONS = [
    "simple_retrieval",
    "with_decay",
    "with_working_memory",
    "with_spreading",
    "with_priming",
    "with_importance",
    "full_system",
]
