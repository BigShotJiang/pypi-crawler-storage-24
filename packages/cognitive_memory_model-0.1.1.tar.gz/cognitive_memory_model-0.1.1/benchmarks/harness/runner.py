"""Benchmark runner — executes scenarios across ablation conditions."""

import argparse
import sys
import time

from benchmarks.generators.fact_generator import load_facts, load_fillers
from benchmarks.harness.conditions import ALL_CONDITIONS, create_condition
from benchmarks.harness.metrics import compute_metrics, format_comparison, format_metrics
from benchmarks.scenarios.basic_recall import run_basic_recall
from benchmarks.scenarios.correction import run_correction_test
from benchmarks.scenarios.multi_session import run_multi_session
from benchmarks.scenarios.rehearsal import run_rehearsal_test
from benchmarks.scenarios.spreading import run_spreading_test
from benchmarks.types import ScenarioMetrics
from cmm.encoding.embedding import EmbeddingModel


SCENARIOS = {
    "recall": "Basic fact recall at various distances",
    "correction": "Correction handling — does corrected fact outrank original",
    "spreading": "Spreading activation — does querying one fact activate related facts",
    "rehearsal": "Rehearsal effect — do repeatedly accessed facts resist decay better",
    "multi_session": "Realistic multi-session conversation with cross-session recall",
}


def run_benchmark(
    scenarios: list[str] | None = None,
    conditions: list[str] | None = None,
    distances: list[int] | None = None,
    top_k: int = 5,
) -> dict[str, list[ScenarioMetrics]]:
    """Run the benchmark suite.

    Args:
        scenarios: Which scenarios to run. None = all.
        conditions: Which ablation conditions to test. None = all.
        distances: Turn distances to test for recall. None = [10, 25, 50].
        top_k: Number of results to retrieve.

    Returns:
        Dict mapping scenario name to list of ScenarioMetrics (one per condition).
    """
    scenarios = scenarios or list(SCENARIOS.keys())
    conditions = conditions or ALL_CONDITIONS

    facts = load_facts()
    fillers = load_fillers()

    # Share a single embedding model across conditions
    print("Loading embedding model...")
    embedding_model = EmbeddingModel()
    print(f"  Model: {embedding_model.model_name} ({embedding_model.dim}D)")

    all_results: dict[str, list[ScenarioMetrics]] = {}

    for scenario_name in scenarios:
        print(f"\n{'=' * 70}")
        print(f"  SCENARIO: {scenario_name} — {SCENARIOS[scenario_name]}")
        print(f"{'=' * 70}")

        scenario_metrics: list[ScenarioMetrics] = []

        for condition_name in conditions:
            print(f"\n  Condition: {condition_name}")
            pipeline = create_condition(condition_name, embedding_model)

            start = time.perf_counter()

            if scenario_name == "recall":
                results = run_basic_recall(
                    pipeline=pipeline,
                    facts=facts,
                    fillers=fillers,
                    distances=distances,
                    top_k=top_k,
                )
            elif scenario_name == "correction":
                results = run_correction_test(
                    pipeline=pipeline,
                    facts=facts,
                    fillers=fillers,
                    top_k=top_k,
                )
            elif scenario_name == "spreading":
                results = run_spreading_test(
                    pipeline=pipeline,
                    facts=facts,
                    fillers=fillers,
                    top_k=10,  # larger k to see spread-activated results
                )
            elif scenario_name == "rehearsal":
                results = run_rehearsal_test(
                    pipeline=pipeline,
                    facts=facts,
                    fillers=fillers,
                    top_k=top_k,
                )
            elif scenario_name == "multi_session":
                results = run_multi_session(
                    pipeline=pipeline,
                    facts=facts,
                    fillers=fillers,
                    top_k=top_k,
                )
            else:
                print(f"    Unknown scenario: {scenario_name}")
                continue

            elapsed = time.perf_counter() - start
            metrics = compute_metrics(scenario_name, condition_name, results)
            scenario_metrics.append(metrics)

            print(f"    {format_metrics(metrics)}")
            print(f"    Total time: {elapsed:.1f}s")

        all_results[scenario_name] = scenario_metrics

        # Print comparison table
        print(format_comparison(scenario_metrics))

    return all_results


def main():
    parser = argparse.ArgumentParser(description="Run cognitive memory benchmarks")
    parser.add_argument(
        "--scenario", "-s",
        choices=list(SCENARIOS.keys()),
        nargs="+",
        help="Scenarios to run (default: all)",
    )
    parser.add_argument(
        "--condition", "-c",
        choices=ALL_CONDITIONS,
        nargs="+",
        help="Ablation conditions to test (default: all)",
    )
    parser.add_argument(
        "--distances", "-d",
        type=int,
        nargs="+",
        default=[10, 25, 50],
        help="Turn distances to test (default: 10 25 50)",
    )
    parser.add_argument(
        "--top-k", "-k",
        type=int,
        default=5,
        help="Number of results to retrieve (default: 5)",
    )
    args = parser.parse_args()

    run_benchmark(
        scenarios=args.scenario,
        conditions=args.condition,
        distances=args.distances,
        top_k=args.top_k,
    )


if __name__ == "__main__":
    main()
