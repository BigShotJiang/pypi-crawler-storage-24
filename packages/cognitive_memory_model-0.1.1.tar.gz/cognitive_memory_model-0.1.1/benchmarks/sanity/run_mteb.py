"""Run MTEB/BEIR retrieval sanity checks on our embedding model.

This validates that our embedding layer (all-MiniLM-L6-v2) produces
baseline-competitive retrieval results. These results go in the paper's
appendix — they prove competence, not novelty.

Usage:
    python -m benchmarks.sanity.run_mteb
    python -m benchmarks.sanity.run_mteb --tasks SciFact
"""

import argparse
import json
import os

import mteb
from sentence_transformers import SentenceTransformer

# Small, fast BEIR tasks for sanity checking
DEFAULT_TASKS = ["SciFact", "NFCorpus", "ArguAna"]


def run_mteb_sanity(tasks: list[str] | None = None, model_name: str = "all-MiniLM-L6-v2"):
    """Run MTEB retrieval tasks and print results."""
    tasks = tasks or DEFAULT_TASKS

    print(f"Loading model: {model_name}")
    model = SentenceTransformer(model_name)

    print(f"Running MTEB tasks: {tasks}")
    print("(This downloads datasets on first run)\n")

    evaluation = mteb.MTEB(tasks=mteb.get_tasks(tasks=tasks))
    results = evaluation.run(
        model,
        output_folder=os.path.join("benchmarks", "results", "mteb"),
        overwrite_results=True,
    )

    # Print summary
    print("\n" + "=" * 70)
    print(f"  MTEB RETRIEVAL SANITY CHECK — {model_name}")
    print("=" * 70)
    print(f"  {'Task':<20s} {'nDCG@10':>10s} {'Recall@10':>10s}")
    print(f"  {'-' * 42}")

    for result in results:
        task_name = result.task_name
        # Extract the main split scores
        for split, scores in result.scores.items():
            if scores:
                main = scores[0]  # first (usually 'test') hf_subset
                ndcg = main.get("ndcg_at_10", 0)
                recall = main.get("recall_at_10", 0)
                print(f"  {task_name:<20s} {ndcg:>10.4f} {recall:>10.4f}")

    print(f"\n  Note: These scores validate the embedding model, not the")
    print(f"  cognitive memory features. See docs/BENCHMARK_PLAN.md for details.")

    return results


def main():
    parser = argparse.ArgumentParser(description="Run MTEB/BEIR sanity checks")
    parser.add_argument(
        "--tasks", "-t",
        nargs="+",
        default=DEFAULT_TASKS,
        help=f"MTEB tasks to run (default: {DEFAULT_TASKS})",
    )
    parser.add_argument(
        "--model", "-m",
        default="all-MiniLM-L6-v2",
        help="Sentence-transformers model name",
    )
    args = parser.parse_args()

    run_mteb_sanity(tasks=args.tasks, model_name=args.model)


if __name__ == "__main__":
    main()
