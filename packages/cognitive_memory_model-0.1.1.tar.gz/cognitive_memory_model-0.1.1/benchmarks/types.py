"""Data types for the benchmark harness."""

from dataclasses import dataclass, field
from enum import Enum


@dataclass
class FictionalFact:
    """A single fictional fact for benchmarking."""

    id: str
    domain: str
    injection_text: str
    queries: list[str]
    expected_keywords: list[str]
    related_fact_ids: list[str] = field(default_factory=list)
    tags: list[str] = field(default_factory=list)
    is_correction: bool = False
    corrects_fact_id: str | None = None


@dataclass
class FillerTurn:
    """An unrelated conversation turn used to create distance."""

    role: str
    content: str


@dataclass
class RecallResult:
    """Result of a single recall test."""

    fact_id: str
    query: str
    distance: int  # turns between injection and query
    retrieved_texts: list[str]
    retrieved_scores: list[float]
    hit: bool  # did any expected keyword appear in results?
    top_score: float
    latency_ms: float


@dataclass
class ScenarioMetrics:
    """Aggregated metrics for a benchmark scenario."""

    scenario_name: str
    condition_name: str
    total_queries: int = 0
    hits: int = 0
    recall_at_k: float = 0.0
    precision_at_k: float = 0.0
    avg_top_score: float = 0.0
    avg_latency_ms: float = 0.0
    recall_by_distance: dict[int, float] = field(default_factory=dict)
    raw_results: list[RecallResult] = field(default_factory=list)

    def compute(self) -> None:
        """Compute aggregate metrics from raw results."""
        if not self.raw_results:
            return
        self.total_queries = len(self.raw_results)
        self.hits = sum(1 for r in self.raw_results if r.hit)
        self.recall_at_k = self.hits / self.total_queries if self.total_queries else 0.0
        self.avg_top_score = (
            sum(r.top_score for r in self.raw_results) / self.total_queries
        )
        self.avg_latency_ms = (
            sum(r.latency_ms for r in self.raw_results) / self.total_queries
        )

        # Group by distance
        by_dist: dict[int, list[RecallResult]] = {}
        for r in self.raw_results:
            by_dist.setdefault(r.distance, []).append(r)
        self.recall_by_distance = {
            d: sum(1 for r in results if r.hit) / len(results)
            for d, results in sorted(by_dist.items())
        }
