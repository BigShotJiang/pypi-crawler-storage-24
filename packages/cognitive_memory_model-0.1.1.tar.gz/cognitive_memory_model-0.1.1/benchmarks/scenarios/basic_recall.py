"""Basic recall scenario — inject facts, add filler, test recall at various distances."""

import random
import time

from benchmarks.harness.clock import SimulatedClock
from benchmarks.types import FictionalFact, FillerTurn, RecallResult
from cmm.core.types import ConversationTurn, Role
from cmm.pipeline.conversation import CognitiveMemoryPipeline


def run_basic_recall(
    pipeline: CognitiveMemoryPipeline,
    facts: list[FictionalFact],
    fillers: list[FillerTurn],
    distances: list[int] | None = None,
    top_k: int = 5,
    seed: int = 42,
    seconds_per_turn: float = 30.0,
) -> list[RecallResult]:
    """Run the basic recall benchmark.

    For each fact and distance combination:
    1. Inject the fact as a user turn
    2. Add D filler turns (with simulated time progression)
    3. Query with each of the fact's queries
    4. Check if expected keywords appear in retrieved results

    Uses a simulated clock so that temporal decay and rehearsal
    actually differentiate conditions.
    """
    if distances is None:
        distances = [10, 25, 50]

    rng = random.Random(seed)
    results: list[RecallResult] = []

    # Filter out correction facts for basic recall
    base_facts = [f for f in facts if not f.is_correction]

    for distance in distances:
        # Fresh pipeline for each distance to avoid cross-contamination
        # We reuse the same pipeline but all facts accumulate — this is
        # intentional as it tests retrieval with growing store size.

        # Set up simulated clock
        clock = SimulatedClock(seconds_per_tick=seconds_per_turn)
        pipeline.retriever.clock = clock

        for fact in base_facts:
            # Inject the fact with a simulated timestamp
            turn = ConversationTurn(
                role=Role.USER,
                content=fact.injection_text,
                timestamp=clock.current_time,
            )
            pipeline.process_turn(turn)
            clock.tick()

            # Add filler turns to create distance
            for i in range(distance):
                filler = rng.choice(fillers)
                filler_turn = ConversationTurn(
                    role=Role(filler.role),
                    content=filler.content,
                    timestamp=clock.current_time,
                )
                pipeline.process_turn(filler_turn)
                clock.tick()

            # Query with each of the fact's queries
            for query in fact.queries:
                start_time = time.perf_counter()
                retrieved = pipeline.recall(query, top_k=top_k)
                elapsed_ms = (time.perf_counter() - start_time) * 1000

                retrieved_texts = [r.memory.gist.text.lower() for r in retrieved]
                retrieved_scores = [r.final_score for r in retrieved]
                combined_text = " ".join(retrieved_texts)

                # Check if any expected keyword appears in results
                hit = any(
                    kw.lower() in combined_text
                    for kw in fact.expected_keywords
                )

                results.append(RecallResult(
                    fact_id=fact.id,
                    query=query,
                    distance=distance,
                    retrieved_texts=retrieved_texts,
                    retrieved_scores=retrieved_scores,
                    hit=hit,
                    top_score=retrieved_scores[0] if retrieved_scores else 0.0,
                    latency_ms=elapsed_ms,
                ))

    # Reset clock to real time
    pipeline.retriever.clock = time.time

    return results
