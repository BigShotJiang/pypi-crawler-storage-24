"""Multi-session conversation scenario — realistic multi-session agent usage.

Simulates a user interacting with an agent over multiple sessions:
- Session 1: Extended discussion on Topic A (inject facts naturally)
- Session 2-3: Different topics (B, C)
- Session 4: Callback to Topic A — test cross-session recall
- Session 5: Mix of topics — test spreading activation across sessions
- Session 6: Corrections and preference updates
- Session 7: Final comprehensive recall test

This tests the full cognitive pipeline: encoding, decay, consolidation,
spreading activation, priming, importance, and metamemory.
"""

import random
import time

from benchmarks.harness.clock import SimulatedClock
from benchmarks.types import FictionalFact, FillerTurn, RecallResult
from cmm.core.types import ConversationTurn, Role
from cmm.pipeline.conversation import CognitiveMemoryPipeline


def _inject(pipeline, clock, role, content):
    """Helper: inject a turn with simulated timestamp."""
    turn = ConversationTurn(
        role=Role(role), content=content, timestamp=clock.current_time
    )
    pipeline.process_turn(turn)
    clock.tick()


def _inject_filler(pipeline, clock, fillers, rng, count):
    """Helper: inject N random filler turns."""
    for _ in range(count):
        f = rng.choice(fillers)
        _inject(pipeline, clock, f.role, f.content)


def run_multi_session(
    pipeline: CognitiveMemoryPipeline,
    facts: list[FictionalFact],
    fillers: list[FillerTurn],
    top_k: int = 5,
    seed: int = 42,
    seconds_per_turn: float = 60.0,
    session_gap_hours: float = 4.0,
) -> list[RecallResult]:
    """Run the multi-session benchmark.

    Simulates 7 sessions spread over several days, with session gaps.
    Tests cross-session recall, consolidation, corrections, and preferences.
    """
    rng = random.Random(seed)
    results: list[RecallResult] = []
    clock = SimulatedClock(seconds_per_tick=seconds_per_turn)
    pipeline.retriever.clock = clock

    fact_map = {f.id: f for f in facts}
    base_facts = [f for f in facts if not f.is_correction]
    corrections = [f for f in facts if f.is_correction]
    by_domain = {}
    for f in base_facts:
        by_domain.setdefault(f.domain, []).append(f)

    # === SESSION 1: Marine biology deep dive ===
    marine_facts = by_domain.get("marine biology", [])
    for f in marine_facts:
        _inject(pipeline, clock, "user", f.injection_text)
        _inject(pipeline, clock, "assistant", f"That's interesting. Let me note that: {f.injection_text[:80]}...")
    _inject_filler(pipeline, clock, fillers, rng, 10)
    pipeline.end_session()

    # Session gap (4 hours)
    for _ in range(int(session_gap_hours * 3600 / seconds_per_turn)):
        clock.tick()

    # === SESSION 2: Technology discussion ===
    tech_facts = by_domain.get("technology", [])
    for f in tech_facts:
        _inject(pipeline, clock, "user", f.injection_text)
        _inject(pipeline, clock, "assistant", f"Got it. {f.injection_text[:60]}...")
    _inject_filler(pipeline, clock, fillers, rng, 15)
    pipeline.end_session()

    for _ in range(int(session_gap_hours * 3600 / seconds_per_turn)):
        clock.tick()

    # === SESSION 3: Geography + Astronomy ===
    for domain in ["geography", "astronomy"]:
        for f in by_domain.get(domain, []):
            _inject(pipeline, clock, "user", f.injection_text)
    _inject_filler(pipeline, clock, fillers, rng, 10)
    pipeline.end_session()

    for _ in range(int(session_gap_hours * 3600 / seconds_per_turn)):
        clock.tick()

    # === SESSION 4: People + User preferences ===
    for domain in ["people", "user_preferences"]:
        for f in by_domain.get(domain, []):
            _inject(pipeline, clock, "user", f.injection_text)
    _inject_filler(pipeline, clock, fillers, rng, 10)
    pipeline.end_session()

    for _ in range(int(session_gap_hours * 3600 / seconds_per_turn)):
        clock.tick()

    # === SESSION 5: Cross-domain connections + Medicine ===
    for domain in ["cross-domain", "medicine"]:
        for f in by_domain.get(domain, []):
            _inject(pipeline, clock, "user", f.injection_text)
    _inject_filler(pipeline, clock, fillers, rng, 10)

    # Run consolidation mid-way
    pipeline.consolidate()
    pipeline.end_session()

    for _ in range(int(session_gap_hours * 3600 / seconds_per_turn)):
        clock.tick()

    # === SESSION 6: Corrections ===
    for c in corrections:
        _inject(pipeline, clock, "user", c.injection_text)
    _inject_filler(pipeline, clock, fillers, rng, 15)
    pipeline.end_session()

    # Longer gap before final test (overnight — 12 hours)
    for _ in range(int(12 * 3600 / seconds_per_turn)):
        clock.tick()

    # === SESSION 7: Comprehensive recall test ===
    # Test 1: Basic cross-session recall (facts from session 1, now 2+ days ago)
    for f in marine_facts[:3]:
        for query in f.queries:
            result = _query_and_measure(pipeline, f, query, "cross_session_recall")
            results.append(result)

    # Test 2: User preference recall
    for f in by_domain.get("user_preferences", []):
        for query in f.queries:
            result = _query_and_measure(pipeline, f, query, "preference_recall")
            results.append(result)

    # Test 3: Cross-domain spreading (query about one domain should activate linked facts)
    for f in by_domain.get("cross-domain", []):
        for query in f.queries:
            result = _query_and_measure(pipeline, f, query, "cross_domain_spread")
            results.append(result)

    # Test 4: Correction accuracy (corrected facts should outrank originals)
    for c in corrections:
        for query in c.queries:
            result = _query_and_measure(pipeline, c, query, "correction_accuracy")
            results.append(result)

    # Test 5: Recall of facts from every domain
    for domain, domain_facts in by_domain.items():
        if domain in ("cross-domain", "user_preferences"):
            continue
        f = domain_facts[0]
        query = f.queries[0]
        result = _query_and_measure(pipeline, f, query, "broad_domain_recall")
        results.append(result)

    pipeline.retriever.clock = time.time
    return results


def _query_and_measure(
    pipeline: CognitiveMemoryPipeline,
    fact: FictionalFact,
    query: str,
    test_name: str,
    top_k: int = 5,
) -> RecallResult:
    """Query the pipeline and measure against expected keywords."""
    start = time.perf_counter()
    retrieved = pipeline.recall(query, top_k=top_k)
    elapsed_ms = (time.perf_counter() - start) * 1000

    retrieved_texts = [r.memory.gist.text.lower() for r in retrieved]
    retrieved_scores = [r.final_score for r in retrieved]
    combined = " ".join(retrieved_texts)

    hit = any(kw.lower() in combined for kw in fact.expected_keywords)

    return RecallResult(
        fact_id=f"{test_name}|{fact.id}",
        query=query,
        distance=0,  # not applicable for multi-session
        retrieved_texts=retrieved_texts,
        retrieved_scores=retrieved_scores,
        hit=hit,
        top_score=retrieved_scores[0] if retrieved_scores else 0.0,
        latency_ms=elapsed_ms,
    )
