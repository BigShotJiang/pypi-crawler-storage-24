"""Rehearsal scenario — test whether repeatedly accessed facts resist decay better."""

import random
import time

from benchmarks.harness.clock import SimulatedClock
from benchmarks.types import FictionalFact, FillerTurn, RecallResult
from cmm.core.types import ConversationTurn, Role
from cmm.pipeline.conversation import CognitiveMemoryPipeline


def run_rehearsal_test(
    pipeline: CognitiveMemoryPipeline,
    facts: list[FictionalFact],
    fillers: list[FillerTurn],
    rehearsal_count: int = 3,
    rehearsal_interval: int = 20,
    post_rehearsal_gap: int = 50,
    top_k: int = 5,
    seed: int = 42,
    seconds_per_turn: float = 30.0,
) -> list[RecallResult]:
    """Run the rehearsal benchmark.

    Tests whether repeatedly accessed memories resist decay better.

    Design:
    - Take pairs of similar facts from the same domain
    - Inject both at the same time
    - Rehearse fact A by querying it periodically (rehearsal_count times)
    - Do NOT rehearse fact B
    - After a long gap, query both
    - Fact A (rehearsed) should score higher than fact B (unrehearsed)

    Returns RecallResults where each result is tagged with whether
    the fact was rehearsed or not (encoded in fact_id suffix).
    """
    rng = random.Random(seed)
    results: list[RecallResult] = []

    base_facts = [f for f in facts if not f.is_correction]

    # Group facts by domain and take pairs
    by_domain: dict[str, list[FictionalFact]] = {}
    for f in base_facts:
        by_domain.setdefault(f.domain, []).append(f)

    pairs: list[tuple[FictionalFact, FictionalFact]] = []
    for domain_facts in by_domain.values():
        for i in range(0, len(domain_facts) - 1, 2):
            pairs.append((domain_facts[i], domain_facts[i + 1]))

    clock = SimulatedClock(seconds_per_tick=seconds_per_turn)
    pipeline.retriever.clock = clock

    for fact_a, fact_b in pairs:
        # Inject both facts at the same time
        pipeline.process_turn(ConversationTurn(
            role=Role.USER, content=fact_a.injection_text, timestamp=clock.current_time
        ))
        clock.tick()
        pipeline.process_turn(ConversationTurn(
            role=Role.USER, content=fact_b.injection_text, timestamp=clock.current_time
        ))
        clock.tick()

        # Rehearse fact A periodically
        for r in range(rehearsal_count):
            # Add filler between rehearsals
            for _ in range(rehearsal_interval):
                filler = rng.choice(fillers)
                pipeline.process_turn(ConversationTurn(
                    role=Role(filler.role), content=filler.content, timestamp=clock.current_time
                ))
                clock.tick()

            # Rehearse fact A by querying it
            pipeline.recall(fact_a.queries[0])

        # Post-rehearsal gap — both facts age equally from here
        for _ in range(post_rehearsal_gap):
            filler = rng.choice(fillers)
            pipeline.process_turn(ConversationTurn(
                role=Role(filler.role), content=filler.content, timestamp=clock.current_time
            ))
            clock.tick()

        total_distance = rehearsal_count * rehearsal_interval + post_rehearsal_gap

        # Query both facts
        for fact, rehearsed in [(fact_a, True), (fact_b, False)]:
            for query in fact.queries[:1]:
                start_time = time.perf_counter()
                retrieved = pipeline.recall(query, top_k=top_k)
                elapsed_ms = (time.perf_counter() - start_time) * 1000

                retrieved_texts = [r.memory.gist.text.lower() for r in retrieved]
                retrieved_scores = [r.final_score for r in retrieved]
                combined_text = " ".join(retrieved_texts)

                hit = any(
                    kw.lower() in combined_text
                    for kw in fact.expected_keywords
                )

                results.append(RecallResult(
                    fact_id=f"{fact.id}|{'rehearsed' if rehearsed else 'unrehearsed'}",
                    query=query,
                    distance=total_distance,
                    retrieved_texts=retrieved_texts,
                    retrieved_scores=retrieved_scores,
                    hit=hit,
                    top_score=retrieved_scores[0] if retrieved_scores else 0.0,
                    latency_ms=elapsed_ms,
                ))

    pipeline.retriever.clock = time.time
    return results
