"""Spreading activation scenario — test whether querying one fact activates related facts.

Two test types:
1. Same-cluster: related facts that share some keywords (existing behavior)
2. Bridge-chain: A→B→C where A and C share NO keywords, connected only through B.
   This is the real test of spreading activation — flat retrieval cannot find C from A.
"""

import random
import time

from benchmarks.harness.clock import SimulatedClock
from benchmarks.types import FictionalFact, FillerTurn, RecallResult
from cmm.core.types import ConversationTurn, Role
from cmm.pipeline.conversation import CognitiveMemoryPipeline


# Bridge chain definitions: (query_fact, bridge_fact, target_fact)
# Query about query_fact → spreading should reach bridge_fact → target_fact
BRIDGE_CHAINS = [
    {
        "name": "wheat→kelp→food_prize",
        "query_fact_id": "bridge_a1",
        "bridge_fact_id": "bridge_b1",
        "target_fact_id": "bridge_c1",
        "query": "Tell me about Halverton wheat",
        "bridge_keywords": ["kenyatta", "yuki tanaka", "kelp"],
        "target_keywords": ["geneva", "food innovation prize"],
    },
    {
        "name": "tensorite→glider→pacific_flight",
        "query_fact_id": "bridge_a2",
        "bridge_fact_id": "bridge_b2",
        "target_fact_id": "bridge_c2",
        "query": "What is Tensorite carbon fiber?",
        "bridge_keywords": ["haruki sato", "glider", "sato aerospace"],
        "target_keywords": ["72-hour", "pacific", "solar"],
    },
    {
        "name": "vaeluri→cognition→neuroscience",
        "query_fact_id": "bridge_a3",
        "bridge_fact_id": "bridge_b3",
        "target_fact_id": "bridge_c3",
        "query": "Tell me about the Vaeluri language",
        "bridge_keywords": ["spatial reasoning", "sanne de vries"],
        "target_keywords": ["neurological", "brain imaging"],
    },
]


def run_spreading_test(
    pipeline: CognitiveMemoryPipeline,
    facts: list[FictionalFact],
    fillers: list[FillerTurn],
    filler_gap: int = 30,
    top_k: int = 10,
    seed: int = 42,
    seconds_per_turn: float = 30.0,
) -> list[RecallResult]:
    """Run the spreading activation benchmark.

    Tests both same-cluster spreading (existing) and bridge-chain spreading (new).
    Bridge chains are the key test: flat retrieval cannot find the target fact
    from the query because they share no keywords. Only spreading activation
    through the bridge fact can activate the target.
    """
    rng = random.Random(seed)
    results: list[RecallResult] = []

    base_facts = [f for f in facts if not f.is_correction]
    fact_map = {f.id: f for f in base_facts}

    clock = SimulatedClock(seconds_per_tick=seconds_per_turn)
    pipeline.retriever.clock = clock

    # --- Part 1: Same-cluster spreading (existing test) ---
    visited = set()
    groups: list[list[FictionalFact]] = []
    for f in base_facts:
        if f.id in visited or not f.related_fact_ids:
            continue
        # Only include non-bridge facts in cluster test
        if f.id.startswith("bridge_"):
            continue
        group = [f]
        visited.add(f.id)
        for rid in f.related_fact_ids:
            if rid in fact_map and rid not in visited and not rid.startswith("bridge_"):
                group.append(fact_map[rid])
                visited.add(rid)
        if len(group) >= 2:
            groups.append(group)

    for group in groups:
        for fact in group:
            pipeline.process_turn(ConversationTurn(
                role=Role.USER, content=fact.injection_text, timestamp=clock.current_time
            ))
            clock.tick()
            for _ in range(filler_gap // len(group)):
                filler = rng.choice(fillers)
                pipeline.process_turn(ConversationTurn(
                    role=Role(filler.role), content=filler.content, timestamp=clock.current_time
                ))
                clock.tick()

        seed_fact = group[0]
        related_facts = group[1:]

        for query in seed_fact.queries[:1]:
            start_time = time.perf_counter()
            retrieved = pipeline.recall(query, top_k=top_k)
            elapsed_ms = (time.perf_counter() - start_time) * 1000

            retrieved_texts = [r.memory.gist.text.lower() for r in retrieved]
            retrieved_scores = [r.final_score for r in retrieved]
            combined_text = " ".join(retrieved_texts)

            for related in related_facts:
                hit = any(kw.lower() in combined_text for kw in related.expected_keywords)
                results.append(RecallResult(
                    fact_id=f"cluster|{seed_fact.id}->{related.id}",
                    query=query,
                    distance=filler_gap,
                    retrieved_texts=retrieved_texts,
                    retrieved_scores=retrieved_scores,
                    hit=hit,
                    top_score=retrieved_scores[0] if retrieved_scores else 0.0,
                    latency_ms=elapsed_ms,
                ))

    # --- Part 2: Bridge-chain spreading ---
    # Inject all bridge facts with generous filler between them
    bridge_fact_ids = set()
    for chain in BRIDGE_CHAINS:
        for key in ["query_fact_id", "bridge_fact_id", "target_fact_id"]:
            bridge_fact_ids.add(chain[key])

    for fid in sorted(bridge_fact_ids):
        fact = fact_map.get(fid)
        if not fact:
            continue
        pipeline.process_turn(ConversationTurn(
            role=Role.USER, content=fact.injection_text, timestamp=clock.current_time
        ))
        clock.tick()
        # Add filler between bridge facts to separate them
        for _ in range(15):
            filler = rng.choice(fillers)
            pipeline.process_turn(ConversationTurn(
                role=Role(filler.role), content=filler.content, timestamp=clock.current_time
            ))
            clock.tick()

    # Now query each chain
    for chain in BRIDGE_CHAINS:
        query = chain["query"]

        start_time = time.perf_counter()
        retrieved = pipeline.recall(query, top_k=top_k)
        elapsed_ms = (time.perf_counter() - start_time) * 1000

        retrieved_texts = [r.memory.gist.text.lower() for r in retrieved]
        retrieved_scores = [r.final_score for r in retrieved]
        combined_text = " ".join(retrieved_texts)

        # Check if bridge fact was activated (1-hop)
        bridge_hit = any(kw.lower() in combined_text for kw in chain["bridge_keywords"])
        results.append(RecallResult(
            fact_id=f"bridge_1hop|{chain['name']}",
            query=query,
            distance=filler_gap,
            retrieved_texts=retrieved_texts,
            retrieved_scores=retrieved_scores,
            hit=bridge_hit,
            top_score=retrieved_scores[0] if retrieved_scores else 0.0,
            latency_ms=elapsed_ms,
        ))

        # Check if target fact was activated (2-hop or via bridge spreading)
        target_hit = any(kw.lower() in combined_text for kw in chain["target_keywords"])
        results.append(RecallResult(
            fact_id=f"bridge_target|{chain['name']}",
            query=query,
            distance=filler_gap,
            retrieved_texts=retrieved_texts,
            retrieved_scores=retrieved_scores,
            hit=target_hit,
            top_score=retrieved_scores[0] if retrieved_scores else 0.0,
            latency_ms=elapsed_ms,
        ))

    pipeline.retriever.clock = time.time
    return results
