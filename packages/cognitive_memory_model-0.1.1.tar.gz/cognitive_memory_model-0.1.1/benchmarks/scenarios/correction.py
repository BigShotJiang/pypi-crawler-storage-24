"""Correction scenario — inject fact, correct it, test which version is recalled."""

import random
import time

from benchmarks.harness.clock import SimulatedClock
from benchmarks.types import FictionalFact, FillerTurn, RecallResult
from cmm.core.types import ConversationTurn, Role
from cmm.pipeline.conversation import CognitiveMemoryPipeline


def run_correction_test(
    pipeline: CognitiveMemoryPipeline,
    facts: list[FictionalFact],
    fillers: list[FillerTurn],
    gap_before_correction: int = 20,
    gap_after_correction: int = 30,
    top_k: int = 5,
    seed: int = 42,
    seconds_per_turn: float = 30.0,
) -> list[RecallResult]:
    """Run the correction benchmark.

    For each correction fact:
    1. Inject the original (wrong) fact
    2. Add gap_before_correction filler turns
    3. Inject the correction
    4. Add gap_after_correction filler turns
    5. Query — the corrected version should rank above the original
    """
    rng = random.Random(seed)
    results: list[RecallResult] = []

    corrections = [f for f in facts if f.is_correction]
    fact_map = {f.id: f for f in facts}

    clock = SimulatedClock(seconds_per_tick=seconds_per_turn)
    pipeline.retriever.clock = clock

    for correction in corrections:
        original = fact_map.get(correction.corrects_fact_id)
        if not original:
            continue

        # Inject original fact
        turn = ConversationTurn(
            role=Role.USER, content=original.injection_text, timestamp=clock.current_time
        )
        pipeline.process_turn(turn)
        clock.tick()

        # Filler gap
        for _ in range(gap_before_correction):
            filler = rng.choice(fillers)
            pipeline.process_turn(ConversationTurn(
                role=Role(filler.role), content=filler.content, timestamp=clock.current_time
            ))
            clock.tick()

        # Inject correction
        pipeline.process_turn(ConversationTurn(
            role=Role.USER, content=correction.injection_text, timestamp=clock.current_time
        ))
        clock.tick()

        # More filler
        for _ in range(gap_after_correction):
            filler = rng.choice(fillers)
            pipeline.process_turn(ConversationTurn(
                role=Role(filler.role), content=filler.content, timestamp=clock.current_time
            ))
            clock.tick()

        total_distance = gap_before_correction + gap_after_correction + 2

        for query in correction.queries:
            start_time = time.perf_counter()
            retrieved = pipeline.recall(query, top_k=top_k)
            elapsed_ms = (time.perf_counter() - start_time) * 1000

            retrieved_texts = [r.memory.gist.text.lower() for r in retrieved]
            retrieved_scores = [r.final_score for r in retrieved]
            combined_text = " ".join(retrieved_texts)

            hit = any(
                kw.lower() in combined_text
                for kw in correction.expected_keywords
            )

            results.append(RecallResult(
                fact_id=correction.id,
                query=query,
                distance=total_distance,
                retrieved_texts=retrieved_texts,
                retrieved_scores=retrieved_scores,
                hit=hit,
                top_score=retrieved_scores[0] if retrieved_scores else 0.0,
                latency_ms=elapsed_ms,
            ))

    pipeline.retriever.clock = time.time
    return results
