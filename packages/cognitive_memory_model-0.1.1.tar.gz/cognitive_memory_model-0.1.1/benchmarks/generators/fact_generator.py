"""Generates fictional facts and filler conversation turns for benchmarks."""

import json
import os
import random
from pathlib import Path

from benchmarks.types import FictionalFact, FillerTurn

DATA_DIR = Path(__file__).parent.parent / "data"

# Filler conversation turns — diverse topics to create distance between facts
FILLER_TURNS: list[dict] = [
    {"role": "user", "content": "Can you help me write a Python function to sort a list of dictionaries by a specific key?"},
    {"role": "assistant", "content": "Sure! You can use the sorted() function with a lambda as the key parameter."},
    {"role": "user", "content": "What's the difference between a list comprehension and a generator expression?"},
    {"role": "assistant", "content": "List comprehensions create the full list in memory, while generators produce items lazily."},
    {"role": "user", "content": "How do I handle exceptions in async Python code?"},
    {"role": "assistant", "content": "You can use try/except blocks inside async functions, or use asyncio.gather with return_exceptions=True."},
    {"role": "user", "content": "What are the best practices for writing REST API endpoints?"},
    {"role": "assistant", "content": "Use proper HTTP methods, return appropriate status codes, and version your API."},
    {"role": "user", "content": "Can you explain how CSS flexbox works?"},
    {"role": "assistant", "content": "Flexbox is a layout model that lets you align items along a main axis and cross axis."},
    {"role": "user", "content": "What's the best way to optimize a SQL query?"},
    {"role": "assistant", "content": "Start with EXPLAIN ANALYZE, add indexes on filtered columns, and avoid SELECT *."},
    {"role": "user", "content": "How do I deploy a containerized app to Kubernetes?"},
    {"role": "assistant", "content": "Create a deployment manifest, build a Docker image, push to a registry, and apply with kubectl."},
    {"role": "user", "content": "What's new in React 19?"},
    {"role": "assistant", "content": "React 19 includes the new compiler, server components improvements, and Actions for forms."},
    {"role": "user", "content": "How do I set up CI/CD with GitHub Actions?"},
    {"role": "assistant", "content": "Create a workflow YAML file in .github/workflows/ with your build, test, and deploy steps."},
    {"role": "user", "content": "Can you explain the CAP theorem?"},
    {"role": "assistant", "content": "CAP theorem states a distributed system can only guarantee two of: consistency, availability, partition tolerance."},
    {"role": "user", "content": "What's the difference between TCP and UDP?"},
    {"role": "assistant", "content": "TCP provides reliable, ordered delivery with handshaking. UDP is faster but unreliable."},
    {"role": "user", "content": "How do I implement authentication with JWT tokens?"},
    {"role": "assistant", "content": "Generate a signed JWT on login, include it in the Authorization header, and verify on each request."},
    {"role": "user", "content": "What are design patterns I should know?"},
    {"role": "assistant", "content": "Start with Singleton, Factory, Observer, Strategy, and Decorator patterns."},
    {"role": "user", "content": "How does garbage collection work in Java?"},
    {"role": "assistant", "content": "Java uses generational GC with young and old generations, with mark-sweep-compact cycles."},
    {"role": "user", "content": "Can you explain microservices architecture?"},
    {"role": "assistant", "content": "Microservices break an application into small, independent services that communicate via APIs."},
    {"role": "user", "content": "What's the best way to handle state in a React app?"},
    {"role": "assistant", "content": "Use useState for local state, Context for shared state, and external stores for complex state."},
    {"role": "user", "content": "How do I use Git rebase effectively?"},
    {"role": "assistant", "content": "Rebase rewrites commit history. Use interactive rebase to squash, reorder, or edit commits."},
    {"role": "user", "content": "What are good practices for error logging?"},
    {"role": "assistant", "content": "Use structured logging, include context, set appropriate log levels, and aggregate centrally."},
    {"role": "user", "content": "How do I optimize images for web performance?"},
    {"role": "assistant", "content": "Use WebP/AVIF formats, lazy loading, responsive images with srcset, and a CDN."},
    {"role": "user", "content": "What is the difference between a mutex and a semaphore?"},
    {"role": "assistant", "content": "A mutex allows one thread at a time. A semaphore allows a configurable number of concurrent accesses."},
    {"role": "user", "content": "How do I profile memory usage in a Python application?"},
    {"role": "assistant", "content": "Use tracemalloc, memory_profiler, or objgraph to track allocations and identify leaks."},
    {"role": "user", "content": "Can you explain event sourcing?"},
    {"role": "assistant", "content": "Event sourcing stores state changes as a sequence of events rather than updating current state directly."},
    {"role": "user", "content": "What's the difference between horizontal and vertical scaling?"},
    {"role": "assistant", "content": "Horizontal scaling adds more machines. Vertical scaling adds more resources to existing machines."},
    {"role": "user", "content": "How does TLS 1.3 improve on TLS 1.2?"},
    {"role": "assistant", "content": "TLS 1.3 removes legacy ciphers, uses fewer round trips, and makes encryption mandatory."},
    {"role": "user", "content": "What is consistent hashing used for?"},
    {"role": "assistant", "content": "Consistent hashing distributes keys across nodes so that adding or removing a node only moves a minimal number of keys."},
    {"role": "user", "content": "How do I write effective integration tests?"},
    {"role": "assistant", "content": "Test real interactions between components, use test databases, and focus on critical paths."},
    {"role": "user", "content": "Can you explain the difference between gRPC and REST?"},
    {"role": "assistant", "content": "gRPC uses HTTP/2, Protocol Buffers, and supports streaming. REST uses HTTP/1.1 and JSON."},
]


def load_facts(path: str | None = None) -> list[FictionalFact]:
    """Load fictional facts from JSON file."""
    if path is None:
        path = str(DATA_DIR / "facts.json")

    with open(path) as f:
        data = json.load(f)

    facts = []
    for d in data:
        if d.get("_comment"):
            pass  # skip comment-only entries (they still have other fields)
        facts.append(FictionalFact(
            id=d["id"],
            domain=d["domain"],
            injection_text=d["injection_text"],
            queries=d["queries"],
            expected_keywords=d["expected_keywords"],
            related_fact_ids=d.get("related_fact_ids", []),
            tags=d.get("tags", []),
            is_correction=d.get("is_correction", False),
            corrects_fact_id=d.get("corrects_fact_id"),
        ))
    return facts


def load_fillers() -> list[FillerTurn]:
    """Load filler conversation turns."""
    return [FillerTurn(**d) for d in FILLER_TURNS]


def save_facts_json(facts: list[FictionalFact], path: str) -> None:
    """Save facts to a JSON file for reproducibility."""
    data = []
    for f in facts:
        data.append({
            "id": f.id,
            "domain": f.domain,
            "injection_text": f.injection_text,
            "queries": f.queries,
            "expected_keywords": f.expected_keywords,
            "related_fact_ids": f.related_fact_ids,
            "tags": f.tags,
            "is_correction": f.is_correction,
            "corrects_fact_id": f.corrects_fact_id,
        })
    with open(path, "w") as fh:
        json.dump(data, fh, indent=2)


def get_fact_stats(facts: list[FictionalFact] | None = None) -> dict:
    """Print statistics about the fact set."""
    if facts is None:
        facts = load_facts()

    base = [f for f in facts if not f.is_correction]
    corrections = [f for f in facts if f.is_correction]
    related = [f for f in base if f.related_fact_ids]
    domains = set(f.domain for f in base)

    # Count clusters
    visited = set()
    clusters = 0
    for f in base:
        if f.id not in visited and f.related_fact_ids:
            clusters += 1
            visited.add(f.id)
            for rid in f.related_fact_ids:
                visited.add(rid)

    return {
        "total_facts": len(facts),
        "base_facts": len(base),
        "corrections": len(corrections),
        "domains": len(domains),
        "domain_names": sorted(domains),
        "facts_with_relations": len(related),
        "related_clusters": clusters,
        "total_queries": sum(len(f.queries) for f in facts),
    }
