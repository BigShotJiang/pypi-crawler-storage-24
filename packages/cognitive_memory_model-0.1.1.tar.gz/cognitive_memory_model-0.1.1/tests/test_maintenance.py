"""Tests for memory maintenance — pruning, deduplication, and health metrics."""

import time

import numpy as np
import pytest

from cmm.core.memory_store import MemoryStore
from cmm.core.types import Gist, Memory, MemoryType
from cmm.maintenance.maintenance import MemoryMaintainer
from cmm.pipeline.conversation import CognitiveMemoryPipeline
from cmm.retrieval.decay import DecayScorer, SECONDS_PER_DAY
from tests.conftest import get_shared_model


def make_embedding(dim=32, seed=None):
    rng = np.random.RandomState(seed)
    v = rng.randn(dim).astype(np.float32)
    return v / np.linalg.norm(v)


class TestPruning:
    def test_prune_old_low_importance(self):
        """Old, low-importance memories should be pruned."""
        store = MemoryStore(dim=32)
        # No grace period, aggressive decay for testing pruning logic
        scorer = DecayScorer(grace_period=0, decay_rate=1e-4)
        maintainer = MemoryMaintainer(store=store, decay_scorer=scorer)

        mem = store.store(gist=Gist(text="old junk"), embedding=make_embedding(32, seed=1))
        mem.timestamp -= 60 * SECONDS_PER_DAY  # 60 days old
        mem.last_accessed -= 60 * SECONDS_PER_DAY
        mem.importance = 0.5

        assert store.size == 1
        pruned = maintainer.prune()
        assert pruned == 1
        assert store.size == 0

    def test_high_importance_survives_pruning(self):
        """High-importance memories should not be pruned regardless of age."""
        store = MemoryStore(dim=32)
        scorer = DecayScorer(grace_period=0, decay_rate=1e-4)
        maintainer = MemoryMaintainer(store=store, decay_scorer=scorer)

        mem = store.store(
            gist=Gist(text="important instruction"),
            embedding=make_embedding(32, seed=1),
            importance=2.0,
        )
        mem.timestamp -= 60 * SECONDS_PER_DAY
        mem.last_accessed -= 60 * SECONDS_PER_DAY

        pruned = maintainer.prune()
        assert pruned == 0
        assert store.size == 1

    def test_recently_accessed_survives(self):
        """Recently accessed memories should not be pruned — within grace period."""
        store = MemoryStore(dim=32)
        scorer = DecayScorer(grace_period=14 * SECONDS_PER_DAY, decay_rate=1e-4)
        maintainer = MemoryMaintainer(store=store, decay_scorer=scorer)

        mem = store.store(
            gist=Gist(text="recently used"),
            embedding=make_embedding(32, seed=1),
            importance=0.5,
        )
        mem.timestamp -= 60 * SECONDS_PER_DAY
        mem.last_accessed = time.time()  # accessed just now — within grace

        pruned = maintainer.prune()
        assert pruned == 0
        assert store.size == 1

    def test_retrieval_works_after_prune(self):
        """FAISS index should work correctly after pruning and rebuild."""
        store = MemoryStore(dim=32)
        scorer = DecayScorer(grace_period=0, decay_rate=1e-4)
        maintainer = MemoryMaintainer(store=store, decay_scorer=scorer)

        for i in range(5):
            mem = store.store(
                gist=Gist(text=f"item-{i}"),
                embedding=make_embedding(32, seed=i),
                importance=0.5,
            )
            if i < 2:
                mem.timestamp -= 60 * SECONDS_PER_DAY
                mem.last_accessed -= 60 * SECONDS_PER_DAY

        assert store.size == 5
        pruned = maintainer.prune()
        assert pruned == 2
        assert store.size == 3

        results = store.retrieve(make_embedding(32, seed=2), top_k=3, threshold=-1.0)
        assert len(results) == 3


class TestDeduplication:
    def test_merge_near_duplicates(self):
        """Near-duplicate memories should be merged."""
        store = MemoryStore(dim=32)
        maintainer = MemoryMaintainer(store=store, duplicate_threshold=0.95)

        # Store two nearly identical embeddings
        base = make_embedding(32, seed=42)
        almost_same = base + 0.01 * make_embedding(32, seed=43)
        almost_same = almost_same / np.linalg.norm(almost_same)

        store.store(gist=Gist(text="first version"), embedding=base, importance=1.0)
        store.store(gist=Gist(text="second version"), embedding=almost_same, importance=1.5)

        assert store.size == 2
        merged = maintainer.deduplicate()
        assert merged == 1
        assert store.size == 1

        # The higher-importance one should survive
        survivor = list(store._memories.values())[0]
        assert survivor.importance == 1.5

    def test_different_memories_not_merged(self):
        """Dissimilar memories should not be merged."""
        store = MemoryStore(dim=32)
        maintainer = MemoryMaintainer(store=store, duplicate_threshold=0.95)

        store.store(gist=Gist(text="zebras"), embedding=make_embedding(32, seed=1))
        store.store(gist=Gist(text="python"), embedding=make_embedding(32, seed=2))

        merged = maintainer.deduplicate()
        assert merged == 0
        assert store.size == 2

    def test_access_count_transferred(self):
        """Merged memories should accumulate access counts."""
        store = MemoryStore(dim=32)
        maintainer = MemoryMaintainer(store=store, duplicate_threshold=0.95)

        base = make_embedding(32, seed=42)
        almost_same = base + 0.001 * make_embedding(32, seed=43)
        almost_same = almost_same / np.linalg.norm(almost_same)

        m1 = store.store(gist=Gist(text="first"), embedding=base, importance=1.0)
        m2 = store.store(gist=Gist(text="second"), embedding=almost_same, importance=1.0)
        m1.access_count = 5
        m2.access_count = 3

        maintainer.deduplicate()
        survivor = list(store._memories.values())[0]
        assert survivor.access_count == 8


class TestHealthMetrics:
    def test_health_metrics(self):
        store = MemoryStore(dim=32)
        maintainer = MemoryMaintainer(store=store)

        store.store(gist=Gist(text="ep1"), embedding=make_embedding(32, seed=1), importance=1.0)
        store.store(gist=Gist(text="ep2"), embedding=make_embedding(32, seed=2), importance=1.5)
        store.store(
            gist=Gist(text="sem1"), embedding=make_embedding(32, seed=3),
            importance=2.0, memory_type=MemoryType.SEMANTIC,
        )

        metrics = maintainer.get_health_metrics()
        assert metrics.total_memories == 3
        assert metrics.episodic_count == 2
        assert metrics.semantic_count == 1
        assert metrics.avg_importance == pytest.approx(1.5)

    def test_empty_store_metrics(self):
        store = MemoryStore(dim=32)
        maintainer = MemoryMaintainer(store=store)
        metrics = maintainer.get_health_metrics()
        assert metrics.total_memories == 0


class TestMaintenanceInPipeline:
    def test_pipeline_maintain(self):
        """Pipeline maintain() should prune and deduplicate."""
        pipeline = CognitiveMemoryPipeline(
            embedding_model=get_shared_model(),
            retriever_threshold=0.0,
            decay_grace_period=0,  # disable grace for testing
            decay_rate=1e-4,      # aggressive for testing
        )

        # Store some content
        pipeline.ingest("user", "Hello")  # routine, low importance (0.5)
        pipeline.ingest("user", "The database uses PostgreSQL on port 5432.")

        # Backdate the greeting well past any decay
        greeting = pipeline.store.get(0)
        greeting.timestamp -= 60 * SECONDS_PER_DAY
        greeting.last_accessed -= 60 * SECONDS_PER_DAY

        metrics = pipeline.maintain()
        assert metrics.pruned_count >= 1  # greeting should be pruned

    def test_pipeline_health(self):
        pipeline = CognitiveMemoryPipeline(embedding_model=get_shared_model(), retriever_threshold=0.0)
        pipeline.ingest("user", "Test content.")

        health = pipeline.health()
        assert health.total_memories == 1
