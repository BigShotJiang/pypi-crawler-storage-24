"""Tests for the Ollama-based gist encoder.

These tests require a running Ollama instance. They are skipped if
Ollama is not available.
"""

import httpx
import pytest

from cmm.core.types import ConversationTurn, Role
from cmm.encoding.ollama_gist_encoder import OllamaGistEncoder
from cmm.pipeline.conversation import CognitiveMemoryPipeline


def ollama_available() -> bool:
    try:
        r = httpx.get("http://localhost:11434/api/tags", timeout=2)
        return r.status_code == 200
    except Exception:
        return False


requires_ollama = pytest.mark.skipif(
    not ollama_available(), reason="Ollama not running"
)


@requires_ollama
class TestOllamaGistEncoder:
    @pytest.fixture
    def encoder(self):
        return OllamaGistEncoder()

    def test_basic_encoding(self, encoder):
        turn = ConversationTurn(
            role=Role.USER,
            content="I need to debug my Python script that parses CSV files.",
        )
        gist = encoder.encode(turn)
        assert gist.text  # non-empty
        assert len(gist.text) < len(turn.content) * 3  # not wildly longer
        assert len(gist.tags) > 0

    def test_preserves_specific_facts(self, encoder):
        turn = ConversationTurn(
            role=Role.USER,
            content="My friend Sarah who lives in Tokyo sent me 3 packages last Tuesday.",
        )
        gist = encoder.encode(turn)
        text_lower = gist.text.lower()
        tags_joined = " ".join(gist.tags)
        combined = text_lower + " " + tags_joined
        # Should preserve at least some specific details
        assert "sarah" in combined or "tokyo" in combined or "package" in combined

    def test_with_context(self, encoder):
        context = [
            ConversationTurn(role=Role.USER, content="Let's discuss machine learning."),
            ConversationTurn(role=Role.ASSISTANT, content="Sure! What aspect interests you?"),
        ]
        turn = ConversationTurn(
            role=Role.USER,
            content="I want to understand how transformers handle attention mechanisms.",
        )
        gist = encoder.encode(turn, context=context)
        assert gist.text
        assert len(gist.tags) > 0

    def test_fallback_on_unparseable(self, encoder):
        """If the model returns garbage, we should get a fallback gist."""
        turn = ConversationTurn(role=Role.USER, content="Test input.")
        # This should always return something, even if parsing fails
        gist = encoder.encode(turn)
        assert gist.text


@requires_ollama
class TestPipelineWithOllama:
    def test_zebra_test_with_gist_compression(self):
        """The zebra test with real gist encoding — memories are compressed."""
        encoder = OllamaGistEncoder()
        pipeline = CognitiveMemoryPipeline(
            gist_encoder=encoder,
            retriever_threshold=0.2,
        )

        # Discuss zebras
        pipeline.ingest("user", "I saw a zebra at the zoo today. It had striking black and white stripes.")
        pipeline.ingest("assistant", "Zebras are fascinating! Their stripes help with thermoregulation and confusing predators.")
        pipeline.ingest("user", "Each zebra has a unique stripe pattern, like human fingerprints. The oldest one was named Zara.")

        # Fill with unrelated content
        fillers = [
            "How do I set up a Docker container for PostgreSQL?",
            "Can you explain the difference between REST and GraphQL?",
            "I'm redecorating my living room in mid-century modern style.",
            "What's the best way to learn Rust programming?",
            "My sourdough starter isn't rising properly.",
        ]
        for f in fillers:
            pipeline.ingest("user", f)

        # Recall zebras
        results = pipeline.recall("Tell me about zebras")
        assert len(results) > 0
        recalled_text = " ".join(r.memory.gist.text.lower() for r in results)
        assert "zebra" in recalled_text or "stripe" in recalled_text

        # Verify gist compression happened — stored gists should be shorter than raw input
        for r in results:
            if "zebra" in r.memory.gist.text.lower():
                # Gist should be compressed (shorter than the original)
                assert len(r.memory.gist.text) < 300
