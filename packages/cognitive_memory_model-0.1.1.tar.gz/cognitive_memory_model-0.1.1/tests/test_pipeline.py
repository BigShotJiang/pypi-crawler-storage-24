"""End-to-end pipeline tests including the "zebra test"."""

import pytest

from cmm.pipeline.conversation import CognitiveMemoryPipeline


@pytest.fixture
def pipeline(shared_embedding_model):
    return CognitiveMemoryPipeline(
        embedding_model=shared_embedding_model,
        retriever_threshold=0.2,
    )


class TestPipeline:
    def test_ingest_stores_memory(self, pipeline):
        results = pipeline.ingest("user", "Hello, how are you?")
        assert pipeline.memory_count == 1
        # First turn has nothing to recall
        assert len(results) == 0

    def test_recall_without_storing(self, pipeline):
        pipeline.ingest("user", "Zebras have black and white stripes for thermoregulation.")
        pipeline.ingest("assistant", "Interesting! Zebra stripes help regulate body temperature.")

        results = pipeline.recall("tell me about zebras")
        assert len(results) > 0
        # Should find zebra-related memories
        texts = [r.memory.gist.text for r in results]
        assert any("zebra" in t.lower() or "stripes" in t.lower() for t in texts)

    def test_zebra_test(self, pipeline):
        """The core test: store zebra facts, fill with unrelated content, recall zebras."""
        # Phase 1: Discuss zebras
        pipeline.ingest("user", "I saw a zebra at the zoo today. It had striking black and white stripes.")
        pipeline.ingest("assistant", "Zebras are fascinating! Their stripes may help with thermoregulation and confusing predators.")
        pipeline.ingest("user", "Yes, and I learned that each zebra has a unique stripe pattern, like human fingerprints.")

        # Phase 2: Fill with unrelated conversation (simulates context window clearing)
        unrelated_topics = [
            "Let's talk about Python programming. I need help with a decorator pattern.",
            "Can you explain how async/await works in JavaScript?",
            "I'm planning a trip to Japan next spring. Any restaurant recommendations?",
            "What's the difference between TCP and UDP protocols?",
            "I need to fix a bug in my CSS grid layout.",
            "How do neural networks handle backpropagation?",
            "My car needs an oil change. What type of oil should I use?",
            "Can you recommend a good book on distributed systems?",
            "I'm learning to cook Italian pasta from scratch.",
            "What are the best practices for database indexing?",
        ]
        for topic in unrelated_topics:
            pipeline.ingest("user", topic)
            pipeline.ingest("assistant", f"Sure, I can help with that. {topic[:50]}...")

        # Phase 3: Ask about zebras again
        results = pipeline.recall("Tell me about that zebra I saw")
        assert len(results) > 0

        # Verify zebra memories are in the results
        recalled_texts = " ".join(r.memory.gist.text.lower() for r in results)
        assert "zebra" in recalled_texts or "stripe" in recalled_texts

    def test_format_recalled(self, pipeline):
        pipeline.ingest("user", "Zebras live in Africa.")
        results = pipeline.recall("African animals")
        formatted = pipeline.format_recalled(results)
        if results:
            assert "[Recalled from memory" in formatted
            assert "[End recalled memories]" in formatted

    def test_multiple_topics_retrieval(self, pipeline):
        """Ensure different topics retrieve their own memories, not others."""
        pipeline.ingest("user", "Python is a great programming language for data science.")
        pipeline.ingest("user", "Elephants are the largest land animals on Earth.")
        pipeline.ingest("user", "The Eiffel Tower is located in Paris, France.")

        python_results = pipeline.recall("programming languages")
        elephant_results = pipeline.recall("large animals")

        if python_results and elephant_results:
            # Top result for each query should be about the right topic
            assert "python" in python_results[0].memory.gist.text.lower() or \
                   "programming" in python_results[0].memory.gist.text.lower()
            assert "elephant" in elephant_results[0].memory.gist.text.lower() or \
                   "animal" in elephant_results[0].memory.gist.text.lower()
