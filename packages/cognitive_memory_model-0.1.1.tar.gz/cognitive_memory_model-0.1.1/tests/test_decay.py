"""Tests for temporal decay with grace period, frequency modulation, and lock threshold."""

import math
import time

import numpy as np
import pytest

from cmm.core.types import Gist, Memory, MemoryType
from cmm.retrieval.decay import DecayScorer, SECONDS_PER_DAY, SECONDS_PER_WEEK


def make_memory(
    memory_id: int = 0,
    timestamp: float | None = None,
    access_count: int = 0,
    last_accessed: float | None = None,
    importance: float = 1.0,
) -> Memory:
    ts = timestamp or time.time()
    return Memory(
        id=memory_id,
        gist=Gist(text="test"),
        embedding=np.zeros(32, dtype=np.float32),
        timestamp=ts,
        access_count=access_count,
        last_accessed=last_accessed or ts,
        importance=importance,
    )


class TestGracePeriod:
    def test_no_decay_during_grace_period(self):
        """Memories within grace period should have decay = 1.0."""
        scorer = DecayScorer(grace_period=14 * SECONDS_PER_DAY)
        now = time.time()

        # Memory created 1 day ago — well within 2-week grace
        memory = make_memory(timestamp=now - SECONDS_PER_DAY, last_accessed=now - SECONDS_PER_DAY)
        assert scorer.compute_decay(memory, now=now) == 1.0

    def test_no_decay_at_one_week(self):
        """Memory 1 week old with no access should still be in grace."""
        scorer = DecayScorer(grace_period=14 * SECONDS_PER_DAY)
        now = time.time()

        memory = make_memory(
            timestamp=now - 7 * SECONDS_PER_DAY,
            last_accessed=now - 7 * SECONDS_PER_DAY,
        )
        assert scorer.compute_decay(memory, now=now) == 1.0

    def test_decay_starts_after_grace(self):
        """Decay should begin only after grace period expires."""
        scorer = DecayScorer(grace_period=14 * SECONDS_PER_DAY, decay_rate=5e-7)
        now = time.time()

        # Memory 3 weeks old, never re-accessed — 1 week past grace
        memory = make_memory(
            timestamp=now - 21 * SECONDS_PER_DAY,
            last_accessed=now - 21 * SECONDS_PER_DAY,
        )
        decay = scorer.compute_decay(memory, now=now)
        assert decay < 1.0
        assert decay > 0.0

    def test_recent_access_resets_grace(self):
        """Accessing a memory should reset the grace period."""
        scorer = DecayScorer(grace_period=14 * SECONDS_PER_DAY)
        now = time.time()

        # Created 30 days ago, but accessed 1 day ago
        memory = make_memory(
            timestamp=now - 30 * SECONDS_PER_DAY,
            last_accessed=now - SECONDS_PER_DAY,
            access_count=5,
        )
        assert scorer.compute_decay(memory, now=now) == 1.0

    def test_zero_grace_period_decays_immediately(self):
        """Grace period of 0 should decay from the start."""
        scorer = DecayScorer(grace_period=0, decay_rate=1e-4)
        now = time.time()

        memory = make_memory(
            timestamp=now - 3600,
            last_accessed=now - 3600,
        )
        decay = scorer.compute_decay(memory, now=now)
        assert decay < 1.0


class TestFrequencyModulation:
    def test_frequent_access_slows_decay(self):
        """Frequently accessed memories should decay slower."""
        scorer = DecayScorer(
            grace_period=0,  # disable grace for this test
            decay_rate=1e-5,
            freq_weight=1.0,
        )
        now = time.time()
        age = 30 * SECONDS_PER_DAY  # 30 days

        # Rarely accessed: 1 time over 30 days
        rare = make_memory(
            timestamp=now - age,
            last_accessed=now - age,
            access_count=1,
        )
        # Frequently accessed: 20 times over 30 days
        frequent = make_memory(
            timestamp=now - age,
            last_accessed=now - age,
            access_count=20,
        )

        d_rare = scorer.compute_decay(rare, now=now)
        d_frequent = scorer.compute_decay(frequent, now=now)

        assert d_frequent > d_rare


class TestLockThreshold:
    def test_frequently_accessed_memory_locks(self):
        """Memories accessed frequently enough should be permanently locked."""
        scorer = DecayScorer(
            grace_period=0,
            lock_frequency=0.5,  # >= 0.5 accesses per week = locked
        )
        now = time.time()

        # Accessed 5 times over 4 weeks = 1.25/week > 0.5 threshold
        memory = make_memory(
            timestamp=now - 4 * SECONDS_PER_WEEK,
            last_accessed=now - 30 * SECONDS_PER_DAY,
            access_count=5,
        )
        assert scorer.compute_decay(memory, now=now) == 1.0
        assert scorer.is_locked(memory, now=now)

    def test_rarely_accessed_memory_not_locked(self):
        """Memories accessed rarely should not be locked."""
        scorer = DecayScorer(lock_frequency=0.5)
        now = time.time()

        # Accessed 1 time over 8 weeks = 0.125/week < 0.5
        memory = make_memory(
            timestamp=now - 8 * SECONDS_PER_WEEK,
            last_accessed=now - 8 * SECONDS_PER_WEEK,
            access_count=1,
        )
        assert not scorer.is_locked(memory, now=now)

    def test_birthday_analogy(self):
        """A memory accessed once per year should be locked with low threshold."""
        scorer = DecayScorer(lock_frequency=0.08)  # ~once per 12 weeks = locked
        now = time.time()

        # Accessed 4 times over 52 weeks = 0.077/week — just below
        memory_annual = make_memory(
            timestamp=now - 52 * SECONDS_PER_WEEK,
            access_count=4,
        )
        # Accessed 5 times over 52 weeks = 0.096/week — above
        memory_regular = make_memory(
            timestamp=now - 52 * SECONDS_PER_WEEK,
            access_count=5,
        )
        assert not scorer.is_locked(memory_annual, now=now)
        assert scorer.is_locked(memory_regular, now=now)


class TestDecayDisabled:
    def test_zero_rate_means_no_decay(self):
        scorer = DecayScorer(decay_rate=0.0)
        now = time.time()
        memory = make_memory(
            timestamp=now - 365 * SECONDS_PER_DAY,
            last_accessed=now - 365 * SECONDS_PER_DAY,
        )
        assert scorer.compute_decay(memory, now=now) == 1.0


class TestApply:
    def test_apply_multiplies_similarity(self):
        scorer = DecayScorer(grace_period=0, decay_rate=1e-5)
        now = time.time()
        memory = make_memory(
            timestamp=now - 30 * SECONDS_PER_DAY,
            last_accessed=now - 30 * SECONDS_PER_DAY,
        )

        raw_sim = 0.8
        result = scorer.apply(raw_sim, memory, now=now)
        decay = scorer.compute_decay(memory, now=now)

        assert result == pytest.approx(raw_sim * decay)
        assert result < raw_sim
