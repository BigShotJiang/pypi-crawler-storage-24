"""Phase 4 integration tests — episodic→semantic consolidation and session summaries.

Uses OllamaConsolidationSummarizer for real LLM-based summarization.
Tests are skipped if Ollama is not running.
"""

import httpx
import pytest

from cmm.consolidation.ollama_summarizer import OllamaConsolidationSummarizer
from cmm.core.types import MemoryType
from cmm.encoding.ollama_gist_encoder import OllamaGistEncoder
from cmm.pipeline.conversation import CognitiveMemoryPipeline


def ollama_available() -> bool:
    try:
        r = httpx.get("http://localhost:11434/api/tags", timeout=2)
        return r.status_code == 200
    except Exception:
        return False


requires_ollama = pytest.mark.skipif(
    not ollama_available(), reason="Ollama not running"
)


@pytest.fixture
def summarizer():
    return OllamaConsolidationSummarizer()


@pytest.fixture
def gist_encoder():
    return OllamaGistEncoder()


@requires_ollama
class TestConsolidation:
    def test_clustering_groups_related_memories(self, summarizer):
        """Similar memories should be clustered and consolidated."""
        pipeline = CognitiveMemoryPipeline(
            retriever_threshold=0.0,
            cluster_similarity=0.5,
            min_cluster_size=3,
            consolidation_summarizer=summarizer,
        )

        # Ingest a cluster of related Python debugging memories
        pipeline.ingest("user", "I'm debugging a Python script that crashes on CSV parsing.")
        pipeline.ingest("assistant", "Let me help you debug the Python CSV parser error.")
        pipeline.ingest("user", "The Python CSV reader throws an error on the header row.")
        pipeline.ingest("assistant", "The CSV parsing issue is likely an encoding problem in Python.")

        # Ingest some unrelated memories
        pipeline.ingest("user", "What is the weather forecast for tomorrow?")
        pipeline.ingest("user", "Can you recommend a good Italian restaurant?")

        initial_count = pipeline.memory_count
        new_memories = pipeline.consolidate()

        # Should produce at least one semantic memory from the Python/CSV cluster
        assert len(new_memories) >= 1
        assert pipeline.memory_count > initial_count

        # New memories should be semantic type with real LLM summaries
        for m in new_memories:
            assert m.memory_type == MemoryType.SEMANTIC
            assert m.importance > 1.0
            # LLM summary should be a proper sentence, not a pipe-concatenation
            assert "|" not in m.gist.text
            print(f"  Consolidated: {m.gist.text}")
            print(f"  Tags: {m.gist.tags}")

    def test_semantic_memories_retrievable_by_broad_cue(self, summarizer):
        """Consolidated semantic memories should be retrievable with broad queries."""
        pipeline = CognitiveMemoryPipeline(
            retriever_threshold=0.1,
            cluster_similarity=0.2,
            min_cluster_size=3,
            consolidation_summarizer=summarizer,
        )

        python_turns = [
            "I need help with a Python decorator pattern.",
            "How do I use Python async/await correctly?",
            "My Python script has a memory leak in the data processing loop.",
            "Can you help me optimize this Python function?",
            "I'm writing Python unit tests with pytest.",
        ]
        for t in python_turns:
            pipeline.ingest("user", t)

        pipeline.consolidate()

        # Broad query should surface the semantic memory
        results = pipeline.recall("Python programming", top_k=10)
        assert len(results) > 0

        semantic_results = [r for r in results if r.memory.memory_type == MemoryType.SEMANTIC]
        assert len(semantic_results) >= 1

        for r in semantic_results:
            print(f"  Semantic hit: {r.memory.gist.text}")

    def test_episodic_still_retrievable_by_specific_cue(self, summarizer):
        """Original episodic memories should still be retrievable with specific queries."""
        pipeline = CognitiveMemoryPipeline(
            retriever_threshold=0.1,
            cluster_similarity=0.5,
            min_cluster_size=3,
            consolidation_summarizer=summarizer,
        )

        pipeline.ingest("user", "I'm debugging a Python CSV parser that crashes on row 47.")
        pipeline.ingest("user", "The Python CSV header detection is off by one.")
        pipeline.ingest("user", "Fixed the Python CSV bug — it was a Unicode BOM issue.")

        pipeline.consolidate()

        # Specific query should still find the specific episodic memory
        results = pipeline.recall("CSV header off by one bug", top_k=10)
        assert len(results) > 0
        episodic = [r for r in results if r.memory.memory_type == MemoryType.EPISODIC]
        assert len(episodic) >= 1

    def test_consolidation_demotes_episodic_importance(self, summarizer):
        """After consolidation, episodic memories in clusters should have reduced importance."""
        pipeline = CognitiveMemoryPipeline(
            retriever_threshold=0.0,
            cluster_similarity=0.5,
            min_cluster_size=3,
            consolidation_summarizer=summarizer,
        )

        pipeline.ingest("user", "Python decorators are useful for logging.")
        pipeline.ingest("user", "Python decorators can add authentication checks.")
        pipeline.ingest("user", "I use Python decorators for caching function results.")

        for mid in range(3):
            assert pipeline.store.get(mid).importance == 1.0

        pipeline.consolidate()

        for mid in range(3):
            mem = pipeline.store.get(mid)
            if mem.memory_type == MemoryType.EPISODIC:
                assert mem.importance < 1.0

    def test_auto_consolidation_trigger(self, summarizer):
        """Consolidation should auto-trigger after the configured number of turns."""
        pipeline = CognitiveMemoryPipeline(
            retriever_threshold=0.0,
            consolidation_threshold=10,
            cluster_similarity=0.4,
            min_cluster_size=3,
            consolidation_summarizer=summarizer,
        )

        for i in range(12):
            pipeline.ingest("user", f"Python programming tip number {i} about functions and classes.")

        semantic = [
            m for m in pipeline.store._memories.values()
            if m.memory_type == MemoryType.SEMANTIC
        ]
        assert len(semantic) >= 1
        for m in semantic:
            print(f"  Auto-consolidated: {m.gist.text}")


@requires_ollama
class TestSessionSummaries:
    def test_end_session_creates_summary(self, summarizer):
        """end_session() should create a session summary memory."""
        pipeline = CognitiveMemoryPipeline(
            retriever_threshold=0.0,
            consolidation_summarizer=summarizer,
        )

        pipeline.ingest("user", "Let's debug my Python CSV parser.")
        pipeline.ingest("assistant", "Sure, what error are you seeing?")
        pipeline.ingest("user", "It crashes on row 47 with a Unicode error.")

        count_before = pipeline.memory_count
        summary = pipeline.end_session()

        assert summary is not None
        assert summary.memory_type == MemoryType.SEMANTIC
        assert "Session summary:" in summary.gist.text
        assert pipeline.memory_count == count_before + 1
        print(f"  Session summary: {summary.gist.text}")

    def test_session_summary_retrievable(self, summarizer):
        """Session summaries should be retrievable."""
        pipeline = CognitiveMemoryPipeline(
            retriever_threshold=0.1,
            consolidation_summarizer=summarizer,
        )

        pipeline.ingest("user", "I need to deploy my app to Kubernetes.")
        pipeline.ingest("assistant", "Let's set up a Kubernetes deployment manifest.")
        pipeline.ingest("user", "The pods keep crashing with OOMKilled errors.")

        pipeline.end_session()

        results = pipeline.recall("Kubernetes deployment issues", top_k=10)
        assert len(results) > 0
        summaries = [r for r in results if "Session summary" in r.memory.gist.text]
        assert len(summaries) >= 1

    def test_end_session_resets_state(self, summarizer):
        """end_session() should clear session tracking so the next session is fresh."""
        pipeline = CognitiveMemoryPipeline(
            retriever_threshold=0.0,
            consolidation_summarizer=summarizer,
        )

        pipeline.ingest("user", "First session content about zebras.")
        pipeline.ingest("assistant", "First session reply about zebras.")
        first_summary = pipeline.end_session()
        assert first_summary is not None

        pipeline.ingest("user", "Second session content about Python.")
        pipeline.ingest("assistant", "Second session reply about Python.")
        second_summary = pipeline.end_session()

        assert second_summary is not None

    def test_end_session_with_too_few_turns(self):
        """end_session() with 0 turns should return None."""
        pipeline = CognitiveMemoryPipeline(retriever_threshold=0.0)
        assert pipeline.end_session() is None

    def test_llm_produces_quality_summaries(self, summarizer, gist_encoder):
        """LLM consolidation should produce meaningful, compressed summaries."""
        pipeline = CognitiveMemoryPipeline(
            retriever_threshold=0.0,
            gist_encoder=gist_encoder,
            consolidation_summarizer=summarizer,
            cluster_similarity=0.4,
            min_cluster_size=3,
        )

        # Full conversation with gist encoding + consolidation
        pipeline.ingest("user", "I saw a zebra at the zoo today. It had striking black and white stripes.")
        pipeline.ingest("assistant", "Zebras are fascinating! Their stripes help with thermoregulation.")
        pipeline.ingest("user", "Each zebra has a unique stripe pattern, like human fingerprints.")
        pipeline.ingest("assistant", "Yes, researchers use stripe patterns to identify individual zebras.")

        new_memories = pipeline.consolidate()

        if new_memories:
            for m in new_memories:
                print(f"  Consolidated gist: {m.gist.text}")
                print(f"  Tags: {m.gist.tags}")
                # LLM summary should mention zebras or stripes
                combined = m.gist.text.lower() + " " + " ".join(m.gist.tags)
                assert "zebra" in combined or "stripe" in combined
