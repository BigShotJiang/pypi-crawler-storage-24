"""Tests for emotional valence scoring."""

import pytest

from cmm.core.types import ConversationTurn, Role
from cmm.scoring.valence import ValenceScorer
from tests.conftest import get_shared_model


class TestValenceScorer:
    @pytest.fixture
    def scorer(self):
        return ValenceScorer()

    # --- Positive emotions ---

    def test_excited_high_arousal(self, scorer):
        turn = ConversationTurn(role=Role.USER, content="This is amazing! The feature works perfectly!!")
        result = scorer.score(turn)
        assert result.valence > 0.5
        assert result.arousal > 0.5
        assert result.emotion in ("excited", "elated")

    def test_satisfied_low_arousal(self, scorer):
        turn = ConversationTurn(role=Role.USER, content="Good, that works. Thanks for the help.")
        result = scorer.score(turn)
        assert result.valence > 0
        assert result.emotion in ("positive", "grateful", "satisfied")

    def test_grateful(self, scorer):
        turn = ConversationTurn(role=Role.USER, content="Thank you so much, I really appreciate your help.")
        result = scorer.score(turn)
        assert result.valence > 0
        assert result.emotion in ("grateful", "positive")

    def test_triumph(self, scorer):
        turn = ConversationTurn(role=Role.USER, content="Finally! After 3 days I got it working!")
        result = scorer.score(turn)
        assert result.valence > 0.5
        assert result.emotion in ("triumphant", "excited")

    # --- Negative emotions ---

    def test_frustrated(self, scorer):
        turn = ConversationTurn(role=Role.USER, content="I'm so frustrated, this keeps breaking every time I try.")
        result = scorer.score(turn)
        assert result.valence < 0
        assert result.emotion == "frustrated"

    def test_confused(self, scorer):
        turn = ConversationTurn(role=Role.USER, content="I'm confused, I don't understand why this isn't working.")
        result = scorer.score(turn)
        assert result.valence < 0
        assert result.emotion == "confused"

    def test_angry(self, scorer):
        turn = ConversationTurn(role=Role.USER, content="This is infuriating! The deployment crashed again!")
        result = scorer.score(turn)
        assert result.valence < -0.5
        assert result.arousal > 0.5
        assert result.emotion in ("angry", "distressed")

    def test_disappointed(self, scorer):
        turn = ConversationTurn(role=Role.USER, content="That's really disappointing. I expected better results.")
        result = scorer.score(turn)
        assert result.valence < 0
        assert result.emotion == "disappointed"

    # --- Neutral ---

    def test_neutral_factual(self, scorer):
        turn = ConversationTurn(role=Role.USER, content="The server runs on port 8080 with PostgreSQL.")
        result = scorer.score(turn)
        assert result.emotion == "neutral"
        assert result.valence == 0.0
        assert result.arousal == 0.0

    def test_neutral_question(self, scorer):
        turn = ConversationTurn(role=Role.USER, content="How do I configure the database connection?")
        result = scorer.score(turn)
        assert abs(result.valence) < 0.5  # might catch "how" but shouldn't be strongly emotional


class TestValenceInPipeline:
    def test_emotions_stored_with_memories(self):
        from cmm.pipeline.conversation import CognitiveMemoryPipeline

        pipeline = CognitiveMemoryPipeline(embedding_model=get_shared_model(), retriever_threshold=0.0)

        pipeline.ingest("user", "This is amazing! The feature finally works!")
        pipeline.ingest("user", "I'm frustrated, the deployment keeps failing.")
        pipeline.ingest("user", "The server runs on port 8080.")

        excited = pipeline.store.get(0)
        frustrated = pipeline.store.get(1)
        neutral = pipeline.store.get(2)

        assert excited.valence > 0.5
        assert excited.emotion in ("excited", "triumphant")

        assert frustrated.valence < 0
        assert frustrated.emotion == "frustrated"

        assert neutral.emotion == "neutral"

    def test_emotional_context_in_formatted_output(self):
        from cmm.pipeline.conversation import CognitiveMemoryPipeline
        from cmm.retrieval.retriever import Retriever

        pipeline = CognitiveMemoryPipeline(embedding_model=get_shared_model(), retriever_threshold=0.0)

        pipeline.ingest("user", "I'm so frustrated with this terrible deployment process!")

        results = pipeline.recall("deployment")
        formatted = Retriever.format_for_context(results)

        # High-arousal emotion should appear in the formatted context
        if results and results[0].memory.arousal >= 0.3:
            assert "emotion:" in formatted
