"""Tests for metamemory signals — confidence levels and partial matches."""

import pytest

from cmm.pipeline.conversation import CognitiveMemoryPipeline
from cmm.retrieval.metamemory import Confidence, MetamemoryScorer, MetamemoryResult
from tests.conftest import get_shared_model


class TestMetamemoryScorer:
    def test_high_confidence(self):
        from cmm.core.types import Gist, Memory, RetrievalResult
        import numpy as np

        scorer = MetamemoryScorer(high_threshold=0.7)
        results = [
            RetrievalResult(
                memory=Memory(id=0, gist=Gist(text="test"), embedding=np.zeros(32), timestamp=0),
                raw_similarity=0.9,
                final_score=0.85,
            )
        ]
        meta = scorer.evaluate(results)
        assert meta.confidence == Confidence.HIGH
        assert meta.has_strong_match

    def test_moderate_confidence(self):
        from cmm.core.types import Gist, Memory, RetrievalResult
        import numpy as np

        scorer = MetamemoryScorer()
        results = [
            RetrievalResult(
                memory=Memory(id=0, gist=Gist(text="test"), embedding=np.zeros(32), timestamp=0),
                raw_similarity=0.5,
                final_score=0.5,
            )
        ]
        meta = scorer.evaluate(results)
        assert meta.confidence == Confidence.MODERATE
        assert meta.has_strong_match

    def test_no_confidence(self):
        scorer = MetamemoryScorer()
        meta = scorer.evaluate([])
        assert meta.confidence == Confidence.NONE
        assert not meta.has_strong_match
        assert not meta.has_tip_of_tongue

    def test_partial_matches_detected(self):
        from cmm.core.types import Gist, Memory, RetrievalResult
        import numpy as np

        scorer = MetamemoryScorer(moderate_threshold=0.5, partial_threshold=0.2)

        # No results above threshold
        results = []
        # But some candidates exist below threshold
        all_candidates = [
            RetrievalResult(
                memory=Memory(id=0, gist=Gist(text="partial hit"), embedding=np.zeros(32), timestamp=0),
                raw_similarity=0.3,
                final_score=0.3,
            )
        ]
        meta = scorer.evaluate(results, all_candidates)
        assert meta.confidence == Confidence.NONE
        assert meta.has_partial
        assert meta.has_tip_of_tongue
        assert len(meta.partial_matches) == 1

    def test_format_with_tip_of_tongue(self):
        from cmm.core.types import Gist, Memory, RetrievalResult
        import numpy as np

        scorer = MetamemoryScorer(partial_threshold=0.2)
        all_candidates = [
            RetrievalResult(
                memory=Memory(id=0, gist=Gist(text="vague zebra memory"), embedding=np.zeros(32), timestamp=0),
                raw_similarity=0.25,
                final_score=0.25,
            )
        ]
        meta = scorer.evaluate([], all_candidates)
        formatted = MetamemoryScorer.format_for_context(meta)
        assert "Partial matches" in formatted
        assert "vague zebra memory" in formatted

    def test_format_no_matches(self):
        scorer = MetamemoryScorer()
        meta = scorer.evaluate([])
        formatted = MetamemoryScorer.format_for_context(meta)
        assert "No relevant memories found" in formatted


class TestMetamemoryInPipeline:
    def test_strong_match_high_confidence(self):
        pipeline = CognitiveMemoryPipeline(embedding_model=get_shared_model(), retriever_threshold=0.3)

        pipeline.ingest("user", "Zebras have black and white stripes for thermoregulation.")

        meta = pipeline.recall_with_metamemory("zebra stripes")
        assert meta.confidence in (Confidence.HIGH, Confidence.MODERATE)
        assert len(meta.results) > 0

    def test_no_match_none_confidence(self):
        pipeline = CognitiveMemoryPipeline(embedding_model=get_shared_model(), retriever_threshold=0.3)

        pipeline.ingest("user", "Python is a great programming language.")

        meta = pipeline.recall_with_metamemory("quantum physics black holes")
        # Should be low or no confidence for a completely unrelated query
        assert meta.confidence in (Confidence.LOW, Confidence.NONE)

    def test_partial_match_tip_of_tongue(self):
        """With a high retriever threshold, partial matches should appear as hints."""
        pipeline = CognitiveMemoryPipeline(embedding_model=get_shared_model(), retriever_threshold=0.6)

        pipeline.ingest("user", "Zebras have black and white stripes.")
        pipeline.ingest("user", "Lions live in the African savanna.")

        # Query somewhat related but not a strong match
        meta = pipeline.recall_with_metamemory("African wildlife animals")

        # With a high threshold, results may be empty but partials should exist
        if not meta.results and meta.has_partial:
            assert meta.has_tip_of_tongue
            assert len(meta.partial_matches) > 0
        # If results exist, that's fine too — the memories are relevant
        elif meta.results:
            assert meta.confidence in (Confidence.HIGH, Confidence.MODERATE)
