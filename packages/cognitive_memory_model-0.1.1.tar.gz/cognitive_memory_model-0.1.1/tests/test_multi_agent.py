"""Tests for multi-agent memory sharing."""

import pytest

from cmm.core.types import MemoryScope
from cmm.multi_agent.shared_store import SharedMemoryManager


class TestSharedMemoryManager:
    @pytest.fixture
    def manager(self):
        return SharedMemoryManager()

    def test_create_multiple_agents(self, manager):
        p1 = manager.create_agent_pipeline("agent-1", session_id="session-1")
        p2 = manager.create_agent_pipeline("agent-2", session_id="session-2")

        assert manager.agent_count == 2
        assert p1.agent_id == "agent-1"
        assert p2.agent_id == "agent-2"

    def test_agents_share_store(self, manager):
        """Both agents should read from and write to the same store."""
        p1 = manager.create_agent_pipeline("agent-1")
        p2 = manager.create_agent_pipeline("agent-2")

        p1.ingest("user", "The database runs on PostgreSQL version 16.")
        p2.ingest("user", "The frontend uses React 19 with TypeScript.")

        # Both memories in the same store
        assert manager.store.size == 2

        # Agent 2 should be able to recall agent 1's memory
        results = p2.recall("database version")
        assert len(results) > 0
        assert any("postgresql" in r.memory.gist.text.lower() for r in results)

    def test_memories_tagged_with_agent_id(self, manager):
        p1 = manager.create_agent_pipeline("agent-1")
        p2 = manager.create_agent_pipeline("agent-2")

        p1.ingest("user", "Agent 1 learned about zebras.")
        p2.ingest("user", "Agent 2 learned about elephants.")

        agent1_mems = manager.get_memories_by_agent("agent-1")
        agent2_mems = manager.get_memories_by_agent("agent-2")

        assert len(agent1_mems) == 1
        assert len(agent2_mems) == 1
        assert "zebra" in agent1_mems[0].gist.text.lower()
        assert "elephant" in agent2_mems[0].gist.text.lower()

    def test_private_scope_not_visible_to_other_agents(self, manager):
        """Private memories should only be visible to the creating agent."""
        p1 = manager.create_agent_pipeline("agent-1", default_scope="private")
        p2 = manager.create_agent_pipeline("agent-2")

        p1.ingest("user", "Secret internal reasoning about zebras.")
        p2.ingest("user", "Public information about elephants.")

        # Agent 2 querying should NOT find agent 1's private memory
        results = manager.store.retrieve(
            query_embedding=manager.embedding_model.embed("zebras"),
            top_k=5,
            agent_id="agent-2",
        )
        private_hits = [r for r in results if "secret" in r.memory.gist.text.lower()]
        assert len(private_hits) == 0

    def test_team_scope_visible_to_all(self, manager):
        """Team-scoped memories should be visible to all agents."""
        p1 = manager.create_agent_pipeline("agent-1", default_scope="team")
        p2 = manager.create_agent_pipeline("agent-2")

        p1.ingest("user", "The API endpoint is at api.example.com/v2.")

        results = manager.store.retrieve(
            query_embedding=manager.embedding_model.embed("API endpoint"),
            top_k=5,
            agent_id="agent-2",
        )
        assert any("api.example.com" in r.memory.gist.text.lower() for r in results)

    def test_contradiction_detection(self, manager):
        """Should detect when two agents store highly similar but potentially conflicting info."""
        p1 = manager.create_agent_pipeline("agent-1")
        p2 = manager.create_agent_pipeline("agent-2")

        # Two agents store similar but potentially conflicting info
        p1.ingest("user", "The server runs on port 8080.")
        p2.ingest("user", "The server runs on port 3000.")

        contradictions = manager.detect_contradictions(similarity_threshold=0.7)
        # These are semantically similar (both about server ports) from different agents
        assert len(contradictions) >= 1
        c = contradictions[0]
        assert c.memory_a.agent_id != c.memory_b.agent_id
        assert c.similarity >= 0.7

    def test_memory_stats(self, manager):
        p1 = manager.create_agent_pipeline("agent-1")
        p2 = manager.create_agent_pipeline("agent-2")

        p1.ingest("user", "Fact from agent 1.")
        p1.ingest("user", "Another fact from agent 1.")
        p2.ingest("user", "Fact from agent 2.")

        stats = manager.get_memory_stats()
        assert stats["total"] == 3
        assert stats["by_agent"]["agent-1"] == 2
        assert stats["by_agent"]["agent-2"] == 1

    def test_nightly_consolidation(self, manager):
        """Nightly consolidation should rebuild index and run maintenance."""
        p1 = manager.create_agent_pipeline("agent-1")

        for i in range(5):
            p1.ingest("user", f"Python programming tip {i} about functions.")

        initial_count = manager.store.size
        summary = manager.nightly_consolidation()
        # Consolidation may merge near-duplicates, so count may decrease
        assert summary["total_memories"] > 0
        assert "agent-1" in summary["agents"]
