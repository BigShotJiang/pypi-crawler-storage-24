"""Phase 3 integration tests — spreading activation and priming in the pipeline."""

import pytest

from cmm.pipeline.conversation import CognitiveMemoryPipeline
from tests.conftest import get_shared_model


class TestSpreadingActivationInPipeline:
    def test_related_memories_activated(self):
        """Mentioning 'zebra' should also activate related memories about stripes/Africa."""
        pipeline = CognitiveMemoryPipeline(
            embedding_model=get_shared_model(),
            retriever_threshold=0.1,
            spread_depth=1,
            spread_factor=0.5,
            spread_top_k=5,
            retriever_top_k=10,
        )

        # Store semantically related memories
        pipeline.ingest("user", "Zebras have black and white stripes.")
        pipeline.ingest("assistant", "Zebra stripes help with thermoregulation and confusing predators.")
        pipeline.ingest("user", "Zebras live in the African savanna and grasslands.")
        pipeline.ingest("assistant", "Africa has many other animals too, like lions, elephants, and giraffes.")
        pipeline.ingest("user", "I love watching nature documentaries about African wildlife.")

        # Query about zebras — should spread to activate Africa/wildlife memories
        results = pipeline.recall("tell me about zebras", top_k=10)
        recalled_texts = " ".join(r.memory.gist.text.lower() for r in results)

        # Direct matches
        assert "zebra" in recalled_texts or "stripe" in recalled_texts
        # Spread-activated: Africa/wildlife should also appear
        assert "africa" in recalled_texts or "wildlife" in recalled_texts or "savanna" in recalled_texts

    def test_spreading_stays_focused(self):
        """Spreading activation should rank related memories above unrelated ones."""
        pipeline = CognitiveMemoryPipeline(
            embedding_model=get_shared_model(),
            retriever_threshold=0.0,
            spread_depth=1,
            spread_factor=0.5,
            spread_top_k=3,
            retriever_top_k=10,
        )

        # Animal cluster
        pipeline.ingest("user", "Zebras have black and white stripes.")
        pipeline.ingest("user", "Lions are predators in the African savanna.")

        # Completely unrelated cluster
        pipeline.ingest("user", "Python is a programming language used for data science.")
        pipeline.ingest("user", "JavaScript runs in web browsers and on Node.js servers.")
        pipeline.ingest("user", "Docker containers help with application deployment.")

        results = pipeline.recall("tell me about zebras", top_k=10)

        # Partition into animal vs programming results
        animal_scores = []
        programming_scores = []
        for r in results:
            text = r.memory.gist.text.lower()
            if "zebra" in text or "lion" in text or "africa" in text:
                animal_scores.append(r.final_score)
            elif "python" in text or "javascript" in text or "docker" in text:
                programming_scores.append(r.final_score)

        assert len(animal_scores) > 0
        # Animal memories should all rank above programming memories
        if programming_scores:
            assert min(animal_scores) > max(programming_scores)


class TestPrimingInPipeline:
    def test_priming_boosts_subsequent_retrieval(self):
        """After talking about animals, animal memories should be primed."""
        pipeline = CognitiveMemoryPipeline(
            embedding_model=get_shared_model(),
            retriever_threshold=0.0,
            priming_boost=0.3,
            priming_decay=0.3,
        )

        # Store diverse memories
        pipeline.ingest("user", "Elephants are the largest land animals on Earth.")
        pipeline.ingest("user", "Python decorators use the @ syntax.")
        pipeline.ingest("user", "Lions live in groups called prides.")

        # First recall about animals — primes animal memories
        pipeline.recall("tell me about wild animals")

        # Now a vague query that could match either topic
        results = pipeline.recall("tell me something interesting")

        # The primed animal memories should score higher
        if results:
            top_text = results[0].memory.gist.text.lower()
            assert "elephant" in top_text or "lion" in top_text or "animal" in top_text

    def test_priming_decays_over_turns(self):
        """Priming boost should diminish after several turns."""
        pipeline = CognitiveMemoryPipeline(
            embedding_model=get_shared_model(),
            retriever_threshold=0.5,  # high threshold to prevent re-priming
            priming_boost=0.3,
            priming_decay=0.5,
            priming_max_turns=5,
        )

        pipeline.ingest("user", "Zebras live in Africa.")

        # Prime zebra memories
        results = pipeline.recall("zebras")
        assert len(results) > 0
        zebra_id = results[0].memory.id

        # Record priming boost immediately
        boost_now = pipeline.priming.get_boost(zebra_id)
        assert boost_now > 1.0

        # Process unrelated turns (high threshold prevents re-priming)
        for text in [
            "Configure the nginx reverse proxy with SSL termination.",
            "The SQL query needs a LEFT JOIN on the orders table.",
            "Refactor the authentication middleware to use JWT tokens.",
            "Set up the Kubernetes pod autoscaler with HPA metrics.",
        ]:
            pipeline.ingest("user", text)

        boost_later = pipeline.priming.get_boost(zebra_id)

        # Boost should have decayed
        assert boost_later < boost_now
        # But should still be slightly above 1.0 (within max_turns)
        assert boost_later > 1.0

    def test_priming_state_exposed(self):
        """Pipeline should expose priming state for inspection."""
        pipeline = CognitiveMemoryPipeline(embedding_model=get_shared_model(), priming_boost=0.3)

        pipeline.ingest("user", "Test content about elephants.")
        pipeline.recall("elephants")

        assert pipeline.priming.size > 0
