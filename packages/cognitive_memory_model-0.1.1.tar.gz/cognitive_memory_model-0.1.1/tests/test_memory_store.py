"""Tests for the FAISS-backed memory store."""

import numpy as np
import pytest

from cmm.core.memory_store import MemoryStore
from cmm.core.types import Gist, MemoryType


@pytest.fixture
def store():
    return MemoryStore(dim=32, nlist=4, nprobe=2)


def random_embedding(dim=32):
    v = np.random.randn(dim).astype(np.float32)
    return v / np.linalg.norm(v)


class TestMemoryStore:
    def test_store_and_retrieve(self, store):
        emb = random_embedding()
        gist = Gist(text="Zebras have black and white stripes", tags=["zebra", "stripes"])
        memory = store.store(gist=gist, embedding=emb)

        assert store.size == 1
        assert memory.id == 0
        assert memory.gist.text == "Zebras have black and white stripes"

        results = store.retrieve(emb, top_k=1)
        assert len(results) == 1
        assert results[0].memory.id == 0
        assert results[0].raw_similarity > 0.99  # should be ~1.0 for same vector

    def test_retrieve_empty_store(self, store):
        results = store.retrieve(random_embedding(), top_k=5)
        assert results == []

    def test_similarity_ordering(self, store):
        # Store two memories with known embeddings
        base = random_embedding()
        similar = base + 0.1 * random_embedding()
        different = random_embedding()

        store.store(gist=Gist(text="similar item"), embedding=similar)
        store.store(gist=Gist(text="different item"), embedding=different)

        results = store.retrieve(base, top_k=2, threshold=-1.0)
        assert len(results) == 2
        assert results[0].memory.gist.text == "similar item"
        assert results[0].raw_similarity > results[1].raw_similarity

    def test_threshold_filtering(self, store):
        store.store(gist=Gist(text="item"), embedding=random_embedding())

        # Query with an orthogonal vector — similarity should be near 0
        orthogonal = random_embedding()
        results = store.retrieve(orthogonal, top_k=5, threshold=0.99)
        # With random vectors in 32D, similarity is typically near 0
        # A threshold of 0.99 should filter most results
        for r in results:
            assert r.raw_similarity >= 0.99

    def test_ivf_training(self):
        # Use a small training threshold to trigger IVF training
        store = MemoryStore(dim=16, nlist=2, nprobe=2)
        store._training_threshold = 10

        for i in range(15):
            store.store(gist=Gist(text=f"item {i}"), embedding=random_embedding(16))

        assert store.is_trained
        assert store.size == 15

        # Retrieval should still work after training
        results = store.retrieve(random_embedding(16), top_k=3)
        assert len(results) == 3

    def test_update_access(self, store):
        emb = random_embedding()
        memory = store.store(gist=Gist(text="test"), embedding=emb)

        assert memory.access_count == 0
        store.update_access(memory.id)
        assert memory.access_count == 1
        assert memory.last_accessed > memory.timestamp

    def test_clear(self, store):
        store.store(gist=Gist(text="test"), embedding=random_embedding())
        assert store.size == 1
        store.clear()
        assert store.size == 0

    def test_get_by_id(self, store):
        memory = store.store(gist=Gist(text="findme"), embedding=random_embedding())
        retrieved = store.get(memory.id)
        assert retrieved is not None
        assert retrieved.gist.text == "findme"

        assert store.get(9999) is None
