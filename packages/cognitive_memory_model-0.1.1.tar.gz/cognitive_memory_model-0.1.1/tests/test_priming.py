"""Tests for priming state."""

import math

import pytest

from cmm.retrieval.priming import PrimingState


class TestPrimingState:
    def test_no_boost_when_not_primed(self):
        priming = PrimingState(boost_strength=0.3)
        assert priming.get_boost(42) == 1.0

    def test_full_boost_at_activation(self):
        priming = PrimingState(boost_strength=0.3)
        priming.activate(1)
        # At turn 0: boost = 1 + 0.3 * e^0 = 1.3
        assert priming.get_boost(1) == pytest.approx(1.3)

    def test_boost_decays_over_turns(self):
        priming = PrimingState(boost_strength=0.3, decay_rate=0.5)
        priming.activate(1)

        boost_0 = priming.get_boost(1)  # turn 0
        priming.tick()
        boost_1 = priming.get_boost(1)  # turn 1
        priming.tick()
        boost_2 = priming.get_boost(1)  # turn 2

        assert boost_0 > boost_1 > boost_2
        assert boost_0 == pytest.approx(1.3)
        # turn 1: 1 + 0.3 * e^(-0.5) ≈ 1.182
        assert boost_1 == pytest.approx(1 + 0.3 * math.exp(-0.5))
        # turn 2: 1 + 0.3 * e^(-1.0) ≈ 1.110
        assert boost_2 == pytest.approx(1 + 0.3 * math.exp(-1.0))

    def test_reactivation_resets_boost(self):
        priming = PrimingState(boost_strength=0.3, decay_rate=0.5)
        priming.activate(1)

        priming.tick()
        priming.tick()
        decayed_boost = priming.get_boost(1)

        # Reactivate
        priming.activate(1)
        fresh_boost = priming.get_boost(1)

        assert fresh_boost > decayed_boost
        assert fresh_boost == pytest.approx(1.3)

    def test_cleanup_after_max_turns(self):
        priming = PrimingState(boost_strength=0.3, max_turns=3)
        priming.activate(1)

        for _ in range(4):  # 4 ticks > max_turns of 3
            priming.tick()

        assert not priming.is_primed(1)
        assert priming.get_boost(1) == 1.0
        assert priming.size == 0

    def test_activate_many(self):
        priming = PrimingState(boost_strength=0.3)
        priming.activate_many([1, 2, 3])

        assert priming.size == 3
        assert all(priming.is_primed(i) for i in [1, 2, 3])

    def test_clear(self):
        priming = PrimingState()
        priming.activate_many([1, 2, 3])
        priming.clear()
        assert priming.size == 0
