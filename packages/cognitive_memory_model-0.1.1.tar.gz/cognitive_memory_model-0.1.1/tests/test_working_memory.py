"""Tests for the working memory buffer."""

import numpy as np
import pytest

from cmm.core.types import Gist, Memory
from cmm.retrieval.working_memory import WorkingMemory


def make_memory(memory_id: int, text: str = "test") -> Memory:
    return Memory(
        id=memory_id,
        gist=Gist(text=text),
        embedding=np.zeros(32, dtype=np.float32),
        timestamp=0.0,
    )


class TestWorkingMemory:
    def test_activate_and_retrieve(self):
        wm = WorkingMemory(capacity=5, default_ttl=3)
        mem = make_memory(0, "zebra facts")
        wm.activate(mem, score=0.9)

        active = wm.get_active()
        assert len(active) == 1
        assert active[0].memory.gist.text == "zebra facts"

    def test_ttl_expiry(self):
        wm = WorkingMemory(capacity=5, default_ttl=3)
        mem = make_memory(0)
        wm.activate(mem, score=0.8)

        wm.tick()  # 2 turns left
        assert wm.size == 1
        wm.tick()  # 1 turn left
        assert wm.size == 1
        wm.tick()  # expired
        assert wm.size == 0

    def test_reactivation_resets_ttl(self):
        wm = WorkingMemory(capacity=5, default_ttl=3)
        mem = make_memory(0)
        wm.activate(mem, score=0.8)

        wm.tick()  # 2 turns left
        wm.tick()  # 1 turn left

        # Reactivate — should reset to 3 turns
        wm.activate(mem, score=0.85)
        wm.tick()  # 2 turns left
        wm.tick()  # 1 turn left
        assert wm.size == 1  # still alive
        wm.tick()  # expired
        assert wm.size == 0

    def test_reactivation_keeps_higher_score(self):
        wm = WorkingMemory(capacity=5, default_ttl=3)
        mem = make_memory(0)
        wm.activate(mem, score=0.9)
        wm.activate(mem, score=0.7)  # lower score shouldn't replace

        active = wm.get_active()
        assert active[0].final_score == 0.9

        wm.activate(mem, score=0.95)  # higher score should replace
        active = wm.get_active()
        assert active[0].final_score == 0.95

    def test_capacity_eviction(self):
        wm = WorkingMemory(capacity=3, default_ttl=5)
        wm.activate(make_memory(0), score=0.5)
        wm.activate(make_memory(1), score=0.9)
        wm.activate(make_memory(2), score=0.7)

        assert wm.size == 3

        # Adding a 4th should evict the lowest (id=0, score=0.5)
        wm.activate(make_memory(3), score=0.8)
        assert wm.size == 3
        assert not wm.contains(0)
        assert wm.contains(1)
        assert wm.contains(2)
        assert wm.contains(3)

    def test_clear(self):
        wm = WorkingMemory(capacity=5, default_ttl=3)
        wm.activate(make_memory(0), score=0.5)
        wm.activate(make_memory(1), score=0.6)
        assert wm.size == 2
        wm.clear()
        assert wm.size == 0

    def test_natural_clearing_on_topic_shift(self):
        """Items not reactivated naturally clear after TTL turns."""
        wm = WorkingMemory(capacity=10, default_ttl=3)

        # Activate some animal memories
        wm.activate(make_memory(0, "zebra"), score=0.9)
        wm.activate(make_memory(1, "elephant"), score=0.8)

        # Simulate turns about a completely different topic (no reactivation)
        for _ in range(3):
            wm.tick()

        # Animal memories should have expired
        assert wm.size == 0

        # New topic memories can now fill the buffer
        wm.activate(make_memory(2, "python code"), score=0.7)
        assert wm.size == 1
