"""Tests for importance scoring."""

import numpy as np
import pytest

from cmm.core.types import ConversationTurn, Role
from cmm.scoring.importance import RuleBasedImportanceScorer
from tests.conftest import get_shared_model


class TestRuleBasedImportanceScorer:
    @pytest.fixture
    def scorer(self):
        return RuleBasedImportanceScorer()

    # --- Corrections ---

    def test_correction_no_i_meant(self, scorer):
        turn = ConversationTurn(role=Role.USER, content="No, I meant the other file.")
        assert scorer.score(turn) == 2.0

    def test_correction_thats_wrong(self, scorer):
        turn = ConversationTurn(role=Role.USER, content="That's wrong, it should be Python 3.")
        assert scorer.score(turn) == 2.0

    def test_correction_actually(self, scorer):
        turn = ConversationTurn(role=Role.USER, content="Actually, I want to use PostgreSQL instead.")
        assert scorer.score(turn) == 2.0

    def test_correction_you_are_wrong(self, scorer):
        turn = ConversationTurn(role=Role.USER, content="You're wrong about that.")
        assert scorer.score(turn) == 2.0

    # --- Instructions ---

    def test_instruction_always(self, scorer):
        turn = ConversationTurn(role=Role.USER, content="Always use type hints in Python code.")
        assert scorer.score(turn) == 2.0

    def test_instruction_never(self, scorer):
        turn = ConversationTurn(role=Role.USER, content="Never commit directly to main.")
        assert scorer.score(turn) == 2.0

    def test_instruction_remember(self, scorer):
        turn = ConversationTurn(role=Role.USER, content="Remember this: the API key rotates weekly.")
        assert scorer.score(turn) == 2.0

    def test_instruction_preference(self, scorer):
        turn = ConversationTurn(role=Role.USER, content="I prefer tabs over spaces.")
        assert scorer.score(turn) == 2.0

    def test_instruction_from_now_on(self, scorer):
        turn = ConversationTurn(role=Role.USER, content="From now on, use snake_case for variables.")
        assert scorer.score(turn) == 2.0

    # --- Routine ---

    def test_routine_greeting(self, scorer):
        turn = ConversationTurn(role=Role.USER, content="Hello")
        assert scorer.score(turn) == 0.5

    def test_routine_thanks(self, scorer):
        turn = ConversationTurn(role=Role.USER, content="Thanks")
        assert scorer.score(turn) == 0.5

    def test_routine_ok(self, scorer):
        turn = ConversationTurn(role=Role.USER, content="Ok")
        assert scorer.score(turn) == 0.5

    def test_routine_sounds_good(self, scorer):
        turn = ConversationTurn(role=Role.USER, content="Sounds good")
        assert scorer.score(turn) == 0.5

    # --- Normal ---

    def test_normal_question(self, scorer):
        turn = ConversationTurn(role=Role.USER, content="How do I set up a virtual environment in Python?")
        assert scorer.score(turn) == 1.0

    def test_normal_statement(self, scorer):
        turn = ConversationTurn(role=Role.USER, content="The server is running on port 8080.")
        assert scorer.score(turn) == 1.0


class TestImportanceInPipeline:
    """Test importance scoring integrated in the pipeline."""

    def test_corrections_stored_with_high_importance(self):
        from cmm.pipeline.conversation import CognitiveMemoryPipeline

        pipeline = CognitiveMemoryPipeline(embedding_model=get_shared_model(), retriever_threshold=0.0)

        pipeline.ingest("user", "The database is PostgreSQL.")
        pipeline.ingest("user", "No, actually I meant MySQL, not PostgreSQL.")

        normal_mem = pipeline.store.get(0)
        correction_mem = pipeline.store.get(1)

        assert correction_mem.importance > normal_mem.importance
        assert correction_mem.importance == 2.0

    def test_routine_stored_with_low_importance(self):
        from cmm.pipeline.conversation import CognitiveMemoryPipeline

        pipeline = CognitiveMemoryPipeline(embedding_model=get_shared_model(), retriever_threshold=0.0)

        pipeline.ingest("user", "Hello")
        pipeline.ingest("user", "I need to debug a complex Python data pipeline.")

        greeting_mem = pipeline.store.get(0)
        content_mem = pipeline.store.get(1)

        assert greeting_mem.importance < content_mem.importance
        assert greeting_mem.importance == 0.5

    def test_novel_info_gets_moderate_importance(self):
        from cmm.pipeline.conversation import CognitiveMemoryPipeline

        pipeline = CognitiveMemoryPipeline(embedding_model=get_shared_model(), retriever_threshold=0.0)

        # Fill store with Python-related content
        pipeline.ingest("user", "Python is great for data science.")
        pipeline.ingest("user", "Python has excellent machine learning libraries.")
        pipeline.ingest("user", "I use Python pandas for data analysis.")

        # Now introduce a completely novel topic
        pipeline.ingest("user", "My car's transmission needs to be replaced.")

        novel_mem = pipeline.store.get(3)
        # Should be scored as novel (dissimilar to Python memories)
        assert novel_mem.importance >= 1.5

    def test_importance_affects_retrieval_ranking(self):
        """High importance memories should have higher final_score than raw similarity would give."""
        from cmm.pipeline.conversation import CognitiveMemoryPipeline

        pipeline = CognitiveMemoryPipeline(embedding_model=get_shared_model(), retriever_threshold=0.0)

        pipeline.ingest("user", "No, I meant the config uses TOML format, not YAML.")

        results = pipeline.recall("TOML config format", top_k=5)
        assert len(results) >= 1

        correction = results[0]
        # Importance of 2.0 means final_score should be ~2x raw_similarity
        assert correction.memory.importance == 2.0
        assert correction.final_score > correction.raw_similarity * 1.5
