"""Tests for spreading activation."""

import numpy as np
import pytest

from cmm.core.memory_store import MemoryStore
from cmm.core.types import Gist, RetrievalResult
from cmm.retrieval.spreading_activation import SpreadingActivation


def make_embedding(dim=32, seed=None):
    rng = np.random.RandomState(seed)
    v = rng.randn(dim).astype(np.float32)
    return v / np.linalg.norm(v)


def make_cluster(center, n, dim=32, noise=0.1):
    """Make n embeddings clustered around center."""
    vecs = []
    for i in range(n):
        v = center + noise * make_embedding(dim, seed=1000 + i)
        v = v / np.linalg.norm(v)
        vecs.append(v)
    return vecs


class TestSpreadingActivation:
    def test_spread_finds_neighbors(self):
        """Spreading from a seed should find its embedding-space neighbors."""
        store = MemoryStore(dim=32, nlist=4, nprobe=2)

        # Create a cluster of related memories
        center = make_embedding(32, seed=42)
        cluster_vecs = make_cluster(center, 5, noise=0.15)
        for i, v in enumerate(cluster_vecs):
            store.store(gist=Gist(text=f"related-{i}"), embedding=v)

        # Add some unrelated memories
        for i in range(5):
            store.store(gist=Gist(text=f"unrelated-{i}"), embedding=make_embedding(32, seed=100 + i))

        # Create a seed result from the first cluster item
        seed = RetrievalResult(
            memory=store.get(0),
            raw_similarity=0.9,
            final_score=0.9,
        )

        sa = SpreadingActivation(store=store, max_depth=1, spread_factor=0.5, spread_top_k=5)
        results = sa.spread([seed])

        # Should include the seed + some cluster neighbors
        assert len(results) > 1
        result_ids = {r.memory.id for r in results}
        assert 0 in result_ids  # seed is preserved

        # At least some cluster neighbors should appear
        cluster_ids = {0, 1, 2, 3, 4}
        found_neighbors = result_ids & cluster_ids
        assert len(found_neighbors) >= 2

    def test_spread_score_decay(self):
        """Spread-activated items should have lower scores than seeds."""
        store = MemoryStore(dim=32, nlist=4, nprobe=2)

        center = make_embedding(32, seed=42)
        cluster_vecs = make_cluster(center, 5, noise=0.1)
        for i, v in enumerate(cluster_vecs):
            store.store(gist=Gist(text=f"item-{i}"), embedding=v)

        seed = RetrievalResult(
            memory=store.get(0),
            raw_similarity=0.9,
            final_score=0.9,
        )

        sa = SpreadingActivation(store=store, max_depth=1, spread_factor=0.5, spread_top_k=5)
        results = sa.spread([seed])

        # Seed should be the highest scored
        assert results[0].memory.id == 0
        # Spread-activated items should have scores < seed's score
        for r in results[1:]:
            assert r.final_score < seed.final_score

    def test_no_spread_with_depth_zero(self):
        """max_depth=0 should return seeds unchanged."""
        store = MemoryStore(dim=32)
        store.store(gist=Gist(text="item"), embedding=make_embedding(32, seed=1))
        store.store(gist=Gist(text="neighbor"), embedding=make_embedding(32, seed=2))

        seed = RetrievalResult(memory=store.get(0), raw_similarity=0.9, final_score=0.9)
        sa = SpreadingActivation(store=store, max_depth=0)
        results = sa.spread([seed])

        assert len(results) == 1
        assert results[0].memory.id == 0

    def test_deduplication_keeps_max_score(self):
        """If a memory is reachable via multiple paths, keep the highest score."""
        store = MemoryStore(dim=32)

        # Triangle: A, B, C all close to each other
        center = make_embedding(32, seed=42)
        vecs = make_cluster(center, 3, noise=0.05)
        for i, v in enumerate(vecs):
            store.store(gist=Gist(text=f"node-{i}"), embedding=v)

        # Two seeds that both neighbor node-2
        seed_a = RetrievalResult(memory=store.get(0), raw_similarity=0.9, final_score=0.9)
        seed_b = RetrievalResult(memory=store.get(1), raw_similarity=0.8, final_score=0.8)

        sa = SpreadingActivation(store=store, max_depth=1, spread_factor=0.5, spread_top_k=5)
        results = sa.spread([seed_a, seed_b])

        # node-2 should appear only once
        node2_results = [r for r in results if r.memory.id == 2]
        assert len(node2_results) == 1

    def test_empty_seeds(self):
        """Spreading with no seeds returns empty."""
        store = MemoryStore(dim=32)
        sa = SpreadingActivation(store=store)
        assert sa.spread([]) == []
