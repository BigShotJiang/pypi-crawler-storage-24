"""Phase 2 integration tests — decay, rehearsal, and working memory in the pipeline."""

import time

import pytest

from cmm.core.memory_store import MemoryStore
from cmm.core.types import Gist
from cmm.pipeline.conversation import CognitiveMemoryPipeline
from cmm.retrieval.decay import DecayScorer, SECONDS_PER_DAY
from tests.conftest import get_shared_model


class TestDecayInPipeline:
    def test_no_decay_within_grace_period(self):
        """Memories within the grace period should not decay."""
        pipeline = CognitiveMemoryPipeline(embedding_model=get_shared_model(), retriever_threshold=0.0)

        pipeline.ingest("user", "Zebras have black and white stripes.")

        memory = pipeline.store.get(0)
        # Backdate by 1 week — still within default 2-week grace
        memory.timestamp -= 7 * SECONDS_PER_DAY
        memory.last_accessed -= 7 * SECONDS_PER_DAY

        scorer = pipeline.retriever.decay_scorer
        decay = scorer.compute_decay(memory, now=time.time())
        assert decay == 1.0

    def test_old_memories_decay_after_grace(self):
        """Memories past the grace period should decay."""
        # Short grace period for testing
        scorer = DecayScorer(grace_period=0, decay_rate=1e-5)
        now = time.time()

        young = Gist(text="young")
        old = Gist(text="old")

        import numpy as np
        young_mem = type('M', (), {
            'last_accessed': now - SECONDS_PER_DAY,
            'timestamp': now - SECONDS_PER_DAY,
            'access_count': 0
        })()
        old_mem = type('M', (), {
            'last_accessed': now - 30 * SECONDS_PER_DAY,
            'timestamp': now - 30 * SECONDS_PER_DAY,
            'access_count': 0
        })()

        young_decay = scorer.compute_decay(young_mem, now=now)
        old_decay = scorer.compute_decay(old_mem, now=now)

        assert young_decay > old_decay
        assert old_decay < 1.0

    def test_accessed_memories_resist_decay(self):
        """Memories that have been accessed frequently should decay slower."""
        scorer = DecayScorer(grace_period=0, decay_rate=1e-5, freq_weight=1.0)
        now = time.time()
        age = 30 * SECONDS_PER_DAY

        from cmm.core.types import Memory
        import numpy as np

        rare = Memory(
            id=0, gist=Gist(text="rare"), embedding=np.zeros(32),
            timestamp=now - age, last_accessed=now - age, access_count=1,
        )
        frequent = Memory(
            id=1, gist=Gist(text="frequent"), embedding=np.zeros(32),
            timestamp=now - age, last_accessed=now - age, access_count=20,
        )

        assert scorer.compute_decay(frequent, now=now) > scorer.compute_decay(rare, now=now)


class TestWorkingMemoryInPipeline:
    def test_working_memory_keeps_recent_retrievals(self):
        """Recently retrieved memories should stay in working memory."""
        pipeline = CognitiveMemoryPipeline(
            embedding_model=get_shared_model(),
            retriever_threshold=0.1,
            working_memory_ttl=5,
        )

        pipeline.ingest("user", "Elephants are the largest land animals.")
        pipeline.ingest("user", "Something completely unrelated about databases.")

        results = pipeline.recall("elephants")
        elephant_results = [r for r in results if "elephant" in r.memory.gist.text.lower()]
        assert len(elephant_results) > 0

        wm = pipeline.working_memory
        assert wm.size > 0

    def test_working_memory_clears_after_ttl(self):
        """Working memory items should expire after TTL turns."""
        pipeline = CognitiveMemoryPipeline(
            embedding_model=get_shared_model(),
            retriever_threshold=0.4,  # higher threshold to prevent re-activation
            working_memory_ttl=3,
        )

        pipeline.ingest("user", "Elephants are the largest land animals.")

        pipeline.recall("elephants")
        assert pipeline.working_memory.size > 0

        # Use very different topics to avoid re-activation of elephant memory
        for text in [
            "Configure the nginx reverse proxy with SSL termination.",
            "The SQL query needs a LEFT JOIN on the orders table.",
            "Refactor the authentication middleware to use JWT tokens.",
            "Set up the Kubernetes pod autoscaler with HPA metrics.",
        ]:
            pipeline.ingest("user", text)

        wm_texts = [r.memory.gist.text.lower() for r in pipeline.working_memory.get_active()]
        assert not any("elephant" in t for t in wm_texts)

    def test_working_memory_reactivation(self):
        """Retrieving a memory again should reset its working memory TTL."""
        pipeline = CognitiveMemoryPipeline(
            embedding_model=get_shared_model(),
            retriever_threshold=0.1,
            working_memory_ttl=3,
        )

        pipeline.ingest("user", "Zebras have unique stripe patterns.")

        pipeline.recall("zebra stripes")
        assert pipeline.working_memory.size > 0

        pipeline.ingest("user", "Unrelated topic one.")
        pipeline.ingest("user", "Unrelated topic two.")

        pipeline.recall("zebra stripes")

        pipeline.ingest("user", "Unrelated topic three.")
        pipeline.ingest("user", "Unrelated topic four.")

        wm_texts = [r.memory.gist.text.lower() for r in pipeline.working_memory.get_active()]
        assert any("zebra" in t or "stripe" in t for t in wm_texts)
