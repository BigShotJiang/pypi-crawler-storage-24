"""Cognitive Memory Model — autoassociative memory for LLMs/agents."""

__version__ = "0.1.1"
