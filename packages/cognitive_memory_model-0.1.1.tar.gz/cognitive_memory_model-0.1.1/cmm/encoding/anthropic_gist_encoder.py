"""Anthropic Claude gist encoder — uses the Anthropic API for gist compression.

Usage:
    encoder = AnthropicGistEncoder()  # uses ANTHROPIC_API_KEY env var
    encoder = AnthropicGistEncoder(model="claude-haiku-4-5-20251001")  # cheapest
"""

import json
import logging
import os

from cmm.core.types import ConversationTurn, Gist
from cmm.encoding.gist_encoder import GistEncoder

logger = logging.getLogger(__name__)

_SYSTEM_PROMPT = """\
You are a memory encoder. Your job is to compress a conversation turn into a short gist summary and extract key tags.

Rules:
- The gist should be 1-2 sentences capturing the core meaning.
- Write the gist in third person (e.g., "User asked about..." or "Assistant explained...").
- Preserve specific names, numbers, and key facts — these are retrieval cues.
- Tags should be individual key concepts, entities, or topics (3-10 tags).
- Respond ONLY with valid JSON in this exact format, no other text:

{"gist": "...", "tags": ["tag1", "tag2", ...]}"""

_USER_TEMPLATE = """\
{context_block}Turn to encode ({role}):
{content}"""

_CONTEXT_TEMPLATE = """\
Recent context:
{turns}

"""


class AnthropicGistEncoder(GistEncoder):
    """Gist encoder using the Anthropic Claude API."""

    def __init__(
        self,
        model: str = "claude-haiku-4-5-20251001",
        api_key: str | None = None,
        temperature: float = 0.1,
        max_tokens: int = 256,
    ):
        import anthropic

        self.model = model
        self.temperature = temperature
        self.max_tokens = max_tokens

        key = api_key or os.environ.get("ANTHROPIC_API_KEY")
        if not key:
            # Try .env file
            env_path = os.path.join(os.path.dirname(__file__), "..", "..", ".env")
            if os.path.exists(env_path):
                with open(env_path) as f:
                    for line in f:
                        line = line.strip()
                        if line.startswith("ANTHROPIC_API_KEY="):
                            key = line.split("=", 1)[1].strip().strip("'\"")
                            break

        self._client = anthropic.Anthropic(api_key=key)

    def encode(self, turn: ConversationTurn, context: list[ConversationTurn] | None = None) -> Gist:
        context_block = ""
        if context:
            turns_text = "\n".join(
                f"  [{t.role.value}]: {t.content[:200]}" for t in context[-3:]
            )
            context_block = _CONTEXT_TEMPLATE.format(turns=turns_text)

        user_message = _USER_TEMPLATE.format(
            context_block=context_block,
            role=turn.role.value,
            content=turn.content,
        )

        try:
            response = self._client.messages.create(
                model=self.model,
                max_tokens=self.max_tokens,
                temperature=self.temperature,
                system=_SYSTEM_PROMPT,
                messages=[{"role": "user", "content": user_message}],
            )
            raw = response.content[0].text.strip()
            return self._parse_response(raw, turn)

        except Exception as e:
            logger.warning("Anthropic gist encoding failed: %s. Falling back to passthrough.", e)
            return self._fallback(turn)

    def _parse_response(self, raw: str, turn: ConversationTurn) -> Gist:
        text = raw
        if text.startswith("```"):
            lines = text.split("\n")
            lines = [l for l in lines if not l.strip().startswith("```")]
            text = "\n".join(lines)

        try:
            data = json.loads(text)
            gist_text = data.get("gist", "").strip()
            tags = data.get("tags", [])
            if not gist_text:
                return self._fallback(turn)
            tags = [str(t).lower().strip() for t in tags if t]
            return Gist(text=gist_text, tags=tags)
        except (json.JSONDecodeError, AttributeError):
            logger.warning("Failed to parse gist JSON: %s", raw[:200])
            return self._fallback(turn)

    @staticmethod
    def _fallback(turn: ConversationTurn) -> Gist:
        text = turn.content[:512]
        if len(turn.content) > 512:
            text += "..."
        return Gist(text=text, tags=[])
