"""OpenAI-compatible gist encoder — works with any OpenAI-compatible API.

Supports: OpenAI, Together AI, Groq, Anyscale, vLLM, LM Studio, and
any server that implements the /v1/chat/completions endpoint.

Usage:
    # OpenAI
    encoder = OpenAIGistEncoder(api_key="sk-...", model="gpt-4o-mini")

    # Together AI
    encoder = OpenAIGistEncoder(
        api_key="...",
        base_url="https://api.together.xyz/v1",
        model="meta-llama/Llama-3-8b-chat-hf",
    )

    # Local vLLM / LM Studio
    encoder = OpenAIGistEncoder(
        base_url="http://localhost:8000/v1",
        model="local-model",
        api_key="not-needed",
    )
"""

import json
import logging
import os

import httpx

from cmm.core.types import ConversationTurn, Gist
from cmm.encoding.gist_encoder import GistEncoder

logger = logging.getLogger(__name__)

_SYSTEM_PROMPT = """\
You are a memory encoder. Your job is to compress a conversation turn into a short gist summary and extract key tags.

Rules:
- The gist should be 1-2 sentences capturing the core meaning.
- Write the gist in third person (e.g., "User asked about..." or "Assistant explained...").
- Preserve specific names, numbers, and key facts — these are retrieval cues.
- Tags should be individual key concepts, entities, or topics (3-10 tags).
- Respond ONLY with valid JSON in this exact format, no other text:

{"gist": "...", "tags": ["tag1", "tag2", ...]}"""

_USER_TEMPLATE = """\
{context_block}Turn to encode ({role}):
{content}"""

_CONTEXT_TEMPLATE = """\
Recent context:
{turns}

"""


class OpenAIGistEncoder(GistEncoder):
    """Gist encoder using any OpenAI-compatible API."""

    def __init__(
        self,
        model: str = "gpt-4o-mini",
        base_url: str = "https://api.openai.com/v1",
        api_key: str | None = None,
        timeout: float = 30.0,
        temperature: float = 0.1,
    ):
        self.model = model
        self.base_url = base_url.rstrip("/")
        self.api_key = api_key or os.environ.get("OPENAI_API_KEY", "")
        self.temperature = temperature
        self._client = httpx.Client(timeout=timeout)

    def encode(self, turn: ConversationTurn, context: list[ConversationTurn] | None = None) -> Gist:
        context_block = ""
        if context:
            turns_text = "\n".join(
                f"  [{t.role.value}]: {t.content[:200]}" for t in context[-3:]
            )
            context_block = _CONTEXT_TEMPLATE.format(turns=turns_text)

        user_message = _USER_TEMPLATE.format(
            context_block=context_block,
            role=turn.role.value,
            content=turn.content,
        )

        try:
            response = self._client.post(
                f"{self.base_url}/chat/completions",
                headers={
                    "Authorization": f"Bearer {self.api_key}",
                    "Content-Type": "application/json",
                },
                json={
                    "model": self.model,
                    "messages": [
                        {"role": "system", "content": _SYSTEM_PROMPT},
                        {"role": "user", "content": user_message},
                    ],
                    "temperature": self.temperature,
                    "max_tokens": 256,
                },
            )
            response.raise_for_status()
            raw = response.json()["choices"][0]["message"]["content"].strip()
            return self._parse_response(raw, turn)

        except Exception as e:
            logger.warning("OpenAI gist encoding failed: %s. Falling back to passthrough.", e)
            return self._fallback(turn)

    def _parse_response(self, raw: str, turn: ConversationTurn) -> Gist:
        text = raw
        if text.startswith("```"):
            lines = text.split("\n")
            lines = [l for l in lines if not l.strip().startswith("```")]
            text = "\n".join(lines)

        try:
            data = json.loads(text)
            gist_text = data.get("gist", "").strip()
            tags = data.get("tags", [])
            if not gist_text:
                return self._fallback(turn)
            tags = [str(t).lower().strip() for t in tags if t]
            return Gist(text=gist_text, tags=tags)
        except (json.JSONDecodeError, AttributeError):
            logger.warning("Failed to parse gist JSON: %s", raw[:200])
            return self._fallback(turn)

    @staticmethod
    def _fallback(turn: ConversationTurn) -> Gist:
        text = turn.content[:512]
        if len(turn.content) > 512:
            text += "..."
        return Gist(text=text, tags=[])

    def close(self):
        self._client.close()
