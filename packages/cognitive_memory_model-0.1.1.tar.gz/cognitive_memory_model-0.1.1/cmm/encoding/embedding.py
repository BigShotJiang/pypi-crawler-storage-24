"""Sentence embedding layer for converting text to dense vectors."""

import numpy as np
from sentence_transformers import SentenceTransformer


class EmbeddingModel:
    """Wraps a sentence-transformers model for text → vector encoding."""

    def __init__(self, model_name: str = "all-mpnet-base-v2", device: str | None = None):
        self.model_name = model_name
        self._model = SentenceTransformer(model_name, device=device)
        self.dim = self._model.get_sentence_embedding_dimension()

    def embed(self, text: str) -> np.ndarray:
        """Embed a single text string."""
        return self._model.encode(text, normalize_embeddings=True)

    def embed_batch(self, texts: list[str]) -> np.ndarray:
        """Embed a batch of texts."""
        return self._model.encode(texts, normalize_embeddings=True)
