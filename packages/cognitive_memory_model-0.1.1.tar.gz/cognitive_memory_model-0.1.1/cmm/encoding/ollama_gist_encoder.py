"""Ollama-based gist encoder — uses a local LLM to compress conversation turns."""

import json
import logging

import httpx

from cmm.core.types import ConversationTurn, Gist
from cmm.encoding.gist_encoder import GistEncoder

logger = logging.getLogger(__name__)

_SYSTEM_PROMPT = """\
You are a memory encoder. Your job is to compress a conversation turn into a short gist summary and extract key tags.

Rules:
- The gist should be 1-2 sentences capturing the core meaning.
- Write the gist in third person (e.g., "User asked about..." or "Assistant explained...").
- Preserve specific names, numbers, and key facts — these are retrieval cues.
- Tags should be individual key concepts, entities, or topics (3-10 tags).
- Respond ONLY with valid JSON in this exact format, no other text:

{"gist": "...", "tags": ["tag1", "tag2", ...]}"""

_USER_TEMPLATE = """\
{context_block}Turn to encode ({role}):
{content}"""

_CONTEXT_TEMPLATE = """\
Recent context:
{turns}

"""


class OllamaGistEncoder(GistEncoder):
    """Gist encoder using a local Ollama model."""

    def __init__(
        self,
        model: str = "mistral:7b-instruct-q4_K_M",
        base_url: str = "http://localhost:11434",
        timeout: float = 30.0,
        temperature: float = 0.1,
    ):
        self.model = model
        self.base_url = base_url
        self.timeout = timeout
        self.temperature = temperature
        self._client = httpx.Client(timeout=timeout)

    def encode(self, turn: ConversationTurn, context: list[ConversationTurn] | None = None) -> Gist:
        context_block = ""
        if context:
            turns_text = "\n".join(
                f"  [{t.role.value}]: {t.content[:200]}" for t in context[-3:]
            )
            context_block = _CONTEXT_TEMPLATE.format(turns=turns_text)

        user_message = _USER_TEMPLATE.format(
            context_block=context_block,
            role=turn.role.value,
            content=turn.content,
        )

        try:
            response = self._client.post(
                f"{self.base_url}/api/generate",
                json={
                    "model": self.model,
                    "prompt": user_message,
                    "system": _SYSTEM_PROMPT,
                    "stream": False,
                    "options": {
                        "temperature": self.temperature,
                        "num_predict": 256,
                    },
                },
            )
            response.raise_for_status()
            raw = response.json()["response"].strip()
            return self._parse_response(raw, turn)

        except Exception as e:
            logger.warning("Ollama gist encoding failed: %s. Falling back to passthrough.", e)
            return self._fallback(turn)

    def _parse_response(self, raw: str, turn: ConversationTurn) -> Gist:
        """Parse the JSON response from the model."""
        # Strip markdown code fences if present
        text = raw
        if text.startswith("```"):
            lines = text.split("\n")
            # Remove first and last lines (the fences)
            lines = [l for l in lines if not l.strip().startswith("```")]
            text = "\n".join(lines)

        try:
            data = json.loads(text)
            gist_text = data.get("gist", "").strip()
            tags = data.get("tags", [])
            if not gist_text:
                return self._fallback(turn)
            # Ensure tags are strings and lowercase
            tags = [str(t).lower().strip() for t in tags if t]
            return Gist(text=gist_text, tags=tags)
        except (json.JSONDecodeError, AttributeError):
            logger.warning("Failed to parse gist JSON: %s", raw[:200])
            return self._fallback(turn)

    @staticmethod
    def _fallback(turn: ConversationTurn) -> Gist:
        """Passthrough fallback if LLM encoding fails."""
        text = turn.content[:512]
        if len(turn.content) > 512:
            text += "..."
        return Gist(text=text, tags=[])

    def close(self):
        self._client.close()

    def __del__(self):
        try:
            self._client.close()
        except Exception:
            pass
