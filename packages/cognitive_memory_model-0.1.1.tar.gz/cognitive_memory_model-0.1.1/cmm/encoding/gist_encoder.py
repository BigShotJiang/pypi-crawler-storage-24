"""Gist encoder — compresses conversation turns into summary + tags.

This module defines the GistEncoder protocol and provides a simple
extractive implementation. For LLM-based gist encoding, subclass
GistEncoder and implement the encode() method with your LLM API.
"""

import re
from abc import ABC, abstractmethod

from cmm.core.types import ConversationTurn, Gist


class GistEncoder(ABC):
    """Base class for gist encoding strategies."""

    @abstractmethod
    def encode(self, turn: ConversationTurn, context: list[ConversationTurn] | None = None) -> Gist:
        """Compress a conversation turn into a gist.

        Args:
            turn: The conversation turn to encode.
            context: Optional preceding turns for context.

        Returns:
            A Gist with compressed text and extracted tags.
        """
        ...


class PassthroughGistEncoder(GistEncoder):
    """Passes through the raw turn content as the gist.

    Extracts simple keyword tags. Useful as a baseline and for testing
    before an LLM-based encoder is configured.
    """

    def __init__(self, max_length: int = 512):
        self.max_length = max_length

    def encode(self, turn: ConversationTurn, context: list[ConversationTurn] | None = None) -> Gist:
        text = turn.content
        if len(text) > self.max_length:
            text = text[: self.max_length] + "..."

        tags = self._extract_tags(turn.content)
        return Gist(text=text, tags=tags)

    @staticmethod
    def _extract_tags(text: str) -> list[str]:
        """Extract simple keyword tags from text.

        Pulls out words that are likely meaningful: capitalized words
        (potential proper nouns/concepts), and longer words that aren't
        common stop words.
        """
        stop_words = {
            "the", "a", "an", "is", "are", "was", "were", "be", "been",
            "being", "have", "has", "had", "do", "does", "did", "will",
            "would", "could", "should", "may", "might", "can", "shall",
            "this", "that", "these", "those", "it", "its", "i", "you",
            "he", "she", "we", "they", "me", "him", "her", "us", "them",
            "my", "your", "his", "our", "their", "what", "which", "who",
            "when", "where", "why", "how", "not", "no", "nor", "but",
            "and", "or", "if", "then", "than", "too", "very", "just",
            "about", "above", "after", "again", "all", "also", "any",
            "because", "before", "between", "both", "each", "for",
            "from", "get", "got", "here", "in", "into", "of", "on",
            "only", "other", "out", "over", "own", "same", "so", "some",
            "such", "to", "under", "up", "with", "there", "more",
        }
        words = re.findall(r"\b[a-zA-Z]{3,}\b", text)
        tags = []
        seen = set()
        for word in words:
            lower = word.lower()
            if lower not in stop_words and lower not in seen:
                # Keep capitalized words and longer words
                if word[0].isupper() or len(word) >= 5:
                    tags.append(lower)
                    seen.add(lower)
        return tags[:20]
