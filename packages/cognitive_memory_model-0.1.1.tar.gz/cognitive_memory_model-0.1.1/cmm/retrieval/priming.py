"""Priming state — recently activated memories boost retrieval of related memories."""

import math


class PrimingState:
    """Tracks recently activated memories and provides a retrieval boost.

    When a memory is activated (retrieved), it and its neighbors become
    "primed" — easier to retrieve for the next several turns. The boost
    decays over turns:

        priming_boost = 1 + boost_strength * e^(-decay_rate * turns_since_activation)

    This creates conversational coherence: if we just talked about animals,
    animal-related memories remain more accessible for a while.
    """

    def __init__(
        self,
        boost_strength: float = 0.3,
        decay_rate: float = 0.5,
        max_turns: int = 10,
    ):
        """
        Args:
            boost_strength: Maximum boost at turn 0 (added to 1.0).
                0.3 means a just-primed memory gets a 1.3x score multiplier.
            decay_rate: How fast priming decays per turn. Higher = faster decay.
                0.5 means ~60% of boost remains after 1 turn, ~37% after 2.
            max_turns: Priming entries older than this are cleaned up.
        """
        self.boost_strength = boost_strength
        self.decay_rate = decay_rate
        self.max_turns = max_turns

        # memory_id -> turns since last activation
        self._primed: dict[int, int] = {}

    def activate(self, memory_id: int) -> None:
        """Mark a memory as primed (reset its turn counter to 0)."""
        self._primed[memory_id] = 0

    def activate_many(self, memory_ids: list[int]) -> None:
        """Mark multiple memories as primed."""
        for mid in memory_ids:
            self._primed[mid] = 0

    def tick(self) -> None:
        """Advance one turn. Increments all counters and cleans up expired entries."""
        expired = []
        for memory_id in self._primed:
            self._primed[memory_id] += 1
            if self._primed[memory_id] > self.max_turns:
                expired.append(memory_id)
        for memory_id in expired:
            del self._primed[memory_id]

    def get_boost(self, memory_id: int) -> float:
        """Get the priming boost multiplier for a memory.

        Returns 1.0 (no boost) if the memory is not primed.
        """
        if memory_id not in self._primed:
            return 1.0

        turns = self._primed[memory_id]
        return 1.0 + self.boost_strength * math.exp(-self.decay_rate * turns)

    def is_primed(self, memory_id: int) -> bool:
        return memory_id in self._primed

    @property
    def size(self) -> int:
        return len(self._primed)

    def clear(self) -> None:
        self._primed.clear()
