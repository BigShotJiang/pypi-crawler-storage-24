"""Temporal decay and rehearsal scoring for memory retrieval.

Decay model inspired by human memory:
- Grace period: no decay for a configurable window after last access (default 2 weeks)
- After grace period: exponential decay begins
- Frequency-dependent decay rate: more frequent access = slower decay
- Lock threshold: memories accessed frequently enough become permanent

This means a memory created today won't start decaying for ~2 weeks.
If it's accessed regularly during that window, the grace period resets
each time. Only neglected memories eventually fade.
"""

import math
import time

from cmm.core.types import Memory

# Time constants
SECONDS_PER_DAY = 86400
SECONDS_PER_WEEK = 604800


class DecayScorer:
    """Applies temporal decay with grace period, frequency modulation, and lock threshold.

    Decay model:
        if memory is locked (access_frequency >= lock_frequency):
            decay = 1.0  (permanent)

        if age_since_last_access <= grace_period:
            decay = 1.0  (no decay during grace)

        else:
            effective_age = age - grace_period
            λ_eff = base_rate / frequency_factor
            frequency_factor = 1 + freq_weight * access_frequency_per_week
            decay = e^(-λ_eff * effective_age)

    Access frequency is computed as: access_count / age_in_weeks (since creation).
    """

    def __init__(
        self,
        grace_period: float = 14 * SECONDS_PER_DAY,  # 2 weeks
        decay_rate: float = 5e-7,
        freq_weight: float = 1.0,
        lock_frequency: float = 0.5,
    ):
        """
        Args:
            grace_period: Seconds after last access before decay begins.
                Default 14 days. Set to 0 to disable grace period.
            decay_rate: Base decay rate λ (per second) after grace period.
                Default 5e-7 means ~50% decay after ~16 days past grace
                for an unrehearsed memory.
            freq_weight: How much access frequency slows decay.
                Higher = stronger frequency effect.
            lock_frequency: If access_frequency (per week) >= this value,
                the memory is locked (never decays). Default 0.5 means
                a memory accessed once every 2 weeks becomes permanent.
        """
        self.grace_period = grace_period
        self.decay_rate = decay_rate
        self.freq_weight = freq_weight
        self.lock_frequency = lock_frequency

    def compute_decay(self, memory: Memory, now: float | None = None) -> float:
        """Compute the decay factor for a memory (0 to 1).

        Returns 1.0 during grace period or if memory is locked.
        """
        if now is None:
            now = time.time()

        # No decay if rate is zero (disabled)
        if self.decay_rate <= 0:
            return 1.0

        age_since_last_access = max(0.0, now - memory.last_accessed)
        age_since_creation = max(1.0, now - memory.timestamp)  # avoid div by zero

        # Compute access frequency (per week)
        age_weeks = age_since_creation / SECONDS_PER_WEEK
        access_frequency = memory.access_count / max(age_weeks, 0.01)

        # Check lock threshold
        if access_frequency >= self.lock_frequency:
            return 1.0

        # Grace period — no decay
        if age_since_last_access <= self.grace_period:
            return 1.0

        # Decay starts after grace period
        effective_age = age_since_last_access - self.grace_period

        # Frequency modulates decay rate (higher frequency = slower decay)
        frequency_factor = 1.0 + self.freq_weight * access_frequency
        effective_rate = self.decay_rate / frequency_factor

        return math.exp(-effective_rate * effective_age)

    def is_locked(self, memory: Memory, now: float | None = None) -> bool:
        """Check if a memory is permanently locked due to frequent access."""
        if now is None:
            now = time.time()

        age_since_creation = max(1.0, now - memory.timestamp)
        age_weeks = age_since_creation / SECONDS_PER_WEEK
        access_frequency = memory.access_count / max(age_weeks, 0.01)

        return access_frequency >= self.lock_frequency

    def apply(self, raw_similarity: float, memory: Memory, now: float | None = None) -> float:
        """Apply decay to a raw similarity score."""
        decay = self.compute_decay(memory, now)
        return raw_similarity * decay
