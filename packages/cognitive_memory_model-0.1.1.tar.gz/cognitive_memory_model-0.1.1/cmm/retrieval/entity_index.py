"""Entity index — maps named entities to memory IDs for entity-linked spreading activation.

Extracts named entities (people, places, organizations, etc.) from memory
gist text and maintains an inverted index: entity → [memory_id, ...].
Spreading activation can traverse this index to find memories that share
entities even when their embedding similarity is low.

This solves the cross-domain spreading problem: "warehouse inspection on
Industrial Way" and "hospital patients near Industrial Way" share an entity
(Industrial Way) but have low embedding similarity (0.18). The entity index
connects them directly.
"""

import logging
import re
from collections import defaultdict

import spacy

from cmm.core.types import Memory

logger = logging.getLogger(__name__)


class EntityIndex:
    """Inverted index mapping normalized entity names to memory IDs.

    Uses spaCy for NER extraction + regex patterns for addresses and
    other structured entities that spaCy may miss.
    """

    def __init__(self):
        self._nlp = spacy.load("en_core_web_sm", disable=["parser", "lemmatizer"])
        self._index: dict[str, set[int]] = defaultdict(set)
        self._memory_entities: dict[int, set[str]] = defaultdict(set)

    def index_memory(self, memory: Memory) -> list[str]:
        """Extract entities from a memory and add to the index.

        Returns the list of extracted entity names.
        """
        entities = self._extract_entities(memory.gist.text)

        # Also extract from tags
        for tag in memory.gist.tags:
            normalized = tag.lower().strip()
            if len(normalized) >= 3:
                entities.add(normalized)

        for entity in entities:
            self._index[entity].add(memory.id)
            self._memory_entities[memory.id].add(entity)

        return sorted(entities)

    def get_linked_memories(self, memory_id: int) -> set[int]:
        """Get all memory IDs that share at least one entity with the given memory."""
        entities = self._memory_entities.get(memory_id, set())
        linked = set()
        for entity in entities:
            linked.update(self._index[entity])
        linked.discard(memory_id)  # don't include self
        return linked

    def get_memories_for_entity(self, entity: str) -> set[int]:
        """Get all memory IDs that mention a specific entity."""
        return set(self._index.get(entity.lower().strip(), set()))

    def get_entities_for_memory(self, memory_id: int) -> set[str]:
        """Get all entities mentioned in a specific memory."""
        return set(self._memory_entities.get(memory_id, set()))

    def get_shared_entities(self, memory_id_a: int, memory_id_b: int) -> set[str]:
        """Get entities shared between two memories."""
        a = self._memory_entities.get(memory_id_a, set())
        b = self._memory_entities.get(memory_id_b, set())
        return a & b

    def remove_memory(self, memory_id: int) -> None:
        """Remove a memory from the entity index."""
        entities = self._memory_entities.pop(memory_id, set())
        for entity in entities:
            self._index[entity].discard(memory_id)
            if not self._index[entity]:
                del self._index[entity]

    @property
    def entity_count(self) -> int:
        return len(self._index)

    @property
    def indexed_memory_count(self) -> int:
        return len(self._memory_entities)

    def save(self, path: str) -> None:
        """Save the entity index to a JSON file."""
        import json
        data = {
            "index": {k: sorted(v) for k, v in self._index.items()},
            "memory_entities": {str(k): sorted(v) for k, v in self._memory_entities.items()},
        }
        with open(path, "w") as f:
            json.dump(data, f)

    def load_from_file(self, path: str) -> None:
        """Load entity index state from a JSON file."""
        import json
        with open(path) as f:
            data = json.load(f)
        self._index.clear()
        for entity, ids in data.get("index", {}).items():
            self._index[entity] = set(ids)
        self._memory_entities.clear()
        for mid_str, entities in data.get("memory_entities", {}).items():
            self._memory_entities[int(mid_str)] = set(entities)

    def _extract_entities(self, text: str) -> set[str]:
        """Extract named entities using spaCy + regex patterns."""
        entities = set()

        # spaCy NER
        doc = self._nlp(text)
        for ent in doc.ents:
            normalized = ent.text.lower().strip()
            # Filter out very short or common entities
            if len(normalized) >= 3 and ent.label_ in (
                "PERSON", "ORG", "GPE", "LOC", "FAC", "PRODUCT", "EVENT",
                "WORK_OF_ART", "LAW", "NORP",
            ):
                entities.add(normalized)

        # Regex: street addresses (e.g., "4200 Industrial Way", "88 Ravenswood Terrace")
        address_pattern = r'\b\d+\s+([A-Z][a-z]+(?:\s+[A-Z][a-z]+)*(?:\s+(?:Street|Avenue|Drive|Boulevard|Road|Lane|Way|Court|Circle|Terrace|Place)))\b'
        for match in re.finditer(address_pattern, text):
            entities.add(match.group(0).lower())

        # Regex: street/road names without numbers
        street_pattern = r'\b([A-Z][a-z]+(?:\s+[A-Z][a-z]+)*\s+(?:Street|Avenue|Drive|Boulevard|Road|Lane|Way|Court|Circle|Terrace|Place))\b'
        for match in re.finditer(street_pattern, text):
            entities.add(match.group(1).lower())

        # Regex: "Dr." prefix names
        dr_pattern = r'\bDr\.?\s+([A-Z][a-z]+\s+[A-Z][a-z]+)\b'
        for match in re.finditer(dr_pattern, text):
            entities.add(match.group(1).lower())

        return entities
