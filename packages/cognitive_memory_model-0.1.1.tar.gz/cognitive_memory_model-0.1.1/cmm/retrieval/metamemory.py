"""Metamemory — the system knowing what it knows and signaling uncertainty.

Provides confidence levels for retrieval results and surfaces partial matches
as "tip of the tongue" hints that something related exists in memory.
"""

from dataclasses import dataclass, field
from enum import Enum

from cmm.core.types import RetrievalResult


class Confidence(Enum):
    """Confidence level for a retrieval result."""
    HIGH = "high"           # Strong match — "I know this"
    MODERATE = "moderate"   # Decent match — "I think I know something about this"
    LOW = "low"             # Weak match — "I vaguely recall something related"
    NONE = "none"           # No match — "I don't have information about this"


@dataclass
class MetamemoryResult:
    """Retrieval results enriched with metamemory signals."""

    results: list[RetrievalResult]
    partial_matches: list[RetrievalResult]
    confidence: Confidence
    top_score: float
    has_partial: bool

    @property
    def has_strong_match(self) -> bool:
        return self.confidence in (Confidence.HIGH, Confidence.MODERATE)

    @property
    def has_tip_of_tongue(self) -> bool:
        """True if we have partial matches but no strong ones."""
        return self.has_partial and not self.has_strong_match


class MetamemoryScorer:
    """Classifies retrieval results into confidence levels and extracts partial matches.

    Score thresholds:
        >= high_threshold    → HIGH confidence
        >= moderate_threshold → MODERATE confidence
        >= partial_threshold  → partial match ("tip of the tongue")
        < partial_threshold   → below detection
    """

    def __init__(
        self,
        high_threshold: float = 0.7,
        moderate_threshold: float = 0.4,
        partial_threshold: float = 0.2,
    ):
        self.high_threshold = high_threshold
        self.moderate_threshold = moderate_threshold
        self.partial_threshold = partial_threshold

    def evaluate(
        self,
        results: list[RetrievalResult],
        all_candidates: list[RetrievalResult] | None = None,
    ) -> MetamemoryResult:
        """Evaluate retrieval results and produce metamemory signals.

        Args:
            results: The top-k retrieval results (above threshold).
            all_candidates: All candidates before threshold filtering,
                including partial matches. If None, only results are used.
        """
        top_score = results[0].final_score if results else 0.0

        # Classify confidence
        if top_score >= self.high_threshold:
            confidence = Confidence.HIGH
        elif top_score >= self.moderate_threshold:
            confidence = Confidence.MODERATE
        elif top_score >= self.partial_threshold:
            confidence = Confidence.LOW
        else:
            confidence = Confidence.NONE

        # Extract partial matches — candidates that scored above partial_threshold
        # but below the retrieval threshold (not in results)
        result_ids = {r.memory.id for r in results}
        partial_matches = []
        if all_candidates:
            for r in all_candidates:
                if (
                    r.memory.id not in result_ids
                    and r.final_score >= self.partial_threshold
                ):
                    partial_matches.append(r)
            partial_matches.sort(key=lambda r: r.final_score, reverse=True)

        return MetamemoryResult(
            results=results,
            partial_matches=partial_matches,
            confidence=confidence,
            top_score=top_score,
            has_partial=len(partial_matches) > 0,
        )

    @staticmethod
    def format_for_context(meta: MetamemoryResult) -> str:
        """Format metamemory result for LLM context injection."""
        if meta.confidence == Confidence.NONE and not meta.has_partial:
            return "[No relevant memories found]"

        lines = []

        if meta.results:
            lines.append(f"[Recalled memories (confidence: {meta.confidence.value})]")
            for r in meta.results:
                tags = ", ".join(r.memory.gist.tags) if r.memory.gist.tags else ""
                tag_str = f" [{tags}]" if tags else ""
                lines.append(f"- (score: {r.final_score:.3f}{tag_str}) {r.memory.gist.text}")
            lines.append("[End recalled memories]")

        if meta.has_tip_of_tongue:
            lines.append("")
            lines.append("[Partial matches — possibly related, low confidence]")
            for r in meta.partial_matches[:3]:  # limit to top 3 hints
                lines.append(f"- (score: {r.final_score:.3f}) {r.memory.gist.text}")
            lines.append("[End partial matches]")

        return "\n".join(lines)
