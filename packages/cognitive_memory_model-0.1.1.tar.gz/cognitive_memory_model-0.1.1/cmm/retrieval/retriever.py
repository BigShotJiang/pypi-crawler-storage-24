"""Retrieval layer — queries the memory store and applies cognitive scoring."""

import time

import numpy as np

from cmm.core.memory_store import MemoryStore
from cmm.core.types import Memory, RetrievalResult
from cmm.encoding.embedding import EmbeddingModel
from cmm.retrieval.decay import DecayScorer
from cmm.retrieval.metamemory import MetamemoryResult, MetamemoryScorer
from cmm.retrieval.priming import PrimingState
from cmm.retrieval.spreading_activation import SpreadingActivation
from cmm.retrieval.working_memory import WorkingMemory


class Retriever:
    """Retrieves relevant memories with decay, spreading activation, priming, and working memory.

    Retrieval pipeline:
    1. Query FAISS for top-k by raw similarity
    2. Apply temporal decay + rehearsal + importance to each score
    3. Apply priming boost to previously activated memories
    4. Filter by threshold on final score
    5. Run spreading activation to find associatively linked memories
    6. Merge with working memory contents (re-scored against current query)
    7. Update access metadata, working memory, and priming state
    8. Re-sort by final score
    """

    def __init__(
        self,
        store: MemoryStore,
        embedding_model: EmbeddingModel,
        top_k: int = 5,
        threshold: float = 0.3,
        decay_scorer: DecayScorer | None = None,
        working_memory: WorkingMemory | None = None,
        spreading_activation: SpreadingActivation | None = None,
        priming: PrimingState | None = None,
    ):
        self.store = store
        self.embedding_model = embedding_model
        self.top_k = top_k
        self.threshold = threshold
        self.decay_scorer = decay_scorer or DecayScorer()
        self.working_memory = working_memory or WorkingMemory()
        self.spreading_activation = spreading_activation or SpreadingActivation(store=store)
        self.priming = priming or PrimingState()
        self.metamemory = MetamemoryScorer()
        self.clock = time.time  # overridable for benchmarks

    def retrieve(self, query_text: str, top_k: int | None = None) -> list[RetrievalResult]:
        """Retrieve memories relevant to the query text."""
        if self.store.size == 0:
            return self._working_memory_only()

        query_embedding = self.embedding_model.embed(query_text)
        return self._retrieve_with_scoring(query_embedding, top_k)

    def retrieve_by_embedding(
        self, embedding: np.ndarray, top_k: int | None = None
    ) -> list[RetrievalResult]:
        """Retrieve memories using a pre-computed embedding vector."""
        if self.store.size == 0:
            return self._working_memory_only()

        return self._retrieve_with_scoring(embedding, top_k)

    def _retrieve_with_scoring(
        self, query_embedding: np.ndarray, top_k: int | None = None
    ) -> list[RetrievalResult]:
        """Core retrieval with decay, priming, spreading activation, and working memory."""
        k = top_k or self.top_k
        now = self.clock()

        # Step 1: Fetch from FAISS (overfetch since decay/priming reorder)
        fetch_k = min(k * 3, self.store.size)
        raw_results = self.store.retrieve(
            query_embedding=query_embedding,
            top_k=fetch_k,
            threshold=-1.0,
        )

        # Step 2-3: Apply decay + importance + priming
        scored = []
        all_scored = []  # includes below-threshold for metamemory
        for r in raw_results:
            decay = self.decay_scorer.compute_decay(r.memory, now)
            priming_boost = self.priming.get_boost(r.memory.id)
            final = r.raw_similarity * decay * r.memory.importance * priming_boost
            result = RetrievalResult(
                memory=r.memory,
                raw_similarity=r.raw_similarity,
                final_score=final,
            )
            all_scored.append(result)
            if final >= self.threshold:
                scored.append(result)

        # Step 4: Take initial top-k for spreading activation seeds
        scored.sort(key=lambda r: r.final_score, reverse=True)
        seeds = scored[:k]

        # Step 5: Spreading activation — expand from seeds
        if seeds:
            expanded = self.spreading_activation.spread(seeds)
            # Apply priming to spread-activated results too
            for r in expanded:
                if r.memory.id not in {s.memory.id for s in seeds}:
                    priming_boost = self.priming.get_boost(r.memory.id)
                    r_final = r.final_score * priming_boost
                    # Replace with priming-adjusted score
                    expanded[expanded.index(r)] = RetrievalResult(
                        memory=r.memory,
                        raw_similarity=r.raw_similarity,
                        final_score=r_final,
                    )
            scored = expanded

        # Step 6: Merge with working memory — re-score against current query
        seen_ids = {r.memory.id for r in scored}
        query_norm = query_embedding.flatten().astype(np.float32)
        norm = np.linalg.norm(query_norm)
        if norm > 0:
            query_norm = query_norm / norm
        for wm_entry in self.working_memory.get_active():
            if wm_entry.memory.id not in seen_ids:
                mem_emb = wm_entry.memory.embedding.flatten()
                similarity = float(np.dot(query_norm, mem_emb))
                decay = self.decay_scorer.compute_decay(wm_entry.memory, now)
                priming_boost = self.priming.get_boost(wm_entry.memory.id)
                final = similarity * decay * wm_entry.memory.importance * priming_boost
                if final >= self.threshold:
                    scored.append(
                        RetrievalResult(
                            memory=wm_entry.memory,
                            raw_similarity=similarity,
                            final_score=final,
                        )
                    )

        # Step 7: Final sort and truncate
        scored.sort(key=lambda r: r.final_score, reverse=True)
        results = scored[:k]

        # Step 8: Update access tracking, working memory, and priming
        activated_ids = []
        for r in results:
            self.store.update_access(r.memory.id)
            self.working_memory.activate(r.memory, r.final_score)
            activated_ids.append(r.memory.id)
        self.priming.activate_many(activated_ids)

        # Stash all candidates for metamemory
        self._last_all_candidates = all_scored

        return results

    def retrieve_with_metamemory(self, query_text: str, top_k: int | None = None) -> MetamemoryResult:
        """Retrieve with metamemory signals — confidence levels and partial matches."""
        results = self.retrieve(query_text, top_k)
        all_candidates = getattr(self, '_last_all_candidates', [])
        return self.metamemory.evaluate(results, all_candidates)

    def _working_memory_only(self) -> list[RetrievalResult]:
        """Return working memory contents when store is empty."""
        results = self.working_memory.get_active()
        results.sort(key=lambda r: r.final_score, reverse=True)
        return results[: self.top_k]

    def tick(self) -> None:
        """Advance one turn — ticks working memory and priming."""
        self.working_memory.tick()
        self.priming.tick()

    @staticmethod
    def format_for_context(results: list[RetrievalResult]) -> str:
        """Format retrieved memories as text for injection into an LLM prompt.

        The output is clearly marked as recalled from memory (not direct user input)
        so the LLM can distinguish between current conversation and past context.
        """
        if not results:
            return ""

        lines = [
            "[Recalled from memory — these are automatically retrieved from past "
            "conversations, not part of the current user message. Use them if relevant.]"
        ]
        for r in results:
            tags = ", ".join(r.memory.gist.tags) if r.memory.gist.tags else ""
            tag_str = f" [{tags}]" if tags else ""
            # Include emotional context if present and notable
            emotion_str = ""
            if r.memory.emotion and r.memory.emotion != "neutral" and r.memory.arousal >= 0.3:
                emotion_str = f" (emotion: {r.memory.emotion})"
            # Include agent attribution in multi-agent contexts
            agent_str = ""
            if r.memory.agent_id and r.memory.agent_id != "default":
                agent_str = f" (from: {r.memory.agent_id})"
            lines.append(f"- (relevance: {r.final_score:.3f}{tag_str}{emotion_str}{agent_str}) {r.memory.gist.text}")
        lines.append("[End recalled memories]")

        return "\n".join(lines)
