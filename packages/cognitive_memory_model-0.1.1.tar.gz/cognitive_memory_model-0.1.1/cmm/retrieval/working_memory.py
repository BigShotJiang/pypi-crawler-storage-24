"""Working memory buffer — short-term store for recently activated memories."""

from cmm.core.types import Memory, RetrievalResult


class WorkingMemoryEntry:
    """A memory held in working memory with a turn-based TTL."""

    __slots__ = ("memory", "score", "turns_remaining")

    def __init__(self, memory: Memory, score: float, ttl: int):
        self.memory = memory
        self.score = score
        self.turns_remaining = ttl


class WorkingMemory:
    """Fixed-size buffer of recently activated memories.

    Items stay in working memory for a configurable number of turns.
    If an item is reactivated (retrieved again), its TTL resets.
    When capacity is exceeded, the lowest-scoring item is evicted.

    This is separate from the FAISS long-term store — it represents
    "what we were just talking about" and gets automatically included
    in retrieval results without needing a FAISS query.
    """

    def __init__(self, capacity: int = 10, default_ttl: int = 5):
        """
        Args:
            capacity: Max items in working memory.
            default_ttl: Turns before an item decays out of working memory.
        """
        self.capacity = capacity
        self.default_ttl = default_ttl
        self._entries: dict[int, WorkingMemoryEntry] = {}

    @property
    def size(self) -> int:
        return len(self._entries)

    def activate(self, memory: Memory, score: float) -> None:
        """Add or reactivate a memory in working memory."""
        if memory.id in self._entries:
            # Reactivation: reset TTL, update score if higher
            entry = self._entries[memory.id]
            entry.turns_remaining = self.default_ttl
            entry.score = max(entry.score, score)
        else:
            # New entry — evict lowest if at capacity
            if len(self._entries) >= self.capacity:
                self._evict_lowest()
            self._entries[memory.id] = WorkingMemoryEntry(
                memory=memory, score=score, ttl=self.default_ttl
            )

    def tick(self) -> None:
        """Advance one turn. Decrements TTL and removes expired entries."""
        expired = []
        for memory_id, entry in self._entries.items():
            entry.turns_remaining -= 1
            if entry.turns_remaining <= 0:
                expired.append(memory_id)
        for memory_id in expired:
            del self._entries[memory_id]

    def get_active(self) -> list[RetrievalResult]:
        """Return all active working memory items as RetrievalResults."""
        return [
            RetrievalResult(
                memory=entry.memory,
                raw_similarity=entry.score,
                final_score=entry.score,
            )
            for entry in self._entries.values()
        ]

    def contains(self, memory_id: int) -> bool:
        return memory_id in self._entries

    def clear(self) -> None:
        self._entries.clear()

    def _evict_lowest(self) -> None:
        """Remove the entry with the lowest score."""
        if not self._entries:
            return
        lowest_id = min(self._entries, key=lambda k: self._entries[k].score)
        del self._entries[lowest_id]
