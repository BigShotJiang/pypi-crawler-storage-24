"""Spreading activation — retrieves associatively linked memories via FAISS + entity links.

Two spreading pathways:
1. **Embedding proximity**: query FAISS with seed embedding → find neighbors in vector space
2. **Entity links**: look up seed's named entities → find all memories sharing those entities

This dual-path approach solves the cross-domain spreading problem: cases that share
an entity (e.g., "Industrial Way") but have very different domain vocabulary (building
inspection vs. hospital report) are connected through the entity index even when their
embedding similarity is too low for FAISS to find.
"""

from cmm.core.memory_store import MemoryStore
from cmm.core.types import RetrievalResult
from cmm.retrieval.entity_index import EntityIndex


class SpreadingActivation:
    """Expands retrieval results via embedding proximity and entity links.

    Starting from initial retrieval results (seeds), spreading follows two paths:
    1. FAISS neighbor query: find embeddings close to each seed
    2. Entity index lookup: find memories sharing named entities with each seed

    Scores decay per hop via spread_factor. Entity-linked memories receive a
    configurable entity_boost to compensate for potentially low embedding similarity.
    """

    def __init__(
        self,
        store: MemoryStore,
        max_depth: int = 1,
        spread_factor: float = 0.5,
        spread_top_k: int = 3,
        entity_index: EntityIndex | None = None,
        entity_boost: float = 0.8,
    ):
        """
        Args:
            store: The FAISS memory store to query.
            max_depth: Maximum hops from initial seeds.
            spread_factor: Score multiplier per hop.
            spread_top_k: Number of FAISS neighbors per seed per hop.
            entity_index: Entity index for entity-linked spreading.
                If None, only embedding-based spreading is used.
            entity_boost: Score multiplier for entity-linked memories.
                Applied as: parent_score * spread_factor * entity_boost.
                Higher values give entity links more weight relative to
                embedding neighbors.
        """
        self.store = store
        self.max_depth = max_depth
        self.spread_factor = spread_factor
        self.spread_top_k = spread_top_k
        self.entity_index = entity_index
        self.entity_boost = entity_boost

    def spread(self, seeds: list[RetrievalResult]) -> list[RetrievalResult]:
        """Expand seed results via spreading activation.

        Returns combined list: original seeds + activated neighbors + entity-linked,
        deduplicated by memory ID (max score wins), sorted by final_score descending.
        """
        if not seeds or self.max_depth < 1:
            return seeds

        score_map: dict[int, RetrievalResult] = {}

        # Add seeds
        for r in seeds:
            score_map[r.memory.id] = r

        # BFS expansion
        frontier = [(r, 0) for r in seeds]

        for depth in range(1, self.max_depth + 1):
            next_frontier = []
            for parent_result, parent_depth in frontier:
                if parent_depth != depth - 1:
                    continue

                # Path 1: Embedding-space neighbors via FAISS
                neighbors = self.store.retrieve(
                    query_embedding=parent_result.memory.embedding,
                    top_k=self.spread_top_k + 1,
                    threshold=-1.0,
                )

                for neighbor in neighbors:
                    if neighbor.memory.id == parent_result.memory.id:
                        continue

                    spread_score = parent_result.final_score * self.spread_factor
                    spread_score *= max(neighbor.raw_similarity, 0.0)

                    if spread_score <= 0:
                        continue

                    activated = RetrievalResult(
                        memory=neighbor.memory,
                        raw_similarity=neighbor.raw_similarity,
                        final_score=spread_score,
                    )

                    existing = score_map.get(neighbor.memory.id)
                    if existing is None or spread_score > existing.final_score:
                        score_map[neighbor.memory.id] = activated

                    next_frontier.append((activated, depth))

                # Path 2: Entity-linked memories
                if self.entity_index is not None:
                    entity_linked = self.entity_index.get_linked_memories(
                        parent_result.memory.id
                    )

                    for linked_id in entity_linked:
                        if linked_id in score_map:
                            continue  # already found via a better path

                        linked_memory = self.store.get(linked_id)
                        if linked_memory is None:
                            continue

                        # Score entity-linked memories using entity_boost
                        entity_score = (
                            parent_result.final_score
                            * self.spread_factor
                            * self.entity_boost
                        )

                        # Shared entities give additional context
                        shared = self.entity_index.get_shared_entities(
                            parent_result.memory.id, linked_id
                        )

                        activated = RetrievalResult(
                            memory=linked_memory,
                            raw_similarity=0.0,  # not from FAISS similarity
                            final_score=entity_score,
                        )

                        existing = score_map.get(linked_id)
                        if existing is None or entity_score > existing.final_score:
                            score_map[linked_id] = activated

                        next_frontier.append((activated, depth))

            frontier.extend(next_frontier)

        results = list(score_map.values())
        results.sort(key=lambda r: r.final_score, reverse=True)
        return results
