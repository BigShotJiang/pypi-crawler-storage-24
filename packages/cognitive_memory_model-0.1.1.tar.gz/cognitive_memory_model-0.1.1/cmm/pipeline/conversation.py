"""Conversation pipeline — parses turns, encodes, stores, and triggers retrieval."""

import logging

from cmm.consolidation.consolidator import Consolidator, ConsolidationSummarizer
from cmm.consolidation.session import SessionSummarizer
from cmm.core.memory_store import MemoryStore
from cmm.core.types import ConversationTurn, Gist, Memory, MemoryType, RetrievalResult, Role
from cmm.encoding.embedding import EmbeddingModel
from cmm.encoding.gist_encoder import GistEncoder, PassthroughGistEncoder
from cmm.retrieval.decay import DecayScorer
from cmm.retrieval.priming import PrimingState
from cmm.retrieval.retriever import Retriever
from cmm.retrieval.entity_index import EntityIndex
from cmm.retrieval.spreading_activation import SpreadingActivation
from cmm.retrieval.working_memory import WorkingMemory
from cmm.maintenance.maintenance import HealthMetrics, MemoryMaintainer
from cmm.scoring.importance import ImportanceScorer, RuleBasedImportanceScorer
from cmm.scoring.valence import ValenceScorer

logger = logging.getLogger(__name__)


class CognitiveMemoryPipeline:
    """End-to-end pipeline: conversation turns in, recalled memories out.

    This is the main entry point for the cognitive memory system. It:
    1. Accepts conversation turns
    2. Encodes them into gist summaries
    3. Embeds and stores them in the FAISS-backed memory store
    4. On each new turn, retrieves relevant memories with decay, spreading
       activation, priming, and working memory
    5. Periodically consolidates episodic memories into semantic memories
    """

    def __init__(
        self,
        embedding_model: EmbeddingModel | None = None,
        gist_encoder: GistEncoder | None = None,
        store: MemoryStore | None = None,
        retriever_top_k: int = 5,
        retriever_threshold: float = 0.3,
        # Decay
        decay_grace_period: float = 14 * 86400,  # 2 weeks
        decay_rate: float = 5e-7,
        decay_freq_weight: float = 1.0,
        decay_lock_frequency: float = 0.5,
        # Working memory
        working_memory_capacity: int = 10,
        working_memory_ttl: int = 5,
        # Spreading activation
        spread_depth: int = 1,
        spread_factor: float = 0.5,
        spread_top_k: int = 3,
        entity_linking: bool = True,
        entity_boost: float = 0.8,
        # Priming
        priming_boost: float = 0.3,
        priming_decay: float = 0.5,
        priming_max_turns: int = 10,
        # Consolidation
        consolidation_summarizer: ConsolidationSummarizer | None = None,
        consolidation_threshold: int = 50,
        cluster_similarity: float = 0.6,
        min_cluster_size: int = 3,
        # Importance
        importance_scorer: ImportanceScorer | None = None,
        # Multi-agent
        agent_id: str | None = None,
        session_id: str | None = None,
        default_scope: str = "team",
    ):
        self.embedding_model = embedding_model or EmbeddingModel()
        self.gist_encoder = gist_encoder or PassthroughGistEncoder()

        dim = self.embedding_model.dim
        self.store = store or MemoryStore(dim=dim)

        decay_scorer = DecayScorer(
            grace_period=decay_grace_period,
            decay_rate=decay_rate,
            freq_weight=decay_freq_weight,
            lock_frequency=decay_lock_frequency,
        )
        working_memory = WorkingMemory(
            capacity=working_memory_capacity,
            default_ttl=working_memory_ttl,
        )
        self.entity_index = EntityIndex() if entity_linking else None
        spreading = SpreadingActivation(
            store=self.store,
            max_depth=spread_depth,
            spread_factor=spread_factor,
            spread_top_k=spread_top_k,
            entity_index=self.entity_index,
            entity_boost=entity_boost,
        )
        priming = PrimingState(
            boost_strength=priming_boost,
            decay_rate=priming_decay,
            max_turns=priming_max_turns,
        )
        self.retriever = Retriever(
            store=self.store,
            embedding_model=self.embedding_model,
            top_k=retriever_top_k,
            threshold=retriever_threshold,
            decay_scorer=decay_scorer,
            working_memory=working_memory,
            spreading_activation=spreading,
            priming=priming,
        )

        # Consolidation
        self.consolidator = Consolidator(
            store=self.store,
            embedding_model=self.embedding_model,
            summarizer=consolidation_summarizer,
            cluster_threshold=cluster_similarity,
            min_cluster_size=min_cluster_size,
        )
        self.session_summarizer = SessionSummarizer(
            store=self.store,
            embedding_model=self.embedding_model,
            summarizer=consolidation_summarizer,
        )
        self.importance_scorer = importance_scorer or RuleBasedImportanceScorer()
        self.valence_scorer = ValenceScorer()
        self.maintainer = MemoryMaintainer(
            store=self.store,
            decay_scorer=decay_scorer,
        )
        self._consolidation_threshold = consolidation_threshold
        self._turns_since_consolidation: int = 0

        # Multi-agent
        from cmm.core.types import MemoryScope
        self.agent_id = agent_id
        self.session_id = session_id
        self._default_scope = MemoryScope(default_scope)

        self._recent_turns: list[ConversationTurn] = []
        self._session_memory_ids: list[int] = []
        self._context_window: int = 3
        self._turn_count: int = 0

    def process_turn(self, turn: ConversationTurn) -> list[RetrievalResult]:
        """Process a conversation turn: store it and retrieve relevant memories.

        Args:
            turn: The conversation turn to process.

        Returns:
            List of retrieved memories relevant to this turn.
        """
        # Tick working memory and priming (items age by one turn)
        self.retriever.tick()
        self._turn_count += 1
        self._turns_since_consolidation += 1

        # Retrieve before storing (so we don't retrieve the turn itself)
        results = self.retriever.retrieve(turn.content)

        # Encode and store
        context = self._recent_turns[-self._context_window :]
        gist = self.gist_encoder.encode(turn, context=context)
        embedding = self.embedding_model.embed(gist.text)

        # Score importance and emotional valence
        importance = self.importance_scorer.score(
            turn=turn,
            store=self.store,
            embedding=embedding,
        )
        valence_result = self.valence_scorer.score(turn)

        memory = self.store.store(
            gist=gist,
            embedding=embedding,
            importance=importance,
            source_role=turn.role,
            timestamp=turn.timestamp,
            agent_id=self.agent_id,
            session_id=self.session_id,
            scope=self._default_scope,
        )
        memory.valence = valence_result.valence
        memory.arousal = valence_result.arousal
        memory.emotion = valence_result.emotion

        # Index entities for entity-linked spreading activation
        if self.entity_index is not None:
            self.entity_index.index_memory(memory)
        self._session_memory_ids.append(memory.id)
        self._recent_turns.append(turn)

        # Auto-consolidation check
        if self._turns_since_consolidation >= self._consolidation_threshold:
            self.consolidate()

        return results

    def ingest(self, role: str | Role, content: str) -> list[RetrievalResult]:
        """Convenience method: create a turn and process it."""
        if isinstance(role, str):
            role = Role(role)
        turn = ConversationTurn(role=role, content=content)
        return self.process_turn(turn)

    def recall(self, query: str, top_k: int | None = None) -> list[RetrievalResult]:
        """Query memory without storing anything."""
        return self.retriever.retrieve(query, top_k=top_k)

    def recall_with_metamemory(self, query: str, top_k: int | None = None):
        """Query memory with metamemory signals (confidence + partial matches).

        Returns a MetamemoryResult with confidence level, results, and
        partial matches ("tip of the tongue" hints).
        """
        from cmm.retrieval.metamemory import MetamemoryResult
        return self.retriever.retrieve_with_metamemory(query, top_k=top_k)

    def format_recalled(self, results: list[RetrievalResult]) -> str:
        """Format retrieval results as text for LLM context injection."""
        return Retriever.format_for_context(results)

    def consolidate(self) -> list[Memory]:
        """Manually trigger memory consolidation.

        Clusters similar episodic memories and creates semantic memories.
        Returns the newly created semantic memories.
        """
        new_memories = self.consolidator.consolidate()
        self._turns_since_consolidation = 0
        if new_memories:
            logger.info("Consolidation produced %d semantic memories.", len(new_memories))
        return new_memories

    def end_session(self) -> Memory | None:
        """End the current session and create a session summary.

        Returns the session summary memory, or None if not enough turns.
        """
        session_memories = [
            self.store.get(mid)
            for mid in self._session_memory_ids
            if self.store.get(mid) is not None
        ]
        summary = self.session_summarizer.summarize_session(session_memories)

        # Reset session state
        self._session_memory_ids.clear()
        self._recent_turns.clear()

        return summary

    def maintain(self) -> HealthMetrics:
        """Run memory maintenance: deduplicate and prune."""
        return self.maintainer.maintain()

    def health(self) -> HealthMetrics:
        """Get memory store health metrics."""
        return self.maintainer.get_health_metrics()

    def save(self, directory: str) -> None:
        """Save the entire pipeline state to disk.

        Saves the FAISS index, all memory metadata, and the entity index.
        Call this to persist memory across restarts.
        """
        import os
        os.makedirs(directory, exist_ok=True)
        self.store.save(directory)
        if self.entity_index is not None:
            self.entity_index.save(os.path.join(directory, "entities.json"))
        logging.getLogger(__name__).info(
            "Saved %d memories to %s", self.memory_count, directory
        )

    @classmethod
    def load(cls, directory: str, **kwargs) -> "CognitiveMemoryPipeline":
        """Load a pipeline from disk.

        Restores the FAISS index, memory metadata, and entity index.
        Additional kwargs are passed to the pipeline constructor for
        configuring decay, spreading, priming, etc.
        """
        import os
        from cmm.core.memory_store import MemoryStore

        store = MemoryStore.load(directory)
        pipeline = cls(store=store, **kwargs)

        # Restore entity index
        entity_path = os.path.join(directory, "entities.json")
        if os.path.exists(entity_path) and pipeline.entity_index is not None:
            pipeline.entity_index.load_from_file(entity_path)

        logging.getLogger(__name__).info(
            "Loaded %d memories from %s", pipeline.memory_count, directory
        )
        return pipeline

    @property
    def memory_count(self) -> int:
        return self.store.size

    @property
    def working_memory(self) -> WorkingMemory:
        return self.retriever.working_memory

    @property
    def priming(self) -> PrimingState:
        return self.retriever.priming

    @property
    def turn_count(self) -> int:
        return self._turn_count
