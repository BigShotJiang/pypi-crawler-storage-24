"""Importance scoring — assigns importance to conversation turns at storage time.

Importance signals (from most to least important):
- Corrections: user correcting the agent ("no, I meant X", "that's wrong")
- Instructions: explicit directives ("always do X", "remember this", "never do Y")
- Novel information: content dissimilar to existing memories (new topics/facts)
- Normal exchanges: typical Q&A, discussion
- Routine: greetings, acknowledgments, filler
"""

import re
from abc import ABC, abstractmethod

import numpy as np

from cmm.core.memory_store import MemoryStore
from cmm.core.types import ConversationTurn, Role


class ImportanceScorer(ABC):
    """Base class for importance scoring strategies."""

    @abstractmethod
    def score(
        self,
        turn: ConversationTurn,
        store: MemoryStore | None = None,
        embedding: np.ndarray | None = None,
    ) -> float:
        """Score the importance of a conversation turn.

        Args:
            turn: The conversation turn to score.
            store: The memory store (for novelty detection).
            embedding: Pre-computed embedding of the turn's gist (for novelty).

        Returns:
            Importance score. 1.0 is baseline. >1 = more important, <1 = less.
        """
        ...


class RuleBasedImportanceScorer(ImportanceScorer):
    """Detects importance signals using pattern matching and novelty.

    Scoring tiers:
        2.0  — corrections and explicit instructions
        1.5  — novel information (dissimilar to anything in memory)
        1.0  — normal exchanges (baseline)
        0.5  — routine/filler (greetings, acknowledgments)
    """

    def __init__(
        self,
        correction_score: float = 2.0,
        instruction_score: float = 2.0,
        novel_score: float = 1.5,
        normal_score: float = 1.0,
        routine_score: float = 0.5,
        novelty_threshold: float = 0.5,
    ):
        """
        Args:
            novelty_threshold: If the max similarity to existing memories is
                below this, the turn is considered novel.
        """
        self.correction_score = correction_score
        self.instruction_score = instruction_score
        self.novel_score = novel_score
        self.normal_score = normal_score
        self.routine_score = routine_score
        self.novelty_threshold = novelty_threshold

    def score(
        self,
        turn: ConversationTurn,
        store: MemoryStore | None = None,
        embedding: np.ndarray | None = None,
    ) -> float:
        text = turn.content.strip()

        # Check for corrections (highest priority)
        if self._is_correction(text):
            return self.correction_score

        # Check for explicit instructions
        if self._is_instruction(text):
            return self.instruction_score

        # Check for routine/filler (lowest priority)
        if self._is_routine(text):
            return self.routine_score

        # Check for novelty (requires store and embedding)
        if store is not None and embedding is not None and store.size > 0:
            if self._is_novel(embedding, store):
                return self.novel_score

        return self.normal_score

    def _is_correction(self, text: str) -> bool:
        """Detect user corrections."""
        lower = text.lower()
        correction_patterns = [
            r"\bno[,.]?\s+(i|that|it|we|actually)",
            r"\bthat'?s?\s+(not|wrong|incorrect)",
            r"\bactually[,.]?\s+(i|it|the|we)",
            r"\bi\s+meant\b",
            r"\bi\s+said\b",
            r"\bnot\s+what\s+i\b",
            r"\byou('re|\s+are)\s+(wrong|incorrect|mistaken)",
            r"\bcorrection\b",
            r"\blet\s+me\s+correct\b",
            r"\bwhat\s+i\s+(really\s+)?meant\b",
        ]
        return any(re.search(p, lower) for p in correction_patterns)

    def _is_instruction(self, text: str) -> bool:
        """Detect explicit instructions/preferences."""
        lower = text.lower()
        instruction_patterns = [
            r"\balways\s+\w+",
            r"\bnever\s+\w+",
            r"\bremember\s+(this|that|to)\b",
            r"\bdon'?t\s+forget\b",
            r"\bkeep\s+in\s+mind\b",
            r"\bimportant\s*:\s*",
            r"\bnote\s*:\s*",
            r"\bmake\s+sure\s+(to|you)\b",
            r"\bfrom\s+now\s+on\b",
            r"\bi\s+prefer\b",
            r"\bi\s+always\s+want\b",
            r"\bmy\s+preference\s+is\b",
        ]
        return any(re.search(p, lower) for p in instruction_patterns)

    def _is_routine(self, text: str) -> bool:
        """Detect routine/filler exchanges."""
        lower = text.lower().strip()
        # Very short messages are often routine
        if len(lower.split()) <= 3:
            routine_phrases = [
                "hi", "hello", "hey", "thanks", "thank you",
                "ok", "okay", "sure", "yes", "no", "got it",
                "sounds good", "great", "perfect", "nice",
                "good morning", "good afternoon", "good evening",
                "bye", "goodbye", "see you", "talk later",
            ]
            return any(lower.startswith(p) or lower == p for p in routine_phrases)
        return False

    def _is_novel(self, embedding: np.ndarray, store: MemoryStore) -> bool:
        """Check if this embedding is dissimilar to everything in the store."""
        results = store.retrieve(
            query_embedding=embedding,
            top_k=1,
            threshold=-1.0,
        )
        if not results:
            return True
        return results[0].raw_similarity < self.novelty_threshold
