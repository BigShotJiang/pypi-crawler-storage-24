"""Emotional valence scoring — detects emotional context in conversation turns.

Assigns valence (positive/negative), arousal (intensity), and emotion labels
to each memory. This enables retrieval to surface emotional context:
"the user was frustrated when discussing deployments last time."
"""

import re
from dataclasses import dataclass

from cmm.core.types import ConversationTurn


@dataclass
class ValenceResult:
    """Emotional valence analysis of a conversation turn."""

    valence: float   # -1.0 (negative) to +1.0 (positive)
    arousal: float   # 0.0 (calm) to 1.0 (intense)
    emotion: str     # primary emotion label


# Emotion patterns: (regex_pattern, emotion_label, valence, arousal)
_POSITIVE_HIGH = [
    (r"\b(amazing|incredible|fantastic|awesome|brilliant|excellent|outstanding)\b", "excited", 0.9, 0.8),
    (r"\b(love|adore|thrilled|ecstatic|overjoyed)\b", "elated", 0.9, 0.9),
    (r"(!{2,}|🎉|🚀|💯)", "excited", 0.8, 0.8),
    (r"\b(finally|at last|breakthrough|eureka)\b", "triumphant", 0.8, 0.7),
]

_POSITIVE_LOW = [
    (r"\b(good|nice|great|happy|pleased|glad|satisfied)\b", "positive", 0.5, 0.3),
    (r"\b(thanks|thank you|appreciate|helpful|useful)\b", "grateful", 0.4, 0.2),
    (r"\b(interesting|cool|neat|intriguing)\b", "curious", 0.3, 0.3),
    (r"\b(works|working|fixed|solved|done)\b", "satisfied", 0.4, 0.2),
]

_NEGATIVE_HIGH = [
    (r"\b(terrible|horrible|awful|disaster|catastrophe|nightmare)\b", "distressed", -0.9, 0.9),
    (r"\b(furious|enraged|livid|infuriating)\b", "angry", -0.8, 0.9),
    (r"\b(hate|despise|loathe|disgusting)\b", "disgusted", -0.8, 0.8),
    (r"\b(broken|crashed|failed|destroyed|lost everything)\b", "distressed", -0.7, 0.8),
]

_NEGATIVE_LOW = [
    (r"\b(frustrated|annoyed|irritated|bothered)\b", "frustrated", -0.5, 0.5),
    (r"\b(confused|lost|stuck|don't understand|unclear)\b", "confused", -0.3, 0.4),
    (r"\b(disappoint\w*|let down|underwhelm\w*)\b", "disappointed", -0.5, 0.3),
    (r"\b(worried|concerned|anxious|nervous)\b", "anxious", -0.4, 0.5),
    (r"\b(boring|tedious|tiresome|dull)\b", "bored", -0.3, 0.2),
    (r"\b(wrong|error|bug|issue|problem|fail)\b", "concerned", -0.2, 0.3),
]

ALL_PATTERNS = _POSITIVE_HIGH + _POSITIVE_LOW + _NEGATIVE_HIGH + _NEGATIVE_LOW


class ValenceScorer:
    """Detects emotional valence in conversation turns using pattern matching.

    For each turn, scans for emotional cue words and phrases, then aggregates
    into a single valence/arousal/emotion result. If multiple emotions are
    detected, the strongest (highest arousal) wins.
    """

    def score(self, turn: ConversationTurn) -> ValenceResult:
        """Analyze the emotional content of a conversation turn."""
        text = turn.content.lower()

        best_emotion = "neutral"
        best_valence = 0.0
        best_arousal = 0.0

        for pattern, emotion, valence, arousal in ALL_PATTERNS:
            if re.search(pattern, text, re.IGNORECASE):
                if arousal > best_arousal:
                    best_emotion = emotion
                    best_valence = valence
                    best_arousal = arousal

        return ValenceResult(
            valence=best_valence,
            arousal=best_arousal,
            emotion=best_emotion,
        )
