"""Consolidation engine — clusters episodic memories into semantic memories."""

import logging
import time
from abc import ABC, abstractmethod

import numpy as np

from cmm.core.memory_store import MemoryStore
from cmm.core.types import Gist, Memory, MemoryType
from cmm.encoding.embedding import EmbeddingModel

logger = logging.getLogger(__name__)


class ConsolidationSummarizer(ABC):
    """Generates a semantic summary from a cluster of related memories."""

    @abstractmethod
    def summarize(self, memories: list[Memory]) -> Gist:
        """Produce a single consolidated gist from a cluster of episodic memories."""
        ...


class SimpleConsolidationSummarizer(ConsolidationSummarizer):
    """Fallback summarizer — concatenates gists and merges tags.

    Useful for testing. For production, use OllamaConsolidationSummarizer.
    """

    def summarize(self, memories: list[Memory]) -> Gist:
        texts = [m.gist.text for m in memories]
        all_tags: dict[str, int] = {}
        for m in memories:
            for tag in m.gist.tags:
                all_tags[tag] = all_tags.get(tag, 0) + 1

        # Keep most frequent tags
        sorted_tags = sorted(all_tags, key=all_tags.get, reverse=True)

        combined = " | ".join(texts)
        if len(combined) > 500:
            combined = combined[:500] + "..."

        return Gist(text=combined, tags=sorted_tags[:10])


class Consolidator:
    """Clusters episodic memories and consolidates them into semantic memories.

    Process:
    1. Collect all episodic memories from the store
    2. Cluster by embedding similarity (simple greedy clustering)
    3. For clusters above a size threshold, generate a semantic summary
    4. Store the semantic memory with higher importance
    5. Optionally reduce importance of consolidated episodic memories
    """

    def __init__(
        self,
        store: MemoryStore,
        embedding_model: EmbeddingModel,
        summarizer: ConsolidationSummarizer | None = None,
        cluster_threshold: float = 0.6,
        min_cluster_size: int = 3,
        semantic_importance: float = 2.0,
        demote_episodic: bool = True,
        episodic_demoted_importance: float = 0.5,
    ):
        """
        Args:
            store: The memory store.
            embedding_model: For embedding the consolidated gist.
            summarizer: LLM-based or simple summarizer for cluster consolidation.
            cluster_threshold: Minimum cosine similarity to group memories.
            min_cluster_size: Minimum memories in a cluster to trigger consolidation.
            semantic_importance: Importance score for new semantic memories.
            demote_episodic: Whether to reduce importance of consolidated episodic memories.
            episodic_demoted_importance: New importance for demoted episodic memories.
        """
        self.store = store
        self.embedding_model = embedding_model
        self.summarizer = summarizer or SimpleConsolidationSummarizer()
        self.cluster_threshold = cluster_threshold
        self.min_cluster_size = min_cluster_size
        self.semantic_importance = semantic_importance
        self.demote_episodic = demote_episodic
        self.episodic_demoted_importance = episodic_demoted_importance

    def consolidate(self) -> list[Memory]:
        """Run consolidation. Returns list of newly created semantic memories."""
        episodic = self._get_episodic_memories()
        if len(episodic) < self.min_cluster_size:
            return []

        clusters = self._cluster(episodic)
        new_memories = []

        for cluster in clusters:
            if len(cluster) < self.min_cluster_size:
                continue

            gist = self.summarizer.summarize(cluster)
            embedding = self.embedding_model.embed(gist.text)

            memory = self.store.store(
                gist=gist,
                embedding=embedding,
                memory_type=MemoryType.SEMANTIC,
                importance=self.semantic_importance,
            )
            new_memories.append(memory)

            if self.demote_episodic:
                for m in cluster:
                    m.importance = min(m.importance, self.episodic_demoted_importance)

            logger.info(
                "Consolidated %d episodic memories into semantic memory %d: %s",
                len(cluster), memory.id, gist.text[:80],
            )

        return new_memories

    def _get_episodic_memories(self) -> list[Memory]:
        """Get all episodic memories from the store."""
        return [
            m for m in self.store._memories.values()
            if m.memory_type == MemoryType.EPISODIC
        ]

    def _cluster(self, memories: list[Memory]) -> list[list[Memory]]:
        """Greedy single-linkage clustering by embedding similarity."""
        if not memories:
            return []

        # Build similarity-based clusters
        assigned = set()
        clusters: list[list[Memory]] = []

        # Precompute normalized embeddings
        embeddings = np.array([m.embedding.flatten() for m in memories], dtype=np.float32)

        for i, mem in enumerate(memories):
            if i in assigned:
                continue

            cluster = [mem]
            assigned.add(i)

            # Find all memories similar enough to this one
            sims = embeddings @ embeddings[i]
            for j in range(len(memories)):
                if j in assigned:
                    continue
                if sims[j] >= self.cluster_threshold:
                    cluster.append(memories[j])
                    assigned.add(j)

            clusters.append(cluster)

        return clusters
