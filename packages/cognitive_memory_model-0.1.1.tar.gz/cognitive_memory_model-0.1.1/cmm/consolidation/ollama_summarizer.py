"""Ollama-based consolidation summarizer — uses a local LLM to summarize memory clusters."""

import json
import logging

import httpx

from cmm.consolidation.consolidator import ConsolidationSummarizer
from cmm.core.types import Gist, Memory

logger = logging.getLogger(__name__)

_SYSTEM_PROMPT = """\
You are a memory consolidation system. You receive a cluster of related episodic memories \
(individual conversation events) and must produce a single semantic memory that captures \
the general knowledge or pattern across them.

Rules:
- Produce 1-2 sentences capturing the recurring theme, fact, or pattern.
- Write in third person (e.g., "User frequently discusses...", "User prefers...").
- Preserve specific recurring names, tools, or concepts.
- Extract the most important tags (key concepts that recur across memories).
- Respond ONLY with valid JSON:

{"gist": "...", "tags": ["tag1", "tag2", ...]}"""

_USER_TEMPLATE = """\
Consolidate these {count} related memories into one semantic memory:

{memories}"""


class OllamaConsolidationSummarizer(ConsolidationSummarizer):
    """Uses a local Ollama model to summarize memory clusters."""

    def __init__(
        self,
        model: str = "mistral:7b-instruct-q4_K_M",
        base_url: str = "http://localhost:11434",
        timeout: float = 30.0,
        temperature: float = 0.1,
    ):
        self.model = model
        self.base_url = base_url
        self.timeout = timeout
        self.temperature = temperature
        self._client = httpx.Client(timeout=timeout)

    def summarize(self, memories: list[Memory]) -> Gist:
        memory_lines = []
        for i, m in enumerate(memories, 1):
            tags = ", ".join(m.gist.tags) if m.gist.tags else ""
            tag_str = f" [{tags}]" if tags else ""
            memory_lines.append(f"  {i}. {m.gist.text}{tag_str}")

        user_message = _USER_TEMPLATE.format(
            count=len(memories),
            memories="\n".join(memory_lines),
        )

        try:
            response = self._client.post(
                f"{self.base_url}/api/generate",
                json={
                    "model": self.model,
                    "prompt": user_message,
                    "system": _SYSTEM_PROMPT,
                    "stream": False,
                    "options": {
                        "temperature": self.temperature,
                        "num_predict": 256,
                    },
                },
            )
            response.raise_for_status()
            raw = response.json()["response"].strip()
            return self._parse_response(raw, memories)

        except Exception as e:
            logger.warning("Ollama consolidation failed: %s. Using fallback.", e)
            return self._fallback(memories)

    def _parse_response(self, raw: str, memories: list[Memory]) -> Gist:
        text = raw
        if text.startswith("```"):
            lines = text.split("\n")
            lines = [l for l in lines if not l.strip().startswith("```")]
            text = "\n".join(lines)

        try:
            data = json.loads(text)
            gist_text = data.get("gist", "").strip()
            tags = data.get("tags", [])
            if not gist_text:
                return self._fallback(memories)
            tags = [str(t).lower().strip() for t in tags if t]
            return Gist(text=gist_text, tags=tags)
        except (json.JSONDecodeError, AttributeError):
            logger.warning("Failed to parse consolidation JSON: %s", raw[:200])
            return self._fallback(memories)

    @staticmethod
    def _fallback(memories: list[Memory]) -> Gist:
        texts = [m.gist.text for m in memories[:5]]
        all_tags: dict[str, int] = {}
        for m in memories:
            for tag in m.gist.tags:
                all_tags[tag] = all_tags.get(tag, 0) + 1
        sorted_tags = sorted(all_tags, key=all_tags.get, reverse=True)
        return Gist(text=" | ".join(texts), tags=sorted_tags[:10])

    def close(self):
        self._client.close()

    def __del__(self):
        try:
            self._client.close()
        except Exception:
            pass
