"""Session summarizer — generates session-level summaries from accumulated turn gists."""

import logging
import time

from cmm.consolidation.consolidator import ConsolidationSummarizer, SimpleConsolidationSummarizer
from cmm.core.memory_store import MemoryStore
from cmm.core.types import Gist, Memory, MemoryType
from cmm.encoding.embedding import EmbeddingModel

logger = logging.getLogger(__name__)


class SessionSummarizer:
    """Generates session-level summary memories from recent episodic turns.

    A session summary captures "what happened in this conversation" as a
    single memory. It sits between turn-level gists (very specific) and
    semantic memories (general patterns).

    Session summaries have moderate importance — higher than individual
    episodic turns but lower than consolidated semantic memories.
    """

    def __init__(
        self,
        store: MemoryStore,
        embedding_model: EmbeddingModel,
        summarizer: ConsolidationSummarizer | None = None,
        session_importance: float = 1.5,
    ):
        self.store = store
        self.embedding_model = embedding_model
        self.summarizer = summarizer or SimpleConsolidationSummarizer()
        self.session_importance = session_importance

    def summarize_session(self, turn_memories: list[Memory]) -> Memory | None:
        """Create a session summary from a list of turn-level memories.

        Args:
            turn_memories: The episodic memories from this session to summarize.

        Returns:
            The newly created session summary memory, or None if not enough turns.
        """
        if len(turn_memories) < 2:
            return None

        gist = self.summarizer.summarize(turn_memories)

        # Prepend "Session summary:" to distinguish from regular gists
        gist = Gist(
            text=f"Session summary: {gist.text}",
            tags=gist.tags,
        )

        embedding = self.embedding_model.embed(gist.text)

        memory = self.store.store(
            gist=gist,
            embedding=embedding,
            memory_type=MemoryType.SEMANTIC,
            importance=self.session_importance,
        )

        logger.info(
            "Created session summary (memory %d) from %d turns: %s",
            memory.id, len(turn_memories), gist.text[:80],
        )

        return memory
