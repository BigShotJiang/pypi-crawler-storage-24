"""Multi-agent shared memory store — enables multiple agents to share a unified memory.

Architecture for production deployment:
- All agents read from and write to the same MemoryStore
- Each memory is tagged with agent_id, session_id, and scope
- PRIVATE memories are only visible to the creating agent
- SHARED/TEAM memories are visible to all agents
- Contradictions are detected and flagged with agent attribution
- Nightly consolidation rebuilds the FAISS index for all agents

For development/single-machine use, agents share a MemoryStore instance directly.
For production/multi-process use, a service layer would be needed (not implemented).
"""

import logging
from dataclasses import dataclass, field

import numpy as np

from cmm.core.memory_store import MemoryStore
from cmm.core.types import Memory, MemoryScope
from cmm.encoding.embedding import EmbeddingModel
from cmm.pipeline.conversation import CognitiveMemoryPipeline

logger = logging.getLogger(__name__)


@dataclass
class Contradiction:
    """A detected contradiction between two memories from different sources."""

    memory_a: Memory
    memory_b: Memory
    similarity: float
    description: str = ""


class SharedMemoryManager:
    """Manages a shared memory store for multiple agents.

    Provides:
    - Agent pipeline creation (each agent gets its own pipeline, shared store)
    - Contradiction detection across agents
    - Nightly consolidation (rebuild index, run consolidation)
    """

    def __init__(
        self,
        embedding_model: EmbeddingModel | None = None,
        store: MemoryStore | None = None,
    ):
        self.embedding_model = embedding_model or EmbeddingModel()
        self.store = store or MemoryStore(dim=self.embedding_model.dim)
        self._pipelines: dict[str, CognitiveMemoryPipeline] = {}

    def create_agent_pipeline(
        self,
        agent_id: str,
        session_id: str | None = None,
        default_scope: str = "team",
        **kwargs,
    ) -> CognitiveMemoryPipeline:
        """Create a pipeline for a specific agent, sharing the central store.

        All agents share the same MemoryStore and EmbeddingModel.
        Each pipeline tags its memories with the agent_id.
        """
        pipeline = CognitiveMemoryPipeline(
            embedding_model=self.embedding_model,
            store=self.store,
            agent_id=agent_id,
            session_id=session_id,
            default_scope=default_scope,
            **kwargs,
        )
        self._pipelines[agent_id] = pipeline
        return pipeline

    def get_pipeline(self, agent_id: str) -> CognitiveMemoryPipeline | None:
        return self._pipelines.get(agent_id)

    def detect_contradictions(
        self,
        similarity_threshold: float = 0.8,
    ) -> list[Contradiction]:
        """Find potential contradictions — highly similar memories from different agents.

        Two memories are flagged as a potential contradiction when they are
        semantically very similar (high embedding similarity) but come from
        different agents. This could mean:
        - One agent hallucinated incorrect information
        - A human team member provided wrong information
        - Two agents have legitimately different but overlapping information

        The contradiction includes agent attribution so the team can investigate.
        """
        memories = list(self.store._memories.values())
        if len(memories) < 2:
            return []

        contradictions: list[Contradiction] = []
        embeddings = np.array(
            [m.embedding.flatten() for m in memories], dtype=np.float32
        )

        for i in range(len(memories)):
            for j in range(i + 1, len(memories)):
                # Only flag cross-agent contradictions
                if memories[i].agent_id == memories[j].agent_id:
                    continue
                if memories[i].agent_id is None or memories[j].agent_id is None:
                    continue

                sim = float(np.dot(embeddings[i], embeddings[j]))
                if sim >= similarity_threshold:
                    contradictions.append(Contradiction(
                        memory_a=memories[i],
                        memory_b=memories[j],
                        similarity=sim,
                        description=(
                            f"High similarity ({sim:.3f}) between memories from "
                            f"agent '{memories[i].agent_id}' and agent '{memories[j].agent_id}'"
                        ),
                    ))

        contradictions.sort(key=lambda c: c.similarity, reverse=True)
        return contradictions

    def nightly_consolidation(self) -> dict:
        """Run nightly maintenance: rebuild index, consolidate, prune.

        This is designed to be run during off-hours when agents are idle.
        It rebuilds the FAISS index (incorporating all memories added during
        the day), runs episodic→semantic consolidation, and prunes old memories.

        Returns a summary of what was done.
        """
        # Rebuild FAISS index
        self.store.rebuild_index()

        # Run consolidation on each pipeline that has a consolidator
        total_consolidated = 0
        for agent_id, pipeline in self._pipelines.items():
            new_memories = pipeline.consolidate()
            total_consolidated += len(new_memories)

        # Run maintenance
        from cmm.maintenance.maintenance import MemoryMaintainer
        maintainer = MemoryMaintainer(store=self.store)
        health = maintainer.maintain()

        summary = {
            "total_memories": self.store.size,
            "agents": list(self._pipelines.keys()),
            "consolidated": total_consolidated,
            "pruned": health.pruned_count,
            "merged": health.merged_count,
            "index_trained": self.store.is_trained,
        }

        logger.info("Nightly consolidation complete: %s", summary)
        return summary

    def merge_local_store(self, local_pipeline: CognitiveMemoryPipeline) -> int:
        """Merge a local agent's memory store into the central shared store.

        This implements the local→central pattern for multi-agent teams:
        1. During the day, each agent writes to their own local pipeline
        2. At end-of-day, their local store is merged into central
        3. The local store can then be cleared for the next day

        Returns the number of memories merged.
        """
        merged = 0
        for memory in list(local_pipeline.store._memories.values()):
            self.store.store(
                gist=memory.gist,
                embedding=memory.embedding,
                memory_type=memory.memory_type,
                importance=memory.importance,
                source_role=memory.source_role,
                timestamp=memory.timestamp,
                agent_id=memory.agent_id,
                session_id=memory.session_id,
                scope=memory.scope,
            )
            # Copy emotional valence
            new_mem = list(self.store._memories.values())[-1]
            new_mem.valence = memory.valence
            new_mem.arousal = memory.arousal
            new_mem.emotion = memory.emotion
            new_mem.access_count = memory.access_count
            new_mem.last_accessed = memory.last_accessed

            # Index entities in central store
            if hasattr(self, '_entity_index') and self._entity_index:
                self._entity_index.index_memory(new_mem)

            merged += 1

        logger.info("Merged %d memories from agent '%s' into central store.",
                     merged, local_pipeline.agent_id)
        return merged

    @property
    def agent_count(self) -> int:
        return len(self._pipelines)

    def get_memories_by_agent(self, agent_id: str) -> list[Memory]:
        """Get all memories created by a specific agent."""
        return [
            m for m in self.store._memories.values()
            if m.agent_id == agent_id
        ]

    def get_memory_stats(self) -> dict:
        """Get per-agent memory statistics."""
        stats: dict[str, int] = {}
        for m in self.store._memories.values():
            aid = m.agent_id or "unknown"
            stats[aid] = stats.get(aid, 0) + 1
        return {
            "total": self.store.size,
            "by_agent": stats,
            "agents": list(self._pipelines.keys()),
        }
