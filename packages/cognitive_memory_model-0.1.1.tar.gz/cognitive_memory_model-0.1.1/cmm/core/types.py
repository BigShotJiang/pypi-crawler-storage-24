"""Core data types for the cognitive memory system."""

from dataclasses import dataclass, field
from enum import Enum
import time
from typing import Optional

import numpy as np


class MemoryType(Enum):
    EPISODIC = "episodic"
    SEMANTIC = "semantic"


class MemoryScope(Enum):
    PRIVATE = "private"    # visible only to the creating agent
    SHARED = "shared"      # visible to all agents in the team
    TEAM = "team"          # visible to all agents (default)


class Role(Enum):
    USER = "user"
    ASSISTANT = "assistant"
    SYSTEM = "system"
    THOUGHT = "thought"


@dataclass
class ConversationTurn:
    """A single turn in a conversation."""

    role: Role
    content: str
    timestamp: float = field(default_factory=time.time)


@dataclass
class Gist:
    """Compressed representation of a conversation turn or group of turns."""

    text: str
    tags: list[str] = field(default_factory=list)


@dataclass
class Memory:
    """A single memory entry in the store."""

    id: int
    gist: Gist
    embedding: np.ndarray
    timestamp: float
    memory_type: MemoryType = MemoryType.EPISODIC
    importance: float = 1.0
    access_count: int = 0
    last_accessed: float = 0.0
    source_role: Optional[Role] = None
    # Multi-agent metadata
    agent_id: Optional[str] = None
    session_id: Optional[str] = None
    scope: MemoryScope = MemoryScope.TEAM
    # Emotional valence
    valence: float = 0.0         # -1.0 (negative) to +1.0 (positive)
    arousal: float = 0.0         # 0.0 (calm) to 1.0 (intense)
    emotion: Optional[str] = None  # e.g., "frustrated", "excited", "neutral"

    def __post_init__(self):
        if self.last_accessed == 0.0:
            self.last_accessed = self.timestamp


@dataclass
class RetrievalResult:
    """A memory returned from a retrieval query, with scoring details."""

    memory: Memory
    raw_similarity: float
    final_score: float
