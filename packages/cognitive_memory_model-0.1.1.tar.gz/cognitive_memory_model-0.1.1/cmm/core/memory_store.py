"""FAISS-backed memory store with O(1) content-addressable retrieval."""

import json
import os
import threading
from pathlib import Path
from typing import Optional

import faiss
import numpy as np

from cmm.core.types import Gist, Memory, MemoryScope, MemoryType, RetrievalResult, Role


class MemoryStore:
    """Content-addressable memory store using FAISS for similarity search.

    Uses FAISS IVF (Inverted File Index) for O(1) amortized lookup.
    Buffers initial writes until enough data exists to train the IVF index,
    falling back to flat (exact) search during the buffer phase.
    """

    def __init__(
        self,
        dim: int = 384,
        nlist: int = 100,
        nprobe: int = 8,
        use_gpu: bool = False,
    ):
        self.dim = dim
        self.nlist = nlist
        self.nprobe = nprobe
        self.use_gpu = use_gpu

        self._memories: dict[int, Memory] = {}
        self._next_id: int = 0
        self._lock = threading.Lock()

        # Start with a flat index; switch to IVF once we have enough data
        self._flat_index = faiss.IndexFlatIP(dim)
        self._ivf_index: Optional[faiss.IndexIVFFlat] = None
        self._trained = False
        self._training_threshold = max(nlist * 10, 256)

        # Map from FAISS internal position to memory ID
        self._faiss_id_to_memory_id: list[int] = []

    @property
    def size(self) -> int:
        return len(self._memories)

    @property
    def is_trained(self) -> bool:
        return self._trained

    def store(
        self,
        gist: Gist,
        embedding: np.ndarray,
        memory_type: MemoryType = MemoryType.EPISODIC,
        importance: float = 1.0,
        source_role: Optional[Role] = None,
        timestamp: Optional[float] = None,
        agent_id: Optional[str] = None,
        session_id: Optional[str] = None,
        scope: MemoryScope = MemoryScope.TEAM,
    ) -> Memory:
        """Store a memory and return it."""
        embedding = self._normalize(embedding)

        with self._lock:
            memory_id = self._next_id
            self._next_id += 1

            import time

            ts = timestamp if timestamp is not None else time.time()

            memory = Memory(
                id=memory_id,
                gist=gist,
                embedding=embedding,
                timestamp=ts,
                memory_type=memory_type,
                importance=importance,
                source_role=source_role,
                agent_id=agent_id,
                session_id=session_id,
                scope=scope,
            )
            self._memories[memory_id] = memory
            self._faiss_id_to_memory_id.append(memory_id)

            vec = embedding.reshape(1, -1).astype(np.float32)
            if self._trained:
                self._ivf_index.add(vec)
            else:
                self._flat_index.add(vec)
                if self._flat_index.ntotal >= self._training_threshold:
                    self._train_ivf()

        return memory

    def retrieve(
        self,
        query_embedding: np.ndarray,
        top_k: int = 5,
        threshold: float = 0.0,
        agent_id: Optional[str] = None,
    ) -> list[RetrievalResult]:
        """Retrieve memories by similarity. Returns raw results without decay/priming.

        Args:
            agent_id: If provided, filters results to memories visible to this agent:
                - TEAM scope: visible to all agents
                - SHARED scope: visible to all agents
                - PRIVATE scope: visible only to the creating agent
                If None, returns all memories regardless of scope.
        """
        query = self._normalize(query_embedding).reshape(1, -1).astype(np.float32)

        with self._lock:
            if self.size == 0:
                return []

            index = self._ivf_index if self._trained else self._flat_index
            # Overfetch if filtering by agent (some results may be filtered out)
            fetch_k = min(top_k * 3 if agent_id else top_k, self.size)
            scores, indices = index.search(query, fetch_k)

        results = []
        for score, idx in zip(scores[0], indices[0]):
            if idx == -1 or score < threshold:
                continue
            memory_id = self._faiss_id_to_memory_id[idx]
            memory = self._memories.get(memory_id)
            if memory is None:
                continue

            # Scope filtering
            if agent_id and memory.scope == MemoryScope.PRIVATE:
                if memory.agent_id != agent_id:
                    continue

            results.append(
                RetrievalResult(
                    memory=memory,
                    raw_similarity=float(score),
                    final_score=float(score),
                )
            )

            if len(results) >= top_k:
                break

        return results

    def get(self, memory_id: int) -> Optional[Memory]:
        """Get a memory by ID."""
        return self._memories.get(memory_id)

    def update_access(self, memory_id: int) -> None:
        """Record that a memory was accessed (for recency tracking)."""
        import time

        memory = self._memories.get(memory_id)
        if memory:
            memory.access_count += 1
            memory.last_accessed = time.time()

    def remove(self, memory_id: int) -> bool:
        """Mark a memory as removed. Requires rebuild_index() to take effect in FAISS."""
        if memory_id in self._memories:
            del self._memories[memory_id]
            return True
        return False

    def rebuild_index(self) -> None:
        """Rebuild the FAISS index from remaining memories.

        Call this after removing memories to sync the FAISS index.
        """
        with self._lock:
            remaining = list(self._memories.values())
            self._flat_index.reset()
            self._ivf_index = None
            self._trained = False
            self._faiss_id_to_memory_id.clear()

            for memory in remaining:
                vec = memory.embedding.reshape(1, -1).astype(np.float32)
                self._faiss_id_to_memory_id.append(memory.id)
                self._flat_index.add(vec)

            if self._flat_index.ntotal >= self._training_threshold:
                self._train_ivf()

    def clear(self) -> None:
        """Remove all memories."""
        with self._lock:
            self._memories.clear()
            self._faiss_id_to_memory_id.clear()
            self._next_id = 0
            self._flat_index.reset()
            self._ivf_index = None
            self._trained = False

    def save(self, directory: str) -> None:
        """Save the memory store to disk.

        Saves:
        - FAISS index as a binary file
        - Memory metadata as JSON
        - ID mappings
        """
        path = Path(directory)
        path.mkdir(parents=True, exist_ok=True)

        with self._lock:
            # Save FAISS index
            index = self._ivf_index if self._trained else self._flat_index
            faiss.write_index(index, str(path / "faiss.index"))

            # Save memory metadata as JSON
            memories_data = []
            for m in self._memories.values():
                memories_data.append({
                    "id": m.id,
                    "gist_text": m.gist.text,
                    "gist_tags": m.gist.tags,
                    "embedding": m.embedding.tolist(),
                    "timestamp": m.timestamp,
                    "memory_type": m.memory_type.value,
                    "importance": m.importance,
                    "access_count": m.access_count,
                    "last_accessed": m.last_accessed,
                    "source_role": m.source_role.value if m.source_role else None,
                    "agent_id": m.agent_id,
                    "session_id": m.session_id,
                    "scope": m.scope.value,
                    "valence": m.valence,
                    "arousal": m.arousal,
                    "emotion": m.emotion,
                })

            meta = {
                "dim": self.dim,
                "nlist": self.nlist,
                "nprobe": self.nprobe,
                "next_id": self._next_id,
                "trained": self._trained,
                "faiss_id_to_memory_id": self._faiss_id_to_memory_id,
                "memories": memories_data,
            }

            with open(path / "memories.json", "w") as f:
                json.dump(meta, f)

    @classmethod
    def load(cls, directory: str) -> "MemoryStore":
        """Load a memory store from disk."""
        path = Path(directory)

        with open(path / "memories.json") as f:
            meta = json.load(f)

        store = cls(
            dim=meta["dim"],
            nlist=meta["nlist"],
            nprobe=meta["nprobe"],
        )
        store._next_id = meta["next_id"]
        store._faiss_id_to_memory_id = meta["faiss_id_to_memory_id"]
        store._trained = meta["trained"]

        # Load FAISS index
        index = faiss.read_index(str(path / "faiss.index"))
        if store._trained:
            store._ivf_index = index
            if hasattr(index, 'nprobe'):
                index.nprobe = store.nprobe
        else:
            store._flat_index = index

        # Reconstruct Memory objects
        for md in meta["memories"]:
            memory = Memory(
                id=md["id"],
                gist=Gist(text=md["gist_text"], tags=md["gist_tags"]),
                embedding=np.array(md["embedding"], dtype=np.float32),
                timestamp=md["timestamp"],
                memory_type=MemoryType(md["memory_type"]),
                importance=md["importance"],
                access_count=md["access_count"],
                last_accessed=md["last_accessed"],
                source_role=Role(md["source_role"]) if md["source_role"] else None,
                agent_id=md.get("agent_id"),
                session_id=md.get("session_id"),
                scope=MemoryScope(md.get("scope", "team")),
                valence=md.get("valence", 0.0),
                arousal=md.get("arousal", 0.0),
                emotion=md.get("emotion"),
            )
            store._memories[memory.id] = memory

        return store

    def _train_ivf(self) -> None:
        """Train the IVF index from buffered flat index data."""
        n = self._flat_index.ntotal
        vectors = faiss.rev_swig_ptr(self._flat_index.get_xb(), n * self.dim)
        vectors = np.array(vectors).reshape(n, self.dim).astype(np.float32)

        nlist = min(self.nlist, n // 2)

        quantizer = faiss.IndexFlatIP(self.dim)
        ivf = faiss.IndexIVFFlat(quantizer, self.dim, nlist, faiss.METRIC_INNER_PRODUCT)
        ivf.nprobe = self.nprobe
        ivf.train(vectors)
        ivf.add(vectors)

        if self.use_gpu:
            try:
                res = faiss.StandardGpuResources()
                ivf = faiss.index_cpu_to_gpu(res, 0, ivf)
            except Exception:
                pass  # Fall back to CPU if GPU not available

        self._ivf_index = ivf
        self._trained = True

    @staticmethod
    def _normalize(v: np.ndarray) -> np.ndarray:
        v = np.asarray(v, dtype=np.float32).flatten()
        norm = np.linalg.norm(v)
        if norm > 0:
            v = v / norm
        return v
