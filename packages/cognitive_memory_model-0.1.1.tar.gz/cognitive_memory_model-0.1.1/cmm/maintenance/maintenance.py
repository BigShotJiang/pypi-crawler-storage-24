"""Memory maintenance — pruning, deduplication, and health metrics."""

import logging
import time
from dataclasses import dataclass, field

import numpy as np

from cmm.core.memory_store import MemoryStore
from cmm.core.types import Memory, MemoryType
from cmm.retrieval.decay import DecayScorer

logger = logging.getLogger(__name__)


@dataclass
class HealthMetrics:
    """Memory store health snapshot."""

    total_memories: int = 0
    episodic_count: int = 0
    semantic_count: int = 0
    pruned_count: int = 0
    merged_count: int = 0
    avg_importance: float = 0.0
    avg_access_count: float = 0.0


class MemoryMaintainer:
    """Performs maintenance operations on the memory store.

    Operations:
    - Prune: remove old, low-importance, unaccessed memories
    - Deduplicate: merge near-duplicate memories (keep highest importance)
    - Health metrics: report on store state
    """

    def __init__(
        self,
        store: MemoryStore,
        decay_scorer: DecayScorer | None = None,
        prune_threshold: float = 0.01,
        prune_min_importance: float = 1.0,
        duplicate_threshold: float = 0.95,
    ):
        """
        Args:
            store: The memory store to maintain.
            decay_scorer: For computing effective decay (determines what's "old").
            prune_threshold: Memories with decay * importance below this are prunable.
            prune_min_importance: Only prune memories with importance at or below this.
                Protects high-importance memories (corrections, instructions) from pruning.
            duplicate_threshold: Cosine similarity above this = near-duplicate.
        """
        self.store = store
        self.decay_scorer = decay_scorer or DecayScorer()
        self.prune_threshold = prune_threshold
        self.prune_min_importance = prune_min_importance
        self.duplicate_threshold = duplicate_threshold

    def prune(self) -> int:
        """Remove old, low-importance, unaccessed memories.

        A memory is pruned if:
        - decay(age, access_count) * importance < prune_threshold
        - importance <= prune_min_importance (protects high-importance memories)

        Returns the number of memories pruned.
        """
        now = time.time()
        to_remove = []

        for memory in list(self.store._memories.values()):
            if memory.importance > self.prune_min_importance:
                continue

            decay = self.decay_scorer.compute_decay(memory, now)
            effective_score = decay * memory.importance

            if effective_score < self.prune_threshold:
                to_remove.append(memory.id)

        for mid in to_remove:
            self.store.remove(mid)

        if to_remove:
            self.store.rebuild_index()
            logger.info("Pruned %d memories.", len(to_remove))

        return len(to_remove)

    def deduplicate(self) -> int:
        """Merge near-duplicate memories.

        For each pair of memories with cosine similarity >= duplicate_threshold,
        keep the one with higher importance (or more access). Remove the other.

        Returns the number of memories removed (merged away).
        """
        memories = list(self.store._memories.values())
        if len(memories) < 2:
            return 0

        embeddings = np.array(
            [m.embedding.flatten() for m in memories], dtype=np.float32
        )

        # Compute pairwise similarities
        to_remove = set()
        for i in range(len(memories)):
            if memories[i].id in to_remove:
                continue
            for j in range(i + 1, len(memories)):
                if memories[j].id in to_remove:
                    continue

                sim = float(np.dot(embeddings[i], embeddings[j]))
                if sim >= self.duplicate_threshold:
                    # Keep the one with higher importance, or more access
                    keep, discard = self._pick_survivor(memories[i], memories[j])
                    to_remove.add(discard.id)

                    # Transfer access count to survivor
                    keep.access_count += discard.access_count

        for mid in to_remove:
            self.store.remove(mid)

        if to_remove:
            self.store.rebuild_index()
            logger.info("Deduplicated %d memories.", len(to_remove))

        return len(to_remove)

    def get_health_metrics(self) -> HealthMetrics:
        """Compute health metrics for the memory store."""
        memories = list(self.store._memories.values())
        if not memories:
            return HealthMetrics()

        episodic = sum(1 for m in memories if m.memory_type == MemoryType.EPISODIC)
        semantic = sum(1 for m in memories if m.memory_type == MemoryType.SEMANTIC)
        avg_importance = sum(m.importance for m in memories) / len(memories)
        avg_access = sum(m.access_count for m in memories) / len(memories)

        return HealthMetrics(
            total_memories=len(memories),
            episodic_count=episodic,
            semantic_count=semantic,
            avg_importance=avg_importance,
            avg_access_count=avg_access,
        )

    def maintain(self) -> HealthMetrics:
        """Run full maintenance: deduplicate, then prune. Returns health metrics."""
        merged = self.deduplicate()
        pruned = self.prune()

        metrics = self.get_health_metrics()
        metrics.pruned_count = pruned
        metrics.merged_count = merged
        return metrics

    @staticmethod
    def _pick_survivor(a: Memory, b: Memory) -> tuple[Memory, Memory]:
        """Pick which memory to keep and which to discard."""
        # Prefer higher importance
        if a.importance != b.importance:
            return (a, b) if a.importance > b.importance else (b, a)
        # Prefer more accesses
        if a.access_count != b.access_count:
            return (a, b) if a.access_count > b.access_count else (b, a)
        # Prefer newer
        return (a, b) if a.timestamp > b.timestamp else (b, a)
