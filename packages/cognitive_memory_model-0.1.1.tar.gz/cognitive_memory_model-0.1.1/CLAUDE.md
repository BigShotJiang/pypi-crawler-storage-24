# CLAUDE.md

This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.

## Project Overview

**cognitive-memory-model** is an autoassociative memory system that gives LLMs/agents automatic, cognitive-like memory. Instead of requiring agents to explicitly read/write memory files, this system passively monitors conversation streams, encodes interactions into compressed "gist" representations, and automatically surfaces relevant memories when associative cues appear in new input.

The system is a **middleware layer** between the conversation stream and the LLM's context window. The LLM does all reasoning — the memory system only surfaces relevant information.

## Core Design Principles

1. **The memory system does NOT reason.** It stores and retrieves information. The LLM handles all reasoning over recalled memories. Do not build query-response logic into the memory layer.
2. **Passive/automatic operation.** The system monitors, encodes, stores, and recalls without the agent needing to "decide" to remember or retrieve.
3. **Gist compression, not verbatim storage.** Memories are compressed summaries (like a movie plot, not the full movie). The LLM reconstructs detail at recall time.
4. **Embeddings for retrieval, not HDC.** We use standard embedding model vectors (e.g., sentence-transformers) with FAISS for similarity search. No HDC/VSA random expansion or bind/bundle algebra — the LLM handles relational reasoning directly.
5. **O(1) retrieval at scale.** FAISS IVF partitions the vector space into `nlist` cells. Query time is O(nprobe × N/nlist). With fixed nlist this is O(N/nlist) — effectively constant for small N but degrades at scale. For true O(1) at any scale, nlist must grow with N (e.g., nlist ∝ √N). Current default nlist=100 is suitable up to ~100K memories; auto-scaling is needed beyond that.

## Architecture Overview

```
Conversation stream (user↔agent turns, reasoning steps)
       │
       ▼
┌─────────────────┐
│  Gist Encoder   │  LLM or small model: turn → compressed summary + tags
└────────┬────────┘
         │
         ▼
┌─────────────────┐
│ Embedding Model │  gist text → dense vector
└────────┬────────┘
         │
         ▼
┌─────────────────────────────────┐
│     FAISS-backed Memory Store   │
│  address: embedding vector      │
│  data: gist, tags, timestamp,   │
│        importance, metadata     │
└────────┬────────────────────────┘
         │
         ▼  (query with current turn's embedding)
┌─────────────────┐
│ Activation /    │  spreading activation, decay,
│ Retrieval Layer │  priming, threshold filtering
└────────┬────────┘
         │
         ▼
  Inject recalled gists into LLM context
```

## Cognitive Features

Retrieval scoring combines multiple signals:

```
final_score = similarity * decay(age, access_count) * importance * priming_boost
```

- **Temporal decay**: `e^(-λ_eff * age)` where age = time since last access, not creation. Default λ=5e-7.
- **Grace period**: no decay for 2 weeks after last access. Memories are at full strength during this window.
- **Rehearsal**: frequently accessed memories decay slower via `λ_eff = λ / (1 + freq_weight * access_frequency_per_week)`
- **Lock threshold**: memories accessed frequently enough (default ≥0.5/week) become permanent and never decay.
- **Working memory**: fixed-size buffer (default 10) of recently activated memories with turn-based TTL (default 5). Items re-scored against current query on merge.
- **Spreading activation**: dual-path expansion from seed results: (1) FAISS embedding neighbors, (2) entity-linked memories via named entity index. Score decays per hop via `spread_factor` (default 0.5).
- **Entity linking**: spaCy NER + regex extracts named entities (people, places, organizations) at storage time. An entity index maps `entity → [memory_ids]`. Spreading activation traverses both embedding proximity AND entity links, enabling cross-domain association (e.g., "Industrial Way" connects a warehouse inspection to a hospital report).
- **Priming**: recently activated memories get a turn-decaying boost: `1 + boost_strength * e^(-decay_rate * turns)` (default 1.3x at activation).
- **Importance weighting**: auto-scored at storage time. Corrections/instructions = 2.0x, novel info = 1.5x, normal = 1.0x, routine = 0.5x.
- **Emotional valence**: each memory tagged with valence (-1 to +1), arousal (0 to 1), and emotion label. Surfaced in retrieval context for empathetic recall.
- **Metamemory**: confidence levels (HIGH/MODERATE/LOW/NONE) and "tip of the tongue" partial match hints via `recall_with_metamemory()`.
- **Threshold filtering**: only memories above final score threshold are surfaced.

## Memory Hierarchy

Three levels of compression, mirroring human memory:

1. **Turn-level gist**: what just happened (a sentence or two)
2. **Session-level summary**: what happened in this conversation (a paragraph)
3. **Thread-level theme**: recurring patterns across conversations (keywords + a sentence)

Consolidation promotes: turns → sessions → themes over time.

## Key Reference

- `docs/FAISS-SDM.md` — Reference document on using FAISS IVF for O(1) content-addressable memory on von Neumann hardware. Documents the approach for the FAISS indexing layer.

## Integrations

See `integrations/README.md` for full details. Every integration supports **true autoassociative memory** except MCP tools.

| Integration | How | Autoassociative? | Language |
|---|---|---|---|
| **HTTP Memory Server** | REST API on localhost or network | Yes | Any |
| **Claude Code Hooks** | UserPromptSubmit + Stop hooks | Yes | N/A (bash) |
| **Python Middleware** | Wraps OpenAI/Anthropic API calls | Yes | Python |
| **MCP Server** | memory_recall/store tools | Semi (tool-based) | Any MCP client |
| **Direct Library** | `CognitiveMemoryPipeline` API | Yes | Python |

Key features across all integrations:
- **Persistence**: `pipeline.save(dir)` / `pipeline.load(dir)` — memories survive restarts
- **Think-out-loud**: capture LLM reasoning as `THOUGHT`-type memories via `<thinking>` tags
- **Multi-agent teams**: `agent_id`/`session_id` tagging, scoped visibility, local→central merge, nightly consolidation
- **Context framing**: recalled memories are clearly marked as "from memory, not current user input" with relevance scores and agent attribution
| **Direct Library** | `CognitiveMemoryPipeline` API | Yes | Python |

**Autoassociative** means the memory system passively monitors all conversation turns and automatically surfaces relevant memories — no one has to decide to "look something up." Every path except MCP achieves this by wrapping the conversation stream so both user messages and LLM responses are captured and recalled automatically.

**MCP tools** are the exception: the LLM must decide to call `memory_recall`. This is the only option for environments that don't support hooks or API wrapping (e.g., Claude Desktop without hooks).

## Package Structure

```
cmm/
├── core/
│   ├── types.py                  # Memory, Gist, ConversationTurn, RetrievalResult, Role, MemoryType
│   └── memory_store.py           # FAISS-backed store with flat→IVF auto-training, remove + rebuild
├── encoding/
│   ├── embedding.py              # Sentence-transformers wrapper (768D, all-mpnet-base-v2)
│   ├── gist_encoder.py           # GistEncoder ABC + PassthroughGistEncoder baseline
│   ├── ollama_gist_encoder.py    # OllamaGistEncoder — local LLM gist compression via Ollama
│   ├── openai_gist_encoder.py    # OpenAIGistEncoder — any OpenAI-compatible API
│   └── anthropic_gist_encoder.py # AnthropicGistEncoder — Anthropic Claude API
├── retrieval/
│   ├── decay.py                  # DecayScorer — temporal decay with rehearsal effect
│   ├── working_memory.py         # WorkingMemory — fixed-size turn-based TTL buffer
│   ├── spreading_activation.py   # SpreadingActivation — dual-path: FAISS neighbors + entity links
│   ├── entity_index.py           # EntityIndex — spaCy NER + regex entity extraction and indexing
│   ├── priming.py                # PrimingState — turn-decaying boost for recently activated memories
│   ├── metamemory.py             # MetamemoryScorer — confidence levels + partial match hints
│   └── retriever.py              # Full retrieval pipeline: FAISS + decay + priming + spreading + WM + metamemory
├── scoring/
│   ├── importance.py             # ImportanceScorer — auto-scores turns (corrections, instructions, novelty, routine)
│   └── valence.py                # ValenceScorer — emotional valence, arousal, and emotion labels
├── consolidation/
│   ├── consolidator.py           # Consolidator — clusters episodic → semantic memories
│   ├── ollama_summarizer.py      # OllamaConsolidationSummarizer — LLM-based cluster summarization
│   └── session.py                # SessionSummarizer — end-of-session summary generation
├── maintenance/
│   └── maintenance.py            # MemoryMaintainer — pruning, deduplication, health metrics
├── multi_agent/
│   └── shared_store.py           # SharedMemoryManager — multi-agent shared memory with contradiction detection
└── pipeline/
    └── conversation.py           # CognitiveMemoryPipeline — main entry point (ingest/recall/consolidate/maintain)

integrations/
├── README.md                     # Integration guide — which path to use
├── middleware.py                  # Python API middleware (wraps OpenAI/Anthropic)
├── claude-code/
│   ├── README.md                 # Claude Code setup instructions
│   ├── memory_server.py          # HTTP memory server (language-agnostic)
│   └── hooks/
│       ├── on_user_message.sh    # UserPromptSubmit hook
│       └── on_assistant_response.sh  # Stop hook
└── mcp/
    └── server.py                 # MCP server for Claude Desktop, Cursor, etc.
```

## Development

See `docs/DEVELOPMENT_PLAN.md` for the phased implementation roadmap. All 5 phases are complete.

### Setup

```bash
python3 -m venv .venv
source .venv/bin/activate
pip install torch --index-url https://download.pytorch.org/whl/cu126  # CUDA 12.6
pip install -e ".[dev]"
```

### Run Tests

```bash
pytest                                          # all tests (requires Ollama for some)
pytest --ignore=tests/test_ollama_encoder.py \
       --ignore=tests/test_phase4_integration.py  # fast tests (no Ollama needed)
pytest tests/test_pipeline.py                   # pipeline + zebra test
pytest -v -k "zebra"                            # just the zebra test
```

Ollama-dependent tests are skipped automatically if Ollama is not running. The local Mistral 7B model is used for gist encoding and consolidation summarization — preferred over fallbacks in all integration tests.

### Run Demos

```bash
python -m demos.handoff --backend anthropic        # Multi-agent shared memory
python -m demos.tip_of_tongue --backend anthropic  # Metamemory tip-of-tongue
python -m demos.six_weeks --backend anthropic      # 6-week personal assistant
python -m demos.investigator --backend anthropic   # Spreading activation at scale
```

### Dependencies

- `torch` (CUDA 12.6) — GPU-accelerated tensor ops for sentence-transformers
- `faiss-cpu` — FAISS similarity search (GPU optional via `pip install faiss-gpu-cu12`)
- `sentence-transformers` — embedding model (`all-mpnet-base-v2`, 768D)
- `spacy` + `en_core_web_sm` — named entity recognition for entity-linked spreading
- `numpy`, `scipy`, `scikit-learn` — transitive deps
