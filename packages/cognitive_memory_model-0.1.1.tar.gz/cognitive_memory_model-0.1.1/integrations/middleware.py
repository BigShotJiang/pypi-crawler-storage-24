"""API Middleware — wraps any LLM API call with automatic memory.

Provides fully autoassociative memory for Python developers using
any LLM API (OpenAI, Anthropic, or any OpenAI-compatible endpoint).

Usage:
    from integrations.middleware import MemoryMiddleware

    # With OpenAI
    mw = MemoryMiddleware(api_type="openai", api_key="sk-...")
    response = mw.chat("What is the Zorbax fish?")
    # Memory is automatically ingested and recalled on every call.

    # With Anthropic
    mw = MemoryMiddleware(api_type="anthropic", api_key="sk-ant-...")
    response = mw.chat("Tell me about the peanut allergy")

    # With any OpenAI-compatible endpoint
    mw = MemoryMiddleware(
        api_type="openai",
        base_url="https://api.together.xyz/v1",
        model="meta-llama/Llama-3-8b-chat-hf",
        api_key="...",
    )
"""

import logging
from typing import Any

from cmm.pipeline.conversation import CognitiveMemoryPipeline
from cmm.retrieval.retriever import Retriever

logger = logging.getLogger(__name__)


class MemoryMiddleware:
    """Wraps LLM API calls with automatic cognitive memory.

    On each `chat()` call:
    1. The user's message is ingested into memory
    2. Relevant memories are recalled and injected into context
    3. The LLM generates a response with memory context
    4. The response is ingested into memory
    5. The response is returned

    Both sides of every conversation are captured automatically.
    """

    def __init__(
        self,
        api_type: str = "openai",
        model: str | None = None,
        base_url: str | None = None,
        api_key: str | None = None,
        system_prompt: str = "You are a helpful assistant.",
        think_out_loud: bool = False,
        pipeline: CognitiveMemoryPipeline | None = None,
        **pipeline_kwargs,
    ):
        """
        Args:
            api_type: "openai" or "anthropic"
            model: Model name. Defaults to gpt-4o-mini (OpenAI) or claude-sonnet-4-6 (Anthropic).
            base_url: API base URL. For OpenAI-compatible endpoints.
            api_key: API key. Falls back to env vars.
            system_prompt: System prompt for the LLM.
            think_out_loud: If True, instructs the LLM to include reasoning
                in <thinking> tags. The reasoning is captured and stored as
                THOUGHT-type memories for richer context.
            pipeline: Pre-configured memory pipeline. If None, creates default.
            **pipeline_kwargs: Additional kwargs for CognitiveMemoryPipeline.
        """
        self.api_type = api_type
        self.think_out_loud = think_out_loud
        self.pipeline = pipeline or CognitiveMemoryPipeline(**pipeline_kwargs)

        # Build system prompt with optional think-out-loud instruction
        self.system_prompt = system_prompt
        if think_out_loud:
            self.system_prompt += (
                "\n\nWhen reasoning through a problem, include your thinking process "
                "in <thinking>...</thinking> tags before your response. This helps "
                "build a richer memory of your reasoning for future conversations."
            )

        if api_type == "openai":
            import httpx
            import os
            self._model = model or "gpt-4o-mini"
            self._base_url = (base_url or "https://api.openai.com/v1").rstrip("/")
            self._api_key = api_key or os.environ.get("OPENAI_API_KEY", "")
            self._client = httpx.Client(timeout=60)
        elif api_type == "anthropic":
            import anthropic
            import os
            self._model = model or "claude-sonnet-4-6"
            key = api_key or os.environ.get("ANTHROPIC_API_KEY")
            self._client = anthropic.Anthropic(api_key=key)
        else:
            raise ValueError(f"Unknown api_type: {api_type}. Use 'openai' or 'anthropic'.")

        self._conversation: list[dict] = []

    def chat(self, message: str, top_k: int = 5) -> str:
        """Send a message with automatic memory recall and storage.

        Args:
            message: The user's message.
            top_k: Number of memories to recall.

        Returns:
            The LLM's response text.
        """
        # Step 1: Ingest user message + recall from memory
        results = self.pipeline.ingest("user", message)
        context = Retriever.format_for_context(results)

        # Step 2: Build prompt with memory context
        augmented_system = self.system_prompt
        if context:
            augmented_system += (
                "\n\nYou have the following information from your memory of "
                "past conversations. Use it if relevant:\n\n" + context
            )

        # Step 3: Call the LLM
        if self.api_type == "openai":
            response_text = self._call_openai(augmented_system, message)
        else:
            response_text = self._call_anthropic(augmented_system, message)

        # Step 4: Extract and store thinking blocks if present
        import re
        thinking_match = re.search(r"<thinking>(.*?)</thinking>", response_text, re.DOTALL)
        if thinking_match and self.think_out_loud:
            thinking_text = thinking_match.group(1).strip()
            self.pipeline.ingest("thought", thinking_text)
            # Store the response without the thinking block
            clean_response = re.sub(r"<thinking>.*?</thinking>\s*", "", response_text, flags=re.DOTALL).strip()
            self.pipeline.ingest("assistant", clean_response)
        else:
            clean_response = response_text
            self.pipeline.ingest("assistant", response_text)

        # Step 5: Update conversation history
        self._conversation.append({"role": "user", "content": message})
        self._conversation.append({"role": "assistant", "content": clean_response})

        return clean_response

    def recall(self, query: str, top_k: int = 5) -> str:
        """Query memory without sending to LLM."""
        results = self.pipeline.recall(query, top_k=top_k)
        return Retriever.format_for_context(results)

    @property
    def memory_count(self) -> int:
        return self.pipeline.memory_count

    def _call_openai(self, system: str, message: str) -> str:
        messages = [{"role": "system", "content": system}]
        # Include recent conversation for context
        messages.extend(self._conversation[-10:])
        messages.append({"role": "user", "content": message})

        response = self._client.post(
            f"{self._base_url}/chat/completions",
            headers={
                "Authorization": f"Bearer {self._api_key}",
                "Content-Type": "application/json",
            },
            json={
                "model": self._model,
                "messages": messages,
                "temperature": 0.7,
                "max_tokens": 1000,
            },
        )
        response.raise_for_status()
        return response.json()["choices"][0]["message"]["content"].strip()

    def _call_anthropic(self, system: str, message: str) -> str:
        messages = list(self._conversation[-10:])
        messages.append({"role": "user", "content": message})

        response = self._client.messages.create(
            model=self._model,
            max_tokens=1000,
            temperature=0.7,
            system=system,
            messages=messages,
        )
        return response.content[0].text.strip()
