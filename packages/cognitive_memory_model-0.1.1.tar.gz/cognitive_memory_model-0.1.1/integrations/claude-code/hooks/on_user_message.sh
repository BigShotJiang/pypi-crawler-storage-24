#!/bin/bash
# Claude Code Hook: UserPromptSubmit
# Fires on every user message. Ingests the message into memory and
# returns recalled memories as additionalContext.
#
# The memory server must be running: python -m integrations.claude-code.memory_server

set -e

CMM_PORT="${CMM_PORT:-7832}"
CMM_URL="http://127.0.0.1:${CMM_PORT}"

# Read hook input from stdin
INPUT=$(cat)
PROMPT=$(echo "$INPUT" | jq -r '.prompt // empty')

if [ -z "$PROMPT" ]; then
    # No prompt, pass through
    echo '{}'
    exit 0
fi

# Call the memory server: ingest user message + recall relevant memories
RESPONSE=$(curl -s -X POST "${CMM_URL}/ingest_and_recall" \
    -H "Content-Type: application/json" \
    -d "$(jq -n --arg content "$PROMPT" --arg role "user" '{role: $role, content: $content}')" \
    2>/dev/null)

if [ $? -ne 0 ] || [ -z "$RESPONSE" ]; then
    # Server not running or error — pass through silently
    echo '{}'
    exit 0
fi

# Extract the recalled context
CONTEXT=$(echo "$RESPONSE" | jq -r '.context // empty')
COUNT=$(echo "$RESPONSE" | jq -r '.count // 0')

if [ -z "$CONTEXT" ] || [ "$COUNT" = "0" ]; then
    # No memories recalled — pass through
    echo '{}'
    exit 0
fi

# Return the recalled memories as additional context
jq -n --arg context "$CONTEXT" '{
    "additionalContext": $context
}'
