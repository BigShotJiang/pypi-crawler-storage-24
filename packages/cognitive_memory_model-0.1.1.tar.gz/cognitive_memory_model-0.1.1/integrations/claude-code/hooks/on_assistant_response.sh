#!/bin/bash
# Claude Code Hook: Stop
# Fires after every assistant response. Ingests the response into memory
# so both sides of the conversation are captured.
#
# The memory server must be running: python -m integrations.claude-code.memory_server

set -e

CMM_PORT="${CMM_PORT:-7832}"
CMM_URL="http://127.0.0.1:${CMM_PORT}"

# Read hook input from stdin
INPUT=$(cat)
RESPONSE_TEXT=$(echo "$INPUT" | jq -r '.last_assistant_message // empty')

if [ -z "$RESPONSE_TEXT" ]; then
    exit 0
fi

# Truncate very long responses to avoid overwhelming the gist encoder
TRUNCATED=$(echo "$RESPONSE_TEXT" | head -c 2000)

# Ingest the assistant's response into memory (fire and forget)
curl -s -X POST "${CMM_URL}/ingest" \
    -H "Content-Type: application/json" \
    -d "$(jq -n --arg content "$TRUNCATED" --arg role "assistant" '{role: $role, content: $content}')" \
    >/dev/null 2>&1 || true

exit 0
