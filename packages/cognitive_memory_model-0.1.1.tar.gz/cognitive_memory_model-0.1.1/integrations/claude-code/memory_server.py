"""Memory server — HTTP API for cognitive memory.

Supports both single-agent and multi-agent (distributed) use:
- Single agent: all requests share one pipeline
- Multi-agent: each request includes agent_id, memories are tagged and scoped

Persists to disk on save/shutdown, loads on startup.

Usage:
    # Single agent (e.g., one Claude Code instance)
    python -m integrations.claude-code.memory_server

    # Multi-agent with persistence (e.g., 60 agents on a team)
    python -m integrations.claude-code.memory_server --data-dir ./memory_data --auto-save 300

    # Bind to network for remote agents
    python -m integrations.claude-code.memory_server --host 0.0.0.0 --port 7832 --data-dir ./memory_data
"""

import argparse
import atexit
import json
import logging
import os
import signal
import threading
import time
from http.server import HTTPServer, BaseHTTPRequestHandler
from socketserver import ThreadingMixIn

from cmm.encoding.embedding import EmbeddingModel
from cmm.multi_agent.shared_store import SharedMemoryManager
from cmm.pipeline.conversation import CognitiveMemoryPipeline
from cmm.retrieval.retriever import Retriever

logger = logging.getLogger(__name__)

# Global state
_manager: SharedMemoryManager | None = None
_data_dir: str | None = None
_emb_model: EmbeddingModel | None = None


def get_manager() -> SharedMemoryManager:
    global _manager, _emb_model
    if _manager is None:
        logger.info("Initializing shared memory manager...")
        _emb_model = EmbeddingModel()
        _manager = SharedMemoryManager(embedding_model=_emb_model)
        logger.info("Manager ready. Embedding dim: %d", _emb_model.dim)
    return _manager


def get_pipeline(agent_id: str | None = None, session_id: str | None = None) -> CognitiveMemoryPipeline:
    """Get or create a pipeline for a specific agent."""
    manager = get_manager()
    aid = agent_id or "default"

    existing = manager.get_pipeline(aid)
    if existing:
        return existing

    return manager.create_agent_pipeline(
        agent_id=aid,
        session_id=session_id,
        retriever_threshold=0.2,
        retriever_top_k=5,
    )


def save_state():
    """Save memory state to disk."""
    if _manager and _data_dir:
        try:
            # Save the shared store
            pipeline = get_pipeline()
            pipeline.save(_data_dir)
            logger.info("Saved %d memories to %s", _manager.store.size, _data_dir)
        except Exception as e:
            logger.error("Failed to save: %s", e)


def load_state():
    """Load memory state from disk if available."""
    global _manager, _emb_model
    if _data_dir and os.path.exists(os.path.join(_data_dir, "memories.json")):
        try:
            logger.info("Loading memories from %s...", _data_dir)
            _emb_model = EmbeddingModel()
            pipeline = CognitiveMemoryPipeline.load(_data_dir, embedding_model=_emb_model)
            _manager = SharedMemoryManager(embedding_model=_emb_model, store=pipeline.store)
            logger.info("Loaded %d memories.", _manager.store.size)
        except Exception as e:
            logger.error("Failed to load: %s. Starting fresh.", e)


class ThreadedHTTPServer(ThreadingMixIn, HTTPServer):
    """HTTP server that handles each request in a separate thread."""
    daemon_threads = True


class MemoryHandler(BaseHTTPRequestHandler):
    """HTTP handler for memory operations."""

    def _parse_body(self):
        content_length = int(self.headers.get("Content-Length", 0))
        body = self.rfile.read(content_length).decode("utf-8") if content_length else "{}"
        return json.loads(body)

    def do_POST(self):
        try:
            data = self._parse_body()
        except json.JSONDecodeError:
            self._respond(400, {"error": "Invalid JSON"})
            return

        routes = {
            "/ingest": self._handle_ingest,
            "/recall": self._handle_recall,
            "/ingest_and_recall": self._handle_ingest_and_recall,
            "/health": lambda d: self._handle_health(),
            "/save": lambda d: self._handle_save(),
            "/consolidate": self._handle_consolidate,
            "/contradictions": self._handle_contradictions,
            "/stats": lambda d: self._handle_stats(),
            "/merge": self._handle_merge,
            "/end_of_day": self._handle_end_of_day,
        }

        handler = routes.get(self.path)
        if handler:
            handler(data)
        else:
            self._respond(404, {"error": f"Unknown endpoint: {self.path}"})

    def do_GET(self):
        if self.path == "/health":
            self._handle_health()
        elif self.path == "/stats":
            self._handle_stats()
        elif self.path.startswith("/memory/"):
            self._handle_get_memory()
        elif self.path == "/memories":
            self._handle_list_memories()
        else:
            self._respond(404, {"error": f"Unknown endpoint: {self.path}"})

    def do_PUT(self):
        if self.path.startswith("/memory/"):
            try:
                data = self._parse_body()
            except json.JSONDecodeError:
                self._respond(400, {"error": "Invalid JSON"})
                return
            self._handle_update_memory(data)
        else:
            self._respond(404, {"error": f"Unknown endpoint: {self.path}"})

    def do_DELETE(self):
        if self.path.startswith("/memory/"):
            self._handle_delete_memory()
        elif self.path.startswith("/memories/agent/"):
            self._handle_delete_agent_memories()
        else:
            self._respond(404, {"error": f"Unknown endpoint: {self.path}"})

    def _handle_ingest(self, data):
        role = data.get("role", "user")
        content = data.get("content", "")
        agent_id = data.get("agent_id")
        session_id = data.get("session_id")

        if not content:
            self._respond(400, {"error": "Missing 'content' field"})
            return

        pipeline = get_pipeline(agent_id, session_id)
        results = pipeline.ingest(role, content)

        self._respond(200, {
            "status": "ingested",
            "agent_id": agent_id or "default",
            "memory_count": get_manager().store.size,
            "recalled": len(results),
        })

    def _handle_recall(self, data):
        query = data.get("query", "")
        top_k = data.get("top_k", 5)
        agent_id = data.get("agent_id")

        if not query:
            self._respond(400, {"error": "Missing 'query' field"})
            return

        pipeline = get_pipeline(agent_id)
        results = pipeline.recall(query, top_k=top_k)
        context = Retriever.format_for_context(results)

        self._respond(200, {
            "context": context,
            "count": len(results),
            "memories": [
                {
                    "text": r.memory.gist.text,
                    "score": r.final_score,
                    "tags": r.memory.gist.tags,
                    "emotion": r.memory.emotion,
                    "agent_id": r.memory.agent_id,
                }
                for r in results
            ],
        })

    def _handle_ingest_and_recall(self, data):
        role = data.get("role", "user")
        content = data.get("content", "")
        top_k = data.get("top_k", 5)
        agent_id = data.get("agent_id")
        session_id = data.get("session_id")

        if not content:
            self._respond(400, {"error": "Missing 'content' field"})
            return

        pipeline = get_pipeline(agent_id, session_id)
        results = pipeline.ingest(role, content)
        context = Retriever.format_for_context(results)

        self._respond(200, {
            "context": context,
            "count": len(results),
            "agent_id": agent_id or "default",
            "memory_count": get_manager().store.size,
        })

    def _handle_health(self):
        manager = get_manager()
        self._respond(200, {
            "status": "ok",
            "total_memories": manager.store.size,
            "agents": list(manager._pipelines.keys()) if manager._pipelines else ["default"],
        })

    def _handle_stats(self):
        manager = get_manager()
        stats = manager.get_memory_stats()
        self._respond(200, stats)

    def _handle_save(self, data=None):
        save_state()
        self._respond(200, {"status": "saved", "path": _data_dir or "no data dir configured"})

    def _handle_consolidate(self, data):
        manager = get_manager()
        summary = manager.nightly_consolidation()
        save_state()
        self._respond(200, summary)

    def _handle_merge(self, data):
        """Merge memories from a local store file into the central store.

        Used by multi-agent teams: each agent saves their local store to
        a file, then POSTs the path to /merge. The server loads and merges
        the memories into the central store.
        """
        local_path = data.get("path", "")
        if not local_path or not os.path.exists(os.path.join(local_path, "memories.json")):
            self._respond(400, {"error": "Missing or invalid 'path' to local store directory"})
            return

        from cmm.core.memory_store import MemoryStore
        try:
            local_store = MemoryStore.load(local_path)
            manager = get_manager()

            merged = 0
            for memory in local_store._memories.values():
                manager.store.store(
                    gist=memory.gist,
                    embedding=memory.embedding,
                    memory_type=memory.memory_type,
                    importance=memory.importance,
                    source_role=memory.source_role,
                    timestamp=memory.timestamp,
                    agent_id=memory.agent_id,
                    session_id=memory.session_id,
                    scope=memory.scope,
                )
                new_mem = list(manager.store._memories.values())[-1]
                new_mem.valence = memory.valence
                new_mem.arousal = memory.arousal
                new_mem.emotion = memory.emotion
                new_mem.access_count = memory.access_count
                new_mem.last_accessed = memory.last_accessed
                merged += 1

            self._respond(200, {
                "status": "merged",
                "merged_count": merged,
                "total_memories": manager.store.size,
            })
        except Exception as e:
            self._respond(500, {"error": f"Merge failed: {e}"})

    def _handle_end_of_day(self, data):
        """Run the full end-of-day workflow for multi-agent teams.

        1. Run consolidation (cluster episodic → semantic)
        2. Run maintenance (dedup + prune)
        3. Detect contradictions
        4. Save to disk
        """
        manager = get_manager()

        # Consolidation
        summary = manager.nightly_consolidation()

        # Contradiction detection
        contradictions = manager.detect_contradictions(similarity_threshold=0.7)

        # Save
        save_state()

        summary["contradictions_found"] = len(contradictions)
        if contradictions:
            summary["top_contradictions"] = [
                {
                    "agent_a": c.memory_a.agent_id,
                    "agent_b": c.memory_b.agent_id,
                    "similarity": round(c.similarity, 3),
                    "text_a": c.memory_a.gist.text[:80],
                    "text_b": c.memory_b.gist.text[:80],
                }
                for c in contradictions[:5]
            ]

        self._respond(200, summary)

    def _handle_contradictions(self, data):
        threshold = data.get("threshold", 0.7)
        manager = get_manager()
        contradictions = manager.detect_contradictions(similarity_threshold=threshold)
        self._respond(200, {
            "count": len(contradictions),
            "contradictions": [
                {
                    "agent_a": c.memory_a.agent_id,
                    "text_a": c.memory_a.gist.text[:100],
                    "agent_b": c.memory_b.agent_id,
                    "text_b": c.memory_b.gist.text[:100],
                    "similarity": round(c.similarity, 3),
                }
                for c in contradictions[:20]
            ],
        })

    # --- CRUD operations for individual memories ---

    def _parse_memory_id(self) -> int | None:
        """Extract memory ID from URL path like /memory/123."""
        try:
            return int(self.path.split("/")[-1])
        except (ValueError, IndexError):
            return None

    def _handle_get_memory(self):
        """GET /memory/{id} — retrieve a single memory by ID."""
        memory_id = self._parse_memory_id()
        if memory_id is None:
            self._respond(400, {"error": "Invalid memory ID"})
            return

        manager = get_manager()
        memory = manager.store.get(memory_id)
        if memory is None:
            self._respond(404, {"error": f"Memory {memory_id} not found"})
            return

        self._respond(200, {
            "id": memory.id,
            "gist": memory.gist.text,
            "tags": memory.gist.tags,
            "importance": memory.importance,
            "memory_type": memory.memory_type.value,
            "agent_id": memory.agent_id,
            "session_id": memory.session_id,
            "scope": memory.scope.value,
            "emotion": memory.emotion,
            "valence": memory.valence,
            "arousal": memory.arousal,
            "access_count": memory.access_count,
            "timestamp": memory.timestamp,
            "last_accessed": memory.last_accessed,
        })

    def _handle_update_memory(self, data):
        """PUT /memory/{id} — update a memory's gist text, tags, or importance."""
        memory_id = self._parse_memory_id()
        if memory_id is None:
            self._respond(400, {"error": "Invalid memory ID"})
            return

        manager = get_manager()
        memory = manager.store.get(memory_id)
        if memory is None:
            self._respond(404, {"error": f"Memory {memory_id} not found"})
            return

        # Update allowed fields
        if "gist" in data:
            memory.gist.text = data["gist"]
        if "tags" in data:
            memory.gist.tags = data["tags"]
        if "importance" in data:
            memory.importance = float(data["importance"])

        self._respond(200, {
            "status": "updated",
            "id": memory_id,
            "gist": memory.gist.text,
            "importance": memory.importance,
        })

    def _handle_delete_memory(self):
        """DELETE /memory/{id} — delete a single memory."""
        memory_id = self._parse_memory_id()
        if memory_id is None:
            self._respond(400, {"error": "Invalid memory ID"})
            return

        manager = get_manager()
        removed = manager.store.remove(memory_id)
        if not removed:
            self._respond(404, {"error": f"Memory {memory_id} not found"})
            return

        # Remove from entity index if applicable
        for pipeline in manager._pipelines.values():
            if pipeline.entity_index:
                pipeline.entity_index.remove_memory(memory_id)
                break

        manager.store.rebuild_index()
        self._respond(200, {
            "status": "deleted",
            "id": memory_id,
            "remaining": manager.store.size,
        })

    def _handle_delete_agent_memories(self):
        """DELETE /memories/agent/{agent_id} — delete all memories from a specific agent."""
        agent_id = self.path.split("/")[-1]
        if not agent_id:
            self._respond(400, {"error": "Missing agent_id"})
            return

        manager = get_manager()
        agent_memories = manager.get_memories_by_agent(agent_id)
        count = 0
        for m in agent_memories:
            manager.store.remove(m.id)
            count += 1

        if count > 0:
            manager.store.rebuild_index()

        self._respond(200, {
            "status": "deleted",
            "agent_id": agent_id,
            "deleted_count": count,
            "remaining": manager.store.size,
        })

    def _handle_list_memories(self):
        """GET /memories?agent_id=X&limit=50 — list memories with optional filtering."""
        from urllib.parse import urlparse, parse_qs
        parsed = urlparse(self.path)
        params = parse_qs(parsed.query)
        agent_filter = params.get("agent_id", [None])[0]
        limit = int(params.get("limit", [50])[0])

        manager = get_manager()
        memories = list(manager.store._memories.values())

        if agent_filter:
            memories = [m for m in memories if m.agent_id == agent_filter]

        # Sort by most recent first
        memories.sort(key=lambda m: m.timestamp, reverse=True)
        memories = memories[:limit]

        self._respond(200, {
            "count": len(memories),
            "memories": [
                {
                    "id": m.id,
                    "gist": m.gist.text[:200],
                    "tags": m.gist.tags,
                    "importance": m.importance,
                    "agent_id": m.agent_id,
                    "memory_type": m.memory_type.value,
                    "emotion": m.emotion,
                }
                for m in memories
            ],
        })

    def _respond(self, status: int, data: dict):
        self.send_response(status)
        self.send_header("Content-Type", "application/json")
        self.end_headers()
        self.wfile.write(json.dumps(data).encode("utf-8"))

    def log_message(self, format, *args):
        logger.debug(format, *args)


def auto_save_loop(interval: int):
    """Background thread that saves state periodically."""
    while True:
        time.sleep(interval)
        save_state()


def main():
    global _data_dir

    parser = argparse.ArgumentParser(description="CMM Memory Server")
    parser.add_argument("--port", "-p", type=int, default=7832, help="Port to listen on")
    parser.add_argument("--host", default="127.0.0.1",
                        help="Host to bind to. Use 0.0.0.0 for network access.")
    parser.add_argument("--data-dir", "-d", default=None,
                        help="Directory for persistent storage. If set, memories survive restarts.")
    parser.add_argument("--auto-save", type=int, default=0,
                        help="Auto-save interval in seconds. 0 = save only on shutdown.")
    parser.add_argument("--verbose", "-v", action="store_true")
    args = parser.parse_args()

    logging.basicConfig(
        level=logging.DEBUG if args.verbose else logging.INFO,
        format="%(asctime)s [CMM] %(message)s",
    )

    _data_dir = args.data_dir

    # Load existing state if available
    if _data_dir:
        load_state()

    # Pre-initialize if not loaded
    get_manager()

    # Save on shutdown
    if _data_dir:
        atexit.register(save_state)
        signal.signal(signal.SIGTERM, lambda *_: (save_state(), exit(0)))

    # Auto-save thread
    if args.auto_save > 0 and _data_dir:
        t = threading.Thread(target=auto_save_loop, args=(args.auto_save,), daemon=True)
        t.start()
        logger.info("Auto-save every %ds to %s", args.auto_save, _data_dir)

    server = ThreadedHTTPServer((args.host, args.port), MemoryHandler)
    logger.info("Memory server listening on http://%s:%d", args.host, args.port)
    logger.info("Persistence: %s", _data_dir or "disabled (use --data-dir to enable)")
    logger.info("Endpoints: POST /ingest, /recall, /ingest_and_recall, /save, /consolidate, /contradictions, GET /health, /stats")

    try:
        server.serve_forever()
    except KeyboardInterrupt:
        logger.info("Shutting down...")
        if _data_dir:
            save_state()
        server.server_close()


if __name__ == "__main__":
    main()
