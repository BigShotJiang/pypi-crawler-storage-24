# Claude Code Hooks Integration

Gives Claude Code **true autoassociative memory** — every conversation is automatically encoded, stored, and recalled without any manual intervention.

## How It Works

```
User types message
    → UserPromptSubmit hook fires
    → Hook calls memory server: ingest(user_message) + recall(query)
    → Hook returns recalled memories as additionalContext
    → Claude sees: user message + recalled memories
    → Claude responds
    → Stop hook fires
    → Hook calls memory server: ingest(assistant_response)
    → Memory store updated with both sides of the conversation
```

Both user messages AND assistant responses are captured. Relevant memories from past conversations are automatically surfaced in future conversations.

## Setup

### 1. Start the memory server

```bash
cd /path/to/cognitive-memory-model
source .venv/bin/activate
python -m integrations.claude-code.memory_server
```

The server runs on `http://127.0.0.1:7832` by default. It loads the embedding model and maintains the FAISS index in-memory.

### 2. Configure Claude Code hooks

Add the following to your Claude Code settings (`.claude/settings.json` or `~/.claude/settings.json`):

```json
{
  "hooks": {
    "UserPromptSubmit": [
      {
        "hooks": [
          {
            "type": "command",
            "command": "/path/to/cognitive-memory-model/integrations/claude-code/hooks/on_user_message.sh",
            "timeout": 10
          }
        ]
      }
    ],
    "Stop": [
      {
        "hooks": [
          {
            "type": "command",
            "command": "/path/to/cognitive-memory-model/integrations/claude-code/hooks/on_assistant_response.sh",
            "timeout": 5
          }
        ]
      }
    ]
  }
}
```

Replace `/path/to/cognitive-memory-model` with the actual path to this repo.

### 3. Use Claude Code normally

That's it. The hooks fire automatically on every message. Recalled memories appear in Claude's context as `[Recalled from memory...]...[End recalled memories]` blocks, clearly marked as past context (not current user input).

## Configuration

| Environment Variable | Default | Description |
|---|---|---|
| `CMM_PORT` | `7832` | Port the memory server listens on |

## Checking Memory Health

```bash
curl http://127.0.0.1:7832/health
```

## Requirements

- `jq` (for JSON processing in hook scripts)
- `curl` (for HTTP calls to memory server)
- The memory server must be running before Claude Code starts
