"""MCP Server for Cognitive Memory Model.

Exposes the memory pipeline as MCP tools that any MCP-compatible client
(Claude Desktop, Cursor, Windsurf, etc.) can use.

Tools:
- memory_recall: Search memory for relevant information
- memory_store: Store a new memory
- memory_status: Check memory system health
- memory_recall_with_metamemory: Search with confidence levels + partial matches

Usage:
    python -m integrations.mcp.server

Configure in Claude Desktop's claude_desktop_config.json:
    {
      "mcpServers": {
        "cognitive-memory": {
          "command": "python",
          "args": ["-m", "integrations.mcp.server"],
          "cwd": "/path/to/cognitive-memory-model",
          "env": {}
        }
      }
    }
"""

import json
import logging

from mcp.server.fastmcp import FastMCP

from cmm.encoding.embedding import EmbeddingModel
from cmm.pipeline.conversation import CognitiveMemoryPipeline
from cmm.retrieval.metamemory import MetamemoryScorer
from cmm.retrieval.retriever import Retriever

logger = logging.getLogger(__name__)

# Initialize the MCP server
mcp = FastMCP("Cognitive Memory")

# Global pipeline
_pipeline: CognitiveMemoryPipeline | None = None


def _get_pipeline() -> CognitiveMemoryPipeline:
    global _pipeline
    if _pipeline is None:
        logger.info("Initializing cognitive memory pipeline...")
        _pipeline = CognitiveMemoryPipeline(
            retriever_threshold=0.2,
            retriever_top_k=5,
        )
        logger.info("Pipeline ready. %d-D embeddings.", _pipeline.embedding_model.dim)
    return _pipeline


@mcp.tool()
def memory_recall(query: str, top_k: int = 5) -> str:
    """Search memory for information relevant to the query.

    Returns recalled memories formatted for context injection.
    Use this when you need to check if you have relevant prior
    information about a topic the user is asking about.

    Args:
        query: What to search memory for.
        top_k: Maximum number of memories to return.
    """
    pipeline = _get_pipeline()
    results = pipeline.recall(query, top_k=top_k)

    if not results:
        return "No relevant memories found."

    return Retriever.format_for_context(results)


@mcp.tool()
def memory_store(content: str, role: str = "user") -> str:
    """Store new information in memory.

    The system automatically extracts gist summaries, named entities,
    importance scores, and emotional valence from the content.

    Args:
        content: The text to store in memory.
        role: Who said it — "user", "assistant", "system", or "thought".
    """
    pipeline = _get_pipeline()
    pipeline.ingest(role, content)

    return f"Stored in memory. Total memories: {pipeline.memory_count}"


@mcp.tool()
def memory_recall_with_confidence(query: str, top_k: int = 5) -> str:
    """Search memory with confidence levels and partial-match hints.

    Like memory_recall, but also returns confidence level (HIGH/MODERATE/LOW/NONE)
    and any "tip of the tongue" partial matches — memories that are possibly
    related but below the retrieval threshold.

    Args:
        query: What to search memory for.
        top_k: Maximum number of memories to return.
    """
    pipeline = _get_pipeline()
    meta = pipeline.recall_with_metamemory(query, top_k=top_k)

    return MetamemoryScorer.format_for_context(meta)


@mcp.tool()
def memory_status() -> str:
    """Check the health and status of the memory system.

    Returns memory count, episodic/semantic split, and system health.
    """
    pipeline = _get_pipeline()
    health = pipeline.health()

    return json.dumps({
        "total_memories": health.total_memories,
        "episodic": health.episodic_count,
        "semantic": health.semantic_count,
        "avg_importance": round(health.avg_importance, 2),
        "avg_access_count": round(health.avg_access_count, 1),
    }, indent=2)


@mcp.tool()
def memory_consolidate() -> str:
    """Run memory consolidation — cluster similar episodic memories into semantic memories.

    This is like "sleeping on it" — the system identifies patterns across
    individual memories and creates higher-level summary memories.
    Run this periodically or when the memory count is high.
    """
    pipeline = _get_pipeline()
    new_memories = pipeline.consolidate()

    if not new_memories:
        return "No memories consolidated — not enough similar clusters found."

    summaries = [m.gist.text[:100] for m in new_memories]
    return f"Consolidated {len(new_memories)} semantic memories:\n" + "\n".join(
        f"  - {s}" for s in summaries
    )


def main():
    logging.basicConfig(level=logging.INFO, format="%(asctime)s [CMM-MCP] %(message)s")
    mcp.run(transport="stdio")


if __name__ == "__main__":
    main()
