"""Generate publication-quality figures for README and paper.

Usage:
    python docs/generate_figures.py
"""

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import matplotlib.patches as mpatches
import numpy as np
from pathlib import Path

OUT = Path(__file__).parent / "figures"
OUT.mkdir(exist_ok=True)

# Style
plt.rcParams.update({
    "font.family": "sans-serif",
    "font.size": 11,
    "axes.titlesize": 14,
    "axes.titleweight": "bold",
    "axes.labelsize": 12,
    "figure.facecolor": "white",
    "axes.facecolor": "#f8f9fa",
    "axes.grid": True,
    "grid.alpha": 0.3,
    "axes.spines.top": False,
    "axes.spines.right": False,
})

BLUE = "#2563eb"
GREEN = "#16a34a"
RED = "#dc2626"
ORANGE = "#ea580c"
PURPLE = "#7c3aed"
GRAY = "#6b7280"
LIGHT_BLUE = "#93c5fd"
LIGHT_GREEN = "#86efac"


def fig1_llm_eval_comparison():
    """Bar chart: Baseline vs Augmented across all scenarios (Opus results)."""
    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(14, 6))

    scenarios = ["Novel Fact\nRecall", "Correction\nAccuracy", "Multi-Memory\nSynthesis", "User\nPreferences"]
    baseline_kw = [17, 40, 36, 33]
    augmented_kw = [98, 100, 95, 100]
    baseline_judge = [0, 0, 0, 2]
    augmented_judge = [85, 88, 61, 80]

    x = np.arange(len(scenarios))
    w = 0.35

    # Keyword scores
    bars1 = ax1.bar(x - w/2, baseline_kw, w, label="Baseline (no memory)", color=GRAY, edgecolor="white")
    bars2 = ax1.bar(x + w/2, augmented_kw, w, label="With CMM", color=BLUE, edgecolor="white")
    ax1.set_ylabel("Keyword Score (%)")
    ax1.set_title("Keyword Accuracy: Claude Opus 4.6")
    ax1.set_xticks(x)
    ax1.set_xticklabels(scenarios)
    ax1.set_ylim(0, 120)
    ax1.set_yticks([0, 20, 40, 60, 80, 100])
    # All labels in black bold, same style
    for bar, val in zip(bars2, augmented_kw):
        ax1.text(bar.get_x() + bar.get_width()/2, bar.get_height() + 2, f"{val}%",
                ha="center", va="bottom", fontweight="bold", fontsize=10, color="black")
    for bar, val in zip(bars1, baseline_kw):
        ax1.text(bar.get_x() + bar.get_width()/2, bar.get_height() + 2, f"{val}%",
                ha="center", va="bottom", fontweight="bold", fontsize=10, color="black")
    # Legend below chart
    ax1.legend(loc="upper center", bbox_to_anchor=(0.5, -0.12), ncol=2, frameon=False)

    # LLM Judge scores
    bars3 = ax2.bar(x - w/2, baseline_judge, w, label="Baseline (no memory)", color=GRAY, edgecolor="white")
    bars4 = ax2.bar(x + w/2, augmented_judge, w, label="With CMM", color=GREEN, edgecolor="white")
    ax2.set_ylabel("LLM Judge Score (%)")
    ax2.set_title("LLM-as-Judge Accuracy: Claude Opus 4.6")
    ax2.set_xticks(x)
    ax2.set_xticklabels(scenarios)
    ax2.set_ylim(0, 120)
    ax2.set_yticks([0, 20, 40, 60, 80, 100])
    # All labels in black bold — including 0% baselines
    for bar, val in zip(bars4, augmented_judge):
        ax2.text(bar.get_x() + bar.get_width()/2, bar.get_height() + 2, f"{val}%",
                ha="center", va="bottom", fontweight="bold", fontsize=10, color="black")
    for bar, val in zip(bars3, baseline_judge):
        ax2.text(bar.get_x() + bar.get_width()/2, max(bar.get_height(), 1) + 2, f"{val}%",
                ha="center", va="bottom", fontweight="bold", fontsize=10, color="black")
    # Legend below chart
    ax2.legend(loc="upper center", bbox_to_anchor=(0.5, -0.12), ncol=2, frameon=False)

    fig.suptitle("End-to-End LLM Evaluation: Baseline vs. CMM-Augmented", fontsize=15, fontweight="bold", y=1.02)
    fig.tight_layout()
    fig.savefig(OUT / "llm_eval_comparison.png", dpi=150, bbox_inches="tight")
    print(f"  Saved: {OUT / 'llm_eval_comparison.png'}")
    plt.close()


def fig2_cross_model():
    """Bar chart: Baseline (blue) vs CMM (green) paired for each metric."""
    fig, ax = plt.subplots(figsize=(12, 5.5))

    # 4 metric groups, each with a baseline/CMM pair
    groups = [
        "Mistral 7B\nKeyword",
        "Mistral 7B\nLLM Judge",
        "Claude Opus\nKeyword",
        "Claude Opus\nLLM Judge",
    ]
    baseline = [21, 32, 31, 1]
    augmented = [82, 81, 98, 78]
    deltas = ["+61%", "+49%", "+67%", "+77%"]

    x = np.arange(len(groups))
    w = 0.35

    bars1 = ax.bar(x - w/2, baseline, w, label="Baseline (no memory)", color=GRAY, edgecolor="white")
    bars2 = ax.bar(x + w/2, augmented, w, label="With CMM", color=GREEN, edgecolor="white")

    ax.set_ylabel("Score (%)")
    ax.set_title("Memory Augmentation Benefits Both Small and Frontier Models", pad=15)
    ax.set_xticks(x)
    ax.set_xticklabels(groups)
    ax.set_ylim(0, 125)
    ax.set_yticks([0, 20, 40, 60, 80, 100])

    # Value labels — all black bold
    for bar, val in zip(bars1, baseline):
        ax.text(bar.get_x() + bar.get_width()/2, max(bar.get_height(), 1) + 2, f"{val}%",
                ha="center", va="bottom", fontweight="bold", fontsize=10, color="black")
    for bar, val in zip(bars2, augmented):
        ax.text(bar.get_x() + bar.get_width()/2, bar.get_height() + 2, f"{val}%",
                ha="center", va="bottom", fontweight="bold", fontsize=10, color="black")

    # Delta annotations between each pair
    for i, (b_bar, a_bar, delta) in enumerate(zip(bars1, bars2, deltas)):
        mid_x = (b_bar.get_x() + b_bar.get_width() + a_bar.get_x()) / 2
        top = max(augmented[i], baseline[i]) + 12
        ax.text(mid_x, top, delta, ha="center", va="bottom", fontsize=12,
                fontweight="bold", color=GREEN,
                bbox=dict(boxstyle="round,pad=0.2", facecolor="#dcfce7", edgecolor=GREEN, alpha=0.8))

    # Divider between Mistral and Opus groups
    ax.axvline(x=1.5, color="black", linestyle=":", alpha=0.3)

    # Legend below
    ax.legend(loc="upper center", bbox_to_anchor=(0.5, -0.1), ncol=2, frameon=False)

    fig.tight_layout()
    fig.savefig(OUT / "cross_model_comparison.png", dpi=150, bbox_inches="tight")
    print(f"  Saved: {OUT / 'cross_model_comparison.png'}")
    plt.close()


def fig3_spreading_activation():
    """Bar chart: Flat retrieval vs spreading activation across 5 chains."""
    fig, ax = plt.subplots(figsize=(10, 5))

    chains = ["Thornfield\n(industrial)", "Ravenswood\n(financial)", "Westbrook\n(pharma)", "Harborview\n(construction)", "Greenfield\n(espionage)"]
    flat = [1, 2, 1, 1, 3]
    spread = [4, 4, 4, 3, 4]

    x = np.arange(len(chains))
    w = 0.35

    bars1 = ax.bar(x - w/2, flat, w, label="Flat Retrieval", color=GRAY, edgecolor="white")
    bars2 = ax.bar(x + w/2, spread, w, label="Spreading Activation\n(embedding + entity linking)", color=PURPLE, edgecolor="white")

    ax.set_ylabel("Chain Cases Found (out of 4)")
    ax.set_title("Cross-Domain Investigation: 1,200 Case Files, 5 Hidden Chains")
    ax.set_xticks(x)
    ax.set_xticklabels(chains)
    ax.set_ylim(0, 5.5)
    ax.set_yticks([0, 1, 2, 3, 4])
    ax.legend(loc="upper left")
    ax.axhline(y=4, color=GREEN, linestyle="--", alpha=0.5, label="Perfect (4/4)")

    for bar, val in zip(bars1, flat):
        ax.text(bar.get_x() + bar.get_width()/2, bar.get_height() + 0.1, str(val),
                ha="center", fontsize=11, fontweight="bold", color=GRAY)
    for bar, val in zip(bars2, spread):
        ax.text(bar.get_x() + bar.get_width()/2, bar.get_height() + 0.1, str(val),
                ha="center", fontsize=11, fontweight="bold", color=PURPLE)

    # Average annotation
    avg_flat = np.mean(flat)
    avg_spread = np.mean(spread)
    ax.text(0.98, 0.95, f"Avg: {avg_flat:.1f}/4 → {avg_spread:.1f}/4 (+{avg_spread-avg_flat:.1f})",
            transform=ax.transAxes, ha="right", va="top", fontsize=11,
            bbox=dict(boxstyle="round,pad=0.3", facecolor=PURPLE, alpha=0.15))

    fig.tight_layout()
    fig.savefig(OUT / "spreading_activation.png", dpi=150, bbox_inches="tight")
    print(f"  Saved: {OUT / 'spreading_activation.png'}")
    plt.close()


def fig4_importance_scoring():
    """Diagram showing the importance scoring math for peanut allergy."""
    fig, ax = plt.subplots(figsize=(10, 3.5))
    ax.set_xlim(0, 10)
    ax.set_ylim(0, 4)
    ax.axis("off")

    # Title
    ax.text(5, 3.7, "Importance Scoring: Life-Critical Memory Recall", fontsize=14,
            fontweight="bold", ha="center", va="top")

    # Query
    ax.text(0.3, 3.0, 'Query: "I\'m ordering food for the team lunch"', fontsize=11,
            ha="left", style="italic")
    ax.text(0.3, 2.5, 'Memory: "I\'m allergic to peanuts. I carry an EpiPen."', fontsize=11,
            ha="left", style="italic")

    # Without importance
    box1 = mpatches.FancyBboxPatch((0.3, 1.3), 4.2, 0.8, boxstyle="round,pad=0.1",
                                    facecolor="#fee2e2", edgecolor=RED, linewidth=2)
    ax.add_patch(box1)
    ax.text(2.4, 1.9, "Without importance:", fontsize=10, fontweight="bold", ha="center", color=RED)
    ax.text(2.4, 1.5, "0.12 similarity → INVISIBLE (below 0.2 threshold)", fontsize=10, ha="center", color=RED)

    # With importance
    box2 = mpatches.FancyBboxPatch((5.3, 1.3), 4.4, 0.8, boxstyle="round,pad=0.1",
                                    facecolor="#dcfce7", edgecolor=GREEN, linewidth=2)
    ax.add_patch(box2)
    ax.text(7.5, 1.9, "With 2.0× importance:", fontsize=10, fontweight="bold", ha="center", color=GREEN)
    ax.text(7.5, 1.5, "0.12 × 2.0 = 0.24 → RECALLED (#1 result)", fontsize=10, ha="center", color=GREEN)

    # Arrow
    ax.annotate("", xy=(5.1, 1.7), xytext=(4.7, 1.7),
                arrowprops=dict(arrowstyle="->", lw=2, color="black"))

    # Bottom note
    ax.text(5, 0.6, "Importance scoring turned a 0.12 similarity into a safety-critical recall.\n"
            "The LLM responded: \"⚠️ IMPORTANT: You have a severe peanut allergy and carry an EpiPen.\"",
            fontsize=10, ha="center", va="center",
            bbox=dict(boxstyle="round,pad=0.4", facecolor="#eff6ff", edgecolor=BLUE, alpha=0.8))

    fig.tight_layout()
    fig.savefig(OUT / "importance_scoring.png", dpi=150, bbox_inches="tight")
    print(f"  Saved: {OUT / 'importance_scoring.png'}")
    plt.close()


def fig5_feature_comparison():
    """Table-style feature comparison with centered checks and legend at top."""
    systems = ["CMM\n(ours)", "Generative\nAgents", "MemGPT", "Standard\nRAG", "LangChain", "ChatGPT\nMemory", "Mem0"]
    features = [
        "Spreading Activation",
        "Entity Linking",
        "Priming",
        "Metamemory",
        "Grace-Period Decay",
        "Importance Scoring",
        "Consolidation",
        "Gist Compression",
        "Multi-Agent",
        "Fully Passive",
    ]

    # 1 = has, 0 = doesn't, 0.5 = partial
    data = np.array([
        [1, 0, 0, 0, 0, 0, 0],
        [1, 0, 0, 0, 0, 0, 0],
        [1, 0, 0, 0, 0, 0, 0],
        [1, 0, 0, 0, 0, 0, 0],
        [1, 1, 0, 0, 0, 0.5, 0.5],
        [1, 1, 0, 0, 0, 0, 0.5],
        [1, 1, 0, 0, 0.5, 0, 0.5],
        [1, 0, 0, 0, 0.5, 0.5, 1],
        [1, 0, 0, 0, 0, 0, 0],
        [1, 1, 0, 0, 0, 0.5, 0.5],
    ])

    n_feat = len(features)
    n_sys = len(systems)

    fig, ax = plt.subplots(figsize=(12, 6))

    # Draw table cells as rectangles with centered content
    cell_w = 1.0
    cell_h = 0.8

    color_map = {0: "#fee2e2", 0.5: "#fef3c7", 1: "#dcfce7"}
    symbol_map = {0: "✗", 0.5: "~", 1: "✓"}
    scolor_map = {0: RED, 0.5: ORANGE, 1: GREEN}

    for i in range(n_feat):
        for j in range(n_sys):
            val = data[i, j]
            rect = mpatches.FancyBboxPatch(
                (j * cell_w + 2.8, (n_feat - 1 - i) * cell_h),
                cell_w * 0.9, cell_h * 0.85,
                boxstyle="round,pad=0.05",
                facecolor=color_map[val], edgecolor="#e5e7eb", linewidth=0.5,
            )
            ax.add_patch(rect)
            ax.text(
                j * cell_w + 2.8 + cell_w * 0.45,
                (n_feat - 1 - i) * cell_h + cell_h * 0.42,
                symbol_map[val],
                ha="center", va="center", fontsize=15, fontweight="bold",
                color=scolor_map[val],
            )

    # Feature labels on the left — tight to the table
    left_edge = 1.0
    table_left = left_edge + 0.2
    for i, feat in enumerate(features):
        ax.text(table_left - 0.1, (n_feat - 1 - i) * cell_h + cell_h * 0.42, feat,
                ha="right", va="center", fontsize=10)

    # Adjust cell positions to use left_edge
    # (re-draw cells with adjusted x offset)
    ax.clear()
    ax.axis("off")
    x_offset = table_left
    for i in range(n_feat):
        for j in range(n_sys):
            val = data[i, j]
            rect = mpatches.FancyBboxPatch(
                (j * cell_w + x_offset, (n_feat - 1 - i) * cell_h),
                cell_w * 0.9, cell_h * 0.85,
                boxstyle="round,pad=0.05",
                facecolor=color_map[val], edgecolor="#e5e7eb", linewidth=0.5,
            )
            ax.add_patch(rect)
            ax.text(
                j * cell_w + x_offset + cell_w * 0.45,
                (n_feat - 1 - i) * cell_h + cell_h * 0.42,
                symbol_map[val],
                ha="center", va="center", fontsize=15, fontweight="bold",
                color=scolor_map[val],
            )

    # Feature labels
    for i, feat in enumerate(features):
        ax.text(x_offset - 0.15, (n_feat - 1 - i) * cell_h + cell_h * 0.42, feat,
                ha="right", va="center", fontsize=10)

    # System labels at the bottom
    for j, sys_name in enumerate(systems):
        ax.text(j * cell_w + x_offset + cell_w * 0.45, -0.4, sys_name,
                ha="center", va="top", fontsize=9)

    table_center = (n_sys * cell_w) / 2 + x_offset

    # Title
    ax.text(table_center, n_feat * cell_h + 0.9,
            "Feature Comparison: Cognitive Memory Systems",
            ha="center", va="center", fontsize=14, fontweight="bold")

    # Legend at top, well above the table
    legend_elements = [
        mpatches.Patch(facecolor="#dcfce7", edgecolor=GREEN, label="  Supported"),
        mpatches.Patch(facecolor="#fef3c7", edgecolor=ORANGE, label="  Partial"),
        mpatches.Patch(facecolor="#fee2e2", edgecolor=RED, label="  Not supported"),
    ]
    ax.legend(handles=legend_elements, loc="upper center",
              bbox_to_anchor=(table_center, n_feat * cell_h + 0.55),
              bbox_transform=ax.transData,
              ncol=3, frameon=False, fontsize=10,
              handlelength=1.5, handleheight=1.0)

    ax.set_xlim(-0.5, n_sys * cell_w + x_offset + 0.3)
    ax.set_ylim(-1.2, n_feat * cell_h + 1.2)
    ax.axis("off")

    fig.tight_layout()
    fig.savefig(OUT / "feature_comparison.png", dpi=150, bbox_inches="tight")
    print(f"  Saved: {OUT / 'feature_comparison.png'}")
    plt.close()


if __name__ == "__main__":
    print("Generating figures...")
    fig1_llm_eval_comparison()
    fig2_cross_model()
    fig3_spreading_activation()
    fig4_importance_scoring()
    fig5_feature_comparison()
    print(f"\nAll figures saved to {OUT}/")
