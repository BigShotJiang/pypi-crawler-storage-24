"""Demo 1: "The Investigator" — Spreading activation at scale.

A detective AI assistant has ingested 1200 case files. Hidden among them
are 5 investigation chains — cases across different domains that are
connected by a shared location, entity, or pattern. Flat retrieval
finds only the direct hit. Spreading activation discovers the full chain.

Usage:
    python -m demos.investigator
    python -m demos.investigator --backend anthropic
    python -m demos.investigator --chain Thornfield
"""

import argparse
import json
import time
from pathlib import Path

from cmm.core.types import ConversationTurn, Role
from cmm.encoding.embedding import EmbeddingModel
from cmm.pipeline.conversation import CognitiveMemoryPipeline
from cmm.retrieval.retriever import Retriever
from demos.utils.formatting import (
    BOLD, CYAN, DIM, GREEN, MAGENTA, RED, RESET, YELLOW,
    comparison, header, llm_response, memory_line, narrate, subheader,
)


CHAIN_QUERIES = {
    "Thornfield": {
        "query": "What do we know about the Thornfield Industries warehouse on Industrial Way?",
        "chain_keywords": [
            ["thornfield", "chemical residue", "warehouse", "marcus hale"],
            ["elena voss", "respiratory", "industrial way", "hospital"],
            ["nordic meridian", "riga", "shipping", "340%"],
            ["volatile organic", "toluene", "xylene", "epa"],
        ],
    },
    "Ravenswood": {
        "query": "Tell me about the property transactions at 88 Ravenswood Terrace.",
        "chain_keywords": [
            ["ravenswood", "pinnacle", "crestview", "orion", "diane kessler"],
            ["first maritime", "wire transfers", "cyprus", "helios"],
            ["assessor", "sale prices", "kessler"],
            ["delaware", "seychelles", "nominee", "kessler"],
        ],
    },
    "Westbrook": {
        "query": "What's happening at Westbrook Family Pharmacy on Maple Avenue?",
        "chain_keywords": [
            ["westbrook", "oxycodone", "340%", "leon whitfield"],
            ["terrence okafor", "pills", "maple"],
            ["sandra cho", "pain clinic", "prescriptions", "vacant lot"],
            ["postal", "priority mail", "packages", "8 states"],
        ],
    },
    "Harborview": {
        "query": "What do we know about the Harborview Towers development permit?",
        "chain_keywords": [
            ["harborview", "bp-2025", "frank novak", "castellan"],
            ["osha", "rebar", "prevailing wage", "castellan"],
            ["campaign finance", "patricia reeves", "castellan", "$47,000"],
            ["amir hassan", "reinforcing steel", "23%", "seismic"],
        ],
    },
    "Greenfield": {
        "query": "What happened at Greenfield BioTech's R&D facility?",
        "chain_keywords": [
            ["greenfield", "server room", "proclean", "4.2tb"],
            ["proclean", "natasha orlov", "st. petersburg", "$2.3m"],
            ["zhenhua", "gf-7721", "gene therapy", "rachel kim"],
            ["ice", "b-1 visas", "technology transfer", "orlov"],
        ],
    },
}


def run_investigator(backend: str = "ollama", chain_name: str | None = None):
    print(header("DEMO: The Investigator — Spreading Activation at Scale"))
    print(narrate(
        "A detective AI assistant has ingested 1,200 case files from a city's "
        "records — traffic incidents, health reports, building inspections, "
        "financial records, and more. Hidden among the noise are investigation "
        "chains: cases in completely different domains that are connected by "
        "a shared location, entity, or pattern. Can spreading activation "
        "discover what flat retrieval misses?"
    ))

    # Load cases
    data = json.loads((Path(__file__).parent / "data" / "cases.json").read_text())
    cases = data["cases"]
    chain_cases = [c for c in cases if c["is_chain"]]
    filler_cases = [c for c in cases if not c["is_chain"]]

    print(f"  {BOLD}Case files:{RESET} {len(cases)} total ({len(chain_cases)} chain, {len(filler_cases)} filler)")
    print(f"  {BOLD}Hidden chains:{RESET} {len(CHAIN_QUERIES)}")
    for name in CHAIN_QUERIES:
        print(f"    • {name}")

    # Build two pipelines: one with spreading, one without
    print(subheader("Loading Cases into Memory"))
    emb = EmbeddingModel()

    # Pipeline WITH spreading activation (depth 2 for multi-hop)
    # At 1200 memories, spreading needs wider neighbor search to find chain cases
    # that rank 20-30th among embedding-space neighbors (behind generic filler)
    pipeline_spread = CognitiveMemoryPipeline(
        embedding_model=emb,
        retriever_threshold=0.10,
        retriever_top_k=15,
        spread_depth=2,
        spread_factor=0.6,
        spread_top_k=30,
    )
    # Pipeline WITHOUT spreading (flat retrieval only)
    pipeline_flat = CognitiveMemoryPipeline(
        embedding_model=emb,
        retriever_threshold=0.10,
        retriever_top_k=15,
        spread_depth=0,
    )

    # Ingest all cases into both pipelines
    start = time.perf_counter()
    for case in cases:
        turn = ConversationTurn(role=Role.USER, content=case["text"])
        pipeline_spread.process_turn(turn)
        pipeline_flat.process_turn(turn)

    elapsed = time.perf_counter() - start
    print(f"  Ingested {len(cases)} cases into memory in {elapsed:.1f}s")
    print(f"  Memory store size: {pipeline_spread.memory_count}")

    # Set up LLM
    if backend == "anthropic":
        from benchmarks.llm_eval.anthropic_responder import AnthropicResponder
        responder = AnthropicResponder()
    else:
        from benchmarks.llm_eval.responder import OllamaResponder
        responder = OllamaResponder()

    # Run selected chains
    chains_to_test = [chain_name] if chain_name else list(CHAIN_QUERIES.keys())

    for cname in chains_to_test:
        if cname not in CHAIN_QUERIES:
            print(f"  Unknown chain: {cname}")
            continue

        chain_info = CHAIN_QUERIES[cname]
        query = chain_info["query"]
        chain_kws = chain_info["chain_keywords"]

        print(header(f"Investigation: {cname}", YELLOW))
        print(f"  {BOLD}Query:{RESET} \"{query}\"\n")

        # Build exact-match detector from actual chain case texts
        chain_case_texts = [
            c["text"][:60].lower()
            for c in cases
            if c.get("chain", "") and cname.lower() in c.get("chain", "").lower()
        ]

        def is_chain_case(text):
            return any(ct in text.lower() for ct in chain_case_texts)

        # --- Flat retrieval (standard top-5, what a normal system would use) ---
        print(subheader("Step 1: Direct Query (flat retrieval, top-5)"))
        flat_results = pipeline_flat.recall(query, top_k=5)

        flat_chain_prefixes = set()
        for r in flat_results:
            if is_chain_case(r.memory.gist.text):
                flat_chain_prefixes.add(r.memory.gist.text[:60].lower())
        flat_chain_hits = len(flat_chain_prefixes)

        print(f"  Retrieved {len(flat_results)} memories from {pipeline_flat.memory_count} total")
        print(f"  Chain cases found: {BOLD}{flat_chain_hits}/{len(chain_kws)}{RESET}\n")

        for r in flat_results[:8]:
            marker = f"{GREEN}★ CHAIN{RESET}" if is_chain_case(r.memory.gist.text) else f"{DIM}  filler{RESET}"
            print(f"  {marker} score={r.final_score:.3f}  {r.memory.gist.text[:75]}...")

        # --- Spreading activation — trace the chain explicitly ---
        print(subheader("Step 2: Spreading Activation — Following the Chain"))
        print(narrate(
            "Starting from the direct hit, spreading activation queries FAISS "
            "with each discovered memory's embedding to find its neighbors. "
            "This traces associative links across domains."
        ))

        # Find the chain seed in flat results
        chain_seed = None
        for r in flat_results:
            if any(kw.lower() in r.memory.gist.text.lower() for kw in chain_kws[0]):
                chain_seed = r
                break

        if chain_seed:
            # Manually trace the spreading chain for visualization
            from cmm.core.types import RetrievalResult
            all_chain_found = [chain_seed]
            seen_ids = {chain_seed.memory.id}

            print(f"  {GREEN}★ Seed:{RESET} score={chain_seed.final_score:.3f}")
            print(f"    {chain_seed.memory.gist.text[:90]}...\n")

            # Hop 1: neighbors of the seed
            hop1_results = pipeline_spread.store.retrieve(
                chain_seed.memory.embedding, top_k=30, threshold=-1.0
            )
            hop1_chain = []
            print(f"  {CYAN}Hop 1:{RESET} Searching neighbors of the seed ({len(hop1_results)} candidates)...")
            for nr in hop1_results:
                if nr.memory.id in seen_ids:
                    continue
                if is_chain_case(nr.memory.gist.text):
                    hop1_chain.append(nr)
                    seen_ids.add(nr.memory.id)
                    print(f"    {GREEN}★ FOUND:{RESET} sim={nr.raw_similarity:.3f}  {nr.memory.gist.text[:75]}...")
                    all_chain_found.append(nr)

            if not hop1_chain:
                print(f"    {DIM}No additional chain cases in the top 30 neighbors{RESET}")

            # Hop 2: neighbors of ALL found chain cases
            hop2_sources = list(hop1_chain)
            # Also try from the seed itself with wider search
            hop2_sources.append(chain_seed)
            for hop_src in hop2_sources:
                hop2_results = pipeline_spread.store.retrieve(
                    hop_src.memory.embedding, top_k=50, threshold=-1.0
                )
                for nr in hop2_results:
                    if nr.memory.id in seen_ids:
                        continue
                    if is_chain_case(nr.memory.gist.text):
                        seen_ids.add(nr.memory.id)
                        src_text = hop_src.memory.gist.text[:40]
                        print(f"\n  {CYAN}Hop 2:{RESET} From '{src_text}...'")
                        print(f"    {GREEN}★ FOUND:{RESET} sim={nr.raw_similarity:.3f}  {nr.memory.gist.text[:75]}...")
                        all_chain_found.append(nr)

            # Deduplicate by text prefix (same case may appear with different memory IDs)
            unique_chain_texts = set()
            deduped_chain = []
            for r in all_chain_found:
                prefix = r.memory.gist.text[:60].lower()
                if prefix not in unique_chain_texts:
                    unique_chain_texts.add(prefix)
                    deduped_chain.append(r)
            all_chain_found = deduped_chain
            spread_chain_hits = len(all_chain_found)
            print(f"\n  {BOLD}Chain cases discovered: {spread_chain_hits}/{len(chain_kws)}{RESET}")
            newly_found = spread_chain_hits - flat_chain_hits
            if newly_found > 0:
                print(f"  {GREEN}{BOLD}Spreading activation discovered +{newly_found} case(s) that flat retrieval missed!{RESET}")
        else:
            all_chain_found = []
            spread_chain_hits = flat_chain_hits

        # --- LLM Synthesis ---
        print(subheader("Step 3: LLM Investigation Brief"))
        print(narrate(
            "The LLM receives all memories discovered through spreading activation "
            "and synthesizes an investigation brief — connecting evidence across "
            "domains that no single query could have found."
        ))

        # Build context from all chain cases found + some supporting results
        all_found_ids = {r.memory.id for r in all_chain_found}
        combined_results = list(all_chain_found)
        for r in flat_results:
            if r.memory.id not in all_found_ids:
                combined_results.append(r)
        combined_results.sort(key=lambda r: r.final_score, reverse=True)

        context = Retriever.format_for_context(combined_results[:15])
        brief = responder.respond(
            query,
            context=(
                "You are a detective AI assistant analyzing city case files. "
                "You have recalled potentially related cases from different domains "
                "(building inspections, health reports, shipping records, environmental "
                "data, financial records, etc.). Look for connections and patterns "
                "across these cases. If you see a potential investigation thread, "
                "lay it out clearly with the evidence from each case.\n\n" + context
            ),
        )
        print(llm_response(brief, f"Investigation Brief: {cname}"))

        # Comparison
        print(f"\n  {BOLD}Impact:{RESET}")
        print(f"    Flat retrieval found {RED}{flat_chain_hits}/{len(chain_kws)}{RESET} chain cases")
        print(f"    Spreading activation found {GREEN}{spread_chain_hits}/{len(chain_kws)}{RESET} chain cases")
        if newly_found > 0:
            print(f"    {GREEN}{BOLD}+{newly_found} cases discovered through associative memory{RESET}")

    # === Summary ===
    print(header("Demo Summary"))
    print(narrate(
        "Spreading activation traverses the embedding space from the initial "
        "retrieval results, discovering related cases that a direct query "
        "would never find. In a store of 1,200 cases, flat retrieval returns "
        "only the obvious matches. Spreading activation follows the associative "
        "links — warehouse inspection → health complaints nearby → suspicious "
        "shipping patterns → environmental readings — building a complete "
        "investigation brief from scattered evidence."
    ))
    print(f"  {BOLD}Key numbers:{RESET}")
    print(f"    Cases in store: {pipeline_spread.memory_count}")
    print(f"    Spreading depth: 2 hops")
    print(f"    Retrieval latency: ~2-5ms per query")
    print()


def main():
    parser = argparse.ArgumentParser(description="Demo: The Investigator")
    parser.add_argument("--backend", "-b", choices=["ollama", "anthropic"],
                        default="ollama", help="LLM backend")
    parser.add_argument("--chain", "-c", choices=list(CHAIN_QUERIES.keys()),
                        default=None, help="Run a specific chain (default: all)")
    args = parser.parse_args()
    run_investigator(backend=args.backend, chain_name=args.chain)


if __name__ == "__main__":
    main()
