"""Demo 2: "Tip of the Tongue" — Metamemory in action.

A technical support scenario where a user describes a recurring problem
using different vocabulary than the original conversation. The memory
scores below the retrieval threshold — but metamemory detects a partial
match and surfaces a hint. This hint primes the memory, and on the
follow-up turn, the memory is fully recalled.

Usage:
    python -m demos.tip_of_tongue
    python -m demos.tip_of_tongue --backend anthropic
"""

import argparse
import time

from benchmarks.llm_eval.responder import OllamaResponder
from cmm.encoding.embedding import EmbeddingModel
from cmm.pipeline.conversation import CognitiveMemoryPipeline
from cmm.retrieval.metamemory import MetamemoryScorer
from cmm.retrieval.retriever import Retriever
from demos.utils.formatting import (
    comparison, header, llm_response, memory_line, narrate, subheader,
    score_breakdown, BOLD, DIM, GREEN, RED, YELLOW, CYAN, RESET,
)


def run_tip_of_tongue(backend: str = "ollama"):
    print(header("DEMO: Tip of the Tongue — Metamemory in Action"))
    print(narrate(
        "A user has been working with an AI assistant for weeks. Three weeks "
        "ago, they had a painful debugging session involving Docker container "
        "OOM crashes. The conversation was detailed and specific. Today, the "
        "user encounters what might be the same problem — but describes it "
        "using completely different words."
    ))

    # Set up pipeline with a retrieval threshold of 0.3
    emb = EmbeddingModel()
    pipeline = CognitiveMemoryPipeline(
        embedding_model=emb,
        retriever_threshold=0.3,
        priming_boost=0.3,
        priming_decay=0.3,
    )

    # === Phase 1: Build up conversation history ===
    print(header("Phase 1: Three Weeks Ago — The Debugging Session"))
    print(narrate(
        "The user had an extended debugging session. The conversation was "
        "detailed and technical, using specific Docker/Kubernetes terminology."
    ))

    week_ago_turns = [
        ("user", "The Docker container keeps crashing with OOM errors after deploying to the staging cluster. I increased the memory limit to 4GB but it still happens."),
        ("assistant", "OOM errors with a 4GB limit suggest a memory leak rather than insufficient allocation. Let me help you investigate."),
        ("user", "We traced it to a memory leak in the image processing service. It allocates buffers for each incoming image but never releases them."),
        ("assistant", "Classic unbounded buffer growth. You'll need to implement a buffer pool or add explicit cleanup after each image is processed."),
        ("user", "I fixed it by adding a context manager that releases the image buffers after each batch. Memory usage is stable now at around 1.2GB."),
        ("assistant", "Good fix. The context manager pattern ensures cleanup even if an exception occurs during processing."),
    ]

    for role, content in week_ago_turns:
        pipeline.ingest(role, content)
        if role == "user":
            print(f"  {BOLD}User:{RESET} {content[:90]}...")

    # Add 2 weeks of filler conversations (simulate time passing)
    print(subheader("Two Weeks of Other Conversations..."))
    filler_topics = [
        "How do I set up a CI/CD pipeline with GitHub Actions?",
        "Can you help me write unit tests for my authentication module?",
        "What's the best way to handle database migrations in production?",
        "I need to optimize my SQL queries for the reporting dashboard.",
        "How do I implement rate limiting in my Express.js API?",
        "Can you review my Terraform configuration for AWS?",
        "I'm having trouble with CORS headers in my React frontend.",
        "What's the difference between gRPC and REST for microservices?",
        "How do I set up monitoring with Prometheus and Grafana?",
        "Can you help me design the schema for our event sourcing system?",
        "I need to implement retry logic with exponential backoff.",
        "How do I configure Nginx as a reverse proxy?",
        "What's the best approach for handling file uploads in Python?",
        "Can you explain the circuit breaker pattern?",
        "I'm implementing a message queue with RabbitMQ.",
        "How do I handle database connection pooling in Python?",
        "What are the best practices for API versioning?",
        "I need help with my Kubernetes ingress configuration.",
        "Can you help me set up structured logging?",
        "How do I implement feature flags in my application?",
    ]
    for topic in filler_topics:
        pipeline.ingest("user", topic)
        pipeline.ingest("assistant", f"Sure, I can help with that. Let me explain...")

    print(f"  {DIM}(20 unrelated conversations ingested — {pipeline.memory_count} total memories){RESET}\n")

    # === Phase 2: The Vague Recall Attempt ===
    print(header("Phase 2: Today — The Vague Query"))
    print(narrate(
        "The user encounters a similar problem. But they describe it using "
        "completely different vocabulary — no mention of 'Docker', 'OOM', "
        "'container', or 'staging cluster'. They say:"
    ))

    vague_query = "My application is running out of resources on the server after we push changes. It's that image handling component acting up again."
    print(f"\n  {BOLD}User:{RESET} \"{vague_query}\"\n")

    # Standard retrieval (threshold 0.3) — should return nothing
    print(subheader("Standard Retrieval (threshold 0.3)"))
    results = pipeline.recall(vague_query)

    if results:
        relevant = [r for r in results if "docker" in r.memory.gist.text.lower()
                    or "oom" in r.memory.gist.text.lower()
                    or "image processing" in r.memory.gist.text.lower()]
        if relevant:
            print(f"  {RED}Standard retrieval found the Docker memory.{RESET}")
            for r in relevant:
                print(memory_line(r.memory.gist.text, score=r.final_score))
        else:
            print(f"  {DIM}Retrieved {len(results)} results, but none about the Docker issue.{RESET}")
            for r in results[:3]:
                print(f"  {DIM}  score: {r.final_score:.3f} — {r.memory.gist.text[:70]}...{RESET}")
    else:
        print(f"  {RED}No results above threshold.{RESET}")

    # === Phase 3: Metamemory to the Rescue ===
    print(subheader("Metamemory Retrieval"))
    print(narrate(
        "But the metamemory layer detects a partial match — a memory that "
        "scored above the partial-match threshold (0.2) but below the "
        "retrieval threshold (0.3). This is the 'tip of the tongue' signal."
    ))

    meta = pipeline.recall_with_metamemory(vague_query)

    print(f"  Confidence: {BOLD}{meta.confidence.value}{RESET}")
    print(f"  Strong matches: {len(meta.results)}")
    print(f"  Partial matches: {len(meta.partial_matches)}")
    print(f"  Tip of the tongue: {BOLD}{meta.has_tip_of_tongue}{RESET}")

    if meta.partial_matches:
        print(f"\n  {YELLOW}{BOLD}Partial matches (\"I think I recall something...\"):{RESET}")
        for pm in meta.partial_matches[:5]:
            print(memory_line(
                pm.memory.gist.text,
                score=pm.final_score,
                emotion=pm.memory.emotion or "",
            ))
            print()

    # Show what the LLM does with the metamemory hint
    print(subheader("LLM Response — With Metamemory Hint"))

    context = MetamemoryScorer.format_for_context(meta)

    if backend == "anthropic":
        from benchmarks.llm_eval.anthropic_responder import AnthropicResponder
        responder = AnthropicResponder()
    else:
        responder = OllamaResponder()

    # Without memory
    baseline = responder.respond(vague_query)
    print(f"  {RED}{BOLD}Without memory:{RESET}")
    print(llm_response(baseline, "Baseline (no memory)"))

    # With metamemory context
    augmented = responder.respond(
        vague_query,
        context=(
            "You are helping a user with a recurring technical issue. "
            "Your memory search returned the following. Note that partial matches "
            "are low-confidence hints — something you vaguely recall that might be related. "
            "If you have partial matches, mention that you think you recall something "
            "similar and ask if it's related.\n\n" + context
        ),
    )
    print(f"  {GREEN}{BOLD}With metamemory hint:{RESET}")
    print(llm_response(augmented, "With Metamemory"))

    # === Phase 4: The Follow-Up (Priming Rescues the Memory) ===
    print(header("Phase 3: The Follow-Up — Priming Rescues the Memory"))
    print(narrate(
        "The user confirms the connection. Now the system queries again — "
        "and the priming boost from the previous partial match pushes the "
        "memory above threshold. What was a vague hint becomes a full recall."
    ))

    followup = "Yes! That's exactly what I mean — the Docker container issue from before. What did we find out about it?"
    print(f"\n  {BOLD}User:{RESET} \"{followup}\"\n")

    # The follow-up query uses Docker vocabulary, so it should match well
    followup_results = pipeline.recall(followup, top_k=5)

    print(subheader("Retrieval Results (after priming)"))
    if followup_results:
        for r in followup_results:
            priming_boost = pipeline.retriever.priming.get_boost(r.memory.id)
            print(memory_line(
                r.memory.gist.text,
                score=r.final_score,
                emotion=r.memory.emotion or "",
            ))
            if priming_boost > 1.0:
                print(f"    {GREEN}↑ priming boost: {priming_boost:.2f}x{RESET}")
            print()

    # LLM response with full recall
    full_context = Retriever.format_for_context(followup_results)
    full_response = responder.respond(
        followup,
        context=(
            "The user is referencing a previous technical issue. You now have "
            "strong recall of the relevant memories. Provide a detailed answer "
            "that references the specific details from memory.\n\n" + full_context
        ),
    )
    print(llm_response(full_response, "Full Recall Response"))

    # === Summary ===
    print(header("Demo Summary"))
    print(narrate(
        "The metamemory system detected a partial match that standard retrieval "
        "missed. Instead of saying 'I don't know,' the LLM said 'I think I "
        "recall something related...' This hint prompted the user to confirm "
        "the connection, and on the follow-up, priming + better vocabulary "
        "produced full recall of the entire debugging session."
    ))

    print(f"  {BOLD}Key cognitive features demonstrated:{RESET}")
    print(f"    1. {CYAN}Metamemory:{RESET} Partial match detected at score ~0.25 (below 0.3 threshold)")
    print(f"    2. {CYAN}Tip of the tongue:{RESET} Low-confidence hint surfaced to the LLM")
    print(f"    3. {CYAN}Priming:{RESET} Partial match primed related memories for the follow-up")
    print(f"    4. {CYAN}Full recall:{RESET} Follow-up query retrieved the complete debugging history")
    print(f"\n  {DIM}No other LLM memory system implements metamemory or priming.{RESET}\n")


def main():
    parser = argparse.ArgumentParser(description="Demo: Tip of the Tongue")
    parser.add_argument("--backend", "-b", choices=["ollama", "anthropic"],
                        default="ollama", help="LLM backend")
    args = parser.parse_args()
    run_tip_of_tongue(backend=args.backend)


if __name__ == "__main__":
    main()
