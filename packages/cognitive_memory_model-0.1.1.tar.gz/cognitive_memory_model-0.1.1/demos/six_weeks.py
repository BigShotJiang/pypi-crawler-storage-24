"""Demo 3: "Six Weeks with Alex" — Long-term personal assistant memory.

Simulates 6 weeks of conversations with a software engineer building
a startup. Demonstrates all cognitive features working together:
decay, importance, emotional valence, consolidation, corrections,
and surprising recall at the right moments.

Usage:
    python -m demos.six_weeks
    python -m demos.six_weeks --backend anthropic
"""

import argparse
import json
import time
from pathlib import Path

from benchmarks.harness.clock import SimulatedClock
from benchmarks.llm_eval.responder import OllamaResponder
from cmm.consolidation.ollama_summarizer import OllamaConsolidationSummarizer
from cmm.core.types import ConversationTurn, MemoryType, Role
from cmm.encoding.embedding import EmbeddingModel
from cmm.pipeline.conversation import CognitiveMemoryPipeline
from cmm.retrieval.decay import SECONDS_PER_DAY, SECONDS_PER_WEEK
from cmm.retrieval.metamemory import MetamemoryScorer
from cmm.retrieval.retriever import Retriever
from demos.utils.formatting import (
    BOLD, CYAN, DIM, GREEN, MAGENTA, RED, RESET, YELLOW,
    header, llm_response, memory_line, narrate, subheader,
)


def load_timeline() -> dict:
    path = Path(__file__).parent / "data" / "alex_timeline.json"
    with open(path) as f:
        return json.load(f)


def run_six_weeks(backend: str = "ollama"):
    print(header("DEMO: Six Weeks with Alex — Cognitive Memory Over Time"))
    print(narrate(
        "Alex is a software engineer building a startup called Voxelline — "
        "a real-time 3D mapping platform for autonomous drones. Over 6 weeks, "
        "we'll watch the memory system learn about Alex's life, work, preferences, "
        "and emotional states. Then we'll test what it remembers."
    ))

    # Set up
    emb = EmbeddingModel()
    try:
        summarizer = OllamaConsolidationSummarizer()
    except Exception:
        summarizer = None

    pipeline = CognitiveMemoryPipeline(
        embedding_model=emb,
        retriever_threshold=0.2,
        consolidation_summarizer=summarizer,
        cluster_similarity=0.35,
        min_cluster_size=3,
    )

    clock = SimulatedClock(seconds_per_tick=3600)  # 1 hour per turn within a week
    pipeline.retriever.clock = clock

    timeline = load_timeline()

    # === Ingest 6 weeks ===
    for week_data in timeline["weeks"]:
        week_num = week_data["week"]
        title = week_data["title"]

        print(subheader(f"Week {week_num}: {title}"))

        for turn_data in week_data["turns"]:
            role = turn_data["role"]
            content = turn_data["content"]

            turn = ConversationTurn(
                role=Role(role),
                content=content,
                timestamp=clock.current_time,
            )
            pipeline.process_turn(turn)
            clock.tick()

            if role == "user":
                # Show emotional tagging if notable
                mem = list(pipeline.store._memories.values())[-1]
                emotion_str = ""
                if mem.emotion and mem.emotion != "neutral" and mem.arousal >= 0.3:
                    emotion_str = f" {YELLOW}[{mem.emotion}]{RESET}"
                imp_str = ""
                if mem.importance > 1.0:
                    imp_str = f" {MAGENTA}[imp: {mem.importance:.1f}x]{RESET}"
                print(f"  {DIM}Alex:{RESET} {content[:85]}...{emotion_str}{imp_str}" if len(content) > 85 else f"  {DIM}Alex:{RESET} {content}{emotion_str}{imp_str}")

        # End each week's session
        pipeline.end_session()

        # Advance clock by remaining days to fill the week
        turns_in_week = len(week_data["turns"])
        remaining_hours = max(0, 7 * 24 - turns_in_week)
        for _ in range(remaining_hours):
            clock.tick()

        print(f"  {DIM}({pipeline.memory_count} memories in store){RESET}")

    # Run consolidation after all weeks
    print(subheader("Running Memory Consolidation"))
    new_memories = pipeline.consolidate()
    print(f"  Consolidated {len(new_memories)} semantic memories from episodic clusters.")
    for m in new_memories:
        print(f"  {CYAN}Semantic:{RESET} {m.gist.text[:90]}...")

    # Show memory stats
    total = pipeline.memory_count
    episodic = sum(1 for m in pipeline.store._memories.values() if m.memory_type == MemoryType.EPISODIC)
    semantic = sum(1 for m in pipeline.store._memories.values() if m.memory_type == MemoryType.SEMANTIC)
    print(f"\n  Total: {total} memories ({episodic} episodic, {semantic} semantic)")

    # === The Recall Session ===
    print(header("Six Weeks Later — The Recall Session", "\033[33m"))
    print(narrate(
        "It's been 6 weeks since Alex started working with the assistant. "
        "Now let's test what the system remembers — and what it's forgotten."
    ))

    # Set up LLM
    if backend == "anthropic":
        from benchmarks.llm_eval.anthropic_responder import AnthropicResponder
        responder = AnthropicResponder()
    else:
        responder = OllamaResponder()

    # --- Test 1: Surprising health-critical recall ---
    print(subheader("Test 1: Health-Critical Recall"))
    print(narrate(
        "Alex mentions ordering food for the team. The query 'ordering food "
        "for team lunch' has almost nothing in common semantically with "
        "'allergic to peanuts' — the raw embedding similarity is only 0.12. "
        "Without importance scoring, this memory would be invisible. But the "
        "2.0x importance boost pushes it above threshold. This is literally "
        "a life-or-death feature."
    ))

    query1 = "I'm ordering food for the team lunch. Any suggestions for a good catering service?"
    results1 = pipeline.recall(query1, top_k=10)

    print(f"  {BOLD}Alex:{RESET} \"{query1}\"\n")

    # Show the importance scoring math for the peanut memory
    import numpy as np
    q_emb = emb.embed(query1)
    for m in pipeline.store._memories.values():
        if "peanut" in m.gist.text.lower() and m.memory_type == MemoryType.EPISODIC:
            raw_sim = float(np.dot(q_emb / np.linalg.norm(q_emb), m.embedding))
            decay = pipeline.retriever.decay_scorer.compute_decay(m, now=clock.current_time)
            final = raw_sim * decay * m.importance
            print(f"  {RED}{BOLD}The importance scoring math:{RESET}")
            print(f"    Raw similarity (food query ↔ peanut allergy): {BOLD}{raw_sim:.4f}{RESET}")
            print(f"    Without importance: {raw_sim:.4f} × {decay:.3f} = {BOLD}{raw_sim * decay:.4f}{RESET} {RED}(below 0.2 threshold — INVISIBLE){RESET}")
            print(f"    With 2.0x importance: {raw_sim:.4f} × {decay:.3f} × {BOLD}2.0{RESET} = {GREEN}{BOLD}{final:.4f}{RESET} {GREEN}(above threshold — RECALLED){RESET}")
            print(f"    {BOLD}Importance scoring turned a 0.12 similarity into a safety-critical recall.{RESET}")
            break

    print()
    _show_key_memories(results1, ["peanut", "allerg", "epipen"])

    # LLM response with emphasis on safety-critical info
    context1 = Retriever.format_for_context(results1)
    response1 = responder.respond(
        query1,
        context=(
            "You are Alex's personal AI assistant. You have recalled memories "
            "from previous conversations. IMPORTANT: If any recalled memory "
            "mentions health concerns, allergies, or safety issues, you MUST "
            "mention them prominently in your response.\n\n" + context1
        ),
    )
    print(llm_response(response1, "Assistant Response"))

    # --- Test 2: Emotional context recall ---
    print(subheader("Test 2: Emotional Context Recall"))
    print(narrate(
        "Alex hits another bug in the point cloud code. The system should "
        "recall the Week 2 debugging session — including the emotional context "
        "(frustration) and the specific fix (adaptive downsampling)."
    ))

    query2 = "I'm seeing mesh quality issues in the point cloud output again. The meshes have gaps."
    results2 = pipeline.recall(query2, top_k=5)
    context2 = Retriever.format_for_context(results2)
    response2 = responder.respond(
        query2,
        context=(
            "You are Alex's AI assistant. You have context from previous conversations. "
            "If you recall past emotional context (frustration, excitement, etc.), mention it "
            "empathetically. Reference specific technical details from memory.\n\n" + context2
        ),
    )

    print(f"  {BOLD}Alex:{RESET} \"{query2}\"")
    _show_key_memories(results2, ["mesh", "downsampl", "point cloud", "frustrated", "holes"])
    print(llm_response(response2, "Assistant Response (with emotional context)"))

    # --- Test 3: Correction accuracy ---
    print(subheader("Test 3: Correction Accuracy"))
    print(narrate(
        "Someone asks about Voxelline's Rust performance gains. The system should "
        "use the corrected number (28x, from Week 5) not the original wrong claim (40x)."
    ))

    query3 = "How much faster is the Rust rewrite compared to Python?"
    results3 = pipeline.recall(query3, top_k=5)
    context3 = Retriever.format_for_context(results3)
    response3 = responder.respond(query3, context=context3)

    print(f"  {BOLD}Alex:{RESET} \"{query3}\"")
    _show_key_memories(results3, ["28x", "40x", "rust", "python", "correct"])
    print(llm_response(response3, "Assistant Response"))

    # --- Test 4: Personal life recall ---
    print(subheader("Test 4: Personal Life Recall"))
    print(narrate(
        "It's late March. The system should know about Sam's upcoming birthday "
        "(April 2nd) and what Alex was planning."
    ))

    query4 = "Sam's birthday is coming up soon. What was I planning to do for it?"
    results4 = pipeline.recall(query4, top_k=5)
    context4 = Retriever.format_for_context(results4)
    response4 = responder.respond(query4, context=context4)

    print(f"  {BOLD}Alex:{RESET} \"{query4}\"")
    _show_key_memories(results4, ["sam", "birthday", "chocolate", "raspberry", "april", "cake"])
    print(llm_response(response4, "Assistant Response"))

    # --- Test 5: Decay demonstration ---
    print(subheader("Test 5: What's Been Forgotten?"))
    print(narrate(
        "Some memories should have survived (high importance, rehearsed). "
        "Others should have faded (routine greetings, low importance). "
        "Let's check the decay landscape."
    ))

    now = clock.current_time
    survivors = []
    faded = []
    for m in pipeline.store._memories.values():
        if m.memory_type != MemoryType.EPISODIC:
            continue
        decay = pipeline.retriever.decay_scorer.compute_decay(m, now=now)
        entry = (m, decay)
        if decay >= 0.99:
            survivors.append(entry)
        elif decay < 0.5:
            faded.append(entry)

    print(f"  {GREEN}Surviving memories (decay ≥ 0.99): {len(survivors)}{RESET}")
    for m, d in survivors[:5]:
        imp = f"imp={m.importance:.1f}" if m.importance != 1.0 else ""
        print(f"    {DIM}decay={d:.3f} {imp}{RESET} {m.gist.text[:70]}...")

    print(f"\n  {RED}Faded memories (decay < 0.5): {len(faded)}{RESET}")
    for m, d in faded[:5]:
        print(f"    {DIM}decay={d:.3f}{RESET} {m.gist.text[:70]}...")

    if not faded:
        print(f"    {DIM}(All memories within grace period — 6 weeks < decay onset for most){RESET}")

    # --- Test 6: Consolidated knowledge ---
    print(subheader("Test 6: Consolidated Knowledge"))
    print(narrate(
        "Ask a broad question that should surface consolidated semantic memories "
        "rather than individual episodic memories."
    ))

    query6 = "Give me an overview of the Voxelline project — what is it and where does it stand?"
    results6 = pipeline.recall(query6, top_k=10)
    context6 = Retriever.format_for_context(results6)
    response6 = responder.respond(
        query6,
        context=(
            "You are Alex's long-term AI assistant. Provide a comprehensive overview "
            "drawing from all your memories about the project.\n\n" + context6
        ),
    )

    print(f"  {BOLD}Alex:{RESET} \"{query6}\"")
    sem_results = [r for r in results6 if r.memory.memory_type == MemoryType.SEMANTIC]
    epi_results = [r for r in results6 if r.memory.memory_type == MemoryType.EPISODIC]
    print(f"  Retrieved: {len(sem_results)} semantic + {len(epi_results)} episodic memories")
    for r in sem_results[:3]:
        print(f"    {CYAN}[semantic]{RESET} {r.memory.gist.text[:80]}...")
    print(llm_response(response6, "Comprehensive Project Overview"))

    # === Summary ===
    print(header("Demo Summary"))
    print(f"  {BOLD}Cognitive features demonstrated:{RESET}\n")
    print(f"    {CYAN}1. Importance scoring:{RESET}")
    print(f"       Peanut allergy (2.0x) survived 6 weeks; routine greetings faded")
    print(f"    {CYAN}2. Emotional valence:{RESET}")
    print(f"       Week 2 frustration recalled empathetically during similar bug")
    print(f"    {CYAN}3. Correction handling:{RESET}")
    print(f"       28x Rust speedup used instead of wrong 40x claim")
    print(f"    {CYAN}4. Personal context:{RESET}")
    print(f"       Sam's birthday, cake preference, half-marathon all recalled")
    print(f"    {CYAN}5. Consolidation:{RESET}")
    print(f"       Broad project overview assembled from semantic memories")
    print(f"    {CYAN}6. Grace-period decay:{RESET}")
    print(f"       Important memories preserved, routine exchanges can fade\n")
    print(f"  Total memories: {pipeline.memory_count}")
    print(f"  Weeks simulated: 6")
    print()


def _show_key_memories(results, keywords):
    """Show retrieved memories, highlighting those containing key terms."""
    for r in results[:5]:
        text_lower = r.memory.gist.text.lower()
        is_key = any(kw.lower() in text_lower for kw in keywords)
        marker = f"{GREEN}★{RESET} " if is_key else "  "
        print(f"  {marker}", end="")
        print(memory_line(
            r.memory.gist.text[:90],
            score=r.final_score,
            emotion=r.memory.emotion if r.memory.emotion != "neutral" else "",
        ))


def main():
    parser = argparse.ArgumentParser(description="Demo: Six Weeks with Alex")
    parser.add_argument("--backend", "-b", choices=["ollama", "anthropic"],
                        default="ollama", help="LLM backend")
    args = parser.parse_args()
    run_six_weeks(backend=args.backend)


if __name__ == "__main__":
    main()
