"""Generate 1200+ fictional case files for the Investigator demo.

Creates a city's worth of incident reports across 15+ categories,
with 5 hidden investigation chains embedded in the noise.
Each chain has 4 linked cases that share a geographic/entity connection
but are in completely different domains.

Run this to regenerate: python -m demos.data.generate_cases
"""

import json
import random
from pathlib import Path

random.seed(42)

# Street names for the city
STREETS = [
    "Oak Street", "Maple Avenue", "Cedar Boulevard", "Pine Road", "Elm Drive",
    "Birch Lane", "Willow Court", "Ash Way", "Spruce Circle", "Hazel Street",
    "River Road", "Harbor Drive", "Market Street", "Main Avenue", "Park Boulevard",
    "Industrial Way", "Commerce Drive", "Factory Road", "Union Street", "Liberty Avenue",
    "Summit Drive", "Valley Road", "Highland Avenue", "Lakeside Boulevard", "Ridge Lane",
]

FIRST_NAMES = [
    "James", "Maria", "David", "Sarah", "Michael", "Lisa", "Robert", "Jennifer",
    "Thomas", "Emily", "Daniel", "Anna", "Carlos", "Nina", "Ahmed", "Yuki",
    "Peter", "Elena", "Marcus", "Fatima", "Wei", "Olga", "Raj", "Sofia",
]

LAST_NAMES = [
    "Chen", "Rodriguez", "Patel", "Kim", "Mueller", "Santos", "Yamamoto", "Okonkwo",
    "Johansson", "Ali", "Petrov", "Singh", "Anderson", "Nakamura", "Fernandez", "Walsh",
    "Kowalski", "Dubois", "Rivera", "Thompson", "Volkov", "Tanaka", "Martinez", "Jensen",
]

BUSINESSES = [
    "Summit Café", "Riverside Deli", "Golden Dragon", "Blue Moon Bar", "Metro Fitness",
    "Harbor Books", "Parkside Pharmacy", "Valley Auto Repair", "Cedar Tech Solutions",
    "Maple Leaf Bakery", "Highland Dental", "Lakeside Laundry", "Ridge Hardware",
    "Oak Street Market", "Birch Grove Daycare", "Elm Street Comics", "Willow Spa",
    "Pine Road Pizza", "Spruce Electronics", "Hazel Street Flowers",
    "Copper Kettle Pub", "Northside Grocery", "Eastview Medical", "Sunset Nails",
    "Ironworks Gym", "Shoreline Seafood", "Crossroads Diner", "Beacon Hill Books",
    "Atlas Coffee Roasters", "Crescent Moon Thai", "Diamond Cuts Barber", "Falcon Auto Body",
    "Green Leaf Organics", "Horizon Dry Cleaners", "Junction Brewing", "Keystone Tavern",
    "Liberty Bell Deli", "Monarch Theaters", "Neptune Aquarium Supply", "Orion Optics",
    "Pacific Rim Sushi", "Quartz Jewelry Studio", "Redwood Wine Bar", "Silverstone Motors",
    "Trident Marine Supply", "Urban Roots Garden Center", "Vanguard Security Systems",
    "Westwind Surf Shop", "Xenon Arcade", "Yellowstone Outfitters", "Zenith Yoga Studio",
]


def random_name():
    return f"{random.choice(FIRST_NAMES)} {random.choice(LAST_NAMES)}"


def random_address():
    return f"{random.randint(100, 9999)} {random.choice(STREETS)}"


def random_business():
    return random.choice(BUSINESSES)


# ============================================================
# HIDDEN INVESTIGATION CHAINS
# Each chain: 4 cases in different domains, linked by location/entity
# ============================================================

CHAINS = [
    {
        "name": "Thornfield Industrial Contamination",
        "description": "Chemical processing operation hidden in a warehouse",
        "cases": [
            {
                "category": "building_inspection",
                "text": "Routine inspection of the Thornfield Industries warehouse at 4200 Industrial Way. Inspector found chemical residue on the loading dock floor and unusual ventilation modifications. Owner Marcus Hale was not present. Building passed structural inspection but environmental concerns were flagged for follow-up.",
            },
            {
                "category": "health_report",
                "text": "Dr. Elena Voss at St. Margaret's Hospital reported a cluster of seven patients from the Industrial Way corridor presenting with unexplained respiratory symptoms including chronic coughing and throat irritation. All patients live or work within three blocks of 4200 Industrial Way. Blood work pending.",
            },
            {
                "category": "shipping_records",
                "text": "Port Authority flagged Nordic Meridian Logistics for irregular shipping patterns. The company has increased container shipments from Riga, Latvia to their distribution point near Industrial Way by 340% since January. Manifests list contents as 'industrial cleaning supplies' but weight ratios are inconsistent with declared goods.",
            },
            {
                "category": "environmental",
                "text": "Environmental monitoring station EM-7 near Industrial Way recorded elevated volatile organic compound levels for the past 90 days. Peak readings occur between 11pm and 4am. Concentrations of toluene and xylene exceed EPA threshold limits by a factor of 3.2. Station is located 200 meters from the Thornfield Industries facility.",
            },
        ],
    },
    {
        "name": "Ravenswood Financial Fraud",
        "description": "Money laundering through real estate and shell companies",
        "cases": [
            {
                "category": "real_estate",
                "text": "Unusual property transaction at 88 Ravenswood Terrace. Property sold three times in 14 months, each time at a 40% markup, cycling between Pinnacle Holdings LLC, Crestview Partners, and Orion Asset Group. Current assessed value is $2.1M but last sale price was $4.8M. All three companies share the same registered agent: attorney Diane Kessler.",
            },
            {
                "category": "banking",
                "text": "Compliance officer at First Maritime Bank flagged account activity for Pinnacle Holdings LLC. The account receives large wire transfers from a Cyprus-based entity called Helios Ventures, then immediately distributes funds to 12 different residential mortgage payments across the metro area. Monthly volume: approximately $890,000.",
            },
            {
                "category": "tax_records",
                "text": "City assessor's office noted that properties at 88 Ravenswood Terrace, 142 Summit Drive, and 305 Harbor Drive are all assessed at values 60-70% below their recent sale prices. All three properties are held by entities registered to the same address: 1200 Commerce Drive Suite 400, which is the office of attorney Diane Kessler.",
            },
            {
                "category": "corporate_registry",
                "text": "Secretary of State records show that Crestview Partners, Pinnacle Holdings LLC, and Orion Asset Group were all incorporated within the same week in Delaware. All three list nominee directors based in the Seychelles. The companies' operating agreements were drafted by Kessler & Associates at 1200 Commerce Drive.",
            },
        ],
    },
    {
        "name": "Westbrook Prescription Ring",
        "description": "Organized prescription drug diversion network",
        "cases": [
            {
                "category": "pharmacy",
                "text": "Westbrook Family Pharmacy at 777 Maple Avenue has dispensed 340% more oxycodone prescriptions than the county average for the past quarter. Pharmacist Leon Whitfield has been the sole dispensing pharmacist for 89% of these prescriptions. State Board of Pharmacy was notified.",
            },
            {
                "category": "traffic_stop",
                "text": "Officer Daniels conducted a traffic stop on a vehicle with expired tags at Maple Avenue and 8th Street. Driver Terrence Okafor had 47 individually packaged pills in the center console, later identified as oxycodone 30mg. Okafor stated he obtained them from 'a pharmacy on Maple.' Released pending lab confirmation and warrant.",
            },
            {
                "category": "medical_board",
                "text": "Medical board received complaints about Dr. Sandra Cho at the Lakeview Pain Clinic. Analysis shows Dr. Cho wrote 156 oxycodone prescriptions last month, with 78% of them filled at a single pharmacy on Maple Avenue. Twelve of her patients share the same listed address at 450 Elm Drive, which is a vacant lot.",
            },
            {
                "category": "postal_service",
                "text": "US Postal Inspector flagged a high volume of Priority Mail packages originating from the Maple Avenue post office branch. Sender analysis shows 23 packages per week shipped by individuals matching names on Westbrook Family Pharmacy customer lists. Destinations span 8 states. Average declared value: $25 per package.",
            },
        ],
    },
    {
        "name": "Harborview Construction Corruption",
        "description": "Rigged bidding and unsafe construction practices",
        "cases": [
            {
                "category": "permits",
                "text": "Building permit BP-2025-4471 for the Harborview Towers development at 500 Harbor Drive was approved despite three failed structural engineering reviews. Permit was signed by Deputy Inspector Frank Novak, overriding the review panel's recommendation to deny. Developer is Castellan Construction, owned by Victor Castellan.",
            },
            {
                "category": "labor_complaint",
                "text": "OSHA received anonymous complaint about Castellan Construction's Harborview Towers project at 500 Harbor Drive. Workers report being told to skip rebar installation in non-load-bearing walls to save time. Complainant also alleges workers are being paid below prevailing wage and threatened with termination for raising safety concerns.",
            },
            {
                "category": "campaign_finance",
                "text": "Campaign finance records show Victor Castellan and his wife donated $47,000 to City Councilmember Patricia Reeves' re-election campaign. Castellan Construction also hired Reeves' son, Bryan Reeves, as a 'community liaison' at $120,000 annual salary. Councilmember Reeves sits on the Building Standards Committee that oversees permit appeals.",
            },
            {
                "category": "engineering",
                "text": "Independent structural engineer Dr. Amir Hassan, hired by the Harborview Towers homeowners association, found that 500 Harbor Drive has 23% less reinforcing steel than required by code. His report states the building 'presents a significant risk of partial collapse in a seismic event exceeding magnitude 5.0.' City inspector Frank Novak declined to comment.",
            },
        ],
    },
    {
        "name": "Greenfield Data Theft",
        "description": "Corporate espionage through a cleaning company",
        "cases": [
            {
                "category": "corporate_security",
                "text": "Greenfield BioTech at 600 Summit Drive reported unauthorized access to their R&D server room. Security badge logs show after-hours entry by cleaning staff from ProClean Services using a master access card. No equipment was stolen, but network logs show 4.2TB of data was copied to an external device between 2am and 4am over three consecutive nights.",
            },
            {
                "category": "business_license",
                "text": "ProClean Services LLC, registered at 1847 Valley Road, obtained cleaning contracts with 14 biotech and pharmaceutical companies in the Summit Drive technology corridor in the past 18 months. Company owner Natasha Orlov previously worked as a research scientist in St. Petersburg, Russia. Business license application listed annual revenue of $180,000 but bank deposits total $2.3M.",
            },
            {
                "category": "patent_filing",
                "text": "Patent office flagged a suspicious filing by Zhenhua Pharmaceutical (Shenzhen) for a gene therapy compound remarkably similar to Greenfield BioTech's unpublished GF-7721 candidate. The Zhenhua filing was submitted 6 weeks after the security breach at 600 Summit Drive. Greenfield's chief scientist Dr. Rachel Kim confirmed the compounds are 'virtually identical in mechanism.'",
            },
            {
                "category": "immigration",
                "text": "ICE investigation found that three ProClean Services employees who had badge access to Greenfield BioTech are persons of interest in a technology transfer investigation. All three entered the US on B-1 business visas but are employed full-time. Their visa applications were sponsored by a consulting firm linked to Natasha Orlov's previous employer in St. Petersburg.",
            },
        ],
    },
]


# ============================================================
# FILLER CASE TEMPLATES
# ============================================================

FILLER_TEMPLATES = {
    "traffic": [
        "Vehicle collision at {addr}. {name1}'s {vehicle1} struck {name2}'s {vehicle2} at the intersection. Minor injuries reported. {name1} cited for failure to yield.",
        "Hit and run at {addr}. Witness reports a {color} {vehicle1} struck a parked car and fled southbound. Partial plate: {plate}. Damage estimated at ${damage}.",
        "DUI checkpoint at {addr}. {name1} arrested for driving under the influence. BAC measured at 0.{bac}. Vehicle impounded.",
    ],
    "noise": [
        "Noise complaint at {addr}. Resident {name1} reports excessive {noise_type} noise from neighboring unit after 11pm. Third complaint this month.",
        "Construction noise violation at {addr}. {business} operating heavy equipment outside permitted hours (before 7am). Fine issued: ${fine}.",
    ],
    "theft": [
        "Shoplifting report at {business} on {street}. Store employee observed {name1} concealing ${value} worth of merchandise. Suspect fled on foot heading {direction}.",
        "Vehicle break-in reported at {addr}. {name1}'s car window smashed, laptop and backpack stolen. No security camera coverage at location.",
        "Package theft at {addr}. {name1} reports {count} packages stolen from porch over the past two weeks. Ring camera footage shows {description}.",
    ],
    "vandalism": [
        "Graffiti reported on the south wall of {business} at {addr}. Tags appear to match the '{tag}' crew active in the {district} district.",
        "Vehicle vandalism at {addr}. {name1}'s car had all four tires slashed overnight. Fourth similar incident on {street} this month.",
    ],
    "health_inspection": [
        "Routine health inspection at {business}. Score: {score}/100. Violations: {violations}. Follow-up inspection scheduled in {days} days.",
        "Food safety complaint at {business} on {street}. Customer {name1} reported finding a foreign object in their meal. Inspector dispatched.",
    ],
    "fire": [
        "Residential fire at {addr}. {rooms}-story home, fire originated in {origin}. {people} occupants evacuated safely. Estimated damage: ${damage}.",
        "Grease fire at {business} on {street}. Kitchen suppression system activated. No injuries. Restaurant closed for {days} days pending inspection.",
    ],
    "domestic": [
        "Welfare check at {addr} requested by neighbor {name2}. Resident {name1} reports a verbal dispute with {relation}. No physical altercation. Resources provided.",
    ],
    "animal": [
        "Stray dog reported at {addr}. Large {breed} breed, no collar or tags. Animal control dispatched. Dog was friendly and taken to county shelter.",
        "Animal noise complaint at {addr}. {name1} reports neighbor's {animal} barking continuously for {hours} hours. Warning issued.",
    ],
    "parking": [
        "Illegal parking complaint at {addr}. {count} vehicles blocking fire hydrant access. Citations issued to {count} vehicles.",
        "Abandoned vehicle at {addr}. {color} {vehicle1} with expired registration, appears to have been stationary for {weeks} weeks. Marked for tow.",
    ],
    "utility": [
        "Water main break at {addr}. {size}-inch main, affecting {blocks} blocks. Emergency repair crew dispatched. Estimated repair time: {hours} hours.",
        "Power outage reported on {street}. {count} residences affected. Cause: {cause}. Utility company ETA: {hours} hours.",
    ],
    "missing_person": [
        "{name1}, age {age}, reported missing from {addr}. Last seen {time} wearing {clothing}. {desc}. Contact Detective {name2} with information.",
    ],
    "fraud": [
        "{name1} at {addr} reports receiving suspicious calls from someone claiming to be from {agency}. Caller demanded payment of ${amount} via gift cards.",
        "Identity theft report by {name1}. Unauthorized credit card opened in their name at {bank}. Charges totaling ${amount} at various online retailers.",
    ],
}

VEHICLES = ["sedan", "SUV", "pickup truck", "minivan", "hatchback", "coupe"]
COLORS = ["red", "blue", "black", "white", "silver", "green", "gray"]
DIRECTIONS = ["north", "south", "east", "west"]
NOISE_TYPES = ["music", "construction", "party", "machinery", "dog barking"]
BREEDS = ["German Shepherd", "Labrador", "Pit Bull mix", "Husky", "Golden Retriever"]
ANIMALS = ["dog", "dogs", "rooster", "parrot"]
ORIGINS = ["kitchen", "garage", "electrical panel", "dryer", "fireplace"]
RELATIONS = ["roommate", "partner", "family member"]
VIOLATIONS = [
    "improper food storage temperature",
    "evidence of pest activity",
    "expired food items in cooler",
    "handwashing station not accessible",
    "grease buildup on exhaust hood",
]
CAUSES = ["fallen tree branch on power line", "transformer failure", "vehicle struck utility pole", "scheduled maintenance overrun"]
AGENCIES = ["the IRS", "Social Security Administration", "Medicare", "the county sheriff"]
BANKS = ["Chase Bank", "Bank of America", "Wells Fargo", "Capital One"]
DISTRICTS = ["downtown", "westside", "harbor", "midtown", "university"]
TAGS = ["KRON", "BLAZE", "VOID", "ECHO", "ZERO"]
CLOTHING = [
    "a blue jacket and jeans", "a red hoodie and black pants",
    "a gray coat and khakis", "a green t-shirt and shorts",
]
DESCS = [
    "Has a distinctive tattoo on left forearm",
    "Walks with a slight limp",
    "May be carrying a black backpack",
    "Known to frequent local parks",
]


def generate_filler():
    category = random.choice(list(FILLER_TEMPLATES.keys()))
    template = random.choice(FILLER_TEMPLATES[category])

    return template.format(
        addr=random_address(),
        name1=random_name(),
        name2=random_name(),
        business=random_business(),
        street=random.choice(STREETS),
        vehicle1=random.choice(VEHICLES),
        vehicle2=random.choice(VEHICLES),
        color=random.choice(COLORS),
        plate=f"{random.choice('ABCDEFGHJKLMNPRSTUVWXYZ')}{random.choice('ABCDEFGHJKLMNPRSTUVWXYZ')}{random.randint(1,9)}-{random.randint(100,999)}",
        damage=random.randint(500, 15000),
        bac=random.randint(8, 19),
        noise_type=random.choice(NOISE_TYPES),
        fine=random.choice([250, 500, 750, 1000]),
        value=random.randint(20, 500),
        direction=random.choice(DIRECTIONS),
        count=random.randint(2, 6),
        description="a person in dark clothing approaching the porch",
        tag=random.choice(TAGS),
        district=random.choice(DISTRICTS),
        score=random.randint(55, 98),
        violations=random.choice(VIOLATIONS),
        days=random.randint(7, 30),
        rooms=random.choice([1, 2, 2, 3]),
        origin=random.choice(ORIGINS),
        people=random.randint(1, 6),
        relation=random.choice(RELATIONS),
        breed=random.choice(BREEDS),
        animal=random.choice(ANIMALS),
        hours=random.randint(1, 12),
        blocks=random.randint(2, 8),
        size=random.choice([4, 6, 8, 12]),
        weeks=random.randint(2, 8),
        cause=random.choice(CAUSES),
        age=random.randint(14, 85),
        time=random.choice(["yesterday evening", "this morning", "two days ago", "last seen Friday"]),
        clothing=random.choice(CLOTHING),
        desc=random.choice(DESCS),
        agency=random.choice(AGENCIES),
        amount=random.randint(500, 10000),
        bank=random.choice(BANKS),
    )


def generate_all():
    cases = []
    case_id = 1

    # Insert chain cases at random positions among filler
    chain_cases = []
    for chain in CHAINS:
        for i, case in enumerate(chain["cases"]):
            chain_cases.append({
                "id": f"chain_{chain['name'].split()[0].lower()}_{i+1}",
                "chain": chain["name"],
                "category": case["category"],
                "text": case["text"],
                "is_chain": True,
                "chain_position": i,
            })

    # Generate unique filler
    filler_cases = []
    seen_texts = set()
    attempts = 0
    while len(filler_cases) < 1180 and attempts < 5000:
        text = generate_filler()
        attempts += 1
        if text in seen_texts:
            continue
        seen_texts.add(text)
        filler_cases.append({
            "id": f"case_{case_id:04d}",
            "chain": None,
            "category": "general",
            "text": text,
            "is_chain": False,
            "chain_position": None,
        })
        case_id += 1

    # Interleave chain cases into filler at distributed positions
    all_cases = list(filler_cases)
    for i, cc in enumerate(chain_cases):
        # Spread chain cases throughout the list
        pos = min(len(all_cases), 50 + i * 55 + random.randint(0, 30))
        all_cases.insert(pos, cc)

    # Reassign sequential IDs
    for i, case in enumerate(all_cases):
        if not case["is_chain"]:
            case["id"] = f"case_{i+1:04d}"

    return all_cases, CHAINS


if __name__ == "__main__":
    cases, chains = generate_all()
    output_path = Path(__file__).parent / "cases.json"
    with open(output_path, "w") as f:
        json.dump({"cases": cases, "chains": [c["name"] for c in chains]}, f, indent=2)
    print(f"Generated {len(cases)} cases ({sum(1 for c in cases if c['is_chain'])} chain, {sum(1 for c in cases if not c['is_chain'])} filler)")
    print(f"Chains: {[c['name'] for c in chains]}")
    print(f"Saved to {output_path}")
