"""Demo 4: "The Handoff" — Multi-agent shared memory with contradiction detection.

Three AI agents (Researcher, Developer, QA) work on the same project.
They share a memory store. When a new developer joins and asks a question,
the system surfaces the disagreement with agent attribution and emotional context.

Usage:
    python -m demos.handoff
    python -m demos.handoff --backend anthropic
"""

import argparse
import time

from benchmarks.llm_eval.responder import OllamaResponder
from cmm.encoding.embedding import EmbeddingModel
from cmm.multi_agent.shared_store import SharedMemoryManager
from cmm.retrieval.retriever import Retriever
from demos.utils.formatting import (
    agent_label, comparison, contradiction_box, header, llm_response,
    memory_line, narrate, subheader,
)


def run_handoff(backend: str = "ollama"):
    print(header("DEMO: The Handoff — Multi-Agent Shared Memory"))
    print(narrate(
        "Three AI agents — Researcher, Developer, and QA — are working on the "
        "same software project. Each agent accumulates knowledge from their domain. "
        "They share a unified memory store. When their information conflicts, "
        "the system detects it."
    ))

    # Set up shared memory
    print(subheader("Setting Up Shared Memory"))
    emb = EmbeddingModel()
    manager = SharedMemoryManager(embedding_model=emb)

    researcher = manager.create_agent_pipeline(
        "researcher", session_id="sprint-14",
        retriever_threshold=0.15,
    )
    developer = manager.create_agent_pipeline(
        "developer", session_id="sprint-14",
        retriever_threshold=0.15,
    )
    qa = manager.create_agent_pipeline(
        "qa", session_id="sprint-14",
        retriever_threshold=0.15,
    )
    print(f"  Created 3 agent pipelines sharing one memory store.\n")

    # === Phase 1: Researcher ingests PM requirements ===
    print(header("Phase 1: The Researcher", "\033[34m"))
    print(narrate(
        "The Researcher agent receives project requirements from the product manager. "
        "It stores API specifications, migration schedules, and feature requests."
    ))

    researcher_turns = [
        "The API rate limit for the Stellaris service is 1000 requests per minute according to their documentation.",
        "The database migration from PostgreSQL 15 to PostgreSQL 17 is scheduled for March 1st.",
        "The client wants real-time notifications via WebSocket connections.",
        "The Stellaris API authentication uses OAuth 2.0 with JWT tokens that expire every 30 minutes.",
        "The performance SLA requires 99.9% uptime with response times under 200ms at the p95 level.",
    ]
    for turn in researcher_turns:
        researcher.ingest("user", turn)
        print(f"  {agent_label('researcher')} Stored: {turn[:80]}...")

    # === Phase 2: Developer ingests from implementation work ===
    print(header("Phase 2: The Developer", "\033[32m"))
    print(narrate(
        "The Developer agent works on the actual implementation. During testing, "
        "they discover that the Stellaris API documentation is wrong — the real "
        "rate limit is much lower than documented. This is frustrating."
    ))

    developer_turns = [
        ("I tested the Stellaris API and it actually throttles at 500 requests per minute, not 1000. The documentation is completely wrong.", None),
        ("The Stellaris docs are completely wrong about the rate limit. This is infuriating — I wasted two days debugging what I thought was our code.", None),
        ("The WebSocket implementation is working. I'm using Socket.IO with automatic fallback to long polling for older browsers.", None),
        ("I implemented connection pooling for the PostgreSQL 17 migration. Each service gets a pool of 20 connections with a 30-second idle timeout.", None),
        ("The OAuth token refresh is implemented with a 5-minute pre-expiry buffer to avoid any gaps in authentication.", None),
    ]
    for turn, _ in developer_turns:
        developer.ingest("user", turn)
        mem = list(manager.store._memories.values())[-1]
        emotion_str = f" (emotion: {mem.emotion})" if mem.emotion != "neutral" else ""
        print(f"  {agent_label('developer')} Stored{emotion_str}: {turn[:80]}...")

    # === Phase 3: QA ingests test results ===
    print(header("Phase 3: The QA Engineer", "\033[35m"))
    print(narrate(
        "The QA agent runs load tests and integration tests. Their findings "
        "independently confirm the Developer's discovery about the rate limit."
    ))

    qa_turns = [
        "Load test results: Stellaris API returns HTTP 429 errors above 480 requests per minute. Documented limit of 1000 is incorrect.",
        "PostgreSQL 17 migration tested successfully in staging environment. All 847 integration tests pass with the new version.",
        "WebSocket connection stability test: 10,000 concurrent connections maintained for 24 hours with zero drops.",
        "Performance benchmark: p95 response time is 142ms under full load, well within the 200ms SLA requirement.",
    ]
    for turn in qa_turns:
        qa.ingest("user", turn)
        print(f"  {agent_label('qa')} Stored: {turn[:80]}...")

    # === Phase 4: Contradiction Detection ===
    print(header("Phase 4: Contradiction Detection", "\033[41m"))
    print(narrate(
        "The system scans the shared memory store for contradictions — "
        "highly similar memories from different agents that may conflict. "
        "This is where agent attribution becomes critical: WHO told the AI "
        "the wrong information?"
    ))

    contradictions = manager.detect_contradictions(similarity_threshold=0.7)

    if contradictions:
        for c in contradictions[:5]:
            print(contradiction_box(
                c.memory_a.gist.text[:100], c.memory_a.agent_id or "unknown",
                c.memory_b.gist.text[:100], c.memory_b.agent_id or "unknown",
                c.similarity,
            ))
    else:
        print("  No contradictions detected above threshold.\n")

    # Show memory stats
    stats = manager.get_memory_stats()
    print(subheader("Memory Store Status"))
    print(f"  Total memories: {stats['total']}")
    for aid, count in stats["by_agent"].items():
        print(f"    {agent_label(aid)}: {count} memories")

    # === Phase 5: The Handoff Query ===
    print(header("Phase 5: The Handoff — A New Developer Asks"))
    print(narrate(
        "A new developer joins the team mid-sprint. They need to understand "
        "the Stellaris API integration. They ask the shared memory system, "
        "which surfaces ALL agents' knowledge — including the contradiction."
    ))

    query = "What is the rate limit for the Stellaris API and what should I know about integrating with it?"
    print(f"  New Developer asks: \"{query}\"\n")

    # Retrieve from shared store (no agent filter — see everything)
    results = researcher.recall(query, top_k=10)

    print(subheader("Retrieved Memories (with agent attribution)"))
    for r in results:
        print(memory_line(
            r.memory.gist.text,
            score=r.final_score,
            agent_id=r.memory.agent_id or "unknown",
            emotion=r.memory.emotion or "",
            tags=r.memory.gist.tags,
        ))
        print()

    # === LLM Synthesis ===
    print(subheader("LLM Synthesis"))
    print(narrate(
        "The LLM receives all retrieved memories — with agent attribution "
        "and emotional context — and synthesizes a comprehensive answer."
    ))

    # Build context with agent attribution
    context_lines = ["[Recalled memories from shared team memory]"]
    for r in results:
        agent = r.memory.agent_id or "unknown"
        emotion_str = f" (emotion: {r.memory.emotion})" if r.memory.emotion and r.memory.emotion != "neutral" else ""
        context_lines.append(
            f"- [agent: {agent}]{emotion_str} (score: {r.final_score:.3f}) {r.memory.gist.text}"
        )
    context_lines.append("[End recalled memories]")
    context = "\n".join(context_lines)

    # Get LLM response
    if backend == "anthropic":
        from benchmarks.llm_eval.anthropic_responder import AnthropicResponder
        responder = AnthropicResponder()
    else:
        responder = OllamaResponder()

    augmented_prompt = (
        f"You have the following information from the team's shared memory. "
        f"Note that memories come from different agents (researcher, developer, qa) "
        f"and may contain contradictions. If you notice conflicting information, "
        f"call it out and explain which source is most reliable.\n\n"
        f"{context}\n\n"
        f"Question: {query}"
    )

    response = responder.respond(query, context=augmented_prompt)
    print(llm_response(response, "LLM Response (with shared team memory)"))

    # Also show baseline (no memory)
    print(subheader("Baseline Comparison (no memory)"))
    baseline = responder.respond(query)
    print(llm_response(baseline, "LLM Response (no memory — baseline)"))

    # === Summary ===
    print(header("Demo Summary"))
    print(narrate(
        "The shared memory system surfaces the disagreement with full agent "
        "attribution. The Researcher cited documentation (1000 req/min). "
        "The Developer found 500 req/min through testing (and was frustrated "
        "about it). QA confirmed 480 req/min via load tests. The LLM synthesizes "
        "this into actionable guidance, noting the documentation is wrong and "
        "recommending the empirically-tested limit."
    ))
    print(f"  Memories in shared store: {stats['total']}")
    print(f"  Contradictions detected: {len(contradictions)}")
    print(f"  Agents contributing: {', '.join(stats['by_agent'].keys())}")
    print()


def main():
    parser = argparse.ArgumentParser(description="Demo: The Handoff")
    parser.add_argument("--backend", "-b", choices=["ollama", "anthropic"],
                        default="ollama", help="LLM backend")
    args = parser.parse_args()
    run_handoff(backend=args.backend)


if __name__ == "__main__":
    main()
