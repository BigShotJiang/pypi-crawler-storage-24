"""Rich terminal output formatting for demos."""

import textwrap

# ANSI color codes
BOLD = "\033[1m"
DIM = "\033[2m"
RED = "\033[31m"
GREEN = "\033[32m"
YELLOW = "\033[33m"
BLUE = "\033[34m"
MAGENTA = "\033[35m"
CYAN = "\033[36m"
WHITE = "\033[37m"
RESET = "\033[0m"
BG_RED = "\033[41m"
BG_GREEN = "\033[42m"
BG_BLUE = "\033[44m"


def header(text: str, color: str = CYAN) -> str:
    width = 72
    return (
        f"\n{color}{BOLD}{'═' * width}\n"
        f"  {text}\n"
        f"{'═' * width}{RESET}\n"
    )


def subheader(text: str, color: str = YELLOW) -> str:
    return f"\n{color}{BOLD}── {text} ──{RESET}\n"


def narrate(text: str) -> str:
    """Narrative text — italic-style dim text for story pacing."""
    wrapped = textwrap.fill(text, width=70)
    return f"\n{DIM}{wrapped}{RESET}\n"


def agent_label(agent_id: str) -> str:
    """Colored label for an agent."""
    colors = {
        "researcher": BLUE,
        "developer": GREEN,
        "qa": MAGENTA,
    }
    color = colors.get(agent_id, WHITE)
    return f"{color}{BOLD}[{agent_id}]{RESET}"


def memory_line(text: str, score: float = 0, agent_id: str = "",
                emotion: str = "", tags: list[str] | None = None) -> str:
    """Format a single memory for display."""
    parts = []
    if score:
        parts.append(f"{DIM}score:{RESET} {BOLD}{score:.3f}{RESET}")
    if agent_id:
        parts.append(agent_label(agent_id))
    if emotion and emotion != "neutral":
        emotion_color = RED if emotion in ("frustrated", "angry", "distressed") else GREEN
        parts.append(f"{emotion_color}({emotion}){RESET}")
    if tags:
        parts.append(f"{DIM}[{', '.join(tags[:5])}]{RESET}")

    meta = " ".join(parts)
    wrapped = textwrap.fill(text, width=64, subsequent_indent="    ")
    return f"  {meta}\n    {wrapped}"


def comparison(label_a: str, text_a: str, label_b: str, text_b: str) -> str:
    """Side-by-side comparison of two results."""
    lines = [
        f"\n{RED}{BOLD}  ✗ {label_a}{RESET}",
        textwrap.fill(f"    {text_a}", width=70, subsequent_indent="    "),
        f"\n{GREEN}{BOLD}  ✓ {label_b}{RESET}",
        textwrap.fill(f"    {text_b}", width=70, subsequent_indent="    "),
    ]
    return "\n".join(lines)


def contradiction_box(mem_a_text: str, agent_a: str,
                      mem_b_text: str, agent_b: str,
                      similarity: float) -> str:
    """Format a contradiction detection result."""
    return (
        f"\n{BG_RED}{BOLD} ⚠ CONTRADICTION DETECTED (similarity: {similarity:.3f}) {RESET}\n"
        f"  {agent_label(agent_a)} {mem_a_text}\n"
        f"  {agent_label(agent_b)} {mem_b_text}\n"
    )


def llm_response(text: str, label: str = "LLM Response") -> str:
    """Format an LLM response in a box."""
    wrapped = textwrap.fill(text, width=66, subsequent_indent="  ")
    return (
        f"\n{CYAN}┌{'─' * 68}┐{RESET}\n"
        f"{CYAN}│{RESET} {BOLD}{label}{RESET}\n"
        f"{CYAN}│{RESET} {wrapped}\n"
        f"{CYAN}└{'─' * 68}┘{RESET}\n"
    )


def score_breakdown(raw_sim: float, decay: float, importance: float,
                    priming: float, final: float, emotion: str = "") -> str:
    """Show the scoring formula breakdown."""
    parts = [
        f"  {DIM}sim={RESET}{raw_sim:.3f}",
        f"{DIM}× decay={RESET}{decay:.3f}",
        f"{DIM}× imp={RESET}{importance:.1f}",
        f"{DIM}× prime={RESET}{priming:.2f}",
        f"{DIM}→{RESET} {BOLD}{final:.3f}{RESET}",
    ]
    if emotion and emotion != "neutral":
        parts.append(f"  {DIM}emotion:{RESET} {emotion}")
    return " ".join(parts)
