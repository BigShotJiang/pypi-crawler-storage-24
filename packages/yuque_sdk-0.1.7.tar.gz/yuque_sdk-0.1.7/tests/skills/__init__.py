"""Tests for skill modules."""
