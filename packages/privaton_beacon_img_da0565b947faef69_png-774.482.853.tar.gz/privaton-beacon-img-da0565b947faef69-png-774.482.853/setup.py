from setuptools import setup
setup(name='privaton-beacon-img-da0565b947faef69-png', version='774.482.853', py_modules=['data'])
