## 环境

- Python 3.11+
- uv 包管理器

## 安装依赖

```bash
uv sync
```

## 配置

```bash
# 复制环境变量示例
cp env.example .env

# 编辑 .env 文件，填入UBox配置
# UBOX_SECRET_ID=your_secret_id
# UBOX_SECRET_KEY=your_secret_key
# UBOX_MODE=local
```

## 测试

```bash
uv run python src/ubox_mcp_server/client_example.py
```

## 打包与分发

```bash
# 构建 wheel 包（用于给用户安装）
uv build
# 产物：dist/ubox_mcp_server-<version>-py3-none-any.whl
```

## 代码入口

- 服务器入口：`src/ubox_mcp_server/server.py`（`main()`）
- 业务封装：`src/ubox_mcp_server/ubox_handler.py`
- 设备管理：`src/ubox_mcp_server/device_manager.py`

