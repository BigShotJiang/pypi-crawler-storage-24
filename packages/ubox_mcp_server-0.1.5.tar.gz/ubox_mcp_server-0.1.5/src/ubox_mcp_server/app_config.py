#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
UBox MCP服务器应用配置管理

用于管理MCP服务器的各种配置参数
支持从命令行参数、环境变量、.env文件加载配置
"""

import os
import argparse
from dotenv import load_dotenv
from typing import Dict, Any, Optional


class AppConfig:
    """应用配置管理类"""
    
    def __init__(self):
        """初始化配置"""
        # 定义参数默认值和必填性
        self.params_meta = {
            # MCP服务器运行模式
            "mcp_mode": {"required": False, "type": str, "default": "stdio"},
            "mcp_host": {"required": False, "type": str, "default": "localhost"},
            "mcp_port": {"required": False, "type": int, "default": 8000},
            
            # 日志配置
            "log_level": {"required": False, "type": str, "default": "INFO"},
            "log_to_file": {"required": False, "type": bool, "default": False},
        }
        
        # 加载配置
        self.config = self._load_all_configs()
        
        # 验证配置
        self._validate_config()
    
    def _load_cli_args(self) -> Dict[str, Any]:
        """从命令行参数获取配置"""
        parser = argparse.ArgumentParser()
        parser.add_argument("--mcp-mode", help="MCP服务器运行模式 (stdio/sse/streamable-http)")
        parser.add_argument("--mcp-host", help="MCP服务器主机地址")
        parser.add_argument("--mcp-port", help="MCP服务器端口")
        
        parser.add_argument("--log-level", help="日志级别 (DEBUG/INFO/WARNING/ERROR)")
        parser.add_argument("--log-to-file", help="是否将日志写入文件")
        
        args, _ = parser.parse_known_args()
        
        return {
            "mcp_mode": args.mcp_mode if hasattr(args, 'mcp_mode') and args.mcp_mode else None,
            "mcp_host": args.mcp_host if hasattr(args, 'mcp_host') and args.mcp_host else None,
            "mcp_port": args.mcp_port if hasattr(args, 'mcp_port') and args.mcp_port else None,
            "log_level": args.log_level if hasattr(args, 'log_level') and args.log_level else None,
            "log_to_file": args.log_to_file if hasattr(args, 'log_to_file') and args.log_to_file else None,
        }
    
    def _load_env_vars(self) -> Dict[str, Any]:
        """从环境变量获取配置"""
        return {
            "mcp_mode": os.getenv("MCP_MODE"),
            "mcp_host": os.getenv("MCP_HOST"),
            "mcp_port": os.getenv("MCP_PORT"),
            
            "log_level": os.getenv("LOG_LEVEL"),
            "log_to_file": os.getenv("LOG_TO_FILE"),
        }
    
    def _load_dotenv(self) -> Dict[str, Any]:
        """从 .env 文件获取配置"""
        load_dotenv()
        return self._load_env_vars()  # 复用环境变量加载逻辑
    
    def _merge_configs(self, *config_sources) -> Dict[str, Any]:
        """按优先级合并配置源（命令行参数 > 环境变量 > .env文件）"""
        merged = {}
        for source in config_sources:
            for param, value in source.items():
                if value is not None and merged.get(param) is None:
                    merged[param] = value
        return merged
    
    def _type_cast(self, raw_config: Dict[str, Any]) -> Dict[str, Any]:
        """类型转换和验证"""
        processed = {}
        for param, meta in self.params_meta.items():
            raw_value = raw_config.get(param)
            
            # 应用默认值（当未配置且允许默认值时）
            if raw_value is None and not meta["required"]:
                processed[param] = meta["default"]
                continue
            
            # 必填参数校验
            if meta["required"] and raw_value is None:
                raise ValueError(f"参数 {param} 为必填项！")
            
            # 类型转换
            try:
                if meta["type"] == bool:
                    # 处理布尔类型（支持 true/1/yes）
                    processed[param] = str(raw_value).lower() in ("true", "1", "yes")
                else:
                    processed[param] = meta["type"](raw_value)
            except (ValueError, TypeError):
                raise TypeError(f"参数 {param} 类型错误，期望 {meta['type'].__name__}")
        
        return processed
    
    def _load_all_configs(self) -> Dict[str, Any]:
        """加载并合并所有配置源"""
        # 按优先级加载配置（从高到低）
        cli_config = self._load_cli_args()
        env_config = self._load_env_vars()
        dotenv_config = self._load_dotenv()
        
        # 合并配置
        merged_raw = self._merge_configs(
            cli_config, env_config, dotenv_config
        )
        
        # 类型转换和验证
        return self._type_cast(merged_raw)
    
    def _validate_config(self):
        """验证配置参数"""
        valid_modes = ["sse", "streamable-http", "stdio"]
        mcp_mode = self.config.get("mcp_mode")
        if mcp_mode not in valid_modes:
            raise ValueError(
                f"无效的MCP模式: {mcp_mode}，支持的模式: {', '.join(valid_modes)}"
            )
        
        mcp_port = self.config.get("mcp_port")
        if not isinstance(mcp_port, int) or mcp_port <= 0 or mcp_port > 65535:
            raise ValueError(f"无效的端口号: {mcp_port}")
    
    def get(self, param_name: str) -> Optional[Any]:
        """获取配置项"""
        return self.config.get(param_name)
    
    def __getattr__(self, name: str) -> Any:
        """支持属性式访问（config.mode）"""
        if name == "mode":
            return self.config.get("mcp_mode")
        elif name == "host":
            return self.config.get("mcp_host")
        elif name == "port":
            return self.config.get("mcp_port")
        elif name in self.config:
            return self.config[name]
        raise AttributeError(f"未找到配置项: {name}")
    
    def is_stdio_mode(self) -> bool:
        """是否为STDIO模式"""
        return self.mode == "stdio"
    
    def is_sse_mode(self) -> bool:
        """是否为SSE模式"""
        return self.mode == "sse"
    
    def is_streamable_http_mode(self) -> bool:
        """是否为Streamable HTTP模式"""
        return self.mode == "streamable-http"
    
    def get_server_url(self) -> Optional[str]:
        """获取服务器URL（仅HTTP模式）"""
        if self.is_streamable_http_mode() or self.is_sse_mode():
            return f"http://{self.host}:{self.port}"
        if self.is_stdio_mode():
            return "stdio://localhost"
        return None
