#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
UBox MCP服务器主文件（支持多设备管理）

通过Model Context Protocol暴露UBox设备自动化能力
支持设备列表获取、自动连接管理和多设备操作
"""

import json
import os
import sys
import argparse
import atexit
import threading
import uuid
from datetime import datetime
from typing import Optional, List, Dict, Any
from mcp.server.fastmcp import FastMCP
from mcp.server.fastmcp.server import Settings


# 提前解析命令行中的 UBox 配置参数，并写入环境变量
# 这样可以在导入依赖 ubox_config 的模块之前生效（如 device_manager）
def _build_cli_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="ubox-mcp-server",
        description="UBox MCP Server - 通过 MCP 暴露 UBox 设备自动化能力（支持 stdio/sse/streamable-http）",
    )
    # UBox 配置
    parser.add_argument("--ubox-secret-id", dest="ubox_secret_id", help="UBox SDK 密钥ID")
    parser.add_argument("--ubox-secret-key", dest="ubox_secret_key", help="UBox SDK 密钥")
    parser.add_argument("--ubox-auth-token", dest="ubox_auth_token",
                        help="UBox Auth Token（可替代 secret_id/secret_key，也可通过 mcp.json 的 Authorization header 传入）")
    parser.add_argument("--ubox-mode", dest="ubox_mode", choices=["local", "normal"], help="UBox 运行模式，默认 local")
    parser.add_argument("--ubox-base-url", dest="ubox_base_url",
                        help="当 --ubox-mode=local 时可用，默认 127.0.0.1:26000")
    parser.add_argument("--ubox-env", dest="ubox_env", choices=["formal", "test"], help="UBox 环境，默认 formal")
    # MCP 配置（AppConfig 也会再次解析，这里仅用于 --help 展示）
    parser.add_argument("--mcp-mode", dest="mcp_mode", choices=["stdio", "sse", "streamable-http"],
                        help="MCP 运行模式，默认 stdio")
    parser.add_argument("--mcp-host", dest="mcp_host", help="MCP 主机地址，默认 localhost")
    parser.add_argument("--mcp-port", dest="mcp_port", type=int, help="MCP 端口，默认 8000")
    # 日志
    parser.add_argument("--log-level", dest="log_level", choices=["DEBUG", "INFO", "WARNING", "ERROR"],
                        help="日志级别，默认 INFO")
    parser.add_argument("--version", action="store_true", help="显示版本信息")
    return parser


def _apply_early_cli_env() -> None:
    parser = _build_cli_parser()
    # 若用户请求帮助或版本信息，立即打印并退出（避免后续导入触发配置校验）
    if "--help" in sys.argv or "-h" in sys.argv:
        parser.print_help()
        sys.exit(0)
    if "--version" in sys.argv:
        from importlib.metadata import version as pkg_version
        try:
            ver = pkg_version("ubox-mcp-server")
        except Exception:
            ver = "unknown"
        print(f"ubox-mcp-server version {ver}")
        sys.exit(0)

    args, _ = parser.parse_known_args()

    # UBox 配置参数
    if getattr(args, "ubox_secret_id", None):
        os.environ["UBOX_SECRET_ID"] = args.ubox_secret_id
    if getattr(args, "ubox_secret_key", None):
        os.environ["UBOX_SECRET_KEY"] = args.ubox_secret_key
    if getattr(args, "ubox_mode", None):
        os.environ["UBOX_MODE"] = args.ubox_mode
    if getattr(args, "ubox_base_url", None):
        os.environ["UBOX_BASE_URL"] = args.ubox_base_url
    if getattr(args, "ubox_auth_token", None):
        os.environ["UBOX_AUTH_TOKEN"] = args.ubox_auth_token
    if getattr(args, "ubox_env", None):
        os.environ["UBOX_ENV"] = args.ubox_env

    # MCP 配置参数（需要在 FastMCP 初始化之前设置）
    if getattr(args, "mcp_mode", None):
        os.environ["MCP_MODE"] = args.mcp_mode
    if getattr(args, "mcp_host", None):
        os.environ["MCP_HOST"] = args.mcp_host
    if getattr(args, "mcp_port", None):
        os.environ["MCP_PORT"] = str(args.mcp_port)
    if getattr(args, "log_level", None):
        os.environ["LOG_LEVEL"] = args.log_level


_apply_early_cli_env()

# 兼容"已安装包环境""模块方式运行""直接运行源码文件"的多种导入路径
try:
    # 优先尝试绝对包名导入（适用于已安装的包）
    from ubox_mcp_server.device_manager import DeviceManager  # type: ignore
    from ubox_mcp_server.ubox_handler import UBoxHandler  # type: ignore
    from ubox_mcp_server.app_config import AppConfig  # type: ignore
except ImportError:
    try:
        # 退回到相对导入（适用于模块方式运行）
        from .device_manager import DeviceManager  # type: ignore
        from .ubox_handler import UBoxHandler  # type: ignore
        from .app_config import AppConfig  # type: ignore
    except ImportError:
        # 最后尝试：在源码仓库直接运行（仅用于开发环境）
        # 检查是否在源码目录中，避免在打包环境中误用
        _CUR_DIR = os.path.dirname(os.path.abspath(__file__))
        _PROJECT_ROOT = os.path.abspath(os.path.join(_CUR_DIR, os.pardir, os.pardir))
        # 只有在 src 目录存在时才尝试从 src 路径导入
        _SRC_DIR = os.path.join(_PROJECT_ROOT, "src", "ubox_mcp_server")
        if os.path.exists(_SRC_DIR) and os.path.isdir(_SRC_DIR):
            if _PROJECT_ROOT not in sys.path:
                sys.path.insert(0, _PROJECT_ROOT)
            from src.ubox_mcp_server.device_manager import DeviceManager  # type: ignore
            from src.ubox_mcp_server.ubox_handler import UBoxHandler  # type: ignore
            from src.ubox_mcp_server.app_config import AppConfig  # type: ignore
        else:
            # 如果都不行，抛出原始异常
            raise ImportError(
                "无法导入 ubox_mcp_server 模块。"
                "请确保包已正确安装或使用正确的运行方式。"
            )

# 读取早期 host/port/debug（来自环境变量或 CLI 早期注入）
_early_host = os.getenv("MCP_HOST", "localhost")
_early_port = int(os.getenv("MCP_PORT", "8000"))
_early_debug = str(os.getenv("LOG_LEVEL", "INFO")).upper() == "DEBUG"

# 创建MCP服务器实例：优先在构造器中指定 host/port/debug
mcp = FastMCP(name="ubox-mcp-server", host=_early_host, port=_early_port, debug=_early_debug)


def _extract_bearer_token(authorization: str) -> Optional[str]:
    """
    从 Authorization 请求头中提取 Bearer Token
    
    Args:
        authorization: Authorization 请求头的值，格式为 "Bearer <token>"
        
    Returns:
        str: 提取的 token，如果格式不正确则返回 None
    """
    if not authorization:
        return None
    parts = authorization.split(" ", 1)
    if len(parts) == 2 and parts[0].lower() == "bearer":
        return parts[1].strip()
    return None

# 全局配置实例
config = AppConfig()
# 全局设备管理器实例（先创建，确保所有地方使用同一个实例）
device_manager = DeviceManager()
# 全局UBox处理器实例（传入共享的 device_manager）
ubox_handler = UBoxHandler(device_manager=device_manager)


# ==================== 异步任务管理器 ====================

class AsyncTaskManager:
    """
    异步任务管理器
    
    用于管理耗时较长的操作（如应用安装），将其放入后台线程执行，
    立即返回 task_id，后续通过 task_id 查询任务状态和结果。
    """
    
    def __init__(self):
        self._tasks: Dict[str, Dict[str, Any]] = {}
        self._lock = threading.Lock()
    
    def create_task(self, task_type: str, description: str, udid: str) -> str:
        """
        创建一个新的异步任务
        
        Args:
            task_type: 任务类型（如 'install_app', 'local_install_app'）
            description: 任务描述
            udid: 设备UDID
            
        Returns:
            str: 任务ID
        """
        task_id = str(uuid.uuid4())[:8]  # 使用短ID，方便使用
        with self._lock:
            self._tasks[task_id] = {
                "task_id": task_id,
                "task_type": task_type,
                "description": description,
                "udid": udid,
                "status": "running",  # running / completed / failed
                "result": None,
                "error": None,
                "created_at": datetime.now().isoformat(),
                "completed_at": None
            }
        return task_id
    
    def complete_task(self, task_id: str, result: Dict[str, Any]):
        """标记任务为已完成"""
        with self._lock:
            if task_id in self._tasks:
                self._tasks[task_id]["status"] = "completed"
                self._tasks[task_id]["result"] = result
                self._tasks[task_id]["completed_at"] = datetime.now().isoformat()
    
    def fail_task(self, task_id: str, error: str):
        """标记任务为失败"""
        with self._lock:
            if task_id in self._tasks:
                self._tasks[task_id]["status"] = "failed"
                self._tasks[task_id]["error"] = error
                self._tasks[task_id]["completed_at"] = datetime.now().isoformat()
    
    def get_task(self, task_id: str) -> Optional[Dict[str, Any]]:
        """获取任务信息"""
        with self._lock:
            return self._tasks.get(task_id, None)
    
    def get_all_tasks(self) -> List[Dict[str, Any]]:
        """获取所有任务列表"""
        with self._lock:
            return list(self._tasks.values())
    
    def cleanup_completed_tasks(self, max_age_seconds: int = 3600):
        """清理已完成超过指定时间的任务"""
        now = datetime.now()
        with self._lock:
            to_remove = []
            for task_id, task in self._tasks.items():
                if task["status"] in ("completed", "failed") and task["completed_at"]:
                    completed_at = datetime.fromisoformat(task["completed_at"])
                    if (now - completed_at).total_seconds() > max_age_seconds:
                        to_remove.append(task_id)
            for task_id in to_remove:
                del self._tasks[task_id]


# 全局异步任务管理器实例
async_task_manager = AsyncTaskManager()

# 注册清理函数，确保在程序退出时关闭 UBox 客户端
def _cleanup_device_manager():
    """清理设备管理器资源"""
    try:
        if device_manager:
            device_manager.close()
    except Exception:
        pass

# 注册退出时的清理函数
atexit.register(_cleanup_device_manager)


# ==================== 版本信息工具 ====================

@mcp.tool()
async def get_version() -> str:
    """
    获取当前 UBox MCP Server 的版本信息

    返回:
        str: JSON格式的版本信息，包含服务器版本号
    """
    from importlib.metadata import version as pkg_version
    try:
        ver = pkg_version("ubox-mcp-server")
    except Exception:
        ver = "unknown"
    return json.dumps({
        "success": True,
        "data": {
            "version": ver,
            "name": "ubox-mcp-server"
        }
    }, ensure_ascii=False, indent=2)


# ==================== 设备管理工具 ====================

@mcp.tool()
async def get_device_list(
        page_num: int = 1,
        page_size: int = 50,
        phone_platform: Optional[List[str]] = None
) -> str:
    """
    获取可用设备列表
    
    获取UBox平台上的可用设备列表，支持分页和平台过滤。
    
    参数:
        page_num (int): 页码，从1开始
            - 默认: 1
            - 示例: 1, 2, 3
            
        page_size (int): 每页设备数量
            - 默认: 50
            - 范围: 1-100
            - 示例: 20, 50, 100
            
        phone_platform (List[str], optional): 平台过滤
            - 可选值: ["android", "ios", "harmonyos", "harmonyos_next"]
            - 默认: None（不过滤）
            - 示例: ["android", "ios"]
            
    返回:
        str: JSON格式的设备列表
            {
                "success": bool,      # 获取是否成功
                "message": str,        # 返回消息
                "data": Dict          # 设备列表数据
                    {
                        "devices": List[Dict],  # 设备列表
                            {
                                "udid": str,           # 设备UDID
                                "os_type": str,        # 操作系统类型
                                "manufacturer": str,   # 设备制造商
                                "model": str,          # 设备型号
                                "status": str          # 设备状态（在线/离线）
                            },
                        "total": int,          # 总设备数量
                        "page_num": int,       # 当前页码
                        "page_size": int       # 每页大小
                    }
            }
            
    使用场景:
        - 设备发现：查看可用的设备
        - 设备选择：选择合适的设备进行连接
        - 设备管理：了解设备分布和状态
        - 批量操作：获取设备列表进行批量处理
        
    注意事项:
        - 需要有效的UBox配置才能获取设备列表
        - 设备状态实时更新，可能与其他操作有延迟
    """
    try:
        result = device_manager.get_device_list(
            page_num=page_num,
            page_size=page_size,
            phone_platform=phone_platform
        )
        return json.dumps(result, ensure_ascii=False, indent=2)
    except Exception as e:
        return json.dumps({
            "success": False,
            "message": f"获取设备列表失败: {str(e)}"
        }, ensure_ascii=False, indent=2)


@mcp.tool()
async def connect_device(
        udid: str,
        os_type: Optional[str] = None,
        config_name: Optional[str] = None
) -> str:
    """
    连接指定设备
    
    连接到指定的设备并自动获取authcode，建立设备操作连接。
    
    参数:
        udid (str): 设备唯一标识符
            - 示例: "YOUR_DEVICE_UDID"
            - 必填: 是
            
        os_type (str, optional): 操作系统类型
            - 可选值: "android", "ios", "harmonyos", "harmonyos_next"
            - 默认: 使用配置中的默认值
            - 示例: "android"
            
        config_name (str, optional): 配置名称
            - 可选值: "normal", "local"
            - 默认: 使用配置中的默认值
            - 示例: "local"
            
    返回:
        str: JSON格式的连接结果
            {
                "success": bool,      # 连接是否成功
                "message": str,       # 返回消息
                "data": Dict          # 连接信息
                    {
                        "udid": str,              # 设备UDID
                        "auth_code": str,         # 设备认证码
                        "device_info": Dict,      # 设备详细信息
                        "connected_at": str       # 连接时间
                    }
            }
            
    使用场景:
        - 设备连接：建立与目标设备的连接
        - 自动化准备：为后续自动化操作做准备
        - 多设备管理：同时连接多个设备
        - 设备切换：在不同设备间切换连接
        
    注意事项:
        - 必须先调用此工具连接设备，才能使用其他设备操作工具
        - 每个设备只需要连接一次，连接后会保持状态
        - 如果设备已连接，会返回现有连接信息
        - 确保设备在线且可访问
    """
    try:
        result = device_manager.connect_device(
            udid=udid,
            os_type=os_type,
            config_name=config_name
        )
        return json.dumps(result, ensure_ascii=False, indent=2)
    except Exception as e:
        return json.dumps({
            "success": False,
            "message": f"连接设备失败: {str(e)}"
        }, ensure_ascii=False, indent=2)


@mcp.tool()
async def disconnect_device(udid: str) -> str:
    """
    断开设备连接
    
    断开与指定设备的连接，释放资源。
    
    参数:
        udid (str): 设备唯一标识符
            - 示例: "YOUR_DEVICE_UDID"
            - 必填: 是
            
    返回:
        str: JSON格式的断开结果
            {
                "success": bool,      # 断开是否成功
                "message": str,       # 返回消息
                "data": Dict          # 断开信息
                    {
                        "udid": str,              # 设备UDID
                        "disconnected_at": str    # 断开时间
                    }
            }
            
    使用场景:
        - 资源释放：释放不再需要的设备连接
        - 设备切换：断开当前设备连接其他设备
        - 清理操作：清理所有设备连接
        - 错误恢复：重新连接有问题的设备
        
    注意事项:
        - 断开连接后，该设备的所有操作将不可用
        - 需要重新连接才能继续使用该设备
    """
    try:
        result = device_manager.disconnect_device(udid=udid)
        return json.dumps(result, ensure_ascii=False, indent=2)
    except Exception as e:
        return json.dumps({
            "success": False,
            "message": f"断开设备失败: {str(e)}"
        }, ensure_ascii=False, indent=2)


@mcp.tool()
async def get_connected_devices() -> str:
    """
    获取已连接的设备列表
    
    获取当前已连接的所有设备信息。
    
    返回:
        str: JSON格式的已连接设备列表
            {
                "success": bool,      # 获取是否成功
                "message": str,       # 返回消息
                "data": Dict          # 已连接设备信息
                    {
                        "devices": List[Dict],  # 已连接设备列表
                            {
                                "udid": str,              # 设备UDID
                                "os_type": str,           # 操作系统类型
                                "manufacturer": str,       # 设备制造商
                                "model": str,             # 设备型号
                                "status": str,            # 连接状态
                                "auth_code": str,         # 认证码
                                "connected_at": str,      # 连接时间
                                "last_activity": str      # 最后活动时间
                            },
                        "count": int           # 已连接设备数量
                    }
            }
            
    使用场景:
        - 连接状态检查：查看当前连接的设备
        - 设备管理：管理多个已连接的设备
        - 状态监控：监控设备连接状态
        - 资源统计：统计已使用的设备资源
    """
    try:
        result = device_manager.get_connected_devices()
        return json.dumps(result, ensure_ascii=False, indent=2)
    except Exception as e:
        return json.dumps({
            "success": False,
            "message": f"获取已连接设备列表失败: {str(e)}"
        }, ensure_ascii=False, indent=2)


@mcp.tool()
async def get_device_status(udid: str) -> str:
    """
    获取设备状态信息
    
    获取指定设备的详细状态信息。
    
    参数:
        udid (str): 设备唯一标识符
            - 示例: "YOUR_DEVICE_UDID"
            - 必填: 是
            
    返回:
        str: JSON格式的设备状态
            {
                "success": bool,      # 获取是否成功
                "message": str,       # 返回消息
                "data": Dict          # 设备状态信息
                    {
                        "udid": str,              # 设备UDID
                        "os_type": str,           # 操作系统类型
                        "manufacturer": str,       # 设备制造商
                        "model": str,             # 设备型号
                        "status": str,            # 连接状态
                        "auth_code": str,         # 认证码
                        "connected_at": str,      # 连接时间
                        "last_activity": str      # 最后活动时间
                    }
            }
            
    使用场景:
        - 状态检查：检查设备连接状态
        - 健康监控：监控设备健康状态
        - 调试信息：获取设备调试信息
        - 连接验证：验证设备连接是否正常
    """
    try:
        result = device_manager.get_device_status(udid=udid)
        return json.dumps(result, ensure_ascii=False, indent=2)
    except Exception as e:
        return json.dumps({
            "success": False,
            "message": f"获取设备状态失败: {str(e)}"
        }, ensure_ascii=False, indent=2)


# ==================== 设备操作工具 ====================

@mcp.tool()
async def get_device_info(udid: str) -> str:
    """
    获取设备详细信息
    
    获取指定设备的详细硬件和系统信息。
    
    参数:
        udid (str): 设备唯一标识符
            - 示例: "YOUR_DEVICE_UDID"
            - 必填: 是
            
    返回:
        str: JSON格式的设备信息
            {
                "success": bool,      # 获取是否成功
                "message": str,       # 返回消息
                "data": Dict          # 设备信息
                    {
                        "device_info": Dict,      # 设备基本信息
                        "auth_info": Dict,        # 认证信息
                        "udid": str              # 设备UDID
                    }
            }
    """
    try:
        result = ubox_handler.get_device_info(udid=udid)
        return json.dumps(result, ensure_ascii=False, indent=2)
    except Exception as e:
        return json.dumps({
            "success": False,
            "message": f"获取设备信息失败: {str(e)}"
        }, ensure_ascii=False, indent=2)


@mcp.tool()
async def take_screenshot_base64(udid: str) -> str:
    """
    获取指定设备的Base64格式截图
    
    参数:
        udid (str): 设备唯一标识符
        
    返回:
        str: JSON格式的Base64截图结果
    """
    try:
        result = ubox_handler.screenshot_base64(udid=udid)
        return json.dumps(result, ensure_ascii=False, indent=2)
    except Exception as e:
        return json.dumps({
            "success": False,
            "message": f"Base64截图失败: {str(e)}"
        }, ensure_ascii=False, indent=2)


@mcp.tool()
async def click_position(
        udid: str,
        pos: List[float],
        duration: float = 0.05,
        times: int = 1
) -> str:
    """
    在指定设备上进行坐标点击操作
    
    参数:
        udid (str): 设备唯一标识符
        pos (List[float]): 点击坐标位置
        duration (float): 点击持续时间
        times (int): 点击次数
        
    返回:
        str: JSON格式的点击结果
    """
    try:
        result = ubox_handler.click_pos(udid=udid, pos=pos, duration=duration, times=times)
        return json.dumps(result, ensure_ascii=False, indent=2)
    except Exception as e:
        return json.dumps({
            "success": False,
            "message": f"坐标点击失败: {str(e)}"
        }, ensure_ascii=False, indent=2)


@mcp.tool()
async def click_element(
        udid: str,
        loc: str,
        by: str = "UI",
        offset: Optional[List[int]] = None,
        timeout: int = 30,
        duration: float = 0.05,
        times: int = 1
) -> str:
    """
    在指定设备上进行智能元素点击
    
    参数:
        udid (str): 设备唯一标识符
        loc (str): 元素定位信息
        by (str): 定位方式
        offset (List[int], optional): 偏移量
        timeout (int): 查找超时时间
        duration (float): 点击持续时间
        times (int): 点击次数
        
    返回:
        str: JSON格式的点击结果
    """
    try:
        result = ubox_handler.click(
            udid=udid, loc=loc, by=by, offset=offset,
            timeout=timeout, duration=duration, times=times
        )
        return json.dumps(result, ensure_ascii=False, indent=2)
    except Exception as e:
        return json.dumps({
            "success": False,
            "message": f"智能点击失败: {str(e)}"
        }, ensure_ascii=False, indent=2)


@mcp.tool()
async def slide_position(
        udid: str,
        pos_from: List[float],
        pos_to: List[float],
        slide_duration: float = 0.1
) -> str:
    """
    在指定设备上进行坐标滑动操作（支持相对坐标和像素坐标）
    
    参数:
        udid (str): 设备唯一标识符
        pos_from (List[float]): 滑动起始坐标，格式为 [x, y]
            - 相对坐标：所有值在 [0, 1.0] 之间，例如 [0.5, 0.5] 表示屏幕中心
            - 像素坐标：值大于 1，例如 [540, 960] 表示像素坐标
        pos_to (List[float]): 滑动结束坐标，格式为 [x, y]
            - 相对坐标：所有值在 [0, 1.0] 之间，例如 [0.5, 0.8] 表示屏幕中下方
            - 像素坐标：值大于 1，例如 [540, 1200] 表示像素坐标
        slide_duration (float): 滑动持续时间（秒），默认 0.1 秒
        
    返回:
        str: JSON格式的滑动结果
        
    注意:
        - 坐标系统自动识别：相对坐标 [0, 0] 表示屏幕左上角，[1, 1] 表示屏幕右下角
        - pos_from 和 pos_to 必须使用相同的坐标系统（都是相对坐标或都是像素坐标）
    """
    try:
        result = ubox_handler.slide_pos(
            udid=udid, pos_from=pos_from, pos_to=pos_to, slide_duration=slide_duration
        )
        return json.dumps(result, ensure_ascii=False, indent=2)
    except Exception as e:
        return json.dumps({
            "success": False,
            "message": f"坐标滑动失败: {str(e)}"
        }, ensure_ascii=False, indent=2)


@mcp.tool()
async def slide_between_elements(
        udid: str,
        loc_from: str,
        loc_to: str,
        by: str = "POS",
        timeout: int = 120,
        down_duration: float = 0
) -> str:
    """
    在指定设备的两个元素间进行滑动操作
    
    参数:
        udid (str): 设备唯一标识符
        loc_from (str): 滑动起始元素定位信息
        loc_to (str): 滑动结束元素定位信息
        by (str): 定位方式
        timeout (int): 查找超时时间
        down_duration (float): 起始位置按下时长
        
    返回:
        str: JSON格式的滑动结果
    """
    try:
        result = ubox_handler.slide(
            udid=udid, loc_from=loc_from, loc_to=loc_to,
            by=by, timeout=timeout, down_duration=down_duration
        )
        return json.dumps(result, ensure_ascii=False, indent=2)
    except Exception as e:
        return json.dumps({
            "success": False,
            "message": f"智能滑动失败: {str(e)}"
        }, ensure_ascii=False, indent=2)


@mcp.tool()
async def input_text(
        udid: str,
        text: str,
        timeout: int = 30,
        depth: int = 10
) -> str:
    """
    向指定设备输入文本
    
    参数:
        udid (str): 设备唯一标识符
        text (str): 要输入的文本内容
        timeout (int): 输入超时时间
        depth (int): source tree的最大深度值
        
    返回:
        str: JSON格式的输入结果
    """
    try:
        result = ubox_handler.input_text(udid=udid, text=text, timeout=timeout, depth=depth)
        return json.dumps(result, ensure_ascii=False, indent=2)
    except Exception as e:
        return json.dumps({
            "success": False,
            "message": f"文本输入失败: {str(e)}"
        }, ensure_ascii=False, indent=2)


@mcp.tool()
async def press_button(udid: str, button: str) -> str:
    """
    在指定设备上执行按键操作
    
    参数:
        udid (str): 设备唯一标识符
        button (str): 按键类型
        
    返回:
        str: JSON格式的按键结果
    """
    try:
        result = ubox_handler.press(udid=udid, button=button)
        return json.dumps(result, ensure_ascii=False, indent=2)
    except Exception as e:
        return json.dumps({
            "success": False,
            "message": f"按键操作失败: {str(e)}"
        }, ensure_ascii=False, indent=2)


@mcp.tool()
async def start_application(
        udid: str,
        package: str,
        clear_data: bool = False
) -> str:
    """
    在指定设备上启动应用程序
    
    参数:
        udid (str): 设备唯一标识符
        package (str): 应用包名或Bundle ID
        clear_data (bool): 是否清除应用数据
        
    返回:
        str: JSON格式的启动结果
    """
    try:
        result = ubox_handler.start_app(udid=udid, package=package, clear_data=clear_data)
        return json.dumps(result, ensure_ascii=False, indent=2)
    except Exception as e:
        return json.dumps({
            "success": False,
            "message": f"启动应用失败: {str(e)}"
        }, ensure_ascii=False, indent=2)


@mcp.tool()
async def stop_application(udid: str, package: str) -> str:
    """
    在指定设备上停止应用程序
    
    参数:
        udid (str): 设备唯一标识符
        package (str): 应用包名或Bundle ID
        
    返回:
        str: JSON格式的停止结果
    """
    try:
        result = ubox_handler.stop_app(udid=udid, package=package)
        return json.dumps(result, ensure_ascii=False, indent=2)
    except Exception as e:
        return json.dumps({
            "success": False,
            "message": f"停止应用失败: {str(e)}"
        }, ensure_ascii=False, indent=2)


@mcp.tool()
async def get_current_application(udid: str) -> str:
    """
    获取指定设备当前运行的应用
    
    参数:
        udid (str): 设备唯一标识符
        
    返回:
        str: JSON格式的当前应用信息
    """
    try:
        result = ubox_handler.current_app(udid=udid)
        return json.dumps(result, ensure_ascii=False, indent=2)
    except Exception as e:
        return json.dumps({
            "success": False,
            "message": f"获取当前应用失败: {str(e)}"
        }, ensure_ascii=False, indent=2)


@mcp.tool()
async def get_running_applications(udid: str) -> str:
    """
    获取指定设备运行中的应用列表
    
    参数:
        udid (str): 设备唯一标识符
        
    返回:
        str: JSON格式的运行应用列表
    """
    try:
        result = ubox_handler.app_list_running(udid=udid)
        return json.dumps(result, ensure_ascii=False, indent=2)
    except Exception as e:
        return json.dumps({
            "success": False,
            "message": f"获取运行应用列表失败: {str(e)}"
        }, ensure_ascii=False, indent=2)


@mcp.tool()
async def execute_adb_command(
        udid: str,
        command: str,
        timeout: int = 10
) -> str:
    """
    在指定设备上执行ADB命令（仅Android和鸿蒙）
    
    参数:
        udid (str): 设备唯一标识符
        command (str): ADB命令
        timeout (int): 命令执行超时时间
        
    返回:
        str: JSON格式的命令执行结果
    """
    try:
        result = ubox_handler.cmd_adb(udid=udid, cmd=command, timeout=timeout)
        return json.dumps(result, ensure_ascii=False, indent=2)
    except Exception as e:
        return json.dumps({
            "success": False,
            "message": f"执行ADB命令失败: {str(e)}"
        }, ensure_ascii=False, indent=2)


@mcp.tool()
async def find_ui_element(
        udid: str,
        xpath: str,
        timeout: int = 30
) -> str:
    """
    在指定设备上查找UI控件元素
    
    参数:
        udid (str): 设备唯一标识符
        xpath (str): XPath表达式
        timeout (int): 查找超时时间
        
    返回:
        str: JSON格式的查找结果
    """
    try:
        result = ubox_handler.find_ui(udid=udid, xpath=xpath, timeout=timeout)
        return json.dumps(result, ensure_ascii=False, indent=2)
    except Exception as e:
        return json.dumps({
            "success": False,
            "message": f"UI控件查找失败: {str(e)}"
        }, ensure_ascii=False, indent=2)


@mcp.tool()
async def get_ui_tree(udid: str, xml_format: bool = True) -> str:
    """
    获取指定设备的UI树结构
    
    参数:
        udid (str): 设备唯一标识符
        xml_format (bool): 是否使用XML格式
        
    返回:
        str: JSON格式的UI树结果
    """
    try:
        result = ubox_handler.get_uitree(udid=udid, xml=xml_format)
        return json.dumps(result, ensure_ascii=False, indent=2)
    except Exception as e:
        return json.dumps({
            "success": False,
            "message": f"获取UI树失败: {str(e)}"
        }, ensure_ascii=False, indent=2)


@mcp.tool()
async def set_clipboard_content(udid: str, text: str) -> str:
    """
    设置指定设备剪贴板内容
    
    参数:
        udid (str): 设备唯一标识符
        text (str): 要设置的剪贴板文本
        
    返回:
        str: JSON格式的设置结果
    """
    try:
        result = ubox_handler.set_clipboard(udid=udid, text=text)
        return json.dumps(result, ensure_ascii=False, indent=2)
    except Exception as e:
        return json.dumps({
            "success": False,
            "message": f"设置剪贴板失败: {str(e)}"
        }, ensure_ascii=False, indent=2)


@mcp.tool()
async def get_clipboard_content(udid: str) -> str:
    """
    获取指定设备剪贴板内容
    
    参数:
        udid (str): 设备唯一标识符
        
    返回:
        str: JSON格式的获取结果
    """
    try:
        result = ubox_handler.get_clipboard(udid=udid)
        return json.dumps(result, ensure_ascii=False, indent=2)
    except Exception as e:
        return json.dumps({
            "success": False,
            "message": f"获取剪贴板失败: {str(e)}"
        }, ensure_ascii=False, indent=2)


@mcp.tool()
async def start_screen_recording(udid: str, video_path: str) -> str:
    """
    开始指定设备的屏幕录制
    
    参数:
        udid (str): 设备唯一标识符
        video_path (str): 视频保存路径
        
    返回:
        str: JSON格式的录制结果
    """
    try:
        result = ubox_handler.record_start(udid=udid, video_path=video_path)
        return json.dumps(result, ensure_ascii=False, indent=2)
    except Exception as e:
        return json.dumps({
            "success": False,
            "message": f"开始录制失败: {str(e)}"
        }, ensure_ascii=False, indent=2)


@mcp.tool()
async def stop_screen_recording(udid: str) -> str:
    """
    停止指定设备的屏幕录制
    
    参数:
        udid (str): 设备唯一标识符
        
    返回:
        str: JSON格式的停止结果
    """
    try:
        result = ubox_handler.record_stop(udid=udid)
        return json.dumps(result, ensure_ascii=False, indent=2)
    except Exception as e:
        return json.dumps({
            "success": False,
            "message": f"停止录制失败: {str(e)}"
        }, ensure_ascii=False, indent=2)


@mcp.tool()
async def long_click_element(
        udid: str,
        loc: str,
        by: str = "UI",
        duration: float = 3.0,
        timeout: int = 30
) -> str:
    """
    在指定设备上执行长按操作
    
    参数:
        udid (str): 设备唯一标识符
        loc (str): 元素定位信息（XPath、文字或图片路径）
        by (str): 定位方式，可选值: "UI", "OCR", "CV", "POS"
        duration (float): 长按持续时间（秒），默认3.0秒
        timeout (int): 查找超时时间（秒），默认30秒
        
    返回:
        str: JSON格式的长按结果
    """
    try:
        result = ubox_handler.long_click(
            udid=udid, loc=loc, by=by, duration=duration, timeout=timeout
        )
        return json.dumps(result, ensure_ascii=False, indent=2)
    except Exception as e:
        return json.dumps({
            "success": False,
            "message": f"长按操作失败: {str(e)}"
        }, ensure_ascii=False, indent=2)


@mcp.tool()
async def get_element_by_cv(
        udid: str,
        template: str,
        threshold: float = 0.8,
        timeout: int = 20,
        crop_box: Optional[List[float]] = None,
        to_gray: bool = True,
        ratio_lv: int = 25,
        is_translucent: bool = False
) -> str:
    """
    通过CV图像匹配获取元素位置和边界信息
    
    参数:
        udid (str): 设备唯一标识符
        template (str): 模板图片路径
        threshold (float): 匹配阈值，默认0.8
        timeout (int): 查找超时时间（秒），默认20秒
        crop_box (List[float], optional): 裁剪区域 [x1, y1, x2, y2]，相对坐标
        to_gray (bool): 是否转换为灰度图匹配，默认True
        ratio_lv (int): 缩放级别，默认25
        is_translucent (bool): 是否为半透明图像，默认False
        
    返回:
        str: JSON格式的元素信息，包含bounds（边界）和中心点坐标
    """
    try:
        result = ubox_handler.get_element_cv(
            udid=udid, tpl=template, threshold=threshold, timeout=timeout,
            crop_box=crop_box, to_gray=to_gray, ratio_lv=ratio_lv,
            is_translucent=is_translucent
        )
        return json.dumps(result, ensure_ascii=False, indent=2)
    except Exception as e:
        return json.dumps({
            "success": False,
            "message": f"CV元素获取失败: {str(e)}"
        }, ensure_ascii=False, indent=2)


@mcp.tool()
async def get_element_by_ocr(
        udid: str,
        word: str,
        timeout: int = 10,
        crop_box: Optional[List[float]] = None
) -> str:
    """
    通过OCR文字识别获取元素位置和边界信息
    
    参数:
        udid (str): 设备唯一标识符
        word (str): 要查找的文字内容
        timeout (int): 查找超时时间（秒），默认10秒
        crop_box (List[float], optional): 裁剪区域 [x1, y1, x2, y2]，相对坐标
        
    返回:
        str: JSON格式的元素信息，包含bounds（边界）和中心点坐标
    """
    try:
        result = ubox_handler.get_element_ocr(
            udid=udid, word=word, timeout=timeout, crop_box=crop_box
        )
        return json.dumps(result, ensure_ascii=False, indent=2)
    except Exception as e:
        return json.dumps({
            "success": False,
            "message": f"OCR元素获取失败: {str(e)}"
        }, ensure_ascii=False, indent=2)


@mcp.tool()
async def install_application(
        udid: str,
        app_url: str
) -> str:
    """
    通过URL安装应用（异步执行）
    
    由于应用安装耗时较长，此操作将在后台异步执行。
    调用后立即返回一个 task_id，可通过 check_async_task_status 工具查询安装进度和结果。
    
    参数:
        udid (str): 设备唯一标识符
        app_url (str): 应用的下载URL
        
    返回:
        str: JSON格式的任务信息，包含 task_id 用于后续查询
    """
    try:
        task_id = async_task_manager.create_task(
            task_type="install_app",
            description=f"通过URL安装应用: {app_url}",
            udid=udid
        )
        
        def _do_install():
            try:
                result = ubox_handler.install_app(udid=udid, app_url=app_url)
                async_task_manager.complete_task(task_id, result)
            except Exception as e:
                async_task_manager.fail_task(task_id, str(e))
        
        thread = threading.Thread(target=_do_install, daemon=True)
        thread.start()
        
        return json.dumps({
            "success": True,
            "message": "应用安装任务已提交，正在后台执行。请使用 check_async_task_status 工具查询任务状态。",
            "data": {
                "task_id": task_id,
                "udid": udid,
                "app_url": app_url,
                "status": "running"
            }
        }, ensure_ascii=False, indent=2)
    except Exception as e:
        return json.dumps({
            "success": False,
            "message": f"提交安装任务失败: {str(e)}"
        }, ensure_ascii=False, indent=2)


@mcp.tool()
async def install_local_application(
        udid: str,
        local_app_path: str,
        need_resign: bool = False
) -> str:
    """
    安装本地应用文件（异步执行）
    
    由于本地应用安装需要上传文件到远程设备，耗时较长，此操作将在后台异步执行。
    调用后立即返回一个 task_id，可通过 check_async_task_status 工具查询安装进度和结果。
    
    参数:
        udid (str): 设备唯一标识符
        local_app_path (str): 本地应用文件路径（APK/IPA）
        need_resign (bool): iOS是否需要重新签名，默认False
        
    返回:
        str: JSON格式的任务信息，包含 task_id 用于后续查询
    """
    try:
        task_id = async_task_manager.create_task(
            task_type="local_install_app",
            description=f"安装本地应用: {local_app_path}",
            udid=udid
        )
        
        def _do_install():
            try:
                result = ubox_handler.local_install_app(
                    udid=udid, local_app_path=local_app_path, need_resign=need_resign
                )
                async_task_manager.complete_task(task_id, result)
            except Exception as e:
                async_task_manager.fail_task(task_id, str(e))
        
        thread = threading.Thread(target=_do_install, daemon=True)
        thread.start()
        
        return json.dumps({
            "success": True,
            "message": "本地应用安装任务已提交，正在后台执行（文件上传+安装可能需要较长时间）。请使用 check_async_task_status 工具查询任务状态。",
            "data": {
                "task_id": task_id,
                "udid": udid,
                "local_app_path": local_app_path,
                "status": "running"
            }
        }, ensure_ascii=False, indent=2)
    except Exception as e:
        return json.dumps({
            "success": False,
            "message": f"提交本地安装任务失败: {str(e)}"
        }, ensure_ascii=False, indent=2)


@mcp.tool()
async def check_async_task_status(task_id: str) -> str:
    """
    查询异步任务的执行状态和结果
    
    用于查询通过 install_application 或 install_local_application 提交的异步安装任务的状态。
    
    参数:
        task_id (str): 任务ID，由 install_application 或 install_local_application 返回
        
    返回:
        str: JSON格式的任务状态信息
            - status 为 "running" 表示任务仍在执行中，请稍后再查询
            - status 为 "completed" 表示任务已完成，result 字段包含执行结果
            - status 为 "failed" 表示任务执行失败，error 字段包含错误信息
    """
    task = async_task_manager.get_task(task_id)
    if not task:
        return json.dumps({
            "success": False,
            "message": f"未找到任务: {task_id}，请检查 task_id 是否正确"
        }, ensure_ascii=False, indent=2)
    
    response = {
        "success": True,
        "message": "",
        "data": task
    }
    
    if task["status"] == "running":
        response["message"] = "任务正在执行中，请稍后再查询"
    elif task["status"] == "completed":
        response["message"] = "任务已完成"
    elif task["status"] == "failed":
        response["message"] = f"任务执行失败: {task.get('error', '未知错误')}"
    
    return json.dumps(response, ensure_ascii=False, indent=2)


@mcp.tool()
async def uninstall_application(udid: str, package: str) -> str:
    """
    卸载应用
    
    参数:
        udid (str): 设备唯一标识符
        package (str): 应用包名或Bundle ID
        
    返回:
        str: JSON格式的卸载结果
    """
    try:
        result = ubox_handler.uninstall_app(udid=udid, package=package)
        return json.dumps(result, ensure_ascii=False, indent=2)
    except Exception as e:
        return json.dumps({
            "success": False,
            "message": f"卸载应用失败: {str(e)}"
        }, ensure_ascii=False, indent=2)


@mcp.tool()
async def start_performance_collection(
        udid: str,
        container_bundle_identifier: str,
        log_output_file: Optional[str] = None,
        case_name: Optional[str] = None
) -> str:
    """
    开始性能采集
    
    参数:
        udid (str): 设备唯一标识符
        container_bundle_identifier (str): 应用包名或Bundle ID
        log_output_file (str, optional): 日志输出文件路径
        case_name (str, optional): 测试用例名称
        
    返回:
        str: JSON格式的启动结果
    """
    try:
        result = ubox_handler.perf_start(
            udid=udid,
            container_bundle_identifier=container_bundle_identifier,
            log_output_file=log_output_file,
            case_name=case_name
        )
        return json.dumps(result, ensure_ascii=False, indent=2)
    except Exception as e:
        return json.dumps({
            "success": False,
            "message": f"开始性能采集失败: {str(e)}"
        }, ensure_ascii=False, indent=2)


@mcp.tool()
async def stop_performance_collection(
        udid: str,
        output_directory: str = "./perf_output"
) -> str:
    """
    停止性能采集并保存数据
    
    参数:
        udid (str): 设备唯一标识符
        output_directory (str): 输出目录，默认"./perf_output"
        
    返回:
        str: JSON格式的停止结果
    """
    try:
        result = ubox_handler.perf_stop(udid=udid, output_directory=output_directory)
        return json.dumps(result, ensure_ascii=False, indent=2)
    except Exception as e:
        return json.dumps({
            "success": False,
            "message": f"停止性能采集失败: {str(e)}"
        }, ensure_ascii=False, indent=2)


@mcp.tool()
async def start_logcat_collection(
        udid: str,
        file: str,
        clear: bool = True,
        re_filter: Optional[str] = None
) -> str:
    """
    开始Logcat日志采集（仅Android和鸿蒙）
    
    参数:
        udid (str): 设备唯一标识符
        file (str): 日志文件保存路径
        clear (bool): 是否清除之前的日志，默认True
        re_filter (str, optional): 正则表达式过滤条件
        
    返回:
        str: JSON格式的启动结果，包含task_id用于后续停止操作
    """
    try:
        result = ubox_handler.logcat_start(
            udid=udid, file=file, clear=clear, re_filter=re_filter
        )
        return json.dumps(result, ensure_ascii=False, indent=2)
    except Exception as e:
        return json.dumps({
            "success": False,
            "message": f"开始Logcat采集失败: {str(e)}"
        }, ensure_ascii=False, indent=2)


@mcp.tool()
async def stop_all_logcat_collection(udid: str) -> str:
    """
    停止所有Logcat采集任务（仅Android和鸿蒙）
    
    参数:
        udid (str): 设备唯一标识符
        
    返回:
        str: JSON格式的停止结果
    """
    try:
        result = ubox_handler.logcat_stop_all(udid=udid)
        return json.dumps(result, ensure_ascii=False, indent=2)
    except Exception as e:
        return json.dumps({
            "success": False,
            "message": f"停止Logcat采集失败: {str(e)}"
        }, ensure_ascii=False, indent=2)


@mcp.tool()
async def list_logcat_tasks(udid: str) -> str:
    """
    列出所有正在运行的Logcat任务（仅Android和鸿蒙）
    
    参数:
        udid (str): 设备唯一标识符
        
    返回:
        str: JSON格式的任务列表
    """
    try:
        result = ubox_handler.logcat_list_tasks(udid=udid)
        return json.dumps(result, ensure_ascii=False, indent=2)
    except Exception as e:
        return json.dumps({
            "success": False,
            "message": f"列出Logcat任务失败: {str(e)}"
        }, ensure_ascii=False, indent=2)


@mcp.tool()
async def start_anr_monitoring(
        udid: str,
        package_name: str,
        collect_am_monitor: bool = True
) -> str:
    """
    开始ANR/Crash监控（仅Android和鸿蒙）
    
    参数:
        udid (str): 设备唯一标识符
        package_name (str): 要监控的应用包名
        collect_am_monitor (bool): 是否收集ActivityManager监控信息，默认True
        
    返回:
        str: JSON格式的启动结果
    """
    try:
        result = ubox_handler.anr_start(
            udid=udid, package_name=package_name, collect_am_monitor=collect_am_monitor
        )
        return json.dumps(result, ensure_ascii=False, indent=2)
    except Exception as e:
        return json.dumps({
            "success": False,
            "message": f"开始ANR监控失败: {str(e)}"
        }, ensure_ascii=False, indent=2)


@mcp.tool()
async def stop_anr_monitoring(
        udid: str,
        output_directory: str = "./anr_output"
) -> str:
    """
    停止ANR/Crash监控并获取结果（仅Android和鸿蒙）
    
    参数:
        udid (str): 设备唯一标识符
        output_directory (str): 输出目录，默认"./anr_output"
        
    返回:
        str: JSON格式的监控结果，包含ANR次数、Crash次数、截图和日志文件等
    """
    try:
        result = ubox_handler.anr_stop(udid=udid, output_directory=output_directory)
        return json.dumps(result, ensure_ascii=False, indent=2)
    except Exception as e:
        return json.dumps({
            "success": False,
            "message": f"停止ANR监控失败: {str(e)}"
        }, ensure_ascii=False, indent=2)


@mcp.tool()
async def ios_open_url(udid: str, url: str) -> str:
    """
    在iOS设备上打开URL（仅iOS）
    
    参数:
        udid (str): 设备唯一标识符
        url (str): 要打开的URL地址
        
    返回:
        str: JSON格式的打开结果
    """
    try:
        result = ubox_handler.ios_open_url(udid=udid, url=url)
        return json.dumps(result, ensure_ascii=False, indent=2)
    except Exception as e:
        return json.dumps({
            "success": False,
            "message": f"iOS打开URL失败: {str(e)}"
        }, ensure_ascii=False, indent=2)


@mcp.tool()
async def find_text_by_ocr(
        udid: str,
        word: str,
        timeout: int = 30,
        crop_box: Optional[List[float]] = None
) -> str:
    """
    通过OCR文字识别查找元素（支持裁剪区域）
    
    参数:
        udid (str): 设备唯一标识符
        word (str): 要查找的文字内容
        timeout (int): 查找超时时间（秒），默认30秒
        crop_box (List[float], optional): 裁剪区域 [x1, y1, x2, y2]，相对坐标(0-1)
        
    返回:
        str: JSON格式的查找结果
    """
    try:
        result = ubox_handler.find_ocr(
            udid=udid, word=word, timeout=timeout, crop_box=crop_box
        )
        return json.dumps(result, ensure_ascii=False, indent=2)
    except Exception as e:
        return json.dumps({
            "success": False,
            "message": f"OCR文字查找失败: {str(e)}"
        }, ensure_ascii=False, indent=2)


@mcp.tool()
async def find_image_by_cv(
        udid: str,
        template: str,
        threshold: float = 0.8,
        timeout: int = 30,
        crop_box: Optional[List[float]] = None,
        to_gray: bool = True,
        ratio_lv: int = 25,
        is_translucent: bool = False,
        time_interval: float = 1.0
) -> str:
    """
    通过CV图像匹配查找元素（支持高级参数）
    
    参数:
        udid (str): 设备唯一标识符
        template (str): 模板图片路径
        threshold (float): 匹配阈值，默认0.8
        timeout (int): 查找超时时间（秒），默认30秒
        crop_box (List[float], optional): 裁剪区域 [x1, y1, x2, y2]，相对坐标
        to_gray (bool): 是否转换为灰度图匹配，默认True
        ratio_lv (int): 缩放级别，默认25
        is_translucent (bool): 是否为半透明图像，默认False
        time_interval (float): 查找间隔时间（秒），默认1.0秒
        
    返回:
        str: JSON格式的查找结果
    """
    try:
        result = ubox_handler.find_cv(
            udid=udid, tpl=template, threshold=threshold, timeout=timeout,
            crop_box=crop_box, to_gray=to_gray, ratio_lv=ratio_lv,
            is_translucent=is_translucent, time_interval=time_interval
        )
        return json.dumps(result, ensure_ascii=False, indent=2)
    except Exception as e:
        return json.dumps({
            "success": False,
            "message": f"CV图像查找失败: {str(e)}"
        }, ensure_ascii=False, indent=2)


@mcp.tool()
async def take_screenshot(
        udid: str,
        label: str = "mcp_screenshot",
        img_path: str = "./screenshots"
) -> str:
    """
    对指定设备进行截图
    
    参数:
        udid (str): 设备唯一标识符
        label (str): 截图文件名标签，默认"mcp_screenshot"
        img_path (str): 图片保存路径，默认"./screenshots"
        
    返回:
        str: JSON格式的截图结果
    """
    try:
        result = ubox_handler.screenshot(
            udid=udid, label=label, img_path=img_path
        )
        return json.dumps(result, ensure_ascii=False, indent=2)
    except Exception as e:
        return json.dumps({
            "success": False,
            "message": f"截图失败: {str(e)}"
        }, ensure_ascii=False, indent=2)


def main():
    """
    主函数 - 启动MCP服务器
    
    支持的传输模式：
    - STDIO: 标准输入输出模式，适合本地集成（默认）
    - SSE (Server-Sent Events): 适合长连接场景
    - Streamable HTTP: MCP协议推荐的新传输方式，支持双向通信
    
    配置方式：
    - 环境变量: MCP_MODE, MCP_HOST, MCP_PORT
    - 命令行参数: --mcp-mode, --mcp-host, --mcp-port
    - .env文件: 在项目根目录创建.env文件
    """
    # 导入 ubox_config 获取认证模式信息
    try:
        from ubox_mcp_server.ubox_config import ubox_config as _ubox_cfg  # type: ignore
    except ImportError:
        try:
            from .ubox_config import ubox_config as _ubox_cfg  # type: ignore
        except ImportError:
            _ubox_cfg = None
    
    auth_mode = "Token" if (_ubox_cfg and _ubox_cfg.has_auth_token()) else "Secret Key"
    
    # 修复 Windows 下 GBK 编码无法输出 emoji 的问题
    # 同时将启动日志输出到 stderr，避免干扰 STDIO 模式的 JSON-RPC 通信
    import io
    _log_stream = io.TextIOWrapper(sys.stderr.buffer, encoding="utf-8", errors="replace")
    
    def _log(msg: str):
        """将启动日志输出到 stderr（UTF-8 编码）"""
        try:
            _log_stream.write(msg + "\n")
            _log_stream.flush()
        except Exception:
            pass
    
    _log("🚀 启动UBox MCP服务器（多设备管理版本）")
    _log(f"📡 运行模式: {config.mode}")
    _log(f"🔑 认证方式: {auth_mode}")
    if config.is_stdio_mode():
        _log("🌐 传输方式: STDIO（标准输入输出）")
    else:
        _log(f"🌐 服务器地址: {config.get_server_url()}")
        _log(f"📦 主机: {config.host}")
        _log(f"🔌 端口: {config.port}")
    _log("💡 Token认证：可通过环境变量 UBOX_AUTH_TOKEN 或 mcp.json 的 env 配置传入")
    _log("=" * 60)

    # 获取服务器配置（从 AppConfig 读取，确保与命令行参数一致）
    host = config.host
    port = config.port

    # 确保 FastMCP 实例使用正确的 host/port
    # 某些版本的 FastMCP 需要在 Settings 中设置，而不是构造器参数
    try:
        if hasattr(mcp, 'settings') and mcp.settings:
            mcp.settings.host = host
            mcp.settings.port = port
    except Exception:
        pass

    # 根据模式启动服务器
    if config.is_stdio_mode():
        # STDIO 模式：通过标准输入输出通信，Token 通过环境变量 UBOX_AUTH_TOKEN 传入
        _log("✅ 启动STDIO模式服务器")
        mcp.run(transport="stdio")
    elif config.is_sse_mode() or config.is_streamable_http_mode():
        # HTTP 模式：添加 Token 提取中间件
        # 当客户端通过 mcp.json 配置 Authorization header 时，
        # 中间件会自动提取 Bearer Token 并更新 DeviceManager 的认证信息
        _original_streamable_http_app = mcp.streamable_http_app
        _original_sse_app = mcp.sse_app
        
        def _patched_streamable_http_app():
            """包装 streamable_http_app，添加 Token 提取中间件"""
            from starlette.middleware import Middleware
            from starlette.middleware.base import BaseHTTPMiddleware
            from starlette.requests import Request
            from starlette.responses import Response
            
            app = _original_streamable_http_app()
            
            class TokenExtractMiddleware(BaseHTTPMiddleware):
                """从 HTTP 请求头中提取 Bearer Token 并更新 DeviceManager"""
                async def dispatch(self, request: Request, call_next):
                    authorization = request.headers.get("authorization", "")
                    token = _extract_bearer_token(authorization)
                    if token:
                        device_manager.update_auth_token(token)
                    response = await call_next(request)
                    return response
            
            app.add_middleware(TokenExtractMiddleware)
            return app
        
        def _patched_sse_app():
            """包装 sse_app，添加 Token 提取中间件"""
            from starlette.middleware.base import BaseHTTPMiddleware
            from starlette.requests import Request
            
            app = _original_sse_app()
            
            class TokenExtractMiddleware(BaseHTTPMiddleware):
                """从 HTTP 请求头中提取 Bearer Token 并更新 DeviceManager"""
                async def dispatch(self, request: Request, call_next):
                    authorization = request.headers.get("authorization", "")
                    token = _extract_bearer_token(authorization)
                    if token:
                        device_manager.update_auth_token(token)
                    response = await call_next(request)
                    return response
            
            app.add_middleware(TokenExtractMiddleware)
            return app
        
        # 替换原始方法
        mcp.streamable_http_app = _patched_streamable_http_app
        mcp.sse_app = _patched_sse_app
        
        if config.is_sse_mode():
            _log(f"✅ 启动SSE模式服务器: http://{host}:{port}")
            mcp.run(transport="sse")
        else:
            _log(f"✅ 启动Streamable HTTP模式服务器: http://{host}:{port}/mcp")
            mcp.run(transport="streamable-http")
    else:
        raise ValueError(
            f"不支持的运行模式: {config.mode}。\n"
            "支持的模式：\n"
            "  - stdio: 标准输入输出模式（默认，推荐本地使用）\n"
            "  - sse: Server-Sent Events模式\n"
            "  - streamable-http: Streamable HTTP模式\n"
            "\n"
            "配置方式：\n"
            "  - 环境变量: export MCP_MODE=stdio\n"
            "  - 命令行: --mcp-mode stdio\n"
            "  - .env文件: MCP_MODE=stdio"
        )


if __name__ == "__main__":
    main()
