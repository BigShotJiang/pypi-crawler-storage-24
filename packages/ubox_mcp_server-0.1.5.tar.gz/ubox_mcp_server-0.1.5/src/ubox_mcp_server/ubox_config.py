#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
UBox SDK 配置管理

简化配置，支持两种认证方式：

方式一：密钥对认证（适用于所有模式）
- secret_id: UBox SDK密钥ID
- secret_key: UBox SDK密钥

方式二：Token认证（适用于本地模式，通过mcp.json配置）
- auth_token: 通过mcp.json的headers.Authorization传入的Bearer Token

通用参数：
- mode: 运行模式（local/normal）
  - local: 本地模式，默认连接 127.0.0.1:26000
  - normal: 标准模式，连接线上设备
"""

import os
from pathlib import Path
from typing import Dict, Optional
from dotenv import load_dotenv


def _find_dotenv_file() -> Optional[Path]:
    """
    从当前工作目录向上查找 .env 文件，直到找到或到达系统根目录
    
    Returns:
        Path: .env 文件的路径，如果未找到则返回 None
    """
    current = Path.cwd()
    
    # 从当前目录开始向上查找
    for path in [current, *current.parents]:
        env_file = path / ".env"
        if env_file.exists() and env_file.is_file():
            return env_file
        # 如果到达系统根目录，停止查找
        if path == path.parent:
            break
    
    return None


class UBoxConfig:
    """UBox配置管理类"""
    
    def __init__(self):
        """初始化配置"""
        # 查找并加载 .env 文件（从当前工作目录向上查找）
        env_file = _find_dotenv_file()
        if env_file:
            # 如果找到了 .env 文件，加载它
            load_dotenv(dotenv_path=str(env_file), override=True)
        else:
            # 如果没找到，尝试从当前目录加载（兼容原有行为）
            load_dotenv()
        
        # 核心配置参数
        self.secret_id = os.getenv("UBOX_SECRET_ID", "")
        self.secret_key = os.getenv("UBOX_SECRET_KEY", "")
        self.mode = os.getenv("UBOX_MODE", "local").lower()
        
        # Token认证参数（可通过环境变量或mcp.json的headers.Authorization传入）
        self.auth_token = os.getenv("UBOX_AUTH_TOKEN", "")
        
        # 验证配置
        self._validate_config()
    
    def _validate_config(self):
        """验证配置参数"""
        if self.mode not in ["local", "normal"]:
            raise ValueError(f"UBOX_MODE 必须为 'local' 或 'normal'，当前值: {self.mode}")
        
        # 如果有auth_token，则不需要secret_id和secret_key
        if self.auth_token:
            return
        
        # 没有auth_token时，必须提供secret_id和secret_key
        if not self.secret_id:
            raise ValueError(
                "UBOX_SECRET_ID 未设置。请选择以下任一认证方式：\n"
                "  方式一：设置 UBOX_SECRET_ID 和 UBOX_SECRET_KEY 环境变量\n"
                "  方式二：设置 UBOX_AUTH_TOKEN 环境变量，或在mcp.json中配置 Authorization header"
            )
        
        if not self.secret_key:
            raise ValueError(
                "UBOX_SECRET_KEY 未设置。请选择以下任一认证方式：\n"
                "  方式一：设置 UBOX_SECRET_ID 和 UBOX_SECRET_KEY 环境变量\n"
                "  方式二：设置 UBOX_AUTH_TOKEN 环境变量，或在mcp.json中配置 Authorization header"
            )
    
    def get_config(self, config_name: Optional[str] = None) -> Dict:
        """
        获取UBox配置
        
        Args:
            config_name: 配置名称，如果为None则使用环境变量中的UBOX_MODE
            
        Returns:
            dict: 配置字典
        """
        # 如果指定了config_name，使用指定的；否则使用环境变量中的mode
        mode = config_name if config_name else self.mode
        
        config = {
            "mode": mode,
            "secret_id": self.secret_id,
            "secret_key": self.secret_key,
            "auth_token": self.auth_token,
            "env": os.getenv("UBOX_ENV", "formal")  # formal/test
        }
        
        # 如果是本地模式，添加base_url
        if mode == "local":
            config["base_url"] = os.getenv("UBOX_BASE_URL", "127.0.0.1:26000")
        
        return config
    
    def is_local_mode(self) -> bool:
        """是否为本地模式"""
        return self.mode == "local"
    
    def is_normal_mode(self) -> bool:
        """是否为标准模式"""
        return self.mode == "normal"
    
    def has_auth_token(self) -> bool:
        """是否配置了auth_token"""
        return bool(self.auth_token)
    
    def is_config_valid(self) -> bool:
        """
        检查配置是否有效
        
        Returns:
            bool: 配置是否有效
        """
        try:
            # auth_token 或 secret_id+secret_key 任一有效即可
            return bool(self.auth_token) or bool(self.secret_id and self.secret_key)
        except Exception:
            return False
    
    def get_device_config(self) -> Dict:
        """
        获取设备配置（兼容性方法）
        
        Returns:
            dict: 设备配置字典
        """
        return {
            "default_udid": os.getenv("UBOX_DEFAULT_UDID", ""),
            "default_os_type": os.getenv("UBOX_DEFAULT_OS_TYPE", "android"),
            "auth_code": os.getenv("UBOX_AUTH_CODE", "")
        }


# 全局配置实例
ubox_config = UBoxConfig()
