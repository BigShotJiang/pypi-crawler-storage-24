#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
UBox MCP服务器 SSE 模式客户端测试

演示如何使用SSE模式连接并调用UBox MCP服务器的工具
"""

import asyncio
import json
from mcp import ClientSession
from mcp.client.sse import sse_client


async def test_sse_client():
    """测试SSE模式客户端连接和工具调用"""
    print("=" * 60)
    print("🚀 UBox MCP服务器 SSE 模式客户端测试")
    print("=" * 60)
    
    # SSE服务器地址
    sse_url = "http://localhost:8000/sse"
    
    try:
        # 创建与服务器的SSE连接，并返回 read_stream 和 write_stream 流
        print(f"\n📡 正在连接到SSE服务器: {sse_url}")
        async with sse_client(url=sse_url) as (read_stream, write_stream):
            async with ClientSession(read_stream, write_stream) as session:
                # 初始化连接
                print("\n1️⃣ 初始化连接...")
                capabilities = await session.initialize()
                print(f"✅ 连接成功！支持的能力: {capabilities.capabilities}\n")

                # 获取可用工具列表
                print("2️⃣ 获取可用工具列表...")
                tools = await session.list_tools()
                print(f"✅ 可用工具数量: {len(tools.tools)}")
                print("\n📋 工具列表:")
                for i, tool in enumerate(tools.tools, 1):
                    print(f"   {i}. {tool.name} - {tool.description}")
                print()

                # 测试：获取设备列表
                print("3️⃣ 测试工具：get_device_list")
                print("   调用参数: page_num=1, page_size=5")
                result = await session.call_tool(
                    "get_device_list",
                    {
                        "page_num": 1,
                        "page_size": 5
                    }
                )
                print(f"✅ 调用成功！")
                print(f"📊 返回结果:")
                # 格式化输出JSON结果
                if hasattr(result, 'content'):
                    for content in result.content:
                        if hasattr(content, 'text'):
                            try:
                                result_data = json.loads(content.text)
                                print(json.dumps(result_data, ensure_ascii=False, indent=2))
                            except:
                                print(content.text)
                print()

                # 测试：连接设备（如果有可用设备）
                print("4️⃣ 测试工具：connect_device")
                print("   注意：需要确保有可用的设备UDID")
                print("   示例UDID: YOUR_DEVICE_UDID")
                
                # 这里只是示例，实际使用时需要替换为真实的UDID
                # udid = "YOUR_DEVICE_UDID"
                # result = await session.call_tool(
                #     "connect_device",
                #     {
                #         "udid": udid,
                #         "os_type": "android"
                #     }
                # )
                # print(f"✅ 设备连接成功！")
                # print(f"📊 返回结果:")
                # if hasattr(result, 'content'):
                #     for content in result.content:
                #         if hasattr(content, 'text'):
                #             try:
                #                 result_data = json.loads(content.text)
                #                 print(json.dumps(result_data, ensure_ascii=False, indent=2))
                #             except:
                #                 print(content.text)
                
                print("   ⚠️  跳过连接测试（需要真实设备UDID）")
                print()

                # 测试：获取已连接设备列表
                print("5️⃣ 测试工具：get_connected_devices")
                result = await session.call_tool(
                    "get_connected_devices",
                    {}
                )
                print(f"✅ 调用成功！")
                print(f"📊 返回结果:")
                if hasattr(result, 'content'):
                    for content in result.content:
                        if hasattr(content, 'text'):
                            try:
                                result_data = json.loads(content.text)
                                print(json.dumps(result_data, ensure_ascii=False, indent=2))
                            except:
                                print(content.text)
                print()

                print("=" * 60)
                print("✅ SSE模式客户端测试完成！")
                print("=" * 60)

    except Exception as e:
        print(f"\n❌ 请求过程中发生异常: {e}")
        import traceback
        traceback.print_exc()


if __name__ == "__main__":
    """
    运行SSE客户端测试
    
    使用前请确保：
    1. UBox MCP服务器已启动（SSE模式）
    2. 服务器运行在 http://localhost:8000
    3. 已配置正确的UBox环境变量
    
    启动服务器命令：
    export MCP_MODE=sse
    uv run ./src/ubox_mcp_server/server.py
    """
    print("\n💡 使用提示:")
    print("   1. 确保服务器已启动（SSE模式）")
    print("   2. 运行命令: export MCP_MODE=sse && uv run ./src/ubox_mcp_server/server.py")
    print("   3. 然后运行此客户端测试脚本\n")
    
    asyncio.run(test_sse_client())

