#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
UBox功能处理模块（支持多设备管理）

封装UBox SDK的各种功能，为MCP服务器提供统一的接口
支持多设备连接管理和自动authcode处理
参考 example.py 中的实际使用方式重写所有功能
"""

import json
import os
import re
import time
import traceback
from typing import Dict, List, Optional, Any, Union
from ubox_py_sdk.models import DeviceButton, DriverType, OSType
from ubox_py_sdk.device_operations import LogcatTask
from .device_manager import DeviceManager, DeviceConnection


class UBoxHandler:
    """UBox功能处理类（支持多设备）"""
    
    def __init__(self, device_manager: Optional[DeviceManager] = None):
        """
        初始化UBox处理器
        
        Args:
            device_manager: 设备管理器实例，如果不提供则创建新实例
        """
        # 如果没有提供设备管理器，创建一个新实例
        # 这样可以支持共享同一个设备管理器实例，也可以独立使用
        self.device_manager = device_manager if device_manager is not None else DeviceManager()
    
    def _get_device_connection(self, udid: str) -> DeviceConnection:
        """
        获取设备连接对象
        
        Args:
            udid: 设备UDID
            
        Returns:
            DeviceConnection: 设备连接对象
            
        Raises:
            RuntimeError: 设备未连接
        """
        device_connection = self.device_manager.get_device_connection(udid)
        if not device_connection:
            raise RuntimeError(f"设备 {udid} 未连接，请先调用 connect_device 连接设备")
        return device_connection
    
    def _execute_device_operation(self, udid: str, operation_name: str, operation_func, *args, **kwargs) -> Dict[str, Any]:
        """
        执行设备操作的通用方法
        
        Args:
            udid: 设备UDID
            operation_name: 操作名称
            operation_func: 操作函数
            *args: 操作参数
            **kwargs: 操作关键字参数
            
        Returns:
            dict: 操作结果
        """
        try:
            device_connection = self._get_device_connection(udid)
            
            # 使用设备连接锁确保线程安全
            with device_connection.connection_lock:
                # 更新设备活动时间
                self.device_manager.update_device_activity(udid)
                
                # 执行操作
                result = operation_func(device_connection.device, *args, **kwargs)
                
                return {
                    "success": True,
                    "message": f"{operation_name}成功",
                    "data": result if isinstance(result, dict) else {"result": result},
                    "udid": udid
                }
                
        except Exception as e:
            return {
                "success": False,
                "message": f"{operation_name}失败: {str(e)}",
                "error": traceback.format_exc(),
                "udid": udid
            }
    
    # ==================== 设备信息相关 ====================
    
    def get_device_info(self, udid: str) -> Dict[str, Any]:
        """
        获取设备详细信息
        
        参考 device.py: device_info()
        
        返回设备的所有信息，包括：
        - Android设备：包含完整的硬件信息（display、density、os_version、manufacturer、model、cpu、memory、storage等）
        - iOS设备：包含基本信息和scale等iOS特有字段
        
        Returns:
            dict: 包含设备信息、认证信息、显示信息等的字典
        """
        def _get_info(device):
            device_info = device.device_info()
            auth_info = device.get_auth_info()
            
            result = {
                "device_info": device_info or {},
                "auth_info": auth_info or {},
                "udid": device.udid
            }
            
            # 添加设备显示信息
            if device_info:
                display = device_info.get('display', {})
                result["display"] = {
                    "width": display.get('width', 0),
                    "height": display.get('height', 0)
                }
                result["model"] = device_info.get('model', 'Unknown')
            
            # 添加认证信息
            if auth_info:
                result["auth_code"] = auth_info.get('authCode', '')
            
            return result
        
        return self._execute_device_operation(udid, "获取设备信息", _get_info)
    
    # ==================== 截图录制相关 ====================
    
    def screenshot(self, udid: str, label: str = "mcp_screenshot", img_path: str = "./screenshots") -> Dict[str, Any]:
        """
        对设备当前画面进行截图并保存到本地
        
        参考 device.py: screenshot()
        
        Args:
            udid: 设备UDID
            label: 截图文件名
            img_path: 文件保存路径
        
        Returns:
            dict: 包含截图路径等信息的字典
        
        Raises:
            UBoxDeviceError: 截图失败时抛出异常
        """
        def _screenshot(device):
            # 确保目录存在
            os.makedirs(img_path, exist_ok=True)
            
            screenshot_path = device.screenshot(label=label, img_path=img_path)
            
            return {
                "screenshot_path": screenshot_path,
                "label": label,
                "img_path": img_path
            }
        
        # 注意：_screenshot 通过闭包捕获了 label, img_path，不需要作为参数传递
        return self._execute_device_operation(udid, "截图", _screenshot)
    
    def screenshot_base64(self, udid: str) -> Dict[str, Any]:
        """
        对设备当前画面进行截图，返回base64编码的图片数据
        
        参考 device.py: screenshot_base64()
        
        Args:
            udid: 设备UDID
        
        Returns:
            dict: 包含base64编码字符串等信息的字典
        
        Raises:
            UBoxDeviceError: 截图失败时抛出异常
        """
        def _screenshot_base64(device):
            base64_image = device.screenshot_base64()
            
            return {
                "base64_image": base64_image,
                "length": len(base64_image)
            }
        
        return self._execute_device_operation(udid, "Base64截图", _screenshot_base64)
    
    def record_start(self, udid: str, video_path: str) -> Dict[str, Any]:
        """
        开始录制屏幕
        
        参考 device.py: record_start()
        
        Args:
            udid: 设备UDID
            video_path: 录屏的输出文件路径
        
        Returns:
            dict: 包含录制启动状态等信息的字典
        
        Raises:
            UBoxDeviceError: 录制启动失败时抛出异常
        """
        def _record_start(device):
            # 确保目录存在
            video_dir = os.path.dirname(video_path) if os.path.dirname(video_path) else "."
            os.makedirs(video_dir, exist_ok=True)
            
            success = device.record_start(video_path=video_path)
            
            return {
                "started": success,
                "video_path": video_path
            }
        
        # 注意：_record_start 通过闭包捕获了 video_path，不需要作为参数传递
        return self._execute_device_operation(udid, "开始录制", _record_start)
    
    def record_stop(self, udid: str) -> Dict[str, Any]:
        """
        停止录制屏幕
        
        参考 device.py: record_stop()
        
        Args:
            udid: 设备UDID
        
        Returns:
            dict: 包含录制停止状态等信息的字典
        
        Raises:
            UBoxDeviceError: 停止录制失败时抛出异常
        """
        def _record_stop(device):
            success = device.record_stop()
            
            return {
                "stopped": success
            }
        
        return self._execute_device_operation(udid, "停止录制", _record_stop)
    
    # ==================== 点击操作相关 ====================
    
    def click_pos(self, udid: str, pos: Union[List[float], List[int]], 
                  duration: float = 0.05, times: int = 1) -> Dict[str, Any]:
        """
        基于相对坐标进行点击操作
        
        参考 device.py: click_pos()
        
        Args:
            udid: 设备UDID
            pos: 相对坐标，取值区间 [0, 1.0]，格式为 [x, y]
            duration: 点击持续时间，默认为 0.05 秒
            times: 点击次数，默认为 1 次，传入 2 可实现双击效果
        
        Returns:
            dict: 包含点击操作结果等信息的字典
        
        Raises:
            UBoxValidationError: 参数验证失败时抛出异常
            UBoxDeviceError: 操作失败时抛出异常
        """
        def _click_pos(device):
            success = device.click_pos(pos, duration=duration, times=times)
            
            return {
                "clicked": success,
                "position": pos,
                "duration": duration,
                "times": times
            }
        
        # 注意：_click_pos 通过闭包捕获了 pos, duration, times，不需要作为参数传递
        return self._execute_device_operation(udid, "坐标点击", _click_pos)
    
    def click(self, udid: str, loc: str, by: str = "UI", offset: Optional[List[int]] = None, 
              timeout: int = 30, duration: float = 0.05, times: int = 1, 
              crop_box: Optional[List[float]] = None, **kwargs) -> Dict[str, Any]:
        """
        基于多种定位方式执行点击操作
        
        参考 device.py: click()
        
        Args:
            udid: 设备UDID
            loc: 待点击的元素，具体形式需符合基于的点击类型
                - 当by="CV"时，loc为模板图像路径
                - 当by="UI"时，loc为UI元素选择器（XPath）
                - 当by="OCR"时，loc为要识别的文字
                - 当by="POS"时，loc为坐标位置
            by: 查找类型，默认为 "UI"
                - "UI": 原生控件 (UI)
                - "CV": 图像匹配 (CV) - loc参数为模板图像路径
                - "OCR": 文字识别 (OCR)
                - "POS": 坐标 (POS)
                - "GA_UNITY": GA Unity
                - "GA_UE": GA UE
            offset: 偏移，元素定位位置加上偏移为实际操作位置
            timeout: 定位元素的超时时间，默认为 30 秒
            duration: 点击的按压时长，以实现长按，默认为 0.05 秒
            times: 点击次数，以实现双击等效果，默认为 1 次
            crop_box: 需要屏蔽或者保留的区域（百分比坐标）
            **kwargs: 基于不同的查找类型，其他需要的参数
                - 当by="CV"时，支持以下参数：
                    - img: 背景图像路径（可选）
                    - tpl_l: 大尺寸模板图像路径（可选）
                    - threshold: 匹配阈值，默认0.8
                    - pos: 目标坐标，用于辅助定位
                    - pos_weight: 坐标辅助定位权重，默认0.05
                    - ratio_lv: 缩放范围，默认21
                    - is_translucent: 是否半透明，默认False
                    - to_gray: 是否转灰度，默认False
                    - deviation: 偏差参数
                    - time_interval: 循环查找间隔，默认0.5秒
        
        Returns:
            dict: 包含点击操作结果等信息的字典
        
        Raises:
            UBoxValidationError: 参数验证失败时抛出异常
            UBoxDeviceError: 操作失败时抛出异常
        """
        def _click(device):
            # 转换by参数
            driver_type_map = {
                "UI": DriverType.UI,
                "CV": DriverType.CV,
                "OCR": DriverType.OCR,
                "POS": DriverType.POS
            }
            driver_type = driver_type_map.get(by.upper(), DriverType.UI)
            
            success = device.click(
                loc=loc,
                by=driver_type,
                offset=offset,
                timeout=timeout,
                duration=duration,
                times=times,
                crop_box=crop_box,
                **kwargs
            )
            
            return {
                "clicked": success,
                "location": loc,
                "by": by,
                "offset": offset,
                "timeout": timeout,
                "duration": duration,
                "times": times,
                "crop_box": crop_box
            }
        
        # 注意：_click 通过闭包捕获了所有参数，不需要作为参数传递
        return self._execute_device_operation(udid, "智能点击", _click)
    
    def long_click(self, udid: str, loc: str, by: str = "UI", 
                   duration: float = 1.0, timeout: int = 30, 
                   crop_box: Optional[List[float]] = None, **kwargs) -> Dict[str, Any]:
        """
        执行长按操作
        
        参考 device.py: long_click()
        
        Args:
            udid: 设备UDID
            loc: 待操作的元素，具体形式需符合基于的操作类型
            by: 查找类型，默认为 "UI" (UI)
            duration: 点击的按压时长，默认为 1 秒
            timeout: 定位元素的超时时间，默认为 30 秒
            crop_box: 需要屏蔽或者保留的区域（百分比坐标）
            **kwargs: 基于不同的查找类型，其他需要的参数
        
        Returns:
            dict: 包含长按操作结果等信息的字典
        
        Raises:
            UBoxValidationError: 参数验证失败时抛出异常
            UBoxDeviceError: 操作失败时抛出异常
        """
        def _long_click(device):
            driver_type_map = {
                "UI": DriverType.UI,
                "CV": DriverType.CV,
                "OCR": DriverType.OCR,
                "POS": DriverType.POS
            }
            driver_type = driver_type_map.get(by.upper(), DriverType.UI)
            
            success = device.long_click(
                loc=loc,
                by=driver_type,
                duration=duration,
                timeout=timeout,
                crop_box=crop_box,
                **kwargs
            )
            
            return {
                "long_clicked": success,
                "location": loc,
                "by": by,
                "duration": duration,
                "timeout": timeout,
                "crop_box": crop_box
            }
        
        # 注意：_long_click 通过闭包捕获了所有参数，不需要作为参数传递
        return self._execute_device_operation(udid, "长按操作", _long_click)
    
    # ==================== 滑动操作相关 ====================
    
    def slide_pos(self, udid: str, pos_from: Union[List[float], List[int]], 
                  pos_to: Union[List[float], List[int]], 
                  slide_duration: float = 0.3, down_duration: float = 0) -> Dict[str, Any]:
        """
        基于坐标执行滑动操作（支持相对坐标和像素坐标）
        
        参考 device.py: slide_pos()
        
        Args:
            udid: 设备UDID
            pos_from: 滑动起始坐标，格式为 [x, y]
                - 相对坐标：所有值在 [0, 1.0] 之间，例如 [0.5, 0.5] 表示屏幕中心
                - 像素坐标：值大于 1，例如 [540, 960] 表示像素坐标
            pos_to: 滑动结束坐标，格式为 [x, y]
                - 相对坐标：所有值在 [0, 1.0] 之间，例如 [0.5, 0.8] 表示屏幕中下方
                - 像素坐标：值大于 1，例如 [540, 1200] 表示像素坐标
            down_duration: 起始位置按下时长（秒），以实现拖拽功能，默认为 0
            slide_duration: 滑动时间，默认为 0.3 秒
        
        Returns:
            dict: 包含滑动操作结果等信息的字典
        
        Raises:
            UBoxValidationError: 参数验证失败时抛出异常
            UBoxDeviceError: 操作失败时抛出异常
        
        Note:
            - 坐标系统自动识别：
              * 相对坐标：[0, 0] 表示屏幕左上角，[1, 1] 表示屏幕右下角
              * 像素坐标：直接使用设备屏幕的实际像素值
            - pos_from 和 pos_to 必须使用相同的坐标系统（都是相对坐标或都是像素坐标）
            - 通过设置 down_duration 可以实现拖拽效果
        """
        def _slide_pos(device):
            success = device.slide_pos(
                pos_from, 
                pos_to, 
                slide_duration=slide_duration,
                down_duration=down_duration
            )
            
            return {
                "slid": success,
                "from": pos_from,
                "to": pos_to,
                "slide_duration": slide_duration,
                "down_duration": down_duration
            }
        
        return self._execute_device_operation(udid, "坐标滑动", _slide_pos)
    
    def slide(self, udid: str, loc_from: str, loc_to: Optional[str] = None, by: str = "UI", 
              timeout: int = 120, down_duration: float = 0, slide_duration: float = 0.3,
              **kwargs) -> Dict[str, Any]:
        """
        基于多种定位方式执行滑动操作
        
        参考 device.py: slide()
        
        Args:
            udid: 设备UDID
            loc_from: 滑动起始元素位置
            loc_to: 滑动结束元素位置，为 None 时则根据 loc_shift 滑动
            by: 查找类型，默认为 "UI" (UI)
            timeout: 定位元素的超时时间，默认为 120 秒
            down_duration: 起始位置按下时长（秒），以实现拖拽功能，默认为 0
            slide_duration: 滑动时间，默认为 0.3 秒
            **kwargs: 基于不同的查找类型，其他需要的参数
        
        Returns:
            dict: 包含滑动操作结果等信息的字典
        
        Raises:
            UBoxValidationError: 参数验证失败时抛出异常
            UBoxDeviceError: 操作失败时抛出异常
        """
        def _slide(device):
            driver_type_map = {
                "UI": DriverType.UI,
                "CV": DriverType.CV,
                "OCR": DriverType.OCR,
                "POS": DriverType.POS
            }
            driver_type = driver_type_map.get(by.upper(), DriverType.POS)
            
            success = device.slide(
                loc_from=loc_from,
                loc_to=loc_to,
                by=driver_type,
                timeout=timeout,
                down_duration=down_duration,
                slide_duration=slide_duration,
                **kwargs
            )
            
            return {
                "slid": success,
                "from": loc_from,
                "to": loc_to,
                "by": by,
                "timeout": timeout,
                "down_duration": down_duration,
                "slide_duration": slide_duration
            }
        
        # 注意：_slide 通过闭包捕获了所有参数，不需要作为参数传递
        return self._execute_device_operation(udid, "智能滑动", _slide)
    
    # ==================== 文本输入相关 ====================
    
    def input_text(self, udid: str, text: str, timeout: int = 30, depth: int = 10) -> Dict[str, Any]:
        """
        向设备输入文本内容
        
        参考 device.py: input_text()
        
        Args:
            udid: 设备UDID
            text: 待输入的文本
            timeout: 超时时间，默认为 30 秒
            depth: source tree 的最大深度值，用于查找输入框，默认为 10
        
        Returns:
            dict: 包含输入操作结果等信息的字典
        
        Raises:
            UBoxValidationError: 参数验证失败时抛出异常
            UBoxDeviceError: 操作失败时抛出异常
        """
        def _input_text(device):
            success = device.input_text(text, timeout=timeout, depth=depth)
            
            return {
                "input_success": success,
                "text": text,
                "timeout": timeout,
                "depth": depth
            }
        
        # 注意：_input_text 通过闭包捕获了所有参数，不需要作为参数传递
        return self._execute_device_operation(udid, "文本输入", _input_text)
    
    # ==================== 按键操作相关 ====================
    
    def press(self, udid: str, button: str) -> Dict[str, Any]:
        """
        执行设备功能键操作
        
        参考 device.py: press()
        
        Args:
            udid: 设备UDID
            button: 设备按键类型，支持的按键包括：
                - HOME: 主页键
                - BACK: 返回键
                - VOLUME_UP: 音量上键
                - VOLUME_DOWN: 音量下键
                - POWER: 电源键
                - DEL: 删除键
                - FORWARD_DEL: 向前删除键
                - MENU: 菜单键
                - RECENT_APP: 最近应用键
                - WAKE_UP: 唤醒键
                - SLEEP: 休眠键
        
        Returns:
            dict: 包含按键操作结果等信息的字典
        
        Raises:
            UBoxValidationError: 参数验证失败时抛出异常
            UBoxDeviceError: 操作失败时抛出异常
        """
        def _press(device):
            button_map = {
                "HOME": DeviceButton.HOME,
                "BACK": DeviceButton.BACK,
                "VOLUME_UP": DeviceButton.VOLUME_UP,
                "VOLUME_DOWN": DeviceButton.VOLUME_DOWN,
                "POWER": DeviceButton.POWER,
                "DEL": DeviceButton.DEL,
                "FORWARD_DEL": DeviceButton.FORWARD_DEL,
                "MENU": DeviceButton.MENU,
                "RECENT_APP": DeviceButton.RECENT_APP,
                "WAKE_UP": DeviceButton.WAKE_UP,
                "SLEEP": DeviceButton.SLEEP
            }
            
            device_button = button_map.get(button.upper())
            if not device_button:
                raise ValueError(f"不支持的按键: {button}。支持的按键: {list(button_map.keys())}")
            
            success = device.press(device_button)
            
            return {
                "pressed": success,
                "button": button
            }
        
        # 注意：_press 通过闭包捕获了 button，不需要作为参数传递
        return self._execute_device_operation(udid, "按键操作", _press)
    
    # ==================== 应用管理相关 ====================
    
    def start_app(self, udid: str, package: str, clear_data: bool = False, **kwargs) -> Dict[str, Any]:
        """
        启动应用
        
        参考 device.py: start_app()
        
        Args:
            udid: 设备UDID
            package: iOS 为应用 bundle id，Android 和鸿蒙对应为包名
            clear_data: 可缺省，默认为 False。仅 Android、HM 相关，清除应用数据，iOS不支持
            **kwargs: 其他扩展参数
        
        Returns:
            dict: 包含启动操作结果等信息的字典
        
        Raises:
            UBoxValidationError: 参数验证失败时抛出异常
            UBoxDeviceError: 操作失败时抛出异常
        """
        def _start_app(device):
            success = device.start_app(package, clear_data=clear_data, **kwargs)
            
            return {
                "started": success,
                "package": package,
                "clear_data": clear_data
            }
        
        # 注意：_start_app 通过闭包捕获了所有参数，不需要作为参数传递
        return self._execute_device_operation(udid, "启动应用", _start_app)
    
    def stop_app(self, udid: str, package: str) -> Dict[str, Any]:
        """
        停止应用
        
        参考 device.py: stop_app()
        
        Args:
            udid: 设备UDID
            package: iOS 为应用 bundle id，Android 和鸿蒙对应为包名
        
        Returns:
            dict: 包含停止操作结果等信息的字典
        
        Raises:
            UBoxValidationError: 参数验证失败时抛出异常
            UBoxDeviceError: 操作失败时抛出异常
        """
        def _stop_app(device):
            success = device.stop_app(package)
            
            return {
                "stopped": success,
                "package": package
            }
        
        # 注意：_stop_app 通过闭包捕获了 package，不需要作为参数传递
        return self._execute_device_operation(udid, "停止应用", _stop_app)
    
    def current_app(self, udid: str) -> Dict[str, Any]:
        """
        获取当前应用
        
        参考 device.py: current_app()
        
        Args:
            udid: 设备UDID
        
        Returns:
            dict: 包含当前应用的包名或bundle ID的字典
                - iOS设备返回bundle ID
                - Android和鸿蒙设备返回package name
        
        Raises:
            UBoxDeviceError: 操作失败时抛出异常
        """
        def _current_app(device):
            current_pkg = device.current_app()
            
            return {
                "current_app": current_pkg
            }
        
        return self._execute_device_operation(udid, "获取当前应用", _current_app)
    
    def app_list_running(self, udid: str) -> Dict[str, Any]:
        """
        获取正在运行的app列表
        
        参考 device.py: app_list_running()
        
        Args:
            udid: 设备UDID
        
        Returns:
            dict: 包含正在运行的app的包名列表的字典
                - Android和鸿蒙设备返回package name列表
                - iOS设备返回bundle ID列表
        
        Raises:
            UBoxDeviceError: 操作失败时抛出异常
        """
        def _app_list_running(device):
            running_apps = device.app_list_running()
            
            return {
                "running_apps": running_apps or [],
                "count": len(running_apps) if running_apps else 0
            }
        
        return self._execute_device_operation(udid, "获取运行应用列表", _app_list_running)
    
    # ==================== ADB命令相关 ====================
    
    def cmd_adb(self, udid: str, cmd: Union[str, List[str]], timeout: int = 10) -> Dict[str, Any]:
        """
        执行 ADB 命令
        
        参考 device.py: cmd_adb()
        
        Args:
            udid: 设备UDID
            cmd: 要执行的 ADB 命令，例如 "ls", "ps", "getprop" 等，可以是字符串或列表
            timeout: 执行命令的超时时间，默认为 10 秒
        
        Returns:
            dict: 包含命令执行结果的字典
                - 安卓设备返回 (output, exit_code) 元组
                - 鸿蒙设备返回 output 字符串
        
        Raises:
            ValueError: 设备类型不支持ADB命令时抛出异常
            UBoxDeviceError: 操作失败时抛出异常
        
        Note:
            - 此功能仅支持Android和鸿蒙设备
        """
        def _cmd_adb(device):
            # 检查设备类型
            if device.os_type not in [OSType.ANDROID, OSType.HM]:
                raise ValueError(f"ADB命令仅支持Android和鸿蒙设备，当前设备类型: {device.os_type}")
            
            result = device.cmd_adb(cmd, timeout=timeout)
            
            return {
                "command": cmd,
                "result": result,
                "timeout": timeout
            }
        
        # 注意：_cmd_adb 通过闭包捕获了 cmd, timeout，不需要作为参数传递
        return self._execute_device_operation(udid, "执行ADB命令", _cmd_adb)
    
    # ==================== UI查找相关 ====================
    
    def find_ui(self, udid: str, xpath: str, timeout: int = 30, **kwargs) -> Dict[str, Any]:
        """
        基于控件查找
        
        参考 device.py: find_ui()
        
        Args:
            udid: 设备UDID
            xpath: 控件xpath
            timeout: 查找超时时间，默认为 30 秒
            **kwargs: 其他扩展参数
        
        Returns:
            dict: 包含查找结果的字典，查找到的中心点坐标
        
        Raises:
            UBoxValidationError: 参数验证失败时抛出异常
            UBoxDeviceError: 操作失败时抛出异常
        """
        def _find_ui(device):
            result = device.find_ui(xpath, timeout=timeout, **kwargs)
            
            return {
                "found": result is not None,
                "xpath": xpath,
                "result": result,
                "timeout": timeout
            }
        
        # 注意：_find_ui 通过闭包捕获了所有参数，不需要作为参数传递
        return self._execute_device_operation(udid, "UI控件查找", _find_ui)
    
    def find_ocr(self, udid: str, word: str, timeout: int = 30, 
                 time_interval: float = 0.5, crop_box: Optional[List[float]] = None,
                 **kwargs) -> Dict[str, Any]:
        """
        基于OCR文字识别的查找
        
        参考 device.py: find_ocr()
        
        Args:
            udid: 设备UDID
            word: 待查找文字
            timeout: 查找超时时间，默认为 30 秒
            time_interval: 循环查找的时间间隔，默认为 0.5 秒
            crop_box: 屏蔽范围或者保留范围，均为百分比
                - 保留范围: 保留矩形范围的<左上角顶点>坐标和<右下角>坐标，示例 [[0.3, 0.3], [0.7, 0.7]]
                - 屏蔽范围: [0, 1, 0, 0.3] 屏蔽x轴 0-1, y轴0-0.3的部分
            **kwargs: 其他扩展参数（可能包含left_word, right_word等辅助定位参数）
        
        Returns:
            dict: 包含查找结果的字典，查找到的中心点坐标，未找到则返回None
        
        Raises:
            UBoxValidationError: 参数验证失败时抛出异常
            UBoxDeviceError: 操作失败时抛出异常
        """
        def _find_ocr(device):
            # 如果提供了裁剪参数，转换为元组格式
            if crop_box and len(crop_box) == 4:
                crop_tuple = tuple(crop_box)
            else:
                crop_tuple = None
            
            result = device.find_ocr(word, timeout=timeout, time_interval=time_interval, 
                                     crop_box=crop_tuple, **kwargs)
            
            return {
                "found": result is not None,
                "word": word,
                "result": result,
                "timeout": timeout,
                "time_interval": time_interval,
                "crop_box": crop_box
            }
        
        # 注意：_find_ocr 通过闭包捕获了所有参数，不需要作为参数传递
        return self._execute_device_operation(udid, "OCR文字查找", _find_ocr)
    
    def find_cv(self, udid: str, tpl: str, img: Optional[str] = None, threshold: float = 0.8, 
                timeout: int = 30, pos: Optional[List[float]] = None, pos_weight: float = 0.05,
                ratio_lv: int = 21, crop_box: Optional[List[float]] = None,
                is_translucent: bool = False, to_gray: bool = False,
                tpl_l: Optional[str] = None, deviation: Optional[List[float]] = None,
                time_interval: float = 0.5, **kwargs) -> Dict[str, Any]:
        """
        基于多尺寸模板匹配的图像查找
        
        参考 device.py: find_cv()
        
        Args:
            udid: 设备UDID
            tpl: 待匹配查找的目标图像路径
            img: 在该图上进行查找，为None时则获取当前设备画面
            timeout: 查找超时时间，默认为 30 秒
            threshold: 匹配阈值 (0-1.0)，默认为 0.8
            pos: 目标图像的坐标，以辅助定位图像位置
            pos_weight: 坐标辅助定位的权重，默认为 0.05
            ratio_lv: 缩放范围，数值越大则进行更大尺寸范围的匹配查找，默认为 21
            crop_box: 屏蔽范围或者保留范围，均为百分比
                - 保留范围: 保留矩形范围的<左上角顶点>坐标和<右下角>坐标，示例 [[0.3, 0.3], [0.7, 0.7]]
                - 屏蔽范围: [0, 1, 0, 0.3] 屏蔽x轴 0-1, y轴0-0.3的部分
            is_translucent: 目标图像是否为半透明，为True则会进行图像预处理，默认为 False
            to_gray: 是否将图像转换为灰度图，默认为 False
            tpl_l: 备选的尺寸更大的目标图像路径，以辅助定位
            deviation: 偏差，目标及备选目标间的偏差
            time_interval: 循环查找的时间间隔，默认为 0.5 秒
            **kwargs: 其他扩展参数
        
        Returns:
            dict: 包含查找结果的字典，查找到的坐标，未找到则返回None
        
        Raises:
            UBoxValidationError: 参数验证失败时抛出异常
            UBoxDeviceError: 操作失败时抛出异常
        """
        def _find_cv(device):
            # 如果提供了裁剪参数，转换为元组格式
            if crop_box and len(crop_box) == 4:
                crop_tuple = tuple(crop_box)
            else:
                crop_tuple = None
            
            # 处理pos参数
            pos_tuple = tuple(pos) if pos and len(pos) == 2 else None
            
            # 处理deviation参数
            deviation_tuple = tuple(deviation) if deviation and len(deviation) == 2 else None
            
            result = device.find_cv(
                tpl=tpl,
                img=img,
                threshold=threshold,
                timeout=timeout,
                pos=pos_tuple,
                pos_weight=pos_weight,
                ratio_lv=ratio_lv,
                crop_box=crop_tuple,
                is_translucent=is_translucent,
                to_gray=to_gray,
                tpl_l=tpl_l,
                deviation=deviation_tuple,
                time_interval=time_interval,
                **kwargs
            )
            
            return {
                "found": result is not None,
                "template": tpl,
                "result": result,
                "threshold": threshold,
                "timeout": timeout,
                "crop_box": crop_box
            }
        
        # 注意：_find_cv 通过闭包捕获了所有参数，不需要作为参数传递
        return self._execute_device_operation(udid, "CV图像查找", _find_cv)
    
    def get_element_cv(self, udid: str, tpl: str, img: Optional[str] = None, 
                       timeout: int = 30, threshold: float = 0.8,
                       pos: Optional[List[float]] = None, pos_weight: float = 0.05,
                       ratio_lv: int = 21, crop_box: Optional[List[float]] = None,
                       is_translucent: bool = False, to_gray: bool = False,
                       tpl_l: Optional[str] = None, deviation: Optional[List[float]] = None,
                       time_interval: float = 0.5, **kwargs) -> Dict[str, Any]:
        """
        基于多尺寸模板匹配的图像查找，返回元素边界信息
        
        参考 device.py: get_element_cv()
        
        Args:
            udid: 设备UDID
            tpl: 待匹配查找的目标图像路径
            img: 在该图上进行查找，为None时则获取当前设备画面
            timeout: 查找超时时间，默认为 30 秒
            threshold: 匹配阈值，默认为 0.8
            pos: 目标图像的坐标，以辅助定位图像位置
            pos_weight: 坐标辅助定位的权重，默认为 0.05
            ratio_lv: 缩放范围，数值越大则进行更大尺寸范围的匹配查找，默认为 21
            crop_box: 屏蔽范围或者保留范围，均为百分比
                - 保留范围: 保留矩形范围的<左上角顶点>坐标和<右下角>坐标，示例 [[0.3, 0.3], [0.7, 0.7]]
                - 屏蔽范围: [0, 1, 0, 0.3] 屏蔽x轴 0-1, y轴0-0.3的部分
            is_translucent: 目标图像是否为半透明，为True则会进行图像预处理，默认为 False
            to_gray: 是否将图像转换为灰度图，默认为 False
            tpl_l: 备选的尺寸更大的目标图像路径，以辅助定位
            deviation: 偏差，目标及备选目标间的偏差
            time_interval: 循环查找的时间间隔，默认为 0.5 秒
            **kwargs: 其他扩展参数
        
        Returns:
            dict: 包含元素边界信息的字典，格式为 {'bounds': [x1, y1, x2, y2]}
        
        Raises:
            UBoxDeviceError: 操作失败时抛出异常
        """
        def _get_element_cv(device):
            if crop_box and len(crop_box) == 4:
                crop_tuple = tuple(crop_box)
            else:
                crop_tuple = None
            
            # 处理pos参数
            pos_tuple = tuple(pos) if pos and len(pos) == 2 else None
            
            # 处理deviation参数
            deviation_tuple = tuple(deviation) if deviation and len(deviation) == 2 else None
            
            result = device.get_element_cv(
                tpl=tpl,
                img=img,
                timeout=timeout,
                threshold=threshold,
                pos=pos_tuple,
                pos_weight=pos_weight,
                ratio_lv=ratio_lv,
                crop_box=crop_tuple,
                is_translucent=is_translucent,
                to_gray=to_gray,
                tpl_l=tpl_l,
                deviation=deviation_tuple,
                time_interval=time_interval,
                **kwargs
            )
            
            return {
                "found": result is not None,
                "element": result,
                "bounds": result.get('bounds') if result else None,
                "template": tpl
            }
        
        # 注意：_get_element_cv 通过闭包捕获了所有参数，不需要作为参数传递
        return self._execute_device_operation(udid, "CV元素获取", _get_element_cv)
    
    def get_element_ocr(self, udid: str, word: str, crop_box: Optional[List[float]] = None,
                        timeout: int = 30, time_interval: float = 0.5, **kwargs) -> Dict[str, Any]:
        """
        基于OCR文字识别的查找，返回元素边界信息
        
        参考 device.py: get_element_ocr()
        
        Args:
            udid: 设备UDID
            word: 待查找文字
            crop_box: 屏蔽范围或者保留范围，均为百分比
                - 保留范围: 保留矩形范围的<左上角顶点>坐标和<右下角>坐标，示例 [[0.3, 0.3], [0.7, 0.7]]
                - 屏蔽范围: [0, 1, 0, 0.3] 屏蔽x轴 0-1, y轴0-0.3的部分
            timeout: 查找超时时间，默认为 30 秒
            time_interval: 循环查找的时间间隔，默认为 0.5 秒
            **kwargs: 其他扩展参数（可能包含left_word, right_word等辅助定位参数）
        
        Returns:
            dict: 包含元素边界信息的字典，格式为 {'bounds': [x1, y1, x2, y2]}
        
        Raises:
            UBoxDeviceError: 操作失败时抛出异常
        """
        def _get_element_ocr(device):
            if crop_box and len(crop_box) == 4:
                crop_tuple = tuple(crop_box)
            else:
                crop_tuple = None
            
            result = device.get_element_ocr(
                word=word,
                crop_box=crop_tuple,
                timeout=timeout,
                time_interval=time_interval,
                **kwargs
            )
            
            return {
                "found": result is not None,
                "element": result,
                "bounds": result.get('bounds') if result else None,
                "word": word
            }
        
        # 注意：_get_element_ocr 通过闭包捕获了所有参数，不需要作为参数传递
        return self._execute_device_operation(udid, "OCR元素获取", _get_element_ocr)
    
    def get_uitree(self, udid: str, xml: bool = False) -> Dict[str, Any]:
        """
        获取控件树（带自动重试和ADB降级机制）
        
        参考 device.py: get_uitree()
        
        获取策略：
        1. 先通过SDK获取控件树，失败时自动重试最多3次，每次间隔2秒
        2. 若SDK重试全部失败，自动降级使用ADB命令(uiautomator dump)获取控件树
        
        常见失败原因：设备端页面未渲染完成、WebView页面、系统弹窗等。
        
        Args:
            udid: 设备UDID
            xml: 为True时返回xml格式数据，否则json格式，默认为 False
        
        Returns:
            dict: 包含控件树数据的字典
        
        Raises:
            UBoxDeviceError: 所有方式均失败时抛出异常
        """
        import time as _time
        
        # ===== 阶段1：通过SDK获取控件树（带重试） =====
        max_retries = 3
        retry_interval = 2  # 每次重试间隔秒数
        last_error = None
        
        for attempt in range(1, max_retries + 1):
            def _get_uitree(device):
                result = device.get_uitree(xml=xml)
                
                return {
                    "uitree": result,
                    "format": "xml" if xml else "json",
                    "length": len(str(result)) if result else 0
                }
            
            # 注意：_get_uitree 通过闭包捕获了 xml，不需要作为参数传递
            response = self._execute_device_operation(udid, "获取UI树", _get_uitree)
            
            if response.get("success"):
                # 成功获取，如果经过了重试则附加提示信息
                if attempt > 1:
                    response["message"] = f"获取UI树成功（第{attempt}次尝试）"
                return response
            
            # 失败，记录错误并准备重试
            last_error = response
            if attempt < max_retries:
                _time.sleep(retry_interval)
        
        # ===== 阶段2：SDK失败，降级使用ADB命令获取控件树 =====
        try:
            adb_result = self._get_uitree_by_adb(udid)
            if adb_result and adb_result.get("success"):
                adb_result["message"] = "通过ADB降级方式获取UI树成功（SDK方式失败后自动切换）"
                return adb_result
        except Exception:
            pass  # ADB方式也失败，返回原始错误
        
        # 所有方式均失败，返回错误信息并附加提示
        if last_error:
            last_error["message"] = (
                f"获取UI树失败（SDK重试{max_retries}次 + ADB降级均失败）: {last_error.get('message', '')}\n"
                f"建议: 1. 确认设备页面已加载完成 "
                f"2. 尝试断开并重新连接设备 "
                f"3. 如果是WebView/游戏页面，请改用OCR方式定位元素"
            )
        return last_error
    
    def _get_uitree_by_adb(self, udid: str) -> Dict[str, Any]:
        """
        通过ADB命令获取控件树（降级方案）
        
        使用 uiautomator dump 命令将控件树导出到设备文件，
        然后通过 cat 命令读取文件内容。
        
        Args:
            udid: 设备UDID
            
        Returns:
            dict: 包含控件树数据的字典
        """
        dump_path = "/sdcard/ui_dump.xml"
        
        # 步骤1：使用 uiautomator dump 导出控件树到设备文件
        dump_response = self.cmd_adb(udid=udid, cmd=f"uiautomator dump {dump_path}", timeout=15)
        if not dump_response.get("success"):
            return dump_response
        
        # 检查 uiautomator dump 命令的退出码（返回格式可能是 [output, exit_code]）
        dump_result = dump_response.get("data", {}).get("result", "")
        if isinstance(dump_result, (list, tuple)) and len(dump_result) >= 2:
            dump_exit_code = dump_result[1]
            dump_output = str(dump_result[0]) if dump_result[0] else ""
            # 退出码非0表示命令执行失败（如被Killed时退出码为137）
            if dump_exit_code != 0:
                return {
                    "success": False,
                    "message": f"通过ADB获取UI树失败：uiautomator dump命令执行失败（退出码: {dump_exit_code}，输出: {dump_output.strip()}）",
                    "udid": udid
                }
        
        # 步骤2：读取导出的控件树文件内容
        cat_response = self.cmd_adb(udid=udid, cmd=f"cat {dump_path}", timeout=10)
        if not cat_response.get("success"):
            return cat_response
        
        # 提取控件树内容
        adb_result = cat_response.get("data", {}).get("result", "")
        # ADB命令返回可能是元组 (output, exit_code)
        if isinstance(adb_result, (list, tuple)) and len(adb_result) > 0:
            uitree_content = str(adb_result[0]) if adb_result[0] else ""
            # 检查 cat 命令的退出码
            if len(adb_result) >= 2 and adb_result[1] != 0:
                return {
                    "success": False,
                    "message": f"通过ADB获取UI树失败：读取dump文件失败（退出码: {adb_result[1]}，输出: {uitree_content.strip()}）",
                    "udid": udid
                }
        else:
            uitree_content = str(adb_result)
        
        # 步骤3：清理临时文件
        self.cmd_adb(udid=udid, cmd=f"rm -f {dump_path}", timeout=5)
        
        # 校验返回内容是否为有效的XML控件树（应以 <?xml 或 <hierarchy 开头）
        stripped_content = uitree_content.strip()
        if stripped_content and len(stripped_content) > 0:
            # 检查内容是否包含错误信息而非有效XML
            error_indicators = ["No such file or directory", "Permission denied", "not found", "error", "Killed"]
            if not stripped_content.startswith("<") and any(err in stripped_content for err in error_indicators):
                return {
                    "success": False,
                    "message": f"通过ADB获取UI树失败：返回内容非有效XML（{stripped_content[:200]}）",
                    "udid": udid
                }
            
            return {
                "success": True,
                "message": "通过ADB获取UI树成功",
                "data": {
                    "uitree": stripped_content,
                    "format": "xml",
                    "length": len(stripped_content),
                    "source": "adb_fallback"
                },
                "udid": udid
            }
        else:
            return {
                "success": False,
                "message": "通过ADB获取UI树失败：导出内容为空",
                "udid": udid
            }
    
    # ==================== 剪贴板操作 ====================
    
    def set_clipboard(self, udid: str, text: str) -> Dict[str, Any]:
        """
        设置剪贴板
        
        参考 device.py: set_clipboard()
        
        Args:
            udid: 设备UDID
            text: 设置的文本
        
        Returns:
            dict: 包含操作结果的字典
        
        Raises:
            UBoxValidationError: 参数验证失败时抛出异常
            UBoxDeviceError: 操作失败时抛出异常
        """
        def _set_clipboard(device):
            device.set_clipboard(text)
            
            return {
                "text": text,
                "set": True
            }
        
        # 注意：_set_clipboard 通过闭包捕获了 text，不需要作为参数传递
        return self._execute_device_operation(udid, "设置剪贴板", _set_clipboard)
    
    def get_clipboard(self, udid: str) -> Dict[str, Any]:
        """
        获取剪贴板
        
        参考 device.py: get_clipboard()
        
        Args:
            udid: 设备UDID
        
        Returns:
            dict: 包含剪贴板文本内容的字典
        
        Raises:
            UBoxDeviceError: 操作失败时抛出异常
        """
        def _get_clipboard(device):
            content = device.get_clipboard()
            
            return {
                "content": content or ""
            }
        
        return self._execute_device_operation(udid, "获取剪贴板", _get_clipboard)
    
    # ==================== 应用安装相关 ====================
    
    def install_app(self, udid: str, app_url: Optional[str] = None, 
                    app_path: Optional[str] = None, need_resign: bool = False,
                    resign_bundle: str = "") -> Dict[str, Any]:
        """
        安装应用到设备
        
        参考 device.py: install_app()
        
        Args:
            udid: 设备UDID
            app_url: 安装包url链接，可下载的cos链接
            app_path: 安装包本地地址(手机所在的client本地地址，本地调试预留、请勿使用此字段)
            need_resign: 可缺省，默认为 False。只有 iOS 涉及，需要重签名时传入 True
            resign_bundle: 可缺省，默认为空。只有 iOS 涉及，need_resign 为 True 时，此参数必须传入非空的 bundleId
        
        Returns:
            dict: 包含安装操作结果等信息的字典
        
        Raises:
            UBoxValidationError: 参数验证失败时抛出异常
            UBoxDeviceError: 操作失败时抛出异常
        """
        def _install_app(device):
            result = device.install_app(
                app_url=app_url,
                app_path=app_path,
                need_resign=need_resign,
                resign_bundle=resign_bundle
            )
            
            return {
                "installed": result,
                "app_url": app_url,
                "app_path": app_path,
                "need_resign": need_resign,
                "resign_bundle": resign_bundle
            }
        
        # 注意：_install_app 通过闭包捕获了所有参数，不需要作为参数传递
        return self._execute_device_operation(udid, "安装应用", _install_app)
    
    def local_install_app(self, udid: str, local_app_path: str, need_resign: bool = False,
                          resign_bundle: str = "") -> Dict[str, Any]:
        """
        安装应用到设备（本地安装）
        
        参考 device.py: local_install_app()
        
        Args:
            udid: 设备UDID
            local_app_path: 安装包本地地址
            need_resign: 可缺省，默认为 False。只有 iOS 涉及，需要重签名时传入 True
            resign_bundle: 可缺省，默认为空。只有 iOS 涉及，need_resign 为 True 时，此参数必须传入非空的 bundleId
        
        Returns:
            dict: 包含安装操作结果等信息的字典
        
        Raises:
            UBoxValidationError: 参数验证失败时抛出异常
            UBoxDeviceError: 操作失败时抛出异常
        """
        def _local_install_app(device):
            result = device.local_install_app(
                local_app_path=local_app_path,
                need_resign=need_resign,
                resign_bundle=resign_bundle
            )
            
            return {
                "installed": result,
                "local_app_path": local_app_path,
                "need_resign": need_resign,
                "resign_bundle": resign_bundle
            }
        
        # 注意：_local_install_app 通过闭包捕获了所有参数，不需要作为参数传递
        return self._execute_device_operation(udid, "本地安装应用", _local_install_app)
    
    def uninstall_app(self, udid: str, package: str) -> Dict[str, Any]:
        """
        从设备卸载应用
        
        参考 device.py: uninstall_app()
        
        Args:
            udid: 设备UDID
            package: 被卸载应用的包名，Android 和鸿蒙为应用的 packageName，iOS 则对应为 bundleId
        
        Returns:
            dict: 包含卸载操作结果等信息的字典
        
        Raises:
            UBoxValidationError: 参数验证失败时抛出异常
            UBoxDeviceError: 操作失败时抛出异常
        """
        def _uninstall_app(device):
            result = device.uninstall_app(pkg=package)
            
            return {
                "uninstalled": result,
                "package": package
            }
        
        # 注意：_uninstall_app 通过闭包捕获了 package，不需要作为参数传递
        return self._execute_device_operation(udid, "卸载应用", _uninstall_app)
    
    # ==================== 性能采集相关 ====================
    
    def perf_start(self, udid: str, container_bundle_identifier: str,
                   sub_process_name: str = '', sub_window: str = '',
                   case_name: str = '', log_output_file: str = 'perf.log') -> Dict[str, Any]:
        """
        开始采集性能数据
        
        参考 device.py: perf_start()
        
        Args:
            udid: 设备UDID
            container_bundle_identifier: 应用包名
            sub_process_name: 进程名，默认为空
            sub_window: window名，默认为空
            case_name: Case名，默认为空
            log_output_file: log文件名，默认为 'perf.log'
        
        Returns:
            dict: 包含启动采集操作结果等信息的字典
        
        Raises:
            UBoxValidationError: 参数验证失败时抛出异常
            UBoxDeviceError: 操作失败时抛出异常
        
        Note:
            - 如果已有性能采集在进行中，会抛出异常，需要先调用perf_stop()结束当前采集
        """
        def _perf_start(device):
            result = device.perf_start(
                container_bundle_identifier=container_bundle_identifier,
                sub_process_name=sub_process_name,
                sub_window=sub_window,
                case_name=case_name,
                log_output_file=log_output_file
            )
            
            return {
                "started": result,
                "container_bundle_identifier": container_bundle_identifier,
                "sub_process_name": sub_process_name,
                "sub_window": sub_window,
                "case_name": case_name,
                "log_output_file": log_output_file
            }
        
        # 注意：_perf_start 通过闭包捕获了所有参数，不需要作为参数传递
        return self._execute_device_operation(udid, "开始性能采集", _perf_start)
    
    def perf_stop(self, udid: str, output_directory: Optional[str] = None) -> Dict[str, Any]:
        """
        停止采集性能数据
        
        参考 device.py: perf_stop()
        
        Args:
            udid: 设备UDID
            output_directory: 数据输出文件目录,可不传，不传则不保存数据；需要使用perf_save_data保存
        
        Returns:
            dict: 包含停止采集操作结果等信息的字典
        
        Raises:
            UBoxDeviceError: 操作失败时抛出异常
        """
        def _perf_stop(device):
            # 如果指定了输出目录，确保目录存在
            if output_directory:
                os.makedirs(output_directory, exist_ok=True)
            
            result = device.perf_stop(output_directory=output_directory)
            
            return {
                "stopped": result,
                "output_directory": output_directory
            }
        
        # 注意：_perf_stop 通过闭包捕获了 output_directory，不需要作为参数传递
        return self._execute_device_operation(udid, "停止性能采集", _perf_stop)
    
    # ==================== Logcat日志采集相关 ====================
    
    def logcat_start(self, udid: str, file: str, clear: bool = False,
                     re_filter: Optional[Union[str, re.Pattern]] = None) -> Dict[str, Any]:
        """
        [仅android和鸿蒙] 启动logcat日志采集
        
        参考 device.py: logcat_start()
        
        Args:
            udid: 设备UDID
            file: 保存logcat的文件路径
            clear: 开始前是否清除logcat，默认为 False
            re_filter: 用于过滤logcat的正则表达式模式（字符串或正则表达式对象）
        
        Returns:
            dict: 包含logcat任务信息的字典，返回任务ID用于后续停止操作
        
        Raises:
            ValueError: 设备类型不支持logcat功能时抛出异常
            UBoxDeviceError: 操作失败时抛出异常
        
        Note:
            - 此功能仅适用于Android和鸿蒙设备
            - 返回的task_id可以用于后续通过logcat_get_task获取任务对象并停止采集
        """
        def _logcat_start(device):
            # 检查设备类型
            if device.os_type not in [OSType.ANDROID, OSType.HM]:
                raise ValueError(f"Logcat功能仅支持Android和鸿蒙设备，当前设备类型: {device.os_type}")
            
            # 确保目录存在
            file_dir = os.path.dirname(file) if os.path.dirname(file) else "."
            os.makedirs(file_dir, exist_ok=True)
            
            task: LogcatTask = device.logcat_start(
                file=file,
                clear=clear,
                re_filter=re_filter
            )
            
            return {
                "task_id": task.task_id,
                "file_path": task.file_path,
                "clear": clear,
                "re_filter": re_filter
            }
        
        # 注意：_logcat_start 通过闭包捕获了所有参数，不需要作为参数传递
        return self._execute_device_operation(udid, "开始Logcat采集", _logcat_start)
    
    def logcat_stop(self, udid: str, task_id: str) -> Dict[str, Any]:
        """
        停止指定的Logcat采集任务
        
        参考 device.py: LogcatTask.stop()
        
        Args:
            udid: 设备UDID
            task_id: Logcat任务ID
        
        Returns:
            dict: 包含停止操作结果等信息的字典
        
        Note:
            - 推荐使用logcat_get_task获取任务对象后直接调用stop()方法
            - 或者使用logcat_stop_all停止所有任务
        """
        def _logcat_stop(device):
            # 这里需要从设备管理器获取任务对象，暂时使用简化实现
            # 实际使用时可能需要维护任务列表
            raise NotImplementedError("请使用logcat_stop_all停止所有任务，或通过任务对象直接调用stop()方法")
        
        # 注意：_logcat_stop 通过闭包捕获了 task_id，不需要作为参数传递
        return self._execute_device_operation(udid, "停止Logcat采集", _logcat_stop)
    
    def logcat_stop_all(self, udid: str) -> Dict[str, Any]:
        """
        [仅android和鸿蒙] 停止所有logcat日志采集任务
        
        参考 device.py: logcat_stop_all()
        
        Args:
            udid: 设备UDID
        
        Returns:
            dict: 包含停止操作结果等信息的字典
        
        Raises:
            ValueError: 设备类型不支持logcat功能时抛出异常
            UBoxDeviceError: 操作失败时抛出异常
        
        Note:
            - 此功能仅适用于Android和鸿蒙设备
            - 停止设备上所有正在运行的logcat任务
            - 推荐使用LogcatTask.stop()方法停止特定任务
        """
        def _logcat_stop_all(device):
            if device.os_type not in [OSType.ANDROID, OSType.HM]:
                raise ValueError(f"Logcat功能仅支持Android和鸿蒙设备，当前设备类型: {device.os_type}")
            
            result = device.logcat_stop_all()
            
            return {
                "stopped": result
            }
        
        return self._execute_device_operation(udid, "停止所有Logcat任务", _logcat_stop_all)
    
    def logcat_list_tasks(self, udid: str) -> Dict[str, Any]:
        """
        [仅android和鸿蒙] 获取所有正在运行的logcat任务列表
        
        参考 device.py: logcat_list_tasks()
        
        Args:
            udid: 设备UDID
        
        Returns:
            dict: 包含正在运行的logcat任务列表的字典
        
        Raises:
            ValueError: 设备类型不支持logcat功能时抛出异常
            UBoxDeviceError: 操作失败时抛出异常
        
        Note:
            - 此功能仅适用于Android和鸿蒙设备
        """
        def _logcat_list_tasks(device):
            if device.os_type not in [OSType.ANDROID, OSType.HM]:
                raise ValueError(f"Logcat功能仅支持Android和鸿蒙设备，当前设备类型: {device.os_type}")
            
            tasks = device.logcat_list_tasks()
            
            return {
                "tasks": [
                    {
                        "task_id": task.task_id,
                        "file_path": task.file_path,
                        "is_running": task.is_running()
                    }
                    for task in tasks
                ],
                "count": len(tasks)
            }
        
        return self._execute_device_operation(udid, "列出Logcat任务", _logcat_list_tasks)
    
    # ==================== ANR/Crash监控相关 ====================
    
    def anr_start(self, udid: str, package_name: str, collect_am_monitor: bool = False) -> Dict[str, Any]:
        """
        [仅android和鸿蒙] 启动ANR/Crash监控
        
        参考 device.py: anr_start()
        
        Args:
            udid: 设备UDID
            package_name: 要监控的应用包名
            collect_am_monitor: 是否开启采集AM监控日志，默认为 False
        
        Returns:
            dict: 包含启动操作结果等信息的字典
        
        Raises:
            ValueError: 设备类型不支持ANR监控功能时抛出异常
            UBoxDeviceError: 操作失败时抛出异常
            UBoxValidationError: 参数验证失败时抛出异常
        
        Note:
            - 此功能仅适用于Android和鸿蒙设备
            - 监控指定应用的ANR（Application Not Responding）和Crash问题
            - 需要调用anr_stop()停止监控
            - collect_am_monitor=True时会额外采集Activity Manager监控日志
        """
        def _anr_start(device):
            if device.os_type not in [OSType.ANDROID, OSType.HM]:
                raise ValueError(f"ANR监控功能仅支持Android和鸿蒙设备，当前设备类型: {device.os_type}")
            
            success = device.anr_start(
                package_name=package_name,
                collect_am_monitor=collect_am_monitor
            )
            
            return {
                "started": success,
                "package_name": package_name,
                "collect_am_monitor": collect_am_monitor
            }
        
        # 注意：_anr_start 通过闭包捕获了所有参数，不需要作为参数传递
        return self._execute_device_operation(udid, "开始ANR监控", _anr_start)
    
    def anr_stop(self, udid: str, output_directory: Optional[str] = None) -> Dict[str, Any]:
        """
        [仅android和鸿蒙] 停止ANR/Crash监控
        
        参考 device.py: anr_stop()
        
        Args:
            udid: 设备UDID
            output_directory: 输出目录，用于保存监控结果文件（截图、日志等），可不传
        
        Returns:
            dict: 监控结果，包含以下字段：
                - success: 是否成功
                - run_time: 运行时间（秒）
                - crash_count: Crash次数
                - anr_count: ANR次数
                - logcat_file: 本地logcat文件路径（如果指定了output_directory）
                - screenshots: 本地截图文件路径列表（如果指定了output_directory）
                - context_files: 本地上下文文件路径列表（如果指定了output_directory）
                - am_monitor_file: 本地AM监控文件路径（如果指定了output_directory）
        
        Raises:
            ValueError: 设备类型不支持ANR监控功能时抛出异常
            UBoxDeviceError: 操作失败时抛出异常
        
        Note:
            - 此功能仅适用于Android和鸿蒙设备
            - 如果指定了output_directory，会自动下载相关文件到本地
        """
        def _anr_stop(device):
            if device.os_type not in [OSType.ANDROID, OSType.HM]:
                raise ValueError(f"ANR监控功能仅支持Android和鸿蒙设备，当前设备类型: {device.os_type}")
            
            # 如果指定了输出目录，确保目录存在
            if output_directory:
                os.makedirs(output_directory, exist_ok=True)
            
            result = device.anr_stop(output_directory=output_directory)
            
            return {
                "success": result.get('success', False),
                "run_time": result.get('run_time', 0),
                "anr_count": result.get('anr_count', 0),
                "crash_count": result.get('crash_count', 0),
                "screenshots": result.get('screenshots', []),
                "context_files": result.get('context_files', []),
                "logcat_file": result.get('logcat_file'),
                "am_monitor_file": result.get('am_monitor_file'),
                "output_directory": output_directory
            }
        
        # 注意：_anr_stop 通过闭包捕获了 output_directory，不需要作为参数传递
        return self._execute_device_operation(udid, "停止ANR监控", _anr_stop)
    
    # ==================== iOS特定功能 ====================
    
    def ios_open_url(self, udid: str, url: str, permission_config: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        """
        iOS设备智能打开URL功能
        
        参考 device.py: ios_open_url()
        
        自动导航到主屏幕，查找并点击"打开URL"按钮，输入URL，处理权限弹窗等。
        这是一个完整的自动化流程，专门为iOS设备设计。
        
        Args:
            udid: 设备UDID
            url: 要打开的URL
            permission_config: 权限弹窗处理配置，包含以下字段：
                - watcher_name: 权限弹窗的watcher名称，默认"权限弹窗"
                - allow_conditions: 允许按钮的匹配条件列表，默认["允许", "打开"]
                - wait_time: 等待权限弹窗处理完成的时间（秒），默认20秒
                - enabled: 是否启用权限弹窗处理，默认True
        
        Returns:
            dict: 包含操作结果等信息的字典
        
        Raises:
            ValueError: 设备类型不是iOS时抛出异常
            UBoxValidationError: 参数验证失败时抛出异常
            UBoxDeviceError: 操作失败时抛出异常
        
        Note:
            - 此功能仅适用于iOS设备
        """
        def _ios_open_url(device):
            if device.os_type != OSType.IOS:
                raise ValueError(f"ios_open_url仅支持iOS设备，当前设备类型: {device.os_type}")
            
            result = device.ios_open_url(url, permission_config=permission_config)
            
            return {
                "opened": result,
                "url": url,
                "permission_config": permission_config
            }
        
        # 注意：_ios_open_url 通过闭包捕获了所有参数，不需要作为参数传递
        return self._execute_device_operation(udid, "iOS打开URL", _ios_open_url)

