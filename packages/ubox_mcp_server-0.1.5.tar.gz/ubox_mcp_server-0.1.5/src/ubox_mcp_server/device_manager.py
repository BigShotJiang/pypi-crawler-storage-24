#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
UBox设备管理模块

负责管理多个设备的连接状态、authcode和操作
"""

import json
import time
import threading
from typing import Dict, List, Optional, Any, Tuple
from dataclasses import dataclass, asdict
from ubox_py_sdk import UBox, RunMode, OSType
from ubox_py_sdk.models import DeviceButton, DriverType, PhonePlatform
from .ubox_config import ubox_config

@dataclass
class DeviceInfo:
    """设备信息数据类"""
    udid: str
    os_type: str
    manufacturer: str
    model: str
    status: str
    auth_code: Optional[str] = None
    connected_at: Optional[str] = None
    last_activity: Optional[str] = None

@dataclass
class DeviceConnection:
    """设备连接信息"""
    device_info: DeviceInfo
    ubox_client: Optional[UBox] = None
    device: Optional[Any] = None
    is_connected: bool = False
    connection_lock: Optional[threading.Lock] = None
    # 最后活动时间戳（用于计算空闲时间）
    _last_activity_timestamp: float = 0.0

class DeviceManager:
    """设备管理器"""
    
    def __init__(self):
        """
        初始化设备管理器
        
        在服务启动时创建共享的 UBox 客户端，所有设备操作都使用这个客户端
        这样可以避免每次操作都创建新的客户端，防止设备被意外回收
        """
        self.devices: Dict[str, DeviceConnection] = {}
        self.config = ubox_config.get_config()
        self.device_config = ubox_config.get_device_config()
        self._lock = threading.Lock()
        
        # 设备空闲超时时间（秒），默认5分钟
        self.idle_timeout = 300  # 5分钟 = 300秒
        
        # 后台检查线程相关
        self._cleanup_thread: Optional[threading.Thread] = None
        self._stop_cleanup = threading.Event()
        
        # 当前使用的 auth_token（可通过 update_auth_token 动态更新）
        self._auth_token = self.config.get('auth_token', '')
        
        # 创建共享的 UBox 客户端（服务启动时初始化，服务关闭时关闭）
        self.ubox_client = self._create_ubox_client()
        
        # 启动后台空闲检查线程
        self._start_idle_cleanup_thread()
    
    def _create_ubox_client(self, auth_token: Optional[str] = None) -> UBox:
        """
        创建 UBox 客户端
        
        支持两种认证方式：
        1. auth_token 方式：通过 mcp.json 的 Authorization header 传入
        2. secret_id + secret_key 方式：通过环境变量或 .env 文件配置
        
        Args:
            auth_token: 可选的 auth_token，优先级高于配置中的 token
            
        Returns:
            UBox: UBox 客户端实例
        """
        token = auth_token or self._auth_token
        
        # 构建 UBox 客户端参数
        ubox_kwargs = {
            "mode": RunMode(self.config.get("mode", "local")),
            "base_url": self.config.get("base_url", ''),
            "log_level": "info",
            "log_to_file": False,
        }
        
        if token:
            # Token 认证方式
            ubox_kwargs["auth_token"] = token
        else:
            # 密钥对认证方式
            ubox_kwargs["secret_id"] = self.config.get('secret_id')
            ubox_kwargs["secret_key"] = self.config.get('secret_key')
        
        return UBox(**ubox_kwargs)
    
    def update_auth_token(self, token: str):
        """
        动态更新 auth_token 并重新创建 UBox 客户端
        
        当从 HTTP 请求头中提取到新的 token 时调用此方法，
        会关闭旧的客户端并创建新的客户端。
        
        Args:
            token: 新的 auth_token
        """
        if not token or token == self._auth_token:
            return  # token 未变化，无需更新
        
        with self._lock:
            old_client = self.ubox_client
            self._auth_token = token
            
            # 创建新的 UBox 客户端
            self.ubox_client = self._create_ubox_client(auth_token=token)
            
            # 关闭旧的客户端
            try:
                if old_client:
                    old_client.close()
            except Exception:
                pass
            
            # 注意：已连接的设备需要重新连接
            # 因为旧客户端关闭后，设备连接会失效
            if self.devices:
                print(f"⚠️ Token 已更新，已连接的 {len(self.devices)} 个设备需要重新连接")
                # 清理旧的设备连接
                self.devices.clear()
    
    def get_device_list(self, page_num: int = 1, page_size: int = 50, 
                       phone_platform: Optional[List[str]] = None) -> Dict[str, Any]:
        """
        获取设备列表
        
        Args:
            page_num: 页码
            page_size: 每页大小
            phone_platform: 平台过滤，如["android", "ios"]
            
        Returns:
            dict: 设备列表信息
        """
        try:
            # 将字符串平台名称转换为 PhonePlatform 枚举
            platform_enums = None
            if phone_platform:
                platform_map = {
                    "android": PhonePlatform.ANDROID,
                    "ios": PhonePlatform.IOS,
                    "harmonyos": PhonePlatform.HARMONYOS,
                    "harmonyos_next": PhonePlatform.HARMONYOS_NEXT,
                }
                platform_enums = [
                    platform_map[p.lower()] for p in phone_platform
                    if p.lower() in platform_map
                ]
            
            # 使用共享的 UBox 客户端获取设备列表（不再创建临时客户端）
            device_list_response = self.ubox_client.device_list(
                page_num=page_num,
                page_size=page_size,
                phone_platform=platform_enums or []
            )
            
            # 处理响应数据
            # 根据实际返回的数据结构，device_list_response 可能是：
            # 1. 直接是列表：device_list_response 本身就是设备列表
            # 2. 包含 data.list：device_list_response.data.list 是设备列表
            # 3. 包含 list：device_list_response.list 是设备列表
            devices = []
            device_list = None
            total = 0
            
            # 尝试多种可能的数据结构
            if isinstance(device_list_response, list):
                # 情况1：直接是列表
                device_list = device_list_response
                total = len(device_list_response)
            elif hasattr(device_list_response, 'list') and device_list_response.list:
                # 情况2：直接有 list 属性
                device_list = device_list_response.list
                total = getattr(device_list_response, 'total', len(device_list_response.list))
            elif hasattr(device_list_response, 'data') and device_list_response.data:
                # 情况3：包含 data 属性
                if hasattr(device_list_response.data, 'list') and device_list_response.data.list:
                    device_list = device_list_response.data.list
                    total = getattr(device_list_response.data, 'total', len(device_list_response.data.list))
                elif isinstance(device_list_response.data, list):
                    device_list = device_list_response.data
                    total = len(device_list_response.data)
            
            # 解析设备列表
            if device_list:
                for device_data in device_list:
                    try:
                        device_info = DeviceInfo(
                            udid=getattr(device_data, 'udid', ''),
                            os_type=self._convert_os_type(getattr(device_data, 'osType', 1)),
                            manufacturer=getattr(device_data, 'manufacturer', '未知'),
                            model=getattr(device_data, 'modelKind', '未知'),
                            status="在线" if getattr(device_data, 'onlineStatus', 0) == 1 else "离线"
                        )
                        if device_info.udid:  # 只有有效的 UDID 才添加
                            devices.append(asdict(device_info))
                    except Exception:
                        # 跳过无法解析的设备
                        continue
            
            return {
                "success": True,
                "message": f"获取设备列表成功，共 {len(devices)} 个设备",
                "data": {
                    "devices": devices,
                    "total": total if total > 0 else len(devices),
                    "page_num": page_num,
                    "page_size": page_size
                }
            }
            
        except Exception as e:
            # 检查是否是 Pydantic 验证错误
            error_str = str(e)
            error_type = type(e).__name__
            
            # 尝试导入 Pydantic 错误类型（如果可用）
            is_pydantic_error = False
            try:
                from pydantic import ValidationError
                if isinstance(e, ValidationError):
                    is_pydantic_error = True
            except ImportError:
                pass
            
            # 检查错误信息中是否包含 Pydantic 相关关键词
            error_lower = error_str.lower()
            if (is_pydantic_error or 
                "validation error" in error_lower or 
                "pydantic" in error_type.lower() or 
                "pydantic" in error_lower or
                "validation errors" in error_lower):
                return {
                    "success": False,
                    "message": "获取设备列表失败：SDK 数据验证错误",
                    "error": "UBox SDK 在解析设备列表响应时遇到 Pydantic 验证错误。这通常是因为后端返回的数据中某些字段为 None（如 openGlEsVersion、cpuCn、cpuCoreNum、cpuFrequency、gpuName、grade 等），但 SDK 的 Pydantic 模型要求这些字段必须有值。",
                    "error_detail": error_str[:500] if len(error_str) > 500 else error_str,  # 限制错误详情长度
                    "error_type": error_type,
                    "suggestion": "这可能是 SDK 版本或后端数据格式的问题。建议：\n"
                                 "1. 检查 ubox-py-sdk 是否为最新版本（当前依赖: ubox-py-sdk>=0.1.34）\n"
                                 "2. 联系 UBox 技术支持确认后端数据格式，或修复 SDK 的 Pydantic 模型定义\n"
                                 "3. 临时解决方案：可以尝试使用其他方式获取设备信息，或等待 SDK 更新"
                }
            
            # 其他错误正常处理
            return {
                "success": False,
                "message": f"获取设备列表失败: {str(e)}",
                "error": error_str,
                "error_type": error_type
            }
    
    def _convert_os_type(self, os_type: int) -> str:
        """转换操作系统类型"""
        os_type_map = {
            1: "android",
            2: "ios", 
            3: "harmonyos",
            4: "harmonyos_next"
        }
        return os_type_map.get(os_type, "unknown")
    
    def connect_device(self, udid: str, os_type: Optional[str] = None, 
                      config_name: Optional[str] = None) -> Dict[str, Any]:
        """
        连接指定设备
        
        Args:
            udid: 设备UDID
            os_type: 操作系统类型
            config_name: 配置名称
            
        Returns:
            dict: 连接结果
        """
        try:
            with self._lock:
                # 检查设备是否已连接
                if udid in self.devices and self.devices[udid].is_connected:
                    return {
                        "success": True,
                        "message": "设备已连接",
                        "data": {
                            "udid": udid,
                            "auth_code": self.devices[udid].device_info.auth_code,
                            "connected_at": self.devices[udid].device_info.connected_at
                        }
                    }
                
                # 使用共享的 UBox 客户端初始化设备（不再创建新的客户端）
                # 每次连接设备时调用 init_device，返回的 device 对象会被保存到设备池
                # 将 os_type 字符串映射为 SDK 支持的 OSType 枚举值
                os_type_mapping = {
                    "android": "android",
                    "ios": "ios",
                    "hm": "hm",
                    "harmonyos": "hm",
                    "harmonyos_next": "hm",
                }
                raw_os_type = os_type or self.device_config.get('default_os_type', 'android')
                mapped_os_type = os_type_mapping.get(raw_os_type.lower(), raw_os_type)
                device = self.ubox_client.init_device(
                    udid=udid,
                    os_type=OSType(mapped_os_type)
                )
                
                # 获取设备信息和authcode
                device_info = device.device_info()
                auth_info = device.get_auth_info()
                auth_code = auth_info.get('authCode') if auth_info else None
                
                # 创建设备连接对象
                current_time = time.time()
                current_time_str = time.strftime("%Y-%m-%d %H:%M:%S")
                device_connection = DeviceConnection(
                    device_info=DeviceInfo(
                        udid=udid,
                        os_type=os_type or self.device_config.get('default_os_type', 'android'),
                        manufacturer=device_info.get('manufacturer', 'Unknown') if device_info else 'Unknown',
                        model=device_info.get('model', 'Unknown') if device_info else 'Unknown',
                        status="已连接",
                        auth_code=auth_code,
                        connected_at=current_time_str,
                        last_activity=current_time_str
                    ),
                    device=device,  # 保存 device 对象，这是从 init_device 返回的
                    is_connected=True,
                    connection_lock=threading.Lock(),
                    _last_activity_timestamp=current_time  # 初始化最后活动时间戳
                )
                
                # 保存设备连接
                self.devices[udid] = device_connection
                
                return {
                    "success": True,
                    "message": "设备连接成功",
                    "data": {
                        "udid": udid,
                        "auth_code": auth_code,
                        "device_info": device_info,
                        "connected_at": device_connection.device_info.connected_at
                    }
                }
                
        except Exception as e:
            return {
                "success": False,
                "message": f"连接设备失败: {str(e)}",
                "error": str(e)
            }
    
    def disconnect_device(self, udid: str) -> Dict[str, Any]:
        """
        断开设备连接
        
        Args:
            udid: 设备UDID
            
        Returns:
            dict: 断开结果
        """
        try:
            with self._lock:
                if udid not in self.devices:
                    return {
                        "success": False,
                        "message": "设备未连接"
                    }
                
                device_connection = self.devices[udid]
                
                # 注意：不关闭 UBox 客户端，因为它是共享的
                # 只需要从设备池中移除 device 对象即可
                # 如果有 device 的释放方法，可以调用（但通常不需要）
                
                # 更新设备状态
                device_connection.is_connected = False
                device_connection.device_info.status = "已断开"
                
                # 移除设备连接（device 对象会被自动回收）
                del self.devices[udid]
                
                return {
                    "success": True,
                    "message": "设备断开成功",
                    "data": {
                        "udid": udid,
                        "disconnected_at": time.strftime("%Y-%m-%d %H:%M:%S")
                    }
                }
                
        except Exception as e:
            return {
                "success": False,
                "message": f"断开设备失败: {str(e)}",
                "error": str(e)
            }
    
    def get_connected_devices(self) -> Dict[str, Any]:
        """
        获取已连接的设备列表
        
        Returns:
            dict: 已连接设备列表
        """
        try:
            with self._lock:
                connected_devices = []
                for udid, device_connection in self.devices.items():
                    if device_connection.is_connected:
                        connected_devices.append(asdict(device_connection.device_info))
                
                return {
                    "success": True,
                    "message": "获取已连接设备列表成功",
                    "data": {
                        "devices": connected_devices,
                        "count": len(connected_devices)
                    }
                }
                
        except Exception as e:
            return {
                "success": False,
                "message": f"获取已连接设备列表失败: {str(e)}",
                "error": str(e)
            }
    
    def get_device_connection(self, udid: str) -> Optional[DeviceConnection]:
        """
        获取设备连接对象
        
        Args:
            udid: 设备UDID
            
        Returns:
            DeviceConnection: 设备连接对象
        """
        with self._lock:
            device_connection = self.devices.get(udid)
            if device_connection and device_connection.is_connected:
                return device_connection
            return None
    
    def update_device_activity(self, udid: str):
        """
        更新设备活动时间
        
        每次设备操作时调用，更新最后活动时间戳和字符串格式的时间
        """
        with self._lock:
            if udid in self.devices:
                device_connection = self.devices[udid]
                current_time = time.time()
                device_connection._last_activity_timestamp = current_time
                device_connection.device_info.last_activity = time.strftime("%Y-%m-%d %H:%M:%S", time.localtime(current_time))
    
    def cleanup_disconnected_devices(self):
        """清理断开的设备连接"""
        with self._lock:
            disconnected_devices = []
            for udid, device_connection in self.devices.items():
                if not device_connection.is_connected:
                    disconnected_devices.append(udid)
            
            for udid in disconnected_devices:
                del self.devices[udid]
    
    def get_device_status(self, udid: str) -> Dict[str, Any]:
        """
        获取设备状态
        
        Args:
            udid: 设备UDID
            
        Returns:
            dict: 设备状态信息
        """
        try:
            device_connection = self.get_device_connection(udid)
            if not device_connection:
                return {
                    "success": False,
                    "message": "设备未连接"
                }
            
            # 更新活动时间
            self.update_device_activity(udid)
            
            return {
                "success": True,
                "message": "获取设备状态成功",
                "data": asdict(device_connection.device_info)
            }
            
        except Exception as e:
            return {
                "success": False,
                "message": f"获取设备状态失败: {str(e)}",
                "error": str(e)
            }
    
    def _start_idle_cleanup_thread(self):
        """启动后台空闲设备检查线程"""
        def _cleanup_idle_devices():
            """定期检查并断开空闲设备"""
            while not self._stop_cleanup.is_set():
                try:
                    # 每30秒检查一次
                    if self._stop_cleanup.wait(30):
                        break  # 收到停止信号
                    
                    current_time = time.time()
                    idle_devices = []
                    
                    with self._lock:
                        # 检查所有已连接的设备
                        for udid, device_connection in self.devices.items():
                            if device_connection.is_connected:
                                idle_time = current_time - device_connection._last_activity_timestamp
                                if idle_time >= self.idle_timeout:
                                    idle_devices.append(udid)
                    
                    # 断开空闲设备（在锁外执行，避免死锁）
                    for udid in idle_devices:
                        try:
                            self.disconnect_device(udid)
                            print(f"⏰ 设备 {udid} 空闲超过 {self.idle_timeout} 秒，已自动断开连接")
                        except Exception as e:
                            print(f"⚠️ 断开空闲设备 {udid} 时出错: {str(e)}")
                            
                except Exception as e:
                    # 记录错误但继续运行
                    print(f"⚠️ 空闲设备检查线程出错: {str(e)}")
        
        # 启动守护线程
        self._cleanup_thread = threading.Thread(target=_cleanup_idle_devices, daemon=True)
        self._cleanup_thread.start()
    
    def close(self):
        """
        关闭设备管理器
        
        关闭共享的 UBox 客户端，应在服务关闭时调用
        """
        try:
            # 停止后台检查线程
            if self._cleanup_thread and self._cleanup_thread.is_alive():
                self._stop_cleanup.set()
                self._cleanup_thread.join(timeout=5)  # 等待最多5秒
            
            with self._lock:
                # 断开所有设备
                for udid in list(self.devices.keys()):
                    self.disconnect_device(udid)
                
                # 关闭共享的 UBox 客户端
                if hasattr(self, 'ubox_client') and self.ubox_client:
                    self.ubox_client.close()
                    self.ubox_client = None
        except Exception as e:
            # 记录错误但不抛出异常
            pass
