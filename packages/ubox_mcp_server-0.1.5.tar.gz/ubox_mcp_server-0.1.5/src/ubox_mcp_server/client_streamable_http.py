#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
UBox MCP服务器 Streamable HTTP 模式客户端测试

演示如何使用Streamable HTTP模式连接并调用UBox MCP服务器的工具
"""

import asyncio
import json
from mcp import ClientSession
from mcp.client.streamable_http import streamablehttp_client


async def test_streamable_http_client():
    """测试Streamable HTTP模式客户端连接和工具调用"""
    print("=" * 60)
    print("🚀 UBox MCP服务器 Streamable HTTP 模式客户端测试")
    print("=" * 60)
    
    # Streamable HTTP服务器地址
    http_url = "http://localhost:8000/mcp"
    
    try:
        # 创建与服务器的连接，并返回 read_stream 和 write_stream 流
        print(f"\n📡 正在连接到Streamable HTTP服务器: {http_url}")
        async with streamablehttp_client(url=http_url) as (read_stream, write_stream, get_session_id_callback):
            # 创建一个客户端会话对象，通过 read_stream 和 write_stream 流与服务器交互
            async with ClientSession(read_stream, write_stream) as session:
                # 向服务器发送初始化请求，确保连接准备就绪
                print("\n1️⃣ 初始化连接...")
                capabilities = await session.initialize()
                print(f"✅ 连接成功！支持的能力: {capabilities.capabilities}\n")

                # 获取可用的工具列表
                print("2️⃣ 获取可用工具列表...")
                tools = await session.list_tools()
                print(f"✅ 可用工具数量: {len(tools.tools)}")
                print("\n📋 工具列表:")
                for i, tool in enumerate(tools.tools, 1):
                    print(f"   {i}. {tool.name} - {tool.description}")
                print()

                # 测试：获取设备列表
                print("3️⃣ 测试工具：get_device_list")
                print("   调用参数: page_num=1, page_size=5")
                result = await session.call_tool(
                    "get_device_list",
                    {
                        "page_num": 1,
                        "page_size": 5
                    }
                )
                print(f"✅ 调用成功！")
                print(f"📊 返回结果:")
                # 格式化输出JSON结果
                if hasattr(result, 'content'):
                    for content in result.content:
                        if hasattr(content, 'text'):
                            try:
                                result_data = json.loads(content.text)
                                print(json.dumps(result_data, ensure_ascii=False, indent=2))
                            except:
                                print(content.text)
                print()

                # 测试：连接设备（如果有可用设备）
                print("4️⃣ 测试工具：connect_device")
                print("   注意：需要确保有可用的设备UDID")
                print("   示例UDID: YOUR_DEVICE_UDID")
                
                # 这里只是示例，实际使用时需要替换为真实的UDID
                # udid = "YOUR_DEVICE_UDID"
                # result = await session.call_tool(
                #     "connect_device",
                #     {
                #         "udid": udid,
                #         "os_type": "android",
                #         "config_name": "local"
                #     }
                # )
                # print(f"✅ 设备连接成功！")
                # print(f"📊 返回结果:")
                # if hasattr(result, 'content'):
                #     for content in result.content:
                #         if hasattr(content, 'text'):
                #             try:
                #                 result_data = json.loads(content.text)
                #                 print(json.dumps(result_data, ensure_ascii=False, indent=2))
                #             except:
                #                 print(content.text)
                
                print("   ⚠️  跳过连接测试（需要真实设备UDID）")
                print()

                # 测试：获取已连接设备列表
                print("5️⃣ 测试工具：get_connected_devices")
                result = await session.call_tool(
                    "get_connected_devices",
                    {}
                )
                print(f"✅ 调用成功！")
                print(f"📊 返回结果:")
                if hasattr(result, 'content'):
                    for content in result.content:
                        if hasattr(content, 'text'):
                            try:
                                result_data = json.loads(content.text)
                                print(json.dumps(result_data, ensure_ascii=False, indent=2))
                            except:
                                print(content.text)
                print()

                # 测试：设备操作 - 截图（需要先连接设备）
                print("6️⃣ 测试工具：take_screenshot_base64")
                print("   注意：此操作需要先连接设备")
                print("   示例调用:")
                print("   - udid: 设备UDID")
                # result = await session.call_tool(
                #     "take_screenshot_base64",
                #     {
                #         "udid": "YOUR_DEVICE_UDID"
                #     }
                # )
                print("   ⚠️  跳过截图测试（需要先连接设备）")
                print()

                print("=" * 60)
                print("✅ Streamable HTTP模式客户端测试完成！")
                print("=" * 60)

    except Exception as e:
        print(f"\n❌ 请求过程中发生异常: {e}")
        import traceback
        traceback.print_exc()


if __name__ == "__main__":
    """
    运行Streamable HTTP客户端测试
    
    使用前请确保：
    1. UBox MCP服务器已启动（Streamable HTTP模式）
    2. 服务器运行在 http://localhost:8000
    3. 已配置正确的UBox环境变量
    
    启动服务器命令：
    export MCP_MODE=streamable-http
    uv run ./src/ubox_mcp_server/server.py
    """
    print("\n💡 使用提示:")
    print("   1. 确保服务器已启动（Streamable HTTP模式）")
    print("   2. 运行命令: export MCP_MODE=streamable-http && uv run ./src/ubox_mcp_server/server.py")
    print("   3. 然后运行此客户端测试脚本\n")
    
    asyncio.run(test_streamable_http_client())

