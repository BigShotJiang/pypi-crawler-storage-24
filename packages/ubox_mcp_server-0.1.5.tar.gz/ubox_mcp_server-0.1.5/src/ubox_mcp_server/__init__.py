#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
UBox MCP服务器包初始化文件

提供包的入口点和主要模块导出
"""

import asyncio

# 使用相对导入，保持包内部导入的一致性
from . import server
from . import ubox_handler
from . import device_manager
from . import ubox_config
from .app_config import AppConfig

__version__ = "0.1.5"


def main():
    """主入口点，用于直接运行包"""
    server.main()


__all__ = [
    "main",
    "server",
    "ubox_handler",
    "device_manager",
    "ubox_config",
    "AppConfig",
    "__version__"
]

