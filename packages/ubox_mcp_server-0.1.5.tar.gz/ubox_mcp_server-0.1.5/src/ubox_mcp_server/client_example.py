#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
UBox MCP服务器客户端完整示例

演示完整的设备操作流程：连接设备 -> 执行操作 -> 断开连接
"""

import asyncio
import json
from mcp import ClientSession
from mcp.client.streamable_http import streamablehttp_client


async def complete_device_workflow():
    """完整的设备操作流程示例"""
    print("=" * 60)
    print("🚀 UBox MCP服务器完整工作流示例")
    print("=" * 60)
    
    http_url = "http://localhost:8000/mcp"
    
    try:
        async with streamablehttp_client(url=http_url) as (read_stream, write_stream, get_session_id_callback):
            async with ClientSession(read_stream, write_stream) as session:
                # 初始化连接
                print("\n1️⃣ 初始化连接...")
                await session.initialize()
                print("✅ 连接成功！\n")

                # 步骤1: 获取设备列表
                print("2️⃣ 获取设备列表...")
                result = await session.call_tool(
                    "get_device_list",
                    {
                        "page_num": 1,
                        "page_size": 10,
                        "phone_platform": ["android"]  # 只获取Android设备
                    }
                )
                
                devices = []
                if hasattr(result, 'content'):
                    for content in result.content:
                        if hasattr(content, 'text'):
                            try:
                                result_data = json.loads(content.text)
                                if result_data.get("success") and result_data.get("data", {}).get("devices"):
                                    devices = result_data["data"]["devices"]
                                    print(f"✅ 找到 {len(devices)} 个设备")
                                    for i, device in enumerate(devices[:5], 1):  # 只显示前5个
                                        print(f"   {i}. {device.get('udid')} - {device.get('model')} ({device.get('status')})")
                            except:
                                pass
                
                if not devices:
                    print("⚠️  没有找到可用设备，结束示例")
                    return
                
                # 选择第一个设备
                test_device = devices[0]
                udid = test_device.get("udid")
                os_type = test_device.get("os_type", "android")
                print(f"\n📱 选择设备: {udid} ({os_type})\n")

                # 步骤2: 连接设备
                print("3️⃣ 连接设备...")
                result = await session.call_tool(
                    "connect_device",
                    {
                        "udid": udid,
                        "os_type": os_type,
                        "config_name": "local"
                    }
                )
                
                connected = False
                if hasattr(result, 'content'):
                    for content in result.content:
                        if hasattr(content, 'text'):
                            try:
                                result_data = json.loads(content.text)
                                if result_data.get("success"):
                                    connected = True
                                    print(f"✅ 设备连接成功！")
                                    print(f"   Auth Code: {result_data.get('data', {}).get('auth_code', 'N/A')}")
                            except:
                                pass
                
                if not connected:
                    print("❌ 设备连接失败，结束示例")
                    return
                
                # 步骤3: 获取设备信息
                print("\n4️⃣ 获取设备详细信息...")
                result = await session.call_tool(
                    "get_device_info",
                    {"udid": udid}
                )
                
                if hasattr(result, 'content'):
                    for content in result.content:
                        if hasattr(content, 'text'):
                            try:
                                result_data = json.loads(content.text)
                                if result_data.get("success"):
                                    print("✅ 设备信息获取成功")
                                    device_info = result_data.get("data", {}).get("device_info", {})
                                    print(f"   制造商: {device_info.get('manufacturer', 'N/A')}")
                                    print(f"   型号: {device_info.get('model', 'N/A')}")
                            except:
                                pass
                
                # 步骤4: 截图操作
                print("\n5️⃣ 执行截图操作...")
                result = await session.call_tool(
                    "take_screenshot_base64",
                    {
                        "udid": udid
                    }
                )
                
                if hasattr(result, 'content'):
                    for content in result.content:
                        if hasattr(content, 'text'):
                            try:
                                result_data = json.loads(content.text)
                                if result_data.get("success"):
                                    print("✅ 截图成功！")
                                    base64_length = result_data.get("data", {}).get("length", 0)
                                    print(f"   Base64图片长度: {base64_length} 字符")
                            except:
                                pass
                
                # 步骤5: 获取当前应用
                print("\n6️⃣ 获取当前运行的应用...")
                result = await session.call_tool(
                    "get_current_application",
                    {"udid": udid}
                )
                
                if hasattr(result, 'content'):
                    for content in result.content:
                        if hasattr(content, 'text'):
                            try:
                                result_data = json.loads(content.text)
                                if result_data.get("success"):
                                    current_app = result_data.get("data", {}).get("current_app", "N/A")
                                    print(f"✅ 当前应用: {current_app}")
                            except:
                                pass
                
                # 步骤6: 获取已连接设备列表
                print("\n7️⃣ 查看已连接设备...")
                result = await session.call_tool(
                    "get_connected_devices",
                    {}
                )
                
                if hasattr(result, 'content'):
                    for content in result.content:
                        if hasattr(content, 'text'):
                            try:
                                result_data = json.loads(content.text)
                                if result_data.get("success"):
                                    connected_count = result_data.get("data", {}).get("count", 0)
                                    print(f"✅ 当前已连接 {connected_count} 个设备")
                            except:
                                pass
                
                # 步骤7: 断开设备连接
                print("\n8️⃣ 断开设备连接...")
                result = await session.call_tool(
                    "disconnect_device",
                    {"udid": udid}
                )
                
                if hasattr(result, 'content'):
                    for content in result.content:
                        if hasattr(content, 'text'):
                            try:
                                result_data = json.loads(content.text)
                                if result_data.get("success"):
                                    print("✅ 设备断开成功！")
                            except:
                                pass
                
                print("\n" + "=" * 60)
                print("✅ 完整工作流示例执行完成！")
                print("=" * 60)

    except Exception as e:
        print(f"\n❌ 执行过程中发生异常: {e}")
        import traceback
        traceback.print_exc()


if __name__ == "__main__":
    """
    运行完整工作流示例
    
    使用前请确保：
    1. UBox MCP服务器已启动（Streamable HTTP模式）
    2. 服务器运行在 http://localhost:8000
    3. 已配置正确的UBox环境变量
    4. 有可用的设备可以连接
    """
    print("\n💡 使用提示:")
    print("   1. 确保服务器已启动")
    print("   2. 运行命令: export MCP_MODE=streamable-http && uv run ./src/ubox_mcp_server/server.py")
    print("   3. 确保有可用的设备")
    print("   4. 然后运行此示例脚本\n")
    
    asyncio.run(complete_device_workflow())

