"""
Generate a single-file, user-friendly HTML report for an ICSF CLI run.
"""

from __future__ import annotations

import html
import json
from typing import Any, Dict, List


def _esc(s: Any) -> str:
    if s is None:
        return ""
    return html.escape(str(s))


def _format_duration(secs: float) -> str:
    mins, secs_int = divmod(int(secs), 60)
    if mins:
        return f"{mins}m {secs_int}s"
    return f"{secs_int}s"


def _repo_name(repo: Dict[str, Any]) -> str:
    return repo.get("full_name") or repo.get("name") or "unknown"


def _repo_url(repo: Dict[str, Any]) -> str:
    return repo.get("html_url") or repo.get("clone_url") or ""

def _json_pretty_block(data: Any, *, max_chars: int = 5000) -> str:
    try:
        txt = json.dumps(data, indent=2, ensure_ascii=False, default=str)
    except Exception:
        txt = str(data)
    if len(txt) > max_chars:
        txt = txt[:max_chars] + "\n… (truncated) …"
    return f'<pre class="pre-block small">{_esc(txt)}</pre>'


def _get_repo_vulns_from_mapping(mapping: Dict[str, Any], repo: Dict[str, Any]) -> List[Dict[str, Any]]:
    repo_id = repo.get("id")
    if repo_id is None:
        return []
    mapped = (mapping or {}).get("mapped_vulnerabilities") or {}
    payload = mapped.get(str(repo_id)) or {}
    vulns = payload.get("vulnerabilities") or []
    return vulns if isinstance(vulns, list) else []


def _render_vuln_table(vulns: List[Dict[str, Any]]) -> str:
    if not vulns:
        return '<p class="muted">No mapped vulnerabilities for this repository.</p>'

    def _row(v: Dict[str, Any], idx: int) -> str:
        vuln_type = v.get("vulnerability") or v.get("type") or v.get("vulnerability_type") or "vulnerability"
        file_path = v.get("matched_file_path") or v.get("file_path") or v.get("file") or ""
        line = v.get("line") or v.get("line_number") or ""
        severity = v.get("severity") or v.get("priority") or ""
        found = v.get("file_found")
        found_badge = (
            '<span class="badge badge-ok">found</span>'
            if found
            else '<span class="badge badge-fail">missing</span>'
            if found is False
            else '<span class="badge badge-skip">—</span>'
        )
        return (
            "<tr>"
            f"<td>{idx}</td>"
            f"<td>{_esc(vuln_type)}</td>"
            f"<td class=\"mono\">{_esc(file_path)}</td>"
            f"<td class=\"mono\">{_esc(line)}</td>"
            f"<td>{_esc(severity)}</td>"
            f"<td>{found_badge}</td>"
            "</tr>"
        )

    rows: List[str] = []
    for i, v in enumerate(vulns, start=1):
        rows.append(_row(v, i))
        if i >= 200:
            rows.append(
                f'<tr><td colspan="6" class="muted">… showing first 200 of {len(vulns)} vulnerabilities …</td></tr>'
            )
            break

    return (
        '<table class="vuln-table">'
        "<thead><tr>"
        "<th>#</th><th>Vulnerability</th><th>File</th><th>Line</th><th>Severity</th><th>File found</th>"
        "</tr></thead>"
        "<tbody>"
        + "".join(rows)
        + "</tbody></table>"
    )


def _render_baseline_section(br: Any) -> str:
    if br is None:
        return '<p class="muted">No baseline run for this repo.</p>'
    if isinstance(br, dict):
        ok = br.get("success") or br.get("build_ok")
        status = "passed" if ok else "failed"
        status_cls = "badge-ok" if ok else "badge-fail"
        out = br.get("output") or br.get("stdout") or br.get("stderr") or ""
        err = br.get("error") or br.get("build_errors") or []
        if isinstance(err, list):
            err = "\n".join(str(e) for e in err)
        lines = []
        if out:
            lines.append(f"<pre class=\"pre-block\">{_esc(out[:2000])}</pre>")
        if err:
            lines.append(f"<pre class=\"pre-block err\">{_esc(str(err)[:1000])}</pre>")
        return f'<span class="badge {status_cls}">{_esc(status)}</span>' + "".join(f"<div>{x}</div>" for x in lines)
    return f'<pre class="pre-block">{_esc(str(br)[:1500])}</pre>'


def _render_build_section(bv: Any) -> str:
    if not bv or not isinstance(bv, dict):
        return '<span class="badge badge-skip">—</span>'
    ok = bv.get("build_ok", False)
    status_cls = "badge-ok" if ok else "badge-fail"
    label = "passed"
    if bv.get("auto_fixed"):
        label += " (after auto-repair)"
    if not ok:
        label = "failed"
    errs = bv.get("build_errors") or []
    if isinstance(errs, list) and errs:
        err_block = "<pre class=\"pre-block err small\">" + _esc("\n".join(str(e) for e in errs[:10])) + "</pre>"
    else:
        err_block = ""
    return f'<span class="badge {status_cls}">{_esc(label)}</span>{err_block}'


def _render_test_section(tr: Any) -> str:
    if tr is None:
        return '<span class="badge badge-skip">—</span>'
    if isinstance(tr, dict):
        ok = tr.get("success", False)
        status_cls = "badge-ok" if ok else "badge-fail"
        label = "passed" if ok else "failed"
        extra = tr.get("tests_generated") or tr.get("coverage")
        if extra is not None:
            label += f" ({extra})"
        err = tr.get("error")
        err_block = f'<pre class="pre-block err small">{_esc(str(err))}</pre>' if err else ""
        return f'<span class="badge {status_cls}">{_esc(label)}</span>{err_block}'
    return f'<pre class="pre-block">{_esc(str(tr)[:500])}</pre>'


def _render_fix_results(results: List[Any]) -> str:
    if not results:
        return '<p class="muted">No fix entries.</p>'
    rows = []
    for i, r in enumerate(results[:50]):
        status = (r or {}).get("status", "?")
        vuln_idx = (r or {}).get("vuln_idx", i + 1)
        res = (r or {}).get("result") or {}
        err = (r or {}).get("error") or ""
        cls = "badge-ok" if status == "success" else ("badge-skip" if status == "skipped" else "badge-fail")
        rows.append(
            f"<tr><td>{_esc(vuln_idx)}</td><td><span class=\"badge {cls}\">{_esc(status)}</span></td>"
            f"<td class=\"cell-msg\">{_esc(err[:200] if err else (res.get('summary') or ''))}</td></tr>"
        )
    if len(results) > 50:
        rows.append(f"<tr><td colspan=\"3\" class=\"muted\">… and {len(results) - 50} more</td></tr>")
    return "<table class=\"fix-table\"><thead><tr><th>#</th><th>Status</th><th>Detail</th></tr></thead><tbody>" + "".join(rows) + "</tbody></table>"


def render_run_report_html(summary: Dict[str, Any], duration_secs: float) -> str:
    """
    Build a single self-contained HTML report string from the CLI run summary.
    """
    run_id = summary.get("run_id") or "—"
    total_with_vulns = summary.get("total_repos_with_vulns", 0)
    total_processed = summary.get("total_repos_processed", 0)
    results = summary.get("results") or []
    mapping = summary.get("mapping") or {}
    total_unmatched = mapping.get("total_unmatched", 0)
    unmatched = mapping.get("unmatched_vulnerabilities") or []
    duration_str = _format_duration(duration_secs)

    repo_cards_html: List[str] = []
    for entry in results:
        repo = entry.get("repo") or {}
        batch = entry.get("batch_results") or {}
        name = _repo_name(repo)
        url = _repo_url(repo)
        name_display = _esc(name)
        if url:
            name_display = f'<a href="{_esc(url)}" target="_blank" rel="noopener">{name_display}</a>'

        successful = batch.get("successful", 0)
        failed = batch.get("failed", 0)
        skipped = batch.get("skipped", 0)
        baseline = batch.get("baseline_test_results")
        build_ver = batch.get("build_verification")
        test_res = batch.get("test_results")
        fix_results_list = batch.get("results") or []
        pr = batch.get("batch_pr_result") or {}
        mapped_vulns = _get_repo_vulns_from_mapping(mapping, repo)

        baseline_html = _render_baseline_section(baseline)
        build_html = _render_build_section(build_ver)
        test_html = _render_test_section(test_res)
        fixes_table = _render_fix_results(fix_results_list)
        vuln_table = _render_vuln_table(mapped_vulns)

        pr_html = ""
        if pr.get("success"):
            pr_url = pr.get("pr_url") or "#"
            pr_num = pr.get("pr_number", "")
            pr_html = f'<a href="{_esc(pr_url)}" target="_blank" rel="noopener" class="pr-link">PR #{_esc(pr_num)}</a>'
        else:
            msg = pr.get("message") or pr.get("error")
            if msg:
                pr_html = f'<span class="muted">PR: {_esc(str(msg)[:120])}</span>'

        card = f"""
        <section class="card">
            <h2 class="card-title">{name_display}</h2>
            <div class="card-meta">
                <span class="meta-label">Fixes</span> <span class="badge badge-ok">{successful} ok</span>
                <span class="badge badge-fail">{failed} failed</span>
                <span class="badge badge-skip">{skipped} skipped</span>
                &nbsp;·&nbsp; <span class="meta-label">Build</span> {build_html}
                &nbsp;·&nbsp; <span class="meta-label">Validation</span> {test_html}
                {f'&nbsp;·&nbsp; {pr_html}' if pr_html else ''}
            </div>
            <details class="details" open>
                <summary>Mapped vulnerabilities (from CSV)</summary>
                <div class="details-body">{vuln_table}</div>
            </details>
            <details class="details">
                <summary>Baseline</summary>
                <div class="details-body">{baseline_html}</div>
            </details>
            <details class="details">
                <summary>Fix results</summary>
                <div class="details-body">{fixes_table}</div>
            </details>
            <details class="details">
                <summary>Raw repo results (debug)</summary>
                <div class="details-body">{_json_pretty_block(batch, max_chars=8000)}</div>
            </details>
        </section>
        """
        repo_cards_html.append(card.strip())

    cards_block = "\n".join(repo_cards_html) if repo_cards_html else "<p class=\"muted\">No repositories processed.</p>"
    unmatched_block = _json_pretty_block(unmatched, max_chars=6000) if unmatched else '<p class="muted">No unmatched vulnerabilities.</p>'

    html_str = f"""<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>ICSF Run Report — {_esc(run_id)}</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=DM+Sans:ital,opsz,wght@0,9..40,400;0,9..40,600;0,9..40,700;1,9..40,400&display=swap" rel="stylesheet">
    <style>
        :root {{
            --bg: #0f1419;
            --surface: #1a2332;
            --border: #2d3a4d;
            --text: #e6edf3;
            --muted: #8b9cb3;
            --ok: #3fb950;
            --fail: #f85149;
            --warn: #d29922;
            --accent: #58a6ff;
        }}
        * {{ box-sizing: border-box; }}
        body {{
            font-family: 'DM Sans', system-ui, sans-serif;
            background: var(--bg);
            color: var(--text);
            line-height: 1.5;
            margin: 0;
            padding: 1.5rem;
            max-width: 900px;
            margin-left: auto;
            margin-right: auto;
        }}
        h1 {{
            font-size: 1.5rem;
            font-weight: 700;
            margin: 0 0 0.25rem 0;
            color: var(--text);
        }}
        .topbar {{
            display: flex;
            gap: 0.75rem;
            align-items: center;
            justify-content: space-between;
            margin-bottom: 1.25rem;
        }}
        .search {{
            width: 340px;
            max-width: 100%;
            background: #0d1117;
            border: 1px solid var(--border);
            border-radius: 8px;
            padding: 0.55rem 0.75rem;
            color: var(--text);
            outline: none;
        }}
        .search::placeholder {{ color: var(--muted); }}
        .subtitle {{ color: var(--muted); font-size: 0.95rem; margin-bottom: 1.5rem; }}
        .summary {{
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(140px, 1fr));
            gap: 1rem;
            margin-bottom: 2rem;
        }}
        .summary-item {{
            background: var(--surface);
            border: 1px solid var(--border);
            border-radius: 8px;
            padding: 1rem;
        }}
        .summary-item .val {{ font-weight: 700; font-size: 1.25rem; color: var(--accent); }}
        .summary-item .lbl {{ font-size: 0.8rem; color: var(--muted); text-transform: uppercase; letter-spacing: 0.03em; }}
        .card {{
            background: var(--surface);
            border: 1px solid var(--border);
            border-radius: 10px;
            padding: 1.25rem 1.5rem;
            margin-bottom: 1.25rem;
        }}
        .card-title {{
            font-size: 1.1rem;
            font-weight: 600;
            margin: 0 0 0.5rem 0;
        }}
        .card-title a {{ color: var(--accent); text-decoration: none; }}
        .card-title a:hover {{ text-decoration: underline; }}
        .card-meta {{ font-size: 0.9rem; color: var(--muted); margin-bottom: 0.75rem; }}
        .meta-label {{ color: var(--text); }}
        .badge {{ display: inline-block; padding: 0.2em 0.5em; border-radius: 4px; font-size: 0.85em; font-weight: 600; }}
        .badge-ok {{ background: rgba(63,185,80,0.2); color: var(--ok); }}
        .badge-fail {{ background: rgba(248,81,73,0.2); color: var(--fail); }}
        .badge-skip {{ background: rgba(139,156,179,0.2); color: var(--muted); }}
        .pr-link {{ color: var(--accent); }}
        .details {{ margin-top: 0.75rem; border-top: 1px solid var(--border); padding-top: 0.75rem; }}
        .details summary {{ cursor: pointer; color: var(--muted); font-size: 0.9rem; }}
        .details-body {{ margin-top: 0.5rem; }}
        .pre-block {{ background: #0d1117; padding: 0.75rem; border-radius: 6px; overflow-x: auto; font-size: 0.85rem; white-space: pre-wrap; word-break: break-all; }}
        .pre-block.err {{ color: var(--fail); }}
        .pre-block.small {{ font-size: 0.8rem; max-height: 120px; overflow-y: auto; }}
        .fix-table {{ width: 100%; font-size: 0.9rem; border-collapse: collapse; }}
        .fix-table th, .fix-table td {{ padding: 0.4rem 0.6rem; text-align: left; border-bottom: 1px solid var(--border); }}
        .fix-table th {{ color: var(--muted); font-weight: 600; }}
        .cell-msg {{ max-width: 320px; overflow: hidden; text-overflow: ellipsis; }}
        .vuln-table {{ width: 100%; font-size: 0.9rem; border-collapse: collapse; }}
        .vuln-table th, .vuln-table td {{ padding: 0.4rem 0.6rem; text-align: left; border-bottom: 1px solid var(--border); vertical-align: top; }}
        .vuln-table th {{ color: var(--muted); font-weight: 600; }}
        .mono {{ font-family: ui-monospace, SFMono-Regular, Menlo, Consolas, monospace; font-size: 0.86em; }}
        .section {{
            background: rgba(13,17,23,0.25);
            border: 1px solid var(--border);
            border-radius: 10px;
            padding: 1rem 1.25rem;
            margin-bottom: 1.25rem;
        }}
        .muted {{ color: var(--muted); font-size: 0.9rem; }}
    </style>
</head>
<body>
    <header>
        <div class="topbar">
            <div>
                <h1>ICSF Run Report</h1>
                <p class="subtitle">Run ID: {_esc(run_id)} &nbsp;·&nbsp; Duration: {_esc(duration_str)}</p>
            </div>
            <input id="repoSearch" class="search" placeholder="Search repos (name, PR, build status)..." />
        </div>
    </header>
    <div class="summary">
        <div class="summary-item"><span class="lbl">Repos with vulnerabilities</span><div class="val">{total_with_vulns}</div></div>
        <div class="summary-item"><span class="lbl">Repos processed</span><div class="val">{total_processed}</div></div>
        <div class="summary-item"><span class="lbl">Duration</span><div class="val">{_esc(duration_str)}</div></div>
        <div class="summary-item"><span class="lbl">Unmatched vulnerabilities</span><div class="val">{_esc(total_unmatched)}</div></div>
    </div>
    <section class="section">
        <details class="details">
            <summary>Unmatched vulnerabilities (from CSV mapping)</summary>
            <div class="details-body">{unmatched_block}</div>
        </details>
    </section>
    <div class="cards">
        {cards_block}
    </div>
    <script>
      (function() {{
        const input = document.getElementById('repoSearch');
        if (!input) return;
        const cards = Array.from(document.querySelectorAll('.card'));
        function norm(s) {{ return (s || '').toLowerCase(); }}
        input.addEventListener('input', function() {{
          const q = norm(input.value);
          cards.forEach(card => {{
            const text = norm(card.innerText);
            card.style.display = text.includes(q) ? '' : 'none';
          }});
        }});
      }})();
    </script>
</body>
</html>
"""
    return html_str
