# Phase 3: Hebbian Reinforcement and Observability - Context

**Gathered:** 2026-03-18
**Status:** Ready for planning

<domain>
## Phase Boundary

Add query-time Hebbian reinforcement (entity pairs from search results get their co-occurrence weights strengthened) and observability (stats reporting, CLI inspection of top pairs).

</domain>

<decisions>
## Implementation Decisions

### Claude's Discretion
All implementation choices are at Claude's discretion — pure infrastructure phase.

</decisions>

<code_context>
## Existing Code Insights

### Reusable Assets
- `search.py:hybrid_search()` auto-record pattern (lines 581-591): Already inserts into note_usage after returning results — same pattern for co-occurrence reinforcement
- `server.py:vault_stats()`: Returns JSON stats — add co-occurrence pair count and weight mass
- `cli.py:cmd_decay()`: Reports note excitability — similar pattern for co-occurrence inspection

### Established Patterns
- Auto-recording wraps in try/except to never disrupt search (line 590)
- Stats reporting aggregates from multiple tables into a JSON dict
- CLI commands use click decorators and print formatted output

### Integration Points
- `search.py:hybrid_search()` — after returning results, extract entity pairs and reinforce weights
- `server.py:vault_stats()` — add co-occurrence stats to output dict
- `cli.py` — add `cooccurrence` subcommand or `--cooccurrence` flag to stats

</code_context>

<specifics>
## Specific Ideas

- Reinforcement should use bounded increment: `weight = min(weight * 1.1, max_weight)` or similar asymptotic formula
- The max_weight cap prevents runaway — suggest 100.0 as default cap
- Reinforcement should only fire for entity pairs that appear in BOTH query terms AND result triples (not all combinations)

</specifics>

<deferred>
## Deferred Ideas

None — discussion stayed within phase scope

</deferred>

---

*Phase: 03-hebbian-reinforcement-and-observability*
*Context gathered: 2026-03-18*
