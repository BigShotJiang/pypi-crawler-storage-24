---
phase: 01-schema-and-core-population
verified: 2026-03-18T02:15:00Z
status: gaps_found
score: 8/9 must-haves verified
re_verification: false
gaps:
  - truth: "Running neurostack index populates co-occurrence rows with non-zero weights"
    status: failed
    reason: "full_index() in watcher.py does not call detect_communities(). co-occurrence is only populated when 'neurostack communities build' is explicitly run. This gap is owned by Phase 2 (POP-03), but the ROADMAP lists it as a Phase 1 success criterion."
    artifacts:
      - path: "src/neurostack/watcher.py"
        issue: "full_index() ends after build_graph/compute_pagerank with no call to detect_communities or persist_cooccurrence"
    missing:
      - "Either: call detect_communities (or persist_cooccurrence directly) at the end of full_index(), OR update the ROADMAP Phase 1 success criterion #2 to reflect that index-flow co-occurrence population is Phase 2 scope (POP-03)"
---

# Phase 1: Schema and Core Population Verification Report

**Phase Goal:** Entity co-occurrence pairs are persisted in SQLite and populated from the existing triple extraction logic
**Verified:** 2026-03-18T02:15:00Z
**Status:** gaps_found
**Re-verification:** No — initial verification

## Goal Achievement

### Observable Truths

| # | Truth | Status | Evidence |
|---|-------|--------|----------|
| 1 | entity_cooccurrence table exists after migration with correct columns | VERIFIED | Table in SCHEMA_SQL lines 267-277; columns entity_a, entity_b, weight, last_seen; composite PK |
| 2 | Indexes on entity_a and entity_b enable bidirectional lookup | VERIFIED | idx_cooccurrence_a and idx_cooccurrence_b present in SCHEMA_SQL and MIGRATION_V12 |
| 3 | Migration from v11 to v12 runs without affecting existing tables or data | VERIFIED | `if current < 12` block in `_run_migrations()` line 705; test_migration_v11_to_v12 PASSES |
| 4 | Fresh schema creation includes entity_cooccurrence table | VERIFIED | In SCHEMA_SQL; test_schema_creation asserts entity_cooccurrence in expected set and PASSES |
| 5 | Entity co-occurrence pairs computed from triples in the same note | VERIFIED | persist_cooccurrence() in cooccurrence.py correctly builds note_entities dict and iterates per-note pairs |
| 6 | Co-occurrence weights persisted to entity_cooccurrence table | VERIFIED | DELETE + executemany INSERT into entity_cooccurrence; 7 cooccurrence tests all PASS |
| 7 | leiden.py calls persist_cooccurrence after triples are available | VERIFIED | detect_communities() calls persist_cooccurrence(conn) before build_note_graph (leiden.py line 169) |
| 8 | Entity pairs stored with entity_a < entity_b (canonical ordering) | VERIFIED | sorted(entities) + nested i/j loop guarantees canonical order; test_canonical_ordering PASSES |
| 9 | Running neurostack index populates co-occurrence rows | FAILED | cmd_index calls full_index() which calls build_graph/pagerank only — no detect_communities call |

**Score:** 8/9 truths verified

### Required Artifacts

| Artifact | Expected | Status | Details |
|----------|----------|--------|---------|
| `src/neurostack/schema.py` | MIGRATION_V12 constant and v12 migration block; entity_cooccurrence in SCHEMA_SQL | VERIFIED | SCHEMA_VERSION=12; entity_cooccurrence in SCHEMA_SQL (lines 267-277); MIGRATION_V12 constant (lines 489-500); migration block (lines 705-716) |
| `tests/test_schema.py` | Tests for v12 migration and cooccurrence table | VERIFIED | 5 new tests: test_cooccurrence_table_columns, test_cooccurrence_indexes, test_cooccurrence_composite_pk, test_migration_v11_to_v12, test_migration_v12_idempotent |
| `src/neurostack/cooccurrence.py` | persist_cooccurrence() function | VERIFIED | Full implementation, 76 lines, reads triples, computes weights, persists with DELETE+INSERT |
| `src/neurostack/leiden.py` | Call to persist_cooccurrence from detect_communities | VERIFIED | Import at line 28; call at line 169 inside detect_communities() |
| `tests/test_cooccurrence.py` | Tests for co-occurrence computation and persistence | VERIFIED | 7 tests covering pairs, weights, canonical ordering, idempotency, last_seen |

### Key Link Verification

| From | To | Via | Status | Details |
|------|----|-----|--------|---------|
| `src/neurostack/schema.py` | `SCHEMA_SQL` | CREATE TABLE IF NOT EXISTS entity_cooccurrence in base schema | VERIFIED | Present at schema.py lines 267-277 |
| `src/neurostack/schema.py` | `_run_migrations` | if current < 12 block running MIGRATION_V12 | VERIFIED | Block at lines 705-716; executescript(MIGRATION_V12) called |
| `src/neurostack/leiden.py` | `src/neurostack/cooccurrence.py` | from .cooccurrence import persist_cooccurrence | VERIFIED | Import present at leiden.py line 28 |
| `src/neurostack/cooccurrence.py` | entity_cooccurrence table | INSERT OR REPLACE INTO entity_cooccurrence | PARTIAL | Uses executemany INSERT (not INSERT OR REPLACE) with a preceding DELETE — functionally equivalent but pattern differs from key_link spec. Full replacement achieved by DELETE+INSERT which is correct. |
| `src/neurostack/watcher.py` | `detect_communities` | full_index calls co-occurrence persistence | NOT WIRED | full_index() has no call to detect_communities or persist_cooccurrence. Co-occurrence only runs via `neurostack communities build`. |

### Requirements Coverage

| Requirement | Source Plan | Description | Status | Evidence |
|-------------|-------------|-------------|--------|----------|
| SCHM-01 | 01-01-PLAN.md | entity_cooccurrence table with columns (entity_a, entity_b, weight, last_seen) | SATISFIED | Table definition in SCHEMA_SQL and MIGRATION_V12; all 4 columns verified |
| SCHM-02 | 01-01-PLAN.md | Indexes on both entity_a and entity_b for bidirectional lookup | SATISFIED | idx_cooccurrence_a and idx_cooccurrence_b in schema and migration; test_cooccurrence_indexes PASSES |
| SCHM-03 | 01-01-PLAN.md | Schema migration (v12+) creates table cleanly without affecting existing data | SATISFIED | Migration block uses CREATE IF NOT EXISTS; test_migration_v11_to_v12 verifies note data preserved |
| POP-01 | 01-02-PLAN.md | Co-occurrence weights computed from triple extraction (shared subjects/objects within the same note) | SATISFIED | persist_cooccurrence() queries triples table, builds note_entities per-note, computes pairs; tests verify weight=2.0 for two notes sharing entities |
| POP-02 | 01-02-PLAN.md | Existing leiden.py co-occurrence computation refactored to persist weights | SATISFIED | detect_communities() now calls persist_cooccurrence(conn) before build_note_graph; weights written to entity_cooccurrence table |

**Orphaned requirements check:** REQUIREMENTS.md maps POP-03 and POP-04 to Phase 2, RETR-01/02/03 to Phase 2, HEBB-01/02/03 and OBS-01/02 to Phase 3. All requirements in plans 01-01 and 01-02 (SCHM-01, SCHM-02, SCHM-03, POP-01, POP-02) are accounted for and satisfied. No orphaned requirements for Phase 1.

### Anti-Patterns Found

| File | Line | Pattern | Severity | Impact |
|------|------|---------|----------|--------|
| None | - | - | - | - |

No TODO/FIXME/placeholder patterns found in any modified files. No stub implementations. No empty handlers.

### Human Verification Required

No items require human verification. All behaviors are verifiable programmatically via the test suite.

### Gaps Summary

**One gap blocks full goal achievement against the ROADMAP's stated success criteria.**

ROADMAP Phase 1 success criterion #2 states: "Running `neurostack index` on a vault with triples populates co-occurrence rows with non-zero weights." This is NOT satisfied. The `neurostack index` CLI command calls `full_index()` in `watcher.py`, which indexes notes, builds the wiki-link graph, and computes PageRank — but does not call `detect_communities()` or `persist_cooccurrence()` directly.

Co-occurrence data is only persisted when `neurostack communities build` is explicitly run, which invokes `detect_communities()` in `leiden.py`.

**Root cause:** The ROADMAP success criterion #2 describes behavior that belongs to POP-03 ("Co-occurrence table is populated during `neurostack index` and `neurostack watch` flows"), which is explicitly assigned to Phase 2 in both REQUIREMENTS.md and the ROADMAP traceability table. There is a mismatch between Phase 1's stated success criteria and the requirement scope assigned to Phase 1.

**Resolution options (either one closes the gap):**

1. **Wire it now (narrower change):** At the end of `full_index()` in `watcher.py`, call `persist_cooccurrence(conn)` directly (without requiring Leiden). This satisfies the ROADMAP criterion within Phase 1 scope without pulling in all of POP-03.

2. **Clarify scope (planning fix):** Update the ROADMAP to move success criterion #2 to Phase 2, making it explicit that index-flow co-occurrence population is Phase 2 work. Phase 1 delivered what its plans specified (SCHM-01/02/03, POP-01, POP-02 all satisfied).

The 5 declared phase requirements (SCHM-01, SCHM-02, SCHM-03, POP-01, POP-02) are all fully satisfied. The gap is against the ROADMAP success criterion, not the requirement IDs.

---

_Verified: 2026-03-18T02:15:00Z_
_Verifier: Claude (gsd-verifier)_
