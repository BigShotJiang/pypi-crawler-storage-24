# Phase 1: Schema and Core Population - Context

**Gathered:** 2026-03-18
**Status:** Ready for planning

<domain>
## Phase Boundary

Add the `entity_cooccurrence` table to NeuroStack's SQLite schema (migration v12) and refactor leiden.py to persist entity co-occurrence weights during the `build_note_graph()` computation that currently discards them.

</domain>

<decisions>
## Implementation Decisions

### Claude's Discretion
All implementation choices are at Claude's discretion — pure infrastructure phase.

</decisions>

<code_context>
## Existing Code Insights

### Reusable Assets
- `leiden.py:build_note_graph()` (lines 40-89): Already computes entity co-occurrence via `entity_notes` dict and `note_weights` dict. The `entity_notes` mapping (entity → set of note_paths) is exactly what we need for entity-entity co-occurrence
- `schema.py`: SCHEMA_VERSION is 11, migrations go up to v11 (note_metadata). V12 is the next slot
- `schema.py:_run_migrations()`: Pattern for adding new migration is clear — add MIGRATION_V12, add `if current < 12:` block

### Established Patterns
- Schema: all tables use `CREATE TABLE IF NOT EXISTS`, indexes use `CREATE INDEX IF NOT EXISTS`
- Migrations: each version gets its own `MIGRATION_VN` string constant and `if current < N:` block in `_run_migrations()`
- Entity names come from `triples.subject` and `triples.object` columns

### Integration Points
- `leiden.py:build_note_graph()` is the natural insertion point — it already iterates over entity co-occurrence
- `watcher.py:_index_triples_for_note()` is called per-note during indexing — could also populate co-occurrence per-note
- The co-occurrence table should be joinable with triples table via subject/object entity names

</code_context>

<specifics>
## Specific Ideas

- Reuse leiden.py's existing `entity_notes` dict pattern but compute entity-entity pairs instead of note-note pairs
- The table should use a composite primary key (entity_a, entity_b) with entity_a < entity_b to avoid duplicates
- Weight represents co-occurrence frequency (number of notes both entities appear in)

</specifics>

<deferred>
## Deferred Ideas

None — discussion stayed within phase scope

</deferred>

---

*Phase: 01-schema-and-core-population*
*Context gathered: 2026-03-18*
