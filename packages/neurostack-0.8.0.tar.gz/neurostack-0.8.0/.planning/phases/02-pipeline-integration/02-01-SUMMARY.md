---
phase: 02-pipeline-integration
plan: 01
subsystem: database
tags: [sqlite, cooccurrence, knowledge-graph, watcher, cli]

requires:
  - phase: 01-schema-and-core-population
    provides: entity_cooccurrence table and persist_cooccurrence function
provides:
  - upsert_cooccurrence_for_note for incremental per-note co-occurrence updates
  - Co-occurrence wiring in watcher indexing flows
  - CLI backfill cooccurrence target
affects: [02-pipeline-integration, retrieval, communities]

tech-stack:
  added: []
  patterns: [incremental upsert with stale pair cleanup via neighbor lookup]

key-files:
  created: []
  modified:
    - src/neurostack/cooccurrence.py
    - src/neurostack/watcher.py
    - src/neurostack/cli.py
    - tests/test_cooccurrence.py

key-decisions:
  - "Stale pair cleanup via co-occurrence neighbor lookup to handle entity removal on re-index"

patterns-established:
  - "Per-note upsert pattern: recompute weight globally for affected pairs, clean up zero-weight pairs"

requirements-completed: [POP-03, POP-04]

duration: 3min
completed: 2026-03-18
---

# Phase 02 Plan 01: Co-occurrence Pipeline Integration Summary

**Per-note incremental co-occurrence upsert with stale pair cleanup, watcher wiring, and CLI backfill target**

## Performance

- **Duration:** 3 min
- **Started:** 2026-03-18T02:03:15Z
- **Completed:** 2026-03-18T02:06:42Z
- **Tasks:** 2
- **Files modified:** 4

## Accomplishments
- Added `upsert_cooccurrence_for_note()` for incremental per-note co-occurrence updates with stale pair cleanup
- Wired co-occurrence into `_index_triples_for_note` (per-note) and `full_index` (full rebuild)
- Added "cooccurrence" as a CLI backfill target alongside summaries/triples/all

## Task Commits

Each task was committed atomically:

1. **Task 1: Add upsert_cooccurrence_for_note and wire into watcher** - `1ef3506` (test) + `601d0af` (feat)
2. **Task 2: Add cooccurrence backfill target to CLI** - `4756784` (feat)

_Note: Task 1 used TDD with separate test and implementation commits._

## Files Created/Modified
- `src/neurostack/cooccurrence.py` - Added upsert_cooccurrence_for_note with neighbor-based stale pair cleanup
- `src/neurostack/watcher.py` - Wired upsert into _index_triples_for_note, persist into full_index
- `src/neurostack/cli.py` - Added cooccurrence to backfill choices and cmd_backfill handler
- `tests/test_cooccurrence.py` - 5 new tests for upsert function (12 total)

## Decisions Made
- Stale pair cleanup via co-occurrence neighbor lookup: when upserting for a note, also look up entities previously paired in co-occurrence table to detect and remove pairs for entities removed from the note

## Deviations from Plan

### Auto-fixed Issues

**1. [Rule 1 - Bug] Added stale pair cleanup to upsert function**
- **Found during:** Task 1 (GREEN phase)
- **Issue:** Plan's upsert implementation only considered current note entities, leaving orphaned co-occurrence pairs when entities were removed from a note during re-indexing
- **Fix:** Before computing pairs, query co-occurrence table for entities previously paired with current entities, include them in the iteration, and delete pairs with zero weight
- **Files modified:** src/neurostack/cooccurrence.py
- **Verification:** test_upsert_re_upsert_same_note_recalculates passes
- **Committed in:** 601d0af (Task 1 feat commit)

---

**Total deviations:** 1 auto-fixed (1 bug fix)
**Impact on plan:** Essential for correctness when notes change content. No scope creep.

## Issues Encountered
None

## User Setup Required
None - no external service configuration required.

## Next Phase Readiness
- Co-occurrence is now maintained during all indexing flows
- Ready for retrieval reinforcement (plan 02-02) which will use co-occurrence weights at query time

---
*Phase: 02-pipeline-integration*
*Completed: 2026-03-18*
