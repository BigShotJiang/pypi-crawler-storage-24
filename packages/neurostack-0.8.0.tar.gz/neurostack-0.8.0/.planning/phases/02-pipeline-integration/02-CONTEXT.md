# Phase 2: Pipeline Integration - Context

**Gathered:** 2026-03-18
**Status:** Ready for planning

<domain>
## Phase Boundary

Wire co-occurrence population into all indexing flows (watcher, backfill) and integrate co-occurrence boost as a scoring stage in hybrid_search().

</domain>

<decisions>
## Implementation Decisions

### Claude's Discretion
All implementation choices are at Claude's discretion — pure infrastructure phase.

</decisions>

<code_context>
## Existing Code Insights

### Reusable Assets
- `watcher.py:_index_triples_for_note()` (line 229): Called per-note during indexing — after triples are inserted, extract entity pairs and upsert co-occurrence
- `search.py:hybrid_search()` (lines 438-606): Scoring pipeline has clear stages — co-occurrence boost slots after hotness blend (line 528) and before excitability boost (line 530)
- `cli.py`: Has `backfill` command that could trigger co-occurrence population

### Established Patterns
- Scoring pipeline: FTS+cosine composite → context boost → hotness blend → excitability boost → sort → dedup → rerank
- `_get_context_notes()` (search.py): Uses entity lookups from triples table — same pattern can query co-occurrence table
- Config via `get_config()` from config.py — boost weight should be configurable there

### Integration Points
- `watcher.py:_index_triples_for_note()` — after triple insertion, populate co-occurrence
- `search.py:hybrid_search()` — new scoring stage between hotness and excitability
- `cli.py:cmd_backfill()` — add co-occurrence backfill option
- `leiden.py:build_note_graph()` — should call shared co-occurrence population function

</code_context>

<specifics>
## Specific Ideas

No specific requirements — open to standard approaches

</specifics>

<deferred>
## Deferred Ideas

None — discussion stayed within phase scope

</deferred>

---

*Phase: 02-pipeline-integration*
*Context gathered: 2026-03-18*
