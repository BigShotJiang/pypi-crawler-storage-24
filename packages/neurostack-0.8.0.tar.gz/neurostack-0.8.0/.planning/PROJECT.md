# NeuroStack Hebbian Co-occurrence Learning

## What This Is

Adding persistent entity co-occurrence tracking to NeuroStack's retrieval pipeline. When entities (triple subjects/objects) appear together across vault notes, their association strengthens over time. At query time, co-occurring entities boost retrieval of related notes -- enabling vault-specific association learning that the pretrained embedding model cannot provide.

## Core Value

Retrieval discovers vault-specific concept associations that pure semantic search misses -- "neurons that fire together wire together" applied to knowledge retrieval.

## Requirements

### Validated

(None yet -- ship to validate)

### Active

- [ ] Persistent entity co-occurrence table populated from triple extraction
- [ ] Co-occurrence weights reinforced at query time (Hebbian learning)
- [ ] Co-occurring entity boost integrated into hybrid_search scoring pipeline
- [ ] Reuse of existing co-occurrence computation from leiden.py (persist what it currently discards)

### Out of Scope

- Full engram/cue separation model -- triples already serve as retrieval keys
- Exponential decay / auto-pruning -- NeuroStack already has hotness_score() with decay
- Access-count reinforcement -- already implemented via note_usage + hotness_score
- Lazy HNSW indexing -- brute-force NumPy is sub-5ms at current scale
- Multi-hop graph traversal -- separate improvement, not Hebbian
- Memory table access tracking -- separate quick win

## Context

**Origin:** Stochastic 5-agent analysis comparing Smriti-MCP concepts against NeuroStack's existing architecture (2026-03-18). Co-occurrence was the only concept from the engram/cue model deemed worth borrowing.

**Current state:** NeuroStack's Leiden community detection (`leiden.py` lines 57-73) already computes entity co-occurrence from shared triple subjects/objects across notes, but discards the weights after building the community graph. Persisting these weights and reinforcing them at retrieval time is the core improvement.

**Existing retrieval pipeline** (`search.py` hybrid_search):
1. FTS5 + semantic scoring: `0.3 * fts + 0.7 * cosine`
2. Context boost: direct 1.4x, 1-hop 1.2x
3. Hotness blend: `0.8 * semantic + 0.2 * hotness`
4. Excitability boost: active notes 1.15x
5. Optional cross-encoder reranking

Co-occurrence boost would slot in as a new scoring stage.

**Scale:** 393 notes, 4,386 triples, 1,654 graph edges. Entity pair count estimated at ~2,000-5,000.

## Constraints

- **Architecture**: NeuroStack NEVER modifies vault files. All computed state lives in SQLite (`~/.local/share/neurostack/`)
- **Tech stack**: Python, SQLite + FTS5, uv for deps, pytest for tests
- **Performance**: Search latency must stay <= 100ms (currently ~50ms)
- **Dependencies**: No new external dependencies -- uses existing SQLite + NumPy
- **Existing schema**: Must be a clean migration (v12+), not modify existing tables

## Key Decisions

| Decision | Rationale | Outcome |
|----------|-----------|---------|
| Co-occurrence only, skip full cue separation | Triples already serve as structured retrieval keys; separate cue entities would duplicate existing functionality | -- Pending |
| Populate from triple extraction, not a separate LLM pass | leiden.py already computes this; persisting saves compute and avoids new LLM costs | -- Pending |
| Reinforce at query time, not just index time | Hebbian principle: associations strengthen through use, not just co-existence | -- Pending |

---
*Last updated: 2026-03-18 after initialization*
