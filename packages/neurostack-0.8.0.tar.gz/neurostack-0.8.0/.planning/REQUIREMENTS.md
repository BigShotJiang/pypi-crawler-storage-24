# Requirements: NeuroStack Hebbian Co-occurrence Learning

**Defined:** 2026-03-18
**Core Value:** Retrieval discovers vault-specific concept associations that pure semantic search misses

## v1 Requirements

### Schema

- [x] **SCHM-01**: New `entity_cooccurrence` table stores entity pair weights with columns (entity_a, entity_b, weight, last_seen)
- [x] **SCHM-02**: Table has indexes on both entity_a and entity_b for bidirectional lookup
- [x] **SCHM-03**: Schema migration (v12+) creates table cleanly without affecting existing data

### Population

- [x] **POP-01**: Co-occurrence weights are computed from triple extraction (shared subjects/objects across notes within the same note)
- [x] **POP-02**: Existing leiden.py co-occurrence computation is refactored to persist weights instead of discarding them
- [x] **POP-03**: Co-occurrence table is populated during `neurostack index` and `neurostack watch` (watcher) flows
- [x] **POP-04**: Backfill command populates co-occurrence from existing triples

### Retrieval Integration

- [x] **RETR-01**: hybrid_search() uses co-occurrence weights to boost notes containing entities that co-occur with query-matched entities
- [x] **RETR-02**: Co-occurrence boost is a distinct scoring stage in the pipeline (after hotness blend, before reranking)
- [x] **RETR-03**: Boost weight is configurable and defaults to a conservative value that does not dominate semantic scoring

### Hebbian Reinforcement

- [x] **HEBB-01**: When hybrid_search() returns results, entity pairs from the query and result triples have their co-occurrence weights reinforced
- [x] **HEBB-02**: Reinforcement uses bounded increment (no runaway weights) -- e.g., multiplicative with asymptote or additive with cap
- [x] **HEBB-03**: Weight reinforcement is transactional and does not add measurable latency to search (<5ms overhead)

### Observability

- [x] **OBS-01**: `neurostack stats` reports co-occurrence table size (entity pairs count, total weight mass)
- [x] **OBS-02**: CLI command or flag to inspect top co-occurring entity pairs

## v2 Requirements

### Decay

- **DECAY-01**: Co-occurrence weights decay over time if not reinforced (temporal Hebbian)
- **DECAY-02**: Configurable decay half-life

### Advanced

- **ADV-01**: Co-occurrence informs community detection (feed weights into Leiden graph)
- **ADV-02**: MCP tool to query co-occurrence graph directly

## Out of Scope

| Feature | Reason |
|---------|--------|
| Full engram/cue separation | Triples already serve as structured retrieval keys |
| Separate cue extraction LLM pass | leiden.py already computes co-occurrence; no new LLM cost |
| Cross-note entity resolution | Entity normalization is a separate concern |
| Negative co-occurrence (anti-Hebbian) | Unnecessary complexity for initial implementation |

## Traceability

| Requirement | Phase | Status |
|-------------|-------|--------|
| SCHM-01 | Phase 1 | Complete |
| SCHM-02 | Phase 1 | Complete |
| SCHM-03 | Phase 1 | Complete |
| POP-01 | Phase 1 | Complete |
| POP-02 | Phase 1 | Complete |
| POP-03 | Phase 2 | Complete |
| POP-04 | Phase 2 | Complete |
| RETR-01 | Phase 2 | Complete |
| RETR-02 | Phase 2 | Complete |
| RETR-03 | Phase 2 | Complete |
| HEBB-01 | Phase 3 | Complete |
| HEBB-02 | Phase 3 | Complete |
| HEBB-03 | Phase 3 | Complete |
| OBS-01 | Phase 3 | Complete |
| OBS-02 | Phase 3 | Complete |

**Coverage:**
- v1 requirements: 15 total
- Mapped to phases: 15
- Unmapped: 0

---
*Requirements defined: 2026-03-18*
*Last updated: 2026-03-18 after roadmap creation*
