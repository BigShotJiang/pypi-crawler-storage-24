# Roadmap: NeuroStack Hebbian Co-occurrence Learning

## Overview

Three phases transform NeuroStack's retrieval pipeline from pure semantic search to association-aware retrieval. First, the co-occurrence schema and core computation are established by persisting what leiden.py currently discards. Second, the co-occurrence data is wired into the indexing flows and search pipeline. Third, Hebbian reinforcement closes the loop -- search usage strengthens associations -- and observability surfaces the learned associations.

## Phases

**Phase Numbering:**
- Integer phases (1, 2, 3): Planned milestone work
- Decimal phases (2.1, 2.2): Urgent insertions (marked with INSERTED)

Decimal phases appear between their surrounding integers in numeric order.

- [x] **Phase 1: Schema and Core Population** - Co-occurrence table exists and is populated from triple extraction (completed 2026-03-18)
- [x] **Phase 2: Pipeline Integration** - Co-occurrence data flows through indexing and boosts search results (completed 2026-03-18)
- [x] **Phase 3: Hebbian Reinforcement and Observability** - Search usage strengthens associations; co-occurrence is inspectable (completed 2026-03-18)

## Phase Details

### Phase 1: Schema and Core Population
**Goal**: Entity co-occurrence pairs are persisted in SQLite and populated from the existing triple extraction logic
**Depends on**: Nothing (first phase)
**Requirements**: SCHM-01, SCHM-02, SCHM-03, POP-01, POP-02
**Success Criteria** (what must be TRUE):
  1. `entity_cooccurrence` table exists in the database after migration with correct columns and indexes
  2. Running `neurostack communities build` populates co-occurrence rows with non-zero weights (full indexing flow wiring is Phase 2 / POP-03)
  3. leiden.py's co-occurrence computation persists weights to SQLite instead of discarding them
  4. Existing data and tables are untouched by the migration
**Plans:** 2/2 plans complete

Plans:
- [x] 01-01-PLAN.md -- Schema migration v12: entity_cooccurrence table with indexes
- [x] 01-02-PLAN.md -- Co-occurrence persistence from triples, wired into leiden.py

### Phase 2: Pipeline Integration
**Goal**: Co-occurrence data is maintained through all indexing flows and boosts hybrid search results
**Depends on**: Phase 1
**Requirements**: POP-03, POP-04, RETR-01, RETR-02, RETR-03
**Success Criteria** (what must be TRUE):
  1. `neurostack watch` (watcher) updates co-occurrence when new notes are indexed
  2. `neurostack backfill` populates co-occurrence from all existing triples
  3. hybrid_search() results are influenced by co-occurrence -- a note with strongly co-occurring entities ranks higher than it would by semantic score alone
  4. Co-occurrence boost is a distinct, configurable stage in the scoring pipeline that does not dominate semantic relevance
**Plans:** 2/2 plans complete

Plans:
- [ ] 02-01-PLAN.md -- Co-occurrence population in watcher, full_index, and backfill CLI
- [ ] 02-02-PLAN.md -- Co-occurrence boost stage in hybrid_search with configurable weight

### Phase 3: Hebbian Reinforcement and Observability
**Goal**: Search usage reinforces entity associations over time and the learned associations are visible to the user
**Depends on**: Phase 2
**Requirements**: HEBB-01, HEBB-02, HEBB-03, OBS-01, OBS-02
**Success Criteria** (what must be TRUE):
  1. After repeated searches involving the same entity pairs, their co-occurrence weight increases
  2. Weight reinforcement is bounded -- no entity pair can reach runaway weight regardless of search volume
  3. Search latency remains under 100ms with reinforcement active (less than 5ms overhead from reinforcement writes)
  4. `neurostack stats` shows co-occurrence table size (pair count, total weight mass)
  5. A CLI command or flag displays top co-occurring entity pairs
**Plans:** 2/2 plans complete

Plans:
- [ ] 03-01-PLAN.md -- Hebbian reinforcement: bounded weight increment at query time
- [ ] 03-02-PLAN.md -- Observability: co-occurrence stats and CLI inspection

## Progress

**Execution Order:**
Phases execute in numeric order: 1 -> 2 -> 3

| Phase | Plans Complete | Status | Completed |
|-------|----------------|--------|-----------|
| 1. Schema and Core Population | 2/2 | Complete    | 2026-03-18 |
| 2. Pipeline Integration | 0/2 | Complete    | 2026-03-18 |
| 3. Hebbian Reinforcement and Observability | 0/2 | Complete    | 2026-03-18 |
