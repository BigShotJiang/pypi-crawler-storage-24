"""
End-to-End Integration Tests for HardRAGGuard

Tests the complete pipeline with all guardrails working together.
"""
import pytest
from hardrag import HardRAGGuard


class TestHardRAGGuardIntegration:
    """Integration tests for complete HardRAG Guard pipeline"""
    
    def test_all_guardrails_pass(self):
        """Test output that passes all guardrails"""
        guard = HardRAGGuard(
            guardrails=["pii"],  # Start with just PII for non-DSPy test
            config={
                "pii": {"threshold": 0.7}
            }
        )
        
        result = guard.validate(
            query="What was our revenue last quarter?",
            retrieved_sources=["Company revenue for Q4 was $10 million."],
            llm_output="The company's revenue for Q4 was $10 million."
        )
        
        assert result.is_valid is True
        assert len(result.violations) == 0
        assert result.execution_time_ms > 0
        assert result.audit_trail["timestamp"] is not None
    
    def test_pii_detection_blocks_output(self):
        """Test that PII in output is detected and blocked"""
        guard = HardRAGGuard(guardrails=["pii"])
        
        result = guard.validate(
            query="Who is our customer?",
            retrieved_sources=["Customer John Smith, email: john@customer.com"],
            llm_output="The customer is John Smith at john@customer.com"
        )
        
        assert result.is_valid is False
        assert len(result.violations) > 0
        assert result.violations[0]["type"] == "PII_DETECTED"
        assert result.anonymized_output is not None
        assert "john@customer.com" not in result.anonymized_output
    
    def test_toxicity_detection_blocks_output(self):
        """Test that toxic content is detected"""
        guard = HardRAGGuard(
            guardrails=["toxicity"],
            config={
                "toxicity": {"use_ml": False}  # Use simple for testing
            }
        )
        
        result = guard.validate(
            query="What do you think?",
            retrieved_sources=["Context here"],
            llm_output="You are stupid and this is a dumb question"
        )
        
        assert result.is_valid is False
        assert len(result.violations) > 0
        assert "TOXICITY" in result.violations[0]["type"]
    
    def test_multiple_guardrails_together(self):
        """Test multiple guardrails working together"""
        guard = HardRAGGuard(
            guardrails=["pii", "toxicity"],
            config={
                "pii": {"threshold": 0.7},
                "toxicity": {"use_ml": False}
            }
        )
        
        # Output with both PII and toxicity
        result = guard.validate(
            query="Test query",
            retrieved_sources=["Context"],
            llm_output="Email john@test.com and tell him he's an idiot"
        )
        
        assert result.is_valid is False
        assert len(result.violations) >= 2  # At least PII and toxicity
        
        # Check both violations present
        violation_types = [v["type"] for v in result.violations]
        assert any("PII" in vtype for vtype in violation_types)
        assert any("TOXICITY" in vtype for vtype in violation_types)
    
    def test_strict_mode_stops_early(self):
        """Test that strict mode stops on first violation"""
        guard = HardRAGGuard(
            guardrails=["pii", "toxicity"],
            strict=True
        )
        
        result = guard.validate(
            query="Query",
            retrieved_sources=["Context"],
            llm_output="Email at john@test.com"  # Will fail PII first
        )
        
        assert result.is_valid is False
        # In strict mode, might only have PII violation (stopped early)
        assert len(result.violations) >= 1
    
    def test_audit_trail_completeness(self):
        """Test that audit trail contains all required information"""
        guard = HardRAGGuard(guardrails=["pii"])
        
        metadata = {"user_id": "user123", "session_id": "session456"}
        
        result = guard.validate(
            query="What is the answer?",
            retrieved_sources=["Answer is here", "More context"],
            llm_output="The answer is 42",
            metadata=metadata
        )
        
        # Check audit trail
        assert "timestamp" in result.audit_trail
        assert result.audit_trail["query"] == "What is the answer?"
        assert result.audit_trail["sources_count"] == 2
        assert result.audit_trail["output_length"] == len("The answer is 42")
        assert result.audit_trail["guardrails_checked"] == ["pii"]
        assert result.audit_trail["metadata"] == metadata
        assert "execution_time_ms" in result.audit_trail
    
    def test_batch_validation(self):
        """Test batch validation of multiple outputs"""
        guard = HardRAGGuard(guardrails=["pii"])
        
        queries = [
            "Query 1",
            "Query 2",
            "Query 3"
        ]
        
        sources_list = [
            ["Source 1"],
            ["Source 2"],
            ["Source 3"]
        ]
        
        outputs = [
            "Clean output 1",
            "Email: user@test.com",  # Has PII
            "Clean output 3"
        ]
        
        results = guard.validate_batch(queries, sources_list, outputs)
        
        assert len(results) == 3
        assert results[0].is_valid is True
        assert results[1].is_valid is False  # PII detected
        assert results[2].is_valid is True
    
    def test_evaluation_scores(self):
        """Test that evaluation scores are calculated"""
        guard = HardRAGGuard(guardrails=["pii", "toxicity"], config={"toxicity": {"use_ml": False}})
        
        result = guard.validate(
            query="Query",
            retrieved_sources=["Context"],
            llm_output="Clean and friendly response"
        )
        
        # Should have scores for each guardrail
        assert "pii_free" in result.evaluation_scores
        assert "toxicity" in result.evaluation_scores
        
        # Clean output should score well
        assert result.evaluation_scores["pii_free"] == 1.0
    
    def test_suggestions_provided(self):
        """Test that suggestions are provided on violations"""
        guard = HardRAGGuard(guardrails=["pii"])
        
        result = guard.validate(
            query="Query",
            retrieved_sources=["Context"],
            llm_output="Contact admin@company.com"
        )
        
        assert result.is_valid is False
        assert len(result.suggestions) > 0
        assert any("PII" in s or "anonymize" in s.lower() for s in result.suggestions)
    
    def test_custom_config_per_guardrail(self):
        """Test custom configuration for each guardrail"""
        guard = HardRAGGuard(
            guardrails=["pii", "toxicity"],
            config={
                "pii": {
                    "threshold": 0.9,  # Stricter
                    "allow_list": ["@company.com"]
                },
                "toxicity": {
                    "threshold": 0.5,  # More lenient
                    "use_ml": False
                }
            }
        )
        
        # Company email should be allowed
        result = guard.validate(
            query="Contact info",
            retrieved_sources=["Context"],
            llm_output="Contact support@company.com for help"
        )
        
        # Should pass (company email in allow list)
        # Note: actual behavior depends on Presidio's allow_list handling
        assert result is not None
    
    def test_error_handling_in_guardrails(self):
        """Test that errors in individual guardrails are handled gracefully"""
        guard = HardRAGGuard(guardrails=["pii"])
        
        # This should not crash even with edge cases
        result = guard.validate(
            query="",
            retrieved_sources=[],
            llm_output=""
        )
        
        assert result is not None
        assert hasattr(result, "is_valid")


class TestHardRAGGuardConfiguration:
    """Tests for configuration options"""
    
    def test_initialization_with_defaults(self):
        """Test guard initializes with default config"""
        guard = HardRAGGuard(guardrails=["pii"])
        
        assert guard.guardrails == ["pii"]
        assert guard.evaluation_mode == "standard"
        assert guard.strict is False
    
    def test_initialization_with_strict_mode(self):
        """Test strict mode initialization"""
        guard = HardRAGGuard(
            guardrails=["pii", "toxicity"],
            strict=True
        )
        
        assert guard.strict is True
    
    def test_unknown_guardrail_ignored(self):
        """Test that unknown guardrails are handled"""
        # Should not crash
        guard = HardRAGGuard(guardrails=["pii", "unknown_guardrail"])
        
        result = guard.validate(
            query="Query",
            retrieved_sources=["Context"],
            llm_output="Output"
        )
        
        # Should still work with known guardrails
        assert result is not None
