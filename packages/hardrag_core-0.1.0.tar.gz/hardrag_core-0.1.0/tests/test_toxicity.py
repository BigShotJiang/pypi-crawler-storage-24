"""
Test Toxicity Guardrail
"""
import pytest
from hardrag.guardrails.toxicity import ToxicityGuardrail, SimpleToxicityGuardrail


class TestSimpleToxicityGuardrail:
    """Tests for rule-based toxicity guardrail (no ML)"""
    
    def setup_method(self):
        """Setup test fixtures"""
        self.guardrail = SimpleToxicityGuardrail(threshold=0.5)
    
    def test_clean_text(self):
        """Test clean text passes"""
        text = "This is a helpful and friendly message."
        result = self.guardrail.detect(text)
        
        assert result["is_toxic"] is False
        assert result["toxicity_score"] == 0.0
    
    def test_toxic_keywords(self):
        """Test toxic keywords detection"""
        text = "You are so stupid and dumb"
        result = self.guardrail.detect(text)
        
        assert result["is_toxic"] is True
        assert result["toxicity_score"] > 0
        assert "insults" in result["categories_detected"]
    
    def test_validation_blocks_toxic(self):
        """Test validation blocks toxic content"""
        text = "This is hate speech"
        result = self.guardrail.validate(text, block_if_toxic=True)
        
        assert result["is_valid"] is False
        assert result["toxicity_detected"] is True
        assert len(result["violations"]) > 0
    
    def test_validation_allows_clean(self):
        """Test validation allows clean content"""
        text = "Thank you for your help"
        result = self.guardrail.validate(text, block_if_toxic=True)
        
        assert result["is_valid"] is True
        assert result["toxicity_detected"] is False


class TestMLToxicityGuardrail:
    """
    Tests for ML-based toxicity guardrail
    
    Note: These tests require transformers and torch
    Skip if not installed
    """
    
    def setup_method(self):
        """Setup test fixtures"""
        try:
            self.guardrail = ToxicityGuardrail(threshold=0.7)
        except ImportError:
            pytest.skip("transformers/torch not installed")
    
    def test_clean_text_ml(self):
        """Test ML model on clean text"""
        text = "Have a wonderful day! Thank you for your assistance."
        result = self.guardrail.detect(text)
        
        assert result["is_toxic"] is False
        assert result["toxicity_score"] < 0.7
    
    def test_toxic_text_ml(self):
        """Test ML model on toxic text"""
        # Mild example for testing
        text = "You are completely useless and worthless"
        result = self.guardrail.detect(text)
        
        # ML model should detect this
        # (exact score depends on model, so we check it's detected)
        assert "toxicity_score" in result
        assert isinstance(result["toxicity_score"], float)
    
    def test_severity_levels(self):
        """Test severity classification"""
        guardrail = self.guardrail
        
        assert guardrail._get_severity(0.95) == "CRITICAL"
        assert guardrail._get_severity(0.8) == "HIGH"
        assert guardrail._get_severity(0.6) == "MEDIUM"
        assert guardrail._get_severity(0.4) == "LOW"
    
    def test_threshold_configuration(self):
        """Test configurable threshold"""
        strict = ToxicityGuardrail(threshold=0.9)
        lenient = ToxicityGuardrail(threshold=0.3)
        
        assert strict.threshold == 0.9
        assert lenient.threshold == 0.3
    
    def test_lazy_loading(self):
        """Test model is lazy loaded"""
        guardrail = ToxicityGuardrail()
        
        # Model should not be loaded yet
        assert guardrail._model is None
        
        # First detect() will load it
        guardrail.detect("test")
        
        # Now model should be loaded
        assert guardrail._model is not None
