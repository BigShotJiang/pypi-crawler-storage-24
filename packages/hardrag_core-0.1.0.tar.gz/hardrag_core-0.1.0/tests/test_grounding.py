"""
Test Grounding Guardrail
"""
import pytest
import dspy
from hardrag.guardrails.grounding import GroundingGuardrail, GroundingCheck


class TestGroundingGuardrail:
    """Tests for DSPy-based grounding guardrail"""
    
    def setup_method(self):
        """Setup test fixtures"""
        # Configure DSPy with a test LM (e.g., OpenAI)
        # In real tests, use mock or local model
        # dspy.settings.configure(lm=...)
        pass
    
    def test_grounded_output(self):
        """Test that well-grounded output passes"""
        guardrail = GroundingGuardrail(threshold=0.8)
        
        sources = [
            "ACME Corporation reported revenue of $10 million in Q4 2023.",
            "The company saw 20% growth year-over-year."
        ]
        
        output = "ACME Corporation's revenue was $10 million in Q4 2023."
        
        # This test requires an actual LLM call
        # For now, we skip it in CI
        pytest.skip("Requires LLM configuration")
        
        result = guardrail(
            retrieved_chunks=sources,
            llm_output=output
        )
        
        assert result["is_grounded"] is True
        assert result["score"] >= 0.8
    
    def test_ungrounded_output(self):
        """Test that ungrounded output fails"""
        guardrail = GroundingGuardrail(threshold=0.8)
        
        sources = [
            "ACME Corporation reported revenue of $10 million in Q4 2023."
        ]
        
        # Output contains unsupported claim
        output = "ACME Corporation's revenue was $50 million in Q4 2023."
        
        pytest.skip("Requires LLM configuration")
        
        result = guardrail(
            retrieved_chunks=sources,
            llm_output=output
        )
        
        assert result["is_grounded"] is False
        assert result["score"] < 0.8
        assert len(result["unsupported_claims"]) > 0
    
    def test_threshold_configuration(self):
        """Test that threshold is configurable"""
        guardrail_strict = GroundingGuardrail(threshold=0.95)
        guardrail_lenient = GroundingGuardrail(threshold=0.5)
        
        assert guardrail_strict.threshold == 0.95
        assert guardrail_lenient.threshold == 0.5
