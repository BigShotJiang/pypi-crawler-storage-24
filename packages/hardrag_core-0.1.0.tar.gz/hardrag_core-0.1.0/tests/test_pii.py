"""
Test PII Guardrail
"""
import pytest
from hardrag.guardrails.pii import PIIGuardrail


class TestPIIGuardrail:
    """Tests for PII detection guardrail"""
    
    def setup_method(self):
        """Setup test fixtures"""
        self.guardrail = PIIGuardrail(threshold=0.7)
    
    def test_email_detection(self):
        """Test email address detection"""
        text = "Contact me at john.doe@example.com for more info"
        result = self.guardrail.detect(text)
        
        assert result["has_pii"] is True
        assert "EMAIL_ADDRESS" in result["pii_types"]
        assert result["total_pii_count"] >= 1
    
    def test_phone_detection(self):
        """Test phone number detection"""
        text = "Call me at (555) 123-4567"
        result = self.guardrail.detect(text)
        
        assert result["has_pii"] is True
        assert "PHONE_NUMBER" in result["pii_types"]
    
    def test_ssn_detection(self):
        """Test SSN detection"""
        text = "My SSN is 123-45-6789"
        result = self.guardrail.detect(text)
        
        assert result["has_pii"] is True
        assert "US_SSN" in result["pii_types"]
    
    def test_credit_card_detection(self):
        """Test credit card detection"""
        text = "My card number is 4532-1234-5678-9010"
        result = self.guardrail.detect(text)
        
        assert result["has_pii"] is True
        assert "CREDIT_CARD" in result["pii_types"]
    
    def test_multiple_pii_types(self):
        """Test detection of multiple PII types"""
        text = "Email: user@test.com, Phone: 555-1234, SSN: 123-45-6789"
        result = self.guardrail.detect(text)
        
        assert result["has_pii"] is True
        assert len(result["pii_types"]) >= 2
        assert result["total_pii_count"] >= 3
    
    def test_no_pii(self):
        """Test text without PII"""
        text = "The company reported revenue of $10 million in Q4."
        result = self.guardrail.detect(text)
        
        assert result["has_pii"] is False
        assert len(result["pii_found"]) == 0
    
    def test_anonymization(self):
        """Test PII anonymization"""
        text = "Contact john@example.com or call 555-1234"
        result = self.guardrail.anonymize(text)
        
        assert result["anonymized_text"] != text
        assert "@" not in result["anonymized_text"] or "<EMAIL_ADDRESS>" in result["anonymized_text"]
        assert len(result["pii_found"]) >= 1
    
    def test_validation_with_pii(self):
        """Test validation fails with PII"""
        text = "My email is sensitive@private.com"
        result = self.guardrail.validate(text, block_if_pii=True)
        
        assert result["is_valid"] is False
        assert len(result["violations"]) > 0
        assert result["violations"][0]["type"] == "PII_DETECTED"
        assert result["anonymized_text"] is not None
    
    def test_validation_without_pii(self):
        """Test validation passes without PII"""
        text = "The revenue was $10 million"
        result = self.guardrail.validate(text, block_if_pii=True)
        
        assert result["is_valid"] is True
        assert len(result["violations"]) == 0
    
    def test_threshold_configuration(self):
        """Test confidence threshold configuration"""
        # High threshold - stricter
        strict_guardrail = PIIGuardrail(threshold=0.9)
        
        # Low threshold - more sensitive
        sensitive_guardrail = PIIGuardrail(threshold=0.3)
        
        assert strict_guardrail.threshold == 0.9
        assert sensitive_guardrail.threshold == 0.3
    
    def test_specific_pii_types(self):
        """Test filtering by specific PII types"""
        # Only detect emails
        email_only = PIIGuardrail(pii_types=["EMAIL_ADDRESS"])
        
        text = "Email: user@test.com, Phone: 555-1234"
        result = email_only.detect(text)
        
        assert result["has_pii"] is True
        assert "EMAIL_ADDRESS" in result["pii_types"]
        # Phone should not be detected (not in pii_types list)
