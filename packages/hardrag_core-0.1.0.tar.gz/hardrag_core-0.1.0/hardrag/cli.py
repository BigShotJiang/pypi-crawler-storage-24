#!/usr/bin/env python3
"""
HardRAG CLI Tool

Command-line interface for validating RAG outputs.
"""
import json
import sys
from typing import Optional
import argparse
from pathlib import Path

from hardrag import HardRAGGuard


def validate_file(
    input_file: str,
    guardrails: list,
    config: Optional[dict] = None,
    output_file: Optional[str] = None,
    strict: bool = False
):
    """Validate RAG outputs from a JSON file"""
    
    # Read input
    with open(input_file, 'r') as f:
        data = json.load(f)
    
    # Initialize guard
    guard = HardRAGGuard(
        guardrails=guardrails,
        config=config or {},
        strict=strict
    )
    
    # Validate
    if isinstance(data, list):
        # Batch validation
        results = guard.validate_batch(
            queries=[item['query'] for item in data],
            retrieved_sources_list=[item['sources'] for item in data],
            llm_outputs=[item['output'] for item in data],
            metadata_list=[item.get('metadata') for item in data]
        )
    else:
        # Single validation
        result = guard.validate(
            query=data['query'],
            retrieved_sources=data['sources'],
            llm_output=data['output'],
            metadata=data.get('metadata')
        )
        results = [result]
    
    # Format output
    output = {
        'total': len(results),
        'valid': sum(1 for r in results if r.is_valid),
        'invalid': sum(1 for r in results if not r.is_valid),
        'results': [
            {
                'is_valid': r.is_valid,
                'violations': r.violations,
                'evaluation_scores': r.evaluation_scores,
                'execution_time_ms': r.execution_time_ms,
                'suggestions': r.suggestions
            }
            for r in results
        ]
    }
    
    # Write or print
    if output_file:
        with open(output_file, 'w') as f:
            json.dump(output, f, indent=2)
        print(f"✓ Results written to {output_file}")
    else:
        print(json.dumps(output, indent=2))
    
    # Return exit code
    return 0 if output['invalid'] == 0 else 1


def validate_text(
    query: str,
    output: str,
    sources: list,
    guardrails: list,
    config: Optional[dict] = None
):
    """Validate a single RAG output from command line args"""
    
    guard = HardRAGGuard(guardrails=guardrails, config=config or {})
    
    result = guard.validate(
        query=query,
        retrieved_sources=sources,
        llm_output=output
    )
    
    # Print results
    print(f"\n{'='*60}")
    print(f"Validation Result: {'✓ VALID' if result.is_valid else '✗ INVALID'}")
    print(f"{'='*60}\n")
    
    if not result.is_valid:
        print(f"Violations ({len(result.violations)}):")
        for i, v in enumerate(result.violations, 1):
            print(f"  {i}. {v['type']}: {v.get('message', 'N/A')}")
        
        if result.suggestions:
            print(f"\nSuggestions:")
            for s in result.suggestions:
                print(f"  • {s}")
    
    print(f"\nEvaluation Scores:")
    for metric, score in result.evaluation_scores.items():
        print(f"  {metric}: {score:.2f}")
    
    print(f"\nExecution Time: {result.execution_time_ms:.2f}ms\n")
    
    return 0 if result.is_valid else 1


def main():
    parser = argparse.ArgumentParser(
        description='HardRAG - Validate RAG outputs with guardrails',
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  # Validate from file
  hardrag validate --input outputs.json --guardrails pii toxicity

  # Validate single output
  hardrag validate --query "What is revenue?" \\
                   --output "Revenue was $10M" \\
                   --sources "Q4 revenue: $10M" \\
                   --guardrails pii

  # Save results to file
  hardrag validate --input outputs.json --output results.json

  # Strict mode (fail fast)
  hardrag validate --input outputs.json --strict
        """
    )
    
    parser.add_argument(
        '--input', '-i',
        help='Input JSON file with RAG outputs'
    )
    parser.add_argument(
        '--output', '-o',
        help='Output file for results (default: stdout)'
    )
    parser.add_argument(
        '--query', '-q',
        help='Single query to validate'
    )
    parser.add_argument(
        '--text', '-t', dest='output_text',
        help='LLM output text to validate'
    )
    parser.add_argument(
        '--sources', '-s',
        nargs='+',
        help='Retrieved source chunks (space-separated)'
    )
    parser.add_argument(
        '--guardrails', '-g',
        nargs='+',
        required=True,
        choices=['pii', 'toxicity', 'grounding'],
        help='Guardrails to enable'
    )
    parser.add_argument(
        '--config', '-c',
        help='JSON config file for guardrails'
    )
    parser.add_argument(
        '--strict',
        action='store_true',
        help='Strict mode: stop on first violation'
    )
    parser.add_argument(
        '--version', '-v',
        action='version',
        version='hardrag-core 0.1.0'
    )
    
    args = parser.parse_args()
    
    # Load config if provided
    config = None
    if args.config:
        with open(args.config, 'r') as f:
            config = json.load(f)
    
    # Validate from file or text
    if args.input:
        exit_code = validate_file(
            input_file=args.input,
            guardrails=args.guardrails,
            config=config,
            output_file=args.output,
            strict=args.strict
        )
    elif args.query and args.output_text:
        if not args.sources:
            print("Error: --sources required when using --query and --output")
            return 1
        
        exit_code = validate_text(
            query=args.query,
            output=args.output_text,
            sources=args.sources,
            guardrails=args.guardrails,
            config=config
        )
    else:
        parser.print_help()
        return 1
    
    return exit_code


if __name__ == '__main__':
    sys.exit(main())
