"""
Core HardRAG Guard Implementation
"""
from typing import List, Dict, Any, Optional, Union
from dataclasses import dataclass, field
from datetime import datetime
import logging
import time

from hardrag.guardrails.pii import PIIGuardrail
from hardrag.guardrails.toxicity import ToxicityGuardrail, SimpleToxicityGuardrail
from hardrag.guardrails.grounding import GroundingGuardrail

logger = logging.getLogger(__name__)


@dataclass
class ValidationResult:
    """Result of a validation check"""
    is_valid: bool
    violations: List[Dict[str, Any]] = field(default_factory=list)
    guardrail_results: Dict[str, Any] = field(default_factory=dict)
    evaluation_scores: Dict[str, float] = field(default_factory=dict)
    audit_trail: Dict[str, Any] = field(default_factory=dict)
    execution_time_ms: float = 0.0
    anonymized_output: Optional[str] = None
    suggestions: List[str] = field(default_factory=list)


class HardRAGGuard:
    """
    Main HardRAG Guard class for validating RAG outputs.
    
    Integrates multiple guardrails:
    - PII detection
    - Toxicity filtering
    - Grounding verification
    - Custom policy enforcement (coming soon)
    
    Example:
        >>> guard = HardRAGGuard(
        ...     guardrails=["pii", "toxicity", "grounding"],
        ...     evaluation_mode="strict"
        ... )
        >>> result = guard.validate(
        ...     query="What is the revenue?",
        ...     retrieved_sources=["Revenue was $10M"],
        ...     llm_output="The revenue was $10M"
        ... )
        >>> print(result.is_valid)
    """
    
    def __init__(
        self,
        guardrails: List[str],
        evaluation_mode: str = "standard",
        config: Optional[Dict[str, Any]] = None,
        strict: bool = False
    ):
        """
        Initialize HardRAG Guard
        
        Args:
            guardrails: List of guardrail names to enable
                       Options: "pii", "toxicity", "grounding"
            evaluation_mode: "strict" (fail on any violation) or 
                           "standard" (collect all violations)
            config: Optional configuration dict for each guardrail
            strict: If True, stop on first violation (fast fail)
        """
        self.guardrails = guardrails
        self.evaluation_mode = evaluation_mode
        self.config = config or {}
        self.strict = strict
        
        # Initialize guardrails
        self._guardrail_instances = {}
        self._init_guardrails()
        
        logger.info(f"HardRAG Guard initialized with guardrails: {guardrails}")
    
    def _init_guardrails(self):
        """Initialize selected guardrails"""
        
        if "pii" in self.guardrails:
            pii_config = self.config.get("pii", {})
            self._guardrail_instances["pii"] = PIIGuardrail(
                threshold=pii_config.get("threshold", 0.7),
                pii_types=pii_config.get("pii_types"),
                allow_list=pii_config.get("allow_list")
            )
            logger.debug("PII guardrail initialized")
        
        if "toxicity" in self.guardrails:
            toxicity_config = self.config.get("toxicity", {})
            use_ml = toxicity_config.get("use_ml", True)
            
            if use_ml:
                try:
                    self._guardrail_instances["toxicity"] = ToxicityGuardrail(
                        threshold=toxicity_config.get("threshold", 0.7),
                        model_name=toxicity_config.get("model_name", "unitary/toxic-bert")
                    )
                    logger.debug("ML-based toxicity guardrail initialized")
                except ImportError:
                    logger.warning("transformers not available, using simple toxicity guardrail")
                    self._guardrail_instances["toxicity"] = SimpleToxicityGuardrail()
            else:
                self._guardrail_instances["toxicity"] = SimpleToxicityGuardrail()
                logger.debug("Rule-based toxicity guardrail initialized")
        
        if "grounding" in self.guardrails:
            grounding_config = self.config.get("grounding", {})
            self._guardrail_instances["grounding"] = GroundingGuardrail(
                threshold=grounding_config.get("threshold", 0.8)
            )
            logger.debug("Grounding guardrail initialized")
    
    def validate(
        self,
        query: str,
        retrieved_sources: List[str],
        llm_output: str,
        metadata: Optional[Dict[str, Any]] = None
    ) -> ValidationResult:
        """
        Validate RAG output against configured guardrails.
        
        Args:
            query: Original user query
            retrieved_sources: Retrieved source chunks
            llm_output: LLM generated output
            metadata: Optional metadata
            
        Returns:
            ValidationResult with validation status and details
        """
        start_time = time.time()
        
        violations = []
        guardrail_results = {}
        evaluation_scores = {}
        suggestions = []
        anonymized_output = llm_output
        
        # Run each guardrail
        for guardrail_name in self.guardrails:
            try:
                if guardrail_name == "pii":
                    result = self._check_pii(llm_output)
                    guardrail_results["pii"] = result
                    
                    if not result["is_valid"]:
                        violations.extend(result["violations"])
                        anonymized_output = result.get("anonymized_text", llm_output)
                        suggestions.append("Remove or anonymize PII in output")
                    
                    evaluation_scores["pii_free"] = 0.0 if result["pii_detected"] else 1.0
                
                elif guardrail_name == "toxicity":
                    result = self._check_toxicity(llm_output)
                    guardrail_results["toxicity"] = result
                    
                    if not result["is_valid"]:
                        violations.extend(result["violations"])
                        suggestions.append("Rephrase to remove toxic content")
                    
                    evaluation_scores["toxicity"] = result.get("toxicity_score", 0.0)
                
                elif guardrail_name == "grounding":
                    result = self._check_grounding(retrieved_sources, llm_output)
                    guardrail_results["grounding"] = result
                    
                    if not result["is_grounded"]:
                        violations.append({
                            "type": "GROUNDING_FAILURE",
                            "severity": "HIGH",
                            "score": result["score"],
                            "unsupported_claims": result.get("unsupported_claims", [])
                        })
                        suggestions.append("Ensure output is supported by retrieved sources")
                    
                    evaluation_scores["grounding"] = result["score"]
                
                # Strict mode: stop on first violation
                if self.strict and len(violations) > 0:
                    logger.debug(f"Strict mode: stopping after {guardrail_name} violation")
                    break
                    
            except Exception as e:
                logger.error(f"Error in {guardrail_name} guardrail: {e}")
                violations.append({
                    "type": "GUARDRAIL_ERROR",
                    "guardrail": guardrail_name,
                    "error": str(e),
                    "severity": "MEDIUM"
                })
        
        # Calculate execution time
        execution_time_ms = (time.time() - start_time) * 1000
        
        # Build audit trail
        audit_trail = {
            "timestamp": datetime.utcnow().isoformat(),
            "query": query,
            "sources_count": len(retrieved_sources),
            "output_length": len(llm_output),
            "guardrails_checked": self.guardrails,
            "metadata": metadata or {},
            "execution_time_ms": execution_time_ms
        }
        
        # Determine overall validity
        is_valid = len(violations) == 0
        
        return ValidationResult(
            is_valid=is_valid,
            violations=violations,
            guardrail_results=guardrail_results,
            evaluation_scores=evaluation_scores,
            audit_trail=audit_trail,
            execution_time_ms=execution_time_ms,
            anonymized_output=anonymized_output if anonymized_output != llm_output else None,
            suggestions=suggestions
        )
    
    def _check_pii(self, text: str) -> Dict[str, Any]:
        """Run PII detection guardrail"""
        pii_guard = self._guardrail_instances["pii"]
        return pii_guard.validate(text, block_if_pii=True)
    
    def _check_toxicity(self, text: str) -> Dict[str, Any]:
        """Run toxicity detection guardrail"""
        toxicity_guard = self._guardrail_instances["toxicity"]
        return toxicity_guard.validate(text, block_if_toxic=True)
    
    def _check_grounding(self, sources: List[str], output: str) -> Dict[str, Any]:
        """Run grounding verification guardrail"""
        grounding_guard = self._guardrail_instances["grounding"]
        return grounding_guard(retrieved_chunks=sources, llm_output=output)
    
    def validate_batch(
        self,
        queries: List[str],
        retrieved_sources_list: List[List[str]],
        llm_outputs: List[str],
        metadata_list: Optional[List[Dict[str, Any]]] = None
    ) -> List[ValidationResult]:
        """
        Validate multiple RAG outputs in batch.
        
        Args:
            queries: List of queries
            retrieved_sources_list: List of retrieved sources (one per query)
            llm_outputs: List of LLM outputs
            metadata_list: Optional list of metadata dicts
            
        Returns:
            List of ValidationResults
        """
        if metadata_list is None:
            metadata_list = [None] * len(queries)
        
        results = []
        for query, sources, output, metadata in zip(
            queries, retrieved_sources_list, llm_outputs, metadata_list
        ):
            result = self.validate(
                query=query,
                retrieved_sources=sources,
                llm_output=output,
                metadata=metadata
            )
            results.append(result)
        
        return results
