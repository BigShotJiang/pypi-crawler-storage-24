"""
PII Detection Guardrail using Microsoft Presidio

Detects and prevents personally identifiable information (PII)
from being exposed in LLM outputs.
"""
from typing import List, Dict, Any, Optional
from presidio_analyzer import AnalyzerEngine
from presidio_anonymizer import AnonymizerEngine


class PIIGuardrail:
    """
    PII detection guardrail using Microsoft Presidio.
    
    Detects common PII types:
    - Email addresses
    - Phone numbers
    - Social Security Numbers (SSN)
    - Credit card numbers
    - Names (PERSON)
    - Locations
    - Dates of birth
    
    Example:
        >>> guardrail = PIIGuardrail(threshold=0.7)
        >>> result = guardrail.detect(
        ...     text="My email is john@example.com and SSN is 123-45-6789"
        ... )
        >>> print(result["has_pii"])  # True
        >>> print(result["pii_types"])  # ["EMAIL_ADDRESS", "US_SSN"]
    """
    
    def __init__(
        self,
        threshold: float = 0.7,
        pii_types: Optional[List[str]] = None,
        allow_list: Optional[List[str]] = None
    ):
        """
        Initialize PII guardrail
        
        Args:
            threshold: Confidence threshold for PII detection (0.0-1.0)
            pii_types: Specific PII types to detect. If None, detects all.
                      Options: EMAIL_ADDRESS, PHONE_NUMBER, US_SSN, 
                              CREDIT_CARD, PERSON, LOCATION, etc.
            allow_list: List of allowed values that should not trigger PII
        """
        self.threshold = threshold
        self.pii_types = pii_types
        self.allow_list = allow_list or []
        
        # Initialize Presidio analyzers
        self.analyzer = AnalyzerEngine()
        self.anonymizer = AnonymizerEngine()
    
    def detect(self, text: str) -> Dict[str, Any]:
        """
        Detect PII in text
        
        Args:
            text: Text to analyze for PII
            
        Returns:
            Dict with:
                - has_pii: bool
                - pii_found: List of detected PII entities
                - pii_types: List of PII types found
                - confidence_scores: Dict of scores per type
        """
        # Analyze text for PII
        results = self.analyzer.analyze(
            text=text,
            entities=self.pii_types,
            language='en',
            score_threshold=self.threshold,
            allow_list=self.allow_list
        )
        
        # Extract PII information
        pii_found = []
        pii_types = set()
        confidence_scores = {}
        
        for result in results:
            pii_item = {
                "type": result.entity_type,
                "start": result.start,
                "end": result.end,
                "text": text[result.start:result.end],
                "score": result.score
            }
            pii_found.append(pii_item)
            pii_types.add(result.entity_type)
            
            # Track highest confidence per type
            if result.entity_type not in confidence_scores:
                confidence_scores[result.entity_type] = result.score
            else:
                confidence_scores[result.entity_type] = max(
                    confidence_scores[result.entity_type],
                    result.score
                )
        
        return {
            "has_pii": len(pii_found) > 0,
            "pii_found": pii_found,
            "pii_types": list(pii_types),
            "confidence_scores": confidence_scores,
            "total_pii_count": len(pii_found)
        }
    
    def anonymize(self, text: str) -> Dict[str, Any]:
        """
        Detect and anonymize PII in text
        
        Args:
            text: Text to anonymize
            
        Returns:
            Dict with:
                - anonymized_text: Text with PII replaced
                - pii_found: List of detected PII
        """
        # Detect PII first
        detection_result = self.detect(text)
        
        if not detection_result["has_pii"]:
            return {
                "anonymized_text": text,
                "pii_found": []
            }
        
        # Analyze for anonymization
        analyzer_results = self.analyzer.analyze(
            text=text,
            entities=self.pii_types,
            language='en',
            score_threshold=self.threshold
        )
        
        # Anonymize
        anonymized_result = self.anonymizer.anonymize(
            text=text,
            analyzer_results=analyzer_results
        )
        
        return {
            "anonymized_text": anonymized_result.text,
            "pii_found": detection_result["pii_found"],
            "pii_types": detection_result["pii_types"]
        }
    
    def validate(
        self,
        text: str,
        block_if_pii: bool = True
    ) -> Dict[str, Any]:
        """
        Validate text against PII policy
        
        Args:
            text: Text to validate
            block_if_pii: If True, fails validation if PII found
            
        Returns:
            Dict with:
                - is_valid: bool
                - violations: List of PII violations
                - anonymized_text: Safe alternative (if PII found)
        """
        detection = self.detect(text)
        
        violations = []
        if detection["has_pii"]:
            for pii in detection["pii_found"]:
                violations.append({
                    "type": "PII_DETECTED",
                    "pii_type": pii["type"],
                    "location": f"chars {pii['start']}-{pii['end']}",
                    "confidence": pii["score"],
                    "severity": "HIGH"
                })
        
        # Get anonymized version
        anonymized = self.anonymize(text) if detection["has_pii"] else None
        
        is_valid = not (block_if_pii and detection["has_pii"])
        
        return {
            "is_valid": is_valid,
            "violations": violations,
            "pii_detected": detection["has_pii"],
            "pii_types": detection["pii_types"],
            "anonymized_text": anonymized["anonymized_text"] if anonymized else text,
            "suggestion": "Remove or anonymize PII before output" if not is_valid else None
        }
