"""
Toxicity Detection Guardrail

Detects and blocks harmful, toxic, or inappropriate content
in LLM outputs using transformer-based classification.
"""
from typing import Dict, Any, Optional, List
import warnings

# Suppress tokenizers warnings
warnings.filterwarnings('ignore', category=FutureWarning)


class ToxicityGuardrail:
    """
    Toxicity detection guardrail using transformer models.
    
    Detects:
    - Toxic language
    - Severe toxicity
    - Obscene content
    - Threats
    - Insults
    - Identity hate
    
    Uses lightweight models for fast inference.
    
    Example:
        >>> guardrail = ToxicityGuardrail(threshold=0.7)
        >>> result = guardrail.detect("This is a normal message")
        >>> print(result["is_toxic"])  # False
    """
    
    def __init__(
        self,
        threshold: float = 0.7,
        model_name: str = "unitary/toxic-bert",
        categories: Optional[List[str]] = None
    ):
        """
        Initialize toxicity guardrail
        
        Args:
            threshold: Toxicity score threshold (0.0-1.0)
            model_name: HuggingFace model to use
                       Options:
                       - "unitary/toxic-bert" (default, fast)
                       - "martin-ha/toxic-comment-model"  
                       - "s-nlp/roberta_toxicity_classifier"
            categories: Specific toxicity categories to check
                       None = check all categories
        """
        self.threshold = threshold
        self.model_name = model_name
        self.categories = categories or [
            "toxicity",
            "severe_toxicity",
            "obscene",
            "threat",
            "insult",
            "identity_attack"
        ]
        
        # Lazy load model (only when first used)
        self._model = None
        self._tokenizer = None
    
    def _load_model(self):
        """Lazy load the toxicity detection model"""
        if self._model is not None:
            return
        
        try:
            from transformers import AutoTokenizer, AutoModelForSequenceClassification
            import torch
            
            self._tokenizer = AutoTokenizer.from_pretrained(self.model_name)
            self._model = AutoModelForSequenceClassification.from_pretrained(
                self.model_name
            )
            self._model.eval()  # Set to evaluation mode
            
        except ImportError:
            raise ImportError(
                "transformers and torch required for toxicity detection. "
                "Install with: pip install transformers torch"
            )
    
    def detect(self, text: str) -> Dict[str, Any]:
        """
        Detect toxicity in text
        
        Args:
            text: Text to analyze
            
        Returns:
            Dict with:
                - is_toxic: bool
                - toxicity_score: float (0.0-1.0)
                - category_scores: Dict of scores per category
                - categories_detected: List of categories above threshold
        """
        import torch
        
        # Load model if not loaded
        self._load_model()
        
        # Tokenize
        inputs = self._tokenizer(
            text,
            return_tensors="pt",
            truncation=True,
            max_length=512,
            padding=True
        )
        
        # Run inference
        with torch.no_grad():
            outputs = self._model(**inputs)
            predictions = torch.sigmoid(outputs.logits)[0]
        
        # Get scores
        category_scores = {}
        categories_detected = []
        
        # Map predictions to categories
        # Note: This mapping depends on the specific model used
        # For toxic-bert: [toxic, severe_toxic, obscene, threat, insult, identity_hate]
        for idx, category in enumerate(self.categories[:len(predictions)]):
            score = predictions[idx].item()
            category_scores[category] = score
            
            if score >= self.threshold:
                categories_detected.append(category)
        
        # Overall toxicity score (max of all categories)
        max_score = max(category_scores.values()) if category_scores else 0.0
        is_toxic = max_score >= self.threshold
        
        return {
            "is_toxic": is_toxic,
            "toxicity_score": max_score,
            "category_scores": category_scores,
            "categories_detected": categories_detected,
            "threshold": self.threshold
        }
    
    def validate(
        self,
        text: str,
        block_if_toxic: bool = True
    ) -> Dict[str, Any]:
        """
        Validate text against toxicity policy
        
        Args:
            text: Text to validate
            block_if_toxic: If True, fails validation if toxic
            
        Returns:
            Dict with:
                - is_valid: bool
                - violations: List of toxicity violations
                - toxicity_score: float
        """
        detection = self.detect(text)
        
        violations = []
        if detection["is_toxic"]:
            for category in detection["categories_detected"]:
                score = detection["category_scores"][category]
                violations.append({
                    "type": "TOXICITY_DETECTED",
                    "category": category,
                    "score": score,
                    "severity": self._get_severity(score),
                    "message": f"{category} content detected (score: {score:.2f})"
                })
        
        is_valid = not (block_if_toxic and detection["is_toxic"])
        
        return {
            "is_valid": is_valid,
            "violations": violations,
            "toxicity_detected": detection["is_toxic"],
            "toxicity_score": detection["toxicity_score"],
            "categories": detection["categories_detected"],
            "suggestion": "Rephrase to remove toxic content" if not is_valid else None
        }
    
    def _get_severity(self, score: float) -> str:
        """Determine severity level based on score"""
        if score >= 0.9:
            return "CRITICAL"
        elif score >= 0.75:
            return "HIGH"
        elif score >= 0.5:
            return "MEDIUM"
        else:
            return "LOW"


# Simple rule-based toxicity detector (fallback, no ML)
class SimpleToxicityGuardrail:
    """
    Simple rule-based toxicity detector (no ML models required).
    Uses keyword matching - fast but less accurate than ML models.
    
    Good for:
    - Development/testing without heavy dependencies
    - Fast screening before ML model
    - Edge cases where ML model unavailable
    """
    
    def __init__(self, threshold: float = 0.5):
        """
        Initialize simple toxicity guardrail
        
        Args:
            threshold: Not used in rule-based, but kept for API compatibility
        """
        self.threshold = threshold
        
        # Basic toxic keywords (very simplified, real lists are much larger)
        self.toxic_keywords = {
            "hate_speech": ["hate", "racist", "sexist"],
            "profanity": ["damn", "hell"],  # Add more as needed
            "insults": ["stupid", "idiot", "dumb"],
            "threats": ["kill", "destroy", "threat"]
        }
    
    def detect(self, text: str) -> Dict[str, Any]:
        """Simple keyword-based detection"""
        text_lower = text.lower()
        
        detected_categories = []
        category_scores = {}
        
        for category, keywords in self.toxic_keywords.items():
            # Count keyword matches
            matches = sum(1 for kw in keywords if kw in text_lower)
            score = min(matches * 0.3, 1.0)  # Simple scoring
            category_scores[category] = score
            
            if score > 0:
                detected_categories.append(category)
        
        max_score = max(category_scores.values()) if category_scores else 0.0
        
        return {
            "is_toxic": max_score > 0,
            "toxicity_score": max_score,
            "category_scores": category_scores,
            "categories_detected": detected_categories,
            "method": "rule-based"
        }
    
    def validate(self, text: str, block_if_toxic: bool = True) -> Dict[str, Any]:
        """Validate using simple rules"""
        detection = self.detect(text)
        
        violations = []
        if detection["is_toxic"]:
            for category in detection["categories_detected"]:
                violations.append({
                    "type": "TOXICITY_DETECTED",
                    "category": category,
                    "method": "keyword_matching"
                })
        
        return {
            "is_valid": not (block_if_toxic and detection["is_toxic"]),
            "violations": violations,
            "toxicity_detected": detection["is_toxic"]
        }
