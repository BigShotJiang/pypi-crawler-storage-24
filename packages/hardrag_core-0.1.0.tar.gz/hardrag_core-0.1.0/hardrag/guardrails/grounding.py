"""
DSPy-based Grounding Check Guardrail

Verifies that LLM outputs are grounded in retrieved sources.
"""
import dspy
from typing import List, Dict, Any


class GroundingCheck(dspy.Signature):
    """
    Verify if LLM output is grounded in retrieved sources.
    
    This signature checks each claim in the output and determines
    if it's supported by the provided source chunks.
    """
    
    retrieved_chunks = dspy.InputField(
        desc="List of retrieved source text chunks"
    )
    llm_output = dspy.InputField(
        desc="LLM generated output to verify"
    )
    grounding_score = dspy.OutputField(
        desc="Score from 0.0 to 1.0 indicating how well grounded the output is"
    )
    unsupported_claims = dspy.OutputField(
        desc="List of claims in output that are not supported by sources"
    )
    supported_claims = dspy.OutputField(
        desc="List of claims that are properly supported"
    )


class GroundingGuardrail(dspy.Module):
    """
    DSPy-based guardrail for checking if outputs are grounded in sources.
    
    Example:
        >>> guardrail = GroundingGuardrail()
        >>> result = guardrail(
        ...     retrieved_chunks=["Source text..."],
        ...     llm_output="Generated claim..."
        ... )
        >>> print(result.grounding_score)
    """
    
    def __init__(self, threshold: float = 0.8):
        """
        Initialize grounding guardrail
        
        Args:
            threshold: Minimum grounding score to pass (0.0-1.0)
        """
        super().__init__()
        self.threshold = threshold
        self.grounding_check = dspy.ChainOfThought(GroundingCheck)
    
    def forward(
        self,
        retrieved_chunks: List[str],
        llm_output: str
    ) -> Dict[str, Any]:
        """
        Check if output is grounded in sources
        
        Args:
            retrieved_chunks: Retrieved source texts
            llm_output: LLM generated output
            
        Returns:
            Dict with is_grounded, score, and details
        """
        # Format chunks for DSPy
        chunks_text = "\n\n".join([
            f"Source {i+1}: {chunk}"
            for i, chunk in enumerate(retrieved_chunks)
        ])
        
        # Run DSPy grounding check
        result = self.grounding_check(
            retrieved_chunks=chunks_text,
            llm_output=llm_output
        )
        
        # Parse score (DSPy might return string)
        try:
            score = float(result.grounding_score)
        except (ValueError, TypeError):
            score = 0.0
        
        is_grounded = score >= self.threshold
        
        return {
            "is_grounded": is_grounded,
            "score": score,
            "threshold": self.threshold,
            "unsupported_claims": result.unsupported_claims,
            "supported_claims": result.supported_claims,
        }
