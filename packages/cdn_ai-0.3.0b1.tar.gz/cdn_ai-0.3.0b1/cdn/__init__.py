"""cdn-ai: Condensa — hyper-efficient AI-to-AI communication language.

Three editions:
  còndensa (!:cdn) — performance: max compression, max interpretability
  cóndensa (~:cdn) — expressive: tone marks for agent negotiation
  cōndensa (@:cdn) — secure: classification, encryption, audit

Quick usage:
    from cdn import encode, decode, encode_with_stats

    # Natural language to Condensa
    cdn_msg = encode("Search the web for SpaceX news, top 5 results")
    # Output: !:srch SpaceX /n:5

    # Condensa to natural language
    nl_msg = decode("!:srch 'SpaceX' /n:5 | sumz /fmt:bullets")
    # Output: Pipeline: Search SpaceX. Limit to 5 results. → Summarize. Format as bullets.

    # With compression stats
    stats = encode_with_stats("Search for SpaceX news and summarize")
    print(f"Saved {stats['reduction_pct']}% tokens")
"""

__version__ = "0.3.0b1"
__all__ = [
    "encode",
    "decode",
    "encode_with_stats",
    "decode_with_stats",
    "count_tokens",
    "tokenize",
    "validate",
    "CondensaEncoder",
    "CondensaDecoder",
]

from .encoder import encode, encode_with_stats, CondensaEncoder
from .decoder import decode, decode_with_stats, CondensaDecoder
from .utils import count_tokens, tokenize
