# wake command directory
