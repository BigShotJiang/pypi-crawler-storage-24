# start command directory
