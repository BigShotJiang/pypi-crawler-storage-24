import os

# Single source of truth lives in config.py.
# Import from there — never duplicate the registry.
from .config import MODULE_DEFAULTS, DEFAULT_PATHS, ModelConfig, get_model_path, get_model_id  # noqa: F401

REMOVE_PHRASES = ['Video Converter', 'eeso', 'Auseesott', 'Aeseesott', 'esoft']
