import pytest

from tigrbl import TigrblApp
from tigrbl.security import HTTPBearer
from tigrbl.op import OpSpec
from tigrbl.orm.tables import Base
from tigrbl.orm.mixins import GUIDPk
from tigrbl.bindings.rest.router import _build_router


from tigrbl.router import Router
from tigrbl.security import Security


pytestmark = pytest.mark.xfail(
    reason="Router does not support include_router(...)",
    strict=False,
)


class Widget(Base, GUIDPk):
    __tablename__ = "widgets_security"
    __tigrbl_auth_dep__ = staticmethod(lambda cred=Security(HTTPBearer()): cred)
    __tigrbl_allow_anon__ = ["list"]


def test_security_applied_per_route():
    child_router = _build_router(
        Widget,
        [OpSpec(alias="list", target="list"), OpSpec(alias="read", target="read")],
    )
    router = Router()
    router.include_router(child_router)
    schema = router.openapi()
    paths = {route.name: route.path_template for route in child_router.routes}
    list_sec = schema["paths"][paths["Widget.list"]]["get"].get("security")
    read_sec = schema["paths"][paths["Widget.read"]]["get"].get("security")
    assert not list_sec
    assert read_sec == [{"HTTPBearer": []}]
    assert "HTTPBearer" in schema["components"]["securitySchemes"]


def test_set_auth_after_include_model_applies_security():
    class Gadget(Base, GUIDPk):
        __tablename__ = "gadgets_security"

    app = TigrblApp()
    app.include_table(Gadget)
    app.set_auth(authn=lambda cred=Security(HTTPBearer()): cred, allow_anon=False)
    router = Router()
    router.include_router(app.router)
    spec = router.openapi()
    post_sec = spec["paths"]["/gadget"]["post"].get("security")
    assert post_sec == [{"HTTPBearer": []}]
