from pathlib import Path

from setuptools import find_packages, setup


README = Path(__file__).with_name("README.md").read_text(encoding="utf-8")


setup(
    name="qianwen",
    version="0.1.0",
    description="Open a URL in the default browser from the command line.",
    long_description=README,
    long_description_content_type="text/markdown",
    author="Codex",
    python_requires=">=3.8",
    package_dir={"": "src"},
    packages=find_packages(where="src"),
    include_package_data=True,
    scripts=["scripts/r.cmd"],
)