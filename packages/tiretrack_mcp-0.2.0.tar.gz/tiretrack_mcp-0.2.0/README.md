# tiretrack-mcp

MCP server for [TireTrack](https://tiretrack.mi.tirerack.com) project management. Manage projects, issues, sprints, and teams from any AI assistant that supports the [Model Context Protocol](https://modelcontextprotocol.io).

## Tools

| Category | Tools |
|----------|-------|
| Projects | `list_projects`, `get_project`, `create_project` |
| Members | `list_project_members`, `add_project_member` |
| Issues | `list_issues`, `get_issue`, `get_issue_by_key`, `create_issue`, `update_issue` |
| Comments | `list_comments`, `add_comment` |
| Sprints | `list_sprints`, `get_sprint_metrics` |
| Search | `search_issues` |
| Users | `list_users`, `get_current_user` |

## Quick Start

### Using uvx (recommended)

```bash
uvx tiretrack-mcp
```

### Using pip

```bash
pip install tiretrack-mcp
tiretrack-mcp
```

## Configuration

Set these environment variables:

| Variable | Required | Description |
|----------|----------|-------------|
| `TIRETRACK_API_URL` | Yes | API base URL (e.g., `https://tiretrack.mi.tirerack.com/api`) |
| `TIRETRACK_EMAIL` | Yes | Your TireTrack account email |
| `TIRETRACK_PASSWORD` | Yes | Your TireTrack account password |

### Claude Code / Claude Desktop

**Stable (production):**

```json
{
  "mcpServers": {
    "tiretrack": {
      "command": "uvx",
      "args": ["--refresh", "tiretrack-mcp"],
      "env": {
        "TIRETRACK_API_URL": "https://tiretrack.mi.tirerack.com",
        "TIRETRACK_EMAIL": "${TIRETRACK_EMAIL}",
        "TIRETRACK_PASSWORD": "${TIRETRACK_PASSWORD}"
      }
    }
  }
}
```

**Dev (pre-release):**

```json
{
  "mcpServers": {
    "tiretrack": {
      "command": "uvx",
      "args": ["--refresh", "--prerelease", "allow", "tiretrack-mcp"],
      "env": {
        "TIRETRACK_API_URL": "https://dev.tiretrack.mi.tirerack.com",
        "TIRETRACK_EMAIL": "${TIRETRACK_EMAIL}",
        "TIRETRACK_PASSWORD": "${TIRETRACK_PASSWORD}"
      }
    }
  }
}
```

> `--refresh` checks PyPI for newer versions on each invocation. `--prerelease allow` installs `.dev` pre-release versions.

### OpenAI Codex CLI

**Stable (production):**

```toml
# .codex/config.toml
[mcp_servers.tiretrack]
command = "uvx"
args = ["--refresh", "tiretrack-mcp"]

[mcp_servers.tiretrack.env]
TIRETRACK_API_URL = "https://tiretrack.mi.tirerack.com"
TIRETRACK_EMAIL = "${TIRETRACK_EMAIL}"
TIRETRACK_PASSWORD = "${TIRETRACK_PASSWORD}"
```

**Dev (pre-release):**

```toml
# .codex/config.toml
[mcp_servers.tiretrack]
command = "uvx"
args = ["--refresh", "--prerelease", "allow", "tiretrack-mcp"]

[mcp_servers.tiretrack.env]
TIRETRACK_API_URL = "https://dev.tiretrack.mi.tirerack.com"
TIRETRACK_EMAIL = "${TIRETRACK_EMAIL}"
TIRETRACK_PASSWORD = "${TIRETRACK_PASSWORD}"
```

### Gemini CLI

**Stable (production):**

```json
{
  "mcpServers": {
    "tiretrack": {
      "command": "uvx",
      "args": ["--refresh", "tiretrack-mcp"],
      "env": {
        "TIRETRACK_API_URL": "https://tiretrack.mi.tirerack.com",
        "TIRETRACK_EMAIL": "${TIRETRACK_EMAIL}",
        "TIRETRACK_PASSWORD": "${TIRETRACK_PASSWORD}"
      }
    }
  }
}
```

**Dev (pre-release):**

```json
{
  "mcpServers": {
    "tiretrack": {
      "command": "uvx",
      "args": ["--refresh", "--prerelease", "allow", "tiretrack-mcp"],
      "env": {
        "TIRETRACK_API_URL": "https://dev.tiretrack.mi.tirerack.com",
        "TIRETRACK_EMAIL": "${TIRETRACK_EMAIL}",
        "TIRETRACK_PASSWORD": "${TIRETRACK_PASSWORD}"
      }
    }
  }
}
```

## Transports

| Transport | Command | Use case |
|-----------|---------|----------|
| stdio (default) | `tiretrack-mcp` | Claude Code, Codex, Gemini CLI, Claude Desktop |
| Streamable HTTP | `tiretrack-mcp --transport streamable-http --port 8080` | ChatGPT, remote clients |
| SSE (legacy) | `tiretrack-mcp --transport sse --port 8080` | Older clients |

## Development

```bash
cd mcp-server
uv sync
uv run tiretrack-mcp --help
```
