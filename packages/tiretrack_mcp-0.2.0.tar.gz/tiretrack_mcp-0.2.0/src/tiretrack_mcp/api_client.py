"""HTTP client for the TireTrack REST API with automatic token management."""

import json
import os
import time

import httpx

API_BASE_URL = os.environ.get("TIRETRACK_API_URL", "https://tiretrack.mi.tirerack.com")
EMAIL = os.environ.get("TIRETRACK_EMAIL", "")
PASSWORD = os.environ.get("TIRETRACK_PASSWORD", "")

# Module-level token state
_access_token: str | None = None
_refresh_token: str | None = None
_token_expires_at: float = 0


async def _login() -> None:
    """Authenticate and store tokens."""
    global _access_token, _refresh_token, _token_expires_at

    if not EMAIL or not PASSWORD:
        raise RuntimeError(
            "TIRETRACK_EMAIL and TIRETRACK_PASSWORD environment variables are required"
        )

    async with httpx.AsyncClient(base_url=API_BASE_URL, timeout=30.0) as client:
        resp = await client.post(
            "/api/v1/auth/login/json",
            json={"email": EMAIL, "password": PASSWORD},
        )
        resp.raise_for_status()
        data = resp.json()

    _access_token = data["access_token"]
    _refresh_token = data["refresh_token"]
    # Assume 25 minutes to be safe (server default is 30)
    _token_expires_at = time.time() + 25 * 60


async def _refresh() -> None:
    """Refresh the access token."""
    global _access_token, _refresh_token, _token_expires_at

    if not _refresh_token:
        return await _login()

    async with httpx.AsyncClient(base_url=API_BASE_URL, timeout=30.0) as client:
        resp = await client.post(
            "/api/v1/auth/refresh",
            json={"refresh_token": _refresh_token},
        )
        if resp.status_code != 200:
            # Refresh token expired, do full login
            return await _login()
        data = resp.json()

    _access_token = data["access_token"]
    _refresh_token = data["refresh_token"]
    _token_expires_at = time.time() + 25 * 60


async def _ensure_token() -> str:
    """Get a valid access token, logging in or refreshing as needed."""
    if _access_token and time.time() < _token_expires_at:
        return _access_token
    if _refresh_token:
        await _refresh()
    else:
        await _login()
    return _access_token  # type: ignore[return-value]


async def api_request(
    method: str,
    path: str,
    *,
    params: dict | None = None,
    json_body: dict | None = None,
) -> dict | list:
    """Make an authenticated API request with automatic token refresh.

    Returns the parsed JSON response.
    """
    token = await _ensure_token()

    async with httpx.AsyncClient(base_url=API_BASE_URL, timeout=30.0) as client:
        resp = await client.request(
            method,
            path,
            params=params,
            json=json_body,
            headers={"Authorization": f"Bearer {token}"},
        )

        # If 401, try refreshing once and retry
        if resp.status_code == 401:
            await _refresh()
            token = _access_token
            resp = await client.request(
                method,
                path,
                params=params,
                json=json_body,
                headers={"Authorization": f"Bearer {token}"},
            )

        if resp.status_code >= 400:
            # Include the response body so callers see the server's error detail
            try:
                body = resp.json()
                detail = body.get("detail", resp.text)
            except Exception:
                detail = resp.text
            raise httpx.HTTPStatusError(
                f"{resp.status_code}: {detail}",
                request=resp.request,
                response=resp,
            )

        if resp.status_code == 204:
            return {"status": "success"}

        return resp.json()


def format_response(data: dict | list) -> str:
    """Format API response as readable JSON."""
    return json.dumps(data, indent=2, default=str)
