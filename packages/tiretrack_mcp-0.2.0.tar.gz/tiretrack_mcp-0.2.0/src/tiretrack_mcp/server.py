"""TireTrack MCP Server — tools for AI-powered project management."""

import mimetypes
from pathlib import Path
from typing import Literal

import httpx
from mcp.server.fastmcp import FastMCP

from .api_client import api_request, format_response

ALLOWED_IMAGE_MIME_TYPES = {"image/png", "image/jpeg", "image/gif", "image/webp"}


def _normalize_text(value: str) -> str:
    """Convert literal escape sequences (\\n, \\t) to real characters.

    LLMs often emit the two-character sequence ``\\n`` instead of an actual
    newline when calling MCP tools.  This helper ensures markdown descriptions
    and comments are stored with proper whitespace so they render correctly in
    the UI.
    """
    return value.replace("\\n", "\n").replace("\\t", "\t")


mcp = FastMCP(
    "TireTrack",
    instructions=(
        "TireTrack is a project management tool (like Jira). "
        "Use these tools to manage projects, issues, sprints, and team members. "
        "Issue keys look like PROJ-123. Statuses flow: backlog → todo → in_progress → dev_testing → done."
    ),
)

# ---------------------------------------------------------------------------
# Projects
# ---------------------------------------------------------------------------


@mcp.tool()
async def list_projects(include_archived: bool = False) -> str:
    """List all projects the current user has access to.

    Returns project name, key, type (kanban/scrum), issue count, and archive status.

    Args:
        include_archived: Include archived projects in the results.
    """
    params = {}
    if include_archived:
        params["include_archived"] = "true"
    data = await api_request("GET", "/api/v1/projects/", params=params)
    return format_response(data)


@mcp.tool()
async def get_project(project_id: str) -> str:
    """Get detailed information about a specific project.

    Args:
        project_id: The project UUID.
    """
    data = await api_request("GET", f"/api/v1/projects/{project_id}")
    return format_response(data)


@mcp.tool()
async def create_project(
    name: str,
    key: str,
    description: str | None = None,
    project_type: Literal["kanban", "scrum"] = "kanban",
) -> str:
    """Create a new project. A default board with columns is created automatically.

    Args:
        name: Project display name (1-255 characters).
        key: Unique project key, 2-10 uppercase letters/numbers starting with a letter (e.g., 'TT', 'PROJ').
        description: Optional project description.
        project_type: Project methodology — 'kanban' or 'scrum'.
    """
    body: dict = {
        "name": name,
        "key": key.upper(),
        "project_type": project_type,
    }
    if description is not None:
        body["description"] = _normalize_text(description)
    data = await api_request("POST", "/api/v1/projects/", json_body=body)
    return format_response(data)


# ---------------------------------------------------------------------------
# Project Members
# ---------------------------------------------------------------------------


@mcp.tool()
async def list_project_members(project_id: str) -> str:
    """List all members of a project with their roles.

    Args:
        project_id: The project UUID.
    """
    data = await api_request("GET", f"/api/v1/projects/{project_id}/members")
    return format_response(data)


@mcp.tool()
async def add_project_member(
    project_id: str,
    user_id: str,
    role: Literal["admin", "member", "viewer"] = "member",
) -> str:
    """Add a user to a project. Requires admin role on the project.

    Args:
        project_id: The project UUID.
        user_id: The user UUID to add.
        role: Role to assign — 'admin', 'member', or 'viewer'.
    """
    data = await api_request(
        "POST",
        f"/api/v1/projects/{project_id}/members",
        json_body={"user_id": user_id, "role": role},
    )
    return format_response(data)


# ---------------------------------------------------------------------------
# Issues
# ---------------------------------------------------------------------------


@mcp.tool()
async def list_issues(
    project_id: str,
    status: Literal[
        "backlog",
        "new",
        "todo",
        "in_progress",
        "dev_testing",
        "qa_testing",
        "done",
        "cancelled",
    ]
    | None = None,
    assignee_id: str | None = None,
    issue_type: Literal["epic", "story", "task", "bug", "subtask"] | None = None,
    priority: Literal["highest", "high", "medium", "low", "lowest"] | None = None,
    sprint_id: str | None = None,
    search: str | None = None,
    page: int = 1,
    page_size: int = 25,
) -> str:
    """List issues in a project with optional filtering.

    Returns paginated results with issue key, title, status, assignee, priority, and type.

    Args:
        project_id: The project UUID (required).
        status: Filter by status.
        assignee_id: Filter by assignee user UUID.
        issue_type: Filter by issue type.
        priority: Filter by priority level.
        sprint_id: Filter by sprint UUID.
        search: Text search across issue titles and descriptions.
        page: Page number (default 1).
        page_size: Results per page (default 25, max 100).
    """
    params: dict = {"project_id": project_id, "page": page, "page_size": page_size}
    if status:
        params["status"] = status
    if assignee_id:
        params["assignee_id"] = assignee_id
    if issue_type:
        params["issue_type"] = issue_type
    if priority:
        params["priority"] = priority
    if sprint_id:
        params["sprint_id"] = sprint_id
    if search:
        params["search"] = search
    data = await api_request("GET", "/api/v1/issues/", params=params)
    return format_response(data)


@mcp.tool()
async def get_issue(issue_id: str) -> str:
    """Get full details of an issue by its UUID.

    Args:
        issue_id: The issue UUID.
    """
    data = await api_request("GET", f"/api/v1/issues/{issue_id}")
    return format_response(data)


@mcp.tool()
async def get_issue_by_key(issue_key: str) -> str:
    """Get full details of an issue by its key (e.g., 'PROJ-123').

    Args:
        issue_key: The issue key like 'TT-1' or 'PROJ-42'.
    """
    data = await api_request("GET", f"/api/v1/issues/key/{issue_key}")
    return format_response(data)


@mcp.tool()
async def create_issue(
    project_id: str,
    title: str,
    issue_type: Literal["epic", "story", "task", "bug", "subtask"] = "task",
    priority: Literal["highest", "high", "medium", "low", "lowest"] = "medium",
    status: Literal[
        "backlog",
        "new",
        "todo",
        "in_progress",
        "dev_testing",
        "qa_testing",
        "done",
        "cancelled",
    ] = "todo",
    description: str | None = None,
    assignee_id: str | None = None,
    sprint_id: str | None = None,
    story_points: int | None = None,
    parent_id: str | None = None,
    epic_id: str | None = None,
) -> str:
    """Create a new issue in a project.

    The issue key (e.g., 'PROJ-1') is auto-generated from the project key.

    Args:
        project_id: The project UUID.
        title: Issue title (1-500 characters).
        issue_type: Type of issue.
        priority: Priority level.
        status: Initial status (default 'todo').
        description: Detailed description (supports markdown).
        assignee_id: UUID of the user to assign.
        sprint_id: UUID of the sprint to add this issue to.
        story_points: Estimated effort (0-100).
        parent_id: UUID of parent issue (for subtasks).
        epic_id: UUID of the epic this issue belongs to.
    """
    body: dict = {
        "project_id": project_id,
        "title": title,
        "issue_type": issue_type,
        "priority": priority,
        "status": status,
    }
    if description is not None:
        body["description"] = _normalize_text(description)
    if assignee_id is not None:
        body["assignee_id"] = assignee_id
    if sprint_id is not None:
        body["sprint_id"] = sprint_id
    if story_points is not None:
        body["story_points"] = story_points
    if parent_id is not None:
        body["parent_id"] = parent_id
    if epic_id is not None:
        body["epic_id"] = epic_id
    data = await api_request("POST", "/api/v1/issues/", json_body=body)
    return format_response(data)


@mcp.tool()
async def update_issue(
    issue_id: str,
    title: str | None = None,
    status: Literal[
        "backlog",
        "new",
        "todo",
        "in_progress",
        "dev_testing",
        "qa_testing",
        "done",
        "cancelled",
    ]
    | None = None,
    priority: Literal["highest", "high", "medium", "low", "lowest"] | None = None,
    issue_type: Literal["epic", "story", "task", "bug", "subtask"] | None = None,
    description: str | None = None,
    assignee_id: str | None = None,
    sprint_id: str | None = None,
    story_points: int | None = None,
    is_flagged: bool | None = None,
    flag_reason: str | None = None,
) -> str:
    """Update an existing issue. Only provide fields you want to change.

    Args:
        issue_id: The issue UUID.
        title: New title.
        status: New status.
        priority: New priority.
        issue_type: New issue type.
        description: New description.
        assignee_id: New assignee UUID (or empty string to unassign).
        sprint_id: New sprint UUID (or empty string to remove from sprint).
        story_points: New story point estimate.
        is_flagged: Flag or unflag the issue.
        flag_reason: Reason for flagging.
    """
    body: dict = {}
    if title is not None:
        body["title"] = title
    if status is not None:
        body["status"] = status
    if priority is not None:
        body["priority"] = priority
    if issue_type is not None:
        body["issue_type"] = issue_type
    if description is not None:
        body["description"] = _normalize_text(description)
    if assignee_id is not None:
        body["assignee_id"] = assignee_id or None
    if sprint_id is not None:
        body["sprint_id"] = sprint_id or None
    if story_points is not None:
        body["story_points"] = story_points
    if is_flagged is not None:
        body["is_flagged"] = is_flagged
    if flag_reason is not None:
        body["flag_reason"] = flag_reason
    data = await api_request("PATCH", f"/api/v1/issues/{issue_id}", json_body=body)
    return format_response(data)


# ---------------------------------------------------------------------------
# Comments
# ---------------------------------------------------------------------------


@mcp.tool()
async def list_comments(issue_id: str) -> str:
    """List all comments on an issue.

    Args:
        issue_id: The issue UUID.
    """
    data = await api_request("GET", f"/api/v1/issues/{issue_id}/comments")
    return format_response(data)


@mcp.tool()
async def add_comment(issue_id: str, content: str) -> str:
    """Add a comment to an issue.

    Args:
        issue_id: The issue UUID.
        content: Comment text (supports markdown).
    """
    data = await api_request(
        "POST",
        f"/api/v1/issues/{issue_id}/comments",
        json_body={"content": _normalize_text(content)},
    )
    return format_response(data)


# ---------------------------------------------------------------------------
# Attachments
# ---------------------------------------------------------------------------


@mcp.tool()
async def add_attachment(
    issue_id: str,
    file_path: str,
    filename: str | None = None,
    mime_type: str | None = None,
) -> str:
    """Upload a local image file and attach it to an issue.

    Supports PNG, JPEG, GIF, and WebP images.

    Args:
        issue_id: The issue UUID.
        file_path: Absolute path to the image file on disk (e.g., '/tmp/screenshot.png').
        filename: Optional display name for the attachment. Defaults to the file's basename.
        mime_type: Optional MIME type. Inferred from the file extension if not provided.
    """
    path = Path(file_path).expanduser().resolve()
    if not path.is_file():
        return f"Error: file not found: {path}"

    raw_bytes = path.read_bytes()
    if filename is None:
        filename = path.name

    if mime_type is None:
        mime_type = mimetypes.guess_type(path.name)[0]
    if mime_type not in ALLOWED_IMAGE_MIME_TYPES:
        return (
            f"Error: unsupported MIME type '{mime_type}'. "
            f"Allowed: {', '.join(sorted(ALLOWED_IMAGE_MIME_TYPES))}"
        )

    # 1. Get a presigned upload URL from the backend
    presigned = await api_request(
        "POST",
        "/api/v1/uploads/presigned-url",
        json_body={"content_type": mime_type, "filename": filename},
    )
    upload_url: str = presigned["upload_url"]  # type: ignore[index]
    object_url: str = presigned["object_url"]  # type: ignore[index]

    # 2. PUT the raw bytes directly to S3 (presigned URL contains auth)
    async with httpx.AsyncClient(timeout=60.0) as client:
        put_resp = await client.put(
            upload_url,
            content=raw_bytes,
            headers={"Content-Type": mime_type},
        )
        put_resp.raise_for_status()

    # 3. Create the attachment record on the issue
    data = await api_request(
        "POST",
        f"/api/v1/issues/{issue_id}/attachments",
        json_body={
            "filename": filename,
            "file_url": object_url,
            "file_size": len(raw_bytes),
            "mime_type": mime_type,
        },
    )
    return format_response(data)


@mcp.tool()
async def list_attachments(issue_id: str) -> str:
    """List all attachments on an issue.

    Args:
        issue_id: The issue UUID.
    """
    data = await api_request("GET", f"/api/v1/issues/{issue_id}/attachments")
    return format_response(data)


@mcp.tool()
async def delete_attachment(issue_id: str, attachment_id: str) -> str:
    """Delete an attachment from an issue.

    Args:
        issue_id: The issue UUID.
        attachment_id: The attachment UUID.
    """
    data = await api_request(
        "DELETE", f"/api/v1/issues/{issue_id}/attachments/{attachment_id}"
    )
    return format_response(data)


# ---------------------------------------------------------------------------
# Sprints
# ---------------------------------------------------------------------------


@mcp.tool()
async def list_sprints(
    project_id: str,
    status_filter: Literal["future", "active", "completed"] | None = None,
) -> str:
    """List sprints in a project, optionally filtered by status.

    Args:
        project_id: The project UUID.
        status_filter: Filter by sprint status.
    """
    params: dict = {}
    if status_filter:
        params["status_filter"] = status_filter
    data = await api_request(
        "GET", f"/api/v1/sprints/project/{project_id}", params=params
    )
    return format_response(data)


@mcp.tool()
async def get_sprint_metrics(sprint_id: str) -> str:
    """Get sprint metrics including burndown chart data and velocity history.

    Args:
        sprint_id: The sprint UUID.
    """
    data = await api_request("GET", f"/api/v1/sprints/{sprint_id}/metrics")
    return format_response(data)


# ---------------------------------------------------------------------------
# Search
# ---------------------------------------------------------------------------


@mcp.tool()
async def search_issues(query: str) -> str:
    """Search issues using JQL-like syntax.

    Supports fields: status, assignee, reporter, priority, type, labels, sprint,
    created, updated, due, story_points, flagged, text, key.

    Example queries:
    - 'status = in_progress AND assignee = me'
    - 'type = bug AND priority >= high'
    - 'text ~ "login error"'
    - 'sprint = "Sprint 5" AND status != done'

    Args:
        query: JQL-like search query string.
    """
    data = await api_request("POST", "/api/v1/search/", json_body={"jql": query})
    return format_response(data)


# ---------------------------------------------------------------------------
# Users
# ---------------------------------------------------------------------------


@mcp.tool()
async def list_users() -> str:
    """List all active users in the system.

    Returns user UUID, email, full name, and avatar URL.
    """
    data = await api_request("GET", "/api/v1/users/")
    return format_response(data)


@mcp.tool()
async def get_current_user() -> str:
    """Get the currently authenticated user's profile."""
    data = await api_request("GET", "/api/v1/auth/me")
    return format_response(data)
