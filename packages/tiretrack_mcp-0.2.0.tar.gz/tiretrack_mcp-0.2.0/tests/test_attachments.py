"""Tests for attachment MCP tools."""

import json
from pathlib import Path
from unittest.mock import AsyncMock, patch

import pytest

from tiretrack_mcp.server import (
    ALLOWED_IMAGE_MIME_TYPES,
    add_attachment,
    delete_attachment,
    list_attachments,
)


@pytest.fixture
def png_file(tmp_path: Path) -> Path:
    """Create a small PNG file for testing."""
    # Minimal valid PNG (1x1 transparent pixel)
    png_bytes = (
        b"\x89PNG\r\n\x1a\n"  # PNG signature
        b"\x00\x00\x00\rIHDR\x00\x00\x00\x01\x00\x00\x00\x01"
        b"\x08\x06\x00\x00\x00\x1f\x15\xc4\x89"
        b"\x00\x00\x00\nIDATx\x9cc\x00\x01\x00\x00\x05\x00\x01"
        b"\r\n\xb4\x00\x00\x00\x00IEND\xaeB`\x82"
    )
    f = tmp_path / "screenshot.png"
    f.write_bytes(png_bytes)
    return f


@pytest.fixture
def jpeg_file(tmp_path: Path) -> Path:
    """Create a tiny JPEG file for testing."""
    f = tmp_path / "photo.jpg"
    f.write_bytes(b"\xff\xd8\xff\xe0" + b"\x00" * 20)
    return f


# ---------------------------------------------------------------------------
# add_attachment
# ---------------------------------------------------------------------------


class TestAddAttachment:
    async def test_file_not_found(self) -> None:
        result = await add_attachment("issue-uuid", "/nonexistent/image.png")
        assert "Error: file not found" in result

    async def test_unsupported_mime_type(self, tmp_path: Path) -> None:
        txt = tmp_path / "notes.txt"
        txt.write_text("hello")
        result = await add_attachment("issue-uuid", str(txt))
        assert "Error: unsupported MIME type" in result
        assert "text/plain" in result

    async def test_unknown_extension_rejected(self, tmp_path: Path) -> None:
        f = tmp_path / "data.xyz"
        f.write_bytes(b"\x00" * 10)
        result = await add_attachment("issue-uuid", str(f))
        assert "Error: unsupported MIME type" in result

    async def test_explicit_mime_type_overrides_extension(self, tmp_path: Path) -> None:
        # File has .bin extension but caller says it's a PNG
        f = tmp_path / "image.bin"
        f.write_bytes(b"\x89PNG" + b"\x00" * 20)

        with (
            patch(
                "tiretrack_mcp.server.api_request", new_callable=AsyncMock
            ) as mock_api,
            patch("tiretrack_mcp.server.httpx.AsyncClient") as mock_client_cls,
        ):
            mock_api.side_effect = [
                {
                    "upload_url": "https://s3.example.com/put",
                    "object_url": "https://s3.example.com/obj",
                },
                {"id": "att-1", "filename": "image.bin"},
            ]
            mock_client = AsyncMock()
            mock_resp = AsyncMock()
            mock_resp.raise_for_status = lambda: None
            mock_client.put = AsyncMock(return_value=mock_resp)
            mock_client.__aenter__ = AsyncMock(return_value=mock_client)
            mock_client.__aexit__ = AsyncMock(return_value=False)
            mock_client_cls.return_value = mock_client

            result = await add_attachment("issue-uuid", str(f), mime_type="image/png")
            assert "att-1" in result

    async def test_explicit_invalid_mime_type_rejected(self, png_file: Path) -> None:
        result = await add_attachment(
            "issue-uuid", str(png_file), mime_type="application/pdf"
        )
        assert "Error: unsupported MIME type" in result
        assert "application/pdf" in result

    async def test_successful_upload_flow(self, png_file: Path) -> None:
        """Full happy path: presigned URL → S3 PUT → create attachment."""
        raw_bytes = png_file.read_bytes()

        with (
            patch(
                "tiretrack_mcp.server.api_request", new_callable=AsyncMock
            ) as mock_api,
            patch("tiretrack_mcp.server.httpx.AsyncClient") as mock_client_cls,
        ):
            mock_api.side_effect = [
                # 1st call: presigned URL
                {
                    "upload_url": "https://s3.example.com/presigned-put",
                    "object_url": "https://cdn.example.com/image.png",
                },
                # 2nd call: create attachment record
                {
                    "id": "att-123",
                    "filename": "screenshot.png",
                    "file_url": "https://cdn.example.com/image.png",
                    "file_size": len(raw_bytes),
                    "mime_type": "image/png",
                },
            ]
            mock_client = AsyncMock()
            mock_resp = AsyncMock()
            mock_resp.raise_for_status = lambda: None
            mock_client.put = AsyncMock(return_value=mock_resp)
            mock_client.__aenter__ = AsyncMock(return_value=mock_client)
            mock_client.__aexit__ = AsyncMock(return_value=False)
            mock_client_cls.return_value = mock_client

            result = await add_attachment("issue-uuid", str(png_file))

        parsed = json.loads(result)
        assert parsed["id"] == "att-123"
        assert parsed["filename"] == "screenshot.png"

        # Verify presigned URL request
        presigned_call = mock_api.call_args_list[0]
        assert presigned_call.args == ("POST", "/api/v1/uploads/presigned-url")
        assert presigned_call.kwargs["json_body"]["content_type"] == "image/png"
        assert presigned_call.kwargs["json_body"]["filename"] == "screenshot.png"

        # Verify S3 PUT
        mock_client.put.assert_called_once_with(
            "https://s3.example.com/presigned-put",
            content=raw_bytes,
            headers={"Content-Type": "image/png"},
        )

        # Verify attachment record creation
        attach_call = mock_api.call_args_list[1]
        assert attach_call.args == (
            "POST",
            "/api/v1/issues/issue-uuid/attachments",
        )
        body = attach_call.kwargs["json_body"]
        assert body["filename"] == "screenshot.png"
        assert body["file_url"] == "https://cdn.example.com/image.png"
        assert body["file_size"] == len(raw_bytes)
        assert body["mime_type"] == "image/png"

    async def test_custom_filename(self, png_file: Path) -> None:
        """Custom filename is used instead of the file's basename."""
        with (
            patch(
                "tiretrack_mcp.server.api_request", new_callable=AsyncMock
            ) as mock_api,
            patch("tiretrack_mcp.server.httpx.AsyncClient") as mock_client_cls,
        ):
            mock_api.side_effect = [
                {
                    "upload_url": "https://s3.example.com/put",
                    "object_url": "https://s3.example.com/obj",
                },
                {"id": "att-1", "filename": "bug-repro.png"},
            ]
            mock_client = AsyncMock()
            mock_resp = AsyncMock()
            mock_resp.raise_for_status = lambda: None
            mock_client.put = AsyncMock(return_value=mock_resp)
            mock_client.__aenter__ = AsyncMock(return_value=mock_client)
            mock_client.__aexit__ = AsyncMock(return_value=False)
            mock_client_cls.return_value = mock_client

            await add_attachment("issue-uuid", str(png_file), filename="bug-repro.png")

        presigned_call = mock_api.call_args_list[0]
        assert presigned_call.kwargs["json_body"]["filename"] == "bug-repro.png"
        attach_call = mock_api.call_args_list[1]
        assert attach_call.kwargs["json_body"]["filename"] == "bug-repro.png"

    async def test_tilde_expansion(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """~ in file_path is expanded to the user's home directory."""
        img = tmp_path / "img.png"
        img.write_bytes(b"\x89PNG" + b"\x00" * 20)

        monkeypatch.setenv("HOME", str(tmp_path))

        with (
            patch(
                "tiretrack_mcp.server.api_request", new_callable=AsyncMock
            ) as mock_api,
            patch("tiretrack_mcp.server.httpx.AsyncClient") as mock_client_cls,
        ):
            mock_api.side_effect = [
                {
                    "upload_url": "https://s3.example.com/put",
                    "object_url": "https://s3.example.com/obj",
                },
                {"id": "att-1", "filename": "img.png"},
            ]
            mock_client = AsyncMock()
            mock_resp = AsyncMock()
            mock_resp.raise_for_status = lambda: None
            mock_client.put = AsyncMock(return_value=mock_resp)
            mock_client.__aenter__ = AsyncMock(return_value=mock_client)
            mock_client.__aexit__ = AsyncMock(return_value=False)
            mock_client_cls.return_value = mock_client

            result = await add_attachment("issue-uuid", "~/img.png")

        assert "att-1" in result

    async def test_jpeg_mime_type_inferred(self, jpeg_file: Path) -> None:
        with (
            patch(
                "tiretrack_mcp.server.api_request", new_callable=AsyncMock
            ) as mock_api,
            patch("tiretrack_mcp.server.httpx.AsyncClient") as mock_client_cls,
        ):
            mock_api.side_effect = [
                {
                    "upload_url": "https://s3.example.com/put",
                    "object_url": "https://s3.example.com/obj",
                },
                {"id": "att-1", "filename": "photo.jpg"},
            ]
            mock_client = AsyncMock()
            mock_resp = AsyncMock()
            mock_resp.raise_for_status = lambda: None
            mock_client.put = AsyncMock(return_value=mock_resp)
            mock_client.__aenter__ = AsyncMock(return_value=mock_client)
            mock_client.__aexit__ = AsyncMock(return_value=False)
            mock_client_cls.return_value = mock_client

            await add_attachment("issue-uuid", str(jpeg_file))

        presigned_call = mock_api.call_args_list[0]
        assert presigned_call.kwargs["json_body"]["content_type"] == "image/jpeg"


# ---------------------------------------------------------------------------
# list_attachments
# ---------------------------------------------------------------------------


class TestListAttachments:
    async def test_returns_formatted_json(self) -> None:
        with patch(
            "tiretrack_mcp.server.api_request", new_callable=AsyncMock
        ) as mock_api:
            mock_api.return_value = [
                {"id": "att-1", "filename": "a.png"},
                {"id": "att-2", "filename": "b.jpg"},
            ]
            result = await list_attachments("issue-uuid")

        parsed = json.loads(result)
        assert len(parsed) == 2
        assert parsed[0]["filename"] == "a.png"

        mock_api.assert_called_once_with("GET", "/api/v1/issues/issue-uuid/attachments")

    async def test_empty_list(self) -> None:
        with patch(
            "tiretrack_mcp.server.api_request", new_callable=AsyncMock
        ) as mock_api:
            mock_api.return_value = []
            result = await list_attachments("issue-uuid")

        assert json.loads(result) == []


# ---------------------------------------------------------------------------
# delete_attachment
# ---------------------------------------------------------------------------


class TestDeleteAttachment:
    async def test_returns_success(self) -> None:
        with patch(
            "tiretrack_mcp.server.api_request", new_callable=AsyncMock
        ) as mock_api:
            mock_api.return_value = {"status": "success"}
            result = await delete_attachment("issue-uuid", "att-123")

        parsed = json.loads(result)
        assert parsed["status"] == "success"

        mock_api.assert_called_once_with(
            "DELETE", "/api/v1/issues/issue-uuid/attachments/att-123"
        )


# ---------------------------------------------------------------------------
# ALLOWED_IMAGE_MIME_TYPES
# ---------------------------------------------------------------------------


class TestAllowedMimeTypes:
    def test_expected_types(self) -> None:
        assert ALLOWED_IMAGE_MIME_TYPES == {
            "image/png",
            "image/jpeg",
            "image/gif",
            "image/webp",
        }
