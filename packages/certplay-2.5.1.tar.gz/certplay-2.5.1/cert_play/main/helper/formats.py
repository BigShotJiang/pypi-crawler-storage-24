from play_helpers.ph_formats import PhFormats


class Formats:
    URL = PhFormats.URL
    DER = PhFormats.DER
