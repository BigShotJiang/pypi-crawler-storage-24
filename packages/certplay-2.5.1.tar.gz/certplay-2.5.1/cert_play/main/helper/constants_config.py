from cert_play import _defaults
from cert_play._tool_name import TOOL_NAME, TOOL_TITLE, TOOL_SW_PACKAGE_NAME, TOOL_TEST_PACKAGE_NAME, TOOL_SW_MODULE_NAME

_run_time_incremental = False
_run_time_play_helpers = False
try:
    from cert_play._version import __version__

    # incremental module is available post installation, run time only,
    _run_time_incremental = True
except ImportError:
    pass
try:
    from play_helpers.ph_defaults import PhDefaults
    from cert_play._git_info import GIT_SUMMARY

    # play_helpers module is available post installation, run time only,
    _run_time_play_helpers = True
except ImportError:
    pass


class ConfigConst:
    TOOL_VERSION = __version__.public() if _run_time_incremental else (
        PhDefaults.VERSION if _run_time_play_helpers else _defaults.VERSION)
    TOOL_VERSION_DETAILED = f'v{TOOL_VERSION}'
    TOOL_NAME = TOOL_NAME
    TOOL_TITLE = TOOL_TITLE
    TOOL_SW_PACKAGE_NAME = TOOL_SW_PACKAGE_NAME
    TOOL_TEST_PACKAGE_NAME = TOOL_TEST_PACKAGE_NAME
    TOOL_SW_MODULE_NAME = TOOL_SW_MODULE_NAME
    TOOL_GIT_SUMMARY = GIT_SUMMARY if _run_time_play_helpers else _defaults.GIT_SUMMARY
    TOOL_DESCRIPTION = f'Generic Certificate Parser based on X.509 and related standards. Can fetch (& parse) TLS certificate(s) of any live website.'
    TOOL_META_DESCRIPTION = f'{TOOL_DESCRIPTION}'
    TOOL_META_KEYWORDS = f'{TOOL_TITLE}, Certificate Parser, certificate parser, cert, certificate, tls, transport layer security, tls certificate, ssl, x509, ssl certificate, openssl. certificate chain, all server certs, all certs'
    TOOL_URL = 'https://github.com/impratikjaiswal/certPlay'
    TOOL_URL_BUG_TRACKER = 'https://github.com/impratikjaiswal/certPlay/issues'
