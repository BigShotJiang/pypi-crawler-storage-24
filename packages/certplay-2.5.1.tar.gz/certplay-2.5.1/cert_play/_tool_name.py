"""
Provides cert_play name, title & package information.
"""
TOOL_NAME = 'certPlay'
TOOL_TITLE = 'Cert Play'
TOOL_SW_PACKAGE_NAME = 'cert_play.main'
TOOL_TEST_PACKAGE_NAME = 'cert_play.test'
TOOL_SW_MODULE_NAME = 'cert_play.main.certplay'
