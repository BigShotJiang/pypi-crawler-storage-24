#----------------------------------------------------------------
# Generated CMake target import file for configuration "Release".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "SlicerLayerDM::MRML" for configuration "Release"
set_property(TARGET SlicerLayerDM::MRML APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(SlicerLayerDM::MRML PROPERTIES
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/slicer_layer_dm_sdk/content/lib/libvtkSlicerLayerDMModuleMRML.dylib"
  IMPORTED_SONAME_RELEASE "@rpath/libvtkSlicerLayerDMModuleMRML.dylib"
  )

list(APPEND _cmake_import_check_targets SlicerLayerDM::MRML )
list(APPEND _cmake_import_check_files_for_SlicerLayerDM::MRML "${_IMPORT_PREFIX}/slicer_layer_dm_sdk/content/lib/libvtkSlicerLayerDMModuleMRML.dylib" )

# Import target "SlicerLayerDM::MRMLDisplayableManager" for configuration "Release"
set_property(TARGET SlicerLayerDM::MRMLDisplayableManager APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(SlicerLayerDM::MRMLDisplayableManager PROPERTIES
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/slicer_layer_dm_sdk/content/lib/libvtkSlicerLayerDMModuleMRMLDisplayableManager.dylib"
  IMPORTED_SONAME_RELEASE "@rpath/libvtkSlicerLayerDMModuleMRMLDisplayableManager.dylib"
  )

list(APPEND _cmake_import_check_targets SlicerLayerDM::MRMLDisplayableManager )
list(APPEND _cmake_import_check_files_for_SlicerLayerDM::MRMLDisplayableManager "${_IMPORT_PREFIX}/slicer_layer_dm_sdk/content/lib/libvtkSlicerLayerDMModuleMRMLDisplayableManager.dylib" )

# Import target "SlicerLayerDM::Logic" for configuration "Release"
set_property(TARGET SlicerLayerDM::Logic APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(SlicerLayerDM::Logic PROPERTIES
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/slicer_layer_dm_sdk/content/lib/libvtkSlicerLayerDMModuleLogic.dylib"
  IMPORTED_SONAME_RELEASE "@rpath/libvtkSlicerLayerDMModuleLogic.dylib"
  )

list(APPEND _cmake_import_check_targets SlicerLayerDM::Logic )
list(APPEND _cmake_import_check_files_for_SlicerLayerDM::Logic "${_IMPORT_PREFIX}/slicer_layer_dm_sdk/content/lib/libvtkSlicerLayerDMModuleLogic.dylib" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
