set_property(TARGET "SlicerLayerDM::MRML" PROPERTY "INTERFACE_vtk_module_python_package" "slicer_layer_dm_sdk")
set_property(TARGET "SlicerLayerDM::MRMLDisplayableManager" PROPERTY "INTERFACE_vtk_module_python_package" "slicer_layer_dm_sdk")
set_property(TARGET "SlicerLayerDM::Logic" PROPERTY "INTERFACE_vtk_module_python_package" "slicer_layer_dm_sdk")
