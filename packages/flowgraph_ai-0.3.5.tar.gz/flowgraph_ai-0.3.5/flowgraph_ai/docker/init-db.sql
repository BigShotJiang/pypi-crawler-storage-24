-- FlowGraph-AI Docker PostgreSQL init
-- Creates the Langfuse database on first container startup.

SELECT 'CREATE DATABASE langfuse'
  WHERE NOT EXISTS (SELECT FROM pg_database WHERE datname = 'langfuse')\gexec
