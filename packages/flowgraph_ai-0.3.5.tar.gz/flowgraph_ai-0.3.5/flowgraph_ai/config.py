import yaml
import os
from dotenv import load_dotenv


def load_config(config_path: str | None = None) -> dict:
    """Load config from YAML and .env file."""
    # Prioritize user's working directory over the framework's installation dir
    env_path = os.path.join(os.getcwd(), ".env")
    if not os.path.exists(env_path):
        env_path = os.path.join(os.path.dirname(__file__), "..", ".env")
    load_dotenv(env_path)

    if config_path is None:
        config_path = os.path.join(os.getcwd(), "config.yaml")
        if not os.path.exists(config_path):
            config_path = os.path.join(os.path.dirname(__file__), "..", "config.yaml")
            
    try:
        with open(config_path, "r") as f:
            return yaml.safe_load(f) or {}
    except FileNotFoundError:
        # If no config is found at all, return empty dict to use framework defaults
        return {}
