"""
Workflow Loader — V3.

Loads and validates YAML workflow definitions.

V3 supports only 3 node types: data_collector, custom_action, response.

YAML format (dict-style nodes):
  workflow: my_workflow
  description: "What this handles — used by intent classifier"
  start_node: first_node
  state:
    my_field: str           # Simple type string
  nodes:
    node_name:
      type: data_collector | custom_action | response
      ...

Standard state fields auto-injected (no need to declare):
  messages, user_language, output, error, user_message
"""

import os
import yaml
import logging

logger = logging.getLogger("flowgraph.engine.workflow_loader")

def _get_workflows_dir() -> str:
    cwd_dir = os.path.join(os.getcwd(), "workflows")
    if os.path.isdir(cwd_dir):
        return cwd_dir
    return os.path.join(os.path.dirname(__file__), "..", "..", "workflows")

_WORKFLOWS_DIR = _get_workflows_dir()

_VALID_NODE_TYPES = {"data_collector", "custom_action", "response"}

_STANDARD_STATE = {
    "user_message": "str",    # Initial user message (generic)
    "user_language": "str",   # Detected language
    "output":        "str",   # Final output to user
    "error":         "str",   # Error message
    "messages":      "list",  # Full conversation history
    # Internal DataCollector routing signals
    "_dc_next_node": "str",
    "_dc_failed":    "bool",
    "_dc_node":      "str",
}


class WorkflowLoader:
    def __init__(self, workflows_dir: str | None = None, fallback_workflow: str = "greeting") -> None:
        self._dir = workflows_dir or _WORKFLOWS_DIR
        self._fallback = fallback_workflow

    def load(self, workflow_name: str) -> dict:
        """Load and normalize a workflow by name."""
        path = os.path.join(self._dir, f"{workflow_name}.yaml")
        if not os.path.exists(path):
            logger.warning(
                "[FALLBACK] workflow=%r  not_found  using=%s  path=%s",
                workflow_name, self._fallback, path,
            )
            path = os.path.join(self._dir, f"{self._fallback}.yaml")
        else:
            logger.debug("[LOAD] workflow=%s  path=%s", workflow_name, path)

        with open(path, "r") as f:
            raw = yaml.safe_load(f)

        config = self._normalize(raw, workflow_name)
        logger.info(
            "[LOAD_DONE] workflow=%s  nodes=%d  start=%s",
            config["workflow"], len(config["nodes"]), config.get("start_node"),
        )
        return config

    def load_metadata(self, workflow_name: str) -> dict:
        """Load only name + description (fast, for intent classifier)."""
        path = os.path.join(self._dir, f"{workflow_name}.yaml")
        if not os.path.exists(path):
            return {"workflow": workflow_name, "description": workflow_name}
        with open(path, "r") as f:
            raw = yaml.safe_load(f) or {}
        return {
            "workflow": raw.get("workflow", workflow_name),
            "description": raw.get("description", workflow_name.replace("_", " ")),
        }

    def _normalize(self, raw: dict, workflow_name: str) -> dict:
        """Normalize YAML to canonical internal format."""
        name = raw.get("workflow", workflow_name)
        description = raw.get("description", name.replace("_", " "))
        initial_input_field = raw.get("initial_input_field", "user_message")

        # Merge standard + user-defined state schema
        user_state = raw.get("state", {})
        state_schema = {**_STANDARD_STATE, **user_state}
        if initial_input_field not in state_schema:
            state_schema[initial_input_field] = "str"

        # Nodes: dict format (V3 primary)
        raw_nodes = raw.get("nodes", {})
        if isinstance(raw_nodes, dict):
            nodes = []
            for node_name, node_def in raw_nodes.items():
                nd = dict(node_def)
                nd["name"] = node_name
                nodes.append(nd)
        elif isinstance(raw_nodes, list):
            nodes = raw_nodes  # backward compat
        else:
            nodes = []

        start_node = raw.get("start_node") or (nodes[0]["name"] if nodes else None)

        config = {
            "workflow": name,
            "description": description,
            "initial_input_field": initial_input_field,
            "start_node": start_node,
            "state": state_schema,
            "nodes": nodes,
            "guardrails": raw.get("guardrails"),  # workflow-level guardrails override (optional)
        }
        self._validate(config)
        return config

    def _validate(self, config: dict) -> None:
        if not config.get("nodes"):
            raise ValueError(f"Workflow '{config['workflow']}' has no nodes defined.")
        for node in config["nodes"]:
            if "name" not in node:
                raise ValueError(f"Node missing 'name': {node}")
            if "type" not in node:
                raise ValueError(f"Node '{node['name']}' missing 'type'.")
            if node["type"] not in _VALID_NODE_TYPES:
                raise ValueError(
                    f"Node '{node['name']}' has unknown type '{node['type']}'. "
                    f"Valid: {_VALID_NODE_TYPES}"
                )
        node_names = {n["name"] for n in config["nodes"]}
        start = config.get("start_node")
        if start and start not in node_names:
            raise ValueError(
                f"Workflow '{config['workflow']}' start_node '{start}' not in nodes {node_names}."
            )

    def list_workflows(self) -> list[str]:
        if not os.path.isdir(self._dir):
            return []
        return [f[:-5] for f in os.listdir(self._dir) if f.endswith(".yaml")]
