import { describe, it, expect, beforeEach } from 'vitest';
import { exportToYAML, validateWorkflow } from '../../src/utils/yamlExport';

describe('Workflow Integration Tests', () => {
  describe('Service Request Workflow', () => {
    let nodes, edges;

    beforeEach(() => {
      nodes = [
        {
          id: 'node_1',
          type: 'dataCollector',
          data: {
            label: 'collect_sr',
            role: 'You are a helpful assistant',
            initial_message: 'Please provide your SR number',
            field: 'sr_number',
            description: 'Service request number in format SR-XXXXX',
            max_retry: 3,
            validation: {
              method: 'regex',
              pattern: '^SR-[0-9]{5}$'
            }
          }
        },
        {
          id: 'node_2',
          type: 'customAction',
          data: {
            label: 'check_status',
            method: 'actions.billing.check_status',
            result_field: 'status',
            routes: [
              { value: 'found', next: 'success_response' },
              { default: true, next: 'error_response' }
            ]
          }
        },
        {
          id: 'node_3',
          type: 'response',
          data: {
            label: 'success_response',
            output_field: 'output',
            template: 'Your SR {{state.sr_number}} status: {{state.status}}'
          }
        },
        {
          id: 'node_4',
          type: 'response',
          data: {
            label: 'error_response',
            error_field: 'error',
            template: 'SR {{state.sr_number}} not found'
          }
        }
      ];

      edges = [
        { source: 'node_1', target: 'node_2' },
        { source: 'node_2', target: 'node_3' },
        { source: 'node_2', target: 'node_4' }
      ];
    });

    it('should validate successfully', () => {
      const result = validateWorkflow(nodes, edges);
      expect(result.isValid).toBe(true);
      expect(result.errors.length).toBe(0);
    });

    it('should export complete YAML', () => {
      const yaml = exportToYAML(nodes, edges, 'service_request', 'Track SR status');

      expect(yaml).toContain('workflow: service_request');
      expect(yaml).toContain('description: Track SR status');
      expect(yaml).toContain('start_node: collect_sr');

      expect(yaml).toContain('collect_sr:');
      expect(yaml).toContain('type: data_collector');
      expect(yaml).toContain('field: sr_number');
      expect(yaml).toContain('pattern: ^SR-[0-9]{5}$');

      expect(yaml).toContain('check_status:');
      expect(yaml).toContain('type: custom_action');
      expect(yaml).toContain('method: actions.billing.check_status');
      expect(yaml).toContain('routes:');

      expect(yaml).toContain('success_response:');
      expect(yaml).toContain('error_response:');
      expect(yaml).toContain('type: response');
    });

    it('should include all state variables', () => {
      const yaml = exportToYAML(nodes, edges, 'service_request', 'Track SR status');

      expect(yaml).toContain('state:');
      expect(yaml).toContain('userQuery: str');
      expect(yaml).toContain('sr_number: str');
      expect(yaml).toContain('status: str');
    });
  });

  describe('Multi-Field HR Workflow', () => {
    let nodes, edges;

    beforeEach(() => {
      nodes = [
        {
          id: 'node_1',
          type: 'dataCollector',
          data: {
            label: 'collect_leave_info',
            role: 'You are an HR assistant',
            initial_message: 'Please provide your leave request details',
            max_retry: 3,
            fields: [
              { field: 'employee_id', description: 'Employee ID' },
              { field: 'leave_type', description: 'Type of leave (vacation, sick, personal)' },
              { field: 'start_date', description: 'Start date (YYYY-MM-DD)' },
              { field: 'end_date', description: 'End date (YYYY-MM-DD)' }
            ]
          }
        },
        {
          id: 'node_2',
          type: 'customAction',
          data: {
            label: 'validate_eligibility',
            method: 'actions.hr.check_eligibility',
            result_field: 'eligibility_status',
            routes: [
              { value: 'approved', next: 'confirmation' },
              { default: true, next: 'rejection' }
            ]
          }
        },
        {
          id: 'node_3',
          type: 'response',
          data: {
            label: 'confirmation',
            output_field: 'output',
            template: 'Leave approved from {{state.start_date}} to {{state.end_date}}'
          }
        },
        {
          id: 'node_4',
          type: 'response',
          data: {
            label: 'rejection',
            error_field: 'error',
            template: 'Leave request cannot be approved'
          }
        }
      ];

      edges = [
        { source: 'node_1', target: 'node_2' },
        { source: 'node_2', target: 'node_3' },
        { source: 'node_2', target: 'node_4' }
      ];
    });

    it('should validate multi-field workflow', () => {
      const result = validateWorkflow(nodes, edges);
      expect(result.isValid).toBe(true);
    });

    it('should export multi-field configuration', () => {
      const yaml = exportToYAML(nodes, edges, 'hr_leave_request', 'Leave request workflow');

      expect(yaml).toContain('fields:');
      expect(yaml).toContain('field: employee_id');
      expect(yaml).toContain('field: leave_type');
      expect(yaml).toContain('field: start_date');
      expect(yaml).toContain('field: end_date');

      expect(yaml).toContain('description: Employee ID');
      expect(yaml).toContain('description: Type of leave');
    });

    it('should add all fields to state', () => {
      const yaml = exportToYAML(nodes, edges, 'hr_leave_request', 'Leave request workflow');

      expect(yaml).toContain('employee_id: str');
      expect(yaml).toContain('leave_type: str');
      expect(yaml).toContain('start_date: str');
      expect(yaml).toContain('end_date: str');
      expect(yaml).toContain('eligibility_status: str');
    });
  });

  describe('Complex Branching Workflow', () => {
    it('should handle multiple paths', () => {
      const nodes = [
        {
          id: '1',
          type: 'dataCollector',
          data: { label: 'collect', initial_message: 'test', field: 'data' }
        },
        {
          id: '2',
          type: 'customAction',
          data: {
            label: 'route',
            method: 'actions.route',
            result_field: 'path',
            routes: [
              { value: 'path_a', next: 'response_a' },
              { value: 'path_b', next: 'response_b' },
              { value: 'path_c', next: 'response_c' },
              { default: true, next: 'default_response' }
            ]
          }
        },
        {
          id: '3',
          type: 'response',
          data: { label: 'response_a', output_field: 'output', template: 'Path A' }
        },
        {
          id: '4',
          type: 'response',
          data: { label: 'response_b', output_field: 'output', template: 'Path B' }
        },
        {
          id: '5',
          type: 'response',
          data: { label: 'response_c', output_field: 'output', template: 'Path C' }
        },
        {
          id: '6',
          type: 'response',
          data: { label: 'default_response', output_field: 'output', template: 'Default' }
        }
      ];

      const edges = [
        { source: '1', target: '2' },
        { source: '2', target: '3' },
        { source: '2', target: '4' },
        { source: '2', target: '5' },
        { source: '2', target: '6' }
      ];

      const result = validateWorkflow(nodes, edges);
      expect(result.isValid).toBe(true);

      const yaml = exportToYAML(nodes, edges, 'branching', 'Complex branching');
      expect(yaml).toContain('value: path_a');
      expect(yaml).toContain('value: path_b');
      expect(yaml).toContain('value: path_c');
      expect(yaml).toContain('default: default_response');
    });
  });

  describe('Error Cases', () => {
    it('should detect disconnected nodes', () => {
      const nodes = [
        {
          id: '1',
          type: 'dataCollector',
          data: { label: 'collect', initial_message: 'test', field: 'data' }
        },
        {
          id: '2',
          type: 'response',
          data: { label: 'orphan', output_field: 'output', template: 'Orphaned' }
        }
      ];
      const edges = [];

      const result = validateWorkflow(nodes, edges);
      expect(result.warnings.some(w => w.includes('no outgoing connections'))).toBe(true);
    });

    it('should detect missing required fields', () => {
      const nodes = [
        {
          id: '1',
          type: 'dataCollector',
          data: { label: 'bad_collector' }
        }
      ];
      const edges = [];

      const result = validateWorkflow(nodes, edges);
      expect(result.isValid).toBe(false);
      expect(result.errors.some(e => e.includes('missing initial message'))).toBe(true);
      expect(result.errors.some(e => e.includes('must have at least one field'))).toBe(true);
    });
  });
});
