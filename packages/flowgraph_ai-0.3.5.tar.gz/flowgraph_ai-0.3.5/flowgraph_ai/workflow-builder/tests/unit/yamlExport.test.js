import { describe, it, expect } from 'vitest';
import { exportToYAML, validateWorkflow } from '../../src/utils/yamlExport';

describe('yamlExport', () => {
  describe('validateWorkflow', () => {
    it('should return error when no nodes exist', () => {
      const result = validateWorkflow([], []);
      expect(result.isValid).toBe(false);
      expect(result.errors).toContain('Workflow must have at least one node');
    });

    it('should return error when no start node exists', () => {
      const nodes = [
        { id: '1', type: 'dataCollector', data: { label: 'Node 1' } },
        { id: '2', type: 'response', data: { label: 'Node 2' } }
      ];
      const edges = [
        { source: '1', target: '2' },
        { source: '2', target: '1' }
      ];

      const result = validateWorkflow(nodes, edges);
      expect(result.isValid).toBe(false);
      expect(result.errors).toContain('Workflow must have a start node (node with no incoming connections)');
    });

    it('should warn when multiple start nodes exist', () => {
      const nodes = [
        { id: '1', type: 'dataCollector', data: { label: 'Node 1' } },
        { id: '2', type: 'dataCollector', data: { label: 'Node 2' } }
      ];
      const edges = [];

      const result = validateWorkflow(nodes, edges);
      expect(result.warnings.length).toBeGreaterThan(0);
      expect(result.warnings[0]).toContain('Multiple start nodes');
    });

    it('should validate data collector node has initial message', () => {
      const nodes = [
        { id: '1', type: 'dataCollector', data: { label: 'collect_data', field: 'test' } }
      ];
      const edges = [];

      const result = validateWorkflow(nodes, edges);
      expect(result.isValid).toBe(false);
      expect(result.errors.some(e => e.includes('missing initial message'))).toBe(true);
    });

    it('should validate data collector has at least one field', () => {
      const nodes = [
        { id: '1', type: 'dataCollector', data: { label: 'collect_data', initial_message: 'Enter data' } }
      ];
      const edges = [];

      const result = validateWorkflow(nodes, edges);
      expect(result.isValid).toBe(false);
      expect(result.errors.some(e => e.includes('must have at least one field'))).toBe(true);
    });

    it('should validate custom action has method', () => {
      const nodes = [
        { id: '1', type: 'customAction', data: { label: 'action' } }
      ];
      const edges = [];

      const result = validateWorkflow(nodes, edges);
      expect(result.isValid).toBe(false);
      expect(result.errors.some(e => e.includes('missing method'))).toBe(true);
    });

    it('should warn when custom action has no routes', () => {
      const nodes = [
        { id: '1', type: 'customAction', data: { label: 'action', method: 'test.method' } }
      ];
      const edges = [];

      const result = validateWorkflow(nodes, edges);
      expect(result.warnings.some(w => w.includes('no routes defined'))).toBe(true);
    });

    it('should detect duplicate node names', () => {
      const nodes = [
        { id: '1', type: 'dataCollector', data: { label: 'collect_data', initial_message: 'test', field: 'test' } },
        { id: '2', type: 'dataCollector', data: { label: 'collect_data', initial_message: 'test', field: 'test' } }
      ];
      const edges = [];

      const result = validateWorkflow(nodes, edges);
      expect(result.isValid).toBe(false);
      expect(result.errors.some(e => e.includes('Duplicate node names'))).toBe(true);
    });

    it('should pass validation for valid workflow', () => {
      const nodes = [
        {
          id: '1',
          type: 'dataCollector',
          data: {
            label: 'collect_data',
            initial_message: 'Enter your email',
            field: 'email'
          }
        },
        {
          id: '2',
          type: 'customAction',
          data: {
            label: 'validate_email',
            method: 'actions.validate',
            routes: [{ value: 'valid', next: 'success' }]
          }
        },
        {
          id: '3',
          type: 'response',
          data: {
            label: 'success',
            output_field: 'output',
            template: 'Success!'
          }
        }
      ];
      const edges = [
        { source: '1', target: '2' },
        { source: '2', target: '3' }
      ];

      const result = validateWorkflow(nodes, edges);
      expect(result.isValid).toBe(true);
      expect(result.errors.length).toBe(0);
    });
  });

  describe('exportToYAML', () => {
    it('should generate valid YAML for simple workflow', () => {
      const nodes = [
        {
          id: '1',
          type: 'dataCollector',
          data: {
            label: 'collect_email',
            initial_message: 'Enter your email',
            field: 'email'
          }
        },
        {
          id: '2',
          type: 'response',
          data: {
            label: 'success',
            output_field: 'output',
            template: 'Thanks for {{state.email}}'
          }
        }
      ];
      const edges = [{ source: '1', target: '2' }];

      const yaml = exportToYAML(nodes, edges, 'test_workflow', 'Test workflow');

      expect(yaml).toContain('workflow: test_workflow');
      expect(yaml).toContain('description: Test workflow');
      expect(yaml).toContain('start_node: collect_email');
      expect(yaml).toContain('type: data_collector');
      expect(yaml).toContain('type: response');
      expect(yaml).toContain('initial_message: Enter your email');
      expect(yaml).toContain('field: email');
    });

    it('should handle multi-field data collectors', () => {
      const nodes = [
        {
          id: '1',
          type: 'dataCollector',
          data: {
            label: 'collect_info',
            initial_message: 'Enter your info',
            fields: [
              { field: 'name', description: 'Your name' },
              { field: 'email', description: 'Your email' }
            ]
          }
        }
      ];
      const edges = [];

      const yaml = exportToYAML(nodes, edges, 'test', 'Test');

      expect(yaml).toContain('fields:');
      expect(yaml).toContain('field: name');
      expect(yaml).toContain('field: email');
      expect(yaml).toContain('description: Your name');
      expect(yaml).toContain('description: Your email');
    });

    it('should handle custom action routes', () => {
      const nodes = [
        {
          id: '1',
          type: 'customAction',
          data: {
            label: 'check_status',
            method: 'actions.check',
            result_field: 'status',
            routes: [
              { value: 'found', next: 'success' },
              { value: 'not_found', next: 'error' },
              { default: true, next: 'fallback' }
            ]
          }
        }
      ];
      const edges = [];

      const yaml = exportToYAML(nodes, edges, 'test', 'Test');

      expect(yaml).toContain('method: actions.check');
      expect(yaml).toContain('result_field: status');
      expect(yaml).toContain('routes:');
      expect(yaml).toContain('value: found');
      expect(yaml).toContain('next: success');
      expect(yaml).toContain('default: fallback');
    });

    it('should populate state variables from nodes', () => {
      const nodes = [
        {
          id: '1',
          type: 'dataCollector',
          data: {
            label: 'collect',
            initial_message: 'test',
            field: 'email'
          }
        },
        {
          id: '2',
          type: 'customAction',
          data: {
            label: 'action',
            method: 'test',
            result_field: 'result'
          }
        }
      ];
      const edges = [];

      const yaml = exportToYAML(nodes, edges, 'test', 'Test');

      expect(yaml).toContain('state:');
      expect(yaml).toContain('email: str');
      expect(yaml).toContain('result: str');
    });
  });
});
