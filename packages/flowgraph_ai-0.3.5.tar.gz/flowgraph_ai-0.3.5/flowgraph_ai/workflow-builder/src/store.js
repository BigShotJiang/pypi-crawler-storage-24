import { create } from 'zustand';
import { persist } from 'zustand/middleware';
import { v4 as uuidv4 } from 'uuid';

const useStore = create(
  persist(
    (set, get) => ({
      folders: [
        { id: 'root', name: 'Workflows', parentId: null }
      ],
      workflows: [],
      activeWorkflowId: null,

      addFolder: (name, parentId = 'root') => set((state) => ({
        folders: [...state.folders, { id: uuidv4(), name, parentId }]
      })),

      deleteFolder: (folderId) => set((state) => {
        if (folderId === 'root') return state;
        return {
          folders: state.folders.filter(f => f.id !== folderId),
          workflows: state.workflows.map(wf => 
            wf.folderId === folderId ? { ...wf, folderId: 'root' } : wf
          )
        };
      }),

      saveWorkflow: (workflowData) => set((state) => {
        const { id, name, description, nodes, edges, folderId, globalConfig, stateFields, initialInputField } = workflowData;
        const now = new Date().toISOString();

        if (state.workflows.find(w => w.id === id)) {
          return {
            workflows: state.workflows.map(w => 
              w.id === id 
                ? { ...w, name, description, nodes, edges, folderId, globalConfig, stateFields, initialInputField, updatedAt: now } 
                : w
            ),
            activeWorkflowId: id
          };
        } else {
          const newId = id || uuidv4();
          return {
            workflows: [
              ...state.workflows,
              {
                id: newId,
                name: name || 'New Workflow',
                description: description || '',
                folderId: folderId || 'root',
                nodes: nodes || [],
                edges: edges || [],
                globalConfig: globalConfig || {},
                stateFields: stateFields || [],
                initialInputField: initialInputField || 'user_message',
                createdAt: now,
                updatedAt: now
              }
            ],
            activeWorkflowId: newId
          };
        }
      }),

      deleteWorkflow: (workflowId) => set((state) => ({
        workflows: state.workflows.filter(w => w.id !== workflowId),
        activeWorkflowId: state.activeWorkflowId === workflowId ? null : state.activeWorkflowId
      })),

      setActiveWorkflow: (workflowId) => set({ activeWorkflowId: workflowId }),

      updateActiveWorkflow: (updates) => set((state) => {
        if (!state.activeWorkflowId) return state;
        const now = new Date().toISOString();
        return {
          workflows: state.workflows.map(w =>
            w.id === state.activeWorkflowId
              ? { ...w, ...updates, updatedAt: now }
              : w
          )
        };
      })

    }),
    {
      name: 'flowgraph-builder-storage',
    }
  )
);

export default useStore;
