import React, { useState } from 'react';
import { ThemeProvider } from './contexts/ThemeContext';
import Layout from './components/Layout';
import Builder from './pages/Builder';
import Examples from './pages/Examples';
import Templates from './pages/Templates';
import Help from './pages/Help';

function App() {
  const [currentPage, setCurrentPage] = useState('builder');

  const renderPage = () => {
    switch (currentPage) {
      case 'builder':
        return <Builder />;
      case 'examples':
        return <Examples />;
      case 'templates':
        return <Templates />;
      case 'help':
        return <Help />;
      default:
        return <Builder />;
    }
  };

  return (
    <ThemeProvider>
      <Layout currentPage={currentPage} onPageChange={setCurrentPage}>
        {renderPage()}
      </Layout>
    </ThemeProvider>
  );
}

export default App;
