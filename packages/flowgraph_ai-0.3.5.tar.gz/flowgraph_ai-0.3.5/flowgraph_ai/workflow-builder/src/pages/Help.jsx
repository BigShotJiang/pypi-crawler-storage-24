import React from 'react';
import { HelpCircle, Zap, Database, GitBranch, CheckCircle2, MessageSquare, FileCode } from 'lucide-react';

const sections = [
  {
    id: 'getting-started',
    title: 'Getting Started',
    icon: HelpCircle,
    content: [
      {
        title: 'Building Your First Workflow',
        steps: [
          'Drag nodes from the sidebar onto the canvas',
          'Connect nodes by dragging from the bottom handle to the top handle of another node',
          'Click an edge to define its routing condition or type (Success, Error, Default)',
          'Click any node to configure it in the right panel',
          'Use "State" in the top bar to define custom state variables',
          'Click "Preview" to see the YAML output, or "Export YAML" to download your workflow'
        ]
      }
    ]
  },
  {
    id: 'data-collector',
    title: 'Data Collector Node',
    icon: Database,
    color: 'blue',
    content: [
      {
        title: 'Purpose',
        text: 'Collects information from users with validation and retry logic. Supports both single-field and multi-field collection.'
      },
      {
        title: 'Key Features',
        features: [
          'Single or multi-field data collection',
          'Built-in validation (regex or custom Python functions)',
          'Automatic retry with fallback routing (on_max_retry)',
          'Optional intent escape for off-topic questions',
          'Humanize responses or run strict hallucination checks',
          'Customizable role, prompts, and Guardrails'
        ]
      },
      {
        title: 'Configuration',
        fields: [
          { name: 'Node Name', desc: 'Unique identifier for the node' },
          { name: 'Role', desc: 'System instruction for LLM behavior' },
          { name: 'Initial Message', desc: 'Question to ask the user' },
          { name: 'Field(s)', desc: 'Data to collect from user (supports default values)' },
          { name: 'Max Retries', desc: 'Number of retry attempts (default: 3)' },
          { name: 'On Max Retry', desc: 'Fallback node to trigger if all retries fail' },
          { name: 'Validation', desc: 'Regex pattern or Python function' },
          { name: 'Intent Escape', desc: 'Allow off-topic questions (toggle/custom prompt)' },
          { name: 'Humanize', desc: 'LLM naturalizes bot responses (toggle/custom prompt)' },
          { name: 'Hallucination Check', desc: 'Verify extraction against context (toggle/custom prompt)' },
          { name: 'Tools', desc: 'Python functions LLM can use to fetch data' },
          { name: 'Guardrails', desc: 'Control response tone and custom safety rules' },
          { name: 'LLM Params', desc: 'Override model, temperature, max tokens, top_p' }
        ]
      }
    ]
  },
  {
    id: 'custom-action',
    title: 'Custom Action Node',
    icon: Zap,
    color: 'orange',
    content: [
      {
        title: 'Purpose',
        text: 'Executes Python business logic and routes to different nodes based on the result.'
      },
      {
        title: 'Key Features',
        features: [
          'Calls custom Python functions',
          'Stores results in workflow state',
          'Conditional routing based on return value',
          'Visual routing with edge type definitions',
          'Support for default routes and error handling',
          'Integrates with external APIs and databases'
        ]
      },
      {
        title: 'Configuration',
        fields: [
          { name: 'Node Name', desc: 'Unique identifier for the node' },
          { name: 'Method Path', desc: 'Python function path (e.g., actions.billing.check_status)' },
          { name: 'Result Field', desc: 'State variable to store the result' },
          { name: 'Routes', desc: 'Mapping of values to next nodes' }
        ]
      }
    ]
  },
  {
    id: 'response',
    title: 'Response Node',
    icon: MessageSquare,
    color: 'green',
    content: [
      {
        title: 'Purpose',
        text: 'Sends the final response to the user. Always the endpoint of a workflow path.'
      },
      {
        title: 'Key Features',
        features: [
          'Template-based responses with state variables',
          'Separate output and error fields',
          'Variable interpolation using {{state.variable}}',
          'Marks the end of workflow execution'
        ]
      },
      {
        title: 'Configuration',
        fields: [
          { name: 'Node Name', desc: 'Unique identifier for the node' },
          { name: 'Output Field', desc: 'State field for success output' },
          { name: 'Error Field', desc: 'State field for error output' },
          { name: 'Template', desc: 'Response message with {{state.variables}}' },
          { name: 'Response Type', desc: 'Visual styling (Default, Success, Error)' },
          { name: 'Guardrails', desc: 'Control final response tone/safety' }
        ]
      }
    ]
  },
  {
    id: 'best-practices',
    title: 'Best Practices',
    icon: CheckCircle2,
    content: [
      {
        title: 'Workflow Design',
        tips: [
          'Start simple with 3-4 nodes',
          'Use descriptive node names',
          'Add validation to all user inputs',
          'Plan your routes before building',
          'Test incrementally as you build',
          'Keep workflows focused on a single task'
        ]
      },
      {
        title: 'Node Naming',
        tips: [
          'Use snake_case for node names',
          'Be descriptive: collect_email not node1',
          'Prefix similar nodes: collect_name, collect_email',
          'Keep names concise but clear'
        ]
      }
    ]
  },
  {
    id: 'validation',
    title: 'Validation',
    icon: GitBranch,
    content: [
      {
        title: 'Regex Validation',
        examples: [
          { pattern: '^[\\w.-]+@[\\w.-]+\\.\\w+$', desc: 'Email address' },
          { pattern: '^\\+?[1-9]\\d{1,14}$', desc: 'Phone number' },
          { pattern: '^\\d{4}-\\d{2}-\\d{2}$', desc: 'Date (YYYY-MM-DD)' },
          { pattern: '^SR-[0-9]{5}$', desc: 'Service request number' },
          { pattern: '^[A-Z]{2,3}-[0-9]+$', desc: 'Ticket ID' }
        ]
      },
      {
        title: 'Custom Validation',
        text: 'Create Python validation functions in validations/ directory. Return (bool, str) tuple where bool indicates validity and str contains error message.'
      }
    ]
  },
  {
    id: 'yaml-structure',
    title: 'YAML Structure',
    icon: FileCode,
    content: [
      {
        title: 'Workflow Structure',
        code: `workflow: workflow_name
description: What this workflow does
initial_input_field: userQuery
state:
  userQuery: str
  custom_field: str
start_node: first_node
nodes:
  first_node:
    type: data_collector
    # ... node config
  second_node:
    type: custom_action
    # ... node config`
      }
    ]
  }
];

export default function Help() {
  const [activeSection, setActiveSection] = React.useState('getting-started');

  const activeContent = sections.find(s => s.id === activeSection);

  return (
    <div className="flex h-[calc(100vh-4rem)]">
      <aside className="w-64 bg-white dark:bg-gray-800 border-r border-gray-200 dark:border-gray-700 overflow-y-auto">
        <div className="p-4 space-y-1">
          {sections.map((section) => {
            const Icon = section.icon;
            const isActive = activeSection === section.id;
            return (
              <button
                key={section.id}
                onClick={() => setActiveSection(section.id)}
                className={`w-full flex items-center gap-3 px-4 py-3 rounded-lg text-left transition-all duration-200 ${
                  isActive
                    ? 'bg-blue-50 dark:bg-blue-900/30 text-blue-600 dark:text-blue-400'
                    : 'text-gray-600 dark:text-gray-400 hover:bg-gray-50 dark:hover:bg-gray-700/50'
                }`}
              >
                <Icon size={18} />
                <span className="text-sm font-medium">{section.title}</span>
              </button>
            );
          })}
        </div>
      </aside>

      <main className="flex-1 overflow-y-auto bg-gray-50 dark:bg-gray-900">
        <div className="max-w-4xl mx-auto p-8">
          {activeContent && (
            <>
              <div className="mb-8">
                <div className="flex items-center gap-4 mb-3">
                  {React.createElement(activeContent.icon, {
                    size: 32,
                    className: 'text-blue-600 dark:text-blue-400'
                  })}
                  <h1 className="text-3xl font-bold text-gray-900 dark:text-gray-100">
                    {activeContent.title}
                  </h1>
                </div>
              </div>

              <div className="space-y-8">
                {activeContent.content.map((item, idx) => (
                  <div key={idx} className="bg-white dark:bg-gray-800 rounded-xl p-6 border border-gray-200 dark:border-gray-700">
                    {item.title && (
                      <h2 className="text-xl font-bold text-gray-900 dark:text-gray-100 mb-4">
                        {item.title}
                      </h2>
                    )}

                    {item.text && (
                      <p className="text-gray-600 dark:text-gray-400 leading-relaxed">
                        {item.text}
                      </p>
                    )}

                    {item.steps && (
                      <ol className="space-y-3">
                        {item.steps.map((step, i) => (
                          <li key={i} className="flex gap-3">
                            <span className="flex-shrink-0 w-6 h-6 rounded-full bg-blue-500 text-white flex items-center justify-center text-sm font-bold">
                              {i + 1}
                            </span>
                            <span className="text-gray-600 dark:text-gray-400 pt-0.5">
                              {step}
                            </span>
                          </li>
                        ))}
                      </ol>
                    )}

                    {item.features && (
                      <ul className="space-y-2">
                        {item.features.map((feature, i) => (
                          <li key={i} className="flex items-start gap-2">
                            <CheckCircle2 size={16} className="text-green-500 mt-1 flex-shrink-0" />
                            <span className="text-gray-600 dark:text-gray-400">{feature}</span>
                          </li>
                        ))}
                      </ul>
                    )}

                    {item.fields && (
                      <div className="space-y-3">
                        {item.fields.map((field, i) => (
                          <div key={i} className="flex gap-3">
                            <div className="font-mono text-sm font-semibold text-blue-600 dark:text-blue-400 min-w-[140px]">
                              {field.name}
                            </div>
                            <div className="text-sm text-gray-600 dark:text-gray-400">
                              {field.desc}
                            </div>
                          </div>
                        ))}
                      </div>
                    )}

                    {item.tips && (
                      <ul className="space-y-2">
                        {item.tips.map((tip, i) => (
                          <li key={i} className="flex items-start gap-2">
                            <div className="w-1.5 h-1.5 rounded-full bg-blue-500 mt-2 flex-shrink-0"></div>
                            <span className="text-gray-600 dark:text-gray-400">{tip}</span>
                          </li>
                        ))}
                      </ul>
                    )}

                    {item.examples && (
                      <div className="space-y-3">
                        {item.examples.map((example, i) => (
                          <div key={i} className="bg-gray-50 dark:bg-gray-900 rounded-lg p-3">
                            <div className="font-mono text-xs text-blue-600 dark:text-blue-400 mb-1">
                              {example.pattern}
                            </div>
                            <div className="text-xs text-gray-600 dark:text-gray-400">
                              {example.desc}
                            </div>
                          </div>
                        ))}
                      </div>
                    )}

                    {item.code && (
                      <pre className="bg-gray-50 dark:bg-gray-900 rounded-lg p-4 overflow-x-auto">
                        <code className="text-sm font-mono text-gray-900 dark:text-gray-100">
                          {item.code}
                        </code>
                      </pre>
                    )}
                  </div>
                ))}
              </div>
            </>
          )}
        </div>
      </main>
    </div>
  );
}
