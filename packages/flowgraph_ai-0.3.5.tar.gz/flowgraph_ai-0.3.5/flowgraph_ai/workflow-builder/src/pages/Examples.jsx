import React from 'react';
import { Play, Download, Copy, CheckCircle2, ArrowRight, X } from 'lucide-react';

const examples = [
  {
    id: 'service-request',
    title: 'Service Request Tracking',
    description: 'Collect SR number, validate format, check status, and provide response',
    category: 'Customer Support',
    nodes: 4,
    complexity: 'Simple',
    color: 'blue',
    flow: ['collect_sr', 'validate_sr', 'check_status', 'response'],
    yaml: `workflow: service_request
description: Track service request status
initial_input_field: userQuery
state:
  userQuery: str
  sr_number: str
start_node: collect_sr
guardrails:
  enabled: true
  tone: "professional and helpful"
nodes:
  collect_sr:
    type: data_collector
    role: "You are a helpful service desk assistant."
    initial_message: "Please provide your SR number (e.g., SR-12345)"
    field: sr_number
    description: "Service Request number in format SR-XXXXX"
    max_retry: 3
    next: check_status
    on_max_retry: error_response
    validation:
      method: "validations.sr.check_sr_format"
  check_status:
    type: custom_action
    method: "actions.billing.check_status"
    result_field: status_result
    routes:
      - value: "found"
        next: success_response
      - default: error_response
  success_response:
    type: response
    output_field: output
    template: "Your service request {{state.sr_number}} is {{state.status_result}}"
  error_response:
    type: response
    error_field: error
    template: "Sorry, we couldn't find that service request"
ui_metadata:
  nodes:
    success_response:
      response_type: success
    error_response:
      response_type: error
  edges:
    "check_status->success_response":
      label: "found"
      type: success
    "check_status->error_response":
      label: "default fallback"
      type: error`
  },
  {
    id: 'order-tracking',
    title: 'Order Tracking',
    description: 'Track customer orders with order ID validation and status updates',
    category: 'E-commerce',
    nodes: 5,
    complexity: 'Medium',
    color: 'orange',
    flow: ['collect_order', 'validate_order', 'fetch_details', 'check_delivery', 'response'],
    yaml: `workflow: order_tracking
description: Track customer order status
initial_input_field: userQuery
state:
  userQuery: str
  order_id: str
start_node: collect_order
nodes:
  collect_order:
    type: data_collector
    initial_message: "Please provide your order ID"
    field: order_id
    description: "Order ID in format ORD-XXXXX"
    max_retry: 3
    humanize:
      enabled: true
      custom_prompt: "Ask for the order number politely. Acknowledge their time."
    hallucination_check: true
    next: fetch_details
    validation:
      method: regex
      pattern: "^ORD-[0-9]{5}$"
  fetch_details:
    type: custom_action
    method: "actions.store.get_order_details"
    result_field: order_details
    routes:
      - value: "found"
        next: success_response
      - default: not_found_response
  success_response:
    type: response
    output_field: output
    template: "Order {{state.order_id}}: {{state.order_details}}"
  not_found_response:
    type: response
    error_field: error
    template: "Order not found"
ui_metadata:
  nodes:
    success_response:
      response_type: success
    not_found_response:
      response_type: error
  edges:
    "fetch_details->success_response":
      label: "found"
      type: success
    "fetch_details->not_found_response":
      label: "default fallback"
      type: error`
  },
  {
    id: 'hr-leave-request',
    title: 'HR Leave Request',
    description: 'Multi-field data collection for employee leave requests',
    category: 'Human Resources',
    nodes: 3,
    complexity: 'Simple',
    color: 'green',
    flow: ['collect_leave_info', 'validate_eligibility', 'confirmation'],
    yaml: `workflow: hr_leave_request
description: Process employee leave requests
initial_input_field: userQuery
state:
  userQuery: str
  employee_id: str
  leave_type: str
  start_date: str
  end_date: str
start_node: collect_leave_info
nodes:
  collect_leave_info:
    type: data_collector
    role: "You are a helpful HR assistant."
    initial_message: "Please provide your leave request details"
    max_retry: 3
    next: validate_eligibility
    llm_params:
      temperature: 0.1
    fields:
      - field: employee_id
        description: "Employee ID"
        validation:
          method: regex
          pattern: "^EMP-[0-9]{4}$"
      - field: leave_type
        description: "Type of leave (vacation, sick, personal)"
        default: "vacation"
      - field: start_date
        description: "Start date (YYYY-MM-DD)"
      - field: end_date
        description: "End date (YYYY-MM-DD)"
  validate_eligibility:
    type: custom_action
    method: "actions.hr.check_eligibility"
    result_field: eligibility_status
    routes:
      - value: "approved"
        next: confirmation
      - default: rejection
  confirmation:
    type: response
    output_field: output
    template: "Leave request approved from {{state.start_date}} to {{state.end_date}}"
  rejection:
    type: response
    error_field: error
    template: "Leave request cannot be approved"
ui_metadata:
  nodes:
    confirmation:
      response_type: success
    rejection:
      response_type: error
  edges:
    "validate_eligibility->confirmation":
      label: "approved"
      type: success
    "validate_eligibility->rejection":
      label: "default fallback"
      type: error`
  },
  {
    id: 'product-inquiry',
    title: 'Product Inquiry',
    description: 'Answer customer questions about products with FAQ integration',
    category: 'E-commerce',
    nodes: 3,
    complexity: 'Simple',
    color: 'cyan',
    flow: ['collect_question', 'search_faq', 'response'],
    yaml: `workflow: product_inquiry
description: Handle product-related questions
initial_input_field: userQuery
state:
  userQuery: str
  product_name: str
start_node: collect_question
nodes:
  collect_question:
    type: data_collector
    initial_message: "What product would you like to know about?"
    field: product_name
    description: "Product name or ID"
    max_retry: 2
    next: search_faq
    allow_intent_escape: true
  search_faq:
    type: custom_action
    method: "actions.faq.search_product"
    result_field: faq_answer
    routes:
      - value: "found"
        next: answer_response
      - default: no_answer_response
  answer_response:
    type: response
    output_field: output
    template: "{{state.faq_answer}}"
  no_answer_response:
    type: response
    output_field: output
    template: "I don't have information about that product"
ui_metadata:
  nodes:
    answer_response:
      response_type: success
    no_answer_response:
      response_type: default
  edges:
    "search_faq->answer_response":
      label: "found"
      type: condition
    "search_faq->no_answer_response":
      label: "default fallback"
      type: default`
  }
];

export default function Examples() {
  const [selectedExample, setSelectedExample] = React.useState(null);
  const [copiedId, setCopiedId] = React.useState(null);

  const handleCopy = (id, yaml) => {
    navigator.clipboard.writeText(yaml);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  const handleDownload = (example) => {
    const blob = new Blob([example.yaml], { type: 'text/yaml' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `${example.id}.yaml`;
    link.click();
    URL.revokeObjectURL(url);
  };

  const getColorClasses = (color) => {
    const colors = {
      blue: 'from-blue-500 to-cyan-500',
      orange: 'from-orange-500 to-amber-500',
      green: 'from-green-500 to-emerald-500',
      cyan: 'from-cyan-500 to-blue-500',
    };
    return colors[color] || colors.blue;
  };

  return (
    <div className="p-8">
      <div className="max-w-7xl mx-auto">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900 dark:text-gray-100 mb-2">
            Workflow Examples
          </h1>
          <p className="text-gray-600 dark:text-gray-400">
            Pre-built workflow examples to help you get started quickly
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {examples.map((example) => (
            <div
              key={example.id}
              className="bg-white dark:bg-gray-800 rounded-xl border-2 border-gray-200 dark:border-gray-700 overflow-hidden hover:border-gray-300 dark:hover:border-gray-600 transition-all duration-200 hover:shadow-lg cursor-pointer group"
              onClick={() => setSelectedExample(example)}
            >
              <div className={`h-2 bg-gradient-to-r ${getColorClasses(example.color)}`} />

              <div className="p-6">
                <div className="flex items-start justify-between mb-4">
                  <div className="flex-1">
                    <h3 className="text-lg font-bold text-gray-900 dark:text-gray-100 mb-1 group-hover:text-blue-600 dark:group-hover:text-blue-400 transition-colors">
                      {example.title}
                    </h3>
                    <p className="text-sm text-gray-600 dark:text-gray-400">
                      {example.description}
                    </p>
                  </div>
                </div>

                <div className="flex items-center gap-4 mb-4 text-xs text-gray-500 dark:text-gray-400">
                  <span className="flex items-center gap-1">
                    <div className="w-2 h-2 rounded-full bg-blue-500" />
                    {example.nodes} nodes
                  </span>
                  <span className="px-2 py-1 bg-gray-100 dark:bg-gray-700 rounded">
                    {example.category}
                  </span>
                  <span className={`px-2 py-1 rounded ${
                    example.complexity === 'Simple' ? 'bg-green-100 dark:bg-green-900/30 text-green-700 dark:text-green-400' :
                    example.complexity === 'Medium' ? 'bg-yellow-100 dark:bg-yellow-900/30 text-yellow-700 dark:text-yellow-400' :
                    'bg-red-100 dark:bg-red-900/30 text-red-700 dark:text-red-400'
                  }`}>
                    {example.complexity}
                  </span>
                </div>

                <div className="flex items-center gap-2 mb-4 overflow-x-auto pb-2">
                  {example.flow.map((step, idx) => (
                    <React.Fragment key={step}>
                      <div className="flex items-center gap-2 px-3 py-1.5 bg-gray-50 dark:bg-gray-700/50 rounded-lg flex-shrink-0">
                        <span className="text-xs font-mono text-gray-700 dark:text-gray-300">{step}</span>
                      </div>
                      {idx < example.flow.length - 1 && (
                        <ArrowRight size={14} className="text-gray-400 flex-shrink-0" />
                      )}
                    </React.Fragment>
                  ))}
                </div>

                <div className="flex gap-2">
                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      handleCopy(example.id, example.yaml);
                    }}
                    className="flex-1 flex items-center justify-center gap-2 px-3 py-2 bg-gray-100 dark:bg-gray-700 text-gray-700 dark:text-gray-300 rounded-lg hover:bg-gray-200 dark:hover:bg-gray-600 transition-all duration-200"
                  >
                    {copiedId === example.id ? <CheckCircle2 size={16} /> : <Copy size={16} />}
                    <span className="text-sm font-medium">{copiedId === example.id ? 'Copied!' : 'Copy'}</span>
                  </button>
                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      handleDownload(example);
                    }}
                    className="flex-1 flex items-center justify-center gap-2 px-3 py-2 bg-gradient-to-r from-blue-600 to-cyan-600 text-white rounded-lg hover:from-blue-700 hover:to-cyan-700 transition-all duration-200"
                  >
                    <Download size={16} />
                    <span className="text-sm font-medium">Download</span>
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {selectedExample && (
        <div className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center p-4" onClick={() => setSelectedExample(null)}>
          <div className="bg-white dark:bg-gray-800 rounded-2xl shadow-2xl w-full max-w-4xl max-h-[90vh] flex flex-col overflow-hidden border border-gray-200 dark:border-gray-700" onClick={(e) => e.stopPropagation()}>
            <div className="flex items-center justify-between p-6 border-b border-gray-200 dark:border-gray-700">
              <div>
                <h2 className="text-2xl font-bold text-gray-900 dark:text-gray-100">
                  {selectedExample.title}
                </h2>
                <p className="text-sm text-gray-600 dark:text-gray-400 mt-1">
                  {selectedExample.description}
                </p>
              </div>
              <button
                onClick={() => setSelectedExample(null)}
                className="p-2 rounded-lg hover:bg-gray-100 dark:hover:bg-gray-700 transition-colors"
              >
                <X size={20} className="text-gray-600 dark:text-gray-400" />
              </button>
            </div>

            <div className="flex-1 overflow-y-auto p-6">
              <pre className="bg-gray-50 dark:bg-gray-900 border border-gray-200 dark:border-gray-700 rounded-xl p-6 overflow-x-auto font-mono text-sm text-gray-900 dark:text-gray-100">
                <code>{selectedExample.yaml}</code>
              </pre>
            </div>

            <div className="flex items-center justify-end gap-2 p-6 border-t border-gray-200 dark:border-gray-700 bg-gray-50 dark:bg-gray-900/50">
              <button
                onClick={() => handleCopy(selectedExample.id, selectedExample.yaml)}
                className="flex items-center gap-2 px-4 py-2 bg-gray-100 dark:bg-gray-700 text-gray-700 dark:text-gray-300 rounded-lg hover:bg-gray-200 dark:hover:bg-gray-600 transition-all duration-200"
              >
                {copiedId === selectedExample.id ? <CheckCircle2 size={18} /> : <Copy size={18} />}
                <span className="text-sm font-medium">{copiedId === selectedExample.id ? 'Copied!' : 'Copy'}</span>
              </button>
              <button
                onClick={() => handleDownload(selectedExample)}
                className="flex items-center gap-2 px-4 py-2 bg-gradient-to-r from-blue-600 to-cyan-600 text-white rounded-lg hover:from-blue-700 hover:to-cyan-700 transition-all duration-200 shadow-lg shadow-blue-500/30"
              >
                <Download size={18} />
                <span className="text-sm font-medium">Download</span>
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
