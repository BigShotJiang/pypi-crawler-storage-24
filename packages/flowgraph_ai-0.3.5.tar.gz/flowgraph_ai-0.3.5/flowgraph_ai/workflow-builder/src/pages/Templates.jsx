import React from 'react';
import { Database, Zap, MessageSquare, Sparkles } from 'lucide-react';

const templates = [
  {
    id: 'single-field',
    icon: Database,
    color: 'blue',
    title: 'Single Field Collector',
    description: 'Collect one piece of information from the user with validation',
    code: `collect_data:
  type: data_collector
  role: "You are a helpful assistant."
  initial_message: "Please provide [field name]"
  field: field_name
  description: "Description of what to collect"
  max_retry: 3
  next: next_node
  validation:
    method: regex
    pattern: "^[A-Z0-9-]+$"`
  },
  {
    id: 'multi-field',
    icon: Database,
    color: 'blue',
    title: 'Multi Field Collector',
    description: 'Collect multiple fields in one interaction',
    code: `collect_data:
  type: data_collector
  role: "You are a helpful assistant."
  initial_message: "Please provide your information"
  max_retry: 3
  next: next_node
  fields:
    - field: first_field
      description: "First field description"
    - field: second_field
      description: "Second field description"
      validation:
        method: regex
        pattern: "pattern_here"`
  },
  {
    id: 'action-routes',
    icon: Zap,
    color: 'orange',
    title: 'Action with Routes',
    description: 'Execute business logic with conditional routing',
    code: `process_action:
  type: custom_action
  method: "actions.module.method_name"
  result_field: action_result
  routes:
    - value: "success"
      next: success_node
    - value: "error"
      next: error_node
    - default: default_node`
  },
  {
    id: 'response-template',
    icon: MessageSquare,
    color: 'green',
    title: 'Response with Template',
    description: 'Send formatted responses using state variables',
    code: `send_response:
  type: response
  output_field: output
  error_field: error
  template: "Thank you! Your {{state.field_name}} has been processed. Result: {{state.result}}"`
  },
  {
    id: 'validation-regex',
    icon: Sparkles,
    color: 'cyan',
    title: 'Regex Validation',
    description: 'Validate input using regular expressions',
    code: `validation:
  method: regex
  pattern: "^[A-Z]{2}-[0-9]{5}$"

# Common patterns:
# Email: ^[\\w.-]+@[\\w.-]+\\.\\w+$
# Phone: ^\\+?[1-9]\\d{1,14}$
# Date: ^\\d{4}-\\d{2}-\\d{2}$
# SR Number: ^SR-[0-9]{5}$`
  },
  {
    id: 'validation-custom',
    icon: Sparkles,
    color: 'cyan',
    title: 'Custom Validation',
    description: 'Use Python functions for complex validation',
    code: `validation:
  method: "validations.module.function_name"

# Example validation function:
# def validate_sr(value: str) -> tuple[bool, str]:
#     if value.startswith("SR-"):
#         return True, ""
#     return False, "Must start with SR-"`
  }
];

export default function Templates() {
  const [copiedId, setCopiedId] = React.useState(null);

  const handleCopy = (id, code) => {
    navigator.clipboard.writeText(code);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  const getColorClasses = (color) => {
    const colors = {
      blue: 'from-blue-500 to-cyan-500',
      orange: 'from-orange-500 to-amber-500',
      green: 'from-green-500 to-emerald-500',
      cyan: 'from-cyan-500 to-blue-500',
    };
    return colors[color] || colors.blue;
  };

  return (
    <div className="p-8">
      <div className="max-w-7xl mx-auto">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900 dark:text-gray-100 mb-2">
            Node Templates
          </h1>
          <p className="text-gray-600 dark:text-gray-400">
            Copy and paste these templates into your workflow YAML files
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {templates.map((template) => {
            const Icon = template.icon;
            return (
              <div
                key={template.id}
                className="bg-white dark:bg-gray-800 rounded-xl border-2 border-gray-200 dark:border-gray-700 overflow-hidden hover:border-gray-300 dark:hover:border-gray-600 transition-all duration-200 hover:shadow-lg"
              >
                <div className={`h-2 bg-gradient-to-r ${getColorClasses(template.color)}`} />

                <div className="p-6">
                  <div className="flex items-start gap-4 mb-4">
                    <div className={`p-3 rounded-xl bg-gradient-to-br ${getColorClasses(template.color)} shadow-lg`}>
                      <Icon size={24} className="text-white" />
                    </div>
                    <div className="flex-1">
                      <h3 className="text-lg font-bold text-gray-900 dark:text-gray-100 mb-1">
                        {template.title}
                      </h3>
                      <p className="text-sm text-gray-600 dark:text-gray-400">
                        {template.description}
                      </p>
                    </div>
                  </div>

                  <div className="bg-gray-50 dark:bg-gray-900 rounded-lg p-4 mb-4 overflow-x-auto">
                    <pre className="font-mono text-xs text-gray-900 dark:text-gray-100">
                      <code>{template.code}</code>
                    </pre>
                  </div>

                  <button
                    onClick={() => handleCopy(template.id, template.code)}
                    className="w-full flex items-center justify-center gap-2 px-4 py-2 bg-gradient-to-r from-blue-600 to-cyan-600 text-white rounded-lg hover:from-blue-700 hover:to-cyan-700 transition-all duration-200 shadow-lg shadow-blue-500/30"
                  >
                    {copiedId === template.id ? (
                      <>
                        <Sparkles size={16} />
                        <span className="text-sm font-medium">Copied!</span>
                      </>
                    ) : (
                      <>
                        <MessageSquare size={16} />
                        <span className="text-sm font-medium">Copy Template</span>
                      </>
                    )}
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}
