import React, { useState, useCallback, useRef } from 'react';
import ReactFlow, {
  addEdge,
  Background,
  Controls,
  MiniMap,
  useNodesState,
  useEdgesState,
  MarkerType,
} from 'reactflow';
import 'reactflow/dist/style.css';

import DataCollectorNode from '../nodes/DataCollectorNode';
import CustomActionNode from '../nodes/CustomActionNode';
import ResponseNode from '../nodes/ResponseNode';
import Sidebar from '../components/Sidebar';
import ConfigPanel from '../components/ConfigPanel';
import YAMLPreview from '../components/YAMLPreview';
import FolderTree from '../components/FolderTree';
import GlobalSettingsPanel from '../components/GlobalSettingsPanel';
import StateEditor from '../components/StateEditor';
import EdgeEditPanel from '../components/EdgeEditPanel';
import LabeledEdge from '../edges/LabeledEdge';
import { exportToYAML } from '../utils/yamlExport';
import { Download, Eye, FileText, Save, Settings, Database, Upload } from 'lucide-react';
import useStore from '../store';
import { parseFromYAML } from '../utils/yamlImport';

const nodeTypes = {
  dataCollector: DataCollectorNode,
  customAction: CustomActionNode,
  response: ResponseNode,
};

const edgeTypes = {
  default: LabeledEdge,
  smoothstep: LabeledEdge,
};

let nodeId = 0;
const getId = () => `node_${nodeId++}`;


export default function Builder() {
  const [nodes, setNodes, onNodesChange] = useNodesState([]);
  const [edges, setEdges, onEdgesChange] = useEdgesState([]);
  const [selectedNode, setSelectedNode] = useState(null);
  const [selectedEdge, setSelectedEdge] = useState(null);
  const [showYAMLPreview, setShowYAMLPreview] = useState(false);
  const [showGlobalSettings, setShowGlobalSettings] = useState(false);
  const [showStateEditor, setShowStateEditor] = useState(false);
  const [isAutoSaveEnabled, setIsAutoSaveEnabled] = useState(false);
  
  const activeWorkflowId = useStore(state => state.activeWorkflowId);
  const workflows = useStore(state => state.workflows);
  const saveWorkflow = useStore(state => state.saveWorkflow);
  const setActiveWorkflow = useStore(state => state.setActiveWorkflow);
  
  const activeWorkflow = workflows.find(w => w.id === activeWorkflowId) || null;

  const [workflowName, setWorkflowName] = useState(activeWorkflow?.name || 'new_workflow');
  const [workflowDescription, setWorkflowDescription] = useState(activeWorkflow?.description || '');
  const [stateFields, setStateFields] = useState(activeWorkflow?.stateFields || []);
  const [initialInputField, setInitialInputField] = useState(activeWorkflow?.initialInputField || 'user_message');
  
  const reactFlowWrapper = useRef(null);
  const fileInputRef = useRef(null);
  const [reactFlowInstance, setReactFlowInstance] = useState(null);

  // Load from store when active workflow changes
  React.useEffect(() => {
    if (activeWorkflow) {
      setNodes(activeWorkflow.nodes || []);
      setEdges(activeWorkflow.edges || []);
      setWorkflowName(activeWorkflow.name || 'new_workflow');
      setWorkflowDescription(activeWorkflow.description || '');
      setStateFields(activeWorkflow.stateFields || []);
      setInitialInputField(activeWorkflow.initialInputField || 'user_message');
    } else {
      setNodes([]);
      setEdges([]);
      setWorkflowName('new_workflow');
      setWorkflowDescription('');
      setStateFields([]);
      setInitialInputField('user_message');
    }
  }, [activeWorkflowId]);

  // Auto-save effect
  React.useEffect(() => {
    if (isAutoSaveEnabled && activeWorkflowId) {
      const timer = setTimeout(() => {
        saveWorkflow({
          id: activeWorkflowId,
          name: workflowName,
          description: workflowDescription,
          nodes,
          edges,
          folderId: activeWorkflow?.folderId || 'root',
          stateFields,
          initialInputField,
        });
      }, 1000);
      return () => clearTimeout(timer);
    }
  }, [nodes, edges, workflowName, workflowDescription, stateFields, initialInputField, isAutoSaveEnabled, activeWorkflowId, saveWorkflow]);

  const handleSave = () => {
    saveWorkflow({
      id: activeWorkflowId,
      name: workflowName,
      description: workflowDescription,
      nodes,
      edges,
      folderId: activeWorkflow?.folderId || 'root',
      stateFields,
      initialInputField,
    });
  };

  const handleSelectWorkflow = (id) => {
    if (id === 'new') {
      setActiveWorkflow(null);
      setNodes([]);
      setEdges([]);
      setWorkflowName('new_workflow');
      setWorkflowDescription('');
      setStateFields([]);
      setInitialInputField('user_message');
    } else {
      setActiveWorkflow(id);
    }
  };

  const onConnect = useCallback((params) => {
    setEdges((eds) =>
      addEdge(
        {
          ...params,
          type: 'default',
          animated: true,
          markerEnd: {
            type: MarkerType.ArrowClosed,
          },
        },
        eds
      )
    );
  }, []);

  const onDragOver = useCallback((event) => {
    event.preventDefault();
    event.dataTransfer.dropEffect = 'move';
  }, []);

  const onDrop = useCallback(
    (event) => {
      event.preventDefault();

      const type = event.dataTransfer.getData('application/reactflow');
      if (!type) return;

      const position = reactFlowInstance.screenToFlowPosition({
        x: event.clientX,
        y: event.clientY,
      });

      const newNode = {
        id: getId(),
        type,
        position,
        data: {
          label: `New ${type}`,
          ...(type === 'dataCollector' && {
            field: '',
            description: '',
            max_retry: 3,
            role: '',
            initial_message: '',
            on_max_retry: '',
            humanize: false,
            hallucination_check: true,
          }),
          ...(type === 'customAction' && {
            method: '',
            result_field: 'action_result',
            routes: [],
          }),
          ...(type === 'response' && {
            output_field: 'output',
            error_field: 'error',
            template: '',
          }),
        },
      };

      setNodes((nds) => nds.concat(newNode));
    },
    [reactFlowInstance]
  );

  const onNodeClick = useCallback((event, node) => {
    setSelectedNode(node);
    setSelectedEdge(null);
  }, []);

  const onEdgeClick = useCallback((event, edge) => {
    setSelectedEdge(edge);
    setSelectedNode(null);
  }, []);

  const onPaneClick = useCallback(() => {
    setSelectedNode(null);
    setSelectedEdge(null);
  }, []);

  const onNodeUpdate = useCallback((nodeId, newData) => {
    setNodes((nds) =>
      nds.map((node) => {
        if (node.id === nodeId) {
          return {
            ...node,
            data: { ...node.data, ...newData },
          };
        }
        return node;
      })
    );
  }, []);

  const onEdgeUpdate = useCallback((edgeId, newData) => {
    setEdges((eds) =>
      eds.map((edge) => {
        if (edge.id === edgeId) {
          return {
            ...edge,
            data: { ...edge.data, ...newData },
          };
        }
        return edge;
      })
    );
  }, []);

  const onEdgeDelete = useCallback((edgeId) => {
    setEdges((eds) => eds.filter(e => e.id !== edgeId));
    setSelectedEdge(null);
  }, []);

  const handleExportYAML = () => {
    const yamlContent = exportToYAML(nodes, edges, workflowName, workflowDescription, activeWorkflow?.globalConfig, stateFields, initialInputField);
    const blob = new Blob([yamlContent], { type: 'text/yaml' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `${workflowName}.yaml`;
    link.click();
    URL.revokeObjectURL(url);
  };

  const handleImportYAML = (event) => {
    const file = event.target.files[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (e) => {
      try {
        const { nodes: parsedNodes, edges: parsedEdges, metadata } = parseFromYAML(e.target.result);
        setNodes(parsedNodes);
        setEdges(parsedEdges);
        setWorkflowName(metadata.workflow);
        setWorkflowDescription(metadata.description);
        setStateFields(metadata.stateFields || []);
        setInitialInputField(metadata.initialInputField || 'user_message');
        setActiveWorkflow(null);
      } catch (err) {
        alert("Failed to parse YAML: " + err.message);
      }
    };
    reader.readAsText(file);
    event.target.value = null;
  };

  return (
    <div className="flex h-[calc(100vh-4rem)]">
      <FolderTree onSelectWorkflow={handleSelectWorkflow} />
      <Sidebar />

      <div className="flex-1 flex flex-col">
        <header className="bg-white dark:bg-gray-800 border-b border-gray-200 dark:border-gray-700 px-6 py-3 transition-colors">
          <div className="flex flex-wrap items-center justify-between gap-4">
            <div className="flex flex-wrap items-center gap-3 flex-1 min-w-[300px]">
              <div className="flex items-center gap-2 shrink-0">
                <FileText size={20} className="text-blue-600 dark:text-blue-400" />
                <input
                  type="text"
                  value={workflowName}
                  onChange={(e) => setWorkflowName(e.target.value)}
                  className="text-lg font-bold text-gray-900 dark:text-gray-100 bg-transparent border-b-2 border-transparent hover:border-gray-300 dark:hover:border-gray-600 focus:border-blue-500 dark:focus:border-blue-400 focus:outline-none px-2 py-1 transition-colors w-48"
                  placeholder="Workflow Name"
                />
              </div>
              <input
                type="text"
                value={workflowDescription}
                onChange={(e) => setWorkflowDescription(e.target.value)}
                className="flex-1 min-w-[200px] text-sm text-gray-600 dark:text-gray-400 bg-transparent border-b border-transparent hover:border-gray-300 dark:hover:border-gray-600 focus:border-blue-500 dark:focus:border-blue-400 focus:outline-none px-2 py-1 transition-colors"
                placeholder="Add a description..."
              />
            </div>
            <div className="flex flex-wrap items-center gap-2 shrink-0">
              <button
                onClick={() => setShowStateEditor(true)}
                className="flex items-center gap-1.5 px-3 py-2 bg-cyan-50 dark:bg-cyan-900/20 text-cyan-700 dark:text-cyan-300 rounded-lg hover:bg-cyan-100 dark:hover:bg-cyan-900/40 transition-all duration-200 text-sm font-medium"
                title="Edit state fields"
              >
                <Database size={16} />
                State
              </button>
              <button
                onClick={() => setShowGlobalSettings(true)}
                className="flex items-center gap-1.5 px-3 py-2 bg-gray-100 dark:bg-gray-700 text-gray-700 dark:text-gray-300 rounded-lg hover:bg-gray-200 dark:hover:bg-gray-600 transition-all duration-200 text-sm font-medium"
              >
                <Settings size={16} />
                Settings
              </button>
              <button
                onClick={() => fileInputRef.current?.click()}
                className="flex items-center gap-1.5 px-3 py-2 bg-gray-100 dark:bg-gray-700 text-gray-700 dark:text-gray-300 rounded-lg hover:bg-gray-200 dark:hover:bg-gray-600 transition-all duration-200 text-sm font-medium"
              >
                <Upload size={16} />
                Import
              </button>
              <input 
                type="file" 
                ref={fileInputRef} 
                accept=".yaml,.yml" 
                className="hidden" 
                onChange={handleImportYAML} 
              />
              <button
                onClick={() => setIsAutoSaveEnabled(!isAutoSaveEnabled)}
                className={`flex items-center gap-1.5 px-3 py-2 rounded-lg transition-all duration-200 text-sm font-medium ${isAutoSaveEnabled ? 'bg-indigo-100 text-indigo-700 dark:bg-indigo-900/50 dark:text-indigo-400 ring-2 ring-indigo-500' : 'bg-gray-100 dark:bg-gray-700 text-gray-700 dark:text-gray-300 hover:bg-gray-200 dark:hover:bg-gray-600'}`}
                title="Toggle Auto-save"
              >
                <Database size={16} />
                Auto-Save: {isAutoSaveEnabled ? 'ON' : 'OFF'}
              </button>
              <button
                onClick={handleSave}
                className="flex items-center gap-1.5 px-3 py-2 bg-indigo-50 dark:bg-indigo-900/30 text-indigo-700 dark:text-indigo-300 rounded-lg hover:bg-indigo-100 dark:hover:bg-indigo-900/50 transition-all duration-200 text-sm font-medium"
              >
                <Save size={16} />
                Save
              </button>
              <button
                onClick={() => setShowYAMLPreview(true)}
                className="flex items-center gap-1.5 px-3 py-2 bg-gray-100 dark:bg-gray-700 text-gray-700 dark:text-gray-300 rounded-lg hover:bg-gray-200 dark:hover:bg-gray-600 transition-all duration-200 text-sm font-medium"
                disabled={nodes.length === 0}
              >
                <Eye size={16} />
                Preview
              </button>
              <button
                onClick={handleExportYAML}
                className="flex items-center gap-1.5 px-3 py-2 bg-gradient-to-r from-blue-600 to-cyan-600 text-white rounded-lg hover:from-blue-700 hover:to-cyan-700 transition-all duration-200 shadow-lg shadow-blue-500/30 disabled:opacity-50 disabled:cursor-not-allowed disabled:shadow-none text-sm font-medium"
                disabled={nodes.length === 0}
              >
                <Download size={16} />
                Export
              </button>
            </div>
          </div>
        </header>

        <div className="flex-1" ref={reactFlowWrapper}>
          <ReactFlow
            nodes={nodes}
            edges={edges}
            onNodesChange={onNodesChange}
            onEdgesChange={onEdgesChange}
            onConnect={onConnect}
            onInit={setReactFlowInstance}
            onDrop={onDrop}
            onDragOver={onDragOver}
            onNodeClick={onNodeClick}
            onEdgeClick={onEdgeClick}
            onPaneClick={onPaneClick}
            nodeTypes={nodeTypes}
            edgeTypes={edgeTypes}
            fitView
            className="bg-gray-50 dark:bg-gray-900"
          >
            <Background
              color="#9ca3af"
              gap={16}
              className="dark:opacity-20"
            />
            <Controls className="bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700 rounded-lg" />
            <MiniMap
              nodeColor={(node) => {
                switch (node.type) {
                  case 'dataCollector':
                    return '#3b82f6';
                  case 'customAction':
                    return '#f97316';
                  case 'response':
                    return '#22c55e';
                  default:
                    return '#6b7280';
                }
              }}
              className="border border-gray-200 dark:border-gray-700 rounded-lg bg-white dark:bg-gray-800"
            />
          </ReactFlow>
        </div>
      </div>

      {selectedNode && (
        <ConfigPanel
          node={selectedNode}
          onUpdate={onNodeUpdate}
          onClose={() => setSelectedNode(null)}
        />
      )}

      {selectedEdge && (
        <EdgeEditPanel
          edge={selectedEdge}
          sourceNode={nodes.find(n => n.id === selectedEdge.source)}
          targetNode={nodes.find(n => n.id === selectedEdge.target)}
          onUpdate={onEdgeUpdate}
          onDelete={onEdgeDelete}
          onClose={() => setSelectedEdge(null)}
        />
      )}

      {showGlobalSettings && (
        <GlobalSettingsPanel onClose={() => setShowGlobalSettings(false)} />
      )}

      {showStateEditor && (
        <StateEditor
          stateFields={stateFields}
          onUpdate={setStateFields}
          onClose={() => setShowStateEditor(false)}
        />
      )}

      {showYAMLPreview && (
        <YAMLPreview
          nodes={nodes}
          edges={edges}
          workflowName={workflowName}
          workflowDescription={workflowDescription}
          globalConfig={activeWorkflow?.globalConfig}
          stateFields={stateFields}
          initialInputField={initialInputField}
          onClose={() => setShowYAMLPreview(false)}
          onExport={handleExportYAML}
        />
      )}
    </div>
  );
}
