import React, { useState } from 'react';
import { getBezierPath, EdgeLabelRenderer, BaseEdge } from 'reactflow';

export default function LabeledEdge({
  id,
  sourceX,
  sourceY,
  targetX,
  targetY,
  sourcePosition,
  targetPosition,
  data,
  style = {},
  markerEnd,
  selected,
}) {
  const [edgePath, labelX, labelY] = getBezierPath({
    sourceX,
    sourceY,
    sourcePosition,
    targetX,
    targetY,
    targetPosition,
  });

  const label = data?.label || '';
  const edgeType = data?.edgeType || 'default'; // 'default', 'condition', 'error', 'success'

  const typeColors = {
    default: {
      stroke: selected ? '#3b82f6' : '#94a3b8',
      bg: 'bg-white dark:bg-gray-800',
      text: 'text-gray-700 dark:text-gray-200',
      border: 'border-gray-300 dark:border-gray-600',
      badge: 'bg-gray-100 dark:bg-gray-700',
    },
    condition: {
      stroke: selected ? '#8b5cf6' : '#a78bfa',
      bg: 'bg-violet-50 dark:bg-violet-900/40',
      text: 'text-violet-700 dark:text-violet-200',
      border: 'border-violet-300 dark:border-violet-600',
      badge: 'bg-violet-100 dark:bg-violet-800/50',
    },
    error: {
      stroke: selected ? '#ef4444' : '#f87171',
      bg: 'bg-red-50 dark:bg-red-900/40',
      text: 'text-red-700 dark:text-red-200',
      border: 'border-red-300 dark:border-red-600',
      badge: 'bg-red-100 dark:bg-red-800/50',
    },
    success: {
      stroke: selected ? '#22c55e' : '#4ade80',
      bg: 'bg-green-50 dark:bg-green-900/40',
      text: 'text-green-700 dark:text-green-200',
      border: 'border-green-300 dark:border-green-600',
      badge: 'bg-green-100 dark:bg-green-800/50',
    },
  };

  const colors = typeColors[edgeType] || typeColors.default;

  return (
    <>
      <BaseEdge
        path={edgePath}
        markerEnd={markerEnd}
        style={{
          ...style,
          stroke: colors.stroke,
          strokeWidth: selected ? 2.5 : 2,
          strokeDasharray: edgeType === 'error' ? '5,5' : undefined,
        }}
      />
      <EdgeLabelRenderer>
        <div
          className="nodrag nopan"
          style={{
            position: 'absolute',
            transform: `translate(-50%, -50%) translate(${labelX}px,${labelY}px)`,
            pointerEvents: 'all',
          }}
        >
          {label ? (
            <div
              className={`px-2.5 py-1 rounded-full border text-xs font-semibold shadow-sm cursor-pointer transition-all hover:scale-105 ${colors.bg} ${colors.text} ${colors.border}`}
              title="Click edge to edit"
            >
              {edgeType === 'condition' && <span className="mr-1">⚡</span>}
              {edgeType === 'error' && <span className="mr-1">⚠️</span>}
              {edgeType === 'success' && <span className="mr-1">✓</span>}
              {label}
            </div>
          ) : selected ? (
            <div
              className="px-2 py-0.5 rounded-full border border-dashed border-gray-400 dark:border-gray-500 text-[10px] text-gray-400 dark:text-gray-500 bg-white dark:bg-gray-800"
            >
              click to add label
            </div>
          ) : null}
        </div>
      </EdgeLabelRenderer>
    </>
  );
}
