import React, { useState } from 'react';
import { X, Plus, Trash2, Database, Type, Hash, List, BookOpen, ToggleLeft } from 'lucide-react';

const STATE_TYPES = [
  { value: 'str', label: 'String', icon: Type, color: 'text-blue-500' },
  { value: 'int', label: 'Integer', icon: Hash, color: 'text-green-500' },
  { value: 'list', label: 'List', icon: List, color: 'text-purple-500' },
  { value: 'dict', label: 'Dict', icon: BookOpen, color: 'text-orange-500' },
  { value: 'bool', label: 'Boolean', icon: ToggleLeft, color: 'text-pink-500' },
];

export default function StateEditor({ stateFields, onUpdate, onClose }) {
  const [newName, setNewName] = useState('');
  const [newType, setNewType] = useState('str');

  const inputClasses = "w-full px-3 py-2 bg-white dark:bg-gray-700 border border-gray-300 dark:border-gray-600 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 dark:focus:ring-blue-400 text-gray-900 dark:text-gray-100 placeholder-gray-500 dark:placeholder-gray-400 transition-colors text-sm";

  const handleAdd = (e) => {
    e.preventDefault();
    const name = newName.trim().replace(/\s+/g, '_').toLowerCase();
    if (!name) return;
    if (stateFields.some(f => f.name === name)) return;
    onUpdate([...stateFields, { name, type: newType }]);
    setNewName('');
    setNewType('str');
  };

  const handleRemove = (index) => {
    const updated = [...stateFields];
    updated.splice(index, 1);
    onUpdate(updated);
  };

  const handleTypeChange = (index, type) => {
    const updated = [...stateFields];
    updated[index] = { ...updated[index], type };
    onUpdate(updated);
  };

  return (
    <div className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center p-4">
      <div className="bg-white dark:bg-gray-800 rounded-2xl shadow-2xl w-full max-w-lg max-h-[80vh] flex flex-col overflow-hidden border border-gray-200 dark:border-gray-700">
        
        {/* Header */}
        <div className="flex items-center justify-between p-5 border-b border-gray-200 dark:border-gray-700">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-gradient-to-br from-blue-500 to-cyan-500 rounded-lg">
              <Database size={18} className="text-white" />
            </div>
            <div>
              <h2 className="text-lg font-bold text-gray-900 dark:text-gray-100">State Fields</h2>
              <p className="text-xs text-gray-500 dark:text-gray-400">Define workflow state variables</p>
            </div>
          </div>
          <button onClick={onClose} className="p-2 rounded-lg hover:bg-gray-100 dark:hover:bg-gray-700 transition-colors">
            <X size={20} className="text-gray-500 dark:text-gray-400" />
          </button>
        </div>

        {/* Auto-injected fields info */}
        <div className="px-5 pt-4">
          <div className="bg-blue-50 dark:bg-blue-900/20 border border-blue-200 dark:border-blue-800 rounded-lg p-3">
            <p className="text-xs text-blue-700 dark:text-blue-300 font-medium mb-1">Auto-injected fields (always available):</p>
            <div className="flex flex-wrap gap-1.5">
              {['user_message', 'user_language', 'output', 'error', 'messages'].map(f => (
                <span key={f} className="text-xs font-mono bg-blue-100 dark:bg-blue-800/40 text-blue-600 dark:text-blue-300 px-2 py-0.5 rounded">
                  {f}
                </span>
              ))}
            </div>
          </div>
        </div>

        {/* Fields list */}
        <div className="flex-1 overflow-y-auto p-5 space-y-2">
          {stateFields.length === 0 && (
            <div className="text-center py-8 text-gray-400 dark:text-gray-500">
              <Database size={32} className="mx-auto mb-2 opacity-50" />
              <p className="text-sm">No custom fields yet</p>
              <p className="text-xs">Fields from nodes are auto-added on export</p>
            </div>
          )}
          {stateFields.map((field, idx) => (
            <div key={idx} className="flex items-center gap-2 bg-gray-50 dark:bg-gray-700/30 border border-gray-200 dark:border-gray-600 rounded-lg px-3 py-2">
              <span className="flex-1 font-mono text-sm text-gray-900 dark:text-gray-100">{field.name}</span>
              <select
                value={field.type}
                onChange={(e) => handleTypeChange(idx, e.target.value)}
                className="text-xs bg-white dark:bg-gray-700 border border-gray-300 dark:border-gray-600 rounded px-2 py-1 text-gray-700 dark:text-gray-300 focus:outline-none focus:ring-1 focus:ring-blue-500"
              >
                {STATE_TYPES.map(t => (
                  <option key={t.value} value={t.value}>{t.label}</option>
                ))}
              </select>
              <button onClick={() => handleRemove(idx)} className="p-1 text-gray-400 hover:text-red-500 dark:hover:text-red-400 transition-colors">
                <Trash2 size={14} />
              </button>
            </div>
          ))}
        </div>

        {/* Add new field */}
        <form onSubmit={handleAdd} className="p-5 border-t border-gray-200 dark:border-gray-700 bg-gray-50 dark:bg-gray-900/50">
          <div className="flex items-center gap-2">
            <input
              type="text"
              value={newName}
              onChange={(e) => setNewName(e.target.value)}
              className={inputClasses + ' flex-1'}
              placeholder="field_name"
            />
            <select
              value={newType}
              onChange={(e) => setNewType(e.target.value)}
              className="text-sm bg-white dark:bg-gray-700 border border-gray-300 dark:border-gray-600 rounded-lg px-3 py-2 text-gray-700 dark:text-gray-300 focus:outline-none focus:ring-1 focus:ring-blue-500"
            >
              {STATE_TYPES.map(t => (
                <option key={t.value} value={t.value}>{t.label}</option>
              ))}
            </select>
            <button
              type="submit"
              disabled={!newName.trim()}
              className="flex items-center gap-1 px-4 py-2 bg-gradient-to-r from-blue-600 to-cyan-600 text-white rounded-lg hover:from-blue-700 hover:to-cyan-700 transition-all shadow-lg shadow-blue-500/30 disabled:opacity-50 disabled:cursor-not-allowed disabled:shadow-none text-sm font-medium"
            >
              <Plus size={16} /> Add
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
