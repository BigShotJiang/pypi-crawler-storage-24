import React, { useMemo } from 'react';
import { X, Download, Copy, CheckCircle2, AlertTriangle, AlertCircle } from 'lucide-react';
import { exportToYAML, validateWorkflow } from '../utils/yamlExport';

export default function YAMLPreview({ nodes, edges, workflowName, workflowDescription, globalConfig, stateFields, initialInputField, onClose, onExport }) {
  const [copied, setCopied] = React.useState(false);

  const validation = useMemo(() => {
    return validateWorkflow(nodes, edges);
  }, [nodes, edges]);

  const yamlContent = useMemo(() => {
    // If we're using Zustand, the Builder component needs to pass down globalConfig
    // We assume it's passed via a prop named globalConfig
    return exportToYAML(nodes, edges, workflowName, workflowDescription, globalConfig, stateFields, initialInputField);
  }, [nodes, edges, workflowName, workflowDescription, globalConfig, stateFields, initialInputField]);

  const handleCopy = () => {
    navigator.clipboard.writeText(yamlContent);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center p-4">
      <div className="bg-white dark:bg-gray-800 rounded-2xl shadow-2xl w-full max-w-4xl max-h-[90vh] flex flex-col overflow-hidden border border-gray-200 dark:border-gray-700">
        <div className="flex items-center justify-between p-6 border-b border-gray-200 dark:border-gray-700">
          <div>
            <h2 className="text-2xl font-bold text-gray-900 dark:text-gray-100">
              YAML Preview
            </h2>
            <p className="text-sm text-gray-600 dark:text-gray-400 mt-1">
              Review your workflow configuration
            </p>
          </div>
          <button
            onClick={onClose}
            className="p-2 rounded-lg hover:bg-gray-100 dark:hover:bg-gray-700 transition-colors"
          >
            <X size={20} className="text-gray-600 dark:text-gray-400" />
          </button>
        </div>

        <div className="flex-1 overflow-y-auto p-6">
          {(validation.errors.length > 0 || validation.warnings.length > 0) && (
            <div className="mb-4 space-y-2">
              {validation.errors.length > 0 && (
                <div className="bg-red-50 dark:bg-red-900/20 border-2 border-red-200 dark:border-red-800 rounded-xl p-4">
                  <div className="flex items-center gap-2 mb-2">
                    <AlertCircle size={18} className="text-red-600 dark:text-red-400" />
                    <h3 className="font-bold text-red-900 dark:text-red-300">Validation Errors</h3>
                  </div>
                  <ul className="space-y-1 text-sm text-red-800 dark:text-red-300">
                    {validation.errors.map((error, idx) => (
                      <li key={idx} className="flex items-start gap-2">
                        <span className="text-red-500 dark:text-red-400">•</span>
                        <span>{error}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              )}

              {validation.warnings.length > 0 && (
                <div className="bg-yellow-50 dark:bg-yellow-900/20 border-2 border-yellow-200 dark:border-yellow-800 rounded-xl p-4">
                  <div className="flex items-center gap-2 mb-2">
                    <AlertTriangle size={18} className="text-yellow-600 dark:text-yellow-400" />
                    <h3 className="font-bold text-yellow-900 dark:text-yellow-300">Warnings</h3>
                  </div>
                  <ul className="space-y-1 text-sm text-yellow-800 dark:text-yellow-300">
                    {validation.warnings.map((warning, idx) => (
                      <li key={idx} className="flex items-start gap-2">
                        <span className="text-yellow-500 dark:text-yellow-400">•</span>
                        <span>{warning}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              )}
            </div>
          )}

          <div className="relative">
            <pre className="bg-gray-50 dark:bg-gray-900 border border-gray-200 dark:border-gray-700 rounded-xl p-6 overflow-x-auto font-mono text-sm text-gray-900 dark:text-gray-100">
              <code>{yamlContent}</code>
            </pre>
          </div>
        </div>

        <div className="flex items-center justify-between gap-3 p-6 border-t border-gray-200 dark:border-gray-700 bg-gray-50 dark:bg-gray-900/50">
          <div className="flex items-center gap-4">
            <div className="text-sm text-gray-600 dark:text-gray-400">
              {nodes.length} nodes, {edges.length} connections
            </div>
            {validation.isValid && (
              <div className="flex items-center gap-1 text-sm text-green-600 dark:text-green-400">
                <CheckCircle2 size={16} />
                <span className="font-medium">Valid</span>
              </div>
            )}
          </div>
          <div className="flex gap-2">
            <button
              onClick={handleCopy}
              className="flex items-center gap-2 px-4 py-2 bg-gray-100 dark:bg-gray-700 text-gray-700 dark:text-gray-300 rounded-lg hover:bg-gray-200 dark:hover:bg-gray-600 transition-all duration-200"
            >
              {copied ? <CheckCircle2 size={18} /> : <Copy size={18} />}
              <span className="text-sm font-medium">{copied ? 'Copied!' : 'Copy'}</span>
            </button>
            <button
              onClick={onExport}
              disabled={!validation.isValid}
              className="flex items-center gap-2 px-4 py-2 bg-gradient-to-r from-blue-600 to-cyan-600 text-white rounded-lg hover:from-blue-700 hover:to-cyan-700 transition-all duration-200 shadow-lg shadow-blue-500/30 disabled:opacity-50 disabled:cursor-not-allowed disabled:shadow-none"
            >
              <Download size={18} />
              <span className="text-sm font-medium">Export</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
