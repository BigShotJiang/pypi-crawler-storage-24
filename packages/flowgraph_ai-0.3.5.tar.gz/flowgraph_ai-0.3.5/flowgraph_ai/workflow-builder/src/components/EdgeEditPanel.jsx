import React, { useState, useEffect, useRef } from 'react';
import { X, GitBranch, Tag } from 'lucide-react';

const EDGE_TYPES = [
  { value: 'default', label: 'Default', icon: '→', color: 'bg-gray-100 dark:bg-gray-700 text-gray-700 dark:text-gray-300 border-gray-300 dark:border-gray-600' },
  { value: 'condition', label: 'Condition', icon: '⚡', color: 'bg-violet-100 dark:bg-violet-900/40 text-violet-700 dark:text-violet-200 border-violet-300 dark:border-violet-600' },
  { value: 'success', label: 'Success', icon: '✓', color: 'bg-green-100 dark:bg-green-900/40 text-green-700 dark:text-green-200 border-green-300 dark:border-green-600' },
  { value: 'error', label: 'Error / Fallback', icon: '⚠️', color: 'bg-red-100 dark:bg-red-900/40 text-red-700 dark:text-red-200 border-red-300 dark:border-red-600' },
];

export default function EdgeEditPanel({ edge, sourceNode, targetNode, onUpdate, onDelete, onClose }) {
  const [label, setLabel] = useState(edge?.data?.label || '');
  const [edgeType, setEdgeType] = useState(edge?.data?.edgeType || 'default');
  const inputRef = useRef(null);

  useEffect(() => {
    setLabel(edge?.data?.label || '');
    setEdgeType(edge?.data?.edgeType || 'default');
    setTimeout(() => inputRef.current?.focus(), 100);
  }, [edge]);

  if (!edge) return null;

  const handleSave = () => {
    onUpdate(edge.id, { ...edge.data, label, edgeType });
    onClose();
  };

  const handleKeyDown = (e) => {
    if (e.key === 'Enter') handleSave();
    if (e.key === 'Escape') onClose();
  };

  const sourceName = sourceNode?.data?.label || edge.source;
  const targetName = targetNode?.data?.label || edge.target;

  const inputClasses = "w-full px-3 py-2 bg-white dark:bg-gray-700 border border-gray-300 dark:border-gray-600 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 dark:focus:ring-blue-400 text-gray-900 dark:text-gray-100 placeholder-gray-500 dark:placeholder-gray-400 transition-colors text-sm";

  return (
    <div className="fixed bottom-6 left-1/2 -translate-x-1/2 z-50 animate-in fade-in slide-in-from-bottom-3">
      <div className="bg-white dark:bg-gray-800 rounded-2xl shadow-2xl border border-gray-200 dark:border-gray-700 w-[480px] overflow-hidden">
        {/* Header */}
        <div className="flex items-center justify-between px-4 py-3 bg-gray-50 dark:bg-gray-900/50 border-b border-gray-200 dark:border-gray-700">
          <div className="flex items-center gap-2">
            <GitBranch size={16} className="text-blue-500 dark:text-blue-400" />
            <span className="text-sm font-bold text-gray-900 dark:text-gray-100">Edge Connection</span>
          </div>
          <div className="flex items-center gap-2">
            <button
              onClick={() => { onDelete(edge.id); onClose(); }}
              className="text-xs px-2 py-1 text-red-600 dark:text-red-400 hover:bg-red-50 dark:hover:bg-red-900/30 rounded transition-colors"
            >
              Delete
            </button>
            <button onClick={onClose} className="p-1 text-gray-400 hover:text-gray-600 dark:hover:text-gray-300 rounded hover:bg-gray-200 dark:hover:bg-gray-700">
              <X size={16} />
            </button>
          </div>
        </div>

        <div className="p-4 space-y-4">
          {/* Connection info */}
          <div className="flex items-center gap-2 text-xs">
            <span className="px-2 py-1 bg-blue-100 dark:bg-blue-900/30 text-blue-700 dark:text-blue-300 rounded-md font-medium truncate max-w-[140px]">{sourceName}</span>
            <span className="text-gray-400 dark:text-gray-500">→</span>
            <span className="px-2 py-1 bg-blue-100 dark:bg-blue-900/30 text-blue-700 dark:text-blue-300 rounded-md font-medium truncate max-w-[140px]">{targetName}</span>
          </div>

          {/* Edge type selector */}
          <div>
            <label className="block text-xs font-semibold text-gray-600 dark:text-gray-400 mb-2 uppercase tracking-wide">Connection Type</label>
            <div className="grid grid-cols-4 gap-1.5">
              {EDGE_TYPES.map(t => (
                <button
                  key={t.value}
                  onClick={() => setEdgeType(t.value)}
                  className={`flex flex-col items-center gap-1 py-2 px-1 rounded-lg border text-xs font-medium transition-all ${
                    edgeType === t.value
                      ? `${t.color} ring-2 ring-blue-500 dark:ring-blue-400 ring-offset-1 dark:ring-offset-gray-800`
                      : 'border-gray-200 dark:border-gray-600 text-gray-500 dark:text-gray-400 hover:bg-gray-50 dark:hover:bg-gray-700/50'
                  }`}
                >
                  <span className="text-base">{t.icon}</span>
                  <span>{t.label}</span>
                </button>
              ))}
            </div>
          </div>

          {/* Label input */}
          <div>
            <label className="block text-xs font-semibold text-gray-600 dark:text-gray-400 mb-2 uppercase tracking-wide">
              <Tag size={12} className="inline mr-1" />
              Condition / Label
            </label>
            <input
              ref={inputRef}
              type="text"
              value={label}
              onChange={(e) => setLabel(e.target.value)}
              onKeyDown={handleKeyDown}
              className={inputClasses}
              placeholder={
                edgeType === 'condition' ? 'e.g. order_type == "mobile"' :
                edgeType === 'error' ? 'e.g. on_max_retry / on_error' :
                edgeType === 'success' ? 'e.g. validation passed' :
                'Describe when this path is taken...'
              }
            />
            <p className="mt-1.5 text-xs text-gray-400 dark:text-gray-500">
              This label appears on the connection line to explain the routing logic
            </p>
          </div>

          {/* Save */}
          <div className="flex justify-end gap-2 pt-1">
            <button onClick={onClose} className="px-3 py-1.5 text-sm text-gray-600 dark:text-gray-400 hover:bg-gray-100 dark:hover:bg-gray-700 rounded-lg transition-colors">
              Cancel
            </button>
            <button
              onClick={handleSave}
              className="px-4 py-1.5 text-sm font-medium bg-gradient-to-r from-blue-600 to-cyan-600 text-white rounded-lg hover:from-blue-700 hover:to-cyan-700 transition-all shadow-md shadow-blue-500/20"
            >
              Save
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
