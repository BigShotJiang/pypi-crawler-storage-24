import React, { useState } from 'react';
import { Settings, X, Cpu, MessageSquare, ShieldAlert } from 'lucide-react';
import useStore from '../store';

export default function GlobalSettingsPanel({ onClose }) {
  const activeWorkflowId = useStore(state => state.activeWorkflowId);
  const workflows = useStore(state => state.workflows);
  const updateActiveWorkflow = useStore(state => state.updateActiveWorkflow);

  const workflow = workflows.find(w => w.id === activeWorkflowId);
  const [config, setConfig] = useState(workflow?.globalConfig || {});

  if (!workflow) return null;

  const handleUpdate = (section, field, value) => {
    const updated = { ...config };
    if (!updated[section]) updated[section] = {};
    
    if (value === '' || value === null) {
      delete updated[section][field];
      if (Object.keys(updated[section]).length === 0) {
        delete updated[section];
      }
    } else {
      updated[section][field] = value;
    }
    
    setConfig(updated);
    updateActiveWorkflow({ globalConfig: updated });
  };

  const inputClasses = "w-full px-3 py-2 text-sm bg-white dark:bg-gray-700 border border-gray-300 dark:border-gray-600 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 dark:focus:ring-blue-400 text-gray-900 dark:text-gray-100 placeholder-gray-500 dark:placeholder-gray-400";
  const labelClasses = "block text-xs font-semibold tracking-wide text-gray-600 dark:text-gray-400 mb-1.5 uppercase";

  return (
    <div className="fixed inset-y-0 right-0 w-[400px] bg-white dark:bg-gray-800 shadow-2xl border-l border-gray-200 dark:border-gray-700 z-50 flex flex-col transition-colors">
      <div className="flex items-center justify-between p-4 border-b border-gray-200 dark:border-gray-700 bg-gray-50 dark:bg-gray-900">
        <div className="flex items-center gap-2">
          <Settings size={20} className="text-gray-600 dark:text-gray-400" />
          <h2 className="text-lg font-bold text-gray-900 dark:text-gray-100">Global Settings</h2>
        </div>
        <button onClick={onClose} className="p-1.5 rounded-lg hover:bg-gray-200 dark:hover:bg-gray-700 text-gray-500 transition-colors">
          <X size={20} />
        </button>
      </div>

      <div className="flex-1 overflow-y-auto p-6 space-y-8">
        
        {/* LLM Config */}
        <section className="space-y-4">
          <div className="flex items-center gap-2 text-blue-600 dark:text-blue-400 font-semibold border-b border-gray-200 dark:border-gray-700 pb-2">
            <Cpu size={18} />
            <h3>LLM Configuration</h3>
          </div>
          
          <div>
            <label className={labelClasses}>Provider</label>
            <select 
              value={config.llm?.provider || ''} 
              onChange={(e) => handleUpdate('llm', 'provider', e.target.value)}
              className={inputClasses}
            >
              <option value="">Default App Config</option>
              <option value="openai">OpenAI</option>
              <option value="anthropic">Anthropic</option>
              <option value="gemini">Google Gemini</option>
              <option value="xai">xAI</option>
              <option value="ollama">Ollama</option>
            </select>
          </div>

          <div>
            <label className={labelClasses}>Model Name</label>
            <input 
              type="text" 
              placeholder="gpt-4o or claude-3-5-sonnet"
              value={config.llm?.model || ''}
              onChange={(e) => handleUpdate('llm', 'model', e.target.value)}
              className={inputClasses}
            />
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className={labelClasses}>Temperature</label>
              <input 
                type="number" step="0.1" min="0" max="2"
                placeholder="0.2"
                value={config.llm?.temperature || ''}
                onChange={(e) => handleUpdate('llm', 'temperature', parseFloat(e.target.value))}
                className={inputClasses}
              />
            </div>
            <div>
              <label className={labelClasses}>Max Tokens</label>
              <input 
                type="number" step="1" min="1"
                placeholder="1024"
                value={config.llm?.max_tokens || ''}
                onChange={(e) => handleUpdate('llm', 'max_tokens', parseInt(e.target.value))}
                className={inputClasses}
              />
            </div>
          </div>
        </section>

        {/* Humanizer */}
        <section className="space-y-4">
          <div className="flex items-center gap-2 text-green-600 dark:text-green-400 font-semibold border-b border-gray-200 dark:border-gray-700 pb-2">
            <MessageSquare size={18} />
            <h3>Humanizer</h3>
          </div>
          
          <div className="flex items-center gap-2">
            <input 
              type="checkbox" 
              checked={config.humanizer?.enabled || false}
              onChange={(e) => handleUpdate('humanizer', 'enabled', e.target.checked)}
              className="rounded text-green-600 w-4 h-4 cursor-pointer"
            />
            <label className="text-sm font-medium text-gray-700 dark:text-gray-300">Enable Humanizer Pipeline</label>
          </div>

          {config.humanizer?.enabled && (
            <div>
              <label className={labelClasses}>Tone Instruction</label>
              <textarea 
                rows={3}
                placeholder="Write in a friendly, empathetic tone..."
                value={config.humanizer?.custom_prompt || ''}
                onChange={(e) => handleUpdate('humanizer', 'custom_prompt', e.target.value)}
                className={inputClasses}
              />
            </div>
          )}
        </section>

        {/* Out of Topic */}
        <section className="space-y-4">
          <div className="flex items-center gap-2 text-red-600 dark:text-red-400 font-semibold border-b border-gray-200 dark:border-gray-700 pb-2">
            <ShieldAlert size={18} />
            <h3>Out of Topic Handling</h3>
          </div>
          
          <div>
            <label className={labelClasses}>Response Template</label>
            <textarea 
              rows={3}
              placeholder="I can only help with product inquiries. How can I assist you with that?"
              value={config.out_of_topic?.template || ''}
              onChange={(e) => handleUpdate('out_of_topic', 'template', e.target.value)}
              className={inputClasses}
            />
          </div>
        </section>

      </div>
      
      <div className="p-4 border-t border-gray-200 dark:border-gray-700 bg-gray-50 dark:bg-gray-900 text-xs text-gray-500">
        Changes to global settings are auto-saved.
      </div>
    </div>
  );
}
