import React, { useState, useEffect } from 'react';
import { X, Plus, Trash2, ChevronDown, ChevronRight, Shield, Cpu, Sparkles, Eye, RotateCcw } from 'lucide-react';

export default function ConfigPanel({ node, onUpdate, onClose }) {
  const [config, setConfig] = useState(node?.data || {});
  const [expandedSections, setExpandedSections] = useState({});

  useEffect(() => {
    setConfig(node?.data || {});
  }, [node]);

  if (!node) return null;

  const inputClasses = "w-full px-3 py-2 bg-white dark:bg-gray-700 border border-gray-300 dark:border-gray-600 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 dark:focus:ring-blue-400 text-gray-900 dark:text-gray-100 placeholder-gray-500 dark:placeholder-gray-400 transition-colors text-sm";
  const labelClasses = "block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1.5";
  const checkboxLabelClasses = "text-sm text-gray-700 dark:text-gray-300";
  const sectionHeaderClasses = "flex items-center gap-2 cursor-pointer select-none py-2 px-3 rounded-lg hover:bg-gray-100 dark:hover:bg-gray-700/50 transition-colors";
  const cardClasses = "border border-gray-200 dark:border-gray-600 rounded-lg p-3 space-y-2 bg-gray-50 dark:bg-gray-700/30";

  const toggleSection = (key) => {
    setExpandedSections(prev => ({ ...prev, [key]: !prev[key] }));
  };

  const handleUpdate = (field, value) => {
    const newConfig = { ...config, [field]: value };
    setConfig(newConfig);
    onUpdate(node.id, newConfig);
  };

  const handleNestedUpdate = (parent, field, value) => {
    const parentObj = { ...(config[parent] || {}) };
    if (value === '' || value === null || value === undefined) {
      delete parentObj[field];
    } else {
      parentObj[field] = value;
    }
    // Remove the parent key entirely if it's empty
    if (Object.keys(parentObj).length === 0) {
      const newConfig = { ...config };
      delete newConfig[parent];
      setConfig(newConfig);
      onUpdate(node.id, newConfig);
    } else {
      handleUpdate(parent, parentObj);
    }
  };

  const handleArrayUpdate = (field, index, value) => {
    const arr = [...(config[field] || [])];
    arr[index] = value;
    handleUpdate(field, arr);
  };

  const handleArrayAdd = (field, defaultValue = '') => {
    const arr = [...(config[field] || []), defaultValue];
    handleUpdate(field, arr);
  };

  const handleArrayRemove = (field, index) => {
    const arr = [...(config[field] || [])];
    arr.splice(index, 1);
    handleUpdate(field, arr);
  };

  const handleRouteUpdate = (index, field, value) => {
    const routes = [...(config.routes || [])];
    routes[index] = { ...routes[index], [field]: value };
    handleUpdate('routes', routes);
  };

  const handleFieldUpdate = (index, field, value) => {
    const fields = [...(config.fields || [])];
    fields[index] = { ...fields[index], [field]: value };
    handleUpdate('fields', fields);
  };

  const handleFieldValidationUpdate = (index, field, value) => {
    const fields = [...(config.fields || [])];
    const fieldObj = { ...fields[index] };
    if (!fieldObj.validation) fieldObj.validation = {};
    if (value === '' || value === null) {
      delete fieldObj.validation[field];
      if (Object.keys(fieldObj.validation).length === 0) delete fieldObj.validation;
    } else {
      fieldObj.validation[field] = value;
    }
    fields[index] = fieldObj;
    handleUpdate('fields', fields);
  };

  const handleToolUpdate = (index, field, value) => {
    const tools = [...(config.tools || [])];
    tools[index] = { ...tools[index], [field]: value };
    handleUpdate('tools', tools);
  };

  const handleArgUpdate = (index, field, value) => {
    const args = [...(config.args_from_state || [])];
    args[index] = { ...args[index], [field]: value };
    handleUpdate('args_from_state', args);
  };

  const handleGuardrailsRuleUpdate = (index, value) => {
    const rules = [...(config.guardrails?.custom_rules || [])];
    rules[index] = value;
    handleNestedUpdate('guardrails', 'custom_rules', rules);
  };

  const handleGuardrailsRuleAdd = () => {
    const rules = [...(config.guardrails?.custom_rules || []), ''];
    handleNestedUpdate('guardrails', 'custom_rules', rules);
  };

  const handleGuardrailsRuleRemove = (index) => {
    const rules = [...(config.guardrails?.custom_rules || [])];
    rules.splice(index, 1);
    handleNestedUpdate('guardrails', 'custom_rules', rules.length > 0 ? rules : null);
  };

  // ── Collapsible Section Component ──
  const Section = ({ id, icon: Icon, title, color, children }) => {
    const isOpen = expandedSections[id];
    return (
      <div className="border border-gray-200 dark:border-gray-600 rounded-xl overflow-hidden">
        <button onClick={() => toggleSection(id)} className={sectionHeaderClasses + ' w-full'}>
          {isOpen ? <ChevronDown size={14} className="text-gray-500 dark:text-gray-400" /> : <ChevronRight size={14} className="text-gray-500 dark:text-gray-400" />}
          <Icon size={16} className={color} />
          <span className="text-sm font-semibold text-gray-800 dark:text-gray-200 flex-1 text-left">{title}</span>
        </button>
        {isOpen && <div className="px-3 pb-3 space-y-3">{children}</div>}
      </div>
    );
  };

  // ═══════════════════════════════════════════════════════════════════
  // GUARDRAILS SUB-SECTION (shared by DataCollector and Response)
  // ═══════════════════════════════════════════════════════════════════
  const renderGuardrails = () => (
    <Section id="guardrails" icon={Shield} title="Guardrails" color="text-amber-500 dark:text-amber-400">
      <div className="flex items-center gap-2">
        <input
          type="checkbox"
          checked={config.guardrails?.enabled !== false}
          onChange={(e) => handleNestedUpdate('guardrails', 'enabled', e.target.checked)}
          className="rounded text-amber-600 w-4 h-4 cursor-pointer"
        />
        <label className={checkboxLabelClasses}>Enable Guardrails</label>
      </div>

      <div>
        <label className={labelClasses}>Tone</label>
        <input
          type="text"
          value={config.guardrails?.tone || ''}
          onChange={(e) => handleNestedUpdate('guardrails', 'tone', e.target.value)}
          className={inputClasses}
          placeholder="warm and professional"
        />
      </div>

      <div>
        <div className="flex items-center justify-between mb-1.5">
          <label className={labelClasses + ' mb-0'}>Custom Rules</label>
          <button onClick={handleGuardrailsRuleAdd} className="flex items-center gap-1 px-2 py-1 text-xs bg-amber-500 text-white rounded hover:bg-amber-600 transition-colors">
            <Plus size={12} /> Add
          </button>
        </div>
        <div className="space-y-1.5">
          {(config.guardrails?.custom_rules || []).map((rule, idx) => (
            <div key={idx} className="flex items-center gap-2">
              <input
                type="text"
                value={rule}
                onChange={(e) => handleGuardrailsRuleUpdate(idx, e.target.value)}
                className={inputClasses + ' flex-1'}
                placeholder="Never mention competitors"
              />
              <button onClick={() => handleGuardrailsRuleRemove(idx)} className="text-red-500 hover:text-red-700 dark:hover:text-red-400 shrink-0">
                <Trash2 size={14} />
              </button>
            </div>
          ))}
        </div>
      </div>

      <div>
        <label className={labelClasses}>Custom Prompt (full override)</label>
        <textarea
          value={config.guardrails?.custom_prompt || ''}
          onChange={(e) => handleNestedUpdate('guardrails', 'custom_prompt', e.target.value)}
          className={inputClasses}
          rows={3}
          placeholder="Fully replaces all guardrail logic..."
        />
      </div>
    </Section>
  );

  // ═══════════════════════════════════════════════════════════════════
  // LLM PARAMS SUB-SECTION (DataCollector + Response)
  // ═══════════════════════════════════════════════════════════════════
  const renderLLMParams = () => (
    <Section id="llm_params" icon={Cpu} title="LLM Params (per-node)" color="text-violet-500 dark:text-violet-400">
      <div>
        <label className={labelClasses}>Model Override</label>
        <input
          type="text"
          value={config.llm_params?.model || ''}
          onChange={(e) => handleNestedUpdate('llm_params', 'model', e.target.value)}
          className={inputClasses}
          placeholder="gpt-4o or claude-sonnet-4-6"
        />
      </div>
      <div className="grid grid-cols-2 gap-3">
        <div>
          <label className={labelClasses}>Temperature</label>
          <input
            type="number" step="0.1" min="0" max="2"
            value={config.llm_params?.temperature ?? ''}
            onChange={(e) => handleNestedUpdate('llm_params', 'temperature', e.target.value ? parseFloat(e.target.value) : null)}
            className={inputClasses}
            placeholder="0.1"
          />
        </div>
        <div>
          <label className={labelClasses}>Max Tokens</label>
          <input
            type="number" step="1" min="1"
            value={config.llm_params?.max_tokens ?? ''}
            onChange={(e) => handleNestedUpdate('llm_params', 'max_tokens', e.target.value ? parseInt(e.target.value) : null)}
            className={inputClasses}
            placeholder="512"
          />
        </div>
      </div>
      <div>
        <label className={labelClasses}>Top P</label>
        <input
          type="number" step="0.1" min="0" max="1"
          value={config.llm_params?.top_p ?? ''}
          onChange={(e) => handleNestedUpdate('llm_params', 'top_p', e.target.value ? parseFloat(e.target.value) : null)}
          className={inputClasses}
          placeholder="1.0"
        />
      </div>
    </Section>
  );

  // ═══════════════════════════════════════════════════════════════════
  // DATA COLLECTOR CONFIG
  // ═══════════════════════════════════════════════════════════════════
  const renderDataCollectorConfig = () => (
    <>
      {/* Basic fields */}
      <div>
        <label className={labelClasses}>Node Name</label>
        <input type="text" value={config.label || ''} onChange={(e) => handleUpdate('label', e.target.value)} className={inputClasses} placeholder="collect_sr" />
      </div>

      <div>
        <label className={labelClasses}>Role / System Instruction</label>
        <textarea value={config.role || ''} onChange={(e) => handleUpdate('role', e.target.value)} className={inputClasses} rows={3} placeholder="You are a helpful assistant..." />
      </div>

      <div>
        <label className={labelClasses}>Initial Message</label>
        <textarea value={config.initial_message || ''} onChange={(e) => handleUpdate('initial_message', e.target.value)} className={inputClasses} rows={2} placeholder="Please provide your SR number..." />
      </div>

      {/* Single vs Multi Field Toggle */}
      <div className="flex items-center gap-4">
        <label className="flex items-center gap-2 cursor-pointer">
          <input type="radio" checked={!config.fields} onChange={() => { const nc = { ...config }; delete nc.fields; setConfig(nc); onUpdate(node.id, nc); }} className="text-blue-600 dark:text-blue-400" />
          <span className="text-sm font-medium text-gray-700 dark:text-gray-300">Single Field</span>
        </label>
        <label className="flex items-center gap-2 cursor-pointer">
          <input type="radio" checked={!!config.fields} onChange={() => handleUpdate('fields', [{ field: '', description: '' }])} className="text-blue-600 dark:text-blue-400" />
          <span className="text-sm font-medium text-gray-700 dark:text-gray-300">Multi Field</span>
        </label>
      </div>

      {/* Single Field Mode */}
      {!config.fields ? (
        <>
          <div>
            <label className={labelClasses}>Field Name</label>
            <input type="text" value={config.field || ''} onChange={(e) => handleUpdate('field', e.target.value)} className={inputClasses} placeholder="sr_number" />
          </div>
          <div>
            <label className={labelClasses}>Description</label>
            <textarea value={config.description || ''} onChange={(e) => handleUpdate('description', e.target.value)} className={inputClasses} rows={2} placeholder="The SR number in format SR-XXXXX" />
          </div>
          <div>
            <label className={labelClasses}>Validation Method</label>
            <input type="text" value={config.validation?.method || ''} onChange={(e) => handleUpdate('validation', { ...(config.validation || {}), method: e.target.value })} className={inputClasses} placeholder="regex or validations.sr.check_sr_format" />
          </div>
          {config.validation?.method === 'regex' && (
            <div>
              <label className={labelClasses}>Regex Pattern</label>
              <input type="text" value={config.validation?.pattern || ''} onChange={(e) => handleUpdate('validation', { ...(config.validation || {}), pattern: e.target.value })} className={inputClasses} placeholder="^[\\w.-]+@[\\w.-]+\\.\\w+$" />
            </div>
          )}
        </>
      ) : (
        /* Multi Field Mode */
        <div>
          <div className="flex items-center justify-between mb-2">
            <label className={labelClasses + ' mb-0'}>Fields</label>
            <button onClick={() => handleArrayAdd('fields', { field: '', description: '' })} className="flex items-center gap-1 px-2 py-1 text-xs bg-blue-500 text-white rounded hover:bg-blue-600 transition-colors">
              <Plus size={14} /> Add Field
            </button>
          </div>
          <div className="space-y-3">
            {(config.fields || []).map((field, idx) => (
              <div key={idx} className={cardClasses}>
                <div className="flex items-center justify-between">
                  <span className="text-xs font-semibold text-gray-500 dark:text-gray-400">Field {idx + 1}</span>
                  <button onClick={() => handleArrayRemove('fields', idx)} className="text-red-500 hover:text-red-700 dark:hover:text-red-400">
                    <Trash2 size={14} />
                  </button>
                </div>
                <input type="text" value={field.field || ''} onChange={(e) => handleFieldUpdate(idx, 'field', e.target.value)} className={inputClasses} placeholder="field_name" />
                <input type="text" value={field.description || ''} onChange={(e) => handleFieldUpdate(idx, 'description', e.target.value)} className={inputClasses} placeholder="Description" />
                <input type="text" value={field.default || ''} onChange={(e) => handleFieldUpdate(idx, 'default', e.target.value)} className={inputClasses} placeholder="Default value (optional)" />
                <div className="grid grid-cols-2 gap-2">
                  <input
                    type="text"
                    value={field.validation?.method || ''}
                    onChange={(e) => handleFieldValidationUpdate(idx, 'method', e.target.value)}
                    className={inputClasses}
                    placeholder="Validation (regex/custom)"
                  />
                  {field.validation?.method === 'regex' && (
                    <input
                      type="text"
                      value={field.validation?.pattern || ''}
                      onChange={(e) => handleFieldValidationUpdate(idx, 'pattern', e.target.value)}
                      className={inputClasses}
                      placeholder="Pattern"
                    />
                  )}
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Tools */}
      <div>
        <div className="flex items-center justify-between mb-2">
          <label className={labelClasses + ' mb-0'}>Tools (Optional)</label>
          <button onClick={() => handleArrayAdd('tools', { name: '', description: '', method: '' })} className="flex items-center gap-1 px-2 py-1 text-xs bg-indigo-500 text-white rounded hover:bg-indigo-600 transition-colors">
            <Plus size={14} /> Add Tool
          </button>
        </div>
        <div className="space-y-3">
          {(config.tools || []).map((tool, idx) => (
            <div key={idx} className={cardClasses}>
              <div className="flex items-center justify-between">
                <span className="text-xs font-semibold text-gray-500 dark:text-gray-400">Tool {idx + 1}</span>
                <button onClick={() => handleArrayRemove('tools', idx)} className="text-red-500 hover:text-red-700 dark:hover:text-red-400">
                  <Trash2 size={14} />
                </button>
              </div>
              <input type="text" value={tool.name || ''} onChange={(e) => handleToolUpdate(idx, 'name', e.target.value)} className={inputClasses} placeholder="tool_name" />
              <input type="text" value={tool.method || ''} onChange={(e) => handleToolUpdate(idx, 'method', e.target.value)} className={inputClasses} placeholder="actions.my_module.my_tool" />
              <input type="text" value={tool.description || ''} onChange={(e) => handleToolUpdate(idx, 'description', e.target.value)} className={inputClasses} placeholder="Description of tool" />
            </div>
          ))}
        </div>
      </div>

      {/* Max Retry + On Max Retry */}
      <div className="grid grid-cols-2 gap-3">
        <div>
          <label className={labelClasses}>Max Retries</label>
          <input type="number" value={config.max_retry || 3} onChange={(e) => handleUpdate('max_retry', parseInt(e.target.value))} className={inputClasses} min="1" />
        </div>
        <div>
          <label className={labelClasses}>On Max Retry</label>
          <input type="text" value={config.on_max_retry || ''} onChange={(e) => handleUpdate('on_max_retry', e.target.value)} className={inputClasses} placeholder="error_response" />
        </div>
      </div>

      {/* Toggle switches */}
      <div className="space-y-2.5 pt-1">
        <div className="flex flex-col gap-2">
          <div className="flex items-center gap-2">
            <input type="checkbox" checked={config.allow_intent_escape || false} onChange={(e) => handleUpdate('allow_intent_escape', e.target.checked)} className="rounded text-blue-600 w-4 h-4 cursor-pointer" />
            <label className={checkboxLabelClasses}>Allow Intent Escape</label>
          </div>
          {config.allow_intent_escape && (
            <div className="ml-6 mt-1">
              <label className={labelClasses}>Custom Prompt</label>
              <textarea 
                value={config.intent_escape_prompt || ''} 
                onChange={(e) => handleUpdate('intent_escape_prompt', e.target.value)} 
                className={inputClasses} 
                rows={2} 
                placeholder="Optional: custom instructions for out of topic questions..." 
              />
            </div>
          )}
        </div>
        <div className="flex flex-col gap-2">
          <div className="flex items-center gap-2">
            <input type="checkbox" checked={config.humanize !== false} onChange={(e) => handleUpdate('humanize', e.target.checked)} className="rounded text-green-600 w-4 h-4 cursor-pointer" />
            <label className={checkboxLabelClasses}>Humanize Responses</label>
          </div>
          {config.humanize !== false && (
            <div className="ml-6 mt-1">
              <label className={labelClasses}>Custom Prompt</label>
              <textarea 
                value={config.humanize_prompt || ''} 
                onChange={(e) => handleUpdate('humanize_prompt', e.target.value)} 
                className={inputClasses} 
                rows={2} 
                placeholder="Optional: custom instructions for standardizing the tone..." 
              />
            </div>
          )}
        </div>
        <div className="flex flex-col gap-2">
          <div className="flex items-center gap-2">
            <input type="checkbox" checked={config.hallucination_check !== false} onChange={(e) => handleUpdate('hallucination_check', e.target.checked)} className="rounded text-purple-600 w-4 h-4 cursor-pointer" />
            <label className={checkboxLabelClasses}>Hallucination Check</label>
          </div>
          {config.hallucination_check !== false && (
            <div className="ml-6 mt-1">
              <label className={labelClasses}>Custom Prompt</label>
              <textarea 
                value={config.hallucination_prompt || ''} 
                onChange={(e) => handleUpdate('hallucination_prompt', e.target.value)} 
                className={inputClasses} 
                rows={2} 
                placeholder="Optional: custom instructions for analyzing the extraction..." 
              />
            </div>
          )}
        </div>

        {/* Node Rollback */}
        <div className="flex flex-col gap-2">
          <div className="flex items-center gap-2">
            <input
              type="checkbox"
              checked={
                typeof config.allow_node_rollback === 'object'
                  ? config.allow_node_rollback?.enabled !== false
                  : !!config.allow_node_rollback
              }
              onChange={(e) => {
                if (e.target.checked) {
                  handleUpdate('allow_node_rollback', { enabled: true, custom_prompt: '' });
                } else {
                  handleUpdate('allow_node_rollback', false);
                }
              }}
              className="rounded text-indigo-600 w-4 h-4 cursor-pointer"
            />
            <label className={checkboxLabelClasses}>Node Rollback</label>
            <span className="text-xs text-gray-400 dark:text-gray-500">(redirect to sibling node if user switches topic)</span>
          </div>
          {(typeof config.allow_node_rollback === 'object'
            ? config.allow_node_rollback?.enabled !== false
            : !!config.allow_node_rollback) && (
            <div className="ml-6 mt-1 space-y-2">
              <div>
                <label className={labelClasses}>Custom Routing Prompt</label>
                <textarea
                  value={
                    typeof config.allow_node_rollback === 'object'
                      ? config.allow_node_rollback?.custom_prompt || ''
                      : ''
                  }
                  onChange={(e) => {
                    const prompt = e.target.value;
                    handleUpdate('allow_node_rollback', {
                      enabled: true,
                      custom_prompt: prompt,
                    });
                  }}
                  className={inputClasses}
                  rows={4}
                  placeholder={`Optional — overrides default routing prompt.\nAvailable placeholders:\n{current_node}, {current_desc}, {user_input},\n{candidates}, {candidate_names}, {language}`}
                />
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Advanced sections */}
      <div className="space-y-2 pt-2">
        {renderGuardrails()}
        {renderLLMParams()}
      </div>
    </>
  );

  // ═══════════════════════════════════════════════════════════════════
  // CUSTOM ACTION CONFIG
  // ═══════════════════════════════════════════════════════════════════
  const renderCustomActionConfig = () => (
    <>
      <div>
        <label className={labelClasses}>Node Name</label>
        <input type="text" value={config.label || ''} onChange={(e) => handleUpdate('label', e.target.value)} className={inputClasses} placeholder="check_billing" />
      </div>

      <div>
        <label className={labelClasses}>Method Path</label>
        <input type="text" value={config.method || ''} onChange={(e) => handleUpdate('method', e.target.value)} className={inputClasses} placeholder="actions.billing.check_status" />
      </div>

      <div>
        <label className={labelClasses}>Result Field</label>
        <input type="text" value={config.result_field || 'action_result'} onChange={(e) => handleUpdate('result_field', e.target.value)} className={inputClasses} placeholder="action_result" />
      </div>

      {/* Args from State */}
      <div>
        <div className="flex items-center justify-between mb-2 mt-2">
          <label className={labelClasses + ' mb-0'}>Args from State</label>
          <button onClick={() => handleArrayAdd('args_from_state', { arg: '', stateKey: '' })} className="flex items-center gap-1 px-2 py-1 text-xs bg-purple-500 text-white rounded hover:bg-purple-600 transition-colors">
            <Plus size={14} /> Add Arg
          </button>
        </div>
        <div className="space-y-2">
          {(config.args_from_state || []).map((argObj, idx) => (
            <div key={idx} className="flex items-center gap-2">
              <input type="text" value={argObj.arg || ''} onChange={(e) => handleArgUpdate(idx, 'arg', e.target.value)} className={inputClasses + ' flex-1'} placeholder="kwarg_name" />
              <span className="text-gray-400 dark:text-gray-500">=</span>
              <input type="text" value={argObj.stateKey || ''} onChange={(e) => handleArgUpdate(idx, 'stateKey', e.target.value)} className={inputClasses + ' flex-1'} placeholder="state_key" />
              <button onClick={() => handleArrayRemove('args_from_state', idx)} className="text-red-500 hover:text-red-700 dark:hover:text-red-400 shrink-0">
                <Trash2 size={14} />
              </button>
            </div>
          ))}
        </div>
      </div>

      <div>
        <label className={labelClasses}>Simple Next Node</label>
        <input type="text" value={config.next || ''} onChange={(e) => handleUpdate('next', e.target.value)} className={inputClasses} placeholder="target_node_name" />
      </div>

      <div>
        <label className={labelClasses}>On Error Route</label>
        <input type="text" value={config.on_error || ''} onChange={(e) => handleUpdate('on_error', e.target.value)} className={inputClasses} placeholder="error_handler_node" />
      </div>

      {/* Routes */}
      <div>
        <div className="flex items-center justify-between mb-2">
          <label className={labelClasses + ' mb-0'}>Routes (Dynamic)</label>
          <button onClick={() => handleArrayAdd('routes', { value: '', next: '' })} className="flex items-center gap-1 px-2 py-1 text-xs bg-orange-500 text-white rounded hover:bg-orange-600 transition-colors">
            <Plus size={14} /> Add Route
          </button>
        </div>
        <div className="space-y-2">
          {(config.routes || []).map((route, idx) => (
            <div key={idx} className="flex items-center gap-2">
              <input type="text" value={route.value || ''} onChange={(e) => handleRouteUpdate(idx, 'value', e.target.value)} className={inputClasses + ' flex-1'} placeholder={route.default !== undefined ? "default" : "value"} disabled={route.default !== undefined} />
              <span className="text-gray-400 dark:text-gray-500">→</span>
              <input type="text" value={route.next || ''} onChange={(e) => handleRouteUpdate(idx, 'next', e.target.value)} className={inputClasses + ' flex-1'} placeholder="next_node" />
              <button onClick={() => handleArrayRemove('routes', idx)} className="text-red-500 hover:text-red-700 dark:hover:text-red-400 shrink-0">
                <Trash2 size={14} />
              </button>
            </div>
          ))}
        </div>
      </div>
    </>
  );

  // ═══════════════════════════════════════════════════════════════════
  // RESPONSE CONFIG
  // ═══════════════════════════════════════════════════════════════════
  const renderResponseConfig = () => (
    <>
      <div>
        <label className={labelClasses}>Node Name</label>
        <input type="text" value={config.label || ''} onChange={(e) => handleUpdate('label', e.target.value)} className={inputClasses} placeholder="success_response" />
      </div>

      <div>
        <label className={labelClasses}>Response Styling</label>
        <div className="grid grid-cols-3 gap-2">
          <label className={`flex items-center justify-center gap-1.5 py-1.5 px-2 rounded border cursor-pointer transition-colors text-xs font-medium ${(!config.response_type || config.response_type === 'default') ? 'bg-green-50 border-green-500 text-green-700 dark:bg-green-900/30 dark:text-green-400' : 'bg-white border-gray-200 text-gray-600 dark:bg-gray-800 dark:border-gray-600 dark:text-gray-400 hover:bg-gray-50 dark:hover:bg-gray-700'}`}>
            <input type="radio" className="hidden" name="response_type" checked={!config.response_type || config.response_type === 'default'} onChange={() => handleUpdate('response_type', 'default')} />
            Default
          </label>
          <label className={`flex items-center justify-center gap-1.5 py-1.5 px-2 rounded border cursor-pointer transition-colors text-xs font-medium ${config.response_type === 'success' ? 'bg-emerald-50 border-emerald-500 text-emerald-700 dark:bg-emerald-900/30 dark:text-emerald-400' : 'bg-white border-gray-200 text-gray-600 dark:bg-gray-800 dark:border-gray-600 dark:text-gray-400 hover:bg-gray-50 dark:hover:bg-gray-700'}`}>
            <input type="radio" className="hidden" name="response_type" checked={config.response_type === 'success'} onChange={() => handleUpdate('response_type', 'success')} />
            Success
          </label>
          <label className={`flex items-center justify-center gap-1.5 py-1.5 px-2 rounded border cursor-pointer transition-colors text-xs font-medium ${config.response_type === 'error' ? 'bg-red-50 border-red-500 text-red-700 dark:bg-red-900/30 dark:text-red-400' : 'bg-white border-gray-200 text-gray-600 dark:bg-gray-800 dark:border-gray-600 dark:text-gray-400 hover:bg-gray-50 dark:hover:bg-gray-700'}`}>
            <input type="radio" className="hidden" name="response_type" checked={config.response_type === 'error'} onChange={() => handleUpdate('response_type', 'error')} />
            Error
          </label>
        </div>
      </div>

      <div>
        <label className={labelClasses}>Output Field</label>
        <input type="text" value={config.output_field || 'output'} onChange={(e) => handleUpdate('output_field', e.target.value)} className={inputClasses} placeholder="output" />
      </div>

      <div>
        <label className={labelClasses}>Error Field</label>
        <input type="text" value={config.error_field || 'error'} onChange={(e) => handleUpdate('error_field', e.target.value)} className={inputClasses} placeholder="error" />
      </div>

      <div>
        <label className={labelClasses}>Template (Optional)</label>
        <textarea value={config.template || ''} onChange={(e) => handleUpdate('template', e.target.value)} className={inputClasses} rows={3} placeholder="Your request {state.request_id} has been submitted!" />
      </div>

      {/* Guardrails for Response */}
      <div className="pt-2">
        {renderGuardrails()}
      </div>
    </>
  );

  // ═══════════════════════════════════════════════════════════════════
  // NODE TYPE BADGE
  // ═══════════════════════════════════════════════════════════════════
  const typeStyles = {
    dataCollector: { label: 'Data Collector', bg: 'bg-blue-100 dark:bg-blue-900/40', text: 'text-blue-700 dark:text-blue-300', border: 'border-blue-200 dark:border-blue-700' },
    customAction: { label: 'Custom Action', bg: 'bg-orange-100 dark:bg-orange-900/40', text: 'text-orange-700 dark:text-orange-300', border: 'border-orange-200 dark:border-orange-700' },
    response: { label: 'Response', bg: 'bg-green-100 dark:bg-green-900/40', text: 'text-green-700 dark:text-green-300', border: 'border-green-200 dark:border-green-700' },
  };
  const style = typeStyles[node.type] || typeStyles.dataCollector;

  return (
    <div className="fixed right-0 top-0 h-full w-[420px] bg-white dark:bg-gray-800 shadow-2xl border-l border-gray-200 dark:border-gray-700 overflow-y-auto z-50 transition-colors">
      <div className="sticky top-0 bg-white dark:bg-gray-800 border-b border-gray-200 dark:border-gray-700 p-4 flex items-center justify-between z-10">
        <div className="flex items-center gap-3">
          <h2 className="text-lg font-bold text-gray-900 dark:text-gray-100">Configure</h2>
          <span className={`text-xs font-semibold px-2.5 py-1 rounded-full border ${style.bg} ${style.text} ${style.border}`}>
            {style.label}
          </span>
        </div>
        <button onClick={onClose} className="p-1.5 rounded-lg text-gray-400 hover:text-gray-600 dark:hover:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-700 transition-colors">
          <X size={20} />
        </button>
      </div>

      <div className="p-4 space-y-4">
        {node.type === 'dataCollector' && renderDataCollectorConfig()}
        {node.type === 'customAction' && renderCustomActionConfig()}
        {node.type === 'response' && renderResponseConfig()}
      </div>
    </div>
  );
}
