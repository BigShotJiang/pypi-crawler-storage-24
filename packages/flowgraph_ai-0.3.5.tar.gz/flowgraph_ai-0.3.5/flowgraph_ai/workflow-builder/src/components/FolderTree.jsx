import React, { useState } from 'react';
import { Folder, FileCode2, Plus, Trash2, ChevronRight, ChevronDown, Save, MoreVertical, X } from 'lucide-react';
import useStore from '../store';

export default function FolderTree({ onSelectWorkflow }) {
  const folders = useStore(state => state.folders);
  const workflows = useStore(state => state.workflows);
  const addFolder = useStore(state => state.addFolder);
  const deleteFolder = useStore(state => state.deleteFolder);
  const deleteWorkflow = useStore(state => state.deleteWorkflow);
  const activeWorkflowId = useStore(state => state.activeWorkflowId);

  const [expandedFolders, setExpandedFolders] = useState(['root']);
  const [newFolderParent, setNewFolderParent] = useState(null);
  const [newFolderName, setNewFolderName] = useState('');

  const toggleFolder = (folderId) => {
    setExpandedFolders(prev => 
      prev.includes(folderId) 
        ? prev.filter(id => id !== folderId)
        : [...prev, folderId]
    );
  };

  const handleAddFolder = (e) => {
    e.preventDefault();
    if (newFolderName.trim() && newFolderParent) {
      addFolder(newFolderName.trim(), newFolderParent);
      setNewFolderName('');
      setNewFolderParent(null);
      if (!expandedFolders.includes(newFolderParent)) {
        setExpandedFolders([...expandedFolders, newFolderParent]);
      }
    }
  };

  const renderTree = (parentId = null, depth = 0) => {
    const childFolders = folders.filter(f => f.parentId === parentId);
    
    // Sort logic: root first
    if (parentId === null && childFolders.length > 0) {
      // Typically parentId=null implies we render 'root'
    }

    return childFolders.map(folder => {
      const isExpanded = expandedFolders.includes(folder.id);
      const folderWorkflows = workflows.filter(w => w.folderId === folder.id);
      
      return (
        <div key={folder.id} className="w-full">
          <div 
            className={`group flex items-center justify-between py-1.5 px-2 rounded-lg cursor-pointer transition-colors ${depth === 0 ? 'bg-gray-100 dark:bg-gray-800/50 mb-1' : 'hover:bg-gray-100 dark:hover:bg-gray-800'}`}
            style={{ paddingLeft: `${depth * 12 + 8}px` }}
          >
            <div className="flex items-center gap-2 flex-1 min-w-0" onClick={() => toggleFolder(folder.id)}>
              <button className="p-0.5 text-gray-500 hover:text-gray-700 dark:text-gray-400 dark:hover:text-gray-200">
                {isExpanded ? <ChevronDown size={14} /> : <ChevronRight size={14} />}
              </button>
              <Folder size={14} className="text-blue-500 dark:text-blue-400 shrink-0" />
              <span className="text-sm font-medium text-gray-700 dark:text-gray-200 truncate select-none">
                {folder.name}
              </span>
            </div>
            
            <div className="flex items-center opacity-0 group-hover:opacity-100 transition-opacity gap-1">
              <button 
                onClick={(e) => { e.stopPropagation(); setNewFolderParent(folder.id); }}
                className="p-1 text-gray-400 hover:text-blue-600 dark:hover:text-blue-400"
                title="New Folder"
              >
                <Plus size={14} />
              </button>
              {folder.id !== 'root' && (
                <button 
                  onClick={(e) => { e.stopPropagation(); deleteFolder(folder.id); }}
                  className="p-1 text-gray-400 hover:text-red-600 dark:hover:text-red-400"
                  title="Delete Folder"
                >
                  <Trash2 size={14} />
                </button>
              )}
            </div>
          </div>

          {newFolderParent === folder.id && (
            <div className="py-1 px-2" style={{ paddingLeft: `${(depth + 1) * 12 + 28}px` }}>
              <form onSubmit={handleAddFolder} className="flex items-center gap-2">
                <input 
                  autoFocus
                  type="text" 
                  value={newFolderName}
                  onChange={e => setNewFolderName(e.target.value)}
                  placeholder="Folder name..."
                  className="flex-1 text-xs px-2 py-1 border border-blue-300 dark:border-blue-700 bg-white dark:bg-gray-900 text-gray-900 dark:text-white rounded focus:outline-none focus:ring-1 focus:ring-blue-500"
                />
                <button type="button" onClick={() => setNewFolderParent(null)} className="text-gray-500 hover:text-gray-700">
                  <X size={14} />
                </button>
              </form>
            </div>
          )}

          {isExpanded && (
            <div className="space-y-0.5 mt-0.5">
              {renderTree(folder.id, depth + 1)}
              
              {folderWorkflows.map(workflow => (
                <div 
                  key={workflow.id}
                  onClick={() => onSelectWorkflow(workflow.id)}
                  className={`group flex items-center justify-between py-1.5 px-2 rounded-lg cursor-pointer transition-colors ${
                    activeWorkflowId === workflow.id 
                    ? 'bg-blue-50 dark:bg-blue-900/30 text-blue-700 dark:text-blue-300' 
                    : 'hover:bg-gray-50 dark:hover:bg-gray-800/80 text-gray-600 dark:text-gray-400'
                  }`}
                  style={{ paddingLeft: `${(depth + 1) * 12 + 28}px` }}
                >
                  <div className="flex items-center gap-2 flex-1 min-w-0">
                    <FileCode2 size={14} className={`shrink-0 ${activeWorkflowId === workflow.id ? 'text-blue-600 dark:text-blue-400' : 'text-gray-400'}`} />
                    <span className={`text-sm truncate select-none ${activeWorkflowId === workflow.id ? 'font-medium' : ''}`}>
                      {workflow.name}
                    </span>
                  </div>
                  <button 
                    onClick={(e) => { e.stopPropagation(); deleteWorkflow(workflow.id); }}
                    className="p-1 opacity-0 group-hover:opacity-100 text-gray-400 hover:text-red-600 transition-opacity"
                    title="Delete Workflow"
                  >
                    <Trash2 size={14} />
                  </button>
                </div>
              ))}
              
              {childFolders.length === 0 && folderWorkflows.length === 0 && (
                <div 
                  className="py-1.5 px-2 text-xs text-gray-400 dark:text-gray-500 italic"
                  style={{ paddingLeft: `${(depth + 1) * 12 + 28}px` }}
                >
                  Empty
                </div>
              )}
            </div>
          )}
        </div>
      );
    });
  };

  return (
    <div className="flex flex-col h-full bg-white dark:bg-gray-800 border-r border-gray-200 dark:border-gray-700 w-64 shrink-0 transition-colors">
      <div className="p-4 border-b border-gray-200 dark:border-gray-700 flex items-center justify-between">
        <h2 className="text-sm font-bold text-gray-900 dark:text-gray-100 uppercase tracking-wider">Explorer</h2>
        <button 
          onClick={() => {
            onSelectWorkflow('new');
          }}
          className="p-1.5 bg-blue-50 text-blue-600 hover:bg-blue-100 dark:bg-blue-900/30 dark:text-blue-400 dark:hover:bg-blue-900/50 rounded-md transition-colors"
          title="New Workflow"
        >
          <Plus size={16} />
        </button>
      </div>
      <div className="flex-1 overflow-y-auto p-2 scrollbar-thin scrollbar-thumb-gray-300 dark:scrollbar-thumb-gray-600">
        {renderTree(null)}
      </div>
    </div>
  );
}
