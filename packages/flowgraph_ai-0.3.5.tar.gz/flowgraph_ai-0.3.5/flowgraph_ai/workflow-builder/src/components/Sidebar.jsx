import React from 'react';
import { Database, Zap, MessageSquare, Sparkles } from 'lucide-react';

export default function Sidebar() {
  const onDragStart = (event, nodeType) => {
    event.dataTransfer.setData('application/reactflow', nodeType);
    event.dataTransfer.effectAllowed = 'move';
  };

  const nodeTypes = [
    {
      type: 'dataCollector',
      label: 'Data Collector',
      icon: Database,
      gradient: 'from-blue-500 to-blue-600',
      bg: 'bg-blue-500',
      description: 'Collect user input with validation'
    },
    {
      type: 'customAction',
      label: 'Custom Action',
      icon: Zap,
      gradient: 'from-orange-500 to-amber-600',
      bg: 'bg-orange-500',
      description: 'Execute business logic'
    },
    {
      type: 'response',
      label: 'Response',
      icon: MessageSquare,
      gradient: 'from-green-500 to-emerald-600',
      bg: 'bg-green-500',
      description: 'Send final response'
    }
  ];

  return (
    <aside className="w-80 shrink-0 bg-white dark:bg-gray-800 border-r border-gray-200 dark:border-gray-700 p-6 overflow-y-auto transition-colors flex flex-col hover:z-20 relative">
      <div className="mb-8">
        <h2 className="text-xl font-bold bg-gradient-to-r from-blue-600 to-cyan-600 dark:from-blue-400 dark:to-cyan-400 bg-clip-text text-transparent mb-2 shrink-0">
          Node Library
        </h2>
        <p className="text-sm text-gray-600 dark:text-gray-400">
          Drag and drop nodes to build your workflow
        </p>
      </div>

      <div className="space-y-4">
        {nodeTypes.map((node) => {
          const Icon = node.icon;
          return (
              <div
                key={node.type}
                className="group bg-white dark:bg-gray-800 border-2 border-gray-200 dark:border-gray-700 rounded-xl overflow-hidden cursor-move hover:shadow-xl hover:border-gray-300 dark:hover:border-gray-600 transition-all duration-200 hover:scale-[1.02] flex flex-col relative"
                draggable
                onDragStart={(e) => onDragStart(e, node.type)}
              >
                <div className={`h-1.5 w-full bg-gradient-to-r ${node.gradient}`} />
                <div className="p-4 flex flex-col gap-2">
                  <div className="flex items-center gap-3">
                    <div className={`p-2 bg-gradient-to-br ${node.gradient} rounded-lg shadow-md group-hover:scale-110 transition-transform duration-200`}>
                      <Icon size={18} className="text-white" strokeWidth={2.5} />
                    </div>
                    <div className="text-sm font-bold text-gray-900 dark:text-gray-100 flex-1">
                      {node.label}
                    </div>
                  </div>
                  <div className="text-xs text-gray-600 dark:text-gray-400 leading-relaxed mt-1">
                    {node.description}
                  </div>
                </div>
              </div>
          );
        })}
      </div>

      <div className="mt-8 p-4 bg-gradient-to-br from-blue-50 to-cyan-50 dark:from-blue-900/20 dark:to-cyan-900/20 border-2 border-blue-200 dark:border-blue-800 rounded-xl">
        <div className="flex items-center gap-2 mb-3">
          <Sparkles size={16} className="text-blue-600 dark:text-blue-400" />
          <h4 className="text-sm font-bold text-blue-900 dark:text-blue-300">Quick Guide</h4>
        </div>
        <ul className="text-xs text-blue-800 dark:text-blue-300 space-y-2">
          <li className="flex items-start gap-2">
            <span className="text-blue-500 dark:text-blue-400">1.</span>
            <span>Drag nodes onto canvas</span>
          </li>
          <li className="flex items-start gap-2">
            <span className="text-blue-500 dark:text-blue-400">2.</span>
            <span>Connect with handles</span>
          </li>
          <li className="flex items-start gap-2">
            <span className="text-blue-500 dark:text-blue-400">3.</span>
            <span>Click to configure</span>
          </li>
          <li className="flex items-start gap-2">
            <span className="text-blue-500 dark:text-blue-400">4.</span>
            <span>Export to YAML</span>
          </li>
        </ul>
      </div>
    </aside>
  );
}
