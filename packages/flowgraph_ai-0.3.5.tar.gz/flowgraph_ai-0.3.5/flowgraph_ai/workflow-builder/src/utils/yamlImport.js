import yaml from 'js-yaml';

// Helper to generate unique node IDs
let importNodeId = 1000;
const getId = () => `node_imported_${importNodeId++}`;

/**
 * Parses a FlowGraph-AI YAML string and converts it to ReactFlow nodes, edges, and metadata.
 * Supports all framework fields including guardrails, llm_params, hallucination_check, humanize, etc.
 * @param {string} yamlText 
 * @returns { nodes: Array, edges: Array, metadata: Object }
 */
export function parseFromYAML(yamlText) {
  try {
    const raw = yaml.load(yamlText);
    if (!raw || !raw.nodes) {
      throw new Error("Invalid YAML: Missing 'nodes' block.");
    }

    const nodes = [];
    const edges = [];
    const nodeNameMap = new Map();
    
    let yPos = 100;

    Object.entries(raw.nodes).forEach(([nodeName, nodeData]) => {
      const id = getId();
      nodeNameMap.set(nodeName, id);

      const rfType = nodeData.type === 'data_collector' ? 'dataCollector' :
                     nodeData.type === 'custom_action' ? 'customAction' :
                     nodeData.type === 'response' ? 'response' : 'dataCollector';

      const rfData = {
        label: nodeName,
        ...nodeData,
      };

      // Normalize custom_action args_from_state from object → array
      if (nodeData.type === 'custom_action') {
        if (nodeData.args_from_state && typeof nodeData.args_from_state === 'object' && !Array.isArray(nodeData.args_from_state)) {
          rfData.args_from_state = Object.entries(nodeData.args_from_state).map(([arg, stateKey]) => ({
            arg, stateKey
          }));
        }
      }

      // Normalize data_collector fields — ensure per-field validation is objects
      if (nodeData.type === 'data_collector' && nodeData.fields && Array.isArray(nodeData.fields)) {
        rfData.fields = nodeData.fields.map(f => ({
          field: f.field || '',
          description: f.description || '',
          default: f.default || '',
          validation: f.validation || null,
        }));
      }

      // Ensure humanize is parsed correctly
      if (nodeData.humanize !== undefined) {
        if (typeof nodeData.humanize === 'object') {
          rfData.humanize = nodeData.humanize.enabled !== false;
          if (nodeData.humanize.custom_prompt) {
            rfData.humanize_prompt = nodeData.humanize.custom_prompt;
          }
        } else {
          rfData.humanize = nodeData.humanize !== false;
        }
      }

      // Parse allow_intent_escape and extract custom_prompt if object
      if (nodeData.allow_intent_escape !== undefined) {
        if (typeof nodeData.allow_intent_escape === 'object' && nodeData.allow_intent_escape !== null) {
          rfData.allow_intent_escape = nodeData.allow_intent_escape.enabled !== false;
          if (nodeData.allow_intent_escape.custom_prompt) {
            rfData.intent_escape_prompt = nodeData.allow_intent_escape.custom_prompt;
          }
        } else {
          rfData.allow_intent_escape = nodeData.allow_intent_escape !== false;
        }
      }

      // Parse hallucination_check and extract custom_prompt if object
      if (nodeData.hallucination_check !== undefined) {
        if (typeof nodeData.hallucination_check === 'object' && nodeData.hallucination_check !== null) {
          rfData.hallucination_check = nodeData.hallucination_check.enabled !== false;
          if (nodeData.hallucination_check.custom_prompt) {
            rfData.hallucination_prompt = nodeData.hallucination_check.custom_prompt;
          }
        } else {
          rfData.hallucination_check = nodeData.hallucination_check !== false;
        }
      }

      // Ensure guardrails is an object
      if (nodeData.guardrails && typeof nodeData.guardrails === 'object') {
        rfData.guardrails = { ...nodeData.guardrails };
      }

      // Ensure llm_params is an object
      if (nodeData.llm_params && typeof nodeData.llm_params === 'object') {
        rfData.llm_params = { ...nodeData.llm_params };
      }

      // Extract inline style dimensions from ui_metadata if present
      const style = {};
      const nodeUiMeta = raw.ui_metadata?.nodes?.[nodeName] || {};
      if (nodeUiMeta.width) style.width = nodeUiMeta.width;
      if (nodeUiMeta.height) style.height = nodeUiMeta.height;

      nodes.push({
        id,
        type: rfType,
        position: { x: 400, y: yPos },
        data: rfData,
        style: Object.keys(style).length > 0 ? style : undefined
      });
      yPos += 180; 
    });

    const uiMetadataEdges = raw.ui_metadata?.edges || {};

    // Build edges based on routing
    Object.entries(raw.nodes).forEach(([nodeName, nodeData]) => {
      const sourceId = nodeNameMap.get(nodeName);

      if (nodeData.next) {
        const targetId = nodeNameMap.get(nodeData.next);
        if (targetId) buildEdge(sourceId, targetId, edges, 'normal', nodeName, nodeData.next, uiMetadataEdges);
      }

      if (nodeData.on_error) {
        const targetId = nodeNameMap.get(nodeData.on_error);
        if (targetId) buildEdge(sourceId, targetId, edges, 'error', nodeName, nodeData.on_error, uiMetadataEdges);
      }

      if (nodeData.on_max_retry) {
        const targetId = nodeNameMap.get(nodeData.on_max_retry);
        if (targetId) buildEdge(sourceId, targetId, edges, 'error', nodeName, nodeData.on_max_retry, uiMetadataEdges);
      }

      if (nodeData.routes && Array.isArray(nodeData.routes)) {
        nodeData.routes.forEach(route => {
          const targetName = route.next || route.default;
          if (targetName) {
            const targetId = nodeNameMap.get(targetName);
            if (targetId) buildEdge(sourceId, targetId, edges, 'route', nodeName, targetName, uiMetadataEdges);
          }
        });
      }
    });

    // Parse state fields
    const stateFields = [];
    if (raw.state && typeof raw.state === 'object') {
      Object.entries(raw.state).forEach(([name, type]) => {
        stateFields.push({ name, type: String(type) });
      });
    }

    return {
      nodes,
      edges,
      metadata: {
        workflow: raw.workflow || 'imported_workflow',
        description: raw.description || '',
        initialInputField: raw.initial_input_field || 'user_message',
        stateFields,
        globalConfig: (() => {
          const gc = {};
          if (raw.llm_config) gc.llm = raw.llm_config;
          if (raw.humanizer) gc.humanizer = raw.humanizer;
          if (raw.out_of_topic) gc.out_of_topic = raw.out_of_topic;
          return gc;
        })(),
      }
    };
  } catch (err) {
    console.error("YAML Parse Error:", err);
    throw err;
  }
}

function buildEdge(source, target, edgesArray, typeStr, sourceName, targetName, uiMetadataEdges) {
  const edgeKey = `${sourceName}->${targetName}`;
  const meta = uiMetadataEdges[edgeKey];
  
  const edgeTypeLabel = meta?.type || (typeStr === 'error' ? 'error' : typeStr === 'route' ? 'condition' : 'default');
  const edgeLabel = meta?.label || (typeStr === 'route' ? 'Condition' : '');

  edgesArray.push({
    id: `e_${source}-${target}-${typeStr}`,
    source,
    target,
    type: 'default', // uses LabeledEdge
    animated: true,
    markerEnd: { type: 'arrowclosed' },
    data: {
      label: edgeLabel,
      edgeType: edgeTypeLabel,
    },
  });
}
