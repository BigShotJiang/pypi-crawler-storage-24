import yaml from 'js-yaml';

export function validateWorkflow(nodes, edges) {
  const errors = [];
  const warnings = [];

  if (nodes.length === 0) {
    errors.push('Workflow must have at least one node');
    return { isValid: false, errors, warnings };
  }

  const startNodes = nodes.filter(node =>
    !edges.some(edge => edge.target === node.id)
  );

  if (startNodes.length === 0) {
    errors.push('Workflow must have a start node (node with no incoming connections)');
  }

  if (startNodes.length > 1) {
    warnings.push(`Multiple start nodes found (${startNodes.length}). Only the first will be used.`);
  }

  const responseNodes = nodes.filter(n => n.type === 'response');
  if (responseNodes.length === 0) {
    warnings.push('Workflow should have at least one response node');
  }

  nodes.forEach(node => {
    const nodeLabel = node.data.label || node.id;

    if (node.type === 'dataCollector') {
      if (!node.data.initial_message) {
        errors.push(`Data Collector "${nodeLabel}" missing initial message`);
      }
      if (!node.data.field && (!node.data.fields || node.data.fields.length === 0)) {
        errors.push(`Data Collector "${nodeLabel}" must have at least one field`);
      }
    } else if (node.type === 'customAction') {
      if (!node.data.method) {
        errors.push(`Custom Action "${nodeLabel}" missing method`);
      }
      if (!node.data.routes || node.data.routes.length === 0) {
        warnings.push(`Custom Action "${nodeLabel}" has no routes defined`);
      }
    } else if (node.type === 'response') {
      if (!node.data.output_field && !node.data.error_field) {
        warnings.push(`Response "${nodeLabel}" should have output_field or error_field`);
      }
    }

    const outgoingEdges = edges.filter(e => e.source === node.id);
    if (node.type !== 'response' && outgoingEdges.length === 0) {
      warnings.push(`Node "${nodeLabel}" has no outgoing connections`);
    }
  });

  const nodeNames = nodes.map(n => (n.data.label || n.id).replace(/\s+/g, '_').toLowerCase());
  const duplicates = nodeNames.filter((name, index) => nodeNames.indexOf(name) !== index);
  if (duplicates.length > 0) {
    errors.push(`Duplicate node names found: ${[...new Set(duplicates)].join(', ')}`);
  }

  return {
    isValid: errors.length === 0,
    errors,
    warnings
  };
}

export function exportToYAML(nodes, edges, workflowName, description) {
  const workflow = {
    workflow: workflowName || 'new_workflow',
    description: description || 'Generated workflow',
    initial_input_field: 'userQuery',
    state: {
      userQuery: 'str'
    },
    start_node: null,
    nodes: {}
  };

  const nodeMap = new Map();
  nodes.forEach(node => {
    nodeMap.set(node.id, { ...node.data, type: node.type });
  });

  const edgeMap = new Map();
  edges.forEach(edge => {
    if (!edgeMap.has(edge.source)) {
      edgeMap.set(edge.source, []);
    }
    edgeMap.get(edge.source).push(edge.target);
  });

  const startNodes = nodes.filter(node =>
    !edges.some(edge => edge.target === node.id)
  );
  if (startNodes.length > 0) {
    const startNodeLabel = startNodes[0].data.label || startNodes[0].id;
    workflow.start_node = startNodeLabel.replace(/\s+/g, '_').toLowerCase();
  }

  nodes.forEach(node => {
    const nodeData = node.data;
    const nodeName = (nodeData.label || node.id).replace(/\s+/g, '_').toLowerCase();
    const nodeConfig = {};

    if (node.type === 'dataCollector') {
      nodeConfig.type = 'data_collector';

      if (nodeData.role) {
        nodeConfig.role = nodeData.role;
      }

      if (nodeData.initial_message) {
        nodeConfig.initial_message = nodeData.initial_message;
      }

      if (nodeData.fields && Array.isArray(nodeData.fields) && nodeData.fields.length > 0) {
        nodeConfig.fields = nodeData.fields.map(f => {
          const fieldConfig = {
            field: f.field,
            description: f.description
          };
          if (f.validation) {
            fieldConfig.validation = f.validation;
          }
          return fieldConfig;
        });

        nodeData.fields.forEach(f => {
          if (f.field && !workflow.state[f.field]) {
            workflow.state[f.field] = 'str';
          }
        });
      } else {
        if (nodeData.field) {
          nodeConfig.field = nodeData.field;
          if (!workflow.state[nodeData.field]) {
            workflow.state[nodeData.field] = 'str';
          }
        }

        if (nodeData.description) {
          nodeConfig.description = nodeData.description;
        }
      }

      if (nodeData.max_retry) {
        nodeConfig.max_retry = nodeData.max_retry;
      }

      const nextNodes = edgeMap.get(node.id) || [];
      if (nextNodes.length > 0) {
        const targetNode = nodeMap.get(nextNodes[0]);
        if (targetNode) {
          const targetLabel = targetNode.label || nextNodes[0];
          nodeConfig.next = targetLabel.replace(/\s+/g, '_').toLowerCase();
        }
      }

      if (nodeData.validation) {
        nodeConfig.validation = nodeData.validation;
      }

      if (nodeData.allow_intent_escape) {
        nodeConfig.allow_intent_escape = nodeData.allow_intent_escape;
      }

      // allow_node_rollback: emit as bool OR dict {enabled, custom_prompt}
      const rollback = nodeData.allow_node_rollback;
      if (rollback === true) {
        nodeConfig.allow_node_rollback = true;
      } else if (rollback && typeof rollback === 'object' && rollback.enabled) {
        if (rollback.custom_prompt && rollback.custom_prompt.trim()) {
          nodeConfig.allow_node_rollback = {
            enabled: true,
            custom_prompt: rollback.custom_prompt.trim(),
          };
        } else {
          nodeConfig.allow_node_rollback = true;
        }
      }

    } else if (node.type === 'customAction') {
      nodeConfig.type = 'custom_action';

      if (nodeData.method) {
        nodeConfig.method = nodeData.method;
      }

      if (nodeData.result_field) {
        nodeConfig.result_field = nodeData.result_field;
        if (!workflow.state[nodeData.result_field]) {
          workflow.state[nodeData.result_field] = 'str';
        }
      }

      if (nodeData.routes && Array.isArray(nodeData.routes) && nodeData.routes.length > 0) {
        nodeConfig.routes = nodeData.routes.map(r => {
          if (r.default !== undefined) {
            return { default: r.next };
          }
          return { value: r.value, next: r.next };
        });
      }

    } else if (node.type === 'response') {
      nodeConfig.type = 'response';

      if (nodeData.output_field) {
        nodeConfig.output_field = nodeData.output_field;
      }

      if (nodeData.error_field) {
        nodeConfig.error_field = nodeData.error_field;
      }

      if (nodeData.template) {
        nodeConfig.template = nodeData.template;
      }
    }

    workflow.nodes[nodeName] = nodeConfig;
  });

  return yaml.dump(workflow, {
    indent: 2,
    lineWidth: -1,
    noRefs: true,
    sortKeys: false
  });
}
