import React from 'react';
import { Handle, Position } from 'reactflow';
import { Zap, GitBranch } from 'lucide-react';
import { NodeResizer } from '@reactflow/node-resizer';
import '@reactflow/node-resizer/dist/style.css';

export default function CustomActionNode({ data, selected }) {
  return (
    <div className={`w-full h-full bg-white dark:bg-gray-800 border-2 rounded-xl shadow-lg min-w-[220px] min-h-[140px] flex flex-col transition-shadow duration-200 ${
      selected
        ? 'border-orange-500 shadow-orange-500/30 shadow-xl'
        : 'border-gray-200 dark:border-gray-700 hover:shadow-xl'
    }`}>
      <NodeResizer 
        color="#f97316" 
        isVisible={selected} 
        minWidth={220} 
        minHeight={140} 
      />
      <Handle
        type="target"
        position={Position.Top}
        className="!bg-orange-500 !w-3 !h-3 !border-2 !border-white dark:!border-gray-800"
      />

      <div className="bg-gradient-to-r from-orange-500 to-amber-600 p-3.5 rounded-t-xl">
        <div className="flex items-center gap-2.5 text-white">
          <div className="p-1.5 bg-white/20 rounded-lg backdrop-blur-sm">
            <Zap size={16} strokeWidth={2.5} />
          </div>
          <div className="flex-1">
            <span className="font-semibold text-sm block">Custom Action</span>
            <span className="text-xs text-orange-100 opacity-90">Business Logic</span>
          </div>
        </div>
      </div>

      <div className="p-3.5 space-y-2.5 flex-1 overflow-auto">
        <div className="text-sm font-semibold text-gray-900 dark:text-gray-100">
          {data.label}
        </div>

        {data.method && (
          <div className="space-y-1">
            <div className="text-xs text-gray-500 dark:text-gray-400">Method</div>
            <div className="font-mono text-xs bg-orange-50 dark:bg-orange-900/30 text-orange-700 dark:text-orange-300 px-2 py-1 rounded break-all">
              {data.method}
            </div>
          </div>
        )}

        {data.routes && data.routes.length > 0 && (
          <div className="flex items-center gap-2 text-xs text-gray-500 dark:text-gray-400">
            <GitBranch size={12} />
            <span className="font-medium">{data.routes.length} routes</span>
          </div>
        )}

        {data.result_field && (
          <div className="flex items-center gap-2 text-xs text-gray-600 dark:text-gray-400">
            <div className="w-1.5 h-1.5 rounded-full bg-orange-500"></div>
            <span className="font-mono bg-gray-50 dark:bg-gray-700/50 px-2 py-0.5 rounded">
              {data.result_field}
            </span>
          </div>
        )}

        {data.args_from_state && data.args_from_state.length > 0 && (
          <div className="flex items-center gap-2 text-xs text-orange-600 dark:text-orange-400">
            <span className="font-medium">{data.args_from_state.length} arg(s) mapped</span>
          </div>
        )}

        {data.next && (
          <div className="flex items-center gap-2 text-xs text-gray-600 dark:text-gray-400">
            <div className="w-1.5 h-1.5 rounded-full bg-purple-500"></div>
            <span className="font-mono bg-gray-50 dark:bg-gray-700/50 px-2 py-0.5 rounded">
              next: {data.next}
            </span>
          </div>
        )}

        {data.on_error && (
          <div className="flex items-center gap-2 text-xs text-red-600 dark:text-red-400">
            <div className="w-1.5 h-1.5 rounded-full bg-red-500"></div>
            <span className="font-mono bg-red-50 dark:bg-red-900/30 px-2 py-0.5 rounded">
              err: {data.on_error}
            </span>
          </div>
        )}
      </div>

      <Handle
        type="source"
        position={Position.Bottom}
        className="!bg-orange-500 !w-3 !h-3 !border-2 !border-white dark:!border-gray-800"
      />
    </div>
  );
}
