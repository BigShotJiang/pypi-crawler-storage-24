import React from 'react';
import { Handle, Position } from 'reactflow';
import { MessageSquare, FileText, CheckCircle2, AlertCircle } from 'lucide-react';
import { NodeResizer } from '@reactflow/node-resizer';
import '@reactflow/node-resizer/dist/style.css';

export default function ResponseNode({ data, selected }) {
  const type = data.response_type || 'default';
  
  const themes = {
    default: {
      border: 'border-green-500',
      shadow: 'shadow-green-500/30',
      header: 'from-green-500 to-emerald-600',
      icon: <MessageSquare size={16} strokeWidth={2.5} />,
      labelBadgeBg: 'bg-green-50 dark:bg-green-900/30',
      labelBadgeText: 'text-green-700 dark:text-green-300',
      handle: '!bg-green-500',
      dot: 'bg-green-500',
      resizer: '#22c55e'
    },
    success: {
      border: 'border-emerald-500',
      shadow: 'shadow-emerald-500/30',
      header: 'from-emerald-500 to-teal-500',
      icon: <CheckCircle2 size={16} strokeWidth={2.5} />,
      labelBadgeBg: 'bg-emerald-50 dark:bg-emerald-900/30',
      labelBadgeText: 'text-emerald-700 dark:text-emerald-300',
      handle: '!bg-emerald-500',
      dot: 'bg-emerald-500',
      resizer: '#10b981'
    },
    error: {
      border: 'border-red-500',
      shadow: 'shadow-red-500/30',
      header: 'from-red-500 to-rose-600',
      icon: <AlertCircle size={16} strokeWidth={2.5} />,
      labelBadgeBg: 'bg-red-50 dark:bg-red-900/30',
      labelBadgeText: 'text-red-700 dark:text-red-300',
      handle: '!bg-red-500',
      dot: 'bg-red-500',
      resizer: '#ef4444'
    }
  };
  
  const t = themes[type] || themes.default;  // Re-enabled assignment to fix white screen crash

  return (
    <div className={`w-full h-full bg-white dark:bg-gray-800 border-2 rounded-xl shadow-lg min-w-[220px] min-h-[140px] flex flex-col transition-shadow duration-200 ${
      selected
        ? `${t.border} ${t.shadow} shadow-xl`
        : 'border-gray-200 dark:border-gray-700 hover:shadow-xl'
    }`}>
      <NodeResizer 
        color={t.resizer} 
        isVisible={selected} 
        minWidth={220} 
        minHeight={140} 
      />
      <Handle
        type="target"
        position={Position.Top}
        className={`${t.handle} !w-3 !h-3 !border-2 !border-white dark:!border-gray-800`}
      />

      <div className={`bg-gradient-to-r ${t.header} p-3.5 rounded-t-xl`}>
        <div className="flex items-center gap-2.5 text-white">
          <div className="p-1.5 bg-white/20 rounded-lg backdrop-blur-sm">
            {t.icon}
          </div>
          <div className="flex-1">
            <span className="font-semibold text-sm block">Response</span>
            <span className="text-xs text-white/90">Final Output</span>
          </div>
        </div>
      </div>

      <div className="p-3.5 space-y-2.5 flex-1 overflow-auto">
        <div className="text-sm font-semibold text-gray-900 dark:text-gray-100 flex items-center gap-2">
          <span>{data.label}</span>
          {type !== 'default' && (
            <span className={`px-1.5 py-0.5 rounded text-[10px] font-bold uppercase tracking-wider ${
              type === 'success' ? 'bg-emerald-100 text-emerald-700 dark:bg-emerald-900/40 dark:text-emerald-400' :
              'bg-red-100 text-red-700 dark:bg-red-900/40 dark:text-red-400'
            }`}>
              {type}
            </span>
          )}
        </div>

        {data.output_field && (
          <div className="flex items-center gap-2 text-xs text-gray-600 dark:text-gray-400">
            <div className={`w-1.5 h-1.5 rounded-full ${t.dot}`}></div>
            <span className={`font-mono px-2 py-0.5 rounded ${t.labelBadgeBg} ${t.labelBadgeText}`}>
              {data.output_field}
            </span>
          </div>
        )}

        {data.error_field && (
          <div className="flex items-center gap-2 text-xs text-gray-600 dark:text-gray-400">
            <div className={`w-1.5 h-1.5 rounded-full ${t.dot}`}></div>
            <span className={`font-mono px-2 py-0.5 rounded ${t.labelBadgeBg} ${t.labelBadgeText}`}>
              err: {data.error_field}
            </span>
          </div>
        )}

        {data.template && (
          <div className="space-y-1">
            <div className="flex items-center gap-1.5 text-xs text-gray-500 dark:text-gray-400">
              <FileText size={12} />
              <span>Template</span>
            </div>
            <div className="font-mono text-xs bg-gray-50 dark:bg-gray-700/50 px-2 py-1.5 rounded break-words line-clamp-2">
              {data.template}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
