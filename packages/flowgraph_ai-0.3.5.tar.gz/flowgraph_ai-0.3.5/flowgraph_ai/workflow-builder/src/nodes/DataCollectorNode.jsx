import React from 'react';
import { Handle, Position } from 'reactflow';
import { Database, CheckCircle2 } from 'lucide-react';
import { NodeResizer } from '@reactflow/node-resizer';
import '@reactflow/node-resizer/dist/style.css';

export default function DataCollectorNode({ data, selected }) {
  return (
    <div className={`w-full h-full bg-white dark:bg-gray-800 border-2 rounded-xl shadow-lg min-w-[220px] min-h-[140px] flex flex-col transition-shadow duration-200 ${
      selected
        ? 'border-blue-500 shadow-blue-500/30 shadow-xl'
        : 'border-gray-200 dark:border-gray-700 hover:shadow-xl'
    }`}>
      <NodeResizer 
        color="#3b82f6" 
        isVisible={selected} 
        minWidth={220} 
        minHeight={140} 
      />
      <Handle
        type="target"
        position={Position.Top}
        className="!bg-blue-500 !w-3 !h-3 !border-2 !border-white dark:!border-gray-800"
      />

      <div className="bg-gradient-to-r from-blue-500 to-blue-600 p-3.5 rounded-t-xl">
        <div className="flex items-center gap-2.5 text-white">
          <div className="p-1.5 bg-white/20 rounded-lg backdrop-blur-sm">
            <Database size={16} strokeWidth={2.5} />
          </div>
          <div className="flex-1">
            <span className="font-semibold text-sm block">Data Collector</span>
            <span className="text-xs text-blue-100 opacity-90">User Input</span>
          </div>
        </div>
      </div>

      <div className="p-3.5 space-y-2.5 flex-1 overflow-auto">
        <div className="text-sm font-semibold text-gray-900 dark:text-gray-100">
          {data.label}
        </div>

        {data.field && !data.fields && (
          <div className="flex items-center gap-2 text-xs text-gray-600 dark:text-gray-400">
            <div className="w-1.5 h-1.5 rounded-full bg-blue-500"></div>
            <span className="font-mono bg-blue-50 dark:bg-blue-900/30 px-2 py-0.5 rounded text-blue-700 dark:text-blue-300">
              {data.field}
            </span>
          </div>
        )}

        {data.fields && data.fields.length > 0 && (
          <div className="space-y-1.5">
            <div className="flex items-center gap-2 text-xs text-gray-500 dark:text-gray-400">
              <CheckCircle2 size={12} />
              <span className="font-medium">{data.fields.length} fields</span>
            </div>
            <div className="flex flex-wrap gap-1">
              {data.fields.slice(0, 3).map((field, idx) => (
                <span
                  key={idx}
                  className="text-xs font-mono bg-blue-50 dark:bg-blue-900/30 text-blue-600 dark:text-blue-400 px-1.5 py-0.5 rounded"
                >
                  {field.field}
                </span>
              ))}
              {data.fields.length > 3 && (
                <span className="text-xs text-gray-500 dark:text-gray-400">
                  +{data.fields.length - 3} more
                </span>
              )}
            </div>
          </div>
        )}

        {data.tools && data.tools.length > 0 && (
          <div className="flex items-center gap-1.5 text-xs">
            <div className="w-1 h-1 rounded-full bg-indigo-500"></div>
            <span className="text-gray-600 dark:text-gray-400 font-medium">{data.tools.length} Tool(s)</span>
          </div>
        )}

        {data.validation?.method && (
          <div className="flex items-center gap-1.5 text-xs">
            <div className="w-1 h-1 rounded-full bg-green-500"></div>
            <span className="text-gray-600 dark:text-gray-400">Validated</span>
          </div>
        )}
      </div>

      <Handle
        type="source"
        position={Position.Bottom}
        className="!bg-blue-500 !w-3 !h-3 !border-2 !border-white dark:!border-gray-800"
      />
    </div>
  );
}
