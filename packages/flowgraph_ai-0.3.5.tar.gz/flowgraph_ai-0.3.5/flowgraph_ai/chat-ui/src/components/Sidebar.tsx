"use client";

import React, { useState, useEffect } from "react";
import { fetchWorkflows, Workflow } from "@/lib/api";
import { Hexagon, MessageSquare, Loader2 } from "lucide-react";

interface SidebarProps {
  onNewConversation: () => void;
  selectedWorkflow: string;
  setSelectedWorkflow: (Workflow: string) => void;
  activeWorkflow: string | null;
  status: string | null;
}

export function Sidebar({
  onNewConversation,
  selectedWorkflow,
  setSelectedWorkflow,
  activeWorkflow,
  status,
}: SidebarProps) {
  const [workflows, setWorkflows] = useState<Workflow[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchWorkflows().then((res) => {
      setWorkflows(res);
      setLoading(false);
    });
  }, []);

  return (
    <div className="w-[30%] min-w-[300px] max-w-[420px] h-full border-r border-[var(--border)] bg-[var(--surface)] flex flex-col relative z-10 text-[var(--foreground)]">
      {/* Header */}
      <div className="h-[60px] px-4 bg-[var(--surface-header)] flex items-center justify-between flex-shrink-0">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-full bg-[var(--border)] flex items-center justify-center text-[var(--muted)] overflow-hidden">
            <Hexagon size={24} strokeWidth={1.5} />
          </div>
          <span className="font-semibold text-[var(--foreground)] text-base">FlowGraph Workflows</span>
        </div>
        <div className="flex items-center gap-2">
          <button
            onClick={onNewConversation}
            className="w-10 h-10 rounded-full flex items-center justify-center text-[var(--muted)] hover:bg-[var(--surface-hover)] transition-colors"
            title="New Chat"
          >
            <MessageSquare size={20} />
          </button>
        </div>
      </div>

      {/* Search / Filter Area */}
      <div className="p-2 border-b border-[var(--border)] bg-[var(--surface)]">
        <div className="bg-[var(--surface-header)] rounded-lg flex items-center px-3 py-1.5 focus-within:bg-[var(--background)] transition-colors border-b-2 border-transparent focus-within:border-[var(--accent)]">
          <div className="text-[var(--muted)] mr-2">
            <svg viewBox="0 0 24 24" height="20" width="20" preserveAspectRatio="xMidYMid meet" fill="none" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"></path></svg>
          </div>
          <select
            value={selectedWorkflow}
            onChange={(e) => setSelectedWorkflow(e.target.value)}
            className="w-full bg-transparent text-[var(--foreground)] text-sm outline-none cursor-pointer placeholder-[var(--muted)]"
          >
            <option value="Auto-detect">Search logic / Auto-detect</option>
            {workflows.map((w) => (
              <option key={w.name} value={w.name}>
                {w.name}
              </option>
            ))}
          </select>
        </div>
      </div>

      {/* Content */}
      <div className="flex-1 overflow-y-auto w-full bg-[var(--surface)]">
        {loading ? (
          <div className="flex items-center justify-center p-8 text-sm text-[var(--muted)]">
            <Loader2 size={24} className="animate-spin text-[var(--accent)]" />
          </div>
        ) : (
          <div className="flex flex-col">
            {/* Current Active Item */}
            <div 
              className={`flex items-center gap-3 px-3 py-3 cursor-pointer transition-colors ${activeWorkflow ? 'bg-[var(--surface-hover)]' : 'hover:bg-[var(--surface-hover)]'}`}
              onClick={activeWorkflow ? undefined : onNewConversation}
            >
              <div className="w-[48px] h-[48px] rounded-full bg-[var(--surface-header)] border border-[var(--border)] flex items-center justify-center text-[var(--muted)] flex-shrink-0 overflow-hidden">
                <Hexagon size={24} strokeWidth={1.5} />
              </div>
              <div className="flex-1 min-w-0 border-b border-[var(--border)] pb-3 pt-1 flex flex-col justify-center h-full">
                <div className="flex justify-between items-baseline mb-0.5">
                  <h4 className="text-[17px] text-[var(--foreground)] truncate leading-5">
                    {activeWorkflow || "New Conversation"}
                  </h4>
                  <span className="text-xs text-[var(--muted)] ml-2 flex-shrink-0">
                    {new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                  </span>
                </div>
                <div className="flex items-center gap-1.5 min-w-0">
                  <span className="text-sm text-[var(--muted)] truncate leading-5 flex-1 block">
                    {status === "waiting_input" ? "Bot: Awaiting your input..." : status === "completed" ? "Bot: Sequence terminated." : "Start a new trace..."}
                  </span>
                  {status === "waiting_input" && (
                    <div className="w-[18px] h-[18px] rounded-full bg-[var(--accent)] text-[var(--accent-fg)] text-[10px] flex items-center justify-center font-bold">1</div>
                  )}
                </div>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
