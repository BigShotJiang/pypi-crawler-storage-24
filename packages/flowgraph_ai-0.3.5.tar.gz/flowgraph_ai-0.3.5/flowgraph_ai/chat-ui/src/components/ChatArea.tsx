"use client";

import React, { useState, useRef, useEffect } from "react";
import { Send, Hexagon, Loader2 } from "lucide-react";
import ReactMarkdown from "react-markdown";

export interface Message {
  role: "user" | "assistant";
  content: string;
}

interface ChatAreaProps {
  messages: Message[];
  onSendMessage: (msg: string) => void;
  isLoading: boolean;
}

export function ChatArea({ messages, onSendMessage, isLoading }: ChatAreaProps) {
  const [input, setInput] = useState("");
  const endOfMessagesRef = useRef<HTMLDivElement>(null);

  // Auto-scroll to bottom when new messages arrive
  useEffect(() => {
    endOfMessagesRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages, isLoading]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!input.trim() || isLoading) return;
    onSendMessage(input.trim());
    setInput("");
  };

  return (
    <div className="flex-1 flex flex-col h-full bg-[var(--background)] relative w-full text-[var(--foreground)]">
      {/* WhatsApp style faint background pattern */}
      <div 
        className="absolute inset-0 pointer-events-none opacity-[0.05] dark:opacity-[0.03] z-0"
        style={{ backgroundImage: 'radial-gradient(circle at center, currentColor 1px, transparent 1px)', backgroundSize: '24px 24px' }}
      ></div>

      {/* Top Header (Contact Context) */}
      <div className="h-[60px] px-4 bg-[var(--surface-header)] flex items-center justify-between relative z-10">
        <div className="flex items-center gap-4 cursor-pointer">
          <div className="w-10 h-10 rounded-full bg-[var(--border)] flex items-center justify-center text-[var(--muted)] overflow-hidden">
            <Hexagon size={24} strokeWidth={1.5} />
          </div>
          <div className="flex flex-col">
            <h2 className="font-medium text-[16px] text-[var(--foreground)] leading-5">FlowGraph AI Support</h2>
            <p className="text-[13px] text-[var(--muted)] leading-4">online</p>
          </div>
        </div>
      </div>

      {/* Chat History Area */}
      <div className="flex-1 overflow-y-auto px-4 sm:px-[5%] py-4 flex flex-col gap-2 relative z-10 w-full mb-1">
        {messages.length === 0 ? (
          <div className="flex-1 flex flex-col items-center justify-center h-full w-full">
            <div className="bg-[var(--surface)] text-[var(--foreground)] rounded-lg p-3 max-w-sm text-center shadow-sm text-[12.5px] leading-5">
              Messages and workflows are end-to-end traced. No one outside of this chat, not even FlowGraph-AI, can read or listen to them. Click to learn more.
            </div>
          </div>
        ) : (
          messages.map((msg, idx) => (
            <div
              key={idx}
              className={`flex w-full mb-[2px] ${msg.role === "user" ? "justify-end" : "justify-start"}`}
            >
              <div
                className={`max-w-[85%] sm:max-w-[65%] px-[9px] py-[6px] rounded-md shadow-sm text-[14.2px] leading-[19px] relative ${
                  msg.role === "user"
                    ? "bg-[var(--bubble-user)] text-[var(--foreground)] rounded-tr-none"
                    : "bg-[var(--bubble-bot)] text-[var(--foreground)] rounded-tl-none"
                }`}
              >
                {/* Tail SVG equivalent would go here if needed, but css rounded corners work well */}
                {msg.role === "assistant" ? (
                  <div className="prose prose-sm dark:prose-invert max-w-none break-words">
                    <ReactMarkdown>{msg.content}</ReactMarkdown>
                  </div>
                ) : (
                  <div className="whitespace-pre-wrap break-words">{msg.content}</div>
                )}
                <div className="w-full text-right mt-1 mb-[-4px] h-[15px] flex justify-end items-center gap-1">
                  <span className="text-[11px] text-[var(--muted)]">
                    {new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                  </span>
                  {msg.role === "user" && (
                    <svg viewBox="0 0 16 15" width="16" height="15" className="text-[#53bdeb]"><path fill="currentColor" d="M15.01 3.316l-.478-.372a.365.365 0 0 0-.51.063L8.666 9.879a.32.32 0 0 1-.484.033l-.358-.325a.319.319 0 0 0-.484.032l-.378.483a.418.418 0 0 0 .036.541l1.32 1.266c.143.14.361.125.484-.033l6.272-8.048a.366.366 0 0 0-.064-.512zm-4.1 0l-.478-.372a.365.365 0 0 0-.51.063L4.566 9.879a.32.32 0 0 1-.484.033L1.891 7.769a.366.366 0 0 0-.515.006l-.423.433a.364.364 0 0 0 .006.514l3.258 3.185c.143.14.361.125.484-.033l6.272-8.048a.365.365 0 0 0-.063-.51z"></path></svg>
                  )}
                </div>
              </div>
            </div>
          ))
        )}

        {isLoading && (
          <div className="flex w-full justify-start">
            <div className="bg-[var(--surface-hover)] text-[var(--foreground)] px-4 py-3 rounded-2xl rounded-bl-none shadow-sm flex items-center gap-3">
              <Loader2 size={16} className="animate-spin text-[var(--accent)]" />
              <span className="text-sm text-[var(--muted)]">Typing...</span>
            </div>
          </div>
        )}
        <div ref={endOfMessagesRef} className="h-2" />
      </div>

      {/* Input Area */}
      <div className="bg-[var(--surface-header)] px-4 py-3 min-h-[62px] flex items-end justify-center relative z-20">
        <form onSubmit={handleSubmit} className="flex gap-2 w-full max-w-[100%] items-end">
          <div className="flex-1 bg-[var(--surface)] text-[var(--foreground)] rounded-lg flex items-center min-h-[42px] px-3 shadow-sm border border-[var(--border)]">
            <input
              type="text"
              value={input}
              onChange={(e) => setInput(e.target.value)}
              placeholder="Type a message"
              className="w-full bg-transparent border-none outline-none py-[9px] text-[15px] placeholder-[var(--muted)]"
              disabled={isLoading}
            />
          </div>
          <button
            type="submit"
            disabled={!input.trim() || isLoading}
            className={`w-[42px] h-[42px] flex-shrink-0 rounded-full flex items-center justify-center transition-all ${
              input.trim() && !isLoading 
                ? "bg-[var(--accent)] text-white hover:bg-emerald-600" 
                : "bg-[var(--surface-hover)] text-[var(--muted)] border border-[var(--border)]"
            } shadow-sm`}
          >
             <Send size={18} className={`${input.trim() && !isLoading ? 'ml-0.5' : ''}`} />
          </button>
        </form>
      </div>
    </div>
  );
}
