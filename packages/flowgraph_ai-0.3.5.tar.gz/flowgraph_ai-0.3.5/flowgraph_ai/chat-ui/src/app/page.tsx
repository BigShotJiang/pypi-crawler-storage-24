"use client";

import React, { useState } from "react";
import { Sidebar } from "@/components/Sidebar";
import { ChatArea, Message } from "@/components/ChatArea";
import { startWorkflow, sendMessage } from "@/lib/api";

export default function ChatApp() {
  const [messages, setMessages] = useState<Message[]>([]);
  const [selectedWorkflow, setSelectedWorkflow] = useState<string>("Auto-detect");
  const [activeWorkflow, setActiveWorkflow] = useState<string | null>(null);
  const [threadId, setThreadId] = useState<string | null>(null);
  const [status, setStatus] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(false);

  const handleNewConversation = () => {
    setMessages([]);
    setThreadId(null);
    setActiveWorkflow(null);
    setStatus(null);
  };

  const handleSendMessage = async (userText: string) => {
    // Add user message to UI
    const newMessages: Message[] = [...messages, { role: "user", content: userText }];
    setMessages(newMessages);
    setIsLoading(true);

    try {
      let data;
      if (!threadId) {
        // Start a new workflow
        const sessionId = crypto.randomUUID().replace(/-/g, "");
        data = await startWorkflow(userText, selectedWorkflow, sessionId);
      } else {
        // Continue existing workflow
        data = await sendMessage(userText, threadId);
      }

      setStatus(data.status);
      if (data.workflow_name) {
        setActiveWorkflow(data.workflow_name);
      }

      let replyText = "";
      if (data.status === "waiting_input") {
        setThreadId(data.session_id);
        replyText = data.question?.question || "Awaiting secondary parameters.";
      } else if (data.status === "completed") {
        setThreadId(data.session_id); // Keep the thread open so follow ups can be triggered by the user if the backend supports it!
        replyText = data.output || "Routine executed successfully. Terminating sequence.";
      } else if (data.status === "follow_up") {
        setThreadId(data.session_id); // keep thread open for continuous conversation
        replyText = data.output || "Follow up response generated.";
      } else if (data.status === "error") {
        setThreadId(null);
        replyText = `Error: ${data.error || "Unknown error occurred."}`;
      } else {
        setThreadId(null);
        replyText = `System Status [${data.status}]: ${data.output || "No output provided"}`;
      }

      setMessages([...newMessages, { role: "assistant", content: replyText }]);
    } catch (error: any) {
      setMessages([...newMessages, { role: "assistant", content: `Network Error: ${error.message}` }]);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="flex h-screen w-full font-sans overflow-hidden bg-[var(--background)]">
      <Sidebar
        onNewConversation={handleNewConversation}
        selectedWorkflow={selectedWorkflow}
        setSelectedWorkflow={setSelectedWorkflow}
        activeWorkflow={activeWorkflow}
        status={status}
      />
      <ChatArea 
        messages={messages} 
        onSendMessage={handleSendMessage} 
        isLoading={isLoading} 
      />
    </div>
  );
}
