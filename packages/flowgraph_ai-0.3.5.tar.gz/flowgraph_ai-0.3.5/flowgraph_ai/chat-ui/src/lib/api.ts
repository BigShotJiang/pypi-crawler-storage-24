export const API_URL = process.env.NEXT_PUBLIC_API_URL || "http://127.0.0.1:8000";

export interface Workflow {
  name: string;
  description?: string;
}

export async function fetchWorkflows(): Promise<Workflow[]> {
  try {
    const res = await fetch(`${API_URL}/workflows`);
    if (!res.ok) throw new Error("Failed to fetch workflows");
    const data = await res.json();
    return data.workflows || [];
  } catch (err) {
    console.error(err);
    return [];
  }
}

export async function startWorkflow(message: string, workflowName?: string, sessionId?: string) {
  const payload: any = { session_id: sessionId, message };
  if (workflowName && workflowName !== "Auto-detect") {
    payload.workflow_name = workflowName;
  }
  const res = await fetch(`${API_URL}/workflow/start`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(payload),
  });
  if (!res.ok) throw new Error("Failed to start workflow");
  return res.json();
}

export async function sendMessage(message: string, sessionId: string) {
  const res = await fetch(`${API_URL}/message`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ session_id: sessionId, message }),
  });
  if (!res.ok) throw new Error("Failed to send message");
  return res.json();
}
