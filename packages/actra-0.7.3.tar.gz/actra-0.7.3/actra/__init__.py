from importlib.metadata import version, PackageNotFoundError

from .policy import Actra, Policy
from .runtime import ActraRuntime
from .types import Action, Actor, Snapshot, Decision, Context
from .errors import ActraError, ActraPolicyError, ActraSchemaError
from .events import DecisionEvent
from .integrations.mcp.context import ActraMCPContext as ActraContext

try:
    __version__ = version("actra")
except PackageNotFoundError:
    __version__ = "0.0.0"

load_policy_from_file = Actra.from_files
load_policy_from_string = Actra.from_strings
compiler_version = Actra.compiler_version

__all__ = [
    "Actra",
    "Policy",
    "ActraRuntime",
    "DecisionEvent",
    "ActraContext",

    # Errors
    "ActraError",
    "ActraPolicyError",
    "ActraSchemaError",

    # Runtime types
    "Action",
    "Actor",
    "Snapshot",
    "Decision",
    "Context",
    
    # Helpers
    "load_policy_from_file",
    "load_policy_from_string",
    "compiler_version",

    "__version__",
]