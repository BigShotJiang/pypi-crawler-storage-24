import sys
import setuptools
import wheel
from setuptools import setup, find_packages

RED = "\033[91m"
YELLOW = "\033[93m"
CYAN = "\033[96m"
RESET = "\033[0m"

README_LINK = "\033]8;;https://github.com/zackcurry/Beam-Me-Up-SHU-y/blob/main/README.md\033\\click here\033]8;;\033\\"

if tuple(int(x) for x in setuptools.__version__.split(".")[:2]) >= (65, 0):
    sys.exit(
        f"\n"
        f"{RED}SETUP FAILED{RESET}\n"
        f"{YELLOW}gym==0.21 requires older build tools. Run these commands first:{RESET}\n\n"
        f"{CYAN}   pip install 'setuptools<65.0' 'wheel<0.38' 'pip<23.0'{RESET}\n"
        f"{CYAN}   pip install -e .{RESET}\n\n"
        f"{YELLOW}For full setup instructions see the README: {README_LINK}{RESET}\n"
    )

setup(
    name="beam_me_up_shu_y",
    version="0.1.2",
    description="TORCS AI racing bot using RL and IBM Granite Enhancements",
    readme="README.md",
    python_requires=">=3.10,<3.11",
    authors=[
        "DAN2026 : Reinforcement Learning Source",
        "Griffin-MK : Reinforcement Learning Source",
        "zackcurry : Beam TORCS",
        "Hen2001 : Beam TORCS",
        "Lewis-Middleton-c4019290 : Beam TORCS",
    ],
    packages=find_packages(where="src"),
    package_dir={"": "src"},
    install_requires=[
        "stable-baselines3[extra]==1.8.0",
        "scipy",
        "pygame",
        "pytest",
        "questionary"
    ],
    entry_points={
        'console_scripts': [
            'bmu = bmu.main:main', 
        ],
    }
)