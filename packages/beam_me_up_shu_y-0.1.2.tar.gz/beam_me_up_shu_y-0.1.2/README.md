# Beam Me Up SHU'y

<br><br>
Student led team for engaging with a TORCS AI bot racing competition along with implementation of several other features. Features to implement are:
- Chatbot
- Lap analysis
- AI race bot (RL)
- Live Commentary

### Documentation

Documentation will be provided inside the repository.

### Note 

This repository does come with vtorcs for the scr patch. However our version of BEAM TORCS is at this repository with setup details : https://github.com/Hen2001/Beam-Torcs . This version comes with AI features.

<br><br>

## How to set up the project environment

### Prerequisites

We are assuming you installed VS Code and are currently on Windows OS.

Ensure you have installed python extension for coding in a python environment and the WSL extension.

If you are on Ubuntu ignore the setup for WSL.

### WSL Setup

Run this command in PowerShell as ADMIN to install WSL

```bash
wsl --install
```
Then once installed. Reboot.

Once rebooted WSL should open and start installing Ubuntu automatically. (The correct distro)

If for some reason WSL installs the incorrect Linux distro run this command to see available distros.

```bash
wsl.exe --list --online
```
Find Ubuntu and run the command 

```bash
wsl.exe --install [distro]
```

Once downloaded and installed. You will be promoted to enter a username and password these are your choice.

Once logged in. Now we need to update our system. Run the commands below.

```bash
sudo apt update
```

```bash
sudo apt upgrade
```

Now we have updated our system, it's time to register our GitHub accounts to our WSL environment, so we can clone the project.

```bash
git config --global user.email "Email linked to github goes here"
```
```bash
git config --global user.name "User name linked to github goes here"
```

Once done this should allow you to clone from this system.

### Development Environment

Assuming you have VS Code + WSL installed. Navigate to VS Code and open it. Open a new window via File > New Window. Close old window.

Now at the bottom left and on the left sidebar you should see remote explorer/remote window. Click on this then select your distro to connect to.

This will download a server so give it some time. Once done navigate to the file explorer inside VS Code. Once you have clicked on file explorer, click clone repository and select GitHub. You will be prompted to allow GitHub to sign in. Click allow. This will take you to 
GitHub's website. Log in to your account (Ensure this account is the same as the one you registered in WSL). Allow authorization and allow GitHub 
and VS Code to connect. 

Navigate back to VS Code, now you should be able to select your repository. In our case this is: Beam-Me-Up-SHU-y

For now just clone the repo into the default provided. Click select as repo destination.

It will prompt for you to open the project you just cloned, select open.

### Installing required dependencies.

Now you have the WSL environment and VS Code it's time to install the correct dependencies.

Depending on the current version of Ubuntu you use, it will use the default that came with the OS. For this project we need to install a older version in order to use OpenAI Gym.

Please run these commands to install.

```bash
sudo apt install software-properties-common -y
```

```bash
sudo add-apt-repository ppa:deadsnakes/ppa
```

```bash
sudo apt update
```

```bash
sudo apt install python3.10 python3.10-venv python3.10-dev -y
```

Once these have completed. Navigate back to VS Code and at the bottom right you can select which interpreter to use. Select 3.10.19. If you cannot find/see this use the search bar at the top and type: >Interpreter. Click on this then select 3.10.19.

Now you have selected the correct python version, we need to create a virtual environment. Navigate back to where you can select the interpreter and
there should be an option called "Create Virtual Environment…" Select this. Select "Venv" and then select "3.10.19" for your version.

Now close your terminal and re-open a new one. You should notice it now says (.venv)[path to your project/Beam-Me-Up-SHU-y].

Due to our initial development tools being set to match with the newer version of python we must downgrade. Run this command.

```bash
pip install "setuptools<65.0" "wheel<0.38" "pip<23.0"
```

Once done, it's time to install the correct packages needed to develop.

The largest package is this. Give this some time to install. This single package contains everything needed to develop.

```bash
pip install stable-baselines3[extra]==1.8.0
```

### Installing TORCS and SRC Server

Now since the development environment has been made it's time to install TORCS and set up the SRC Server. This SRC Server allows us
to connect our code (python, c#, java) and control the TORCS car via SNAKEOIL (Our refactored version).

Firstly, navigate back to WSL terminal and enter these commands once in root. Not your project root.

```bash
sudo apt install -y g++ make wget xautomation libglib2.0-dev libgl1-mesa-dev \
libglu1-mesa-dev freeglut3-dev libplib-dev libopenal-dev libalut-dev \
libvorbis-dev libxi-dev libxmu-dev libxrender-dev libxrandr-dev libpng-dev zlib1g-dev
```

This is needed for extracting.

```base
sudo apt install bzip2
```

Install TORCS all in one. This may take a while.

```bash
wget https://downloads.sourceforge.net/project/torcs/all-in-one/1.3.4/torcs-1.3.4.tar.bz2
```

Extract TORCS

```bash
tar xfvj torcs-1.3.4.tar.bz2
```

Change directory to TORCS.

```bash
cd torcs-1.3.4

```

From there we need to get the SRC Server patch. Make sure you current directory is torcs-1.3.4.

```bash
wget https://downloads.sourceforge.net/project/cig/SCR%20Championship/Server%20Linux/2.1/scr-linux-patch.tgz
```

Extract patch.

```bash
tar xfvz scr-linux-patch.tgz
```

Change directory to patch.

```bash
cd scr-patch
```

Run patch install script.

```bash
sh do_patch.sh
```
This returns you back to TORCS directory.

```bash
cd ..
```
To build the game we need to fix some issues with the source code and newer OS. Run these commands in the TORCS directory.

```bash
sed -i '164s/const char\* error = .*/const char* error = NULL;/' src/libs/musicplayer/OpenALMusicPlayer.cpp
```

```bash
sed -i 's/isnan/std::isnan/g' src/drivers/olethros/geometry.cpp
```

```bash
sed -i 's/char \*p = strrchr(argv\[0\], \x27\/\x27);/const char *p = strrchr(argv[0], \x27\/\x27);/' src/linux/main.cpp
```

Once done we can configure the source. Ensure we are still in the TORCS directory.

```bash
sudo apt install libxxf86vm-dev
```

```bash
./configure
```

In order to build source run these commands.

```bash
make
```

Install it to your system.

```bash
sudo make install
```

```bash
sudo make datainstall
```

Now you have installed TORCS with the SRC Server patch. If you cannot install something contact DAN2026.

In order to run use this command in torcs-1.3.4 directory.

```bash
torcs
```

### WSL Linux Cheat Sheet (Ubuntu)

This sheet is here to help newcomers to Linux to understand basic commands.

In order to navigate between directories use

```bash
cd dir_path
```

In order to see all directories within your Dir use this command.

```bash
ls
```

```bash 
ls -la
```

In order to rename a file use

```bash 
mv -i file_name new_file_name
```

In order to kill TORCS when its running

```bash
pkill torcs
```

In order to kill a potential infinite loop training script

```bash 
ps aux | grep python
kill -9 [PID_NUMBER]
```

In order to grant permission to a file to run

```bash
chmod +x filename
```

In order to see installed packages.

```bash
pip list
```

In order to check python version.

```bash
python3 --version
```

In order to update Linux packages

```bash
sudo apt update
```

In order to copy a file

```bash
cp source_file.py destination_file.py
```

In order to copy a file/DIR.

```bash
cp -r folder_name/ new_folder_name/
```

In order to remove a file.

```bash
rm filename.py
```

In order to delete a DIR/folder.

```bash
rm -rf folder_name/
```
