from typing import Any, Optional

class Logger:
    
    _instance: Optional['Logger'] = None

    def __new__(cls):
        if cls._instance is None:
            cls._instance = super(Logger, cls).__new__(cls)
        return cls._instance

    def __init__(self):
        
        if hasattr(self, "_initialized"):
            return
        self._initialized = True
    