from bmu.system.events import event_bus
# import globals
from bmu.system.project.project_factory import ProjectFactory
from bmu.system.utils import PathUtil


def test():
    
    factory = ProjectFactory()
    
    path = PathUtil.get_project_root()
  
    file_path = path / "project" / "test_driver.py"
    
    context = {"class_name" : "test"}
    
    content = factory._render("heuristic/driver.jinja", context)
        
    factory._write(file_path, content)

if __name__ == "__main__":
    # event_bus.request_spawn_torcs(0, False)
    
    test()    
    
    
    #TODO Seperate structure functions from write/read functions
    
    #TODO Add file path functions to util for systems
    
    #TODO Create a "Create project structure function"
    
    
