import os
import datetime
import re
from pathlib import Path
from typing import List, Optional
import time

class TimeUtil:
    """Handles timestamping and time-based formatting."""
    
    @staticmethod
    def get_timestamp() -> str:
        """Returns current time in YYYY-MM-DD_HH-MM format."""
        return datetime.datetime.now().strftime("%Y-%m-%d_%H-%M")

    @staticmethod
    def sort_by_timestamp(items: List[str], reverse: bool = True) -> List[str]:
        """
        Sorts a list of strings (filenames) containing timestamps.
        Assumes format: something_YYYY-MM-DD_HH-MM.zip
        """
        def extract_timestamp(text: str):
            match = re.search(r'\d{4}-\d{2}-\d{2}_\d{2}-\d{2}', text)
            return match.group(0) if match else ""

        return sorted(items, key=extract_timestamp, reverse=reverse)
        