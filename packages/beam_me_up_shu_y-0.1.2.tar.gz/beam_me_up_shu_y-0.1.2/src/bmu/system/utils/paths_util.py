import os
import datetime
import re
from pathlib import Path
from typing import List, Optional

class PathUtil:
    """Handles path searching."""
    
    @staticmethod
    def get_project_root() -> Path:
        """
        Walks up from cwd looking for a .gitignore project marker.
        Falls back to cwd if no marker is found.
        """
        current = Path.cwd()
        for parent in [current, *current.parents]:
            if (parent / ".gitignore").exists():
                return parent
        return current

    @staticmethod
    def find_file(filename: str, search_path: Optional[Path] = None) -> Optional[Path]:
        
        """
        Recursively searches for a specific file starting from search_path.
        """
        search_path = search_path or PathUtil.get_project_root()
        for path in search_path.rglob(filename):
            if path.is_file():
                return path
        return None
    
    @staticmethod
    def find_dir(dirname: str, search_path: Optional[Path] = None) -> Optional[Path]:
        """
        Recursively searches for a specific directory name starting from search_path.
        Returns the Path object if found, otherwise None.
        """
        search_path = search_path or PathUtil.get_project_root()
        
        for path in search_path.rglob(dirname):
            if path.is_dir():
                return path
        return None