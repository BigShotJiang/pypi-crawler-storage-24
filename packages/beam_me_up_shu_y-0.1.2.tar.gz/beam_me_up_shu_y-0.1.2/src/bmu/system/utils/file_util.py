import os
import datetime
import re
from pathlib import Path
from typing import List, Optional
import pandas as pd
from .paths_util import PathUtil

class FileUtil:
    """Common file system operations."""

    @staticmethod
    def ensure_dir(path: str) -> None:
        
        """
        Creates directory if it doesn't exist.
        """
        
        Path(path).mkdir(parents=True, exist_ok=True)

    @staticmethod
    def get_latest_file(directory: str,extension: str = ".zip",) -> Optional[str]:
        
        """
        Finds the most recently modified file with a specific extension.
        """
        dir_path = Path(directory)
        if not dir_path.exists():
            return None

        files = list(dir_path.glob(f"*{extension}"))
        if not files:
            return None

        return str(max(files, key=lambda f: f.stat().st_mtime))
    
    @staticmethod
    def get_all_filenames(directory: str, extension: Optional[str] = None) -> List[str]:
        """
        Fetches all filenames from a directory and returns them as a list.
        
        :param directory: The path to the folder.
        :param extension: Optional filter (e.g., '.zip' or '.png').
        :return: List of filenames (strings).
        """
        if not os.path.exists(directory):
            print(f"[ERROR] Directory not found: {directory}")
            return []

        files = [
            f for f in os.listdir(directory) 
            if os.path.isfile(os.path.join(directory, f)) and not f.startswith('.')
        ]

        if extension:
            ext = extension if extension.startswith('.') else f".{extension}"
            files = [f for f in files if f.lower().endswith(ext.lower())]

        return files
    
    def load_reward_csv(filename: Optional[str] = None) -> pd.DataFrame:
        """
        Loads a reward CSV from bmu/logs/rewards/.
        If no filename is provided, loads the most recent one.
        """
        root = PathUtil.get_project_root()
        rewards_dir = root / "logs" / "rewards"

        if not rewards_dir.exists():
            raise FileNotFoundError(f"Rewards directory not found: {rewards_dir}")

        if filename:
            path = rewards_dir / filename
            if not path.exists():
                raise FileNotFoundError(f"File not found: {path}")
        else:
            csv_files = sorted(rewards_dir.glob("*.csv"), key=lambda f: f.stat().st_mtime, reverse=True)
            if not csv_files:
                raise FileNotFoundError(f"No CSV files found in {rewards_dir}")
            path = csv_files[0]

        print(f"Loading: {path.name}")
        return pd.read_csv(path)