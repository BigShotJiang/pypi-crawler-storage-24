import os
from datetime import datetime
from .base_logger import BaseLogger
from bmu.system.utils import PathUtil, FileUtil, TimeUtil
from pathlib import Path
from typing import List, Optional
from dataclasses import asdict
from bmu.system.events import event_bus, EventSignals
import pandas as pd

class RewardLogger(BaseLogger):

    def __init__(self):

        self._agent_name = "unknown"
        self._records    = []
        self._columns    = None

        event_bus.subscribe(EventSignals.AGENT_STARTED, self._on_agent_started)

        root    = PathUtil.get_project_root()
        log_dir = root / "logs" / "rewards"
        log_dir.mkdir(parents=True, exist_ok=True)

        timestamp  = TimeUtil.get_timestamp()
        self._path = log_dir / f"{timestamp}.csv"


    def log_reward(self, payload: dict) -> None:
        row = {
            "agent": self._agent_name,
            **payload,
        }

        if self._columns is None:
            self._columns = list(row.keys())

        self._records.append(row)

        if payload["done"]:
            self._flush()
    
    
    def _flush(self) -> None:
        
        if not self._records:
            return
        
        df = pd.DataFrame(self._records, columns=self._columns)
        
        df.to_csv(
            self._path,
            mode="a",
            header=not os.path.exists(self._path),
            index=False,
            float_format="%.4f",
        )
        self._records = []
    
    def _on_agent_started(self, agent_name: str) -> None:
        self._agent_name = agent_name
        
    
    def shutdown(self) -> None:
        self._flush()

    def log_error(self, message) -> None: pass
    def log_success(self, message) -> None: pass
    def log_info(self, message) -> None: pass
    def log_warn(self, message) -> None: pass
    def log_agent(self, message) -> None: pass
