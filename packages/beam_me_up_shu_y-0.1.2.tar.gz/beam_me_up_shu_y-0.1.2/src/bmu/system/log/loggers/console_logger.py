from .base_logger import BaseLogger
from bmu.system.events import event_bus
from typing import Any

class ConsoleLogger(BaseLogger):
    RED = "\033[91m"
    GREEN = "\033[92m"
    BLUE = "\033[94m"
    YELLOW = "\033[93m"
    RESET = "\033[0m"


    def log_error(self, message: Any) -> None:
        print(f"{self.RED}[ERROR]{self.RESET} {message}{self.RESET}")

    def log_success(self, message: Any) -> None:
        print(f"{self.GREEN}[SUCCESS]{self.RESET} {message}{self.RESET}")

    def log_info(self, message: Any) -> None:
        print(f"{self.BLUE}[INFO]{self.RESET} {message}{self.RESET}")

    def log_warn(self, message: Any) -> None:
        print(f"{self.YELLOW}[WARN]{self.RESET} {message}{self.RESET}")

    def log_agent(self, message: Any) -> None:
        lines = message if isinstance(message, list) else message.split("\n")

        for line in lines:
            if line.strip() == "":
                continue

            print(f"{self.BLUE}[AGENT]{self.RESET} {line}")


    def log_reward(self, payload : dict) -> None: pass
    def shutdown(self) -> None: pass