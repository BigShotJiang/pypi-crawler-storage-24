from abc import ABC, abstractmethod
from typing import Any

class BaseLogger(ABC):
    @abstractmethod
    def log_error(self, message: Any) -> None:
        pass

    @abstractmethod
    def log_success(self, message: Any) -> None:
        pass

    @abstractmethod
    def log_info(self, message: Any) -> None:
        pass

    @abstractmethod
    def log_warn(self, message: Any) -> None:
        pass

    @abstractmethod
    def log_agent(self, message: Any) -> None:
        pass

    @abstractmethod
    def log_reward(self, payload : dict) -> None:
        pass
    
    @abstractmethod
    def shutdown(self) -> None:
        pass
    
