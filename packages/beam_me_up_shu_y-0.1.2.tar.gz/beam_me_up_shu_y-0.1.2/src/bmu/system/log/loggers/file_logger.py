import os
from datetime import datetime
from .base_logger import BaseLogger
from bmu.system.utils import PathUtil, FileUtil, TimeUtil
from pathlib import Path
from typing import List, Optional, Any
from bmu.system.events import event_bus

class FileLogger(BaseLogger):

    def __init__(self):

        self._flush_counter = 0

        root = PathUtil.get_project_root()

        runs_dir = root / "logs" / "runs"

        runs_dir.mkdir(parents=True, exist_ok=True)

        timestamp = TimeUtil.get_timestamp()
        self.path = runs_dir / f"{timestamp}.log"

        self.file = open(str(self.path), "a", encoding="utf-8", buffering=8192)

        self.file.write(f"[========] [ROOT] Logging Started at: {datetime.now()} ---\n")

    def _write(self, level : str, message: Any) -> None:
        
        timestamp = datetime.now().strftime("%H:%M:%S")
        
        self.file.write(f"[{timestamp}] [{level}] {message}\n")
        
        self._flush_counter += 1
        
        if self._flush_counter >= 50:
            self.file.flush()
            self._flush_counter = 0

    def log_error(self, message: Any) -> None:
        self._write("ERROR", message)

    def log_success(self, message: Any) -> None:
        self._write("SUCCESS", message)

    def log_info(self, message: Any) -> None:
        self._write("INFO", message)

    def log_warn(self, message: Any) -> None:
        self._write("WARN", message)

    def log_agent(self, message: Any) -> None:
        timestamp = datetime.now().strftime("%H:%M:%S")

        lines = message if isinstance(message, list) else message.split("\n")

        for line in lines:
            if line.strip() == "":
                continue
            self.file.write(f"[{timestamp}] [AGENT] {line}\n")

    def log_reward(self, payload : dict) -> None:
        pass

    def __del__(self):
        if hasattr(self, "file") and not self.file.closed:
            self.file.flush()
            self.file.close()

    def shutdown(self) -> None:
        if hasattr(self, "file"):
            self.file.flush()
            self.file.close()