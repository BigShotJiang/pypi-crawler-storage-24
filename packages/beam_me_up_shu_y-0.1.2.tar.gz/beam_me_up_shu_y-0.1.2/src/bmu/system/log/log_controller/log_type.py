from enum import Enum

class LogType(Enum):
    CONSOLE = "console"
    FILE = "file"
    REWARD = "reward"
    AGENT = "agent"