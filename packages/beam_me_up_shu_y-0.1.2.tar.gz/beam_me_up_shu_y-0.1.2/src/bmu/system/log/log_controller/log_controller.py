from ..loggers import BaseLogger
from ..loggers import ConsoleLogger
from ..loggers import FileLogger
from ..loggers import RewardLogger
import threading, queue, atexit
from bmu.system.events import event_bus, EventSignals
from typing import Any, ClassVar
from .log_type import LogType

    
class LogController(BaseLogger):

    # This should be prob made into a enum called action states or log states.

    ACTION_ERROR: ClassVar[str] = "log_error"
    ACTION_SUCCESS: ClassVar[str] = "log_success"
    ACTION_INFO: ClassVar[str] = "log_info"
    ACTION_WARN: ClassVar[str] = "log_warn"
    ACTION_AGENT: ClassVar[str] = "log_agent"
    ACTION_REWARD: ClassVar[str] = "log_reward"
    
    LOGGER_MAP = {
        LogType.CONSOLE: ConsoleLogger,
        LogType.FILE: FileLogger,
        LogType.REWARD: RewardLogger
    }

    def __init__(self, console_logging: bool = False, file_logging: bool = False, reward_logging: bool = False ):
        """
        Centralized controller for managing multiple logging outputs asynchronously.

        This class acts as a dispatcher, using a background thread and a queue to
        ensure that logging operations do not block the main application execution.

        console_logging:   Enable logging to the console.\n
        file_logging:      Enable logging to a file.\n
        reward_logging:      Enable logging to a reward csv.\n
        """
        self.loggers: list[BaseLogger] = self.register_loggers(file_logging, console_logging, reward_logging)

        self._log_queue = queue.Queue()

        self._logging_thread = threading.Thread(target=self._log_main, daemon=True)
        self._logging_thread.start()

        atexit.register(self.shutdown)

        event_bus.subscribe(EventSignals.REQUEST_LOG_INFO, self.log_info)
        event_bus.subscribe(EventSignals.REQUEST_LOG_SUCCESS, self.log_success)
        event_bus.subscribe(EventSignals.REQUEST_LOG_WARN, self.log_warn)
        event_bus.subscribe(EventSignals.REQUEST_LOG_ERROR, self.log_error)
        event_bus.subscribe(EventSignals.REQUEST_LOG_AGENT, self.log_agent)
        event_bus.subscribe(EventSignals.REQUEST_LOG_REWARD, self.log_reward)
        
    def _log_main(self) -> None:
        """
        The main worker loop running in a background thread.

        Pulls logging tasks from the queue and dispatches them to all
        registered logger instances using dynamic method lookup.
        """
        while True:
            target_function, message = self._log_queue.get()

            for logger in self.loggers:
                
                log_function = getattr(logger, target_function, None)
                
                if log_function:
                    log_function(message)

            self._log_queue.task_done()

    def log_error(self, message: Any) -> None:
        """
        Queue an error message to be logged by all active loggers.

        message: The error content (string or list) to be processed.
        """
        self._log_queue.put((self.ACTION_ERROR, message))

    def log_success(self, message: Any) -> None:
        """
        Queue a success message to be logged by all active loggers.

        message: The success message string to be processed.
        """
        self._log_queue.put((self.ACTION_SUCCESS, message))

    def log_info(self, message: Any) -> None:
        """
        Queue an informational message to be logged by all active loggers.

        message: The info message string to be processed.
        """
        self._log_queue.put((self.ACTION_INFO, message))

    def log_warn(self, message: Any) -> None:
        """
        Queue a warning message to be logged by all active loggers.

        message: The warning message string to be processed.
        """
        self._log_queue.put((self.ACTION_WARN, message))

    def log_agent(self, message: Any) -> None:
        """
        Queue an agent-specific message to be logged by all active loggers.

        message: The specific agent activity string to be processed.
        """
        self._log_queue.put((self.ACTION_AGENT, message))

    def register_loggers(self, file_logging: bool, console_logging: bool, reward_logging: bool) -> list[BaseLogger]:
        """
        Initialize and return a list of logger instances based on configuration.

        file_logging:    Flag to enable the FileLogger.
        console_logging: Flag to enable the ConsoleLogger.
        reward_logging:  Flag to enable the RewardLogger.

        Result:        A list of initialized logger instances.
        """
        loggers: list[BaseLogger] = []

        if file_logging:
            loggers.append(FileLogger())

        if console_logging:
            loggers.append(ConsoleLogger())
            
        if reward_logging:
            loggers.append(RewardLogger())
            
        if not loggers:
            print("[ERROR] Warning: No loggers initialized.")

        return loggers

    def log_reward(self, payload: dict) -> None:
        """
        Queue a reward to be logged by the reward logger instance.

        message: The warning message string to be processed.
        """
        self._log_queue.put((self.ACTION_REWARD, payload))

    def add_logger(self, log_type: LogType) -> None:
        
        logger_class = self.LOGGER_MAP.get(log_type)
        
        if logger_class and not any(isinstance(l, logger_class) for l in self.loggers):
            
            self.loggers.append(logger_class())

    def remove_logger(self, log_type: LogType) -> None:
        
        logger_class = self.LOGGER_MAP.get(log_type)
        
        for l in self.loggers[:]:
            
            if isinstance(l, logger_class):
                
                if hasattr(l, "shutdown"):
                    
                    l.shutdown()
                    
                self.loggers.remove(l)

    def shutdown(self) -> None:
        """
        Block until all queued log messages have been processed.
        Called automatically on interpreter exit via atexit.
        """
        self._log_queue.join()
        
        for logger in self.loggers:
            logger.shutdown()
            
    