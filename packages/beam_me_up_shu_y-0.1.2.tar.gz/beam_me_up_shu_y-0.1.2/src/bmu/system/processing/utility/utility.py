import threading

class ProcessesUtility:
    
    @staticmethod
    def check_threads():
        print(f"Total Threads : {threading.active_count()} ")
        for thread in threading.enumerate():
            print(f"Name: {thread.name}, Daemon: {thread.daemon}, ID: {thread.ident}")