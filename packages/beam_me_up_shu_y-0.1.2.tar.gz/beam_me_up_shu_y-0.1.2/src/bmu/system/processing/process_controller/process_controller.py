import subprocess, atexit
from ..processes.base.base_process import BaseProcess
from ..processes.torcs_gui.torcs_gui_process import TorcsGUIProcess
from ..processes.torcs_headless.torcs_headless_process import TorcsHeadlessProcess
from ..processes.xvfb.xvfb_process import XvfbProcess
from bmu.system.events import event_bus, EventSignals
from typing import ClassVar


class ProcessController:

    CLEANUP_CMD: ClassVar[list[str]] = ["pkill", "torcs"]

    def __init__(self):

        self._process_dict: dict[str, BaseProcess] = {}
        
        event_bus.subscribe(EventSignals.REQUEST_TORCS_PROCESS, self.torcs_process_requested)
        
        event_bus.subscribe(EventSignals.REQUEST_TORCS_RESTART, self.reset)
        
        event_bus.subscribe(EventSignals.REQUEST_CLEAR_PROCESSES, self.clear_processes)
        
        event_bus.subscribe(EventSignals.REQUEST_TORCS_LAUNCH, self.launch)


        atexit.register(self.closing_cleanup)

    def _register_process(self,  process: BaseProcess) -> None:
        self._process_dict[process._process_name] = process

    def _unregister_process(self, process_name: str) -> None:
        self._process_dict.pop(process_name)

    def display_dictionary(self) -> None:
        for key, value in self._process_dict.items():
            print(f"Key: {key}\nState: {value._state}\nPID: {value._pid}\nProcess: {value._process}\n")

    def launch(self, process_name: str) -> None:
        self._process_dict.get(process_name).launch()

    def end(self, process_name: str) -> None:
        self._process_dict.get(process_name).end()

    def reset(self, process_name: str) -> None:
        self._process_dict.get(process_name).reset()

    def clear_processes(self) -> None:

        for process in self._process_dict.values():

            process.end()

        self._process_dict.clear()

    def torcs_worker(self, headless: bool = False, env_id: int = 0) -> BaseProcess:
        """
        Creates and registers a TORCS simulation process.

        Args:
            headless (bool): If True, launches TORCS in a virtual display (no GUI). 
                            If False, launches with a visible GUI. Defaults to False.
            env_id (int): Unique identifier for the environment instance. Defaults to 0.

        Returns:
            BaseProcess: The initialized TorcsGUIProcess or TorcsHeadlessProcess instance.
        """

        if headless == False:
            current_process = TorcsGUIProcess(
                env_id=env_id
            )

            self._register_process(
                process=current_process
            )

            return current_process
        else:

            current_process = TorcsHeadlessProcess(
                env_id=env_id
            )

            self._register_process(
                process=current_process
            )

            return current_process

    def xvfb_worker(self, total_displays: int, auto_launch: bool)  -> None:
        """
        Creates a set amount of virtual displays and registers them to the process dictionary.

        Args:
            total_displays (int): The total number of Xvfb instances to initialize. 
                                 Displays are indexed from 0, corresponding to 
                                 X11 display numbers starting at :100.
            auto_launch (bool): If True, immediately calls the launch() method for 
                               each created Xvfb process. If False, processes 
                               must be launched manually via the controller.
        """

        for i in range(total_displays):
            xvfb_proc = XvfbProcess(
                display_id=i
            )

            self._register_process(
                process=xvfb_proc
            )

            if auto_launch:
                xvfb_proc.launch()

    def torcs_process_requested(self, env_id: int, headless: bool)  -> None:
        
        new_process = self.torcs_worker(
            headless=headless,
            env_id=env_id
            )
        
        self.launch(
            process_name = new_process._process_name)
        

    def closing_cleanup(self) -> None:
        
        event_bus.request_log_info("Starting closing cleanup...")

        event_bus.request_log_info("Terminating zombie processes")
        
        subprocess.run(self.CLEANUP_CMD)


