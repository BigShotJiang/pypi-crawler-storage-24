from .bus import EventBus
from .signals import EventSignals

event_bus = EventBus()