from ..signals import EventSignals
from typing import overload, Literal, Any
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from bmu.ml import EnvType, VecType, AgentTypes

class EventBus:
    def __init__(self):

        # print(f"Event bus loaded")

        self._listeners: dict[EventSignals, list] = {}

    def subscribe(self, signal: EventSignals, func) -> None:
        """Register a function to respond to a specific signal."""

        if signal not in self._listeners:
            self._listeners[signal] = []

        if func not in self._listeners[signal]:
            self._listeners[signal].append(func)

    def _emit(self, signal: EventSignals, *args, **kwargs)  -> None:  # ** = unpacks arguments
        """Executes a signal if found within the signals enum."""

        if signal not in self._listeners:  # stops signals that dont exist
            return

        for func in self._listeners[signal]:
            try:
                func(*args, **kwargs)
            except Exception as e:
                print(f"[EventBus] Error in listener {func.__name__}: {e}")

    # These functions below are effectively wrappers for auto fill using VS code
    # And it makes debugging easier since we can simply read its action based off of name.

    # region Process Controller Wrappers

    def request_torcs_restart(self, process_name: str):
        self._emit(EventSignals.REQUEST_TORCS_RESTART, process_name=process_name)

    def request_torcs_launch(self, process_name: str):
        """
        Launchs torcs does NOT register torcs instance into the dictionary.
        """

        self._emit(EventSignals.REQUEST_TORCS_LAUNCH, process_name=process_name)

    def request_clear_processes(self):
        self._emit(EventSignals.REQUEST_CLEAR_PROCESSES)

    def request_spawn_torcs(self, env_id: int, headless: bool = False):
        """
        Requests the Controller to create, register, and launch a TORCS instance.
        """
        self._emit(EventSignals.REQUEST_TORCS_PROCESS, env_id=env_id, headless=headless)

    # endregion

    # region Log Controller Wrappers

    def request_log_success(self, message: Any) -> None:
        """Requests a success log."""
        self._emit(EventSignals.REQUEST_LOG_SUCCESS, message=message)

    def request_log_warn(self, message: Any) -> None:
        """Requests a warning log."""
        self._emit(EventSignals.REQUEST_LOG_WARN, message=message)

    def request_log_agent(self, message: Any | list) -> None:
        """Requests an agent log. Accepts a single message or a list."""
        self._emit(EventSignals.REQUEST_LOG_AGENT, message=message)

    def request_log_error(self, message: Any) -> None:
        """Requests an error log."""
        self._emit(EventSignals.REQUEST_LOG_ERROR, message=message)

    def request_log_info(self, message: Any) -> None:
        """Requests an informational log."""
        self._emit(EventSignals.REQUEST_LOG_INFO, message=message)

    def request_log_reward(self, payload) -> None:
        """Requests a reward log, typically used during training to track episode rewards."""
        self._emit(EventSignals.REQUEST_LOG_REWARD, payload=payload)

    # endregion

    # region Environment Wrappers

    def request_start_env(self, requested_env: "EnvType", env_wrapper: "VecType", **config)  -> None:  # So quotes tell python that this will exist
        self._emit(EventSignals.REQUEST_START_ENV, requested_env, env_wrapper, **config)

    # endregion

    # region Agent Wrappers

    def request_start_agent(self, requested_agent: "AgentTypes", env)  -> None:
        self._emit(EventSignals.REQUEST_AGENT, requested_agent, env)

    def request_agent_started(self, agent_name: str)  -> None:
        self._emit(EventSignals.AGENT_STARTED, agent_name)

    # endregion
