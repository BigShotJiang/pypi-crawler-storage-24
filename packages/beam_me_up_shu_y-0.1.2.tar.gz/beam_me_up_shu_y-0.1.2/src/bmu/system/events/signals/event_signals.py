from enum import Enum, auto

class EventSignals(Enum):
    
    # Maybe we seperate this into different signals per controller? 
    
    REQUEST_TORCS_LAUNCH = auto()
    REQUEST_TORCS_RESTART = auto()
    REQUEST_TORCS_PROCESS = auto()
    REQUEST_CLEAR_PROCESSES = auto()
    
    REQUEST_LOG_INFO = auto()
    REQUEST_LOG_SUCCESS = auto()
    REQUEST_LOG_WARN = auto()
    REQUEST_LOG_ERROR = auto()
    REQUEST_LOG_AGENT = auto()
    REQUEST_LOG_REWARD = auto()

    REQUEST_START_ENV = auto()
    REQUEST_GET_ENV = auto()
    
    REQUEST_AGENT = auto()
    AGENT_STARTED = auto()