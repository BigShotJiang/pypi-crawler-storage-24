
from typing import Union

class Utility:
    @staticmethod
    def destringify(s):
        """makes a string into a value or a list of strings into a list of values"""
        if not s:
            return s
        if type(s) is str:
            try:
                return float(s)
            except ValueError:
                return s
        elif type(s) is list:
            if len(s) < 1:
                return s  # Safety check
            if len(s) < 2:
                # Use Utility.destringify instead of self.destringify
                return Utility.destringify(s[0])
            else:
                # Use Utility.destringify here too
                return [Utility.destringify(i) for i in s]

    def clip(v, lo, hi):
        if v < lo:
            return lo
        elif v > hi:
            return hi
        else:
            return v

    @staticmethod
    def bargraph(x, mn, mx, w, c="X"):
        """Draws a simple asciiart bar graph. Very handy for
        visualizing what's going on with the data.
        x= Value from sensor, mn= minimum plottable value,
        mx= maximum plottable value, w= width of plot in chars,
        c= the character to plot with."""
        if not w:
            return ""  # No width!
        if x < mn:
            x = mn  # Clip to bounds.
        if x > mx:
            x = mx  # Clip to bounds.
        tx = mx - mn  # Total real units possible to show on graph.
        if tx <= 0:
            return "backwards"  # Stupid bounds.
        upw = tx / float(w)  # X Units per output char width.
        if upw <= 0:
            return "what?"  # Don't let this happen.
        negpu, pospu, negnonpu, posnonpu = 0, 0, 0, 0
        if mn < 0:  # Then there is a negative part to graph.
            if x < 0:  # And the plot is on the negative side.
                negpu = -x + min(0, mx)
                negnonpu = -mn + x
            else:  # Plot is on pos. Neg side is empty.
                negnonpu = -mn + min(0, mx)  # But still show some empty neg.
        if mx > 0:  # There is a positive part to the graph
            if x > 0:  # And the plot is on the positive side.
                pospu = x - max(0, mn)
                posnonpu = mx - x
            else:  # Plot is on neg. Pos side is empty.
                posnonpu = mx - max(0, mn)  # But still show some empty pos.
        nnc = int(negnonpu / upw) * "-"
        npc = int(negpu / upw) * c
        ppc = int(pospu / upw) * c
        pnc = int(posnonpu / upw) * "_"
        return "[%s]" % (nnc + npc + ppc + pnc)
