# region Imports
from ..server.server_state import ServerState
from ..arguments.args import Arguments
from ..driver_actions.driver_action import DriverAction
import socket
import sys
import os
import time
import getopt
from bmu.system.events import event_bus, EventSignals
from typing import List

# endregion

class Client:
    
    # region Initialization
    
    def __init__(
        
        self,
        host=None,
        port: int = None,
        client_id=None,
        episodes: int =None, 
        track_name: str = None,
        stage: int = None,
        debug_mode: bool =None,
        vision: bool=False,
        env_id: int = 0,
        headless_mode: bool = False,
        sensor_angles: List[float] = [-45, -19, -12, -7, -4, -2.5, -1.7, -1, -.5, 0, .5, 1, 1.7, 2.5, 4, 7, 12, 19, 45]
        
        ):
        
        # region Documentation
        """
        Handles the UDP network connection between Python and the TORCS server.
        """
        # endregion
        
        # region Default Configuration
        self.vision = vision
        self.data_size = 2**16
        self.host = "localhost"
        self.port = 3001 + env_id
        self.sid = "SCR"
        self.max_episodes = 1
        self.track_name = "unknown"
        self.stage = 3  # 0=Warm-up, 1=Qualifying 2=Race, 3=unknown
        self.debug = False
        self.max_steps = 100000
        self._sensor_angles = sensor_angles
        if headless_mode:
            self.connection_attempts = 5
        else:
            self.connection_attempts = 50
        self.timeout_rate = 0.02
        self.miss_count = 0
        self._process_name = f"torcs-env-{env_id}"

        # endregion

        # self.parse_command_line()

        # region Argument Overrides
        if host:
            self.host = host
        if port:
            self.port = port
        if client_id:
            self.sid = client_id
        if episodes:
            self.max_episodes = episodes
        if track_name:
            self.track_name = track_name
        if stage:
            self.stage = stage
        if debug_mode:
            self.debug = debug_mode
        # endregion

        self.S = ServerState()
        self.R = DriverAction()
        self.setup_connection()
        
    # endregion

    # region Connection Logic
    def setup_connection(self):
        # region Documentation
        """
        Establishes the UDP socket and performs the initial handshake with the TORCS server.
        """
        # endregion
        
        # Create Socket
        try:
            self.sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        except socket.error:
            event_bus.request_log_error("Error: Could not create socket...")
            sys.exit(-1)

        self.sock.settimeout(self.timeout_rate)
        attempts_remaining = self.connection_attempts

        # region Handshake Loop
        while True:
            
            sensor_angles_str = " ".join(str(angle) for angle in self._sensor_angles)
            
            init_message = "%s(init %s)" % (self.sid, sensor_angles_str)

            try:
                self.sock.sendto(init_message.encode(), (self.host, self.port))
            except socket.error:
                sys.exit(-1)

            incoming_data = str()
            try:
                incoming_data, address = self.sock.recvfrom(self.data_size)
                incoming_data = incoming_data.decode("utf-8")
            except socket.error:
                
                # These cause allot of spam messages... only uncomment if you want them
                
                # event_bus.request_log_info("Waiting for server on %d............" % self.port)
                # event_bus.request_log_info("Count Down : " + str(attempts_remaining))
                
                if attempts_remaining < 0:
                    event_bus.request_torcs_launch(
                        process_name=self._process_name
                    )
                    attempts_remaining = 5  
                attempts_remaining -= 1

                if attempts_remaining == 0:
                    event_bus.request_log_warn(f"Client attempting to reconnect on port {self.port}. Retrying...")

            if "***identified***" in incoming_data:
                event_bus.request_log_success(f"Client connected on {self.port}")
                break
        # endregion
    # endregion

    # NOT IN USE : we dont use vtorcs
    
    # # region Command Line Parsing
    # def parse_command_line(self):
    #     # region Documentation
    #     """
    #     Parses system arguments to configure host, port, and race settings.
    #     """
    #     # endregion
    #     cmd_arguments = Arguments()

    #     try:
    #         (options, remaining_args) = getopt.getopt(
    #             sys.argv[1:],
    #             "H:p:i:m:e:t:s:dhv",
    #             [
    #                 "host=", "port=", "id=", "steps=", "episodes=",
    #                 "track=", "stage=", "debug", "help", "version",
    #             ],
    #         )
    #     except getopt.error as error_msg:
    #         event_bus.request_log_error("getopt error: %s\n%s" % (error_msg, cmd_arguments.get_usage()))
    #         sys.exit(-1)

    #     try:
    #         for option, value in options:
    #             if option in ("-h", "--help"):
    #                 print(cmd_arguments.get_usage())
    #                 sys.exit(0)
    #             if option in ("-d", "--debug"):
    #                 self.debug = True
    #             if option in ("-H", "--host"):
    #                 self.host = value
    #             if option in ("-i", "--id"):
    #                 self.sid = value
    #             if option in ("-t", "--track"):
    #                 self.track_name = value
    #             if option in ("-s", "--stage"):
    #                 self.stage = int(value)
    #             if option in ("-p", "--port"):
    #                 self.port = int(value)
    #             if option in ("-e", "--episodes"):
    #                 self.max_episodes = int(value)
    #             if option in ("-m", "--steps"):
    #                 self.max_steps = int(value)
    #             if option in ("-v", "--version"):
    #                 print("%s %s" % (sys.argv[0], cmd_arguments.get_version()))
    #                 sys.exit(0)
    #     except ValueError as error_msg:
    #         event_bus.request_log_error("Bad parameter for option %s: %s" % (option, error_msg))
    #         sys.exit(-1)

    #     if len(remaining_args) > 0:
    #         event_bus.request_log_info("Superfluous input detected: %s" % (", ".join(remaining_args)))
    #         sys.exit(-1)
    # # endregion

    # region Communication
    def get_servers_input(self)  -> None:
        # region Documentation
        """
        Listens for UDP packets from the server and updates the internal ServerState.
        """
        # endregion
        if not self.sock:
            return

        while True:
            server_string = str()
            try:
                server_string, address = self.sock.recvfrom(self.data_size)
                server_string = server_string.decode("utf-8")
            except socket.error:
                self.miss_count += 1
                if self.miss_count % 100 == 0:
                    event_bus.request_log_error("Client timeout...")

            if "***identified***" in server_string:
                event_bus.request_log_success(f"Client connected on {self.port}")
                continue
            elif "***shutdown***" in server_string:
                event_bus.request_log_info("Server stopped the race on %d. Position: %d" % 
                         (self.port, self.S.d.get("racePos", 0)))
                self.shutdown()
                return
            elif "***restart***" in server_string:
                event_bus.request_log_error("Server requested restart on %d." % self.port)
                self.shutdown()
                return
            elif not server_string:
                continue
            else:
                self.S.parse_server_str(server_string)
                if self.debug:
                    sys.stderr.write("\x1b[2J\x1b[H")
                    print(self.S)
                break

    def respond_to_server(self):
        # region Documentation
        """
        Sends the current DriverAction (R) to the TORCS server.
        """
        # endregion
        if not self.sock:
            return
        try:
            message = repr(self.R)
            self.sock.sendto(message.encode(), (self.host, self.port))
        except socket.error as error_msg:
            event_bus.request_log_error("Error sending to server: %s" % str(error_msg))
            sys.exit(-1)
            
        if self.debug:
            print(self.R.fancyout())
    # endregion

    # region Shutdown
    def shutdown(self):
        # region Documentation
        """
        Closes the UDP socket and terminates the client session.
        """
        # endregion
        if not self.sock:
            return
        
        event_bus.request_log_info("Race terminated or %s steps elapsed. Shutting down %d." % (self.max_steps, self.port))
        
        self.sock.close()
        self.sock = None
    # endregion