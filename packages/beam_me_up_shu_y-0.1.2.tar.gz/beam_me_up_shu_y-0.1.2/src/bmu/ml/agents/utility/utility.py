from stable_baselines3.common.vec_env import SubprocVecEnv
import gym
import numpy as np
import time, os, inspect

class AgentUtility:
    
    
    @staticmethod
    def testing():
        print("agent utility loaded")
        
    @staticmethod    
    def get_model_properties(model):
        policy_type = getattr(model, "policy_class", "Unknown")
        lr = getattr(model, "learning_rate", "N/A")
        batch_size = getattr(model, "batch_size", "N/A")
        n_steps = getattr(model, "n_steps", "N/A")

        return policy_type, lr, batch_size, n_steps
    
    @staticmethod
    def display_agent_config(model, env, event_bus):
        
        policy_type = getattr(model, "policy_class", "Unknown")
        lr = getattr(model, "learning_rate", "N/A")
        batch_size = getattr(model, "batch_size", "N/A")
        n_steps = getattr(model, "n_steps", "N/A")
        
        message = [
            f"{'=' * 45}",
            f"{'AGENT CONFIGURATION':^45}",  # Centers text in the 45-char box
            f"{'-' * 45}",
            f" Model:      {type(model).__name__}",
            f" Policy:     {getattr(policy_type, '__name__', policy_type)}",
            f" Env:        {type(env).__name__}",
            f" Device:     {model.device}",
            f"{'-' * 45}",
            f" Train Mode: {'Active' if model.learning_rate else 'Inference'}",
            f" Batch Size: {batch_size}",
            f" LR:         {lr}",
            f" Rollout:    {n_steps} steps",
            f"{'=' * 45}",
        ]
        
        event_bus.request_log_success("Agent loaded: ")

        event_bus.request_log_agent(message)
        
    @staticmethod
    def preload_model(model, env):
        """
        Preloads the gpu
        """

        dummy_obs = env.observation_space.sample()
        dummy_obs = dummy_obs[np.newaxis, ...]
        model.predict(dummy_obs)
        
    @staticmethod
    def get_timestamp():
        return time.strftime("%Y-%m-%d_%H-%M")