from .off_policy_agent import OffPolicyAgent
from stable_baselines3 import DQN
import gym


class AgentDQN(OffPolicyAgent):
    
    """
    DQN (Deep Q-Network) agent implementation.

    An `off-policy` `value-based` algorithm designed for `discrete` action spaces only.
    Inherits save/load/train/evaluate behaviour from `OffPolicyAgent`.
    
    `Warning:` This model does not work with `TORCS` continous environment currently.
    """
    
    def __init__(self, environment: gym.Env) -> None:
        
        """
        Initialises the `AgentDQN` with a pre-configured model and environment.

        `Warning:` This model does not work with `TORCS` continous environment currently.

        Args:
            environment: The `gym.Env` the agent will train and evaluate in.
        """
        
        policy_kwargs = dict(net_arch=[256, 256])

        model = DQN(
            "MlpPolicy",
            environment,
            device="cpu",
            verbose=1,
            learning_rate=0.0001,
            buffer_size=1000000,
            learning_starts=1000,
            batch_size=32,
            tau=1.0,
            gamma=0.99,
            train_freq=4,
            gradient_steps=1,
            target_update_interval=10000,
            exploration_fraction=0.1,
            exploration_final_eps=0.05,
            policy_kwargs=policy_kwargs,
        )
        super().__init__(model, environment)
