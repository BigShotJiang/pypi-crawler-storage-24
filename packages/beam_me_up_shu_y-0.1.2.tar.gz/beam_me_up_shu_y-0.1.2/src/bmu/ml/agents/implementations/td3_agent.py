from .off_policy_agent import OffPolicyAgent
from stable_baselines3 import TD3
from stable_baselines3.common.noise import NormalActionNoise
import numpy as np
import gym


class AgentTD3(OffPolicyAgent):
    
    """
    TD3 (Twin Delayed Deep Deterministic Policy Gradient) agent implementation.

    An `off-policy` `actor-critic` algorithm designed for `continuous` action spaces.
    Extends `DDPG` with `twin critics` and `delayed policy updates` to reduce overestimation bias.
    Inherits save/load/train/evaluate behaviour from `OffPolicyAgent`.
    """
    
    def __init__(self, environment: gym.Env) -> None:
        
        """
        Initialises the `AgentTD3` with a pre-configured model and environment.

        Args:
            environment: The `gym.Env` the agent will train and evaluate in.
        """
        
        n_actions = environment.action_space.shape[0]

        action_noise = NormalActionNoise(
            mean=np.zeros(n_actions),
            sigma=0.1 * np.ones(n_actions)
        )

        policy_kwargs = dict(net_arch=[256, 256])

        model = TD3(
            "MlpPolicy",
            environment,
            device="cpu",
            verbose=1,
            learning_rate=0.0001,            
            buffer_size=1000000,
            learning_starts=10000,          
            batch_size=256,
            tau=0.005,
            gamma=0.99,
            train_freq=4,
            gradient_steps=4,
            policy_delay=2,                 
            target_policy_noise=0.2,        
            target_noise_clip=0.5,           
            action_noise=action_noise,
            policy_kwargs=policy_kwargs,
        )

        super().__init__(model, environment)

    def main(self, **kwargs) -> None:
        pass