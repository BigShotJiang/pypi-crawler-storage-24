from abc import ABC, abstractmethod
from stable_baselines3.common.base_class import BaseAlgorithm
import time, inspect, os, gym
from stable_baselines3.common.vec_env import DummyVecEnv, VecEnv
import numpy as np
from ..utility import AgentUtility
from bmu.system.events import event_bus
from bmu.system.utils import PathUtil, FileUtil, TimeUtil
from pathlib import Path
from typing import Optional


class AgentBase(ABC):
    
    """
    Abstract base class for all agent implementations.

    Provides shared infrastructure for `training`, `evaluation`, `model saving/loading`, and `tensorboard logging`.
    Concrete agents must inherit from either `OnPolicyAgent` or `OffPolicyAgent` rather than this class directly.
    Abstract methods `_run_training`, `_run_evaluation`, `_save`, and `_load` must be implemented by subclasses.
    """

    def __init__(self, model: BaseAlgorithm, env: gym.Env) -> None:
        
        """
        Initialises the agent with a model and environment.

        Wraps the environment in a `DummyVecEnv` if it is not already vectorized.
        Displays the agent configuration via `AgentUtility`.

        Args:
            model: The `BaseAlgorithm` instance to train and evaluate.
            env: The `gym.Env` the agent will interact with.
        """
        
        self._timestamp = TimeUtil.get_timestamp()
        
        self._model = model
        self._env = env

        if isinstance(env, VecEnv):
            self._vectorized_env = env
            self._env = env
        else:
            self._env = env
            self._vectorized_env = DummyVecEnv([lambda: self._env])

        AgentUtility.display_agent_config(
            model=self._model, env=self._env, event_bus=event_bus
        )

    def train(self, timesteps: int = 1000, model_name: Optional[str] = None) -> None:
        
        """
        Trains the model for a set number of `timesteps`.

        Loads the most recent model by default, or a specific model if `model_name` is provided.
        Sets the `tensorboard` log directory before training begins.
        Saves the model automatically on completion.

        Args:
            timesteps: Total number of environment steps to train for. Defaults to `1000`.
            model_name: Optional name of a specific model file to load. Defaults to `None`.
        """

        self._load(model_name)
        self._model.set_env(self._vectorized_env)

        self._model.tensorboard_log = self._get_tensorboard_dir()

        event_bus.request_log_success("Starting training...")
        self._run_training(timesteps)
        event_bus.request_log_success("Training complete.")
        self._save()
        event_bus.request_clear_processes()

    def evaluate(self, episodes: int = 5, model_name: Optional[str] = None) -> None:
        
        """
        Evaluates the model for a set number of `episodes`.

        Loads the most recent model by default, or a specific model if `model_name` is provided.
        Runs the model deterministically with no exploration.

        Args:
            episodes: Number of episodes to evaluate for. Defaults to `5`.
            model_name: Optional name of a specific model file to load. Defaults to `None`.
        """
        
        self._load(model_name)
        event_bus.request_log_success("Starting evaluation...")
        self._run_evaluation(episodes)
        event_bus.request_clear_processes()

    def _get_save_path(self, subdir: str) -> Path:
        
        """
        Constructs and returns the save path for the current agent under `models/{AgentName}/{subdir}/`.

        Creates the directory if it does not already exist.
        The filename is automatically timestamped via `TimeUtil`.

        Args:
            subdir: Subdirectory under the agent folder, typically `weights` or `buffer`.

        Returns:
            `Path` to the save location including the timestamped filename.
        """

        root = PathUtil.get_project_root()
        agent_name = self.__class__.__name__
        models_dir = root / "artifacts" / "models" / agent_name / subdir
        models_dir.mkdir(parents=True, exist_ok=True)
        return models_dir / f"model_{self._timestamp}"

    def _get_load_path(self, subdir: str, extension: str, model_name: Optional[str] = None) -> Path | None:
        
        """
        Resolves and returns the load path for the most recent file matching the given `extension` and `subdir`.

        If `model_name` is provided, resolves that specific file instead.
        Returns `None` if the directory does not exist or no matching files are found.

        Args:
            subdir: Subdirectory under the agent folder, typically `weights` or `buffer`.
            extension: File extension to search for, e.g. `.zip` or `.pkl`.
            model_name: Optional name of a specific file to load. Defaults to `None`.

        Returns:
            `Path` to the resolved file, or `None` if not found.
        """

        root = PathUtil.get_project_root()
        agent_name = self.__class__.__name__
        models_dir = root / "artifacts" / "models" / agent_name / subdir

        if not models_dir.exists():
            event_bus.request_log_error(f"Directory {models_dir} does not exist.")
            return None

        if model_name:
            if not model_name.endswith(extension):
                model_name += extension
            return models_dir / model_name

        files = FileUtil.get_all_filenames(str(models_dir), extension=extension)
        if not files:
            event_bus.request_log_error(
                f"No {extension} files found in {models_dir}, continuing without."
            )
            return None

        sorted_files = TimeUtil.sort_by_timestamp(files, reverse=True)
        final_file = models_dir / sorted_files[0]
        event_bus.request_log_info(f"Found latest file: {final_file.name}")
        return final_file

    def _get_tensorboard_dir(self) -> str:
        
        """
        Resolves the `tensorboard` logs directory for the current agent.

        Creates the directory under `logs/tensorboard/{AgentName}/` if it does not already exist.

        Returns:
            `str` path to the tensorboard directory.
        """
        
        root = PathUtil.get_project_root()
        agent_name = self.__class__.__name__
        tensorboard_dir = root / "logs" / "tensorboard" / agent_name

        if not tensorboard_dir.exists():

            event_bus.request_log_info("Creating tensorboard directory.")

            tensorboard_dir.mkdir(parents=True, exist_ok=True)

            event_bus.request_log_info(
                f"Created tensorboard directory: {tensorboard_dir}"
            )
        else:
            event_bus.request_log_info(
                f"Found tensorboard directory at: {str(tensorboard_dir)}"
            )

        return str(tensorboard_dir)

    def _get_file_name(self) -> str:
        
        """
        Returns a timestamped filename string in the format `model_{timestamp}`.

        Used to ensure `tensorboard` log names match their corresponding saved model files.

        Returns:
            `str` filename with current timestamp.
        """
        
        return f"model_{TimeUtil.get_timestamp()}"

    @abstractmethod
    def _run_training(self) -> None:
        
        """
        Abstract method. Executes the algorithm-specific training loop.

        Must be implemented by `OnPolicyAgent` or `OffPolicyAgent` subclasses.

        Args:
            timesteps: Total number of environment steps to train for.
        """
        
        pass

    @abstractmethod
    def _run_evaluation(self) -> None:
        
        """
        Abstract method. Executes the algorithm-specific evaluation loop.

        Must be implemented by `OnPolicyAgent` or `OffPolicyAgent` subclasses.

        Args:
            episodes: Number of episodes to evaluate for.
        """
        
        pass

    @abstractmethod
    def _save(self) -> None:
        
        """
        Abstract method. Saves the model and any additional algorithm-specific artifacts.

        `OnPolicyAgent` saves weights only. `OffPolicyAgent` additionally saves the `replay buffer`.
        Must be implemented by subclasses.
        """
        
        pass

    @abstractmethod
    def _load(self, model_name: Optional[str] = None) -> None:
        
        """
        Abstract method. Loads the model and any additional algorithm-specific artifacts.

        `OnPolicyAgent` loads weights only. `OffPolicyAgent` additionally loads the `replay buffer` if available.
        Must be implemented by subclasses.

        Args:
            model_name: Optional name of a specific model file to load. Defaults to `None`.
        """
        
        pass
