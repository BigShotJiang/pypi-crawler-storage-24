from stable_baselines3 import PPO
from .on_policy_agent import OnPolicyAgent
import gym


class AgentPPO(OnPolicyAgent):
    
    """
    PPO (Proximal Policy Optimization) agent implementation.

    An `on-policy` `actor-critic` algorithm designed for `continuous` action spaces.
    Inherits save/load/train/evaluate behaviour from `OnPolicyAgent`.
    """
        
    def __init__(self, environment: gym.Env) -> None:
        
        """
        Initialises the `AgentPPO` with a pre-configured model and environment.

        Args:
            environment: The `gym.Env` the agent will train and evaluate in.
        """
        
        policy_kwargs = dict(net_arch=dict(pi=[256, 256], vf=[256, 256]))

        model = PPO(
            "MlpPolicy",
            environment,
            device="cpu",
            verbose=1,
            n_steps=4096,
            batch_size=256,
            ent_coef=0.01,
            gae_lambda=0.95,
            learning_rate=0.0003,
            n_epochs=10,
            clip_range=0.2,
            policy_kwargs=policy_kwargs,
        )

        super().__init__(model, environment)
