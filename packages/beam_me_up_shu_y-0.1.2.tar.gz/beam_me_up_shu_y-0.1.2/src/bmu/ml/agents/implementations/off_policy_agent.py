from .base_agent import AgentBase
from bmu.system.events import event_bus
from typing import Optional
from ..utility.utility import AgentUtility
from stable_baselines3.common.off_policy_algorithm import OffPolicyAlgorithm
import numpy as np
from stable_baselines3.common.vec_env import VecNormalize

class OffPolicyAgent(AgentBase):
    
    """
    `Off-policy` agent base implementation for `SAC`, `TD3`, `DDPG`, and `DQN`.

    Provides shared `save`, `load`, `training`, and `evaluation` behaviour for all `off-policy` algorithms.
    Saves and loads `model weights`, a `replay buffer`, and `VecNormalize` statistics — preserving past experience and reward normalisation between runs.
    Applies `VecNormalize` reward normalisation by default, which stabilises critic learning for off-policy algorithms.
    Inherits shared implementations from `AgentBase`.
    """
    
    def __init__(self, model, env, normalize_reward: bool = True):
        
        """
        Initialises the `OffPolicyAgent` with a model, environment, and optional reward normalisation.

        Wraps the vectorized environment in `VecNormalize` if `normalize_reward` is `True` and one is not already present.
        Reward normalisation is enabled by default as it stabilises critic learning for off-policy algorithms.
        Observation normalisation is disabled as `TorcsEnv` handles this internally.

        Args:
            model: The `OffPolicyAlgorithm` instance to train and evaluate.
            env: The `gym.Env` or `VecEnv` the agent will interact with.
            normalize_reward: Whether to wrap the environment with `VecNormalize` for reward normalisation. Defaults to `True`.
        """
                
        super().__init__(model, env)
        self._model: OffPolicyAlgorithm
        
        if normalize_reward and not isinstance(self._vectorized_env, VecNormalize):
            
            self._vectorized_env = VecNormalize(
                self._vectorized_env,
                norm_obs=False,
                norm_reward=True,
                clip_reward=10.0,
                gamma=0.99
            )
        

    def _save(self) -> None:

        """
        Saves the `model weights`, `replay buffer`, and `VecNormalize` statistics to their respective subdirectories.

        Writes up to three files per save — a `.zip` weights file, a `.pkl` replay buffer file, and a `.pkl` VecNormalize stats file.
        All files share the same timestamp via `_get_save_path` to ensure they remain paired on load.
        VecNormalize stats are only saved if the environment is wrapped with `VecNormalize`.
        """

        weights_path = self._get_save_path("weights")
        buffer_path = self._get_save_path("buffer")

        self._model.save(weights_path)
        self._model.save_replay_buffer(buffer_path)
        
        event_bus.request_log_success(f"Model saved: {weights_path.name}")
        event_bus.request_log_success(f"Replay buffer saved: {buffer_path.name}")

        if isinstance(self._vectorized_env, VecNormalize):
            
            vecnorm_path = self._get_save_path("vecnormalize")
            
            self._vectorized_env.save(str(vecnorm_path) + ".pkl")
            
            event_bus.request_log_success(f"VecNormalize stats saved: {vecnorm_path.name}")

    def _load(self, model_name: Optional[str] = None) -> None:
        
        """
        Loads the `model weights`, `replay buffer`, and `VecNormalize` statistics from their respective subdirectories.

        Loads the most recent `.zip`, `.pkl` buffer, and `.pkl` VecNormalize files by default, or a specific model if `model_name` is provided.
        VecNormalize stats are restored before the model is loaded to ensure the environment scaling matches what the critic was trained on.
        Forces the model onto the correct `device` to prevent `cpu`/`cuda` mismatch on load.
        Calls `AgentUtility.preload_model` after loading to ensure the model is ready for eval/training.
        Starts fresh with a warning if no weights are found.
        Continues without a buffer or VecNormalize stats with a warning if no matching files are found.

        Args:
            model_name: Optional name of a specific model file to load. Defaults to `None`.
        """
        
        weights_path = self._get_load_path("weights", ".zip", model_name)
        buffer_path = self._get_load_path("buffer", ".pkl", model_name)
        vecnorm_path = self._get_load_path("vecnormalize", ".pkl")

        if not weights_path or not weights_path.exists():
            
            event_bus.request_log_warn("No model found, starting fresh.")
            return

        if vecnorm_path and vecnorm_path.exists() and isinstance(self._vectorized_env, VecNormalize):
            
            raw_env = self._vectorized_env.venv
            
            self._vectorized_env = VecNormalize.load(str(vecnorm_path), raw_env)
            
            event_bus.request_log_success(f"VecNormalize stats loaded: {vecnorm_path.name}")
        
        self._model = self._model.__class__.load(
            weights_path, 
            env=self._vectorized_env, 
            device=self._model.device
        )

        AgentUtility.preload_model(model=self._model, env=self._env)
        
        event_bus.request_log_success(f"Model loaded: {weights_path.name}")

        if buffer_path and buffer_path.exists():
            
            self._model.load_replay_buffer(buffer_path)
            event_bus.request_log_success(f"Replay buffer loaded: {buffer_path.name}")
            
        else:
            
            event_bus.request_log_warn("No replay buffer found, starting fresh.")

    def _run_training(self, timesteps: int) -> None:
        
        """
        Executes the `off-policy` training loop via `SB3` `learn()`.

        Logs to `tensorboard` using a timestamped `tb_log_name`.
        Does not reset timestep count between runs via `reset_num_timesteps=False`.

        Args:
            timesteps: Total number of environment steps to train for.
        """

        self._model.learn(
            total_timesteps=timesteps,
            progress_bar=True,
            tb_log_name=self._get_file_name(),
            reset_num_timesteps=False
        )

    def _run_evaluation(self, episodes: int) -> None:
        
        """
        Evaluates the model deterministically over a set number of `episodes`.

        Disables `VecNormalize` reward normalisation and stat updates during evaluation to ensure raw rewards are used for scoring.
        Restores normalisation after evaluation completes.
        Uses `deterministic=True` to disable exploration during evaluation.

        Args:
            episodes: Number of episodes to evaluate for.
        """
        
        if isinstance(self._vectorized_env, VecNormalize):
            self._vectorized_env.training = False
            self._vectorized_env.norm_reward = False

        for episode in range(episodes):
            obs = self._env.reset()
            done, score = False, 0

            while not done:
                action, _ = self._model.predict(obs, deterministic=True)
                obs, reward, done, _ = self._env.step(action)
                score += reward

        if isinstance(self._vectorized_env, VecNormalize):
            self._vectorized_env.training = True
            self._vectorized_env.norm_reward = True
