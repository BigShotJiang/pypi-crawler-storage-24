from .base_agent import AgentBase
from ..utility import AgentUtility
from bmu.system.events import event_bus
from typing import Optional
from stable_baselines3.common.on_policy_algorithm import OnPolicyAlgorithm


class OnPolicyAgent(AgentBase):
    
    """
    `On-policy` agent base implementation for `PPO` and `A2C`.

    Provides shared `save`, `load`, `training`, and `evaluation` behaviour for all `on-policy` algorithms.
    Only saves and loads `model weights` — no replay buffer required.
    Inherits shared implementation's from `AgentBase`.
    """
    
    def __init__(self, model, env):
        
        """
        Initialises the `OnPolicyAgent` with a model and environment.

        Args:
            model: The `OnPolicyAlgorithm` instance to train and evaluate.
            env: The `gym.Env` the agent will interact with.
        """
        
        super().__init__(model, env)

        self._model: OnPolicyAlgorithm

    def _save(self) -> None:

        """
        Saves the `model weights` to the `weights` subdirectory.

        On-policy algorithms only require weights — no `replay buffer` to save.
        Filename is automatically timestamped via `_get_save_path`.
        """

        path = self._get_save_path("weights")
        self._model.save(path)
        event_bus.request_log_success(f"Model saved: {path.name}")

    def _load(self, model_name: Optional[str] = None) -> None:
        """
        Loads the `model weights` from the `weights` subdirectory.

        Loads the most recent `.zip` file by default, or a specific file if `model_name` is provided.
        Calls `AgentUtility.preload_model` after loading to ensure the model is ready for interaction.
        Starts fresh with a warning if no model is found.

        Args:
            model_name: Optional name of a specific `.zip` file to load. Defaults to `None`.
        """

        path = self._get_load_path("weights", ".zip", model_name)

        if not path or not path.exists():
            event_bus.request_log_warn("No model found, starting fresh.")
            return

        self._model = self._model.__class__.load(path, env=self._vectorized_env)

        AgentUtility.preload_model(model=self._model, env=self._env)

        event_bus.request_log_success(f"Model loaded: {path.name}")

    def _run_training(self, timesteps: int) -> None:
        
        """
        Executes the `on-policy` training loop via `SB3` `learn()`.

        Logs to `tensorboard` using a timestamped `tb_log_name`.
        Does not reset timestep count between runs via `reset_num_timesteps=False`.

        Args:
            timesteps: Total number of environment steps to train for.
        """

        self._model.learn(
            total_timesteps=timesteps,
            progress_bar=True,
            tb_log_name=self._get_file_name(),
            reset_num_timesteps=False,
        )

    def _run_evaluation(self, episodes: int) -> None:
        
        """
        Evaluates the model deterministically over a set number of `episodes`.

        Uses `deterministic = True` to disable exploration during evaluation.
        Logs the `total reward` for each episode via the `event_bus`.

        Args:
            episodes: Number of episodes to evaluate for.
        """

        for episode in range(episodes):

            obs = self._env.reset()
            done, score = False, 0

            while not done:
                action, _ = self._model.predict(obs, deterministic=True)
                obs, reward, done, _ = self._env.step(action)
                score += reward

            event_bus.request_log_info(
                f"Episode {episode} finished. Total Reward: {score}"
            )
