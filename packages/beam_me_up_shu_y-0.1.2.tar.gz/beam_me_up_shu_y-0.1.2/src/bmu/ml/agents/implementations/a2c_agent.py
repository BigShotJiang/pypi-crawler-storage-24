from .on_policy_agent import OnPolicyAgent
from stable_baselines3 import A2C
import gym


class AgentA2C(OnPolicyAgent):
    
    """
    A2C (Advantage Actor Critic) agent implementation.

    An `on-policy` `actor-critic` algorithm designed for `continuous` action spaces.
    Inherits save/load/train/evaluate behaviour from `OnPolicyAgent`.
    """
    
    def __init__(self, environment: gym.Env) -> None:
        
        """
        Initialises the `AgentA2C` with a pre-configured model and environment.

        Args:
            environment: The `gym.Env` the agent will train and evaluate in.
        """
        
        model = A2C(
            "MlpPolicy",
            environment,
            device="cpu",
            verbose=1,
            learning_rate=0.0007,
            n_steps=5,
            gamma=0.99,
            gae_lambda=1.0,
            ent_coef=0.0,
            vf_coef=0.5,
            max_grad_norm=0.5,
        )
        super().__init__(model, environment)

