from .off_policy_agent import OffPolicyAgent
from stable_baselines3 import SAC
import gym


class AgentSAC(OffPolicyAgent):
    
    """
    SAC (Soft Actor Critic) agent implementation.

    An `off-policy` `actor-critic` algorithm designed for `continuous` action spaces.
    Inherits save/load/train/evaluate behaviour from `OffPolicyAgent`.
    
    `Warning:` This model does not work with `TORCS` action space currently.
    
    """
    
    def __init__(self, environment: gym.Env) -> None:
        
        """
        Initialises the `AgentSAC` with a pre-configured model and environment.

        `Warning:` This model does not work with `TORCS` action space currently.

        Args:
            environment: The `gym.Env` the agent will train and evaluate in.
        """
        
        ent_coef = "auto"

        policy_kwargs = dict(net_arch=dict(pi=[256, 256], qf=[256, 256]))

        model = SAC(
            "MlpPolicy",
            environment,
            device="cpu",
            verbose=1,
            learning_rate=0.0003,
            buffer_size=1000000,
            learning_starts=1000,
            batch_size=256,
            tau=0.005,
            gamma=0.99,
            train_freq=1,
            gradient_steps=1,
            ent_coef=ent_coef,
            policy_kwargs=policy_kwargs,
        )

        super().__init__(model, environment)
