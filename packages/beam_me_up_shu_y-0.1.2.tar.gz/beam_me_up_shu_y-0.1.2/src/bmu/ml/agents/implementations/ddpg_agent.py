from .off_policy_agent import OffPolicyAgent
from stable_baselines3 import DDPG
from stable_baselines3.common.noise import NormalActionNoise
import numpy as np
import gym


class AgentDDPG(OffPolicyAgent):
    
    """
    DDPG (Deep Deterministic Policy Gradient) agent implementation.

    An `off-policy` `actor-critic` algorithm designed for `continuous` action spaces.
    Inherits save/load/train/evaluate behaviour from `OffPolicyAgent`.
    """
    
    def __init__(self, environment: gym.Env) -> None:
        
        """
        Initialises the `AgentDDPG` with a pre-configured model and environment.

        Args:
            environment: The `gym.Env` the agent will train and evaluate in.
        """
        
        n_actions = environment.action_space.shape[0]

        action_noise = NormalActionNoise(
            mean=np.zeros(n_actions), sigma=0.1 * np.ones(n_actions)
        )

        policy_kwargs = dict(net_arch=[256, 256])

        model = DDPG(
            "MlpPolicy",
            environment,
            device="cpu",
            verbose=1,
            learning_rate=0.001,
            buffer_size=1000000,
            learning_starts=100,
            batch_size=256,
            tau=0.005,
            gamma=0.99,
            train_freq=1,
            action_noise=action_noise,
            policy_kwargs=policy_kwargs,
        )

        super().__init__(model, environment)
