from enum import Enum, auto

class AgentTypes(Enum):
    
    """
    The agent type's that have been made and supported.
    """
    
    PPO = auto()
    A2C = auto()
    SAC = auto()
    TD3 = auto()
    DDPG = auto()
    DQN = auto()