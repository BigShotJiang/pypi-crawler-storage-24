from typing import Any, ClassVar
from bmu.system.events import event_bus, EventSignals
from ..implementations.agent_types import AgentTypes
from ..implementations.ppo_agent import AgentPPO
from ..implementations.a2c_agent import AgentA2C
from ..implementations.sac_agent import AgentSAC
from ..implementations.td3_agent import AgentTD3
from ..implementations.ddpg_agent import AgentDDPG
from ..implementations.dqn_agent import AgentDQN
from ..implementations.base_agent import AgentBase
import sys


class AgentController:

    AGENT_REGISTRY: ClassVar[dict[AgentTypes, type]] = {
        AgentTypes.PPO:  AgentPPO,
        AgentTypes.A2C:  AgentA2C,
        AgentTypes.SAC:  AgentSAC,
        AgentTypes.TD3:  AgentTD3,
        AgentTypes.DDPG: AgentDDPG,
        AgentTypes.DQN:  AgentDQN,
    }

    def __init__(self) -> None:
        self._agent = None
        event_bus.subscribe(EventSignals.REQUEST_AGENT, self.start_agent)

    def validate_agent(self, agent_type: AgentTypes) -> bool:

        CONTINUOUS_ONLY = {AgentTypes.PPO, AgentTypes.A2C, AgentTypes.SAC, AgentTypes.TD3, AgentTypes.DDPG}
        
        DISCRETE_ONLY = {AgentTypes.DQN}

        agent_class = self.AGENT_REGISTRY.get(agent_type)

        if not agent_class:
            event_bus.request_log_error(f"Agent [{agent_type.name}] is currently not registered.")
            return False

        if agent_type in DISCRETE_ONLY:
            event_bus.request_log_error(f"Agent [{agent_type.name}] requires a discrete action space.")
            return False

        event_bus.request_log_success(f"Agent class '{agent_class.__name__}' is valid")
        return True

    def start_agent(self, requested_agent: AgentTypes, env: Any) -> None:

        if not self.validate_agent(requested_agent):
            event_bus.request_log_error(f"Aborting: Agent [{requested_agent.name}] could not be started.")
            sys.exit(1)

        agent_class = self.AGENT_REGISTRY[requested_agent]
        self._agent = agent_class(environment=env)

        if self._agent:
            event_bus.request_log_success(f"Agent: {type(self._agent).__name__} successfully started")
            event_bus.request_agent_started(type(self._agent).__name__)

    def get_agent(self) -> AgentBase | None:
        return self._agent