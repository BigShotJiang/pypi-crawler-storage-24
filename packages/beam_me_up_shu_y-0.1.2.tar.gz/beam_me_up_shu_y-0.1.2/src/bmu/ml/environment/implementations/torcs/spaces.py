from gym import spaces
import numpy as np
from bmu.system.events import event_bus


class TorcsSpaces:
    
    
    def __init__(self, gears, throttle, vision) -> None:
        
        self._vision = vision
        self._throttle = throttle
        self._gears = gears      
        self._last_gear = 1
    
        event_bus.request_log_success("On policy space's loaded.")

    def initialize_spaces(self) -> None:
        """
        Intializes the action space and observation space needed for the gym.env interface.
        """
        self.action_space()
        self.observation_space()
    
    def reset(self) -> None:
        
        self._last_gear = 1
    
    def action_space(self) -> None:
        """
        Setup's the action spaces.
        """
        if self._gears:
            self.action_space = spaces.Box(-1.0,
                                            1.0, shape=(3,), dtype=np.float32)
        elif self._throttle:
            self.action_space = spaces.Box(-1.0,
                                            1.0, shape=(2,), dtype=np.float32)
        else:
            self.action_space = spaces.Box(-1.0,
                                            1.0, shape=(1,), dtype=np.float32)
    
    def observation_space(self) -> None:
        """
        Observation space when using vision for machine learning
        """
        if not self._vision:
            self.observation_space = spaces.Box(-np.inf, np.inf, shape=(73,),
                                                dtype=np.float32)
        else:
            self.observation_space = spaces.Box(0, 255, shape=(64, 64, 3),
                                                dtype=np.uint8)
    
    def translate_action(self, action, client)-> dict[str, float]:
        """
        Translates raw network outputs into TORCS control values.
        """
        translated_action = {}

        translated_action["steer"] = np.clip(action[0], -1.0, 1.0)

        if self._throttle:
            pedal_input = action[1]
            if pedal_input > 0.0:
                translated_action["accel"] = pedal_input
                translated_action["brake"] = 0.0
            else:
                translated_action["accel"] = 0.0
                translated_action["brake"] = np.abs(pedal_input)

        if self._gears:
            gear_raw = action[-1]
            target_gear = int(np.round(np.interp(gear_raw, [-1, 1], [1, 6])))

            current_gear = self._last_gear
            if target_gear > current_gear + 1:
                target_gear = current_gear + 1
            elif target_gear < current_gear - 1:
                target_gear = current_gear - 1

            translated_action["gear"] = np.clip(target_gear, 1, 6)
            self._last_gear = translated_action["gear"]
        else:
            rpm = client.S.d['rpm']
            current_gear = client.S.d['gear']

            if rpm > 8000:
                translated_action["gear"] = current_gear + 1
            elif rpm < 2500 and current_gear > 1:
                translated_action["gear"] = current_gear - 1
            else:
                translated_action["gear"] = current_gear if current_gear > 0 else 1

            translated_action["gear"] = np.clip(
                translated_action["gear"], 1, 6)

        return translated_action