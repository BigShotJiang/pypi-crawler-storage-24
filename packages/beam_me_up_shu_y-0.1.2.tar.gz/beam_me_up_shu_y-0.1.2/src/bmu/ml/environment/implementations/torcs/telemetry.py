from dataclasses import dataclass
from typing import List

@dataclass
class Telemetry:
    angle: float
    cur_lap_time: float
    damage: float
    dist_from_start: float
    dist_raced: float
    fuel: float
    gear: float
    last_lap_time: float
    opponents: list[float]
    race_pos: float
    rpm: float
    speed_x: float
    speed_y: float
    speed_z: float
    track: list[float]
    track_pos: float
    wheel_spin_vel: list[float]
    z: float
    focus: list[float]

    @classmethod
    def from_dict(cls, d: dict) -> "Telemetry":
        
        """
        Extract's telemetry values such as: speed, gear and angle and return's the dataclass Telemetry.
        """
        
        return cls(
            angle=d["angle"],
            cur_lap_time=d["curLapTime"],
            damage=d["damage"],
            dist_from_start=d["distFromStart"],
            dist_raced=d["distRaced"],
            fuel=d["fuel"],
            gear=d["gear"],
            last_lap_time=d["lastLapTime"],
            opponents=d["opponents"],
            race_pos=d["racePos"],
            rpm=d["rpm"],
            speed_x=d["speedX"],
            speed_y=d["speedY"],
            speed_z=d["speedZ"],
            track=d["track"],
            track_pos=d["trackPos"],
            wheel_spin_vel=d["wheelSpinVel"],
            z=d["z"],
            focus=d["focus"]
        )