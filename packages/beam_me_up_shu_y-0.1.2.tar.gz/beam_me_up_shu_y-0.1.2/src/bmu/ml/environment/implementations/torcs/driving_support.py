import numpy as np
from typing import List

class TorcsDrivingSupport:
    
    
    def __init__(self, gears, throttle, vision):
        
        self._vision = vision
        self._throttle = throttle
        self._gears = gears      
    
    def driving_support(self, client, command_packet, agent_action) -> None:
        
        """
        Handles pedal and gear logic based on environment configuration.
        """
        
        if not self._throttle:
            
            obs = client.S.d
            speed_x = float(obs["speedX"])
            wheel_spin = np.array(obs["wheelSpinVel"], dtype=np.float32)
            sensor_dist = obs["track"]

            target_speed = self.get_target_speed(sensor_dist=sensor_dist)

            PEDAL_WINDOW = 50.0
            
            diff = speed_x - target_speed
            accel_brake = np.clip(-diff / PEDAL_WINDOW, -1.0, 1.0)

            speed_wheels = float(np.mean(wheel_spin))
            if (speed_x - speed_wheels) > 1.5:
                accel_brake -= (speed_x - speed_wheels - 1.5) / 5.0

            if accel_brake >= 0.0:
                command_packet["accel"] = accel_brake
                command_packet["brake"] = 0.0
            else:
                command_packet["accel"] = 0.0
                command_packet["brake"] = -accel_brake
        else:
            command_packet["accel"] = agent_action.get("accel", 0.0)
            command_packet["brake"] = agent_action.get("brake", 0.0)

        if self._gears:
            command_packet["gear"] = agent_action.get("gear", 1)
        else:
            command_packet["gear"] = agent_action.get("gear", 1)
            
    def get_target_speed(self, sensor_dist: List[float]) -> float:

        SENSOR_MAX = 150
        HIGH_RATIO = 0.6
        MEDIUM_RATIO = 0.3

        target_speed_list = [30, 55, 60, 65, 70, 80, 100, 145, 300]

        front_sensor = sensor_dist[9]
        front_sensor_norm = sensor_dist[9] / SENSOR_MAX

        wide_sensor = max(sensor_dist[3], sensor_dist[15]) / SENSOR_MAX  # 10+- degree

        ultrawide_sensor = (
            max(sensor_dist[1], sensor_dist[-2]) / SENSOR_MAX
        )  # 20+- degree

        if front_sensor == SENSOR_MAX:
            return target_speed_list[8]
        elif front_sensor_norm >= HIGH_RATIO:
            return target_speed_list[7]
        elif front_sensor_norm >= MEDIUM_RATIO:
            return target_speed_list[6]
        else:
            if wide_sensor >= HIGH_RATIO:
                return target_speed_list[5]

            elif wide_sensor >= MEDIUM_RATIO:
                return target_speed_list[4]
            else:
                if ultrawide_sensor >= HIGH_RATIO:
                    return target_speed_list[3]
                elif ultrawide_sensor >= MEDIUM_RATIO:
                    return target_speed_list[2]
                else:
                    return target_speed_list[1]