from enum import Enum

class TorcsTurnDirection(Enum):
    LEFT = "left"
    RIGHT = "right"
    STRAIGHT = "straight"
    
    
class TorcsDrivingMode(Enum):
    STRAIGHT = "straight"
    CORNERING = "cornering"
    
    
class TorcsTerminationReason(Enum):
    IDLING    = "idling"
    OFFTRACK  = "offtrack"
    DAMAGE    = "damage"
    LAP_COMPLETE = "lap_complete"
    

class TorcsRacelinePosition(Enum):
    ENTRY    = "entry"
    EXITPOINT  = "exitpoint"
    APEX    = "apex"
    STRAIGHT = "straight"
