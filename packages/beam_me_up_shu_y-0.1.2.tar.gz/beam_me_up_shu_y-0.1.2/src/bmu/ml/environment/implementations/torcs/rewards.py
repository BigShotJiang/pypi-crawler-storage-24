import numpy as np
from bmu.system.events import event_bus
from typing import TYPE_CHECKING, Dict, Any, ClassVar, List, Final, TypeAlias
from .telemetry import Telemetry
from .car_states import TorcsTurnDirection, TorcsRacelinePosition
from scipy.optimize import leastsq
import math

if TYPE_CHECKING:
    from bmu.system import Client


RewardResult: TypeAlias = tuple[float, bool]
PenaltyResult: TypeAlias = tuple[float, bool]

class TorcsRewards:

    _TERMINAL_JUDGE_START: ClassVar[int] = 250

    def __init__(self, car_angles : List[float]) -> None:

        self._time_step = 0
        self._last_damage = 0.0
        self._next_checkpoint = 5000.0
        self._last_dist_raced = 0
        
        self._car_angles: Final[List[float]] = car_angles 
        self._turn_direction : TorcsTurnDirection = TorcsTurnDirection.STRAIGHT
        self._front_sensor_history: List[float] = []
        self._raceline_position: TorcsRacelinePosition = TorcsRacelinePosition.STRAIGHT


    def reset(self) -> None:

        self._time_step = 0
        self._last_damage = 0.0
        self._next_checkpoint = 5000.0
        self._last_dist_raced = 0
        
        self._turn_direction : TorcsTurnDirection = TorcsTurnDirection.STRAIGHT

    def calculate(self, client: "Client") -> tuple[float, bool]:
        
        is_done = False
        telemetry = Telemetry.from_dict(client.S.d)
        
        self._update_timestep()
        # self._update_turn_dir(telemetry)
        # self._update_raceline_pos(telemetry)
        
        reward_components = {
            "speed": self._reward_speed(telemetry),
            "centering": self._reward_centering_test(telemetry),
            "progress": self._reward_progress(telemetry),
            "overspeed": self._punish_overspeed_test(telemetry),
            "damage": self._punish_damage(telemetry),
            "idling": self._punish_idling(telemetry),
            "offtrack": self._punish_offtrack(telemetry),
        }

        total_reward = 0.0
        
        for reward, done_flag in reward_components.values():
            total_reward += reward
            is_done |= done_flag

        total_reward = float(np.clip(total_reward, -15.0, 15.0))

        self._log_rewards(reward_components, total_reward, is_done)

        if is_done:
            client.R.d["meta"] = True
            client.respond_to_server()

        return total_reward, is_done

    def _reward_progress(self, telemetry: Telemetry) -> RewardResult:
        """
        Reward based on true distance traveled during the episode.
        """
        reward = (telemetry.dist_raced - self._last_dist_raced) / 100.0

        self._last_dist_raced = telemetry.dist_raced

        return reward, False

    def _reward_speed(self, telemetry: Telemetry) -> RewardResult:

        reward = (telemetry.speed_x * np.cos(telemetry.angle)) / 100.0

        return reward, False

    def _reward_checkpoint(self, telemetry: Telemetry) -> RewardResult:

        reward = 0

        if telemetry.dist_from_start >= self._next_checkpoint:
            reward += 5.0
            self._next_checkpoint += 5000.0

        return reward, False

    def _reward_centering(self, telemetry: Telemetry) -> RewardResult:

        reward = 0

        reward = (1.0 - abs(telemetry.track_pos)) * 0.3

        return reward, False
    
    def _reward_centering_test(self, telemetry: Telemetry) -> RewardResult:

        reward = (1.0 - abs(telemetry.track_pos)) * 0.3

        return reward, False

    def _reward_movement(self, telemetry: Telemetry) -> RewardResult:

        reward = 0

        movement_bonus = np.tanh(telemetry.speed_x / 20.0) * 0.5

        reward += movement_bonus

        return reward, False

    def _reward_lap(self, telemetry: Telemetry) -> RewardResult:

        """
        Terminates after one lap, currently no reward is given for completing a lap.
        """

        reward = 0
        is_done = False

        if telemetry.last_lap_time > 0:

            is_done = True

        return reward, is_done

    def _punish_underspeed(self, telemetry: Telemetry) -> PenaltyResult:
        
        reward = 0

        front_sensors = np.mean(telemetry.track[8:11])

        if front_sensors > 75 and telemetry.speed_x < 150:

            underspeed_penalty = (150 - telemetry.speed_x) / 100.0

            reward -= underspeed_penalty

        return reward, False

    def _punish_offtrack(self, telemetry: Telemetry) -> PenaltyResult:

        reward = 0

        if abs(telemetry.track_pos) > 1.0 or np.cos(telemetry.angle) < 0:
            reward -= 3.0

        return reward, False

    def _punish_slowness(self, telemetry: Telemetry) -> PenaltyResult:

        reward = 0

        if telemetry.speed_x < 5.0:
            reward -= 0.5

        return reward, False

    def _punish_damage(self, telemetry: Telemetry) -> PenaltyResult:

        reward = 0

        damage_delta = telemetry.damage - self._last_damage

        if damage_delta > 0:

            reward -= 2.0

        self._last_damage = telemetry.damage

        return reward, False

    def _punish_idling(self, telemetry: Telemetry) -> PenaltyResult:
        """
        Returns the reward penalty for idling and whether the episode should terminate.
        """
        reward = 0.0
        is_done = False

        if self._time_step > self._TERMINAL_JUDGE_START and telemetry.speed_x < 1.0:
            reward -= 5.0
            is_done = True

        return reward, is_done

    def _punish_overspeed_test(self, telemetry: Telemetry) -> PenaltyResult:

        reward = 0

        front_sensors = telemetry.track[9]

        if front_sensors < 50:

            if telemetry.speed_x > 100:

                overspeed_penalty = (telemetry.speed_x - 100) / 100.0

                reward -= overspeed_penalty

            # event_bus.request_log_info("Upcoming corner")

        return reward, False


    def _log_rewards( self, reward_components: Dict, total_reward: float, is_done: bool) -> None:

        payload = {
            **{name: value for name, (value, _) in reward_components.items()},
            "total_reward": total_reward,
            "done": is_done,
            "timestep": self._time_step,
        }

        event_bus.request_log_reward(payload)
        
    def _get_angle_map(self, telemetry: Telemetry, logging: bool ) -> Dict[float, float]:
        
        angle_map: Dict[float, float] = dict(zip(self._car_angles, telemetry.track))

        if logging and self._time_step % 5 == 0:
            event_bus.request_log_info("Angle mapping:")
            
            for pair in angle_map .items():
                key, value = pair
                event_bus.request_log_info(f"Angle: {key}, Distance: {value}")
        
        return angle_map 

    def _update_timestep(self) -> None:
        """
        Increments the timestep.
        """
        self._time_step += 1