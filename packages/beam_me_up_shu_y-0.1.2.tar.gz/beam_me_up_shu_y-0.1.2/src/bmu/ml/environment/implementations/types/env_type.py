
from enum import Enum, auto

class EnvType(Enum):
    TORCS = auto()
    DEBUG = auto()
    PENDULUM = auto()
    MOUNTAIN_CAR = auto()
    LUNAR_LANDER = auto()
    BIPEDAL_WALKER = auto()