# region Imports
import time
import gym
import numpy as np
from numpy.typing import NDArray
from gym import spaces
from bmu.system.network import Client
from bmu.system.events import event_bus
from .rewards import TorcsRewards
from .spaces import TorcsSpaces
from .driving_support import TorcsDrivingSupport
from typing import ClassVar, List, Final
# endregion


class TorcsEnv(gym.Env):

    """TORCS environment which provides support for configuration and multiple instances via different ports and environment ids.
    This class implments the stable baselines 3 gym.ENV class"""

    _TERMINAL_JUDGE_START: ClassVar[int] = 250
    _SHUTDOWN_TIME: ClassVar[float] = 0.35
    
    _CAR_ANGLES_STABLE: ClassVar[List[float]] = [-90, -60, -40, -25, -15, -8, -4, -2, -1, 0, 1, 2, 4, 8, 15, 25, 40, 60, 90]
    _CAR_ANGLES_AGRESSIVE: ClassVar[List[float]] = [-45.0, -19.0, -12.0, -7.0, -4.0, -2.5, -1.7, -1.0, -0.5, 0.0, 0.5, 1.0, 1.7, 2.5, 4.0, 7.0, 12.0, 19.0, 45.0]


    _SELECTED_ANGLES : ClassVar[List[float]] = _CAR_ANGLES_AGRESSIVE
    
    def __init__(
        self,
        vision: bool = False,
        throttle: bool = False,
        gear_change: bool = False,
        port: int = 3001,
        headless: bool = False,
        env_id: int = 0
    ) -> None:
        """
        Initializes the TORCS environment and launches the TORCS process.
        """
        super(TorcsEnv, self).__init__()
        
        self._is_first_run: bool = True
        self._observation: NDArray[np.float32] | None = None
        
        self._vision: Final[bool] = vision
        self._port: Final[int] = port + env_id
        self._id: Final[int] = env_id
        self._headless_mode: Final[bool] = headless
        self._process_name: Final[str] = f"torcs-env-{self._id}"

        event_bus.request_spawn_torcs(
            env_id=self._id,
            headless=self._headless_mode
        )

        self._rewards: TorcsRewards = TorcsRewards(self._SELECTED_ANGLES)
        
        self._spaces: TorcsSpaces = TorcsSpaces(gear_change, throttle, vision)
        
        self._driving_support: TorcsDrivingSupport = TorcsDrivingSupport(gear_change, throttle, vision)

        self._spaces.initialize_spaces()

    def step(self, action: NDArray[np.float32]) -> tuple[NDArray[np.float32], float, bool, dict]:
        """
        Performs a single simulation step and returns observation, is_done and the reward.
        """
        agent_action: dict = self._spaces.translate_action(
            action=action,
            client=self.client
        )

        self.set_meta(False)
        self.set_steer(agent_action["steer"])

        self._driving_support.driving_support(
            client=self.client,
            command_packet=self.client.R.d,
            agent_action=agent_action
        )

        self.client.respond_to_server()
        self.client.get_servers_input()

        self._observation = self.normalize_observation()

        reward, is_terminated = self._rewards.calculate(self.client)

        return self.get_obs(), reward, is_terminated, {}

    def reset(self, relaunch: bool = False) -> NDArray[np.float32]:
        """
        Resets the TORCS environment / process and establishes a new client connection.
        """
        self._rewards.reset()
        self._spaces.reset()

        if not self._is_first_run:
            self.set_meta(True)
            self.client.respond_to_server()

            if hasattr(self.client, "sock"):
                try:
                    self.client.sock.close()
                except Exception:
                    pass

            time.sleep(self._SHUTDOWN_TIME)

            if relaunch:
                event_bus.request_torcs_restart(
                    process_name=self._process_name
                )

        self.client: Client = Client(
            port=self._port,
            vision=self._vision,
            env_id=self._id,
            headless_mode=self._headless_mode,
            sensor_angles=self._SELECTED_ANGLES
        )

        self.client.max_steps = np.inf
        self.client.get_servers_input()

        self._observation = self.normalize_observation()
        self._is_first_run = False

        return self.get_obs()

    @property
    def action_space(self) -> spaces.Space:
        """Returns the action space needed for the gym.env interface"""
        return self._spaces.action_space

    @property
    def observation_space(self) -> spaces.Space:
        """Returns the observation space needed for the gym.env interface"""
        return self._spaces.observation_space

    def get_driver_action(self) -> dict:
        """Returns the TORCS driver action dictionary."""
        return self.client.R.d

    def get_telemetry(self) -> dict:
        """Returns the TORCS client telemetry dictionary."""
        return self.client.S.d

    def get_obs(self) -> NDArray[np.float32] | None:
        """Returns the current observation."""
        return self._observation

    def set_meta(self, value: bool) -> None:
        """Sets the meta value for the driver action dictionary to a target value."""
        self.client.R.d["meta"] = value

    def set_steer(self, value: float) -> None:
        """Sets the steer value for the driver action dictionary to a target value."""
        self.client.R.d["steer"] = value

    def normalize_observation(self) -> NDArray[np.float32] | NDArray[np.uint8]:
        """Normalizes telemetry or images into observation vectors."""
        if not self._vision:
            obs = np.hstack([
                np.array(self.client.S.d["focus"], dtype=np.float32) / 200.0,
                np.array(self.client.S.d["speedX"], dtype=np.float32) / 150.0,
                np.array(self.client.S.d["speedY"], dtype=np.float32) / 150.0,
                np.array(self.client.S.d["speedZ"], dtype=np.float32) / 150.0,
                np.array(self.client.S.d["opponents"], dtype=np.float32) / 200.0,
                np.array(self.client.S.d["rpm"], dtype=np.float32) / 10000.0,
                np.array(self.client.S.d["track"], dtype=np.float32) / 100.0,
                np.array(self.client.S.d["trackPos"], dtype=np.float32),
                np.array(self.client.S.d["angle"], dtype=np.float32) / np.pi,
                np.array(self.client.S.d["gear"], dtype=np.float32) / 6.0,
                np.array(self.client.S.d["wheelSpinVel"], dtype=np.float32) / 100.0,
                np.array(self.client.S.d["distFromStart"], dtype=np.float32) / 10000.0,
                np.array(self.client.S.d["lastLapTime"], dtype=np.float32) / 200.0,
            ])
            return obs.astype(np.float32)
        else:
            img = np.array(self.client.S.d["img"], dtype=np.uint8)
            return img.reshape(64, 64, 3).astype(np.uint8)