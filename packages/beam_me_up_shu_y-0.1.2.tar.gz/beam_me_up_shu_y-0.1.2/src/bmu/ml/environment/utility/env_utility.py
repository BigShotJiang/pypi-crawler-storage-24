import numpy as np
from bmu.system.events import event_bus, EventSignals

class Utility:
    
    @staticmethod  
    def Testing():
        print("Working")
     
    @staticmethod   
    def _output_telemetry(obs):
        for key, value in obs.items():
            event_bus.request_log_info(f"{key}: {value}")