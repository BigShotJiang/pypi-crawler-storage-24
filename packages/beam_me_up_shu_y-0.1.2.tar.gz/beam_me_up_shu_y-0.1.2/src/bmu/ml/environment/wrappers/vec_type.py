from enum import Enum, auto

class VecType(Enum):
    DUMMY = auto()
    SUBPROC = auto()