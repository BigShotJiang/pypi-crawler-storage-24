from ..implementations.torcs.env import TorcsEnv
from ..implementations.types.env_type import EnvType
from stable_baselines3.common.vec_env import SubprocVecEnv as SB3SubprocVecEnv
from bmu.system.events import event_bus
from typing import ClassVar, Any, Callable


class SubprocVecEnv():
    
    BASE_SEED: ClassVar[int] = 42
    
    ENV_REGISTRY: ClassVar[dict[EnvType, type]] = {
        EnvType.TORCS: TorcsEnv,
    }

    def __init__(self, env_type: EnvType, **config: Any) -> None:
        self._env_class = self.ENV_REGISTRY.get(env_type)
        
        if not self._env_class:
            event_bus.request_log_error("Non supported environment for subprocVecEnv")
        else:
            self._wrapped_env = self.wrap_env(**config)
        
    def wrap_env(self, num_env: int = 8, **config: Any) -> SB3SubprocVecEnv:
        """
        Creates and wraps 8 environments in a SubprocVecEnv wrapper. 
        Returns a list of environments.
        """
        return SB3SubprocVecEnv([self.make_env(i, **config) for i in range(num_env)])
    
    def make_env(self, rank: int, **config: Any) -> Callable:
        def _init():
            env = self._env_class(env_id=rank, **config)
            env.seed(self.BASE_SEED + rank)
            return env
        return _init

    def get_env(self) -> SB3SubprocVecEnv | None:
        if self._wrapped_env is None:
            event_bus.request_log_error("No wrapped environment to get")
            return None
        return self._wrapped_env