from ..implementations.torcs.env import TorcsEnv
from ..implementations.types.env_type import EnvType
from .base_vec_env import BaseVecEnv
from bmu.system.events import event_bus
from stable_baselines3.common.vec_env import DummyVecEnv as SB3DummyVecEnv
from typing import ClassVar, Any


class DummyVecEnv(BaseVecEnv):
    
    ENV_REGISTRY: ClassVar[dict[EnvType, type]] = {
        EnvType.TORCS: TorcsEnv,
    }
    
    def __init__(self, env_type: EnvType, **config: Any) -> None:
        self._env_class = self.ENV_REGISTRY.get(env_type)
        
        if not self._env_class:
            event_bus.request_log_error("Non supported environment for dummyVecEnv")
        else:
            self._wrapped_env = self.wrap_env(**config)
        
    def wrap_env(self, **config: Any) -> SB3DummyVecEnv:
        """
        Creates and returns a dummy vectorized environment.
        """
        env = self._env_class(env_id=0, **config)
        return SB3DummyVecEnv([lambda: env])
 
    def get_env(self) -> SB3DummyVecEnv | None:
        if self._wrapped_env is None:
            event_bus.request_log_error("No wrapped environment to get")
            return None
        return self._wrapped_env