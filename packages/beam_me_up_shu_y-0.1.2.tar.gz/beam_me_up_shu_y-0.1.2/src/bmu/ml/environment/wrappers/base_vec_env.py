from abc import ABC, abstractmethod

class BaseVecEnv(ABC):
    
    @abstractmethod
    def wrap_env(self):
        pass