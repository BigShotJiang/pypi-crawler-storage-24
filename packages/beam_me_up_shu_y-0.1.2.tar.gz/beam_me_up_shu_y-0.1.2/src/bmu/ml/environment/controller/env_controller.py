from typing import Any, TYPE_CHECKING, ClassVar
from bmu.system.events import event_bus, EventSignals
from ..wrappers.subproc_vec_env import SubprocVecEnv
from ..wrappers.dummy_vec_env import DummyVecEnv
from ..implementations.types.env_type import EnvType
from ..wrappers.vec_type import VecType
from ..implementations.torcs.env import TorcsEnv
from enum import Enum
import gym
import sys

if TYPE_CHECKING:
    from ..wrappers.subproc_vec_env import SubprocVecEnv
    from ..wrappers.dummy_vec_env import DummyVecEnv

class EnvironmentController:
    
    ENV_REGISTRY: dict[str, type] = {"torcs": TorcsEnv}

    def __init__(self) -> None:
        
        self._environment = None    
        event_bus.subscribe(EventSignals.REQUEST_START_ENV, self.start_env)
        
    
    @classmethod
    def register_environment(cls, name: str, env_class: gym.Env) -> None:
        """
        Allows users to register their environment from their project
        folder into the controller.
        """
        
        if not issubclass(env_class, gym.Env):
            
            event_bus.request_log_error(f"Registration Failed: '{env_class.__name__}' instance does not inherit from gym.Env")
            
            sys.exit(1)
            
            return
        
        cls.ENV_REGISTRY[name.lower()] = env_class
        
        event_bus.request_log_success(f"Registered custom environment: {name}")
        
    def validate_env(self, env: Any) -> None:
        
        lookup_key = env.name.lower() if isinstance(env, Enum) else str(env).lower()
        
        self._env_class = self.ENV_REGISTRY.get(lookup_key)
        
        if not self._env_class:
            event_bus.request_log_error(f"Environment '{lookup_key}' is currently not registered")
            return
    
    def start_env(self, requested_env: EnvType, env_wrapper: VecType, **env_config: Any) -> None:
        
        self.validate_env(env=requested_env)
        
        match env_wrapper:
            case VecType.SUBPROC:
                self._environment = SubprocVecEnv(requested_env, **env_config).get_env()
            case VecType.DUMMY:
                self._environment = DummyVecEnv(requested_env, **env_config).get_env()

        if self._environment:
            env_type_name = type(self._environment).__name__
            event_bus.request_log_success(f"Environment successfully started with wrapper: {env_type_name}")
    
    def get_env(self) -> SubprocVecEnv | DummyVecEnv | None:
        return self._environment