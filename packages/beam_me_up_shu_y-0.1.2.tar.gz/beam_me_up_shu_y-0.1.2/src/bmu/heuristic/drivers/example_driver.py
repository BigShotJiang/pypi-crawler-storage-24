from bmu.system.network import Client
from .base_driver import BaseDriver

class ExampleDriver(BaseDriver):

        
    def __init__(self):
        super().__init__(
            client_port=3001
        )
        
        self.target_speed = 60
        self._target_acceleration = 0.5
        self._target_brake = 0
        self._target_track_pos = 0
        
        self._upshift = 6000
        self._downshift = 2000
        
        
    def drive(self):
        
        self.client.get_servers_input()
        
        self._speed_x = self.client.S.d.get("speedX", 0.0)
        self._speed_y = self.client.S.d.get("speedY", 0.0)
        self._speed_z = self.client.S.d.get("speedZ", 0.0)
        self._gear = self.client.S.d.get("gear", 0.0)
        self._track = self.client.S.d.get("track", 0.0)
        self._rpm = self.client.S.d.get("rpm", 0.0)
        self._angle = self.client.S.d.get("angle", 0.0)
        self._track_pos  =  self.client.S.d.get("trackPos", 0.0)
        
        self.resolve_steering_angle()
        self.resolve_acceleration()
        self.resolve_gears()

        self.client.respond_to_server()

    def resolve_gears(self):
        
        if self._gear == 0:
            self.client.R.d["gear"] = 1
            return
        if self._rpm > self._upshift and self._gear < 6:
            self.client.R.d["gear"] = self._gear + 1
        elif self._rpm < self._downshift and self._gear > 1:
            self.client.R.d["gear"] = self._gear - 1
        else:
            self.client.R.d["gear"] = self._gear

    def resolve_acceleration(self):
        

        self.client.R.d["accel"] = self._target_acceleration
        self.client.R.d["brake"] = self._target_brake

    def resolve_steering_angle(self):
        
        kp_pos = 0.45
        kp_angle = 1.0

        position_correction = self._track_pos * kp_pos
        
        steering = (self._angle * kp_angle) - position_correction
        
        self.client.R.d["steer"] = max(-1.0, min(1.0, steering))
    