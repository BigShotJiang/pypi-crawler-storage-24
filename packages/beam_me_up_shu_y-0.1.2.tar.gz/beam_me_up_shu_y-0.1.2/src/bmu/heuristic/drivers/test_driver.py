from bmu.system.network import Client
from .base_driver import BaseDriver
class TestDriver(BaseDriver):

        
    def __init__(self):
        super().__init__(
            client_port=3001
        )
        
        self.target_speed = 400
        
        self._upshift = 6000
        self._downshift = 2000
        
        
    def drive(self):
        
        self.client.get_servers_input()
        
        self._speed_x = self.client.S.d.get("speedX", 0.0)
        self._speed_y = self.client.S.d.get("speedY", 0.0)
        self._speed_z = self.client.S.d.get("speedZ", 0.0)
        self._gear = self.client.S.d.get("gear", 0.0)
        self._track = self.client.S.d.get("track", 0.0)
        self._rpm = self.client.S.d.get("rpm", 0.0)
        self._angle = self.client.S.d.get("angle", 0.0)
        self._track_pos  =  self.client.S.d.get("trackPos", 0.0)
        
        self.raceline_logic()
        self.resolve_steering_angle()
        self.resolve_acceleration()
        self.resolve_gears()

        self.client.respond_to_server()

    def resolve_gears(self):
        
        if self._gear == 0:
            self.client.R.d["gear"] = 1
            return

        if self._rpm > self._upshift and self._gear < 6:
            self.client.R.d["gear"] = self._gear + 1
        elif self._rpm < self._downshift and self._gear > 1:
            self.client.R.d["gear"] = self._gear - 1
        else:
            self.client.R.d["gear"] = self._gear

    def resolve_acceleration(self):
        

        self.client.R.d["accel"] = self._target_acceleration
        self.client.R.d["brake"] = self._target_brake

    def resolve_steering_angle(self):
        
        alpha = 0.01
        
        if not hasattr(self, '_smoothed_target'):
            self._smoothed_target = self._track_pos
            
        self._smoothed_target = self._smoothed_target + (self._target_track_pos - self._smoothed_target) * alpha

        desired_steer = self._angle - self._smoothed_target
        
        kp = 0.5 
        
        final_steer = desired_steer * kp

        self.client.R.d["steer"] = max(-1.0, min(1.0, final_steer))
    
    def raceline_logic(self):
        left_sensors = max(self._track[0:8])
        right_sensors = max(self._track[10:18])
        front_sensors = self._track[0]

        safety_value = 0.05  

        OUTER_DISTANCE = 80
        
        APEX_DISTANCE = 50

        if left_sensors > right_sensors and front_sensors < OUTER_DISTANCE:
            
            if front_sensors > APEX_DISTANCE:
                
                self._target_acceleration = 0.5
                self._target_brake = 0
                self._target_track_pos = self._track_pos + (1.0 - safety_value)
            else:
                self._target_acceleration = 0.5
                self._target_brake = 0
                self._target_track_pos = self._track_pos + (-1.0 + safety_value)
                
        elif right_sensors > left_sensors and front_sensors < OUTER_DISTANCE:
            
            if front_sensors > APEX_DISTANCE:
                
                
                self._target_track_pos = self._track_pos + (-1.0 + safety_value)
                self._target_acceleration = 0.5
                self._target_brake = 0
                
            else:
                
                self._target_acceleration = 0.5
                self._target_brake = 0
                self._target_track_pos = self._track_pos + (1.0 - safety_value)       
            
        else:
            
            self._target_track_pos = 0.0
            self._target_acceleration = 0.5
            self._target_brake = 0
            