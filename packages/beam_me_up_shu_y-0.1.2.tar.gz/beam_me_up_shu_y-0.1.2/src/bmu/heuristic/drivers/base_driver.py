from abc import ABC, abstractmethod
from bmu.system.network import Client
from bmu.system.events import event_bus

class BaseDriver(ABC):
    def __init__(self, client_port):
        self.client = Client(
            port=client_port
        )
        
    @abstractmethod
    def drive(self):
        """
        Main function for drive, apply steering + acceleration/veloicty logic here.

        :param self: This instance
        :param client: Client obj.
        """

    def run(self):
        """The main loop that keeps the script alive and driving."""
        event_bus.request_log_success("Starting Driver Loop...")
        while True:
            self.drive()