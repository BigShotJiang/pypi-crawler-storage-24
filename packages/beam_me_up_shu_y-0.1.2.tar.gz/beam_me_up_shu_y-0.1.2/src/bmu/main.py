from bmu.system.cli.console import BmuConsole
from bmu.system.cli.options import MainMenuOption
from bmu.system.project.project_factory import ProjectFactory, HeuristicBotConfig

def __main() -> None:

    console = BmuConsole()
    factory = ProjectFactory()

    DISPATCH = {
        MainMenuOption.CREATE_HEURISTIC_BOT: lambda: _create_heuristic_bot(console, factory),
        MainMenuOption.EXIT: console.exit,
    }

    console.header()

    while True:
        
        action = console.main_menu()

        if action is None:
            console.exit()

        DISPATCH[MainMenuOption(action)]()

def _create_heuristic_bot(console: BmuConsole, factory: ProjectFactory) -> None:
    
    name = console.prompt_bot_name()
    
    if not name:
        return
    
    console.section("Creating heuristic bot")
    
    try:
        
        dest = factory.get_user_project_dir()
        
        paths = factory.create_heuristic_bot(HeuristicBotConfig(name=name), dest)
        
        console.show_created_path(name, paths["driver"])
        
    except FileExistsError as e:
        
        console.print_error(str(e))


def main() -> None:
    
    console = BmuConsole()
    
    project_factory = ProjectFactory()
    
    console.agent_type_menu()
    
    console.archive_menu()
    

if __name__ == "__main__":
    main()
