from bmu.system.log import LogController
from bmu.system.processing import ProcessController
from bmu.ml.environment import EnvironmentController, TorcsEnv
from bmu.ml.agents import AgentController

# Its recommended to turn logging off during training for faster training times due to large amount of log messages, this should be used for debugging.

log = LogController(reward_logging=True, console_logging=True, file_logging=True)

process_controller = ProcessController()

env_controller = EnvironmentController()

env_controller.register_environment("torcs",TorcsEnv)

agent_controller = AgentController()


