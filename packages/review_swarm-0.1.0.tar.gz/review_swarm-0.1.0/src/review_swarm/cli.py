"""CLI entry point for ReviewSwarm."""

from __future__ import annotations

import click

from .config import Config


@click.group()
def main():
    """ReviewSwarm -- Collaborative AI Code Review MCP Server."""
    pass


@main.command()
@click.option("--port", default=8787, help="Port for SSE transport")
@click.option("--host", default="127.0.0.1", help="Host to bind to")
@click.option("--transport", default="sse", type=click.Choice(["sse", "stdio"]))
def serve(port: int, host: str, transport: str):
    """Start the ReviewSwarm MCP server."""
    from .server import create_mcp_server

    mcp = create_mcp_server()

    click.echo(f"ReviewSwarm v0.1.0 starting on {transport}...")
    if transport == "sse":
        click.echo(f"Listening on http://{host}:{port}/sse")
        mcp.run(transport="sse", host=host, port=port)
    else:
        mcp.run(transport="stdio")


@main.command("list-sessions")
def list_sessions():
    """List all review sessions."""
    config = Config.load()
    from .session_manager import SessionManager

    mgr = SessionManager(config)
    sessions = mgr.list_sessions()

    if not sessions:
        click.echo("No sessions found.")
        return

    for s in sessions:
        status = s.get("status", "unknown")
        name = s.get("name", s["session_id"])
        click.echo(f"  {s['session_id']}  [{status}]  {name}")


if __name__ == "__main__":
    main()
