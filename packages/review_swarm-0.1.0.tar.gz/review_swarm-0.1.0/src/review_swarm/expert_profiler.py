"""Expert profile loading and project analysis for expert suggestions."""

from __future__ import annotations

import re
from pathlib import Path

import yaml


_BUILTIN_DIR = Path(__file__).parent / "experts"


class ExpertProfiler:
    def __init__(self, custom_dirs: list[Path] | None = None):
        self._custom_dirs = custom_dirs or []

    def list_profiles(self) -> list[dict]:
        profiles = []
        for yaml_file in sorted(_BUILTIN_DIR.glob("*.yaml")):
            profiles.append(self._load_yaml(yaml_file))
        for d in self._custom_dirs:
            if d.exists():
                for yaml_file in sorted(d.glob("*.yaml")):
                    profiles.append(self._load_yaml(yaml_file))
        return profiles

    def load_profile(self, name: str) -> dict:
        # Check built-in first
        path = _BUILTIN_DIR / f"{name}.yaml"
        if path.exists():
            return self._load_yaml(path)
        # Check custom dirs
        for d in self._custom_dirs:
            path = d / f"{name}.yaml"
            if path.exists():
                return self._load_yaml(path)
        raise FileNotFoundError(f"Expert profile '{name}' not found")

    def suggest_experts(self, project_path: str) -> list[dict]:
        proj = Path(project_path)
        if not proj.exists():
            return []

        # Collect all source file contents for analysis
        file_contents: dict[str, str] = {}
        for ext in ("*.py", "*.js", "*.ts", "*.tsx", "*.go", "*.rs", "*.java"):
            for f in proj.rglob(ext):
                try:
                    file_contents[str(f.relative_to(proj))] = f.read_text(
                        encoding="utf-8", errors="ignore"
                    )
                except Exception:
                    continue

        has_docs = (proj / "docs").exists() and any((proj / "docs").rglob("*"))
        has_tests = (proj / "tests").exists() and any((proj / "tests").rglob("*"))

        suggestions = []
        for profile in self.list_profiles():
            score = self._score_relevance(profile, file_contents, has_docs, has_tests)
            if score > 0:
                profile_name = Path(profile.get("_source_file", "")).stem
                suggestions.append({
                    "profile_name": profile_name,
                    "name": profile["name"],
                    "description": profile.get("description", ""),
                    "confidence": min(score, 1.0),
                })

        suggestions.sort(key=lambda s: s["confidence"], reverse=True)
        return suggestions

    def _score_relevance(
        self, profile: dict, file_contents: dict[str, str],
        has_docs: bool, has_tests: bool,
    ) -> float:
        score = 0.0
        signals = profile.get("relevance_signals", {})
        import_signals = signals.get("imports", [])
        pattern_signals = signals.get("patterns", [])

        all_text = "\n".join(file_contents.values())

        # Check imports
        for imp in import_signals:
            if f"import {imp}" in all_text or f"from {imp}" in all_text:
                score += 0.3

        # Check patterns
        for pat in pattern_signals:
            try:
                if re.search(pat, all_text):
                    score += 0.2
            except re.error:
                continue

        # Base score for universal experts
        if file_contents:
            name = profile.get("name", "").lower()
            if "signature" in name or "consistency" in name:
                score = max(score, 0.5)  # always relevant for code projects

        return score

    def _load_yaml(self, path: Path) -> dict:
        data = yaml.safe_load(path.read_text(encoding="utf-8"))
        data["_source_file"] = str(path)
        return data
