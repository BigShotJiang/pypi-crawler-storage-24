"""Session lifecycle management."""

from __future__ import annotations

import json
import secrets
from datetime import datetime, timezone
from pathlib import Path

from .config import Config
from .finding_store import FindingStore
from .claim_registry import ClaimRegistry
from .reaction_engine import ReactionEngine
from .models import _now_iso


class SessionManager:
    def __init__(self, config: Config, expert_profiler=None):
        self._config = config
        self._expert_profiler = expert_profiler
        self._stores: dict[str, FindingStore] = {}
        self._claims: dict[str, ClaimRegistry] = {}
        self._engines: dict[str, ReactionEngine] = {}

    def start_session(self, project_path: str, name: str | None = None) -> str:
        today = datetime.now(timezone.utc).strftime("%Y-%m-%d")
        seq = len(list(self._config.sessions_path.glob(f"sess-{today}-*"))) + 1
        session_id = f"sess-{today}-{seq:03d}"

        sess_dir = self._config.sessions_path / session_id
        sess_dir.mkdir(parents=True, exist_ok=True)

        meta = {
            "schema_version": 1,
            "session_id": session_id,
            "project_path": project_path,
            "name": name or session_id,
            "created_at": _now_iso(),
            "status": "active",
        }
        (sess_dir / "meta.json").write_text(
            json.dumps(meta, indent=2), encoding="utf-8"
        )
        (sess_dir / "findings.jsonl").write_text("", encoding="utf-8")
        (sess_dir / "claims.json").write_text("[]", encoding="utf-8")
        (sess_dir / "reactions.jsonl").write_text("", encoding="utf-8")

        # Auto-suggest experts if configured (spec requirement)
        if self._expert_profiler and self._config.experts.auto_suggest:
            try:
                suggestions = self._expert_profiler.suggest_experts(project_path)
                meta["suggested_experts"] = suggestions
                (sess_dir / "meta.json").write_text(
                    json.dumps(meta, indent=2), encoding="utf-8"
                )
            except Exception:
                pass  # non-critical, session starts regardless

        return session_id

    def end_session(self, session_id: str) -> dict:
        sess_dir = self._session_dir(session_id)

        # Read store BEFORE clearing caches
        store = self.get_finding_store(session_id)
        result = {
            "session_id": session_id,
            "status": "completed",
            "finding_count": store.count(),
            "findings_by_severity": store.count_by_severity(),
            "findings_by_status": store.count_by_status(),
        }

        # Release all claims
        claims_reg = self.get_claim_registry(session_id)
        claims_reg.release_all(session_id)

        # Update meta
        meta = self._load_meta(sess_dir)
        meta["status"] = "completed"
        meta["ended_at"] = _now_iso()
        (sess_dir / "meta.json").write_text(
            json.dumps(meta, indent=2), encoding="utf-8"
        )

        # Clear caches after all reads are done
        self._stores.pop(session_id, None)
        self._claims.pop(session_id, None)
        self._engines.pop(session_id, None)

        return result

    def get_session(self, session_id: str) -> dict:
        sess_dir = self._session_dir(session_id)
        meta = self._load_meta(sess_dir)
        store = self.get_finding_store(session_id)
        claims = self.get_claim_registry(session_id)
        return {
            **meta,
            "finding_count": store.count(),
            "findings_by_severity": store.count_by_severity(),
            "findings_by_status": store.count_by_status(),
            "active_claims": len(claims.get_claims(session_id)),
        }

    def list_sessions(self) -> list[dict]:
        sessions = []
        if not self._config.sessions_path.exists():
            return sessions
        for sess_dir in sorted(self._config.sessions_path.iterdir()):
            if not sess_dir.is_dir():
                continue
            meta_file = sess_dir / "meta.json"
            if not meta_file.exists():
                continue
            meta = json.loads(meta_file.read_text(encoding="utf-8"))
            sessions.append(meta)
        return sessions

    def get_finding_store(self, session_id: str) -> FindingStore:
        if session_id not in self._stores:
            sess_dir = self._session_dir(session_id)
            self._stores[session_id] = FindingStore(
                sess_dir / "findings.jsonl",
                max_findings=10_000,
            )
        return self._stores[session_id]

    def get_claim_registry(self, session_id: str) -> ClaimRegistry:
        if session_id not in self._claims:
            sess_dir = self._session_dir(session_id)
            self._claims[session_id] = ClaimRegistry(sess_dir / "claims.json")
        return self._claims[session_id]

    def get_reaction_engine(self, session_id: str) -> ReactionEngine:
        if session_id not in self._engines:
            sess_dir = self._session_dir(session_id)
            store = self.get_finding_store(session_id)
            self._engines[session_id] = ReactionEngine(
                store,
                sess_dir / "reactions.jsonl",
                confirm_threshold=self._config.consensus.confirm_threshold,
            )
        return self._engines[session_id]

    def get_project_path(self, session_id: str) -> str:
        sess_dir = self._session_dir(session_id)
        meta = self._load_meta(sess_dir)
        return meta["project_path"]

    def _session_dir(self, session_id: str) -> Path:
        d = self._config.sessions_path / session_id
        if not d.exists():
            raise KeyError(f"Session {session_id} not found")
        return d

    def _load_meta(self, sess_dir: Path) -> dict:
        return json.loads((sess_dir / "meta.json").read_text(encoding="utf-8"))
