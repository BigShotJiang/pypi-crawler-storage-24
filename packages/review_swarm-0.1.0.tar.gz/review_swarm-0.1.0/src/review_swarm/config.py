"""Global configuration loading."""

from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path

import yaml


@dataclass
class ConsensusConfig:
    confirm_threshold: int = 2
    auto_close_duplicates: bool = True


@dataclass
class ExpertsConfig:
    custom_dir: str = "~/.review-swarm/custom-experts"
    auto_suggest: bool = True


@dataclass
class Config:
    storage_dir: str = "~/.review-swarm"
    max_sessions: int = 50
    default_format: str = "markdown"
    consensus: ConsensusConfig = field(default_factory=ConsensusConfig)
    experts: ExpertsConfig = field(default_factory=ExpertsConfig)

    @property
    def storage_path(self) -> Path:
        return Path(self.storage_dir).expanduser()

    @property
    def sessions_path(self) -> Path:
        return self.storage_path / "sessions"

    @property
    def custom_experts_path(self) -> Path:
        return Path(self.experts.custom_dir).expanduser()

    @classmethod
    def load(cls, path: Path | None = None) -> Config:
        if path is None:
            path = Path("~/.review-swarm/config.yaml").expanduser()
        if not path.exists():
            return cls()
        data = yaml.safe_load(path.read_text(encoding="utf-8")) or {}
        consensus = ConsensusConfig(**data.get("consensus", {}))
        experts = ExpertsConfig(**data.get("experts", {}))
        return cls(
            storage_dir=data.get("storage_dir", "~/.review-swarm"),
            max_sessions=data.get("max_sessions", 50),
            default_format=data.get("default_format", "markdown"),
            consensus=consensus,
            experts=experts,
        )
