"""FindingStore -- Append-only JSONL storage with in-memory index for findings."""

from __future__ import annotations

import json
from collections import Counter
from pathlib import Path

from .models import Category, Finding, Severity, Status, _now_iso


class FindingStore:
    """Append-only JSONL storage with in-memory index for findings.

    Each finding is stored as one JSON line in the JSONL file.
    An in-memory dict provides fast lookup/filtering.
    """

    def __init__(self, jsonl_path: Path, max_findings: int = 10_000) -> None:
        self._path = Path(jsonl_path)
        self._max_findings = max_findings
        self._findings: dict[str, Finding] = {}
        self._load()

    # ── Public API ──────────────────────────────────────────────────────

    def post(self, finding: Finding) -> str:
        """Store a new finding. Sets timestamps, appends to JSONL.

        Returns the finding ID.
        Raises ValueError if the store has reached its max_findings limit.
        """
        if len(self._findings) >= self._max_findings:
            raise ValueError(
                f"Finding limit reached ({self._max_findings}). "
                "Cannot store more findings."
            )
        now = _now_iso()
        finding.created_at = now
        finding.updated_at = now
        self._findings[finding.id] = finding
        self._append(finding)
        return finding.id

    def get(self, **filters) -> list[Finding]:
        """Return findings matching all provided filters.

        Supported filters:
            file (str), severity (Severity), category (Category),
            expert_role (str), status (Status), min_confidence (float).
        """
        results = list(self._findings.values())

        if "file" in filters:
            results = [f for f in results if f.file == filters["file"]]
        if "severity" in filters:
            results = [f for f in results if f.severity == filters["severity"]]
        if "category" in filters:
            results = [f for f in results if f.category == filters["category"]]
        if "expert_role" in filters:
            results = [
                f for f in results if f.expert_role == filters["expert_role"]
            ]
        if "status" in filters:
            results = [f for f in results if f.status == filters["status"]]
        if "min_confidence" in filters:
            min_conf = filters["min_confidence"]
            results = [f for f in results if f.confidence >= min_conf]

        return results

    def get_by_id(self, finding_id: str) -> Finding | None:
        """Return a finding by its ID, or None if not found."""
        return self._findings.get(finding_id)

    def count(self) -> int:
        """Return total number of findings."""
        return len(self._findings)

    def count_by_severity(self) -> dict[str, int]:
        """Return counts grouped by severity value."""
        counter: Counter[str] = Counter()
        for f in self._findings.values():
            counter[f.severity.value] += 1
        return dict(counter)

    def count_by_status(self) -> dict[str, int]:
        """Return counts grouped by status value."""
        counter: Counter[str] = Counter()
        for f in self._findings.values():
            counter[f.status.value] += 1
        return dict(counter)

    # ── Private (called by ReactionEngine / internal) ───────────────────

    def _update_status(self, finding_id: str, status: Status) -> None:
        """Update the status of a finding. Rewrites JSONL."""
        finding = self._findings.get(finding_id)
        if finding is None:
            raise KeyError(f"Finding {finding_id} not found")
        finding.status = status
        finding.updated_at = _now_iso()
        self._flush()

    def _add_reaction(self, finding_id: str, reaction_dict: dict) -> None:
        """Append a reaction dict to a finding's reactions list. Flushes."""
        finding = self._findings.get(finding_id)
        if finding is None:
            raise KeyError(f"Finding {finding_id} not found")
        finding.reactions.append(reaction_dict)
        finding.updated_at = _now_iso()
        self._flush()

    def _add_related(self, finding_id: str, related_id: str) -> None:
        """Append a related finding ID if not already present. Flushes."""
        finding = self._findings.get(finding_id)
        if finding is None:
            raise KeyError(f"Finding {finding_id} not found")
        if related_id not in finding.related_findings:
            finding.related_findings.append(related_id)
            finding.updated_at = _now_iso()
            self._flush()

    # ── I/O ─────────────────────────────────────────────────────────────

    def _flush(self) -> None:
        """Rewrite the entire JSONL file from in-memory state.

        NOTE: breaks strict append-only semantics for v0.1 -- acceptable
        because updates (status, reactions) require modifying existing lines.
        """
        with open(self._path, "w", encoding="utf-8") as fh:
            for finding in self._findings.values():
                fh.write(json.dumps(finding.to_dict()) + "\n")

    def _append(self, finding: Finding) -> None:
        """Append a single finding as one JSON line to the JSONL file."""
        self._path.parent.mkdir(parents=True, exist_ok=True)
        with open(self._path, "a", encoding="utf-8") as fh:
            fh.write(json.dumps(finding.to_dict()) + "\n")

    def _load(self) -> None:
        """Load all findings from the JSONL file into memory."""
        if not self._path.exists():
            return
        with open(self._path, "r", encoding="utf-8") as fh:
            for line in fh:
                line = line.strip()
                if not line:
                    continue
                data = json.loads(line)
                finding = Finding.from_dict(data)
                self._findings[finding.id] = finding
