# ReviewSwarm

Collaborative AI code review via MCP. Multiple specialized agents review your code simultaneously, coordinate through a shared whiteboard, and reach consensus on findings.

ReviewSwarm is **not** an LLM -- it's infrastructure. It provides 12 MCP tools that AI agents use to post findings, claim files, react to each other's work, and generate reports. You spawn the agents; ReviewSwarm coordinates them.

## Install

```bash
cd review-swarm
pip install -e ".[dev]"
```

## Quick Start

### 1. Add to Claude Code

Add to your `~/.claude/settings.json` (or project `.mcp.json`):

```json
{
  "mcpServers": {
    "review-swarm": {
      "command": "review-swarm",
      "args": ["serve", "--transport", "stdio"]
    }
  }
}
```

Or with SSE transport (for multi-client like Cursor/Windsurf):

```json
{
  "mcpServers": {
    "review-swarm": {
      "url": "http://127.0.0.1:8787/sse"
    }
  }
}
```

Start the server first: `review-swarm serve --port 8787`

### 2. Run a Review

Tell your AI assistant:

> "Start a ReviewSwarm session for this project. Use the threading-safety, api-signatures, and consistency experts. Review all Python files in src/."

The agent will:
1. Call `start_session` with your project path
2. Call `suggest_experts` to see recommended experts
3. Call `claim_file` for each file it reviews
4. Call `post_finding` for each issue found (with evidence)
5. Call `get_findings` to see what other experts found
6. Call `react` to confirm/dispute other findings
7. Call `get_summary` for the final report

### 3. Multi-Agent Review (the real power)

Launch 3 parallel agents, each with a different expert role:

```
Agent A (threading-safety): "You are a Threading Safety Expert reviewing this project.
  Use the ReviewSwarm MCP tools. Session ID: sess-2026-03-21-001.
  Claim files before reviewing. Post findings with evidence.
  Check other experts' findings and react to them."

Agent B (api-signatures): same prompt, different role

Agent C (consistency): same prompt, different role
```

Each agent claims files, posts findings, and reacts to others' work. ReviewSwarm tracks consensus automatically:
- **2+ confirms** (no disputes) = finding is **confirmed**
- **1+ dispute** = finding is **disputed** (with reason)
- **duplicate** reactions link related findings

## CLI

```bash
# Start server (stdio for single client)
review-swarm serve --transport stdio

# Start server (SSE for multiple clients)
review-swarm serve --port 8787

# List past sessions
review-swarm list-sessions
```

## MCP Tools (12 total)

### Session Management
| Tool | Description |
|------|-------------|
| `start_session` | Start a review session for a project path |
| `end_session` | End session, release claims, get summary stats |
| `get_session` | Get current session state (finding counts, claims) |
| `list_sessions` | List all sessions |

### Expert Coordination
| Tool | Description |
|------|-------------|
| `suggest_experts` | Analyze project, recommend expert profiles |
| `claim_file` | Claim a file for review (prevents duplicate work) |
| `release_file` | Release a claimed file |
| `get_claims` | See which files are currently claimed |

### Findings
| Tool | Description |
|------|-------------|
| `post_finding` | Post a finding with evidence (actual + expected + source_ref) |
| `get_findings` | Query findings with filters (severity, file, status, etc.) |
| `react` | React to a finding: confirm, dispute, extend, or duplicate |
| `get_summary` | Generate markdown or JSON report |

### post_finding Parameters

Every finding requires evidence:

```
session_id:        "sess-2026-03-21-001"
expert_role:       "threading-safety"
file:              "src/server.py"
line_start:        42
line_end:          58
severity:          "critical" | "high" | "medium" | "low" | "info"
category:          "bug" | "omission" | "inconsistency" | "security" | "performance" | "style" | "design"
title:             "Race condition in cache update"
actual:            "self._cache[key] = value without lock"
expected:          "Cache writes should be protected by self._lock"
source_ref:        "src/server.py:45"
suggestion_action: "fix" | "investigate" | "document" | "ignore"
suggestion_detail: "Wrap cache write in 'with self._lock:' block"
confidence:        0.92
```

### react Parameters

```
session_id:          "sess-2026-03-21-001"
expert_role:         "api-signatures"
finding_id:          "f-a1b2c3"
reaction:            "confirm" | "dispute" | "extend" | "duplicate"
reason:              "Verified: no lock protection on lines 42-58"
related_finding_id:  "f-d4e5f6"   # for duplicate/extend only
```

## Built-in Expert Profiles

| Profile | Detects |
|---------|---------|
| `threading-safety` | Race conditions, deadlocks, unprotected shared state |
| `api-signatures` | Signature/docstring mismatches, bad defaults, type errors |
| `consistency` | Cross-file contradictions, stale docs, broken imports |

### Custom Experts

Create YAML files in `~/.review-swarm/custom-experts/`:

```yaml
name: "Security Expert"
version: "1.0"
description: "OWASP Top 10 and injection vulnerabilities"
file_patterns: ["**/*.py", "**/*.js"]
exclude_patterns: ["tests/**"]
relevance_signals:
  imports: ["flask", "django", "fastapi", "sqlalchemy"]
  patterns: ["request\\.", "cursor\\.execute", "eval\\("]
check_rules:
  - id: "sql-injection"
    description: "SQL queries built from user input"
    severity_default: "critical"
    check: "Find string formatting in SQL queries"
severity_guidance:
  critical: "Direct injection with user-controlled input"
  high: "Injection possible with crafted input"
system_prompt: |
  You are a Security Expert. Review code for injection
  vulnerabilities, auth bypasses, and data exposure.
  ...
```

## Configuration

Optional. Create `~/.review-swarm/config.yaml`:

```yaml
storage_dir: "~/.review-swarm"
max_sessions: 50
default_format: "markdown"

consensus:
  confirm_threshold: 2        # confirms needed without disputes
  auto_close_duplicates: true

experts:
  custom_dir: "~/.review-swarm/custom-experts"
  auto_suggest: true           # suggest experts on session start
```

## Data Storage

Sessions stored in `~/.review-swarm/sessions/`:

```
~/.review-swarm/sessions/
  sess-2026-03-21-001/
    meta.json          # Session metadata, status
    findings.jsonl     # Append-only findings log
    claims.json        # Current file claims
    reactions.jsonl    # Reaction log
```

## Development

```bash
pip install -e ".[dev]"
pytest                         # 90 tests, <1s
pytest -v --tb=short           # verbose output
```

## How It Works

```
You (Claude Code / Cursor / Windsurf)
  |
  |  "Review this project with 3 experts"
  v
Spawn Agent A ──── MCP ──┐
Spawn Agent B ──── MCP ──┤
Spawn Agent C ──── MCP ──┤
                         v
              ReviewSwarm Server
              ┌─────────────────┐
              │  Shared State:  │
              │  - Findings     │  Agents read each other's work,
              │  - Claims       │  confirm or dispute findings,
              │  - Reactions    │  avoid reviewing same files.
              │  - Consensus    │
              └─────────────────┘
                         │
                         v
              Final Report (markdown/JSON)
              - Confirmed findings (2+ agrees)
              - Disputed findings (with reasons)
              - Per-file breakdown
              - Expert coverage map
```
