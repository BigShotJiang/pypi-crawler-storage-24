# Project Authors

The following people have made contributions to the project (in alphabetical
order by last name) and are considered "The Verde Developers":

* [Sarah Margrethe Askevold](https://github.com/SAskevold) - University of Liverpool, UK (ORCID: [0000-0002-9434-3594](https://www.orcid.org/0000-0002-9434-3594))
* [David Hoese](https://github.com/djhoese) - University of Wisconsin - Madison, USA (ORCID: [0000-0003-1167-7829](https://www.orcid.org/0000-0003-1167-7829))
* [Lindsey Heagy](https://github.com/lheagy) - University of California Berkeley, Department of Statistics, USA (ORCID: [0000-0002-1551-5926](https://www.orcid.org/0000-0002-1551-5926))
* [Gabriel G. R. de Lima](https://github.com/Gabriel-Goes) - Universidade de São Paulo, Brazil (ORCID: [0009-0009-7325-8524](https://orcid.org/0009-0009-7325-8524))
* [Jesse Pisel](https://github.com/jessepisel) - University of Texas at Austin, College of Natural Sciences, USA (ORCID: [0000-0002-7358-0590](https://www.orcid.org/0000-0002-7358-0590))
* [Santiago Soler](https://github.com/santisoler) - University of British Columbia, BC, Canada (ORCID: [0000-0001-9202-5317](https://www.orcid.org/0000-0001-9202-5317))
* [Gelson Ferreira Souza-Junior](https://github.com/Souza-junior) - Universidade de São Paulo, Brazil (ORCID: [0000-0002-5695-4239](https://orcid.org/0000-0002-5695-4239))
* [Matthew Tankersley](https://github.com/mdtanker) - Kiel University, Germany (ORCID: [0000-0003-4266-8554](https://orcid.org/0000-0003-4266-8554))
* [Leonardo Uieda](https://github.com/leouieda) - Universidade de São Paulo, Brazil (ORCID: [0000-0001-6123-9515](https://www.orcid.org/0000-0001-6123-9515))
