# simplecalc
一个适合初学者的简单 Python 计算库。

## 安装
```bash
pip install simplecalc-yourname
```

## 使用
```python
from simplecalc import add, sub


print(add(1, 2))  # 3
print(sub(5, 3))  # 2
```

