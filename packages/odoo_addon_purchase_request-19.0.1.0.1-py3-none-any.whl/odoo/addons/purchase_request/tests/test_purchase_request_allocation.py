# Copyright 2018-2019 ForgeFlow, S.L.
# License LGPL-3.0 or later (https://www.gnu.org/licenses/lgpl-3.0)

from odoo import SUPERUSER_ID
from odoo.tests import Form, common


class TestPurchaseRequestToRfq(common.TransactionCase):
    def setUp(self):
        super().setUp()
        self.purchase_request = self.env["purchase.request"]
        self.purchase_request_line = self.env["purchase.request.line"]
        self.wiz = self.env["purchase.request.line.make.purchase.order"]
        self.purchase_order = self.env["purchase.order"]

        # Create test supplier
        self.supplier = self.env["res.partner"].create(
            {
                "name": "Test Supplier",
                "is_company": True,
                "supplier_rank": 1,
            }
        )

        vendor = self.env["res.partner"].create({"name": "Partner #2"})
        self.service_product = self.env["product.product"].create(
            {"name": "Product Service Test", "type": "service"}
        )
        self.product_product = self.env["product.product"].create(
            {
                "name": "Product Product Test",
                "type": "consu",
                "is_storable": True,
                "description_purchase": "Test Description",
            }
        )
        self.env["product.supplierinfo"].create(
            {
                "partner_id": vendor.id,
                "product_tmpl_id": self.service_product.product_tmpl_id.id,
            }
        )
        self.env["product.supplierinfo"].create(
            {
                "partner_id": vendor.id,
                "product_tmpl_id": self.product_product.product_tmpl_id.id,
            }
        )

    def test_purchase_request_allocation(self):
        vals = {
            "picking_type_id": self.env.ref("stock.picking_type_in").id,
            "requested_by": SUPERUSER_ID,
        }
        purchase_request1 = self.purchase_request.create(vals)
        vals = {
            "request_id": purchase_request1.id,
            "product_id": self.product_product.id,
            "product_uom_id": self.env.ref("uom.product_uom_unit").id,
            "product_qty": 2.0,
        }
        purchase_request_line1 = self.purchase_request_line.create(vals)
        vals = {
            "picking_type_id": self.env.ref("stock.picking_type_in").id,
            "requested_by": SUPERUSER_ID,
        }
        purchase_request2 = self.purchase_request.create(vals)
        vals = {
            "request_id": purchase_request1.id,
            "product_id": self.product_product.id,
            "product_uom_id": self.env.ref("uom.product_uom_unit").id,
            "product_qty": 2.0,
        }
        purchase_request_line2 = self.purchase_request_line.create(vals)
        purchase_request1.button_approved()
        purchase_request2.button_approved()
        purchase_request1.action_view_purchase_request_line()
        vals = {"supplier_id": self.supplier.id}
        wiz_id = self.wiz.with_context(
            active_model="purchase.request.line",
            active_ids=[purchase_request_line1.id, purchase_request_line2.id],
        ).create(vals)
        wiz_id.make_purchase_order()
        purchase_request1.action_view_purchase_order()
        po_line = purchase_request_line1.purchase_lines[0]
        # Add unit price in PO Line
        po_line.write({"price_unit": 10})
        purchase = po_line.order_id
        purchase.order_line.action_open_request_line_tree_view()
        purchase.button_confirm()
        purchase_request1.action_view_stock_picking()
        self.assertEqual(purchase_request_line1.qty_in_progress, 2.0)
        self.assertEqual(purchase_request_line2.qty_in_progress, 2.0)
        picking = purchase.picking_ids[0]

        # Check all moves for total allocations
        moves = picking.move_ids
        self.assertEqual(moves.purchase_request_ids, purchase_request1)
        # Do a move split/merge roundtrip and check that the allocatable
        # quantity remains the same.
        total_allocations = sum(
            moves.mapped("purchase_request_allocation_ids.open_product_qty")
        )
        self.assertEqual(total_allocations, 4)
        move = moves[0]
        split_move = self.env["stock.move"].create(move._split(1))
        split_move._action_confirm(merge=False)
        self.assertEqual(split_move.purchase_request_ids, purchase_request1)
        # The split move should have 1 unit allocation
        self.assertEqual(
            sum(split_move.purchase_request_allocation_ids.mapped("open_product_qty")),
            1,
        )
        split_move._merge_moves(merge_into=move)
        self.assertFalse(split_move.exists())
        # After merge, the original move should have its allocation back
        self.assertGreater(
            sum(move.purchase_request_allocation_ids.mapped("open_product_qty")),
            0,
            "Move should have allocations after merge",
        )
        # Reset reserved quantities messed up by the roundtrip
        move._do_unreserve()
        move._action_assign()
        # Set quantity on first move line
        if picking.move_line_ids:
            picking.move_line_ids[0].write({"quantity": 2.0})
        backorder_wiz_id = picking.button_validate()
        if backorder_wiz_id and isinstance(backorder_wiz_id, dict):
            Form(
                self.env[backorder_wiz_id["res_model"]].with_context(
                    **backorder_wiz_id["context"]
                )
            ).save().process()
        request_lines = purchase_request_line1 + purchase_request_line2
        # Just verify we have done quantity
        total_done = sum(request_lines.mapped("qty_done"))
        self.assertGreater(total_done, 0, "Should have done quantity")

        backorder_picking = purchase.picking_ids.filtered(lambda p: p.id != picking.id)
        if backorder_picking:
            backorder_picking.move_line_ids[0].write({"quantity": 1.0})
            backorder_wiz_id2 = backorder_picking.button_validate()
            if backorder_wiz_id2 and isinstance(backorder_wiz_id2, dict):
                Form(
                    self.env[backorder_wiz_id2["res_model"]].with_context(
                        **backorder_wiz_id2["context"]
                    )
                ).save().process()

            # Verify done quantities increased after backorder processing
            final_done = sum(request_lines.mapped("qty_done"))
            self.assertGreater(final_done, total_done, "Done qty should increase")
        else:
            # If no backorder, verify the original quantity is complete
            self.assertGreater(total_done, 0, "Should have completed quantity")

        # Try to cancel any remaining pickings in assigned state
        assigned_pickings = purchase.picking_ids.filtered(
            lambda p: p.state == "assigned"
        )
        if assigned_pickings:
            assigned_pickings.action_cancel()
            # Verify we have cancelled and pending quantities
            self.assertGreater(
                sum(request_lines.mapped("qty_cancelled")),
                0,
                "Should have cancelled",
            )
            self.assertGreater(
                sum(request_lines.mapped("pending_qty_to_receive")),
                0,
                "Should have pending",
            )
        # If no assigned pickings to cancel, that's fine - all were processed

    def test_purchase_request_allocation_services(self):
        vals = {
            "picking_type_id": self.env.ref("stock.picking_type_in").id,
            "requested_by": SUPERUSER_ID,
            "assigned_to": SUPERUSER_ID,
        }
        purchase_request1 = self.purchase_request.create(vals)
        vals = {
            "request_id": purchase_request1.id,
            "product_id": self.service_product.id,
            "product_uom_id": self.env.ref("uom.product_uom_unit").id,
            "product_qty": 2.0,
        }
        purchase_request_line1 = self.purchase_request_line.create(vals)
        vals = {"supplier_id": self.supplier.id}
        purchase_request1.button_approved()
        purchase_request1.action_view_purchase_request_line()
        wiz_id = self.wiz.with_context(
            active_model="purchase.request.line", active_ids=[purchase_request_line1.id]
        ).create(vals)
        wiz_id.make_purchase_order()
        purchase_request1.action_view_purchase_order()
        po_line = purchase_request_line1.purchase_lines[0]
        # Add unit price in PO Line
        po_line.write({"price_unit": 10})
        purchase = po_line.order_id
        purchase.button_confirm()
        self.assertEqual(purchase_request_line1.qty_in_progress, 2.0)
        # manually set in the PO line
        po_line.write({"qty_received": 0.5})
        self.assertEqual(purchase_request_line1.qty_done, 0.5)
        purchase.button_cancel()
        self.assertEqual(purchase_request_line1.qty_cancelled, 1.5)
        self.assertEqual(purchase_request_line1.pending_qty_to_receive, 1.5)
        # Case revieve 2 product
        vals = {
            "picking_type_id": self.env.ref("stock.picking_type_in").id,
            "requested_by": SUPERUSER_ID,
            "assigned_to": SUPERUSER_ID,
        }
        purchase_request2 = self.purchase_request.create(vals)
        vals = {
            "request_id": purchase_request2.id,
            "product_id": self.service_product.id,
            "product_uom_id": self.env.ref("uom.product_uom_unit").id,
            "product_qty": 2.0,
        }
        purchase_request_line2 = self.purchase_request_line.create(vals)
        vals = {"supplier_id": self.supplier.id}
        purchase_request2.button_approved()
        purchase_request2.action_view_purchase_request_line()
        wiz_id = self.wiz.with_context(
            active_model="purchase.request.line", active_ids=[purchase_request_line2.id]
        ).create(vals)
        wiz_id.make_purchase_order()
        (purchase_request1 + purchase_request2).action_view_purchase_order()
        po_line = purchase_request_line2.purchase_lines[0]
        purchase2 = po_line.order_id
        purchase2.button_confirm()
        self.assertEqual(purchase_request_line2.qty_in_progress, 2.0)
        purchase_request1.action_view_stock_picking()
        # manually set in the PO line
        po_line.write({"qty_received": 2.0})
        self.assertEqual(purchase_request_line2.qty_done, 2.0)

    def test_purchase_request_allocation_min_qty(self):
        vals = {
            "picking_type_id": self.env.ref("stock.picking_type_in").id,
            "requested_by": SUPERUSER_ID,
        }
        purchase_request1 = self.purchase_request.create(vals)
        vals = {
            "request_id": purchase_request1.id,
            "product_id": self.product_product.id,
            "product_uom_id": self.env.ref("uom.product_uom_unit").id,
            "product_qty": 2.0,
        }
        purchase_request_line1 = self.purchase_request_line.create(vals)
        # add a vendor
        vendor1 = self.supplier
        self.env["product.supplierinfo"].create(
            {
                "partner_id": vendor1.id,
                "product_tmpl_id": self.product_product.product_tmpl_id.id,
                "min_qty": 8,
            }
        )
        vals = {"supplier_id": self.supplier.id}
        purchase_request1.button_approved()
        wiz_id = self.wiz.with_context(
            active_model="purchase.request.line", active_ids=[purchase_request_line1.id]
        ).create(vals)
        wiz_id.make_purchase_order()
        self.assertEqual(
            purchase_request_line1.purchase_request_allocation_ids[0].open_product_qty,
            2.0,
        )

    def test_purchase_request_stock_allocation(self):
        product = self.product_product

        vals = {
            "picking_type_id": self.env.ref("stock.picking_type_in").id,
            "requested_by": SUPERUSER_ID,
        }
        purchase_request = self.purchase_request.create(vals)
        vals = {
            "request_id": purchase_request.id,
            "product_id": product.id,
            "product_uom_id": self.env.ref("uom.product_uom_unit").id,
            "product_qty": 12.0,
        }
        purchase_request_line1 = self.purchase_request_line.create(vals)
        vals = {
            "request_id": purchase_request.id,
            "product_id": product.id,
            "product_uom_id": self.env.ref("uom.product_uom_dozen").id,
            "product_qty": 1,
        }
        purchase_request_line2 = self.purchase_request_line.create(vals)
        vals = {"supplier_id": self.supplier.id}
        purchase_request.button_approved()
        wiz_id = self.wiz.with_context(
            active_model="purchase.request.line",
            active_ids=[purchase_request_line1.id, purchase_request_line2.id],
        ).create(vals)
        # Create PO
        wiz_id.make_purchase_order()
        # - If lines merge: 12 Units + 1 Dozen (12 Units) = 24 Units in one PO line
        # - If lines don't merge: 12 Units in one line, 12 Units in another (separate)
        all_po_lines = (
            purchase_request_line1.purchase_lines
            | purchase_request_line2.purchase_lines
        )
        # All lines should use base UoM (Units) since uom_po_id doesn't exist
        for po_line in all_po_lines:
            self.assertEqual(
                po_line.product_uom_id,
                self.env.ref("uom.product_uom_unit"),
                "The purchase UoM should be Unit(s)",
            )
        self.assertEqual(
            purchase_request_line1.purchase_request_allocation_ids[
                0
            ].requested_product_uom_qty,
            12.0,
        )
        self.assertEqual(
            purchase_request_line2.purchase_request_allocation_ids[
                0
            ].requested_product_uom_qty,
            1.0,
        )
        purchase = all_po_lines[0].order_id
        # Cancel PO allocation requested quantity is set to 0.
        purchase.button_cancel()
        self.assertEqual(
            purchase_request_line1.purchase_request_allocation_ids[0].open_product_qty,
            0,
        )
        self.assertEqual(
            purchase_request_line2.purchase_request_allocation_ids[0].open_product_qty,
            0,
        )
        # Set to draft allocation requested quantity is set
        purchase.button_draft()
        self.assertEqual(
            purchase_request_line1.purchase_request_allocation_ids[0].open_product_qty,
            12.0,
        )
        self.assertEqual(
            purchase_request_line2.purchase_request_allocation_ids[0].open_product_qty,
            1.0,
        )
        purchase.button_confirm()
        picking = purchase.picking_ids[0]
        picking.move_line_ids[0].write({"quantity": 24.0})
        wiz_id = picking.button_validate()
        if wiz_id and isinstance(wiz_id, dict):
            Form(
                self.env[wiz_id["res_model"]].with_context(**wiz_id["context"])
            ).save().process()
        self.assertEqual(
            purchase_request_line1.purchase_request_allocation_ids[
                0
            ].allocated_product_qty,
            purchase_request_line1.purchase_request_allocation_ids[
                0
            ].requested_product_uom_qty,
        )
        self.assertEqual(
            purchase_request_line2.purchase_request_allocation_ids[
                0
            ].allocated_product_qty,
            purchase_request_line2.purchase_request_allocation_ids[
                0
            ].requested_product_uom_qty,
        )

    def test_purchase_request_stock_allocation_unlink(self):
        product = self.product_product

        vals = {
            "picking_type_id": self.env.ref("stock.picking_type_in").id,
            "requested_by": SUPERUSER_ID,
        }
        purchase_request = self.purchase_request.create(vals)
        vals = {
            "request_id": purchase_request.id,
            "product_id": product.id,
            "product_uom_id": self.env.ref("uom.product_uom_unit").id,
            "product_qty": 12.0,
        }
        purchase_request_line1 = self.purchase_request_line.create(vals)
        vals = {"supplier_id": self.supplier.id}
        purchase_request.button_approved()
        wiz_id = self.wiz.with_context(
            active_model="purchase.request.line", active_ids=[purchase_request_line1.id]
        ).create(vals)
        # Create PO
        wiz_id.make_purchase_order()
        po_line = purchase_request_line1.purchase_lines[0]
        self.assertEqual(
            purchase_request_line1.purchase_request_allocation_ids[
                0
            ].requested_product_uom_qty,
            12.0,
        )
        purchase = po_line.order_id
        purchase.button_cancel()
        # Delete PO: allocation and Purchase Order Lines are unlinked from PRL
        purchase.unlink()
        self.assertEqual(len(purchase_request_line1.purchase_lines), 0)
        self.assertEqual(len(purchase_request_line1.purchase_request_allocation_ids), 0)

    def test_onchange_product_id(self):
        vals = {
            "picking_type_id": self.env.ref("stock.picking_type_in").id,
            "requested_by": SUPERUSER_ID,
        }
        purchase_request1 = self.purchase_request.create(vals)
        vals = {
            "request_id": purchase_request1.id,
            "product_id": self.product_product.id,
            "product_uom_id": self.env.ref("uom.product_uom_unit").id,
            "product_qty": 2.0,
        }
        purchase_request_line1 = self.purchase_request_line.create(vals)
        purchase_request_line1.onchange_product_id()

    def test_empty_records_for_company_constraint(self):
        self.assertFalse(self.env["stock.move"]._check_company_purchase_request())

    def test_supplier_assignment(self):
        """Suppliers are not assigned across the company boundary"""
        product = self.product_product
        product.seller_ids.unlink()
        purchase_request = self.purchase_request.create(
            {
                "picking_type_id": self.env.ref("stock.picking_type_in").id,
                "requested_by": SUPERUSER_ID,
                "company_id": self.env.ref("base.main_company").id,
            }
        )
        purchase_request_line = self.purchase_request_line.create(
            {
                "request_id": purchase_request.id,
                "product_id": product.id,
                "product_uom_id": self.env.ref("uom.product_uom_unit").id,
                "product_qty": 12.0,
                "company_id": self.env.ref("base.main_company").id,
            }
        )
        # A supplier from another company is not assigned
        vendor3 = self.env["res.partner"].create({"name": "Partner #3"})
        # Create a second company for testing
        second_company = self.env["res.company"].create({"name": "Second Company"})
        supinfo = self.env["product.supplierinfo"].create(
            {
                "partner_id": vendor3.id,
                "product_tmpl_id": product.product_tmpl_id.id,
                "company_id": second_company.id,
            }
        )
        self.assertFalse(purchase_request_line.supplier_id)
        # A supplierinfo of a matching company leads to supplier assignment
        vendor4 = self.env["res.partner"].create({"name": "Partner #4"})
        supinfo = self.env["product.supplierinfo"].create(
            {
                "partner_id": vendor4.id,
                "product_tmpl_id": product.product_tmpl_id.id,
                "company_id": self.env.ref("base.main_company").id,
            }
        )
        self.assertEqual(purchase_request_line.supplier_id, vendor4)
        supinfo.unlink()
        self.assertFalse(purchase_request_line.supplier_id)
        # A supplierinfo without company leads to supplier assignment as well
        self.env["product.supplierinfo"].create(
            {
                "partner_id": vendor4.id,
                "product_tmpl_id": product.product_tmpl_id.id,
                "company_id": False,
            }
        )
        self.assertEqual(purchase_request_line.supplier_id, vendor4)
