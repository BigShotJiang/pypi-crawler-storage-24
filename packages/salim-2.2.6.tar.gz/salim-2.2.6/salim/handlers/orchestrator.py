"""
Salim Orchestrator — Manus-style multi-agent task orchestration with PDCA loop.

Manus-inspired features NOT in Salim v14:
  • Planning agent    — decomposes goals into a ranked DAG of sub-tasks
  • Execution agent   — dispatches each sub-task, picks best tool
  • Monitoring agent  — evaluates progress, detects stalls, adjusts strategy
  • Learning agent    — captures outcome patterns, updates long-term preferences
  • PDCA cycle        — Plan → Do → Check → Act (self-correcting loop)
  • Asynchronous bg   — task runs in background, Telegram shows live progress
  • Transparent log   — full step-by-step replay visible at any time
  • Shared context    — all agents share one typed context object (no hacks)

Commands:
  /do <complex goal>            — fully autonomous PDCA task (Manus-style)
  /dostatus                     — live progress of running orchestrated task
  /dostop                       — cancel the running task
  /dolog [n]                    — show last N orchestrator run summaries
  /doplan <goal>                — preview the plan WITHOUT executing (dry-run)
  /dopref <key> <value>         — set a learner preference (e.g. output_format=markdown)
  /doprefs                      — show all learner preferences
"""
from __future__ import annotations

import asyncio
import html
import json
import logging
import os
import platform
import re
import subprocess
import sys
import time
from datetime import datetime
from pathlib import Path
from typing import Any, Optional

from telegram import Update
from telegram.ext import ContextTypes

from salim.auth import require_auth
from salim.db import memory_get, memory_set

logger = logging.getLogger("salim.orchestrator")
esc = lambda v: html.escape(str(v), quote=False)
H = "HTML"

ORCH_DIR      = Path.home() / ".salim" / "orchestrator"
ORCH_LOG_FILE = ORCH_DIR / "runs.jsonl"
PREFS_KEY     = "orchestrator_prefs"

_active: dict[int, asyncio.Task]  = {}
_stops:  dict[int, asyncio.Event] = {}

MAX_STEPS   = 30
STEP_TIMEOUT = 60


# ═══════════════════════════════════════════════════════════════════════════════
#  SHARED CONTEXT
# ═══════════════════════════════════════════════════════════════════════════════

class OrchestratorContext:
    """All agents share one typed context — no globals, no hacks."""

    def __init__(self, user_id: int, goal: str, prefs: dict):
        self.user_id = user_id
        self.goal    = goal
        self.prefs   = prefs
        self.plan:   list[dict]  = []       # [{id, desc, tool, status, result}]
        self.history: list[dict] = []       # step-by-step execution log
        self.memory:  dict       = {}       # scratchpad
        self.start_ts = time.time()
        self.status   = "planning"          # planning|running|checking|acting|done|failed

    def log(self, agent: str, msg: str, data: Any = None):
        entry = {
            "ts": datetime.utcnow().isoformat(),
            "agent": agent,
            "msg": msg,
            "data": data,
        }
        self.history.append(entry)
        logger.debug("[%s] %s: %s", agent, msg, data or "")

    def elapsed(self) -> str:
        s = int(time.time() - self.start_ts)
        return f"{s//60}m{s%60}s"


# ═══════════════════════════════════════════════════════════════════════════════
#  TOOL REGISTRY  (Execution agent dispatches here)
# ═══════════════════════════════════════════════════════════════════════════════

async def _tool_shell(cmd: str, **_) -> str:
    """Run a shell command and return stdout/stderr."""
    try:
        result = subprocess.run(
            cmd, shell=True, capture_output=True, text=True, timeout=30
        )
        out = (result.stdout + result.stderr).strip()
        return out[:3000] if out else "(no output)"
    except subprocess.TimeoutExpired:
        return "ERROR: command timed out after 30s"
    except Exception as e:
        return f"ERROR: {e}"


async def _tool_web_fetch(url: str, **_) -> str:
    """Fetch a URL and return cleaned text content."""
    try:
        import httpx
        headers = {"User-Agent": "Mozilla/5.0 (compatible; SalimOrchestrator/1.0)"}
        async with httpx.AsyncClient(follow_redirects=True, timeout=15) as client:
            r = await client.get(url, headers=headers)
            r.raise_for_status()
            text = r.text
        text = re.sub(r"<script[^>]*>.*?</script>", " ", text, flags=re.DOTALL | re.I)
        text = re.sub(r"<style[^>]*>.*?</style>", " ", text, flags=re.DOTALL | re.I)
        text = re.sub(r"<[^>]+>", " ", text)
        text = re.sub(r"\s+", " ", text).strip()
        return text[:4000]
    except Exception as e:
        return f"FETCH_ERROR: {e}"


async def _tool_web_search(query: str, **_) -> str:
    """Search DuckDuckGo and return top results."""
    try:
        import httpx
        url = f"https://api.duckduckgo.com/?q={query}&format=json&no_html=1"
        async with httpx.AsyncClient(timeout=10) as c:
            r = await c.get(url, headers={"User-Agent": "SalimOrchestrator/1.0"})
            data = r.json()
        results = []
        if data.get("AbstractText"):
            results.append(f"Summary: {data['AbstractText'][:500]}")
        for item in data.get("RelatedTopics", [])[:5]:
            if isinstance(item, dict) and item.get("Text"):
                results.append(f"• {item['Text'][:200]}")
        return "\n".join(results) or "No results found."
    except Exception as e:
        return f"SEARCH_ERROR: {e}"


async def _tool_read_file(path: str, **_) -> str:
    try:
        p = Path(path).expanduser()
        if not p.exists():
            return f"FILE_NOT_FOUND: {path}"
        content = p.read_text(errors="replace")
        return content[:4000]
    except Exception as e:
        return f"READ_ERROR: {e}"


async def _tool_write_file(path: str, content: str = "", **_) -> str:
    try:
        p = Path(path).expanduser()
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_text(content)
        return f"Written {len(content)} chars to {path}"
    except Exception as e:
        return f"WRITE_ERROR: {e}"


async def _tool_python(code: str, **_) -> str:
    """Execute Python code in a subprocess sandbox."""
    try:
        with __import__("tempfile").NamedTemporaryFile(
            mode="w", suffix=".py", delete=False
        ) as f:
            f.write(code)
            fname = f.name
        result = subprocess.run(
            [sys.executable, fname],
            capture_output=True, text=True, timeout=30
        )
        os.unlink(fname)
        out = (result.stdout + result.stderr).strip()
        return out[:3000] or "(no output)"
    except subprocess.TimeoutExpired:
        return "TIMEOUT: code ran >30s"
    except Exception as e:
        return f"PYTHON_ERROR: {e}"


TOOLS = {
    "shell":      _tool_shell,
    "web_fetch":  _tool_web_fetch,
    "web_search": _tool_web_search,
    "read_file":  _tool_read_file,
    "write_file": _tool_write_file,
    "python":     _tool_python,
}


# ═══════════════════════════════════════════════════════════════════════════════
#  AI CALL HELPER
# ═══════════════════════════════════════════════════════════════════════════════

async def _ai(prompt: str, system: str = "", max_tokens: int = 1200) -> str:
    """Call the configured AI backend (NVIDIA NIM → Groq → fallback)."""
    try:
        from salim.ai import call_ai
        return await call_ai(prompt, system=system, max_tokens=max_tokens)
    except Exception:
        pass
    # Minimal fallback using httpx + NVIDIA NIM
    try:
        import httpx
        from salim.config import Config
        cfg = Config()
        api_key = cfg.get("NVIDIA_API_KEY", "")
        if not api_key:
            return "AI_UNAVAILABLE: no API key configured"
        payload = {
            "model": "meta/llama-4-maverick-17b-128e-instruct",
            "messages": [
                {"role": "system", "content": system or "You are a helpful assistant."},
                {"role": "user", "content": prompt},
            ],
            "max_tokens": max_tokens,
            "temperature": 0.3,
        }
        async with httpx.AsyncClient(timeout=60) as c:
            r = await c.post(
                "https://integrate.api.nvidia.com/v1/chat/completions",
                headers={"Authorization": f"Bearer {api_key}", "Content-Type": "application/json"},
                json=payload,
            )
            data = r.json()
            return data["choices"][0]["message"]["content"].strip()
    except Exception as e:
        return f"AI_ERROR: {e}"


# ═══════════════════════════════════════════════════════════════════════════════
#  AGENT: PLANNER
# ═══════════════════════════════════════════════════════════════════════════════

async def planning_agent(ctx: OrchestratorContext) -> list[dict]:
    """Decompose the goal into an ordered list of concrete sub-tasks."""
    ctx.status = "planning"
    ctx.log("planner", "Decomposing goal", ctx.goal)

    system = (
        "You are a task planning AI. Given a goal, output ONLY a JSON array "
        "of sub-tasks. Each element: {\"id\":int, \"desc\":str, \"tool\":str, \"args\":{}}. "
        f"Available tools: {list(TOOLS.keys())}. "
        "tool=web_search: args={{\"query\":str}}. "
        "tool=web_fetch: args={{\"url\":str}}. "
        "tool=shell: args={{\"cmd\":str}}. "
        "tool=python: args={{\"code\":str}}. "
        "tool=read_file: args={{\"path\":str}}. "
        "tool=write_file: args={{\"path\":str, \"content\":str}}. "
        "Output ONLY the JSON array, no markdown, no explanation."
    )

    prefs_note = ""
    if ctx.prefs:
        prefs_note = f"\nUser preferences: {json.dumps(ctx.prefs)}"

    prompt = f"Goal: {ctx.goal}{prefs_note}\n\nCreate a step-by-step plan as JSON:"
    raw = await _ai(prompt, system=system, max_tokens=1500)

    # Extract JSON array
    raw = raw.strip()
    m = re.search(r"\[.*\]", raw, re.DOTALL)
    if m:
        raw = m.group(0)
    try:
        plan = json.loads(raw)
        for step in plan:
            step.setdefault("status", "pending")
            step.setdefault("result", None)
        ctx.log("planner", f"Plan created: {len(plan)} steps")
        return plan
    except json.JSONDecodeError:
        # Fallback: single shell step
        ctx.log("planner", "JSON parse failed, using fallback plan")
        return [{"id": 1, "desc": ctx.goal, "tool": "shell", "args": {"cmd": "echo 'No plan generated'"}, "status": "pending", "result": None}]


# ═══════════════════════════════════════════════════════════════════════════════
#  AGENT: EXECUTOR
# ═══════════════════════════════════════════════════════════════════════════════

async def execution_agent(ctx: OrchestratorContext, step: dict) -> str:
    """Execute a single plan step using the correct tool."""
    ctx.status = "running"
    tool_name = step.get("tool", "shell")
    args      = step.get("args", {})

    ctx.log("executor", f"Running step {step['id']}: {step['desc']}", args)

    tool_fn = TOOLS.get(tool_name)
    if tool_fn is None:
        return f"UNKNOWN_TOOL: {tool_name}"

    # Inject context memory into args if relevant
    if tool_name in ("shell", "python") and ctx.memory:
        # Make last result accessible
        last = list(ctx.memory.values())[-1] if ctx.memory else ""
        args.setdefault("_prev_result", str(last)[:500])

    try:
        result = await asyncio.wait_for(tool_fn(**args), timeout=STEP_TIMEOUT)
    except asyncio.TimeoutError:
        result = f"TIMEOUT: step {step['id']} exceeded {STEP_TIMEOUT}s"
    except Exception as e:
        result = f"EXEC_ERROR: {e}"

    ctx.memory[f"step_{step['id']}"] = result
    return result


# ═══════════════════════════════════════════════════════════════════════════════
#  AGENT: MONITOR
# ═══════════════════════════════════════════════════════════════════════════════

async def monitoring_agent(ctx: OrchestratorContext, step: dict, result: str) -> dict:
    """Evaluate a step result: pass, retry, or replan."""
    ctx.status = "checking"
    ctx.log("monitor", f"Checking step {step['id']}", result[:200])

    error_signals = ["ERROR", "TIMEOUT", "FAIL", "Exception", "Traceback", "not found", "permission denied"]
    has_error = any(sig.lower() in result.lower() for sig in error_signals)

    if not has_error:
        return {"action": "pass", "reason": "Step completed successfully"}

    # Ask AI whether to retry, replan, or continue
    system = (
        "You are a monitoring AI. Evaluate if a step result indicates failure. "
        "Respond ONLY as JSON: {\"action\":\"pass\"|\"retry\"|\"replan\"|\"skip\", \"reason\":str, \"fix\":str}"
    )
    prompt = (
        f"Goal: {ctx.goal}\n"
        f"Step: {step['desc']}\n"
        f"Tool: {step['tool']}\n"
        f"Result: {result[:800]}\n"
        "Decide: should we pass, retry (with fix), replan, or skip?"
    )
    raw = await _ai(prompt, system=system, max_tokens=300)
    m = re.search(r"\{.*\}", raw, re.DOTALL)
    if m:
        try:
            decision = json.loads(m.group(0))
            ctx.log("monitor", f"Decision: {decision}")
            return decision
        except Exception:
            pass
    return {"action": "skip", "reason": "Monitor could not parse decision", "fix": ""}


# ═══════════════════════════════════════════════════════════════════════════════
#  AGENT: LEARNER
# ═══════════════════════════════════════════════════════════════════════════════

async def learning_agent(ctx: OrchestratorContext, final_output: str, user_id: int):
    """Record what worked, update user preferences."""
    ctx.status = "acting"
    ctx.log("learner", "Learning from run")

    system = (
        "You are a learning AI. Given a completed task run, extract user preferences "
        "and effective patterns. Output ONLY JSON: {\"learned\":{key:value,...}}"
    )
    step_summary = [
        {"id": s["id"], "desc": s["desc"], "tool": s["tool"], "ok": not (s.get("result", "") or "").startswith("ERROR")}
        for s in ctx.plan
    ]
    prompt = (
        f"Goal: {ctx.goal}\n"
        f"Steps: {json.dumps(step_summary)}\n"
        f"Final output length: {len(final_output)} chars\n"
        "What preferences or patterns should be remembered for next time?"
    )
    raw = await _ai(prompt, system=system, max_tokens=400)
    m = re.search(r"\{.*\}", raw, re.DOTALL)
    if m:
        try:
            data = json.loads(m.group(0))
            learned = data.get("learned", {})
            if learned:
                prefs = json.loads(memory_get(user_id, PREFS_KEY, "{}") or "{}")
                prefs.update(learned)
                memory_set(user_id, PREFS_KEY, json.dumps(prefs))
                ctx.log("learner", f"Learned {len(learned)} preferences")
        except Exception:
            pass


# ═══════════════════════════════════════════════════════════════════════════════
#  SYNTHESIZER
# ═══════════════════════════════════════════════════════════════════════════════

async def synthesize_result(ctx: OrchestratorContext) -> str:
    """Ask AI to synthesize all step results into a coherent final answer."""
    results_text = "\n\n".join(
        f"Step {s['id']} [{s['desc']}]:\n{s.get('result','')[:800]}"
        for s in ctx.plan
        if s.get("result")
    )
    if not results_text.strip():
        return "No results were collected."

    output_fmt = ctx.prefs.get("output_format", "markdown")
    system = f"You are a synthesis AI. Combine all research results into a clear, comprehensive answer in {output_fmt} format."
    prompt  = f"Original goal: {ctx.goal}\n\nCollected results:\n{results_text[:6000]}\n\nSynthesize a final answer:"
    return await _ai(prompt, system=system, max_tokens=2000)


# ═══════════════════════════════════════════════════════════════════════════════
#  PDCA ORCHESTRATOR MAIN LOOP
# ═══════════════════════════════════════════════════════════════════════════════

async def _run_pdca(
    user_id: int,
    goal: str,
    msg_obj,
    stop_event: asyncio.Event,
):
    """Full PDCA orchestration loop."""
    ORCH_DIR.mkdir(parents=True, exist_ok=True)

    prefs = json.loads(memory_get(user_id, PREFS_KEY, "{}") or "{}")
    ctx   = OrchestratorContext(user_id, goal, prefs)

    async def update(text: str):
        try:
            await msg_obj.edit_text(text, parse_mode=H)
        except Exception:
            pass

    # ── PLAN ──────────────────────────────────────────────────────────────────
    await update(f"🧠 <b>PLANNING</b>  |  Goal: {esc(goal[:100])}\n⏳ Decomposing into sub-tasks…")
    ctx.plan = await planning_agent(ctx)

    plan_preview = "\n".join(
        f"  {s['id']}. [{s['tool']}] {esc(s['desc'][:80])}" for s in ctx.plan
    )
    await update(
        f"📋 <b>Plan ready</b>  ({len(ctx.plan)} steps)\n<pre>{plan_preview}</pre>\n\n▶️ Starting execution…"
    )
    await asyncio.sleep(1)

    # ── DO / CHECK / ACT  (step loop) ─────────────────────────────────────────
    retry_counts: dict[int, int] = {}

    for step in ctx.plan:
        if stop_event.is_set():
            break
        if len(ctx.history) > MAX_STEPS:
            break

        step_num = step["id"]
        retry_counts.setdefault(step_num, 0)

        for attempt in range(3):  # max 3 attempts per step
            if stop_event.is_set():
                break

            await update(
                f"⚙️ <b>Step {step_num}/{len(ctx.plan)}</b>  [{step['tool']}]\n"
                f"{esc(step['desc'][:100])}\n"
                f"<i>Elapsed: {ctx.elapsed()}</i>"
            )

            # DO
            result = await execution_agent(ctx, step)
            step["result"] = result
            step["status"] = "done"

            # CHECK
            decision = await monitoring_agent(ctx, step, result)
            action   = decision.get("action", "pass")

            if action == "pass":
                ctx.log("pdca", f"Step {step_num} ✓")
                break

            elif action == "retry" and attempt < 2:
                fix = decision.get("fix", "")
                ctx.log("pdca", f"Step {step_num} retry #{attempt+1}: {fix}")
                if fix and step["tool"] == "shell":
                    step["args"]["cmd"] = fix
                elif fix and step["tool"] == "python":
                    step["args"]["code"] = fix
                await asyncio.sleep(1)
                continue

            elif action == "replan":
                ctx.log("pdca", f"Step {step_num} triggering replan")
                # Ask AI for a replacement step
                system = "Output ONLY a JSON object: {\"desc\":str, \"tool\":str, \"args\":{}}"
                prompt = (
                    f"Original step failed: {step['desc']}\n"
                    f"Error: {result[:500]}\n"
                    f"Fix: {decision.get('fix','')}\n"
                    "Provide a replacement step:"
                )
                raw = await _ai(prompt, system=system, max_tokens=300)
                m = re.search(r"\{.*\}", raw, re.DOTALL)
                if m:
                    try:
                        new_step = json.loads(m.group(0))
                        step.update(new_step)
                        step["status"] = "pending"
                        step["result"] = None
                        continue
                    except Exception:
                        pass
                break  # Give up replanning

            else:  # skip
                step["status"] = "skipped"
                ctx.log("pdca", f"Step {step_num} skipped: {decision.get('reason','')}")
                break

    # ── SYNTHESIZE ────────────────────────────────────────────────────────────
    await update(f"🔬 <b>Synthesizing results…</b>  <i>{ctx.elapsed()}</i>")
    final = await synthesize_result(ctx)
    ctx.status = "done"

    # ── LEARN ─────────────────────────────────────────────────────────────────
    asyncio.create_task(learning_agent(ctx, final, user_id))

    # ── SAVE RUN LOG ──────────────────────────────────────────────────────────
    run_log = {
        "ts": datetime.utcnow().isoformat(),
        "goal": goal,
        "steps": len(ctx.plan),
        "elapsed": ctx.elapsed(),
        "status": ctx.status,
        "history_len": len(ctx.history),
    }
    with open(ORCH_LOG_FILE, "a") as f:
        f.write(json.dumps(run_log) + "\n")

    # ── FINAL REPLY ───────────────────────────────────────────────────────────
    header = (
        f"✅ <b>Task Complete</b>  ({ctx.elapsed()} · {len(ctx.plan)} steps)\n"
        f"<b>Goal:</b> {esc(goal[:100])}\n\n"
    )
    chunks = [final[i:i+3500] for i in range(0, len(final), 3500)]
    await update(header + esc(chunks[0]) if chunks else header + "(empty result)")
    for chunk in chunks[1:]:
        await msg_obj.reply_text(esc(chunk), parse_mode=H)


# ═══════════════════════════════════════════════════════════════════════════════
#  TELEGRAM COMMAND HANDLERS
# ═══════════════════════════════════════════════════════════════════════════════

class OrchestratorHandlers:

    @require_auth
    async def cmd_do(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """/do <complex goal> — autonomous PDCA task"""
        goal = " ".join(context.args or []).strip()
        if not goal:
            await update.message.reply_text(
                "Usage: /do <goal>\nExample: /do research the best Python web frameworks and write a comparison report",
                parse_mode=H,
            )
            return

        uid = update.effective_user.id
        if uid in _active and not _active[uid].done():
            await update.message.reply_text("⚠️ A task is already running. Use /dostop to cancel.", parse_mode=H)
            return

        msg = await update.message.reply_text(
            f"🚀 <b>Orchestrator started</b>\nGoal: {esc(goal[:150])}\n⏳ Planning…",
            parse_mode=H,
        )

        stop = asyncio.Event()
        _stops[uid] = stop

        async def _run():
            try:
                await _run_pdca(uid, goal, msg, stop)
            except asyncio.CancelledError:
                await msg.edit_text("🛑 Task cancelled.", parse_mode=H)
            except Exception as e:
                logger.exception("Orchestrator error")
                await msg.edit_text(f"❌ Orchestrator error: {esc(str(e))}", parse_mode=H)
            finally:
                _active.pop(uid, None)
                _stops.pop(uid, None)

        task = asyncio.create_task(_run())
        _active[uid] = task

    @require_auth
    async def cmd_dostatus(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """/dostatus — check running task"""
        uid = update.effective_user.id
        if uid not in _active or _active[uid].done():
            await update.message.reply_text("ℹ️ No active orchestrator task.", parse_mode=H)
            return
        await update.message.reply_text("⚙️ Orchestrator task is running…", parse_mode=H)

    @require_auth
    async def cmd_dostop(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """/dostop — cancel running task"""
        uid = update.effective_user.id
        if uid in _stops:
            _stops[uid].set()
        if uid in _active:
            _active[uid].cancel()
        await update.message.reply_text("🛑 Stop signal sent.", parse_mode=H)

    @require_auth
    async def cmd_dolog(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """/dolog [n] — show last N run summaries"""
        n = int(context.args[0]) if context.args else 5
        if not ORCH_LOG_FILE.exists():
            await update.message.reply_text("No orchestrator runs yet.", parse_mode=H)
            return
        lines = ORCH_LOG_FILE.read_text().strip().split("\n")
        recent = lines[-n:]
        rows = []
        for line in reversed(recent):
            try:
                r = json.loads(line)
                rows.append(
                    f"• <b>{r.get('goal','')[:60]}</b>\n"
                    f"  {r.get('ts','')[:16]} | {r.get('elapsed','')} | {r.get('steps','')} steps | {r.get('status','')}"
                )
            except Exception:
                pass
        text = f"<b>Last {len(rows)} orchestrator runs:</b>\n\n" + "\n\n".join(rows)
        await update.message.reply_text(text, parse_mode=H)

    @require_auth
    async def cmd_doplan(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """/doplan <goal> — preview plan without executing"""
        goal = " ".join(context.args or []).strip()
        if not goal:
            await update.message.reply_text("Usage: /doplan <goal>", parse_mode=H)
            return

        uid   = update.effective_user.id
        msg   = await update.message.reply_text("🧠 Planning (dry-run)…", parse_mode=H)
        prefs = json.loads(memory_get(uid, PREFS_KEY, "{}") or "{}")
        ctx   = OrchestratorContext(uid, goal, prefs)
        plan  = await planning_agent(ctx)

        rows = "\n".join(
            f"  {s['id']}. [{s['tool']}] {esc(s['desc'])}" for s in plan
        )
        await msg.edit_text(
            f"📋 <b>Dry-run Plan</b> ({len(plan)} steps)\n<pre>{rows}</pre>\n\n"
            "Use /do to execute this plan.",
            parse_mode=H,
        )

    @require_auth
    async def cmd_dopref(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """/dopref <key> <value> — set a learner preference"""
        if len(context.args or []) < 2:
            await update.message.reply_text("Usage: /dopref <key> <value>", parse_mode=H)
            return
        uid   = update.effective_user.id
        key   = context.args[0]
        value = " ".join(context.args[1:])
        prefs = json.loads(memory_get(uid, PREFS_KEY, "{}") or "{}")
        prefs[key] = value
        memory_set(uid, PREFS_KEY, json.dumps(prefs))
        await update.message.reply_text(
            f"✅ Preference set: <code>{esc(key)}</code> = <code>{esc(value)}</code>", parse_mode=H
        )

    @require_auth
    async def cmd_doprefs(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """/doprefs — show all learner preferences"""
        uid   = update.effective_user.id
        prefs = json.loads(memory_get(uid, PREFS_KEY, "{}") or "{}")
        if not prefs:
            await update.message.reply_text("No preferences set yet.", parse_mode=H)
            return
        rows = "\n".join(f"  <code>{esc(k)}</code>: {esc(str(v))}" for k, v in prefs.items())
        await update.message.reply_text(f"<b>Your preferences:</b>\n{rows}", parse_mode=H)
