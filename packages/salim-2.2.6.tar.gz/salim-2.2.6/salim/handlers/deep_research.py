"""
Salim Deep Research — Manus-style autonomous web research with full reports.

Features:
  • Deep Research: AI plans queries → fetches web pages → synthesizes report
  • Wide Research: parallel research on N items (companies, products, topics)
  • Self-correcting: validates sources, retries failed fetches, cross-checks facts
  • Output formats: Markdown report, CSV, JSON, downloadable Word/PDF
  • Replay log: every research session saved and viewable

Commands:
  /research <topic>           — deep research with full cited report
  /wresearch <items...>       — wide research on multiple items in parallel
  /research status            — show active research jobs
  /research cancel            — cancel running research
  /research last              — get last research report
  /scrape <url> [fields...]   — structured web scraping → CSV/JSON
  /scrapesite <url> <pages>   — multi-page scrape with auto-pagination
"""
from __future__ import annotations

import asyncio
import csv
import html
import io
import json
import logging
import re
import time
import urllib.parse
from datetime import datetime
from pathlib import Path
from typing import Optional

from telegram import InlineKeyboardButton, InlineKeyboardMarkup, Update
from telegram.ext import ContextTypes

from salim.auth import require_auth
from salim.utils import truncate

logger = logging.getLogger("salim.research")
esc = lambda v: html.escape(str(v), quote=False)
H = "HTML"

# ── Per-user research state ──────────────────────────────────────────────────
_active_research: dict[int, asyncio.Task] = {}
_research_stop:   dict[int, asyncio.Event] = {}
_last_report:     dict[int, dict] = {}   # user_id → {title, content, sources, ts}

RESEARCH_SAVE_DIR = Path.home() / ".salim" / "research"


# ═══════════════════════════════════════════════════════════════════════════════
#  WEB FETCH HELPERS
# ═══════════════════════════════════════════════════════════════════════════════

async def _fetch_url(url: str, timeout: int = 10) -> tuple[str, str]:
    """Fetch a URL, return (title, text_content). Never raises."""
    try:
        import httpx
        headers = {
            "User-Agent": "Mozilla/5.0 (compatible; SalimResearch/1.0)",
            "Accept": "text/html,application/xhtml+xml,text/plain",
        }
        async with httpx.AsyncClient(follow_redirects=True, timeout=timeout) as client:
            r = await client.get(url, headers=headers)
            r.raise_for_status()
            raw = r.text

        # Extract title
        title_m = re.search(r"<title[^>]*>(.*?)</title>", raw, re.IGNORECASE | re.DOTALL)
        title = title_m.group(1).strip() if title_m else url

        # Strip HTML tags → plain text
        text = re.sub(r"<script[^>]*>.*?</script>", " ", raw, flags=re.DOTALL | re.IGNORECASE)
        text = re.sub(r"<style[^>]*>.*?</style>", " ", text, flags=re.DOTALL | re.IGNORECASE)
        text = re.sub(r"<[^>]+>", " ", text)
        text = re.sub(r"\s+", " ", text).strip()
        # Keep up to 3000 chars per page for context
        return title[:200], text[:3000]

    except Exception as e:
        return url, f"[Fetch error: {e}]"


async def _search_duckduckgo(query: str, max_results: int = 5) -> list[dict]:
    """Scrape DuckDuckGo HTML search results. Returns list of {title, url, snippet}."""
    results = []
    try:
        import httpx
        encoded = urllib.parse.quote_plus(query)
        url = f"https://html.duckduckgo.com/html/?q={encoded}"
        headers = {"User-Agent": "Mozilla/5.0 (compatible; SalimResearch/1.0)"}
        async with httpx.AsyncClient(follow_redirects=True, timeout=12) as client:
            r = await client.get(url, headers=headers)
            raw = r.text

        # Parse results
        # DDG HTML: <a class="result__a" href="...">title</a>
        links = re.findall(r'<a[^>]+class="result__a"[^>]+href="([^"]+)"[^>]*>(.*?)</a>', raw, re.DOTALL)
        snippets_raw = re.findall(r'<a[^>]+class="result__snippet"[^>]*>(.*?)</a>', raw, re.DOTALL)

        snippets = []
        for s in snippets_raw:
            s = re.sub(r"<[^>]+>", "", s).strip()
            snippets.append(s[:300])

        for i, (href, title_raw) in enumerate(links[:max_results]):
            # DuckDuckGo uses redirect URLs — extract the real URL
            real_url = href
            qs = urllib.parse.parse_qs(urllib.parse.urlparse(href).query)
            if "uddg" in qs:
                real_url = urllib.parse.unquote(qs["uddg"][0])
            title_clean = re.sub(r"<[^>]+>", "", title_raw).strip()
            snippet = snippets[i] if i < len(snippets) else ""
            results.append({"title": title_clean, "url": real_url, "snippet": snippet})

    except Exception as e:
        logger.warning(f"DuckDuckGo search failed: {e}")

    return results


# ═══════════════════════════════════════════════════════════════════════════════
#  AI SYNTHESIS HELPER
# ═══════════════════════════════════════════════════════════════════════════════

async def _ai_call(config, system: str, user: str, max_tokens: int = 2000) -> str:
    """Call the Salim AI with given prompts."""
    try:
        from salim.ai import SalimAI
        ai = SalimAI(config)
        result = await ai.chat(
            messages=[{"role": "user", "content": user}],
            system=system,
            max_tokens=max_tokens,
        )
        return result
    except Exception as e:
        return f"[AI error: {e}]"


# ═══════════════════════════════════════════════════════════════════════════════
#  DEEP RESEARCH ENGINE
# ═══════════════════════════════════════════════════════════════════════════════

async def _deep_research_task(
    user_id: int,
    topic: str,
    config,
    progress_cb,
    stop_event: asyncio.Event,
) -> dict:
    """
    Full deep research pipeline:
    1. AI generates 5 search queries for the topic
    2. Execute all searches in parallel
    3. Fetch top pages from each query in parallel
    4. AI synthesizes a comprehensive cited report
    """
    ts = datetime.now().strftime("%Y-%m-%d %H:%M")
    sources = []
    all_content = []

    # Step 1: Generate search queries
    await progress_cb("🧠 Planning research queries...")
    queries_raw = await _ai_call(
        config,
        "You are a research planning AI. Output ONLY a JSON array of 5 distinct search queries (strings). No explanation.",
        f"Generate 5 diverse search queries to thoroughly research: {topic}\n\nOutput JSON array only, e.g.: [\"query1\", \"query2\", ...]"
    )
    try:
        # Extract JSON array from response
        arr_match = re.search(r'\[.*?\]', queries_raw, re.DOTALL)
        queries = json.loads(arr_match.group()) if arr_match else [topic]
    except Exception:
        queries = [topic, f"{topic} overview", f"{topic} analysis", f"{topic} latest", f"{topic} examples"]

    queries = queries[:5]
    await progress_cb(f"🔍 Searching {len(queries)} query angles in parallel...")

    if stop_event.is_set():
        return {"error": "Cancelled"}

    # Step 2: Search all queries in parallel
    search_tasks = [_search_duckduckgo(q, max_results=4) for q in queries]
    all_search_results = await asyncio.gather(*search_tasks, return_exceptions=True)

    # Collect unique URLs
    seen_urls: set[str] = set()
    urls_to_fetch = []
    for results in all_search_results:
        if isinstance(results, list):
            for r in results:
                url = r.get("url", "")
                if url and url not in seen_urls and url.startswith("http"):
                    seen_urls.add(url)
                    urls_to_fetch.append(r)

    urls_to_fetch = urls_to_fetch[:12]  # Cap at 12 pages
    await progress_cb(f"📄 Fetching {len(urls_to_fetch)} web pages in parallel...")

    if stop_event.is_set():
        return {"error": "Cancelled"}

    # Step 3: Fetch all pages in parallel
    fetch_tasks = [_fetch_url(r["url"]) for r in urls_to_fetch]
    fetched = await asyncio.gather(*fetch_tasks, return_exceptions=True)

    for i, (page_title, page_text) in enumerate(fetched):
        if isinstance(page_text, Exception):
            continue
        if "[Fetch error" in page_text:
            continue
        url = urls_to_fetch[i]["url"]
        snippet = urls_to_fetch[i].get("snippet", "")
        sources.append({
            "n": len(sources) + 1,
            "title": page_title or urls_to_fetch[i].get("title", url),
            "url": url,
            "snippet": snippet,
        })
        all_content.append(
            f"=== Source [{len(sources)}]: {page_title} ===\nURL: {url}\n{page_text}\n"
        )

    await progress_cb(f"✍️ Synthesizing report from {len(sources)} sources...")

    if stop_event.is_set():
        return {"error": "Cancelled"}

    # Step 4: AI synthesis
    context = "\n\n".join(all_content)[:12000]  # Token-safe truncation
    sources_list = "\n".join([f"[{s['n']}] {s['title']} — {s['url']}" for s in sources])

    report_text = await _ai_call(
        config,
        """You are a professional research analyst. Write a comprehensive, well-structured research report.
Use inline citations like [1], [2] referencing the source numbers.
Structure:
## Executive Summary
## Key Findings  
## Detailed Analysis
## Conclusion
## Sources
Write in clear, professional prose. Be thorough and accurate. Minimum 500 words.""",
        f"""Research Topic: {topic}

Source Material (from {len(sources)} web pages):
{context}

Available Sources:
{sources_list}

Write a comprehensive research report with citations.""",
        max_tokens=3000,
    )

    # Save report
    RESEARCH_SAVE_DIR.mkdir(parents=True, exist_ok=True)
    safe_name = re.sub(r"[^\w\-]", "_", topic[:40])
    report_path = RESEARCH_SAVE_DIR / f"research_{safe_name}_{int(time.time())}.md"
    full_report = f"# Research Report: {topic}\n*Generated: {ts}*\n\n{report_text}"
    report_path.write_text(full_report, encoding="utf-8")

    return {
        "title": topic,
        "report": report_text,
        "sources": sources,
        "path": str(report_path),
        "ts": ts,
        "n_sources": len(sources),
    }


# ═══════════════════════════════════════════════════════════════════════════════
#  WIDE RESEARCH ENGINE  (parallel N-item research)
# ═══════════════════════════════════════════════════════════════════════════════

async def _research_single_item(item: str, config) -> dict:
    """Research a single item — used in parallel by wide research."""
    results = await _search_duckduckgo(f"{item} overview facts", max_results=3)
    if not results:
        return {"item": item, "summary": "No data found.", "url": ""}

    # Fetch top result
    top = results[0]
    _, page_text = await _fetch_url(top["url"])

    # AI summarize this single item
    from salim.ai import SalimAI
    try:
        ai = SalimAI(config)
        summary = await ai.chat(
            messages=[{"role": "user", "content": f"Summarize key facts about '{item}' in 3-5 bullet points based on:\n{page_text[:2000]}"}],
            system="You are a concise research analyst. Output 3-5 bullet points only. Be factual.",
            max_tokens=300,
        )
    except Exception as e:
        summary = top.get("snippet", f"Error: {e}")

    return {
        "item": item,
        "summary": summary,
        "url": top["url"],
        "source_title": top["title"],
    }


async def _wide_research_task(
    user_id: int,
    items: list[str],
    config,
    progress_cb,
    stop_event: asyncio.Event,
) -> dict:
    """Run parallel research on all items simultaneously."""
    await progress_cb(f"🚀 Launching {len(items)} parallel research agents...")

    # Run all in parallel (cap at 10 concurrent)
    sem = asyncio.Semaphore(10)

    async def bounded(item):
        async with sem:
            return await _research_single_item(item, config)

    tasks = [bounded(item) for item in items]
    results = await asyncio.gather(*tasks, return_exceptions=True)

    processed = []
    for r in results:
        if isinstance(r, Exception):
            processed.append({"item": "error", "summary": str(r), "url": ""})
        else:
            processed.append(r)

    await progress_cb(f"📊 All {len(processed)} items researched. Building report...")

    # Build CSV
    csv_buf = io.StringIO()
    writer = csv.DictWriter(csv_buf, fieldnames=["item", "summary", "source_title", "url"])
    writer.writeheader()
    for row in processed:
        writer.writerow({
            "item": row.get("item", ""),
            "summary": re.sub(r"\s+", " ", row.get("summary", "")),
            "source_title": row.get("source_title", ""),
            "url": row.get("url", ""),
        })

    # Build markdown summary
    md_lines = [f"# Wide Research: {len(items)} Items\n*Generated: {datetime.now().strftime('%Y-%m-%d %H:%M')}*\n"]
    for row in processed:
        md_lines.append(f"## {row.get('item', '')}\n{row.get('summary', '')}\n*Source: [{row.get('source_title', '')}]({row.get('url', '')})*\n")

    # Save files
    RESEARCH_SAVE_DIR.mkdir(parents=True, exist_ok=True)
    ts_str = int(time.time())
    csv_path = RESEARCH_SAVE_DIR / f"wide_research_{ts_str}.csv"
    md_path  = RESEARCH_SAVE_DIR / f"wide_research_{ts_str}.md"
    csv_path.write_text(csv_buf.getvalue(), encoding="utf-8")
    md_path.write_text("\n".join(md_lines), encoding="utf-8")

    return {
        "items": items,
        "results": processed,
        "csv_path": str(csv_path),
        "md_path": str(md_path),
        "n": len(processed),
    }


# ═══════════════════════════════════════════════════════════════════════════════
#  WEB SCRAPER
# ═══════════════════════════════════════════════════════════════════════════════

async def _scrape_url_structured(url: str, fields: list[str]) -> list[dict]:
    """
    Fetch a page and extract structured data using regex/pattern heuristics.
    For each field, tries to find text near the field name.
    """
    _, page_text = await _fetch_url(url, timeout=15)
    if "[Fetch error" in page_text:
        return [{"error": page_text, "url": url}]

    # Try to extract tabular/structured data
    # Strategy: look for repeating patterns (tables, lists, divs with similar content)
    rows = []

    # Simple heuristic: split by newlines and find dense info blocks
    lines = [l.strip() for l in page_text.split("  ") if len(l.strip()) > 5]

    if fields:
        # Try to find values near field keywords
        record = {"url": url}
        for field in fields:
            pattern = re.compile(rf"{re.escape(field)}[:\s]+([^\n\|]+)", re.IGNORECASE)
            m = pattern.search(page_text)
            record[field] = m.group(1).strip()[:200] if m else ""
        rows.append(record)
    else:
        # Extract all visible text as structured rows (name/value pairs)
        for line in lines[:50]:
            if ":" in line:
                parts = line.split(":", 1)
                rows.append({"key": parts[0].strip()[:80], "value": parts[1].strip()[:200]})

    return rows if rows else [{"url": url, "content": page_text[:500]}]


# ═══════════════════════════════════════════════════════════════════════════════
#  HANDLER MIXIN
# ═══════════════════════════════════════════════════════════════════════════════

class DeepResearchHandlers:
    """
    Mixin providing /research, /wresearch, and /scrape commands.
    """

    # ── /research <topic> ────────────────────────────────────────────────────
    @require_auth
    async def cmd_research(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        user_id = update.effective_user.id
        args = ctx.args or []

        if not args:
            await update.effective_message.reply_text(
                "📚 <b>Deep Research</b>\n\n"
                "Usage: <code>/research &lt;topic&gt;</code>\n"
                "Example: <code>/research quantum computing applications 2025</code>\n\n"
                "Salim will:\n"
                "• Plan 5 search angles\n"
                "• Search + fetch 10-15 web sources in parallel\n"
                "• Write a comprehensive cited report\n"
                "• Save as Markdown file for download",
                parse_mode=H,
            )
            return

        topic = " ".join(args)

        # Cancel existing
        if user_id in _active_research and not _active_research[user_id].done():
            await update.effective_message.reply_text("⚠️ Cancelling previous research...")
            _research_stop.get(user_id, asyncio.Event()).set()
            await asyncio.sleep(0.5)

        msg = await update.effective_message.reply_text(
            f"🔬 <b>Starting Deep Research</b>\nTopic: <b>{esc(topic)}</b>\n\n⏳ Initializing...",
            parse_mode=H,
        )
        stop_ev = asyncio.Event()
        _research_stop[user_id] = stop_ev

        async def progress(status: str):
            try:
                await msg.edit_text(
                    f"🔬 <b>Research:</b> {esc(topic)}\n\n{esc(status)}",
                    parse_mode=H,
                )
            except Exception:
                pass

        async def run():
            try:
                result = await _deep_research_task(user_id, topic, self.config, progress, stop_ev)
                if "error" in result:
                    await msg.edit_text(f"❌ Research cancelled.", parse_mode=H)
                    return

                _last_report[user_id] = result

                # Send report summary
                sources_text = "\n".join([
                    f"  [{s['n']}] <a href='{esc(s['url'])}'>{esc(s['title'][:60])}</a>"
                    for s in result["sources"][:8]
                ])
                preview = result["report"][:1500]

                await msg.edit_text(
                    f"✅ <b>Research Complete</b>\n"
                    f"📌 Topic: <b>{esc(result['title'])}</b>\n"
                    f"📄 Sources: {result['n_sources']}\n"
                    f"🕐 {result['ts']}\n\n"
                    f"{esc(preview)}{'...' if len(result['report']) > 1500 else ''}\n\n"
                    f"<b>Sources Used:</b>\n{sources_text}",
                    parse_mode=H,
                    disable_web_page_preview=True,
                )

                # Send report as file
                report_bytes = io.BytesIO(
                    f"# Research Report: {result['title']}\n\n{result['report']}".encode()
                )
                report_bytes.name = f"research_{re.sub(r'[^\\w]', '_', topic[:30])}.md"
                await update.effective_message.reply_document(
                    document=report_bytes,
                    caption=f"📄 Full research report: {topic}",
                )

            except Exception as e:
                logger.exception(f"Deep research error: {e}")
                await msg.edit_text(f"❌ Research error: {esc(str(e))}", parse_mode=H)

        task = asyncio.create_task(run())
        _active_research[user_id] = task

    # ── /wresearch <item1>, <item2>, ... ────────────────────────────────────
    @require_auth
    async def cmd_wresearch(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        user_id = update.effective_user.id
        args = ctx.args or []

        if not args:
            await update.effective_message.reply_text(
                "🔀 <b>Wide Research</b> — research many items in parallel\n\n"
                "Usage: <code>/wresearch item1, item2, item3, ...</code>\n"
                "Example: <code>/wresearch Apple, Google, Microsoft, Amazon, Meta</code>\n\n"
                "Each item researched simultaneously — results in CSV + report.",
                parse_mode=H,
            )
            return

        # Parse items: support comma or newline separation
        raw = " ".join(args)
        items = [i.strip() for i in re.split(r"[,\n]+", raw) if i.strip()]
        items = items[:20]  # Cap at 20

        if len(items) < 2:
            await update.effective_message.reply_text(
                "❌ Please provide at least 2 items separated by commas.\n"
                "Example: <code>/wresearch Tesla, Rivian, Lucid</code>",
                parse_mode=H,
            )
            return

        msg = await update.effective_message.reply_text(
            f"🚀 <b>Wide Research</b>\n{len(items)} items: {esc(', '.join(items[:5]))}"
            f"{'...' if len(items) > 5 else ''}\n\n⏳ Launching parallel agents...",
            parse_mode=H,
        )
        stop_ev = asyncio.Event()
        _research_stop[user_id] = stop_ev

        async def progress(status: str):
            try:
                await msg.edit_text(
                    f"🔀 <b>Wide Research</b> ({len(items)} items)\n\n{esc(status)}",
                    parse_mode=H,
                )
            except Exception:
                pass

        async def run():
            try:
                result = await _wide_research_task(user_id, items, self.config, progress, stop_ev)

                await msg.edit_text(
                    f"✅ <b>Wide Research Complete</b>\n"
                    f"📊 {result['n']} items researched in parallel\n"
                    f"📄 CSV + Markdown report attached below",
                    parse_mode=H,
                )

                # Send CSV
                csv_path = Path(result["csv_path"])
                if csv_path.exists():
                    await update.effective_message.reply_document(
                        document=open(csv_path, "rb"),
                        caption=f"📊 Wide Research Results ({result['n']} items)",
                        filename=csv_path.name,
                    )

                # Send MD report
                md_path = Path(result["md_path"])
                if md_path.exists():
                    await update.effective_message.reply_document(
                        document=open(md_path, "rb"),
                        caption=f"📄 Wide Research Report",
                        filename=md_path.name,
                    )

            except Exception as e:
                logger.exception(f"Wide research error: {e}")
                await msg.edit_text(f"❌ Wide research error: {esc(str(e))}", parse_mode=H)

        task = asyncio.create_task(run())
        _active_research[user_id] = task

    # ── /research cancel / status / last ─────────────────────────────────────
    @require_auth
    async def cmd_research_ctrl(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        user_id = update.effective_user.id
        sub = ctx.args[0].lower() if ctx.args else "status"

        if sub == "cancel":
            ev = _research_stop.get(user_id)
            if ev:
                ev.set()
            await update.effective_message.reply_text("🛑 Research cancellation requested.")

        elif sub == "status":
            task = _active_research.get(user_id)
            if task and not task.done():
                await update.effective_message.reply_text("🔬 Research is running...")
            else:
                await update.effective_message.reply_text("✅ No active research.")

        elif sub == "last":
            report = _last_report.get(user_id)
            if not report:
                await update.effective_message.reply_text("📭 No recent research found.")
                return
            report_bytes = io.BytesIO(
                f"# {report['title']}\n\n{report['report']}".encode()
            )
            report_bytes.name = "last_research.md"
            await update.effective_message.reply_document(
                document=report_bytes,
                caption=f"📄 Last research: {report['title']} ({report['ts']})",
            )

    # ── /scrape <url> [field1] [field2] ... ──────────────────────────────────
    @require_auth
    async def cmd_scrape(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        args = ctx.args or []
        if not args:
            await update.effective_message.reply_text(
                "🕷️ <b>Web Scraper</b>\n\n"
                "Usage: <code>/scrape &lt;url&gt; [field1] [field2] ...</code>\n\n"
                "Examples:\n"
                "<code>/scrape https://example.com/products name price description</code>\n"
                "<code>/scrape https://example.com</code> — auto-extract key-value pairs\n\n"
                "Output: structured CSV file",
                parse_mode=H,
            )
            return

        url = args[0]
        if not url.startswith("http"):
            url = "https://" + url
        fields = args[1:] if len(args) > 1 else []

        msg = await update.effective_message.reply_text(
            f"🕷️ Scraping <code>{esc(url)}</code>...", parse_mode=H
        )
        try:
            rows = await _scrape_url_structured(url, fields)

            # Build CSV
            if not rows:
                await msg.edit_text("❌ No data extracted from that URL.", parse_mode=H)
                return

            all_keys = set()
            for r in rows:
                all_keys.update(r.keys())
            keys = sorted(all_keys)

            csv_buf = io.StringIO()
            writer = csv.DictWriter(csv_buf, fieldnames=keys)
            writer.writeheader()
            for r in rows:
                writer.writerow({k: r.get(k, "") for k in keys})

            await msg.edit_text(
                f"✅ Scraped <code>{esc(url)}</code>\n"
                f"📊 {len(rows)} records, {len(keys)} fields\n"
                f"Fields: {esc(', '.join(keys[:8]))}",
                parse_mode=H,
            )

            csv_bytes = io.BytesIO(csv_buf.getvalue().encode())
            domain = urllib.parse.urlparse(url).netloc.replace(".", "_")
            csv_bytes.name = f"scrape_{domain}_{int(time.time())}.csv"
            await update.effective_message.reply_document(
                document=csv_bytes,
                caption=f"🕷️ Scraped data from {url}",
            )

        except Exception as e:
            await msg.edit_text(f"❌ Scrape error: {esc(str(e))}", parse_mode=H)

    # ── /scrapesite <url> <pages> ─────────────────────────────────────────────
    @require_auth
    async def cmd_scrapesite(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        args = ctx.args or []
        if len(args) < 2:
            await update.effective_message.reply_text(
                "🕸️ Usage: <code>/scrapesite &lt;url&gt; &lt;pages&gt;</code>\n"
                "Example: <code>/scrapesite https://news.ycombinator.com 3</code>",
                parse_mode=H,
            )
            return

        url = args[0]
        if not url.startswith("http"):
            url = "https://" + url
        try:
            n_pages = min(int(args[1]), 10)
        except ValueError:
            n_pages = 3

        msg = await update.effective_message.reply_text(
            f"🕸️ Scraping {n_pages} pages from <code>{esc(url)}</code>...", parse_mode=H
        )

        try:
            import httpx as _httpx
            all_rows = []
            seen_urls = {url}
            to_fetch = [url]

            async with _httpx.AsyncClient(follow_redirects=True, timeout=10) as client:
                for page_n in range(n_pages):
                    if not to_fetch:
                        break
                    current_url = to_fetch.pop(0)
                    headers = {"User-Agent": "Mozilla/5.0 (compatible; SalimScraper/1.0)"}
                    try:
                        r = await client.get(current_url, headers=headers)
                        raw = r.text
                    except Exception:
                        continue

                    # Extract links for pagination
                    links = re.findall(r'href="(/[^"?#]+|https?://[^"?#]+)"', raw)
                    base = urllib.parse.urlparse(url)
                    for lnk in links:
                        if not lnk.startswith("http"):
                            lnk = f"{base.scheme}://{base.netloc}{lnk}"
                        if lnk not in seen_urls and base.netloc in lnk:
                            seen_urls.add(lnk)
                            to_fetch.append(lnk)

                    # Extract text data
                    text = re.sub(r"<[^>]+>", " ", raw)
                    text = re.sub(r"\s+", " ", text).strip()
                    all_rows.append({"page": page_n + 1, "url": current_url, "content": text[:500]})

                    await msg.edit_text(
                        f"🕸️ Scraped page {page_n + 1}/{n_pages}: <code>{esc(current_url[:60])}</code>",
                        parse_mode=H,
                    )

            csv_buf = io.StringIO()
            writer = csv.DictWriter(csv_buf, fieldnames=["page", "url", "content"])
            writer.writeheader()
            writer.writerows(all_rows)

            await msg.edit_text(
                f"✅ Site scrape complete\n📊 {len(all_rows)} pages scraped",
                parse_mode=H,
            )
            csv_bytes = io.BytesIO(csv_buf.getvalue().encode())
            domain = urllib.parse.urlparse(url).netloc.replace(".", "_")
            csv_bytes.name = f"site_{domain}_{int(time.time())}.csv"
            await update.effective_message.reply_document(
                document=csv_bytes,
                caption=f"🕸️ Site scrape: {url} ({len(all_rows)} pages)",
            )

        except Exception as e:
            await msg.edit_text(f"❌ Site scrape error: {esc(str(e))}", parse_mode=H)
