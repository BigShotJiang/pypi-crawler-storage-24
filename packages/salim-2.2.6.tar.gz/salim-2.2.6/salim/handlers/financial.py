"""
Salim Financial Analysis — Manus-style real-world financial intelligence.

Features:
  • Live stock prices via Yahoo Finance (no API key needed)
  • Technical analysis: RSI, MACD, moving averages
  • AI-powered buy/sell/hold sentiment from news + price action
  • Portfolio tracker: track multiple symbols
  • Market overview: indices, crypto prices
  • Earnings calendar lookup
  • AI financial report generation

Commands:
  /stock <SYMBOL>              — full analysis with chart data + AI insight
  /stocks <SYM1> <SYM2> ...   — compare multiple stocks
  /portfolio add/remove/show   — manage your watchlist
  /market                      — market overview (indices + crypto)
  /finreport <topic>           — AI financial report on any topic
"""
from __future__ import annotations

import asyncio
import html
import io
import json
import logging
import re
import time
from datetime import datetime
from pathlib import Path
from typing import Optional

from telegram import Update
from telegram.ext import ContextTypes

from salim.auth import require_auth

logger = logging.getLogger("salim.finance")
esc = lambda v: html.escape(str(v), quote=False)
H = "HTML"

PORTFOLIO_DIR = Path.home() / ".salim" / "portfolio"


# ═══════════════════════════════════════════════════════════════════════════════
#  YAHOO FINANCE DATA FETCHER (no API key required)
# ═══════════════════════════════════════════════════════════════════════════════

async def _yf_quote(symbol: str) -> dict:
    """Fetch real-time quote from Yahoo Finance."""
    try:
        import httpx
    except ImportError:
        return {"symbol": symbol, "error": "httpx not installed. Run: pip install httpx", "price": 0}
    url = f"https://query1.finance.yahoo.com/v8/finance/chart/{symbol.upper()}?interval=1d&range=3mo"
    headers = {
        "User-Agent": "Mozilla/5.0",
        "Accept": "application/json",
    }
    try:
        async with httpx.AsyncClient(timeout=15, follow_redirects=True) as client:
            r = await client.get(url, headers=headers)
            data = r.json()

        result = data.get("chart", {}).get("result", [{}])[0]
        meta = result.get("meta", {})
        timestamps = result.get("timestamp", [])
        quotes = result.get("indicators", {}).get("quote", [{}])[0]

        closes = quotes.get("close", [])
        opens  = quotes.get("open", [])
        highs  = quotes.get("high", [])
        lows   = quotes.get("low", [])
        volumes = quotes.get("volume", [])

        # Filter None values
        closes = [c for c in closes if c is not None]

        current_price = meta.get("regularMarketPrice", 0)
        prev_close = meta.get("chartPreviousClose", meta.get("previousClose", 0))
        change = current_price - prev_close if prev_close else 0
        change_pct = (change / prev_close * 100) if prev_close else 0

        # Simple technical indicators
        sma_20 = sum(closes[-20:]) / min(20, len(closes)) if closes else 0
        sma_50 = sum(closes[-50:]) / min(50, len(closes)) if closes else 0

        # RSI (14-period simplified)
        rsi = _calc_rsi(closes[-15:]) if len(closes) >= 15 else None

        return {
            "symbol": symbol.upper(),
            "name": meta.get("longName", meta.get("shortName", symbol)),
            "price": current_price,
            "prev_close": prev_close,
            "change": change,
            "change_pct": change_pct,
            "market_cap": meta.get("marketCap"),
            "volume": meta.get("regularMarketVolume", 0),
            "52w_high": meta.get("fiftyTwoWeekHigh", 0),
            "52w_low": meta.get("fiftyTwoWeekLow", 0),
            "sma_20": sma_20,
            "sma_50": sma_50,
            "rsi": rsi,
            "currency": meta.get("currency", "USD"),
            "exchange": meta.get("exchangeName", ""),
            "closes_90d": closes[-90:],
            "timestamps": timestamps[-90:] if timestamps else [],
            "error": None,
        }
    except Exception as e:
        return {"symbol": symbol, "error": str(e), "price": 0}


def _calc_rsi(closes: list, period: int = 14) -> Optional[float]:
    """Calculate RSI from close prices."""
    if len(closes) < period + 1:
        return None
    gains, losses = [], []
    for i in range(1, len(closes)):
        delta = closes[i] - closes[i - 1]
        if delta > 0:
            gains.append(delta)
            losses.append(0)
        else:
            gains.append(0)
            losses.append(abs(delta))
    if not gains:
        return 50.0
    avg_gain = sum(gains[-period:]) / period
    avg_loss = sum(losses[-period:]) / period
    if avg_loss == 0:
        return 100.0
    rs = avg_gain / avg_loss
    return round(100 - (100 / (1 + rs)), 1)


def _fmt_number(n) -> str:
    if n is None:
        return "N/A"
    n = float(n)
    if abs(n) >= 1e12:
        return f"${n / 1e12:.2f}T"
    if abs(n) >= 1e9:
        return f"${n / 1e9:.2f}B"
    if abs(n) >= 1e6:
        return f"${n / 1e6:.2f}M"
    return f"${n:,.2f}"


def _trend_emoji(change_pct: float) -> str:
    if change_pct > 3:   return "🚀"
    if change_pct > 1:   return "📈"
    if change_pct > 0:   return "⬆️"
    if change_pct > -1:  return "⬇️"
    if change_pct > -3:  return "📉"
    return "💥"


def _rsi_signal(rsi: Optional[float]) -> str:
    if rsi is None:
        return "N/A"
    if rsi < 30:
        return f"{rsi} 🟢 Oversold (potential BUY)"
    if rsi > 70:
        return f"{rsi} 🔴 Overbought (potential SELL)"
    return f"{rsi} 🟡 Neutral"


async def _fetch_news_sentiment(symbol: str) -> str:
    """Fetch recent news headlines for a symbol."""
    try:
        import httpx
        url = f"https://query2.finance.yahoo.com/v1/finance/search?q={symbol}&newsCount=5"
        headers = {"User-Agent": "Mozilla/5.0"}
        async with httpx.AsyncClient(timeout=10) as client:
            r = await client.get(url, headers=headers)
            data = r.json()
        news = data.get("news", [])[:5]
        headlines = [n.get("title", "") for n in news if n.get("title")]
        return "\n".join(f"• {h}" for h in headlines[:5]) if headlines else "No recent news."
    except Exception:
        return "News unavailable."


async def _get_market_index(symbol: str) -> dict:
    """Get index data for market overview."""
    return await _yf_quote(symbol)


# ═══════════════════════════════════════════════════════════════════════════════
#  PORTFOLIO MANAGER
# ═══════════════════════════════════════════════════════════════════════════════

def _load_portfolio(user_id: int) -> list:
    PORTFOLIO_DIR.mkdir(parents=True, exist_ok=True)
    path = PORTFOLIO_DIR / f"{user_id}.json"
    if not path.exists():
        return []
    try:
        return json.loads(path.read_text())
    except Exception:
        return []


def _save_portfolio(user_id: int, symbols: list):
    PORTFOLIO_DIR.mkdir(parents=True, exist_ok=True)
    path = PORTFOLIO_DIR / f"{user_id}.json"
    path.write_text(json.dumps(symbols))


# ═══════════════════════════════════════════════════════════════════════════════
#  HANDLER MIXIN
# ═══════════════════════════════════════════════════════════════════════════════

class FinancialHandlers:

    # ── /stock <SYMBOL> ─────────────────────────────────────────────────────
    @require_auth
    async def cmd_stock(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        args = ctx.args or []
        if not args:
            await update.effective_message.reply_text(
                "📈 <b>Stock Analysis</b>\n\n"
                "Usage: <code>/stock &lt;SYMBOL&gt;</code>\n"
                "Examples: <code>/stock AAPL</code> · <code>/stock TSLA</code> · <code>/stock BTC-USD</code>\n\n"
                "Get: live price, 52-week range, RSI, SMA, AI sentiment + news",
                parse_mode=H,
            )
            return

        symbol = args[0].upper()
        msg = await update.effective_message.reply_text(
            f"📊 Fetching data for <code>{esc(symbol)}</code>...", parse_mode=H
        )

        try:
            # Fetch quote and news in parallel
            quote_task = _yf_quote(symbol)
            news_task  = _fetch_news_sentiment(symbol)
            quote, news = await asyncio.gather(quote_task, news_task)

            if quote.get("error"):
                await msg.edit_text(
                    f"❌ Could not fetch <code>{esc(symbol)}</code>: {esc(quote['error'])}",
                    parse_mode=H,
                )
                return

            price     = quote["price"]
            change    = quote["change"]
            chg_pct   = quote["change_pct"]
            currency  = quote["currency"]
            emoji     = _trend_emoji(chg_pct)
            sign      = "+" if change >= 0 else ""

            # AI analysis
            ai_prompt = f"""Analyze this stock briefly (3-4 sentences):
Symbol: {symbol} — {quote['name']}
Price: {price:.2f} {currency} ({sign}{chg_pct:.2f}% today)
52w High: {quote['52w_high']:.2f}, Low: {quote['52w_low']:.2f}
RSI: {quote['rsi']}, SMA20: {quote['sma_20']:.2f}, SMA50: {quote['sma_50']:.2f}
Recent news: {news[:500]}
Give: sentiment (bullish/bearish/neutral), key risk, opportunity. End with BUY/HOLD/SELL signal."""

            try:
                from salim.ai import SalimAI
                ai = SalimAI(self.config)
                ai_insight = await ai.chat(
                    messages=[{"role": "user", "content": ai_prompt}],
                    system="You are a financial analyst. Be concise, factual, and clear. Always note you are not financial advice.",
                    max_tokens=300,
                )
            except Exception:
                ai_insight = "AI analysis unavailable."

            text = (
                f"{emoji} <b>{esc(quote['name'])} ({esc(symbol)})</b>\n"
                f"💰 <b>{price:.2f} {currency}</b>  {sign}{change:.2f} ({sign}{chg_pct:.2f}%)\n"
                f"📊 Exchange: {esc(quote['exchange'])}\n\n"

                f"📉 <b>52-Week Range</b>\n"
                f"  Low: {quote['52w_low']:.2f} → High: {quote['52w_high']:.2f}\n\n"

                f"📐 <b>Technical Indicators</b>\n"
                f"  RSI (14): {_rsi_signal(quote['rsi'])}\n"
                f"  SMA 20: {quote['sma_20']:.2f}  |  SMA 50: {quote['sma_50']:.2f}\n"
                f"  Volume: {quote['volume']:,}\n"
                f"  Market Cap: {_fmt_number(quote['market_cap'])}\n\n"

                f"📰 <b>Recent News</b>\n{esc(news[:400])}\n\n"

                f"🤖 <b>AI Analysis</b>\n{esc(ai_insight)}"
            )

            await msg.edit_text(text, parse_mode=H, disable_web_page_preview=True)

        except Exception as e:
            logger.exception(f"Stock cmd error: {e}")
            await msg.edit_text(f"❌ Error: {esc(str(e))}", parse_mode=H)

    # ── /stocks <SYM1> <SYM2> ... ───────────────────────────────────────────
    @require_auth
    async def cmd_stocks(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        args = ctx.args or []
        if not args:
            await update.effective_message.reply_text(
                "📊 Usage: <code>/stocks SYM1 SYM2 SYM3</code>\n"
                "Example: <code>/stocks AAPL MSFT GOOGL AMZN TSLA</code>",
                parse_mode=H,
            )
            return

        symbols = [a.upper() for a in args[:8]]
        msg = await update.effective_message.reply_text(
            f"📊 Comparing {len(symbols)} stocks...", parse_mode=H
        )

        try:
            tasks = [_yf_quote(s) for s in symbols]
            quotes = await asyncio.gather(*tasks)

            lines = [f"📊 <b>Stock Comparison</b> — {datetime.now().strftime('%H:%M')}\n"]
            for q in quotes:
                if q.get("error"):
                    lines.append(f"❌ <code>{esc(q['symbol'])}</code>: {esc(q['error'])}")
                    continue
                sign = "+" if q['change'] >= 0 else ""
                emoji = _trend_emoji(q['change_pct'])
                lines.append(
                    f"{emoji} <code>{esc(q['symbol'])}</code> {q['price']:.2f} "
                    f"({sign}{q['change_pct']:.2f}%)  RSI:{q['rsi'] or 'N/A'}"
                )

            await msg.edit_text("\n".join(lines), parse_mode=H)

        except Exception as e:
            await msg.edit_text(f"❌ {esc(str(e))}", parse_mode=H)

    # ── /portfolio add/remove/show ───────────────────────────────────────────
    @require_auth
    async def cmd_portfolio(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        user_id = update.effective_user.id
        args = ctx.args or []
        sub = args[0].lower() if args else "show"

        portfolio = _load_portfolio(user_id)

        if sub == "add" and len(args) > 1:
            sym = args[1].upper()
            if sym not in portfolio:
                portfolio.append(sym)
                _save_portfolio(user_id, portfolio)
            await update.effective_message.reply_text(
                f"✅ Added <code>{esc(sym)}</code> to portfolio. Total: {len(portfolio)} symbols.",
                parse_mode=H,
            )

        elif sub in ("remove", "del") and len(args) > 1:
            sym = args[1].upper()
            portfolio = [s for s in portfolio if s != sym]
            _save_portfolio(user_id, portfolio)
            await update.effective_message.reply_text(f"✅ Removed <code>{esc(sym)}</code>.", parse_mode=H)

        elif sub in ("show", "list", "check"):
            if not portfolio:
                await update.effective_message.reply_text(
                    "📂 Portfolio is empty.\nAdd stocks: <code>/portfolio add AAPL</code>",
                    parse_mode=H,
                )
                return

            msg = await update.effective_message.reply_text(
                f"📂 Loading {len(portfolio)} portfolio positions...", parse_mode=H
            )
            tasks = [_yf_quote(s) for s in portfolio]
            quotes = await asyncio.gather(*tasks)

            lines = [f"💼 <b>Portfolio</b> ({len(portfolio)} symbols)\n"]
            total_change_pct = []
            for q in quotes:
                if q.get("error"):
                    lines.append(f"❌ <code>{esc(q['symbol'])}</code>: N/A")
                    continue
                sign = "+" if q['change'] >= 0 else ""
                emoji = _trend_emoji(q['change_pct'])
                total_change_pct.append(q['change_pct'])
                lines.append(
                    f"{emoji} <b>{esc(q['symbol'])}</b>: {q['price']:.2f} "
                    f"<code>{sign}{q['change_pct']:.2f}%</code>  "
                    f"RSI: {q['rsi'] or 'N/A'}"
                )

            if total_change_pct:
                avg_chg = sum(total_change_pct) / len(total_change_pct)
                sign = "+" if avg_chg >= 0 else ""
                lines.append(f"\n📊 Portfolio avg today: <b>{sign}{avg_chg:.2f}%</b>")

            lines.append("\n<i>Use /stock SYMBOL for full analysis</i>")
            await msg.edit_text("\n".join(lines), parse_mode=H)

        elif sub == "clear":
            _save_portfolio(user_id, [])
            await update.effective_message.reply_text("✅ Portfolio cleared.")

        else:
            await update.effective_message.reply_text(
                "💼 <b>Portfolio Commands</b>\n"
                "<code>/portfolio add AAPL</code> — add symbol\n"
                "<code>/portfolio remove TSLA</code> — remove symbol\n"
                "<code>/portfolio show</code> — view all positions\n"
                "<code>/portfolio clear</code> — clear all",
                parse_mode=H,
            )

    # ── /market ──────────────────────────────────────────────────────────────
    @require_auth
    async def cmd_market(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        msg = await update.effective_message.reply_text("🌍 Fetching market data...", parse_mode=H)
        try:
            # Indices + crypto + popular stocks in parallel
            indices  = ["^GSPC", "^DJI", "^IXIC", "^RUT"]  # S&P500, DJI, Nasdaq, Russell
            crypto   = ["BTC-USD", "ETH-USD"]
            popular  = ["AAPL", "TSLA", "NVDA", "MSFT"]
            all_syms = indices + crypto + popular

            tasks  = [_yf_quote(s) for s in all_syms]
            quotes = await asyncio.gather(*tasks)
            quote_map = {q["symbol"]: q for q in quotes}

            lines = [f"🌍 <b>Market Overview</b> — {datetime.now().strftime('%H:%M UTC')}\n"]

            lines.append("📈 <b>Indices</b>")
            idx_labels = {"^GSPC": "S&P 500", "^DJI": "Dow Jones", "^IXIC": "Nasdaq", "^RUT": "Russell 2000"}
            for sym, label in idx_labels.items():
                q = quote_map.get(sym.replace("^", "") if "^" not in sym else sym, {})
                if not q or q.get("error"):
                    continue
                sign = "+" if q['change'] >= 0 else ""
                lines.append(f"  {_trend_emoji(q['change_pct'])} {label}: {q['price']:,.2f} ({sign}{q['change_pct']:.2f}%)")

            lines.append("\n₿ <b>Crypto</b>")
            for sym in crypto:
                q = quote_map.get(sym, {})
                if not q or q.get("error"):
                    continue
                sign = "+" if q['change'] >= 0 else ""
                label = sym.replace("-USD", "")
                lines.append(f"  {_trend_emoji(q['change_pct'])} {label}: ${q['price']:,.2f} ({sign}{q['change_pct']:.2f}%)")

            lines.append("\n🏢 <b>Popular Stocks</b>")
            for sym in popular:
                q = quote_map.get(sym, {})
                if not q or q.get("error"):
                    continue
                sign = "+" if q['change'] >= 0 else ""
                lines.append(f"  {_trend_emoji(q['change_pct'])} {esc(q['symbol'])}: ${q['price']:.2f} ({sign}{q['change_pct']:.2f}%)")

            lines.append(f"\n<i>Use /stock SYMBOL for detailed analysis</i>")
            await msg.edit_text("\n".join(lines), parse_mode=H)

        except Exception as e:
            await msg.edit_text(f"❌ Market data error: {esc(str(e))}", parse_mode=H)

    # ── /finreport <topic> ───────────────────────────────────────────────────
    @require_auth
    async def cmd_finreport(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        args = ctx.args or []
        if not args:
            await update.effective_message.reply_text(
                "📋 <b>Financial Report Generator</b>\n\n"
                "Usage: <code>/finreport &lt;topic&gt;</code>\n"
                "Examples:\n"
                "<code>/finreport Tesla Q4 2024 earnings outlook</code>\n"
                "<code>/finreport semiconductor sector trends 2025</code>\n"
                "<code>/finreport impact of interest rates on tech stocks</code>",
                parse_mode=H,
            )
            return

        topic = " ".join(args)
        msg = await update.effective_message.reply_text(
            f"📋 Generating financial report on: <b>{esc(topic)}</b>...", parse_mode=H
        )

        try:
            # If topic looks like a stock symbol, fetch data
            ticker_match = re.match(r"^([A-Z]{1,5})$", topic.strip())
            stock_context = ""
            if ticker_match:
                q = await _yf_quote(ticker_match.group(1))
                if not q.get("error"):
                    news = await _fetch_news_sentiment(ticker_match.group(1))
                    stock_context = f"\nLive data: {json.dumps({k: v for k, v in q.items() if k != 'closes_90d'}, default=str)}\nNews: {news}"

            from salim.ai import SalimAI
            ai = SalimAI(self.config)
            report = await ai.chat(
                messages=[{"role": "user", "content":
                    f"Write a professional financial analysis report on: {topic}\n{stock_context}\n\n"
                    "Structure: Executive Summary, Market Context, Key Data Points, Risks, Opportunities, Conclusion.\n"
                    "Be factual and analytical. Note this is for informational purposes only."}],
                system="You are a senior financial analyst writing institutional-quality research reports. "
                       "Use proper financial terminology. Always include a disclaimer.",
                max_tokens=1500,
            )

            await msg.edit_text(
                f"📋 <b>Financial Report: {esc(topic)}</b>\n\n{esc(report[:3500])}",
                parse_mode=H,
            )

            # Send as file if long
            if len(report) > 2000:
                report_bytes = io.BytesIO(
                    f"# Financial Report: {topic}\n\n{report}".encode()
                )
                safe_name = re.sub(r"[^\w]", "_", topic[:30])
                report_bytes.name = f"finreport_{safe_name}.md"
                await update.effective_message.reply_document(
                    document=report_bytes,
                    caption=f"📋 Financial Report: {topic}",
                )

        except Exception as e:
            await msg.edit_text(f"❌ Report error: {esc(str(e))}", parse_mode=H)
