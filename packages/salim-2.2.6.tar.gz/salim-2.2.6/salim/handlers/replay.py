"""
Salim Replay — Manus-style transparent task session replay and sharing.

Manus has a "Manus's Computer" window where users can see EVERY step the agent
took, replay entire sessions, and share session logs with others.
Salim v14 has no session replay or shareable logs.

Commands:
  /replay [session_id]     — view last session (or specific session)
  /replaylist              — list all saved sessions
  /replayshare [session_id]— get a shareable JSON dump of a session
  /replaysave <note>       — tag the current/last session with a note
"""
from __future__ import annotations

import html
import json
import logging
import time
from datetime import datetime
from pathlib import Path
from typing import Optional

from telegram import Update
from telegram.ext import ContextTypes

from salim.auth import require_auth

logger = logging.getLogger("salim.replay")
esc = lambda v: html.escape(str(v), quote=False)
H = "HTML"

REPLAY_DIR = Path.home() / ".salim" / "sessions"


# ═══════════════════════════════════════════════════════════════════════════════
#  SESSION STORE  (used by agent2, orchestrator, deep_research to write logs)
# ═══════════════════════════════════════════════════════════════════════════════

def save_session(
    user_id: int,
    session_type: str,
    goal: str,
    steps: list[dict],
    final_output: str = "",
    tags: list[str] | None = None,
) -> str:
    """Save a session and return its session_id."""
    REPLAY_DIR.mkdir(parents=True, exist_ok=True)
    session_id = f"{user_id}_{int(time.time())}"
    path = REPLAY_DIR / f"{session_id}.json"
    data = {
        "session_id":   session_id,
        "user_id":      user_id,
        "type":         session_type,
        "goal":         goal,
        "ts":           datetime.utcnow().isoformat(),
        "steps":        steps,
        "final_output": final_output,
        "tags":         tags or [],
    }
    path.write_text(json.dumps(data, indent=2))
    return session_id


def load_session(session_id: str) -> Optional[dict]:
    """Load a session by ID."""
    path = REPLAY_DIR / f"{session_id}.json"
    if not path.exists():
        return None
    try:
        return json.loads(path.read_text())
    except Exception:
        return None


def list_sessions(user_id: int, limit: int = 20) -> list[dict]:
    """Return the most recent sessions for a user."""
    REPLAY_DIR.mkdir(parents=True, exist_ok=True)
    files = sorted(REPLAY_DIR.glob(f"{user_id}_*.json"), reverse=True)[:limit]
    sessions = []
    for f in files:
        try:
            data = json.loads(f.read_text())
            sessions.append({
                "session_id": data.get("session_id"),
                "type":       data.get("type"),
                "goal":       data.get("goal", "")[:80],
                "ts":         data.get("ts", "")[:16],
                "steps":      len(data.get("steps", [])),
                "tags":       data.get("tags", []),
            })
        except Exception:
            pass
    return sessions


# ═══════════════════════════════════════════════════════════════════════════════
#  TELEGRAM HANDLERS
# ═══════════════════════════════════════════════════════════════════════════════

class ReplayHandlers:

    @require_auth
    async def cmd_replay(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """/replay [session_id] — view a session step by step"""
        uid = update.effective_user.id
        if context.args:
            session_id = context.args[0]
        else:
            sessions = list_sessions(uid, 1)
            if not sessions:
                await update.message.reply_text("No sessions saved yet.", parse_mode=H)
                return
            session_id = sessions[0]["session_id"]

        data = load_session(session_id)
        if not data:
            await update.message.reply_text(f"Session <code>{esc(session_id)}</code> not found.", parse_mode=H)
            return

        steps = data.get("steps", [])
        goal  = data.get("goal", "")
        ts    = data.get("ts", "")[:16]

        lines = [
            f"<b>🎬 Session Replay</b>",
            f"<b>ID:</b> <code>{esc(session_id)}</code>",
            f"<b>Type:</b> {esc(data.get('type',''))}",
            f"<b>Goal:</b> {esc(goal[:120])}",
            f"<b>Date:</b> {ts}",
            f"<b>Steps:</b> {len(steps)}",
            "",
        ]

        for i, step in enumerate(steps[:25], 1):
            agent  = esc(step.get("agent", step.get("tool", "?")))
            msg    = esc(step.get("msg", step.get("desc", ""))[:100])
            result = esc(str(step.get("result", step.get("data", "")))[:150])
            lines.append(f"<b>{i}.</b> [{agent}] {msg}")
            if result and result != "None":
                lines.append(f"   ↳ <i>{result}</i>")

        if len(steps) > 25:
            lines.append(f"\n<i>… and {len(steps)-25} more steps. Use /replayshare to get full log.</i>")

        final = data.get("final_output", "")
        if final:
            lines.append(f"\n<b>Final output:</b>\n{esc(final[:600])}")

        await update.message.reply_text("\n".join(lines), parse_mode=H)

    @require_auth
    async def cmd_replaylist(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """/replaylist — list saved sessions"""
        uid      = update.effective_user.id
        sessions = list_sessions(uid)
        if not sessions:
            await update.message.reply_text("No sessions saved yet.", parse_mode=H)
            return

        rows = []
        for s in sessions:
            tags = f" [{', '.join(s['tags'])}]" if s["tags"] else ""
            rows.append(
                f"<code>{esc(s['session_id'])}</code>  [{esc(s['type'])}] {s['steps']} steps\n"
                f"  {s['ts']} — {esc(s['goal'])}{esc(tags)}"
            )

        text = f"<b>Your sessions ({len(sessions)}):</b>\n\n" + "\n\n".join(rows)
        await update.message.reply_text(text[:4000], parse_mode=H)

    @require_auth
    async def cmd_replayshare(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """/replayshare [session_id] — download full session as JSON"""
        uid = update.effective_user.id
        if context.args:
            session_id = context.args[0]
        else:
            sessions = list_sessions(uid, 1)
            if not sessions:
                await update.message.reply_text("No sessions saved.", parse_mode=H)
                return
            session_id = sessions[0]["session_id"]

        path = REPLAY_DIR / f"{session_id}.json"
        if not path.exists():
            await update.message.reply_text("Session not found.", parse_mode=H)
            return

        await update.message.reply_document(
            document=path.open("rb"),
            filename=f"session_{session_id}.json",
            caption=f"📦 Session log: <code>{esc(session_id)}</code>",
            parse_mode=H,
        )

    @require_auth
    async def cmd_replaysave(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """/replaysave <note> — tag the last session"""
        uid  = update.effective_user.id
        note = " ".join(context.args or []).strip()
        if not note:
            await update.message.reply_text("Usage: /replaysave <note>", parse_mode=H)
            return

        sessions = list_sessions(uid, 1)
        if not sessions:
            await update.message.reply_text("No sessions to tag.", parse_mode=H)
            return

        session_id = sessions[0]["session_id"]
        path       = REPLAY_DIR / f"{session_id}.json"
        data       = json.loads(path.read_text())
        data.setdefault("tags", []).append(note)
        path.write_text(json.dumps(data, indent=2))
        await update.message.reply_text(
            f"✅ Tagged session <code>{esc(session_id)}</code> with: <i>{esc(note)}</i>",
            parse_mode=H,
        )
