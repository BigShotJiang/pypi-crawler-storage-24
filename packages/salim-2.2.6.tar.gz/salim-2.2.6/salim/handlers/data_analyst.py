"""
Salim Data Analyst — Manus-style multi-modal data analysis.

Manus can analyze CSV/JSON/Excel data, produce charts, statistics,
and AI-generated insights. Salim v14 has no structured data analysis.

Commands:
  /analyze <file_path>              — full AI analysis of a CSV/JSON/Excel file
  /chart <file_path> <chart_type>   — generate chart from data (bar/line/pie/scatter/heatmap)
  /pivot <file_path> <row> <col>    — pivot table
  /correlate <file_path>            — correlation matrix
  /anomaly <file_path>              — AI-powered anomaly detection
  /dataquery <file_path> <question> — natural language query on data
"""
from __future__ import annotations

import asyncio
import csv
import html
import io
import json
import logging
import os
import subprocess
import sys
import tempfile
from pathlib import Path
from typing import Optional

from telegram import Update
from telegram.ext import ContextTypes

from salim.auth import require_auth

logger = logging.getLogger("salim.analyst")
esc = lambda v: html.escape(str(v), quote=False)
H = "HTML"

ANALYST_DIR = Path.home() / ".salim" / "analyst"


def _ensure(*pkgs):
    for pkg in pkgs:
        try:
            __import__(pkg.split("[")[0].replace("-", "_"))
        except ImportError:
            subprocess.run([sys.executable, "-m", "pip", "install", pkg, "-q"], check=False)


# ═══════════════════════════════════════════════════════════════════════════════
#  DATA LOADING
# ═══════════════════════════════════════════════════════════════════════════════

def _load_data(path_str: str):
    """Load data from CSV, JSON, JSONL, TSV, or Excel. Returns (headers, rows, df_or_None)."""
    path = Path(path_str).expanduser()
    if not path.exists():
        raise FileNotFoundError(f"File not found: {path_str}")

    suffix = path.suffix.lower()

    if suffix in (".xlsx", ".xls", ".ods"):
        _ensure("openpyxl")
        import openpyxl
        wb = openpyxl.load_workbook(path, read_only=True, data_only=True)
        ws = wb.active
        rows = [[str(c.value or "") for c in row] for row in ws.iter_rows()]
        wb.close()
        headers = rows[0] if rows else []
        data_rows = rows[1:]
    elif suffix == ".json":
        raw = json.loads(path.read_text())
        if isinstance(raw, list) and raw:
            headers = list(raw[0].keys()) if isinstance(raw[0], dict) else [str(i) for i in range(len(raw[0]))]
            data_rows = [[str(row.get(h, "")) for h in headers] for row in raw if isinstance(row, dict)]
        else:
            headers = ["key", "value"]
            data_rows = [[str(k), str(v)] for k, v in (raw.items() if isinstance(raw, dict) else [])]
    elif suffix == ".jsonl":
        lines = [json.loads(l) for l in path.read_text().splitlines() if l.strip()]
        headers = list(lines[0].keys()) if lines else []
        data_rows = [[str(row.get(h, "")) for h in headers] for row in lines]
    else:  # CSV / TSV / TXT
        delimiter = "\t" if suffix == ".tsv" else ","
        with path.open(newline="", encoding="utf-8", errors="replace") as f:
            reader = csv.reader(f, delimiter=delimiter)
            all_rows = list(reader)
        headers   = all_rows[0]  if all_rows else []
        data_rows = all_rows[1:] if len(all_rows) > 1 else []

    return headers, data_rows


def _basic_stats(headers: list, rows: list) -> dict:
    """Compute basic statistics for numeric columns."""
    stats = {}
    for i, col in enumerate(headers):
        vals = []
        for row in rows:
            if i < len(row):
                try:
                    vals.append(float(row[i]))
                except (ValueError, TypeError):
                    pass
        if vals:
            vals.sort()
            n   = len(vals)
            avg = sum(vals) / n
            stats[col] = {
                "count": n,
                "min":   round(vals[0], 4),
                "max":   round(vals[-1], 4),
                "mean":  round(avg, 4),
                "median": round(vals[n//2], 4),
                "stddev": round((sum((x - avg)**2 for x in vals) / n) ** 0.5, 4),
            }
    return stats


async def _ai_insight(prompt: str, system: str = "") -> str:
    try:
        from salim.ai import call_ai
        return await call_ai(prompt, system=system, max_tokens=1200)
    except Exception as e:
        return f"AI unavailable: {e}"


# ═══════════════════════════════════════════════════════════════════════════════
#  CHART GENERATOR
# ═══════════════════════════════════════════════════════════════════════════════

def _make_chart(headers: list, rows: list, chart_type: str, title: str = "") -> Optional[str]:
    """Generate a chart PNG and return its path."""
    _ensure("matplotlib")
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    ANALYST_DIR.mkdir(parents=True, exist_ok=True)
    outpath = str(ANALYST_DIR / f"chart_{int(__import__('time').time())}.png")

    # Try to find numeric + label columns
    numeric_cols = []
    label_col    = 0
    for i, h in enumerate(headers):
        try:
            float(rows[0][i] if rows else "x")
            numeric_cols.append(i)
        except (ValueError, IndexError):
            label_col = i

    if not numeric_cols:
        return None

    labels = [r[label_col] if label_col < len(r) else str(j) for j, r in enumerate(rows[:50])]
    values = []
    for ci in numeric_cols[:3]:
        col_vals = []
        for r in rows[:50]:
            try:
                col_vals.append(float(r[ci]))
            except (ValueError, IndexError):
                col_vals.append(0.0)
        values.append((headers[ci], col_vals))

    fig, ax = plt.subplots(figsize=(10, 6))
    ax.set_title(title or "Data Chart", fontsize=14, fontweight="bold")

    ct = chart_type.lower()
    if ct == "pie" and values:
        _, vals = values[0]
        ax.pie(vals[:10], labels=labels[:10], autopct="%1.1f%%")
    elif ct == "scatter" and len(values) >= 2:
        ax.scatter(values[0][1], values[1][1], alpha=0.7)
        ax.set_xlabel(values[0][0])
        ax.set_ylabel(values[1][0])
    elif ct == "line":
        for col_name, vals in values:
            ax.plot(range(len(vals)), vals, marker="o", markersize=3, label=col_name)
        ax.legend()
        ax.set_xticks(range(min(len(labels), 20)))
        ax.set_xticklabels(labels[:20], rotation=45, ha="right", fontsize=8)
    elif ct == "heatmap" and len(values) >= 2:
        import numpy as np
        matrix = [[v for _, vals in values for v in [vals[j] if j < len(vals) else 0]] for j in range(len(rows[:20]))]
        im = ax.imshow(matrix, cmap="YlOrRd", aspect="auto")
        ax.set_yticks(range(min(20, len(labels))))
        ax.set_yticklabels(labels[:20], fontsize=8)
        ax.set_xticks(range(len(values)))
        ax.set_xticklabels([v[0] for v in values], rotation=45, ha="right", fontsize=8)
        plt.colorbar(im, ax=ax)
    else:  # bar (default)
        x = range(len(labels))
        width = 0.8 / max(len(values), 1)
        for k, (col_name, vals) in enumerate(values):
            offsets = [xi + k * width for xi in x]
            ax.bar(offsets, vals, width=width, label=col_name, alpha=0.8)
        ax.set_xticks([xi + width * (len(values) - 1) / 2 for xi in x])
        ax.set_xticklabels(labels, rotation=45, ha="right", fontsize=8)
        if len(values) > 1:
            ax.legend()

    ax.grid(True, alpha=0.3)
    plt.tight_layout()
    plt.savefig(outpath, dpi=120, bbox_inches="tight")
    plt.close()
    return outpath


# ═══════════════════════════════════════════════════════════════════════════════
#  HANDLERS
# ═══════════════════════════════════════════════════════════════════════════════

class DataAnalystHandlers:

    @require_auth
    async def cmd_analyze(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """/analyze <file> — full AI analysis"""
        if not context.args:
            await update.message.reply_text("Usage: /analyze <file_path>", parse_mode=H)
            return

        path_str = context.args[0]
        msg = await update.message.reply_text("🔍 Loading data…", parse_mode=H)

        try:
            headers, rows = _load_data(path_str)
        except Exception as e:
            await msg.edit_text(f"❌ Error loading file: {esc(str(e))}", parse_mode=H)
            return

        if not headers or not rows:
            await msg.edit_text("❌ File is empty or has no data.", parse_mode=H)
            return

        await msg.edit_text("📊 Computing statistics…", parse_mode=H)
        stats = _basic_stats(headers, rows)

        # Build AI prompt
        sample = rows[:10]
        sample_text = "\n".join(",".join(r) for r in sample)
        stats_text  = json.dumps(stats, indent=2)[:2000]

        system = "You are a senior data analyst. Analyze the dataset and provide: 1) Key findings, 2) Patterns and trends, 3) Anomalies or outliers, 4) Business/actionable insights, 5) Recommended next analyses."
        prompt = (
            f"Dataset: {Path(path_str).name}\n"
            f"Shape: {len(rows)} rows × {len(headers)} columns\n"
            f"Columns: {', '.join(headers)}\n\n"
            f"Statistics:\n{stats_text}\n\n"
            f"Sample (first 10 rows):\n{sample_text}\n\n"
            "Provide a comprehensive data analysis:"
        )

        await msg.edit_text("🤖 AI analyzing…", parse_mode=H)
        insight = await _ai_insight(prompt, system)

        # Try to generate a chart
        chart_path = None
        try:
            chart_path = _make_chart(headers, rows, "bar", title=f"Analysis: {Path(path_str).name}")
        except Exception:
            pass

        text = (
            f"<b>📊 Data Analysis: {esc(Path(path_str).name)}</b>\n"
            f"<b>Shape:</b> {len(rows)} rows × {len(headers)} cols\n"
            f"<b>Columns:</b> {esc(', '.join(headers[:10]))}\n\n"
            f"{esc(insight[:2500])}"
        )
        await msg.edit_text(text[:4000], parse_mode=H)

        if chart_path and Path(chart_path).exists():
            await update.message.reply_photo(
                photo=open(chart_path, "rb"),
                caption="📈 Auto-generated chart",
            )

    @require_auth
    async def cmd_chart(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """/chart <file> <bar|line|pie|scatter|heatmap>"""
        args = context.args or []
        if not args:
            await update.message.reply_text(
                "Usage: /chart <file_path> [bar|line|pie|scatter|heatmap]", parse_mode=H
            )
            return

        path_str   = args[0]
        chart_type = args[1] if len(args) > 1 else "bar"
        msg = await update.message.reply_text(f"📈 Generating {chart_type} chart…", parse_mode=H)

        try:
            headers, rows = _load_data(path_str)
            chart_path = _make_chart(headers, rows, chart_type, title=Path(path_str).name)
        except Exception as e:
            await msg.edit_text(f"❌ {esc(str(e))}", parse_mode=H)
            return

        if not chart_path:
            await msg.edit_text("❌ No numeric data found to chart.", parse_mode=H)
            return

        await msg.delete()
        await update.message.reply_photo(
            photo=open(chart_path, "rb"),
            caption=f"📊 {chart_type.title()} chart for {esc(Path(path_str).name)}",
        )

    @require_auth
    async def cmd_dataquery(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """/dataquery <file> <question> — NL query on data"""
        args = context.args or []
        if len(args) < 2:
            await update.message.reply_text(
                "Usage: /dataquery <file_path> <question about the data>", parse_mode=H
            )
            return

        path_str = args[0]
        question = " ".join(args[1:])
        msg = await update.message.reply_text("🔍 Querying data…", parse_mode=H)

        try:
            headers, rows = _load_data(path_str)
        except Exception as e:
            await msg.edit_text(f"❌ {esc(str(e))}", parse_mode=H)
            return

        stats = _basic_stats(headers, rows)
        sample = "\n".join(",".join(r) for r in rows[:20])

        system = "You are a data analyst. Answer the user's question about the dataset precisely. If the answer requires computation, show the calculation."
        prompt = (
            f"Dataset columns: {', '.join(headers)}\n"
            f"Total rows: {len(rows)}\n"
            f"Statistics: {json.dumps(stats)[:1500]}\n"
            f"Sample data:\n{sample}\n\n"
            f"Question: {question}"
        )

        answer = await _ai_insight(prompt, system)
        await msg.edit_text(
            f"<b>Query:</b> {esc(question)}\n\n<b>Answer:</b>\n{esc(answer[:2000])}",
            parse_mode=H,
        )

    @require_auth
    async def cmd_anomaly(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """/anomaly <file> — AI anomaly detection"""
        if not context.args:
            await update.message.reply_text("Usage: /anomaly <file_path>", parse_mode=H)
            return

        path_str = context.args[0]
        msg = await update.message.reply_text("🔎 Detecting anomalies…", parse_mode=H)

        try:
            headers, rows = _load_data(path_str)
        except Exception as e:
            await msg.edit_text(f"❌ {esc(str(e))}", parse_mode=H)
            return

        stats  = _basic_stats(headers, rows)
        sample = "\n".join(",".join(r) for r in rows[:30])

        system = "You are a data quality expert. Identify anomalies, outliers, data quality issues, and suspicious patterns in the dataset."
        prompt = (
            f"Dataset: {Path(path_str).name} ({len(rows)} rows)\n"
            f"Columns: {', '.join(headers)}\n"
            f"Stats: {json.dumps(stats)[:1500]}\n"
            f"Sample:\n{sample}\n\n"
            "List anomalies, outliers, and data quality issues found:"
        )

        result = await _ai_insight(prompt, system)
        await msg.edit_text(
            f"<b>🔎 Anomaly Report: {esc(Path(path_str).name)}</b>\n\n{esc(result[:2500])}",
            parse_mode=H,
        )

    @require_auth
    async def cmd_correlate(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """/correlate <file> — correlation matrix"""
        if not context.args:
            await update.message.reply_text("Usage: /correlate <file_path>", parse_mode=H)
            return

        path_str = context.args[0]
        msg = await update.message.reply_text("📐 Computing correlations…", parse_mode=H)

        try:
            headers, rows = _load_data(path_str)
        except Exception as e:
            await msg.edit_text(f"❌ {esc(str(e))}", parse_mode=H)
            return

        # Get numeric columns only
        numeric = {}
        for i, h in enumerate(headers):
            vals = []
            for r in rows:
                try:
                    vals.append(float(r[i]))
                except (ValueError, IndexError):
                    pass
            if len(vals) >= 5:
                numeric[h] = vals[:min(len(vals), 500)]

        if len(numeric) < 2:
            await msg.edit_text("❌ Need at least 2 numeric columns for correlation.", parse_mode=H)
            return

        def pearson(xs, ys):
            n   = min(len(xs), len(ys))
            xs  = xs[:n]; ys = ys[:n]
            mx  = sum(xs)/n; my = sum(ys)/n
            num = sum((x-mx)*(y-my) for x,y in zip(xs,ys))
            dx  = (sum((x-mx)**2 for x in xs)**0.5)
            dy  = (sum((y-my)**2 for y in ys)**0.5)
            return round(num / (dx*dy+1e-10), 4)

        cols = list(numeric.keys())
        matrix = []
        for a in cols:
            row_str = f"<b>{esc(a[:15])}</b>: "
            for b in cols:
                r = pearson(numeric[a], numeric[b])
                emoji = "🔴" if abs(r) > 0.8 else ("🟡" if abs(r) > 0.5 else "⚪")
                row_str += f"{emoji}{r:+.2f} "
            matrix.append(row_str)

        text = (
            f"<b>📐 Correlation Matrix: {esc(Path(path_str).name)}</b>\n"
            f"Columns: {', '.join(esc(c) for c in cols)}\n\n"
            + "\n".join(matrix)
            + "\n\n🔴 |r|>0.8 strong  🟡 |r|>0.5 moderate  ⚪ weak"
        )
        await msg.edit_text(text[:4000], parse_mode=H)
