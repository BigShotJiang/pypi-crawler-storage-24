"""
Salim Knowledge Base — Manus-style persistent knowledge store with semantic search.

Manus learns from interactions and builds a user-specific knowledge base.
Salim v14 has /memory for key-value pairs but no semantic search or graph.

Commands:
  /kb add <title> <content>         — add knowledge entry
  /kb search <query>                — semantic keyword search
  /kb get <id_or_title>             — retrieve specific entry
  /kb list [tag]                    — list all entries (optionally by tag)
  /kb del <id>                      — delete an entry
  /kb tag <id> <tags...>            — add tags to entry
  /kb summary                       — AI summary of your entire knowledge base
  /kb import <file_path>            — bulk import from text/markdown file
  /kb export                        — download full KB as Markdown
  /kb relate <id1> <id2>            — link two entries as related
  /kb graph                         — show knowledge graph (text)
"""
from __future__ import annotations

import hashlib
import html
import json
import logging
import re
import time
from collections import defaultdict
from datetime import datetime
from pathlib import Path
from typing import Optional

from telegram import Update
from telegram.ext import ContextTypes

from salim.auth import require_auth

logger = logging.getLogger("salim.kb")
esc = lambda v: html.escape(str(v), quote=False)
H = "HTML"

KB_DIR = Path.home() / ".salim" / "kb"


# ═══════════════════════════════════════════════════════════════════════════════
#  STORAGE
# ═══════════════════════════════════════════════════════════════════════════════

def _kb_file(user_id: int) -> Path:
    KB_DIR.mkdir(parents=True, exist_ok=True)
    return KB_DIR / f"{user_id}.json"


def _load_kb(user_id: int) -> dict:
    p = _kb_file(user_id)
    if not p.exists():
        return {"entries": {}, "relations": []}
    try:
        return json.loads(p.read_text())
    except Exception:
        return {"entries": {}, "relations": []}


def _save_kb(user_id: int, kb: dict):
    _kb_file(user_id).write_text(json.dumps(kb, indent=2))


def _entry_id(title: str) -> str:
    return hashlib.md5(f"{title}{time.time()}".encode()).hexdigest()[:8]


def _tokenize(text: str) -> set:
    return set(re.findall(r"\b\w{3,}\b", text.lower()))


def _score(entry: dict, query_tokens: set) -> int:
    tokens = (
        _tokenize(entry.get("title", ""))
        | _tokenize(entry.get("content", ""))
        | _tokenize(" ".join(entry.get("tags", [])))
    )
    return len(tokens & query_tokens)


# ═══════════════════════════════════════════════════════════════════════════════
#  AI HELPERS
# ═══════════════════════════════════════════════════════════════════════════════

async def _ai(prompt: str, system: str = "", max_tokens: int = 800) -> str:
    try:
        from salim.ai import call_ai
        return await call_ai(prompt, system=system, max_tokens=max_tokens)
    except Exception as e:
        return f"AI_UNAVAILABLE: {e}"


# ═══════════════════════════════════════════════════════════════════════════════
#  HANDLERS
# ═══════════════════════════════════════════════════════════════════════════════

class KnowledgeBaseHandlers:

    @require_auth
    async def cmd_kb(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """/kb <subcommand> — knowledge base"""
        args = context.args or []
        if not args:
            await update.message.reply_text(
                "<b>📚 Knowledge Base</b>\n\n"
                "/kb add &lt;title&gt; | &lt;content&gt;\n"
                "/kb search &lt;query&gt;\n"
                "/kb get &lt;id_or_title&gt;\n"
                "/kb list [tag]\n"
                "/kb del &lt;id&gt;\n"
                "/kb tag &lt;id&gt; &lt;tags...&gt;\n"
                "/kb summary\n"
                "/kb export\n"
                "/kb relate &lt;id1&gt; &lt;id2&gt;\n"
                "/kb graph\n"
                "/kb import &lt;file&gt;",
                parse_mode=H,
            )
            return

        uid = update.effective_user.id
        sub = args[0].lower()

        if sub == "add":
            text = " ".join(args[1:])
            if "|" in text:
                title, content = text.split("|", 1)
                title   = title.strip()
                content = content.strip()
            else:
                title   = text[:60].strip()
                content = text.strip()

            if not title or not content:
                await update.message.reply_text(
                    "Usage: /kb add <title> | <content>\nExample: /kb add Python tips | Use list comprehensions for better performance",
                    parse_mode=H,
                )
                return

            kb  = _load_kb(uid)
            eid = _entry_id(title)
            kb["entries"][eid] = {
                "id": eid, "title": title, "content": content,
                "tags": [], "created": datetime.utcnow().isoformat(),
                "updated": datetime.utcnow().isoformat(),
            }
            _save_kb(uid, kb)
            await update.message.reply_text(
                f"✅ Saved to KB: <b>{esc(title)}</b> [<code>{eid}</code>]",
                parse_mode=H,
            )

        elif sub == "search":
            query = " ".join(args[1:])
            if not query:
                await update.message.reply_text("Usage: /kb search <query>", parse_mode=H)
                return
            kb     = _load_kb(uid)
            tokens = _tokenize(query)
            scored = [
                (eid, entry, _score(entry, tokens))
                for eid, entry in kb["entries"].items()
            ]
            scored.sort(key=lambda x: x[2], reverse=True)
            hits = [(eid, e) for eid, e, sc in scored if sc > 0][:8]

            if not hits:
                await update.message.reply_text(f"No results for: <i>{esc(query)}</i>", parse_mode=H)
                return

            rows = []
            for eid, e in hits:
                tags = f" [{', '.join(e['tags'])}]" if e["tags"] else ""
                rows.append(
                    f"<code>{eid}</code> <b>{esc(e['title'])}</b>{esc(tags)}\n"
                    f"  {esc(e['content'][:100])}"
                )
            await update.message.reply_text(
                f"<b>🔍 KB Search: {esc(query)}</b> ({len(hits)} results)\n\n" + "\n\n".join(rows),
                parse_mode=H,
            )

        elif sub == "get":
            if len(args) < 2:
                await update.message.reply_text("Usage: /kb get <id_or_title>", parse_mode=H)
                return
            query = " ".join(args[1:])
            kb    = _load_kb(uid)

            # Try exact ID first
            entry = kb["entries"].get(query)
            if not entry:
                # Try title match
                for e in kb["entries"].values():
                    if query.lower() in e["title"].lower():
                        entry = e
                        break
            if not entry:
                await update.message.reply_text(f"Entry not found: {esc(query)}", parse_mode=H)
                return

            tags = f"\n<b>Tags:</b> {', '.join(esc(t) for t in entry['tags'])}" if entry["tags"] else ""
            await update.message.reply_text(
                f"<b>{esc(entry['title'])}</b> [<code>{entry['id']}</code>]\n"
                f"<i>{entry.get('created','')[:10]}</i>{tags}\n\n"
                f"{esc(entry['content'][:3000])}",
                parse_mode=H,
            )

        elif sub == "list":
            kb   = _load_kb(uid)
            tag  = args[1].lower() if len(args) > 1 else None
            entries = list(kb["entries"].values())
            if tag:
                entries = [e for e in entries if tag in [t.lower() for t in e.get("tags", [])]]
            if not entries:
                await update.message.reply_text("No entries found.", parse_mode=H)
                return

            rows = []
            for e in sorted(entries, key=lambda x: x.get("created",""), reverse=True)[:30]:
                tags = f" [{', '.join(e['tags'][:3])}]" if e["tags"] else ""
                rows.append(f"<code>{e['id']}</code> <b>{esc(e['title'])}</b>{esc(tags)}")

            header = f"<b>📚 Knowledge Base ({len(entries)} entries)</b>"
            if tag:
                header += f" [tag: {esc(tag)}]"
            await update.message.reply_text(header + "\n\n" + "\n".join(rows), parse_mode=H)

        elif sub == "del":
            if len(args) < 2:
                await update.message.reply_text("Usage: /kb del <id>", parse_mode=H)
                return
            kb = _load_kb(uid)
            eid = args[1]
            if eid in kb["entries"]:
                title = kb["entries"][eid]["title"]
                del kb["entries"][eid]
                kb["relations"] = [r for r in kb.get("relations", []) if eid not in r]
                _save_kb(uid, kb)
                await update.message.reply_text(f"🗑 Deleted: <b>{esc(title)}</b>", parse_mode=H)
            else:
                await update.message.reply_text("Entry not found.", parse_mode=H)

        elif sub == "tag":
            if len(args) < 3:
                await update.message.reply_text("Usage: /kb tag <id> <tags...>", parse_mode=H)
                return
            kb  = _load_kb(uid)
            eid = args[1]
            if eid not in kb["entries"]:
                await update.message.reply_text("Entry not found.", parse_mode=H)
                return
            new_tags = args[2:]
            kb["entries"][eid].setdefault("tags", [])
            for t in new_tags:
                if t not in kb["entries"][eid]["tags"]:
                    kb["entries"][eid]["tags"].append(t)
            _save_kb(uid, kb)
            await update.message.reply_text(
                f"✅ Tags updated: {esc(', '.join(kb['entries'][eid]['tags']))}",
                parse_mode=H,
            )

        elif sub == "summary":
            kb = _load_kb(uid)
            if not kb["entries"]:
                await update.message.reply_text("KB is empty.", parse_mode=H)
                return
            msg = await update.message.reply_text("🤖 Summarizing your knowledge base…", parse_mode=H)
            all_text = "\n\n".join(
                f"[{e['title']}]: {e['content'][:300]}"
                for e in list(kb["entries"].values())[:40]
            )
            system = "You are a knowledge assistant. Summarize what the user knows, identify themes, and suggest gaps."
            result = await _ai(f"Knowledge base contents:\n{all_text[:5000]}", system)
            await msg.edit_text(
                f"<b>📚 Your KB Summary</b> ({len(kb['entries'])} entries)\n\n{esc(result[:2500])}",
                parse_mode=H,
            )

        elif sub == "export":
            kb = _load_kb(uid)
            if not kb["entries"]:
                await update.message.reply_text("KB is empty.", parse_mode=H)
                return
            lines = ["# Salim Knowledge Base Export\n"]
            for e in sorted(kb["entries"].values(), key=lambda x: x.get("created","")):
                tags = f"  \nTags: {', '.join(e['tags'])}" if e["tags"] else ""
                lines.append(f"## {e['title']}  \nID: `{e['id']}`  \nDate: {e.get('created','')[:10]}{tags}\n\n{e['content']}\n")
            md_content = "\n---\n\n".join(lines)
            import io
            buf = io.BytesIO(md_content.encode())
            buf.name = "knowledge_base.md"
            await update.message.reply_document(document=buf, caption="📚 Your full knowledge base")

        elif sub == "relate":
            if len(args) < 3:
                await update.message.reply_text("Usage: /kb relate <id1> <id2>", parse_mode=H)
                return
            kb  = _load_kb(uid)
            a, b = args[1], args[2]
            if a not in kb["entries"] or b not in kb["entries"]:
                await update.message.reply_text("One or both IDs not found.", parse_mode=H)
                return
            kb.setdefault("relations", [])
            if [a, b] not in kb["relations"] and [b, a] not in kb["relations"]:
                kb["relations"].append([a, b])
            _save_kb(uid, kb)
            ta = kb["entries"][a]["title"]
            tb = kb["entries"][b]["title"]
            await update.message.reply_text(
                f"🔗 Related: <b>{esc(ta)}</b> ↔ <b>{esc(tb)}</b>",
                parse_mode=H,
            )

        elif sub == "graph":
            kb = _load_kb(uid)
            relations = kb.get("relations", [])
            if not relations:
                await update.message.reply_text("No relations defined yet. Use /kb relate <id1> <id2>.", parse_mode=H)
                return
            lines = ["<b>🕸 Knowledge Graph</b>\n"]
            for a, b in relations:
                ta = kb["entries"].get(a, {}).get("title", a)[:40]
                tb = kb["entries"].get(b, {}).get("title", b)[:40]
                lines.append(f"  {esc(ta)} ↔ {esc(tb)}")
            await update.message.reply_text("\n".join(lines), parse_mode=H)

        elif sub == "import":
            if len(args) < 2:
                await update.message.reply_text("Usage: /kb import <file_path>", parse_mode=H)
                return
            path = Path(args[1]).expanduser()
            if not path.exists():
                await update.message.reply_text("File not found.", parse_mode=H)
                return
            text    = path.read_text(errors="replace")
            kb      = _load_kb(uid)
            count   = 0
            # Split on ## headings or --- separators
            sections = re.split(r"\n(?:#{1,3} |---\n)", text)
            for section in sections:
                section = section.strip()
                if len(section) < 10:
                    continue
                lines   = section.split("\n", 1)
                title   = lines[0].strip()[:80]
                content = lines[1].strip() if len(lines) > 1 else section
                if not title:
                    continue
                eid = _entry_id(title)
                kb["entries"][eid] = {
                    "id": eid, "title": title, "content": content[:2000],
                    "tags": ["imported"], "created": datetime.utcnow().isoformat(),
                    "updated": datetime.utcnow().isoformat(),
                }
                count += 1
            _save_kb(uid, kb)
            await update.message.reply_text(
                f"✅ Imported <b>{count}</b> entries from {esc(path.name)}.",
                parse_mode=H,
            )

        else:
            await update.message.reply_text(f"Unknown subcommand: {esc(sub)}. Use /kb for help.", parse_mode=H)
