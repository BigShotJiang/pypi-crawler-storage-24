"""
Salim Workflow Engine — Manus-style named pipeline automation.

Manus can build complex workflows with conditionals, loops, and triggers.
Salim v14 has /at /every schedulers but no full workflow pipelines.

Commands:
  /wf new <name> <description>        — create new workflow
  /wf step <name> <tool> <args...>    — add step to workflow
  /wf if <name> <condition> <action>  — add conditional branch
  /wf trigger <name> cron|file|event  — set trigger
  /wf run <name> [args...]            — run a workflow now
  /wf list                            — list all workflows
  /wf show <name>                     — inspect a workflow
  /wf del <name>                      — delete a workflow
  /wf log <name>                      — show run history
  /wf enable/disable <name>           — toggle auto-trigger
"""
from __future__ import annotations

import asyncio
import html
import json
import logging
import os
import re
import subprocess
import time
from datetime import datetime
from pathlib import Path
from typing import Any

from telegram import Update
from telegram.ext import ContextTypes

from salim.auth import require_auth

logger = logging.getLogger("salim.workflow")
esc = lambda v: html.escape(str(v), quote=False)
H = "HTML"

WF_DIR     = Path.home() / ".salim" / "workflows"
WF_LOG_DIR = Path.home() / ".salim" / "wf_logs"

_running_wf: dict[str, asyncio.Task] = {}


# ═══════════════════════════════════════════════════════════════════════════════
#  WORKFLOW STORAGE
# ═══════════════════════════════════════════════════════════════════════════════

def _wf_path(name: str) -> Path:
    WF_DIR.mkdir(parents=True, exist_ok=True)
    return WF_DIR / f"{name}.json"


def _load_wf(name: str) -> dict | None:
    p = _wf_path(name)
    if not p.exists():
        return None
    try:
        return json.loads(p.read_text())
    except Exception:
        return None


def _save_wf(wf: dict):
    p = _wf_path(wf["name"])
    p.write_text(json.dumps(wf, indent=2))


def _list_wfs() -> list[dict]:
    WF_DIR.mkdir(parents=True, exist_ok=True)
    wfs = []
    for f in sorted(WF_DIR.glob("*.json")):
        try:
            wfs.append(json.loads(f.read_text()))
        except Exception:
            pass
    return wfs


def _log_run(name: str, status: str, output: str, elapsed: float):
    WF_LOG_DIR.mkdir(parents=True, exist_ok=True)
    entry = {
        "ts": datetime.utcnow().isoformat(),
        "name": name,
        "status": status,
        "elapsed_s": round(elapsed, 2),
        "output": output[:2000],
    }
    log_file = WF_LOG_DIR / f"{name}.jsonl"
    with open(log_file, "a") as f:
        f.write(json.dumps(entry) + "\n")


# ═══════════════════════════════════════════════════════════════════════════════
#  STEP EXECUTOR
# ═══════════════════════════════════════════════════════════════════════════════

async def _execute_step(step: dict, context_vars: dict) -> str:
    """Execute one workflow step, interpolating {{var}} placeholders."""
    tool = step.get("tool", "shell")
    raw  = json.dumps(step.get("args", {}))

    # Interpolate context variables
    for k, v in context_vars.items():
        raw = raw.replace(f"{{{{{k}}}}}", str(v))
    try:
        args = json.loads(raw)
    except Exception:
        args = {}

    if tool == "shell":
        cmd = args.get("cmd", "echo 'no cmd'")
        try:
            r = subprocess.run(cmd, shell=True, capture_output=True, text=True, timeout=30)
            return (r.stdout + r.stderr).strip()[:2000]
        except subprocess.TimeoutExpired:
            return "TIMEOUT"
        except Exception as e:
            return f"ERROR: {e}"

    elif tool == "web_fetch":
        try:
            import httpx
            url = args.get("url", "")
            async with httpx.AsyncClient(timeout=15, follow_redirects=True) as c:
                r = await c.get(url, headers={"User-Agent": "SalimWorkflow/1.0"})
                text = re.sub(r"<[^>]+>", " ", r.text)
                return re.sub(r"\s+", " ", text).strip()[:2000]
        except Exception as e:
            return f"FETCH_ERROR: {e}"

    elif tool == "write_file":
        path    = args.get("path", "")
        content = args.get("content", "")
        try:
            p = Path(path).expanduser()
            p.parent.mkdir(parents=True, exist_ok=True)
            p.write_text(content)
            return f"Written {len(content)} chars to {path}"
        except Exception as e:
            return f"WRITE_ERROR: {e}"

    elif tool == "read_file":
        try:
            return Path(args.get("path","")).expanduser().read_text(errors="replace")[:2000]
        except Exception as e:
            return f"READ_ERROR: {e}"

    elif tool == "ai":
        try:
            from salim.ai import call_ai
            return await call_ai(args.get("prompt", ""), max_tokens=800)
        except Exception as e:
            return f"AI_ERROR: {e}"

    elif tool == "notify":
        # Will be sent as Telegram message back to user
        return f"NOTIFY:{args.get('message','')}"

    elif tool == "python":
        import tempfile, sys
        code = args.get("code", "")
        with tempfile.NamedTemporaryFile(mode="w", suffix=".py", delete=False) as f:
            f.write(code)
            fname = f.name
        try:
            r = subprocess.run([sys.executable, fname], capture_output=True, text=True, timeout=30)
            os.unlink(fname)
            return (r.stdout + r.stderr).strip()[:2000]
        except Exception as e:
            return f"PYTHON_ERROR: {e}"

    return f"UNKNOWN_TOOL: {tool}"


async def _check_condition(condition: str, context_vars: dict) -> bool:
    """Evaluate a simple condition string."""
    # Replace variables
    cond = condition
    for k, v in context_vars.items():
        cond = cond.replace(f"{{{{{k}}}}}", str(v))

    # Support: contains, >, <, ==, !=
    try:
        if " contains " in cond:
            a, b = cond.split(" contains ", 1)
            return b.strip().strip('"\'') in a.strip()
        if " == " in cond:
            a, b = cond.split(" == ", 1)
            return a.strip() == b.strip().strip('"\'')
        if " != " in cond:
            a, b = cond.split(" != ", 1)
            return a.strip() != b.strip().strip('"\'')
        if " > " in cond:
            a, b = cond.split(" > ", 1)
            return float(a.strip()) > float(b.strip())
        if " < " in cond:
            a, b = cond.split(" < ", 1)
            return float(a.strip()) < float(b.strip())
        return bool(eval(cond, {"__builtins__": {}}, {}))
    except Exception:
        return True  # default pass


# ═══════════════════════════════════════════════════════════════════════════════
#  WORKFLOW RUNNER
# ═══════════════════════════════════════════════════════════════════════════════

async def run_workflow(
    wf: dict,
    update_fn=None,
    run_args: list = None,
) -> tuple[str, str]:
    """Execute a workflow. Returns (status, full_output)."""
    start_ts  = time.time()
    ctx_vars  = {"args": " ".join(run_args or [])}
    outputs   = []
    wf_name   = wf.get("name", "?")

    for i, run_args_item in enumerate(run_args or [], 1):
        ctx_vars[f"arg{i}"] = run_args_item

    for step_idx, step in enumerate(wf.get("steps", []), 1):
        if update_fn:
            await update_fn(f"⚙️ Step {step_idx}/{len(wf['steps'])}: {esc(step.get('desc','')[:60])}")

        # Check condition
        condition = step.get("condition")
        if condition:
            ok = await _check_condition(condition, ctx_vars)
            if not ok:
                outputs.append(f"[Step {step_idx} SKIPPED — condition false: {condition}]")
                continue

        result = await _execute_step(step, ctx_vars)
        ctx_vars[f"step{step_idx}"] = result
        ctx_vars["last"] = result
        outputs.append(f"[Step {step_idx}: {step.get('desc','')[:40]}]\n{result}")

        # Check on_error
        if result.upper().startswith("ERROR") and step.get("on_error") == "stop":
            outputs.append("[Workflow stopped due to error]")
            elapsed = time.time() - start_ts
            _log_run(wf_name, "error", "\n\n".join(outputs), elapsed)
            return "error", "\n\n".join(outputs)

    elapsed = time.time() - start_ts
    full_output = "\n\n".join(outputs)
    _log_run(wf_name, "success", full_output, elapsed)
    return "success", full_output


# ═══════════════════════════════════════════════════════════════════════════════
#  TELEGRAM HANDLERS
# ═══════════════════════════════════════════════════════════════════════════════

TOOLS_HELP = "shell|web_fetch|write_file|read_file|ai|python|notify"

class WorkflowHandlers:

    @require_auth
    async def cmd_wf(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """/wf <subcommand> — workflow management"""
        args = context.args or []
        if not args:
            await update.message.reply_text(
                "<b>Workflow Engine</b>\n\n"
                "/wf new &lt;name&gt; &lt;description&gt;\n"
                "/wf step &lt;name&gt; &lt;tool&gt; &lt;args_json&gt; [desc=...]\n"
                "/wf if &lt;name&gt; &lt;condition&gt;\n"
                "/wf run &lt;name&gt; [args...]\n"
                "/wf list\n"
                "/wf show &lt;name&gt;\n"
                "/wf del &lt;name&gt;\n"
                "/wf log &lt;name&gt;\n"
                "/wf enable|disable &lt;name&gt;\n\n"
                f"Tools: <code>{esc(TOOLS_HELP)}</code>",
                parse_mode=H,
            )
            return

        sub = args[0].lower()

        if sub == "new":
            if len(args) < 2:
                await update.message.reply_text("Usage: /wf new <name> [description]", parse_mode=H)
                return
            name = args[1]
            desc = " ".join(args[2:]) or ""
            if _load_wf(name):
                await update.message.reply_text(f"⚠️ Workflow <b>{esc(name)}</b> already exists.", parse_mode=H)
                return
            wf = {"name": name, "desc": desc, "steps": [], "enabled": True, "trigger": None, "created": datetime.utcnow().isoformat()}
            _save_wf(wf)
            await update.message.reply_text(f"✅ Workflow <b>{esc(name)}</b> created.\nAdd steps with /wf step {esc(name)} <tool> ...", parse_mode=H)

        elif sub == "step":
            if len(args) < 4:
                await update.message.reply_text(
                    "Usage: /wf step <name> <tool> <args_json_or_cmd>\n"
                    f"Tools: {esc(TOOLS_HELP)}\n"
                    'Example: /wf step myflow shell {"cmd":"date"}',
                    parse_mode=H,
                )
                return
            name  = args[1]
            tool  = args[2]
            wf    = _load_wf(name)
            if not wf:
                await update.message.reply_text(f"Workflow <b>{esc(name)}</b> not found.", parse_mode=H)
                return

            raw_args = " ".join(args[3:])
            # Try JSON first, else treat as shell cmd
            step_args = {}
            try:
                step_args = json.loads(raw_args)
            except json.JSONDecodeError:
                if tool == "shell":
                    step_args = {"cmd": raw_args}
                elif tool == "ai":
                    step_args = {"prompt": raw_args}
                elif tool in ("read_file", "write_file"):
                    step_args = {"path": raw_args}
                else:
                    step_args = {"cmd": raw_args}

            step = {
                "tool": tool,
                "args": step_args,
                "desc": f"{tool}: {raw_args[:50]}",
                "on_error": "continue",
            }
            wf["steps"].append(step)
            _save_wf(wf)
            await update.message.reply_text(
                f"✅ Step added to <b>{esc(name)}</b>: [{tool}] {esc(raw_args[:60])}",
                parse_mode=H,
            )

        elif sub == "if":
            if len(args) < 4:
                await update.message.reply_text(
                    "Usage: /wf if <name> <step_index_1based> <condition>\n"
                    "Example: /wf if myflow 2 {{last}} contains error",
                    parse_mode=H,
                )
                return
            name     = args[1]
            step_idx = int(args[2]) - 1
            cond     = " ".join(args[3:])
            wf       = _load_wf(name)
            if not wf or step_idx >= len(wf["steps"]):
                await update.message.reply_text("Workflow or step not found.", parse_mode=H)
                return
            wf["steps"][step_idx]["condition"] = cond
            _save_wf(wf)
            await update.message.reply_text(
                f"✅ Condition set on step {step_idx+1}: <code>{esc(cond)}</code>",
                parse_mode=H,
            )

        elif sub == "run":
            if len(args) < 2:
                await update.message.reply_text("Usage: /wf run <name> [args...]", parse_mode=H)
                return
            name = args[1]
            run_args = args[2:]
            wf   = _load_wf(name)
            if not wf:
                await update.message.reply_text(f"Workflow <b>{esc(name)}</b> not found.", parse_mode=H)
                return

            msg = await update.message.reply_text(
                f"▶️ Running workflow <b>{esc(name)}</b>…", parse_mode=H
            )

            async def _upd(txt):
                try:
                    await msg.edit_text(f"▶️ <b>{esc(name)}</b>\n{txt}", parse_mode=H)
                except Exception:
                    pass

            async def _exec():
                status, output = await run_workflow(wf, update_fn=_upd, run_args=run_args)
                icon = "✅" if status == "success" else "❌"
                final = f"{icon} <b>Workflow {esc(name)} {status}</b>\n\n{esc(output[:3000])}"
                await msg.edit_text(final[:4000], parse_mode=H)

            asyncio.create_task(_exec())

        elif sub == "list":
            wfs = _list_wfs()
            if not wfs:
                await update.message.reply_text("No workflows defined. Use /wf new <name>.", parse_mode=H)
                return
            rows = []
            for w in wfs:
                enabled = "✅" if w.get("enabled") else "⏸"
                rows.append(
                    f"{enabled} <b>{esc(w['name'])}</b> ({len(w.get('steps',[]))} steps)\n"
                    f"   {esc(w.get('desc','')[:60])}"
                )
            await update.message.reply_text(
                f"<b>Workflows ({len(wfs)}):</b>\n\n" + "\n\n".join(rows), parse_mode=H
            )

        elif sub == "show":
            if len(args) < 2:
                await update.message.reply_text("Usage: /wf show <name>", parse_mode=H)
                return
            wf = _load_wf(args[1])
            if not wf:
                await update.message.reply_text("Workflow not found.", parse_mode=H)
                return
            steps = wf.get("steps", [])
            step_lines = "\n".join(
                f"  {i+1}. [{s['tool']}] {esc(s.get('desc','')[:60])}"
                + (f"\n     if: {esc(s.get('condition',''))}" if s.get("condition") else "")
                for i, s in enumerate(steps)
            )
            text = (
                f"<b>Workflow: {esc(wf['name'])}</b>\n"
                f"<b>Desc:</b> {esc(wf.get('desc',''))}\n"
                f"<b>Steps:</b> {len(steps)}\n"
                f"<b>Enabled:</b> {wf.get('enabled')}\n\n"
                f"<pre>{step_lines}</pre>"
            )
            await update.message.reply_text(text[:4000], parse_mode=H)

        elif sub == "del":
            if len(args) < 2:
                await update.message.reply_text("Usage: /wf del <name>", parse_mode=H)
                return
            p = _wf_path(args[1])
            if p.exists():
                p.unlink()
                await update.message.reply_text(f"🗑 Workflow <b>{esc(args[1])}</b> deleted.", parse_mode=H)
            else:
                await update.message.reply_text("Workflow not found.", parse_mode=H)

        elif sub == "log":
            if len(args) < 2:
                await update.message.reply_text("Usage: /wf log <name>", parse_mode=H)
                return
            log_file = WF_LOG_DIR / f"{args[1]}.jsonl"
            if not log_file.exists():
                await update.message.reply_text("No runs logged yet.", parse_mode=H)
                return
            lines = log_file.read_text().strip().split("\n")[-10:]
            rows  = []
            for line in reversed(lines):
                try:
                    r = json.loads(line)
                    icon = "✅" if r["status"] == "success" else "❌"
                    rows.append(f"{icon} {r['ts'][:16]}  {r['elapsed_s']}s\n   {esc(r['output'][:80])}")
                except Exception:
                    pass
            await update.message.reply_text(
                f"<b>Run log: {esc(args[1])}</b>\n\n" + "\n\n".join(rows),
                parse_mode=H,
            )

        elif sub in ("enable", "disable"):
            if len(args) < 2:
                await update.message.reply_text(f"Usage: /wf {sub} <name>", parse_mode=H)
                return
            wf = _load_wf(args[1])
            if not wf:
                await update.message.reply_text("Workflow not found.", parse_mode=H)
                return
            wf["enabled"] = sub == "enable"
            _save_wf(wf)
            icon = "✅" if wf["enabled"] else "⏸"
            await update.message.reply_text(
                f"{icon} Workflow <b>{esc(args[1])}</b> {'enabled' if wf['enabled'] else 'disabled'}.",
                parse_mode=H,
            )

        else:
            await update.message.reply_text(f"Unknown subcommand: {esc(sub)}", parse_mode=H)
