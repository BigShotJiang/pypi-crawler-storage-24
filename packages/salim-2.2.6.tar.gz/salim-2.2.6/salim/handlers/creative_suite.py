"""
Salim Creative Suite — Manus-style content generation.

Features:
  • Slide/Presentation generation: AI outline → Python-pptx → PPTX file
  • Data Dashboard: CSV/data → matplotlib charts → HTML dashboard or PNG
  • Batch image processing: resize, convert, watermark multiple images
  • Content generation: blog posts, marketing copy, summaries from URLs
  • Resume/CV builder: structured JSON → professional DOCX/PDF

Commands:
  /slides <topic> [N slides]      — generate PPTX presentation
  /dashboard <data_description>   — generate data visualization dashboard
  /batchimg <operation> <params>  — batch image processing
  /blogpost <topic>               — generate full blog post with structure
  /summarize <url>                — summarize webpage/article
"""
from __future__ import annotations

import asyncio
import html
import io
import json
import logging
import os
import re
import subprocess
import sys
import tempfile
import time
from datetime import datetime
from pathlib import Path
from typing import Optional

from telegram import Update
from telegram.ext import ContextTypes

from salim.auth import require_auth

logger = logging.getLogger("salim.creative")
esc = lambda v: html.escape(str(v), quote=False)
H = "HTML"

CREATIVE_DIR = Path.home() / ".salim" / "creative"


# ═══════════════════════════════════════════════════════════════════════════════
#  AUTO-INSTALLER HELPER
# ═══════════════════════════════════════════════════════════════════════════════

def _ensure_package(pkg: str, import_name: Optional[str] = None) -> bool:
    """Install a package if not available."""
    import_name = import_name or pkg
    try:
        __import__(import_name)
        return True
    except ImportError:
        try:
            subprocess.run(
                [sys.executable, "-m", "pip", "install", pkg, "-q"],
                capture_output=True,
                timeout=60,
            )
            __import__(import_name)
            return True
        except Exception:
            return False


# ═══════════════════════════════════════════════════════════════════════════════
#  AI HELPER
# ═══════════════════════════════════════════════════════════════════════════════

async def _ai_generate(config, prompt: str, system: str, max_tokens: int = 2000) -> str:
    try:
        from salim.ai import SalimAI
        ai = SalimAI(config)
        return await ai.chat(
            messages=[{"role": "user", "content": prompt}],
            system=system,
            max_tokens=max_tokens,
        )
    except Exception as e:
        return f"AI error: {e}"


# ═══════════════════════════════════════════════════════════════════════════════
#  PRESENTATION GENERATOR
# ═══════════════════════════════════════════════════════════════════════════════

async def _generate_slides_json(config, topic: str, n_slides: int) -> list[dict]:
    """Ask AI to produce slide content as JSON."""
    prompt = f"""Create a professional {n_slides}-slide presentation about: {topic}

Output ONLY a valid JSON array. Each element has:
  "title": slide title (short, punchy)
  "bullets": array of 3-5 bullet points (each under 12 words)
  "speaker_notes": 2-3 sentences of presenter notes

Example output:
[
  {{"title": "Introduction", "bullets": ["Key point 1", "Key point 2"], "speaker_notes": "Welcome..."}}
]

Output JSON array only. No explanation, no markdown fences."""

    raw = await _ai_generate(config, prompt,
                              "You are a presentation designer. Output ONLY valid JSON arrays.",
                              max_tokens=2000)

    # Extract JSON
    try:
        arr_match = re.search(r'\[.*\]', raw, re.DOTALL)
        if arr_match:
            return json.loads(arr_match.group())
    except Exception:
        pass

    # Fallback: build basic structure
    return [
        {"title": f"Slide {i+1}: {topic}", "bullets": ["Point 1", "Point 2", "Point 3"], "speaker_notes": ""}
        for i in range(n_slides)
    ]


def _build_pptx(slides_data: list[dict], title: str) -> Optional[bytes]:
    """Build PPTX file from slide data. Returns bytes or None."""
    if not _ensure_package("python-pptx", "pptx"):
        return None

    from pptx import Presentation
    from pptx.util import Inches, Pt
    from pptx.enum.text import PP_ALIGN
    from pptx.dml.color import RGBColor

    prs = Presentation()
    prs.slide_width  = Inches(13.33)
    prs.slide_height = Inches(7.5)

    slide_layouts = prs.slide_layouts

    for i, slide in enumerate(slides_data):
        if i == 0:
            layout = slide_layouts[0]  # Title slide
        else:
            layout = slide_layouts[1]  # Title + content

        sl = prs.slides.add_slide(layout)

        # Title
        title_tf = sl.shapes.title
        if title_tf:
            title_tf.text = slide.get("title", f"Slide {i+1}")
            for para in title_tf.text_frame.paragraphs:
                for run in para.runs:
                    run.font.bold = True
                    run.font.size = Pt(32 if i == 0 else 28)

        # Content / bullets
        bullets = slide.get("bullets", [])
        if bullets and len(sl.placeholders) > 1:
            content_ph = sl.placeholders[1]
            tf = content_ph.text_frame
            tf.clear()
            for j, bullet in enumerate(bullets):
                if j == 0:
                    para = tf.paragraphs[0]
                else:
                    para = tf.add_paragraph()
                para.text = str(bullet)
                para.level = 0
                if para.runs:
                    para.runs[0].font.size = Pt(18)

        # Speaker notes
        notes = slide.get("speaker_notes", "")
        if notes:
            notes_slide = sl.notes_slide
            notes_slide.notes_text_frame.text = notes

    buf = io.BytesIO()
    prs.save(buf)
    buf.seek(0)
    return buf.read()


# ═══════════════════════════════════════════════════════════════════════════════
#  DATA DASHBOARD GENERATOR
# ═══════════════════════════════════════════════════════════════════════════════

async def _generate_dashboard(config, description: str, data_file: Optional[str] = None) -> tuple[bytes, str]:
    """
    Generate Python matplotlib code to create charts, execute it, return PNG.
    """
    if not _ensure_package("matplotlib"):
        return b"", "matplotlib not available"

    # Build a data generation / analysis script via AI
    data_context = ""
    if data_file and Path(data_file).exists():
        import csv as csv_mod
        with open(data_file, newline="", encoding="utf-8", errors="replace") as f:
            reader = csv_mod.DictReader(f)
            rows = list(reader)[:20]
            if rows:
                data_context = f"\nSample CSV data (first 20 rows):\n{json.dumps(rows, indent=2)[:1000]}"

    code_prompt = f"""Write Python code that creates a matplotlib dashboard for: {description}
{data_context}

Requirements:
1. Use matplotlib and optionally numpy/pandas (assume installed)
2. Create 2-4 subplots in a figure (12, 8 inches)
3. Use plt.tight_layout()
4. Save to 'dashboard_output.png' with dpi=150
5. Use realistic sample data if no data is provided
6. Add title, labels, grid
7. Make it visually professional

Output ONLY the Python code, no explanation, no markdown fences."""

    code = await _ai_generate(config, code_prompt,
                               "You are a data visualization expert. Output ONLY executable Python code.",
                               max_tokens=1500)

    # Clean code
    code = re.sub(r"```python\n?", "", code)
    code = re.sub(r"```\n?", "", code)
    code = code.strip()

    # Execute in temp dir
    with tempfile.TemporaryDirectory() as tmpdir:
        script_path = os.path.join(tmpdir, "dashboard.py")
        output_path = os.path.join(tmpdir, "dashboard_output.png")

        # Prepend data file copy if available
        full_code = f"""
import os, sys
os.chdir(r'{tmpdir}')
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np

try:
    import pandas as pd
except ImportError:
    pass

{code}
"""
        with open(script_path, "w") as f:
            f.write(full_code)

        try:
            result = subprocess.run(
                [sys.executable, script_path],
                capture_output=True,
                text=True,
                timeout=30,
            )

            if os.path.exists(output_path):
                with open(output_path, "rb") as f:
                    return f.read(), ""
            else:
                err = result.stderr[-500:] if result.stderr else "No output file generated"
                return b"", err
        except subprocess.TimeoutExpired:
            return b"", "Dashboard generation timed out (30s)"
        except Exception as e:
            return b"", str(e)


# ═══════════════════════════════════════════════════════════════════════════════
#  HANDLER MIXIN
# ═══════════════════════════════════════════════════════════════════════════════

class CreativeSuiteHandlers:

    # ── /slides <topic> [N] ──────────────────────────────────────────────────
    @require_auth
    async def cmd_slides(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        args = ctx.args or []
        if not args:
            await update.effective_message.reply_text(
                "🎨 <b>Presentation Generator</b>\n\n"
                "Usage: <code>/slides &lt;topic&gt; [number_of_slides]</code>\n"
                "Examples:\n"
                "<code>/slides Introduction to Machine Learning 8</code>\n"
                "<code>/slides Q3 Sales Results 6</code>\n"
                "<code>/slides Climate Change Solutions 10</code>\n\n"
                "Output: Real downloadable .pptx file",
                parse_mode=H,
            )
            return

        # Parse optional slide count at end
        n_slides = 8
        topic_parts = args[:]
        if args[-1].isdigit():
            n_slides = max(3, min(20, int(args[-1])))
            topic_parts = args[:-1]
        topic = " ".join(topic_parts)

        msg = await update.effective_message.reply_text(
            f"🎨 <b>Creating Presentation</b>\n"
            f"📌 Topic: {esc(topic)}\n"
            f"📊 Slides: {n_slides}\n\n"
            "⏳ Generating slide content with AI...",
            parse_mode=H,
        )

        try:
            slides_data = await _generate_slides_json(self.config, topic, n_slides)

            await msg.edit_text(
                f"🎨 <b>Building PPTX</b>\n"
                f"📝 Generated {len(slides_data)} slides, assembling file...",
                parse_mode=H,
            )

            pptx_bytes = await asyncio.get_event_loop().run_in_executor(
                None, lambda: _build_pptx(slides_data, topic)
            )

            if not pptx_bytes:
                # Fallback: send JSON outline
                outline = "\n".join([
                    f"**Slide {i+1}: {s['title']}**\n" +
                    "\n".join(f"  • {b}" for b in s.get("bullets", []))
                    for i, s in enumerate(slides_data)
                ])
                await msg.edit_text(
                    f"⚠️ python-pptx not available. Here's the outline:\n\n"
                    f"<pre>{esc(outline[:3000])}</pre>",
                    parse_mode=H,
                )
                return

            safe_name = re.sub(r"[^\w]", "_", topic[:30])
            file_name = f"presentation_{safe_name}.pptx"

            await msg.edit_text(
                f"✅ <b>Presentation Ready!</b>\n"
                f"📌 {esc(topic)}\n"
                f"📊 {len(slides_data)} slides  |  {len(pptx_bytes) // 1024} KB",
                parse_mode=H,
            )

            pptx_io = io.BytesIO(pptx_bytes)
            pptx_io.name = file_name
            await update.effective_message.reply_document(
                document=pptx_io,
                caption=f"🎨 Presentation: {topic} ({len(slides_data)} slides)",
                filename=file_name,
            )

        except Exception as e:
            logger.exception(f"Slides error: {e}")
            await msg.edit_text(f"❌ Slides error: {esc(str(e))}", parse_mode=H)

    # ── /dashboard <description> ─────────────────────────────────────────────
    @require_auth
    async def cmd_dashboard(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        args = ctx.args or []
        msg_obj = update.effective_message

        if not args:
            await msg_obj.reply_text(
                "📊 <b>Data Dashboard Generator</b>\n\n"
                "Usage: <code>/dashboard &lt;description&gt;</code>\n"
                "Examples:\n"
                "<code>/dashboard monthly sales by region bar chart</code>\n"
                "<code>/dashboard stock price comparison line chart AAPL vs TSLA</code>\n"
                "<code>/dashboard pie chart of global internet usage by country</code>\n\n"
                "Or reply to a CSV file with <code>/dashboard</code> to visualize it.\n"
                "Output: PNG dashboard image",
                parse_mode=H,
            )
            return

        description = " ".join(args)

        # Check if replying to a CSV
        data_file = None
        if msg_obj.reply_to_message and msg_obj.reply_to_message.document:
            doc = msg_obj.reply_to_message.document
            if doc.file_name and doc.file_name.endswith(".csv"):
                CREATIVE_DIR.mkdir(parents=True, exist_ok=True)
                csv_path = CREATIVE_DIR / f"data_{int(time.time())}.csv"
                file_obj = await doc.get_file()
                await file_obj.download_to_drive(str(csv_path))
                data_file = str(csv_path)

        msg = await msg_obj.reply_text(
            f"📊 <b>Generating Dashboard</b>\n{esc(description)}\n\n⏳ AI writing visualization code...",
            parse_mode=H,
        )

        try:
            await msg.edit_text(
                f"📊 <b>Generating Dashboard</b>\n{esc(description)}\n\n⏳ Executing visualization code...",
                parse_mode=H,
            )

            png_bytes, error = await _generate_dashboard(self.config, description, data_file)

            if error or not png_bytes:
                await msg.edit_text(
                    f"❌ Dashboard error: {esc(error or 'No output generated')}\n\n"
                    "Tip: Try a simpler description or check if matplotlib is installed.",
                    parse_mode=H,
                )
                return

            await msg.edit_text(
                f"✅ <b>Dashboard Generated!</b>\n📊 {esc(description)}",
                parse_mode=H,
            )
            await msg_obj.reply_photo(
                photo=io.BytesIO(png_bytes),
                caption=f"📊 Dashboard: {description}",
            )

        except Exception as e:
            logger.exception(f"Dashboard error: {e}")
            await msg.edit_text(f"❌ Dashboard error: {esc(str(e))}", parse_mode=H)

    # ── /blogpost <topic> ────────────────────────────────────────────────────
    @require_auth
    async def cmd_blogpost(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        args = ctx.args or []
        if not args:
            await update.effective_message.reply_text(
                "✍️ <b>Blog Post Generator</b>\n\n"
                "Usage: <code>/blogpost &lt;topic&gt;</code>\n"
                "Example: <code>/blogpost The Future of Renewable Energy in 2030</code>\n\n"
                "Generates: full structured blog post with intro, sections, conclusion",
                parse_mode=H,
            )
            return

        topic = " ".join(args)
        msg = await update.effective_message.reply_text(
            f"✍️ Writing blog post on: <b>{esc(topic)}</b>...", parse_mode=H
        )

        try:
            content = await _ai_generate(
                self.config,
                f"Write a comprehensive, engaging blog post about: {topic}\n\n"
                "Structure:\n"
                "# [Compelling Title]\n"
                "## Introduction\n"
                "## [Section 1 - Key Point]\n"
                "## [Section 2 - Analysis]\n"
                "## [Section 3 - Examples/Evidence]\n"
                "## Conclusion\n\n"
                "Length: 600-900 words. Engaging, informative, well-structured.",
                "You are a professional content writer and blogger. Write compelling, well-researched content.",
                max_tokens=1500,
            )

            # Send as file
            CREATIVE_DIR.mkdir(parents=True, exist_ok=True)
            safe_name = re.sub(r"[^\w]", "_", topic[:40])
            file_path = CREATIVE_DIR / f"blog_{safe_name}_{int(time.time())}.md"
            file_path.write_text(content, encoding="utf-8")

            await msg.edit_text(
                f"✅ <b>Blog Post Ready!</b>\n📌 {esc(topic)}\n"
                f"📄 {len(content.split())} words\n\n"
                f"{esc(content[:800])}...",
                parse_mode=H,
            )

            blog_io = io.BytesIO(content.encode())
            blog_io.name = f"blog_{safe_name}.md"
            await update.effective_message.reply_document(
                document=blog_io,
                caption=f"✍️ Blog Post: {topic}",
            )

        except Exception as e:
            await msg.edit_text(f"❌ Blog post error: {esc(str(e))}", parse_mode=H)

    # ── /summarize <url> ─────────────────────────────────────────────────────
    @require_auth
    async def cmd_summarize_url(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        """Fetch and summarize a URL."""
        args = ctx.args or []
        if not args:
            await update.effective_message.reply_text(
                "🔗 Usage: <code>/summarize &lt;url&gt;</code>\n"
                "Example: <code>/summarize https://example.com/article</code>",
                parse_mode=H,
            )
            return

        url = args[0]
        if not url.startswith("http"):
            url = "https://" + url

        msg = await update.effective_message.reply_text(
            f"🔗 Fetching and summarizing <code>{esc(url[:60])}</code>...", parse_mode=H
        )

        try:
            import httpx as _httpx
            headers = {"User-Agent": "Mozilla/5.0 (compatible; SalimBot/1.0)"}
            async with _httpx.AsyncClient(follow_redirects=True, timeout=15) as client:
                r = await client.get(url, headers=headers)
                raw = r.text

            # Extract title and text
            title_m = re.search(r"<title[^>]*>(.*?)</title>", raw, re.IGNORECASE | re.DOTALL)
            title = re.sub(r"<[^>]+>", "", title_m.group(1)).strip() if title_m else url

            text = re.sub(r"<script[^>]*>.*?</script>", " ", raw, flags=re.DOTALL | re.IGNORECASE)
            text = re.sub(r"<style[^>]*>.*?</style>", " ", text, flags=re.DOTALL | re.IGNORECASE)
            text = re.sub(r"<[^>]+>", " ", text)
            text = re.sub(r"\s+", " ", text).strip()[:4000]

            summary = await _ai_generate(
                self.config,
                f"Summarize this webpage content in 3-5 bullet points:\n\nTitle: {title}\nURL: {url}\n\nContent:\n{text}",
                "You are a precise summarizer. Give clear, factual bullet points. Start each bullet with •",
                max_tokens=400,
            )

            await msg.edit_text(
                f"🔗 <b>{esc(title[:100])}</b>\n"
                f"<a href='{esc(url)}'>{esc(url[:60])}</a>\n\n"
                f"{esc(summary)}",
                parse_mode=H,
                disable_web_page_preview=True,
            )

        except Exception as e:
            await msg.edit_text(f"❌ Summarize error: {esc(str(e))}", parse_mode=H)

    # ── /batchimg <operation> ────────────────────────────────────────────────
    @require_auth
    async def cmd_batchimg(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        """Batch process images: resize, convert, compress, watermark."""
        args = ctx.args or []
        if not args:
            await update.effective_message.reply_text(
                "🖼️ <b>Batch Image Processing</b>\n\n"
                "Usage: <code>/batchimg &lt;operation&gt; [params]</code>\n\n"
                "Operations:\n"
                "• <code>/batchimg resize 800x600</code> — resize all images in ~/Pictures\n"
                "• <code>/batchimg convert jpg</code> — convert to JPEG\n"
                "• <code>/batchimg compress 85</code> — compress to quality 85\n"
                "• <code>/batchimg watermark 'My Name'</code> — add text watermark\n"
                "• <code>/batchimg info</code> — show info on images in current dir\n\n"
                "Processes images in current working directory.",
                parse_mode=H,
            )
            return

        op = args[0].lower()
        params = args[1:] if len(args) > 1 else []

        if not _ensure_package("Pillow", "PIL"):
            await update.effective_message.reply_text(
                "⚠️ Pillow is not installed. Run: <code>/run pip install Pillow</code>",
                parse_mode=H,
            )
            return

        from PIL import Image
        import glob

        cwd = Path(getattr(self, "_cwd", Path.home()))
        image_files = []
        for ext in ("*.jpg", "*.jpeg", "*.png", "*.bmp", "*.gif", "*.webp"):
            image_files.extend(cwd.glob(ext))
            image_files.extend(cwd.glob(ext.upper()))

        if not image_files:
            await update.effective_message.reply_text(
                f"❌ No image files found in <code>{esc(str(cwd))}</code>",
                parse_mode=H,
            )
            return

        msg = await update.effective_message.reply_text(
            f"🖼️ Processing {len(image_files)} images: <b>{esc(op)}</b>...", parse_mode=H
        )

        processed = 0
        errors = 0

        try:
            if op == "info":
                lines = [f"🖼️ <b>Images in {esc(str(cwd))}</b>\n"]
                for f in image_files[:20]:
                    try:
                        with Image.open(f) as im:
                            size = f.stat().st_size
                            lines.append(f"<code>{esc(f.name)}</code>: {im.size[0]}×{im.size[1]}  {size // 1024}KB")
                    except Exception as e:
                        lines.append(f"<code>{esc(f.name)}</code>: error")
                await msg.edit_text("\n".join(lines[:25]), parse_mode=H)
                return

            CREATIVE_DIR.mkdir(parents=True, exist_ok=True)
            out_dir = CREATIVE_DIR / f"batch_{op}_{int(time.time())}"
            out_dir.mkdir(parents=True, exist_ok=True)

            for img_path in image_files:
                try:
                    with Image.open(img_path) as im:
                        if op == "resize" and params:
                            # Parse WxH
                            dims = params[0].lower().replace("x", "x")
                            w, h = map(int, dims.split("x"))
                            im_out = im.resize((w, h), Image.LANCZOS)
                            out_path = out_dir / img_path.name
                            im_out.save(str(out_path))

                        elif op == "convert" and params:
                            fmt = params[0].upper()
                            new_name = img_path.stem + f".{params[0].lower()}"
                            out_path = out_dir / new_name
                            im.convert("RGB").save(str(out_path), format=fmt)

                        elif op == "compress":
                            quality = int(params[0]) if params else 80
                            out_path = out_dir / img_path.name
                            im.save(str(out_path), quality=quality, optimize=True)

                        elif op == "watermark" and params:
                            from PIL import ImageDraw, ImageFont
                            wm_text = " ".join(params)
                            draw = ImageDraw.Draw(im)
                            w, h = im.size
                            draw.text((w // 2 - 50, h - 40), wm_text, fill=(255, 255, 255, 128))
                            out_path = out_dir / img_path.name
                            im.save(str(out_path))

                        else:
                            continue

                        processed += 1
                except Exception:
                    errors += 1

            # Zip output
            import zipfile
            zip_path = CREATIVE_DIR / f"batch_{op}_{int(time.time())}.zip"
            with zipfile.ZipFile(str(zip_path), "w") as zf:
                for f in out_dir.iterdir():
                    zf.write(f, f.name)

            await msg.edit_text(
                f"✅ <b>Batch Processing Complete</b>\n"
                f"✔️ Processed: {processed}  ❌ Errors: {errors}\n"
                f"📦 ZIP archive attached",
                parse_mode=H,
            )

            await update.effective_message.reply_document(
                document=open(zip_path, "rb"),
                caption=f"🖼️ Batch {op}: {processed} images",
                filename=zip_path.name,
            )

        except Exception as e:
            logger.exception(f"Batch image error: {e}")
            await msg.edit_text(f"❌ Batch processing error: {esc(str(e))}", parse_mode=H)
