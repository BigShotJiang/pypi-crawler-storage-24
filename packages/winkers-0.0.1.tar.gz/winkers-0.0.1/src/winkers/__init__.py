"""Architectural context layer for AI coding agents."""

__version__ = "0.0.1"
