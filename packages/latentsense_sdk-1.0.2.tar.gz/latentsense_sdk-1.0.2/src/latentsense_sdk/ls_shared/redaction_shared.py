from typing import List, Tuple, Optional

import pydantic

from .base import SimpleTextFile
from .segments import Segment


class Redaction(pydantic.BaseModel):
    score: float
    entity_type: str
    text: str
    start: int
    end: int
    word_pairs: Optional[List[Tuple[float, str, str]]] = None


class RedactionsForSegment(pydantic.BaseModel):
    segment: Segment
    redacted_text: str
    redactions: List[Redaction]

    @property
    def full_redacted_text(self):
        return self.segment.prefix + self.redacted_text + self.segment.suffix


class RedactionFileAnalysis(pydantic.BaseModel):
    file: SimpleTextFile
    redacted: str
    redactions_for_segments: List[RedactionsForSegment]
    report: str
    cutoff: float
    relevance_term: str


class RedactionFileAnalysisWithOriginal(RedactionFileAnalysis):
    runId: str
    originalBytes: str
