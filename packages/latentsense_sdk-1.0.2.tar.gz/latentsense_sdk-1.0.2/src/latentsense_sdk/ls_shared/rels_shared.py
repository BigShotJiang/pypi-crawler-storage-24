from typing import Optional, List

import pydantic

from .base import SimpleTextFile
from .segments import Segment


class RelsGraphEdge(pydantic.BaseModel):
    source: str
    to: str
    canonical_relation: str
    original_triplet: str
    num_reasoning_signifiers: int
    proposition: str
    segment: Segment


class RelationshipGraph(pydantic.BaseModel):
    nodes: List[str]
    edges: List[RelsGraphEdge]


class RelationshipMeasures(pydantic.BaseModel):
    salience: float
    relevance: float


class Location(pydantic.BaseModel):
    start: int
    end: int


class RelationshipPartSpan(pydantic.BaseModel):
    location: Location
    text: Optional[str] = None


class RelationshipAnalysis(pydantic.BaseModel):
    id: int
    parent: RelationshipPartSpan
    child: RelationshipPartSpan
    relation: RelationshipPartSpan
    measures: RelationshipMeasures
    segment: Segment
    previous_segments: List[Segment]

    def __str__(self):
        return f"{self.parent} - {self.relation} - {self.child}"


class ReasonerXFileAnalysis(pydantic.BaseModel):
    file: SimpleTextFile
    graph: RelationshipGraph


class RelsFileAnalysis(pydantic.BaseModel):
    file: SimpleTextFile
    relationships: List[RelationshipAnalysis]
    concepts: List[str]

    @classmethod
    def make_from_relationships(
        cls,
        file: SimpleTextFile,
        relationships: List["EntityRelation"],
        concepts: List[str],
        include_text,
    ):
        analysis_relationships = []
        for i, relationship in enumerate(relationships):
            parent = RelationshipPartSpan(
                location=Location(
                    start=relationship.parent.start_char,
                    end=relationship.parent.end_char,
                )
            )
            child = RelationshipPartSpan(
                location=Location(
                    start=relationship.child.start_char,
                    end=relationship.child.end_char,
                )
            )
            relation = RelationshipPartSpan(
                location=Location(
                    start=relationship.relation.start_char,
                    end=relationship.relation.end_char,
                )
            )

            if include_text:
                parent.text = str(relationship.parent)
                child.text = str(relationship.child)
                relation.text = str(relationship.relation)

            relationship = RelationshipAnalysis(
                id=i,
                parent=parent,
                child=child,
                relation=relation,
                measures=RelationshipMeasures(
                    salience=relationship.salience,
                    relevance=min(1.0, relationship.relevance),
                ),
                segment=relationship.segment,
                previous_segments=relationship.previous_segments,
            )
            analysis_relationships.append(relationship)

        analysis = cls(
            file=file, relationships=analysis_relationships, concepts=concepts
        )
        return analysis


class RelsFileAnalysisWithOriginal(RelsFileAnalysis):
    runId: str
    originalBytes: str


class ReasonerXFileAnalysisWithOriginal(ReasonerXFileAnalysis):
    runId: str
    originalBytes: str


### Chat Types

from typing import Literal, List

from pydantic import BaseModel

from .segments import Segment


class RexMessage(BaseModel):
    text: str
    type: str


class HumanRexMessage(RexMessage):
    type: Literal["human"] = "human"


class AiRexMessage(RexMessage):
    type: Literal["ai"] = "ai"
    evidence: List[str]

    def __str__(self):
        evidence_str = "\n".join(f"- {item}" for item in self.evidence)
        return f"{self.text}\n\nEVIDENCE:\n{evidence_str}"

    @classmethod
    def from_text(cls, text) -> "AiRexMessage":
        # todo also pass in list of valid propositions
        #  and validate evidence list here matches them

        if "EVIDENCE:" in text:
            response_text, evidence_string = text.split("EVIDENCE:", 1)
            raw_evidence = [
                citation.strip()
                for citation in evidence_string.split("\n")
                if "-" in citation
            ]
            evidence = []
            for citation in raw_evidence:
                citation = citation.replace("-", "").strip()
                if citation[0] in ("'", '"'):
                    citation = citation[1:]
                if citation[-1] in ("'", '"'):
                    citation = citation[:-1]
                evidence.append(citation)
        else:
            response_text = text
            evidence = []

        ai_rex_message = AiRexMessage(text=response_text, evidence=evidence)

        return ai_rex_message


class GraphEdge(BaseModel):
    source: str
    canonical_relation: str
    to: str
    num_reasoning_signifiers: int
    original_triplet: str
    proposition: str
    segment: Segment

    @property
    def category(self):
        return self.segment.file_detail.category


class GraphInfo(BaseModel):
    nodes: List[str]
    edges: List[GraphEdge]
