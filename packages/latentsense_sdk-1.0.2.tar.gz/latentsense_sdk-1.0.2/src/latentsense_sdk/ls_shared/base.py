from typing import Optional, List

import pydantic

from .segments import Segment


class SimpleTextFile(pydantic.BaseModel):
    name: str
    segments: List[Segment]

    @property
    def text(self):
        return "".join(segment.text for segment in self.segments)

    @property
    def semantic_segments(self):
        return [
            segment for segment in self.segments if segment.last_semantic_offset >= -1
        ]

    @property
    def semantic_text(self):
        return "".join(segment.inner_text for segment in self.segments)


class Location(pydantic.BaseModel):
    start: int
    end: int
    text: Optional[str] = None
