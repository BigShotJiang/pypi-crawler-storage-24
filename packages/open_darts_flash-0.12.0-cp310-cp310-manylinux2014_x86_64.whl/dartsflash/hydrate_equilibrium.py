import numpy as np
import xarray as xr

from dartsflash.dartsflash import DARTSFlash, R
from dartsflash.components import ConcentrationUnits as cu
from dartsflash.libflash import RootFinding


def evaluate_equilibrium(flash: DARTSFlash, state_spec: dict, compositions: dict, mole_fractions: bool,
                         hydrate_eos_name: str = "sI", concentrations: dict = None, concentration_unit: cu = cu.MOLALITY,
                         print_state: str = None):
    """
    Method to calculate equilibrium pressure/temperature between fluid phases and hydrate phase at given range of P/T, z

    :param flash: DARTSFlash instance, should contain hydrate EoS
    :param state_spec: Dictionary containing state specification. Either pressure or temperature should be None
    :param compositions: Dictionary containing compositions
    :param mole_fractions: Switch for mole fractions in state
    :param hydrate_eos_name: Key of hydrate EoS in Flash.eos, default is "sI"
    :param concentrations: Dictionary of concentrations
    :param concentration_unit: Unit for concentration. 0/MOLALITY) molality (mol/kg H2O), 1/WEIGHT) Weight fraction (-)
    :param print_state: Switch for printing state and progress
    """
    assert hydrate_eos_name in flash.eos.keys(), "Unable to find hydrate EoS"
    assert state_spec["pressure"] is None or state_spec["temperature"] is None, \
        "Please only provide range of pressures OR temperatures, the other one will be computed"
    calc_pressure = state_spec["pressure"] is None
    output_arrays = {"pres": 1} if calc_pressure else {"temp": 1}
    output_type = {"pres": float} if calc_pressure else {"temp": float}

    flash.prev = 1. if calc_pressure else 273.15

    def evaluate(state):
        if calc_pressure:
            result = calc_equilibrium_pressure(flash, state[1], state[2:], flash.prev, hydrate_eos_name)
            output_data = {"pres": lambda pressure=result: pressure}
        else:
            result = calc_equilibrium_temperature(flash, state[0], state[2:], flash.prev, hydrate_eos_name)
            output_data = {"temp": lambda temperature=result: temperature}
        flash.prev = result if result is not None else flash.prev

        return output_data

    return flash.evaluate_full_space(state_spec=state_spec, compositions=compositions, mole_fractions=mole_fractions,
                                     evaluate=evaluate, output_arrays=output_arrays, output_type=output_type,
                                     concentrations=concentrations, concentration_unit=concentration_unit,
                                     print_state=print_state)


def calc_equilibrium_pressure(flash: DARTSFlash, temperature: float, composition: list, p_init: float = None,
                              hydrate_eos_name: str = "sI", dp: float = 10., min_p: float = 1., max_p: float = 500.,
                              tol_f: float = 1e-15, tol_x: float = 1e-15, verbose: bool = False):
    """
    Method to calculate equilibrium pressure between fluid phases and hydrate phase at given T, z

    :param flash: DARTSFlash instance, should contain hydrate EoS
    :param temperature: Temperature [K]
    :param composition: Feed mole fractions [-]
    :param p_init: Initial guess for equilibrium pressure [bar]
    :param hydrate_eos_name: Key of hydrate EoS in Flash.eos, default is "sI"
    :param dp: Step size to find pressure bounds
    :param min_p: Minimum pressure [bar]
    :param tol_f: Tolerance for objective function
    :param tol_x: Tolerance for variable
    :param verbose: Switch for verbose output
    """
    # Find bounds for pressure
    p_init = min_p if p_init is None else p_init
    p_min, p_max = p_init, p_init
    if calc_df(flash, p_init, temperature, composition, hydrate_eos_name) > 0:
        # Hydrate fugacity larger than fluid fugacity
        while True:
            p_max = min(max_p, p_max+dp)
            if calc_df(flash, p_max, temperature, composition, hydrate_eos_name) < 0:
                break
            p_min = min(max_p, p_min+dp)
            if p_min == max_p:
                if verbose:
                    print("Equilibrium pressure above p_max", temperature)
                return None
    else:
        # Hydrate fugacity smaller than fluid fugacity
        while True:
            p_min = max(min_p, p_min-dp)
            if calc_df(flash, p_min, temperature, composition, hydrate_eos_name) > 0:
                break
            p_max = max(min_p, p_max-dp)
            if p_max == min_p:
                if verbose:
                    print("Equilibrium pressure below p_min", temperature)
                return None

    pres = (p_min + p_max) / 2

    # Define objective function for Brent's method
    def obj_fun(pres):
        df = calc_df(flash, pres, temperature, composition, hydrate_eos_name)
        return -df

    rf = RootFinding()
    error = rf.brent(obj_fun, pres, p_min, p_max, tol_f, tol_x)

    if not error == 1:
        return rf.getx()
    else:
        if verbose:
            print("Not converged", temperature)
        return None


def calc_equilibrium_temperature(flash: DARTSFlash, pressure: float, composition: list, t_init: float = None,
                                 hydrate_eos_name: str = "sI", dT: float = 10., min_T: float = 250.,
                                 tol_f: float = 1e-15, tol_x: float = 1e-15, verbose: bool = False):
    """
    Method to calculate equilibrium temperature between fluid phases and hydrate phase at given P, z

    :param flash: DARTSFlash instance, should contain hydrate EoS
    :param pressure: Pressure [bar]
    :param composition: Feed mole fractions [-]
    :param t_init: Initial guess for equilibrium temperature [K]
    :param hydrate_eos_name: Key of hydrate EoS in Flash.eos, default is "sI"
    :param dT: Step size to find pressure bounds
    :param min_T: Minimum temperature [K]
    :param tol_f: Tolerance for objective function
    :param tol_x: Tolerance for variable
    :param verbose: Switch for verbose output
    """
    # Find bounds for temperature
    t_init = min_T if t_init is not None else t_init
    T_min, T_max = t_init, t_init
    if calc_df(flash, pressure, t_init, composition, hydrate_eos_name) < 0:
        while True:
            T_max += dT
            if calc_df(flash, pressure, T_max, composition) > 0:
                break
            T_min += dT
    else:
        while True:
            T_min = max(min_T, T_min - dT)
            if calc_df(flash, pressure, T_min, composition, hydrate_eos_name) < 0:
                break
            T_max = max(min_T, T_max - dT)
            if T_max == min_T:
                if verbose:
                    print("Equilibrium temperature below T_min", pressure)
                return None

    temp = (T_min + T_max) / 2

    # Define objective function for Brent's method
    def obj_fun(temp):
        df = calc_df(flash, pressure, temp, composition, hydrate_eos_name)
        return df

    rf = RootFinding()
    error = rf.brent(obj_fun, temp, T_min, T_max, tol_f, tol_x)

    if not error == 1:
        return rf.getx()
    else:
        if verbose:
            print("Not converged", pressure)
        return None


def calc_df(flash: DARTSFlash, pressure: float, temperature: float, composition: list, hydrate_eos_name: str = "sI"):
    """
    Method to calculate fugacity difference between fluid mixture and hydrate phase

    :param flash: DARTSFlash instance, should contain hydrate EoS
    :param pressure: Pressure [bar]
    :param temperature: Temperature [K]
    :param composition: Feed mole fractions [-]
    :param hydrate_eos_name: Key of hydrate EoS in Flash.eos, default is "sI"
    """
    flash.evaluate(pressure, temperature, composition)
    flash_results = flash.get_flash_results()
    V = np.array(flash_results.nu)
    x = np.array(flash_results.X).reshape(len(V), flash.ns)
    f0 = flash.eos[flash.flash_params.eos_order[0]].fugacity(pressure, temperature, x[0, :])

    fwH = flash.eos[hydrate_eos_name].fw(pressure, temperature, f0)
    df = fwH - f0[flash.comp_data.H2O_idx]
    return df


def calc_properties(flash: DARTSFlash, state_spec: dict, compositions: dict, state_variables: list, flash_results: xr.Dataset,
                    guest_idx: list, aq_eos: str, nonaq_eos: str, hydrate_eos_name: str = "sI", x_H: float = None,
                    concentrations: dict = None, concentration_unit: cu = cu.MOLALITY, print_state: str = None):
    """
    Method to calculate hydrate phase properties at given P,T,z:
    - Hydration number nH [-]
    - Density rhoH [kg/m3]
    - Enthalpy of hydrate formation/dissociation dH [kJ/kmol]

    :param flash: DARTSFlash instance, should contain hydrate EoS
    :param state_spec: Dictionary containing state specification
    :param compositions: Dictionary containing variable dimensions
    :param state_variables: List of state variable names to find index in flash results
    :param flash_results: Dataset of flash results with equilibrium curves
    :param guest_idx: Index of guest molecule(s)
    :param aq_eos: Name of aqueous EoS
    :param nonaq_eos: Name of non-aqueous EoS
    :param hydrate_eos_name: Key of hydrate EoS in Flash.eos, default is "sI"
    :param x_H: Constant hydrate composition, optional
    :param concentrations: Dictionary of concentrations
    :param concentration_unit: Unit for concentration. 0/MOLALITY) molality (mol/kg H2O), 1/WEIGHT) Weight fraction (-)
    :param print_state: Switch for printing state and progress
    """
    state_spec["pressure"] = np.array([state_spec["pressure"]]) if not hasattr(state_spec["pressure"], "__len__") else state_spec["pressure"]
    state_spec["temperature"] = np.array([state_spec["temperature"]]) if not hasattr(state_spec["temperature"], "__len__") else state_spec["temperature"]
    assert state_spec["pressure"][0] is None or state_spec["temperature"][0] is None, \
        "Please only provide range of pressures OR temperatures, the other one will be computed"
    calc_pressure = state_spec["pressure"][0] is None
    output_arrays = {"nH": 1, "rhoH": 1, "dH": 1}
    output_type = {"nH": float, "rhoH": float, "dH": float}

    def evaluate(state):
        output_data = {}

        # Retrieve flash results at current state: p, T, X, eos_idxs, roots
        flash_result = flash_results.loc[{state_var: state[i] for i, state_var in enumerate(state_variables[:-1])}]
        eos_idxs = flash_result.eos_idx.values
        X = flash_result.X.values
        x = np.array(X).reshape(flash.np_max, flash.ns)
        # roots = flash_result.roots.values
        roots = np.zeros(flash.np_max)

        # Calculate hydrate composition
        if x_H is None:
            if calc_pressure:
                p, T = flash_result.pres.values[0], state[1]
                f0 = flash.eos[flash.flash_params.eos_order[0]].fugacity(p, T, x[0, :])
                fwH = flash.eos[hydrate_eos_name].fw(p, T, f0)
                xH = flash.eos[hydrate_eos_name].xH()
            else:
                p, T = state[0], flash_result.temp.values[0]
                f0 = flash.eos[flash.flash_params.eos_order[0]].fugacity(p, T, x[0, :])
                fwH = flash.eos[hydrate_eos_name].fw(p, T, f0)
                xH = flash.eos[hydrate_eos_name].xH()
        else:
            xH = x_H

        # Calculate hydration number nH
        nH = 1. / xH[guest_idx] - 1.
        output_data["nH"] = lambda: nH

        # Density rhoH
        Mw = np.sum(xH * np.array(flash.flash_params.comp_data.Mw)) * 1e-3
        output_data["rhoH"] = lambda: Mw / flash.eos[hydrate_eos_name].V(state[0], state[1], xH)

        # Enthalpy of hydrate formation/dissociation
        Hv = flash.eos[nonaq_eos].H(state[0], state[1], x[1, :], 0, True) * R
        Ha = nH * flash.eos[aq_eos].H(state[0], state[1], x[0, :], 0, True) * R
        Hh = flash.eos[hydrate_eos_name].H(state[0], state[1], xH, 0, True) * (nH + 1) * R
        output_data["dH"] = lambda: (Hv + Ha - Hh) * 1e-3  # H_hyd < H_fluids -> enthalpy release upon formation

        return output_data

    return flash.evaluate_full_space(state_spec=state_spec, compositions=compositions, mole_fractions=True,
                                     evaluate=evaluate, output_arrays=output_arrays, output_type=output_type,
                                     concentrations=concentrations, concentration_unit=concentration_unit,
                                     print_state=print_state)
