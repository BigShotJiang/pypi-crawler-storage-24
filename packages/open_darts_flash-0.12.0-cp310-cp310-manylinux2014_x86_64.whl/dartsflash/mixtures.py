import numpy as np
from dartsflash.components import CompData
from dartsflash.dartsflash import DARTSFlash, EoS, FlashParams


class IAPWS(DARTSFlash):
    def __init__(self, iapws_ideal: bool = True, ice_phase: bool = False):
        super().__init__(comp_data=CompData(components=["H2O"]))

        # Add IAPWS-95 EoS
        iapws = self.get_eos["IAPWS"](self.comp_data, iapws_ideal=iapws_ideal)
        self.add_eos("IAPWS", iapws, root_order=[EoS.RootFlag.MAX, EoS.RootFlag.MIN])

        # Add IAPWS-ice EoS, used only if in ice conditions
        self.eos_order = ["IAPWS", "Ice"] if ice_phase else ["IAPWS"]
        if ice_phase:
            ice = self.get_eos["IAPWSIce"](self.comp_data, iapws_ideal=iapws_ideal)
            self.add_eos("Ice", ice)

    def check_assertions(self):
        return


class VL(DARTSFlash):
    def set_vl_eos(self, vl_eos, root_order: list = None, trial_comps: list = None, rich_phase_order: list = None,
                   stability_tol: float = 1e-20, switch_tol: float = 1e-3, max_iter: int = 100, use_gmix: bool = False):
        # Set default parameters
        trial_comps = trial_comps if trial_comps is not None else [i for i in range(self.nc)]
        root_order = [EoS.RootFlag.MAX, EoS.RootFlag.MIN] if root_order is None else root_order
        rich_phase_order = rich_phase_order if rich_phase_order is not None else []

        self.add_eos("VL", self.get_eos[vl_eos](self.comp_data), trial_comps=trial_comps,
                     root_order=root_order, stability_tol=stability_tol, switch_tol=switch_tol,
                     max_iter=max_iter, rich_phase_order=rich_phase_order, use_gmix=use_gmix)

    def check_assertions(self):
        assert "VL" in self.eos.keys(), "Please specify VL EoS"


class VLAq(DARTSFlash):
    def __init__(self, comp_data: CompData, mixture_name: str = None, hybrid: bool = True):
        super().__init__(comp_data, mixture_name=mixture_name)
        self.hybrid = hybrid
        self.H2O_idx = comp_data.components.index("H2O")

    def set_vl_eos(self, vl_eos: str, trial_comps: list = None, stability_tol: float = 1e-20, switch_tol: float = 1e-3,
                   max_iter: int = 100, root_order: list = None, rich_phase_order: list = None, use_gmix: bool = False):
        # Set default parameters
        trial_comps = trial_comps if trial_comps is not None else [i for i in range(self.nc)]
        root_order = root_order if root_order is not None else [EoS.RootFlag.MAX, EoS.RootFlag.MIN]
        rich_phase_order = rich_phase_order if rich_phase_order is not None else []

        # Set preferred roots for hybrid-EoS approach
        preferred_roots = [(self.H2O_idx, 0.8, EoS.MAX)] if self.hybrid else None

        # Add VL EoS object from get_eos()
        self.add_eos("VL", self.get_eos[vl_eos](comp_data=self.comp_data), trial_comps=trial_comps,
                     stability_tol=stability_tol, switch_tol=switch_tol, max_iter=max_iter, use_gmix=use_gmix,
                     preferred_roots=preferred_roots, root_order=root_order, rich_phase_order=rich_phase_order)

    def set_aq_eos(self, aq_eos: str, stability_tol: float = 1e-20, switch_tol: float = 1e-20, max_iter: int = 10,
                   use_gmix: bool = False):
        # Add AQEoS object from get_eos()
        self.add_eos("Aq", self.get_eos[aq_eos](comp_data=self.comp_data),
                     eos_range={self.H2O_idx: [0.6, 1.]}, trial_comps=[self.H2O_idx],
                     stability_tol=stability_tol, switch_tol=switch_tol, max_iter=max_iter, use_gmix=use_gmix)

    def check_assertions(self):
        assert "VL" in self.eos.keys(), "Please specify VL EoS"
        if self.hybrid:
            assert "Aq" in self.eos.keys(), "Please specify Aq EoS"


class VLAqH(VLAq):
    def set_h_eos(self, hydrate_type: str = None, stability_tol: float = 1e-20, switch_tol: float = 1e-1,
                  max_iter: int = 20, use_gmix: bool = False):
        self.hydrate_type = hydrate_type
        if hydrate_type is None:
            self.add_eos("sI", self.get_eos["Ballard"](comp_data=self.comp_data, hydrate_type="sI"),
                         trial_comps=[self.H2O_idx],
                         stability_tol=stability_tol, switch_tol=switch_tol, max_iter=max_iter, use_gmix=use_gmix)
            self.add_eos("sII", self.get_eos["Ballard"](comp_data=self.comp_data, hydrate_type="sII"),
                         trial_comps=[self.H2O_idx],
                         stability_tol=stability_tol, switch_tol=switch_tol, max_iter=max_iter, use_gmix=use_gmix)
            # self.add_eos("sH", self.get_eos["Ballard"](comp_data=self.comp_data, hydrate_type="sH"),
            #              trial_comps=[self.H2O_idx],
            #              stability_tol=stability_tol, switch_tol=switch_tol, max_iter=max_iter, use_gmix=use_gmix)
        else:
            self.add_eos(hydrate_type, self.get_eos["Ballard"](comp_data=self.comp_data, hydrate_type=hydrate_type),
                         trial_comps=[self.H2O_idx],
                         stability_tol=stability_tol, switch_tol=switch_tol, max_iter=max_iter, use_gmix=use_gmix)

    def check_assertions(self):
        assert "VL" in self.eos.keys(), "Please specify VL EoS"
        if self.hybrid:
            assert "Aq" in self.eos.keys(), "Please specify Aq EoS"
        assert (self.hydrate_type if self.hydrate_type is not None else "sI") in self.eos.keys(), "Please specify hydrate EoS"
