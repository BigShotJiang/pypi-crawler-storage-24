import numpy as np
import xarray as xr

from dartsflash.dartsflash import DARTSFlash
from dartsflash.diagram import Diagram, TernaryDiagram


class PlotEoS:
    """
    Class with methods for plotting EoS P-V and compressibility factor
    """
    @staticmethod
    def pressure_volume(flash: DARTSFlash, temperatures: list | np.ndarray, compositions: list = None,
                        p_props: xr.Dataset = None, v_props: xr.Dataset = None,
                        p_range: list = None, v_range: list = None,
                        logx: bool = False, logy: bool = False):
        """
        Method to plot pressure-volume (P-V) diagram for EoS

        :param flash: DARTSFlash object
        :param temperatures: List of temperatures to plot
        :param compositions: List of compositions to plot
        :param p_props: xarray.Dataset with P-based properties
        :param v_props: xarray.Dataset with V-based properties
        :param p_range: Pressure range
        :param v_range: Volume range
        :param logx: x-axis is logarithmic, default is False
        :param logy: y-axis is logarithmic, default is False
        """
        # Initialize Plot object
        from dartsflash.diagram import Diagram
        plot = Diagram(figsize=(8, 5))
        plot.add_attributes(#suptitle="PV diagram for " + flash.mixture_name,
                            ax_labels=["volume, m3/mol", "pressure, bar"])

        # Plot P vs. V from VT-properties
        if v_props is not None:
            # Slice Dataset at composition
            assert np.all([comp not in v_props.dims for comp in flash.components]) if compositions is None else True, \
                "No composition provided, but v_props dataset contains compositional dimensions"
            comps = {comp: compositions[i] for i, comp in enumerate(flash.components[:-1]) if comp in v_props.dims}

            volume = v_props.volume.values
            pressure = np.array([v_props.sel(comps, method='nearest').sel(
                {"temperature": temp}, method='nearest').P.values for temp in temperatures])
            plot.draw_line(X=volume, Y=pressure,
                           datalabels=['{} K'.format(temp) for temp in temperatures])
            plot.set_axes(xlim=v_range, ylim=p_range)

        # Plot P vs. V from PT-properties
        if p_props is not None:
            # Slice Dataset at composition
            assert np.all([comp not in p_props.dims for comp in flash.components]) if compositions is None else True, \
                "No composition provided, but p_props dataset contains compositional dimensions"
            comps = {comp: compositions[i] for i, comp in enumerate(flash.components[:-1]) if comp in p_props.dims}

            volume = np.array([p_props.sel(comps, method='nearest').sel(
                {"temperature": temp}, method='nearest').V.values for temp in temperatures])
            pressure = np.tile(p_props.pressure.values, (len(temperatures), 1))
            plot.draw_line(X=volume, Y=pressure, styles='dashed',
                           datalabels=['{} K'.format(temp) for temp in temperatures] if v_props is None else None)
        plot.add_attributes(legend=True)
        plot.set_axes(xlim=v_range, ylim=p_range, logx=logx, logy=logy)

        return plot

    @staticmethod
    def compressibility(flash: DARTSFlash, temperatures: list | np.ndarray, compositions: list = None,
                        p_props: xr.Dataset = None, v_props: xr.Dataset = None,
                        p_range: list = None, z_range: list = None):
        """
        Method to plot compressibility factor Z versus pressure for EoS

        :param flash: DARTSFlash object
        :param temperatures: List of temperatures to plot
        :param compositions: List of compositions to plot
        :param p_props: xarray.Dataset with P-based properties
        :param v_props: xarray.Dataset with V-based properties
        :param p_range: Pressure range
        :param z_range: Compressibility factor range
        """
        # Initialize Plot object
        from dartsflash.diagram import Diagram
        plot = Diagram(figsize=(8, 5))
        plot.add_attributes(#suptitle="Compressibility factor Z of " + flash.mixture_name,
                            ax_labels=["pressure, bar", "Z, -"])

        # Plot Z vs. P from VT-properties
        if v_props is not None:
            # Slice Dataset at composition
            assert np.all([comp not in v_props.dims for comp in flash.components]) if compositions is None else True, \
                "No composition provided, but v_props dataset contains compositional dimensions"
            comps = {comp: compositions[i] for i, comp in enumerate(flash.components[:-1]) if comp in v_props.dims}

            Z = np.array([v_props.sel(comps, method='nearest').sel({"temperature": temp}, method='nearest').Z.values for temp in temperatures])
            pressure = np.array([v_props.sel(comps, method='nearest').sel({"temperature": temp}, method='nearest').P.values for temp in temperatures])
            plot.draw_line(X=pressure, Y=Z,
                           datalabels=['{} K'.format(temp) for temp in temperatures])
            plot.set_axes(xlim=p_range, ylim=z_range)

        # Plot Z vs. P from PT-properties
        if p_props is not None:
            # Slice Dataset at composition
            assert np.all([comp not in p_props.dims for comp in flash.components]) if compositions is None else True, \
                "No composition provided, but p_props dataset contains compositional dimensions"
            comps = {comp: compositions[i] for i, comp in enumerate(flash.components[:-1]) if comp in p_props.dims}

            Z = np.array([p_props.sel(comps, method='nearest').sel({"temperature": temp}, method='nearest').Z.values for temp in temperatures])
            pressure = np.array([p_props.pressure.values for temp in temperatures])
            plot.draw_line(X=pressure, Y=Z, styles="dashed",
                           datalabels=['{} K'.format(temp) for temp in temperatures] if v_props is None else None)
            plot.set_axes(xlim=p_range, ylim=z_range)
        plot.add_attributes(legend=True)

        return plot


class PlotProps:
    """
    Class with methods for plotting phase properties and thermodynamic surfaces (e.g., Gibbs energy)
    """
    @staticmethod
    def plot1d(flash: DARTSFlash, props: xr.Dataset, x_var: str, prop_names: list, composition: list = None,
               state: dict = None, title: list = None, ax_labels: list = None, colours: list = None,
               datalabels: list = None):
        """
        Method to generate 1D plot of phase properties vs. state variable or composition

        :param flash: DARTSFlash object
        :param props: xarray.Dataset with properties
        :param x_var: Name of x-axis variable
        :param prop_names: List of properties to plot
        :param composition: List of compositions to plot
        :param state: Dictionary of states to plot
        :param title: Title of plot
        :param ax_labels: List of axes labels
        :param colours: List of colours
        :param datalabels: List of labels
        """
        # Determine state specification
        state = state if state is not None else {}
        assert x_var in props.dims, f"Variable {x_var} not found in props dataset"
        if x_var in flash.state_vars:
            state[x_var] = state[x_var] if x_var in state.keys() else eval("props." + x_var + ".values")

        # Slice dataset at current state
        assert np.all([comp not in props.dims for comp in flash.components]) if composition is None else True, \
            "No composition provided, but props dataset contains compositional dimensions"
        prop_names = [prop_names] if isinstance(prop_names, str) else prop_names
        comps = {comp: composition[i] for i, comp in enumerate(flash.components[:-1])
                 if comp in props.dims and comp != x_var}
        props_at_state = props.sel(comps, method='nearest').sel(state, method='nearest').squeeze().transpose(..., x_var)
        x = props_at_state.coords[x_var].values

        # Create Diagram object
        from dartsflash.diagram import Diagram
        nplots = len(prop_names)
        plot = Diagram(ncols=nplots, figsize=(nplots * 5 + 3, 5))

        assert props is not None, "Please provide the properties to plot"
        for i, prop_name in enumerate(prop_names):
            plot.subplot_idx = i
            prop_array = eval("props_at_state." + prop_name + ".values")

            plot.draw_line(X=x, Y=prop_array, colours=colours, datalabels=datalabels)
            plot.add_attributes(title=title if isinstance(title, str) else (title[i] if title is not None else None),
                                ax_labels=ax_labels)
        return plot

    @staticmethod
    def plot2d(flash: DARTSFlash, props: xr.Dataset, x_var: str, y_var: str, prop_names: list, composition: list = None,
               state: dict = None, logx: bool = False, logy: bool = False, title: list = None, ax_labels: list = None,
               cmap: str = 'winter'):
        """
        Method to generate 2D plot of phase properties

        :param flash: DARTSFlash object
        :param props: xarray.Dataset with properties
        :param x_var: Name of x variable
        :param y_var: Name of y variable
        :param prop_names: List of properties to plot
        :param composition: List of compositions to plot
        :param state: Dictionary of states to plot
        :param logx: x-axis is logarithmic, default is False
        :param logy: y-axis is logarithmic, default is False
        :param title: Title of plot
        :param ax_labels: List of axes labels
        :param cmap: Color map to use
        """
        # Determine state specification
        state = state if state is not None else {}
        for var in [x_var, y_var]:
            assert var in props.dims, f"Variable {var} not found in props dataset"
            if var in flash.state_vars:
                state[var] = state[var] if var in state.keys() else eval("props." + var + ".values")

        # Find compositions
        assert np.all([comp not in props.dims for comp in flash.components]) if composition is None else True, \
            "No composition provided, but props dataset contains compositional dimensions"
        comps = {comp: composition[i] for i, comp in enumerate(flash.components[:-1]) if comp in props.dims
                 and comp != x_var and comp != y_var}

        # Slice dataset at current state
        props_at_state = props.sel(comps, method='nearest').sel(state, method='nearest').squeeze().transpose(x_var, y_var, ...)
        x = props_at_state.coords[x_var].values
        y = props_at_state.coords[y_var].values
        assert not np.isscalar(x), f"Provide array for {x_var}"
        assert not np.isscalar(y), f"Provide array for {y_var}"

        # Create Diagram object
        from dartsflash.diagram import Diagram
        nplots = len(prop_names)
        plot = Diagram(ncols=nplots, figsize=(nplots * 5 + 3, 5))
        is_float = [type(props.dtypes[prop]) is np.dtypes.Float64DType for prop in prop_names]

        for i, prop_name in enumerate(prop_names):
            plot.subplot_idx = i
            prop_array = eval("props_at_state." + prop_name + ".values")

            plot.draw_surf(x=x, y=y, data=prop_array, colours=cmap, colorbar=True, contour=True, fill_contour=True,
                           is_float=is_float[i], ax_labels=ax_labels, logx=logx, logy=logy,
                           )
            plot.add_attributes(title=title if isinstance(title, str) else (title[i] if title is not None else None),
                                ax_labels=ax_labels)
        return plot

    @staticmethod
    def binary(flash: DARTSFlash, prop_name: str, variable_comp_idx: int, dz: float,
               min_z: float = None, max_z: float = None, state: dict = None, composition_to_plot: list = None,
               plot_1p: bool = True, props: xr.Dataset = None, flash_results: xr.Dataset = None, sp_results: xr.Dataset = None,
               title: str = None, ax_label: str = None, datalabels: list = None, legend_loc: str = None):
        """
        Method to plot binary thermodynamic surfaces (e.g., Gibbs energy vs. composition)

        :param flash: DARTSFlash object
        :param state: Dictionary of states to plot surfaces for
        :param variable_comp_idx: Index of variable component
        :param dz: Composition interval
        :param min_z: Minimum composition for composition variable, will default to 0
        :param max_z: Maximum composition for composition variable, will default to 1
        :param plot_1p: Plot single-phase or multiphase results
        :param props: xarray.DataArray of properties
        :param flash_results: xarray.Dataset of flash results
        :param sp_results: xarray.Dataset of stationary points results
        :param composition_to_plot: Composition to plot results for
        :param prop_name: Name of property for indexing
        :param title: Title of plot
        :param ax_label: Axes label
        :param datalabels: List of data labels
        :param legend_loc: Legend location
        """
        # Determine state specification
        state = state if state is not None else {}
        for var in flash.state_vars:
            state[var] = state[var] if var in state.keys() else eval("flash_results." + var + ".values")
        assert np.all([1 if np.isscalar(arr) else len(arr) == 1 for arr in state.values()]), \
            "Can't specify array for state specifications"

        # Determine compositions
        variable_comp = flash.components[variable_comp_idx]
        comp_str = flash.comp_data.comp_labels[variable_comp_idx]
        min_z = 0. if min_z is None else min_z
        max_z = 1. if max_z is None else max_z
        z0 = np.arange(min_z, max_z + dz * 0.1, dz)

        # Initialize plot
        from dartsflash.diagram import Diagram
        plot = Diagram(figsize=(8, 5))

        # Slice results at current state
        res_at_state = props.sel(state, method='nearest').transpose(..., variable_comp).squeeze()
        ydata = eval("res_at_state." + prop_name + ".values")
        minY, maxY = np.nanmin(ydata), np.nanmax(ydata)

        # Plot 1P/equilibrium state
        if plot_1p:
            # Loop over EoS to plot 1P curves
            for j in range(ydata.shape[0]):
                plot.draw_line(X=z0, Y=ydata[j, ...] if ydata.ndim >= 2 else ydata,
                               colours=plot.colours[j], styles=plot.linestyles[0],
                               datalabels=datalabels[j] if datalabels is not None else None)

        else:
            # Plot equilibrium state
            plot.draw_line(X=z0, Y=ydata, colours=plot.colours[0],
                           datalabels=datalabels)

        # Plot flash results at composition
        if flash_results is not None:
            assert composition_to_plot is not None, "Please provide composition to plot equilibrium phases for"

            # Slice flash results at current state
            flash_at_pt = flash_results.sel(state, method='nearest').squeeze()
            comps = {comp: composition_to_plot[i] for i, comp in enumerate(flash.components[:-1])}

            # Find flash results at P,T,z
            flash_at_ptz = flash_at_pt.sel(comps, method='nearest').squeeze()
            X = flash_at_ptz.X.values
            eos_idx = flash_at_ptz.eos_idx.values
            root = flash_at_ptz.root_type.values
            Xj = np.array([X[jj * flash.ns:(jj + 1) * flash.ns] for jj in range(flash.np_max)])

            # Plot phase compositions xij at feed composition z
            xx, yy = [], []
            for j, xj in enumerate(Xj):
                if flash_at_ptz.nu.values[j] > 0.:
                    comps = {comp: Xj[j, i] for i, comp in enumerate(flash.components[:-1])}
                    data = res_at_state.sel(comps, method='nearest')
                    value = eval("data." + prop_name + ".values")[eos_idx[j] + (0 if root[j] != 1 else 1)]

                    xx.append(xj)
                    yy.append(np.float64(value))
            xx = np.array(xx)
            plot.draw_point(X=xx[:, 0], Y=yy, colours='r')
            plot.draw_line(X=xx[:, 0], Y=yy, colours='r')

        # Plot stationary points from stability analysis
        if sp_results is not None:
            assert composition_to_plot is not None, "Please provide composition to plot stationary points for"

            # Slice results at current state
            sp_at_pt = sp_results.sel(state, method='nearest').squeeze()
            comps = {comp: composition_to_plot[i] for i, comp in enumerate(flash.components[:-1])}

            # Find stationary points at P,T,z
            sp_at_ptz = sp_at_pt.sel(comps, method='nearest').squeeze()
            Y = sp_at_ptz.y.values
            tot_sp = sp_at_ptz.tot_sp.values
            tpd = sp_at_ptz.tpd.values
            eos_idx = sp_at_ptz.eos_idx.values
            roots = sp_at_ptz.root_type.values

            Yj = np.array([Y[jj * flash.ns:(jj + 1) * flash.ns] for jj in range(tot_sp)])
            yj = []
            for j, xj in enumerate(Yj):
                if not np.isnan(xj[0]):
                    comps = {comp: Yj[j, i] for i, comp in enumerate(flash.components[:-1])}
                    data = res_at_state.sel(comps, method='nearest')
                    value = eval("data." + prop_name + ".values")
                    value = value[eos_idx[j]] if len(flash.eos.keys()) > 1 else value
                else:
                    value = np.nan
                yj.append(np.float64(value))

            # Plot phase compositions xij at feed composition z
            plot.draw_point(X=Yj[:, 0], Y=yj, colours='g')

        plot.add_attributes(suptitle=title, ax_labels=[comp_str, ax_label], grid=True,
                            legend=(datalabels is not None), legend_loc=legend_loc)
        plot.ax[plot.subplot_idx].set(xlim=[min_z, max_z], ylim=[minY, maxY])

        return plot

    @staticmethod
    def ternary(flash: DARTSFlash, variable_comp_1: int, variable_comp_2: int, dz: float, state: dict = None,
                min_z: list = None, max_z: list = None, plot_1p: bool = True, props: xr.Dataset = None,
                flash_results: xr.Dataset = None, sp_results: xr.Dataset = None, composition_to_plot: list = None,
                prop_name: str = "", title: str = None, cmap: str = 'winter'):
        """
        Method to plot ternary thermodynamic surfaces (e.g., Gibbs energy vs. composition)

        :param flash: DARTSFlash object
        :param state: Dictionary of states to plot surfaces for
        :param variable_comp_idx: Indices of variable components
        :param dz: Composition interval
        :param min_z: Minimum composition for composition variables, will default to 0 for each
        :param max_z: Maximum composition for composition variables, will default to 1 for each
        :param props: xarray.DataArray of properties
        :param flash_results: xarray.Dataset of flash results
        :param sp_results: xarray.Dataset of stationary points results
        :param composition_to_plot: Composition to plot results for
        :param prop_name: Name of property for indexing
        :param title: Title of plot
        :param cmap: plt.Colormap for plotting
        """
        # Determine state specification
        state = state if state is not None else {}
        for var in flash.state_vars:
            state[var] = state[var] if var in state.keys() else eval("flash_results." + var + ".values")
        assert np.all([1 if np.isscalar(arr) else len(arr) == 1 for arr in state.values()]), \
            "Can't specify array for state specifications"

        # Find compositions
        variable_comp_idx = [variable_comp_1, variable_comp_2]
        variable_comps = [flash.components[idx] for idx in variable_comp_idx]
        min_z = [0., 0.] if min_z is None else min_z
        max_z = [1., 1.] if max_z is None else max_z
        x0 = np.arange(min_z[0], max_z[0] + dz * 0.1, dz)
        x1 = np.arange(min_z[1], max_z[1] + dz * 0.1, dz)

        # Slice results at current state
        res_at_state = props.sel(state, method='nearest').transpose(variable_comps[0], variable_comps[1], ...).squeeze()
        ydata = eval("res_at_state." + prop_name + ".values")

        if plot_1p:
            # Create TernaryDiagram object
            from dartsflash.diagram import TernaryDiagram
            nplots = flash.n_phase_types
            plot = TernaryDiagram(ncols=nplots, figsize=(nplots * 5 + 3, 5), dz=dz)

            # Plot Gibbs energy surface of each EoS
            for j in range(flash.n_phase_types):
                data = ydata[..., j] if ydata.ndim > 2 else ydata
                plot.subplot_idx = j
                if np.nanmin(data):
                    plot.draw_surf(X1=x0, X2=x1, data=data, is_float=True, nlevels=10,
                                   colours=cmap, colorbar=True, contour=True, fill_contour=True,
                                   corner_labels=flash.comp_data.comp_labels
                                   )
                # plot.add_attributes(title=eosname)
        else:
            # Create TernaryDiagram object
            from dartsflash.diagram import TernaryDiagram
            plot = TernaryDiagram(ncols=1, figsize=(8, 5), dz=dz)

            # Plot Gibbs energy surface of equilibrium state
            plot.draw_surf(X1=x0, X2=x1, data=ydata, is_float=True, nlevels=10,
                           colours=cmap, colorbar=True, contour=True, fill_contour=True,
                           corner_labels=flash.comp_data.comp_labels
                           )

        # Plot flash results at specified composition
        if flash_results is not None:
            assert composition_to_plot is not None, "Please provide composition to plot equilibrium phases for"

            # Plot phase compositions xij at feed composition z
            comps = {comp: composition_to_plot[i] for i, comp in enumerate(flash.components[:-1])}
            # plot.draw_compositions(compositions=composition_to_plot, colours='k')

            # Find flash results at P,T,z
            flash_at_ptz = flash_results.sel({**state, **comps}, method='nearest').squeeze()
            X = flash_at_ptz.X.values
            Xj = [X[jj * flash.ns:(jj + 1) * flash.ns] for jj in range(flash.np_max)]

            # Plot phase compositions
            if flash_at_ptz.np.values > 1:
                eos_idx = flash_at_ptz.eos_idx.values
                roots = flash_at_ptz.root_type.values
                axes = [eos_idx[jj] + (1 if roots[jj] == 0 else 0) for jj in range(flash.np_max)]
                plot.draw_compositions(compositions=Xj, axes=axes,
                                       colours='r', connect_compositions=True)
            else:
                # For single phase conditions, skip
                pass

        # Plot stationary points from stability analysis
        if sp_results is not None:
            assert composition_to_plot is not None, "Please provide composition to plot stationary points for"

            # Slice results at current state
            comps = {comp: composition_to_plot[i] for i, comp in enumerate(flash.components[:-1])}

            # Find stationary points at P,T,z
            sp_at_ptz = sp_results.sel({**state, **comps}, method='nearest').squeeze()
            Y = sp_at_ptz.y.values
            tot_sp = sp_at_ptz.tot_sp.values
            tpd = sp_at_ptz.tpd.values

            Yj = np.array([Y[jj * flash.ns:(jj + 1) * flash.ns] for jj in range(tot_sp)])

            # Plot phase compositions
            if not np.all(np.isnan(tpd)):
                eos_idx = sp_at_ptz.eos_idx.values
                roots = sp_at_ptz.root_type.values
                axes = [eos_idx[jj] + (1 if roots[jj] == 0 else 0) for jj in range(tot_sp)]

                plot.draw_compositions(compositions=Yj, axes=axes,
                                       colours='g', connect_compositions=False)
            else:
                # For single phase conditions, skip
                pass

        plot.add_attributes(suptitle=title)

        return plot


class PlotFlash:
    """
    Class with methods for plotting flash results
    """
    @staticmethod
    def solubility(flash: DARTSFlash, flash_results: xr.Dataset, dissolved_comp_idx: int | list, phase_idx: list, x_var: str,
                   state: dict = None, concentrations: list = None, logy: bool = False, xlim: list = None, ylim: list = None,
                   colours: list = None, styles: list = None, labels: list = None, plot_1p: bool = False,
                   legend: bool = True, legend_loc: str = "upper right", sharex: bool = False):
        """
        Method to plot solubility of component i in phase j against x-var (pressure, temperature, ...)

        :param flash: DARTSFlash instance
        :param flash_results: xarray.Dataset
        :param dissolved_comp_idx: (int | list) Component index or list of indices
        :param phase_idx: (int) Solvent phase index
        :param x_var: (str) Variable for x-axis
        :param state: (dict) State specifications, default is None
        :param concentrations: List of concentrations to plot solubility curves
        :param logy: (bool) Logarithmic y-axis
        :param xlim: List of x-axis limits
        :param ylim: List of y-axis limits
        :param colours: (List of) colours
        :param styles: (List of) linestyles
        :param labels: (List of) labels
        :param plot_1p: (bool) Plot data for 1P conditions, default is False
        :param legend: (bool) Switch on/off legend
        :param legend_loc: (str) Location of legend, default is "upper right"
        :param sharex: (bool) Share x-axis with all plots
        """
        # Slice Dataset at current state
        state = state if state is not None else {}
        state["pressure"] = state["pressure"] if "pressure" in state.keys() else flash_results.pressure.values
        state["temperature"] = state["temperature"] if "temperature" in state.keys() else flash_results.temperature.values
        dims_to_squeeze = [dim for dim, size in flash_results.dims.mapping.items()
                           if size == 1 and dim is not x_var and dim not in state.keys()]
        flash_at_state = flash_results.sel(state, method='nearest').squeeze(dim=dims_to_squeeze)

        # Initialize Plot object
        from dartsflash.diagram import Diagram
        dissolved_comp_idx = [dissolved_comp_idx] if not hasattr(dissolved_comp_idx, "__len__") else dissolved_comp_idx
        nplots = len(dissolved_comp_idx)
        plot = Diagram(nrows=nplots, figsize=(8, nplots * 5), sharex=sharex)

        # Loop over components
        for j, idx in enumerate(dissolved_comp_idx):
            plot.subplot_idx = j
            phase_name = flash.flash_params.eos_order[phase_idx]
            dissolved_comp = flash.comp_data.comp_labels[idx]
            comp_idx = phase_idx * flash.ns + idx
            plot.add_attributes(title=dissolved_comp + " solubility in " + phase_name,
                                ax_labels=[("pressure, bar" if x_var == 'pressure' else "temperature, K"),
                                           r"x{}".format(dissolved_comp)])

            if concentrations is not None:
                assert styles is not None, "Please specify styles for plotting of different concentrations"
                for i, concentration in enumerate(concentrations):
                    x_at_state = flash_at_state.isel(concentrations=i, X_array=comp_idx).X.transpose(..., x_var).values
                    x_at_state = np.where(flash_at_state.np.transpose(..., x_var).values > (0 if plot_1p else 1), x_at_state, np.nan)
                    x_at_state = x_at_state.squeeze()

                    # Plot solubility data
                    colour = colours[i] if colours is not None else plot.colours[i]
                    plot.draw_line(X=state[x_var], Y=x_at_state, colours=colour, styles=styles[i], datalabels=labels[i])

            else:
                x_at_state = flash_at_state.isel(X_array=comp_idx).X.transpose(..., x_var).values
                x_at_state = np.where(flash_at_state.np.transpose(..., x_var).values > (0 if plot_1p else 1), x_at_state, np.nan)
                x_at_state = x_at_state.squeeze()

                # Plot solubility data
                plot.draw_line(X=state[x_var], Y=x_at_state, colours=colours, styles=styles, datalabels=labels)

            plot.add_attributes(legend=legend, legend_loc=legend_loc, grid=True)
            plot.set_axes(xlim=xlim, ylim=ylim, logy=logy)

        return plot

    @staticmethod
    def binary(flash: DARTSFlash, flash_results: xr.Dataset, y_var: str, variable_comp_idx: int, dz: float,
               min_z: float = None, max_z: float = None, state: dict = None,
               min_val: float = 0., max_val: float = 1., min_temp: float = None, max_temp: float = None,
               nlevels: int = 11, plot_phase_fractions: bool = False, cmap: str = 'winter'):
        """
        Method to plot binary phase diagram of state specification vs. composition.
        Optional phase boundaries and tielines to connect these compositions.

        :param flash: DARTSFlash object
        :param flash_results: xarray.DataArray
        :param state: State to plot GE surfaces for
        :param variable_comp_idx: Index of variable component
        """
        # Determine state specification
        state = state if state is not None else {}
        for var in flash.state_vars:
            state[var] = state[var] if var in state.keys() else eval("flash_results." + var + ".values")
        assert np.any([1 if np.isscalar(arr) else len(arr) == 1 for arr in state.values()]), \
            "Can't specify array for both state specifications"

        # Determine compositions
        variable_comp = flash.components[variable_comp_idx]
        comp_str = flash.comp_data.comp_labels[variable_comp_idx]
        min_z = 0. if min_z is None else min_z
        max_z = 1. if max_z is None else max_z
        z0 = np.arange(min_z, max_z + dz * 0.1, dz)

        # Slice dataset at current state
        assert y_var in flash.state_vars, "y_var must be consistent with FlashType"
        y = state[y_var]
        min_z = 0. if min_z is None else min_z
        max_z = 1. if max_z is None else max_z
        z0 = np.arange(min_z, max_z + dz * 0.1, dz)

        comps = {comp: flash_results.dims[comp] for i, comp in enumerate(flash.components[:-1])
                 if comp != variable_comp and comp in flash_results.dims}
        results_at_state = flash_results.sel(state, method='nearest').sel(comps, method='nearest').squeeze()
        np_max = int(np.nanmax(results_at_state.np.values))

        # Create Diagram object
        from dartsflash.diagram import Diagram
        nplots = np_max - 1 if plot_phase_fractions else 1
        plot = Diagram(ncols=nplots, figsize=(nplots * 5 + 3, 5))
        plot.add_attributes(ax_labels=[comp_str, flash.get_labels[y_var]],
                            suptitle="Phase diagram for " + flash.mixture_name)

        # Plot temperature
        if flash.flash_type > DARTSFlash.FlashType.PTFlash:
            data = results_at_state.temp.transpose(variable_comp, y_var).values
            data[data <= flash.flash_params.T_min + 1e-2] = flash.flash_params.T_min
            data[data >= flash.flash_params.T_max - 1e-2] = flash.flash_params.T_max
            plot.draw_surf(x=z0, y=y, data=data,
                           min_val=min_temp, max_val=max_temp, nlevels=nlevels, contour=True, fill_contour=True,
                           colours=cmap, colorbar=True, colorbar_title="temperature, K"
                           )

        # Plot flash results at feed composition z
        if plot_phase_fractions:
            # Plot phase fractions for each phase
            for j in range(np_max - 1):
                plot.subplot_idx = j
                data = results_at_state.nu.isel(nu_array=j).transpose(variable_comp, y_var).values
                min_val = np.nanmin(data) if min_val is None else min_val
                max_val = np.nanmax(data) if max_val is None else max_val

                data[data == 0.] = np.nan
                data[data >= 1.] = np.nan

                plot.draw_surf(x=z0, y=y, data=data,
                               is_float=True, min_val=min_val, max_val=max_val, nlevels=nlevels,
                               colours='w', contour=True, fill_contour=False, contour_linestyle=plot.linestyles[j], )
                # plt.clabel(contours, inline=True, fontsize=8)
                plot.add_attributes(subplot_idx=j, title="Phase {}".format(j))
        else:
            # Plot np at feed composition z
            plot.subplot_idx = 0
            phase_state_ids = results_at_state.phase_state_id.transpose(variable_comp, y_var).values

            min_val = np.nanmin(data) if min_val is None else min_val
            max_val = np.nanmax(data) if max_val is None else max_val

            # plot.draw_surf(x=x, y=state["enthalpy"], data=data, min_val=min_val, max_val=max_val,
            #                is_float=False, colours='w', contour=True, fill_contour=False)
            plot.draw_contours(z0, y, phase_state_ids, colours='k' if y_var in ["temperature", "pressure"] else 'w')

            # # Plot equilibrium phases at composition
            # if composition_to_plot is not None:
            #     assert len(composition_to_plot) == flash.ns
            #     comps = {comp: composition_to_plot[i] for i, comp in enumerate(flash.components[:-1])}
            #
            #     X = results_at_state.sel(comps, method='nearest').squeeze().X.values
            #     Xj = [X[j * flash.ns:(j + 1) * flash.ns] for j in range(flash.np_max)]
            #     plot.draw_point(compositions=composition_to_plot, colours='k')
            #     plot.draw_point(compositions=Xj, colours='r', connect_compositions=True)
            # # Plot phase compositions xij at feed composition z
            # for i, yi in enumerate(y):
            #     state = {y_var: yi}
            #     j = 0
            #     while j < len(z0):
            #         # Find flash results at P,T,z
            #         comps = {variable_comp: z0[j]}
            #         results_at_ptz = results_at_state.sel(state, method='nearest').sel(comps, method='nearest').squeeze()
            #
            #         # For single phase conditions, skip
            #         if results_at_ptz.np.values > 1:
            #             Xj = [results_at_ptz.X.values[jj * flash.ns + variable_comp_idx] for jj in range(flash.np_max)]
            #             Y = [yi for jj in range(flash.np_max)]
            #             j = np.where(z0 >= np.nanmax(Xj))[0][0]
            #             plot.draw_point(X=Xj, Y=Y, colours='k')
            #         else:
            #             j += 1
            #             pass

        return plot

    @staticmethod
    def ternary(flash: DARTSFlash, flash_results: xr.Dataset, dz: float, min_z: list = None, max_z: list = None, state: dict = None,
                composition_to_plot: list = None, plot_phase_fractions: bool = False, plot_tielines: bool = False, cmap: str = 'winter'):
        """
        Method to plot ternary phase diagram. The phase diagram is generated by plotting the compositions
        of the equilibrium phases at the specified feed compositions. Optional tielines connect these compositions.

        :param flash: DARTSFlash object
        :param flash_results: xarray.Dataset
        :param dz: float
        :param state: dict
        :param min_z: list
        :param max_z: list
        :param plot_tielines: bool
        """
        # Determine state specification
        state = state if state is not None else {}
        for var in flash.state_vars:
            state[var] = state[var] if var in state.keys() else eval("flash_results." + var + ".values")
        assert np.all([1 if np.isscalar(arr) else len(arr) == 1 for arr in state.values()]), \
            "Can't specify array for state specifications"

        # Slice dataset at current state
        flash_at_pt = flash_results.sel(state, method='nearest').squeeze()
        np_max = int(np.nanmax(flash_at_pt.np.values))

        min_z = [0., 0.] if min_z is None else min_z
        max_z = [1., 1.] if max_z is None else max_z
        z0 = np.arange(min_z[0], max_z[0]+dz*0.1, dz)
        z1 = np.arange(min_z[1], max_z[1]+dz*0.1, dz)

        # Create TernaryDiagram object
        from dartsflash.diagram import TernaryDiagram
        nplots = np_max - 1 if plot_phase_fractions else 1
        plot = TernaryDiagram(ncols=nplots, figsize=(nplots * 6, 5), dz=dz, min_z=min_z, max_z=max_z)
        plot.add_attributes(suptitle="Phase diagram for " + flash.mixture_name + " at P = {} bar and T = {} K"
                            .format(state["pressure"], state["temperature"]))
        plot.triangulation(z0, z1, corner_labels=flash.comp_data.comp_labels)

        if plot_phase_fractions:
            # Plot flash results at feed composition z
            for j in range(np_max - 1):
                plot.subplot_idx = j
                plot.draw_surf(z0, z1, data=flash_at_pt.nu.isel(nu_array=j).values, is_float=True, nlevels=10,
                               colours=cmap, colorbar=True, contour=False, fill_contour=True, min_val=0., max_val=1.,
                               corner_labels=flash.comp_data.comp_labels
                               )
                plot.add_attributes(title="Phase {}".format(j))
            plot.add_attributes(suptitle="Phase fraction for " + flash.mixture_name + " at P = {} bar and T = {} K"
                                .format(state["pressure"], state["temperature"]))
        else:
            # Plot phase state ids at feed composition z
            phase_state_ids = flash_at_pt.phase_state_id.values
            # phase_state_ids[phase_state_ids == 0] = -1
            plot.subplot_idx = 0
            plot.draw_contours(z0, z1, phase_state_ids, colours='k', corner_labels=flash.comp_data.comp_labels,
                               # mask=0,
                               linewidth=0.5)
            # plot.draw_surf(z0, z1, data=phase_state_ids, is_float=False, colours=cmap, colorbar=True,
            #                contour=False, fill_contour=True, min_val=0, max_val=len(flash.flash_params.phase_states_str)-2,
            #                corner_labels=flash.comp_data.comp_labels,
            #                # colorbar_labels=flash.flash_params.phase_states_str,
            #                colorbar_labels=["Aq", "V", "L", "Aq-V", "Aq-L", "V-L", "Aq-V-L"],
            #                )
            # plot.add_attributes(suptitle="Number of phases for " + flash.mixture_name + " at P = {} bar and T = {} K"
            #                     .format(state["pressure"], state["temperature"]))

            # Plot TPD at composition
            if composition_to_plot is not None:
                assert len(composition_to_plot) == flash.ns
                comps = {comp: composition_to_plot[i] for i, comp in enumerate(flash.components[:-1])}

                X = flash_at_pt.sel(comps, method='nearest').squeeze().X.values
                Xj = [X[j * flash.ns:(j + 1) * flash.ns] for j in range(flash.np_max)]
                plot.draw_compositions(compositions=composition_to_plot, colours='k')
                plot.draw_compositions(compositions=Xj, colours='r', connect_compositions=True)

        # Plot phase compositions xij at feed composition z
        comps = {comp: None for comp in flash.components[:-1]}
        for i, zi in enumerate(z0):
            comps[flash.components[0]] = zi
            for j, zj in enumerate(z1):
                comps[flash.components[1]] = zj

                # Find flash results at P,T,z
                flash_at_ptz = flash_at_pt.sel(comps, method='nearest').squeeze()
                X = flash_at_ptz.X.values
                Xj = [X[jj * flash.ns:(jj + 1) * flash.ns] for jj in range(flash.np_max)]

                # For single phase conditions, skip
                if flash_at_ptz.np.values == 3:
                    plot.draw_compositions(compositions=Xj, colours='b', connect_compositions=True)
                elif flash_at_ptz.np.values == 2:
                    plot.draw_compositions(compositions=Xj, colours='r', connect_compositions=plot_tielines)
                else:
                    pass

        return plot

    @staticmethod
    def pt(flash: DARTSFlash, flash_results: xr.Dataset, composition: list = None, state: dict = None,
           plot_phase_fractions: bool = False, min_val: float = 0., max_val: float = 1., nlevels: int = 11,
           critical_point: dict = None, logT: bool = False, logP: bool = False, pt_props: xr.Dataset = None,
           cmap: str = 'winter'):
        """
        Method to plot PT phase diagram at composition z.

        """
        # Slice dataset at current state
        assert np.all([comp not in flash_results.dims for comp in flash.components]) if composition is None else True, \
            "No composition provided, but flash_results dataset contains compositional dimensions"
        comps = {comp: composition[i] for i, comp in enumerate(flash.components[:-1]) if comp in flash_results.dims}
        flash_at_z = flash_results.sel(comps, method='nearest').squeeze()
        np_max = max(int(np.nanmax(flash_at_z.np.values)), 2)
        state = state if state is not None else {"pressure": flash_results.pressure.values,
                                                 "temperature": flash_results.temperature.values}

        # Create Diagram object
        from dartsflash.diagram import Diagram
        nplots = 1
        plot = Diagram(ncols=nplots, figsize=(nplots * 5 + 3, 5))
        plot.add_attributes(suptitle="PT diagram for " + flash.mixture_name,
                            ax_labels=["temperature, K", "pressure, bar"])

        if plot_phase_fractions:
            # Plot flash results at feed composition z
            for j in range(np_max - 1):
                plot.subplot_idx = j
                plot.draw_surf(x=state["temperature"], y=state["pressure"], data=flash_at_z.sel(nu_array=j).nu.T.values,
                               ax_labels=["temperature, K", "pressure, bar"], is_float=True, min_val=min_val, max_val=max_val,
                               colours=cmap, colorbar=True, contour=True, fill_contour=True, nlevels=nlevels, logx=logT, logy=logP)
                plot.add_attributes(title="Phase {}".format(j))
        else:
            # Plot np at feed composition z
            plot.subplot_idx = 0

            # if critical_point is not None:
            #     states_to_draw = {spec: arr[arr <= critical_point[spec]] for spec, arr in state.items()}
            # else:
            #     states_to_draw = state

            phase_state_ids = flash_at_z.phase_state_id.T.values
            if critical_point is not None:
                mask = np.zeros(np.shape(phase_state_ids), dtype=bool)
                mask[state["temperature"] > critical_point["temperature"], :] = True
                mask[:, state["pressure"] > critical_point["pressure"]] = True
                phase_state_ids[mask] = -1

            plot.draw_contours(state["temperature"], state["pressure"], phase_state_ids,
                               colours='w' if pt_props is not None else 'k', mask=-1)

            # plot.draw_surf(x=state["temperature"], y=state["pressure"], data=flash_at_z.phase_state_id.T.values,
            #                ax_labels=["temperature, K", "pressure, bar"], is_float=False,
            #                colours=cmap, colorbar=True, contour=False, fill_contour=True, logx=logT, logy=logP)

        # Plot phase compositions xij at feed composition z
        T_ranges = np.empty((len(state["pressure"]), 2))
        for ii, p in enumerate(state["pressure"]):
            # Slice flash results at P,z
            np_at_pz = flash_at_z.sel({"pressure": p}, method='nearest').squeeze().np.values
            T_ranges[ii, :] = None
            for j, t in enumerate(state["temperature"]):
                if np_at_pz[j] >= 1.:
                    T_ranges[ii, 0] = t
                    break
            for jj, t in enumerate(state["temperature"][j:]):
                if np_at_pz[j + jj] == 1.:
                    T_ranges[ii, 1] = t
                    break
            if T_ranges[ii, 0] == T_ranges[ii, 1]:
                break

        plot.draw_line(np.append(np.append(T_ranges[:, 0], [None]), T_ranges[:, 1]),
                       np.append(np.append(state["pressure"], [None]), state["pressure"]))

        # Draw critical point
        if critical_point is not None:
            plot.draw_point(X=critical_point["temperature"], Y=critical_point["pressure"],
                            colours='w' if pt_props is not None else 'k')

        if logT:
            plot.ax[plot.subplot_idx].set_xscale("log")
        if logP:
            plot.ax[plot.subplot_idx].set_yscale("log")
        return plot

    @staticmethod
    def px(flash: DARTSFlash, flash_results: xr.Dataset, composition: list = None,
           state: dict = None, plot_phase_fractions: bool = True, min_temp: float = None, max_temp: float = None,
           min_val: float = 0., max_val: float = 1., nlevels: int = 11, logP: bool = False, cmap: str = 'winter'):
        # Slice dataset at current state
        assert np.all([comp not in flash_results.dims for comp in flash.components]) if composition is None else True, \
            "No composition provided, but flash_results dataset contains compositional dimensions"
        comps = {comp: composition[i] for i, comp in enumerate(flash.components[:-1]) if comp in flash_results.dims}
        flash_at_z = flash_results.sel(comps, method='nearest').squeeze()
        np_max = max(int(np.nanmax(flash_at_z.np.values)), 2)

        spec2 = flash.state_vars[1]
        state = state if state is not None else {"pressure": flash_results.pressure.values,
                                                 spec2: eval("flash_results." + spec2 + ".values")}

        # Create Diagram object
        from dartsflash.diagram import Diagram
        plot = Diagram(ncols=1, figsize=(8, 5))
        # plot.add_attributes(suptitle="PH-diagram of " + flash.mixture_name)

        # Plot temperature
        data = np.array(flash_at_z.temp.T.values, copy=True)
        data[data <= flash.flash_params.T_min + 1e-2] = flash.flash_params.T_min + 1e-2
        data[data >= flash.flash_params.T_max - 1e-2] = flash.flash_params.T_max - 1e-2
        plot.draw_surf(x=state[spec2], y=state['pressure'], data=data,
                       min_val=min_temp, max_val=max_temp, nlevels=nlevels, contour=True, fill_contour=True,
                       ax_labels=[flash.get_labels[spec2], "pressure, bar"],
                       colours=cmap, colorbar=True, colorbar_title="temperature, K"
                       )

        # Plot flash results at feed composition z
        if plot_phase_fractions:
            # Plot phase fractions for each phase
            for j in range(np_max - 1):
                data = np.array(flash_at_z.nu.isel(nu_array=j).transpose(spec2, "pressure").values, copy=True)
                min_val = np.nanmin(data) if min_val is None else min_val
                max_val = np.nanmax(data) if max_val is None else max_val

                data[data == 0.] = np.nan
                data[data >= 1.] = np.nan

                plot.draw_surf(x=state[spec2], y=state["pressure"], data=data,
                               is_float=True, min_val=min_val, max_val=max_val, nlevels=nlevels,
                               colours='w', contour=True, fill_contour=False, contour_linestyle=plot.linestyles[j],
                               logy=logP)
                # plt.clabel(contours, inline=True, fontsize=8)
        else:
            # Plot np at feed composition z
            plot.subplot_idx = 0
            data = np.array(flash_at_z.np.transpose(spec2, "pressure").values, copy=True)
            min_val = np.nanmin(data) if min_val is None else min_val
            max_val = np.nanmax(data) if max_val is None else max_val

            plot.draw_surf(x=state[spec2], y=state["pressure"], data=data, min_val=min_val, max_val=max_val,
                           is_float=False, colours='w', contour=True, fill_contour=False, logy=logP)

        return plot


class PlotHydrate:
    """
    Class with methods to plot hydrate equilibrium curves
    """
    @staticmethod
    def pt(flash: DARTSFlash, flash_results: xr.Dataset, composition: list = None, state: dict = None,
           concentrations: list = None, labels: list = None, ref_t: list = None, ref_p: list = None,
           xlim: list = None, ylim: list = None, logx: bool = False, logy: bool = False, legend_loc: str = 'upper right'):
        # Slice Dataset at state and composition
        state = state if state is not None else {"pressure": flash_results.pressure.values,
                                                 "temperature": flash_results.temperature.values}
        results_at_state = flash_results.sel(state, method='nearest').squeeze()

        # Loop over compositions
        assert np.all([comp not in flash_results.dims for comp in flash.components]) if composition is None else True, \
            "No composition provided, but flash_results dataset contains compositional dimensions"
        comps = {comp: composition[i] for i, comp in enumerate(flash.components[:-1]) if comp in flash_results.dims}
        results_at_comp = results_at_state.sel(comps, method='nearest').squeeze()

        # Initialize Plot object
        from dartsflash.diagram import Diagram
        plot = Diagram(figsize=(8, 5))
        plot.add_attributes(#suptitle=flash.mixture_name + "-hydrate",
                            ax_labels=["temperature, K", "pressure, bar"])

        # If multiple salt concentrations have been specified, concatenate
        if not results_at_comp.pressure.values:
            if concentrations is not None:
                X_at_state = [results_at_comp.isel(concentrations=i).pres.values
                              for i, _ in enumerate(concentrations)]
            else:
                X_at_state = results_at_comp.pres.values
        else:
            if concentrations is not None:
                X_at_state = [results_at_comp.isel(concentrations=i).temp.T.values
                              for i, _ in enumerate(concentrations)]
            else:
                X_at_state = results_at_comp.temp.values

        # Plot equilibrium curve data
        if not results_at_comp.pressure.values:
            pressure = X_at_state
            temperature = results_at_comp.temperature.values
        else:
            pressure = results_at_comp.pressure.values
            temperature = X_at_state

        plot.draw_line(X=temperature, Y=pressure, datalabels=labels)
        plot.set_axes(xlim=xlim, ylim=ylim, logx=logx, logy=logy)
        if ref_t is not None or ref_p is not None:
            plot.draw_point(X=ref_t, Y=ref_p)
        plot.add_attributes(legend=labels is not None, legend_loc=legend_loc, grid=True)

        return plot

    @staticmethod
    def binary(flash: DARTSFlash, flash_results: xr.Dataset, variable_comp_idx: int, dz: float,
               min_z: float = None, max_z: float = None, state: dict = None, logy: bool = False):
        """
        Method to plot hydrate equilibrium curves for binary gas mixtures

        :param flash: DARTSFlash object
        :param flash_results: xarray.DataArray
        :param state: State to plot GE surfaces for
        :param variable_comp_idx: Index of variable component
        """
        variable_comp = flash.components[variable_comp_idx]
        comp_str = flash.comp_data.comp_labels[variable_comp_idx]

        # Slice dataset at current state
        px = state["pressure"] is None
        y_var = ("pressure" if px else "temperature")
        y = state[y_var]
        min_z = 0. if min_z is None else min_z
        max_z = 1. if max_z is None else max_z
        z0 = np.arange(min_z, max_z + dz * 0.1, dz)

        comps = {comp: flash_results.dims[comp] for i, comp in enumerate(flash.components[:-1])
                 if comp != variable_comp and comp in flash_results.dims}
        results_at_state = flash_results.sel(state, method='nearest').sel(comps, method='nearest').squeeze()

        # Create TernaryDiagram object
        from dartsflash.diagram import Diagram
        nplots = 1
        plot = Diagram(ncols=nplots, figsize=(nplots * 5 + 3, 5))
        plot.add_attributes(ax_labels=[comp_str, "pressure, bar" if px else "temperature, K"],
                            suptitle="Hydrate equilibrium " + y_var + " for " + flash.mixture_name)

        # Plot phase compositions xij at feed composition z
        if px:
            labels = ["T = {} K".format(t) for t in state["temperature"]]
            data = results_at_state.pres.transpose("temperature", variable_comp).values
        else:
            labels = ["P = {} bar".format(p) for p in state["pressure"]]
            data = results_at_state.temp.transpose("pressure", variable_comp).values

        plot.draw_line(X=z0, Y=data, )
        plot.set_axes(logy=logy, xlim=[min_z, max_z])

        return plot

    @staticmethod
    def ternary(flash: DARTSFlash, flash_results: xr.Dataset, dz: float,
                min_z: list = None, max_z: list = None, state: dict = None,
                composition_to_plot: list = None, plot_phase_fractions: bool = False, cmap: str = 'winter'):
        pass
