import sys
import os
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from l0n0lc import jit, 映射类型, int32, 取址
from l0n0lc.基础映射 import _指针类型基类
if not os.path.exists('l0n0lcoutput'):
    os.mkdir('l0n0lcoutput')

with open('l0n0lcoutput/Addr.h', 'w') as fp:
    fp.write('''
#pragma once
struct Addr{
    Addr(){}
    int x = 123;
    int y = 123;
    int get_x(){
        return this->x;
    }
    int get_y(){
        return this->x;
    }
};             
''')


with open('l0n0lcoutput/Home.h', 'w') as fp:
    fp.write('''
#pragma once
#include "Addr.h"             
struct Home{
    Home(){}
    int area = 123;
    Addr addr;
    int get_area(){
        return this->area;
    }
    Addr get_addr(){return this->addr;}             
};             
''')



with open('l0n0lcoutput/Person.h', 'w') as fp:
    fp.write('''
#pragma once
#include "Home.h"             
struct Person{
    Person(){}
    int age = 123;
    Home home;             
    int get_age(){
        return this->age;
    }
    Home get_home(){
        return this->home;
    }
    Home* get_home_ptr(){
        return &(this->home);
    }             
};             
''')


@映射类型('Addr', ['"Addr.h"'])
class Addr:
    x:int32 = int32(0)
    y:int32 = int32(0)

    def get_x(self)->int32:
        return int32(0)    
    
    def get_y(self)->int32:
        return int32(0)    

@映射类型('Home', ['"Home.h"'])
class Home:
    area:int32 = int32(0)
    addr: Addr
    def get_area(self)->int32:
        return int32(0)
    def get_addr(self)->Addr:
        return self.addr

@映射类型('Home*', ['"Home.h"'])
class HomePtr(_指针类型基类, Home):
    _值类型 = Home

@映射类型('Person', ['"Person.h"'])
class Person:
    age:int32 = int32(0)
    home:Home
    def get_age(self)->int32:
        return int32(0)
    def get_home(self)->Home:
        return Home()
    def get_home_ptr(self)->HomePtr:
        return HomePtr(取址(self.home))

@映射类型('Person*', ['"Person.h"'])
class PersonPtr(_指针类型基类, Person):
    _值类型 = Person

@jit(总是重编=True)
def getPtr()->'PersonPtr':
    return PersonPtr(0)

@jit(总是重编=True)
def test_person():
    p = Person()
    pPtr = getPtr()
    p.age = int32(12)
    age = p.get_age()
    age2 = p.age
    area = p.home.get_area()
    area2 = p.get_home().get_area()
    area3 = p.get_home().area
    x = p.get_home().addr.get_x()
    x2 = p.get_home().addr.x
    x3 = p.get_home_ptr().addr.x
    x4 = p.get_home_ptr().get_addr().x
    x5 = p.get_home_ptr().get_addr().get_x()
    y = p.get_home().get_addr().get_y()
    y2 = p.get_home().get_addr().get_y()
    print(age, age2)

test_person()


