"""测试 include_paths 功能"""
import unittest
import os
from l0n0lc.工具 import 映射函数, 映射函数到, 映射类型, 全局上下文, Cpp函数映射, Cpp类型映射


class TestIncludePaths(unittest.TestCase):
    """测试 include_paths 参数"""

    def setUp(self):
        """每个测试前保存状态"""
        # 保存当前状态
        self._saved_function_mappings = dict(全局上下文.函数映射表)
        self._saved_type_mappings = dict(全局上下文.类型映射表)
        self._saved_reverse_mappings = dict(全局上下文.反向类型映射表)

    def tearDown(self):
        """每个测试后恢复状态"""
        # 恢复之前的状态
        全局上下文.函数映射表.clear()
        全局上下文.函数映射表.update(self._saved_function_mappings)
        全局上下文.类型映射表.clear()
        全局上下文.类型映射表.update(self._saved_type_mappings)
        全局上下文.反向类型映射表.clear()
        全局上下文.反向类型映射表.update(self._saved_reverse_mappings)

    def test_映射函数_include_paths(self):
        """测试映射函数装饰器的 include_paths 参数"""
        def dummy_func():
            pass

        @映射函数(
            dummy_func,
            包含头文件=['<test.h>'],
            库=['testlib'],
            库目录=['/usr/local/lib'],
            include_paths=['/usr/local/include', '/opt/include']
        )
        def mapped_func():
            pass

        # 验证映射已注册
        self.assertIn(dummy_func, 全局上下文.函数映射表)

        # 验证映射信息
        mapping = 全局上下文.函数映射表[dummy_func]
        self.assertEqual(mapping.包含头文件, ['<test.h>'])
        self.assertEqual(mapping.库, ['testlib'])
        self.assertEqual(mapping.库目录, ['/usr/local/lib'])
        self.assertEqual(mapping.包含目录, ['/usr/local/include', '/opt/include'])

    def test_映射函数到_include_paths(self):
        """测试映射函数到装饰器的 include_paths 参数"""
        @映射函数到(
            cpp='test_func({arg})',
            headers=['<test.h>'],
            libraries=['testlib'],
            library_dirs=['/usr/local/lib'],
            include_paths=['/usr/local/include', '/opt/include']
        )
        def my_func(arg: int) -> int:
            pass

        # 验证映射已注册
        self.assertIn(my_func, 全局上下文.函数映射表)

        # 验证映射信息
        mapping = 全局上下文.函数映射表[my_func]
        self.assertEqual(mapping.包含头文件, ['<test.h>'])
        self.assertEqual(mapping.库, ['testlib'])
        self.assertEqual(mapping.库目录, ['/usr/local/lib'])
        self.assertEqual(mapping.包含目录, ['/usr/local/include', '/opt/include'])

    def test_映射类型_include_paths(self):
        """测试映射类型装饰器的 include_paths 参数"""
        class TestType:
            pass

        @映射类型(
            TestType,
            包含头文件=['<test.h>'],
            库=['testlib'],
            库目录=['/usr/local/lib'],
            include_paths=['/usr/local/include', '/opt/include']
        )
        class MappedType:
            pass

        # 验证映射已注册
        self.assertIn(MappedType, 全局上下文.类型映射表)

        # 验证映射信息
        mapping = 全局上下文.类型映射表[MappedType]
        self.assertEqual(mapping.包含头文件, ['<test.h>'])
        self.assertEqual(mapping.库, ['testlib'])
        self.assertEqual(mapping.库目录, ['/usr/local/lib'])
        self.assertEqual(mapping.包含目录, ['/usr/local/include', '/opt/include'])

    def test_包含目录默认为空列表(self):
        """测试不提供 include_paths 时默认为空列表"""
        def dummy_func():
            pass

        @映射函数(dummy_func)
        def mapped_func():
            pass

        mapping = 全局上下文.函数映射表[dummy_func]
        self.assertEqual(mapping.包含目录, [])

    def test_Cpp函数映射_包含目录(self):
        """测试 Cpp函数映射 类的包含目录字段"""
        mapping = Cpp函数映射(
            目标函数='test_func',
            包含头文件=['<test.h>'],
            库=['testlib'],
            库目录=['/usr/local/lib'],
            包含目录=['/usr/local/include']
        )

        self.assertEqual(mapping.目标函数, 'test_func')
        self.assertEqual(mapping.包含头文件, ['<test.h>'])
        self.assertEqual(mapping.库, ['testlib'])
        self.assertEqual(mapping.库目录, ['/usr/local/lib'])
        self.assertEqual(mapping.包含目录, ['/usr/local/include'])

    def test_Cpp类型映射_包含目录(self):
        """测试 Cpp类型映射 类的包含目录字段"""
        mapping = Cpp类型映射(
            目标类型='TestType',
            包含头文件=['<test.h>'],
            库=['testlib'],
            库目录=['/usr/local/lib'],
            包含目录=['/usr/local/include']
        )

        self.assertEqual(mapping.目标类型, 'TestType')
        self.assertEqual(mapping.包含头文件, ['<test.h>'])
        self.assertEqual(mapping.库, ['testlib'])
        self.assertEqual(mapping.库目录, ['/usr/local/lib'])
        self.assertEqual(mapping.包含目录, ['/usr/local/include'])


if __name__ == '__main__':
    unittest.main()
