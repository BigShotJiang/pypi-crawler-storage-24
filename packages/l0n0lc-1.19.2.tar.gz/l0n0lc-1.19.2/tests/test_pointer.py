import sys
import os
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from l0n0lc import *

@jit(总是重编=True)
def test_pointer():
    p = float32_ptr(0)


test_pointer()