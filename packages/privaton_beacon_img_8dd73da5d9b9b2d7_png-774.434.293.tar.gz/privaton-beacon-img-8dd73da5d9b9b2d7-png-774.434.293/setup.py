from setuptools import setup
setup(name='privaton-beacon-img-8dd73da5d9b9b2d7-png', version='774.434.293', py_modules=['data'])
