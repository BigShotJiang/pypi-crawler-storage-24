from dataclasses import dataclass
import math
from matplotlib import pyplot as plt
import numpy as np
import pandas as pd

from .broker import Order, OrderSide
from .strategy import Strategy
from .enums import CommissionType
import copy
import itertools
from typing import Callable, Any
from tqdm import tqdm
import concurrent.futures
import pickle
import os
import gc
from enum import Enum


class DataSplitMode(Enum):
    """Enumeration for data split modes in optimization."""
    TRAIN = "train"
    VALIDATE = "validate"
    TEST = "test"


@dataclass
class TrainValidateTestSplit:
    """
    Container for train/validate/test data splits.
    
    This class holds the split configuration and indices for dividing
    historical data into training, validation, and test sets for
    machine learning-style optimization workflows.
    
    Attributes:
        train_start (int): Starting index for training data.
        train_end (int): Ending index for training data.
        validate_start (int): Starting index for validation data.
        validate_end (int): Ending index for validation data.
        test_start (int): Starting index for test data.
        test_end (int): Ending index for test data.
        train_ratio (float): Ratio of data used for training.
        validate_ratio (float): Ratio of data used for validation.
        test_ratio (float): Ratio of data used for testing.
    """
    train_start: int
    train_end: int
    validate_start: int
    validate_end: int
    test_start: int
    test_end: int
    train_ratio: float = 0.6
    validate_ratio: float = 0.2
    test_ratio: float = 0.2
    
    def __post_init__(self):
        """Validate split ratios sum to 1.0."""
        total = self.train_ratio + self.validate_ratio + self.test_ratio
        if not np.isclose(total, 1.0):
            raise ValueError(
                f"Split ratios must sum to 1.0, got {total:.3f}"
            )


def create_train_validate_test_split(
    data_length: int,
    train_ratio: float = 0.6,
    validate_ratio: float = 0.2,
    test_ratio: float = 0.2
) -> TrainValidateTestSplit:
    """
    Create indices for train/validate/test split.
    
    This function divides the data indices into three sets for ML-style
    optimization: training (parameter fitting), validation (hyperparameter
    selection), and testing (final evaluation).
    
    Args:
        data_length (int): Total number of data points.
        train_ratio (float, optional): Fraction of data for training.
            Defaults to 0.6 (60%).
        validate_ratio (float, optional): Fraction of data for validation.
            Defaults to 0.2 (20%).
        test_ratio (float, optional): Fraction of data for testing.
            Defaults to 0.2 (20%).
            
    Returns:
        TrainValidateTestSplit: Object containing start/end indices for
            each split.
            
    Raises:
        ValueError: If ratios don't sum to 1.0 or are invalid.
        
    Example:
        >>> split = create_train_validate_test_split(1000, 0.6, 0.2, 0.2)
        >>> print(f"Train: {split.train_start}-{split.train_end}")
        >>> print(f"Validate: {split.validate_start}-{split.validate_end}")
        >>> print(f"Test: {split.test_start}-{split.test_end}")
    """
    if not np.isclose(train_ratio + validate_ratio + test_ratio, 1.0):
        raise ValueError("Split ratios must sum to 1.0")
    
    if train_ratio <= 0 or validate_ratio <= 0 or test_ratio <= 0:
        raise ValueError("All split ratios must be positive")
    
    train_end = int(data_length * train_ratio)
    validate_end = int(data_length * (train_ratio + validate_ratio))
    
    return TrainValidateTestSplit(
        train_start=0,
        train_end=train_end,
        validate_start=train_end,
        validate_end=validate_end,
        test_start=validate_end,
        test_end=data_length,
        train_ratio=train_ratio,
        validate_ratio=validate_ratio,
        test_ratio=test_ratio
    )


@dataclass
class OptimizationResult:
    """
    Container for optimization results with train/validate/test splits.
    
    This class holds the complete results of an optimization run that
    includes evaluation on all three data splits, enabling proper
    model selection and generalization assessment.
    
    Attributes:
        best_params (dict): Best parameter values found.
        train_report: Backtest report for training data.
        validate_report: Backtest report for validation data.
        test_report: Backtest report for test data.
        train_metrics (dict): Computed metrics for training performance.
        validate_metrics (dict): Computed metrics for validation performance.
        test_metrics (dict): Computed metrics for test performance.
        all_results (pd.DataFrame): DataFrame with all parameter combinations
            and their metrics for each split.
    """
    best_params: dict
    train_report: Any
    validate_report: Any
    test_report: Any
    train_metrics: dict
    validate_metrics: dict
    test_metrics: dict
    all_results: pd.DataFrame

def max_drawdown(equity: pd.Series) -> float:
    """
    Calculate the maximum drawdown of an equity curve.
    
    The maximum drawdown represents the largest peak-to-trough decline
    in the equity curve, expressed as a positive percentage.
    
    Args:
        equity (pd.Series): Time series of equity values.
        
    Returns:
        float: Maximum drawdown as a positive percentage (e.g., 0.15 for 15%).
        
    Example:
        >>> equity = pd.Series([100, 110, 95, 105, 90])  
        >>> max_drawdown(equity)  
        0.18181818181818182  # ~18.18% drawdown
    """
    running_max = equity.cummax()
    drawdown = (equity - running_max) / running_max
    max_dd = drawdown.min()
    return float(abs(max_dd))  # return as positive percentage

def _infer_periods_per_year(index: pd.Index, default: int = 252 * 24 * 60) -> int:
    """
    Infer the number of trading periods per year from a datetime index.
    
    This function analyzes the time differences in the index to determine
    the appropriate number of periods per year for annualized calculations.
    Falls back to minute-level trading (252 trading days * 24 hours * 60 minutes)
    if the index cannot be analyzed or contains insufficient data.
    
    Args:
        index (pd.Index): DatetimeIndex containing timestamps.
        default (int, optional): Default periods per year for minute trading.
            Defaults to 252 * 24 * 60 (minute-level data).
            
    Returns:
        int: Estimated number of trading periods per year.
        
    Example:
        >>> dates = pd.date_range('2020-01-01', periods=100, freq='D')  
        >>> _infer_periods_per_year(dates)  
        252  # Daily trading periods
    """
    # Simple inference; falls back to minute trading year if uncertain
    if not isinstance(index, pd.DatetimeIndex) or len(index) < 3:
        return default
    dt = np.diff(index.values).astype("timedelta64[s]").astype(float)
    if not np.isfinite(dt).any():
        return default
    med_sec = np.median(dt[dt > 0])
    if not np.isfinite(med_sec) or med_sec <= 0:
        return default
    periods_per_day = 86400.0 / med_sec
    # Assume 252 trading days/year
    return int(round(252 * periods_per_day))

def _worker_init(pickled_strategy: bytes, cash: float, commision: float,
                 commision_type, lot_size: int):
    """
    Initializer for worker processes in parallel optimization.
    
    This function stores a pickled strategy and backtest configuration
    in module globals so each worker process can reuse them for
    parallel parameter optimization.
    
    Args:
        pickled_strategy (bytes): Serialized strategy instance.
        cash (float): Initial cash amount for backtesting.
        commision (float): Commission rate for trades.
        commision_type: Type of commission calculation (CommissionType enum).
        lot_size (int): Size of trading lots.
        
    Note:
        This function is designed to be called by worker processes
        during parallel optimization and should not be used directly.
    """
    global _WORKER_PICKLED_STRAT, _WORKER_BT_CONFIG
    _WORKER_PICKLED_STRAT = pickled_strategy
    _WORKER_BT_CONFIG = {
        "cash": cash,
        "commision": commision,
        "commision_type": commision_type,
        "lot_size": lot_size,
    }

def _worker_eval(param_items):
    """
    Worker evaluation function for parallel parameter optimization.
    
    This function runs in worker processes to evaluate a single
    parameter combination and return performance metrics.
    
    Args:
        param_items: Sequence of (key, value) pairs (tuple) to reconstruct dict.
                    Each tuple represents a parameter name and its value.
                    
    Returns:
        dict: Dictionary containing metrics for the evaluated parameters:
            - 'params': Dictionary of parameter values used
            - 'final_cash': Final cash amount after backtest
            - 'total_return': Total return as decimal (e.g., 0.15 for 15%)
            - 'sharpe': Sharpe ratio (or NaN if invalid)
            - 'max_drawdown': Maximum drawdown as decimal
            - 'trades': Number of trades executed
            
    Note:
        This function is designed for use in worker processes during
        parallel optimization and should not be called directly.
    """
    global _WORKER_PICKLED_STRAT, _WORKER_BT_CONFIG
    # Reconstruct params dict
    params = dict(param_items)

    # Unpickle a fresh strategy instance for this task
    strat = pickle.loads(_WORKER_PICKLED_STRAT)

    # Apply param overrides
    for k, v in params.items():
        setattr(strat, k, v)

    # Run backtest locally in worker (no progress bar)
    bt = SimpleBacktester(
        strat,
        cash=_WORKER_BT_CONFIG["cash"],
        commission=_WORKER_BT_CONFIG["commision"],
        commission_type=_WORKER_BT_CONFIG["commision_type"],
        lot_size=_WORKER_BT_CONFIG["lot_size"],
    )
    report = bt.run(progress_bar=False)

    # Compute metrics (same logic as before)
    equity = report.PnlRecord.astype(float)
    returns = equity.pct_change().dropna()

    annual_rf = 0.04
    rf_per_period = annual_rf / report.periods_per_year

    if len(returns) < 2 or returns.std(ddof=1) == 0:
        sharpe = float("nan")
    else:
        excess = returns - rf_per_period
        mean = excess.mean()
        vol = excess.std(ddof=1)
        sharpe = float((mean / vol) * (report.periods_per_year ** 0.5))

    running_max = equity.cummax()
    drawdown = ((equity - running_max) / running_max).min()
    mdd = float(abs(drawdown))

    tot_return = float(equity.iloc[-1] / equity.iloc[0] - 1.0)

    # Keep worker returned payload small — don't send large objects back.
    result = {
        "params": params,
        "final_cash": report.final_cash,
        "total_return": tot_return,
        "sharpe": sharpe,
        "max_drawdown": mdd,
        "trades": len(report.orders),
    }

    # Cleanup references to free memory inside worker
    del strat, bt, report, equity, returns
    gc.collect()

    return result

def _compute_backtest_metrics(report: "BacktestReport") -> dict[str, Any]:
    equity = report.PnlRecord.astype(float)
    returns = equity.pct_change().dropna()

    annual_rf = report.annual_rf
    rf_per_period = annual_rf / report.periods_per_year

    if len(returns) < 2 or returns.std(ddof=1) == 0:
        sharpe = float("nan")
    else:
        excess = returns - rf_per_period
        mean = excess.mean()
        vol = excess.std(ddof=1)
        sharpe = float((mean / vol) * (report.periods_per_year ** 0.5))

    running_max = equity.cummax()
    drawdown = ((equity - running_max) / running_max).min()
    mdd = float(abs(drawdown))

    tot_return = float(equity.iloc[-1] / equity.iloc[0] - 1.0)

    return {
        "final_cash": report.final_cash,
        "total_return": tot_return,
        "sharpe": sharpe,
        "max_drawdown": mdd,
        "trades": len(report.orders),
    }

def _extract_metric_value(report: "BacktestReport", metric: str) -> Any:
    value = getattr(report, metric, None)
    if callable(value):
        value = value()
    return value

def _risk_tolerance_passes(report: "BacktestReport", risk_tolerance: dict[str, float] | None) -> bool:
    if not risk_tolerance:
        return True

    metrics = _compute_backtest_metrics(report)
    for metric, max_value in risk_tolerance.items():
        if max_value is None:
            continue
        current_value = metrics.get(metric, _extract_metric_value(report, metric))
        if current_value is None:
            raise AttributeError(f"BacktestReport does not expose metric '{metric}'")
        if not np.isfinite(float(current_value)):
            return False
        if float(current_value) > float(max_value):
            return False

    return True

@dataclass
class BacktestReport:
    """
    Container for backtest results and performance metrics.
    
    This class encapsulates the complete results of a backtest run,
    including P&L records, orders executed, and calculated performance
    metrics such as Sharpe ratio and maximum drawdown.
    
    Attributes:
        starting_cash (np.float64): Initial cash amount at start of backtest.
        final_cash (np.float64): Final cash amount at end of backtest.
        PnlRecord (pd.Series): Time series of P&L values throughout the backtest.
        orders (list[Order]): List of all orders executed during the backtest.
    """
    starting_cash: np.float64
    final_cash: np.float64
    PnlRecord: pd.Series
    orders: list[Order]
    tradeRecord: list[np.float64]

    @property
    def annual_rf(self):
        return 0.04

    @property
    def periods_per_year(self):
        """
        Calculate the number of trading periods per year.
        
        This property infers the appropriate number of periods per year
        from the P&L record index, useful for annualized calculations.
        
        Returns:
            int: Number of trading periods per year (e.g., 252 for daily data).
        """
        return _infer_periods_per_year(self.PnlRecord.astype(float).index, 252 * 24 * 60)
    
    @property
    def total_return(self):
        equity = self.PnlRecord.astype(float)
        tot_return = float(equity.iloc[-1] / equity.iloc[0] - 1.0)
        return tot_return
    
    @property
    def kelly_criterion(self):
        winning = 0
        losing = 0
        total_wins = 0
        total_losses = 0
        for trade in self.tradeRecord:
            if trade > 0:
                total_wins += abs(trade)
                winning += 1
            elif trade < 0:
                total_losses += abs(trade)
                losing += 1
        if winning + losing == 0:
            return 0.0
        if winning == 0:
            return 0.0
        if losing == 0:
            return 1.0
        W = winning / (winning + losing)
        avg_win = total_wins / winning
        avg_loss = total_losses / losing
        if avg_loss == 0:
            return 0.0
        R = avg_win / avg_loss
        if R == 0:
            return 0.0
        kelly = W - (1 - W) / R
        return kelly

    def plot(self, figsize: tuple = (10, 5)) -> None:
        """
        Plot the equity curve and drawdown charts.
        
        Creates a two-panel plot showing:
        1. The equity curve over time
        2. The drawdown curve as a percentage
        
        Args:
            figsize (tuple, optional): Figure size as (width, height) in inches.
                Defaults to (10, 5).
                
        Note:
            This method uses matplotlib to display the plots and requires
            an interactive environment to show the figures.
        """
        equity = self.PnlRecord.astype(float)
        running_max = equity.cummax()
        drawdown = (equity - running_max) / running_max

        fig, ax = plt.subplots(
            2, figsize=figsize, sharex=True
        )

        ax_eq, ax_dd = ax

        ax_eq.plot(equity.index, equity.values, label="Equity", color="tab:blue")
        ax_eq.set_ylabel("Equity Value")
        ax_eq.set_title("Equity Curve")
        ax_eq.legend()
        ax_eq.grid(alpha=0.3)

        ax_dd.fill_between(
            drawdown.index,
            drawdown.values,
            color="tab:red",
            alpha=0.3,
            label="Drawdown",
        )
        ax_dd.set_ylabel("Drawdown")
        ax_dd.set_xlabel("Date")
        ax_dd.legend()
        ax_dd.grid(alpha=0.3)

        plt.tight_layout()
        plt.show()

    def __str__(self) -> str:
        """
        Generate a formatted string summary of backtest results.
        
        Returns a human-readable string containing key performance
        metrics including total return, Sharpe ratio with confidence
        intervals, maximum drawdown, and total number of trades.
        
        Returns:
            str: Formatted string with backtest summary statistics.
        """
        equity = self.PnlRecord.astype(float)
        returns = equity.pct_change().dropna()

        # Risk-free per period from an annual rate
        rf_per_period = self.annual_rf / self.periods_per_year

        if len(returns) < 2 or returns.std(ddof=1) == 0:
            sharpe = np.nan
            lo = np.nan
            hi = np.nan
        else:
            excess = returns - rf_per_period
            mean = excess.mean()
            vol = excess.std(ddof=1)
            sharpe = (mean / vol) * np.sqrt(self.periods_per_year)

            # Standard error of Sharpe (i.i.d. normal approx)
            n = len(excess)
            se = np.sqrt((1 + 0.5 * sharpe**2) / n)
            z = 1.96  # 95% CI
            lo = sharpe - z * se
            hi = sharpe + z * se

        # Max drawdown on equity curve
        running_max = equity.cummax()
        drawdown = ((equity - running_max) / running_max).min()
        mdd = float(abs(drawdown))

        tot_return = float(equity.iloc[-1] / equity.iloc[0] - 1.0)
        annualized_return = float((1.0 + tot_return) ** (self.periods_per_year / max(len(returns), 1)) - 1.0)
        tot_orders = len(self.orders)

        return (
            f"Starting Cash: ${self.starting_cash:,.2f}\n"
            f"Final Cash: ${self.final_cash:,.2f}\n"
            f"Total Return: {tot_return:,.2%}\n"
            f"Annualized Return: {annualized_return:,.2%}\n"
            f"Sharpe Ratio: {sharpe:.2f}" if np.isfinite(sharpe) else
            f"Sharpe Ratio: nan"
        ) + (
            f"\nSharpe Confidence Interval: [{lo:.4f}, {hi:.4f}]"
            if np.isfinite(sharpe) else "\nSharpe Confidence Interval: [nan, nan]"
        ) + (
            f"\nMax Drawdown: {mdd:.2%}\n"
            f"Kelly Fraction: {self.kelly_criterion:.3}\n"
            f"Total Trades: {tot_orders:,}"
        )

class SimpleBacktester():
    """
    Simple backtester for executing trading strategies on historical data.
    
    This class provides functionality to run backtests on trading strategies,
    calculate performance metrics, and perform parameter optimization through
    grid search (both sequential and parallel).
    
    The backtester simulates realistic trading conditions including:
    - Order execution with market and limit orders
    - Commission calculations
    - Position management
    - Margin calls
    - P&L tracking
    
    Example:
        >>> from quantex import SimpleBacktester, CSVDataSource  
        >>> # Create strategy and data source  
        >>> source = CSVDataSource("data.csv")  
        >>> # strategy = MyStrategy()  # Your custom strategy  
        >>> bt = SimpleBacktester(strategy, cash=10000)  
        >>> report = bt.run()  
        >>> print(report)  
    """
    def __init__(self, 
                 strategy: Strategy,
                cash: float = 10_000, 
                commission: float = 0.002, 
                commission_type: CommissionType = CommissionType.PERCENTAGE,
                lot_size: int = 1,
                margin_call: float = 0.5 ## 50% of the cash lost
                ):
        """
        Initialize the backtester with strategy and configuration parameters.
        
        Args:
            strategy (Strategy): Trading strategy to backtest. Must implement
                the Strategy interface with init() and next() methods.
            cash (float, optional): Initial cash amount. Defaults to 10,000.
            commission (float, optional): Commission rate per trade. Defaults to 0.002 (0.2%).
            commission_type (CommissionType, optional): Type of commission calculation.
                Can be CommissionType.PERCENTAGE or CommissionType.CASH.
                Defaults to CommissionType.PERCENTAGE.
            lot_size (int, optional): Size of trading lots. Defaults to 1.
            margin_call (float, optional): Margin call threshold as fraction of
                cash value. Defaults to 0.5 (50%).
                
        Raises:
            ValueError: If strategy is None or commission rate is negative.
        """
        self.strategy = copy.deepcopy(strategy)
        self.cash = cash
        self.commission = commission
        self.commission_type = commission_type
        self.lot_size = lot_size
        self.margin_call = margin_call
        source = self.strategy.positions[list(self.strategy.positions.keys())[0]].source
        self.PnLRecord = np.zeros(len(source.data['Close']), dtype=np.float64)

    def _reset_runtime_state(self) -> None:
        source = self.strategy.positions[list(self.strategy.positions.keys())[0]].source
        self.PnLRecord = np.zeros(len(source.data['Close']), dtype=np.float64)
        self.strategy.indicators = []

        for data_source in self.strategy.data.values():
            data_source.current_index = len(data_source.data)

        for broker in self.strategy.positions.values():
            broker.position = np.float64(0)
            broker.position_avg_price = np.float64(0)
            broker.cash = np.float64(0)
            broker.orders = []
            broker.complete_orders = []
            broker._i = 0
            broker.PnLRecord = np.full(len(broker.source.data['Close']), self.cash, dtype=np.float64)
            broker.cashRecord = []

    def run(self, progress_bar: bool = False) -> BacktestReport:
        """
        Execute the backtest for the configured strategy.
        
        This method runs the complete backtest simulation, iterating through
        all data points in the strategy's data sources, executing strategy logic,
        processing orders, and tracking performance metrics.
        
        Args:
            progress_bar (bool, optional): Whether to show a progress bar during
                backtest execution. Useful for long-running backtests.
                Defaults to False.
                
        Returns:
            BacktestReport: Object containing complete backtest results including:
                - Starting and final cash amounts
                - P&L record over time
                - List of all executed orders
                - Calculated performance metrics
                
        Note:
            This method modifies the internal state of the strategy and
            should not be called multiple times on the same instance
            without resetting.
        """
        self._reset_runtime_state()

        # Distribute the initial portfolio cash evenly across all symbols so that
        # the aggregate starting equity equals `self.cash`, regardless of the
        # number of data sources attached to the strategy. This avoids
        # double-counting cash when multiple symbols are used.
        n_positions = max(len(self.strategy.positions), 1)
        per_position_cash = np.float64(self.cash / n_positions)

        for key in self.strategy.positions.keys():
            broker = self.strategy.positions[key]
            broker.cash = per_position_cash
            broker.lot_size = self.lot_size
            broker.margin_call = self.margin_call
            broker.commision = np.float64(self.commission)
            broker.commision_type = self.commission_type

        self.strategy.init()

        for data_source in self.strategy.data.values():
            data_source.current_index = 0

        ## Simple backtesting loop
        for i in tqdm(range(0, max([len(i) for i in self.strategy.data.values()])), disable=(not progress_bar)):
            for val in self.strategy.data.values():
                val.current_index = i
            for val in self.strategy.positions.values():
                val._iterate(i)
            for item in self.strategy.indicators:
                # Make indicators time-aware in the same way as DataSource:
                # at step i, expose data up to and including index i.
                # Clamp to the underlying array length to avoid overflow.
                item._i = min(i + 1, item.shape[0])
            self.strategy.next()
        orders: list[Order] = []
        tradeRecord: list[np.float64] = []
        for val in self.strategy.positions.values():
            val.close()
            self.PnLRecord += val.PnLRecord
            cashRecord = np.array(val.cashRecord)
            trades = np.diff(cashRecord)
            tradeRecord.extend(trades)
            orders.extend(val.complete_orders)

        index = list(self.strategy.positions.values())[0].source.data['Close'].index
        return BacktestReport(
            starting_cash=np.float64(self.cash),
            final_cash=self.PnLRecord[-1],
            PnlRecord=pd.Series(self.PnLRecord, index=index),
            orders=orders,
            tradeRecord=tradeRecord)
    
    def optimize(
        self,
        params: dict[str, range],
        constraint: Callable[[dict[str, Any]], bool] | None = None,
        objective: str = "sharpe",
        risk_tolerance: dict[str, float] | None = None,
    ):
        """
        Perform a grid search over the provided parameter ranges.
        
        This method systematically tests all combinations of parameter values
        to find the optimal configuration for the trading strategy. Each
        parameter combination is backtested individually to evaluate performance.
        
        Args:
            params (dict[str, range]): Dictionary mapping strategy attribute names
                to iterables of candidate values. For example:
                ```python
                {
                    'fast_period': range(5, 21, 5),    # [5, 10, 15, 20]
                    'slow_period': range(20, 51, 10),  # [20, 30, 40, 50]
                    'threshold': np.linspace(0.01, 0.1, 10)
                }
                ```
            constraint (Callable[[dict[str, Any]], bool] | None, optional):
                Optional callable that takes a candidate parameter dict and returns
                True to evaluate the combo or False to skip it. Useful for enforcing
                logical constraints like ensuring fast_period < slow_period.
                Defaults to None (no constraints).
            objective (str, optional): BacktestReport attribute or computed metric to
                optimize. Defaults to "sharpe". Supports any attribute exposed by
                BacktestReport and the computed metrics "final_cash", "total_return",
                "sharpe", "max_drawdown", and "trades".
            risk_tolerance (dict[str, float] | None, optional): Optional maximum
                allowed values for candidate metrics. Any candidate that exceeds a
                threshold is discarded before scoring. For example,
                {"max_drawdown": 0.05} rejects strategies with drawdown above 5%.
                Defaults to None.
                
        Returns:
            tuple: A tuple containing (best_params, best_report, results):
                - best_params (dict[str, Any]): Dictionary of parameter values
                  that produced the best performance.
                - best_report (BacktestReport): Complete backtest report for the
                  best parameter combination.
                - results (pd.DataFrame): DataFrame with metrics for all valid
                  parameter combinations, sorted by performance.
                  
        Raises:
            ValueError: If params is empty or contains parameters with no values.
            TypeError: If any parameter values are not iterable.
            
        Note:
            The optimization uses the selected objective as the primary selection
            criterion. If the objective is invalid (NaN), the candidate is skipped.
            
        Example:
            >>> bt = SimpleBacktester(strategy)  
            >>> best_params, best_report, results = bt.optimize({  
            ...     'fast_period': [5, 10, 20],  
            ...     'slow_period': [20, 50, 100]  
            ... }, constraint=lambda p: p['fast_period'] < p['slow_period'])  
            >>> print(f"Best parameters: {best_params}")  
            >>> print(f"Best Sharpe ratio: {best_report.periods_per_year}")  
        """
        if not params:
            raise ValueError("params must not be empty")

        keys = list(params.keys())
        value_lists = []
        for k in keys:
            vals = params[k]
            # Ensure iterability and materialize to list for cartesian product
            try:
                candidates = list(vals)
            except TypeError:
                raise TypeError(f"Parameter '{k}' must be iterable")
            if len(candidates) == 0:
                raise ValueError(f"Parameter '{k}' has no candidate values")
            value_lists.append(candidates)

        results_rows = []
        best_report = None
        best_params = None
        best_score = -np.inf

        valid_metrics = {"final_cash", "total_return", "sharpe", "max_drawdown", "trades"}

        total_combos = len(list(itertools.product(*value_lists)))

        for combo in tqdm(itertools.product(*value_lists), total=(total_combos)):
            # Build parameter dict for this combo
            row_params = {k: v for k, v in zip(keys, combo)}

            # Apply optional constraint; skip combo if it returns False or raises
            if constraint is not None:
                try:
                    if not bool(constraint(row_params)):
                        continue
                except Exception:
                    # If the constraint itself errors, treat as invalid combo
                    continue

            # Fresh strategy copy per combo
            strat_copy = copy.deepcopy(self.strategy)
            for k, v in row_params.items():
                setattr(strat_copy, k, v)

            # Run a fresh backtest instance retaining runtime settings
            bt = SimpleBacktester(
                strat_copy,
                cash=self.cash,
                commission=self.commission,
                commission_type=self.commission_type,
                lot_size=self.lot_size,
            )
            report = bt.run(progress_bar=False)

            metrics = _compute_backtest_metrics(report)

            if not _risk_tolerance_passes(report, risk_tolerance):
                continue

            if objective in valid_metrics:
                score = metrics.get(objective)
            else:
                score = getattr(report, objective, None)
                if callable(score):
                    score = score()

            if score is None:
                raise AttributeError(f"BacktestReport does not expose objective '{objective}'")

            try:
                score = float(score)  # type: ignore[arg-type]
            except (TypeError, ValueError):
                raise TypeError(f"Objective '{objective}' must be numeric")

            if not np.isfinite(score):
                continue

            row = dict(row_params)
            row.update(metrics)
            row["objective_score"] = score
            results_rows.append(row)

            if score > best_score:
                best_score = score
                best_params = {k: v for k, v in zip(keys, combo)}
                best_report = report

        results_df = pd.DataFrame(results_rows)

        # Sort results by composite score (Sharpe desc, then return, then cash)
        if not results_df.empty:
            results_df.sort_values(by=["objective_score"], ascending=False, inplace=True, kind="mergesort")

        return best_params or {}, best_report, results_df
    
    def optimize_parallel(
             self,
             params: dict[str, range],
             constraint: Callable[[dict[str, Any]], bool] | None = None,
             objective: str = "sharpe",
             risk_tolerance: dict[str, float] | None = None,
             workers: int | None = None,
             chunksize: int = 1):
        """
        Perform parallel grid search over parameter ranges for optimization.
        
        This method is identical to optimize() but uses multiprocessing to
        distribute parameter combinations across multiple worker processes,
        significantly reducing computation time for large parameter spaces.
        
        Args:
            params (dict[str, range]): Dictionary mapping strategy attribute names
                to iterables of candidate values (same format as optimize()).
             constraint (Callable[[dict[str, Any]], bool] | None, optional):
                Optional callable for parameter constraints (same as optimize()).
                Defaults to None.
             objective (str, optional): BacktestReport attribute or computed metric to
                optimize. Defaults to "sharpe".
             risk_tolerance (dict[str, float] | None, optional): Optional maximum
                allowed metric values for candidate rejection before scoring.
                Defaults to None.
            workers (int | None, optional): Maximum number of worker processes to use.
                If None, defaults to min(os.cpu_count()-1, 4) to avoid overwhelming
                the system. Defaults to None.
            chunksize (int, optional): Chunk size for ProcessPoolExecutor.map.
                Smaller values provide better load balancing for many small tasks.
                Larger values reduce overhead for fewer, larger tasks.
                Defaults to 1.
                
        Returns:
            tuple: Same return format as optimize():
                (best_params, best_report, results_df)
                
        Raises:
            ValueError: If params is empty or contains parameters with no values.
            TypeError: If any parameter values are not iterable.
            
        Note:
            - This method creates separate processes, so the strategy must be
              picklable for multiprocessing to work.
            - The main process re-runs the best configuration to get the full
              BacktestReport (parallel workers only return summary metrics).
            - Uses ProcessPoolExecutor for true parallelism across CPU cores.
            - Memory usage scales with the number of workers as each worker
              maintains a copy of the strategy.
              
        Performance Tips:
            - For parameter spaces with many combinations (>1000), prefer
              optimize_parallel over optimize for better performance.
            - For small parameter spaces, optimize() may be faster due to
              lower multiprocessing overhead.
            - Monitor system memory usage as each worker maintains a full
              copy of the strategy and data.
              
        Example:
            >>> bt = SimpleBacktester(strategy)  
            >>> # Use 4 workers for parallel optimization  
            >>> best_params, best_report, results = bt.optimize_parallel(  
            ...     {'period1': range(5, 50, 5), 'period2': range(20, 100, 10)},  
            ...     workers=4  
            ... )  
        """
        if not params:
            raise ValueError("params must not be empty")

        keys = list(params.keys())
        value_lists = []
        lens = []
        for k in keys:
            vals = params[k]
            try:
                candidates = list(vals)
            except TypeError:
                raise TypeError(f"Parameter '{k}' must be iterable")
            if len(candidates) == 0:
                raise ValueError(f"Parameter '{k}' has no candidate values")
            value_lists.append(candidates)
            lens.append(len(candidates))

        # determine total combos without materializing them
        total_combos = 1
        for L in lens:
            total_combos *= L

        # prepare iterable of param dicts as sequences of items (so pickling is slightly cheaper)
        def _param_items_iter():
            for combo in itertools.product(*value_lists):
                row_params = {k: v for k, v in zip(keys, combo)}
                if constraint is not None:
                    try:
                        if not bool(constraint(row_params)):
                            continue
                    except Exception:
                        continue
                # yield as tuple of items for stable order and smaller IPC
                yield tuple(row_params.items())

        # choose worker count conservatively to avoid RAM hogging
        cpu_count = os.cpu_count() or 1
        if workers is None:
            workers = max(1, min(cpu_count - 1, 4))
        else:
            workers = max(1, int(workers))

        # pickle the base strategy once and send bytes to worker initializer
        pickled_strategy = pickle.dumps(self.strategy)

        results_rows = []
        # Use ProcessPoolExecutor with worker initializer so each worker holds
        # exactly one copy of the strategy in memory.
        with concurrent.futures.ProcessPoolExecutor(
            max_workers=workers,
            initializer=_worker_init,
            initargs=(
                pickled_strategy,
                self.cash,
                self.commission,
                self.commission_type,
                self.lot_size,
            ),
        ) as exe:
            # map the worker over param item tuples
            # use list() on map to iterate with tqdm and collect results
            it = exe.map(_worker_eval, _param_items_iter(), chunksize=chunksize)
            # iterate with progress display
            for res in tqdm(it, total=total_combos, disable=(total_combos <= 1)):
                results_rows.append(res)

        valid_metrics = {"final_cash", "total_return", "sharpe", "max_drawdown", "trades"}
        filtered_rows = []
        for row in results_rows:
            row_params = row["params"]
            if risk_tolerance is not None:
                if any(float(row.get(metric, np.inf)) > float(limit) for metric, limit in risk_tolerance.items() if limit is not None):
                    continue
            if objective in valid_metrics:
                score = row.get(objective)
            else:
                score = row.get(objective)
            if score is None or not np.isfinite(float(score)):
                continue
            row["objective_score"] = float(score)
            filtered_rows.append(row)

        # Build DataFrame of small metrics returned from workers
        results_df = pd.DataFrame(filtered_rows)
        if not results_df.empty:
            results_df.sort_values(by=["objective_score"], ascending=False, inplace=True, kind="mergesort")

        # Determine best params from results_df if any
        if results_df.empty:
            return {}, None, results_df

        best_row = results_df.iloc[0]
        best_params = best_row["params"]

        # Re-run full backtest locally in main process for best_params to obtain
        # the full BacktestReport (includes PnLRecord and orders)
        strat_copy = copy.deepcopy(self.strategy)
        for k, v in best_params.items():
            setattr(strat_copy, k, v)
        bt = SimpleBacktester(
            strat_copy,
            cash=self.cash,
            commission=self.commission,
            commission_type=self.commission_type,
            lot_size=self.lot_size,
        )
        best_report = bt.run(progress_bar=False)

        return best_params, best_report, results_df

    def optimize_with_split(
        self,
        params: dict[str, Any],
        constraint: Callable[[dict[str, Any]], bool] | None = None,
        objective: str = "sharpe",
        risk_tolerance: dict[str, float] | None = None,
        train_ratio: float = 0.6,
        validate_ratio: float = 0.2,
        test_ratio: float = 0.2,
        selection_criterion: str = "validate",
    ) -> OptimizationResult:
        """
        Optimize strategy parameters using train/validate/test splits.
        
        This method implements ML-style optimization with three data splits:
        - Training set: Used to fit strategy parameters
        - Validation set: Used to select the best parameters
        - Test set: Used for final out-of-sample evaluation
        
        This approach helps prevent overfitting by evaluating generalization
        performance on held-out data before final selection.
        
        Args:
            params (dict[str, range]): Dictionary mapping strategy attribute names
                to iterables of candidate values (same format as optimize()).
            constraint (Callable[[dict[str, Any]], bool] | None, optional):
                Optional callable for parameter constraints. Defaults to None.
            objective (str, optional): Metric to optimize. Defaults to "sharpe".
                Supports same metrics as optimize().
            risk_tolerance (dict[str, float] | None, optional): Optional maximum
                allowed metric values. Defaults to None.
            train_ratio (float, optional): Fraction of data for training.
                Defaults to 0.6 (60%).
            validate_ratio (float, optional): Fraction of data for validation.
                Defaults to 0.2 (20%).
            test_ratio (float, optional): Fraction of data for testing.
                Defaults to 0.2 (20%).
            selection_criterion (str, optional): Which split to use for final
                parameter selection. Options: "train", "validate", "test".
                Defaults to "validate".
                
        Returns:
            OptimizationResult: Object containing:
                - best_params: Best parameters found
                - train_report: BacktestReport for training data
                - validate_report: BacktestReport for validation data
                - test_report: BacktestReport for test data
                - train_metrics: Metrics computed on training data
                - validate_metrics: Metrics computed on validation data
                - test_metrics: Metrics computed on test data
                - all_results: DataFrame with all results
                
        Raises:
            ValueError: If split ratios don't sum to 1.0 or selection_criterion
                is invalid.
                
        Example:
            >>> bt = SimpleBacktester(strategy)
            >>> result = bt.optimize_with_split(
            ...     {'fast_period': [5, 10, 15], 'slow_period': [20, 30, 50]},
            ...     selection_criterion='validate'
            ... )
            >>> print(f"Best params: {result.best_params}")
            >>> print(f"Train Sharpe: {result.train_metrics['sharpe']}")
            >>> print(f"Validate Sharpe: {result.validate_metrics['sharpe']}")
            >>> print(f"Test Sharpe: {result.test_metrics['sharpe']}")
        """
        # Validate selection criterion
        valid_criteria = {"train", "validate", "test"}
        if selection_criterion not in valid_criteria:
            raise ValueError(
                f"selection_criterion must be one of {valid_criteria}, "
                f"got '{selection_criterion}'"
            )
        
        # Get data length from the strategy's data source
        source = self.strategy.positions[list(self.strategy.positions.keys())[0]].source
        data_length = len(source.data)
        
        # Create the split
        split = create_train_validate_test_split(
            data_length,
            train_ratio,
            validate_ratio,
            test_ratio
        )
        
        # Prepare parameter combinations
        if not params:
            raise ValueError("params must not be empty")

        keys = list(params.keys())
        value_lists = []
        for k in keys:
            vals = params[k]
            try:
                candidates = list(vals)
            except TypeError:
                raise TypeError(f"Parameter '{k}' must be iterable")
            if len(candidates) == 0:
                raise ValueError(f"Parameter '{k}' has no candidate values")
            value_lists.append(candidates)

        # Store results for each split
        train_results = []
        validate_results = []
        test_results = []
        
        valid_metrics = {"final_cash", "total_return", "sharpe", "max_drawdown", "trades"}
        
        total_combos = len(list(itertools.product(*value_lists)))
        
        # Create a modified strategy that uses data slices
        def create_split_strategy(params_dict: dict, split_mode: DataSplitMode):
            """Create a strategy copy with data sliced to the specified split."""
            strat_copy = copy.deepcopy(self.strategy)
            for k, v in params_dict.items():
                # Convert float to int if the strategy expects integer parameters
                if isinstance(v, float) and v == int(v):
                    v = int(v)
                setattr(strat_copy, k, v)
            
            # Slice each data source to the appropriate split
            for key, broker in strat_copy.positions.items():
                source = broker.source
                if split_mode == DataSplitMode.TRAIN:
                    start, end = split.train_start, split.train_end
                elif split_mode == DataSplitMode.VALIDATE:
                    start, end = split.validate_start, split.validate_end
                else:  # TEST
                    start, end = split.test_start, split.test_end
                
                # Create a new data source with sliced data
                sliced_df = source.data.iloc[start:end].copy()
                from .datasource import DataSource
                new_source = DataSource(sliced_df)
                broker.source = new_source
                # Also update the strategy's data dictionary
                strat_copy.data[key] = new_source
                
            return strat_copy, split_mode

        # Run optimization for each split
        for combo in tqdm(itertools.product(*value_lists), total=total_combos, desc="Optimizing"):
            row_params = {k: v for k, v in zip(keys, combo)}
            
            # Apply constraint
            if constraint is not None:
                try:
                    if not bool(constraint(row_params)):
                        continue
                except Exception:
                    continue
            
            # Evaluate on all three splits
            for mode in [DataSplitMode.TRAIN, DataSplitMode.VALIDATE, DataSplitMode.TEST]:
                strat_copy, _ = create_split_strategy(row_params, mode)
                
                bt = SimpleBacktester(
                    strat_copy,
                    cash=self.cash,
                    commission=self.commission,
                    commission_type=self.commission_type,
                    lot_size=self.lot_size,
                )
                report = bt.run(progress_bar=False)
                metrics = _compute_backtest_metrics(report)
                
                # Apply risk tolerance filter
                if risk_tolerance is not None:
                    if not _risk_tolerance_passes(report, risk_tolerance):
                        continue
                
                # Compute objective score
                if objective in valid_metrics:
                    score = metrics.get(objective)
                else:
                    score = getattr(report, objective, None)
                    if callable(score):
                        score = score()
                
                if score is None or not np.isfinite(float(score)):  # type: ignore[arg-type]
                    continue
                
                row = dict(row_params)
                row["objective_score"] = float(score)  # type: ignore[arg-type]
                row.update(metrics)
                
                if mode == DataSplitMode.TRAIN:
                    train_results.append(row)
                elif mode == DataSplitMode.VALIDATE:
                    validate_results.append(row)
                else:
                    test_results.append(row)
        
        # Create DataFrames
        train_df = pd.DataFrame(train_results) if train_results else pd.DataFrame()
        validate_df = pd.DataFrame(validate_results) if validate_results else pd.DataFrame()
        test_df = pd.DataFrame(test_results) if test_results else pd.DataFrame()
        
        # Select best parameters based on selection criterion
        if selection_criterion == "validate" and not validate_df.empty:
            validate_df_sorted = validate_df.sort_values(
                by=["objective_score"], ascending=False, kind="mergesort"
            )
            best_idx = validate_df_sorted.index[0]
            best_params = {k: validate_df.loc[best_idx, k] for k in keys}
            best_validate_score = validate_df.loc[best_idx, "objective_score"]
        elif selection_criterion == "train" and not train_df.empty:
            train_df_sorted = train_df.sort_values(
                by=["objective_score"], ascending=False, kind="mergesort"
            )
            best_idx = train_df_sorted.index[0]
            best_params = {k: train_df.loc[best_idx, k] for k in keys}
            best_validate_score = train_df.loc[best_idx, "objective_score"]
        elif selection_criterion == "test" and not test_df.empty:
            test_df_sorted = test_df.sort_values(
                by=["objective_score"], ascending=False, kind="mergesort"
            )
            best_idx = test_df_sorted.index[0]
            best_params = {k: test_df.loc[best_idx, k] for k in keys}
            best_validate_score = test_df.loc[best_idx, "objective_score"]
        else:
            best_params = {}
            best_validate_score = -np.inf
        
        # Get full reports for best parameters
        train_report = None
        validate_report = None
        test_report = None
        train_metrics = {}
        validate_metrics = {}
        test_metrics = {}
        
        if best_params:
            # Run full backtests for best parameters on each split
            for mode, report_attr, metrics_attr in [
                (DataSplitMode.TRAIN, 'train_report', 'train_metrics'),
                (DataSplitMode.VALIDATE, 'validate_report', 'validate_metrics'),
                (DataSplitMode.TEST, 'test_report', 'test_metrics'),
            ]:
                strat_copy, _ = create_split_strategy(best_params, mode)
                bt = SimpleBacktester(
                    strat_copy,
                    cash=self.cash,
                    commission=self.commission,
                    commission_type=self.commission_type,
                    lot_size=self.lot_size,
                )
                report = bt.run(progress_bar=False)
                metrics = _compute_backtest_metrics(report)
                
                if mode == DataSplitMode.TRAIN:
                    train_report = report
                    train_metrics = metrics
                elif mode == DataSplitMode.VALIDATE:
                    validate_report = report
                    validate_metrics = metrics
                else:
                    test_report = report
                    test_metrics = metrics
        
        # Combine all results
        all_results = pd.DataFrame()
        if not train_df.empty:
            train_df_copy = train_df.copy()
            train_df_copy["split"] = "train"
            all_results = pd.concat([all_results, train_df_copy], ignore_index=True)
        if not validate_df.empty:
            validate_df_copy = validate_df.copy()
            validate_df_copy["split"] = "validate"
            all_results = pd.concat([all_results, validate_df_copy], ignore_index=True)
        if not test_df.empty:
            test_df_copy = test_df.copy()
            test_df_copy["split"] = "test"
            all_results = pd.concat([all_results, test_df_copy], ignore_index=True)
        
        return OptimizationResult(
            best_params=best_params,
            train_report=train_report,
            validate_report=validate_report,
            test_report=test_report,
            train_metrics=train_metrics,
            validate_metrics=validate_metrics,
            test_metrics=test_metrics,
            all_results=all_results
        )

    def optimize_gradient_descent(
        self,
        param_init: dict[str, float],
        param_bounds: dict[str, tuple[float, float]],
        objective: str = "sharpe",
        learning_rate: float = 0.01,
        max_iterations: int = 100,
        tolerance: float = 1e-6,
        momentum: float = 0.9,
        train_ratio: float = 0.7,
        validate_ratio: float = 0.15,
        test_ratio: float = 0.15,
        selection_criterion: str = "validate",
        progress_bar: bool = True,
    ) -> OptimizationResult:
        """
        Optimize strategy parameters using gradient descent.
        
        This method performs gradient-based optimization on continuous
        strategy parameters, similar to machine learning workflows. It uses
        train/validate/test splits to prevent overfitting and select the best
        model based on validation performance.
        
        The optimization computes numerical gradients by evaluating small
        perturbations around the current parameter values.
        
        Args:
            param_init (dict[str, float]): Initial parameter values.
            param_bounds (dict[str, tuple[float, float]]): Bounds for each
                parameter as (min, max) tuples.
            objective (str, optional): Metric to optimize. Defaults to "sharpe".
                Supports same metrics as optimize().
            learning_rate (float, optional): Step size for gradient descent.
                Defaults to 0.01.
            max_iterations (int, optional): Maximum number of iterations.
                Defaults to 100.
            tolerance (float, optional): Convergence tolerance. Optimization
                stops when gradient magnitude falls below this threshold.
                Defaults to 1e-6.
            momentum (float, optional): Momentum factor for accelerated
                descent. Defaults to 0.9.
            train_ratio (float, optional): Fraction of data for training.
                Defaults to 0.7 (70%).
            validate_ratio (float, optional): Fraction of data for validation.
                Defaults to 0.15 (15%).
            test_ratio (float, optional): Fraction of data for testing.
                Defaults to 0.15 (15%).
            selection_criterion (str, optional): Which split to use for final
                parameter selection. Options: "train", "validate", "test".
                Defaults to "validate".
            progress_bar (bool, optional): Whether to show progress bar.
                Defaults to True.
                
        Returns:
            OptimizationResult: Object containing:
                - best_params: Optimized parameter values
                - train_report: BacktestReport for training data
                - validate_report: BacktestReport for validation data
                - test_report: BacktestReport for test data
                - train_metrics: Metrics computed on training data
                - validate_metrics: Metrics computed on validation data
                - test_metrics: Metrics computed on test data
                - all_results: DataFrame with iteration history
                
        Example:
            >>> bt = SimpleBacktester(strategy)
            >>> result = bt.optimize_gradient_descent(
            ...     param_init={'fast_period': 10.0, 'slow_period': 30.0},
            ...     param_bounds={
            ...         'fast_period': (2.0, 50.0),
            ...         'slow_period': (10.0, 100.0)
            ...     },
            ...     learning_rate=0.05,
            ...     max_iterations=50
            ... )
            >>> print(f"Optimized params: {result.best_params}")
            >>> print(f"Final validation Sharpe: {result.validate_metrics['sharpe']}")
        """
        # Validate selection criterion
        valid_criteria = {"train", "validate", "test"}
        if selection_criterion not in valid_criteria:
            raise ValueError(
                f"selection_criterion must be one of {valid_criteria}, "
                f"got '{selection_criterion}'"
            )
        
        # Validate parameters
        if not param_init:
            raise ValueError("param_init must not be empty")
        if set(param_init.keys()) != set(param_bounds.keys()):
            raise ValueError("param_init and param_bounds must have the same keys")
        
        # Get data length from the strategy's data source
        source = self.strategy.positions[list(self.strategy.positions.keys())[0]].source
        data_length = len(source.data)
        
        # Create the split
        split = create_train_validate_test_split(
            data_length,
            train_ratio,
            validate_ratio,
            test_ratio
        )
        
        valid_metrics = {"final_cash", "total_return", "sharpe", "max_drawdown", "trades"}
        
        # Helper to create sliced strategy
        def create_split_strategy(params_dict: dict, split_mode: DataSplitMode):
            """Create a strategy copy with data sliced to the specified split."""
            strat_copy = copy.deepcopy(self.strategy)
            for k, v in params_dict.items():
                # Convert float to int if the strategy expects integer parameters
                if isinstance(v, float) and v == int(v):
                    v = int(v)
                setattr(strat_copy, k, v)
            
            # Slice each data source to the appropriate split
            for key, broker in strat_copy.positions.items():
                source = broker.source
                if split_mode == DataSplitMode.TRAIN:
                    start, end = split.train_start, split.train_end
                elif split_mode == DataSplitMode.VALIDATE:
                    start, end = split.validate_start, split.validate_end
                else:  # TEST
                    start, end = split.test_start, split.test_end
                
                sliced_df = source.data.iloc[start:end].copy()
                from .datasource import DataSource
                new_source = DataSource(sliced_df)
                broker.source = new_source
                # Also update the strategy's data dictionary
                strat_copy.data[key] = new_source
                
            return strat_copy
        
        # Function to evaluate parameters on a specific split
        def evaluate_params(params_dict: dict, split_mode: DataSplitMode) -> float:
            """Evaluate objective function on specified split."""
            strat_copy = create_split_strategy(params_dict, split_mode)
            bt = SimpleBacktester(
                strat_copy,
                cash=self.cash,
                commission=self.commission,
                commission_type=self.commission_type,
                lot_size=self.lot_size,
            )
            report = bt.run(progress_bar=False)
            metrics = _compute_backtest_metrics(report)
            
            if objective in valid_metrics:
                score = metrics.get(objective)
            else:
                score = getattr(report, objective, None)
                if callable(score):
                    score = score()
            
            if score is None or not np.isfinite(float(score)):  # type: ignore[arg-type]
                return -np.inf
            
            return float(score)  # type: ignore[arg-type]
        
        # Compute numerical gradient
        def compute_gradient(params: dict, eps: float = 1e-5) -> dict:
            """Compute numerical gradient using central differences."""
            grad = {}
            for key in params:
                params_plus = params.copy()
                params_minus = params.copy()
                params_plus[key] = params[key] + eps
                params_minus[key] = params[key] - eps
                
                # Use validation set for gradient computation
                f_plus = evaluate_params(params_plus, DataSplitMode.VALIDATE)
                f_minus = evaluate_params(params_minus, DataSplitMode.VALIDATE)
                
                grad[key] = (f_plus - f_minus) / (2 * eps)
            
            return grad
        
        # Gradient descent optimization
        current_params = param_init.copy()
        velocities = {k: 0.0 for k in current_params}
        
        iteration_history = []
        best_params = current_params.copy()
        best_score = -np.inf
        
        param_names = list(current_params.keys())
        
        iterator = range(max_iterations)
        if progress_bar:
            iterator = tqdm(iterator, desc="Gradient Descent")
        
        for iteration in iterator:
            # Compute gradient
            gradient = compute_gradient(current_params)
            
            # Check for convergence (gradient magnitude)
            grad_magnitude = np.sqrt(sum(g**2 for g in gradient.values()))
            if grad_magnitude < tolerance:
                if progress_bar:
                    print(f"\nConverged at iteration {iteration}")
                break
            
            # Update velocities with momentum
            for key in param_names:
                velocities[key] = momentum * velocities[key] - learning_rate * gradient[key]
            
            # Update parameters
            for key in param_names:
                current_params[key] += velocities[key]
                
                # Apply bounds
                min_val, max_val = param_bounds[key]
                current_params[key] = np.clip(current_params[key], min_val, max_val)
            
            # Evaluate on all splits
            train_score = evaluate_params(current_params, DataSplitMode.TRAIN)
            validate_score = evaluate_params(current_params, DataSplitMode.VALIDATE)
            test_score = evaluate_params(current_params, DataSplitMode.TEST)
            
            # Track best parameters based on selection criterion
            if selection_criterion == "validate" and validate_score > best_score:
                best_score = validate_score
                best_params = current_params.copy()
            elif selection_criterion == "train" and train_score > best_score:
                best_score = train_score
                best_params = current_params.copy()
            elif selection_criterion == "test" and test_score > best_score:
                best_score = test_score
                best_params = current_params.copy()
            
            # Record iteration history
            row = current_params.copy()
            row["iteration"] = iteration
            row["train_score"] = train_score
            row["validate_score"] = validate_score
            row["test_score"] = test_score
            row["gradient_magnitude"] = grad_magnitude
            iteration_history.append(row)
        
        # Create history DataFrame
        history_df = pd.DataFrame(iteration_history)
        
        # Get final reports for best parameters
        train_report = None
        validate_report = None
        test_report = None
        train_metrics = {}
        validate_metrics = {}
        test_metrics = {}
        
        for mode, report_attr, metrics_attr in [
            (DataSplitMode.TRAIN, 'train_report', 'train_metrics'),
            (DataSplitMode.VALIDATE, 'validate_report', 'validate_metrics'),
            (DataSplitMode.TEST, 'test_report', 'test_metrics'),
        ]:
            strat_copy = create_split_strategy(best_params, mode)
            bt = SimpleBacktester(
                strat_copy,
                cash=self.cash,
                commission=self.commission,
                commission_type=self.commission_type,
                lot_size=self.lot_size,
            )
            report = bt.run(progress_bar=False)
            metrics = _compute_backtest_metrics(report)
            
            if mode == DataSplitMode.TRAIN:
                train_report = report
                train_metrics = metrics
            elif mode == DataSplitMode.VALIDATE:
                validate_report = report
                validate_metrics = metrics
            else:
                test_report = report
                test_metrics = metrics
        
        return OptimizationResult(
            best_params=best_params,
            train_report=train_report,
            validate_report=validate_report,
            test_report=test_report,
            train_metrics=train_metrics,
            validate_metrics=validate_metrics,
            test_metrics=test_metrics,
            all_results=history_df
        )
