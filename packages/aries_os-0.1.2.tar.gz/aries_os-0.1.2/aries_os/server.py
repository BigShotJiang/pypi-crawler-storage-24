"""FastAPI server — replaces proxy.cjs."""

from __future__ import annotations

import asyncio
import json
import os
import re
import subprocess
from pathlib import Path

import httpx
from dotenv import load_dotenv
from fastapi import FastAPI, Request, Response
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse, StreamingResponse
from fastapi.staticfiles import StaticFiles

# ── Load .env from cwd (so users can keep keys next to where they run aries-os)
load_dotenv(Path.cwd() / ".env")
load_dotenv(Path(__file__).parent.parent / "aries-os" / ".env", override=False)  # dev fallback

# ── Helpers ────────────────────────────────────────────────────────────────────

def _env(key: str) -> str:
    """Return env var, trying both plain and VITE_ prefixed versions."""
    return os.environ.get(key) or os.environ.get(f"VITE_{key}") or ""


PROVIDERS: dict[str, dict] = {
    "cerebras": {"url": "https://api.cerebras.ai/v1/chat/completions",                       "key": lambda: _env("CEREBRAS_API_KEY")},
    "groq":     {"url": "https://api.groq.com/openai/v1/chat/completions",                  "key": lambda: _env("GROQ_API_KEY")},
    "openai":   {"url": "https://api.openai.com/v1/chat/completions",                        "key": lambda: _env("OPENAI_API_KEY")},
    "gemini":   {"url": "https://generativelanguage.googleapis.com/v1beta/openai/chat/completions", "key": lambda: _env("GEMINI_API_KEY")},
    "chutes":   {"url": "https://llm.chutes.ai/v1/chat/completions",                         "key": lambda: _env("CHUTES_API_KEY")},
}


async def _call_llm(
    client: httpx.AsyncClient,
    url: str,
    key: str,
    body: dict,
    timeout: float = 90.0,
) -> str:
    """Call an OpenAI-compatible endpoint and return the text content."""
    r = await client.post(
        url,
        json=body,
        headers={"Authorization": f"Bearer {key}", "Content-Type": "application/json"},
        timeout=timeout,
    )
    r.raise_for_status()
    data = r.json()
    return data["choices"][0]["message"]["content"] or ""


async def _call_cerebras(client: httpx.AsyncClient, messages: list, max_tokens: int = 4096) -> str:
    key = _env("CEREBRAS_API_KEY")
    return await _call_llm(
        client,
        PROVIDERS["cerebras"]["url"],
        key,
        {"model": "qwen-3-235b-a22b-instruct-2507", "messages": messages,
         "max_tokens": max_tokens, "stream": False, "temperature": 0.7},
    )


async def _call_chutes_with_fallback(
    client: httpx.AsyncClient,
    chutes_model: str,
    groq_fallback_model: str,
    messages: list,
    max_tokens: int = 4096,
) -> str:
    chutes_key = _env("CHUTES_API_KEY")
    groq_key = _env("GROQ_API_KEY")
    try:
        print(f"[DeepResearch] Trying Chutes: {chutes_model}")
        result = await _call_llm(
            client,
            PROVIDERS["chutes"]["url"],
            chutes_key,
            {"model": chutes_model, "messages": messages, "max_tokens": max_tokens,
             "stream": False, "temperature": 0.7},
            timeout=90.0,
        )
        print(f"[DeepResearch] ✓ Chutes {chutes_model} responded")
        return result
    except Exception as e:
        print(f"[DeepResearch] Chutes failed ({e}), falling back to Groq: {groq_fallback_model}")
        return await _call_llm(
            client,
            PROVIDERS["groq"]["url"],
            groq_key,
            {"model": groq_fallback_model, "messages": messages, "max_tokens": max_tokens,
             "stream": False, "temperature": 0.7},
            timeout=30.0,
        )


async def _jina_search(client: httpx.AsyncClient, query: str) -> str:
    try:
        from urllib.parse import quote
        encoded = quote(query, safe="")
        r = await client.get(
            f"https://s.jina.ai/{encoded}",
            headers={"Accept": "text/plain", "X-Return-Format": "text"},
            timeout=10.0,
        )
        return r.text[:3000]
    except Exception:
        return ""


# ── App ────────────────────────────────────────────────────────────────────────

app = FastAPI(title="Aries AI OS", docs_url=None, redoc_url=None)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["GET", "POST", "OPTIONS"],
    allow_headers=["*"],
)


# ── /api/chat ──────────────────────────────────────────────────────────────────

@app.post("/api/chat")
async def chat(request: Request) -> Response:
    body = await request.json()
    provider: str = body.get("provider", "cerebras")
    model: str = body.get("model", "")
    messages: list = body.get("messages", [])
    stream: bool = body.get("stream", False)

    p = PROVIDERS.get(provider)
    if not p:
        return JSONResponse({"error": "Unknown provider"}, status_code=400)
    key = p["key"]()
    if not key:
        return JSONResponse({"error": f"Missing API key for {provider}"}, status_code=500)

    upstream_body = {"model": model, "messages": messages}
    if stream:
        upstream_body["stream"] = True

    async with httpx.AsyncClient(timeout=120.0) as client:
        try:
            r = await client.post(
                p["url"],
                json=upstream_body,
                headers={"Authorization": f"Bearer {key}", "Content-Type": "application/json"},
            )

            # Auto-fallback: Cerebras 503 → Groq
            if r.status_code == 503 and provider == "cerebras":
                groq_key = _env("GROQ_API_KEY")
                if groq_key:
                    r = await client.post(
                        PROVIDERS["groq"]["url"],
                        json={"model": "llama3-8b-8192", "messages": messages, "stream": stream},
                        headers={"Authorization": f"Bearer {groq_key}", "Content-Type": "application/json"},
                    )

            return Response(
                content=r.content,
                status_code=r.status_code,
                media_type="application/json",
            )
        except Exception as e:
            return JSONResponse({"error": str(e)}, status_code=500)


# ── /api/deep-research ────────────────────────────────────────────────────────

@app.post("/api/deep-research")
async def deep_research(request: Request) -> JSONResponse:
    body = await request.json()
    prompt: str = body.get("prompt", "").strip()
    file_content: str = body.get("fileContent", "")
    if not prompt:
        return JSONResponse({"error": "Missing prompt"}, status_code=400)

    file_ctx = f"\n\n--- Uploaded File Context ---\n{file_content[:8000]}" if file_content else ""

    async with httpx.AsyncClient(timeout=120.0) as client:
        try:
            # Phase 1: Generate search queries
            print("[DeepResearch] Phase 1: Generating search queries...")
            query_resp = await _call_cerebras(client, [
                {"role": "system", "content": "Generate exactly 3 concise web search queries for this research topic. Return ONLY a JSON array of 3 strings. Example: [\"query 1\",\"query 2\",\"query 3\"]"},
                {"role": "user", "content": prompt},
            ], max_tokens=256)

            search_queries = [prompt]
            try:
                match = re.search(r"\[[\s\S]*?\]", query_resp)
                if match:
                    parsed = json.loads(match.group())
                    if isinstance(parsed, list) and parsed:
                        search_queries = parsed[:3]
            except Exception:
                pass
            print(f"[DeepResearch] Search queries: {search_queries}")

            # Phase 2: Parallel web search
            print("[DeepResearch] Phase 2: Web searching...")
            search_results = await asyncio.gather(*[
                _jina_search(client, q) for q in search_queries
            ])
            web_context = "\n\n".join(
                f'--- Web Result {i+1}: "{search_queries[i]}" ---\n{r}'
                for i, r in enumerate(search_results) if r
            )
            print(f"[DeepResearch] Web search complete. Got {len(web_context)} chars.")

            # Phase 3: Parallel LLM calls
            research_system_prompt = (
                "You are a world-class research analyst.\n"
                "Provide a comprehensive, deeply-reasoned, expert-level analysis using structured markdown:\n"
                "- Clear ## headings for each major section\n"
                "- Evidence-based reasoning with specific facts\n"
                "- Cite web search data where available\n"
                "- Expert synthesis and insight beyond the obvious\n"
                "- Practical implications and actionable conclusions\n"
                "Think step-by-step and be thorough."
            )
            research_messages = [
                {"role": "system", "content": research_system_prompt},
                {"role": "user", "content": f"Research Question: {prompt}{file_ctx}\n\n" +
                 (f"Live Web Research:\n{web_context}" if web_context else "")},
            ]

            print("[DeepResearch] Phase 3: Calling DeepSeek V3 and Kimi K2 in parallel...")
            analysis1, analysis2 = await asyncio.gather(
                _call_chutes_with_fallback(client, "deepseek-ai/DeepSeek-V3", "deepseek-r1-distill-llama-70b", research_messages, 4096),
                _call_chutes_with_fallback(client, "moonshotai/Kimi-K2-Instruct", "llama-3.3-70b-versatile", research_messages, 4096),
            )
            print("[DeepResearch] Phase 3 complete.")

            # Phase 4: Synthesis
            print("[DeepResearch] Phase 4: Synthesizing...")
            synthesis = await _call_cerebras(client, [
                {"role": "system", "content": (
                    "You are a master research synthesizer. Merge two expert analyses into ONE unified, authoritative document.\n"
                    "Rules:\n"
                    "1. Combine the best insights from both — no duplicates\n"
                    "2. Resolve contradictions with balanced perspective\n"
                    "3. Flow naturally as a single document — never reference \"Analysis A\" or \"Model A/B\"\n"
                    "4. Use professional markdown: ## headings, **bold key terms**, bullet lists, tables where appropriate\n"
                    "5. End with a ## Conclusion section\n"
                    "Output only the final document."
                )},
                {"role": "user", "content": f'Question: "{prompt}"\n\n=== Analysis 1 ===\n{analysis1}\n\n=== Analysis 2 ===\n{analysis2}'},
            ], max_tokens=8000)
            print("[DeepResearch] ✓ Done!")

            return JSONResponse({"answer": synthesis, "queriesUsed": search_queries})
        except Exception as e:
            print(f"[DeepResearch] Fatal error: {e}")
            return JSONResponse({"error": str(e)}, status_code=500)


# ── /api/terminal ─────────────────────────────────────────────────────────────

@app.post("/api/terminal")
async def terminal(request: Request) -> JSONResponse:
    body = await request.json()
    cmd: str = body.get("cmd", "").strip()
    cwd: str = body.get("cwd", "") or str(Path.cwd())
    if not cmd:
        return JSONResponse({"error": "No command provided"}, status_code=400)
    try:
        proc = await asyncio.create_subprocess_shell(
            cmd,
            cwd=cwd,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
        )
        stdout, stderr = await asyncio.wait_for(proc.communicate(), timeout=30.0)
        return JSONResponse({
            "stdout": stdout.decode(errors="replace"),
            "stderr": stderr.decode(errors="replace"),
            "exitCode": proc.returncode or 0,
        })
    except asyncio.TimeoutError:
        return JSONResponse({"stdout": "", "stderr": "Command timed out after 30s", "exitCode": 1})
    except Exception as e:
        return JSONResponse({"error": str(e)}, status_code=500)


# ── /api/imagine ──────────────────────────────────────────────────────────────

@app.post("/api/imagine")
async def imagine(request: Request) -> Response:
    body = await request.json()
    chutes_key = _env("CHUTES_API_KEY")
    if not chutes_key:
        return JSONResponse({"error": "Missing CHUTES_API_KEY"}, status_code=500)
    try:
        async with httpx.AsyncClient(timeout=120.0) as client:
            r = await client.post(
                "https://chutes-z-image-turbo.chutes.ai/generate",
                json=body,
                headers={"Authorization": f"Bearer {chutes_key}", "Content-Type": "application/json"},
            )
            content_type = r.headers.get("content-type", "image/png")
            return Response(content=r.content, status_code=r.status_code, media_type=content_type)
    except Exception as e:
        return JSONResponse({"error": str(e)}, status_code=500)


# ── /api/music ────────────────────────────────────────────────────────────────

@app.post("/api/music")
async def music(request: Request) -> Response:
    body = await request.json()
    chutes_key = _env("CHUTES_API_KEY")
    if not chutes_key:
        return JSONResponse({"error": "Missing CHUTES_API_KEY"}, status_code=500)
    try:
        async with httpx.AsyncClient(timeout=120.0) as client:
            r = await client.post(
                "https://chutes-diffrhythm.chutes.ai/generate",
                json=body,
                headers={"Authorization": f"Bearer {chutes_key}", "Content-Type": "application/json"},
            )
            return Response(content=r.content, status_code=r.status_code,
                            media_type=r.headers.get("content-type", "audio/wav"))
    except Exception as e:
        return JSONResponse({"error": str(e)}, status_code=500)


# ── /api/video ────────────────────────────────────────────────────────────────

@app.post("/api/video")
async def video(request: Request) -> Response:
    body = await request.json()
    chutes_key = _env("CHUTES_API_KEY")
    if not chutes_key:
        return JSONResponse({"error": "Missing CHUTES_API_KEY"}, status_code=500)
    print("[video] → chutes-wan-2-2-i2v-14b-fast.chutes.ai/generate")
    try:
        async with httpx.AsyncClient(timeout=300.0) as client:
            r = await client.post(
                "https://chutes-wan-2-2-i2v-14b-fast.chutes.ai/generate",
                json=body,
                headers={"Authorization": f"Bearer {chutes_key}", "Content-Type": "application/json"},
            )
            print(f"[video] upstream status: {r.status_code}")
            return Response(content=r.content, status_code=r.status_code,
                            media_type=r.headers.get("content-type", "video/mp4"))
    except Exception as e:
        print(f"[video] error: {e}")
        return JSONResponse({"error": str(e)}, status_code=500)


# ── Static frontend ───────────────────────────────────────────────────────────

_DIST = Path(__file__).parent / "dist"
if _DIST.exists():
    # Mount assets so JS/CSS loads, then fallback to index.html for SPA routing
    app.mount("/assets", StaticFiles(directory=str(_DIST / "assets")), name="assets")

    @app.get("/{full_path:path}")
    async def spa_fallback(full_path: str) -> Response:
        # Serve index.html for all non-API routes (SPA client-side routing)
        index = _DIST / "index.html"
        if index.exists():
            return Response(content=index.read_bytes(), media_type="text/html")
        return Response("Frontend not found. Run 'npm run build' first.", status_code=404)
else:
    @app.get("/")
    async def no_frontend() -> JSONResponse:
        return JSONResponse({
            "message": "Aries AI OS backend is running. Frontend not built yet.",
            "hint": "Run 'npm run build' inside aries-os/ and copy dist/ to aries_os/dist/"
        })
