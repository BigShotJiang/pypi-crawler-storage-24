"""CLI entry point — run with `aries-os` or `python -m aries_os`."""

from __future__ import annotations

import os
import sys
import webbrowser
import threading
import time


def main() -> None:
    port = int(os.environ.get("PORT", 8888))
    host = os.environ.get("HOST", "127.0.0.1")

    print(f"""
  ╔══════════════════════════════════════════╗
  ║        ⚡  Aries AI Operating System     ║
  ╚══════════════════════════════════════════╝
  → Server:  http://{host}:{port}
  → API keys are loaded from .env in your current directory.
  → Press Ctrl+C to stop.
""")

    # Open browser slightly after server starts
    def _open_browser():
        time.sleep(1.5)
        webbrowser.open(f"http://{host}:{port}")

    threading.Thread(target=_open_browser, daemon=True).start()

    try:
        import uvicorn
        from aries_os.server import app
        uvicorn.run(app, host=host, port=port, log_level="warning")
    except ImportError:
        print("Error: uvicorn is not installed. Run: pip install uvicorn[standard]", file=sys.stderr)
        sys.exit(1)
    except KeyboardInterrupt:
        print("\n👋 Aries AI OS stopped.")


if __name__ == "__main__":
    main()
