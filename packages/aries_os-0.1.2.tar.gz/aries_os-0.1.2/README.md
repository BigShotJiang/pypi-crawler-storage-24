# ⚡ Aries AI OS

> Your personal AI productivity operating system — install and run in seconds.

---

## 🚀 Quick Start

```bash
pip install aries-os
```

Create a `.env` file with your API keys:

```env
CEREBRAS_API_KEY=your_key
GROQ_API_KEY=your_key
CHUTES_API_KEY=your_key

# Optional — enables data persistence across sessions
SUPABASE_URL=https://your-project.supabase.co
SUPABASE_ANON_KEY=eyJ...
```

Launch:

```bash
aries-os
```

Browser opens automatically at **http://localhost:8888**.

---

## 🔑 API Keys

| Key | Required | Get it from |
|---|---|---|
| `CEREBRAS_API_KEY` | ✅ Yes | [cloud.cerebras.ai](https://cloud.cerebras.ai) |
| `GROQ_API_KEY` | ✅ Recommended | [console.groq.com](https://console.groq.com) |
| `CHUTES_API_KEY` | ⚡ For image / music / video / Deep Research | [chutes.ai](https://chutes.ai) |
| `SUPABASE_URL` + `SUPABASE_ANON_KEY` | Optional | [supabase.com](https://supabase.com) |

---

## ⚙️ Options

```bash
PORT=9000 aries-os      # run on a different port
python -m aries_os      # alternative launch method
```

---

## 🤖 Features

- **AI Chat** — powered by Cerebras (Qwen / Llama), with Groq fallback
- **Deep Research** — multi-model pipeline (DeepSeek V3 + Kimi K2) with live web search
- **AI Coder** — Monaco editor with AI code generation
- **Image Generation** — Chutes image AI
- **Music Generation** — DiffRhythm via Chutes
- **Video Generation** — Wan 2.2 via Chutes
- **Notes, Tasks, Calendar** — with optional Supabase persistence
- **Presentations, Resumes, PDF summaries** — document AI tools
- **Terminal** — run shell commands from the browser

---

## 🗄️ Supabase Setup (Optional)

Without Supabase, the app runs in **in-memory mode** — all data resets on restart.

To enable persistence, create a project at [supabase.com](https://supabase.com) and run this SQL:

```sql
create extension if not exists "uuid-ossp";

create table if not exists public.tasks (
  id uuid primary key default uuid_generate_v4(),
  user_id text not null default 'local',
  title text not null, done boolean not null default false,
  due date, type text default 'task',
  created_at timestamptz default now(), updated_at timestamptz default now()
);

create table if not exists public.notes (
  id uuid primary key default uuid_generate_v4(),
  user_id text not null default 'local',
  content text not null, title text, tags text[] default '{}',
  type text default 'note', created_at timestamptz default now()
);

create table if not exists public.chat_messages (
  id uuid primary key default uuid_generate_v4(),
  user_id text not null default 'local',
  role text not null check (role in ('user', 'assistant', 'system')),
  content text not null, agent text, created_at timestamptz default now()
);

create table if not exists public.user_activity (
  id uuid primary key default uuid_generate_v4(),
  user_id text not null default 'local',
  action text not null, detail text, icon text, created_at timestamptz default now()
);

alter table public.tasks enable row level security;
alter table public.notes enable row level security;
alter table public.chat_messages enable row level security;
alter table public.user_activity enable row level security;

create policy "Allow all" on public.tasks for all using (true);
create policy "Allow all" on public.notes for all using (true);
create policy "Allow all" on public.chat_messages for all using (true);
create policy "Allow all" on public.user_activity for all using (true);
```
