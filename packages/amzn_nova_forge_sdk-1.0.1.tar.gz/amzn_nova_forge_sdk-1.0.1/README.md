# amzn-nova-forge-sdk is now amzn-nova-forge

This package has been renamed. Use `pip install amzn-nova-forge` instead.

New package: https://pypi.org/project/amzn-nova-forge/
