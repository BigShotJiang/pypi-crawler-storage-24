# ylclab-single-cell-metabolomics/tests/test_normalization.py
import os
import json
import numpy as np
import pandas as pd
import pyarrow as pa
import pyarrow.parquet as pq
import pytest
from pathlib import Path
from single_cell_metabolomics.normalization import NormalizationExecutor


# ---------------------------------------------------------------------------
# Fixture — write a tiny 3-sample × 4-feature COO parquet to tmp_path
# ---------------------------------------------------------------------------
@pytest.fixture
def tiny_parquet(tmp_path):
    """6 samples × 5 features — large enough for 2-component PCA."""
    rng = np.random.default_rng(0)
    features = ['f1', 'f2', 'f3', 'f4', 'f5']
    # First 3 samples have deterministic ratios (used by scaling tests)
    intensities = {
        's1': [100.0, 200.0, 300.0, 400.0, 500.0],
        's2': [200.0, 400.0, 600.0, 800.0, 1000.0],  # 2x s1
        's3': [50.0,  100.0, 150.0, 200.0, 250.0],   # 0.5x s1
        's4': rng.uniform(50, 300, len(features)).tolist(),
        's5': rng.uniform(50, 300, len(features)).tolist(),
        's6': rng.uniform(50, 300, len(features)).tolist(),
    }
    rows = []
    for sample, vals in intensities.items():
        for feat, val in zip(features, vals):
            rows.append({'row': feat, 'col': sample, 'value': val})

    df = pd.DataFrame(rows)
    parquet_path = str(tmp_path / 'matrix.parquet')
    pq.write_table(pa.Table.from_pandas(df, preserve_index=False), parquet_path)

    row_tsv = tmp_path / 'row.tsv'
    row_tsv.write_text('feature\n' + '\n'.join(features))
    col_tsv = tmp_path / 'col.tsv'
    col_tsv.write_text('sample\n' + '\n'.join(intensities.keys()))

    return parquet_path, str(row_tsv), str(col_tsv)


def make_executor(tiny_parquet):
    parquet_path, row_path, col_path = tiny_parquet
    return NormalizationExecutor(parquet_path, row_path, col_path, metadata_path='')


# ---------------------------------------------------------------------------
# Tests
# ---------------------------------------------------------------------------

def test_tic_normalization(tiny_parquet):
    """After TIC, each sample should sum to 1e6."""
    ex = make_executor(tiny_parquet)
    ex.normalize('TIC', '', '', '', 'none', False)
    row_sums = ex.adata.X.sum(axis=1)
    np.testing.assert_allclose(row_sums, np.full(ex.adata.n_obs, 1e6), rtol=1e-5)


def test_median_normalization_equalizes_medians(tiny_parquet):
    """After median normalization, all sample sums should be equal."""
    ex = make_executor(tiny_parquet)
    ex.normalize('median', '', '', '', 'none', False)
    row_sums = ex.adata.X.sum(axis=1)
    assert np.std(row_sums) < 1e-6, f"Medians not equalized: {row_sums}"


def test_reference_feature_normalization(tiny_parquet):
    """After reference feature normalization, f1 intensity should be 1.0 for all samples."""
    ex = make_executor(tiny_parquet)
    ex.normalize('referenceFeature', 'f1', '', '', 'none', False)
    f1_idx = list(ex.adata.var_names).index('f1')
    f1_values = ex.adata.X[:, f1_idx]
    np.testing.assert_allclose(f1_values, np.ones(ex.adata.n_obs), rtol=1e-5)


def test_reference_feature_missing_raises(tiny_parquet):
    """Should raise ValueError if reference feature not in dataset."""
    ex = make_executor(tiny_parquet)
    with pytest.raises(ValueError, match="not found"):
        ex.normalize('referenceFeature', 'nonexistent_feature', '', '', 'none', False)


def test_transformation_log1p(tiny_parquet):
    """Log1p should equal log(x+1) element-wise."""
    ex = make_executor(tiny_parquet)
    original = ex.adata.X.copy()
    ex.normalize('none', '', '', '', 'log1p', False)
    expected = np.log(original + 1.0)
    np.testing.assert_allclose(ex.adata.X, expected, rtol=1e-5)


def test_transformation_arcsinh(tiny_parquet):
    """Arcsinh should equal np.arcsinh element-wise."""
    ex = make_executor(tiny_parquet)
    original = ex.adata.X.copy()
    ex.normalize('none', '', '', '', 'arcsinh', False)
    np.testing.assert_allclose(ex.adata.X, np.arcsinh(original), rtol=1e-5)


def test_zscore_clips_at_10(tiny_parquet):
    """Z-score should clip values at max_value=10, and produce ~zero column means."""
    ex = make_executor(tiny_parquet)
    ex.normalize('none', '', '', '', 'none', True)
    assert ex.adata.X.max() <= 10.0 + 1e-6
    # Column means should be approximately 0 (z-score centers each feature)
    col_means = ex.adata.X.mean(axis=0)
    np.testing.assert_allclose(col_means, np.zeros(len(col_means)), atol=1e-6)
    # Column stds should be <= 1.0 (clipping can only reduce variance, never increase it)
    col_stds = ex.adata.X.std(axis=0)
    assert col_stds.max() <= 1.0 + 1e-6, f"Z-score std exceeds 1.0: {col_stds.max()}"


def test_pqn_normalization(tiny_parquet):
    """PQN normalization: the median quotient of each sample relative to the reference should be 1."""
    ex = make_executor(tiny_parquet)
    original_X = ex.adata.X.copy()
    ex.normalize('PQN', '', '', '', 'none', False)
    # Compute reference spectrum (median of original rows)
    reference = np.median(original_X, axis=0)
    reference = np.where(reference == 0, 1e-10, reference)
    # For each sample, the median quotient relative to the reference should be ~1
    for i in range(ex.adata.n_obs):
        quotients = ex.adata.X[i, :] / reference
        median_quotient = np.median(quotients)
        np.testing.assert_allclose(
            median_quotient, 1.0, rtol=1e-4,
            err_msg=f"Sample {i} median quotient should be 1.0 after PQN"
        )


def test_transformation_log2(tiny_parquet):
    """Log2 should equal log2(x+1) element-wise."""
    ex = make_executor(tiny_parquet)
    original = ex.adata.X.copy()
    ex.normalize('none', '', '', '', 'log2', False)
    expected = np.log2(original + 1.0)
    np.testing.assert_allclose(ex.adata.X, expected, rtol=1e-5)


def test_transformation_sqrt(tiny_parquet):
    """Square root should equal sqrt(x) element-wise."""
    ex = make_executor(tiny_parquet)
    original = ex.adata.X.copy()
    ex.normalize('none', '', '', '', 'sqrt', False)
    expected = np.sqrt(np.maximum(original, 0.0))
    np.testing.assert_allclose(ex.adata.X, expected, rtol=1e-5)


def test_zscore_parquet_preserves_zeros(tiny_parquet, tmp_path):
    """After z-score, write_normalized_parquet must write all values including zeros."""
    ex = make_executor(tiny_parquet)
    ex.normalize('TIC', '', '', '', 'none', True)
    out_path = str(tmp_path / 'out.parquet')
    ex.write_normalized_parquet(out_path)
    out_df = pq.read_table(out_path).to_pandas()
    # The parquet must have rows for all (sample, feature) pairs that are finite
    n_finite = np.isfinite(ex.adata.X).sum()
    assert len(out_df) == n_finite, (
        f"Expected {n_finite} rows (all finite values), got {len(out_df)}"
    )


def test_violin_downsampling_limits(tiny_parquet):
    """Violin data should have at most 50 samples x 500 features per sample."""
    ex = make_executor(tiny_parquet)
    violin = ex.capture_violin_data()
    assert len(violin) <= 50
    for values in violin.values():
        assert len(values) <= 500


def test_pca_output_shape(tiny_parquet):
    """PCA output should have pc1, pc2 arrays and variance_ratio of length 2."""
    ex = make_executor(tiny_parquet)
    ex.normalize('TIC', '', '', '', 'arcsinh', False)
    pca_data = ex.compute_pca_data(pca_color_label='')
    assert len(pca_data['pca']['pc1']) <= 1000
    assert len(pca_data['pca']['pc1']) == len(pca_data['pca']['pc2'])
    assert len(pca_data['pca_variance_ratio']) == 2


def test_emit_sentinel_writes_file(tiny_parquet, tmp_path, monkeypatch):
    """emit_sentinel should write normalization_metadata.json with all required fields."""
    monkeypatch.chdir(tmp_path)
    parquet_path, row_path, col_path = tiny_parquet
    ex = NormalizationExecutor(parquet_path, row_path, col_path, metadata_path='')
    violin_before = ex.capture_violin_data()
    ex.normalize('TIC', '', '', '', 'arcsinh', False)
    violin_after = ex.capture_violin_data()
    pca_data = ex.compute_pca_data('')
    ex.emit_sentinel(
        serial_number='TEST001', dataset_uid=1, analysis_id=102,
        storage_path='normalized.parquet', row_path=row_path, column_path=col_path,
        scaling_method='TIC', transformation='arcsinh', do_z_score=False,
        violin_before=violin_before, violin_after=violin_after, pca_data=pca_data,
    )
    sentinel_file = tmp_path / 'normalization_metadata.json'
    assert sentinel_file.exists()
    sentinel = json.loads(sentinel_file.read_text())
    for field in ['serial_number', 'dataset_uid', 'pipeline_stage', 'analysis_id',
                   'storage_path', 'row_path', 'column_path',
                   'scaling_method', 'transformation',
                   'violin_before', 'violin_after', 'pca', 'pca_variance_ratio', 'status']:
        assert field in sentinel, f"Missing field: {field}"
    assert sentinel['status'] == 'completed'
    assert sentinel['storage_path'].startswith('/')
