import os  # Used in Task 2 tests
import json  # Used in Task 2 tests
import pytest
import pyarrow as pa
import pyarrow.parquet as pq
from pathlib import Path
from typer.testing import CliRunner
from single_cell_metabolomics.filtration import FilterExecutor, app


@pytest.fixture
def tmp_inputs(tmp_path):
    """Create minimal sparse matrix fixtures: 3 samples, 4 features, 2 NAs."""
    # matrix_data: COO format, col=sample, row=feature
    # sample 0: features 0,1,2 (3 features)
    # sample 1: features 0,1,2,3 (4 features)
    # sample 2: features 1,2,3 (3 features)
    rows = [0,1,2, 0,1,2,3, 1,2,3]
    cols = [0,0,0, 1,1,1,1, 2,2,2]
    vals = [1.0]*10
    table = pa.table({"row": rows, "col": cols, "value": vals})
    parquet_path = str(tmp_path / "matrix.parquet")
    pq.write_table(table, parquet_path)

    row_tsv = tmp_path / "row.tsv"
    row_tsv.write_text("index\tmode\tmass\n0\tpos\t100.0\n1\tpos\t200.0\n2\tpos\t300.0\n3\tpos\t400.0\n")

    col_tsv = tmp_path / "col.tsv"
    col_tsv.write_text("index\tsample\n0\tS1\n1\tS2\n2\tS3\n")

    meta_csv = tmp_path / "meta.csv"
    meta_csv.write_text("sample,label\nS1,sc\nS2,sc\nS3,sc\n")

    return str(parquet_path), str(row_tsv), str(col_tsv), str(meta_csv)


def test_compute_stats_before_counts(tmp_inputs):
    parquet, row, col, meta = tmp_inputs
    fe = FilterExecutor(parquet, row, col, meta)
    stats = fe.compute_stats_before()
    fe.close()
    assert stats["before_sample_count"] == 3
    assert stats["before_feature_count"] == 4
    # total cells = 3*4=12, non-NA = 10, NA = 2
    assert stats["before_na_count"] == 2
    assert sorted(stats["features_per_sample_before"]) == [3, 3, 4]
    assert sorted(stats["samples_per_feature_before"]) == [2, 2, 3, 3]


def test_compute_stats_after_counts(tmp_inputs):
    parquet, row, col, meta = tmp_inputs
    fe = FilterExecutor(parquet, row, col, meta)
    # Filter: min 4 features per sample removes samples 0 and 2 (they only have 3 features each);
    # min 1 sample per feature keeps all 4 features (each appears in at least 1 sample).
    # Converges to: 1 sample (sample 1), 4 features (0,1,2,3).
    fe.filter_strict_min_counts(min_features_for_sample=4, min_samples_for_feature=1)
    fe.remove_unused_features()
    fe.remove_unused_samples()
    stats = fe.compute_stats_after()
    fe.close()
    assert stats["after_sample_count"] == 1   # only sample 1 remains
    assert stats["after_feature_count"] == 4  # all features remain (each in ≥1 sample)
    assert stats["after_na_count"] == 0       # sample 1 has all 4 features, fully dense
    assert len(stats["features_per_sample_after"]) == stats["after_sample_count"]
    assert len(stats["samples_per_feature_after"]) == stats["after_feature_count"]


def test_emit_sentinel_writes_json_file(tmp_inputs, tmp_path, monkeypatch):
    """emit_sentinel() writes filtration_metadata.json with correct fields."""
    parquet, row, col, meta = tmp_inputs
    fe = FilterExecutor(parquet, row, col, meta)
    fe.close()

    # Change working dir to tmp_path so the output file lands there
    monkeypatch.chdir(tmp_path)

    stats_before = {
        "before_sample_count": 3,
        "before_feature_count": 4,
        "before_na_count": 2,
        "features_per_sample_before": [3, 4, 3],
        "samples_per_feature_before": [2, 3, 3, 2],
    }
    stats_after = {
        "after_sample_count": 1,
        "after_feature_count": 4,
        "after_na_count": 0,
        "features_per_sample_after": [4],
        "samples_per_feature_after": [1, 1, 1, 1],
    }

    fe.emit_sentinel(
        serial_number="TEST001",
        dataset_uid=42,
        analysis_id=101,
        storage_path="output.parquet",
        row_path="row_feature_names.tsv",
        column_path="column_sample_names.tsv",
        stats_before=stats_before,
        stats_after=stats_after,
    )

    sentinel_file = tmp_path / "filtration_metadata.json"
    assert sentinel_file.exists(), "filtration_metadata.json was not created"

    with open(sentinel_file) as f:
        data = json.load(f)

    assert data["serial_number"] == "TEST001"
    assert data["dataset_uid"] == 42
    assert data["analysis_id"] == 101
    assert data["pipeline_stage"] == "analysis"
    assert data["status"] == "completed"
    assert data["storage_path"].startswith("/"), "storage_path must be absolute"
    assert data["row_path"].startswith("/"), "row_path must be absolute"
    assert data["column_path"].startswith("/"), "column_path must be absolute"


def test_filter_and_mask_cli_produces_sentinel(tmp_inputs, tmp_path, monkeypatch):
    """filter_and_mask CLI with --analysis-id produces filtration_metadata.json."""
    parquet, row, col, meta = tmp_inputs
    output_parquet = str(tmp_path / "filtered.parquet")
    output_row = str(tmp_path / "row_out.tsv")
    output_col = str(tmp_path / "col_out.tsv")

    # Change working dir so filtration_metadata.json lands in tmp_path
    monkeypatch.chdir(tmp_path)

    runner = CliRunner()
    result = runner.invoke(app, [
        "filter-and-mask",
        "--serial-number", "TEST001",
        "--dataset-uid", "1",
        "--analysis-id", "101",
        "--parquet-path", parquet,
        "--row-path", row,
        "--column-path", col,
        "--metadata-path", meta,
        "--min-sample-number", "1",
        "--min-feature-number", "1",
        "--output-parquet-path", output_parquet,
        "--output-row-path", output_row,
        "--output-column-path", output_col,
    ])

    assert result.exit_code == 0, f"CLI exited with code {result.exit_code}:\n{result.output}"

    sentinel_file = tmp_path / "filtration_metadata.json"
    assert sentinel_file.exists(), "filtration_metadata.json was not created by CLI"

    with open(sentinel_file) as f:
        data = json.load(f)

    assert data["analysis_id"] == 101
    assert data["serial_number"] == "TEST001"
    assert data["pipeline_stage"] == "analysis"
    assert data["status"] == "completed"
    assert data["storage_path"].startswith("/"), "storage_path must be an absolute path"
    assert "before_sample_count" in data
    assert "after_sample_count" in data
