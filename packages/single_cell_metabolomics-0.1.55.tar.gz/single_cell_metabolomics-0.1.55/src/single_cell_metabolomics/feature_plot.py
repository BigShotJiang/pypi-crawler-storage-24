import json
import os
import sys

import duckdb
import numpy as np
import pandas as pd
import pyarrow as pa
import pyarrow.parquet as pq
import typer
from loguru import logger

app = typer.Typer(add_completion=False)

_DOWNSAMPLE_SEED = 42
_MAX_CELLS = 1000


class FeaturePlotExecutor:
    def __init__(
        self,
        parquet_path: str,
        row_path: str,
        column_path: str,
        dr_parquet_path: str,
    ):
        # Load intensity matrix (cells × features)
        conn = duckdb.connect(database=':memory:')
        conn.read_parquet(parquet_path).create('matrix_data')
        df = conn.sql(
            'SELECT col, row, COALESCE(value, 0.0) AS value FROM matrix_data'
        ).to_df()
        conn.close()
        dense = df.pivot(index='col', columns='row', values='value').fillna(0.0)

        self.cell_names: list[str] = dense.index.tolist()
        self.feature_names: list[str] = dense.columns.tolist()
        self.X: np.ndarray = dense.values.astype(np.float64)  # (n_cells, n_features)

        # Load DR embedding
        dr_df = pd.read_parquet(dr_parquet_path)
        # Align DR embedding to matrix cell order
        dr_indexed = dr_df.set_index('cell_name')
        self.dr_x = [float(dr_indexed.loc[c, 'component_1']) if c in dr_indexed.index else 0.0 for c in self.cell_names]
        self.dr_y = [float(dr_indexed.loc[c, 'component_2']) if c in dr_indexed.index else 0.0 for c in self.cell_names]

    def compute_stats_before(self) -> dict:
        return {
            'n_cells': len(self.cell_names),
            'n_features': len(self.feature_names),
        }

    def resolve_features(self, feature_list: str) -> list[str]:
        """Parse comma-separated names or 1-based indices. No mixing allowed."""
        if not feature_list or not feature_list.strip():
            return []

        entries = [e.strip() for e in feature_list.split(',') if e.strip()]
        if not entries:
            return []

        # Detect mode: all integers = index mode; else name mode
        def is_int(s: str) -> bool:
            try:
                int(s)
                return True
            except ValueError:
                return False

        if all(is_int(e) for e in entries):
            # 1-based index mode
            resolved = []
            for e in entries:
                idx = int(e) - 1  # convert to 0-based
                if 0 <= idx < len(self.feature_names):
                    resolved.append(self.feature_names[idx])
                else:
                    logger.warning(f"Index {e} out of range (1–{len(self.feature_names)}), skipping")
            return resolved
        else:
            # Name mode
            name_set = set(self.feature_names)
            resolved = []
            for e in entries:
                if e in name_set:
                    resolved.append(e)
                else:
                    logger.warning(f"Feature '{e}' not found in dataset, skipping")
            return resolved

    def build_scatter_plots(self, resolved_features: list[str], accumulate: bool) -> list[dict]:
        """Build downsampled scatter plot data for each feature (or accumulated)."""
        if not resolved_features:
            return []

        n_cells = len(self.cell_names)
        if n_cells > _MAX_CELLS:
            rng = np.random.default_rng(_DOWNSAMPLE_SEED)
            indices = rng.choice(n_cells, size=_MAX_CELLS, replace=False)
            indices = sorted(indices)
        else:
            indices = list(range(n_cells))

        sampled_cells = [self.cell_names[i] for i in indices]
        sampled_x = [self.dr_x[i] for i in indices]
        sampled_y = [self.dr_y[i] for i in indices]

        feature_idx_map = {name: i for i, name in enumerate(self.feature_names)}

        if accumulate:
            # Sum all selected feature intensities per cell
            accumulated = np.zeros(len(indices), dtype=np.float64)
            for feat in resolved_features:
                fi = feature_idx_map[feat]
                accumulated += self.X[indices, fi]
            title = 'Accumulated: ' + ', '.join(resolved_features[:5])
            if len(resolved_features) > 5:
                title += f', ... ({len(resolved_features)} features)'
            return [{
                'title': title,
                'x': sampled_x,
                'y': sampled_y,
                'intensity': accumulated.tolist(),
                'cell_names': sampled_cells,
            }]
        else:
            plots = []
            for feat in resolved_features:
                fi = feature_idx_map[feat]
                intensity = self.X[indices, fi].tolist()
                plots.append({
                    'title': feat,
                    'x': sampled_x,
                    'y': sampled_y,
                    'intensity': intensity,
                    'cell_names': sampled_cells,
                })
            return plots

    def compute_stats_after(
        self,
        feature_list: str,
        accumulate: str,
        resolved_features: list[str],
        scatter_plots: list[dict],
    ) -> dict:
        n_plotted = len(scatter_plots[0]['x']) if scatter_plots else 0
        return {
            'feature_list': feature_list,
            'accumulate': accumulate,
            'resolved_features': resolved_features,
            'n_features': len(resolved_features),
            'n_cells_plotted': n_plotted,
            'scatter_plots': scatter_plots,
        }

    def emit_sentinel(
        self,
        serial_number: str,
        dataset_uid: int,
        analysis_id: int,
        storage_path: str,
        stats_before: dict,
        stats_after: dict,
    ) -> None:
        sentinel = {
            'serial_number': serial_number,
            'dataset_uid': dataset_uid,
            'pipeline_stage': 'analysis',
            'analysis_id': analysis_id,
            'storage_path': os.path.abspath(storage_path),
            'status': 'completed',
            **stats_before,
            **stats_after,
        }
        json_str = json.dumps(sentinel)
        print(f'__FEATURE_PLOT_METADATA_START__{json_str}__FEATURE_PLOT_METADATA_END__')
        with open('feature_plot_metadata.json', 'w') as f:
            json.dump(sentinel, f)
        logger.success('Feature plot sentinel written.')


@app.command()
def plot(
    serial_number: str = '',
    dataset_uid: int = 0,
    # --- input paths (infrastructure, not parameters) ---
    parquet_path: str = '',
    row_path: str = '',
    column_path: str = '',
    dr_parquet_path: str = '',
    # --- analysis ID (required for sentinel) ---
    analysis_id: int = typer.Option(..., help="Analysis ID (e.g. 106 for SC feature plotting, 206 for LCM)"),
    # --- analysis parameters (match analysisParameterConfig.js parameterName in snake_case) ---
    feature_list: str = '',
    accumulate: str = 'false',
    # --- output paths ---
    output_feature_plot_path: str = 'feature_plot_metadata.json',
):
    """Visualize feature intensities on the dimensionality-reduction embedding scatter map."""
    logger.info(f'Starting feature plot for serial={serial_number}, dataset_uid={dataset_uid}, analysis_id={analysis_id}')
    logger.info(f'feature_list={feature_list!r}, accumulate={accumulate!r}')

    executor = FeaturePlotExecutor(
        parquet_path=parquet_path,
        row_path=row_path,
        column_path=column_path,
        dr_parquet_path=dr_parquet_path,
    )

    stats_before = executor.compute_stats_before()
    logger.info(f'Stats before: {stats_before}')

    resolved_features = executor.resolve_features(feature_list)
    logger.info(f'Resolved {len(resolved_features)} feature(s): {resolved_features[:10]}')

    do_accumulate = accumulate.lower() == 'true'
    scatter_plots = executor.build_scatter_plots(resolved_features, do_accumulate)
    logger.info(f'Built {len(scatter_plots)} scatter plot(s)')

    stats_after = executor.compute_stats_after(feature_list, accumulate, resolved_features, scatter_plots)

    executor.emit_sentinel(
        serial_number=serial_number,
        dataset_uid=dataset_uid,
        analysis_id=analysis_id,
        storage_path=output_feature_plot_path,
        stats_before=stats_before,
        stats_after=stats_after,
    )

    logger.success('Feature plot complete.')


@app.callback()
def callback():
    pass


if __name__ == '__main__':
    app()
