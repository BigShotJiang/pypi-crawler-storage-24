"""
EAISports CLI - Unified command-line interface for EAISports.

Provides subcommands for:
- eaisports chat          - Interactive chat (same as ./eaisports)
- eaisports gateway       - Run gateway in foreground
- eaisports gateway start - Start gateway service
- eaisports gateway stop  - Stop gateway service  
- eaisports setup         - Interactive setup wizard
- eaisports status        - Show status of all components
- eaisports cron          - Manage cron jobs
"""

__version__ = "0.1.9"
