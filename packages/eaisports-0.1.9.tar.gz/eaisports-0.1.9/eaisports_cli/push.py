"""
EAISports Push Command -- deploy a game to the EAISports platform.

Bundles the built game (dist/) into a tarball and uploads it to the
EAISports deploy API.

Usage (from CLI):
    eaisports push                  # pick a game interactively
    eaisports push my-trivia-game   # push a specific game by slug
"""

import logging
import subprocess
import sys
import tarfile
import tempfile
from pathlib import Path

import requests

from eaisports_cli.colors import Colors, color
from eaisports_cli.config import load_config, get_eaisports_home

logger = logging.getLogger(__name__)

DEFAULT_API_URL = "https://api.eaisports.ai"


# =========================================================================
# Bundle helper
# =========================================================================

def _create_bundle(game_dir: Path) -> Path:
    """Create a tarball of the game's dist/ directory.

    Returns the path to the temporary .tar.gz file.  The caller is
    responsible for cleaning it up.
    """
    dist_dir = game_dir / "dist"
    if not dist_dir.exists() or not any(dist_dir.iterdir()):
        raise FileNotFoundError(f"No dist/ directory found in {game_dir}")

    tmp = tempfile.NamedTemporaryFile(
        suffix=".tar.gz", prefix="eaisports-bundle-", delete=False
    )
    tmp.close()
    bundle_path = Path(tmp.name)

    with tarfile.open(bundle_path, "w:gz") as tar:
        tar.add(dist_dir, arcname="dist")

    logger.debug("Bundle created: %s", bundle_path)
    return bundle_path


# =========================================================================
# Push command
# =========================================================================

def run_push(slug: str = None, api_url: str = None) -> None:
    """Bundle and deploy a game to the EAISports platform.

    Parameters
    ----------
    slug:
        Game slug (directory name under ``~/.eaisports/games/``).
        If *None*, the most-recently-modified game is used.
    api_url:
        Base URL for the EAISports API.  Defaults to ``DEFAULT_API_URL``.
    """
    api_url = api_url or DEFAULT_API_URL
    config = load_config()
    home = get_eaisports_home()

    # -- Resolve wallet
    wallet_address = config.get("wallet_address")
    if not wallet_address:
        print(color("  Configure your wallet first: `eaisports init`", Colors.RED))
        sys.exit(1)

    # -- Resolve game directory
    games_root = home / "games"
    if slug:
        game_dir = games_root / slug
    else:
        # Pick the most-recently-modified game directory
        if not games_root.exists():
            print(color("  No games found. Run `eaisports build` first.", Colors.RED))
            sys.exit(1)
        candidates = sorted(
            [d for d in games_root.iterdir() if d.is_dir()],
            key=lambda d: d.stat().st_mtime,
            reverse=True,
        )
        if not candidates:
            print(color("  No games found. Run `eaisports build` first.", Colors.RED))
            sys.exit(1)
        game_dir = candidates[0]
        slug = game_dir.name

    if not game_dir.exists():
        print(color(f"  Game not found: {game_dir}", Colors.RED))
        sys.exit(1)

    print(color(f"  Deploying game: {slug}", Colors.CYAN))
    print(color(f"  Game directory: {game_dir}", Colors.DIM))

    # -- Build the game
    print(color("  Running build...", Colors.DIM))
    try:
        subprocess.run(
            ["npm", "run", "build"],
            cwd=game_dir,
            check=True,
            capture_output=True,
            text=True,
        )
    except subprocess.CalledProcessError as exc:
        print(color("  Build failed. Run `eaisports preview` to debug.", Colors.RED))
        if exc.stderr:
            print(color(f"  {exc.stderr.strip()}", Colors.DIM))
        sys.exit(1)

    dist_dir = game_dir / "dist"
    if not dist_dir.exists() or not any(dist_dir.iterdir()):
        print(color("  Build failed. Run `eaisports preview` to debug.", Colors.RED))
        sys.exit(1)

    print(color("  Build complete.", Colors.GREEN))

    # -- Create bundle
    print(color("  Creating bundle...", Colors.DIM))
    try:
        bundle_path = _create_bundle(game_dir)
    except FileNotFoundError:
        print(color("  Build failed. Run `eaisports preview` to debug.", Colors.RED))
        sys.exit(1)

    # -- Upload to deploy API
    print(color("  Uploading to EAISports...", Colors.DIM))
    deploy_url = f"{api_url}/api/games/deploy"

    try:
        with open(bundle_path, "rb") as bundle_file:
            resp = requests.post(
                deploy_url,
                headers={"X-Wallet-Address": wallet_address},
                files={"bundle": ("bundle.tar.gz", bundle_file, "application/gzip")},
                data={"slug": slug, "wallet_address": wallet_address},
                timeout=120,
            )

        if resp.status_code == 200:
            data = resp.json()
            live_url = data.get("url", f"https://eaisports.ai/games/{slug}")
            tokens = data.get("tokens_earned", 0)

            print()
            print(color("  Game deployed!", Colors.GREEN, Colors.BOLD))
            print(color(f"  Live URL: {live_url}", Colors.CYAN))
            print(color(f"  Share: Check out my game on EAISports! {live_url}", Colors.DIM))
            if tokens:
                print(color(f"  Points earned: +{tokens} pts", Colors.YELLOW))
            print()
        else:
            error_msg = ""
            try:
                error_msg = resp.json().get("error", resp.text)
            except Exception:
                error_msg = resp.text
            print(color(f"  Deploy failed ({resp.status_code}): {error_msg}", Colors.RED))
            sys.exit(1)

    except requests.ConnectionError:
        print(color("  Could not reach the EAISports API. Check your connection.", Colors.RED))
        sys.exit(1)
    except requests.Timeout:
        print(color("  Request timed out. Try again later.", Colors.RED))
        sys.exit(1)
    except requests.RequestException as exc:
        print(color(f"  Network error: {exc}", Colors.RED))
        sys.exit(1)
    finally:
        # -- Clean up the tarball
        try:
            bundle_path.unlink(missing_ok=True)
            logger.debug("Cleaned up bundle: %s", bundle_path)
        except OSError:
            pass
