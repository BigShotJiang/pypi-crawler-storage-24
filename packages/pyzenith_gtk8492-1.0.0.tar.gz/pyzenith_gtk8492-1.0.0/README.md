# PyZenith UI Framework

PyZenith is an advanced, high-performance UI/UX framework for Python designed to mirror the capabilities of Java's UI libraries with added complex logic and systems.

## Key Features

- **Advanced Rendering Engine**: Canvas-based rendering with layer management, event propagation, and layout managers (Flex, Absolute).
- **Reactive State Management**: Observable states with computed properties, validation, middleware, and persistence.
- **Sophisticated Animation System**: Easing functions (Cubic, Bounce, Spring), keyframes, and chained sequences.
- **Robust Component Library**: Buttons, TextFields, ProgressBars, Panels, and Vector Icons.
- **Comprehensive Testing Framework**: Built-in unit, integration, and performance testing systems.
- **Cross-Platform OS Handler**: Unified API for Windows, macOS, and Linux, including a dedicated Linux environment installer.
- **Intelligent Error Advisory**: Global exception interceptor with contextual documentation and fix suggestions.
- **Modern Networking & Web Engine**: High-performance HTTP client and a custom HTML/DOM browser engine.
- **Integrated Database ORM**: High-level ORM for thread-safe data persistence and querying.
- **Multimedia Suite**: Asynchronous audio engine and centralized asset management.

## Installation

```bash
pip install pyzenith
```

## Structure

- `pyzenith/core`: Rendering engine, layer management, and base `Widget`.
- `pyzenith/components`: Stateful UI components (Button, TextField, etc.).
- `pyzenith/logic`: Reactive state management and data binding.
- `pyzenith/systems`: Animation, event, and layout systems.
- `pyzenith/database`: Thread-safe ORM and database engine.
- `pyzenith/multimedia`: Async audio and asset pipelines.
- `pyzenith/network`: HTTP client and web browser engine.
- `pyzenith/os_system`: Cross-platform handlers and installers.
- `pyzenith/errors`: Intelligent error advisor and handler.
- `pyzenith/testing`: Test framework and integration runner.

## Example Code

```python
from pyzenith.core.engine import PyZenithEngine
from pyzenith.components.basic import Button, Label

engine = PyZenithEngine("PyZenith Pro Application", 1280, 720)
label = Label("Welcome to PyZenith", 100, 100)
button = Button("Click Me", 100, 150)

engine.add_widget(label)
engine.add_widget(button)
engine.run()
```

## License

MIT License. See `LICENSE` for details.

## Author

GTK8492
