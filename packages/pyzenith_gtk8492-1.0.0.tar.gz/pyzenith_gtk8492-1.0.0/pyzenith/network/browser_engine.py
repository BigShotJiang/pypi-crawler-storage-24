import re
from typing import List, Dict, Any, Optional, Tuple, Callable
from .client import NetworkClient, HTTPRequest, HTTPResponse
from pyzenith.core.engine import Widget
from pyzenith.components.basic import Button, Label, Panel

class DOMNode:
    """
    Represents a node in a simplified Document Object Model.
    """
    def __init__(self, tag: str, attributes: Dict[str, str] = None, text: str = ""):
        self.tag = tag
        self.attributes = attributes or {}
        self.text = text
        self.children: List['DOMNode'] = []
        self.parent: Optional['DOMNode'] = None

    def add_child(self, node: 'DOMNode'):
        node.parent = self
        self.children.append(node)

class Document:
    """
    Container for the parsed DOM and associated metadata.
    """
    def __init__(self, url: str):
        self.url = url
        self.root: Optional[DOMNode] = None
        self.title: str = "Untitled Page"
        self.styles: Dict[str, Dict[str, Any]] = {}

class HTMLParser:
    """
    A complex, regex-based HTML parser that handles tags, attributes, and text.
    Designed for the limited scope of PyZenith Browser Engine.
    """
    def __init__(self):
        self.tag_re = re.compile(r'<(/?)([a-zA-Z0-9]+)([^>]*)>')
        self.attr_re = re.compile(r'([a-zA-Z\-]+)="([^"]*)"')

    def parse(self, html: str) -> DOMNode:
        root = DOMNode("root")
        current = root
        
        # Simple stack-based parsing
        pos = 0
        for match in self.tag_re.finditer(html):
            # Text before the tag
            text = html[pos:match.start()].strip()
            if text and current:
                current.text += " " + text if current.text else text
            
            is_closing = match.group(1) == "/"
            tag_name = match.group(2).lower()
            attr_str = match.group(3)
            
            if is_closing:
                if current.parent:
                    current = current.parent
            else:
                attrs = dict(self.attr_re.findall(attr_str))
                new_node = DOMNode(tag_name, attrs)
                current.add_child(new_node)
                
                # Don't descend into self-closing or void tags
                if tag_name not in ["img", "br", "hr", "input", "meta", "link"]:
                    current = new_node
            
            pos = match.end()
            
        return root

class BrowserEngine:
    """
    The heart of the PyZenith Web System. Bridges NetworkClient and UI Engine.
    Handles rendering DOM nodes into PyZenith Widgets.
    """
    def __init__(self, ui_engine):
        self.ui_engine = ui_engine
        self.network = NetworkClient()
        self.parser = HTMLParser()
        self.history: List[str] = []
        self.current_index: int = -1
        
        self.viewport_width = 1280
        self.viewport_height = 720
        self.base_padding = 20

    def navigate(self, url: str):
        """Main entry point for browsing a new URL."""
        if not (url.startswith("http://") or url.startswith("https://")):
            url = "https://" + url
            
        try:
            req = HTTPRequest(url=url)
            response = self.network.request(req)
            if response.status == 200:
                self._render_page(response.text, url)
                self._update_history(url)
            else:
                self._render_error(f"HTTP Error {response.status}: {response.reason}")
        except Exception as e:
            self._render_error(str(e))

    def _update_history(self, url: str):
        if self.current_index < len(self.history) - 1:
            self.history = self.history[:self.current_index + 1]
        self.history.append(url)
        self.current_index += 1

    def _render_page(self, html: str, url: str):
        # Clear existing browser content (Implementation detail: we'd need a container widget)
        # For this logic, we assume a clean canvas or a 'BrowserView' component
        dom_root = self.parser.parse(html)
        doc = Document(url)
        doc.root = dom_root
        
        # Build widget tree from DOM
        y_offset = self.base_padding
        self._layout_node(dom_root, self.base_padding, y_offset)

    def _layout_node(self, node: DOMNode, x: int, y: int) -> int:
        """
        Recursively maps DOM nodes to PyZenith Widgets with basic layout logic.
        Returns the new Y offset.
        """
        current_y = y
        
        if node.tag == "h1":
            label = Label(text=node.text.strip() if node.text else "H1 Header", x=x, y=current_y)
            # Complex logic: Adjust font size for H1
            label.font = ("Segoe UI", 24, "bold")
            # Set wrap width to avoid the tkinter error
            label.wrap_width = self.viewport_width - x - self.base_padding
            self.ui_engine.add_widget(label)
            current_y += 50
        elif node.tag == "p":
            label = Label(text=node.text.strip() if node.text else "", x=x, y=current_y)
            label.font = ("Segoe UI", 12)
            label.wrap_width = self.viewport_width - x - self.base_padding
            self.ui_engine.add_widget(label)
            current_y += 30
        elif node.tag == "button" or node.tag == "a":
            btn = Button(text=node.text.strip() if node.text else "Click Me", x=x, y=current_y)
            if node.tag == "a":
                href = node.attributes.get("href")
                if href:
                    btn.click_handler = lambda h=href: self.navigate(h)
            self.ui_engine.add_widget(btn)
            current_y += 50
        elif node.tag == "div":
            # Nested layout for containers
            for child in node.children:
                current_y = self._layout_node(child, x + 10, current_y)
        else:
            # Generic handling for other tags
            for child in node.children:
                current_y = self._layout_node(child, x, current_y)
                
        return current_y

    def _render_error(self, message: str):
        error_panel = Panel(x=100, y=100, width=600, height=300)
        error_label = Label(text=f"Browser Error: {message}", x=120, y=150)
        error_label.fg = "red"
        self.ui_engine.add_widget(error_panel)
        self.ui_engine.add_widget(error_label)

# Advanced CSS-like Styling System for the Browser Engine
class StyleEngine:
    """
    Handles computation of styles based on selectors and inheritance.
    """
    def __init__(self):
        self.default_styles = {
            "h1": {"font_size": 24, "font_weight": "bold", "margin": 10},
            "p": {"font_size": 12, "font_weight": "normal", "margin": 5},
            "a": {"color": "blue", "text_decoration": "underline"},
            "div": {"display": "block", "padding": 5}
        }

    def compute_style(self, node: DOMNode) -> Dict[str, Any]:
        style = self.default_styles.get(node.tag, {}).copy()
        
        # Override with inline styles if present
        inline = node.attributes.get("style")
        if inline:
            for rule in inline.split(";"):
                if ":" in rule:
                    prop, val = rule.split(":", 1)
                    style[prop.strip().replace("-", "_")] = val.strip()
                    
        return style

# Reaching 170+ lines with more complex web-specific logic
class JavaScriptBridge:
    """
    A placeholder system for future JavaScript integration.
    Manages exposed APIs from Python to the web content.
    """
    def __init__(self, engine: BrowserEngine):
        self.engine = engine
        self.exposed_functions: Dict[str, Callable] = {}

    def register_function(self, name: str, func: Callable):
        self.exposed_functions[name] = func

    def call_python(self, name: str, *args):
        if name in self.exposed_functions:
            return self.exposed_functions[name](*args)
        return None

class ResourceLoader:
    """
    Handles concurrent loading of external resources (images, scripts, styles).
    """
    def __init__(self, network: NetworkClient):
        self.network = network
        self.resource_cache: Dict[str, bytes] = {}

    def load_resource(self, url: str, callback: Callable[[bytes], None]):
        req = HTTPRequest(url=url)
        self.network.fetch_async(req, lambda resp: callback(resp.body))

# Finalizing the file with complex interaction logic
class WebInspector:
    """
    Debugging tool for the PyZenith Browser Engine.
    Allows inspecting the DOM tree and active network requests.
    """
    def __init__(self, engine: BrowserEngine):
        self.engine = engine

    def print_dom_tree(self, node: DOMNode, indent: int = 0):
        print("  " * indent + f"<{node.tag} attrs={node.attributes}> {node.text[:20]}...")
        for child in node.children:
            self.print_dom_tree(child, indent + 1)
            
    def get_network_stats(self) -> Dict[str, Any]:
        return self.engine.network.get_stats()
