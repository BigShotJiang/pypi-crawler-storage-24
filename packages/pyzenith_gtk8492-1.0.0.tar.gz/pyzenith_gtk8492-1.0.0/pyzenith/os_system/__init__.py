from .handler import OSHandler
from .installer import LinuxInstaller

__all__ = ['OSHandler', 'LinuxInstaller']

def get_os_handler():
    return OSHandler()

def setup_linux():
    installer = LinuxInstaller()
    installer.full_setup()
