# PyZenith Testing System
# Initializing the testing package

from .framework import TestCase, TestResult, TestSuite, assert_equal, assert_true, assert_false
from .runner import TestRunner, TestLogger

__version__ = "1.0.0"
