from pyzenith.errors.handler import PyZenithErrorHandler, ErrorContext
from pyzenith.errors.advisor import PyZenithAdvisor

def initialize_error_system():
    """
    Convenience function to set up the PyZenith error handling and advisor system.
    """
    advisor = PyZenithAdvisor()
    handler = PyZenithErrorHandler(advisor=advisor)
    handler.install()
    return handler, advisor

__all__ = ["PyZenithErrorHandler", "PyZenithAdvisor", "initialize_error_system", "ErrorContext"]
