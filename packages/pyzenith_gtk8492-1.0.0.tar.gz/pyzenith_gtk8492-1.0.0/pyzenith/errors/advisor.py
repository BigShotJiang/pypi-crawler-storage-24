import re
from typing import Dict, List, Any, Optional
from pyzenith.errors.handler import ErrorContext

class PyZenithAdvisor:
    """
    Knowledge base and intelligent advisor for PyZenith related errors.
    Maps exception patterns to documentation, logic explanations, and fixes.
    """
    def __init__(self):
        self.error_patterns = self._initialize_patterns()
        self.doc_registry = self._initialize_docs()
        self.fix_templates = self._initialize_fixes()

    def _initialize_patterns(self) -> Dict[str, str]:
        return {
            r"Tkinter": "GUI_SYSTEM_ERROR",
            r"Widget": "COMPONENT_LOGIC_ERROR",
            r"PyZenithEngine": "ENGINE_CORE_ERROR",
            r"StateManager": "REACTIVE_STATE_ERROR",
            r"Animation": "SYSTEM_TRANSITION_ERROR",
            r"AttributeError.*has no attribute 'render'": "MISSING_RENDER_METHOD",
            r"TypeError.*'NoneType' object is not callable": "UNINITIALIZED_CALLBACK",
            r"ValueError.*Invalid value for state": "STATE_VALIDATION_FAILURE",
            r"RecursionError": "CIRCULAR_DEPENDENCY_DETECTED",
            r"Model": "ORM_MODEL_ERROR",
            r"QuerySet": "ORM_QUERY_ERROR",
            r"AssetManager": "ASSET_LOAD_ERROR",
            r"AudioPlayer": "AUDIO_SYSTEM_ERROR",
            r"NetworkClient": "NETWORK_HTTP_ERROR",
            r"BrowserEngine": "BROWSER_PARSER_ERROR",
            r"OSHandler": "OS_SYSTEM_ERROR",
            r"LinuxInstaller": "INSTALLER_ENV_ERROR",
            r"TestCase": "TEST_FRAMEWORK_ERROR",
            r"TestSuite": "TEST_RUNNER_ERROR",
            r"IntegrationTestManager": "INTEGRATION_TEST_ERROR",
            r"ValueError.*negative volume": "AUDIO_VOLUME_ERROR",
            r"TypeError.*'int' object is not iterable": "ITERATION_ON_INT",
            r"KeyError.*not found in states": "STATE_NOT_FOUND",
            r"RuntimeError.*already running": "ENGINE_RESTART_ERROR",
            r"ConnectionRefusedError": "NETWORK_CONNECTION_REFUSED",
            r"TimeoutError": "NETWORK_TIMEOUT_ERROR",
            r"FileNotFoundError.*assets": "ASSET_FILE_MISSING",
            r"PermissionError": "OS_PERMISSION_DENIED",
            r"sqlite3.OperationalError": "DB_OPERATIONAL_ERROR",
            r"ImportError.*pyzenith": "LIBRARY_IMPORT_ERROR",
            r"ModuleNotFoundError": "DEPENDENCY_MISSING",
            r"AttributeError.*'NoneType' object has no attribute 'x'": "NULL_OBJECT_REFERENCE",
            r"IndexError": "LIST_INDEX_OUT_OF_BOUNDS",
            r"StopIteration": "ITERATOR_EXHAUSTED",
            r"ZeroDivisionError": "ARITHMETIC_ZERO_DIVISION",
            r"AssertionError": "TEST_ASSERTION_FAILED",
            r"BrokenPipeError": "NETWORK_BROKEN_PIPE",
            r"SSLError": "SSL_CERTIFICATE_ERROR",
            r"HTTPError.*404": "WEB_NOT_FOUND_404",
            r"HTTPError.*500": "WEB_SERVER_ERROR_500",
            r"KeyboardInterrupt": "USER_ABORT_SIGNAL",
            r"MemoryError": "SYSTEM_OUT_OF_MEMORY",
            r"OverflowError": "NUMERIC_OVERFLOW",
            r"NameError": "VARIABLE_NOT_DEFINED",
            r"SyntaxError": "CODE_SYNTAX_ERROR",
            r"IndentationError": "CODE_INDENT_ERROR",
            r"TabError": "TAB_SPACE_MIX_ERROR",
            r"SystemError": "INTERNAL_INTERPRETER_ERROR",
            r"GeneratorExit": "GENERATOR_STOPPED",
            r"FloatingPointError": "FLOAT_CALC_ERROR",
            r"ReferenceError": "WEAKREF_INVALID",
            r"UnboundLocalError": "LOCAL_VAR_UNBOUND",
            r"UnicodeError": "ENCODING_DECODING_ERROR",
            r"UnicodeEncodeError": "ENCODING_FAILURE",
            r"UnicodeDecodeError": "DECODING_FAILURE",
            r"UnicodeTranslateError": "TRANSLATION_FAILURE",
            r"OSError.*Errno 13": "OS_PERMISSION_DENIED_E13",
            r"OSError.*Errno 2": "OS_FILE_NOT_FOUND_E2",
            r"OSError.*Errno 32": "OS_BROKEN_PIPE_E32",
            r"BlockingIOError": "IO_BLOCKING_ERROR",
            r"ChildProcessError": "OS_CHILD_PROCESS_FAILURE",
            r"ConnectionAbortedError": "CONNECTION_ABORTED",
            r"ConnectionResetError": "CONNECTION_RESET",
            r"FileExistsError": "OS_FILE_ALREADY_EXISTS",
            r"IsADirectoryError": "OS_PATH_IS_DIR",
            r"NotADirectoryError": "OS_PATH_NOT_DIR",
            r"InterruptedError": "SYSTEM_CALL_INTERRUPTED",
            r"ProcessLookupError": "PROCESS_NOT_FOUND",
            r"BufferError": "MEMORY_BUFFER_FAILURE",
            r"ArithmeticError": "GENERAL_MATH_ERROR",
            r"LookupError": "DATA_LOOKUP_FAILURE",
            r"EOFError": "INPUT_END_OF_FILE",
            r"NotImplementedError": "ABSTRACT_METHOD_NOT_IMPL",
            r"EnvironmentError": "OS_ENVIRONMENT_ERROR",
            r"IOError": "GENERAL_IO_FAILURE",
            r"VMError": "VIRTUAL_MACHINE_ERROR",
            r"RuntimeWarning": "RUNTIME_CAUTION_NEEDED",
            r"UserWarning": "USER_API_CAUTION",
            r"DeprecationWarning": "API_OBSOLETE_WARNING",
            r"PendingDeprecationWarning": "API_SOON_OBSOLETE",
            r"SyntaxWarning": "DUBIOUS_SYNTAX_WARNING",
            r"ImportWarning": "IMPORT_PROCESS_WARNING",
            r"UnicodeWarning": "UNICODE_HANDLING_WARNING",
            r"BytesWarning": "BYTES_HANDLING_WARNING",
            r"ResourceWarning": "RESOURCE_LEAK_WARNING",
            r"FutureWarning": "FUTURE_API_CHANGE",
            r"BadStatusLine": "HTTP_INVALID_RESPONSE",
            r"InvalidURL": "URL_MALFORMED_ERROR",
            r"MissingSchema": "URL_MISSING_HTTP",
            r"ChunkedEncodingError": "HTTP_CHUNK_FAILURE",
            r"ContentDecodingError": "HTTP_CONTENT_FAILURE",
            r"StreamConsumedError": "NETWORK_STREAM_ERROR",
            r"ProxyError": "NETWORK_PROXY_FAILURE",
            r"RetryError": "NETWORK_RETRY_EXHAUSTED",
            r"InvalidHeader": "HTTP_HEADER_MALFORMED",
            r"InvalidProxyURL": "PROXY_URL_INVALID",
            r"UnrewindableBodyError": "HTTP_BODY_REWIND_FAIL",
            r"ReadTimeout": "NETWORK_READ_TIMEOUT",
            r"ConnectTimeout": "NETWORK_CONNECT_TIMEOUT",
            r"InsecureRequestWarning": "SSL_VERIFY_DISABLED",
            r"InvalidSchema": "URL_SCHEMA_UNKNOWN"
        }

    def _initialize_docs(self) -> Dict[str, str]:
        return {
            "GUI_SYSTEM_ERROR": "PyZenith uses Tkinter as the underlying windowing engine. Ensure your OS has Tcl/Tk installed correctly.",
            "COMPONENT_LOGIC_ERROR": "Widgets must inherit from pyzenith.core.engine.Widget and implement the render() method.",
            "ENGINE_CORE_ERROR": "The PyZenithEngine manages the main loop. Only one instance of the engine should run at a time.",
            "REACTIVE_STATE_ERROR": "States in PyZenith are reactive. Changing a state triggers re-renders for subscribed widgets.",
            "SYSTEM_TRANSITION_ERROR": "Animations require a valid Easing function and a duration > 0.",
            "MISSING_RENDER_METHOD": "Every Zenith component must override the 'render' method to draw on the canvas.",
            "UNINITIALIZED_CALLBACK": "Check if you've assigned a function to the event handler (e.g., button.click_handler = my_func).",
            "STATE_VALIDATION_FAILURE": "PyZenith State objects can have validators. Ensure the value being set meets the validator criteria.",
            "CIRCULAR_DEPENDENCY_DETECTED": "Two or more ComputedStates are likely watching each other, creating an infinite loop.",
            "ORM_MODEL_ERROR": "PyZenith ORM Models require Fields. Ensure you are not instantiating a raw Model without fields.",
            "ORM_QUERY_ERROR": "QuerySet evaluation failed. Check if the database engine is properly connected.",
            "ASSET_LOAD_ERROR": "The AssetManager failed to load a file. Supported formats: .png, .jpg, .wav, .mp3.",
            "AUDIO_SYSTEM_ERROR": "The Audio engine encountered an issue with the sound device or file format.",
            "NETWORK_HTTP_ERROR": "HTTP request failed. Check your internet connection or the server URL.",
            "BROWSER_PARSER_ERROR": "The Browser Engine could not parse the HTML content. Ensure it is valid HTML5.",
            "OS_SYSTEM_ERROR": "Cross-platform operation failed. The OSHandler may lack permissions for this action.",
            "INSTALLER_ENV_ERROR": "Linux environment setup failed. Check if 'sudo' is required for package installation.",
            "TEST_FRAMEWORK_ERROR": "The Testing framework encountered an internal error. Check TestCase inheritance.",
            "TEST_RUNNER_ERROR": "Test discovery failed. Ensure test files follow the 'test_*.py' naming convention.",
            "INTEGRATION_TEST_ERROR": "Integration scenario failed. Multiple systems failed to synchronize state.",
            "AUDIO_VOLUME_ERROR": "Audio volume must be between 0.0 and 1.0. Negative values are not allowed.",
            "ITERATION_ON_INT": "You are trying to loop over an integer. PyZenith lists and dictionaries are iterable.",
            "STATE_NOT_FOUND": "The requested state key does not exist in the StateManager registry.",
            "ENGINE_RESTART_ERROR": "PyZenithEngine.run() called while the engine is already active. Use engine.stop() first.",
            "NETWORK_CONNECTION_REFUSED": "The target server refused the connection. Verify the port and server status.",
            "NETWORK_TIMEOUT_ERROR": "The network request took too long. Check server latency or network stability.",
            "ASSET_FILE_MISSING": "Specified asset file path does not exist on disk. Check for typos in the path.",
            "OS_PERMISSION_DENIED": "Operation not permitted by the OS. PyZenith may need admin/root privileges.",
            "DB_OPERATIONAL_ERROR": "Database engine could not execute SQL. Check table schema and field types.",
            "LIBRARY_IMPORT_ERROR": "PyZenith is not installed in the current environment. Try 'pip install pyzenith'.",
            "DEPENDENCY_MISSING": "A required third-party module is missing. PyZenith requires 'requests' and 'pillow'.",
            "NULL_OBJECT_REFERENCE": "Accessing a property on None. Likely a widget was not found by engine.root_widget.find_at().",
            "LIST_INDEX_OUT_OF_BOUNDS": "Accessing an index outside the range of a PyZenith list component.",
            "ITERATOR_EXHAUSTED": "The iterator has reached the end. Ensure loops are correctly terminated.",
            "ARITHMETIC_ZERO_DIVISION": "Division by zero in UI calculation. Check layout constraints and widget sizes.",
            "TEST_ASSERTION_FAILED": "An assertion in your test case failed. Review the expected vs actual values.",
            "NETWORK_BROKEN_PIPE": "The network connection was closed unexpectedly by the server.",
            "SSL_CERTIFICATE_ERROR": "SSL verification failed. The server's certificate is invalid or expired.",
            "WEB_NOT_FOUND_404": "The requested web page was not found (404). Check the URL path.",
            "WEB_SERVER_ERROR_500": "The web server encountered an internal error (500).",
            "USER_ABORT_SIGNAL": "Execution interrupted by user (Ctrl+C). PyZenith is shutting down gracefully.",
            "SYSTEM_OUT_OF_MEMORY": "Python has run out of memory. Reduce the number of active high-res assets.",
            "NUMERIC_OVERFLOW": "Numeric value is too large for the current hardware/software limit.",
            "VARIABLE_NOT_DEFINED": "Using a variable name that hasn't been defined in the current scope.",
            "CODE_SYNTAX_ERROR": "Python syntax error. PyZenith scripts must be valid Python 3.10+ code.",
            "CODE_INDENT_ERROR": "Incorrect indentation in your script. Python requires consistent use of spaces.",
            "TAB_SPACE_MIX_ERROR": "Mixed tabs and spaces detected. Use 4 spaces for PyZenith projects.",
            "INTERNAL_INTERPRETER_ERROR": "Internal Python interpreter error. This is likely not a PyZenith issue.",
            "GENERATOR_STOPPED": "A generator function raised StopIteration instead of yielding.",
            "FLOAT_CALC_ERROR": "Floating point error. Check for NaN or Infinite results in math operations.",
            "WEAKREF_INVALID": "Accessing an object that has been garbage collected by the PyZenith engine.",
            "LOCAL_VAR_UNBOUND": "Local variable referenced before assignment. Check scope in event handlers.",
            "ENCODING_DECODING_ERROR": "Error during text encoding or decoding. Use UTF-8 for all PyZenith files.",
            "ENCODING_FAILURE": "Failed to encode text to bytes. Check character compatibility with the encoding.",
            "DECODING_FAILURE": "Failed to decode bytes to text. Input data might be corrupted.",
            "TRANSLATION_FAILURE": "Unicode translation failed during text processing.",
            "OS_PERMISSION_DENIED_E13": "EACCES: Permission denied. The OS blocked file access.",
            "OS_FILE_NOT_FOUND_E2": "ENOENT: No such file or directory in the system path.",
            "OS_BROKEN_PIPE_E32": "EPIPE: Broken pipe. The process communicating with PyZenith ended.",
            "IO_BLOCKING_ERROR": "A non-blocking I/O operation would block the PyZenith main loop.",
            "OS_CHILD_PROCESS_FAILURE": "A child process spawned by OSHandler failed to execute.",
            "CONNECTION_ABORTED": "The connection was aborted by the local host during transfer.",
            "CONNECTION_RESET": "The connection was reset by the peer. Check server connectivity.",
            "OS_FILE_ALREADY_EXISTS": "Trying to create a file that already exists in the system.",
            "OS_PATH_IS_DIR": "Operation expected a file, but found a directory instead.",
            "OS_PATH_NOT_DIR": "Operation expected a directory, but found a file instead.",
            "SYSTEM_CALL_INTERRUPTED": "A system call was interrupted by a signal (EINTR).",
            "PROCESS_NOT_FOUND": "The OS process specified by ID could not be located.",
            "MEMORY_BUFFER_FAILURE": "Operation on an internal memory buffer failed (BufferError).",
            "GENERAL_MATH_ERROR": "General arithmetic error in the logic module.",
            "DATA_LOOKUP_FAILURE": "LookupError: The specified key or index was not found in the dataset.",
            "INPUT_END_OF_FILE": "Unexpected EOF while reading input from a terminal or file.",
            "ABSTRACT_METHOD_NOT_IMPL": "A method in a PyZenith base class must be implemented by the subclass.",
            "OS_ENVIRONMENT_ERROR": "Issue with the operating system environment or configuration.",
            "GENERAL_IO_FAILURE": "General Input/Output error. Check hardware and file permissions.",
            "VIRTUAL_MACHINE_ERROR": "Issue detected within the Python virtual machine execution.",
            "RUNTIME_CAUTION_NEEDED": "A potential issue was detected at runtime that might cause instability.",
            "USER_API_CAUTION": "The API is being used in a way that is technically correct but not recommended.",
            "API_OBSOLETE_WARNING": "This PyZenith feature is deprecated and will be removed in future versions.",
            "API_SOON_OBSOLETE": "This feature is pending deprecation. Start migrating to newer alternatives.",
            "DUBIOUS_SYNTAX_WARNING": "Python found suspicious code that may behave unexpectedly.",
            "IMPORT_PROCESS_WARNING": "Issues detected during the module import process.",
            "UNICODE_HANDLING_WARNING": "Unicode processing might result in data loss or incorrect rendering.",
            "BYTES_HANDLING_WARNING": "Issues detected during bytes/string conversion operations.",
            "RESOURCE_LEAK_WARNING": "A resource (file handle, socket) was not closed properly.",
            "FUTURE_API_CHANGE": "A feature is being used that will change behavior in future releases.",
            "HTTP_INVALID_RESPONSE": "The server returned an invalid HTTP response line.",
            "URL_MALFORMED_ERROR": "The URL provided is not correctly formatted for the network client.",
            "URL_MISSING_HTTP": "The URL is missing the protocol (http:// or https://).",
            "HTTP_CHUNK_FAILURE": "Error while processing chunked transfer encoding.",
            "HTTP_CONTENT_FAILURE": "Error while decoding HTTP response content.",
            "NETWORK_STREAM_ERROR": "The network stream has already been consumed.",
            "NETWORK_PROXY_FAILURE": "The specified proxy server could not be reached.",
            "NETWORK_RETRY_EXHAUSTED": "All retry attempts for the network request have failed.",
            "HTTP_HEADER_MALFORMED": "An invalid character was found in an HTTP header.",
            "PROXY_URL_INVALID": "The proxy URL provided is malformed or uses an unsupported protocol.",
            "HTTP_BODY_REWIND_FAIL": "Failed to rewind the request body for a retry attempt.",
            "NETWORK_READ_TIMEOUT": "The server took too long to send data after the connection was established.",
            "NETWORK_CONNECT_TIMEOUT": "The client took too long to connect to the remote server.",
            "SSL_VERIFY_DISABLED": "Insecure request made without SSL verification. This is a security risk.",
            "URL_SCHEMA_UNKNOWN": "The URL scheme is unknown or not supported by the network client."
        }

    def _initialize_fixes(self) -> Dict[str, str]:
        return {
            "MISSING_RENDER_METHOD": "Add 'def render(self):' to your class and use self.engine.canvas to draw.",
            "UNINITIALIZED_CALLBACK": "Initialize the callback: widget.on_click = lambda: print('Clicked!')",
            "STATE_VALIDATION_FAILURE": "Check your State(key, initial_value, validators=[...]) definition.",
            "CIRCULAR_DEPENDENCY_DETECTED": "Break the dependency chain. Use a standard State for one of the variables instead of ComputedState.",
            "GUI_SYSTEM_ERROR": "Install the Tcl/Tk development packages using your system's package manager (e.g., apt, dnf, or brew).",
            "ORM_MODEL_ERROR": "Define appropriate fields (like StringField or IntegerField) in your Model subclass definition.",
            "ORM_QUERY_ERROR": "Ensure engine.connect() is called before performing database queries.",
            "ASSET_LOAD_ERROR": "Verify the file path and ensure the image format is supported by Pillow.",
            "AUDIO_SYSTEM_ERROR": "Check if another application is using the audio device or if the file is corrupted.",
            "NETWORK_HTTP_ERROR": "Wrap your request in a try-except block and check internet connectivity.",
            "BROWSER_PARSER_ERROR": "Verify the HTML source code for unclosed tags or invalid characters.",
            "OS_SYSTEM_ERROR": "Check system logs for permission errors or missing binaries.",
            "INSTALLER_ENV_ERROR": "Run the script with appropriate permissions or manually install missing packages.",
            "TEST_FRAMEWORK_ERROR": "Ensure your test class inherits from pyzenith.testing.TestCase.",
            "TEST_RUNNER_ERROR": "Move your tests to a 'tests/' directory and name them 'test_*.py'.",
            "INTEGRATION_TEST_ERROR": "Use IntegrationTestManager to synchronize events between systems.",
            "AUDIO_VOLUME_ERROR": "Ensure the volume level is set using a floating-point number between 0.0 and 1.0.",
            "ITERATION_ON_INT": "Verify the variable is a collection (list or dict) before attempting to loop over its elements.",
            "STATE_NOT_FOUND": "Call state_manager.create_state() before trying to get_state().",
            "ENGINE_RESTART_ERROR": "Check if engine.run() is inside a loop; it should only be called once.",
            "NETWORK_CONNECTION_REFUSED": "Verify the server is running and listening on the expected port.",
            "NETWORK_TIMEOUT_ERROR": "Increase the timeout value in the request configuration.",
            "ASSET_FILE_MISSING": "Double-check the file name and path for accuracy and case-sensitivity.",
            "OS_PERMISSION_DENIED": "Run your IDE or terminal as Administrator (Windows) or use sudo (Linux).",
            "DB_OPERATIONAL_ERROR": "Verify your SQL syntax or check if the table actually exists.",
            "LIBRARY_IMPORT_ERROR": "Check your PYTHONPATH or reinstall PyZenith in the current venv.",
            "DEPENDENCY_MISSING": "Use your Python package manager to install the required libraries (requests, pillow, sounddevice).",
            "NULL_OBJECT_REFERENCE": "Implement a null-check (is not None) before accessing properties of a potentially uninitialized object.",
            "LIST_INDEX_OUT_OF_BOUNDS": "Check the length using len(list) before accessing an index.",
            "ITERATOR_EXHAUSTED": "Re-initialize the iterator or use a standard for-loop.",
            "ARITHMETIC_ZERO_DIVISION": "Validate the denominator to ensure it is non-zero before performing any division operations.",
            "TEST_ASSERTION_FAILED": "Debug the code to see why the actual value differs from the expectation.",
            "NETWORK_BROKEN_PIPE": "Implement a retry mechanism for transient network failures.",
            "SSL_CERTIFICATE_ERROR": "Update your local CA certificate store or verify the server's certificate chain.",
            "WEB_NOT_FOUND_404": "Verify that the URL path is correct and the resource exists on the server.",
            "WEB_SERVER_ERROR_500": "Check the server-side logs for the cause of the internal error.",
            "USER_ABORT_SIGNAL": "Ensure resources are released in a try-finally block.",
            "SYSTEM_OUT_OF_MEMORY": "Optimize memory usage by clearing unused assets from AssetManager.",
            "NUMERIC_OVERFLOW": "Use decimal.Decimal for very large numbers or optimize the algorithm.",
            "VARIABLE_NOT_DEFINED": "Check for typos in the variable name and ensure it's in the correct scope.",
            "CODE_SYNTAX_ERROR": "Check for missing colons, parentheses, or incorrect keyword usage.",
            "CODE_INDENT_ERROR": "Ensure all lines in the block have the same number of leading spaces.",
            "TAB_SPACE_MIX_ERROR": "Convert all tabs to spaces (usually 4 spaces per indent level).",
            "INTERNAL_INTERPRETER_ERROR": "Update your Python version to the latest stable release.",
            "GENERATOR_STOPPED": "Use a return statement to stop the generator or fix the internal logic.",
            "FLOAT_CALC_ERROR": "Use math.isclose() for float comparisons to avoid precision issues.",
            "WEAKREF_INVALID": "Keep a strong reference to the object as long as it's needed.",
            "LOCAL_VAR_UNBOUND": "Assign a value to the variable before the loop or try block.",
            "ENCODING_DECODING_ERROR": "Explicitly specify a standard character encoding (such as 'utf-8') when performing I/O operations.",
            "ENCODING_FAILURE": "Ensure the text contains only characters supported by the target encoding.",
            "DECODING_FAILURE": "Check if the file was truly saved with the encoding you are using to read it.",
            "TRANSLATION_FAILURE": "Review the translation map for missing or invalid characters.",
            "OS_PERMISSION_DENIED_E13": "Check if the file is opened by another program or check ACLs.",
            "OS_FILE_NOT_FOUND_E2": "Use os.path.exists() to verify the path before performing operations.",
            "OS_BROKEN_PIPE_E32": "Check if the receiving process is still alive and accepting data.",
            "IO_BLOCKING_ERROR": "Use a selector or async/await for non-blocking I/O operations.",
            "OS_CHILD_PROCESS_FAILURE": "Check the return code of the child process and inspect its stderr.",
            "CONNECTION_ABORTED": "Check for network interference (firewalls, routers) or server load.",
            "CONNECTION_RESET": "Implement a reconnection logic in your network client.",
            "OS_FILE_ALREADY_EXISTS": "Delete the existing file or use a different filename.",
            "OS_PATH_IS_DIR": "Ensure you are targeting a specific file, not its parent directory.",
            "OS_PATH_NOT_DIR": "Verify that all components of the path are directories.",
            "SYSTEM_CALL_INTERRUPTED": "Retry the system call if it fails with an EINTR error code.",
            "PROCESS_NOT_FOUND": "Ensure the process is still running before attempting to manage it.",
            "MEMORY_BUFFER_FAILURE": "Ensure the buffer is not being modified while it's being read.",
            "GENERAL_MATH_ERROR": "Review complex math formulas for potential domain errors (e.g., sqrt of negative).",
            "DATA_LOOKUP_FAILURE": "Check if the key exists using 'if key in dict:' before access.",
            "INPUT_END_OF_FILE": "Ensure the input stream is correctly terminated and not closed prematurely.",
            "ABSTRACT_METHOD_NOT_IMPL": "Implement all required methods in your custom widget subclass.",
            "OS_ENVIRONMENT_ERROR": "Verify that all required environment variables are set correctly.",
            "GENERAL_IO_FAILURE": "Check hardware health and ensure the disk is not full.",
            "VIRTUAL_MACHINE_ERROR": "This is a severe error; try restarting your computer or reinstalling Python.",
            "RUNTIME_CAUTION_NEEDED": "Review the logic that triggered this warning to prevent future crashes.",
            "USER_API_CAUTION": "Consult the PyZenith Best Practices guide for the recommended way to use this API.",
            "API_OBSOLETE_WARNING": "Update your code to use the newer replacement API as soon as possible.",
            "API_SOON_OBSOLETE": "Plan a migration strategy for this feature in your next project update.",
            "DUBIOUS_SYNTAX_WARNING": "Refactor the code to be more explicit and follow PEP 8 standards.",
            "IMPORT_PROCESS_WARNING": "Check for circular imports or missing __init__.py files in your packages.",
            "UNICODE_HANDLING_WARNING": "Use escape sequences for special characters or use a more robust encoding.",
            "BYTES_HANDLING_WARNING": "Always use .encode() or .decode() explicitly with a specified encoding.",
            "RESOURCE_LEAK_WARNING": "Use 'with' statements (context managers) for files and sockets.",
            "FUTURE_API_CHANGE": "Consult the changelog for details on how this API will change in the next version.",
            "HTTP_INVALID_RESPONSE": "Check if the URL is correct and the server is actually an HTTP server.",
            "URL_MALFORMED_ERROR": "Use urllib.parse to construct URLs correctly and safely.",
            "URL_MISSING_HTTP": "Prepend 'http://' or 'https://' to the beginning of the URL string.",
            "HTTP_CHUNK_FAILURE": "Check for network instability or server-side streaming issues.",
            "HTTP_CONTENT_FAILURE": "Verify that the server is sending the content encoding it claims to send.",
            "NETWORK_STREAM_ERROR": "Reset the stream or fetch a fresh response from the server.",
            "NETWORK_PROXY_FAILURE": "Check your proxy settings and ensure the proxy server is online.",
            "NETWORK_RETRY_EXHAUSTED": "The server might be down permanently; check its status manually.",
            "HTTP_HEADER_MALFORMED": "Ensure headers only contain ASCII characters and follow the format Key: Value.",
            "PROXY_URL_INVALID": "Ensure the proxy URL includes the scheme (e.g., http://proxy:8080).",
            "HTTP_BODY_REWIND_FAIL": "If sending a stream, consider reading it into memory for easier retries.",
            "NETWORK_READ_TIMEOUT": "Optimize server performance or increase the 'read_timeout' parameter.",
            "NETWORK_CONNECT_TIMEOUT": "Check if the server IP is correct and accessible through your firewall.",
            "SSL_VERIFY_DISABLED": "Provide a path to a CA bundle or fix the server's certificate configuration.",
            "URL_SCHEMA_UNKNOWN": "Check for typos in the protocol (e.g., 'htpt' instead of 'http').",
            "DEFAULT": "Review the PyZenith documentation for the specific module mentioned in the traceback."
        }

    def get_advice(self, context: ErrorContext) -> str:
        """
        Analyzes the error context and returns a high-level analysis.
        """
        error_msg = str(context.exc_value)
        code_line = context.code_line.strip() if context.code_line else ""

        for pattern, category in self.error_patterns.items():
            if re.search(pattern, error_msg, re.IGNORECASE) or re.search(pattern, code_line, re.IGNORECASE):
                return f"Detected potential {category.replace('_', ' ').title()}. This usually happens during {category.lower()} operations."
        
        return "Generic Python error detected while running PyZenith. Examining the code structure for anomalies..."

    def get_documentation(self, context: ErrorContext) -> str:
        """
        Returns relevant documentation on how PyZenith works for the specific error.
        """
        error_msg = str(context.exc_value)
        code_line = context.code_line.strip() if context.code_line else ""

        # Check for specific error patterns first
        for pattern, category in self.error_patterns.items():
            if re.search(pattern, error_msg, re.IGNORECASE) or re.search(pattern, code_line, re.IGNORECASE):
                return self.doc_registry.get(category, "Consult the PyZenith Wiki for core concepts.")
        
        # Context-aware docs based on filename
        if "logic/state.py" in context.filename:
            return self.doc_registry["REACTIVE_STATE_ERROR"]
        if "core/engine.py" in context.filename:
            return self.doc_registry["ENGINE_CORE_ERROR"]
        if "database/orm.py" in context.filename:
            return self.doc_registry["ORM_MODEL_ERROR"]
        if "multimedia/audio.py" in context.filename:
            return self.doc_registry["AUDIO_SYSTEM_ERROR"]
        if "network/client.py" in context.filename:
            return self.doc_registry["NETWORK_HTTP_ERROR"]
        
        return "PyZenith is built on a custom Canvas rendering engine with reactive state management and a layer-based event system."

    def get_fix_suggestion(self, context: ErrorContext) -> str:
        """
        Provides a specific suggestion on how to fix the line of code that failed.
        """
        code = context.code_line.strip() if context.code_line else ""
        error_msg = str(context.exc_value)

        # Specific code-based fixes
        if "StateManager" in code and "create_state" not in code:
            return "Ensure you are using 'state_manager.create_state(key, value)' to initialize reactive data."
        
        if "Animation" in code and "duration" not in code:
            return "Animations require a 'duration' parameter in milliseconds. Example: Animation(target, duration=500)."
        
        if "Model" in code and "(" in code and "Field" not in code:
            return "When defining Models, ensure your class attributes are PyZenith Fields (e.g., name = StringField())."

        # Check patterns for both error message and code line
        for pattern, category in self.error_patterns.items():
            if re.search(pattern, error_msg, re.IGNORECASE) or re.search(pattern, code, re.IGNORECASE):
                return self.fix_templates.get(category, self.fix_templates["DEFAULT"])

        return f"Check the syntax on line {context.line_no}: '{code}'. Verify that all PyZenith objects are properly initialized."

    def generate_tutorial_link(self, category: str) -> str:
        base_url = "https://docs.pyzenith.io/en/latest/guides/"
        links = {
            "GUI_SYSTEM_ERROR": "setup.html",
            "COMPONENT_LOGIC_ERROR": "custom_widgets.html",
            "REACTIVE_STATE_ERROR": "state_management.html",
            "SYSTEM_TRANSITION_ERROR": "animations.html"
        }
        return base_url + links.get(category, "index.html")

    def analyze_performance_impact(self, context: ErrorContext) -> str:
        """
        Heuristically determines if the error might be causing performance bottlenecks.
        """
        if context.exc_type == RecursionError:
            return "Critical: This error is blocking the UI thread and will cause the application to hang."
        if "render" in context.func_name:
            return "Warning: Error occurred during render cycle. Frequent errors here will cause frame drops."
        return "Impact: Minimal. This appears to be a logic-level exception."

    def get_complex_fix_scenario(self, context: ErrorContext) -> str:
        """
        Provides a multi-step fix for more complex architectural issues.
        """
        if context.exc_type == AttributeError:
            return (
                "1. Verify that the object instance is not None.\n"
                "2. Check if you've imported the correct class from pyzenith.components.\n"
                "3. If it's a custom widget, ensure super().__init__() was called."
            )
        return "Consult the PyZenith architecture guide for structural refactoring advice."

    def get_module_context(self, filename: str) -> str:
        """
        Returns a description of the PyZenith module where the error occurred.
        """
        if "core" in filename: return "PyZenith Core: Handles rendering and OS window management."
        if "logic" in filename: return "PyZenith Logic: Manages reactive data binding and state."
        if "systems" in filename: return "PyZenith Systems: Coordinates animations, physics, and input."
        if "components" in filename: return "PyZenith Components: Pre-built UI elements like Buttons and Labels."
        return "User Application Space: Custom logic extending PyZenith."

    def suggest_alternative_api(self, code_line: str) -> Optional[str]:
        """
        Suggests more modern or efficient PyZenith APIs if legacy usage is detected.
        """
        if "tk.Button" in code_line:
            return "Suggestion: Use 'pyzenith.components.Button' instead of raw Tkinter buttons for better integration."
        if "threading.Thread" in code_line and "pyzenith" in code_line:
            return "Suggestion: Use PyZenith's built-in async task runner for UI-safe threading."
        return None

    def validate_code_style(self, code_line: str) -> List[str]:
        """
        Basic style check for PyZenith standards.
        """
        issues = []
        if len(code_line) > 120:
            issues.append("Line exceeds recommended width for PyZenith readability.")
        if "self._" in code_line and "handler" not in code_line:
            issues.append("Direct access to private PyZenith members is discouraged.")
        return issues

    def get_interactive_fix_wizard(self, context: ErrorContext) -> Dict[str, Any]:
        """
        Prepares data for an interactive fix wizard in the future.
        """
        return {
            "error_id": id(context),
            "severity": "HIGH" if context.exc_type in (TypeError, ValueError) else "MEDIUM",
            "possible_actions": [
                {"label": "Auto-Fix", "action": "REPLACE_LINE", "data": self.get_fix_suggestion(context)},
                {"label": "View Docs", "action": "OPEN_URL", "data": self.generate_tutorial_link("DEFAULT")},
                {"label": "Ignore", "action": "DISMISS"}
            ]
        }

    def log_advisor_intervention(self, context: ErrorContext):
        """
        Internal logging of how the advisor helped resolve an issue.
        """
        # In a real system, this would send anonymous telemetry to improve fix accuracy
        pass
