from setuptools import setup, find_packages

setup(
    name="pyzenith-gtk8492",
    version="1.0.0",
    author="GTK8492",
    author_email="gtk8492@example.com",
    description="An advanced UI/UX framework for Python with complex logic and systems.",
    long_description=open("README.md").read(),
    long_description_content_type="text/markdown",
    url="https://github.com/GTK8492/pyzenith",
    packages=find_packages(),
    include_package_data=True,
    install_requires=[
        "requests>=2.25.0",
        "Pillow>=8.0.0",
    ],
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
        "Topic :: Software Development :: User Interfaces",
    ],
    python_requires=">=3.10",
)
