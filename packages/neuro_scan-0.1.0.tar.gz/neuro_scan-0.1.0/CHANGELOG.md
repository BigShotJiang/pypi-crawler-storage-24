# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.1.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [0.1.0] - 2026-03-12

### Added

- Layer ablation analysis — zero out each layer, measure score impact
- Logit lens analysis — project hidden states to vocabulary at each layer
- Attention entropy analysis — quantify focus/diffusion of attention heads
- Automatic layer-function labeling (early_processing, syntax, reasoning, formatting, output)
- Prompt repetition experiment (`prompt-repeat` command)
- Three built-in probes: math, eq (emotional intelligence), json (format compliance)
- Custom probe support via JSON files
- Two inference backends: HuggingFace Transformers and ExLlamaV2
- Interactive Plotly HTML visualizations (ablation bar chart, logit lens heatmap, attention heatmap)
- JSON and CSV export for all results
- CLI with `map`, `ablate`, `logit-lens`, `attention`, `prompt-repeat`, `probes`, and `version` commands
- Comprehensive test suite (103 tests)
- CI/CD with GitHub Actions (lint, test, PyPI publish)
