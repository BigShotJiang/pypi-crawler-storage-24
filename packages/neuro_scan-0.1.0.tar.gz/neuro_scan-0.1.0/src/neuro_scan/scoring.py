"""Logit distribution scoring — reused from layer-scan with neuro-scan extensions.

Core scoring from logit distributions, plus entropy and top-k token utilities
for logit lens analysis.
"""

from __future__ import annotations

import logging
from dataclasses import dataclass

import numpy as np
import torch
from torch.nn import functional as F  # noqa: N812

logger = logging.getLogger(__name__)


@dataclass(frozen=True)
class ScoreResult:
    """Result of scoring a single sample from logits.

    Args:
        expected_score: Weighted average score from the probability distribution.
        uncertainty: Variance of the score distribution.
        probabilities: Probability of each score value in the restricted set.
        raw_logits: The raw logit values for the restricted token set.
    """

    expected_score: float
    uncertainty: float
    probabilities: list[float]
    raw_logits: list[float]


def score_from_logits(
    logits: torch.Tensor,
    score_token_ids: list[int],
    score_values: list[float] | None = None,
) -> ScoreResult:
    """Compute expected score from logit distribution over a restricted token set.

    Args:
        logits: Raw logits tensor of shape (vocab_size,) for the scoring position.
        score_token_ids: Token IDs corresponding to score values.
        score_values: Numeric values for each token. Defaults to [0, 1, ..., len-1].

    Returns:
        ScoreResult with expected score, uncertainty, and distribution details.
    """
    if score_values is None:
        score_values = list(range(len(score_token_ids)))

    if len(score_token_ids) != len(score_values):
        raise ValueError(
            f"score_token_ids ({len(score_token_ids)}) and "
            f"score_values ({len(score_values)}) must have equal length"
        )

    if len(score_token_ids) == 0:
        raise ValueError("score_token_ids must not be empty")

    restricted_logits = logits[score_token_ids].float()

    # Clamp +inf to prevent NaN from softmax
    if torch.isinf(restricted_logits).any():
        max_finite = restricted_logits[torch.isfinite(restricted_logits)]
        clamp_val = max_finite.max().item() + 100.0 if len(max_finite) > 0 else 1e6
        restricted_logits = torch.clamp(restricted_logits, max=clamp_val)

    probs = F.softmax(restricted_logits, dim=0)

    probs_np = probs.detach().cpu().numpy()
    values_np = np.array(score_values, dtype=np.float64)

    expected = float(np.dot(values_np, probs_np))
    variance = float(np.dot((values_np - expected) ** 2, probs_np))

    return ScoreResult(
        expected_score=expected,
        uncertainty=variance,
        probabilities=probs_np.tolist(),
        raw_logits=restricted_logits.detach().cpu().tolist(),
    )


def get_digit_token_ids(tokenizer) -> tuple[list[int], list[float]]:
    """Get token IDs for digits 0-9 from a tokenizer.

    Returns:
        Tuple of (token_ids, score_values) for digits 0-9.

    Raises:
        ValueError: If any digit encodes to multiple tokens.
    """
    token_ids = []
    score_values = []
    multi_token_digits = []

    for digit in range(10):
        token_id = tokenizer.encode(str(digit), add_special_tokens=False)
        if len(token_id) == 1:
            token_ids.append(token_id[0])
            score_values.append(float(digit))
        else:
            multi_token_digits.append((digit, token_id))

    if multi_token_digits:
        details = ", ".join(f"'{d}' -> {ids}" for d, ids in multi_token_digits)
        logger.warning(
            "Tokenizer encodes some digits as multiple tokens: %s. "
            "Digit-based scoring is not compatible with this tokenizer.",
            details,
        )
        raise ValueError(
            f"Digits encode to multiple tokens: {details}. "
            "This tokenizer is not compatible with digit-based scoring. "
            "Consider using a custom probe with --probe custom --custom-probe <path> "
            "that maps to single-token score values."
        )

    return token_ids, score_values


def aggregate_scores(results: list[ScoreResult]) -> tuple[float, float]:
    """Aggregate multiple ScoreResults into a single score and uncertainty.

    Args:
        results: List of ScoreResult from individual probe samples.

    Returns:
        Tuple of (mean_score, mean_uncertainty).
    """
    if not results:
        return 0.0, 0.0

    scores = [r.expected_score for r in results]
    uncertainties = [r.uncertainty for r in results]

    return float(np.mean(scores)), float(np.mean(uncertainties))


# --- neuro-scan extensions ---


def entropy_from_logits(logits: torch.Tensor) -> float:
    """Compute entropy of the full vocabulary distribution.

    Args:
        logits: Raw logits of shape (vocab_size,).

    Returns:
        Entropy in nats. Higher = more uncertain distribution.
    """
    logits = logits.float()
    # Clamp for numerical stability
    if torch.isinf(logits).any():
        max_finite = logits[torch.isfinite(logits)]
        clamp_val = max_finite.max().item() + 100.0 if len(max_finite) > 0 else 1e6
        logits = torch.clamp(logits, min=-clamp_val, max=clamp_val)

    probs = F.softmax(logits, dim=0)
    # Avoid log(0) by clamping
    log_probs = torch.log(probs.clamp(min=1e-12))
    entropy = -torch.sum(probs * log_probs).item()
    return float(entropy)


def top_k_tokens(
    logits: torch.Tensor,
    tokenizer,
    k: int = 5,
) -> list[tuple[str, float]]:
    """Get top-k tokens and their probabilities from logits.

    Args:
        logits: Raw logits of shape (vocab_size,).
        tokenizer: Tokenizer with decode method.
        k: Number of top tokens to return.

    Returns:
        List of (token_str, probability) tuples, sorted descending.
    """
    probs = F.softmax(logits.float(), dim=0)
    top_probs, top_ids = torch.topk(probs, min(k, len(probs)))

    results = []
    for prob, token_id in zip(top_probs.tolist(), top_ids.tolist()):
        token_str = tokenizer.decode([token_id])
        results.append((token_str, prob))

    return results
