"""neuro-scan: LLM Neuroanatomy Explorer — map what each transformer layer does."""

__version__ = "0.1.0"
