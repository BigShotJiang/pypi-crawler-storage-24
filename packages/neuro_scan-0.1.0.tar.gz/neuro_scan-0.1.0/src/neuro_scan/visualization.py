"""Visualization for neuro-scan results.

Generates three types of interactive HTML charts:
A. Ablation Sensitivity Bar Chart — which layers matter most
B. Logit Lens Trajectory Heatmap — when does the correct token emerge
C. Attention Entropy Heatmap — which heads are focused vs diffuse
"""

from __future__ import annotations

import logging
from pathlib import Path
from typing import TYPE_CHECKING

import numpy as np

from neuro_scan.labeler import get_label_color

if TYPE_CHECKING:
    from neuro_scan.config import NeuroReport

logger = logging.getLogger(__name__)


def generate_ablation_chart(
    report: NeuroReport,
    output_path: str | Path,
    title: str | None = None,
) -> Path:
    """Generate an interactive ablation sensitivity bar chart.

    X-axis: layer index (0..N-1)
    Y-axis: score_delta (baseline - ablated score)
    Color: auto-labeled layer function
    Stars: top-k most important layers

    Args:
        report: The neuro-scan report.
        output_path: Path for the output HTML file.
        title: Custom title.

    Returns:
        Path to the generated HTML file.
    """
    import plotly.graph_objects as go

    output_path = Path(output_path)
    output_path.parent.mkdir(parents=True, exist_ok=True)

    if title is None:
        model_name = Path(report.model_path).name
        title = f"Layer Ablation Sensitivity — {model_name} / {report.probe_name}"

    layers = list(range(report.total_layers))
    deltas = [r.score_delta for r in report.ablation_results]
    colors = [get_label_color(report.layer_labels.get(i, "")) for i in layers]
    labels = [report.layer_labels.get(i, "unknown") for i in layers]

    fig = go.Figure()

    fig.add_trace(
        go.Bar(
            x=layers,
            y=deltas,
            marker_color=colors,
            text=labels,
            hovertemplate=(
                "Layer %{x}<br>"
                "Score delta: %{y:.4f}<br>"
                "Function: %{text}<br>"
                "<extra></extra>"
            ),
        )
    )

    # Mark top-k layers with stars
    for rank, layer_idx in enumerate(report.top_important_layers, 1):
        delta = report.ablation_results[layer_idx].score_delta
        fig.add_trace(
            go.Scatter(
                x=[layer_idx],
                y=[delta],
                mode="markers+text",
                marker={"size": 14, "color": "gold", "symbol": "star"},
                text=[f"#{rank}"],
                textposition="top center",
                name=f"Top {rank}: layer {layer_idx} (delta={delta:.4f})",
                showlegend=True,
            )
        )

    fig.update_layout(
        title=title,
        xaxis_title="Layer Index",
        yaxis_title="Score Delta (baseline - ablated)",
        width=1000,
        height=500,
        showlegend=True,
        xaxis={"dtick": max(1, report.total_layers // 20)},
    )

    # Baseline annotation
    fig.add_annotation(
        text=f"Baseline: {report.baseline_score:.4f}",
        xref="paper", yref="paper",
        x=0.02, y=0.98,
        showarrow=False,
        font={"size": 12, "color": "gray"},
    )

    fig.write_html(str(output_path), include_plotlyjs="cdn")
    logger.info("Ablation chart saved to %s", output_path)

    return output_path


def generate_logit_lens_heatmap(
    report: NeuroReport,
    output_path: str | Path,
    title: str | None = None,
) -> Path:
    """Generate a logit lens trajectory heatmap.

    X-axis: layer index
    Y-axis: sample index
    Color: target token probability at each layer

    Args:
        report: The neuro-scan report.
        output_path: Path for the output HTML file.
        title: Custom title.

    Returns:
        Path to the generated HTML file.
    """
    import plotly.graph_objects as go

    output_path = Path(output_path)
    output_path.parent.mkdir(parents=True, exist_ok=True)

    if title is None:
        model_name = Path(report.model_path).name
        title = f"Logit Lens Trajectory — {model_name} / {report.probe_name}"

    trajectories = report.logit_lens_trajectory
    if not trajectories:
        # Create empty chart with message
        fig = go.Figure()
        fig.add_annotation(
            text="No logit lens data available",
            xref="paper", yref="paper",
            x=0.5, y=0.5, showarrow=False,
            font={"size": 20},
        )
        fig.update_layout(title=title, width=1000, height=500)
        fig.write_html(str(output_path), include_plotlyjs="cdn")
        return output_path

    # Build probability matrix
    num_samples = len(trajectories)
    num_layers = len(trajectories[0]) if trajectories else 0

    prob_matrix = np.zeros((num_samples, num_layers))
    hover_text = []

    for s_idx, trajectory in enumerate(trajectories):
        row_hover = []
        for l_idx, step in enumerate(trajectory):
            prob_matrix[s_idx, l_idx] = step.target_token_prob
            row_hover.append(
                f"Layer {step.layer_idx}<br>"
                f"Top token: {step.top_token} ({step.top_token_prob:.3f})<br>"
                f"Target prob: {step.target_token_prob:.3f}<br>"
                f"Entropy: {step.entropy:.2f}"
            )
        hover_text.append(row_hover)

    fig = go.Figure()

    fig.add_trace(
        go.Heatmap(
            z=prob_matrix,
            x=list(range(num_layers)),
            y=[f"Sample {i}" for i in range(num_samples)],
            colorscale="Viridis",
            colorbar={"title": "Target Token Prob"},
            text=hover_text,
            hovertemplate="%{text}<extra></extra>",
        )
    )

    # Mark emergence layers per sample
    for s_idx, trajectory in enumerate(trajectories):
        for step in trajectory:
            if step.target_token_prob > 0.1:
                fig.add_trace(
                    go.Scatter(
                        x=[step.layer_idx],
                        y=[f"Sample {s_idx}"],
                        mode="markers",
                        marker={"size": 8, "color": "red", "symbol": "diamond"},
                        name=f"Emergence (sample {s_idx}, layer {step.layer_idx})",
                        showlegend=False,
                        hovertemplate=(
                            f"Emergence at layer {step.layer_idx}<br>"
                            f"Target prob: {step.target_token_prob:.3f}<extra></extra>"
                        ),
                    )
                )
                break  # Only mark first emergence

    fig.update_layout(
        title=title,
        xaxis_title="Layer Index",
        yaxis_title="Probe Sample",
        width=1000,
        height=max(400, num_samples * 30 + 200),
    )

    fig.write_html(str(output_path), include_plotlyjs="cdn")
    logger.info("Logit lens heatmap saved to %s", output_path)

    return output_path


def generate_attention_heatmap(
    report: NeuroReport,
    output_path: str | Path,
    title: str | None = None,
) -> Path:
    """Generate an attention entropy heatmap.

    X-axis: layer index
    Y-axis: attention head index
    Color: entropy (high = diffuse attention, low = focused)

    Args:
        report: The neuro-scan report.
        output_path: Path for the output HTML file.
        title: Custom title.

    Returns:
        Path to the generated HTML file.
    """
    import plotly.graph_objects as go

    output_path = Path(output_path)
    output_path.parent.mkdir(parents=True, exist_ok=True)

    if title is None:
        model_name = Path(report.model_path).name
        title = f"Attention Entropy — {model_name} / {report.probe_name}"

    entropy_data = report.attention_entropy
    if not entropy_data:
        fig = go.Figure()
        fig.add_annotation(
            text="No attention data available (backend may not support attention extraction)",
            xref="paper", yref="paper",
            x=0.5, y=0.5, showarrow=False,
            font={"size": 16},
        )
        fig.update_layout(title=title, width=1000, height=500)
        fig.write_html(str(output_path), include_plotlyjs="cdn")
        return output_path

    # Build entropy matrix: [num_heads x num_layers]
    num_layers = len(entropy_data)
    num_heads = len(entropy_data[0]) if entropy_data else 0

    entropy_matrix = np.zeros((num_heads, num_layers))
    for l_idx, head_entropies in enumerate(entropy_data):
        for h_idx, ent in enumerate(head_entropies):
            entropy_matrix[h_idx, l_idx] = ent

    fig = go.Figure()

    fig.add_trace(
        go.Heatmap(
            z=entropy_matrix,
            x=list(range(num_layers)),
            y=[f"Head {i}" for i in range(num_heads)],
            colorscale="RdYlBu_r",  # Red = high entropy, Blue = low
            colorbar={"title": "Entropy (nats)"},
            hovertemplate=(
                "Layer %{x}, Head %{y}<br>"
                "Entropy: %{z:.3f}<br>"
                "<extra></extra>"
            ),
        )
    )

    fig.update_layout(
        title=title,
        xaxis_title="Layer Index",
        yaxis_title="Attention Head",
        width=1000,
        height=max(400, num_heads * 15 + 200),
    )

    fig.write_html(str(output_path), include_plotlyjs="cdn")
    logger.info("Attention heatmap saved to %s", output_path)

    return output_path


def generate_summary_text(report: NeuroReport) -> str:
    """Generate a text summary of neuroanatomy results.

    Args:
        report: The neuro-scan report.

    Returns:
        Formatted text summary.
    """
    lines = [
        "=" * 60,
        "NEURO-SCAN RESULTS",
        "=" * 60,
        f"Model: {report.model_path}",
        f"Probe: {report.probe_name}",
        f"Total layers: {report.total_layers}",
        f"Scan time: {report.total_time_seconds:.1f}s",
        "",
        f"Baseline score: {report.baseline_score:.4f} "
        f"(+/-{report.baseline_uncertainty:.4f})",
        "",
        "TOP IMPORTANT LAYERS (by ablation sensitivity):",
        "-" * 60,
    ]

    for rank, layer_idx in enumerate(report.top_important_layers, 1):
        result = report.ablation_results[layer_idx]
        label = report.layer_labels.get(layer_idx, "unknown")
        lines.append(
            f"  #{rank}: layer {layer_idx:3d} "
            f"(delta={result.score_delta:+.4f}) "
            f"[{label}]"
        )

    lines.extend(["", "LAYER FUNCTION DISTRIBUTION:", "-" * 60])

    # Count labels
    label_counts: dict[str, int] = {}
    for label in report.layer_labels.values():
        label_counts[label] = label_counts.get(label, 0) + 1

    for label, count in sorted(label_counts.items(), key=lambda x: -x[1]):
        pct = count / report.total_layers * 100
        lines.append(f"  {label:25s}: {count:3d} layers ({pct:.1f}%)")

    lines.extend(["", "=" * 60])
    return "\n".join(lines)
