class BaseModel:
    pass
