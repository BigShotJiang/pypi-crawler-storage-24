# guardianhub_sdk/models/contracts/completion.py
from .base import SovereignBaseContract, SovereignBaseResponse
from pydantic import Field
from typing import Dict, Any, Optional

class MissionManifest(SovereignBaseContract):
    """The 'Final Signal' Request: Proof of Mission Completion."""
    mission_id: str = Field(..., description="The unique session/mission identifier")
    final_report: Dict[str, Any] = Field(..., description="The synthesized IntelligenceReport")
    mission_status: str = Field("COMPLETED", description="Final state: COMPLETED, FAILED, or PARTIAL")
    callback_url: str = Field(..., description="Sutram's local DNS callback endpoint")
    step_reports: list = Field(default_factory=list, description="List of individual step execution reports")

class CallbackAck(SovereignBaseResponse):
    """The 'Final Signal' Response: Orchestrator's acknowledgement."""
    orchestrator_received: bool = Field(True)
    next_mission_token: Optional[str] = Field(None, description="For chained agentic workflows")


from typing import List, Dict, Any, Optional
from pydantic import Field
from .base import SovereignBaseContract


class TacticalExecutionReport(SovereignBaseContract):
    """
    🎯 THE INTERVENTION OUTCOME:
    The raw data and audit trail produced by the Muscle's tactical loop.
    """
    mission_id: str
    status: str = Field("SUCCESS", description="SUCCESS, PARTIAL, or FAILED")

    # ⚔️ THE INTELLIGENCE PACKAGE
    # This stores the accumulated_context (The actual bank details, tech stacks, etc.)
    intelligence_package: Dict[str, Any] = Field(
        default_factory=dict,
        description="The physical data discovered during the loop"
    )

    # 🛡️ THE AUDIT TRAIL
    # Stores exactly what physical API calls were made (The 'Scroll' results)
    step_results: List[Dict[str, Any]] = Field(
        default_factory=list,
        description="The resolved physical execution logs for each step"
    )

    error_message: Optional[str] = None