"""DuckDB storage plugin package."""
