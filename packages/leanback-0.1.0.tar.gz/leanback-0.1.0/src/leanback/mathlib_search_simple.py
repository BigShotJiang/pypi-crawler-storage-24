"""
Simple Mathlib search using Python regex on source files.

No complex parsing, no indexes, just fast pattern matching.
"""

import re
from dataclasses import dataclass
from pathlib import Path

from .common.errors import LeanBackError


@dataclass
class SimpleSearchResult:
    """A search result from Mathlib."""

    name: str
    file: str
    line: int
    text: str
    kind: str | None = None  # theorem, def, lemma, etc.


class SimpleMathlibSearch:
    """Fast Mathlib search using regex on source files."""

    def __init__(self, project_path: Path | None = None):
        self.project_path = project_path or Path.cwd()
        self.mathlib_dir = self._find_mathlib_in_project()

        if not self.mathlib_dir:
            raise LeanBackError(
                "Mathlib not found in project",
                "Ensure your project has Mathlib as a dependency",
            )

    def _find_mathlib_in_project(self) -> Path | None:
        """Find Mathlib in the project's lake packages."""
        lake_packages = self.project_path / ".lake" / "packages"
        if not lake_packages.exists():
            return None

        # Check common names first, then fall back to scanning
        for name in ("mathlib", "mathlib4"):
            candidate = lake_packages / name
            if candidate.exists() and (candidate / "Mathlib").exists():
                return candidate

        # Scan all packages for one containing a Mathlib/ directory
        for item in lake_packages.iterdir():
            if item.is_dir() and (item / "Mathlib").exists():
                return item

        return None

    def _get_namespaces_at_line(self, content: str, target_line: int) -> list[str]:
        """Get the active namespace stack at a given line number."""
        namespaces = []
        for i, line in enumerate(content.splitlines(), 1):
            if i >= target_line:
                break
            stripped = line.strip()
            if stripped.startswith("namespace "):
                ns = stripped.split("namespace ", 1)[1].split()[0].strip()
                namespaces.append(ns)
            elif stripped.startswith("end ") and namespaces:
                end_ns = stripped.split("end ", 1)[1].split()[0].strip()
                # Pop matching namespace
                if namespaces and namespaces[-1] == end_ns:
                    namespaces.pop()
        return namespaces

    def _fully_qualify_name(self, name: str, namespaces: list[str]) -> str:
        """Prepend active namespaces to a declaration name."""
        if not namespaces or "." in name:
            return name
        return ".".join(namespaces) + "." + name

    def search(self, query: str, max_results: int = 50) -> list[SimpleSearchResult]:
        """
        Search for declarations using Python's built-in regex.

        Args:
            query: Search query (can be name, pattern, or regex)
            max_results: Maximum results to return

        Returns:
            List of search results
        """
        if not query.strip():
            return []

        results = []

        # Always search for declarations (theorem/def/lemma/etc.) matching the query.
        # This avoids matching usages like `rw [add_comm]`.
        decl_keywords = r"(?:protected\s+)?(?:noncomputable\s+)?(?:private\s+)?(theorem|def|lemma|instance|structure|class|inductive|abbrev|axiom)"

        # For dotted names like "SimpleGraph.neighborFinset", we need to search
        # for the last component and then verify the namespace matches
        if self._looks_like_exact_name(query):
            # Extract the last component for the regex search
            parts = query.rsplit(".", 1)
            last_component = re.escape(parts[-1])
            namespace_prefix = parts[0] if len(parts) > 1 else None
            pattern = re.compile(
                rf"^\s*{decl_keywords}\s+\S*{last_component}\b",
                re.MULTILINE,
            )
        else:
            namespace_prefix = None
            escaped_query = re.escape(query)
            # Non-dotted query: match declarations whose name contains the query
            pattern = re.compile(
                rf"^\s*{decl_keywords}\s+\S*{escaped_query}\S*",
                re.MULTILINE,
            )

        # Search through all Lean files — max_results only truncates output,
        # it does not limit the scan scope.
        mathlib_path = self.mathlib_dir / "Mathlib"
        total_found = 0

        for lean_file in mathlib_path.rglob("*.lean"):
            try:
                # Read file content
                with open(lean_file, encoding="utf-8") as f:
                    content = f.read()

                # Search for matches
                for match in pattern.finditer(content):
                    # Get line number and full line
                    line_no = content[: match.start()].count("\n") + 1

                    # Get the full line containing the match
                    line_start = content.rfind("\n", 0, match.start()) + 1
                    line_end = content.find("\n", match.end())
                    if line_end == -1:
                        line_end = len(content)
                    line_text = content[line_start:line_end].strip()

                    # Extract declaration kind and name from the full line
                    kind = None
                    name = "unknown"

                    # Strip modifiers to find the keyword
                    clean_line = line_text
                    for modifier in ("protected ", "noncomputable ", "private "):
                        if clean_line.startswith(modifier):
                            clean_line = clean_line[len(modifier) :]

                    for k in [
                        "theorem",
                        "def",
                        "lemma",
                        "instance",
                        "structure",
                        "class",
                        "inductive",
                        "abbrev",
                        "axiom",
                    ]:
                        if clean_line.startswith(k + " "):
                            kind = k
                            # Extract name after kind
                            after_kind = clean_line.split(k, 1)[1].strip()
                            name_part = (
                                after_kind.split()[0] if after_kind else "unknown"
                            )
                            name = (
                                name_part.split(":")[0]
                                .split("(")[0]
                                .split("{")[0]
                                .strip()
                            )
                            break

                    if name == "unknown":
                        continue

                    # Fully qualify the name using namespace context
                    namespaces = self._get_namespaces_at_line(content, line_no)
                    fq_name = self._fully_qualify_name(name, namespaces)

                    # If searching for a dotted name, verify the namespace matches
                    if namespace_prefix:
                        if not fq_name.startswith(
                            namespace_prefix + "."
                        ) and not fq_name.endswith("." + query.rsplit(".", 1)[-1]):
                            # Also check if the query appears as-is in the fq_name
                            if query not in fq_name:
                                continue

                    total_found += 1

                    # Only store up to max_results
                    if len(results) < max_results:
                        rel_path = lean_file.relative_to(self.mathlib_dir)
                        results.append(
                            SimpleSearchResult(
                                name=fq_name,
                                file=str(rel_path),
                                line=line_no,
                                text=line_text,
                                kind=kind,
                            )
                        )

            except Exception:
                # Skip files that can't be read
                continue

        # Store total_found for callers to access
        self._last_total_found = total_found
        return results

    def _looks_like_exact_name(self, query: str) -> bool:
        """Check if query looks like an exact declaration name."""
        # Names typically have dots and use camelCase or snake_case
        return "." in query and all(c.isalnum() or c in "._" for c in query)
