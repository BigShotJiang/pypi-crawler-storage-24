"""
Mathlib search functionality for LeanBack.

Provides simple regex-based search of Mathlib declarations in your project.
"""

from dataclasses import dataclass
from pathlib import Path

from .mathlib_search_simple import SimpleMathlibSearch


@dataclass
class SearchResult:
    """Structured search result."""

    name: str
    type_signature: str
    module: str | None = None
    suggested_import: str | None = None


class SearchError(Exception):
    """Search error with suggestions."""

    def __init__(
        self, message: str, error_code: str, suggestions: list[str] | None = None
    ):
        super().__init__(message)
        self.message = message
        self.error_code = error_code
        self.suggestions = suggestions or []

    def to_dict(self) -> dict:
        """Convert to dictionary for JSON output."""
        return {
            "error": True,
            "message": self.message,
            "error_code": self.error_code,
            "suggestions": self.suggestions,
        }


def search_mathlib_declarations(
    pattern: str,
    project_path: Path,
    timeout: int = 30,  # Kept for compatibility
    filter_namespace: str | None = None,  # Kept for compatibility
    exclude_internal: bool = True,  # Kept for compatibility
    max_results: int = 50,
    use_minimal_import: bool = False,  # Kept for compatibility
    backend: str = "auto",  # Kept for compatibility
) -> tuple[list[SearchResult], int]:
    """
    Search Mathlib declarations in the project.

    Args:
        pattern: Search pattern (exact name, substring, or regex)
        project_path: Path to Lean project
        max_results: Maximum results to return
        Other args kept for backwards compatibility

    Returns:
        Tuple of (results list, total_found count before truncation)
    """
    total_scanned = 0
    try:
        # Use simple search on project's Mathlib
        simple_search = SimpleMathlibSearch(project_path)
        # When post-filters are active, scan without limit so filtering
        # doesn't discard matches that happen to appear after max_results.
        has_post_filters = bool(filter_namespace) or exclude_internal
        scan_limit = 10000 if has_post_filters else max_results
        simple_results = simple_search.search(pattern, scan_limit)
        total_scanned = getattr(simple_search, "_last_total_found", 0)

        # Apply filters if provided
        if filter_namespace:
            simple_results = [
                r
                for r in simple_results
                if r.name.startswith(filter_namespace + ".")
                or r.file.startswith(filter_namespace.replace(".", "/"))
            ]

        if exclude_internal:
            simple_results = [
                r
                for r in simple_results
                if not (
                    r.name.endswith("'")
                    or r.name.endswith(".match")
                    or r.name.endswith(".proof")
                    or r.name.endswith(".rec")
                    or r.name.endswith(".mk")
                    or "._" in r.name
                )
            ]

        # Rank results: exact matches first, then prefix, then rest
        query_lower = pattern.lower()
        query_suffix = "." + query_lower  # e.g. ".add_comm"

        def _rank(r):
            name_lower = r.name.lower()
            # Exact match (e.g. "add_comm" or "Nat.add_comm" for query "add_comm")
            if name_lower == query_lower or name_lower.endswith(query_suffix):
                return 0
            # Name starts with query (prefix match)
            if name_lower.startswith(query_lower):
                return 1
            # Last component starts with query
            last = name_lower.rsplit(".", 1)[-1]
            if last.startswith(query_lower):
                return 1
            return 2

        simple_results.sort(key=_rank)

        # Truncate to requested max_results after filtering and ranking
        simple_results = simple_results[:max_results]

        # Convert to SearchResult format
        results = []
        for sr in simple_results:
            # Convert file path to module name
            module = sr.file.replace("/", ".").replace(".lean", "")
            if module.startswith("Mathlib."):
                import_stmt = f"import {module}"
            else:
                import_stmt = f"import Mathlib.{module}"

            results.append(
                SearchResult(
                    name=sr.name,
                    type_signature=sr.text,
                    module=module,
                    suggested_import=import_stmt,
                )
            )

        return results, total_scanned

    except Exception as e:
        raise SearchError(
            f"Search failed: {e!s}",
            "SEARCH_ERROR",
            ["Check that project has Mathlib", "Try a simpler pattern"],
        ) from e


def batch_search_declarations(
    patterns: list[str], project_path: Path, **kwargs
) -> dict:
    """
    Search multiple patterns efficiently.

    Args:
        patterns: List of search patterns
        project_path: Path to project
        **kwargs: Additional arguments passed to search

    Returns:
        Dictionary mapping patterns to results or errors
    """
    results = {}

    for pattern in patterns:
        try:
            search_results, total_found = search_mathlib_declarations(
                pattern, project_path, **kwargs
            )
            results[pattern] = {
                "success": True,
                "results": [
                    {
                        "name": r.name,
                        "type_signature": r.type_signature,
                        "module": r.module,
                        "suggested_import": r.suggested_import,
                    }
                    for r in search_results
                ],
                "count": len(search_results),
                "total_found": total_found,
            }
        except SearchError as e:
            results[pattern] = e.to_dict()

    return results
