# LeanBack Implementation

MCP server exposing Lean 4 development tools via Model Context Protocol.

## Module Structure

- `mcp_server.py`: MCP server — defines project_info, check, prove, goals, eval, search tools
- `check.py`: Check tool implementation
- `prove.py`: Prove tool implementation
- `goals.py`: Goals tool implementation (proof state inspection)
- `mathlib_search.py`: Search tool (Mathlib declaration search)
- `mathlib_search_simple.py`: Regex-based Mathlib search backend
- `mcp_test.py`: E2E test client
- `common/`: Shared utilities
  - `env.py`: Lean environment handling (LeanRunner)
  - `errors.py`: Error parsing and formatting
  - `project_context.py`: Project validation and context
  - `path_manager.py`: Path resolution and management
  - `util.py`: Misc utilities (temp file creation)
