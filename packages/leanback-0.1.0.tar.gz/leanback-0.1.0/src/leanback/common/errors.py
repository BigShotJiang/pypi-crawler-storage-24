"""
Error parsing and formatting utilities for Lean output.

This module provides functionality for parsing Lean's error messages and
formatting them in a user-friendly way.
"""

import json
import re
from dataclasses import dataclass
from pathlib import Path


class LeanBackError(Exception):
    """General LeanBack exception with user-friendly messages."""

    def __init__(self, message: str, suggestion: str | None = None):
        self.message = message
        self.suggestion = suggestion
        super().__init__(message)


@dataclass
class LeanError:
    """Data structure for a parsed Lean error."""

    file_name: str
    line: int
    column: int
    end_line: int | None = None
    end_column: int | None = None
    severity: str = "error"
    message: str = ""
    suggestion: str | None = None
    kind: str | None = None

    def __str__(self) -> str:
        """Format error as string."""
        # Try to use relative path for more readable output
        file_path = Path(self.file_name)
        try:
            # Attempt to make the path relative to the current working directory
            if file_path.is_absolute():
                relative_path = file_path.relative_to(Path.cwd())
                file_display = str(relative_path)
            else:
                file_display = self.file_name
        except ValueError:
            # If we can't make it relative, use the original path
            file_display = self.file_name

        location = f"{file_display}:{self.line}:{self.column}"
        if self.end_line and self.end_column:
            location += f"-{self.end_line}:{self.end_column}"

        result = f"{location}: {self.severity}: {self.message}"
        if self.suggestion:
            result += f"\nHint: {self.suggestion}"
        return result


def parse_lean_json_output(json_output: str) -> list:
    """
    Parse Lean's JSON output format into structured errors.

    Args:
        json_output: The JSON output from Lean (--json flag)

    Returns:
        List of parsed LeanError objects
    """
    errors = []

    # Skip parsing if output is empty or doesn't look like JSON
    if not json_output or not json_output.strip():
        return []

    # Quick check to avoid attempting JSON parsing on plaintext
    if not json_output.strip().startswith("{"):
        # Check if this looks like a standard Lean text error
        if "error:" in json_output or "warning:" in json_output:
            return parse_lean_text_output(json_output)
        # Otherwise, create a general parsing error
        errors.append(
            LeanError(
                file_name="unknown",
                line=0,
                column=0,
                severity="error",
                message="Unexpected output format from Lean (not JSON)",
            )
        )
        return errors

    # Lean sometimes outputs multiple JSON objects line by line instead of a proper array
    # We need to handle both formats
    if "\n{" in json_output or (
        json_output.count("}") > 1 and json_output.count("{") > 1
    ):
        # Looks like line-delimited JSON objects - process each line separately
        for line in json_output.strip().split("\n"):
            if line.strip() and line.strip().startswith("{"):
                # Process individual JSON object
                errors.extend(parse_single_json_object(line))
        return errors
    else:
        # Appears to be a single JSON object - process normally
        try:
            data = json.loads(json_output)
            return process_json_messages(data)
        except json.JSONDecodeError as e:
            # Try line-by-line parsing as a fallback
            try:
                for line in json_output.strip().split("\n"):
                    if line.strip() and line.strip().startswith("{"):
                        # Process individual JSON object
                        errors.extend(parse_single_json_object(line))
                if errors:
                    return errors
            except Exception:
                pass  # Fall through to the error reporting below

            # Provide more detailed error message
            errors.append(
                LeanError(
                    file_name="unknown",
                    line=0,
                    column=0,
                    severity="error",
                    message=f"Failed to parse Lean output as JSON: {e!s}. This might indicate a Lean crash or invalid output format.",
                )
            )
            return errors


def parse_single_json_object(json_str: str) -> list:
    """
    Parse a single JSON object from Lean output.

    Args:
        json_str: A single JSON object as string

    Returns:
        List of parsed LeanError objects
    """
    errors = []
    try:
        data = json.loads(json_str)

        # If this is a message object rather than a container of messages
        if "severity" in data and "data" in data:
            # Process as a single message
            file_name = data.get("fileName", "unknown")
            pos = data.get("pos", {})
            line = pos.get("line", 0) if isinstance(pos, dict) else 0
            column = pos.get("column", 0) if isinstance(pos, dict) else 0
            end_pos = data.get("endPos", {})
            end_line = (
                end_pos.get("line") if end_pos and isinstance(end_pos, dict) else None
            )
            end_column = (
                end_pos.get("column") if end_pos and isinstance(end_pos, dict) else None
            )
            severity = data.get("severity", "error").lower()
            if severity == "information":
                severity = "info"

            # Get message from data
            msg_text = data.get("data", "Unknown error")
            if isinstance(msg_text, dict):
                msg_text = str(msg_text)

            # Use the unified suggestion function
            suggestion = _get_suggestion_for_message(msg_text)

            errors.append(
                LeanError(
                    file_name=file_name,
                    line=line,
                    column=column,
                    end_line=end_line,
                    end_column=end_column,
                    severity=severity,
                    message=msg_text,
                    suggestion=suggestion,
                    kind=data.get("kind"),
                )
            )
        elif "messages" in data:
            # Process as a container of messages
            errors.extend(process_json_messages(data))
    except json.JSONDecodeError:
        # Skip invalid JSON objects
        pass

    return errors


def process_json_messages(data: dict) -> list:
    """
    Process messages from a parsed JSON object.

    Args:
        data: Parsed JSON data

    Returns:
        List of parsed LeanError objects
    """
    errors = []

    # Extract errors from the parsed JSON
    for message in data.get("messages", []):
        # Skip goals or other non-error messages
        if "data" in message and "goalState" in message["data"]:
            continue

        # Extract basic information
        file_name = message.get("file_name", "unknown")
        pos = message.get("pos", {})
        line = pos.get("line", 0)
        column = pos.get("column", 0)
        end_pos = message.get("end_pos", {})
        end_line = end_pos.get("line") if end_pos else None
        end_column = end_pos.get("column") if end_pos else None
        severity = message.get("severity", "error").lower()
        if severity == "information":
            severity = "info"
        msg_text = message.get("text", "Unknown error")

        # Use the unified suggestion function
        suggestion = _get_suggestion_for_message(msg_text)

        errors.append(
            LeanError(
                file_name=file_name,
                line=line,
                column=column,
                end_line=end_line,
                end_column=end_column,
                severity=severity,
                message=msg_text,
                suggestion=suggestion,
                kind=message.get("kind"),
            )
        )

    return errors


def parse_lean_text_output(text_output: str) -> list:
    """
    Parse Lean's text output format into structured errors.
    This is a fallback when JSON output isn't available.

    Args:
        text_output: The text output from Lean

    Returns:
        List of parsed LeanError objects
    """
    errors = []

    # Enhanced regex patterns for different error formats
    # Standard Lean error format: "file.lean:10:5: error: message"
    standard_pattern = (
        r"(.*?\.lean):(\d+):(\d+)(?:-(\d+):(\d+))?: (error|warning|info): (.*)"
    )

    # Lake build error format: "error: file.lean:10:5: message"
    lake_pattern = (
        r"(error|warning|info): (.*?\.lean):(\d+):(\d+)(?:-(\d+):(\d+))?: (.*)"
    )

    # Alternative format without severity prefix
    alt_pattern = r"(.*?\.lean):(\d+):(\d+)(?:-(\d+):(\d+))?: (.*)"

    # Multi-line error context tracking
    current_error = None
    context_lines = []

    lines = text_output.split("\n")
    i = 0

    while i < len(lines):
        line = lines[i]

        # Try standard pattern first
        match = re.match(standard_pattern, line)
        if match:
            # Save previous error if exists
            if current_error:
                if context_lines:
                    current_error.message += "\n" + "\n".join(context_lines)
                errors.append(current_error)
                context_lines = []

            file_name = match.group(1)
            line_num = int(match.group(2))
            col_num = int(match.group(3))
            end_line = int(match.group(4)) if match.group(4) else None
            end_col = int(match.group(5)) if match.group(5) else None
            severity = match.group(6)
            message = match.group(7)

            current_error = LeanError(
                file_name=file_name,
                line=line_num,
                column=col_num,
                end_line=end_line,
                end_column=end_col,
                severity=severity,
                message=message,
                suggestion=_get_suggestion_for_message(message),
            )
            i += 1
            continue

        # Try lake pattern
        match = re.match(lake_pattern, line)
        if match:
            if current_error:
                if context_lines:
                    current_error.message += "\n" + "\n".join(context_lines)
                errors.append(current_error)
                context_lines = []

            severity = match.group(1)
            file_name = match.group(2)
            line_num = int(match.group(3))
            col_num = int(match.group(4))
            end_line = int(match.group(5)) if match.group(5) else None
            end_col = int(match.group(6)) if match.group(6) else None
            message = match.group(7)

            current_error = LeanError(
                file_name=file_name,
                line=line_num,
                column=col_num,
                end_line=end_line,
                end_column=end_col,
                severity=severity,
                message=message,
                suggestion=_get_suggestion_for_message(message),
            )
            i += 1
            continue

        # Try alternative pattern (no severity)
        match = re.match(alt_pattern, line)
        if match and ":" in match.group(6):  # Ensure it's likely an error message
            if current_error:
                if context_lines:
                    current_error.message += "\n" + "\n".join(context_lines)
                errors.append(current_error)
                context_lines = []

            file_name = match.group(1)
            line_num = int(match.group(2))
            col_num = int(match.group(3))
            end_line = int(match.group(4)) if match.group(4) else None
            end_col = int(match.group(5)) if match.group(5) else None
            message = match.group(6)

            # Determine severity from message content
            severity = "error"
            if message.lower().startswith("warning:"):
                severity = "warning"
                message = message[8:].strip()
            elif message.lower().startswith("info:"):
                severity = "info"
                message = message[5:].strip()

            current_error = LeanError(
                file_name=file_name,
                line=line_num,
                column=col_num,
                end_line=end_line,
                end_column=end_col,
                severity=severity,
                message=message,
                suggestion=_get_suggestion_for_message(message),
            )
            i += 1
            continue

        # Check if this is a context line (starts with whitespace and current_error exists)
        if current_error and line and (line.startswith("  ") or line.startswith("\t")):
            context_lines.append(line)
        elif current_error and not line.strip():
            # Empty line might separate errors
            if context_lines:
                current_error.message += "\n" + "\n".join(context_lines)
            errors.append(current_error)
            current_error = None
            context_lines = []

        i += 1

    # Don't forget the last error
    if current_error:
        if context_lines:
            current_error.message += "\n" + "\n".join(context_lines)
        errors.append(current_error)

    # If no errors were found but there's error-like content, try to extract it
    if not errors and text_output.strip():
        # Look for common error indicators
        for line in lines:
            if any(
                indicator in line.lower()
                for indicator in ["error:", "failed", "unknown", "cannot"]
            ):
                # Extract as a general error
                errors.append(
                    LeanError(
                        file_name="unknown",
                        line=0,
                        column=0,
                        severity="error",
                        message=line.strip(),
                        suggestion=_get_suggestion_for_message(line),
                    )
                )
                break

        # If still no errors, include the full output
        if not errors:
            errors.append(
                LeanError(
                    file_name="unknown",
                    line=0,
                    column=0,
                    severity="error",
                    message=text_output.strip()[:500],  # Limit message length
                )
            )

    return errors


def _get_suggestion_for_message(message: str) -> str | None:
    """
    Get a helpful suggestion based on the error message content.

    Args:
        message: The error message

    Returns:
        A suggestion string or None
    """
    msg_lower = message.lower()

    # Simple suggestions that identify the issue without prescribing solutions
    if "unknown identifier" in msg_lower:
        # Try to extract the identifier (including dot-qualified names like Nat.add_comm)
        match = re.search(
            r"unknown identifier [`']?([\w.]+)[`']?", message, re.IGNORECASE
        )
        if match:
            ident = match.group(1)
            return f"'{ident}' is not defined in the current scope."
        return "Identifier not found in the current scope."

    elif "unknown tactic" in msg_lower:
        match = re.search(r"unknown tactic [`']?([\w.]+)[`']?", message, re.IGNORECASE)
        if match:
            tactic = match.group(1)
            return f"Tactic '{tactic}' is not available."
        return "This tactic is not available."

    elif "does not exist" in msg_lower and "import" in msg_lower:
        return "Import path not found."

    elif "unknown module prefix" in msg_lower:
        match = re.search(
            r"unknown module prefix [`']?([\w.]+)[`']?", message, re.IGNORECASE
        )
        if match:
            module = match.group(1)
            if module == "Mathlib":
                return "Mathlib is not available in this project."
            return f"Module '{module}' not found."
        return "Module not found."

    elif "failed to synthesize instance" in msg_lower:
        return "Required type class instance not found."

    # For other error types, return None to avoid being prescriptive
    return None


def parse_lean_output(output: str, json_format: bool = False) -> list:
    """
    Parse Lean's output into structured errors.

    Args:
        output: The output from Lean
        json_format: Whether the output is in JSON format

    Returns:
        List of parsed LeanError objects
    """
    if not output or not output.strip():
        return []

    if json_format:
        # Check if it actually looks like JSON before parsing it as such
        if output.strip().startswith("{"):
            try:
                return parse_lean_json_output(output)
            except Exception:
                return parse_lean_text_output(output)
        else:
            # If we expected JSON but got text, try parsing as text as a fallback
            return parse_lean_text_output(output)
    else:
        return parse_lean_text_output(output)
