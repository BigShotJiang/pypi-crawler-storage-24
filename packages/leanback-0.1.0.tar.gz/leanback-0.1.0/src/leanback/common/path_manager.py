"""
Centralized path management for LeanBack tools.

This module provides a unified interface for managing paths to project directories
and constructing the LEAN_PATH environment variable for projects using standard
Lake workflow with per-project dependencies.
"""

import tomllib
from pathlib import Path
from typing import Any


class PathManager:
    """
    Centralized path management for LeanBack tools.

    This class handles all operations related to finding, validating, and
    constructing paths for projects using standard Lake workflow.
    """

    _MAX_CACHE_SIZE = 1000

    def __init__(self):
        """Initialize a new PathManager."""
        self._cache: dict[str, Any] = {}

    def _cache_set(self, key: str, value: Any) -> None:
        """Set a cache entry, clearing the cache if it exceeds the size limit."""
        if len(self._cache) >= self._MAX_CACHE_SIZE:
            self._cache.clear()
        self._cache[key] = value

    def is_valid_project(self, project_path: str | Path, refresh: bool = False) -> bool:
        """
        Check if a path is a valid Lean project.

        A valid project must have:
        - A lean-toolchain file
        - Either lakefile.toml or lakefile.lean

        Args:
            project_path: Path to the project directory
            refresh: Whether to refresh the cached check

        Returns:
            True if the path is a valid project, False otherwise
        """
        if isinstance(project_path, str):
            project_path = Path(project_path)

        cache_key = f"valid_project:{project_path}"
        if refresh or cache_key not in self._cache:
            # Check if the directory exists
            if not project_path.exists() or not project_path.is_dir():
                self._cache_set(cache_key, False)
                return False

            # Check for lean-toolchain file
            if not (project_path / "lean-toolchain").exists():
                self._cache_set(cache_key, False)
                return False

            # Check for lakefile (either .toml or .lean)
            if (
                not (project_path / "lakefile.toml").exists()
                and not (project_path / "lakefile.lean").exists()
            ):
                self._cache_set(cache_key, False)
                return False

            self._cache_set(cache_key, True)

        return self._cache[cache_key]

    def project_uses_mathlib(
        self, project_path: str | Path, refresh: bool = False
    ) -> bool:
        """
        Check if a project uses mathlib by looking at its lakefile.toml.

        Args:
            project_path: Path to the project directory
            refresh: Whether to refresh the cached check

        Returns:
            True if the project uses mathlib, False otherwise
        """
        if isinstance(project_path, str):
            project_path = Path(project_path)

        cache_key = f"project_uses_mathlib:{project_path}"
        if refresh or cache_key not in self._cache:
            # First check if it's a valid project
            if not self.is_valid_project(project_path, refresh=refresh):
                self._cache_set(cache_key, False)
                return False

            # Look for lakefile.toml
            lakefile_path = project_path / "lakefile.toml"
            if not lakefile_path.exists():
                # For now, assume lakefile.lean doesn't use mathlib
                self._cache_set(cache_key, False)
                return False

            try:
                with open(lakefile_path, "rb") as f:
                    lake_config = tomllib.load(f)

                # Check if mathlib is in dependencies
                has_mathlib = False

                # Check for dependencies.mathlib section
                if "dependencies" in lake_config and isinstance(
                    lake_config["dependencies"], dict
                ):
                    has_mathlib = "mathlib" in lake_config["dependencies"]

                self._cache_set(cache_key, has_mathlib)

            except Exception:
                # If we can't parse the lakefile, assume it doesn't use mathlib
                self._cache_set(cache_key, False)

        return self._cache[cache_key]

    def find_project_root(self, start_path: str | Path | None = None) -> Path | None:
        """
        Find the nearest Lean project root directory by traversing up from the start path.

        Args:
            start_path: The directory to start the search from (defaults to current directory)

        Returns:
            Path to the project root or None if not found
        """
        if start_path is None:
            start_path = Path.cwd()
        elif isinstance(start_path, str):
            start_path = Path(start_path)

        # Store the original relative format of the path
        original_path = start_path

        # Use absolute path for traversal but keep track of the relative position
        current = start_path.absolute()

        # Traverse up to find a lean-toolchain file or lakefile.toml
        while current != current.parent:  # Stop at root
            if (current / "lean-toolchain").exists() and (
                (current / "lakefile.toml").exists()
                or (current / "lakefile.lean").exists()
            ):
                # Found the project root - return the path in the same format as input
                if original_path.is_absolute():
                    return current
                else:
                    try:
                        return current.relative_to(Path.cwd())
                    except ValueError:
                        return current
            current = current.parent

        return None

    def file_has_mathlib_import(
        self, file_path: str | Path, refresh: bool = False
    ) -> bool:
        """
        Check if a Lean file imports mathlib.

        Args:
            file_path: Path to the Lean file
            refresh: Whether to refresh the cached check

        Returns:
            True if the file imports mathlib, False otherwise
        """
        if isinstance(file_path, str):
            file_path = Path(file_path)

        cache_key = f"file_has_mathlib_import:{file_path}"
        if refresh or cache_key not in self._cache:
            try:
                with open(file_path) as f:
                    content = f.read()
                    self._cache_set(cache_key, "import Mathlib" in content)
            except (OSError, UnicodeDecodeError):
                self._cache_set(cache_key, False)

        return self._cache[cache_key]
