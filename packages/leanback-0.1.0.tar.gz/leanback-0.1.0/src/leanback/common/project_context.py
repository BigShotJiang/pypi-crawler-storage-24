"""
Project context management for LeanBack tools.

This module provides a unified context for working with Lean projects,
handling path resolution, validation, and environment configuration.
"""

import tomllib
from pathlib import Path
from typing import Any

from rich.console import Console

from leanback.common.path_manager import PathManager


class ProjectContext:
    """
    Context for working with Lean projects.

    This class provides a unified interface for working with Lean projects,
    handling path resolution, validation, and environment configuration.
    It uses PathManager for path-related operations.
    """

    def __init__(
        self,
        project_path: str | Path | None = None,
        console: Console | None = None,
    ):
        """
        Initialize a project context.

        Args:
            project_path: Path to the project directory (string or Path)
            console: Console for output
        """
        self.path_manager = PathManager()
        self.console = console or Console()
        self.project_path = self._resolve_project_path(project_path)
        self._config = None
        self._errors = []

    def _resolve_project_path(self, path: str | Path | None) -> Path | None:
        """
        Resolve project path from an absolute path.

        Args:
            path: Absolute path to a Lean project directory

        Returns:
            Resolved absolute Path object or None if not found
        """
        if path is None:
            return None

        potential_path = Path(str(path))
        if (
            potential_path.is_absolute()
            and potential_path.exists()
            and potential_path.is_dir()
        ):
            return potential_path.absolute()

        return None

    def _get_config(self) -> dict[str, Any] | None:
        """
        Get the lakefile.toml configuration with caching.

        Returns:
            Dict with the parsed lakefile.toml or None if not found
        """
        if self._config is not None:
            return self._config

        if not self.project_path:
            return None

        lakefile_path = self.project_path / "lakefile.toml"
        if not lakefile_path.exists():
            return None

        try:
            with open(lakefile_path, "rb") as f:
                self._config = tomllib.load(f)
            return self._config
        except Exception:
            return None

    def is_valid(self) -> bool:
        """
        Check if this context has a valid project path.

        Returns:
            True if the project path is valid, False otherwise
        """
        if not self.project_path:
            return False

        return self.path_manager.is_valid_project(self.project_path)

    def validate(self) -> tuple[bool, list[str]]:
        """
        Validate project structure and return (success, errors).

        Returns:
            Tuple of (success, list of error messages)
        """
        self._errors = []

        # Check if the path exists
        if not self.project_path:
            self._errors.append("No project path provided or found.")
            return False, self._errors

        if not self.project_path.exists():
            self._errors.append(
                f"Project directory '{self.project_path}' does not exist."
            )
            return False, self._errors

        # Check for lean-toolchain file
        toolchain_path = self.project_path / "lean-toolchain"
        if not toolchain_path.exists():
            self._errors.append(
                "No lean-toolchain file found. Create one with the desired Lean version "
                "or create a project with: lake +leanprover-community/mathlib4:lean-toolchain new <name> math"
            )
        else:
            # Verify toolchain file content
            with open(toolchain_path) as f:
                toolchain_content = f.read().strip()
                if not toolchain_content.startswith("leanprover"):
                    self._errors.append(
                        f"Invalid lean-toolchain format. Expected 'leanprover/lean4:...' but got '{toolchain_content}'. "
                        "Update the file with a valid Lean 4 version."
                    )

        # Check for lakefile (either .toml or .lean)
        lakefile_toml = self.project_path / "lakefile.toml"
        lakefile_lean = self.project_path / "lakefile.lean"

        if not lakefile_toml.exists() and not lakefile_lean.exists():
            self._errors.append(
                "No lakefile.toml or lakefile.lean found. Create one "
                "or create a project with: lake +leanprover-community/mathlib4:lean-toolchain new <name> math"
            )

        # If using lakefile.toml, check for basic configuration
        if lakefile_toml.exists():
            config = self._get_config()
            if config:
                # Check for project name (top-level or under [package])
                has_name = "name" in config or "name" in config.get("package", {})
                if not has_name:
                    self._errors.append("No 'name' field in lakefile.toml.")

                # Check for Lean library configuration
                if "lean_lib" not in config:
                    self._errors.append("No 'lean_lib' entry in lakefile.toml.")
                elif not config["lean_lib"]:
                    self._errors.append("Empty 'lean_lib' array in lakefile.toml.")
            else:
                self._errors.append("Could not parse lakefile.toml.")

        return len(self._errors) == 0, self._errors

    def resolve_file_path(self, file_path: str | Path) -> Path | None:
        """
        Resolve a file path relative to the project with smart resolution.

        This method tries various strategies to find the file:
        1. Exact path (absolute or relative to project)
        2. Common project structure patterns
        3. Search for the file name in the project

        Args:
            file_path: The file path to resolve (can be relative or just a filename)

        Returns:
            Resolved absolute Path or None if not found
        """
        if not self.project_path:
            return None

        # Convert to Path
        file_path = Path(file_path)

        # If already absolute and exists, return it
        if file_path.is_absolute() and file_path.exists():
            return file_path

        # Try exact relative path from project root
        candidate = self.project_path / file_path
        if candidate.exists():
            return candidate

        # Get the file name without directory
        file_name = file_path.name

        # Common patterns to try
        patterns = []

        # If it's just a filename (no directory), try common locations
        if str(file_path) == file_name:
            # Try ProjectName/filename pattern
            project_name = self.project_path.name
            patterns.extend(
                [
                    self.project_path / project_name / file_name,
                    self.project_path / "src" / file_name,
                    self.project_path / "lib" / file_name,
                ]
            )

        # Check all patterns
        for pattern in patterns:
            if pattern.exists():
                return pattern

        # If still not found, search for the file in the project
        # (excluding .lake directory)
        try:
            for found_file in self.project_path.rglob(file_name):
                # Skip files in .lake directory
                if ".lake" not in found_file.parts:
                    return found_file
        except Exception:
            pass

        return None

    def suggest_file_path(self, file_path: str | Path) -> list[str]:
        """
        Suggest possible file paths when the exact path is not found.

        Args:
            file_path: The file path that wasn't found

        Returns:
            List of suggestions (relative paths from project root)
        """
        if not self.project_path:
            return []

        suggestions = []
        file_name = Path(file_path).name

        # Remove .lean extension for matching
        base_name = file_name.replace(".lean", "")

        try:
            # Find similar files
            for found_file in self.project_path.rglob("*.lean"):
                # Skip files in .lake directory
                if ".lake" in found_file.parts:
                    continue

                found_base = found_file.stem

                # Check for similar names (case-insensitive)
                if (
                    base_name.lower() in found_base.lower()
                    or found_base.lower() in base_name.lower()
                ):
                    rel_path = found_file.relative_to(self.project_path)
                    suggestions.append(str(rel_path))

                # Stop after finding 5 suggestions
                if len(suggestions) >= 5:
                    break
        except Exception:
            pass

        return suggestions
