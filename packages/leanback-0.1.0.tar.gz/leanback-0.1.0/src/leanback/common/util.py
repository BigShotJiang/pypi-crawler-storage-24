"""
Utility functions for the LeanBack tools.

This module contains common utility functions used across the tools.
"""

import os
import tempfile
from pathlib import Path


def create_temp_file(content: str, suffix: str = ".lean") -> Path:
    """
    Create a temporary file with the given content.

    Args:
        content: Content to write to the file
        suffix: File suffix

    Returns:
        Path to the temporary file
    """
    fd, temp_path = tempfile.mkstemp(suffix=suffix)
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as f:
            f.write(content)
        return Path(temp_path)
    except Exception:
        # Clean up if something goes wrong
        os.unlink(temp_path)
        raise


def build_proof_content(
    theorem: str,
    tactics: list[str],
    imports: list[str],
) -> tuple[str, dict[int, int]]:
    """Build a Lean proof file from theorem, tactics, and imports.

    Returns:
        (content, line_to_tactic_map) where line_to_tactic_map maps
        1-based line numbers to 0-based tactic indices. Multi-line
        tactics get entries for each line they span.
    """
    lines: list[str] = []

    # Imports
    for imp in imports:
        lines.append(f"import {imp}")
    if imports:
        lines.append("")  # blank separator

    # Theorem statement — wrap bare propositions
    theorem_stmt = theorem.strip()
    if not any(
        theorem_stmt.startswith(kw + " ") for kw in ["theorem", "lemma", "example"]
    ):
        theorem_stmt = f"theorem test_theorem : {theorem_stmt}"
    lines.append(f"{theorem_stmt} := by")

    # Tactics with line mapping (1-based line numbers, 0-based tactic indices)
    line_to_tactic: dict[int, int] = {}
    for i, tactic in enumerate(tactics):
        tactic_lines = tactic.split("\n")
        for tl in tactic_lines:
            lines.append(f"  {tl}")
            line_number = len(lines)  # 1-based (len after append)
            line_to_tactic[line_number] = i

    content = "\n".join(lines) + "\n"
    return content, line_to_tactic
