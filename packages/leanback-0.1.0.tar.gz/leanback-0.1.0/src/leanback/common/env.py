"""
Lean environment handling utilities.

This module provides functionality for executing Lean commands in the correct environment.
"""

import os
import subprocess
from pathlib import Path


class LeanRunner:
    """
    Utility for running Lean commands in the appropriate environment.
    """

    @staticmethod
    def run_lean(
        file_path: str | Path,
        project_path: str | Path | None = None,
        capture_json: bool = False,
        check: bool = True,
        env_vars: dict[str, str] | None = None,
        timeout: float | None = None,
    ) -> tuple[int, str, str]:
        """
        Run Lean on a file in the appropriate environment.

        Args:
            file_path: Path to the Lean file to run
            project_path: Path to a Lean project (for lake env)
            capture_json: Whether to request JSON output
            check: Whether to raise an exception on non-zero exit codes
            env_vars: Additional environment variables
            timeout: Timeout in seconds

        Returns:
            Tuple of (exit_code, stdout, stderr)
        """
        # Convert to Path
        if isinstance(file_path, str):
            file_path = Path(file_path)

        # We need absolute paths for checking existence internally
        abs_file_path = file_path.absolute()

        # Determine which path and command to use
        if project_path:
            # If a project is specified, use that project's environment
            project_path = (
                Path(project_path) if isinstance(project_path, str) else project_path
            )

            # Always use lake env lean for projects - this ensures proper dependency management
            command = ["lake", "env", "lean"]
            if capture_json:
                command.append("--json")
            command.append(str(abs_file_path))
            cwd = project_path

            # Lake automatically handles all dependency paths - no manual LEAN_PATH setup needed

        else:
            # Default: run directly with lean for files without project context
            command = ["lean"]
            if capture_json:
                command.append("--json")
            command.append(str(abs_file_path))

            cwd = file_path.parent

        # Set up environment
        proc_env = os.environ.copy()
        if env_vars:
            proc_env.update(env_vars)

        try:
            result = subprocess.run(
                command,
                cwd=cwd,
                check=check,
                capture_output=True,
                text=True,
                env=proc_env,
                timeout=timeout,
            )
            return result.returncode, result.stdout, result.stderr
        except subprocess.CalledProcessError as e:
            return e.returncode, e.stdout, e.stderr
        except subprocess.TimeoutExpired:
            return 124, "", "Lean execution timed out"
