"""
Implementation of the leanback-goals tool.

This module provides goal state inspection during Lean proof construction.
"""

import os
from pathlib import Path

from rich.console import Console

from leanback.common.util import build_proof_content, create_temp_file


def parse_goals(data: str) -> list[str]:
    """Parse Lean's 'unsolved goals' data into individual goal strings.

    Strips the 'unsolved goals' prefix and splits on blank lines.
    Each chunk is one goal (hypotheses + ⊢ conclusion).

    Args:
        data: The raw data string from a Tactic.unsolvedGoals message.

    Returns:
        List of goal strings.
    """
    text = data.strip()

    # Strip "unsolved goals\n" prefix if present
    prefix = "unsolved goals\n"
    if text.startswith(prefix):
        text = text[len(prefix) :]
    elif text == "unsolved goals":
        return []

    if not text:
        return []

    # Split on blank lines (double newline)
    raw_goals = text.split("\n\n")
    return [g.strip() for g in raw_goals if g.strip()]


def extract_goals(
    theorem: str,
    tactics: list[str] | None,
    imports: list[str] | None,
    project_path: Path,
    console: Console,
) -> dict:
    """Run a partial proof and return the goal state.

    Args:
        theorem: Theorem statement.
        tactics: Tactic list (None/empty for initial goal).
        imports: Module imports.
        project_path: Path to Lean project.
        console: Rich console for logging.

    Returns:
        Structured dict with success, status, goals, etc.
    """
    from leanback.check import check_file

    effective_tactics = list(tactics) if tactics else []
    use_skip = len(effective_tactics) == 0

    # Use 'skip' for empty tactics to avoid syntax error from empty by block
    build_tactics = ["skip"] if use_skip else effective_tactics

    content, line_to_tactic = build_proof_content(
        theorem=theorem,
        tactics=build_tactics,
        imports=imports or [],
    )

    temp_file = create_temp_file(content)

    try:
        success, errors = check_file(
            file_path=temp_file,
            project_path=project_path,
            console=console,
        )
    finally:
        try:
            os.unlink(temp_file)
        except OSError:
            pass

    # Classify output using kind field
    unsolved_goals_msgs = [e for e in errors if e.kind == "Tactic.unsolvedGoals"]
    sorry_msgs = [e for e in errors if e.kind == "hasSorry"]
    other_errors = [
        e for e in errors if e.severity == "error" and e.kind != "Tactic.unsolvedGoals"
    ]

    tactics_count = len(effective_tactics)

    # Case 1: Proof complete (no errors)
    if success and not sorry_msgs:
        return {
            "success": True,
            "status": "complete",
            "tactics_applied": tactics_count,
            "goals": [],
        }

    # Case 2: Sorry used (proof "complete" but not valid)
    if success and sorry_msgs:
        return {
            "success": True,
            "status": "complete",
            "tactics_applied": tactics_count,
            "goals": [],
            "sorry_used": True,
        }

    # Case 3: Goals remain (unsolved goals, no other errors)
    if unsolved_goals_msgs and not other_errors:
        goals = []
        for msg in unsolved_goals_msgs:
            goals.extend(parse_goals(msg.message))
        return {
            "success": True,
            "status": "incomplete",
            "tactics_applied": tactics_count,
            "goals": goals,
        }

    # Case 4: Tactic or setup error
    # Try to identify which tactic failed using line mapping
    failed_tactic_info = None
    goals_from_unsolved = []

    if unsolved_goals_msgs:
        for msg in unsolved_goals_msgs:
            goals_from_unsolved.extend(parse_goals(msg.message))

    for err in other_errors:
        if err.line in line_to_tactic and not use_skip:
            tactic_idx = line_to_tactic[err.line]
            failed_tactic_info = {
                "index": tactic_idx,
                "tactic": effective_tactics[tactic_idx],
                "error": err.message,
            }
            break

    result: dict = {
        "success": False,
        "status": "error",
        "tactics_applied": failed_tactic_info["index"] if failed_tactic_info else 0,
        "goals": goals_from_unsolved,
    }

    if failed_tactic_info:
        result["failed_tactic"] = failed_tactic_info

    # Include raw messages for debugging
    result["messages"] = [
        {"severity": e.severity, "message": e.message}
        for e in errors
        if e.severity == "error"
    ]

    return result
