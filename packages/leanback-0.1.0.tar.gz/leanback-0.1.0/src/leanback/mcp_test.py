#!/usr/bin/env python3
"""E2E test client for LeanBack MCP server."""

import argparse
import asyncio
import json
import logging
import sys
import traceback
from pathlib import Path

from mcp.client.session import ClientSession
from mcp.client.stdio import StdioServerParameters, stdio_client


# Configure logging
logging.basicConfig(
    level=logging.INFO, format="%(asctime)s - %(levelname)s - %(message)s"
)
logger = logging.getLogger(__name__)


async def test_check_tool(session: ClientSession, project: str):
    """Test the check tool."""
    logger.info("Testing check tool...")

    # Test 1: Check entire project
    logger.info(f"  Test 1: Checking entire project '{project}'")
    try:
        result = await session.call_tool("check", {"project": project})
        content = result.content[0] if result.content else None
        if content and hasattr(content, "text"):
            data = json.loads(content.text)
            logger.info(f"  Result: {json.dumps(data, indent=2)}")
        else:
            logger.info(f"  Raw result: {result}")
    except Exception as e:
        logger.error(f"  Failed: {e}")
        traceback.print_exc()

    # Test 2: Check specific file
    logger.info("  Test 2: Checking specific file 'test_simple_proof.lean'")
    try:
        result = await session.call_tool(
            "check", {"project": project, "file": "test_simple_proof.lean"}
        )
        content = result.content[0] if result.content else None
        if content and hasattr(content, "text"):
            data = json.loads(content.text)
            logger.info(f"  Result: {json.dumps(data, indent=2)}")
    except Exception as e:
        logger.error(f"  Failed: {e}")

    # Test 3: Check expression
    logger.info("  Test 3: Checking expression '#check 2 + 2 = 4'")
    try:
        result = await session.call_tool(
            "check", {"project": project, "expr": "#check 2 + 2 = 4"}
        )
        content = result.content[0] if result.content else None
        if content and hasattr(content, "text"):
            data = json.loads(content.text)
            logger.info(f"  Result: {json.dumps(data, indent=2)}")
    except Exception as e:
        logger.error(f"  Failed: {e}")

    logger.info("✓ Check tool tests completed")


async def test_prove_tool(session: ClientSession, project: str):
    """Test the prove tool."""
    logger.info("Testing prove tool...")

    # Test 1: Simple theorem with tactic
    logger.info("  Test 1: Proving simple theorem '2 + 2 = 4'")
    try:
        result = await session.call_tool(
            "prove", {"project": project, "theorem": "2 + 2 = 4", "tactics": ["rfl"]}
        )
        content = result.content[0] if result.content else None
        if content and hasattr(content, "text"):
            data = json.loads(content.text)
            logger.info(f"  Result: {json.dumps(data, indent=2)}")
    except Exception as e:
        logger.error(f"  Failed: {e}")

    # Test 2: Verify proof file
    logger.info("  Test 2: Verifying proof file 'test_simple_proof.lean'")
    try:
        result = await session.call_tool(
            "prove", {"project": project, "file": "test_simple_proof.lean"}
        )
        content = result.content[0] if result.content else None
        if content and hasattr(content, "text"):
            data = json.loads(content.text)
            logger.info(f"  Result: {json.dumps(data, indent=2)}")
    except Exception as e:
        logger.error(f"  Failed: {e}")

    # Test 3: Theorem with mathlib
    logger.info("  Test 3: Proving theorem with mathlib")
    try:
        result = await session.call_tool(
            "prove",
            {
                "project": project,
                "theorem": "∀ n : Nat, n + 0 = n",
                "tactics": ["intro n", "rfl"],
                "mathlib": True,
            },
        )
        content = result.content[0] if result.content else None
        if content and hasattr(content, "text"):
            data = json.loads(content.text)
            logger.info(f"  Result: {json.dumps(data, indent=2)}")
    except Exception as e:
        logger.error(f"  Failed: {e}")

    logger.info("✓ Prove tool tests completed")


async def test_eval_tool(session: ClientSession, project: str):
    """Test the eval tool."""
    logger.info("Testing eval tool...")

    # Test 1: Evaluate expression
    logger.info("  Test 1: Evaluating expression '#eval 2 + 2'")
    try:
        result = await session.call_tool(
            "eval", {"project": project, "code": "#eval 2 + 2"}
        )
        content = result.content[0] if result.content else None
        if content and hasattr(content, "text"):
            data = json.loads(content.text)
            logger.info(f"  Result: {json.dumps(data, indent=2)}")
    except Exception as e:
        logger.error(f"  Failed: {e}")

    # Test 2: Check type
    logger.info("  Test 2: Checking type '#check Nat.add'")
    try:
        result = await session.call_tool(
            "eval", {"project": project, "code": "#check Nat.add"}
        )
        content = result.content[0] if result.content else None
        if content and hasattr(content, "text"):
            data = json.loads(content.text)
            logger.info(f"  Result: {json.dumps(data, indent=2)}")
    except Exception as e:
        logger.error(f"  Failed: {e}")

    # Test 3: Evaluate with mathlib
    logger.info("  Test 3: Evaluating with mathlib")
    try:
        result = await session.call_tool(
            "eval",
            {
                "project": project,
                "code": "example : ∃ x : Nat, x > 0 := by use 1; simp",
                "mathlib": True,
            },
        )
        content = result.content[0] if result.content else None
        if content and hasattr(content, "text"):
            data = json.loads(content.text)
            logger.info(f"  Result: {json.dumps(data, indent=2)}")
    except Exception as e:
        logger.error(f"  Failed: {e}")

    logger.info("✓ Eval tool tests completed")


async def test_search_tool(session: ClientSession, project: str):
    """Test the search tool."""
    logger.info("Testing search tool...")

    # Test 1: Search for a pattern
    logger.info("  Test 1: Searching for 'add_comm'")
    try:
        result = await session.call_tool(
            "search", {"project": project, "pattern": "add_comm", "max_results": 5}
        )
        content = result.content[0] if result.content else None
        if content and hasattr(content, "text"):
            data = json.loads(content.text)
            logger.info(f"  Result: Found {len(data.get('results', []))} matches")
            if data.get("results"):
                logger.info(f"    First match: {data['results'][0]['name']}")
    except Exception as e:
        logger.error(f"  Failed: {e}")

    # Test 2: Batch search
    logger.info("  Test 2: Batch searching for 'add_comm,mul_comm,sub_eq_add_neg'")
    try:
        result = await session.call_tool(
            "search",
            {
                "project": project,
                "batch": "add_comm,mul_comm,sub_eq_add_neg",
                "max_results": 3,
            },
        )
        content = result.content[0] if result.content else None
        if content and hasattr(content, "text"):
            data = json.loads(content.text)
            logger.info(f"  Result: {json.dumps(data, indent=2)}")
    except Exception as e:
        logger.error(f"  Failed: {e}")

    # Test 3: Filtered search
    logger.info("  Test 3: Searching for 'reverse' in List namespace")
    try:
        result = await session.call_tool(
            "search",
            {
                "project": project,
                "pattern": "reverse",
                "filter_namespace": "List",
                "max_results": 5,
            },
        )
        content = result.content[0] if result.content else None
        if content and hasattr(content, "text"):
            data = json.loads(content.text)
            logger.info(
                f"  Result: Found {len(data.get('results', []))} matches in List namespace"
            )
    except Exception as e:
        logger.error(f"  Failed: {e}")

    logger.info("✓ Search tool tests completed")


async def test_goals_tool(session: ClientSession, project: str):
    """Test the goals tool."""
    logger.info("Testing goals tool...")

    # Test 1: Initial goal (no tactics)
    logger.info("  Test 1: Initial goal for '∀ n : Nat, n + 0 = n'")
    try:
        result = await session.call_tool(
            "goals",
            {"project": project, "theorem": "∀ n : Nat, n + 0 = n"},
        )
        content = result.content[0] if result.content else None
        if content and hasattr(content, "text"):
            data = json.loads(content.text)
            logger.info(f"  Result: {json.dumps(data, indent=2)}")
    except Exception as e:
        logger.error(f"  Failed: {e}")

    # Test 2: Partial tactics (goals remain)
    logger.info("  Test 2: After 'intro n'")
    try:
        result = await session.call_tool(
            "goals",
            {
                "project": project,
                "theorem": "∀ n : Nat, n + 0 = n",
                "tactics": ["intro n"],
            },
        )
        content = result.content[0] if result.content else None
        if content and hasattr(content, "text"):
            data = json.loads(content.text)
            logger.info(f"  Result: {json.dumps(data, indent=2)}")
    except Exception as e:
        logger.error(f"  Failed: {e}")

    # Test 3: Complete proof
    logger.info("  Test 3: Complete proof with simp")
    try:
        result = await session.call_tool(
            "goals",
            {
                "project": project,
                "theorem": "∀ n : Nat, n + 0 = n",
                "tactics": ["intro n", "simp"],
                "mathlib": True,
            },
        )
        content = result.content[0] if result.content else None
        if content and hasattr(content, "text"):
            data = json.loads(content.text)
            logger.info(f"  Result: {json.dumps(data, indent=2)}")
    except Exception as e:
        logger.error(f"  Failed: {e}")

    # Test 4: Tactic failure
    logger.info("  Test 4: Failing tactic (rfl on non-reflexive goal)")
    try:
        result = await session.call_tool(
            "goals",
            {
                "project": project,
                "theorem": "∀ n m : Nat, n + m = m + n",
                "tactics": ["intro n", "intro m", "rfl"],
            },
        )
        content = result.content[0] if result.content else None
        if content and hasattr(content, "text"):
            data = json.loads(content.text)
            logger.info(f"  Result: {json.dumps(data, indent=2)}")
    except Exception as e:
        logger.error(f"  Failed: {e}")

    # Test 5: Multiple goals (constructor)
    logger.info("  Test 5: Multiple goals with constructor")
    try:
        result = await session.call_tool(
            "goals",
            {
                "project": project,
                "theorem": "True ∧ True",
                "tactics": ["constructor"],
            },
        )
        content = result.content[0] if result.content else None
        if content and hasattr(content, "text"):
            data = json.loads(content.text)
            logger.info(f"  Result: {json.dumps(data, indent=2)}")
    except Exception as e:
        logger.error(f"  Failed: {e}")

    # Test 6: Induction (case labels)
    logger.info("  Test 6: Induction goals")
    try:
        result = await session.call_tool(
            "goals",
            {
                "project": project,
                "theorem": "∀ n : Nat, 0 + n = n",
                "tactics": ["intro n", "induction n"],
            },
        )
        content = result.content[0] if result.content else None
        if content and hasattr(content, "text"):
            data = json.loads(content.text)
            logger.info(f"  Result: {json.dumps(data, indent=2)}")
    except Exception as e:
        logger.error(f"  Failed: {e}")

    # Test 7: Sorry
    logger.info("  Test 7: Sorry usage")
    try:
        result = await session.call_tool(
            "goals",
            {
                "project": project,
                "theorem": "∀ n : Nat, n + 0 = n",
                "tactics": ["intro n", "sorry"],
            },
        )
        content = result.content[0] if result.content else None
        if content and hasattr(content, "text"):
            data = json.loads(content.text)
            logger.info(f"  Result: {json.dumps(data, indent=2)}")
    except Exception as e:
        logger.error(f"  Failed: {e}")

    logger.info("✓ Goals tool tests completed")


async def show_tool_descriptions():
    """Connect to the MCP server and display tool descriptions."""
    server_params = StdioServerParameters(
        command="uv",
        args=["run", "python", "-m", "leanback.mcp_server"],
    )

    try:
        logger.info("Connecting to LeanBack MCP server...")
        async with stdio_client(server_params) as (read, write):
            async with ClientSession(read, write) as session:
                await session.initialize()
                logger.info("✓ Connected to server\n")

                try:
                    tools_result = await session.list_tools()
                    for tool in tools_result.tools:
                        print(f"=== Tool: {tool.name} ===")
                        print(f"\n{tool.description}")
                        print("\n" + "=" * 50 + "\n")
                except Exception as e:
                    logger.error(f"Failed to list tools: {e}")
                    raise

    except Exception as e:
        logger.error(f"Failed to connect: {e}")
        raise


async def run_tests(project: str, tool: str | None):
    """Run tests against the MCP server."""
    server_params = StdioServerParameters(
        command="uv",
        args=["run", "python", "-m", "leanback.mcp_server"],
    )

    try:
        logger.info("Connecting to LeanBack MCP server...")
        async with stdio_client(server_params) as (read, write):
            async with ClientSession(read, write) as session:
                await session.initialize()
                logger.info("✓ Connected to server")

                # List available tools
                try:
                    tools_result = await session.list_tools()
                    tool_names = [t.name for t in tools_result.tools]
                    logger.info(f"Available tools: {tool_names}")
                except Exception as e:
                    logger.error(f"Failed to list tools: {e}")
                    raise

                # Run tests based on specified tool
                if tool is None or tool == "check":
                    await test_check_tool(session, project)
                if tool is None or tool == "prove":
                    await test_prove_tool(session, project)
                if tool is None or tool == "goals":
                    await test_goals_tool(session, project)
                if tool is None or tool == "eval":
                    await test_eval_tool(session, project)
                if tool is None or tool == "search":
                    await test_search_tool(session, project)

    except Exception as e:
        logger.error(f"Test failed: {e}")
        raise


def main():
    """Main entry point for the test client."""
    parser = argparse.ArgumentParser(description="LeanBack MCP Server Test Client")
    parser.add_argument(
        "--project",
        "-p",
        type=str,
        required=False,
        help="Absolute path to a Lean project for testing (required for tool tests)",
    )
    parser.add_argument(
        "--tool",
        type=str,
        choices=["check", "prove", "goals", "eval", "search"],
        help="Test specific tool only",
    )
    parser.add_argument(
        "--debug",
        action="store_true",
        help="Enable debug logging",
    )
    parser.add_argument(
        "--tool-descriptions",
        action="store_true",
        help="Display tool descriptions and exit",
    )

    args = parser.parse_args()

    if args.debug:
        logging.getLogger().setLevel(logging.DEBUG)

    # Show tool descriptions (no project needed)
    if args.tool_descriptions:
        try:
            asyncio.run(show_tool_descriptions())
        except Exception:
            logger.error("Failed to show tool descriptions!")
            sys.exit(1)
        return

    # For tool tests, project is required
    if not args.project:
        logger.error("--project is required for tool tests")
        parser.print_usage()
        sys.exit(1)

    # Validate project path
    project_path = Path(args.project).resolve()
    if not project_path.exists():
        logger.error(f"Project directory does not exist: {project_path}")
        sys.exit(1)

    # Run tests
    try:
        asyncio.run(run_tests(str(project_path), args.tool))
        logger.info("All tests passed!")
    except Exception:
        logger.error("Tests failed!")
        sys.exit(1)


if __name__ == "__main__":
    main()
