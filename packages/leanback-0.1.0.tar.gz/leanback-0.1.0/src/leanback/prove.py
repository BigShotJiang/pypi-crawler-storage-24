"""
Implementation of the leanback-prove tool.

This module provides functionality for verifying Lean proofs.
"""

import os
from pathlib import Path

from rich.console import Console

from leanback.common.errors import LeanError
from leanback.common.util import build_proof_content, create_temp_file


def verify_proof(
    theorem: str,
    tactics: list[str] | None = None,
    proof_file: str | Path | None = None,
    imports: list[str] | None = None,
    project_path: str | Path | None = None,
    console: Console | None = None,
) -> tuple[bool, list[LeanError]]:
    """
    Verify a proof without interactive mode.

    Args:
        theorem: The theorem statement to prove
        tactics: List of tactics to apply
        proof_file: Path to a file containing the proof
        imports: List of modules to import
        project_path: Path to the Lean project
        console: Rich console for output

    Returns:
        Tuple of (success, errors)
    """
    if console is None:
        console = Console()

    if project_path and isinstance(project_path, str):
        project_path = Path(project_path)

    # If proof_file is provided, read the proof from file
    if proof_file:
        proof_file = Path(proof_file) if isinstance(proof_file, str) else proof_file
        if not proof_file.exists():
            return False, [
                LeanError(
                    file_name=str(proof_file),
                    line=0,
                    column=0,
                    severity="error",
                    message=f"Proof file '{proof_file}' does not exist",
                )
            ]

        # Run Lean on the file directly
        from leanback.check import check_file

        return check_file(
            file_path=proof_file, project_path=project_path, console=console
        )

    # Otherwise, construct a proof from theorem and tactics
    content, _ = build_proof_content(
        theorem=theorem,
        tactics=tactics or [],
        imports=imports or [],
    )

    # Create a temporary file
    temp_file = create_temp_file(content)

    try:
        # Check the temporary file
        from leanback.check import check_file

        return check_file(
            file_path=temp_file, project_path=project_path, console=console
        )
    finally:
        # Clean up
        try:
            os.unlink(temp_file)
        except OSError:
            pass
