import re 

def validate_auth(email: str) -> bool:
    return bool(re.match(r"(?:\S+@\S+\.\S+|[a-zA-Z0-9._-]+)(?::|\|)\S+", email))