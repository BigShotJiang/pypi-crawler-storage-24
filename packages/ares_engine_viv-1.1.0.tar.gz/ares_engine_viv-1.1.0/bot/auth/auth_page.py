import time
from rich.console import Console
from rich.panel import Panel
from rich.align import Align
from rich.text import Text
from rich.live import Live
from rich import box
from bot.auth.authentication import Authentication


console = Console()
auth  = Authentication()

def typewriter(text, style="bold cyan", delay=0.03):
    for char in text:
        console.print(char, style=style, end="")
        time.sleep(delay)
    console.print()


def blinking_text(message, duration=4):
    end_time = time.time() + duration
    while time.time() < end_time:
        console.print(f"[bold red]{message}[/bold red]", justify="center")
        time.sleep(0.4)
        console.print(" " * len(message), justify="center")
        time.sleep(0.4)


def show_banner():
    banner = """
▄█████╗ ██████╗ ███████╗███████╗
██╔══██╗██╔══██╗██╔════╝██╔════╝
███████║██████╔╝█████╗  ███████╗
██╔══██║██╔══██╗██╔══╝  ╚════██║
██║  ██║██║  ██║███████╗███████║
╚═╝  ╚═╝╚═╝  ╚═╝╚══════╝╚══════╝
    """
    header = Text()
    header.append(f"{banner}\n", style="bold cyan")
    header.append("ARES v3\n\n", style="bold yellow")
    header.append("Secure • Encrypted • Licensed\n", style="bold green")

    console.print(header)


def show_license_notice():
    notice_text = Text()
    notice_text.append("ACCESS DENIED\n\n", style="bold red")
    notice_text.append("A valid license key is required.\n\n", style="white")
    notice_text.append("If you don't have a license key,\n", style="white")
    notice_text.append("Contact Telegram Support:\n\n", style="white")
    notice_text.append("@cheetah_ares", style="bold green underline")


    console.print(notice_text)


def authentication_page():
    console.clear()

    # Typewriter intro
    typewriter("Initializing ARES Secure System...", "bold cyan")
    time.sleep(0.5)
    typewriter("Loading encrypted modules...", "bold magenta")
    time.sleep(1)

    console.clear()
    show_banner()
    is_available  = auth.check_auth()
    
    information  = "[ PROCESSING REQUEST... ]" if is_available else "[ !!! LICENSE REQUIRED !!! ]"

    warning_w = Text.assemble((f"{information}\n", f"bold { "green" if is_available else "red"} blink"))
    console.print(warning_w)

    # Blinking warning
    # blinking_text("!!! LICENSE REQUIRED !!!", duration=5)

