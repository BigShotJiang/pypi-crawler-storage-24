from rich.console import Console
from rich.panel import Panel
from rich.columns import Columns
from rich.box import DOUBLE_EDGE, ROUNDED
from rich.align import Align
from rich.text import Text
from rich.table import Table
from bot.utils.common_utils import clear_screen, choice_selector
from bot.ui.banner import Banner
import time
import sys
from rich.live import Live

console = Console()
banner = Banner(console)

def display_about():
    clear_screen()
    banner.about()

    header = Panel(
        Text("ARES-V3 APEX CLUSTER\nAdvanced Automation & Biometric Security Bypass", 
             justify="center", style="bold white on blue"),
        subtitle="[v3.0.4-STABLE]",
        expand=True
    )
    console.print(header)

    about_table = Table(show_header=False, box=None, padding=(0, 2))
    about_table.add_row(
        "[bold cyan]ENGINE CORE[/bold cyan]", 
        "Asynchronous Producer-Consumer architecture using [bold green]asyncio.Queue[/bold green]. "
        "Engineered for high-throughput with zero memory leakage on 2M+ lines."
    )
    about_table.add_row(
        "[bold cyan]BIOMETRICS[/bold cyan]", 
        "Human-emulated input patterns using [bold green]Bézier curve mouse movement[/bold green] "
        "and Gaussian-distributed typing delays to bypass behavioral analysis."
    )
    about_table.add_row(
        "[bold cyan]STEALTH[/bold cyan]", 
        "Integrated [bold green]Playwright-Stealth[/bold green] with TLS fingerprint "
        "obfuscation and dynamic User-Agent rotation per worker context."
    )
    about_table.add_row(
        "[bold cyan]BACKPRESSURE[/bold cyan]", 
        "Dynamic flow control prevents memory spikes. The engine streams data from "
        "disk in real-time rather than pre-loading into RAM."
    )
    
    console.print(Panel(about_table, title="[bold white]Architecture DeAmbantares1tails[/bold white]", border_style="cyan"))

    features = [
        Panel("[bold green]✓[/bold green] WAF/Rate-Limit Auto-Backoff", border_style="dim"),
        Panel("[bold green]✓[/bold green] Multi-Threaded Context Isolation", border_style="dim"),
        Panel("[bold green]✓[/bold green] Deep-Verify Auth Validation", border_style="dim"),
        Panel("[bold green]✓[/bold green] Real-time Rich Telemetry", border_style="dim"),
    ]
    console.print(Columns(features))

    console.print("\n[dim italic]Ares version 3.0.4. "
                  "Designed for extreme-scale credential validation and stress testing.[/dim italic]")


def typewrite_text(text: str, style: str = "bold white"):
    """Simulates a typewriter effect for terminal flair."""
    console = Console()
    displayed_text = ""
    for char in text:
        displayed_text += char
        console.print(f"[{style}]{char}[/]", end="")
        sys.stdout.flush()
        time.sleep(0.01)
    print()

def display_help():
    console = Console()
    
    # 1. Typewriter Intro (Optional - remove sleep if you want it instant)
    typewrite_text(" > INITIALIZING ARES_ENGINE HELP_MOD...", style="bold cyan")
    
    # --- Header Banner ---
    # Using 'blink' on the engine name and 'reverse' for high contrast
    header_text = Text.assemble(
        ("\n ⚡ ", "bold gold1"), 
        ("ARES", "bold white blink"), 
        (" ENGINE ", "bold reverse white"),  
        (" SYNCHRONIZED ", "italic green"),
        (" v3.0.4 ", "italic dim white"), 
        (" ⚡ \n", "bold gold1")
    )
    console.print(Panel(header_text, style="bold gold1", border_style="gold1", box=DOUBLE_EDGE, expand=True))

    # --- Table 1: Status & Execution ---
    status_table = Table(show_header=True, header_style="bold magenta", box=ROUNDED, border_style="bright_black")
    status_table.add_column("Code", width=10)
    status_table.add_column("State / Vector", width=25)
    status_table.add_column("Heuristic Logic", style="dim")

    status_table.add_row(
        "[bold green]HIT[/]", 
        "Telemetry Positive", 
        "State mutation exceeds Heuristic Threshold (2-5)"
    )
    status_table.add_row(
        "[bold red]FAIL[/]", 
        "State Static", 
        "Zero mutation detected / Negative string match"
    )
    status_table.add_row(
        "[bold orange1]WAF[/]", 
        "Traffic Blocked", 
        "Gateway 403/429. Auto-sequencing backoff engaged"
    )
    status_table.add_row(
        "[bold magenta]ERR[/]", 
        "Process Fault", 
        "Internal driver timeout or context initialization fail"
    )
    status_table.add_row(
        "[bold cyan]CONN[/]", 
        "Handshaking", 
        "Negotiating TLS cipher suites and DOM availability"
    )

    # --- Table 2: Scoring & Telemetry ---
    score_table = Table(show_header=True, header_style="bold blue", box=ROUNDED, border_style="bright_black")
    score_table.add_column("Signal", width=12)
    score_table.add_column("Weight", justify="center")
    score_table.add_column("Impact Vector")

    # Replaced 'valid auth' with 'Endpoint recognition' and 'Session mutation'
    score_table.add_row("API Probe", "[bold green]+3[/]", "Backend endpoint recognized session token")
    score_table.add_row("Cookie Diff", "[bold green]+2[/]", "Header-level session persistence detected")
    score_table.add_row("Storage", "[bold green]+2[/]", "Local/Session storage state mutation")
    score_table.add_row("URL Signal", "[bold green]+1[/]", "Navigation to post-submission directory")
    score_table.add_row("DOM Shift", "[bold green]+1[/]", "Input vector removal from active viewport")

    # --- Layout into Columns ---
    console.print(Columns([
        Panel(status_table, title="[bold white]Runtime Telemetry[/]", border_style="magenta", padding=(1, 2)),
        Panel(score_table, title="[bold white]Signal Assessment[/]", border_style="blue", padding=(1, 2))
    ]))

    # --- Footer Tip with Blink ---
    footer_text = Text.assemble(
        (" 💡 ", "bold yellow"),
        ("PRO TIP: ", "bold white"),
        ("Monitor ", "dim white"),
        ("ares_engine.log", "italic cyan"),
        (" for real-time JSON packet traces.", "dim white"),
        (" [SYSTEM READY]", "bold green blink")
    )
    
    console.print(Panel(footer_text, style="white", border_style="bright_black"))
