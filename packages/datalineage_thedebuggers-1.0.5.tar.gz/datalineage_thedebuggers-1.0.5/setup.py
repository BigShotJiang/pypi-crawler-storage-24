from setuptools import setup, find_packages

with open("README.md", "r", encoding="utf-8") as f:
    long_description = f.read()

setup(
    name="datalineage-thedebuggers",
    version="1.0.5",
    author="The Debuggers",
    author_email="",
    description="Git-like versioning system for ML datasets — immutable, reproducible, auditable.",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/Rakshita2305/DataLineage",
    packages=find_packages(),
    install_requires=[
        "pandas>=1.5.0",
        "numpy>=1.23.0",
    ],
    entry_points={
        "console_scripts": [
            "datalineage=DataLineage.app:main",
        ],
    },
    classifiers=[
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
        "Topic :: Scientific/Engineering :: Artificial Intelligence",
        "Topic :: Software Development :: Version Control",
    ],
    python_requires=">=3.8",
)