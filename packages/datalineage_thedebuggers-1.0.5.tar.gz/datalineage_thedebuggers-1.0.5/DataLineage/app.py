
import sys
import os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

import re
import json
import numpy as np
from pathlib import Path
from typing import Dict, Optional
from collections import Counter, defaultdict
from datetime import datetime
from src.integrity import verify_version_integrity
from src.repo import RepoState
from src.commit_service import (
    create_version_from_head,
    create_version_from_raw_default,
    create_version_from_raw_no_preprocessing,
)
from src.diff_service import compare_versions
from src.errors import DataLineageError
from src.io_loader import load_dataset

# --- Robust version ID validation ---
def is_valid_version_id(version_id: str) -> bool:
    return bool(re.fullmatch(r"[a-fA-F0-9]{64}", str(version_id)))

# --- Auto-evaluate version helper ---
def evaluate_version_auto(repo, version_id, verbose=True):
    from src.eval_pipeline import evaluate_and_train_bow
    try:
        metrics = evaluate_and_train_bow(repo, version_id, allow_user_input=False, verbose=verbose, save_report=True)
        if verbose and metrics:
            print(f"[AUTO-EVAL] F1: {metrics.get('f1')}, Accuracy: {metrics.get('accuracy')}")
        return metrics
    except Exception as e:
        if verbose:
            print(f"[AUTO-EVAL] Evaluation failed: {e}")
        return None

def _print_header() -> None:
    pass  # Removed old header as requested

def _print_menu() -> None:
    menu = [
        "1. Initialize new project structure",
        "2. Commit new version from HEAD + config",
        "3. Commit new version from raw dataset + config",
        "4. List all committed versions",
        "5. Checkout a specific version",
        "6. View logs for a specific version",
        "7. Compare two versions (diff)",
        "8. Verify version integrity",
        "9. Train Bag-of-Words classifier",
        "10. Evaluate a version (manual)",
        "11. Show metric trend (F1, accuracy)",
        "12. Recommend best version (by F1)",
        "13. Create branch",
        "14. Switch branch",
        "15. List branches",
        "16. Exit"
        # Option 17 is hidden, not in menu
    ]
    for line in menu:
        print(line)

# --- True lossless compress/uncompress at module level ---
def compress_old_versions(repo, keep_n=3):
    import zipfile
    logs = [rec for rec in repo.read_logs() if rec.get("event_type", "commit") == "commit" and rec.get("version_id")]
    records_by_id = {str(rec.get("version_id")): rec for rec in logs}
    parent_by_id = {}
    for version_id, rec in records_by_id.items():
        parent = rec.get("parent_id")
        parent_by_id[version_id] = str(parent) if parent not in {None, "None", "null", ""} else None
    # For each branch, keep latest N uncompressed
    branches = repo.list_branches()
    for branch in branches:
        tip_version = repo.get_branch_head(branch)
        # Build chain from tip to root
        chain = []
        curr = tip_version
        seen = set()
        while curr and curr not in seen:
            seen.add(curr)
            chain.append(curr)
            curr = parent_by_id.get(curr)
        chain = list(reversed(chain))
        # Keep latest N uncompressed, compress older
        for i, version_id in enumerate(chain):
            vdir = repo.versions_root / version_id
            csv_path = vdir / 'processed.csv'
            zip_path = vdir / 'processed.csv.zip'
            if i < len(chain) - keep_n:
                # Compress if not already compressed
                if csv_path.exists() and not zip_path.exists():
                    with zipfile.ZipFile(zip_path, 'w', zipfile.ZIP_DEFLATED) as zf:
                        zf.write(csv_path, arcname='processed.csv')
                    csv_path.unlink()
                elif zip_path.exists() and csv_path.exists():
                    csv_path.unlink()
            else:
                # Uncompress if needed
                if not csv_path.exists() and zip_path.exists():
                    with zipfile.ZipFile(zip_path, 'r') as zf:
                        zf.extract('processed.csv', vdir)
def _show_metric_trend_flow(repo):
    print("Show Metric Trend (F1 progression across version history)")
    head = repo.get_head()
    if not head:
        print("No HEAD version found.")
        return
    chain_ids = repo.get_version_chain(head)
    chain = []
    for vid in chain_ids:
        try:
            metadata = repo.get_version_metadata(vid)
        except Exception:
            metadata = {}
        eval_metrics = metadata.get("eval_metrics")
        f1 = eval_metrics["f1"] if eval_metrics and "f1" in eval_metrics else None
        comment = metadata.get("commit_message", "")
        if not comment and "text_columns" in metadata:
            comment = f"Text columns: {metadata['text_columns']}"
        chain.append({
            "version_id": vid,
            "f1": f1,
            "comment": comment,
        })
    if not chain:
        print("No version chain found.")
        return
    print("\n=== F1 Progression ===")
    prev_f1 = None
    for i, v in enumerate(chain):
        label = f"v{i+1}"
        f1 = v["f1"]
        comment = v["comment"]
        if f1 is None:
            print(f"{label}: F1=N/A | {comment}")
        else:
            delta = f"" if prev_f1 is None else f" ({(f1-prev_f1)*100:+.1f}% change)"
            bar = "|" + "#"*int(f1*20) + " "*(20-int(f1*20)) + f"| {f1:.2f}"
            print(f"{label}: {bar}{delta} | {comment}")
            prev_f1 = f1
def _recommend_best_version_flow(repo):
    print('.' * 70)
    print("RECOMMEND BEST VERSION".center(70))
    print('.' * 70)
    print("(rank by F1 score)".center(70))
    print('.' * 70)
    logs = [rec for rec in repo.read_logs() if rec.get("event_type", "commit") == "commit" and rec.get("version_id")]
    total_versions = len(logs)
    results = []
    unevaluated = 0
    for record in logs:
        version_id = record.get("version_id")
        comment = record.get("commit_message", "")
        try:
            metadata = repo.get_version_metadata(version_id)
            eval_metrics = metadata.get("eval_metrics")
        except Exception:
            eval_metrics = None
        if not eval_metrics or "f1" not in eval_metrics:
            unevaluated += 1
            continue
        results.append({
            "version_id": version_id,
            "f1": eval_metrics["f1"],
            "accuracy": eval_metrics.get("accuracy", 0.0),
            "comment": comment,
        })
    if not results:
        print(f"Found {total_versions} versions, 0 evaluated, {total_versions} not yet evaluated. Run Option 10 to evaluate remaining versions.")
        return
    # Sort by F1 descending
    results.sort(key=lambda x: x["f1"], reverse=True)
    print('.' * 70)
    print("BEST VERSION RANKING (by F1)".center(70))
    print('.' * 70)
    for i, r in enumerate(results, 1):
        print(f" #{i:<2} {r['version_id'][:8]} | F1: {r['f1']:.3f} | Accuracy: {r['accuracy']:.3f} | {r['comment']:<28.28s}")
    print("═" * 70)
    # Show best version summary
    best = results[0]
    print('.' * 70)
    print("BEST VERSION SUMMARY".center(70))
    print('.' * 70)
    print(f"Version: {best['version_id'][:8]:<8s} | F1: {best['f1']:.3f} | {best['comment']:<38.38s}")
    print('.' * 70)
    # Show actionable next step for unevaluated
    if unevaluated > 0:
        print(f"\nFound {total_versions} versions, {len(results)} evaluated, {unevaluated} not yet evaluated. Run Option 10 to evaluate remaining versions.")
    print("═" * 72)
from src.eval_pipeline import evaluate_and_train_bow

def _evaluate_version_flow(repo):
    print("\nEvaluate Version (retroactive BoW evaluation)")
    version_id = input("Enter version ID to evaluate: ").strip()
    if not version_id:
        print("No version ID provided.")
        return
    # Check if already evaluated
    try:
        metadata = repo.get_version_metadata(version_id)
    except Exception:
        metadata = {}
    eval_metrics = metadata.get("eval_metrics")
    if eval_metrics and all(k in eval_metrics for k in ("accuracy", "precision", "recall", "f1")):
        print('.' * 70)
        print("CLASSIFIER RESULTS (from logs/meta)")
        print(f"Accuracy  : {eval_metrics.get('accuracy', float('nan')):7.3f}")
        print(f"Precision : {eval_metrics.get('precision', float('nan')):7.3f}")
        print(f"Recall    : {eval_metrics.get('recall', float('nan')):7.3f}")
        print(f"F1        : {eval_metrics.get('f1', float('nan')):7.3f}")
        print(f"AUC-ROC   : {eval_metrics.get('auc_roc', float('nan')):7.3f}")
        print(f"MCC       : {eval_metrics.get('mcc', float('nan')):7.3f}")
        print(f"FPR       : {eval_metrics.get('fpr', float('nan')):7.3f}")
        print(f"FNR       : {eval_metrics.get('fnr', float('nan')):7.3f}")
        print()
        cm = eval_metrics.get('confusion_matrix')
        labels = eval_metrics.get('labels', ['0', '1'])
        if cm is not None:
            print("=== Confusion Matrix ===")
            print(f"{'':>16}Pred {labels[0]:<7}Pred {labels[1]:<7}")
            print(f"Actual {labels[0]:<6}  [   {cm[0][0]:<5} |   {cm[0][1]:<5} ]")
            print(f"Actual {labels[1]:<6}  [   {cm[1][0]:<5} |   {cm[1][1]:<5} ]")
            print()
        print('.' * 70)
        print("[INFO] Evaluation metrics already computed for this version. Not re-evaluating.")
        return
    # If not, run evaluation
    print("[INFO] No evaluation found for this version. Running evaluation...")
    metrics = evaluate_and_train_bow(repo, version_id, allow_user_input=True, verbose=True, save_report=True)
    if metrics:
        print('.' * 70)
        print("CLASSIFIER RESULTS (newly computed)")
        print(f"Accuracy  : {metrics.get('accuracy', float('nan')):7.3f}")
        print(f"Precision : {metrics.get('precision', float('nan')):7.3f}")
        print(f"Recall    : {metrics.get('recall', float('nan')):7.3f}")
        print(f"F1        : {metrics.get('f1', float('nan')):7.3f}")
        print(f"AUC-ROC   : {metrics.get('auc_roc', float('nan')):7.3f}")
        print(f"MCC       : {metrics.get('mcc', float('nan')):7.3f}")
        print(f"FPR       : {metrics.get('fpr', float('nan')):7.3f}")
        print(f"FNR       : {metrics.get('fnr', float('nan')):7.3f}")
        print()
        cm = metrics.get('confusion_matrix')
        labels = metrics.get('labels', ['0', '1'])
        if cm is not None:
            print("=== Confusion Matrix ===")
            print(f"{'':>16}Pred {labels[0]:<7}Pred {labels[1]:<7}")
            print(f"Actual {labels[0]:<6}  [   {cm[0][0]:<5} |   {cm[0][1]:<5} ]")
            print(f"Actual {labels[1]:<6}  [   {cm[1][0]:<5} |   {cm[1][1]:<5} ]")
            print()
        print('.' * 70)
    else:
        print('.' * 70)
        print("Evaluation failed or no metrics returned.")
        print('.' * 70)
def _wait_for_main_menu(repo, version_id) -> None:
    input("\nPress Enter to return to Main Menu...")

def _print_output_header(command_name: str) -> None:
    print('.' * 70)
    print(f"OUTPUT - {command_name.upper()}")
    print('.' * 70)

def _print_output_footer() -> None:
    print('.' * 70)

def _show_init_status(repo: RepoState) -> Dict[str, str]:
    head = repo.get_head()
    current_branch = repo.get_current_branch()
    detached_head = repo.get_detached_head()
    log_count = len(repo.read_logs())
    head_str = str(head) if isinstance(head, str) else (str(head) if head is not None else '-')
    section = (
        "REPOSITORY STATUS\n"
        f"Project root:      {str(repo.project_root)}\n"
        f"Internal repo:     {str(repo.repo_root)}\n"
        f"Versions path:     {str(repo.versions_root)}\n"
        f"Current branch:    {str(current_branch)}\n"
        + (f"Detached HEAD:     {str(detached_head)[:8]}\n" if detached_head else "")
        + f"Current HEAD:      {head_str[:8] if head_str else '-'}\n"
        + f"Total log entries: {str(log_count)}"
    )
    print('.' * 70)
    print(section)
    print('.' * 70)
    return {
        "Command": "init/status",
        "Project Root": str(repo.project_root),
        "Current Branch": str(current_branch),
        "Detached HEAD": str(detached_head),
        "Current HEAD": str(head),
        "Log Entries": str(log_count),
    }


def _ensure_not_detached_for_commit(repo: RepoState) -> None:
    detached_head = repo.get_detached_head()
    if detached_head:
        raise DataLineageError(
            "You are in detached mode. Switch to a branch (Option 14) or create a branch from this version (Option 13) before committing."
        )

def _train_bow_classifier_flow(repo):
    print('.' * 70)
    print("TRAIN BAG-OF-WORDS CLASSIFIER (NumPy-only)")
    print('.' * 70)
    version_id = input("Enter version ID to train on: ").strip()
    if not version_id:
        print("No version ID provided.")
        return
    metrics = evaluate_and_train_bow(repo, version_id, allow_user_input=True, verbose=True, save_report=True)
    if metrics:
        results = (
            "CLASSIFIER RESULTS\n"
            f"Accuracy : {metrics['accuracy']:>7.3f}  Precision : {metrics['precision']:>7.3f}\n"
            f"Recall   : {metrics['recall']:>7.3f}  F1        : {metrics['f1']:>7.3f}"
        )
        print('.' * 70)
        print(results)
        print('.' * 70)

    # ...existing code for commit, diff, integrity, etc...




def _commit_from_head_flow(repo: RepoState) -> Dict[str, str]:
    print('.' * 70)
    print("COMMIT FROM CURRENT HEAD + CONFIG".center(70))
    print('.' * 70)
    _ensure_not_detached_for_commit(repo)
    current_head = repo.get_head()
    print(f"Current HEAD: {str(current_head)[:8] if current_head else '-'}")
    if not current_head:
        raise DataLineageError(
            "HEAD is not set. First create a version using raw dataset input."
        )

    current_record = _find_version_record(repo, current_head)
    # If you want to print a summary, define 'section' or use current_record fields as needed.
    # Example (uncomment and adjust as needed):
    # print_boxed_section(f"Current HEAD Version: {current_record.get('version_id', '-')[:8]}")

    config_path = input("Config file path (.json): ").strip()
    commit_message = input("Commit message: ").strip()

    if not config_path:
        raise DataLineageError("Config path is required for HEAD commit mode.")
    if not commit_message:
        raise DataLineageError("Commit message is required.")

    print("Processing commit...")
    result = create_version_from_head(
        repo=repo,
        config_path=config_path,
        commit_message=commit_message,
    )

    if result["status"] == "duplicate":
        print("NO NEW VERSION CREATED")
        print(f"Reason: {result['message']}")
        print(f"Existing version: {str(result['version_id'])[:8]}")
        return {
            "Command": "commit-head",
            "Status": "duplicate",
            "Mode": "head-config",
            "Dataset Path": "HEAD",
            "Config Path": config_path,
            "Resolved Version": result["version_id"],
            "HEAD": str(result["head"]),
        }

    print("VERSION CREATED SUCCESSFULLY")
    print(f"Version ID: {str(result['version_id'])[:8]}")
    print(f"Parent ID:  {str(result['parent_id'])[:8] if result['parent_id'] else '-'}")
    rb = result['rows_before']
    ra = result['rows_after']
    print(f"Rows before -> after: {rb:,} -> {ra:,}")
    print(f"Saved at:   {str(result['version_path'])}")

    # Auto-evaluate new version
    evaluate_version_auto(repo, result["version_id"], verbose=True)
    _wait_for_main_menu(repo, result["version_id"])
    return {
        "Command": "commit-head",
        "Status": "created",
        "Mode": "head-config",
        "Dataset Path": "HEAD",
        "Config Path": config_path,
        "Version ID": result["version_id"],
        "Parent ID": str(result["parent_id"]),
        "HEAD": str(result["head"]),
    }


def _commit_from_raw_flow(repo: RepoState) -> Dict[str, str]:
    print("COMMIT FROM RAW DATASET")
    _ensure_not_detached_for_commit(repo)
    dataset_path = input("Raw dataset file path (CSV/JSON): ").strip()
    commit_message = input("Commit message: ").strip()
    
    apply_preprocessing = input("\nApply default preprocessing? (yes/no) [yes]: ").strip().lower()
    if not apply_preprocessing:
        apply_preprocessing = "yes"

    if not dataset_path:
        raise DataLineageError("Dataset path is required for raw commit mode.")
    if not commit_message:
        raise DataLineageError("Commit message is required.")


    if apply_preprocessing in ["yes", "y"]:
        print("Applying default preprocessing (smart_fill, text cleanup, deduplication...)")
        print("Processing commit...")
        result = create_version_from_raw_default(
            repo=repo,
            dataset_path=dataset_path,
            commit_message=commit_message,
        )
        config_mode = "DEFAULT_CONFIG"

        if result["status"] == "duplicate":
            print("NO NEW VERSION CREATED")
            print(f"Reason: {result['message']}")
            print(f"Existing version: {str(result['version_id'])[:8]}")
            return {
                "Command": "commit-raw",
                "Status": "duplicate",
                "Mode": "raw-" + config_mode,
                "Dataset Path": dataset_path,
                "Config Path": config_mode,
                "Resolved Version": result["version_id"],
                "HEAD": str(result["head"]),
            }

        print("VERSION CREATED SUCCESSFULLY")
        print(f"Version ID: {str(result['version_id'])[:8]}")
        print(f"Parent ID:  {str(result['parent_id'])[:8] if result['parent_id'] else '-'}")
        rb = result['rows_before']
        ra = result['rows_after']
        print(f"Rows before: {rb:,}")
        print(f"Rows after:  {ra:,}")
        print(f"HEAD updated to: {str(result['head'])[:8]}")

        # Auto-evaluate new version
        evaluate_version_auto(repo, result["version_id"], verbose=True)
        _wait_for_main_menu(repo, result["version_id"])
        return {
            "Command": "commit-raw",
            "Status": "created",
            "Mode": "raw-" + config_mode,
            "Dataset Path": dataset_path,
            "Config Path": config_mode,
            "Version ID": result["version_id"],
            "Parent ID": str(result["parent_id"]),
            "HEAD": result["head"],
            "Rows Before": str(result["rows_before"]),
            "Rows After": str(result["rows_after"]),
        }
    else:
        # Prompt for custom config
        print("\nSkipping default preprocessing. Would you like to provide a custom config for processing?")
        config_path = input("Enter custom config file path (.json), or leave blank to skip: ").strip()
        if config_path:
            print("\nApplying custom config for processing...")
            print("Processing commit...")
            from src.commit_service import create_version_from_paths
            result = create_version_from_paths(
                repo=repo,
                dataset_path=dataset_path,
                config_path=config_path,
                commit_message=commit_message,
            )
            config_mode = config_path

            if result["status"] == "duplicate":
                print("NO NEW VERSION CREATED")
                print(f"Reason: {result['message']}")
                print(f"Existing version: {str(result['version_id'])[:8]}")
                return {
                    "Command": "commit-raw",
                    "Status": "duplicate",
                    "Mode": "raw-" + config_mode,
                    "Dataset Path": dataset_path,
                    "Config Path": config_mode,
                    "Resolved Version": result["version_id"],
                    "HEAD": str(result["head"]),
                }

            print("VERSION CREATED SUCCESSFULLY")
            print(f"Version ID: {str(result['version_id'])[:8]}")
            print(f"Parent ID:  {str(result['parent_id'])[:8] if result['parent_id'] else '-'}")
            rb = result['rows_before']
            ra = result['rows_after']
            print(f"Rows before: {rb:,}")
            print(f"Rows after:  {ra:,}")
            print(f"HEAD updated to: {str(result['head'])[:8]}")

            # Auto-evaluate new version
            evaluate_version_auto(repo, result["version_id"], verbose=True)
            return {
                "Command": "commit-raw",
                "Status": "created",
                "Mode": "raw-" + config_mode,
                "Dataset Path": dataset_path,
                "Config Path": config_mode,
                "Version ID": result["version_id"],
                "Parent ID": str(result["parent_id"]),
                "HEAD": result["head"],
                "Rows Before": str(result["rows_before"]),
                "Rows After": str(result["rows_after"]),
            }
        else:
            print("\nNo preprocessing or config provided. No version will be created. Raw dataset will be available for future use.")
            return {
                "Command": "commit-raw",
                "Status": "aborted-no-preprocessing",
                "Mode": "raw-abort",
                "Dataset Path": dataset_path,
                "Message": "No version created. No preprocessing or config was provided.",
            }


def _list_versions(repo: RepoState) -> Dict[str, str]:
    # --- Minimal branch-wise lineage summary (EXACT style as user's screenshot) ---
    print("Branch-wise lineage:")
    for branch in repo.list_branches():
        tip = repo.get_branch_head(branch)
        # Build chain from root to tip
        chain = []
        seen = set()
        curr = tip
        while curr and curr not in seen:
            seen.add(curr)
            chain.append(curr)
            try:
                meta = repo.get_version_metadata(curr)
                curr = meta.get("parent_id")
            except Exception:
                break
        chain = list(reversed(chain))
        # Show only short IDs
        chain_str = " -> ".join([str(v)[:8] for v in chain])
        if branch == repo.get_current_branch():
            print(f"- {branch}: {chain_str} <- current")
        else:
            print(f"- {branch}: {chain_str}")
    logs = [
        record
        for record in repo.read_logs()
        if record.get("event_type", "commit") == "commit" and record.get("version_id")
    ]
    head = repo.get_head()
    current_branch = repo.get_current_branch()
    detached_head = repo.get_detached_head()

    print(f"\nCurrent branch: {current_branch}")
    if detached_head:
        print(f"Detached HEAD: {detached_head}")
    print(f"Current HEAD: {head}")

    if not logs:
        print("\nNo committed versions yet.")
        return {
            "Command": "list-versions",
            "Total Versions": "0",
        }

    # --- Linear linked-list style view ---
    # Dynamically determine box width for ALL VERSIONS (LINKED LIST)
    linked_lines = []
    prev_arrow = "  "
    for idx, record in enumerate(logs, start=1):
        version_id = str(record.get("version_id"))
        message = str(record.get("commit_message", ""))
        markers = []
        if head == version_id:
            markers.append("HEAD")
        if current_branch and repo.get_branch_head(current_branch) == version_id:
            markers.append("tip")
        if detached_head and detached_head == version_id:
            markers.append("detached")
        marker_str = (" [" + ", ".join(markers) + "]") if markers else ""
        arrow = "→" if idx < len(logs) else "  "
        line = f"║{prev_arrow}{version_id[:8]}{marker_str:<18s} {arrow} {message:<44.44s}║"
        linked_lines.append(line)
        prev_arrow = "  " if arrow == "  " else "  |"
    max_linked_width = max((len(l) for l in linked_lines), default=70)
    title_linked = " ALL VERSIONS (LINKED LIST) "
    box_linked_width = max(max_linked_width, len(title_linked) + 4)
    # Color heading if supported (ANSI bright cyan)
    heading_color = '\033[96m'  # bright cyan
    reset_color = '\033[0m'
    # Minimal box: only horizontal lines above and below the title, no vertical sides
    print("\n" + '.' * box_linked_width)
    print(heading_color + title_linked + reset_color)
    print('.' * box_linked_width)
    for l in linked_lines:
        print(l[1:-1].rstrip())
    print('.' * box_linked_width)

    # --- Branch-wise tree view ---
    # Dynamically determine box width for BRANCH-WISE LINEAGE
    branches = repo.list_branches()
    if "main" in branches:
        ordered_branches = ["main"] + [b for b in branches if b != "main"]
    else:
        ordered_branches = sorted(branches)
    branch_tips = {branch: repo.get_branch_head(branch) for branch in ordered_branches}
    def build_chain(tip):
        chain = []
        seen = set()
        curr = tip
        while curr and curr not in seen:
            seen.add(curr)
            chain.append(curr)
            try:
                meta = repo.get_version_metadata(curr)
                curr = meta.get("parent_id")
            except Exception:
                break
        return list(reversed(chain))

    branchwise_lines = []
    for branch in ordered_branches:
        tip = branch_tips.get(branch)
        chain = build_chain(tip) if tip else []
        is_current = (current_branch == branch)
        branch_arrow = "→" if is_current else " "
        branch_label = f"{branch}{' (current)' if is_current else ''}"
        # Print branch header
        branchwise_lines.append(f"║{branch_arrow} BRANCH: {branch_label}")
        for idx, version_id in enumerate(chain, start=1):
            try:
                metadata = repo.get_version_metadata(version_id)
            except Exception:
                metadata = {}
            parent_id = metadata.get("parent_id") or "None"
            rows = metadata.get("row_count", "-")
            if isinstance(rows, int):
                rows = f"{rows:,}"
            message = str(metadata.get("commit_message", ""))
            markers = []
            if head == version_id:
                markers.append("HEAD")
            if branch_tips.get(branch) == version_id:
                markers.append("tip")
            if detached_head and detached_head == version_id:
                markers.append("detached")
            marker_str = f" [{', '.join(markers)}]" if markers else ""
            # Tree lines: show '│' for all but last version in branch
            is_last = (idx == len(chain))
            tree_line = "│" if not is_last else " "
            v_arrow = "→" if (head == version_id or (branch_tips.get(branch) == version_id and is_current)) else " "
            branchwise_lines.append(f"║ {tree_line} {v_arrow} {idx}. version={version_id[:8]} | parent={parent_id[:8] if parent_id != 'None' else 'None'} | rows={rows}{marker_str}")
            branchwise_lines.append(f"║ {tree_line}    message: {message}")
        # After each branch, print a vertical space for separation
        branchwise_lines.append(f"║")
    max_branchwise_width = max((len(l) for l in branchwise_lines), default=70)
    title_branchwise = " BRANCH-WISE LINEAGE "
    box_branchwise_width = max(max_branchwise_width, len(title_branchwise) + 4)
    print("\n" + '.' * box_branchwise_width)
    print(heading_color + title_branchwise + reset_color)
    print('.' * box_branchwise_width)
    for l in branchwise_lines:
        print(l[1:-1].rstrip())
    print('.' * box_branchwise_width)
    # Remove any extra horizontal lines after this section

    records_by_id = {str(record.get("version_id")): record for record in logs}
    parent_by_id = {}
    for version_id, record in records_by_id.items():
        parent = record.get("parent_id")
        parent_by_id[version_id] = str(parent) if parent not in {None, "None", "null", ""} else None

    def _build_chain_to_tip(tip_version: Optional[str]):
        head = repo.get_head()
        current_branch = repo.get_current_branch()
        detached_head = repo.get_detached_head()
        # (prints removed for DRYness)

        # Use graph index for version chains
        branches = repo.list_branches()
        if "main" in branches:
            ordered_branches = ["main"] + [b for b in branches if b != "main"]
        else:
            ordered_branches = sorted(branches)

        branch_tips = {branch: repo.get_branch_head(branch) for branch in ordered_branches}
        main_chain = repo.get_version_chain(branch_tips.get("main")) if "main" in branch_tips and branch_tips["main"] else []

        import os
        from pathlib import Path
        # Find latest 3 version IDs in main_chain (or all chains if needed)
        latest_n = 3
        if main_chain:
            latest_ids = set(main_chain[-latest_n:])
        else:
            all_ids = repo.get_all_versions()
            latest_ids = set(all_ids[-latest_n:])

        def _format_version_line(index: int, branch_name: str, version_id: str):
            try:
                metadata = repo.get_version_metadata(version_id)
            except Exception:
                all_ids = set(repo.get_all_versions())
                head = repo.get_head()
                current_branch = repo.get_current_branch()
                detached_head = repo.get_detached_head()

                print(f"\nCurrent branch: {current_branch}")
                if detached_head:
                    print(f"Detached HEAD: {detached_head}")
                print(f"Current HEAD: {head}")

                if not all_ids:
                    print("\nNo committed versions yet.")
                    return {
                        "Command": "list-versions",
                        "Total Versions": "0",
                    }

                logs = [
                    record
                    for record in repo.read_logs()
                    if record.get("event_type", "commit") == "commit" and record.get("version_id")
                ]
                records_by_id = {str(record.get("version_id")): record for record in logs}
                parent_by_id = {}
                for version_id, record in records_by_id.items():
                    parent = record.get("parent_id")
                    parent_by_id[version_id] = str(parent) if parent not in {None, "None", "null", ""} else None
            print(f"║    message: {message:<54.54s}║")

        print("╔" + "═" * 27 + " COMMITTED VERSIONS " + "═" * 28 + "╗")

        shown_ids = set()
        if main_chain:
            print("║ MAIN BRANCH:" + " " * 56 + "║")
            for idx, version_id in enumerate(main_chain, start=1):
                _format_version_line(idx, "main", version_id)
                shown_ids.add(version_id)
        elif "main" in branch_tips:
            print("║ MAIN BRANCH: (empty)" + " " * 48 + "║")

        non_main = [b for b in ordered_branches if b != "main"]
        for branch in non_main:
            tip = branch_tips.get(branch)
            full_chain = repo.get_version_chain(tip) if tip else []

            # Show branch from fork point onward (no old shared ancestors before fork point).
            start_idx = 0
            if main_chain and full_chain:
                i = 0
                max_i = min(len(main_chain), len(full_chain))
                while i < max_i and main_chain[i] == full_chain[i]:
                    i += 1
                start_idx = max(0, i - 1)

            visible_chain = full_chain[start_idx:]

            print(f"║ BRANCH: {branch:<62s}║")
            if not visible_chain:
                print("║   (empty)" + " " * 59 + "║")
                continue

            for idx, version_id in enumerate(visible_chain, start=1):
                _format_version_line(idx, branch, version_id)
                shown_ids.add(version_id)

        # Show any remaining versions not reachable from branch tips
        all_ids = set(repo.get_all_versions())
        remaining = [vid for vid in all_ids if vid not in shown_ids]
        if remaining:
            print("║ OTHER COMMITS (not reachable from current branch pointers):" + " " * 13 + "║")
            for idx, version_id in enumerate(remaining, start=1):
                try:
                    metadata = repo.get_version_metadata(version_id)
                except Exception:
                    metadata = {}
                parent_id = metadata.get("parent_id") or "None"
                rows = metadata.get("row_count", "-")
                if isinstance(rows, int):
                    rows = f"{rows:,}"
                message = str(metadata.get("commit_message", ""))
                print(f"║ {idx}. version={version_id[:8]} | parent={parent_id[:8] if parent_id != 'None' else 'None'} | rows={rows:<8s} [other]               ║")
                print(f"║    message: {message:<54.54s}║")

        print("╚" + "═" * 70 + "╝")
        return {
            "Command": "list-versions",
            "Total Versions": str(len(all_ids)),
        }
    print("╚" + "═" * 70 + "╝")

    return {
        "Command": "list-versions",
        "Total Versions": str(len(logs)),
        "Current Branch": str(current_branch),
        "Current HEAD": str(head),
    }


def _find_version_record(repo: RepoState, version_id: str) -> Optional[Dict]:
    for record in repo.read_logs():
        if record.get("event_type", "commit") != "commit":
            continue
        if str(record.get("version_id")) == version_id:
            return record
    return None


def _print_version_details(record: Dict) -> None:
    print('.' * 70)
    print("VERSION DETAILS".center(70))
    print('.' * 70)
    print(f"version_id:     {str(record.get('version_id'))[:8]:<54s}")
    print(f"parent_id:      {str(record.get('parent_id'))[:8] if record.get('parent_id') else '-':<54s}")
    print(f"timestamp:      {str(record.get('timestamp')):<54s}")
    print(f"commit_message: {str(record.get('commit_message')):<54s}")
    print(f"source_data:    {str(record.get('source_data_path')):<54s}")
    print(f"source_config:  {str(record.get('source_config_path')):<54s}")
    print(f"input_hash:     {str(record.get('input_hash'))[:8]:<54s}")
    print(f"config_hash:    {str(record.get('config_hash'))[:8]:<54s}")
    print(f"version_hash:   {str(record.get('version_hash'))[:8]:<54s}")
    rc = record.get('row_count')
    rc_disp = f"{rc:,}" if isinstance(rc, int) else str(rc)
    print(f"row_count:      {rc_disp:<54s}")
    print('.' * 70)


def _select_version_interactively(repo: RepoState) -> Optional[str]:
    logs = [
        record
        for record in repo.read_logs()
        if record.get("event_type", "commit") == "commit" and record.get("version_id")
    ]
    if not logs:
        raise DataLineageError("No versions available to checkout.")

    while True:
        current_head = repo.get_head()
        print("\nCurrent menu: Checkout Version")
        print(f"Current HEAD: {current_head}")
        print("Available versions:")
        for index, record in enumerate(logs, start=1):
            version_id = str(record.get("version_id"))
            message = str(record.get("commit_message", ""))
            marker = " <- HEAD" if current_head == version_id else ""
            print(f"{index}. {version_id}{marker}")
            print(f"   message: {message}")

        print("\nCheckout options:")
        print("  1) Direct select for checkout")
        print("  2) View specific version details first")
        print("  3) Exit from Current Menu")
        option = input("Choose option (1/2/3): ").strip()

        if option == "3":
            return None

        if option == "2":
            version_to_view = input("Enter version ID to view details: ").strip()
            if not version_to_view:
                print("Version ID is required.")
                continue
            record = _find_version_record(repo, version_to_view)
            if record is None:
                print(f"Version not found: {version_to_view}")
                continue
            _print_version_details(record)
            proceed = input("Checkout this version now? (y/n): ").strip().lower()
            if proceed == "y":
                return version_to_view
            if proceed == "n":
                continue
            print("Invalid selection. Returning to checkout options.")
            continue

        if option == "1":
            selection = input(
                "Enter version index or exact version ID for checkout: "
            ).strip()
            if not selection:
                print("Version selection is required.")
                continue

            if selection.isdigit():
                selected_index = int(selection)
                if selected_index < 1 or selected_index > len(logs):
                    print("Invalid version index.")
                    continue
                return str(logs[selected_index - 1].get("version_id"))

            if is_valid_version_id(selection):
                return selection
            print("Error: Version ID must be a 64-character hexadecimal string.")
            continue

        print("Invalid option. Please choose 1, 2, or 3.")


def _checkout_flow(repo: RepoState) -> Dict[str, str]:
    target_version = _select_version_interactively(repo)
    if target_version is None:
        print("\nCheckout cancelled. Exiting current menu.")
        return {
            "Command": "checkout",
            "Status": "cancelled",
        }

    if not is_valid_version_id(target_version):
        print("Error: Version ID must be a 64-character hexadecimal string.")
        return {
            "Command": "checkout",
            "Status": "invalid-id",
            "Version": target_version,
        }
    if not repo.version_exists(target_version):
        raise DataLineageError(f"Version not found: {target_version}")

    previous_head = repo.get_head()
    repo.checkout_detached(target_version)

    print('.' * 70)
    print("CHECKOUT SUCCESSFUL".center(70))
    print('.' * 70)
    print(f"Current branch: {str(repo.get_current_branch()):<54s}")
    print(f"Mode: detached HEAD{' ' * 44}")
    print(f"Previous HEAD: {str(previous_head)[:8] if previous_head else '-':<54s}")
    print(f"Current HEAD:  {str(target_version)[:8]:<54s}")
    print('.' * 70)
    return {
        "Command": "checkout",
        "Status": "success",
        "Branch": repo.get_current_branch(),
        "Mode": "detached",
        "Previous HEAD": str(previous_head),
        "Current HEAD": target_version,
    }


def _create_branch_flow(repo: RepoState) -> Dict[str, str]:
    print('.' * 70)
    print("CREATE BRANCH".center(70))
    print('.' * 70)
    print(f"Current branch: {str(repo.get_current_branch()):<54s}")
    print(f"Current HEAD:   {str(repo.get_head())[:8] if repo.get_head() else '-':<54s}")
    print('.' * 70)

    branch_name = input("New branch name: ").strip()
    from_version = input("Start from version ID (leave blank = current HEAD): ").strip()
    if not branch_name:
        raise DataLineageError("Branch name is required.")
    if from_version and not is_valid_version_id(from_version):
        raise DataLineageError("Version ID must be a 64-character hexadecimal string.")

    try:
        created = repo.create_branch(branch_name, from_version or None)
    except ValueError as e:
        raise DataLineageError(str(e))

    branch_head = repo.get_branch_head(created)
    print('.' * 70)
    print("BRANCH CREATED SUCCESSFULLY".center(70))
    print('.' * 70)
    print(f"Branch: {str(created):<54s}")
    print(f"Tip version: {str(branch_head)[:8] if branch_head else '-':<54s}")
    print('.' * 70)
    return {
        "Command": "create-branch",
        "Status": "created",
        "Branch": created,
        "Head": str(branch_head),
    }


def _switch_branch_flow(repo: RepoState) -> Dict[str, str]:
    print('.' * 70)
    print("SWITCH BRANCH".center(70))
    print('.' * 70)
    current = repo.get_current_branch()
    branches = repo.list_branches()
    if not branches:
        raise DataLineageError("No branches found.")
    print(f"Current branch: {str(current):<54s}")
    print("Available branches:".ljust(54))
    for idx, name in enumerate(branches, start=1):
        marker = " <- current" if name == current else ""
        print(f"{idx}. {name}{marker:<60s}")
    selected = input("Enter branch name to switch: ").strip()
    if not selected:
        raise DataLineageError("Branch name is required.")
    try:
        new_head = repo.switch_branch(selected)
    except ValueError as e:
        raise DataLineageError(str(e))
    print('.' * 70)
    print("BRANCH SWITCHED SUCCESSFULLY".center(70))
    print('.' * 70)
    print(f"Current branch: {str(repo.get_current_branch()):<54s}")
    print(f"Mode: branch{' ' * 54}")
    print(f"HEAD: {str(new_head)[:8] if new_head else '-':<54s}")
    print('.' * 70)
    return {
        "Command": "switch-branch",
        "Status": "switched",
        "Branch": repo.get_current_branch(),
        "Head": str(new_head),
    }


def _list_branches_flow(repo: RepoState) -> Dict[str, str]:
    print("\nList Branches")
    current = repo.get_current_branch()
    branches = repo.list_branches()
    if not branches:
        print("No branches available.")
        return {
            "Command": "list-branches",
            "Total Branches": "0",
            "Current Branch": str(current),
        }

    print(f"Current branch: {current}")
    print("\nBranches:")
    for idx, name in enumerate(branches, start=1):
        tip = repo.get_branch_head(name)
        marker = " <- current" if name == current else ""
        print(f"{idx}. {name} | tip={tip}{marker}")

    return {
        "Command": "list-branches",
        "Total Branches": str(len(branches)),
        "Current Branch": str(current),
    }


def _view_specific_version_logs(repo: RepoState) -> Dict[str, str]:
    target_version = input("\nEnter version ID to view logs: ").strip()
    if not target_version:
        raise DataLineageError("Version ID is required.")
    if not is_valid_version_id(target_version):
        print("Error: Version ID must be a 64-character hexadecimal string.")
        return {
            "Command": "view-version-logs",
            "Status": "invalid-id",
            "Version ID": target_version,
        }

    record = _find_version_record(repo, target_version)
    if record is None:
        raise DataLineageError(f"Version not found in logs: {target_version}")

    _print_version_details(record)
    return {
        "Command": "view-version-logs",
        "Status": "shown",
        "Version ID": target_version,
    }



def _compare_versions_flow(repo: RepoState) -> Dict[str, str]:
    version_a = input("\nEnter base version ID (A): ").strip()
    version_b = input("Enter target version ID (B): ").strip()

    if not version_a or not version_b:
        raise DataLineageError("Both version IDs are required for compare.")
    if not is_valid_version_id(version_a) or not is_valid_version_id(version_b):
        print("Error: Both version IDs must be 64-character hexadecimal strings.")
        return {"Command": "compare-versions", "Status": "invalid-id"}

    result = compare_versions(repo=repo, version_a=version_a, version_b=version_b)
    rpt = result.get("_report", {})

    summary     = rpt.get("summary", {})
    col_info    = rpt.get("columns", {})
    cfg_diff    = rpt.get("config_diff", {})
    preproc     = rpt.get("preprocessing", {})
    row_lvl     = rpt.get("row_level", {})
    semantic    = rpt.get("semantic", {})
    lbl_diff    = rpt.get("label_distribution", {})
    eval_diff   = rpt.get("eval_metrics", {})

    SEP = "=" * 60

    # ── 1. Header ──────────────────────────────────────────────
    print(f"\n{SEP}")
    print(f"  VERSION COMPARISON REPORT")
    print(f"  A: {version_a[:16]}...  vs  B: {version_b[:16]}...")
    print(SEP)

    # ── 2. Quick verdict ───────────────────────────────────────
    print("\n[1] QUICK VERDICT")
    same_input  = summary.get("input_same", False)
    cfg_changed = summary.get("config_changed", False)
    if same_input and cfg_changed:
        print("  Same raw data, different preprocessing config.")
        print("  All differences below are caused by config changes.")
    elif not same_input and not cfg_changed:
        print("  Different raw data, same config.")
        print("  All differences below are caused by data changes.")
    elif not same_input and cfg_changed:
        print("  Both raw data AND config are different.")
    else:
        print("  Same raw data and same config — versions should be identical.")

    # ── 3. Config changes ──────────────────────────────────────
    print("\n[2] CONFIG CHANGES")
    changed_keys = cfg_diff.get("changed", {})
    only_a_keys  = cfg_diff.get("only_in_a", {})
    only_b_keys  = cfg_diff.get("only_in_b", {})
    if not changed_keys and not only_a_keys and not only_b_keys:
        print("  No config changes detected.")
    else:
        for key, info in changed_keys.items():
            print(f"  [{info['impact']}] {key}: {info['a']}  -->  {info['b']}")
            print(f"         {info['explanation']}")
        for key, val in only_a_keys.items():
            print(f"  [ONLY-A] {key} = {val}  (removed in B)")
        for key, val in only_b_keys.items():
            print(f"  [ONLY-B] {key} = {val}  (new in B)")

    # ── 4. Preprocessing pipeline impact ───────────────────────
    print("\n[3] PREPROCESSING PIPELINE IMPACT")
    pa = preproc.get("version_a", {})
    pb = preproc.get("version_b", {})
    print(f"  Version A: {pa.get('rows_before', '?')} rows in "
          f"→ {pa.get('rows_after', '?')} rows out  ({pa.get('retention_pct', '?')}% retained)")
    print(f"  Version B: {pb.get('rows_before', '?')} rows in "
          f"→ {pb.get('rows_after', '?')} rows out  ({pb.get('retention_pct', '?')}% retained)")
    if pa.get("cols_dropped"):
        print(f"  A dropped columns: {pa['cols_dropped']}")
    if pb.get("cols_dropped"):
        print(f"  B dropped columns: {pb['cols_dropped']}")

    # ── 5. Row / column count ──────────────────────────────────
    print("\n[4] ROW & COLUMN COUNT")
    row_delta = summary.get("row_delta", 0)
    pct = (row_delta / max(1, summary.get("row_count_a", 1))) * 100
    sign = "+" if row_delta >= 0 else ""
    print(f"  Rows:    A={summary.get('row_count_a')}   B={summary.get('row_count_b')}   "
          f"Delta={sign}{row_delta}  ({sign}{pct:.1f}%)")
    print(f"  Columns: A={summary.get('column_count_a')}   B={summary.get('column_count_b')}")
    if col_info.get("only_in_a"):
        print(f"  Columns only in A: {col_info['only_in_a']}")
    if col_info.get("only_in_b"):
        print(f"  Columns only in B: {col_info['only_in_b']}")

    # ── 6. Row-level diff ──────────────────────────────────────
    print("\n[5] ROW-LEVEL DIFF  (index-aligned comparison)")
    print(f"  Changed rows : {row_lvl.get('changed_rows_total', 0)}")
    print(f"  Added rows   : {row_lvl.get('added_rows_total', 0)}")
    print(f"  Removed rows : {row_lvl.get('removed_rows_total', 0)}")

    samples = row_lvl.get("changed_rows_sample", [])
    if samples:
        print(f"\n  Sample of changed rows (showing up to 5):")
        for entry in samples[:5]:
            print(f"    Row {entry['row_index']}:")
            for col, chg in entry["diffs"].items():
                a_val = chg["a"][:60] if len(str(chg["a"])) > 60 else chg["a"]
                b_val = chg["b"][:60] if len(str(chg["b"])) > 60 else chg["b"]
                print(f"      {col}:  \"{a_val}\"  -->  \"{b_val}\"")

    # ── 7. Semantic diff ───────────────────────────────────────
    if semantic:
        print("\n[6] SEMANTIC DIFF  (per column)")
        for col, s in semantic.items():
            ctype = s.get("type", "other")
            print(f"\n  Column '{col}'  [{ctype}]")
            if ctype == "text":
                print(f"    Vocab size:    A={s.get('vocab_size_a', 0)}   B={s.get('vocab_size_b', 0)}")
                print(f"    Vocab overlap: {s.get('vocab_overlap_pct', 0)}%")
                lost  = s.get('words_lost_count', 0)
                gained= s.get('words_gained_count', 0)
                risk  = s.get('oov_risk', 'LOW')
                print(f"    Words lost: {lost}   Words gained: {gained}   OOV risk: {risk}")
                if s.get("words_lost_sample"):
                    print(f"    Lost words sample: {s['words_lost_sample'][:10]}")
                if s.get("words_gained_sample"):
                    print(f"    Gained words sample: {s['words_gained_sample'][:10]}")
                la = s.get("text_length_a", {})
                lb = s.get("text_length_b", {})
                print(f"    Avg text length: A={la.get('mean', 0):.1f}  B={lb.get('mean', 0):.1f}  "
                      f"Delta={s.get('mean_length_delta', 0):+.1f} chars")
                nd = s.get("null_delta", 0)
                if nd != 0:
                    print(f"    Null count change: {nd:+d}")
            elif ctype == "numeric":
                print(f"    Mean:  A={s.get('mean_a', 0):.4f}   B={s.get('mean_b', 0):.4f}   "
                      f"Shift={s.get('mean_shift', 0):+.4f}")
                print(f"    Std:   A={s.get('std_a', 0):.4f}   B={s.get('std_b', 0):.4f}   "
                      f"Shift={s.get('std_shift', 0):+.4f}")

    # ── 8. Label distribution ──────────────────────────────────
    print("\n[7] LABEL DISTRIBUTION")
    if not lbl_diff.get("changed", False):
        print("  No change in label distribution.")
    else:
        for lbl, info in lbl_diff.get("per_label", {}).items():
            delta = info["delta"]
            sign = "+" if delta >= 0 else ""
            print(f"  {lbl}: A={info['count_a']}  B={info['count_b']}  ({sign}{delta})")

    # ── 9. Eval metrics ────────────────────────────────────────
    print("\n[8] EVAL METRICS  (if evaluated)")
    f1_a  = eval_diff.get("f1_a")
    f1_b  = eval_diff.get("f1_b")
    acc_a = eval_diff.get("acc_a")
    acc_b = eval_diff.get("acc_b")
    if f1_a is None and f1_b is None:
        print("  Not evaluated yet. Run Option 10 to evaluate versions.")
    else:
        f1_d  = eval_diff.get("f1_delta")
        acc_d = eval_diff.get("acc_delta")
        fa_s  = f"{f1_a:.4f}"  if f1_a  is not None else "N/A"
        fb_s  = f"{f1_b:.4f}"  if f1_b  is not None else "N/A"
        aa_s  = f"{acc_a:.4f}" if acc_a is not None else "N/A"
        ab_s  = f"{acc_b:.4f}" if acc_b is not None else "N/A"
        fd_s  = (f"{f1_d:+.4f}"  if f1_d  is not None else "N/A")
        ad_s  = (f"{acc_d:+.4f}" if acc_d is not None else "N/A")
        print(f"  F1:       A={fa_s}   B={fb_s}   Delta={fd_s}")
        print(f"  Accuracy: A={aa_s}   B={ab_s}   Delta={ad_s}")

    print(f"\n{SEP}")
    print(f"  Full report saved: {result['report_path']}")
    print(SEP)

    return {
        "Command": "compare-versions",
        "Status": "done",
        "Version A": version_a,
        "Version B": version_b,
        "Report": result["report_path"],
    }


def _verify_version_integrity_flow(repo: RepoState) -> Dict[str, str]:
    version_id = input("\nEnter version ID to verify integrity: ").strip()
    if not is_valid_version_id(version_id):
        print("Error: Version ID must be a 64-character hexadecimal string.")
        return {"Command": "verify-integrity", "Status": "invalid-id", "Version": version_id}
    version_dir = repo.versions_root / version_id
    try:
        verify_version_integrity(version_dir)
        print(f"Integrity check PASSED for version {version_id}.")
        return {"Command": "verify-integrity", "Status": "passed", "Version": version_id}
    except Exception as e:
        print(f"Integrity check FAILED for version {version_id}: {e}")
        return {"Command": "verify-integrity", "Status": "failed", "Version": version_id, "Error": str(e)}


def main() -> None:
    default_root = Path(__file__).resolve().parent
    while True:
        _print_header()
        _print_menu()
        choice = input("\nEnter option number: ").strip()
        try:
            if choice == "1":
                user_root = Path(input("Enter project root (or leave blank for current directory): ").strip() or default_root)
                if not user_root.exists():
                    print("\nDirectory does not exist. Please check the path and try again.")
                    continue
                try:
                    repo = RepoState(project_root=user_root)
                    print("\nProject structure already exists at this location. Showing repository status:\n")
                    _show_init_status(repo)
                    # You must provide repo and version_id here. If not available, skip or prompt for them.
                    # Example: _wait_for_main_menu(repo, version_id)
                    continue
                except Exception:
                    pass
                print(f"\n{'-' * 72}\n")
                print("  - raw_data/")
                print("  - reports/")
                confirm = input("Proceed with creation? (y/n): ").strip().lower()
                if confirm == "y":
                    (user_root / ".mydata" / "versions").mkdir(parents=True, exist_ok=True)
                    (user_root / ".mydata" / "branches").mkdir(parents=True, exist_ok=True)
                    (user_root / "raw_data").mkdir(parents=True, exist_ok=True)
                    (user_root / "reports").mkdir(parents=True, exist_ok=True)
                    head_file = user_root / ".mydata" / "HEAD"
                    current_branch_file = user_root / ".mydata" / "CURRENT_BRANCH"
                    detached_head_file = user_root / ".mydata" / "DETACHED_HEAD"
                    main_branch_file = user_root / ".mydata" / "branches" / "main"
                    logs_file = user_root / ".mydata" / "logs.jsonl"
                    meta_file = user_root / ".mydata" / "repo_meta.json"
                    if not head_file.exists():
                        head_file.write_text("\n", encoding="utf-8")
                    if not current_branch_file.exists():
                        current_branch_file.write_text("main\n", encoding="utf-8")
                    if not detached_head_file.exists():
                        detached_head_file.write_text("\n", encoding="utf-8")
                    if not main_branch_file.exists():
                        main_branch_file.write_text(head_file.read_text(encoding="utf-8") or "\n", encoding="utf-8")
                    if not logs_file.exists():
                        logs_file.write_text("", encoding="utf-8")
                    if not meta_file.exists():
                        meta_file.write_text("{}\n", encoding="utf-8")
                    print("\nProject structure created successfully!")
                    repo = RepoState(project_root=user_root)
                else:
                    print("\nInitialization cancelled. No changes made.")
                    continue
                _show_init_status(repo)
                # You must provide repo and version_id here. If not available, skip or prompt for them.
                # Example: _wait_for_main_menu(repo, version_id)
                continue
            elif choice in {str(i) for i in range(2, 16)}:
                try:
                    repo = RepoState(project_root=default_root)
                except Exception as error:
                    print("\nRepository is not initialized. Please run option 1 to initialize the project structure first.\n")
                    # You must provide repo and version_id here. If not available, skip or prompt for them.
                    # Example: _wait_for_main_menu(repo, version_id)
                    continue
                if choice == "2":
                    _print_output_header("commit-from-head")
                    result = _commit_from_head_flow(repo)
                    _print_output_footer()
                    compress_old_versions(repo, keep_n=3)
                elif choice == "3":
                    _print_output_header("commit-from-raw")
                    result = _commit_from_raw_flow(repo)
                    _print_output_footer()
                    compress_old_versions(repo, keep_n=3)
                elif choice == "4":
                    _print_output_header("list-versions")
                    _list_versions(repo)
                    _print_output_footer()
                elif choice == "5":
                    _print_output_header("checkout-version")
                    _checkout_flow(repo)
                    _print_output_footer()
                elif choice == "6":
                    _print_output_header("view-version-logs")
                    _view_specific_version_logs(repo)
                    _print_output_footer()
                elif choice == "7":
                    _print_output_header("compare-versions")
                    _compare_versions_flow(repo)
                    _print_output_footer()
                elif choice == "8":
                    _print_output_header("verify-version-integrity")
                    _verify_version_integrity_flow(repo)
                    _print_output_footer()
                elif choice == "9":
                    _print_output_header("train-bow-classifier")
                    _train_bow_classifier_flow(repo)
                    _print_output_footer()
                elif choice == "10":
                    _print_output_header("evaluate-version")
                    _evaluate_version_flow(repo)
                    _print_output_footer()
                elif choice == "11":
                    _print_output_header("show-metric-trend")
                    _show_metric_trend_flow(repo)
                    _print_output_footer()
                elif choice == "12":
                    _print_output_header("recommend-best-version")
                    _recommend_best_version_flow(repo)
                    _print_output_footer()
                elif choice == "13":
                    _print_output_header("create-branch")
                    _create_branch_flow(repo)
                    _print_output_footer()
                elif choice == "14":
                    _print_output_header("switch-branch")
                    _switch_branch_flow(repo)
                    _print_output_footer()
                elif choice == "15":
                    _print_output_header("list-branches")
                    _list_branches_flow(repo)
                    _print_output_footer()
                continue
            elif choice == "16":
                print("\nExiting DataLineage Prototype. Goodbye.")
                break
            else:
                print("\nInvalid option. Please choose 1-16.")
                # You must provide repo and version_id here. If not available, skip or prompt for them.
                # Example: _wait_for_main_menu(repo, version_id)
                continue
        except DataLineageError as e:
            print(f"Error: {str(e)}")
            # You must provide repo and version_id here. If not available, skip or prompt for them.
            # Example: _wait_for_main_menu(repo, version_id)
        except Exception as e:
            print(f"Unexpected error: {str(e)}")
            # You must provide repo and version_id here. If not available, skip or prompt for them.
            # Example: _wait_for_main_menu(repo, version_id)


if __name__ == "__main__":
    main()
