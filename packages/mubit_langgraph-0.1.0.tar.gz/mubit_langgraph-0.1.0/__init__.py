"""
mubit-langgraph — LangGraph BaseStore backed by MuBit.

This adapter now routes MuBit calls through the canonical Python SDK transport
instead of duplicating raw HTTP request logic.
"""

from __future__ import annotations

import asyncio
import json
import uuid
from datetime import datetime, timezone
from typing import Any, Iterable, Optional

from .mubit_client import MubitControlClient, normalize_metadata

try:
    from langgraph.store.base import (
        BaseStore,
        GetOp,
        Item,
        ListNamespacesOp,
        Op,
        PutOp,
        Result,
        SearchItem,
        SearchOp,
    )
except ImportError as e:
    raise ImportError(
        "langgraph is required: pip install mubit-langgraph[langgraph]"
    ) from e


def _parse_namespace(ns: tuple[str, ...]) -> tuple[str, str]:
    parts = [p for p in ns if p and p != "*"]
    if len(parts) == 0:
        return ("", "default")
    if len(parts) == 1:
        return ("", "default")
    if len(parts) == 2:
        return (parts[1], "default")
    return (parts[1], "/".join(parts[2:]))


def _tuple_starts_with(ns: tuple[str, ...], prefix: tuple[str, ...]) -> bool:
    if len(prefix) > len(ns):
        return False
    return all(part == "*" or part == ns[idx] for idx, part in enumerate(prefix))


def _tuple_ends_with(ns: tuple[str, ...], suffix: tuple[str, ...]) -> bool:
    if len(suffix) > len(ns):
        return False
    offset = len(ns) - len(suffix)
    return all(
        part == "*" or part == ns[offset + idx] for idx, part in enumerate(suffix)
    )


def _metadata_from_value(value: dict[str, Any]) -> dict[str, Any]:
    metadata = value.get("metadata")
    if isinstance(metadata, dict):
        return metadata
    return {
        key: entry
        for key, entry in value.items()
        if key
        not in {
            "text",
            "intent",
            "source",
            "lesson_type",
            "lesson_scope",
            "lesson_importance",
            "lesson_conditions",
            "metadata",
        }
        and entry is not None
    }


def _compact(payload: dict[str, Any]) -> dict[str, Any]:
    return {key: value for key, value in payload.items() if value is not None}


def _to_item(namespace: tuple[str, ...], key: str, evidence: dict[str, Any]) -> Item:
    now = datetime.now(timezone.utc)
    return Item(
        value={
            "text": evidence.get("content", ""),
            "metadata": normalize_metadata(evidence),
        },
        key=key,
        namespace=namespace,
        created_at=now,
        updated_at=now,
    )


class MubitStore(BaseStore):
    supports_ttl = False

    def __init__(
        self,
        *,
        endpoint: str = "http://127.0.0.1:3000",
        api_key: str = "",
        mubit_client: Optional[Any] = None,
    ) -> None:
        self._namespaces: set[tuple[str, ...]] = set()
        self._client = mubit_client or MubitControlClient(
            endpoint=endpoint.rstrip("/"), api_key=api_key
        )

    def batch(self, ops: Iterable[Op]) -> list[Result]:
        results: list[Result] = []
        for op in ops:
            if isinstance(op, GetOp):
                results.append(self._handle_get(op))
            elif isinstance(op, SearchOp):
                results.append(self._handle_search(op))
            elif isinstance(op, PutOp):
                self._handle_put(op)
                results.append(None)
            elif isinstance(op, ListNamespacesOp):
                results.append(self._handle_list_namespaces(op))
            else:
                results.append(None)
        return results

    async def abatch(self, ops: Iterable[Op]) -> list[Result]:
        return await asyncio.to_thread(self.batch, list(ops))

    def _handle_get(self, op: GetOp) -> Optional[Item]:
        user_id, session_id = _parse_namespace(op.namespace)
        data = self._client.recall(
            session_id=session_id,
            user_id=user_id or None,
            query=op.key,
            limit=1,
        )
        evidence = data.get("evidence", [])
        if not evidence:
            return None
        return _to_item(op.namespace, op.key, evidence[0])

    def _handle_search(self, op: SearchOp) -> list[SearchItem]:
        ns = getattr(op, "namespace", None) or getattr(op, "namespace_prefix", ())
        user_id, session_id = _parse_namespace(ns)
        data = self._client.recall(
            session_id=session_id,
            user_id=user_id or None,
            query=op.query or "",
            limit=op.limit,
            entry_types=op.filter.get("entry_types") if op.filter else None,
        )
        now = datetime.now(timezone.utc)
        results: list[SearchItem] = []
        for ev in data.get("evidence", []):
            results.append(
                SearchItem(
                    value={
                        "text": ev.get("content", ""),
                        "metadata": normalize_metadata(ev),
                    },
                    key=ev.get("id", str(uuid.uuid4())),
                    namespace=ns,
                    created_at=now,
                    updated_at=now,
                    score=ev.get("score"),
                )
            )
        return results

    def _handle_put(self, op: PutOp) -> None:
        user_id, session_id = _parse_namespace(op.namespace)
        self._namespaces.add(op.namespace)
        text = op.value.get("text", json.dumps(op.value))
        self._client.remember(
            **_compact(
                {
                    "session_id": session_id,
                    "user_id": user_id or None,
                    "text": text,
                    "intent": op.value.get("intent"),
                    "source": op.value.get("source"),
                    "lesson_type": op.value.get("lesson_type"),
                    "lesson_scope": op.value.get("lesson_scope"),
                    "lesson_importance": op.value.get("lesson_importance"),
                    "lesson_conditions": op.value.get("lesson_conditions"),
                    "metadata": _metadata_from_value(op.value),
                    "upsert_key": op.key,
                }
            )
        )

    def _handle_list_namespaces(self, op: ListNamespacesOp) -> list[tuple[str, ...]]:
        results: list[tuple[str, ...]] = []
        for namespace in self._namespaces:
            match = True
            for condition in op.match_conditions or []:
                if condition.match_type == "prefix" and not _tuple_starts_with(
                    namespace, condition.path
                ):
                    match = False
                    break
                if condition.match_type == "suffix" and not _tuple_ends_with(
                    namespace, condition.path
                ):
                    match = False
                    break
            if not match:
                continue
            if op.max_depth is not None and len(namespace) > op.max_depth:
                namespace = namespace[: op.max_depth]
            results.append(namespace)

        deduped: list[tuple[str, ...]] = []
        seen: set[tuple[str, ...]] = set()
        for namespace in results:
            if namespace not in seen:
                seen.add(namespace)
                deduped.append(namespace)
        return deduped[op.offset : op.offset + op.limit]

    def checkpoint(
        self,
        namespace: tuple[str, ...],
        snapshot: str,
        *,
        label: str = "",
        metadata: Optional[dict[str, Any]] = None,
        agent_id: str = "langgraph",
    ) -> dict[str, Any]:
        user_id, session_id = _parse_namespace(namespace)
        return self._client.checkpoint(
            session_id=session_id,
            user_id=user_id or None,
            snapshot=snapshot,
            label=label,
            metadata=metadata,
            agent_id=agent_id,
        )

    async def acheckpoint(self, namespace: tuple[str, ...], snapshot: str, **kwargs):
        return await asyncio.to_thread(self.checkpoint, namespace, snapshot, **kwargs)

    def record_outcome(
        self,
        namespace: tuple[str, ...],
        reference_id: str,
        outcome: str,
        *,
        signal: Optional[float] = None,
        rationale: str = "",
        agent_id: str = "langgraph",
    ) -> dict[str, Any]:
        user_id, session_id = _parse_namespace(namespace)
        return self._client.record_outcome(
            session_id=session_id,
            user_id=user_id or None,
            reference_id=reference_id,
            outcome=outcome,
            signal=signal,
            rationale=rationale,
            agent_id=agent_id,
        )

    async def arecord_outcome(self, namespace: tuple[str, ...], reference_id: str, outcome: str, **kwargs):
        return await asyncio.to_thread(
            self.record_outcome, namespace, reference_id, outcome, **kwargs
        )

    def surface_strategies(
        self,
        namespace: tuple[str, ...],
        *,
        lesson_types: Optional[list[str]] = None,
        max_strategies: int = 5,
    ) -> dict[str, Any]:
        user_id, session_id = _parse_namespace(namespace)
        return self._client.surface_strategies(
            session_id=session_id,
            user_id=user_id or None,
            lesson_types=lesson_types,
            max_strategies=max_strategies,
        )

    async def asurface_strategies(self, namespace: tuple[str, ...], **kwargs):
        return await asyncio.to_thread(self.surface_strategies, namespace, **kwargs)

    def get_context(self, namespace: tuple[str, ...], **kwargs):
        user_id, session_id = _parse_namespace(namespace)
        return self._client.get_context(
            session_id=session_id,
            user_id=user_id or None,
            query=kwargs.get("query", ""),
            mode=kwargs.get("mode"),
            sections=kwargs.get("sections"),
            entry_types=kwargs.get("entry_types"),
            limit=kwargs.get("limit"),
            max_token_budget=kwargs.get("max_token_budget"),
            agent_id=kwargs.get("agent_id"),
        )

    def archive(self, namespace: tuple[str, ...], **kwargs):
        user_id, session_id = _parse_namespace(namespace)
        return self._client.archive(
            session_id=session_id,
            user_id=user_id or None,
            content=kwargs.get("content") or kwargs.get("text"),
            artifact_kind=kwargs.get("artifact_kind") or kwargs.get("artifactKind"),
            metadata=kwargs.get("metadata"),
            agent_id=kwargs.get("agent_id") or kwargs.get("agentId"),
            origin_agent_id=kwargs.get("origin_agent_id") or kwargs.get("originAgentId"),
            source_attempt_id=kwargs.get("source_attempt_id") or kwargs.get("sourceAttemptId"),
            source_tool=kwargs.get("source_tool") or kwargs.get("sourceTool"),
            labels=kwargs.get("labels"),
            family=kwargs.get("family"),
            importance=kwargs.get("importance"),
        )

    def dereference(self, namespace: tuple[str, ...], **kwargs):
        user_id, session_id = _parse_namespace(namespace)
        return self._client.dereference(
            session_id=session_id,
            user_id=user_id or None,
            reference_id=kwargs.get("reference_id") or kwargs.get("referenceId"),
            agent_id=kwargs.get("agent_id") or kwargs.get("agentId"),
        )

    def memory_health(self, namespace: tuple[str, ...], **kwargs):
        user_id, session_id = _parse_namespace(namespace)
        return self._client.memory_health(
            session_id=session_id,
            user_id=user_id or None,
            limit=kwargs.get("limit"),
        )

    def diagnose(self, namespace: tuple[str, ...], **kwargs):
        user_id, session_id = _parse_namespace(namespace)
        return self._client.diagnose(
            session_id=session_id,
            user_id=user_id or None,
            error_text=kwargs.get("error_text", ""),
            error_type=kwargs.get("error_type"),
            limit=kwargs.get("limit"),
        )

    def register_agent(self, namespace: tuple[str, ...], **kwargs):
        user_id, session_id = _parse_namespace(namespace)
        return self._client.register_agent(
            session_id=session_id,
            user_id=user_id or None,
            agent_id=kwargs["agent_id"],
            role=kwargs.get("role"),
            status=kwargs.get("status"),
            read_scopes=kwargs.get("read_scopes"),
            write_scopes=kwargs.get("write_scopes"),
            shared_memory_lanes=kwargs.get("shared_memory_lanes"),
            capabilities=kwargs.get("capabilities"),
        )

    def list_agents(self, namespace: tuple[str, ...]):
        user_id, session_id = _parse_namespace(namespace)
        return self._client.list_agents(
            session_id=session_id,
            user_id=user_id or None,
        )

    def handoff(self, namespace: tuple[str, ...], **kwargs):
        user_id, session_id = _parse_namespace(namespace)
        return self._client.handoff(
            session_id=session_id,
            user_id=user_id or None,
            from_agent_id=kwargs["from_agent_id"],
            to_agent_id=kwargs["to_agent_id"],
            content=kwargs["content"],
            requested_action=kwargs.get("requested_action"),
            metadata=kwargs.get("metadata"),
        )

    def feedback(self, namespace: tuple[str, ...], **kwargs):
        user_id, session_id = _parse_namespace(namespace)
        return self._client.feedback(
            session_id=session_id,
            user_id=user_id or None,
            handoff_id=kwargs["handoff_id"],
            verdict=kwargs["verdict"],
            comments=kwargs.get("comments"),
            from_agent_id=kwargs.get("from_agent_id"),
            metadata=kwargs.get("metadata"),
        )

    def close(self) -> None:
        return None
