from __future__ import annotations

import unittest

from integrations.python.mubit_langgraph.mubit_client import MubitControlClient


class FakeControl:
    def __init__(self) -> None:
        self.calls: list[dict] = []
        self.polls = 0

    def get_ingest_job(self, payload):
        self.calls.append(payload)
        self.polls += 1
        return {"done": self.polls >= 2}


class FakeTransport:
    def __init__(self) -> None:
        self.calls: list[tuple[dict, dict]] = []

    def invoke(self, op, payload):
        self.calls.append((op, payload))
        return {"accepted": True, "job_id": "job-1"}


class FakeSdkClient:
    def __init__(self) -> None:
        self._transport = FakeTransport()
        self.control = FakeControl()


class TestMubitControlClient(unittest.TestCase):
    def test_remember_waits_for_ingest_completion(self) -> None:
        sdk_client = FakeSdkClient()
        client = MubitControlClient(sdk_client=sdk_client)

        client.remember(session_id="session-1", text="release note")

        self.assertEqual(len(sdk_client.control.calls), 2)


if __name__ == "__main__":
    unittest.main()
