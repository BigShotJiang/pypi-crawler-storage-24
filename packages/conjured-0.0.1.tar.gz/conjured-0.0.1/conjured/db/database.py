"""Database connection pooling — sync and async.

Reads connection string from DATABASE_URL env var or
config/services/database.toml. Provides context managers
for pooled connections.

Usage:
    from conjured.services.database import db_connection, async_db_connection

    with db_connection() as conn:
        cur = conn.cursor()
        cur.execute("SELECT ...")

    async with async_db_connection() as conn:
        cur = conn.cursor()
        await cur.execute("SELECT ...")
"""

import os
import threading
import tomllib
from contextlib import asynccontextmanager, contextmanager

import psycopg
from psycopg.rows import tuple_row
from psycopg_pool import AsyncConnectionPool, ConnectionPool

from pathlib import Path

from conjured.core.paths import CONFIG_DIR

_SCHEMA_PATH = Path(__file__).parent / "schema.sql"


def _get_connection_string() -> str:
    """Resolve database connection string.

    Priority: DATABASE_URL env var > config/services/database.toml.
    """
    env_url = os.environ.get("DATABASE_URL")
    if env_url:
        return env_url
    path = CONFIG_DIR / "services" / "database.toml"
    with open(path, "rb") as f:
        data = tomllib.load(f)
    return data["connection_string"]


# ── Sync connection pool ──────────────────────────────────────────────────

_pool: ConnectionPool | None = None
_pool_lock = threading.Lock()


def _init_pool():
    """Initialize the sync connection pool (double-checked locking)."""
    global _pool
    if _pool is not None:
        return
    with _pool_lock:
        if _pool is not None:
            return
        _pool = ConnectionPool(
            conninfo=_get_connection_string(),
            min_size=2,
            max_size=20,
            open=True,
            kwargs={"row_factory": tuple_row, "autocommit": False},
        )


def get_connection():
    """Get a connection from the sync pool.

    Prefer db_connection() context manager instead.
    """
    _init_pool()
    return _pool.getconn()


def release_connection(conn):
    """Return a connection to the sync pool."""
    if _pool and conn:
        _pool.putconn(conn)


@contextmanager
def db_connection():
    """Sync context manager for pooled connections."""
    _init_pool()
    with _pool.connection() as conn:
        yield conn


# ── Async connection pool ────────────────────────────────────────────────

_async_pool: AsyncConnectionPool | None = None


async def init_async_pool():
    """Initialize the async connection pool. Call from FastAPI lifespan."""
    global _async_pool
    if _async_pool is not None:
        return
    _async_pool = AsyncConnectionPool(
        conninfo=_get_connection_string(),
        min_size=2,
        max_size=20,
        open=False,
        kwargs={"row_factory": tuple_row, "autocommit": False},
    )
    await _async_pool.open()
    await _async_pool.wait()


async def close_async_pool():
    """Close the async connection pool. Call from FastAPI shutdown."""
    global _async_pool
    if _async_pool is not None:
        await _async_pool.close()
        _async_pool = None


@asynccontextmanager
async def async_db_connection():
    """Async context manager for pooled connections."""
    if _async_pool is None:
        raise RuntimeError("Async pool not initialized. Call init_async_pool() first.")
    async with _async_pool.connection() as conn:
        yield conn


# ── Schema setup ──────────────────────────────────────────────────────────

def setup_database():
    """Create all tables and indexes from schema.sql.

    Idempotent — safe to run repeatedly (all statements use IF NOT EXISTS).
    """
    schema_sql = _SCHEMA_PATH.read_text(encoding="utf-8")
    with db_connection() as conn:
        conn.autocommit = True
        conn.execute(schema_sql)
    print("Database setup complete.")
