"""Multi-NPC turn orchestration and history formatting.

The orchestrator sits ABOVE the pipeline. It decides which NPC speaks next
and reframes history for each NPC's individual pipeline run.

Turn order modes:
    freeform    — score-based selection (default, current behavior)
    round_robin — cycle through actors list
    scripted    — fixed turn_sequence from scene config
"""


def select_speakers(session: dict, addressed_to: str = "room",
                    npc_configs: dict = None,
                    silence_threshold: float = 1.0,
                    player_initiated: bool = True) -> list[str]:
    """Pick which NPC(s) speak this turn based on turn order mode.

    Turn order modes (from scene config via session):
        "freeform" (default): score-based selection
        "round_robin": cycle through actors in order
        "scripted": follow scene's turn_sequence list

    For freeform scoring:
        - Direct address: +10 (if addressed_to matches NPC name or key)
        - Social dominance: social_dominance * 3.0 (0–3 range)
        - Recency penalty: -4 if spoke last turn, -2 if 2 turns ago

    Actor overrides (from session["actor_overrides"]) are checked
    for social_dominance_override before NPC config values.

    silence_threshold: minimum score required to speak. Only applies when
    player_initiated=False (NPC-initiative / silence watcher). When the
    player sends a message, someone always responds — the threshold is
    bypassed and the highest-scoring NPC is selected regardless.

    Returns an ordered list of NPC keys (usually 1).
    Empty list only possible for NPC-initiated turns below threshold.
    """
    npc_configs = npc_configs or {}
    npc_keys = session.get("npc_keys", [])
    if not npc_keys:
        return []

    turn_order = session.get("turn_order", "freeform")

    if turn_order == "round_robin":
        return _select_round_robin(session, npc_keys)
    elif turn_order == "scripted":
        return _select_scripted(session)

    # Freeform: score-based selection
    actor_overrides = session.get("actor_overrides", {})
    turn_history = session.get("turn_history", [])
    current_turn = session.get("current_turn", 0)

    scores = {}
    for npc_key in npc_keys:
        score = 0.0
        config = npc_configs.get(npc_key, {})
        npc = config.get("npc", {})

        # Direct address bonus
        npc_name = npc.get("name", "")
        if addressed_to and addressed_to not in ("room", "player"):
            if addressed_to.lower() in (npc_key.lower(), npc_name.lower()):
                score += 10.0

        # Social dominance base score — actor override takes priority
        overrides = actor_overrides.get(npc_key, {})
        dominance = overrides.get("social_dominance_override", 0.0)
        if not dominance:
            dominance = npc.get("social_dominance", 0.5)
        score += dominance * 3.0

        # Recency penalty
        last_spoke_turn = None
        for entry in reversed(turn_history):
            if entry["speaker"] == npc_key:
                last_spoke_turn = entry["turn"]
                break

        if last_spoke_turn is not None:
            turns_since = current_turn - last_spoke_turn
            if turns_since <= 1:
                score -= 4.0
            elif turns_since <= 2:
                score -= 2.0

        scores[npc_key] = score

    if not scores:
        return []

    # Silence threshold: only applies to NPC-initiated turns (silence watcher).
    # Player-initiated turns always get a response — someone must speak.
    max_score = max(scores.values())
    if not player_initiated and max_score < silence_threshold:
        return []

    # Return the highest-scoring NPC
    sorted_npcs = sorted(scores.items(), key=lambda x: -x[1])
    return [sorted_npcs[0][0]]


def _select_round_robin(session: dict, npc_keys: list[str]) -> list[str]:
    """Cycle through actors in order."""
    turn_history = session.get("turn_history", [])
    if not turn_history:
        return [npc_keys[0]]

    # Find last speaker and pick the next one in rotation
    last_speaker = turn_history[-1]["speaker"]
    try:
        idx = npc_keys.index(last_speaker)
        next_idx = (idx + 1) % len(npc_keys)
    except ValueError:
        next_idx = 0
    return [npc_keys[next_idx]]


def _select_scripted(session: dict) -> list[str]:
    """Follow fixed turn_sequence from scene config."""
    sequence = session.get("turn_sequence", [])
    if not sequence:
        return []
    current_turn = session.get("current_turn", 0)
    idx = current_turn % len(sequence)
    return [sequence[idx]]


def detect_addressed_npc(message: str, npc_keys: list[str],
                         npc_configs: dict) -> str:
    """Check if the player's message addresses a specific NPC by name.

    Simple heuristic: check if any NPC's display name or config key
    appears in the message text.

    Returns the NPC key if found, or "room" if no specific NPC addressed.
    """
    message_lower = message.lower()
    for npc_key in npc_keys:
        config = npc_configs.get(npc_key, {})
        npc_name = config.get("npc", {}).get("name", "")
        # Check display name (e.g. "Mira Hollowthorn") and first name
        if npc_name and npc_name.lower() in message_lower:
            return npc_key
        first_name = npc_name.split()[0] if npc_name else ""
        if first_name and len(first_name) > 2 and first_name.lower() in message_lower:
            return npc_key
        # Check config key (e.g. "mira")
        if npc_key.lower() in message_lower:
            return npc_key
    return "room"


def format_history_for_npc(history: list[dict], npc_key: str,
                           npc_names_by_key: dict = None) -> list[dict]:
    """Reframe conversation history for one NPC's perspective.

    - This NPC's messages → role: "assistant"
    - Player messages → role: "user" (no prefix)
    - Other NPC messages → role: "user" with "[OtherName says]: content"

    Args:
        history: Full session history with speaker field.
        npc_key: The NPC we're building history for.
        npc_names_by_key: {npc_key: display_name} mapping for speaker prefixes.

    Returns:
        List of {role, content} dicts suitable for LLM messages.
    """
    npc_names_by_key = npc_names_by_key or {}
    formatted = []

    for msg in history:
        speaker = msg.get("speaker", "user")
        content = msg.get("content", "")

        if speaker == npc_key:
            formatted.append({"role": "assistant", "content": content})
        elif speaker == "user":
            formatted.append({"role": "user", "content": content})
        else:
            other_name = npc_names_by_key.get(speaker, speaker)
            formatted.append({
                "role": "user",
                "content": f"[{other_name} says]: {content}",
            })

    return formatted
