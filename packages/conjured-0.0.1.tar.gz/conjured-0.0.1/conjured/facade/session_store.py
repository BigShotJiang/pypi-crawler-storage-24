"""In-memory session store.

Generic state container — holds session dicts keyed by ID.
No domain knowledge. Doesn't know about NPCs, scenes, or pipelines.

The facade's session creation logic adds domain-specific fields.
Import handlers seed pipeline-specific data when the first turn runs.
"""

import asyncio
import time
import uuid
from typing import Optional

from conjured.core.logging import get_logger

logger = get_logger(__name__)

SESSIONS: dict[str, dict] = {}

_STALE_THRESHOLD = 3600  # 1 hour
_last_reap = 0.0


def create_session(
    user_id: int = None,
    pipeline: str = "default",
) -> dict:
    """Create a minimal session and return it.

    The session starts with only infrastructure fields. Domain-specific
    fields (npc_key, scene, protected_facts, etc.) are added by the
    facade or by import handlers.
    """
    session_id = str(uuid.uuid4())
    session = {
        "session_id": session_id,
        "pipeline": pipeline,
        "history": [],
        "active": True,
        "user_id": user_id,
        "event_queue": asyncio.Queue(),
        "_last_access": time.time(),
    }
    SESSIONS[session_id] = session
    return session


def get_session(session_id: str) -> Optional[dict]:
    """Retrieve a session, updating last access time. Returns None if not found."""
    _reap_stale_sessions()
    session = SESSIONS.get(session_id)
    if session is not None:
        session["_last_access"] = time.time()
    return session


def end_session(session_id: str):
    """Remove session from in-memory store."""
    SESSIONS.pop(session_id, None)


def push_event(session_id: str, event: dict) -> None:
    """Push an SSE event to a session's queue. No-op if missing."""
    session = SESSIONS.get(session_id)
    if session and "event_queue" in session:
        try:
            session["event_queue"].put_nowait(event)
        except asyncio.QueueFull:
            pass


def append_history(session_id: str, role: str, content: str, speaker: str = None):
    """Append a message to a session's conversation history."""
    session = SESSIONS.get(session_id)
    if session:
        session["history"].append({
            "role": role,
            "content": content,
            "speaker": speaker,
        })


def get_history(session_id: str) -> list[dict]:
    """Get conversation history for a session."""
    session = SESSIONS.get(session_id)
    return session["history"] if session else []


def _reap_stale_sessions():
    """Lazily remove sessions inactive for >1 hour."""
    global _last_reap
    now = time.time()
    if now - _last_reap < 300:
        return
    _last_reap = now
    stale = [
        sid for sid, s in SESSIONS.items()
        if not s.get("active", True) or (now - s.get("_last_access", now)) > _STALE_THRESHOLD
    ]
    for sid in stale:
        SESSIONS.pop(sid, None)
    if stale:
        logger.info("stale_sessions_reaped", count=len(stale))
