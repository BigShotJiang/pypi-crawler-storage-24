"""Patience calculation for async NPC turns.

Determines how long an NPC waits before speaking unprompted
when the player is silent. Pure computation — caller provides config.
"""

from __future__ import annotations

# NPC personality trait → multiplier on base patience
PATIENCE_TRAIT_MULTIPLIERS = {
    "very_low": 0.4,
    "low": 0.7,
    "medium": 1.0,
    "high": 1.4,
    "very_high": 2.0,
}


def calculate_patience(
    npc_config: dict,
    scene: dict,
    patience_config: dict,
    pending_question: bool = False,
) -> float:
    """Calculate how many seconds before this NPC speaks unprompted.

    Formula: base × trait_mult × question_mult × (1 - dominance × 0.5) × (1 - tension × 0.3)
    Clamped to [min_seconds, max_seconds].
    Scene `patience_seconds` override takes precedence if set.

    Args:
        npc_config: NPC TOML config dict.
        scene: Scene config dict.
        patience_config: Patience tuning knobs (from config/handlers/state/patience.toml).
        pending_question: Whether the NPC asked the player a question.
    """
    base = patience_config.get("base_seconds", 15.0)
    q_mult = patience_config.get("question_multiplier", 2.5)
    min_s = patience_config.get("min_seconds", 5.0)
    max_s = patience_config.get("max_seconds", 45.0)

    # Scene override
    scene_override = scene.get("patience_seconds")
    if scene_override is not None:
        return max(min_s, min(float(scene_override), max_s))

    npc = npc_config.get("npc", {})

    # NPC patience personality trait
    trait = npc.get("patience", "medium")
    trait_mult = PATIENCE_TRAIT_MULTIPLIERS.get(trait, 1.0)

    # Social dominance: higher → less patient (speaks sooner)
    dominance = float(npc.get("social_dominance", 0.5))
    dom_factor = 1.0 - dominance * 0.5

    # Scene tension: higher → less patient
    tension = float(scene.get("tension", 0.0))
    tension_factor = 1.0 - tension * 0.3

    # Pending question: NPC asked the player something → wait longer
    question_factor = q_mult if pending_question else 1.0

    patience = base * trait_mult * question_factor * dom_factor * tension_factor
    return max(min_s, min(patience, max_s))
