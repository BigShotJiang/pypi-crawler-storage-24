"""Response pool lookup — Hades-style tiered pool system.

Tiers
-----
1 (story)    : Hand-crafted lines for game-critical moments (openings, milestones).
2 (contextual): State-gated lines, marked "seen" per session.
3 (generated) : Implicit — normal pipeline (not in pool files).
4 (fallback)  : Generic in-character lines when generation fails.

Pool files live in ``config/pools/<npc_key>.toml``.  At runtime, pools are
loaded from the compiled artifact (``compiled/response_pools.json``); if not
compiled, falls back to raw TOML.

Functions
---------
load_pools(npc_key)       → dict with tier_1, tier_2, tier_4 lists
find_pool_match(...)      → best matching entry or None
get_fallback_line(...)    → random Tier 4 entry
"""

from __future__ import annotations

import random
import tomllib
from pathlib import Path

from conjured.core.logging import get_logger
from conjured.handlers.utils.conditions import evaluate_conditions

logger = get_logger(__name__)

_POOLS_DIR = Path(__file__).resolve().parent.parent.parent.parent / "config" / "pools"


# ---------------------------------------------------------------------------
# Loading
# ---------------------------------------------------------------------------

def load_pools(npc_key: str) -> dict:
    """Load pool entries for an NPC.

    Tries compiled artifact first, falls back to raw TOML.
    Returns ``{"tier_1": [...], "tier_2": [...], "tier_4": [...]}``.
    """
    try:
        from conjured.core.artifacts import load_artifact
        all_pools = load_artifact("response_pools")
        if all_pools and npc_key in all_pools:
            return all_pools[npc_key]
    except Exception:
        pass

    # Fallback: load raw TOML
    path = _POOLS_DIR / f"{npc_key}.toml"
    if not path.exists():
        return {"tier_1": [], "tier_2": [], "tier_4": []}

    with open(path, "rb") as f:
        data = tomllib.load(f)

    return {
        "tier_1": data.get("tier_1", []),
        "tier_2": data.get("tier_2", []),
        "tier_4": data.get("tier_4", []),
    }


# ---------------------------------------------------------------------------
# Condition matching
# ---------------------------------------------------------------------------

def _entry_matches(entry: dict, *, trigger: str | None, input_class: str | None,
                   dialogue_act: str | None, npc_state: dict, session: dict,
                   query: str) -> bool:
    """Check if a pool entry matches the current context."""
    # Trigger filter (opening, silence, etc.)
    if "trigger" in entry:
        if entry["trigger"] != trigger:
            return False

    # Input class filter
    if "input_class" in entry:
        if entry["input_class"] != input_class:
            return False

    # Dialogue act filter
    if "dialogue_act" in entry:
        if entry["dialogue_act"] != dialogue_act:
            return False

    # Keyword filter (any keyword must appear in query)
    if "keywords" in entry and entry["keywords"]:
        query_lower = query.lower()
        if not any(kw.lower() in query_lower for kw in entry["keywords"]):
            return False

    # Conditions filter — uses shared evaluator
    conditions = entry.get("conditions", {})
    if conditions and not evaluate_conditions(conditions, npc_state, session):
        return False

    return True


def _specificity_score(entry: dict, query: str) -> int:
    """Score an entry by specificity.  Higher = more specific = preferred."""
    score = len(entry.get("conditions", {}))
    score += entry.get("priority", 0)

    # Bonus for each matching keyword
    if "keywords" in entry and entry["keywords"]:
        query_lower = query.lower()
        score += sum(1 for kw in entry["keywords"] if kw.lower() in query_lower)

    # Bonus for having a trigger, input_class, or dialogue_act filter
    if "trigger" in entry:
        score += 1
    if "input_class" in entry:
        score += 1
    if "dialogue_act" in entry:
        score += 1

    return score


# ---------------------------------------------------------------------------
# Pool match
# ---------------------------------------------------------------------------

def find_pool_match(
    npc_key: str,
    *,
    trigger: str | None = None,
    input_class: str | None = None,
    dialogue_act: str | None = None,
    mood: str = "",
    npc_state: dict | None = None,
    session: dict | None = None,
    query: str = "",
) -> dict | None:
    """Find the best matching pool entry across Tier 1 → Tier 2.

    Returns the entry dict with an added ``"tier"`` key, or None.
    """
    pools = load_pools(npc_key)
    if not pools:
        return None

    npc_state = npc_state or {}
    session = session or {}

    # Build npc_state for condition matching (include mood for mood_in/mood_not_in)
    pool_npc_state = {
        "familiarity": npc_state.get("familiarity", 0.0),
        "trust": npc_state.get("trust", 0.0),
        "respect": npc_state.get("respect", 0.0),
        "mood": mood,
    }

    # Session already has revealed_facts — pass through
    pool_session = session

    seen_key = f"_pool_seen_{npc_key}"
    seen_ids = set(session.get(seen_key, []))

    match_kwargs = dict(
        trigger=trigger,
        input_class=input_class,
        dialogue_act=dialogue_act,
        npc_state=pool_npc_state,
        session=pool_session,
        query=query,
    )

    # Tier 1: story-critical (not filtered by seen — always eligible)
    best = _find_best_in_tier(pools.get("tier_1", []), seen_ids=set(), **match_kwargs)
    if best:
        best["tier"] = "tier_1"
        return best

    # Tier 2: contextual (filtered by seen)
    best = _find_best_in_tier(pools.get("tier_2", []), seen_ids=seen_ids, **match_kwargs)
    if best:
        best["tier"] = "tier_2"
        return best

    return None


def _find_best_in_tier(
    entries: list[dict],
    seen_ids: set,
    **match_kwargs,
) -> dict | None:
    """Find the best matching entry in a single tier."""
    candidates = []
    for entry in entries:
        if entry.get("id", "") in seen_ids:
            continue
        if _entry_matches(entry, **match_kwargs):
            score = _specificity_score(entry, match_kwargs.get("query", ""))
            candidates.append((score, entry))

    if not candidates:
        return None

    # Sort by specificity (descending), stable sort preserves file order for ties
    candidates.sort(key=lambda x: x[0], reverse=True)
    return dict(candidates[0][1])  # return a copy


def get_pool_entry_by_id(npc_key: str, entry_id: str) -> dict | None:
    """Look up a pool entry by ID across all tiers.  Returns copy or None."""
    pools = load_pools(npc_key)
    for tier_name in ("tier_1", "tier_2", "tier_4"):
        for entry in pools.get(tier_name, []):
            if entry.get("id") == entry_id:
                result = dict(entry)
                result["tier"] = tier_name
                return result
    return None


def get_fallback_line(npc_key: str, seen_ids: set | None = None) -> dict | None:
    """Get a random Tier 4 fallback line (not seen-tracked)."""
    pools = load_pools(npc_key)
    tier_4 = pools.get("tier_4", [])
    if not tier_4:
        return None
    entry = random.choice(tier_4)
    return dict(entry)
