"""NPC agenda system — proactive topic initiation with condition gating.

Evaluates agenda items from NPC TOML config, selects topics via probability
gate + tension matching, tracks deflections computationally.

Pure functions — no DB, no API imports.
"""

from __future__ import annotations

import random

from conjured.handlers.utils.conditions import evaluate_conditions
from conjured.core.logging import get_logger

logger = get_logger(__name__)

# Mood → tension group mapping.
# Low tension always allowed. Medium needs moderate+. High needs intense.
_CALM_MOODS = frozenset({
    "neutral", "content", "pleased", "curious", "amused", "happy",
    "distracted", "relaxed",
})
_MODERATE_MOODS = frozenset({
    "solemn", "cautious", "troubled", "confused", "determined",
    "skeptical", "tired", "surprised", "concerned", "wary",
})
# Everything else is considered intense (allows all tensions).

_INITIATIVE_MULTIPLIERS = {
    "low": 0.5,
    "medium": 1.0,
    "high": 1.75,
}


def mood_allows_tension(mood: str, tension: str) -> bool:
    """Check if the current mood allows a given tension level.

    Low tension is always allowed. Medium needs moderate or intense mood.
    High tension needs intense mood (anything not calm or moderate).
    """
    if tension == "low":
        return True
    if mood in _CALM_MOODS:
        return False
    if tension == "medium":
        return True  # moderate + intense both allow medium
    # tension == "high": only intense moods
    return mood not in _MODERATE_MOODS


def evaluate_agenda_items(
    items: list[dict],
    npc_state: dict,
    session: dict,
    agenda_state: dict,
) -> list[dict]:
    """Filter agenda items by conditions and addressed status.

    Returns eligible items sorted by priority (lower = more urgent).
    """
    addressed = agenda_state.get("addressed", {})
    eligible = []

    for item in items:
        item_id = item.get("id", "")
        if not item_id:
            continue
        if addressed.get(item_id):
            continue
        conditions = item.get("requires", {})
        if not evaluate_conditions(conditions, npc_state, session):
            continue
        eligible.append(item)

    eligible.sort(key=lambda i: i.get("priority", 99))
    return eligible


def select_agenda_topic(
    eligible: list[dict],
    mood: str,
    trigger: str | None,
    probability: float,
    silence_probability: float,
    initiative_mult: float,
) -> dict | None:
    """Select an agenda topic via probability gate + tension matching.

    Returns the selected item or None.
    """
    if not eligible:
        return None

    # Determine effective probability
    if trigger == "silence":
        p = silence_probability * initiative_mult
    else:
        p = probability * initiative_mult

    if random.random() >= p:
        return None

    # Pick first eligible item whose tension matches the mood
    for item in eligible:
        tension = item.get("tension", "low")
        if mood_allows_tension(mood, tension):
            return item

    return None


def check_deflection(
    query: str,
    last_raised: dict,
) -> tuple[list[str], list[str]]:
    """Check if player addressed or deflected the last raised topic.

    Returns (addressed_ids, deflected_ids) based on keyword matching.
    """
    if not last_raised or not query:
        return [], []

    topic_id = last_raised.get("topic_id", "")
    keywords = last_raised.get("keywords", [])
    if not topic_id or not keywords:
        return [], []

    query_lower = query.lower()
    if any(kw.lower() in query_lower for kw in keywords):
        return [topic_id], []
    return [], [topic_id]


def get_initiative_multiplier(npc_config: dict) -> float:
    """Read npc.personality.initiative and return the probability multiplier."""
    initiative = npc_config.get("npc", {}).get("personality", {}).get(
        "initiative", "medium"
    )
    return _INITIATIVE_MULTIPLIERS.get(initiative, 1.0)


def build_agenda_section(item: dict, prompts: dict) -> str:
    """Format agenda topic content for prompt injection."""
    agenda_prompts = prompts.get("agenda", {})
    injection = agenda_prompts.get(
        "injection",
        "You want to bring up the following topic naturally in conversation:",
    )

    parts = [injection, f"- {item['topic']}"]

    subtext = item.get("subtext", "")
    if subtext:
        prefix = agenda_prompts.get("subtext_prefix", "Your underlying thought:")
        parts.append(f"{prefix} {subtext}")

    desired_effect = item.get("desired_effect", "")
    if desired_effect:
        prefix = agenda_prompts.get("desired_effect_prefix", "What you hope to achieve:")
        parts.append(f"{prefix} {desired_effect}")

    return "\n".join(parts)


def build_deflection_notice(item: dict, npc_name: str, prompts: dict) -> str:
    """Format deflection notice for inference-from-absence."""
    agenda_prompts = prompts.get("agenda", {})
    template = agenda_prompts.get(
        "deflection_notice",
        "You notice they keep avoiding the subject of {topic}. This is becoming conspicuous.",
    )
    return template.format(topic=item.get("topic", "something"), name=npc_name)
