"""Handler package — importing this module registers all handlers.

Used by ensure_handlers_loaded() in the pipeline registry.
"""

from conjured.handlers.analysis import length_hint  # noqa: F401
from conjured.handlers.analysis import process_emotes  # noqa: F401
