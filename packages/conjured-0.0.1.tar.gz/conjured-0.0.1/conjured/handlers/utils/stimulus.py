"""Stimulus detection and relevance annotation — evidence, gifts, contradictions.

Detects when a player presents a stimulus (evidence, gift, contradiction)
to an NPC, annotates it with NPC-specific relevance, and builds prompt
text for calibrated reactions.

Pure functions — called by analysis and prompt assembly handlers.

TODO: presentation verbs, dialogue act sets, and reaction templates should
be extracted to a handler TOML when the analysis/prompt handlers migrate.
"""

from __future__ import annotations

PRESENTATION_VERBS: frozenset[str] = frozenset({
    "show", "give", "present", "offer", "hand", "reveal", "tell",
    "inform", "explain", "demonstrate", "produce", "provide",
    "bring", "deliver", "display", "share", "confess", "admit",
    "disclose", "return", "surrender", "submit",
})

STIMULUS_DIALOGUE_ACTS: frozenset[str] = frozenset({
    "offer", "statement", "confession", "accusation", "action",
})


# ---------------------------------------------------------------------------
# Detection
# ---------------------------------------------------------------------------

def detect_stimulus(
    action_triple: dict | None,
    dialogue_act: str | list[str],
    entities: list[dict],
    query: str,
) -> dict | None:
    """Detect if the player is presenting a stimulus to the NPC.

    Path 1: action triple with a presentation verb and non-trivial object.
    Path 2: stimulus dialogue act with entity references and non-trivial query.

    Returns a stimulus dict or None.
    """
    if action_triple and action_triple.get("verb") in PRESENTATION_VERBS:
        obj = action_triple.get("object") or ""
        if obj and len(obj.strip()) > 1:
            return {
                "verb": action_triple["verb"],
                "object": obj,
                "indirect_object": action_triple.get("indirect_object", ""),
                "source": "action_triple",
                "entities": entities,
            }

    acts = dialogue_act if isinstance(dialogue_act, list) else [dialogue_act]
    matching_act = next((a for a in acts if a in STIMULUS_DIALOGUE_ACTS), None)
    if matching_act and entities:
        if len(query.split()) >= 3:
            verb_map = {
                "offer": "present",
                "statement": "inform",
                "confession": "confess",
                "accusation": "accuse",
                "action": "demonstrate",
            }
            return {
                "verb": verb_map.get(matching_act, "present"),
                "object": query,
                "indirect_object": "",
                "source": "dialogue_act",
                "entities": entities,
            }

    return None


# ---------------------------------------------------------------------------
# Relevance annotation
# ---------------------------------------------------------------------------

def annotate_relevance(
    stimulus: dict,
    npc_config: dict,
    npc_state: dict,
) -> dict:
    """Annotate a stimulus with NPC-specific relevance signals.

    Returns dict with domain_match, personal_match, sensitivity_hit,
    emotional_weight (0.0-1.0).
    """
    npc = npc_config.get("npc", {})
    stimulus_text = stimulus.get("object", "").lower()
    entity_keys = {e.get("key", "") for e in stimulus.get("entities", [])}

    tag_modifiers = npc.get("tag_modifiers", {})
    domain_match = [
        tag for tag in tag_modifiers
        if tag.lower() in stimulus_text
    ]

    relationships = npc.get("npc_relationships", [])
    personal_match = [
        {"npc_key": rel["npc_key"], "description": rel.get("description", "")}
        for rel in relationships
        if rel.get("npc_key", "") in entity_keys
    ]

    sensitivities = npc.get("emotional_profile", {}).get("sensitivities", {})
    sensitivity_hit = _check_sensitivity_match(stimulus_text, sensitivities)

    weight = 0.0
    if domain_match:
        weight += 0.3
    if personal_match:
        weight += 0.4
    if sensitivity_hit:
        weight += 0.3
    weight = min(1.0, weight)

    return {
        "domain_match": domain_match,
        "personal_match": personal_match,
        "sensitivity_hit": sensitivity_hit,
        "emotional_weight": weight,
    }


def _check_sensitivity_match(text: str, sensitivities: dict) -> str | None:
    """Check if stimulus text matches any NPC sensitivity. Returns key or None."""
    for key in sensitivities:
        words = key.lower().split("_")
        if any(w in text for w in words if len(w) > 2):
            return key
    return None


# ---------------------------------------------------------------------------
# Reaction intensity
# ---------------------------------------------------------------------------

def get_reaction_intensity(expression_style: str) -> str:
    """Map NPC expression_style to reaction intensity keyword."""
    return {
        "restrained": "subtle",
        "expressive": "visible",
        "deflective": "deflected",
        "sardonic": "ironic",
        "controlled": "controlled",
    }.get(expression_style, "visible")


# ---------------------------------------------------------------------------
# Prompt section building
# ---------------------------------------------------------------------------

def build_stimulus_section(
    stimulus: dict,
    relevance: dict,
    expression_style: str,
    prompts: dict,
) -> str:
    """Build prompt section text for stimulus reaction.

    Returns empty string if prompts are missing.
    """
    sp = prompts.get("stimulus", {})
    if not sp:
        return ""

    parts = []

    detected_template = sp.get(
        "detected",
        "The player just presented something to you: {stimulus_description}",
    )
    verb = stimulus.get("verb", "presented")
    obj = stimulus.get("object", "something")
    parts.append(detected_template.format(stimulus_description=f"{verb}s {obj}"))

    if relevance.get("domain_match"):
        domain_template = sp.get(
            "relevance_domain",
            "This relates to something you know about: {domain}",
        )
        parts.append(domain_template.format(
            domain=", ".join(relevance["domain_match"]),
        ))

    for pm in relevance.get("personal_match", []):
        personal_template = sp.get(
            "relevance_personal",
            "This involves {connection} — someone you have feelings about.",
        )
        parts.append(personal_template.format(
            connection=pm.get("npc_key", "someone"),
        ))

    if relevance.get("sensitivity_hit"):
        sensitive_template = sp.get(
            "relevance_sensitive",
            "This touches on a topic that is emotionally charged for you: {sensitivity}",
        )
        parts.append(sensitive_template.format(
            sensitivity=relevance["sensitivity_hit"].replace("_", " "),
        ))

    reaction_key = f"reaction_{expression_style}"
    reaction_text = sp.get(reaction_key, "")
    if reaction_text:
        parts.append(reaction_text)

    return "\n".join(parts)
