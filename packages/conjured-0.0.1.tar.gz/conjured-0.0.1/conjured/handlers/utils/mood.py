"""Mood accumulator and behavioral state builder.

Two-axis (warmth, arousal) mood model. Pure computation — no DB, no
pipeline wiring, no config loading.

Call update_mood() each turn to advance the mood state, get_mood_key()
to map axes to a discrete label, build_behavioral_state() to produce
the prompt fragment.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any


# ---------------------------------------------------------------------------
# Mood state
# ---------------------------------------------------------------------------

@dataclass
class MoodState:
    """Two-axis mood representation per NPC session.

    warmth: -1 (cold) to +1 (warm)
    arousal: -1 (calm) to +1 (agitated)
    """

    warmth: float = 0.0
    arousal: float = 0.0
    baseline_warmth: float = 0.0
    baseline_arousal: float = 0.0
    friction_warmth: float = 0.2
    friction_arousal: float = 0.1
    responsiveness: float = 0.5

    def __post_init__(self) -> None:
        self.warmth = _clamp(self.warmth)
        self.arousal = _clamp(self.arousal)

    @classmethod
    def from_npc_config(cls, npc_config: dict) -> MoodState:
        """Build initial mood state from an NPC TOML config dict.

        Reads from ``npc_config["npc"]["mood"]`` if present, otherwise
        uses defaults.
        """
        mood_cfg = (npc_config.get("npc") or {}).get("mood") or {}
        bw = float(mood_cfg.get("baseline_warmth", 0.0))
        ba = float(mood_cfg.get("baseline_arousal", 0.0))
        return cls(
            warmth=bw,
            arousal=ba,
            baseline_warmth=bw,
            baseline_arousal=ba,
            friction_warmth=float(mood_cfg.get("friction_warmth", 0.2)),
            friction_arousal=float(mood_cfg.get("friction_arousal", 0.1)),
            responsiveness=float(mood_cfg.get("responsiveness", 0.5)),
        )


def _clamp(v: float, lo: float = -1.0, hi: float = 1.0) -> float:
    return max(lo, min(hi, v))


# ---------------------------------------------------------------------------
# DA → signal mapping (21 canonical DA classes)
# ---------------------------------------------------------------------------

# Each entry: (warmth_pressure, arousal_pressure)
DA_SIGNALS: dict[str, tuple[float, float]] = {
    "question":        ( 0.0,  +0.1),
    "yes_no_question": ( 0.0,  +0.1),
    "command":         (-0.1,  +0.3),
    "statement":       ( 0.0,   0.0),
    "opinion":         ( 0.0,  +0.1),
    "agree":           (+0.2,   0.0),
    "disagree":        (-0.1,  +0.2),
    "acknowledgment":  (+0.1,  -0.1),
    "greeting":        (+0.1,   0.0),
    "farewell":        ( 0.0,  -0.2),
    "action":          ( 0.0,  +0.2),
    "emote":           (+0.1,   0.0),
    "out_of_character":( 0.0,   0.0),
    "offer":           (+0.3,  +0.1),
    "hostile":         (-0.6,  +0.8),
    "hedge":           ( 0.0,   0.0),
    "conditional":     ( 0.0,  +0.1),
    "intent":          ( 0.0,  +0.1),
    "flirt":           (+0.4,  +0.3),
    "accusation":      (-0.5,  +0.7),
    "confession":      (+0.2,  +0.3),
}

# Weight applied to DA signal vs sentiment score in pressure calculation
_DA_WEIGHT = 0.6
_SENTIMENT_WEIGHT = 0.4

# Context flag adjustments
_CONTEXT_SIGNALS: dict[str, tuple[float, float]] = {
    "ik_detected":           (-0.3, +0.5),
    "manipulation_detected": ( 0.0,  0.0),  # handled by scrubber, not mood
}


# ---------------------------------------------------------------------------
# Mood update
# ---------------------------------------------------------------------------

def update_mood(
    current: MoodState,
    player_da: str | None,
    sentiment_score: float,
    context_flags: dict[str, bool] | None = None,
) -> MoodState:
    """Advance mood state by one turn.

    Parameters
    ----------
    current : MoodState
        The NPC's current mood axes.
    player_da : str | None
        Dialogue act label from DistilBERT (e.g. "hostile", "greeting").
    sentiment_score : float
        VADER compound score, -1 to +1.
    context_flags : dict
        Optional boolean flags like ``ik_detected``, ``manipulation_detected``.

    Returns a **new** MoodState (does not mutate ``current``).
    """
    ctx = context_flags or {}

    # --- pressure from DA ---
    da_w, da_a = DA_SIGNALS.get(player_da or "", (0.0, 0.0))

    # --- pressure from sentiment ---
    sent_w = sentiment_score
    sent_a = abs(sentiment_score) * 0.3

    # --- combined pressure ---
    pressure_w = da_w * _DA_WEIGHT + sent_w * _SENTIMENT_WEIGHT
    pressure_a = da_a * _DA_WEIGHT + sent_a * _SENTIMENT_WEIGHT

    # --- context flag adjustments ---
    for flag, (cw, ca) in _CONTEXT_SIGNALS.items():
        if ctx.get(flag):
            pressure_w += cw
            pressure_a += ca

    # --- apply responsiveness ---
    resp = current.responsiveness
    delta_w = pressure_w * resp
    delta_a = pressure_a * resp

    # --- apply friction (pull toward baseline) ---
    friction_w = (current.baseline_warmth - current.warmth) * current.friction_warmth
    friction_a = (current.baseline_arousal - current.arousal) * current.friction_arousal

    new_w = _clamp(current.warmth + delta_w + friction_w)
    new_a = _clamp(current.arousal + delta_a + friction_a)

    return MoodState(
        warmth=new_w,
        arousal=new_a,
        baseline_warmth=current.baseline_warmth,
        baseline_arousal=current.baseline_arousal,
        friction_warmth=current.friction_warmth,
        friction_arousal=current.friction_arousal,
        responsiveness=current.responsiveness,
    )


# ---------------------------------------------------------------------------
# Mood key mapping (axes → discrete label)
# ---------------------------------------------------------------------------

_COLD = -0.25
_WARM = 0.25
_CALM = -0.15
_AGITATED = 0.25


def get_mood_key(
    warmth: float,
    arousal: float,
    context_flags: dict[str, bool] | None = None,
) -> str:
    """Map warmth/arousal axes to a discrete mood key.

    Special context flags can override the geometric mapping:
    - ``ik_detected`` → "suspicious"
    """
    ctx = context_flags or {}
    if ctx.get("ik_detected"):
        return "suspicious"

    if warmth <= _COLD:
        w_band = "cold"
    elif warmth >= _WARM:
        w_band = "warm"
    else:
        w_band = "neutral"

    if arousal <= _CALM:
        a_band = "calm"
    elif arousal >= _AGITATED:
        a_band = "agitated"
    else:
        a_band = "neutral"

    return _MOOD_GRID[(w_band, a_band)]


_MOOD_GRID: dict[tuple[str, str], str] = {
    ("cold",    "calm"):     "solemn",
    ("cold",    "neutral"):  "cautious",
    ("cold",    "agitated"): "irritated",
    ("neutral", "calm"):     "neutral",
    ("neutral", "neutral"):  "neutral",
    ("neutral", "agitated"): "curious",
    ("warm",    "calm"):     "content",
    ("warm",    "neutral"):  "pleased",
    ("warm",    "agitated"): "amused",
}


# ---------------------------------------------------------------------------
# Behavioral state builder
# ---------------------------------------------------------------------------

_REL_THRESHOLDS = (0.3, 0.7)


def _rel_level(score: float) -> str:
    """Map a 0-1 relationship score to low/mid/high."""
    if score < _REL_THRESHOLDS[0]:
        return "low"
    elif score < _REL_THRESHOLDS[1]:
        return "mid"
    else:
        return "high"


def build_behavioral_state(
    mood_key: str,
    familiarity: float = 0.5,
    trust: float = 0.5,
    respect: float = 0.5,
    *,
    prompts: dict | None = None,
) -> str:
    """Combine mood prompt + relationship prompts into a single text block.

    Parameters
    ----------
    mood_key : str
        Discrete mood label from get_mood_key().
    familiarity, trust, respect : float
        Relationship scores (0-1).
    prompts : dict | None
        Prompt config dict with ``rules.mood`` and ``rules.rel_*`` sections.
        When None, returns relationship lines only (no mood text).
    """
    parts: list[str] = []

    rules = (prompts or {}).get("rules", {})

    # --- mood line ---
    mood_text = rules.get("mood", {}).get(mood_key, "")
    if mood_text:
        parts.append(mood_text)

    # --- relationship lines ---
    for dim, score in (("rel_familiarity", familiarity), ("rel_trust", trust), ("rel_respect", respect)):
        level = _rel_level(score)
        rel_text = rules.get(dim, {}).get(level, "")
        if rel_text:
            parts.append(rel_text)

    return "\n".join(parts)
