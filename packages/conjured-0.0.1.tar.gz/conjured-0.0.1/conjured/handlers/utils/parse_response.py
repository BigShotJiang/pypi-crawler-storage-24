"""Schema-aware response parsing for pipeline generation output.

Knows which JSON field holds the primary text for each schema type.
Includes stage direction extraction (RP action verbs in parens/asterisks).
This is domain logic — it belongs with handlers, not in core.

Usage by generation handlers:
    from conjured.handlers.utils.parse_response import parse_response
"""

import re

from conjured.core.parsing import parse_json, strip_html_tags

# ---------------------------------------------------------------------------
# Stage direction extraction (domain-specific verb list)
# ---------------------------------------------------------------------------

_ASTERISK_ACTION_RE = re.compile(r"\*[^*]+\*")
_PARENS_ACTION_RE = re.compile(
    r"\([^)]*(?:looks|leans|smiles|nods|sighs|pauses|glances|waves|shrugs|"
    r"gestures|steps|turns|crosses|folds|taps|reaches|adjusts|shifts|tilts|"
    r"narrows|raises|lowers|clenches)[^)]*\)",
    re.IGNORECASE,
)


def extract_stage_directions(text: str) -> tuple[str, list[str]]:
    """Extract asterisk-wrapped actions and parenthetical stage directions.

    Returns (clean_text, directions) where directions is a list of
    extracted action strings (without asterisks/parens).
    """
    directions: list[str] = []

    def _collect_asterisk(m: re.Match) -> str:
        directions.append(m.group(0)[1:-1].strip())
        return ""

    def _collect_parens(m: re.Match) -> str:
        directions.append(m.group(0)[1:-1].strip())
        return ""

    text = _ASTERISK_ACTION_RE.sub(_collect_asterisk, text)
    text = _PARENS_ACTION_RE.sub(_collect_parens, text)
    text = re.sub(r"  +", " ", text).strip()
    return text, directions


def strip_stage_directions(text: str) -> str:
    """Remove stage directions. Convenience wrapper."""
    clean, _ = extract_stage_directions(text)
    return clean


# ---------------------------------------------------------------------------
# Schema-aware response parsing
# ---------------------------------------------------------------------------

# Schema name → primary text field in the JSON output
_SCHEMA_PRIMARY_FIELD = {
    "dialogue_events": "dialogue",
    "arbitration": "ruling",
    "narration": "narration",
    "deliberation": "dialogue",
    "synthesis": "summary",
    "authoring": "content",
    "arena_generation": "name",
    "battle_narration": "narrative",
}


def parse_response(raw: str, schema: str = "dialogue_events") -> tuple[str, list, bool, list[str]]:
    """Parse structured JSON output from LLM generation.

    Args:
        raw: Raw LLM output string.
        schema: Schema name — determines which JSON field holds the primary text.

    Returns (dialogue, events, parse_ok, stage_directions).
    """
    primary_field = _SCHEMA_PRIMARY_FIELD.get(schema, "dialogue")
    data = parse_json(raw)
    if not isinstance(data, dict):
        clean = strip_html_tags(raw)
        dialogue, stage_directions = extract_stage_directions(clean)
        return dialogue, [], False, stage_directions
    clean = strip_html_tags(data.get(primary_field, data.get("dialogue", raw)))
    dialogue, stage_directions = extract_stage_directions(clean)
    return dialogue, data.get("events", []), True, stage_directions
