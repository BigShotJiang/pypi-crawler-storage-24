"""Conversational entrainment — pacing, formality, and vocabulary adaptation.

Adapts NPC communication style to match the player's register:
- Formality detection: casual / neutral / formal classification
- Vocabulary tracking: rolling word frequency window across turns
- Dynamic max_tokens: scale LLM output budget to player input length

Pure functions — called by prompt assembly and generation handlers.

TODO: regex sets, stop words, and verbosity scales should be extracted
to a handler TOML (config/handlers/prompt/entrainment.toml) when the
prompt assembly handler migrates. Currently hardcoded or passed as dicts.
"""

from __future__ import annotations

import re

# Contractions that signal casual register.
_CONTRACTIONS = re.compile(
    r"\b(don't|can't|won't|wouldn't|shouldn't|couldn't|isn't|aren't|wasn't|weren't"
    r"|i'm|you're|we're|they're|he's|she's|it's|i've|you've|we've|they've"
    r"|i'll|you'll|we'll|they'll|i'd|you'd|we'd|they'd"
    r"|ain't|gonna|wanna|gotta|dunno|kinda|sorta)\b",
    re.IGNORECASE,
)

# Polite markers that signal formal register.
_FORMAL_MARKERS = re.compile(
    r"\b(please|thank you|thanks|pardon|excuse me|sir|madam|ma'am"
    r"|greetings|good morning|good evening|good day|forgive me"
    r"|if you would|if you please|i beg|with respect)\b",
    re.IGNORECASE,
)

# Common stop words excluded from vocabulary tracking.
_STOP_WORDS = frozenset({
    "a", "an", "the", "and", "or", "but", "in", "on", "at", "to", "for",
    "of", "with", "by", "from", "is", "are", "was", "were", "be", "been",
    "being", "have", "has", "had", "do", "does", "did", "will", "would",
    "could", "should", "may", "might", "shall", "can", "not", "no", "yes",
    "it", "its", "this", "that", "these", "those", "he", "she", "they",
    "we", "you", "i", "me", "my", "your", "his", "her", "our", "their",
    "them", "him", "us", "who", "what", "where", "when", "why", "how",
    "which", "if", "then", "than", "so", "as", "just", "also", "about",
    "up", "out", "into", "over", "some", "any", "all", "very", "too",
    "here", "there", "now", "well", "like", "know", "think", "want",
    "got", "get", "go", "going", "went", "come", "came", "said", "say",
    "tell", "told", "see", "saw", "look", "make", "take", "give", "let",
    "much", "many", "more", "most", "own", "other", "only", "even",
    "still", "back", "really", "right", "yeah", "okay", "oh", "hey",
    "hmm", "uh", "um",
})

_HEDGE_WORDS = frozenset({
    "maybe", "perhaps", "possibly", "suppose", "guess",
})

_EXCLUDE_WORDS = _STOP_WORDS | _HEDGE_WORDS


def detect_formality(text: str) -> str:
    """Classify player text as 'casual', 'neutral', or 'formal'."""
    if not text or not text.strip():
        return "neutral"

    score = 0.0

    contractions = len(_CONTRACTIONS.findall(text))
    if contractions >= 2:
        score -= 2.0
    elif contractions == 1:
        score -= 1.0

    formal_markers = len(_FORMAL_MARKERS.findall(text))
    if formal_markers >= 2:
        score += 2.0
    elif formal_markers == 1:
        score += 1.0

    words = text.split()
    if words:
        avg_len = sum(len(w.strip(".,!?;:'\"")) for w in words) / len(words)
        if avg_len < 3.5:
            score -= 1.0
        elif avg_len > 5.5:
            score += 1.0

    stripped = text.strip()
    if stripped == stripped.lower() and not stripped.endswith((".", "!", "?")):
        score -= 0.5

    if stripped[0].isupper() and stripped.endswith("."):
        score += 0.5

    if score <= -1.5:
        return "casual"
    elif score >= 1.5:
        return "formal"
    return "neutral"


def track_vocabulary(
    query: str,
    entrainment_state: dict,
    exclude_set: set | None = None,
    window_size: int = 5,
) -> None:
    """Update rolling word frequency window in entrainment_state.

    Tracks last `window_size` player messages. Mutates entrainment_state.
    """
    if not query or not query.strip():
        return

    exclude = exclude_set or _EXCLUDE_WORDS

    words = set()
    for token in query.lower().split():
        clean = token.strip(".,!?;:'\"()-")
        if len(clean) >= 4 and clean.isalpha() and clean not in exclude:
            words.add(clean)

    if not words:
        return

    window = entrainment_state.get("vocab_window", [])
    window.append(list(words))
    if len(window) > window_size:
        window = window[-window_size:]
    entrainment_state["vocab_window"] = window

    counts: dict[str, int] = {}
    for word_set in window:
        for w in word_set:
            counts[w] = counts.get(w, 0) + 1
    entrainment_state["vocab_counts"] = counts


def get_adopted_terms(
    entrainment_state: dict,
    threshold: int = 2,
    max_terms: int = 5,
) -> list[str]:
    """Return content words the player has used >= threshold times."""
    counts = entrainment_state.get("vocab_counts", {})
    if not counts:
        return []

    candidates = [(w, c) for w, c in counts.items() if c >= threshold]
    candidates.sort(key=lambda x: x[1], reverse=True)
    return [w for w, _ in candidates[:max_terms]]


def build_entrainment_section(
    adopted_terms: list[str],
    formality: str,
    pacing: str,
    npc_formality: str,
    prompts: dict,
) -> str:
    """Format entrainment instructions for prompt injection.

    Returns empty string if no adaptation needed.
    """
    entrainment_prompts = prompts.get("entrainment", {})
    parts = []

    if adopted_terms:
        template = entrainment_prompts.get(
            "vocabulary_mirror",
            "The player tends to use these terms: {terms}. Mirror their language naturally when relevant.",
        )
        parts.append(template.format(terms=", ".join(adopted_terms)))

    if formality == "casual" and npc_formality != "casual":
        text = entrainment_prompts.get(
            "formality_casual",
            "The player speaks casually and informally. Match their register — relax your language.",
        )
        parts.append(text)
    elif formality == "formal" and npc_formality != "formal":
        text = entrainment_prompts.get(
            "formality_formal",
            "The player speaks formally and precisely. Match their register — be more measured in your speech.",
        )
        parts.append(text)

    return "\n".join(parts)


def compute_dynamic_max_tokens(
    player_word_count: int,
    npc_verbosity: str,
    config: dict,
) -> int:
    """Compute max_tokens based on player input length.

    Base: player_words × multiplier. Adjusted by NPC verbosity.
    Clamped to [min_tokens, max_tokens].
    """
    multiplier = config.get("multiplier", 3.0)
    min_tokens = config.get("min_tokens", 50)
    max_tokens = config.get("max_tokens", 500)

    verbosity_scales = {
        "terse": config.get("verbosity_scale_terse", 0.6),
        "measured": config.get("verbosity_scale_moderate", 1.0),
        "moderate": config.get("verbosity_scale_moderate", 1.0),
        "verbose": config.get("verbosity_scale_verbose", 1.5),
    }
    v_scale = verbosity_scales.get(npc_verbosity, 1.0)

    base = player_word_count * multiplier * v_scale
    return int(max(min_tokens, min(max_tokens, base)))
