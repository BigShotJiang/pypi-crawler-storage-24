"""Controlled disfluencies — character-specific speech imperfections.

Disfluency profiles modulate speech naturalness during prompt assembly:
- nervous: hedging, trailing off
- deceptive: self-corrections, over-specificity
- thoughtful: rephrasing, mid-sentence pivots
- authoritative: almost none
- none: no disfluency injection

Emotional arousal modulates frequency (higher arousal = more disfluency).

Pure functions — called by the prompt assembly handler.

TODO: mood→arousal frozensets and profile templates should be extracted
to a handler TOML (config/handlers/prompt/disfluency.toml) when the
prompt assembly handler migrates. Currently passed in as a prompts dict.
"""

from __future__ import annotations

# ---------------------------------------------------------------------------
# Mood → arousal classification
# ---------------------------------------------------------------------------

_LOW_AROUSAL_MOODS = frozenset({
    "neutral", "content", "pleased", "calm", "bored",
    "tired", "distracted", "solemn", "nostalgic", "resigned",
    "satisfied", "relaxed", "focused",
})

_MODERATE_AROUSAL_MOODS = frozenset({
    "curious", "amused", "cautious", "confused", "troubled",
    "skeptical", "concerned", "worried", "determined", "grateful",
    "mischievous", "hopeful", "embarrassed", "annoyed",
    "defensive", "guilty", "sad", "impatient",
})


def get_arousal_level(mood: str) -> str:
    """Classify mood into arousal level: 'low', 'moderate', or 'high'."""
    if mood in _LOW_AROUSAL_MOODS:
        return "low"
    if mood in _MODERATE_AROUSAL_MOODS:
        return "moderate"
    return "high"


def should_inject_disfluency(profile: str, arousal: str) -> bool:
    """Determine whether disfluency instruction should be injected this turn."""
    if profile in ("none", "authoritative", ""):
        return False
    if arousal in ("high", "moderate"):
        return True
    return profile == "nervous"


def get_disfluency_cap(arousal: str) -> str:
    """Return arousal-dependent cap string for prompt instruction."""
    if arousal == "high":
        return "up to 2"
    if arousal == "moderate":
        return "1-2"
    return "at most 1"


def build_disfluency_section(
    profile: str,
    arousal: str,
    prompts: dict,
) -> str:
    """Build prompt section text for disfluency injection.

    Args:
        profile: NPC disfluency profile (from voice config)
        arousal: 'low', 'moderate', or 'high' (from get_arousal_level)
        prompts: dict with 'disfluency' key containing profile templates

    Returns empty string if no injection needed.
    """
    if not should_inject_disfluency(profile, arousal):
        return ""

    disfluency_prompts = prompts.get("disfluency", {})
    profile_text = disfluency_prompts.get(profile, "")
    if not profile_text:
        return ""

    cap = get_disfluency_cap(arousal)
    cap_template = disfluency_prompts.get(
        "cap_instruction",
        "Use {cap} natural disfluencies in your response — no more.",
    )
    cap_text = cap_template.format(cap=cap)

    return f"{profile_text}\n{cap_text}"
