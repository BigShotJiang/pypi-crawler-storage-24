"""Condition evaluator — checks condition dicts against NPC state + session.

Used by mandatory delivery (Phase 4.2), conditional revelation gating (Phase 4.4),
secret reveal conditions, and response pool gating.
Conditions are AND'd: all must be satisfied for the result to be True.

Supported condition types:
    trust, familiarity, respect — relationship >= threshold
    trust_lt, familiarity_lt, respect_lt — relationship < threshold
    mood_in  — npc_state["mood"] must be in the given list
    mood_not_in — npc_state["mood"] must NOT be in the given list
    flag  — single session flag is truthy
    flags — list of session flags, all must be truthy
    min_turns — minimum player turn count in session history
    force_at_turn — unconditionally true when turn count >= value (deadline trigger)
    revealed_fact  — a specific fact ID must be in session["revealed_facts"]
    not_revealed_fact — a specific fact ID must NOT be in session["revealed_facts"]
    isolation_state — NPC must be in this isolation state or later
                      ("cracking" matches cracking+aware, "aware" matches aware only)

Usage:
    from conjured.handlers.utils.conditions import evaluate_conditions

    evaluate_conditions({"trust": 0.5, "flag": "quest_started"}, npc_state, session)
    # True if npc_state["trust"] >= 0.5 AND session["flags"]["quest_started"] is truthy

    # Mood gating (e.g. response pools)
    evaluate_conditions({"mood_in": ["angry", "furious"]}, npc_state, session)

    # Deadline trigger: force reveal at turn 12 regardless of trust
    evaluate_conditions({"force_at_turn": 12}, npc_state, session)

    # Reveal when NPC is cracking or aware
    evaluate_conditions({"isolation_state": "cracking"}, npc_state, session)
"""

from __future__ import annotations

from conjured.core.logging import get_logger

logger = get_logger(__name__)

_RELATIONSHIP_FIELDS = frozenset({
    "trust", "familiarity", "respect",
})

_RELATIONSHIP_LT_SUFFIXES = {
    f"{f}_lt": f for f in _RELATIONSHIP_FIELDS
}


def evaluate_conditions(conditions: dict, npc_state: dict, session: dict) -> bool:
    """Evaluate all conditions against current state. Returns True if ALL pass.

    Args:
        conditions: dict of condition_type → value (from TOML config or game layer)
        npc_state: NPC state dict with relationship values, mood, etc.
        session: session dict with history, flags, etc.

    Returns:
        True if every condition is satisfied (or conditions is empty/None).
    """
    if not conditions:
        return True

    for key, value in conditions.items():
        if key in _RELATIONSHIP_FIELDS:
            current = npc_state.get(key, 0.0)
            if current < float(value):
                return False

        elif key in _RELATIONSHIP_LT_SUFFIXES:
            field = _RELATIONSHIP_LT_SUFFIXES[key]
            current = npc_state.get(field, 0.0)
            if current >= float(value):
                return False

        elif key == "mood_in":
            if npc_state.get("mood", "") not in value:
                return False

        elif key == "mood_not_in":
            if npc_state.get("mood", "") in value:
                return False

        elif key == "flag":
            flags = session.get("flags", {})
            if not flags.get(value):
                return False

        elif key == "flags":
            flags = session.get("flags", {})
            if not all(flags.get(f) for f in value):
                return False

        elif key == "min_turns":
            turn_count = sum(1 for m in session.get("history", []) if m.get("role") == "user")
            if turn_count < int(value):
                return False

        elif key == "force_at_turn":
            # Deadline trigger — unconditionally satisfied when turn count >= value
            turn_count = sum(1 for m in session.get("history", []) if m.get("role") == "user")
            if turn_count < int(value):
                return False

        elif key == "isolation_state":
            # Match this state or any later state in the progression.
            # Checks npc_state first, then session isolation_states dict.
            _STATE_ORDER = {"full": 0, "cracking": 1, "aware": 2}
            current_iso = npc_state.get("_isolation_state", "")
            if not current_iso:
                npc_key = npc_state.get("_key", npc_state.get("name", ""))
                iso_states = session.get("isolation_states", {})
                current_iso = iso_states.get(npc_key, "full") if npc_key else "full"
            required_level = _STATE_ORDER.get(value, 0)
            current_level = _STATE_ORDER.get(current_iso, 0)
            if current_level < required_level:
                return False

        elif key == "revealed_fact":
            revealed = session.get("revealed_facts", [])
            if value not in revealed:
                return False

        elif key == "not_revealed_fact":
            revealed = session.get("revealed_facts", [])
            if value in revealed:
                return False

        else:
            logger.warning("unknown_condition_type", key=key, value=value)

    return True
