"""DA-modulated emote probability — controls when emote directives are injected.

Computes per-turn probability of injecting an emote directive into the NPC
prompt, based on dialogue act category, NPC mood, and per-NPC emote config.

    probability = base_chance × da_modifier × mood_modifier

Physical vocabulary constraints (repertoire/avoid lists) restrict which
physical actions the model can produce.

Pure functions — called by prompt assembly handler.

TODO: _DA_MODIFIERS, _MOOD_MODIFIERS, and templates should be extracted
to a handler TOML when the prompt assembly handler migrates.
"""

from __future__ import annotations

import random

_DA_MODIFIERS: dict[str, float] = {
    "hostile": 1.5, "accusation": 1.4, "confession": 1.4, "flirt": 1.3,
    "emote": 0.0, "action": 0.3,
    "disagree": 1.2, "opinion": 1.1, "hedge": 1.1,
    "offer": 1.0, "intent": 1.0, "conditional": 1.0,
    "statement": 1.0, "command": 1.0, "question": 0.9, "yes_no_question": 0.8,
    "agree": 0.6, "acknowledgment": 0.5, "greeting": 0.4, "farewell": 0.4,
    "out_of_character": 0.0,
}

_MOOD_MODIFIERS: dict[str, float] = {
    "furious": 1.5, "alarmed": 1.4, "scared": 1.3, "angry": 1.3, "surprised": 1.3,
    "suspicious": 1.2, "irritated": 1.1, "troubled": 1.1, "curious": 1.1,
    "amused": 1.0, "cautious": 1.0, "confused": 1.0, "concerned": 1.0,
    "embarrassed": 1.1, "anxious": 1.2,
    "neutral": 0.8, "content": 0.8, "pleased": 0.9, "calm": 0.7,
    "bored": 0.6, "tired": 0.6, "solemn": 0.8, "distracted": 0.7,
}

_DEFAULT_MOOD_MODIFIER = 0.9


def compute_emote_probability(base_chance: float, dialogue_act: str, mood: str) -> float:
    """Compute final emote probability for this turn. Returns [0.0, 1.0]."""
    da_mod = _DA_MODIFIERS.get(dialogue_act, 1.0)
    mood_mod = _MOOD_MODIFIERS.get(mood, _DEFAULT_MOOD_MODIFIER)
    return max(0.0, min(1.0, base_chance * da_mod * mood_mod))


def should_emote(base_chance: float, dialogue_act: str, mood: str) -> bool:
    """Roll against computed probability — returns True if emote should fire."""
    return random.random() < compute_emote_probability(base_chance, dialogue_act, mood)


def build_emote_section(emote_config: dict, voice_config: dict, prompts: dict) -> str:
    """Build emote directive prompt text with physical vocabulary constraints.

    Returns prompt text or empty string if no directive needed.
    """
    emote_prompts = prompts.get("emote_directive", {})
    base_text = emote_prompts.get("instruction", "")
    if not base_text:
        return ""

    parts = [base_text]

    physical = voice_config.get("physical", {})
    repertoire = physical.get("repertoire", [])
    avoid = physical.get("avoid", [])

    if repertoire:
        repertoire_text = emote_prompts.get("repertoire_prefix", "Physical vocabulary:")
        parts.append(f"{repertoire_text} {', '.join(repertoire)}")

    if avoid:
        avoid_text = emote_prompts.get("avoid_prefix", "Never use:")
        parts.append(f"{avoid_text} {', '.join(avoid)}")

    return "\n".join(parts)
