"""Analysis handler: extract and optionally resolve player emotes.

Parses *action text* markers from player input. Two modes controlled by
params.mode (default: "extract"):

- "extract" — extract emotes, build action text from raw emotes
- "full"    — extract + classify verbs, check plausibility, attenuate
              aggression/supernatural, separate tone hints

To disable emote processing entirely, omit this handler from the pipeline.

Config: config/handlers/analysis/emote_verbs.toml (verb taxonomy + plausible items)
"""

from __future__ import annotations

import re
from dataclasses import dataclass
from typing import Optional

from pydantic import BaseModel, Field

from conjured.core.logging import get_logger
from conjured.pipeline.registry import register_handler, HandlerExample

logger = get_logger(__name__)


# ---------------------------------------------------------------------------
# Config schema — loaded and validated by runner, injected via ctx.params
# ---------------------------------------------------------------------------

class _AttenuationTemplate(BaseModel):
    verb: str
    resolved: str


class _VerbClass(BaseModel):
    description: str = ""
    resolution: str = "passthrough"
    verbs: list[str] = Field(default_factory=list)
    attenuation_templates: list[_AttenuationTemplate] = Field(default_factory=list)
    default_attenuation: str = "The player makes a dramatic gesture."


class EmoteConfig(BaseModel):
    mode: str = Field(default="extract", description="'extract' (parse only) or 'full' (+ verb classification, attenuation, tone hints)")
    plausible_items: list[str] = Field(default_factory=list, description="Flattened list of plausible object words for interact checks")
    # Verb classes — each top-level TOML section becomes a VerbClass
    gesture: _VerbClass = Field(default_factory=_VerbClass)
    expression: _VerbClass = Field(default_factory=_VerbClass)
    movement: _VerbClass = Field(default_factory=_VerbClass)
    speech_modifier: _VerbClass = Field(default_factory=_VerbClass)
    interact: _VerbClass = Field(default_factory=_VerbClass)
    aggression: _VerbClass = Field(default_factory=_VerbClass)
    supernatural: _VerbClass = Field(default_factory=_VerbClass)
    fallback: _VerbClass = Field(default_factory=lambda: _VerbClass(resolution="object_check"))

    def build_verb_map(self) -> dict[str, str]:
        """Build verb → class name lookup. Called once at config load time."""
        vm: dict[str, str] = {}
        for class_name in ("gesture", "expression", "movement", "speech_modifier",
                           "interact", "aggression", "supernatural"):
            vc = getattr(self, class_name)
            for verb in vc.verbs:
                vm[verb.lower()] = class_name
            for tmpl in vc.attenuation_templates:
                vm[tmpl.verb.lower()] = class_name
        return vm

    def build_template_map(self, class_name: str) -> dict[str, str]:
        """Build verb → resolved text lookup for attenuation classes."""
        vc = getattr(self, class_name, None)
        if vc is None:
            return {}
        return {t.verb: t.resolved for t in vc.attenuation_templates}


# ---------------------------------------------------------------------------
# Emote extraction (pure functions)
# ---------------------------------------------------------------------------

_EMOTE_PATTERN = re.compile(r"\*([^*]{3,120})\*")

_INJECTION_SIGNALS = re.compile(
    r"(ignore|disregard|forget|override|system|prompt|instruction)",
    re.IGNORECASE,
)


def extract_emotes(text: str) -> tuple[list[str], str]:
    """Extract *emote* markers from player input.

    Returns (emotes, remaining_text) where remaining_text has emotes stripped.
    Emotes that look like injection attempts are left in place (not extracted).
    """
    if not text or "*" not in text:
        return [], text

    emotes: list[str] = []
    remaining = text

    for match in _EMOTE_PATTERN.finditer(text):
        content = match.group(1).strip()
        full_match = match.group(0)

        if _INJECTION_SIGNALS.search(content):
            logger.debug("emote_extraction_skipped_injection", content=content[:50])
            continue

        emotes.append(content)
        remaining = remaining.replace(full_match, " ", 1)

    remaining = re.sub(r"\s{2,}", " ", remaining).strip()
    return emotes, remaining


def build_player_action_text(emotes: list[str]) -> str:
    """Build natural-language description of player actions from emote list."""
    if not emotes:
        return ""
    if len(emotes) == 1:
        return f"The player {emotes[0]}."
    parts = ", ".join(emotes[:-1])
    return f"The player {parts} and {emotes[-1]}."


# ---------------------------------------------------------------------------
# Emote validation (inlined from engine/emote/validation.py)
# ---------------------------------------------------------------------------

@dataclass
class EmoteResult:
    """Result of validating a single emote."""
    raw: str
    resolved_text: str
    verb_class: str
    resolution: str
    attenuated: bool = False
    tone_hint: str = ""
    object_text: str = ""

    def to_dict(self) -> dict:
        return {
            "raw": self.raw,
            "resolved_text": self.resolved_text,
            "verb_class": self.verb_class,
            "resolution": self.resolution,
            "attenuated": self.attenuated,
            "tone_hint": self.tone_hint,
            "object_text": self.object_text,
        }


def _extract_verb_and_object(emote_text: str) -> tuple[str, str]:
    """Extract root verb and direct object from emote text.

    Uses spaCy if available, falls back to first-word heuristic.
    """
    try:
        from conjured.ml.spacy import get_spacy
        nlp = get_spacy()
    except ImportError:
        nlp = None

    if nlp is not None:
        doc = nlp(emote_text)
        for token in doc:
            if token.dep_ == "ROOT" and token.pos_ == "VERB":
                verb = token.lemma_.lower()
                obj_parts = []
                for child in token.children:
                    if child.dep_ in ("dobj", "attr"):
                        obj_parts.append(child.text)
                        for gc in child.children:
                            if gc.dep_ in ("compound", "amod", "det"):
                                obj_parts.insert(0, gc.text)
                return verb, " ".join(obj_parts)

        for token in doc:
            if token.pos_ == "VERB":
                verb = token.lemma_.lower()
                obj_parts = []
                for child in token.children:
                    if child.dep_ in ("dobj", "attr"):
                        obj_parts.append(child.text)
                        for gc in child.children:
                            if gc.dep_ in ("compound", "amod", "det"):
                                obj_parts.insert(0, gc.text)
                return verb, " ".join(obj_parts)

    # Fallback: first word = verb, rest = object
    words = emote_text.strip().split()
    if words:
        return words[0].lower(), " ".join(words[1:])
    return "", ""


def _is_object_plausible(object_text: str, plausible_items: list[str]) -> bool:
    """Check if the direct object matches any plausible item word."""
    if not object_text or not plausible_items:
        return True
    plausible_set = {w.lower() for w in plausible_items}
    obj_lower = object_text.lower()
    if obj_lower in plausible_set:
        return True
    for word in obj_lower.split():
        if word in plausible_set:
            return True
    return False


def _attenuate(verb: str, config: EmoteConfig, class_name: str, emote_text: str) -> str:
    """Generate attenuated description for aggression/supernatural verbs."""
    template_map = config.build_template_map(class_name)
    template = template_map.get(verb)
    if not template:
        vc = getattr(config, class_name, None)
        template = vc.default_attenuation if vc else "The player makes a dramatic gesture."

    # Simple target extraction
    target = "you"
    words = emote_text.split()
    for i, w in enumerate(words):
        if w.lower() == "the" and i + 1 < len(words):
            target = " ".join(words[i:])
            break
        if i > 0 and w[0].isupper() and w.lower() not in ("i",):
            target = w
            break

    return template.replace("{target}", target)


def _resolve_verb(verb: str, verb_map: dict[str, str]) -> tuple[str, str]:
    """Resolve verb to (normalized_verb, class). Tries naive de-conjugation."""
    v = verb.lower()
    if v in verb_map:
        return v, verb_map[v]
    for suffix in ("s", "es", "ed", "ing"):
        stem = v[:-len(suffix)] if v.endswith(suffix) and len(v) > len(suffix) + 1 else None
        if stem and stem in verb_map:
            return stem, verb_map[stem]
    return v, "_fallback"


def _validate_emote(emote_text: str, config: EmoteConfig, verb_map: dict[str, str]) -> EmoteResult:
    """Validate a single emote and determine its resolution."""
    raw_verb, obj_text = _extract_verb_and_object(emote_text)
    verb, verb_class = _resolve_verb(raw_verb, verb_map)

    if verb_class == "_fallback":
        resolution_type = config.fallback.resolution
    else:
        vc = getattr(config, verb_class, None)
        resolution_type = vc.resolution if vc else "passthrough"

    if resolution_type == "passthrough":
        return EmoteResult(raw=emote_text, resolved_text=emote_text,
                           verb_class=verb_class, resolution="passthrough")

    if resolution_type == "scene_check":
        return EmoteResult(raw=emote_text, resolved_text=emote_text,
                           verb_class=verb_class, resolution="passthrough")

    if resolution_type == "tone_hint":
        return EmoteResult(raw=emote_text, resolved_text=emote_text,
                           verb_class=verb_class, resolution="tone_hint", tone_hint=verb)

    if resolution_type == "object_check":
        plausible = _is_object_plausible(obj_text, config.plausible_items)
        if plausible:
            return EmoteResult(raw=emote_text, resolved_text=emote_text,
                               verb_class=verb_class if verb_class != "_fallback" else "interact",
                               resolution="passthrough", object_text=obj_text)
        else:
            return EmoteResult(raw=emote_text, resolved_text=f"pantomimes {emote_text}",
                               verb_class=verb_class if verb_class != "_fallback" else "interact",
                               resolution="attenuated", attenuated=True, object_text=obj_text)

    if resolution_type in ("attenuate_physical", "attenuate_pantomime"):
        resolved = _attenuate(verb, config, verb_class, emote_text)
        return EmoteResult(raw=emote_text, resolved_text=resolved,
                           verb_class=verb_class, resolution="attenuated", attenuated=True)

    logger.warning("emote_unknown_resolution", resolution=resolution_type, verb=verb)
    return EmoteResult(raw=emote_text, resolved_text=emote_text,
                       verb_class=verb_class, resolution="passthrough")


# ---------------------------------------------------------------------------
# Output schema
# ---------------------------------------------------------------------------

class EmoteOutput(BaseModel):
    """Handler output contract. Required fields always written, optional
    fields only written in 'full' mode."""
    cleaned_input: str = Field(description="Player input with *emote* markers stripped")
    raw_emotes: list[str] = Field(description="Extracted emote strings, e.g. ['draws dagger', 'steps back']")
    player_action_text: str = Field(description="Natural language action description for the system prompt")
    emote_results: Optional[list[dict]] = Field(default=None, description="Per-emote classification/resolution details (full mode only)")
    tone_hints: Optional[list[str]] = Field(default=None, description="Speech modifier hints like 'whisper', 'shout' (full mode only)")
    any_attenuated: Optional[bool] = Field(default=None, description="Whether any emote was rewritten for plausibility (full mode only)")


# ---------------------------------------------------------------------------
# Handler
# ---------------------------------------------------------------------------

@register_handler(
    "process_emotes",
    category="analysis",
    reads=["player_input"],
    schema=EmoteOutput,
    params_schema=EmoteConfig,
    description="Extract *emote* markers, optionally classify and resolve",
    tags=["security", "prompt_shaping"],
    example=HandlerExample(
        inputs={"player_input": "*draws dagger* I don't trust you"},
        outputs={"cleaned_input": "I don't trust you", "raw_emotes": ["draws dagger"]},
        description="Extracts asterisk-wrapped emotes, returns cleaned text",
    ),
)
def process_emotes(ctx):
    """Extract emotes from player input, optionally validate and resolve.

    Reads:
        player_input: str — raw player message (required)

    Params:
        mode: str — "extract" or "full" (default "extract")
        (full mode also uses verb taxonomy and plausible_items from params)

    Writes (always):
        cleaned_input: str — input with emotes stripped
        raw_emotes: list[str] — extracted emote strings
        player_action_text: str — natural language action description for prompt

    Writes (full mode only):
        emote_results: list[dict] — per-emote classification/resolution details
        tone_hints: list[str] — speech modifier hints (e.g. "whisper")
        any_attenuated: bool — whether any emote was rewritten
    """
    text = ctx.read("player_input")
    config = ctx.params

    emotes, remaining = extract_emotes(text)

    if not emotes:
        ctx.write("cleaned_input", text)
        ctx.write("raw_emotes", [])
        ctx.write("player_action_text", "")
        return

    # Emote-only input: inject ellipsis so downstream NLP has valid text
    if not remaining:
        remaining = "..."

    ctx.write("cleaned_input", remaining)
    ctx.write("raw_emotes", emotes)

    if config.mode == "full":
        verb_map = config.build_verb_map()
        results = [_validate_emote(e, config, verb_map) for e in emotes]

        tone_hints = [r.tone_hint for r in results if r.tone_hint]
        resolved_emotes = [r.resolved_text for r in results if r.resolution != "tone_hint"]
        action_text = build_player_action_text(resolved_emotes) if resolved_emotes else ""

        ctx.write("player_action_text", action_text)
        ctx.write("emote_results", [r.to_dict() for r in results])
        ctx.write("tone_hints", tone_hints)
        ctx.write("any_attenuated", any(r.attenuated for r in results))

        logger.debug("emote_validated", mode="full", count=len(emotes),
                     attenuated=any(r.attenuated for r in results),
                     tone_hints=tone_hints)
    else:
        ctx.write("player_action_text", build_player_action_text(emotes))
        logger.debug("emote_extracted", mode="extract", count=len(emotes))
