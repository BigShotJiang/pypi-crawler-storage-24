"""Analysis handler: DA-injected response length hints.

Reads the dialogue act classification from context and writes a
response length instruction that gets included in the prompt.

Config: config/handlers/analysis/length_hints.toml
"""

from pydantic import BaseModel, Field

from conjured.pipeline.registry import register_handler, HandlerExample


# ---------------------------------------------------------------------------
# Schemas
# ---------------------------------------------------------------------------

class LengthHintOutput(BaseModel):
    length_hint: str = Field(description="Response length instruction, e.g. 'Respond in 2-3 sentences.'")


class LengthHintConfig(BaseModel):
    defaults: dict[str, str] = Field(default_factory=dict, description="Fallback hints by category (expertise, multi_segment, unknown)")
    hints: dict[str, str] = Field(default_factory=dict, description="DA label → length hint mapping")


# ---------------------------------------------------------------------------
# Handler
# ---------------------------------------------------------------------------

@register_handler(
    "enrich_length_hint",
    category="analysis",
    reads=["dialogue_act"],
    optional_reads=["dialogue_acts", "is_expertise_question"],
    schema=LengthHintOutput,
    params_schema=LengthHintConfig,
    description="DA-injected response length instruction",
    tags=["prompt_shaping"],
    example=HandlerExample(
        inputs={"dialogue_act": "question"},
        outputs={"length_hint": "Respond in 2-3 sentences."},
        description="Question DA maps to medium-length response",
    ),
)
def enrich_length_hint(ctx):
    """Look up length hint from DA classification and write to context.

    Reads:
        dialogue_act: str — primary dialogue act classification (required)
        dialogue_acts: list[str] | None — per-segment DAs for multi-segment input (optional)
        is_expertise_question: bool — whether the query hits NPC expertise (optional)

    Writes:
        length_hint: str — instruction like "Respond in 2-3 sentences."
    """
    config = ctx.params

    da = ctx.read("dialogue_act")
    dialogue_acts = ctx.read("dialogue_acts")
    is_expertise = ctx.read("is_expertise_question")

    if is_expertise:
        ctx.write("length_hint", config.defaults.get("expertise", "Respond in 3-5 sentences."))
    elif dialogue_acts and len(dialogue_acts) > 1:
        ctx.write("length_hint", config.defaults.get("multi_segment", "Respond in 3-5 sentences."))
    else:
        hint = config.hints.get(da, config.defaults.get("unknown", "Respond in 2-3 sentences."))
        ctx.write("length_hint", hint)
