"""Pydantic schemas for structured LLM output.

Used by the generation handler to enforce JSON structure via the
``format`` parameter (GBNF/json_schema grammar enforcement).
"""

from pydantic import BaseModel


class NPCResponse(BaseModel):
    """NPC dialogue response schema — enforced via GBNF at generation time."""
    dialogue: str
    action: str = ""
    addressed_to: str = "player"
    ik_detected: bool = False
    conversation_ending: bool = False
    events: list[dict] = []


class JudgeMemory(BaseModel):
    """Single memory from the post-conversation judge."""
    fact: str
    emotion: str
    emotional_weight: str = ""
    type: str = "observation"


class JudgeRelationship(BaseModel):
    """Relationship score output from the judge."""
    familiarity: float = 5.0
    trust: float = 5.0
    respect: float = 5.0


class JudgeResponse(BaseModel):
    """Post-conversation judge output — memories + relationship + summary."""
    memories: list[JudgeMemory] = []
    relationship: JudgeRelationship = JudgeRelationship()
    summary: str = ""


class ExtractionResponse(BaseModel):
    """Extraction pass schema — inner_thought first for chain-of-thought reasoning."""
    inner_thought: str = ""
    dialogue: str = ""
    events: list[dict] = []
    action: str = ""
    addressed_to: str = "player"
    topics: list[str] = []
    npc_claims: list[str] = []


def build_extraction_schema(scene: dict) -> dict:
    """Build a JSON schema for the extraction pass, including scene extensions.

    Same extension-injection logic as ``build_response_schema`` but uses
    ``ExtractionResponse`` which includes ``inner_thought`` for chain-of-thought.
    """
    schema = ExtractionResponse.model_json_schema()

    for ext in scene.get("output_extensions", []):
        name = ext["name"]
        ext_type = ext.get("type", "string")
        json_type = {
            "string": "string",
            "int": "integer",
            "integer": "integer",
            "float": "number",
            "bool": "boolean",
            "boolean": "boolean",
        }.get(ext_type, "string")
        schema["properties"][name] = {"type": json_type}

    return schema


def build_response_schema(scene: dict) -> dict:
    """Build a JSON schema for NPCResponse, dynamically adding scene extensions.

    Scene ``output_extensions`` (e.g. suspicion_delta, mood_shift) are added as
    optional properties on the base schema so the model can produce them.
    """
    schema = NPCResponse.model_json_schema()

    for ext in scene.get("output_extensions", []):
        name = ext["name"]
        ext_type = ext.get("type", "string")
        json_type = {
            "string": "string",
            "int": "integer",
            "float": "number",
            "bool": "boolean",
        }.get(ext_type, "string")
        schema["properties"][name] = {"type": json_type}

    return schema
