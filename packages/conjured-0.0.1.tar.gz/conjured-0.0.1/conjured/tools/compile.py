"""Artifact compilation — build tool for pre-processing game config.

Content-hashed staleness detection: recompiles only when source configs
change. Called by bootstrap.py --sync and the CLI.

Usage:
    python -m conjured.tools.compile           # recompile stale only
    python -m conjured.tools.compile --force   # recompile all
    python -m conjured.tools.compile --check   # dry run — report staleness
    python -m conjured.tools.compile --list    # list registered artifacts
"""

from __future__ import annotations

import hashlib
import json
import time
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path

from conjured.core.artifacts import ARTIFACTS, COMPILED_DIR
from conjured.core.logging import get_logger

logger = get_logger(__name__)

MANIFEST_PATH = COMPILED_DIR / "manifest.json"


# ---------------------------------------------------------------------------
# Data structures
# ---------------------------------------------------------------------------

@dataclass
class ManifestEntry:
    """Persisted state for a single compiled artifact."""
    source_hash: str
    compiled_at: str  # ISO 8601
    version: int = 1


# ---------------------------------------------------------------------------
# Content hashing
# ---------------------------------------------------------------------------

def hash_files(paths: list[Path]) -> str:
    """Compute SHA256 hex digest from sorted file paths + contents."""
    h = hashlib.sha256()
    for p in sorted(paths):
        h.update(str(p).encode())
        if p.exists():
            h.update(p.read_bytes())
    return h.hexdigest()


def hash_files_and_params(*extra: str, paths: list[Path]) -> str:
    """Hash files plus additional string parameters (e.g. model name)."""
    h = hashlib.sha256()
    for ex in extra:
        h.update(ex.encode())
    for p in sorted(paths):
        h.update(str(p).encode())
        if p.exists():
            h.update(p.read_bytes())
    return h.hexdigest()


# ---------------------------------------------------------------------------
# Manifest I/O
# ---------------------------------------------------------------------------

def _load_manifest() -> dict[str, ManifestEntry]:
    """Load manifest.json. Returns empty dict if missing or corrupt."""
    if not MANIFEST_PATH.exists():
        return {}
    try:
        with open(MANIFEST_PATH) as f:
            raw = json.load(f)
        return {k: ManifestEntry(**v) for k, v in raw.items()}
    except (json.JSONDecodeError, TypeError, KeyError):
        logger.warning("manifest_corrupt", path=str(MANIFEST_PATH))
        return {}


def _save_manifest(manifest: dict[str, ManifestEntry]) -> None:
    """Write manifest.json atomically (write tmp then rename)."""
    COMPILED_DIR.mkdir(parents=True, exist_ok=True)
    data = {
        k: {
            "source_hash": v.source_hash,
            "compiled_at": v.compiled_at,
            "version": v.version,
        }
        for k, v in manifest.items()
    }
    tmp = MANIFEST_PATH.with_suffix(".tmp")
    with open(tmp, "w") as f:
        json.dump(data, f, indent=2)
    tmp.replace(MANIFEST_PATH)


# ---------------------------------------------------------------------------
# Staleness detection
# ---------------------------------------------------------------------------

def is_stale(name: str) -> bool:
    """Check if an artifact needs recompilation."""
    if name not in ARTIFACTS:
        raise ValueError(f"Unknown artifact: {name}. Registered: {list(ARTIFACTS.keys())}")

    manifest = _load_manifest()
    entry = manifest.get(name)
    if entry is None:
        return True

    current_hash = ARTIFACTS[name].compiler.source_hash()
    return current_hash != entry.source_hash


# ---------------------------------------------------------------------------
# Compilation
# ---------------------------------------------------------------------------

def compile_artifact(name: str, force: bool = False) -> bool:
    """Compile a single artifact. Returns True if compilation occurred."""
    if name not in ARTIFACTS:
        raise ValueError(f"Unknown artifact: {name}. Registered: {list(ARTIFACTS.keys())}")

    meta = ARTIFACTS[name]

    if not force and not is_stale(name):
        logger.info("compile_skip", artifact=name, reason="up_to_date")
        return False

    COMPILED_DIR.mkdir(parents=True, exist_ok=True)

    t = time.perf_counter()
    try:
        meta.compiler.compile(COMPILED_DIR)
    except Exception:
        logger.exception("compile_failed", artifact=name)
        raise

    elapsed_ms = round((time.perf_counter() - t) * 1000)

    manifest = _load_manifest()
    manifest[name] = ManifestEntry(
        source_hash=meta.compiler.source_hash(),
        compiled_at=datetime.now(timezone.utc).isoformat(),
    )
    _save_manifest(manifest)

    with meta._lock:
        meta._instance = None

    logger.info("compile_done", artifact=name, elapsed_ms=elapsed_ms)
    return True


def compile_all(force: bool = False) -> dict[str, bool]:
    """Compile all registered artifacts. Returns {name: was_compiled}."""
    results = {}
    for name in ARTIFACTS:
        results[name] = compile_artifact(name, force=force)
    return results


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------

def main():
    """CLI entry point for python -m conjured.tools.compile."""
    import argparse
    from conjured.core.logging import configure_logging
    configure_logging()

    parser = argparse.ArgumentParser(
        prog="python -m conjured.tools.compile",
        description="Compile dialogue artifacts from game config.",
    )
    parser.add_argument("--force", action="store_true",
                        help="Recompile all artifacts regardless of staleness.")
    parser.add_argument("--check", action="store_true",
                        help="Dry run: report staleness without compiling.")
    parser.add_argument("--list", action="store_true", dest="list_artifacts",
                        help="List all registered artifacts.")
    args = parser.parse_args()

    if args.list_artifacts:
        print(f"Registered artifacts ({len(ARTIFACTS)}):")
        for name in ARTIFACTS:
            stale = is_stale(name)
            status = "STALE" if stale else "up-to-date"
            print(f"  {name:30s} [{status}]")
        return

    if args.check:
        print("Staleness check:")
        any_stale = False
        for name in ARTIFACTS:
            stale = is_stale(name)
            if stale:
                any_stale = True
            status = "STALE - needs recompile" if stale else "up-to-date"
            print(f"  {name:30s} [{status}]")
        if not any_stale:
            print("\nAll artifacts are up to date.")
        return

    results = compile_all(force=args.force)
    compiled_count = sum(1 for v in results.values() if v)
    skipped_count = sum(1 for v in results.values() if not v)
    print(f"\nCompilation complete: {compiled_count} compiled, {skipped_count} skipped.")


if __name__ == "__main__":
    main()
