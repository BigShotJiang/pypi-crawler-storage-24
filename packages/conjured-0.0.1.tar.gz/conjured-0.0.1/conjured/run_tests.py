"""Test runner — discovers and runs all tests in src/tests/.

Tests mirror the conjured/ package structure:
    src/tests/core/test_logging.py          tests conjured.core.logging
    src/tests/handlers/enrich/test_x.py     tests conjured.handlers.enrich.x

Does not reach outside src/.

Usage:
    python src/conjured/run_tests.py                              # all tests
    python src/conjured/run_tests.py src/tests/core/              # one dir
    python src/conjured/run_tests.py src/tests/core/test_logging.py  # one file
    python src/conjured/run_tests.py -k "test_foo"                # pass-through

Output captured to src/conjured/.last_run.txt. Kills zombies on timeout.
"""

import os
import subprocess
import sys
import time

# src/conjured/run_tests.py → parent = src/conjured/
PACKAGE_DIR = os.path.dirname(os.path.abspath(__file__))
# src/conjured/ → parent = src/
SRC_DIR = os.path.dirname(PACKAGE_DIR)
TESTS_DIR = os.path.join(SRC_DIR, "tests")
RESULTS_FILE = os.path.join(PACKAGE_DIR, ".last_run.txt")
TOTAL_TIMEOUT = 30


def _kill_process_tree(pid):
    """Kill a process and all its children (Windows)."""
    try:
        subprocess.run(
            ["taskkill", "/F", "/T", "/PID", str(pid)],
            stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
        )
    except Exception:
        pass


def main():
    args = sys.argv[1:]

    if args:
        test_paths = args
    else:
        if not os.path.isdir(TESTS_DIR):
            print(f"No tests directory found at {TESTS_DIR}")
            sys.exit(1)
        test_paths = [TESTS_DIR]

    # PYTHONPATH must include src/ so conjured imports work
    env = os.environ.copy()
    env["PYTHONPATH"] = SRC_DIR + os.pathsep + env.get("PYTHONPATH", "")

    cmd = [sys.executable, "-u", "-m", "pytest", "--tb=short"] + test_paths

    with open(RESULTS_FILE, "w", encoding="utf-8") as log:
        log.write(f"Running: {' '.join(cmd)}\n\n")
        log.flush()

        start = time.time()
        proc = subprocess.Popen(
            cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
            cwd=SRC_DIR, text=True, env=env,
        )

        try:
            stdout, _ = proc.communicate(timeout=TOTAL_TIMEOUT)
            elapsed = time.time() - start
            log.write(stdout)
            log.write(f"\nCompleted in {elapsed:.1f}s (exit {proc.returncode})\n")

            for line in stdout.strip().splitlines()[-3:]:
                print(line)
            print(f"  ({elapsed:.1f}s) Full output: src/conjured/.last_run.txt")

            sys.exit(proc.returncode)

        except subprocess.TimeoutExpired:
            elapsed = time.time() - start
            _kill_process_tree(proc.pid)
            proc.wait()
            log.write(f"\n*** TIMEOUT after {elapsed:.1f}s ***\n")
            print(f"TIMEOUT after {elapsed:.1f}s")
            sys.exit(1)


if __name__ == "__main__":
    main()
