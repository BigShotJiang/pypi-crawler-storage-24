"""PipelineContext construction for tests.

Provides make_handler_context() — the only way tests should create
a PipelineContext. Returns a HandlerTestContext that wraps PipelineContext
with test-only inspection methods (read_output, has_output, output_keys).

The real PipelineContext has NO inspection backdoors — handlers can only
access keys via read()/write() with contract enforcement.
"""

from __future__ import annotations

from typing import Any

from conjured.pipeline.context import PipelineContext


class HandlerTestContext(PipelineContext):
    """PipelineContext subclass with test-only output inspection.

    Adds read_output(), has_output(), output_keys() for asserting handler
    writes without bypassing production contract enforcement. These methods
    are only available in test code — production PipelineContext doesn't
    have them.

    All PipelineContext methods (read, write, _set_active_handler, etc.)
    work unchanged.
    """

    def read_output(self, key: str, default: Any = None) -> Any:
        """Read a handler's output for test assertions (no contract check)."""
        return self._data.get(key, default)

    def has_output(self, key: str) -> bool:
        """Check if a handler wrote a key (no contract check)."""
        return key in self._data

    def output_keys(self) -> set[str]:
        """All keys currently in context."""
        return set(self._data.keys())


def make_handler_context(**data) -> HandlerTestContext:
    """Create a HandlerTestContext seeded with test data.

    Usage:
        ctx = make_handler_context(
            npc_config={"npc": {"name": "Test"}},
            query="hello",
            scene={"location_description": "A room"},
        )

    All keys are written via _force_write (bypass enforcement).
    The handler under test then accesses them via ctx.read().
    Assert outputs via ctx.read_output() / ctx.has_output().
    """
    ctx = HandlerTestContext()
    for k, v in data.items():
        ctx._force_write(k, v)
    return ctx
