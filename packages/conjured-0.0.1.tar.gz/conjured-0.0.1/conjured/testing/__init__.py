"""Test utilities for conjured — shared across all test suites.

NOT shipped to end users. Excluded from builds via pyproject.toml.

Usage:
    from conjured.testing import make_handler_context, load_test_npc
    from conjured.testing.fixtures import mock_ml_models
"""