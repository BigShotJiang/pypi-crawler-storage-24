"""Shared test fixtures — ML mocking, fake embeddings, common data.

These replace the monolithic tests/conftest.py patching. Import
what you need in each package's conftest.py.
"""

import pytest

FAKE_EMBEDDING = [0.1] * 384


def fake_embed(text):
    """Deterministic embedding for tests — no real model loaded."""
    import hashlib
    seed = int(hashlib.md5(text.encode()).hexdigest()[:8], 16)
    return [((seed + i) % 1000) / 1000.0 for i in range(384)]


@pytest.fixture
def mock_embeddings(monkeypatch):
    """Patch embedding model to return fake vectors."""
    monkeypatch.setattr(
        "conjured.ml.embeddings.get_embedding", fake_embed
    )
