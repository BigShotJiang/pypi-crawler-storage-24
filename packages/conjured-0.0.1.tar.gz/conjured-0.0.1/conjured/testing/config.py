"""Test config loading — singleton master configs.

Loads from conjured/config/ — the single source of truth.
Tests use the same configs the engine ships with.

Tests must NOT modify the returned dicts. If a test needs a field
that the master config doesn't have, the config is incomplete
and should be updated — the test failure is the signal.
"""

import tomllib
from pathlib import Path

_CONFIG_DIR = Path(__file__).parent.parent / "config"


def load_test_npc() -> dict:
    """Load the master NPC config. One config, no key parameter."""
    path = _CONFIG_DIR / "handlers" / "import" / "example_npc.toml"
    with open(path, "rb") as f:
        return tomllib.load(f)


def load_test_scene() -> dict:
    """Load the master scene config. One config, no key parameter."""
    path = _CONFIG_DIR / "handlers" / "import" / "example_scene.toml"
    with open(path, "rb") as f:
        return tomllib.load(f)


def load_test_pipeline() -> dict:
    """Load the master pipeline config. One config, no key parameter."""
    path = _CONFIG_DIR / "pipelines" / "example_pipeline.toml"
    with open(path, "rb") as f:
        return tomllib.load(f)
