"""PipelineContext — typed accumulator with contract enforcement.

Handlers declare reads/optional_reads (inputs) and a Pydantic schema
(outputs). The registry derives writes/optional_writes from the schema.
The runner sets allowed keys before each handler call. read()/write()
enforce contracts at runtime.

Handler config is accessed via ctx.params (validated Pydantic instance).

Design doc: docs/dev/design/pipeline_v2.md
"""

from __future__ import annotations

from typing import Any


class ContractViolation(Exception):
    """Raised when a handler accesses a context key outside its contract."""
    pass


class PipelineContext:
    """Typed accumulator — grows as handlers add to it.

    Handlers can only access keys they declared. The runner calls
    _set_active_handler() before each handler to set allowed keys,
    and _set_params() to inject validated config.

    read() behavior:
        - Key not in declared reads or optional_reads → ContractViolation
        - Key in reads but not yet written → ContractViolation (required)
        - Key in optional_reads but not yet written → returns None
        - Key declared and written → returns value

    write() behavior:
        - Key not in declared writes or optional_writes → ContractViolation
        - Key in writes or optional_writes → stores value

    params: Validated Pydantic instance of handler config. Set by runner
        before each handler, cleared after. None if handler has no params_schema.
    """

    __slots__ = ("_data", "_active_reads", "_active_optional_reads",
                 "_active_writes", "_active_optional_writes", "_params")

    def __init__(self):
        object.__setattr__(self, "_data", {})
        object.__setattr__(self, "_active_reads", None)
        object.__setattr__(self, "_active_optional_reads", None)
        object.__setattr__(self, "_active_writes", None)
        object.__setattr__(self, "_active_optional_writes", None)
        object.__setattr__(self, "_params", None)

    def _set_active_handler(self, reads: list[str], writes: list[str],
                            optional_reads: list[str] = None,
                            optional_writes: list[str] = None) -> None:
        """Called by the runner before each handler to set allowed keys."""
        object.__setattr__(self, "_active_reads", set(reads))
        object.__setattr__(self, "_active_optional_reads", set(optional_reads or []))
        object.__setattr__(self, "_active_writes", set(writes))
        object.__setattr__(self, "_active_optional_writes", set(optional_writes or []))

    def _set_params(self, params: Any) -> None:
        """Called by the runner to inject validated handler config."""
        object.__setattr__(self, "_params", params)

    def _clear_active_handler(self) -> None:
        """Called by the runner after each handler."""
        object.__setattr__(self, "_active_reads", None)
        object.__setattr__(self, "_active_optional_reads", None)
        object.__setattr__(self, "_active_writes", None)
        object.__setattr__(self, "_active_optional_writes", None)
        object.__setattr__(self, "_params", None)

    @property
    def params(self) -> Any:
        """Handler config — validated Pydantic instance, set by runner."""
        return self._params

    def read(self, key: str) -> Any:
        """Read a context key.

        Raises ContractViolation if:
            - key not in declared reads or optional_reads
            - key in required reads but not yet written

        Returns None if key is in optional_reads but not yet written.
        """
        all_allowed = set()
        if self._active_reads is not None:
            all_allowed = self._active_reads | self._active_optional_reads

        if all_allowed and key not in all_allowed:
            raise ContractViolation(
                f"Handler tried to read '{key}' but it's not in declared reads. "
                f"Allowed: {sorted(all_allowed)}"
            )

        if key not in self._data:
            # Optional read — return None
            if self._active_optional_reads and key in self._active_optional_reads:
                return None
            # Required read — raise
            raise ContractViolation(
                f"Handler tried to read '{key}' but no prior handler has written it."
            )

        return self._data[key]

    def write(self, key: str, value: Any) -> None:
        """Write a context key. Raises ContractViolation if not declared in writes or optional_writes."""
        if self._active_writes is not None:
            all_allowed = self._active_writes | self._active_optional_writes
            if key not in all_allowed:
                raise ContractViolation(
                    f"Handler tried to write '{key}' but it's not in declared writes. "
                    f"Allowed: {sorted(all_allowed)}"
                )
        self._data[key] = value

    def _force_write(self, key: str, value: Any) -> None:
        """Bypass enforcement — used by the runner for initial seeding."""
        self._data[key] = value

    def __getattr__(self, name: str) -> Any:
        """Block direct field access — forces handlers to use read()."""
        raise AttributeError(
            f"PipelineContext has no attribute '{name}'. "
            f"Use ctx.read('{name}') instead."
        )
