"""
Handler registry — flat name→meta mapping for the composable pipeline.

Handlers register by name with declared contracts. Every handler must have
a schema (Pydantic BaseModel) that defines its outputs. The registry derives
writes/optional_writes from the schema's fields.

Usage:
    from conjured.pipeline.registry import register_handler, get_handler

    class EmotionOutput(BaseModel):
        mood: str = Field(description="Current emotional state")
        emotional_blend: list[float] = Field(description="Weighted emotion vector")

    @register_handler("emotion_robust",
                      category="analysis",
                      reads=["npc_config", "player_input"],
                      schema=EmotionOutput,
                      description="Mood determination from DA + sentiment")
    def emotion_robust(ctx):
        ...

    meta = get_handler("emotion_robust")  # returns HandlerMeta
    meta.fn(ctx)                          # call the handler
"""

from dataclasses import dataclass, field
from typing import Any, Callable


def _derive_writes_from_schema(schema: type) -> tuple[list[str], list[str]]:
    """Split a Pydantic model's fields into required and optional writes.

    Required fields (no default) → writes (handler guarantees these).
    Optional fields (has default) → optional_writes (handler may produce these).

    This is the single source of truth: the schema defines what the handler
    writes, and the registry derives the contract from it.

    Returns (writes, optional_writes).
    """
    if not hasattr(schema, "model_fields"):
        raise TypeError(f"schema must be a Pydantic BaseModel, got {schema}")

    writes = []
    optional_writes = []
    for name, field_info in schema.model_fields.items():
        if field_info.is_required():
            writes.append(name)
        else:
            optional_writes.append(name)
    return writes, optional_writes


@dataclass
class HandlerExample:
    """Structured input→output example for editor tooltips and docs.

    Machine-readable: the editor can render inputs/outputs consistently
    and validate that example keys match the handler's reads/writes.
    """
    inputs: dict[str, Any]
    outputs: dict[str, Any]
    description: str = ""


@dataclass
class HandlerMeta:
    """Metadata for a registered handler.

    Attributes:
        fn: The handler callable.
        category: Functional group (analysis, knowledge, prompt, generation,
            state, result, import). Display label for UI grouping, not execution order.
        reads: Context keys this handler requires (must be written by a prior handler).
        optional_reads: Context keys this handler can use if available (returns None if missing).
        writes: Context keys this handler guarantees it will produce. Derived from schema.
        optional_writes: Context keys this handler may produce depending on config/mode.
            Derived from schema (fields with defaults). Pipeline editor shows as dashed lines.
        schema: Pydantic model whose fields define the handler's outputs.
            Required fields → writes. Optional fields (default value) → optional_writes.
            All fields must have Field(description="...").
            Also used for LLM format enforcement on generate handlers.
        params_schema: Optional Pydantic model declaring handler config params.
            The runner validates TOML config + pipeline inline overrides against this
            schema, then injects the validated instance via ctx._set_params().
            Handlers access config via ctx.params (typed, autocomplete-friendly).
        required_config_fields: Dotted paths into config files this handler needs
            (e.g. "npc.engagement.engagement_limit"). Validated at pipeline load time.
        swallow_errors: If True, handler failure is logged but doesn't break the pipeline.
        description: Human-readable one-line purpose.
        tags: Freeform labels for filtering/grouping (e.g. ["requires_db", "slow", "rag"]).
        example: Structured input→output snapshot for editor tooltips and docs.
        cacheable: If True, runner may cache this handler's output per session.
        parallel_group: Handlers sharing a group can run concurrently when reads/writes don't conflict.
    """
    fn: Callable
    category: str = ""
    reads: list[str] = field(default_factory=list)
    optional_reads: list[str] = field(default_factory=list)
    writes: list[str] = field(default_factory=list)
    optional_writes: list[str] = field(default_factory=list)
    schema: type | None = None
    params_schema: type | None = None
    required_config_fields: list[str] = field(default_factory=list)
    swallow_errors: bool = False
    description: str = ""
    tags: list[str] = field(default_factory=list)
    example: HandlerExample | None = None
    cacheable: bool = False
    parallel_group: str | None = None


# Flat registry: handler_name → HandlerMeta
HANDLERS: dict[str, HandlerMeta] = {}


def register_handler(name: str, *, category: str = "", reads: list[str] | None = None,
                     optional_reads: list[str] | None = None, schema: type,
                     params_schema: type | None = None,
                     required_config_fields: list[str] | None = None,
                     swallow_errors: bool = False,
                     description: str = "", tags: list[str] | None = None,
                     example: HandlerExample | None = None, cacheable: bool = False,
                     parallel_group: str | None = None):
    """Decorator that registers a handler function by name.

    schema is required — it defines the handler's output contract. Required
    Pydantic fields → writes, optional fields → optional_writes.

    params_schema is optional — declares handler config. The runner validates
    TOML + pipeline inline overrides against it and injects via ctx._set_params().

    Usage:
        @register_handler("retrieve_knowledge",
                          category="knowledge",
                          reads=["npc_config", "player_input", "scene"],
                          optional_reads=["entity_tags"],
                          schema=KnowledgeOutput,
                          params_schema=KnowledgeConfig,
                          description="RAG retrieval + obstruction filter",
                          example=HandlerExample(
                              inputs={"player_input": "Tell me about the signal"},
                              outputs={"knowledge_sections": ["The VLF signal was first detected..."]},
                              description="Retrieves relevant knowledge for a lore question",
                          ))
        def retrieve_knowledge(ctx):
            limit = ctx.params.retrieval_limit  # typed, validated
            ...
    """
    def decorator(fn: Callable) -> Callable:
        if name in HANDLERS:
            raise ValueError(f"Handler '{name}' is already registered. Names must be unique.")

        resolved_writes, resolved_optional_writes = _derive_writes_from_schema(schema)

        if params_schema is not None and not hasattr(params_schema, "model_fields"):
            raise TypeError(
                f"Handler '{name}': params_schema must be a Pydantic BaseModel, got {params_schema}"
            )

        HANDLERS[name] = HandlerMeta(
            fn=fn,
            category=category,
            reads=reads or [],
            optional_reads=optional_reads or [],
            writes=resolved_writes,
            optional_writes=resolved_optional_writes,
            schema=schema,
            params_schema=params_schema,
            required_config_fields=required_config_fields or [],
            swallow_errors=swallow_errors,
            description=description,
            tags=tags or [],
            example=example,
            cacheable=cacheable,
            parallel_group=parallel_group,
        )
        return fn
    return decorator


def get_handler(name: str) -> HandlerMeta | None:
    """Look up a handler by name. Returns None if not found."""
    return HANDLERS.get(name)


def get_handler_fn(name: str) -> Callable | None:
    """Get just the callable for a handler. Returns None if not found."""
    meta = HANDLERS.get(name)
    return meta.fn if meta else None


_handlers_loaded = False


def ensure_handlers_loaded():
    """Import all handler modules to trigger @register_handler decorators.

    Safe to call multiple times — imports only once. Each handler module
    is listed explicitly so renames break loudly.
    """
    global _handlers_loaded
    if _handlers_loaded:
        return
    from conjured.handlers.analysis import length_hint  # noqa: F401
    from conjured.handlers.analysis import process_emotes  # noqa: F401
    _handlers_loaded = True


def reset_registry():
    """Clear all registered handlers. Test use only."""
    global _handlers_loaded
    HANDLERS.clear()
    _handlers_loaded = False
