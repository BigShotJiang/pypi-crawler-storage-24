"""Semantic cache for NPC responses — FAISS-based nearest-neighbor lookup.

Stores recent (query_embedding, context_hash) -> response pairs per NPC.
Cache is session-scoped: lives in session state, lost on session end.

Usage:
    from conjured.memory.semantic_cache import SemanticCache, compute_context_hash, is_stateless

    cache = SemanticCache.from_session(session, npc_key, params)
    hit = cache.lookup(query_embedding, context_hash, threshold)
    if hit:
        return hit

    # After generation:
    cache.store(query_embedding, context_hash, response_data)
    cache.save_to_session(session, npc_key)

TODO: _STATELESS_ACTS and context_hash_fields should be TOML config
when the generation handler migrates.
"""

from __future__ import annotations

import hashlib

from conjured.core.logging import get_logger

logger = get_logger(__name__)

# Dialogue acts that are context-independent (cache doesn't need context hash match)
_STATELESS_ACTS = frozenset({
    "greeting", "farewell", "acknowledgment", "agree", "disagree",
    "out_of_character",
})


def is_stateless(dialogue_act: str | list[str]) -> bool:
    """Check if a dialogue act (or any act in a list) is stateless."""
    if isinstance(dialogue_act, list):
        return any(act in _STATELESS_ACTS for act in dialogue_act)
    return dialogue_act in _STATELESS_ACTS


def compute_context_hash(npc_state: dict, session: dict, params: dict) -> str:
    """Hash relevant context fields for cache validity."""
    fields = params.get("context_hash_fields", ["mood", "familiarity_bucket", "trust_bucket"])
    parts = []
    for field in fields:
        if field == "mood":
            parts.append(str(npc_state.get("current_mood", "")))
        elif field == "familiarity_bucket":
            fam = float(npc_state.get("familiarity", 0.0))
            parts.append(str(int(fam * 10)))
        elif field == "trust_bucket":
            trust = float(npc_state.get("trust", 0.0))
            parts.append(str(int(trust * 10)))
        elif field == "respect_bucket":
            resp = float(npc_state.get("respect", 0.0))
            parts.append(str(int(resp * 10)))
    return hashlib.md5("|".join(parts).encode()).hexdigest()[:8]


def _session_key(npc_key: str) -> str:
    return f"_semantic_cache_{npc_key}"


class SemanticCache:
    """Session-scoped semantic cache backed by FAISS IndexFlatIP."""

    def __init__(self, embeddings: list, context_hashes: list,
                 responses: list, turn_counter: int = 0,
                 max_entries: int = 200, ttl_turns: int = 50):
        self.embeddings: list[list[float]] = embeddings
        self.context_hashes: list[str] = context_hashes
        self.responses: list[dict] = responses
        self.turn_counter: int = turn_counter
        self.max_entries: int = max_entries
        self.ttl_turns: int = ttl_turns

    @classmethod
    def from_session(cls, session: dict, npc_key: str, params: dict) -> SemanticCache:
        """Load cache from session state, or create empty."""
        key = _session_key(npc_key)
        data = session.get(key, {})
        return cls(
            embeddings=list(data.get("embeddings", [])),
            context_hashes=list(data.get("context_hashes", [])),
            responses=list(data.get("responses", [])),
            turn_counter=data.get("turn_counter", 0),
            max_entries=params.get("max_entries_per_npc", 200),
            ttl_turns=params.get("ttl_turns", 50),
        )

    def save_to_session(self, session: dict, npc_key: str) -> None:
        """Persist cache state to session dict."""
        key = _session_key(npc_key)
        session[key] = {
            "embeddings": self.embeddings,
            "context_hashes": self.context_hashes,
            "responses": self.responses,
            "turn_counter": self.turn_counter,
        }

    def lookup(self, query_embedding: list[float], context_hash: str,
               threshold: float, stateless: bool = False) -> dict | None:
        """Find a cached response matching the query.

        Returns response dict with added similarity key, or None.
        """
        if not self.embeddings:
            return None

        import faiss
        import numpy as np

        vectors = np.array(self.embeddings, dtype=np.float32)
        index = faiss.IndexFlatIP(vectors.shape[1])
        index.add(vectors)

        query = np.array([query_embedding], dtype=np.float32)
        scores, indices = index.search(query, min(5, len(self.embeddings)))

        for i in range(len(indices[0])):
            idx = int(indices[0][i])
            score = float(scores[0][i])

            if idx < 0 or score < threshold:
                continue

            entry_turn = self.responses[idx].get("turn_num", 0)
            if self.turn_counter - entry_turn > self.ttl_turns:
                continue

            if not stateless and self.context_hashes[idx] != context_hash:
                continue

            result = dict(self.responses[idx])
            result["similarity"] = score
            return result

        return None

    def best_similarity(self, query_embedding: list[float], context_hash: str,
                        stateless: bool = False) -> float | None:
        """Return the highest similarity score in the cache for calibration logging."""
        if not self.embeddings:
            return None

        import faiss
        import numpy as np

        vectors = np.array(self.embeddings, dtype=np.float32)
        index = faiss.IndexFlatIP(vectors.shape[1])
        index.add(vectors)

        query = np.array([query_embedding], dtype=np.float32)
        scores, indices = index.search(query, 1)

        if len(indices[0]) > 0 and int(indices[0][0]) >= 0:
            idx = int(indices[0][0])
            if stateless or self.context_hashes[idx] == context_hash:
                return float(scores[0][0])
        return None

    def store(self, query_embedding: list[float], context_hash: str,
              response_data: dict) -> None:
        """Add a response to the cache. Enforces FIFO eviction at max_entries."""
        self.turn_counter += 1
        entry = dict(response_data)
        entry["turn_num"] = self.turn_counter

        self.embeddings.append(query_embedding)
        self.context_hashes.append(context_hash)
        self.responses.append(entry)

        while len(self.embeddings) > self.max_entries:
            self.embeddings.pop(0)
            self.context_hashes.pop(0)
            self.responses.pop(0)
