"""Generic text and JSON parsing utilities.

No domain knowledge. Any project could use these.

Usage:
    from conjured.core.parsing import parse_json, strip_html_tags
"""

import json
import re

from conjured.core.logging import get_logger

logger = get_logger(__name__)

_HTML_TAG_RE = re.compile(r"</?[a-zA-Z][^>]*>")


def strip_html_tags(text: str) -> str:
    """Remove HTML tags that LLMs sometimes inject into dialogue/narration."""
    return _HTML_TAG_RE.sub("", text)


def parse_json(raw: str) -> dict | None:
    """Strip markdown fences, thinking blocks, and parse JSON. Returns dict or None."""
    try:
        clean = raw.strip()
        if "<think>" in clean:
            clean = re.sub(r'<think>.*?</think>\s*', '', clean, flags=re.DOTALL).strip()
        if clean.startswith("```"):
            clean = clean.split("```")[1]
            if clean.startswith("json"):
                clean = clean[4:]
        return json.loads(clean.strip())
    except Exception:
        logger.exception("json_parse_failed")
        return None
