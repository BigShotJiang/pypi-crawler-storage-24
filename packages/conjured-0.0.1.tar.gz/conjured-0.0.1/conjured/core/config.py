"""Generic TOML config loading with caching.

No engine, API, or game-specific logic. Any module can import this.

Usage:
    from conjured.core.config import load_toml, get_nested, invalidate

    cfg = load_toml(Path("config/something.toml"))
    val = get_nested(cfg, "section.key", default="fallback")
"""

import tomllib
from pathlib import Path

_cache: dict[Path, dict] = {}


def load_toml(path: Path) -> dict:
    """Load and cache a TOML file. Returns the parsed dict.

    Cache is keyed by resolved path, so symlinks and relative paths
    resolve to the same entry. Call invalidate() to clear.
    """
    key = path.resolve()
    if key not in _cache:
        with open(key, "rb") as f:
            _cache[key] = tomllib.load(f)
    return _cache[key]


def get_nested(config: dict, dotted_key: str, default=None):
    """Traverse a nested dict using dot-separated keys.

    get_nested(cfg, "generation.temperature", default=0.7)
    is equivalent to cfg.get("generation", {}).get("temperature", 0.7)
    """
    parts = dotted_key.split(".")
    current = config
    for part in parts[:-1]:
        if not isinstance(current, dict):
            return default
        current = current.get(part, {})
    if not isinstance(current, dict):
        return default
    return current.get(parts[-1], default)


def invalidate(path: Path | None = None):
    """Clear cached config. If path given, clear only that file. Otherwise clear all."""
    if path is not None:
        _cache.pop(path.resolve(), None)
    else:
        _cache.clear()
