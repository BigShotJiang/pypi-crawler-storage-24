"""Shared utility functions used across layers."""

from __future__ import annotations


def deep_merge(base: dict, overlay: dict) -> dict:
    """Recursively merge overlay into base. Overlay values win on conflict.

    Lists are replaced (not appended). None values in overlay delete the key.
    Returns a new dict — base is not mutated.
    """
    result = dict(base)
    for key, value in overlay.items():
        if value is None:
            result.pop(key, None)
        elif isinstance(value, dict) and isinstance(result.get(key), dict):
            result[key] = deep_merge(result[key], value)
        else:
            result[key] = value
    return result
