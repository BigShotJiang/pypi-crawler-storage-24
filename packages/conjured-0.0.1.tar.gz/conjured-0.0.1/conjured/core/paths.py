"""Path resolution — single source of truth for the engine package.

Resolution order for CONFIG_DIR:
    1. CONJURE_CONFIG_DIR env var (or .env)
    2. conjured/config/ (ships with package — reference templates)

Usage:
    from conjured.core.paths import CONFIG_DIR, MODELS_DIR, PROJECT_ROOT
"""

import os
from pathlib import Path

from dotenv import load_dotenv

load_dotenv()

# src/conjured/core/ → parent = src/conjured/
PACKAGE_ROOT = Path(__file__).parent.parent

# src/conjured/core/ → up to repo root
PROJECT_ROOT = PACKAGE_ROOT.parent.parent

# Config — inside the package (ships as reference templates)
# Games/consumers override via CONJURE_CONFIG_DIR env var or .env
CONFIG_DIR = Path(os.environ.get(
    "CONJURE_CONFIG_DIR",
    str(PACKAGE_ROOT / "config"),
))

# External paths — at repo root (not inside package)
MODELS_DIR = Path(os.environ.get(
    "CONJURE_MODELS_DIR",
    str(PROJECT_ROOT / "models"),
))
