"""Shared utilities — no project-internal imports. Any layer can use these.

Usage:
    from conjured.core import get_logger, load_toml, PROJECT_ROOT
"""

from conjured.core.config import load_toml, get_nested, invalidate
from conjured.core.logging import get_logger, configure_logging, compute_profile, check_budget, format_report
from conjured.core.paths import PROJECT_ROOT, PACKAGE_ROOT, CONFIG_DIR, MODELS_DIR
from conjured.core.utils import deep_merge
