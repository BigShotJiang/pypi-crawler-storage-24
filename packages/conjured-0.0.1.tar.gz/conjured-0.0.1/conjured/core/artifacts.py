"""Artifact registry and runtime loader.

Registry for compiled artifacts (pre-processed game config → optimized
runtime data). The build tool (tools/compile.py) compiles artifacts.
Handlers load them at runtime via load_artifact().

Usage:
    from conjured.core.artifacts import register_artifact, load_artifact

    @register_artifact("entity_dict")
    class EntityDict:
        name = "entity_dict"
        def source_hash(self) -> str: ...
        def compile(self, output_dir: Path) -> None: ...
        def load(self, compiled_dir: Path) -> Any: ...

    # At runtime (in a handler):
    data = load_artifact("entity_dict")
"""

from __future__ import annotations

import threading
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

from conjured.core.logging import get_logger
from conjured.core.paths import PROJECT_ROOT

logger = get_logger(__name__)

COMPILED_DIR = PROJECT_ROOT / "compiled"


@dataclass
class ArtifactMeta:
    """Registry entry for a compiled artifact."""
    name: str
    compiler: object  # has source_hash(), compile(), load() methods
    _instance: Any = field(default=None, repr=False)
    _lock: threading.Lock = field(default_factory=threading.Lock, repr=False)


# The registry — populated by @register_artifact
ARTIFACTS: dict[str, ArtifactMeta] = {}


def register_artifact(name: str):
    """Decorator that registers an artifact compiler class.

    The class must implement:
        name: str
        source_hash() -> str
        compile(output_dir: Path) -> None
        load(compiled_dir: Path) -> Any
    """
    def decorator(cls):
        ARTIFACTS[name] = ArtifactMeta(name=name, compiler=cls())
        return cls
    return decorator


def load_artifact(name: str) -> Any:
    """Load a compiled artifact, using a cached singleton.

    Thread-safe via per-artifact Lock with double-checked locking.
    Raises FileNotFoundError if artifact is not compiled.
    """
    if name not in ARTIFACTS:
        raise ValueError(f"Unknown artifact: {name}. Registered: {list(ARTIFACTS.keys())}")

    meta = ARTIFACTS[name]

    if meta._instance is not None:
        return meta._instance

    with meta._lock:
        if meta._instance is not None:
            return meta._instance

        artifact_dir = COMPILED_DIR / name
        if not artifact_dir.exists():
            raise FileNotFoundError(
                f"Artifact '{name}' not compiled. Run: python -m conjured.tools.compile"
            )

        meta._instance = meta.compiler.load(COMPILED_DIR)
        return meta._instance


def invalidate(name: str | None = None) -> None:
    """Clear cached artifact instance(s), forcing reload on next access."""
    targets = [name] if name else list(ARTIFACTS.keys())
    for n in targets:
        if n in ARTIFACTS:
            with ARTIFACTS[n]._lock:
                ARTIFACTS[n]._instance = None
