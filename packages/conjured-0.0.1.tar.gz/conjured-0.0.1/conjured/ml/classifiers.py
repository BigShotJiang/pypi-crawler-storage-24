"""Trained classifier inference — lazy-loaded models for input classification.

Tiered ML classifiers for dialogue act and manipulation detection:
  - Tier 2: DistilBERT multi-task ONNX (~10-15ms, highest accuracy)
  - Tier 1: LogReg on MiniLM embeddings (~1ms, optional fallback)
  - Tier 0: Keyword heuristics (in handler code, no model needed)

Models loaded once on first call, then cached for the process lifetime.

Usage:
    from conjured.ml.classifiers import (
        classify_dialogue_act_text, classify_manipulation_text,
        classify_dialogue_act, classify_manipulation,
    )
"""

from __future__ import annotations

import json
import os
from pathlib import Path
from typing import Any

import numpy as np

from conjured.core.logging import get_logger
from conjured.core.paths import MODELS_DIR

logger = get_logger(__name__)

# ---------------------------------------------------------------------------
# Module-level caches — loaded once per process
# ---------------------------------------------------------------------------

# Tier 1: LogReg on MiniLM embeddings
_dialogue_act_clf: Any = None
_dialogue_act_labels: dict[int, str] | None = None
_manipulation_clf: Any = None
_logreg_checked = False

# Tier 2: DistilBERT multi-task ONNX
_distilbert_session: Any = None
_distilbert_tokenizer: Any = None
_distilbert_da_labels: dict[int, str] | None = None
_distilbert_checked = False


# ---------------------------------------------------------------------------
# Tier 1: LogReg loaders
# ---------------------------------------------------------------------------

def _load_logreg() -> None:
    """Lazy-load LogReg classifier models (Tier 1)."""
    global _dialogue_act_clf, _dialogue_act_labels, _manipulation_clf, _logreg_checked

    if _logreg_checked:
        return
    _logreg_checked = True

    da_model_path = MODELS_DIR / "dialogue_act_classifier.joblib"
    da_labels_path = MODELS_DIR / "dialogue_act_labels.json"
    if da_model_path.exists() and da_labels_path.exists():
        try:
            import joblib
            _dialogue_act_clf = joblib.load(da_model_path)
            with open(da_labels_path) as f:
                _dialogue_act_labels = {int(k): v for k, v in json.load(f).items()}
            logger.info("classifier_loaded", name="dialogue_act_logreg",
                        classes=len(_dialogue_act_labels))
        except Exception as e:
            logger.warning("classifier_load_failed", name="dialogue_act_logreg", error=str(e))
    else:
        logger.debug("classifier_not_found", name="dialogue_act_logreg",
                      path=str(da_model_path))

    manip_model_path = MODELS_DIR / "manipulation_classifier.joblib"
    if manip_model_path.exists():
        try:
            import joblib
            _manipulation_clf = joblib.load(manip_model_path)
            logger.info("classifier_loaded", name="manipulation_logreg")
        except Exception as e:
            logger.warning("classifier_load_failed", name="manipulation_logreg", error=str(e))
    else:
        logger.debug("classifier_not_found", name="manipulation_logreg",
                      path=str(manip_model_path))


# ---------------------------------------------------------------------------
# Tier 2: DistilBERT ONNX loader
# ---------------------------------------------------------------------------

def _load_distilbert() -> None:
    """Lazy-load DistilBERT multi-task ONNX model (Tier 2)."""
    global _distilbert_session, _distilbert_tokenizer, _distilbert_da_labels, _distilbert_checked

    if _distilbert_checked:
        return
    _distilbert_checked = True

    model_dir = MODELS_DIR / "distilbert_multitask"
    onnx_path = model_dir / "model.onnx"
    labels_path = model_dir / "label_map_da.json"

    if not onnx_path.exists() or not labels_path.exists():
        logger.debug("classifier_not_found", name="distilbert_multitask",
                      path=str(onnx_path))
        return

    try:
        import onnxruntime
        from transformers import AutoTokenizer

        _providers = ["CUDAExecutionProvider", "CPUExecutionProvider"]
        _distilbert_session = onnxruntime.InferenceSession(
            str(onnx_path),
            providers=_providers,
        )
        _distilbert_tokenizer = AutoTokenizer.from_pretrained(str(model_dir))
        with open(labels_path) as f:
            _distilbert_da_labels = {int(k): v for k, v in json.load(f).items()}

        # Warmup inference — triggers ONNX JIT kernel compilation at startup
        _warmup_enc = _distilbert_tokenizer(
            ["hello"], truncation=True, padding="max_length", max_length=64, return_tensors="np"
        )
        _distilbert_session.run(None, {
            "input_ids": _warmup_enc["input_ids"].astype(np.int64),
            "attention_mask": _warmup_enc["attention_mask"].astype(np.int64),
        })

        logger.info("classifier_loaded", name="distilbert_multitask",
                     classes=len(_distilbert_da_labels))
    except Exception as e:
        logger.warning("classifier_load_failed", name="distilbert_multitask", error=str(e))
        _distilbert_session = None
        _distilbert_tokenizer = None
        _distilbert_da_labels = None


def _run_distilbert(text: str) -> tuple[np.ndarray, np.ndarray] | None:
    """Run text through DistilBERT ONNX. Returns (da_logits, manip_logits) or None."""
    _load_distilbert()
    if _distilbert_session is None or _distilbert_tokenizer is None:
        return None

    try:
        enc = _distilbert_tokenizer(
            [text], truncation=True, padding="max_length",
            max_length=64, return_tensors="np",
        )
        outputs = _distilbert_session.run(None, {
            "input_ids": enc["input_ids"].astype(np.int64),
            "attention_mask": enc["attention_mask"].astype(np.int64),
        })
        return outputs[0][0], outputs[1][0]
    except Exception as e:
        logger.warning("distilbert_inference_failed", error=str(e))
        return None


def _run_distilbert_batch(texts: list[str]) -> list[tuple[np.ndarray, np.ndarray]] | None:
    """Run multiple texts through DistilBERT ONNX in a single batched call."""
    _load_distilbert()
    if _distilbert_session is None or _distilbert_tokenizer is None:
        return None

    if not texts:
        return []

    try:
        enc = _distilbert_tokenizer(
            texts, truncation=True, padding="max_length",
            max_length=64, return_tensors="np",
        )
        outputs = _distilbert_session.run(None, {
            "input_ids": enc["input_ids"].astype(np.int64),
            "attention_mask": enc["attention_mask"].astype(np.int64),
        })
        return [(outputs[0][i], outputs[1][i]) for i in range(len(texts))]
    except Exception as e:
        logger.warning("distilbert_batch_inference_failed", error=str(e), batch_size=len(texts))
        return None


# ---------------------------------------------------------------------------
# Tier 2 public API (text-based, DistilBERT)
# ---------------------------------------------------------------------------

def classify_dialogue_act_text(text: str) -> str | None:
    """Classify dialogue act from raw text using DistilBERT (Tier 2).

    Returns one of 21 canonical act labels, or None if not available.
    """
    result = _run_distilbert(text)
    if result is None or _distilbert_da_labels is None:
        return None
    da_logits, _ = result
    pred = int(np.argmax(da_logits))
    return _distilbert_da_labels.get(pred)


def classify_manipulation_text(text: str) -> bool | None:
    """Classify manipulation attempt from raw text using DistilBERT (Tier 2).

    Returns True (injection), False (normal), or None if not available.
    """
    result = _run_distilbert(text)
    if result is None:
        return None
    _, manip_logits = result
    return bool(np.argmax(manip_logits) == 1)


def classify_batch_text(texts: list[str]) -> list[tuple[str | None, bool | None]] | None:
    """Batch-classify dialogue acts and manipulation for multiple texts (Tier 2)."""
    results = _run_distilbert_batch(texts)
    if results is None or _distilbert_da_labels is None:
        return None

    output = []
    for da_logits, manip_logits in results:
        da_pred = int(np.argmax(da_logits))
        da_label = _distilbert_da_labels.get(da_pred)
        is_manip = bool(np.argmax(manip_logits) == 1)
        output.append((da_label, is_manip))
    return output


def classify_manipulation_text_proba(text: str) -> float | None:
    """Return injection probability from DistilBERT (Tier 2), or None."""
    result = _run_distilbert(text)
    if result is None:
        return None
    _, manip_logits = result
    exp = np.exp(manip_logits - np.max(manip_logits))
    proba = exp / exp.sum()
    return float(proba[1])


# ---------------------------------------------------------------------------
# Tier 1 public API (embedding-based, LogReg)
# ---------------------------------------------------------------------------

def classify_dialogue_act(embedding: list[float] | np.ndarray) -> str | None:
    """Classify dialogue act from pre-computed embedding (Tier 1).

    Returns act label or None if model unavailable.
    """
    _load_logreg()
    if _dialogue_act_clf is None or _dialogue_act_labels is None:
        return None

    X = np.array(embedding, dtype=np.float32).reshape(1, -1)
    pred = _dialogue_act_clf.predict(X)[0]
    return _dialogue_act_labels[int(pred)]


def classify_manipulation(embedding: list[float] | np.ndarray) -> bool | None:
    """Classify manipulation attempt from embedding (Tier 1).

    Returns True (injection), False (normal), or None if unavailable.
    """
    _load_logreg()
    if _manipulation_clf is None:
        return None

    X = np.array(embedding, dtype=np.float32).reshape(1, -1)
    pred = _manipulation_clf.predict(X)[0]
    return bool(pred == 1)


def classify_manipulation_proba(embedding: list[float] | np.ndarray) -> float | None:
    """Return injection probability (0.0-1.0) from LogReg (Tier 1), or None."""
    _load_logreg()
    if _manipulation_clf is None:
        return None

    X = np.array(embedding, dtype=np.float32).reshape(1, -1)
    proba = _manipulation_clf.predict_proba(X)[0]
    return float(proba[1])
