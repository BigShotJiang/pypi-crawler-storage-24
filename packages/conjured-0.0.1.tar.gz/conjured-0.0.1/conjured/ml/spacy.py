"""Lazy spaCy model loader.

Thread-safe, loads once. Returns None if spaCy or en_core_web_sm unavailable.

Usage:
    from conjured.ml.spacy import get_spacy
    nlp = get_spacy()  # spacy.Language or None
"""

import threading

from conjured.core.logging import get_logger

logger = get_logger(__name__)

_nlp = None
_lock = threading.Lock()
_checked = False


def get_spacy():
    """Lazy-load spaCy en_core_web_sm. Returns None if unavailable."""
    global _nlp, _checked
    if not _checked:
        with _lock:
            if not _checked:
                try:
                    import spacy
                    _nlp = spacy.load("en_core_web_sm")
                except (ImportError, OSError):
                    logger.warning("spacy_unavailable",
                                   msg="spaCy or en_core_web_sm not installed")
                _checked = True
    return _nlp
