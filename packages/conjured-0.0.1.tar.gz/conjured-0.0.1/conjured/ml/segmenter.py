"""Sentence segmentation for multi-intent player input.

Splits player text into individual sentences/intents before dialogue act
classification. Uses WtP (Where's the Point) for boundary detection on
unpunctuated text, spaCy conjunct splitting for coordinated clauses, and
a minimum-length rejoin filter to prevent fragments.

Models loaded once on first call, then cached for the process lifetime.

Usage:
    from conjured.ml.segmenter import segment_sentences

    segments = segment_sentences("I heard the king is dead where is the blacksmith")
    # ["I heard the king is dead", "where is the blacksmith"]
"""

from __future__ import annotations

from typing import Any

from conjured.core.logging import get_logger
from conjured.core.paths import MODELS_DIR

logger = get_logger(__name__)

# Module-level cache for WtP model
_wtp_model: Any = None
_wtp_checked = False


def _load_wtp() -> None:
    """Lazy-load WtP sat-3l-sm model."""
    global _wtp_model, _wtp_checked

    if _wtp_checked:
        return
    _wtp_checked = True

    try:
        import torch
        from wtpsplit import SaT
        model_dir = str(MODELS_DIR / "sat-3l-sm")
        _wtp_model = SaT(model_dir)
        if torch.cuda.is_available():
            _wtp_model.half().to("cuda")
        _wtp_model.split("hello")  # warmup
        logger.info("segmenter_loaded", model="sat-3l-sm")
    except Exception as e:
        logger.warning("segmenter_load_failed", model="sat-3l-sm", error=str(e))
        _wtp_model = None


def _split_conjuncts(sent) -> list[str]:
    """Split a spaCy Span on coordinating conjunctions between verb clauses."""
    split_points = []
    for token in sent:
        if token.dep_ == "cc" and token.head.pos_ == "VERB":
            has_conj_verb = any(
                child.dep_ == "conj" and child.pos_ == "VERB"
                for child in token.head.children
            )
            if has_conj_verb:
                split_points.append(token.i - sent.start)

    if not split_points:
        return [sent.text]

    tokens = [t.text_with_ws for t in sent]
    result = []
    prev = 0
    for sp in split_points:
        chunk = "".join(tokens[prev:sp]).strip()
        if chunk:
            result.append(chunk)
        prev = sp
    chunk = "".join(tokens[prev:]).strip()
    if chunk:
        result.append(chunk)
    return result


def _rejoin_short(segments: list[str], min_words: int = 3) -> list[str]:
    """Rejoin segments shorter than min_words with their neighbor."""
    if len(segments) <= 1:
        return segments
    result = []
    for seg in segments:
        if result and len(seg.split()) < min_words:
            result[-1] = result[-1] + " " + seg
        else:
            result.append(seg)
    if len(result) > 1 and len(result[-1].split()) < min_words:
        result[-2] = result[-2] + " " + result[-1]
        result.pop()
    return result


def segment_sentences(text: str) -> list[str]:
    """Split player input into individual sentences/intents.

    Returns a list of 1+ segments. Single-sentence input returns [text].
    Falls back to [text] if models aren't available.
    """
    if not text or not text.strip():
        return [text] if text else []

    text = text.strip()

    _load_wtp()
    if _wtp_model is None:
        return [text]

    try:
        wtp_segs = [s.strip() for s in _wtp_model.split(text) if s.strip()]
    except Exception as e:
        logger.warning("segmenter_wtp_failed", error=str(e))
        return [text]

    if len(wtp_segs) <= 1 and not wtp_segs:
        return [text]

    # Apply spaCy conjunct splitting on each WtP segment
    from conjured.ml.spacy import get_spacy
    nlp = get_spacy()

    if nlp is not None:
        result = []
        for seg in wtp_segs:
            try:
                doc = nlp(seg)
                for sent in doc.sents:
                    splits = _split_conjuncts(sent)
                    result.extend(splits)
            except Exception:
                logger.exception("segmenter_failed", segment=seg[:100])
                result.append(seg)
        segments = [s.strip() for s in result if s.strip()]
    else:
        segments = wtp_segs

    segments = _rejoin_short(segments, min_words=3)

    return segments if segments else [text]
