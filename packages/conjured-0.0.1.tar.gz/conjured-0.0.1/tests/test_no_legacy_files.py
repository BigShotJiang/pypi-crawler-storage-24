"""Guardrails — prevent legacy patterns from sneaking into conjured/.

Tests:
1. Forbidden files must not exist in src/conjured/
2. Legacy config god files must not be imported by conjured code
3. Renamed directories must not reappear
"""

from pathlib import Path

CONJURE_DIR = Path(__file__).parent.parent / "conjured"

# (path relative to src/conjured/, reason it must not exist)
FORBIDDEN_FILES = [
    ("context_metadata.py", "replaced by PipelineContext typed accumulator"),
    ("history.py", "was a thin wrapper, deleted"),
    ("logging.py", "use conjured.core.logging, not a re-export"),
    ("auth.py", "auth is a consumer concern, not engine — lives in consumers/auth/"),
    ("tts.py", "TTS rendering is a consumer concern — lives in consumers/tts/"),
    ("core/config_listing.py", "dead — old directory-scanning pattern replaced by master template + JSON filters"),
    ("core/output_parser.py", "split into core/parsing.py (generic) + handlers/utils/parse_response.py (domain)"),
    ("core/qa_timing.py", "merged into core/logging.py — timing capture is logging infrastructure"),
    ("core/latency.py", "merged into core/logging.py — latency profiling is logging infrastructure"),
    ("handlers/state/record_timing.py", "merged into core/logging.py — runner calls logging directly"),
    ("handlers/state/latency_masking.py", "delivery concern — timing logic belongs in facade, not pipeline"),
    ("pipeline/turn.py", "replaced by result stage handler — each pipeline defines its own return shape"),
    ("config/engine/handler_reference.toml", "generated from HandlerMeta — not a static file"),
    ("config/engine/accuracy_data.json", "dead — eval tracking lives in tools/eval/"),
    ("config/engine/settings_overrides.json", "dead — empty file with no consumers"),
]

# Directories that were renamed/removed
FORBIDDEN_DIRS = [
    ("templates", "renamed to config/"),
    ("handlers/config", "renamed to handlers/import/"),
    ("config/npcs", "moved to config/handlers/import/"),
    ("config/scenes", "moved to config/handlers/import/"),
    ("emote", "emote processing is handlers/analysis/ — no separate package"),
]

# Legacy config god files — handlers must use per-concern TOMLs in config/handlers/
LEGACY_CONFIG_PATHS = [
    "config/engine/parameters.toml",
    "config/engine/prompts.toml",
    "config/engine/enums.toml",
]


def test_no_forbidden_files_in_conjured():
    """Files elected for removal must not exist in src/conjured/."""
    found = []
    for relpath, reason in FORBIDDEN_FILES:
        full = CONJURE_DIR / relpath
        if full.exists():
            found.append(f"  {relpath} — {reason}")

    if found:
        msg = "Forbidden files found in src/conjured/:\n" + "\n".join(found)
        raise AssertionError(msg)


def test_no_forbidden_dirs_in_conjured():
    """Renamed/removed directories must not reappear."""
    found = []
    for relpath, reason in FORBIDDEN_DIRS:
        full = CONJURE_DIR / relpath
        if full.is_dir():
            found.append(f"  {relpath} — {reason}")

    if found:
        msg = "Forbidden directories found in src/conjured/:\n" + "\n".join(found)
        raise AssertionError(msg)


def test_no_legacy_config_imports():
    """Conjured Python files must not reference legacy config god files.

    Handlers should load from config/handlers/<category>/, not from
    config/engine/parameters.toml, prompts.toml, or enums.toml.
    These god files exist only for the old engine during migration.
    """
    legacy_patterns = [
        "engine/parameters",
        "engine/prompts",
        "engine/enums",
        '"parameters.toml"',
        '"prompts.toml"',
        '"enums.toml"',
        "TEMPLATES_DIR",
        "core.latency",
        "state.record_timing",
    ]

    violations = []
    for py_file in CONJURE_DIR.rglob("*.py"):
        text = py_file.read_text(encoding="utf-8")
        for pattern in legacy_patterns:
            if pattern in text:
                rel = py_file.relative_to(CONJURE_DIR)
                violations.append(f"  {rel} references '{pattern}'")

    if violations:
        msg = (
            "Conjured code must not import from legacy config god files.\n"
            "Use per-concern TOMLs in config/handlers/ instead:\n"
            + "\n".join(violations)
        )
        raise AssertionError(msg)
