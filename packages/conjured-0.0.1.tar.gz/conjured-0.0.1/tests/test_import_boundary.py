"""Enforce that src/tests/ only imports from conjured.* — never engine.*, core.*, studio.*, etc.

This test scans all test files in src/tests/ and fails if any import
reaches outside the conjured package. This prevents regression toward
the old monolith import patterns.
"""

import ast
import os
from pathlib import Path

TESTS_DIR = Path(__file__).parent
ALLOWED_PREFIXES = ("conjured.",)
# stdlib and third-party are fine — we only block project-internal non-conjured imports
BLOCKED_PREFIXES = ("engine.", "core.", "studio.", "games.", "consumers.", "api.", "db.")


def _scan_imports(filepath: Path) -> list[str]:
    """Extract all import module names from a Python file."""
    with open(filepath, "r", encoding="utf-8") as f:
        try:
            tree = ast.parse(f.read(), filename=str(filepath))
        except SyntaxError:
            return []

    violations = []
    for node in ast.walk(tree):
        if isinstance(node, ast.ImportFrom) and node.module:
            for prefix in BLOCKED_PREFIXES:
                if node.module.startswith(prefix):
                    violations.append(f"{filepath.name}:{node.lineno} — from {node.module}")
        elif isinstance(node, ast.Import):
            for alias in node.names:
                for prefix in BLOCKED_PREFIXES:
                    if alias.name.startswith(prefix):
                        violations.append(f"{filepath.name}:{node.lineno} — import {alias.name}")
    return violations


def test_no_imports_outside_conjured():
    """Every test in src/tests/ must import from conjured.*, not engine.* or core.*."""
    all_violations = []
    for root, _, files in os.walk(TESTS_DIR):
        for fname in files:
            if fname.startswith("test_") and fname.endswith(".py"):
                path = Path(root) / fname
                violations = _scan_imports(path)
                all_violations.extend(violations)

    if all_violations:
        msg = "Tests importing from outside conjured:\n" + "\n".join(f"  {v}" for v in all_violations)
        raise AssertionError(msg)
