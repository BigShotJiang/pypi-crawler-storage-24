"""Enforce that src/conjured/ only imports from conjured.* — never engine.*, core.*, studio.*, etc.

This test scans all Python files in src/conjured/ and fails if any import
reaches outside the package into the old codebase. This prevents the
conjured package from depending on legacy code.

conjured.testing is allowed to import from engine.* during migration
(e.g., PipelineContext bridge). This exception is tracked and will
be removed when migration completes.
"""

import ast
import os
from pathlib import Path

CONJURE_DIR = Path(__file__).parent.parent / "conjured"
BLOCKED_PREFIXES = ("engine.", "core.", "studio.", "games.", "consumers.", "api.", "db.")

# Files allowed to import from blocked prefixes during migration.
# Each entry is (filename, blocked_module_prefix, reason).
# Remove entries as migration progresses — empty list = migration complete.
MIGRATION_EXCEPTIONS = []


def _is_excepted(filepath: Path, module: str) -> bool:
    """Check if this import is a known migration exception."""
    rel = str(filepath.relative_to(CONJURE_DIR)).replace("\\", "/")
    for exc_file, exc_module, _ in MIGRATION_EXCEPTIONS:
        if rel == exc_file and module.startswith(exc_module):
            return True
    return False


def _scan_imports(filepath: Path) -> list[str]:
    """Extract blocked import references from a Python file."""
    with open(filepath, "r", encoding="utf-8") as f:
        try:
            tree = ast.parse(f.read(), filename=str(filepath))
        except SyntaxError:
            return []

    violations = []
    for node in ast.walk(tree):
        if isinstance(node, ast.ImportFrom) and node.module:
            for prefix in BLOCKED_PREFIXES:
                if node.module.startswith(prefix) and not _is_excepted(filepath, node.module):
                    rel = filepath.relative_to(CONJURE_DIR)
                    violations.append(f"{rel}:{node.lineno} — from {node.module}")
        elif isinstance(node, ast.Import):
            for alias in node.names:
                for prefix in BLOCKED_PREFIXES:
                    if alias.name.startswith(prefix) and not _is_excepted(filepath, alias.name):
                        rel = filepath.relative_to(CONJURE_DIR)
                        violations.append(f"{rel}:{node.lineno} — import {alias.name}")
    return violations


def test_conjured_does_not_import_legacy():
    """Every file in src/conjured/ must import from conjured.*, not engine.* or core.*."""
    all_violations = []
    for root, _, files in os.walk(CONJURE_DIR):
        for fname in files:
            if fname.endswith(".py"):
                path = Path(root) / fname
                violations = _scan_imports(path)
                all_violations.extend(violations)

    if all_violations:
        msg = "Conjured files importing from legacy codebase:\n" + "\n".join(f"  {v}" for v in all_violations)
        raise AssertionError(msg)


def test_migration_exceptions_still_needed():
    """Each migration exception should still exist. Remove stale entries."""
    for exc_file, exc_module, reason in MIGRATION_EXCEPTIONS:
        filepath = CONJURE_DIR / exc_file
        assert filepath.exists(), (
            f"Migration exception file '{exc_file}' no longer exists. "
            f"Remove from MIGRATION_EXCEPTIONS."
        )
        with open(filepath, "r", encoding="utf-8") as f:
            content = f.read()
        assert exc_module in content, (
            f"Migration exception '{exc_file}' no longer imports '{exc_module}'. "
            f"Remove from MIGRATION_EXCEPTIONS. Reason was: {reason}"
        )
