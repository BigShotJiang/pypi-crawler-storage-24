"""Template completeness — every required_config_fields path must exist in the master templates.

This test catches: handler added that needs npc.engagement.engagement_limit,
but the NPC template doesn't have that field. Fails at test time, not runtime.
"""

from conjured.testing.config import load_test_npc, load_test_scene, load_test_pipeline
from conjured.pipeline.registry import HANDLERS, ensure_handlers_loaded


def _resolve_dotted(data: dict, dotted_path: str) -> bool:
    """Check if a dotted path exists in a nested dict. Returns True if found."""
    parts = dotted_path.split(".")
    current = data
    for part in parts:
        if not isinstance(current, dict) or part not in current:
            return False
        current = current[part]
    return True


def _get_template_for_prefix(prefix: str) -> dict | None:
    """Map a field prefix to the right template."""
    if prefix == "npc":
        return load_test_npc()
    elif prefix == "scene":
        return load_test_scene()
    elif prefix == "pipeline":
        return load_test_pipeline()
    return None


def test_all_required_config_fields_exist_in_templates():
    """Every handler's required_config_fields must resolve in the master template."""
    ensure_handlers_loaded()

    missing = []
    for handler_name, meta in HANDLERS.items():
        for field_path in meta.required_config_fields:
            # First segment determines which template (npc.engagement.limit → npc template)
            prefix = field_path.split(".")[0]
            template = _get_template_for_prefix(prefix)
            if template is None:
                missing.append(f"{handler_name}: unknown template prefix '{prefix}' in '{field_path}'")
                continue
            if not _resolve_dotted(template, field_path):
                missing.append(f"{handler_name}: '{field_path}' not found in {prefix} template")

    if missing:
        msg = "Handler required_config_fields missing from templates:\n" + "\n".join(f"  {m}" for m in missing)
        raise AssertionError(msg)
