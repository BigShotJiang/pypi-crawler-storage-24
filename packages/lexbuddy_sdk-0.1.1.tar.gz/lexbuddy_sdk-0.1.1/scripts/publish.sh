#!/usr/bin/env bash
# Publish lexbuddy-sdk to PyPI.
# Usage:
#   ./scripts/publish.sh           # publish to real PyPI
#   ./scripts/publish.sh --test    # publish to TestPyPI first
set -euo pipefail

SDK_DIR="$(cd "$(dirname "$0")/.." && pwd)"
cd "$SDK_DIR"

echo "==> Cleaning previous build artifacts..."
rm -rf dist/ build/ *.egg-info

echo "==> Building distribution packages..."
python -m build

echo "==> Checking distribution packages..."
twine check dist/*

if [[ "${1:-}" == "--test" ]]; then
    echo "==> Uploading to TestPyPI..."
    twine upload --repository testpypi dist/*
    echo ""
    echo "Install from TestPyPI with:"
    echo "  pip install --index-url https://test.pypi.org/simple/ lexbuddy-sdk"
else
    echo "==> Uploading to PyPI..."
    twine upload dist/*
    echo ""
    echo "Install from PyPI with:"
    echo "  pip install lexbuddy-sdk"
fi
