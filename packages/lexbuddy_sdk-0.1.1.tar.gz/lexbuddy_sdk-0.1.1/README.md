# lexbuddy-sdk

Shared models, enums, auth, and utilities for LexBuddy backend services.

## Installation

### Development (monorepo — editable)
```bash
pip install -e ../lexbuddy-sdk
```

### Production (once published to PyPI)
```bash
pip install lexbuddy-sdk==0.1.0
```

## Structure

```
lexbuddy_sdk/
├── enums/
│   ├── billing.py       # PlanTier, BillingInterval, BillingStatus
│   ├── iam.py           # ManagedType, ResourceType, ActionType, EffectType
│   └── management.py    # AIProvider, RoleName, DocSource, ConvKind, MatterStatus, …
├── models/
│   ├── billing.py       # Plan, PlanPrice, Subscription, Invoice, …
│   ├── iam.py           # Policy, RolePolicy
│   ├── management.py    # User, Organization, Client, Matter, Conversations, …
│   └── usage.py         # OrgUsage
├── db/
│   ├── base.py          # SQLAlchemy Base
│   └── async_database.py  # create_async_db() factory
├── auth/
│   └── cognito.py       # CognitoJWKsCache, CognitoJWTVerifier
└── utils/
    ├── ids.py           # now_iso(), new_ulid_like(), new_id()
    └── paging.py        # encode_cursor(), decode_cursor()
```

## Usage

### DB setup in each service

```python
# app/db/async_database.py
from config.settings import settings
from lexbuddy_sdk.db.async_database import create_async_db

engine, SessionLocal, get_db = create_async_db(
    postgres_user=settings.POSTGRES_USER,
    postgres_password=settings.POSTGRES_PASSWORD,
    postgres_host=settings.POSTGRES_HOST,
    postgres_port=settings.POSTGRES_PORT,
    postgres_db=settings.POSTGRES_DB,
    ssl_mode=settings.POSTGRES_SSL_MODE,
)
```

### Auth

```python
from lexbuddy_sdk.auth.cognito import CognitoJWTVerifier

verifier = CognitoJWTVerifier(
    region=settings.AWS_COGNITO_REGION,
    user_pool_id=settings.AWS_COGNITO_USER_POOL_ID,
    app_client_id=settings.AWS_COGNITO_APP_CLIENT_ID,
)
claims = await verifier.verify_and_decode(token)
```

## Publishing to PyPI

```bash
pip install build twine
./scripts/publish.sh --test   # TestPyPI first
./scripts/publish.sh          # then real PyPI
```
