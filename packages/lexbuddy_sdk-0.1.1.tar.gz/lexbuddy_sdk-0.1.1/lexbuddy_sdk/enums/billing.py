from enum import Enum as PyEnum


class PlanTier(PyEnum):
    free = "free"
    starter = "starter"
    growth = "growth"
    enterprise = "enterprise"

class BillingInterval(PyEnum):
    month = "month"
    year = "year"

class BillingStatus(PyEnum):
    trialing = "trialing"
    active = "active"
    past_due = "past_due"
    canceled = "canceled"
    incomplete = "incomplete"
    incomplete_expired = "incomplete_expired"
    unpaid = "unpaid"
