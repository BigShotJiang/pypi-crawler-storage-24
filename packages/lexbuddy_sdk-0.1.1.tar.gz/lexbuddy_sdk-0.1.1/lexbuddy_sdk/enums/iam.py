from enum import StrEnum


class ManagedType(StrEnum):
    system = "system"
    org = "org"


class ResourceType(StrEnum):
    ORGANIZATION = "Organization"
    CLIENT = "Client"
    MATTER = "Matter"
    CONVERSATION = "Conversation"
    DOCUMENTS = "Documents"

    MEMBERS = "Members"
    ROLES = "Roles"
    POLICIES = "Policies"

    PLAN = "Plan"

    DRIVE = "Drive"
    ONEDRIVE = "OneDrive"
    DROPBOX = "Dropbox"

    TEMPLATES = "Templates"
    WORKFLOWS = "Workflows"
    INTEGRATIONS = "Integrations"
    AUDIT_LOGS = "AuditLogs"
    API_KEYS = "ApiKeys"
    NOTIFICATIONS = "Notifications"
    BILLING = "Billing"

    ALL = "*"

class ActionType(StrEnum):
    CREATE = "Create"
    READ = "Read"
    UPDATE = "Update"
    DELETE = "Delete"
    LIST = "List"

    UPLOAD = "Upload"
    DOWNLOAD = "Download"
    EXPORT = "Export"
    IMPORT = "Import"

    SHARE = "Share"
    COMMENT = "Comment"
    ASSIGN = "Assign"
    INVITE = "Invite"

    MANAGE = "Manage"
    CONFIGURE = "Configure"
    APPROVE = "Approve"
    REVOKE = "Revoke"

    ARCHIVE = "Archive"
    RESTORE = "Restore"
    VERSION = "Version"

    EXECUTE = "Execute"

    ALL = "*"

class EffectType(StrEnum):
    ALLOW = "Allow"
    DENY = "Deny"
