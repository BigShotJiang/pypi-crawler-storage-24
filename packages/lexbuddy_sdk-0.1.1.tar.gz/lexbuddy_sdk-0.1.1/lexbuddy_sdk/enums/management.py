from enum import Enum as PyEnum


class AIProvider(PyEnum):
    bedrock = "bedrock"
    openai = "openai"
    azure_openai = "azure_openai"
    vertex = "vertex"
    local = "local"
    other = "other"

class RoleName(PyEnum):
    owner = "owner"
    admin = "admin"
    lawyer = "lawyer"
    paralegal = "paralegal"
    guest = "guest"
    billing = "billing"

class PermissionKey(PyEnum):
    org_read = "org_read"
    org_write = "org_write"
    org_manage_billing = "org_manage_billing"
    client_read = "client_read"
    client_write = "client_write"
    client_delete = "client_delete"
    matter_read = "matter_read"
    matter_write = "matter_write"
    matter_delete = "matter_delete"
    doc_read = "doc_read"
    doc_write = "doc_write"
    doc_delete = "doc_delete"
    conv_read = "conv_read"
    conv_write = "conv_write"
    conv_delete = "conv_delete"

class ScopeType(PyEnum):
    organization = "organization"
    client = "client"
    matter = "matter"

class DocSource(PyEnum):
    uploaded = "uploaded"
    ai_generated = "ai_generated"
    imported = "imported"
    synced = "synced"

class DocFormat(PyEnum):
    pdf = "pdf"
    docx = "docx"
    md = "md"
    txt = "txt"
    html = "html"
    image = "image"
    other = "other"

class ConvKind(PyEnum):
    general = "general"
    document_drafting = "document_drafting"
    research = "research"
    qa = "qa"

class MessageRole(PyEnum):
    user = "user"
    assistant = "assistant"
    system = "system"
    tool = "tool"

class IndexState(PyEnum):
    pending = "pending"
    processing = "processing"
    indexed = "indexed"
    failed = "failed"

class MatterStatus(PyEnum):
    """Lifecycle status for matters (Asuntos).
    ACTIVE: default, visible in normal listings.
    ARCHIVED: hidden from default listing; can be restored to ACTIVE.
    DRAFT: optional; not shown in default listing until activated (future use).
    CLOSED: optional; definitively closed, no restore (future use).
    """
    ACTIVE = "ACTIVE"
    ARCHIVED = "ARCHIVED"
    DRAFT = "DRAFT"
    CLOSED = "CLOSED"


# Valid matter status transitions: from_status -> set of allowed to_status
MATTER_STATUS_TRANSITIONS: dict[str, set[str]] = {
    MatterStatus.ACTIVE.value: {MatterStatus.ARCHIVED.value, MatterStatus.CLOSED.value},
    MatterStatus.ARCHIVED.value: {MatterStatus.ACTIVE.value},
    MatterStatus.DRAFT.value: {MatterStatus.ACTIVE.value},
    MatterStatus.CLOSED.value: set(),  # terminal
}
