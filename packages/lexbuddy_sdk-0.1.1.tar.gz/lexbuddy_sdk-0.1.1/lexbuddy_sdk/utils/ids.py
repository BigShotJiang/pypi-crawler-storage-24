from datetime import datetime, timezone
import uuid


def now_iso():
    return datetime.now(timezone.utc).isoformat(timespec="milliseconds").replace("+00:00", "Z")

def new_ulid_like():
    ts = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%S%f")
    return f"{ts}_{uuid.uuid4().hex[:8]}"

def new_id(prefix: str):
    return f"{prefix}_{uuid.uuid4().hex}"
