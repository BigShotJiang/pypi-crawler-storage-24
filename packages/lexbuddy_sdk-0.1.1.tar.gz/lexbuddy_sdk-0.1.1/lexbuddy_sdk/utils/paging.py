import base64
import json
from typing import Optional


def encode_cursor(lek: Optional[dict]) -> Optional[str]:
    if not lek:
        return None
    raw = json.dumps(lek, separators=(",", ":")).encode("utf-8")
    return base64.urlsafe_b64encode(raw).decode("utf-8")

def decode_cursor(cursor: Optional[str]) -> Optional[dict]:
    if not cursor:
        return None
    raw = base64.urlsafe_b64decode(cursor.encode("utf-8"))
    return json.loads(raw.decode("utf-8"))
