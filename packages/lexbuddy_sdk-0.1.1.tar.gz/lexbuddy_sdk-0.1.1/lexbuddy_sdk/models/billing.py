from sqlalchemy import Column, String, JSON, DateTime, Enum, Boolean, Integer, ForeignKey, UniqueConstraint, Index
from sqlalchemy.dialects.postgresql import UUID
from sqlalchemy.sql import func
import uuid

from lexbuddy_sdk.db.base import Base
from lexbuddy_sdk.enums.billing import PlanTier, BillingInterval, BillingStatus


class Plan(Base):
    __tablename__ = "plans"
    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    tier = Column(Enum(PlanTier, name="plan_tier"), nullable=False, unique=True)
    stripe_product_id = Column(String, nullable=False, unique=True)
    limits = Column(JSON)
    is_custom = Column(Boolean, nullable=False, default=False)
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(DateTime(timezone=True), server_default=func.now(), onupdate=func.now())

class PlanPrice(Base):
    __tablename__ = "plan_prices"
    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    plan_id = Column(UUID(as_uuid=True), ForeignKey("plans.id"), nullable=False)
    stripe_price_id = Column(String, nullable=False, unique=True)
    interval = Column(Enum(BillingInterval, name="billing_interval"), nullable=False)
    unit_amount_cents = Column(Integer, nullable=False)
    currency = Column(String, nullable=False, default="usd")
    allows_seats = Column(Boolean, nullable=False, default=False)

    __table_args__ = (
        UniqueConstraint("plan_id", "interval", name="uq_planprice_plan_interval"),
    )

class Subscription(Base):
    __tablename__ = "subscriptions"
    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    organization_id = Column(UUID(as_uuid=True), ForeignKey("organizations.id"), nullable=False)
    stripe_subscription_id = Column(String, nullable=False, unique=True)
    stripe_customer_id = Column(String, nullable=False)
    plan_id = Column(UUID(as_uuid=True), ForeignKey("plans.id"), nullable=False)
    plan_price_id = Column(UUID(as_uuid=True), ForeignKey("plan_prices.id"), nullable=False)
    status = Column(Enum(BillingStatus, name="billing_status"), nullable=False)
    quantity = Column(Integer, nullable=False, default=1)
    cancel_at_period_end = Column(Boolean, nullable=False, default=False)
    current_period_start = Column(DateTime(timezone=True))
    current_period_end = Column(DateTime(timezone=True))
    trial_end = Column(DateTime(timezone=True))
    snapshot = Column(JSON)
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(DateTime(timezone=True), server_default=func.now(), onupdate=func.now())

    __table_args__ = (
        Index("ix_subscriptions_org", "organization_id"),
    )

class SubscriptionItem(Base):
    __tablename__ = "subscription_items"
    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    subscription_id = Column(UUID(as_uuid=True), ForeignKey("subscriptions.id"), nullable=False)
    stripe_subscription_item_id = Column(String, nullable=False, unique=True)
    stripe_price_id = Column(String, nullable=False)
    quantity = Column(Integer, nullable=False, default=1)
    metadata_json = Column(JSON)

    __table_args__ = (
        Index("ix_subscription_items_sub", "subscription_id"),
        UniqueConstraint("subscription_id", "stripe_price_id", name="uq_subitem_sub_price"),
    )

class Invoice(Base):
    __tablename__ = "invoices"
    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    organization_id = Column(UUID(as_uuid=True), ForeignKey("organizations.id"), nullable=False)
    stripe_invoice_id = Column(String, nullable=False, unique=True)
    status = Column(String)
    amount_due_cents = Column(Integer)
    amount_paid_cents = Column(Integer)
    hosted_invoice_url = Column(String)
    invoice_pdf = Column(String)
    currency = Column(String, default="usd")
    created_at_stripe = Column(DateTime(timezone=True))
    created_at = Column(DateTime(timezone=True), server_default=func.now())

    __table_args__ = (Index("ix_invoices_org_created", "organization_id", "created_at"),)

class StripeWebhookEvent(Base):
    __tablename__ = "stripe_webhook_events"
    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    event_id = Column(String, nullable=False, unique=True)
    type = Column(String, nullable=False)
    payload = Column(JSON, nullable=False)
    processed = Column(Boolean, nullable=False, default=False)
    processed_at = Column(DateTime(timezone=True))
    created_at = Column(DateTime(timezone=True), server_default=func.now())
