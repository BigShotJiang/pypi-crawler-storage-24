from sqlalchemy import Column, String, Text, Enum, Boolean, ForeignKey, UniqueConstraint, Index, DateTime
from sqlalchemy.dialects.postgresql import UUID as PGUUID
from sqlalchemy.sql import func
from sqlalchemy.types import JSON
import uuid

from lexbuddy_sdk.db.base import Base
from lexbuddy_sdk.enums.iam import ManagedType


class Policy(Base):
    __tablename__ = "policies"
    id = Column(PGUUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    organization_id = Column(PGUUID(as_uuid=True), ForeignKey("organizations.id"), nullable=True)
    owner_role_id = Column(PGUUID(as_uuid=True), ForeignKey("roles.id"), nullable=True)
    name = Column(String, nullable=False)
    description = Column(Text)
    managed_type = Column(Enum(ManagedType, name="managed_type"), nullable=False, default=ManagedType.org)
    is_mutable = Column(Boolean, nullable=False, default=True)
    is_inline = Column(Boolean, nullable=False, default=False)
    document_json = Column(JSON, nullable=False, default=dict)
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(DateTime(timezone=True), server_default=func.now(), onupdate=func.now())
    __table_args__ = (
        UniqueConstraint("organization_id", "name", name="uq_policies_org_name"),
        Index("ix_policies_org_name", "organization_id", "name"),
    )

class RolePolicy(Base):
    __tablename__ = "role_policies"
    role_id = Column(PGUUID(as_uuid=True), ForeignKey("roles.id"), primary_key=True, nullable=False)
    policy_id = Column(PGUUID(as_uuid=True), ForeignKey("policies.id"), primary_key=True, nullable=False)
    __table_args__ = (
        Index("ix_role_policies_role", "role_id"),
    )
