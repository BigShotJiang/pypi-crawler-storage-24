from sqlalchemy import Column, Integer, ForeignKey, DateTime
from sqlalchemy.dialects.postgresql import UUID
from sqlalchemy.sql import func

from lexbuddy_sdk.db.base import Base


class OrgUsage(Base):
    __tablename__ = "org_usage"

    organization_id = Column(UUID(as_uuid=True), ForeignKey("organizations.id"), primary_key=True)

    conversations = Column(Integer, nullable=False, default=0)
    users = Column(Integer, nullable=False, default=0)
    clients = Column(Integer, nullable=False, default=0)
    matters = Column(Integer, nullable=False, default=0)
    storage_mb = Column(Integer, nullable=False, default=0)

    updated_at = Column(DateTime(timezone=True), server_default=func.now(), onupdate=func.now())
