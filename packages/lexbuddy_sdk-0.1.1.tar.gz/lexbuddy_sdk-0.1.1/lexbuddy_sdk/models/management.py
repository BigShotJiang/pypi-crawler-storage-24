import json
import uuid

from sqlalchemy import (
    Boolean, Column, DateTime, Enum, ForeignKey, Index,
    Integer, String, Text, UniqueConstraint, text,
)
from sqlalchemy.dialects.postgresql import UUID, UUID as PGUUID
from sqlalchemy.ext.mutable import MutableDict
from sqlalchemy.sql import func, JSON

from lexbuddy_sdk.db.base import Base
from lexbuddy_sdk.enums.billing import BillingStatus, PlanTier
from lexbuddy_sdk.enums.iam import ManagedType
from lexbuddy_sdk.enums.management import (
    AIProvider, ConvKind, DocFormat, DocSource, IndexState,
    MessageRole, PermissionKey, RoleName, ScopeType,
)

# Conversation column defaults — must match the server_default values below.
# Override at record-creation time in each service if different values are needed.
_DEFAULT_AI_PROVIDER = "bedrock"
_DEFAULT_AI_MODEL = "anthropic.claude-3-sonnet-20240229-v1:0"
_DEFAULT_SYSTEM_INSTRUCTIONS_MD = "You are a helpful legal assistant. Answer concisely and with clarity."
_DEFAULT_TOOL_CONFIG: dict = {"tools_enabled": True, "allow_citations": True}
_DEFAULT_GENERATION_PARAMS: dict = {"temperature": 0.2, "max_tokens": 2048}
_DEFAULT_MESSAGES_BACKEND = "dynamodb"
_DEFAULT_DDB_TABLE_NAME = "conversations_messages"


class User(Base):
    __tablename__ = "users"
    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    email = Column(String, nullable=False, unique=True)
    name = Column(String)
    middle_name = Column(String)
    family_name = Column(String)
    avatar_url = Column(String)
    cognito_sub = Column(String, unique=True, index=True)
    default_org_id = Column(UUID(as_uuid=True), ForeignKey("organizations.id"))
    is_blocked = Column(Boolean)
    is_active = Column(Boolean, nullable=False, default=True)
    last_login_at = Column(DateTime(timezone=True))
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(DateTime(timezone=True), server_default=func.now(), onupdate=func.now())

class Organization(Base):
    __tablename__ = "organizations"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    name = Column(String, nullable=False, unique=True)
    slug = Column(String, nullable=False, unique=True)
    owner_first_name = Column(String, nullable=False, default="N/A", server_default=text("'N/A'"))
    owner_last_name = Column(String, nullable=False, default="N/A", server_default=text("'N/A'"))
    job_title = Column(String)
    additional_email = Column(String)
    restrict_email_domain = Column(Boolean, default=False, server_default=text("false"))
    organization_type = Column(String)
    logo_url = Column(String)
    website = Column(String)
    about = Column(Text)

    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(
        DateTime(timezone=True),
        server_default=func.now(),
        onupdate=func.now()
    )

    s3_bucket_URI = Column(String)
    s3_bucket_URL = Column(String)

    stripe_customer_id = Column(String, unique=True)
    current_subscription_id = Column(String)
    current_price_id = Column(String)

    billing_email = Column(String)

    billing_status = Column(
        Enum(BillingStatus, name="org_billing_status"),
        default=BillingStatus.incomplete
    )
    current_plan_tier = Column(
        Enum(PlanTier, name="org_current_plan_tier"),
        nullable=True
    )

    current_period_end = Column(DateTime(timezone=True))
    cancel_at_period_end = Column(Boolean, default=False)
    seat_quantity = Column(Integer, default=1)
    pending_deletion_at = Column(DateTime(timezone=True), nullable=True)

class OrganizationMember(Base):
    __tablename__ = "organization_members"
    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    organization_id = Column(UUID(as_uuid=True), ForeignKey("organizations.id"), nullable=False)
    user_id = Column(UUID(as_uuid=True), ForeignKey("users.id"), nullable=False)
    invited_by = Column(UUID(as_uuid=True), ForeignKey("users.id"))
    joined_at = Column(DateTime(timezone=True), server_default=func.now())
    is_active = Column(Boolean, default=True)
    __table_args__ = (
        UniqueConstraint("organization_id", "user_id", name="uq_org_member_org_user"),
        Index("ix_org_members_user_org", "user_id", "organization_id"),
    )

class Role(Base):
    __tablename__ = "roles"
    id = Column(PGUUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    organization_id = Column(PGUUID(as_uuid=True), ForeignKey("organizations.id"), nullable=True)
    name = Column(String, nullable=False)
    description = Column(Text)
    managed_type = Column(Enum(ManagedType, name="managed_type"), nullable=False, default=ManagedType.org)
    is_mutable = Column(Boolean, nullable=False, default=True)
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(DateTime(timezone=True), server_default=func.now(), onupdate=func.now())
    __table_args__ = (
        UniqueConstraint("organization_id", "name", name="uq_roles_org_name"),
        Index("ix_roles_org_name", "organization_id", "name"),
    )

class Permission(Base):
    __tablename__ = "permissions"
    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    key = Column(Enum(PermissionKey, name="permission_key"), nullable=False, unique=True)
    description = Column(Text)

class RolePermission(Base):
    __tablename__ = "role_permissions"
    role_id = Column(UUID(as_uuid=True), ForeignKey("roles.id"), primary_key=True, nullable=False)
    permission_id = Column(UUID(as_uuid=True), ForeignKey("permissions.id"), primary_key=True, nullable=False)
    __table_args__ = (Index("ix_role_permissions_role", "role_id"),)

class UserRoleAssignment(Base):
    __tablename__ = "user_role_assignments"
    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    user_id = Column(UUID(as_uuid=True), ForeignKey("users.id"), nullable=False)
    organization_id = Column(UUID(as_uuid=True), ForeignKey("organizations.id"), nullable=False)
    role_id = Column(UUID(as_uuid=True), ForeignKey("roles.id"), nullable=False)
    scope = Column(Enum(ScopeType, name="scope_type"))
    scope_id = Column(UUID(as_uuid=True))
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    __table_args__ = (
        UniqueConstraint("user_id", "organization_id", "role_id", "scope", "scope_id", name="uq_user_role_scope"),
        Index("ix_user_roles_user_org", "user_id", "organization_id"),
        Index("ix_user_roles_user_scope", "user_id", "scope", "scope_id"),
    )

class Client(Base):
    __tablename__ = "clients"
    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    organization_id = Column(UUID(as_uuid=True), ForeignKey("organizations.id"), nullable=False)
    name = Column(String, nullable=False)
    logo_url = Column(String)
    website = Column(String)
    about = Column(Text)
    activity = Column(Text)
    contact_name = Column(String)
    contact_email = Column(String)
    contact_phone = Column(String)
    address = Column(JSON)
    created_by = Column(UUID(as_uuid=True), ForeignKey("users.id"))
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(DateTime(timezone=True), server_default=func.now(), onupdate=func.now())
    __table_args__ = (Index("ix_clients_org_name", "organization_id", "name"),)

    s3_bucket_URI = Column(String)
    s3_bucket_URL = Column(String)

class Matter(Base):
    __tablename__ = "matters"
    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    organization_id = Column(UUID(as_uuid=True), ForeignKey("organizations.id"), nullable=False)
    client_id = Column(UUID(as_uuid=True), ForeignKey("clients.id"), nullable=True)
    name = Column(String, nullable=False)
    description = Column(Text)
    status = Column(String, default="ACTIVE", server_default=text("'ACTIVE'"))
    created_by = Column(UUID(as_uuid=True), ForeignKey("users.id"))
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(DateTime(timezone=True), server_default=func.now(), onupdate=func.now())
    updated_by = Column(UUID(as_uuid=True), ForeignKey("users.id"), nullable=True)
    archived_at = Column(DateTime(timezone=True), nullable=True)
    archived_by = Column(UUID(as_uuid=True), ForeignKey("users.id"), nullable=True)
    __table_args__ = (
        Index("ix_matters_org_client_status", "organization_id", "client_id", "status"),
        Index("ix_matters_org_created", "organization_id", "created_at"),
    )

    s3_bucket_URI = Column(String)
    s3_bucket_URL = Column(String)

class MatterMember(Base):
    __tablename__ = "matter_members"
    matter_id = Column(UUID(as_uuid=True), ForeignKey("matters.id"), primary_key=True, nullable=False)
    user_id = Column(UUID(as_uuid=True), ForeignKey("users.id"), primary_key=True, nullable=False)
    role = Column(Enum(RoleName, name="matter_member_role_name"), nullable=False)
    added_at = Column(DateTime(timezone=True), server_default=func.now())
    __table_args__ = (Index("ix_matter_members_user_matter", "user_id", "matter_id"),)


class Conversations(Base):
    __tablename__ = "conversations"
    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)

    organization_id = Column(UUID(as_uuid=True), ForeignKey("organizations.id"), nullable=False)
    created_by = Column(UUID(as_uuid=True), ForeignKey("users.id"))
    title = Column(String)
    kind = Column(Enum(ConvKind, name="conv_kind"), nullable=False, default=ConvKind.general, server_default=text("'general'"))
    client_id = Column(UUID(as_uuid=True), ForeignKey("clients.id"), nullable=True)
    matter_id = Column(UUID(as_uuid=True), ForeignKey("matters.id"))

    ai_provider = Column(
        Enum(AIProvider, name="ai_provider"),
        nullable=True,
        default=_DEFAULT_AI_PROVIDER,
        server_default=text(f"'{_DEFAULT_AI_PROVIDER}'")
    )
    ai_model = Column(
        String,
        default=_DEFAULT_AI_MODEL,
        server_default=text(f"'{_DEFAULT_AI_MODEL}'")
    )
    system_instructions_md = Column(
        Text,
        default=_DEFAULT_SYSTEM_INSTRUCTIONS_MD,
        server_default=text(f"'{_DEFAULT_SYSTEM_INSTRUCTIONS_MD}'")
    )

    tool_config = Column(
        MutableDict.as_mutable(JSON),
        default=lambda: dict(_DEFAULT_TOOL_CONFIG),
        server_default=text(f"'{json.dumps(_DEFAULT_TOOL_CONFIG)}'::jsonb")
    )
    generation_params = Column(
        MutableDict.as_mutable(JSON),
        default=lambda: dict(_DEFAULT_GENERATION_PARAMS),
        server_default=text(f"'{json.dumps(_DEFAULT_GENERATION_PARAMS)}'::jsonb")
    )

    messages_backend = Column(
        String,
        nullable=False,
        default=_DEFAULT_MESSAGES_BACKEND,
        server_default=text(f"'{_DEFAULT_MESSAGES_BACKEND}'")
    )
    ddb_table_name = Column(
        String,
        default=_DEFAULT_DDB_TABLE_NAME,
        server_default=text(f"'{_DEFAULT_DDB_TABLE_NAME}'")
    )
    ddb_partition_key = Column(
        String,
        unique=True,
        default=lambda: f"conv#{uuid.uuid4().hex}"
    )

    message_count = Column(Integer, nullable=False, default=0, server_default=text("0"))
    first_message_at = Column(DateTime(timezone=True))
    last_message_at = Column(DateTime(timezone=True))
    last_message_role = Column(Enum(MessageRole, name="message_role"))
    last_message_preview = Column(Text)
    last_message_external_id = Column(String)

    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(DateTime(timezone=True), server_default=func.now(), onupdate=func.now())

    __table_args__ = (
        Index("ix_conversations_org_matter_client", "organization_id", "matter_id", "client_id"),
        Index("ix_conversations_org_created", "organization_id", "created_at"),
        Index("ix_conversations_kind", "kind"),
    )

class StorageBlob(Base):
    __tablename__ = "storage_blobs"
    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    organization_id = Column(UUID(as_uuid=True), ForeignKey("organizations.id"), nullable=False)
    url = Column(String)
    mime_type = Column(String)
    byte_size = Column(Integer)
    checksum = Column(String)
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    __table_args__ = (UniqueConstraint("organization_id", "checksum", name="uq_storage_blobs_org_checksum"),)

class Folder(Base):
    __tablename__ = "folders"
    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    organization_id = Column(UUID(as_uuid=True), ForeignKey("organizations.id"), nullable=False)
    matter_id = Column(UUID(as_uuid=True), ForeignKey("matters.id"))
    client_id = Column(UUID(as_uuid=True), ForeignKey("clients.id"), nullable=True)
    parent_id = Column(UUID(as_uuid=True), ForeignKey("folders.id"))
    name = Column(String, nullable=False)
    created_by = Column(UUID(as_uuid=True), ForeignKey("users.id"))
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    __table_args__ = (Index("ix_folders_org_matter_client_parent", "organization_id", "matter_id", "client_id", "parent_id"),)

class Document(Base):
    __tablename__ = "documents"
    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    organization_id = Column(UUID(as_uuid=True), ForeignKey("organizations.id"), nullable=False)
    client_id = Column(UUID(as_uuid=True), ForeignKey("clients.id"), nullable=True)
    matter_id = Column(UUID(as_uuid=True), ForeignKey("matters.id"))
    folder_id = Column(UUID(as_uuid=True), ForeignKey("folders.id"))
    title = Column(String, nullable=False)
    doc_source = Column(Enum(DocSource, name="doc_source"), nullable=False)
    doc_format = Column(Enum(DocFormat, name="doc_format"), nullable=False)
    current_version_id = Column(UUID(as_uuid=True), ForeignKey("document_versions.id"))
    created_by = Column(UUID(as_uuid=True), ForeignKey("users.id"))
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(DateTime(timezone=True), server_default=func.now(), onupdate=func.now())
    is_archived = Column(Boolean, default=False)
    __table_args__ = (Index("ix_documents_org_matter_client_folder", "organization_id", "matter_id", "client_id", "folder_id"),)

class DocumentVersion(Base):
    __tablename__ = "document_versions"
    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    document_id = Column(UUID(as_uuid=True), ForeignKey("documents.id"), nullable=False)
    version_no = Column(Integer, nullable=False)
    blob_id = Column(UUID(as_uuid=True), ForeignKey("storage_blobs.id"))
    content_md = Column(Text)
    source_s3_key = Column(String)
    source_filename = Column(String)
    source_extension = Column(String)
    md_s3_key = Column(String)
    md_etag = Column(String)
    source_etag = Column(String)
    created_by = Column(UUID(as_uuid=True), ForeignKey("users.id"))
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    __table_args__ = (UniqueConstraint("document_id", "version_no", name="uq_document_versions_doc_version"),)

class DocumentTag(Base):
    __tablename__ = "document_tags"
    document_id = Column(UUID(as_uuid=True), ForeignKey("documents.id"), primary_key=True, nullable=False)
    tag = Column(String, primary_key=True, nullable=False)

class DocumentLink(Base):
    __tablename__ = "document_links"
    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    source_document_id = Column(UUID(as_uuid=True), ForeignKey("documents.id"), nullable=False)
    target_document_id = Column(UUID(as_uuid=True), ForeignKey("documents.id"), nullable=False)
    relation = Column(String)
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    __table_args__ = (UniqueConstraint("source_document_id", "target_document_id", "relation", name="uq_document_links_src_tgt_rel"),)

class DocIndexJob(Base):
    __tablename__ = "doc_index_jobs"
    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    organization_id = Column(UUID(as_uuid=True), ForeignKey("organizations.id"), nullable=False)
    document_version_id = Column(UUID(as_uuid=True), ForeignKey("document_versions.id"), nullable=False)
    state = Column(Enum(IndexState, name="index_state"), nullable=False, default=IndexState.pending)
    error = Column(Text)
    started_at = Column(DateTime(timezone=True))
    finished_at = Column(DateTime(timezone=True))
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    __table_args__ = (UniqueConstraint("document_version_id", name="uq_doc_index_jobs_document_version_id"),)

class DocChunk(Base):
    __tablename__ = "doc_chunks"
    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    document_version_id = Column(UUID(as_uuid=True), ForeignKey("document_versions.id"), nullable=False)
    seq = Column(Integer, nullable=False)
    content = Column(Text, nullable=False)
    token_count = Column(Integer)
    embedding = Column(Text)
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    __table_args__ = (UniqueConstraint("document_version_id", "seq", name="uq_doc_chunks_doc_seq"),)

class AuditLog(Base):
    __tablename__ = "audit_logs"
    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    organization_id = Column(UUID(as_uuid=True), ForeignKey("organizations.id"), nullable=False)
    user_id = Column(UUID(as_uuid=True), ForeignKey("users.id"))
    action = Column(String, nullable=False)
    target_table = Column(String)
    target_id = Column(UUID(as_uuid=True))
    metadata_json = Column("metadata", JSON)
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    __table_args__ = (Index("ix_audit_logs_org_created", "organization_id", "created_at"),)

class SkillExecution(Base):
    """Tracks skill executions per conversation for audit and traceability."""
    __tablename__ = "skill_executions"
    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    conversation_id = Column(String, nullable=False, index=True)
    user_id = Column(String, nullable=False, index=True)
    organization_id = Column(UUID(as_uuid=True), nullable=False, index=True)

    skill_name = Column(String, nullable=False, index=True)
    skill_type = Column(String)
    tool_call_id = Column(String)

    status = Column(String, nullable=False)
    input_data = Column(JSON)
    output_data = Column(JSON)
    error_message = Column(Text)
    error_code = Column(String)

    started_at = Column(DateTime(timezone=True), nullable=False)
    completed_at = Column(DateTime(timezone=True))
    duration_ms = Column(Integer)

    model_key = Column(String)
    org_id = Column(String)
    client_id = Column(String)
    matter_id = Column(String)

    execution_metadata = Column("metadata", JSON)

    created_at = Column(DateTime(timezone=True), server_default=func.now())

    __table_args__ = (
        Index("ix_skill_executions_conv_created", "conversation_id", "created_at"),
        Index("ix_skill_executions_user_created", "user_id", "created_at"),
        Index("ix_skill_executions_org_created", "organization_id", "created_at"),
        Index("ix_skill_executions_status", "status"),
    )

class ErrorLog(Base):
    """Tracks errors and exceptions for audit and debugging."""
    __tablename__ = "error_logs"
    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    conversation_id = Column(String, nullable=True, index=True)
    user_id = Column(String, nullable=True, index=True)
    organization_id = Column(UUID(as_uuid=True), nullable=True, index=True)

    error_type = Column(String, nullable=False)
    error_code = Column(String)
    error_message = Column(Text, nullable=False)
    error_message_raw = Column(Text)
    severity = Column(String, nullable=False, default="error")

    component = Column(String)
    tool_name = Column(String)
    skill_name = Column(String)
    tool_call_id = Column(String)

    stack_trace = Column(Text)
    exception_type = Column(String)
    exception_args = Column(JSON)

    request_id = Column(String)
    model_key = Column(String)
    org_id = Column(String)
    client_id = Column(String)
    matter_id = Column(String)

    fallback_used = Column(Boolean, default=False)
    fallback_type = Column(String)
    fallback_details = Column(JSON)

    context = Column(JSON)

    error_metadata = Column("metadata", JSON)

    created_at = Column(DateTime(timezone=True), server_default=func.now())

    __table_args__ = (
        Index("ix_error_logs_conv_created", "conversation_id", "created_at"),
        Index("ix_error_logs_user_created", "user_id", "created_at"),
        Index("ix_error_logs_org_created", "organization_id", "created_at"),
        Index("ix_error_logs_type_severity", "error_type", "severity"),
        Index("ix_error_logs_created", "created_at"),
    )

class ApiKey(Base):
    __tablename__ = "api_keys"
    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    organization_id = Column(UUID(as_uuid=True), ForeignKey("organizations.id"), nullable=False)
    name = Column(String)
    hashed_key = Column(String, nullable=False)
    scopes = Column(JSON)
    created_by = Column(UUID(as_uuid=True), ForeignKey("users.id"))
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    revoked_at = Column(DateTime(timezone=True))
    __table_args__ = (UniqueConstraint("organization_id", "name", name="uq_api_keys_org_name"),)

