from __future__ import annotations

import time
from typing import Any, Dict, Optional

import httpx
from jose import jwt


class CognitoJWKsCache:
    def __init__(self, jwks_url: str, ttl_seconds: int = 3600):
        self.jwks_url = jwks_url
        self.ttl_seconds = ttl_seconds
        self._jwks: Optional[Dict[str, Any]] = None
        self._expires_at = 0.0

    async def get(self) -> Dict[str, Any]:
        now = time.time()
        if self._jwks is None or now >= self._expires_at:
            async with httpx.AsyncClient(timeout=10.0) as client:
                resp = await client.get(self.jwks_url)
                resp.raise_for_status()
                self._jwks = resp.json()
                self._expires_at = now + self.ttl_seconds
        return self._jwks or {}


class CognitoJWTVerifier:
    def __init__(self, region: str, user_pool_id: str, app_client_id: str, jwks_ttl: int = 3600):
        self.region = region
        self.user_pool_id = user_pool_id
        self.app_client_id = app_client_id
        self.issuer = f"https://cognito-idp.{region}.amazonaws.com/{user_pool_id}"
        self.jwks_url = f"{self.issuer}/.well-known/jwks.json"
        self._cache = CognitoJWKsCache(self.jwks_url, ttl_seconds=jwks_ttl)

    async def _get_key_for_kid(self, kid: str) -> Optional[Dict[str, Any]]:
        jwks = await self._cache.get()
        for key in jwks.get("keys", []):
            if key.get("kid") == kid:
                return key
        return None

    async def verify_and_decode(self, token: str) -> Dict[str, Any]:
        try:
            headers = jwt.get_unverified_header(token)
        except Exception as e:
            raise ValueError(f"Invalid header: {e}")

        kid = headers.get("kid")
        if not kid:
            raise ValueError("Missing 'kid' in token header.")

        key = await self._get_key_for_kid(kid)
        if not key:
            self._cache._expires_at = 0
            key = await self._get_key_for_kid(kid)
            if not key:
                raise ValueError("JWKS key not found for 'kid'.")

        try:
            claims = jwt.decode(
                token,
                key,
                algorithms=[key.get("alg", "RS256")],
                options={"verify_aud": False},
                issuer=self.issuer,
            )
        except Exception as e:
            raise ValueError(f"Invalid token: {e}")

        token_use = claims.get("token_use")
        if token_use not in ("id", "access"):
            raise ValueError("Invalid or missing token_use.")

        if token_use == "id":
            aud = claims.get("aud")
            if aud != self.app_client_id:
                raise ValueError("Invalid audience for ID token.")
        else:
            client_id = claims.get("client_id")
            if client_id != self.app_client_id:
                raise ValueError("Invalid client_id for Access token.")

        return claims
