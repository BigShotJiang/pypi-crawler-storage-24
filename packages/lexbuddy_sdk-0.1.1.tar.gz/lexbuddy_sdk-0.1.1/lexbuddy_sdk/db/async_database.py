from typing import AsyncGenerator, Optional
from urllib.parse import quote_plus
from sqlalchemy.ext.asyncio import create_async_engine, AsyncSession, AsyncEngine
from sqlalchemy.orm import sessionmaker


def create_async_db(
    postgres_user: str,
    postgres_password: str,
    postgres_host: str,
    postgres_port: int,
    postgres_db: str,
    ssl_mode: Optional[str] = None,
) -> tuple[AsyncEngine, sessionmaker, callable]:
    """
    Factory that creates an async SQLAlchemy engine, session factory, and get_db dependency.

    Usage in each service's db/async_database.py:

        from config.settings import settings
        from lexbuddy_sdk.db.async_database import create_async_db

        engine, SessionLocal, get_db = create_async_db(
            postgres_user=settings.POSTGRES_USER,
            postgres_password=settings.POSTGRES_PASSWORD,
            postgres_host=settings.POSTGRES_HOST,
            postgres_port=settings.POSTGRES_PORT,
            postgres_db=settings.POSTGRES_DB,
            ssl_mode=settings.POSTGRES_SSL_MODE,
        )
    """
    encoded_user = quote_plus(postgres_user)
    encoded_password = quote_plus(postgres_password)

    database_url = (
        f"postgresql+asyncpg://{encoded_user}:"
        f"{encoded_password}@{postgres_host}:"
        f"{postgres_port}/{postgres_db}"
    )

    connect_args = {"ssl": ssl_mode} if ssl_mode else {}

    engine = create_async_engine(
        database_url,
        echo=False,
        pool_pre_ping=True,
        connect_args=connect_args,
    )

    session_local = sessionmaker(
        bind=engine,
        class_=AsyncSession,
        expire_on_commit=False,
    )

    async def get_db() -> AsyncGenerator[AsyncSession, None]:
        async with session_local() as session:
            try:
                yield session
            finally:
                pass

    return engine, session_local, get_db
