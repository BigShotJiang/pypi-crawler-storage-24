"""
lexbuddy-sdk — Shared models, enums, auth, and utilities for LexBuddy backend services.
"""

__version__ = "0.1.0"
