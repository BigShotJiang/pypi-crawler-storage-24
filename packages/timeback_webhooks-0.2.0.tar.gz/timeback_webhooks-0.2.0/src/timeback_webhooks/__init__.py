"""
Timeback Webhooks Client

A Python client for managing webhook registrations and filters.

Example:
    ```python
    from timeback_webhooks import WebhooksClient

    async def main():
        client = WebhooksClient(
            env="staging",
            client_id="your-client-id",
            client_secret="your-client-secret",
        )

        webhook = await client.webhooks.create({
            "name": "My Webhook",
            "targetUrl": "https://myapp.example.com/events",
            "secret": "my-shared-secret",
            "active": True,
        })

        # Add a filter
        await client.webhook_filters.create({
            "webhookId": webhook.id,
            "filterKey": "type",
            "filterValue": "ActivityEvent",
            "filterType": "string",
            "filterOperator": "eq",
            "active": True,
        })
    ```
"""

from importlib.metadata import PackageNotFoundError, version

try:
    __version__ = version("timeback-webhooks")
except PackageNotFoundError:
    __version__ = "0.0.0"

from .client import WebhooksClient
from .exceptions import (
    APIError,
    AuthenticationError,
    ForbiddenError,
    InputValidationError,
    NotFoundError,
    RateLimitError,
    ServerError,
    TimebackError,
    ValidationError,
    ValidationIssue,
    WebhooksError,
    create_input_validation_error,
)
from .types import (
    FilterOperation,
    FilterType,
    Webhook,
    WebhookCreateInput,
    WebhookDeleteResponse,
    WebhookFilter,
    WebhookFilterCreateInput,
    WebhookFilterDeleteResponse,
    WebhookFilterListResponse,
    WebhookFilterResponse,
    WebhookFilterUpdateInput,
    WebhookListResponse,
    WebhookResponse,
    WebhookUpdateInput,
)

__all__ = [
    "APIError",
    "AuthenticationError",
    "FilterOperation",
    "FilterType",
    "ForbiddenError",
    "InputValidationError",
    "NotFoundError",
    "RateLimitError",
    "ServerError",
    "TimebackError",
    "ValidationError",
    "ValidationIssue",
    "Webhook",
    "WebhookCreateInput",
    "WebhookDeleteResponse",
    "WebhookFilter",
    "WebhookFilterCreateInput",
    "WebhookFilterDeleteResponse",
    "WebhookFilterListResponse",
    "WebhookFilterResponse",
    "WebhookFilterUpdateInput",
    "WebhookListResponse",
    "WebhookResponse",
    "WebhookUpdateInput",
    "WebhooksClient",
    "WebhooksError",
    "__version__",
    "create_input_validation_error",
]
