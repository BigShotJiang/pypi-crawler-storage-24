"""
Webhooks Exceptions

Re-exports common errors and adds Webhooks-specific exceptions.
"""

from timeback_common import (
    APIError,
    AuthenticationError,
    ForbiddenError,
    InputValidationError,
    NotFoundError,
    RateLimitError,
    ServerError,
    TimebackError,
    ValidationError,
    ValidationIssue,
    create_input_validation_error,
)

WebhooksError = TimebackError


__all__ = [
    "APIError",
    "AuthenticationError",
    "ForbiddenError",
    "InputValidationError",
    "NotFoundError",
    "RateLimitError",
    "ServerError",
    "TimebackError",
    "ValidationError",
    "ValidationIssue",
    "WebhooksError",
    "create_input_validation_error",
]
