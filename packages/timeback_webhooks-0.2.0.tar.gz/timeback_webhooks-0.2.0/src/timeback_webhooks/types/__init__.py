"""Webhooks type definitions."""

from .api import (
    FilterOperation,
    FilterType,
    Webhook,
    WebhookDeleteResponse,
    WebhookFilter,
    WebhookFilterDeleteResponse,
    WebhookFilterListResponse,
    WebhookFilterResponse,
    WebhookListResponse,
    WebhookResponse,
)
from .inputs import (
    WebhookCreateInput,
    WebhookFilterCreateInput,
    WebhookFilterUpdateInput,
    WebhookUpdateInput,
)

__all__ = [
    "FilterOperation",
    "FilterType",
    "Webhook",
    "WebhookCreateInput",
    "WebhookDeleteResponse",
    "WebhookFilter",
    "WebhookFilterCreateInput",
    "WebhookFilterDeleteResponse",
    "WebhookFilterListResponse",
    "WebhookFilterResponse",
    "WebhookFilterUpdateInput",
    "WebhookListResponse",
    "WebhookResponse",
    "WebhookUpdateInput",
]
