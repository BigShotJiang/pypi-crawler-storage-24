
{
    "version": "2026.3.17",
    "target": "default",
    "variant": "cpu"
}
