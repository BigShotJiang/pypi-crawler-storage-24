# tmam

[![PyPI version](https://badge.fury.io/py/tmam.svg)](https://pypi.org/project/tmam/)
[![License](https://img.shields.io/badge/License-Apache%202.0-blue.svg)](LICENSE)

OpenTelemetry-native auto-instrumentation library for monitoring LLM applications, enabling cost tracking, tracing, and observability for your GenAI projects.

## Installation

```bash
pip install tmam
```

## Quick Start

```python
import tmam
from openai import OpenAI

# Initialize tmam — auto-instruments all supported LLM providers
tmam.init(
    environment="production",
    application_name="my-llm-app",
)

# Use OpenAI as normal — calls are automatically traced
client = OpenAI()
response = client.chat.completions.create(
    model="gpt-4o",
    messages=[{"role": "user", "content": "Hello, world!"}],
)
print(response.choices[0].message.content)
# Traces with token counts, latency, and cost appear in your tmam dashboard
```

## Features

- **Auto-instrumentation** for 40+ LLM providers (OpenAI, Anthropic, Cohere, Mistral, Bedrock, VertexAI, and more)
- **Tracing** with `@tmam.trace()` decorator and `tmam.start_trace()` context manager
- **Metrics** collection for token usage, cost, latency, and request volume
- **Evaluations** with built-in evaluators for hallucination, bias, and toxicity detection
- **Experiments** for running dataset-driven evaluations with concurrency control
- **Vault** integration for secure secret retrieval
- **GPU monitoring** for GPU utilization and memory tracking

## Configuration

| Environment Variable | Description | Default |
|---------------------|-------------|---------|
| `OTEL_EXPORTER_OTLP_ENDPOINT` | tmam API endpoint | `https://api.tmam.ai` |
| `OTEL_EXPORTER_OTLP_HEADERS` | Headers including API key (`x-api-key=pk_xxx.sk_xxx`) | — |

| Init Parameter | Description | Default |
|---------------|-------------|---------|
| `environment` | Deployment environment name | `'default'` |
| `application_name` | Application name for grouping traces | `'default'` |
| `otlp_endpoint` | Override OTLP endpoint | env var |
| `otlp_headers` | Override OTLP headers dict | env var |

## Cost Allocation Tags

Track spending by team, department, or cost center using API key tags:

1. Go to **Settings > API Keys** in the platform
2. Add tags to your API key (e.g., `team: engineering`, `department: ML`)
3. View cost breakdowns by tag in **Cost Explorer**

## Guides

- [Error Handling & Troubleshooting](docs/error-handling.md)
- [FastAPI Integration](docs/fastapi-integration.md)
- [Changelog](docs/CHANGELOG.md)

## License

Apache 2.0 — see [LICENSE](LICENSE) for details.
