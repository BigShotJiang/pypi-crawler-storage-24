"""Monkey-patch an MCP ClientSession to capture telemetry and enforce governance."""

from __future__ import annotations

import logging
from typing import Any, Dict, List, Optional
from uuid import uuid4

from turingpulse_interfaces import ToolCallInfo

logger = logging.getLogger("turingpulse.sdk.mcp")

_MAX_RESULT_TEXT = 5000


def patch_mcp_client(
    session: Any,
    *,
    server_name: str = "unknown",
    governance: Optional[Dict[str, Any]] = None,
) -> None:
    """Patch an MCP ClientSession to add TuringPulse observability and governance.

    Wraps ``call_tool``, ``list_tools``, and ``read_resource`` to:
    1. Create spans with ``node_type="mcp_tool"``
    2. Run pre-execution policy checks (when HITL governance is enabled)
    3. Capture tool call results in the trace

    Args:
        session: An ``mcp.ClientSession`` instance.
        server_name: Human-readable name for the MCP server (appears in spans).
        governance: Optional governance config dict (``{"hitl": True}``).
    """
    governance_directive = _resolve_governance_directive(governance)
    _patch_call_tool(session, server_name=server_name, governance=governance_directive)
    _patch_read_resource(session, server_name=server_name, governance=governance_directive)
    logger.debug("Patched MCP ClientSession for server '%s'", server_name)


def _resolve_governance_directive(governance: Optional[Dict[str, Any]]) -> Any:
    if not governance:
        return None
    try:
        from turingpulse_sdk.governance import GovernanceDirective
        return GovernanceDirective(**governance)
    except Exception:
        logger.warning("Invalid governance config — governance will be disabled")
        return None


def _patch_call_tool(
    session: Any,
    *,
    server_name: str,
    governance: Any,
) -> None:
    original_call_tool = session.call_tool

    async def patched_call_tool(
        name: str, arguments: Optional[Dict[str, Any]] = None, **kwargs: Any
    ) -> Any:
        try:
            from turingpulse_sdk.plugin import get_plugin
            plugin = get_plugin()
        except Exception:
            return await original_call_tool(name, arguments, **kwargs)

        from turingpulse_sdk.context import ExecutionContext, bind_context, current_context
        from turingpulse_sdk.instrumentation import InstrumentationOptions
        from turingpulse_sdk.exceptions import GovernanceBlockedError

        parent = current_context()
        span_name = f"mcp.{server_name}.{name}"

        context = ExecutionContext(
            run_id=parent.run_id if parent else uuid4().hex,
            operation=span_name,
            parent_span_id=parent.span_id if parent else None,
            depth=(parent.depth + 1) if parent else 0,
            workflow_name=parent.workflow_name if parent else server_name,
            node_type="mcp_tool",
            tool_name=name,
            tool_args=arguments,
            mcp_server=server_name,
            fingerprint_builder=parent.fingerprint_builder if parent else None,
        )

        options = InstrumentationOptions(
            name=context.workflow_name,
            operation=span_name,
            governance=governance,
        )

        span_cm = plugin.tracing.span(
            span_name,
            attributes={
                "mcp.server": server_name,
                "mcp.tool_name": name,
                "node_type": "mcp_tool",
            },
            context=context,
        )

        with bind_context(context), span_cm:
            try:
                await plugin._pre_execution_policy_check_async(context, options)

                result = await original_call_tool(name, arguments, **kwargs)

                is_error = getattr(result, "isError", False)
                result_text = _extract_result_text(result)

                input_str = str(arguments) if arguments else ""
                context.set_io(
                    input_data=input_str[:_MAX_RESULT_TEXT],
                    output_data=result_text,
                )

                if result_text and not is_error:
                    await plugin._post_execution_policy_check_async(
                        context, options, result,
                    )

                context.add_tool_call(
                    tool_name=name,
                    tool_args=arguments or {},
                    tool_result=result_text,
                    success=not is_error,
                    error_message=str(result.content) if is_error else None,
                    mcp_server=server_name,
                )

                context.finish(result=result)
                return result

            except GovernanceBlockedError:
                context.finish(error=GovernanceBlockedError(
                    reason="MCP tool call blocked by policy",
                ))
                raise
            except Exception as exc:
                context.finish(error=exc)
                raise
            finally:
                try:
                    event = plugin.event_builder.build(context, options, [])
                    payload = plugin.client.serialize_events([event])
                    await plugin.client.emit_serialized_payload_async(payload)
                except Exception:
                    logger.debug("Failed to emit MCP tool call event for '%s'", name)

    session.call_tool = patched_call_tool


def _patch_read_resource(session: Any, *, server_name: str, governance: Any = None) -> None:
    original_read_resource = session.read_resource

    async def patched_read_resource(uri: str, **kwargs: Any) -> Any:
        try:
            from turingpulse_sdk.plugin import get_plugin
            plugin = get_plugin()
        except Exception:
            return await original_read_resource(uri, **kwargs)

        from turingpulse_sdk.context import ExecutionContext, bind_context, current_context
        from turingpulse_sdk.instrumentation import InstrumentationOptions
        from turingpulse_sdk.exceptions import GovernanceBlockedError

        parent = current_context()
        span_name = f"mcp.{server_name}.read_resource"

        context = ExecutionContext(
            run_id=parent.run_id if parent else uuid4().hex,
            operation=span_name,
            parent_span_id=parent.span_id if parent else None,
            depth=(parent.depth + 1) if parent else 0,
            workflow_name=parent.workflow_name if parent else server_name,
            node_type="mcp_tool",
            mcp_server=server_name,
            fingerprint_builder=parent.fingerprint_builder if parent else None,
        )

        options = InstrumentationOptions(
            name=context.workflow_name,
            operation=span_name,
            governance=governance,
        )

        span_cm = plugin.tracing.span(
            span_name,
            attributes={
                "mcp.server": server_name,
                "mcp.resource_uri": str(uri),
                "node_type": "mcp_tool",
            },
            context=context,
        )

        with bind_context(context), span_cm:
            try:
                await plugin._pre_execution_policy_check_async(context, options)

                result = await original_read_resource(uri, **kwargs)
                result_text = str(result)[:_MAX_RESULT_TEXT] if result else ""
                context.set_io(
                    input_data=str(uri),
                    output_data=result_text,
                )

                if result_text:
                    try:
                        post_result = await plugin.client.policy_check_async(
                            tool_name="read_resource",
                            mcp_server=server_name,
                            output_text=result_text[:10_000],
                            node_type="mcp_tool",
                            workflow_name=context.workflow_name,
                        )
                        if post_result.blocked:
                            raise GovernanceBlockedError(
                                reason=post_result.reason or "Resource read blocked by policy",
                                policy_ids=post_result.policy_ids,
                            )
                    except GovernanceBlockedError:
                        raise
                    except Exception:
                        if plugin.config.policy_fail_mode == "closed":
                            raise

                context.finish(result=result)
                return result
            except GovernanceBlockedError:
                context.finish(error=GovernanceBlockedError(
                    reason="MCP resource read blocked by policy",
                ))
                raise
            except Exception as exc:
                context.finish(error=exc)
                raise
            finally:
                try:
                    event = plugin.event_builder.build(context, options, [])
                    payload = plugin.client.serialize_events([event])
                    await plugin.client.emit_serialized_payload_async(payload)
                except Exception:
                    logger.debug(
                        "Failed to emit MCP resource read event for '%s'", uri,
                    )

    session.read_resource = patched_read_resource


def _extract_result_text(result: Any) -> str:
    """Extract text content from an MCP CallToolResult, capped for payload size."""
    try:
        if not hasattr(result, "content"):
            return str(result)[:_MAX_RESULT_TEXT]
        content_parts: List[Any] = (
            result.content if isinstance(result.content, list) else [result.content]
        )
        text_parts: List[str] = []
        for part in content_parts:
            if hasattr(part, "text"):
                text_parts.append(part.text)
        return "\n".join(text_parts)[:_MAX_RESULT_TEXT]
    except Exception:
        return ""
