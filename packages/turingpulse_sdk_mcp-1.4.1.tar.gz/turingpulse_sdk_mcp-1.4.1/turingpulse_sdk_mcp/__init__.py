"""TuringPulse SDK integration for Model Context Protocol (MCP)."""

from turingpulse_sdk_mcp._patcher import patch_mcp_client

__all__ = ["patch_mcp_client"]
