# Jinkies Monitor

Django infrastructure monitoring package that sends alerts to Slack via Jinkies.

## Features

- 🚀 **API Performance Monitoring** - Alert on slow requests (>2s)
- 🔴 **Error Rate Tracking** - Detect error spikes
- 🔍 **404 Monitoring** - Track missing endpoints
- 🔐 **Failed Login Detection** - Security monitoring
- 💾 **Redis Memory Alerts** - Memory usage tracking
- 📊 **Celery Queue Monitoring** - Task backlog alerts
- 💿 **Disk Space Alerts** - Storage monitoring
- 🌐 **External API Health** - Monitor Stripe, HubSpot, etc.
- ⚡ **Auto-deduplication** - Prevent alert spam

## Installation

```bash
pip install jinkies-monitor
```

## Quick Start

### 1. Add to INSTALLED_APPS

```python
INSTALLED_APPS = [
    # ...
    'jinkies_monitor',
]
```

### 2. Add Middleware

```python
MIDDLEWARE = [
    # ...
    'jinkies_monitor.middleware.InfrastructureMonitoringMiddleware',
    'jinkies_monitor.middleware.FailedLoginMonitorMiddleware',
]
```

### 3. Configure Settings

```python
JINKIES_MONITOR = {
    'WEBHOOK_URL': 'https://your-jinkies-webhook-url',
    'SERVICE_NAME': 'my-app',
    'ENVIRONMENT': 'production',
    
    # Thresholds
    'SLOW_REQUEST_THRESHOLD': 2.0,
    'ERROR_RATE_THRESHOLD': 20,
    '404_RATE_THRESHOLD': 50,
    'REDIS_MEMORY_THRESHOLD': 80,
    'CELERY_QUEUE_THRESHOLD': 100,
    
    # Enable/disable checks
    'CHECK_REDIS_MEMORY': True,
    'CHECK_CELERY_QUEUE': True,
    'CHECK_DISK_SPACE': True,
    'MONITOR_STRIPE': True,
}
```

### 4. Setup Celery Beat (Optional)

```python
from celery.schedules import crontab

CELERY_BEAT_SCHEDULE = {
    'check-redis-memory': {
        'task': 'jinkies_monitor.tasks.check_redis_memory',
        'schedule': crontab(minute='*/5'),
    },
    'check-celery-queue': {
        'task': 'jinkies_monitor.tasks.check_celery_queue',
        'schedule': crontab(minute='*/5'),
    },
    'check-disk-space': {
        'task': 'jinkies_monitor.tasks.check_disk_space',
        'schedule': crontab(minute='*/10'),
    },
}
```

## Configuration Options

| Setting | Default | Description |
|---------|---------|-------------|
| `WEBHOOK_URL` | `''` | Jinkies webhook URL (required) |
| `SERVICE_NAME` | `'django-app'` | Service identifier |
| `ENVIRONMENT` | `'production'` | Environment name |
| `SLOW_REQUEST_THRESHOLD` | `2.0` | Seconds before alerting |
| `ERROR_RATE_THRESHOLD` | `20` | Errors per 5 min |
| `404_RATE_THRESHOLD` | `50` | 404s per 5 min |
| `REDIS_MEMORY_THRESHOLD` | `80` | Percent |
| `CELERY_QUEUE_THRESHOLD` | `100` | Tasks |
| `DISK_SPACE_THRESHOLD` | `80` | Percent |
| `DEDUPE_WINDOW` | `300` | Seconds |
| `ENABLED` | `True` | Master switch |

## Manual Alerts

```python
from jinkies_monitor.utils import send_alert

send_alert(
    title="Custom Alert",
    message="Something important happened",
    severity="WARNING",
    fields={'Key': 'Value'},
    dedupe_key='my_alert'
)
```

## Requirements

- Django >= 4.0
- Celery >= 5.0 (optional, for periodic checks)
- Redis (optional, for caching)
- psutil >= 5.9

## License

MIT
