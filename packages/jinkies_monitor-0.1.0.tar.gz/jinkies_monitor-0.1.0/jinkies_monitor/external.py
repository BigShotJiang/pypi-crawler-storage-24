"""
External service monitoring
"""
import logging
import time
import requests
from .utils import send_alert
from .settings import get_setting

logger = logging.getLogger(__name__)


def check_external_api(name, url, timeout=5):
    """Check if external API is responding"""
    try:
        start = time.time()
        response = requests.get(url, timeout=timeout)
        duration = time.time() - start
        
        if response.status_code >= 500:
            send_alert(
                title=f"{name} API Error",
                message=f"{name} returned {response.status_code}",
                severity="CRITICAL",
                fields={'URL': url, 'Status': str(response.status_code), 'Duration': f"{duration:.2f}s"},
                dedupe_key=f"external:{name}"
            )
        elif duration > 3:
            send_alert(
                title=f"{name} API Slow",
                message=f"{name} response took {duration:.2f}s",
                severity="WARNING",
                fields={'URL': url, 'Duration': f"{duration:.2f}s"},
                dedupe_key=f"external_slow:{name}"
            )
    except requests.exceptions.Timeout:
        send_alert(
            title=f"{name} API Timeout",
            message=f"{name} did not respond within {timeout}s",
            severity="CRITICAL",
            fields={'URL': url, 'Timeout': f"{timeout}s"},
            dedupe_key=f"external_timeout:{name}"
        )
    except requests.exceptions.RequestException as e:
        send_alert(
            title=f"{name} API Unreachable",
            message=f"Failed to connect to {name}: {str(e)}",
            severity="CRITICAL",
            fields={'URL': url, 'Error': str(e)},
            dedupe_key=f"external_down:{name}"
        )


def monitor_stripe_webhooks():
    """Check Stripe webhook delivery status"""
    if not get_setting('MONITOR_STRIPE'):
        return
    
    try:
        import stripe
        from django.conf import settings
        
        stripe.api_key = settings.STRIPE_SECRET_KEY
        
        # Get recent webhook events
        events = stripe.Event.list(limit=100, type='*')
        
        failed_count = 0
        for event in events.auto_paging_iter():
            if hasattr(event, 'request') and event.request:
                # Check if webhook delivery failed
                if event.request.get('idempotency_key'):
                    failed_count += 1
        
        if failed_count > 5:
            send_alert(
                title="Stripe Webhook Failures",
                message=f"{failed_count} webhook deliveries failed",
                severity="WARNING",
                fields={'Failed': str(failed_count)},
                dedupe_key='stripe_webhooks'
            )
    except Exception as e:
        logger.error(f"Failed to check Stripe webhooks: {e}")
