"""
Signal handlers for automatic error alerting
"""
import logging
from django.core.signals import got_request_exception
from django.dispatch import receiver
from .utils import send_alert
from .settings import get_setting

logger = logging.getLogger(__name__)


@receiver(got_request_exception)
def handle_request_exception(sender, request, **kwargs):
    """Send alert on unhandled exceptions"""
    if not get_setting('ENABLED'):
        return
    
    import sys
    exc_info = sys.exc_info()
    if exc_info[0] is None:
        return
    
    exception = exc_info[1]
    
    # Skip common/expected exceptions
    skip_exceptions = ['Http404', 'PermissionDenied', 'ValidationError']
    if exception.__class__.__name__ in skip_exceptions:
        return
    
    import traceback
    stack_trace = ''.join(traceback.format_exception(*exc_info))
    
    send_alert(
        title=f"Unhandled Exception: {exception.__class__.__name__}",
        message=f"```{str(exception)[:500]}```",
        severity="CRITICAL",
        fields={
            'Path': request.path,
            'Method': request.method,
            'User': str(getattr(request.user, 'email', 'anonymous')),
            'Stack': f"```{stack_trace[:1000]}```"
        },
        dedupe_key=f"exception:{exception.__class__.__name__}:{request.path}"
    )
