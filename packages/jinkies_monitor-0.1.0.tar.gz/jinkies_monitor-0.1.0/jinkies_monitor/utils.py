"""
Utility functions for Jinkies Monitor
"""
import json
import logging
import threading
import time
import urllib.request
from django.core.cache import cache
from .settings import get_setting

logger = logging.getLogger(__name__)


def send_alert(title, message, severity='INFO', fields=None, dedupe_key=None):
    """Send alert to infrastructure channel"""
    if not get_setting('ENABLED'):
        return
    
    webhook_url = get_setting('WEBHOOK_URL')
    if not webhook_url:
        logger.warning("JINKIES_MONITOR WEBHOOK_URL not configured")
        return
    
    # Deduplication
    if dedupe_key:
        cache_key = f'jinkies:alert:{dedupe_key}'
        if cache.get(cache_key):
            return
        cache.set(cache_key, True, get_setting('DEDUPE_WINDOW'))
    
    emoji = {'CRITICAL': '🔴', 'WARNING': '⚠️', 'INFO': 'ℹ️', 'SUCCESS': '✅'}.get(severity, 'ℹ️')
    
    blocks = [
        {'type': 'header', 'text': {'type': 'plain_text', 'text': f"{emoji} {title}"}},
        {'type': 'section', 'text': {'type': 'mrkdwn', 'text': message}},
        {
            'type': 'context',
            'elements': [
                {'type': 'mrkdwn', 'text': f"*Service:* {get_setting('SERVICE_NAME')} | *Environment:* {get_setting('ENVIRONMENT')}"}
            ]
        }
    ]
    
    if fields:
        blocks.insert(2, {
            'type': 'section',
            'fields': [{'type': 'mrkdwn', 'text': f"*{k}:*\n{v}"} for k, v in fields.items()]
        })
    
    payload = {'blocks': blocks}
    
    def _send():
        try:
            req = urllib.request.Request(
                webhook_url,
                data=json.dumps(payload).encode('utf-8'),
                headers={'Content-Type': 'application/json'},
                method='POST'
            )
            urllib.request.urlopen(req, timeout=3)
        except Exception as e:
            logger.error(f"Failed to send Jinkies alert: {e}")
    
    threading.Thread(target=_send, daemon=True).start()
