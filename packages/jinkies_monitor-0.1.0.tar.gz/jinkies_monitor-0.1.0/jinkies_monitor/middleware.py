"""
Infrastructure monitoring middleware
"""
import time
import logging
from django.core.cache import cache
from .settings import get_setting
from .utils import send_alert

logger = logging.getLogger(__name__)


class InfrastructureMonitoringMiddleware:
    """Monitor API performance and errors"""
    
    def __init__(self, get_response):
        self.get_response = get_response
        self.enabled = get_setting('ENABLED')
    
    def __call__(self, request):
        if not self.enabled:
            return self.get_response(request)
        
        start_time = time.time()
        response = self.get_response(request)
        duration = time.time() - start_time
        
        # Track slow requests
        threshold = get_setting('SLOW_REQUEST_THRESHOLD')
        if duration > threshold:
            self._alert_slow_request(request, duration)
        
        # Track 404s
        if response.status_code == 404:
            self._track_404(request)
        
        # Track 5xx errors
        if 500 <= response.status_code < 600:
            self._track_error(request, response.status_code)
        
        return response
    
    def _alert_slow_request(self, request, duration):
        send_alert(
            title="Slow API Response",
            message=f"`{request.method} {request.path}` took {duration:.2f}s",
            severity="WARNING",
            fields={
                'Path': request.path,
                'Method': request.method,
                'Duration': f"{duration:.2f}s",
                'User': str(getattr(request.user, 'email', 'anonymous'))
            },
            dedupe_key=f"slow:{request.path}"
        )
    
    def _track_404(self, request):
        key = 'jinkies:404_count'
        count = cache.get(key, 0) + 1
        cache.set(key, count, 300)
        
        threshold = get_setting('404_RATE_THRESHOLD')
        if count == threshold:
            send_alert(
                title="404 Rate Spike",
                message=f"{threshold}+ 404 errors in 5 minutes",
                severity="WARNING",
                fields={'Count': str(count), 'Recent Path': request.path}
            )
    
    def _track_error(self, request, status_code):
        key = 'jinkies:error_count'
        count = cache.get(key, 0) + 1
        cache.set(key, count, 300)
        
        threshold = get_setting('ERROR_RATE_THRESHOLD')
        if count == threshold:
            send_alert(
                title="Error Rate Spike",
                message=f"{threshold}+ server errors in 5 minutes",
                severity="CRITICAL",
                fields={'Count': str(count), 'Status': str(status_code), 'Path': request.path}
            )


class FailedLoginMonitorMiddleware:
    """Monitor failed login attempts"""
    
    def __init__(self, get_response):
        self.get_response = get_response
        self.enabled = get_setting('ENABLED')
    
    def __call__(self, request):
        response = self.get_response(request)
        
        if not self.enabled:
            return response
        
        # Track failed logins on auth endpoints
        if '/auth/login' in request.path and response.status_code == 401:
            self._track_failed_login(request)
        
        return response
    
    def _track_failed_login(self, request):
        key = 'jinkies:failed_login_count'
        count = cache.get(key, 0) + 1
        cache.set(key, count, 300)
        
        threshold = get_setting('FAILED_LOGIN_THRESHOLD')
        if count == threshold:
            send_alert(
                title="Failed Login Spike",
                message=f"{threshold}+ failed login attempts in 5 minutes",
                severity="WARNING",
                fields={'Count': str(count), 'IP': request.META.get('REMOTE_ADDR', 'unknown')}
            )
