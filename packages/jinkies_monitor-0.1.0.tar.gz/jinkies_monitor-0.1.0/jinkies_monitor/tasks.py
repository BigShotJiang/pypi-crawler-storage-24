"""
Celery tasks for infrastructure monitoring
"""
from celery import shared_task
import psutil
import logging
from django.core.cache import cache
from .settings import get_setting
from .utils import send_alert

logger = logging.getLogger(__name__)


@shared_task
def check_redis_memory():
    """Check Redis memory usage"""
    if not get_setting('CHECK_REDIS_MEMORY'):
        return
    
    try:
        from django_redis import get_redis_connection
        redis_conn = get_redis_connection('default')
        info = redis_conn.info('memory')
        
        used = info['used_memory']
        max_memory = info.get('maxmemory', 0)
        
        if max_memory > 0:
            usage_pct = (used / max_memory) * 100
            threshold = get_setting('REDIS_MEMORY_THRESHOLD')
            
            if usage_pct > threshold:
                send_alert(
                    title="High Redis Memory Usage",
                    message=f"Redis memory at {usage_pct:.1f}%",
                    severity='CRITICAL' if usage_pct > 90 else 'WARNING',
                    fields={
                        'Usage': f"{usage_pct:.1f}%",
                        'Used': f"{used / 1024 / 1024:.1f} MB",
                        'Max': f"{max_memory / 1024 / 1024:.1f} MB"
                    },
                    dedupe_key='redis_memory'
                )
    except Exception as e:
        logger.error(f"Failed to check Redis memory: {e}")


@shared_task
def check_celery_queue():
    """Check Celery queue backlog"""
    if not get_setting('CHECK_CELERY_QUEUE'):
        return
    
    try:
        from celery import current_app
        inspect = current_app.control.inspect()
        active = inspect.active()
        reserved = inspect.reserved()
        
        total_tasks = 0
        if active:
            total_tasks += sum(len(tasks) for tasks in active.values())
        if reserved:
            total_tasks += sum(len(tasks) for tasks in reserved.values())
        
        threshold = get_setting('CELERY_QUEUE_THRESHOLD')
        if total_tasks > threshold:
            send_alert(
                title="High Celery Queue Backlog",
                message=f"{total_tasks} tasks in queue",
                severity='WARNING',
                fields={'Tasks': str(total_tasks), 'Threshold': str(threshold)},
                dedupe_key='celery_queue'
            )
    except Exception as e:
        logger.error(f"Failed to check Celery queue: {e}")


@shared_task
def check_disk_space():
    """Check disk space usage"""
    if not get_setting('CHECK_DISK_SPACE'):
        return
    
    try:
        disk = psutil.disk_usage('/')
        usage_pct = disk.percent
        threshold = get_setting('DISK_SPACE_THRESHOLD')
        
        if usage_pct > threshold:
            send_alert(
                title="High Disk Usage",
                message=f"Disk usage at {usage_pct}%",
                severity='CRITICAL' if usage_pct > 90 else 'WARNING',
                fields={
                    'Usage': f"{usage_pct}%",
                    'Used': f"{disk.used / 1024 / 1024 / 1024:.1f} GB",
                    'Free': f"{disk.free / 1024 / 1024 / 1024:.1f} GB",
                    'Total': f"{disk.total / 1024 / 1024 / 1024:.1f} GB"
                },
                dedupe_key='disk_space'
            )
    except Exception as e:
        logger.error(f"Failed to check disk space: {e}")


@shared_task
def send_infrastructure_alert_task(title, message, severity='INFO', fields=None):
    """Async task wrapper for sending alerts"""
    send_alert(title, message, severity, fields)
