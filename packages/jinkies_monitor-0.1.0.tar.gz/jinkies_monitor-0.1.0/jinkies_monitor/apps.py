from django.apps import AppConfig


class JinkiesMonitorConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'jinkies_monitor'
    verbose_name = 'Jinkies Infrastructure Monitor'
    
    def ready(self):
        from . import signals
