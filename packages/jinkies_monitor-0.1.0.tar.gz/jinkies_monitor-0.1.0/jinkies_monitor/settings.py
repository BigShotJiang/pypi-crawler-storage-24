"""
Default settings for Jinkies Monitor
Override these in your Django settings.py
"""

JINKIES_MONITOR_DEFAULTS = {
    # Required
    'WEBHOOK_URL': '',
    'SERVICE_NAME': 'django-app',
    'ENVIRONMENT': 'production',
    
    # Alert thresholds
    'SLOW_REQUEST_THRESHOLD': 2.0,  # seconds
    'ERROR_RATE_THRESHOLD': 20,  # errors per 5 min
    '404_RATE_THRESHOLD': 50,  # 404s per 5 min
    'FAILED_LOGIN_THRESHOLD': 10,  # failed logins per 5 min
    
    # Infrastructure checks (Celery periodic tasks)
    'CHECK_REDIS_MEMORY': True,
    'REDIS_MEMORY_THRESHOLD': 80,  # percent
    'CHECK_CELERY_QUEUE': True,
    'CELERY_QUEUE_THRESHOLD': 100,  # tasks
    'CHECK_DISK_SPACE': True,
    'DISK_SPACE_THRESHOLD': 80,  # percent
    
    # External service monitoring
    'MONITOR_STRIPE': True,
    'MONITOR_EXTERNAL_APIS': True,
    
    # Alert deduplication
    'DEDUPE_WINDOW': 300,  # seconds (5 min)
    
    # Enable/disable
    'ENABLED': True,
}


def get_setting(name):
    """Get Jinkies Monitor setting with fallback to defaults"""
    from django.conf import settings
    
    user_settings = getattr(settings, 'JINKIES_MONITOR', {})
    return user_settings.get(name, JINKIES_MONITOR_DEFAULTS.get(name))
