"""
Jinkies Monitor - Django infrastructure monitoring package
"""
__version__ = '0.1.0'

default_app_config = 'jinkies_monitor.apps.JinkiesMonitorConfig'
