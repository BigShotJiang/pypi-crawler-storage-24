from .results import (
    GreenWaterResults,
    HeatDemandResults,
    KPI,
    LoadProfileResults,
    PhotovoltaicResults,
    SimStadtResults,
    SolarPotentialResults,
    create_simstadt_results,
)
from .runner import run_workflow_with_citygml
from .workflows import greenwater_simulation, heatdemand_simulation, photovoltaic_simulation

__all__ = [
    "KPI",
    "SimStadtResults",
    "HeatDemandResults",
    "LoadProfileResults",
    "PhotovoltaicResults",
    "GreenWaterResults",
    "SolarPotentialResults",
    "create_simstadt_results",
    "run_workflow_with_citygml",
    "photovoltaic_simulation",
    "heatdemand_simulation",
    "greenwater_simulation",
]


def main() -> None:
    # TODO: Use argparse? e.g. for GUI or templates
    # TODO: return SimStadt result when ran with params? Display KPIS, df, and files
    import re
    from .runner import get_simstadt_folder, get_simstadt_output

    print("simstadt - Python library for SimStadt workflows.")
    print("See https://simstadt.hft-stuttgart.de/ for SimStadt documentation.")
    print()

    try:
        folder = get_simstadt_folder()
        print(f"SimStadt folder : {folder}")
    except ValueError as e:
        print(f"SimStadt folder : NOT FOUND\n{e}")
        return

    output = get_simstadt_output(folder)
    m = re.search(r"Launching SimStadt (\S+) \((\w+), rev\. (\w+), (\d\d\d\d)(\d\d)(\d\d)\)", output)
    if m:
        version, branch, commit, yyyy, mm, dd = m.groups()
        print(f"SimStadt version: {version} (branch: {branch}, rev: {commit}, date: {yyyy}-{mm}-{dd})")
    else:
        print("SimStadt version: unknown (could not parse version string)")
