from dataclasses import dataclass
from typing import ClassVar

import pandas as pd

from .base import SimStadtResults, detect_decimal
from .kpi import KPI
from .providers import Providers


@dataclass(repr=False)
class LoadProfileResults(SimStadtResults):
    """Results for LoadProfile workflows.

    The dataframe has one column per building (building GML ID as column name)
    and 8760 rows of hourly energy demand [kWh/h].
    """

    supported_providers: ClassVar[list[str]] = [Providers.LOAD_PROFILE]
    csv_identifier = "_load_profile_Hourly"

    def _parse_results(self) -> pd.DataFrame:
        csv_decimal = detect_decimal(self.csv_path, 6, "Area")
        df = pd.read_csv(self.csv_path, skiprows=range(1, 12), sep=";", decimal=csv_decimal)
        # First column is the timestamp; remaining columns are per-building loads
        return df.drop(columns=[df.columns[0]])

    @property
    def kpis(self) -> list[KPI]:
        # TODO: Add sum, average. Add timestep too?
        # TODO: Add people? Add total heated area?
        df = self.dataframe
        total = df.sum().sum()
        return [
            KPI("Number of buildings", df.shape[1], precision=0),
            KPI("Total load", total, "kWh/a", precision=1),
            KPI("Average load", total / 8760, "kWh/h", precision=1),
        ]
