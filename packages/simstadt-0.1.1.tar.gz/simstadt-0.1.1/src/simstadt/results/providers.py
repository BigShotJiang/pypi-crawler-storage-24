from enum import Enum


class Providers(str, Enum):
    HEAT_DEMAND = (
        "de.hftstuttgart.simstadtworkflows.energy.HeatDemandAnalysisWorkflowProvider"
    )
    HEAT_DEMAND_WITH_REFURBISHMENT = "de.hftstuttgart.simstadtworkflows.energy.HeatDemandAnalysisWithRefurbishmentStrategyWorkflowProvider"
    HEAT_DEMAND_WITH_HISTORIC_REFURBISHMENT = "de.hftstuttgart.simstadtworkflows.energy.HeatDemandAnalysisWithHistoricAndFutureRefurbishmentWorkflowProvider"
    HEAT_DEMAND_WITH_SHADOW = "de.hftstuttgart.simstadtworkflows.shadow.HeatDemandCalculationWithShadowProcessingProvider"
    PHOTOVOLTAIC = "de.hftstuttgart.simstadtworkflows.energy.PhotovoltaicPotentialAnalysisWorkflowProvider"
    PHOTOVOLTAIC_WITH_SHADOW = "de.hftstuttgart.simstadtworkflows.shadow.PVPotentialWithShadowProcessingProvider"
    PHOTOVOLTAIC_FINANCE = "de.hftstuttgart.simstadtworkflows.economics.PhotovoltaicPotentialFinancialAnalysisWorkflowProvider"
    GREEN_WATER = (
        "de.hftstuttgart.simstadtworkflows.greenwater.GreenWaterWorkflowProvider"
    )
    LOAD_PROFILE = "de.hftstuttgart.simstadtworkflows.energy.LoadProfileProvider"
    SOLAR_POTENTIAL = "de.hftstuttgart.simstadtworkflows.energy.SolarPotentialAnalysisWorkflowProvider"
