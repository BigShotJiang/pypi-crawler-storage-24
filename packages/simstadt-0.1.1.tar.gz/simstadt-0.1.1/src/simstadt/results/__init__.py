from .base import SimStadtResults, detect_decimal, get_workflow_provider
from .green_water import GreenWaterResults
from .heat_demand import HeatDemandResults
from .kpi import KPI
from .load_profile import LoadProfileResults
from .photovoltaic import PhotovoltaicResults
from .providers import Providers
from .solar_potential import SolarPotentialResults


def create_simstadt_results(description: str, output_files: list) -> SimStadtResults:
    """Factory: detect workflow type from params.xml and return the correct subclass."""
    provider = get_workflow_provider(output_files)
    return SimStadtResults.create(
        provider, description=description, output_files=sorted(output_files)
    )


__all__ = [
    "KPI",
    "Providers",
    "SimStadtResults",
    "HeatDemandResults",
    "PhotovoltaicResults",
    "LoadProfileResults",
    "SolarPotentialResults",
    "GreenWaterResults",
    "create_simstadt_results",
    "detect_decimal",
    "get_workflow_provider",
]
