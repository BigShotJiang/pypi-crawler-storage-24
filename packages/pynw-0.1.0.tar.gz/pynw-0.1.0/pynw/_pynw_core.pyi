from __future__ import annotations

import numpy as np
import numpy.typing as npt

def nw_traceback_indices(
    score_matrix: npt.NDArray[np.float64],
    gap_penalty_seq1: float,
    gap_penalty_seq2: float,
) -> tuple[float, npt.NDArray[np.intp], npt.NDArray[np.intp]]: ...
