<p align="center">
  <a href="https://api.moysklad.ru"><img src="https://www.moysklad.ru/upload/logos/logoMS500.png" alt="MoyskladAPI"></a>
</p>

<div align="center">

<p align="center">
Асинхронная библиотека для работы с API МойСклад
</p>

[![License: MIT](https://img.shields.io/badge/License-MIT-blue.svg)](https://opensource.org/licenses/MIT)
[![PyPI version](https://img.shields.io/pypi/v/moysklad-api.svg)](https://pypi.org/project/moysklad-api/)
[![Downloads](https://img.shields.io/pypi/dm/moysklad-api.svg)](https://pypi.python.org/pypi/moysklad-api)
[![Status](https://img.shields.io/badge/status-pre--alpha-8B5CF6.svg?logo=git&logoColor=white)]()
[![API Version](https://img.shields.io/badge/Мой_Склад_API-1.2-blue.svg)](https://dev.moysklad.ru/doc/api/remap/1.2/)

</div>

> [!CAUTION]
> Библиотека находится в активной разработке и 100% **не рекомендуется для использования в продакшн среде**.

## Установка

```console
pip install moysklad-api
```

## Пример использования

```python
import asyncio

from moysklad_api import MoyskladAPI, F


async def main():
    async with MoyskladAPI(token="your_token_here") as api:
        # Получение всех товаров
        products = await api.get_products(limit=None)
        print(products.rows)

        # Фильтрация: архивные товары с пустым описанием,
        # supplier заменяется объектом вместо ссылки
        archived = await api.get_products(
            filters=[
                F.archived == True,
                F.description.empty(),
            ],
            expand="supplier",
            limit=None,
        )
        for product in archived.rows:
            print(product.name, product.supplier)

        # Расширенный отчет об остатках
        stock = await api.get_stock()
        print(stock)

        # Отчёт прибыльности по товарам
        profit = await api.get_profit_by_product()
        print(profit)

asyncio.run(main())
```
