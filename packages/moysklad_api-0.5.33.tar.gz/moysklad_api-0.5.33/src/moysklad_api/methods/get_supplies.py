from collections.abc import Sequence

from ..filters.condition import Condition
from ..methods import MSMethod
from ..types import MetaArray, Supply


class GetSupplies(MSMethod):
    __return__ = MetaArray[Supply]
    __api_method__ = "entity/supply"

    limit: int | None = None
    offset: int | None = None
    expand: Sequence[str] | str | None = None
    filters: Condition | Sequence[Condition] | None = None
