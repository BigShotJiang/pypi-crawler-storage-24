from pydantic import Field

from ..methods.base import MSMethod
from ..types import PurchaseOrder


class UpdatePurchaseOrder(MSMethod[PurchaseOrder]):
    __return__ = PurchaseOrder
    __api_method__ = "entity/purchaseorder"

    id: str = Field(..., alias="purchaseorder_id")
    data: PurchaseOrder
