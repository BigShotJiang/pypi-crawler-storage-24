from ..methods.base import MSMethod
from ..types import Demand


class UpdateDemands(MSMethod[Demand]):
    __return__ = list[Demand]
    __api_method__ = "entity/demand"

    data: list[Demand]
