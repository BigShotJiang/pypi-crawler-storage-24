from collections.abc import Sequence

from ..filters.condition import Condition
from ..methods import MSMethod
from ..types import Demand, MetaArray


class GetDemands(MSMethod):
    __return__ = MetaArray[Demand]
    __api_method__ = "entity/demand"

    limit: int | None = None
    offset: int | None = None
    expand: Sequence[str] | str | None = None
    filters: Condition | Sequence[Condition] | None = None
