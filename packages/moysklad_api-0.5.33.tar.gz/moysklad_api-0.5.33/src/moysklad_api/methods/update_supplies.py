from ..methods.base import MSMethod
from ..types import Supply


class UpdateSupplies(MSMethod[Supply]):
    __return__ = list[Supply]
    __api_method__ = "entity/supply"

    data: list[Supply]
