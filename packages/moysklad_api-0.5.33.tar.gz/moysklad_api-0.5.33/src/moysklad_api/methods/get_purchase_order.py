from collections.abc import Sequence

from pydantic import Field

from ..filters.condition import Condition
from ..methods import MSMethod
from ..types import PurchaseOrder


class GetPurchaseOrder(MSMethod):
    __return__ = PurchaseOrder
    __api_method__ = "entity/purchaseorder"

    id: str = Field(..., alias="purchaseorder_id")
    limit: int | None = None
    offset: int | None = None
    expand: Sequence[str] | str | None = None
    filters: Condition | Sequence[Condition] | None = None
