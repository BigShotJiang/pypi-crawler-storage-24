from pydantic import Field

from ..methods.base import MSMethod
from ..types import Demand


class UpdateDemand(MSMethod[Demand]):
    __return__ = Demand
    __api_method__ = "entity/demand"

    id: str = Field(..., alias="demand_id")
    data: Demand
