from pydantic import Field

from ..enums import EntityType
from ..methods.base import MSMethod
from ..types import File


class DeleteFile(MSMethod[File]):
    __return__ = File
    __api_method__ = "entity/{entity_type}/{entity_id}/files"

    entity_type: EntityType = Field(..., alias="entity_type")
    entity_id: str = Field(..., alias="entity_id")
    id: str = Field(..., alias="file_id")
