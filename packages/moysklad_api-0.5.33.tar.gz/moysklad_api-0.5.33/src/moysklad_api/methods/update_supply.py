from pydantic import Field

from ..methods.base import MSMethod
from ..types import Supply


class UpdateSupply(MSMethod[Supply]):
    __return__ = Supply
    __api_method__ = "entity/supply"

    id: str = Field(..., alias="supply_id")
    data: Supply
