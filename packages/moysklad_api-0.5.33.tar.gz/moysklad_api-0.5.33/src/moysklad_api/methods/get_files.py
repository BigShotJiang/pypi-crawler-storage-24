from pydantic import Field

from ..enums import EntityType
from ..methods.base import MSMethod
from ..types import File, MetaArray


class GetFiles(MSMethod[MetaArray[File]]):
    __return__ = MetaArray[File]
    __api_method__ = "entity/{entity_type}/{entity_id}/files"

    entity_type: EntityType = Field(..., alias="entity_type")
    entity_id: str = Field(..., alias="entity_id")
    limit: int | None = None
