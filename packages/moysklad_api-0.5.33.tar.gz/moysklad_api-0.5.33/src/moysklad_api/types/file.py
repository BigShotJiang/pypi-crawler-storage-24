from datetime import datetime

from pydantic import BaseModel, Field

from .meta import Meta


class FileMiniature(BaseModel):
    href: str | None = None
    type: str | None = None
    media_type: str | None = Field(None, alias="mediaType")
    download_href: str | None = Field(None, alias="downloadHref")


class File(BaseModel):
    meta: Meta | None = None
    title: str | None = None
    filename: str | None = None
    size: int | None = None
    created: datetime | None = None
    content: str | None = None
    miniature: FileMiniature | None = None
    tiny: FileMiniature | None = None
