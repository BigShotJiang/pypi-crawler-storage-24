from datetime import datetime

from pydantic import Field

from .account import Account
from .agent import Agent
from .attribute import Attribute
from .contract import Contract
from .employee import Employee
from .entity import Entity
from .file import File
from .group import Group
from .meta_array import MetaArray
from .organization import Organization
from .overhead import Overhead
from .project import Project
from .rate import Rate
from .sales_channel import SalesChannel
from .state import State
from .store import Store
from .supply_position import SupplyPosition


class Supply(Entity):
    account_id: str | None = Field(None, alias="accountId")
    agent: Agent | None = Field(None, alias="agent")
    agent_account: Account | None = Field(None, alias="agentAccount")
    applicable: bool | None = Field(None, alias="applicable")
    attributes: list[Attribute] | None = Field(None, alias="attributes")
    code: str | None = Field(None, alias="code")
    contract: Contract | None = Field(None, alias="contract")
    created: datetime | None = Field(None, alias="created")
    deleted: datetime | None = Field(None, alias="deleted")
    description: str | None = Field(None, alias="description")
    external_code: str | None = Field(None, alias="externalCode")
    files: File | None = Field(None, alias="files")
    group: Group | None = Field(None, alias="group")
    id: str | None = Field(None, alias="id")
    incoming_date: datetime | None = Field(None, alias="incomingDate")
    incoming_number: str | None = Field(None, alias="incomingNumber")
    moment: datetime | None = Field(None, alias="moment")
    name: str | None = Field(None, alias="name")
    organization: Organization | None = Field(None, alias="organization")
    organization_account: Account | None = Field(None, alias="organizationAccount")
    overhead: Overhead | None = Field(None, alias="overhead")
    owner: Employee | None = Field(None, alias="owner")
    payed_sum: float | None = Field(None, alias="payedSum")
    positions: MetaArray[SupplyPosition] | SupplyPosition | None = Field(None, alias="positions")
    printed: bool | None = Field(None, alias="printed")
    project: Project | None = Field(None, alias="project")
    published: bool | None = Field(None, alias="published")
    rate: Rate | None = Field(None, alias="rate")
    sales_channel: SalesChannel | None = Field(None, alias="salesChannel")
    shared: bool | None = Field(None, alias="shared")
    state: State | None = Field(None, alias="state")
    store: Store | None = Field(None, alias="store")
    sum: float | None = Field(None, alias="sum")
    sync_id: str | None = Field(None, alias="syncId")
    updated: datetime | None = Field(None, alias="updated")
    vat_enabled: bool | None = Field(None, alias="vatEnabled")
    vat_included: bool | None = Field(None, alias="vatIncluded")
    vat_sum: float | None = Field(None, alias="vatSum")
