"""
Hooks de Behave para integrar Soft Assertions
"""
from hakalab_framework.core.soft_assertions import SoftAssertionManager


def before_scenario_soft_assertions(context, scenario):
    """
    Hook antes de cada escenario para inicializar soft assertions
    
    Si el escenario tiene el tag @soft_assertions, activa el modo automáticamente
    """
    # Inicializar manager si no existe
    if not hasattr(context, 'soft_assertions'):
        context.soft_assertions = SoftAssertionManager()
    
    # Verificar si el escenario tiene el tag @soft_assertions
    if 'soft_assertions' in scenario.tags:
        context.soft_assertions.enable()
        print(f"\n✓ Soft Assertions activadas para: {scenario.name}")
        print(f"  Los steps continuarán ejecutándose incluso si fallan\n")


def after_step_soft_assertions(context, step):
    """
    Hook después de cada step para permitir continuar después de un fallo
    
    Si soft assertions está activo y el step falló con AssertionError,
    captura el error pero NO modifica el status del step (se queda como failed).
    Limpia la excepción para que Behave continúe ejecutando los siguientes steps.
    """
    if not hasattr(context, 'soft_assertions'):
        return
    
    # Incrementar contador de steps
    if context.soft_assertions.is_enabled():
        context.soft_assertions.increment_step()
    
    # Si el step falló y soft assertions está activo
    if step.status.name == 'failed' and context.soft_assertions.is_enabled():
        # Verificar si el error es un AssertionError
        if step.exception and isinstance(step.exception, AssertionError):
            # Capturar el error para el resumen final
            error_msg = str(step.exception)
            context.soft_assertions.capture_error(step.name, step.exception)
            
            # CRÍTICO: NO modificar step.status (se queda como failed)
            # Solo limpiar la excepción para que Behave continúe
            step.exception = None
            step.error_message = None
            
            # Guardar el error original en el step para el reporte
            step.soft_assertion_error = error_msg
            
            # CRÍTICO: Forzar a Behave a continuar
            # Esto es necesario porque Behave detiene el escenario cuando un step falla
            if hasattr(context, '_runner'):
                # Limpiar el flag de error del runner
                if hasattr(context._runner, 'step_failed'):
                    context._runner.step_failed = False


def after_scenario_soft_assertions(context, scenario):
    """
    Hook después de cada escenario para mostrar resumen de errores
    
    Imprime un resumen de todos los errores capturados durante el escenario.
    El escenario ya está marcado como failed porque tiene steps fallidos.
    """
    if not hasattr(context, 'soft_assertions'):
        return
    
    # Si soft assertions está activo y hay errores
    if context.soft_assertions.is_enabled():
        if context.soft_assertions.has_errors():
            # Imprimir resumen
            summary = context.soft_assertions.get_summary()
            print(f"\n{'='*70}")
            print(f"📊 RESUMEN DE SOFT ASSERTIONS")
            print(f"{'='*70}")
            print(f"Total de validaciones fallidas: {summary['total_errors']}")
            print(f"{'='*70}")
            
            # Imprimir cada error
            for error in context.soft_assertions.errors:
                print(f"  ❌ [Step {error['step_number']}] {error['step_name']}")
                print(f"     {error['error']}")
            
            print(f"{'='*70}\n")
        
        # Desactivar soft assertions
        context.soft_assertions.disable()
    
    # Limpiar errores para el siguiente escenario
    if hasattr(context, 'soft_assertions'):
        context.soft_assertions.clear()
