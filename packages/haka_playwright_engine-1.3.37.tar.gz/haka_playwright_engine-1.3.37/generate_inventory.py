#!/usr/bin/env python3
"""
Script para generar inventario completo de pasos del framework Hakalab.

Este script analiza todos los archivos en hakalab_framework/steps/, extrae
los decoradores de pasos, los filtra y categoriza, y genera un archivo
.feature con el inventario completo organizado por funcionalidad.

Uso:
    python generate_inventory.py
"""

import os
import re
import glob
from dataclasses import dataclass
from typing import List, Dict, Set
from datetime import datetime
from collections import defaultdict


@dataclass
class StepDefinition:
    """Representa un paso extraído con sus metadatos."""
    text: str              # Texto del paso
    decorator_type: str    # @step, @given, @when, @then
    function_name: str     # Nombre de la función
    file_path: str         # Archivo de origen
    language: str          # 'es' o 'en'
    category: str = ''     # Categoría funcional (asignada después)


@dataclass
class CategoryMetadata:
    """Metadatos de una categoría."""
    name: str
    description: str
    order: int


class StepExtractor:
    """Extrae definiciones de pasos desde archivos Python."""
    
    # Patrón para encontrar decoradores de pasos
    STEP_PATTERN = re.compile(r'@(?:step|given|when|then)\([\'"](.+?)[\'"]\)')
    FUNCTION_PATTERN = re.compile(r'def\s+(\w+)\s*\(')
    
    def extract_from_file(self, file_path: str) -> List[StepDefinition]:
        """Extrae todos los pasos de un archivo Python."""
        steps = []
        
        try:
            with open(file_path, 'r', encoding='utf-8') as f:
                content = f.read()
                lines = content.split('\n')
                
            i = 0
            while i < len(lines):
                line = lines[i]
                
                # Buscar decorador de paso
                match = self.STEP_PATTERN.search(line)
                if match:
                    step_text = match.group(1)
                    decorator_type = line.strip().split('(')[0].replace('@', '')
                    
                    # Buscar la función asociada (puede estar varias líneas después)
                    function_name = ''
                    for j in range(i + 1, min(i + 10, len(lines))):
                        func_match = self.FUNCTION_PATTERN.search(lines[j])
                        if func_match:
                            function_name = func_match.group(1)
                            break
                    
                    # Detectar idioma
                    language = self._detect_language(step_text)
                    
                    step_def = StepDefinition(
                        text=step_text,
                        decorator_type=decorator_type,
                        function_name=function_name,
                        file_path=file_path,
                        language=language
                    )
                    steps.append(step_def)
                
                i += 1
                
        except Exception as e:
            print(f"⚠️ Error procesando {file_path}: {e}")
        
        return steps
    
    def extract_from_directory(self, directory_path: str) -> List[StepDefinition]:
        """Extrae todos los pasos de todos los archivos en un directorio."""
        all_steps = []
        
        # Buscar todos los archivos .py excepto __init__.py
        pattern = os.path.join(directory_path, '*.py')
        files = [f for f in glob.glob(pattern) if not f.endswith('__init__.py')]
        
        print(f"📂 Procesando {len(files)} archivos...")
        
        for file_path in sorted(files):
            steps = self.extract_from_file(file_path)
            all_steps.extend(steps)
            print(f"  ✓ {os.path.basename(file_path)}: {len(steps)} pasos")
        
        return all_steps
    
    def _detect_language(self, step_text: str) -> str:
        """Detecta el idioma de un paso."""
        # Palabras clave en español
        spanish_keywords = [
            'voy ', 'hago ', 'verifico ', 'espero ', 'aguardo ', 'valido ',
            'compruebo ', 'selecciono ', 'relleno ', 'escribo ', 'envío ',
            'recargo ', 'navego ', 'arrastro ', 'suelto ', 'presiono ',
            'guardo ', 'extraigo ', 'descargo ', 'subo ', 'consulta ',
            'el ', 'la ', 'los ', 'las ', 'que ', 'con ', 'en ', 'de '
        ]
        
        # Palabras clave en inglés
        english_keywords = [
            'I ', 'the ', 'a ', 'an ', 'is ', 'are ', 'should ', 'will ',
            'go ', 'click ', 'verify ', 'wait ', 'fill ', 'select ',
            'send ', 'reload ', 'navigate ', 'drag ', 'drop ', 'press '
        ]
        
        # Verificar palabras clave en español
        if any(kw in step_text.lower() for kw in spanish_keywords):
            return 'es'
        
        # Verificar palabras clave en inglés
        if any(step_text.startswith(kw) or f' {kw}' in step_text for kw in english_keywords):
            return 'en'
        
        # Heurística adicional: si contiene acentos, es español
        if any(c in step_text for c in 'áéíóúñÁÉÍÓÚÑ'):
            return 'es'
        
        # Por defecto, asumir inglés
        return 'en'


class StepFilter:
    """Filtra pasos según criterios específicos."""
    
    def filter_by_language(self, steps: List[StepDefinition], language: str) -> List[StepDefinition]:
        """Filtra pasos por idioma."""
        filtered = [s for s in steps if s.language == language]
        print(f"🔍 Filtrado por idioma '{language}': {len(filtered)}/{len(steps)} pasos")
        return filtered
    
    def remove_que_variants(self, steps: List[StepDefinition]) -> List[StepDefinition]:
        """Elimina variantes con 'que' al inicio si existe la versión base."""
        # Crear diccionario: paso_base -> [pasos]
        base_to_variants = defaultdict(list)
        
        for step in steps:
            if step.text.startswith('que '):
                base_text = step.text[4:]  # Remover "que "
                base_to_variants[base_text].append(('que', step))
            else:
                base_to_variants[step.text].append(('base', step))
        
        # Mantener solo la versión base si existe
        result = []
        removed_count = 0
        
        for base_text, variants in base_to_variants.items():
            # Buscar versión sin "que"
            base_versions = [s for t, s in variants if t == 'base']
            que_versions = [s for t, s in variants if t == 'que']
            
            if base_versions:
                # Si existe versión base, usar esa
                result.extend(base_versions)
                removed_count += len(que_versions)
            else:
                # Si solo existe versión con "que", mantenerla
                result.extend(que_versions)
        
        print(f"🔍 Eliminadas {removed_count} variantes 'que': {len(result)} pasos restantes")
        return result
    
    def remove_duplicates(self, steps: List[StepDefinition]) -> List[StepDefinition]:
        """Elimina pasos duplicados exactos."""
        seen_texts: Set[str] = set()
        unique_steps = []
        duplicates_count = 0
        
        for step in steps:
            if step.text not in seen_texts:
                seen_texts.add(step.text)
                unique_steps.append(step)
            else:
                duplicates_count += 1
        
        print(f"🔍 Eliminados {duplicates_count} duplicados: {len(unique_steps)} pasos únicos")
        return unique_steps


class StepCategorizer:
    """Clasifica pasos en categorías funcionales."""
    
    # Mapeo de archivo a categoría
    FILE_TO_CATEGORY = {
        'navigation_steps.py': ('Navegación', 'Navegar entre páginas, URLs, controlar historial', 1),
        'interaction_steps.py': ('Interacción con Elementos', 'Clicks, inputs, selección de elementos', 2),
        'web_elements_steps.py': ('Interacción con Elementos', 'Clicks, inputs, selección de elementos', 2),
        'validation_steps.py': ('Validación y Aserciones', 'Verificar estados, contenidos, propiedades', 3),
        'assertion_steps.py': ('Validación y Aserciones', 'Verificar estados, contenidos, propiedades', 3),
        'api_testing_steps.py': ('APIs y Servicios REST', 'Testing de APIs, peticiones HTTP, validación JSON', 4),
        'api_json_validation_steps.py': ('APIs y Servicios REST', 'Testing de APIs, peticiones HTTP, validación JSON', 4),
        'wait_steps.py': ('Esperas y Timing', 'Esperas explícitas, timeouts, sincronización', 5),
        'timing_steps.py': ('Esperas y Timing', 'Esperas explícitas, timeouts, sincronización', 5),
        'form_handling_steps.py': ('Formularios y Inputs Avanzados', 'Manejo de formularios complejos, validaciones', 6),
        'advanced_input_steps.py': ('Formularios y Inputs Avanzados', 'Manejo de formularios complejos, validaciones', 6),
        'table_steps.py': ('Tablas y Datos', 'Interacción con tablas, extracción de datos', 7),
        'data_extraction_steps.py': ('Tablas y Datos', 'Interacción con tablas, extracción de datos', 7),
        'modal_steps.py': ('Modales y Ventanas', 'Manejo de modales, popups, ventanas', 8),
        'window_steps.py': ('Modales y Ventanas', 'Manejo de modales, popups, ventanas', 8),
        'scroll_steps.py': ('Scroll y Viewport', 'Control de scroll, responsive testing', 9),
        'responsive_steps.py': ('Scroll y Viewport', 'Control de scroll, responsive testing', 9),
        'drag_drop_steps.py': ('Drag & Drop', 'Arrastrar y soltar elementos', 10),
        'keyboard_mouse_steps.py': ('Teclado y Mouse', 'Eventos de teclado y mouse avanzados', 11),
        'file_steps.py': ('Archivos', 'Manejo de archivos, uploads, downloads', 12),
        'csv_file_steps.py': ('Archivos', 'Manejo de archivos, uploads, downloads', 12),
        'pdf_steps.py': ('Archivos', 'Manejo de archivos, uploads, downloads', 12),
        'database_steps.py': ('Base de Datos', 'Consultas y validaciones de base de datos', 13),
        'email_steps.py': ('Email', 'Verificación de emails, SMTP', 14),
        'variable_steps.py': ('Variables y Contexto', 'Manejo de variables, contexto, entorno', 15),
        'environment_steps.py': ('Variables y Contexto', 'Manejo de variables, contexto, entorno', 15),
        'iframe_steps.py': ('Iframes', 'Cambio de contexto a iframes', 16),
        'combobox_steps.py': ('Combobox y Selectores', 'Interacción con combobox y selectores', 17),
        'combobox_validation_steps.py': ('Combobox y Selectores', 'Interacción con combobox y selectores', 17),
        'accessibility_steps.py': ('Accesibilidad', 'Testing de accesibilidad, ARIA', 18),
        'performance_steps.py': ('Performance', 'Medición de performance, métricas', 19),
        'ocr_steps.py': ('OCR', 'Reconocimiento óptico de caracteres', 20),
        'semantic_validation_steps.py': ('Semántica y NLP', 'Validación semántica, procesamiento de lenguaje natural', 21),
        'semantic_nlp_steps.py': ('Semántica y NLP', 'Validación semántica, procesamiento de lenguaje natural', 21),
        'semantic_advanced_steps.py': ('Semántica y NLP', 'Validación semántica, procesamiento de lenguaje natural', 21),
        'genai_advanced_steps.py': ('GenAI', 'Testing de modelos de IA generativa', 22),
        'genai_evaluation_steps.py': ('GenAI', 'Testing de modelos de IA generativa', 22),
        'salesforce_steps.py': ('Salesforce', 'Interacción con Salesforce', 23),
        'jira_xray_steps.py': ('Jira/Xray', 'Integración con Jira y Xray', 24),
        'browser_control_steps.py': ('Configuración de Browser', 'Control avanzado del navegador', 25),
        'browser_advanced_config_steps.py': ('Configuración de Browser', 'Control avanzado del navegador', 25),
        'advanced_steps.py': ('Avanzados', 'Pasos avanzados y misceláneos', 26),
    }
    
    def categorize(self, steps: List[StepDefinition]) -> Dict[str, List[StepDefinition]]:
        """Clasifica pasos en categorías funcionales."""
        categorized = defaultdict(list)
        
        for step in steps:
            filename = os.path.basename(step.file_path)
            
            if filename in self.FILE_TO_CATEGORY:
                category_name, _, _ = self.FILE_TO_CATEGORY[filename]
                step.category = category_name
                categorized[category_name].append(step)
            else:
                # Fallback: categoría "Avanzados"
                step.category = 'Avanzados'
                categorized['Avanzados'].append(step)
        
        print(f"📊 Categorizados en {len(categorized)} categorías")
        return dict(categorized)
    
    def get_category_metadata(self, category_name: str) -> CategoryMetadata:
        """Obtiene metadatos de una categoría."""
        for filename, (name, desc, order) in self.FILE_TO_CATEGORY.items():
            if name == category_name:
                return CategoryMetadata(name=name, description=desc, order=order)
        
        # Fallback para categoría no encontrada
        return CategoryMetadata(name=category_name, description='Pasos varios', order=999)
    
    def get_sorted_categories(self, categorized: Dict[str, List[StepDefinition]]) -> List[str]:
        """Retorna categorías ordenadas por su orden definido."""
        category_order = {}
        for cat_name in categorized.keys():
            metadata = self.get_category_metadata(cat_name)
            category_order[cat_name] = metadata.order
        
        return sorted(categorized.keys(), key=lambda x: category_order[x])


class FeatureGenerator:
    """Genera el archivo .feature final con formato."""
    
    def generate(self, categorized: Dict[str, List[StepDefinition]], output_path: str):
        """Genera el archivo .feature completo."""
        categorizer = StepCategorizer()
        sorted_categories = categorizer.get_sorted_categories(categorized)
        
        total_steps = sum(len(steps) for steps in categorized.values())
        
        with open(output_path, 'w', encoding='utf-8') as f:
            self._write_header(f, total_steps)
            
            for i, category_name in enumerate(sorted_categories, 1):
                steps = categorized[category_name]
                metadata = categorizer.get_category_metadata(category_name)
                self._write_category(f, i, metadata, steps)
        
        print(f"\n✅ Archivo generado: {output_path}")
        print(f"📊 Total de pasos: {total_steps}")
        print(f"📊 Total de categorías: {len(sorted_categories)}")
    
    def _write_header(self, file, total_steps: int):
        """Escribe el encabezado del archivo."""
        now = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        
        header = f"""# ============================================================================
# INVENTARIO COMPLETO DE PASOS - HAKALAB FRAMEWORK
# ============================================================================
# Este archivo contiene TODOS los pasos disponibles en el framework
# organizados por funcionalidad.
#
# IMPORTANTE: Este NO es un escenario ejecutable, es una REFERENCIA.
# Los pasos están sin palabras clave de Gherkin (Given/When/Then)
# para que puedas copiar y pegar según necesites.
#
# Versión: 1.3.17+
# Fecha: {now}
# Total de pasos: {total_steps}
# ============================================================================

"""
        file.write(header)
    
    def _write_category(self, file, number: int, metadata: CategoryMetadata, steps: List[StepDefinition]):
        """Escribe una categoría completa con sus pasos."""
        separator = f"\n# {'=' * 76}\n"
        file.write(separator)
        file.write(f"# {number}. {metadata.name.upper()}\n")
        file.write(separator)
        file.write(f"# Uso: {metadata.description}\n")
        file.write(f"# Total: {len(steps)} pasos\n\n")
        
        # Ordenar pasos alfabéticamente
        sorted_steps = sorted(steps, key=lambda s: s.text)
        
        for step in sorted_steps:
            file.write(f"{step.text}\n")
        
        file.write("\n")


def main():
    """Función principal del script."""
    print("=" * 80)
    print("GENERADOR DE INVENTARIO DE PASOS - HAKALAB FRAMEWORK")
    print("=" * 80)
    print()
    
    # Validar que existe el directorio de steps
    steps_dir = 'hakalab_framework/steps/'
    if not os.path.exists(steps_dir):
        print(f"❌ Error: Directorio {steps_dir} no encontrado")
        return 1
    
    # 1. Extraer pasos
    print("📝 PASO 1: Extrayendo pasos de archivos Python...")
    extractor = StepExtractor()
    all_steps = extractor.extract_from_directory(steps_dir)
    print(f"✓ Total extraído: {len(all_steps)} pasos\n")
    
    # 2. Filtrar pasos
    print("🔍 PASO 2: Filtrando pasos...")
    step_filter = StepFilter()
    
    # Filtrar por idioma español
    filtered_steps = step_filter.filter_by_language(all_steps, 'es')
    
    # Eliminar variantes "que"
    filtered_steps = step_filter.remove_que_variants(filtered_steps)
    
    # Eliminar duplicados
    filtered_steps = step_filter.remove_duplicates(filtered_steps)
    print()
    
    # 3. Categorizar pasos
    print("📊 PASO 3: Categorizando pasos...")
    categorizer = StepCategorizer()
    categorized = categorizer.categorize(filtered_steps)
    print()
    
    # 4. Generar archivo
    print("📄 PASO 4: Generando archivo .feature...")
    output_file = 'TODOS_LOS_PASOS_DISPONIBLES.feature'
    generator = FeatureGenerator()
    generator.generate(categorized, output_file)
    
    print("\n" + "=" * 80)
    print("✅ PROCESO COMPLETADO EXITOSAMENTE")
    print("=" * 80)
    
    return 0


if __name__ == '__main__':
    exit(main())
