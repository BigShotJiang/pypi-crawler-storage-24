#include <veda/device.h>
