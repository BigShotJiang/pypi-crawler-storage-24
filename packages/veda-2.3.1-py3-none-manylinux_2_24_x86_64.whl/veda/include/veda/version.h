#pragma once

#define VEDA_VERSION "2.3.1"
