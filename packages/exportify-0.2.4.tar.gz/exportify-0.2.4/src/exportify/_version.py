# SPDX-FileCopyrightText: 2026 Knitli Inc.
# SPDX-License-Identifier: MIT OR Apache-2.0
"""Version information for Exportify."""
from typing import Final


__version__: Final[str] = "0.2.4"

__all__ = ("__version__",)
