"""
Config 配置类型存根

提供 VSCode/Pylance 类型提示支持。
"""
from dataclasses import dataclass
from typing import Optional, Dict, Any


@dataclass
class Config:
    """Playwright-EZ 配置"""

    # 浏览器配置
    headless: bool
    browser_type: str

    # 窗口配置
    maximize_window: bool
    viewport_width: Optional[int]
    viewport_height: Optional[int]

    # 弹窗配置
    auto_close_popup: bool
    popup_close_timeout: float

    # 高亮配置
    highlight_enabled: bool
    highlight_color: str
    highlight_duration: float
    highlight_style: str

    # 等待配置
    default_timeout: float
    poll_interval: float
    stability_threshold: int

    # 日志配置
    log_enabled: bool
    log_level: str
    log_format: str
    log_to_file: bool
    log_file_path: str
    log_file_rotation: str
    log_file_retention: str

    # 多标签配置
    max_tabs: int

    # 截图配置
    screenshot_on_error: bool
    screenshot_dir: str

    # 反检测配置
    stealth_enabled: bool
    stealth_user_agent: Optional[str]
    stealth_locale: Optional[str]
    stealth_timezone: Optional[str]
    stealth_viewport: Optional[dict]

    # 人类化操作配置
    human_behavior_enabled: bool
    human_type_delay_min: int
    human_type_delay_max: int
    human_mouse_steps: int
    human_scroll_steps: int

    # 自定义参数
    extra_params: Dict[str, Any]

    def setup_logger(self) -> Any: ...

    # ==================== 序列化方法 ====================
    def to_dict(self) -> Dict[str, Any]: ...
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "Config": ...
    def to_json(self, indent: int = 2) -> str: ...
    @classmethod
    def from_json(cls, json_str: str) -> "Config": ...
    def save(self, filepath: str) -> None: ...
    @classmethod
    def load(cls, filepath: str) -> "Config": ...
    def merge(self, **kwargs) -> "Config": ...
    def copy(self) -> "Config": ...

    # ==================== 自定义参数方法 ====================
    def get_extra(self, key: str, default: Any = None) -> Any: ...
    def set_extra(self, key: str, value: Any) -> None: ...
    def update_extra(self, params: Dict[str, Any]) -> None: ...
    def delete_extra(self, key: str) -> bool: ...
    def clear_extra(self) -> None: ...
    def has_extra(self, key: str) -> bool: ...


def get_config() -> Config: ...
def set_config(config: Config) -> None: ...
