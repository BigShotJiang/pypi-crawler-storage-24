"""
测试辅助模块
提供可访问性检查、测试数据工厂、Mock服务器、测试隔离、报告生成、录制器、代码生成器等功能
"""
from .accessibility_checker import (
    AccessibilityChecker,
    AccessibilityCheckResult,
    AccessibilityCheckConfig,
    AccessibilityViolation,
    AccessibilityPass,
    AccessibilityNode,
    create_accessibility_checker,
)
from .test_data_factory import (
    TestDataFactory,
    FactoryConfig,
    FakeUser,
    FakeProduct,
    FakeOrder,
    UserFactory,
    ProductFactory,
    OrderFactory,
    create_user_factory,
    create_product_factory,
    create_order_factory,
)
from .mock_server import (
    MockServer,
    MockConfig,
    MockResponse,
    RequestLog,
    create_mock_server,
)
from .test_isolator import (
    TestIsolator,
    IsolationConfig,
    IsolationContext,
    IsolationResult,
    create_test_isolator,
)
from .test_reporter import (
    TestReporter,
    ReportConfig,
    TestCase,
    TestStep,
    TestStatus,
    ReportSummary,
    create_test_reporter,
)
from .auto_recorder import (
    AutoRecorder,
    AutoRecorderConfig,
    RecordedAction,
    RecordingSession,
    create_auto_recorder,
)
from .code_generator import (
    CodeGenerator,
    CodeGeneratorConfig,
    GeneratedCode,
    create_code_generator,
)

__all__ = [
    # 可访问性检查
    "AccessibilityChecker",
    "AccessibilityCheckResult",
    "AccessibilityCheckConfig",
    "AccessibilityViolation",
    "AccessibilityPass",
    "AccessibilityNode",
    "create_accessibility_checker",
    # 测试数据工厂
    "TestDataFactory",
    "FactoryConfig",
    "FakeUser",
    "FakeProduct",
    "FakeOrder",
    "UserFactory",
    "ProductFactory",
    "OrderFactory",
    "create_user_factory",
    "create_product_factory",
    "create_order_factory",
    # Mock 服务器
    "MockServer",
    "MockConfig",
    "MockResponse",
    "RequestLog",
    "create_mock_server",
    # 测试隔离
    "TestIsolator",
    "IsolationConfig",
    "IsolationContext",
    "IsolationResult",
    "create_test_isolator",
    # 测试报告
    "TestReporter",
    "ReportConfig",
    "TestCase",
    "TestStep",
    "TestStatus",
    "ReportSummary",
    "create_test_reporter",
    # 自动录制器
    "AutoRecorder",
    "AutoRecorderConfig",
    "RecordedAction",
    "RecordingSession",
    "create_auto_recorder",
    # 代码生成器
    "CodeGenerator",
    "CodeGeneratorConfig",
    "GeneratedCode",
    "create_code_generator",
]
