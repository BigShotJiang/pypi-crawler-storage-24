"""
浏览器模块 - 门面导入

此文件保持向后兼容，实际实现已重构到 browser/ 子模块。
"""
from .browser import EasyBrowser, Tab, BrowserCore
from .browser.mixins import (
    TabManagerMixin,
    NavigationMixin,
    ElementsMixin,
    WindowMixin,
    BatchMixin,
    PropertiesMixin,
)

__all__ = [
    "EasyBrowser",
    "Tab",
    "BrowserCore",
    "TabManagerMixin",
    "NavigationMixin",
    "ElementsMixin",
    "WindowMixin",
    "BatchMixin",
    "PropertiesMixin",
]
