"""
LLM 提供商工厂
根据配置创建对应的 LLM 提供商实例
"""
from typing import Optional

from .base import BaseLLMProvider
from .claude import ClaudeProvider
from .openai import OpenAIProvider
from .ollama import OllamaProvider
from .custom import CustomProvider
from ..types import LLMConfig, LLMProvider as ProviderEnum


def create_llm_provider(config: LLMConfig) -> Optional[BaseLLMProvider]:
    """
    创建 LLM 提供商实例

    Args:
        config: LLM 配置

    Returns:
        BaseLLMProvider: LLM 提供商实例，如果 provider 为 RULE 则返回 None

    Raises:
        ValueError: 不支持的 LLM 提供商
    """
    providers = {
        ProviderEnum.CLAUDE: ClaudeProvider,
        ProviderEnum.OPENAI: OpenAIProvider,
        ProviderEnum.OLLAMA: OllamaProvider,
        ProviderEnum.CUSTOM: CustomProvider,
    }

    # RULE 提供商不需要 LLM 实例
    if config.provider == ProviderEnum.RULE:
        return None

    provider_class = providers.get(config.provider)
    if provider_class is None:
        raise ValueError(f"不支持的 LLM 提供商: {config.provider}")

    return provider_class(config)
