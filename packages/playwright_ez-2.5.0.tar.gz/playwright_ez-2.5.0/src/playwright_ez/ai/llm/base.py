"""
LLM 提供商基类
定义统一的 LLM 调用接口
"""
from abc import ABC, abstractmethod
from dataclasses import dataclass
from typing import Optional


@dataclass
class LLMResponse:
    """LLM 响应"""
    content: str
    success: bool
    error: Optional[str] = None
    tokens_used: int = 0


class BaseLLMProvider(ABC):
    """LLM 提供商基类"""

    @abstractmethod
    async def call(self, prompt: str, system_prompt: Optional[str] = None) -> LLMResponse:
        """
        调用 LLM

        Args:
            prompt: 用户提示
            system_prompt: 系统提示

        Returns:
            LLMResponse: LLM 响应
        """
        pass

    @abstractmethod
    async def is_available(self) -> bool:
        """
        检查 LLM 是否可用

        Returns:
            bool: 是否可用
        """
        pass
