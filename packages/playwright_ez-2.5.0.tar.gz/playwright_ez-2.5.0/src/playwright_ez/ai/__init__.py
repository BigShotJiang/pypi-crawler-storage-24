"""
AI 辅助模块
集成 AI 能力增强自动化，支持智能选择器、错误诊断、代码生成
支持 LLM 混合模式（Claude、OpenAI、Ollama、自定义）

子模块:
- types: 类型定义
- finder: 智能元素查找器
- analyzer: 页面和内容分析器
- healer: 自动修复器
- helper: AI 辅助主类
- llm: LLM 提供商（Claude、OpenAI、Ollama、自定义）
- engine: 引擎模块（规则引擎、混合引擎）
"""

from .types import (
    AIConfig,
    LLMConfig,
    LLMProvider,
    SelectorSuggestion,
    ErrorDiagnosis,
    CodeSuggestion,
)

from .finder import SmartElementFinder
from .analyzer import PageAnalyzer, ContentAnalyzer
from .healer import AutoHealer
from .helper import AIHelper, create_ai_helper

# LLM 子模块
from .llm import (
    BaseLLMProvider,
    LLMResponse,
    create_llm_provider,
    ClaudeProvider,
    OpenAIProvider,
    OllamaProvider,
    CustomProvider,
)

# 引擎子模块
from .engine import (
    BaseEngine,
    RuleEngine,
    HybridEngine,
)

__all__ = [
    # 类型定义
    "AIConfig",
    "LLMConfig",
    "LLMProvider",
    "SelectorSuggestion",
    "ErrorDiagnosis",
    "CodeSuggestion",
    # 核心类
    "SmartElementFinder",
    "PageAnalyzer",
    "ContentAnalyzer",
    "AutoHealer",
    "AIHelper",
    # LLM 模块
    "BaseLLMProvider",
    "LLMResponse",
    "create_llm_provider",
    "ClaudeProvider",
    "OpenAIProvider",
    "OllamaProvider",
    "CustomProvider",
    # 引擎模块
    "BaseEngine",
    "RuleEngine",
    "HybridEngine",
    # 工厂函数
    "create_ai_helper",
]
