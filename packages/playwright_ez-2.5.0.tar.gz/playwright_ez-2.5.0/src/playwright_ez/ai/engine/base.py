"""
引擎基类
定义统一的 AI 引擎接口
"""
from abc import ABC, abstractmethod
from typing import Optional, List

from ..types import SelectorSuggestion, ErrorDiagnosis, CodeSuggestion


class BaseEngine(ABC):
    """AI 引擎基类"""

    @abstractmethod
    async def suggest_selectors(
        self,
        description: str,
        element_type: Optional[str] = None,
    ) -> List[SelectorSuggestion]:
        """
        根据描述建议选择器

        Args:
            description: 元素描述
            element_type: 元素类型

        Returns:
            List[SelectorSuggestion]: 选择器建议列表
        """
        pass

    @abstractmethod
    async def diagnose_error(
        self,
        error: Exception,
        context: Optional[dict] = None,
    ) -> ErrorDiagnosis:
        """
        诊断错误

        Args:
            error: 错误对象
            context: 上下文信息

        Returns:
            ErrorDiagnosis: 诊断结果
        """
        pass

    @abstractmethod
    async def generate_test_code(
        self,
        scenario: str,
        include_assertions: bool = True,
    ) -> CodeSuggestion:
        """
        生成测试代码

        Args:
            scenario: 测试场景
            include_assertions: 是否包含断言

        Returns:
            CodeSuggestion: 代码建议
        """
        pass
