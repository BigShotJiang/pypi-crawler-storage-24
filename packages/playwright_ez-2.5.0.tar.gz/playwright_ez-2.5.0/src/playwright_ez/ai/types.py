"""
AI 辅助模块类型定义
"""
from dataclasses import dataclass, field
from enum import Enum
from typing import List, Optional, Callable


class LLMProvider(Enum):
    """LLM 提供商"""
    RULE = "rule"           # 纯规则引擎
    CLAUDE = "claude"       # Anthropic Claude
    OPENAI = "openai"       # OpenAI GPT
    OLLAMA = "ollama"       # Ollama 本地模型
    CUSTOM = "custom"       # 自定义模型


@dataclass
class LLMConfig:
    """LLM 配置"""
    provider: LLMProvider = LLMProvider.RULE

    # Claude 配置
    claude_api_key: Optional[str] = None
    claude_model: str = "claude-sonnet-4-20250514"

    # OpenAI 配置
    openai_api_key: Optional[str] = None
    openai_model: str = "gpt-4o"
    openai_base_url: Optional[str] = None

    # Ollama 配置
    ollama_base_url: str = "http://localhost:11434"
    ollama_model: str = "llama3"

    # 自定义配置
    custom_call_fn: Optional[Callable[[str], str]] = None

    # 通用配置
    temperature: float = 0.7
    max_tokens: int = 1024
    timeout: int = 30


@dataclass
class AIConfig:
    """AI 配置"""
    enable_healing: bool = True
    enable_suggestions: bool = True
    max_suggestions: int = 5
    context_window: int = 1000

    # LLM 配置
    llm: LLMConfig = field(default_factory=LLMConfig)

    # 混合模式配置
    use_llm_first: bool = True          # 优先使用 LLM
    fallback_to_rule: bool = True       # LLM 失败时回退到规则引擎


@dataclass
class SelectorSuggestion:
    """选择器建议"""
    selector: str
    confidence: float
    strategy: str
    element_type: str
    description: str = ""


@dataclass
class ErrorDiagnosis:
    """错误诊断结果"""
    error_type: str
    likely_causes: List[str]
    suggested_solutions: List[str]
    related_elements: List[str] = field(default_factory=list)


@dataclass
class CodeSuggestion:
    """代码建议"""
    code: str
    description: str
    language: str = "python"
    confidence: float = 0.8
