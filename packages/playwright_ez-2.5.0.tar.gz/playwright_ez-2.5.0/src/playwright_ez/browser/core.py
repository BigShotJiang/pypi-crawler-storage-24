"""
浏览器核心类 - 初始化和关闭逻辑
"""
from typing import Optional, TYPE_CHECKING, Callable, Any, List
import gc
import time
from pathlib import Path

from playwright.async_api import (
    async_playwright,
    Browser,
    BrowserContext,
    Playwright,
)
from loguru import logger

from ..config import Config, get_config
from ..highlight import ElementHighlighter
from ..wait import SmartWait

if TYPE_CHECKING:
    from .tab import Tab
    from ..video import VideoManager, VideoRecorder


class BrowserCore:
    """
    浏览器核心功能 - 初始化和关闭

    这是所有 Mixin 的基类，提供：
    - __init__: 初始化配置和内部状态
    - start(): 启动浏览器
    - close(): 关闭浏览器
    - __aenter__, __aexit__: 上下文管理器
    - 内存优化和性能监控
    """

    # 类级别的预热状态
    _playwright_warmed: bool = False

    def __init__(self, config: Optional[Config] = None):
        self.config = config or get_config()
        self._playwright: Optional[Playwright] = None
        self._browser: Optional[Browser] = None
        self._context: Optional[BrowserContext] = None
        self._tabs: dict[str, "Tab"] = {}
        self._current_tab: Optional[str] = None

        # 原有模块
        self.highlighter = ElementHighlighter(self.config)
        self.smart_wait = SmartWait(self.config)

        self._tab_counter = 0

        # 核心模块懒加载属性
        self._network = None
        self._interceptor = None
        self._cookies = None
        self._session = None
        self._form = None
        self._visual = None
        self._recorder = None
        self._performance = None
        self._file = None
        self._extractor = None

        # 辅助类懒加载属性
        self._automation = None
        self._diagnostics = None
        self._scraper = None
        self._test = None
        self._monitor = None
        self._security = None
        self._ai = None

        # 新增懒加载属性
        self._selector = None
        self._popup = None
        self._mobile = None
        self._generator = None
        self._assertions = None
        self._state = None
        self._recovery = None

        # 视频录制
        self._video_manager: Optional["VideoManager"] = None
        self._video_recorder: Optional["VideoRecorder"] = None

        # 性能监控
        self._start_time: Optional[float] = None
        self._memory_hooks: list[Callable] = []

    async def start(self) -> "EasyBrowser":
        """启动浏览器"""
        from ..anti_detection import AntiDetection
        from .tab import Tab

        self._start_time = time.time()
        logger.info(f"启动浏览器: type={self.config.browser_type}, headless={self.config.headless}")

        self._playwright = await async_playwright().start()

        if self.config.browser_type == "chromium":
            browser_launcher = self._playwright.chromium
        elif self.config.browser_type == "firefox":
            browser_launcher = self._playwright.firefox
        elif self.config.browser_type == "webkit":
            browser_launcher = self._playwright.webkit
        else:
            raise ValueError(f"不支持的浏览器类型: {self.config.browser_type}")

        self._browser = await browser_launcher.launch(headless=self.config.headless)

        # 准备上下文选项
        context_options = {}

        # 窗口最大化或自定义视口
        if self.config.maximize_window:
            # 获取屏幕尺寸并设置为视口
            # 注意：需要在有界面的环境下才能获取真实屏幕尺寸
            context_options["viewport"] = None  # 让浏览器自动决定
            context_options["screen"] = {"width": 1920, "height": 1080}  # 默认大屏
        elif self.config.viewport_width and self.config.viewport_height:
            context_options["viewport"] = {
                "width": self.config.viewport_width,
                "height": self.config.viewport_height,
            }

        # 应用反检测配置
        if self.config.stealth_enabled:
            stealth_options = AntiDetection.get_context_options(
                user_agent=self.config.stealth_user_agent,
                viewport=self.config.stealth_viewport,
                locale=self.config.stealth_locale,
                timezone=self.config.stealth_timezone,
            )
            # 合并反检测选项（不覆盖已有的视口配置）
            for key, value in stealth_options.items():
                if key == "viewport" and "viewport" in context_options:
                    continue
                context_options[key] = value
            logger.debug(f"反检测已启用: ua={stealth_options.get('user_agent', 'random')[:50]}...")

        # 视频录制配置
        if self.config.record_video:
            video_dir = Path(self.config.video_dir)
            video_dir.mkdir(parents=True, exist_ok=True)

            context_options["record_video_dir"] = str(video_dir)

            if self.config.video_size:
                context_options["record_video_size"] = {
                    "width": self.config.video_size.get("width", 1280),
                    "height": self.config.video_size.get("height", 720),
                }

            logger.info(f"视频录制已启用: {video_dir}")

        self._context = await self._browser.new_context(**context_options)

        # 初始化视频管理器
        if self.config.record_video:
            from ..video import VideoManager, VideoRecorder
            self._video_manager = VideoManager(
                self._context,
                video_dir=self.config.video_dir,
                video_size=self.config.video_size,
            )
            self._video_recorder = VideoRecorder(self)

        # 创建第一个标签页
        await self.new_tab("default")

        # 如果配置了最大化，在启动后执行最大化
        if self.config.maximize_window and not self.config.headless:
            await self.maximize()

        elapsed = time.time() - self._start_time
        logger.info(f"浏览器启动成功 (耗时: {elapsed:.2f}s)")
        return self

    async def close(self):
        """关闭浏览器"""
        logger.info("关闭浏览器")

        # 保存视频录制
        if self._video_manager:
            try:
                saved = await self._video_manager.save_all()
                if saved:
                    logger.info(f"已保存 {len(saved)} 个视频文件")
            except Exception as e:
                logger.warning(f"保存视频失败: {e}")

        # 执行资源清理钩子
        await self._run_cleanup_hooks()

        for tab_id in list(self._tabs.keys()):
            await self.close_tab(tab_id)

        if self._context:
            await self._context.close()
            self._context = None
        if self._browser:
            await self._browser.close()
            self._browser = None
        if self._playwright:
            await self._playwright.stop()
            self._playwright = None

        self._tabs.clear()
        self._current_tab = None

        # 主动垃圾回收
        self.gc_collect()

        logger.info("浏览器已关闭")

    async def __aenter__(self) -> "EasyBrowser":
        return await self.start()

    async def __aexit__(self, exc_type, exc_val, exc_tb):
        await self.close()

    # ==================== 性能优化方法 ====================

    def gc_collect(self) -> int:
        """
        主动执行垃圾回收

        Returns:
            int: 回收的对象数量
        """
        collected = gc.collect()
        logger.debug(f"垃圾回收: {collected} 个对象")
        return collected

    def add_cleanup_hook(self, hook: Callable) -> None:
        """
        添加资源清理钩子

        钩子在浏览器关闭前执行，用于清理自定义资源。

        Args:
            hook: 清理函数（可以是同步或异步）
        """
        self._memory_hooks.append(hook)

    def remove_cleanup_hook(self, hook: Callable) -> None:
        """移除资源清理钩子"""
        if hook in self._memory_hooks:
            self._memory_hooks.remove(hook)

    async def _run_cleanup_hooks(self) -> None:
        """执行所有清理钩子"""
        import asyncio

        for hook in self._memory_hooks:
            try:
                result = hook()
                if asyncio.iscoroutine(result):
                    await result
            except Exception as e:
                logger.warning(f"清理钩子执行失败: {e}")

        self._memory_hooks.clear()

    def get_memory_usage(self) -> dict:
        """
        获取内存使用情况

        Returns:
            dict: 内存使用信息
        """
        import psutil
        import os

        process = psutil.Process(os.getpid())
        memory_info = process.memory_info()

        return {
            "rss_mb": memory_info.rss / 1024 / 1024,  # 物理内存
            "vms_mb": memory_info.vms / 1024 / 1024,  # 虚拟内存
            "tabs_count": len(self._tabs),
            "uptime_seconds": time.time() - self._start_time if self._start_time else 0,
        }

    def get_performance_stats(self) -> dict:
        """
        获取性能统计

        Returns:
            dict: 性能统计信息
        """
        return {
            "browser_type": self.config.browser_type,
            "headless": self.config.headless,
            "tabs_count": len(self._tabs),
            "uptime_seconds": time.time() - self._start_time if self._start_time else 0,
            "is_running": self._browser is not None,
        }

    # ==================== 视频录制 ====================

    @property
    def video(self) -> Optional["VideoManager"]:
        """
        获取视频管理器

        Returns:
            VideoManager: 视频管理器，如果未启用视频录制返回 None
        """
        return self._video_manager

    def is_video_enabled(self) -> bool:
        """检查是否启用视频录制"""
        return self._video_manager is not None

    async def save_video(self, save_path: Optional[str] = None) -> Optional[str]:
        """
        保存当前标签页的视频

        Args:
            save_path: 保存路径（可选）

        Returns:
            str: 视频文件路径
        """
        if not self._video_manager:
            logger.warning("视频录制未启用")
            return None

        current_tab = self.get_tab()
        return await self._video_manager.save_video(current_tab.name, save_path)

    async def save_all_videos(self) -> List[str]:
        """
        保存所有视频

        Returns:
            List[str]: 视频文件路径列表
        """
        if not self._video_manager:
            logger.warning("视频录制未启用")
            return []

        return await self._video_manager.save_all()

    # ==================== 类方法：预热 ====================

    @classmethod
    async def warmup(cls) -> None:
        """
        预热 Playwright

        提前初始化 Playwright 引擎，加快后续浏览器启动速度。
        建议在应用启动时调用一次。
        """
        if cls._playwright_warmed:
            return

        logger.info("预热 Playwright 引擎...")
        playwright = await async_playwright().start()
        await playwright.stop()

        cls._playwright_warmed = True
        logger.info("Playwright 引擎预热完成")

    @classmethod
    def is_warmed_up(cls) -> bool:
        """检查是否已预热"""
        return cls._playwright_warmed


# 前向引用类型
EasyBrowser = "EasyBrowser"
