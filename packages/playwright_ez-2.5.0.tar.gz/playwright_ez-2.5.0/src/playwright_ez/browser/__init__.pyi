"""
浏览器模块类型存根

提供 VSCode/Pylance 额外属性类型提示支持。
主要定义懒加载属性的类型，方法类型在源代码中已定义。
"""
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from playwright.async_api import Page
    from ..config import Config
    from ..element import Element, ElementList
    from ..highlight import ElementHighlighter
    from ..wait import SmartWait
    from ..network import NetworkMonitor, NetworkInterceptor
    from ..session import CookieManager, SessionManager
    from ..form import FormHandler
    from ..visual import VisualTester
    from ..recorder import ActionRecorder
    from ..performance import PerformanceAnalyzer
    from ..file_handler import FileHandler
    from ..extract import DataExtractor
    from ..selector import SmartSelector
    from ..popup import PopupHandler
    from ..mobile import MobileHelper
    from ..generator import DataGenerator
    from ..assertions import Assert
    from ..state import PageStateManager
    from ..recovery import SmartRecovery
    from ..browser_helpers import (
        AutomationHelper,
        DiagnosticsHelper,
        ScraperHelper,
        TestHelper,
        MonitoringHelper,
        SecurityHelper,
    )
    from ..ai import AIHelper


# 注意：方法签名已在 browser/__init__.py 源代码中定义
# 此文件仅补充懒加载属性的类型提示

