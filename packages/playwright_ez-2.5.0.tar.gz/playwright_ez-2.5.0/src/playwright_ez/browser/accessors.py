"""
模块访问器 Mixin
提供核心模块和辅助类的懒加载访问
"""
from typing import Optional, TYPE_CHECKING

if TYPE_CHECKING:
    from ..network import NetworkMonitor, NetworkInterceptor
    from ..session import CookieManager, SessionManager
    from ..form import FormHandler
    from ..visual import VisualTester
    from ..recorder import ActionRecorder
    from ..performance import PerformanceAnalyzer
    from ..file_handler import FileHandler
    from ..extract import DataExtractor
    from ..browser_helpers import (
        AutomationHelper, DiagnosticsHelper, ScraperHelper,
        TestHelper, MonitoringHelper, SecurityHelper,
    )


class ModuleAccessorsMixin:
    """
    核心模块属性访问器 Mixin
    提供懒加载属性访问
    """

    # 这些属性需要在主类中初始化
    _network: Optional["NetworkMonitor"] = None
    _interceptor: Optional["NetworkInterceptor"] = None
    _cookies: Optional["CookieManager"] = None
    _session: Optional["SessionManager"] = None
    _form: Optional["FormHandler"] = None
    _visual: Optional["VisualTester"] = None
    _recorder: Optional["ActionRecorder"] = None
    _performance: Optional["PerformanceAnalyzer"] = None
    _file: Optional["FileHandler"] = None
    _extractor: Optional["DataExtractor"] = None

    @property
    def network(self) -> "NetworkMonitor":
        """获取网络监控器"""
        if self._network is None:
            from ..network import NetworkMonitor
            self._network = NetworkMonitor(self.page)
        return self._network

    @property
    def interceptor(self) -> "NetworkInterceptor":
        """获取网络拦截器"""
        if self._interceptor is None:
            from ..network import NetworkInterceptor
            self._interceptor = NetworkInterceptor(self.page)
        return self._interceptor

    @property
    def cookies(self) -> "CookieManager":
        """获取 Cookie 管理器"""
        if self._cookies is None:
            from ..session import CookieManager
            if self._context is None:
                raise RuntimeError("浏览器上下文未初始化，请先启动浏览器")
            self._cookies = CookieManager(self._context)
        return self._cookies

    @property
    def session(self) -> "SessionManager":
        """获取会话管理器"""
        if self._session is None:
            from ..session import SessionManager
            if self._context is None:
                raise RuntimeError("浏览器上下文未初始化，请先启动浏览器")
            self._session = SessionManager(self._context)
        return self._session

    @property
    def form(self) -> "FormHandler":
        """获取表单处理器"""
        if self._form is None:
            from ..form import FormHandler
            self._form = FormHandler(self.page)
        return self._form

    @property
    def visual(self) -> "VisualTester":
        """获取视觉测试器"""
        if self._visual is None:
            from ..visual import VisualTester
            self._visual = VisualTester(self.page)
        return self._visual

    @property
    def recorder(self) -> "ActionRecorder":
        """获取操作录制器"""
        if self._recorder is None:
            from ..recorder import ActionRecorder
            self._recorder = ActionRecorder(self.page)
        return self._recorder

    @property
    def performance(self) -> "PerformanceAnalyzer":
        """获取性能分析器"""
        if self._performance is None:
            from ..performance import PerformanceAnalyzer
            self._performance = PerformanceAnalyzer(self.page)
        return self._performance

    @property
    def file(self) -> "FileHandler":
        """获取文件处理器"""
        if self._file is None:
            from ..file_handler import FileHandler
            self._file = FileHandler(self.page)
        return self._file

    @property
    def extractor(self) -> "DataExtractor":
        """获取数据提取器"""
        if self._extractor is None:
            from ..extract import DataExtractor
            self._extractor = DataExtractor(self.page)
        return self._extractor


class HelperAccessorsMixin:
    """
    辅助类属性访问器 Mixin
    提供懒加载属性访问
    """

    _automation: Optional["AutomationHelper"] = None
    _diagnostics: Optional["DiagnosticsHelper"] = None
    _scraper: Optional["ScraperHelper"] = None
    _test: Optional["TestHelper"] = None
    _monitor: Optional["MonitoringHelper"] = None
    _security: Optional["SecurityHelper"] = None

    @property
    def automation(self) -> "AutomationHelper":
        """获取自动化辅助类"""
        if self._automation is None:
            from ..browser_helpers import AutomationHelper
            self._automation = AutomationHelper(lambda: self.page)
        return self._automation

    @property
    def diagnostics(self) -> "DiagnosticsHelper":
        """获取诊断辅助类"""
        if self._diagnostics is None:
            from ..browser_helpers import DiagnosticsHelper
            self._diagnostics = DiagnosticsHelper(lambda: self.page)
        return self._diagnostics

    @property
    def scraper(self) -> "ScraperHelper":
        """获取数据采集辅助类"""
        if self._scraper is None:
            from ..browser_helpers import ScraperHelper
            self._scraper = ScraperHelper()
        return self._scraper

    @property
    def test(self) -> "TestHelper":
        """获取测试辅助类"""
        if self._test is None:
            from ..browser_helpers import TestHelper
            self._test = TestHelper(lambda: self.page)
        return self._test

    @property
    def monitor(self) -> "MonitoringHelper":
        """获取监控辅助类"""
        if self._monitor is None:
            from ..browser_helpers import MonitoringHelper
            self._monitor = MonitoringHelper(lambda: self.page)
        return self._monitor

    @property
    def security(self) -> "SecurityHelper":
        """获取安全辅助类"""
        if self._security is None:
            from ..browser_helpers import SecurityHelper
            self._security = SecurityHelper(lambda: self.page)
        return self._security

    def _reset_helpers(self):
        """重置所有辅助类实例"""
        self._network = None
        self._interceptor = None
        self._form = None
        self._visual = None
        self._recorder = None
        self._performance = None
        self._file = None
        self._extractor = None

        if self._automation:
            self._automation.reset()
        if self._diagnostics:
            self._diagnostics.reset()
        if self._scraper:
            self._scraper.reset()
        if self._test:
            self._test.reset()
        if self._monitor:
            self._monitor.reset()
        if self._security:
            self._security.reset()
