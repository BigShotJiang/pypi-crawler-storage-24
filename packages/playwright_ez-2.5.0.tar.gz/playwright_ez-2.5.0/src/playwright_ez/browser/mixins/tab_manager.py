"""
标签页管理 Mixin
"""
from typing import Optional, TYPE_CHECKING

from loguru import logger

if TYPE_CHECKING:
    from ..tab import Tab
    from playwright.async_api import Page, BrowserContext


class TabManagerMixin:
    """标签页管理功能"""

    # 这些属性由 BrowserCore 定义，这里声明类型供类型检查
    _tabs: dict[str, "Tab"]
    _current_tab: Optional[str]
    _tab_counter: int
    _context: "BrowserContext"
    config: "Config"
    _video_manager: Optional["VideoManager"]

    @property
    def page(self) -> "Page":
        """获取当前标签页的 Page 对象"""
        return self.get_tab().page

    async def new_tab(self, name: Optional[str] = None) -> "Tab":
        """
        创建新标签页

        Args:
            name: 标签页名称

        Returns:
            Tab: 新创建的标签页
        """
        from ..tab import Tab
        from ...anti_detection import AntiDetection

        if len(self._tabs) >= self.config.max_tabs:
            raise ValueError(f"已达到最大标签页数量: {self.config.max_tabs}")

        self._tab_counter += 1
        tab_id = f"tab_{self._tab_counter}"
        name = name or tab_id

        page = await self._context.new_page()

        # 应用页面隐身处理
        if self.config.stealth_enabled:
            await AntiDetection.stealth_page(page)

        tab = Tab(id=tab_id, page=page, name=name)

        self._tabs[tab_id] = tab

        # 注册视频录制
        if self._video_manager:
            self._video_manager.register_page(page, name)

        if self._current_tab is None:
            self._current_tab = tab_id

        logger.info(f"创建新标签页: id={tab_id}, name={name}")
        return tab

    async def close_tab(self, tab_id: Optional[str] = None):
        """
        关闭标签页

        Args:
            tab_id: 标签页ID，默认关闭当前标签页
        """
        tab_id = tab_id or self._current_tab
        if tab_id is None:
            return

        tab = self._tabs.get(tab_id)
        if tab:
            # 取消注册视频
            if self._video_manager:
                self._video_manager.unregister_page(tab.name)

            await tab.page.close()
            del self._tabs[tab_id]
            logger.info(f"关闭标签页: id={tab_id}")

            if self._current_tab == tab_id:
                self._current_tab = next(iter(self._tabs), None) if self._tabs else None

    def switch_tab(self, tab_id: str) -> "Tab":
        """
        切换到指定标签页

        Args:
            tab_id: 标签页ID

        Returns:
            Tab: 目标标签页
        """
        if tab_id not in self._tabs:
            raise ValueError(f"标签页不存在: {tab_id}")

        self._current_tab = tab_id
        tab = self._tabs[tab_id]
        logger.info(f"切换到标签页: id={tab_id}, name={tab.name}")
        return tab

    def get_tab(self, tab_id: Optional[str] = None) -> "Tab":
        """
        获取标签页

        Args:
            tab_id: 标签页ID，默认返回当前标签页

        Returns:
            Tab: 标签页
        """
        tab_id = tab_id or self._current_tab
        if tab_id is None:
            raise ValueError("没有可用的标签页")
        return self._tabs[tab_id]

    def list_tabs(self) -> list["Tab"]:
        """列出所有标签页"""
        return list(self._tabs.values())
