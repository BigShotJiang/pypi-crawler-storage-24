"""
浏览器模块

提供简化浏览器操作的核心类。
"""
from __future__ import annotations
from typing import TYPE_CHECKING, Optional, Dict, Any, List, Callable, Awaitable

from .tab import Tab
from .core import BrowserCore
from .mixins import (
    TabManagerMixin,
    NavigationMixin,
    ElementsMixin,
    WindowMixin,
    BatchMixin,
    PropertiesMixin,
    ElementLocatorMixin,
)

if TYPE_CHECKING:
    from playwright.async_api import Page
    from ..config import Config
    from ..element import Element, ElementList
    from ..wait import WaitCondition


class EasyBrowser(
    PropertiesMixin,
    BatchMixin,
    WindowMixin,
    ElementsMixin,
    ElementLocatorMixin,
    NavigationMixin,
    TabManagerMixin,
    BrowserCore,
):
    """
    简化的浏览器操作类

    特性:
    - 多标签页支持
    - 自动元素高亮
    - 智能等待
    - 操作日志
    - 极简语法: browser('selector')
    """

    # 类型注解属性
    config: Config
    _tabs: Dict[str, Tab]
    _current_tab: Optional[str]

    # ==================== 标签页管理 ====================
    async def new_tab(self, name: Optional[str] = None) -> Tab:
        return await super().new_tab(name)

    async def close_tab(self, tab_id: Optional[str] = None) -> None:
        return await super().close_tab(tab_id)

    def switch_tab(self, tab_id: str) -> Tab:
        return super().switch_tab(tab_id)

    def get_tab(self, tab_id: Optional[str] = None) -> Tab:
        return super().get_tab(tab_id)

    def list_tabs(self) -> List[Tab]:
        return super().list_tabs()

    # ==================== 导航 ====================
    async def goto(
        self,
        url: str,
        tab_id: Optional[str] = None,
        wait_until: str = "load"
    ) -> Tab:
        return await super().goto(url, tab_id, wait_until)

    async def go_back(self, tab_id: Optional[str] = None) -> bool:
        return await super().go_back(tab_id)

    async def go_forward(self, tab_id: Optional[str] = None) -> bool:
        return await super().go_forward(tab_id)

    async def refresh(self, tab_id: Optional[str] = None) -> None:
        return await super().refresh(tab_id)

    # ==================== 元素操作 ====================
    async def click(
        self,
        selector: str,
        tab_id: Optional[str] = None,
        highlight: bool = True,
        wait_condition: "WaitCondition" = None,
        timeout: Optional[float] = None,
        human: Optional[bool] = None,
        force: bool = False,
        dispatch: bool = False,
    ) -> bool:
        return await super().click(
            selector, tab_id, highlight, wait_condition, timeout, human, force, dispatch
        )

    async def type_text(
        self,
        selector: str,
        text: str,
        tab_id: Optional[str] = None,
        highlight: bool = True,
        clear: bool = False,
        timeout: Optional[float] = None,
        human: Optional[bool] = None,
        force: bool = False,
        secret: bool = False,
    ) -> bool:
        return await super().type_text(
            selector, text, tab_id, highlight, clear, timeout, human, force, secret
        )

    async def get_text(
        self,
        selector: str,
        tab_id: Optional[str] = None,
        highlight: bool = True,
    ) -> Optional[str]:
        return await super().get_text(selector, tab_id, highlight)

    async def scroll(
        self,
        selector: Optional[str] = None,
        tab_id: Optional[str] = None,
        direction: str = "down",
        distance: int = 500,
        human: Optional[bool] = None,
    ) -> None:
        return await super().scroll(selector, tab_id, direction, distance, human)

    async def screenshot(
        self,
        path: Optional[str] = None,
        tab_id: Optional[str] = None,
        full_page: bool = False,
    ) -> bytes:
        return await super().screenshot(path, tab_id, full_page)

    # ==================== 极简语法 ====================
    def __call__(self, selector: str) -> Element:
        return super().__call__(selector)

    def find(self, selector: str) -> Element:
        return super().find(selector)

    def find_all(self, selector: str) -> ElementList:
        return super().find_all(selector)

    def by_text(self, text: str, exact: bool = False) -> Element:
        return super().by_text(text, exact)

    def by_role(self, role: str, name: Optional[str] = None) -> Element:
        return super().by_role(role, name)

    def by_label(self, text: str) -> Element:
        return super().by_label(text)

    def by_placeholder(self, text: str) -> Element:
        return super().by_placeholder(text)

    def by_test_id(self, test_id: str) -> Element:
        return super().by_test_id(test_id)

    def by_xpath(self, xpath: str) -> Element:
        return super().by_xpath(xpath)

    def by_css(self, selector: str) -> Element:
        return super().by_css(selector)

    # ==================== 批量操作 ====================
    async def parallel_action(
        self,
        action: Callable[[Tab], Awaitable[Any]],
        tab_ids: Optional[List[str]] = None,
    ) -> List[Any]:
        return await super().parallel_action(action, tab_ids)

    async def sequential_action(
        self,
        action: Callable[[Tab], Awaitable[Any]],
        tab_ids: Optional[List[str]] = None,
    ) -> List[Any]:
        return await super().sequential_action(action, tab_ids)


__all__ = [
    "EasyBrowser",
    "Tab",
    "BrowserCore",
    "TabManagerMixin",
    "NavigationMixin",
    "ElementsMixin",
    "WindowMixin",
    "BatchMixin",
    "PropertiesMixin",
    "ElementLocatorMixin",
]
