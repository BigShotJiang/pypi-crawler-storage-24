"""
浏览器模块类型定义
"""
from dataclasses import dataclass
from playwright.async_api import Page


@dataclass
class Tab:
    """标签页"""
    id: str
    page: Page
    name: str = ""
    url: str = ""

    def __post_init__(self):
        self.url = self.page.url
