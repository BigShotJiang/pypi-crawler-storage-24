"""
诊断模块
提供控制台监控、错误分析、页面快照等功能
"""
from .console_monitor import (
    ConsoleMonitor,
    ConsoleLogEntry,
    ConsoleMonitorConfig,
    ConsoleMonitorResult,
    ConsoleFilterConfig,
    create_console_monitor,
)
from .error_analyzer import (
    ErrorAnalyzer,
    ErrorAnalysisResult,
    ErrorLocation,
    create_error_analyzer,
)
from .page_snapshot import (
    PageSnapshot,
    SnapshotConfig,
    SnapshotResult,
    DOMSnapshot,
    DiffResult,
    create_page_snapshot,
)

__all__ = [
    # 控制台监控
    "ConsoleMonitor",
    "ConsoleLogEntry",
    "ConsoleMonitorConfig",
    "ConsoleMonitorResult",
    "ConsoleFilterConfig",
    "create_console_monitor",
    # 错误分析
    "ErrorAnalyzer",
    "ErrorAnalysisResult",
    "ErrorLocation",
    "create_error_analyzer",
    # 页面快照
    "PageSnapshot",
    "SnapshotConfig",
    "SnapshotResult",
    "DOMSnapshot",
    "DiffResult",
    "create_page_snapshot",
]
