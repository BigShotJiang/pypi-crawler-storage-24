"""
并发和负载测试模块
支持并发测试、负载测试、浏览器池、任务队列、重试执行器

子模块:
- types: 类型定义
- runner: 并发执行器
- load_test: 负载测试
- monitor: 性能监控和基准测试
- pool: 浏览器实例池
- queue: 任务队列
- retry: 重试执行器
"""

from .types import (
    # 负载测试类型
    LoadTestResult,
    # 浏览器池类型
    BrowserPoolConfig,
    BrowserInstance,
    # 任务队列类型
    TaskStatus,
    TaskQueueConfig,
    QueueTask,
    # 重试类型
    RetryConfig,
    RetryResult,
)

from .runner import ConcurrentRunner
from .load_test import LoadTester
from .monitor import PerformanceMonitor, Benchmark
from .pool import BrowserPool
from .queue import TaskQueue
from .retry import RetryExecutor, with_retry

__all__ = [
    # 类型定义
    "LoadTestResult",
    "BrowserPoolConfig",
    "BrowserInstance",
    "TaskStatus",
    "TaskQueueConfig",
    "QueueTask",
    "RetryConfig",
    "RetryResult",
    # 核心类
    "ConcurrentRunner",
    "LoadTester",
    "PerformanceMonitor",
    "Benchmark",
    "BrowserPool",
    "TaskQueue",
    "RetryExecutor",
    # 装饰器
    "with_retry",
]
