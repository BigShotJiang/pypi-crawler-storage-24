"""
Playwright-EZ 主入口类型存根

提供 VSCode/Pylance 类型提示支持。
"""
from typing import Optional, Dict, Any, List

# 核心
from .browser import EasyBrowser, Tab
from .config import Config

# 元素代理
from .element import Element, ElementList
from .relative import RelativeLocator

# 配置持久化
from .profile import BrowserProfile, ProfileManager

# 双引擎模式
from .dual_engine import DualEngine, DualEngineResponse, DualEngineContext


def get_config() -> Config: ...
def set_config(config: Config) -> None: ...


__version__: str
__all__: List[str]
