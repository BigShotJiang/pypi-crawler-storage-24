"""
监控辅助类
整合 monitoring 子模块，提供统一访问入口
"""
from typing import Callable, Optional
from playwright.async_api import Page

from ..monitoring import SEOChecker


class MonitoringHelper:
    """
    监控辅助类
    整合 monitoring 子模块

    使用方式:
        browser.monitor.seo  # SEOChecker
    """

    def __init__(self, get_page: Callable[[], Page]):
        """
        初始化监控辅助类

        Args:
            get_page: 获取当前 Page 对象的回调函数
        """
        self._get_page = get_page
        self._seo: Optional[SEOChecker] = None

    @property
    def seo(self) -> SEOChecker:
        """
        获取 SEO 检查器

        Returns:
            SEOChecker: SEO 检查器实例
        """
        if self._seo is None:
            self._seo = SEOChecker(self._get_page())
        return self._seo

    def reset(self):
        """
        重置所有实例
        当切换标签页时调用，确保使用正确的 Page 对象
        """
        self._seo = None
