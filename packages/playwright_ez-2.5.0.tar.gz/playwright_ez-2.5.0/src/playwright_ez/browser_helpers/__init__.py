"""
浏览器辅助类模块
提供分组访问子模块的辅助类

使用方式:
    browser.automation.infinite_scroll  # InfiniteScrollHandler
    browser.diagnostics.console          # ConsoleMonitor
    browser.scraper.rate_limiter         # RateLimiter
    browser.test.accessibility           # AccessibilityChecker
    browser.monitor.seo                  # SEOChecker
    browser.security.scanner             # SecurityScanner
"""

from .automation import AutomationHelper
from .diagnostics import DiagnosticsHelper
from .scraper import ScraperHelper
from .test import TestHelper
from .monitoring import MonitoringHelper
from .security import SecurityHelper

__all__ = [
    "AutomationHelper",
    "DiagnosticsHelper",
    "ScraperHelper",
    "TestHelper",
    "MonitoringHelper",
    "SecurityHelper",
]
