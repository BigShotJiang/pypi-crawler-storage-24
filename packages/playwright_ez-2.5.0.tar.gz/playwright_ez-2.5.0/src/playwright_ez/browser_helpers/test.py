"""
测试辅助类
整合 test_helpers 子模块，提供统一访问入口
"""
from typing import Callable, Optional
from playwright.async_api import Page

from ..test_helpers import (
    AccessibilityChecker,
    AccessibilityCheckConfig,
    UserFactory,
    ProductFactory,
    OrderFactory,
    FactoryConfig,
    MockServer,
    MockConfig,
)


class TestHelper:
    """
    测试辅助类
    整合 test_helpers 子模块

    使用方式:
        browser.test_helpers.accessibility  # AccessibilityChecker
        browser.test_helpers.user_factory   # UserFactory
        browser.test_helpers.product_factory # ProductFactory
        browser.test_helpers.mock           # MockServer
    """

    def __init__(self, get_page: Callable[[], Page]):
        """
        初始化测试辅助类

        Args:
            get_page: 获取当前 Page 对象的回调函数
        """
        self._get_page = get_page
        self._accessibility: Optional[AccessibilityChecker] = None
        self._accessibility_config: Optional[AccessibilityCheckConfig] = None
        self._user_factory: Optional[UserFactory] = None
        self._product_factory: Optional[ProductFactory] = None
        self._order_factory: Optional[OrderFactory] = None
        self._mock: Optional[MockServer] = None
        self._factory_config: Optional[FactoryConfig] = None
        self._mock_config: Optional[MockConfig] = None

    @property
    def accessibility(self) -> AccessibilityChecker:
        """
        获取可访问性检查器

        Returns:
            AccessibilityChecker: 可访问性检查器实例
        """
        if self._accessibility is None:
            self._accessibility = AccessibilityChecker(
                self._get_page(),
                self._accessibility_config
            )
        return self._accessibility

    @property
    def user_factory(self) -> UserFactory:
        """
        获取用户数据工厂

        Returns:
            UserFactory: 用户数据工厂实例
        """
        if self._user_factory is None:
            self._user_factory = UserFactory(self._factory_config)
        return self._user_factory

    @property
    def product_factory(self) -> ProductFactory:
        """
        获取产品数据工厂

        Returns:
            ProductFactory: 产品数据工厂实例
        """
        if self._product_factory is None:
            self._product_factory = ProductFactory(self._factory_config)
        return self._product_factory

    @property
    def order_factory(self) -> OrderFactory:
        """
        获取订单数据工厂

        Returns:
            OrderFactory: 订单数据工厂实例
        """
        if self._order_factory is None:
            self._order_factory = OrderFactory(self._factory_config)
        return self._order_factory

    @property
    def mock(self) -> MockServer:
        """
        获取 Mock 服务器

        Returns:
            MockServer: Mock 服务器实例
        """
        if self._mock is None:
            self._mock = MockServer(self._get_page(), self._mock_config)
        return self._mock

    def set_accessibility_config(self, config: AccessibilityCheckConfig):
        """
        设置可访问性检查配置

        Args:
            config: 可访问性检查配置
        """
        self._accessibility_config = config
        self._accessibility = None

    def set_factory_config(self, config: FactoryConfig):
        """
        设置数据工厂配置

        Args:
            config: 数据工厂配置
        """
        self._factory_config = config
        self._user_factory = None
        self._product_factory = None
        self._order_factory = None

    def set_mock_config(self, config: MockConfig):
        """
        设置 Mock 服务器配置

        Args:
            config: Mock 服务器配置
        """
        self._mock_config = config
        self._mock = None

    def reset(self):
        """
        重置所有实例
        当切换标签页时调用，确保使用正确的 Page 对象
        """
        self._accessibility = None
        self._mock = None
