"""
数据采集辅助类
整合 scraper 子模块，提供统一访问入口
"""
from typing import Callable, Optional
from playwright.async_api import Page
from ..scraper import (
    RateLimiter,
    RateLimiterConfig,
    DataValidator,
    DataValidatorConfig,
    IncrementalCrawler,
    CrawlConfig,
    SmartScraperV2,
    SmartScraperConfig,
)


class ScraperHelper:
    """
    数据采集辅助类
    整合 scraper 子模块

    使用方式:
        browser.scraper.rate_limiter  # RateLimiter
        browser.scraper.validator     # DataValidator
        browser.scraper.incremental   # IncrementalCrawler
        browser.scraper.smart         # SmartScraperV2
    """

    def __init__(self, get_page: Callable[[], Page]):
        """
        初始化数据采集辅助类

        Args:
            get_page: 获取当前 Page 对象的回调函数
        """
        self._get_page = get_page
        self._rate_limiter: Optional[RateLimiter] = None
        self._validator: Optional[DataValidator] = None
        self._incremental: Optional[IncrementalCrawler] = None
        self._smart: Optional[SmartScraperV2] = None
        self._rate_limiter_config: Optional[RateLimiterConfig] = None
        self._validator_config: Optional[DataValidatorConfig] = None
        self._crawl_config: Optional[CrawlConfig] = None
        self._scraper_config: Optional[SmartScraperConfig] = None

    @property
    def rate_limiter(self) -> RateLimiter:
        """
        获取限流器

        Returns:
            RateLimiter: 限流器实例
        """
        if self._rate_limiter is None:
            self._rate_limiter = RateLimiter(self._rate_limiter_config)
        return self._rate_limiter

    @property
    def validator(self) -> DataValidator:
        """
        获取数据验证器

        Returns:
            DataValidator: 数据验证器实例
        """
        if self._validator is None:
            self._validator = DataValidator(self._validator_config)
        return self._validator

    @property
    def incremental(self) -> IncrementalCrawler:
        """
        获取增量爬虫

        Returns:
            IncrementalCrawler: 增量爬虫实例
        """
        if self._incremental is None:
            self._incremental = IncrementalCrawler(
                self._get_page(),
                self._crawl_config
            )
        return self._incremental

    @property
    def smart(self) -> SmartScraperV2:
        """
        获取智能爬虫

        Returns:
            SmartScraperV2: 智能爬虫实例
        """
        if self._smart is None:
            self._smart = SmartScraperV2(
                self._get_page(),
                self._scraper_config
            )
        return self._smart

    def set_rate_limiter_config(self, config: RateLimiterConfig):
        """
        设置限流器配置

        Args:
            config: 限流器配置
        """
        self._rate_limiter_config = config
        self._rate_limiter = None

    def set_validator_config(self, config: DataValidatorConfig):
        """
        设置验证器配置

        Args:
            config: 验证器配置
        """
        self._validator_config = config
        self._validator = None

    def reset(self):
        """重置所有实例"""
        self._rate_limiter = None
        self._validator = None
        self._incremental = None
        self._smart = None
