"""
自动化辅助类
整合 automation 子模块，提供统一访问入口
"""
from typing import Callable, Optional
from playwright.async_api import Page

from ..automation import (
    InfiniteScrollHandler,
    InfiniteScrollConfig,
    PaginationNavigator,
    PaginationConfig,
    IframeManager,
    DragDropHelper,
    DragConfig,
    FileManager,
    FileResult,
    UploadConfig,
    DownloadConfig,
)


class AutomationHelper:
    """
    自动化辅助类
    整合 automation 子模块

    使用方式:
        browser.automation.infinite_scroll  # InfiniteScrollHandler
        browser.automation.pagination       # PaginationNavigator
        browser.automation.iframe           # IframeManager
        browser.automation.drag_drop        # DragDropHelper
        browser.automation.file             # FileManager
    """

    def __init__(self, get_page: Callable[[], Page]):
        """
        初始化自动化辅助类

        Args:
            get_page: 获取当前 Page 对象的回调函数
        """
        self._get_page = get_page
        self._infinite_scroll: Optional[InfiniteScrollHandler] = None
        self._pagination: Optional[PaginationNavigator] = None
        self._iframe: Optional[IframeManager] = None
        self._drag_drop: Optional[DragDropHelper] = None
        self._file: Optional[FileManager] = None

    @property
    def infinite_scroll(self) -> InfiniteScrollHandler:
        """
        获取无限滚动处理器

        Returns:
            InfiniteScrollHandler: 无限滚动处理器实例
        """
        if self._infinite_scroll is None:
            self._infinite_scroll = InfiniteScrollHandler(self._get_page())
        return self._infinite_scroll

    @property
    def pagination(self) -> PaginationNavigator:
        """
        获取分页导航器

        Returns:
            PaginationNavigator: 分页导航器实例
        """
        if self._pagination is None:
            self._pagination = PaginationNavigator(self._get_page())
        return self._pagination

    @property
    def iframe(self) -> IframeManager:
        """
        获取 iframe 管理器

        Returns:
            IframeManager: iframe 管理器实例
        """
        if self._iframe is None:
            self._iframe = IframeManager(self._get_page())
        return self._iframe

    @property
    def drag_drop(self) -> DragDropHelper:
        """
        获取拖拽操作助手

        Returns:
            DragDropHelper: 拖拽操作助手实例
        """
        if self._drag_drop is None:
            self._drag_drop = DragDropHelper(self._get_page())
        return self._drag_drop

    @property
    def file(self) -> FileManager:
        """
        获取文件管理器

        Returns:
            FileManager: 文件管理器实例
        """
        if self._file is None:
            self._file = FileManager(self._get_page())
        return self._file

    def reset(self):
        """
        重置所有实例
        当切换标签页时调用，确保使用正确的 Page 对象
        """
        self._infinite_scroll = None
        self._pagination = None
        self._iframe = None
        self._drag_drop = None
        self._file = None
