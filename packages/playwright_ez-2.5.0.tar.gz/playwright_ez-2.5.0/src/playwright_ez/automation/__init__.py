"""
自动化增强模块
提供无限滚动、分页导航、iframe管理、拖拽操作、文件管理等功能
"""
from .infinite_scroll import (
    InfiniteScrollHandler,
    InfiniteScrollConfig,
    InfiniteScrollResult,
    create_infinite_scroll_handler,
)
from .pagination_navigator import (
    PaginationNavigator,
    PaginationConfig,
    PaginationResult,
    create_pagination_navigator,
)
from .iframe_manager import (
    IframeManager,
    IframeInfo,
    create_iframe_manager,
)
from .drag_drop import (
    DragDropHelper,
    DragConfig,
    DragResult,
    create_drag_drop_helper,
)
from .file_manager import (
    FileManager,
    FileResult,
    UploadConfig,
    DownloadConfig,
    create_file_manager,
)

__all__ = [
    # 无限滚动
    "InfiniteScrollHandler",
    "InfiniteScrollConfig",
    "InfiniteScrollResult",
    "create_infinite_scroll_handler",
    # 分页导航
    "PaginationNavigator",
    "PaginationConfig",
    "PaginationResult",
    "create_pagination_navigator",
    # iframe 管理
    "IframeManager",
    "IframeInfo",
    "create_iframe_manager",
    # 拖拽操作
    "DragDropHelper",
    "DragConfig",
    "DragResult",
    "create_drag_drop_helper",
    # 文件管理
    "FileManager",
    "FileResult",
    "UploadConfig",
    "DownloadConfig",
    "create_file_manager",
]
