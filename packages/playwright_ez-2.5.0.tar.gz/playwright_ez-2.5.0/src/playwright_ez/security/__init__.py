"""
安全测试模块
提供安全扫描、XSS 检测、Header 检查等功能
"""
from .security_scanner import (
    SecurityScanner,
    SecurityScanResult,
    SecurityIssue,
    create_security_scanner,
)
from .xss_detector import (
    XSSDetector,
    XSSConfig,
    XSSIssue,
    XSSScanResult,
    create_xss_detector,
)
from .header_checker import (
    HeaderChecker,
    HeaderCheckConfig,
    HeaderCheckResult,
    HeaderIssue,
    create_header_checker,
)

__all__ = [
    # 安全扫描
    "SecurityScanner",
    "SecurityScanResult",
    "SecurityIssue",
    "create_security_scanner",
    # XSS 检测
    "XSSDetector",
    "XSSConfig",
    "XSSIssue",
    "XSSScanResult",
    "create_xss_detector",
    # Header 检查
    "HeaderChecker",
    "HeaderCheckConfig",
    "HeaderCheckResult",
    "HeaderIssue",
    "create_header_checker",
]
