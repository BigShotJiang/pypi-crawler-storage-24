"""
数据提取相关类型定义
"""
from dataclasses import dataclass, field
from datetime import datetime
from typing import Any, List, Optional


@dataclass
class ExtractionRule:
    """提取规则"""
    name: str
    selector: str
    attribute: Optional[str] = None  # None表示取文本，否则取属性值
    multiple: bool = False
    required: bool = True
    default: Any = None
    transform: Optional[str] = None  # 转换函数名


@dataclass
class ExtractionResult:
    """提取结果"""
    success: bool
    data: Any
    errors: List[str] = field(default_factory=list)
    timestamp: datetime = field(default_factory=datetime.now)
