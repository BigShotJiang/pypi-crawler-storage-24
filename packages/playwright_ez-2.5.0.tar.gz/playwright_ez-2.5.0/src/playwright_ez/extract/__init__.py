"""
数据提取模块
从网页中提取结构化数据

子模块:
- types: 数据类型定义
- basic: 基础数据提取器
- template: 爬虫模板
- exporter: 数据导出器
- pagination: 分页爬取器
- dynamic: 动态内容提取器
- form: 表单数据提取器
- scraper: 智能爬虫
"""

from .types import ExtractionRule, ExtractionResult
from .basic import DataExtractor
from .template import ScraperTemplate
from .exporter import DataExporter, save_to_json, save_to_csv
from .pagination import PaginationExtractor
from .dynamic import DynamicContentExtractor
from .form import FormDataExtractor
from .scraper import SmartScraper

__all__ = [
    # 类型定义
    "ExtractionRule",
    "ExtractionResult",
    # 核心类
    "DataExtractor",
    "ScraperTemplate",
    "DataExporter",
    "PaginationExtractor",
    "DynamicContentExtractor",
    "FormDataExtractor",
    "SmartScraper",
    # 快捷函数
    "save_to_json",
    "save_to_csv",
]
