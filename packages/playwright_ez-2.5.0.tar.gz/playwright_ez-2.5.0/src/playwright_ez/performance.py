"""
性能分析模块
页面加载性能、资源分析、性能指标
"""
import json
from typing import Optional, Dict, Any, List
from playwright.async_api import Page
from loguru import logger
from dataclasses import dataclass, field
from datetime import datetime
import statistics


@dataclass
class PerformanceMetric:
    """性能指标"""
    name: str
    value: float
    unit: str = "ms"
    timestamp: datetime = field(default_factory=datetime.now)


@dataclass
class ResourceTiming:
    """资源加载时间"""
    name: str
    url: str
    resource_type: str
    start_time: float
    end_time: float
    duration: float
    size: int = 0
    status: int = 0


@dataclass
class PageLoadMetrics:
    """页面加载指标"""
    url: str
    dom_content_loaded: float = 0
    load: float = 0
    first_paint: float = 0
    first_contentful_paint: float = 0
    largest_contentful_paint: float = 0
    time_to_interactive: float = 0
    total_blocking_time: float = 0
    cumulative_layout_shift: float = 0
    speed_index: float = 0
    resources: List[ResourceTiming] = field(default_factory=list)
    timestamp: datetime = field(default_factory=datetime.now)


class PerformanceAnalyzer:
    """
    性能分析器
    分析页面加载性能和资源
    """
    
    def __init__(self, page: Page):
        self.page = page
        self._metrics: List[PageLoadMetrics] = []
    
    async def measure_page_load(self) -> PageLoadMetrics:
        """
        测量页面加载性能
        
        Returns:
            PageLoadMetrics: 页面加载指标
        """
        logger.info("开始测量页面加载性能")
        
        # 获取Navigation Timing
        timing = await self.page.evaluate("""
            () => {
                const timing = performance.getEntriesByType('navigation')[0];
                return timing ? {
                    domContentLoaded: timing.domContentLoadedEventEnd - timing.startTime,
                    load: timing.loadEventEnd - timing.startTime,
                } : null;
            }
        """)
        
        # 获取Paint Timing
        paint_timing = await self.page.evaluate("""
            () => {
                const paints = performance.getEntriesByType('paint');
                const result = {};
                paints.forEach(paint => {
                    result[paint.name] = paint.startTime;
                });
                return result;
            }
        """)
        
        # 获取Web Vitals
        web_vitals = await self.page.evaluate("""
            () => {
                return new Promise((resolve) => {
                    const vitals = {
                        lcp: 0,
                        fid: 0,
                        cls: 0,
                    };
                    
                    // LCP
                    if (PerformanceObserver) {
                        try {
                            const lcpObserver = new PerformanceObserver((list) => {
                                const entries = list.getEntries();
                                vitals.lcp = entries[entries.length - 1].startTime;
                            });
                            lcpObserver.observe({ type: 'largest-contentful-paint', buffered: true });
                        } catch (e) {}
                    }
                    
                    // 等待一小段时间让指标收集完成
                    setTimeout(() => resolve(vitals), 100);
                });
            }
        """)
        
        # 获取资源加载时间
        resources = await self.page.evaluate("""
            () => {
                const resources = performance.getEntriesByType('resource');
                return resources.map(r => ({
                    name: r.name,
                    type: r.initiatorType,
                    startTime: r.startTime,
                    duration: r.duration,
                    size: r.transferSize || 0,
                    status: r.responseStatus || 0,
                }));
            }
        """)
        
        # 构建结果
        metrics = PageLoadMetrics(
            url=self.page.url,
            dom_content_loaded=timing.get('domContentLoaded', 0) if timing else 0,
            load=timing.get('load', 0) if timing else 0,
            first_paint=paint_timing.get('first-paint', 0),
            first_contentful_paint=paint_timing.get('first-contentful-paint', 0),
            largest_contentful_paint=web_vitals.get('lcp', 0),
            resources=[
                ResourceTiming(
                    name=r['name'],
                    url=r['name'],
                    resource_type=r['type'],
                    start_time=r['startTime'],
                    end_time=r['startTime'] + r['duration'],
                    duration=r['duration'],
                    size=r['size'],
                    status=r['status'],
                )
                for r in resources
            ]
        )
        
        self._metrics.append(metrics)
        logger.info(f"页面加载性能测量完成: load={metrics.load:.0f}ms")
        
        return metrics
    
    async def get_memory_usage(self) -> Dict[str, float]:
        """
        获取内存使用情况
        
        Returns:
            Dict: 内存使用信息（MB）
        """
        memory = await self.page.evaluate("""
            () => {
                if (performance.memory) {
                    return {
                        usedJSHeapSize: performance.memory.usedJSHeapSize / 1048576,
                        totalJSHeapSize: performance.memory.totalJSHeapSize / 1048576,
                        jsHeapSizeLimit: performance.memory.jsHeapSizeLimit / 1048576,
                    };
                }
                return null;
            }
        """)
        
        return memory or {}
    
    async def get_cpu_usage(self, duration_ms: int = 1000) -> Dict[str, float]:
        """
        获取CPU使用情况
        
        Args:
            duration_ms: 测量持续时间
            
        Returns:
            Dict: CPU使用信息
        """
        cpu = await self.page.evaluate(f"""
            () => {{
                return new Promise((resolve) => {{
                    const start = performance.now();
                    let busy = 0;
                    
                    const interval = setInterval(() => {{
                        busy += 1;
                    }}, 0);
                    
                    setTimeout(() => {{
                        clearInterval(interval);
                        const elapsed = performance.now() - start;
                        resolve({{
                            busyTime: busy,
                            totalTime: elapsed,
                            cpuUsage: (busy / elapsed * 100)
                        }});
                    }}, {duration_ms});
                }});
            }}
        """)
        
        return cpu or {}
    
    async def analyze_resources(self) -> Dict[str, Any]:
        """
        分析资源加载情况
        
        Returns:
            Dict: 资源分析结果
        """
        resources = await self.page.evaluate("""
            () => {
                const resources = performance.getEntriesByType('resource');
                const result = {
                    total: resources.length,
                    totalSize: 0,
                    totalDuration: 0,
                    byType: {},
                    slowResources: [],
                };
                
                resources.forEach(r => {
                    const type = r.initiatorType || 'other';
                    const size = r.transferSize || 0;
                    
                    if (!result.byType[type]) {
                        result.byType[type] = { count: 0, size: 0, duration: 0 };
                    }
                    
                    result.byType[type].count += 1;
                    result.byType[type].size += size;
                    result.byType[type].duration += r.duration;
                    
                    result.totalSize += size;
                    result.totalDuration += r.duration;
                    
                    // 记录慢资源（>500ms）
                    if (r.duration > 500) {
                        result.slowResources.push({
                            name: r.name,
                            type: type,
                            duration: r.duration,
                            size: size,
                        });
                    }
                });
                
                result.totalSizeMB = result.totalSize / 1048576;
                
                return result;
            }
        """)
        
        logger.info(f"资源分析完成: {resources['total']}个资源, {resources['totalSizeMB']:.2f}MB")
        return resources
    
    async def get_web_vitals(self) -> Dict[str, float]:
        """
        获取Web Vitals指标
        
        Returns:
            Dict: Web Vitals
        """
        vitals = await self.page.evaluate("""
            () => {
                return new Promise((resolve) => {
                    const result = {
                        LCP: 0,  // Largest Contentful Paint
                        FID: 0,  // First Input Delay
                        CLS: 0,  // Cumulative Layout Shift
                        FCP: 0,  // First Contentful Paint
                        TTFB: 0, // Time to First Byte
                    };
                    
                    // FCP & TTFB
                    const paints = performance.getEntriesByType('paint');
                    paints.forEach(p => {
                        if (p.name === 'first-contentful-paint') {
                            result.FCP = p.startTime;
                        }
                    });
                    
                    // TTFB
                    const navigation = performance.getEntriesByType('navigation')[0];
                    if (navigation) {
                        result.TTFB = navigation.responseStart - navigation.requestStart;
                    }
                    
                    // LCP
                    try {
                        const lcpEntries = performance.getEntriesByType('largest-contentful-paint');
                        if (lcpEntries.length > 0) {
                            result.LCP = lcpEntries[lcpEntries.length - 1].startTime;
                        }
                    } catch (e) {}
                    
                    // CLS
                    try {
                        let clsValue = 0;
                        const layoutShifts = performance.getEntriesByType('layout-shift');
                        layoutShifts.forEach(entry => {
                            if (!entry.hadRecentInput) {
                                clsValue += entry.value;
                            }
                        });
                        result.CLS = clsValue;
                    } catch (e) {}
                    
                    resolve(result);
                });
            }
        """)
        
        return vitals
    
    def get_resource_by_type(self, resource_type: str) -> List[ResourceTiming]:
        """获取指定类型的资源"""
        if not self._metrics:
            return []
        
        return [
            r for r in self._metrics[-1].resources
            if r.resource_type == resource_type
        ]
    
    def get_slow_resources(self, threshold_ms: float = 1000) -> List[ResourceTiming]:
        """获取慢资源"""
        if not self._metrics:
            return []
        
        return [
            r for r in self._metrics[-1].resources
            if r.duration > threshold_ms
        ]
    
    def summary(self) -> Dict[str, Any]:
        """生成性能摘要"""
        if not self._metrics:
            return {}
        
        latest = self._metrics[-1]
        
        return {
            "url": latest.url,
            "page_load": {
                "dom_content_loaded": f"{latest.dom_content_loaded:.0f}ms",
                "load": f"{latest.load:.0f}ms",
                "first_paint": f"{latest.first_paint:.0f}ms",
                "first_contentful_paint": f"{latest.first_contentful_paint:.0f}ms",
            },
            "resources": {
                "total": len(latest.resources),
                "slow_count": len(self.get_slow_resources()),
            },
            "timestamp": latest.timestamp.isoformat(),
        }
    
    def print_summary(self):
        """打印性能摘要"""
        summary = self.summary()
        
        print("\n=== 性能分析摘要 ===")
        print(f"URL: {summary.get('url', 'N/A')}")
        
        if 'page_load' in summary:
            print("\n页面加载:")
            for key, value in summary['page_load'].items():
                print(f"  {key}: {value}")
        
        if 'resources' in summary:
            print(f"\n资源统计:")
            print(f"  总数: {summary['resources']['total']}")
            print(f"  慢资源: {summary['resources']['slow_count']}")
    
    def save_report(self, filepath: str):
        """保存性能报告"""
        report = {
            "metrics": [
                {
                    "url": m.url,
                    "dom_content_loaded": m.dom_content_loaded,
                    "load": m.load,
                    "first_paint": m.first_paint,
                    "first_contentful_paint": m.first_contentful_paint,
                    "largest_contentful_paint": m.largest_contentful_paint,
                    "resource_count": len(m.resources),
                    "timestamp": m.timestamp.isoformat(),
                }
                for m in self._metrics
            ],
            "summary": self.summary(),
        }
        
        with open(filepath, 'w', encoding='utf-8') as f:
            json.dump(report, f, ensure_ascii=False, indent=2)
        
        logger.info(f"性能报告已保存: {filepath}")


class PerformanceBudget:
    """
    性能预算
    设置性能阈值，超出时告警
    """
    
    def __init__(self):
        self.thresholds: Dict[str, float] = {
            "dom_content_loaded": 1500,  # ms
            "load": 3000,  # ms
            "first_paint": 1000,  # ms
            "first_contentful_paint": 1800,  # ms
            "largest_contentful_paint": 2500,  # ms
            "total_resources": 100,  # count
            "total_size_mb": 5,  # MB
        }
        self.violations: List[Dict[str, Any]] = []
    
    def set_threshold(self, metric: str, value: float):
        """设置阈值"""
        self.thresholds[metric] = value
    
    def check(self, metrics: PageLoadMetrics) -> List[Dict[str, Any]]:
        """
        检查性能指标是否超出预算
        
        Args:
            metrics: 页面加载指标
            
        Returns:
            List: 违规列表
        """
        violations = []
        
        checks = [
            ("dom_content_loaded", metrics.dom_content_loaded),
            ("load", metrics.load),
            ("first_paint", metrics.first_paint),
            ("first_contentful_paint", metrics.first_contentful_paint),
            ("largest_contentful_paint", metrics.largest_contentful_paint),
        ]
        
        for metric_name, value in checks:
            threshold = self.thresholds.get(metric_name)
            if threshold and value > threshold:
                violation = {
                    "metric": metric_name,
                    "actual": value,
                    "threshold": threshold,
                    "over": value - threshold,
                }
                violations.append(violation)
                logger.warning(
                    f"性能预算违规: {metric_name}={value:.0f}ms, "
                    f"阈值={threshold}ms, 超出={value-threshold:.0f}ms"
                )
        
        self.violations.extend(violations)
        return violations
    
    def is_within_budget(self, metrics: PageLoadMetrics) -> bool:
        """检查是否在预算内"""
        return len(self.check(metrics)) == 0

    async def check_and_alert(
        self,
        metrics: PageLoadMetrics,
        alert_callback: Optional[callable] = None,
    ) -> bool:
        """
        检查并发出告警

        Args:
            metrics: 页面加载指标
            alert_callback: 告警回调函数，接收告警消息

        Returns:
            bool: 是否在预算内
        """
        violations = self.check(metrics)

        if violations and alert_callback:
            for v in violations:
                message = (
                    f"性能预算违规: {v['metric']}={v['actual']:.0f}ms, "
                    f"阈值={v['threshold']:.0f}ms, 超出={v['over']:.0f}ms"
                )
                alert_callback(message)

        return len(violations) == 0

    def reset(self) -> None:
        """重置违规记录"""
        self.violations.clear()


class PerformanceReporter:
    """
    性能报告生成器

    生成 HTML 和 JSON 格式的性能报告。
    """

    def __init__(self):
        self._metrics_history: List[PageLoadMetrics] = []

    def add_metrics(self, metrics: PageLoadMetrics) -> None:
        """添加性能指标到历史记录"""
        self._metrics_history.append(metrics)

    def generate_report(
        self,
        metrics: Optional[List[PageLoadMetrics]] = None,
        include_charts: bool = True,
    ) -> str:
        """
        生成 HTML 性能报告

        Args:
            metrics: 性能指标列表，默认使用历史记录
            include_charts: 是否包含图表

        Returns:
            str: HTML 报告内容
        """
        metrics_list = metrics or self._metrics_history
        if not metrics_list:
            return "<html><body><h1>无性能数据</h1></body></html>"

        # 生成报告内容
        html_parts = [
            "<!DOCTYPE html>",
            "<html lang='zh-CN'>",
            "<head>",
            "    <meta charset='UTF-8'>",
            "    <title>Playwright-EZ 性能报告</title>",
            "    <style>",
            "        body { font-family: Arial, sans-serif; margin: 20px; background: #f5f5f5; }",
            "        .container { max-width: 1200px; margin: 0 auto; background: white; padding: 20px; border-radius: 8px; box-shadow: 0 2px 4px rgba(0,0,0,0.1); }",
            "        h1 { color: #333; border-bottom: 2px solid #4CAF50; padding-bottom: 10px; }",
            "        h2 { color: #555; margin-top: 30px; }",
            "        table { width: 100%; border-collapse: collapse; margin: 15px 0; }",
            "        th, td { padding: 12px; text-align: left; border-bottom: 1px solid #ddd; }",
            "        th { background: #4CAF50; color: white; }",
            "        tr:hover { background: #f5f5f5; }",
            "        .good { color: #4CAF50; font-weight: bold; }",
            "        .warning { color: #FF9800; font-weight: bold; }",
            "        .bad { color: #f44336; font-weight: bold; }",
            "        .summary { display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 15px; margin: 20px 0; }",
            "        .summary-card { background: #e8f5e9; padding: 15px; border-radius: 8px; text-align: center; }",
            "        .summary-card h3 { margin: 0; color: #666; font-size: 14px; }",
            "        .summary-card .value { font-size: 24px; font-weight: bold; color: #333; margin: 10px 0; }",
            "        .chart { margin: 20px 0; }",
            "    </style>",
            "</head>",
            "<body>",
            "    <div class='container'>",
            "        <h1>🚀 Playwright-EZ 性能报告</h1>",
            f"        <p>生成时间: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}</p>",
            f"        <p>共 {len(metrics_list)} 次测量</p>",
        ]

        # 汇总卡片
        if metrics_list:
            avg_load = statistics.mean([m.load for m in metrics_list if m.load > 0])
            avg_fcp = statistics.mean([m.first_contentful_paint for m in metrics_list if m.first_contentful_paint > 0])
            total_resources = sum(len(m.resources) for m in metrics_list)

            html_parts.extend([
                "        <div class='summary'>",
                f"            <div class='summary-card'><h3>平均加载时间</h3><div class='value'>{avg_load:.0f}ms</div></div>",
                f"            <div class='summary-card'><h3>平均 FCP</h3><div class='value'>{avg_fcp:.0f}ms</div></div>",
                f"            <div class='summary-card'><h3>总资源数</h3><div class='value'>{total_resources}</div></div>",
                f"            <div class='summary-card'><h3>测试页面数</h3><div class='value'>{len(metrics_list)}</div></div>",
                "        </div>",
            ])

        # 详细表格
        html_parts.extend([
            "        <h2>📊 详细指标</h2>",
            "        <table>",
            "            <tr>",
            "                <th>URL</th>",
            "                <th>DCL (ms)</th>",
            "                <th>Load (ms)</th>",
            "                <th>FP (ms)</th>",
            "                <th>FCP (ms)</th>",
            "                <th>LCP (ms)</th>",
            "                <th>资源数</th>",
            "            </tr>",
        ])

        for m in metrics_list:
            # 根据加载时间设置样式
            load_class = "good" if m.load < 2000 else "warning" if m.load < 4000 else "bad"
            html_parts.append(
                f"            <tr>"
                f"<td title='{m.url}'>{m.url[:50]}{'...' if len(m.url) > 50 else ''}</td>"
                f"<td>{m.dom_content_loaded:.0f}</td>"
                f"<td class='{load_class}'>{m.load:.0f}</td>"
                f"<td>{m.first_paint:.0f}</td>"
                f"<td>{m.first_contentful_paint:.0f}</td>"
                f"<td>{m.largest_contentful_paint:.0f}</td>"
                f"<td>{len(m.resources)}</td>"
                f"</tr>"
            )

        html_parts.extend([
            "        </table>",
        ])

        # 简单的图表（使用 CSS 柱状图）
        if include_charts and metrics_list:
            html_parts.extend([
                "        <h2>📈 加载时间趋势</h2>",
                "        <div class='chart' style='display: flex; align-items: flex-end; height: 200px; gap: 10px; padding: 20px; background: #fafafa; border-radius: 8px;'>",
            ])

            max_load = max(m.load for m in metrics_list) or 1
            for i, m in enumerate(metrics_list):
                height = (m.load / max_load) * 150
                color = "#4CAF50" if m.load < 2000 else "#FF9800" if m.load < 4000 else "#f44336"
                html_parts.append(
                    f"            <div title='{m.url[:30]}... - {m.load:.0f}ms' "
                    f"style='width: 30px; height: {height}px; background: {color}; border-radius: 4px 4px 0 0; cursor: pointer;'></div>"
                )

            html_parts.append("        </div>")

        # 资源分析
        if metrics_list:
            all_resources = []
            for m in metrics_list:
                all_resources.extend(m.resources)

            if all_resources:
                # 按类型统计
                type_stats: Dict[str, Dict] = {}
                for r in all_resources:
                    if r.resource_type not in type_stats:
                        type_stats[r.resource_type] = {"count": 0, "size": 0, "duration": 0}
                    type_stats[r.resource_type]["count"] += 1
                    type_stats[r.resource_type]["size"] += r.size
                    type_stats[r.resource_type]["duration"] += r.duration

                html_parts.extend([
                    "        <h2>📦 资源分析</h2>",
                    "        <table>",
                    "            <tr>",
                    "                    <th>类型</th>",
                    "                    <th>数量</th>",
                    "                    <th>总大小 (KB)</th>",
                    "                    <th>总耗时 (ms)</th>",
                    "            </tr>",
                ])

                for rtype, stats in sorted(type_stats.items(), key=lambda x: x[1]["duration"], reverse=True):
                    html_parts.append(
                        f"            <tr>"
                        f"<td>{rtype}</td>"
                        f"<td>{stats['count']}</td>"
                        f"<td>{stats['size'] / 1024:.1f}</td>"
                        f"<td>{stats['duration']:.0f}</td>"
                        f"</tr>"
                    )

                html_parts.append("        </table>")

        html_parts.extend([
            "    </div>",
            "</body>",
            "</html>",
        ])

        return "\n".join(html_parts)

    def compare_reports(
        self,
        baseline: PageLoadMetrics,
        current: PageLoadMetrics,
    ) -> Dict[str, Any]:
        """
        对比两次性能数据

        Args:
            baseline: 基线指标
            current: 当前指标

        Returns:
            Dict: 对比结果
        """
        def calc_change(baseline_val: float, current_val: float) -> Dict[str, Any]:
            if baseline_val == 0:
                return {"baseline": 0, "current": current_val, "change": 0, "percent": 0, "status": "new"}

            change = current_val - baseline_val
            percent = (change / baseline_val) * 100

            # 状态判断
            if percent > 10:
                status = "regression"  # 回归（性能下降）
            elif percent < -10:
                status = "improvement"  # 改进
            else:
                status = "stable"  # 稳定

            return {
                "baseline": baseline_val,
                "current": current_val,
                "change": change,
                "percent": percent,
                "status": status,
            }

        comparison = {
            "url": {
                "baseline": baseline.url,
                "current": current.url,
            },
            "metrics": {
                "dom_content_loaded": calc_change(baseline.dom_content_loaded, current.dom_content_loaded),
                "load": calc_change(baseline.load, current.load),
                "first_paint": calc_change(baseline.first_paint, current.first_paint),
                "first_contentful_paint": calc_change(baseline.first_contentful_paint, current.first_contentful_paint),
                "largest_contentful_paint": calc_change(baseline.largest_contentful_paint, current.largest_contentful_paint),
            },
            "resources": {
                "baseline_count": len(baseline.resources),
                "current_count": len(current.resources),
            },
            "timestamp": datetime.now().isoformat(),
        }

        # 添加总结
        regressions = sum(1 for m in comparison["metrics"].values() if m["status"] == "regression")
        improvements = sum(1 for m in comparison["metrics"].values() if m["status"] == "improvement")

        comparison["summary"] = {
            "regressions": regressions,
            "improvements": improvements,
            "overall": "improved" if improvements > regressions else "regressed" if regressions > improvements else "stable",
        }

        return comparison

    def save_report(self, filepath: str, metrics: Optional[List[PageLoadMetrics]] = None) -> None:
        """保存 HTML 报告到文件"""
        report = self.generate_report(metrics)
        with open(filepath, 'w', encoding='utf-8') as f:
            f.write(report)
        logger.info(f"性能报告已保存: {filepath}")

    def save_comparison(
        self,
        filepath: str,
        baseline: PageLoadMetrics,
        current: PageLoadMetrics,
    ) -> None:
        """保存对比报告到文件"""
        comparison = self.compare_reports(baseline, current)
        with open(filepath, 'w', encoding='utf-8') as f:
            json.dump(comparison, f, ensure_ascii=False, indent=2)
        logger.info(f"对比报告已保存: {filepath}")
