"""
DualEngine 双引擎模式类型存根

提供 VSCode/Pylance 类型提示支持。
"""
from typing import Optional, Dict, Any, TYPE_CHECKING

if TYPE_CHECKING:
    from .browser import EasyBrowser


class DualEngineResponse:
    """双引擎响应"""

    url: str
    status_code: int
    headers: Dict[str, str]
    content: bytes
    text: str
    json_data: Optional[Any]
    mode: str
    elapsed: float

    def json(self) -> Any: ...


class DualEngine:
    """双引擎模式"""

    def __init__(
        self,
        browser: Optional["EasyBrowser"] = None,
        requests_session: Optional[Any] = None,
        default_mode: str = "auto",
        static_threshold: float = 0.5,
    ) -> None: ...

    @property
    def requests_session(self) -> Any: ...

    async def get(
        self,
        url: str,
        mode: str = "auto",
        headers: Optional[Dict[str, str]] = None,
        cookies: Optional[Dict[str, str]] = None,
        timeout: float = 30.0,
        **kwargs,
    ) -> DualEngineResponse: ...

    async def post(
        self,
        url: str,
        mode: str = "auto",
        data: Optional[Dict[str, Any]] = None,
        json: Optional[Dict[str, Any]] = None,
        headers: Optional[Dict[str, str]] = None,
        cookies: Optional[Dict[str, str]] = None,
        timeout: float = 30.0,
        **kwargs,
    ) -> DualEngineResponse: ...

    async def put(
        self,
        url: str,
        mode: str = "auto",
        data: Optional[Dict[str, Any]] = None,
        json: Optional[Dict[str, Any]] = None,
        headers: Optional[Dict[str, str]] = None,
        timeout: float = 30.0,
        **kwargs,
    ) -> DualEngineResponse: ...

    async def delete(
        self,
        url: str,
        mode: str = "auto",
        headers: Optional[Dict[str, str]] = None,
        timeout: float = 30.0,
        **kwargs,
    ) -> DualEngineResponse: ...

    async def sync_cookies_to_browser(self) -> None: ...
    async def sync_cookies_to_requests(self) -> None: ...
    async def sync_cookies(self, direction: str = "both") -> None: ...
    async def is_static_page(self, url: str) -> bool: ...
    def clear_cache(self) -> None: ...
    def set_url_type(self, url: str, mode: str) -> None: ...
    def get_stats(self) -> Dict[str, Any]: ...


class DualEngineContext:
    """双引擎上下文管理器"""

    def __init__(
        self,
        config: Optional[Any] = None,
        default_mode: str = "auto",
    ) -> None: ...

    async def __aenter__(self) -> DualEngine: ...
    async def __aexit__(self, exc_type, exc_val, exc_tb) -> None: ...
