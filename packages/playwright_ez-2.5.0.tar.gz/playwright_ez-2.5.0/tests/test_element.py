"""
测试：Element 代理类和极简语法
"""
import pytest
import sys
sys.path.insert(0, "src")

from playwright_ez import EasyBrowser, Config, Element, ElementList
from playwright_ez.browser import ElementLocatorMixin


class TestElementProxy:
    """测试 Element 代理类"""

    @pytest.mark.asyncio
    async def test_element_call_syntax(self):
        """测试 browser('selector') 语法"""
        async with EasyBrowser() as browser:
            await browser.goto("https://example.com")

            # 使用极简语法定位元素
            element = browser("h1")

            # 验证返回的是 Element 类型
            assert isinstance(element, Element)
            assert element._selector == "h1"

    @pytest.mark.asyncio
    async def test_element_text_property(self):
        """测试获取元素文本"""
        async with EasyBrowser() as browser:
            await browser.goto("https://example.com")

            # 获取 h1 的文本
            element = browser("h1")
            text = await element.text

            assert text is not None
            assert "Example Domain" in text

    @pytest.mark.asyncio
    async def test_element_click_and_fill(self):
        """测试元素点击和填充"""
        async with EasyBrowser() as browser:
            await browser.goto("https://www.baidu.com")

            # 定位搜索框
            search_box = browser("#kw")

            # 链式调用：填充并验证
            await search_box.fill("playwright")
            value = await search_box.value

            assert value == "playwright"

    @pytest.mark.asyncio
    async def test_element_chain_calls(self):
        """测试链式调用"""
        async with EasyBrowser() as browser:
            await browser.goto("https://www.baidu.com")

            # 链式调用
            element = browser("#kw")
            result = await element.fill("test").press("Enter")

            # 链式调用应该返回 Element
            assert isinstance(result, Element)

    @pytest.mark.asyncio
    async def test_element_nth_first_last(self):
        """测试 nth/first/last 方法"""
        async with EasyBrowser() as browser:
            await browser.goto("https://example.com")

            # 获取所有段落
            paragraphs = browser("p")

            # 测试 first
            first = paragraphs.first()
            assert isinstance(first, Element)

            # 测试 last
            last = paragraphs.last()
            assert isinstance(last, Element)

            # 测试 nth
            nth_0 = paragraphs.nth(0)
            assert isinstance(nth_0, Element)

    @pytest.mark.asyncio
    async def test_element_wait_for(self):
        """测试元素等待方法"""
        async with EasyBrowser() as browser:
            await browser.goto("https://example.com")

            element = browser("h1")

            # 等待元素可见
            result = await element.wait_until_visible(timeout=5)
            assert isinstance(result, Element)

            # 检查可见性
            is_visible = await element.is_visible()
            assert is_visible

    @pytest.mark.asyncio
    async def test_element_state_checks(self):
        """测试元素状态检查方法"""
        async with EasyBrowser() as browser:
            await browser.goto("https://example.com")

            element = browser("h1")

            # 检查各种状态
            assert await element.is_visible()
            assert await element.is_enabled()
            assert not await element.is_disabled()

    @pytest.mark.asyncio
    async def test_element_count(self):
        """测试元素计数"""
        async with EasyBrowser() as browser:
            await browser.goto("https://example.com")

            element = browser("p")
            count = await element.count()

            assert count >= 1

    @pytest.mark.asyncio
    async def test_element_attributes(self):
        """测试元素属性获取"""
        async with EasyBrowser() as browser:
            await browser.goto("https://example.com")

            # 测试 tag_name
            element = browser("h1")
            tag = await element.tag_name
            assert tag == "h1"

            # 测试 get_attribute
            # 注意：example.com 的 h1 可能没有特定属性
            element2 = browser("a")
            href = await element2.get_attribute("href")
            # href 属性可能存在
            assert href is not None or True  # 宽松检查


class TestElementLocatorMixin:
    """测试元素定位 Mixin"""

    @pytest.mark.asyncio
    async def test_by_text(self):
        """测试 by_text 方法"""
        async with EasyBrowser() as browser:
            await browser.goto("https://example.com")

            element = browser.by_text("Example Domain")
            assert isinstance(element, Element)

    @pytest.mark.asyncio
    async def test_by_css(self):
        """测试 by_css 方法"""
        async with EasyBrowser() as browser:
            await browser.goto("https://example.com")

            element = browser.by_css("h1")
            assert isinstance(element, Element)

    @pytest.mark.asyncio
    async def test_find_all(self):
        """测试 find_all 方法"""
        async with EasyBrowser() as browser:
            await browser.goto("https://example.com")

            elements = browser.find_all("p")
            assert isinstance(elements, ElementList)

            count = await elements.count()
            assert count >= 1


class TestSelectorDetection:
    """测试选择器类型自动检测"""

    @pytest.mark.asyncio
    async def test_css_selector(self):
        """测试 CSS 选择器检测"""
        async with EasyBrowser() as browser:
            await browser.goto("https://example.com")

            # CSS 选择器
            element = browser("h1")
            assert isinstance(element, Element)

    @pytest.mark.asyncio
    async def test_xpath_selector(self):
        """测试 XPath 选择器检测"""
        async with EasyBrowser() as browser:
            await browser.goto("https://example.com")

            # XPath 选择器
            element = browser("//h1")
            assert isinstance(element, Element)

    @pytest.mark.asyncio
    async def test_text_selector(self):
        """测试文本选择器检测"""
        async with EasyBrowser() as browser:
            await browser.goto("https://example.com")

            # 文本选择器
            element = browser("text=Example Domain")
            assert isinstance(element, Element)


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
