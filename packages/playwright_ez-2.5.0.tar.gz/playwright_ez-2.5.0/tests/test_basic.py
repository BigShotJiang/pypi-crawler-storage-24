"""
测试：Playwright-EZ 基础功能
"""
import asyncio
import pytest
import sys
sys.path.insert(0, "/root/.openclaw/workspace/projects/playwright-ez/src")

from playwright_ez import EasyBrowser, Config, WaitCondition


@pytest.mark.asyncio
async def test_browser_start_close():
    """测试浏览器启动和关闭"""
    browser = EasyBrowser()
    
    # 启动
    await browser.start()
    assert browser._browser is not None
    assert len(browser._tabs) == 1
    
    # 关闭
    await browser.close()
    assert browser._browser is None
    assert len(browser._tabs) == 0


@pytest.mark.asyncio
async def test_context_manager():
    """测试上下文管理器"""
    async with EasyBrowser() as browser:
        assert browser._browser is not None
        assert len(browser._tabs) == 1


@pytest.mark.asyncio
async def test_multi_tab():
    """测试多标签页"""
    async with EasyBrowser() as browser:
        # 创建新标签页
        tab1 = await browser.new_tab("tab1")
        assert tab1.name == "tab1"
        assert len(browser._tabs) == 2
        
        tab2 = await browser.new_tab("tab2")
        assert len(browser._tabs) == 3
        
        # 切换标签页
        browser.switch_tab(tab1.id)
        assert browser._current_tab == tab1.id
        
        # 关闭标签页
        await browser.close_tab(tab1.id)
        assert len(browser._tabs) == 2


@pytest.mark.asyncio
async def test_navigation():
    """测试导航"""
    async with EasyBrowser() as browser:
        await browser.goto("https://www.baidu.com")
        tab = browser.get_tab()
        assert "baidu.com" in tab.url


@pytest.mark.asyncio
async def test_click_and_type():
    """测试点击和输入"""
    async with EasyBrowser() as browser:
        await browser.goto("https://www.baidu.com")

        # 获取页面标题
        title = await browser.page.title()
        assert "百度" in title


@pytest.mark.asyncio
async def test_smart_wait():
    """测试智能等待"""
    async with EasyBrowser() as browser:
        await browser.goto("https://www.baidu.com")

        # 使用更稳定的元素 - 页面本身
        locator = browser.page.locator("body")

        # 等待元素附加到DOM
        result = await browser.smart_wait.wait_for(
            locator,
            WaitCondition.ATTACHED,
            timeout=10
        )
        assert result.success


@pytest.mark.asyncio
async def test_screenshot():
    """测试截图"""
    async with EasyBrowser() as browser:
        await browser.goto("https://www.baidu.com")
        
        screenshot = await browser.screenshot("/tmp/test_screenshot.png")
        assert screenshot is not None
        assert len(screenshot) > 0


@pytest.mark.asyncio
async def test_parallel_action():
    """测试并行操作"""
    async with EasyBrowser() as browser:
        # 创建多个标签页
        tab1 = await browser.new_tab("tab1")
        tab2 = await browser.new_tab("tab2")
        
        # 并行执行
        async def get_url(tab):
            return tab.url
        
        results = await browser.parallel_action(get_url)
        assert len(results) == 3  # default + tab1 + tab2


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
