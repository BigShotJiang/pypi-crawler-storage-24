"""
统一入口测试
验证所有模块通过 EasyBrowser 统一访问
"""
import pytest
from playwright_ez import (
    EasyBrowser,
    NetworkMonitor,
    NetworkInterceptor,
    CookieManager,
    SessionManager,
    FormHandler,
    VisualTester,
    ActionRecorder,
    PerformanceAnalyzer,
    FileHandler,
    DataExtractor,
    AutomationHelper,
    DiagnosticsHelper,
    ScraperHelper,
    TestHelper,
    MonitoringHelper,
    SecurityHelper,
    InfiniteScrollHandler,
    PaginationNavigator,
    IframeManager,
    DragDropHelper,
    FileManager,
    ConsoleMonitor,
    ErrorAnalyzer,
    RateLimiter,
    DataValidator,
    AccessibilityChecker,
    SEOChecker,
    SecurityScanner,
)


@pytest.mark.asyncio
async def test_network_accessor():
    """测试网络监控器访问器"""
    async with EasyBrowser() as browser:
        await browser.goto("https://example.com")

        # 验证类型
        assert isinstance(browser.network, NetworkMonitor)
        assert isinstance(browser.interceptor, NetworkInterceptor)


@pytest.mark.asyncio
async def test_session_accessor():
    """测试会话管理器访问器"""
    async with EasyBrowser() as browser:
        await browser.goto("https://example.com")

        # 验证类型
        assert isinstance(browser.cookies, CookieManager)
        assert isinstance(browser.session, SessionManager)


@pytest.mark.asyncio
async def test_form_accessor():
    """测试表单处理器访问器"""
    async with EasyBrowser() as browser:
        await browser.goto("https://example.com")

        assert isinstance(browser.form, FormHandler)


@pytest.mark.asyncio
async def test_visual_accessor():
    """测试视觉测试器访问器"""
    async with EasyBrowser() as browser:
        await browser.goto("https://example.com")

        assert isinstance(browser.visual, VisualTester)


@pytest.mark.asyncio
async def test_recorder_accessor():
    """测试录制器访问器"""
    async with EasyBrowser() as browser:
        await browser.goto("https://example.com")

        assert isinstance(browser.recorder, ActionRecorder)


@pytest.mark.asyncio
async def test_performance_accessor():
    """测试性能分析器访问器"""
    async with EasyBrowser() as browser:
        await browser.goto("https://example.com")

        assert isinstance(browser.performance, PerformanceAnalyzer)


@pytest.mark.asyncio
async def test_file_accessor():
    """测试文件处理器访问器"""
    async with EasyBrowser() as browser:
        await browser.goto("https://example.com")

        assert isinstance(browser.file, FileHandler)


@pytest.mark.asyncio
async def test_extractor_accessor():
    """测试数据提取器访问器"""
    async with EasyBrowser() as browser:
        await browser.goto("https://example.com")

        assert isinstance(browser.extractor, DataExtractor)


@pytest.mark.asyncio
async def test_automation_helper():
    """测试自动化辅助类"""
    async with EasyBrowser() as browser:
        await browser.goto("https://example.com")

        # 验证辅助类类型
        assert isinstance(browser.automation, AutomationHelper)

        # 验证子模块类型
        assert isinstance(browser.automation.infinite_scroll, InfiniteScrollHandler)
        assert isinstance(browser.automation.pagination, PaginationNavigator)
        assert isinstance(browser.automation.iframe, IframeManager)
        assert isinstance(browser.automation.drag_drop, DragDropHelper)
        assert isinstance(browser.automation.file, FileManager)


@pytest.mark.asyncio
async def test_diagnostics_helper():
    """测试诊断辅助类"""
    async with EasyBrowser() as browser:
        await browser.goto("https://example.com")

        # 验证辅助类类型
        assert isinstance(browser.diagnostics, DiagnosticsHelper)

        # 验证子模块类型
        assert isinstance(browser.diagnostics.console, ConsoleMonitor)
        assert isinstance(browser.diagnostics.error, ErrorAnalyzer)


@pytest.mark.asyncio
async def test_scraper_helper():
    """测试数据采集辅助类"""
    async with EasyBrowser() as browser:
        await browser.goto("https://example.com")

        # 验证辅助类类型
        assert isinstance(browser.scraper, ScraperHelper)

        # 验证子模块类型
        assert isinstance(browser.scraper.rate_limiter, RateLimiter)
        assert isinstance(browser.scraper.validator, DataValidator)


@pytest.mark.asyncio
async def test_test_helper():
    """测试测试辅助类"""
    async with EasyBrowser() as browser:
        await browser.goto("https://example.com")

        # 验证辅助类类型
        assert isinstance(browser.test, TestHelper)

        # 验证子模块类型
        assert isinstance(browser.test.accessibility, AccessibilityChecker)


@pytest.mark.asyncio
async def test_monitoring_helper():
    """测试监控辅助类"""
    async with EasyBrowser() as browser:
        await browser.goto("https://example.com")

        # 验证辅助类类型
        assert isinstance(browser.monitor, MonitoringHelper)

        # 验证子模块类型
        assert isinstance(browser.monitor.seo, SEOChecker)


@pytest.mark.asyncio
async def test_security_helper():
    """测试安全辅助类"""
    async with EasyBrowser() as browser:
        await browser.goto("https://example.com")

        # 验证辅助类类型
        assert isinstance(browser.security, SecurityHelper)

        # 验证子模块类型
        assert isinstance(browser.security.scanner, SecurityScanner)


@pytest.mark.asyncio
async def test_lazy_loading():
    """测试懒加载机制"""
    async with EasyBrowser() as browser:
        await browser.goto("https://example.com")

        # 首次访问创建实例
        n1 = browser.network

        # 再次访问返回同一实例
        n2 = browser.network

        assert n1 is n2, "懒加载应返回同一实例"


@pytest.mark.asyncio
async def test_helper_lazy_loading():
    """测试辅助类懒加载机制"""
    async with EasyBrowser() as browser:
        await browser.goto("https://example.com")

        # 首次访问创建实例
        h1 = browser.automation

        # 再次访问返回同一实例
        h2 = browser.automation

        assert h1 is h2, "辅助类懒加载应返回同一实例"


@pytest.mark.asyncio
async def test_multitab_access():
    """测试多标签页访问"""
    async with EasyBrowser() as browser:
        # 创建第一个标签页
        await browser.goto("https://example.com")

        # 获取第一个标签页的网络监控器
        network1 = browser.network

        # 创建第二个标签页
        tab2 = await browser.new_tab("tab2")
        await browser.goto("https://example.org", tab_id=tab2.id)

        # 切换到第一个标签页
        browser.switch_tab("tab_1")

        # 网络监控器应该已重置
        # 注意：这里不验证是否为同一实例，因为标签页切换可能导致重置


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
