"""
测试：RelativeLocator 相对定位器
"""
import pytest
import sys
sys.path.insert(0, "src")

from playwright_ez import EasyBrowser, Config, Element, RelativeLocator


class TestRelativeLocator:
    """测试相对定位器"""

    @pytest.mark.asyncio
    async def test_parent(self):
        """测试获取父元素"""
        async with EasyBrowser() as browser:
            await browser.goto("https://example.com")

            # 获取一个子元素
            element = browser("p")

            # 获取父元素
            parent = element.parent()

            assert isinstance(parent, Element)
            # 父元素应该是 div 或 body
            tag = await parent.tag_name
            assert tag in ["div", "body"]

    @pytest.mark.asyncio
    async def test_parent_multiple_levels(self):
        """测试多级父元素"""
        async with EasyBrowser() as browser:
            await browser.goto("https://example.com")

            element = browser("p")

            # 获取祖父元素（两级）
            grandparent = element.parent(level=2)

            assert isinstance(grandparent, Element)

    @pytest.mark.asyncio
    async def test_child(self):
        """测试获取子元素"""
        async with EasyBrowser() as browser:
            await browser.goto("https://example.com")

            # 获取 body 元素
            body = browser("body")

            # 获取第一个子元素
            first_child = body.child()

            assert isinstance(first_child, Element)

    @pytest.mark.asyncio
    async def test_child_with_selector(self):
        """测试使用选择器获取子元素"""
        async with EasyBrowser() as browser:
            await browser.goto("https://example.com")

            # 获取 body
            body = browser("body")

            # 使用选择器获取子元素
            heading = body.child("h1")

            assert isinstance(heading, Element)
            text = await heading.text
            assert "Example" in text

    @pytest.mark.asyncio
    async def test_next_sibling(self):
        """测试获取下一个兄弟元素"""
        async with EasyBrowser() as browser:
            await browser.goto("https://example.com")

            # 获取 h1
            h1 = browser("h1")

            # 获取下一个兄弟元素
            next_sib = h1.next_sibling()

            assert isinstance(next_sib, Element)
            # 下一个应该是 p 标签
            tag = await next_sib.tag_name
            assert tag == "p"

    @pytest.mark.asyncio
    async def test_prev_sibling(self):
        """测试获取上一个兄弟元素"""
        async with EasyBrowser() as browser:
            await browser.goto("https://example.com")

            # 获取第一个段落
            paragraphs = browser("p")
            first_p = paragraphs.first()

            # 获取上一个兄弟元素
            prev_sib = first_p.prev_sibling()

            assert isinstance(prev_sib, Element)
            # 上一个应该是 h1
            tag = await prev_sib.tag_name
            assert tag == "h1"

    @pytest.mark.asyncio
    async def test_ancestor(self):
        """测试获取祖先元素"""
        async with EasyBrowser() as browser:
            await browser.goto("https://example.com")

            # 获取一个深层元素
            element = browser("p")

            # 查找 body 祖先
            body_ancestor = element.ancestor("body")

            assert isinstance(body_ancestor, Element)
            tag = await body_ancestor.tag_name
            assert tag == "body"

    @pytest.mark.asyncio
    async def test_children(self):
        """测试获取所有子元素"""
        async with EasyBrowser() as browser:
            await browser.goto("https://example.com")

            # 获取 body
            body = browser("body")

            # 获取所有子元素
            children = body.children()

            assert isinstance(children, Element)
            count = await children.count()
            assert count >= 1

    @pytest.mark.asyncio
    async def test_relative_property(self):
        """测试 relative 属性访问"""
        async with EasyBrowser() as browser:
            await browser.goto("https://example.com")

            element = browser("p")

            # 访问 relative 属性
            relative = element.relative

            assert isinstance(relative, RelativeLocator)


class TestCSStoXPath:
    """测试 CSS 到 XPath 转换"""

    @pytest.mark.asyncio
    async def test_id_selector_conversion(self):
        """测试 ID 选择器转换"""
        async with EasyBrowser() as browser:
            await browser.goto("https://example.com")

            # 使用 #id 格式
            # example.com 页面可能没有 id，使用宽松测试
            element = browser("body")
            assert isinstance(element, Element)

    @pytest.mark.asyncio
    async def test_class_selector_conversion(self):
        """测试 class 选择器转换"""
        async with EasyBrowser() as browser:
            await browser.goto("data:text/html,<div class='test-class'>Test</div>")

            # 使用 .class 格式
            element = browser(".test-class")
            text = await element.text
            assert "Test" in text


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
