# Playwright-EZ 🎭

一个功能全面、简单易用的 Playwright 封装库，让浏览器自动化变得简单高效。

## ✨ 核心特性

### 🗂️ 多标签页管理
创建、切换、关闭标签页，并行/顺序执行操作

### 🎨 元素高亮
操作元素时自动高亮显示，方便调试

### ⏳ 智能等待
13种等待条件，自定义条件，带重试执行

### 🔍 智能选择器
CSS/XPath/Text/Role/Placeholder/Label/链式选择器

### 🍪 Cookie & Session管理
保存/加载Cookie，会话状态管理

### 🌐 网络监控 & 拦截
请求日志、API追踪、拦截、模拟响应

### 📁 文件操作
上传/下载文件、批量上传、PDF转换

### 🛡️ 反检测
隐藏自动化特征、人类化操作

### 📝 表单处理
智能填充、验证、登录表单快捷操作

### 🏗️ 页面对象模型(POM)
BasePage、PageFactory、步骤装饰器

### 📊 性能分析
页面加载指标、Web Vitals、资源分析

### 📱 移动端模拟
20+预定义设备、GPS定位、网络条件模拟

### 👁️ 视觉测试
截图对比、差异检测、报告生成

### 🎬 操作录制回放
录制操作、回放、代码自动生成

### 🐛 调试工具
调试信息捕获、错误处理、断言库

### 📤 数据提取
表格/列表提取、JSON-LD、结构化数据

### 🔌 API测试
HTTP请求、Mock服务、GraphQL支持

### 🔗 WebSocket监控
WS连接监控、消息拦截、录制回放

### 🧪 Pytest集成
Fixtures、Hooks、测试报告

### 💻 命令行工具
截图、录制、回放、抓取命令

### 🔐 验证码处理
验证码识别辅助、滑动验证码处理

### 🎲 数据生成
测试数据生成器，支持多种数据类型

### 📈 测试报告
HTML报告、性能报告、覆盖率报告

### 💾 数据库操作
SQLite数据库简化操作

### ⚙️ 环境管理
多环境配置、密钥管理

## 📦 安装

```bash
pip install playwright-ez
playwright install chromium
```

## 🚀 快速开始

```python
import asyncio
from playwright_ez import EasyBrowser

async def main():
    async with EasyBrowser() as browser:
        # 导航
        await browser.goto("https://example.com")
        
        # 操作（自动高亮+智能等待）
        await browser.click("button.submit")
        await browser.type_text("input.email", "test@example.com")
        
        # 获取内容
        text = await browser.get_text("h1")
        print(text)

asyncio.run(main())
```

## 📚 文档

详细文档请参考项目源码中的docstring。

## 📄 License

MIT