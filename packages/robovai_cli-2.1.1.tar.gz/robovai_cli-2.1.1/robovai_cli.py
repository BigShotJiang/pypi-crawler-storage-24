#!/usr/bin/env python3
"""
RoboVAI CLI - Enterprise AI Agent Management Tool
Powered by Nova Platform
https://robovai.tech
"""

import asyncio
import json
import logging
import os
import subprocess
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, Optional

import httpx
import typer
from dotenv import load_dotenv
from rich.console import Console
from rich.panel import Panel
from rich.text import Text
from robovai_cli_core import (
    DeerFlowAdapter,
    build_oss_index,
    check_oss_prune_readiness,
    materialize_persona_file,
    materialize_registry,
    search_personas,
)
from typing_extensions import Annotated

# ═══════════════════════════════════════════════════════════════════════════
# CONFIGURATION
# ═══════════════════════════════════════════════════════════════════════════

load_dotenv()

app = typer.Typer(
    name="robovai",
    help="🤖 RoboVAI CLI - Build and manage AI agents locally or in the cloud.",
    rich_markup_mode="rich",
)

# Configure logging
logging.basicConfig(
    level=logging.INFO, format="%(asctime)s - %(name)s - %(levelname)s - %(message)s"
)
logger = logging.getLogger("robovai-cli")

# Config file paths
CONFIG_DIR = Path.home() / ".robovai"
CONFIG_FILE = CONFIG_DIR / "config.json"
AGENTS_DIR = CONFIG_DIR / "agents"
DEFAULT_OSS_REFERENCES: Dict[str, str] = {
    "deer-flow": "https://github.com/bytedance/deer-flow.git",
    "langflow": "https://github.com/langflow-ai/langflow.git",
    "system-prompts-and-models-of-ai-tools": "https://github.com/x1xhlol/system-prompts-and-models-of-ai-tools.git",
    "opencode": "https://github.com/anomalyco/opencode.git",
    "langchain": "https://github.com/langchain-ai/langchain.git",
    "gemini-cli": "https://github.com/google-gemini/gemini-cli.git",
    "aionui": "https://github.com/iOfficeAI/AionUi.git",
    "plandex": "https://github.com/plandex-ai/plandex.git",
}
OSS_ROOT = Path("oss_references")
PROJECT_ROOT = Path(__file__).resolve().parent

# Initialize directories
CONFIG_DIR.mkdir(exist_ok=True)
AGENTS_DIR.mkdir(exist_ok=True)

console = Console()

# ═══════════════════════════════════════════════════════════════════════════
# STARTUP UI
# ═══════════════════════════════════════════════════════════════════════════


def _build_robovai_ascii_art() -> Text:
    """Create an oversized, space-themed ASCII art logo for ROBOVAI."""
    art_lines = [
        "   ██████╗  ██████╗ ██████╗  ██████╗ ██╗   ██╗ █████╗ ██╗",
        "   ██╔══██╗██╔═══██╗██╔══██╗██╔═══██╗██║   ██║██╔══██╗██║",
        "   ██████╔╝██║   ██║██████╔╝██║   ██║██║   ██║███████║██║",
        "   ██╔══██╗██║   ██║██╔══██╗██║   ██║╚██╗ ██╔╝██╔══██║██║",
        "   ██║  ██║╚██████╔╝██████╔╝╚██████╔╝ ╚████╔╝ ██║  ██║██║",
        "   ╚═╝  ╚═╝ ╚═════╝ ╚═════╝  ╚═════╝   ╚═══╝  ╚═╝  ╚═╝╚═╝",
    ]

    # Color schemes for each character line (gradient from cyan to magenta)
    colors_per_line = [
        "#00d9ff",  # Cyan
        "#00c9ff",  # Cyan-Blue
        "#5fa5ff",  # Blue
        "#9d5eff",  # Purple
        "#d946ff",  # Magenta
        "#ff1493",  # Deep Magenta
    ]

    result = Text(justify="center")
    result.append("\n", style="")
    for line, color in zip(art_lines, colors_per_line):
        result.append(line + "\n", style=f"bold {color}")

    return result


def print_startup_banner() -> None:
    """Render an oversized cosmic startup banner inspired by Copilot & Gemini."""
    # Build the main header with ASCII art
    header = _build_robovai_ascii_art()

    # Build platform info with cosmic styling
    info = Text(justify="center")
    info.append("\n")
    info.append("✦ ✦ ✦  ", style="bold #7ef2c8")
    info.append("Enterprise Agentic Platform", style="bold #7ef2c8")
    info.append("  ✦ ✦ ✦\n", style="bold #7ef2c8")
    info.append("\n")

    # Provider modes
    modes = Text(justify="center")
    modes.append("☁️  Cloud (Groq • NVIDIA • OpenRouter)  +  ", style="bold #68d5ff")
    modes.append("💻 Offline (Ollama)", style="bold #b57ff6")
    modes.append("\n\n", style="")

    # Capabilities
    features = Text(justify="center")
    features.append("⚙  112 Tools  •  ", style="#7ef2c8")
    features.append("🧠 Multi-Agent  •  ", style="#a78bfa")
    features.append("🔒 Secure Automation\n", style="#d979df")

    # Command hint
    hint = Text(justify="center")
    hint.append("\n")
    hint.append("Type ", style="#8390ae")
    hint.append("robovai --help", style="bold #68d5ff")
    hint.append(" • Use ", style="#8390ae")
    hint.append("--no-banner", style="bold #f06fb8")
    hint.append(" to hide", style="#8390ae")

    # Combine all content
    panel_content = Text(justify="center")
    panel_content.append_text(header)
    panel_content.append_text(info)
    panel_content.append_text(modes)
    panel_content.append_text(features)
    panel_content.append_text(hint)

    # Render with cosmic panel
    panel = Panel(
        panel_content,
        title="[bold #7ef2c8]🚀 Welcome to RoboVAI[/bold #7ef2c8]",
        subtitle="[bold #8e8bff]⚡ Powered by Nova[/bold #8e8bff]",
        border_style="#2a4a7c",
        padding=(1, 3),
        expand=False,
    )
    console.print(panel)


@app.callback(invoke_without_command=True)
def main(
    ctx: typer.Context,
    no_banner: Annotated[
        bool,
        typer.Option("--no-banner", help="Disable startup banner"),
    ] = False,
):
    """RoboVAI CLI root callback."""
    if ctx.invoked_subcommand is None and not no_banner:
        if os.getenv("ROBOVAI_CLI_BANNER", "1").strip() != "0":
            print_startup_banner()


# ═══════════════════════════════════════════════════════════════════════════
# UTILITY FUNCTIONS
# ═══════════════════════════════════════════════════════════════════════════


def load_config() -> Dict[str, Any]:
    """Load CLI configuration from home directory."""
    if CONFIG_FILE.exists():
        with open(CONFIG_FILE, "r") as f:
            return json.load(f)
    return {
        "api_url": os.getenv("NOVA_API_URL", "http://localhost:8000"),
        "api_key": os.getenv("NOVA_API_KEY", ""),
        "authenticated": False,
        "provider_mode": os.getenv("LLM_PROVIDER", "auto"),
        "provider_chain": os.getenv(
            "LLM_PROVIDER_CHAIN", "groq,nvidia,openrouter,ollama"
        ),
        "ollama_base_url": os.getenv("OLLAMA_BASE_URL", "http://localhost:11434"),
        "ollama_model": os.getenv("OLLAMA_MODEL", "llama2"),
    }


def save_config(config: Dict[str, Any]) -> None:
    """Save CLI configuration to home directory."""
    with open(CONFIG_FILE, "w") as f:
        json.dump(config, f, indent=2)


def get_headers() -> Dict[str, str]:
    """Get HTTP headers with authentication."""
    config = load_config()
    headers = {"Content-Type": "application/json"}
    if config.get("api_key"):
        headers["Authorization"] = f"Bearer {config['api_key']}"
    return headers


async def api_request(
    method: str,
    endpoint: str,
    data: Optional[Dict] = None,
    api_url: Optional[str] = None,
) -> Dict[str, Any]:
    """Make HTTP request to RoboVAI API."""
    config = load_config()
    base_url = api_url or config.get("api_url", "http://localhost:8000")

    url = f"{base_url.rstrip('/')}/{endpoint.lstrip('/')}"
    headers = get_headers()

    async with httpx.AsyncClient(timeout=30.0) as client:
        try:
            if method.upper() == "GET":
                response = await client.get(url, headers=headers)
            elif method.upper() == "POST":
                response = await client.post(url, json=data, headers=headers)
            elif method.upper() == "PUT":
                response = await client.put(url, json=data, headers=headers)
            elif method.upper() == "DELETE":
                response = await client.delete(url, headers=headers)
            else:
                raise ValueError(f"Unsupported method: {method}")

            response.raise_for_status()
            return response.json() if response.text else {"status": "success"}
        except httpx.HTTPError as e:
            logger.error(f"API request failed: {e}")
            raise typer.Exit(code=1)


def load_agent_config(name: str) -> Dict[str, Any]:
    """Load an agent profile from local CLI storage."""
    agent_file = AGENTS_DIR / f"{name}.json"
    if not agent_file.exists():
        typer.secho(f"❌ Agent '{name}' not found.", fg=typer.colors.RED)
        raise typer.Exit(code=1)
    with open(agent_file, "r") as f:
        return json.load(f)


def _persona_prompt_from_file(file_path: Path) -> str:
    """Load persona/system prompt text from a source file safely."""
    if not file_path.exists() or not file_path.is_file():
        raise ValueError(f"Persona file not found: {file_path}")
    text = file_path.read_text(encoding="utf-8", errors="ignore").strip()
    if not text:
        raise ValueError(f"Persona file is empty: {file_path}")
    return text


# ═══════════════════════════════════════════════════════════════════════════
# AUTH COMMANDS
# ═══════════════════════════════════════════════════════════════════════════


@app.command()
def login(
    api_key: Annotated[str, typer.Option(..., help="Your RoboVAI API key")] = "",
    api_url: Annotated[
        str, typer.Option(help="API URL (default: localhost:8000)")
    ] = "",
):
    """🔐 Authenticate with RoboVAI API."""
    config = load_config()

    if not api_key:
        api_key = typer.prompt("Enter your RoboVAI API key")

    if api_url:
        config["api_url"] = api_url

    config["api_key"] = api_key
    config["authenticated"] = True
    config["authenticated_at"] = datetime.now().isoformat()

    save_config(config)
    typer.secho("✅ Logged in successfully!", fg=typer.colors.GREEN)
    typer.echo(f"   API URL: {config['api_url']}")


@app.command()
def logout():
    """🚪 Logout from RoboVAI."""
    config = load_config()
    config["api_key"] = ""
    config["authenticated"] = False
    save_config(config)
    typer.secho("✅ Logged out successfully!", fg=typer.colors.GREEN)


@app.command()
def whoami():
    """👤 Show current authenticated user/context."""
    config = load_config()
    if not config.get("authenticated"):
        typer.secho(
            "❌ Not authenticated. Run 'robovai login' first.", fg=typer.colors.RED
        )
        raise typer.Exit(code=1)

    typer.echo(f"API URL: {config['api_url']}")
    typer.echo(f"Authenticated: {config.get('authenticated_at')}")


# ═══════════════════════════════════════════════════════════════════════════
# AGENT COMMANDS
# ═══════════════════════════════════════════════════════════════════════════


@app.command()
def agent_create(
    name: Annotated[str, typer.Argument(help="Agent name")],
    model: Annotated[
        str, typer.Option(help="Model (claude, gpt-4, ollama/llama2, etc.)")
    ] = "claude",
    description: Annotated[str, typer.Option(help="Agent description")] = "",
    system_prompt: Annotated[str, typer.Option(help="System prompt instructions")] = "",
):
    """🤖 Create a new AI agent."""
    config = load_config()
    if not config.get("authenticated"):
        typer.secho(
            "❌ Not authenticated. Run 'robovai login' first.", fg=typer.colors.RED
        )
        raise typer.Exit(code=1)

    agent_data = {
        "name": name,
        "model": model,
        "description": description or f"{name} agent",
        "system_prompt": system_prompt or f"You are {name}, a helpful AI assistant.",
        "created_at": datetime.now().isoformat(),
    }

    agent_file = AGENTS_DIR / f"{name}.json"
    with open(agent_file, "w") as f:
        json.dump(agent_data, f, indent=2)

    typer.secho(f"✅ Agent '{name}' created successfully!", fg=typer.colors.GREEN)
    typer.echo(f"   Model: {model}")
    typer.echo(f"   Config: {agent_file}")


@app.command()
def agent_list():
    """📋 List all local agents."""
    agents = list(AGENTS_DIR.glob("*.json"))

    if not agents:
        typer.secho("No agents found.", fg=typer.colors.YELLOW)
        return

    typer.echo("\n[bold]Local Agents:[/bold]")
    for agent_file in agents:
        with open(agent_file, "r") as f:
            agent = json.load(f)
        typer.echo(f"  • {agent['name']} ({agent['model']})")


@app.command()
def agent_delete(
    name: Annotated[str, typer.Argument(help="Agent name")],
):
    """🗑️ Delete an agent."""
    agent_file = AGENTS_DIR / f"{name}.json"

    if not agent_file.exists():
        typer.secho(f"❌ Agent '{name}' not found.", fg=typer.colors.RED)
        raise typer.Exit(code=1)

    if typer.confirm(f"Are you sure you want to delete '{name}'?"):
        agent_file.unlink()
        typer.secho(f"✅ Agent '{name}' deleted.", fg=typer.colors.GREEN)


# ═══════════════════════════════════════════════════════════════════════════
# LOCAL LLM COMMANDS (OLLAMA)
# ═══════════════════════════════════════════════════════════════════════════


@app.command()
def ollama_status():
    """🔍 Check Ollama service status."""
    try:
        import subprocess

        result = subprocess.run(
            ["ollama", "list"], capture_output=True, text=True, timeout=5
        )
        if result.returncode == 0:
            typer.secho("✅ Ollama is running", fg=typer.colors.GREEN)
            typer.echo("\nInstalled models:")
            typer.echo(result.stdout)
        else:
            typer.secho("❌ Ollama error", fg=typer.colors.RED)
            typer.echo(result.stderr)
    except FileNotFoundError:
        typer.secho(
            "❌ Ollama not found. Install it from https://ollama.ai",
            fg=typer.colors.RED,
        )
    except Exception as e:
        typer.secho(f"❌ Error: {e}", fg=typer.colors.RED)


@app.command()
def ollama_pull(
    model_name: Annotated[
        str, typer.Argument(help="Model to pull (e.g., llama2, mistral, neural-chat)")
    ] = "llama2",
):
    """📥 Download an Ollama model locally."""
    try:
        import subprocess

        typer.echo(f"Pulling {model_name}...")
        result = subprocess.run(
            ["ollama", "pull", model_name], capture_output=False, text=True
        )
        if result.returncode == 0:
            typer.secho(
                f"✅ {model_name} downloaded successfully!", fg=typer.colors.GREEN
            )
        else:
            typer.secho(f"❌ Failed to pull {model_name}", fg=typer.colors.RED)
    except FileNotFoundError:
        typer.secho("❌ Ollama not installed.", fg=typer.colors.RED)


@app.command()
def provider_show():
    """🧭 Show current provider mode (cloud/offline/hybrid) and model settings."""
    config = load_config()
    typer.echo("\n[bold]Provider Profile:[/bold]")
    typer.echo(f"  Mode: {config.get('provider_mode', 'auto')}")
    typer.echo(
        f"  Chain: {config.get('provider_chain', 'groq,nvidia,openrouter,ollama')}"
    )
    typer.echo(
        f"  Ollama URL: {config.get('ollama_base_url', 'http://localhost:11434')}"
    )
    typer.echo(f"  Ollama Model: {config.get('ollama_model', 'llama2')}")


@app.command()
def provider_set(
    mode: Annotated[
        str,
        typer.Option(help="Provider mode: auto | cloud | hybrid | offline | ollama"),
    ] = "hybrid",
    chain: Annotated[
        str,
        typer.Option(help="Fallback chain, comma-separated providers"),
    ] = "groq,nvidia,openrouter,ollama",
    ollama_base_url: Annotated[
        str,
        typer.Option(help="Ollama API URL"),
    ] = "http://localhost:11434",
    ollama_model: Annotated[
        str,
        typer.Option(help="Default Ollama model"),
    ] = "llama2",
):
    """⚙️ Configure cloud/offline provider profile for CLI and backend env export."""
    allowed_modes = {"auto", "cloud", "hybrid", "offline", "ollama"}
    if mode not in allowed_modes:
        typer.secho(f"❌ Invalid mode '{mode}'.", fg=typer.colors.RED)
        raise typer.Exit(code=1)

    config = load_config()
    config["provider_mode"] = mode
    config["provider_chain"] = chain
    config["ollama_base_url"] = ollama_base_url
    config["ollama_model"] = ollama_model
    save_config(config)

    typer.secho("✅ Provider profile updated.", fg=typer.colors.GREEN)
    typer.echo("Use these env vars in backend deployment:")
    typer.echo(f"  LLM_PROVIDER={mode}")
    typer.echo(f"  LLM_PROVIDER_CHAIN={chain}")
    typer.echo(f"  OLLAMA_BASE_URL={ollama_base_url}")
    typer.echo(f"  OLLAMA_MODEL={ollama_model}")


# ═══════════════════════════════════════════════════════════════════════════
# ADVANCED LLM PROVIDER COMMANDS
# ═══════════════════════════════════════════════════════════════════════════


@app.command()
def provider_list():
    """📋 List all configured LLM providers (OpenAI, Anthropic, Gemini, etc)."""
    config = load_config()
    api_url = config.get("api_url", "http://localhost:8000")
    token = config.get("api_key")

    headers = {}
    if token:
        headers["Authorization"] = f"Bearer {token}"

    async def _list():
        try:
            async with httpx.AsyncClient(timeout=30.0) as client:
                response = await client.get(
                    f"{api_url}/llm/providers",
                    headers=headers,
                )
                response.raise_for_status()

                data = response.json()
                providers = data.get("providers", [])

                if not providers:
                    typer.echo("[yellow]No providers configured.[/yellow]")
                    return

                typer.echo("\n[bold cyan]Available LLM Providers:[/bold cyan]")
                for provider in providers:
                    status = (
                        "[green]✓[/green]"
                        if provider.get("available")
                        else "[red]✗[/red]"
                    )
                    typer.echo(
                        f"  {status} [bright_cyan]{provider['name']}[/bright_cyan]"
                    )
                    if provider.get("default_model"):
                        typer.echo(f"     Default: {provider['default_model']}")
                    if provider.get("models"):
                        typer.echo(f"     Models: {', '.join(provider['models'][:3])}")
                    typer.echo()

        except Exception as e:
            typer.secho(f"❌ Failed to list providers: {e}", fg=typer.colors.RED)
            raise typer.Exit(code=1)

    asyncio.run(_list())


@app.command()
def provider_models(
    provider_name: Annotated[
        str,
        typer.Option(help="Provider name (openai, anthropic, gemini, mistral, ollama)"),
    ] = "openai",
    show_custom: Annotated[
        bool,
        typer.Option(help="Show how to add custom models"),
    ] = False,
):
    """🤖 List all available LATEST models for a specific provider."""
    config = load_config()
    api_url = config.get("api_url", "http://localhost:8000")
    token = config.get("api_key")

    headers = {}
    if token:
        headers["Authorization"] = f"Bearer {token}"

    async def _models():
        try:
            async with httpx.AsyncClient(timeout=30.0) as client:
                response = await client.get(
                    f"{api_url}/llm/providers/{provider_name}/models",
                    headers=headers,
                )
                response.raise_for_status()

                data = response.json()
                models = data.get("models", [])

                if not models:
                    typer.echo(f"[yellow]No models found for {provider_name}.[/yellow]")
                    return

                typer.echo(
                    f"\n[bold cyan]Models for {provider_name.upper()}:[/bold cyan]"
                )
                for model in models:
                    typer.echo(f"  • {model}")
                    typer.echo()
                    typer.echo("[dim]✓ These are LATEST models from API[/dim]")

                    if show_custom:
                        typer.echo()
                        typer.echo(
                            "[bright_cyan]💡 To use a custom model not in list:[/bright_cyan]"
                        )
                        typer.echo(
                            f"  robovai llm-generate --provider {provider_name} --model my-custom-model"
                        )
                        typer.echo("  (Provider will validate it on use)")

        except Exception as e:
            typer.secho(f"❌ Failed to get models: {e}", fg=typer.colors.RED)
            raise typer.Exit(code=1)

    asyncio.run(_models())


@app.command()
def provider_config(
    provider_name: Annotated[
        str, typer.Argument(help="Provider name (openai, anthropic, gemini)")
    ],
    api_key: Annotated[
        str,
        typer.Option(help="API key"),
    ] = "",
    default_model: Annotated[
        str,
        typer.Option(help="Default model for this provider"),
    ] = "",
):
    """🔑 Configure an LLM provider (API keys, default model)."""
    config = load_config()

    providers_key = "configured_providers"
    if providers_key not in config:
        config[providers_key] = {}

    provider_config = config[providers_key].get(provider_name, {})

    if api_key:
        provider_config["api_key"] = api_key
    if default_model:
        provider_config["default_model"] = default_model

    config[providers_key][provider_name] = provider_config
    save_config(config)

    typer.secho(
        f"✅ {provider_name.upper()} configured successfully!", fg=typer.colors.GREEN
    )

    if api_key:
        masked = f"{api_key[:8]}...{api_key[-4:]}"
        typer.echo(f"  API Key: {masked}")
    if default_model:
        typer.echo(f"  Default Model: {default_model}")

    # Export environment variable info
    typer.echo("\nSet environment variable:")
    typer.echo(f"  {provider_name.upper()}_API_KEY={api_key if api_key else '...'}")
    if default_model:
        typer.echo(f"  {provider_name.upper()}_MODEL={default_model}")


@app.command()
def provider_health():
    """🏥 Check health status of all configured LLM providers."""
    config = load_config()
    api_url = config.get("api_url", "http://localhost:8000")
    token = config.get("api_key")

    headers = {}
    if token:
        headers["Authorization"] = f"Bearer {token}"

    async def _health():
        try:
            async with httpx.AsyncClient(timeout=30.0) as client:
                response = await client.get(
                    f"{api_url}/llm/health",
                    headers=headers,
                )
                response.raise_for_status()

                data = response.json()
                health = data.get("health", {})

                typer.echo("\n[bold cyan]Provider Health Status:[/bold cyan]")
                for provider, status in health.items():
                    status_color = (
                        typer.colors.GREEN if status == "healthy" else typer.colors.RED
                    )
                    typer.echo(
                        f"  {provider:<15} [{typer.style(status, fg=status_color)}]"
                    )

        except Exception as e:
            typer.secho(f"❌ Failed to check health: {e}", fg=typer.colors.RED)
            raise typer.Exit(code=1)

    asyncio.run(_health())


@app.command()
def local_backends():
    """🖥️ Discover and manage local LLM backends (Ollama, vLLM, LM Studio, LocalAI)."""
    config = load_config()
    api_url = config.get("api_url", "http://localhost:8000")
    token = config.get("api_key")

    headers = {}
    if token:
        headers["Authorization"] = f"Bearer {token}"

    async def _backends():
        try:
            async with httpx.AsyncClient(timeout=30.0) as client:
                response = await client.get(
                    f"{api_url}/llm/local-backends",
                    headers=headers,
                )
                response.raise_for_status()

                data = response.json()
                backends = data.get("backends", {})

                typer.echo("\n[bold cyan]Local LLM Backends:[/bold cyan]")

                if not backends:
                    typer.echo("[yellow]No local backends detected.[/yellow]")
                    typer.echo("\nInstall one of:")
                    typer.echo("  • Ollama: ollama.ai")
                    typer.echo("  • vLLM: https://github.com/vllm-project/vllm")
                    typer.echo("  • LM Studio: lmstudio.ai")
                    typer.echo("  • LocalAI: localai.io")
                    return

                for backend_name, info in backends.items():
                    status = (
                        "[green]✓[/green]" if info.get("available") else "[red]✗[/red]"
                    )
                    typer.echo(f"  {status} [bright_cyan]{backend_name}[/bright_cyan]")
                    if info.get("models"):
                        models_str = ", ".join(info["models"][:3])
                        typer.echo(f"     Models: {models_str}")

        except Exception as e:
            typer.secho(f"❌ Failed to get backends: {e}", fg=typer.colors.RED)
            raise typer.Exit(code=1)

    asyncio.run(_backends())


@app.command()
def llm_test(
    provider: Annotated[
        str, typer.Option(help="Provider to test (openai, anthropic, gemini, ollama)")
    ] = "auto",
    prompt: Annotated[str, typer.Option(help="Test prompt")] = "What is 2+2?",
):
    """✈️ Test an LLM provider with a sample prompt."""
    config = load_config()
    api_url = config.get("api_url", "http://localhost:8000")
    token = config.get("api_key")

    headers = {"Authorization": f"Bearer {token}"} if token else {}

    async def _test():
        try:
            typer.echo(f"\nTesting provider: [bold cyan]{provider}[/bold cyan]")
            typer.echo(f"Prompt: {prompt}\n")

            async with httpx.AsyncClient(timeout=60.0) as client:
                response = await client.post(
                    f"{api_url}/llm/generate",
                    json={
                        "prompt": prompt,
                        "provider": provider,
                    },
                    headers=headers,
                )
                response.raise_for_status()

                data = response.json()
                result = data.get("response", "No response")
                used_provider = data.get("provider_used", "unknown")

                typer.echo("[bold]Response:[/bold]")
                typer.echo(f"  {result}\n")
                typer.echo(f"[dim]Used provider: {used_provider}[/dim]")

        except Exception as e:
            typer.secho(f"❌ Test failed: {e}", fg=typer.colors.RED)
            raise typer.Exit(code=1)

    asyncio.run(_test())


@app.command()
def agent_run(
    name: Annotated[str, typer.Argument(help="Agent profile name")],
    message: Annotated[str, typer.Argument(help="Task/message for the agent")],
    ai_level: Annotated[
        str, typer.Option(help="fast | balanced | powerful")
    ] = "balanced",
    user_id: Annotated[str, typer.Option(help="User id in backend")] = "cli_user",
):
    """▶️ Run a local agent profile against Nova backend /agent/run endpoint."""
    config = load_config()
    if not config.get("authenticated"):
        typer.secho(
            "❌ Not authenticated. Run 'robovai login' first.", fg=typer.colors.RED
        )
        raise typer.Exit(code=1)

    agent = load_agent_config(name)
    prompt = (
        f"Agent Name: {agent.get('name')}\n"
        f"Agent Description: {agent.get('description', '')}\n"
        f"System Prompt: {agent.get('system_prompt', '')}\n\n"
        f"User Task: {message}"
    )

    payload = {
        "message": prompt,
        "user_id": user_id,
        "platform": "cli",
        "use_agent": True,
        "ai_level": ai_level,
    }
    result = asyncio.run(api_request("POST", "/agent/run", payload))
    response = result.get("response", "")
    typer.secho("\n✅ Agent Response:", fg=typer.colors.GREEN)
    typer.echo(response)


@app.command()
def multi_agent_run(
    agents: Annotated[
        str, typer.Argument(help="Comma-separated agent names (execution order)")
    ],
    message: Annotated[str, typer.Argument(help="Shared task for all agents")],
    ai_level: Annotated[
        str, typer.Option(help="fast | balanced | powerful")
    ] = "powerful",
    user_id: Annotated[
        str, typer.Option(help="User id in backend")
    ] = "cli_multi_agent",
):
    """🧠 Run multiple agents in sequence and aggregate outputs."""
    config = load_config()
    if not config.get("authenticated"):
        typer.secho(
            "❌ Not authenticated. Run 'robovai login' first.", fg=typer.colors.RED
        )
        raise typer.Exit(code=1)

    agent_names = [a.strip() for a in agents.split(",") if a.strip()]
    if len(agent_names) < 2:
        typer.secho(
            "❌ Provide at least two agents for multi-agent run.", fg=typer.colors.RED
        )
        raise typer.Exit(code=1)

    conversation_context = message
    outputs: Dict[str, str] = {}
    for agent_name in agent_names:
        agent = load_agent_config(agent_name)
        payload = {
            "message": (
                f"Agent Name: {agent.get('name')}\n"
                f"Role: {agent.get('description', '')}\n"
                f"System Prompt: {agent.get('system_prompt', '')}\n\n"
                f"Shared Task: {message}\n"
                f"Previous Agents Context:\n{conversation_context}"
            ),
            "user_id": user_id,
            "platform": "cli",
            "use_agent": True,
            "ai_level": ai_level,
        }
        result = asyncio.run(api_request("POST", "/agent/run", payload))
        answer = result.get("response", "")
        outputs[agent_name] = answer
        conversation_context += f"\n\n[{agent_name}]\n{answer}"
        typer.secho(f"✅ {agent_name} completed", fg=typer.colors.GREEN)

    typer.echo("\n[bold]Multi-agent aggregated output:[/bold]")
    for agent_name, answer in outputs.items():
        typer.echo(f"\n--- {agent_name} ---\n{answer}")


@app.command()
def oss_sync(
    target_dir: Annotated[
        str, typer.Option(help="Directory for OSS references")
    ] = "oss_references",
):
    """📦 Clone or update curated OSS references for acceleration and integration study."""
    root = Path(target_dir)
    root.mkdir(parents=True, exist_ok=True)

    typer.echo("Syncing OSS references (shallow clones)...")
    for name, repo_url in DEFAULT_OSS_REFERENCES.items():
        dest = root / name
        if dest.exists():
            typer.echo(f"↻ Updating {name}...")
            result = subprocess.run(
                ["git", "-C", str(dest), "pull", "--ff-only"],
                capture_output=True,
                text=True,
            )
        else:
            typer.echo(f"↓ Cloning {name}...")
            result = subprocess.run(
                ["git", "clone", "--depth", "1", repo_url, str(dest)],
                capture_output=True,
                text=True,
            )

        if result.returncode != 0:
            typer.secho(f"❌ Failed: {name}", fg=typer.colors.RED)
            if result.stderr:
                typer.echo(result.stderr.strip())
            continue
        typer.secho(f"✅ Ready: {name}", fg=typer.colors.GREEN)


@app.command()
def cli_structure():
    """🧱 Print RoboVAI CLI module structure (requested enterprise baseline)."""
    typer.echo("\n[bold]RoboVAI CLI Module Structure[/bold]")
    typer.echo("robovai-nova/")
    typer.echo("  robovai_cli.py")
    typer.echo("  robovai_cli_core/")
    typer.echo("    __init__.py")
    typer.echo("    models.py")
    typer.echo("    oss_registry.py")
    typer.echo("    persona_catalog.py")
    typer.echo("    workflow_adapter.py")
    typer.echo("  oss_references/")
    typer.echo("    deer-flow/")
    typer.echo("    gemini-cli/")
    typer.echo("    plandex/")
    typer.echo("    langchain/")
    typer.echo("    langflow/")
    typer.echo("    system-prompts-and-models-of-ai-tools/")
    typer.echo("\nUse `robovai oss-index` to verify actual integration status.")


@app.command()
def oss_index(
    target_dir: Annotated[
        str, typer.Option(help="Directory containing OSS references")
    ] = "oss_references",
):
    """📇 Build a local integration index from OSS references."""
    root = Path(target_dir)
    entries = build_oss_index(root, DEFAULT_OSS_REFERENCES)

    typer.echo("\n[bold]OSS Integration Index[/bold]")
    for entry in entries:
        state = "✅" if entry.present else "❌"
        revision = entry.revision or "n/a"
        typer.echo(f"{state} {entry.key:<22} rev={revision:<8} path={entry.local_path}")

    missing = [entry.key for entry in entries if not entry.present]
    if missing:
        typer.secho(
            f"\nMissing repositories: {', '.join(missing)}", fg=typer.colors.YELLOW
        )
        typer.echo("Run `robovai oss-sync` to fetch missing integrations.")


@app.command()
def persona_search(
    query: Annotated[str, typer.Argument(help="Persona keyword or role")],
    limit: Annotated[int, typer.Option(help="Max results")] = 10,
):
    """🔎 Search system-prompts OSS reference for reusable agent personas."""
    prompt_repo = OSS_ROOT / "system-prompts-and-models-of-ai-tools"
    if not prompt_repo.exists():
        typer.secho(
            "❌ system-prompts reference missing. Run `robovai oss-sync` first.",
            fg=typer.colors.RED,
        )
        raise typer.Exit(code=1)

    candidates = search_personas(prompt_repo, query=query, limit=limit)
    if not candidates:
        typer.secho("No persona candidates found.", fg=typer.colors.YELLOW)
        return

    typer.echo("\n[bold]Persona Candidates[/bold]")
    for candidate in candidates:
        typer.echo(f"\n• Title: {candidate.title}")
        typer.echo(f"  File: {candidate.file_path}")
        typer.echo(f"  Snippet: {candidate.snippet}")


@app.command()
def agent_import_persona(
    name: Annotated[str, typer.Argument(help="New local agent name")],
    persona_file: Annotated[
        str,
        typer.Argument(help="Absolute or relative file path to persona prompt source"),
    ],
    model: Annotated[
        str, typer.Option(help="Model (claude, gpt-4, ollama/llama3, etc.)")
    ] = "claude",
    description: Annotated[
        str, typer.Option(help="Optional description override")
    ] = "",
    materialize: Annotated[
        bool,
        typer.Option(
            help="Copy persona file into robovai_assets/personas so it remains after pruning oss_references"
        ),
    ] = True,
):
    """🧠 Import an OSS persona file into local RoboVAI agent profile."""
    persona_path = Path(persona_file)
    if not persona_path.is_absolute():
        persona_path = Path.cwd() / persona_path

    try:
        prompt_text = _persona_prompt_from_file(persona_path)
    except ValueError as exc:
        typer.secho(f"❌ {exc}", fg=typer.colors.RED)
        raise typer.Exit(code=1) from exc

    effective_source = persona_path
    if materialize:
        try:
            effective_source = materialize_persona_file(
                source_file=persona_path,
                project_root=PROJECT_ROOT,
                target_name=name,
            )
            prompt_text = _persona_prompt_from_file(effective_source)
        except Exception as exc:
            typer.secho(f"❌ Failed to materialize persona: {exc}", fg=typer.colors.RED)
            raise typer.Exit(code=1) from exc

    agent_data = {
        "name": name,
        "model": model,
        "description": description or f"Imported persona from {persona_path.name}",
        "system_prompt": prompt_text,
        "source": {
            "type": "materialized-persona" if materialize else "oss-persona",
            "file": str(effective_source),
            "original_file": str(persona_path),
        },
        "created_at": datetime.now().isoformat(),
    }

    agent_file = AGENTS_DIR / f"{name}.json"
    with open(agent_file, "w") as f:
        json.dump(agent_data, f, indent=2)

    typer.secho(f"✅ Agent '{name}' imported from persona.", fg=typer.colors.GREEN)
    typer.echo(f"   Source: {effective_source}")
    if materialize:
        typer.echo("   Mode: materialized (safe for oss_references deletion)")
    typer.echo(f"   Agent File: {agent_file}")


@app.command()
def oss_materialize(
    include: Annotated[
        str,
        typer.Option(
            help="Comma-separated OSS directories to materialize (default: all known references)"
        ),
    ] = "",
    source_dir: Annotated[
        str,
        typer.Option(help="Source OSS reference directory"),
    ] = "oss_references",
):
    """📦 Copy selected OSS artifacts into local robovai_assets for post-prune independence."""
    source_root = Path(source_dir)
    if not source_root.exists():
        typer.secho(
            "❌ Source oss_references directory not found.", fg=typer.colors.RED
        )
        raise typer.Exit(code=1)

    if include.strip():
        items = [item.strip() for item in include.split(",") if item.strip()]
    else:
        items = sorted(DEFAULT_OSS_REFERENCES.keys())

    copied = materialize_registry(
        project_root=PROJECT_ROOT,
        source_root=source_root,
        include=items,
    )

    typer.echo("\n[bold]Materialized OSS Assets[/bold]")
    if not copied:
        typer.secho(
            "No folders were copied. Check --include names.", fg=typer.colors.YELLOW
        )
        return

    for key, destination in copied.items():
        typer.echo(f"✅ {key} -> {destination}")


@app.command()
def oss_prune_check(
    source_dir: Annotated[
        str,
        typer.Option(help="OSS reference directory to evaluate for pruning"),
    ] = "oss_references",
):
    """🧪 Verify whether oss_references can be deleted safely."""
    result = check_oss_prune_readiness(
        project_root=PROJECT_ROOT,
        oss_root=Path(source_dir),
    )
    typer.echo("\n[bold]OSS Prune Readiness[/bold]")
    for key, value in result.items():
        typer.echo(f"  {key}: {value}")


@app.command()
def workflow_status(
    engine: Annotated[
        str,
        typer.Option(help="Workflow engine adapter name: deer-flow"),
    ] = "deer-flow",
):
    """🧩 Show local status of workflow adapters (starting with deer-flow)."""
    if engine != "deer-flow":
        typer.secho(
            "❌ Unsupported engine for now. Supported: deer-flow",
            fg=typer.colors.RED,
        )
        raise typer.Exit(code=1)

    adapter = DeerFlowAdapter(OSS_ROOT / "deer-flow")
    status = adapter.status()
    typer.echo("\n[bold]Workflow Adapter Status[/bold]")
    for key, value in status.items():
        typer.echo(f"  {key}: {value}")


@app.command()
def workflow_run(
    task: Annotated[
        str, typer.Argument(help="Business task to run via workflow engine")
    ],
    engine: Annotated[
        str,
        typer.Option(help="Workflow engine adapter name: deer-flow"),
    ] = "deer-flow",
):
    """⚡ Run a lightweight workflow integration proof (deer-flow adapter)."""
    if engine != "deer-flow":
        typer.secho(
            "❌ Unsupported engine for now. Supported: deer-flow",
            fg=typer.colors.RED,
        )
        raise typer.Exit(code=1)

    adapter = DeerFlowAdapter(OSS_ROOT / "deer-flow")
    result = adapter.run_example(task)

    typer.echo("\n[bold]Workflow Run Result[/bold]")
    for key, value in result.items():
        typer.echo(f"  {key}: {value}")


# ═══════════════════════════════════════════════════════════════════════════
# CONFIG COMMANDS
# ═══════════════════════════════════════════════════════════════════════════


@app.command()
def config_show():
    """⚙️ Show current configuration."""
    config = load_config()
    typer.echo("\n[bold]RoboVAI CLI Configuration:[/bold]")
    typer.echo(f"  API URL: {config.get('api_url')}")
    typer.echo(f"  Authenticated: {config.get('authenticated')}")
    typer.echo(f"  Config File: {CONFIG_FILE}")


@app.command()
def config_set(
    key: Annotated[str, typer.Argument(help="Config key (api_url, api_key)")],
    value: Annotated[str, typer.Argument(help="Config value")],
):
    """🔧 Set a configuration value."""
    config = load_config()
    config[key] = value
    save_config(config)
    typer.secho(f"✅ Config updated: {key} = {value}", fg=typer.colors.GREEN)


# ═══════════════════════════════════════════════════════════════════════════
# MULTI-AGENT COMMANDS
# ═══════════════════════════════════════════════════════════════════════════


@app.command()
def multi_agent_list():
    """📋 List all available agents on backend."""

    async def _list():
        config = load_config()
        api_url = config.get("api_url", "http://localhost:8000")
        token = config.get("api_key")

        headers = {}
        if token:
            headers["Authorization"] = f"Bearer {token}"

        try:
            async with httpx.AsyncClient(timeout=30.0) as client:
                response = await client.get(
                    f"{api_url}/multi-agent/agents", headers=headers
                )
                response.raise_for_status()

                data = response.json()
                agents = data.get("agents", [])

                if not agents:
                    typer.echo("[yellow]ℹ️  No agents registered.[/yellow]")
                    return

                typer.echo("\n[bold cyan]Available Agents:[/bold cyan]")
                for agent in agents:
                    typer.echo(
                        f"  • [bright_cyan]{agent['name']}[/bright_cyan] (ID: {agent['id']})"
                    )
                    typer.echo(f"    Role: {agent.get('role', 'custom')}")
                    typer.echo(f"    Model: {agent.get('model', 'unknown')}")
                    typer.echo(
                        f"    Tools: {len(agent.get('available_tools', []))} available"
                    )
                    typer.echo()
        except Exception as e:
            typer.secho(f"❌ Failed to list agents: {e}", fg=typer.colors.RED)
            raise typer.Exit(code=1)

    asyncio.run(_list())


@app.command()
def multi_agent_execute(
    workflow_id: Annotated[str, typer.Argument(help="Workflow ID to execute")],
    input_data: Annotated[
        str,
        typer.Option(help="JSON input data for workflow (or file path)"),
    ] = "{}",
):
    """⚡ Execute a multi-agent workflow."""

    async def _execute():
        config = load_config()
        api_url = config.get("api_url", "http://localhost:8000")
        token = config.get("api_key")

        headers = {"Content-Type": "application/json"}
        if token:
            headers["Authorization"] = f"Bearer {token}"

        # Parse input data
        try:
            if input_data.startswith("{"):
                payload = json.loads(input_data)
            else:
                # Try to load from file
                with open(input_data, "r") as f:
                    payload = json.load(f)
        except (json.JSONDecodeError, FileNotFoundError) as e:
            typer.secho(f"❌ Invalid input data: {e}", fg=typer.colors.RED)
            raise typer.Exit(code=1)

        try:
            async with httpx.AsyncClient(timeout=300.0) as client:
                response = await client.post(
                    f"{api_url}/multi-agent/workflows/{workflow_id}/execute",
                    json=payload,
                    headers=headers,
                )
                response.raise_for_status()

                result = response.json()
                execution_id = result.get("execution_id")

                typer.secho("\n✅ Workflow execution started!", fg=typer.colors.GREEN)
                typer.echo(f"  Execution ID: [cyan]{execution_id}[/cyan]")
                typer.echo(f"  Status: [yellow]{result.get('status')}[/yellow]")
                typer.echo("\n[bold]Check status with:[/bold]")
                typer.echo(f"  robovai multi-agent-status {execution_id}")
        except Exception as e:
            typer.secho(f"❌ Failed to execute workflow: {e}", fg=typer.colors.RED)
            raise typer.Exit(code=1)

    asyncio.run(_execute())


@app.command()
def multi_agent_status(
    execution_id: Annotated[str, typer.Argument(help="Execution ID to check status")],
):
    """📊 Check multi-agent workflow execution status."""

    async def _status():
        config = load_config()
        api_url = config.get("api_url", "http://localhost:8000")
        token = config.get("api_key")

        headers = {}
        if token:
            headers["Authorization"] = f"Bearer {token}"

        try:
            async with httpx.AsyncClient(timeout=30.0) as client:
                response = await client.get(
                    f"{api_url}/multi-agent/executions/{execution_id}",
                    headers=headers,
                )
                response.raise_for_status()

                execution = response.json()
                status = execution.get("status", "unknown")

                # Color-code status
                status_color = {
                    "completed": typer.colors.GREEN,
                    "failed": typer.colors.RED,
                    "running": typer.colors.YELLOW,
                    "queued": typer.colors.BLUE,
                }.get(status, typer.colors.WHITE)

                typer.echo("\n[bold]Execution Status:[/bold]")
                typer.echo(f"  ID: [cyan]{execution_id}[/cyan]")
                typer.echo(
                    f"  Status: [bold]{typer.style(status, fg=status_color)}[/bold]"
                )
                typer.echo(f"  Workflow: {execution.get('workflow_id')}")
                typer.echo(f"  Submitted: {execution.get('submitted_at')}")

                # Show result if completed
                if execution.get("result"):
                    typer.echo("\n[bold]Result:[/bold]")
                    result = execution["result"]
                    typer.echo(f"  Overall Status: {result.get('status')}")
                    typer.echo(f"  Total Duration: {result.get('total_duration')}s")
                    typer.echo(f"  Total Tokens: {result.get('total_tokens')}")

                    # Show agent results
                    agent_results = result.get("agent_results", {})
                    if agent_results:
                        typer.echo("\n  [bold cyan]Agent Results:[/bold cyan]")
                        for agent_id, agent_result in agent_results.items():
                            typer.echo(f"    • {agent_id}")
                            if isinstance(agent_result, dict):
                                for key, value in agent_result.items():
                                    typer.echo(f"      {key}: {value}")

                # Show error if failed
                if execution.get("error"):
                    typer.secho(
                        f"\n  ❌ Error: {execution['error']}", fg=typer.colors.RED
                    )
        except Exception as e:
            typer.secho(f"❌ Failed to get execution status: {e}", fg=typer.colors.RED)
            raise typer.Exit(code=1)

    asyncio.run(_status())


@app.command()
def multi_agent_workflows():
    """📚 List all defined workflows."""

    async def _workflows():
        config = load_config()
        api_url = config.get("api_url", "http://localhost:8000")
        token = config.get("api_key")

        headers = {}
        if token:
            headers["Authorization"] = f"Bearer {token}"

        try:
            async with httpx.AsyncClient(timeout=30.0) as client:
                response = await client.get(
                    f"{api_url}/multi-agent/workflows", headers=headers
                )
                response.raise_for_status()

                data = response.json()
                workflows = data.get("workflows", [])

                if not workflows:
                    typer.echo("[yellow]ℹ️  No workflows defined.[/yellow]")
                    return

                typer.echo("\n[bold cyan]Defined Workflows:[/bold cyan]")
                for workflow in workflows:
                    typer.echo(
                        f"  • [bright_cyan]{workflow['name']}[/bright_cyan] (ID: {workflow['id']})"
                    )
                    typer.echo(f"    Description: {workflow.get('description', 'N/A')}")
                    typer.echo(f"    Agents: {workflow.get('agents', 0)}")
                    typer.echo(
                        f"    Strategy: {workflow.get('execution_strategy', 'unknown')}"
                    )
                    typer.echo()
        except Exception as e:
            typer.secho(f"❌ Failed to list workflows: {e}", fg=typer.colors.RED)
            raise typer.Exit(code=1)

    asyncio.run(_workflows())


@app.command()
def multi_agent_health():
    """🏥 Check multi-agent system health."""

    async def _health():
        config = load_config()
        api_url = config.get("api_url", "http://localhost:8000")
        token = config.get("api_key")

        headers = {}
        if token:
            headers["Authorization"] = f"Bearer {token}"

        try:
            async with httpx.AsyncClient(timeout=30.0) as client:
                response = await client.get(
                    f"{api_url}/multi-agent/health", headers=headers
                )
                response.raise_for_status()

                health = response.json()
                status = health.get("status", "unknown")

                status_color = (
                    typer.colors.GREEN if status == "healthy" else typer.colors.RED
                )

                typer.echo("\n[bold]Multi-Agent System Health:[/bold]")
                typer.echo(
                    f"  Status: [bold]{typer.style(status, fg=status_color)}[/bold]"
                )
                typer.echo(
                    f"  Registered Agents: {health.get('agents_registered', '?')}"
                )
                typer.echo(
                    f"  Defined Workflows: {health.get('workflows_defined', '?')}"
                )
                typer.echo(
                    f"  Active Executions: {health.get('active_executions', '?')}"
                )
                typer.echo(f"  Total Executions: {health.get('total_executions', '?')}")

                if health.get("error"):
                    typer.secho(f"\n  Error: {health['error']}", fg=typer.colors.RED)
        except Exception as e:
            typer.secho(f"❌ Failed to check health: {e}", fg=typer.colors.RED)
            raise typer.Exit(code=1)

    asyncio.run(_health())


@app.command()
def update_check():
    """🚀 Check for RobovAI Nova updates and latest announcements."""
    console.print(
        Panel.fit(
            "[bold gold1]RoboVAI Nova CLI Update Checker[/bold gold1]\n"
            "Checking upstream for new updates...",
            title="Update",
            border_style="cyan",
        )
    )

    try:
        import requests

        api_url = "https://nova.robovai.tech/api/announcements/active"
        try:
            resp = requests.get(api_url, timeout=5)
            if resp.status_code == 200:
                data = resp.json()
                if data.get("success") and data.get("announcement"):
                    ann = data["announcement"]
                    console.print(
                        f"\n[bold green]📣 Latest Announcement:[/bold green] {ann['title']}"
                    )
                    console.print(f"[white]{ann['content']}[/white]\n")
        except Exception:
            pass  # Fail gracefully if server is down

        # Simulating current fetch vs latest mock logic
        console.print(
            "\n[bold]Current Version:[/bold] v2.1.0\n"
            "[bold green]Latest Release:[/bold green] v2.1.0\n"
            "[bold cyan]Status:[/bold cyan] You are up to date! 🎉\n"
            "\n[link=https://robovai.tech/changelog]🔗 View Full Changelog[/link]"
        )
    except Exception as e:
        console.print(f"[red]Failed to check for updates: {str(e)}[/red]")


# ═══════════════════════════════════════════════════════════════════════════
# MAIN ENTRY POINT
# ═══════════════════════════════════════════════════════════════════════════

if __name__ == "__main__":
    app()
