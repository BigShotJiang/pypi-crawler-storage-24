import os
from setuptools import find_packages, setup

# Read the contents of the beautifully crafted README
with open(os.path.join(os.path.dirname(__file__), "README_PyPI.md"), encoding="utf-8") as f:
    long_description = f.read()

setup(
    name="robovai-cli",
    version="2.1.1",
    description="RobovAI Nova Official Command Line Interface - Enterprise AI Platform",
    long_description=long_description,
    long_description_content_type="text/markdown",
    author="Mo Shaban / RobovAI",
    author_email="contact.robovai@gmail.com",
    url="https://nova.robovai.tech",
    project_urls={
        "Company": "https://robovai.tech",
        "Author": "https://moshaban.me",
    },
    py_modules=["robovai_cli"],
    packages=find_packages(include=["robovai_cli_core", "robovai_cli_core.*"]),
    install_requires=[
        "typer[all]>=0.9.0",
        "httpx>=0.25.0",
        "python-dotenv>=1.0.0",
        "rich>=13.0.0",
        "requests>=2.25.0",
        "colorama>=0.4.6"
    ],
    entry_points={
        "console_scripts": [
            "robovai=robovai_cli:app",
        ],
    },
    python_requires=">=3.10",
    classifiers=[
        "Development Status :: 5 - Production/Stable",
        "Intended Audience :: Developers",
        "Intended Audience :: System Administrators",
        "Topic :: Scientific/Engineering :: Artificial Intelligence",
        "License :: OSI Approved :: MIT License",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Programming Language :: Python :: 3.12",
    ],
)
