"""Examples for the `atomery` package."""
