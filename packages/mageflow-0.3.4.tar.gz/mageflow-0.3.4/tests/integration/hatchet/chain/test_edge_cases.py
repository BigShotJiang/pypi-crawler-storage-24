import asyncio

import pytest

import mageflow
from tests.integration.hatchet.assertions import (
    assert_signature_done,
    assert_signature_not_called,
    get_runs,
)
from tests.integration.hatchet.conftest import HatchetInitData
from tests.integration.hatchet.models import ContextMessage
from tests.integration.hatchet.worker import (
    chain_callback,
    error_callback,
    timeout_task,
)


@pytest.mark.asyncio(loop_scope="session")
async def test__chain__task_timeout__chain_call_error_callback(
    hatchet_client_init: HatchetInitData,
    test_ctx,
    ctx_metadata,
    trigger_options,
    sign_task1,
):
    # Arrange
    redis_client, hatchet = (
        hatchet_client_init.redis_client,
        hatchet_client_init.hatchet,
    )
    success_callback_sign = await mageflow.asign(chain_callback)
    error_callback_sign = await mageflow.asign(error_callback)
    chain_signature = await mageflow.achain(
        [sign_task1, timeout_task],
        success=success_callback_sign,
        error=error_callback_sign,
    )

    # Act
    await chain_signature.aio_run_no_wait(ContextMessage(), options=trigger_options)
    await asyncio.sleep(10)

    # Assert
    runs = await get_runs(hatchet, ctx_metadata)

    assert_signature_done(runs, error_callback_sign)
    assert_signature_not_called(runs, success_callback_sign)
