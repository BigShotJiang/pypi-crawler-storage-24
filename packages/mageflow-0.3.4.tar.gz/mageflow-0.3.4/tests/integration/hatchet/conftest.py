import asyncio
import dataclasses
import logging
import os
import subprocess
import sys
import time
import uuid
from contextlib import contextmanager
from datetime import datetime
from io import BytesIO
from pathlib import Path
from threading import Thread
from typing import AsyncGenerator, Callable, Generator

import psutil
import pytest
import pytest_asyncio
import rapyer
import requests
from hatchet_sdk import Hatchet
from hatchet_sdk.clients.admin import TriggerWorkflowOptions
from hatchet_sdk.clients.rest import V1TaskStatus
from hatchet_sdk.features.runs import BulkCancelReplayOpts, RunFilter
from redis.asyncio.client import Redis
from thirdmagic.task_def import MageflowTaskDefinition

import mageflow
from mageflow import Mageflow
from mageflow.client import HatchetMageflow
from tests.integration.hatchet.worker import (
    chain_callback,
    config_obj,
    fail_task,
    task1,
    task1_callback,
    task2,
    task3,
)

# If redis key starts with one of these, it shouldn't be removed
STATIC_REDIS_PREFIX_KEYS = [MageflowTaskDefinition.__name__]
pytest.register_assert_rewrite("tests.assertions")


@dataclasses.dataclass
class HatchetInitData:
    redis_client: Redis
    hatchet: HatchetMageflow


@pytest_asyncio.fixture(scope="function", loop_scope="session")
async def hatchet() -> AsyncGenerator[Hatchet, None]:
    copy_config = config_obj.model_copy(deep=True)
    hatchet = Hatchet(debug=True, config=copy_config)
    start_time = datetime.now()
    yield hatchet
    bulk_cancel_by_filters = BulkCancelReplayOpts(
        filters=RunFilter(
            since=start_time,
            until=datetime.now(),
            statuses=[V1TaskStatus.RUNNING],
        )
    )
    await hatchet.runs.aio_bulk_cancel(bulk_cancel_by_filters)


@pytest_asyncio.fixture(scope="function", loop_scope="session")
async def hatchet_client_init(
    real_redis, hatchet
) -> AsyncGenerator[HatchetInitData, None]:
    await rapyer.init_rapyer(real_redis, prefer_normal_json_dump=True)
    hatchet = Mageflow(hatchet, real_redis)
    worker_data = HatchetInitData(redis_client=real_redis, hatchet=hatchet)

    yield worker_data

    await rapyer.teardown_rapyer()


@pytest_asyncio.fixture(scope="session", loop_scope="session", autouse=True)
async def hatchet_worker_deploy(
    redis_client,
) -> AsyncGenerator[subprocess.Popen[bytes], None]:
    await redis_client.flushall()
    current_file = Path(__file__).absolute()
    test_worker_path = current_file.parent / "worker.py"
    command = [sys.executable, str(test_worker_path)]

    with hatchet_worker(command) as proc:
        await asyncio.sleep(10)
        yield proc
    await redis_client.flushall()


def wait_for_worker_health(healthcheck_port: int) -> bool:
    worker_healthcheck_attempts = 0
    max_healthcheck_attempts = 25
    last_error = None

    while True:
        if worker_healthcheck_attempts > max_healthcheck_attempts:
            raise last_error
            raise Exception(
                f"Worker failed to start within {max_healthcheck_attempts} seconds"
            )

        try:
            requests.get(f"http://localhost:{healthcheck_port}/health", timeout=5)

            return True
        except Exception as e:
            last_error = e
            time.sleep(1)

        worker_healthcheck_attempts += 1


def log_output(
    pipe: BytesIO, log_func: Callable[[str], None], prefix: str = ""
) -> None:
    for line in iter(pipe.readline, b""):
        decoded_line = line.decode().strip()
        if decoded_line:  # Only log non-empty lines
            log_func(f"[WORKER{prefix}] {decoded_line}")


@contextmanager
def hatchet_worker(
    command: list[str],
    healthcheck_port: int = 8001,
) -> Generator[subprocess.Popen[bytes], None, None]:
    # Configure logging to capture worker output
    logger = logging.getLogger()
    if not logger.handlers:
        logging.basicConfig(
            level=logging.INFO,
            format="%(asctime)s - %(levelname)s - %(message)s",
            force=True,
        )

    logging.info(f"Starting background worker: {' '.join(command)}")

    os.environ["HATCHET_CLIENT_WORKER_HEALTHCHECK_PORT"] = str(healthcheck_port)
    env = os.environ.copy()
    # Find the project root by looking for pyproject.toml
    current_path = Path(__file__).absolute()
    project_root = current_path
    while project_root.parent != project_root:
        if (project_root / "pyproject.toml").exists():
            break
        project_root = project_root.parent

    if not (project_root / "pyproject.toml").exists():
        raise RuntimeError(
            f"Could not find project root with pyproject.toml starting from {current_path}"
        )

    logging.info(f"Project root found: {project_root}")
    logging.info(f"Settings file exists: {(project_root / '.secrets.toml').exists()}")

    # Make sure we have the correct Python path in tox
    python_path = env.get("PYTHONPATH", "")
    if str(project_root) not in python_path:
        if python_path:
            env["PYTHONPATH"] = f"{project_root}:{python_path}"
        else:
            env["PYTHONPATH"] = str(project_root)

    # Enable coverage for subprocess
    env["COVERAGE_PROCESS_START"] = str(project_root / "pyproject.toml")

    proc = subprocess.Popen(
        command,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        env=env,
        cwd=project_root,
    )

    # Check if the process is still running
    if proc.poll() is not None:
        raise Exception(f"Worker failed to start with return code {proc.returncode}")

    Thread(
        target=log_output, args=(proc.stdout, logging.info, "-STDOUT"), daemon=True
    ).start()
    Thread(
        target=log_output, args=(proc.stderr, logging.error, "-STDERR"), daemon=True
    ).start()

    wait_for_worker_health(healthcheck_port=healthcheck_port)

    yield proc

    logging.info("Cleaning up background worker")

    parent = psutil.Process(proc.pid)
    children = parent.children(recursive=True)

    for child in children:
        child.terminate()

    parent.terminate()

    _, alive = psutil.wait_procs([parent] + children, timeout=5)

    for p in alive:
        logging.warning(f"Force killing process {p.pid}")
        p.kill()


async def extract_bad_keys_from_redis(redis_client):
    redis_keys = await redis_client.keys()
    non_persistent_keys = [
        key
        for key in redis_keys
        # Ignore all persistent keys
        if all(
            [
                not key.startswith(approve_prefix)
                for approve_prefix in STATIC_REDIS_PREFIX_KEYS
            ]
        )
    ]
    return non_persistent_keys


@pytest.fixture(scope="function")
def ctx_metadata() -> dict:
    return {"test_run_id": uuid.uuid4().hex}


@pytest.fixture(scope="function")
def trigger_options(ctx_metadata):
    return TriggerWorkflowOptions(additional_metadata=ctx_metadata)


@pytest.fixture(scope="function")
def test_ctx():
    return {"test_data": uuid.uuid4().hex}


@pytest_asyncio.fixture(loop_scope="session")
async def sign_task(req):
    task = req.params
    signature = await mageflow.asign(task)
    return signature


@pytest_asyncio.fixture(scope="function", loop_scope="session")
async def sign_task1():
    signature = await mageflow.asign(task1)
    return signature


@pytest_asyncio.fixture(scope="function", loop_scope="session")
async def sign_task2():
    signature = await mageflow.asign(task2)
    return signature


@pytest_asyncio.fixture(scope="function", loop_scope="session")
async def sign_task3():
    signature = await mageflow.asign(task3)
    return signature


@pytest_asyncio.fixture(scope="function", loop_scope="session")
async def sign_callback1():
    signature = await mageflow.asign(task1_callback)
    return signature


@pytest_asyncio.fixture(scope="function", loop_scope="session")
async def sign_fail_task():
    signature = await mageflow.asign(fail_task)
    return signature


@pytest_asyncio.fixture(scope="function", loop_scope="session")
async def sign_chain_callback():
    signature = await mageflow.asign(chain_callback)
    return signature
