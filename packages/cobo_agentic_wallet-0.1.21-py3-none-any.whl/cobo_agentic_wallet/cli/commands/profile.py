"""Profile commands – list, inspect, switch, archive, and restore agent profiles."""

from __future__ import annotations

import os
import shutil
from pathlib import Path
from typing import Any

import typer

from cobo_agentic_wallet.cli._common import get_context, resolve_wallet_uuid, run_with_client
from cobo_agentic_wallet.cli._output import emit
from cobo_agentic_wallet.client import WalletAPIClient
from cobo_agentic_wallet.cli.config import (
    get_default_profile,
    list_archived_profiles,
    list_profiles,
    load_config,
    load_global_config,
    resolve_credentials_path,
    resolve_profile_dir,
    save_global_config,
    set_default_profile,
)
from cobo_agentic_wallet.cli.tss import TSS_PID_FILE

app = typer.Typer(no_args_is_help=True)


@app.command("list")
def list_cmd(
    ctx: typer.Context,
    archived: bool = typer.Option(
        False,
        "--archived",
        help="Show archived (backed-up) profiles instead of active ones.",
    ),
) -> None:
    """List agent profiles on this machine."""
    context = get_context(ctx)

    if archived:
        agent_ids = list_archived_profiles()
        items = []
        for agent_id in agent_ids:
            backup_dir = resolve_profile_dir(agent_id).parent / f"profile_{agent_id}.bak"
            entry: dict[str, object] = {
                "agent_id": agent_id,
                "archived": True,
                "backup_dir": str(backup_dir),
            }
            creds_file = backup_dir / "credentials"
            try:
                creds = load_config(creds_file)
                entry["env"] = creds.get("env")
                entry["wallet_uuid"] = creds.get("wallet_uuid")
                entry["status"] = creds.get("status")
                entry["onboarded_at"] = creds.get("onboarded_at")
            except (FileNotFoundError, ValueError):
                entry["env"] = None
                entry["wallet_uuid"] = None
                entry["status"] = None
                entry["onboarded_at"] = None
            items.append(entry)
        items.sort(key=lambda e: e.get("onboarded_at") or "", reverse=True)
        emit(items, context.output_format)
        return

    default = get_default_profile()
    profiles = list_profiles()
    items = []
    for agent_id in profiles:
        entry: dict[str, object] = {
            "agent_id": agent_id,
            "active": agent_id == default,
            "profile_dir": str(resolve_profile_dir(agent_id)),
        }
        try:
            creds = load_config(resolve_credentials_path(agent_id))
            entry["env"] = creds.get("env")
            entry["wallet_uuid"] = creds.get("wallet_uuid")
            entry["status"] = creds.get("status")
            entry["onboarded_at"] = creds.get("onboarded_at")
        except (FileNotFoundError, ValueError):
            entry["env"] = None
            entry["wallet_uuid"] = None
            entry["status"] = None
            entry["onboarded_at"] = None
        items.append(entry)
    items.sort(key=lambda e: e.get("onboarded_at") or "", reverse=True)
    emit(items, context.output_format)


@app.command("current")
def current(ctx: typer.Context) -> None:
    """Show the currently active profile and its credentials."""
    context = get_context(ctx)
    default = get_default_profile()
    if not default:
        typer.echo("No active profile. Run 'caw onboard' first.", err=True)
        raise typer.Exit(1)
    result: dict[str, object] = {
        "agent_id": default,
        "profile_dir": str(resolve_profile_dir(default)),
    }
    try:
        creds = load_config(resolve_credentials_path(default))
        result["env"] = creds.get("env")
        result["wallet_uuid"] = creds.get("wallet_uuid")
        result["status"] = creds.get("status")
        result["api_url"] = creds.get("api_url")
        result["onboarded_at"] = creds.get("onboarded_at")
    except (FileNotFoundError, ValueError):
        result["env"] = None
        result["wallet_uuid"] = None
        result["status"] = "credentials_missing"
    emit(result, context.output_format)


@app.command("use")
def use(
    ctx: typer.Context,
    agent_id: str = typer.Argument(help="Agent ID of the profile to activate."),
) -> None:
    """Switch the default profile to a different agent."""
    context = get_context(ctx)
    profiles = list_profiles()
    if agent_id not in profiles:
        typer.echo(
            f"Profile '{agent_id}' not found. Available: {', '.join(profiles) or '(none)'}",
            err=True,
        )
        raise typer.Exit(1)
    set_default_profile(agent_id)
    result: dict[str, object] = {
        "agent_id": agent_id,
        "profile_dir": str(resolve_profile_dir(agent_id)),
        "message": f"Switched to profile '{agent_id}'.",
    }
    emit(result, context.output_format)


@app.command("env")
def env_cmd(ctx: typer.Context) -> None:
    """Show the environment of the active profile (e.g. sandbox, dev, prod)."""
    context = get_context(ctx)
    default = get_default_profile()
    if not default:
        typer.echo("No active profile. Run 'caw onboard' first.", err=True)
        raise typer.Exit(1)
    result: dict[str, object] = {
        "agent_id": default,
    }
    try:
        creds = load_config(resolve_credentials_path(default))
        result["env"] = creds.get("env")
        result["api_url"] = creds.get("api_url")
    except (FileNotFoundError, ValueError):
        result["env"] = None
        result["api_url"] = None
    emit(result, context.output_format)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _stop_tss_in_profile(profile_dir: Path) -> None:
    """Best-effort stop TSS Node inside a profile directory."""
    tss_dir = profile_dir / "tss-node"
    pid_file = tss_dir / TSS_PID_FILE
    if not pid_file.exists():
        return
    try:
        pid = int(pid_file.read_text(encoding="utf-8").strip())
        os.kill(pid, 0)
        import signal

        os.kill(pid, signal.SIGTERM)
        typer.echo(f"Stopped TSS Node (PID {pid})", err=True)
    except (ValueError, OSError):
        pass
    pid_file.unlink(missing_ok=True)


# ---------------------------------------------------------------------------
# Archive & Restore
# ---------------------------------------------------------------------------


@app.command("archive")
def archive(
    ctx: typer.Context,
    agent_id: str | None = typer.Argument(
        None,
        help="Agent ID to archive. Defaults to the active profile.",
    ),
) -> None:
    """Archive a profile (stops TSS, moves to .bak).

    \b
    caw profile archive              Archive the active profile
    caw profile archive <agent_id>   Archive a specific profile

    The profile directory is renamed to profile_<id>.bak for safekeeping.
    Use 'caw profile restore <agent_id>' to bring it back.
    """
    context = get_context(ctx)

    target = agent_id or get_default_profile()
    if not target:
        typer.echo("No profile specified and no active profile.", err=True)
        raise typer.Exit(1)

    profile_dir = resolve_profile_dir(target)
    if not profile_dir.exists():
        typer.echo(f"Profile directory not found: {profile_dir}", err=True)
        raise typer.Exit(1)

    _stop_tss_in_profile(profile_dir)

    backup = Path(f"{profile_dir}.bak")
    if backup.exists():
        shutil.rmtree(backup)
    profile_dir.rename(backup)

    current_default = get_default_profile()
    if current_default == target:
        global_cfg = load_global_config()
        global_cfg.pop("default_profile", None)
        save_global_config(global_cfg)

    result: dict[str, Any] = {
        "agent_id": target,
        "backup": str(backup),
        "status": "archived",
        "message": f"Profile '{target}' archived to {backup}.",
    }
    emit(result, context.output_format)


@app.command("restore")
def restore(
    ctx: typer.Context,
    agent_id: str = typer.Argument(help="Agent ID of the archived profile to restore."),
) -> None:
    """Restore an archived profile from .bak back to active.

    \b
    caw profile restore <agent_id>   Restore a previously archived profile
    """
    context = get_context(ctx)

    profile_dir = resolve_profile_dir(agent_id)
    backup = Path(f"{profile_dir}.bak")

    if not backup.exists():
        typer.echo(
            f"No archived profile found for '{agent_id}'. Expected: {backup}",
            err=True,
        )
        raise typer.Exit(1)

    if profile_dir.exists():
        typer.echo(
            f"Active profile '{agent_id}' already exists at {profile_dir}. "
            "Archive it first before restoring.",
            err=True,
        )
        raise typer.Exit(1)

    backup.rename(profile_dir)

    result: dict[str, Any] = {
        "agent_id": agent_id,
        "profile_dir": str(profile_dir),
        "status": "restored",
        "message": f"Profile '{agent_id}' restored to {profile_dir}.",
    }
    emit(result, context.output_format)


# ---------------------------------------------------------------------------
# Claim
# ---------------------------------------------------------------------------


@app.command("claim")
def claim(
    ctx: typer.Context,
    wallet_uuid: str | None = typer.Option(
        None,
        "--wallet",
        "-w",
        help="Wallet UUID. Defaults to the active profile's wallet.",
    ),
) -> None:
    """Generate a claim link for an autonomous wallet.

    \b
    For wallets created via Autonomous mode (caw onboard --create-wallet),
    this generates a consent token and returns a link that a human can open
    in the Web Console to claim ownership of the wallet.
    """
    from cobo_agentic_wallet_api.models import WalletClaimInitiate

    context = get_context(ctx)
    resolved_wallet = resolve_wallet_uuid(wallet_uuid)

    async def _initiate(client: WalletAPIClient) -> Any:
        payload = WalletClaimInitiate(wallet_id=resolved_wallet)
        return await client.initiate_wallet_claim(payload)

    result = run_with_client(context, _initiate)
    emit(result, context.output_format)


@app.command("claim-info")
def claim_info(
    ctx: typer.Context,
    wallet_uuid: str | None = typer.Option(
        None,
        "--wallet",
        "-w",
        help="Wallet UUID. Defaults to the active profile's wallet.",
    ),
) -> None:
    """Check the claim status of a wallet.

    \b
    Returns the current claim state: not_found, valid (pending), expired, or claimed.
    When valid, includes the agent and wallet details.
    """
    context = get_context(ctx)
    resolved_wallet = resolve_wallet_uuid(wallet_uuid)

    async def _query(client: WalletAPIClient) -> Any:
        return await client.get_claim_info_by_wallet(resolved_wallet)

    result = run_with_client(context, _query)
    emit(result, context.output_format)
