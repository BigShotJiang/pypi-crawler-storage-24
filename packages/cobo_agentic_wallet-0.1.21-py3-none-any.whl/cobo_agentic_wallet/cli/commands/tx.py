"""Transaction and contract call commands."""

from __future__ import annotations

from typing import Any

import typer

from cobo_agentic_wallet.cli._common import (
    run_command,
    resolve_wallet_uuid,
    run_with_client,
    get_context,
)
from cobo_agentic_wallet.client import WalletAPIClient

app = typer.Typer(no_args_is_help=True)


def _ensure_tss_node_online(ctx: typer.Context, wallet_uuid: str) -> None:
    """Check TSS Node status via API; auto-start the local node if offline."""
    context = get_context(ctx)

    async def _check(client: WalletAPIClient) -> Any:
        return await client.get_wallet_node_status(wallet_uuid)

    node_info = run_with_client(context, _check)
    if isinstance(node_info, dict) and node_info.get("online"):
        return

    typer.echo("TSS Node is offline, attempting to start...", err=True)
    try:
        from cobo_agentic_wallet.cli.commands.node import _resolve_binary
        from cobo_agentic_wallet.cli.tss import start_tss_node

        binary = _resolve_binary()
        if binary.exists():
            start_tss_node(
                tss_binary_path=binary,
                reporter=lambda msg: typer.echo(msg, err=True),
            )
        else:
            typer.echo(
                "TSS Node binary not found. Please start the TSS Node manually.",
                err=True,
            )
            raise typer.Exit(1)
    except (FileNotFoundError, RuntimeError) as exc:
        typer.echo(f"Failed to auto-start TSS Node: {exc}", err=True)
        raise typer.Exit(1) from exc


@app.command("transfer")
def transfer(
    ctx: typer.Context,
    wallet_uuid: str | None = typer.Argument(
        None, help="Wallet UUID. Falls back to the wallet_uuid in the config file."
    ),
    to: str = typer.Option(..., "--to", help="Destination address."),
    token: str = typer.Option(
        ...,
        "--token",
        help="Token ID to transfer (e.g. USDC, ETH). Use 'caw meta tokens' to list supported tokens.",
    ),
    amount: str = typer.Option(
        ..., "--amount", help="Amount to transfer as a string (e.g. '10.5')."
    ),
    chain: str = typer.Option(
        "ETH",
        "--chain",
        help="Chain ID (e.g. ETH, BASE, SOLANA). Use 'caw meta chains' to list supported chains.",
    ),
    src_addr: str | None = typer.Option(
        None,
        "--src-addr",
        help="Source address to send from. Defaults to the wallet's primary address for the chain.",
    ),
    request_id: str | None = typer.Option(
        None,
        "--request-id",
        help="Idempotency key to prevent duplicate submissions. Safe to retry with the same value.",
    ),
    fee: str | None = typer.Option(
        None, "--fee", help="Fee configuration as a JSON object (optional override)."
    ),
    sponsor: str = typer.Option(
        "true",
        "--sponsor",
        help="Gas sponsorship: 'true' (default) to use Cobo Gasless — no gas tokens needed. 'false' to pay gas from the sender address.",
    ),
) -> None:
    """Transfer tokens from a wallet. The transfer is evaluated against active policies before submission.

    If the transfer is denied by a policy, a non-zero exit code is returned and the denial details
    are printed to stderr.
    """
    import json as json_module

    wallet_uuid = resolve_wallet_uuid(wallet_uuid)
    _ensure_tss_node_online(ctx, wallet_uuid)
    sponsor_bool = str(sponsor).strip().lower() in ("true", "1", "yes")
    parsed_fee = json_module.loads(fee) if fee else None

    async def _operation(client: WalletAPIClient) -> Any:
        return await client.transfer_tokens(
            wallet_uuid,
            chain_id=chain,
            dst_addr=to,
            token_id=token,
            amount=amount,
            src_addr=src_addr,
            request_id=request_id,
            fee=parsed_fee,
            sponsor=sponsor_bool,
        )

    run_command(ctx, _operation)


@app.command("list")
def list_transactions(
    ctx: typer.Context,
    wallet_uuid: str | None = typer.Argument(
        None, help="Wallet UUID. Falls back to the wallet_uuid in the config file."
    ),
    limit: int = typer.Option(
        50, min=1, max=200, help="Maximum number of results to return (1–200)."
    ),
    offset: int = typer.Option(0, min=0, help="Number of results to skip for pagination."),
    status: str | None = typer.Option(
        None, "--status", help="Filter by transaction status (e.g. submitted, completed, failed)."
    ),
    token: str | None = typer.Option(None, "--token", help="Filter by token ID."),
    chain: str | None = typer.Option(None, "--chain", help="Filter by chain ID."),
) -> None:
    """List pending and in-flight transactions for a wallet."""
    wallet_uuid = resolve_wallet_uuid(wallet_uuid)

    async def _operation(client: WalletAPIClient) -> Any:
        return await client.list_transactions(
            wallet_uuid, limit=limit, offset=offset, status=status, token_id=token, chain_id=chain
        )

    run_command(ctx, _operation)


@app.command("get")
def get_transaction(
    ctx: typer.Context,
    wallet_uuid: str | None = typer.Argument(
        None, help="Wallet UUID. Falls back to the wallet_uuid in the config file."
    ),
    tx_id: str = typer.Argument(
        ..., help="Transaction UUID returned by 'caw tx transfer' or 'caw tx call'."
    ),
) -> None:
    """Get the current status and details of a transaction by its ID."""
    wallet_uuid = resolve_wallet_uuid(wallet_uuid)

    async def _operation(client: WalletAPIClient) -> Any:
        return await client.get_transaction(wallet_uuid, tx_id)

    run_command(ctx, _operation)


@app.command("call")
def contract_call(
    ctx: typer.Context,
    wallet_uuid: str | None = typer.Argument(
        None, help="Wallet UUID. Falls back to the wallet_uuid in the config file."
    ),
    contract: str | None = typer.Option(
        None, "--contract", help="Contract address to call (EVM only)."
    ),
    calldata: str | None = typer.Option(
        None, "--calldata", help="Hex-encoded ABI calldata (EVM only, e.g. 0xa9059cbb...)."
    ),
    chain: str = typer.Option(
        "ETH",
        "--chain",
        help="Chain ID (e.g. ETH, BASE, SOLANA). Use 'caw meta chains' to list supported chains.",
    ),
    value: str = typer.Option(
        "0",
        "--value",
        help="Native token amount to send with the call, in human-readable units (e.g. 0.1 for 0.1 ETH). Default: 0.",
    ),
    src_addr: str | None = typer.Option(
        None,
        "--src-addr",
        help="Source address to send from. Defaults to the wallet's primary address for the chain.",
    ),
    request_id: str | None = typer.Option(
        None,
        "--request-id",
        help="Idempotency key to prevent duplicate submissions. Safe to retry with the same value.",
    ),
    instructions: str | None = typer.Option(
        None, "--instructions", help="Solana instructions as a JSON array (Solana only)."
    ),
    address_lookup_tables: str | None = typer.Option(
        None,
        "--address-lookup-tables",
        help="Solana address lookup table accounts as a JSON array (Solana only).",
    ),
    fee: str | None = typer.Option(
        None, "--fee", help="Fee configuration as a JSON object (optional override)."
    ),
    sponsor: str = typer.Option(
        "true",
        "--sponsor",
        help="Gas sponsorship: 'true' (default) to use Cobo Gasless — no gas tokens needed. 'false' to pay gas from the sender address.",
    ),
) -> None:
    """Call a smart contract from a wallet. The call is evaluated against active policies before submission.

    For EVM chains, provide --contract and --calldata.
    For Solana, provide --instructions (and optionally --address-lookup-tables).

    If the call is denied by a policy, a non-zero exit code is returned and the denial details
    are printed to stderr.
    """
    import json as json_module

    wallet_uuid = resolve_wallet_uuid(wallet_uuid)
    _ensure_tss_node_online(ctx, wallet_uuid)
    sponsor_bool = str(sponsor).strip().lower() in ("true", "1", "yes")
    parsed_instructions = json_module.loads(instructions) if instructions else None
    parsed_lookup_tables = (
        json_module.loads(address_lookup_tables) if address_lookup_tables else None
    )
    parsed_fee = json_module.loads(fee) if fee else None

    async def _operation(client: WalletAPIClient) -> Any:
        return await client.contract_call(
            wallet_uuid,
            chain_id=chain,
            contract_addr=contract,
            calldata=calldata,
            value=value,
            instructions=parsed_instructions,
            address_lookup_table_accounts=parsed_lookup_tables,
            src_addr=src_addr,
            request_id=request_id,
            fee=parsed_fee,
            sponsor=sponsor_bool,
        )

    run_command(ctx, _operation)


@app.command("estimate-transfer-fee")
def estimate_transfer_fee(
    ctx: typer.Context,
    wallet_uuid: str | None = typer.Argument(
        None, help="Wallet UUID. Falls back to the wallet_uuid in the config file."
    ),
    to: str = typer.Option(..., "--to", help="Destination address."),
    token: str = typer.Option(..., "--token", help="Token ID (e.g. USDC, ETH)."),
    amount: str = typer.Option(
        ..., "--amount", help="Amount to transfer as a string (e.g. '10.5')."
    ),
    chain: str = typer.Option("ETH", "--chain", help="Chain ID (e.g. ETH, BASE)."),
    src_addr: str | None = typer.Option(
        None,
        "--src-addr",
        help="Source address. Defaults to the wallet's primary address for the chain.",
    ),
) -> None:
    """Estimate the gas fee for a token transfer without submitting it."""
    wallet_uuid = resolve_wallet_uuid(wallet_uuid)

    async def _operation(client: WalletAPIClient) -> Any:
        return await client.estimate_transfer_fee(
            wallet_uuid,
            chain_id=chain,
            dst_addr=to,
            token_id=token,
            amount=amount,
            src_addr=src_addr,
        )

    run_command(ctx, _operation)


@app.command("estimate-call-fee")
def estimate_contract_call_fee(
    ctx: typer.Context,
    wallet_uuid: str | None = typer.Argument(
        None, help="Wallet UUID. Falls back to the wallet_uuid in the config file."
    ),
    contract: str | None = typer.Option(
        None, "--contract", help="Contract address to call (EVM only)."
    ),
    calldata: str | None = typer.Option(
        None, "--calldata", help="Hex-encoded ABI calldata (EVM only, e.g. 0xa9059cbb...)."
    ),
    chain: str = typer.Option("ETH", "--chain", help="Chain ID (e.g. ETH, BASE)."),
    value: str = typer.Option(
        "0",
        "--value",
        help="Native token amount to send with the call, in human-readable units (e.g. 0.1 for 0.1 ETH). Default: 0.",
    ),
    src_addr: str | None = typer.Option(
        None,
        "--src-addr",
        help="Source address. Defaults to the wallet's primary address for the chain.",
    ),
    instructions: str | None = typer.Option(
        None, "--instructions", help="Solana instructions as a JSON array (Solana only)."
    ),
    address_lookup_tables: str | None = typer.Option(
        None,
        "--address-lookup-tables",
        help="Solana address lookup table accounts as a JSON array (Solana only).",
    ),
) -> None:
    """Estimate the gas fee for a contract call without submitting it."""
    import json as json_module

    wallet_uuid = resolve_wallet_uuid(wallet_uuid)
    parsed_instructions = json_module.loads(instructions) if instructions else None
    parsed_lookup_tables = (
        json_module.loads(address_lookup_tables) if address_lookup_tables else None
    )

    async def _operation(client: WalletAPIClient) -> Any:
        return await client.estimate_contract_call_fee(
            wallet_uuid,
            chain_id=chain,
            contract_addr=contract,
            calldata=calldata,
            value=value,
            instructions=parsed_instructions,
            address_lookup_table_accounts=parsed_lookup_tables,
            src_addr=src_addr,
        )

    run_command(ctx, _operation)


@app.command("drop")
def drop_transaction(
    ctx: typer.Context,
    wallet_uuid: str | None = typer.Argument(
        None, help="Wallet UUID. Falls back to the wallet_uuid in the config file."
    ),
    transaction_uuid: str = typer.Argument(..., help="UUID of the pending transaction to cancel."),
    request_id: str | None = typer.Option(
        None, "--request-id", help="Idempotency key for the drop request."
    ),
    fee: str | None = typer.Option(
        None, "--fee", help="Fee configuration as a JSON object (optional override)."
    ),
    cobo_transaction_id: str | None = typer.Option(
        None, "--cobo-transaction-id", help="Cobo transaction ID."
    ),
) -> None:
    """Cancel a pending transaction that has not yet been broadcast to the chain."""
    import json as json_module

    wallet_uuid = resolve_wallet_uuid(wallet_uuid)
    parsed_fee = json_module.loads(fee) if fee else None

    async def _operation(client: WalletAPIClient) -> Any:
        return await client.drop_transaction(
            wallet_uuid,
            transaction_uuid,
            request_id=request_id,
            fee=parsed_fee,
            cobo_transaction_id=cobo_transaction_id,
        )

    run_command(ctx, _operation)


@app.command("records")
def list_transaction_records(
    ctx: typer.Context,
    wallet_uuid: str | None = typer.Argument(
        None, help="Wallet UUID. Falls back to the wallet_uuid in the config file."
    ),
    limit: int = typer.Option(
        50, min=1, max=200, help="Maximum number of results to return (1–200)."
    ),
    offset: int = typer.Option(0, min=0, help="Number of results to skip for pagination."),
    status: str | None = typer.Option(None, "--status", help="Filter by record status."),
    record_type: str | None = typer.Option(None, "--type", help="Filter by record type."),
    token_id: str | None = typer.Option(None, "--token", help="Filter by token ID."),
    chain_id: str | None = typer.Option(None, "--chain", help="Filter by chain ID."),
) -> None:
    """List the historical transaction record log for a wallet (completed and failed transactions)."""
    wallet_uuid = resolve_wallet_uuid(wallet_uuid)

    async def _operation(client: WalletAPIClient) -> Any:
        return await client.list_transaction_records(
            wallet_uuid,
            limit=limit,
            offset=offset,
            status=status,
            wallet_type=record_type,
            token_id=token_id,
            chain_id=chain_id,
        )

    run_command(ctx, _operation)


@app.command("record")
def get_transaction_record(
    ctx: typer.Context,
    wallet_uuid: str | None = typer.Argument(
        None, help="Wallet UUID. Falls back to the wallet_uuid in the config file."
    ),
    record_uuid: str = typer.Argument(..., help="Transaction record UUID from 'caw tx records'."),
) -> None:
    """Get the details of a single transaction record by its ID."""
    wallet_uuid = resolve_wallet_uuid(wallet_uuid)

    async def _operation(client: WalletAPIClient) -> Any:
        return await client.get_transaction_record(wallet_uuid, record_uuid)

    run_command(ctx, _operation)
