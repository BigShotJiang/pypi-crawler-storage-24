"""Configuration for the Neo Cortex server.

All configuration comes from environment variables, set via .mcp.json env block.
No ~/.accounts, no hardcoded paths, no system env vars.
"""

import os

__all__ = [
    "load_api_key",
    "CORTEX_DB_PATH", "COLLECTION_NAME", "MEMORY_INDEX_DB_PATH",
    "CONVERSATION_DB_PATH",
    "JINA_MODEL", "JINA_DIMENSIONS", "JINA_URL",
    "CLASSIFIER_PROVIDER",
    "GROQ_MODEL", "GROQ_URL",
    "GEMINI_MODEL", "GEMINI_URL",
    "DIGESTOR_MODE", "DIGESTOR_BUDGET", "DIGESTOR_BUDGET_MAX",
    "DIGESTOR_BUDGET_THRESHOLD",
    "CONSOLIDATION_SIMILARITY_THRESHOLD", "CONSOLIDATION_MAX_GROUP_SIZE",
]


def load_api_key(name: str) -> str:
    """Load an API key from environment variable.

    Keys are passed via .mcp.json env block:
        "env": { "JINA_API_KEY": "...", "GROQ_API_KEY": "...", "GEMINI_API_KEY": "..." }
    """
    env_var = f"{name.upper()}_API_KEY"
    env_val = os.environ.get(env_var)
    if env_val:
        return env_val
    raise KeyError(f"Key '{name}' not found — set {env_var} in .mcp.json env block")


# Paths — all derivable from CORTEX_DATA_DIR
# Only override individual paths if you need non-standard layout
_data_dir = os.environ.get("CORTEX_DATA_DIR", os.getcwd())
_default_db = os.path.join(_data_dir, "cortex_db")

CORTEX_DB_PATH = os.environ.get("CORTEX_DB_PATH", _default_db)
COLLECTION_NAME = os.environ.get("CORTEX_COLLECTION", "conversations_v2")

# Memory index (SQLite + FTS5)
MEMORY_INDEX_DB_PATH = os.environ.get("MEMORY_INDEX_DB_PATH", os.path.join(CORTEX_DB_PATH, "memory_index.db"))

# Conversation log
CONVERSATION_DB_PATH = os.environ.get("CONVERSATION_DB_PATH", os.path.join(CORTEX_DB_PATH, "conversation_log.db"))

# Jina embeddings
JINA_MODEL = os.environ.get("JINA_MODEL", "jina-embeddings-v3")
JINA_DIMENSIONS = int(os.environ.get("JINA_DIMENSIONS", "1024"))
JINA_URL = "https://api.jina.ai/v1/embeddings"

# Classifier provider: "gemini" (default) or "groq"
CLASSIFIER_PROVIDER = os.environ.get("CLASSIFIER_PROVIDER", "gemini")

# Groq (legacy — available if CLASSIFIER_PROVIDER=groq)
GROQ_MODEL = os.environ.get("GROQ_MODEL", "llama-3.3-70b-versatile")
GROQ_URL = "https://api.groq.com/openai/v1/chat/completions"

# Gemini (default for classifier + distiller)
GEMINI_MODEL = os.environ.get("GEMINI_MODEL", "gemini-2.0-flash")
GEMINI_URL = "https://generativelanguage.googleapis.com/v1beta"

# Digestor mode: "distill" (Gemini) | "segment" (Groq legacy)
DIGESTOR_MODE = os.environ.get("DIGESTOR_MODE", "distill")

# Digestor batch sizing (tokens)
DIGESTOR_BUDGET = int(os.environ.get("DIGESTOR_BUDGET", "32000"))
DIGESTOR_BUDGET_MAX = int(os.environ.get("DIGESTOR_BUDGET_MAX", "32000"))
DIGESTOR_BUDGET_THRESHOLD = int(os.environ.get("DIGESTOR_BUDGET_THRESHOLD", "200"))


# Consolidation (phase 2 — merge similar memories during idle)
CONSOLIDATION_SIMILARITY_THRESHOLD = float(os.environ.get("CONSOLIDATION_SIMILARITY_THRESHOLD", "0.82"))
CONSOLIDATION_MAX_GROUP_SIZE = int(os.environ.get("CONSOLIDATION_MAX_GROUP_SIZE", "3"))
