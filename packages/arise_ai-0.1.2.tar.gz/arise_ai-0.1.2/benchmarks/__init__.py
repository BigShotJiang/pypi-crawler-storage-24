"""ARISE benchmark suite."""
