"""
Hydra primary config module.
"""
