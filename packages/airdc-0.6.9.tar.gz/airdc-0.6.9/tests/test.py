from copy import deepcopy


lis = [[1, 2]] * 2
lis = deepcopy(lis)
lis[0][0] = 0
print(lis)  # [[0, 2], [0, 2]]
