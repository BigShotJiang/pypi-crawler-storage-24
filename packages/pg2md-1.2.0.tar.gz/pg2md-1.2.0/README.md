# pg2md

[![PyPI version](https://badge.fury.io/py/pg2md.svg)](https://badge.fury.io/py/pg2md)
[![Python](https://img.shields.io/pypi/pyversions/pg2md.svg)](https://pypi.org/project/pg2md/)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)
[![Downloads](https://static.pepy.tech/badge/pg2md)](https://pepy.tech/project/pg2md)
[![GitHub stars](https://img.shields.io/github/stars/lemantorus/pg2md.svg?style=social)](https://github.com/lemantorus/pg2md/stargazers)
[![GitHub issues](https://img.shields.io/github/issues/lemantorus/pg2md.svg)](https://github.com/lemantorus/pg2md/issues)
[![GitHub forks](https://img.shields.io/github/forks/lemantorus/pg2md.svg?style=social)](https://github.com/lemantorus/pg2md/network/members)

**P**a**g**e to **M**ark**d**own — fast HTML-to-Markdown converter with JavaScript rendering support.

Converts any web page to clean Markdown using Playwright for JS rendering and Rust-based `html-to-markdown` for conversion.

## Features

- **Auto Lightpanda** — automatically downloads and starts Lightpanda browser
- **JavaScript Rendering** — handles SPA, React, Vue, dynamic content
- **Fast Conversion** — Rust-based `html-to-markdown` core
- **Clean Output** — strips scripts, styles, navigation, forms
- **Proxy Support** — HTTP/HTTPS/SOCKS5 with auth
- **Custom User-Agents** — includes Googlebot, Bingbot, etc.
- **Async & Sync API** — `parse()` and `async_parse()`
- **Batch Processing** — `async_parse_many()` for parallel requests
- **Configurable** — images, links, headers, timeouts

## Quick Start

```python
from pg2md import PageParser

# Auto-downloads Lightpanda, starts it, and parses page
# If Lightpanda fails, falls back to Chromium automatically
parser = PageParser()
markdown = parser.parse("https://example.com")
print(markdown)
```

First run will download Lightpanda (~50MB) to `~/.cache/pg2md/`.

**Note:** Lightpanda is in beta and may not support all Playwright features. If it fails, pg2md automatically falls back to Chromium.

## Installation

```bash
pip install pg2md
playwright install chromium  # fallback browser if Lightpanda unsupported
```

## Usage Examples

### Basic Usage

```python
from pg2md import PageParser

parser = PageParser()
result = parser.parse("https://example.com")
print(result)
```

### Without Images and Links

```python
from pg2md import PageParser

parser = PageParser(with_image=False, with_link=False)
result = parser.parse("https://example.com")
```

### With Proxy

```python
from pg2md import PageParser, ProxyConfig

proxy = ProxyConfig(
    server="http://proxy.example.com:8080",
    username="user",
    password="pass"
)

parser = PageParser()
result = parser.parse("https://example.com", proxy=proxy)
```

### SOCKS5 Proxy

```python
from pg2md import PageParser, ProxyConfig

proxy = ProxyConfig(server="socks5://127.0.0.1:1080")
parser = PageParser()
result = parser.parse("https://example.com", proxy=proxy)
```

### Custom User-Agent

```python
from pg2md import PageParser, BrowserConfig, UserAgents

config = BrowserConfig(
    cdp_url=None,
    user_agent=UserAgents.GOOGLEBOT_DESKTOP,
    extra_headers={"Accept-Language": "en-US,en;q=0.9"}
)

parser = PageParser(browser_config=config)
result = parser.parse("https://example.com")
```

### Async API

```python
import asyncio
from pg2md import PageParser

async def main():
    parser = PageParser()
    result = await parser.async_parse("https://example.com")
    print(result)

asyncio.run(main())
```

### Batch Processing

```python
import asyncio
from pg2md import PageParser

async def main():
    parser = PageParser()
    urls = [
        "https://example.com",
        "https://example.org",
        "https://example.net",
    ]
    results = await parser.async_parse_many(urls)
    
    for url, result in results.items():
        if isinstance(result, Exception):
            print(f"Error {url}: {result}")
        else:
            print(f"{url}: {len(result)} chars")

asyncio.run(main())
```

### Using Lightpanda

```python
from pg2md import PageParser, BrowserConfig

# Start Lightpanda manually:
# ./lightpanda serve --host 127.0.0.1 --port 9222

config = BrowserConfig(cdp_url="ws://127.0.0.1:9222")
parser = PageParser(browser_config=config)
result = parser.parse("https://example.com")
```

## Configuration

### BrowserConfig

| Parameter | Type | Default | Description |
|-----------|------|---------|-------------|
| `cdp_url` | `str \| None` | `"auto"` | `"auto"` = auto Lightpanda, `None` = Chromium, `"ws://..."` = custom CDP |
| `lightpanda_bin` | `str \| None` | `None` | Path to Lightpanda binary (for manual start) |
| `navigation_timeout` | `int` | `60000` | Navigation timeout (ms) |
| `wait_until` | `str` | `"domcontentloaded"` | Wait event (`"load"`, `"domcontentloaded"`, `"networkidle"`) |
| `default_proxy` | `ProxyConfig \| None` | `None` | Default proxy for all requests |
| `user_agent` | `str \| None` | Chrome Desktop | User-Agent string |
| `extra_headers` | `dict \| None` | `None` | Additional HTTP headers |
| `viewport` | `dict \| None` | `{"width": 1920, "height": 1080}` | Browser viewport size |

### ProxyConfig

| Parameter | Type | Default | Description |
|-----------|------|---------|-------------|
| `server` | `str` | required | Proxy URL |
| `username` | `str \| None` | `None` | Username |
| `password` | `str \| None` | `None` | Password |
| `bypass` | `str \| None` | `None` | Hosts to bypass |

### UserAgents

Available presets:

- `CHROME_DESKTOP`, `CHROME_MAC`, `CHROME_LINUX`
- `FIREFOX_DESKTOP`
- `SAFARI_MAC`
- `EDGE`
- `GOOGLEBOT_DESKTOP`, `GOOGLEBOT_MOBILE`, `GOOGLEBOT_VIDEO`
- `BINGBOT`, `BINGBOT_MOBILE`
- `YANDEXBOT`
- `DUCKBOT`
- `APPLEBOT`

## API Reference

### PageParser

```python
PageParser(
    with_image: bool = False,
    with_link: bool = True,
    browser_config: BrowserConfig | None = None
)
```

#### Methods

| Method | Description |
|--------|-------------|
| `parse(url, proxy=None)` | Sync parse, returns Markdown string |
| `async_parse(url, proxy=None)` | Async parse, returns Markdown string |
| `async_parse_many(urls, proxy=None)` | Batch async parse, returns dict |
| `stop_lightpanda()` | Stop Lightpanda if started |

## Development

```bash
git clone https://github.com/lemantorus/pg2md.git
cd pg2md
python -m venv venv
source venv/bin/activate
pip install -e ".[dev]"
playwright install chromium
```

## License

[MIT](LICENSE)

## Credits

- [Playwright](https://playwright.dev/python/) — browser automation
- [html-to-markdown](https://pypi.org/project/html-to-markdown/) — Rust-based HTML to Markdown
- [BeautifulSoup](https://www.crummy.com/software/BeautifulSoup/) — HTML parsing
