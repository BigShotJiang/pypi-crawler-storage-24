"""
PageParser — Parser for web pages with JS rendering via Lightpanda/Playwright
and conversion to clean Markdown.

Dependencies:
    pip install playwright html-to-markdown beautifulsoup4
    playwright install chromium  # if using regular Chrome, not Lightpanda

Running Lightpanda (optional, instead of Chrome):
    ./lightpanda serve --host 127.0.0.1 --port 9222

Usage:
    parser = PageParser(with_image=False, with_link=False)

    # Without proxy
    result = parser.parse("https://example.com")

    # With proxy for a specific request
    proxy = ProxyConfig(server="http://1.2.3.4:8080", username="user", password="pass")
    result = parser.parse("https://example.com", proxy=proxy)

    print(result)
"""

import re
import subprocess
import time
import asyncio
from dataclasses import dataclass
from typing import Optional, Literal

from bs4 import BeautifulSoup
from html_to_markdown import convert, ConversionOptions, PreprocessingOptions
from playwright.async_api import async_playwright, ProxySettings, ViewportSize

from pg2md import lightpanda


@dataclass
class ProxyConfig:
    """
    Proxy settings for a single request.

    Supported server formats:
        http://host:port
        https://host:port
        socks5://host:port

    Args:
        server   : proxy address (required)
        username : login (optional)
        password : password (optional)
        bypass   : comma-separated list of hosts to bypass proxy
                   (e.g. "localhost,127.0.0.1")
    """

    server: str
    username: Optional[str] = None
    password: Optional[str] = None
    bypass: Optional[str] = None

    def to_playwright(self) -> ProxySettings:
        """Converts to Playwright ProxySettings format."""
        settings: ProxySettings = {"server": self.server}
        if self.username:
            settings["username"] = self.username
        if self.password:
            settings["password"] = self.password
        if self.bypass:
            settings["bypass"] = self.bypass
        return settings


class UserAgents:
    """Popular User-Agent strings for bypassing blocks."""

    CHROME_DESKTOP = (
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) "
        "Chrome/120.0.0.0 Safari/537.36"
    )

    CHROME_MAC = (
        "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) "
        "Chrome/120.0.0.0 Safari/537.36"
    )

    FIREFOX_DESKTOP = (
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:121.0) Gecko/20100101 Firefox/121.0"
    )

    SAFARI_MAC = (
        "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) "
        "Version/17.2 Safari/605.1.15"
    )

    EDGE = (
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) "
        "Chrome/120.0.0.0 Safari/537.36 Edg/120.0.0.0"
    )

    GOOGLEBOT_DESKTOP = "Mozilla/5.0 (compatible; Googlebot/2.1; +http://www.google.com/bot.html)"

    GOOGLEBOT_MOBILE = (
        "Mozilla/5.0 (Linux; Android 6.0.1; Nexus 5X Build/MMB29P) "
        "AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.6099.71 MobileSafari/537.36 "
        "(compatible; Googlebot/2.1; +http://www.google.com/bot.html)"
    )

    GOOGLEBOT_VIDEO = (
        "Mozilla/5.0 (Linux; Android 6.0.1; Nexus 5X Build/MMB29P) "
        "AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.6099.71 MobileSafari/537.36 "
        "Googlebot/2.1"
    )

    BINGBOT = "Mozilla/5.0 (compatible; bingbot/2.0; +http://www.bing.com/bingbot.htm)"

    BINGBOT_MOBILE = (
        "Mozilla/5.0 (iPhone; CPU iPhone OS 16_6 like Mac OS X) AppleWebKit/605.1.15 "
        "(KHTML, like Gecko) Version/16.6 Mobile/15E148 BingWeb/7.15.13.7055 (advisor; +http://www.bing.com/bingbot.htm)"
    )

    YANDEXBOT = "Mozilla/5.0 (compatible; YandexBot/3.0; +http://yandex.com/bots)"

    DUCKBOT = "DuckDuckBot/1.0; (+http://duckduckgo.com/duckduckbot.html)"

    APPLEBOT = (
        "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) "
        "Version/17.0 Safari/605.1.15 Applebot/0.1"
    )

    CHROME_LINUX = (
        "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) "
        "Chrome/120.0.0.0 Safari/537.36"
    )


@dataclass
class BrowserConfig:
    """
    Browser connection settings.

    cdp_url options:
        "auto"  - Auto-download and start Lightpanda (default)
        None    - Use built-in Chromium via Playwright
        "ws://host:port" - Connect to existing CDP server (Lightpanda/Chrome)
    """

    cdp_url: Optional[str] = "auto"
    lightpanda_bin: Optional[str] = None
    navigation_timeout: int = 60_000
    wait_until: Literal["load", "domcontentloaded", "networkidle"] = "domcontentloaded"
    default_proxy: Optional[ProxyConfig] = None
    user_agent: Optional[str] = UserAgents.CHROME_DESKTOP
    extra_headers: Optional[dict[str, str]] = None
    viewport: Optional[ViewportSize] = None

    def __post_init__(self):
        if self.viewport is None:
            self.viewport = {"width": 1920, "height": 1080}


class HtmlCleaner:
    """
    Cleans HTML before converting to Markdown:
      - removes <script>, <style>, <noscript>, <svg>, <canvas>, <video>, <audio>
      - removes <img> (optional)
      - removes href/src with data:, blob: (base64 junk)
      - strips links, keeping only text (optional)
    """

    ALWAYS_STRIP_TAGS = [
        "script",
        "style",
        "noscript",
        "svg",
        "canvas",
        "video",
        "audio",
        "iframe",
        "object",
        "embed",
        "head",
    ]

    def __init__(self, with_image: bool = False, with_link: bool = True):
        self.with_image = with_image
        self.with_link = with_link

    def clean(self, html: str) -> str:
        soup = BeautifulSoup(html, "html.parser")

        for tag in self.ALWAYS_STRIP_TAGS:
            for el in soup.find_all(tag):
                el.decompose()

        if not self.with_image:
            for el in soup.find_all("img"):
                el.decompose()
        else:
            for el in soup.find_all("img"):
                src = el.get("src", "")
                if isinstance(src, str) and (src.startswith("data:") or src.startswith("blob:")):
                    el.decompose()

        if not self.with_link:
            for el in soup.find_all("a"):
                el.replace_with(el.get_text())
        else:
            for el in soup.find_all("a"):
                href = el.get("href", "")
                if isinstance(href, str) and (href.startswith("data:") or href.startswith("blob:")):
                    el["href"] = ""

        for el in soup.find_all(True):
            for attr in ("src", "href", "srcset", "poster", "background"):
                val = el.get(attr, "")
                if isinstance(val, str) and (val.startswith("data:") or val.startswith("blob:")):
                    del el[attr]

        return str(soup)


class MarkdownCleaner:
    """Final cleanup of ready Markdown text."""

    _BASE64_LINE = re.compile(r"^[A-Za-z0-9+/=]{40,}\s*$", re.MULTILINE)
    _BINARY_GARBAGE = re.compile(r"[\x00-\x08\x0b\x0c\x0e-\x1f\x7f-\x9f]")
    _EXCESS_NEWLINES = re.compile(r"\n{3,}")
    _MD_IMAGE = re.compile(r"!\[.*?\]\(.*?\)")

    def clean(self, text: str, strip_images: bool = False) -> str:
        text = self._BINARY_GARBAGE.sub("", text)
        text = self._BASE64_LINE.sub("", text)

        if strip_images:
            text = self._MD_IMAGE.sub("", text)

        text = self._EXCESS_NEWLINES.sub("\n\n", text)

        return text.strip()


class PageParser:
    """
    Parses web pages with JS rendering and returns clean Markdown.

    Args:
        with_image     (bool)         : Include images in output. Default False.
        with_link      (bool)         : Include links (href). Default True.
                                        False — links are replaced with their text.
        browser_config (BrowserConfig): Browser connection settings.
                                        Can set default_proxy for all requests.

    Proxy is passed to parse() / async_parse() per-request:
        proxy = ProxyConfig(server="socks5://1.2.3.4:1080")
        result = parser.parse("https://example.com", proxy=proxy)
    """

    def __init__(
        self,
        with_image: bool = False,
        with_link: bool = True,
        browser_config: Optional[BrowserConfig] = None,
    ):
        self.with_image = with_image
        self.with_link = with_link
        self.config = browser_config or BrowserConfig()

        self._html_cleaner = HtmlCleaner(with_image=with_image, with_link=with_link)
        self._md_cleaner = MarkdownCleaner()

        self._lightpanda_proc: Optional[subprocess.Popen] = None
        self._auto_lightpanda_proc: Optional[subprocess.Popen] = None
        self._auto_cdp_url: Optional[str] = None

    def parse(self, url: str, proxy: Optional[ProxyConfig] = None) -> str:
        """
        Synchronous wrapper over async_parse.

        Args:
            url   : page to parse
            proxy : proxy for this specific request (overrides default_proxy)
        """
        return asyncio.run(self.async_parse(url, proxy=proxy))

    async def async_parse(self, url: str, proxy: Optional[ProxyConfig] = None) -> str:
        """
        Loads page, renders JS, returns clean Markdown.

        Args:
            url   : page to parse
            proxy : proxy for this specific request (overrides default_proxy)
        """
        html = await self._fetch_html(url, proxy=proxy)
        return self._html_to_markdown(html)

    async def async_parse_many(
        self,
        urls: list[str],
        proxy: Optional[ProxyConfig] = None,
    ) -> dict[str, str | BaseException]:
        """
        Parses multiple URLs in parallel.

        Args:
            urls  : list of pages
            proxy : one proxy for all requests (or None)
        """
        tasks = [self.async_parse(url, proxy=proxy) for url in urls]
        results = await asyncio.gather(*tasks, return_exceptions=True)
        return {url: res for url, res in zip(urls, results)}

    async def _fetch_html(self, url: str, proxy: Optional[ProxyConfig] = None) -> str:
        """Opens browser, loads page, returns HTML."""
        self._maybe_start_lightpanda()

        effective_proxy = proxy or self.config.default_proxy
        proxy_settings = effective_proxy.to_playwright() if effective_proxy else None

        headers = {}
        cdp_url = self._resolve_cdp_url()
        use_cdp = cdp_url is not None
        if use_cdp and self.config.user_agent:
            headers["User-Agent"] = self.config.user_agent
        if self.config.extra_headers:
            headers.update(self.config.extra_headers)

        async with async_playwright() as pw:
            fallback_to_chromium = False

            while True:
                try:
                    if use_cdp and not fallback_to_chromium:
                        browser = await pw.chromium.connect_over_cdp(cdp_url)
                        context = await browser.new_context(
                            proxy=proxy_settings,
                            extra_http_headers=headers if headers else None,
                            viewport=self.config.viewport,
                        )
                    else:
                        browser = await pw.chromium.launch(headless=True)
                        context = await browser.new_context(
                            proxy=proxy_settings,
                            user_agent=self.config.user_agent,
                            extra_http_headers=headers if headers else None,
                            viewport=self.config.viewport,
                        )

                    page = await context.new_page()

                    try:
                        await page.goto(
                            url,
                            timeout=self.config.navigation_timeout,
                            wait_until=self.config.wait_until,
                        )
                        await page.wait_for_timeout(1500)
                        html = await page.content()
                    finally:
                        await page.close()
                        await context.close()
                        await browser.close()

                    return html

                except Exception as e:
                    if use_cdp and not fallback_to_chromium and self.config.cdp_url == "auto":
                        print(f"[pg2md] Lightpanda failed: {e}")
                        print("[pg2md] Falling back to Chromium...")
                        self._stop_auto_lightpanda()
                        fallback_to_chromium = True
                        continue
                    else:
                        raise

    def _resolve_cdp_url(self) -> Optional[str]:
        """Resolve CDP URL based on config."""
        if self.config.cdp_url == "auto":
            if self._auto_cdp_url:
                return self._auto_cdp_url

            if lightpanda.is_supported():
                self._auto_lightpanda_proc = lightpanda.start()
                self._auto_cdp_url = "ws://127.0.0.1:9222"
                return self._auto_cdp_url
            else:
                return None
        return self.config.cdp_url

    def _html_to_markdown(self, html: str) -> str:
        """Cleans HTML and converts to Markdown."""

        clean_html = self._html_cleaner.clean(html)

        options = ConversionOptions(
            heading_style="atx",
            strong_em_symbol="*",
            bullets="*",
            escape_asterisks=False,
        )
        preprocessing = PreprocessingOptions(
            enabled=True,
            preset="aggressive",
            remove_navigation=True,
            remove_forms=True,
        )
        markdown = convert(clean_html, options, preprocessing)

        markdown = self._md_cleaner.clean(markdown, strip_images=not self.with_image)

        return markdown

    def _maybe_start_lightpanda(self) -> None:
        """If binary path is set and process not running — start it."""
        if not self.config.lightpanda_bin:
            return
        if self._lightpanda_proc and self._lightpanda_proc.poll() is None:
            return

        self._lightpanda_proc = subprocess.Popen(
            [
                self.config.lightpanda_bin,
                "serve",
                "--host",
                "127.0.0.1",
                "--port",
                "9222",
            ],
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
        )
        time.sleep(1.5)

    def stop_lightpanda(self) -> None:
        """Explicitly stops Lightpanda if started by us."""
        if self._lightpanda_proc:
            self._lightpanda_proc.terminate()
            self._lightpanda_proc = None

    def _stop_auto_lightpanda(self) -> None:
        """Stop auto-launched Lightpanda process."""
        if self._auto_lightpanda_proc:
            lightpanda.stop(self._auto_lightpanda_proc)
            self._auto_lightpanda_proc = None
            self._auto_cdp_url = None

    def stop(self) -> None:
        """Stop all browser processes started by this parser."""
        self.stop_lightpanda()
        self._stop_auto_lightpanda()

    def __enter__(self):
        return self

    def __exit__(self, *_):
        self.stop()


if __name__ == "__main__":
    import sys

    url = sys.argv[1] if len(sys.argv) > 1 else "https://example.com"

    parser = PageParser(with_image=False, with_link=False)

    with parser:
        result = parser.parse(url)

    print(result)
