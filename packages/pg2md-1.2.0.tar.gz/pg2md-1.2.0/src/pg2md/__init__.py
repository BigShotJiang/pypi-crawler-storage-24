"""
pg2md — Page to Markdown converter with JS rendering support.

A fast, clean HTML-to-Markdown converter that uses Playwright for
JavaScript rendering and html-to-markdown (Rust-based) for conversion.

Features:
    - Auto-download and start Lightpanda browser (default)
    - JavaScript rendering via Playwright/Lightpanda
    - Fast Rust-based HTML-to-Markdown conversion
    - Proxy support (HTTP/HTTPS/SOCKS5)
    - Custom User-Agents (Googlebot, Bingbot, etc.)

Example:
    from pg2md import PageParser

    # Auto-downloads Lightpanda and parses page
    parser = PageParser()
    markdown = parser.parse("https://example.com")
    print(markdown)

    # With proxy
    from pg2md import ProxyConfig
    proxy = ProxyConfig(server="socks5://1.2.3.4:1080")
    markdown = parser.parse("https://example.com", proxy=proxy)
"""

from pg2md.parser import (
    PageParser,
    BrowserConfig,
    ProxyConfig,
    UserAgents,
    HtmlCleaner,
    MarkdownCleaner,
)
from pg2md import lightpanda

__version__ = "1.2.0"
__author__ = "lemantorus"
__all__ = [
    "PageParser",
    "BrowserConfig",
    "ProxyConfig",
    "UserAgents",
    "HtmlCleaner",
    "MarkdownCleaner",
    "lightpanda",
    "__version__",
]
