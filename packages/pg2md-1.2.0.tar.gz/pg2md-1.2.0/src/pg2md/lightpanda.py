"""
Lightpanda browser auto-downloader and launcher.

Automatically downloads Lightpanda binary from GitHub releases
and manages the CDP server process.

Supported platforms:
    - Linux x86_64
    - macOS arm64 (Apple Silicon)
"""

import platform
import subprocess
import time
import urllib.request
from pathlib import Path

LIGHTPANDA_VERSION = "nightly"

DOWNLOAD_URLS = {
    (
        "Linux",
        "x86_64",
    ): "https://github.com/lightpanda-io/browser/releases/download/nightly/lightpanda-x86_64-linux",
    (
        "Darwin",
        "arm64",
    ): "https://github.com/lightpanda-io/browser/releases/download/nightly/lightpanda-aarch64-macos",
}


def get_cache_dir() -> Path:
    """Returns the cache directory for Lightpanda binary."""
    xdg_cache = Path.home() / ".cache" / "pg2md"
    return xdg_cache


def get_binary_path() -> Path:
    """Returns the path to the Lightpanda binary."""
    return get_cache_dir() / "lightpanda"


def get_platform_key() -> tuple[str, str]:
    """Returns (system, machine) tuple for current platform."""
    return (platform.system(), platform.machine())


def is_supported() -> bool:
    """Check if Lightpanda is available for current platform."""
    return get_platform_key() in DOWNLOAD_URLS


def is_downloaded() -> bool:
    """Check if Lightpanda binary is already downloaded."""
    return get_binary_path().exists()


def download(force: bool = False) -> Path:
    """
    Download Lightpanda binary if not already present.

    Args:
        force: Re-download even if binary exists

    Returns:
        Path to the binary

    Raises:
        RuntimeError: If platform is not supported
    """
    binary_path = get_binary_path()

    if binary_path.exists() and not force:
        return binary_path

    key = get_platform_key()
    if key not in DOWNLOAD_URLS:
        raise RuntimeError(
            f"Lightpanda not available for {key[0]} {key[1]}. "
            f"Supported: {list(DOWNLOAD_URLS.keys())}"
        )

    url = DOWNLOAD_URLS[key]
    binary_path.parent.mkdir(parents=True, exist_ok=True)

    print(f"[pg2md] Downloading Lightpanda {LIGHTPANDA_VERSION}...")
    urllib.request.urlretrieve(url, binary_path)
    binary_path.chmod(0o755)
    print(f"[pg2md] Saved to {binary_path}")

    return binary_path


def start(
    host: str = "127.0.0.1",
    port: int = 9222,
    download_if_missing: bool = True,
) -> subprocess.Popen:
    """
    Start Lightpanda CDP server.

    Args:
        host: Host to bind to
        port: Port to bind to
        download_if_missing: Download binary if not present

    Returns:
        subprocess.Popen object
    """
    if download_if_missing:
        binary_path = download()
    else:
        binary_path = get_binary_path()
        if not binary_path.exists():
            raise FileNotFoundError(
                f"Lightpanda binary not found at {binary_path}. "
                "Set download_if_missing=True to auto-download."
            )

    proc = subprocess.Popen(
        [str(binary_path), "serve", "--host", host, "--port", str(port)],
        stdout=subprocess.DEVNULL,
        stderr=subprocess.DEVNULL,
    )

    cdp_url = f"ws://{host}:{port}"
    _wait_for_cdp(cdp_url, timeout=10)

    return proc


def _wait_for_cdp(cdp_url: str, timeout: float = 10.0) -> bool:
    """Wait for CDP server to be ready."""
    import socket

    host = cdp_url.split("://")[1].split(":")[0]
    port = int(cdp_url.split(":")[-1])

    start_time = time.time()
    while time.time() - start_time < timeout:
        try:
            sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            sock.settimeout(1)
            result = sock.connect_ex((host, port))
            sock.close()
            if result == 0:
                time.sleep(0.5)
                return True
        except Exception:
            pass
        time.sleep(0.2)

    raise TimeoutError(f"Lightpanda CDP server not ready at {cdp_url}")


def stop(proc: subprocess.Popen) -> None:
    """Stop Lightpanda process."""
    if proc and proc.poll() is None:
        proc.terminate()
        try:
            proc.wait(timeout=5)
        except subprocess.TimeoutExpired:
            proc.kill()
