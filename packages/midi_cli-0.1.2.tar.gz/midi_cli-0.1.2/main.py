#!/usr/bin/env -S uv run --project .
"""Thin wrapper so ./main.py keeps working."""
from midi_cli.app import main

if __name__ == "__main__":
    main()
