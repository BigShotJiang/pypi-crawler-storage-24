import numpy as np

import midi_cli.state as st


def reset_loop_state():
    """Clear loop buffer and return to idle. Must be called with voices_lock held."""
    st.loop_state = "idle"
    st.loop_buffer = None
    st.loop_pos = 0
    st.loop_record_chunks = []
    st.loop_layer_count = 0


def cycle_loop_state():
    """Advance the loop state machine. Must be called with voices_lock held."""
    if st.loop_state == "idle":
        st.loop_record_chunks = []
        st.loop_state = "recording"
    elif st.loop_state == "recording":
        if st.loop_record_chunks:
            st.loop_buffer = np.concatenate(st.loop_record_chunks)
        else:
            st.loop_buffer = None
        st.loop_record_chunks = []
        st.loop_pos = 0
        st.loop_layer_count = 1
        st.loop_state = "playing"
    elif st.loop_state == "playing":
        st.loop_state = "overdub"
    elif st.loop_state == "overdub":
        st.loop_layer_count += 1
        st.loop_state = "playing"
