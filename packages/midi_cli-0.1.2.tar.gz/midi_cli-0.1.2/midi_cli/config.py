import json
import os

import rtmidi
import sounddevice as sd


CONFIG_PATH = "config.json"


def load_config():
    """Read config.json; return empty dict if missing."""
    if not os.path.isfile(CONFIG_PATH):
        return {}
    with open(CONFIG_PATH, "r") as f:
        return json.load(f)


def save_config(cfg):
    """Write config.json."""
    with open(CONFIG_PATH, "w") as f:
        json.dump(cfg, f, indent=2)


def _get_input_devices():
    """Return input device names with the system default first."""
    devs = sd.query_devices()
    names = [d["name"] for d in devs if d["max_input_channels"] > 0]
    try:
        idx = sd.default.device[0]
        if idx >= 0:
            default_name = devs[idx]["name"]
            if default_name in names:
                names.remove(default_name)
                names.insert(0, default_name)
    except Exception:
        pass
    return names


def _get_output_devices():
    """Return output device names with the system default first."""
    devs = sd.query_devices()
    names = [d["name"] for d in devs if d["max_output_channels"] > 0]
    try:
        idx = sd.default.device[1]
        if idx >= 0:
            default_name = devs[idx]["name"]
            if default_name in names:
                names.remove(default_name)
                names.insert(0, default_name)
    except Exception:
        pass
    return names


def _prompt_device(label, names):
    """Prompt user to pick from a numbered list; Enter accepts the first."""
    print(f"\n{label}:")
    for i, name in enumerate(names):
        suffix = " (default)" if i == 0 else ""
        print(f"  {i + 1}. {name}{suffix}")
    while True:
        try:
            raw = input("Select [1]: ").strip()
        except EOFError:
            return names[0]
        if raw == "":
            return names[0]
        try:
            idx = int(raw) - 1
            if 0 <= idx < len(names):
                return names[idx]
        except ValueError:
            pass
        print(f"  Please enter 1\u2013{len(names)}.")


def run_setup_wizard():
    """
    Detect audio/MIDI devices, prompt only when there is ambiguity (>1 option)
    or when a saved device has disappeared. Returns config dict.
    """
    cfg = load_config()
    changed = False

    # --- Audio input ---
    input_names = _get_input_devices()
    saved = cfg.get("input_device")
    if "input_device" in cfg and saved is not None and saved not in input_names:
        print(f"Warning: saved input device '{saved}' not found.")
        del cfg["input_device"]
        changed = True
    # Re-prompt if previously defaulted but new devices have appeared
    if "input_device" in cfg and cfg["input_device"] is None and len(input_names) > 1:
        del cfg["input_device"]
        changed = True
    if "input_device" not in cfg:
        changed = True
        cfg["input_device"] = _prompt_device("Input device", input_names) if len(input_names) > 1 else None

    # --- Audio output ---
    output_names = _get_output_devices()
    saved = cfg.get("output_device")
    if "output_device" in cfg and saved is not None and saved not in output_names:
        print(f"Warning: saved output device '{saved}' not found.")
        del cfg["output_device"]
        changed = True
    # Re-prompt if previously defaulted but new devices have appeared
    if "output_device" in cfg and cfg["output_device"] is None and len(output_names) > 1:
        del cfg["output_device"]
        changed = True
    if "output_device" not in cfg:
        changed = True
        cfg["output_device"] = _prompt_device("Output device", output_names) if len(output_names) > 1 else None

    # --- MIDI ---
    _tmp = rtmidi.MidiIn()
    midi_ports = _tmp.get_ports()
    _tmp.delete()
    saved = cfg.get("midi_port")
    if "midi_port" in cfg and saved is not None and saved not in midi_ports:
        print(f"Warning: saved MIDI port '{saved}' not found.")
        del cfg["midi_port"]
        changed = True
    if "midi_port" not in cfg:
        changed = True
        cfg["midi_port"] = _prompt_device("MIDI input port", midi_ports) if len(midi_ports) > 1 else None

    if changed:
        save_config(cfg)

    return cfg
