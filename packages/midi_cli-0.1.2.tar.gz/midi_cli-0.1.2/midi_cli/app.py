import os
import select
import sys
import termios
import threading
import tty

import sounddevice as sd

import midi_cli.state as st
from midi_cli.audio import audio_callback
from midi_cli.sampler import load_samples, load_pitch_offsets, save_sample, adjust_pitch, compute_chromatic_samples_async, execute_copy, stop_recording
from midi_cli.midi import open_midi_input, trigger_keyboard_note, midi_callback
from midi_cli.ui import draw_ui, reset_trim_state, reset_copy_state
from midi_cli.loop import reset_loop_state, cycle_loop_state


def main():
    from midi_cli.config import run_setup_wizard
    cfg = run_setup_wizard()
    st.input_device = cfg.get("input_device")
    st.output_device = cfg.get("output_device")
    st.midi_port = cfg.get("midi_port")
    sys.stdout.write("\033[2J\033[H")
    sys.stdout.flush()

    midi_in, port_name = open_midi_input(st.midi_port)
    if midi_in is None:
        st.keyboard_mock_mode = True
    else:
        st.ui_midi_port = port_name

    load_samples()
    load_pitch_offsets()

    stream = sd.OutputStream(
        samplerate=st.SAMPLE_RATE,
        blocksize=st.BLOCK_SIZE,
        channels=1,
        callback=audio_callback,
        device=st.output_device,
    )
    stream.start()

    fd = sys.stdin.fileno()
    old_settings = termios.tcgetattr(fd)
    sys.stdout.write(st.HIDE_CURSOR)
    sys.stdout.flush()

    try:
        tty.setraw(fd)
        initialized = False
        while True:
            draw_ui(initialized)
            initialized = True

            ready, _, _ = select.select([fd], [], [], 0.05)
            if ready:
                ch = os.read(fd, 1).decode("utf-8", errors="replace")
                if ch in ("q", "\x03"):  # q or Ctrl+C
                    break
                elif ch == "\r" and st.mode == "trim" and st.trim_selected_note is not None:
                    if st.trim_step == 0:
                        # Confirm start, advance to end adjustment
                        st.trim_step = 1
                        st.trim_loop_pos = st.trim_start
                    else:
                        # Confirm end, slice and save
                        audio = st.samples[st.trim_selected_note][st.trim_start:st.trim_end]
                        note = st.trim_selected_note
                        save_sample(note, audio)
                        # Recompute chromatic if this was the root
                        if st.chromatic_root_note == note:
                            compute_chromatic_samples_async(note)
                        reset_trim_state()
                elif ch == "\r" and st.mode == "copy" and st.copy_confirm_pending:
                    execute_copy()
                elif ch == "\t":  # Tab: next mode
                    if st.mode == "record":
                        st.keyboard_recording_notes.clear()
                        if st.recording_note is not None:
                            threading.Thread(target=stop_recording, args=(st.recording_note,), daemon=True).start()
                    if st.mode == "trim":
                        reset_trim_state()
                    if st.mode == "copy":
                        reset_copy_state()
                    if st.mode == "loop":
                        with st.voices_lock:
                            reset_loop_state()
                    st.mode = st.MODES[(st.MODES.index(st.mode) + 1) % len(st.MODES)]
                    if st.mode == "chromatic":
                        st.chromatic_selecting = st.chromatic_root_note is None
                elif ch == "r" and st.mode == "chromatic" and not st.chromatic_selecting:
                    st.chromatic_selecting = True
                elif ch == "\x1b":  # escape sequence
                    # Use select on fd with timeout to distinguish bare Escape from sequences
                    esc_ready, _, _ = select.select([fd], [], [], 0.02)
                    if not esc_ready:
                        # Bare Escape
                        if st.mode == "trim" and st.trim_selected_note is not None:
                            reset_trim_state()
                        elif st.mode == "copy" and (st.copy_source_note is not None or st.copy_confirm_pending):
                            reset_copy_state()
                        elif st.mode == "loop":
                            with st.voices_lock:
                                reset_loop_state()
                    else:
                        seq = os.read(fd, 2).decode("utf-8", errors="replace")
                        if seq == "[Z":  # Shift+Tab: previous mode
                            if st.mode == "record":
                                st.keyboard_recording_notes.clear()
                                if st.recording_note is not None:
                                    threading.Thread(target=stop_recording, args=(st.recording_note,), daemon=True).start()
                            if st.mode == "trim":
                                reset_trim_state()
                            if st.mode == "copy":
                                reset_copy_state()
                            if st.mode == "loop":
                                with st.voices_lock:
                                    reset_loop_state()
                            st.mode = st.MODES[(st.MODES.index(st.mode) - 1) % len(st.MODES)]
                            if st.mode == "chromatic":
                                st.chromatic_selecting = st.chromatic_root_note is None
                        elif st.mode == "trim" and st.trim_selected_note is not None:
                            sample_len = len(st.samples[st.trim_selected_note])
                            fine = max(1, sample_len // 1000)    # 0.1%
                            coarse = max(1, sample_len // 100)   # 1%
                            if st.trim_step == 0:
                                if seq == "[D":    # Left: decrease start
                                    st.trim_start = max(0, st.trim_start - fine)
                                elif seq == "[C":  # Right: increase start
                                    st.trim_start = min(st.trim_end - st.MIN_TRIM_SAMPLES, st.trim_start + fine)
                                elif seq == "[B":  # Down: decrease start (coarse)
                                    st.trim_start = max(0, st.trim_start - coarse)
                                elif seq == "[A":  # Up: increase start (coarse)
                                    st.trim_start = min(st.trim_end - st.MIN_TRIM_SAMPLES, st.trim_start + coarse)
                            else:
                                if seq == "[D":    # Left: decrease end
                                    st.trim_end = max(st.trim_start + st.MIN_TRIM_SAMPLES, st.trim_end - fine)
                                elif seq == "[C":  # Right: increase end
                                    st.trim_end = min(sample_len, st.trim_end + fine)
                                elif seq == "[B":  # Down: decrease end (coarse)
                                    st.trim_end = max(st.trim_start + st.MIN_TRIM_SAMPLES, st.trim_end - coarse)
                                elif seq == "[A":  # Up: increase end (coarse)
                                    st.trim_end = min(sample_len, st.trim_end + coarse)
                            st.trim_start = max(0, st.trim_start)
                            st.trim_end = max(st.trim_start + st.MIN_TRIM_SAMPLES, st.trim_end)
                        elif st.mode == "pitch" and st.pitch_selected_note is not None:
                            if seq == "[A":    # Up: +1 semitone
                                adjust_pitch(st.pitch_selected_note, 1, 0)
                            elif seq == "[B":  # Down: -1 semitone
                                adjust_pitch(st.pitch_selected_note, -1, 0)
                            elif seq == "[C":  # Right: +10 cents
                                adjust_pitch(st.pitch_selected_note, 0, st.CENTS_STEP)
                            elif seq == "[D":  # Left: -10 cents
                                adjust_pitch(st.pitch_selected_note, 0, -st.CENTS_STEP)
                elif ch == 'l' and st.mode == "loop":
                    with st.voices_lock:
                        cycle_loop_state()
                elif st.keyboard_mock_mode and ch in st.KEYBOARD_NOTE_MAP:
                    trigger_keyboard_note(st.KEYBOARD_NOTE_MAP[ch])
                elif st.keyboard_mock_mode and ch == '`':
                    new_val = 0 if st.sustain else 127
                    midi_callback(([0xB0, 64, new_val], 0), None)
    except (KeyboardInterrupt, EOFError):
        pass
    finally:
        termios.tcsetattr(fd, termios.TCSADRAIN, old_settings)
        sys.stdout.write(st.SHOW_CURSOR)
        sys.stdout.flush()
        stream.stop()
        stream.close()
        if midi_in is not None:
            midi_in.close_port()
            midi_in.delete()


if __name__ == "__main__":
    main()
