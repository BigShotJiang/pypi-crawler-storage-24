import threading

import rtmidi

import midi_cli.state as st
from midi_cli.sampler import start_recording, stop_recording, compute_chromatic_samples_async, execute_copy
from midi_cli.loop import cycle_loop_state


def midi_callback(event, data):
    message, delta_time = event
    if len(message) < 3:
        return

    status, note, velocity = message[0], message[1], message[2]
    msg_type = status & 0xF0

    if msg_type == 0x90 and velocity > 0:
        if st.mode == "record":
            threading.Thread(target=start_recording, args=(note,), daemon=True).start()
            return

        if st.mode == "trim":
            if st.trim_selected_note is None and note in st.samples:
                st.trim_selected_note = note
                st.trim_step = 0
                st.trim_start = 0
                st.trim_end = len(st.samples[note])
                st.trim_loop_pos = 0
                st.trim_looping = True
            return

        if st.mode == "copy":
            if st.copy_confirm_pending:
                return
            if st.copy_source_note is None:
                if note in st.samples:
                    st.copy_source_note = note
                return
            else:
                st.copy_dest_note = note
                if note in st.samples:
                    st.copy_confirm_pending = True
                else:
                    execute_copy()
                return

        st.ui_active_note = st.midi_note_name(note)
        if st.mode == "pitch":
            with st.voices_lock:
                if note in st.samples:
                    st.sample_voices[note] = {"pos": 0, "releasing": False, "gain": 1.0}
                    st.pitch_selected_note = note
            return
        if st.mode == "chromatic":
            if st.chromatic_selecting:
                if note in st.samples:
                    st.chromatic_root_note = note
                    with st.voices_lock:
                        st.sample_voices.clear()
                    st.chromatic_selecting = False
                    compute_chromatic_samples_async(note)
            else:
                with st.voices_lock:
                    if note in st.chromatic_samples:
                        st.sample_voices[note] = {"pos": 0, "releasing": False, "gain": 1.0}
            return
        with st.voices_lock:
            if st.mode in ("sample", "loop"):
                if note in st.samples:
                    st.sample_voices[note] = {"pos": 0, "releasing": False, "gain": 1.0}
            else:
                st.voices[note] = {"phase": 0.0, "gain": 0.0, "releasing": False, "age": 0, "faded_in": False}
                st.sustained_notes.discard(note)
    elif msg_type == 0x80 or (msg_type == 0x90 and velocity == 0):
        if st.mode == "record":
            threading.Thread(target=stop_recording, args=(note,), daemon=True).start()
            return
        if st.mode in ("trim", "copy"):
            return
        # Only clear if this note is still the active one
        note_name = st.midi_note_name(note)
        if st.ui_active_note == note_name:
            st.ui_active_note = None
        with st.voices_lock:
            if st.mode in ("sample", "pitch", "chromatic"):
                if note in st.sample_voices:
                    st.sample_voices[note]["releasing"] = True
            else:
                if note in st.voices:
                    if st.sustain:
                        st.sustained_notes.add(note)
                    else:
                        st.voices[note]["releasing"] = True
    elif msg_type == 0xB0 and note == 64:
        pedal_on = velocity >= 64
        st.ui_sustain = pedal_on
        if pedal_on and st.mode == "loop":
            with st.voices_lock:
                cycle_loop_state()
            return
        with st.voices_lock:
            st.sustain = pedal_on
            if not pedal_on:
                for n in st.sustained_notes:
                    if n in st.voices:
                        st.voices[n]["releasing"] = True
                st.sustained_notes.clear()


def trigger_keyboard_note(note):
    if st.mode == "record":
        if note in st.keyboard_recording_notes:
            st.keyboard_recording_notes.discard(note)
            threading.Thread(target=stop_recording, args=(note,), daemon=True).start()
        else:
            st.keyboard_recording_notes.add(note)
            threading.Thread(target=start_recording, args=(note,), daemon=True).start()
        return

    old = st.keyboard_timers.pop(note, None)
    if old:
        old.cancel()
    midi_callback(([0x90, note, 100], 0), None)
    if st.mode in ("sample", "pitch", "chromatic", "trim", "copy", "loop"):
        # Sample modes: one-shot, let the sample play to its natural end
        return
    if st.sustain:
        midi_callback(([0x80, note, 0], 0), None)
    else:
        def note_off():
            st.keyboard_timers.pop(note, None)
            midi_callback(([0x80, note, 0], 0), None)
        t = threading.Timer(st.KEYBOARD_NOTE_RELEASE_S, note_off)
        t.daemon = True
        st.keyboard_timers[note] = t
        t.start()


def open_midi_input(port_name=None):
    midi_in = rtmidi.MidiIn()
    ports = midi_in.get_ports()
    if not ports:
        midi_in.delete()
        return None, ""
    port_index = 0
    if port_name is not None:
        if port_name in ports:
            port_index = ports.index(port_name)
        else:
            print(f"Warning: MIDI port '{port_name}' not found, using port 0.")
    midi_in.open_port(port_index)
    midi_in.set_callback(midi_callback)
    return midi_in, ports[port_index]
