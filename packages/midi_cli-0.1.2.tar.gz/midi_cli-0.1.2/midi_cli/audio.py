import numpy as np

import midi_cli.state as st


def build_synth_envelope(gain, releasing, faded_in, age, frames):
    """Vectorized envelope: returns (gains_array, new_gain, new_age, new_faded_in)."""
    idx = np.arange(frames)

    if releasing:
        gains = np.maximum(0.0, gain - st.FADE_OUT_STEP * (idx + 1))
        new_gain = max(0.0, gain - st.FADE_OUT_STEP * frames)
        return gains, new_gain, age, faded_in

    if not faded_in:
        # Fade-in with concurrent stage1 decay:
        # Recurrence: g' = (g + FADE_IN_STEP) * STAGE1_DECAY
        # We compute iteratively to find the clamp point, then switch to pure decay.
        gains = np.empty(frames)
        g = gain
        clamp_idx = frames  # assume no clamp within block
        for i in range(frames):
            g = (g + st.FADE_IN_STEP) * st.STAGE1_DECAY
            if g >= 1.0:
                g = 1.0
                clamp_idx = i
                break
            gains[i] = g

        if clamp_idx < frames:
            # Faded in at clamp_idx
            gains[clamp_idx] = g
            remaining = frames - clamp_idx - 1
            if remaining > 0:
                post_age = age + clamp_idx + 1
                if post_age < st.STAGE1_SAMPLES:
                    s1_left = st.STAGE1_SAMPLES - post_age
                    if remaining <= s1_left:
                        gains[clamp_idx + 1:] = g * st.STAGE1_DECAY ** (idx[:remaining] + 1)
                    else:
                        gains[clamp_idx + 1:clamp_idx + 1 + s1_left] = g * st.STAGE1_DECAY ** (idx[:s1_left] + 1)
                        g_at_boundary = g * st.STAGE1_DECAY ** s1_left
                        rest = remaining - s1_left
                        gains[clamp_idx + 1 + s1_left:] = g_at_boundary * st.STAGE2_DECAY ** (idx[:rest] + 1)
                else:
                    gains[clamp_idx + 1:] = g * st.STAGE2_DECAY ** (idx[:remaining] + 1)
            new_gain = gains[-1]
            new_age = age + frames
            return gains, new_gain, new_age, True
        else:
            # Still fading in at end of block
            new_gain = g
            new_age = age + frames
            return gains, new_gain, new_age, False

    # Already faded in — pure decay
    if age >= st.STAGE1_SAMPLES:
        # Pure stage2
        gains = gain * st.STAGE2_DECAY ** (idx + 1)
    elif age + frames <= st.STAGE1_SAMPLES:
        # Pure stage1
        gains = gain * st.STAGE1_DECAY ** (idx + 1)
    else:
        # Stage1 → stage2 boundary mid-block
        s1_left = st.STAGE1_SAMPLES - age
        gains = np.empty(frames)
        gains[:s1_left] = gain * st.STAGE1_DECAY ** (idx[:s1_left] + 1)
        g_at_boundary = gain * st.STAGE1_DECAY ** s1_left
        s2_count = frames - s1_left
        gains[s1_left:] = g_at_boundary * st.STAGE2_DECAY ** (idx[:s2_count] + 1)

    new_gain = gains[-1]
    new_age = age + frames
    return gains, new_gain, new_age, faded_in


def audio_callback(outdata, frames, time_info, status):
    with st.voices_lock:
        if st.mode == "trim" and st.trim_looping and st.trim_selected_note is not None:
            sample_data = st.samples.get(st.trim_selected_note)
            if sample_data is None or st.trim_end <= st.trim_start:
                outdata[:] = 0
                return
            # Bounds-check loop pos
            region_len = st.trim_end - st.trim_start
            cycle_len = max(region_len, st.MIN_LOOP_PERIOD)
            if st.trim_loop_pos < 0 or st.trim_loop_pos >= cycle_len:
                st.trim_loop_pos = 0
            mix = np.zeros(frames)
            written = 0
            while written < frames:
                if st.trim_loop_pos < region_len:
                    # Playing audio portion
                    src_pos = st.trim_start + st.trim_loop_pos
                    avail = region_len - st.trim_loop_pos
                    n = min(frames - written, avail)
                    mix[written:written + n] = sample_data[src_pos:src_pos + n]
                    st.trim_loop_pos += n
                    written += n
                else:
                    # Silence padding portion
                    avail = cycle_len - st.trim_loop_pos
                    n = min(frames - written, avail)
                    # mix is already zeros
                    st.trim_loop_pos += n
                    written += n
                if st.trim_loop_pos >= cycle_len:
                    st.trim_loop_pos = 0
            mix *= 0.25
            np.clip(mix, -1.0, 1.0, out=mix)
            outdata[:, 0] = mix
            return

        if st.mode == "loop":
            mix = np.zeros(frames)

            # Sample voice mixing (same logic as sample mode)
            finished = []
            for note, sv in st.sample_voices.items():
                if note not in st.samples:
                    finished.append(note)
                    continue
                pos = sv["pos"]
                gain = sv["gain"]
                releasing = sv["releasing"]
                sample_data = st.samples[note]
                remaining = len(sample_data) - pos
                n = min(frames, remaining)
                if n <= 0:
                    finished.append(note)
                    continue
                buf = np.zeros(frames)
                buf[:n] = sample_data[pos:pos + n] * gain
                if releasing:
                    fade_gains = np.maximum(0.0, gain - st.FADE_OUT_STEP * (np.arange(n) + 1))
                    buf[:n] *= fade_gains
                    gain = max(0.0, gain - st.FADE_OUT_STEP * n)
                else:
                    gain = min(1.0, gain + st.FADE_IN_STEP * n)
                mix += buf
                sv["pos"] = pos + n
                sv["gain"] = gain
                if (releasing and gain <= 0.0) or pos + n >= len(sample_data):
                    finished.append(note)
            for note in finished:
                del st.sample_voices[note]

            # Loop capture/playback
            if st.loop_state == "recording":
                st.loop_record_chunks.append(mix.copy())
            elif st.loop_state in ("playing", "overdub") and st.loop_buffer is not None:
                buf = st.loop_buffer
                buf_len = len(buf)
                loop_chunk = np.zeros(frames)
                written = 0
                pos = st.loop_pos
                while written < frames:
                    avail = buf_len - pos
                    take = min(avail, frames - written)
                    loop_chunk[written:written + take] = buf[pos:pos + take]
                    if st.loop_state == "overdub":
                        buf[pos:pos + take] += mix[written:written + take]
                        np.clip(buf[pos:pos + take], -1.0, 1.0, out=buf[pos:pos + take])
                    written += take
                    pos = (pos + take) % buf_len
                mix += loop_chunk
                st.loop_pos = (st.loop_pos + frames) % buf_len

            mix *= 0.25
            np.clip(mix, -1.0, 1.0, out=mix)
            outdata[:, 0] = mix
            return

        if st.mode in ("sample", "pitch", "chromatic", "trim"):
            if not st.sample_voices:
                outdata[:] = 0
                return

            mix = np.zeros(frames)
            finished = []

            for note, sv in st.sample_voices.items():
                if st.mode == "chromatic":
                    sample_data = st.chromatic_samples.get(note)
                    if sample_data is None:
                        finished.append(note)
                        continue
                else:
                    if note not in st.samples:
                        finished.append(note)
                        continue
                    ps = st.pitched_samples.get(note)
                    sample_data = ps if ps is not None else st.samples.get(note)
                pos = sv["pos"]
                gain = sv["gain"]
                releasing = sv["releasing"]

                remaining = len(sample_data) - pos
                n = min(frames, remaining)
                if n <= 0:
                    finished.append(note)
                    continue

                buf = np.zeros(frames)
                buf[:n] = sample_data[pos:pos + n] * gain

                if releasing:
                    fade_gains = np.maximum(0.0, gain - st.FADE_OUT_STEP * (np.arange(n) + 1))
                    buf[:n] *= fade_gains
                    gain = max(0.0, gain - st.FADE_OUT_STEP * n)
                else:
                    gain = min(1.0, gain + st.FADE_IN_STEP * n)

                mix += buf
                sv["pos"] = pos + n
                sv["gain"] = gain
                if (releasing and gain <= 0.0) or pos + n >= len(sample_data):
                    finished.append(note)

            for note in finished:
                del st.sample_voices[note]

            mix *= 0.25
            np.clip(mix, -1.0, 1.0, out=mix)
            outdata[:, 0] = mix
            return

        # Synth mode
        if not st.voices:
            outdata[:] = 0
            return

        mix = np.zeros(frames)
        finished = []

        for note, v in st.voices.items():
            freq = st.note_to_freq(note)
            phase = v["phase"]
            gain = v["gain"]
            releasing = v["releasing"]
            age = v["age"]
            faded_in = v["faded_in"]

            phase_step = 2.0 * np.pi * freq / st.SAMPLE_RATE
            phases = phase + np.arange(frames) * phase_step
            phase_matrix = phases[:, None] * st.H_MULTIPLIERS[None, :]
            raw_signal = np.sin(phase_matrix) @ st.HARMONICS
            gains, gain, age, faded_in = build_synth_envelope(gain, releasing, faded_in, age, frames)
            buf = raw_signal * gains
            phase = phases[-1] + phase_step

            mix += buf
            v["phase"] = phase % (2.0 * np.pi)
            v["gain"] = gain
            v["age"] = age
            v["faded_in"] = faded_in
            if (releasing and gain == 0.0) or gain < st.SILENCE_THRESHOLD:
                finished.append(note)

        for note in finished:
            del st.voices[note]

        mix *= 0.25  # fixed headroom (up to ~4 voices at full level)
        np.clip(mix, -1.0, 1.0, out=mix)
        outdata[:, 0] = mix


def trim_silence(audio, threshold_db=-20):
    """Trim leading and trailing silence from an audio array."""
    threshold = 10 ** (threshold_db / 20.0)  # convert dB to linear
    above = np.abs(audio) > threshold
    if not np.any(above):
        return audio  # all silence, return as-is
    indices = np.where(above)[0]
    pad = int(0.05 * st.SAMPLE_RATE)  # 50ms pad
    start = max(indices[0] - pad, 0)
    end = min(indices[-1] + 1 + pad, len(audio))
    return audio[start:end]
