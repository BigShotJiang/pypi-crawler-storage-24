import os
import sys
import time

import numpy as np

import midi_cli.state as st
from midi_cli.sampler import format_pitch_info


def render_waveform(note):
    """Render a centered ASCII waveform of the sample with trim region highlighted."""
    audio = st.samples.get(note)
    if audio is None:
        return []
    cols = os.get_terminal_size().columns - 2  # leave margin
    cols = max(10, cols)
    n = len(audio)
    rows = st.TRIM_WAVEFORM_HEIGHT
    half = rows / 2  # rows above/below center (float for smooth mapping)
    blocks = " \u2581\u2582\u2583\u2584\u2585\u2586\u2587\u2588"
    blocks_rev = " \u2594\u2594\u2580\u2580\u2580\u2580\u2588\u2588"

    # Compute peak amplitude per column bin
    peaks = np.zeros(cols)
    for c in range(cols):
        start = c * n // cols
        end = (c + 1) * n // cols
        if start < end:
            peaks[c] = np.max(np.abs(audio[start:end]))

    max_peak = np.max(peaks) if np.max(peaks) > 0 else 1.0

    # Compute which columns are inside the trim region
    trim_start_col = st.trim_start * cols // n if n > 0 else 0
    trim_end_col = (st.trim_end * cols + n - 1) // n if n > 0 else cols  # ceiling

    # Active marker column
    if st.trim_step == 0:
        marker_col = trim_start_col
    else:
        marker_col = min(trim_end_col - 1, cols - 1)

    # Playback position column (only during audio, not silence padding)
    region_len = st.trim_end - st.trim_start
    if region_len > 0 and st.trim_looping and st.trim_loop_pos < region_len:
        play_offset = st.trim_loop_pos
        play_col = trim_start_col + play_offset * (trim_end_col - trim_start_col) // region_len
        play_col = max(trim_start_col, min(play_col, trim_end_col - 1))
    else:
        play_col = -1

    WHITE = "\033[97m"

    lines = []
    for row in range(rows):
        # Center is between row half-1 and half
        # Upper half: rows 0..half-1 (top row = max amplitude)
        # Lower half: rows half..rows-1 (bottom row = max amplitude)
        dist_from_center = abs(row - half + 0.5) / half  # 0 at center, 1 at edges
        threshold_low = dist_from_center
        threshold_high = dist_from_center + 1.0 / half

        is_upper = row < half
        line = " "
        for c in range(cols):
            level = peaks[c] / max_peak
            if level <= threshold_low:
                char = " "
            else:
                frac = min(1.0, (level - threshold_low) / (threshold_high - threshold_low))
                idx = int(frac * (len(blocks) - 1))
                if is_upper:
                    char = blocks[idx]
                else:
                    # Bottom half: use reversed blocks so fill grows from top of cell
                    char = blocks_rev[idx]

            in_region = trim_start_col <= c < trim_end_col
            is_boundary = c == trim_start_col or c == trim_end_col - 1
            if c == play_col:
                head = char if char.strip() else "\u2502"
                line += f"{st.RED}{st.BOLD}{head}{st.RST}"
            elif is_boundary:
                bar = char if char.strip() else "\u2502"
                if c == marker_col:
                    line += f"{st.ORANGE}{st.BOLD}{bar}{st.RST}"
                else:
                    line += f"{st.CYAN}{bar}{st.RST}"
            elif in_region:
                line += f"{st.CYAN}{char}{st.RST}"
            else:
                line += f"{st.DIM}{char}{st.RST}"
        lines.append(line)
    return lines


def render_loop_waveform(audio, loop_state, loop_pos, loop_layer_count):
    """Render a 6-row waveform for loop mode with colored playhead."""
    cols = os.get_terminal_size().columns - 2
    cols = max(10, cols)
    n = len(audio)
    rows = st.TRIM_WAVEFORM_HEIGHT
    half = rows / 2
    blocks = " \u2581\u2582\u2583\u2584\u2585\u2586\u2587\u2588"
    blocks_rev = " \u2594\u2594\u2580\u2580\u2580\u2580\u2588\u2588"

    # Compute peak amplitude per column bin
    peaks = np.zeros(cols)
    for c in range(cols):
        start = c * n // cols
        end = (c + 1) * n // cols
        if start < end:
            peaks[c] = np.max(np.abs(audio[start:end]))

    max_peak = np.max(peaks) if np.max(peaks) > 0 else 1.0

    # Color by state
    if loop_state == "recording":
        color = st.RED
    elif loop_state == "overdub":
        color = st.YELLOW
    else:
        color = st.GREEN

    # Playhead column (only during playing/overdub)
    if loop_state in ("playing", "overdub") and n > 0:
        play_col = loop_pos * cols // n
        play_col = max(0, min(play_col, cols - 1))
    else:
        play_col = -1

    lines = []
    for row in range(rows):
        dist_from_center = abs(row - half + 0.5) / half
        threshold_low = dist_from_center
        threshold_high = dist_from_center + 1.0 / half

        is_upper = row < half
        line = " "
        for c in range(cols):
            level = peaks[c] / max_peak
            if level <= threshold_low:
                char = " "
            else:
                frac = min(1.0, (level - threshold_low) / (threshold_high - threshold_low))
                idx = int(frac * (len(blocks) - 1))
                if is_upper:
                    char = blocks[idx]
                else:
                    char = blocks_rev[idx]

            if c == play_col:
                head = char if char.strip() else "\u2502"
                line += f"{st.RED}{st.BOLD}{head}{st.RST}"
            else:
                line += f"{color}{char}{st.RST}"
        lines.append(line)
    return lines


def reset_trim_state():
    """Reset all trim mode state back to selection."""
    st.trim_selected_note = None
    st.trim_step = 0
    st.trim_start = 0
    st.trim_end = 0
    st.trim_loop_pos = 0
    st.trim_looping = False


def reset_copy_state():
    """Reset all copy mode state back to selection."""
    st.copy_source_note = None
    st.copy_dest_note = None
    st.copy_confirm_pending = False


def draw_ui(initialized):
    """Render the TUI in place using ANSI escape codes."""
    with st.voices_lock:
        ui_rec = st.ui_recording
        loop_snap = (st.loop_state, st.loop_pos, st.loop_layer_count)
        if st.loop_state == "recording" and st.loop_record_chunks:
            loop_audio = np.concatenate(st.loop_record_chunks)
        else:
            loop_audio = st.loop_buffer
    out = ""
    waveform_block = st.TRIM_WAVEFORM_HEIGHT + 1  # always reserved (6 rows + 1 blank)
    total_lines = st.NUM_UI_LINES + waveform_block  # always 11

    # Move cursor back up to overwrite previous frame
    if initialized:
        out += f"\033[{st.prev_ui_lines}A"

    # Waveform area — always exactly waveform_block lines so the console never moves
    if st.mode == "trim" and st.trim_selected_note is not None:
        waveform_lines = render_waveform(st.trim_selected_note)
        for wl in waveform_lines:
            out += f"{st.CLEAR_LINE}\r{wl}\r\n"
        out += f"{st.CLEAR_LINE}\r\n"  # blank separator
    elif st.mode == "loop" and loop_snap[0] != "idle" and loop_audio is not None:
        waveform_lines = render_loop_waveform(loop_audio, *loop_snap)
        for wl in waveform_lines:
            out += f"{st.CLEAR_LINE}\r{wl}\r\n"
        out += f"{st.CLEAR_LINE}\r\n"
    else:
        for _ in range(waveform_block):
            out += f"{st.CLEAR_LINE}\r\n"

    # Line 0: app name + mode selector (compact, left-aligned)
    line0 = f" {st.BOLD}midi-cli{st.RST}  "
    for i, m in enumerate(st.MODES):
        if i > 0:
            line0 += f"{st.DIM} \u2502 {st.RST}"
        if m == st.mode:
            line0 += f"{st.BOLD}{m}{st.RST}"
        else:
            line0 += f"{st.DIM}{m}{st.RST}"
    out += f"{st.CLEAR_LINE}\r{line0}\r\n"

    # Line 1: note/rec indicator + sustain + sample count (or pitch/trim info)
    line1 = ""
    if st.mode == "trim":
        if st.trim_selected_note is not None:
            name = st.midi_note_name(st.trim_selected_note)
            start_ms = st.trim_start / st.SAMPLE_RATE * 1000
            end_ms = st.trim_end / st.SAMPLE_RATE * 1000
            total_ms = len(st.samples[st.trim_selected_note]) / st.SAMPLE_RATE * 1000
            if st.trim_step == 0:
                line1 += f" {st.GREEN}{st.BOLD}\u2666{st.RST} {st.BOLD}{name}  start={start_ms:.0f}ms{st.RST}  end={end_ms:.0f}ms  {st.DIM}{total_ms:.0f}ms total{st.RST}"
            else:
                line1 += f" {st.GREEN}{st.BOLD}\u2666{st.RST} {st.BOLD}{name}{st.RST}  start={start_ms:.0f}ms  {st.BOLD}end={end_ms:.0f}ms{st.RST}  {st.DIM}{total_ms:.0f}ms total{st.RST}"
        else:
            line1 += f" {st.DIM}play a key to select{st.RST}"
    elif st.mode == "pitch":
        if st.pitch_selected_note is not None:
            offset = st.pitch_offsets.get(st.pitch_selected_note, {"semitones": 0, "cents": 0})
            info = format_pitch_info(st.pitch_selected_note, offset)
            line1 += f" {st.GREEN}{st.BOLD}\u2666{st.RST} {st.BOLD}{info}{st.RST}"
        else:
            line1 += f" {st.DIM}play a key to select{st.RST}"
    elif st.mode == "chromatic":
        if st.chromatic_selecting:
            line1 += f" {st.DIM}play a key to select{st.RST}"
        elif st.chromatic_computing and st.chromatic_root_note is not None:
            line1 += f" {st.YELLOW}{st.BOLD}computing {st.midi_note_name(st.chromatic_root_note)}...{st.RST}"
        elif st.chromatic_root_note is not None:
            root_name = st.midi_note_name(st.chromatic_root_note)
            range_start = st.midi_note_name(max(0, st.chromatic_root_note - 12))
            range_end = st.midi_note_name(min(127, st.chromatic_root_note + 12))
            line1 += f" {st.GREEN}{st.BOLD}\u2666{st.RST} {st.BOLD}{root_name}  {range_start}\u2013{range_end}{st.RST}"
        else:
            line1 += f" {st.DIM}play a key to select{st.RST}"
    elif st.mode == "copy":
        if st.copy_confirm_pending and st.copy_source_note is not None and st.copy_dest_note is not None:
            src_name = st.midi_note_name(st.copy_source_note)
            dst_name = st.midi_note_name(st.copy_dest_note)
            line1 += f" {st.YELLOW}{st.BOLD}overwrite {dst_name}?  {src_name} \u2192 {dst_name}{st.RST}"
        elif st.copy_source_note is not None:
            src_name = st.midi_note_name(st.copy_source_note)
            line1 += f" {st.GREEN}{st.BOLD}\u2666{st.RST} {st.BOLD}{src_name}{st.RST}  {st.DIM}play a key to paste{st.RST}"
        else:
            line1 += f" {st.DIM}play a key to copy{st.RST}"
    elif st.mode == "loop":
        l_state, l_pos, l_layers = loop_snap
        if l_state == "recording":
            rec_secs = len(loop_audio) / st.SAMPLE_RATE if loop_audio is not None else 0
            rec_m, rec_s = int(rec_secs) // 60, rec_secs % 60
            line1 += f" {st.RED}{st.BOLD}[REC]{st.RST}  {st.DIM}{rec_m}:{rec_s:04.1f}{st.RST}"
        elif l_state == "playing":
            buf_secs = len(loop_audio) / st.SAMPLE_RATE if loop_audio is not None else 0
            pos_secs = l_pos / st.SAMPLE_RATE if loop_audio is not None else 0
            pos_m, pos_s = int(pos_secs) // 60, pos_secs % 60
            layer_word = "layer" if l_layers == 1 else "layers"
            line1 += f" {st.GREEN}{st.BOLD}[PLAY]{st.RST}  {st.DIM}{pos_m}:{pos_s:04.1f} / {buf_secs:.1f}  x{l_layers} {layer_word}{st.RST}"
        elif l_state == "overdub":
            buf_secs = len(loop_audio) / st.SAMPLE_RATE if loop_audio is not None else 0
            pos_secs = l_pos / st.SAMPLE_RATE if loop_audio is not None else 0
            pos_m, pos_s = int(pos_secs) // 60, pos_secs % 60
            layer_word = "layer" if l_layers == 1 else "layers"
            line1 += f" {st.YELLOW}{st.BOLD}[DUB]{st.RST}  {st.DIM}{pos_m}:{pos_s:04.1f} / {buf_secs:.1f}  x{l_layers} {layer_word}{st.RST}"
        else:
            line1 += f" {st.DIM}idle{st.RST}"
    elif ui_rec:
        elapsed = time.time() - ui_rec["start_time"]
        line1 += f" {st.RED}{st.BOLD}\u25cf REC {ui_rec['note']}  {elapsed:.1f}s{st.RST}"
    elif st.ui_active_note:
        line1 += f" {st.GREEN}{st.BOLD}\u25cf{st.RST} {st.BOLD}{st.ui_active_note:<4}{st.RST}"
    else:
        line1 += f" {st.DIM} {st.RST}     "  # blank note area

    line1 += f"  {st.DIM}sustain {st.RST}"
    if st.ui_sustain:
        line1 += f"{st.YELLOW}{st.BOLD}\u25cf{st.RST}"
    else:
        line1 += f"{st.DIM}\u25cb{st.RST}"
    line1 += f"  {st.DIM}{st.CYAN}{len(st.samples)} samples{st.RST}"
    out += f"{st.CLEAR_LINE}\r{line1}\r\n"

    # Line 2: MIDI controller name or keyboard mode hint
    if st.keyboard_mock_mode:
        line2 = f" {st.DIM}keyboard mode  [1-0] play  [` ] sustain{st.RST}"
    else:
        line2 = f" {st.DIM}{st.ui_midi_port}{st.RST}" if st.ui_midi_port else ""
    out += f"{st.CLEAR_LINE}\r{line2}\r\n"

    # Line 3: help keys
    if st.mode == "trim":
        if st.trim_selected_note is None:
            line3 = f" {st.DIM}[Tab] mode  [play] select  [q] quit{st.RST}"
        else:
            line3 = f" {st.DIM}[\u2190\u2192] fine  [\u2191\u2193] coarse  [enter] set  [esc] cancel  [q] quit{st.RST}"
    elif st.mode == "pitch":
        line3 = f" {st.DIM}[Tab] mode  [\u2191\u2193] semitone  [\u2190\u2192] cents  [q] quit{st.RST}"
    elif st.mode == "chromatic":
        if st.chromatic_selecting:
            line3 = f" {st.DIM}[Tab] mode  [play] select  [q] quit{st.RST}"
        else:
            line3 = f" {st.DIM}[Tab] mode  [r] reselect  [q] quit{st.RST}"
    elif st.mode == "copy":
        if st.copy_confirm_pending:
            line3 = f" {st.DIM}[enter] confirm  [esc] cancel  [q] quit{st.RST}"
        elif st.copy_source_note is not None:
            line3 = f" {st.DIM}[Tab] mode  [play] paste  [esc] cancel  [q] quit{st.RST}"
        else:
            line3 = f" {st.DIM}[Tab] mode  [play] select  [q] quit{st.RST}"
    elif st.mode == "loop":
        line3 = f" {st.DIM}[sustain/l] record/play/dub  [esc] clear  [play] sample  [q] quit{st.RST}"
    else:
        line3 = f" {st.DIM}[Tab] mode  [q] quit{st.RST}"
    out += f"{st.CLEAR_LINE}\r{line3}\r\n"

    st.prev_ui_lines = total_lines

    sys.stdout.write(out)
    sys.stdout.flush()
