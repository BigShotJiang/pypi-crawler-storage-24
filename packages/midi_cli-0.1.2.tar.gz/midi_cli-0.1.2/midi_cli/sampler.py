import json
import os
import threading
import time
import wave

import numpy as np
import pyrubberband as pyrb
import sounddevice as sd

import midi_cli.state as st
from midi_cli.audio import trim_silence


def load_pitch_offsets():
    """Load pitch offsets from samples/pitch_offsets.json if it exists."""
    path = os.path.join("samples", "pitch_offsets.json")
    if not os.path.isfile(path):
        return
    with open(path, "r") as f:
        raw = json.load(f)
    st.pitch_offsets = {int(k): v for k, v in raw.items()}
    for note, offset in st.pitch_offsets.items():
        if note in st.samples:
            recompute_pitched_sample(note)


def save_pitch_offsets():
    """Save pitch offsets to samples/pitch_offsets.json, pruning zero entries."""
    to_save = {k: v for k, v in st.pitch_offsets.items()
                if v["semitones"] != 0 or v["cents"] != 0}
    os.makedirs("samples", exist_ok=True)
    path = os.path.join("samples", "pitch_offsets.json")
    with open(path, "w") as f:
        json.dump(to_save, f, indent=2)


def recompute_pitched_sample(note):
    """Recompute the pitched version of a sample for the given note."""
    offset = st.pitch_offsets.get(note)
    if offset is None or (offset["semitones"] == 0 and offset["cents"] == 0):
        with st.voices_lock:
            st.pitched_samples.pop(note, None)
        return
    total_steps = offset["semitones"] + offset["cents"] / 100.0
    result = pyrb.pitch_shift(st.samples[note], sr=st.SAMPLE_RATE, n_steps=total_steps)
    with st.voices_lock:
        st.pitched_samples[note] = result


def recompute_pitched_sample_async(note):
    """Recompute pitched sample in a background thread."""
    threading.Thread(target=recompute_pitched_sample, args=(note,), daemon=True).start()


def compute_chromatic_samples(root_note):
    """Pre-compute pitched versions of the root sample across two octaves (one up, one down)."""
    range_start = max(0, root_note - 12)
    range_end = min(127, root_note + 12)
    source = st.samples[root_note]
    result = {}
    for midi_note in range(range_start, range_end + 1):
        offset = midi_note - root_note
        if offset == 0:
            result[midi_note] = source
        else:
            result[midi_note] = pyrb.pitch_shift(source, sr=st.SAMPLE_RATE, n_steps=offset)
    with st.voices_lock:
        st.chromatic_samples.clear()
        st.chromatic_samples.update(result)
    st.chromatic_computing = False


def compute_chromatic_samples_async(root_note):
    """Launch chromatic pre-computation in a background thread."""
    st.chromatic_computing = True
    threading.Thread(target=compute_chromatic_samples, args=(root_note,), daemon=True).start()


def format_pitch_info(note, offset):
    """Return a formatted string like 'C4  +3st +20c'."""
    s = offset["semitones"]
    c = offset["cents"]
    s_str = f"+{s}st" if s >= 0 else f"{s}st"
    c_str = f"+{c}c" if c >= 0 else f"{c}c"
    return f"{st.midi_note_name(note):<4} {s_str} {c_str}"


def adjust_pitch(note, semitones, cents):
    """Adjust pitch offset for a note by the given semitone/cent deltas."""
    if note not in st.pitch_offsets:
        st.pitch_offsets[note] = {"semitones": 0, "cents": 0}
    offset = st.pitch_offsets[note]
    offset["semitones"] += semitones
    offset["cents"] += cents
    # Normalize cents overflow into semitones
    while offset["cents"] >= 100:
        offset["cents"] -= 100
        offset["semitones"] += 1
    while offset["cents"] <= -100:
        offset["cents"] += 100
        offset["semitones"] -= 1
    save_pitch_offsets()
    recompute_pitched_sample_async(note)


def save_sample(note_number, audio):
    """Store a sample in memory and save to disk as WAV."""
    st.samples[note_number] = audio

    os.makedirs("samples", exist_ok=True)
    filepath = f"samples/note_{note_number}.wav"
    with wave.open(filepath, "w") as wf:
        wf.setnchannels(1)
        wf.setsampwidth(2)  # 16-bit
        wf.setframerate(st.SAMPLE_RATE)
        int_data = np.clip(audio * 32767, -32768, 32767).astype(np.int16)
        wf.writeframes(int_data.tobytes())

    if note_number in st.pitch_offsets:
        recompute_pitched_sample_async(note_number)


def execute_copy():
    """Copy sample and pitch offset from source to destination."""
    src = st.copy_source_note
    dst = st.copy_dest_note
    if src is None or dst is None or src not in st.samples:
        st.copy_source_note = None
        st.copy_dest_note = None
        st.copy_confirm_pending = False
        return

    # Copy pitch offset (or remove dest's offset if source has none)
    if src in st.pitch_offsets:
        st.pitch_offsets[dst] = dict(st.pitch_offsets[src])
    else:
        st.pitch_offsets.pop(dst, None)

    # Copy sample data
    save_sample(dst, st.samples[src].copy())
    save_pitch_offsets()

    # Recompute chromatic samples if dest was the chromatic root
    if st.chromatic_root_note == dst:
        compute_chromatic_samples_async(dst)

    # Reset copy state
    st.copy_source_note = None
    st.copy_dest_note = None
    st.copy_confirm_pending = False


def start_recording(note_number):
    with st.voices_lock:
        if st.recording_note is not None:
            return  # already recording; ignore
        st.recording_note = note_number
        st.recording_chunks = []
        st.ui_recording = {"note": st.midi_note_name(note_number), "start_time": time.time()}

    def _callback(indata, frames, time_info, status):
        st.recording_chunks.append(indata[:, 0].copy())

    stream = sd.InputStream(
        samplerate=st.SAMPLE_RATE, channels=1, dtype="float32",
        device=st.input_device, callback=_callback,
    )
    stream.start()
    with st.voices_lock:
        st.recording_stream = stream


def stop_recording(note_number):
    with st.voices_lock:
        if st.recording_note != note_number:
            return  # not recording this note; ignore
        stream = st.recording_stream
        chunks = list(st.recording_chunks)
        st.recording_note = None
        st.recording_stream = None
        st.recording_chunks = []
        st.ui_recording = None

    if stream is not None:
        stream.stop()
        stream.close()

    if chunks:
        audio = np.concatenate(chunks).astype("float64")
        audio = trim_silence(audio)
        save_sample(note_number, audio)


def load_samples():
    """Load any existing .wav files from ./samples/ directory."""
    if not os.path.isdir("samples"):
        return
    for filename in os.listdir("samples"):
        if filename.startswith("note_") and filename.endswith(".wav"):
            try:
                note_num = int(filename[5:-4])
            except ValueError:
                continue
            filepath = os.path.join("samples", filename)
            with wave.open(filepath, "r") as wf:
                n_frames = wf.getnframes()
                raw = wf.readframes(n_frames)
                width = wf.getsampwidth()
                if width == 2:
                    int_data = np.frombuffer(raw, dtype=np.int16)
                    audio = int_data.astype(np.float64) / 32767.0
                elif width == 4:
                    int_data = np.frombuffer(raw, dtype=np.int32)
                    audio = int_data.astype(np.float64) / 2147483647.0
                else:
                    continue
                # If stereo, take first channel
                if wf.getnchannels() > 1:
                    audio = audio[::wf.getnchannels()]
                st.samples[note_num] = audio
