import threading

import numpy as np

# Audio constants
SAMPLE_RATE = 48000
BLOCK_SIZE = 256
FADE_SAMPLES = int(0.005 * SAMPLE_RATE)  # 5ms fade

# Note/keyboard constants
NOTE_NAMES = ["C", "C#", "D", "D#", "E", "F", "F#", "G", "G#", "A", "A#", "B"]
KEYBOARD_NOTE_MAP = {'1': 60, '2': 61, '3': 62, '4': 63, '5': 64,
                     '6': 65, '7': 66, '8': 67, '9': 68, '0': 69}
KEYBOARD_NOTE_RELEASE_S = 0.25

# ANSI escape helpers
RST = "\033[0m"
DIM = "\033[2m"
BOLD = "\033[1m"
GREEN = "\033[32m"
RED = "\033[31m"
YELLOW = "\033[33m"
CYAN = "\033[36m"
ORANGE = "\033[38;5;208m"
CLEAR_LINE = "\033[2K"
HIDE_CURSOR = "\033[?25l"
SHOW_CURSOR = "\033[?25h"
NUM_UI_LINES = 4

# Per-sample gain step for 5ms fade
FADE_IN_STEP = 1.0 / FADE_SAMPLES
FADE_OUT_STEP = 1.0 / FADE_SAMPLES

# Two-stage exponential decay (piano-like)
# Stage 1: fast initial decay (~0.5s) — hammer brightness fading
STAGE1_SAMPLES = int(0.5 * SAMPLE_RATE)
STAGE1_DECAY = 0.4 ** (1.0 / STAGE1_SAMPLES)  # drops to ~40% over 0.5s
# Stage 2: slow ring-out (~7s to silence)
STAGE2_DECAY = 0.001 ** (1.0 / (7.0 * SAMPLE_RATE))
SILENCE_THRESHOLD = 0.001

# Harmonic amplitudes (piano-like spectrum)
HARMONICS = np.array([1.0, 0.5, 0.25, 0.12, 0.06])
HARMONICS /= HARMONICS.sum()  # normalize so total max = 1.0
H_MULTIPLIERS = np.arange(1, len(HARMONICS) + 1)  # [1, 2, 3, 4, 5]


def midi_note_name(note_number):
    return f"{NOTE_NAMES[note_number % 12]}{(note_number // 12) - 1}"


def note_to_freq(note):
    return 440.0 * 2.0 ** ((note - 69) / 12.0)


# Voice: {note: {"phase": float, "gain": float, "releasing": bool}}
voices = {}
voices_lock = threading.Lock()
sustain = False
sustained_notes = set()

# Sampler state
MODES = ["synth", "sample", "record", "pitch", "chromatic", "trim", "copy", "loop"]
mode = "synth"
samples = {}  # note_number -> numpy array (mono float64)
sample_voices = {}  # note -> {"pos": int, "releasing": bool, "gain": float}

# Dynamic recording state
recording_note = None       # int: MIDI note currently recording, or None
recording_chunks = []       # list of np.ndarray frames from InputStream callback
recording_stream = None     # sd.InputStream instance, or None
keyboard_recording_notes = set()  # notes with in-progress keyboard-toggle recordings

# Pitch mode state
pitch_offsets = {}        # note_number -> {"semitones": int, "cents": int}
pitched_samples = {}      # note_number -> pre-computed pitched numpy array
pitch_selected_note = None  # currently selected note for pitch adjustment
CENTS_STEP = 10           # cents per left/right arrow press

# Chromatic mode state
chromatic_root_note = None      # selected root MIDI note
chromatic_samples = {}          # midi_note -> numpy array (pre-computed)
chromatic_computing = False     # True while background thread runs
chromatic_selecting = False     # True when waiting for user to pick root

# Trim mode state
trim_selected_note = None   # MIDI note being trimmed (None = selecting)
trim_step = 0               # 0 = adjusting start, 1 = adjusting end
trim_start = 0              # start sample index
trim_end = 0                # end sample index
trim_loop_pos = 0           # current playback position for loop preview
trim_looping = False        # True while preview loop is active
TRIM_WAVEFORM_HEIGHT = 6    # rows for waveform display
MIN_TRIM_SAMPLES = 480      # ~10ms minimum trim length
MIN_LOOP_PERIOD = int(2.0 * SAMPLE_RATE)  # minimum loop cycle including silence

# Loop mode state
loop_state = "idle"       # "idle", "recording", "playing", "overdub"
loop_buffer = None        # np.ndarray once recorded, None when idle
loop_pos = 0              # current playback position (int)
loop_record_chunks = []   # list of np.ndarray, accumulated during recording
loop_layer_count = 0      # 1 after first recording, increments each overdub completion

# Copy mode state
copy_source_note = None       # MIDI note selected as source
copy_dest_note = None         # MIDI note selected as destination
copy_confirm_pending = False  # True when awaiting overwrite confirmation

# UI state
ui_active_note = None
ui_sustain = False
ui_recording = None  # None or {"note": str, "start_time": float}
ui_midi_port = ""
prev_ui_lines = NUM_UI_LINES

keyboard_mock_mode = False
keyboard_timers = {}  # note -> threading.Timer, for pending note-offs

# Device selections (set by startup wizard, None = system default / port 0)
input_device = None   # audio input device name or None
output_device = None  # audio output device name or None
midi_port = None      # MIDI port name or None
