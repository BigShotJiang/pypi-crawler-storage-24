# midi-cli

A little midi player in your terminal, tested in zsh on macOS.

## Install

```sh
pipx install midi-cli
```

Or with pip:

```sh
pip install midi-cli
```

### For development

```sh
uv pip install -e .
```

## Usage

```sh
midi-cli
```
