# tendQuant

个人量化开发必备，快速获取A股全市场5000+股票和场内ETF的实时行情数据，基于 MQTT 协议提供实时、稳定、高效的行情数据推送服务，免费获取常见 A股 指数的实时行情数据。

官网链接：[https://tendquant.cn](https://tendquant.cn)

项目地址：[https://github.com/top2189/tendQuant](https://github.com/top2189/tendQuant)


## 功能特性

- **MQTTv5支持**：默认使用MQTTv5协议
- **WebSocket支持**：支持通过WebSocket协议连接
- **自动重连**：断开连接后自动尝试重连
- **简单API**：简洁的订阅/取消订阅接口
- **错误处理**：详细的错误信息和处理机制

## 安装方法

```bash
pip install -U tendquant
```

## 使用示例

### 基本用法

```python
from tendquant import Client

# 创建客户端实例
client = Client(
    username="a2dZMmrflhY4MwRN",
    password="6WUc6unvD4G3VVPx4K6t2Nl5mVq4fjtu",
)

# 连接到broker
client.connect()

# 订阅主题
client.subscribe("lv1/tradeList/000001")
client.subscribe("lv1/tradeList/600000")

# 取消订阅
client.unsubscribe("lv1/tradeList/000001")

# 断开连接
client.disconnect()
```

### 自定义消息处理器

```python
from tendquant import Client
import json

def custom_on_message(client, userdata, msg):
    topic = msg.topic
    payload = msg.payload.decode('utf-8')
    data = json.loads(payload)
    print(f"收到消息: {topic} -> {data}")

# 创建客户端
client = Client(
    username="a2dZMmrflhY4MwRN",
    password="6WUc6unvD4G3VVPx4K6t2Nl5mVq4fjtu",
)

# 设置自定义消息处理器
client.client.on_message = custom_on_message

# 连接
client.connect()
```

## CLI工具

### Cli工具使用

```bash
# 订阅所有股票的五档盘口数据，“#” 表示订阅所有股票代码
tendquant -u a2dZMmrflhY4MwRN -p 6WUc6unvD4G3VVPx4K6t2Nl5mVq4fjtu -s lv1/orderBook/#
```

## 许可证

MIT License

## 贡献

欢迎贡献代码！请提交Pull Request。