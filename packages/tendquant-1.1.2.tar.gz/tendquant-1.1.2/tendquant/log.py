import sys
import ctypes
import logging
from typing import Optional

# 日志颜色配置
class LogColors:
    """ANSI颜色代码"""
    RESET = '\033[0m'
    DEBUG = '\033[90m'      # 灰色
    INFO = '\033[92m'       # 绿色
    WARNING = '\033[93m'    # 黄色
    ERROR = '\033[91m'      # 红色
    CRITICAL = '\033[95m'   # 紫色

class ColoredFormatter(logging.Formatter):
    """彩色日志格式化器"""
    
    def __init__(self, fmt=None, datefmt=None, use_colors=True):
        super().__init__(fmt, datefmt)
        self.use_colors = use_colors and self._supports_color()
    
    def _supports_color(self):
        """检查终端是否支持颜色，并尝试在 Windows 上启用"""
        platform = sys.platform
        is_supported = False
        
        # Windows 平台处理
        if platform == 'win32':
            # 尝试调用 Windows API 启用虚拟终端处理
            kernel32 = ctypes.windll.kernel32
            # STD_OUTPUT_HANDLE 的值是 -11
            STD_OUTPUT_HANDLE = -11
            # ENABLE_VIRTUAL_TERMINAL_PROCESSING 的值是 0x0004
            ENABLE_VIRTUAL_TERMINAL_PROCESSING = 0x0004
            
            # 获取标准输出句柄
            handle = kernel32.GetStdHandle(STD_OUTPUT_HANDLE)
            if handle:
                # 获取当前模式
                mode = ctypes.c_ulong()
                if kernel32.GetConsoleMode(handle, ctypes.byref(mode)):
                    # 尝试设置模式，添加虚拟终端处理标志
                    if kernel32.SetConsoleMode(handle, mode.value | ENABLE_VIRTUAL_TERMINAL_PROCESSING):
                        is_supported = True
        # Linux/Mac 平台处理
        elif hasattr(sys.stdout, 'isatty') and sys.stdout.isatty():
            is_supported = True
            
        return is_supported
    
    def format(self, record):
        # 保存原始消息
        original_msg = record.msg
        original_levelname = record.levelname
        
        # 添加颜色
        if self.use_colors:
            # 为级别名称添加颜色
            if record.levelno == logging.DEBUG:
                record.levelname = f"{LogColors.DEBUG}{record.levelname}  {LogColors.RESET}"
            elif record.levelno == logging.INFO:
                record.levelname = f"{LogColors.INFO}{record.levelname}   {LogColors.RESET}"
            elif record.levelno == logging.WARNING:
                record.levelname = f"{LogColors.WARNING}{record.levelname}{LogColors.RESET}"
            elif record.levelno >= logging.ERROR:
                record.levelname = f"{LogColors.ERROR}{record.levelname}  {LogColors.RESET}"
            
            # 为消息内容添加颜色
            if record.levelno == logging.WARNING:
                record.msg = f"{LogColors.WARNING}{record.msg}{LogColors.RESET}"
            elif record.levelno == logging.INFO:
                record.msg = f"{LogColors.INFO}{record.msg}{LogColors.RESET}"
            elif record.levelno == logging.DEBUG:
                record.msg = f"{LogColors.DEBUG}{record.msg}{LogColors.RESET}"
            elif record.levelno >= logging.ERROR:
                record.msg = f"{LogColors.ERROR}{record.msg}{LogColors.RESET}"
                
        
        # 格式化消息
        result = super().format(record)
        
        # 恢复原始值
        record.msg = original_msg
        record.levelname = original_levelname
        
        return result


def setup_logger(
    name: str,
    level: int = logging.INFO,
    use_colors: bool = True,
    log_format: Optional[str] = None
) -> logging.Logger:
    """
    配置并返回日志记录器
    
    Args:
        name: 日志记录器名称
        level: 日志级别
        use_colors: 是否使用彩色输出
        log_format: 日志格式，默认格式为: 时间 - 级别 - 消息
    
    Returns:
        logging.Logger: 配置好的日志记录器
    """
    logger = logging.getLogger(name)
    logger.setLevel(level)
    
    # 避免重复添加handler
    if logger.handlers:
        return logger
    
    # 创建控制台处理器
    handler = logging.StreamHandler()
    
    # 设置日志格式
    if log_format is None:
        log_format = '%(asctime)s - %(levelname)s - %(message)s'
    
    formatter = ColoredFormatter(
        fmt=log_format,
        datefmt='%Y-%m-%d %H:%M:%S',
        use_colors=use_colors
    )
    handler.setFormatter(formatter)
    logger.addHandler(handler)
    
    return logger

