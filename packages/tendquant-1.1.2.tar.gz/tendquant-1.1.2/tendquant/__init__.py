from .client import Client

__version__ = "1.1.2"
__author__ = "tendQuant"
__email__ = "fengyuan2189@gmail.com"

__all__ = ["Client"]