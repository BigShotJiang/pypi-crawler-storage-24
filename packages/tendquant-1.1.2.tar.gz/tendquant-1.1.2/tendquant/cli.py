#!/usr/bin/env python3
"""
tendQuant CLI tool
"""
import time
import argparse
from . import Client

def main():
    parser = argparse.ArgumentParser(description="tendQuant Client CLI")
    parser.add_argument("-u", "--username", help="认证用户")
    parser.add_argument("-p", "--password", help="认证密码")
    parser.add_argument("-s", "--subscribe", help="需要订阅的主题")
    parser.add_argument("-o", "--output", help="保存行情到指定目录")
    
    args = parser.parse_args()

    # Create client
    client = Client(
        username=args.username,
        password=args.password,
        output_dir=args.output
    )
    
    # Connect
    client.connect()
    
    # Subscribe
    if args.subscribe:
        client.subscribe(args.subscribe)
    
    # Keep running
    try:
        while True:
            time.sleep(1)
    except KeyboardInterrupt:
        client.disconnect()
        
if __name__ == "__main__":
    main()