from setuptools import setup, find_packages

with open("README.md", "r", encoding="utf-8") as fh:
    long_description = fh.read()

setup(
    name="tendQuant",
    version="1.1.2",
    author="tendQuant",
    author_email="fengyuan2189@gmail.com",
    description="A MQTT client library for tendQuant",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/top2189/tendQuant",
    packages=find_packages(),
    classifiers=[
        "Development Status :: 3 - Alpha",
        "Intended Audience :: Developers",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.7",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
    ],
    python_requires=">=3.7",
    install_requires=[
        "paho-mqtt>=2.0.0",
    ],
    entry_points={
        "console_scripts": [
            "tendquant = tendquant.cli:main",
        ],
    },
    include_package_data=True,
)