# ADR-108: Multi-Agent Graph Access — Shared Intelligence Layer

**Date:** 2026-03-14 | **Status:** ACCEPTED

## Context

AI coding tools (Claude Code, Cursor, Windsurf, Devin, custom orchestrators) increasingly spawn multiple background agents for complex tasks. Currently, only the main orchestrator has Graqle MCP access. Subagents work blind — reading raw files, missing cross-cutting dependencies, unable to check lessons or run preflight checks.

**The numbers:** A 10-agent parallel refactor reads ~40-60K tokens of raw files vs ~4-8K tokens via Graqle = 75-85% token savings. Every subagent running `graq_preflight` catches risks the orchestrator might miss.

## Decision

Implement tiered access with 5 features:

### 1. `graq context --json` (Low effort, High impact)
Structured JSON output from CLI — no ANSI codes, no embedding vectors, parseable by any subagent via Bash. This works TODAY with any AI tool, no protocol changes needed.

### 2. `graq mcp serve --read-only` (Medium effort, High impact)
MCP server mode that blocks mutation tools (`graq_learn`, `graq_reload`). Only exposes: `graq_context`, `graq_lessons`, `graq_preflight`, `graq_impact`, `graq_inspect`, `graq_reason`. Prevents concurrent write corruption while giving subagents full intelligence.

### 3. `graq serve --http --read-only` (Medium-High effort, High impact)
HTTP server mode for true multi-process concurrent access. FastAPI app with read-only flag that returns 403 on `/learn` and `/reload`. Any process can query via HTTP.

### 4. File-level locking on `graqle.json` (Medium effort, Safety)
Cross-platform file locking (Windows: `msvcrt.locking()`, Unix: `fcntl.flock()`) on all graph writes. Safety net for concurrent orchestrator instances.

### 5. `--caller` parameter (Low effort, Observability)
Track which agent queried what in metrics. Enables per-agent cost attribution and usage analytics.

## Access Tiers

| Role | Tools | Write Access |
|------|-------|-------------|
| Orchestrator (main agent) | All MCP tools | Full |
| Subagent (background) | Read-only MCP or `--json` CLI | None |
| HTTP client | REST API endpoints | Configurable |

## Consequences

**Positive:**
- Graqle becomes a **shared intelligence layer**, not a single-session tool
- Value scales linearly with agent count (more agents = more token savings)
- Works with ANY orchestrator — not tied to Claude Code
- File locking prevents graph corruption from concurrent writes
- Caller tracking enables per-agent cost attribution

**Negative:**
- HTTP server adds a network dependency (localhost only by default)
- Read-only mode requires users to understand the access model
- File locking adds ~5ms overhead per write (acceptable)

## Why This Is Strategic

AI-assisted development is moving toward multi-agent workflows. Graqle as a single-session tool is "useful CLI tool." Graqle with multi-agent access is "infrastructure every AI coding agent depends on." This is the difference between a tool and a platform.
