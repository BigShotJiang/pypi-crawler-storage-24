# ADR-107: Windows Unicode — Universal Fix Across All Platforms

**Date:** 2026-03-14 | **Status:** ACCEPTED

## Context

Graqle CLI uses Rich for terminal output. Rich's `_win32_console.py` writes Unicode characters (→, ⚡, ●) directly to the Win32 console handle via `WriteConsoleW`. On Windows terminals with cp1252 encoding (the default), this triggers `UnicodeEncodeError: 'charmap' codec can't encode character '\u2192'`.

This was reported as **P0-001** in v0.16.0 and persisted through v0.18.0 because the initial fix (`PYTHONIOENCODING=utf-8` env var) was insufficient — it configures Python's stream encoding but does NOT affect Rich's internal Win32 console writer, which bypasses Python's IO layer entirely.

**Reproduction:** 100% on Windows 11 with default PowerShell or cmd.exe. Triggered by `graq context <any-node>` when output contains relationship arrows (`→`).

## Root Cause Analysis

Three independent failure points:

1. **Python stdout/stderr encoding:** Defaults to cp1252 on Windows. Any `print()` or `sys.stdout.write()` with non-ASCII chars fails.
2. **Rich Win32 Console API:** Rich detects Windows and uses `WriteConsoleW` via ctypes. When this path encounters chars outside the console's code page, it falls back to the stream writer — which is still cp1252.
3. **No ASCII fallback:** Code used Unicode symbols (→, ●, ⚡) without checking platform capability.

## Decision

Implement a **three-layer defense** in a single module (`graqle/cli/console.py`):

### Layer 1: Stream Reconfiguration (runs on import)
```python
def _ensure_utf8_streams():
    os.environ["PYTHONIOENCODING"] = "utf-8"
    if hasattr(sys.stdout, "reconfigure"):
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    # Fallback: wrap in TextIOWrapper for older Python
```
This ensures all `print()` calls use UTF-8.

### Layer 2: Rich Console with `force_terminal=True`
```python
def create_console():
    if sys.platform == "win32":
        return Console(force_terminal=True, force_jupyter=False)
    return Console()
```
`force_terminal=True` tells Rich to use VT100 escape sequences instead of the Win32 Console API. Modern Windows Terminal (since 2019) supports VT100 natively. This completely bypasses the `_win32_console.py` code path.

### Layer 3: Symbol Sanitization
```python
def safe_symbol(unicode_char: str, ascii_fallback: str) -> str:
    if sys.platform == "win32":
        return ascii_fallback
    return unicode_char
```
For any remaining edge cases (piped output, legacy terminals), provides ASCII fallbacks.

### Single Source of Truth
All CLI files import from `graqle.cli.console` — no direct `from rich.console import Console` anywhere in CLI code. This ensures the fix is applied universally.

## Consequences

**Positive:**
- Works on all Windows versions (10+, Server 2019+) with any terminal emulator
- Works on all Unix/macOS terminals (no change in behavior)
- Works when piped (`graq context auth > file.txt`)
- Zero external dependencies added
- `errors="replace"` means even truly unrenderable chars show `?` instead of crashing

**Negative:**
- `force_terminal=True` on very old Windows versions (pre-VT100) may show raw ANSI codes instead of colors. Acceptable trade-off vs crashing.
- ASCII fallback symbols (→ becomes ->) are less visually appealing. Acceptable.

## Lessons Learned

1. `PYTHONIOENCODING` env var is necessary but not sufficient when Rich is involved — Rich has its own IO path.
2. Always test CLI output on Windows cp1252 terminals, not just UTF-8 configured ones.
3. A Unicode fix must cover ALL output paths: Python streams, Rich console, and raw symbol usage.
4. `force_terminal=True` is the single most impactful fix for Rich on Windows.
