# ADR-110: Frictionless UX and Permission-Based Feature Gating

**Date:** 2026-03-14 | **Status:** ACCEPTED (PENDING implementation — Phase 7)

## Context

Graqle must be the command developers type before they start working — not because they have to, but because working without it feels like driving without GPS. This requires zero-config adoption AND responsible cost control for advanced features that use external APIs.

The core tension: **maximum value with minimum friction** vs **never spend money without asking**.

## Decision

### Design Principles

| Principle | Meaning |
|-----------|---------|
| **DETECT don't ASK** | Check env vars, running processes, file extensions — don't prompt |
| **DEFAULT don't REQUIRE** | Every config has sensible defaults. `graqle.yaml` never required |
| **DEFER don't BLOCK** | Code scan instant, user works. Heavy scanning in background |
| **ENRICH don't DUMP** | Clean summaries with sources, not raw vectors |

### Zero-Config First Run

```bash
$ pip install graqle
$ cd my-project
$ graq

  ✓ Detected: git repo, Python + TypeScript
  ✓ Detected: AWS credentials (Bedrock, eu-north-1)
  ✓ Scanned: 1,018 code nodes (2.1s)
  ✓ Background: 8 JSON configs, 14 docs — scanning...
  ✓ Configured: Claude Code (.mcp.json written)
```

Value in 60 seconds. Zero configuration.

### Permission-Based Feature Gating (5 Tiers)

**Core principle: local is free and automatic. External costs require permission.**

| Tier | What's Included | Permission? | Cost |
|------|----------------|-------------|------|
| **Tier 0: Local-Only** | Code AST scan, JSON parse, MD/TXT parse, exact/fuzzy linking, canonical dedup | **No — automatic** | $0 |
| **Tier 1: Local + Heavy** | PDF/DOCX/PPTX/XLSX parsing, concept clustering (local embeddings) | **No — automatic if deps installed** | $0 (CPU only) |
| **Tier 2: API Embeddings** | Semantic linking (Bedrock Titan V2), semantic dedup | **Yes — user opts in** | ~$0.001/query |
| **Tier 3: LLM-Assisted** | LLM node typing, contradiction analysis, relationship extraction | **Yes — user sets budget** | ~$0.01-0.10/doc |
| **Tier 4: Full Intelligence** | All above + continuous background enrichment | **Yes — budget ceiling required** | User-controlled |

**Key rules:**
1. **Never spend money without asking.** Even $0.001.
2. **Show what you'll get.** Preview enrichment results before committing.
3. **Remember the answer.** User says "yes" once → don't ask again for same scan type until budget changes.
4. **Hard ceiling is hard.** If `monthly_budget` is hit, stop ALL paid operations with clear message.

### Budget Control

```yaml
cost:
  scan_budget: 1.00           # Max $ per scan run
  monthly_budget: 10.00       # Hard monthly ceiling
  warn_at: 0.50               # Warn at 50% of scan_budget consumed
  escalation: prompt          # "prompt" (ask), "auto" (within budget), "deny" (never)
```

### Machine Capability Awareness

Scale parallel operations to available hardware:

| Capacity | RAM | Threads | Behavior |
|----------|-----|---------|----------|
| minimal | <4GB | 1 | Sequential, skip large files |
| standard | 4-8GB | 2 | Basic embeddings |
| capable | 8-16GB | 4 | Full embeddings |
| powerful | 16GB+ | 8+ | Everything enabled, batch embeddings |

### Auto-Detection Matrix

| Signal | Method | Action |
|--------|--------|--------|
| Backend | `AWS_*` env vars → Bedrock; `ANTHROPIC_API_KEY` → Anthropic | Set model backend |
| IDE | Running processes, `.cursor/`, `.vscode/` | Auto-write MCP configs |
| Language | File extensions in root | Route to correct analyzers |
| Exclusions | Built-in smart defaults | Auto-exclude node_modules, dist, .git |
| Region | `AWS_DEFAULT_REGION` env var | Set Bedrock region |

### Natural Language as Default Interface

```bash
graq "what depends on auth?"           → routes to impact
graq "is it safe to change payment?"   → routes to preflight
graq "what went wrong last time?"      → routes to lessons
```

Keyword-based classifier (zero LLM cost). Power users can still use explicit commands.

### Document Quality Gate

Auto-reject documents that don't contribute meaningful knowledge:
- Too short (<50 chars)
- Binary/garbled content (>50% non-ASCII)
- No parseable structure
- Exact duplicate (by hash)
- Test fixture/mock data

Rejected documents logged to `.graqle/rejection-report.json`.

### Codebase Health Warnings

Post-scan warnings about graph pollution:
- Large test data directories
- Headingless Word docs
- Superseded document versions
- Recommendations with estimated impact

### Premium Tier Gating

| Feature | Free | Pro $19/mo | Team $29/dev/mo |
|---------|------|-----------|-----------------|
| Code + JSON scan | Unlimited | Unlimited | Unlimited |
| Document scan | 10 docs | Unlimited | Unlimited |
| Graph nodes | 500 | 5,000 | 50,000 |
| Exact + fuzzy linking | Yes | Yes | Yes |
| Semantic linking | No | Yes | Yes |
| Contradiction detection | Basic | Full | Full |
| Cross-repo graphs | No | No | Yes |

### Config Philosophy

```
ZERO CONFIG (80% of users): graq → auto-detect, smart defaults
LIGHT CONFIG (power users): .graqle-ignore + graqle.yaml (overrides only)
FULL CONFIG (enterprise): All settings explicit + merge decisions
```

### Adoption Funnel

```
MINUTE 1:  pip install graqle && graq     → graph exists, first query works
MINUTE 5:  user asks 3-4 questions        → "this is actually useful"
DAY 1:     JSON + docs scanned in bg      → "it knows about my ADRs!"
WEEK 1:    user teaches a few things      → "it remembers what I told it"
WEEK 2:    contradictions found           → "it found 3 stale docs"
MONTH 1:   graph has 30 days of knowledge → "I can't work without this"
```

## Implementation Estimate

~8 source + ~5 test files, 3 sprints:
- Sprint 1: Zero-config `graq`, smart excludes, auto-detect backend, auto-configure IDE
- Sprint 2: NL query routing, budget/cost control, machine capability assessment, document quality gate
- Sprint 3: Codebase health warnings, plan limits/upsell gating, parallel scanning

## Consequences

**Positive:**
- Zero-friction adoption: `pip install graqle && graq` produces useful graph with no config.
- Local-first: best case = all information stays local, zero cost.
- Permission-based gating prevents surprise API costs.
- Machine capability awareness prevents resource exhaustion on low-spec hardware.
- Document quality gate prevents graph pollution from junk files.

**Negative:**
- Auto-detection may misclassify edge cases (mitigated by explicit config override).
- NL query routing adds a classification layer (mitigated by keyword-based, zero LLM cost).
- Premium gating may frustrate free-tier users (mitigated by generous free tier + clear upgrade path).
- Machine detection depends on `psutil` (mitigated by graceful fallback to "standard" capacity).
