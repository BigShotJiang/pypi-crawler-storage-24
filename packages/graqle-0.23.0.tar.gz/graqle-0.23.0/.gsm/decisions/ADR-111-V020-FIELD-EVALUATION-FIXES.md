# ADR-111: v0.20.0 Field Evaluation Fixes + LLM Init Philosophy

**Date:** 2026-03-14 | **Status:** ACCEPTED
**Source:** CopyForge v0.20.0 Field Evaluation Report (8.5/10)

---

## Context

CopyForge's field evaluation of v0.20.0 revealed 6 P1 bugs and 5 P2 issues. This is the third consecutive field report (v0.16.0, v0.18.0, v0.20.0). Three items appeared for the third consecutive report (.mcp.json path, Bedrock region, model validation), indicating systemic root causes rather than one-off bugs.

Additionally, the user's explicit feedback: **"We should not hardcode Bedrock. Normal users should be asked to set up their LLM with proper explanation of how it will save their context tokens. One-time cost, long-term savings."**

---

## Decision: LLM Init Philosophy — DETECT, EXPLAIN, ASK

**Never hardcode a specific LLM backend.** The `graq init` flow must:

1. **DETECT** what's available (check env vars, installed packages)
2. **EXPLAIN** why an LLM is needed and how Graqle saves tokens:
   - "Graqle builds a knowledge graph so your AI assistant reads 500-token focused summaries instead of 20,000-token brute-force file scans"
   - "One-time 2-minute setup saves thousands of tokens on every query — typically 33x cheaper and 541x more token-efficient"
3. **ASK** the user to choose from detected options (never default silently)
4. **VALIDATE** the chosen model works before writing config

### Region Resolution Chain (Bedrock)
```
config.region → AWS_DEFAULT_REGION → AWS_REGION → ASK USER
```
Never fall back to "us-east-1". If no region is detectable, **ask**.

### Model Validation
- Bedrock: call `list_foundation_models()` and let user pick from valid models
- Anthropic/OpenAI: validate with a minimal API call during init
- `graq doctor` must show WARN (not "--") when validation fails

---

## P1 Fixes

### P1-1: Background doc scan hangs on Windows
- **Root cause:** Daemon threads with file I/O can be killed mid-write on Windows when the main process exits. The scan thread writes `.graqle-scan-state.json` after every file — if the main CLI exits before the thread finishes, Windows terminates the daemon thread abruptly.
- **Fix:** Use `daemon=False` on Windows (via `sys.platform`). Add exception logging around the entire thread body. Flush state file writes with `os.fsync()`.
- **Lesson:** Daemon threads are unsafe for background I/O on Windows. Always use non-daemon threads when the thread writes files.

### P1-2: Titan V2 region hardcoded to us-east-1
- **Root cause:** Fallback chain ends with `"us-east-1"` instead of reading from config. This is the THIRD report of region hardcoding.
- **Fix:** Region resolution chain: `explicit param → config file → AWS_DEFAULT_REGION → AWS_REGION`. Remove all hardcoded region fallbacks. If no region found, raise clear error.
- **Lesson:** Never hardcode AWS regions. Use the standard resolution chain. Every hardcoded region is a bug for users in other regions.

### P1-3: Bedrock model ID validation shows "--" instead of FAIL
- **Root cause:** Exception handler returns `INFO` status (renders as "--"), hiding the failure from users.
- **Fix:** Change from `INFO` to `WARN` so it renders as "!!" with visible messaging.
- **Lesson:** Diagnostic tools must never hide failures. `INFO`/`--` means "not applicable", not "failed but we're hiding it".

### P1-4: .mcp.json writes bare "graq" (3rd report)
- **Root cause:** `_resolve_graq_command()` falls back to `"graq"` when not found on PATH. Every Windows pip user hits this because `Scripts/` isn't on PATH by default.
- **Fix:** After exhausting PATH and common locations, derive path from `sys.executable` (the Python that's running graq right now). `Path(sys.executable).parent / "Scripts" / "graq.exe"` or `Path(sys.executable).parent / "graq"` will always work because pip installed graq alongside the current Python.
- **Lesson:** When your CLI is running, `sys.executable` is the one reliable anchor. Use it as the ultimate fallback.

### P1-5: Version string mismatch (0.19.0 vs 0.20.0)
- **Root cause:** `__version__.py` was not updated when pyproject.toml was bumped.
- **Fix:** Update `__version__.py` to `0.20.1`. Add to release checklist.
- **Lesson:** Version must be updated in BOTH pyproject.toml AND `__version__.py`. Consider single-sourcing from pyproject.toml using `importlib.metadata`.

### P1-6: graq init wrong defaults for Bedrock
- **Root cause:** Line 591 tries to use `api_key_ref` as region (fundamentally wrong). Line 959 defaults to `"us-east-1"`.
- **Fix:** For Bedrock: resolve region from `AWS_DEFAULT_REGION → AWS_REGION`, never from api_key_ref. For model: remove hardcoded default, prompt user to select from available models or provide a known-working default per region.

---

## Lessons Learned (Distilled)

| # | Lesson | Category | Priority |
|---|--------|----------|----------|
| 1 | Never hardcode AWS regions — use env var resolution chain | deploy | CRITICAL |
| 2 | Daemon threads are unsafe for file I/O on Windows | logic | CRITICAL |
| 3 | Diagnostic "--" must never hide failures — use WARN/FAIL | logic | HIGH |
| 4 | Use `sys.executable` as anchor for finding sibling executables | logic | HIGH |
| 5 | Version must be synced between pyproject.toml and __version__.py | build | HIGH |
| 6 | LLM init should DETECT → EXPLAIN → ASK, never silently default | logic | CRITICAL |
| 7 | Items reported 3x means systemic root cause, not one-off bug | logic | HIGH |
| 8 | One-time setup cost messaging converts better than silent defaults | logic | MEDIUM |

---

## Consequences

**Positive:**
- Every user gets a working LLM on first init (no silent misconfiguration)
- Windows users get reliable background scanning
- `graq doctor` becomes trustworthy (no hidden failures)
- MCP integration works out-of-the-box on Windows

**Negative:**
- `graq init` takes 30 seconds longer (user must answer LLM question)
- Cannot fully automate init in CI (must pass `--backend` flag explicitly)

**Trade-off accepted:** 30 seconds of user time during init prevents hours of debugging misconfigured backends. One-time cost, long-term savings.
