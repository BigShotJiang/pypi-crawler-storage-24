# ADR-112: Cloud Sync + Neptune Backend for Team Features (Upsell)

**Date:** 2026-03-14 | **Status:** ACCEPTED

---

## Context

Graqle's current architecture is local-first: JSON/NetworkX for single developers, with Neo4j auto-upgrade at 5,000 nodes. For the Team tier ($29/dev/mo), we need a shared, cloud-hosted graph that enables:

1. **Cross-developer knowledge sharing** — one team member teaches the graph, everyone benefits
2. **Cross-repo graphs** — connect microservice repos into a unified architecture view
3. **Persistent graph** — survives laptop wipes, onboarding new devs is instant
4. **Access control** — who can teach/modify vs. read-only

This is the upsell from Free/Pro (local-only) to Team (cloud-hosted).

## Decision

### Architecture: Graqle Cloud Gateway + Amazon Neptune

```
Developer A (local)          Developer B (local)
     │                              │
     ▼                              ▼
  graq sync push              graq sync pull
     │                              │
     ▼                              ▼
┌─────────────────────────────────────────┐
│       Graqle Cloud Gateway (Lambda)     │
│  - Auth (Cognito / API key)             │
│  - Team management                      │
│  - Sync protocol (delta-based)          │
│  - Rate limiting / billing              │
└──────────────┬──────────────────────────┘
               │
               ▼
┌─────────────────────────────────────────┐
│       Amazon Neptune (Serverless)        │
│  - Shared team graph                    │
│  - Gremlin/OpenCypher queries           │
│  - Cross-repo entity resolution         │
│  - Versioned graph snapshots            │
└─────────────────────────────────────────┘
```

### Sync Protocol

**Delta-based sync** — not full graph replication:

```
graq sync push    → sends only changed nodes/edges since last sync
graq sync pull    → receives only changes from team graph
graq sync status  → shows sync state (ahead/behind/in-sync)
graq sync resolve → interactive conflict resolution
```

**Sync state file:** `.graqle/sync-state.json`
```json
{
  "team_id": "team-copyforge",
  "last_push": "2026-03-14T10:00:00Z",
  "last_pull": "2026-03-14T09:55:00Z",
  "local_version": 47,
  "remote_version": 45,
  "status": "ahead_by_2"
}
```

### Conflict Resolution

When two developers modify the same node:
1. **Source priority** — Code > API spec > Config > Taught > Docs
2. **Timestamp** — newer wins for same-priority sources
3. **Manual** — `graq sync resolve` for ambiguous cases

### CLI Commands (Foundation)

```bash
# Team setup
graq team create <name>           # Create team, get team ID
graq team invite <email>          # Invite member
graq team members                 # List team members
graq team leave                   # Leave team

# Cloud sync
graq sync push                    # Push local changes to cloud
graq sync pull                    # Pull team changes locally
graq sync status                  # Show sync state
graq sync resolve                 # Resolve conflicts

# Cross-repo
graq link add <repo-url>          # Link another repo's graph
graq link list                    # Show linked repos
graq link merge                   # Merge linked graphs
```

### Neptune Schema

```gremlin
// Node properties
g.addV('Function').property('id', 'fn::auth.py::verify_token')
  .property('label', 'verify_token')
  .property('source_type', 'code')
  .property('team_id', 'team-copyforge')
  .property('repo', 'copyforge-backend')
  .property('updated_by', 'dev-alice')
  .property('updated_at', '2026-03-14T10:00:00Z')
  .property('version', 47)

// Cross-repo edges
g.addE('CALLS').from(V('fn::gateway::route_auth'))
  .to(V('fn::auth-service::verify_token'))
  .property('cross_repo', true)
```

### Pricing / Upsell Triggers

| Signal | Action |
|--------|--------|
| Graph > 500 nodes (Free limit) | "Upgrade to Pro for 5,000 nodes" |
| Graph > 5,000 nodes (Pro limit) | "Upgrade to Team for 50,000 nodes + cloud sync" |
| `graq sync push` on Free/Pro | "Cloud sync requires Team plan" |
| 2+ developers detected (git log) | "Share your graph with your team — graq team create" |
| Cross-repo link attempted | "Cross-repo graphs require Team plan" |

### Implementation Phases

| Phase | What | Sprint |
|-------|------|--------|
| 1. Foundation | `graq sync` CLI stubs, sync state file, delta computation | 1 |
| 2. Cloud Gateway | Lambda + API Gateway + Cognito auth | 2-3 |
| 3. Neptune Backend | Neptune Serverless setup, Gremlin adapter | 3-4 |
| 4. Sync Protocol | Push/pull/resolve, conflict detection | 4-5 |
| 5. Team Management | Create/invite/members/leave, permissions | 5-6 |
| 6. Cross-Repo | Link/merge across repos, entity resolution | 6-7 |

### Phase 1 Deliverables (Foundation — this sprint)

1. `graqle/cloud/__init__.py` — Cloud client stub
2. `graqle/cloud/sync.py` — Delta computation (what changed since last sync)
3. `graqle/cloud/team.py` — Team config management
4. `graqle/cli/commands/sync.py` — CLI commands (stubs that work locally)
5. `graqle/cli/commands/team.py` — Team CLI commands
6. `graqle/connectors/neptune.py` — Neptune adapter (extends existing upgrade.py)

## Consequences

**Positive:**
- Clear upgrade path: Free → Pro → Team
- Neptune Serverless = pay-per-query, no idle costs
- Delta sync = minimal bandwidth, works on slow connections
- Foundation code works locally first (can test without cloud infra)

**Negative:**
- Neptune Serverless has cold start latency (~5-10s first query)
- Sync conflicts in teaching (two devs teach conflicting facts)
- AWS vendor lock-in for Team tier

**Trade-off accepted:** Neptune Serverless is the best fit for variable team usage — no idle costs, scales to enterprise. Cold starts are acceptable since graph queries are not latency-critical.
