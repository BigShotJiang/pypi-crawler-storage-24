"""Domain models for frpdeck."""
