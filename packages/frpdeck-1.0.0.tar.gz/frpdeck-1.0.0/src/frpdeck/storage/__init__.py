"""Storage helpers."""
