"""Command registration helpers."""
