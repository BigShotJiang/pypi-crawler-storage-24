"""Service layer for frpdeck."""
