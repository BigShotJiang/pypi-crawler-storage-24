"""selfimprovingcode — Self-improving AI agent framework
Official package by Colin McNamara LLC. Namespace reservation.
"""
__version__ = "0.0.1"
__author__ = "Colin McNamara"
