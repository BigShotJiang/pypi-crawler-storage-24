# selfimprovingcode
> Self-improving AI agent framework
**Official package by Colin McNamara LLC.** Namespace reservation.
- Website: https://selfimprovingcode.ai
- License: Proprietary
