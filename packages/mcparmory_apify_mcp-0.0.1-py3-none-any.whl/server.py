"""MCP server for Apify API — placeholder."""

def main() -> None:
    print("mcparmory-apify-mcp: full server coming soon. See https://mcparmory.com")

if __name__ == "__main__":
    main()
