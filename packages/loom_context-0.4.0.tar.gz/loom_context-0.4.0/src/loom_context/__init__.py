"""Loom-Context: Architecture Context Engine for AI-First Engineering."""

__version__ = "0.4.0"
