#!/usr/bin/env node
/**
 * navigate_capture.js
 * 连接微信开发者工具自动化端口，跳转到指定页面，
 * 同时通过 CDP (Chromium DevTools Protocol) 采集高清日志，
 * 等待指定毫秒数后输出所有日志为 JSON。
 *
 * 用法：
 *   node navigate_capture.js --port <自动化端口> --page <页面路径> --wait <毫秒> [--cdp-port <CDP端口>]
 *
 * 示例：
 *   node navigate_capture.js --port 9420 --page /pages/index/index --wait 3000 --cdp-port 9222
 */

'use strict';

const automator = require('miniprogram-automator');
const WebSocket = require('./node_modules/ws');
const http = require('http');

function parseArgs(argv) {
    const args = { port: 9420, page: '', wait: 2000, cdpPort: 9222 };
    for (let i = 2; i < argv.length; i++) {
        switch (argv[i]) {
            case '--port':
                args.port = parseInt(argv[++i], 10);
                break;
            case '--page':
                args.page = argv[++i];
                break;
            case '--wait':
                args.wait = Math.min(Math.max(parseInt(argv[++i], 10), 100), 30000);
                break;
            case '--cdp-port':
                args.cdpPort = parseInt(argv[++i], 10);
                break;
        }
    }
    return args;
}

// ── CDP 日志采集 ──────────────────────────────────────────────

async function getCdpTargets(cdpPort) {
    return new Promise((resolve, reject) => {
        const req = http.get(`http://127.0.0.1:${cdpPort}/json/list`, (res) => {
            let data = '';
            res.on('data', (chunk) => data += chunk);
            res.on('end', () => {
                try { resolve(JSON.parse(data)); }
                catch (_) { resolve([]); }
            });
        });
        req.on('error', reject);
        req.end();
    });
}

function attachCdpTarget(target, logs, activeConnections) {
    if (activeConnections.has(target.id)) return;

    // 排除 IDE 自身 UI
    const isIdeUI = target.url && (
        target.url.startsWith('devtools://') ||
        target.url.startsWith('chrome-extension://') ||
        target.url === '微信开发者工具'
    );
    if (isIdeUI && target.type !== 'webview') return;

    activeConnections.set(target.id, true);

    try {
        const ws = new WebSocket(target.webSocketDebuggerUrl);

        ws.on('open', () => {
            ws.send(JSON.stringify({ id: 1, method: 'Console.enable' }));
            ws.send(JSON.stringify({ id: 2, method: 'Runtime.enable' }));
            ws.send(JSON.stringify({ id: 3, method: 'Log.enable' }));
        });

        ws.on('message', (data) => {
            try {
                const msg = JSON.parse(data);
                const method = msg.method;
                const params = msg.params;
                if (!method) return;

                if (method === 'Console.messageAdded') {
                    logs.push({
                        timestamp: new Date().toISOString(),
                        type: 'CONSOLE',
                        url: target.url,
                        targetType: target.type,
                        content: params.message,
                    });
                } else if (method === 'Runtime.consoleAPICalled') {
                    logs.push({
                        timestamp: new Date().toISOString(),
                        type: 'RUNTIME_CONSOLE',
                        url: target.url,
                        targetType: target.type,
                        content: {
                            type: params.type,
                            args: params.args.map(a => a.value || a.description || 'unserializable'),
                        },
                    });
                } else if (method === 'Runtime.exceptionThrown') {
                    logs.push({
                        timestamp: new Date().toISOString(),
                        type: 'EXCEPTION',
                        url: target.url,
                        targetType: target.type,
                        content: params.exceptionDetails,
                    });
                }
            } catch (_) { }
        });

        ws.on('close', () => activeConnections.delete(target.id));
        ws.on('error', () => activeConnections.delete(target.id));
    } catch (_) {
        activeConnections.delete(target.id);
    }
}

// ── 主流程 ────────────────────────────────────────────────────

async function main() {
    const args = parseArgs(process.argv);
    const { port, page, wait, cdpPort } = args;

    if (!page) {
        process.stdout.write(JSON.stringify({ success: false, error: '必须指定 --page 参数' }));
        process.exit(0);
        return;
    }

    const cdpLogs = [];
    const activeConnections = new Map();
    let currentPageInfo = null;
    let miniProgram = null;
    let cdpAvailable = false;

    // ── 1. 启动 CDP 日志采集（在跳转前开始监听）──────────────
    try {
        const targets = await getCdpTargets(cdpPort);
        if (targets.length > 0) {
            cdpAvailable = true;
            for (const target of targets) {
                attachCdpTarget(target, cdpLogs, activeConnections);
            }
        }
    } catch (_) {
        // CDP 不可用，后续仍可完成跳转
    }

    // 持续发现新 target（页面跳转后可能产生新 target）
    let discoveryInterval = null;
    if (cdpAvailable) {
        discoveryInterval = setInterval(async () => {
            try {
                const targets = await getCdpTargets(cdpPort);
                for (const target of targets) {
                    attachCdpTarget(target, cdpLogs, activeConnections);
                }
            } catch (_) { }
        }, 500);
    }

    // 给 CDP 连接一点时间建立
    if (cdpAvailable) {
        await new Promise(r => setTimeout(r, 300));
    }

    // ── 2. 通过 automator 跳转页面 ──────────────────────────
    try {
        miniProgram = await automator.connect({
            wsEndpoint: `ws://localhost:${port}`,
        });

        const pagePath = page.startsWith('/') ? page : `/${page}`;
        await miniProgram.reLaunch(pagePath);

        // 等待页面稳定 + CDP 采集日志
        await new Promise(r => setTimeout(r, wait));

        // 获取当前页面信息
        try {
            const currentPage = await miniProgram.currentPage();
            if (currentPage) {
                currentPageInfo = {
                    path: currentPage.path,
                    query: currentPage.query || {},
                };
            }
        } catch (_) { }

    } catch (err) {
        if (discoveryInterval) clearInterval(discoveryInterval);

        const output = {
            success: false,
            error: err.message || String(err),
            port,
            page,
            wait_ms: wait,
            cdp_port: cdpPort,
            cdp_available: cdpAvailable,
            current_page: currentPageInfo,
            cdp_logs: cdpLogs,
        };
        process.stdout.write(JSON.stringify(output, null, 2));
        process.exit(0);
        return;
    }

    // ── 3. 停止采集，输出结果 ────────────────────────────────
    if (discoveryInterval) clearInterval(discoveryInterval);

    const output = {
        success: true,
        port,
        page,
        wait_ms: wait,
        cdp_port: cdpPort,
        cdp_available: cdpAvailable,
        current_page: currentPageInfo,
        cdp_logs: cdpLogs,
    };
    process.stdout.write(JSON.stringify(output, null, 2));
    process.exit(0);
}

main().catch((err) => {
    process.stdout.write(JSON.stringify({ success: false, error: String(err) }, null, 2));
    process.exit(1);
});
