"""
Smoke tests for pymlpipeline package.
Run:  pytest tests/
"""
import sys
import types
import pytest
from pathlib import Path
from unittest.mock import patch, MagicMock


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _load_preprocessor():
    import pymlpipeline.preprocessor as pp
    return pp


def _load_model_builder():
    import pymlpipeline.model_builder as mb
    return mb


# ---------------------------------------------------------------------------
# 1. Import tests
# ---------------------------------------------------------------------------

class TestImports:
    def test_package_imports(self):
        import pymlpipeline
        assert pymlpipeline.__version__ == "1.0.0"

    def test_preprocessor_imports(self):
        pp = _load_preprocessor()
        assert hasattr(pp, "run_pipeline")
        assert hasattr(pp, "CFG")
        assert hasattr(pp, "ENV")

    def test_model_builder_imports(self):
        mb = _load_model_builder()
        assert hasattr(mb, "run_model_builder")
        assert hasattr(mb, "CFG")
        assert hasattr(mb, "ENV")

    def test_cli_imports(self):
        from pymlpipeline.cli import main, cmd_init, cmd_preprocess, cmd_build, cmd_predict
        assert callable(main)


# ---------------------------------------------------------------------------
# 2. Config singleton tests
# ---------------------------------------------------------------------------

class TestConfig:
    def test_empty_config(self):
        pp = _load_preprocessor()
        cfg = pp._Config()
        assert cfg.s("pipeline", "data_source") is None
        assert cfg.g("missing", "key", default="fallback") == "fallback"

    def test_config_load_valid(self, tmp_path):
        yaml_file = tmp_path / "test.yaml"
        yaml_file.write_text(
            "pipeline:\n  data_source: demo\n  auto_mode: true\n"
        )
        pp = _load_preprocessor()
        cfg = pp._Config()
        cfg.load(str(yaml_file))
        assert cfg.s("pipeline", "data_source") == "demo"
        assert cfg.b("pipeline", "auto_mode") is True

    def test_config_load_missing_file(self):
        pp = _load_preprocessor()
        cfg = pp._Config()
        cfg.load("/nonexistent/path/config.yaml")
        # Should warn but not crash; dict stays empty
        assert cfg._d == {}

    def test_auto_mode_flag(self, tmp_path):
        yaml_file = tmp_path / "auto.yaml"
        yaml_file.write_text("pipeline:\n  auto_mode: true\n")
        pp = _load_preprocessor()
        cfg = pp._Config()
        cfg.load(str(yaml_file))
        assert cfg.auto is True


# ---------------------------------------------------------------------------
# 3. Environment detection tests
# ---------------------------------------------------------------------------

class TestEnvironment:
    def test_env_resolve_local_no_libs(self):
        pp = _load_preprocessor()
        env = pp._Env()
        # In test environment with no GCP libs, should resolve to local
        env.has_bq  = False
        env.has_gcs = False
        env.has_adc = False
        env.on_gcp_vm = False
        assert env.resolve() == "local"

    def test_env_resolve_gcp_with_libs(self):
        pp = _load_preprocessor()
        env = pp._Env()
        env.has_bq  = True
        env.has_adc = True
        env.on_gcp_vm = False
        assert env.resolve() == "gcp"

    def test_env_resolve_forced_local(self, tmp_path, monkeypatch):
        yaml_file = tmp_path / "local.yaml"
        yaml_file.write_text("pipeline:\n  environment: local\n")
        pp = _load_preprocessor()
        pp.CFG.load(str(yaml_file))
        env = pp._Env()
        env.has_bq = True
        env.has_adc = True   # even with GCP available
        assert env.resolve() == "local"
        pp.CFG._d = {}  # cleanup

    def test_env_resolve_forced_gcp(self, tmp_path):
        yaml_file = tmp_path / "gcp.yaml"
        yaml_file.write_text("pipeline:\n  environment: gcp\n")
        pp = _load_preprocessor()
        pp.CFG.load(str(yaml_file))
        env = pp._Env()
        assert env.resolve() == "gcp"
        pp.CFG._d = {}  # cleanup


# ---------------------------------------------------------------------------
# 4. Data loading — local CSV tests
# ---------------------------------------------------------------------------

class TestLocalCSVLoader:
    def test_load_csv_basic(self, tmp_path):
        import pandas as pd
        csv = tmp_path / "data.csv"
        csv.write_text("a,b,c\n1,2,3\n4,5,6\n")
        pp = _load_preprocessor()
        pp.CFG._d = {
            "pipeline": {"auto_mode": True},
            "local": {"csv_path": str(csv), "separator": ",", "encoding": "utf-8"}
        }
        log = pp.Log()
        df = pp._load_local_csv(log)
        assert df.shape == (2, 3)
        assert list(df.columns) == ["a", "b", "c"]
        pp.CFG._d = {}

    def test_load_csv_folder(self, tmp_path):
        import pandas as pd
        (tmp_path / "data.csv").write_text("x,y\n1,2\n3,4\n")
        pp = _load_preprocessor()
        pp.CFG._d = {
            "pipeline": {"auto_mode": True},
            "local": {"csv_path": "", "csv_folder": str(tmp_path),
                      "separator": ",", "encoding": "utf-8"}
        }
        log = pp.Log()
        df = pp._load_local_csv(log)
        assert df.shape == (2, 2)
        pp.CFG._d = {}

    def test_load_csv_missing_raises(self, tmp_path):
        pp = _load_preprocessor()
        pp.CFG._d = {
            "pipeline": {"auto_mode": True},
            "local": {"csv_path": str(tmp_path / "nonexistent.csv"),
                      "separator": ",", "encoding": "utf-8"}
        }
        log = pp.Log()
        with pytest.raises(FileNotFoundError):
            pp._load_local_csv(log)
        pp.CFG._d = {}


# ---------------------------------------------------------------------------
# 5. Demo data test
# ---------------------------------------------------------------------------

class TestDemoData:
    def test_load_demo_shape(self):
        pp = _load_preprocessor()
        df = pp._load_demo()
        assert df.shape[0] > 600
        assert "churn" in df.columns
        assert "customer_id" in df.columns

    def test_load_demo_has_nulls(self):
        import pandas as pd
        pp = _load_preprocessor()
        df = pp._load_demo()
        assert df.isnull().sum().sum() > 0   # intentional nulls in demo data


# ---------------------------------------------------------------------------
# 6. Model builder catalog tests
# ---------------------------------------------------------------------------

class TestModelCatalog:
    def test_classification_catalog_size(self):
        mb = _load_model_builder()
        assert len(mb.CLASSIFICATION_MODELS) >= 30

    def test_regression_catalog_size(self):
        mb = _load_model_builder()
        assert len(mb.REGRESSION_MODELS) >= 20

    def test_clustering_catalog_size(self):
        mb = _load_model_builder()
        assert len(mb.CLUSTERING_MODELS) >= 20

    def test_all_classification_models_instantiable(self):
        mb = _load_model_builder()
        for name, model in mb.CLASSIFICATION_MODELS.items():
            assert model is not None, f"{name} is None"
            assert hasattr(model, "fit"),     f"{name} has no .fit()"
            assert hasattr(model, "predict"), f"{name} has no .predict()"

    def test_all_regression_models_instantiable(self):
        mb = _load_model_builder()
        for name, model in mb.REGRESSION_MODELS.items():
            assert hasattr(model, "fit"),     f"{name} has no .fit()"
            assert hasattr(model, "predict"), f"{name} has no .predict()"

    def test_optional_libs_handled_gracefully(self):
        """Catalog builds without error even if xgboost/lightgbm/catboost are missing."""
        mb = _load_model_builder()
        clf, reg, clu = mb._build_model_catalogs()
        assert isinstance(clf, dict)
        assert isinstance(reg, dict)
        assert isinstance(clu, dict)


# ---------------------------------------------------------------------------
# 7. CLI tests
# ---------------------------------------------------------------------------

class TestCLI:
    def test_init_copies_config(self, tmp_path, monkeypatch):
        monkeypatch.chdir(tmp_path)
        from pymlpipeline.cli import cmd_init
        args = MagicMock(); args.force = False
        cmd_init(args)
        assert (tmp_path / "pipeline_config.yaml").exists()

    def test_init_no_overwrite(self, tmp_path, monkeypatch, capsys):
        monkeypatch.chdir(tmp_path)
        (tmp_path / "pipeline_config.yaml").write_text("existing: true\n")
        from pymlpipeline.cli import cmd_init
        args = MagicMock(); args.force = False
        cmd_init(args)
        captured = capsys.readouterr()
        assert "already exists" in captured.out

    def test_init_force_overwrite(self, tmp_path, monkeypatch):
        monkeypatch.chdir(tmp_path)
        (tmp_path / "pipeline_config.yaml").write_text("old: true\n")
        from pymlpipeline.cli import cmd_init
        args = MagicMock(); args.force = True
        cmd_init(args)
        content = (tmp_path / "pipeline_config.yaml").read_text()
        assert "old: true" not in content   # was overwritten

    def test_version_string(self):
        from pymlpipeline.cli import _get_version
        v = _get_version()
        assert v == "1.0.0"

    def test_main_no_args_exits(self):
        from pymlpipeline.cli import main
        with pytest.raises(SystemExit):
            with patch("sys.argv", ["pymlpipeline"]):
                main()


# ---------------------------------------------------------------------------
# 8. Full pipeline smoke test (demo mode, no GCP)
# ---------------------------------------------------------------------------

class TestPipelineSmoke:
    def test_preprocessor_demo_end_to_end(self, tmp_path, monkeypatch):
        """Run the full preprocessor pipeline on demo data in auto_mode=True."""
        import pymlpipeline.preprocessor as pp
        import yaml

        cfg_data = {
            "pipeline": {
                "environment":    "local",
                "data_source":    "demo",
                "save_to_gcs":    False,
                "auto_mode":      True,
                "target_column":  "churn",
                "identifier_columns": ["customer_id"],
                "keyword_drop_terms": ["snapshot","constant","mostly"],
                "high_null_threshold": 50.0,
                "remove_duplicates": True,
                "low_variance_threshold": 99.0,
                "impute_numeric":    "median",
                "impute_categorical":"mode",
                "handle_outliers":  True,
                "outlier_method":   "iqr",
                "outlier_action":   "clip",
                "corr_low_threshold":  0.01,
                "corr_high_threshold": 0.95,
                "encoding_method":  "onehot",
                "encoding_cardinality_limit": 20,
                "normalise":        True,
                "normalise_method": "standard",
                "model_type":       "classification",
            },
            "output": {"dataset_id":"","table_id":""},
        }

        cfg_path = tmp_path / "test_config.yaml"
        cfg_path.write_text(yaml.dump(cfg_data))

        # Change working dir so local outputs land in tmp
        monkeypatch.chdir(tmp_path)

        pp.CFG.load(str(cfg_path))
        df_out, df_ids, report_path = pp.run_pipeline()

        assert df_out.shape[0] > 0,       "Output dataframe is empty"
        assert df_out.shape[1] > 0,       "Output has no columns"
        assert Path(report_path).exists(), "Word report not created"

        # Cleanup CFG
        pp.CFG._d = {}
