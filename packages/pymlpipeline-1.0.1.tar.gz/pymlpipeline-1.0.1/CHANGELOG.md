# Changelog

All notable changes to this project will be documented in this file.  
Format follows [Keep a Changelog](https://keepachangelog.com/en/1.0.0/).

---

## [1.0.0] — 2026-03-21

### Added
- `pymlpipeline preprocess` — full data cleaning & preprocessing pipeline
  - BigQuery (4 query modes), local CSV, and demo data sources
  - Column profile CSV uploaded to GCS before target selection
  - Target leakage check, stratified reload, identifier sidecar
  - Keyword drop, high-null drop, dtype normalisation, imputation, outlier handling
  - EDA charts, correlation filter, one-hot/label encoding, normalisation
  - Word (.docx) preprocessing report
  - BigQuery output write + GCS upload of all artefacts

- `pymlpipeline build` — ML model training & evaluation
  - 81 models: 33 classifiers, 25 regressors, 23 clustering algorithms
  - Optional: XGBoost, LightGBM, CatBoost (auto-detected at runtime)
  - 5-method feature importance (MI, F-stat, RF, Permutation, RFE)
  - Correlation-based top-N feature selection
  - Full evaluation metrics: AUC-ROC, PR curve, MCC, Kappa, Log-Loss, Brier, calibration
  - Per-model charts: confusion matrix, ROC, PR, learning curve, CV violin, calibration, prob histogram
  - Multi-model comparison: bar chart + radar chart
  - Word (.docx) model evaluation report
  - AI-generated training script via Gemini 2.5 Pro on Vertex AI (ADC, no API key)
  - `best_model.pkl` + `predict.py` saved alongside model PKLs

- `pymlpipeline predict` — standalone prediction
  - Reads from local CSV, GCS, or BigQuery
  - Applies same preprocessing (scaler.pkl)
  - Outputs class labels + per-class probabilities

- `pymlpipeline init` — copies default `pipeline_config.yaml` to CWD

- Environment auto-detection (`auto | gcp | local`)
  - Probes BigQuery, GCS, ADC, GCP VM metadata server
  - Falls back to local mode gracefully when GCP libraries are absent
  - Clear install hints shown when GCP features are not available

- Single shared `pipeline_config.yaml` for all three tools
