#!/usr/bin/env python3
"""
pymlpipeline — Command-Line Interface
====================================
Entry point registered as the `pymlpipeline` command.

Sub-commands
------------
  init        Copy default pipeline_config.yaml to the current directory
  preprocess  Run the data cleaning & preprocessing pipeline
  build       Train, evaluate and compare ML models
  predict     Score new data using a saved model + scaler

Examples
--------
  pymlpipeline init
  pymlpipeline preprocess --config pipeline_config.yaml
  pymlpipeline build      --config pipeline_config.yaml
  pymlpipeline predict \\
      --model  ml_model_output/2026-03-21/models/best_model.pkl \\
      --scaler ml_model_output/2026-03-21/models/scaler.pkl \\
      --data   new_customers.csv
  pymlpipeline predict --model best_model.pkl --scaler scaler.pkl \\
      --bq my-project.dataset.table
  pymlpipeline predict --model best_model.pkl --scaler scaler.pkl \\
      --gcs gs://bucket/path/new_data.csv
"""

import argparse
import sys
import shutil
from pathlib import Path


def cmd_init(args):
    """Copy the bundled default config to the current working directory."""
    src = Path(__file__).parent / "config" / "pipeline_config.yaml"
    dst = Path.cwd() / "pipeline_config.yaml"
    if dst.exists() and not args.force:
        print(f"⚠  {dst} already exists.  Use --force to overwrite.")
        return
    shutil.copy2(src, dst)
    print(f"✔  pipeline_config.yaml written to {dst}")
    print(f"\n   Edit it for your environment, then run:")
    print(f"   pymlpipeline preprocess --config pipeline_config.yaml")


def cmd_preprocess(args):
    """Run the full preprocessing pipeline."""
    from pymlpipeline.preprocessor import CFG, run_pipeline, ENV
    CFG.load(args.config)
    from pymlpipeline.preprocessor import _banner, _Env
    _banner("Configuration Summary")
    CFG.print_summary()
    ENV.print_summary()
    run_pipeline()


def cmd_build(args):
    """Train and evaluate ML models."""
    from pymlpipeline.model_builder import CFG, run_model_builder
    CFG.load(args.config)
    run_model_builder()


def cmd_predict(args):
    """Run predictions on new data."""
    import pickle
    import warnings
    import numpy as np
    import pandas as pd
    from pathlib import Path
    from datetime import datetime

    warnings.filterwarnings("ignore")

    # Load model and scaler
    print(f"Loading model  : {args.model}")
    with open(args.model, "rb") as f:
        model = pickle.load(f)
    print(f"Loading scaler : {args.scaler}")
    with open(args.scaler, "rb") as f:
        scaler = pickle.load(f)

    # Load data
    if args.bq:
        project = args.project or args.bq.split(".")[0]
        from google.cloud import bigquery
        client = bigquery.Client(project=project)
        q = args.bq_query or f"SELECT * FROM `{args.bq.replace('.', '`.`', 2)}`"
        print(f"Querying BigQuery: {q[:80]}")
        df = client.query(q).to_dataframe()
    elif args.gcs:
        from google.cloud import storage as gcs
        uri = args.gcs[len("gs://"):]
        bucket, _, blob = uri.partition("/")
        tmp = Path(f"/tmp/pymlpipeline_predict_{datetime.now():%H%M%S}.csv")
        gcs.Client().bucket(bucket).blob(blob).download_to_filename(str(tmp))
        df = pd.read_csv(str(tmp))
    elif args.data:
        df = pd.read_csv(args.data)
    else:
        print("ERROR: Provide one of --data, --gcs, or --bq")
        sys.exit(1)

    print(f"Loaded: {df.shape[0]:,} rows × {df.shape[1]} cols")

    # Basic preprocessing to match training
    obj_cols = df.select_dtypes(exclude=[np.number]).columns
    for col in obj_cols:
        conv = pd.to_numeric(df[col], errors="coerce")
        if conv.notna().sum() / max(df[col].notna().sum(), 1) >= 0.95:
            df[col] = conv
    df = df.select_dtypes(include=[np.number]).fillna(df.median(numeric_only=True))

    # Scale and predict
    X = pd.DataFrame(scaler.transform(df.astype(float)), columns=df.columns)
    y_pred = model.predict(X)

    out = pd.DataFrame({"prediction": y_pred})
    if hasattr(model, "predict_proba"):
        try:
            proba = model.predict_proba(X)
            for i, cls in enumerate(model.classes_):
                out[f"prob_{cls}"] = proba[:, i]
        except Exception:
            pass

    ts  = datetime.now().strftime("%Y-%m-%d_%H-%M-%S")
    out_path = args.out or f"predictions_{ts}.csv"
    out.to_csv(out_path, index=False)
    print(f"✔  Predictions saved: {out_path}  ({len(out):,} rows)")
    print(f"   Distribution: {dict(pd.Series(y_pred).value_counts())}")


def main():
    parser = argparse.ArgumentParser(
        prog="pymlpipeline",
        description="End-to-End ML Pipeline — GCP + Local",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog=__doc__,
    )
    parser.add_argument("--version", action="version",
                        version=f"%(prog)s {_get_version()}")

    sub = parser.add_subparsers(dest="command", metavar="<command>")
    sub.required = True

    # ── init ──────────────────────────────────────────────────────────────────
    p_init = sub.add_parser("init",
        help="Copy default pipeline_config.yaml to current directory")
    p_init.add_argument("--force", action="store_true",
        help="Overwrite if pipeline_config.yaml already exists")
    p_init.set_defaults(func=cmd_init)

    # ── preprocess ────────────────────────────────────────────────────────────
    p_pre = sub.add_parser("preprocess",
        help="Run data cleaning & preprocessing pipeline",
        aliases=["pp", "prep"])
    p_pre.add_argument("--config", "-c", default="pipeline_config.yaml",
        help="Path to pipeline_config.yaml  (default: ./pipeline_config.yaml)")
    p_pre.set_defaults(func=cmd_preprocess)

    # ── build ─────────────────────────────────────────────────────────────────
    p_bld = sub.add_parser("build",
        help="Train, evaluate and compare ML models",
        aliases=["train", "model"])
    p_bld.add_argument("--config", "-c", default="pipeline_config.yaml",
        help="Path to pipeline_config.yaml  (default: ./pipeline_config.yaml)")
    p_bld.set_defaults(func=cmd_build)

    # ── predict ───────────────────────────────────────────────────────────────
    p_prd = sub.add_parser("predict",
        help="Score new data with a saved model",
        aliases=["score", "infer"])
    p_prd.add_argument("--model",    required=True,
        help="Path to trained model .pkl")
    p_prd.add_argument("--scaler",   required=True,
        help="Path to scaler .pkl")
    p_prd.add_argument("--data",     default="",
        help="Local CSV file path")
    p_prd.add_argument("--gcs",      default="",
        help="GCS URI:  gs://bucket/path/data.csv")
    p_prd.add_argument("--bq",       default="",
        help="BigQuery: project.dataset.table")
    p_prd.add_argument("--bq_query", default="",
        help="Custom BigQuery SQL query (overrides --bq table scan)")
    p_prd.add_argument("--project",  default="",
        help="GCP project ID for BigQuery auth")
    p_prd.add_argument("--out",      default="",
        help="Output CSV path  (default: predictions_<timestamp>.csv)")
    p_prd.set_defaults(func=cmd_predict)

    args = parser.parse_args()
    args.func(args)


def _get_version():
    try:
        from pymlpipeline import __version__
        return __version__
    except Exception:
        return "unknown"


if __name__ == "__main__":
    main()
