#!/usr/bin/env python3
"""
ML Model Builder — GCP Edition
================================
Reads the processed output CSV produced by ml_preprocessor_gcp.py,
trains selected ML models, evaluates them, generates a detailed Word
report, and saves everything (models, encoders, report, charts) to
a GCS bucket or local folder.

Usage:
    python ml_model_builder.py --config pipeline_config.yaml
    python ml_model_builder.py                  # fully interactive
"""

import os, sys, io, warnings, textwrap, tempfile, argparse, shutil, pickle, json
from datetime import datetime
from pathlib import Path

try:
    import yaml
    _YAML_OK = True
except ImportError:
    _YAML_OK = False

import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import seaborn as sns
warnings.filterwarnings("ignore")

from sklearn.model_selection import (
    train_test_split, StratifiedKFold, KFold, cross_val_score
)
from sklearn.preprocessing import StandardScaler, LabelEncoder
from sklearn.pipeline import Pipeline
from sklearn.metrics import (
    # Classification
    accuracy_score, precision_score, recall_score, f1_score,
    roc_auc_score, confusion_matrix, classification_report,
    roc_curve, precision_recall_curve, average_precision_score,
    # Regression
    mean_absolute_error, mean_squared_error, r2_score,
    mean_absolute_percentage_error,
    # Clustering
    silhouette_score, calinski_harabasz_score, davies_bouldin_score,
)
from sklearn.feature_selection import (
    SelectKBest, RFE, mutual_info_classif, mutual_info_regression,
    f_classif, f_regression,
)
from sklearn.inspection import permutation_importance

# Classification models
from sklearn.linear_model import LogisticRegression
from sklearn.tree import DecisionTreeClassifier
from sklearn.ensemble import (
    RandomForestClassifier, GradientBoostingClassifier,
    AdaBoostClassifier, ExtraTreesClassifier
)
from sklearn.svm import SVC
from sklearn.neighbors import KNeighborsClassifier
from sklearn.naive_bayes import GaussianNB
from sklearn.neural_network import MLPClassifier

# Regression models
from sklearn.linear_model import Ridge, Lasso, ElasticNet, LinearRegression
from sklearn.tree import DecisionTreeRegressor
from sklearn.ensemble import (
    RandomForestRegressor, GradientBoostingRegressor,
    AdaBoostRegressor, ExtraTreesRegressor
)
from sklearn.svm import SVR
from sklearn.neighbors import KNeighborsRegressor
from sklearn.neural_network import MLPRegressor

# Clustering models
from sklearn.cluster import KMeans, DBSCAN, AgglomerativeClustering
from sklearn.mixture import GaussianMixture

# Word report
from docx import Document
from docx.shared import Inches, Pt, RGBColor, Emu
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.oxml.ns import qn
from docx.oxml import OxmlElement

# ── Terminal colours ──────────────────────────────────────────────────────────
C  = "\033[96m"; G = "\033[92m"; Y = "\033[93m"
R  = "\033[91m"; B = "\033[1m";  RST = "\033[0m"

def _banner(t): print(f"\n{B}{C}{'='*62}\n  {t}\n{'='*62}{RST}")
def _ok(t):     print(f"  {G}✔  {t}{RST}")
def _warn(t):   print(f"  {Y}⚠  {t}{RST}")
def _info(t):   print(f"  {C}➤  {t}{RST}")
def _step(t):   print(f"  {B}{t}{RST}")

# ── Staging dir ───────────────────────────────────────────────────────────────
STAGING = Path(tempfile.mkdtemp(prefix="ml_models_"))

# =============================================================================
# CONFIG SINGLETON
# =============================================================================
class _Config:
    def __init__(self): self._d = {}

    def load(self, path: str) -> None:
        if not path: return
        if not _YAML_OK: _warn("PyYAML not installed."); return
        p = Path(path)
        if not p.exists(): _warn(f"Config not found: {path}"); return
        try:
            with open(p) as f: self._d = yaml.safe_load(f) or {}
            _ok(f"Config loaded: {path}")
        except Exception as e:
            _warn(f"YAML error: {e}"); self._d = {}

    def g(self, *keys, default=None):
        node = self._d
        for k in keys:
            if not isinstance(node, dict) or k not in node: return default
            node = node[k]
        if node is None or node == "" or node == []: return default
        return node

    def s(self, *keys) -> str | None:
        v = self.g(*keys)
        return str(v).strip() if v is not None else None

    def b(self, *keys, default=None) -> bool | None:
        v = self.g(*keys)
        return bool(v) if v is not None else default

    def f(self, *keys, default=None) -> float | None:
        v = self.g(*keys)
        try:    return float(v) if v is not None else default
        except: return default

    def i(self, *keys, default=None) -> int | None:
        v = self.g(*keys)
        try:    return int(v) if v is not None else default
        except: return default

    def lst(self, *keys) -> list | None:
        v = self.g(*keys)
        return [str(x) for x in v] if isinstance(v, list) else None

    @property
    def auto(self) -> bool:
        return bool(self.g("pipeline","auto_mode", default=False))


CFG = _Config()

# =============================================================================
# ENVIRONMENT DETECTION  (shared with ml_preprocessor_gcp.py)
# =============================================================================
class _Env:
    def __init__(self):
        self.has_bq     = False
        self.has_gcs    = False
        self.has_auth   = False
        self.has_vertex = False
        for lib, attr in [("google.cloud.bigquery","has_bq"),
                           ("google.cloud.storage","has_gcs"),
                           ("google.auth","has_auth"),
                           ("vertexai","has_vertex")]:
            try: __import__(lib); setattr(self,attr,True)
            except ImportError: pass
        self.has_adc = False
        self.on_gcp_vm = False
        if self.has_auth:
            try:
                import google.auth
                google.auth.default(); self.has_adc = True
            except Exception: pass
        try:
            import urllib.request
            req = urllib.request.Request(
                "http://metadata.google.internal/computeMetadata/v1/project/project-id",
                headers={"Metadata-Flavor":"Google"}, method="GET")
            with urllib.request.urlopen(req, timeout=1):
                self.on_gcp_vm = True
        except Exception: pass

    def resolve(self) -> str:
        cfg = CFG.s("pipeline","environment") or "auto"
        if cfg == "gcp":   return "gcp"
        if cfg == "local": return "local"
        return "gcp" if (self.has_bq or self.has_gcs) and (self.has_adc or self.on_gcp_vm) else "local"

    def print_summary(self):
        mode = self.resolve()
        print(f"\n  {B}Environment:{RST}  "
              f"{'GCP' if mode=='gcp' else 'LOCAL'}  "
              f"({'BigQuery + GCS available' if mode=='gcp' else 'local files only'})")
        if mode == "local":
            missing = []
            if not self.has_bq:  missing.append("google-cloud-bigquery")
            if not self.has_gcs: missing.append("google-cloud-storage")
            if missing:
                print(f"  {Y}To enable GCP: pip install {' '.join(missing)}")
                print(f"                 gcloud auth application-default login{RST}")


ENV = _Env()

# =============================================================================
def _ask(prompt: str, default: str = "") -> str:
    v = input(f"\n  {B}{prompt}{RST} [{default}]: ").strip()
    return v if v else default

def _confirm(prompt: str, default: bool = True) -> bool:
    sfx = "[Y/n]" if default else "[y/N]"
    r = input(f"\n  {B}{prompt} {sfx}{RST}: ").strip().lower()
    if not r: return default
    return r in ("y","yes")

def _menu(question: str, options: list, default: str = "1",
          multi: bool = False) -> list | str:
    """Show numbered menu. If multi=True, allow comma-separated picks."""
    print(f"\n  {B}{question}{RST}")
    for i, o in enumerate(options, 1):
        print(f"    {C}{i}.{RST} {o}")
    if multi:
        print(f"    {Y}(comma-separated for multiple, e.g. 1,3,4){RST}")
        r = input(f"\n  Choice [{default}]: ").strip() or default
        picks = []
        for tok in r.split(","):
            tok = tok.strip()
            if tok.isdigit() and 1 <= int(tok) <= len(options):
                picks.append(options[int(tok)-1])
        return picks if picks else [options[0]]
    else:
        r = input(f"\n  Choice [{default}]: ").strip() or default
        if r.isdigit() and 1 <= int(r) <= len(options):
            return options[int(r)-1]
        return options[0]

# =============================================================================
# GCS HELPERS
# =============================================================================
def _gcs_put(local: str, blob: str, bucket: str) -> str:
    try:
        from google.cloud import storage
        b = storage.Client().bucket(bucket)
        b.blob(blob).upload_from_filename(local)
        uri = f"gs://{bucket}/{blob}"
        _ok(f"Uploaded: {uri}")
        return uri
    except Exception as e:
        _warn(f"GCS upload failed: {e}"); return ""

def _save_all(files: dict, gcs_bucket: str, gcs_folder: str,
              local_dir: Path) -> None:
    """
    files: {local_path: subfolder_name}
    GCS upload is skipped in local mode or when gcs_bucket is empty.
    """
    env_mode = ENV.resolve()
    for local_path, subfolder in files.items():
        if not Path(local_path).exists():
            _warn(f"File not found: {local_path}"); continue
        fname = Path(local_path).name
        if gcs_bucket and env_mode == "gcp":
            blob = f"{gcs_folder}/{subfolder}/{fname}"
            _gcs_put(local_path, blob, gcs_bucket)
        dest_dir = local_dir / subfolder
        dest_dir.mkdir(parents=True, exist_ok=True)
        shutil.copy2(local_path, dest_dir / fname)
        _ok(f"Saved: {dest_dir/fname}")

# =============================================================================
# STEP 1 — DATA LOADING  (BigQuery primary → GCS → local → interactive)
# =============================================================================

def _load_from_bigquery(project: str, dataset: str, table: str,
                         query_override: str = "") -> "pd.DataFrame":
    """
    Load the processed output table from BigQuery using ADC — no API key.
    Normalises all nullable extension types (Int64, Float64, boolean, StringDtype)
    to plain numpy dtypes so sklearn and downstream pandas ops work correctly.
    """
    try:
        from google.cloud import bigquery
    except ImportError:
        raise ImportError(
            "google-cloud-bigquery not installed.\n"
            "Fix: pip install google-cloud-bigquery db-dtypes"
        )

    client = bigquery.Client(project=project)
    full   = f"`{project}.{dataset}.{table}`"

    if query_override:
        query = query_override.strip()
        _ok(f"BQ custom query ({len(query)} chars)")
    else:
        query = f"SELECT * FROM {full}"

    _step(f"Query: {query}")

    # Optional: show row count before fetch
    try:
        tbl_ref = client.get_table(f"{project}.{dataset}.{table}")
        _ok(f"BQ table: ~{tbl_ref.num_rows:,} rows × {len(tbl_ref.schema)} cols")
    except Exception:
        pass

    df = client.query(query).to_dataframe()

    # Normalise BigQuery nullable extension types → standard numpy dtypes
    for col in df.columns:
        dt = df[col].dtype
        if hasattr(dt, "numpy_dtype"):
            kind = dt.numpy_dtype.kind
            if kind in ("i", "u"):
                df[col] = df[col].astype("float64" if df[col].isnull().any() else "int64")
            elif kind == "f":
                df[col] = df[col].astype("float64")
        elif isinstance(dt, pd.BooleanDtype):
            df[col] = df[col].astype("object")
        elif isinstance(dt, pd.StringDtype):
            df[col] = df[col].astype("object")

    return df


def _download_from_gcs(gcs_uri: str, local_dest: "Path") -> "Path":
    """
    Download gs://bucket/blob  to  local_dest.
    Requires google-cloud-storage.
    """
    without_prefix = gcs_uri[len("gs://"):]
    bucket_name, _, blob_path = without_prefix.partition("/")
    _step(f"Downloading: {gcs_uri}")
    try:
        from google.cloud import storage
        b = storage.Client().bucket(bucket_name).blob(blob_path)
        local_dest.parent.mkdir(parents=True, exist_ok=True)
        b.download_to_filename(str(local_dest))
        _ok(f"Downloaded: {local_dest}")
        return local_dest
    except ImportError:
        raise ImportError("google-cloud-storage not installed. "
                          "Fix: pip install google-cloud-storage")
    except Exception as e:
        raise RuntimeError(f"GCS download failed for {gcs_uri}: {e}") from e


def _find_latest_gcs_csv(bucket: str, base_folder: str) -> "str | None":
    """
    List bucket/base_folder and return the URI of the most recent
    .../output/processed_output.csv written by ml_preprocessor_gcp.py.
    """
    try:
        from google.cloud import storage
        prefix  = f"{base_folder.strip('/')}/" if base_folder else ""
        blobs   = list(storage.Client().list_blobs(bucket, prefix=prefix))
        matches = [b.name for b in blobs
                   if b.name.endswith("/output/processed_output.csv")]
        if not matches:
            return None
        uri = f"gs://{bucket}/{sorted(matches)[-1]}"
        _ok(f"Latest GCS CSV: {uri}")
        return uri
    except Exception as e:
        _warn(f"GCS auto-detect failed: {e}")
        return None


def _load_data(log: dict):
    """
    Load the processed dataset written by ml_preprocessor_gcp.py.

    Source resolution order  (first match wins):
    ──────────────────────────────────────────────────────────────────────────
    1. BigQuery  (RECOMMENDED — primary source)
       Config keys (all three required):
         model.bq_source_project   or  output.project_id  or  bigquery.project_id
         model.bq_source_dataset   or  output.dataset_id
         model.bq_source_table     or  output.table_id
       Optional:
         model.bq_source_query  — full SELECT override

    2. GCS explicit URI
         model.processed_csv: "gs://bucket/path/processed_output.csv"

    3. GCS auto-detect
       Lists gcs.bucket / gcs.base_folder for the latest preprocessor run folder
       (.../output/processed_output.csv) and downloads it.

    4. Local auto-detect
       Scans ./ml_pipeline_output/*/output/processed_output.csv

    5. Interactive prompt  (only when auto_mode: false)
       Accepts:  project.dataset.table  |  gs://...  |  /local/path
    ──────────────────────────────────────────────────────────────────────────
    Returns (df, target, id_cols, model_type, class_label_backup)
    """
    _banner("STEP 1 · Load Processed Data  (BigQuery → GCS → Local)")

    env_mode = ENV.resolve()

    # ── Config values ─────────────────────────────────────────────────────────
    bq_project = (CFG.s("model","bq_source_project") or
                  CFG.s("output","project_id")        or
                  CFG.s("bigquery","project_id")       or "")
    bq_dataset = (CFG.s("model","bq_source_dataset")  or
                  CFG.s("output","dataset_id")          or "")
    bq_table   = (CFG.s("model","bq_source_table")    or
                  CFG.s("output","table_id")            or "")
    bq_query   =  CFG.s("model","bq_source_query")    or ""

    cfg_csv    = CFG.s("model","processed_csv")  or ""
    # Local mode: also check local.csv_path
    if not cfg_csv and env_mode == "local":
        cfg_csv = CFG.s("local","csv_path") or ""

    gcs_bucket = CFG.s("gcs","bucket")           or ""
    gcs_base   = (CFG.s("gcs","base_folder")     or "").strip("/")

    df           = None
    data_source  = ""

    # ── Strategy 1: BigQuery (GCP mode only) ─────────────────────────────────
    have_bq = bool(bq_project and bq_dataset and bq_table)
    if env_mode == "local" and (have_bq or bq_query):
        _warn("BigQuery source configured but running in LOCAL mode — skipping BQ.")
        _info("To use BigQuery: pip install google-cloud-bigquery + gcloud auth application-default login")
    elif have_bq or bq_query:
        _ok(f"BigQuery source  : {bq_project}.{bq_dataset}.{bq_table}"
            if have_bq else "BigQuery (custom query)")
        _ok(f"Auth             : ADC — no API key")
        try:
            df          = _load_from_bigquery(bq_project, bq_dataset, bq_table, bq_query)
            data_source = (f"bigquery://{bq_project}.{bq_dataset}.{bq_table}"
                           if have_bq else f"bigquery://{bq_project}/<custom_query>")
            _ok(f"Loaded from BigQuery: {df.shape[0]:,} rows × {df.shape[1]} cols")
        except Exception as e:
            _warn(f"BigQuery load failed: {type(e).__name__}: {e}")
            _info("Falling back to next source …")

    # ── Strategy 2: explicit GCS URI or local path from config ───────────────
    if df is None and cfg_csv:
        if cfg_csv.startswith("gs://"):
            _ok(f"Config CSV source: GCS → {cfg_csv}")
            tmp  = STAGING / "processed_output.csv"
            lp   = _download_from_gcs(cfg_csv, tmp)   # hard fail if set explicitly
            df   = pd.read_csv(str(lp))
        else:
            p = Path(cfg_csv)
            if not p.exists():
                raise FileNotFoundError(
                    f"Config CSV not found: {cfg_csv}\n"
                    f"Update model.processed_csv in pipeline_config.yaml."
                )
            _ok(f"Config CSV source: local → {cfg_csv}")
            df = pd.read_csv(str(p))
        data_source = cfg_csv
        _ok(f"Loaded: {df.shape[0]:,} rows × {df.shape[1]} cols")

    # ── Strategy 3: GCS auto-detect (GCP mode only) ──────────────────────────
    if df is None and gcs_bucket and env_mode != "local":
        _step(f"Auto-detecting latest CSV in gs://{gcs_bucket}/{gcs_base}/…")
        uri = _find_latest_gcs_csv(gcs_bucket, gcs_base)
        if uri:
            try:
                tmp = STAGING / "processed_output.csv"
                lp  = _download_from_gcs(uri, tmp)
                df  = pd.read_csv(str(lp))
                data_source = uri
                _ok(f"Loaded from GCS: {df.shape[0]:,} rows × {df.shape[1]} cols")
            except Exception as e:
                _warn(f"GCS fallback failed: {e}")

    # ── Strategy 4: local auto-detect ────────────────────────────────────────
    if df is None:
        _step("Scanning local ./ml_pipeline_output/ …")
        cands = sorted(
            Path("./ml_pipeline_output").glob("*/output/processed_output.csv"),
            reverse=True
        )
        if cands:
            df          = pd.read_csv(str(cands[0]))
            data_source = str(cands[0])
            _ok(f"Loaded from local: {df.shape[0]:,} rows × {df.shape[1]} cols  "
                f"← {data_source}")

    # ── Strategy 5: interactive prompt ───────────────────────────────────────
    if df is None:
        if CFG.auto:
            raise FileNotFoundError(
                "No data source found. Set one in pipeline_config.yaml:\n"
                "  model.bq_source_project / bq_source_dataset / bq_source_table\n"
                "    (reads from the BigQuery table written by ml_preprocessor_gcp.py)\n"
                "  model.processed_csv: gs://bucket/path/file.csv  (GCS)\n"
                "  model.processed_csv: /local/path/file.csv       (local)"
            )
        print(f"\n  {B}No data found automatically. Enter one of:{RST}")
        print(f"    BigQuery:  my-project.my_dataset.my_table")
        print(f"    GCS URI:   gs://bucket/path/processed_output.csv")
        print(f"    Local:     /path/to/processed_output.csv")
        raw = _ask("Data source").strip()

        if "." in raw and not raw.startswith("gs://") and "/" not in raw:
            parts = raw.split(".")
            if len(parts) == 3:
                bq_project, bq_dataset, bq_table = parts
                df = _load_from_bigquery(bq_project, bq_dataset, bq_table)
                data_source = f"bigquery://{raw}"
            else:
                raise ValueError(f"Cannot parse '{raw}' — use project.dataset.table")
        elif raw.startswith("gs://"):
            tmp = STAGING / "processed_output.csv"
            lp  = _download_from_gcs(raw, tmp)
            df  = pd.read_csv(str(lp))
            data_source = raw
        else:
            df  = pd.read_csv(raw)
            data_source = raw
        _ok(f"Loaded: {df.shape[0]:,} rows × {df.shape[1]} cols")

    if df is None or df.empty:
        raise RuntimeError("Failed to load data from any source. "
                           "Check your pipeline_config.yaml settings.")

    # ── Column inventory ──────────────────────────────────────────────────────
    _ok(f"Data source: {data_source}")
    print(f"\n  {'#':<5}{'Column':<44}{'DType':<18}{'Non-null':>10}{'Unique':>10}")
    print("  " + "─"*90)
    for i, col in enumerate(df.columns, 1):
        print(f"  {i:<5}{col:<44}{str(df[col].dtype):<18}"
              f"{df[col].notna().sum():>10,}{df[col].nunique():>10,}")

    # ── Identifier columns ────────────────────────────────────────────────────
    id_cands = [c for c in df.columns
                if any(k in c.lower() for k in
                       ["id","uuid","guid","key","customer","order","row"])]
    non_feat = ["class_label","prediction"]
    id_cols  = list(dict.fromkeys(
        (CFG.lst("model","identifier_columns") or []) +
        [c for c in id_cands if c in df.columns] +
        [c for c in non_feat if c in df.columns]
    ))
    if id_cols:
        _ok(f"Identifier / meta cols (excluded from features): {id_cols}")

    # ── Target column ─────────────────────────────────────────────────────────
    target = CFG.s("model","target_column") or CFG.s("pipeline","target_column")
    if not target or target not in df.columns:
        if CFG.auto:
            cands  = [c for c in df.columns
                      if c not in id_cols
                      and df[c].dtype.kind in ("f","i","u")
                      and df[c].nunique() <= 50]
            target = cands[-1] if cands else df.columns[-1]
            _warn(f"auto_mode: target_column not set — guessing '{target}'")
        else:
            feat_cands = [c for c in df.columns if c not in id_cols]
            print(f"\n  Available columns:")
            for i, col in enumerate(feat_cands, 1):
                print(f"  {i:<5}{col:<44}{str(df[col].dtype):<18}"
                      f"{df[col].nunique():>10,}")
            raw = _ask("Target column name or number").strip()
            target = (feat_cands[int(raw)-1]
                      if raw.isdigit() and 1 <= int(raw) <= len(feat_cands)
                      else raw)
    _ok(f"Target: '{target}'  dtype={df[target].dtype}  "
        f"non-null={df[target].notna().sum():,}  unique={df[target].nunique()}")

    # ── Model type ────────────────────────────────────────────────────────────
    mt_cfg = CFG.s("model","model_type") or CFG.s("pipeline","model_type")
    if mt_cfg in ("classification","regression","clustering"):
        model_type = mt_cfg
        _ok(f"Model type (config): {model_type}")
    elif CFG.auto:
        n_uniq     = df[target].nunique() if target in df.columns else 0
        model_type = "classification" if n_uniq <= 20 else "regression"
        _ok(f"Model type (auto, {n_uniq} unique values): {model_type}")
    else:
        choice = _menu("Model type?", [
            "Classification — predict a category / class",
            "Regression     — predict a continuous number",
            "Clustering     — discover natural groups (no target needed)",
        ], "1")
        model_type = ("classification" if "class"  in choice else
                      "regression"     if "regress" in choice else "clustering")
    _ok(f"Model type: {model_type}")

    # Capture class_label before any drops (needed for target recovery)
    class_label_backup = df["class_label"].copy() if "class_label" in df.columns else None

    log["data_source"] = data_source
    log["csv_path"]    = data_source    # backward compat for report
    log["csv_source"]  = ("bigquery" if data_source.startswith("bigquery://") else
                          "gcs"      if data_source.startswith("gs://")       else "local")
    log["bq_project"]  = bq_project
    log["bq_dataset"]  = bq_dataset
    log["bq_table"]    = bq_table
    log["target"]      = target
    log["id_cols"]     = id_cols
    log["model_type"]  = model_type
    log["n_rows"]      = df.shape[0]
    log["n_cols"]      = df.shape[1]
    return df, target, id_cols, model_type, class_label_backup


# =============================================================================
# STEP 2 — PREPROCESSING + FEATURE PREP
# =============================================================================
def _prepare_features(df: pd.DataFrame, target: str, id_cols: list,
                      model_type: str, log: dict,
                      class_label_backup: pd.Series | None = None):
    """
    Returns X, y (or X only for clustering), feature_names, scaler
    """
    _banner("STEP 2 · Feature Preparation")
    prep_steps = []   # track every preprocessing action for the report

    # Drop id/meta columns
    drop_cols = [c for c in id_cols if c in df.columns]
    if drop_cols:
        df = df.drop(columns=drop_cols)
        _ok(f"Dropped identifier/meta columns: {drop_cols}")
        prep_steps.append(f"Dropped identifier/meta columns: {drop_cols}")

    # Separate target
    if model_type != "clustering" and target in df.columns:
        y = df[target].copy()
        X = df.drop(columns=[target])
    else:
        y = None
        X = df.copy() if target not in df.columns else df.drop(columns=[target])

    # Convert boolean-like object columns to numeric
    obj_cols_all = X.select_dtypes(exclude=[np.number]).columns.tolist()
    converted_cols = []
    for col in obj_cols_all:
        converted = pd.to_numeric(X[col], errors="coerce")
        pct_ok = converted.notna().sum() / max(X[col].notna().sum(), 1)
        if pct_ok >= 0.95:
            X[col] = converted.astype("float64")
            converted_cols.append(col)
    if converted_cols:
        _ok(f"Converted {len(converted_cols)} boolean/object columns to numeric")
        prep_steps.append(f"Boolean/object→numeric conversion: {converted_cols}")

    # Drop any remaining non-numeric columns that truly cannot be used
    obj_cols = X.select_dtypes(exclude=[np.number]).columns.tolist()
    if obj_cols:
        _warn(f"Dropping non-numeric columns (unencodable): {obj_cols}")
        X = X.drop(columns=obj_cols)
        prep_steps.append(f"Dropped non-numeric (unencodable): {obj_cols}")

    # Drop columns with all-NaN
    all_nan = [c for c in X.columns if X[c].isnull().all()]
    if all_nan:
        X = X.drop(columns=all_nan)
        _warn(f"Dropped all-NaN columns: {all_nan}")
        prep_steps.append(f"Dropped all-NaN columns: {all_nan}")

    # Fill remaining NaNs with column median
    nan_cols = [c for c in X.columns if X[c].isnull().any()]
    if nan_cols:
        for c in nan_cols:
            X[c] = X[c].fillna(X[c].median())
        _ok(f"Filled NaN with median in: {nan_cols}")
        prep_steps.append(f"NaN filled with column median: {nan_cols}")

    # Drop target NaN rows — handle all-NaN target gracefully
    if y is not None:
        y = pd.to_numeric(y, errors="coerce")

        # If target is entirely NaN, try multiple recovery strategies
        if y.isnull().all():
            _warn(f"Target '{target}' is all-NaN in the processed CSV.")

            # Strategy 1: class_label backup column — try as numeric first
            if class_label_backup is not None and not class_label_backup.isnull().all():
                numeric_recovery = pd.to_numeric(class_label_backup, errors="coerce")
                if numeric_recovery.notna().sum() > 0:
                    y = numeric_recovery
                    _ok(f"Recovery 1: target from class_label (numeric). "
                        f"Unique: {sorted(y.dropna().unique().tolist())}")
                else:
                    le = LabelEncoder()
                    raw = class_label_backup.fillna("__missing__").astype(str)
                    y   = pd.Series(le.fit_transform(raw), index=raw.index, name=target)
                    _ok(f"Recovery 1: target from class_label (LabelEncoder). "
                        f"Classes: {list(le.classes_)}")
                    log["label_encoder_classes"] = list(le.classes_)

            # Strategy 2: re-read from original CSV — find target column
            if y.isnull().all() or y.nunique() < 2:
                csv_path = log.get("csv_path","")
                _warn("class_label also invalid — attempting to re-read target "
                      "from original CSV with pandas infer.")
                try:
                    df_orig = pd.read_csv(csv_path)
                    if target in df_orig.columns:
                        y_orig = pd.to_numeric(df_orig[target], errors="coerce")
                        if y_orig.notna().sum() > 0 and y_orig.nunique() >= 2:
                            # Align index
                            y = y_orig.iloc[:len(y)].reset_index(drop=True)
                            _ok(f"Recovery 2: target re-read from CSV. "
                                f"Unique: {sorted(y.dropna().unique().tolist())}")
                except Exception as e:
                    _warn(f"Re-read failed: {e}")

            if y.isnull().all():
                _warn("All recovery strategies failed. Target remains all-NaN.")
                _warn("The processed_output.csv may have a corrupt target column.")
                _warn("Re-run ml_preprocessor_gcp.py to regenerate a clean CSV.")

        # Final NaN drop
        mask = y.notna()
        X = X.loc[mask].reset_index(drop=True)
        y = y.loc[mask].reset_index(drop=True)

    feature_names = list(X.columns)
    _ok(f"Features: {len(feature_names)} | Samples: {len(X):,}")
    if y is not None:
        if model_type == "classification":
            vc = y.value_counts().sort_index()
            print(f"\n  Target distribution:")
            for v, cnt in vc.items():
                print(f"    Class {v}: {cnt:,}  ({cnt/len(y)*100:.1f}%)")
            prep_steps.append(f"Target distribution: { {int(v):int(c) for v,c in vc.items()} }")

    # Scale features
    scaler = StandardScaler()
    X_scaled = pd.DataFrame(
        scaler.fit_transform(X.astype(float)),
        columns=feature_names
    )
    _ok(f"Features scaled with StandardScaler")
    prep_steps.append(f"StandardScaler applied to {len(feature_names)} features")

    # Save scaler
    scaler_path = str(STAGING / "scaler.pkl")
    with open(scaler_path,"wb") as f: pickle.dump(scaler, f)
    _ok(f"Scaler saved: {scaler_path}")

    log["feature_names"] = feature_names
    log["n_features"]    = len(feature_names)
    log["scaler_path"]   = scaler_path
    log["prep_steps"]    = prep_steps   # record all steps for report

    return X_scaled, y, feature_names, scaler


# =============================================================================
# STEP 2b — TARGET LEAKAGE CHECK  (req 4)
# Show columns whose names contain the target name (≥5% substring match)
# and let the user decide which to drop before training.
# =============================================================================
def _check_target_leakage(X: pd.DataFrame, target: str,
                           log: dict) -> pd.DataFrame:
    _banner("STEP 2b · Target Leakage / Column Name Check")

    tgt_lower = target.lower()
    candidates = []
    for col in X.columns:
        col_lower = col.lower()
        # 5% character overlap threshold using simple token check
        # A column matches if it shares a significant substring with target
        max_sub = max(
            (len(s) for s in [tgt_lower, col_lower]
             if s in col_lower or s in tgt_lower or
             any(tgt_lower[i:i+max(1,int(len(tgt_lower)*0.5))] in col_lower
                 for i in range(len(tgt_lower)))),
            default=0
        )
        overlap_pct = max_sub / max(len(tgt_lower), 1) * 100
        if overlap_pct >= 5 and col != target:
            candidates.append((col, round(overlap_pct, 1)))

    if not candidates:
        _ok(f"No columns with name similarity to target '{target}'.")
        log["leakage_dropped"] = []
        return X

    print(f"\n  {Y}Columns with name similarity to target '{target}':{RST}")
    print(f"  {'#':<5}{'Column':<44}{'Similarity%':>12}  Note")
    print("  " + "─"*72)
    for i, (col, pct) in enumerate(candidates, 1):
        print(f"  {i:<5}{col:<44}{pct:>11.1f}%  ← may be leakage")

    cfg_drop = CFG.lst("model","leakage_drop_columns") or []
    if cfg_drop:
        to_drop = [c for c in cfg_drop if c in X.columns]
        _ok(f"Dropping leakage columns (config): {to_drop}")
    elif CFG.auto:
        _ok("auto_mode: skipping leakage drop (set model.leakage_drop_columns in config).")
        to_drop = []
    else:
        print(f"\n  Enter column numbers to DROP (comma-sep), or Enter to keep all:")
        raw = input(f"  Drop columns: ").strip()
        to_drop = []
        if raw:
            for tok in raw.split(","):
                tok = tok.strip()
                if tok.isdigit():
                    idx = int(tok) - 1
                    if 0 <= idx < len(candidates):
                        to_drop.append(candidates[idx][0])
            _ok(f"Dropping: {to_drop}")
        else:
            _ok("No columns dropped.")

    if to_drop:
        X = X.drop(columns=to_drop, errors="ignore")
        _ok(f"Dropped {len(to_drop)} potentially leaking column(s).")

    log["leakage_candidates"] = candidates
    log["leakage_dropped"]    = to_drop
    return X


# =============================================================================
# STEP 2c — CORRELATION-BASED FEATURE SELECTION  (req 5)
# Keep only the top-N features by absolute correlation with target.
# N is controlled by model.top_features_by_correlation in config (default 30).
# =============================================================================
def _select_top_corr_features(X: pd.DataFrame, y: pd.Series,
                               model_type: str, log: dict) -> pd.DataFrame:
    _banner("STEP 2c · Top-N Feature Selection by Correlation")

    if model_type == "clustering" or y is None:
        _ok("Clustering — skipping correlation feature selection.")
        log["corr_feature_selection"] = {}
        return X

    top_n = CFG.i("model","top_features_by_correlation", default=30)
    _ok(f"Keeping top {top_n} features by |Pearson correlation| with target")
    _info("Set model.top_features_by_correlation in config to change this number")

    # Compute correlation of each feature with target
    corr_scores = {}
    for col in X.columns:
        try:
            r = float(pd.Series(X[col].values).corr(pd.Series(y.values)))
            if pd.notna(r):
                corr_scores[col] = abs(r)
        except Exception:
            corr_scores[col] = 0.0

    sorted_corr = dict(sorted(corr_scores.items(), key=lambda x: x[1], reverse=True))

    # Print full ranked list
    print(f"\n  {'Rank':<6}{'Feature':<44}{'|Corr|':>8}  Bar")
    print("  " + "─"*70)
    for rank, (feat, score) in enumerate(sorted_corr.items(), 1):
        bar = "█" * int(score * 40)
        col = G if score > 0.3 else (Y if score > 0.1 else RST)
        print(f"  {rank:<6}{feat:<44}{score:>8.4f}  {col}{bar}{RST}")

    # Save correlation bar chart
    try:
        top_plot = min(40, len(sorted_corr))
        feats_p  = list(sorted_corr.keys())[:top_plot]
        vals_p   = [sorted_corr[f] for f in feats_p]
        colors   = [("#2F9E44" if v > 0.3 else "#F59F00" if v > 0.1 else "#E03131")
                    for v in vals_p]
        fig, ax  = plt.subplots(figsize=(9, max(4, top_plot * 0.38)))
        ax.barh(feats_p[::-1], vals_p[::-1], color=colors[::-1])
        ax.axvline(0.1, color="gray", linestyle="--", lw=1)
        ax.set_xlabel("|Pearson Correlation with Target|")
        ax.set_title(f"Feature Correlation with '{log.get('target','target')}'\n"
                     f"(red dashed = 0.1 threshold)", fontweight="bold")
        fig.tight_layout()
        p = str(STAGING / "correlation_with_target.png")
        fig.savefig(p, dpi=120, bbox_inches="tight"); plt.close(fig)
        log["corr_target_chart"] = p
        _ok("Correlation-with-target chart saved")
    except Exception as e:
        _warn(f"Corr chart failed: {e}"); plt.close("all")

    # Correlation matrix heatmap (top 20 features)
    try:
        top20 = list(sorted_corr.keys())[:min(20, len(sorted_corr))]
        fig, ax = plt.subplots(figsize=(10, 8))
        corr_matrix = X[top20].corr()
        mask = np.triu(np.ones_like(corr_matrix, dtype=bool))
        sns.heatmap(corr_matrix, mask=mask, annot=True, fmt=".2f",
                    cmap="coolwarm", center=0, ax=ax,
                    annot_kws={"size": 7}, linewidths=0.5)
        ax.set_title("Feature Correlation Matrix (Top 20 by target corr)",
                     fontweight="bold")
        fig.tight_layout()
        p = str(STAGING / "correlation_matrix.png")
        fig.savefig(p, dpi=120, bbox_inches="tight"); plt.close(fig)
        log["corr_matrix_chart"] = p
        _ok("Correlation matrix heatmap saved")
    except Exception as e:
        _warn(f"Corr matrix chart failed: {e}"); plt.close("all")

    # Trim to top_n
    if len(sorted_corr) > top_n:
        keep    = list(sorted_corr.keys())[:top_n]
        dropped = [c for c in X.columns if c not in keep]
        X       = X[keep]
        _ok(f"Kept top {top_n} features. Dropped {len(dropped)} low-correlation features.")
        log["corr_dropped_features"] = dropped
    else:
        _ok(f"Only {len(sorted_corr)} features — keeping all (< {top_n} threshold).")
        log["corr_dropped_features"] = []

    log["corr_feature_selection"] = sorted_corr
    log["top_n_features"]         = top_n
    log["feature_names"]          = list(X.columns)   # update after trim
    log["n_features"]             = len(X.columns)
    return X



# =============================================================================
# STEP 3 — FEATURE SELECTION
# =============================================================================
def _feature_selection(X: pd.DataFrame, y: pd.Series,
                       model_type: str, log: dict) -> dict:
    """
    Runs multiple feature selection methods and returns importance scores dict.
    """
    _banner("STEP 3 · Feature Selection & Importance Analysis")
    results = {}
    feats   = list(X.columns)

    if model_type == "clustering" or y is None:
        _ok("Clustering mode — skipping supervised feature selection.")
        log["feature_selection"] = {}
        return {}

    _step("Running feature selection methods …")

    # 1. Statistical filter
    try:
        if model_type == "classification":
            selector = SelectKBest(score_func=mutual_info_classif, k="all")
        else:
            selector = SelectKBest(score_func=mutual_info_regression, k="all")
        selector.fit(X, y)
        mi = dict(zip(feats, selector.scores_))
        results["Mutual Information"] = mi
        _ok(f"Mutual information computed ({len(mi)} features)")
    except Exception as e:
        _warn(f"Mutual info failed: {e}")

    # 2. F-statistic
    try:
        if model_type == "classification":
            fs, _ = f_classif(X, y)
        else:
            fs, _ = f_regression(X, y)
        results["F-Statistic"] = dict(zip(feats, fs))
        _ok("F-statistic computed")
    except Exception as e:
        _warn(f"F-statistic failed: {e}")

    # 3. Random Forest native importance
    try:
        if model_type == "classification":
            rf = RandomForestClassifier(n_estimators=100, random_state=42, n_jobs=-1)
        else:
            rf = RandomForestRegressor(n_estimators=100, random_state=42, n_jobs=-1)
        rf.fit(X, y)
        results["Random Forest Importance"] = dict(zip(feats, rf.feature_importances_))
        _ok("Random Forest feature importances computed")
    except Exception as e:
        _warn(f"RF importance failed: {e}")

    # 4. Permutation importance
    try:
        if model_type == "classification":
            base = RandomForestClassifier(n_estimators=50, random_state=42)
        else:
            base = RandomForestRegressor(n_estimators=50, random_state=42)
        base.fit(X, y)
        perm = permutation_importance(base, X, y, n_repeats=5, random_state=42)
        results["Permutation Importance"] = dict(zip(feats, perm.importances_mean))
        _ok("Permutation importances computed")
    except Exception as e:
        _warn(f"Permutation importance failed: {e}")

    # 5. RFE with Logistic/Linear Regression
    try:
        if model_type == "classification":
            estimator = LogisticRegression(max_iter=1000, random_state=42)
        else:
            estimator = Ridge()
        rfe = RFE(estimator=estimator, n_features_to_select=max(1, len(feats)//2), step=1)
        rfe.fit(X, y)
        # Rank: 1 = selected, higher = eliminated earlier
        rfe_scores = {f: 1.0 if r==1 else 0.0 for f,r in zip(feats, rfe.ranking_)}
        results["RFE Selected"] = rfe_scores
        _ok(f"RFE: {sum(v==1.0 for v in rfe_scores.values())} features selected")
    except Exception as e:
        _warn(f"RFE failed: {e}")

    # ── Aggregate: normalise each method 0-1 then average ─────────────────────
    agg = {}
    for method, scores in results.items():
        vals = np.array(list(scores.values()))
        rng  = vals.max() - vals.min()
        norm = (vals - vals.min()) / rng if rng > 0 else np.zeros_like(vals)
        for f, s in zip(feats, norm):
            agg[f] = agg.get(f, 0.0) + s / len(results)

    agg_sorted = dict(sorted(agg.items(), key=lambda x: x[1], reverse=True))

    # Print ranked feature list
    print(f"\n  {'Rank':<6}{'Feature':<40}{'Importance Score':>16}")
    print("  " + "─"*64)
    for rank, (feat, score) in enumerate(agg_sorted.items(), 1):
        bar  = "█" * int(score * 30)
        col  = G if score > 0.6 else (Y if score > 0.3 else "")
        print(f"  {rank:<6}{feat:<40}{score:>10.4f}  {col}{bar}{RST}")

    log["feature_selection"]     = {m: dict(sorted(s.items(),key=lambda x:x[1],reverse=True))
                                    for m, s in results.items()}
    log["feature_importance_agg"] = agg_sorted

    # Save feature importance chart
    try:
        top_n = min(20, len(agg_sorted))
        top_feats  = list(agg_sorted.keys())[:top_n]
        top_scores = [agg_sorted[f] for f in top_feats]
        fig, ax = plt.subplots(figsize=(9, max(4, top_n * 0.4)))
        colors = [("#2F9E44" if s>0.6 else "#F59F00" if s>0.3 else "#E03131")
                  for s in top_scores]
        ax.barh(top_feats[::-1], top_scores[::-1], color=colors[::-1])
        ax.set_xlabel("Aggregated Importance Score (0–1)", fontsize=11)
        ax.set_title(f"Top {top_n} Feature Importances\n(aggregated: MI + F-stat + RF + Permutation + RFE)",
                     fontweight="bold", fontsize=12)
        ax.axvline(0.5, color="gray", linestyle="--", lw=1, alpha=0.7)
        fig.tight_layout()
        p = str(STAGING / "feature_importance.png")
        fig.savefig(p, dpi=120, bbox_inches="tight"); plt.close(fig)
        log["feature_importance_chart"] = p
        _ok(f"Feature importance chart saved")
    except Exception as e:
        _warn(f"Chart failed: {e}"); plt.close("all")

    return agg_sorted

# =============================================================================
# STEP 4 — MODEL SELECTION
# =============================================================================
# =============================================================================
# MODEL CATALOG — built dynamically so XGBoost / LightGBM / CatBoost are
# included when installed, skipped gracefully when not.
# =============================================================================

def _build_model_catalogs() -> tuple[dict, dict, dict]:
    """
    Build and return (CLASSIFICATION_MODELS, REGRESSION_MODELS, CLUSTERING_MODELS).
    Optional libraries (XGBoost, LightGBM, CatBoost) are probed at runtime
    and included only when available. Each entry is:
        name  →  (model_instance, category, description)
    so the selection menu can show helpful context.
    """
    from sklearn.linear_model import (
        LogisticRegression, RidgeClassifier, SGDClassifier,
        PassiveAggressiveClassifier, Perceptron,
        LinearRegression, Ridge, Lasso, ElasticNet,
        HuberRegressor, BayesianRidge, SGDRegressor,
        PassiveAggressiveRegressor,
    )
    from sklearn.tree import (
        DecisionTreeClassifier, ExtraTreeClassifier,
        DecisionTreeRegressor, ExtraTreeRegressor,
    )
    from sklearn.ensemble import (
        RandomForestClassifier, GradientBoostingClassifier,
        ExtraTreesClassifier, AdaBoostClassifier,
        BaggingClassifier, HistGradientBoostingClassifier,
        VotingClassifier, StackingClassifier,
        RandomForestRegressor, GradientBoostingRegressor,
        ExtraTreesRegressor, AdaBoostRegressor,
        BaggingRegressor, HistGradientBoostingRegressor,
    )
    from sklearn.svm import SVC, SVR, LinearSVC, LinearSVR, NuSVC, NuSVR
    from sklearn.neighbors import (
        KNeighborsClassifier, RadiusNeighborsClassifier,
        KNeighborsRegressor,
    )
    from sklearn.naive_bayes import (
        GaussianNB, BernoulliNB, MultinomialNB, ComplementNB,
    )
    from sklearn.neural_network import MLPClassifier, MLPRegressor
    from sklearn.discriminant_analysis import (
        LinearDiscriminantAnalysis, QuadraticDiscriminantAnalysis,
    )
    from sklearn.gaussian_process import (
        GaussianProcessClassifier, GaussianProcessRegressor,
    )
    from sklearn.calibration import CalibratedClassifierCV
    from sklearn.semi_supervised import LabelSpreading, LabelPropagation
    from sklearn.cluster import (
        KMeans, MiniBatchKMeans, AgglomerativeClustering,
        DBSCAN, MeanShift, SpectralClustering, OPTICS,
        Birch, AffinityPropagation,
    )
    from sklearn.mixture import GaussianMixture, BayesianGaussianMixture

    # ── Classification ────────────────────────────────────────────────────────
    clf = {}

    # Linear / probabilistic
    clf["Logistic Regression"]           = (LogisticRegression(max_iter=1000, random_state=42),
                                             "Linear", "L2-regularised logistic regression")
    clf["Logistic Regression (L1)"]      = (LogisticRegression(penalty="l1", solver="saga",
                                              max_iter=1000, random_state=42),
                                             "Linear", "Sparse L1 logistic regression")
    clf["Ridge Classifier"]              = (RidgeClassifier(),
                                             "Linear", "Ridge regression adapted for classification")
    clf["SGD Classifier"]                = (SGDClassifier(max_iter=1000, random_state=42),
                                             "Linear", "Stochastic gradient descent (fast for large data)")
    clf["Passive-Aggressive"]            = (PassiveAggressiveClassifier(max_iter=1000, random_state=42),
                                             "Linear", "Online PA algorithm for text/streaming")
    clf["Perceptron"]                    = (Perceptron(max_iter=1000, random_state=42),
                                             "Linear", "Simple single-layer neural classifier")

    # Discriminant Analysis
    clf["Linear Discriminant Analysis"]  = (LinearDiscriminantAnalysis(),
                                             "Discriminant", "LDA — maximises class separation")
    clf["Quadratic Discriminant Analysis"]= (QuadraticDiscriminantAnalysis(),
                                             "Discriminant", "QDA — non-linear class boundaries")

    # Naive Bayes
    clf["Gaussian Naive Bayes"]          = (GaussianNB(),
                                             "Naive Bayes", "Assumes Gaussian feature distributions")
    clf["Bernoulli Naive Bayes"]         = (BernoulliNB(),
                                             "Naive Bayes", "Binary/boolean features")
    clf["Complement Naive Bayes"]        = (ComplementNB(),
                                             "Naive Bayes", "Good for imbalanced text data")

    # Tree-based
    clf["Decision Tree"]                 = (DecisionTreeClassifier(random_state=42),
                                             "Tree", "Single CART decision tree")
    clf["Extra Tree (single)"]           = (ExtraTreeClassifier(random_state=42),
                                             "Tree", "Single extremely randomised tree")

    # Ensemble — Bagging / Forest
    clf["Random Forest"]                 = (RandomForestClassifier(n_estimators=200,
                                              random_state=42, n_jobs=-1),
                                             "Ensemble-Forest", "Bootstrap-aggregated decision trees")
    clf["Extra Trees (Forest)"]          = (ExtraTreesClassifier(n_estimators=200,
                                              random_state=42, n_jobs=-1),
                                             "Ensemble-Forest", "Extremely randomised forest")
    clf["Bagging (Decision Tree)"]       = (BaggingClassifier(n_estimators=100, random_state=42,
                                              n_jobs=-1),
                                             "Ensemble-Bagging", "Bagging meta-estimator")

    # Ensemble — Boosting
    clf["Gradient Boosting (GBM)"]       = (GradientBoostingClassifier(n_estimators=200,
                                              random_state=42),
                                             "Ensemble-Boosting", "Classic sklearn GBM")
    clf["Hist Gradient Boosting"]        = (HistGradientBoostingClassifier(max_iter=200,
                                              random_state=42),
                                             "Ensemble-Boosting", "Fast histogram-based GBM (handles NaN)")
    clf["AdaBoost"]                      = (AdaBoostClassifier(n_estimators=100, random_state=42),
                                             "Ensemble-Boosting", "Adaptive boosting of weak learners")

    # SVM
    clf["SVM (RBF Kernel)"]              = (SVC(probability=True, random_state=42),
                                             "SVM", "Support Vector Machine with RBF kernel")
    clf["SVM (Linear Kernel)"]           = (SVC(kernel="linear", probability=True, random_state=42),
                                             "SVM", "Linear SVM (good for high-dimensional data)")
    clf["SVM (Poly Kernel)"]             = (SVC(kernel="poly", probability=True, random_state=42),
                                             "SVM", "SVM with polynomial kernel")
    clf["Nu-SVM"]                        = (NuSVC(probability=True, random_state=42),
                                             "SVM", "SVM with nu parameter controlling support vectors")
    clf["Linear SVC"]                    = (CalibratedClassifierCV(LinearSVC(max_iter=2000,
                                              random_state=42)),
                                             "SVM", "Fast linear SVM (calibrated for probabilities)")

    # Neighbours
    clf["K-Nearest Neighbors (k=5)"]     = (KNeighborsClassifier(n_neighbors=5, n_jobs=-1),
                                             "Neighbours", "Instance-based learning, k=5")
    clf["K-Nearest Neighbors (k=11)"]    = (KNeighborsClassifier(n_neighbors=11, n_jobs=-1),
                                             "Neighbours", "Instance-based learning, k=11 (smoother)")
    clf["K-Nearest Neighbors (k=3)"]     = (KNeighborsClassifier(n_neighbors=3, n_jobs=-1),
                                             "Neighbours", "Instance-based learning, k=3 (fine-grained)")

    # Neural Network
    clf["MLP (128-64)"]                  = (MLPClassifier(hidden_layer_sizes=(128,64),
                                              max_iter=500, random_state=42),
                                             "Neural Net", "2-layer MLP, 128→64 neurons")
    clf["MLP (256-128-64)"]              = (MLPClassifier(hidden_layer_sizes=(256,128,64),
                                              max_iter=500, random_state=42),
                                             "Neural Net", "3-layer MLP, 256→128→64 neurons")
    clf["MLP (64-32)"]                   = (MLPClassifier(hidden_layer_sizes=(64,32),
                                              max_iter=500, random_state=42),
                                             "Neural Net", "2-layer MLP, smaller (faster)")

    # Gaussian Process (small datasets only)
    clf["Gaussian Process"]              = (GaussianProcessClassifier(random_state=42, n_jobs=-1),
                                             "Probabilistic", "Bayesian GP (slow on large data)")

    # Semi-supervised
    clf["Label Spreading"]               = (LabelSpreading(),
                                             "Semi-supervised", "Graph-based label propagation")
    clf["Label Propagation"]             = (LabelPropagation(),
                                             "Semi-supervised", "Graph-based label propagation (variant)")

    # ── Optional: XGBoost ─────────────────────────────────────────────────────
    try:
        from xgboost import XGBClassifier
        clf["XGBoost"]                   = (XGBClassifier(n_estimators=200, random_state=42,
                                              n_jobs=-1, eval_metric="logloss",
                                              use_label_encoder=False),
                                             "Ensemble-Boosting", "Extreme gradient boosting (XGBoost)")
        clf["XGBoost (dart)"]            = (XGBClassifier(n_estimators=200, booster="dart",
                                              random_state=42, n_jobs=-1, eval_metric="logloss",
                                              use_label_encoder=False),
                                             "Ensemble-Boosting", "XGBoost with DART dropout boosting")
    except ImportError:
        pass

    # ── Optional: LightGBM ────────────────────────────────────────────────────
    try:
        from lightgbm import LGBMClassifier
        clf["LightGBM"]                  = (LGBMClassifier(n_estimators=200, random_state=42,
                                              n_jobs=-1, verbose=-1),
                                             "Ensemble-Boosting", "Light gradient boosting (Microsoft)")
        clf["LightGBM (DART)"]           = (LGBMClassifier(n_estimators=200, boosting_type="dart",
                                              random_state=42, n_jobs=-1, verbose=-1),
                                             "Ensemble-Boosting", "LightGBM with DART dropout")
        clf["LightGBM (GOSS)"]           = (LGBMClassifier(n_estimators=200, boosting_type="goss",
                                              random_state=42, n_jobs=-1, verbose=-1),
                                             "Ensemble-Boosting", "LightGBM gradient-based one-side sampling")
    except ImportError:
        pass

    # ── Optional: CatBoost ────────────────────────────────────────────────────
    try:
        from catboost import CatBoostClassifier
        clf["CatBoost"]                  = (CatBoostClassifier(iterations=200, random_state=42,
                                              verbose=0),
                                             "Ensemble-Boosting", "Categorical boosting (Yandex)")
        clf["CatBoost (balanced)"]       = (CatBoostClassifier(iterations=200, random_state=42,
                                              auto_class_weights="Balanced", verbose=0),
                                             "Ensemble-Boosting", "CatBoost with auto class-weight balancing")
    except ImportError:
        pass

    # ── Regression ────────────────────────────────────────────────────────────
    reg = {}

    # Linear
    reg["Linear Regression"]             = (LinearRegression(),
                                             "Linear", "Ordinary least squares")
    reg["Ridge Regression"]              = (Ridge(alpha=1.0),
                                             "Linear", "L2-regularised linear regression")
    reg["Lasso Regression"]              = (Lasso(alpha=0.01, max_iter=5000),
                                             "Linear", "L1-regularised (feature selection)")
    reg["ElasticNet"]                    = (ElasticNet(alpha=0.01, l1_ratio=0.5, max_iter=5000),
                                             "Linear", "Combined L1+L2 regularisation")
    reg["Huber Regression"]              = (HuberRegressor(max_iter=500),
                                             "Linear", "Robust to outliers in target")
    reg["Bayesian Ridge"]                = (BayesianRidge(),
                                             "Probabilistic", "Bayesian linear regression")
    reg["SGD Regressor"]                 = (SGDRegressor(max_iter=1000, random_state=42),
                                             "Linear", "SGD for very large datasets")
    reg["Passive-Aggressive Regressor"]  = (PassiveAggressiveRegressor(max_iter=1000,
                                              random_state=42),
                                             "Linear", "Online regression algorithm")

    # Tree-based
    reg["Decision Tree"]                 = (DecisionTreeRegressor(random_state=42),
                                             "Tree", "Single CART regression tree")
    reg["Extra Tree (single)"]           = (ExtraTreeRegressor(random_state=42),
                                             "Tree", "Single extremely randomised tree")

    # Ensemble
    reg["Random Forest"]                 = (RandomForestRegressor(n_estimators=200,
                                              random_state=42, n_jobs=-1),
                                             "Ensemble-Forest", "Bootstrap-aggregated regression trees")
    reg["Extra Trees (Forest)"]          = (ExtraTreesRegressor(n_estimators=200,
                                              random_state=42, n_jobs=-1),
                                             "Ensemble-Forest", "Extremely randomised forest")
    reg["Bagging (Decision Tree)"]       = (BaggingRegressor(n_estimators=100, random_state=42,
                                              n_jobs=-1),
                                             "Ensemble-Bagging", "Bagging meta-estimator")
    reg["Gradient Boosting (GBM)"]       = (GradientBoostingRegressor(n_estimators=200,
                                              random_state=42),
                                             "Ensemble-Boosting", "Classic sklearn GBM")
    reg["Hist Gradient Boosting"]        = (HistGradientBoostingRegressor(max_iter=200,
                                              random_state=42),
                                             "Ensemble-Boosting", "Fast histogram-based GBM")
    reg["AdaBoost"]                      = (AdaBoostRegressor(n_estimators=100, random_state=42),
                                             "Ensemble-Boosting", "Adaptive boosting")

    # SVM
    reg["SVM (RBF Kernel)"]              = (SVR(kernel="rbf"),
                                             "SVM", "Support Vector Regression, RBF kernel")
    reg["SVM (Linear Kernel)"]           = (SVR(kernel="linear"),
                                             "SVM", "Linear SVR")
    reg["Nu-SVR"]                        = (NuSVR(kernel="rbf"),
                                             "SVM", "Nu-parameter SVR")
    reg["Linear SVR"]                    = (LinearSVR(max_iter=2000, random_state=42),
                                             "SVM", "Fast linear SVR")

    # Neighbours
    reg["K-Nearest Neighbors (k=5)"]     = (KNeighborsRegressor(n_neighbors=5, n_jobs=-1),
                                             "Neighbours", "k=5 neighbour regression")
    reg["K-Nearest Neighbors (k=11)"]    = (KNeighborsRegressor(n_neighbors=11, n_jobs=-1),
                                             "Neighbours", "k=11 neighbour regression (smoother)")

    # Neural Network
    reg["MLP (128-64)"]                  = (MLPRegressor(hidden_layer_sizes=(128,64),
                                              max_iter=500, random_state=42),
                                             "Neural Net", "2-layer MLP regressor")
    reg["MLP (256-128-64)"]              = (MLPRegressor(hidden_layer_sizes=(256,128,64),
                                              max_iter=500, random_state=42),
                                             "Neural Net", "3-layer MLP regressor")

    # Gaussian Process
    reg["Gaussian Process"]              = (GaussianProcessRegressor(random_state=42),
                                             "Probabilistic", "Bayesian GP regressor (small datasets)")

    # Optional: XGBoost
    try:
        from xgboost import XGBRegressor
        reg["XGBoost"]                   = (XGBRegressor(n_estimators=200, random_state=42,
                                              n_jobs=-1),
                                             "Ensemble-Boosting", "Extreme gradient boosting regression")
        reg["XGBoost (dart)"]            = (XGBRegressor(n_estimators=200, booster="dart",
                                              random_state=42, n_jobs=-1),
                                             "Ensemble-Boosting", "XGBoost with DART dropout")
    except ImportError:
        pass

    # Optional: LightGBM
    try:
        from lightgbm import LGBMRegressor
        reg["LightGBM"]                  = (LGBMRegressor(n_estimators=200, random_state=42,
                                              n_jobs=-1, verbose=-1),
                                             "Ensemble-Boosting", "Light gradient boosting regression")
        reg["LightGBM (DART)"]           = (LGBMRegressor(n_estimators=200, boosting_type="dart",
                                              random_state=42, n_jobs=-1, verbose=-1),
                                             "Ensemble-Boosting", "LightGBM DART regression")
    except ImportError:
        pass

    # Optional: CatBoost
    try:
        from catboost import CatBoostRegressor
        reg["CatBoost"]                  = (CatBoostRegressor(iterations=200, random_state=42,
                                              verbose=0),
                                             "Ensemble-Boosting", "CatBoost regression")
    except ImportError:
        pass

    # ── Clustering ────────────────────────────────────────────────────────────
    clu = {}
    clu["K-Means (k=2)"]                 = (KMeans(n_clusters=2, random_state=42, n_init=10),
                                             "Partition", "K-Means with 2 clusters")
    clu["K-Means (k=3)"]                 = (KMeans(n_clusters=3, random_state=42, n_init=10),
                                             "Partition", "K-Means with 3 clusters")
    clu["K-Means (k=4)"]                 = (KMeans(n_clusters=4, random_state=42, n_init=10),
                                             "Partition", "K-Means with 4 clusters")
    clu["K-Means (k=5)"]                 = (KMeans(n_clusters=5, random_state=42, n_init=10),
                                             "Partition", "K-Means with 5 clusters")
    clu["K-Means (k=6)"]                 = (KMeans(n_clusters=6, random_state=42, n_init=10),
                                             "Partition", "K-Means with 6 clusters")
    clu["Mini-Batch K-Means (k=3)"]      = (MiniBatchKMeans(n_clusters=3, random_state=42),
                                             "Partition", "Fast K-Means for large datasets, k=3")
    clu["Mini-Batch K-Means (k=5)"]      = (MiniBatchKMeans(n_clusters=5, random_state=42),
                                             "Partition", "Fast K-Means for large datasets, k=5")
    clu["Agglomerative (k=3, Ward)"]     = (AgglomerativeClustering(n_clusters=3, linkage="ward"),
                                             "Hierarchical", "Bottom-up, Ward linkage, k=3")
    clu["Agglomerative (k=4, Ward)"]     = (AgglomerativeClustering(n_clusters=4, linkage="ward"),
                                             "Hierarchical", "Bottom-up, Ward linkage, k=4")
    clu["Agglomerative (k=3, Complete)"] = (AgglomerativeClustering(n_clusters=3,
                                              linkage="complete"),
                                             "Hierarchical", "Bottom-up, complete linkage, k=3")
    clu["Agglomerative (k=3, Average)"]  = (AgglomerativeClustering(n_clusters=3,
                                              linkage="average"),
                                             "Hierarchical", "Bottom-up, average linkage, k=3")
    clu["Gaussian Mixture (k=3)"]        = (GaussianMixture(n_components=3, random_state=42),
                                             "Probabilistic", "Soft assignments via GMM, k=3")
    clu["Gaussian Mixture (k=4)"]        = (GaussianMixture(n_components=4, random_state=42),
                                             "Probabilistic", "Soft assignments via GMM, k=4")
    clu["Bayesian Gaussian Mixture (k=5)"]=(BayesianGaussianMixture(n_components=5,
                                              random_state=42),
                                             "Probabilistic", "Variational Bayes GMM — infers k automatically")
    clu["DBSCAN (eps=0.5)"]              = (DBSCAN(eps=0.5, min_samples=5),
                                             "Density", "Density-based, finds noise points")
    clu["DBSCAN (eps=1.0)"]              = (DBSCAN(eps=1.0, min_samples=5),
                                             "Density", "DBSCAN with wider neighbourhood")
    clu["OPTICS"]                        = (OPTICS(min_samples=5, n_jobs=-1),
                                             "Density", "Ordering-based DBSCAN variant, variable density")
    clu["Mean Shift"]                    = (MeanShift(n_jobs=-1),
                                             "Density", "Finds modes in data — no k needed")
    clu["Spectral Clustering (k=3)"]     = (SpectralClustering(n_clusters=3, random_state=42,
                                              n_jobs=-1),
                                             "Spectral", "Graph-based, good for non-convex shapes, k=3")
    clu["Spectral Clustering (k=4)"]     = (SpectralClustering(n_clusters=4, random_state=42,
                                              n_jobs=-1),
                                             "Spectral", "Graph-based spectral clustering, k=4")
    clu["BIRCH (k=3)"]                   = (Birch(n_clusters=3),
                                             "Hierarchical", "Incremental clustering tree, k=3")
    clu["BIRCH (k=5)"]                   = (Birch(n_clusters=5),
                                             "Hierarchical", "Incremental clustering tree, k=5")
    clu["Affinity Propagation"]          = (AffinityPropagation(random_state=42),
                                             "Graph", "Message-passing, determines k automatically")

    return clf, reg, clu


# Build catalogs once at module load
_CLF_CATALOG, _REG_CATALOG, _CLU_CATALOG = _build_model_catalogs()

# Keep backward-compatible flat dicts (model_instance only) for the trainer
CLASSIFICATION_MODELS = {n: m for n,(m,_,_) in _CLF_CATALOG.items()}
REGRESSION_MODELS     = {n: m for n,(m,_,_) in _REG_CATALOG.items()}
CLUSTERING_MODELS     = {n: m for n,(m,_,_) in _CLU_CATALOG.items()}

_AVAILABLE_LIBS = []
for _lib in ["xgboost","lightgbm","catboost"]:
    try: __import__(_lib); _AVAILABLE_LIBS.append(_lib)
    except ImportError: pass


def _select_models(model_type: str, log: dict) -> dict:
    _banner("STEP 4 · Model Selection")

    if model_type == "classification":
        catalog_full = _CLF_CATALOG
        flat_catalog = CLASSIFICATION_MODELS
    elif model_type == "regression":
        catalog_full = _REG_CATALOG
        flat_catalog = REGRESSION_MODELS
    else:
        catalog_full = _CLU_CATALOG
        flat_catalog = CLUSTERING_MODELS

    names = list(catalog_full.keys())

    # ── Group by category for display ─────────────────────────────────────────
    from collections import defaultdict
    by_cat: dict[str, list[tuple[int,str,str]]] = defaultdict(list)
    for i, (name, (_, cat, desc)) in enumerate(catalog_full.items(), 1):
        by_cat[cat].append((i, name, desc))

    # ── Config-driven selection ────────────────────────────────────────────────
    cfg_models = CFG.lst("model","selected_models")
    if cfg_models:
        selected = {}
        for cn in cfg_models:
            for name in names:
                if cn.lower() in name.lower() or name.lower() in cn.lower():
                    selected[name] = flat_catalog[name]; break
        if selected:
            _ok(f"Models from config ({len(selected)}): {list(selected.keys())}")
            log["selected_models"] = list(selected.keys())
            return selected
        _warn("No config models matched — prompting for selection.")

    # ── Auto mode defaults ─────────────────────────────────────────────────────
    if CFG.auto:
        defaults = {
            "classification": [
                "Logistic Regression", "Random Forest",
                "Hist Gradient Boosting", "Extra Trees (Forest)",
                "SVM (RBF Kernel)", "K-Nearest Neighbors (k=5)",
                "MLP (128-64)",
            ],
            "regression": [
                "Linear Regression", "Ridge Regression",
                "Random Forest", "Hist Gradient Boosting",
                "Extra Trees (Forest)", "MLP (128-64)",
            ],
            "clustering": [
                "K-Means (k=3)", "K-Means (k=4)", "K-Means (k=5)",
                "DBSCAN (eps=0.5)", "Gaussian Mixture (k=3)",
            ],
        }
        # Add optional if available
        if "xgboost" in _AVAILABLE_LIBS:
            defaults["classification"].append("XGBoost")
            defaults["regression"].append("XGBoost")
        if "lightgbm" in _AVAILABLE_LIBS:
            defaults["classification"].append("LightGBM")
            defaults["regression"].append("LightGBM")
        if "catboost" in _AVAILABLE_LIBS:
            defaults["classification"].append("CatBoost")
            defaults["regression"].append("CatBoost")
        chosen = [n for n in defaults[model_type] if n in flat_catalog]
        _ok(f"Auto-selected {len(chosen)} models: {chosen}")
        log["selected_models"] = chosen
        return {n: flat_catalog[n] for n in chosen}

    # ── Interactive selection menu ─────────────────────────────────────────────
    total = len(names)
    print(f"\n  {B}{'='*70}{RST}")
    print(f"  {B}  AVAILABLE {model_type.upper()} MODELS  ({total} total){RST}")
    if _AVAILABLE_LIBS:
        print(f"  {G}  Optional libraries detected: {', '.join(_AVAILABLE_LIBS)}{RST}")
    else:
        print(f"  {Y}  Tip: pip install xgboost lightgbm catboost  to unlock 5+ more models{RST}")
    print(f"  {B}{'='*70}{RST}\n")

    # Print by category
    cat_order = [
        "Ensemble-Boosting", "Ensemble-Forest", "Ensemble-Bagging",
        "Tree", "Linear", "Discriminant", "SVM", "Neighbours",
        "Neural Net", "Naive Bayes", "Probabilistic", "Semi-supervised",
        "Partition", "Hierarchical", "Density", "Spectral", "Graph",
    ]
    ordered_cats = [c for c in cat_order if c in by_cat] + \
                   [c for c in by_cat if c not in cat_order]

    for cat in ordered_cats:
        entries = by_cat[cat]
        cat_label = {
            "Ensemble-Boosting": "🚀 BOOSTING ENSEMBLES",
            "Ensemble-Forest":   "🌲 FOREST ENSEMBLES",
            "Ensemble-Bagging":  "📦 BAGGING ENSEMBLES",
            "Tree":              "🌿 DECISION TREES",
            "Linear":            "📐 LINEAR MODELS",
            "Discriminant":      "🔬 DISCRIMINANT ANALYSIS",
            "SVM":               "⚡ SUPPORT VECTOR MACHINES",
            "Neighbours":        "📍 NEIGHBOUR METHODS",
            "Neural Net":        "🧠 NEURAL NETWORKS",
            "Naive Bayes":       "📊 NAIVE BAYES",
            "Probabilistic":     "🎲 PROBABILISTIC MODELS",
            "Semi-supervised":   "🔄 SEMI-SUPERVISED",
            "Partition":         "🔵 PARTITION CLUSTERING",
            "Hierarchical":      "🌳 HIERARCHICAL CLUSTERING",
            "Density":           "🔴 DENSITY-BASED CLUSTERING",
            "Spectral":          "💎 SPECTRAL CLUSTERING",
            "Graph":             "🕸  GRAPH-BASED CLUSTERING",
        }.get(cat, f"▸ {cat.upper()}")

        print(f"  {C}{cat_label}{RST}")
        for (i, name, desc) in entries:
            tag = f"{G} ★ available{RST}" if any(
                lib in name.lower() for lib in _AVAILABLE_LIBS
            ) else ""
            print(f"    {B}{i:>3}.{RST}  {name:<42}  {Y}{desc}{RST}{tag}")
        print()

    print(f"  {B}{'─'*70}{RST}")
    print(f"  Enter model numbers (comma-separated):  1,3,7,12")
    print(f"  Enter ranges:                           1-5,8,12-15")
    print(f"  Enter category name:                    boosting  |  forest  |  svm  |  all")
    print(f"  Press Enter for recommended defaults")
    print(f"  {B}{'─'*70}{RST}")

    raw = input(f"\n  Your selection: ").strip()

    if not raw:
        # Default recommended per type
        rec = {
            "classification": [1,3,5,7,12],   # approx top picks
            "regression":     [1,2,5,7,9],
            "clustering":     [2,3,4,16,13],
        }
        chosen = [names[i-1] for i in rec.get(model_type,[1]) if 0 < i <= total]
        _ok(f"Using recommended defaults: {chosen}")
    elif raw.lower() in ("all","*"):
        chosen = names
        _ok(f"All {len(chosen)} models selected")
    else:
        # Parse keywords
        chosen = []
        raw_lower = raw.lower()
        kw_map = {
            "boosting": "Ensemble-Boosting",
            "forest":   "Ensemble-Forest",
            "bagging":  "Ensemble-Bagging",
            "tree":     "Tree",
            "linear":   "Linear",
            "svm":      "SVM",
            "knn":      "Neighbours",
            "neighbour":"Neighbours",
            "neural":   "Neural Net",
            "mlp":      "Neural Net",
            "bayes":    "Naive Bayes",
            "cluster":  None,   # all clustering
        }
        matched_keyword = False
        for kw, cat_name in kw_map.items():
            if kw in raw_lower:
                matched_keyword = True
                if cat_name:
                    chosen += [n for i,n,d in by_cat.get(cat_name,[])]
                else:
                    chosen += names
        if not matched_keyword:
            # Parse numbers and ranges
            for tok in raw.replace(" ", "").split(","):
                if "-" in tok:
                    try:
                        lo, hi = tok.split("-", 1)
                        for idx in range(int(lo), int(hi)+1):
                            if 1 <= idx <= total:
                                chosen.append(names[idx-1])
                    except ValueError:
                        pass
                elif tok.isdigit():
                    idx = int(tok)
                    if 1 <= idx <= total:
                        chosen.append(names[idx-1])

        # Deduplicate preserving order
        seen  = set(); chosen = [n for n in chosen if not (n in seen or seen.add(n))]

        if not chosen:
            _warn("No valid selection — using top-5 defaults.")
            chosen = names[:5]

    selected = {n: flat_catalog[n] for n in chosen if n in flat_catalog}

    # Print final selection summary
    print(f"\n  {B}Selected {len(selected)} models:{RST}")
    for i, n in enumerate(selected, 1):
        _, cat, desc = catalog_full[n]
        print(f"    {G}{i:>2}.{RST}  {n:<42}  [{cat}]")

    log["selected_models"] = list(selected.keys())
    return selected



# =============================================================================
# STEP 5 — TRAIN/EVALUATE CLASSIFICATION  (reqs 1, 6, 7)
# Metrics: Accuracy, Precision, Recall, F1, ROC-AUC, MCC, Kappa,
#          Log-loss, Brier score, Average Precision
# Charts:  Confusion matrix, ROC curve, Precision-Recall curve,
#          Learning curve, Calibration plot, CV score distribution,
#          Class probability histogram, Multi-model comparison
# =============================================================================
def _train_classification(X: pd.DataFrame, y: pd.Series,
                           models: dict, log: dict) -> tuple[dict, dict]:
    _banner("STEP 5 · Classification Training & Evaluation")

    from sklearn.metrics import (
        matthews_corrcoef, cohen_kappa_score, log_loss, brier_score_loss
    )
    from sklearn.calibration import calibration_curve
    from sklearn.model_selection import learning_curve

    # ── Guard ─────────────────────────────────────────────────────────────────
    n_cls = y.nunique()
    if n_cls < 2:
        _warn(f"Target has only {n_cls} unique class(es) — cannot train classifiers.")
        return {n: {"error": f"Only {n_cls} class(es) — need ≥2"} for n in models}, {}

    test_size = CFG.f("model","test_size", default=0.2)
    cv_folds  = CFG.i("model","cv_folds",  default=5)

    strat = y if n_cls < 50 else None
    X_tr, X_te, y_tr, y_te = train_test_split(
        X, y, test_size=test_size, random_state=42, stratify=strat
    )
    _ok(f"Split  →  Train: {len(X_tr):,}  |  Test: {len(X_te):,}  "
        f"({100*(1-test_size):.0f}/{100*test_size:.0f})")

    is_binary  = n_cls == 2
    classes    = sorted(y.unique().tolist())
    cv_obj     = StratifiedKFold(n_splits=cv_folds, shuffle=True, random_state=42)
    results    = {}
    charts     = {}

    for name, model in models.items():
        _step(f"Training: {name} …")
        try:
            model.fit(X_tr, y_tr)
            safe = name.replace(" ","_").replace("(","").replace(")","").replace("/","_")

            # ── Predictions ──────────────────────────────────────────────────
            y_pred_tr = model.predict(X_tr)
            y_pred_te = model.predict(X_te)
            y_proba   = None
            if hasattr(model,"predict_proba"):
                try: y_proba = model.predict_proba(X_te)
                except: pass

            # ── TRAIN metrics ─────────────────────────────────────────────────
            tr_acc  = accuracy_score(y_tr, y_pred_tr)
            tr_f1   = f1_score(y_tr, y_pred_tr, average="weighted", zero_division=0)

            # ── TEST metrics ─────────────────────────────────────────────────
            acc  = accuracy_score(y_te, y_pred_te)
            prec = precision_score(y_te, y_pred_te, average="weighted", zero_division=0)
            rec  = recall_score(y_te, y_pred_te, average="weighted", zero_division=0)
            f1   = f1_score(y_te, y_pred_te, average="weighted", zero_division=0)
            mcc  = matthews_corrcoef(y_te, y_pred_te)
            kappa= cohen_kappa_score(y_te, y_pred_te)
            cm   = confusion_matrix(y_te, y_pred_te)
            cr   = classification_report(y_te, y_pred_te, zero_division=0)

            # Proba-based metrics
            auc = ap = logloss = brier = None
            if y_proba is not None:
                if is_binary:
                    try: auc     = roc_auc_score(y_te, y_proba[:,1])
                    except: pass
                    try: ap      = average_precision_score(y_te, y_proba[:,1])
                    except: pass
                    try: logloss = log_loss(y_te, y_proba)
                    except: pass
                    try: brier   = brier_score_loss(y_te, y_proba[:,1])
                    except: pass
                else:
                    try: auc = roc_auc_score(y_te, y_proba,
                                              multi_class="ovr", average="weighted")
                    except: pass
                    try: logloss = log_loss(y_te, y_proba)
                    except: pass

            # ── CV metrics ────────────────────────────────────────────────────
            cv_scorer = "roc_auc" if is_binary else "f1_weighted"
            try:
                cv_scores = cross_val_score(model, X, y, cv=cv_obj,
                                            scoring=cv_scorer, n_jobs=-1)
                cv_mean, cv_std = float(cv_scores.mean()), float(cv_scores.std())
            except Exception as e:
                _warn(f"CV failed: {e}"); cv_scores = np.array([]); cv_mean=cv_std=None

            # ── Print summary ─────────────────────────────────────────────────
            _ok(f"  TRAIN  Acc={tr_acc:.4f}  F1={tr_f1:.4f}")
            _ok(f"  TEST   Acc={acc:.4f}  Prec={prec:.4f}  Rec={rec:.4f}  "
                f"F1={f1:.4f}  MCC={mcc:.4f}  Kappa={kappa:.4f}"
                + (f"\n         AUC={auc:.4f}  AP={ap:.4f}  LogLoss={logloss:.4f}"
                   if auc else ""))
            print(cr)
            if cv_mean is not None:
                _ok(f"  CV ({cv_folds}-fold) {cv_scorer}={cv_mean:.4f}±{cv_std:.4f}")

            # ── Store results ─────────────────────────────────────────────────
            results[name] = {
                "train_accuracy": tr_acc, "train_f1": tr_f1,
                "accuracy": acc, "precision": prec, "recall": rec,
                "f1": f1, "mcc": mcc, "kappa": kappa,
                "roc_auc": auc, "avg_precision": ap,
                "log_loss": logloss, "brier_score": brier,
                "cv_mean": cv_mean, "cv_std": cv_std,
                "cv_scores": cv_scores.tolist() if len(cv_scores) else [],
                "confusion_matrix": cm.tolist(),
                "classification_report": cr,
            }

            # ── Save model ────────────────────────────────────────────────────
            pkl_path = str(STAGING / f"{safe}.pkl")
            with open(pkl_path,"wb") as f: pickle.dump(model, f)
            results[name]["model_path"] = pkl_path
            _ok(f"  Model saved: {safe}.pkl")

            # ── CHARTS ────────────────────────────────────────────────────────
            chart_paths = []

            # 1. Confusion matrix
            try:
                fig, ax = plt.subplots(figsize=(max(5, n_cls+1), max(4, n_cls)))
                sns.heatmap(cm, annot=True, fmt="d", cmap="Blues", ax=ax,
                            xticklabels=classes, yticklabels=classes)
                ax.set_title(f"{name} — Confusion Matrix\n"
                             f"Acc={acc:.3f}  F1={f1:.3f}  MCC={mcc:.3f}",
                             fontweight="bold")
                ax.set_ylabel("Actual"); ax.set_xlabel("Predicted")
                fig.tight_layout()
                p = str(STAGING / f"{safe}_cm.png")
                fig.savefig(p, dpi=120, bbox_inches="tight"); plt.close(fig)
                chart_paths.append(p)
            except Exception as e: _warn(f"CM chart: {e}"); plt.close("all")

            # 2. ROC curve
            if y_proba is not None:
                try:
                    if is_binary:
                        fpr, tpr, thr = roc_curve(y_te, y_proba[:,1])
                        fig, ax = plt.subplots(figsize=(6,5))
                        ax.plot(fpr, tpr, "#4C6EF5", lw=2.5,
                                label=f"AUC = {auc:.4f}" if auc else "ROC")
                        ax.fill_between(fpr, tpr, alpha=0.08, color="#4C6EF5")
                        ax.plot([0,1],[0,1],"k--", lw=1)
                        # optimal threshold marker (Youden's J)
                        j = tpr - fpr; best = np.argmax(j)
                        ax.scatter(fpr[best], tpr[best], color="red", zorder=5,
                                   label=f"Best thr={thr[best]:.3f}")
                        ax.set_xlabel("False Positive Rate")
                        ax.set_ylabel("True Positive Rate (Recall)")
                        ax.set_title(f"{name} — ROC Curve", fontweight="bold")
                        ax.legend(); fig.tight_layout()
                        p = str(STAGING / f"{safe}_roc.png")
                        fig.savefig(p, dpi=120, bbox_inches="tight"); plt.close(fig)
                        chart_paths.append(p)
                    else:
                        # One-vs-Rest ROC for multiclass
                        fig, ax = plt.subplots(figsize=(7,5))
                        from sklearn.preprocessing import label_binarize
                        y_te_bin = label_binarize(y_te, classes=classes)
                        for i, cls in enumerate(classes):
                            if y_te_bin.shape[1] > i:
                                fpr_i, tpr_i, _ = roc_curve(y_te_bin[:,i], y_proba[:,i])
                                ax.plot(fpr_i, tpr_i, lw=1.5, label=f"Class {cls}")
                        ax.plot([0,1],[0,1],"k--")
                        ax.set_xlabel("FPR"); ax.set_ylabel("TPR")
                        ax.set_title(f"{name} — ROC Curves (OvR)", fontweight="bold")
                        ax.legend(fontsize=8); fig.tight_layout()
                        p = str(STAGING / f"{safe}_roc.png")
                        fig.savefig(p, dpi=120, bbox_inches="tight"); plt.close(fig)
                        chart_paths.append(p)
                except Exception as e: _warn(f"ROC chart: {e}"); plt.close("all")

            # 3. Precision-Recall curve (binary)
            if is_binary and y_proba is not None:
                try:
                    prec_c, rec_c, _ = precision_recall_curve(y_te, y_proba[:,1])
                    fig, ax = plt.subplots(figsize=(6,5))
                    ax.plot(rec_c, prec_c, "#2F9E44", lw=2.5,
                            label=f"AP = {ap:.4f}" if ap else "PR")
                    ax.fill_between(rec_c, prec_c, alpha=0.08, color="#2F9E44")
                    baseline = float(y_te.mean())
                    ax.axhline(baseline, color="gray", linestyle="--",
                               label=f"Baseline = {baseline:.3f}")
                    ax.set_xlabel("Recall"); ax.set_ylabel("Precision")
                    ax.set_title(f"{name} — Precision-Recall Curve", fontweight="bold")
                    ax.legend(); fig.tight_layout()
                    p = str(STAGING / f"{safe}_pr.png")
                    fig.savefig(p, dpi=120, bbox_inches="tight"); plt.close(fig)
                    chart_paths.append(p)
                except Exception as e: _warn(f"PR chart: {e}"); plt.close("all")

            # 4. Learning curve
            try:
                train_s = np.linspace(0.1, 1.0, 8)
                tr_szs, tr_sc, val_sc = learning_curve(
                    model, X, y, train_sizes=train_s,
                    cv=StratifiedKFold(3, shuffle=True, random_state=42),
                    scoring="f1_weighted", n_jobs=-1
                )
                fig, ax = plt.subplots(figsize=(7,4))
                ax.plot(tr_szs, tr_sc.mean(1), "o-", color="#4C6EF5", label="Train")
                ax.fill_between(tr_szs, tr_sc.mean(1)-tr_sc.std(1),
                                tr_sc.mean(1)+tr_sc.std(1), alpha=0.15, color="#4C6EF5")
                ax.plot(tr_szs, val_sc.mean(1), "s-", color="#F76707", label="CV Val")
                ax.fill_between(tr_szs, val_sc.mean(1)-val_sc.std(1),
                                val_sc.mean(1)+val_sc.std(1), alpha=0.15, color="#F76707")
                ax.set_xlabel("Training set size"); ax.set_ylabel("F1 Score (weighted)")
                ax.set_title(f"{name} — Learning Curve", fontweight="bold")
                ax.legend(); fig.tight_layout()
                p = str(STAGING / f"{safe}_lc.png")
                fig.savefig(p, dpi=120, bbox_inches="tight"); plt.close(fig)
                chart_paths.append(p)
            except Exception as e: _warn(f"Learning curve: {e}"); plt.close("all")

            # 5. CV score distribution (violin/box)
            if len(cv_scores) > 0:
                try:
                    fig, ax = plt.subplots(figsize=(5,3))
                    ax.violinplot(cv_scores, positions=[0], showmedians=True)
                    ax.scatter([0]*len(cv_scores), cv_scores, color="#4C6EF5",
                               alpha=0.7, zorder=5, s=40)
                    ax.axhline(cv_mean, color="red", lw=1.5, linestyle="--",
                               label=f"Mean={cv_mean:.4f}")
                    ax.set_xticks([0]); ax.set_xticklabels([cv_scorer])
                    ax.set_ylabel("Score")
                    ax.set_title(f"{name} — CV Score Distribution ({cv_folds}-fold)",
                                 fontweight="bold")
                    ax.legend(); fig.tight_layout()
                    p = str(STAGING / f"{safe}_cv.png")
                    fig.savefig(p, dpi=120, bbox_inches="tight"); plt.close(fig)
                    chart_paths.append(p)
                except Exception as e: _warn(f"CV violin: {e}"); plt.close("all")

            # 6. Calibration plot (binary)
            if is_binary and y_proba is not None:
                try:
                    prob_true, prob_pred = calibration_curve(y_te, y_proba[:,1], n_bins=10)
                    fig, ax = plt.subplots(figsize=(5,4))
                    ax.plot(prob_pred, prob_true, "s-", color="#4C6EF5",
                            lw=2, label="Model")
                    ax.plot([0,1],[0,1], "k--", label="Perfect calibration")
                    ax.set_xlabel("Mean Predicted Probability")
                    ax.set_ylabel("Fraction of Positives")
                    ax.set_title(f"{name} — Calibration Plot", fontweight="bold")
                    ax.legend(); fig.tight_layout()
                    p = str(STAGING / f"{safe}_cal.png")
                    fig.savefig(p, dpi=120, bbox_inches="tight"); plt.close(fig)
                    chart_paths.append(p)
                except Exception as e: _warn(f"Calibration plot: {e}"); plt.close("all")

            # 7. Predicted-probability histogram (binary)
            if is_binary and y_proba is not None:
                try:
                    fig, ax = plt.subplots(figsize=(6,4))
                    for cls_val, colour in zip(sorted(y_te.unique()),
                                               ["#4C6EF5","#F76707"]):
                        mask = y_te == cls_val
                        ax.hist(y_proba[mask, 1], bins=30, alpha=0.55,
                                color=colour, label=f"Class {cls_val}", density=True)
                    ax.set_xlabel("Predicted Probability (Positive Class)")
                    ax.set_ylabel("Density")
                    ax.set_title(f"{name} — Probability Distribution by Class",
                                 fontweight="bold")
                    ax.legend(); fig.tight_layout()
                    p = str(STAGING / f"{safe}_probhist.png")
                    fig.savefig(p, dpi=120, bbox_inches="tight"); plt.close(fig)
                    chart_paths.append(p)
                except Exception as e: _warn(f"Prob hist: {e}"); plt.close("all")

            charts[name] = chart_paths
            _ok(f"  {len(chart_paths)} evaluation charts saved")

        except Exception as e:
            _warn(f"Training failed for {name}: {e}")
            results[name] = {"error": str(e)}

    log["classification_results"] = results
    log["test_size"]  = test_size
    log["cv_folds"]   = cv_folds
    log["n_train"]    = len(X_tr)
    log["n_test"]     = len(X_te)
    log["classes"]    = classes
    log["is_binary"]  = is_binary

    # ── Multi-model comparison chart ─────────────────────────────────────────
    valid = {n: r for n, r in results.items() if "accuracy" in r}
    if len(valid) > 1:
        try:
            nv   = list(valid.keys())
            metrics_to_plot = {
                "Accuracy":    [valid[n]["accuracy"]   for n in nv],
                "F1 (w)":      [valid[n]["f1"]         for n in nv],
                "Precision":   [valid[n]["precision"]  for n in nv],
                "Recall":      [valid[n]["recall"]     for n in nv],
            }
            if any(valid[n].get("roc_auc") for n in nv):
                metrics_to_plot["ROC-AUC"] = [valid[n].get("roc_auc") or 0 for n in nv]
            if any(valid[n].get("avg_precision") for n in nv):
                metrics_to_plot["Avg Prec"] = [valid[n].get("avg_precision") or 0 for n in nv]

            n_metrics = len(metrics_to_plot)
            x = np.arange(len(nv))
            width = 0.8 / n_metrics
            colors_m = ["#4C6EF5","#2F9E44","#F76707","#E03131","#7950F2","#1098AD"]
            fig, ax = plt.subplots(figsize=(max(12, len(nv)*2), 6))
            for i, (met_name, vals) in enumerate(metrics_to_plot.items()):
                offset = (i - n_metrics/2 + 0.5) * width
                ax.bar(x + offset, vals, width, label=met_name,
                       color=colors_m[i % len(colors_m)], alpha=0.85)
            ax.set_xticks(x)
            ax.set_xticklabels(nv, rotation=30, ha="right", fontsize=10)
            ax.set_ylim(0, 1.05); ax.set_ylabel("Score")
            ax.set_title("Model Comparison — All Classification Metrics",
                         fontweight="bold", fontsize=13)
            ax.legend(loc="lower right"); ax.grid(axis="y", alpha=0.3)
            fig.tight_layout()
            p = str(STAGING / "comparison_classification.png")
            fig.savefig(p, dpi=130, bbox_inches="tight"); plt.close(fig)
            log["comparison_chart"] = p
            _ok("Multi-metric comparison chart saved")
        except Exception as e:
            _warn(f"Comparison chart: {e}"); plt.close("all")

        # Best-model radar chart
        try:
            from matplotlib.patches import FancyArrowPatch
            met_names = ["Accuracy","F1","Precision","Recall","AUC"]
            def _safe(r, k): return r.get(k) or 0
            # Only top 5 models
            top5 = list(valid.keys())[:5]
            angles = np.linspace(0, 2*np.pi, len(met_names), endpoint=False)
            angles = np.concatenate([angles, [angles[0]]])
            fig, ax = plt.subplots(figsize=(7,7), subplot_kw=dict(polar=True))
            for ni, n in enumerate(top5):
                r = valid[n]
                vals_r = [_safe(r,"accuracy"), _safe(r,"f1"),
                          _safe(r,"precision"), _safe(r,"recall"),
                          _safe(r,"roc_auc")]
                vals_r += [vals_r[0]]
                ax.plot(angles, vals_r, lw=2, label=n,
                        color=colors_m[ni % len(colors_m)])
                ax.fill(angles, vals_r, alpha=0.07,
                        color=colors_m[ni % len(colors_m)])
            ax.set_xticks(angles[:-1]); ax.set_xticklabels(met_names, fontsize=11)
            ax.set_ylim(0,1)
            ax.set_title("Model Comparison Radar", fontweight="bold",
                         pad=20, fontsize=13)
            ax.legend(loc="upper right", bbox_to_anchor=(1.3,1.1), fontsize=9)
            fig.tight_layout()
            p = str(STAGING / "comparison_radar.png")
            fig.savefig(p, dpi=120, bbox_inches="tight"); plt.close(fig)
            log["radar_chart"] = p
            _ok("Radar comparison chart saved")
        except Exception as e:
            _warn(f"Radar chart: {e}"); plt.close("all")

    return results, charts


    _banner("STEP 5 · Classification Model Training & Evaluation")

    # Validate target has at least 2 classes
    n_cls = y.nunique()
    if n_cls < 2:
        _warn(f"Target has only {n_cls} unique class(es) — cannot train classifiers.")
        _warn("This usually means the target column was all-NaN and the recovery")
        _warn("from class_label produced only one class (e.g. all 'unknown').")
        _warn("Check that your processed_output.csv has valid target values.")
        # Return empty results so the pipeline continues to report generation
        return {name: {"error": f"Only {n_cls} class(es) in target — need ≥2"}
                for name in models}, {}

    test_size = CFG.f("model","test_size", default=0.2)
    cv_folds  = CFG.i("model","cv_folds",  default=5)
    random_st = 42

    # Train/test split
    n_cls = y.nunique()
    strat = y if n_cls < 50 else None
    X_tr, X_te, y_tr, y_te = train_test_split(
        X, y, test_size=test_size, random_state=random_st, stratify=strat
    )
    _ok(f"Train: {len(X_tr):,}  Test: {len(X_te):,}  (split {100*(1-test_size):.0f}/{100*test_size:.0f})")

    is_binary  = n_cls == 2
    cv_scorer  = "roc_auc" if is_binary else "f1_weighted"
    results    = {}
    charts     = {}

    for name, model in models.items():
        _step(f"Training: {name} …")
        try:
            model.fit(X_tr, y_tr)
            y_pred  = model.predict(X_te)
            y_proba = None
            if hasattr(model, "predict_proba"):
                try: y_proba = model.predict_proba(X_te)
                except: pass

            # Metrics
            acc  = accuracy_score(y_te, y_pred)
            prec = precision_score(y_te, y_pred, average="weighted", zero_division=0)
            rec  = recall_score(y_te, y_pred, average="weighted", zero_division=0)
            f1   = f1_score(y_te, y_pred, average="weighted", zero_division=0)
            cm   = confusion_matrix(y_te, y_pred)
            cr   = classification_report(y_te, y_pred, zero_division=0)

            auc  = None
            if y_proba is not None and is_binary:
                try: auc = roc_auc_score(y_te, y_proba[:,1])
                except: pass
            elif y_proba is not None and not is_binary:
                try: auc = roc_auc_score(y_te, y_proba, multi_class="ovr", average="weighted")
                except: pass

            # Cross-validation
            try:
                cv = StratifiedKFold(n_splits=cv_folds, shuffle=True, random_state=42)
                cv_scores = cross_val_score(model, X, y, cv=cv, scoring=cv_scorer, n_jobs=-1)
                cv_mean, cv_std = float(cv_scores.mean()), float(cv_scores.std())
            except Exception as e:
                _warn(f"CV failed for {name}: {e}"); cv_mean=cv_std=None

            results[name] = {
                "accuracy": acc, "precision": prec, "recall": rec, "f1": f1,
                "roc_auc": auc, "cv_mean": cv_mean, "cv_std": cv_std,
                "confusion_matrix": cm.tolist(), "classification_report": cr,
            }
            _ok(f"  Acc={acc:.4f}  F1={f1:.4f}"
                + (f"  AUC={auc:.4f}" if auc else "")
                + (f"  CV={cv_mean:.4f}±{cv_std:.4f}" if cv_mean else ""))

            # ── Save model ────────────────────────────────────────────────────
            safe_name = name.replace(" ","_").replace("(","").replace(")","").replace("/","_")
            pkl_path  = str(STAGING / f"{safe_name}.pkl")
            with open(pkl_path,"wb") as f: pickle.dump(model, f)
            results[name]["model_path"] = pkl_path
            _ok(f"  Model saved: {pkl_path}")

            # ── Charts ────────────────────────────────────────────────────────
            chart_paths = []

            # Confusion matrix
            try:
                fig, ax = plt.subplots(figsize=(max(4,n_cls), max(3,n_cls-1)))
                sns.heatmap(cm, annot=True, fmt="d", cmap="Blues", ax=ax,
                            xticklabels=sorted(y.unique()),
                            yticklabels=sorted(y.unique()))
                ax.set_title(f"{name}\nConfusion Matrix", fontweight="bold")
                ax.set_ylabel("True"); ax.set_xlabel("Predicted")
                fig.tight_layout()
                p = str(STAGING / f"{safe_name}_cm.png")
                fig.savefig(p, dpi=110, bbox_inches="tight"); plt.close(fig)
                chart_paths.append(p)
            except Exception as e:
                _warn(f"CM chart failed: {e}"); plt.close("all")

            # ROC curve (binary only)
            if is_binary and y_proba is not None:
                try:
                    fpr, tpr, _ = roc_curve(y_te, y_proba[:,1])
                    fig, ax = plt.subplots(figsize=(6,5))
                    ax.plot(fpr, tpr, color="#4C6EF5", lw=2,
                            label=f"AUC = {auc:.4f}" if auc else "ROC")
                    ax.plot([0,1],[0,1],"k--", lw=1)
                    ax.set_xlabel("False Positive Rate"); ax.set_ylabel("True Positive Rate")
                    ax.set_title(f"{name} — ROC Curve", fontweight="bold")
                    ax.legend(); fig.tight_layout()
                    p = str(STAGING / f"{safe_name}_roc.png")
                    fig.savefig(p, dpi=110, bbox_inches="tight"); plt.close(fig)
                    chart_paths.append(p)
                except Exception as e:
                    _warn(f"ROC chart failed: {e}"); plt.close("all")

            charts[name] = chart_paths

        except Exception as e:
            _warn(f"Training failed for {name}: {e}")
            results[name] = {"error": str(e)}

    log["classification_results"] = results
    log["test_size"]  = test_size
    log["cv_folds"]   = cv_folds
    log["n_train"]    = len(X_tr)
    log["n_test"]     = len(X_te)

    # ── Comparative bar chart (Accuracy + F1 + AUC) ───────────────────────────
    try:
        valid = {n: r for n, r in results.items() if "accuracy" in r}
        if len(valid) > 1:
            names_v = list(valid.keys())
            accs    = [valid[n]["accuracy"] for n in names_v]
            f1s     = [valid[n]["f1"]       for n in names_v]
            aucs    = [valid[n]["roc_auc"] or 0 for n in names_v]

            x     = np.arange(len(names_v))
            width = 0.25
            fig, ax = plt.subplots(figsize=(max(10, len(names_v)*1.4), 5))
            ax.bar(x-width, accs, width, label="Accuracy", color="#4C6EF5", alpha=0.85)
            ax.bar(x,       f1s,  width, label="F1 Score", color="#2F9E44", alpha=0.85)
            if any(a>0 for a in aucs):
                ax.bar(x+width, aucs, width, label="ROC-AUC", color="#F76707", alpha=0.85)
            ax.set_xticks(x); ax.set_xticklabels(names_v, rotation=25, ha="right")
            ax.set_ylim(0, 1.05); ax.set_ylabel("Score")
            ax.set_title("Model Comparison — Classification Metrics", fontweight="bold", fontsize=13)
            ax.legend(); fig.tight_layout()
            p = str(STAGING / "comparison_classification.png")
            fig.savefig(p, dpi=120, bbox_inches="tight"); plt.close(fig)
            log["comparison_chart"] = p
            _ok("Comparison chart saved")
    except Exception as e:
        _warn(f"Comparison chart failed: {e}"); plt.close("all")

    return results, charts

# =============================================================================
# STEP 5 — TRAIN/EVALUATE REGRESSION
# =============================================================================
def _train_regression(X: pd.DataFrame, y: pd.Series,
                       models: dict, log: dict) -> dict:
    _banner("STEP 5 · Regression Model Training & Evaluation")

    test_size = CFG.f("model","test_size", default=0.2)
    cv_folds  = CFG.i("model","cv_folds",  default=5)

    X_tr, X_te, y_tr, y_te = train_test_split(
        X, y, test_size=test_size, random_state=42
    )
    _ok(f"Train: {len(X_tr):,}  Test: {len(X_te):,}")

    results = {}
    charts  = {}

    for name, model in models.items():
        _step(f"Training: {name} …")
        try:
            model.fit(X_tr, y_tr)
            y_pred = model.predict(X_te)

            mae  = mean_absolute_error(y_te, y_pred)
            rmse = float(np.sqrt(mean_squared_error(y_te, y_pred)))
            r2   = r2_score(y_te, y_pred)
            try: mape = mean_absolute_percentage_error(y_te, y_pred) * 100
            except: mape = None

            # Cross-validation
            try:
                cv_s = cross_val_score(model, X, y, cv=cv_folds, scoring="r2", n_jobs=-1)
                cv_mean, cv_std = float(cv_s.mean()), float(cv_s.std())
            except: cv_mean=cv_std=None

            results[name] = {
                "mae":mae, "rmse":rmse, "r2":r2, "mape":mape,
                "cv_mean":cv_mean, "cv_std":cv_std,
            }
            _ok(f"  MAE={mae:.4f}  RMSE={rmse:.4f}  R²={r2:.4f}"
                + (f"  CV-R²={cv_mean:.4f}±{cv_std:.4f}" if cv_mean else ""))

            # Save model
            safe_name = name.replace(" ","_").replace("(","").replace(")","").replace("/","_")
            pkl_path  = str(STAGING / f"{safe_name}.pkl")
            with open(pkl_path,"wb") as f: pickle.dump(model, f)
            results[name]["model_path"] = pkl_path

            # Actual vs Predicted chart
            try:
                fig, axes = plt.subplots(1, 2, figsize=(12, 4))
                # Scatter
                axes[0].scatter(y_te, y_pred, alpha=0.4, color="#4C6EF5", s=15)
                mn = min(float(y_te.min()), float(y_pred.min()))
                mx = max(float(y_te.max()), float(y_pred.max()))
                axes[0].plot([mn,mx],[mn,mx],"r--",lw=1.5)
                axes[0].set_xlabel("Actual"); axes[0].set_ylabel("Predicted")
                axes[0].set_title("Actual vs Predicted", fontweight="bold")
                # Residuals
                residuals = y_te - y_pred
                axes[1].scatter(y_pred, residuals, alpha=0.4, color="#F76707", s=15)
                axes[1].axhline(0, color="k", lw=1.5)
                axes[1].set_xlabel("Predicted"); axes[1].set_ylabel("Residual")
                axes[1].set_title("Residual Plot", fontweight="bold")
                fig.suptitle(name, fontweight="bold", fontsize=13)
                fig.tight_layout()
                p = str(STAGING / f"{safe_name}_reg.png")
                fig.savefig(p, dpi=110, bbox_inches="tight"); plt.close(fig)
                charts[name] = [p]
            except Exception as e:
                _warn(f"Chart failed: {e}"); plt.close("all")

        except Exception as e:
            _warn(f"Training failed for {name}: {e}")
            results[name] = {"error": str(e)}

    log["regression_results"] = results
    log["n_train"]  = len(X_tr)
    log["n_test"]   = len(X_te)

    # Comparison chart (R², MAE, RMSE normalised)
    try:
        valid = {n: r for n, r in results.items() if "r2" in r}
        if len(valid) > 1:
            nv   = list(valid.keys())
            r2s  = [valid[n]["r2"]   for n in nv]
            maes = [valid[n]["mae"]  for n in nv]
            rmses= [valid[n]["rmse"] for n in nv]
            x    = np.arange(len(nv)); w = 0.25
            fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(max(12, len(nv)*1.8), 5))
            ax1.bar(x, r2s, color="#4C6EF5", alpha=0.85)
            ax1.set_xticks(x); ax1.set_xticklabels(nv, rotation=25, ha="right")
            ax1.set_ylabel("R² Score"); ax1.set_title("R² Comparison", fontweight="bold")
            ax1.axhline(0, color="k", lw=0.5)
            ax2.bar(x-w/2, maes,  w, label="MAE",  color="#2F9E44", alpha=0.85)
            ax2.bar(x+w/2, rmses, w, label="RMSE", color="#E03131", alpha=0.85)
            ax2.set_xticks(x); ax2.set_xticklabels(nv, rotation=25, ha="right")
            ax2.set_ylabel("Error"); ax2.set_title("MAE vs RMSE", fontweight="bold")
            ax2.legend()
            fig.suptitle("Regression Model Comparison", fontweight="bold", fontsize=13)
            fig.tight_layout()
            p = str(STAGING / "comparison_regression.png")
            fig.savefig(p, dpi=120, bbox_inches="tight"); plt.close(fig)
            log["comparison_chart"] = p
            _ok("Comparison chart saved")
    except Exception as e:
        _warn(f"Comparison chart failed: {e}"); plt.close("all")

    return results, charts

# =============================================================================
# STEP 5 — TRAIN/EVALUATE CLUSTERING
# =============================================================================
def _train_clustering(X: pd.DataFrame, models: dict, log: dict) -> dict:
    _banner("STEP 5 · Clustering Model Training & Evaluation")
    results = {}
    charts  = {}

    for name, model in models.items():
        _step(f"Fitting: {name} …")
        try:
            labels = model.fit_predict(X)
            n_clusters = len(set(labels)) - (1 if -1 in labels else 0)
            n_noise    = int((labels == -1).sum())

            metrics = {"n_clusters": n_clusters, "n_noise": n_noise}
            if n_clusters >= 2 and n_clusters < len(X):
                try:
                    mask = labels != -1
                    metrics["silhouette"]        = float(silhouette_score(X[mask], labels[mask]))
                    metrics["calinski_harabasz"]  = float(calinski_harabasz_score(X[mask], labels[mask]))
                    metrics["davies_bouldin"]     = float(davies_bouldin_score(X[mask], labels[mask]))
                except Exception as e:
                    _warn(f"Metrics failed: {e}")

            results[name] = metrics
            _ok(f"  Clusters={n_clusters}  Noise={n_noise}"
                + (f"  Silhouette={metrics.get('silhouette',0):.4f}" if "silhouette" in metrics else ""))

            # Save model
            safe_name = name.replace(" ","_").replace("(","").replace(")","").replace("/","_")
            pkl_path  = str(STAGING / f"{safe_name}.pkl")
            with open(pkl_path,"wb") as f: pickle.dump(model, f)
            results[name]["model_path"] = pkl_path

            # PCA 2D cluster plot
            try:
                from sklearn.decomposition import PCA
                pca  = PCA(n_components=2, random_state=42)
                X2d  = pca.fit_transform(X)
                fig, ax = plt.subplots(figsize=(7, 5))
                scatter = ax.scatter(X2d[:,0], X2d[:,1], c=labels,
                                     cmap="tab10", alpha=0.5, s=12)
                plt.colorbar(scatter, ax=ax, label="Cluster")
                ax.set_xlabel(f"PC1 ({pca.explained_variance_ratio_[0]*100:.1f}% var)")
                ax.set_ylabel(f"PC2 ({pca.explained_variance_ratio_[1]*100:.1f}% var)")
                ax.set_title(f"{name}\nPCA 2D Cluster View", fontweight="bold")
                fig.tight_layout()
                p = str(STAGING / f"{safe_name}_clusters.png")
                fig.savefig(p, dpi=110, bbox_inches="tight"); plt.close(fig)
                charts[name] = [p]
            except Exception as e:
                _warn(f"Cluster chart failed: {e}"); plt.close("all")

        except Exception as e:
            _warn(f"Fitting failed for {name}: {e}")
            results[name] = {"error": str(e)}

    log["clustering_results"] = results
    return results, charts

# =============================================================================
# STEP 6 — WORD REPORT (using python-docx, consistent with preprocessor)
# =============================================================================
def _rgb(r,g,b): return RGBColor(r,g,b)

def _h(doc, txt, lv=1):
    p = doc.add_heading(txt, level=lv)
    p.alignment = WD_ALIGN_PARAGRAPH.LEFT
    return p

def _row(tbl, cells, hdr=False):
    row = tbl.add_row()
    for i,(txt,w) in enumerate(cells):
        cell = row.cells[i]; cell.text = str(txt)
        if hdr:
            cell.paragraphs[0].runs[0].bold = True
            tc = cell._tc; pr = tc.get_or_add_tcPr()
            s  = OxmlElement("w:shd")
            s.set(qn("w:val"),"clear"); s.set(qn("w:color"),"auto")
            s.set(qn("w:fill"),"1F3864"); pr.append(s)
            cell.paragraphs[0].runs[0].font.color.rgb = RGBColor(255,255,255)
        cell.paragraphs[0].paragraph_format.space_before = Pt(2)
        cell.paragraphs[0].paragraph_format.space_after  = Pt(2)

def _img(doc, path, w=Inches(5.5)):
    try:
        doc.add_picture(path, width=w)
    except Exception as e:
        doc.add_paragraph(f"[Chart unavailable: {e}]")

def _generate_report(log: dict, results: dict, charts: dict,
                     feature_importance: dict) -> str:
    _banner("STEP 6 · Generating Word Report")
    doc = Document()

    # Page setup
    for sec in doc.sections:
        sec.left_margin = sec.right_margin = Inches(1)
        sec.top_margin  = sec.bottom_margin = Inches(1)

    # Title page
    p = doc.add_paragraph(); p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    r = p.add_run("ML Model Training Report")
    r.bold = True; r.font.size = Pt(24); r.font.color.rgb = _rgb(31,56,100)
    doc.add_paragraph()
    sub = doc.add_paragraph(); sub.alignment = WD_ALIGN_PARAGRAPH.CENTER
    sub.add_run(
        f"Source CSV: {log.get('csv_path','N/A')}\n"
        f"Target: {log.get('target','N/A')}  |  Type: {log.get('model_type','N/A')}\n"
        f"Models: {', '.join(log.get('selected_models',[]))}\n"
        f"Generated: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}"
    ).font.size = Pt(11)
    doc.add_page_break()

    # 1. Summary
    _h(doc, "1. Executive Summary")
    mt = log.get("model_type","N/A")
    doc.add_paragraph(
        f"This report documents the training, evaluation, and comparison of "
        f"{len(log.get('selected_models',[]))} {mt} model(s) on the dataset "
        f"'{Path(log.get('csv_path','N/A')).name}'. "
        f"The dataset contains {log.get('n_rows',0):,} rows and "
        f"{log.get('n_features',0)} features after preprocessing. "
        f"An 80/20 train-test split was used with {log.get('cv_folds',5)}-fold "
        f"cross-validation."
    )

    # Summary metrics table
    tbl = doc.add_table(rows=1, cols=2); tbl.style = "Table Grid"
    _row(tbl,[("Parameter",4500),("Value",4500)], hdr=True)
    entries = [
        ("Input CSV",          log.get("csv_path","N/A")),
        ("Target column",      log.get("target","N/A")),
        ("Model type",         log.get("model_type","N/A")),
        ("Total samples",      f"{log.get('n_rows',0):,}"),
        ("Features",           str(log.get("n_features",0))),
        ("Train samples",      f"{log.get('n_train',0):,}"),
        ("Test samples",       f"{log.get('n_test',0):,}"),
        ("CV folds",           str(log.get("cv_folds",5))),
        ("Models trained",     str(len(log.get("selected_models",[])))),
    ]
    for k,v in entries: _row(tbl,[(k,4500),(v,4500)])
    doc.add_paragraph()

    # 2. Feature Selection
    _h(doc, "2. Feature Selection & Importance")
    doc.add_paragraph(
        "Five feature selection methods were applied: Mutual Information, "
        "F-Statistic, Random Forest Importance, Permutation Importance, and "
        "Recursive Feature Elimination (RFE). Scores were normalised to [0,1] "
        "and averaged to produce the aggregated importance ranking below."
    )
    if feature_importance:
        fi_chart = log.get("feature_importance_chart")
        if fi_chart and Path(fi_chart).exists():
            _img(doc, fi_chart, w=Inches(6.0))
            doc.add_paragraph()
        # Table of top 20
        top_n = min(20, len(feature_importance))
        tbl2 = doc.add_table(rows=1, cols=3); tbl2.style = "Table Grid"
        _row(tbl2,[("Rank",1000),("Feature",5000),("Agg. Score",2000)], hdr=True)
        for rank,(feat,score) in enumerate(list(feature_importance.items())[:top_n],1):
            _row(tbl2,[(str(rank),1000),(feat,5000),(f"{score:.4f}",2000)])
        doc.add_paragraph()

        # Method breakdown
        _h(doc,"2b. Scores by Method",2)
        for method, scores in log.get("feature_selection",{}).items():
            _h(doc, method, 3)
            tbl_m = doc.add_table(rows=1, cols=2); tbl_m.style = "Table Grid"
            _row(tbl_m,[("Feature",5500),("Score",2500)], hdr=True)
            for feat, score in list(scores.items())[:15]:
                _row(tbl_m,[(feat,5500),(f"{score:.4f}",2500)])
            doc.add_paragraph()

    # 3. Model Results
    _h(doc, "3. Model Training & Evaluation")

    if mt == "classification":
        _classification_report_section(doc, results, charts, log)
    elif mt == "regression":
        _regression_report_section(doc, results, charts, log)
    else:
        _clustering_report_section(doc, results, charts, log)

    # 4. Comparative Summary (if multiple models)
    valid_results = {n:r for n,r in results.items() if "error" not in r}
    if len(valid_results) > 1:
        _h(doc, "4. Comparative Model Summary")
        cmp_chart = log.get("comparison_chart")
        if cmp_chart and Path(cmp_chart).exists():
            _img(doc, cmp_chart, w=Inches(6.5)); doc.add_paragraph()
        _build_comparison_table(doc, valid_results, mt)

    # 5. Important Features summary
    _h(doc, "5. Most Important Features")
    if feature_importance:
        top15 = list(feature_importance.items())[:15]
        doc.add_paragraph(
            f"The following {len(top15)} features were ranked most important "
            "across all feature selection methods:"
        )
        tbl3 = doc.add_table(rows=1, cols=3); tbl3.style = "Table Grid"
        _row(tbl3,[("Rank",800),("Feature Name",5500),("Importance Score",2000)], hdr=True)
        for rank,(feat,score) in enumerate(top15,1):
            importance_level = "HIGH" if score>0.6 else "MEDIUM" if score>0.3 else "LOW"
            _row(tbl3,[(str(rank),800),(feat,5500),(f"{score:.4f}  [{importance_level}]",2000)])
        doc.add_paragraph()
        doc.add_paragraph(
            "Features with score > 0.6 are considered HIGH importance, "
            "0.3–0.6 MEDIUM, and < 0.3 LOW importance. "
            "Consider focusing on HIGH importance features for model simplification."
        )

    # 6. Recommendations
    _h(doc, "6. Recommendations & Next Steps")
    recs = _build_recommendations(valid_results, mt, feature_importance)
    for rec in recs: doc.add_paragraph(rec, style="List Bullet")

    # 7. Artifacts
    _h(doc, "7. Saved Artifacts")
    doc.add_paragraph("All artifacts are saved to the output directory and GCS bucket:")
    tbl4 = doc.add_table(rows=1, cols=3); tbl4.style = "Table Grid"
    _row(tbl4,[("File",4000),("Type",2000),("Description",3000)], hdr=True)
    for n,r in results.items():
        if "model_path" in r:
            safe = n.replace(" ","_").replace("(","").replace(")","").replace("/","_")
            _row(tbl4,[(f"{safe}.pkl",4000),("Pickle",2000),(f"Trained {n} model",3000)])
    _row(tbl4,[("scaler.pkl",4000),("Pickle",2000),("StandardScaler fitted on training data",3000)])
    _row(tbl4,[(f"model_training_code.py",4000),("Python",2000),("Complete training script",3000)])
    _row(tbl4,[("ML_Model_Report.docx",4000),("Report",2000),("This document",3000)])
    doc.add_paragraph()

    out_path = str(STAGING / "ML_Model_Report.docx")
    doc.save(out_path)
    _ok(f"Report saved: {out_path}")
    return out_path


def _classification_report_section(doc, results, charts, log):
    comp_tbl = doc.add_table(rows=1, cols=7); comp_tbl.style = "Table Grid"
    _row(comp_tbl,[
        ("Model",3000),("Accuracy",1200),("Precision",1200),
        ("Recall",1200),("F1",1200),("ROC-AUC",1200),("CV Score",1200)
    ], hdr=True)
    for name, r in results.items():
        if "error" in r:
            _row(comp_tbl,[(name,3000),("ERROR",1200),("",""),("",""),("",""),("",""),("","")]); continue
        _row(comp_tbl,[
            (name,3000),
            (f"{r.get('accuracy',0):.4f}",1200),
            (f"{r.get('precision',0):.4f}",1200),
            (f"{r.get('recall',0):.4f}",1200),
            (f"{r.get('f1',0):.4f}",1200),
            (f"{r.get('roc_auc',0):.4f}" if r.get('roc_auc') else "N/A",1200),
            (f"{r.get('cv_mean',0):.4f}±{r.get('cv_std',0):.4f}" if r.get('cv_mean') else "N/A",1200),
        ])
    doc.add_paragraph()

    for name, r in results.items():
        _h(doc, f"3. {name}", 2)
        if "error" in r:
            doc.add_paragraph(f"Training failed: {r['error']}"); continue
        doc.add_paragraph(
            f"Accuracy: {r.get('accuracy',0):.4f}  |  "
            f"F1: {r.get('f1',0):.4f}  |  "
            f"ROC-AUC: {r.get('roc_auc','N/A')}"
        )
        cr_text = r.get("classification_report","")
        if cr_text:
            p = doc.add_paragraph()
            run = p.add_run(cr_text)
            run.font.name = "Courier New"; run.font.size = Pt(8)
        for chart in charts.get(name, []):
            if Path(chart).exists():
                _img(doc, chart, w=Inches(5.0)); doc.add_paragraph()


def _regression_report_section(doc, results, charts, log):
    comp_tbl = doc.add_table(rows=1, cols=7); comp_tbl.style = "Table Grid"
    _row(comp_tbl,[
        ("Model",3500),("MAE",1200),("RMSE",1200),("R²",1200),
        ("MAPE%",1200),("CV R²",1200),("CV Std",1200)
    ], hdr=True)
    for name, r in results.items():
        if "error" in r:
            _row(comp_tbl,[(name,3500),("ERROR",""),("",""),("",""),("",""),("",""),("","")]); continue
        _row(comp_tbl,[
            (name,3500),
            (f"{r.get('mae',0):.4f}",1200),(f"{r.get('rmse',0):.4f}",1200),
            (f"{r.get('r2',0):.4f}",1200),
            (f"{r.get('mape',0):.2f}%" if r.get('mape') else "N/A",1200),
            (f"{r.get('cv_mean',0):.4f}" if r.get('cv_mean') else "N/A",1200),
            (f"{r.get('cv_std',0):.4f}" if r.get('cv_std') else "N/A",1200),
        ])
    doc.add_paragraph()
    for name, r in results.items():
        _h(doc, f"3. {name}", 2)
        if "error" in r: doc.add_paragraph(f"Training failed: {r['error']}"); continue
        doc.add_paragraph(f"MAE: {r.get('mae',0):.4f}  |  RMSE: {r.get('rmse',0):.4f}  |  R²: {r.get('r2',0):.4f}")
        for chart in charts.get(name, []):
            if Path(chart).exists(): _img(doc, chart, w=Inches(6.0)); doc.add_paragraph()


def _clustering_report_section(doc, results, charts, log):
    comp_tbl = doc.add_table(rows=1, cols=6); comp_tbl.style = "Table Grid"
    _row(comp_tbl,[
        ("Model",3000),("Clusters",1200),("Silhouette",1500),
        ("Calinski-H",1500),("Davies-B",1500),("Noise pts",1200)
    ], hdr=True)
    for name, r in results.items():
        if "error" in r:
            _row(comp_tbl,[(name,3000),("ERROR",""),("",""),("",""),("",""),("","")]); continue
        _row(comp_tbl,[
            (name,3000),
            (str(r.get("n_clusters","N/A")),1200),
            (f"{r.get('silhouette',0):.4f}" if "silhouette" in r else "N/A",1500),
            (f"{r.get('calinski_harabasz',0):.2f}" if "calinski_harabasz" in r else "N/A",1500),
            (f"{r.get('davies_bouldin',0):.4f}" if "davies_bouldin" in r else "N/A",1500),
            (str(r.get("n_noise",0)),1200),
        ])
    doc.add_paragraph()
    for name, r in results.items():
        _h(doc, f"3. {name}", 2)
        if "error" in r: doc.add_paragraph(f"Failed: {r['error']}"); continue
        doc.add_paragraph(
            f"Clusters: {r.get('n_clusters','N/A')}  |  "
            f"Silhouette: {r.get('silhouette','N/A')}  |  "
            f"Davies-Bouldin: {r.get('davies_bouldin','N/A')}"
        )
        for chart in charts.get(name, []):
            if Path(chart).exists(): _img(doc, chart, w=Inches(5.5)); doc.add_paragraph()


def _build_comparison_table(doc, results, mt):
    if mt == "classification":
        names_v = list(results.keys())
        best_acc = max(names_v, key=lambda n: results[n].get("accuracy",0))
        best_f1  = max(names_v, key=lambda n: results[n].get("f1",0))
        best_auc = max(names_v, key=lambda n: results[n].get("roc_auc") or 0)
        doc.add_paragraph(f"Best Accuracy : {best_acc}  ({results[best_acc]['accuracy']:.4f})")
        doc.add_paragraph(f"Best F1 Score : {best_f1}  ({results[best_f1]['f1']:.4f})")
        if results[best_auc].get("roc_auc"):
            doc.add_paragraph(f"Best ROC-AUC  : {best_auc}  ({results[best_auc]['roc_auc']:.4f})")
    elif mt == "regression":
        names_v = list(results.keys())
        best_r2   = max(names_v, key=lambda n: results[n].get("r2",  -999))
        best_mae  = min(names_v, key=lambda n: results[n].get("mae",  999))
        best_rmse = min(names_v, key=lambda n: results[n].get("rmse", 999))
        doc.add_paragraph(f"Best R²   : {best_r2}    ({results[best_r2]['r2']:.4f})")
        doc.add_paragraph(f"Lowest MAE  : {best_mae}  ({results[best_mae]['mae']:.4f})")
        doc.add_paragraph(f"Lowest RMSE : {best_rmse}  ({results[best_rmse]['rmse']:.4f})")
    else:
        names_v = [n for n,r in results.items() if "silhouette" in r]
        if names_v:
            best_s = max(names_v, key=lambda n: results[n].get("silhouette",0))
            doc.add_paragraph(f"Best Silhouette: {best_s}  ({results[best_s]['silhouette']:.4f})")
    doc.add_paragraph()


def _build_recommendations(results, mt, feature_importance):
    recs = []
    valid = {n:r for n,r in results.items() if "error" not in r}
    if not valid: return ["No valid results to recommend from."]

    if mt == "classification":
        best = max(valid, key=lambda n: valid[n].get("f1",0))
        recs.append(f"Recommended model: {best} "
                    f"(F1={valid[best].get('f1',0):.4f}, "
                    f"Accuracy={valid[best].get('accuracy',0):.4f})")
        recs.append("Perform hyperparameter tuning (GridSearchCV / Optuna) on the top model.")
        recs.append("Consider class imbalance handling (SMOTE, class_weight) if classes are unequal.")
    elif mt == "regression":
        best = max(valid, key=lambda n: valid[n].get("r2",-999))
        recs.append(f"Recommended model: {best} (R²={valid[best].get('r2',0):.4f})")
        recs.append("Check residual plots for heteroscedasticity and non-linearity.")
        recs.append("Try polynomial features or log-transform the target for skewed distributions.")
    else:
        if any("silhouette" in r for r in valid.values()):
            best = max(valid, key=lambda n: valid[n].get("silhouette",0))
            recs.append(f"Recommended clustering: {best} "
                        f"(Silhouette={valid[best].get('silhouette',0):.4f})")
        recs.append("Validate cluster assignments with domain knowledge.")
        recs.append("Try different k values and use Elbow / Silhouette plots to pick optimal k.")

    if feature_importance:
        low_feat = [f for f,s in feature_importance.items() if s < 0.2]
        if low_feat:
            recs.append(f"Consider removing {len(low_feat)} low-importance features: {low_feat[:5]}{'…' if len(low_feat)>5 else ''}")
    recs.append("Use the saved .pkl files for model deployment. Always apply the same scaler.pkl before inference.")
    recs.append("Re-train periodically as data distribution may drift over time.")
    return recs




# =============================================================================
# STEP 7 — AI-POWERED TRAINING SCRIPT GENERATION
# Works both LOCALLY (Ollama, LM Studio, Anthropic Claude API) and on GCP
# (Vertex AI / Gemini 2.5 Pro with ADC — no API key needed).
#
# Priority order:
#   1. Ollama          — local, free, no internet required
#   2. LM Studio / LocalAI / any OpenAI-compatible local server
#   3. Anthropic Claude API  — cloud, requires ANTHROPIC_API_KEY
#   4. Vertex AI REST  — GCP, requires ADC + project ID
#   5. Vertex AI SDK   — GCP, requires google-cloud-aiplatform
#   6. Static template — always available, no LLM needed
# =============================================================================

def _build_gemini_prompt(log: dict, results: dict,
                          feature_importance: dict) -> str:
    """
    Build a rich, structured prompt that works with ANY LLM — local or cloud.
    Contains full dataset context so the generated script is specific to the
    actual data, features, models, and results.
    """
    mt         = log.get("model_type", "classification")
    target     = log.get("target", "target")
    csv_path   = log.get("csv_path", "processed_output.csv")
    id_cols    = log.get("id_cols", [])
    feat_names = log.get("feature_names", [])
    selected   = log.get("selected_models", [])
    test_size  = log.get("test_size", 0.2)
    cv_folds   = log.get("cv_folds", 5)
    n_rows     = log.get("n_rows", 0)
    n_features = log.get("n_features", 0)
    n_train    = log.get("n_train", 0)
    n_test     = log.get("n_test", 0)
    gcs_bucket = log.get("gcs_bucket", "")
    gcs_folder = log.get("gcs_folder", "models")

    top_feats = list(feature_importance.items())[:15] if feature_importance else []
    feat_str  = "\n".join(
        f"  {i+1:>2}. {f:<42} score={s:.4f}  "
        f"[{'HIGH' if s>0.6 else 'MEDIUM' if s>0.3 else 'LOW'}]"
        for i,(f,s) in enumerate(top_feats)
    ) or "  (not available)"

    results_str = ""
    for name, r in results.items():
        if "error" in r:
            results_str += f"\n  {name}: FAILED — {r['error']}"
            continue
        if mt == "classification":
            results_str += (
                f"\n  {name}:"
                f"  acc={r.get('accuracy',0):.4f}"
                f"  f1={r.get('f1',0):.4f}"
                + (f"  auc={r.get('roc_auc',0):.4f}" if r.get('roc_auc') else "")
                + (f"  cv={r.get('cv_mean',0):.4f}" if r.get('cv_mean') else "")
            )
        elif mt == "regression":
            results_str += (
                f"\n  {name}:"
                f"  mae={r.get('mae',0):.4f}"
                f"  rmse={r.get('rmse',0):.4f}"
                f"  r2={r.get('r2',0):.4f}"
            )
        else:
            results_str += (
                f"\n  {name}: clusters={r.get('n_clusters','N/A')}"
                + (f"  silhouette={r.get('silhouette',0):.4f}" if r.get('silhouette') else "")
            )

    gcs_note = (
        f"GCS bucket : {gcs_bucket}\nGCS folder : {gcs_folder}\n"
        f"Upload all outputs to gs://{gcs_bucket}/{gcs_folder}/"
        if gcs_bucket else
        "GCS: not configured — save everything locally to ./ml_output/<timestamp>/"
    )

    metric_guide = {
        "classification": (
            "accuracy, precision (weighted), recall (weighted), F1 (weighted), "
            "ROC-AUC (binary: per-class proba; multiclass: OvR weighted), "
            "MCC, Cohen Kappa, Log-Loss, Brier Score, Average Precision, "
            "confusion matrix heatmap, ROC curve, Precision-Recall curve, "
            "Learning curve, Calibration plot, CV violin plot, "
            "stratified K-fold cross-validation"
        ),
        "regression": (
            "MAE, RMSE, R², MAPE, "
            "K-fold cross-validation (scoring=r2), "
            "actual-vs-predicted scatter, residual plot"
        ),
        "clustering": (
            "silhouette score, Calinski-Harabász, Davies-Bouldin, "
            "noise points (DBSCAN), PCA 2D scatter coloured by cluster"
        ),
    }.get(mt, "")

    return f"""You are a senior ML engineer. Generate a COMPLETE, PRODUCTION-READY Python script.

The script must be runnable immediately:  python model_training_code.py

==========================================================================
DATASET
==========================================================================
CSV file        : {csv_path}
Target column   : {target}
Model type      : {mt}
Rows            : {n_rows:,}
Features        : {n_features}  →  {feat_names}
Drop these cols : {id_cols + ['class_label', 'prediction']}
Train/Test split: {100*(1-test_size):.0f}/{100*test_size:.0f}  (train={n_train:,}  test={n_test:,})
CV folds        : {cv_folds}

==========================================================================
MODELS TO IMPLEMENT  (train ALL of them)
==========================================================================
{chr(10).join(f'  • {m}' for m in selected)}

==========================================================================
FEATURE IMPORTANCE  (top 15)
==========================================================================
{feat_str}

==========================================================================
RESULTS FROM THIS RUN
==========================================================================
{results_str or '  (not available — train from scratch)'}

==========================================================================
OUTPUT
==========================================================================
{gcs_note}
Subfolder layout:
  models/  ← .pkl for each model + scaler.pkl
  charts/  ← all .png evaluation charts
  report/  ← ML_Model_Report.docx + results.json
  code/    ← this script itself

==========================================================================
REQUIRED SECTIONS
==========================================================================
1. IMPORTS — all libraries; try/except for google-cloud-storage
2. CONFIGURATION — CSV_PATH, TARGET_COL, ID_COLS, MODEL_TYPE, TEST_SIZE,
   CV_FOLDS, RANDOM_STATE=42, GCS_BUCKET, GCS_FOLDER, OUTPUT_DIR
3. DATA LOADING — read CSV, drop ID/meta cols, recover target from
   class_label if target is all-NaN (LabelEncoder fallback)
4. PREPROCESSING — convert bool/object cols, fill NaN with median,
   StandardScaler → save scaler.pkl
5. FEATURE SELECTION — Mutual Info, F-stat, RF importance, Permutation,
   RFE — normalise [0,1], average, print ranked table, save bar chart
6. TRAIN/TEST SPLIT — stratified for classification
7. MODEL TRAINING & EVALUATION — for each model:
   Metrics for {mt}: {metric_guide}
   Save: evaluation charts (.png), trained model (.pkl)
8. COMPARATIVE ANALYSIS — side-by-side table + bar chart (multiple models)
   Print best model with reason
9. IMPORTANT FEATURES REPORT — top 15 with score and HIGH/MEDIUM/LOW label
10. WORD REPORT — python-docx with title page, summary table, feature
    importance chart, per-model sections, comparative summary, top features
11. SAVE & UPLOAD — copy script to code/, save results.json, upload to GCS
    if GCS_BUCKET is set (use google.cloud.storage if available)

==========================================================================
CODING STANDARDS
==========================================================================
- Python 3.10+; every section has a clear header comment
- Wrap all operations in try/except with clear messages
- Print ✔ success, ⚠ warnings, ✘ errors
- Constants at top — no magic values inside functions
- if __name__ == "__main__": guard at bottom
- Only use: scikit-learn, pandas, numpy, matplotlib, seaborn, python-docx,
  pickle, json, pathlib, datetime, google-cloud-storage (optional), warnings

==========================================================================
OUTPUT FORMAT
==========================================================================
Return ONLY raw Python code.
Do NOT include markdown, no ```python fences, no explanations.
Start with exactly:  #!/usr/bin/env python3
End with the last line of Python code.
""".strip()


# ── LLM caller implementations ─────────────────────────────────────────────

def _call_ollama(prompt: str, model: str = "", host: str = "") -> str:
    """
    Call a local Ollama instance.
    Requires: ollama running locally  (ollama serve)
    Model:    llama3, mistral, codellama, deepseek-coder, phi3, gemma2, etc.
    Install:  https://ollama.com  (free, runs on CPU or GPU)
    """
    import urllib.request, json as _j
    host  = host or "http://localhost:11434"
    model = model or "llama3"
    _step(f"Calling Ollama @ {host}  model={model} …")
    payload = _j.dumps({
        "model":  model,
        "prompt": prompt,
        "stream": False,
        "options": {"temperature": 0.2, "num_predict": 8192},
    }).encode("utf-8")
    req = urllib.request.Request(
        f"{host}/api/generate",
        data=payload,
        headers={"Content-Type": "application/json"},
        method="POST",
    )
    with urllib.request.urlopen(req, timeout=600) as resp:
        data = _j.loads(resp.read().decode("utf-8"))
    text = data.get("response", "")
    if not text:
        raise ValueError(f"Empty Ollama response: {data}")
    return text


def _call_openai_compatible(prompt: str, base_url: str,
                             model: str, api_key: str = "local") -> str:
    """
    Call any OpenAI-compatible local server.
    Works with: LM Studio, Jan, LocalAI, Koboldcpp, text-generation-webui,
                vLLM, llama.cpp with --api flag, and many more.
    No internet needed — runs entirely on your machine.
    """
    import urllib.request, json as _j
    payload = _j.dumps({
        "model": model,
        "messages": [{"role": "user", "content": prompt}],
        "temperature": 0.2,
        "max_tokens": 8192,
    }).encode("utf-8")
    req = urllib.request.Request(
        f"{base_url.rstrip('/')}/chat/completions",
        data=payload,
        headers={
            "Content-Type":  "application/json",
            "Authorization": f"Bearer {api_key}",
        },
        method="POST",
    )
    with urllib.request.urlopen(req, timeout=600) as resp:
        data = _j.loads(resp.read().decode("utf-8"))
    choices = data.get("choices", [])
    if not choices:
        raise ValueError(f"No choices in response: {data}")
    return choices[0]["message"]["content"]


def _call_anthropic(prompt: str, api_key: str,
                    model: str = "claude-opus-4-5") -> str:
    """
    Call Anthropic Claude API.
    Requires: ANTHROPIC_API_KEY environment variable or gemini.anthropic_api_key in config.
    Models: claude-opus-4-5, claude-sonnet-4-5, claude-haiku-4-5-20251001
    """
    import urllib.request, json as _j
    payload = _j.dumps({
        "model":      model,
        "max_tokens": 8192,
        "messages":   [{"role": "user", "content": prompt}],
    }).encode("utf-8")
    req = urllib.request.Request(
        "https://api.anthropic.com/v1/messages",
        data=payload,
        headers={
            "Content-Type":      "application/json",
            "x-api-key":         api_key,
            "anthropic-version": "2023-06-01",
        },
        method="POST",
    )
    with urllib.request.urlopen(req, timeout=300) as resp:
        data = _j.loads(resp.read().decode("utf-8"))
    content = data.get("content", [])
    if not content:
        raise ValueError(f"Empty Anthropic response: {data}")
    return content[0]["text"]


def _get_adc_token() -> str:
    """Get OAuth2 ADC token for Vertex AI (GCP only)."""
    try:
        import google.auth
        import google.auth.transport.requests
        credentials, _ = google.auth.default(
            scopes=["https://www.googleapis.com/auth/cloud-platform"]
        )
        request = google.auth.transport.requests.Request()
        credentials.refresh(request)
        return credentials.token
    except Exception as e:
        raise RuntimeError(
            f"ADC token fetch failed: {e}\n"
            "Fix: gcloud auth application-default login"
        ) from e


def _call_vertex_rest(prompt: str, project: str,
                      location: str = "us-central1") -> str:
    """Call Gemini 2.5 Pro on Vertex AI via REST + ADC token (GCP only)."""
    import urllib.request, json as _j
    token    = _get_adc_token()
    endpoint = (
        f"https://{location}-aiplatform.googleapis.com/v1/"
        f"projects/{project}/locations/{location}/"
        f"publishers/google/models/gemini-2.5-pro:generateContent"
    )
    payload  = _j.dumps({
        "contents": [{"role": "user", "parts": [{"text": prompt}]}],
        "generationConfig": {
            "temperature": 0.2, "maxOutputTokens": 8192, "candidateCount": 1
        },
    }).encode("utf-8")
    req = urllib.request.Request(
        endpoint, data=payload,
        headers={"Content-Type": "application/json; charset=utf-8",
                 "Authorization": f"Bearer {token}"},
        method="POST",
    )
    with urllib.request.urlopen(req, timeout=300) as resp:
        data = _j.loads(resp.read().decode("utf-8"))
    candidates = data.get("candidates", [])
    if not candidates:
        raise ValueError(f"No candidates in response: {data}")
    parts = candidates[0].get("content", {}).get("parts", [])
    if not parts:
        raise ValueError(f"No parts in candidate")
    return parts[0].get("text", "")


def _call_vertex_sdk(prompt: str, project: str,
                     location: str = "us-central1") -> str:
    """Call Gemini 2.5 Pro via Vertex AI SDK (GCP only)."""
    import vertexai
    from vertexai.generative_models import GenerativeModel, GenerationConfig
    vertexai.init(project=project, location=location)
    model = GenerativeModel("gemini-2.5-pro")
    cfg   = GenerationConfig(temperature=0.2, max_output_tokens=8192)
    resp  = model.generate_content(prompt, generation_config=cfg)
    return resp.text


def _clean_code(raw: str) -> str | None:
    """Strip markdown fences and validate Python syntax. Returns None on fail."""
    code = raw.strip()
    if code.startswith("```"):
        body = code.splitlines()
        s = 1
        e = len(body)
        for i in range(len(body) - 1, -1, -1):
            if body[i].strip() == "```":
                e = i; break
        code = "\n".join(body[s:e]).strip()
    import ast
    try:
        ast.parse(code)
        return code
    except SyntaxError as se:
        _warn(f"Syntax error in generated code (line {se.lineno}): {se.msg}")
        return None


def _generate_training_script(log: dict, results: dict,
                               feature_importance: dict) -> tuple[str, str]:
    """
    Generate a complete ML training script using an LLM.

    LOCAL (no GCP / no internet required):
    ───────────────────────────────────────
      1. Ollama          — free, runs on CPU/GPU
                           Install: https://ollama.com
                           Setup:   ollama pull llama3 && ollama serve
                           Config:  gemini.local_llm: "ollama"
                                    gemini.ollama_model: "llama3"

      2. LM Studio / LocalAI / Jan / llama.cpp
                           Any OpenAI-compatible local server
                           Config:  gemini.local_llm: "openai_compatible"
                                    gemini.local_base_url: "http://localhost:1234/v1"
                                    gemini.local_model: "model-name"

    CLOUD (internet required):
    ───────────────────────────
      3. Anthropic Claude — fast, high quality
                           Config:  gemini.anthropic_api_key: "sk-ant-..."
                                    OR env var: ANTHROPIC_API_KEY

      4. Vertex AI (GCP)  — Gemini 2.5 Pro, billed to your GCP project
                           Config:  gemini.vertex_project: "my-gcp-project"
                           Setup:   gcloud auth application-default login

    ALWAYS AVAILABLE:
    ─────────────────
      5. Static template  — no LLM; generates solid equivalent code
    """
    _banner("STEP 7 · AI Training Script Generation")

    # ── Read all LLM config ───────────────────────────────────────────────────
    local_llm      = CFG.s("gemini","local_llm")       or ""    # ollama | openai_compatible
    ollama_host    = CFG.s("gemini","ollama_host")      or "http://localhost:11434"
    ollama_model   = CFG.s("gemini","ollama_model")     or "llama3"
    local_base_url = CFG.s("gemini","local_base_url")   or "http://localhost:1234/v1"
    local_model    = CFG.s("gemini","local_model")      or ""
    anthropic_key  = (CFG.s("gemini","anthropic_api_key") or
                      os.environ.get("ANTHROPIC_API_KEY",""))
    anthropic_model= CFG.s("gemini","anthropic_model")  or "claude-opus-4-5"
    vertex_project = (CFG.s("gemini","vertex_project")  or
                      CFG.s("bigquery","project_id")    or
                      os.environ.get("GOOGLE_CLOUD_PROJECT","") or
                      os.environ.get("GCLOUD_PROJECT",""))
    vertex_location= CFG.s("gemini","vertex_location")  or "us-central1"

    env_mode = ENV.resolve()

    # Print what's configured
    print(f"\n  {B}LLM options detected:{RST}")
    if local_llm == "ollama":
        print(f"  {G}★{RST}  Ollama ({ollama_host})  model={ollama_model}  ← will try first")
    elif local_llm == "openai_compatible":
        print(f"  {G}★{RST}  OpenAI-compatible ({local_base_url})  model={local_model}  ← will try first")
    if anthropic_key:
        print(f"  {G}✔{RST}  Anthropic Claude ({anthropic_model})")
    if vertex_project and env_mode == "gcp":
        print(f"  {G}✔{RST}  Vertex AI / Gemini 2.5 Pro  project={vertex_project}")
    if not any([local_llm, anthropic_key, (vertex_project and env_mode=="gcp")]):
        print(f"  {Y}–{RST}  No LLM configured — will use static template")
        print(f"  {C}Tip: add to pipeline_config.yaml:")
        print(f"    gemini:")
        print(f"      local_llm: \"ollama\"        # free, local")
        print(f"      ollama_model: \"llama3\"     # or mistral, codellama, phi3 ...")
        print(f"    OR")
        print(f"      anthropic_api_key: \"sk-ant-...\"  # cloud{RST}")

    # ── Build prompt ──────────────────────────────────────────────────────────
    prompt = _build_gemini_prompt(log, results, feature_importance)
    _step(f"Prompt: {len(prompt):,} chars | "
          f"{len(log.get('selected_models',[]))} models | "
          f"{log.get('n_features', 0)} features")

    prompt_path = str(STAGING / "llm_prompt.txt")
    with open(prompt_path, "w", encoding="utf-8") as f:
        f.write(
            f"# pymlpipeline — LLM Training Script Prompt\n"
            f"# LLM config  : {local_llm or anthropic_key and 'anthropic' or vertex_project and 'vertex' or 'none'}\n"
            f"# Generated   : {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n"
            f"# {'='*60}\n\n" + prompt
        )
    _ok(f"Prompt saved: {prompt_path}")

    generated_code = None
    method_used    = ""

    # ── Method 1: Ollama (local, free) ────────────────────────────────────────
    if not generated_code and local_llm == "ollama":
        _step(f"[1/5] Trying Ollama  ({ollama_host}  model={ollama_model}) …")
        try:
            raw = _call_ollama(prompt, model=ollama_model, host=ollama_host)
            generated_code = _clean_code(raw)
            if generated_code:
                method_used = f"Ollama ({ollama_model})"
                _ok(f"✔ Script generated via Ollama ({ollama_model})")
            else:
                _warn("Ollama response failed syntax check — trying next method.")
        except Exception as e:
            _warn(f"Ollama failed: {type(e).__name__}: {e}")
            if "Connection refused" in str(e) or "refused" in str(e).lower():
                _info("Ollama not running. Start with:  ollama serve")
                _info("Pull a model first:  ollama pull llama3")

    # ── Method 2: OpenAI-compatible local server ──────────────────────────────
    if not generated_code and local_llm == "openai_compatible":
        _step(f"[2/5] Trying OpenAI-compatible server ({local_base_url}) …")
        try:
            raw = _call_openai_compatible(prompt, base_url=local_base_url,
                                          model=local_model or "local-model")
            generated_code = _clean_code(raw)
            if generated_code:
                method_used = f"Local server ({local_base_url})"
                _ok(f"✔ Script generated via local OpenAI-compatible server")
            else:
                _warn("Local server response failed syntax check.")
        except Exception as e:
            _warn(f"Local server failed: {type(e).__name__}: {e}")
            if "Connection refused" in str(e) or "refused" in str(e).lower():
                _info("Local LLM server not running.")
                _info("LM Studio:  https://lmstudio.ai  (start server on port 1234)")
                _info("LocalAI:    https://localai.io")
                _info("Jan:        https://jan.ai")

    # ── Method 3: Anthropic Claude API ───────────────────────────────────────
    if not generated_code and anthropic_key:
        _step(f"[3/5] Trying Anthropic Claude ({anthropic_model}) …")
        try:
            raw = _call_anthropic(prompt, api_key=anthropic_key,
                                  model=anthropic_model)
            generated_code = _clean_code(raw)
            if generated_code:
                method_used = f"Anthropic {anthropic_model}"
                _ok(f"✔ Script generated via Anthropic Claude")
            else:
                _warn("Anthropic response failed syntax check.")
        except Exception as e:
            _warn(f"Anthropic API failed: {type(e).__name__}: {e}")

    # ── Method 4: Vertex AI REST (GCP, ADC, no API key) ──────────────────────
    if not generated_code and vertex_project and env_mode == "gcp":
        _step(f"[4/5] Trying Vertex AI REST (project={vertex_project}) …")
        try:
            raw = _call_vertex_rest(prompt, vertex_project, vertex_location)
            generated_code = _clean_code(raw)
            if generated_code:
                method_used = f"Vertex AI Gemini 2.5 Pro"
                _ok("✔ Script generated via Vertex AI")
            else:
                _warn("Vertex AI response failed syntax check.")
        except ImportError:
            _warn("google-auth not installed. Fix: pip install \'pymlpipeline[gcp]\'")
        except RuntimeError as auth_err:
            _warn(str(auth_err))
        except Exception as e:
            _warn(f"Vertex AI REST failed: {type(e).__name__}: {e}")

    # ── Method 5: Vertex AI SDK ───────────────────────────────────────────────
    if not generated_code and vertex_project and env_mode == "gcp":
        _step(f"[5/5] Trying Vertex AI SDK …")
        try:
            raw = _call_vertex_sdk(prompt, vertex_project, vertex_location)
            generated_code = _clean_code(raw)
            if generated_code:
                method_used = "Vertex AI SDK"
                _ok("✔ Script generated via Vertex AI SDK")
        except ImportError:
            _info("google-cloud-aiplatform not installed — skipped.")
        except Exception as e:
            _warn(f"Vertex AI SDK failed: {type(e).__name__}: {e}")

    # ── Save or fall back ─────────────────────────────────────────────────────
    if generated_code:
        script_path = str(STAGING / "model_training_code.py")
        with open(script_path, "w", encoding="utf-8") as f:
            f.write(generated_code)
        log["gemini_generated"] = True
        log["llm_method"]       = method_used
        _ok(f"AI-generated script saved: {script_path}")
        _ok(f"Method: {method_used}  ({generated_code.count(chr(10))+1} lines)")
        _ok("Ready to run:  python model_training_code.py")
        return script_path, prompt_path

    # ── Static fallback (always works, no LLM needed) ─────────────────────────
    if any([local_llm, anthropic_key, (vertex_project and env_mode=="gcp")]):
        _warn("All LLM methods failed — using static template.")
    else:
        _info("No LLM configured — using static template.")
        _info("To enable AI-generated scripts, add to pipeline_config.yaml:")
        _info("  gemini:")
        _info("    local_llm: \"ollama\"     # free local LLM")
        _info("    ollama_model: \"llama3\"  # or mistral, phi3, codellama ...")

    script_path = _generate_training_script_static(log, results)
    return script_path, prompt_path




def _generate_training_script_static(log: dict, results: dict) -> str:
    """
    Static fallback: generate a solid training script without Gemini.
    Produces the same code as before, but as a clean fallback only.
    """
    mt      = log.get("model_type","classification")
    target  = log.get("target","target")
    id_cols = log.get("id_cols",[])
    csv     = log.get("csv_path","processed_output.csv")
    feats   = log.get("feature_names",[])
    models  = log.get("selected_models",[])
    gcs_b   = log.get("gcs_bucket","")
    gcs_f   = log.get("gcs_folder","models")

    header = f'''#!/usr/bin/env python3
"""
ML Model Training Script
========================
Auto-generated by ml_model_builder.py (static fallback — Gemini unavailable)
Generated : {datetime.now().strftime("%Y-%m-%d %H:%M:%S")}
Model type: {mt}
Target    : {target}
Models    : {models}

Usage:
    python model_training_code.py
"""
'''
    config_block = f'''
# =============================================================================
# CONFIGURATION
# =============================================================================
import os, sys, warnings, pickle, json, shutil
import numpy as np
import pandas as pd
import matplotlib; matplotlib.use("Agg")
import matplotlib.pyplot as plt
import seaborn as sns
from pathlib import Path
from datetime import datetime
from sklearn.model_selection import train_test_split, cross_val_score, StratifiedKFold
from sklearn.preprocessing import StandardScaler, LabelEncoder
from sklearn.feature_selection import (SelectKBest, RFE,
    mutual_info_classif, mutual_info_regression, f_classif, f_regression)
from sklearn.inspection import permutation_importance
from sklearn.metrics import *
'''

    if mt == "classification":
        config_block += '''
from sklearn.linear_model import LogisticRegression
from sklearn.tree import DecisionTreeClassifier
from sklearn.ensemble import (RandomForestClassifier, GradientBoostingClassifier,
    AdaBoostClassifier, ExtraTreesClassifier)
from sklearn.svm import SVC
from sklearn.neighbors import KNeighborsClassifier
from sklearn.naive_bayes import GaussianNB
from sklearn.neural_network import MLPClassifier
'''
    elif mt == "regression":
        config_block += '''
from sklearn.linear_model import LinearRegression, Ridge, Lasso, ElasticNet
from sklearn.tree import DecisionTreeRegressor
from sklearn.ensemble import (RandomForestRegressor, GradientBoostingRegressor,
    AdaBoostRegressor, ExtraTreesRegressor)
from sklearn.svm import SVR
from sklearn.neighbors import KNeighborsRegressor
from sklearn.neural_network import MLPRegressor
'''
    else:
        config_block += '''
from sklearn.cluster import KMeans, DBSCAN, AgglomerativeClustering
from sklearn.mixture import GaussianMixture
'''

    config_block += f'''
warnings.filterwarnings("ignore")

CSV_PATH     = r"{csv}"
TARGET_COL   = "{target}"
ID_COLS      = {(id_cols + ["class_label","prediction"])!r}
MODEL_TYPE   = "{mt}"
TEST_SIZE    = {log.get("test_size",0.2)}
CV_FOLDS     = {log.get("cv_folds",5)}
RANDOM_STATE = 42
GCS_BUCKET   = "{gcs_b}"
GCS_FOLDER   = "{gcs_f}"
OUTPUT_DIR   = Path("./ml_output") / datetime.now().strftime("%Y-%m-%d_%H-%M-%S")
OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
for sub in ("models","charts","report","code"):
    (OUTPUT_DIR/sub).mkdir(exist_ok=True)

print(f"Output directory: {{OUTPUT_DIR}}")
'''

    # Build model dict
    model_defs = {
        "classification": {
            "Logistic Regression":     "LogisticRegression(max_iter=1000,random_state=42)",
            "Decision Tree":           "DecisionTreeClassifier(random_state=42)",
            "Random Forest":           "RandomForestClassifier(n_estimators=200,random_state=42,n_jobs=-1)",
            "Gradient Boosting (GBM)": "GradientBoostingClassifier(n_estimators=200,random_state=42)",
            "Extra Trees":             "ExtraTreesClassifier(n_estimators=200,random_state=42,n_jobs=-1)",
            "AdaBoost":                "AdaBoostClassifier(n_estimators=100,random_state=42)",
            "SVM (RBF Kernel)":        "SVC(probability=True,random_state=42)",
            "K-Nearest Neighbors":     "KNeighborsClassifier(n_jobs=-1)",
            "Naive Bayes":             "GaussianNB()",
            "MLP Neural Network":      "MLPClassifier(hidden_layer_sizes=(128,64),max_iter=500,random_state=42)",
        },
        "regression": {
            "Linear Regression":       "LinearRegression()",
            "Ridge Regression":        "Ridge(alpha=1.0)",
            "Lasso Regression":        "Lasso(alpha=0.01,max_iter=5000)",
            "ElasticNet":              "ElasticNet(alpha=0.01,l1_ratio=0.5,max_iter=5000)",
            "Decision Tree":           "DecisionTreeRegressor(random_state=42)",
            "Random Forest":           "RandomForestRegressor(n_estimators=200,random_state=42,n_jobs=-1)",
            "Gradient Boosting (GBM)": "GradientBoostingRegressor(n_estimators=200,random_state=42)",
            "Extra Trees":             "ExtraTreesRegressor(n_estimators=200,random_state=42,n_jobs=-1)",
            "SVM (RBF Kernel)":        "SVR(kernel='rbf')",
            "K-Nearest Neighbors":     "KNeighborsRegressor(n_jobs=-1)",
            "MLP Neural Network":      "MLPRegressor(hidden_layer_sizes=(128,64),max_iter=500,random_state=42)",
        },
        "clustering": {
            "K-Means (k=3)":          "KMeans(n_clusters=3,random_state=42,n_init=10)",
            "K-Means (k=4)":          "KMeans(n_clusters=4,random_state=42,n_init=10)",
            "K-Means (k=5)":          "KMeans(n_clusters=5,random_state=42,n_init=10)",
            "Agglomerative (k=3)":    "AgglomerativeClustering(n_clusters=3)",
            "Agglomerative (k=4)":    "AgglomerativeClustering(n_clusters=4)",
            "Gaussian Mixture (k=3)": "GaussianMixture(n_components=3,random_state=42)",
            "Gaussian Mixture (k=4)": "GaussianMixture(n_components=4,random_state=42)",
            "DBSCAN (eps=0.5)":       "DBSCAN(eps=0.5,min_samples=5)",
            "DBSCAN (eps=1.0)":       "DBSCAN(eps=1.0,min_samples=5)",
        },
    }
    cat = model_defs.get(mt, {})
    model_lines = ["MODELS = {"]
    for name in models:
        if name in cat:
            model_lines.append(f'    {name!r}: {cat[name]},')
    model_lines.append("}")
    model_block = "\n".join(model_lines)

    body = f'''
# =============================================================================
# 1. LOAD DATA
# =============================================================================
print("\\n[1] Loading data ...")
df = pd.read_csv(CSV_PATH)
print(f"  Loaded: {{df.shape[0]:,}} rows × {{df.shape[1]}} cols")
class_label_backup = df["class_label"].copy() if "class_label" in df.columns else None
drop_cols = [c for c in ID_COLS if c in df.columns]
df = df.drop(columns=drop_cols, errors="ignore")

# =============================================================================
# 2. PREPROCESSING
# =============================================================================
print("\\n[2] Preprocessing ...")
if MODEL_TYPE != "clustering" and TARGET_COL in df.columns:
    y = df[TARGET_COL].copy()
    X = df.drop(columns=[TARGET_COL])
else:
    X = df.copy(); y = None

X = X.select_dtypes(include=[np.number])
X = X.fillna(X.median(numeric_only=True))

if y is not None:
    y = pd.to_numeric(y, errors="coerce")
    if y.isnull().all() and class_label_backup is not None:
        le = LabelEncoder()
        y = pd.Series(le.fit_transform(class_label_backup.fillna("unknown").astype(str)))
        print(f"  Target recovered from class_label: {{list(le.classes_)}}")
    mask = y.notna()
    X = X[mask].reset_index(drop=True)
    y = y[mask].reset_index(drop=True)

feature_names = list(X.columns)
print(f"  Features: {{len(feature_names)}}  Samples: {{len(X):,}}")
if y is not None:
    print(f"  Target distribution:\\n{{y.value_counts().to_string()}}")

scaler  = StandardScaler()
X_sc    = pd.DataFrame(scaler.fit_transform(X.astype(float)), columns=feature_names)
scaler_path = OUTPUT_DIR/"models"/"scaler.pkl"
with open(scaler_path,"wb") as f: pickle.dump(scaler,f)
print(f"  ✔ Scaler saved: {{scaler_path}}")

# =============================================================================
# 3. FEATURE SELECTION
# =============================================================================
print("\\n[3] Feature selection ...")
agg_importance = {{}}
if y is not None:
    methods = {{}}
    try:
        sel = SelectKBest(score_func=mutual_info_classif if MODEL_TYPE=="classification"
                          else mutual_info_regression, k="all")
        sel.fit(X_sc, y); methods["MI"] = dict(zip(feature_names, sel.scores_))
    except Exception as e: print(f"  MI failed: {{e}}")
    try:
        fs, _ = (f_classif if MODEL_TYPE=="classification" else f_regression)(X_sc, y)
        methods["F-stat"] = dict(zip(feature_names, fs))
    except Exception as e: print(f"  F-stat failed: {{e}}")
    try:
        rf = (RandomForestClassifier if MODEL_TYPE=="classification"
              else RandomForestRegressor)(n_estimators=100,random_state=42,n_jobs=-1)
        rf.fit(X_sc, y); methods["RF"] = dict(zip(feature_names, rf.feature_importances_))
    except Exception as e: print(f"  RF importance failed: {{e}}")
    try:
        base = (RandomForestClassifier if MODEL_TYPE=="classification"
                else RandomForestRegressor)(n_estimators=50,random_state=42)
        base.fit(X_sc, y)
        pi = permutation_importance(base, X_sc, y, n_repeats=5, random_state=42)
        methods["Perm"] = dict(zip(feature_names, pi.importances_mean))
    except Exception as e: print(f"  Permutation importance failed: {{e}}")
    try:
        est = (LogisticRegression(max_iter=1000,random_state=42) if MODEL_TYPE=="classification"
               else Ridge())
        rfe = RFE(est, n_features_to_select=max(1,len(feature_names)//2))
        rfe.fit(X_sc, y)
        methods["RFE"] = {{f:1.0 if r==1 else 0.0 for f,r in zip(feature_names,rfe.ranking_)}}
    except Exception as e: print(f"  RFE failed: {{e}}")
    for mname, scores in methods.items():
        vals = np.array(list(scores.values()))
        rng  = vals.max()-vals.min()
        norm = (vals-vals.min())/rng if rng>0 else np.zeros_like(vals)
        for f,s in zip(feature_names, norm):
            agg_importance[f] = agg_importance.get(f,0)+s/len(methods)
    agg_importance = dict(sorted(agg_importance.items(), key=lambda x:x[1], reverse=True))
    print("\\n  Feature Importance Ranking:")
    print(f"  {{\'Rank\':<6}}{{\'Feature\':<42}}{{\'Score\':>8}}")
    print("  "+"-"*58)
    for rank,(feat,score) in enumerate(list(agg_importance.items())[:15],1):
        lvl = "HIGH" if score>0.6 else "MEDIUM" if score>0.3 else "LOW"
        print(f"  {{rank:<6}}{{feat:<42}}{{score:>8.4f}}  [{{lvl}}]")
    try:
        top = list(agg_importance.items())[:min(20,len(agg_importance))]
        fig,ax = plt.subplots(figsize=(9,max(4,len(top)*0.45)))
        colors = ["#2F9E44" if s>0.6 else "#F59F00" if s>0.3 else "#E03131" for _,s in top]
        ax.barh([f for f,_ in reversed(top)],[s for _,s in reversed(top)],color=list(reversed(colors)))
        ax.set_xlabel("Aggregated Importance"); ax.set_title("Feature Importances",fontweight="bold")
        fig.tight_layout()
        p = OUTPUT_DIR/"charts"/"feature_importance.png"
        fig.savefig(p,dpi=120,bbox_inches="tight"); plt.close(fig)
        print(f"  ✔ Feature importance chart saved: {{p}}")
    except Exception as e: print(f"  Chart failed: {{e}}"); plt.close("all")

# =============================================================================
# 4. TRAIN / TEST SPLIT
# =============================================================================
print("\\n[4] Train/test split ...")
if MODEL_TYPE != "clustering" and y is not None:
    strat = y if (MODEL_TYPE=="classification" and y.nunique()<50) else None
    X_train,X_test,y_train,y_test = train_test_split(
        X_sc, y, test_size=TEST_SIZE, random_state=RANDOM_STATE, stratify=strat)
    print(f"  Train: {{len(X_train):,}}  Test: {{len(X_test):,}}")
else:
    X_train = X_sc.copy(); X_test=y_train=y_test=None
    print("  Clustering: using all data")

# =============================================================================
# 5. MODEL DEFINITIONS
# =============================================================================
{model_block}

# =============================================================================
# 6. TRAINING & EVALUATION
# =============================================================================
print("\\n[5] Training models ...")
all_results = {{}}

for name, model in MODELS.items():
    print(f"\\n  Training: {{name}} ...")
    try:
        safe = name.replace(" ","_").replace("(","").replace(")","").replace("/","_")
'''

    if mt == "classification":
        body += '''
        model.fit(X_train, y_train)
        y_pred  = model.predict(X_test)
        y_proba = model.predict_proba(X_test) if hasattr(model,"predict_proba") else None
        acc  = accuracy_score(y_test,y_pred)
        prec = precision_score(y_test,y_pred,average="weighted",zero_division=0)
        rec  = recall_score(y_test,y_pred,average="weighted",zero_division=0)
        f1   = f1_score(y_test,y_pred,average="weighted",zero_division=0)
        cm   = confusion_matrix(y_test,y_pred)
        cr   = classification_report(y_test,y_pred,zero_division=0)
        auc  = None
        if y_proba is not None and y.nunique()==2:
            try: auc = roc_auc_score(y_test, y_proba[:,1])
            except: pass
        cv   = StratifiedKFold(n_splits=CV_FOLDS,shuffle=True,random_state=RANDOM_STATE)
        cv_s = cross_val_score(model,X_sc,y,cv=cv,scoring="f1_weighted",n_jobs=-1)
        print(f"    Acc={acc:.4f}  F1={f1:.4f}"+(f"  AUC={auc:.4f}" if auc else ""))
        print(cr)
        all_results[name] = {"accuracy":acc,"precision":prec,"recall":rec,"f1":f1,
                              "roc_auc":auc,"cv_mean":float(cv_s.mean()),"cv_std":float(cv_s.std())}
        # Confusion matrix
        try:
            fig,ax = plt.subplots(figsize=(5,4))
            sns.heatmap(cm,annot=True,fmt="d",cmap="Blues",ax=ax)
            ax.set_title(f"{name}\\nConfusion Matrix",fontweight="bold")
            fig.tight_layout(); p=OUTPUT_DIR/"charts"/f"{safe}_cm.png"
            fig.savefig(p,dpi=110,bbox_inches="tight"); plt.close(fig)
        except: plt.close("all")
        # ROC curve
        if auc and y_proba is not None and y.nunique()==2:
            try:
                fpr,tpr,_ = roc_curve(y_test,y_proba[:,1])
                fig,ax=plt.subplots(figsize=(6,5))
                ax.plot(fpr,tpr,lw=2,label=f"AUC={auc:.4f}")
                ax.plot([0,1],[0,1],"k--"); ax.set_xlabel("FPR"); ax.set_ylabel("TPR")
                ax.set_title(f"{name} — ROC Curve",fontweight="bold"); ax.legend()
                fig.tight_layout(); p=OUTPUT_DIR/"charts"/f"{safe}_roc.png"
                fig.savefig(p,dpi=110,bbox_inches="tight"); plt.close(fig)
            except: plt.close("all")
'''
    elif mt == "regression":
        body += '''
        model.fit(X_train, y_train)
        y_pred = model.predict(X_test)
        mae  = mean_absolute_error(y_test,y_pred)
        rmse = float(np.sqrt(mean_squared_error(y_test,y_pred)))
        r2   = r2_score(y_test,y_pred)
        try: mape = mean_absolute_percentage_error(y_test,y_pred)*100
        except: mape = None
        cv_s = cross_val_score(model,X_sc,y,cv=CV_FOLDS,scoring="r2",n_jobs=-1)
        print(f"    MAE={mae:.4f}  RMSE={rmse:.4f}  R²={r2:.4f}")
        all_results[name] = {"mae":mae,"rmse":rmse,"r2":r2,"mape":mape,
                              "cv_mean":float(cv_s.mean()),"cv_std":float(cv_s.std())}
        try:
            fig,(ax1,ax2)=plt.subplots(1,2,figsize=(12,4))
            ax1.scatter(y_test,y_pred,alpha=0.4,s=15)
            mn,mx=min(float(y_test.min()),float(y_pred.min())),max(float(y_test.max()),float(y_pred.max()))
            ax1.plot([mn,mx],[mn,mx],"r--"); ax1.set_xlabel("Actual"); ax1.set_ylabel("Predicted")
            ax1.set_title("Actual vs Predicted")
            ax2.scatter(y_pred,y_test-y_pred,alpha=0.4,s=15); ax2.axhline(0,color="k")
            ax2.set_xlabel("Predicted"); ax2.set_ylabel("Residual"); ax2.set_title("Residuals")
            fig.suptitle(name,fontweight="bold"); fig.tight_layout()
            p=OUTPUT_DIR/"charts"/f"{safe}_reg.png"
            fig.savefig(p,dpi=110,bbox_inches="tight"); plt.close(fig)
        except: plt.close("all")
'''
    else:
        body += '''
        labels = model.fit_predict(X_train)
        n_cl = len(set(labels))-(1 if -1 in labels else 0)
        mask = labels!=-1
        metrics = {"n_clusters":n_cl}
        if n_cl>=2:
            metrics["silhouette"] = float(silhouette_score(X_train[mask],labels[mask]))
            metrics["calinski"]   = float(calinski_harabasz_score(X_train[mask],labels[mask]))
            metrics["davies"]     = float(davies_bouldin_score(X_train[mask],labels[mask]))
        print(f"    Clusters={n_cl}"+(f"  Silhouette={metrics.get('silhouette',0):.4f}" if 'silhouette' in metrics else ""))
        all_results[name] = metrics
        try:
            from sklearn.decomposition import PCA
            pca=PCA(n_components=2,random_state=42); X2=pca.fit_transform(X_train)
            fig,ax=plt.subplots(figsize=(7,5))
            ax.scatter(X2[:,0],X2[:,1],c=labels,cmap="tab10",alpha=0.5,s=12)
            ax.set_title(f"{name}\\nPCA 2D",fontweight="bold"); fig.tight_layout()
            p=OUTPUT_DIR/"charts"/f"{safe}_clusters.png"
            fig.savefig(p,dpi=110,bbox_inches="tight"); plt.close(fig)
        except: plt.close("all")
'''

    body += '''
        with open(OUTPUT_DIR/"models"/f"{safe}.pkl","wb") as f: pickle.dump(model,f)
        print(f"    ✔ Model saved: {safe}.pkl")
    except Exception as e:
        print(f"    ✘ Failed: {e}")
        all_results[name] = {"error":str(e)}

# =============================================================================
# 7. COMPARATIVE SUMMARY
# =============================================================================
print("\\n[6] Results Summary")
print("="*60)
valid = {n:r for n,r in all_results.items() if "error" not in r}
'''

    if mt == "classification":
        body += '''
for n,r in valid.items():
    print(f"  {n:<40} Acc={r['accuracy']:.4f}  F1={r['f1']:.4f}")
if valid:
    best = max(valid, key=lambda n: valid[n]["f1"])
    print(f"\\n  ★ Best model (F1): {best}  ({valid[best]['f1']:.4f})")
# Comparison chart
if len(valid)>1:
    try:
        nv=list(valid.keys()); x=np.arange(len(nv)); w=0.25
        fig,ax=plt.subplots(figsize=(max(10,len(nv)*1.4),5))
        ax.bar(x-w,[valid[n]["accuracy"] for n in nv],w,label="Accuracy",color="#4C6EF5",alpha=0.85)
        ax.bar(x,  [valid[n]["f1"]       for n in nv],w,label="F1",      color="#2F9E44",alpha=0.85)
        aucs=[valid[n].get("roc_auc") or 0 for n in nv]
        if any(a>0 for a in aucs):
            ax.bar(x+w,aucs,w,label="AUC",color="#F76707",alpha=0.85)
        ax.set_xticks(x); ax.set_xticklabels(nv,rotation=25,ha="right")
        ax.set_ylim(0,1.05); ax.set_ylabel("Score")
        ax.set_title("Model Comparison",fontweight="bold"); ax.legend(); fig.tight_layout()
        fig.savefig(OUTPUT_DIR/"charts"/"comparison.png",dpi=120,bbox_inches="tight"); plt.close(fig)
        print("  ✔ Comparison chart saved")
    except: plt.close("all")
'''
    elif mt == "regression":
        body += '''
for n,r in valid.items():
    print(f"  {n:<40} R²={r['r2']:.4f}  MAE={r['mae']:.4f}")
if valid:
    best = max(valid, key=lambda n: valid[n]["r2"])
    print(f"\\n  ★ Best model (R²): {best}  ({valid[best]['r2']:.4f})")
if len(valid)>1:
    try:
        nv=list(valid.keys()); x=np.arange(len(nv)); w=0.3
        fig,(ax1,ax2)=plt.subplots(1,2,figsize=(max(12,len(nv)*1.8),5))
        ax1.bar(x,[valid[n]["r2"] for n in nv],color="#4C6EF5",alpha=0.85)
        ax1.set_xticks(x); ax1.set_xticklabels(nv,rotation=25,ha="right")
        ax1.set_title("R² Comparison",fontweight="bold")
        ax2.bar(x-w/2,[valid[n]["mae"]  for n in nv],w,label="MAE", color="#2F9E44",alpha=0.85)
        ax2.bar(x+w/2,[valid[n]["rmse"] for n in nv],w,label="RMSE",color="#E03131",alpha=0.85)
        ax2.set_xticks(x); ax2.set_xticklabels(nv,rotation=25,ha="right")
        ax2.set_title("MAE vs RMSE",fontweight="bold"); ax2.legend()
        fig.suptitle("Regression Comparison",fontweight="bold"); fig.tight_layout()
        fig.savefig(OUTPUT_DIR/"charts"/"comparison.png",dpi=120,bbox_inches="tight"); plt.close(fig)
        print("  ✔ Comparison chart saved")
    except: plt.close("all")
'''

    body += f'''
# =============================================================================
# 8. IMPORTANT FEATURES
# =============================================================================
if agg_importance:
    print("\\n[7] Top 15 Important Features:")
    print(f"  {{\'Rank\':<6}}{{\'Feature\':<42}}{{\'Score\':>8}}  Level")
    print("  "+"-"*62)
    for rank,(feat,score) in enumerate(list(agg_importance.items())[:15],1):
        lvl = "HIGH" if score>0.6 else "MEDIUM" if score>0.3 else "LOW"
        print(f"  {{rank:<6}}{{feat:<42}}{{score:>8.4f}}  [{{lvl}}]")

# =============================================================================
# 9. SAVE RESULTS JSON
# =============================================================================
with open(OUTPUT_DIR/"report"/"results.json","w") as f:
    json.dump(all_results, f, indent=2, default=str)
print(f"\\n  ✔ Results saved: {{OUTPUT_DIR/'report'/'results.json'}}")

# =============================================================================
# 10. GCS UPLOAD
# =============================================================================
if GCS_BUCKET:
    print(f"\\n[8] Uploading to GCS: gs://{{GCS_BUCKET}}/{{GCS_FOLDER}}/")
    try:
        from google.cloud import storage
        client = storage.Client()
        for local_file in OUTPUT_DIR.rglob("*"):
            if local_file.is_file():
                rel = local_file.relative_to(OUTPUT_DIR)
                blob_path = f"{{GCS_FOLDER}}/{{rel}}"
                bucket = client.bucket(GCS_BUCKET)
                bucket.blob(blob_path).upload_from_filename(str(local_file))
                print(f"  ✔ gs://{{GCS_BUCKET}}/{{blob_path}}")
    except Exception as e:
        print(f"  ✘ GCS upload failed: {{e}}")

print(f"\\n{'='*60}")
print(f"All Done! Outputs saved to: {{OUTPUT_DIR}}")
print(f"{'='*60}")

if __name__ == "__main__":
    pass  # All code runs at module level
'''

    script = header + config_block + body
    script_path = str(STAGING / "model_training_code.py")
    with open(script_path, "w") as f:
        f.write(script)
    _ok(f"Static training script saved: {script_path}")
    return script_path


    """
    Generate a self-contained Python training script that replicates
    everything done in this run, with all hyperparameters hard-coded.
    """
    _banner("STEP 7 · Generating Training Python Script")

    mt      = log.get("model_type","classification")
    target  = log.get("target","target")
    id_cols = log.get("id_cols",[])
    csv     = log.get("csv_path","processed_output.csv")
    feats   = log.get("feature_names",[])
    models  = log.get("selected_models",[])

    lines = [
        '#!/usr/bin/env python3',
        '"""',
        f'ML Model Training Script — auto-generated by ml_model_builder.py',
        f'Generated: {datetime.now().strftime("%Y-%m-%d %H:%M:%S")}',
        f'Model type: {mt}',
        f'Target    : {target}',
        f'Models    : {models}',
        '"""',
        '',
        'import numpy as np',
        'import pandas as pd',
        'import matplotlib',
        'matplotlib.use("Agg")',
        'import matplotlib.pyplot as plt',
        'import seaborn as sns',
        'import pickle, warnings, os',
        'from pathlib import Path',
        'from datetime import datetime',
        'warnings.filterwarnings("ignore")',
        '',
        'from sklearn.model_selection import train_test_split, cross_val_score, StratifiedKFold',
        'from sklearn.preprocessing import StandardScaler',
        'from sklearn.metrics import (',
    ]
    if mt == "classification":
        lines += [
            '    accuracy_score, precision_score, recall_score, f1_score,',
            '    roc_auc_score, confusion_matrix, classification_report,',
            '    roc_curve',
            ')',
        ]
    elif mt == "regression":
        lines += [
            '    mean_absolute_error, mean_squared_error, r2_score,',
            '    mean_absolute_percentage_error',
            ')',
        ]
    else:
        lines += [
            '    silhouette_score, calinski_harabasz_score, davies_bouldin_score',
            ')',
        ]

    lines += [
        'from sklearn.feature_selection import SelectKBest, mutual_info_classif, mutual_info_regression',
        'from sklearn.inspection import permutation_importance',
        '',
    ]

    # Model imports
    if mt == "classification":
        lines += [
            'from sklearn.linear_model import LogisticRegression',
            'from sklearn.tree import DecisionTreeClassifier',
            'from sklearn.ensemble import (RandomForestClassifier, GradientBoostingClassifier,',
            '    AdaBoostClassifier, ExtraTreesClassifier)',
            'from sklearn.svm import SVC',
            'from sklearn.neighbors import KNeighborsClassifier',
            'from sklearn.naive_bayes import GaussianNB',
            'from sklearn.neural_network import MLPClassifier',
            '',
        ]
    elif mt == "regression":
        lines += [
            'from sklearn.linear_model import Ridge, Lasso, ElasticNet, LinearRegression',
            'from sklearn.tree import DecisionTreeRegressor',
            'from sklearn.ensemble import (RandomForestRegressor, GradientBoostingRegressor,',
            '    AdaBoostRegressor, ExtraTreesRegressor)',
            'from sklearn.svm import SVR',
            'from sklearn.neighbors import KNeighborsRegressor',
            'from sklearn.neural_network import MLPRegressor',
            '',
        ]
    else:
        lines += [
            'from sklearn.cluster import KMeans, DBSCAN, AgglomerativeClustering',
            'from sklearn.mixture import GaussianMixture',
            '',
        ]

    lines += [
        '# ============================================================',
        '# CONFIGURATION',
        '# ============================================================',
        f'CSV_PATH   = r"{csv}"',
        f'TARGET_COL = "{target}"',
        f'ID_COLS    = {id_cols!r}',
        f'MODEL_TYPE = "{mt}"',
        f'TEST_SIZE  = {log.get("test_size",0.2)}',
        f'CV_FOLDS   = {log.get("cv_folds",5)}',
        f'RANDOM_STATE = 42',
        'OUTPUT_DIR = Path("./ml_output") / datetime.now().strftime("%Y-%m-%d_%H-%M-%S")',
        'OUTPUT_DIR.mkdir(parents=True, exist_ok=True)',
        '',
        '# ============================================================',
        '# 1. LOAD DATA',
        '# ============================================================',
        'print("Loading data …")',
        'df = pd.read_csv(CSV_PATH)',
        'print(f"Loaded: {df.shape[0]:,} rows × {df.shape[1]} cols")',
        '',
        '# Drop identifier and meta columns',
        'drop_cols = [c for c in ID_COLS if c in df.columns]',
        'drop_cols += [c for c in ["class_label","prediction"] if c in df.columns]',
        'df = df.drop(columns=drop_cols, errors="ignore")',
        '',
        '# ============================================================',
        '# 2. FEATURE PREPARATION',
        '# ============================================================',
    ]

    if mt != "clustering":
        lines += [
            f'y = df[TARGET_COL].copy()',
            f'X = df.drop(columns=[TARGET_COL])',
        ]
    else:
        lines += [
            f'X = df.drop(columns=[TARGET_COL], errors="ignore")',
            f'y = None',
        ]

    lines += [
        '',
        '# Drop non-numeric columns',
        'obj_cols = X.select_dtypes(exclude=[np.number]).columns.tolist()',
        'if obj_cols:',
        '    print(f"Dropping non-numeric: {obj_cols}")',
        '    X = X.drop(columns=obj_cols)',
        '',
        '# Fill NaN with column median',
        'X = X.fillna(X.median(numeric_only=True))',
    ]

    if mt != "clustering":
        lines += [
            '',
            '# Drop target NaN rows',
            'if y is not None:',
            '    y = pd.to_numeric(y, errors="coerce")',
            '    mask = y.notna()',
            '    X, y = X[mask].reset_index(drop=True), y[mask].reset_index(drop=True)',
        ]

    lines += [
        '',
        'feature_names = list(X.columns)',
        'print(f"Features: {len(feature_names)}  Samples: {len(X):,}")',
        '',
        '# Scale features',
        'scaler = StandardScaler()',
        'X_scaled = pd.DataFrame(scaler.fit_transform(X.astype(float)), columns=feature_names)',
        '',
        '# Save scaler',
        'with open(OUTPUT_DIR/"scaler.pkl","wb") as f: pickle.dump(scaler, f)',
        'print("Scaler saved.")',
        '',
        '# ============================================================',
        '# 3. FEATURE SELECTION',
        '# ============================================================',
        'print("Running feature selection …")',
    ]

    if mt == "classification":
        lines += [
            'fi_selector = SelectKBest(score_func=mutual_info_classif, k="all")',
        ]
    elif mt == "regression":
        lines += [
            'fi_selector = SelectKBest(score_func=mutual_info_regression, k="all")',
        ]

    if mt != "clustering":
        lines += [
            'fi_selector.fit(X_scaled, y)',
            'fi_scores = dict(sorted(zip(feature_names, fi_selector.scores_),',
            '                        key=lambda x: x[1], reverse=True))',
            'print("\\nMutual Information Feature Importances:")',
            'for feat, score in list(fi_scores.items())[:15]:',
            '    print(f"  {feat:<40} {score:.4f}")',
        ]

    lines += [
        '',
        '# ============================================================',
        '# 4. TRAIN / TEST SPLIT',
        '# ============================================================',
    ]

    if mt != "clustering":
        lines += [
            'n_uniq = int(y.nunique()) if y is not None else 0',
            'strat  = y if (MODEL_TYPE == "classification" and n_uniq < 50) else None',
            'X_train, X_test, y_train, y_test = train_test_split(',
            '    X_scaled, y, test_size=TEST_SIZE, random_state=RANDOM_STATE, stratify=strat',
            ')',
            'print(f"Train: {len(X_train):,}  Test: {len(X_test):,}")',
        ]
    else:
        lines += [
            'X_train = X_scaled.copy()  # Clustering uses all data',
        ]

    lines += [
        '',
        '# ============================================================',
        '# 5. MODEL DEFINITIONS',
        '# ============================================================',
    ]

    # Generate model dict based on what was actually selected
    if mt == "classification":
        model_code = "MODELS = {\n"
        for name in models:
            if name in CLASSIFICATION_MODELS:
                m = CLASSIFICATION_MODELS[name]
                model_code += f'    {name!r}: {repr(m)},\n'
        model_code += "}"
    elif mt == "regression":
        model_code = "MODELS = {\n"
        for name in models:
            if name in REGRESSION_MODELS:
                m = REGRESSION_MODELS[name]
                model_code += f'    {name!r}: {repr(m)},\n'
        model_code += "}"
    else:
        model_code = "MODELS = {\n"
        for name in models:
            if name in CLUSTERING_MODELS:
                m = CLUSTERING_MODELS[name]
                model_code += f'    {name!r}: {repr(m)},\n'
        model_code += "}"
    lines.append(model_code)

    lines += [
        '',
        '# ============================================================',
        '# 6. TRAINING & EVALUATION',
        '# ============================================================',
        'all_results = {}',
        '',
        'for name, model in MODELS.items():',
        '    print(f"\\nTraining: {name} …")',
        '    try:',
    ]

    if mt == "classification":
        lines += [
            '        model.fit(X_train, y_train)',
            '        y_pred  = model.predict(X_test)',
            '        y_proba = model.predict_proba(X_test) if hasattr(model,"predict_proba") else None',
            '',
            '        acc  = accuracy_score(y_test, y_pred)',
            '        prec = precision_score(y_test, y_pred, average="weighted", zero_division=0)',
            '        rec  = recall_score(y_test, y_pred, average="weighted", zero_division=0)',
            '        f1   = f1_score(y_test, y_pred, average="weighted", zero_division=0)',
            '        cm   = confusion_matrix(y_test, y_pred)',
            '        cr   = classification_report(y_test, y_pred, zero_division=0)',
            '',
            '        auc  = None',
            '        if y_proba is not None and y.nunique() == 2:',
            '            try: auc = roc_auc_score(y_test, y_proba[:,1])',
            '            except: pass',
            '',
            '        # Cross-validation',
            '        cv   = StratifiedKFold(n_splits=CV_FOLDS, shuffle=True, random_state=RANDOM_STATE)',
            '        cv_s = cross_val_score(model, X_scaled, y, cv=cv, scoring="f1_weighted", n_jobs=-1)',
            '',
            '        print(f"  Acc={acc:.4f}  F1={f1:.4f}" + (f"  AUC={auc:.4f}" if auc else ""))',
            '        print(cr)',
            '',
            '        all_results[name] = {"accuracy":acc,"precision":prec,"recall":rec,',
            '                              "f1":f1,"roc_auc":auc,',
            '                              "cv_mean":float(cv_s.mean()),"cv_std":float(cv_s.std())}',
            '',
            '        # Confusion matrix chart',
            '        fig,ax = plt.subplots(figsize=(5,4))',
            '        sns.heatmap(cm, annot=True, fmt="d", cmap="Blues", ax=ax)',
            '        ax.set_title(f"{name}\\nConfusion Matrix", fontweight="bold")',
            '        safe = name.replace(" ","_").replace("(","").replace(")","").replace("/","_")',
            '        fig.savefig(OUTPUT_DIR/f"{safe}_cm.png", dpi=110, bbox_inches="tight"); plt.close(fig)',
        ]
    elif mt == "regression":
        lines += [
            '        model.fit(X_train, y_train)',
            '        y_pred = model.predict(X_test)',
            '',
            '        mae  = mean_absolute_error(y_test, y_pred)',
            '        rmse = float(np.sqrt(mean_squared_error(y_test, y_pred)))',
            '        r2   = r2_score(y_test, y_pred)',
            '        try: mape = mean_absolute_percentage_error(y_test, y_pred)*100',
            '        except: mape = None',
            '',
            '        cv_s = cross_val_score(model, X_scaled, y, cv=CV_FOLDS, scoring="r2", n_jobs=-1)',
            '',
            '        print(f"  MAE={mae:.4f}  RMSE={rmse:.4f}  R²={r2:.4f}")',
            '        all_results[name] = {"mae":mae,"rmse":rmse,"r2":r2,"mape":mape,',
            '                              "cv_mean":float(cv_s.mean()),"cv_std":float(cv_s.std())}',
            '',
            '        # Actual vs Predicted chart',
            '        fig,(ax1,ax2) = plt.subplots(1,2,figsize=(12,4))',
            '        ax1.scatter(y_test, y_pred, alpha=0.4, s=15)',
            '        mn,mx = min(float(y_test.min()),float(y_pred.min())), max(float(y_test.max()),float(y_pred.max()))',
            '        ax1.plot([mn,mx],[mn,mx],"r--")',
            '        ax1.set_xlabel("Actual"); ax1.set_ylabel("Predicted")',
            '        ax1.set_title("Actual vs Predicted")',
            '        ax2.scatter(y_pred, y_test-y_pred, alpha=0.4, s=15)',
            '        ax2.axhline(0, color="k")',
            '        ax2.set_xlabel("Predicted"); ax2.set_ylabel("Residual")',
            '        ax2.set_title("Residuals")',
            '        fig.suptitle(name, fontweight="bold")',
            '        safe = name.replace(" ","_").replace("(","").replace(")","").replace("/","_")',
            '        fig.savefig(OUTPUT_DIR/f"{safe}_reg.png", dpi=110, bbox_inches="tight"); plt.close(fig)',
        ]
    else:
        lines += [
            '        labels = model.fit_predict(X_train)',
            '        n_clusters = len(set(labels)) - (1 if -1 in labels else 0)',
            '        metrics = {"n_clusters": n_clusters}',
            '        mask = labels != -1',
            '        if n_clusters >= 2:',
            '            metrics["silhouette"]       = float(silhouette_score(X_train[mask], labels[mask]))',
            '            metrics["calinski_harabasz"] = float(calinski_harabasz_score(X_train[mask], labels[mask]))',
            '            metrics["davies_bouldin"]    = float(davies_bouldin_score(X_train[mask], labels[mask]))',
            '        print(f"  Clusters={n_clusters}  Silhouette={metrics.get(\"silhouette\",\"N/A\")}")',
            '        all_results[name] = metrics',
        ]

    lines += [
        '',
        '        # Save model',
        '        safe = name.replace(" ","_").replace("(","").replace(")","").replace("/","_")',
        '        with open(OUTPUT_DIR/f"{safe}.pkl","wb") as f: pickle.dump(model, f)',
        '        print(f"  Model saved: {safe}.pkl")',
        '',
        '    except Exception as e:',
        '        print(f"  ERROR training {name}: {e}")',
        '        all_results[name] = {"error": str(e)}',
        '',
        '# ============================================================',
        '# 7. RESULTS SUMMARY',
        '# ============================================================',
        'print("\\n" + "="*60)',
        'print("RESULTS SUMMARY")',
        'print("="*60)',
        'for name, r in all_results.items():',
        '    if "error" in r: print(f"  {name}: ERROR — {r[\"error\"]}"); continue',
    ]

    if mt == "classification":
        lines += [
            '    print(f"  {name:<40} Acc={r[\"accuracy\"]:.4f}  F1={r[\"f1\"]:.4f}")',
        ]
    elif mt == "regression":
        lines += [
            '    print(f"  {name:<40} R²={r[\"r2\"]:.4f}  MAE={r[\"mae\"]:.4f}")',
        ]
    else:
        lines += [
            '    print(f"  {name:<40} Clusters={r[\"n_clusters\"]}  Silhouette={r.get(\"silhouette\",\"N/A\")}")',
        ]

    lines += [
        '',
        '# Save results as JSON',
        'import json',
        'with open(OUTPUT_DIR/"results.json","w") as f: json.dump(all_results, f, indent=2)',
        'print(f"\\nAll outputs saved to: {OUTPUT_DIR}")',
    ]

    script = "\n".join(lines)
    script_path = str(STAGING / "model_training_code.py")
    with open(script_path,"w") as f: f.write(script)
    _ok(f"Training script saved: {script_path}")
    return script_path


# =============================================================================


# STEP 8 — GENERATE PREDICTION SCRIPT  (req 8)
# A standalone script that loads scaler.pkl + model.pkl and predicts on
# new data from BigQuery, GCS CSV, or a local file.
# =============================================================================
def _generate_predict_script(log: dict, results: dict) -> str:
    _banner("STEP 8 · Generating Prediction Script")

    mt         = log.get("model_type", "classification")
    target     = log.get("target", "target")
    id_cols    = log.get("id_cols", [])
    feat_names = log.get("feature_names", [])
    bq_project = log.get("bq_project", "")
    bq_dataset = log.get("bq_dataset", "")
    bq_table   = log.get("bq_table", "")
    gcs_bucket = log.get("gcs_bucket", "")
    gcs_folder = log.get("gcs_folder", "")
    classes    = log.get("classes", [])

    # Pick best model name
    valid = {n: r for n, r in results.items() if "error" not in r}
    if mt == "classification":
        best = max(valid, key=lambda n: valid[n].get("f1", 0)) if valid else ""
    elif mt == "regression":
        best = max(valid, key=lambda n: valid[n].get("r2", -999)) if valid else ""
    else:
        best = list(valid.keys())[0] if valid else ""

    best_safe = best.replace(" ","_").replace("(","").replace(")","").replace("/","_") if best else "model"

    script = f'''#!/usr/bin/env python3
"""
ML Prediction Script
====================
Auto-generated by ml_model_builder.py
Generated : {datetime.now().strftime("%Y-%m-%d %H:%M:%S")}
Model type: {mt}
Target    : {target}
Best model: {best}

Usage:
    python predict.py --model {best_safe}.pkl --scaler scaler.pkl --data input.csv
    python predict.py --model {best_safe}.pkl --scaler scaler.pkl --bq project.dataset.table
    python predict.py --model {best_safe}.pkl --scaler scaler.pkl --gcs gs://bucket/path/data.csv

All data sources (local CSV, GCS, BigQuery) are supported.
The script applies the same preprocessing as during training.
"""

import os, sys, argparse, warnings, pickle
import numpy as np
import pandas as pd
from pathlib import Path
from datetime import datetime

warnings.filterwarnings("ignore")

# ─── Configuration ─────────────────────────────────────────────────────────────
TARGET_COL   = {target!r}
ID_COLS      = {(id_cols + ["class_label","prediction"])!r}
FEATURE_NAMES= {feat_names!r}    # expected after preprocessing
MODEL_TYPE   = {mt!r}
CLASSES      = {classes!r}

# ─── Argument parser ───────────────────────────────────────────────────────────
ap = argparse.ArgumentParser(description="ML Prediction Script")
ap.add_argument("--model",   required=True, help="Path to trained model .pkl")
ap.add_argument("--scaler",  required=True, help="Path to scaler .pkl")
ap.add_argument("--data",    default="",    help="Local CSV path")
ap.add_argument("--gcs",     default="",    help="GCS URI:  gs://bucket/path/file.csv")
ap.add_argument("--bq",      default="",    help="BigQuery: project.dataset.table")
ap.add_argument("--bq_query",default="",    help="Custom BigQuery SQL query")
ap.add_argument("--out",     default="",    help="Output CSV path (default: predictions_<ts>.csv)")
ap.add_argument("--project", default={bq_project!r},
                              help="GCP project for BigQuery auth")
args = ap.parse_args()

# ─── Load model & scaler ──────────────────────────────────────────────────────
print(f"Loading model  : {{args.model}}")
with open(args.model,"rb") as f:  model  = pickle.load(f)
print(f"Loading scaler : {{args.scaler}}")
with open(args.scaler,"rb") as f: scaler = pickle.load(f)
print(f"Model  : {{type(model).__name__}}")
print(f"Scaler : {{type(scaler).__name__}}")

# ─── Load input data ──────────────────────────────────────────────────────────
def _load_bq(bq_ref: str, bq_query: str, project: str) -> pd.DataFrame:
    from google.cloud import bigquery
    client = bigquery.Client(project=project or bq_ref.split(".")[0])
    if bq_query:
        query = bq_query
    else:
        p, d, t = bq_ref.split(".")
        query = f"SELECT * FROM `{{p}}.{{d}}.{{t}}`"
    print(f"BQ query: {{query[:100]}}")
    df = client.query(query).to_dataframe()
    # normalise nullable types
    for col in df.columns:
        dt = df[col].dtype
        if hasattr(dt,"numpy_dtype"):
            if dt.numpy_dtype.kind in ("i","u"):
                df[col] = df[col].astype("float64" if df[col].isnull().any() else "int64")
            elif dt.numpy_dtype.kind == "f":
                df[col] = df[col].astype("float64")
    return df

def _load_gcs(uri: str) -> pd.DataFrame:
    from google.cloud import storage
    without = uri[len("gs://"):]
    bucket, _, blob = without.partition("/")
    tmp = Path(f"/tmp/predict_input_{{datetime.now().strftime('%H%M%S')}}.csv")
    storage.Client().bucket(bucket).blob(blob).download_to_filename(str(tmp))
    return pd.read_csv(str(tmp))

if args.bq:
    print(f"Loading data from BigQuery: {{args.bq}}")
    df = _load_bq(args.bq, args.bq_query, args.project)
elif args.gcs:
    print(f"Loading data from GCS: {{args.gcs}}")
    df = _load_gcs(args.gcs)
elif args.data:
    print(f"Loading data from local: {{args.data}}")
    df = pd.read_csv(args.data)
else:
    print("ERROR: Provide one of --data, --gcs, or --bq")
    sys.exit(1)

print(f"Loaded: {{df.shape[0]:,}} rows x {{df.shape[1]}} cols")

# ─── Preserve identifiers ──────────────────────────────────────────────────────
id_data = df[[c for c in ID_COLS if c in df.columns]].copy()

# ─── Preprocessing (mirror of training pipeline) ──────────────────────────────
drop_cols = [c for c in ID_COLS if c in df.columns]
if TARGET_COL in df.columns:
    drop_cols.append(TARGET_COL)
df = df.drop(columns=drop_cols, errors="ignore")

# Convert boolean/object numeric columns
for col in df.select_dtypes(exclude=[np.number]).columns:
    conv = pd.to_numeric(df[col], errors="coerce")
    if conv.notna().sum() / max(df[col].notna().sum(), 1) >= 0.95:
        df[col] = conv.astype("float64")

# Drop non-numeric
df = df.select_dtypes(include=[np.number])

# Align feature columns to training schema
missing_cols = [c for c in FEATURE_NAMES if c not in df.columns]
extra_cols   = [c for c in df.columns   if c not in FEATURE_NAMES]
if missing_cols:
    print(f"WARNING: Missing features {{missing_cols}} — filling with 0")
    for c in missing_cols: df[c] = 0.0
if extra_cols:
    print(f"INFO: Dropping extra columns not seen in training: {{extra_cols}}")
df = df[FEATURE_NAMES]   # reorder to match training

# Fill NaN with median
df = df.fillna(df.median(numeric_only=True))

# Scale
X = pd.DataFrame(scaler.transform(df.astype(float)), columns=FEATURE_NAMES)
print(f"Features ready: {{X.shape[1]}} cols x {{X.shape[0]:,}} rows")

# ─── Predict ──────────────────────────────────────────────────────────────────
print("Running predictions ...")
y_pred = model.predict(X)

out_df = id_data.reset_index(drop=True).copy()
out_df["prediction"] = y_pred

if MODEL_TYPE == "classification":
    if CLASSES:
        cls_map = {{i: c for i,c in enumerate(CLASSES)}}
        out_df["prediction_label"] = pd.Series(y_pred).map(cls_map).fillna(pd.Series(y_pred).astype(str))
    if hasattr(model, "predict_proba"):
        try:
            proba = model.predict_proba(X)
            for i, cls in enumerate(model.classes_):
                out_df[f"prob_class_{{cls}}"] = proba[:, i]
        except Exception as e:
            print(f"Probability estimation failed: {{e}}")

# ─── Save output ──────────────────────────────────────────────────────────────
ts_str = datetime.now().strftime("%Y-%m-%d_%H-%M-%S")
out_path = args.out or f"predictions_{{ts_str}}.csv"
out_df.to_csv(out_path, index=False)
print(f"\\nPredictions saved: {{out_path}}")
print(f"Rows: {{len(out_df):,}}  |  Columns: {{list(out_df.columns)}}")

# Summary
if MODEL_TYPE == "classification" and "prediction_label" in out_df.columns:
    print("\\nPrediction distribution:")
    vc = out_df["prediction_label"].value_counts()
    for v, cnt in vc.items():
        print(f"  {{v}}: {{cnt:,}}  ({{cnt/len(out_df)*100:.1f}}%)")

print("\\nDone.")
'''

    path = str(STAGING / "predict.py")
    with open(path, "w", encoding="utf-8") as f:
        f.write(script)
    _ok(f"Prediction script saved: {path}")
    _ok(f"Usage: python predict.py --model {best_safe}.pkl --scaler scaler.pkl --bq project.dataset.table")
    return path


# =============================================================================
# MAIN
# =============================================================================
def run_model_builder():
    print(f"\n{B}{C}"
          "╔══════════════════════════════════════════════════════════════╗\n"
          "║         ML MODEL BUILDER  (GCP + Local)                      ║\n"
          f"╚══════════════════════════════════════════════════════════════╝{RST}")

    ENV.print_summary()   # show environment and library availability

    log = {}
    ts  = datetime.now().strftime("%Y-%m-%d_%H-%M-%S")

    # GCS / output config
    gcs_bucket = CFG.s("gcs","bucket") or ""
    gcs_base   = (CFG.s("gcs","base_folder") or "").strip("/")
    gcs_folder = f"{gcs_base}/{ts}/models" if gcs_base else f"{ts}/models"
    if gcs_bucket:
        _ok(f"GCS target: gs://{gcs_bucket}/{gcs_folder}/")
    local_dir  = Path(f"./ml_model_output/{ts}")
    local_dir.mkdir(parents=True, exist_ok=True)
    _ok(f"Local output: {local_dir}")

    log["gcs_bucket"] = gcs_bucket
    log["gcs_folder"] = gcs_folder
    log["local_dir"]  = str(local_dir)
    log["timestamp"]  = ts

    # Run pipeline
    df, target, id_cols, model_type, class_label_backup = _load_data(log)
    X, y, feature_names, scaler = _prepare_features(
        df, target, id_cols, model_type, log, class_label_backup
    )
    # Step 2b: Target leakage check — ask user to drop name-similar columns
    X = _check_target_leakage(X, target, log)
    # Step 2c: Correlation-based feature selection (top N by |corr| with target)
    X = _select_top_corr_features(X, y, model_type, log)

    feature_importance               = _feature_selection(X, y, model_type, log)
    selected_models                  = _select_models(model_type, log)

    if model_type == "classification":
        results, charts = _train_classification(X, y, selected_models, log)
    elif model_type == "regression":
        results, charts = _train_regression(X, y, selected_models, log)
    else:
        results, charts = _train_clustering(X, selected_models, log)

    # Generate report, training script, and prediction script
    report_path  = _generate_report(log, results, charts, feature_importance)
    script_path, prompt_path = _generate_training_script(log, results, feature_importance)
    predict_path = _generate_predict_script(log, results)

    # Collect all output files  {local_path: subfolder}
    all_files = {}

    # Models
    for name, r in results.items():
        if "model_path" in r:
            all_files[r["model_path"]] = "models"
    # Scaler + predict script alongside models
    if log.get("scaler_path"): all_files[log["scaler_path"]] = "models"
    all_files[predict_path] = "models"
    # Charts — all of them
    for name_charts in charts.values():
        for p in name_charts:
            all_files[p] = "charts"
    for chart_key in ["feature_importance_chart","comparison_chart","radar_chart",
                      "corr_target_chart","corr_matrix_chart"]:
        if log.get(chart_key):
            all_files[log[chart_key]] = "charts"
    # Report + training script + prompt
    all_files[report_path]  = "report"
    all_files[script_path]  = "code"
    all_files[prompt_path]  = "code"

    # Save results JSON
    results_json = str(STAGING / "results.json")
    clean_results = {}
    for n,r in results.items():
        clean_r = {k:v for k,v in r.items() if k not in ("model_path","confusion_matrix")}
        if "confusion_matrix" in r: clean_r["confusion_matrix"] = r["confusion_matrix"]
        clean_results[n] = clean_r
    with open(results_json,"w") as f: json.dump(clean_results, f, indent=2, default=str)
    all_files[results_json] = "report"

    # Save everything
    _save_all(all_files, gcs_bucket, gcs_folder, local_dir)

    # Final summary
    _banner("All Done!")
    _ok(f"Model type     : {model_type}")
    trained_count = len([r for r in results.values() if "error" not in r])
    _ok(f"Models trained : {trained_count}/{len(results)}")
    best_name = ""
    if model_type == "classification":
        valid = {n:r for n,r in results.items() if "f1" in r}
        if valid:
            best_name = max(valid, key=lambda n: valid[n]["f1"])
            _ok(f"Best model     : {best_name}")
            _ok(f"  Accuracy={valid[best_name]['accuracy']:.4f}  "
                f"F1={valid[best_name]['f1']:.4f}  "
                f"AUC={valid[best_name].get('roc_auc') or 'N/A'}  "
                f"MCC={valid[best_name].get('mcc',0):.4f}")
            # Save best model copy as best_model.pkl for easy use with predict.py
            best_safe = best_name.replace(" ","_").replace("(","").replace(")","").replace("/","_")
            best_pkl  = str(local_dir / "models" / f"{best_safe}.pkl")
            best_copy = str(local_dir / "models" / "best_model.pkl")
            if Path(best_pkl).exists():
                shutil.copy2(best_pkl, best_copy)
                _ok(f"Best model copy: models/best_model.pkl  ← use with predict.py")
    elif model_type == "regression":
        valid = {n:r for n,r in results.items() if "r2" in r}
        if valid:
            best_name = max(valid, key=lambda n: valid[n]["r2"])
            _ok(f"Best model     : {best_name}  (R²={valid[best_name]['r2']:.4f})")
            best_safe = best_name.replace(" ","_").replace("(","").replace(")","").replace("/","_")
            best_pkl  = str(local_dir / "models" / f"{best_safe}.pkl")
            best_copy = str(local_dir / "models" / "best_model.pkl")
            if Path(best_pkl).exists():
                shutil.copy2(best_pkl, best_copy)
                _ok(f"Best model copy: models/best_model.pkl")
    _ok(f"Local output   : {local_dir}/")
    if gcs_bucket:
        _ok(f"GCS output     : gs://{gcs_bucket}/{gcs_folder}/")

    gemini_generated = log.get("gemini_generated", False)
    _ok(f"Training script: {Path(script_path).name}  "
        f"({'✨ Gemini 2.5 Pro generated' if gemini_generated else 'static template'})")
    _ok(f"Predict script : models/predict.py")

    print(f"\n  {B}Output folder structure:{RST}")
    print(f"  {local_dir}/")
    print(f"    models/   — *.pkl model files + scaler.pkl + best_model.pkl + predict.py")
    print(f"    charts/   — confusion matrix, ROC, PR, learning curve, calibration,")
    print(f"                  CV violin, prob histogram, radar, feature importance,")
    print(f"                  correlation-with-target, correlation matrix")
    print(f"    report/   — ML_Model_Report.docx + results.json")
    print(f"    code/     — model_training_code.py + gemini_prompt.txt")
    print(f"\n  {B}To run predictions on new data:{RST}")
    print(f"  python predict.py --model models/best_model.pkl --scaler models/scaler.pkl \\")
    print(f"    --bq my-project.my_dataset.new_table")


# =============================================================================
# ENTRY POINT
# =============================================================================
if __name__ == "__main__":
    ap = argparse.ArgumentParser(description="ML Model Builder — GCP Edition")
    ap.add_argument("--config","-c", default="",
                    help="Path to pipeline_config.yaml (same file as preprocessor)")
    args = ap.parse_args()

    # Load config into singleton BEFORE anything else
    CFG.load(args.config)

    run_model_builder()
