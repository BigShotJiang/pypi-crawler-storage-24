"""
pymlpipeline — End-to-End ML Pipeline (GCP + Local)
=====================================================
A two-tool ML pipeline covering the full journey from raw data to trained
models, prediction scripts, and Word reports.

Supports both GCP (BigQuery / GCS / Vertex AI) and fully local environments
(CSV files, Ollama, LM Studio, Anthropic Claude).

Tools
-----
pymlpipeline preprocess   Data cleaning & preprocessing pipeline
pymlpipeline build        Train, evaluate and compare ML models
pymlpipeline predict      Score new data with a saved model + scaler

AI script generation (STEP 7) — local-first, no GCP required:
  • Ollama      — free, runs on CPU/GPU  (ollama pull llama3)
  • LM Studio   — GUI app, OpenAI-compatible server
  • LocalAI     — Docker-based local server
  • Anthropic Claude API
  • Vertex AI / Gemini 2.5 Pro (GCP, ADC, no API key)
  • Static template — always works, no LLM needed

Quick start
-----------
    pip install pymlpipeline                       # core
    pip install "pymlpipeline[gcp]"                # + BigQuery / GCS
    pip install "pymlpipeline[gcp,boosting]"       # + XGBoost / LightGBM / CatBoost

    pymlpipeline init                              # create pipeline_config.yaml
    pymlpipeline preprocess --config pipeline_config.yaml
    pymlpipeline build      --config pipeline_config.yaml
    pymlpipeline predict    --model best_model.pkl --scaler scaler.pkl --data new.csv

Local LLM (no internet, free):
    # 1. Install Ollama from https://ollama.com
    # 2. ollama pull llama3 && ollama serve
    # 3. In pipeline_config.yaml:
    #      gemini:
    #        local_llm:    "ollama"
    #        ollama_model: "llama3"

GitHub
------
    https://github.com/your-org/pymlpipeline
"""

__version__   = "1.0.0"
__author__    = "Your Name"
__email__     = "your@email.com"
__license__   = "MIT"

from pymlpipeline.preprocessor  import run_pipeline, CFG as preprocessor_cfg
from pymlpipeline.model_builder import run_model_builder, CFG as model_cfg

__all__ = [
    "run_pipeline",
    "run_model_builder",
    "preprocessor_cfg",
    "model_cfg",
    "__version__",
]
