#!/usr/bin/env python3
"""
ML Data Cleaning & Preprocessing Pipeline — GCP BigQuery Edition
Run:  python ml_preprocessor_gcp.py --config pipeline_config.yaml
"""
import os, sys, io, warnings, textwrap, tempfile, argparse, shutil
from datetime import datetime
from pathlib import Path

try:
    import yaml
    _YAML_OK = True
except ImportError:
    _YAML_OK = False

import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.preprocessing import (
    LabelEncoder, StandardScaler, MinMaxScaler, RobustScaler, MaxAbsScaler
)
from docx import Document
from docx.shared import Inches, Pt, RGBColor, Emu
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.oxml.ns import qn
from docx.oxml import OxmlElement

warnings.filterwarnings("ignore")

# ── Terminal colours ──────────────────────────────────────────────────────────
C  = "\033[96m"; G = "\033[92m"; Y = "\033[93m"
R  = "\033[91m"; B = "\033[1m";  X = "\033[0m"
PAL = ["#4C6EF5","#F76707","#2F9E44","#E03131","#7950F2","#1098AD","#F59F00","#364FC7"]
sns.set_theme(style="whitegrid", palette=PAL)

def _banner(t): print(f"\n{B}{C}{'='*62}\n  {t}\n{'='*62}{X}")
def _ok(t):   print(f"  {G}✔  {t}{X}")
def _warn(t): print(f"  {Y}⚠  {t}{X}")
def _drop(t): print(f"  {R}✘  {t}{X}")
def _step(t): print(f"  {C}➤  {t}{X}")

# =============================================================================
# CONFIG  — loaded once from YAML, used everywhere via CFG singleton
# =============================================================================
class _Config:
    """
    Thin wrapper around the parsed YAML dict.
    g(key, default) returns config value or default.
    All pipeline functions call CFG.g(...) — never raw input() unless needed.
    """
    def __init__(self):
        self._d = {}

    def load(self, path: str) -> None:
        if not path:
            return
        if not _YAML_OK:
            _warn("PyYAML not installed. Run: pip install pyyaml"); return
        p = Path(path)
        if not p.exists():
            _warn(f"Config file not found: {path}"); return
        try:
            with open(p) as f:
                self._d = yaml.safe_load(f) or {}
            _ok(f"Config loaded: {path}")
        except Exception as e:
            _warn(f"YAML parse error in {path}: {e}")
            self._d = {}

    def g(self, *keys, default=None):
        """Traverse nested keys.  Returns default for missing/blank/empty."""
        node = self._d
        for k in keys:
            if not isinstance(node, dict) or k not in node:
                return default
            node = node[k]
        if node is None or node == "" or node == []:
            return default
        return node

    def s(self, *keys) -> str | None:
        v = self.g(*keys)
        return str(v).strip() if v is not None else None

    def b(self, *keys, default=None) -> bool | None:
        v = self.g(*keys)
        return bool(v) if v is not None else default

    def f(self, *keys, default=None) -> float | None:
        v = self.g(*keys)
        try:    return float(v) if v is not None else default
        except: return default

    def i(self, *keys, default=None) -> int | None:
        v = self.g(*keys)
        try:    return int(v) if v is not None else default
        except: return default

    def lst(self, *keys) -> list | None:
        v = self.g(*keys)
        return [str(x) for x in v] if isinstance(v, list) else None

    @property
    def auto(self) -> bool:
        return bool(self.g("pipeline","auto_mode", default=False))

    def print_summary(self):
        if not self._d:
            print(f"  {Y}No config loaded — fully interactive mode.{X}")
            return
        print(f"\n  {B}Loaded settings:{X}")
        rows = [
            ("BQ Project",     self.s("bigquery","project_id") or "?"),
            ("BQ Dataset",     self.s("bigquery","dataset_id") or "?"),
            ("BQ Table",       self.s("bigquery","table_id")   or "?"),
            ("Query mode",     self.s("bigquery","query_mode") or "full_table"),
            ("Row limit",      str(self.i("bigquery","row_limit")) if self.g("bigquery","row_limit") else "all"),
            ("GCS Bucket",     self.s("gcs","bucket")          or "?"),
            ("GCS Folder",     self.s("gcs","base_folder")     or "(root)"),
            ("Data source",    self.s("pipeline","data_source") or "?"),
            ("Save to GCS",    str(self.b("pipeline","save_to_gcs", default=None))),
            ("Auto mode",      str(self.auto)),
            ("Target column",  self.s("pipeline","target_column") or "?"),
            ("Identifiers",    ", ".join(self.lst("pipeline","identifier_columns") or []) or "?"),
            ("Model type",     self.s("pipeline","model_type") or "?"),
            ("Output dataset", self.s("output","dataset_id")   or "(skip)"),
            ("Output table",   self.s("output","table_id")     or "(skip)"),
        ]
        for k, v in rows:
            dot = f"  {G}✔{X}" if v not in ("?", "None", "") else f"  {Y}?{X}"
            print(f"  {k:<22} {v}{dot}")


# Singleton — the ONLY instance used across the whole program
CFG = _Config()

# =============================================================================
# ENVIRONMENT DETECTION  — runs once at import time
# Probes for GCP libraries and credentials so every function knows what's
# available without repeating try/except blocks everywhere.
# =============================================================================
class _Env:
    """
    Detects the runtime environment (GCP vs local) and which optional
    libraries are available.  All pipeline functions read from ENV.*
    instead of trying imports inline.

    Environment resolution (pipeline.environment in config):
      "gcp"   — assume full GCP access; fail hard if BQ/GCS unavailable
      "local" — skip all GCP calls; use local CSV files throughout
      "auto"  — probe what's available and use best option (default)
    """

    def __init__(self):
        # ── Library availability ─────────────────────────────────────────
        self.has_bq      = False   # google-cloud-bigquery
        self.has_gcs     = False   # google-cloud-storage
        self.has_auth    = False   # google-auth (ADC)
        self.has_vertex  = False   # google-cloud-aiplatform
        self.has_docx    = False   # python-docx

        try:
            import google.cloud.bigquery; self.has_bq = True
        except ImportError: pass

        try:
            import google.cloud.storage; self.has_gcs = True
        except ImportError: pass

        try:
            import google.auth; self.has_auth = True
        except ImportError: pass

        try:
            import vertexai; self.has_vertex = True
        except ImportError: pass

        try:
            from docx import Document; self.has_docx = True
        except ImportError: pass

        # ── ADC / credentials ────────────────────────────────────────────
        self.has_adc     = False
        self.adc_email   = ""
        if self.has_auth:
            try:
                import google.auth
                creds, project = google.auth.default()
                self.has_adc   = True
                self.adc_email = getattr(creds, "service_account_email",
                                 getattr(creds, "token_uri", "ADC active"))
            except Exception:
                pass

        # ── GCP metadata server (running on a VM/Cloud Run/GKE?) ─────────
        self.on_gcp_vm = False
        try:
            import urllib.request
            req = urllib.request.Request(
                "http://metadata.google.internal/computeMetadata/v1/project/project-id",
                headers={"Metadata-Flavor":"Google"}, method="GET"
            )
            with urllib.request.urlopen(req, timeout=1) as r:
                self.gcp_vm_project = r.read().decode()
                self.on_gcp_vm      = True
        except Exception:
            self.gcp_vm_project = ""

        # ── Resolved environment mode ─────────────────────────────────────
        # Will be set to "gcp" | "local" | "auto" after config is loaded
        self.mode = "auto"

    def resolve(self) -> str:
        """
        Return effective environment: 'gcp' or 'local'.
        Called after config is loaded (CFG.s is available).
        """
        cfg_mode = CFG.s("pipeline","environment") or "auto"
        if cfg_mode == "gcp":
            return "gcp"
        if cfg_mode == "local":
            return "local"
        # auto: GCP if any GCP library and credentials exist, else local
        if (self.has_bq or self.has_gcs) and (self.has_adc or self.on_gcp_vm):
            return "gcp"
        return "local"

    def print_summary(self):
        mode = self.resolve()
        print(f"\n  {B}Environment:{X}  {G if mode=='gcp' else Y}{mode.upper()}{X}")
        rows = [
            ("google-cloud-bigquery", self.has_bq),
            ("google-cloud-storage",  self.has_gcs),
            ("google-auth (ADC)",     self.has_auth),
            ("ADC credentials",       self.has_adc),
            ("Running on GCP VM",     self.on_gcp_vm),
            ("google-cloud-aiplatform",self.has_vertex),
            ("python-docx",           self.has_docx),
        ]
        for name, ok in rows:
            tick = f"{G}✔{X}" if ok else f"{Y}–{X}"
            print(f"  {tick}  {name}")
        if mode == "local":
            print(f"\n  {Y}Running in LOCAL mode — BigQuery and GCS are disabled.")
            print(f"  Data will be read from local CSV files and saved locally.{X}")
            # Show install hint
            missing = []
            if not self.has_bq:  missing.append("google-cloud-bigquery")
            if not self.has_gcs: missing.append("google-cloud-storage")
            if missing:
                print(f"\n  {C}To enable GCP features, run:{X}")
                print(f"    pip install {' '.join(missing)}")
                print(f"    gcloud auth application-default login")
        else:
            print(f"\n  {G}Running in GCP mode — BigQuery and GCS are available.{X}")
            if self.adc_email:
                print(f"  ADC identity: {self.adc_email}")


ENV = _Env()


def _ask(prompt: str, default: str = "") -> str:
    v = input(f"\n  {B}{prompt}{X} [{default}]: ").strip()
    return v if v else default

def _ask_float(prompt: str, default: float) -> float:
    while True:
        r = input(f"\n  {B}{prompt}{X} [{default}]: ").strip()
        if not r: return default
        try:    return float(r)
        except: _warn("Enter a number.")

def _confirm(prompt: str, default: bool = True) -> bool:
    sfx = "[Y/n]" if default else "[y/N]"
    r = input(f"\n  {B}{prompt} {sfx}{X}: ").strip().lower()
    if not r: return default
    return r in ("y","yes")

def _menu(question: str, options: list, default: str = "1") -> str:
    print(f"\n  {B}{question}{X}")
    for i, o in enumerate(options, 1):
        print(f"    {C}{i}.{X} {o}")
    r = input(f"\n  Choice [{default}]: ").strip()
    if not r: r = default
    if r.isdigit() and 1 <= int(r) <= len(options):
        return options[int(r)-1].lower()
    return r.lower()

# Config-aware wrappers
def _c_confirm(prompt: str, default: bool, cfg_val=None) -> bool:
    if cfg_val is not None:
        r = bool(cfg_val); _ok(f"{prompt}: {'Yes' if r else 'No'} (config)"); return r
    if CFG.auto:
        _ok(f"{prompt}: {'Yes' if default else 'No'} (auto default)"); return default
    return _confirm(prompt, default)

def _c_str(prompt: str, default: str, cfg_val=None) -> str:
    if cfg_val is not None:
        _ok(f"{prompt}: '{cfg_val}' (config)"); return str(cfg_val)
    if CFG.auto:
        _ok(f"{prompt}: '{default}' (auto default)"); return default
    return _ask(prompt, default)

def _c_float(prompt: str, default: float, cfg_val=None) -> float:
    if cfg_val is not None:
        try:
            v = float(cfg_val); _ok(f"{prompt}: {v} (config)"); return v
        except: pass
    if CFG.auto:
        _ok(f"{prompt}: {default} (auto default)"); return default
    return _ask_float(prompt, default)

def _c_choice(question: str, options: list, default: str,
              cfg_val: str | None = None) -> str:
    if cfg_val is not None:
        _ok(f"{question}: '{cfg_val}' (config)"); return str(cfg_val)
    if CFG.auto:
        _ok(f"{question}: '{default}' (auto default)"); return default
    return _menu(question, options, default)

# =============================================================================
# REPORT LOG
# =============================================================================
class Log:
    def __init__(self):
        self.project = self.dataset = self.table = self.target = ""
        self.orig_shape = self.final_shape = (0, 0)
        self.steps: list[dict] = []
        self.eda_charts: list[str] = []
        self.corr_chart = ""
        self.encoding_done: list[str] = []
        self.normalization = ""
        self.dropped_cols: list[str] = []
        self.imputed_cols: list[dict] = []
        self.dtype_conversions: list[str] = []
        self.identifier_cols: list[str] = []
        self.model_type = ""
        self.class_labels: dict = {}
        self.preview_info: dict = {}
        self.preview_csv = ""
        self.output_csv = ""
        self.gcs_bucket = self.gcs_base = self.gcs_run = ""
        self.gcs_uploads: list[dict] = []
        self.bq_query = ""
        self.bq_query_notes: list[str] = []
        self.bq_output_uri = ""
        self.high_null_threshold = 50.0
        self.keyword_terms: list[str] = []
        self.keyword_dropped: list[str] = []
        self.high_null_dropped: list[dict] = []

    def add(self, step, title, reason, detail=""):
        self.steps.append({"step": step, "title": title,
                            "reason": reason, "detail": detail})

# temp staging dir for all outputs
STAGING = Path(tempfile.mkdtemp(prefix="ml_pipeline_"))

# =============================================================================
# BIGQUERY LOADER
# =============================================================================
def _load_bq(log: Log) -> pd.DataFrame:
    """
    BigQuery loader — 4 query modes, all controllable from config.
    Mode 1: full_table  — SELECT * with optional LIMIT
    Mode 2: columns     — pick specific columns + optional LIMIT
    Mode 3: filter      — WHERE conditions + optional LIMIT + optional columns
    Mode 4: custom_sql  — user supplies entire SQL query
    All modes show query preview and confirm before executing.
    """
    _banner("STEP 1 · BigQuery Data Source")
    try:
        from google.cloud import bigquery
    except ImportError:
        _warn("google-cloud-bigquery not installed. Run: pip install google-cloud-bigquery db-dtypes")
        raise

    # ── Connection details ────────────────────────────────────────────────────
    pid = CFG.s("bigquery","project_id") or _ask("GCP Project ID")
    did = CFG.s("bigquery","dataset_id") or _ask("BigQuery Dataset name")
    tid = CFG.s("bigquery","table_id")   or _ask("BigQuery Table name")
    if CFG.s("bigquery","project_id"): _ok(f"Project  (config): {pid}")
    if CFG.s("bigquery","dataset_id"): _ok(f"Dataset  (config): {did}")
    if CFG.s("bigquery","table_id"):   _ok(f"Table    (config): {tid}")

    log.project = pid; log.dataset = did; log.table = tid
    full   = f"`{pid}.{did}.{tid}`"
    client = bigquery.Client(project=pid)

    # ── Schema preview ────────────────────────────────────────────────────────
    _step("Fetching table schema …")
    try:
        tbl_ref  = client.get_table(f"{pid}.{did}.{tid}")
        schema   = [(f.name, f.field_type) for f in tbl_ref.schema]
        tot_rows = tbl_ref.num_rows
        _ok(f"Table has {len(schema)} columns and ~{tot_rows:,} rows")
        print(f"\n  {'#':<5} {'Column':<45} {'Type'}")
        print("  " + "─"*62)
        for i, (c, t) in enumerate(schema, 1):
            print(f"  {i:<5} {c:<45} {t}")
    except Exception as e:
        _warn(f"Schema fetch failed ({e}) — column-picker mode unavailable.")
        schema = []; tot_rows = None

    # ── Short-circuit: custom_sql from config ─────────────────────────────────
    custom = CFG.s("bigquery","custom_sql")
    if custom:
        query = custom.strip()
        _ok("Using custom_sql from config.")
        query_notes = ["Mode: Custom SQL (from config)"]
        print(f"\n  {B}Query from config:{X}")
        for line in query.splitlines(): print(f"    {C}{line}{X}")
        if not _c_confirm("Execute this query", True):
            raise SystemExit(0)
        _step("Executing …")
        df = client.query(query).to_dataframe()
        _ok(f"Loaded {df.shape[0]:,} rows × {df.shape[1]} cols")
        log.bq_query = query
        return df, client

    # ── Query mode ────────────────────────────────────────────────────────────
    cfg_mode = CFG.s("bigquery","query_mode")
    MODE_MAP = {"full_table":"1","columns":"2","filter":"3","custom_sql":"4"}
    MODE_OPTS = [
        "Full table — SELECT * (with optional row LIMIT)",
        "Select specific columns — choose columns to include",
        "Filter rows — add WHERE conditions + optional LIMIT",
        "Custom SQL — write your own complete query",
    ]
    if cfg_mode and cfg_mode in MODE_MAP:
        mode = MODE_MAP[cfg_mode]
        _ok(f"Query mode (config): {cfg_mode}")
    else:
        mode = _c_choice("How do you want to load the data?", MODE_OPTS, "1")

    query       = ""
    query_notes = []

    # ── MODE 1: Full table ────────────────────────────────────────────────────
    if "full table" in mode or mode == "1":
        if CFG.g("bigquery","row_limit"):
            limit_str = str(CFG.i("bigquery","row_limit"))
            _ok(f"Row limit (config): {limit_str}")
        else:
            limit_str = "" if CFG.auto else _ask("Row LIMIT (Enter for ALL rows)", "").strip()
        lc = f"\nLIMIT {limit_str}" if limit_str.isdigit() else ""
        query = f"SELECT *\nFROM   {full}{lc}"
        query_notes = [
            "Mode: Full table (SELECT *)",
            f"LIMIT: {limit_str if limit_str.isdigit() else 'None (all rows)'}",
        ]

    # ── MODE 2: Column selection ──────────────────────────────────────────────
    elif "select specific" in mode or mode == "2":
        if CFG.lst("bigquery","columns"):
            chosen = CFG.lst("bigquery","columns")
            _ok(f"Columns (config): {chosen}")
        elif not schema:
            _warn("Schema unavailable — falling back to SELECT *.")
            chosen = None
        else:
            raw = "" if CFG.auto else _ask("Column numbers (comma-separated, Enter=ALL)","").strip()
            if raw:
                chosen = []
                for tok in raw.split(","):
                    tok = tok.strip()
                    if tok.isdigit() and 1 <= int(tok) <= len(schema):
                        chosen.append(schema[int(tok)-1][0])
                if not chosen: chosen = None
            else:
                chosen = None

        if CFG.g("bigquery","row_limit"):
            limit_str = str(CFG.i("bigquery","row_limit"))
        else:
            limit_str = "" if CFG.auto else _ask("Row LIMIT (Enter for ALL)","").strip()

        sel_clause = (", ".join(f"`{c}`" for c in chosen) if chosen else "*")
        lc = f"\nLIMIT {limit_str}" if limit_str.isdigit() else ""
        query = f"SELECT {sel_clause}\nFROM   {full}{lc}"
        query_notes = ["Mode: Column selection",
                       f"Columns: {chosen or 'ALL'}",
                       f"LIMIT: {limit_str or 'None'}"]

    # ── MODE 3: WHERE filter ──────────────────────────────────────────────────
    elif "filter rows" in mode or mode == "3":
        if CFG.lst("bigquery","where_conditions"):
            conditions = CFG.lst("bigquery","where_conditions")
            combiner   = CFG.s("bigquery","where_combiner") or "AND"
            _ok(f"WHERE conditions (config): {conditions}")
            _ok(f"Combiner (config): {combiner}")
            if not CFG.auto:
                while True:
                    extra = input(f"  {C}Extra condition{X} (blank to finish): ").strip()
                    if not extra: break
                    conditions.append(extra); _ok(f"Added: {extra}")
        else:
            if CFG.auto:
                conditions = []; combiner = "AND"
                _warn("auto_mode: no where_conditions configured — loading full table.")
            else:
                print(f"\n  {B}WHERE Condition Builder{X}")
                print(f"  Examples:  age > 25   |   region = 'North'   |   status IS NOT NULL")
                print(f"  Type each condition, press Enter. Blank line to finish.\n")
                conditions = []
                while True:
                    cond = input(f"  {C}Condition {len(conditions)+1}{X} (blank=done): ").strip()
                    if not cond: break
                    conditions.append(cond); _ok(f"Added: {cond}")

                if not conditions:
                    _warn("No conditions — loading full table.")
                    combiner = "AND"
                else:
                    j = _menu("Combine conditions with",
                               ["AND  (all must be true)","OR   (any can be true)"],"1")
                    combiner = "AND" if ("and" in j or j=="1") else "OR"

        where_clause = f"\nWHERE  {f'  {combiner} '.join(conditions)}" if conditions else ""

        # Optional column restriction
        if schema and CFG.lst("bigquery","columns"):
            sel_clause = ", ".join(f"`{c}`" for c in CFG.lst("bigquery","columns"))
        elif schema and not CFG.auto and _confirm("Restrict columns?", False):
            raw = _ask("Column numbers (comma-sep, Enter=ALL)","").strip()
            if raw:
                chosen2 = [schema[int(t)-1][0] for t in raw.split(",")
                           if t.strip().isdigit() and 1<=int(t)<=len(schema)]
                sel_clause = ", ".join(f"`{c}`" for c in chosen2) if chosen2 else "*"
            else: sel_clause = "*"
        else: sel_clause = "*"

        if CFG.g("bigquery","row_limit"):
            limit_str = str(CFG.i("bigquery","row_limit"))
        else:
            limit_str = "" if CFG.auto else _ask("Row LIMIT (Enter=ALL)","").strip()
        lc = f"\nLIMIT {limit_str}" if limit_str.isdigit() else ""
        query = f"SELECT {sel_clause}\nFROM   {full}{where_clause}{lc}"
        query_notes = ["Mode: Filter (WHERE clause)",
                       f"Conditions: {conditions}",
                       f"Combiner: {combiner}",
                       f"LIMIT: {limit_str or 'None'}"]

    # ── MODE 4: Custom SQL (interactive) ──────────────────────────────────────
    else:
        if CFG.auto:
            query = f"SELECT *\nFROM   {full}"
            _warn("auto_mode + custom_sql mode but no sql provided — falling back to SELECT *.")
        else:
            print(f"\n  {B}Custom SQL — type your query. Type END on a new line to finish.{X}\n")
            lines = []
            while True:
                line = input(f"  {C}SQL>{X} ")
                if line.strip().upper() == "END": break
                lines.append(line)
            query = "\n".join(lines).strip() or f"SELECT *\nFROM   {full}"
        query_notes = ["Mode: Custom SQL"]

    # ── Preview + confirm ─────────────────────────────────────────────────────
    print(f"\n  {B}{'─'*56}")
    print(f"  Query to execute:{X}")
    for line in query.splitlines(): print(f"    {C}{line}{X}")
    print(f"  {B}{'─'*56}{X}")
    if not _c_confirm("Execute this query", True):
        _warn("Cancelled."); raise SystemExit(0)

    _step("Executing …")
    df = client.query(query).to_dataframe()
    _ok(f"Loaded {df.shape[0]:,} rows × {df.shape[1]} cols")
    log.bq_query      = query
    log.bq_query_notes = [n for n in query_notes if n]
    return df, client


def _load_demo() -> pd.DataFrame:
    np.random.seed(42); n = 615
    df = pd.DataFrame({
        "customer_id":    range(n),
        "snapshot_date":  pd.date_range("2023-01-01", periods=n, freq="D"),
        "age":            np.random.randint(18,72,n).astype(float),
        "income":         np.random.normal(55000,18000,n),
        "credit_score":   np.random.randint(300,850,n).astype(float),
        "loan_amount":    np.random.exponential(20000,n),
        "loan_term":      np.random.choice([12,24,36,48,60],n).astype(float),
        "employment_type":np.random.choice(["Salaried","Self-Employed","Unemployed"],n),
        "region":         np.random.choice(["North","South","East","West"],n),
        "product_type":   np.random.choice(["Home","Auto","Personal","Education"],n),
        "constant_col":   1,
        "mostly_null":    pd.array([float("nan")]*530+[1.0]*85),
        "churn":          np.random.randint(0,2,n),
    })
    df.loc[np.random.choice(n,45,replace=False),"age"]          = float("nan")
    df.loc[np.random.choice(n,30,replace=False),"income"]       = float("nan")
    df.loc[np.random.choice(n,20,replace=False),"credit_score"] = float("nan")
    return pd.concat([df, df.iloc[:15]], ignore_index=True)


def _load_local_csv(log: "Log") -> pd.DataFrame:
    """
    Load data from a local CSV or directory of CSVs.
    Supports:
      local.csv_path   — single file path
      local.csv_folder — folder; loads the newest CSV inside it
    Also accepts a GCS URI (gs://…) when google-cloud-storage IS available,
    so the same config key works in both environments.
    """
    _banner("STEP 1 · Local CSV Data Source")

    csv_path  = CFG.s("local","csv_path")    or ""
    csv_folder= CFG.s("local","csv_folder")  or ""
    separator = CFG.s("local","separator")   or ","
    encoding  = CFG.s("local","encoding")    or "utf-8"

    # ── Resolve which file to read ─────────────────────────────────────────
    resolved: str = ""

    if csv_path:
        if csv_path.startswith("gs://") and ENV.has_gcs:
            # GCS URI via storage — download to temp
            tmp = Path(tempfile.mkdtemp()) / "input.csv"
            without = csv_path[len("gs://"):]
            bkt, _, blob_path = without.partition("/")
            try:
                from google.cloud import storage as _gcs
                _gcs.Client().bucket(bkt).blob(blob_path).download_to_filename(str(tmp))
                resolved = str(tmp)
                _ok(f"Downloaded from GCS: {csv_path}")
            except Exception as e:
                raise RuntimeError(f"GCS download failed: {e}")
        elif csv_path.startswith("gs://"):
            raise RuntimeError(
                f"GCS URI given ({csv_path}) but google-cloud-storage is not installed.\n"
                f"Install: pip install google-cloud-storage  OR provide a local path."
            )
        else:
            resolved = csv_path

    elif csv_folder:
        folder = Path(csv_folder)
        if not folder.exists():
            raise FileNotFoundError(f"CSV folder not found: {csv_folder}")
        csvs = sorted(folder.glob("*.csv"), key=lambda p: p.stat().st_mtime, reverse=True)
        if not csvs:
            raise FileNotFoundError(f"No CSV files found in: {csv_folder}")
        resolved = str(csvs[0])
        _ok(f"Using newest CSV in folder: {resolved}")

    else:
        if CFG.auto:
            raise FileNotFoundError(
                "Local mode requires local.csv_path or local.csv_folder in config.\n"
                "Example:\n  local:\n    csv_path: /path/to/data.csv"
            )
        raw = _ask("Path to CSV file (or directory containing CSVs)").strip()
        p   = Path(raw)
        if p.is_dir():
            csvs = sorted(p.glob("*.csv"), key=lambda f: f.stat().st_mtime, reverse=True)
            if not csvs:
                raise FileNotFoundError(f"No CSVs found in {raw}")
            resolved = str(csvs[0])
        else:
            resolved = raw

    if not Path(resolved).exists():
        raise FileNotFoundError(f"CSV file not found: {resolved}")

    _ok(f"Reading: {resolved}")

    # ── Read ───────────────────────────────────────────────────────────────
    try:
        df = pd.read_csv(resolved, sep=separator, encoding=encoding,
                         low_memory=False)
    except UnicodeDecodeError:
        _warn("UTF-8 decode failed — retrying with latin-1")
        df = pd.read_csv(resolved, sep=separator, encoding="latin-1",
                         low_memory=False)

    _ok(f"Loaded {df.shape[0]:,} rows × {df.shape[1]} cols  ←  {resolved}")

    log.project = "local"; log.dataset = Path(resolved).parent.name
    log.table   = Path(resolved).stem
    log.bq_query= f"-- local CSV: {resolved}"
    log.bq_query_notes = [f"Mode: Local CSV", f"File: {resolved}"]
    return df



# =============================================================================
# GCS
# =============================================================================
def _configure_gcs(log: "Log") -> None:
    if ENV.resolve() == "local":
        _ok("Local mode — GCS disabled. Outputs will be saved locally.")
        log.gcs_bucket = ""; log.gcs_base = ""; log.gcs_run = ""
        return
    _banner("GCS Output Configuration")
    bucket = CFG.s("gcs","bucket") or _ask("GCS Bucket (no gs:// prefix)")
    base   = CFG.s("gcs","base_folder") or _ask("Base folder (Enter for root)","")
    base   = base.strip("/")
    ts     = datetime.now().strftime("%Y-%m-%d_%H-%M-%S")
    run    = f"{base}/{ts}" if base else ts
    log.gcs_bucket = bucket; log.gcs_base = base; log.gcs_run = run
    _ok(f"gs://{bucket}/{run}/")

def _gcs_put(local: str, blob: str, bucket: str) -> str:
    if not bucket or ENV.resolve() == "local":
        return ""   # silently skip in local mode
    try:
        from google.cloud import storage
        b = storage.Client().bucket(bucket)
        b.blob(blob).upload_from_filename(local)
        return f"gs://{bucket}/{blob}"
    except Exception as e:
        _warn(f"GCS upload failed: {e}"); return ""

# =============================================================================
# STEP 2 — FULL DATA LOAD + COLUMN PROFILE CSV  (no row limit here)
# Profile is uploaded to GCS IMMEDIATELY so user can review before naming target
# =============================================================================
def _preview(df: pd.DataFrame, log: Log) -> None:
    _banner("STEP 2 · Full Data Profile → GCS")
    rows, cols = df.shape
    dups  = int(df.duplicated().sum())
    nulls = int(df.isnull().sum().sum())
    mem   = df.memory_usage(deep=True).sum()/1e6
    ts    = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

    print(f"\n  {'Rows':<26}: {rows:>12,}")
    print(f"  {'Columns':<26}: {cols:>12,}")
    print(f"  {'Duplicate rows':<26}: {dups:>12,}")
    print(f"  {'Total null cells':<26}: {nulls:>12,}  ({nulls/(rows*cols)*100:.2f}% of all cells)")
    print(f"  {'Memory':<26}: {mem:>11.2f} MB")
    print(f"  {'Timestamp':<26}: {ts}")

    # ── Terminal null bar ──────────────────────────────────────────────────────
    ns = (df.isnull().sum()/rows*100).sort_values(ascending=False)
    top = ns[ns>0].head(15)
    if not top.empty:
        print(f"\n  {Y}Top columns by null%:{X}")
        for col, pct in top.items():
            bar = "█"*int(pct/2.5)
            cl  = R if pct>50 else (Y if pct>20 else G)
            print(f"  {col:<42} {pct:>5.1f}%  {cl}{bar}{X}")
    else:
        print(f"\n  {G}No missing values detected.{X}")

    num_set  = set(df.select_dtypes(include=[np.number]).columns)
    dt_set   = set(df.select_dtypes(include=["datetime","datetimetz"]).columns)
    bool_set = set(df.select_dtypes(include=["bool"]).columns)

    def _role(col, n_uniq, null_pct, is_num):
        cl = col.lower()
        if any(k in cl for k in ["id","uuid","guid","key","serial","unnamed","row_num"]):
            return "identifier – drop"
        if any(k in cl for k in ["date","time","snapshot","created","updated","timestamp"]):
            return "datetime – drop"
        if null_pct>70: return "very high-null – drop"
        if null_pct>50: return "high-null – consider drop"
        if n_uniq==1:   return "constant – drop"
        if n_uniq==2 and is_num: return "binary – possible target"
        if n_uniq<=10 and null_pct<5: return "low-cardinality – possible target"
        if is_num:      return "continuous feature"
        return "categorical feature"

    def _target_fit(col, n_uniq, null_pct, is_num, n):
        if null_pct>20: return "poor – high nulls"
        if n_uniq==1:   return "poor – constant"
        if n_uniq==2:   return "excellent – binary classification"
        if n_uniq<=10 and null_pct<5: return "good – multiclass classification"
        if is_num and n_uniq>50: return "good – regression"
        if n_uniq/n>0.9: return "poor – near-unique (likely ID)"
        return "fair – review"

    # ── Build per-column profile (64 attributes) ──────────────────────────────
    _step(f"Profiling {cols} columns …")
    records = []
    for i, col in enumerate(df.columns, 1):
        s  = df[col]; snn = s.dropna()
        dt = str(s.dtype)
        is_num = col in num_set
        nn  = int(s.isnull().sum())
        np_ = round(nn/rows*100, 2)
        nu  = int(s.nunique(dropna=True))
        upc = round(nu/rows*100, 2)
        kind = ("numeric"  if is_num else
                "datetime" if col in dt_set else
                "boolean"  if col in bool_set else "categorical")
        nsev = ("CRITICAL(>70%)" if np_>70 else "HIGH(>50%)" if np_>50
                else "MEDIUM(>20%)" if np_>20 else "LOW(>5%)" if np_>5 else "NONE")
        mn=mx=me=md=st=sk=kt=p1=p5=p25=p75=p95=p99=iq=cv=zc=zp=nc=np2=""
        if is_num and len(snn):
            f = snn.astype(float)
            mn,mx,me,md,st = (round(float(f.min()),4), round(float(f.max()),4),
                              round(float(f.mean()),4), round(float(f.median()),4),
                              round(float(f.std()),4))
            try: sk,kt = round(float(f.skew()),3), round(float(f.kurt()),3)
            except: sk=kt=""
            q = f.quantile([.01,.05,.25,.75,.95,.99])
            p1,p5,p25,p75,p95,p99 = [round(float(q[x]),4) for x in [.01,.05,.25,.75,.95,.99]]
            iq = round(p75-p25, 4)
            cv = round(float(st/me),3) if me else ""
            zc = int((f==0).sum()); zp = round(zc/len(f)*100,2)
            nc = int((f<0).sum());  np2 = round(nc/len(f)*100,2)
        tv=tf=tp=sv=sf=""
        if len(snn):
            vc = s.value_counts(dropna=True)
            if len(vc)>=1: tv,tf,tp = str(vc.index[0]),int(vc.iloc[0]),round(float(vc.iloc[0]/rows*100),2)
            if len(vc)>=2: sv,sf = str(vc.index[1]),int(vc.iloc[1])
        try: samps = snn.unique()[:10].tolist()
        except: samps = []
        sv_d = {f"sample_{j+1}": str(samps[j]) if j<len(samps) else "" for j in range(10)}
        hs=hsc=ld=le=lu=al=ml=mxl=""
        if kind=="categorical" and len(snn):
            ss = snn.astype(str)
            hs  = bool(ss.str.contains(" ",regex=False).any())
            hsc = bool(ss.str.contains(r"[^a-zA-Z0-9 _\-.]",regex=True).any())
            ld  = bool(ss.str.match(r"^\d{4}[-/]\d{2}",na=False).any())
            le  = bool(ss.str.contains(r"@.*\.",regex=True,na=False).any())
            lu  = bool(ss.str.match(r"^https?://",na=False).any())
            lens= ss.str.len()
            al  = round(float(lens.mean()),2); ml=int(lens.min()); mxl=int(lens.max())

        records.append({
            "run_timestamp":ts, "source":f"{log.project}.{log.dataset}.{log.table}",
            "dataset_rows":rows, "dataset_cols":cols,
            "#":i, "column_name":col, "dtype":dt, "pandas_kind":kind,
            "null_count":nn, "null_pct":np_, "null_severity":nsev,
            "unique_count":nu, "uniqueness_pct":upc,
            "is_constant":nu<=1, "is_binary":nu==2, "is_high_card":upc>50 and not is_num,
            "min":mn, "max":mx, "range":round(mx-mn,4) if mn!="" else "",
            "mean":me, "median":md, "std":st, "skewness":sk, "kurtosis":kt,
            "p1":p1,"p5":p5,"p25":p25,"p75":p75,"p95":p95,"p99":p99,"iqr":iq,
            "coeff_variation":cv, "zero_count":zc, "zero_pct":zp,
            "neg_count":nc, "neg_pct":np2,
            "top_value":tv, "top_freq":tf, "top_pct":tp,
            "second_value":sv, "second_freq":sf,
            **sv_d,
            "has_spaces":hs, "has_special":hsc, "looks_date":ld,
            "looks_email":le, "looks_url":lu,
            "avg_str_len":al, "min_str_len":ml, "max_str_len":mxl,
            "suggested_role":      _role(col, nu, np_, is_num),
            "target_suitability":  _target_fit(col, nu, np_, is_num, rows),
            "drop_rec": ("DROP-ID"       if "identifier" in _role(col,nu,np_,is_num) else
                         "DROP-DT"       if "datetime"   in _role(col,nu,np_,is_num) else
                         "DROP-CONST"    if nu<=1        else
                         "DROP-HIGHNULL" if np_>70       else
                         "REVIEW"        if np_>50       else "KEEP"),
            "analyst_notes": ""
        })

    prof     = pd.DataFrame(records)
    csv_path = str(STAGING / "column_profile.csv")
    prof.to_csv(csv_path, index=False)
    _ok(f"Column profile built: {cols} columns × {len(prof.columns)} attributes")

    # ── Upload to GCS IMMEDIATELY (before target prompt) ──────────────────────
    gcs_uri = ""
    if log.gcs_bucket and log.gcs_run:
        gcs_uri = _gcs_put(csv_path,
                           f"{log.gcs_run}/profile/column_profile.csv",
                           log.gcs_bucket)
        if gcs_uri:
            print(f"\n  {G}{B}✔  Column profile uploaded to GCS:{X}")
            print(f"     {gcs_uri}")
            print(f"\n  {C}➤  Open that file in Google Sheets / BigQuery Studio")
            print(f"     to review all {cols} columns — stats, nulls, samples —")
            print(f"     then come back here to enter the target column name.{X}\n")
        else:
            print(f"\n  {Y}Profile saved locally: {csv_path}{X}")
            print(f"  {C}➤  Review the CSV above, then enter your target column.{X}\n")
    else:
        print(f"\n  {G}{B}✔  Column profile saved locally:{X}  {csv_path}")
        print(f"  {C}➤  Open the file above to review columns, then enter your target.{X}\n")

    log.preview_csv  = csv_path
    log.preview_info = {
        "rows":rows, "cols":cols, "duplicates":dups, "null_total":nulls,
        "memory_mb":round(mem,2), "csv_gcs":gcs_uri,
        "columns": [{"name":r["column_name"],"dtype":r["dtype"],
                     "null_pct":r["null_pct"],"unique":r["unique_count"],
                     "null_sev":r["null_severity"],"target_fit":r["target_suitability"],
                     "drop_rec":r["drop_rec"]} for r in records]
    }
    log.add(1,"Full Data Profile",
            "Complete column profile (64 attributes per column) built from ALL rows "
            "and uploaded to GCS immediately — before any sampling or target selection — "
            "so the analyst can review it in a spreadsheet while the pipeline waits.",
            f"Shape {rows}×{cols} | Nulls:{nulls} | Dups:{dups} | "
            f"CSV:{gcs_uri or csv_path}")
    _ok("Preview complete.")


# =============================================================================
# STEP 3 — TARGET SELECTION
# =============================================================================
def _select_target(df: pd.DataFrame, log: Log) -> str:
    _banner("STEP 3 · Target Column Selection")
    print(f"\n  {'#':<5}{'Column':<38}{'DType':<16}{'Unique':>8}  {'Null%':>6}")
    print("  "+"─"*75)
    for i, col in enumerate(df.columns, 1):
        nu = df[col].nunique(); np_ = df[col].isnull().mean()*100
        hint = f"  {Y}← recommended{X}" if nu<=20 and np_<5 else ""
        print(f"  {i:<5}{col:<38}{str(df[col].dtype):<16}{nu:>8,}  {np_:>5.1f}%{hint}")

    cfg_t = CFG.s("pipeline","target_column")
    if cfg_t and cfg_t in df.columns:
        _ok(f"Target (config): '{cfg_t}'")
        target = cfg_t
    elif cfg_t:
        _warn(f"Config target '{cfg_t}' not in dataframe — select interactively.")
        target = _pick_column(df, "target column")
    elif CFG.auto:
        _warn("auto_mode=true but target_column not set — defaulting to last column.")
        target = df.columns[-1]
    else:
        target = _pick_column(df, "target column")

    _ok(f"Target locked: '{target}'  (never dropped/processed)")
    vc = df[target].value_counts(dropna=False)
    for v, cnt in vc.head(15).items():
        pct = cnt/len(df)*100
        print(f"  {str(v):<25} {cnt:>7,}  {pct:.1f}%  {'█'*int(pct/2)}")
    log.target = target
    log.orig_shape = df.shape
    log.add(2,"Target Selection",f"'{target}' selected as target.",
            f"dtype={df[target].dtype} uniq={df[target].nunique()}")
    return target

def _pick_column(df: pd.DataFrame, label: str) -> str:
    while True:
        r = _ask(f"Enter {label} name or number").strip()
        if r.isdigit() and 1 <= int(r) <= len(df.columns):
            return df.columns[int(r)-1]
        if r in df.columns: return r
        _warn("Not found. Try again.")

# =============================================================================
# STEP 3a — TARGET ENCODING  (classification only, right after target selected)
# Ask user: which raw value maps to 0, which to 1, etc.
# The encoded target replaces the raw target column and is preserved unchanged
# through all subsequent preprocessing steps.
# =============================================================================
def _encode_target(df: pd.DataFrame, target: str,
                   model_type: str, log: Log) -> tuple[pd.DataFrame, dict]:
    """
    For classification: show every unique value in the target column and ask
    the user to assign a numeric code (0, 1, 2, …) to each.  The mapping is
    applied immediately and the encoded column replaces the original.

    The raw→numeric mapping is stored in log.class_labels so the report and
    output CSV can display human-readable labels alongside the numeric codes.

    Returns (df_with_encoded_target, class_labels_dict)
    """
    if model_type != "classification":
        return df, {}

    _banner("STEP 3a · Target Encoding (Classification)")

    classes = sorted(df[target].dropna().unique().tolist(), key=str)
    n_cls   = len(classes)

    print(f"\n  Target column : '{target}'")
    print(f"  Unique values : {n_cls}")
    print(f"\n  Current value distribution:")
    vc = df[target].value_counts(dropna=False)
    for v, cnt in vc.items():
        pct = cnt / len(df) * 100
        print(f"  {str(v):<30} {cnt:>8,}  ({pct:.1f}%)  {'█'*int(pct/2)}")

    print(f"\n  {B}Assign a numeric code to each class value.{X}")
    print(f"  For binary classification use 0 and 1.")
    print(f"  For multi-class use 0, 1, 2, … (one unique integer per class).")
    print(f"  Press Enter to keep the suggested default code.\n")

    used_codes:  set   = set()
    class_labels: dict = {}   # raw_value_str → numeric_code

    for idx, cls in enumerate(classes):
        default_code = str(idx)
        while True:
            if CFG.auto:
                code_str = default_code
                _ok(f"  '{cls}' → {code_str}  (auto default)")
            else:
                code_str = _ask(
                    f"Numeric code for class {cls!r}",
                    default=default_code
                ).strip()
            # Validate: must be an integer, must not be reused
            try:
                code_int = int(code_str)
            except ValueError:
                _warn(f"  '{code_str}' is not a valid integer — try again."); continue
            if code_int in used_codes:
                _warn(f"  Code {code_int} already used — enter a different code."); continue
            used_codes.add(code_int)
            class_labels[str(cls)] = code_int
            _ok(f"  '{cls}' → {code_int}")
            break

    # Print the final mapping
    print(f"\n  {B}Target encoding map:{X}")
    print(f"  {'Original value':<30} {'Numeric code':>12}")
    print("  " + "─"*44)
    for raw, code in class_labels.items():
        print(f"  {raw:<30} {code:>12}")

    # Apply mapping to the target column
    # Values not in the map (e.g. NaN) stay as NaN
    df[target] = df[target].map(
        {cls_val: code for cls_val, code in
         [(str(k) if not isinstance(k, str) else k, v)
          for k, v in class_labels.items()] +
         [(k, v) for k, v in class_labels.items()]}
    )

    # Convert to float (allows NaN) then to int after imputation later
    df[target] = pd.to_numeric(df[target], errors="coerce")

    unmapped = df[target].isnull().sum()
    if unmapped > 0:
        _warn(f"{unmapped:,} target rows could not be mapped and are now NaN "
              f"— they will be dropped during imputation.")

    _ok(f"Target '{target}' encoded in-place: {class_labels}")

    log.class_labels = {str(k): v for k, v in class_labels.items()}
    log.add(2.5, "Target Encoding",
            f"Each unique value of '{target}' was mapped to a user-defined numeric "
            "code. The encoded column replaces the original target and is preserved "
            "unchanged through all preprocessing steps.",
            f"Mapping: {class_labels}")

    return df, log.class_labels


# =============================================================================
# STEP 3b — STRATIFIED RELOAD
# =============================================================================
def _stratified_reload(df: pd.DataFrame, target: str, log: Log, client) -> pd.DataFrame:
    limit = CFG.i("bigquery","sampling_limit")
    if not limit: return df
    _banner("STEP 3b · Stratified Data Reload")
    full = f"`{log.project}.{log.dataset}.{log.table}`"
    n_uniq = df[target].nunique(dropna=True)
    if n_uniq > 20:
        query = f"SELECT * FROM {full} ORDER BY RAND() LIMIT {limit}"
        strategy = f"Random sample (continuous target, {limit:,} rows)"
    else:
        classes = df[target].dropna().unique().tolist()
        per = max(1, limit // len(classes))
        parts = [f"  SELECT * FROM {full} WHERE {target}={repr(c) if isinstance(c,str) else c} ORDER BY RAND() LIMIT {per}"
                 for c in classes]
        query = "\nUNION ALL\n".join(parts)
        strategy = f"Stratified ({len(classes)} classes × {per:,} rows)"
    _ok(strategy)
    if not _c_confirm("Execute stratified reload", True):
        return df
    try:
        df2 = client.query(query).to_dataframe()
        _ok(f"Reloaded: {df2.shape[0]:,} rows")
        log.bq_query = query
        log.add(2.5,"Stratified Reload",strategy,f"Shape:{df2.shape}")
        return df2
    except Exception as e:
        _warn(f"Reload failed: {e}"); return df

# =============================================================================
# STEP 3c — IDENTIFIER SELECTION
# =============================================================================
def _select_identifiers(df: pd.DataFrame, target: str, log: Log):
    _banner("STEP 3c · Identifier Column Selection")
    cands = [c for c in df.columns if c != target]
    print(f"\n  {'#':<5}{'Column':<40}{'DType':<16}{'Unique%':>9}  Hint")
    print("  "+"─"*80)
    for i, col in enumerate(cands, 1):
        nu = df[col].nunique(); up = nu/len(df)*100
        hint = f"  {C}← ID?{X}" if any(k in col.lower() for k in ["id","uuid","key","serial"]) \
               else (f"  {Y}← high uniqueness{X}" if up>90 else "")
        print(f"  {i:<5}{col:<40}{str(df[col].dtype):<16}{up:>8.1f}%{hint}")

    cfg_ids = CFG.lst("pipeline","identifier_columns") or []
    valid   = [c for c in cfg_ids if c in df.columns]
    if valid:
        _ok(f"Identifiers (config): {valid}")
        id_cols = valid
    elif CFG.auto:
        _ok("auto_mode: no identifiers set"); id_cols = []
    else:
        r = _ask("Identifier column(s) — numbers or names, comma-sep (Enter=none)", "")
        id_cols = []
        if r:
            for tok in r.split(","):
                tok = tok.strip()
                if tok.isdigit() and 1<=int(tok)<=len(cands): id_cols.append(cands[int(tok)-1])
                elif tok in df.columns: id_cols.append(tok)

    if not id_cols:
        _ok("No identifiers — all columns go through pipeline.")
        log.identifier_cols = []
        return df, pd.DataFrame(index=df.index)

    df_id  = df[id_cols].copy().reset_index(drop=True)
    df_feat = df.drop(columns=id_cols).reset_index(drop=True)
    for c in id_cols: _ok(f"  Identifier: '{c}'")
    print(f"  {G}Identifiers sidelined. Will be re-joined at the end.{X}")
    log.identifier_cols = id_cols
    log.add(3,"Identifier Split",f"Columns excluded from pipeline: {id_cols}",
            f"{len(df_feat.columns)} feature columns remain")
    return df_feat, df_id

# =============================================================================
# STEP 4 — KEYWORD DROP
# =============================================================================
def _keyword_drop(df: pd.DataFrame, target: str, log: Log) -> pd.DataFrame:
    _banner("STEP 4 · Keyword-Based Column Drop")
    AUTO = ["id","_id","uuid","guid","snapshot","date","timestamp",
            "created","updated","modified","index","row_num","unnamed","serial"]
    terms_cfg = CFG.lst("pipeline","keyword_drop_terms")
    if terms_cfg:
        terms = [t.lower() for t in terms_cfg]
        _ok(f"Keyword terms (config): {terms}")
    else:
        found = [k for k in AUTO if any(k in c.lower() for c in df.columns if c!=target)]
        if found: _warn(f"Auto-suggested: {found}")
        if CFG.auto:
            terms = found
        else:
            r = _ask("Keyword terms (comma-sep, Enter to skip)","")
            terms = [t.strip().lower() for t in r.split(",") if t.strip()] if r else found

    if not terms:
        _ok("No keyword terms — skipping."); return df

    all_dropped = []
    matched = [c for c in df.columns if c!=target and any(t in c.lower() for t in terms)]
    if matched:
        print(f"\n  Columns matching {terms}:")
        for c in matched: print(f"    {R}✘{X}  {c}  ({df[c].dtype})")
        if _c_confirm(f"Drop all {len(matched)} matched columns", True):
            df = df.drop(columns=matched)
            all_dropped = matched
            for c in matched: _drop(f"Dropped '{c}'")

    # Reverification
    remaining = [c for c in df.columns if c!=target]
    print(f"\n  {B}── {len(remaining)} feature columns remain ──{X}")
    for i,c in enumerate(remaining,1):
        print(f"  {i}. {c}  ({df[c].dtype})")

    if not CFG.auto:
        while _confirm("Add more keyword terms?", False):
            r = _ask("More terms (comma-sep)")
            extra = [t.strip().lower() for t in r.split(",") if t.strip()]
            new_m = [c for c in df.columns if c!=target and any(t in c.lower() for t in extra)]
            if new_m:
                for c in new_m: print(f"    {R}✘{X}  {c}")
                if _confirm(f"Drop these {len(new_m)}?"):
                    df = df.drop(columns=new_m)
                    all_dropped += new_m

    if all_dropped:
        log.dropped_cols += all_dropped
        log.keyword_terms = terms
        log.keyword_dropped = all_dropped
        log.add(4,"Keyword Drop","ID/date/metadata columns removed.",
                f"Terms:{terms} | Dropped:{all_dropped}")
    return df

# =============================================================================
# STEP 5 — HIGH-NULL DROP
# =============================================================================
def _high_null_drop(df: pd.DataFrame, target: str, log: Log) -> pd.DataFrame:
    _banner("STEP 5 · Drop High-Null Columns")
    ns = df.isnull().sum()/len(df)*100
    print(f"\n  {'Column':<40}{'Null%':>8}  Bar")
    print("  "+"─"*72)
    for col, pct in ns.sort_values(ascending=False).items():
        if pct==0: continue
        bar = "█"*int(pct/2.5)+"░"*(40-int(pct/2.5))
        cl  = R if pct>50 else (Y if pct>20 else G)
        tgt = f"  {C}← TARGET{X}" if col==target else ""
        print(f"  {col:<40}{pct:>7.1f}%  {cl}{bar}{X}{tgt}")

    thresh = _c_float("Drop columns with null% ABOVE (%)", 50.0,
                      CFG.f("pipeline","high_null_threshold"))
    log.high_null_threshold = thresh
    cands = [c for c in df.columns if c!=target and ns.get(c,0)>thresh]
    if not cands:
        _ok(f"No columns exceed {thresh}%"); return df

    print(f"\n  {len(cands)} column(s) above {thresh}%:")
    drops = []
    for c in cands:
        drops.append({"col":c,"null_pct":round(ns[c],2),"null_count":int(df[c].isnull().sum())})
        print(f"  {R}✘{X}  {c:<40} {ns[c]:.1f}%")
    if _c_confirm(f"Drop {len(cands)} high-null column(s)", True):
        df = df.drop(columns=cands)
        log.dropped_cols += cands
        log.high_null_dropped = drops
        _drop(f"Dropped {len(cands)} columns.")
        log.add(5,"High-Null Drop",f"Columns above {thresh}% null removed.",
                f"Dropped:{cands}")
    return df

# =============================================================================
# STEP 6 — CLEANING (dupes, LV, dtype conv, impute, outliers)
# =============================================================================
def _clean(df: pd.DataFrame, target: str, log: Log) -> pd.DataFrame:

    # 6a. Duplicates
    _banner("STEP 6a · Duplicate Rows")
    n_dup = int(df.duplicated().sum())
    if n_dup:
        if _c_confirm(f"Remove {n_dup:,} duplicate rows", True,
                      CFG.b("pipeline","remove_duplicates",default=None)):
            df = df.drop_duplicates().reset_index(drop=True)
            _drop(f"Removed {n_dup:,} rows.")
            log.add(5.1,"Duplicates",f"{n_dup:,} duplicates removed.")
    else: _ok("No duplicates.")

    # 6b. Low-variance
    _banner("STEP 6b · Near-Constant Columns")
    lv = _c_float("Drop cols where top value covers MORE than (%) of rows", 99.0,
                  CFG.f("pipeline","low_variance_threshold"))
    lv_drop = [(c, df[c].value_counts(normalize=True).iloc[0]*100)
               for c in df.columns if c!=target
               if df[c].value_counts(normalize=True).iloc[0]*100 > lv]
    if lv_drop:
        for c,f in lv_drop: print(f"  {R}✘{X}  {c:<40} top={f:.1f}%")
        if _c_confirm(f"Drop {len(lv_drop)} near-constant columns", True):
            df = df.drop(columns=[c for c,_ in lv_drop])
            log.dropped_cols += [c for c,_ in lv_drop]
            log.add(6,"Low-Variance Drop",f"Threshold={lv}%",str([c for c,_ in lv_drop]))
    else: _ok("No near-constant columns.")

    # 6c. Dtype normalisation
    _banner("STEP 6c · Data Type Normalisation & Conversion")
    converted = []
    # Phase 1: nullable extension types from BigQuery
    for col in df.columns:
        dtype = df[col].dtype; old = str(dtype)
        if hasattr(dtype,"numpy_dtype") and dtype.numpy_dtype.kind in ("i","u"):
            df[col] = df[col].astype("float64") if df[col].isnull().any() else df[col].astype("int64")
            _ok(f"'{col}': {old} → {df[col].dtype}"); converted.append(col)
        elif hasattr(dtype,"numpy_dtype") and dtype.numpy_dtype.kind == "f":
            df[col] = df[col].astype("float64"); converted.append(col)
        elif isinstance(dtype, pd.BooleanDtype):
            df[col] = df[col].astype("object"); converted.append(col)
        elif isinstance(dtype, pd.StringDtype):
            df[col] = df[col].astype("object"); converted.append(col)
        elif not isinstance(dtype, np.dtype):
            try:
                df[col] = df[col].astype("float64") if df[col].isnull().any() else df[col].astype(str)
            except: df[col] = df[col].astype(str)
            converted.append(col)

    # Phase 2: object cols that look numeric or datetime
    obj_set = set(df.select_dtypes(include=["object","category"]).columns)
    for col in list(obj_set):
        if col == target: continue
        snn = df[col].dropna()
        if len(snn)==0: continue
        cn = pd.to_numeric(df[col], errors="coerce")
        if cn.notna().sum()/max(df[col].notna().sum(),1) >= 0.95:
            df[col] = cn.astype("float64"); _ok(f"'{col}': object→float64"); converted.append(col); continue
        try:
            with warnings.catch_warnings():
                warnings.simplefilter("ignore")
                cd = pd.to_datetime(df[col], errors="coerce")
            if cd.notna().sum()/max(df[col].notna().sum(),1) >= 0.90:
                df[col] = cd; _ok(f"'{col}': object→datetime"); converted.append(col)
        except: pass

    # Phase 3: manual overrides from config
    ov = CFG.s("pipeline","dtype_override") or ""
    if not ov and not CFG.auto:
        ov = _ask("Manual dtype overrides col:type,... (Enter skip)","")
    if ov:
        for pair in ov.split(","):
            if ":" not in pair: continue
            c, t = [x.strip() for x in pair.split(":",1)]
            if c not in df.columns: continue
            try:
                if t in ("numeric","float"): df[c] = pd.to_numeric(df[c],errors="coerce").astype("float64")
                elif t == "int": df[c] = pd.to_numeric(df[c],errors="coerce").astype("float64")
                elif t in ("datetime","date"): df[c] = pd.to_datetime(df[c],errors="coerce")
                elif t == "category": df[c] = df[c].astype("object").astype("category")
                elif t in ("string","str","object"): df[c] = df[c].astype(str)
                _ok(f"Override '{c}' → {t}"); converted.append(c)
            except Exception as e: _warn(f"Override failed: {e}")

    log.dtype_conversions = list(set(converted))
    if converted: log.add(6.1,"Dtype Conversion","Extension/nullable types normalised.",str(set(converted)))

    # Reclassify
    num_set  = set(df.select_dtypes(include=[np.number]).columns)
    dt_set   = set(df.select_dtypes(include=["datetime","datetimetz"]).columns)
    bool_set = set(df.select_dtypes(include=["bool"]).columns)
    obj_set  = set(df.select_dtypes(include=["object","category"]).columns)

    # Print current dtypes
    print(f"\n  {'Column':<40}{'Dtype':<20}Kind")
    print("  "+"─"*65)
    for col in df.columns:
        if col==target: continue
        kind = ("numeric" if col in num_set else "datetime" if col in dt_set
                else "boolean" if col in bool_set else "categorical")
        print(f"  {col:<40}{str(df[col].dtype):<20}{kind}")

    # 6d. Imputation
    _banner("STEP 6d · Null Value Imputation")
    null_cols = [c for c in df.columns if df[c].isnull().any() and c!=target]
    if not null_cols:
        _ok("No nulls to impute.")
    else:
        print(f"\n  {len(null_cols)} columns have nulls:")
        for c in null_cols:
            kind = ("numeric" if c in num_set else "datetime" if c in dt_set
                    else "boolean" if c in bool_set else "categorical")
            print(f"  • {c:<40} {df[c].isnull().mean()*100:.1f}%  ({kind})")

        n_strat = _c_str("Numeric strategy (mean/median/mode/drop_rows)","median",
                         CFG.s("pipeline","impute_numeric"))
        c_strat = _c_str("Categorical strategy (mode/unknown)","mode",
                         CFG.s("pipeline","impute_categorical"))

        for col in null_cols:
            if col in num_set:
                fill_map = {"mean":lambda: float(df[col].mean()),
                            "mode":lambda: float(df[col].mode()[0]),
                            "median":lambda: float(df[col].median())}
                if "drop" in n_strat:
                    df = df.dropna(subset=[col]).reset_index(drop=True)
                    _ok(f"'{col}' → dropped rows"); log.imputed_cols.append({"col":col,"strategy":"drop_rows","type":"numeric"}); continue
                fill = fill_map.get(n_strat, fill_map["median"])()
                if not pd.api.types.is_float_dtype(df[col]): df[col] = df[col].astype("float64")
                df[col] = df[col].fillna(fill)
                _ok(f"Numeric '{col}' → {n_strat} ({fill:.4g})")
                log.imputed_cols.append({"col":col,"strategy":n_strat,"type":"numeric"})
            elif col in dt_set:
                if CFG.auto:
                    df[col] = df[col].ffill(); strategy = "ffill"
                else:
                    a = _menu(f"Datetime '{col}' nulls?",["Forward fill","Backward fill","Drop rows","Leave NaT"],"1")
                    if "forward" in a or a=="1": df[col]=df[col].ffill(); strategy="ffill"
                    elif "backward" in a or a=="2": df[col]=df[col].bfill(); strategy="bfill"
                    elif "drop" in a or a=="3": df=df.dropna(subset=[col]).reset_index(drop=True); strategy="drop"
                    else: strategy="NaT"
                _ok(f"Datetime '{col}' → {strategy}")
                log.imputed_cols.append({"col":col,"strategy":strategy,"type":"datetime"})
            elif col in bool_set:
                fill = bool(df[col].mode()[0]) if len(df[col].mode()) else False
                df[col] = df[col].fillna(fill); _ok(f"Bool '{col}' → {fill}")
                log.imputed_cols.append({"col":col,"strategy":"mode","type":"bool"})
            else:
                fill = df[col].mode()[0] if "mode" in c_strat and len(df[col].mode()) else "Unknown"
                df[col] = df[col].fillna(fill); _ok(f"Categorical '{col}' → '{fill}'")
                log.imputed_cols.append({"col":col,"strategy":c_strat,"type":"categorical"})

        log.add(7,"Imputation","dtype-aware imputation applied.",
                f"numeric:{n_strat} categorical:{c_strat}")

    # 6e. Outliers
    _banner("STEP 6e · Outlier Handling")
    if _c_confirm("Handle outliers", True, CFG.b("pipeline","handle_outliers",default=None)):
        method = CFG.s("pipeline","outlier_method") or "iqr"
        action = CFG.s("pipeline","outlier_action") or "clip"
        _ok(f"Method: {method}  Action: {action}")
        num_feat = [c for c in df.select_dtypes(include=[np.number]).columns if c!=target]
        total = 0
        for col in num_feat:
            if "iqr" in method:
                Q1,Q3 = df[col].quantile(.25),df[col].quantile(.75)
                lo,hi = Q1-1.5*(Q3-Q1), Q3+1.5*(Q3-Q1)
            else:
                mu,sigma = df[col].mean(),df[col].std()
                lo,hi = mu-3*sigma, mu+3*sigma
            mask = (df[col]<lo)|(df[col]>hi); n = int(mask.sum())
            if not n: continue
            total += n
            if "clip" in action:   df[col] = df[col].clip(lo,hi)
            elif "drop" in action: df = df[~mask].reset_index(drop=True)
            else:                  df[f"{col}_outlier"] = mask.astype(int)
            _warn(f"'{col}': {n:,} outliers → {action}")
        if total: log.add(8,"Outliers",f"method:{method} action:{action}",f"total:{total:,}")
        else: _ok("No outliers detected.")
    return df

# =============================================================================
# STEP 7 — EDA
# =============================================================================
def _eda(df: pd.DataFrame, target: str, log: Log) -> None:
    _banner("STEP 7 · Exploratory Data Analysis")
    _step("Generating charts …")
    num_cols = [c for c in df.select_dtypes(include=[np.number]).columns if c!=target]
    cat_cols = [c for c in df.select_dtypes(exclude=[np.number]).columns if c!=target]
    binary_tgt = df[target].nunique()==2

    def _save(fig, name):
        p = str(STAGING/f"{name}.png")
        fig.savefig(p,dpi=110,bbox_inches="tight"); plt.close(fig)
        log.eda_charts.append(p); return p

    # Target dist
    fig,ax = plt.subplots(figsize=(6,4))
    if df[target].nunique()<=15:
        vc=df[target].value_counts(); ax.bar(vc.index.astype(str),vc.values,color=PAL[:len(vc)])
    else:
        ax.hist(df[target].dropna(),bins=30,color=PAL[0],edgecolor="white")
    ax.set_title(f"Target: {target}",fontweight="bold"); fig.tight_layout(); _save(fig,"01_target_dist")
    _ok("Chart: Target distribution")

    # Numeric histograms
    if num_cols:
        nc=min(3,len(num_cols)); nr=(len(num_cols)+nc-1)//nc
        fig,axes=plt.subplots(nr,nc,figsize=(6*nc,4*nr))
        axes=np.array(axes).flatten()
        for i,col in enumerate(num_cols):
            ax=axes[i]; data=df[col].dropna()
            ax.hist(data,bins=30,color=PAL[i%len(PAL)],alpha=0.7,edgecolor="white",density=True)
            try:
                if data.nunique()>1: data.plot.kde(ax=ax,color="black",lw=1.5)
            except: pass
            ax.set_title(col,fontweight="bold")
        for j in range(len(num_cols),len(axes)): axes[j].set_visible(False)
        fig.suptitle("Numeric Distributions",fontsize=13,fontweight="bold")
        fig.tight_layout(); _save(fig,"02_numeric_dist"); _ok("Chart: Numeric distributions")

    # Boxplots by target
    if binary_tgt and num_cols:
        nc=min(3,len(num_cols)); nr=(len(num_cols)+nc-1)//nc
        fig,axes=plt.subplots(nr,nc,figsize=(6*nc,4*nr)); axes=np.array(axes).flatten()
        for i,col in enumerate(num_cols):
            ax=axes[i]
            groups=[df.loc[df[target]==v,col].dropna() for v in df[target].unique()]
            ax.boxplot(groups,labels=[str(v) for v in df[target].unique()],
                       patch_artist=True,boxprops=dict(facecolor=PAL[0],alpha=0.6),
                       medianprops=dict(color="black",lw=2))
            ax.set_title(col,fontweight="bold")
        for j in range(len(num_cols),len(axes)): axes[j].set_visible(False)
        fig.suptitle("Features by Target Class",fontsize=13,fontweight="bold")
        fig.tight_layout(); _save(fig,"03_boxplots"); _ok("Chart: Boxplots by target")

    # Categorical distributions
    if cat_cols:
        pc=[c for c in cat_cols if df[c].nunique()<=20]
        if pc:
            nc=min(3,len(pc)); nr=(len(pc)+nc-1)//nc
            fig,axes=plt.subplots(nr,nc,figsize=(6*nc,4*nr)); axes=np.array(axes).flatten()
            for i,col in enumerate(pc):
                ax=axes[i]; vc=df[col].value_counts().head(15)
                ax.barh(vc.index.astype(str),vc.values,color=PAL[i%len(PAL)])
                ax.set_title(col,fontweight="bold"); ax.invert_yaxis()
            for j in range(len(pc),len(axes)): axes[j].set_visible(False)
            fig.suptitle("Categorical Distributions",fontsize=13,fontweight="bold")
            fig.tight_layout(); _save(fig,"04_cat_dist"); _ok("Chart: Categorical distributions")

    # Correlation heatmap
    if len(num_cols)>=2:
        try:
            fig,ax=plt.subplots(figsize=(max(8,len(num_cols)),max(6,len(num_cols)-1)))
            cm=df[num_cols+([ target] if target in df.select_dtypes(include=[np.number]).columns else [])].corr()
            mask=np.triu(np.ones_like(cm,dtype=bool))
            sns.heatmap(cm,mask=mask,annot=True,fmt=".2f",cmap="coolwarm",center=0,ax=ax,
                        annot_kws={"size":8},linewidths=0.5)
            ax.set_title("Correlation Heatmap",fontweight="bold",fontsize=13)
            fig.tight_layout(); _save(fig,"05_corr_heatmap"); _ok("Chart: Correlation heatmap")
        except Exception as e: _warn(f"Heatmap failed: {e}"); plt.close("all")

    _ok(f"EDA complete — {len(log.eda_charts)} charts")

# =============================================================================
# STEP 8 — CORRELATION FILTER
# =============================================================================
def _corr_filter(df: pd.DataFrame, target: str, log: Log) -> pd.DataFrame:
    _banner("STEP 8 · Correlation Filter")
    num_df = df.select_dtypes(include=[np.number])
    if target not in num_df.columns:
        _warn("Target non-numeric — skipping correlation filter."); return df
    corr_full = num_df.corr()
    if target not in corr_full.columns: return df
    corr = corr_full[target].drop(target,errors="ignore").abs().sort_values(ascending=False).dropna()
    if corr.empty: _ok("No valid correlations."); return df
    print(f"\n  {'Feature':<40}{'|Corr|':>8}  Bar")
    print("  "+"─"*60)
    for col,val in corr.items():
        bar = "█"*int(val*40) if pd.notna(val) else "—"
        print(f"  {col:<40}{val:>8.4f}  {bar}")

    # Save corr chart
    try:
        fig,ax=plt.subplots(figsize=(8,max(4,len(corr)*0.4+1)))
        colors=[PAL[0] if v>=0.1 else "#CCCCCC" for v in corr.values]
        ax.barh(corr.index[::-1],corr.values[::-1],color=colors[::-1])
        ax.axvline(0.1,color="red",linestyle="--",lw=1.2)
        ax.set_title(f"Feature Correlation with '{target}'",fontweight="bold")
        ax.set_xlabel("Absolute Pearson Correlation")
        fig.tight_layout()
        p = str(STAGING/"09_target_corr.png")
        fig.savefig(p,dpi=110,bbox_inches="tight"); plt.close(fig)
        log.corr_chart = p
    except Exception as e: _warn(f"Corr chart failed: {e}"); plt.close("all")

    lo = _c_float("Drop features with |corr| BELOW",0.01, CFG.f("pipeline","corr_low_threshold"))
    low = corr[corr<lo].index.tolist()
    if low:
        print(f"\n  Below {lo}: {low}")
        if _c_confirm("Drop low-correlation features", True):
            df = df.drop(columns=low)
            log.dropped_cols += low
            log.add(9,"Low-Corr Drop",f"threshold={lo}",str(low))

    hi = _c_float("Drop one from each pair with |corr| ABOVE",0.95, CFG.f("pipeline","corr_high_threshold"))
    nf = [c for c in df.select_dtypes(include=[np.number]).columns if c!=target]
    if len(nf)>=2:
        try:
            fc = df[nf].corr().abs()
            upper = fc.where(np.triu(np.ones_like(fc,dtype=bool),k=1))
            to_hi: set = set()
            for c in upper.columns:
                for r in upper.index:
                    v = upper.loc[r,c]
                    if pd.notna(v) and v>hi: to_hi.add(c); _warn(f"Multicoll: '{c}'↔'{r}' ({v:.3f})")
            if to_hi and _c_confirm(f"Drop multicollinear {list(to_hi)}", True):
                df = df.drop(columns=list(to_hi)); log.dropped_cols += list(to_hi)
                log.add(10,"Multicoll Drop",f"threshold={hi}",str(list(to_hi)))
        except Exception as e: _warn(f"Multicoll check failed: {e}")
    return df

# =============================================================================
# STEP 9 — ENCODING
# =============================================================================
def _encode(df: pd.DataFrame, target: str, log: Log) -> pd.DataFrame:
    _banner("STEP 9 · Categorical Encoding")
    cat_cols = [c for c in df.select_dtypes(exclude=[np.number]).columns if c!=target]
    if not cat_cols: _ok("No categorical columns."); return df
    for c in cat_cols: print(f"  • {c:<40} unique={df[c].nunique()}")
    method = CFG.s("pipeline","encoding_method") or \
             _c_choice("Encoding method",["onehot","label","skip"],"onehot")
    card = int(_c_float("One-hot max cardinality",20, CFG.i("pipeline","encoding_cardinality_limit")))
    done = []
    if "onehot" in method:
        enc = [c for c in cat_cols if df[c].nunique()<=card]
        skip= [c for c in cat_cols if df[c].nunique()> card]
        if skip: _warn(f"High-cardinality skipped: {skip}")
        if enc:  df = pd.get_dummies(df,columns=enc,drop_first=True); done=enc; _ok(f"One-hot: {enc}")
    elif "label" in method:
        le = LabelEncoder()
        for c in cat_cols: df[c]=le.fit_transform(df[c].astype(str)); done.append(c)
        _ok(f"Label encoded: {cat_cols}")
    else: _ok("Encoding skipped.")
    log.encoding_done = done
    log.add(11,"Encoding",f"method={method}",str(done))
    return df

# =============================================================================
# STEP 10 — NORMALISATION (all numeric including encoded)
# =============================================================================
def _normalise(df: pd.DataFrame, target: str, log: Log) -> pd.DataFrame:
    _banner("STEP 10 · Normalisation")
    print(f"  {Y}Applies to ALL numeric cols (including encoded categoricals){X}")
    if not _c_confirm("Normalise features", True, CFG.b("pipeline","normalise",default=None)):
        _ok("Skipped."); return df
    method = CFG.s("pipeline","normalise_method") or \
             _c_choice("Scaler",["standard","minmax","robust","maxabs"],"standard")
    smap = {"standard":StandardScaler(),"minmax":MinMaxScaler(),
            "robust":RobustScaler(),"maxabs":MaxAbsScaler()}
    scaler = next((v for k,v in smap.items() if k in method.lower()), StandardScaler())
    num_cols = [c for c in df.select_dtypes(include=[np.number]).columns if c!=target]
    if num_cols:
        df[num_cols] = df[num_cols].astype("float64")
        df[num_cols] = scaler.fit_transform(df[num_cols])
        _ok(f"{type(scaler).__name__} applied to {len(num_cols)} cols.")
        log.normalization = type(scaler).__name__
        log.add(12,"Normalisation",f"method={type(scaler).__name__}",str(num_cols))
    return df

# =============================================================================
# STEP 11 — MODEL TYPE  (class labels already applied in STEP 3a)
# =============================================================================
def _model_type(df: pd.DataFrame, target: str, log: Log) -> str:
    _banner("STEP 11 · Model Type")
    n_uniq = df[target].nunique(dropna=True)
    sugg   = "classification" if n_uniq <= 20 else "regression"
    print(f"  Target '{target}': {n_uniq} unique values  (suggested: {sugg})")

    # If already set during _encode_target step, honour it
    if log.model_type in ("classification","regression"):
        _ok(f"Model type already set: {log.model_type}"); return log.model_type

    mt = CFG.s("pipeline","model_type")
    if mt in ("classification","regression"):
        _ok(f"Model type (config): {mt}")
    elif CFG.auto:
        mt = sugg; _ok(f"Model type (auto): {mt}")
    else:
        r  = _menu("Model type?",["Classification","Regression"],"1")
        mt = "classification" if "class" in r else "regression"

    log.model_type = mt
    log.add(11,"Model Type",f"type={mt}",f"target_uniq={n_uniq}")
    return mt


# =============================================================================
# STEP 12 — BUILD OUTPUT CSV
# =============================================================================
def _build_output(df: pd.DataFrame, df_id: pd.DataFrame,
                  target: str, log: Log) -> str:
    _banner("STEP 12 · Build Output CSV")
    feat_cols = [c for c in df.columns if c != target]
    parts = []
    if not df_id.empty:
        parts.append(df_id.reset_index(drop=True))
    parts.append(df[feat_cols].reset_index(drop=True))
    if target in df.columns:
        parts.append(df[[target]].reset_index(drop=True))

    # If classification: add a human-readable class_label column
    # class_labels maps  original_string_value → numeric_code
    # We reverse it here: numeric_code → original_string_value
    if log.model_type == "classification" and log.class_labels:
        reverse_map = {str(v): k for k, v in log.class_labels.items()}
        def _lbl(v):
            return reverse_map.get(str(int(v)) if pd.notna(v) else "nan",
                                   str(v) if pd.notna(v) else "")
        parts.append(
            df[target].apply(_lbl).rename("class_label").reset_index(drop=True)
        )

    # Blank prediction column — fill after model inference
    parts.append(pd.DataFrame({"prediction": [""] * len(df)}))
    out  = pd.concat(parts, axis=1)
    path = str(STAGING / "processed_output.csv")
    out.to_csv(path, index=False)
    log.output_csv = path

    _ok(f"Output CSV: {out.shape[0]:,} rows × {out.shape[1]} cols")
    _ok(f"  Identifiers  : {list(df_id.columns) if not df_id.empty else 'none'}")
    _ok(f"  Features     : {len(feat_cols)}")
    _ok(f"  Target       : '{target}' (numeric encoded)")
    if log.model_type == "classification" and log.class_labels:
        _ok(f"  class_label  : human-readable reverse-lookup column added")
    _ok(f"  prediction   : blank — fill after model inference")

    log.add(14,"Output CSV",
            "Processed dataset with identifiers, encoded features, numeric target, "
            "human-readable class_label, and blank prediction column.",
            f"Shape:{out.shape} | Target:'{target}' | "
            f"Encoding:{log.class_labels}")
    return path


# =============================================================================
# BQ WRITE
# =============================================================================
def _bq_write(df_out: pd.DataFrame, log: "Log") -> str:
    _banner("STEP 13 · Write to BigQuery")

    # Skip entirely in local mode
    if ENV.resolve() == "local":
        _ok("Local mode — BigQuery write skipped.")
        _ok("Processed data saved to local folder (see above).")
        return ""

    # Skip if dataset/table blank in config
    skip = (not CFG.s("output","dataset_id") and not CFG.s("output","table_id"))
    if skip:
        if CFG.auto: _ok("BQ write skipped (not configured)."); return ""
        if not _confirm("Write output to BigQuery?", False): return ""
    try:
        from google.cloud import bigquery as bq
    except ImportError:
        _warn("google-cloud-bigquery not installed — skipping BQ write."); return ""
    pid = CFG.s("output","project_id") or log.project or _ask("Output BQ Project")
    did = CFG.s("output","dataset_id") or _ask("Output BQ Dataset")
    tid = CFG.s("output","table_id")   or _ask("Output BQ Table")
    if not did or not tid: _ok("BQ write skipped (no dataset/table)."); return ""
    dest = f"{pid}.{did}.{tid}"
    mode = CFG.s("output","write_mode") or "replace"
    _ok(f"Writing to: {dest}  mode={mode}")
    if not _c_confirm(f"Confirm write {df_out.shape[0]:,} rows → {dest}", True):
        return ""
    df2 = df_out.copy()
    df2.columns = [c.replace(" ","_").replace("-","_").replace(".","_") for c in df2.columns]
    for c in df2.columns:
        if hasattr(df2[c].dtype,"numpy_dtype"): df2[c]=df2[c].astype(str(df2[c].dtype.numpy_dtype))
    disp = bq.WriteDisposition.WRITE_TRUNCATE if mode=="replace" else bq.WriteDisposition.WRITE_APPEND
    jc = bq.LoadJobConfig(write_disposition=disp, autodetect=True)
    try:
        client = bq.Client(project=pid)
        client.load_table_from_dataframe(df2, dest, job_config=jc).result()
        tbl = client.get_table(dest)
        _ok(f"Written: {tbl.num_rows:,} rows in {dest}")
        log.bq_output_uri = dest
        log.add(15,"BQ Write",f"Wrote to {dest}",f"rows={tbl.num_rows:,}")
        return dest
    except Exception as e: _warn(f"BQ write failed: {e}"); return ""

# =============================================================================
# DOCX REPORT
# =============================================================================
def _rgb(r,g,b): return RGBColor(r,g,b)
def _h(doc,txt,lv=1):
    p=doc.add_heading(txt,level=lv); p.alignment=WD_ALIGN_PARAGRAPH.LEFT; return p
def _row(tbl,cells,hdr=False):
    row=tbl.add_row()
    for i,(txt,w) in enumerate(cells):
        cell=row.cells[i]; cell.text=str(txt)
        if hdr:
            cell.paragraphs[0].runs[0].bold=True
            tc=cell._tc; pr=tc.get_or_add_tcPr()
            s=OxmlElement("w:shd"); s.set(qn("w:val"),"clear"); s.set(qn("w:color"),"auto")
            s.set(qn("w:fill"),"1F3864"); pr.append(s)
            cell.paragraphs[0].runs[0].font.color.rgb=RGBColor(255,255,255)
        cell.paragraphs[0].paragraph_format.space_before=Pt(2)
        cell.paragraphs[0].paragraph_format.space_after=Pt(2)
def _img(doc,path,w=Inches(5.8)):
    try: doc.add_picture(path,width=w)
    except Exception as e: doc.add_paragraph(f"[Chart unavailable: {e}]")

def _report(orig_shape, df: pd.DataFrame, log: Log) -> str:
    _banner("Generating Word Report")
    doc = Document()
    for sec in doc.sections:
        sec.page_width=Emu(12240*914); sec.page_height=Emu(15840*914)
        sec.left_margin=sec.right_margin=sec.top_margin=sec.bottom_margin=Inches(1)
    # Title
    p=doc.add_paragraph(); p.alignment=WD_ALIGN_PARAGRAPH.CENTER
    r=p.add_run("ML Data Cleaning & Preprocessing Report")
    r.bold=True; r.font.size=Pt(22); r.font.color.rgb=_rgb(31,56,100)
    doc.add_paragraph()
    sub=doc.add_paragraph(); sub.alignment=WD_ALIGN_PARAGRAPH.CENTER
    sub.add_run(f"Source: {log.project}.{log.dataset}.{log.table}\n"
                f"Target: {log.target}  |  Model: {log.model_type}\n"
                f"Generated: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}").font.size=Pt(11)
    doc.add_page_break()
    # 1. Summary
    _h(doc,"1. Executive Summary")
    or_,oc_=orig_shape; fr_,fc_=df.shape
    doc.add_paragraph(
        f"Pipeline applied to {log.project}.{log.dataset}.{log.table}. "
        f"Original: {or_:,} rows × {oc_} cols. Final: {fr_:,} rows × {fc_} cols. "
        f"Dropped: {len(log.dropped_cols)} cols. Imputed: {len(log.imputed_cols)} cols. "
        f"Target: '{log.target}'. Identifiers: {log.identifier_cols or 'none'}.")
    tbl=doc.add_table(rows=1,cols=2); tbl.style="Table Grid"
    _row(tbl,[("Metric",4000),("Value",4000)],hdr=True)
    for k,v in [("Source",f"{log.project}.{log.dataset}.{log.table}"),
                ("Target",log.target),("Model type",log.model_type),
                ("Identifiers",str(log.identifier_cols)),
                ("Orig shape",f"{or_:,}×{oc_}"),("Final shape",f"{fr_:,}×{fc_}"),
                ("Dropped cols",str(len(log.dropped_cols))),
                ("Imputed cols",str(len(log.imputed_cols))),
                ("Encoding",str(log.encoding_done or "None")),
                ("Normalisation",log.normalization or "None"),
                ("BQ output",log.bq_output_uri or "Not written")]:
        _row(tbl,[(k,4000),(v,4000)])
    doc.add_paragraph()
    # 2. Data Source
    _h(doc,"2. Data Source")
    doc.add_paragraph(f"Loaded from BigQuery: {log.project}.{log.dataset}.{log.table}")
    if log.bq_query_notes:
        _h(doc,"Query Configuration",2)
        for note in log.bq_query_notes:
            doc.add_paragraph(note, style="List Bullet")
        doc.add_paragraph()
    if log.bq_query:
        _h(doc,"Executed Query",2)
        p=doc.add_paragraph(); r2=p.add_run(log.bq_query)
        r2.font.name="Courier New"; r2.font.size=Pt(9); r2.font.color.rgb=_rgb(30,60,114)
        p.paragraph_format.left_indent=Inches(0.4)
        doc.add_paragraph()
    # 2a. Preview
    _h(doc,"2a. Column Profile",2)
    pi=log.preview_info
    if pi:
        doc.add_paragraph(f"Rows: {pi.get('rows',0):,} | Cols: {pi.get('cols',0)} | "
                          f"Nulls: {pi.get('null_total',0):,} | Dups: {pi.get('duplicates',0):,} | "
                          f"Memory: {pi.get('memory_mb',0):.2f}MB")
        if pi.get("csv_gcs"): doc.add_paragraph(f"Profile CSV (GCS): {pi['csv_gcs']}")
        cols_info = pi.get("columns",[])
        if cols_info:
            tbl2=doc.add_table(rows=1,cols=6); tbl2.style="Table Grid"
            _row(tbl2,[("Column",2200),("DType",1200),("Null%",900),("Unique",900),
                       ("Target Fit",1800),("Rec",1400)],hdr=True)
            for c in cols_info:
                _row(tbl2,[(c["name"],2200),(c["dtype"],1200),(f"{c['null_pct']:.1f}%",900),
                            (f"{c['unique']:,}",900),(c.get("target_fit",""),1800),(c.get("drop_rec",""),1400)])
            doc.add_paragraph()
    # 2b. Target
    _h(doc,"2b. Target Selection",2)
    doc.add_paragraph(f"'{log.target}' selected as target. Protected from all processing.")
    # 2c. Identifiers
    _h(doc,"2c. Identifier Columns",2)
    if log.identifier_cols:
        doc.add_paragraph(f"Columns excluded from processing and re-joined at end: {log.identifier_cols}")
    else:
        doc.add_paragraph("No identifier columns designated.")
    # 3. Processing Steps
    _h(doc,"3. Processing Steps")
    for s in log.steps:
        _h(doc,f"{s['step']}. {s['title']}",2)
        doc.add_paragraph(s["reason"])
        if s["detail"]:
            p=doc.add_paragraph(); p.add_run("Details: ").bold=True; p.add_run(s["detail"])
    # Dropped
    if log.dropped_cols:
        _h(doc,"Dropped Columns",2)
        for c in log.dropped_cols: doc.add_paragraph(c,style="List Bullet")
    # Imputed
    if log.imputed_cols:
        _h(doc,"Imputation Summary",2)
        tbl3=doc.add_table(rows=1,cols=3); tbl3.style="Table Grid"
        _row(tbl3,[("Column",3500),("Type",2000),("Strategy",2000)],hdr=True)
        for it in log.imputed_cols: _row(tbl3,[(it["col"],3500),(it["type"],2000),(it["strategy"],2000)])
        doc.add_paragraph()
    # 4. EDA
    _h(doc,"4. Exploratory Data Analysis")
    titles=["Target Distribution","Numeric Distributions","Boxplots by Target",
            "Categorical Distributions","Correlation Heatmap"]
    for i,path in enumerate(log.eda_charts):
        if not Path(path).exists(): continue
        _h(doc,titles[i] if i<len(titles) else f"Chart {i+1}",2)
        _img(doc,path); doc.add_paragraph()
    # 5. Correlation
    _h(doc,"5. Correlation Analysis")
    doc.add_paragraph("Pearson correlation computed. Low-signal and multicollinear features removed.")
    if log.corr_chart and Path(log.corr_chart).exists():
        _img(doc,log.corr_chart); doc.add_paragraph()
    # 6-7. Encoding & Normalisation
    _h(doc,"6. Encoding & Normalisation")
    doc.add_paragraph(f"Encoding: {log.encoding_done or 'None'}. "
                      f"Normalisation: {log.normalization or 'None'}. "
                      "Normalisation was applied to ALL numeric columns including encoded categoricals.")
    # 8. Class Labels
    if log.model_type=="classification" and log.class_labels:
        _h(doc,"7. Class Label Mapping")
        tbl4=doc.add_table(rows=1,cols=2); tbl4.style="Table Grid"
        _row(tbl4,[("Class Value",4000),("Label",4000)],hdr=True)
        for v,lbl in log.class_labels.items(): _row(tbl4,[(v,4000),(lbl,4000)])
        doc.add_paragraph()
    # 8. Final
    _h(doc,"8. Final Dataset")
    doc.add_paragraph(f"Final shape: {df.shape[0]:,} rows × {df.shape[1]} cols.")
    if log.output_csv: doc.add_paragraph(f"Output CSV: {log.output_csv}")
    if log.bq_output_uri: doc.add_paragraph(f"BigQuery table: {log.bq_output_uri}")
    # 9. GCS
    if log.gcs_bucket:
        _h(doc,"9. GCS Output")
        doc.add_paragraph(f"Run folder: gs://{log.gcs_bucket}/{log.gcs_run}/")
        if log.gcs_uploads:
            tbl5=doc.add_table(rows=1,cols=2); tbl5.style="Table Grid"
            _row(tbl5,[("File",3500),("GCS URI",5500)],hdr=True)
            for it in log.gcs_uploads: _row(tbl5,[(Path(it["local"]).name,3500),(it["gcs_uri"],5500)])
            doc.add_paragraph()
    # Save
    out=str(STAGING/"ML_Preprocessing_Report.docx")
    doc.save(out); _ok(f"Report staged: {out}"); return out

# =============================================================================
# SAVE ALL OUTPUTS  (GCS or local)
# =============================================================================
def _save_outputs(all_files: list[str], log: Log) -> None:
    if log.gcs_bucket:
        _banner("Uploading Outputs → GCS")
        col_w=52
        print(f"  {'File':<{col_w}} Status")
        print("  "+"─"*(col_w+30))
        for f_path in all_files:
            if not Path(f_path).exists(): continue
            fname = Path(f_path).name
            if fname.endswith(".docx"):   blob = f"{log.gcs_run}/report/{fname}"
            elif fname.endswith(".csv") and "profile" in fname: blob = f"{log.gcs_run}/profile/{fname}"
            elif fname.endswith(".csv"):  blob = f"{log.gcs_run}/output/{fname}"
            else:                         blob = f"{log.gcs_run}/charts/{fname}"
            uri = _gcs_put(f_path, blob, log.gcs_bucket)
            if uri:
                log.gcs_uploads.append({"local":f_path,"gcs_uri":uri})
                print(f"  {fname:<{col_w}} {G}✔ {uri}{X}")
            else:
                print(f"  {fname:<{col_w}} {R}✘ FAILED{X}")
    else:
        _banner("Saving Outputs Locally")
        ts = datetime.now().strftime("%Y-%m-%d_%H-%M-%S")
        out_dir = Path(f"./ml_pipeline_output/{ts}")
        for sub in ("report","output","charts","profile"):
            (out_dir/sub).mkdir(parents=True, exist_ok=True)
        for f_path in all_files:
            if not Path(f_path).exists(): continue
            fname = Path(f_path).name
            if fname.endswith(".docx"):   dest = out_dir/"report"/fname
            elif fname.endswith(".csv") and "profile" in fname: dest = out_dir/"profile"/fname
            elif fname.endswith(".csv"):  dest = out_dir/"output"/fname
            else:                         dest = out_dir/"charts"/fname
            shutil.copy2(f_path, dest)
            _ok(f"Saved: {dest}")

# =============================================================================
# MAIN PIPELINE
# =============================================================================
def run_pipeline():
    print(f"\n{B}{C}"
          "╔══════════════════════════════════════════════════════════════╗\n"
          "║    ML DATA CLEANING & PREPROCESSING TOOL                     ║\n"
          f"╚══════════════════════════════════════════════════════════════╝{X}")
    log = Log()

    # ── Environment summary ───────────────────────────────────────────────────
    ENV.print_summary()
    env_mode = ENV.resolve()

    # ── Data source selection ─────────────────────────────────────────────────
    # Priority: config pipeline.data_source → env-aware default → interactive
    src = CFG.s("pipeline","data_source")

    if src == "demo":
        _ok("Data source (config): demo synthetic dataset")
        df = _load_demo()
        log.project="demo"; log.dataset="demo_dataset"; log.table="demo_table"
        log.bq_query="-- demo mode"; log.bq_query_notes=["Mode: Demo"]
        bq_client = None

    elif src == "csv" or src == "local":
        _ok("Data source (config): local CSV")
        df = _load_local_csv(log)
        bq_client = None

    elif src == "bigquery":
        if env_mode == "local":
            _warn("data_source=bigquery but running in LOCAL mode (GCP libs missing).")
            _warn("Falling back to local CSV — set local.csv_path in config.")
            df = _load_local_csv(log); bq_client = None
        else:
            _ok("Data source (config): bigquery")
            df, bq_client = _load_bq(log)

    else:
        # No config — offer choices based on what's available
        if env_mode == "local":
            opts = ["csv — local CSV file", "demo — built-in synthetic dataset"]
        else:
            opts = ["bigquery — GCP BigQuery table",
                    "csv — local CSV file",
                    "demo — built-in synthetic dataset"]
        choice = _c_choice("Data source", opts, "1")

        if "bigquery" in choice:
            df, bq_client = _load_bq(log)
        elif "csv" in choice:
            df = _load_local_csv(log); bq_client = None
        else:
            df = _load_demo()
            log.project="demo"; log.dataset="demo_dataset"; log.table="demo_table"
            log.bq_query="-- demo mode"; log.bq_query_notes=["Mode: Demo"]
            bq_client = None

    orig_shape = df.shape

    # ── GCS config — set up BEFORE preview so profile can be uploaded ─────────
    if env_mode == "local":
        _ok("Local mode — GCS disabled. All outputs saved locally.")
        log.gcs_bucket = ""; log.gcs_base = ""; log.gcs_run = ""
    else:
        gcs_on = CFG.b("pipeline","save_to_gcs", default=None)
        if gcs_on is True:
            _configure_gcs(log)
        elif gcs_on is False:
            _ok("GCS disabled (config).")
        else:
            if _confirm("Save to GCS?", True):
                _configure_gcs(log)

    # ─────────────────────────────────────────────────────────────────────────
    # STEP 2: Build full column profile from ALL data and upload to GCS NOW.
    #         Pipeline pauses here — user reviews the GCS CSV in Sheets/BQ
    #         Studio and comes back to type the target column name.
    # ─────────────────────────────────────────────────────────────────────────
    _preview(df, log)                                         # STEP 2 → uploads to GCS

    # ─────────────────────────────────────────────────────────────────────────
    # STEP 3: Ask for target column AFTER user has had a chance to review CSV.
    # ─────────────────────────────────────────────────────────────────────────
    target = _select_target(df, log)                          # STEP 3

    # ─────────────────────────────────────────────────────────────────────────
    # STEP 3a: Model type + target encoding.
    #   • Ask classification or regression (config or interactive).
    #   • If classification: show unique target values → user maps each to
    #     a numeric code (0, 1, 2, …).
    #   • The encoded target replaces the raw column RIGHT NOW, before any
    #     preprocessing, so it is preserved through every subsequent step.
    # ─────────────────────────────────────────────────────────────────────────
    _banner("STEP 3a · Model Type")
    n_uniq_tgt = df[target].nunique(dropna=True)
    sugg_mt    = "classification" if n_uniq_tgt <= 20 else "regression"
    mt_cfg     = CFG.s("pipeline","model_type")
    if mt_cfg in ("classification","regression"):
        model_type = mt_cfg;  _ok(f"Model type (config): {model_type}")
    elif CFG.auto:
        model_type = sugg_mt; _ok(f"Model type (auto): {model_type}")
    else:
        r          = _menu("Model type?",["Classification","Regression"],"1")
        model_type = "classification" if "class" in r else "regression"
    log.model_type = model_type

    df, _ = _encode_target(df, target, model_type, log)       # STEP 3a

    # ─────────────────────────────────────────────────────────────────────────
    # STEP 3b: Stratified reload from BQ (if sampling_limit configured).
    #   Now that target is encoded to numeric we can do stratified sampling.
    # ─────────────────────────────────────────────────────────────────────────
    if bq_client and CFG.i("bigquery","sampling_limit"):
        df = _stratified_reload(df, target, log, bq_client)   # STEP 3b

    # ─────────────────────────────────────────────────────────────────────────
    # STEP 3c → 12: All preprocessing — target is NEVER touched after this.
    # ─────────────────────────────────────────────────────────────────────────
    df, df_id = _select_identifiers(df, target, log)          # STEP 3c
    df        = _keyword_drop(df, target, log)                # STEP 4
    df        = _high_null_drop(df, target, log)              # STEP 5
    df        = _clean(df, target, log)                       # STEP 6
    _eda(df, target, log)                                     # STEP 7
    df        = _corr_filter(df, target, log)                 # STEP 8
    df        = _encode(df, target, log)                      # STEP 9
    df        = _normalise(df, target, log)                   # STEP 10
    mt        = _model_type(df, target, log)                  # STEP 11 (no re-ask)

    log.final_shape = df.shape

    # ── Final summary ─────────────────────────────────────────────────────────
    _banner("Pipeline Complete")
    print(f"  Original   : {orig_shape[0]:,} × {orig_shape[1]}")
    print(f"  Final      : {df.shape[0]:,} × {df.shape[1]}")
    print(f"  Model type : {log.model_type}")
    print(f"  Target enc.: {log.class_labels or 'N/A (regression)'}")
    print(f"  Identifiers: {log.identifier_cols or 'none'}")
    print(f"  Dropped    : {len(log.dropped_cols)} cols")
    print(f"  Imputed    : {len(log.imputed_cols)} cols")
    print(f"  Encoding   : {log.encoding_done or 'None'}")
    print(f"  Scaling    : {log.normalization or 'None'}")

    # ─────────────────────────────────────────────────────────────────────────
    # STEP 12: Build output CSV  (identifiers + features + target + class_label + prediction)
    # ─────────────────────────────────────────────────────────────────────────
    out_csv = _build_output(df, df_id, target, log)           # STEP 12

    # ─────────────────────────────────────────────────────────────────────────
    # Generate Word report
    # ─────────────────────────────────────────────────────────────────────────
    report = _report(orig_shape, df, log)

    # ─────────────────────────────────────────────────────────────────────────
    # Save all outputs → GCS (primary) or local folder (fallback)
    # Files saved:
    #   output/   processed_output.csv
    #   report/   ML_Preprocessing_Report.docx
    #   charts/   *.png
    #   profile/  column_profile.csv
    # ─────────────────────────────────────────────────────────────────────────
    all_files = (
        [report, out_csv]
        + log.eda_charts
        + ([log.corr_chart] if log.corr_chart else [])
        + ([log.preview_csv] if log.preview_csv else [])
    )
    _save_outputs(all_files, log)

    # Re-generate report now GCS URIs are populated, then re-upload
    if log.gcs_bucket:
        report = _report(orig_shape, df, log)
        uri    = _gcs_put(report,
                          f"{log.gcs_run}/report/{Path(report).name}",
                          log.gcs_bucket)
        if uri:
            _ok(f"Final report (with GCS manifest) uploaded: {uri}")

    # ─────────────────────────────────────────────────────────────────────────
    # STEP 13: Write processed table back to BigQuery.
    # Output project / dataset / table can differ from the source.
    # ─────────────────────────────────────────────────────────────────────────
    df_bq = pd.read_csv(out_csv)
    _bq_write(df_bq, log)

    _banner("All Done!")
    if log.gcs_bucket:
        _ok(f"GCS run folder : gs://{log.gcs_bucket}/{log.gcs_run}/")
        _ok(f"  ├─ profile/  column_profile.csv  ← reviewed before target selection")
        _ok(f"  ├─ output/   processed_output.csv")
        _ok(f"  ├─ report/   ML_Preprocessing_Report.docx")
        _ok(f"  └─ charts/   *.png")
    if log.bq_output_uri:
        _ok(f"BigQuery output: {log.bq_output_uri}")

    return df, df_id, report

# =============================================================================
# ENTRY POINT
# =============================================================================
if __name__ == "__main__":
    ap = argparse.ArgumentParser(
        description="ML Data Cleaning & Preprocessing Pipeline  (GCP + Local)"
    )
    ap.add_argument("--config","-c", default="",
                    help="Path to pipeline_config.yaml")
    args = ap.parse_args()

    # Load config into the global CFG singleton BEFORE anything else runs.
    CFG.load(args.config)

    _banner("Configuration Summary")
    CFG.print_summary()

    # Show environment summary after config is loaded
    # (ENV.resolve() now reads pipeline.environment from config)
    ENV.print_summary()

    df_clean, df_ids, report = run_pipeline()
