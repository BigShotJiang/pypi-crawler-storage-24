from setuptools import setup, find_packages

setup(
    name="asciicam",
    version="1.0.0",
    packages=find_packages(),
    install_requires=[
        "opencv-python-headless", # Often better for non-GUI environments, but we use curses
        "numpy",
        "Pillow",
    ],
    entry_points={
        "console_scripts": [
            "asciicam=asciicam.main:main",
        ],
    },
    author="Yaduraj Singh",
    author_email="yaduraj@example.com", # Added placeholder
    description="Real-time ASCII Camera in the terminal",
    long_description=open("README.md").read(),
    long_description_content_type="text/markdown",
    url="https://github.com/YaduEnc/AsciiCam",
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
        "Topic :: Multimedia :: Video :: Display",
        "Environment :: Console :: Curses",
    ],
    python_requires='>=3.7',
)
