"""
Real-Time ASCII Camera - Edge Mapper
Calculates gradients and maps them to directional ASCII characters (|, /, -, \).
"""

import cv2
import numpy as np
from typing import List

class EdgeMapper:
    """Maps grayscale pixel gradients to directional ASCII characters"""
    
    def __init__(self):
        # Character set for directions
        # Horizontal, Vertical, Diag1 (\), Diag2 (/)
        # We use a space (' ') for no edge (flat area)
        self.edge_chars = {
            'H': '-',
            'V': '|',
            'D1': '\\',
            'D2': '/',
            'NONE': ' '
        }
    
    def map_edges(self, gray: np.ndarray, threshold: int = 50) -> List[str]:
        """
        Detect edge directions and map them to characters.
        """
        # 1. Calculate gradients in x and y
        grad_x = cv2.Sobel(gray, cv2.CV_32F, 1, 0, ksize=3)
        grad_y = cv2.Sobel(gray, cv2.CV_32F, 0, 1, ksize=3)
        
        # 2. Calculate magnitude and angle
        magnitude = np.sqrt(grad_x**2 + grad_y**2)
        angle = np.arctan2(grad_y, grad_x) * 180 / np.pi
        
        # Normalize angle to [0, 180)
        angle[angle < 0] += 180
        
        # 3. Create character frame
        h, w = gray.shape
        char_frame = np.full((h, w), ' ', dtype=object)
        
        # Condition for an edge to exist
        is_edge = magnitude > threshold
        
        # Map angles to directions
        # Vertical: ~90 degrees (70-110)
        is_V = is_edge & ((angle >= 67.5) & (angle < 112.5))
        # Horizontal: ~0/180 degrees (0-22.5 or 157.5-180)
        is_H = is_edge & ((angle < 22.5) | (angle >= 157.5))
        # Diagonal 1 (\): ~135 degrees (112.5-157.5)
        is_D1 = is_edge & ((angle >= 112.5) & (angle < 157.5))
        # Diagonal 2 (/): ~45 degrees (22.5-67.5)
        is_D2 = is_edge & ((angle >= 22.5) & (angle < 67.5))
        
        # Assign characters
        char_frame[is_V] = self.edge_chars['V']
        char_frame[is_H] = self.edge_chars['H']
        char_frame[is_D1] = self.edge_chars['D1']
        char_frame[is_D2] = self.edge_chars['D2']
        
        return [''.join(row) for row in char_frame]
