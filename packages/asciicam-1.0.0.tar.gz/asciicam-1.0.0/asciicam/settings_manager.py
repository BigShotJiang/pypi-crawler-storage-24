"""
Real-Time ASCII Camera - Settings Manager
Handles saving and loading of user preferences.
"""

import json
import os
from . import config

SETTINGS_FILE = "user_settings.json"

def load_settings():
    """Load settings from JSON file and apply to config"""
    if not os.path.exists(SETTINGS_FILE):
        return

    try:
        with open(SETTINGS_FILE, "r") as f:
            settings = json.load(f)
        
        # Apply settings to config
        for key, value in settings.items():
            if hasattr(config, key):
                setattr(config, key, value)
                
    except Exception as e:
        print(f"Error loading settings: {e}")

def save_settings():
    """Save current configuration to JSON file"""
    settings = {
        "DEFAULT_ZOOM": getattr(config, "DEFAULT_ZOOM", 1.0),
        "DEFAULT_RAMP": getattr(config, "DEFAULT_RAMP", config.RAMP_ALPHA),
        "ENABLE_MIRROR": getattr(config, "ENABLE_MIRROR", True),
        "ENABLE_INVERT": getattr(config, "ENABLE_INVERT", False),
        "ENABLE_GLITCH": getattr(config, "ENABLE_GLITCH", False),
        "ENABLE_EDGE_MAPPING": getattr(config, "ENABLE_EDGE_MAPPING", False),
        "CONTRAST_BOOST": getattr(config, "CONTRAST_BOOST", 1.1),
        "BRIGHTNESS_BOOST": getattr(config, "BRIGHTNESS_BOOST", 10),
    }

    try:
        with open(SETTINGS_FILE, "w") as f:
            json.dump(settings, f, indent=4)
    except Exception as e:
        print(f"Error saving settings: {e}")

def update_setting(key, value):
    """Update a specific setting in config and save to file"""
    if hasattr(config, key):
        setattr(config, key, value)
        save_settings()
