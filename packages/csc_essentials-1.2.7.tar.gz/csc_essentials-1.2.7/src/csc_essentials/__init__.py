"""csc_essentials package exports.

Este módulo agrega exports de utilitários presentes em `csc_essentials` para
facilitar importações do pacote (ex.: `from csc_essentials import ajusta_nome_coluna`).
"""

from .utils import ajusta_nome_coluna, converter_valor
from .database import (
    inserir_banco_dados,
    atualiza_tabela,
    executar_com_fallback,
    atualiza_tabelas_silvers,
    obter_schema_map,
)
from .logging import GeradorLog, AlertaSlack
from .core import parar_vm
from .oracle import (
    conexao_ftp_oracle,
    baixar_arquivo_em_blocos,
    detectar_separador,
    envia_outbound,
    salvar_csv_gzip,
    upload_para_gcs,
    carregar_csv_no_bigquery,
    deleta_arquivos_outbound,
    ler_arquivos_bucket,
)

__all__ = [
    "ajusta_nome_coluna",
    "obter_schema_map",
    "converter_valor",
    "inserir_banco_dados",
    "atualiza_tabela",
    "executar_com_fallback",
    "atualiza_tabelas_silvers",
    "parar_vm",
    "GeradorLog",
    "AlertaSlack",
    "conexao_ftp_oracle",
    "baixar_arquivo_em_blocos",
    "detectar_separador",
    "envia_outbound",
    "salvar_csv_gzip",
    "upload_para_gcs",
    "carregar_csv_no_bigquery",
    "deleta_arquivos_outbound",
    "ler_arquivos_bucket",
]

