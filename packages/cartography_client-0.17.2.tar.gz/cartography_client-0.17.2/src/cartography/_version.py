# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

__title__ = "cartography"
__version__ = "0.17.2"  # x-release-please-version
