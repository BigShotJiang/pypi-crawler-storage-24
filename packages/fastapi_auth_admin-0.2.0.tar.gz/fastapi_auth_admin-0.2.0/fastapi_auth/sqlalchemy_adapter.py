from dataclasses import dataclass

from sqlalchemy import event, select
from sqlalchemy.ext.asyncio import AsyncSession, async_sessionmaker, create_async_engine
from sqlalchemy.orm import DeclarativeBase, Mapped, mapped_column

from .models import User
from .security import hash_password

ADMIN_EMAIL = "admin@admin.com"
ADMIN_INITIAL_PASSWORD = "changeme"

# ── ORM model ───────────────────────────────────────────────────────


class Base(DeclarativeBase):
    pass


class UserModel(Base):
    __tablename__ = "users"

    email: Mapped[str] = mapped_column(primary_key=True)
    hashed_password: Mapped[str]
    is_admin: Mapped[bool] = mapped_column(default=False)
    approved: Mapped[bool] = mapped_column(default=False)


# ── Engine / session setup ──────────────────────────────────────────

_engine = None
_SessionLocal = None


async def init_db(url: str = "sqlite+aiosqlite:///./users.db") -> None:
    global _engine, _SessionLocal

    _engine = create_async_engine(url)

    @event.listens_for(_engine.sync_engine, "connect")
    def set_sqlite_pragma(dbapi_connection, connection_record):
        cursor = dbapi_connection.cursor()
        cursor.execute("PRAGMA journal_mode=WAL")
        cursor.execute("PRAGMA foreign_keys=ON")
        cursor.close()

    _SessionLocal = async_sessionmaker(_engine, autocommit=False, autoflush=False)

    async with _engine.begin() as conn:
        await conn.run_sync(Base.metadata.create_all)

    # Seed admin user
    async with _SessionLocal() as session:
        if await session.get(UserModel, ADMIN_EMAIL) is None:
            session.add(UserModel(
                email=ADMIN_EMAIL,
                hashed_password=hash_password(ADMIN_INITIAL_PASSWORD),
                is_admin=True,
                approved=True,
            ))
            await session.commit()


# ── Adapter ─────────────────────────────────────────────────────────


@dataclass
class SqlAlchemyUserRepository:
    conn: AsyncSession

    async def find_by_email(self, email: str) -> User | None:
        row = await self.conn.get(UserModel, email)
        if row is None:
            return None
        return User(
            email=row.email,
            hashed_password=row.hashed_password,
            is_admin=row.is_admin,
            approved=row.approved,
        )

    async def create(self, user: User) -> None:
        self.conn.add(UserModel(
            email=user.email,
            hashed_password=user.hashed_password,
            is_admin=user.is_admin,
            approved=user.approved,
        ))
        await self.conn.commit()

    async def update(self, user: User) -> None:
        row = await self.conn.get(UserModel, user.email)
        if row is None:
            return
        row.hashed_password = user.hashed_password
        row.is_admin = user.is_admin
        row.approved = user.approved
        await self.conn.commit()

    async def list_pending(self) -> list[User]:
        result = await self.conn.execute(
            select(UserModel)
            .where(UserModel.approved == False, UserModel.is_admin == False)  # noqa: E712
        )
        rows = result.scalars().all()
        return [
            User(
                email=r.email,
                hashed_password=r.hashed_password,
                is_admin=r.is_admin,
                approved=r.approved,
            )
            for r in rows
        ]

    async def ensure_admin(self, email: str, hashed_password: str) -> None:
        if await self.conn.get(UserModel, email) is not None:
            return
        self.conn.add(UserModel(
            email=email,
            hashed_password=hashed_password,
            is_admin=True,
            approved=True,
        ))
        await self.conn.commit()


# ── FastAPI dependency ──────────────────────────────────────────────


async def get_user_repo():
    if _SessionLocal is None:
        raise RuntimeError("User DB not initialized. Call init_db() first.")
    async with _SessionLocal() as session:
        yield SqlAlchemyUserRepository(conn=session)
