from .errors import (
    InvalidCredentials,
    NotAuthorized,
    UserAlreadyExists,
    UserNotApproved,
    UserNotFound,
)
from .models import TokenPayload, User
from .ports import UserRepositoryPort
from .security import create_access_token, hash_password, verify_password


async def register(email: str, password: str, repo: UserRepositoryPort) -> User:
    if await repo.find_by_email(email) is not None:
        raise UserAlreadyExists(email)
    user = User(email=email, hashed_password=hash_password(password))
    await repo.create(user)
    return user


async def login(
    email: str,
    password: str,
    repo: UserRepositoryPort,
    extra_claims: dict | None = None,
) -> str:
    user = await repo.find_by_email(email)
    if user is None or not verify_password(password, user.hashed_password):
        raise InvalidCredentials()
    if not user.approved:
        raise UserNotApproved(email)
    payload = TokenPayload(
        sub=user.email,
        extra={"is_admin": user.is_admin, **(extra_claims or {})},
    )
    return create_access_token(payload)


async def approve_user(
    email: str, caller: TokenPayload, repo: UserRepositoryPort
) -> User:
    if not caller.extra.get("is_admin"):
        raise NotAuthorized()
    user = await repo.find_by_email(email)
    if user is None:
        raise UserNotFound(email)
    user.approved = True
    await repo.update(user)
    return user


async def reject_user(
    email: str, caller: TokenPayload, repo: UserRepositoryPort
) -> None:
    if not caller.extra.get("is_admin"):
        raise NotAuthorized()
    user = await repo.find_by_email(email)
    if user is None:
        raise UserNotFound(email)
    user.approved = False
    await repo.update(user)


async def list_pending_users(
    caller: TokenPayload, repo: UserRepositoryPort
) -> list[User]:
    if not caller.extra.get("is_admin"):
        raise NotAuthorized()
    return await repo.list_pending()


async def change_password(
    email: str,
    current_password: str,
    new_password: str,
    caller: TokenPayload,
    repo: UserRepositoryPort,
) -> None:
    if caller.sub != email:
        raise NotAuthorized()
    user = await repo.find_by_email(email)
    if user is None or not verify_password(current_password, user.hashed_password):
        raise InvalidCredentials()
    user.hashed_password = hash_password(new_password)
    await repo.update(user)
