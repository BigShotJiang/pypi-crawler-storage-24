import pytest
from fastapi import FastAPI
from httpx import ASGITransport, AsyncClient

from fastapi_auth import auth_router, configure_security, set_get_user_repo
from fastapi_auth.sqlalchemy_adapter import get_user_repo, init_db

ADMIN_EMAIL = "admin@admin.com"
ADMIN_PASSWORD = "changeme"


@pytest.fixture
async def app():
    configure_security(secret_key="test-secret-key-that-is-long-enough-for-hs256")
    await init_db("sqlite+aiosqlite:///:memory:")
    set_get_user_repo(get_user_repo)
    fa = FastAPI()
    fa.include_router(auth_router)
    return fa


@pytest.fixture
async def client(app):
    async with AsyncClient(transport=ASGITransport(app=app), base_url="http://test") as ac:
        yield ac


@pytest.fixture
async def admin_token(client):
    resp = await client.post(
        "/auth/login",
        data={"username": ADMIN_EMAIL, "password": ADMIN_PASSWORD},
    )
    return resp.json()["access_token"]
