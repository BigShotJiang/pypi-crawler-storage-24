"""Integration tests for all /auth endpoints."""

import pytest

from tests.conftest import ADMIN_EMAIL, ADMIN_PASSWORD

USER_EMAIL = "user@example.com"
USER_PASSWORD = "password123"


# ── Helpers ──────────────────────────────────────────────────────────

async def register(client, email=USER_EMAIL, password=USER_PASSWORD):
    return await client.post("/auth/register", json={"email": email, "password": password})


async def approve(client, admin_token, email=USER_EMAIL):
    return await client.post(
        "/auth/approve",
        json={"email": email},
        headers={"Authorization": f"Bearer {admin_token}"},
    )


async def login(client, email=USER_EMAIL, password=USER_PASSWORD):
    return await client.post("/auth/login", data={"username": email, "password": password})


# ── Register ─────────────────────────────────────────────────────────

class TestRegister:
    async def test_success(self, client):
        resp = await register(client)
        assert resp.status_code == 200
        data = resp.json()
        assert data["email"] == USER_EMAIL
        assert data["approved"] is False

    async def test_duplicate_returns_409(self, client):
        await register(client)
        resp = await register(client)
        assert resp.status_code == 409

    async def test_invalid_email_returns_422(self, client):
        resp = await client.post(
            "/auth/register", json={"email": "not-an-email", "password": "x"}
        )
        assert resp.status_code == 422


# ── Login ─────────────────────────────────────────────────────────────

class TestLogin:
    async def test_admin_login_success(self, client):
        resp = await login(client, ADMIN_EMAIL, ADMIN_PASSWORD)
        assert resp.status_code == 200
        data = resp.json()
        assert "access_token" in data
        assert data["token_type"] == "bearer"

    async def test_unapproved_user_returns_403(self, client):
        await register(client)
        resp = await login(client)
        assert resp.status_code == 403

    async def test_wrong_password_returns_401(self, client):
        await register(client)
        resp = await login(client, password="wrong")
        assert resp.status_code == 401

    async def test_unknown_user_returns_401(self, client):
        resp = await login(client, email="ghost@example.com")
        assert resp.status_code == 401

    async def test_approved_user_can_login(self, client, admin_token):
        await register(client)
        await approve(client, admin_token)
        resp = await login(client)
        assert resp.status_code == 200
        assert "access_token" in resp.json()


# ── /me ───────────────────────────────────────────────────────────────

class TestMe:
    async def test_returns_email_and_claims(self, client, admin_token):
        resp = await client.get(
            "/auth/me", headers={"Authorization": f"Bearer {admin_token}"}
        )
        assert resp.status_code == 200
        data = resp.json()
        assert data["email"] == ADMIN_EMAIL
        assert data["is_admin"] is True

    async def test_unauthenticated_returns_401(self, client):
        resp = await client.get("/auth/me")
        assert resp.status_code == 401

    async def test_invalid_token_returns_401(self, client):
        resp = await client.get("/auth/me", headers={"Authorization": "Bearer bad.token"})
        assert resp.status_code == 401


# ── Change password ───────────────────────────────────────────────────

class TestChangePassword:
    async def test_success(self, client, admin_token):
        resp = await client.post(
            "/auth/change-password",
            json={"current_password": ADMIN_PASSWORD, "new_password": "newpass456"},
            headers={"Authorization": f"Bearer {admin_token}"},
        )
        assert resp.status_code == 200
        # New password works
        assert (await login(client, ADMIN_EMAIL, "newpass456")).status_code == 200

    async def test_wrong_current_password_returns_401(self, client, admin_token):
        resp = await client.post(
            "/auth/change-password",
            json={"current_password": "wrong", "new_password": "newpass456"},
            headers={"Authorization": f"Bearer {admin_token}"},
        )
        assert resp.status_code == 401

    async def test_unauthenticated_returns_401(self, client):
        resp = await client.post(
            "/auth/change-password",
            json={"current_password": ADMIN_PASSWORD, "new_password": "x"},
        )
        assert resp.status_code == 401


# ── Admin: pending / approve / reject ─────────────────────────────────

class TestAdmin:
    async def test_list_pending_shows_registered_users(self, client, admin_token):
        await register(client)
        resp = await client.get(
            "/auth/pending", headers={"Authorization": f"Bearer {admin_token}"}
        )
        assert resp.status_code == 200
        emails = [u["email"] for u in resp.json()]
        assert USER_EMAIL in emails

    async def test_list_pending_excludes_approved(self, client, admin_token):
        await register(client)
        await approve(client, admin_token)
        resp = await client.get(
            "/auth/pending", headers={"Authorization": f"Bearer {admin_token}"}
        )
        assert resp.status_code == 200
        emails = [u["email"] for u in resp.json()]
        assert USER_EMAIL not in emails

    async def test_list_pending_non_admin_returns_403(self, client, admin_token):
        await register(client)
        await approve(client, admin_token)
        user_token = (await login(client)).json()["access_token"]
        resp = await client.get(
            "/auth/pending", headers={"Authorization": f"Bearer {user_token}"}
        )
        assert resp.status_code == 403

    async def test_approve_success(self, client, admin_token):
        await register(client)
        resp = await approve(client, admin_token)
        assert resp.status_code == 200
        assert resp.json()["approved"] is True

    async def test_approve_nonexistent_returns_404(self, client, admin_token):
        resp = await approve(client, admin_token, email="ghost@example.com")
        assert resp.status_code == 404

    async def test_approve_non_admin_returns_403(self, client, admin_token):
        await register(client)
        await approve(client, admin_token)
        user_token = (await login(client)).json()["access_token"]
        resp = await client.post(
            "/auth/approve",
            json={"email": ADMIN_EMAIL},
            headers={"Authorization": f"Bearer {user_token}"},
        )
        assert resp.status_code == 403

    async def test_reject_success(self, client, admin_token):
        await register(client)
        resp = await client.post(
            "/auth/reject",
            json={"email": USER_EMAIL},
            headers={"Authorization": f"Bearer {admin_token}"},
        )
        assert resp.status_code == 200
        assert USER_EMAIL in resp.json()["detail"]

    async def test_reject_nonexistent_returns_404(self, client, admin_token):
        resp = await client.post(
            "/auth/reject",
            json={"email": "ghost@example.com"},
            headers={"Authorization": f"Bearer {admin_token}"},
        )
        assert resp.status_code == 404

    async def test_rejected_user_cannot_login(self, client, admin_token):
        await register(client)
        await approve(client, admin_token)
        await client.post(
            "/auth/reject",
            json={"email": USER_EMAIL},
            headers={"Authorization": f"Bearer {admin_token}"},
        )
        resp = await login(client)
        assert resp.status_code == 403
