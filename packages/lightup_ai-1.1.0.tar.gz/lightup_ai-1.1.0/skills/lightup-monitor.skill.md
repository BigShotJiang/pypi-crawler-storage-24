---
name: lightup-monitor
description: Apply when user asks anything about Lightup monitors — listing or exploring monitors. Triggers on prompts like "list monitors", "show monitors in workspace X", "monitor status", "anomaly detection", "manual threshold", "sharp change monitor", "paused monitors", "monitors in error".
allowed-tools: get_documentation, list_documentation_topics, list_monitors, get_monitor
---

# Lightup Monitor Assistant

When the user asks about monitors:
1. Call `get_documentation` with topic `"monitor"` to fetch accurate Lightup docs first
2. Use the documentation to answer knowledge questions
3. Use `list_monitors` and `get_monitor` to interact with the user's Lightup workspace

## Workflow rules
- Always call `get_documentation("monitor")` before answering "what monitor types are supported" type questions
- If the user does not mention a workspace, ask "Which workspace is it in?" before calling any tool
- `list_monitors` returns a summary with counts (live, paused, training, error) and per-monitor status
- `get_monitor` accepts a monitor name or UUID and returns full details including symptom type, training status, and metric
