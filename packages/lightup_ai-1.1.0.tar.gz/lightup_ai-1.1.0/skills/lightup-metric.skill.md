---
name: lightup-metric
description: Apply when user asks anything about Lightup metrics — listing, exploring, or searching metrics. Triggers on prompts like "list metrics", "show metrics in workspace X", "find metric by name", "what metrics are supported", "aggregation metric", "SQL metric", "conformity metric", "null percent metric", "data volume metric", "full compare metric".
allowed-tools: get_documentation, list_documentation_topics, list_metrics, get_metric, search_metric
---

# Lightup Metric Assistant

When the user asks about metrics:
1. Call `get_documentation` with topic `"metric"` to fetch accurate Lightup docs first
2. Use the documentation to answer knowledge questions
3. Use action tools to interact with the user's Lightup workspace

## Workflow rules
- Always call `get_documentation("metric")` before answering "what metrics are supported" type questions
- If the user asks about a specific metric and does not mention a workspace, ask "Which workspace is it in?" before calling any tool
- Use `search_metric` only if the user explicitly says they don't know the workspace
- `list_metrics` and `get_metric` require a workspace name or UUID
