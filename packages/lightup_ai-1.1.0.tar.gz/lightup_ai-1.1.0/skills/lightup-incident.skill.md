---
name: lightup-incident
description: Apply when user asks anything about Lightup incidents — listing or investigating incidents. Triggers on prompts like "show open incidents", "investigate this incident", "why did this alert fire", "get incident details", "incident status", "rejected incident", "unviewed incidents".
allowed-tools: get_documentation, list_documentation_topics, list_incidents, get_incident
---

# Lightup Incident Assistant

When the user asks about incidents:
1. Call `get_documentation` with topic `"incident"` to fetch accurate Lightup docs first
2. Use the documentation to answer knowledge questions
3. Use `list_incidents` and `get_incident` to interact with the user's Lightup workspace

## Incident statuses
- **Unviewed** — new, not yet reviewed
- **Viewed** — acknowledged
- **Rejected** — false positive
- **Submitted** — escalated
- **Closed** — resolved

## Incident direction
- **UP** — value spiked above expected
- **DOWN** — value dropped below expected
- **NEUTRAL** — anomaly without clear direction

## Workflow rules
- Always call `get_documentation("incident")` before answering knowledge questions
- If the user does not mention a workspace, ask "Which workspace is it in?" before calling any tool
- `list_incidents` returns recent incidents with monitor name, metric, status, direction, and timestamps
- `get_incident` returns full details for a specific incident UUID including datasource and reason
