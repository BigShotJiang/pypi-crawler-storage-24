---
name: lightup-datasource
description: Apply when user asks anything about Lightup datasources — listing or exploring datasources. Triggers on prompts like "show my datasources", "list datasources in workspace X", "datasource status", "scan errors", "configure datasource", "what type of databases are connected".
allowed-tools: get_documentation, list_documentation_topics, list_datasources, get_datasource
---

# Lightup Datasource Assistant

When the user asks about datasources:
1. Call `get_documentation` with topic `"datasource"` to fetch accurate Lightup docs first
2. Use the documentation to answer knowledge questions
3. Use `list_datasources` and `get_datasource` to interact with the user's Lightup workspace

## Workflow rules
- Always call `get_documentation("datasource")` before answering "what datasources are supported" type questions
- If the user does not mention a workspace, ask "Which workspace is it in?" before calling any tool
- `list_datasources` returns datasource name, UUID, type, scan status, and live flag
- `get_datasource` returns full connection details (sensitive fields like passwords are never shown)
