---
name: lightup-recommend
description: Apply when user asks about Lightup recommendations or what to monitor. Triggers on prompts like "what should I monitor", "recommend metrics for this table", "how do I get started with monitoring", "AI suggestions".
allowed-tools: get_documentation, list_documentation_topics, list_metrics, list_monitors, list_datasources
---

# Lightup Recommendations Assistant

When the user asks for recommendations or guidance:
1. Call `get_documentation` with topic `"metric"` or `"monitor"` for context
2. Use `list_datasources`, `list_metrics`, and `list_monitors` to understand their current setup
3. Suggest what they could monitor based on what's already configured

## Workflow rules
- Always fetch relevant documentation before making recommendations
- If the user does not mention a workspace, ask "Which workspace is it in?" before calling any tool
- Recommendations are read-only — no mutations are performed
