# lightup-ai

AI assistant for [Lightup](https://lightup.ai) data quality — ask questions about your metrics, monitors, datasources, and incidents in plain English.

Connects your Lightup instance to an AI assistant (Claude, OpenAI, or Gemini) via the [Model Context Protocol (MCP)](https://modelcontextprotocol.io). Also works as an MCP server for Claude Desktop and Claude Code.

---

## Requirements

- Python 3.11+
- A Lightup account with a refresh token
- An API key for Claude, OpenAI, or Gemini

---

## Installation

```bash
pip install lightup-ai
```

---

## Quick start

```bash
lightup-ai start
```

This runs a guided setup wizard that:
1. Connects to your Lightup instance
2. Configures your AI provider (Claude / OpenAI / Gemini)
3. Starts the MCP server
4. Opens an interactive chat session

On the first run you will be prompted for:
- Your `lightup-api-credential.json` file path (or host + refresh token manually)
- Your AI provider and API key

Config is saved to `~/.lightup-ai/config.json` and reused on subsequent runs.

### Verbose mode

```bash
lightup-ai start -v
```

Shows API calls, tool invocations, and server logs as they happen.

---

## Using with Claude Desktop

After running `lightup-ai start`, the setup wizard auto-configures Claude Desktop. Restart Claude Desktop to apply.

To configure manually, add to `~/Library/Application Support/Claude/claude_desktop_config.json`:

```json
{
  "mcpServers": {
    "lightup-ai": {
      "command": "lightup-ai",
      "args": ["serve", "--stdio"]
    }
  }
}
```

---

## Using with Claude Code

After setup, Claude Code is auto-configured. To add manually:

```bash
claude mcp add --transport sse lightup-ai http://localhost:8765/sse
```

---

## What you can ask

- "List my workspaces"
- "Create a workspace called Acme with description 'Production monitoring'"
- "Show all metrics in workspace Acme"
- "What monitors are failing in workspace Acme?"
- "List recent incidents in workspace Acme"
- "Get details for incident `<uuid>`"
- "Show all integrations in workspace Acme"
- "Create a postgres datasource in workspace Acme"
- "What is a slice in Lightup?"
- "How does monitoring work?"

---

## Available tools

| Tool | Description |
|---|---|
| `list_workspaces` | List all workspaces |
| `get_workspace` | Get workspace details |
| `create_workspace` | Create a new workspace |
| `list_metrics` | List metrics in a workspace |
| `get_metric` | Get metric details |
| `search_metric` | Search for a metric by name across all workspaces |
| `list_datasources` | List datasources in a workspace |
| `get_datasource` | Get datasource details |
| `test_datasource_connection` | Test a datasource connection before creating |
| `create_datasource` | Create a new datasource (postgres, snowflake, mysql, bigquery, etc.) |
| `list_monitors` | List monitors in a workspace |
| `get_monitor` | Get monitor details |
| `list_incidents` | List recent incidents in a workspace |
| `get_incident` | Get incident details |
| `list_integrations` | List integrations (email, Slack, ServiceNow, OpsGenie) in a workspace |
| `get_documentation` | Fetch Lightup product documentation by topic |
| `list_documentation_topics` | List all available documentation topics |
