"""
Lightup AI Config

Loads and saves ~/.lightup-ai/config.json
"""

import json
import os
from pathlib import Path

CONFIG_DIR = Path.home() / ".lightup-ai"
CONFIG_FILE = CONFIG_DIR / "config.json"

AI_PROVIDERS = {
    "claude": {
        "name": "Claude (Anthropic)",
        "default_model": "claude-sonnet-4-6",
        "key_env": "ANTHROPIC_API_KEY",
        "key_hint": "sk-ant-...",
    },
    "openai": {
        "name": "OpenAI (GPT-4)",
        "default_model": "gpt-4o",
        "key_env": "OPENAI_API_KEY",
        "key_hint": "sk-...",
    },
    "gemini": {
        "name": "Gemini (Google)",
        "default_model": "gemini-2.0-flash",
        "key_env": "GEMINI_API_KEY",
        "key_hint": "AIza...",
    },
}


class Config:
    def __init__(self, data: dict):
        self.host: str = data.get("host", "")
        self.refresh_token: str = data.get("refresh_token", "")
        self.ai_provider: str = data.get("ai_provider", "claude")
        self.ai_model: str = data.get("ai_model", "claude-sonnet-4-6")
        self.ai_api_key: str = data.get("ai_api_key", "")

    def to_dict(self) -> dict:
        return {
            "host": self.host,
            "refresh_token": self.refresh_token,
            "ai_provider": self.ai_provider,
            "ai_model": self.ai_model,
            "ai_api_key": self.ai_api_key,
        }

    def is_valid(self) -> bool:
        if not self.host or not self.refresh_token:
            return False
        if not self.ai_api_key:
            return False
        return True


def load_config() -> Config | None:
    """Load config from ~/.lightup-ai/config.json or environment variables."""
    data = {}

    # Load from file if exists
    if CONFIG_FILE.exists():
        with open(CONFIG_FILE) as f:
            data = json.load(f)

    # Environment variables override file
    if os.environ.get("LIGHTUP_HOST"):
        data["host"] = os.environ["LIGHTUP_HOST"]
    if os.environ.get("LIGHTUP_REFRESH_TOKEN"):
        data["refresh_token"] = os.environ["LIGHTUP_REFRESH_TOKEN"]
    if os.environ.get("LIGHTUP_AI_PROVIDER"):
        data["ai_provider"] = os.environ["LIGHTUP_AI_PROVIDER"]
    if os.environ.get("LIGHTUP_AI_MODEL"):
        data["ai_model"] = os.environ["LIGHTUP_AI_MODEL"]

    # AI key from provider-specific env var
    provider = data.get("ai_provider", "claude")
    if provider in AI_PROVIDERS:
        env_key = AI_PROVIDERS[provider]["key_env"]
        if env_key and os.environ.get(env_key):
            data["ai_api_key"] = os.environ[env_key]

    if not data:
        return None

    return Config(data)


def save_config(config: Config) -> None:
    """Save config to ~/.lightup-ai/config.json"""
    CONFIG_DIR.mkdir(parents=True, exist_ok=True)
    with open(CONFIG_FILE, "w") as f:
        json.dump(config.to_dict(), f, indent=2)
    # restrict permissions — config contains API keys
    CONFIG_FILE.chmod(0o600)
