"""
Lightup AI Setup Wizard

Interactive setup: collects Lightup host/token + AI provider config,
tests connections, saves config, and auto-configures Claude Desktop.
"""

import json
import signal
import socket
import subprocess
from pathlib import Path

try:
    import readline  # enables arrow keys, cursor movement, history in input()

    readline.parse_and_bind("tab: complete")
except ImportError:
    pass  # Windows — not available, input() still works

import httpx
import psutil
from lightup_ai.config import AI_PROVIDERS, Config, save_config

CLAUDE_DESKTOP_CONFIG = (
    Path.home()
    / "Library"
    / "Application Support"
    / "Claude"
    / "claude_desktop_config.json"
)

MCP_PORT = 8765
MCP_SSE_URL = f"http://localhost:{MCP_PORT}/sse"


def prompt(label: str, default: str = "", secret: bool = False) -> str:
    """Prompt user for input with optional default."""
    display = f"{label}"
    if default:
        display += f" [{default}]"
    display += ": "

    if secret:
        import getpass

        value = getpass.getpass(display)
    else:
        value = input(display).strip()

    return value or default


def pick_provider() -> tuple[str, str]:
    """Interactive AI provider selection. Returns (provider_key, model)."""
    print("\nChoose AI provider:")
    keys = list(AI_PROVIDERS.keys())
    for i, key in enumerate(keys, 1):
        info = AI_PROVIDERS[key]
        print(f"  {i}. {info['name']}")

    while True:
        choice = input(f"\nSelect [1-{len(keys)}]: ").strip()
        if choice.isdigit() and 1 <= int(choice) <= len(keys):
            provider_key = keys[int(choice) - 1]
            model = AI_PROVIDERS[provider_key]["default_model"]
            return provider_key, model
        print(f"  Invalid choice, enter 1-{len(keys)}")


def test_lightup_connection(
    host: str, refresh_token: str, verbose: bool = False
) -> bool:
    """Verify host is reachable and refresh token is valid."""
    url = f"{host.rstrip('/')}/api/v1/token/refresh/"
    if verbose:
        print(f"\n  [api] POST {url}")
    try:
        resp = httpx.post(url, json={"refresh": refresh_token}, timeout=10)
        if verbose:
            print(f"  [api] → {resp.status_code}")
            data = resp.json()
            if data.get("access"):
                print("  [api] Access token received: <redacted>")
            else:
                print(f"  [api] Response: {data}")
        return resp.status_code == 200 and bool(resp.json().get("access"))
    except Exception as e:
        if verbose:
            print(f"  [api] Error: {e}")
        return False


def test_ai_key(provider: str, api_key: str) -> bool:
    """Validate AI API key format."""
    if not api_key:
        return False
    if provider == "claude":
        return api_key.startswith("sk-ant-")
    if provider == "openai":
        return api_key.startswith("sk-") or api_key.startswith("sk-proj-")
    if provider == "gemini":
        return api_key.startswith("AIza")
    return True


def configure_claude_desktop(config: Config) -> bool:
    """Auto-write lightup-ai entry into Claude Desktop config."""
    if not CLAUDE_DESKTOP_CONFIG.exists():
        return False

    try:
        with open(CLAUDE_DESKTOP_CONFIG) as f:
            desktop_config = json.load(f)
    except Exception:
        desktop_config = {}

    desktop_config.setdefault("mcpServers", {})
    desktop_config["mcpServers"]["lightup-ai"] = {
        "command": "lightup-ai",
        "args": ["serve", "--stdio"],
    }

    with open(CLAUDE_DESKTOP_CONFIG, "w") as f:
        json.dump(desktop_config, f, indent=2)

    return True


def _port_in_use(port: int) -> bool:
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        return s.connect_ex(("localhost", port)) == 0


def _kill_port(port: int) -> bool:
    """Kill any process listening on the given port. Returns True if killed."""
    for proc in psutil.process_iter(["pid"]):
        try:
            for conn in proc.net_connections():
                if conn.laddr.port == port and conn.status == "LISTEN":
                    proc.send_signal(signal.SIGTERM)
                    proc.wait(timeout=3)
                    return True
        except (psutil.NoSuchProcess, psutil.AccessDenied):
            pass
    return False


def _configure_claude_code_mcp(port: int = MCP_PORT) -> None:
    """Auto-add lightup-ai to Claude Code by writing ~/.claude.json directly."""
    claude_json = Path.home() / ".claude.json"
    if not claude_json.exists():
        print("  ℹ️  Claude Code: not installed")
        return

    try:
        with open(claude_json) as f:
            data = json.load(f)
    except Exception:
        data = {}

    data.setdefault("mcpServers", {})
    if "lightup-ai" in data["mcpServers"]:
        print("  ✅ Claude Code: lightup-ai already connected")
        return

    data["mcpServers"]["lightup-ai"] = {
        "type": "sse",
        "url": f"http://localhost:{port}/sse",
    }

    try:
        with open(claude_json, "w") as f:
            json.dump(data, f, indent=2)
        print("  ✅ Claude Code: lightup-ai connected")
        print("     → Restart Claude Code to apply changes")
    except Exception as e:
        print(f"  ⚠️  Claude Code: auto-config failed ({e})")
        print(
            f"       claude mcp add --transport sse lightup-ai http://localhost:{port}/sse"
        )


def start_server(port: int = MCP_PORT, verbose: bool = False) -> None:
    """Kill any existing server on the port and start a fresh one in background."""
    if _port_in_use(port):
        print(f"  Stopping existing server on port {port}...", end=" ", flush=True)
        if _kill_port(port):
            print("done")
        else:
            print("failed — server may still be running")
            return

    print(f"  Starting MCP server on port {port}...", end=" ", flush=True)
    import sys
    import threading

    stderr = subprocess.PIPE if verbose else subprocess.DEVNULL
    proc = subprocess.Popen(
        [sys.executable, "-m", "lightup_ai.server"],
        stdout=subprocess.DEVNULL,
        stderr=stderr,
    )

    if verbose:

        def _stream_logs():
            for line in proc.stderr:
                print(f"  [server] {line.decode().rstrip()}", flush=True)

        threading.Thread(target=_stream_logs, daemon=True).start()

    # Wait briefly and confirm it started
    import time

    for _ in range(10):
        time.sleep(0.5)
        if _port_in_use(port):
            print(f"✅  http://localhost:{port}/sse")
            return
    print("⚠️  server did not start — run manually: lightup-ai serve")


def run_doctor(config: Config) -> None:
    """Verify all components are working. Runs automatically after setup."""
    print("\n" + "─" * 60)
    print("Verification checks:")

    # Lightup host + token valid
    if test_lightup_connection(config.host, config.refresh_token):
        print(f"  ✅ Lightup connected: {config.host}")
    else:
        print(f"  ❌ Cannot connect to Lightup: {config.host}")

    # MCP server running
    if _port_in_use(MCP_PORT):
        print(f"  ✅ MCP server running: http://localhost:{MCP_PORT}")
    else:
        print("  ❌ MCP server not running")

    # Claude Code MCP
    claude_json = Path.home() / ".claude.json"
    if claude_json.exists():
        try:
            with open(claude_json) as f:
                claude_config = json.load(f)
            servers = claude_config.get("mcpServers", {})
            if "lightup-ai" in servers:
                print("  ✅ Claude Code: lightup-ai connected")
            else:
                _configure_claude_code_mcp()
        except Exception:
            print("  ℹ️  Claude Code: config unreadable")
    else:
        print("  ℹ️  Claude Code: not installed")

    # Claude Desktop (optional)
    if CLAUDE_DESKTOP_CONFIG.exists():
        with open(CLAUDE_DESKTOP_CONFIG) as f:
            desktop = json.load(f)
        if "lightup-ai" in desktop.get("mcpServers", {}):
            print("  ✅ Claude Desktop: configured")
        else:
            print("  ℹ️  Claude Desktop: not configured (optional)")

    print(f"  ✅ AI provider: {config.ai_provider} / {config.ai_model}")


def load_credential_file(path: str) -> tuple[str, str] | None:
    """
    Parse a Lightup API credential file.
    Returns (host, refresh_token) or None if invalid.
    Supports the standard format: data.server + data.refresh
    """
    try:
        with open(path) as f:
            cred = json.load(f)
        data = cred.get("data", {})
        host = data.get("server", "")
        refresh_token = data.get("refresh", "")
        if host and refresh_token:
            return host.rstrip("/"), refresh_token
    except Exception:
        pass
    return None


def run_setup(verbose: bool = False) -> Config:
    """Run the interactive setup wizard followed by verification checks."""
    from lightup_ai.config import CONFIG_FILE

    # Clear stale config before starting
    if CONFIG_FILE.exists():
        CONFIG_FILE.unlink()

    print("\nWelcome to Lightup AI!")
    print("This will set up the Lightup AI assistant on your machine.")
    print("─" * 60)

    # Lightup connection
    print("\nLightup connection:")
    host = ""
    refresh_token = ""

    cred_path = prompt(
        "  Credential file path (lightup-api-credential.json)", default=""
    )
    if cred_path:
        result = load_credential_file(cred_path.strip())
        if result:
            host, refresh_token = result
            print(f"  Host: {host}")
            print("  Testing Lightup connection...", end=" ", flush=True)
            if test_lightup_connection(host, refresh_token, verbose=verbose):
                print("✅")
            else:
                print("❌ Connection failed — please enter credentials manually.")
                host = ""
                refresh_token = ""
        else:
            print("  ❌ Could not read credential file — please enter manually.")

    if not host:
        host = prompt("  Lightup host (e.g. https://app.stage.lightup.ai)")

    if not refresh_token:
        while True:
            try:
                refresh_token = prompt("  Lightup refresh token", secret=True)
            except (KeyboardInterrupt, EOFError):
                print("\nSetup cancelled.")
                raise SystemExit(0)
            print("\n  Testing Lightup connection...", end=" ", flush=True)
            if test_lightup_connection(host, refresh_token, verbose=verbose):
                print("✅")
                break
            print("❌ Invalid refresh token — please try again. (Ctrl+C to exit)")

    # AI provider
    print("\nAI provider:")
    provider, model = pick_provider()

    key_hint = AI_PROVIDERS[provider]["key_hint"]
    api_key = ""
    while True:
        api_key = prompt(f"  API key ({key_hint})", secret=True)
        if not api_key:
            print("  ❌ API key is required. Please enter a valid key.")
            continue
        print("\n  Testing AI key...", end=" ", flush=True)
        if test_ai_key(provider, api_key):
            print("✅")
            break
        print("❌ Invalid key — please try again.")

    # Save config
    config = Config(
        {
            "host": host,
            "refresh_token": refresh_token,
            "ai_provider": provider,
            "ai_model": model,
            "ai_api_key": api_key,
        }
    )
    save_config(config)
    print("\n✅ Config saved to ~/.lightup-ai/config.json")

    # Claude Desktop auto-config
    if configure_claude_desktop(config):
        print("✅ Claude Desktop configured automatically")
        print("   → Restart Claude Desktop to apply changes")
    else:
        print("ℹ️  Claude Desktop not found — skipping auto-config")

    # Claude Code auto-config
    _configure_claude_code_mcp()

    # Start MCP server in background
    print("\nStarting MCP server:")
    start_server(verbose=verbose)

    # Verify everything
    run_doctor(config)

    print("\n" + "─" * 60)
    print("Setup complete! Starting interactive chat...\n")
    print("  Type your question and press Enter.")
    print("  Type 'exit' or press Ctrl+C to quit.")
    print("─" * 60 + "\n")

    run_chat(config, verbose=verbose)

    return config


def _thinking_spinner(fn, *args, label: str = "AI") -> str:
    """Run fn(*args) in a thread while showing an animated thinking spinner."""
    import itertools
    import threading

    frames = ["⠋", "⠙", "⠹", "⠸", "⠼", "⠴", "⠦", "⠧", "⠇", "⠏"]
    itertools.cycle(["Thinking", "Thinking.", "Thinking..", "Thinking..."])
    result = [None]
    error = [None]
    done = threading.Event()

    def worker():
        try:
            result[0] = fn(*args)
        except Exception as e:
            error[0] = e
        finally:
            done.set()

    thread = threading.Thread(target=worker)
    thread.start()

    spinner = itertools.cycle(frames)
    thinking = itertools.cycle(["Thinking", "Thinking.", "Thinking..", "Thinking..."])
    while not done.wait(0.1):
        print(f"\r  {next(spinner)} {next(thinking)}   ", end="", flush=True)

    print("\r" + " " * 30 + "\r", end="", flush=True)  # clear spinner line

    if error[0]:
        raise error[0]
    return result[0]


def run_chat(config: Config, verbose: bool = False) -> None:
    """Interactive chat loop — runs after setup or via `lightup-ai chat`."""
    from lightup_ai.ai.factory import get_ai_provider
    from lightup_ai.tools.client import get_tool_usage, reset_tool_usage, set_verbose

    set_verbose(verbose)
    reset_tool_usage()
    mcp_url = MCP_SSE_URL
    provider = get_ai_provider(config, mcp_url, verbose=verbose)
    messages = []

    while True:
        try:
            question = input("You: ").strip()
        except (KeyboardInterrupt, EOFError):
            print("\nGoodbye!")
            break

        if not question:
            continue
        if question.lower() in ("exit", "quit", "bye"):
            print("Goodbye!")
            break

        messages.append({"role": "user", "content": question})

        try:
            answer = _thinking_spinner(
                provider.chat, list(messages), config.ai_provider
            )
            if answer:
                print(f"\n{config.ai_provider.capitalize()}: {answer}")
                messages.append({"role": "assistant", "content": answer})
            else:
                messages.pop()
                print(
                    f"\n{config.ai_provider.capitalize()}: (no response — please try again)"
                )
        except Exception as e:
            messages.pop()  # drop unanswered user message
            inner = e
            while hasattr(inner, "exceptions") and inner.exceptions:
                inner = inner.exceptions[0]
            print(f"❌ {inner}")

        print()

    usage = get_tool_usage()
    if usage:
        print("\nTools used this session:")
        for tool, count in usage.most_common():
            print(f"  {tool}: {count}x")
