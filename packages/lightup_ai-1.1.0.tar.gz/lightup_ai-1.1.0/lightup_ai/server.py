"""
Lightup AI Server

Exposes Lightup data engineering operations as MCP tools
for safe agentic/vibe coding workflows.

Runs as HTTP/SSE server on http://localhost:8765
"""

import logging
import sys

import mcp.types as types
import uvicorn
from lightup_ai.tools.datasources import (
    create_datasource,
    get_datasource,
    list_datasources,
    test_datasource_connection,
)
from lightup_ai.tools.documentation import (
    DOCS_DIR,
    get_documentation,
    list_documentation_topics,
)
from lightup_ai.tools.incidents import get_incident, list_incidents
from lightup_ai.tools.integrations import list_integrations
from lightup_ai.tools.metrics import get_metric, list_metrics, search_metric
from lightup_ai.tools.monitors import get_monitor, list_monitors
from lightup_ai.tools.workspaces import create_workspace, get_workspace, list_workspaces
from mcp.server import Server
from mcp.server.sse import SseServerTransport
from starlette.applications import Starlette
from starlette.requests import Request
from starlette.responses import Response
from starlette.routing import Mount, Route

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(message)s",
    stream=sys.stderr,
)
logger = logging.getLogger(__name__)

HOST = "0.0.0.0"
PORT = 8765

app = Server("lightup-ai")


@app.list_tools()
async def list_tools() -> list[types.Tool]:
    return [
        types.Tool(
            name="get_documentation",
            description=(
                "Fetch Lightup product documentation for a given topic. "
                "Use this to answer questions about how Lightup works before calling any action tools. "
                "Topics: metric, monitor, datasource, incident, schedule, slice, integration. "
                "Or pass a specific filename like 'sql-metrics.md'."
            ),
            inputSchema={
                "type": "object",
                "required": ["topic"],
                "properties": {
                    "topic": {
                        "type": "string",
                        "description": "Topic or doc filename to look up (e.g. 'metric', 'monitor', 'sql-metrics.md')",
                    }
                },
            },
        ),
        types.Tool(
            name="list_documentation_topics",
            description="List all available Lightup documentation files.",
            inputSchema={"type": "object", "properties": {}},
        ),
        types.Tool(
            name="list_workspaces",
            description="List all Lightup workspaces the user has access to.",
            inputSchema={"type": "object", "properties": {}},
        ),
        types.Tool(
            name="create_workspace",
            description="Create a new Lightup workspace with a name and optional description.",
            inputSchema={
                "type": "object",
                "required": ["name"],
                "properties": {
                    "name": {
                        "type": "string",
                        "description": "Name for the new workspace",
                    },
                    "description": {
                        "type": "string",
                        "description": "Optional description for the workspace",
                    },
                },
            },
        ),
        types.Tool(
            name="get_workspace",
            description="Get details for a specific Lightup workspace by UUID.",
            inputSchema={
                "type": "object",
                "required": ["workspace_uuid"],
                "properties": {
                    "workspace_uuid": {
                        "type": "string",
                        "description": "UUID of the workspace to retrieve",
                    }
                },
            },
        ),
        types.Tool(
            name="search_metric",
            description="Search for a metric by name across all workspaces. Use this when the user asks about a metric but does not specify a workspace.",
            inputSchema={
                "type": "object",
                "required": ["metric_name"],
                "properties": {
                    "metric_name": {
                        "type": "string",
                        "description": "Name (or partial name) of the metric to search for",
                    }
                },
            },
        ),
        types.Tool(
            name="list_metrics",
            description="List all metrics in a Lightup workspace. Accepts workspace name or UUID.",
            inputSchema={
                "type": "object",
                "required": ["workspace_name_or_uuid"],
                "properties": {
                    "workspace_name_or_uuid": {
                        "type": "string",
                        "description": "Name or UUID of the workspace",
                    }
                },
            },
        ),
        types.Tool(
            name="get_metric",
            description="Get details for a specific metric by name or UUID. Accepts workspace name or UUID.",
            inputSchema={
                "type": "object",
                "required": ["workspace_name_or_uuid", "metric_name_or_uuid"],
                "properties": {
                    "workspace_name_or_uuid": {
                        "type": "string",
                        "description": "Name or UUID of the workspace",
                    },
                    "metric_name_or_uuid": {
                        "type": "string",
                        "description": "Name or UUID of the metric",
                    },
                },
            },
        ),
        types.Tool(
            name="list_datasources",
            description="List all datasources in a Lightup workspace, including their scan status and any error messages. Use this to check the health of datasources. Accepts workspace name or UUID.",
            inputSchema={
                "type": "object",
                "required": ["workspace_name_or_uuid"],
                "properties": {
                    "workspace_name_or_uuid": {
                        "type": "string",
                        "description": "Name or UUID of the workspace",
                    }
                },
            },
        ),
        types.Tool(
            name="get_datasource",
            description="Get details for a specific datasource by name or UUID. Accepts workspace name or UUID.",
            inputSchema={
                "type": "object",
                "required": ["workspace_name_or_uuid", "datasource_name_or_uuid"],
                "properties": {
                    "workspace_name_or_uuid": {
                        "type": "string",
                        "description": "Name or UUID of the workspace",
                    },
                    "datasource_name_or_uuid": {
                        "type": "string",
                        "description": "Name or UUID of the datasource",
                    },
                },
            },
        ),
        types.Tool(
            name="test_datasource_connection",
            description=(
                "Test a datasource connection before creating it. "
                "Always call this before create_datasource and show the result to the user. "
                "connection_config_json is a JSON string of the connection object. "
                "Examples by type — "
                'postgres: {"type":"postgres","host":"...","port":5432,"dbname":"...","user":"...","password":"..."}, '
                'snowflake: {"type":"snowflake","account":"...","user":"...","password":"...","warehouse":"...","database":"..."}, '
                'mysql: {"type":"mysql","host":"...","port":3306,"dbname":"...","user":"...","password":"..."}, '
                'bigquery: {"type":"bigquery","project":"...","dataset":"...","credentials":"..."}, '
                'redshift: {"type":"redshift","host":"...","port":5439,"dbname":"...","user":"...","password":"..."}, '
                'databricks: {"type":"databricks","host":"...","token":"...","http_path":"...","catalog":"..."}.'
            ),
            inputSchema={
                "type": "object",
                "required": [
                    "workspace_name_or_uuid",
                    "name",
                    "connection_config_json",
                ],
                "properties": {
                    "workspace_name_or_uuid": {
                        "type": "string",
                        "description": "Name or UUID of the workspace",
                    },
                    "name": {
                        "type": "string",
                        "description": "Name for the datasource",
                    },
                    "connection_config_json": {
                        "type": "string",
                        "description": "JSON string of the connection config including type and credentials",
                    },
                    "scan_interval": {
                        "type": "string",
                        "description": "Scan interval in seconds (default: 86400 = 24 hours)",
                    },
                },
            },
        ),
        types.Tool(
            name="create_datasource",
            description=(
                "Create a new datasource in a workspace. "
                "ALWAYS call test_datasource_connection first and confirm with the user before calling this. "
                "Uses the same connection_config_json format as test_datasource_connection."
            ),
            inputSchema={
                "type": "object",
                "required": [
                    "workspace_name_or_uuid",
                    "name",
                    "connection_config_json",
                ],
                "properties": {
                    "workspace_name_or_uuid": {
                        "type": "string",
                        "description": "Name or UUID of the workspace",
                    },
                    "name": {
                        "type": "string",
                        "description": "Name for the datasource",
                    },
                    "connection_config_json": {
                        "type": "string",
                        "description": "JSON string of the connection config including type and credentials",
                    },
                    "scan_interval": {
                        "type": "string",
                        "description": "Scan interval in seconds (default: 86400 = 24 hours)",
                    },
                },
            },
        ),
        types.Tool(
            name="list_monitors",
            description="List all monitors in a Lightup workspace. Accepts workspace name or UUID.",
            inputSchema={
                "type": "object",
                "required": ["workspace_name_or_uuid"],
                "properties": {
                    "workspace_name_or_uuid": {
                        "type": "string",
                        "description": "Name or UUID of the workspace",
                    }
                },
            },
        ),
        types.Tool(
            name="get_monitor",
            description="Get details for a specific monitor by name or UUID. Accepts workspace name or UUID.",
            inputSchema={
                "type": "object",
                "required": ["workspace_name_or_uuid", "monitor_name_or_uuid"],
                "properties": {
                    "workspace_name_or_uuid": {
                        "type": "string",
                        "description": "Name or UUID of the workspace",
                    },
                    "monitor_name_or_uuid": {
                        "type": "string",
                        "description": "Name or UUID of the monitor",
                    },
                },
            },
        ),
        types.Tool(
            name="list_incidents",
            description="List recent incidents in a Lightup workspace. Accepts workspace name or UUID.",
            inputSchema={
                "type": "object",
                "required": ["workspace_name_or_uuid"],
                "properties": {
                    "workspace_name_or_uuid": {
                        "type": "string",
                        "description": "Name or UUID of the workspace",
                    }
                },
            },
        ),
        types.Tool(
            name="get_incident",
            description="Get details for a specific incident by UUID. Accepts workspace name or UUID.",
            inputSchema={
                "type": "object",
                "required": ["workspace_name_or_uuid", "incident_uuid"],
                "properties": {
                    "workspace_name_or_uuid": {
                        "type": "string",
                        "description": "Name or UUID of the workspace",
                    },
                    "incident_uuid": {
                        "type": "string",
                        "description": "UUID of the incident",
                    },
                },
            },
        ),
        types.Tool(
            name="list_integrations",
            description="List all integrations (email, Slack, ServiceNow, OpsGenie, etc.) in a Lightup workspace, including their run status and any error messages. Use this to check the health of integrations. Accepts workspace name or UUID.",
            inputSchema={
                "type": "object",
                "required": ["workspace_name_or_uuid"],
                "properties": {
                    "workspace_name_or_uuid": {
                        "type": "string",
                        "description": "Name or UUID of the workspace",
                    }
                },
            },
        ),
    ]


@app.call_tool()
async def call_tool(name: str, arguments: dict) -> list[types.TextContent]:
    logger.info(f"Tool: {name}  args: {arguments}")
    if name == "get_documentation":
        result = get_documentation(arguments["topic"])
        return [types.TextContent(type="text", text=result)]

    if name == "list_documentation_topics":
        topics = list_documentation_topics()
        return [types.TextContent(type="text", text="\n".join(topics))]

    if name == "list_workspaces":
        return [types.TextContent(type="text", text=list_workspaces())]

    if name == "create_workspace":
        return [
            types.TextContent(
                type="text",
                text=create_workspace(
                    arguments["name"],
                    arguments.get("description", ""),
                ),
            )
        ]

    if name == "get_workspace":
        return [
            types.TextContent(
                type="text", text=get_workspace(arguments["workspace_uuid"])
            )
        ]

    if name == "search_metric":
        return [
            types.TextContent(type="text", text=search_metric(arguments["metric_name"]))
        ]

    if name == "list_metrics":
        return [
            types.TextContent(
                type="text", text=list_metrics(arguments["workspace_name_or_uuid"])
            )
        ]

    if name == "get_metric":
        return [
            types.TextContent(
                type="text",
                text=get_metric(
                    arguments["workspace_name_or_uuid"],
                    arguments["metric_name_or_uuid"],
                ),
            )
        ]

    if name == "list_datasources":
        return [
            types.TextContent(
                type="text", text=list_datasources(arguments["workspace_name_or_uuid"])
            )
        ]

    if name == "get_datasource":
        return [
            types.TextContent(
                type="text",
                text=get_datasource(
                    arguments["workspace_name_or_uuid"],
                    arguments["datasource_name_or_uuid"],
                ),
            )
        ]

    if name == "test_datasource_connection":
        return [
            types.TextContent(
                type="text",
                text=test_datasource_connection(
                    arguments["workspace_name_or_uuid"],
                    arguments["name"],
                    arguments["connection_config_json"],
                    int(arguments.get("scan_interval", 86400)),
                ),
            )
        ]

    if name == "create_datasource":
        return [
            types.TextContent(
                type="text",
                text=create_datasource(
                    arguments["workspace_name_or_uuid"],
                    arguments["name"],
                    arguments["connection_config_json"],
                    int(arguments.get("scan_interval", 86400)),
                ),
            )
        ]

    if name == "list_monitors":
        return [
            types.TextContent(
                type="text", text=list_monitors(arguments["workspace_name_or_uuid"])
            )
        ]

    if name == "get_monitor":
        return [
            types.TextContent(
                type="text",
                text=get_monitor(
                    arguments["workspace_name_or_uuid"],
                    arguments["monitor_name_or_uuid"],
                ),
            )
        ]

    if name == "list_incidents":
        return [
            types.TextContent(
                type="text", text=list_incidents(arguments["workspace_name_or_uuid"])
            )
        ]

    if name == "get_incident":
        return [
            types.TextContent(
                type="text",
                text=get_incident(
                    arguments["workspace_name_or_uuid"], arguments["incident_uuid"]
                ),
            )
        ]

    if name == "list_integrations":
        return [
            types.TextContent(
                type="text",
                text=list_integrations(arguments["workspace_name_or_uuid"]),
            )
        ]

    raise ValueError(f"Unknown tool: {name}")


def create_starlette_app() -> Starlette:
    sse = SseServerTransport("/messages/")

    async def handle_sse(request: Request) -> Response:
        async with sse.connect_sse(
            request.scope, request.receive, request._send
        ) as streams:
            await app.run(streams[0], streams[1], app.create_initialization_options())
        return Response()

    return Starlette(
        routes=[
            Route("/sse", endpoint=handle_sse, methods=["GET"]),
            Mount("/messages/", app=sse.handle_post_message),
        ]
    )


def main():
    doc_count = len(list(DOCS_DIR.iterdir())) if DOCS_DIR.exists() else 0
    logger.info("Lightup AI server starting...")
    logger.info(f"Docs directory: {DOCS_DIR} ({doc_count} files)")
    logger.info(
        "Registered tools: get_documentation, list_documentation_topics, list_workspaces, get_workspace"
    )
    logger.info(f"SSE endpoint:  http://{HOST}:{PORT}/sse")
    logger.info(f"Messages endpoint: http://{HOST}:{PORT}/messages/")

    starlette_app = create_starlette_app()
    uvicorn.run(starlette_app, host=HOST, port=PORT)


if __name__ == "__main__":
    main()
