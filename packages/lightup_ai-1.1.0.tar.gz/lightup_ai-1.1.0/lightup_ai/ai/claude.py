"""
Claude (Anthropic) AI provider.

For local MCP servers: manual agentic loop — fetch tools from MCP server,
pass to Claude as tool definitions, execute tool calls, return final answer.
"""


import anthropic
from lightup_ai.ai.base import SYSTEM_PROMPT, AIProvider
from lightup_ai.tools.client import track_tool
from mcp import ClientSession
from mcp.client.sse import sse_client


class ClaudeProvider(AIProvider):
    def __init__(
        self, api_key: str, model: str, mcp_server_url: str, verbose: bool = False
    ):
        self._client = anthropic.Anthropic(api_key=api_key)
        self._model = model
        self._mcp_server_url = mcp_server_url
        self._verbose = verbose

    def chat(self, messages: list[dict], tools: list[dict] | None = None) -> str:
        import asyncio

        return asyncio.run(self._chat_async(messages))

    async def _chat_async(self, messages: list[dict]) -> str:
        async with sse_client(self._mcp_server_url) as (read, write):
            async with ClientSession(read, write) as session:
                await session.initialize()

                # Fetch tools from MCP server
                tools_result = await session.list_tools()
                if self._verbose:
                    print(
                        f"\n  [tools registered] ({len(tools_result.tools)}):",
                        flush=True,
                    )
                    for t in tools_result.tools:
                        print(f"    - {t.name}", flush=True)
                tools = [
                    {
                        "name": t.name,
                        "description": t.description,
                        "input_schema": t.inputSchema,
                    }
                    for t in tools_result.tools
                ]

                system = SYSTEM_PROMPT

                # Agentic loop
                while True:
                    response = self._client.messages.create(
                        model=self._model,
                        max_tokens=4096,
                        system=system,
                        messages=messages,
                        tools=tools,
                    )

                    # No tool call — return final answer
                    if response.stop_reason == "end_turn":
                        for block in response.content:
                            if hasattr(block, "text"):
                                return block.text
                        return ""

                    # Execute tool calls
                    if response.stop_reason == "tool_use":
                        # Add assistant message with tool use blocks
                        messages.append(
                            {"role": "assistant", "content": response.content}
                        )

                        # Execute each tool call and collect results
                        tool_results = []
                        for block in response.content:
                            if block.type == "tool_use":
                                track_tool(block.name)
                                if self._verbose:
                                    import json

                                    print(
                                        f"\n  [tool invoked] {block.name}  {json.dumps(block.input)}",
                                        flush=True,
                                    )
                                result = await session.call_tool(
                                    block.name, block.input
                                )
                                result_text = (
                                    result.content[0].text if result.content else ""
                                )
                                if self._verbose:
                                    preview = result_text[:200].replace("\n", " ")
                                    print(f"  [tool result]  {preview}", flush=True)
                                tool_results.append(
                                    {
                                        "type": "tool_result",
                                        "tool_use_id": block.id,
                                        "content": result_text,
                                    }
                                )

                        # Feed results back to Claude
                        messages.append({"role": "user", "content": tool_results})
                        continue

                    # Unexpected stop reason
                    return ""
