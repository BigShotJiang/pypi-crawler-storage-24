"""
OpenAI (GPT-4) AI provider.

Manual agentic loop — fetch tools from local MCP server via SSE,
pass to GPT-4 as function definitions, execute tool calls, return final answer.
"""

import asyncio
import json

from lightup_ai.ai.base import SYSTEM_PROMPT, AIProvider
from lightup_ai.tools.client import track_tool
from mcp import ClientSession
from mcp.client.sse import sse_client
from openai import AsyncOpenAI


class OpenAIProvider(AIProvider):
    def __init__(
        self, api_key: str, model: str, mcp_server_url: str, verbose: bool = False
    ):
        self._client = AsyncOpenAI(api_key=api_key)
        self._model = model
        self._mcp_server_url = mcp_server_url
        self._verbose = verbose

    def chat(self, messages: list[dict], tools: list[dict] | None = None) -> str:
        return asyncio.run(self._chat_async(messages))

    async def _chat_async(self, messages: list[dict]) -> str:
        async with sse_client(self._mcp_server_url) as (read, write):
            async with ClientSession(read, write) as session:
                await session.initialize()

                # Fetch tools from MCP server and convert to OpenAI function format
                tools_result = await session.list_tools()
                if self._verbose:
                    print(
                        f"\n  [tools registered] ({len(tools_result.tools)}):",
                        flush=True,
                    )
                    for t in tools_result.tools:
                        print(f"    - {t.name}", flush=True)
                openai_tools = [
                    {
                        "type": "function",
                        "function": {
                            "name": t.name,
                            "description": t.description or "",
                            "parameters": t.inputSchema,
                        },
                    }
                    for t in tools_result.tools
                ]

                system = SYSTEM_PROMPT
                messages = [{"role": "system", "content": system}] + messages

                # Agentic loop
                while True:
                    response = await self._client.chat.completions.create(
                        model=self._model,
                        messages=messages,
                        tools=openai_tools,
                        tool_choice="auto",
                    )

                    msg = response.choices[0].message
                    finish_reason = response.choices[0].finish_reason

                    # No tool call — return final answer
                    if finish_reason == "stop" or not msg.tool_calls:
                        return msg.content or ""

                    # Add assistant message with tool calls to history
                    messages.append(msg.model_dump(exclude_unset=True))

                    # Execute each tool call and feed results back
                    for tc in msg.tool_calls:
                        args = json.loads(tc.function.arguments)
                        track_tool(tc.function.name)
                        if self._verbose:
                            print(
                                f"\n  [tool invoked] {tc.function.name}  {tc.function.arguments}",
                                flush=True,
                            )
                        result = await session.call_tool(tc.function.name, args)
                        result_text = result.content[0].text if result.content else ""
                        if self._verbose:
                            preview = result_text[:200].replace("\n", " ")
                            print(f"  [tool result]  {preview}", flush=True)
                        messages.append(
                            {
                                "role": "tool",
                                "tool_call_id": tc.id,
                                "content": result_text,
                            }
                        )
