"""
AI provider factory — returns the right provider from config.
"""

from lightup_ai.ai.base import AIProvider
from lightup_ai.ai.claude import ClaudeProvider
from lightup_ai.ai.gemini import GeminiProvider
from lightup_ai.ai.openai import OpenAIProvider
from lightup_ai.config import Config


def get_ai_provider(
    config: Config, mcp_server_url: str, verbose: bool = False
) -> AIProvider:
    match config.ai_provider:
        case "claude":
            return ClaudeProvider(
                config.ai_api_key, config.ai_model, mcp_server_url, verbose=verbose
            )
        case "openai":
            return OpenAIProvider(
                config.ai_api_key, config.ai_model, mcp_server_url, verbose=verbose
            )
        case "gemini":
            return GeminiProvider(
                config.ai_api_key, config.ai_model, mcp_server_url, verbose=verbose
            )
        case _:
            raise ValueError(f"Unknown AI provider: {config.ai_provider}")
