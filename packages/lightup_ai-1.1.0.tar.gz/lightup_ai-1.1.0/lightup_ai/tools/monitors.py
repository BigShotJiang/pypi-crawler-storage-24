"""
MCP tools for Lightup monitors.
"""

from lightup_ai.tools.client import api_get
from lightup_ai.tools.metrics import _is_uuid, _resolve_workspace_uuid


def list_monitors(workspace_name_or_uuid: str) -> str:
    """List all monitors in a workspace."""
    workspace_uuid = _resolve_workspace_uuid(workspace_name_or_uuid)
    resp = api_get(f"/api/v1/ws/{workspace_uuid}/monitors/")

    monitors = resp.get("data", [])
    summary = resp.get("metadata", {})

    if not monitors:
        return "No monitors found in this workspace."

    lines = [
        f"Found {summary.get('totalCount', len(monitors))} monitor(s): "
        f"{summary.get('liveCount', 0)} live, "
        f"{summary.get('pausedCount', 0)} paused, "
        f"{summary.get('trainingCount', 0)} training, "
        f"{summary.get('errorCount', 0)} error\n"
    ]

    for m in monitors:
        if m.get("type") == "template":
            continue  # skip template monitors

        meta = m.get("metadata", {})
        cfg = m.get("config", {})
        status = m.get("status", {})
        symptom = cfg.get("symptom", {})

        lines.append(f"  Name:        {meta.get('name', '')}")
        lines.append(f"  UUID:        {meta.get('uuid', '')}")
        lines.append(f"  Type:        {symptom.get('type', '')}")
        lines.append(
            f"  Metric:      {meta.get('metricName', '')} ({meta.get('metricType', '')})"
        )
        lines.append(
            f"  Table:       {meta.get('schemaName', '')}.{meta.get('tableName', '')}"
        )
        lines.append(f"  Status:      {status.get('displayStatus', '')}")
        lines.append(
            f"  Muted:       {cfg.get('alertConfig', {}).get('isMuted', False)}"
        )
        lines.append("")

    return "\n".join(lines).strip()


def get_monitor(workspace_name_or_uuid: str, monitor_name_or_uuid: str) -> str:
    """Get details for a specific monitor by name or UUID."""
    workspace_uuid = _resolve_workspace_uuid(workspace_name_or_uuid)

    # If UUID provided, fetch directly
    is_uuid = _is_uuid(monitor_name_or_uuid)
    if is_uuid:
        m = api_get(f"/api/v1/ws/{workspace_uuid}/monitors/{monitor_name_or_uuid}")
    else:
        resp = api_get(f"/api/v1/ws/{workspace_uuid}/monitors/")
        monitors = resp.get("data", [])
        search = monitor_name_or_uuid.lower()
        m = next(
            (
                m
                for m in monitors
                if m.get("type") != "template"
                and m.get("metadata", {}).get("name", "").lower() == search
            ),
            None,
        )

    if not m:
        return f"Monitor '{monitor_name_or_uuid}' not found in workspace."

    meta = m.get("metadata", {})
    cfg = m.get("config", {})
    status = m.get("status", {})
    symptom = cfg.get("symptom", {})
    training = status.get("training", {})

    lines = [
        f"Name:           {meta.get('name', '')}",
        f"UUID:           {meta.get('uuid', '')}",
        f"Symptom type:   {symptom.get('type', '')}",
        f"Direction:      {symptom.get('direction', '(n/a)')}",
        f"Display status: {status.get('displayStatus', '')}",
        f"Run status:     {status.get('runStatus', '')}",
        f"Trained:        {training.get('isTrained', '')} / {training.get('status', '')}",
        f"Muted:          {cfg.get('alertConfig', {}).get('isMuted', False)}",
        f"Live:           {cfg.get('isLive', '')}",
        f"Metrics:        {', '.join(cfg.get('metrics', []))}",
    ]
    # These fields only present in list response
    if meta.get("metricName"):
        lines.insert(
            2,
            f"Metric:         {meta.get('metricName', '')} ({meta.get('metricType', '')})",
        )
        lines.insert(3, f"Source:         {meta.get('sourceName', '')}")
        lines.insert(
            4,
            f"Table:          {meta.get('schemaName', '')}.{meta.get('tableName', '')}",
        )
        lines.insert(5, f"Column:         {meta.get('columnName') or '(none)'}")
    if status.get("runStatusMessage"):
        lines.append(f"Status msg:     {status['runStatusMessage']}")

    return "\n".join(lines)
