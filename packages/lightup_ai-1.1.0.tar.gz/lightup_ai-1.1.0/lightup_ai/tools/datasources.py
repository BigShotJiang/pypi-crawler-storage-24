"""
MCP tools for Lightup datasources.
"""

import json

from lightup_ai.tools.client import api_get, api_post
from lightup_ai.tools.metrics import _is_uuid, _resolve_workspace_uuid


def list_datasources(workspace_name_or_uuid: str) -> str:
    """List all datasources in a workspace."""
    workspace_uuid = _resolve_workspace_uuid(workspace_name_or_uuid)
    sources = api_get(f"/api/v1/ws/{workspace_uuid}/sources/")
    if not sources:
        return "No datasources found in this workspace."

    lines = [f"Found {len(sources)} datasource(s):\n"]
    for s in sources:
        meta = s.get("metadata", {})
        cfg = s.get("config", {})
        conn = cfg.get("connection", {})
        status = s.get("status", {})

        lines.append(f"  Name:        {meta.get('name', '')}")
        lines.append(f"  UUID:        {meta.get('uuid', '')}")
        lines.append(f"  Type:        {conn.get('type', '')}")
        lines.append(f"  Health:      {status.get('lastScannedStatus', '(unknown)')}")
        if status.get("lastScannedFailedReason"):
            lines.append(f"  Error:       {status['lastScannedFailedReason']}")
        lines.append(f"  Live:        {cfg.get('isLive', '')}")
        if meta.get("tags"):
            lines.append(f"  Tags:        {', '.join(meta['tags'])}")
        lines.append("")

    return "\n".join(lines).strip()


def get_datasource(workspace_name_or_uuid: str, datasource_name_or_uuid: str) -> str:
    """Get details for a specific datasource by name or UUID."""
    workspace_uuid = _resolve_workspace_uuid(workspace_name_or_uuid)

    # If UUID provided, fetch directly; otherwise resolve name from list
    is_uuid = _is_uuid(datasource_name_or_uuid)
    if is_uuid:
        s = api_get(f"/api/v1/ws/{workspace_uuid}/sources/{datasource_name_or_uuid}")
    else:
        sources = api_get(f"/api/v1/ws/{workspace_uuid}/sources/")
        search = datasource_name_or_uuid.lower()
        match = next(
            (
                s
                for s in sources
                if s.get("metadata", {}).get("name", "").lower() == search
            ),
            None,
        )
        if not match:
            return f"Datasource '{datasource_name_or_uuid}' not found in workspace."
        source_uuid = match["metadata"]["uuid"]
        s = api_get(f"/api/v1/ws/{workspace_uuid}/sources/{source_uuid}")

    if not s:
        return f"Datasource '{datasource_name_or_uuid}' not found in workspace."

    meta = s.get("metadata", {})
    cfg = s.get("config", {})
    conn = cfg.get("connection", {})
    profiler = cfg.get("profiler", {})
    status = s.get("status", {})

    # Skip sensitive fields
    sensitive = {"password", "token", "privateKey", "privateKeyPassphrase"}
    conn_info = {k: v for k, v in conn.items() if k not in sensitive and k != "type"}

    lines = [
        f"Name:          {meta.get('name', '')}",
        f"UUID:          {meta.get('uuid', '')}",
        f"Type:          {conn.get('type', '')}",
        f"Live:          {cfg.get('isLive', '')}",
        f"Scan status:   {status.get('lastScannedStatus', '')}",
        f"Scan errors:   {status.get('scanErrorCount', 0)}",
    ]
    if status.get("lastScannedFailedReason"):
        lines.append(f"Scan error:    {status['lastScannedFailedReason']}")

    for k, v in conn_info.items():
        lines.append(f"{k:<15}{v}")

    lines += [
        f"Profiler:      {'enabled' if profiler.get('enabled') else 'disabled'}",
        f"Scan interval: {profiler.get('scanInterval', '')}s",
    ]
    if meta.get("tags"):
        lines.append(f"Tags:          {', '.join(meta['tags'])}")

    return "\n".join(lines)


def _build_datasource_payload(
    name: str, connection_config_json: str, scan_interval: int = 86400
) -> dict:
    """Build the standard datasource payload from connection config JSON."""
    try:
        connection = json.loads(connection_config_json)
    except json.JSONDecodeError as e:
        raise ValueError(f"Invalid connection_config JSON: {e}")
    return {
        "apiVersion": "v1",
        "metadata": {"name": name},
        "config": {
            "connection": connection,
            "profiler": {"enabled": True, "scanInterval": scan_interval},
        },
    }


def test_datasource_connection(
    workspace_name_or_uuid: str,
    name: str,
    connection_config_json: str,
    scan_interval: int = 86400,
) -> str:
    """Test a datasource connection before creating it."""
    workspace_uuid = _resolve_workspace_uuid(workspace_name_or_uuid)
    payload = _build_datasource_payload(name, connection_config_json, scan_interval)
    resp = api_post(f"/api/v1/ws/{workspace_uuid}/sources/inspection", payload)

    overall = resp.get("connectionStatus", "unknown")
    lines = [f"Connection test: {overall.upper()}"]

    lines.append(f"  Host:        {resp.get('hostConnectionStatus', '(unknown)')}")
    lines.append(f"  Credentials: {resp.get('credentialStatus', '(unknown)')}")
    lines.append(f"  Database:    {resp.get('databaseConnectionStatus', '(unknown)')}")

    if resp.get("latency") is not None:
        lines.append(f"  Latency:     {resp['latency']:.3f}s")

    schemas = resp.get("schemas", [])
    if schemas:
        lines.append(f"  Schemas:     {', '.join(schemas)}")

    if overall != "success" and resp.get("stacktrace"):
        # Show first line of stacktrace only — enough to diagnose
        first_line = resp["stacktrace"].strip().splitlines()[-1][:300]
        lines.append(f"  Error:       {first_line}")

    return "\n".join(lines)


def create_datasource(
    workspace_name_or_uuid: str,
    name: str,
    connection_config_json: str,
    scan_interval: int = 86400,
) -> str:
    """Create a new datasource in a workspace."""
    workspace_uuid = _resolve_workspace_uuid(workspace_name_or_uuid)
    payload = _build_datasource_payload(name, connection_config_json, scan_interval)
    resp = api_post(f"/api/v1/ws/{workspace_uuid}/sources/", payload)

    meta = resp.get("metadata", {})
    cfg = resp.get("config", {})
    conn = cfg.get("connection", {})

    lines = [
        "Datasource created successfully.",
        f"Name:          {meta.get('name', '')}",
        f"UUID:          {meta.get('uuid', '')}",
        f"Type:          {conn.get('type', '')}",
        f"Live:          {cfg.get('isLive', '')}",
    ]
    return "\n".join(lines)
