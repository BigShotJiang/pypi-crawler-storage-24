"""
MCP tools for Lightup integrations.
"""

from lightup_ai.tools.client import api_get
from lightup_ai.tools.metrics import _resolve_workspace_uuid

# Sensitive config fields that should never be shown
_SENSITIVE = {"password", "apiKey", "webHookUrl", "token"}


def list_integrations(workspace_name_or_uuid: str) -> str:
    """List all integrations in a workspace."""
    workspace_uuid = _resolve_workspace_uuid(workspace_name_or_uuid)
    integrations = api_get(f"/api/v1/ws/{workspace_uuid}/integrations/")

    if not integrations:
        return "No integrations found in this workspace."

    lines = [f"Found {len(integrations)} integration(s):\n"]
    for intg in integrations:
        meta = intg.get("metadata", {})
        cfg = intg.get("config", {})
        status = intg.get("status", {})

        intg_type = cfg.get("type", "")
        lines.append(f"  Name:       {meta.get('name', '')}")
        lines.append(f"  UUID:       {meta.get('uuid', '')}")
        lines.append(f"  Type:       {intg_type}")
        lines.append(f"  Mode:       {cfg.get('mode', '')}")
        lines.append(f"  Timezone:   {cfg.get('timezone', '')}")
        lines.append(f"  Health:     {status.get('runStatus', '(unknown)')}")
        if status.get("runStatusMessage"):
            lines.append(f"  Error:      {status['runStatusMessage']}")

        # Type-specific non-sensitive details
        if intg_type == "email":
            emails = cfg.get("emailAddressList", [])
            lines.append(f"  Recipients: {', '.join(emails)}")
        elif intg_type == "slack":
            lines.append("  Webhook:    <redacted>")
        elif intg_type == "servicenow":
            lines.append(f"  Host:       {cfg.get('host', '')}")
            lines.append(f"  Username:   {cfg.get('username', '')}")
        elif intg_type == "opsgenie":
            lines.append(f"  Instance:   {cfg.get('instanceUrl', '')}")
            lines.append(f"  Priority:   {cfg.get('priority', '')}")

        owner = meta.get("ownedBy", {})
        if owner.get("email"):
            lines.append(f"  Owner:      {owner['email']}")
        lines.append("")

    return "\n".join(lines).strip()
