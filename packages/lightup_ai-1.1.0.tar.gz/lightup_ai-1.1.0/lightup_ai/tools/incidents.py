"""
MCP tools for Lightup incidents.
"""

import datetime

from lightup_ai.tools.client import api_get
from lightup_ai.tools.metrics import _resolve_workspace_uuid

STATUS_LABELS = {
    1: "UNVIEWED",
    2: "VIEWED",
    3: "REJECTED",
    4: "SUBMITTED",
    5: "CLOSED",
}

DIRECTION_LABELS = {
    1: "UP",
    -1: "DOWN",
    0: "NEUTRAL",
}


def _fmt_ts(ts) -> str:
    """Format a Unix timestamp to a human-readable UTC string."""
    if not ts:
        return ""
    try:
        return datetime.datetime.fromtimestamp(float(ts), tz=datetime.UTC).strftime(
            "%Y-%m-%d %H:%M UTC"
        )
    except (ValueError, TypeError, OSError):
        return str(ts)


def _resolve_monitor_info(
    workspace_uuid: str, filter_uuid: str
) -> tuple[str, str, str]:
    """
    Fetch monitor name, metric name, and datasource name from the monitor details endpoint.
    Returns (monitor_name, metric_name, source_name).
    """
    monitor_name = filter_uuid
    metric_name = ""
    source_name = ""
    try:
        m = api_get(f"/api/v1/ws/{workspace_uuid}/monitors/{filter_uuid}")
        if m:
            meta = m.get("metadata", {})
            monitor_name = meta.get("name") or filter_uuid
            metric_name = meta.get("metricName", "")
            source_name = meta.get("sourceName", "")
    except Exception as e:
        from lightup_ai.tools.client import _log

        _log(f"could not resolve monitor {filter_uuid}: {e}")
    return monitor_name, metric_name, source_name


def list_incidents(workspace_name_or_uuid: str) -> str:
    """List recent incidents in a workspace."""
    workspace_uuid = _resolve_workspace_uuid(workspace_name_or_uuid)
    resp = api_get(f"/api/v0/ws/{workspace_uuid}/incidents/")

    incidents = resp.get("data", [])
    meta = resp.get("metadata", {})
    ref = resp.get("ref", {})

    filter_map = ref.get("filterMap", {})
    stream_map = ref.get("streamMap", {})

    if not incidents:
        return "No incidents found in this workspace."

    lines = [
        f"Found {meta.get('total', len(incidents))} incident(s): "
        f"{meta.get('unread', 0)} unread, "
        f"{meta.get('accepted', 0)} accepted\n"
    ]

    for inc in incidents:
        filter_uuid = inc.get("filter_uuid", "")

        # Try filterMap first (cheap); fall back to monitor API if name not resolved
        monitor_info = filter_map.get(filter_uuid, {})
        monitor_name = monitor_info.get("name") or ""
        streams = monitor_info.get("streams", [])
        metric_name = stream_map.get(streams[0], {}).get("name", "") if streams else ""

        if not monitor_name:
            monitor_name, metric_name_api, _ = _resolve_monitor_info(
                workspace_uuid, filter_uuid
            )
            if not metric_name:
                metric_name = metric_name_api

        status_int = inc.get("status", 0)
        direction_raw = inc.get("direction", "")

        lines.append(f"  ID:          {inc.get('id', '')}")
        lines.append(f"  UUID:        {inc.get('uuid', '')}")
        lines.append(f"  Monitor:     {monitor_name}")
        if metric_name:
            lines.append(f"  Metric:      {metric_name}")
        lines.append(f"  Type:        {inc.get('incident_type', '')}")
        lines.append(f"  Status:      {STATUS_LABELS.get(status_int, str(status_int))}")
        lines.append(
            f"  Direction:   {DIRECTION_LABELS.get(direction_raw, str(direction_raw))}"
        )
        lines.append(f"  Impact:      {inc.get('impact', '')}")
        lines.append(f"  Start:       {_fmt_ts(inc.get('start_ts'))}")
        end_ts = inc.get("end_ts")
        lines.append(
            f"  End:         {_fmt_ts(end_ts) if end_ts else '(ongoing)' if inc.get('ongoing') else ''}"
        )
        slice_val = inc.get("slice")
        if slice_val:
            lines.append(f"  Slice:       {slice_val}")
        lines.append("")

    return "\n".join(lines).strip()


def get_incident(workspace_name_or_uuid: str, incident_uuid: str) -> str:
    """Get details for a specific incident by UUID."""
    workspace_uuid = _resolve_workspace_uuid(workspace_name_or_uuid)

    inc = api_get(f"/api/v0/ws/{workspace_uuid}/incidents/{incident_uuid}")
    if not inc or "uuid" not in inc:
        return f"Incident '{incident_uuid}' not found in workspace."

    filter_uuid = inc.get("filter_uuid", "")
    monitor_name, metric_name, source_name = _resolve_monitor_info(
        workspace_uuid, filter_uuid
    )

    status_int = inc.get("status", 0)
    direction_raw = inc.get("direction", "")

    lines = [
        f"ID:            {inc.get('id', '')}",
        f"UUID:          {inc.get('uuid', '')}",
        f"Monitor:       {monitor_name}",
        f"Monitor UUID:  {filter_uuid}",
        f"Metric:        {metric_name or '(none)'}",
        f"Datasource:    {source_name or '(unknown)'}",
        f"Type:          {inc.get('incident_type', '')}",
        f"Status:        {STATUS_LABELS.get(status_int, str(status_int))}",
        f"Direction:     {DIRECTION_LABELS.get(direction_raw, str(direction_raw))}",
        f"Impact:        {inc.get('impact', '')}",
        f"Reason:        {inc.get('reason', '')}",
        f"Start:         {_fmt_ts(inc.get('start_ts'))}",
        f"End:           {_fmt_ts(inc.get('end_ts')) if inc.get('end_ts') else '(ongoing)' if inc.get('ongoing') else ''}",
        f"Closed:        {_fmt_ts(inc.get('close_ts'))}",
    ]

    slice_val = inc.get("slice")
    if slice_val:
        lines.append(f"Slice:         {slice_val}")

    return "\n".join(lines)
