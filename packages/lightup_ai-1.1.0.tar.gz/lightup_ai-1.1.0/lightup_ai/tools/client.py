"""
Lightup API client — shared HTTP client for all tools.
Exchanges refresh token for Bearer access token, caching it until near-expiry.
"""

import threading
import time
from collections import Counter

import httpx
from lightup_ai.config import load_config

# Thread-safe lock for shared state
_lock = threading.Lock()
_verbose = False
_tool_usage: Counter = Counter()

# Token cache
_cached_token: str | None = None
_token_expires_at: float = 0.0  # Unix timestamp


def set_verbose(enabled: bool) -> None:
    global _verbose
    with _lock:
        _verbose = enabled


def track_tool(name: str) -> None:
    with _lock:
        _tool_usage[name] += 1


def get_tool_usage() -> Counter:
    with _lock:
        return _tool_usage.copy()


def reset_tool_usage() -> None:
    with _lock:
        _tool_usage.clear()


def _log(msg: str) -> None:
    if _verbose:
        print(f"  [api] {msg}", flush=True)


def _get_access_token(base_url: str, refresh_token: str) -> str:
    """Exchange refresh token for a Bearer access token, with caching."""
    global _cached_token, _token_expires_at

    with _lock:
        # Reuse cached token if still valid (with 5 min safety buffer)
        if _cached_token and time.time() < _token_expires_at:
            return _cached_token

        resp = httpx.post(
            f"{base_url}/api/v1/token/refresh/",
            json={"refresh": refresh_token},
            timeout=10,
        )
        resp.raise_for_status()
        try:
            data = resp.json()
        except Exception:
            raise RuntimeError("Token refresh returned non-JSON response.")
        access_token = data.get("access")
        if not access_token:
            raise RuntimeError("Token refresh failed — check your refresh token.")
        # Cache for 50 minutes (tokens typically expire in 60 min)
        _cached_token = f"Bearer {access_token}"
        _token_expires_at = time.time() + 50 * 60
        return _cached_token


def invalidate_token() -> None:
    """Force next API call to re-fetch the access token."""
    global _cached_token, _token_expires_at
    with _lock:
        _cached_token = None
        _token_expires_at = 0.0


def get_auth_headers() -> tuple[str, dict]:
    """Return (base_url, headers) with a cached Bearer token."""
    config = load_config()
    if not config or not config.host or not config.refresh_token:
        raise RuntimeError("Lightup not configured. Run: lightup-ai start")

    base_url = config.host.rstrip("/")
    bearer = _get_access_token(base_url, config.refresh_token)
    headers = {
        "accept": "application/json",
        "content-type": "application/json",
        "authorization": bearer,
    }
    return base_url, headers


def _parse_json(resp: httpx.Response) -> dict:
    """Parse JSON from response, raising a clear error on failure."""
    try:
        return resp.json()
    except Exception:
        raise RuntimeError(
            f"API returned non-JSON response (status {resp.status_code}): {resp.text[:200]}"
        )


def api_get(path: str) -> dict:
    """GET {host}{path} with a Bearer token and return parsed JSON."""
    base_url, headers = get_auth_headers()
    _log(f"GET {path}")
    resp = httpx.get(
        f"{base_url}{path}", headers=headers, timeout=15, follow_redirects=True
    )
    _log(f"→ {resp.status_code}")
    resp.raise_for_status()
    return _parse_json(resp)


def api_post(path: str, payload: dict) -> dict:
    """POST {host}{path} with a Bearer token and return parsed JSON."""
    base_url, headers = get_auth_headers()
    _log(f"POST {path}")
    resp = httpx.post(
        f"{base_url}{path}",
        json=payload,
        headers=headers,
        timeout=15,
        follow_redirects=True,
    )
    _log(f"→ {resp.status_code}")
    resp.raise_for_status()
    return _parse_json(resp)
