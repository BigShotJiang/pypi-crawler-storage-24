"""
MCP tools for Lightup workspaces.
"""

from lightup_ai.tools.client import api_get, api_post


def list_workspaces() -> str:
    """List all workspaces the user has access to."""
    data = api_get("/api/v1/workspaces")
    workspaces = data.get("data", [])
    if not workspaces:
        return "No workspaces found."

    lines = [f"Found {len(workspaces)} workspace(s):\n"]
    for ws in workspaces:
        lines.append(f"  Name:        {ws['name']}")
        lines.append(f"  UUID:        {ws['uuid']}")
        if ws.get("description"):
            lines.append(f"  Description: {ws['description']}")
        lines.append(f"  Active:      {ws['active']}")
        lines.append("")

    return "\n".join(lines).strip()


def create_workspace(name: str, description: str = "") -> str:
    """Create a new workspace."""
    payload = {"name": name}
    if description:
        payload["description"] = description
    data = api_post("/api/v1/workspaces/", payload)
    ws = data.get("data") or data
    if not ws:
        return "Workspace creation failed — no data returned."

    lines = [
        "Workspace created successfully.",
        f"Name:        {ws.get('name', '')}",
        f"UUID:        {ws.get('uuid', '')}",
        f"Description: {ws.get('description') or '(none)'}",
        f"Active:      {ws.get('active', '')}",
    ]
    return "\n".join(lines)


def get_workspace(workspace_uuid: str) -> str:
    """Get details for a specific workspace by UUID."""
    data = api_get(f"/api/v1/workspaces/{workspace_uuid}")
    ws = data.get("data") or data
    if not ws:
        return f"Workspace {workspace_uuid} not found."

    lines = [
        f"Name:        {ws['name']}",
        f"UUID:        {ws['uuid']}",
        f"Description: {ws.get('description') or '(none)'}",
        f"Active:      {ws['active']}",
        f"Metric approval:  {ws.get('config', {}).get('enableApprovals', {}).get('metricApproval', '(unknown)')}",
        f"Monitor approval: {ws.get('config', {}).get('enableApprovals', {}).get('monitorApproval', '(unknown)')}",
    ]
    return "\n".join(lines)
