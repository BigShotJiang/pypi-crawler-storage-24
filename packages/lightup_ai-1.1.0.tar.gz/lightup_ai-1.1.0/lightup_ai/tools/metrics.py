"""
MCP tools for Lightup metrics.
"""

from lightup_ai.tools.client import _log, api_get


def _is_uuid(s: str) -> bool:
    """Return True if s looks like a UUID (36 chars containing hyphens)."""
    return len(s) == 36 and "-" in s


def search_metric(metric_name: str) -> str:
    """Search for a metric by name across all workspaces."""
    workspaces = api_get("/api/v1/workspaces/").get("data", [])
    search = metric_name.lower()
    found = []

    for ws in workspaces:
        ws_uuid = ws["uuid"]
        try:
            metrics = api_get(f"/api/v1/ws/{ws_uuid}/metrics/")
            for m in metrics:
                meta = m.get("metadata", {})
                if search in meta.get("name", "").lower():
                    found.append((ws["name"], ws_uuid, m))
        except Exception as e:
            _log(f"skipping workspace '{ws['name']}': {e}")
            continue

    if not found:
        return f"No metric found with name '{metric_name}' across all workspaces."

    lines = [f"Found {len(found)} match(es) for '{metric_name}':\n"]
    for ws_name, ws_uuid, m in found:
        meta = m.get("metadata", {})
        cfg = m.get("config", {})
        status = m.get("status", {})
        config_type = cfg.get("configType", "")
        agg = cfg.get("aggregation") or {}
        table = cfg.get("table") or {}
        src_tbl = (cfg.get("sourceTable") or {}).get("table", {})

        lines.append(f"  Workspace:     {ws_name}")
        lines.append(f"  Name:          {meta.get('name', '')}")
        lines.append(f"  UUID:          {meta.get('uuid', '')}")
        lines.append(f"  Config type:   {config_type}")
        lines.append(f"  Run status:    {status.get('runStatus', '')}")
        lines.append(f"  Monitor count: {meta.get('monitorCount', 0)}")
        if config_type == "fullCompareMetricConfig":
            tgt_tbl = (cfg.get("targetTable") or {}).get("table", {})
            lines.append(
                f"  Source table:  {src_tbl.get('schemaName', '')}.{src_tbl.get('tableName', '')}"
            )
            lines.append(
                f"  Target table:  {tgt_tbl.get('schemaName', '')}.{tgt_tbl.get('tableName', '')}"
            )
            lines.append(f"  Compare type:  {cfg.get('compareType', '')}")
        else:
            lines.append(
                f"  Table:         {table.get('schemaName', '')}.{table.get('tableName', '')}"
            )
            lines.append(
                f"  Aggregation:   {agg.get('type', '')} / {agg.get('aggregationWindow', '')}"
            )
        if status.get("runStatusMessage"):
            lines.append(f"  Status msg:    {status['runStatusMessage'][:200]}")
        lines.append("")

    return "\n".join(lines).strip()


def list_metrics(workspace_name_or_uuid: str) -> str:
    """List all metrics in a workspace. Workspace can be name or UUID."""
    workspace_uuid = _resolve_workspace_uuid(workspace_name_or_uuid)
    metrics = api_get(f"/api/v1/ws/{workspace_uuid}/metrics/")
    if not metrics:
        return "No metrics found in this workspace."

    lines = [f"Found {len(metrics)} metric(s):\n"]
    for m in metrics:
        meta = m.get("metadata", {})
        cfg = m.get("config", {})
        status = m.get("status", {})
        table = cfg.get("table", {})

        lines.append(f"  Name:       {meta.get('name', '(unnamed)')}")
        lines.append(f"  UUID:       {meta.get('uuid', '')}")
        lines.append(
            f"  Type:       {cfg.get('dimension', '')} / {(cfg.get('aggregation') or {}).get('type', '')}"
        )
        if table:
            lines.append(
                f"  Table:      {table.get('schemaName', '')}.{table.get('tableName', '')}"
            )
        lines.append(f"  Status:     {status.get('runStatus', '')}")
        lines.append(f"  Monitors:   {meta.get('monitorCount', 0)}")
        lines.append("")

    return "\n".join(lines).strip()


def _resolve_workspace_uuid(workspace_name_or_uuid: str) -> str:
    """Return workspace UUID — accepts either UUID or name."""
    # If it looks like a UUID, use it directly
    if _is_uuid(workspace_name_or_uuid):
        return workspace_name_or_uuid
    # Otherwise look up by name
    workspaces = api_get("/api/v1/workspaces/").get("data", [])
    search = workspace_name_or_uuid.lower()
    ws = next(
        (w for w in workspaces if w["name"].lower() == search),
        None,
    )
    if not ws:
        # Try partial match
        ws = next(
            (w for w in workspaces if search in w["name"].lower()),
            None,
        )
    if not ws:
        raise ValueError(f"Workspace '{workspace_name_or_uuid}' not found.")
    return ws["uuid"]


def get_metric(workspace_name_or_uuid: str, metric_name_or_uuid: str) -> str:
    """Get details for a specific metric by name or UUID. Workspace can be name or UUID."""
    workspace_uuid = _resolve_workspace_uuid(workspace_name_or_uuid)
    metrics = api_get(f"/api/v1/ws/{workspace_uuid}/metrics/")

    search = metric_name_or_uuid.lower()
    summary = next(
        (
            m
            for m in metrics
            if m.get("metadata", {}).get("uuid", "").lower() == search
            or m.get("metadata", {}).get("name", "").lower() == search
        ),
        None,
    )

    if not summary:
        return f"Metric '{metric_name_or_uuid}' not found in workspace."

    m = summary  # list API already returns full metric details

    meta = m.get("metadata", {})
    cfg = m.get("config", {})
    status = m.get("status", {})
    config_type = cfg.get("configType", "")

    lines = [
        f"Name:          {meta.get('name', '')}",
        f"UUID:          {meta.get('uuid', '')}",
        f"Description:   {meta.get('description') or '(none)'}",
        f"Dimension:     {cfg.get('dimension', '')}",
        f"Config type:   {config_type}",
        f"Run status:    {status.get('runStatus', '')}",
        f"Monitor count: {meta.get('monitorCount', 0)}",
        f"Mode:          {m.get('mode', '')}",
        f"Creation type: {meta.get('creationType', '')}",
    ]

    # Full compare metric
    if config_type == "fullCompareMetricConfig":
        src = cfg.get("sourceTable", {})
        tgt = cfg.get("targetTable", {})
        src_tbl = src.get("table", {})
        tgt_tbl = tgt.get("table", {})
        lines += [
            f"Compare type:  {cfg.get('compareType', '')}",
            f"Query scope:   {cfg.get('queryScope', '')}",
            f"Source table:  {src_tbl.get('schemaName', '')}.{src_tbl.get('tableName', '')}",
            f"Target table:  {tgt_tbl.get('schemaName', '')}.{tgt_tbl.get('tableName', '')}",
            f"Value columns: {', '.join(src.get('valueColumns', []))}",
            f"Slice columns: {', '.join(src.get('sliceByColumns', []))}",
        ]
    else:
        # Regular aggregation metric
        table = cfg.get("table") or {}
        agg = cfg.get("aggregation") or {}
        lines += [
            f"Table:         {table.get('schemaName', '')}.{table.get('tableName', '')}",
            f"Aggregation:   {agg.get('type', '')} / window: {agg.get('aggregationWindow', '')}",
        ]

    if status.get("runStatusMessage"):
        lines.append(f"Status msg:    {status['runStatusMessage'][:300]}")

    return "\n".join(lines)
