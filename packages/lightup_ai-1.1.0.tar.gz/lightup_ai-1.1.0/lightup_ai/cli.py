"""
Lightup AI CLI

Usage:
    lightup-ai          # guided setup + interactive chat
    lightup-ai -v       # with verbose logs
"""

import sys


def main():
    # Internal commands (not shown in help)
    if len(sys.argv) > 1 and sys.argv[1] == "start":
        sys.argv.pop(1)  # treat 'start' as default, strip it and continue

    if len(sys.argv) > 1 and sys.argv[1] == "serve":
        import uvicorn
        from lightup_ai.server import HOST, create_starlette_app
        from lightup_ai.setup_wizard import _kill_port, _port_in_use

        if "--stdio" in sys.argv:
            import asyncio

            from lightup_ai.server import app
            from mcp.server.stdio import stdio_server

            async def run():
                async with stdio_server() as (read, write):
                    await app.run(read, write, app.create_initialization_options())

            asyncio.run(run())
        else:
            port = 8765
            for i, arg in enumerate(sys.argv):
                if arg == "--port" and i + 1 < len(sys.argv):
                    port = int(sys.argv[i + 1])
            if _port_in_use(port):
                print(f"Port {port} already in use — stopping...", end=" ", flush=True)
                if _kill_port(port):
                    print("done")
                else:
                    print("failed")
                    sys.exit(1)
            uvicorn.run(create_starlette_app(), host=HOST, port=port)
        return

    # Public CLI
    import argparse

    parser = argparse.ArgumentParser(
        prog="lightup-ai",
        description=(
            "Lightup AI — agentic data quality assistant\n\n"
            "  lightup-ai start      guided setup + interactive chat\n"
            "  lightup-ai start -v   same with verbose logs\n"
        ),
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    parser.add_argument(
        "--verbose", "-v", action="store_true", help="Show detailed logs"
    )
    args = parser.parse_args()

    from lightup_ai.setup_wizard import run_setup

    run_setup(verbose=args.verbose)


if __name__ == "__main__":
    main()
