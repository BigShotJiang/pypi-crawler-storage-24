from avatar_yaml.models.avatar_metadata import (
    DataRecipient,
    DataSubject,
    DataType,
    SensitivityLevel,
)
from avatar_yaml.models.config import Config, ConfigParser
from avatar_yaml.models.parameters import OutputFormat, ReportLanguage, ReportType


def test_parse_metadata_with_pia() -> None:
    """Test parsing AvatarMetadata with PIA fields."""
    yaml_str = """---
kind: AvatarMetadata
metadata:
  name: test-metadata
spec:
  display_name: healthcare_data
  pia_metadata:
    datarecipient: internal
    data_type: health
    datasubject: patients
    sensitivity_level: High
"""
    config: Config = ConfigParser().parse_yaml(yaml_str)

    assert config.set_name == "healthcare_data"
    assert config.avatar_metadata is not None
    assert config.avatar_metadata.spec is not None
    assert config.avatar_metadata.spec.pia_metadata is not None
    pia = config.avatar_metadata.spec.pia_metadata
    assert pia.datarecipient == DataRecipient.INTERNAL
    assert pia.data_type == DataType.HEALTH
    assert pia.datasubject == DataSubject.PATIENTS
    assert pia.sensitivity_level == SensitivityLevel.HIGH


def test_parse_schema_basic() -> None:
    """Test parsing basic schema with tables and columns."""
    yaml_str = """---
kind: AvatarMetadata
metadata:
  name: test-metadata
spec:
  display_name: test_dataset
---
kind: AvatarSchema
metadata:
  name: schema
spec:
  tables:
  - name: users
    data:
      volume: input
      file: users.csv
    columns:
    - field: id
      type: int
      primary_key: true
    - field: foreign_key
      type: category
      identifier: true
    - field: age
      type: int
    - field: salary
      type: float
"""
    config: Config = ConfigParser().parse_yaml(yaml_str)

    assert "users" in config.tables
    users = config.tables["users"]
    assert users.name == "users"
    assert users.data is not None
    assert users.data.volume == "input"
    assert users.data.file == "users.csv"
    assert users.columns is not None
    assert len(users.columns) == 4
    # Check primary key column
    pk_col = [c for c in users.columns if c.primary_key][0]
    assert pk_col.field == "id"
    # Check for identifier column
    fk_cols = [c for c in users.columns if c.identifier]
    assert len(fk_cols) == 1
    assert fk_cols[0].field == "foreign_key"
    # Check types of columns
    age_col = [c for c in users.columns if c.field == "age"][0]
    assert age_col.type == "int"
    salary_col = [c for c in users.columns if c.field == "salary"][0]
    assert salary_col.type == "float"


def test_parse_avatarization_parameters_complete() -> None:
    """Test parsing avatarization parameters with all fields."""
    yaml_str = """---
kind: AvatarMetadata
metadata:
  name: test-metadata
spec:
  display_name: test_dataset
---
kind: AvatarSchema
metadata:
  name: schema
spec:
  tables:
  - name: users
    data:
      volume: input
      file: users.csv
    columns:
    - field: id
      type: int
      primary_key: true
---
kind: AvatarParameters
metadata:
  name: params
spec:
  schema: schema
  avatarization:
    users:
      k: 5
      ncp: 10
      use_categorical_reduction: true
      column_weights:
        id: 0.5
        name: 1.0
      exclude_variables:
        variable_names: [excluded_col]
        replacement_strategy: row_order
      imputation:
        method: knn
        k: 3
        training_fraction: 0.8
        return_data_imputed: false
  results:
    volume: output
"""
    config: Config = ConfigParser().parse_yaml(yaml_str)

    assert "users" in config.avatarization
    params = config.avatarization["users"]
    assert params.k == 5
    assert params.ncp == 10
    assert params.use_categorical_reduction is True
    assert params.column_weights == {"id": 0.5, "name": 1.0}
    assert params.exclude_variables is not None
    assert params.exclude_variables["variable_names"] == ["excluded_col"]
    assert params.exclude_variables["replacement_strategy"] == "row_order"
    assert params.imputation is not None
    assert params.imputation["method"] == "knn"
    assert params.imputation["k"] == 3
    assert params.imputation["training_fraction"] == 0.8
    assert params.imputation["return_data_imputed"] is False


def test_parse_time_series_parameters() -> None:
    """Test parsing time series parameters."""
    yaml_str = """---
kind: AvatarMetadata
metadata:
  name: test-metadata
spec:
  display_name: test_dataset
---
kind: AvatarSchema
metadata:
  name: schema
spec:
  tables:
  - name: timeseries_data
    data:
      volume: input
      file: ts.csv
    columns:
    - field: id
      type: int
      primary_key: true
---
kind: AvatarParameters
metadata:
  name: params
spec:
  schema: schema
  time_series:
    timeseries_data:
      projection:
        nf: 5
        type: fpca
      alignment:
        nb_points: 100
        method: mean
  results:
    volume: output
"""
    config: Config = ConfigParser().parse_yaml(yaml_str)

    assert "timeseries_data" in config.time_series
    params = config.time_series["timeseries_data"]
    assert params.projection is not None
    assert params.alignment is not None
    assert params.projection["nf"] == 5
    assert params.projection["projection_type"] == "fpca"
    assert params.alignment["nb_points"] == 100
    assert params.alignment["method"] == "mean"


def test_parse_privacy_metrics_parameters() -> None:
    """Test parsing privacy metrics parameters."""
    yaml_str = """---
kind: AvatarMetadata
metadata:
  name: test-metadata
spec:
  display_name: test_dataset
---
kind: AvatarSchema
metadata:
  name: schema
spec:
  tables:
  - name: users
    data:
      volume: input
      file: users.csv
    columns:
    - field: id
      type: int
      primary_key: true
---
kind: AvatarParameters
metadata:
  name: params
spec:
  schema: schema
  privacy_metrics:
    users:
      ncp: 10
      use_categorical_reduction: true
      known_variables: [age, gender]
      target: income
      quantile_threshold: 0.05
      column_weights:
        age: 1.0
        gender: 0.5
      exclude_variables:
        variable_names: [ssn]
        replacement_strategy: row_order
      imputation:
        method: mean
        training_fraction: 0.9
  results:
    volume: output
"""
    config: Config = ConfigParser().parse_yaml(yaml_str)

    assert "users" in config.privacy_metrics
    params = config.privacy_metrics["users"]
    assert params.ncp == 10
    assert params.use_categorical_reduction is True
    assert params.known_variables == ["age", "gender"]
    assert params.target == "income"
    assert params.quantile_threshold == 0.05
    assert params.column_weights == {"age": 1.0, "gender": 0.5}
    assert params.exclude_variables is not None
    assert params.exclude_variables["variable_names"] == ["ssn"]
    assert params.imputation is not None
    assert params.imputation["method"] == "mean"


def test_parse_signal_metrics_parameters() -> None:
    """Test parsing signal metrics parameters."""
    yaml_str = """---
kind: AvatarMetadata
metadata:
  name: test-metadata
spec:
  display_name: test_dataset
---
kind: AvatarSchema
metadata:
  name: schema
spec:
  tables:
  - name: sensors
    data:
      volume: input
      file: sensors.csv
    columns:
    - field: id
      type: int
      primary_key: true
---
kind: AvatarParameters
metadata:
  name: params
spec:
  schema: schema
  signal_metrics:
    sensors:
      ncp: 5
      use_categorical_reduction: false
      column_weights:
        sensor_a: 2.0
        sensor_b: 1.0
      exclude_variables:
        variable_names: [calibration]
        replacement_strategy: row_order
      imputation:
        method: knn
        k: 5
  results:
    volume: output
"""
    config: Config = ConfigParser().parse_yaml(yaml_str)

    assert "sensors" in config.signal_metrics
    params = config.signal_metrics["sensors"]
    assert params.ncp == 5
    assert params.use_categorical_reduction is False
    assert params.column_weights == {"sensor_a": 2.0, "sensor_b": 1.0}
    assert params.exclude_variables is not None
    assert params.exclude_variables["variable_names"] == ["calibration"]
    assert params.imputation is not None
    assert params.imputation["method"] == "knn"


def test_parse_avatarization_open_dp_parameters() -> None:
    """Test parsing OpenDP avatarization parameters."""
    yaml_str = """---
kind: AvatarMetadata
metadata:
  name: test-metadata
spec:
  display_name: test_dataset
---
kind: AvatarSchema
metadata:
  name: schema
spec:
  tables:
  - name: users
    data:
      volume: input
      file: users.csv
    columns:
    - field: id
      type: int
      primary_key: true
---
kind: AvatarParameters
metadata:
  name: params
spec:
  schema: schema
  avatarization_open_dp:
    users:
      epsilon: 1.5
      preprocess_budget_ratio: 0.8
      ncp: 3
      use_categorical_reduction: true
      column_weights:
        id: 1.0
      exclude_variables:
        variable_names: [sensitive]
        replacement_strategy: row_order
      imputation:
        method: knn
        k: 5
  results:
    volume: output
"""
    config: Config = ConfigParser().parse_yaml(yaml_str)

    assert "users" in config.avatarization_open_dp
    params = config.avatarization_open_dp["users"]
    assert params.epsilon == 1.5
    assert params.preprocess_budget_ratio == 0.8
    assert params.ncp == 3
    assert params.use_categorical_reduction is True
    assert params.column_weights == {"id": 1.0}
    assert params.exclude_variables is not None
    assert params.exclude_variables["variable_names"] == ["sensitive"]
    assert params.imputation is not None
    assert params.imputation["method"] == "knn"


def test_parse_avatarization_fast_dp_parameters() -> None:
    """Test parsing FastDP avatarization parameters."""
    yaml_str = """---
kind: AvatarMetadata
metadata:
  name: test-metadata
spec:
  display_name: test_dataset
---
kind: AvatarSchema
metadata:
  name: schema
spec:
  tables:
  - name: data
    data:
      volume: input
      file: data.csv
    columns:
    - field: id
      type: int
      primary_key: true
---
kind: AvatarParameters
metadata:
  name: params
spec:
  schema: schema
  avatarization_fast_dp:
    data:
      epsilon: 1.5
      mechanism: gmm
      gmm_n_components: 3
      histogram_n_bins: 20
      bounds_percentile: 5.0
      ncp: 2
      use_categorical_reduction: false
  results:
    volume: output
"""
    config: Config = ConfigParser().parse_yaml(yaml_str)

    assert "data" in config.avatarization_fast_dp
    params = config.avatarization_fast_dp["data"]
    assert params.epsilon == 1.5
    assert params.mechanism == "gmm"
    assert params.gmm_n_components == 3
    assert params.histogram_n_bins == 20
    assert params.bounds_percentile == 5.0
    assert params.ncp == 2
    assert params.use_categorical_reduction is False


def test_parse_schema_with_links() -> None:
    """Test that links are correctly parsed from YAML."""
    yaml_str = """---
kind: AvatarMetadata
metadata:
  name: test-metadata
spec:
  display_name: test_dataset
  pia_metadata:
    datarecipient: unknown
    data_type: unknown
    datasubject: unknown
    sensitivity_level: Undefined
---
kind: AvatarSchema
metadata:
  name: schema
spec:
  tables:
  - name: parent_table
    data:
      volume: input
      file: parent.csv
    columns:
    - field: id
      type: int
      primary_key: true
    - field: name
      type: category
    links:
    - field: id
      to:
        table: child_table
        field: parent_id
      method: linear_sum_assignment
  - name: child_table
    data:
      volume: input
      file: child.csv
    columns:
    - field: child_id
      type: int
      primary_key: true
    - field: parent_id
      type: int
      identifier: true
    - field: value
      type: float
"""

    # Parse the YAML
    config: Config = ConfigParser().parse_yaml(yaml_str)

    # Verify tables were created
    assert "parent_table" in config.tables
    assert "child_table" in config.tables

    # Verify link was created
    parent_table = config.tables["parent_table"]
    assert parent_table.links is not None
    assert len(parent_table.links) == 1

    # Verify link details
    link = parent_table.links[0]
    assert link.field == "id"
    assert link.to.table == "child_table"
    assert link.to.field == "parent_id"
    assert link.method == "linear_sum_assignment"


def test_parse_multiple_parameter_types() -> None:
    """Test parsing multiple parameter types for different tables."""
    yaml_str = """---
kind: AvatarMetadata
metadata:
  name: test-metadata
spec:
  display_name: test_dataset
---
kind: AvatarSchema
metadata:
  name: schema
spec:
  tables:
  - name: users
    data:
      volume: input
      file: users.csv
    columns:
    - field: id
      type: int
      primary_key: true
  - name: timeseries
    data:
      volume: input
      file: ts.csv
    columns:
    - field: id
      type: int
      primary_key: true
---
kind: AvatarParameters
metadata:
  name: params
spec:
  schema: schema
  avatarization:
    users:
      k: 5
      ncp: 10
  time_series:
    timeseries:
      projection:
        nf: 3
        type: fpca
      alignment:
        nb_points: 50
        method: mean
  results:
    volume: output
"""
    config: Config = ConfigParser().parse_yaml(yaml_str)
    assert len(config.tables) == 2
    assert "users" in config.tables
    assert "timeseries" in config.tables

    assert "users" in config.avatarization
    assert "timeseries" in config.time_series
    assert config.avatarization["users"].k == 5
    ts_params = config.time_series["timeseries"]
    assert ts_params.projection is not None
    assert ts_params.projection["nf"] == 3


def test_parse_report_parameters() -> None:
    """Test parsing report parameters documents."""
    yaml_str = """---
kind: AvatarMetadata
metadata:
  name: test-metadata
spec:
  display_name: test_dataset
---
kind: AvatarSchema
metadata:
  name: schema
spec:
  tables:
  - name: users
    data:
      volume: input
      file: users.csv
---
kind: AvatarReportParameters
metadata:
  name: report
spec:
  report_type: basic
  output_format: pdf
  language: en
---
kind: AvatarReportParameters
metadata:
  name: report_pia
spec:
  report_type: pia
  output_format: docx
  language: fr
"""
    config: Config = ConfigParser().parse_yaml(yaml_str)

    assert config.report is not None
    assert len(config.report) == 2
    assert config.report[ReportType.BASIC] == (OutputFormat.PDF, ReportLanguage.EN)
    assert config.report[ReportType.PIA] == (OutputFormat.DOCX, ReportLanguage.FR)


def test_parse_parameters_before_schema_document_order() -> None:
    """Test parsing works when AvatarParameters appears before AvatarSchema."""
    yaml_str = """---
kind: AvatarMetadata
metadata:
  name: test-metadata
spec:
  display_name: test_dataset
---
kind: AvatarParameters
metadata:
  name: params
spec:
  schema: schema
  avatarization:
    users:
      k: 5
      ncp: 10
  results:
    volume: output
---
kind: AvatarSchema
metadata:
  name: schema
spec:
  tables:
  - name: users
    data:
      volume: input
      file: users.csv
    columns:
    - field: id
      type: int
      primary_key: true
"""

    config: Config = ConfigParser().parse_yaml(yaml_str)

    assert "users" in config.tables
    assert "users" in config.avatarization
    assert config.avatarization["users"].k == 5
    assert config.avatarization["users"].ncp == 10


def test_extract_exclude_variables_helper() -> None:
    """Test _extract_exclude_variables helper method."""
    params = {
        "exclude_variables": {
            "variable_names": ["col1", "col2"],
            "replacement_strategy": "row_order",
        }
    }

    names, method = ConfigParser()._extract_exclude_variables(params)

    assert names == ["col1", "col2"]
    assert method == "row_order"


def test_extract_exclude_variables_empty() -> None:
    """Test _extract_exclude_variables with no exclude_variables."""
    params: dict[str, object] = {}

    names, method = ConfigParser()._extract_exclude_variables(params)

    assert names is None
    assert method is None


def test_extract_imputation_helper() -> None:
    """Test _extract_imputation helper method."""
    params = {
        "imputation": {
            "method": "knn",
            "k": 5,
            "training_fraction": 0.8,
            "return_data_imputed": True,
        }
    }

    method, k, training_frac, return_imputed = ConfigParser()._extract_imputation(params)

    assert method == "knn"
    assert k == 5
    assert training_frac == 0.8
    assert return_imputed is True


def test_extract_imputation_empty() -> None:
    """Test _extract_imputation with no imputation."""
    params: dict[str, object] = {}

    method, k, training_frac, return_imputed = ConfigParser()._extract_imputation(params)

    assert method is None
    assert k is None
    assert training_frac is None
    assert return_imputed is None


def test_extract_data_augmentation_helper() -> None:
    """Test _extract_data_augmentation helper method."""
    params = {
        "data_augmentation": {
            "augmentation_strategy": 2.0,
            "target_column": "income",
            "should_anonymize_original_table": True,
        }
    }

    strategy, target, anonymize = ConfigParser()._extract_data_augmentation(params)

    assert strategy == 2.0
    assert target == "income"
    assert anonymize is True


def test_extract_data_augmentation_empty() -> None:
    """Test _extract_data_augmentation with no data_augmentation."""
    params: dict[str, object] = {}

    strategy, target, anonymize = ConfigParser()._extract_data_augmentation(params)

    assert strategy is None
    assert target is None
    assert anonymize is None
