from pathlib import Path

from avatar_yaml.models.advice import AdviceType
from avatar_yaml.models.config import Config
from avatar_yaml.models.parameters import OutputFormat, ReportLanguage, ReportType
from avatar_yaml.models.schema import ColumnType


def test_roundtrip_with_all_avatarization_parameters():
    """Test round-trip with complete avatarization parameters."""
    config1 = Config(set_name="full_params")
    config1.create_table(
        "data",
        "input",
        "data.csv",
        primary_key="id",
        types={"id": ColumnType.INT, "value": ColumnType.NUMERIC},
    )
    config1.create_avatarization_parameters(
        "data",
        k=5,
        ncp=10,
        use_categorical_reduction=True,
        column_weights={"value": 2.0},
        exclude_variable_names=["sensitive_col"],
        exclude_variable_method="row_order",
        imputation_method="knn",
        imputation_k=3,
        imputation_training_fraction=0.8,
        imputation_return_data_imputed=False,
    )

    yaml1 = config1.get_yaml()
    config2 = Config.from_yaml(yaml1)
    yaml2 = config2.get_yaml()

    assert yaml1 == yaml2
    assert config2.set_name == "full_params"
    assert config1 == config2


def test_roundtrip_with_time_series():
    """Test round-trip with time series parameters."""
    config1 = Config(set_name="ts_data")
    config1.create_table(
        "signals",
        "input",
        "signals.csv",
        primary_key="id",
        time_series_time="timestamp",
        types={"id": ColumnType.INT, "timestamp": ColumnType.NUMERIC},
    )
    config1.create_time_series_parameters(
        "signals",
        nf=5,
        projection_type="fpca",
        nb_points=100,
        method="mean",
    )

    yaml1 = config1.get_yaml()
    config2 = Config.from_yaml(yaml1)
    yaml2 = config2.get_yaml()

    assert yaml1 == yaml2
    assert config1 == config2


def test_roundtrip_with_open_dp():
    """Test round-trip with OpenDP avatarization parameters."""
    config1 = Config(set_name="open_dp_test")
    config1.create_table(
        "data",
        "input",
        "data.csv",
        primary_key="id",
        types={"id": ColumnType.INT},
    )
    config1.create_avatarization_open_dp_parameters(
        "data",
        epsilon=1.5,
        preprocess_budget_ratio=0.8,
        ncp=3,
        use_categorical_reduction=True,
    )

    yaml1 = config1.get_yaml()
    config2 = Config.from_yaml(yaml1)
    yaml2 = config2.get_yaml()

    assert yaml1 == yaml2
    assert config1 == config2


def test_roundtrip_with_fast_dp():
    """Test round-trip with FastDP avatarization parameters."""
    config1 = Config(set_name="fast_dp_test")
    config1.create_table(
        "data",
        "input",
        "data.csv",
        primary_key="id",
        types={"id": ColumnType.INT},
    )
    config1.create_avatarization_fast_dp_parameters(
        "data",
        epsilon=1.5,
        mechanism="gmm",
        gmm_n_components=3,
        histogram_n_bins=20,
        bounds_percentile=5.0,
        ncp=2,
    )

    yaml1 = config1.get_yaml()
    config2 = Config.from_yaml(yaml1)
    yaml2 = config2.get_yaml()

    assert yaml1 == yaml2
    assert config1 == config2


def test_roundtrip_preserves_seed():
    """Test that seed and other global parameters are preserved."""
    config1 = Config(set_name="with_seed", seed=42, max_distribution_plots=10)
    config1.create_table("data", "input", "data.csv", primary_key="id")
    config1.create_avatarization_parameters("data", k=5, ncp=10)

    yaml1 = config1.get_yaml()
    config2 = Config.from_yaml(yaml1)
    yaml2 = config2.get_yaml()

    assert yaml1 == yaml2
    assert config1 == config2


def test_roundtrip_with_report_parameters() -> None:
    """Test round-trip with report parameters."""
    config1 = Config(set_name="with_reports")
    config1.create_table("data", "input", "data.csv", primary_key="id")
    config1.create_avatarization_parameters("data", k=5)
    config1.create_report(
        report_type=ReportType.BASIC,
        output_format=OutputFormat.PDF,
        language=ReportLanguage.EN,
    )
    config1.create_report(
        report_type=ReportType.PIA,
        output_format=OutputFormat.DOCX,
        language=ReportLanguage.FR,
    )

    yaml1 = config1.get_yaml()
    config2 = Config.from_yaml(yaml1)
    yaml2 = config2.get_yaml()

    assert yaml1 == yaml2
    assert config1 == config2


def test_parse_yaml_details():
    yaml_path = Path(__file__).parent.parent / "yaml_examples/multitable_test.yaml"

    yaml_content = yaml_path.read_text()
    config = Config.from_yaml(yaml_content)

    # Check metadata
    assert config.set_name == "tutorial_multitable"

    assert "patient" in config.tables
    assert "doctor" in config.tables
    assert "visit" in config.tables

    patient = config.tables["patient"]
    assert patient.individual_level is True
    assert len(patient.columns) == 5  # p_id, gender, height, age, weight

    pk_cols = [col for col in patient.columns if col.primary_key]
    assert len(pk_cols) == 1
    assert pk_cols[0].field == "p_id"

    for table in config.tables.values():
        if table.name == "patient" or table.name == "doctor":
            assert table.links

    assert len(config.avatarization) == 3  # patient, doctor, visit
    assert "patient" in config.avatarization
    assert "doctor" in config.avatarization
    assert "visit" in config.avatarization


def test_round_trip_with_real_yaml():
    """Test that parsing a yaml produces the same yaml when parsed back."""
    yaml_path = Path(__file__).parent.parent / "yaml_examples/multitable_test.yaml"

    yaml_content = yaml_path.read_text()
    config = Config.from_yaml(yaml_content)
    exported_yaml = config.get_yaml()

    assert yaml_content == exported_yaml


def test_roundtrip_with_advice() -> None:
    """Test that advice parameters survive a round-trip."""
    config1 = Config(set_name="with_advice")
    config1.create_table("data", "input", "data.csv", primary_key="id")
    config1.create_avatarization_parameters("data", k=5)
    config1.create_advice(advisor_type=[AdviceType.VARIABLES, AdviceType.PARAMETERS])

    yaml1 = config1.get_yaml()
    config2 = Config.from_yaml(yaml1)
    yaml2 = config2.get_yaml()

    assert yaml1 == yaml2
    assert config2.advice != {}
    assert config1 == config2
