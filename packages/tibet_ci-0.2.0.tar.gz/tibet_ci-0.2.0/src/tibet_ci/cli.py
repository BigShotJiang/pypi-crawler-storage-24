"""
tibet-ci CLI — Zero-Config CI/CD TIBET Integration.

Usage::

    tibet-ci info              Concept overview
    tibet-ci run [path]        Run full pipeline (auto-detect project)
    tibet-ci detect [path]     Detect project type only
    tibet-ci demo              Demo run with simulated project
    tibet-ci badge [path]      Generate badge status
    tibet-ci validate [path]   Quick project validation (no pipeline run)
    tibet-ci audit-line [path] One-liner: badge + exit code (CI/CD friendly)
    tibet-ci validate-demo     Demo all validators (project, AI, B2B)
"""

import argparse
import json
import sys
import tempfile
from pathlib import Path

from .detector import detect_project
from .runner import PipelineRunner, DEFAULT_STAGES
from .validator import QuickValidator, AIValidator, B2BValidator


def cmd_info(args: argparse.Namespace) -> int:
    print()
    print("=" * 64)
    print("  TIBET-CI — Zero-Config CI/CD TIBET Integration")
    print("=" * 64)
    print()
    print("The CI/CD Multiplier:")
    print("  One line in your pipeline config — TIBET audits everything.")
    print()
    print("  # .github/workflows/tibet.yml")
    print("  - uses: humotica/tibet-ci@v1")
    print()
    print("How it works:")
    print("  1. DETECT   Auto-detect language, build tool, test runner")
    print("  2. INSTALL  Install dependencies (pip/npm/cargo/go mod)")
    print("  3. LINT     Run linter (ruff/eslint/clippy/vet)")
    print("  4. TEST     Run tests (pytest/jest/cargo test/go test)")
    print("  5. AUDIT    TIBET compliance audit")
    print("  6. BUILD    Build package/binary")
    print("  7. REPORT   Generate badge + checksum rapport")
    print()
    print("Every stage = TIBET token:")
    print()
    print("  +--------------------------------------------------+")
    print("  | ERIN      | What ran: command, exit code, hash    |")
    print("  | ERAAN     | Previous stage token, dependencies    |")
    print("  | EROMHEEN  | CI platform, runner, commit, branch   |")
    print("  | ERACHTER  | Intent: 'CI pipeline stage: {name}'  |")
    print("  +--------------------------------------------------+")
    print()
    print("Supported projects:")
    print("  Python    pyproject.toml / setup.py    pytest + ruff")
    print("  Node      package.json                 jest + eslint")
    print("  Rust      Cargo.toml                   cargo test + clippy")
    print("  Go        go.mod                       go test + go vet")
    print("  Java      pom.xml / build.gradle       mvn/gradle test")
    print()
    print("Supported CI platforms:")
    print("  GitHub Actions, GitLab CI, Bitbucket Pipelines, Jenkins")
    print()
    print("=" * 64)
    return 0


def cmd_detect(args: argparse.Namespace) -> int:
    path = args.path or "."
    info = detect_project(path)

    if args.json:
        print(json.dumps(info.to_dict(), indent=2))
    else:
        print()
        print(f"  Project Detection: {Path(path).resolve()}")
        print(f"  {'─' * 50}")
        print(f"  Language:        {info.language}")
        print(f"  Build tool:      {info.build_tool}")
        print(f"  Test command:    {info.test_command or '(none)'}")
        print(f"  Lint command:    {info.lint_command or '(none)'}")
        print(f"  Package manager: {info.package_manager}")
        print(f"  Source dir:      {info.source_dir}")
        print(f"  Config files:    {', '.join(info.config_files) or '(none)'}")
        print()

    return 0


def cmd_run(args: argparse.Namespace) -> int:
    path = args.path or "."
    stages = args.stages.split(",") if args.stages else None

    runner = PipelineRunner()
    result = runner.run(path, stages=stages)

    if args.json:
        print(json.dumps(result.to_dict(), indent=2))
    else:
        print()
        print(f"  TIBET CI Pipeline — {Path(path).resolve()}")
        print(f"  Platform: {runner.platform}")
        print(f"  {'─' * 56}")
        print()

        for stage in result.stages:
            status = "PASS" if stage.passed else "FAIL"
            marker = "[+]" if stage.passed else "[X]"
            print(f"  {marker} {stage.name:<16} {status}  ({stage.duration_ms:.0f}ms)")
            if not stage.passed and stage.output_summary:
                # Show first line of failure output
                first_line = stage.output_summary.split("\n")[0][:60]
                print(f"      {first_line}")

        print()
        print(f"  {'─' * 56}")
        print(f"  Stages:     {result.passed} passed, {result.failed} failed")
        print(f"  Total time: {result.total_time:.0f}ms")
        print(f"  Badge:      {result.badge_status}")
        print(f"  Checksum:   {result.checksum}")
        print(f"  TIBET chain: {result.tibet_chain_length} tokens")
        print()

    return 0 if result.badge_status != "FAILING" else 1


def cmd_badge(args: argparse.Namespace) -> int:
    path = args.path or "."

    runner = PipelineRunner()
    # Run only detect + audit for quick badge
    result = runner.run(path, stages=["detect", "audit"])

    if args.json:
        data = {
            "badge_status": result.badge_status,
            "checksum": result.checksum,
            "passed": result.passed,
            "failed": result.failed,
        }
        print(json.dumps(data, indent=2))
    else:
        print()
        print(f"  TIBET Badge: {result.badge_status}")
        print(f"  Checksum:    {result.checksum}")
        print()

    return 0


def cmd_demo(args: argparse.Namespace) -> int:
    print()
    print("  TIBET CI Demo — Simulated Python Project")
    print("  " + "=" * 52)
    print()

    # Create a temporary project to demo against
    with tempfile.TemporaryDirectory(prefix="tibet-ci-demo-") as tmpdir:
        tmp = Path(tmpdir)

        # Create minimal Python project
        (tmp / "pyproject.toml").write_text(
            '[build-system]\nrequires = ["hatchling"]\n'
            'build-backend = "hatchling.build"\n\n'
            '[project]\nname = "demo-project"\nversion = "0.1.0"\n'
        )
        (tmp / "src").mkdir()
        (tmp / "src" / "demo.py").write_text(
            '"""Demo module."""\n\ndef hello() -> str:\n    return "Hello from TIBET CI"\n'
        )
        (tmp / "LICENSE").write_text("MIT License\n")
        (tmp / "README.md").write_text("# Demo Project\n")
        (tmp / ".gitignore").write_text("__pycache__/\n*.pyc\n")

        print("  Created simulated Python project:")
        print(f"    pyproject.toml  (hatchling)")
        print(f"    src/demo.py")
        print(f"    LICENSE, README.md, .gitignore")
        print()

        # Run detect stage
        info = detect_project(tmp)
        print(f"  [1/7] DETECT")
        print(f"    Language:  {info.language}")
        print(f"    Build:     {info.build_tool}")
        print(f"    Test:      {info.test_command}")
        print(f"    Lint:      {info.lint_command}")
        print()

        # Run full pipeline
        runner = PipelineRunner()
        result = runner.run(tmp, stages=["detect", "audit", "report"])

        print(f"  Running pipeline stages...")
        print()

        for stage in result.stages:
            status = "PASS" if stage.passed else "FAIL"
            marker = "[+]" if stage.passed else "[X]"
            print(f"  {marker} {stage.name:<16} {status}  ({stage.duration_ms:.1f}ms)")

        print()
        print(f"  {'─' * 52}")
        print(f"  Badge:      {result.badge_status}")
        print(f"  Checksum:   {result.checksum}")
        print(f"  Chain:      {result.tibet_chain_length} TIBET tokens")
        print()

        # Show one token as example
        if runner.provenance.tokens:
            token = runner.provenance.tokens[0]
            print(f"  Example TIBET Token (first stage):")
            print(f"    token_id:     {token.token_id}")
            print(f"    stage:        {token.stage_name}")
            print(f"    content_hash: {token.content_hash}")
            print(f"    ERIN:         jis:ci:{token.stage_name}")
            print(f"    ERAAN:        parent={token.parent_id or '(root)'}")
            print(f"    EROMHEEN:     platform={runner.platform}")
            print(f"    ERACHTER:     {token.erachter.get('intent', '')}")
            print()

    if args.json:
        print(json.dumps(result.to_dict(), indent=2))

    return 0


def cmd_validate(args: argparse.Namespace) -> int:
    """Quick project validation — no pipeline run needed."""
    path = args.path or "."
    validator = QuickValidator()
    result = validator.validate_project(path)

    if args.json:
        print(json.dumps(result.to_dict(), indent=2))
    else:
        print()
        print(f"  TIBET Validate: {Path(path).resolve()}")
        print(f"  {'─' * 52}")
        for check in result.checks:
            marker = "[+]" if check["passed"] else "[X]"
            print(f"  {marker} {check['name']:<18} {check['detail']}")
        print(f"  {'─' * 52}")
        print(f"  Badge:    {result.badge}")
        print(f"  Passed:   {result.checks_passed}/{result.checks_passed + result.checks_failed}")
        print(f"  Checksum: {result.checksum}")
        print(f"  Time:     {result.duration_ms:.1f}ms")
        print()

    return 0 if result.valid else 1


def cmd_audit_line(args: argparse.Namespace) -> int:
    """One-liner audit — just badge + exit code."""
    path = args.path or "."
    validator = QuickValidator()
    badge, exit_code = validator.audit_line(path)

    if args.json:
        print(json.dumps({"badge": badge, "exit_code": exit_code}))
    else:
        print(badge)

    return exit_code


def cmd_validate_chain(args: argparse.Namespace) -> int:
    """Validate a TIBET chain from JSON file."""
    chain_file = Path(args.file)
    if not chain_file.exists():
        print(f"File not found: {chain_file}", file=sys.stderr)
        return 1

    chain_data = json.loads(chain_file.read_text())
    if not isinstance(chain_data, list):
        chain_data = [chain_data]

    validator = QuickValidator()
    result = validator.validate_chain(chain_data)

    if args.json:
        print(json.dumps(result.to_dict(), indent=2))
    else:
        print()
        print(f"  TIBET Chain Validation: {chain_file}")
        print(f"  {'─' * 52}")
        for check in result.checks:
            marker = "[+]" if check["passed"] else "[X]"
            print(f"  {marker} {check['name']:<18} {check['detail']}")
        print(f"  {'─' * 52}")
        print(f"  Badge:    {result.badge}")
        print(f"  Checksum: {result.checksum}")
        print()

    return 0 if result.valid else 1


def cmd_validate_demo(args: argparse.Namespace) -> int:
    """Demo all validators — project, AI pipeline, B2B transaction."""
    print()
    print("  TIBET-CI Validator Demo")
    print("  " + "=" * 52)
    print()

    # 1. Project validation
    print("  [1] Project Validation")
    print("  " + "-" * 30)
    with tempfile.TemporaryDirectory(prefix="tibet-ci-validate-") as tmpdir:
        tmp = Path(tmpdir)
        (tmp / "pyproject.toml").write_text('[project]\nname = "demo"\nversion = "0.1.0"\n')
        (tmp / "src").mkdir()
        (tmp / "src" / "main.py").write_text("print('hello')\n")
        (tmp / "LICENSE").write_text("MIT\n")
        (tmp / "README.md").write_text("# Demo\n")
        (tmp / ".gitignore").write_text("__pycache__/\n")

        v = QuickValidator()
        result = v.validate_project(tmp)
        for check in result.checks:
            marker = "[+]" if check["passed"] else "[X]"
            print(f"    {marker} {check['name']:<18} {check['detail']}")
        print(f"    Badge: {result.badge} ({result.duration_ms:.1f}ms)")
    print()

    # 2. AI Pipeline validation
    print("  [2] AI Pipeline Validation")
    print("  " + "-" * 30)
    ai = AIValidator()

    # Good pipeline
    good_steps = [
        {"type": "data_ingestion", "source": "huggingface/dataset-x", "erin": {"action": "load"}, "token_id": "t1"},
        {"type": "training", "version": "v2.1", "epochs": 10, "erin": {"action": "train"}, "token_id": "t2"},
        {"type": "evaluation", "accuracy": 0.94, "erin": {"action": "eval"}, "token_id": "t3"},
        {"type": "human_review", "reviewer": "jis:jasper", "approved": True, "erin": {"action": "review"}, "token_id": "t4"},
    ]
    result = ai.validate_ai_pipeline(good_steps)
    print(f"    Complete pipeline: {result.badge}")
    for check in result.checks:
        marker = "[+]" if check["passed"] else "[X]"
        print(f"      {marker} {check['detail']}")

    print()

    # Bad pipeline (no review, no versioning)
    bad_steps = [
        {"type": "training", "epochs": 5, "erin": {"action": "train"}, "token_id": "t1"},
        {"type": "deployment", "target": "production", "erin": {"action": "deploy"}, "token_id": "t2"},
    ]
    result = ai.validate_ai_pipeline(bad_steps)
    print(f"    Incomplete pipeline: {result.badge}")
    for check in result.checks:
        marker = "[+]" if check["passed"] else "[X]"
        print(f"      {marker} {check['detail']}")
    print()

    # 3. B2B Transaction validation
    print("  [3] B2B Transaction Validation")
    print("  " + "-" * 30)
    b2b = B2BValidator()

    good_tx = {
        "parties": [
            {"name": "Humotica BV", "jis_did": "jis:humotica"},
            {"name": "Bank NL", "jis_did": "jis:bank-nl"},
        ],
        "approvals": [
            {"approver": "jis:jasper", "timestamp": "2026-03-07T10:00:00Z"},
            {"approver": "jis:bank-nl:cfo", "timestamp": "2026-03-07T11:00:00Z"},
        ],
        "amount": 50000,
        "timestamp": "2026-03-07T10:00:00Z",
        "tibet_token": "tok_abc123",
    }
    result = b2b.validate_transaction(good_tx)
    print(f"    Complete transaction: {result.badge}")
    for check in result.checks:
        marker = "[+]" if check["passed"] else "[X]"
        print(f"      {marker} {check['detail']}")

    print()

    bad_tx = {
        "parties": [{"name": "Unknown Corp"}],
        "amount": 999999,
    }
    result = b2b.validate_transaction(bad_tx)
    print(f"    Incomplete transaction: {result.badge}")
    for check in result.checks:
        marker = "[+]" if check["passed"] else "[X]"
        print(f"      {marker} {check['detail']}")
    print()

    # Summary
    print("  Usage in CI/CD:")
    print("  " + "-" * 30)
    print("    # One-liner (GitHub Actions / GitLab CI)")
    print("    tibet-ci audit-line .        # Exit 0=pass, 1=fail")
    print()
    print("    # Full validation")
    print("    tibet-ci validate .          # Project structure check")
    print("    tibet-ci validate-chain r.json  # Chain integrity check")
    print()
    print("    # Python API")
    print("    from tibet_ci import QuickValidator, AIValidator, B2BValidator")
    print()

    return 0


def main() -> None:
    parser = argparse.ArgumentParser(
        prog="tibet-ci",
        description="Zero-Config CI/CD TIBET Integration",
    )
    parser.add_argument(
        "-j", "--json",
        action="store_true",
        default=False,
        help="Output as JSON",
    )

    sub = parser.add_subparsers(dest="command")

    # info
    sub.add_parser("info", help="Concept overview")

    # detect
    p_detect = sub.add_parser("detect", help="Detect project type")
    p_detect.add_argument("path", nargs="?", default=".", help="Project path")
    p_detect.add_argument("-j", "--json", action="store_true", default=False)

    # run
    p_run = sub.add_parser("run", help="Run full CI pipeline")
    p_run.add_argument("path", nargs="?", default=".", help="Project path")
    p_run.add_argument("-j", "--json", action="store_true", default=False)
    p_run.add_argument(
        "-s", "--stages",
        default=None,
        help=f"Comma-separated stages to run (default: all). "
             f"Available: {','.join(DEFAULT_STAGES)}",
    )

    # demo
    p_demo = sub.add_parser("demo", help="Demo run with simulated project")
    p_demo.add_argument("-j", "--json", action="store_true", default=False)

    # badge
    p_badge = sub.add_parser("badge", help="Generate badge status")
    p_badge.add_argument("path", nargs="?", default=".", help="Project path")
    p_badge.add_argument("-j", "--json", action="store_true", default=False)

    # validate
    p_validate = sub.add_parser("validate", help="Quick project validation (no pipeline run)")
    p_validate.add_argument("path", nargs="?", default=".", help="Project path")
    p_validate.add_argument("-j", "--json", action="store_true", default=False)

    # audit-line
    p_audit_line = sub.add_parser("audit-line", help="One-liner: badge + exit code")
    p_audit_line.add_argument("path", nargs="?", default=".", help="Project path")
    p_audit_line.add_argument("-j", "--json", action="store_true", default=False)

    # validate-chain
    p_chain = sub.add_parser("validate-chain", help="Validate TIBET chain from JSON file")
    p_chain.add_argument("file", help="JSON file with TIBET chain")
    p_chain.add_argument("-j", "--json", action="store_true", default=False)

    # validate-demo
    p_vdemo = sub.add_parser("validate-demo", help="Demo all validators (project, AI, B2B)")
    p_vdemo.add_argument("-j", "--json", action="store_true", default=False)

    args = parser.parse_args()

    if not args.command:
        parser.print_help()
        sys.exit(0)

    commands = {
        "info": cmd_info,
        "detect": cmd_detect,
        "run": cmd_run,
        "demo": cmd_demo,
        "badge": cmd_badge,
        "validate": cmd_validate,
        "audit-line": cmd_audit_line,
        "validate-chain": cmd_validate_chain,
        "validate-demo": cmd_validate_demo,
    }
    sys.exit(commands[args.command](args))
