"""
Lightweight TIBET validator for CI/CD pipelines.

The fast path: validate tokens, chains, and projects in one line.
No full pipeline run needed. Just: does this pass? Yes/No. Exit 0/1.

Usage::

    # CLI
    tibet-ci validate .                    # Validate project structure
    tibet-ci validate --chain result.json  # Validate a TIBET chain
    tibet-ci audit-line .                  # One-liner: badge + exit code

    # Python
    from tibet_ci import QuickValidator
    v = QuickValidator()
    ok = v.validate_project(".")
    ok = v.validate_chain(chain_data)

    # Domain modules
    from tibet_ci import AIValidator, B2BValidator
    v = AIValidator()
    result = v.validate_model_pipeline(steps)
"""

import hashlib
import json
import os
import time
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Optional


@dataclass
class ValidationResult:
    """Result of a validation check."""
    valid: bool
    checks_passed: int = 0
    checks_failed: int = 0
    checks: list[dict] = field(default_factory=list)
    badge: str = "UNKNOWN"  # VALID, WARNING, INVALID
    checksum: str = ""
    duration_ms: float = 0.0

    def to_dict(self) -> dict:
        return {
            "valid": self.valid,
            "badge": self.badge,
            "checks_passed": self.checks_passed,
            "checks_failed": self.checks_failed,
            "checks": self.checks,
            "checksum": self.checksum,
            "duration_ms": round(self.duration_ms, 1),
        }


class QuickValidator:
    """
    Lightweight TIBET validator — fast yes/no answers.

    No pipeline execution. No dependency install. No subprocess.
    Just structural and integrity checks.
    """

    def validate_project(self, path: str | Path = ".") -> ValidationResult:
        """
        Validate project structure for TIBET compliance.

        Checks:
        - Has LICENSE
        - Has README
        - Has project config (pyproject.toml, package.json, Cargo.toml, etc.)
        - Has .gitignore
        - Has source directory
        - No secrets in tracked files
        """
        start = time.monotonic()
        root = Path(path).resolve()
        checks = []

        # LICENSE
        has_license = (root / "LICENSE").exists() or (root / "LICENSE.md").exists() or (root / "LICENCE").exists()
        checks.append({"name": "license", "passed": has_license, "detail": "LICENSE file present" if has_license else "No LICENSE file"})

        # README
        has_readme = (root / "README.md").exists() or (root / "README.rst").exists() or (root / "README").exists()
        checks.append({"name": "readme", "passed": has_readme, "detail": "README present" if has_readme else "No README"})

        # Project config
        config_files = ["pyproject.toml", "package.json", "Cargo.toml", "go.mod", "pom.xml", "build.gradle"]
        found_configs = [f for f in config_files if (root / f).exists()]
        has_config = len(found_configs) > 0
        checks.append({"name": "config", "passed": has_config, "detail": f"Found: {', '.join(found_configs)}" if found_configs else "No project config"})

        # .gitignore
        has_gitignore = (root / ".gitignore").exists()
        checks.append({"name": "gitignore", "passed": has_gitignore, "detail": ".gitignore present" if has_gitignore else "No .gitignore"})

        # Source directory
        has_src = (root / "src").is_dir() or (root / "lib").is_dir() or (root / "app").is_dir()
        checks.append({"name": "source_dir", "passed": has_src, "detail": "Source directory found" if has_src else "No src/ or lib/ directory"})

        # Secret files check
        secret_patterns = [".env", "credentials.json", "secrets.yaml", "secrets.yml", ".env.local", "id_rsa", "id_ed25519"]
        found_secrets = [f for f in secret_patterns if (root / f).exists()]
        no_secrets = len(found_secrets) == 0
        checks.append({"name": "no_secrets", "passed": no_secrets, "detail": "No secret files detected" if no_secrets else f"WARNING: {', '.join(found_secrets)}"})

        passed = sum(1 for c in checks if c["passed"])
        failed = sum(1 for c in checks if not c["passed"])

        # Badge
        if failed == 0:
            badge = "VALID"
        elif failed <= 2:
            badge = "WARNING"
        else:
            badge = "INVALID"

        # Checksum of validation state
        state = json.dumps(checks, sort_keys=True)
        checksum = hashlib.sha256(state.encode()).hexdigest()[:16]

        duration = (time.monotonic() - start) * 1000

        return ValidationResult(
            valid=failed == 0,
            checks_passed=passed,
            checks_failed=failed,
            checks=checks,
            badge=badge,
            checksum=checksum,
            duration_ms=duration,
        )

    def validate_chain(self, chain_data: list[dict]) -> ValidationResult:
        """
        Validate a TIBET token chain for integrity.

        Checks:
        - Chain is not empty
        - All tokens have required TIBET fields (ERIN, ERAAN, EROMHEEN, ERACHTER)
        - Parent references are consistent
        - Timestamps are chronological
        - Content hashes are present
        """
        start = time.monotonic()
        checks = []

        # Non-empty
        not_empty = len(chain_data) > 0
        checks.append({"name": "non_empty", "passed": not_empty, "detail": f"Chain has {len(chain_data)} tokens" if not_empty else "Empty chain"})

        if not not_empty:
            return ValidationResult(
                valid=False, checks_passed=0, checks_failed=1,
                checks=checks, badge="INVALID",
                duration_ms=(time.monotonic() - start) * 1000,
            )

        # Required TIBET fields
        tibet_fields = {"erin", "eraan", "eromheen", "erachter"}
        all_have_tibet = all(tibet_fields.issubset(set(t.keys())) for t in chain_data)
        checks.append({"name": "tibet_fields", "passed": all_have_tibet, "detail": "All tokens have ERIN/ERAAN/EROMHEEN/ERACHTER" if all_have_tibet else "Missing TIBET fields in some tokens"})

        # Parent chain consistency
        chain_valid = True
        for i, token in enumerate(chain_data):
            if i == 0:
                # First token should have no parent or null parent
                continue
            parent_id = token.get("parent_id") or token.get("eraan", {}).get("parent_token")
            prev_id = chain_data[i - 1].get("token_id")
            if parent_id and prev_id and parent_id != prev_id:
                chain_valid = False
                break
        checks.append({"name": "chain_integrity", "passed": chain_valid, "detail": "Parent chain consistent" if chain_valid else "Broken parent references"})

        # Timestamps chronological
        timestamps = [t.get("timestamp", "") for t in chain_data if t.get("timestamp")]
        chrono_valid = timestamps == sorted(timestamps) if timestamps else True
        checks.append({"name": "chronological", "passed": chrono_valid, "detail": "Timestamps chronological" if chrono_valid else "Out-of-order timestamps"})

        # Content hashes present
        has_hashes = all(t.get("content_hash", "") for t in chain_data)
        checks.append({"name": "content_hashes", "passed": has_hashes, "detail": "All tokens have content hashes" if has_hashes else "Missing content hashes"})

        passed = sum(1 for c in checks if c["passed"])
        failed = sum(1 for c in checks if not c["passed"])

        if failed == 0:
            badge = "VALID"
        elif failed <= 1:
            badge = "WARNING"
        else:
            badge = "INVALID"

        checksum = hashlib.sha256(json.dumps(chain_data, sort_keys=True, default=str).encode()).hexdigest()[:16]
        duration = (time.monotonic() - start) * 1000

        return ValidationResult(
            valid=failed == 0,
            checks_passed=passed,
            checks_failed=failed,
            checks=checks,
            badge=badge,
            checksum=checksum,
            duration_ms=duration,
        )

    def audit_line(self, path: str | Path = ".") -> tuple[str, int]:
        """
        One-liner audit — returns (badge, exit_code).

        For CI/CD YAML:
            tibet-ci audit-line .
            # Prints: VALID (or WARNING or INVALID)
            # Exit code: 0 (pass) or 1 (fail)
        """
        result = self.validate_project(path)
        return result.badge, 0 if result.valid else 1


class AIValidator(QuickValidator):
    """
    AI-specific TIBET validator.

    Validates AI/ML pipeline provenance:
    - Model training data has provenance
    - Inference steps are tracked
    - Model versioning is present
    - Bias/fairness checks are documented
    """

    def validate_ai_pipeline(self, steps: list[dict]) -> ValidationResult:
        """Validate an AI pipeline for provenance compliance."""
        start = time.monotonic()
        checks = []

        # Has data provenance step
        data_steps = [s for s in steps if s.get("type") in ("data_ingestion", "data_load", "dataset")]
        has_data_prov = len(data_steps) > 0
        checks.append({"name": "data_provenance", "passed": has_data_prov,
                        "detail": f"{len(data_steps)} data provenance steps" if has_data_prov else "No data provenance — where does your training data come from?"})

        # Has model versioning
        model_steps = [s for s in steps if s.get("type") in ("training", "model_save", "model_export")]
        has_model = len(model_steps) > 0
        if has_model:
            has_version = all(s.get("version") or s.get("model_version") for s in model_steps)
        else:
            has_version = False
        checks.append({"name": "model_versioning", "passed": has_version,
                        "detail": "Model versions tracked" if has_version else "No model versioning"})

        # Has evaluation step
        eval_steps = [s for s in steps if s.get("type") in ("evaluation", "test", "benchmark", "validation")]
        has_eval = len(eval_steps) > 0
        checks.append({"name": "evaluation", "passed": has_eval,
                        "detail": f"{len(eval_steps)} evaluation steps" if has_eval else "No evaluation step — how do you know it works?"})

        # Has human review
        review_steps = [s for s in steps if s.get("type") in ("review", "human_review", "approval")]
        has_review = len(review_steps) > 0
        checks.append({"name": "human_review", "passed": has_review,
                        "detail": "Human review present" if has_review else "No human review step (EU AI Act compliance risk)"})

        # TIBET provenance on all steps
        all_have_tibet = all(
            s.get("erin") or s.get("tibet_token") or s.get("token_id")
            for s in steps
        )
        checks.append({"name": "tibet_provenance", "passed": all_have_tibet,
                        "detail": "All steps have TIBET provenance" if all_have_tibet else "Some steps lack TIBET tokens"})

        passed = sum(1 for c in checks if c["passed"])
        failed = sum(1 for c in checks if not c["passed"])

        badge = "VALID" if failed == 0 else ("WARNING" if failed <= 2 else "INVALID")
        checksum = hashlib.sha256(json.dumps(checks, sort_keys=True).encode()).hexdigest()[:16]
        duration = (time.monotonic() - start) * 1000

        return ValidationResult(
            valid=failed == 0,
            checks_passed=passed,
            checks_failed=failed,
            checks=checks,
            badge=badge,
            checksum=checksum,
            duration_ms=duration,
        )


class B2BValidator(QuickValidator):
    """
    B2B-specific TIBET validator.

    Validates business process provenance:
    - Contract/agreement has TIBET token
    - All parties are identified (JIS DIDs)
    - Approval chain is complete
    - Compliance checks are documented
    - Audit trail is exportable
    """

    def validate_transaction(self, transaction: dict) -> ValidationResult:
        """Validate a B2B transaction for provenance compliance."""
        start = time.monotonic()
        checks = []

        # Has parties
        parties = transaction.get("parties", [])
        has_parties = len(parties) >= 2
        checks.append({"name": "parties_identified", "passed": has_parties,
                        "detail": f"{len(parties)} parties identified" if has_parties else "Need at least 2 parties for B2B"})

        # Parties have JIS DIDs
        has_jis = all(
            p.get("jis_did") or p.get("did") or (isinstance(p, str) and p.startswith("jis:"))
            for p in parties
        ) if parties else False
        checks.append({"name": "jis_identity", "passed": has_jis,
                        "detail": "All parties have JIS identity" if has_jis else "Parties need JIS DIDs for trust"})

        # Has approval chain
        approvals = transaction.get("approvals", [])
        has_approvals = len(approvals) > 0
        checks.append({"name": "approval_chain", "passed": has_approvals,
                        "detail": f"{len(approvals)} approvals recorded" if has_approvals else "No approval chain"})

        # Has TIBET provenance
        has_tibet = bool(transaction.get("tibet_token") or transaction.get("token_id") or transaction.get("erin"))
        checks.append({"name": "tibet_provenance", "passed": has_tibet,
                        "detail": "TIBET provenance attached" if has_tibet else "No TIBET token on transaction"})

        # Has timestamp
        has_timestamp = bool(transaction.get("timestamp") or transaction.get("created_at"))
        checks.append({"name": "timestamp", "passed": has_timestamp,
                        "detail": "Timestamp recorded" if has_timestamp else "No timestamp — when did this happen?"})

        # Has value/amount
        has_value = transaction.get("amount") is not None or transaction.get("value") is not None
        checks.append({"name": "value_recorded", "passed": has_value,
                        "detail": "Transaction value recorded" if has_value else "No value/amount recorded"})

        passed = sum(1 for c in checks if c["passed"])
        failed = sum(1 for c in checks if not c["passed"])

        badge = "VALID" if failed == 0 else ("WARNING" if failed <= 2 else "INVALID")
        checksum = hashlib.sha256(json.dumps(checks, sort_keys=True).encode()).hexdigest()[:16]
        duration = (time.monotonic() - start) * 1000

        return ValidationResult(
            valid=failed == 0,
            checks_passed=passed,
            checks_failed=failed,
            checks=checks,
            badge=badge,
            checksum=checksum,
            duration_ms=duration,
        )
