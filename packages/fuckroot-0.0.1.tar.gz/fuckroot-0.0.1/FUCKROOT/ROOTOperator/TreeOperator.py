from FUCKROOT.ROOT_BASE import *
from ROUtils import *
import pandas as pd
import awkward as ak
from tqdm import tqdm


def _to_dataframe(obj, index):
    if isinstance(obj, pd.DataFrame):
        return obj

    if isinstance(obj, pd.Series):
        return obj.to_frame()

    if isinstance(obj, ak.Array):
        return ak.to_dataframe(obj)

    raise TypeError(
        f"Tree at index {index} returned unsupported type {type(obj)!r}; "
        "expected pandas DataFrame/Series or awkward Array."
    )

def concat(trees):
    assert len(trees) > 1, "At least two trees are required for concatenation."
    assert check_consitency(trees), "Trees have different keys, cannot concatenate."

    combined_tree = Tree()

    raw_items = [tree.get_all_pandas() for tree in tqdm(trees)]
    print(raw_items)
    dfs = [_to_dataframe(item, idx) for idx, item in enumerate(raw_items)]
    print(dfs, "dfs")

    merged_df = pd.concat(dfs, ignore_index=True)
    
    print(f"Concatenated DataFrame shape: {merged_df.shape}")
    combined_tree.load_from_pandas(merged_df)

    return combined_tree









if __name__ == '__main__':
    rt = ROOT("/home/easonfu/pyproj/FUCKROOT/zdelete/tuple_reco_baseline.root")
    print(rt)


    trees = []
    for i in range(15):
        tree = rt["FakeClusteringTV_59b6baa0/tv_layer"]
        print(tree)
        trees.append(tree)

    combined_tree = concat(trees)
    print(combined_tree)



