from typing import List


def check_consitency(trees: List) -> bool:
    keys = []
    for tree in trees:
        keys.append(tree.keys())

    unique_keys = set(tuple(k) for k in keys)
    if len(unique_keys) > 1:
        return False
    else:
        return True