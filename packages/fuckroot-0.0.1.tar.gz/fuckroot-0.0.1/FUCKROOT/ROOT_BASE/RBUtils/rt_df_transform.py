import uproot
import pandas as pd
import tempfile
import awkward as ak





def df_to_rt(df, tree_name="DecayTree"):
    if not isinstance(df, pd.DataFrame):
        raise TypeError(f"df must be a pandas DataFrame, got {type(df)!r}")

    tmp = tempfile.NamedTemporaryFile(suffix=".root", delete=False)

    # Write only explicit data columns so pandas row index is not materialized as a ROOT branch.
    payload = {col: df[col].to_numpy() for col in df.columns}

    with uproot.recreate(tmp.name) as f:
        f[tree_name] = payload

    rt = uproot.open(tmp.name)


    return rt[tree_name]



def rt_to_df(rt):
    df = rt.arrays(library="pd")
    return df


if __name__ == "__main__":
    pass