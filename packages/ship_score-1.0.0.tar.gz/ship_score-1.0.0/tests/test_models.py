"""Tests for Pydantic models."""

from ship_score.models import (
    CrawlerStatus,
    DetectResult,
    HealthStatus,
    ScoreResult,
    ToolInfo,
    ToolsResult,
)


class TestScoreResult:
    def test_basic_parsing(self) -> None:
        data = {
            "score": 73,
            "grade": "B",
            "confidence": 0.82,
            "factors": {"length": 0.9},
            "recommendations": ["Add tests"],
        }
        result = ScoreResult.model_validate(data)
        assert result.score == 73
        assert result.grade == "B"
        assert result.confidence == 0.82
        assert result.factors == {"length": 0.9}
        assert result.recommendations == ["Add tests"]

    def test_defaults(self) -> None:
        result = ScoreResult(score=50, grade="C", confidence=0.5)
        assert result.factors == {}
        assert result.recommendations == []


class TestDetectResult:
    def test_basic_parsing(self) -> None:
        data = {
            "is_ai_generated": True,
            "confidence": 0.89,
            "features_used": 174,
        }
        result = DetectResult.model_validate(data)
        assert result.is_ai_generated is True
        assert result.is_ai is True
        assert result.confidence == 0.89
        assert result.features_used == 174

    def test_not_ai(self) -> None:
        data = {
            "is_ai_generated": False,
            "confidence": 0.12,
            "features_used": 50,
        }
        result = DetectResult.model_validate(data)
        assert result.is_ai is False


class TestToolInfo:
    def test_basic(self) -> None:
        data = {
            "name": "claude",
            "display_name": "Claude",
            "reliability_score": 44,
            "grade": "F",
            "total_scored": 100,
        }
        tool = ToolInfo.model_validate(data)
        assert tool.name == "claude"
        assert tool.reliability_score == 44

    def test_extra_fields_allowed(self) -> None:
        data = {"name": "test", "extra_field": "ok"}
        tool = ToolInfo.model_validate(data)
        assert tool.name == "test"


class TestToolsResult:
    def test_list(self) -> None:
        data = {
            "tools": [
                {"name": "claude", "display_name": "Claude"},
            ],
        }
        result = ToolsResult.model_validate(data)
        assert len(result.tools) == 1


class TestCrawlerStatus:
    def test_extra_fields(self) -> None:
        data = {
            "total_commits": 22000,
            "total_repos": 10000,
            "some_extra": True,
        }
        status = CrawlerStatus.model_validate(data)
        assert status.total_commits == 22000


class TestHealthStatus:
    def test_healthy(self) -> None:
        h = HealthStatus(
            api_reachable=True,
            api_url="http://test",
            total_commits=100,
            total_repos=50,
        )
        assert h.api_reachable is True
        assert h.error is None

    def test_unhealthy(self) -> None:
        h = HealthStatus(
            api_reachable=False,
            api_url="http://test",
            error="timeout",
        )
        assert h.api_reachable is False
        assert h.error == "timeout"
