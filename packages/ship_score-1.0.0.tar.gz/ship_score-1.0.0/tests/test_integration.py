"""Integration test that hits the live SHIP API.

Run with: pytest -m integration
Skipped by default in CI (requires network access to SHIP API).
"""

import pytest

from ship_score.client import ShipClient


@pytest.mark.integration
class TestLiveAPI:
    def test_health_endpoint(self) -> None:
        """Verify the live API is reachable and returns valid data."""
        client = ShipClient()
        status = client.health()
        if not status.api_reachable:
            pytest.skip(
                f"SHIP API not reachable: {status.error}"
            )
        assert status.total_commits > 0
        assert status.total_repos > 0
        client.close()
