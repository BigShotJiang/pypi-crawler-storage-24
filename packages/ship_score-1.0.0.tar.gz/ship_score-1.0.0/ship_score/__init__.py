"""SHIP Protocol — AI code reliability scoring."""

from .client import ShipClient
from .models import DetectResult, HealthStatus, ScoreResult, ToolInfo

__all__ = [
    "ShipClient",
    "ScoreResult",
    "DetectResult",
    "HealthStatus",
    "ToolInfo",
]

__version__ = "1.0.0"
