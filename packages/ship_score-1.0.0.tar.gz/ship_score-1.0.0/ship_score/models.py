"""Pydantic models for SHIP Protocol API responses."""

from __future__ import annotations

from typing import Any, Dict, List, Optional

from pydantic import BaseModel, Field


class ScoreResult(BaseModel):
    """Result from the /v2/score endpoint."""

    score: int = Field(description="Reliability score 0-100")
    grade: str = Field(description="Letter grade (A-F)")
    confidence: float = Field(
        description="Confidence in the score (0-1)",
    )
    factors: Dict[str, Any] = Field(
        default_factory=dict,
        description="Scoring factor breakdown",
    )
    recommendations: List[str] = Field(
        default_factory=list,
        description="Improvement recommendations",
    )


class DetectResult(BaseModel):
    """Result from the /v2/detect endpoint."""

    is_ai_generated: bool = Field(
        alias="is_ai_generated",
        description="Whether code is AI-generated",
    )
    confidence: float = Field(
        description="Detection confidence (0-1)",
    )
    features_used: int = Field(
        default=0,
        description="Number of features analyzed",
    )

    model_config = {"populate_by_name": True}

    @property
    def is_ai(self) -> bool:
        """Convenience alias."""
        return self.is_ai_generated


class ToolInfo(BaseModel):
    """A single tool entry from /v2/tools."""

    name: str
    display_name: str = ""
    reliability_score: Optional[float] = None
    grade: Optional[str] = None
    total_scored: Optional[int] = None

    model_config = {"extra": "allow"}


class ToolsResult(BaseModel):
    """Result from the /v2/tools endpoint."""

    tools: List[ToolInfo] = Field(default_factory=list)


class CrawlerStatus(BaseModel):
    """Result from the /v2/crawler-status endpoint."""

    total_commits: int = 0
    total_repos: int = 0

    model_config = {"extra": "allow"}


class HealthStatus(BaseModel):
    """Aggregated health information."""

    api_reachable: bool = False
    api_url: str = ""
    total_commits: int = 0
    total_repos: int = 0
    error: Optional[str] = None
