"""Token-budget scheduler: estimate request size, track TPM, wait before dispatch to avoid 429."""

import json
import os
import threading
import time
from typing import Any

# Stay under tier limit. Set OPENARTEMIS_TPM_LIMIT to match your API tier (default 200K).
_default_tpm = 200_000
try:
    _env = os.environ.get("OPENARTEMIS_TPM_LIMIT", "").strip()
    if _env:
        _default_tpm = max(1000, int(_env))
except (TypeError, ValueError):
    pass
TPM_LIMIT = _default_tpm
# Max input tokens per request (leave room for response)
MAX_INPUT_TOKENS_PER_CALL = 24_000
WINDOW_SECONDS = 60
DEFAULT_RETRY_SLEEP = 30.0

_lock = threading.Lock()
_usage: dict[str, list[tuple[float, int]]] = {}  # model -> [(monotonic_time, tokens), ...]
_retry_after_until: float = 0.0  # monotonic time until which we must wait (from 429)

# Session-level cumulative cost tracking
_session_tokens = {"input": 0, "output": 0, "calls": 0}

# Rough per-1K-token pricing (input/output) for cost estimation
_PRICING = {
    "claude-sonnet-4-5": (0.003, 0.015),
    "claude-opus-4-5": (0.015, 0.075),
    "claude-haiku-4-5": (0.00025, 0.00125),
    "claude-3-5-sonnet-20241022": (0.003, 0.015),
    "claude-3-5-haiku-20241022": (0.001, 0.005),
    "claude-3-opus-20240229": (0.015, 0.075),
}
_DEFAULT_PRICING = (0.003, 0.015)  # Claude Sonnet pricing


def reset_session_cost() -> None:
    """Reset session token/cost counters (call at start of agent run)."""
    _session_tokens["input"] = 0
    _session_tokens["output"] = 0
    _session_tokens["calls"] = 0


def get_session_cost() -> dict:
    """Return session stats: {input_tokens, output_tokens, calls, estimated_cost_usd}."""
    inp = _session_tokens["input"]
    out = _session_tokens["output"]
    calls = _session_tokens["calls"]
    # Use average pricing
    cost = (inp / 1000) * _DEFAULT_PRICING[0] + (out / 1000) * _DEFAULT_PRICING[1]
    return {"input_tokens": inp, "output_tokens": out, "calls": calls, "estimated_cost_usd": round(cost, 4)}


def estimate_request_tokens(messages: list[Any], max_tokens: int = 2048) -> int:
    """Estimate input + output tokens. Uses ~4 chars per token heuristic."""
    try:
        raw = json.dumps(messages, default=str)
        input_est = max(1, len(raw) // 4)
    except Exception:
        input_est = 2000
    return input_est + max_tokens


def set_retry_after(seconds: float) -> None:
    """Call when a 429 is received; next wait_before_call will sleep at least this long."""
    global _retry_after_until
    if seconds > 0:
        with _lock:
            _retry_after_until = time.monotonic() + seconds


def _prune(model: str) -> None:
    """Drop entries older than WINDOW_SECONDS."""
    now = time.monotonic()
    cutoff = now - WINDOW_SECONDS
    if model in _usage:
        _usage[model] = [(t, n) for t, n in _usage[model] if t > cutoff]


def _current_usage(model: str) -> int:
    _prune(model)
    return sum(n for _, n in _usage.get(model, []))


def wait_before_call(model: str, estimate: int) -> None:
    """Wait if TPM budget would be exceeded or if a 429 retry-after is active, then record usage."""
    global _retry_after_until
    with _lock:
        now = time.monotonic()
        # Honor server 429 "try again in Xs"
        if _retry_after_until > now:
            wait = _retry_after_until - now
            _retry_after_until = 0.0
        else:
            wait = 0.0
        if wait <= 0:
            current = _current_usage(model)
            if current + estimate > TPM_LIMIT:
                # Wait for oldest entry to exit the window
                if model in _usage and _usage[model]:
                    oldest = min(t for t, _ in _usage[model])
                    wait = max(0.0, oldest + WINDOW_SECONDS - now)
                if wait <= 0:
                    wait = DEFAULT_RETRY_SLEEP
                wait = min(wait, DEFAULT_RETRY_SLEEP)
    if wait > 0:
        time.sleep(wait)
    with _lock:
        _prune(model)
        if model not in _usage:
            _usage[model] = []
        _usage[model].append((time.monotonic(), estimate))


def _convert_tools_to_anthropic(tools: list[Any]) -> list[dict]:
    """Convert OpenAI-format tools [{type:function, function:{name,description,parameters}}]
    to Anthropic format [{name, description, input_schema}]."""
    result = []
    for t in tools:
        if isinstance(t, dict) and t.get("type") == "function":
            fn = t.get("function", {})
            result.append({
                "name": fn.get("name", ""),
                "description": fn.get("description", ""),
                "input_schema": fn.get("parameters", {"type": "object", "properties": {}}),
            })
        elif isinstance(t, dict) and "name" in t and "input_schema" in t:
            result.append(t)  # already Anthropic format
    return result


def create_with_budget(client: Any, model: str, messages: list[Any], **kwargs: Any) -> Any:
    """Call Anthropic messages.create after waiting for token budget. Pass through kwargs."""
    from openartemis.config import DEFAULT_BASE_MODEL
    model = (model or "").strip() or DEFAULT_BASE_MODEL
    max_tokens_val = kwargs.pop("max_tokens", 2048)
    # Extract system message; convert OpenAI-format messages to Anthropic format.
    # Messages with content already as a list (Anthropic native) are passed through unchanged.
    system_msg = None
    anthropic_messages = []
    for msg in messages:
        role = msg.get("role", "")
        content = msg.get("content")
        if role == "system":
            system_msg = content if isinstance(content, str) else ""
        elif role == "tool":
            # OpenAI tool result → Anthropic tool_result block inside user message
            tool_use_id = msg.get("tool_call_id", "")
            text_content = content if isinstance(content, str) else ""
            anthropic_messages.append({
                "role": "user",
                "content": [{"type": "tool_result", "tool_use_id": tool_use_id, "content": text_content}] if tool_use_id else text_content,
            })
        elif isinstance(content, list):
            # Already Anthropic-native format (list of blocks) — pass through as-is
            anthropic_messages.append({"role": role, "content": content})
        else:
            # Plain string content
            anthropic_messages.append({"role": role, "content": content or ""})
    # Convert OpenAI-format tools to Anthropic format
    raw_tools = kwargs.pop("tools", None)
    tool_choice = kwargs.pop("tool_choice", None)
    # Drop any remaining OpenAI-only kwargs
    kwargs.pop("stream", None)
    estimate = estimate_request_tokens(messages, max_tokens=max_tokens_val)
    wait_before_call(model, estimate)
    create_kwargs: dict[str, Any] = {
        "model": model,
        "messages": anthropic_messages,
        "max_tokens": max_tokens_val,
    }
    if system_msg:
        create_kwargs["system"] = system_msg
    if raw_tools:
        create_kwargs["tools"] = _convert_tools_to_anthropic(raw_tools)
        if tool_choice == "auto" or tool_choice is None:
            create_kwargs["tool_choice"] = {"type": "auto"}
        elif tool_choice == "none":
            pass  # omit tools entirely is the Anthropic way
        elif isinstance(tool_choice, dict):
            create_kwargs["tool_choice"] = tool_choice
    create_kwargs.update(kwargs)
    resp = client.messages.create(**create_kwargs)
    # Track actual usage for cost estimation
    try:
        usage = getattr(resp, "usage", None)
        if usage:
            _session_tokens["input"] += getattr(usage, "input_tokens", 0)
            _session_tokens["output"] += getattr(usage, "output_tokens", 0)
        _session_tokens["calls"] += 1
    except Exception:
        pass
    # Wrap Anthropic response to emulate OpenAI response format so existing callers work unchanged.
    # Supports: resp.choices[0].message.content, msg.tool_calls, tc.function.name/arguments,
    # tc.id, msg.role, resp._tool_calls (Anthropic-native list).
    import json as _json

    class _FunctionCall:
        def __init__(self, name: str, arguments: str):
            self.name = name
            self.arguments = arguments

    class _ToolCall:
        def __init__(self, id: str, name: str, input_dict: dict):
            self.id = id
            self.type = "function"
            self.function = _FunctionCall(name, _json.dumps(input_dict))

    class _Message:
        def __init__(self, text: str, tcs: list, stop_reason: str, raw_content: list):
            self.content = text or None
            self.role = "assistant"
            self.tool_calls = tcs if tcs else None
            self.stop_reason = stop_reason
            # Native Anthropic content blocks — use this for conversation history
            # so tool_result messages can reference tool_use block IDs correctly.
            self._anthropic_content = raw_content

        def model_dump(self) -> dict:
            d: dict = {"role": self.role, "content": self.content or ""}
            if self.tool_calls:
                d["tool_calls"] = [
                    {"id": tc.id, "type": "function",
                     "function": {"name": tc.function.name, "arguments": tc.function.arguments}}
                    for tc in self.tool_calls
                ]
            return d

        def to_anthropic_dict(self) -> dict:
            """Return assistant message in Anthropic API format (preserves tool_use blocks)."""
            return {"role": "assistant", "content": self._anthropic_content}

    class _Choice:
        def __init__(self, msg: Any):
            self.message = msg
            self.finish_reason = "tool_calls" if msg.tool_calls else "stop"

    class _WrappedResp:
        def __init__(self, r: Any):
            text = ""
            tool_calls = []
            anthropic_tool_calls = []
            raw_content = []
            for block in getattr(r, "content", []):
                btype = getattr(block, "type", "")
                if btype == "text":
                    text += block.text
                    raw_content.append({"type": "text", "text": block.text})
                elif btype == "tool_use":
                    bid = getattr(block, "id", "")
                    bname = getattr(block, "name", "")
                    binput = getattr(block, "input", {})
                    tool_calls.append(_ToolCall(bid, bname, binput))
                    anthropic_tool_calls.append({"id": bid, "name": bname, "input": binput})
                    raw_content.append({"type": "tool_use", "id": bid, "name": bname, "input": binput})
            stop_reason = getattr(r, "stop_reason", "end_turn")
            msg = _Message(text, tool_calls, stop_reason, raw_content)
            self.choices = [_Choice(msg)]
            self._tool_calls = anthropic_tool_calls  # native Anthropic format
            self.usage = getattr(r, "usage", None)
    return _WrappedResp(resp)
