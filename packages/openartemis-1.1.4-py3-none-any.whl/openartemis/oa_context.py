"""OpenArtemis context (.oa) — persistent JSONL in Artemiscontext folder per workspace."""

import json
from pathlib import Path
from typing import Any

ARTEMISCONTEXT_DIR = "Artemiscontext"
CONTEXT_FILENAME = "context.oa"
HUMAN_CONTEXT_FILENAME = "Artemiscontext.OA"


def _context_dir(workspace: Path) -> Path:
    """Directory that holds both machine (.oa) and human-readable context files."""
    return workspace.resolve() / ARTEMISCONTEXT_DIR


def _context_path(workspace: Path) -> Path:
    """Path to workspace/Artemiscontext/context.oa (JSONL events)."""
    return _context_dir(workspace) / CONTEXT_FILENAME


def _human_context_path(workspace: Path) -> Path:
    """Path to workspace/Artemiscontext/Artemiscontext.OA (human-readable log)."""
    return _context_dir(workspace) / HUMAN_CONTEXT_FILENAME


def ensure_artemiscontext(workspace: Path) -> Path:
    """Create workspace/Artemiscontext/ if needed. Returns the machine context file path.

    This also ensures a human-readable Artemiscontext.OA file exists alongside the JSONL
    ledger so users (and future training pipelines) can inspect a lightweight text log.
    """
    ctx_dir = _context_dir(workspace)
    ctx_dir.mkdir(parents=True, exist_ok=True)
    path = ctx_dir / CONTEXT_FILENAME
    if not path.exists():
        path.write_text("", encoding="utf-8")
    human_path = _human_context_path(workspace)
    if not human_path.exists():
        # Initial header to explain the purpose; subsequent events append lines.
        human_path.write_text(
            "# Artemiscontext log\n"
            "# Human-readable summary of recent agent runs in this workspace.\n\n",
            encoding="utf-8",
        )
    return path


def _append_human_summary(workspace: Path, event: dict[str, Any]) -> None:
    """Append a compact, human-readable line for a given event to Artemiscontext.OA.

    The goal is not to be exhaustive, just to leave a breadcrumb trail that a human
    (or an offline dataset builder) can skim without parsing JSON.
    """
    kind = str(event.get("event") or "").strip()
    if not kind:
        return
    parts: list[str] = [kind]
    ts = event.get("ts")
    if isinstance(ts, str) and ts:
        parts.append(ts)
    if kind == "session_start":
        goal = (event.get("goal") or "").strip()
        if goal:
            parts.append(f"goal={goal[:120]}")
    elif kind == "plan":
        stack = (event.get("stack") or "").strip()
        if stack:
            parts.append(f"stack={stack[:80]}")
        step_count = event.get("step_count")
        if isinstance(step_count, int):
            parts.append(f"steps={step_count}")
    elif kind == "step_done":
        step_id = event.get("step_id")
        action = (event.get("action") or "").strip()
        parts.append(f"step={step_id}")
        if action:
            parts.append(f"action={action[:80]}")
    elif kind == "screenshot_feedback":
        entry = (event.get("entrypoint") or "").strip()
        summary = (event.get("summary") or "").strip()
        if entry:
            parts.append(f"entry={entry}")
        if summary:
            parts.append(f"ui={summary[:100]}")
    elif kind == "session_end":
        outcome = (event.get("outcome") or "").strip()
        if outcome:
            parts.append(f"outcome={outcome}")
    elif kind == "playtest_run":
        outcome = (event.get("result") or "").strip()
        if outcome:
            parts.append(f"playtest={outcome}")

    line = " | ".join(parts)
    human_path = _human_context_path(workspace)
    try:
        with open(human_path, "a", encoding="utf-8") as f:
            f.write(line[:400] + "\n")
    except OSError:
        # Non-fatal; machine context is the source of truth.
        pass


def append_oa_event(workspace: Path, event: dict[str, Any]) -> None:
    """Append one JSONL line to workspace/Artemiscontext/context.oa and a brief
    human-readable summary line to Artemiscontext.OA.

    The JSONL ledger is the source of truth; the text log is for quick inspection.
    """
    path = ensure_artemiscontext(workspace)
    line = json.dumps(event, ensure_ascii=False) + "\n"
    with open(path, "a", encoding="utf-8") as f:
        f.write(line)
    _append_human_summary(workspace, event)


def list_main_artifact_paths(workspace: Path) -> list[str]:
    """Return absolute paths to likely entrypoint files in workspace (for CLI display)."""
    ws = workspace.resolve()
    paths: list[str] = []
    for name in ("index.html", "index.htm", "main.py", "app.py", "main.js"):
        p = ws / name
        if p.exists() and p.is_file():
            paths.append(str(p))
    return paths[:10]


def load_oa_summary(
    workspace: Path,
    max_lines: int = 50,
    max_chars: int = 1500,
) -> str:
    """Read last N lines of context.oa, parse JSONL, build a short text summary for the system prompt."""
    path = _context_path(workspace)
    if not path.exists():
        return ""

    try:
        lines = path.read_text(encoding="utf-8", errors="replace").strip().splitlines()
    except OSError:
        return ""

    # Take last max_lines
    lines = lines[-max_lines:] if len(lines) > max_lines else lines
    events: list[dict] = []
    for line in lines:
        line = line.strip()
        if not line:
            continue
        try:
            events.append(json.loads(line))
        except (json.JSONDecodeError, TypeError):
            continue

    if not events:
        return ""

    parts: list[str] = []
    last_goal = ""
    last_outcome = ""
    last_stack = ""
    last_screenshot = ""
    artifacts: list[str] = []

    for ev in events:
        kind = ev.get("event") or ""
        if kind == "session_start":
            last_goal = (ev.get("goal") or "").strip()[:200]
        elif kind == "plan":
            last_stack = (ev.get("stack") or "").strip()[:150]
        elif kind == "screenshot_feedback":
            last_screenshot = (ev.get("summary") or "").strip()[:300]
        elif kind == "session_end":
            last_outcome = (ev.get("outcome") or "").strip()
            arts = ev.get("artifacts")
            if isinstance(arts, list):
                artifacts = [str(a) for a in arts[:10]]
            elif isinstance(arts, str):
                artifacts = [arts]

    if last_goal:
        parts.append(f"Last goal: {last_goal}")
    if last_stack:
        parts.append(f"Stack: {last_stack}")
    if last_outcome:
        parts.append(f"Last outcome: {last_outcome}")
    if last_screenshot:
        parts.append(f"Last UI feedback: {last_screenshot}")
    if artifacts:
        parts.append("Main files: " + ", ".join(artifacts[-5:]))

    summary = "\n".join(parts).strip()
    if len(summary) > max_chars:
        summary = summary[: max_chars - 3] + "..."
    return summary
