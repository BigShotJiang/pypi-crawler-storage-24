"""Session management for OpenArtemis."""

import hashlib
import json
import os
import secrets
from datetime import datetime, timedelta
from pathlib import Path

from openartemis.auth.db import DB_PATH, DATA_DIR, SESSION_FILE, get_user_by_id
from openartemis.auth.passwords import verify_password


SESSION_DAYS = 7


def _hash_token(token: str) -> str:
    return hashlib.sha256(token.encode()).hexdigest()


def has_active_session(user_id: int) -> bool:
    """Return True if user already has a valid (non-expired) session in the DB."""
    import sqlite3
    conn = sqlite3.connect(DB_PATH)
    try:
        cur = conn.execute(
            "SELECT COUNT(*) FROM sessions WHERE user_id = ? AND expires_at > datetime('now')",
            (user_id,),
        )
        return cur.fetchone()[0] > 0
    finally:
        conn.close()


def create_session(user_id: int) -> str:
    """Create session for user. Revokes all previous sessions first (single-session enforcement)."""
    token = secrets.token_urlsafe(32)
    token_hash = _hash_token(token)
    expires = datetime.utcnow() + timedelta(days=SESSION_DAYS)

    import sqlite3
    conn = sqlite3.connect(DB_PATH)
    try:
        conn.execute("DELETE FROM sessions WHERE user_id = ?", (user_id,))
        conn.execute(
            "INSERT INTO sessions (user_id, token_hash, expires_at) VALUES (?, ?, ?)",
            (user_id, token_hash, expires.isoformat()),
        )
        conn.commit()
    finally:
        conn.close()

    DATA_DIR.mkdir(parents=True, exist_ok=True)
    with open(SESSION_FILE, "w", encoding="utf-8") as f:
        json.dump({"token": token, "user_id": user_id}, f)
    return token


def get_session_user() -> dict | None:
    """Get current user from session file. Returns user dict or None."""
    if not SESSION_FILE.exists():
        return None
    try:
        with open(SESSION_FILE, encoding="utf-8") as f:
            data = json.load(f)
        if not isinstance(data, dict):
            SESSION_FILE.unlink(missing_ok=True)
            return None
        token = data.get("token")
        user_id = data.get("user_id")
        if not token or not user_id:
            return None
    except (json.JSONDecodeError, OSError, AttributeError):
        try:
            SESSION_FILE.unlink(missing_ok=True)
        except OSError:
            pass
        return None

    import sqlite3
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    try:
        token_hash = _hash_token(token)
        cur = conn.execute(
            "SELECT user_id, expires_at FROM sessions WHERE token_hash = ?",
            (token_hash,),
        )
        row = cur.fetchone()
        if not row:
            return None
        expires = datetime.fromisoformat(row["expires_at"])
        if expires < datetime.utcnow():
            conn.execute("DELETE FROM sessions WHERE token_hash = ?", (token_hash,))
            conn.commit()
            return None
        user = get_user_by_id(row["user_id"])
        return user
    finally:
        conn.close()


def revoke_session() -> None:
    """Remove current session from file and DB."""
    if SESSION_FILE.exists():
        try:
            with open(SESSION_FILE, encoding="utf-8") as f:
                data = json.load(f)
            token = data.get("token", "")
            if token:
                import sqlite3
                conn = sqlite3.connect(DB_PATH)
                try:
                    conn.execute("DELETE FROM sessions WHERE token_hash = ?", (_hash_token(token),))
                    conn.commit()
                finally:
                    conn.close()
        except Exception:
            pass
        try:
            SESSION_FILE.unlink()
        except OSError:
            pass
