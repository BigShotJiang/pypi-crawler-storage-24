"""Hook registry for agent lifecycle events. Hooks can deny an action by returning 'deny' or (for scripts) exiting non-zero."""

import json
import os
import subprocess
from pathlib import Path
from typing import Any, Callable

CONFIG_DIR = Path.home() / ".openartemis"
HOOKS_FILE = CONFIG_DIR / "hooks.json"

# event -> list of (callable or script path)
_registry: dict[str, list[Callable[..., Any] | str]] = {
    "session_start": [],
    "session_end": [],
    "before_edit": [],
    "after_edit": [],
    "before_run_cmd": [],
    "after_run_cmd": [],
    "plan_approved": [],
}


def register_hook(event: str, callback: Callable[..., Any] | str) -> None:
    """Register a hook for an event. callback is a callable(**kwargs) or path to a script."""
    if event not in _registry:
        _registry[event] = []
    _registry[event].append(callback)


def _run_script(script_path: str, event: str, env_extra: dict[str, str]) -> bool:
    """Run a script; return False if it exits non-zero (deny)."""
    path = Path(script_path).expanduser().resolve()
    if not path.exists():
        return True
    env = os.environ.copy()
    env["OPENARTEMIS_EVENT"] = event
    for k, v in env_extra.items():
        env[k] = str(v)
    try:
        result = subprocess.run(
            [str(path)] if path.suffix != ".py" else [os.environ.get("PYTHON", "python"), str(path)],
            env=env,
            cwd=os.getcwd(),
            timeout=60,
            capture_output=True,
        )
        return result.returncode == 0
    except Exception:
        return False


def fire(event: str, **kwargs: Any) -> bool:
    """
    Run all hooks for the event. Return False if any hook denied (returned 'deny' or script exit != 0).
    """
    if event not in _registry:
        return True
    env_extra = {f"OPENARTEMIS_{k.upper()}": str(v) for k, v in kwargs.items()}
    for cb in _registry[event]:
        if callable(cb):
            try:
                out = cb(**kwargs)
                if out == "deny":
                    return False
            except Exception:
                return False
        elif isinstance(cb, str):
            if not _run_script(cb, event, env_extra):
                return False
    # Load hooks from hooks.json (scripts only)
    if HOOKS_FILE.exists():
        try:
            data = json.loads(HOOKS_FILE.read_text(encoding="utf-8"))
            for script in data.get(event, []):
                if not _run_script(script, event, env_extra):
                    return False
        except (json.JSONDecodeError, OSError):
            pass
    return True


def list_hooks() -> dict[str, list[str]]:
    """Return event -> list of registered hook descriptions (for CLI)."""
    out: dict[str, list[str]] = {ev: [] for ev in _registry}
    for ev, hooks in _registry.items():
        for h in hooks:
            if callable(h):
                out[ev].append(f"<{getattr(h, '__name__', 'callable')}>")
            else:
                out[ev].append(str(h))
    if HOOKS_FILE.exists():
        try:
            data = json.loads(HOOKS_FILE.read_text(encoding="utf-8"))
            for ev, scripts in data.items():
                if ev not in out:
                    out[ev] = []
                for s in scripts:
                    out[ev].append(s)
        except (json.JSONDecodeError, OSError):
            pass
    return out
