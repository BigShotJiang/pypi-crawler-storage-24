"""O3DE Bridge — installation, project management, editor control, and build pipeline.

This module handles all direct interaction with the Open 3D Engine (O3DE):
- Discovering/installing O3DE from offline packages
- Creating and configuring projects
- Enabling gems (PythonEditorBindings, PhysX, Atom, etc.)
- Injecting and executing Python automation scripts in the editor
- Building and exporting games
"""

import json
import logging
import os
import shutil
import subprocess
import sys
import time
if sys.platform == "win32":
    import winreg  # type: ignore[import]
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

logger = logging.getLogger(__name__)

# Default O3DE paths
O3DE_REGISTRY_KEY = r"SOFTWARE\O3DE"
O3DE_ENV_VAR = "O3DE_PATH"
O3DE_DEFAULT_INSTALL = Path("C:/O3DE/25.10.2")
O3DE_OFFLINE_INSTALLER = Path("C:/Dev/Detective/ArtemisEngine/o3de_installer_2510_2-offline")

# Required gems for agent automation
REQUIRED_GEMS = [
    "EditorPythonBindings",
    "Atom",
    "PhysX",
    "ScriptCanvas",
    "LandscapeCanvas",
    "WhiteBox",
    "StartingPointInput",
]

# O3DE project templates
TEMPLATES = {
    "Standard": "DefaultProject",
    "Minimal": "MinimalProject",
    "Multiplayer": "MultiplayerSample",
}


class O3DEBridge:
    """Bridge between Artemis and O3DE engine."""

    def __init__(self, o3de_path: Optional[Path] = None):
        self.o3de_path: Optional[Path] = o3de_path
        self.project_path: Optional[Path] = None
        self.editor_process: Optional[subprocess.Popen] = None
        self._scripts_dir: Optional[Path] = None
        self._python_ready: bool = False

        if self.o3de_path is None:
            self.o3de_path = self._discover_o3de()

    # ── Discovery ──

    def _discover_o3de(self) -> Optional[Path]:
        """Find O3DE installation via env var, registry, or common paths."""
        # 1. Environment variable
        env = os.environ.get(O3DE_ENV_VAR, "").strip()
        if env:
            p = Path(env)
            if self._is_valid_o3de(p):
                logger.info("O3DE found via env: %s", p)
                return p

        # 2. Windows registry
        try:
            with winreg.OpenKey(winreg.HKEY_LOCAL_MACHINE, O3DE_REGISTRY_KEY) as key:
                val, _ = winreg.QueryValueEx(key, "InstallPath")
                p = Path(val)
                if self._is_valid_o3de(p):
                    logger.info("O3DE found via registry: %s", p)
                    return p
        except (OSError, FileNotFoundError):
            pass

        # 3. Common paths
        candidates = [
            O3DE_DEFAULT_INSTALL,
            Path("C:/O3DE"),
            Path("C:/Program Files/O3DE"),
            Path("C:/Program Files (x86)/O3DE"),
            Path(os.environ.get("USERPROFILE", "")) / "O3DE",
            Path("D:/O3DE"),
            Path("E:/O3DE"),
        ]
        for p in candidates:
            if self._is_valid_o3de(p):
                logger.info("O3DE found at: %s", p)
                return p

        # 4. Scan for version-specific installations
        o3de_base = Path("C:/O3DE")
        if o3de_base.exists():
            for item in o3de_base.iterdir():
                if item.is_dir() and self._is_valid_o3de(item):
                    logger.info("O3DE found in versioned path: %s", item)
                    return item

        # 5. Search common drive roots for O3DE folders
        for drive in ["C:", "D:", "E:"]:
            drive_path = Path(drive)
            if drive_path.exists():
                for item in drive_path.iterdir():
                    if item.is_dir() and "o3de" in item.name.lower():
                        if self._is_valid_o3de(item):
                            logger.info("O3DE found in: %s", item)
                            return item
                        # Also check versioned subdirectories
                        for sub in item.iterdir():
                            if sub.is_dir() and self._is_valid_o3de(sub):
                                logger.info("O3DE found in versioned subdirectory: %s", sub)
                                return sub

        logger.warning("O3DE installation not found")
        return None

    @staticmethod
    def _is_valid_o3de(path: Path) -> bool:
        """Check if path contains a valid O3DE installation."""
        if not path.exists():
            return False
        # Look for o3de executable or scripts
        markers = [
            "o3de.bat", "o3de.exe", "scripts/o3de.py", "python/python.cmd",
            "bin/Editor.exe", "cmake", "engine"
        ]
        return any((path / m).exists() for m in markers)

    def check_dependencies(self) -> Dict[str, bool]:
        """Check if required dependencies (cmake, etc.) are available."""
        deps = {}
        
        # Check for cmake in system PATH
        try:
            result = subprocess.run(["cmake", "--version"], capture_output=True, text=True, timeout=5)
            deps["cmake"] = result.returncode == 0
            deps["system_cmake"] = result.returncode == 0
        except (FileNotFoundError, subprocess.TimeoutExpired):
            deps["cmake"] = False
            deps["system_cmake"] = False
            
        # Check for O3DE's bundled cmake
        if self.o3de_path:
            cmake_paths = [
                self.o3de_path / "cmake" / "bin" / "cmake.exe",
                self.o3de_path / "cmake" / "runtime" / "bin" / "cmake.exe",
                self.o3de_path / "3rdParty" / "cmake" / "bin" / "cmake.exe",
            ]
            for cmake_path in cmake_paths:
                if cmake_path.exists():
                    deps["o3de_cmake"] = True
                    deps["cmake"] = True  # Consider it available if O3DE has it
                    break
                    
        return deps

    def set_o3de_path(self, path: Path) -> bool:
        """Manually set O3DE path and validate it."""
        if self._is_valid_o3de(path):
            self.o3de_path = path
            self._python_ready = False
            logger.info("O3DE path manually set to: %s", path)
            return True
        return False

    @property
    def is_installed(self) -> bool:
        return self.o3de_path is not None and self._is_valid_o3de(self.o3de_path)

    def _get_cmake(self) -> str:
        """Return the absolute path to cmake.exe (bundled or system)."""
        if self.o3de_path:
            cmake_dirs = [
                self.o3de_path / "cmake" / "runtime" / "bin",
                self.o3de_path / "cmake" / "bin",
                self.o3de_path / "3rdParty" / "cmake" / "bin",
            ]
            for d in cmake_dirs:
                cmake_exe = d / "cmake.exe"
                if cmake_exe.exists():
                    return str(cmake_exe)
        # Fallback to system cmake
        found = shutil.which("cmake")
        if found:
            return found
        raise FileNotFoundError(
            "cmake not found. Install cmake from https://cmake.org/download/ "
            "or ensure O3DE's bundled cmake exists."
        )

    def _get_env(self) -> Dict[str, str]:
        """Return an env dict with O3DE's bundled cmake in PATH."""
        env = os.environ.copy()
        if not self.o3de_path:
            return env
        cmake_dirs = [
            self.o3de_path / "cmake" / "runtime" / "bin",
            self.o3de_path / "cmake" / "bin",
            self.o3de_path / "3rdParty" / "cmake" / "bin",
        ]
        for d in cmake_dirs:
            if (d / "cmake.exe").exists():
                env["PATH"] = str(d) + os.pathsep + env.get("PATH", "")
                break
        return env

    def ensure_engine_registered(
        self,
        on_status: Optional[Any] = None,
    ) -> bool:
        """Ensure the O3DE engine is registered in the user manifest."""
        if not self.o3de_path:
            return False
        
        def _status(msg: str):
            if on_status:
                on_status(msg)
            logger.info(msg)

        # Check if engine is already registered
        manifest_path = Path.home() / ".o3de" / "o3de_manifest.json"
        try:
            if manifest_path.exists():
                manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
                engines = manifest.get("engines", [])
                # Check if our engine path is already registered
                for engine in engines:
                    if Path(engine).resolve() == self.o3de_path.resolve():
                        _status("Engine already registered.")
                        return True
        except Exception as e:
            _status(f"Warning: could not read manifest: {e}")

        # Register the engine
        _status("Registering O3DE engine...")
        cli = self.get_o3de_cli()
        env = self._get_env()
        try:
            result = subprocess.run(
                [cli, "register", "--this-engine"],
                capture_output=True, text=True, timeout=120,
                cwd=str(self.o3de_path),
                env=env,
            )
            if result.returncode == 0:
                _status("Engine registered successfully.")
                return True
            else:
                err = (result.stdout.strip() + "\n" + result.stderr.strip()).strip()
                _status(f"Engine registration failed: {err[:200]}")
                return False
        except (FileNotFoundError, subprocess.TimeoutExpired, OSError) as e:
            _status(f"Engine registration error: {e}")
            return False

    def ensure_o3de_python(
        self,
        on_status: Optional[Any] = None,
    ) -> bool:
        """Bootstrap O3DE's internal Python venv if not already set up.

        O3DE ships its own Python and requires a venv to be created via
        ``get_python.bat`` before the CLI (``o3de.bat``) can work.
        """
        if self._python_ready:
            return True
        if not self.o3de_path:
            return False

        def _status(msg: str):
            if on_status:
                on_status(msg)
            logger.info(msg)

        get_python = self.o3de_path / "python" / "get_python.bat"
        if not get_python.exists():
            _status("get_python.bat not found — assuming Python is ready")
            self._python_ready = True
            return True

        # Quick check: does the venv already exist?
        env = self._get_env()
        try:
            result = subprocess.run(
                [str(self.o3de_path / "scripts" / "o3de.bat"), "--help"],
                capture_output=True, text=True, timeout=30, env=env,
            )
            if result.returncode == 0:
                self._python_ready = True
                return True
        except (FileNotFoundError, subprocess.TimeoutExpired, OSError) as e:
            _status(f"o3de.bat check skipped: {e}")

        _status("Setting up O3DE Python environment (one-time, may take a minute)...")
        try:
            result = subprocess.run(
                [str(get_python)],
                capture_output=True, text=True, timeout=600,
                cwd=str(self.o3de_path), env=env,
            )
        except (FileNotFoundError, OSError) as e:
            _status(f"get_python.bat failed to run: {e}")
            return False
        except subprocess.TimeoutExpired:
            _status("Python setup timed out (10 min)")
            return False
        if result.returncode != 0:
            err = (result.stdout + result.stderr)[:500]
            _status(f"Python setup failed: {err}")
            return False

        self._python_ready = True
        _status("O3DE Python environment ready.")
        return True

    def get_o3de_cli(self) -> str:
        """Return the o3de CLI command."""
        if not self.o3de_path:
            raise RuntimeError("O3DE not installed")
        for name in ["o3de.bat", "scripts/o3de.bat", "scripts/o3de.py"]:
            p = self.o3de_path / name
            if p.exists():
                return str(p)
        raise RuntimeError(f"o3de CLI not found in {self.o3de_path}")

    def get_editor_exe(self) -> str:
        """Return the O3DE Editor executable path."""
        if not self.o3de_path:
            raise RuntimeError("O3DE not installed")
        candidates = [
            self.o3de_path / "bin" / "Windows" / "profile" / "Default" / "Editor.exe",
            self.o3de_path / "bin" / "profile" / "Editor.exe",
            self.o3de_path / "Editor.exe",
        ]
        for c in candidates:
            if c.exists():
                return str(c)
        # Glob fallback
        found = list(self.o3de_path.rglob("Editor.exe"))
        if found:
            return str(found[0])
        raise RuntimeError(f"Editor.exe not found in {self.o3de_path}")

    # ── Installation ──

    def install_from_offline(
        self,
        installer_dir: Optional[Path] = None,
        on_status: Optional[Any] = None,
    ) -> bool:
        """Install O3DE from the offline installer package (MSI or EXE)."""
        installer_dir = installer_dir or O3DE_OFFLINE_INSTALLER
        if not installer_dir.exists():
            raise FileNotFoundError(f"Installer not found: {installer_dir}")

        def _status(msg: str):
            if on_status:
                on_status(msg)
            logger.info(msg)

        # Prefer MSI for silent install
        msi = list(installer_dir.glob("*.msi"))
        exe = list(installer_dir.glob("*_installer.exe"))

        if msi:
            _status(f"Installing O3DE via MSI: {msi[0].name} ...")
            result = subprocess.run(
                ["msiexec", "/i", str(msi[0]), "/quiet", "/norestart",
                 f"INSTALLDIR={O3DE_DEFAULT_INSTALL}"],
                capture_output=True, text=True, timeout=1800,
            )
            if result.returncode == 0:
                self.o3de_path = O3DE_DEFAULT_INSTALL
                _status("O3DE installed successfully.")
                return True
            _status(f"MSI install failed (exit {result.returncode}): {result.stderr[:300]}")

        if exe:
            _status(f"Installing O3DE via EXE: {exe[0].name} ...")
            result = subprocess.run(
                [str(exe[0]), "/S", f"/D={O3DE_DEFAULT_INSTALL}"],
                capture_output=True, text=True, timeout=1800,
            )
            if result.returncode == 0:
                self.o3de_path = O3DE_DEFAULT_INSTALL
                _status("O3DE installed successfully.")
                return True
            _status(f"EXE install failed (exit {result.returncode}): {result.stderr[:300]}")

        return False

    # ── Project Management ──

    def create_project(
        self,
        name: str,
        project_root: Optional[Path] = None,
        template: str = "Standard",
        on_status: Optional[Any] = None,
    ) -> Path:
        """Create a new O3DE project and enable required gems."""
        if not self.is_installed:
            raise RuntimeError("O3DE is not installed")

        # Ensure O3DE Python venv is bootstrapped
        if not self.ensure_o3de_python(on_status=on_status):
            raise RuntimeError(
                "O3DE Python environment could not be set up.\n"
                f"Try running manually: {self.o3de_path / 'python' / 'get_python.bat'}"
            )

        env = self._get_env()

        root = project_root or Path.home() / "O3DEProjects"
        root.mkdir(parents=True, exist_ok=True)
        project_path = root / name

        def _status(msg: str):
            if on_status:
                on_status(msg)
            logger.info(msg)

        _status(f"Creating O3DE project '{name}' ...")
        cli = self.get_o3de_cli()
        tpl = TEMPLATES.get(template, template)

        try:
            result = subprocess.run(
                [cli, "create-project",
                 "--project-path", str(project_path),
                 "--template-name", tpl],
                capture_output=True, text=True, timeout=300,
                env=env,
            )
        except FileNotFoundError:
            raise RuntimeError(f"O3DE CLI not found: {cli}")
        except subprocess.TimeoutExpired:
            raise RuntimeError("Project creation timed out (5 min)")
        if result.returncode != 0:
            err = (result.stdout.strip() + "\n" + result.stderr.strip()).strip()
            raise RuntimeError(f"Failed to create project: {err[:500]}")

        self.project_path = project_path
        self._scripts_dir = project_path / "Editor" / "Scripts"
        self._scripts_dir.mkdir(parents=True, exist_ok=True)

        # Enable required gems
        for gem in REQUIRED_GEMS:
            _status(f"Enabling gem: {gem}")
            try:
                subprocess.run(
                    [cli, "enable-gem", "--gem-name", gem,
                     "--project-path", str(project_path)],
                    capture_output=True, text=True, timeout=120,
                    env=env,
                )
            except (FileNotFoundError, subprocess.TimeoutExpired, OSError):
                _status(f"Warning: failed to enable gem {gem}")

        _status(f"Project created at {project_path}")
        return project_path

    def open_project(self, project_path: Path) -> None:
        """Open an existing O3DE project."""
        if not project_path.exists():
            raise FileNotFoundError(f"Project not found: {project_path}")
        self.project_path = project_path
        self._scripts_dir = project_path / "Editor" / "Scripts"
        self._scripts_dir.mkdir(parents=True, exist_ok=True)

    def enable_gem(self, gem_name: str) -> bool:
        """Enable a gem for the current project."""
        if not self.project_path:
            raise RuntimeError("No project open")
        cli = self.get_o3de_cli()
        env = self._get_env()
        try:
            result = subprocess.run(
                [cli, "enable-gem", "--gem-name", gem_name,
                 "--project-path", str(self.project_path)],
                capture_output=True, text=True, timeout=120,
                env=env,
            )
            return result.returncode == 0
        except (FileNotFoundError, subprocess.TimeoutExpired, OSError):
            return False

    # ── Editor Script Execution ──

    def write_editor_script(self, script_name: str, content: str) -> Path:
        """Write a Python script into the project's Editor/Scripts directory."""
        if not self._scripts_dir:
            raise RuntimeError("No project open")
        path = self._scripts_dir / script_name
        path.write_text(content, encoding="utf-8")
        return path

    def run_editor_script(self, script_content: str, script_name: str = "artemis_auto.py") -> str:
        """Write and execute a Python script inside the O3DE Editor.

        Launches the editor with --run-python-script if not already running.
        Returns combined stdout/stderr from the editor process start.
        """
        script_path = self.write_editor_script(script_name, script_content)
        return self._launch_editor_with_script(script_path)

    def run_editor_script_file(self, script_path: Path) -> str:
        """Execute an existing Python script in the O3DE Editor."""
        if not script_path.exists():
            raise FileNotFoundError(f"Script not found: {script_path}")
        return self._launch_editor_with_script(script_path)

    def _launch_editor_with_script(self, script_path: Path) -> str:
        """Launch O3DE Editor with a Python script."""
        if not self.project_path:
            raise RuntimeError("No project open")

        editor = self.get_editor_exe()
        cmd = [
            editor,
            f"--project-path={self.project_path}",
            f"--exec-python-script={script_path}",
            "--skip-welcome-screen",
        ]

        try:
            self.editor_process = subprocess.Popen(
                cmd,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                cwd=str(self.project_path),
                creationflags=subprocess.CREATE_NEW_PROCESS_GROUP,
            )
            # Give editor time to start
            time.sleep(3)
            return f"Editor launched (PID {self.editor_process.pid}) with script: {script_path.name}"
        except Exception as e:
            return f"Failed to launch editor: {e}"

    def stop_editor(self) -> None:
        """Stop the running O3DE Editor process."""
        if self.editor_process:
            try:
                self.editor_process.terminate()
                self.editor_process.wait(timeout=15)
            except Exception:
                try:
                    self.editor_process.kill()
                except Exception:
                    pass
            self.editor_process = None

    # ── Script Generation Helpers ──

    def generate_level_script(
        self,
        level_name: str,
        terrain_size: int = 1024,
        use_terrain: bool = True,
    ) -> str:
        """Generate Python script to create a new level."""
        return f"""import azlmbr.legacy.general as general

# Create level: {level_name}
general.idle_enable(True)
general.create_level_no_prompt("{level_name}", {terrain_size}, 1.0, {use_terrain})
general.idle_wait(3.0)
general.save_level()
print("Level '{level_name}' created and saved.")
"""

    def generate_entity_script(
        self,
        entity_name: str,
        components: List[str],
        position: Tuple[float, float, float] = (0.0, 0.0, 0.0),
        parent: Optional[str] = None,
    ) -> str:
        """Generate Python script to create an entity with components."""
        components_code = ""
        for comp in components:
            components_code += f"""
    typeIds = editor.EditorComponentAPIBus(bus.Broadcast, 'FindComponentTypeIdsByEntityType', ["{comp}"], 0)
    if typeIds:
        editor.EditorComponentAPIBus(bus.Broadcast, 'AddComponentsOfType', entity_id, typeIds)
        print(f"  Added component: {comp}")
"""

        parent_code = ""
        if parent:
            parent_code = f"""
    # Set parent
    search_filter = entity.SearchFilter()
    search_filter.names = ["{parent}"]
    parent_ids = entity.SearchBus(bus.Broadcast, 'SearchEntities', search_filter)
    if parent_ids:
        editor.EditorEntityAPIBus(bus.Event, 'SetParent', entity_id, parent_ids[0])
"""

        return f"""import azlmbr.bus as bus
import azlmbr.editor as editor
import azlmbr.entity as entity
import azlmbr.math as math

# Create entity: {entity_name}
entity_id = editor.ToolsApplicationRequestBus(bus.Broadcast, 'CreateNewEntity', entity.EntityId())
editor.EditorEntityAPIBus(bus.Event, 'SetName', entity_id, "{entity_name}")

# Set position
position = math.Vector3({position[0]}, {position[1]}, {position[2]})
editor.TransformBus(bus.Event, 'SetWorldTranslation', entity_id, position)

# Add components
{components_code}
{parent_code}
print("Entity '{entity_name}' created at {position}")
"""

    def generate_lighting_script(
        self,
        light_type: str = "Directional",
        color: Tuple[float, float, float] = (1.0, 1.0, 0.9),
        intensity: float = 4.0,
    ) -> str:
        """Generate Python script to set up scene lighting."""
        return f"""import azlmbr.bus as bus
import azlmbr.editor as editor
import azlmbr.entity as entity
import azlmbr.math as math

# Create {light_type} light
light_id = editor.ToolsApplicationRequestBus(bus.Broadcast, 'CreateNewEntity', entity.EntityId())
editor.EditorEntityAPIBus(bus.Event, 'SetName', light_id, "{light_type}Light")

# Set rotation for directional light
rotation = math.Vector3(-45.0, 0.0, -30.0)
editor.TransformBus(bus.Event, 'SetWorldRotation', light_id, rotation)

# Add {light_type} Light component
typeIds = editor.EditorComponentAPIBus(bus.Broadcast, 'FindComponentTypeIdsByEntityType', ["{light_type} Light"], 0)
if typeIds:
    editor.EditorComponentAPIBus(bus.Broadcast, 'AddComponentsOfType', light_id, typeIds)

# Create global skybox / IBL
sky_id = editor.ToolsApplicationRequestBus(bus.Broadcast, 'CreateNewEntity', entity.EntityId())
editor.EditorEntityAPIBus(bus.Event, 'SetName', sky_id, "Sky")
for comp in ["HDRi Skybox", "Global Skylight (IBL)"]:
    typeIds = editor.EditorComponentAPIBus(bus.Broadcast, 'FindComponentTypeIdsByEntityType', [comp], 0)
    if typeIds:
        editor.EditorComponentAPIBus(bus.Broadcast, 'AddComponentsOfType', sky_id, typeIds)

print("Lighting setup complete: {light_type} light + Sky")
"""

    def generate_physics_script(
        self,
        entity_name: str,
        body_type: str = "Dynamic",
        collider_shape: str = "Box",
    ) -> str:
        """Generate Python script to add physics to an entity."""
        return f"""import azlmbr.bus as bus
import azlmbr.editor as editor
import azlmbr.entity as entity

# Find entity: {entity_name}
search_filter = entity.SearchFilter()
search_filter.names = ["{entity_name}"]
found = entity.SearchBus(bus.Broadcast, 'SearchEntities', search_filter)
if not found:
    print("Entity '{entity_name}' not found!")
else:
    eid = found[0]
    # Add PhysX {body_type} Rigid Body
    for comp in ["PhysX {body_type} Rigid Body", "PhysX {collider_shape} Collider"]:
        typeIds = editor.EditorComponentAPIBus(bus.Broadcast, 'FindComponentTypeIdsByEntityType', [comp], 0)
        if typeIds:
            editor.EditorComponentAPIBus(bus.Broadcast, 'AddComponentsOfType', eid, typeIds)
            print(f"  Added {{comp}} to {entity_name}")
    print("Physics added to '{entity_name}'")
"""

    def generate_terrain_script(
        self,
        size: int = 1024,
        height_scale: float = 100.0,
    ) -> str:
        """Generate Python script to create terrain."""
        return f"""import azlmbr.bus as bus
import azlmbr.editor as editor
import azlmbr.entity as entity
import azlmbr.math as math

# Create terrain entity
terrain_id = editor.ToolsApplicationRequestBus(bus.Broadcast, 'CreateNewEntity', entity.EntityId())
editor.EditorEntityAPIBus(bus.Event, 'SetName', terrain_id, "Terrain")

# Add terrain components
for comp in ["Axis Aligned Box Shape", "Terrain Layer Spawner", "Terrain Height Gradient List",
             "Gradient", "Terrain Surface Gradient List"]:
    typeIds = editor.EditorComponentAPIBus(bus.Broadcast, 'FindComponentTypeIdsByEntityType', [comp], 0)
    if typeIds:
        editor.EditorComponentAPIBus(bus.Broadcast, 'AddComponentsOfType', terrain_id, typeIds)
        print(f"  Added {{comp}}")

# Set terrain size
scale = math.Vector3({size}, {size}, {height_scale})
editor.TransformBus(bus.Event, 'SetLocalScale', terrain_id, scale)

print("Terrain created: {size}x{size}, height scale {height_scale}")
"""

    # ── Headless Prefab Writing (no Editor.exe needed) ──

    def _new_uuid(self) -> str:
        """Generate a UUID string for O3DE entity/component IDs."""
        import uuid
        return str(uuid.uuid4())

    def _ensure_level_dir(self, level_name: str) -> Path:
        """Ensure the level directory exists and return its path."""
        if not self.project_path:
            raise RuntimeError("No project open")
        level_dir = self.project_path / "Levels" / level_name
        level_dir.mkdir(parents=True, exist_ok=True)
        return level_dir

    def _get_prefab_path(self, level_name: str) -> Path:
        """Return the prefab file path for a level."""
        return self._ensure_level_dir(level_name) / f"{level_name}.prefab"

    def _load_or_create_prefab(self, level_name: str) -> dict:
        """Load an existing level prefab or create a new empty one."""
        prefab_path = self._get_prefab_path(level_name)
        if prefab_path.exists():
            try:
                return json.loads(prefab_path.read_text(encoding="utf-8"))
            except (json.JSONDecodeError, OSError):
                pass

        container_id = self._new_uuid()
        return {
            "ContainerEntity": {
                "Id": container_id,
                "Name": level_name,
                "Components": {
                    "TransformComponent": {
                        "$type": "TransformComponent",
                        "Id": self._new_uuid(),
                        "Parent Entity": "",
                        "Transform Data": {
                            "Translate": [0.0, 0.0, 0.0],
                            "Rotate": [0.0, 0.0, 0.0],
                            "Scale": [1.0, 1.0, 1.0],
                        },
                    }
                },
            },
            "Entities": {},
            "Instances": {},
        }

    def _save_prefab(self, level_name: str, prefab: dict) -> Path:
        """Write the prefab JSON to disk."""
        prefab_path = self._get_prefab_path(level_name)
        prefab_path.write_text(json.dumps(prefab, indent=2), encoding="utf-8")
        return prefab_path

    def _add_entity_to_prefab(
        self,
        prefab: dict,
        name: str,
        components: List[str],
        position: Tuple[float, float, float] = (0.0, 0.0, 0.0),
        parent: Optional[str] = None,
        extra_component_data: Optional[Dict[str, Any]] = None,
    ) -> str:
        """Add an entity to a prefab dict. Returns the entity UUID."""
        entity_id = self._new_uuid()
        comp_dict: Dict[str, Any] = {
            "TransformComponent": {
                "$type": "TransformComponent",
                "Id": self._new_uuid(),
                "Parent Entity": parent or "",
                "Transform Data": {
                    "Translate": list(position),
                    "Rotate": [0.0, 0.0, 0.0],
                    "Scale": [1.0, 1.0, 1.0],
                },
            }
        }
        for comp_name in components:
            comp_key = comp_name.replace(" ", "")
            comp_dict[comp_key] = {
                "$type": comp_name,
                "Id": self._new_uuid(),
            }

        if extra_component_data:
            for k, v in extra_component_data.items():
                if k in comp_dict and isinstance(v, dict):
                    comp_dict[k].update(v)
                else:
                    comp_dict[k] = v

        prefab["Entities"][entity_id] = {
            "Id": entity_id,
            "Name": name,
            "Components": comp_dict,
        }
        return entity_id

    # ── Public Headless API ──

    def write_level_prefab(
        self,
        level_name: str,
        terrain: bool = False,
        terrain_size: int = 512,
        height_scale: float = 20.0,
        lighting: str = "bright",
    ) -> str:
        """Create a level prefab file on disk (headless, no editor)."""
        prefab = self._load_or_create_prefab(level_name)

        # Add default camera
        self._add_entity_to_prefab(prefab, "MainCamera", ["Camera"], position=(0, 5, -10))

        # Lighting
        if lighting == "dark":
            self._add_entity_to_prefab(
                prefab, "AmbientLight", ["Point Light"],
                position=(0, 10, 0),
            )
        elif lighting == "dramatic":
            self._add_entity_to_prefab(
                prefab, "SunLight", ["Directional Light"],
                position=(0, 50, 0),
            )
            self._add_entity_to_prefab(prefab, "Sky", ["HDRi Skybox", "Global Skylight (IBL)"])
        else:  # bright
            self._add_entity_to_prefab(
                prefab, "SunLight", ["Directional Light"],
                position=(0, 50, 0),
            )
            self._add_entity_to_prefab(prefab, "Sky", ["HDRi Skybox", "Global Skylight (IBL)"])

        # Terrain
        if terrain:
            self._add_entity_to_prefab(
                prefab, "Terrain",
                ["Axis Aligned Box Shape", "Terrain Layer Spawner",
                 "Terrain Height Gradient List", "Terrain Surface Gradient List"],
                extra_component_data={
                    "AxisAlignedBoxShape": {
                        "Dimensions": [terrain_size, terrain_size, height_scale],
                    }
                },
            )

        path = self._save_prefab(level_name, prefab)
        return f"Level '{level_name}' created: {path}"

    def write_entity_to_level(
        self,
        level_name: str,
        entity_name: str,
        components: List[str],
        position: Tuple[float, float, float] = (0.0, 0.0, 0.0),
        parent: Optional[str] = None,
    ) -> str:
        """Add an entity to an existing level prefab (headless)."""
        if not level_name:
            level_name = "Main"
        prefab = self._load_or_create_prefab(level_name)
        self._add_entity_to_prefab(prefab, entity_name, components, position, parent)
        self._save_prefab(level_name, prefab)
        return f"Entity '{entity_name}' added to level '{level_name}' with components: {components}"

    def add_physics_to_entity(
        self,
        level_name: str,
        entity_name: str,
        body_type: str = "Dynamic",
        collider_shape: str = "Box",
    ) -> str:
        """Add physics components to an existing entity in a level prefab (headless)."""
        if not level_name:
            level_name = "Main"
        prefab = self._load_or_create_prefab(level_name)

        # Find entity and add physics components
        for eid, ent in prefab.get("Entities", {}).items():
            if ent.get("Name") == entity_name:
                comps = ent.get("Components", {})
                comps[f"PhysX{body_type}RigidBody"] = {
                    "$type": f"PhysX {body_type} Rigid Body",
                    "Id": self._new_uuid(),
                }
                comps[f"PhysX{collider_shape}Collider"] = {
                    "$type": f"PhysX {collider_shape} Collider",
                    "Id": self._new_uuid(),
                }
                self._save_prefab(level_name, prefab)
                return f"Physics added to '{entity_name}': {body_type} body + {collider_shape} collider"

        return f"Entity '{entity_name}' not found in level '{level_name}'"

    def set_material_on_entity(
        self,
        level_name: str,
        entity_name: str,
        material_path: str,
    ) -> str:
        """Set material on an entity in a level prefab (headless)."""
        if not level_name:
            level_name = "Main"
        prefab = self._load_or_create_prefab(level_name)

        for eid, ent in prefab.get("Entities", {}).items():
            if ent.get("Name") == entity_name:
                comps = ent.get("Components", {})
                comps["MaterialComponent"] = {
                    "$type": "Material",
                    "Id": self._new_uuid(),
                    "Default Material": {"Material Asset": material_path},
                }
                self._save_prefab(level_name, prefab)
                return f"Material '{material_path}' set on '{entity_name}'"

        return f"Entity '{entity_name}' not found in level '{level_name}'"

    def get_current_level_name(self) -> str:
        """Return the current/default level name."""
        if not self.project_path:
            return "Main"
        levels_dir = self.project_path / "Levels"
        if levels_dir.exists():
            for d in levels_dir.iterdir():
                if d.is_dir() and (d / f"{d.name}.prefab").exists():
                    return d.name
        return "Main"

    # ── Build Pipeline ──

    def build_game(
        self,
        platform: str = "PC",
        config: str = "profile",
        on_status: Optional[Any] = None,
    ) -> Tuple[bool, str]:
        """Build the game for the specified platform."""
        if not self.project_path:
            raise RuntimeError("No project open")

        def _status(msg: str):
            if on_status:
                on_status(msg)
            logger.info(msg)

        _status(f"Building game for {platform} ({config})...")

        # Ensure engine is registered before building
        if not self.ensure_engine_registered(on_status=on_status):
            return False, "Engine registration failed. Cannot build."

        env = self._get_env()

        try:
            cmake = self._get_cmake()
        except FileNotFoundError as e:
            return False, str(e)

        _status(f"Using cmake: {cmake}")

        # Use cmake to build
        build_dir = self.project_path / "build"
        build_dir.mkdir(exist_ok=True)

        # Configure
        _status("Configuring build...")
        configure_cmd = [
            cmake,
            "-B", str(build_dir),
            "-S", str(self.project_path),
            f"-DLY_3RDPARTY_PATH={self.o3de_path / '3rdParty'}",
            "-G", "Visual Studio 17 2022",
        ]
        try:
            result = subprocess.run(configure_cmd, capture_output=True, text=True, timeout=600, env=env)
        except FileNotFoundError:
            return False, f"cmake not found at: {cmake}"
        except subprocess.TimeoutExpired:
            return False, "Configure timed out (10 min)"
        if result.returncode != 0:
            err = (result.stdout.strip() + "\n" + result.stderr.strip()).strip()
            return False, f"Configure failed: {err[:500]}"

        # Build
        _status("Compiling...")
        build_cmd = [
            cmake,
            "--build", str(build_dir),
            "--config", config,
            "--target", f"{self.project_path.name}.GameLauncher",
            "-j", str(os.cpu_count() or 4),
        ]
        try:
            result = subprocess.run(build_cmd, capture_output=True, text=True, timeout=3600, env=env)
        except FileNotFoundError:
            return False, f"cmake not found at: {cmake}"
        except subprocess.TimeoutExpired:
            return False, "Build timed out (60 min)"
        if result.returncode != 0:
            err = (result.stdout.strip() + "\n" + result.stderr.strip()).strip()
            return False, f"Build failed: {err[:500]}"

        _status("Build complete!")
        return True, f"Built {self.project_path.name} for {platform} ({config})"

    def get_game_launcher(self) -> Optional[Path]:
        """Find the built game launcher executable."""
        if not self.project_path:
            return None
        name = self.project_path.name
        candidates = [
            self.project_path / "build" / "bin" / "profile" / f"{name}.GameLauncher.exe",
            self.project_path / "build" / "bin" / "Release" / f"{name}.GameLauncher.exe",
        ]
        for c in candidates:
            if c.exists():
                return c
        found = list((self.project_path / "build").rglob(f"*GameLauncher.exe"))
        return found[0] if found else None

    def launch_game(self) -> Optional[subprocess.Popen]:
        """Launch the built game."""
        launcher = self.get_game_launcher()
        if not launcher:
            raise FileNotFoundError("Game launcher not found. Build the game first.")
        return subprocess.Popen(
            [str(launcher)],
            cwd=str(launcher.parent),
            creationflags=subprocess.CREATE_NEW_PROCESS_GROUP,
        )

    # ── Project Info ──

    def scan_existing_projects(self, projects_root: Optional[Path] = None) -> List[Dict[str, Any]]:
        """Scan for existing O3DE projects and return their info."""
        root = projects_root or Path.home() / "O3DEProjects"
        projects: List[Dict[str, Any]] = []
        if not root.exists():
            return projects
        for d in sorted(root.iterdir()):
            if d.is_dir() and (d / "project.json").exists():
                info: Dict[str, Any] = {"name": d.name, "path": str(d)}
                try:
                    pj = json.loads((d / "project.json").read_text(encoding="utf-8"))
                    info["display_name"] = pj.get("project_name", d.name)
                except Exception:
                    info["display_name"] = d.name
                # Quick stats
                scripts_dir = d / "Editor" / "Scripts"
                info["scripts"] = sum(1 for _ in scripts_dir.rglob("*.py")) if scripts_dir.exists() else 0
                lua_dir = d / "Scripts"
                info["lua_scripts"] = sum(1 for _ in lua_dir.rglob("*.lua")) if lua_dir.exists() else 0
                levels_dir = d / "Levels"
                info["levels"] = sum(1 for _ in levels_dir.iterdir() if _.is_dir()) if levels_dir.exists() else 0
                build_dir = d / "build"
                info["built"] = build_dir.exists() and any(build_dir.rglob("*GameLauncher.exe"))
                projects.append(info)
        return projects

    def get_project_info(self) -> Dict[str, Any]:
        """Get information about the current project."""
        if not self.project_path:
            return {"status": "no_project"}

        info: Dict[str, Any] = {
            "name": self.project_path.name,
            "path": str(self.project_path),
            "o3de_path": str(self.o3de_path) if self.o3de_path else None,
            "installed": self.is_installed,
        }

        # Count assets (check multiple possible locations)
        asset_count = 0
        for adir in ["Assets", "assets", "Textures", "textures"]:
            ad = self.project_path / adir
            if ad.exists():
                asset_count += sum(1 for _ in ad.rglob("*") if _.is_file())
        info["asset_count"] = asset_count

        # Count scripts (Lua in Scripts/, Python in Editor/Scripts/)
        script_count = 0
        lua_dir = self.project_path / "Scripts"
        if lua_dir.exists():
            script_count += sum(1 for _ in lua_dir.rglob("*.lua"))
        editor_scripts_dir = self.project_path / "Editor" / "Scripts"
        if editor_scripts_dir.exists():
            script_count += sum(1 for _ in editor_scripts_dir.rglob("*.py"))
        info["script_count"] = script_count

        # Count levels
        levels_dir = self.project_path / "Levels"
        if levels_dir.exists():
            info["level_count"] = sum(1 for _ in levels_dir.iterdir() if _.is_dir())

        # Check build
        launcher = self.get_game_launcher()
        info["built"] = launcher is not None
        if launcher:
            info["launcher_path"] = str(launcher)

        return info
