"""Language Server Protocol (LSP) manager stubs for the IDE runtime."""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Dict, List, Optional


@dataclass(slots=True)
class LSPServerInfo:
    """Metadata about a language server attached to a workspace."""

    language_id: str
    command: str
    args: list[str]
    workspace_root: Path


class LSPManager:
    """Track and configure LSP servers per workspace.

    The initial version only keeps metadata; the Theia backend is
    responsible for actually spawning the language servers.
    """

    def __init__(self) -> None:
        self._servers: Dict[str, List[LSPServerInfo]] = {}

    def register_server(self, workspace: Path, info: LSPServerInfo) -> None:
        key = str(workspace.resolve())
        self._servers.setdefault(key, []).append(info)

    def list_servers(self, workspace: Path) -> list[LSPServerInfo]:
        return list(self._servers.get(str(workspace.resolve()), []))


__all__ = ["LSPManager", "LSPServerInfo"]

