"""Debug Adapter Protocol (DAP) manager stubs for the IDE runtime."""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Dict, Optional


@dataclass(slots=True)
class DebugSessionInfo:
    """Metadata about a debug session."""

    id: str
    workspace_root: Path
    config_id: str


class DAPManager:
    """Track DAP sessions per workspace.

    The actual DAP wiring is handled inside Theia; this manager keeps
    lightweight state so the daemon/CLI can report what is running.
    """

    def __init__(self) -> None:
        self._sessions: Dict[str, DebugSessionInfo] = {}

    def add_session(self, info: DebugSessionInfo) -> None:
        self._sessions[info.id] = info

    def get_session(self, session_id: str) -> Optional[DebugSessionInfo]:
        return self._sessions.get(session_id)

    def list_sessions(self) -> list[DebugSessionInfo]:
        return list(self._sessions.values())


__all__ = ["DAPManager", "DebugSessionInfo"]

