"""Client for sending IDEAction requests to the Theia backend plugin.

This is intentionally thin: it assumes the Artemis backend plugin exposes
an HTTP endpoint that accepts JSON payloads of the form
{"kind": "...", "payload": {...}} and returns
{"ok": bool, "message": str, "details": {...}}.
"""

from __future__ import annotations

import json
import os
from typing import Any

import requests

from . import IDEAction, IDEActionResult


def _ide_base_url() -> str:
    return os.environ.get("OPENARTEMIS_IDE_BASE_URL", "http://127.0.0.1:8790").rstrip("/")


def send_ide_action(action: IDEAction) -> IDEActionResult:
    """Send a single IDEAction to the backend plugin.

    If the IDE runtime is disabled or the request fails, this returns a
    best-effort error message rather than raising.
    """

    enabled = os.environ.get("OPENARTEMIS_IDE_RUNTIME_ENABLED", "").strip().lower() in {"1", "true", "yes", "on"}
    if not enabled:
        return IDEActionResult(ok=False, message="IDE runtime disabled (set OPENARTEMIS_IDE_RUNTIME_ENABLED=1)")

    url = f"{_ide_base_url()}/ide-action"
    try:
        resp = requests.post(url, json=action.to_dict(), timeout=10)
        resp.raise_for_status()
        data: dict[str, Any] = resp.json()
        return IDEActionResult(
            ok=bool(data.get("ok", False)),
            message=str(data.get("message", "")),
            details=data.get("details") if isinstance(data.get("details"), dict) else None,
        )
    except Exception as e:
        return IDEActionResult(ok=False, message=f"IDE action failed: {e!s}", details=None)


__all__ = ["send_ide_action"]

