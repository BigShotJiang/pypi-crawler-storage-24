"""Artemis IDE runtime integration layer.

This package hosts the Theia-based \"IDE runtime\" used by background
agent jobs. It sits between:

- The **Python side** (CLI, chat, agent orchestrator), and
- The **IDE side** (headless Eclipse Theia backend with LSP/DAP).

Key concepts:

- Workspace: a directory (often a git worktree) that the daemon and Theia
  backend operate on.
- Job: a long-running task (plan, agent run, refactor, etc.) that issues
  high-level IDE actions instead of raw file writes.
- IDE actions: language-agnostic operations such as rename_symbol,
  organize_imports, run_test, or applyWorkspaceEdit, which are implemented
  via Theia, LSP, and DAP.

The concrete runtime pieces live in sibling modules:

- runtime.daemon: HTTP/JSON-RPC daemon that manages workspaces and jobs.
- runtime.ide_actions: typed representations of IDE actions and helpers for
  routing them to the IDE backend.
- runtime.lsp: language-server (LSP) lifecycle and status management.
- runtime.dap: debug adapter (DAP) lifecycle and operations.
- runtime.workspaces: workspace discovery and optional git worktree
  isolation for jobs.
- runtime.extensions: curated extension manifest and security checks.

These modules are intentionally decoupled from the OpenAI-facing agent
prompts so the runtime can evolve independently of model integrations.
"""

from __future__ import annotations

from dataclasses import dataclass
from enum import Enum
from typing import Literal, TypedDict


WorkspaceId = str
JobId = str


class JobStatus(str, Enum):
    """High-level lifecycle states for background jobs."""

    PENDING = "pending"
    RUNNING = "running"
    PAUSED = "paused"
    FAILED = "failed"
    SUCCESS = "success"
    CANCELED = "canceled"
    PLAN_ONLY = "plan-only"


class JobMode(str, Enum):
    """Job execution modes."""

    PLAN = "plan"
    AGENT = "agent"
    ASK = "ask"


class WorkspaceRef(TypedDict):
    """Minimal workspace descriptor exchanged with the daemon."""

    id: WorkspaceId
    path: str
    description: str | None


class JobRef(TypedDict, total=False):
    """Minimal job descriptor exchanged with the daemon."""

    id: JobId
    workspace_id: WorkspaceId
    mode: JobMode
    status: JobStatus
    prompt: str
    created_at: str
    updated_at: str


@dataclass(slots=True)
class IDEActionResult:
    """Normalised result from an IDE action call."""

    ok: bool
    message: str
    details: dict | None = None


__all__ = [
    "WorkspaceId",
    "JobId",
    "JobStatus",
    "JobMode",
    "WorkspaceRef",
    "JobRef",
    "IDEActionResult",
]

