"""Artemis daemon core abstractions.

This module defines the in-memory structures and interfaces that the
future `artemis-daemon` process will use. The actual HTTP/JSON-RPC
server can be built on top of these types without being tightly coupled
to Typer/CLI or to any specific web framework.
"""

from __future__ import annotations

import threading
from dataclasses import dataclass, field
from datetime import datetime
from pathlib import Path
from typing import Dict, List, Optional

from . import IDEActionResult, JobId, JobMode, JobRef, JobStatus, WorkspaceId, WorkspaceRef
from . import workspaces as ws_mod


@dataclass(slots=True)
class JobRecord:
    """Internal representation of a job in the daemon."""

    id: JobId
    workspace_id: WorkspaceId
    mode: JobMode
    prompt: str
    status: JobStatus = JobStatus.PENDING
    created_at: datetime = field(default_factory=datetime.utcnow)
    updated_at: datetime = field(default_factory=datetime.utcnow)
    log: List[str] = field(default_factory=list)

    def to_ref(self) -> JobRef:
        return {
            "id": self.id,
            "workspace_id": self.workspace_id,
            "mode": self.mode,
            "status": self.status,
            "prompt": self.prompt,
            "created_at": self.created_at.isoformat(),
            "updated_at": self.updated_at.isoformat(),
        }


class ArtemisDaemon:
    """In-memory job/workspace registry.

    In the full implementation this will back a long-lived process with
    an HTTP/JSON-RPC surface. For now it provides a simple API the CLI
    or tests can exercise without networking.
    """

    def __init__(self) -> None:
        self._workspaces: Dict[WorkspaceId, WorkspaceRef] = {}
        self._jobs: Dict[JobId, JobRecord] = {}
        self._lock = threading.Lock()

    # Workspace management -------------------------------------------------

    def register_workspace(self, path: Path, description: str | None = None) -> WorkspaceRef:
        resolved = ws_mod.resolve_workspace_root(path)
        workspace_id: WorkspaceId = str(resolved)
        ref: WorkspaceRef = {
            "id": workspace_id,
            "path": str(resolved),
            "description": description,
        }
        with self._lock:
            self._workspaces[workspace_id] = ref
        return ref

    def list_workspaces(self) -> list[WorkspaceRef]:
        with self._lock:
            return list(self._workspaces.values())

    # Job management -------------------------------------------------------

    def submit_job(self, workspace_id: WorkspaceId, mode: JobMode, prompt: str) -> JobRef:
        now = datetime.utcnow()
        job_id: JobId = f"{int(now.timestamp())}-{len(self._jobs) + 1}"
        rec = JobRecord(id=job_id, workspace_id=workspace_id, mode=mode, prompt=prompt)
        with self._lock:
            self._jobs[job_id] = rec
        return rec.to_ref()

    def get_job(self, job_id: JobId) -> Optional[JobRef]:
        with self._lock:
            rec = self._jobs.get(job_id)
        return rec.to_ref() if rec else None

    def list_jobs(self) -> list[JobRef]:
        with self._lock:
            return [rec.to_ref() for rec in self._jobs.values()]

    def update_job_status(self, job_id: JobId, status: JobStatus, log_line: str | None = None) -> None:
        """Update job status and optionally append a log line."""
        with self._lock:
            rec = self._jobs.get(job_id)
            if not rec:
                return
            rec.status = status
            rec.updated_at = datetime.utcnow()
            if log_line:
                rec.log.append(log_line)

    def append_log(self, job_id: JobId, log_line: str) -> None:
        """Append a log line without changing status."""
        with self._lock:
            rec = self._jobs.get(job_id)
            if not rec:
                return
            rec.log.append(log_line)
            rec.updated_at = datetime.utcnow()


__all__ = ["ArtemisDaemon", "JobStatus"]


