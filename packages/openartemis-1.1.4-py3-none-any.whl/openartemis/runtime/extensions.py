"""Curated extension manifest and security notes for Theia/VS Code."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Dict, List


@dataclass(slots=True)
class ExtensionSpec:
    """Describe an allowed IDE extension."""

    id: str
    version: str
    source: str  # e.g. "open-vsx", "private-registry"
    sha256: str | None = None


CURATED_EXTENSIONS: Dict[str, ExtensionSpec] = {
    # Core language support examples (placeholders; versions to be set
    # when wiring a real registry).
    "ms-python.python": ExtensionSpec(
        id="ms-python.python",
        version="*",
        source="open-vsx",
        sha256=None,
    ),
    "ms-vscode.vscode-typescript-next": ExtensionSpec(
        id="ms-vscode.vscode-typescript-next",
        version="*",
        source="open-vsx",
        sha256=None,
    ),
}


def is_extension_allowed(extension_id: str) -> bool:
    """Return True if an extension id is in the curated manifest."""

    return extension_id in CURATED_EXTENSIONS


__all__ = ["ExtensionSpec", "CURATED_EXTENSIONS", "is_extension_allowed"]

