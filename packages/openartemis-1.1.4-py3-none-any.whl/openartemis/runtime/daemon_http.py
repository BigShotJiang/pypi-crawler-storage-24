"""HTTP server wrapper around ArtemisDaemon.

This is a minimal JSON/HTTP API, intended to be run via the
`openartemis daemon` CLI command. It does not expose any authentication
and is meant for localhost use only.
"""

from __future__ import annotations

import json
import threading
from http.server import BaseHTTPRequestHandler, HTTPServer
from pathlib import Path
from typing import Any

from . import JobMode, JobStatus
from .daemon import ArtemisDaemon
from .workspaces import resolve_workspace_root


def _agent_output_dir() -> Path:
    """Mirror cli.get_agent_output_dir() without importing cli.py."""
    import os

    raw = os.environ.get("OPENARTEMIS_AGENT_OUTPUT_DIR", "").strip()
    if raw:
        return Path(raw).expanduser().resolve()
    return Path.home() / ".openartemis" / "agent_output"


def _agent_output_path(request: str) -> Path:
    """Simplified version of cli._agent_output_path()."""
    import datetime
    import re

    text = (request or "task").strip()
    words = re.sub(r"[^\w\s-]", " ", text).split()
    slug = "-".join(w.lower() for w in words[:4] if w) or "task"
    slug = re.sub(r"-+", "-", slug).strip("-")[:22] or "task"
    ts = datetime.datetime.now().strftime("%Y-%m-%d_%H-%M")
    return _agent_output_dir() / f"{ts}_{slug}.md"


class _DaemonState:
    def __init__(self) -> None:
        self.daemon = ArtemisDaemon()


def run_http_daemon(host: str = "127.0.0.1", port: int = 8787) -> None:
    """Start a blocking HTTP server around ArtemisDaemon."""

    state = _DaemonState()

    class Handler(BaseHTTPRequestHandler):
        def _send_json(self, obj: Any, status: int = 200) -> None:
            data = json.dumps(obj).encode("utf-8")
            self.send_response(status)
            self.send_header("Content-Type", "application/json")
            self.send_header("Content-Length", str(len(data)))
            self.end_headers()
            self.wfile.write(data)

        def do_GET(self) -> None:  # type: ignore[override]
            if self.path == "/health":
                self._send_json({"status": "ok"})
                return
            if self.path == "/jobs":
                jobs = state.daemon.list_jobs()
                self._send_json({"jobs": jobs})
                return
            self.send_response(404)
            self.end_headers()

        def do_POST(self) -> None:  # type: ignore[override]
            if self.path != "/jobs":
                self.send_response(404)
                self.end_headers()
                return
            length = int(self.headers.get("Content-Length", "0"))
            raw = self.rfile.read(length) if length else b"{}"
            try:
                payload = json.loads(raw.decode("utf-8"))
            except json.JSONDecodeError:
                self._send_json({"error": "invalid JSON"}, status=400)
                return
            prompt = (payload.get("prompt") or "").strip()
            mode_str = (payload.get("mode") or "agent").strip().lower()
            workspace = Path(payload.get("workspace") or ".")
            if not prompt:
                self._send_json({"error": "prompt is required"}, status=400)
                return
            try:
                mode = JobMode.AGENT if mode_str != "plan" else JobMode.PLAN
            except Exception:
                mode = JobMode.AGENT
            ws_root = resolve_workspace_root(workspace)
            ws_ref = state.daemon.register_workspace(ws_root, description=None)
            job_ref = state.daemon.submit_job(ws_ref["id"], mode, prompt)

            # Fire-and-forget subprocess that uses existing CLI machinery.
            t = threading.Thread(
                target=_run_agent_job_subprocess,
                args=(job_ref["id"], ws_root, prompt, mode == JobMode.PLAN, state.daemon),
                daemon=True,
            )
            t.start()
            self._send_json({"job": job_ref}, status=202)

        def log_message(self, fmt: str, *args: Any) -> None:  # type: ignore[override]
            # Silence default HTTP server logging.
            return

    server = HTTPServer((host, port), Handler)
    try:
        server.serve_forever()
    finally:
        server.server_close()


def _run_agent_job_subprocess(job_id: str, workspace: Path, prompt: str, plan_mode: bool, daemon: ArtemisDaemon) -> None:
    """Spawn the existing agent-run CLI as a subprocess for this job."""
    import os
    import subprocess
    import sys

    out_dir = _agent_output_dir()
    out_dir.mkdir(parents=True, exist_ok=True)
    output_path = _agent_output_path(prompt)

    # Mirror cli._run_agent_background markers so agent-status continues to work.
    (out_dir / f"{output_path.name}.running").write_text(prompt, encoding="utf-8")
    (out_dir / f"{output_path.name}.workspace").write_text(str(workspace.resolve()), encoding="utf-8")

    cmd = [sys.executable, "-m", "openartemis", "agent-run", prompt, str(output_path)]
    if plan_mode:
        cmd.append("--plan")
    env = os.environ.copy()
    env["OPENARTEMIS_AGENT_WORKSPACE"] = str(workspace.resolve())

    daemon.update_job_status(job_id, JobStatus.RUNNING, log_line="spawned agent-run subprocess")
    try:
        proc = subprocess.Popen(
            cmd,
            env=env,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            stdin=subprocess.DEVNULL,
        )
        proc.wait()
        if proc.returncode == 0:
            daemon.update_job_status(job_id, JobStatus.SUCCESS, log_line="agent job completed")
        else:
            daemon.update_job_status(job_id, JobStatus.FAILED, log_line=f"agent job failed (exit {proc.returncode})")
    except Exception as e:
        daemon.update_job_status(job_id, JobStatus.FAILED, log_line=f"agent job error: {e}")


__all__ = ["run_http_daemon"]

