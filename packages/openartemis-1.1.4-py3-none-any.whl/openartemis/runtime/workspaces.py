"""Workspace utilities for the Artemis IDE runtime."""

from __future__ import annotations

import subprocess
from dataclasses import dataclass
from pathlib import Path
from typing import Optional


@dataclass(slots=True)
class WorkspaceConfig:
    """Configuration for a workspace used by a job."""

    root: Path
    use_git_worktree: bool = False
    worktree_base: Optional[Path] = None


def resolve_workspace_root(path: Path) -> Path:
    """Return an absolute workspace root."""
    return path.expanduser().resolve()


def prepare_job_workspace(cfg: WorkspaceConfig) -> Path:
    """Return a filesystem path for a job to operate in.

    If `use_git_worktree` is True and the path is inside a git repo,
    this will attempt to create a dedicated worktree under
    `worktree_base` (or a `.artemis-worktrees` folder).
    If worktree creation fails, it falls back to using the original
    root path so the agent can still make progress.
    """

    root = resolve_workspace_root(cfg.root)
    if not cfg.use_git_worktree:
        return root

    git_dir = _find_git_dir(root)
    if not git_dir:
        return root

    base = cfg.worktree_base or (git_dir.parent / ".artemis-worktrees")
    base.mkdir(parents=True, exist_ok=True)
    worktree_path = base / root.name

    if worktree_path.exists():
        return worktree_path

    try:
        # `git worktree add <path> <branch-or-head>`
        subprocess.run(
            ["git", "worktree", "add", str(worktree_path), "HEAD"],
            cwd=str(git_dir),
            check=True,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
        )
        return worktree_path
    except Exception:
        # Fall back to the main tree if worktree creation fails.
        return root


def _find_git_dir(start: Path) -> Optional[Path]:
    """Walk up from start to find the .git directory."""
    cur = start
    for _ in range(10):
        if (cur / ".git").exists():
            return cur
        if cur.parent == cur:
            break
        cur = cur.parent
    return None


__all__ = ["WorkspaceConfig", "resolve_workspace_root", "prepare_job_workspace"]

