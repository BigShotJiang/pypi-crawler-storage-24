"""Theia backend integration for the Artemis IDE runtime.

This module does NOT start Theia by default; it defines the process
launcher and configuration that the daemon can use to run a headless
Eclipse Theia backend with backend plugins only.

The intent is:
- The Python daemon constructs a :class:`TheiaBackendConfig` for a
  workspace.
- It calls :func:`start_theia_backend` to spawn the Node-based backend
  (e.g. ~/.openartemis/theia/theia-backend.js).
- IDE actions are then issued over JSON-RPC (HTTP or stdio) to a
  backend plugin that exposes workspace/LSP/DAP operations.

Keeping this in Python makes it easy to unit-test the process wiring
without requiring a full Theia checkout in this repository.
"""

from __future__ import annotations

import os
import subprocess
import sys
from dataclasses import dataclass
from pathlib import Path
from typing import Iterable, Mapping, Sequence


@dataclass(slots=True)
class TheiaBackendConfig:
    """Configuration for launching a headless Theia backend."""

    workspace_root: Path
    port: int | None = None
    plugins_dir: Path | None = None
    node_path: str = "node"
    script_path: Path = Path.home() / ".openartemis" / "theia" / "theia-backend.js"
    extra_args: Sequence[str] = ()
    env_overrides: Mapping[str, str] | None = None


def build_theia_command(cfg: TheiaBackendConfig) -> list[str]:
    """Build the Node command line used to start the backend.

    The script_path is intentionally configurable so users can install
    or update the Theia backend independently of the Python package.
    """

    cmd: list[str] = [cfg.node_path, str(cfg.script_path)]
    if cfg.port:
        cmd += ["--port", str(cfg.port)]
    if cfg.workspace_root:
        cmd += ["--workspace", str(cfg.workspace_root.resolve())]
    if cfg.plugins_dir:
        cmd += ["--plugins", str(cfg.plugins_dir.resolve())]
    if cfg.extra_args:
        cmd.extend(list(cfg.extra_args))
    return cmd


def start_theia_backend(cfg: TheiaBackendConfig) -> subprocess.Popen[bytes]:
    """Start the Theia backend process for a workspace.

    This function does not implement health checks or JSON-RPC wiring;
    the daemon is responsible for supervising the process and talking
    to the Artemis backend plugin over HTTP or stdio.
    """

    cmd = build_theia_command(cfg)
    env = os.environ.copy()
    if cfg.env_overrides:
        env.update(cfg.env_overrides)
    # Use workspace root as cwd so relative paths inside Theia match
    # what the agent sees.
    cwd = str(cfg.workspace_root.resolve())
    # Do not raise here; callers should handle OSError and report a
    # friendly error back to the user if Node/Theia is missing.
    return subprocess.Popen(
        cmd,
        cwd=cwd,
        env=env,
        stdin=subprocess.DEVNULL,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
    )


__all__ = ["TheiaBackendConfig", "build_theia_command", "start_theia_backend"]

