"""IDE-level actions exposed to the Artemis agent.

These are higher-level than raw file writes: they mirror what a human
does through an IDE (rename symbol, organize imports, run tests, etc.).

Python code uses these dataclasses/TypedDicts; the daemon is responsible
for translating them to Theia workspace edits, LSP requests, or DAP
operations via the backend plugin.
"""

from __future__ import annotations

from dataclasses import dataclass
from enum import Enum
from typing import Any, Literal, TypedDict


class IDEActionKind(str, Enum):
    OPEN_TEXT_DOCUMENT = "open_text_document"
    GET_TEXT = "get_text"
    APPLY_TEXT_EDITS = "apply_text_edits"
    RENAME_SYMBOL = "rename_symbol"
    ORGANIZE_IMPORTS = "organize_imports"
    FORMAT_DOCUMENT = "format_document"
    FIX_ALL = "fix_all"
    SEARCH_WORKSPACE = "search_workspace"
    ADD_FILE = "add_file"
    MOVE_FILE = "move_file"
    DELETE_FILE = "delete_file"
    RUN_TEST = "run_test"
    RUN_TASK = "run_task"
    RUN_COMMAND = "run_command"
    GET_DIAGNOSTICS = "get_diagnostics"
    CODE_ACTIONS = "code_actions"
    DEBUG_LAUNCH = "debug_launch"
    DEBUG_ATTACH = "debug_attach"
    DEBUG_SET_BREAKPOINTS = "debug_set_breakpoints"
    DEBUG_STEP = "debug_step"
    DEBUG_CONTINUE = "debug_continue"
    DEBUG_INSPECT_VARIABLE = "debug_inspect_variable"


class IDEActionPayload(TypedDict, total=False):
    """JSON-serialisable payload for an IDE action."""

    uri: str
    text: str
    edits: list[dict]
    position: dict
    newName: str
    query: str
    options: dict
    path: str
    fromPath: str
    toPath: str
    target: str
    name: str
    command: str
    args: list[Any]
    range: dict
    configId: str
    params: dict
    lines: list[int]
    sessionId: str
    frameId: int
    expression: str


@dataclass(slots=True)
class IDEAction:
    """One IDE operation requested by the agent."""

    kind: IDEActionKind
    payload: IDEActionPayload

    def to_dict(self) -> dict[str, Any]:
        return {"kind": self.kind.value, "payload": dict(self.payload)}

    @staticmethod
    def from_dict(data: dict[str, Any]) -> "IDEAction":
        kind = IDEActionKind(data.get("kind"))
        payload: IDEActionPayload = data.get("payload", {}) or {}
        return IDEAction(kind=kind, payload=payload)


__all__ = ["IDEActionKind", "IDEActionPayload", "IDEAction"]

