"""Secrets vault — encrypted store under ~/.openartemis/secrets. Key from OPENARTEMIS_VAULT_KEY."""

import base64
import hashlib
import os
from pathlib import Path

VAULT_DIR = Path.home() / ".openartemis" / "secrets"


def _vault_key() -> bytes:
    raw = os.environ.get("OPENARTEMIS_VAULT_KEY", "").strip() or "openartemis-default-vault-key"
    return base64.urlsafe_b64encode(hashlib.sha256(raw.encode()).digest())


def _secret_path(key: str) -> Path:
    safe = "".join(c if c.isalnum() or c in "-_" else "_" for c in key)
    if not safe:
        safe = "default"
    VAULT_DIR.mkdir(parents=True, exist_ok=True)
    return VAULT_DIR / f"{safe}.secret"


def get_secret(key: str) -> str:
    """Return secret value for key, or empty string if missing/invalid."""
    try:
        p = _secret_path(key)
        if not p.exists():
            return ""
        raw = p.read_bytes()
        try:
            from cryptography.fernet import Fernet
            f = Fernet(_vault_key())
            return f.decrypt(raw).decode("utf-8", errors="replace")
        except ImportError:
            return raw.decode("utf-8", errors="replace")
    except Exception:
        return ""


def set_secret(key: str, value: str) -> bool:
    """Store secret. Returns True on success."""
    try:
        p = _secret_path(key)
        VAULT_DIR.mkdir(parents=True, exist_ok=True)
        data = value.encode("utf-8")
        try:
            from cryptography.fernet import Fernet
            f = Fernet(_vault_key())
            data = f.encrypt(data)
        except ImportError:
            pass
        p.write_bytes(data)
        return True
    except Exception:
        return False
