"""Preflight environment checker: validate required env vars, tools, and
optional IDE runtime (Theia-based backend) per mode.

This module is deliberately lightweight so it can run before any heavy
imports. When IDE runtime support is enabled via env vars, preflight
also ensures that the runtime bundle is present under
``~/.openartemis/theia/`` and, if necessary, downloads and unpacks it.
"""

from __future__ import annotations

import json
import os
import shutil
import sys
import tarfile
import tempfile
from pathlib import Path
from typing import Callable

import requests

# Mode -> list of (check_id, required, description, checker)
# checker() -> (ok: bool, message: str)


def _check_present(key: str) -> tuple[bool, str]:
    v = os.environ.get(key, "").strip()
    if not v:
        return False, "not set"
    if v.startswith("sk-") and len(v) < 20:
        return False, "looks like a placeholder"
    return True, "set"


def _check_ffmpeg() -> tuple[bool, str]:
    ffmpeg = shutil.which("ffmpeg")
    if ffmpeg:
        return True, ffmpeg
    return False, "not in PATH (required for TikTok/Instagram/X audio)"


def _check_openai() -> tuple[bool, str]:
    return _check_present("ANTHROPIC_API_KEY")


def _check_transcriptapi() -> tuple[bool, str]:
    return _check_present("TRANSCRIPTAPI_API_KEY")


def _check_youtube() -> tuple[bool, str]:
    return _check_present("YOUTUBE_API_KEY")


def _check_brave() -> tuple[bool, str]:
    return _check_present("BRAVE_SEARCH_API_KEY")


def _check_workspace() -> tuple[bool, str]:
    raw = os.environ.get("OPENARTEMIS_AGENT_OUTPUT_DIR", "").strip()
    agent_out = Path(raw).expanduser().resolve() if raw else (Path.home() / ".openartemis" / "agent_output")
    try:
        agent_out.mkdir(parents=True, exist_ok=True)
        return True, str(agent_out)
    except Exception as e:
        return False, str(e)


def _ide_runtime_enabled() -> bool:
    v = os.environ.get("OPENARTEMIS_IDE_RUNTIME_ENABLED", "").strip().lower()
    return v in {"1", "true", "yes", "on"}


def _ide_runtime_root() -> Path:
    raw = os.environ.get("OPENARTEMIS_IDE_RUNTIME_DIR", "").strip()
    return Path(raw).expanduser().resolve() if raw else (Path.home() / ".openartemis" / "theia")


def _ide_runtime_version_path() -> Path:
    return _ide_runtime_root() / "runtime-version.json"


def _detect_platform_tag() -> str:
    """Return a simple platform tag used to pick the right runtime archive."""
    plat = sys.platform
    arch = os.environ.get("PROCESSOR_ARCHITECTURE", "") or os.environ.get("ARCHFLAGS", "")
    if not arch:
        arch = getattr(__import__("platform"), "machine")()
    arch = arch.lower()
    if plat.startswith("win"):
        return "win-x64" if "64" in arch else "win-x86"
    if plat == "darwin":
        if "arm" in arch or "aarch64" in arch:
            return "macos-arm64"
        return "macos-x64"
    # Default to linux variants
    return "linux-x64" if "64" in arch else "linux-x86"


def _download_and_unpack_runtime(url: str, dest: Path) -> str:
    dest.mkdir(parents=True, exist_ok=True)
    with tempfile.TemporaryDirectory() as tmpdir:
        tmp_path = Path(tmpdir) / "runtime.tar.gz"
        resp = requests.get(url, stream=True, timeout=60)
        resp.raise_for_status()
        with tmp_path.open("wb") as f:
            for chunk in resp.iter_content(chunk_size=8192):
                if chunk:
                    f.write(chunk)
        with tarfile.open(tmp_path, "r:gz") as tf:
            tf.extractall(dest)
    return f"downloaded from {url} into {dest}"


def _check_ide_runtime() -> tuple[bool, str]:
    """Ensure IDE runtime is present when enabled.

    Behaviour:
    - If OPENARTEMIS_IDE_RUNTIME_ENABLED is not truthy, this is a no-op.
    - If enabled and the backend script exists, report it as OK.
    - If enabled and missing, attempt to download it using
      OPENARTEMIS_IDE_RUNTIME_URL (or BASE_URL+VERSION+platform tag).
    """

    if not _ide_runtime_enabled():
        return True, "disabled (set OPENARTEMIS_IDE_RUNTIME_ENABLED=1 to enable)"

    root = _ide_runtime_root()
    backend = root / "theia-backend.js"
    version_file = _ide_runtime_version_path()

    if backend.exists():
        version = "unknown"
        try:
            if version_file.exists():
                version = json.loads(version_file.read_text(encoding="utf-8")).get("version", "unknown")
        except Exception:
            version = "unknown"
        return True, f"present (version {version}) at {backend}"

    # Need to install
    base_url = os.environ.get("OPENARTEMIS_IDE_RUNTIME_BASE_URL", "").rstrip("/")
    explicit_url = os.environ.get("OPENARTEMIS_IDE_RUNTIME_URL", "").strip()
    runtime_version = os.environ.get("OPENARTEMIS_IDE_RUNTIME_VERSION", "").strip()
    platform_tag = _detect_platform_tag()

    if explicit_url:
        url = explicit_url
    elif base_url and runtime_version:
        url = f"{base_url}/artemis-runtime-{runtime_version}-{platform_tag}.tar.gz"
    else:
        return False, (
            "IDE runtime enabled but not installed. Set OPENARTEMIS_IDE_RUNTIME_URL to a runtime archive "
            "or OPENARTEMIS_IDE_RUNTIME_BASE_URL + OPENARTEMIS_IDE_RUNTIME_VERSION."
        )

    try:
        detail = _download_and_unpack_runtime(url, root)
        version_info = {
            "version": runtime_version or "unknown",
            "platform": platform_tag,
            "source_url": url,
        }
        try:
            version_file.write_text(json.dumps(version_info, indent=2), encoding="utf-8")
        except OSError:
            # Non-fatal if we can't write metadata.
            pass
        return True, f"installed IDE runtime ({detail})"
    except Exception as e:
        return False, f"install failed: {e}"


def cleanup_ide_runtime() -> tuple[bool, str]:
    """Remove cached IDE runtime (for uninstall or troubleshooting)."""

    root = _ide_runtime_root()
    if not root.exists():
        return True, "no runtime directory to remove"
    try:
        shutil.rmtree(root)
        return True, f"removed {root}"
    except Exception as e:
        return False, f"failed to remove {root}: {e}"


CHECKS: dict[str, list[tuple[str, bool, str, Callable[[], tuple[bool, str]]]]] = {
    "chat": [
        ("ANTHROPIC_API_KEY", True, "Artemis chat", _check_openai),
    ],
    "harvest": [
        ("TRANSCRIPTAPI_API_KEY", False, "YouTube (TranscriptAPI)", _check_transcriptapi),
        ("YOUTUBE_API_KEY", False, "YouTube (Google API)", _check_youtube),
        ("ffmpeg", False, "TikTok/Instagram/X audio", _check_ffmpeg),
    ],
    "agent": [
        ("ANTHROPIC_API_KEY", True, "Agent mode", _check_openai),
        ("workspace", False, "Agent output dir", _check_workspace),
        ("ide_runtime", False, "IDE runtime (Theia backend, optional)", _check_ide_runtime),
    ],
    "research": [
        ("ANTHROPIC_API_KEY", True, "Research pipeline", _check_openai),
        ("BRAVE_SEARCH_API_KEY", False, "Web search", _check_brave),
        ("TRANSCRIPTAPI_API_KEY", False, "Harvest in research", _check_transcriptapi),
    ],
}


def run_preflight(mode: str | None = None) -> list[tuple[str, str, bool, str]]:
    """
    Run preflight checks for the given mode or all modes.
    Returns list of (mode, check_id, ok, message).
    """
    modes = [mode] if mode else list(CHECKS.keys())
    results: list[tuple[str, str, bool, str]] = []
    for m in modes:
        if m not in CHECKS:
            results.append((m, "?", False, "unknown mode"))
            continue
        for check_id, required, desc, checker in CHECKS[m]:
            ok, msg = checker()
            results.append((m, check_id, ok, msg))
    return results


def preflight_table(results: list[tuple[str, str, bool, str]]) -> str:
    """Format results as a simple table string (for console or tests)."""
    lines = ["Mode     | Check              | Status  | Detail", "-" * 55]
    for mode, check_id, ok, msg in results:
        status = "OK" if ok else "MISSING"
        lines.append(f"{mode:8} | {check_id:18} | {status:7} | {msg}")
    return "\n".join(lines)
