"""Artemis CLI theme — dark minimal with cyan accent.

Single source of truth for all visual constants and console helpers.
Import this everywhere instead of inline Rich markup strings.
"""

from __future__ import annotations

from typing import TYPE_CHECKING

from prompt_toolkit.styles import Style as PtStyle

if TYPE_CHECKING:
    from rich.console import Console

# ── Colour tokens ────────────────────────────────────────────────────────────

ACCENT  = "cyan"
DIM     = "dim"
SUCCESS = "green"
ERROR   = "red"
WARN    = "yellow"
BORDER  = "cyan"
INFO    = "cyan"

# ── ASCII logo — clean block letters ─────────────────────────────────────────

LOGO = (
    " \u2588\u2588\u2588\u2588\u2588\u2557 \u2588\u2588\u2588\u2588\u2588\u2588\u2557 \u2588\u2588\u2588\u2588\u2588\u2588\u2588\u2588\u2557\u2588\u2588\u2588\u2588\u2588\u2588\u2588\u2557\u2588\u2588\u2588\u2557   \u2588\u2588\u2588\u2557\u2588\u2588\u2557\u2588\u2588\u2588\u2588\u2588\u2588\u2588\u2557\n"
    "\u2588\u2588\u2554\u2550\u2550\u2588\u2588\u2557\u2588\u2588\u2554\u2550\u2550\u2588\u2588\u2557\u255a\u2550\u2550\u2588\u2588\u2554\u2550\u2550\u255d\u2588\u2588\u2554\u2550\u2550\u2550\u2550\u255d\u2588\u2588\u2588\u2588\u2557 \u2588\u2588\u2588\u2588\u2551\u2588\u2588\u2551\u2588\u2588\u2554\u2550\u2550\u2550\u2550\u255d\n"
    "\u2588\u2588\u2588\u2588\u2588\u2588\u2588\u2551\u2588\u2588\u2588\u2588\u2588\u2588\u2554\u255d   \u2588\u2588\u2551   \u2588\u2588\u2588\u2588\u2588\u2557  \u2588\u2588\u2554\u2588\u2588\u2588\u2588\u2554\u2588\u2588\u2551\u2588\u2588\u2551\u2588\u2588\u2588\u2588\u2588\u2588\u2588\u2557\n"
    "\u2588\u2588\u2554\u2550\u2550\u2588\u2588\u2551\u2588\u2588\u2554\u2550\u2550\u2588\u2588\u2557   \u2588\u2588\u2551   \u2588\u2588\u2554\u2550\u2550\u255d  \u2588\u2588\u2551\u255a\u2588\u2588\u2554\u255d\u2588\u2588\u2551\u2588\u2588\u2551\u255a\u2550\u2550\u2550\u2550\u2588\u2588\u2551\n"
    "\u2588\u2588\u2551  \u2588\u2588\u2551\u2588\u2588\u2551  \u2588\u2588\u2551   \u2588\u2588\u2551   \u2588\u2588\u2588\u2588\u2588\u2588\u2588\u2557\u2588\u2588\u2551 \u255a\u2550\u255d \u2588\u2588\u2551\u2588\u2588\u2551\u2588\u2588\u2588\u2588\u2588\u2588\u2588\u2551\n"
    "\u255a\u2550\u255d  \u255a\u2550\u255d\u255a\u2550\u255d  \u255a\u2550\u255d   \u255a\u2550\u255d   \u255a\u2550\u2550\u2550\u2550\u2550\u2550\u255d\u255a\u2550\u255d     \u255a\u2550\u255d\u255a\u2550\u255d\u255a\u2550\u2550\u2550\u2550\u2550\u2550\u255d"
)


def print_logo(console: "Console", version: str = "") -> None:
    """Print the block-letter ARTEMIS logo in cyan + version tag."""
    console.print()
    for line in LOGO.splitlines():
        console.print(f"[bold cyan]{line}[/bold cyan]")
    tag = f"  v{version}" if version else ""
    console.print(f"[dim]{tag}  \u00b7  cli[/dim]")
    console.print()


# ── Structural helpers ────────────────────────────────────────────────────────

def rule(console: "Console", label: str = "") -> None:
    """Thin cyan horizontal rule, optionally labelled."""
    from rich.rule import Rule
    if label:
        console.print(Rule(f"[dim]{label}[/dim]", style="cyan"))
    else:
        console.print(Rule(style="cyan"))


def blank(console: "Console") -> None:
    console.print()


# ── Status helpers ────────────────────────────────────────────────────────────

def ok(console: "Console", msg: str) -> None:
    console.print(f"  [green]\u2713[/green]  {msg}")


def err(console: "Console", msg: str) -> None:
    console.print(f"  [red]\u2717[/red]  [red]{msg}[/red]")


def info(console: "Console", msg: str) -> None:
    console.print(f"  [dim]\u00b7[/dim]  [dim]{msg}[/dim]")


def warn(console: "Console", msg: str) -> None:
    console.print(f"  [yellow]![/yellow]  [yellow]{msg}[/yellow]")


def step(console: "Console", n: int, label: str) -> None:
    console.print(f"  [dim]{n}[/dim]  {label}")


def kv(console: "Console", key: str, val: str) -> None:
    console.print(f"  [dim]{key:<14}[/dim]  {val}")


def accent(console: "Console", msg: str) -> None:
    console.print(f"  [cyan]{msg}[/cyan]")


def header(console: "Console", title: str) -> None:
    console.print(f"[bold cyan]\u25c6 {title}[/bold cyan]")


def dim_kv(console: "Console", key: str, val: str) -> None:
    console.print(f"  [dim]{key}[/dim]  [cyan]{val}[/cyan]")


# ── Questionary styles ────────────────────────────────────────────────────────

def prompt_style() -> PtStyle:
    """Minimal dark prompt style — cyan pointer, white highlight."""
    return PtStyle.from_dict({
        "highlighted":  "bold fg:ansicyan",
        "selected":     "noreverse",
        "pointer":      "bold fg:ansicyan",
        "question":     "bold fg:white",
        "answer":       "fg:white",
        "instruction":  "fg:ansidarkgray",
    })


def select_opts() -> dict:
    """Drop-in replacement for _QUESTIONARY_SELECT_OPTS."""
    return {
        "use_arrow_keys": True,
        "use_jk_keys":    False,
        "instruction":    "",
        "qmark":          "",
        "style":          prompt_style(),
    }


# ── Version helper ────────────────────────────────────────────────────────────

def get_version() -> str:
    try:
        from importlib.metadata import version
        return version("openartemis")
    except Exception:
        try:
            from openartemis import __version__
            return __version__
        except Exception:
            return "1.0"
