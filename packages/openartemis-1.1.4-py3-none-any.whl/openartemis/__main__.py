"""Entry point for python -m openartemis."""

from openartemis.cli import main

if __name__ == "__main__":
    main()
