"""OpenArtemisCompiler (.oac) — build manifest format and local compilation engine.

A .oac file is a JSON manifest that describes how to compile/package a project
after downloading it from the E2B sandbox. The CLI reads this manifest and
executes the build steps locally on the user's Windows machine.

The .oac file does NOT contain code or algorithms — it's pure instructions.
The compilation logic lives here in the CLI.
"""

import json
import os
import subprocess
import sys
from pathlib import Path
from typing import Any, Optional

OAC_VERSION = "1.0"
OAC_EXTENSION = ".oac"


def generate_oac_manifest(
    project_name: str,
    language: str,
    entry_point: str,
    build_commands: list[str],
    compile_target: str = "",
    files: list[str] | None = None,
    dependencies: dict[str, str] | None = None,
    notes: str = "",
) -> dict[str, Any]:
    """Generate a .oac manifest dict.

    Args:
        project_name: Name of the project (e.g. "flappy-bird")
        language: Primary language (python, javascript, typescript, c, cpp, rust, go, java, html, etc.)
        entry_point: Main file to run (e.g. "main.py", "index.html", "src/main.rs")
        build_commands: Ordered list of shell commands to build (e.g. ["npm install", "npm run build"])
        compile_target: What to produce — "exe", "msi", "jar", "binary", "webapp", "" (none)
        files: List of project files (for reference)
        dependencies: Map of dependency name → version
        notes: Any extra build notes
    """
    return {
        "oac_version": OAC_VERSION,
        "project_name": project_name,
        "language": language,
        "entry_point": entry_point,
        "build_commands": build_commands,
        "compile_target": compile_target,
        "files": files or [],
        "dependencies": dependencies or {},
        "notes": notes,
    }


def write_oac(manifest: dict[str, Any], dest: Path) -> Path:
    """Write .oac manifest to disk."""
    dest.parent.mkdir(parents=True, exist_ok=True)
    if not dest.name.endswith(OAC_EXTENSION):
        dest = dest.with_suffix(OAC_EXTENSION)
    dest.write_text(json.dumps(manifest, indent=2, ensure_ascii=False), encoding="utf-8")
    return dest


def read_oac(path: Path) -> dict[str, Any]:
    """Read and parse a .oac manifest file."""
    text = path.read_text(encoding="utf-8")
    data = json.loads(text)
    if not isinstance(data, dict):
        raise ValueError(f"Invalid .oac file: expected JSON object, got {type(data).__name__}")
    return data


def is_compilable(manifest: dict[str, Any]) -> bool:
    """Check if the project described by this manifest can be compiled into a standalone artifact."""
    target = (manifest.get("compile_target") or "").strip().lower()
    if target in ("exe", "msi", "binary", "jar"):
        return True
    lang = (manifest.get("language") or "").strip().lower()
    if lang in ("python", "c", "cpp", "c++", "rust", "go", "java", "csharp", "c#"):
        return True
    return False


def _run_build_command(cmd: str, cwd: Path, on_status: Any = None) -> tuple[bool, str]:
    """Run a single build command. Returns (success, output)."""
    if on_status:
        on_status(f"Running: {cmd}")
    try:
        result = subprocess.run(
            cmd,
            shell=True,
            cwd=str(cwd),
            capture_output=True,
            text=True,
            timeout=600,
            encoding="utf-8",
            errors="replace",
        )
        out = (result.stdout or "") + (result.stderr or "")
        return result.returncode == 0, out.strip()
    except subprocess.TimeoutExpired:
        return False, f"Command timed out: {cmd}"
    except Exception as e:
        return False, f"Error: {e}"


def compile_project(
    project_dir: Path,
    manifest: dict[str, Any],
    on_status: Any = None,
) -> tuple[bool, str, Optional[Path]]:
    """Execute the build manifest to compile/package the project locally.

    Returns (success, message, artifact_path).
    """
    lang = (manifest.get("language") or "").strip().lower()
    target = (manifest.get("compile_target") or "").strip().lower()
    entry = manifest.get("entry_point", "")
    build_cmds = manifest.get("build_commands", [])
    project_name = manifest.get("project_name", "project")

    # Step 1: Run build commands in order
    for cmd in build_cmds:
        if on_status:
            on_status(f"Build: {cmd}")
        ok, out = _run_build_command(cmd, project_dir, on_status)
        if not ok:
            return False, f"Build failed at '{cmd}':\n{out}", None

    # Step 2: Compile based on language + target
    artifact: Optional[Path] = None

    if lang == "python" and target == "exe":
        # Use PyInstaller to create .exe
        if on_status:
            on_status("Compiling Python → .exe with PyInstaller...")
        ok, out = _run_build_command(
            f"pip install pyinstaller -q && pyinstaller --onefile --distpath dist --name {project_name} {entry}",
            project_dir,
            on_status,
        )
        if ok:
            exe_path = project_dir / "dist" / f"{project_name}.exe"
            if exe_path.exists():
                artifact = exe_path
                return True, f"Compiled: {exe_path}", artifact
        return False, f"PyInstaller failed:\n{out}", None

    elif lang in ("c", "cpp", "c++") and target in ("exe", "binary"):
        if on_status:
            on_status("Compiling C/C++ → .exe with gcc/g++...")
        compiler = "g++" if lang in ("cpp", "c++") else "gcc"
        exe_name = f"{project_name}.exe"
        ok, out = _run_build_command(
            f"{compiler} -o {exe_name} {entry}",
            project_dir,
            on_status,
        )
        if ok:
            artifact = project_dir / exe_name
            if artifact.exists():
                return True, f"Compiled: {artifact}", artifact
        return False, f"Compilation failed:\n{out}", None

    elif lang == "rust" and target in ("exe", "binary"):
        if on_status:
            on_status("Compiling Rust → binary with cargo...")
        ok, out = _run_build_command("cargo build --release", project_dir, on_status)
        if ok:
            # Look for binary in target/release
            release_dir = project_dir / "target" / "release"
            if release_dir.exists():
                for f in release_dir.iterdir():
                    if f.is_file() and f.suffix == ".exe":
                        artifact = f
                        return True, f"Compiled: {artifact}", artifact
            return True, f"Rust build succeeded. Check target/release/", None
        return False, f"Cargo build failed:\n{out}", None

    elif lang == "go" and target in ("exe", "binary"):
        if on_status:
            on_status("Compiling Go → binary...")
        exe_name = f"{project_name}.exe"
        ok, out = _run_build_command(f"go build -o {exe_name}", project_dir, on_status)
        if ok:
            artifact = project_dir / exe_name
            return True, f"Compiled: {artifact}", artifact
        return False, f"Go build failed:\n{out}", None

    elif lang == "java" and target == "jar":
        if on_status:
            on_status("Compiling Java → jar...")
        ok, out = _run_build_command(
            f"javac {entry} && jar cfe {project_name}.jar Main *.class",
            project_dir,
            on_status,
        )
        if ok:
            artifact = project_dir / f"{project_name}.jar"
            return True, f"Compiled: {artifact}", artifact
        return False, f"Java compilation failed:\n{out}", None

    elif lang in ("javascript", "typescript") and target == "exe":
        # Use pkg or nexe for Node.js → .exe
        if on_status:
            on_status("Packaging Node.js → .exe with pkg...")
        ok, out = _run_build_command(
            f"npx pkg {entry} --target node18-win-x64 --output {project_name}.exe",
            project_dir,
            on_status,
        )
        if ok:
            artifact = project_dir / f"{project_name}.exe"
            if artifact.exists():
                return True, f"Compiled: {artifact}", artifact
        return False, f"pkg failed:\n{out}", None

    # No compilation needed or unknown target
    if target in ("webapp", "", "none"):
        return True, "No compilation needed — project is ready to run.", None

    return True, f"Build commands completed. No auto-compiler for {lang}/{target}.", None


# ── OAC generation prompt for the AI ──

OAC_GENERATION_PROMPT = """After you finish building and verifying the project, generate a .oac build manifest.
Call write_file with path "build.oac" and content that is a JSON object with these fields:
{
  "oac_version": "1.0",
  "project_name": "<short project name>",
  "language": "<primary language: python/javascript/typescript/html/c/cpp/rust/go/java/etc>",
  "entry_point": "<main file to run, e.g. main.py or index.html>",
  "build_commands": ["<ordered shell commands to install deps and build, e.g. npm install, pip install -r requirements.txt>"],
  "compile_target": "<what to produce: exe/binary/jar/webapp/none>",
  "files": ["<list of all files you created>"],
  "dependencies": {"<package>": "<version>"},
  "notes": "<any special instructions for running or compiling>"
}

Rules for the manifest:
- For web projects (HTML/JS): language="html" or "javascript", compile_target="webapp", build_commands can be empty
- For Python scripts: language="python", compile_target="exe" if it should be a standalone program
- For Node.js apps: include "npm install" in build_commands
- The manifest must be valid JSON
- Write it as the LAST file before your final summary
"""
