"""Context window manager with tiered compression for maintaining long conversation history."""

import json
import os
import re
from typing import Any, Callable

from openartemis.config import resolve_artemis_model, completion_tokens_kwarg


COMPRESS_PROMPT = """Summarize these conversation messages into key facts, decisions, code changes, files created, issues found, and fixes applied. Be concise but preserve ALL technical details (file names, variable names, error messages, stack choices). Output a single dense paragraph.

Messages to compress:
{messages_text}"""


# ── Tier 0: Rule-based noise stripping ──

# ANSI escape codes (colors, cursor movement, etc.)
_ANSI_RE = re.compile(r"\x1b\[[0-9;]*[a-zA-Z]|\x1b\].*?\x07")
# npm/yarn progress bars and download lines
_NPM_NOISE_RE = re.compile(r"^(npm (WARN|notice|http)|added \d+ packages|[\s│├└─┐┘┬┴┤┌]+$|⸩\s*$|\d+\.\d+ MB|\.{3,}$|#+ +\d+(\.\d+)?%)", re.MULTILINE)
# Repeated blank lines
_MULTI_BLANK_RE = re.compile(r"\n{3,}")


def _strip_noise(text: str) -> str:
    """Strip terminal noise from text: ANSI codes, npm progress, repeated blanks.

    This is Tier 0 compression — pure mechanical, zero cost, runs before LLM.
    """
    if not text:
        return text
    # Strip ANSI escape codes
    text = _ANSI_RE.sub("", text)
    # Strip npm/yarn noise lines
    text = _NPM_NOISE_RE.sub("", text)
    # Collapse repeated blank lines
    text = _MULTI_BLANK_RE.sub("\n\n", text)
    # Strip node_modules file listings
    lines = text.split("\n")
    filtered = []
    for line in lines:
        stripped = line.strip()
        # Skip node_modules paths, empty lines in bulk
        if "node_modules/" in stripped:
            continue
        # Skip progress percentages
        if re.match(r"^\d+%\s", stripped):
            continue
        filtered.append(line)
    return "\n".join(filtered).strip()


def compress_tool_result(tool_name: str, result: str, max_len: int = 2000) -> str:
    """Compress a single tool result for the agent conversation history.

    Applied inline during the agent loop — not deferred to context window compression.
    Keeps the main context pristine by stripping noise at the source.
    """
    if not result:
        return result

    # Strip noise first (free, always)
    result = _strip_noise(result)

    # Tool-specific compression
    if tool_name == "run_terminal":
        # Aggressively truncate install/build output
        if len(result) > max_len:
            # Keep first 500 + last 500 chars with truncation notice
            mid = len(result) - 1000
            result = result[:500] + f"\n...[{mid} chars stripped]...\n" + result[-500:]

    elif tool_name == "write_file":
        # Only keep the confirmation line, strip content echo
        lines = result.split("\n")
        kept = [l for l in lines if l.startswith("Wrote ") or l.startswith("[LINT]")]
        if kept:
            result = "\n".join(kept)

    elif tool_name == "read_file":
        # Cap file content reads
        if len(result) > max_len:
            result = result[:max_len] + f"\n...[truncated, {len(result) - max_len} chars omitted]"

    # Final length cap
    if len(result) > max_len:
        result = result[:max_len] + "\n...[truncated]"

    return result


def count_tokens(text: str) -> int:
    """Estimate token count using ~4 chars per token heuristic."""
    if not text:
        return 0
    return max(1, len(text) // 4)


def count_messages_tokens(messages: list[dict[str, Any]]) -> int:
    """Estimate total tokens across a list of messages."""
    try:
        raw = json.dumps(messages, default=str)
        return max(1, len(raw) // 4)
    except Exception:
        return sum(count_tokens(m.get("content", "")) for m in messages)


class ContextWindow:
    """Manages a conversation context window with automatic compression.
    
    When the total token count exceeds the soft limit (80% of max_tokens),
    older messages are compressed into a summary to free space.
    """

    def __init__(self, max_tokens: int = 200_000, role: str = "chat"):
        self.max_tokens = max_tokens
        self.role = role  # "chat" or "agent"
        self.messages: list[dict[str, Any]] = []
        self.compressed_summary: str = ""
        self._soft_limit = int(max_tokens * 0.8)
        self._keep_recent = 20 if role == "chat" else 30  # messages to keep uncompressed

    def add(self, message: dict[str, Any]) -> None:
        """Add a message to the context window."""
        self.messages.append(message)
        self._maybe_compress()

    def add_many(self, messages: list[dict[str, Any]]) -> None:
        """Add multiple messages at once."""
        self.messages.extend(messages)
        self._maybe_compress()

    def get_total_tokens(self) -> int:
        """Get estimated total token count (compressed summary + messages)."""
        summary_tokens = count_tokens(self.compressed_summary)
        messages_tokens = count_messages_tokens(self.messages)
        return summary_tokens + messages_tokens

    def get_messages_for_api(self, system_prompt: str = "") -> list[dict[str, Any]]:
        """Get messages formatted for API call, including compressed context.
        
        Returns: [system_msg, (compressed_context_msg)?, ...recent_messages]
        """
        result = []

        # System prompt first
        if system_prompt:
            result.append({"role": "system", "content": system_prompt})

        # Inject compressed context if we have any
        if self.compressed_summary:
            result.append({
                "role": "system",
                "content": f"[COMPRESSED CONTEXT FROM EARLIER]\n{self.compressed_summary}\n[END COMPRESSED CONTEXT]"
            })

        # Add all current messages
        result.extend(self.messages)

        return result

    def _maybe_compress(self) -> None:
        """Compress older messages if we're over the soft limit.

        Tiered compression:
          Tier 0: Rule-based noise stripping (ANSI, install logs, progress bars)
          Tier 1: Haiku LLM summarization of stripped text
          Tier 2: Re-compress summary if it exceeds 4000 tokens
        """
        current_tokens = self.get_total_tokens()
        if current_tokens <= self._soft_limit:
            return

        # Don't compress if we have very few messages
        if len(self.messages) <= self._keep_recent + 2:
            return

        # Split: older messages to compress, recent to keep
        split_point = len(self.messages) - self._keep_recent
        if split_point <= 0:
            return

        to_compress = self.messages[:split_point]
        to_keep = self.messages[split_point:]

        # Tier 0: Rule-based noise stripping
        compress_text = self._messages_to_text(to_compress)
        compress_text = _strip_noise(compress_text)

        # Tier 1: LLM compression (Haiku — cheap + fast)
        new_summary = self._compress_via_llm(compress_text)
        if new_summary:
            # Merge with existing compressed summary
            if self.compressed_summary:
                self.compressed_summary = f"{self.compressed_summary}\n\n--- Later ---\n{new_summary}"
            else:
                self.compressed_summary = new_summary

            # Tier 2: Re-compress if summary exceeds 4000 tokens (was 8000)
            summary_tokens = count_tokens(self.compressed_summary)
            if summary_tokens > 4000:
                re_compressed = self._compress_via_llm(self.compressed_summary)
                if re_compressed:
                    self.compressed_summary = re_compressed

        # Keep only recent messages
        self.messages = to_keep

    def _messages_to_text(self, messages: list[dict[str, Any]]) -> str:
        """Convert messages to plain text for compression."""
        parts = []
        for m in messages:
            role = m.get("role", "unknown")
            content = m.get("content", "")
            if isinstance(content, list):
                # Anthropic-native content blocks — extract text only
                text_parts = []
                for block in content:
                    if isinstance(block, dict):
                        if block.get("type") == "text":
                            text_parts.append(block.get("text", ""))
                        elif block.get("type") == "tool_result":
                            text_parts.append(block.get("content", "")[:300])
                content = " ".join(text_parts)
            if not content:
                continue
            # Truncate very long tool results
            if role == "tool" and len(content) > 500:
                content = content[:500] + "...[truncated]"
            # Apply noise stripping to individual tool results
            if role == "tool":
                content = _strip_noise(content)
            parts.append(f"[{role}]: {content}")
        return "\n".join(parts)

    def _compress_via_llm(self, text: str) -> str:
        """Use Haiku to compress text into a concise summary (cheap + fast)."""
        try:
            from openartemis.config import get_anthropic_client
            client = get_anthropic_client()
            # Use Haiku for compression — 10x cheaper than Sonnet
            model = "claude-haiku-4-5"
            # Cap input to avoid huge API calls
            if len(text) > 40000:
                text = text[:40000] + "\n...[truncated for compression]"

            resp = client.messages.create(
                model=model,
                max_tokens=1024,
                messages=[
                    {"role": "user", "content": COMPRESS_PROMPT.format(messages_text=text)}
                ],
            )
            result = (resp.content[0].text or "").strip()
            return result if result else self._compress_fallback(text)
        except Exception:
            return self._compress_fallback(text)

    def _compress_fallback(self, text: str) -> str:
        """Fallback compression without LLM: extract key lines."""
        lines = text.split("\n")
        # Keep lines mentioning files, errors, or key actions
        key_patterns = ["file", "error", "fix", "issue", "created", "wrote", "build", "install", "test"]
        important = []
        for line in lines:
            lower = line.lower()
            if any(p in lower for p in key_patterns):
                important.append(line.strip())
        if not important:
            # Just keep first and last few lines
            important = lines[:5] + ["..."] + lines[-5:]
        return "\n".join(important[:50])

    def to_dict(self) -> dict:
        """Serialize for persistence."""
        return {
            "max_tokens": self.max_tokens,
            "role": self.role,
            "messages": self.messages,
            "compressed_summary": self.compressed_summary,
        }

    @classmethod
    def from_dict(cls, data: dict) -> "ContextWindow":
        """Deserialize from persistence."""
        cw = cls(
            max_tokens=data.get("max_tokens", 200_000),
            role=data.get("role", "chat"),
        )
        cw.messages = data.get("messages", [])
        cw.compressed_summary = data.get("compressed_summary", "")
        return cw
