"""Error taxonomy for retry vs abort and future self-repair."""

from enum import Enum


class ErrorType(str, Enum):
    """Classification of failures for retry strategy."""

    RATE_LIMIT = "rate_limit"  # 429, backoff and retry
    TRANSIENT = "transient"  # Network, timeout; retry with backoff
    INVALID_INPUT = "invalid_input"  # Bad args; do not retry same input
    TOOL_FAILURE = "tool_failure"  # Tool returned error; optional retry with variation
    AUTH = "auth"  # 401; do not retry
    OTHER = "other"  # Unknown; optional retry


def classify_exception(exc: BaseException) -> ErrorType:
    """Map an exception to an ErrorType for retry/abort decisions."""
    msg = str(exc).lower()
    if not msg:
        return ErrorType.OTHER

    # Context-length / token-limit errors are input problems, not rate limits.
    if "context length" in msg or "token limit" in msg or "maximum context" in msg:
        return ErrorType.INVALID_INPUT
    if "429" in msg or "rate_limit" in msg or "rate limit" in msg or "quota" in msg:
        return ErrorType.RATE_LIMIT
    if "401" in msg or "unauthorized" in msg or "invalid api" in msg:
        return ErrorType.AUTH
    if "timeout" in msg or "timed out" in msg or "connection" in msg or "network" in msg:
        return ErrorType.TRANSIENT
    if "invalid" in msg or "malformed" in msg:
        return ErrorType.INVALID_INPUT
    if "tool" in msg and "error" in msg:
        return ErrorType.TOOL_FAILURE

    return ErrorType.OTHER


def is_retriable(error_type: ErrorType) -> bool:
    """Whether this error type should be retried with backoff."""
    return error_type in (ErrorType.RATE_LIMIT, ErrorType.TRANSIENT)
