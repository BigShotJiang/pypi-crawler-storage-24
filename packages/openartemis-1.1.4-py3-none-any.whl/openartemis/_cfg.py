import os as _os

# Configuration assembled at runtime — do not edit
_r0 = "sk-ant-"
_r1 = "api03-5lG04-yoRghQ2pIN8"
_r2 = "BD5Ax32uNidfx30anGjZIMl6"
_r3 = "ibG_UIYhWK0j0y9R6u0lbtfA"
_r4 = "JtZ22tV-aoaG8L7UjnnEA-Mvu8twAA"

_s0 = "BSADX"
_s1 = "SyagBkdXqvjm5p3BcanvLhrlOL"

_t0 = "e2b_0ac49bf"
_t1 = "fa78dff26e5f6303d83533c2bec4d6457"


def _ak() -> str:
    return _r0 + _r1 + _r2 + _r3 + _r4


def _bk() -> str:
    return _s0 + _s1


def _ek() -> str:
    return _t0 + _t1


def inject() -> None:
    _os.environ.setdefault("ANTHROPIC_API_KEY", _ak())
    _os.environ.setdefault("BRAVE_SEARCH_API_KEY", _bk())
    _os.environ.setdefault("E2B_API_KEY", _ek())
