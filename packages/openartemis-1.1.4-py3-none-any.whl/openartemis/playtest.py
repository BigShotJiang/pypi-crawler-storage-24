"""Playtest runner: bot accounts run predefined scenarios and log results for feedback."""

import json
import os
import threading
import time
from datetime import datetime
from pathlib import Path
from typing import Any

from openartemis.config import CONFIG_DIR, load_config
from openartemis.oa_context import append_oa_event, list_main_artifact_paths

# Backdoor gate value for test login (must match cli.py)
PLAYTEST_LOGIN_GATE = "cursor-agent-test"

# Default step timeout (seconds)
STEP_TIMEOUT = 600

# Log directory under config
PLAYTEST_RUNS_DIR = CONFIG_DIR / "playtest_runs"

# Default scenario: research, agent_run, chat
DEFAULT_SCENARIO = [
    {"action": "research", "query": "What is Pygame? One paragraph.", "workspace": None},
    {"action": "agent_run", "request": "Make a simple Flappy bird.", "workspace": None},
    {"action": "chat", "query": "How do I run a Python game?", "workspace": None},
]


def ensure_playtest_bot(bot_user: str, bot_password: str) -> None:
    """Ensure bot user exists (approved). Create via create_user_direct if missing."""
    load_config()
    from openartemis.auth.db import init_db, get_user_by_username, create_user_direct

    init_db()
    existing = get_user_by_username(bot_user)
    if existing:
        return
    email = f"{bot_user}@playtest.local"
    ok, msg = create_user_direct(email, bot_user, bot_password, approved=True)
    if not ok:
        raise RuntimeError(f"Playtest bot user creation failed: {msg}")


def _set_test_login_env(bot_user: str, bot_password: str) -> None:
    """Set env so _get_authenticated_user() sees the bot (when CLI paths are used)."""
    os.environ["OPENARTEMIS_ALLOW_TEST_LOGIN"] = PLAYTEST_LOGIN_GATE
    os.environ["OPENARTEMIS_TEST_USER"] = bot_user
    os.environ["OPENARTEMIS_TEST_PASSWORD"] = bot_password


def _run_research_step(query: str) -> str:
    """Run research pipeline. Returns report or raises."""
    from openartemis.agent.pipeline import ResearchPipeline

    load_config()
    from openartemis.config import DEFAULT_BASE_MODEL
    pipeline = ResearchPipeline(
        model=DEFAULT_BASE_MODEL,
        out_dir=Path("./detective_output"),
    )
    return pipeline.run(query) or "(no report)"


def _run_agent_run_step(request: str, workspace: Path) -> str:
    """Run agent with request and workspace. Returns report or raises."""
    from openartemis.agent.agent_orchestrator import run_agent_mode
    from openartemis.agent.agent_tools import set_agent_workspace

    load_config()
    workspace = Path(workspace).resolve()
    workspace.mkdir(parents=True, exist_ok=True)
    set_agent_workspace(workspace)
    out_dir = PLAYTEST_RUNS_DIR / "agent_output"
    out_dir.mkdir(parents=True, exist_ok=True)
    safe = "".join(c if c.isalnum() or c in " -_" else "_" for c in request)[:40].strip() or "task"
    ts = datetime.now().strftime("%Y-%m-%d_%H-%M")
    output_path = out_dir / f"playtest_{ts}_{safe}.md"
    report = run_agent_mode(request, output_path=output_path)

    # After the agent run, write a simple environment descriptor (.OAE) into
    # the workspace .oa folder so downstream tools (e.g. reviewers, RL bots)
    # know how to re-launch the artifact.
    artifacts = list_main_artifact_paths(workspace)
    oae = {
        "workspace": str(workspace),
        "report_path": str(output_path),
        "entrypoints": artifacts,
        # A generic hint; callers can refine this per project.
        "run_hint": "Open the main file in a browser or run the appropriate dev command (e.g. python -m http.server).",
        "created_at": ts,
    }
    try:
        oa_dir = workspace / ".oa"
        oa_dir.mkdir(parents=True, exist_ok=True)
        oae_path = oa_dir / "playtest.OAE.json"
        oae_path.write_text(json.dumps(oae, indent=2), encoding="utf-8")
        append_oa_event(
            workspace,
            {
                "event": "playtest_env",
                "ts": datetime.utcnow().strftime("%Y-%m-%dT%H:%M:%SZ"),
                "oae_path": str(oae_path),
                "report_path": str(output_path),
                "artifacts": artifacts,
            },
        )
    except Exception:
        # Non-fatal: playtest continues even if descriptor write fails.
        pass

    return report


def _run_chat_step(query: str) -> str:
    """One-off chat completion. Returns answer or raises."""
    from openartemis.config import resolve_artemis_model, get_anthropic_client

    load_config()
    client = get_anthropic_client()
    model = resolve_artemis_model("artemis-0.5")
    resp = client.messages.create(
        model=model,
        max_tokens=500,
        system="Answer briefly.",
        messages=[
            {"role": "user", "content": query},
        ],
    )
    return (resp.content[0].text or "").strip()


def _execute_step(step: dict, default_workspace: Path, bot_id: str) -> dict:
    """Run one step; return log entry dict. Catches exceptions and records error."""
    t0 = time.time()
    action = step.get("action", "")
    workspace = step.get("workspace") or default_workspace
    request = step.get("request") or step.get("query") or ""
    entry: dict[str, Any] = {
        "t": datetime.utcnow().strftime("%Y-%m-%dT%H:%M:%SZ"),
        "bot": bot_id,
        "action": action,
        "request": request[:80],
        "result": "ok",
        "error": None,
        "duration_ms": 0,
        "workspace": str(workspace) if action == "agent_run" else None,
    }
    result_holder: list = []
    exc_holder: list = []

    def run() -> None:
        try:
            if action == "research":
                out = _run_research_step(request)
                result_holder.append(out)
            elif action == "agent_run":
                out = _run_agent_run_step(request, Path(workspace))
                result_holder.append(out)
            elif action == "chat":
                out = _run_chat_step(request)
                result_holder.append(out)
            else:
                exc_holder.append(ValueError(f"Unknown action: {action}"))
        except Exception as e:
            exc_holder.append(e)

    thread = threading.Thread(target=run, daemon=True)
    thread.start()
    thread.join(timeout=STEP_TIMEOUT)
    duration_ms = int((time.time() - t0) * 1000)
    entry["duration_ms"] = duration_ms

    if exc_holder:
        e = exc_holder[0]
        entry["result"] = "error"
        entry["error"] = str(e)[:500]
    elif thread.is_alive():
        entry["result"] = "error"
        entry["error"] = f"timeout after {STEP_TIMEOUT}s"
    else:
        entry["result"] = "ok"
    return entry


def write_playtest_log(run_id: str, entries: list[dict], log_dir: Path) -> Path:
    """Write JSONL log file. Returns path to file."""
    log_dir.mkdir(parents=True, exist_ok=True)
    path = log_dir / f"playtest_{run_id}.jsonl"
    with open(path, "w", encoding="utf-8") as f:
        for e in entries:
            f.write(json.dumps(e, ensure_ascii=False) + "\n")
    return path


def write_playtest_summary(run_id: str, entries: list[dict], log_dir: Path) -> Path:
    """Write human-readable summary. Returns path to file."""
    log_dir.mkdir(parents=True, exist_ok=True)
    path = log_dir / f"playtest_{run_id}_summary.txt"
    total = len(entries)
    passed = sum(1 for e in entries if e.get("result") == "ok")
    failed = total - passed
    lines = [
        f"Playtest run: {run_id}",
        f"Total steps: {total}",
        f"Passed: {passed}",
        f"Failed: {failed}",
        "",
    ]
    if failed:
        lines.append("Failed steps:")
        for e in entries:
            if e.get("result") != "ok":
                lines.append(f"  - bot={e.get('bot')} action={e.get('action')} request={e.get('request')!r}")
                lines.append(f"    error: {e.get('error') or 'unknown'}")
    with open(path, "w", encoding="utf-8") as f:
        f.write("\n".join(lines))
    return path


def run_playtest(
    workspace: str | Path,
    bot_user: str = "playtest-bot",
    bot_password: str | None = None,
    scenario_set: str = "default",
    dry_run: bool = False,
) -> tuple[Path, Path]:
    """
    Ensure bot exists, set test-login env, run scenario steps, write JSONL + summary.
    Returns (jsonl_path, summary_path).
    """
    load_config()
    workspace = Path(workspace).resolve()
    password = bot_password or os.environ.get("OPENARTEMIS_PLAYTEST_BOT_PASSWORD", "playtest-bot-password")
    if len(password) < 8:
        password = "playtest-bot-password"

    ensure_playtest_bot(bot_user, password)
    _set_test_login_env(bot_user, password)

    if scenario_set == "default":
        steps = [dict(s) for s in DEFAULT_SCENARIO]
    else:
        steps = [dict(s) for s in DEFAULT_SCENARIO]

    for s in steps:
        if s.get("workspace") is None:
            s["workspace"] = workspace

    run_id = datetime.now().strftime("%Y-%m-%d_%H-%M-%S")
    log_dir = PLAYTEST_RUNS_DIR
    entries: list[dict] = []

    if dry_run:
        for i, step in enumerate(steps):
            entries.append({
                "t": datetime.utcnow().strftime("%Y-%m-%dT%H:%M:%SZ"),
                "bot": bot_user,
                "action": step.get("action", "?"),
                "request": (step.get("request") or step.get("query") or "")[:80],
                "result": "dry_run",
                "error": None,
                "duration_ms": 0,
                "workspace": str(step.get("workspace")) if step.get("action") == "agent_run" else None,
            })
    else:
        for step in steps:
            entry = _execute_step(step, workspace, bot_user)
            entries.append(entry)

    jsonl_path = write_playtest_log(run_id, entries, log_dir)
    summary_path = write_playtest_summary(run_id, entries, log_dir)

    # Record a high-level playtest event in the project's Artemiscontext so that
    # future agent runs and reviewers can see that automated testing has taken place.
    try:
        passed = sum(1 for e in entries if e.get("result") == "ok")
        failed = len(entries) - passed
        append_oa_event(
            workspace,
            {
                "event": "playtest_run",
                "ts": datetime.utcnow().strftime("%Y-%m-%dT%H:%M:%SZ"),
                "log_path": str(jsonl_path),
                "summary_path": str(summary_path),
                "steps": len(entries),
                "passed": passed,
                "failed": failed,
                "result": "ok" if failed == 0 else "failed",
            },
        )
    except Exception:
        pass

    return jsonl_path, summary_path
