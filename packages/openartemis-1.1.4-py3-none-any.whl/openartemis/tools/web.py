"""Web tools: Brave Search, fetch_webpage (trafilatura), browse_webpage (Playwright).
Brave Search API: ~1 request/second; 429 when exceeded. We throttle and retry on 429."""

import logging
import os
import time
from typing import Any

import requests
from dotenv import load_dotenv
from pathlib import Path

load_dotenv(Path(__file__).resolve().parents[2] / ".env")

logger = logging.getLogger(__name__)

BRAVE_API_URL = "https://api.search.brave.com/res/v1/web/search"
BRAVE_MIN_GAP_SEC = 1.0
_brave_last_call: float = 0.0


def brave_search(
    q: str,
    count: int = 10,
    freshness: str | None = None,
) -> dict[str, Any]:
    """Search the web via Brave Search API. Returns results with title, url, description.
    Throttled to ~1 req/s; retries on 429 using X-RateLimit-Reset or 2s backoff."""
    api_key = os.environ.get("BRAVE_SEARCH_API_KEY", "").strip()
    if not api_key:
        return {"error": "BRAVE_SEARCH_API_KEY not set", "results": []}
    params = {"q": q, "count": min(count, 20)}
    if freshness and freshness in ("pd", "pw", "pm", "py"):
        params["freshness"] = freshness

    max_attempts = 3
    for attempt in range(max_attempts):
        global _brave_last_call
        now = time.monotonic()
        gap = _brave_last_call + BRAVE_MIN_GAP_SEC - now
        if gap > 0:
            time.sleep(gap)
        _brave_last_call = time.monotonic()
        try:
            resp = requests.get(
                BRAVE_API_URL,
                params=params,
                headers={"X-Subscription-Token": api_key},
                timeout=15,
            )
            if resp.status_code == 200:
                data = resp.json()
                results = []
                for r in data.get("web", {}).get("results", []):
                    results.append({
                        "title": r.get("title", ""),
                        "url": r.get("url", ""),
                        "description": r.get("description", ""),
                    })
                return {"results": results, "count": len(results)}
            if resp.status_code == 429:
                wait_s = 2.0
                reset = resp.headers.get("X-RateLimit-Reset")
                if reset is not None:
                    try:
                        wait_s = max(1.0, float(reset))
                    except (TypeError, ValueError):
                        pass
                if attempt < max_attempts - 1:
                    logger.warning("Brave 429, retry in %.1fs (attempt %d)", wait_s, attempt + 1)
                    time.sleep(wait_s)
                    continue
                return {"error": "Brave API rate limited (429)", "results": []}
            return {"error": f"Brave API error: {resp.status_code}", "results": []}
        except Exception as e:
            logger.warning("Brave search failed: %s", e)
            return {"error": str(e), "results": []}
    return {"error": "Brave API error after retries", "results": []}


def fetch_webpage(url: str) -> dict[str, Any]:
    """Fetch URL and extract main text with trafilatura. Fast for static HTML."""
    try:
        from trafilatura import bare_extraction, fetch_url
    except ImportError:
        return {"error": "trafilatura not installed. pip install trafilatura", "url": url}
    try:
        downloaded = fetch_url(url)
        if not downloaded:
            return {"error": "Failed to fetch URL", "url": url}
        doc = bare_extraction(downloaded, url=url, with_metadata=True)
        if not doc:
            return {"error": "No main content extracted", "url": url}
        text = doc.text if hasattr(doc, "text") else ""
        if not text:
            return {"error": "No main content extracted", "url": url}
        title = ""
        if hasattr(doc, "as_dict"):
            d = doc.as_dict()
            title = d.get("title", "") or ""
        elif hasattr(doc, "metadata") and doc.metadata:
            m = doc.metadata
            title = getattr(m, "title", "") if hasattr(m, "title") else (m.get("title", "") if isinstance(m, dict) else "")
        return {"url": url, "title": title or "", "text": (text or "")[:50000]}
    except Exception as e:
        logger.warning("fetch_webpage failed for %s: %s", url, e)
        return {"error": str(e), "url": url}


def browse_webpage(url: str, selector: str | None = None) -> dict[str, Any]:
    """Fetch URL with headless browser (Playwright). Use for JS-heavy sites."""
    try:
        from playwright.sync_api import sync_playwright
    except ImportError:
        return {"error": "playwright not installed. pip install playwright && playwright install chromium", "url": url}
    try:
        with sync_playwright() as p:
            browser = p.chromium.launch(headless=True)
            page = browser.new_page()
            page.goto(url, wait_until="domcontentloaded", timeout=15000)
            page.wait_for_load_state("networkidle", timeout=10000)
            title = page.title()
            if selector:
                elem = page.query_selector(selector)
                text = elem.inner_text() if elem else page.inner_text("body")
            else:
                text = page.inner_text("body")
            browser.close()
        return {"url": url, "title": title or "", "text": (text or "")[:50000]}
    except Exception as e:
        logger.warning("browse_webpage failed for %s: %s", url, e)
        return {"error": str(e), "url": url}
