"""OpenAI Code Interpreter wrapper via Assistants API. Run Python in a sandbox for math, data, or small scripts.
Set OPENARTEMIS_ENABLE_CODE_INTERPRETER=1 to enable. Uses OPENAI_API_KEY. Sessions are one-off (new assistant/thread per call)."""

import logging
import os
import time
from pathlib import Path

logger = logging.getLogger(__name__)

# Default timeout for run completion (seconds)
RUN_TIMEOUT = 120
POLL_INTERVAL = 1.0


def run_code_interpreter(description_or_code: str, timeout_seconds: int | None = None) -> str:
    """Run a single Code Interpreter request via OpenAI Assistants API.
    description_or_code: natural language request (e.g. 'compute sqrt(2) to 50 digits') or code snippet.
    Returns the assistant's text output or an error string."""
    if not os.environ.get("OPENAI_API_KEY"):
        return "Error: OPENAI_API_KEY not set. Code interpreter requires OpenAI."
    if not os.environ.get("OPENARTEMIS_ENABLE_CODE_INTERPRETER", "").strip().lower() in ("1", "true", "yes"):
        return "Code interpreter is disabled. Set OPENARTEMIS_ENABLE_CODE_INTERPRETER=1 to enable."
    timeout = timeout_seconds if timeout_seconds is not None else RUN_TIMEOUT
    try:
        from openartemis.config import get_openai_client
    except ImportError:
        return "Error: openai package not installed. pip install openai"
    client = get_openai_client()
    assistant = None
    try:
        assistant = client.beta.assistants.create(
            instructions="You run Python code to answer the user. Be concise. Return the result or a short summary; include key numbers or outputs.",
            model="gpt-4o",
            tools=[{"type": "code_interpreter"}],
        )
        thread = client.beta.threads.create(
            messages=[{"role": "user", "content": str(description_or_code).strip() or "Hello"}],
        )
        run = client.beta.threads.runs.create(thread_id=thread.id, assistant_id=assistant.id)
        deadline = time.monotonic() + timeout
        while time.monotonic() < deadline:
            run = client.beta.threads.runs.retrieve(thread_id=thread.id, run_id=run.id)
            if run.status == "completed":
                break
            if run.status in ("failed", "cancelled", "expired"):
                msg = getattr(run, "last_error", None)
                err = f"Run {run.status}: {msg}" if msg else str(run.status)
                return f"Code interpreter run ended: {err}"
            time.sleep(POLL_INTERVAL)
        else:
            return f"Code interpreter timed out after {timeout}s."
        messages = client.beta.threads.messages.list(thread_id=thread.id, order="desc", limit=5)
        for m in messages.data:
            if getattr(m, "role", None) == "assistant" and getattr(m, "content", None):
                for block in m.content:
                    if getattr(block, "type", None) == "text" and getattr(block, "text", None):
                        return getattr(block.text, "value", "") or "(no output)"
        return "(No assistant reply)"
    except Exception as e:
        logger.exception("Code interpreter error")
        return f"Error: {e}"
    finally:
        if assistant is not None:
            try:
                client.beta.assistants.delete(assistant.id)
            except Exception:
                pass
