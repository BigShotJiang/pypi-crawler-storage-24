"""Map Hugging Face tool-using datasets into Artemis fine-tune JSONL.

This module sketches out how to convert:
- SWE-bench / SWE-smith trajectories (SWE-bench/SWE-smith-trajectories)
- ToolBench-v1 (tuandunghcmut/toolbench-v1)

into our training schema:

{"messages": [...], "parallel_tool_calls": false, "tools": [...]}

It assumes the `datasets` library is installed (`pip install datasets`) and
that you have access to the referenced datasets. The exact field names in
those datasets may evolve, so the mapping functions are written to make it
obvious where to adapt them if schemas change.
"""

from __future__ import annotations

from pathlib import Path
from typing import Any, Dict, List

from datasets import Dataset, load_dataset

from openartemis.fine_tune.schema import ARTEMIS_AGENT_SYSTEM_PROMPT, get_agent_tools_spec


def _swe_smith_to_example(row: Dict[str, Any]) -> Dict[str, Any]:
    """Convert one SWE-smith trajectory row into an Artemis JSONL example.

    Expected (conceptual) fields in `row` (names may differ slightly):
    - row["problem_statement"]: natural language description of the bug/task.
    - row["trajectory"]: list of tool-like actions with keys such as
      {"action": "run", "tool_name": "bash", "args": "...", "stdout": "..."}.

    If your local dataset uses different keys, adjust this function to match.
    """
    user_goal = row.get("problem_statement") or "Fix the bug described in this SWE-smith task."
    messages: List[Dict[str, Any]] = [
        {"role": "system", "content": ARTEMIS_AGENT_SYSTEM_PROMPT},
        {"role": "user", "content": f"Goal: {user_goal}"},
    ]
    tools = get_agent_tools_spec()

    # Map SWE-smith tool names to Artemis tool functions
    def map_tool_name(name: str) -> str:
        lower = (name or "").lower()
        if lower in ("bash", "shell", "run", "terminal"):
            return "run_terminal"
        if lower in ("open_file", "read_file"):
            return "read_file"
        if lower in ("write_file", "apply_patch"):
            return "apply_patch"
        return "run_terminal"

    traj = row.get("trajectory") or []
    call_id_counter = 0
    for step in traj:
        tool_name_raw = step.get("tool_name") or step.get("action")
        mapped_name = map_tool_name(str(tool_name_raw))
        call_id_counter += 1
        call_id = f"call_{call_id_counter}"
        args: Dict[str, Any] = {}

        if mapped_name == "run_terminal":
            args = {"command": step.get("command") or step.get("args") or ""}
        elif mapped_name == "read_file":
            args = {"path": step.get("path") or step.get("file") or ""}
        elif mapped_name == "apply_patch":
            args = {
                "path": step.get("path") or step.get("file") or "",
                "patch": step.get("patch") or step.get("diff") or "",
            }

        messages.append(
            {
                "role": "assistant",
                "tool_calls": [
                    {
                        "id": call_id,
                        "type": "function",
                        "function": {
                            "name": mapped_name,
                            "arguments": __import__("json").dumps(args, ensure_ascii=False),
                        },
                    }
                ],
            }
        )
        # Use stdout / new file content as tool result preview
        stdout = step.get("stdout") or step.get("result") or ""
        messages.append({"role": "tool", "tool_call_id": call_id, "content": stdout[:1000]})

    messages.append(
        {
            "role": "assistant",
            "content": "Bug fix applied based on the edits and test runs above. "
            "Summarize which files were changed and whether the test command now passes.",
        }
    )

    return {
        "messages": messages,
        "parallel_tool_calls": False,
        "tools": tools,
    }


def export_swe_smith(
    output_path: Path,
    split: str = "train",
    limit: int | None = None,
) -> None:
    """Load SWE-smith trajectories from Hugging Face and export to JSONL.

    The dataset name and split may need adjustment depending on how you
    prefer to slice SWE-smith locally.
    """
    ds: Dataset = load_dataset("SWE-bench/SWE-smith-trajectories", split=split)  # type: ignore[arg-type]
    if limit is not None:
        ds = ds.select(range(min(limit, len(ds))))

    output_path.parent.mkdir(parents=True, exist_ok=True)
    import json

    with output_path.open("w", encoding="utf-8") as f:
        for row in ds:
            ex = _swe_smith_to_example(row)
            f.write(json.dumps(ex, ensure_ascii=False) + "\n")


def _toolbench_to_example(row: Dict[str, Any]) -> Dict[str, Any]:
    """Convert one ToolBench row into our JSONL schema.

    ToolBench typically contains:
    - a user query
    - one or more tool calls with arguments
    - ground truth tool responses
    """
    user_query = row.get("query") or row.get("instruction") or "Use tools to answer the question."
    tool_calls = row.get("tool_calls") or row.get("trajectory") or []

    messages: List[Dict[str, Any]] = [
        {"role": "system", "content": ARTEMIS_AGENT_SYSTEM_PROMPT},
        {"role": "user", "content": user_query},
    ]
    tools = get_agent_tools_spec()

    import json

    call_id_counter = 0
    for tc in tool_calls:
        name = tc.get("tool_name") or tc.get("name")
        args = tc.get("arguments") or tc.get("args") or {}
        call_id_counter += 1
        call_id = f"call_{call_id_counter}"
        messages.append(
            {
                "role": "assistant",
                "tool_calls": [
                    {
                        "id": call_id,
                        "type": "function",
                        "function": {
                            "name": name,
                            "arguments": json.dumps(args, ensure_ascii=False),
                        },
                    }
                ],
            }
        )
        result = tc.get("result") or tc.get("observation") or ""
        messages.append({"role": "tool", "tool_call_id": call_id, "content": result[:1000]})

    messages.append(
        {
            "role": "assistant",
            "content": "Answer the user based on the tool results above. "
            "Cite which tools you used and include concrete next commands or file paths if relevant.",
        }
    )

    return {
        "messages": messages,
        "parallel_tool_calls": False,
        "tools": tools,
    }


def export_toolbench(
    output_path: Path,
    split: str = "train",
    limit: int | None = None,
) -> None:
    """Export ToolBench-v1 rows into Artemis JSONL.

    Adjust dataset name or config if you are using a different slice of
    ToolBench locally.
    """
    ds: Dataset = load_dataset("tuandunghcmut/toolbench-v1", split=split)  # type: ignore[arg-type]
    if limit is not None:
        ds = ds.select(range(min(limit, len(ds))))

    output_path.parent.mkdir(parents=True, exist_ok=True)
    import json

    with output_path.open("w", encoding="utf-8") as f:
        for row in ds:
            ex = _toolbench_to_example(row)
            f.write(json.dumps(ex, ensure_ascii=False) + "\n")

