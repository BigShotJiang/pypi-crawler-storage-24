"""Schemas and prompts for Artemis fine-tuning datasets.

This module defines the canonical system prompts and tool registries
used when generating JSONL examples for OpenAI fine-tuning. Keeping
them in one place ensures that training data and runtime stay aligned.
"""

from __future__ import annotations

from typing import Any, Dict, List


ARTEMIS_AGENT_SYSTEM_PROMPT: str = """
You are Artemis Agent, an autonomous coding worker for OpenArtemis.

You operate ONLY inside WORKSPACE_ROOT. Never read, write, or run commands
outside this workspace. Never use absolute paths outside WORKSPACE_ROOT and
never traverse upwards with `..`.

Behavior:
- You always READ BEFORE YOU EDIT. Use `read_file` and `list_dir` to inspect
  the workspace before making changes.
- Prefer `apply_patch` or `search_replace` for modifications to existing
  files. Use `write_file` mainly for new files or very small complete files.
- When you change executable code, run appropriate tests or checks with
  `run_terminal` (e.g. `pytest`, `npm test`, `npm run lint`), then interpret
  failures and fix them.
- When a prompt is vague, contradictory, or missing critical details, ask
  clarifying questions before doing heavy work.
- You can work for many steps. Do not rush to a final answer; prioritize
  correctness, robustness, and clear instructions for how to run the result.

Tool discipline:
- Do not fabricate file contents; always read first when updating.
- Do not run networked package installs in a tight loop; if installs keep
  failing, explain exact commands for the user instead of retrying forever.
- Keep commands reproducible and simple; prefer standard tooling.
""".strip()


ARTEMIS_RESEARCH_SYSTEM_PROMPT: str = """
You are Artemis Research Agent.

You answer complex questions by using web/search tools, harvesting transcripts,
and synthesizing a concise, sourced report. You:
- Use tools to gather facts.
- Cross-check sources and highlight disagreements.
- Produce an executive summary, key findings with citations like [1], [2],
  and a numbered Sources list.
- When appropriate, finish with a short handoff plan for Agent Mode describing
  what code or changes Artemis Agent should implement next.
""".strip()


def _agent_tools() -> List[Dict[str, Any]]:
    """Return the OpenAI tools spec for coding Agent fine-tunes."""
    return [
        {
            "type": "function",
            "function": {
                "name": "list_dir",
                "description": "List directory contents inside the workspace.",
                "parameters": {
                    "type": "object",
                    "properties": {
                        "path": {"type": "string", "description": "Directory path relative to WORKSPACE_ROOT."}
                    },
                    "required": ["path"],
                },
            },
        },
        {
            "type": "function",
            "function": {
                "name": "read_file",
                "description": "Read a text or JSON file from the workspace.",
                "parameters": {
                    "type": "object",
                    "properties": {
                        "path": {"type": "string", "description": "File path relative to WORKSPACE_ROOT."}
                    },
                    "required": ["path"],
                },
            },
        },
        {
            "type": "function",
            "function": {
                "name": "write_file",
                "description": "Create or overwrite a file in the workspace.",
                "parameters": {
                    "type": "object",
                    "properties": {
                        "path": {"type": "string"},
                        "content": {"type": "string"},
                    },
                    "required": ["path", "content"],
                },
            },
        },
        {
            "type": "function",
            "function": {
                "name": "search_in_files",
                "description": "Search for a string in files under a path.",
                "parameters": {
                    "type": "object",
                    "properties": {
                        "query": {"type": "string"},
                        "path": {"type": "string"},
                        "max_results": {"type": "integer", "minimum": 1, "maximum": 200},
                    },
                    "required": ["query", "path"],
                },
            },
        },
        {
            "type": "function",
            "function": {
                "name": "apply_patch",
                "description": "Apply a unified diff patch to a file in the workspace.",
                "parameters": {
                    "type": "object",
                    "properties": {
                        "path": {"type": "string"},
                        "patch": {"type": "string", "description": "Unified diff starting with *** Begin Patch."},
                    },
                    "required": ["path", "patch"],
                },
            },
        },
        {
            "type": "function",
            "function": {
                "name": "search_replace",
                "description": "Replace occurrences of a string in a file.",
                "parameters": {
                    "type": "object",
                    "properties": {
                        "path": {"type": "string"},
                        "old_string": {"type": "string"},
                        "new_string": {"type": "string"},
                    },
                    "required": ["path", "old_string", "new_string"],
                },
            },
        },
        {
            "type": "function",
            "function": {
                "name": "run_terminal",
                "description": "Run a shell command inside the workspace.",
                "parameters": {
                    "type": "object",
                    "properties": {
                        "command": {"type": "string", "description": "Command to run relative to WORKSPACE_ROOT."}
                    },
                    "required": ["command"],
                },
            },
        },
        {
            "type": "function",
            "function": {
                "name": "generate_image",
                "description": "Generate an image asset and save it to the workspace.",
                "parameters": {
                    "type": "object",
                    "properties": {
                        "description": {"type": "string", "description": "Natural language description of the image."},
                        "path": {"type": "string", "description": "Output path, e.g. assets/bird.png."},
                    },
                    "required": ["description", "path"],
                },
            },
        },
        {
            "type": "function",
            "function": {
                "name": "take_screenshot",
                "description": "Capture a screenshot of a URL or local HTML file and analyze it.",
                "parameters": {
                    "type": "object",
                    "properties": {
                        "url_or_path": {"type": "string"},
                        "prompt": {"type": "string"},
                    },
                    "required": ["url_or_path", "prompt"],
                },
            },
        },
        {
            "type": "function",
            "function": {
                "name": "get_secret",
                "description": "Retrieve a named secret (API key, token) from the vault.",
                "parameters": {
                    "type": "object",
                    "properties": {"key": {"type": "string"}},
                    "required": ["key"],
                },
            },
        },
    ]


def _research_tools() -> List[Dict[str, Any]]:
    """Return tools spec for Research Agent fine-tunes."""
    return [
        {
            "type": "function",
            "function": {
                "name": "harvest_transcripts",
                "description": "Download and transcribe videos or social clips for research.",
                "parameters": {
                    "type": "object",
                    "properties": {
                        "query": {"type": "string"},
                        "platforms": {"type": "array", "items": {"type": "string"}},
                        "max_results": {"type": "integer", "minimum": 1, "maximum": 50},
                    },
                    "required": ["query"],
                },
            },
        },
        {
            "type": "function",
            "function": {
                "name": "brave_search",
                "description": "Search the web for recent, relevant pages.",
                "parameters": {
                    "type": "object",
                    "properties": {
                        "q": {"type": "string"},
                        "count": {"type": "integer", "minimum": 1, "maximum": 20},
                    },
                    "required": ["q"],
                },
            },
        },
        {
            "type": "function",
            "function": {
                "name": "fetch_webpage",
                "description": "Fetch and extract the main text content from a URL.",
                "parameters": {
                    "type": "object",
                    "properties": {"url": {"type": "string"}},
                    "required": ["url"],
                },
            },
        },
        {
            "type": "function",
            "function": {
                "name": "browse_webpage",
                "description": "Open a URL in a headless browser and interact if necessary.",
                "parameters": {
                    "type": "object",
                    "properties": {"url": {"type": "string"}},
                    "required": ["url"],
                },
            },
        },
    ]


def get_agent_tools_spec() -> List[Dict[str, Any]]:
    """Public helper used by dataset builders for coding Agent examples."""
    return _agent_tools()


def get_research_tools_spec() -> List[Dict[str, Any]]:
    """Public helper used by dataset builders for Research Agent examples."""
    return _research_tools()


def _o3de_tools() -> List[Dict[str, Any]]:
    """Return tools spec for O3DE Game Agent fine-tunes."""
    return [
        {"type": "function", "function": {
            "name": "o3de_create_project",
            "description": "Create a new O3DE project with required gems.",
            "parameters": {"type": "object", "properties": {
                "name": {"type": "string"}, "template": {"type": "string", "default": "Standard"},
            }, "required": ["name"]},
        }},
        {"type": "function", "function": {
            "name": "o3de_create_level",
            "description": "Create a new level in the O3DE project.",
            "parameters": {"type": "object", "properties": {
                "name": {"type": "string"}, "size": {"type": "integer", "default": 1024},
                "use_terrain": {"type": "boolean", "default": True},
            }, "required": ["name"]},
        }},
        {"type": "function", "function": {
            "name": "o3de_create_entity",
            "description": "Create an entity with components and position.",
            "parameters": {"type": "object", "properties": {
                "name": {"type": "string"}, "components": {"type": "string"},
                "position": {"type": "string", "default": "0,0,0"},
                "parent": {"type": "string", "default": ""},
            }, "required": ["name"]},
        }},
        {"type": "function", "function": {
            "name": "o3de_add_component",
            "description": "Add a component to an existing entity.",
            "parameters": {"type": "object", "properties": {
                "entity_name": {"type": "string"}, "component_type": {"type": "string"},
            }, "required": ["entity_name", "component_type"]},
        }},
        {"type": "function", "function": {
            "name": "o3de_setup_lighting",
            "description": "Set up lighting: directional, point, spot, or area.",
            "parameters": {"type": "object", "properties": {
                "light_type": {"type": "string", "default": "directional"},
                "color": {"type": "string", "default": "255,255,230"},
                "intensity": {"type": "number", "default": 5.0},
            }, "required": []},
        }},
        {"type": "function", "function": {
            "name": "o3de_write_script",
            "description": "Write a Lua or Python script for the project.",
            "parameters": {"type": "object", "properties": {
                "name": {"type": "string"}, "content": {"type": "string"},
                "script_type": {"type": "string", "default": "lua"},
            }, "required": ["name", "content"]},
        }},
        {"type": "function", "function": {
            "name": "o3de_create_terrain",
            "description": "Create terrain with specified size and height.",
            "parameters": {"type": "object", "properties": {
                "size": {"type": "integer", "default": 1024},
                "height_scale": {"type": "number", "default": 50.0},
            }, "required": []},
        }},
        {"type": "function", "function": {
            "name": "o3de_add_physics",
            "description": "Add rigid body and collider to an entity.",
            "parameters": {"type": "object", "properties": {
                "entity_name": {"type": "string"},
                "body_type": {"type": "string", "default": "dynamic"},
                "collider_shape": {"type": "string", "default": "box"},
            }, "required": ["entity_name"]},
        }},
        {"type": "function", "function": {
            "name": "o3de_build_game",
            "description": "Build the game executable.",
            "parameters": {"type": "object", "properties": {
                "platform": {"type": "string", "default": "windows"},
                "config": {"type": "string", "default": "profile"},
            }, "required": []},
        }},
        {"type": "function", "function": {
            "name": "o3de_save_level",
            "description": "Save the current level.",
            "parameters": {"type": "object", "properties": {}, "required": []},
        }},
        {"type": "function", "function": {
            "name": "o3de_project_info",
            "description": "Get project status: entities, scripts, assets, build state.",
            "parameters": {"type": "object", "properties": {}, "required": []},
        }},
        {"type": "function", "function": {
            "name": "generate_image",
            "description": "Generate a game texture/asset image from a text prompt.",
            "parameters": {"type": "object", "properties": {
                "description": {"type": "string"}, "path": {"type": "string"},
            }, "required": ["description", "path"]},
        }},
    ]


def get_o3de_tools_spec() -> List[Dict[str, Any]]:
    """Public helper used by dataset builders for O3DE Game Agent examples."""
    return _o3de_tools()

