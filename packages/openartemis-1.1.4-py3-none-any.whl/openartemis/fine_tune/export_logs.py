"""Export Artemis agent and research runs into OpenAI fine-tune JSONL.

This script reads .replay.jsonl audit logs plus their neighboring report files
and converts them into training examples with the schema:

{"messages": [...], "parallel_tool_calls": false, "tools": [...]}

It is intentionally conservative: it only uses high-level tool metadata from
`audit_log.log_tool` and a single user goal inferred from the report header.
This is enough to teach the fine-tuned model how to structure tool calls and
final summaries, while keeping parsing logic simple and robust.

Usage (from project root):

    python -m openartemis.fine_tune.export_logs \\
        --runs-root C:\\Users\\User\\ArtemisProjects \\
        --output data/artemis_runs.jsonl
"""

from __future__ import annotations

import argparse
import json
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional

from openartemis.fine_tune.schema import (
    ARTEMIS_AGENT_SYSTEM_PROMPT,
    ARTEMIS_RESEARCH_SYSTEM_PROMPT,
    get_agent_tools_spec,
    get_research_tools_spec,
)


@dataclass
class ReplayEvent:
    """One line from a .replay.jsonl file."""

    raw: Dict[str, Any]

    @property
    def tool(self) -> Optional[str]:
        return self.raw.get("tool")

    @property
    def args(self) -> Dict[str, Any]:
        return self.raw.get("args") or {}

    @property
    def step(self) -> Optional[int]:
        return self.raw.get("step")

    @property
    def phase(self) -> str:
        return self.raw.get("phase") or ""


def _iter_replay_events(path: Path) -> Iterable[ReplayEvent]:
    with path.open("r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            try:
                obj = json.loads(line)
            except json.JSONDecodeError:
                continue
            yield ReplayEvent(raw=obj)


def _infer_goal_from_report(report_path: Path) -> str:
    """Best-effort extraction of the user goal from an Agent report."""
    try:
        text = report_path.read_text(encoding="utf-8", errors="replace")
    except OSError:
        return "Artemis agent run"
    # First line after heading often contains the original goal
    lines = [ln.strip() for ln in text.splitlines() if ln.strip()]
    if not lines:
        return "Artemis agent run"
    title = lines[0]
    if title.startswith("# Agent Report — "):
        return title.replace("# Agent Report — ", "").strip() or "Artemis agent run"
    return title


def _build_messages_from_replay(
    events: Iterable[ReplayEvent],
    mode: str,
    user_goal: str,
) -> Dict[str, Any]:
    """Convert a sequence of replay events into a fine-tune example."""
    system = ARTEMIS_AGENT_SYSTEM_PROMPT if mode == "agent" else ARTEMIS_RESEARCH_SYSTEM_PROMPT
    tools = get_agent_tools_spec() if mode == "agent" else get_research_tools_spec()

    messages: List[Dict[str, Any]] = [
        {"role": "system", "content": system},
        {"role": "user", "content": f"Goal: {user_goal}"},
    ]

    tool_call_counter = 0
    for ev in events:
        if not ev.tool:
            continue
        tool_call_counter += 1
        call_id = f"call_{tool_call_counter}"
        # Assistant proposes a tool call
        messages.append(
            {
                "role": "assistant",
                "tool_calls": [
                    {
                        "id": call_id,
                        "type": "function",
                        "function": {
                            "name": ev.tool,
                            "arguments": json.dumps(ev.args, ensure_ascii=False),
                        },
                    }
                ],
            }
        )
        # Tool returns a preview result (we only logged a preview in audit_log)
        preview = ev.raw.get("result_preview", "")
        messages.append(
            {
                "role": "tool",
                "tool_call_id": call_id,
                "content": preview,
            }
        )

    # Final assistant summary: we do not reconstruct it from the report here;
    # instead, we include a short, generic completion that encourages the
    # model to close the loop. The report text itself can be used in a
    # separate dataset if needed.
    messages.append(
        {
            "role": "assistant",
            "content": "Work complete based on the tools run above. "
            "Summarize what changed, mention any failing tests, and give the "
            "user clear next steps (e.g., which command to run to start the app).",
        }
    )

    return {
        "messages": messages,
        "parallel_tool_calls": False,
        "tools": tools,
    }


def _detect_mode_from_path(report_path: Path) -> str:
    name = report_path.name.lower()
    if "detective" in str(report_path.parent).lower() or "investigate" in name:
        return "research"
    return "agent"


def export_runs(runs_root: Path, output_path: Path) -> None:
    """Scan for .replay.jsonl files under runs_root and export JSONL."""
    lines: List[str] = []
    for replay_path in runs_root.rglob("*.replay.jsonl"):
        report_path = replay_path.with_suffix(".md")
        mode = _detect_mode_from_path(report_path)
        goal = _infer_goal_from_report(report_path)
        events = list(_iter_replay_events(replay_path))
        if not events:
            continue
        example = _build_messages_from_replay(events, mode=mode, user_goal=goal)
        lines.append(json.dumps(example, ensure_ascii=False))

    output_path.parent.mkdir(parents=True, exist_ok=True)
    with output_path.open("w", encoding="utf-8") as f:
        for line in lines:
            f.write(line + "\n")


def main(argv: Optional[List[str]] = None) -> None:
    parser = argparse.ArgumentParser(description="Export Artemis runs to fine-tune JSONL.")
    parser.add_argument(
        "--runs-root",
        type=Path,
        required=True,
        help="Root directory containing agent_output or ArtemisProjects runs.",
    )
    parser.add_argument(
        "--output",
        type=Path,
        required=True,
        help="Output JSONL file path.",
    )
    args = parser.parse_args(argv)
    export_runs(args.runs_root, args.output)


if __name__ == "__main__":
    main()

