"""Build train/val from all sources, validate, upload, and start a fine-tuning job.

Target: well-generalized model (no over/underfitting). Uses:
- Epochs: 2 (sweet spot from your val loss curve)
- Learning rate multiplier: 1.0 (was 2, which drove overfitting)
- Batch size: 2
- Same base model and file format as before.

Usage (from repo root, with OPENAI_API_KEY set):

  python -m openartemis.fine_tune.launch_job --data-dir data --base-model gpt-4.1-mini-2025-04-14
"""

from __future__ import annotations

import argparse
import hashlib
import json
import os
import random
import sys
from pathlib import Path
from typing import Any

from openartemis.config import get_openai_client


# Balanced hyperparameters: avoid overfitting (2 epochs, LR 1.0)
DEFAULT_EPOCHS = 2
DEFAULT_BATCH_SIZE = 2
DEFAULT_LR_MULTIPLIER = 1.0
DEFAULT_BASE_MODEL = "gpt-4.1-mini-2025-04-14"


def _normalize_example(obj: dict[str, Any]) -> dict[str, Any] | None:
    """Ensure example is valid for OpenAI fine-tuning: last message from assistant, no null content."""
    messages = obj.get("messages")
    if not messages or len(messages) < 2:
        return None
    # Fix any null content to ""
    for m in messages:
        if m.get("content") is None:
            m["content"] = ""
    last = messages[-1]
    if last.get("role") != "assistant":
        return None
    if last.get("tool_calls"):
        # API requires last message to be assistant with no tool_calls. Append a short summary.
        messages.append({
            "role": "assistant",
            "content": "Done. Summary of changes and how to run or test the result.",
        })
    last = messages[-1]
    if not isinstance(last.get("content"), str):
        last["content"] = last.get("content") or ""
    # Ensure parallel_tool_calls is set
    if "parallel_tool_calls" not in obj:
        obj["parallel_tool_calls"] = False
    return obj


def _example_fingerprint(obj: dict[str, Any]) -> str:
    """Stable hash to dedupe only near-duplicate full transcripts (first user + message count)."""
    first_user = ""
    for m in obj.get("messages", []):
        if m.get("role") == "user" and isinstance(m.get("content"), str):
            first_user = m["content"][:300]
            break
    n_msg = len(obj.get("messages", []))
    return hashlib.sha256((first_user + str(n_msg)).encode("utf-8")).hexdigest()


def load_and_merge(data_dir: Path, glob: str = "*.jsonl", dedupe: bool = True) -> list[dict[str, Any]]:
    """Load all JSONL files from data_dir matching glob, normalize, optionally dedupe."""
    seen: set[str] = set()
    out: list[dict[str, Any]] = []
    for path in sorted(data_dir.glob(glob)):
        if path.name in ("train_final.jsonl", "val_final.jsonl") or "final" in path.name:
            continue
        with path.open("r", encoding="utf-8") as f:
            for line in f:
                line = line.strip()
                if not line:
                    continue
                try:
                    obj = json.loads(line)
                except json.JSONDecodeError:
                    continue
                norm = _normalize_example(obj)
                if norm is None:
                    continue
                if dedupe:
                    fp = _example_fingerprint(norm)
                    if fp in seen:
                        continue
                    seen.add(fp)
                out.append(norm)
    return out


def main() -> int:
    parser = argparse.ArgumentParser(description="Build dataset, upload, start fine-tuning job.")
    parser.add_argument("--data-dir", type=Path, default=Path("data"), help="Directory containing *.jsonl")
    parser.add_argument("--base-model", type=str, default=DEFAULT_BASE_MODEL, help="Base model ID")
    parser.add_argument("--epochs", type=int, default=DEFAULT_EPOCHS)
    parser.add_argument("--batch-size", type=int, default=DEFAULT_BATCH_SIZE)
    parser.add_argument("--lr-multiplier", type=float, default=DEFAULT_LR_MULTIPLIER)
    parser.add_argument("--val-ratio", type=float, default=0.15, help="Fraction for validation (e.g. 0.15)")
    parser.add_argument("--dry-run", action="store_true", help="Only build train/val files, do not upload or create job")
    parser.add_argument("--no-dedupe", action="store_true", help="Keep all examples (no fingerprint deduplication)")
    parser.add_argument("--suffix", type=str, default="", help="Suffix for train/val filenames, e.g. _v2")
    args = parser.parse_args()

    data_dir = args.data_dir.resolve()
    if not data_dir.is_dir():
        print(f"Data directory not found: {data_dir}", file=sys.stderr)
        return 1

    examples = load_and_merge(data_dir, dedupe=not args.no_dedupe)
    if len(examples) < 10:
        print(f"Need at least 10 examples after merge; got {len(examples)}. Add more JSONL files to {data_dir}.", file=sys.stderr)
        return 1

    random.shuffle(examples)
    n_val = max(2, min(int(len(examples) * args.val_ratio), len(examples) - 8))
    n_train = len(examples) - n_val
    train_list = examples[:n_train]
    val_list = examples[n_train:]

    train_path = data_dir / f"train_final{args.suffix}.jsonl"
    val_path = data_dir / f"val_final{args.suffix}.jsonl"
    train_path.write_text("\n".join(json.dumps(ex, ensure_ascii=False) for ex in train_list), encoding="utf-8")
    val_path.write_text("\n".join(json.dumps(ex, ensure_ascii=False) for ex in val_list), encoding="utf-8")
    print(f"Wrote {len(train_list)} train -> {train_path}")
    print(f"Wrote {len(val_list)} val -> {val_path}")

    if args.dry_run:
        print("Dry run: skipping upload and job creation.")
        return 0

    api_key = os.environ.get("OPENAI_API_KEY", "").strip()
    if not api_key:
        print("OPENAI_API_KEY is not set. Set it and re-run.", file=sys.stderr)
        return 1

    client = get_openai_client()

    print("Uploading training file...")
    with train_path.open("rb") as f:
        train_file = client.files.create(file=f, purpose="fine-tune")
    print(f"  Training file ID: {train_file.id}")

    print("Uploading validation file...")
    with val_path.open("rb") as f:
        val_file = client.files.create(file=f, purpose="fine-tune")
    print(f"  Validation file ID: {val_file.id}")

    hyperparams: dict[str, Any] = {
        "n_epochs": args.epochs,
        "batch_size": args.batch_size,
        "learning_rate_multiplier": args.lr_multiplier,
    }

    print(f"Creating fine-tuning job (base={args.base_model}, epochs={args.epochs}, batch_size={args.batch_size}, lr_multiplier={args.lr_multiplier})...")
    job = client.fine_tuning.jobs.create(
        model=args.base_model,
        training_file=train_file.id,
        validation_file=val_file.id,
        hyperparameters=hyperparams,
    )
    print(f"Job created: {job.id}")
    print(f"Status: {job.status}")
    print("Monitor in the OpenAI dashboard or with: openai api fine_tuning.jobs.retrieve -i " + job.id)
    return 0


if __name__ == "__main__":
    sys.exit(main())
