"""Estimate token usage for fine-tune JSONL datasets.

This helper uses `tiktoken` (or the OpenAI tokenizer fallback) to compute
approximate token counts for a JSONL file of training examples. It is used
to keep the total training corpus within budget (e.g. ~1.5M tokens for
GPT-4.1 mini at ~$5 / 1M training tokens).
"""

from __future__ import annotations

import argparse
import json
from pathlib import Path
from typing import Any, Dict, List, Optional

try:
    import tiktoken
except ImportError:  # pragma: no cover - optional dependency
    tiktoken = None  # type: ignore[assignment]


def _encode(text: str, model: str) -> List[int]:
    if tiktoken is None:
        # Very rough fallback: split on whitespace
        return text.split()
    enc = tiktoken.encoding_for_model(model)
    return enc.encode(text)


def estimate_tokens_for_example(example: Dict[str, Any], model: str) -> int:
    """Approximate token count for a single training example."""
    total = 0
    for msg in example.get("messages", []):
        role = msg.get("role", "")
        content = msg.get("content") or ""
        total += len(_encode(role, model))
        if isinstance(content, str):
            total += len(_encode(content, model))
        # tool_calls get encoded as JSON
        tool_calls = msg.get("tool_calls") or []
        if tool_calls:
            total += len(_encode(json.dumps(tool_calls, ensure_ascii=False), model))
    # tools schema also contributes some tokens
    tools = example.get("tools") or []
    if tools:
        total += len(_encode(json.dumps(tools, ensure_ascii=False), model))
    return total


def estimate_file_tokens(path: Path, model: str) -> int:
    total = 0
    with path.open("r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            try:
                obj = json.loads(line)
            except json.JSONDecodeError:
                continue
            total += estimate_tokens_for_example(obj, model)
    return total


def main(argv: Optional[List[str]] = None) -> None:
    parser = argparse.ArgumentParser(description="Estimate token counts for fine-tune JSONL files.")
    parser.add_argument("paths", type=Path, nargs="+", help="One or more JSONL files.")
    parser.add_argument(
        "--model",
        type=str,
        default="gpt-4.1-mini",
        help="Model name for tokenizer selection (e.g. gpt-4.1-mini).",
    )
    args = parser.parse_args(argv)

    grand_total = 0
    for p in args.paths:
        n = estimate_file_tokens(p, args.model)
        grand_total += n
        print(f"{p}: ~{n} tokens")
    print(f"TOTAL: ~{grand_total} tokens")


if __name__ == "__main__":
    main()

