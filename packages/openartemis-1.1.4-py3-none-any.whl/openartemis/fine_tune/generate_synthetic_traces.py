"""Generate synthetic \"gold\" tool-use traces for Artemis fine-tuning.

This script uses a stronger base model (e.g. gpt-4.1) to create high-quality
tool-using conversations in the exact JSONL format expected by OpenAI
fine-tuning. It relies on the canonical system prompts and tool registries
from `openartemis.fine_tune.schema`.

It does NOT run automatically during normal Artemis usage; it is a one-off
data generation helper you can invoke when you want to refresh or expand
the fine-tuning dataset.
"""

from __future__ import annotations

import argparse
import json
from pathlib import Path
from typing import Any, Dict, List, Optional

from openartemis.config import get_openai_client
from openartemis.fine_tune.schema import (
    ARTEMIS_AGENT_SYSTEM_PROMPT,
    ARTEMIS_RESEARCH_SYSTEM_PROMPT,
    get_agent_tools_spec,
    get_research_tools_spec,
    get_o3de_tools_spec,
)


DEFAULT_STRONG_MODEL = "gpt-4.1"


def _build_seed_tasks() -> List[Dict[str, Any]]:
    """Return a small library of seed tasks for generation.

    You can extend this list or replace it entirely with your own tasks.
    Each dict must have:
    - mode: \"agent\" or \"research\"
    - description: natural language task description given to the generator
    """
    return [
        {
            "mode": "agent",
            "description": "Build a simple side-scrolling bird game in a single index.html with HTML, CSS, and JavaScript. Use canvas, scoring, and restart, and follow best practices: read existing files before editing, use apply_patch, and run tests or basic checks.",
        },
        {
            "mode": "agent",
            "description": "Refactor a Python CLI tool into a package with a main entrypoint, subcommands, and unit tests. Use search_in_files to find relevant modules, apply_patch for edits, and run pytest until tests pass.",
        },
        {
            "mode": "agent",
            "description": "Given an existing Node.js web app, add a high-score leaderboard backed by a JSON file. Read existing routes, use apply_patch to modify router files, and add npm scripts and tests. Run npm test to verify.",
        },
        {
            "mode": "research",
            "description": "Research the trade-offs between in-browser canvas games and native mobile games for a small indie project, then produce a sourced report with citations and a short handoff plan for implementing a canvas prototype.",
        },
        {
            "mode": "o3de",
            "description": "Build a first-person shooter using O3DE with a player entity (camera, physics, capsule collider), weapon system, 3 enemy zombies with chase AI, health pickups, terrain, and directional lighting. Write all Lua scripts for player controller, weapon, and enemy AI.",
        },
        {
            "mode": "o3de",
            "description": "Build a 3D platformer using O3DE with a player that has double-jump, 5 platforms (2 moving), collectible coins with rotation, checkpoints, and a kill zone. Write Lua scripts for platformer controller, moving platform, and collectible.",
        },
        {
            "mode": "o3de",
            "description": "Build a survival game using O3DE with a player, day-night cycle (rotating sun), harvestable trees and rocks, crafting system (campfire, shelter, axe, spear), hunger/thirst meters, and terrain. Write all Lua scripts.",
        },
        {
            "mode": "o3de",
            "description": "Build a horror game using O3DE in a dark indoor environment. Player with flashlight (battery drain), a stalker monster with patrol/chase AI, jump scare triggers, locked doors with key items, and dim point lighting. Write all Lua scripts.",
        },
        {
            "mode": "o3de",
            "description": "Build an RPG using O3DE with a third-person player, follow camera, NPC merchant with dialogue, quest giver NPC, loot chests, inventory system, XP/leveling stats system, and terrain with vegetation. Write all Lua scripts.",
        },
    ]


def _system_and_tools_for_mode(mode: str) -> tuple[str, List[Dict[str, Any]]]:
    if mode == "research":
        return ARTEMIS_RESEARCH_SYSTEM_PROMPT, get_research_tools_spec()
    if mode == "o3de":
        o3de_system = (
            "You are the O3DE Game Agent for OpenArtemis. You build AAA 3D games using "
            "Open 3D Engine tools. Create entities, set up lighting, write Lua scripts, "
            "generate textures, and build the game. Follow the entity-component model: "
            "every game object is an Entity with Components (Transform, Mesh, PhysX, Lua Script, etc). "
            "Always: create level → setup lighting → create entities → write scripts → save → build."
        )
        return o3de_system, get_o3de_tools_spec()
    return ARTEMIS_AGENT_SYSTEM_PROMPT, get_agent_tools_spec()


def generate_trace_for_task(
    client: Any,  # OpenAI client from get_openai_client()
    task: Dict[str, Any],
    model: str = DEFAULT_STRONG_MODEL,
    max_turns: int = 16,
) -> Dict[str, Any]:
    """Ask a strong model to simulate a full tool-using trace for one task."""
    mode = task.get("mode", "agent")
    system, tools = _system_and_tools_for_mode(mode)
    user_desc = task.get("description", "")

    messages: List[Dict[str, Any]] = [
        {"role": "system", "content": system},
        {
            "role": "user",
            "content": (
                "You are generating a training example for an Artemis coding agent.\n"
                "Follow the system instructions exactly and use tools step by step.\n"
                "User goal:\n"
                f"{user_desc}"
            ),
        },
    ]

    # We want the final message in every example to be an assistant message
    # (no tool_calls), because the fine-tuning API expects that shape.
    for _ in range(max_turns):
        resp = client.chat.completions.create(
            model=model,
            messages=messages,
            tools=tools,
            tool_choice="auto",
        )
        msg = resp.choices[0].message
        messages.append(
            {
                "role": msg.role,
                "content": msg.content or "",
                "tool_calls": [
                    {
                        "id": t.id,
                        "type": "function",
                        "function": {
                            "name": t.function.name,
                            "arguments": t.function.arguments or "{}",
                        },
                    }
                    for t in (msg.tool_calls or [])
                ],
            }
        )
        if not msg.tool_calls:
            # Natural language final answer – stop here
            break

        # For fine-tuning we do not need to actually execute the tools; instead
        # we provide short synthetic tool results so the model learns the
        # structure of tool ↔ tool_result ↔ follow-up.
        for tc in msg.tool_calls or []:
            synthetic_content = (
                f"(synthetic result for {tc.function.name}; in real runs Artemis "
                "would execute this tool and include the real output here.)"
            )
            messages.append(
                {
                    "role": "tool",
                    "tool_call_id": tc.id,
                    "content": synthetic_content,
                }
            )

    # Ensure the last message is a plain assistant turn with natural language
    # content (no tool_calls), as required by fine-tuning.
    if not messages or messages[-1]["role"] != "assistant" or messages[-1].get("tool_calls"):
        messages.append(
            {
                "role": "assistant",
                "content": (
                    "Summary: describe what you built or fixed, which tools you used, "
                    "and how the user can run tests or start the app. Mention any "
                    "follow-up improvements you would suggest."
                ),
            }
        )

    return {
        "messages": messages,
        "parallel_tool_calls": False,
        "tools": tools,
    }


def generate_synthetic_dataset(
    output_path: Path,
    model: str = DEFAULT_STRONG_MODEL,
    tasks: Optional[List[Dict[str, Any]]] = None,
) -> None:
    client = get_openai_client()
    tasks = tasks or _build_seed_tasks()
    output_path.parent.mkdir(parents=True, exist_ok=True)

    with output_path.open("w", encoding="utf-8") as f:
        for task in tasks:
            example = generate_trace_for_task(client, task, model=model)
            f.write(json.dumps(example, ensure_ascii=False) + "\n")


def main(argv: Optional[List[str]] = None) -> None:
    parser = argparse.ArgumentParser(description="Generate synthetic Artemis tool-use traces.")
    parser.add_argument("--output", type=Path, required=True, help="Output JSONL file path.")
    parser.add_argument(
        "--model",
        type=str,
        default=DEFAULT_STRONG_MODEL,
        help="Base model to use for generation (e.g. gpt-4.1).",
    )
    args = parser.parse_args(argv)
    generate_synthetic_dataset(args.output, model=args.model)


if __name__ == "__main__":
    main()

