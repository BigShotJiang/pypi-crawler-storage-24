"""Retry helper: max attempts, backoff, optional variation for agent/pipeline LLM and tool calls."""

import random
import re
import time
from typing import Callable, TypeVar

from openartemis.errors import ErrorType, classify_exception, is_retriable
from openartemis.token_budget import set_retry_after as token_budget_set_retry_after

T = TypeVar("T")

# Match "try again in 300ms", "try again in 2.386s", "Please try again in 19.934s" from 429 responses
_RETRY_AFTER_RE = re.compile(r"try again in (\d+(?:\.\d+)?)\s*(ms|s)", re.IGNORECASE)


def get_retry_after_seconds(exc: BaseException) -> float | None:
    """If the exception message contains 'try again in Xms' or 'X.Ys', return that duration in seconds. Otherwise None."""
    m = _RETRY_AFTER_RE.search(str(exc))
    if m:
        value = float(m.group(1))
        unit = (m.group(2) or "s").lower()
        if unit == "ms":
            delay = value / 1000.0
        else:
            delay = value
        return max(0.3, delay)
    return None


def retry_with_backoff(
    fn: Callable[[], T],
    max_attempts: int = 3,
    backoff_base: float = 1.0,
    backoff_max: float = 60.0,
    on_retry: Callable[[int, Exception], None] | None = None,
) -> T:
    """
    Call fn(); on exception, classify and retry if retriable (RateLimit, Transient).
    For 429, honors "try again in Xms" from the error message when present; otherwise
    uses exponential backoff: backoff_base * 2 ** attempt, capped at backoff_max.
    Raises the last exception if all attempts fail.
    """
    last: BaseException | None = None
    for attempt in range(max_attempts):
        try:
            return fn()
        except BaseException as e:
            last = e
            et = classify_exception(e)
            if not is_retriable(et) or attempt == max_attempts - 1:
                raise
            delay = get_retry_after_seconds(e)
            if delay is None:
                delay = min(backoff_base * (2**attempt), backoff_max)
                # Jitter: 0.5–1.0x so retries spread
                delay = delay * (0.5 + 0.5 * random.random())
            else:
                # So token_budget scheduler can wait before next dispatch
                token_budget_set_retry_after(delay)
            if on_retry:
                on_retry(attempt + 1, e)
            time.sleep(delay)
    if last:
        raise last
    raise RuntimeError("retry_with_backoff: no result")
