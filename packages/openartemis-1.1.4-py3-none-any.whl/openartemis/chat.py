"""Chat session — AI with research tools, used when user asks."""

import json
import os
from pathlib import Path
from typing import Any, Callable

from openartemis.config import load_config, resolve_artemis_model, get_max_tokens, get_max_credits, completion_tokens_kwarg, get_anthropic_client
from openartemis.context_window import ContextWindow

load_config()

from openartemis.agent import TOOLS, DetectiveAgent

CHAT_SYSTEM = """You are Artemis, a helpful AI assistant in a CLI chat. You can have normal conversations.

You also have research tools: harvest_transcripts, list_transcripts, read_transcript, brave_search, fetch_webpage, browse_webpage.
For deeper research, the user can use /research to run the multi-agent pipeline.
Use them ONLY when the user explicitly asks you to research, find, harvest, or look something up.
Examples: "research Mr Beast's latest video", "find out about X", "harvest transcripts about Y"

For normal chat, just respond. For research requests, use the tools and summarize what you find."""


class ChatSession:
    """Persistent chat with AI that can use research tools."""

    def __init__(
        self,
        on_tool_call: Callable[[str, dict], None] | None = None,
        user_id: int | None = None,
        is_admin: bool = False,
        session_id: int | None = None,
    ):
        self.client = get_anthropic_client()
        self.agent = DetectiveAgent(out_dir=Path("./detective_output"))
        self.model_display = "Artemis-0.5"
        self.model = resolve_artemis_model(self.model_display)
        model_reveal = f"If the user asks what base or API model you use, you may tell them: this session uses the model {self.model}."
        system_content = CHAT_SYSTEM + "\n\n" + model_reveal
        self._system_content = system_content
        self.messages: list[dict[str, Any]] = [{"role": "system", "content": system_content}]
        self.context_window = ContextWindow(max_tokens=200_000, role="chat")
        self.on_tool_call = on_tool_call
        self.credits_used = 0
        self.user_id = user_id
        self.is_admin = is_admin
        self.session_id = session_id
        self._last_persisted = 1

    def persist(self) -> None:
        """Append new messages to DB and sync to local file."""
        if not self.session_id or not self.user_id:
            return
        from openartemis.auth.db import append_chat_message, DATA_DIR

        for i in range(self._last_persisted, len(self.messages)):
            m = self.messages[i]
            role = m.get("role", "")
            content = m.get("content", "") or ""
            tc = m.get("tool_calls")
            append_chat_message(self.session_id, role, content, tc)
        self._last_persisted = len(self.messages)

        local_dir = DATA_DIR / "chat_history"
        local_dir.mkdir(parents=True, exist_ok=True)
        local_path = local_dir / f"{self.session_id}.json"
        with open(local_path, "w", encoding="utf-8") as f:
            json.dump(
                [{"role": m["role"], "content": m.get("content", ""), "tool_calls": m.get("tool_calls")} for m in self.messages if m["role"] != "system"],
                f,
                indent=2,
                ensure_ascii=False,
            )

    def send(
        self,
        user_text: str,
        stream_callback: Callable[[str], None] | None = None,
    ) -> str:
        """Send user message, get AI response (may use tools). Returns final text.
        If stream_callback is set, call it with each content chunk for streaming display.
        Raises ValueError if OPENARTEMIS_MAX_CREDITS is set and session would exceed it."""
        max_credits = get_max_credits()
        if max_credits is not None and self.credits_used >= max_credits and not self.is_admin:
            raise ValueError(
                f"Session credits cap reached ({self.credits_used}/{max_credits}). "
                "Set OPENARTEMIS_MAX_CREDITS higher or start a new chat."
            )
        self.messages.append({"role": "user", "content": user_text})

        def _messages_for_api() -> list[dict[str, Any]]:
            """Use context window for smart compression instead of hard truncation."""
            # Sync non-system messages to context window
            non_system = [m for m in self.messages if m.get("role") != "system"]
            self.context_window.messages = non_system
            return self.context_window.get_messages_for_api(self._system_content)

        max_tokens = get_max_tokens()
        
        for _ in range(15):
            messages = _messages_for_api()
            
            # Convert messages to Anthropic format
            anthropic_messages = []
            system_message = None
            
            for msg in messages:
                if msg.get("role") == "system":
                    system_message = msg.get("content")
                else:
                    anthropic_messages.append({
                        "role": msg.get("role"),
                        "content": msg.get("content")
                    })
            
            # Check if we have tool results to include
            for msg in messages:
                if msg.get("role") == "tool":
                    # Add tool result as user message
                    anthropic_messages.append({
                        "role": "user",
                        "content": f"Tool result: {msg.get('content')}"
                    })
            
            # Prepare the API call
            create_kw = {
                "model": self.model,
                "messages": anthropic_messages,
                "max_tokens": max_tokens or 4096,
                "stream": True,
            }
            
            if system_message:
                create_kw["system"] = system_message
            
            try:
                # Use Anthropic's streaming API
                with self.client.messages.stream(**create_kw) as stream:
                    content_parts = []
                    tool_use_blocks = []
                    current_tool = None
                    
                    for text in stream.text_stream:
                        if text:
                            content_parts.append(text)
                            if stream_callback:
                                stream_callback(text)
                    
                    # Get the final message
                    message = stream.get_final_message()
                    
                    # Extract content and tool calls
                    content = ""
                    for block in message.content:
                        if block.type == "text":
                            content += block.text
                        elif block.type == "tool_use":
                            tool_use_blocks.append({
                                "id": block.id,
                                "name": block.name,
                                "input": block.input
                            })
                    
                    # Add assistant message
                    msg_dict = {
                        "role": "assistant",
                        "content": content,
                        "tool_calls": None
                    }
                    
                    if tool_use_blocks:
                        # Convert to OpenAI-style tool calls for compatibility
                        msg_dict["tool_calls"] = [
                            {
                                "id": tool["id"],
                                "type": "function",
                                "function": {
                                    "name": tool["name"],
                                    "arguments": json.dumps(tool["input"])
                                }
                            }
                            for tool in tool_use_blocks
                        ]
                    
                    self.messages.append(msg_dict)
                    
                    if not tool_use_blocks:
                        return content.strip()
                    
                    # Execute tools
                    for tool in tool_use_blocks:
                        name = tool["name"]
                        args = tool["input"]
                        
                        if self.on_tool_call:
                            self.on_tool_call(name, args)
                        result = self.agent._execute_tool(name, args)
                        
                        if name == "harvest_transcripts" and not self.is_admin:
                            try:
                                r = json.loads(result)
                                credits = 1 + r.get("harvested_count", 0)
                                self.credits_used += credits
                                if self.user_id:
                                    from openartemis.auth.db import log_usage
                                    log_usage(self.user_id, credits, "harvest")
                            except (json.JSONDecodeError, TypeError):
                                self.credits_used += 1
                                if self.user_id:
                                    from openartemis.auth.db import log_usage
                                    log_usage(self.user_id, 1, "harvest")
                        
                        self.messages.append({
                            "role": "user",
                            "content": f"Tool {name} returned: {result}"
                        })
                
            except Exception as e:
                # Fallback to non-streaming if streaming fails
                try:
                    create_kw_no_stream = create_kw.copy()
                    create_kw_no_stream["stream"] = False
                    
                    response = self.client.messages.create(**create_kw_no_stream)
                    
                    content = ""
                    tool_use_blocks = []
                    
                    for block in response.content:
                        if block.type == "text":
                            content += block.text
                        elif block.type == "tool_use":
                            tool_use_blocks.append({
                                "id": block.id,
                                "name": block.name,
                                "input": block.input
                            })
                    
                    if stream_callback:
                        stream_callback(content)
                    
                    msg_dict = {
                        "role": "assistant",
                        "content": content,
                        "tool_calls": None
                    }
                    
                    if tool_use_blocks:
                        msg_dict["tool_calls"] = [
                            {
                                "id": tool["id"],
                                "type": "function",
                                "function": {
                                    "name": tool["name"],
                                    "arguments": json.dumps(tool["input"])
                                }
                            }
                            for tool in tool_use_blocks
                        ]
                    
                    self.messages.append(msg_dict)
                    
                    if not tool_use_blocks:
                        return content.strip()
                    
                    # Execute tools (same as above)
                    for tool in tool_use_blocks:
                        name = tool["name"]
                        args = tool["input"]
                        
                        if self.on_tool_call:
                            self.on_tool_call(name, args)
                        result = self.agent._execute_tool(name, args)
                        
                        if name == "harvest_transcripts" and not self.is_admin:
                            try:
                                r = json.loads(result)
                                credits = 1 + r.get("harvested_count", 0)
                                self.credits_used += credits
                                if self.user_id:
                                    from openartemis.auth.db import log_usage
                                    log_usage(self.user_id, credits, "harvest")
                            except (json.JSONDecodeError, TypeError):
                                self.credits_used += 1
                                if self.user_id:
                                    from openartemis.auth.db import log_usage
                                    log_usage(self.user_id, 1, "harvest")
                        
                        self.messages.append({
                            "role": "user",
                            "content": f"Tool {name} returned: {result}"
                        })
                
                except Exception as e2:
                    return f"Error: {str(e2)}"

        return "Max turns reached."
