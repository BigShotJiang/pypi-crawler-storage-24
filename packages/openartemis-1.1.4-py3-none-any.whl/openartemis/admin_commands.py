"""Admin commands for managing Artemis CLI (no-server edition)."""

import json
from datetime import date, timedelta
from pathlib import Path

from rich.console import Console
from rich.panel import Panel
from rich.table import Table

from openartemis.auth import init_db, get_session_user
from openartemis.auth.db import (
    cleanup_expired_codes,
    get_user_count,
    list_users,
)

console = Console()

# Where the developer stores the master codes file
_MASTER_FILE = Path(__file__).resolve().parents[1] / "codes_master.json"


def _require_admin():
    init_db()
    user = get_session_user()
    if not user or user.get("role") != "admin":
        console.print("[red]Admin access required.[/red]")
        return None
    return user


def show_todays_codes(days_ahead: int = 0) -> None:
    """Print today's (or a future day's) 15 invite codes from codes_master.json."""
    if not _MASTER_FILE.exists():
        console.print(f"[red]codes_master.json not found at {_MASTER_FILE}[/red]")
        console.print("[dim]Run: python scripts/generate_master_codes.py[/dim]")
        return
    master = json.loads(_MASTER_FILE.read_text(encoding="utf-8"))
    start = date.fromisoformat(master["start_date"])
    target = date.today() + timedelta(days=days_ahead)
    idx = (target - start).days
    days = master["days"]
    if idx < 0 or idx >= len(days):
        console.print(f"[yellow]No codes for {target} (out of range).[/yellow]")
        return
    console.print(Panel(
        "\n".join(f"  {i:2d}.  {c}" for i, c in enumerate(days[idx]["codes"], 1)),
        title=f"[bold cyan]Invite codes for {target}[/bold cyan]",
        border_style="cyan",
    ))
    console.print(f"[dim]Valid for {365 - idx} more days · single-use each[/dim]")


def stats_command() -> None:
    """Show user + code stats."""
    _require_admin()
    user_count = get_user_count()
    users = list_users()
    # Count used codes from DB
    from openartemis.auth.db import _get_conn
    conn = _get_conn()
    used = conn.execute("SELECT COUNT(*) FROM used_codes").fetchone()[0]
    conn.close()
    # How many pre-generated codes exist total
    total_pregenerated = 0
    if _MASTER_FILE.exists():
        m = json.loads(_MASTER_FILE.read_text())
        total_pregenerated = sum(len(d["codes"]) for d in m["days"])
    console.print(Panel(
        f"[bold]Users[/bold]  total={user_count}  "
        f"admins={sum(1 for u in users if u.get('role')=='admin')}  "
        f"approved={sum(1 for u in users if u.get('approved'))}\n\n"
        f"[bold]Pre-generated codes[/bold]  total={total_pregenerated}  used={used}  "
        f"remaining={total_pregenerated - used}",
        title="Stats", border_style="cyan",
    ))


def cleanup_command() -> None:
    """Remove expired legacy DB-created codes."""
    _require_admin()
    removed = cleanup_expired_codes()
    console.print(f"[green]✓ Removed {removed} expired legacy codes[/green]")
