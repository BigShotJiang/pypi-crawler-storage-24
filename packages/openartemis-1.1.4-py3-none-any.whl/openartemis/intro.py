"""Artemis CLI startup animation — raven fly-in with trailing ARTEMIS text.

Pure ANSI terminal animation. No external dependencies (stdlib only).
Call play_intro() once on boot before the main CLI loads.
"""

import os
import shutil
import sys
import time

# ── ANSI escape helpers ──────────────────────────────────────────────────────

_ESC = "\033"
_HIDE_CURSOR = f"{_ESC}[?25l"
_SHOW_CURSOR = f"{_ESC}[?25h"
_CLEAR_SCREEN = f"{_ESC}[2J{_ESC}[H"
_DIM = f"{_ESC}[2m"
_BOLD = f"{_ESC}[1m"
_RESET = f"{_ESC}[0m"
_CYAN = f"{_ESC}[36m"
_BOLD_CYAN = f"{_ESC}[1;36m"


def _goto(row: int, col: int) -> str:
    """ANSI escape to move cursor to (row, col) — 1-indexed."""
    return f"{_ESC}[{row};{col}H"


def _write(s: str) -> None:
    """Write string to stdout and flush immediately. Use __stdout__ to bypass Rich wrapping."""
    out = sys.__stdout__ or sys.stdout
    out.write(s)
    out.flush()


# ── Raven sprite frames (3-frame wing flap) ─────────────────────────────────
# Each frame is a list of strings (rows). All frames must have the same height.

_RAVEN_FRAMES = [
    # Frame 0 — wings up
    [
        r"  /\  /\ ",
        r"  / \/ \ ",
        r" / /vv\ \\",
        r"  / >> \  ",
        r"   \__/  ",
    ],
    # Frame 1 — wings mid
    [
        r"         ",
        r"  --  -- ",
        r" / /vv\ \\",
        r"  / >> \  ",
        r"   \__/  ",
    ],
    # Frame 2 — wings down
    [
        r"         ",
        r"  \/  \/ ",
        r" / /vv\ \\",
        r"  / >> \  ",
        r"   \__/  ",
    ],
]

_RAVEN_HEIGHT = len(_RAVEN_FRAMES[0])
_RAVEN_WIDTH = max(len(line) for frame in _RAVEN_FRAMES for line in frame)

# ── Block-art raven logo (from ArtemisLogo.png) ─────────────────────────────
# Angular raven face: swept wings, eye cutouts, V-beak

_BLOCK_LOGO = [
    r"           ▄█▀▀▀▀▄       ▄▀▀▀▀█▄           ",
    r"         ▄██▀     ▀▄   ▄▀     ▀██▄         ",
    r"       ▄██▀   ▄▄▄  ▀▄▄▀  ▄▄▄   ▀██▄       ",
    r"     ▄██▀    █▀  ▀▄    ▄▀  ▀█    ▀██▄     ",
    r"    ███      ▀▄   █    █   ▄▀      ███    ",
    r"    ███        ▀▄▄▀▄  ▄▀▄▄▀        ███    ",
    r"     ▀██▄        ▀██▄▄██▀        ▄██▀     ",
    r"       ▀██▄        ▀██▀        ▄██▀       ",
    r"         ▀██▄       ▀▀       ▄██▀         ",
    r"           ▀██▄    ▄██▄    ▄██▀           ",
    r"             ▀██▄▄██▀▀██▄▄██▀             ",
    r"               ▀███▀  ▀███▀               ",
    r"                 ▀▀    ▀▀                 ",
]

# ── Letters to trail ─────────────────────────────────────────────────────────

_LETTERS = list("ARTEMIS")
_LETTER_SPACING = 3  # columns between each letter


def play_intro() -> None:
    """Play the raven fly-in animation. Safe to call from any context."""
    # Guard: skip if not a real terminal
    # On Windows, sys.stdout may be wrapped (Rich/typer) so check stdin too
    if not sys.stdout.isatty() and not sys.stdin.isatty():
        return
    cols, rows = shutil.get_terminal_size((80, 24))
    if cols < 40 or rows < 20:
        return
    # On Windows, enable ANSI escape processing
    if sys.platform == "win32":
        try:
            import ctypes
            kernel32 = ctypes.windll.kernel32
            # STD_OUTPUT_HANDLE = -11
            handle = kernel32.GetStdHandle(-11)
            # ENABLE_VIRTUAL_TERMINAL_PROCESSING = 0x0004
            mode = ctypes.c_ulong()
            kernel32.GetConsoleMode(handle, ctypes.byref(mode))
            kernel32.SetConsoleMode(handle, mode.value | 0x0004)
        except Exception:
            pass

    try:
        _write(_HIDE_CURSOR)
        _write(_CLEAR_SCREEN)
        _run_animation(cols, rows)
    finally:
        _write(_SHOW_CURSOR)
        _write(_CLEAR_SCREEN)


def _run_animation(cols: int, rows: int) -> None:
    """Core animation loop."""
    # ── Geometry ──
    text_total_width = len(_LETTERS) * _LETTER_SPACING - (_LETTER_SPACING - 1)
    text_start_col = max(1, (cols - text_total_width) // 2)
    raven_row = rows // 2 - _RAVEN_HEIGHT // 2  # vertical center
    text_row = raven_row + _RAVEN_HEIGHT // 2     # text on the middle row of the raven

    # How far the raven travels: from col 1 to past the text, then off-screen
    raven_start = 1
    # The raven should be past the last letter when all letters are placed
    raven_end_text = text_start_col + text_total_width + _RAVEN_WIDTH + 2
    raven_exit = cols + _RAVEN_WIDTH + 2  # off-screen right

    # ── Phase 1+2: Raven flies in, letters trail behind ──
    frame_idx = 0
    letters_placed = 0
    frames_since_letter = 0
    letter_interval = 3  # place a letter every N movement frames

    col = raven_start
    step = 2  # columns per frame

    while col < raven_end_text:
        # Erase previous raven position
        _erase_raven(raven_row, max(1, col - step), cols)
        # Draw raven at current position
        _draw_raven(raven_row, col, frame_idx % 3, cols)
        # Place a letter if it's time
        frames_since_letter += 1
        if letters_placed < len(_LETTERS) and frames_since_letter >= letter_interval:
            letter_col = text_start_col + letters_placed * _LETTER_SPACING
            _write(_goto(text_row, letter_col))
            _write(f"{_BOLD_CYAN}{_LETTERS[letters_placed]}{_RESET}")
            letters_placed += 1
            frames_since_letter = 0

        frame_idx += 1
        col += step
        time.sleep(0.05)

    # Place any remaining letters
    while letters_placed < len(_LETTERS):
        letter_col = text_start_col + letters_placed * _LETTER_SPACING
        _write(_goto(text_row, letter_col))
        _write(f"{_BOLD_CYAN}{_LETTERS[letters_placed]}{_RESET}")
        letters_placed += 1
        time.sleep(0.08)

    # ── Phase 3: Raven exits right ──
    while col < raven_exit:
        _erase_raven(raven_row, max(1, col - step), cols)
        _draw_raven(raven_row, col, frame_idx % 3, cols)
        frame_idx += 1
        col += step + 1  # accelerate slightly
        time.sleep(0.035)

    # Final erase of raven
    _erase_raven(raven_row, max(1, col - step - 1), cols)

    # ── Phase 4: Dim fade ──
    # Redraw text in dim
    for i, letter in enumerate(_LETTERS):
        letter_col = text_start_col + i * _LETTER_SPACING
        _write(_goto(text_row, letter_col))
        _write(f"{_DIM}{_CYAN}{letter}{_RESET}")
    time.sleep(0.4)

    # Restore to bold cyan
    for i, letter in enumerate(_LETTERS):
        letter_col = text_start_col + i * _LETTER_SPACING
        _write(_goto(text_row, letter_col))
        _write(f"{_BOLD_CYAN}{letter}{_RESET}")
    time.sleep(0.15)

    # ── Phase 5: Block-art raven logo ──
    logo_start_row = text_row + 2
    logo_width = max(len(line) for line in _BLOCK_LOGO)

    for idx, line in enumerate(_BLOCK_LOGO):
        r = logo_start_row + idx
        if r >= rows:
            break
        c = max(1, (cols - logo_width) // 2)
        _write(_goto(r, c))
        _write(f"{_CYAN}{line}{_RESET}")
        time.sleep(0.04)

    # ── Phase 6: Hold then clear ──
    time.sleep(1.5)
    # Clear happens in the finally block of play_intro()


def _draw_raven(top_row: int, left_col: int, frame: int, term_cols: int) -> None:
    """Draw a raven sprite at the given position, clipping to terminal width."""
    sprite = _RAVEN_FRAMES[frame]
    for i, line in enumerate(sprite):
        r = top_row + i
        # Clip: only draw the portion that fits on screen
        if left_col > term_cols:
            continue
        visible_start = max(0, 1 - left_col)
        visible_end = min(len(line), term_cols - left_col + 1)
        if visible_start >= visible_end:
            continue
        draw_col = max(1, left_col)
        _write(_goto(r, draw_col))
        _write(f"{_BOLD_CYAN}{line[visible_start:visible_end]}{_RESET}")


def _erase_raven(top_row: int, left_col: int, term_cols: int) -> None:
    """Erase a raven-sized rectangle at the given position."""
    blank = " " * (_RAVEN_WIDTH + 4)
    for i in range(_RAVEN_HEIGHT):
        r = top_row + i
        draw_col = max(1, left_col)
        _write(_goto(r, draw_col))
        end = min(len(blank), term_cols - draw_col + 1)
        if end > 0:
            _write(blank[:end])
