"""Orchestrator — creates a structured plan from user request (single LLM call, no tools)."""

import json
import os
from pathlib import Path

from dotenv import load_dotenv
from openartemis.config import get_anthropic_client as _get_anthropic_client

load_dotenv(Path(__file__).resolve().parents[2] / ".env")

from openartemis.config import DEFAULT_BASE_MODEL, get_max_tokens_or_default
from openartemis.token_budget import create_with_budget

CLARIFICATION_PROMPT = """You are a project clarification assistant. Given a user request to build something, generate 3-4 multiple choice questions to better understand their requirements.

Each question should have 4 options (A, B, C, D) and an option E for custom input.

Output format:
{"questions": [
  {
    "question": "What platform would you like it on?",
    "options": ["Web", "Desktop app", "Mobile app", "Console game"],
    "id": "platform"
  },
  ...
]}

Rules:
- Focus on critical technical decisions that affect the implementation
- Keep questions simple and clear
- Options should cover the most common choices
- Include option E implicitly for custom answers (handled by UI)
- Generate 3-4 questions maximum"""

PLAN_PROMPT = """You are a research planner. Given a user request, break it into 5-8 sub-questions that together fully answer the request. Each sub-question will be researched in parallel (gather phase).

First sub-question MUST be: "What is the single best stack (e.g. Pygame, Unity, Vanilla JS) for this request?" so we commit to one stack before details.

Output a JSON object with this exact structure:
{"tasks": [
  {"id": 1, "description": "Sub-question to answer (one clear question)", "hint": "tool_name", "url": "optional url if applicable"},
  ...
]}

Available tools/hints:
- brave_search — web search (use for recent news, general web info)
- harvest_transcripts — YouTube, TikTok, Instagram, X transcripts
- fetch_webpage — fast text extraction from a URL (static HTML)
- browse_webpage — full render with headless browser (JS-heavy sites)
- list_transcripts — list harvested files (use out_dir from harvest)
- read_transcript — read a transcript file

Rules:
- Break the user request into 5-8 sub-questions. Each task is one sub-question.
- Each task should be independent and parallelizable (different angles/sources).
- Include "url" in task only when the task targets a specific URL (fetch_webpage, browse_webpage).
- For harvest_transcripts, include the search query in description.
- For brave_search, include the search query in description.
- Output ONLY valid JSON, no markdown or extra text."""


def create_plan(user_request: str, model: str | None = None) -> list[dict]:
    """Create a plan of up to 5 tasks from user request. Returns list of task dicts."""
    client = _get_anthropic_client()
    model = model or DEFAULT_BASE_MODEL
    plan_messages = [
        {"role": "system", "content": PLAN_PROMPT},
        {"role": "user", "content": user_request},
    ]
    resp = create_with_budget(
        client,
        model,
        plan_messages,
        max_tokens=get_max_tokens_or_default(),
    )
    content = (resp.choices[0].message.content or "").strip()
    from openartemis.agent.agent_orchestrator import _extract_json_object
    data = _extract_json_object(content)
    if data is not None:
        tasks = data.get("tasks", [])
        return tasks[:8]
    return []


def generate_clarification_questions(user_request: str, model: str | None = None) -> list[dict]:
    """Generate 3-4 multiple choice questions to clarify user requirements."""
    client = _get_anthropic_client()
    model = model or DEFAULT_BASE_MODEL
    messages = [
        {"role": "system", "content": CLARIFICATION_PROMPT},
        {"role": "user", "content": user_request},
    ]
    resp = create_with_budget(
        client,
        model,
        messages,
        max_tokens=get_max_tokens_or_default(),
    )
    content = (resp.choices[0].message.content or "").strip()
    from openartemis.agent.agent_orchestrator import _extract_json_object
    data = _extract_json_object(content)
    if data is not None:
        return data.get("questions", [])
    return []
