"""Agent workspace tools — read_file, write_file, list_dir, run_terminal, take_screenshot. Sandboxed to workspace.
Artifact convention: main entrypoint at workspace root (e.g. index.html for web, main.py for Python).
Plugins: add .py files in ~/.openartemis/tools/ that define TOOL_SCHEMA (OpenAI function schema) and run(args) -> str."""

import base64
import importlib.util
import os
import re
import subprocess
import threading
from pathlib import Path
from typing import Any, Optional

DIAGNOSTICS_MAX_CHARS = 1500

from openartemis.auth.db import DATA_DIR

try:
    from openartemis.tools.code_interpreter import run_code_interpreter as _run_code_interpreter
except ImportError:
    _run_code_interpreter = None

TOOLS_DIR = Path.home() / ".openartemis" / "tools"
PLUGIN_TOOLS: list[dict[str, Any]] = []
PLUGIN_HANDLERS: dict[str, Any] = {}

_DEFAULT_WORKSPACE = DATA_DIR / "agent_workspace"
_current_workspace: Optional[Path] = None
_terminal_log_path: Optional[Path] = None
_agent_container_id: Optional[str] = None

# Session undo: (path_relative_to_workspace, content_before_edit). Max depth 10.
_undo_stack: list[tuple[str, str]] = []
_UNDO_MAX_DEPTH = 10

# Public alias for code that imports AGENT_WORKSPACE; prefer get_agent_workspace()
AGENT_WORKSPACE = _DEFAULT_WORKSPACE


def get_agent_workspace() -> Path:
    """Return current workspace (user override or default)."""
    return _current_workspace if _current_workspace is not None else _DEFAULT_WORKSPACE


def set_agent_workspace(path: Optional[Path]) -> None:
    """Set workspace override for this run. Pass None to clear."""
    global _current_workspace
    _current_workspace = path


def set_terminal_log_path(path: Optional[Path]) -> None:
    """When set, run_terminal streams output to this file (for dashboard terminal-stream cue)."""
    global _terminal_log_path
    _terminal_log_path = path


def get_terminal_log_path() -> Optional[Path]:
    """Return current terminal log path if set."""
    return _terminal_log_path


def set_agent_container_id(container_id: Optional[str]) -> None:
    """When set (Docker sandbox), run_terminal executes inside this container."""
    global _agent_container_id
    _agent_container_id = container_id


def get_agent_container_id() -> Optional[str]:
    """Return current sandbox container id if set."""
    return _agent_container_id


def _resolve(path: str) -> Path:
    """Resolve path within workspace. Raises ValueError if outside."""
    base = get_agent_workspace().resolve()
    resolved = (base / path).resolve()
    if not str(resolved).startswith(str(base)):
        raise ValueError("Path must be inside workspace")
    return resolved


def read_file(path: str) -> str:
    """Read file contents. Path is relative to workspace."""
    try:
        p = _resolve(path)
        return p.read_text(encoding="utf-8", errors="replace")
    except FileNotFoundError:
        return f"Error: File not found: {path}"
    except ValueError as e:
        return f"Error: {e}"
    except Exception as e:
        return f"Error: {e}"


def _push_edit_checkpoint(path: str, content: str) -> None:
    """Push (path, content) onto undo stack; cap depth."""
    global _undo_stack
    _undo_stack.append((path, content))
    if len(_undo_stack) > _UNDO_MAX_DEPTH:
        _undo_stack.pop(0)


def restore_last_checkpoint() -> bool:
    """Restore the last file edit (pop stack and write back). Returns True if restored."""
    global _undo_stack
    if not _undo_stack:
        return False
    path_rel, content = _undo_stack.pop()
    try:
        p = _resolve(path_rel)
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_text(content, encoding="utf-8")
        return True
    except Exception:
        return False


def clear_undo_stack() -> None:
    """Clear the session undo stack (e.g. at start of agent run)."""
    global _undo_stack
    _undo_stack.clear()


def write_file(path: str, content: str) -> str:
    """Write content to file. Path is relative to workspace. Creates parent dirs."""
    try:
        p = _resolve(path)
        if p.exists():
            _push_edit_checkpoint(path, p.read_text(encoding="utf-8", errors="replace"))
        else:
            _push_edit_checkpoint(path, "")
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_text(content, encoding="utf-8")
        return f"Wrote {path}"
    except ValueError as e:
        return f"Error: {e}"
    except Exception as e:
        return f"Error: {e}"


def list_dir(path: str = ".") -> str:
    """List files and dirs. Path is relative to workspace."""
    get_agent_workspace().mkdir(parents=True, exist_ok=True)
    try:
        p = _resolve(path)
        if not p.is_dir():
            return f"Error: Not a directory: {path}"
        items = []
        for x in sorted(p.iterdir()):
            kind = "dir" if x.is_dir() else "file"
            items.append(f"  {kind}: {x.name}")
        return "\n".join(items) if items else "(empty)"
    except ValueError as e:
        return f"Error: {e}"
    except Exception as e:
        return f"Error: {e}"


def _parse_unified_diff(patch_content: str) -> list[tuple[int, list[str]]]:
    """Parse unified diff into list of (old_start_1based, hunk_lines). We apply to current (old) file so use old line numbers."""
    hunks: list[tuple[int, list[str]]] = []
    lines = patch_content.replace("\r\n", "\n").replace("\r", "\n").split("\n")
    i = 0
    while i < len(lines):
        line = lines[i]
        if line.startswith("@@ ") and " @@ " in line:
            # @@ -old_start,old_count +new_start,new_count @@
            part = line.split(" @@ ", 1)[0].strip()
            part = part[3:].strip()  # drop @@
            parts = part.split()
            if len(parts) >= 2:
                try:
                    old_part = parts[0]  # -3,2 or -3
                    new_part = parts[1]  # +3,2 or +3
                    old_start = int(old_part.split(",")[0].replace("-", ""))
                    hunk_lines: list[str] = []
                    i += 1
                    while i < len(lines) and not lines[i].startswith("@@"):
                        hunk_lines.append(lines[i])
                        i += 1
                    hunks.append((old_start, hunk_lines))
                    continue
                except (ValueError, IndexError):
                    pass
        i += 1
    return hunks


def _apply_hunk(content: str, old_start_1: int, hunk_lines: list[str]) -> str:
    """Apply one hunk (unified diff lines) to content. old_start_1 is the line number (1-based) in the current (old) file.
    Returns new content or raises ValueError if context doesn't match."""
    file_lines = content.splitlines(keepends=True)
    if not file_lines and not hunk_lines:
        return content
    # Start at old_start (1-based) in current file
    idx = max(0, old_start_1 - 1)
    new_lines: list[str] = []
    i = 0
    for hunk_line in hunk_lines:
        if hunk_line.startswith(" "):
            # context: must match current file line
            if idx >= len(file_lines):
                raise ValueError(f"Context line at line {idx + 1} not found (file has {len(file_lines)} lines)")
            expected = hunk_line[1:].rstrip()
            if file_lines[idx].rstrip() != expected:
                raise ValueError(f"Context mismatch at line {idx + 1}: expected context line")
            new_lines.append(file_lines[idx])
            idx += 1
            i += 1
        elif hunk_line.startswith("-"):
            # remove line from file
            if idx >= len(file_lines):
                raise ValueError(f"Delete at line {idx + 1} but file has only {len(file_lines)} lines")
            removed = hunk_line[1:].rstrip()
            if file_lines[idx].rstrip() != removed:
                raise ValueError(f"Line to delete at {idx + 1} does not match")
            idx += 1
        elif hunk_line.startswith("+"):
            new_lines.append(hunk_line[1:] + "\n")
            i += 1
    # Build result: lines before hunk + new_lines + lines after hunk
    before = file_lines[: max(0, old_start_1 - 1)]
    after = file_lines[idx:] if idx <= len(file_lines) else []
    return "".join(before + new_lines + after)


def apply_patch(path: str, patch_content: str) -> str:
    """Apply a unified diff patch to a file. Path is relative to workspace. Fails clearly if patch is invalid or context doesn't match."""
    try:
        p = _resolve(path)
        content = p.read_text(encoding="utf-8", errors="replace")
        hunks = _parse_unified_diff(patch_content)
        if not hunks:
            return "Error: No valid hunks in patch (expected @@ ... @@ format)"
        _push_edit_checkpoint(path, content)
        for old_start, hunk_lines in hunks:
            content = _apply_hunk(content, old_start, hunk_lines)
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_text(content, encoding="utf-8")
        return f"Applied patch to {path} ({len(hunks)} hunk(s))"
    except FileNotFoundError:
        return f"Error: File not found: {path}"
    except ValueError as e:
        return f"Error: Patch failed — {e}"
    except Exception as e:
        return f"Error: {e}"


def search_replace(path: str, old_string: str, new_string: str) -> str:
    """Replace old_string with new_string in file (all occurrences). Path relative to workspace."""
    try:
        p = _resolve(path)
        content = p.read_text(encoding="utf-8", errors="replace")
        _push_edit_checkpoint(path, content)
        if old_string not in content:
            return f"Error: old_string not found in {path}"
        new_content = content.replace(old_string, new_string)
        p.write_text(new_content, encoding="utf-8")
        count = content.count(old_string)
        return f"Replaced {count} occurrence(s) in {path}"
    except FileNotFoundError:
        return f"Error: File not found: {path}"
    except ValueError as e:
        return f"Error: {e}"
    except Exception as e:
        return f"Error: {e}"


def search_in_files(query: str, path: str = ".", max_results: int = 50) -> str:
    """Search for text in workspace files. Returns file:line: snippet for each match. Path is relative to workspace."""
    try:
        base = get_agent_workspace().resolve()
        root = (base / path).resolve()
        if not str(root).startswith(str(base)):
            return "Error: Path must be inside workspace"
        if not root.is_dir():
            return "Error: Not a directory"
        pattern = query.strip()
        if not pattern:
            return "Error: query is required"
        results: list[str] = []
        count = 0
        try:
            for f in root.rglob("*"):
                if count >= max_results:
                    break
                if not f.is_file():
                    continue
                try:
                    raw = f.read_bytes()
                    if b"\x00" in raw[:8192]:
                        continue
                    text = raw.decode("utf-8", errors="replace")
                except (OSError, UnicodeDecodeError):
                    continue
                rel = f.relative_to(base)
                for i, line in enumerate(text.splitlines(), 1):
                    if count >= max_results:
                        break
                    if pattern.lower() in line.lower():
                        snippet = line.strip()[:120] + ("..." if len(line.strip()) > 120 else "")
                        results.append(f"{rel}:{i}: {snippet}")
                        count += 1
        except OSError as e:
            return f"Error: {e}"
        if not results:
            return f"No matches for '{pattern[:80]}' in {path}"
        return "\n".join(results)
    except ValueError as e:
        return f"Error: {e}"
    except Exception as e:
        return f"Error: {e}"


def take_screenshot(url_or_path: str, prompt: str = "Describe what you see. Any issues or improvements?") -> str:
    """Take screenshot of URL or file path, send to vision model for feedback."""
    try:
        from playwright.sync_api import sync_playwright
        from openartemis.config import get_anthropic_client as _gc, DEFAULT_BASE_MODEL
        import os

        if url_or_path.startswith(("http://", "https://")):
            url = url_or_path
        else:
            p = _resolve(url_or_path)
            url = f"file:///{p.as_posix()}"

        with sync_playwright() as p:
            browser = p.chromium.launch(headless=True)
            page = browser.new_page(viewport={"width": 1280, "height": 720})
            page.goto(url, wait_until="networkidle", timeout=15000)
            screenshot_bytes = page.screenshot()
            browser.close()

        b64 = base64.standard_b64encode(screenshot_bytes).decode()
        client = _gc()
        resp = client.messages.create(
            model=DEFAULT_BASE_MODEL,
            max_tokens=1024,
            messages=[
                {
                    "role": "user",
                    "content": [
                        {"type": "text", "text": prompt},
                        {"type": "image", "source": {"type": "base64", "media_type": "image/png", "data": b64}},
                    ],
                }
            ],
        )
        return (resp.content[0].text or "").strip()
    except Exception as e:
        return f"Error: {e}"


def generate_image(description: str, path: str) -> str:
    """Generate an image from a text description using the Images API and save to workspace path (e.g. assets/background.png)."""
    try:
        import os
        from openartemis.config import get_anthropic_client as _gc
        client = _gc()
        if not getattr(client, 'api_key', None):
            return "Error: Anthropic client not available. Cannot generate images."
        resolved = _resolve(path)
        resolved.parent.mkdir(parents=True, exist_ok=True)
        model = os.environ.get("OPENARTEMIS_IMAGE_MODEL", "dall-e-3")
        size = "1024x1024"
        if "dall-e-2" in model.lower():
            size = "512x512"
        resp = client.images.generate(
            model=model,
            prompt=description[:4000],
            size=size,
            response_format="b64_json",
            n=1,
        )
        if not resp.data:
            return "Error: No image data returned."
        b64 = resp.data[0].b64_json
        if not b64:
            return "Error: Empty image data."
        data = base64.standard_b64decode(b64)
        suffix = resolved.suffix.lower() or ".png"
        if suffix not in (".png", ".jpg", ".jpeg", ".webp"):
            resolved = resolved.with_suffix(".png")
        resolved.write_bytes(data)
        return f"Saved image to {path} ({len(data)} bytes)."
    except ValueError as e:
        return f"Error (path): {e}"
    except Exception as e:
        return f"Error: {e}"


def _parse_diagnostics(stdout: str, stderr: str) -> str:
    """Parse common linter/compiler patterns (file:line: message, file(line,col), etc.). Return short summary or empty."""
    combined = (stdout or "") + "\n" + (stderr or "")
    if not combined.strip():
        return ""
    diagnostics: list[str] = []
    # file:line: message or file:line:col: message
    for m in re.finditer(
        r"(?m)^([^\s:]+):(\d+)(?::(\d+))?\s*:\s*(.+?)(?=\n[A-Za-z_].*:\d+|$)",
        combined,
    ):
        path, line, col, msg = m.group(1), m.group(2), m.group(3) or "", m.group(4).strip()
        diagnostics.append(f"{path}:{line}:{f'{col}:' if col else ''} {msg[:200]}")
    # file(line,col): message or file (line:col)
    for m in re.finditer(
        r"(?m)([^\s(]+)\s*\(\s*(\d+)\s*(?:[,:]\s*(\d+))?\s*\)\s*:\s*(.+?)(?=\n|$)",
        combined,
    ):
        path, line, col, msg = m.group(1), m.group(2), m.group(3) or "", m.group(4).strip()
        diagnostics.append(f"{path}:{line}:{f'{col}:' if col else ''} {msg[:200]}")
    # "file" line col message (TS/ESLint style)
    for m in re.finditer(
        r'(?m)"([^"]+)"\s+line\s+(\d+)(?:\s+col\s+(\d+))?\s+(.+?)(?=\n|$)',
        combined,
    ):
        path, line, col, msg = m.group(1), m.group(2), m.group(3) or "", m.group(4).strip()
        diagnostics.append(f"{path}:{line}:{f'{col}:' if col else ''} {msg[:200]}")
    if not diagnostics:
        return ""
    summary = f"Diagnostics (parsed): {len(diagnostics)} issue(s)\n" + "\n".join(diagnostics[:15])
    if len(summary) > DIAGNOSTICS_MAX_CHARS:
        summary = summary[: DIAGNOSTICS_MAX_CHARS - 20] + "\n... (truncated)"
    return summary


def _is_likely_server_command(command: str) -> bool:
    """True if the command typically starts a long-running dev server (would block run_terminal)."""
    c = (command or "").strip().lower()
    if not c:
        return False
    markers = (
        "http.server",
        "serve ",
        "npx serve",
        "npm run dev",
        "npm start",
        "vite",
        "vue-cli-service serve",
        "ng serve",
        "react-scripts start",
        "next dev",
        "npm run start",
        "yarn dev",
        "yarn start",
        "pnpm dev",
        "pnpm start",
    )
    return any(m in c for m in markers)


def run_terminal(command: str) -> str:
    """Run command in workspace directory. Restricted to workspace cwd. Streams to terminal log file if set. In Docker sandbox, runs inside container.
    Long-running server commands (e.g. http.server, npx serve, npm run dev) are started in the background so the agent can continue with take_screenshot."""
    try:
        raw = os.environ.get("OPENARTEMIS_AGENT_TERMINAL_TIMEOUT", "").strip()
        timeout = 300
        if raw:
            try:
                timeout = int(raw)
                timeout = max(1, min(timeout, 3600))
            except ValueError:
                pass
        cid = get_agent_container_id()
        if cid is not None:
            from openartemis.agent.sandbox import exec_in_container
            out, code = exec_in_container(cid, command, timeout=timeout)
            log_path = get_terminal_log_path()
            if log_path is not None and out:
                try:
                    log_path.parent.mkdir(parents=True, exist_ok=True)
                    with open(log_path, "a", encoding="utf-8") as f:
                        f.write(f"\n--- {command}\n{out}\n")
                except OSError:
                    pass
            diag = _parse_diagnostics(out, "")
            return (out + "\n\n" + diag).strip() if diag else out
        ws = get_agent_workspace()
        ws.mkdir(parents=True, exist_ok=True)
        log_path = get_terminal_log_path()

        # Long-running server commands: start in background so the agent is not stuck waiting
        if _is_likely_server_command(command):
            import time
            if log_path is not None:
                log_path.parent.mkdir(parents=True, exist_ok=True)
                with open(log_path, "a", encoding="utf-8") as log_file:
                    log_file.write(f"\n--- {command} (background)\n")
            if os.name == "nt":
                # Windows: CREATE_NO_WINDOW prevents visible PowerShell popups
                _CREATE_NO_WINDOW = 0x08000000
                proc = subprocess.Popen(
                    command,
                    shell=True,
                    cwd=str(ws),
                    stdin=subprocess.DEVNULL,
                    stdout=subprocess.DEVNULL,
                    stderr=subprocess.DEVNULL,
                    creationflags=subprocess.CREATE_NEW_PROCESS_GROUP | _CREATE_NO_WINDOW,
                )
            else:
                # Unix: run in background via shell
                proc = subprocess.Popen(
                    command + " &",
                    shell=True,
                    cwd=str(ws),
                    stdin=subprocess.DEVNULL,
                    stdout=subprocess.PIPE,
                    stderr=subprocess.STDOUT,
                )
                proc.wait(timeout=5)
            time.sleep(3)
            return (
                "Server started in background. Wait a few seconds then use take_screenshot with the app URL "
                "(e.g. http://localhost:8000 or http://localhost:5173) to verify the app."
            )

        if log_path is not None:
            log_path.parent.mkdir(parents=True, exist_ok=True)
            with open(log_path, "a", encoding="utf-8") as log_file:
                log_file.write(f"\n--- {command}\n")
            proc = subprocess.Popen(
                command,
                shell=True,
                cwd=str(ws),
                stdout=subprocess.PIPE,
                stderr=subprocess.STDOUT,
                text=True,
                encoding="utf-8",
                errors="replace",
            )
            lines: list[str] = []
            def read_stream() -> None:
                if proc.stdout is None:
                    return
                for line in proc.stdout:
                    lines.append(line)
                    if log_path is not None:
                        try:
                            with open(log_path, "a", encoding="utf-8") as f:
                                f.write(line)
                        except OSError:
                            pass
            reader = threading.Thread(target=read_stream)
            reader.daemon = True
            reader.start()
            try:
                proc.wait(timeout=timeout)
            except subprocess.TimeoutExpired:
                proc.kill()
                proc.wait()
                reader.join(timeout=1)
                return f"Error: Command timed out ({timeout}s)"
            reader.join(timeout=2)
            out = "".join(lines)
            diag = _parse_diagnostics(out, "")
            result_str = out.strip() or f"(exit {proc.returncode})"
            return (result_str + "\n\n" + diag).strip() if diag else result_str
        result = subprocess.run(
            command,
            shell=True,
            cwd=str(ws),
            capture_output=True,
            text=True,
            timeout=timeout,
        )
        out = result.stdout or ""
        err = result.stderr or ""
        if err:
            out = out + "\n[stderr]\n" + err
        diag = _parse_diagnostics(result.stdout or "", result.stderr or "")
        result_str = out.strip() or f"(exit {result.returncode})"
        return (result_str + "\n\n" + diag).strip() if diag else result_str
    except subprocess.TimeoutExpired:
        return f"Error: Command timed out ({timeout}s)"
    except Exception as e:
        return f"Error: {e}"


def get_secret(key: str) -> str:
    """Return secret from vault (e.g. API key). Key is name like OPENAI_API_KEY."""
    try:
        from openartemis.secrets import get_secret as _get
        value = _get(key)
        if not value:
            return f"Error: No secret stored for key: {key}"
        return value
    except Exception as e:
        return f"Error: {e}"


def _execute_builtin(name: str, args: dict) -> str:
    """Execute built-in tool only."""
    if name == "read_file":
        return read_file(args.get("path", ""))
    if name == "write_file":
        return write_file(args.get("path", ""), args.get("content", ""))
    if name == "list_dir":
        return list_dir(args.get("path", "."))
    if name == "search_in_files":
        max_r = args.get("max_results", 50)
        if isinstance(max_r, (int, float)):
            max_r = max(1, min(int(max_r), 200))
        else:
            max_r = 50
        return search_in_files(args.get("query", ""), args.get("path", "."), max_results=max_r)
    if name == "run_terminal":
        return run_terminal(args.get("command", ""))
    if name == "take_screenshot":
        return take_screenshot(
            args.get("url_or_path", ""),
            args.get("prompt", "Describe what you see. Any issues or improvements?"),
        )
    if name == "generate_image":
        return generate_image(
            args.get("description", ""),
            args.get("path", ""),
        )
    if name == "search_replace":
        return search_replace(
            args.get("path", ""),
            args.get("old_string", ""),
            args.get("new_string", ""),
        )
    if name == "apply_patch":
        return apply_patch(args.get("path", ""), args.get("patch_content", ""))
    if name == "get_secret":
        return get_secret(args.get("key", ""))
    if name == "run_code_interpreter":
        if _run_code_interpreter is None:
            return "Code interpreter not available (openartemis.tools.code_interpreter not loaded)."
        return _run_code_interpreter(args.get("description_or_code", ""))
    if name in {"format_document", "get_diagnostics", "run_test", "search_workspace"}:
        # IDE-backed tools: delegate to runtime.ide_client if IDE runtime is enabled.
        try:
            import json as _json  # local alias to avoid polluting module namespace
            from openartemis.runtime.ide_actions import IDEAction, IDEActionKind
            from openartemis.runtime.ide_client import send_ide_action
        except Exception as e:  # pragma: no cover - defensive; runtime optional
            return f"IDE runtime not available in this environment ({e!s})"

        kind_map = {
            "format_document": IDEActionKind.FORMAT_DOCUMENT,
            "get_diagnostics": IDEActionKind.GET_DIAGNOSTICS,
            "run_test": IDEActionKind.RUN_TEST,
            "search_workspace": IDEActionKind.SEARCH_WORKSPACE,
        }
        kind = kind_map.get(name)
        if not kind:
            return f"Error: Unsupported IDE action {name!r}"
        payload = {k: v for k, v in args.items() if v is not None}
        action = IDEAction(kind=kind, payload=payload)  # type: ignore[arg-type]
        result = send_ide_action(action)
        details = f" ({_json.dumps(result.details)})" if result.details else ""
        prefix = "OK" if result.ok else "Error"
        return f"{prefix}: {result.message}{details}"
    return f"Unknown tool: {name}"


def load_plugin_tools() -> None:
    """Load plugin tools from ~/.openartemis/tools/*.py. Each module must define TOOL_SCHEMA and run(args)."""
    global PLUGIN_TOOLS, PLUGIN_HANDLERS
    PLUGIN_TOOLS.clear()
    PLUGIN_HANDLERS.clear()
    if not TOOLS_DIR.exists():
        return
    for py in TOOLS_DIR.glob("*.py"):
        if py.name.startswith("_"):
            continue
        try:
            spec = importlib.util.spec_from_file_location(f"openartemis_plugin_{py.stem}", py)
            if spec is None or spec.loader is None:
                continue
            mod = importlib.util.module_from_spec(spec)
            spec.loader.exec_module(mod)
            schema = getattr(mod, "TOOL_SCHEMA", None)
            run_fn = getattr(mod, "run", None)
            if schema and callable(run_fn):
                fn = schema.get("function") if isinstance(schema, dict) else {}
                name = (fn.get("name") if isinstance(fn, dict) else None) or (schema.get("name") if isinstance(schema, dict) else None)
                if not name:
                    continue
                if isinstance(schema, dict) and schema.get("type") != "function":
                    schema = {"type": "function", "function": {"name": name, "description": str((fn or schema).get("description", "")), "parameters": (fn or schema).get("parameters", {"type": "object", "properties": {}})}}
                PLUGIN_TOOLS.append(schema)
                PLUGIN_HANDLERS[name] = run_fn
        except Exception:
            continue


READ_ONLY_TOOL_NAMES = frozenset({"read_file", "list_dir", "search_in_files", "take_screenshot", "get_secret"})


def get_read_only_agent_tools() -> list[dict[str, Any]]:
    """Return only read-only tools (no write_file, run_terminal, search_replace). For Plan Mode."""
    return [t for t in AGENT_TOOLS if _tool_name(t) in READ_ONLY_TOOL_NAMES]


def _tool_name(t: dict) -> str:
    """Extract function name from a tool schema."""
    fn = t.get("function") if isinstance(t.get("function"), dict) else {}
    return (fn.get("name") or "").strip()


def get_all_agent_tools() -> list[dict[str, Any]]:
    """Return built-in tools plus loaded plugin tools."""
    if not PLUGIN_TOOLS:
        load_plugin_tools()
    return AGENT_TOOLS + PLUGIN_TOOLS


def execute_agent_tool(name: str, args: dict) -> str:
    """Execute built-in or plugin tool by name."""
    if name in PLUGIN_HANDLERS:
        try:
            return str(PLUGIN_HANDLERS[name](args))
        except Exception as e:
            return f"Plugin error: {e}"
    return _execute_builtin(name, args)


AGENT_TOOLS = [
    {
        "type": "function",
        "function": {
            "name": "read_file",
            "description": "Read file contents. Path is relative to workspace.",
            "parameters": {
                "type": "object",
                "properties": {"path": {"type": "string", "description": "File path (e.g. index.html)"}},
                "required": ["path"],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "format_document",
            "description": "Ask the IDE runtime (when enabled) to format a single document (e.g. using prettier/black). Falls back to a no-op message when runtime is disabled.",
            "parameters": {
                "type": "object",
                "properties": {
                    "uri": {"type": "string", "description": "Document URI or workspace-relative path"},
                },
                "required": ["uri"],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "get_diagnostics",
            "description": "Ask the IDE runtime (when enabled) for diagnostics on a single document. Use this to find and fix compiler/lint errors.",
            "parameters": {
                "type": "object",
                "properties": {
                    "uri": {"type": "string", "description": "Document URI or workspace-relative path"},
                },
                "required": ["uri"],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "run_test",
            "description": "Ask the IDE/runtime to run a named test task or target (e.g. npm test, pytest).",
            "parameters": {
                "type": "object",
                "properties": {
                    "target": {"type": "string", "description": "Test target or task name (e.g. 'npm test', 'pytest')."},
                },
                "required": ["target"],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "search_workspace",
            "description": "Use the IDE/runtime to search the workspace (e.g. via LSP or ripgrep). Prefer this over manual search when the IDE is available.",
            "parameters": {
                "type": "object",
                "properties": {
                    "query": {"type": "string", "description": "Text to search for"},
                },
                "required": ["query"],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "write_file",
            "description": "Write content to file. Creates parent dirs if needed.",
            "parameters": {
                "type": "object",
                "properties": {
                    "path": {"type": "string", "description": "File path"},
                    "content": {"type": "string", "description": "File content"},
                },
                "required": ["path", "content"],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "list_dir",
            "description": "List files and directories in path.",
            "parameters": {
                "type": "object",
                "properties": {"path": {"type": "string", "description": "Directory path (default: .)", "default": "."}},
                "required": [],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "search_in_files",
            "description": "Search for text in workspace files. Returns file:line: snippet for each match. Use to find where something is defined or used.",
            "parameters": {
                "type": "object",
                "properties": {
                    "query": {"type": "string", "description": "Text to search for (case-insensitive)"},
                    "path": {"type": "string", "description": "Directory to search in (default: .)", "default": "."},
                    "max_results": {"type": "integer", "description": "Max number of matches to return (default 50)", "default": 50},
                },
                "required": ["query"],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "run_terminal",
            "description": "Run shell command in workspace. Use for npm, python, etc.",
            "parameters": {
                "type": "object",
                "properties": {"command": {"type": "string", "description": "Shell command to run"}},
                "required": ["command"],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "take_screenshot",
            "description": "Take screenshot of URL (e.g. http://localhost:8000) or file path. Sends to vision model for feedback on UI.",
            "parameters": {
                "type": "object",
                "properties": {
                    "url_or_path": {"type": "string", "description": "URL or file path to capture"},
                    "prompt": {"type": "string", "description": "What to ask the vision model (default: describe and suggest improvements)", "default": "Describe what you see. Any issues or improvements?"},
                },
                "required": ["url_or_path"],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "generate_image",
            "description": "Generate an image from a text description (backgrounds, sprites, characters, logos) and save to workspace path. Use for assets the plan lists in 'images'. Creates parent dirs. Path e.g. assets/background.png.",
            "parameters": {
                "type": "object",
                "properties": {
                    "description": {"type": "string", "description": "Detailed prompt for the image (e.g. 'sky background with clouds, cartoon style')"},
                    "path": {"type": "string", "description": "Workspace path to save the image (e.g. assets/bird.png)"},
                },
                "required": ["description", "path"],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "search_replace",
            "description": "Replace old_string with new_string in file (all occurrences). Use for small edits without rewriting whole file.",
            "parameters": {
                "type": "object",
                "properties": {
                    "path": {"type": "string", "description": "File path relative to workspace"},
                    "old_string": {"type": "string", "description": "Exact string to replace"},
                    "new_string": {"type": "string", "description": "Replacement string"},
                },
                "required": ["path", "old_string", "new_string"],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "apply_patch",
            "description": "Apply a unified diff patch to a file. Use when you have a precise diff. Prefer search_replace for small edits; use write_file only for new or small files.",
            "parameters": {
                "type": "object",
                "properties": {
                    "path": {"type": "string", "description": "File path relative to workspace"},
                    "patch_content": {"type": "string", "description": "Unified diff content (e.g. @@ -1,3 +1,4 @@ ...)"},
                },
                "required": ["path", "patch_content"],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "get_secret",
            "description": "Get a secret from the vault (e.g. API key). Key is the name like OPENAI_API_KEY. Use when you need credentials not in env.",
            "parameters": {
                "type": "object",
                "properties": {"key": {"type": "string", "description": "Secret key name (e.g. OPENAI_API_KEY)"}},
                "required": ["key"],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "run_code_interpreter",
            "description": "Run Python in a sandbox via OpenAI Code Interpreter (math, data, small scripts). Only works if OPENARTEMIS_ENABLE_CODE_INTERPRETER=1. Use for one-off computations, not for editing project files.",
            "parameters": {
                "type": "object",
                "properties": {
                    "description_or_code": {
                        "type": "string",
                        "description": "What to compute (e.g. 'compute sqrt(2) to 50 digits') or a short code snippet to run",
                    },
                },
                "required": ["description_or_code"],
            },
        },
    },
]
