"""Game genre blueprints — complete entity/component/script recipes for 12+ game types.

Each blueprint provides the agent with a deterministic construction plan:
what entities to create, what components they need, what Lua scripts to write,
what assets to generate, and how to wire everything together.

The Director agent selects the matching blueprint from the user's prompt
and injects it into each specialist agent's context.
"""

from typing import Any, Dict, List

# ── Helper: common entity patterns ──

def _player_fps() -> Dict[str, Any]:
    return {
        "name": "Player",
        "components": ["Camera", "PhysX Dynamic Rigid Body", "PhysX Capsule Collider",
                       "StartingPointInput", "Lua Script"],
        "position": (0, 1.8, 0),
        "scripts": ["player_fps_controller"],
    }

def _player_third_person() -> Dict[str, Any]:
    return {
        "name": "Player",
        "components": ["Mesh", "PhysX Dynamic Rigid Body", "PhysX Capsule Collider",
                       "StartingPointInput", "Lua Script"],
        "position": (0, 1.0, 0),
        "scripts": ["player_third_person_controller"],
        "children": [
            {"name": "FollowCamera", "components": ["Camera", "Lua Script"],
             "position": (0, 3, -5), "scripts": ["camera_follow"]},
        ],
    }

def _directional_light() -> Dict[str, Any]:
    return {
        "name": "Sun",
        "components": ["Directional Light"],
        "rotation": (-45, 0, -30),
    }

def _skybox() -> Dict[str, Any]:
    return {
        "name": "Sky",
        "components": ["HDRi Skybox", "Global Skylight (IBL)"],
    }

def _ground_plane() -> Dict[str, Any]:
    return {
        "name": "Ground",
        "components": ["Mesh", "PhysX Static Rigid Body", "PhysX Box Collider"],
        "position": (0, 0, 0),
        "scale": (100, 0.1, 100),
    }


# ═══════════════════════════════════════════════════
# GENRE BLUEPRINTS
# ═══════════════════════════════════════════════════

BLUEPRINTS: Dict[str, Dict[str, Any]] = {}


# ── FPS ──
BLUEPRINTS["fps"] = {
    "genre": "FPS",
    "description": "First-person shooter with weapons, enemies, and health system",
    "required_entities": [
        _player_fps(),
        {"name": "Weapon_Rifle", "components": ["Mesh", "Lua Script"], "parent": "Player",
         "position": (0.3, -0.2, 0.5), "scripts": ["weapon_system"]},
        {"name": "Crosshair", "components": ["UiCanvas"], "scripts": ["hud_crosshair"]},
        {"name": "EnemySpawner", "components": ["Lua Script"], "position": (0, 0, 0),
         "scripts": ["enemy_spawner"]},
        {"name": "Enemy_Zombie", "components": ["Mesh", "PhysX Dynamic Rigid Body",
         "PhysX Capsule Collider", "Lua Script"], "position": (10, 1, 10),
         "scripts": ["enemy_ai_chase"]},
        {"name": "HealthPickup", "components": ["Mesh", "PhysX Static Rigid Body",
         "PhysX Box Collider", "Lua Script"], "scripts": ["pickup_health"]},
        {"name": "AmmoPickup", "components": ["Mesh", "PhysX Static Rigid Body",
         "PhysX Box Collider", "Lua Script"], "scripts": ["pickup_ammo"]},
        _directional_light(),
        _skybox(),
    ],
    "required_scripts": {
        "player_fps_controller": {
            "type": "lua",
            "template": """local PlayerFPS = {
    Properties = {
        MoveSpeed = { default = 8.0 },
        LookSpeed = { default = 2.0 },
        JumpForce = { default = 5.0 },
        Health = { default = 100 },
        MaxHealth = { default = 100 },
    }
}
function PlayerFPS:OnActivate()
    self.tickHandler = TickBus.Connect(self)
    self.inputHandler = InputEventNotificationBus.Connect(self, InputEventNotificationId(""))
    self.health = self.Properties.Health
    self.yaw = 0
    self.pitch = 0
end
function PlayerFPS:OnTick(dt, st)
    -- Movement with WASD
    local tm = TransformBus.Event.GetWorldTm(self.entityId)
    local forward = tm:GetBasisY()
    local right = tm:GetBasisX()
    local velocity = Vector3(0,0,0)
    if self.moveForward then velocity = velocity + forward * self.Properties.MoveSpeed * dt end
    if self.moveBack then velocity = velocity - forward * self.Properties.MoveSpeed * dt end
    if self.moveRight then velocity = velocity + right * self.Properties.MoveSpeed * dt end
    if self.moveLeft then velocity = velocity - right * self.Properties.MoveSpeed * dt end
    RigidBodyRequestBus.Event.SetLinearVelocity(self.entityId, velocity)
end
function PlayerFPS:TakeDamage(amount)
    self.health = math.max(0, self.health - amount)
    if self.health <= 0 then self:Die() end
end
function PlayerFPS:Die()
    Debug.Log("Player died!")
end
function PlayerFPS:OnDeactivate()
    self.tickHandler:Disconnect()
    self.inputHandler:Disconnect()
end
return PlayerFPS""",
        },
        "weapon_system": {
            "type": "lua",
            "template": """local Weapon = {
    Properties = {
        Damage = { default = 25 },
        FireRate = { default = 0.15 },
        MaxAmmo = { default = 30 },
        ReloadTime = { default = 2.0 },
        Range = { default = 100.0 },
    }
}
function Weapon:OnActivate()
    self.tickHandler = TickBus.Connect(self)
    self.ammo = self.Properties.MaxAmmo
    self.cooldown = 0
    self.reloading = false
end
function Weapon:OnTick(dt, st)
    if self.cooldown > 0 then self.cooldown = self.cooldown - dt end
end
function Weapon:Fire()
    if self.reloading or self.cooldown > 0 or self.ammo <= 0 then return end
    self.ammo = self.ammo - 1
    self.cooldown = self.Properties.FireRate
    -- Raycast for hit detection
    local tm = TransformBus.Event.GetWorldTm(self.entityId)
    local origin = tm:GetTranslation()
    local direction = tm:GetBasisY()
    local request = RayCastRequest()
    request.m_start = origin
    request.m_direction = direction * self.Properties.Range
    local result = PhysicsSystemRequestBus.Broadcast.RayCast(request)
    if result:HasHit() then
        local hitEntity = result:GetHitEntityId()
        -- Send damage event
    end
end
function Weapon:Reload()
    self.reloading = true
    self.ammo = self.Properties.MaxAmmo
    self.reloading = false
end
function Weapon:OnDeactivate() self.tickHandler:Disconnect() end
return Weapon""",
        },
        "enemy_ai_chase": {
            "type": "lua",
            "template": """local EnemyAI = {
    Properties = {
        Speed = { default = 4.0 },
        Health = { default = 50 },
        Damage = { default = 10 },
        DetectRange = { default = 20.0 },
        AttackRange = { default = 2.0 },
        AttackCooldown = { default = 1.0 },
    }
}
function EnemyAI:OnActivate()
    self.tickHandler = TickBus.Connect(self)
    self.health = self.Properties.Health
    self.attackTimer = 0
    self.state = "idle"
end
function EnemyAI:OnTick(dt, st)
    self.attackTimer = math.max(0, self.attackTimer - dt)
    local myPos = TransformBus.Event.GetWorldTranslation(self.entityId)
    local playerPos = TransformBus.Event.GetWorldTranslation(self.playerEntityId or EntityId())
    local dist = myPos:GetDistance(playerPos)
    if dist < self.Properties.DetectRange then
        self.state = "chase"
        local dir = (playerPos - myPos):GetNormalized()
        local velocity = dir * self.Properties.Speed
        RigidBodyRequestBus.Event.SetLinearVelocity(self.entityId, velocity)
        if dist < self.Properties.AttackRange and self.attackTimer <= 0 then
            self:Attack()
        end
    else
        self.state = "idle"
        RigidBodyRequestBus.Event.SetLinearVelocity(self.entityId, Vector3(0,0,0))
    end
end
function EnemyAI:Attack()
    self.attackTimer = self.Properties.AttackCooldown
    -- Deal damage to player
end
function EnemyAI:TakeDamage(amount)
    self.health = self.health - amount
    if self.health <= 0 then self:Die() end
end
function EnemyAI:Die()
    GameEntityContextRequestBus.Event.DestroyEntity(self.entityId)
end
function EnemyAI:OnDeactivate() self.tickHandler:Disconnect() end
return EnemyAI""",
        },
        "enemy_spawner": {
            "type": "lua",
            "template": """local Spawner = {
    Properties = {
        SpawnInterval = { default = 5.0 },
        MaxEnemies = { default = 10 },
        SpawnRadius = { default = 30.0 },
        EnemyPrefab = { default = "" },
    }
}
function Spawner:OnActivate()
    self.tickHandler = TickBus.Connect(self)
    self.timer = 0
    self.count = 0
end
function Spawner:OnTick(dt, st)
    self.timer = self.timer + dt
    if self.timer >= self.Properties.SpawnInterval and self.count < self.Properties.MaxEnemies then
        self.timer = 0
        self.count = self.count + 1
        local angle = math.random() * math.pi * 2
        local r = math.random() * self.Properties.SpawnRadius
        local x = math.cos(angle) * r
        local z = math.sin(angle) * r
        Debug.Log("Spawning enemy at " .. x .. ", " .. z)
    end
end
function Spawner:OnDeactivate() self.tickHandler:Disconnect() end
return Spawner""",
        },
    },
    "required_assets": [
        {"description": "Dark metal rifle weapon texture, game-ready, 512x512", "path": "assets/weapon_rifle.png"},
        {"description": "Zombie enemy character texture, game-ready, 512x512", "path": "assets/enemy_zombie.png"},
        {"description": "Concrete ground floor texture, tileable, 512x512", "path": "assets/ground_concrete.png"},
    ],
    "level_layout": {
        "terrain": True, "terrain_size": 512, "height_scale": 20.0,
    },
    "test_criteria": [
        "Player entity exists with Camera and PhysX components",
        "At least 1 enemy entity exists with AI script",
        "Weapon entity exists as child of Player",
        "Lighting and sky are set up",
        "Build compiles without errors",
    ],
}


# ── Third-Person Action ──
BLUEPRINTS["third_person_action"] = {
    "genre": "Third-Person Action",
    "description": "Third-person action game with melee combat, dodge, and camera follow",
    "required_entities": [
        _player_third_person(),
        {"name": "Sword", "components": ["Mesh", "Lua Script"], "parent": "Player",
         "position": (0.5, 0.5, 0), "scripts": ["melee_combat"]},
        {"name": "Enemy_Knight", "components": ["Mesh", "PhysX Dynamic Rigid Body",
         "PhysX Capsule Collider", "Lua Script"], "position": (8, 1, 8),
         "scripts": ["enemy_ai_melee"]},
        {"name": "HUD", "components": ["UiCanvas"], "scripts": ["hud_health_stamina"]},
        _directional_light(),
        _skybox(),
        _ground_plane(),
    ],
    "required_scripts": {
        "player_third_person_controller": {
            "type": "lua",
            "template": """local Player3P = {
    Properties = {
        MoveSpeed = { default = 6.0 },
        SprintSpeed = { default = 10.0 },
        DodgeForce = { default = 12.0 },
        Health = { default = 100 },
        Stamina = { default = 100 },
        StaminaRegen = { default = 15.0 },
    }
}
function Player3P:OnActivate()
    self.tickHandler = TickBus.Connect(self)
    self.health = self.Properties.Health
    self.stamina = self.Properties.Stamina
    self.isDodging = false
    self.dodgeTimer = 0
end
function Player3P:OnTick(dt, st)
    self.stamina = math.min(self.Properties.Stamina, self.stamina + self.Properties.StaminaRegen * dt)
    if self.isDodging then
        self.dodgeTimer = self.dodgeTimer - dt
        if self.dodgeTimer <= 0 then self.isDodging = false end
    end
end
function Player3P:Dodge(direction)
    if self.stamina >= 20 and not self.isDodging then
        self.stamina = self.stamina - 20
        self.isDodging = true
        self.dodgeTimer = 0.3
        RigidBodyRequestBus.Event.ApplyLinearImpulse(self.entityId, direction * self.Properties.DodgeForce)
    end
end
function Player3P:OnDeactivate() self.tickHandler:Disconnect() end
return Player3P""",
        },
        "camera_follow": {
            "type": "lua",
            "template": """local CameraFollow = {
    Properties = {
        Target = { default = EntityId() },
        Distance = { default = 5.0 },
        Height = { default = 3.0 },
        SmoothSpeed = { default = 8.0 },
    }
}
function CameraFollow:OnActivate()
    self.tickHandler = TickBus.Connect(self)
end
function CameraFollow:OnTick(dt, st)
    if not self.Properties.Target:IsValid() then return end
    local targetPos = TransformBus.Event.GetWorldTranslation(self.Properties.Target)
    local desiredPos = targetPos + Vector3(0, self.Properties.Height, -self.Properties.Distance)
    local currentPos = TransformBus.Event.GetWorldTranslation(self.entityId)
    local newPos = currentPos:Lerp(desiredPos, self.Properties.SmoothSpeed * dt)
    TransformBus.Event.SetWorldTranslation(self.entityId, newPos)
    TransformBus.Event.LookAt(self.entityId, targetPos)
end
function CameraFollow:OnDeactivate() self.tickHandler:Disconnect() end
return CameraFollow""",
        },
        "melee_combat": {
            "type": "lua",
            "template": """local MeleeCombat = {
    Properties = {
        Damage = { default = 30 },
        AttackRange = { default = 2.5 },
        ComboWindow = { default = 0.5 },
        AttackCooldown = { default = 0.4 },
    }
}
function MeleeCombat:OnActivate()
    self.tickHandler = TickBus.Connect(self)
    self.comboCount = 0
    self.cooldown = 0
    self.comboTimer = 0
end
function MeleeCombat:OnTick(dt, st)
    self.cooldown = math.max(0, self.cooldown - dt)
    self.comboTimer = self.comboTimer - dt
    if self.comboTimer <= 0 then self.comboCount = 0 end
end
function MeleeCombat:Attack()
    if self.cooldown > 0 then return end
    self.comboCount = self.comboCount + 1
    self.cooldown = self.Properties.AttackCooldown
    self.comboTimer = self.Properties.ComboWindow
    local damage = self.Properties.Damage * (1 + self.comboCount * 0.2)
    Debug.Log("Attack! Combo " .. self.comboCount .. " Damage: " .. damage)
end
function MeleeCombat:OnDeactivate() self.tickHandler:Disconnect() end
return MeleeCombat""",
        },
    },
    "required_assets": [
        {"description": "Medieval knight character texture, armored, 512x512", "path": "assets/knight.png"},
        {"description": "Sword weapon texture, steel blade, 256x256", "path": "assets/sword.png"},
        {"description": "Stone castle floor texture, tileable, 512x512", "path": "assets/stone_floor.png"},
    ],
    "level_layout": {"terrain": False},
    "test_criteria": [
        "Player entity exists with follow camera child",
        "Melee weapon entity with combat script",
        "At least 1 enemy with AI",
        "Build compiles without errors",
    ],
}


# ── RPG ──
BLUEPRINTS["rpg"] = {
    "genre": "RPG",
    "description": "Role-playing game with stats, inventory, NPCs, quests, and leveling",
    "required_entities": [
        _player_third_person(),
        {"name": "NPC_Merchant", "components": ["Mesh", "PhysX Static Rigid Body",
         "PhysX Capsule Collider", "Lua Script"], "position": (5, 1, 0),
         "scripts": ["npc_dialogue"]},
        {"name": "NPC_QuestGiver", "components": ["Mesh", "PhysX Static Rigid Body",
         "PhysX Capsule Collider", "Lua Script"], "position": (-5, 1, 3),
         "scripts": ["npc_dialogue", "quest_giver"]},
        {"name": "LootChest", "components": ["Mesh", "PhysX Static Rigid Body",
         "PhysX Box Collider", "Lua Script"], "position": (10, 0.5, -5),
         "scripts": ["interactable_chest"]},
        {"name": "HUD_RPG", "components": ["UiCanvas"],
         "scripts": ["hud_rpg"]},
        _directional_light(),
        _skybox(),
    ],
    "required_scripts": {
        "player_third_person_controller": BLUEPRINTS["third_person_action"]["required_scripts"]["player_third_person_controller"],
        "camera_follow": BLUEPRINTS["third_person_action"]["required_scripts"]["camera_follow"],
        "inventory_system": {
            "type": "lua",
            "template": """local Inventory = {
    Properties = { MaxSlots = { default = 20 } }
}
function Inventory:OnActivate()
    self.items = {}
    self.gold = 0
end
function Inventory:AddItem(item)
    if #self.items < self.Properties.MaxSlots then
        table.insert(self.items, item)
        Debug.Log("Added: " .. item.name)
        return true
    end
    return false
end
function Inventory:RemoveItem(index)
    if self.items[index] then
        table.remove(self.items, index)
        return true
    end
    return false
end
function Inventory:AddGold(amount) self.gold = self.gold + amount end
function Inventory:OnDeactivate() end
return Inventory""",
        },
        "stats_system": {
            "type": "lua",
            "template": """local Stats = {
    Properties = {
        Level = { default = 1 },
        XP = { default = 0 },
        XPToLevel = { default = 100 },
        Strength = { default = 10 },
        Dexterity = { default = 10 },
        Intelligence = { default = 10 },
        Vitality = { default = 10 },
    }
}
function Stats:OnActivate()
    self.level = self.Properties.Level
    self.xp = self.Properties.XP
end
function Stats:AddXP(amount)
    self.xp = self.xp + amount
    while self.xp >= self.Properties.XPToLevel * self.level do
        self.xp = self.xp - self.Properties.XPToLevel * self.level
        self:LevelUp()
    end
end
function Stats:LevelUp()
    self.level = self.level + 1
    self.Properties.Strength = self.Properties.Strength + 2
    self.Properties.Vitality = self.Properties.Vitality + 2
    Debug.Log("Level Up! Now level " .. self.level)
end
function Stats:OnDeactivate() end
return Stats""",
        },
        "npc_dialogue": {
            "type": "lua",
            "template": """local NPCDialogue = {
    Properties = {
        Name = { default = "NPC" },
        InteractRange = { default = 3.0 },
        Greeting = { default = "Hello, traveler!" },
    }
}
function NPCDialogue:OnActivate()
    self.tickHandler = TickBus.Connect(self)
    self.inRange = false
end
function NPCDialogue:OnTick(dt, st)
    local myPos = TransformBus.Event.GetWorldTranslation(self.entityId)
    -- Check if player is in range for interaction
end
function NPCDialogue:Interact()
    Debug.Log(self.Properties.Name .. ": " .. self.Properties.Greeting)
end
function NPCDialogue:OnDeactivate() self.tickHandler:Disconnect() end
return NPCDialogue""",
        },
    },
    "required_assets": [
        {"description": "Fantasy RPG character texture, medieval outfit, 512x512", "path": "assets/player_rpg.png"},
        {"description": "NPC merchant character texture, robes, 512x512", "path": "assets/npc_merchant.png"},
        {"description": "Wooden treasure chest texture, 256x256", "path": "assets/chest.png"},
        {"description": "Green grass terrain texture, tileable, 512x512", "path": "assets/grass.png"},
    ],
    "level_layout": {"terrain": True, "terrain_size": 1024, "height_scale": 50.0},
    "test_criteria": [
        "Player with stats and inventory scripts",
        "At least 2 NPC entities with dialogue",
        "Interactable objects (chests)",
        "Build compiles",
    ],
}


# ── Platformer ──
BLUEPRINTS["platformer"] = {
    "genre": "Platformer",
    "description": "Side-scrolling or 3D platformer with jumping, collectibles, and checkpoints",
    "required_entities": [
        {"name": "Player", "components": ["Mesh", "PhysX Dynamic Rigid Body",
         "PhysX Capsule Collider", "Lua Script", "Camera"],
         "position": (0, 2, 0), "scripts": ["platformer_controller"]},
        {"name": "Platform_Start", "components": ["Mesh", "PhysX Static Rigid Body",
         "PhysX Box Collider"], "position": (0, 0, 0), "scale": (5, 0.5, 3)},
        {"name": "Platform_Moving", "components": ["Mesh", "PhysX Kinematic Rigid Body",
         "PhysX Box Collider", "Lua Script"], "position": (8, 2, 0),
         "scale": (3, 0.5, 3), "scripts": ["moving_platform"]},
        {"name": "Collectible_Coin", "components": ["Mesh", "PhysX Static Rigid Body",
         "PhysX Sphere Collider", "Lua Script"], "position": (4, 3, 0),
         "scripts": ["collectible"]},
        {"name": "Checkpoint", "components": ["Mesh", "PhysX Static Rigid Body",
         "PhysX Box Collider", "Lua Script"], "position": (15, 1, 0),
         "scripts": ["checkpoint"]},
        {"name": "KillZone", "components": ["PhysX Static Rigid Body", "PhysX Box Collider",
         "Lua Script"], "position": (0, -10, 0), "scale": (200, 1, 200),
         "scripts": ["kill_zone"]},
        _directional_light(),
        _skybox(),
    ],
    "required_scripts": {
        "platformer_controller": {
            "type": "lua",
            "template": """local Platformer = {
    Properties = {
        MoveSpeed = { default = 7.0 },
        JumpForce = { default = 8.0 },
        DoubleJumpForce = { default = 6.0 },
        MaxJumps = { default = 2 },
        Gravity = { default = -20.0 },
    }
}
function Platformer:OnActivate()
    self.tickHandler = TickBus.Connect(self)
    self.jumpsLeft = self.Properties.MaxJumps
    self.isGrounded = false
    self.score = 0
    self.checkpoint = nil
end
function Platformer:OnTick(dt, st)
    -- Ground check via raycast
    local pos = TransformBus.Event.GetWorldTranslation(self.entityId)
    -- Apply gravity
    local vel = RigidBodyRequestBus.Event.GetLinearVelocity(self.entityId)
    vel.z = vel.z + self.Properties.Gravity * dt
    RigidBodyRequestBus.Event.SetLinearVelocity(self.entityId, vel)
end
function Platformer:Jump()
    if self.jumpsLeft > 0 then
        self.jumpsLeft = self.jumpsLeft - 1
        local force = self.jumpsLeft == self.Properties.MaxJumps - 1
            and self.Properties.JumpForce or self.Properties.DoubleJumpForce
        RigidBodyRequestBus.Event.ApplyLinearImpulse(self.entityId, Vector3(0, force, 0))
    end
end
function Platformer:OnGrounded()
    self.isGrounded = true
    self.jumpsLeft = self.Properties.MaxJumps
end
function Platformer:AddScore(amount) self.score = self.score + amount end
function Platformer:Respawn()
    if self.checkpoint then
        TransformBus.Event.SetWorldTranslation(self.entityId, self.checkpoint)
    end
end
function Platformer:OnDeactivate() self.tickHandler:Disconnect() end
return Platformer""",
        },
        "moving_platform": {
            "type": "lua",
            "template": """local MovingPlatform = {
    Properties = {
        MoveAxis = { default = Vector3(0, 1, 0) },
        MoveDistance = { default = 5.0 },
        Speed = { default = 2.0 },
    }
}
function MovingPlatform:OnActivate()
    self.tickHandler = TickBus.Connect(self)
    self.startPos = TransformBus.Event.GetWorldTranslation(self.entityId)
    self.timer = 0
end
function MovingPlatform:OnTick(dt, st)
    self.timer = self.timer + dt * self.Properties.Speed
    local offset = math.sin(self.timer) * self.Properties.MoveDistance
    local newPos = self.startPos + self.Properties.MoveAxis * offset
    TransformBus.Event.SetWorldTranslation(self.entityId, newPos)
end
function MovingPlatform:OnDeactivate() self.tickHandler:Disconnect() end
return MovingPlatform""",
        },
        "collectible": {
            "type": "lua",
            "template": """local Collectible = {
    Properties = {
        Value = { default = 10 },
        RotateSpeed = { default = 90.0 },
    }
}
function Collectible:OnActivate()
    self.tickHandler = TickBus.Connect(self)
end
function Collectible:OnTick(dt, st)
    local rot = TransformBus.Event.GetWorldRotation(self.entityId)
    rot.z = rot.z + math.rad(self.Properties.RotateSpeed * dt)
    TransformBus.Event.SetWorldRotation(self.entityId, rot)
end
function Collectible:OnCollected(playerEntity)
    Debug.Log("Collected! +" .. self.Properties.Value)
    GameEntityContextRequestBus.Event.DestroyEntity(self.entityId)
end
function Collectible:OnDeactivate() self.tickHandler:Disconnect() end
return Collectible""",
        },
    },
    "required_assets": [
        {"description": "Cartoon character texture, colorful platformer style, 512x512", "path": "assets/player_platformer.png"},
        {"description": "Gold coin collectible texture, shiny, 128x128", "path": "assets/coin.png"},
        {"description": "Platform stone block texture, tileable, 256x256", "path": "assets/platform_stone.png"},
    ],
    "level_layout": {"terrain": False},
    "test_criteria": [
        "Player with double-jump",
        "At least 3 platform entities",
        "Collectibles with rotation",
        "Kill zone below platforms",
        "Build compiles",
    ],
}


# ── Racing ──
BLUEPRINTS["racing"] = {
    "genre": "Racing",
    "description": "Racing game with vehicle physics, track, AI racers, and lap counting",
    "required_entities": [
        {"name": "PlayerCar", "components": ["Mesh", "PhysX Dynamic Rigid Body",
         "PhysX Box Collider", "Lua Script", "Camera"],
         "position": (0, 1, 0), "scripts": ["vehicle_controller"]},
        {"name": "AICar_1", "components": ["Mesh", "PhysX Dynamic Rigid Body",
         "PhysX Box Collider", "Lua Script"], "position": (3, 1, 0),
         "scripts": ["ai_racer"]},
        {"name": "Track_Checkpoint_1", "components": ["PhysX Static Rigid Body",
         "PhysX Box Collider", "Lua Script"], "position": (50, 1, 0),
         "scripts": ["race_checkpoint"]},
        {"name": "RaceManager", "components": ["Lua Script"],
         "scripts": ["race_manager"]},
        {"name": "BoostPad", "components": ["PhysX Static Rigid Body",
         "PhysX Box Collider", "Lua Script"], "position": (25, 0, 0),
         "scripts": ["boost_pad"]},
        _directional_light(),
        _skybox(),
    ],
    "required_scripts": {
        "vehicle_controller": {
            "type": "lua",
            "template": """local Vehicle = {
    Properties = {
        Acceleration = { default = 20.0 },
        MaxSpeed = { default = 40.0 },
        TurnSpeed = { default = 3.0 },
        BrakeForce = { default = 15.0 },
        Drag = { default = 0.98 },
    }
}
function Vehicle:OnActivate()
    self.tickHandler = TickBus.Connect(self)
    self.speed = 0
    self.lap = 0
end
function Vehicle:OnTick(dt, st)
    self.speed = self.speed * self.Properties.Drag
    local tm = TransformBus.Event.GetWorldTm(self.entityId)
    local forward = tm:GetBasisY()
    local velocity = forward * self.speed
    RigidBodyRequestBus.Event.SetLinearVelocity(self.entityId, velocity)
end
function Vehicle:Accelerate(dt)
    self.speed = math.min(self.Properties.MaxSpeed, self.speed + self.Properties.Acceleration * dt)
end
function Vehicle:Brake(dt)
    self.speed = math.max(0, self.speed - self.Properties.BrakeForce * dt)
end
function Vehicle:Boost(multiplier)
    self.speed = math.min(self.Properties.MaxSpeed * 1.5, self.speed * multiplier)
end
function Vehicle:OnDeactivate() self.tickHandler:Disconnect() end
return Vehicle""",
        },
        "race_manager": {
            "type": "lua",
            "template": """local RaceManager = {
    Properties = { TotalLaps = { default = 3 }, Countdown = { default = 3 } }
}
function RaceManager:OnActivate()
    self.tickHandler = TickBus.Connect(self)
    self.raceStarted = false
    self.timer = self.Properties.Countdown
    self.raceTime = 0
end
function RaceManager:OnTick(dt, st)
    if not self.raceStarted then
        self.timer = self.timer - dt
        if self.timer <= 0 then self.raceStarted = true; Debug.Log("GO!") end
    else
        self.raceTime = self.raceTime + dt
    end
end
function RaceManager:OnDeactivate() self.tickHandler:Disconnect() end
return RaceManager""",
        },
    },
    "required_assets": [
        {"description": "Sports car texture, red racing car, 512x512", "path": "assets/car_red.png"},
        {"description": "Asphalt road texture, tileable, 512x512", "path": "assets/road_asphalt.png"},
    ],
    "level_layout": {"terrain": True, "terrain_size": 512, "height_scale": 10.0},
    "test_criteria": ["Player car with vehicle physics", "AI racer", "Lap counter", "Build compiles"],
}


# ── Horror ──
BLUEPRINTS["horror"] = {
    "genre": "Horror",
    "description": "Horror game with dark atmosphere, flashlight, enemy stalking, and jump scares",
    "required_entities": [
        _player_fps(),
        {"name": "Flashlight", "components": ["Spot Light", "Lua Script"], "parent": "Player",
         "position": (0.3, 0, 0.5), "scripts": ["flashlight_controller"]},
        {"name": "Monster", "components": ["Mesh", "PhysX Dynamic Rigid Body",
         "PhysX Capsule Collider", "Lua Script"], "position": (20, 1, 20),
         "scripts": ["stalker_ai"]},
        {"name": "AmbientSound", "components": ["Audio Trigger"], "position": (0, 5, 0)},
        {"name": "JumpScareTrigger", "components": ["PhysX Static Rigid Body",
         "PhysX Box Collider", "Lua Script"], "position": (10, 1, 5),
         "scripts": ["jump_scare_trigger"]},
        {"name": "LockedDoor", "components": ["Mesh", "PhysX Static Rigid Body",
         "PhysX Box Collider", "Lua Script"], "position": (15, 1.5, 0),
         "scripts": ["locked_door"]},
        {"name": "Key_Item", "components": ["Mesh", "PhysX Static Rigid Body",
         "PhysX Box Collider", "Lua Script"], "position": (8, 0.5, -8),
         "scripts": ["pickup_key"]},
        {"name": "DimLight", "components": ["Point Light"], "position": (5, 3, 0)},
        _skybox(),
    ],
    "required_scripts": {
        "player_fps_controller": BLUEPRINTS["fps"]["required_scripts"]["player_fps_controller"],
        "flashlight_controller": {
            "type": "lua",
            "template": """local Flashlight = {
    Properties = { BatteryLife = { default = 120.0 }, DrainRate = { default = 1.0 } }
}
function Flashlight:OnActivate()
    self.tickHandler = TickBus.Connect(self)
    self.battery = self.Properties.BatteryLife
    self.isOn = true
end
function Flashlight:OnTick(dt, st)
    if self.isOn then
        self.battery = math.max(0, self.battery - self.Properties.DrainRate * dt)
        if self.battery <= 0 then self:Toggle() end
    end
end
function Flashlight:Toggle()
    self.isOn = not self.isOn
    -- Toggle light component visibility
end
function Flashlight:OnDeactivate() self.tickHandler:Disconnect() end
return Flashlight""",
        },
        "stalker_ai": {
            "type": "lua",
            "template": """local Stalker = {
    Properties = {
        Speed = { default = 2.5 },
        ChaseSpeed = { default = 6.0 },
        DetectRange = { default = 15.0 },
        LoseRange = { default = 30.0 },
        KillRange = { default = 1.5 },
    }
}
function Stalker:OnActivate()
    self.tickHandler = TickBus.Connect(self)
    self.state = "patrol"
    self.patrolTimer = 0
end
function Stalker:OnTick(dt, st)
    local myPos = TransformBus.Event.GetWorldTranslation(self.entityId)
    -- Patrol randomly, chase when player detected, kill when close
    if self.state == "patrol" then
        self.patrolTimer = self.patrolTimer + dt
        -- Wander logic
    elseif self.state == "chase" then
        -- Move toward player at chase speed
    end
end
function Stalker:OnDeactivate() self.tickHandler:Disconnect() end
return Stalker""",
        },
    },
    "required_assets": [
        {"description": "Dark horror monster texture, shadowy creature, 512x512", "path": "assets/monster.png"},
        {"description": "Old rusty key item texture, 128x128", "path": "assets/key.png"},
        {"description": "Dark wooden door texture, old and worn, 512x512", "path": "assets/door_old.png"},
    ],
    "level_layout": {"terrain": False},
    "test_criteria": [
        "Flashlight with battery drain",
        "Stalker AI enemy",
        "Jump scare triggers",
        "Dark lighting (no directional light, only point/spot)",
        "Build compiles",
    ],
}


# ── RTS ──
BLUEPRINTS["rts"] = {
    "genre": "RTS",
    "description": "Real-time strategy with unit selection, building, resource gathering",
    "required_entities": [
        {"name": "RTSCamera", "components": ["Camera", "Lua Script"],
         "position": (0, 30, -20), "scripts": ["rts_camera"]},
        {"name": "Base", "components": ["Mesh", "PhysX Static Rigid Body",
         "PhysX Box Collider", "Lua Script"], "position": (0, 0, 0),
         "scripts": ["building_base"]},
        {"name": "Worker", "components": ["Mesh", "PhysX Dynamic Rigid Body",
         "PhysX Capsule Collider", "Lua Script"], "position": (2, 0.5, 2),
         "scripts": ["unit_worker"]},
        {"name": "Soldier", "components": ["Mesh", "PhysX Dynamic Rigid Body",
         "PhysX Capsule Collider", "Lua Script"], "position": (4, 0.5, 2),
         "scripts": ["unit_soldier"]},
        {"name": "GoldMine", "components": ["Mesh", "PhysX Static Rigid Body",
         "PhysX Box Collider", "Lua Script"], "position": (15, 0, 10),
         "scripts": ["resource_node"]},
        {"name": "SelectionManager", "components": ["Lua Script"],
         "scripts": ["selection_manager"]},
        _directional_light(),
        _skybox(),
    ],
    "required_scripts": {
        "rts_camera": {
            "type": "lua",
            "template": """local RTSCamera = {
    Properties = {
        PanSpeed = { default = 20.0 },
        ZoomSpeed = { default = 5.0 },
        MinHeight = { default = 10.0 },
        MaxHeight = { default = 50.0 },
    }
}
function RTSCamera:OnActivate()
    self.tickHandler = TickBus.Connect(self)
end
function RTSCamera:OnTick(dt, st)
    -- Pan with WASD/arrow keys, zoom with scroll
end
function RTSCamera:OnDeactivate() self.tickHandler:Disconnect() end
return RTSCamera""",
        },
        "unit_worker": {
            "type": "lua",
            "template": """local Worker = {
    Properties = {
        Speed = { default = 5.0 },
        GatherRate = { default = 10 },
        CarryCapacity = { default = 50 },
        Health = { default = 40 },
    }
}
function Worker:OnActivate()
    self.tickHandler = TickBus.Connect(self)
    self.carrying = 0
    self.state = "idle"
    self.target = nil
end
function Worker:OnTick(dt, st)
    if self.state == "gathering" and self.target then
        self.carrying = math.min(self.Properties.CarryCapacity, self.carrying + self.Properties.GatherRate * dt)
        if self.carrying >= self.Properties.CarryCapacity then self.state = "returning" end
    end
end
function Worker:OnDeactivate() self.tickHandler:Disconnect() end
return Worker""",
        },
    },
    "required_assets": [
        {"description": "Medieval base building texture, wooden fort, 512x512", "path": "assets/base.png"},
        {"description": "Gold mine resource texture, rocky with gold veins, 256x256", "path": "assets/gold_mine.png"},
    ],
    "level_layout": {"terrain": True, "terrain_size": 1024, "height_scale": 30.0},
    "test_criteria": ["RTS camera with pan/zoom", "At least 2 unit types", "Resource gathering", "Build compiles"],
}


# ── Puzzle ──
BLUEPRINTS["puzzle"] = {
    "genre": "Puzzle",
    "description": "Puzzle game with interactable objects, triggers, gates, and inventory items",
    "required_entities": [
        _player_fps(),
        {"name": "PressurePlate", "components": ["Mesh", "PhysX Static Rigid Body",
         "PhysX Box Collider", "Lua Script"], "position": (5, 0, 0),
         "scripts": ["pressure_plate"]},
        {"name": "Gate", "components": ["Mesh", "PhysX Kinematic Rigid Body",
         "PhysX Box Collider", "Lua Script"], "position": (10, 1.5, 0),
         "scripts": ["gate"]},
        {"name": "PushBlock", "components": ["Mesh", "PhysX Dynamic Rigid Body",
         "PhysX Box Collider"], "position": (3, 0.5, 3)},
        _directional_light(),
        _skybox(),
        _ground_plane(),
    ],
    "required_scripts": {
        "player_fps_controller": BLUEPRINTS["fps"]["required_scripts"]["player_fps_controller"],
        "pressure_plate": {
            "type": "lua",
            "template": """local PressurePlate = {
    Properties = { TargetGate = { default = EntityId() }, WeightThreshold = { default = 1.0 } }
}
function PressurePlate:OnActivate()
    self.tickHandler = TickBus.Connect(self)
    self.activated = false
end
function PressurePlate:OnTick(dt, st)
    -- Check for overlapping entities with sufficient weight
end
function PressurePlate:Activate()
    self.activated = true
    -- Signal gate to open
    Debug.Log("Pressure plate activated!")
end
function PressurePlate:OnDeactivate() self.tickHandler:Disconnect() end
return PressurePlate""",
        },
        "gate": {
            "type": "lua",
            "template": """local Gate = {
    Properties = { OpenHeight = { default = 4.0 }, Speed = { default = 2.0 } }
}
function Gate:OnActivate()
    self.tickHandler = TickBus.Connect(self)
    self.closedPos = TransformBus.Event.GetWorldTranslation(self.entityId)
    self.openPos = self.closedPos + Vector3(0, self.Properties.OpenHeight, 0)
    self.isOpen = false
end
function Gate:OnTick(dt, st)
    local target = self.isOpen and self.openPos or self.closedPos
    local current = TransformBus.Event.GetWorldTranslation(self.entityId)
    local newPos = current:Lerp(target, self.Properties.Speed * dt)
    TransformBus.Event.SetWorldTranslation(self.entityId, newPos)
end
function Gate:Open() self.isOpen = true end
function Gate:Close() self.isOpen = false end
function Gate:OnDeactivate() self.tickHandler:Disconnect() end
return Gate""",
        },
    },
    "required_assets": [
        {"description": "Stone pressure plate texture, ancient looking, 128x128", "path": "assets/pressure_plate.png"},
        {"description": "Iron gate texture, heavy bars, 512x512", "path": "assets/iron_gate.png"},
    ],
    "level_layout": {"terrain": False},
    "test_criteria": ["Pressure plate + gate trigger pair", "Pushable physics blocks", "Build compiles"],
}


# ── Survival ──
BLUEPRINTS["survival"] = {
    "genre": "Survival",
    "description": "Survival game with crafting, hunger, day-night cycle, and shelter building",
    "required_entities": [
        _player_fps(),
        {"name": "DayNightCycle", "components": ["Directional Light", "Lua Script"],
         "rotation": (-45, 0, 0), "scripts": ["day_night_cycle"]},
        {"name": "Tree", "components": ["Mesh", "PhysX Static Rigid Body",
         "PhysX Capsule Collider", "Lua Script"], "position": (5, 3, 5),
         "scripts": ["harvestable_resource"]},
        {"name": "Rock", "components": ["Mesh", "PhysX Static Rigid Body",
         "PhysX Sphere Collider", "Lua Script"], "position": (-5, 0.5, 8),
         "scripts": ["harvestable_resource"]},
        {"name": "Campfire", "components": ["Mesh", "Point Light", "Particle Emitter",
         "Lua Script"], "position": (0, 0, 0), "scripts": ["campfire"]},
        _skybox(),
    ],
    "required_scripts": {
        "player_fps_controller": BLUEPRINTS["fps"]["required_scripts"]["player_fps_controller"],
        "survival_needs": {
            "type": "lua",
            "template": """local Survival = {
    Properties = {
        MaxHunger = { default = 100 },
        MaxThirst = { default = 100 },
        HungerRate = { default = 1.0 },
        ThirstRate = { default = 1.5 },
        MaxTemperature = { default = 100 },
    }
}
function Survival:OnActivate()
    self.tickHandler = TickBus.Connect(self)
    self.hunger = self.Properties.MaxHunger
    self.thirst = self.Properties.MaxThirst
    self.temperature = 50
end
function Survival:OnTick(dt, st)
    self.hunger = math.max(0, self.hunger - self.Properties.HungerRate * dt)
    self.thirst = math.max(0, self.thirst - self.Properties.ThirstRate * dt)
    if self.hunger <= 0 or self.thirst <= 0 then
        Debug.Log("Critical survival needs!")
    end
end
function Survival:Eat(amount) self.hunger = math.min(self.Properties.MaxHunger, self.hunger + amount) end
function Survival:Drink(amount) self.thirst = math.min(self.Properties.MaxThirst, self.thirst + amount) end
function Survival:OnDeactivate() self.tickHandler:Disconnect() end
return Survival""",
        },
        "crafting_system": {
            "type": "lua",
            "template": """local Crafting = { Properties = {} }
function Crafting:OnActivate()
    self.recipes = {
        { name = "Campfire", materials = { Wood = 5, Stone = 3 } },
        { name = "Shelter", materials = { Wood = 15, Stone = 5 } },
        { name = "Axe", materials = { Wood = 2, Stone = 3 } },
        { name = "Spear", materials = { Wood = 3, Stone = 1 } },
    }
end
function Crafting:CanCraft(recipeName, inventory)
    for _, recipe in ipairs(self.recipes) do
        if recipe.name == recipeName then
            for mat, count in pairs(recipe.materials) do
                if (inventory[mat] or 0) < count then return false end
            end
            return true
        end
    end
    return false
end
function Crafting:OnDeactivate() end
return Crafting""",
        },
        "day_night_cycle": {
            "type": "lua",
            "template": """local DayNight = {
    Properties = { CycleLength = { default = 120.0 }, StartHour = { default = 8.0 } }
}
function DayNight:OnActivate()
    self.tickHandler = TickBus.Connect(self)
    self.time = self.Properties.StartHour / 24.0
end
function DayNight:OnTick(dt, st)
    self.time = self.time + dt / self.Properties.CycleLength
    if self.time >= 1.0 then self.time = self.time - 1.0 end
    local angle = self.time * 360 - 90
    TransformBus.Event.SetWorldRotation(self.entityId, Vector3(math.rad(angle), 0, 0))
    -- Adjust light intensity based on time
    local intensity = math.max(0, math.sin(self.time * math.pi))
end
function DayNight:IsNight() return self.time > 0.75 or self.time < 0.25 end
function DayNight:OnDeactivate() self.tickHandler:Disconnect() end
return DayNight""",
        },
        "harvestable_resource": {
            "type": "lua",
            "template": """local Resource = {
    Properties = {
        ResourceType = { default = "Wood" },
        Amount = { default = 5 },
        HitPoints = { default = 3 },
        RespawnTime = { default = 60.0 },
    }
}
function Resource:OnActivate()
    self.tickHandler = TickBus.Connect(self)
    self.hp = self.Properties.HitPoints
    self.depleted = false
    self.respawnTimer = 0
end
function Resource:OnTick(dt, st)
    if self.depleted then
        self.respawnTimer = self.respawnTimer - dt
        if self.respawnTimer <= 0 then
            self.depleted = false
            self.hp = self.Properties.HitPoints
        end
    end
end
function Resource:Harvest()
    if self.depleted then return nil end
    self.hp = self.hp - 1
    if self.hp <= 0 then
        self.depleted = true
        self.respawnTimer = self.Properties.RespawnTime
        return { type = self.Properties.ResourceType, amount = self.Properties.Amount }
    end
    return nil
end
function Resource:OnDeactivate() self.tickHandler:Disconnect() end
return Resource""",
        },
    },
    "required_assets": [
        {"description": "Pine tree texture, forest style, 512x512", "path": "assets/tree_pine.png"},
        {"description": "Boulder rock texture, grey stone, 256x256", "path": "assets/rock.png"},
        {"description": "Campfire texture with flames, 256x256", "path": "assets/campfire.png"},
    ],
    "level_layout": {"terrain": True, "terrain_size": 1024, "height_scale": 40.0},
    "test_criteria": [
        "Survival needs (hunger, thirst)",
        "Day-night cycle rotating sun",
        "Harvestable resources",
        "Crafting recipes",
        "Build compiles",
    ],
}


# ── Fighting ──
BLUEPRINTS["fighting"] = {
    "genre": "Fighting",
    "description": "Fighting game with hitbox/hurtbox, combos, special moves, and rounds",
    "required_entities": [
        {"name": "Fighter_P1", "components": ["Mesh", "PhysX Dynamic Rigid Body",
         "PhysX Capsule Collider", "Lua Script"], "position": (-3, 1, 0),
         "scripts": ["fighter_controller"]},
        {"name": "Fighter_P2", "components": ["Mesh", "PhysX Dynamic Rigid Body",
         "PhysX Capsule Collider", "Lua Script"], "position": (3, 1, 0),
         "scripts": ["fighter_ai"]},
        {"name": "FightCamera", "components": ["Camera"], "position": (0, 3, -8)},
        {"name": "RoundManager", "components": ["Lua Script"],
         "scripts": ["round_manager"]},
        {"name": "HUD_Fight", "components": ["UiCanvas"], "scripts": ["hud_fight"]},
        _directional_light(),
        _skybox(),
        _ground_plane(),
    ],
    "required_scripts": {
        "fighter_controller": {
            "type": "lua",
            "template": """local Fighter = {
    Properties = {
        Health = { default = 100 },
        PunchDamage = { default = 8 },
        KickDamage = { default = 12 },
        SpecialDamage = { default = 25 },
        MoveSpeed = { default = 5.0 },
        SpecialMeter = { default = 0 },
        MaxSpecial = { default = 100 },
    }
}
function Fighter:OnActivate()
    self.tickHandler = TickBus.Connect(self)
    self.health = self.Properties.Health
    self.special = 0
    self.comboCount = 0
    self.hitstun = 0
    self.blockStun = 0
    self.isBlocking = false
end
function Fighter:OnTick(dt, st)
    self.hitstun = math.max(0, self.hitstun - dt)
    self.blockStun = math.max(0, self.blockStun - dt)
end
function Fighter:Punch() if self.hitstun > 0 then return end; self.comboCount = self.comboCount + 1 end
function Fighter:Kick() if self.hitstun > 0 then return end end
function Fighter:Special()
    if self.special >= self.Properties.MaxSpecial then
        self.special = 0
        Debug.Log("SPECIAL MOVE!")
    end
end
function Fighter:TakeDamage(amount)
    if self.isBlocking then amount = amount * 0.2 end
    self.health = math.max(0, self.health - amount)
    self.hitstun = 0.3
    self.special = math.min(self.Properties.MaxSpecial, self.special + amount * 0.5)
end
function Fighter:OnDeactivate() self.tickHandler:Disconnect() end
return Fighter""",
        },
        "round_manager": {
            "type": "lua",
            "template": """local RoundManager = {
    Properties = {
        MaxRounds = { default = 3 },
        RoundTime = { default = 60.0 },
    }
}
function RoundManager:OnActivate()
    self.tickHandler = TickBus.Connect(self)
    self.round = 1
    self.timer = self.Properties.RoundTime
    self.p1Wins = 0
    self.p2Wins = 0
end
function RoundManager:OnTick(dt, st)
    self.timer = math.max(0, self.timer - dt)
    if self.timer <= 0 then self:EndRound() end
end
function RoundManager:EndRound()
    self.round = self.round + 1
    self.timer = self.Properties.RoundTime
    Debug.Log("Round " .. self.round)
end
function RoundManager:OnDeactivate() self.tickHandler:Disconnect() end
return RoundManager""",
        },
    },
    "required_assets": [
        {"description": "Fighter character 1 texture, martial artist, 512x512", "path": "assets/fighter1.png"},
        {"description": "Fighter character 2 texture, rival, 512x512", "path": "assets/fighter2.png"},
        {"description": "Fighting arena floor texture, 512x512", "path": "assets/arena_floor.png"},
    ],
    "level_layout": {"terrain": False},
    "test_criteria": ["2 fighter entities", "Combo system", "Round manager", "Health bars", "Build compiles"],
}


# ── Multiplayer ──
BLUEPRINTS["multiplayer"] = {
    "genre": "Multiplayer",
    "description": "Online multiplayer game with lobby, player spawning, and sync",
    "required_entities": [
        {"name": "NetworkManager", "components": ["Lua Script"],
         "scripts": ["network_manager"]},
        {"name": "LobbyManager", "components": ["Lua Script"],
         "scripts": ["lobby_manager"]},
        {"name": "PlayerSpawnPoint_1", "components": ["Lua Script"],
         "position": (-5, 1, 0), "scripts": ["spawn_point"]},
        {"name": "PlayerSpawnPoint_2", "components": ["Lua Script"],
         "position": (5, 1, 0), "scripts": ["spawn_point"]},
        _directional_light(), _skybox(), _ground_plane(),
    ],
    "required_scripts": {
        "network_manager": {"type": "lua", "template": """local Net = { Properties = { MaxPlayers = { default = 16 } } }
function Net:OnActivate() self.players = {} end
function Net:OnDeactivate() end
return Net"""},
    },
    "required_assets": [],
    "level_layout": {"terrain": True, "terrain_size": 512, "height_scale": 20.0},
    "test_criteria": ["Network manager entity", "Spawn points", "Build compiles"],
}


# ── Open World ──
BLUEPRINTS["open_world"] = {
    "genre": "Open World",
    "description": "Open world game with POIs, fast travel, dynamic weather, and exploration",
    "required_entities": [
        _player_third_person(),
        {"name": "WeatherSystem", "components": ["Lua Script"],
         "scripts": ["weather_system"]},
        {"name": "POI_Village", "components": ["Lua Script"],
         "position": (100, 0, 50), "scripts": ["poi_marker"]},
        {"name": "POI_Dungeon", "components": ["Lua Script"],
         "position": (-80, 0, 120), "scripts": ["poi_marker"]},
        {"name": "FastTravel_Village", "components": ["Mesh", "PhysX Static Rigid Body",
         "PhysX Box Collider", "Lua Script"], "position": (100, 0, 50),
         "scripts": ["fast_travel_point"]},
        {"name": "Minimap", "components": ["Camera"], "position": (0, 100, 0)},
        _directional_light(), _skybox(),
    ],
    "required_scripts": {
        "player_third_person_controller": BLUEPRINTS["third_person_action"]["required_scripts"]["player_third_person_controller"],
        "camera_follow": BLUEPRINTS["third_person_action"]["required_scripts"]["camera_follow"],
        "weather_system": {
            "type": "lua",
            "template": """local Weather = {
    Properties = { ChangeInterval = { default = 120.0 } }
}
function Weather:OnActivate()
    self.tickHandler = TickBus.Connect(self)
    self.current = "clear"
    self.timer = self.Properties.ChangeInterval
    self.states = {"clear", "cloudy", "rain", "storm", "fog"}
end
function Weather:OnTick(dt, st)
    self.timer = self.timer - dt
    if self.timer <= 0 then
        self.timer = self.Properties.ChangeInterval
        self.current = self.states[math.random(#self.states)]
        Debug.Log("Weather: " .. self.current)
    end
end
function Weather:OnDeactivate() self.tickHandler:Disconnect() end
return Weather""",
        },
        "fast_travel_point": {
            "type": "lua",
            "template": """local FastTravel = {
    Properties = { Name = { default = "Unknown" }, Discovered = { default = false } }
}
function FastTravel:OnActivate() end
function FastTravel:Discover() self.Properties.Discovered = true end
function FastTravel:TravelTo(playerEntity)
    if self.Properties.Discovered then
        local pos = TransformBus.Event.GetWorldTranslation(self.entityId)
        TransformBus.Event.SetWorldTranslation(playerEntity, pos)
    end
end
function FastTravel:OnDeactivate() end
return FastTravel""",
        },
    },
    "required_assets": [
        {"description": "Village buildings texture, medieval style, 512x512", "path": "assets/village.png"},
        {"description": "Large terrain grass and dirt texture, tileable, 1024x1024", "path": "assets/terrain_grass.png"},
    ],
    "level_layout": {"terrain": True, "terrain_size": 2048, "height_scale": 100.0},
    "test_criteria": ["Large terrain", "Weather system", "Fast travel points", "POI markers", "Build compiles"],
}


# ═══════════════════════════════════════════════════
# GENRE DETECTION
# ═══════════════════════════════════════════════════

# Keywords mapped to blueprint keys
GENRE_KEYWORDS: Dict[str, List[str]] = {
    "fps": ["fps", "first person shooter", "first-person shooter", "shoot", "gun", "rifle", "call of duty", "doom", "halo"],
    "third_person_action": ["third person", "third-person", "action adventure", "hack and slash", "god of war", "dark souls", "melee action", "action rpg combat"],
    "rpg": ["rpg", "role playing", "role-playing", "quest", "npc", "inventory", "leveling", "experience points", "skyrim", "zelda", "witcher"],
    "platformer": ["platformer", "platform", "jump", "side scroll", "mario", "sonic", "collectible", "double jump"],
    "racing": ["racing", "race", "car", "vehicle", "driving", "speed", "lap", "track", "forza", "gran turismo", "need for speed"],
    "horror": ["horror", "scary", "dark", "monster", "flashlight", "jump scare", "resident evil", "silent hill", "creepy", "haunted"],
    "rts": ["rts", "real time strategy", "real-time strategy", "base building", "command", "army", "unit", "starcraft", "age of empires"],
    "puzzle": ["puzzle", "logic", "trigger", "pressure plate", "portal", "solve", "brain", "riddle"],
    "survival": ["survival", "craft", "hunger", "thirst", "day night", "resource", "gather", "build shelter", "rust", "ark", "minecraft"],
    "fighting": ["fighting", "fighter", "combo", "punch", "kick", "street fighter", "mortal kombat", "tekken", "round", "versus"],
    "multiplayer": ["multiplayer", "online", "co-op", "pvp", "mmo", "lobby", "server"],
    "open_world": ["open world", "open-world", "explore", "sandbox", "gta", "fast travel", "weather"],
}


def detect_genre(prompt: str) -> str:
    """Detect game genre from user prompt. Returns blueprint key or 'fps' as default."""
    lower = prompt.lower()
    scores: Dict[str, int] = {}
    for genre, keywords in GENRE_KEYWORDS.items():
        score = sum(1 for kw in keywords if kw in lower)
        if score > 0:
            scores[genre] = score
    if scores:
        return max(scores, key=scores.get)
    return "fps"


def get_blueprint(genre_key: str) -> Dict[str, Any]:
    """Get blueprint for a genre. Falls back to FPS if not found."""
    return BLUEPRINTS.get(genre_key, BLUEPRINTS["fps"])


def get_blueprint_for_prompt(prompt: str) -> Dict[str, Any]:
    """Detect genre from prompt and return the matching blueprint."""
    genre = detect_genre(prompt)
    return get_blueprint(genre)


def get_all_genre_names() -> List[str]:
    """Return all available genre display names."""
    return [bp["genre"] for bp in BLUEPRINTS.values()]
