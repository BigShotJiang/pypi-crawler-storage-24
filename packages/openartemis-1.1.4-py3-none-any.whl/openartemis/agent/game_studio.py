"""Multi-agent Game Studio — 5 specialized agents orchestrated by a Director.

Architecture:
  Director        → Creates GDD, assigns tasks, reviews output, handles fix cycles
  Engine Operator → Creates project, levels, entities, components, terrain, lighting
  Asset Artist    → Generates textures via DALL-E, creates materials, imports assets
  Gameplay Dev    → Writes all Lua scripts (player, enemy AI, UI, game logic)
  QA Tester       → Builds project, checks errors, reports bugs back to Director

Flow:
  User prompt → Director creates GDD from blueprint
    → Engine Operator sets up world
    → Asset Artist generates textures + materials
    → Gameplay Dev writes all Lua scripts
    → Engine Operator wires scripts to entities
    → QA Tester builds + verifies
    → If QA finds issues → Director assigns fix
    → Repeat QA loop up to 3 times
    → Final report
"""

import json
import os
import time
import logging
from pathlib import Path
from typing import Any, Callable, Dict, List, Optional, Tuple

from openartemis.config import get_anthropic_client as _get_openai_client
from openartemis.agent.game_blueprints import (
    detect_genre,
    get_blueprint,
    get_blueprint_for_prompt,
)

logger = logging.getLogger(__name__)

# ═══════════════════════════════════════════════════
# AGENT SYSTEM PROMPTS
# ═══════════════════════════════════════════════════

DIRECTOR_PROMPT = """You are the Director of a AAA game studio powered by OpenArtemis.
Your job: read the user's game idea, pick a genre blueprint, and produce a Game Design Document (GDD).

You will receive a GENRE BLUEPRINT with pre-built entity lists, script templates, and asset requirements.
Your GDD adapts the blueprint to the user's specific vision.

Output a JSON GDD:
{
  "title": "Game Title",
  "genre": "detected genre",
  "description": "2-3 sentence game summary",
  "entities": [
    {"name": "EntityName", "components": ["Comp1", "Comp2"], "position": [x,y,z], "scripts": ["script_name"], "parent": null}
  ],
  "scripts": [
    {"name": "script_name", "description": "what this script does", "use_template": true}
  ],
  "assets": [
    {"description": "detailed image generation prompt", "path": "assets/filename.png"}
  ],
  "level": {
    "name": "LevelName",
    "terrain": true,
    "terrain_size": 1024,
    "height_scale": 50.0,
    "lighting": "bright" or "dark" or "dramatic"
  },
  "test_criteria": ["criterion 1", "criterion 2"]
}

Rules:
- Use the blueprint entities/scripts as your starting point, customize names/properties to match the user's theme
- Every entity must have components listed
- Every script must be in the scripts array
- Every texture/image needed must be in assets
- Be specific: "zombie in dark forest" not "enemy texture"
- Output ONLY valid JSON, no markdown"""

ENGINE_OPERATOR_PROMPT = """You are the Engine Operator agent. You control O3DE to set up the game world.

Your tasks (in order):
1. Create the level with terrain if needed
2. Set up lighting (bright, dark, or dramatic)
3. Create all entities from the GDD with their components
4. Set entity positions and parent relationships
5. Attach scripts to entities after Gameplay Dev writes them

Use these tools:
- o3de_create_level(name, size, use_terrain)
- o3de_setup_lighting(light_type, color, intensity)
- o3de_create_entity(name, components, position, parent)
- o3de_add_component(entity_name, component_type)
- o3de_set_property(entity_name, component, property_path, value)
- o3de_create_terrain(size, height_scale)
- o3de_save_level()

Execute each task by calling the appropriate tool. Be precise with entity names — they must match the GDD exactly."""

ASSET_ARTIST_PROMPT = """You are the Asset Artist agent. You generate game textures and materials.

For each asset in the GDD:
1. Call generate_image with a detailed, game-ready prompt
2. Call o3de_import_asset to bring it into the project
3. Call o3de_set_material to assign materials to entities

Use these tools:
- generate_image(description, path)
- o3de_import_asset(source_path, asset_type)
- o3de_set_material(entity_name, material_path)

Image prompt tips:
- Always include "game-ready texture" or "game asset" in prompts
- Specify resolution: "512x512" or "1024x1024"
- Include art style: "realistic", "stylized", "pixel art", "low-poly"
- Include the object: "zombie character front view, game-ready texture, 512x512"

Execute all asset generation. Do not skip any asset from the GDD."""

GAMEPLAY_DEV_PROMPT = """You are the Gameplay Dev agent. You write all Lua scripts for the game.

For each script in the GDD:
1. If use_template is true, use the provided template as-is (it's already complete)
2. If use_template is false, write a new Lua script following O3DE patterns
3. Call o3de_write_script to save each script

O3DE Lua script pattern:
```lua
local ScriptName = {
    Properties = {
        Speed = { default = 5.0, description = "Movement speed" },
    }
}
function ScriptName:OnActivate()
    self.tickHandler = TickBus.Connect(self)
end
function ScriptName:OnTick(deltaTime, scriptTime)
    -- Game logic here
end
function ScriptName:OnDeactivate()
    self.tickHandler:Disconnect()
end
return ScriptName
```

Use these tools:
- o3de_write_script(name, content, script_type)
- o3de_run_editor_script(script_content)

Write complete, working Lua scripts. No placeholders, no TODOs. Every script must be functional."""

QA_TESTER_PROMPT = """You are the QA Tester agent. You verify the game builds and works correctly.

Your tasks:
1. Check project info to verify all entities/scripts exist
2. Build the game
3. Review build output for errors
4. Report issues as a structured JSON list

Use these tools:
- o3de_project_info()
- o3de_build_game(platform, config)
- o3de_save_level()

Output a JSON report:
{
  "build_success": true/false,
  "errors": ["error 1", "error 2"],
  "warnings": ["warning 1"],
  "missing_entities": ["entity that should exist but doesn't"],
  "missing_scripts": ["script that should exist but doesn't"],
  "test_results": [
    {"criterion": "test description", "passed": true/false, "note": "details"}
  ],
  "overall": "PASS" or "FAIL",
  "fix_suggestions": ["suggestion 1"]
}

Be thorough. Check every test criterion from the GDD."""


# ═══════════════════════════════════════════════════
# AGENT RUNNER
# ═══════════════════════════════════════════════════

def _call_agent(
    system_prompt: str,
    user_message: str,
    tools: List[Dict[str, Any]] | None = None,
    tool_executor: Callable | None = None,
    on_status: Callable[[str], None] | None = None,
    max_turns: int = 15,
    model: str = "gpt-4.1",
) -> str:
    """Run a single agent with optional tool calling. Returns final text output."""
    client = _get_openai_client()

    messages: list[dict[str, Any]] = [
        {"role": "system", "content": system_prompt},
        {"role": "user", "content": user_message},
    ]

    for turn in range(max_turns):
        try:
            kwargs: dict[str, Any] = {
                "model": model,
                "messages": messages,
                "max_tokens": 4096,
            }
            if tools:
                kwargs["tools"] = tools
                kwargs["tool_choice"] = "auto"

            resp = client.chat.completions.create(**kwargs)
        except Exception as e:
            logger.error("Agent API error: %s", e)
            if on_status:
                on_status(f"API error: {e}")
            return f"Error: {e}"

        msg = resp.choices[0].message
        # Serialize for history
        msg_dict: dict[str, Any] = {"role": msg.role, "content": msg.content or ""}
        if msg.tool_calls:
            msg_dict["tool_calls"] = [
                {"id": t.id, "type": "function",
                 "function": {"name": t.function.name, "arguments": t.function.arguments or "{}"}}
                for t in msg.tool_calls
            ]
        messages.append(msg_dict)

        if not msg.tool_calls:
            return msg.content or ""

        # Execute tool calls
        for tc in msg.tool_calls:
            name = tc.function.name
            try:
                args = json.loads(tc.function.arguments or "{}")
            except json.JSONDecodeError:
                args = {}

            if on_status:
                short_args = ", ".join(f"{k}={v!r}" for k, v in list(args.items())[:2])
                on_status(f"{name}({short_args})")

            result = tool_executor(name, args) if tool_executor else f"No executor for {name}"

            messages.append({
                "role": "tool",
                "tool_call_id": tc.id,
                "content": str(result)[:2000],
            })

    return "(max turns reached)"


# ═══════════════════════════════════════════════════
# GAME STUDIO ORCHESTRATOR
# ═══════════════════════════════════════════════════

class GameStudio:
    """Multi-agent game studio that orchestrates 5 specialized agents."""

    def __init__(
        self,
        bridge: Any,
        on_status: Callable[[str], None] | None = None,
        model: str = "gpt-4.1",
    ):
        self.bridge = bridge
        self.on_status = on_status
        self.model = model
        self.gdd: Dict[str, Any] = {}
        self.qa_report: Dict[str, Any] = {}
        self.lines_coded = 0
        self.entities_created: List[str] = []
        self.assets_generated: List[str] = []
        self.scripts_written: List[str] = []
        self.start_time = time.time()
        self.trace: List[Dict[str, Any]] = []
        self._memory: Optional[Any] = None
        # Try to load memory for repo indexing
        try:
            from openartemis.agent.agent_memory import AgentMemory
            if bridge.project_path:
                self._memory = AgentMemory(bridge.project_path.name, bridge.project_path)
        except Exception:
            pass

    def _status(self, agent: str, msg: str) -> None:
        if self.on_status:
            self.on_status(f"[{agent}] {msg}")

    def _log_trace(self, agent: str, action: str, data: Any = None) -> None:
        self.trace.append({
            "agent": agent,
            "action": action,
            "data": data,
            "elapsed": round(time.time() - self.start_time, 1),
        })

    def _get_past_build_context(self, genre_key: str) -> str:
        """Retrieve past build context from memory for Director injection."""
        if not self._memory:
            return ""
        try:
            ctx = self._memory.get_build_context_for_genre(genre_key)
            if ctx:
                return f"PAST BUILD REFERENCE:\n{ctx}\n\n"
        except Exception:
            pass
        return ""

    def _save_build_to_memory(self, trace_data: Dict[str, Any]) -> None:
        """Save successful build to memory for future retrieval."""
        if not self._memory:
            return
        try:
            self._memory.add_game_build(trace_data)
        except Exception:
            pass

    # ── Phase 1: Director creates GDD ──

    def run_director(self, user_prompt: str) -> Dict[str, Any]:
        """Director agent creates a Game Design Document from the user's prompt."""
        self._status("Director", "Analyzing game concept...")
        self._log_trace("director", "start", {"prompt": user_prompt[:200]})

        genre_key = detect_genre(user_prompt)
        blueprint = get_blueprint(genre_key)

        self._status("Director", f"Detected genre: {blueprint['genre']}")

        # Build context with blueprint
        bp_context = json.dumps({
            "genre": blueprint["genre"],
            "entities": [
                {"name": e["name"], "components": e["components"],
                 "scripts": e.get("scripts", []),
                 "position": e.get("position", (0, 0, 0))}
                for e in blueprint["required_entities"]
            ],
            "script_templates": {
                name: {"type": info["type"], "has_template": True}
                for name, info in blueprint.get("required_scripts", {}).items()
            },
            "assets": blueprint.get("required_assets", []),
            "level": blueprint.get("level_layout", {}),
            "test_criteria": blueprint.get("test_criteria", []),
        }, indent=2)

        user_msg = f"""User wants to build: {user_prompt}

GENRE BLUEPRINT ({blueprint['genre']}):
{bp_context}

{self._get_past_build_context(genre_key)}
Create a GDD that adapts this blueprint to the user's specific vision. Customize entity names, properties, and descriptions to match their theme while keeping the proven architecture."""

        result = _call_agent(
            system_prompt=DIRECTOR_PROMPT,
            user_message=user_msg,
            on_status=lambda m: self._status("Director", m),
            max_turns=1,
            model=self.model,
        )

        # Parse GDD
        try:
            # Try to extract JSON from response
            if "```" in result:
                json_str = result.split("```")[1]
                if json_str.startswith("json"):
                    json_str = json_str[4:]
                self.gdd = json.loads(json_str.strip())
            else:
                self.gdd = json.loads(result.strip())
        except (json.JSONDecodeError, IndexError):
            # Fallback: build GDD directly from blueprint
            self._status("Director", "Using blueprint directly as GDD")
            self.gdd = {
                "title": user_prompt.split()[0:3],
                "genre": blueprint["genre"],
                "description": user_prompt,
                "entities": [
                    {"name": e["name"], "components": e["components"],
                     "position": list(e.get("position", (0, 0, 0))),
                     "scripts": e.get("scripts", []),
                     "parent": e.get("parent")}
                    for e in blueprint["required_entities"]
                ],
                "scripts": [
                    {"name": name, "description": f"{name} script", "use_template": True}
                    for name in blueprint.get("required_scripts", {})
                ],
                "assets": blueprint.get("required_assets", []),
                "level": {
                    "name": "Main",
                    "terrain": blueprint.get("level_layout", {}).get("terrain", False),
                    "terrain_size": blueprint.get("level_layout", {}).get("terrain_size", 512),
                    "height_scale": blueprint.get("level_layout", {}).get("height_scale", 20.0),
                    "lighting": "bright",
                },
                "test_criteria": blueprint.get("test_criteria", []),
            }

        # Store blueprint reference for script templates
        self._blueprint = blueprint
        n_ent = len(self.gdd.get("entities", []))
        n_scr = len(self.gdd.get("scripts", []))
        n_ast = len(self.gdd.get("assets", []))
        self._status("Director", f"GDD ready: {n_ent} entities, {n_scr} scripts, {n_ast} assets")
        self._log_trace("director", "gdd_created", {"entities": n_ent, "scripts": n_scr, "assets": n_ast})
        return self.gdd

    # ── Phase 2: Engine Operator sets up world ──

    def run_engine_operator(self) -> None:
        """Engine Operator creates level, terrain, lighting, and all entities."""
        from openartemis.agent.o3de_tools import O3DE_TOOL_SCHEMAS, execute_o3de_tool

        self._status("Engine Operator", "Setting up game world...")
        self._log_trace("engine_operator", "start")

        gdd = self.gdd
        level = gdd.get("level", {})

        # Build task list as user message
        tasks = []
        tasks.append(f"1. Create level '{level.get('name', 'Main')}' with terrain={'terrain' in str(level.get('terrain', False)).lower()} size={level.get('terrain_size', 512)}")

        lighting = level.get("lighting", "bright")
        if lighting == "dark":
            tasks.append("2. Set up dark lighting: dim point lights only, no directional light, dark atmosphere")
        elif lighting == "dramatic":
            tasks.append("2. Set up dramatic lighting: strong directional light with warm color, high contrast")
        else:
            tasks.append("2. Set up bright lighting: directional light (sun), skybox, ambient")

        if level.get("terrain"):
            tasks.append(f"3. Create terrain: size={level.get('terrain_size', 512)}, height_scale={level.get('height_scale', 20.0)}")

        for i, ent in enumerate(gdd.get("entities", []), start=4):
            comps = ", ".join(ent.get("components", []))
            pos = ent.get("position", [0, 0, 0])
            parent = ent.get("parent")
            parent_str = f", parent={parent}" if parent else ""
            tasks.append(f"{i}. Create entity '{ent['name']}' with components [{comps}] at position {pos}{parent_str}")

        tasks.append(f"{len(tasks)+1}. Save level")

        task_text = "\n".join(tasks)
        user_msg = f"Execute these tasks using O3DE tools:\n\n{task_text}"

        # Filter tools to engine-relevant ones
        engine_tools = [t for t in O3DE_TOOL_SCHEMAS if t["function"]["name"] in (
            "o3de_create_level", "o3de_setup_lighting", "o3de_create_entity",
            "o3de_add_component", "o3de_set_property", "o3de_create_terrain",
            "o3de_save_level", "o3de_import_asset", "o3de_set_material",
        )]

        def on_tool(msg: str):
            self._status("Engine Operator", msg)
            if "o3de_create_entity" in msg:
                parts = msg.split("name=")
                if len(parts) > 1:
                    ename = parts[1].split(",")[0].strip("'\")")
                    self.entities_created.append(ename)

        _call_agent(
            system_prompt=ENGINE_OPERATOR_PROMPT,
            user_message=user_msg,
            tools=engine_tools,
            tool_executor=lambda n, a: execute_o3de_tool(n, a),
            on_status=on_tool,
            max_turns=20,
            model=self.model,
        )

        self._log_trace("engine_operator", "done", {"entities": len(self.entities_created)})
        self._status("Engine Operator", f"World built: {len(self.entities_created)} entities")

    # ── Phase 3: Asset Artist generates textures ──

    def run_asset_artist(self) -> None:
        """Asset Artist generates all textures and materials."""
        from openartemis.agent.o3de_tools import O3DE_TOOL_SCHEMAS, execute_o3de_tool

        assets = self.gdd.get("assets", [])
        if not assets:
            self._status("Asset Artist", "No assets required, skipping")
            return

        self._status("Asset Artist", f"Generating {len(assets)} textures...")
        self._log_trace("asset_artist", "start", {"count": len(assets)})

        # Build task
        asset_lines = [f"- {a['description']} → {a['path']}" for a in assets]
        user_msg = f"Generate these game textures:\n\n" + "\n".join(asset_lines)

        asset_tools = [t for t in O3DE_TOOL_SCHEMAS if t["function"]["name"] in (
            "o3de_import_asset", "o3de_set_material",
        )]
        # Add generate_image tool
        asset_tools.append({
            "type": "function",
            "function": {
                "name": "generate_image",
                "description": "Generate an image from a text description and save to path",
                "parameters": {
                    "type": "object",
                    "properties": {
                        "description": {"type": "string", "description": "Detailed image prompt"},
                        "path": {"type": "string", "description": "File path (e.g. assets/texture.png)"},
                    },
                    "required": ["description", "path"],
                },
            },
        })

        def _exec_asset_tool(name: str, args: dict) -> str:
            if name == "generate_image":
                try:
                    from openartemis.agent.agent_tools import generate_image
                    result = generate_image(args.get("description", ""), args.get("path", ""))
                    self.assets_generated.append(args.get("path", "unknown"))
                    return result
                except Exception as e:
                    return f"Error: {e}"
            return execute_o3de_tool(name, args)

        _call_agent(
            system_prompt=ASSET_ARTIST_PROMPT,
            user_message=user_msg,
            tools=asset_tools,
            tool_executor=_exec_asset_tool,
            on_status=lambda m: self._status("Asset Artist", m),
            max_turns=len(assets) + 5,
            model=self.model,
        )

        self._log_trace("asset_artist", "done", {"generated": len(self.assets_generated)})
        self._status("Asset Artist", f"Generated {len(self.assets_generated)} assets")

    # ── Phase 4: Gameplay Dev writes scripts ──

    def run_gameplay_dev(self) -> None:
        """Gameplay Dev writes all Lua scripts."""
        from openartemis.agent.o3de_tools import O3DE_TOOL_SCHEMAS, execute_o3de_tool

        scripts = self.gdd.get("scripts", [])
        if not scripts:
            self._status("Gameplay Dev", "No scripts required, skipping")
            return

        self._status("Gameplay Dev", f"Writing {len(scripts)} scripts...")
        self._log_trace("gameplay_dev", "start", {"count": len(scripts)})

        blueprint_scripts = self._blueprint.get("required_scripts", {})

        # For scripts with templates, write them directly (faster, more reliable)
        written_directly = 0
        for script_def in scripts:
            sname = script_def.get("name", "")
            if script_def.get("use_template") and sname in blueprint_scripts:
                template = blueprint_scripts[sname].get("template", "")
                if template:
                    try:
                        result = execute_o3de_tool("o3de_write_script", {
                            "name": sname,
                            "content": template,
                            "script_type": blueprint_scripts[sname].get("type", "lua"),
                        })
                        self.scripts_written.append(sname)
                        self.lines_coded += template.count("\n") + 1
                        written_directly += 1
                        self._status("Gameplay Dev", f"Wrote {sname} ({template.count(chr(10))+1} lines)")
                    except Exception as e:
                        self._status("Gameplay Dev", f"Error writing {sname}: {e}")

        # For remaining scripts (no template), use the LLM
        remaining = [s for s in scripts if s.get("name") not in self.scripts_written]
        if remaining:
            script_desc = "\n".join(f"- {s['name']}: {s.get('description', 'game script')}" for s in remaining)
            user_msg = f"Write these Lua scripts for O3DE:\n\n{script_desc}"

            script_tools = [t for t in O3DE_TOOL_SCHEMAS if t["function"]["name"] in (
                "o3de_write_script", "o3de_run_editor_script",
            )]

            def on_script_tool(msg: str):
                self._status("Gameplay Dev", msg)
                if "o3de_write_script" in msg:
                    parts = msg.split("name=")
                    if len(parts) > 1:
                        sn = parts[1].split(",")[0].strip("'\")")
                        self.scripts_written.append(sn)
                    # Estimate lines from content
                    content_parts = msg.split("content=")
                    if len(content_parts) > 1:
                        self.lines_coded += content_parts[1].count("\\n") + 1

            _call_agent(
                system_prompt=GAMEPLAY_DEV_PROMPT,
                user_message=user_msg,
                tools=script_tools,
                tool_executor=lambda n, a: execute_o3de_tool(n, a),
                on_status=on_script_tool,
                max_turns=len(remaining) * 2 + 5,
                model=self.model,
            )

        self._log_trace("gameplay_dev", "done", {
            "written_from_template": written_directly,
            "written_by_llm": len(self.scripts_written) - written_directly,
            "total_lines": self.lines_coded,
        })
        self._status("Gameplay Dev", f"Wrote {len(self.scripts_written)} scripts ({self.lines_coded} lines)")

    # ── Phase 5: QA Tester ──

    def run_qa_tester(self) -> Dict[str, Any]:
        """QA Tester verifies the game builds and checks criteria."""
        from openartemis.agent.o3de_tools import O3DE_TOOL_SCHEMAS, execute_o3de_tool

        self._status("QA Tester", "Running quality checks...")
        self._log_trace("qa_tester", "start")

        test_criteria = self.gdd.get("test_criteria", [])
        criteria_text = "\n".join(f"- {c}" for c in test_criteria)

        user_msg = f"""Verify this O3DE game project.

Expected entities: {', '.join(e['name'] for e in self.gdd.get('entities', []))}
Expected scripts: {', '.join(s['name'] for s in self.gdd.get('scripts', []))}

Test criteria:
{criteria_text}

Steps:
1. Call o3de_project_info() to check what exists
2. Call o3de_build_game() to compile
3. Report results as JSON"""

        qa_tools = [t for t in O3DE_TOOL_SCHEMAS if t["function"]["name"] in (
            "o3de_project_info", "o3de_build_game", "o3de_save_level",
        )]

        result = _call_agent(
            system_prompt=QA_TESTER_PROMPT,
            user_message=user_msg,
            tools=qa_tools,
            tool_executor=lambda n, a: execute_o3de_tool(n, a),
            on_status=lambda m: self._status("QA Tester", m),
            max_turns=5,
            model=self.model,
        )

        # Parse QA report
        try:
            if "```" in result:
                json_str = result.split("```")[1]
                if json_str.startswith("json"):
                    json_str = json_str[4:]
                self.qa_report = json.loads(json_str.strip())
            else:
                self.qa_report = json.loads(result.strip())
        except (json.JSONDecodeError, IndexError):
            self.qa_report = {
                "build_success": "error" not in result.lower(),
                "errors": [],
                "overall": "PASS" if "error" not in result.lower() else "FAIL",
                "raw": result[:500],
            }

        status = self.qa_report.get("overall", "UNKNOWN")
        self._log_trace("qa_tester", "done", {"status": status})
        self._status("QA Tester", f"QA result: {status}")
        return self.qa_report

    # ── Fix Cycle ──

    def run_fix_cycle(self, issues: List[str]) -> None:
        """Director assigns fixes based on QA issues."""
        from openartemis.agent.o3de_tools import O3DE_TOOL_SCHEMAS, execute_o3de_tool

        self._status("Director", f"Fixing {len(issues)} issues...")
        self._log_trace("director", "fix_cycle", {"issues": issues[:5]})

        # Categorize issues
        script_issues = [i for i in issues if any(kw in i.lower() for kw in ["script", "lua", "function", "nil"])]
        entity_issues = [i for i in issues if any(kw in i.lower() for kw in ["entity", "component", "missing entity"])]
        asset_issues = [i for i in issues if any(kw in i.lower() for kw in ["texture", "material", "asset", "image"])]
        build_issues = [i for i in issues if i not in script_issues + entity_issues + asset_issues]

        all_tools = O3DE_TOOL_SCHEMAS

        if script_issues:
            self._status("Gameplay Dev", f"Fixing {len(script_issues)} script issues")
            fix_msg = "Fix these script issues:\n" + "\n".join(f"- {i}" for i in script_issues)
            _call_agent(
                system_prompt=GAMEPLAY_DEV_PROMPT,
                user_message=fix_msg,
                tools=[t for t in all_tools if "script" in t["function"]["name"]],
                tool_executor=lambda n, a: execute_o3de_tool(n, a),
                on_status=lambda m: self._status("Gameplay Dev", m),
                max_turns=10,
                model=self.model,
            )

        if entity_issues:
            self._status("Engine Operator", f"Fixing {len(entity_issues)} entity issues")
            fix_msg = "Fix these entity/component issues:\n" + "\n".join(f"- {i}" for i in entity_issues)
            _call_agent(
                system_prompt=ENGINE_OPERATOR_PROMPT,
                user_message=fix_msg,
                tools=[t for t in all_tools if any(kw in t["function"]["name"] for kw in ["entity", "component", "level"])],
                tool_executor=lambda n, a: execute_o3de_tool(n, a),
                on_status=lambda m: self._status("Engine Operator", m),
                max_turns=10,
                model=self.model,
            )

    # ── Full Pipeline ──

    def run(self, user_prompt: str, max_fix_cycles: int = 3) -> Tuple[str, Dict[str, Any]]:
        """Run the full multi-agent pipeline. Returns (report_markdown, trace_data)."""
        self.start_time = time.time()

        # Phase 1: Director
        self._status("Director", "Phase 1/5: Creating Game Design Document...")
        gdd = self.run_director(user_prompt)

        # Phase 2: Engine Operator (world setup)
        self._status("Engine Operator", "Phase 2/5: Building game world...")
        self.run_engine_operator()

        # Phase 3: Asset Artist (textures — can run in parallel concept, sequential here)
        self._status("Asset Artist", "Phase 3/5: Generating art assets...")
        self.run_asset_artist()

        # Phase 4: Gameplay Dev (scripts)
        self._status("Gameplay Dev", "Phase 4/5: Writing gameplay scripts...")
        self.run_gameplay_dev()

        # Phase 5: QA + Fix loops
        self._status("QA Tester", "Phase 5/5: Testing and verification...")
        for cycle in range(max_fix_cycles):
            qa_report = self.run_qa_tester()
            if qa_report.get("overall") == "PASS":
                break
            issues = qa_report.get("errors", []) + qa_report.get("fix_suggestions", [])
            if not issues:
                break
            self._status("Director", f"Fix cycle {cycle + 1}/{max_fix_cycles}")
            self.run_fix_cycle(issues)

        # Generate final report
        elapsed = time.time() - self.start_time
        report = self._generate_report(user_prompt, elapsed)

        trace_data = {
            "prompt": user_prompt,
            "genre": self.gdd.get("genre", "unknown"),
            "gdd": self.gdd,
            "trace": self.trace,
            "build_success": self.qa_report.get("build_success", False),
            "fix_cycles": min(cycle + 1, max_fix_cycles) if 'cycle' in dir() else 0,
            "entities_created": len(self.entities_created),
            "scripts_written": len(self.scripts_written),
            "assets_generated": len(self.assets_generated),
            "total_lines": self.lines_coded,
            "elapsed_seconds": round(elapsed, 1),
        }

        # Save to repo index for future retrieval
        self._save_build_to_memory(trace_data)

        return report, trace_data

    def _generate_report(self, prompt: str, elapsed: float) -> str:
        """Generate a markdown summary report."""
        mins = int(elapsed) // 60
        secs = int(elapsed) % 60
        title = self.gdd.get("title", prompt[:50])
        genre = self.gdd.get("genre", "Unknown")
        qa_status = self.qa_report.get("overall", "N/A")

        lines = [
            f"# {title}",
            f"**Genre:** {genre} | **Time:** {mins}m {secs}s | **QA:** {qa_status}",
            "",
            "## Stats",
            f"- **Entities created:** {len(self.entities_created)}",
            f"- **Scripts written:** {len(self.scripts_written)} ({self.lines_coded} lines)",
            f"- **Assets generated:** {len(self.assets_generated)}",
            "",
        ]

        if self.entities_created:
            lines.append("## Entities")
            for e in self.entities_created:
                lines.append(f"- `{e}`")
            lines.append("")

        if self.scripts_written:
            lines.append("## Scripts")
            for s in self.scripts_written:
                lines.append(f"- `{s}`")
            lines.append("")

        if self.qa_report.get("errors"):
            lines.append("## Known Issues")
            for err in self.qa_report["errors"]:
                lines.append(f"- {err}")
            lines.append("")

        lines.append("## How to Run")
        lines.append(f"1. Open O3DE Editor with this project")
        lines.append(f"2. Load level: {self.gdd.get('level', {}).get('name', 'Main')}")
        lines.append(f"3. Press Ctrl+G to enter game mode")

        return "\n".join(lines)


# ═══════════════════════════════════════════════════
# PUBLIC API
# ═══════════════════════════════════════════════════

def run_game_studio(
    user_prompt: str,
    bridge: Any,
    on_status: Callable[[str], None] | None = None,
    model: str = "gpt-4.1",
    max_fix_cycles: int = 3,
) -> Tuple[str, Dict[str, Any]]:
    """Run the full multi-agent game studio pipeline.

    Args:
        user_prompt: User's game description
        bridge: O3DEBridge instance (project already created/opened)
        on_status: Callback for status updates (receives "[AgentName] message")
        model: LLM model to use
        max_fix_cycles: Max QA fix iterations

    Returns:
        (report_markdown, trace_data)
    """
    from openartemis.agent.o3de_tools import set_bridge
    set_bridge(bridge)

    # Point agent workspace at the project so generated assets land inside it
    if bridge.project_path:
        from openartemis.agent.agent_tools import set_agent_workspace
        set_agent_workspace(bridge.project_path)

    studio = GameStudio(bridge=bridge, on_status=on_status, model=model)
    return studio.run(user_prompt, max_fix_cycles=max_fix_cycles)
