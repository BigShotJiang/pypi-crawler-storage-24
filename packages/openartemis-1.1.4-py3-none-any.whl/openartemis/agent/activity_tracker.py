"""Activity tracker for E2B agent - provides real-time transparency into agent actions."""

import time
from collections import deque
from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Optional


class EventType(Enum):
    """Types of events the agent can perform."""
    FILE_WRITE = "file_write"
    FILE_READ = "file_read"
    FILE_EDIT = "file_edit"
    COMMAND_RUN = "command_run"
    SCREENSHOT = "screenshot"
    TEST_RUN = "test_run"
    DEPENDENCY_INSTALL = "dependency_install"
    SERVER_LAUNCH = "server_launch"
    ERROR_FIX = "error_fix"
    PHASE_CHANGE = "phase_change"
    HEARTBEAT = "heartbeat"


@dataclass
class ActivityEvent:
    """Represents a single agent activity event."""
    timestamp: str
    event_type: EventType
    description: str
    details: dict[str, Any] = field(default_factory=dict)
    status: str = "success"  # success, error, in_progress


@dataclass
class Artifacts:
    """Real-time artifact tracking."""
    files_created: int = 0
    files_modified: int = 0
    last_file: Optional[str] = None
    last_file_time: Optional[str] = None
    last_command: Optional[str] = None
    last_command_exit: Optional[int] = None
    last_command_time: Optional[str] = None
    last_test_result: Optional[str] = None
    last_test_time: Optional[str] = None
    last_screenshot: Optional[str] = None
    last_screenshot_time: Optional[str] = None
    total_commands: int = 0
    total_screenshots: int = 0
    total_tests: int = 0


class ActivityTracker:
    """Centralized activity tracking for E2B agent transparency."""
    
    def __init__(self, max_events: int = 100):
        self.max_events = max_events
        self.events: deque[ActivityEvent] = deque(maxlen=max_events)
        self.artifacts = Artifacts()
        self.sandbox_id: Optional[str] = None
        self.last_action_time: float = time.time()
        self.current_phase: str = "Starting"
        
    def set_sandbox_id(self, sandbox_id: str) -> None:
        """Set the E2B sandbox ID for tracking."""
        self.sandbox_id = sandbox_id
        
    def add_event(self, event_type: EventType, description: str, 
                 details: dict[str, Any] = None, status: str = "success") -> None:
        """Add a new activity event."""
        timestamp = time.strftime("%H:%M:%S")
        event = ActivityEvent(
            timestamp=timestamp,
            event_type=event_type,
            description=description,
            details=details or {},
            status=status
        )
        self.events.append(event)
        self.last_action_time = time.time()
        self._update_artifacts(event)
        
    def _update_artifacts(self, event: ActivityEvent) -> None:
        """Update artifact counters based on event type."""
        if event.event_type == EventType.FILE_WRITE:
            self.artifacts.files_created += 1
            self.artifacts.last_file = event.details.get("path", "unknown")
            self.artifacts.last_file_time = event.timestamp
        elif event.event_type == EventType.FILE_EDIT:
            self.artifacts.files_modified += 1
            self.artifacts.last_file = event.details.get("path", "unknown")
            self.artifacts.last_file_time = event.timestamp
        elif event.event_type == EventType.COMMAND_RUN:
            self.artifacts.total_commands += 1
            self.artifacts.last_command = event.description
            self.artifacts.last_command_exit = event.details.get("exit_code")
            self.artifacts.last_command_time = event.timestamp
        elif event.event_type == EventType.SCREENSHOT:
            self.artifacts.total_screenshots += 1
            self.artifacts.last_screenshot = event.description
            self.artifacts.last_screenshot_time = event.timestamp
        elif event.event_type == EventType.TEST_RUN:
            self.artifacts.total_tests += 1
            self.artifacts.last_test_result = event.description
            self.artifacts.last_test_time = event.timestamp
            
    def get_recent_events(self, count: int = 10) -> list[ActivityEvent]:
        """Get the most recent events."""
        return list(self.events)[-count:]
        
    def get_events_by_type(self, event_type: EventType) -> list[ActivityEvent]:
        """Get all events of a specific type."""
        return [e for e in self.events if e.event_type == event_type]
        
    def is_idle(self, threshold_seconds: int = 10) -> bool:
        """Check if the agent has been idle."""
        return time.time() - self.last_action_time > threshold_seconds
        
    def get_live_metrics(self) -> str:
        """Get a compact string of live metrics."""
        total_files = self.artifacts.files_created + self.artifacts.files_modified
        last_action = "idle"
        if self.events:
            last_action = self.events[-1].description.split("...")[0][:30]
        
        return (f"files: {total_files} • cmds: {self.artifacts.total_commands} • "
                f"tests: {self.artifacts.total_tests} • screenshots: {self.artifacts.total_screenshots} • "
                f"last: {last_action}")
                
    def get_idle_message(self) -> str:
        """Get an idle heartbeat message."""
        if self.current_phase.lower() in ["build", "building"]:
            return "Still working… currently writing files and setting up project"
        elif self.current_phase.lower() in ["verify", "verifying"]:
            return "Still working… currently verifying build output"
        elif self.current_phase.lower() in ["fix", "fixing"]:
            return "Still working… currently fixing issues found"
        elif self.current_phase.lower() in ["manifest"]:
            return "Still working… currently creating build manifest"
        else:
            return "Still working… processing current task"
