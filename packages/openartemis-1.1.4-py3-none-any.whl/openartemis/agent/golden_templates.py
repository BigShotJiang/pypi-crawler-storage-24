"""Golden Templates — proven, tested reference implementations.

The model gets the relevant template injected into its system prompt
as a reference to follow the same patterns, NOT to copy verbatim.
Each template is ~100-200 lines of working code.

Usage:
    from openartemis.agent.golden_templates import get_template
    code = get_template("flappy_bird")  # returns str or None
"""

from __future__ import annotations


def get_template(template_id: str | None) -> str | None:
    """Return the golden template source code for the given ID, or None."""
    if not template_id:
        return None
    return _TEMPLATES.get(template_id)


def get_template_prompt_block(template_id: str | None) -> str:
    """Return a formatted prompt block with the template, or empty string."""
    code = get_template(template_id)
    if not code:
        return ""
    return (
        f"=== REFERENCE IMPLEMENTATION ({template_id}) ===\n"
        "Adapt this working code to match the user's request.\n"
        "Do NOT copy verbatim — use the same patterns, physics, and structure.\n"
        f"```html\n{code}\n```\n"
        "=== END REFERENCE ==="
    )


# ═══════════════════════════════════════════════════════════════════════════════
# Templates
# ═══════════════════════════════════════════════════════════════════════════════

_FLAPPY_BIRD = """\
<!DOCTYPE html>
<html><head><meta charset="utf-8"><title>Flappy Bird</title>
<style>*{margin:0;padding:0}body{background:#222;display:flex;justify-content:center;align-items:center;height:100vh}canvas{border:2px solid #555;border-radius:8px}</style>
</head><body>
<canvas id="c" width="480" height="640"></canvas>
<script>
const canvas=document.getElementById('c'),ctx=canvas.getContext('2d');
const W=480,H=640,G=0.4,FLAP=-7,TERM=10,PIPE_W=60,GAP=160,PIPE_SPD=2,SPAWN=100,R=15;
let bird,pipes,score,frame,gameOver,started;
function reset(){bird={x:120,y:H/2,vy:0};pipes=[];score=0;frame=0;gameOver=false;started=false;}
reset();
function flap(){if(gameOver){reset();return;}if(!started)started=true;bird.vy=FLAP;}
document.addEventListener('keydown',e=>{if(e.code==='Space'){e.preventDefault();flap();}});
canvas.addEventListener('click',flap);
canvas.addEventListener('touchstart',e=>{e.preventDefault();flap();});
function update(){
  if(!started||gameOver)return;
  bird.vy=Math.min(bird.vy+G,TERM);bird.y+=bird.vy;
  if(bird.y-R<0)bird.y=R;
  if(bird.y+R>H){bird.y=H-R;gameOver=true;}
  if(frame%SPAWN===0){let gapY=100+Math.random()*(H-GAP-200);pipes.push({x:W,top:gapY,bot:gapY+GAP,scored:false});}
  frame++;
  for(let p of pipes){
    p.x-=PIPE_SPD;
    if(!p.scored&&p.x+PIPE_W<bird.x){p.scored=true;score++;}
    if(bird.x+R>p.x&&bird.x-R<p.x+PIPE_W){if(bird.y-R<p.top||bird.y+R>p.bot)gameOver=true;}
  }
  pipes=pipes.filter(p=>p.x+PIPE_W>0);
}
function draw(){
  ctx.fillStyle='#70c5ce';ctx.fillRect(0,0,W,H);
  // ground
  ctx.fillStyle='#ded895';ctx.fillRect(0,H-40,W,40);
  ctx.fillStyle='#5cb85c';ctx.fillRect(0,H-45,W,5);
  // pipes
  ctx.fillStyle='#5cb85c';
  for(let p of pipes){ctx.fillRect(p.x,0,PIPE_W,p.top);ctx.fillRect(p.x,p.bot,PIPE_W,H-p.bot);
    ctx.fillStyle='#4cae4c';ctx.fillRect(p.x-3,p.top-20,PIPE_W+6,20);ctx.fillRect(p.x-3,p.bot,PIPE_W+6,20);ctx.fillStyle='#5cb85c';}
  // bird
  ctx.fillStyle='#f5c542';ctx.beginPath();ctx.arc(bird.x,bird.y,R,0,Math.PI*2);ctx.fill();
  ctx.fillStyle='#e8a317';ctx.beginPath();ctx.arc(bird.x+5,bird.y-3,4,0,Math.PI*2);ctx.fill();
  ctx.fillStyle='#fff';ctx.beginPath();ctx.arc(bird.x+6,bird.y-5,5,0,Math.PI*2);ctx.fill();
  ctx.fillStyle='#333';ctx.beginPath();ctx.arc(bird.x+7,bird.y-5,2.5,0,Math.PI*2);ctx.fill();
  // score
  ctx.fillStyle='#fff';ctx.font='bold 48px sans-serif';ctx.textAlign='center';
  ctx.strokeStyle='#333';ctx.lineWidth=3;ctx.strokeText(score,W/2,70);ctx.fillText(score,W/2,70);
  if(!started){ctx.font='24px sans-serif';ctx.fillText('Click or Space to Start',W/2,H/2+60);}
  if(gameOver){ctx.fillStyle='rgba(0,0,0,0.5)';ctx.fillRect(0,0,W,H);
    ctx.fillStyle='#fff';ctx.font='bold 40px sans-serif';ctx.fillText('Game Over',W/2,H/2-30);
    ctx.font='24px sans-serif';ctx.fillText('Score: '+score,W/2,H/2+10);
    ctx.fillText('Click or Space to Restart',W/2,H/2+50);}
}
function loop(){update();draw();requestAnimationFrame(loop);}
loop();
</script></body></html>
"""

_SNAKE = """\
<!DOCTYPE html>
<html><head><meta charset="utf-8"><title>Snake</title>
<style>*{margin:0;padding:0}body{background:#222;display:flex;justify-content:center;align-items:center;height:100vh;flex-direction:column}canvas{border:2px solid #555;border-radius:8px}#score{color:#fff;font:bold 24px sans-serif;margin-bottom:10px}</style>
</head><body>
<div id="score">Score: 0</div>
<canvas id="c" width="400" height="400"></canvas>
<script>
const canvas=document.getElementById('c'),ctx=canvas.getContext('2d'),scoreEl=document.getElementById('score');
const GRID=20,COLS=20,ROWS=20,W=400,H=400,SPEED=150;
let snake,dir,food,score,gameOver,interval;
function reset(){
  snake=[{x:10,y:10},{x:9,y:10},{x:8,y:10}];dir={x:1,y:0};
  score=0;gameOver=false;placeFood();scoreEl.textContent='Score: 0';
  if(interval)clearInterval(interval);interval=setInterval(update,SPEED);
}
function placeFood(){
  do{food={x:Math.floor(Math.random()*COLS),y:Math.floor(Math.random()*ROWS)};}
  while(snake.some(s=>s.x===food.x&&s.y===food.y));
}
document.addEventListener('keydown',e=>{
  if(gameOver&&(e.code==='Space'||e.code==='Enter')){reset();return;}
  const k=e.key;
  if((k==='ArrowUp'||k==='w')&&dir.y!==1)dir={x:0,y:-1};
  else if((k==='ArrowDown'||k==='s')&&dir.y!==-1)dir={x:0,y:1};
  else if((k==='ArrowLeft'||k==='a')&&dir.x!==1)dir={x:-1,y:0};
  else if((k==='ArrowRight'||k==='d')&&dir.x!==-1)dir={x:1,y:0};
});
function update(){
  if(gameOver)return;
  const head={x:snake[0].x+dir.x,y:snake[0].y+dir.y};
  if(head.x<0||head.x>=COLS||head.y<0||head.y>=ROWS||snake.some(s=>s.x===head.x&&s.y===head.y)){gameOver=true;draw();return;}
  snake.unshift(head);
  if(head.x===food.x&&head.y===food.y){score++;scoreEl.textContent='Score: '+score;placeFood();}
  else snake.pop();
  draw();
}
function draw(){
  ctx.fillStyle='#1a1a2e';ctx.fillRect(0,0,W,H);
  // grid lines
  ctx.strokeStyle='#16213e';ctx.lineWidth=0.5;
  for(let i=0;i<COLS;i++){ctx.beginPath();ctx.moveTo(i*GRID,0);ctx.lineTo(i*GRID,H);ctx.stroke();}
  for(let i=0;i<ROWS;i++){ctx.beginPath();ctx.moveTo(0,i*GRID);ctx.lineTo(W,i*GRID);ctx.stroke();}
  // snake
  snake.forEach((s,i)=>{ctx.fillStyle=i===0?'#4ecca3':'#36b390';
    ctx.fillRect(s.x*GRID+1,s.y*GRID+1,GRID-2,GRID-2);
    ctx.fillStyle='#2d9c7a';ctx.fillRect(s.x*GRID+3,s.y*GRID+3,GRID-6,GRID-6);});
  // food
  ctx.fillStyle='#e23636';ctx.beginPath();ctx.arc(food.x*GRID+GRID/2,food.y*GRID+GRID/2,GRID/2-2,0,Math.PI*2);ctx.fill();
  ctx.fillStyle='#ff6b6b';ctx.beginPath();ctx.arc(food.x*GRID+GRID/2-2,food.y*GRID+GRID/2-2,3,0,Math.PI*2);ctx.fill();
  if(gameOver){ctx.fillStyle='rgba(0,0,0,0.6)';ctx.fillRect(0,0,W,H);
    ctx.fillStyle='#fff';ctx.font='bold 36px sans-serif';ctx.textAlign='center';
    ctx.fillText('Game Over',W/2,H/2-20);ctx.font='20px sans-serif';
    ctx.fillText('Score: '+score,W/2,H/2+15);ctx.fillText('Press Space to Restart',W/2,H/2+45);}
}
reset();
</script></body></html>
"""

_TODO_APP = """\
<!DOCTYPE html>
<html><head><meta charset="utf-8"><title>Todo App</title>
<style>
*{margin:0;padding:0;box-sizing:border-box}
body{font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,sans-serif;background:#f0f2f5;min-height:100vh;display:flex;justify-content:center;padding:40px 20px}
.app{width:100%;max-width:500px}
h1{text-align:center;color:#333;margin-bottom:24px;font-size:32px}
.input-row{display:flex;gap:8px;margin-bottom:24px}
.input-row input{flex:1;padding:12px 16px;border:2px solid #ddd;border-radius:8px;font-size:16px;outline:none;transition:border-color .2s}
.input-row input:focus{border-color:#5b7fff}
.input-row button{padding:12px 24px;background:#5b7fff;color:#fff;border:none;border-radius:8px;font-size:16px;cursor:pointer;transition:background .2s}
.input-row button:hover{background:#4a6cee}
.filters{display:flex;gap:8px;margin-bottom:16px;justify-content:center}
.filters button{padding:6px 16px;border:1px solid #ddd;background:#fff;border-radius:20px;cursor:pointer;font-size:14px;transition:all .2s}
.filters button.active{background:#5b7fff;color:#fff;border-color:#5b7fff}
.todo-list{list-style:none}
.todo-item{display:flex;align-items:center;gap:12px;padding:12px 16px;background:#fff;border-radius:8px;margin-bottom:8px;box-shadow:0 1px 3px rgba(0,0,0,.08);transition:transform .15s}
.todo-item:hover{transform:translateX(4px)}
.todo-item.done span{text-decoration:line-through;color:#aaa}
.todo-item input[type=checkbox]{width:20px;height:20px;cursor:pointer}
.todo-item span{flex:1;font-size:16px}
.todo-item .delete{background:none;border:none;color:#e74c3c;font-size:20px;cursor:pointer;opacity:0;transition:opacity .2s}
.todo-item:hover .delete{opacity:1}
.count{text-align:center;color:#888;margin-top:16px;font-size:14px}
</style></head><body>
<div class="app">
<h1>Todo App</h1>
<div class="input-row"><input id="inp" type="text" placeholder="What needs to be done?" autofocus><button onclick="addTodo()">Add</button></div>
<div class="filters"><button class="active" onclick="setFilter('all',this)">All</button><button onclick="setFilter('active',this)">Active</button><button onclick="setFilter('done',this)">Done</button></div>
<ul class="todo-list" id="list"></ul>
<div class="count" id="count"></div>
</div>
<script>
let todos=[],filter='all',nextId=1;
const inp=document.getElementById('inp'),list=document.getElementById('list'),countEl=document.getElementById('count');
inp.addEventListener('keydown',e=>{if(e.key==='Enter')addTodo();});
function addTodo(){const t=inp.value.trim();if(!t)return;todos.push({id:nextId++,text:t,done:false});inp.value='';render();}
function toggle(id){const t=todos.find(x=>x.id===id);if(t)t.done=!t.done;render();}
function remove(id){todos=todos.filter(x=>x.id!==id);render();}
function setFilter(f,btn){filter=f;document.querySelectorAll('.filters button').forEach(b=>b.classList.remove('active'));btn.classList.add('active');render();}
function render(){
  const vis=todos.filter(t=>filter==='all'?true:filter==='active'?!t.done:t.done);
  list.innerHTML=vis.map(t=>`<li class="todo-item ${t.done?'done':''}"><input type="checkbox" ${t.done?'checked':''} onchange="toggle(${t.id})"><span>${t.text}</span><button class="delete" onclick="remove(${t.id})">x</button></li>`).join('');
  const left=todos.filter(t=>!t.done).length;
  countEl.textContent=`${left} item${left!==1?'s':''} left`;
}
render();
</script></body></html>
"""

_LANDING_PAGE = """\
<!DOCTYPE html>
<html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Landing Page</title>
<style>
*{margin:0;padding:0;box-sizing:border-box}
body{font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,sans-serif;color:#333;line-height:1.6}
.hero{background:linear-gradient(135deg,#667eea 0%,#764ba2 100%);color:#fff;padding:100px 20px;text-align:center}
.hero h1{font-size:clamp(2rem,5vw,3.5rem);margin-bottom:16px}
.hero p{font-size:clamp(1rem,2.5vw,1.25rem);opacity:.9;max-width:600px;margin:0 auto 32px}
.btn{display:inline-block;padding:14px 32px;background:#fff;color:#667eea;font-weight:700;border-radius:8px;text-decoration:none;font-size:1.1rem;transition:transform .2s,box-shadow .2s}
.btn:hover{transform:translateY(-2px);box-shadow:0 8px 25px rgba(0,0,0,.15)}
.features{padding:80px 20px;max-width:1000px;margin:0 auto;display:grid;grid-template-columns:repeat(auto-fit,minmax(250px,1fr));gap:40px}
.feature{text-align:center;padding:24px}
.feature .icon{font-size:48px;margin-bottom:16px}
.feature h3{margin-bottom:8px;font-size:1.25rem}
.feature p{color:#666;font-size:.95rem}
.cta{background:#f8f9fa;padding:60px 20px;text-align:center}
.cta h2{margin-bottom:16px;font-size:clamp(1.5rem,3vw,2rem)}
.cta .btn{background:#667eea;color:#fff}
footer{background:#2d3436;color:#ddd;padding:30px 20px;text-align:center;font-size:.9rem}
</style></head><body>
<section class="hero">
<h1>Build Something Amazing</h1>
<p>A modern platform that helps you create, ship, and scale your ideas faster than ever before.</p>
<a href="#features" class="btn">Get Started Free</a>
</section>
<section class="features" id="features">
<div class="feature"><div class="icon">&#9889;</div><h3>Lightning Fast</h3><p>Optimized performance that keeps your users engaged and your bounce rate low.</p></div>
<div class="feature"><div class="icon">&#128274;</div><h3>Secure by Default</h3><p>Enterprise-grade security built in from day one. Your data is always safe.</p></div>
<div class="feature"><div class="icon">&#128640;</div><h3>Easy to Scale</h3><p>Grow from zero to millions of users without changing your architecture.</p></div>
</section>
<section class="cta">
<h2>Ready to get started?</h2>
<p style="color:#666;margin-bottom:24px">Join thousands of developers who are already building with us.</p>
<a href="#" class="btn">Start Building</a>
</section>
<footer>&copy; 2025 Company. All rights reserved.</footer>
</body></html>
"""


_PONG = """\
<!DOCTYPE html>
<html><head><meta charset="utf-8"><title>Pong</title>
<style>*{margin:0;padding:0}body{background:#111;display:flex;justify-content:center;align-items:center;height:100vh;flex-direction:column}canvas{border:2px solid #444;border-radius:4px}#info{color:#aaa;font:14px sans-serif;margin-top:10px}</style>
</head><body>
<canvas id="c" width="640" height="480"></canvas>
<div id="info">W/S = Left Paddle | Up/Down = Right Paddle | Space = Start/Restart</div>
<script>
const canvas=document.getElementById('c'),ctx=canvas.getContext('2d');
const W=640,H=480,PAD_W=12,PAD_H=80,PAD_SPD=4,BALL_R=8,BALL_SPD=4;
let p1,p2,ball,score1,score2,playing;
const keys={};
function reset(){
  p1={x:20,y:H/2-PAD_H/2};p2={x:W-20-PAD_W,y:H/2-PAD_H/2};
  ball={x:W/2,y:H/2,vx:BALL_SPD*(Math.random()>.5?1:-1),vy:BALL_SPD*(Math.random()-.5)};
  score1=0;score2=0;playing=false;
}
function resetBall(dir){ball={x:W/2,y:H/2,vx:BALL_SPD*dir,vy:BALL_SPD*(Math.random()-.5)};}
reset();
document.addEventListener('keydown',e=>{keys[e.key]=true;if(e.code==='Space'){e.preventDefault();if(!playing)playing=true;}});
document.addEventListener('keyup',e=>{keys[e.key]=false;});
function update(){
  if(!playing)return;
  if(keys['w']||keys['W'])p1.y=Math.max(0,p1.y-PAD_SPD);
  if(keys['s']||keys['S'])p1.y=Math.min(H-PAD_H,p1.y+PAD_SPD);
  if(keys['ArrowUp'])p2.y=Math.max(0,p2.y-PAD_SPD);
  if(keys['ArrowDown'])p2.y=Math.min(H-PAD_H,p2.y+PAD_SPD);
  ball.x+=ball.vx;ball.y+=ball.vy;
  if(ball.y-BALL_R<=0||ball.y+BALL_R>=H)ball.vy*=-1;
  if(ball.x-BALL_R<=p1.x+PAD_W&&ball.y>=p1.y&&ball.y<=p1.y+PAD_H){ball.vx=Math.abs(ball.vx);ball.vy+=(ball.y-(p1.y+PAD_H/2))*0.1;}
  if(ball.x+BALL_R>=p2.x&&ball.y>=p2.y&&ball.y<=p2.y+PAD_H){ball.vx=-Math.abs(ball.vx);ball.vy+=(ball.y-(p2.y+PAD_H/2))*0.1;}
  if(ball.x<0){score2++;resetBall(1);}
  if(ball.x>W){score1++;resetBall(-1);}
}
function draw(){
  ctx.fillStyle='#111';ctx.fillRect(0,0,W,H);
  ctx.setLineDash([8,8]);ctx.strokeStyle='#333';ctx.lineWidth=2;
  ctx.beginPath();ctx.moveTo(W/2,0);ctx.lineTo(W/2,H);ctx.stroke();ctx.setLineDash([]);
  ctx.fillStyle='#4fc3f7';ctx.fillRect(p1.x,p1.y,PAD_W,PAD_H);
  ctx.fillStyle='#ef5350';ctx.fillRect(p2.x,p2.y,PAD_W,PAD_H);
  ctx.fillStyle='#fff';ctx.beginPath();ctx.arc(ball.x,ball.y,BALL_R,0,Math.PI*2);ctx.fill();
  ctx.font='bold 48px monospace';ctx.textAlign='center';ctx.fillStyle='#4fc3f7';ctx.fillText(score1,W/4,60);
  ctx.fillStyle='#ef5350';ctx.fillText(score2,3*W/4,60);
  if(!playing){ctx.fillStyle='#fff';ctx.font='20px sans-serif';ctx.fillText('Press Space to Start',W/2,H/2+60);}
}
function loop(){update();draw();requestAnimationFrame(loop);}
loop();
</script></body></html>
"""

_BREAKOUT = """\
<!DOCTYPE html>
<html><head><meta charset="utf-8"><title>Breakout</title>
<style>*{margin:0;padding:0}body{background:#1a1a2e;display:flex;justify-content:center;align-items:center;height:100vh}canvas{border:2px solid #444;border-radius:4px}</style>
</head><body>
<canvas id="c" width="480" height="640"></canvas>
<script>
const canvas=document.getElementById('c'),ctx=canvas.getContext('2d');
const W=480,H=640,COLS=8,ROWS=5,BW=50,BH=20,BPAD=6,BTOP=60;
const PAD_W=80,PAD_H=12,PAD_SPD=6;
let paddle,ball,bricks,score,lives,gameOver,started;
function makeBricks(){
  const b=[];const colors=['#e74c3c','#e67e22','#f1c40f','#2ecc71','#3498db'];
  for(let r=0;r<ROWS;r++)for(let c=0;c<COLS;c++){
    b.push({x:c*(BW+BPAD)+35,y:r*(BH+BPAD)+BTOP,w:BW,h:BH,alive:true,color:colors[r]});}
  return b;
}
function reset(){paddle={x:W/2-PAD_W/2,y:H-40};ball={x:W/2,y:H-60,vx:3,vy:-3};bricks=makeBricks();score=0;lives=3;gameOver=false;started=false;}
reset();
const keys={};
document.addEventListener('keydown',e=>{keys[e.key]=true;if(e.code==='Space'){e.preventDefault();if(gameOver)reset();else if(!started)started=true;}});
document.addEventListener('keyup',e=>{keys[e.key]=false;});
canvas.addEventListener('click',()=>{if(gameOver)reset();else if(!started)started=true;});
canvas.addEventListener('touchstart',e=>{e.preventDefault();if(gameOver)reset();else if(!started)started=true;});
canvas.addEventListener('mousemove',e=>{const r=canvas.getBoundingClientRect();paddle.x=Math.max(0,Math.min(W-PAD_W,(e.clientX-r.left)-PAD_W/2));});
function update(){
  if(!started||gameOver)return;
  if(keys['ArrowLeft']||keys['a'])paddle.x=Math.max(0,paddle.x-PAD_SPD);
  if(keys['ArrowRight']||keys['d'])paddle.x=Math.min(W-PAD_W,paddle.x+PAD_SPD);
  ball.x+=ball.vx;ball.y+=ball.vy;
  if(ball.x-6<=0||ball.x+6>=W)ball.vx*=-1;
  if(ball.y-6<=0)ball.vy*=-1;
  if(ball.y+6>=paddle.y&&ball.x>=paddle.x&&ball.x<=paddle.x+PAD_W){ball.vy=-Math.abs(ball.vy);ball.vx+=(ball.x-(paddle.x+PAD_W/2))*0.05;}
  if(ball.y>H){lives--;if(lives<=0)gameOver=true;else{ball={x:W/2,y:H-60,vx:3,vy:-3};started=false;}}
  for(let b of bricks){if(!b.alive)continue;if(ball.x+6>b.x&&ball.x-6<b.x+b.w&&ball.y+6>b.y&&ball.y-6<b.y+b.h){b.alive=false;ball.vy*=-1;score+=10;}}
  if(bricks.every(b=>!b.alive)){bricks=makeBricks();ball={x:W/2,y:H-60,vx:3,vy:-3};started=false;}
}
function draw(){
  ctx.fillStyle='#1a1a2e';ctx.fillRect(0,0,W,H);
  for(let b of bricks){if(!b.alive)continue;ctx.fillStyle=b.color;ctx.fillRect(b.x,b.y,b.w,b.h);
    ctx.fillStyle='rgba(255,255,255,0.2)';ctx.fillRect(b.x,b.y,b.w,b.h/3);}
  ctx.fillStyle='#ecf0f1';ctx.fillRect(paddle.x,paddle.y,PAD_W,PAD_H);
  ctx.fillStyle='#fff';ctx.beginPath();ctx.arc(ball.x,ball.y,6,0,Math.PI*2);ctx.fill();
  ctx.fillStyle='#fff';ctx.font='bold 20px sans-serif';ctx.textAlign='left';ctx.fillText('Score: '+score,15,30);
  ctx.textAlign='right';ctx.fillText('Lives: '+lives,W-15,30);
  if(!started&&!gameOver){ctx.textAlign='center';ctx.font='18px sans-serif';ctx.fillText('Click or Space to Launch',W/2,H/2+80);}
  if(gameOver){ctx.fillStyle='rgba(0,0,0,0.6)';ctx.fillRect(0,0,W,H);ctx.fillStyle='#fff';ctx.font='bold 36px sans-serif';ctx.textAlign='center';
    ctx.fillText('Game Over',W/2,H/2-20);ctx.font='20px sans-serif';ctx.fillText('Score: '+score,W/2,H/2+15);ctx.fillText('Click or Space to Restart',W/2,H/2+50);}
}
function loop(){update();draw();requestAnimationFrame(loop);}
loop();
</script></body></html>
"""

_CALCULATOR = """\
<!DOCTYPE html>
<html><head><meta charset="utf-8"><title>Calculator</title>
<style>
*{margin:0;padding:0;box-sizing:border-box}
body{font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,sans-serif;background:#1a1a2e;display:flex;justify-content:center;align-items:center;height:100vh}
.calc{background:#16213e;border-radius:16px;padding:24px;width:320px;box-shadow:0 20px 60px rgba(0,0,0,.4)}
.display{background:#0f3460;border-radius:12px;padding:16px 20px;margin-bottom:16px;text-align:right;min-height:80px;display:flex;flex-direction:column;justify-content:flex-end}
.display .prev{color:#888;font-size:14px;min-height:20px}
.display .curr{color:#fff;font-size:36px;font-weight:bold;word-break:break-all}
.buttons{display:grid;grid-template-columns:repeat(4,1fr);gap:10px}
.btn{padding:18px;border:none;border-radius:12px;font-size:20px;cursor:pointer;transition:all .15s;font-weight:500}
.btn:hover{transform:scale(1.05)}
.btn:active{transform:scale(0.95)}
.num{background:#1a1a3e;color:#fff}.num:hover{background:#2a2a5e}
.op{background:#e94560;color:#fff}.op:hover{background:#ff6b81}
.fn{background:#533483;color:#fff}.fn:hover{background:#6c44a2}
.eq{background:#00b4d8;color:#fff;grid-column:span 2}.eq:hover{background:#48cae4}
</style></head><body>
<div class="calc">
<div class="display"><div class="prev" id="prev"></div><div class="curr" id="curr">0</div></div>
<div class="buttons">
<button class="btn fn" onclick="clearAll()">C</button><button class="btn fn" onclick="toggleSign()">+/-</button><button class="btn fn" onclick="percent()">%</button><button class="btn op" onclick="setOp('/')">÷</button>
<button class="btn num" onclick="digit('7')">7</button><button class="btn num" onclick="digit('8')">8</button><button class="btn num" onclick="digit('9')">9</button><button class="btn op" onclick="setOp('*')">×</button>
<button class="btn num" onclick="digit('4')">4</button><button class="btn num" onclick="digit('5')">5</button><button class="btn num" onclick="digit('6')">6</button><button class="btn op" onclick="setOp('-')">−</button>
<button class="btn num" onclick="digit('1')">1</button><button class="btn num" onclick="digit('2')">2</button><button class="btn num" onclick="digit('3')">3</button><button class="btn op" onclick="setOp('+')">+</button>
<button class="btn num" onclick="digit('0')" style="grid-column:span 2">0</button><button class="btn num" onclick="decimal()">.</button><button class="btn op" onclick="calculate()">=</button>
</div></div>
<script>
let curr='0',prev='',op='',resetNext=false;
const currEl=document.getElementById('curr'),prevEl=document.getElementById('prev');
function update(){currEl.textContent=curr;prevEl.textContent=prev?prev+' '+{'/':'÷','*':'×','-':'−','+':'+'}[op]||op:'';}
function digit(d){if(curr==='0'||resetNext){curr=d;resetNext=false;}else if(curr.length<12)curr+=d;update();}
function decimal(){if(resetNext){curr='0.';resetNext=false;}else if(!curr.includes('.'))curr+='.';update();}
function clearAll(){curr='0';prev='';op='';resetNext=false;update();}
function toggleSign(){if(curr!=='0')curr=curr.startsWith('-')?curr.slice(1):'-'+curr;update();}
function percent(){curr=String(parseFloat(curr)/100);update();}
function setOp(o){if(prev&&!resetNext)calculate();prev=curr;op=o;resetNext=true;update();}
function calculate(){if(!prev||!op)return;const a=parseFloat(prev),b=parseFloat(curr);
  let r;if(op==='+')r=a+b;else if(op==='-')r=a-b;else if(op==='*')r=a*b;else if(op==='/'){if(b===0){curr='Error';prev='';op='';update();return;}r=a/b;}
  curr=String(Math.round(r*1e10)/1e10);prev='';op='';resetNext=true;update();}
document.addEventListener('keydown',e=>{const k=e.key;if(k>='0'&&k<='9')digit(k);else if(k==='.')decimal();else if(k==='+')setOp('+');else if(k==='-')setOp('-');else if(k==='*')setOp('*');else if(k==='/')setOp('/');else if(k==='Enter'||k==='=')calculate();else if(k==='Escape'||k==='c')clearAll();else if(k==='Backspace'){curr=curr.length>1?curr.slice(0,-1):'0';update();}});
update();
</script></body></html>
"""

_CHAT_UI = """\
<!DOCTYPE html>
<html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Chat</title>
<style>
*{margin:0;padding:0;box-sizing:border-box}
body{font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,sans-serif;background:#f0f2f5;height:100vh;display:flex;flex-direction:column}
.header{background:#075e54;color:#fff;padding:12px 20px;display:flex;align-items:center;gap:12px}
.header .avatar{width:40px;height:40px;border-radius:50%;background:#128c7e;display:flex;align-items:center;justify-content:center;font-size:18px}
.header h2{font-size:18px;font-weight:600}
.header .status{font-size:12px;opacity:.7}
.messages{flex:1;overflow-y:auto;padding:20px;display:flex;flex-direction:column;gap:8px}
.msg{max-width:75%;padding:8px 14px;border-radius:12px;font-size:15px;line-height:1.4;position:relative;word-wrap:break-word}
.msg .time{font-size:11px;opacity:.5;margin-top:4px;text-align:right}
.msg.sent{background:#dcf8c6;align-self:flex-end;border-bottom-right-radius:4px}
.msg.recv{background:#fff;align-self:flex-start;border-bottom-left-radius:4px;box-shadow:0 1px 2px rgba(0,0,0,.08)}
.input-area{background:#f0f2f5;padding:10px 16px;display:flex;gap:10px;align-items:center;border-top:1px solid #ddd}
.input-area input{flex:1;padding:10px 16px;border:none;border-radius:24px;font-size:15px;outline:none;background:#fff}
.input-area button{width:44px;height:44px;border-radius:50%;border:none;background:#075e54;color:#fff;font-size:20px;cursor:pointer;display:flex;align-items:center;justify-content:center;transition:background .2s}
.input-area button:hover{background:#128c7e}
.typing{align-self:flex-start;background:#fff;padding:8px 14px;border-radius:12px;font-size:14px;color:#888;display:none;box-shadow:0 1px 2px rgba(0,0,0,.08)}
</style></head><body>
<div class="header"><div class="avatar">A</div><div><h2>Artemis</h2><div class="status">online</div></div></div>
<div class="messages" id="msgs"><div class="msg recv">Hey there! How can I help you today?<div class="time">now</div></div></div>
<div class="typing" id="typing">Artemis is typing...</div>
<div class="input-area"><input id="inp" type="text" placeholder="Type a message..." autofocus><button onclick="send()">&#10148;</button></div>
<script>
const msgs=document.getElementById('msgs'),inp=document.getElementById('inp'),typing=document.getElementById('typing');
const replies=['That sounds interesting!','Tell me more about that.','I see what you mean.','Great question! Let me think...','Sure, I can help with that!','Interesting perspective!','Got it, anything else?'];
inp.addEventListener('keydown',e=>{if(e.key==='Enter')send();});
function addMsg(text,type){
  const d=document.createElement('div');d.className='msg '+type;
  const t=new Date();const ts=t.getHours().toString().padStart(2,'0')+':'+t.getMinutes().toString().padStart(2,'0');
  d.innerHTML=text+'<div class="time">'+ts+'</div>';
  msgs.appendChild(d);msgs.scrollTop=msgs.scrollHeight;
}
function send(){const t=inp.value.trim();if(!t)return;addMsg(t,'sent');inp.value='';
  typing.style.display='block';msgs.scrollTop=msgs.scrollHeight;
  setTimeout(()=>{typing.style.display='none';addMsg(replies[Math.floor(Math.random()*replies.length)],'recv');},800+Math.random()*1200);}
</script></body></html>
"""

_TEMPLATES: dict[str, str] = {
    "flappy_bird": _FLAPPY_BIRD,
    "snake": _SNAKE,
    "pong": _PONG,
    "breakout": _BREAKOUT,
    "todo_app": _TODO_APP,
    "landing_page": _LANDING_PAGE,
    "calculator": _CALCULATOR,
    "chat_ui": _CHAT_UI,
}
