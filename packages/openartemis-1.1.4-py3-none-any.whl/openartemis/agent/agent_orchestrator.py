"""Agent orchestrator — lead model plans, worker executes with workspace tools."""

import json
import os
import threading
import time
from datetime import datetime
import re
from pathlib import Path
from typing import Any, Callable, Tuple

from dotenv import load_dotenv
from openartemis.config import get_anthropic_client as _get_openai_client

load_dotenv(Path(__file__).resolve().parents[2] / ".env")

from openartemis.agent.agent_tools import (
    clear_undo_stack,
    execute_agent_tool,
    get_agent_workspace,
    get_all_agent_tools,
    set_agent_container_id,
    set_terminal_log_path,
)
from openartemis.agent.sandbox import (
    create_job_container,
    destroy_job_container,
    is_sandbox_enabled,
)
from openartemis.agent.audit_log import (
    log_audit,
    log_phase,
    log_tool,
    replay_path_for,
)
from openartemis.agent.rl_bot import customize_for_task
from openartemis.config import (
    DEFAULT_BASE_MODEL,
    agent_clarify_and_prd_enabled,
    agent_reviewer_enabled,
    get_build_model,
    get_exec_model,
    get_max_tokens_full_file,
    get_max_tokens_or_default,
    get_max_turns_per_step,
    get_permission_mode,
    get_plan_model,
    resolve_artemis_model,
)
from openartemis.hooks import fire as hooks_fire
from openartemis.errors import ErrorType, classify_exception
from openartemis.retry import get_retry_after_seconds
from openartemis.token_budget import (
    create_with_budget,
    estimate_request_tokens,
    set_retry_after as token_budget_set_retry_after,
)
from openartemis.token_budget import MAX_INPUT_TOKENS_PER_CALL
from openartemis.oa_context import append_oa_event, ensure_artemiscontext, load_oa_summary

FALLBACK_MODEL = DEFAULT_BASE_MODEL


def _extract_json_object(text: str) -> dict | None:
    """Robustly extract a JSON object from model output.

    Handles: raw JSON, ```json fences (even with preamble), and bare { ... }
    buried inside prose.  Returns the parsed dict or None on failure.
    """
    if not text or not text.strip():
        return None

    text = text.strip()

    # 1) Try direct parse first (ideal case — model returned pure JSON).
    try:
        data = json.loads(text)
        if isinstance(data, dict):
            return data
    except (json.JSONDecodeError, ValueError):
        pass

    # 2) Strip markdown code fences (```json ... ``` or ``` ... ```).
    #    The fence may not be at the very start of the response.
    fence_pattern = re.compile(r"```(?:json)?\s*\n([\s\S]*?)\n\s*```", re.IGNORECASE)
    m = fence_pattern.search(text)
    if m:
        try:
            data = json.loads(m.group(1).strip())
            if isinstance(data, dict):
                return data
        except (json.JSONDecodeError, ValueError):
            pass

    # 3) Find the outermost { ... } and try to parse that.
    first_brace = text.find("{")
    last_brace = text.rfind("}")
    if first_brace != -1 and last_brace > first_brace:
        candidate = text[first_brace : last_brace + 1]
        try:
            data = json.loads(candidate)
            if isinstance(data, dict):
                return data
        except (json.JSONDecodeError, ValueError):
            pass

    return None

IDENTITY_LEAD = "You are the planning agent for OpenArtemis (Autonomous Development Runtime). "
IDENTITY_WORKER = "You are the execution agent for OpenArtemis (Autonomous Development Runtime). "

AGENT_OS_SYSTEM = """You are the OpenArtemis Agent OS. You receive ONE prompt and deliver a COMPLETE, WORKING project. You operate in phases — follow them strictly.

═══ PHASE 1: BUILD (your FIRST response) ═══
Write ALL project files NOW using write_file. Multiple write_file calls in one response.
- Do NOT plan in text. Do NOT ask questions. Do NOT read files (workspace is empty). JUST WRITE CODE.
- Every file must be COMPLETE. No placeholders, no TODOs, no stubs.
- Choose the SIMPLEST stack that works. One file is better than five.

═══ PHASE 2: VERIFY (your SECOND response) ═══
After writing files, verify the project works:
- For web/games: run_terminal to start a server, then take_screenshot with this EXACT prompt:
  "Is this working? Answer YES or NO for each: (1) Visible game/UI elements rendered? (2) Player can interact (click/tap/spacebar)? (3) Score or key UI visible? List any bugs."
- For scripts: run_terminal to execute, check output.
- For libraries: run_terminal to run tests.
After the screenshot, you MUST answer all 3 questions yourself. If ANY answer is NO → go to Phase 3.

═══ PHASE 3: FIX (if verification finds problems) ═══
If screenshot or test output shows issues:
- Diagnose from the error/screenshot feedback.
- Fix with search_replace (small edits) or write_file (rewrites).
- Re-verify after fixing. Repeat until all 3 verify questions are YES or you've tried 3 fixes.

═══ PHASE 4: REPORT (your FINAL response — no tool calls) ═══
When everything works (all 3 verify questions = YES), respond with a brief summary (no tool calls):
- What was built
- Key files created
- How to run it

═══ TOOLS ═══
- write_file(path, content) — create/overwrite file. Call MULTIPLE TIMES in one response.
- read_file(path) — read existing file
- list_dir(path) — list directory ("." for workspace root)
- search_in_files(query, path, max_results) — search text in workspace
- run_terminal(command) — run shell command. Servers: Windows "start /B cmd", Unix "cmd &"
- take_screenshot(url_or_path, prompt) — capture URL/file + vision assessment. USE THIS TO VERIFY.
- generate_image(description, path) — AI-generate image (sprites, backgrounds, logos)
- search_replace(path, old_string, new_string) — find-and-replace in file
- apply_patch(path, patch_content) — apply unified diff
- get_secret(key) — get API key from vault

═══ PROJECT PATTERNS ═══
- Game (Flappy Bird, Snake, Pong, etc.): Single index.html with <style> + <script>. Canvas API. Must include: game loop (requestAnimationFrame), input (keyboard/mouse/touch), physics, collision, scoring, game over + restart. Colorful, smooth 60fps.
- Web app: Single index.html or index.html + style.css + app.js. Clean, responsive.
- Python script: main.py. Add requirements.txt only if external packages needed.
- Multi-file project: Keep it minimal. One clear entrypoint.

═══ GAME PHYSICS CONSTANTS (use these exactly — do not guess) ═══
These are proven values for smooth, fun gameplay at 60fps (requestAnimationFrame):
- Gravity: velocityY += 0.4 each frame (NOT 0.5 or 1.0 — 0.4 feels natural)
- Flap / jump strength: velocityY = -7 (negative = upward)
- Terminal velocity (max fall speed): velocityY = Math.min(velocityY, 10)
- Pipe / obstacle speed: 2px per frame (NOT 3+, too fast)
- Pipe gap height: 160px (NOT less — playable gap)
- Pipe width: 60px
- Pipe spawn interval: 100 frames
- Bird / player radius: 15px
- Snake speed: move every 150ms
- Pong paddle speed: 4px per key event
- Breakout ball speed: {x: 3, y: -3} initial
APPLY THESE. Do not use different values unless the request explicitly asks for hard mode.

═══ GAME QUALITY CHECKLIST (must ALL pass before Phase 4) ═══
[ ] Physics feel correct — not too fast, not too slow (use constants above)
[ ] Spacebar AND mouse click AND touch (touchstart) all trigger the same action
[ ] Score counter visible and increments correctly
[ ] Game over screen shows final score and "Click to restart" or "Press Space to restart"
[ ] Restart actually resets all state (score, positions, velocities)
[ ] Canvas fills the viewport or has a sensible fixed size (e.g. 480x640)
[ ] No JavaScript errors (check by reading the code — avoid undefined variables)
[ ] Background and at least basic colors — not a blank white canvas

═══ WEB APP QUALITY CHECKLIST ═══
[ ] Layout looks correct at 1280px wide
[ ] All buttons/links are clickable and do something
[ ] Forms validate input before submitting
[ ] No broken images or missing styles
[ ] Responsive — does not overflow on mobile widths

═══ QUALITY RULES ═══
- Code must be CORRECT and COMPLETE. Working > fast. Working > elegant.
- ALL: consistent style, minimal comments (only non-obvious logic)
- NEVER ship a game where the bird/character falls off screen in under 2 seconds with no input
- NEVER ship a blank canvas or a canvas with only a background color and no game elements

═══ IMPORTANT ═══
Your FIRST response should contain ONLY tool calls (write_file, etc). No planning text.
After build + verify + fix, your LAST response is a text summary with NO tool calls.
The user will never respond — you run autonomously until done."""

LEAD_SYSTEM = """You are the planning agent for OpenArtemis (Autonomous Development Runtime). You are a coding lead. Given a user request, create a step-by-step plan to build it.

First commit to ONE stack (e.g. "Vanilla Canvas in a single index.html", "Phaser 3 + Vite", "Pygame"). Do not list alternatives.

IMPORTANT: When user asks for "AI chat UI", they mean a chat interface that connects to an AI API (like OpenAI). This includes:
- Message history display (user and AI messages, different styling)
- Input field with send button
- API integration to send messages to AI and display responses
- Typing indicators and loading states
- Error handling for API failures
- Do NOT create a simple messaging/chat app without AI integration

Output a JSON object:
{"stack": "your chosen stack in one short sentence", "steps": [
  {"id": 1, "action": "description of what to do", "file": "exact filename e.g. index.html or game.js"},
  ...
], "images": [
  {"id": "short-id", "description": "detailed image prompt", "path": "assets/filename.png"},
  ...
]}

- "images" is optional. Include it when the project needs art: backgrounds, sprites, characters, logos. Each entry has id (short id for steps to reference), description (prompt for AI image generation), path (workspace path e.g. assets/background.png). Add steps that say "Generate image X" and "Use assets/X in the game".
- Choose exactly one stack and state it. No "either X or Y".
- Every step that creates or edits a file must include "file" with the exact filename (e.g. index.html, style.css, game.js).
- For a single-file stack (e.g. "single index.html", one HTML file): use fewer, chunkier steps (about 5-15). Each step can describe a full coherent piece (e.g. "Implement full game loop: bird, gravity, pipes, collision, score, game over and restart in index.html"). The worker can output the whole file or large sections.
- For multi-file projects: break into small, concrete steps; each step is one file write or one command.
- For web apps: create index.html, add JS/CSS as needed, then run server. Name every file.
- Max 50 steps. Output ONLY valid JSON, no markdown."""

# ── O3DE-specific system prompts ──

O3DE_LEAD_SYSTEM = """You are the planning agent for OpenArtemis AAA Game Development using Open 3D Engine (O3DE). You create step-by-step plans to build 3D games.

You have access to the O3DE engine via Python automation (azlmbr APIs). You control entities, components, materials, physics, lighting, terrain, and gameplay scripts.

Output a JSON object:
{"stack": "O3DE (Open 3D Engine) — AAA 3D game", "steps": [
  {"id": 1, "action": "description of what to do", "tool": "o3de tool name"},
  ...
]}

═══ O3DE ENTITY-COMPONENT MODEL ═══
Everything in O3DE is an Entity with Components:
- Entity = a game object (player, enemy, tree, light, camera)
- Component = behavior/data attached to entity (Transform, Mesh, Light, PhysX Rigid Body, Script)

═══ COMMON COMPONENTS ═══
- Transform — position, rotation, scale (every entity has this)
- Mesh — 3D model rendering
- Directional Light / Point Light / Spot Light / Area Light — lighting
- Camera — viewport/player camera
- PhysX Dynamic Rigid Body — physics-simulated object
- PhysX Static Rigid Body — immovable physics object
- PhysX Box/Sphere/Capsule/Mesh Collider — collision shapes
- Lua Script — gameplay logic
- Script Canvas — visual scripting
- Audio Trigger — sound effects
- Particle Emitter — particles/VFX
- HDRi Skybox — sky rendering
- Global Skylight (IBL) — ambient lighting
- Terrain Layer Spawner — terrain system
- Vegetation Layer Spawner — procedural vegetation

═══ TYPICAL GAME SETUP SEQUENCE ═══
1. Create project (o3de_create_project)
2. Create level (o3de_create_level)
3. Set up lighting (o3de_setup_lighting) — always do this early
4. Create terrain if outdoor (o3de_create_terrain)
5. Create entities: player, enemies, objects, cameras
6. Add physics to interactive entities (o3de_add_physics)
7. Write gameplay scripts in Lua (o3de_write_script)
8. Attach scripts to entities
9. Save level (o3de_save_level)
10. Build game (o3de_build_game)

═══ GAME TYPE PATTERNS ═══
- FPS: Player entity (Camera, CharacterController, Lua Script), weapons, enemies with AI, terrain, lighting
- RPG: Player, NPCs with dialogue, inventory system, quests via Lua, terrain, towns
- Platformer: Player with CharacterController, platforms with static physics, collectibles, camera follow
- Racing: Vehicle entities with PhysX, track with colliders, checkpoints, timer
- Horror: Dark lighting, ambient audio, scripted events, flashlight entity

═══ RULES ═══
- Always start with create_project → create_level → setup_lighting
- Every entity needs a Transform component (added automatically)
- For visible objects: add Mesh component + material
- For interactive objects: add PhysX Rigid Body + Collider
- For gameplay logic: write Lua scripts and attach to entities
- Max 40 steps. Output ONLY valid JSON."""

O3DE_WORKER_SYSTEM = """You are the O3DE execution agent for OpenArtemis AAA Game Development. You execute ONE step at a time using O3DE tools.

═══ O3DE TOOLS ═══
- o3de_create_project(name, template) — create new O3DE project
- o3de_create_level(name, size, use_terrain) — create a new level
- o3de_create_entity(name, components, position, parent) — create entity with components
- o3de_add_component(entity_name, component_type) — add component to entity
- o3de_set_property(entity_name, component, property_path, value) — set component property
- o3de_import_asset(source_path, asset_type) — import model/texture/audio
- o3de_set_material(entity_name, material_path) — assign material to mesh
- o3de_create_terrain(size, height_scale) — create terrain
- o3de_setup_lighting(light_type, color, intensity) — set up lights + skybox
- o3de_add_physics(entity_name, body_type, collider_shape) — add rigid body + collider
- o3de_write_script(name, content, script_type) — write Lua or Python script
- o3de_run_editor_script(script_content) — write Python script to project (runs when Editor opens)
- o3de_build_game(platform, config) — build game executable
- o3de_save_level() — save current level
- o3de_project_info() — get project status

═══ COMPONENT REFERENCE ═══
Rendering: Mesh, Decal, HDRi Skybox
Lighting: Directional Light, Point Light, Spot Light, Area Light, Global Skylight (IBL)
Physics: PhysX Dynamic Rigid Body, PhysX Static Rigid Body, PhysX Kinematic Rigid Body
Colliders: PhysX Box Collider, PhysX Sphere Collider, PhysX Capsule Collider, PhysX Mesh Collider
Scripting: Lua Script, Script Canvas
Audio: Audio Trigger, Audio Environment
VFX: Particle Emitter
Terrain: Axis Aligned Box Shape, Terrain Layer Spawner, Terrain Height Gradient List
Camera: Camera
Input: Input, StartingPointInput

═══ LUA SCRIPTING PATTERN ═══
Lua scripts for gameplay go in Scripts/ folder. Basic pattern:
```lua
local MyScript = {
    Properties = {
        Speed = { default = 5.0, description = "Movement speed" },
    }
}

function MyScript:OnActivate()
    self.tickHandler = TickBus.Connect(self)
end

function MyScript:OnTick(deltaTime, scriptTime)
    -- Game logic here
end

function MyScript:OnDeactivate()
    self.tickHandler:Disconnect()
end

return MyScript
```

Execute the step. Be precise with entity names and component types."""

WORKER_SYSTEM = """You are the execution agent for OpenArtemis (Autonomous Development Runtime). You are a coding worker. You execute ONE small, focused step at a time using your tools.

Artifacts: keep the main entrypoint at workspace root (e.g. index.html for web apps, main.py for Python). One clear entrypoint per project.

AI CHAT UI REMINDER: When building an "AI chat UI", ensure you:
- Connect to an AI API (OpenAI or similar) using fetch/axios
- Display streaming or typed responses from the AI
- Show different styling for user vs AI messages
- Include typing indicators and loading states
- Handle API errors gracefully
- This is NOT just a simple chat/messaging app between users

Tools: read_file, write_file, list_dir, search_in_files, run_terminal, take_screenshot, generate_image, search_replace, apply_patch, get_secret, run_code_interpreter.

- read_file(path) — read file contents
- write_file(path, content) — write or overwrite file
- list_dir(path) — list directory (default ".")
- search_in_files(query, path, max_results) — search for text in workspace; returns file:line: snippet
- run_terminal(command) — run command in workspace. For long-running servers, start in background so the next tool can run: Windows use "start /B python -m http.server 8000", Unix use "python -m http.server 8000 &"
- take_screenshot(url_or_path, prompt) — capture URL or file, send to vision model for feedback. Use it to assess UI/gameplay and decide whether to continue or fix.
- generate_image(description, path) — generate an image from a text description (backgrounds, sprites, characters, logos) and save to workspace path (e.g. assets/background.png). Use for any image the plan lists in "images"; then reference the path in HTML/JS/CSS (e.g. url('assets/background.png')).
- search_replace(path, old_string, new_string) — replace all occurrences in file (for small edits)
- apply_patch(path, patch_content) — apply a unified diff to a file; use when you have a precise diff
- get_secret(key) — get API key or secret from vault (e.g. get_secret("OPENAI_API_KEY"))
- run_code_interpreter(description_or_code) — run Python in OpenAI sandbox (math, data, one-off scripts). Only available when OPENARTEMIS_ENABLE_CODE_INTERPRETER=1. Do not use for editing project files.

Prefer search_replace for small edits; use apply_patch when you have a precise diff; use write_file only for new files or when the file is small.
For files that already exist in the workspace (e.g. index.html): always read_file first, then use search_replace or apply_patch to make changes. Do not use write_file to overwrite existing files unless you are intentionally doing a full rewrite.
When the goal is to upgrade or extend an existing project (e.g. add pipes, sprites, background): you MUST read_file the existing entrypoint (index.html, game.js, etc.) first, then use search_replace or apply_patch to modify them so the app uses new assets and logic; do not only add new files without updating existing code.

Images: When the plan includes an "images" array, call generate_image(description, path) for each entry before or when the step needs it; then use the saved path in your code.

Image feedback: For web or game builds, after writing UI or starting a dev server, call take_screenshot on the app URL (e.g. http://localhost:5173 or http://localhost:8000). Use the vision result to decide: if the app looks correct and complete, continue to the next step; if something is wrong or missing, fix it with search_replace or write_file before continuing. This is your feedback loop to assess and iterate.

Reliability loop: when a step touches executable code, you should (when reasonable) run tests and checks using run_terminal (e.g. npm test, pytest, or language-appropriate commands) and fix failing diagnostics before moving on. For code files, format them using the workspace's formatter task or tool when available (e.g. npm run lint/fix, black, isort), so the project stays consistent. Treat this as part of every step: change, then immediately verify and fix before you consider the step done.

Change budget: prefer small diffs. In each step, try to limit how many files you rewrite; if you find yourself doing many write_file or apply_patch calls in a single step, stop, wrap up with a summary, and let the next step handle additional changes. Avoid deleting or rewriting core entrypoints in one shot unless the plan explicitly calls for it.

Execute the step. For web apps: write HTML, start server in background, then take_screenshot to verify and decide. Be concise."""

# Max chars for tool result in messages (truncate read_file/run_terminal; keep full for write_file/search_replace)
TOOL_RESULT_MAX_CHARS = 1500
TOOLS_KEEP_FULL_RESULT = frozenset({"write_file", "search_replace", "apply_patch"})


def _truncate_tool_result(result: str, max_chars: int = TOOL_RESULT_MAX_CHARS, tool_name: str = "") -> str:
    """Truncate tool result before appending to messages. Keep full for write_file/search_replace."""
    if tool_name in TOOLS_KEEP_FULL_RESULT:
        return result
    if not isinstance(result, str):
        result = str(result)
    if len(result) <= max_chars:
        return result
    return f"(output truncated, showing last {max_chars} chars):\n" + result[-max_chars:]


def _trim_messages_to_budget(
    messages: list[dict[str, Any]],
    max_input_tokens: int = MAX_INPUT_TOKENS_PER_CALL,
    max_tokens: int = 2048,
) -> list[dict[str, Any]]:
    """Trim messages to fit within token budget while preserving tool_call/result pairs.

    Always keeps system + first user message.  Then adds complete
    assistant→tool groups from the end of the conversation until the
    budget would be exceeded.  A "group" is an assistant message that
    has tool_calls followed by all its corresponding tool-result
    messages, or a plain assistant message with no tool_calls.
    """
    if estimate_request_tokens(messages, max_tokens=max_tokens) <= max_input_tokens:
        return messages

    # Always keep system + first user message (indices 0 and 1).
    prefix = [messages[0], messages[1]] if len(messages) >= 2 else list(messages)
    rest = messages[len(prefix):]

    if not rest:
        return prefix

    # Split rest into groups: each group is either
    #   [assistant_with_tool_calls, tool, tool, ...]  or
    #   [assistant_without_tool_calls]  or
    #   [tool (orphan, shouldn't happen but be safe)]
    def _msg_has_tool_use(msg: dict) -> bool:
        """Return True if message is an assistant message with tool calls (OpenAI or Anthropic format)."""
        if msg.get("role") != "assistant":
            return False
        # OpenAI format: tool_calls key
        if msg.get("tool_calls"):
            return True
        # Anthropic format: content is a list containing tool_use blocks
        content = msg.get("content")
        if isinstance(content, list):
            return any(isinstance(b, dict) and b.get("type") == "tool_use" for b in content)
        return False

    def _msg_is_tool_result(msg: dict) -> bool:
        """Return True if message is a tool result (OpenAI role:tool or Anthropic role:user with tool_result)."""
        if msg.get("role") == "tool":
            return True
        if msg.get("role") == "user":
            content = msg.get("content")
            if isinstance(content, list):
                return any(isinstance(b, dict) and b.get("type") == "tool_result" for b in content)
        return False

    groups: list[list[dict[str, Any]]] = []
    i = 0
    while i < len(rest):
        msg = rest[i]
        if _msg_has_tool_use(msg):
            # Collect this assistant + all following tool result messages
            group = [msg]
            i += 1
            while i < len(rest) and _msg_is_tool_result(rest[i]):
                group.append(rest[i])
                i += 1
            groups.append(group)
        else:
            groups.append([msg])
            i += 1

    # Take groups from the END until adding one more would bust the budget.
    kept_groups: list[list[dict[str, Any]]] = []
    for group in reversed(groups):
        candidate = prefix[:]
        for g in kept_groups:
            candidate.extend(g)
        candidate.extend(group)
        if estimate_request_tokens(candidate, max_tokens=max_tokens) <= max_input_tokens:
            kept_groups.insert(0, group)
        else:
            break

    # If we couldn't keep ANY group, keep at least the last one (best effort).
    if not kept_groups and groups:
        kept_groups = [groups[-1]]

    result = prefix[:]
    for g in kept_groups:
        result.extend(g)
    return result


def _checkpoint_path(output_path: Path | None) -> Path | None:
    if output_path is None:
        return None
    return output_path.parent / (output_path.stem + ".checkpoint.json")


def _is_single_file_plan(steps: list, chosen_stack: str) -> bool:
    """True if plan targets a single file (e.g. one index.html), so worker can use higher max_tokens."""
    files = {s.get("file", "").strip() for s in steps if s.get("file")}
    if len(files) != 1:
        return False
    stack_lower = (chosen_stack or "").lower()
    if "single" in stack_lower or "one file" in stack_lower or "index.html" in stack_lower:
        return True
    return list(files)[0].lower().endswith(".html") or list(files)[0].lower().endswith(".htm")


def _get_main_artifact_paths(workspace: Path, steps: list | None = None) -> list[str]:
    """Return list of absolute paths to main entrypoint files in workspace (for report and .oa)."""
    ws = workspace.resolve()
    paths: list[str] = []
    for name in ("index.html", "index.htm", "main.py", "app.py", "main.js"):
        p = ws / name
        if p.exists() and p.is_file():
            paths.append(str(p))
    if steps:
        for s in steps:
            f = (s.get("file") or "").strip()
            if not f:
                continue
            p = (ws / f).resolve()
            try:
                p.relative_to(ws)
            except ValueError:
                continue
            if p.exists() and p.is_file() and str(p) not in paths:
                paths.append(str(p))
    return paths[:10]


def _load_project_instructions(workspace: Path) -> str:
    """Load project instructions from OPENARTEMIS.md (workspace root or .openartemis/). User-level from ~/.openartemis/OPENARTEMIS.md applied first if present."""
    parts: list[str] = []
    user_file = Path.home() / ".openartemis" / "OPENARTEMIS.md"
    if user_file.exists():
        try:
            parts.append(user_file.read_text(encoding="utf-8", errors="replace").strip())
        except OSError:
            pass
    for candidate in (workspace / "OPENARTEMIS.md", workspace / ".openartemis" / "OPENARTEMIS.md"):
        if candidate.exists():
            try:
                parts.append(candidate.read_text(encoding="utf-8", errors="replace").strip())
            except OSError:
                pass
            break
    if not parts:
        return ""
    return "\n\n".join(parts).strip()


_QUALITY_INSTRUCTIONS_CONTENT = """# OpenArtemis Quality Rules
These rules are automatically injected into every agent build.

## Games
- Use proven physics constants: gravity += 0.4/frame, jump = -7, pipe speed = 2px/frame, pipe gap = 160px
- Always support spacebar + mouse click + touch (touchstart) for the same primary action
- Show score on canvas at all times during play
- Game over screen must show final score and how to restart (click or spacebar)
- Restart must fully reset all state: score, positions, velocities, arrays
- Canvas must have a colored background — never a blank white canvas
- Test that the character doesn't fall off screen in under 2 seconds with no input

## Web Apps
- Layout must work at 1280px wide minimum
- All buttons must be functional
- Forms must validate before submitting

## All Projects
- No placeholder code, no TODOs, no stubs in final output
- No JavaScript errors (avoid undefined variables, always initialize state)
- Complete, working code on first delivery
"""


def _auto_create_quality_instructions() -> None:
    """Create ~/.openartemis/OPENARTEMIS.md with quality rules if it doesn't exist yet."""
    user_dir = Path.home() / ".openartemis"
    user_file = user_dir / "OPENARTEMIS.md"
    if user_file.exists():
        return
    try:
        user_dir.mkdir(parents=True, exist_ok=True)
        user_file.write_text(_QUALITY_INSTRUCTIONS_CONTENT, encoding="utf-8")
    except OSError:
        pass


def _infer_project_commands(workspace: Path) -> dict[str, str]:
    """Infer default test/lint/dev commands for the workspace.

    Heuristics only – cheap to compute and safe when nothing matches.
    Returned keys are simple labels like 'unit_tests', 'lint', 'dev_server'.
    """
    cmds: dict[str, str] = {}
    ws = workspace.resolve()

    # Node / JS projects
    pkg = ws / "package.json"
    if pkg.exists():
        try:
            data = json.loads(pkg.read_text(encoding="utf-8", errors="replace"))
            scripts = data.get("scripts") or {}
            if "test" in scripts and "unit_tests" not in cmds:
                cmds["unit_tests"] = "npm test"
            if "lint" in scripts and "lint" not in cmds:
                cmds["lint"] = "npm run lint"
            if "dev" in scripts and "dev_server" not in cmds:
                cmds["dev_server"] = "npm run dev"
        except Exception:
            pass

    # Python projects
    if (
        (ws / "pyproject.toml").exists()
        or (ws / "pytest.ini").exists()
        or (ws / "tests").exists()
    ):
        cmds.setdefault("unit_tests", "pytest -q")

    return cmds


_TARGET_PATTERN = re.compile(r"@([\w\-/\.]+)")


def _extract_explicit_targets(prompt: str) -> tuple[str, list[str]]:
    """Extract @file/@folder/@symbol-style tokens from the user prompt.

    Returns a tuple of (cleaned_prompt, targets). Targets are returned as raw
    strings like "src/game.ts" or "lib/" and can be resolved relative to the
    agent workspace by callers.
    """
    if not prompt:
        return prompt, []
    targets = _TARGET_PATTERN.findall(prompt)
    cleaned = _TARGET_PATTERN.sub(r"\1", prompt)
    # De-duplicate while preserving order
    seen: set[str] = set()
    unique_targets: list[str] = []
    for t in targets:
        if t not in seen:
            seen.add(t)
            unique_targets.append(t)
    return cleaned.strip(), unique_targets


def _build_context_snippet(workspace: Path, targets: list[str], max_chars: int = 4000) -> str:
    """Build a lightweight context snippet from explicit @targets in the prompt.

    For each target that resolves to a file under the workspace, include a short
    header and the first few hundred characters of its contents. For directories,
    list a handful of entries. This keeps things cheap while giving the model
    concrete anchors into the codebase.
    """
    if not targets:
        return ""

    ws = workspace.resolve()
    parts: list[str] = []
    remaining = max_chars

    for raw in targets:
        if remaining <= 0:
            break
        candidate = (ws / raw).resolve()
        try:
            candidate.relative_to(ws)
        except ValueError:
            # Ignore paths outside the workspace
            continue

        if candidate.is_file():
            try:
                text = candidate.read_text(encoding="utf-8", errors="replace")
            except OSError:
                continue
            snippet = text[: min(len(text), 800)]
            header = f"// File: {candidate.relative_to(ws)}"
            block = f"{header}\n{snippet}"
        elif candidate.is_dir():
            try:
                entries = [p.name for p in candidate.iterdir()][:20]
            except OSError:
                continue
            header = f"// Folder: {candidate.relative_to(ws)}"
            listing = "\n".join(f"- {name}" for name in entries)
            block = f"{header}\n{listing}"
        else:
            continue

        if len(block) > remaining:
            block = block[:remaining]
        parts.append(block)
        remaining -= len(block)

    if not parts:
        return ""

    return "Explicitly referenced files and folders:\n\n" + "\n\n".join(parts)


def _write_prd_file(workspace: Path, content: str) -> Path | None:
    """Persist the Clarify+PRD output into the workspace's .oa ledger."""
    if not content:
        return None
    ws = workspace.resolve()
    oa_dir = ws / ".oa"
    try:
        oa_dir.mkdir(parents=True, exist_ok=True)
    except OSError:
        return None
    ts = datetime.now().strftime("%Y%m%d-%H%M%S")
    prd_path = oa_dir / f"PRD-{ts}.md"
    try:
        prd_path.write_text(content, encoding="utf-8")
        latest = oa_dir / "PRD.latest.md"
        latest.write_text(content, encoding="utf-8")
    except OSError:
        return None
    return prd_path


def _run_combined_pre_planning(
    client: Any,  # OpenAI client from get_openai_client()
    lead_model: str,
    workspace: Path,
    goal: str,
    oa_summary: str,
    status_cb: Callable[[str], None] | None = None,
) -> tuple[str, str, str, str]:
    """Combined Questioner + Translator + Orc router in a SINGLE API call.

    Returns (questioner_md, translator_brief, orc_profile, orc_notes).
    All may be empty strings on failure.
    """
    goal = (goal or "").strip()
    if not goal:
        return "", "", "", ""
    if status_cb:
        status_cb("Analyzing goal (questions, brief, routing)...")

    context_bits: list[str] = []
    if oa_summary and oa_summary.strip():
        context_bits.append("Existing workspace context:\n" + oa_summary)
    context_block = ("\n\n".join(context_bits) + "\n\n") if context_bits else ""

    user_text = (
        f"{context_block}"
        "You are a pre-planning assistant for Artemis Agent. Do three things in ONE response:\n\n"
        "1) **Questioner**: List 3-5 clarifying questions a senior engineer would ask before coding. "
        "For each, include a \"Likely answer\" if the goal implies one.\n\n"
        "2) **Translator**: Rewrite the goal into a compact developer brief with sections: "
        "Goal, Constraints, Key entities & files, Acceptance tests.\n\n"
        "3) **Orc Router**: Classify as one of: web_app, cli_tool, game, library. "
        "Add short stack/approach notes.\n\n"
        "Output JSON with this exact shape:\n"
        "{\n"
        '  "questions": "markdown list of clarifying questions with likely answers",\n'
        '  "brief": "the translator brief as markdown",\n'
        '  "profile": "web_app|cli_tool|game|library",\n'
        '  "notes": "short orc routing notes"\n'
        "}\n\n"
        f"Goal from user:\n{goal}\n"
    )

    messages = [
        {
            "role": "system",
            "content": (
                "You are the pre-planning assistant for OpenArtemis. "
                "Combine the Questioner, Translator, and Orc Router roles into one response. "
                "Output ONLY valid JSON."
            ),
        },
        {"role": "user", "content": user_text},
    ]

    try:
        resp = create_with_budget(
            client,
            (lead_model or "").strip() or FALLBACK_MODEL,
            messages,
            max_tokens=1024,
        )
    except Exception:
        return "", "", "", ""

    content = (resp.choices[0].message.content or "").strip()
    data = _extract_json_object(content)
    if data is None:
        return "", "", "", ""

    questions = (data.get("questions") or "").strip()
    brief = (data.get("brief") or "").strip()
    profile = (data.get("profile") or "").strip()
    notes = (data.get("notes") or "").strip()
    if profile not in {"web_app", "cli_tool", "game", "library"}:
        profile = ""
    return questions, brief, profile, notes


def _run_questioner(
    client: Any,  # OpenAI client from get_openai_client()
    lead_model: str,
    workspace: Path,
    goal: str,
    oa_summary: str,
    status_cb: Callable[[str], None] | None = None,
) -> str | None:
    """Simulate a dedicated Questioner role that surfaces clarifying questions.

    This is a lightweight, non-interactive pass: the model infers the questions
    it WOULD ask and, where obvious, the answers implied by the goal/context.
    """
    goal = (goal or "").strip()
    if not goal:
        return None
    if status_cb:
        status_cb("Thinking through clarifying questions...")

    context_bits: list[str] = []
    if oa_summary.strip():
        context_bits.append("Existing workspace context (summarized):\n" + oa_summary)
    context_block = ("\n\n".join(context_bits) + "\n\n") if context_bits else ""

    user_text = (
        f"{context_block}"
        "You are the Questioner role for Artemis Agent.\n"
        "Given the goal below, infer 5–10 clarifying questions a senior engineer would ask "
        "BEFORE planning or coding. When the answer is strongly implied by the goal/context, "
        "include a short \"Likely answer\" line.\n\n"
        "Output as markdown with this structure:\n"
        "## Clarifying questions\n"
        "1. <question>\n"
        "   - Likely answer: <short guess or \"unknown\">\n"
        "...\n\n"
        f"Goal from user:\n{goal}\n"
    )

    messages = [
        {
            "role": "system",
            "content": (
                "You are the Questioner for OpenArtemis. "
                "Your ONLY job is to surface high-value clarifying questions and likely answers. "
                "Do not design solutions or write code."
            ),
        },
        {"role": "user", "content": user_text},
    ]

    try:
        resp = create_with_budget(
            client,
            (lead_model or "").strip() or FALLBACK_MODEL,
            messages,
            max_tokens=get_max_tokens_or_default(),
        )
    except Exception:
        return None

    text = (resp.choices[0].message.content or "").strip()
    return text or None


def _run_translator(
    client: Any,  # OpenAI client from get_openai_client()
    lead_model: str,
    goal: str,
    questioner_markdown: str,
    oa_summary: str,
    status_cb: Callable[[str], None] | None = None,
) -> str | None:
    """Translator role: turn messy goal + questions into a crisp brief.

    Produces a compact markdown brief used as shared context for planner/worker.
    """
    goal = (goal or "").strip()
    if not goal:
        return None
    if status_cb:
        status_cb("Translating goal into structured brief...")

    context_bits: list[str] = []
    if oa_summary.strip():
        context_bits.append("Existing workspace context (summarized):\n" + oa_summary)
    if questioner_markdown:
        context_bits.append("Clarifying questions and likely answers:\n" + questioner_markdown)
    context_block = ("\n\n".join(context_bits) + "\n\n") if context_bits else ""

    user_text = (
        f"{context_block}"
        "You are the Translator role for Artemis Agent.\n"
        "Rewrite the goal and clarifications into a structured, developer-friendly brief with "
        "these sections (markdown):\n"
        "## Goal\n"
        "## Constraints\n"
        "## Key entities & files\n"
        "## Risks\n"
        "## Acceptance tests\n\n"
        "Keep it compact and concrete. Do NOT propose an implementation plan; focus on what "
        "should be true when the work is done.\n\n"
        f"Original goal:\n{goal}\n"
    )

    messages = [
        {
            "role": "system",
            "content": (
                "You are the Translator for OpenArtemis. "
                "You turn messy user goals and Q&A into a clear, compact brief. "
                "Do not write code or low-level plans."
            ),
        },
        {"role": "user", "content": user_text},
    ]

    try:
        resp = create_with_budget(
            client,
            (lead_model or "").strip() or FALLBACK_MODEL,
            messages,
            max_tokens=get_max_tokens_or_default(),
        )
    except Exception:
        return None

    brief = (resp.choices[0].message.content or "").strip()
    return brief or None


def _run_orc_router(
    client: Any,  # OpenAI client from get_openai_client()
    lead_model: str,
    goal: str,
    translator_brief: str,
    status_cb: Callable[[str], None] | None = None,
) -> tuple[str, str]:
    """Determine an Orc profile (web_app, cli_tool, game, library) and notes.

    Returns (profile, markdown_notes).
    """
    goal = (goal or "").strip()
    if not goal:
        return "", ""
    if status_cb:
        status_cb("Routing mission to an Orc profile...")

    user_text = (
        "You are the Orc router for Artemis Agent. Classify the mission into one of:\n"
        "- web_app\n"
        "- cli_tool\n"
        "- game\n"
        "- library\n\n"
        "Then output JSON only with keys:\n"
        "{ \"profile\": \"one of the above\",\n"
        "  \"notes\": \"short guidance for planner and workers (stack focus, UI vs backend, etc.)\" }\n\n"
        "Translator brief:\n"
        f"{translator_brief}\n\n"
        "Original goal:\n"
        f"{goal}\n"
    )

    messages = [
        {
            "role": "system",
            "content": (
                "You are the Orc router for Artemis. "
                "You ONLY choose a profile and write short notes. Output strict JSON."
            ),
        },
        {"role": "user", "content": user_text},
    ]

    try:
        resp = create_with_budget(
            client,
            (lead_model or "").strip() or FALLBACK_MODEL,
            messages,
            max_tokens=512,
        )
    except Exception:
        return "", ""

    content = (resp.choices[0].message.content or "").strip()
    data = _extract_json_object(content)
    if data is None:
        return "", ""

    profile = (data.get("profile") or "").strip()
    notes = (data.get("notes") or "").strip()
    if profile not in {"web_app", "cli_tool", "game", "library"}:
        profile = ""
    return profile, notes


def _run_clarify_and_prd(
    client: Any,  # OpenAI client from get_openai_client()
    lead_model: str,
    workspace: Path,
    goal: str,
    oa_summary: str,
    status_cb: Callable[[str], None] | None = None,
) -> str | None:
    """Run a lightweight Clarify+PRD pass before planning.

    This does not block on interactive Q&A. Instead, it asks the model to:
    - Infer clarifying questions it WOULD ask.
    - Capture assumptions, constraints, and acceptance tests.
    - Produce a concise markdown PRD we can save and feed into planning.
    """
    goal = (goal or "").strip()
    if not goal:
        return None
    if status_cb:
        status_cb("Clarifying goal and drafting PRD...")

    context_block = ""
    if oa_summary.strip():
        context_block = f"Existing context from this workspace (summarized):\n{oa_summary}\n\n"

    user_text = (
        f"{context_block}"
        "You are preparing a brief PRD for an Artemis Agent mission.\n\n"
        "1) Infer up to 5 clarifying questions you would ask the human to fully understand the goal.\n"
        "2) Based on the goal (and any answers implied by the description), write down:\n"
        "   - A short summary in plain language.\n"
        "   - Key requirements.\n"
        "   - Constraints or non-goals (if any are implied).\n"
        "   - Rough acceptance tests the agent should implicitly check against.\n\n"
        "3) Output a compact markdown document with sections:\n"
        "   ## Summary\n"
        "   ## Clarifying questions\n"
        "   ## Requirements\n"
        "   ## Constraints\n"
        "   ## Acceptance tests\n\n"
        "If the goal is already extremely clear and no questions are needed, include an empty Clarifying questions list.\n\n"
        f"Goal from user:\n{goal}"
    )

    messages = [
        {
            "role": "system",
            "content": (
                "You are the Clarify+PRD helper for OpenArtemis Agent. "
                "Your job is to turn a messy user request into a crisp, compact PRD that downstream "
                "planning and execution agents can follow. Do not invent implementation details; "
                "focus on summarizing the goal, surfacing clarifying questions, and writing pragmatic "
                "acceptance tests."
            ),
        },
        {"role": "user", "content": user_text},
    ]

    try:
        resp = create_with_budget(
            client,
            (lead_model or "").strip() or FALLBACK_MODEL,
            messages,
            max_tokens=get_max_tokens_or_default(),
        )
    except Exception:
        return None

    prd = (resp.choices[0].message.content or "").strip()
    return prd or None


def _run_sequential_thinking(
    client: Any,  # OpenAI client from get_openai_client()
    lead_model: str,
    goal: str,
    workspace: Path,
    oa_summary: str,
    explicit_targets: list[str],
    status_cb: Callable[[str], None] | None = None,
) -> tuple[dict[str, Any] | None, str]:
    """Run a lightweight \"Sequential Thinking\" pass to structure the mission.

    Returns a tuple of:
    - structured JSON object (or None on failure)
    - pretty-printed markdown string to inject into system prompts
    """
    goal = (goal or "").strip()
    if not goal:
        return None, ""

    if status_cb:
        status_cb("Thinking through steps and risks...")

    context_bits: list[str] = []
    if oa_summary.strip():
        context_bits.append("Existing context from this workspace (summarized):\n" + oa_summary)
    if explicit_targets:
        context_bits.append(
            "User explicitly mentioned these files/folders/symbols:\n"
            + "\n".join(f"- {t}" for t in explicit_targets[:15])
        )
    context_block = ("\n\n".join(context_bits) + "\n\n") if context_bits else ""

    user_text = (
        f"{context_block}"
        "You are preparing a short, strictly structured scratchpad for Artemis Agent before it edits any code.\n"
        "Given the goal below, think step by step and produce JSON with this shape:\n\n"
        "{\n"
        '  \"summary\": \"one-sentence restatement of the goal\",\n'
        '  \"steps\": [\"concrete step 1\", \"concrete step 2\", ...],\n'
        '  \"files\": [\"relative/path.ext\", ...],\n'
        '  \"tests\": [\"pytest -q\", \"npm test\", \"custom command\"],\n'
        '  \"risks\": [\"obvious risk 1\", \"obvious risk 2\"]\n'
        "}\n\n"
        "Rules:\n"
        "- Keep steps small and execution-focused (read, edit, run, verify).\n"
        "- Only include files that are clearly relevant or likely entrypoints.\n"
        "- Tests may be empty if you truly see no obvious command, but prefer a best guess.\n"
        "- Do not output markdown; output ONLY valid JSON.\n\n"
        f"Goal from user:\n{goal}\n"
    )

    messages = [
        {
            "role": "system",
            "content": (
                "You are the Sequential Thinking helper for Artemis. "
                "Your job is to produce a compact JSON scratchpad with steps, files, tests, and risks. "
                "Do not plan a full architecture; just organize the work into an ordered list the worker can follow."
            ),
        },
        {"role": "user", "content": user_text},
    ]

    try:
        resp = create_with_budget(
            client,
            (lead_model or "").strip() or FALLBACK_MODEL,
            messages,
            max_tokens=get_max_tokens_or_default(),
        )
    except Exception:
        return None, ""

    content = (resp.choices[0].message.content or "").strip()
    data = _extract_json_object(content)
    if data is None:
        return None, ""

    # Build a human-friendly markdown block for system prompts.
    summary = (data.get("summary") or "").strip()
    steps = [s for s in (data.get("steps") or []) if isinstance(s, str)]
    files = [f for f in (data.get("files") or []) if isinstance(f, str)]
    tests = [t for t in (data.get("tests") or []) if isinstance(t, str)]
    risks = [r for r in (data.get("risks") or []) if isinstance(r, str)]

    lines: list[str] = []
    if summary:
        lines.append(f"Summary: {summary}")
    if steps:
        lines.append("\nSteps:")
        for i, s in enumerate(steps, 1):
            lines.append(f"- {i}. {s}")
    if files:
        lines.append("\nFiles to focus on:")
        for f in files:
            lines.append(f"- {f}")
    if tests:
        lines.append("\nTests or commands to run:")
        for t in tests:
            lines.append(f"- {t}")
    if risks:
        lines.append("\nRisks / caveats:")
        for r in risks:
            lines.append(f"- {r}")
    pretty = "\n".join(lines).strip()

    # Persist to .oa for future runs.
    try:
        append_oa_event(
            workspace,
            {
                "event": "sequential_thinking",
                "ts": datetime.now().isoformat(),
                "scratchpad": data,
            },
        )
    except Exception:
        # Non-fatal; orchestration should continue even if logging fails.
        pass

    return data, pretty


def run_agent_mode(
    user_request: str,
    lead_model: str | None = None,
    worker_model: str | None = None,
    on_status: Callable[[str], None] | None = None,
    max_steps: int = 50,
    output_path: Path | None = None,
    resume_from_checkpoint: bool = False,
    plan_mode: bool = False,
    permission_callback: Callable[[str, dict], bool] | None = None,
    direct_build: bool = False,
) -> str:
    """
    Run agent mode: lead plans, worker executes. Returns final report.
    If resume_from_checkpoint and a checkpoint exists next to output_path, resume from last step.
    If plan_mode is True, only the lead runs; the plan is written to the report and no execution is performed.
    If direct_build is True, skip planning: one model gets the full goal and uses tools until done (good for single-file tasks).
    permission_callback(name, args) is called for write_file/run_terminal/search_replace when interactive; return False to deny.
    """
    client = _get_openai_client()
    # Extract any explicit @file/@folder/@symbol tags so we can build a small
    # context package, but still keep the main request text natural.
    user_request_clean, explicit_targets = _extract_explicit_targets(user_request or "")
    lead_model = (lead_model or get_plan_model()) or FALLBACK_MODEL
    worker_model = (worker_model or get_exec_model()) or FALLBACK_MODEL
    lead_model = resolve_artemis_model(lead_model) if isinstance(lead_model, str) and "artemis" in lead_model.lower() else lead_model
    worker_model = resolve_artemis_model(worker_model) if isinstance(worker_model, str) and "artemis" in worker_model.lower() else worker_model
    if not lead_model or not worker_model:
        lead_model = lead_model or FALLBACK_MODEL
        worker_model = worker_model or FALLBACK_MODEL

    get_agent_workspace().mkdir(parents=True, exist_ok=True)
    clear_undo_stack()
    ensure_artemiscontext(get_agent_workspace())
    append_oa_event(
        get_agent_workspace(),
        {"event": "session_start", "ts": datetime.now().isoformat(), "workspace": str(get_agent_workspace().resolve()), "goal": (user_request_clean or "").strip()[:500]},
    )
    if not hooks_fire("session_start", user_request=user_request, output_path=str(output_path) if output_path else ""):
        return "Hooks denied session start."
    status_path = (output_path.with_name(output_path.name + ".status") if output_path else None)
    checkpoint_path = _checkpoint_path(output_path)
    replay_path = replay_path_for(output_path)
    terminal_path = (output_path.parent / (output_path.stem + ".terminal") if output_path else None)
    if terminal_path is not None:
        set_terminal_log_path(terminal_path)
    container_id: str | None = None
    if output_path and is_sandbox_enabled():
        cid = create_job_container(get_agent_workspace(), output_path.stem or "openartemis-agent")
        if cid:
            container_id = cid
            set_agent_container_id(cid)
    blockers_path = (output_path.with_name(output_path.name + ".blockers") if output_path else None)
    cancel_path = (output_path.with_name(output_path.name + ".cancel") if output_path else None)
    pause_path = (output_path.with_name(output_path.name + ".pause") if output_path else None)
    throttled_path = (output_path.with_name(output_path.stem + ".throttled") if output_path else None)
    done_path = (output_path.with_name(output_path.stem + ".done") if output_path else None)
    _STATUS_MAX_LINES = 20

    def _wait_if_paused() -> None:
        while pause_path is not None and pause_path.exists():
            log_audit(replay_path, "paused")
            _status("Paused. Run 'openartemis agent-unpause' to continue.")
            time.sleep(2)

    def _is_canceled() -> bool:
        return cancel_path is not None and cancel_path.exists()

    def _clear_blockers() -> None:
        if blockers_path and blockers_path.exists():
            try:
                blockers_path.write_text("", encoding="utf-8")
            except Exception:
                pass

    def _append_blocker(line: str) -> None:
        if blockers_path:
            try:
                blockers_path.parent.mkdir(parents=True, exist_ok=True)
                with open(blockers_path, "a", encoding="utf-8") as f:
                    f.write(line.strip() + "\n")
            except Exception:
                pass

    _clear_blockers()

    def _status(s: str) -> None:
        if on_status:
            on_status(s)
        if status_path:
            try:
                status_path.parent.mkdir(parents=True, exist_ok=True)
                line = f"{datetime.now().strftime('%H:%M:%S')} {s}"
                existing = status_path.read_text(encoding="utf-8", errors="replace").strip().splitlines() if status_path.exists() else []
                existing.append(line)
                status_path.write_text("\n".join(existing[-_STATUS_MAX_LINES:]), encoding="utf-8")
            except Exception:
                pass

    def _write_throttled(retry_until_ts: float) -> None:
        if throttled_path:
            try:
                throttled_path.parent.mkdir(parents=True, exist_ok=True)
                throttled_path.write_text(f"retry_until:{retry_until_ts}", encoding="utf-8")
            except Exception:
                pass

    def _clear_throttled() -> None:
        if throttled_path and throttled_path.exists():
            try:
                throttled_path.unlink(missing_ok=True)
            except Exception:
                pass

    def _write_done(outcome: str, error: str | None = None) -> None:
        if done_path:
            try:
                done_path.parent.mkdir(parents=True, exist_ok=True)
                payload = {"outcome": outcome, "finished_at": datetime.now().isoformat()}
                if error:
                    payload["error"] = (error[:500] + "…") if len(error) > 500 else error
                done_path.write_text(json.dumps(payload), encoding="utf-8")
            except Exception:
                pass

    def _write_checkpoint(steps: list, report_parts: list, step_index: int, lead_sys: str, worker_sys: str, stack: str = "") -> None:
        if checkpoint_path is None:
            return
        try:
            checkpoint_path.parent.mkdir(parents=True, exist_ok=True)
            payload = {
                "user_request": user_request,
                "steps": steps,
                "report_parts": report_parts,
                "step_index": step_index,
                "lead_system": lead_sys,
                "worker_system": worker_sys,
            }
            if stack:
                payload["chosen_stack"] = stack
            checkpoint_path.write_text(json.dumps(payload, indent=2), encoding="utf-8")
        except Exception:
            pass

    def _start_heartbeat(message: str, interval_sec: float = 12) -> threading.Event:
        """Start a daemon thread that writes a timestamped line to status_path every interval_sec until stop_event is set."""
        stop_event = threading.Event()

        def _run() -> None:
            while not stop_event.wait(interval_sec):
                if status_path is None:
                    break
                try:
                    status_path.parent.mkdir(parents=True, exist_ok=True)
                    line = f"{datetime.now().strftime('%H:%M:%S')} {message}"
                    existing = status_path.read_text(encoding="utf-8", errors="replace").strip().splitlines() if status_path.exists() else []
                    existing.append(line)
                    status_path.write_text("\n".join(existing[-_STATUS_MAX_LINES:]), encoding="utf-8")
                except Exception:
                    pass

        t = threading.Thread(target=_run, daemon=True)
        t.start()
        return stop_event

    steps: list[dict] = []
    report_parts: list[str] = []
    lead_system = ""
    worker_system = ""
    start_index = 0
    chosen_stack = ""

    if resume_from_checkpoint and checkpoint_path and checkpoint_path.exists():
        try:
            data = json.loads(checkpoint_path.read_text(encoding="utf-8"))
            steps = data.get("steps", [])
            report_parts = data.get("report_parts", [])
            start_index = min(data.get("step_index", 0), len(steps))
            lead_system = data.get("lead_system", "")
            worker_system = data.get("worker_system", "")
            chosen_stack = data.get("chosen_stack", "")
        except (json.JSONDecodeError, OSError):
            start_index = 0
            steps = []

    if direct_build:
        # ═══ AGENT OS: One-prompt phased build loop ═══
        # Phase 1: Build → Phase 2: Verify → Phase 3: Fix → Phase 4: Report
        _status("Phase 1: Building project...")
        _auto_create_quality_instructions()
        project_instructions = _load_project_instructions(get_agent_workspace())
        oa_summary = load_oa_summary(get_agent_workspace(), max_chars=1200)
        # Use Agent OS prompt for new projects; worker prompt for existing
        if oa_summary and oa_summary.strip():
            d_sys = IDENTITY_WORKER + "\n" + WORKER_SYSTEM
            if project_instructions:
                d_sys += "\n\n---\nProject instructions (OPENARTEMIS.md):\n" + project_instructions
            d_sys += "\n\n---\nOpenArtemis context (recent .oa):\n" + oa_summary
            goal_msg = f"This folder already has project files. Read them with read_file first, then use search_replace or apply_patch to change existing files; use write_file only for new files.\n\nGoal: {user_request}"
        else:
            d_sys = AGENT_OS_SYSTEM
            if project_instructions:
                d_sys += "\n\n---\nProject instructions (OPENARTEMIS.md):\n" + project_instructions
            goal_msg = f"Build this NOW. Write all files immediately, then verify.\n\n{user_request}"
        os_messages: list[dict[str, Any]] = [
            {"role": "system", "content": d_sys},
            {"role": "user", "content": goal_msg},
        ]
        os_report = "Agent OS build completed."
        files_written: list[str] = []
        _os_phase = "build"  # build → verify → fix → report
        _fix_attempts = 0
        _MAX_FIX_ATTEMPTS = 5
        _MAX_TOTAL_TURNS = 20

        def _exec_tool(tc_obj: Any, msgs: list[dict]) -> None:
            """Execute a single tool call with permission checks and status emissions."""
            nonlocal files_written
            name = tc_obj.function.name
            try:
                args = json.loads(tc_obj.function.arguments)
            except json.JSONDecodeError:
                args = {}
            # Phase-aware status
            if name == "write_file":
                path = args.get("path", "?")
                content = args.get("content", "")
                lines = content.count("\n") + 1 if content else 0
                _status(f"Writing {path} ({lines} lines)...")
            elif name == "read_file":
                _status(f"Reading {args.get('path', '?')}...")
            elif name == "run_terminal":
                cmd = (args.get("command") or "?")[:50]
                _status(f"Running: {cmd}...")
            elif name == "search_replace":
                _status(f"Fixing {args.get('path', '?')}...")
            elif name == "take_screenshot":
                _status("Verifying with screenshot...")
            elif name == "generate_image":
                _status(f"Generating image: {args.get('description', '?')[:40]}...")
            elif name == "list_dir":
                _status("Listing files...")
            elif name == "apply_patch":
                _status(f"Patching {args.get('path', '?')}...")
            # Permission checks for destructive tools
            if name in ("write_file", "run_terminal", "search_replace", "apply_patch"):
                hook_before = "before_run_cmd" if name == "run_terminal" else "before_edit"
                if not hooks_fire(hook_before, name=name, args=args):
                    result = "Hook denied action."
                else:
                    mode = get_permission_mode()
                    if mode == "deny-writes":
                        result = "Permission denied (deny-writes mode)."
                    elif permission_callback is not None:
                        if mode == "ask":
                            allow = permission_callback(name, args)
                        elif mode == "auto-edit":
                            allow = (name != "run_terminal") or permission_callback(name, args)
                        else:
                            allow = True
                        result = execute_agent_tool(name, args) if allow else "User denied permission."
                    else:
                        result = execute_agent_tool(name, args)
                hook_after = "after_run_cmd" if name == "run_terminal" else "after_edit"
                hooks_fire(hook_after, name=name, args=args, result=result)
            else:
                result = execute_agent_tool(name, args)
            # Track file writes
            if name == "write_file" and "Wrote" in (result or ""):
                fpath = args.get("path", "?")
                if fpath not in files_written:
                    files_written.append(fpath)
                _status(f"Created {fpath}")
            log_tool(replay_path, 0, "agent_os", name, args, result)
            content_str = _truncate_tool_result(result, tool_name=name)
            msgs.append({"role": "tool", "tool_call_id": tc_obj.id, "content": content_str})

        # ── Main Agent OS loop ──
        _build_model = get_build_model()  # Haiku — cheap, fast for tool turns
        _report_model = (worker_model or "").strip() or FALLBACK_MODEL  # Sonnet — report only
        for _turn in range(_MAX_TOTAL_TURNS):
            if _is_canceled():
                os_report = "Canceled."
                break
            # Phase-aware status header
            if _os_phase == "build":
                _status(f"Phase 1: Building... (turn {_turn + 1})")
            elif _os_phase == "verify":
                _status(f"Phase 2: Verifying... (turn {_turn + 1})")
            elif _os_phase == "fix":
                _status(f"Phase 3: Fixing (attempt {_fix_attempts}/{_MAX_FIX_ATTEMPTS})...")
            # Heartbeat for background mode
            hb = _start_heartbeat(f"Agent OS {_os_phase}...", 5)
            try:
                os_max = get_max_tokens_full_file()
                to_send = _trim_messages_to_budget(os_messages, max_tokens=os_max)
                # Use cheap build model for all tool-calling turns;
                # switch to the user's chosen model only for the final text report.
                _turn_model = _build_model if _os_phase != "report" else _report_model
                resp = create_with_budget(
                    client,
                    _turn_model,
                    to_send,
                    tools=get_all_agent_tools(),
                    tool_choice="auto",
                    max_tokens=os_max,
                )
            except Exception as e:
                et = classify_exception(e)
                if et == ErrorType.RATE_LIMIT:
                    delay = get_retry_after_seconds(e) or 30.0
                    _status(f"Rate limited — retrying in {delay:.0f}s...")
                    _append_blocker(f"429 TPM | retry in {delay:.0f}s")
                    _write_throttled(time.time() + delay)
                    token_budget_set_retry_after(delay)
                    time.sleep(delay)
                    _clear_throttled()
                    hb.set()
                    continue  # retry same turn
                os_report = f"Error: {e}"
                hb.set()
                break
            finally:
                hb.set()
            msg = resp.choices[0].message
            # Use Anthropic-native format to preserve tool_use blocks (required for tool_result pairing)
            if hasattr(msg, 'to_anthropic_dict'):
                os_messages.append(msg.to_anthropic_dict())
            else:
                os_messages.append({"role": msg.role, "content": msg.content or ""})

            if not msg.tool_calls:
                # No tool calls = model is producing final report
                if _os_phase != "report":
                    # First time hitting no-tool-call: switch to report phase and
                    # re-run with the stronger model so the summary is high quality.
                    _os_phase = "report"
                    _status("Phase 4: Generating report...")
                    continue
                os_report = msg.content or "Build completed."
                _status("Phase 4: Report complete.")
                break

            # Execute all tool calls
            has_write = False
            has_screenshot = False
            has_run = False
            has_fix = False
            for tc in msg.tool_calls:
                _exec_tool(tc, os_messages)
                n = tc.function.name
                if n == "write_file":
                    has_write = True
                if n == "take_screenshot":
                    has_screenshot = True
                if n == "run_terminal":
                    has_run = True
                if n == "search_replace" or n == "apply_patch":
                    has_fix = True

            # Phase transitions based on what tools were used
            if _os_phase == "build" and has_write and not has_screenshot:
                # Still building, but if next turn has no writes, transition
                pass
            if _os_phase == "build" and (has_screenshot or has_run) and not has_write:
                _os_phase = "verify"
                _status("Phase 2: Verifying project...")
            if _os_phase == "verify" and has_fix:
                _os_phase = "fix"
                _fix_attempts += 1
                _status(f"Phase 3: Fixing issues (attempt {_fix_attempts})...")
            if _os_phase == "fix" and has_screenshot:
                # Re-verifying after fix
                _os_phase = "verify"
                _status("Phase 2: Re-verifying after fix...")
            if _os_phase == "fix" and _fix_attempts >= _MAX_FIX_ATTEMPTS:
                # Give up fixing, ask model for report
                os_messages.append({
                    "role": "user",
                    "content": "Maximum fix attempts reached. Please provide a final summary of what was built and any remaining issues. Do NOT call any more tools."
                })
        else:
            os_report = "Agent OS: max turns reached. Partial build may be available in workspace."

        # ── Finalize ──
        _clear_blockers()
        ws = get_agent_workspace().resolve()
        report_path_str = str(output_path.resolve()) if output_path else ""
        workspace_str = str(ws)
        artifacts_list = _get_main_artifact_paths(ws, None)
        # Append file list to report
        if files_written:
            os_report += "\n\n---\n## Files created\n" + "\n".join(f"- `{f}`" for f in files_written)
        locations_lines = [
            "",
            "---",
            "## Output locations",
            f"- **Report:** `{report_path_str}`",
            f"- **Workspace:** `{workspace_str}`",
        ]
        if artifacts_list:
            locations_lines.append("- **Main file(s):**")
            for a in artifacts_list:
                locations_lines.append(f"  - `{a}`")
        else:
            locations_lines.append("- **Main file(s):** (none)")
        locations_section = "\n".join(locations_lines)
        if output_path:
            output_path.parent.mkdir(parents=True, exist_ok=True)
            output_path.write_text(
                f"# Agent Report — {user_request}\n\n{datetime.now().isoformat()}\n\n---\n\n{os_report}{locations_section}",
                encoding="utf-8",
            )
            _write_done("success")
        hooks_fire("session_end", outcome="success", report=os_report)
        append_oa_event(
            get_agent_workspace(),
            {"event": "session_end", "ts": datetime.now().isoformat(), "outcome": "success", "report_path": report_path_str, "workspace": workspace_str, "artifacts": artifacts_list},
        )
        set_terminal_log_path(None)
        if container_id:
            destroy_job_container(container_id)
            set_agent_container_id(None)
        return os_report

    if not steps:
        _status("Creating plan...")
        _write_checkpoint(steps=[], report_parts=[], step_index=0, lead_sys="", worker_sys="", stack="")
        skip_customize = os.environ.get("OPENARTEMIS_SKIP_CUSTOMIZE", "").strip().lower() in ("1", "true", "yes")
        if skip_customize:
            lead_system = IDENTITY_LEAD + LEAD_SYSTEM
            worker_system = IDENTITY_WORKER + WORKER_SYSTEM
        else:
            customized = customize_for_task(user_request, model=lead_model)
            lead_system = customized["lead"]
            worker_system = customized["worker"]
            if not lead_system.strip().startswith(IDENTITY_LEAD.strip()):
                lead_system = IDENTITY_LEAD + lead_system
            if not worker_system.strip().startswith(IDENTITY_WORKER.strip()):
                worker_system = IDENTITY_WORKER + worker_system

        workspace = get_agent_workspace()
        project_instructions = _load_project_instructions(workspace)
        if project_instructions:
            lead_system += "\n\n---\nProject instructions (OPENARTEMIS.md):\n" + project_instructions
            worker_system += "\n\n---\nProject instructions (OPENARTEMIS.md):\n" + project_instructions

        project_commands = _infer_project_commands(workspace)
        if project_commands:
            cmds_lines = []
            if "unit_tests" in project_commands:
                cmds_lines.append(f"- unit tests: `{project_commands['unit_tests']}`")
            if "lint" in project_commands:
                cmds_lines.append(f"- lint: `{project_commands['lint']}`")
            if "dev_server" in project_commands:
                cmds_lines.append(f"- dev server: `{project_commands['dev_server']}`")
            if cmds_lines:
                cmds_text = "Default project commands you can use with run_terminal:\n" + "\n".join(
                    cmds_lines
                )
                lead_system += "\n\n---\n" + cmds_text
                worker_system += "\n\n---\n" + cmds_text
                append_oa_event(
                    workspace,
                    {
                        "event": "project_commands",
                        "ts": datetime.now().isoformat(),
                        "commands": project_commands,
                    },
                )

        # Build a small context package from any @file/@folder targets the user
        # referenced directly in the request. This keeps the plan grounded in
        # the same files the human is thinking about without scanning the whole
        # repo every time.
        explicit_context = _build_context_snippet(workspace, explicit_targets)
        if explicit_context:
            lead_system += "\n\n---\nCode context (explicit targets):\n" + explicit_context
            worker_system += "\n\n---\nCode context (explicit targets):\n" + explicit_context

        oa_summary = load_oa_summary(workspace, max_chars=1200)
        if oa_summary:
            lead_system += "\n\n---\nOpenArtemis context (recent .oa):\n" + oa_summary
            worker_system += "\n\n---\nOpenArtemis context (recent .oa):\n" + oa_summary

        # Combined pre-planning: Questioner + Translator + Orc router in ONE API call.
        # Replaces 3-5 separate calls for massive speed and cost savings.
        questioner_md, translator_brief, orc_profile, orc_notes = _run_combined_pre_planning(
            client,
            lead_model,
            workspace,
            user_request_clean,
            oa_summary or "",
            status_cb=_status,
        )
        if questioner_md:
            lead_system += "\n\n---\nQuestioner notes:\n" + questioner_md
            worker_system += "\n\n---\nQuestioner notes:\n" + questioner_md
        if translator_brief:
            lead_system += "\n\n---\nTranslator brief:\n" + translator_brief
            worker_system += "\n\n---\nTranslator brief:\n" + translator_brief
        if orc_profile:
            profile_block = f"Orc profile: {orc_profile}\n\n{orc_notes}".strip()
            lead_system += "\n\n---\nOrc routing profile:\n" + profile_block
            worker_system += "\n\n---\nOrc routing profile:\n" + profile_block
        append_oa_event(
            workspace,
            {
                "event": "pre_planning",
                "ts": datetime.now().isoformat(),
                "questioner": (questioner_md[:500] + "…") if len(questioner_md) > 500 else questioner_md,
                "translator": (translator_brief[:500] + "…") if len(translator_brief) > 500 else translator_brief,
                "orc_profile": orc_profile,
                "orc_notes": (orc_notes[:300] + "…") if len(orc_notes) > 300 else orc_notes,
            },
        )

        _status("Choosing stack and steps (Plan phase)...")
        lead_model_used = lead_model
        heartbeat = _start_heartbeat("Still creating plan...", 12)
        lead_user_content = user_request or ""
        if oa_summary and (user_request or "").strip():
            lead_user_content = f"Context (existing project in this folder):\n{oa_summary}\n\nUser request: {lead_user_content}"
        try:
            for attempt in range(2):
                try:
                    lead_messages = [
                        {"role": "system", "content": lead_system or ""},
                        {"role": "user", "content": lead_user_content},
                    ]
                    model_for_lead = (lead_model_used or "").strip() or FALLBACK_MODEL
                    resp = create_with_budget(
                        client,
                        model_for_lead,
                        lead_messages,
                        max_tokens=get_max_tokens_or_default(),
                    )
                    break
                except Exception as e:
                    et = classify_exception(e)
                    if et == ErrorType.RATE_LIMIT and attempt == 0:
                        log_audit(replay_path, "rate_limit", model=FALLBACK_MODEL)
                        _append_blocker(f"429 TPM | Using fallback for plan: {FALLBACK_MODEL}")
                        lead_model_used = FALLBACK_MODEL
                        delay = get_retry_after_seconds(e) or 30.0
                        _status(f"THROTTLED: retry in {delay:.0f}s")
                        retry_until_ts = time.time() + delay
                        _write_throttled(retry_until_ts)
                        if delay:
                            token_budget_set_retry_after(delay)
                            time.sleep(delay)
                        _clear_throttled()
                        continue
                    log_audit(replay_path, "error", error=str(e), error_type=et.value)
                    _append_blocker(f"{et.value} | {e!s}")
                    raise
            content = (resp.choices[0].message.content or "").strip()
            data = _extract_json_object(content)
            if data is not None:
                steps = data.get("steps", [])[:max_steps]
                chosen_stack = (data.get("stack") or "").strip()
            else:
                append_oa_event(
                    get_agent_workspace(),
                    {"event": "session_end", "ts": datetime.now().isoformat(), "outcome": "error", "report_path": "", "workspace": str(get_agent_workspace().resolve()), "artifacts": []},
                )
                hooks_fire("session_end", outcome="error", error="Could not create plan")
                set_terminal_log_path(None)
                if container_id:
                    destroy_job_container(container_id)
                    set_agent_container_id(None)
                return "Could not create plan. Please try rephrasing."
            if not steps:
                append_oa_event(
                    get_agent_workspace(),
                    {"event": "session_end", "ts": datetime.now().isoformat(), "outcome": "error", "report_path": "", "workspace": str(get_agent_workspace().resolve()), "artifacts": []},
                )
                hooks_fire("session_end", outcome="error", error="No steps in plan")
                set_terminal_log_path(None)
                if container_id:
                    destroy_job_container(container_id)
                    set_agent_container_id(None)
                return "No steps in plan."
            start_index = 0
            log_phase(replay_path, "lead", "plan_created")
        finally:
            heartbeat.set()

    worker_max_tokens = get_max_tokens_full_file() if _is_single_file_plan(steps, chosen_stack) else get_max_tokens_or_default()

    if plan_mode:
        _status("Plan mode: writing plan (no execution).")
        plan_report = "## Plan (approval required)\n\nRun the same request without --plan to execute.\n\n```json\n" + json.dumps({"steps": steps}, indent=2) + "\n```"
        execute_hint = "\n\nTo execute this plan: run Agent again, use the same (or similar) prompt, and choose **No** for 'Plan only first'."
        if output_path:
            output_path.parent.mkdir(parents=True, exist_ok=True)
            output_path.write_text(
                f"# Agent Plan — {user_request}\n\n{datetime.now().isoformat()}\n\n---\n\n{plan_report}{execute_hint}",
                encoding="utf-8",
            )
            _write_done("plan")
        append_oa_event(
            get_agent_workspace(),
            {"event": "session_end", "ts": datetime.now().isoformat(), "outcome": "plan", "report_path": str(output_path.resolve()) if output_path else "", "workspace": str(get_agent_workspace().resolve()), "artifacts": []},
        )
        hooks_fire("session_end", outcome="plan", report=plan_report)
        set_terminal_log_path(None)
        if container_id:
            destroy_job_container(container_id)
            set_agent_container_id(None)
        return plan_report

    recent_files: list[str] = []
    recent_changes: list[str] = []
    # Track per-step status for accurate checklist reporting
    step_status: dict[int, str] = {}

    # Simple internal task ledger: remaining vs completed actions for this job.
    task_ledger = {
        "remaining": [s.get("action", "") for s in steps],
        "completed": [],
    }

    _write_checkpoint(steps, report_parts, start_index, lead_system, worker_system, chosen_stack)
    append_oa_event(
        get_agent_workspace(),
        {
            "event": "plan",
            "ts": datetime.now().isoformat(),
            "stack": chosen_stack,
            "steps": steps[:30],
            "step_count": len(steps),
        },
    )
    append_oa_event(
        get_agent_workspace(),
        {
            "event": "task_ledger",
            "ts": datetime.now().isoformat(),
            "ledger": {
                "remaining": task_ledger["remaining"][:50],
                "completed": task_ledger["completed"][-20:],
            },
        },
    )

    for idx in range(start_index, len(steps)):
        _wait_if_paused()
        if _is_canceled():
            log_audit(replay_path, "canceled")
            _status("Canceled by user.")
            _clear_blockers()
            if cancel_path and cancel_path.exists():
                try:
                    cancel_path.unlink(missing_ok=True)
                except Exception:
                    pass
                if output_path:
                    output_path.parent.mkdir(parents=True, exist_ok=True)
                    _ws = get_agent_workspace().resolve()
                    _arts = _get_main_artifact_paths(_ws, steps)
                    _loc = ["\n\n---\n## Output locations", f"- **Report:** `{output_path.resolve()}`", f"- **Workspace:** `{_ws}`"]
                    if _arts:
                        _loc.append("- **Main file(s):**")
                        for _a in _arts:
                            _loc.append(f"  - `{_a}`")
                    else:
                        _loc.append("- **Main file(s):** (none)")
                    _loc_txt = "\n".join(_loc)
                    output_path.write_text(
                        f"# Canceled\n\nRun canceled by user.\n\n{datetime.now().isoformat()}\n\n---\n\nPartial report:\n\n" + "\n\n".join(report_parts) + _loc_txt,
                        encoding="utf-8",
                    )
                _write_done("canceled", error="Canceled by user.")
                append_oa_event(
                    get_agent_workspace(),
                    {"event": "session_end", "ts": datetime.now().isoformat(), "outcome": "canceled", "report_path": str(output_path.resolve()) if output_path else "", "workspace": str(get_agent_workspace().resolve()), "artifacts": _get_main_artifact_paths(get_agent_workspace(), steps)},
                )
                hooks_fire("session_end", outcome="canceled")
                set_terminal_log_path(None)
                if container_id:
                    destroy_job_container(container_id)
                    set_agent_container_id(None)
                return "Canceled by user."
        step = steps[idx]
        step_id = step.get("id", 0)
        action = step.get("action", "")
        log_phase(replay_path, "worker", "step_started", step_id)
        _status(f"Step {step_id}: {action[:50]}...")
        _status("Planning next step...")
        goal_block = f"Goal: {user_request}"
        if chosen_stack:
            goal_block += f"\n\nStack: {chosen_stack}"
        goal_block += f"\n\nCurrent step: Step {step_id}: {action}"
        if recent_files or recent_changes:
            goal_block += "\n\nOpen/recent: " + (", ".join(recent_files[-10:]) if recent_files else "(none)")
            goal_block += ". Recent changes: " + ("; ".join(recent_changes[-5:]) if recent_changes else "(none)")
        messages = [
            {"role": "system", "content": worker_system},
            {"role": "user", "content": goal_block},
        ]
        worker_model_used = worker_model
        max_turns = get_max_turns_per_step()

        # Change-budget counters for this step (very lightweight heuristic).
        writes_this_step = 0
        patches_this_step = 0
        replaces_this_step = 0
        commands_this_step = 0

        for _ in range(max_turns):
            if _is_canceled():
                log_audit(replay_path, "canceled")
                _status("Canceled by user.")
                _clear_blockers()
                if cancel_path and cancel_path.exists():
                    try:
                        cancel_path.unlink(missing_ok=True)
                    except Exception:
                        pass
                if output_path:
                    output_path.parent.mkdir(parents=True, exist_ok=True)
                    _ws = get_agent_workspace().resolve()
                    _arts = _get_main_artifact_paths(_ws, steps)
                    _loc = ["\n\n---\n## Output locations", f"- **Report:** `{output_path.resolve()}`", f"- **Workspace:** `{_ws}`"]
                    if _arts:
                        _loc.append("- **Main file(s):**")
                        for _a in _arts:
                            _loc.append(f"  - `{_a}`")
                    else:
                        _loc.append("- **Main file(s):** (none)")
                    _loc_txt = "\n".join(_loc)
                    output_path.write_text(
                        f"# Canceled\n\nRun canceled by user.\n\n{datetime.now().isoformat()}\n\n---\n\nPartial report:\n\n" + "\n\n".join(report_parts) + _loc_txt,
                        encoding="utf-8",
                    )
                _write_done("canceled", error="Canceled by user.")
                append_oa_event(
                    get_agent_workspace(),
                    {"event": "session_end", "ts": datetime.now().isoformat(), "outcome": "canceled", "report_path": str(output_path.resolve()) if output_path else "", "workspace": str(get_agent_workspace().resolve()), "artifacts": _get_main_artifact_paths(get_agent_workspace(), steps)},
                )
                hooks_fire("session_end", outcome="canceled")
                set_terminal_log_path(None)
                if container_id:
                    destroy_job_container(container_id)
                    set_agent_container_id(None)
                return "Canceled by user."
            _wait_if_paused()
            worker_heartbeat = _start_heartbeat("Calling model…", 12)
            try:
                for _api_attempt in range(2):
                    if _api_attempt > 0:
                        log_audit(replay_path, "retry", attempt=_api_attempt + 1)
                    try:
                        model_for_worker = (worker_model_used or "").strip() or FALLBACK_MODEL
                        messages_to_send = _trim_messages_to_budget(
                            messages, max_tokens=worker_max_tokens
                        )
                        resp = create_with_budget(
                            client,
                            model_for_worker,
                            messages_to_send,
                            tools=get_all_agent_tools(),
                            tool_choice="auto",
                            max_tokens=worker_max_tokens,
                        )
                        break
                    except Exception as e:
                        et = classify_exception(e)
                        if et == ErrorType.RATE_LIMIT and _api_attempt == 0:
                            log_audit(replay_path, "rate_limit", model=FALLBACK_MODEL)
                            _append_blocker(f"429 TPM | Using fallback: {FALLBACK_MODEL}")
                            worker_model_used = FALLBACK_MODEL
                            delay = get_retry_after_seconds(e) or 30.0
                            _status(f"THROTTLED: retry in {delay:.0f}s")
                            retry_until_ts = time.time() + delay
                            _write_throttled(retry_until_ts)
                            if delay:
                                token_budget_set_retry_after(delay)
                                time.sleep(delay)
                            _clear_throttled()
                            continue
                        log_audit(replay_path, "error", error=str(e), error_type=et.value)
                        _append_blocker(f"{et.value} | {e!s}")
                        raise
            finally:
                worker_heartbeat.set()
            msg = resp.choices[0].message
            # Use Anthropic-native format to preserve tool_use blocks
            if hasattr(msg, 'to_anthropic_dict'):
                messages.append(msg.to_anthropic_dict())
            else:
                messages.append({"role": msg.role, "content": msg.content or ""})

            if not msg.tool_calls:
                report_parts.append(f"Step {step_id}: {msg.content or '(no output)'}")
                step_status[int(step_id) if isinstance(step_id, int) else idx] = "done"
                break

            for tc in msg.tool_calls:
                name = tc.function.name
                try:
                    args = json.loads(tc.function.arguments)
                except json.JSONDecodeError:
                    args = {}
                if name == "read_file":
                    _status("Reading workspace...")
                elif name == "list_dir":
                    _status("Checking file...")
                elif name == "write_file":
                    _status(f"Writing {args.get('path', '')}...")
                elif name == "run_terminal":
                    cmd = (args.get("command") or "")[:40]
                    if "install" in cmd.lower() or "pip" in cmd.lower() or "npm" in cmd.lower():
                        _status("Installing dependencies...")
                    elif "server" in cmd.lower() or "http" in cmd.lower():
                        _status("Starting dev server...")
                    else:
                        _status(f"Running: {cmd}...")
                elif name == "take_screenshot":
                    _status("Taking screenshot and reviewing...")
                    _status("Checking browser...")
                # Hooks and permission check for write/run/edit
                if name in ("write_file", "run_terminal", "search_replace", "apply_patch"):
                    hook_event_before = "before_run_cmd" if name == "run_terminal" else "before_edit"
                    if not hooks_fire(hook_event_before, name=name, args=args):
                        result = "Hook denied action."
                    else:
                        mode = get_permission_mode()
                        if mode == "deny-writes":
                            result = "Permission denied (deny-writes mode). No writes or runs allowed."
                        elif permission_callback is not None:
                            if mode == "ask":
                                allow = permission_callback(name, args)
                            elif mode == "auto-edit":
                                allow = (name != "run_terminal") or permission_callback(name, args)
                            else:
                                allow = True
                            if not allow:
                                result = "User denied permission."
                            else:
                                result = execute_agent_tool(name, args)
                        else:
                            result = execute_agent_tool(name, args)
                    hook_event_after = "after_run_cmd" if name == "run_terminal" else "after_edit"
                    hooks_fire(hook_event_after, name=name, args=args, result=result)
                else:
                    result = execute_agent_tool(name, args)
                log_tool(replay_path, step_id, "worker", name, args, result)
                path = (args.get("path") or "").strip()
                if path and name in ("read_file", "write_file", "search_replace", "apply_patch"):
                    recent_files = [path] + [p for p in recent_files if p != path][:9]
                if name == "write_file" and path:
                    writes_this_step += 1
                    recent_changes = (recent_changes + [f"Wrote {path}"])[-5:]
                elif name == "search_replace" and path:
                    replaces_this_step += 1
                    recent_changes = (recent_changes + [f"Replaced in {path}"])[-5:]
                elif name == "apply_patch" and path:
                    patches_this_step += 1
                    recent_changes = (recent_changes + [f"Applied patch to {path}"])[-5:]
                if name == "run_terminal":
                    commands_this_step += 1
                if name == "run_terminal" and "server" in (args.get("command") or "").lower():
                    _status("Waiting for server...")
                _status("Reviewing output...")
                content = _truncate_tool_result(result, tool_name=name)
                messages.append({"role": "tool", "tool_call_id": tc.id, "content": content})
        else:
            report_parts.append(f"Step {step_id}: (max turns)")
            step_status[int(step_id) if isinstance(step_id, int) else idx] = "max_turns"
        log_phase(replay_path, "worker", "step_finished", step_id)

        # Update internal ledger: move this step from remaining to completed.
        try:
            if action in task_ledger["remaining"]:
                task_ledger["remaining"].remove(action)
            task_ledger["completed"].append(action)
        except Exception:
            pass

        # Record a short change-budget + ledger snapshot into .oa
        change_summary = {
            "writes": writes_this_step,
            "patches": patches_this_step,
            "replacements": replaces_this_step,
            "commands": commands_this_step,
        }
        append_oa_event(
            get_agent_workspace(),
            {
                "event": "step_done",
                "ts": datetime.now().isoformat(),
                "step_id": step_id,
                "action": (action or "")[:200],
                "files_touched": list(recent_files)[:20],
                "change_summary": change_summary,
            },
        )
        append_oa_event(
            get_agent_workspace(),
            {
                "event": "task_ledger",
                "ts": datetime.now().isoformat(),
                "ledger": {
                    "remaining": task_ledger["remaining"][:50],
                    "completed": task_ledger["completed"][-20:],
                },
            },
        )

        # Persist checkpoint after each step so we can roll back or resume.
        _status(f"Verifying step {step_id}...")
        _write_checkpoint(steps, report_parts, idx + 1, lead_system, worker_system, chosen_stack)

    # Post-execution verify-and-fix: capture app state, then 1-2 worker turns to fix/improve
    verify_entrypoint = None
    if steps:
        files_in_plan = {s.get("file", "").strip() for s in steps if s.get("file")}
        for f in ("index.html", "index.htm"):
            if f in files_in_plan and (get_agent_workspace() / f).exists():
                verify_entrypoint = f
                break
        if not verify_entrypoint and len(files_in_plan) == 1:
            only = list(files_in_plan)[0]
            if (get_agent_workspace() / only).exists():
                verify_entrypoint = only
    if verify_entrypoint:
        _status("Verify-and-fix: capturing app state...")
        try:
            screenshot_result = execute_agent_tool(
                "take_screenshot",
                {
                    "url_or_path": verify_entrypoint,
                    "prompt": "Does this match a complete, working result for the user's goal? List any bugs, missing features, or broken UI. If it looks good, say so; if not, list what to fix.",
                },
            )
        except Exception as e:
            screenshot_result = f"Screenshot failed: {e}"
        append_oa_event(
            get_agent_workspace(),
            {"event": "screenshot_feedback", "ts": datetime.now().isoformat(), "entrypoint": verify_entrypoint, "summary": (screenshot_result or "")[:500]},
        )
        verify_prompt = f"Goal: {user_request}\n\nScreenshot assessment of the app:\n\n{screenshot_result}\n\nIf the assessment says something is wrong or missing, fix it with write_file or search_replace. If it already looks good, you may reply briefly that no changes are needed. Be concise."
        v_messages = [
            {"role": "system", "content": worker_system},
            {"role": "user", "content": verify_prompt},
        ]
        for _verify_round in range(2):
            if _is_canceled():
                break
            try:
                v_to_send = _trim_messages_to_budget(
                    v_messages, max_tokens=worker_max_tokens
                )
                resp_v = create_with_budget(
                    client,
                    (worker_model or "").strip() or FALLBACK_MODEL,
                    v_to_send,
                    tools=get_all_agent_tools(),
                    tool_choice="auto",
                    max_tokens=worker_max_tokens,
                )
            except Exception as e:
                report_parts.append(f"Verify-and-fix: error — {e}")
                break
            msg_v = resp_v.choices[0].message
            if hasattr(msg_v, 'to_anthropic_dict'):
                v_messages.append(msg_v.to_anthropic_dict())
            else:
                v_messages.append({"role": msg_v.role, "content": msg_v.content or ""})
            if not msg_v.tool_calls:
                report_parts.append(f"Verify-and-fix: {msg_v.content or 'done'}")
                break
            for tc in msg_v.tool_calls:
                name = tc.function.name
                try:
                    args = json.loads(tc.function.arguments)
                except json.JSONDecodeError:
                    args = {}
                if name in ("write_file", "run_terminal", "search_replace", "apply_patch"):
                    hook_before = "before_run_cmd" if name == "run_terminal" else "before_edit"
                    if not hooks_fire(hook_before, name=name, args=args):
                        result = "Hook denied action."
                    else:
                        mode = get_permission_mode()
                        if mode == "deny-writes":
                            result = "Permission denied (deny-writes mode)."
                        elif permission_callback is not None:
                            if mode == "ask":
                                allow = permission_callback(name, args)
                            elif mode == "auto-edit":
                                allow = (name != "run_terminal") or permission_callback(name, args)
                            else:
                                allow = True
                            result = execute_agent_tool(name, args) if allow else "User denied permission."
                        else:
                            result = execute_agent_tool(name, args)
                    hook_after = "after_run_cmd" if name == "run_terminal" else "after_edit"
                    hooks_fire(hook_after, name=name, args=args, result=result)
                else:
                    result = execute_agent_tool(name, args)
                content = _truncate_tool_result(result, tool_name=name)
                v_messages.append({"role": "tool", "tool_call_id": tc.id, "content": content})
        else:
            report_parts.append("Verify-and-fix: completed (max rounds)")

    report = "\n\n".join(report_parts)

    # Lightweight reviewer pass: have the model look at the plan + report and call out risks
    # and how to run/undo in plain language. This uses a single extra chat completion and
    # can be disabled via OPENARTEMIS_AGENT_ENABLE_REVIEWER=0.
    reviewer_notes = ""
    if agent_reviewer_enabled():
        try:
            review_messages = [
                {
                    "role": "system",
                    "content": (
                        "You are a senior code reviewer for Artemis. You only see the goal, the high-level "
                        "plan steps, and the agent's report (no full diffs). Evaluate the run against this rubric:\n"
                        "- Goal alignment: did the work actually address the stated goal?\n"
                        "- Safety & scope: any risky large rewrites, missing rollbacks, or surprising side effects?\n"
                        "- Verification: were tests/linters/diagnostics or UI checks run, and are there gaps?\n\n"
                        "Then summarize in three short sections:\n"
                        "1) Summary of the goal and what changed.\n"
                        "2) How to run the app/tests (based on any hints in the report or common defaults).\n"
                        "3) How a user could roll back the changes (e.g. from checkpoints or git).\n"
                        "Be concise and concrete."
                    ),
                },
                {
                    "role": "user",
                    "content": json.dumps(
                        {
                            "goal": user_request,
                            "steps": steps,
                            "report": report[-8000:],  # cap for safety
                            # Short summary of recent context (last runs, UI feedback, playtests)
                            "workspace_context": load_oa_summary(get_agent_workspace(), max_chars=800),
                        },
                        indent=2,
                    ),
                },
            ]
            review_resp = create_with_budget(
                client,
                (lead_model or "").strip() or FALLBACK_MODEL,
                review_messages,
                max_tokens=get_max_tokens_or_default(),
            )
            reviewer_notes = (review_resp.choices[0].message.content or "").strip()
        except Exception:
            reviewer_notes = ""
    checklist_lines = ["", "---", "## Checklist"]
    for idx, step in enumerate(steps):
        action = step.get("action") or str(step.get("id", ""))
        sid = step.get("id", idx)
        status = step_status.get(int(sid) if isinstance(sid, int) else idx, "pending")
        if status == "done":
            checkbox = "x"
            suffix = ""
        elif status == "max_turns":
            checkbox = " "
            suffix = " (not fully completed: max turns reached)"
        else:
            checkbox = " "
            suffix = ""
        checklist_lines.append(f"- [{checkbox}] {action}{suffix}")
    report = report + "\n".join(checklist_lines)
    if reviewer_notes:
        report = report + "\n\n---\n## Reviewer notes\n\n" + reviewer_notes
    _status("Updating report...")
    _status("Finalizing...")
    _status("Done")
    _clear_blockers()
    hooks_fire("session_end", outcome="success", report=report)

    ws = get_agent_workspace().resolve()
    report_path_str = str(output_path.resolve()) if output_path else ""
    workspace_str = str(ws)
    artifacts_list = _get_main_artifact_paths(ws, steps)
    locations_lines = [
        "",
        "---",
        "## Output locations",
        f"- **Report:** `{report_path_str}`",
        f"- **Workspace:** `{workspace_str}`",
    ]
    if artifacts_list:
        locations_lines.append("- **Main file(s):**")
        for a in artifacts_list:
            locations_lines.append(f"  - `{a}`")
    else:
        locations_lines.append("- **Main file(s):** (none)")
    locations_section = "\n".join(locations_lines)

    if output_path:
        output_path.parent.mkdir(parents=True, exist_ok=True)
        output_path.write_text(
            f"# Agent Report — {user_request}\n\n{datetime.now().isoformat()}\n\n---\n\n{report}{locations_section}",
            encoding="utf-8",
        )
        _write_done("success")
    append_oa_event(
        get_agent_workspace(),
        {"event": "session_end", "ts": datetime.now().isoformat(), "outcome": "success", "report_path": report_path_str, "workspace": workspace_str, "artifacts": artifacts_list},
    )

    set_terminal_log_path(None)
    if container_id:
        destroy_job_container(container_id)
        set_agent_container_id(None)
    return report


# ═══════════════════════════════════════════════════════════════════════════════
# E2B Cloud Sandbox Agent — runs entirely inside E2B Linux VM
# ═══════════════════════════════════════════════════════════════════════════════

_E2B_BASE_SYSTEM = """\
You are an expert programmer. Build COMPLETE, WORKING projects fast.

=== RULES ===
- NO explanations, NO planning text — ONLY tool calls until the manifest
- Write ALL files in FIRST response
- NO placeholders, ALL complete code

=== PHASE 1: BUILD (FIRST response) ===
Write EVERYTHING needed. NO stubs, NO TODOs.

=== PHASE 2: VERIFY ===
- Start server: run_terminal("python3 -m http.server 8000 &")
- Run quick_verify("http://localhost:8000") — if it returns "responding", that is enough
- Only call take_screenshot if quick_verify explicitly says "not responding"
- If both fail, skip and go to manifest — do NOT retry forever

=== PHASE 3: FIX (max 1 attempt) ===
Only if verify found a clear JavaScript error:
- One targeted search_replace fix
- Then go straight to manifest

=== PHASE 4: MANIFEST ===
Write build.oac with the actual project info (JSON).

=== CRITICAL ===
- FIRST response = ONLY tool calls (write_file etc.)
- Write build.oac LAST (triggers completion)"""


def _build_e2b_system(user_request: str, spec: Any = None, template_code: str | None = None) -> str:
    """Return E2B agent system prompt with spec, template, and user request embedded."""
    parts = [_E2B_BASE_SYSTEM]

    # Inject expanded spec if available
    if spec is not None and hasattr(spec, "to_prompt_block"):
        parts.append("\n\n" + spec.to_prompt_block())

    # Inject golden template if available
    if template_code:
        parts.append(
            "\n\n=== REFERENCE IMPLEMENTATION ===\n"
            "Adapt this working code to match the user's request. "
            "Use the same patterns, physics, and structure.\n"
            f"```html\n{template_code}\n```\n"
            "=== END REFERENCE ==="
        )

    # Always include the user request
    parts.append(f"\n\n=== USER REQUEST ===\n{user_request.strip()}")

    return "\n".join(parts)


def run_agent_e2b(
    user_request: str,
    sandbox: Any,
    on_status: Callable[[str], None] | None = None,
    max_turns: int = 15,  # Reduced from 25 for speed
) -> str:
    """Run the agent loop entirely inside an E2B cloud sandbox.

    Args:
        user_request: What the user wants to build
        sandbox: E2BSandbox instance (already started)
        on_status: Callback for status updates
        max_turns: Maximum API call turns

    Returns:
        Final report string
    """
    from openartemis.agent.e2b_sandbox import E2B_AGENT_TOOLS, execute_e2b_tool
    from openartemis.agent.activity_tracker import ActivityTracker, EventType
    from openartemis.token_budget import create_with_budget
    from openartemis.context_window import compress_tool_result, count_messages_tokens

    # Initialize activity tracker
    tracker = ActivityTracker()
    if hasattr(sandbox, 'sandbox_id') and sandbox.sandbox_id:
        tracker.set_sandbox_id(sandbox.sandbox_id)
        tracker.add_event(EventType.PHASE_CHANGE, "Agent session started", 
                         {"sandbox_id": sandbox.sandbox_id})

    client = _get_openai_client()
    # Use cheap build model for tool turns; allow override via OPENARTEMIS_E2B_MODEL
    e2b_model = os.environ.get("OPENARTEMIS_E2B_MODEL", "").strip()
    if e2b_model:
        worker_model = resolve_artemis_model(e2b_model) if "artemis" in e2b_model.lower() else e2b_model
    else:
        worker_model = get_build_model()  # Haiku by default — cheap + fast for tool turns

    # Phase timing for optimization
    import time
    phase_start_time = time.time()
    PHASE_TIMEOUTS = {
        "build": 120,  # 2 minutes max for build
        "verify": 90,  # 90 seconds max for verify
        "fix": 60,     # 1 minute max per fix attempt
        "manifest": 30 # 30 seconds max for manifest
    }

    def _status(msg: str) -> None:
        if on_status:
            on_status(msg)
            
    def _track_activity(event_type: EventType, description: str, details: dict = None, status: str = "success") -> None:
        """Track an activity event."""
        tracker.add_event(event_type, description, details, status)
        # Also call the original status callback for backward compatibility
        if on_status:
            on_status(description)

    # ── Prompt expansion: turn vague request into structured spec + template ──
    from openartemis.agent.prompt_expander import expand_prompt
    from openartemis.agent.golden_templates import get_template
    from openartemis.agent.circuit_breaker import CircuitBreaker, Action as CBAction
    spec = expand_prompt(user_request)
    template_code = get_template(spec.template_id)
    _status(f"Spec: {spec.project_type} | template: {spec.template_id or 'none'} | complexity: {spec.complexity}")

    # ── Circuit breaker + TDD setup ──
    cb = CircuitBreaker()
    test_script = spec.generate_test_script()
    # Initialize git for checkpoint/rollback
    try:
        sandbox.git_init()
        _status("Git initialized for checkpoint/rollback")
    except Exception:
        pass  # Git init failure is non-fatal

    messages: list[dict[str, Any]] = [
        {"role": "system", "content": _build_e2b_system(user_request, spec=spec, template_code=template_code)},
        {"role": "user", "content": f"Build this NOW. Write all files, verify, then write build.oac.\n\n{user_request}"},
    ]

    report = "Agent completed."
    files_written: list[str] = []
    phase = "build"
    fix_attempts = 0
    _tests_run = False  # Track whether we've run TDD tests this build cycle

    def _truncate(text: str, max_len: int = 4000) -> str:
        if len(text) <= max_len:
            return text
        return text[:max_len] + "\n... [truncated]"

    # ── Async test runner: fires tests during API latency ──
    import threading
    _async_test_result: dict | None = None
    _async_test_lock = threading.Lock()

    def _run_tests_async():
        """Run test script in background thread."""
        nonlocal _async_test_result
        if not test_script:
            return
        try:
            result = sandbox.run_tests(test_script)
            with _async_test_lock:
                _async_test_result = result
        except Exception:
            pass

    def _get_async_test_result() -> dict | None:
        """Retrieve and clear async test result if available."""
        nonlocal _async_test_result
        with _async_test_lock:
            r = _async_test_result
            _async_test_result = None
            return r

    for turn in range(max_turns):
        # Check phase timeout
        current_phase_time = time.time() - phase_start_time
        if phase in PHASE_TIMEOUTS and current_phase_time > PHASE_TIMEOUTS[phase]:
            if phase == "verify":
                # Fallback: assume verification passed if timeout
                _status(f"Verification timeout - assuming success after {PHASE_TIMEOUTS[phase]}s")
                phase = "manifest"
            elif phase == "fix":
                # Move to manifest after too many fix attempts
                _status(f"Fix timeout - moving to manifest after {PHASE_TIMEOUTS[phase]}s")
                phase = "manifest"
            else:
                _status(f"Phase {phase} timeout - moving to next phase")
                if phase == "build":
                    phase = "verify"
                elif phase == "manifest":
                    break
            phase_start_time = time.time()  # Reset timer for new phase
            
        if phase == "build":
            _status(f"Phase 1: Building... (turn {turn + 1})")
            tracker.current_phase = "Build"
            tracker.add_event(EventType.PHASE_CHANGE, "Phase 1: Building...", {"turn": turn + 1})
        elif phase == "verify":
            _status(f"Phase 2: Verifying... (turn {turn + 1})")
            tracker.current_phase = "Verify"
            tracker.add_event(EventType.PHASE_CHANGE, "Phase 2: Verifying...", {"turn": turn + 1})
        elif phase == "fix":
            _status(f"Phase 3: Fixing (attempt {fix_attempts})...")
            tracker.current_phase = "Fix"
            tracker.add_event(EventType.PHASE_CHANGE, "Phase 3: Fixing...", {"attempt": fix_attempts})
        elif phase == "manifest":
            _status("Phase 4: Writing build manifest...")
            tracker.current_phase = "Manifest"
            tracker.add_event(EventType.PHASE_CHANGE, "Phase 4: Writing build manifest...")

        try:
            from openartemis.config import get_max_tokens_full_file
            max_tok = get_max_tokens_full_file()
            resp = create_with_budget(
                client,
                worker_model,
                messages,
                tools=E2B_AGENT_TOOLS,
                tool_choice="auto",
                max_tokens=max_tok,
            )
        except Exception as e:
            from openartemis.errors import classify_exception, ErrorType
            from openartemis.retry import get_retry_after_seconds
            et = classify_exception(e)
            if et == ErrorType.RATE_LIMIT:
                delay = get_retry_after_seconds(e) or 30.0
                _status(f"Rate limited — retrying in {delay:.0f}s...")
                import time
                time.sleep(delay)
                continue
            report = f"Error: {e}"
            break

        msg = resp.choices[0].message
        # Use Anthropic-native format to preserve tool_use blocks
        if hasattr(msg, 'to_anthropic_dict'):
            messages.append(msg.to_anthropic_dict())
        else:
            messages.append({"role": msg.role, "content": msg.content or ""})

        if not msg.tool_calls:
            report = msg.content or "Build completed."
            _status("Phase 5: Report complete.")
            break

        # Execute tool calls against E2B sandbox
        has_write = False
        has_screenshot = False
        has_fix = False
        has_oac = False

        for tc in msg.tool_calls:
            name = tc.function.name
            try:
                args = json.loads(tc.function.arguments)
            except json.JSONDecodeError:
                args = {}

            # Status messages with activity tracking
            if name == "write_file":
                path = args.get("path", "?")
                content = args.get("content", "")
                lines = content.count("\n") + 1 if content else 0
                _status(f"Writing {path} ({lines} lines)...")
                _track_activity(EventType.FILE_WRITE, f"Writing {path} ({lines} lines)", 
                              {"path": path, "lines": lines})
                has_write = True
                if path.endswith(".oac"):
                    has_oac = True
            elif name == "read_file":
                path = args.get("path", "?")
                _status(f"Reading {path}...")
                _track_activity(EventType.FILE_READ, f"Reading {path}", {"path": path})
            elif name == "run_terminal":
                cmd = (args.get("command") or "?")[:50]
                _status(f"Running: {cmd}...")
                _track_activity(EventType.COMMAND_RUN, f"Running: {cmd}", {"command": cmd})
            elif name == "search_replace" or name == "apply_patch":
                path = args.get("path", "?")
                _status(f"Fixing {path}...")
                _track_activity(EventType.ERROR_FIX, f"Fixing {path}", {"path": path})
                has_fix = True
            elif name == "take_screenshot":
                _status("Verifying with screenshot...")
                _track_activity(EventType.SCREENSHOT, "Verifying with screenshot")
                has_screenshot = True
            elif name == "list_dir":
                _status("Listing files...")

            # Execute against E2B
            result = execute_e2b_tool(sandbox, name, args)

            # Track files with enhanced activity tracking
            if name == "write_file" and "Wrote" in (result or ""):
                fpath = args.get("path", "?")
                if fpath not in files_written:
                    files_written.append(fpath)
                _status(f"Created {fpath}")
                _track_activity(EventType.FILE_WRITE, f"Created {fpath}", {"path": fpath}, "success")
            elif name == "run_terminal":
                # Track command completion
                cmd = args.get("command", "")[:50]
                exit_code = None
                if "exit" in str(result).lower():
                    try:
                        # Try to extract exit code from result
                        import re
                        exit_match = re.search(r'exit (\d+)', str(result))
                        if exit_match:
                            exit_code = int(exit_match.group(1))
                    except:
                        pass
                _track_activity(EventType.COMMAND_RUN, f"Command completed: {cmd}", 
                              {"command": cmd, "exit_code": exit_code, "result": result[:100]}, 
                              "success" if exit_code in [0, None] else "error")

            # Compress tool result before appending (keeps context pristine)
            compressed = compress_tool_result(name, result or "")
            messages.append({
                "role": "tool",
                "tool_call_id": tc.id,
                "content": compressed,
            })

        # Phase transitions - prevent regression
        if phase == "build" and (has_screenshot or (not has_write and not has_fix)):
            phase = "verify"
        if phase == "verify" and has_fix:
            phase = "fix"
            fix_attempts += 1
        if phase == "fix" and has_screenshot:
            phase = "verify"
        if has_oac:
            phase = "manifest"
            # Once in manifest, don't allow regression - finish quickly
            break

        # Fire async tests in background (runs during next API call latency)
        if has_write and test_script and phase == "build":
            threading.Thread(target=_run_tests_async, daemon=True).start()

        # ── TDD: Run mechanical tests when transitioning to verify ──
        if phase == "verify" and test_script and not _tests_run:
            _tests_run = True
            _status("Running mechanical tests...")
            try:
                # Check if async results are already available
                test_results = _get_async_test_result()
                if test_results is None:
                    # Async wasn't ready — run synchronously
                    test_results = sandbox.run_tests(test_script)
                passed = test_results.get("passed", 0)
                failed = test_results.get("failed", 0)
                _status(f"Tests: {passed} passed, {failed} failed")
                tracker.add_event(EventType.PHASE_CHANGE, f"TDD: {passed} passed, {failed} failed",
                                 {"test_results": test_results})

                if cb.all_passed(test_results):
                    # All tests passed — save checkpoint
                    commit = sandbox.git_checkpoint(f"tests-passed-turn-{turn}")
                    if commit:
                        cb._checkpoints.append(commit)
                        _status(f"Checkpoint saved: {commit[:8]}")
                else:
                    # Some tests failed — run through circuit breaker
                    action = cb.record_batch_results(test_results)
                    errors_str = "; ".join(test_results.get("errors", [])[:3])

                    if action == CBAction.ROLLBACK_AND_ESCALATE:
                        # Roll back to last good state
                        _status(f"Circuit breaker: escalating to {cb.get_current_model()}")
                        if cb._checkpoints:
                            sandbox.git_rollback(cb._checkpoints[-1])
                            _status("Rolled back to last checkpoint")
                        # Switch model
                        worker_model = cb.get_current_model()
                        # Inject failure context into conversation
                        escalation_msg = cb.get_escalation_context()
                        cb.clear_escalation_context()
                        messages.append({
                            "role": "user",
                            "content": f"{escalation_msg}\n\nRebuild the project. The previous approach failed these tests: {errors_str}"
                        })
                        phase = "build"
                        _tests_run = False
                        phase_start_time = time.time()
                        tracker.add_event(EventType.PHASE_CHANGE, f"Circuit breaker escalated to {worker_model}")
                        continue

                    elif action == CBAction.HARD_FAIL:
                        _status("Circuit breaker: hard fail — all model tiers exhausted")
                        report = f"Build failed mechanical tests after exhausting all model tiers.\nFailing tests: {errors_str}"
                        break

                    elif action == CBAction.RETRY:
                        # Feed errors back to current model
                        messages.append({
                            "role": "user",
                            "content": f"[TEST FAILURES] Fix these issues: {errors_str}\nDo NOT rewrite from scratch — use search_replace to fix the specific issues."
                        })
                        phase = "fix"
                        _tests_run = False
                        phase_start_time = time.time()
                        continue

            except Exception as e:
                _status(f"Test execution error (non-fatal): {e}")

    else:
        report = "Agent: max turns reached. Project may be partially complete."

    if files_written:
        report += "\n\n---\n## Files created\n" + "\n".join(f"- `{f}`" for f in files_written)

    # Add circuit breaker status to report
    cb_status = cb.get_status()
    if cb_status["total_escalations"] > 0:
        report += f"\n\n---\n## Circuit Breaker\n- Escalations: {cb_status['total_escalations']}\n- Final model: {cb_status['current_model']}"

    # Add final session summary to tracker
    tracker.add_event(EventType.PHASE_CHANGE, "Agent session completed", 
                     {"files_written": len(files_written), "total_turns": turn + 1,
                      "circuit_breaker": cb_status})

    return report, tracker


def run_agent_o3de(
    user_request: str,
    bridge: Any,
    on_status: Callable[[str], None] | None = None,
    max_turns: int = 25,
) -> Tuple[str, Any]:
    """Run the multi-agent game studio for O3DE AAA game development.

    Uses the GameStudio with 5 specialized agents:
    Director, Engine Operator, Asset Artist, Gameplay Dev, QA Tester.

    Args:
        user_request: What the user wants to build
        bridge: O3DEBridge instance (project already created)
        on_status: Callback for status updates
        max_turns: Maximum API call turns (unused, kept for API compat)

    Returns:
        (report_string, trace_data_dict)
    """
    from openartemis.agent.game_studio import run_game_studio

    # Resolve model
    e2b_model = os.environ.get("OPENARTEMIS_E2B_MODEL", "").strip()
    if e2b_model:
        worker_model = resolve_artemis_model(e2b_model) if "artemis" in e2b_model.lower() else e2b_model
    else:
        worker_model = "gpt-4.1"
        exec_model = get_exec_model()
        if exec_model and exec_model != "artemis-1-mini":
            worker_model = resolve_artemis_model(exec_model) if "artemis" in exec_model.lower() else exec_model

    report, trace_data = run_game_studio(
        user_prompt=user_request,
        bridge=bridge,
        on_status=on_status,
        model=worker_model,
        max_fix_cycles=3,
    )

    # Save trace for fine-tuning
    try:
        import json as _json
        traces_path = Path(__file__).resolve().parents[1] / "data" / "o3de_traces.jsonl"
        traces_path.parent.mkdir(parents=True, exist_ok=True)
        with open(traces_path, "a", encoding="utf-8") as f:
            f.write(_json.dumps(trace_data, default=str) + "\n")
    except Exception:
        pass

    return report, trace_data
