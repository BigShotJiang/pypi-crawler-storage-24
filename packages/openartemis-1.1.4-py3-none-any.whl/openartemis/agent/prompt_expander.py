"""Prompt Expander — turns vague human prompts into structured project specs.

Flow:  vague prompt -> expand_prompt() -> ProjectSpec
"""

from __future__ import annotations

import re
from dataclasses import dataclass, field
from typing import Any


# ── Project type detection patterns ──

_GAME_KEYWORDS = [
    "flappy bird", "flappy", "snake", "pong", "breakout", "tetris",
    "tic tac toe", "tic-tac-toe", "space invaders", "asteroids",
    "platformer", "shooter", "puzzle game", "card game", "board game",
    "game", "arcade", "pacman", "pac-man", "minesweeper", "sudoku",
    "chess", "checkers", "solitaire", "2048", "memory game",
    "brick breaker", "dino game", "jump game", "runner",
    "whack a mole", "whack-a-mole", "simon says", "hangman",
    "wordle", "typing game",
]

_WEBAPP_KEYWORDS = [
    "website", "web app", "webapp", "landing page", "dashboard",
    "portfolio", "blog", "e-commerce", "ecommerce", "store",
    "login page", "sign up", "signup", "form", "survey",
    "admin panel", "cms", "todo", "to-do", "task manager",
    "calculator", "converter", "weather app", "chat app",
    "social media", "forum", "wiki", "documentation",
    "pricing page", "about page", "contact page",
]

_API_KEYWORDS = ["api", "rest api", "graphql", "backend", "server", "microservice", "endpoint", "webhook", "crud"]
_SCRIPT_KEYWORDS = ["script", "automation", "scraper", "web scraper", "cli tool", "command line", "batch", "etl"]

# ── Specific template matching ──

_GAME_PATTERNS: list[tuple[str, list[str]]] = [
    ("flappy_bird", ["flappy bird", "flappy", "bird game", "pipe game"]),
    ("snake", ["snake game", "snake"]),
    ("pong", ["pong", "ping pong", "table tennis game"]),
    ("breakout", ["breakout", "brick breaker", "arkanoid", "brick game"]),
    ("tetris", ["tetris", "block puzzle", "falling blocks"]),
    ("platformer", ["platformer", "jump game", "runner game", "side scroller"]),
    ("space_invaders", ["space invaders", "shooter", "space shooter"]),
    ("memory_game", ["memory game", "matching game", "card match"]),
    ("tic_tac_toe", ["tic tac toe", "tic-tac-toe", "noughts and crosses"]),
]

_WEBAPP_PATTERNS: list[tuple[str, list[str]]] = [
    ("todo_app", ["todo", "to-do", "task manager", "task list", "task app"]),
    ("landing_page", ["landing page", "homepage", "marketing page"]),
    ("calculator", ["calculator", "calc app"]),
    ("chat_ui", ["chat app", "chat ui", "messaging", "messenger"]),
    ("portfolio", ["portfolio", "personal site", "personal website"]),
    ("dashboard", ["dashboard", "admin panel", "analytics"]),
]

# ── Proven constants ──

_GAME_PHYSICS = {
    "gravity": 0.4, "flap_strength": -7, "terminal_velocity": 10,
    "pipe_speed": 2, "pipe_gap": 160, "pipe_width": 60,
    "pipe_spawn_interval": 100, "bird_radius": 15,
    "canvas_width": 480, "canvas_height": 640,
    "snake_speed_ms": 150, "pong_paddle_speed": 4,
    "breakout_ball_speed_x": 3, "breakout_ball_speed_y": -3,
}

_GAME_FEATURES = [
    "requestAnimationFrame game loop at 60fps",
    "Input: spacebar + mouse click + touchstart all do the same primary action",
    "Score counter visible on canvas at all times",
    "Game over screen: shows final score + 'Click or Space to restart'",
    "Restart resets ALL state: score, positions, velocities, arrays",
    "Colored background — never a blank white canvas",
    "Smooth physics using the constants provided",
]

_GAME_QUALITY_GATES = [
    "Bird/character does NOT fall off screen in under 2s with no input",
    "Score increments correctly when passing obstacles",
    "Restart fully resets all game state",
    "All 3 input methods work: spacebar, click, touch",
    "No JavaScript errors (no undefined variables)",
    "Game elements are visible and colored (not blank canvas)",
]

_WEBAPP_FEATURES = [
    "Responsive layout (works at 1280px and 375px)",
    "All buttons are functional and do something",
    "Clean, modern UI with proper spacing and colors",
    "Semantic HTML with proper heading hierarchy",
]

_WEBAPP_QUALITY_GATES = [
    "Layout looks correct at 1280px wide",
    "No broken images or missing styles",
    "All interactive elements respond to user actions",
    "Page loads without JavaScript errors",
]


@dataclass
class ProjectSpec:
    """Structured project specification expanded from a vague prompt."""
    original_prompt: str
    project_type: str  # "game", "webapp", "api", "script", "unknown"
    template_id: str | None  # matches golden_templates key, or None
    platform: str  # "web", "python", "node"
    stack: str  # e.g. "single index.html, Canvas API"
    features: list[str] = field(default_factory=list)
    constraints: dict[str, Any] = field(default_factory=dict)
    quality_gates: list[str] = field(default_factory=list)
    complexity: str = "simple"  # "simple", "medium", "complex"
    needs_research: bool = False
    needs_clarification: bool = False

    def to_prompt_block(self) -> str:
        """Format spec as a block to inject into the agent system prompt."""
        lines = [f"=== PROJECT SPEC (from: \"{self.original_prompt}\") ==="]
        lines.append(f"Type: {self.project_type} | Platform: {self.platform} | Stack: {self.stack}")
        if self.features:
            lines.append("\nRequired features:")
            for f in self.features:
                lines.append(f"  - {f}")
        if self.constraints:
            lines.append("\nConstants (proven values — do not change):")
            for k, v in self.constraints.items():
                lines.append(f"  - {k}: {v}")
        if self.quality_gates:
            lines.append("\nQuality gates (ALL must pass before completion):")
            for g in self.quality_gates:
                lines.append(f"  [ ] {g}")
        lines.append("=== END SPEC ===")
        return "\n".join(lines)

    def to_dict(self) -> dict[str, Any]:
        return {
            "original_prompt": self.original_prompt,
            "project_type": self.project_type,
            "template_id": self.template_id,
            "platform": self.platform,
            "stack": self.stack,
            "features": self.features,
            "constraints": self.constraints,
            "quality_gates": self.quality_gates,
            "complexity": self.complexity,
            "needs_research": self.needs_research,
        }

    def generate_test_script(self) -> str | None:
        """Generate a Node.js test script that mechanically validates the built project.

        Returns a self-contained JS script that outputs JSON:
        {"passed": N, "failed": N, "errors": ["test_id: reason", ...]}
        Returns None if no tests can be generated for this project type.
        """
        if self.project_type == "game":
            return _GAME_TEST_SCRIPT
        elif self.project_type == "webapp":
            return _WEBAPP_TEST_SCRIPT
        elif self.project_type == "api":
            return _API_TEST_SCRIPT
        return None


def _detect_type(prompt: str) -> str:
    lower = prompt.lower()
    for _tid, keywords in _GAME_PATTERNS:
        if any(kw in lower for kw in keywords):
            return "game"
    for _tid, keywords in _WEBAPP_PATTERNS:
        if any(kw in lower for kw in keywords):
            return "webapp"
    if any(kw in lower for kw in _GAME_KEYWORDS):
        return "game"
    if any(kw in lower for kw in _WEBAPP_KEYWORDS):
        return "webapp"
    if any(kw in lower for kw in _API_KEYWORDS):
        return "api"
    if any(kw in lower for kw in _SCRIPT_KEYWORDS):
        return "script"
    return "unknown"


def _detect_template(prompt: str) -> str | None:
    lower = prompt.lower()
    for tid, keywords in _GAME_PATTERNS:
        if any(kw in lower for kw in keywords):
            return tid
    for tid, keywords in _WEBAPP_PATTERNS:
        if any(kw in lower for kw in keywords):
            return tid
    return None


def _assess_complexity(prompt: str, project_type: str) -> str:
    lower = prompt.lower()
    complex_kw = [
        "database", "auth", "authentication", "oauth", "payment",
        "stripe", "real-time", "websocket", "multiplayer",
        "machine learning", "ml", "ai model", "microservice",
        "docker", "kubernetes", "full stack", "fullstack",
    ]
    if any(kw in lower for kw in complex_kw):
        return "complex"
    medium_kw = [
        "multiple pages", "multi-page", "routing", "navigation",
        "api integration", "fetch data", "external api",
        "user accounts", "profiles",
    ]
    if any(kw in lower for kw in medium_kw):
        return "medium"
    if project_type in ("game", "webapp"):
        return "simple"
    return "medium"


def expand_prompt(prompt: str) -> ProjectSpec:
    """Expand a vague user prompt into a full ProjectSpec.

    Pure heuristic — no LLM calls, runs in <1ms.
    """
    prompt = (prompt or "").strip()
    if not prompt:
        return ProjectSpec(
            original_prompt=prompt, project_type="unknown",
            template_id=None, platform="web", stack="index.html",
        )

    project_type = _detect_type(prompt)
    template_id = _detect_template(prompt)
    complexity = _assess_complexity(prompt, project_type)

    if project_type == "game":
        return ProjectSpec(
            original_prompt=prompt, project_type="game",
            template_id=template_id, platform="web",
            stack="single index.html with <style> + <script>, Canvas API",
            features=list(_GAME_FEATURES),
            constraints=dict(_GAME_PHYSICS),
            quality_gates=list(_GAME_QUALITY_GATES),
            complexity=complexity,
        )
    elif project_type == "webapp":
        return ProjectSpec(
            original_prompt=prompt, project_type="webapp",
            template_id=template_id, platform="web",
            stack="single index.html with <style> + <script>",
            features=list(_WEBAPP_FEATURES),
            constraints={},
            quality_gates=list(_WEBAPP_QUALITY_GATES),
            complexity=complexity,
        )
    elif project_type == "api":
        return ProjectSpec(
            original_prompt=prompt, project_type="api",
            template_id=None, platform="python",
            stack="Python Flask or FastAPI",
            features=[
                "RESTful endpoints with proper HTTP methods",
                "JSON request/response format",
                "Error handling with appropriate status codes",
                "Requirements.txt with dependencies",
            ],
            quality_gates=[
                "All endpoints return valid JSON",
                "Error cases return proper HTTP status codes",
                "Server starts without errors",
            ],
            complexity=complexity,
            needs_research=complexity == "complex",
            needs_clarification=True,
        )
    elif project_type == "script":
        return ProjectSpec(
            original_prompt=prompt, project_type="script",
            template_id=None, platform="python",
            stack="Python script (main.py)",
            features=[
                "Clear CLI interface or function entry point",
                "Error handling for common failure cases",
            ],
            quality_gates=["Script runs without errors", "Output is correct for sample inputs"],
            complexity=complexity,
            needs_clarification=True,
        )
    else:
        return ProjectSpec(
            original_prompt=prompt, project_type="unknown",
            template_id=None, platform="web",
            stack="index.html or Python script",
            complexity=complexity,
            needs_research=True,
            needs_clarification=True,
        )


# ═══════════════════════════════════════════════════════════════════════════════
# Mechanical test scripts — generated per project type, run in E2B sandbox
# Each outputs JSON: {"passed": N, "failed": N, "errors": ["test_id: reason"]}
# ═══════════════════════════════════════════════════════════════════════════════

_GAME_TEST_SCRIPT = r"""
const fs = require('fs');
const path = require('path');
const results = {passed: 0, failed: 0, errors: []};

function assert(id, condition, reason) {
  if (condition) { results.passed++; }
  else { results.failed++; results.errors.push(id + ': ' + (reason || 'failed')); }
}

// Find the main HTML file
const projDir = '/home/user/ArtemisProject';
let htmlFile = '';
for (const f of ['index.html', 'game.html', 'main.html']) {
  if (fs.existsSync(path.join(projDir, f))) { htmlFile = path.join(projDir, f); break; }
}
if (!htmlFile) {
  // Search one level deep
  try {
    const files = fs.readdirSync(projDir);
    for (const f of files) {
      if (f.endsWith('.html')) { htmlFile = path.join(projDir, f); break; }
    }
  } catch(e) {}
}

if (!htmlFile) {
  results.failed++;
  results.errors.push('find_html: No HTML file found in project');
  console.log(JSON.stringify(results));
  process.exit(0);
}

const html = fs.readFileSync(htmlFile, 'utf8');

// Core game structure tests
assert('has_canvas', /<canvas/i.test(html), 'No <canvas> element found');
assert('has_game_loop', /requestAnimationFrame|setInterval|setTimeout/.test(html), 'No game loop (requestAnimationFrame/setInterval)');
assert('has_draw_call', /\.fillRect|\.drawImage|\.arc|\.fillText|\.stroke|\.fill\b/.test(html), 'No canvas draw calls');
assert('has_input', /addEventListener|onkeydown|onkeyup|onclick|ontouchstart/.test(html), 'No input event listeners');
assert('has_game_state', /score|lives|health|gameOver|game_over|isRunning|started/.test(html), 'No game state variables (score/lives/gameOver)');

// Syntax check: try to parse the JS
const scriptMatch = html.match(/<script[^>]*>([\s\S]*?)<\/script>/i);
if (scriptMatch) {
  try {
    new Function(scriptMatch[1]);
    assert('js_syntax', true);
  } catch(e) {
    assert('js_syntax', false, 'SyntaxError: ' + e.message);
  }
} else {
  assert('js_syntax', false, 'No <script> block found');
}

// HTML structure
assert('has_doctype', /<!DOCTYPE/i.test(html), 'Missing <!DOCTYPE html>');
assert('has_head', /<head/i.test(html), 'Missing <head>');
assert('has_body', /<body/i.test(html), 'Missing <body>');
assert('has_style', /<style|stylesheet/i.test(html), 'No styles (game should have canvas styling)');

console.log(JSON.stringify(results));
"""

_WEBAPP_TEST_SCRIPT = r"""
const fs = require('fs');
const path = require('path');
const results = {passed: 0, failed: 0, errors: []};

function assert(id, condition, reason) {
  if (condition) { results.passed++; }
  else { results.failed++; results.errors.push(id + ': ' + (reason || 'failed')); }
}

const projDir = '/home/user/ArtemisProject';
let htmlFile = '';
for (const f of ['index.html', 'app.html', 'main.html']) {
  if (fs.existsSync(path.join(projDir, f))) { htmlFile = path.join(projDir, f); break; }
}
if (!htmlFile) {
  try {
    const files = fs.readdirSync(projDir);
    for (const f of files) {
      if (f.endsWith('.html')) { htmlFile = path.join(projDir, f); break; }
    }
  } catch(e) {}
}

if (!htmlFile) {
  results.failed++;
  results.errors.push('find_html: No HTML file found in project');
  console.log(JSON.stringify(results));
  process.exit(0);
}

const html = fs.readFileSync(htmlFile, 'utf8');

// Structure tests
assert('has_doctype', /<!DOCTYPE/i.test(html), 'Missing <!DOCTYPE html>');
assert('has_semantic', /<(header|main|section|nav|footer|article|aside)/i.test(html), 'No semantic HTML elements');
assert('has_styles', /<style|stylesheet/i.test(html), 'No CSS styles');
assert('has_viewport', /viewport/i.test(html), 'No viewport meta (not responsive)');
assert('has_title', /<title>.+<\/title>/i.test(html), 'Empty or missing <title>');

// Interactive elements
assert('has_interactive', /onclick|addEventListener|onsubmit|onchange|oninput/i.test(html), 'No interactive JavaScript');
assert('has_buttons_or_inputs', /<button|<input|<select|<textarea|<a\s/i.test(html), 'No interactive elements (buttons/inputs/links)');

// Quality
assert('not_empty_body', /<body[^>]*>[\s\S]{50,}<\/body>/i.test(html), 'Body content too short (<50 chars)');
assert('has_content', /<(h1|h2|h3|p|div|span)[^>]*>.+<\/(h1|h2|h3|p|div|span)>/i.test(html), 'No visible text content');

// Syntax check
const scriptMatch = html.match(/<script[^>]*>([\s\S]*?)<\/script>/i);
if (scriptMatch && scriptMatch[1].trim().length > 0) {
  try {
    new Function(scriptMatch[1]);
    assert('js_syntax', true);
  } catch(e) {
    assert('js_syntax', false, 'SyntaxError: ' + e.message);
  }
} else {
  assert('js_syntax', true); // No JS is okay for static pages
}

console.log(JSON.stringify(results));
"""

_API_TEST_SCRIPT = r"""
const fs = require('fs');
const path = require('path');
const { execSync } = require('child_process');
const results = {passed: 0, failed: 0, errors: []};

function assert(id, condition, reason) {
  if (condition) { results.passed++; }
  else { results.failed++; results.errors.push(id + ': ' + (reason || 'failed')); }
}

const projDir = '/home/user/ArtemisProject';

// Check for entry point
const entryPoints = ['server.js', 'app.js', 'index.js', 'main.py', 'app.py', 'server.py'];
let found = false;
for (const f of entryPoints) {
  if (fs.existsSync(path.join(projDir, f))) { found = true; break; }
}
assert('has_entry_point', found, 'No server entry point (server.js/app.py/etc.)');

// Check for package.json or requirements.txt
const hasPkgJson = fs.existsSync(path.join(projDir, 'package.json'));
const hasReqs = fs.existsSync(path.join(projDir, 'requirements.txt'));
assert('has_deps', hasPkgJson || hasReqs, 'No dependency file (package.json or requirements.txt)');

// If package.json exists, validate it
if (hasPkgJson) {
  try {
    const pkg = JSON.parse(fs.readFileSync(path.join(projDir, 'package.json'), 'utf8'));
    assert('valid_package_json', true);
    assert('has_start_script', !!(pkg.scripts && (pkg.scripts.start || pkg.scripts.dev)), 'No start/dev script in package.json');
  } catch(e) {
    assert('valid_package_json', false, 'Invalid JSON: ' + e.message);
  }
}

// Check for route definitions
let hasRoutes = false;
try {
  const files = fs.readdirSync(projDir);
  for (const f of files) {
    const fp = path.join(projDir, f);
    if (fs.statSync(fp).isFile() && (f.endsWith('.js') || f.endsWith('.py') || f.endsWith('.ts'))) {
      const content = fs.readFileSync(fp, 'utf8');
      if (/app\.(get|post|put|delete|patch|use)|@app\.route|router\.|fastify\./i.test(content)) {
        hasRoutes = true;
        break;
      }
    }
  }
} catch(e) {}
assert('has_routes', hasRoutes, 'No API route definitions found');

console.log(JSON.stringify(results));
"""
