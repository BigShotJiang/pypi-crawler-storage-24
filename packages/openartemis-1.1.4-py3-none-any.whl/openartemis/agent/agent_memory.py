"""Agent memory system for maintaining context between sessions."""

import json
import os
from pathlib import Path
from typing import Dict, List, Optional, Any
from datetime import datetime

from openartemis.context_window import ContextWindow


class AgentMemory:
    """Memory system for E2B agent to maintain project context."""
    
    def __init__(self, project_name: str, local_project: Path):
        self.project_name = project_name
        self.local_project = local_project
        self.memory_file = local_project / ".artemis_memory.json"
        self.memory: Dict[str, Any] = self._load_memory()
        # 1M token context window for agent projects
        cw_data = self.memory.get("context_window")
        if cw_data:
            self.context_window = ContextWindow.from_dict(cw_data)
        else:
            self.context_window = ContextWindow(max_tokens=1_000_000, role="agent")
    
    def _load_memory(self) -> Dict[str, Any]:
        """Load existing memory or create new."""
        if self.memory_file.exists():
            try:
                with open(self.memory_file, 'r', encoding='utf-8') as f:
                    return json.load(f)
            except Exception:
                pass
        
        # Create new memory structure
        return {
            "project_name": self.project_name,
            "created_at": datetime.now().isoformat(),
            "sessions": [],
            "files_created": [],
            "issues_found": [],
            "fixes_applied": [],
            "user_feedback": [],
            "project_context": {}
        }
    
    def save_memory(self) -> None:
        """Save memory to disk."""
        try:
            self.memory["updated_at"] = datetime.now().isoformat()
            self.memory["context_window"] = self.context_window.to_dict()
            with open(self.memory_file, 'w', encoding='utf-8') as f:
                json.dump(self.memory, f, indent=2, ensure_ascii=False)
        except Exception:
            pass  # Fail silently if can't save
    
    def add_session(self, session_data: Dict[str, Any]) -> None:
        """Add a new agent session to memory."""
        session_data["timestamp"] = datetime.now().isoformat()
        self.memory["sessions"].append(session_data)
        self.save_memory()
    
    def add_files(self, files: List[str]) -> None:
        """Add created files to memory."""
        self.memory["files_created"].extend(files)
        self.memory["files_created"] = list(set(self.memory["files_created"]))  # Remove duplicates
        self.save_memory()
    
    def add_issue(self, issue: str) -> None:
        """Add an issue found by user."""
        self.memory["issues_found"].append({
            "issue": issue,
            "timestamp": datetime.now().isoformat()
        })
        self.save_memory()
    
    def add_fix(self, fix: str) -> None:
        """Add a fix applied by agent."""
        self.memory["fixes_applied"].append({
            "fix": fix,
            "timestamp": datetime.now().isoformat()
        })
        self.save_memory()
    
    def add_feedback(self, feedback: str) -> None:
        """Add user feedback."""
        self.memory["user_feedback"].append({
            "feedback": feedback,
            "timestamp": datetime.now().isoformat()
        })
        self.save_memory()
    
    def set_context(self, key: str, value: Any) -> None:
        """Set project context."""
        self.memory["project_context"][key] = value
        self.save_memory()
    
    def get_context_summary(self) -> str:
        """Get a summary of project context for the agent."""
        summary_parts = []
        
        # Project info
        summary_parts.append(f"Project: {self.project_name}")
        summary_parts.append(f"Created: {self.memory.get('created_at', 'Unknown')}")
        
        # Files created
        if self.memory["files_created"]:
            files_str = ", ".join(self.memory["files_created"][:10])
            if len(self.memory["files_created"]) > 10:
                files_str += f" and {len(self.memory['files_created']) - 10} more"
            summary_parts.append(f"Files: {files_str}")
        
        # Previous issues
        if self.memory["issues_found"]:
            recent_issues = self.memory["issues_found"][-3:]  # Last 3 issues
            issues_str = "; ".join([issue["issue"] for issue in recent_issues])
            summary_parts.append(f"Previous issues: {issues_str}")
        
        # Previous fixes
        if self.memory["fixes_applied"]:
            recent_fixes = self.memory["fixes_applied"][-3:]  # Last 3 fixes
            fixes_str = "; ".join([fix["fix"] for fix in recent_fixes])
            summary_parts.append(f"Recent fixes: {fixes_str}")
        
        # User feedback
        if self.memory["user_feedback"]:
            recent_feedback = self.memory["user_feedback"][-2:]  # Last 2 feedbacks
            feedback_str = "; ".join([fb["feedback"] for fb in recent_feedback])
            summary_parts.append(f"User feedback: {feedback_str}")
        
        return "\n".join(summary_parts)
    
    def get_session_count(self) -> int:
        """Get number of sessions."""
        return len(self.memory["sessions"])
    
    def has_previous_sessions(self) -> bool:
        """Check if there are previous sessions."""
        return len(self.memory["sessions"]) > 0

    def add_agent_message(self, role: str, content: str) -> None:
        """Add an agent conversation message to the context window."""
        self.context_window.add({"role": role, "content": content})

    def get_full_context_for_agent(self) -> str:
        """Get full context for agent prompt injection (compressed if needed)."""
        parts = [self.get_context_summary()]
        if self.context_window.compressed_summary:
            parts.append(f"\nConversation history:\n{self.context_window.compressed_summary}")
        # Add plan if it exists
        plan_path = self.local_project / "plan.md"
        if plan_path.exists():
            try:
                plan_text = plan_path.read_text(encoding="utf-8")[:4000]
                parts.append(f"\nBuild plan:\n{plan_text}")
            except Exception:
                pass
        return "\n".join(parts)

    # ── Game Build Index (for O3DE repo indexing) ──

    def add_game_build(self, trace_data: Dict[str, Any]) -> None:
        """Index a successful game build for future retrieval."""
        if "game_builds" not in self.memory:
            self.memory["game_builds"] = []
        build_entry = {
            "timestamp": datetime.now().isoformat(),
            "prompt": trace_data.get("prompt", "")[:200],
            "genre": trace_data.get("genre", "unknown"),
            "entities_created": trace_data.get("entities_created", 0),
            "scripts_written": trace_data.get("scripts_written", 0),
            "total_lines": trace_data.get("total_lines", 0),
            "build_success": trace_data.get("build_success", False),
            "fix_cycles": trace_data.get("fix_cycles", 0),
            "assets_generated": trace_data.get("assets_generated", 0),
            "elapsed_seconds": trace_data.get("elapsed_seconds", 0),
            "gdd_summary": {
                "title": trace_data.get("gdd", {}).get("title", ""),
                "entity_names": [
                    e.get("name", "") for e in trace_data.get("gdd", {}).get("entities", [])
                ],
                "script_names": [
                    s.get("name", "") for s in trace_data.get("gdd", {}).get("scripts", [])
                ],
            },
        }
        self.memory["game_builds"].append(build_entry)
        # Keep last 20 builds
        self.memory["game_builds"] = self.memory["game_builds"][-20:]
        self.save_memory()

    def find_similar_builds(self, genre: str, limit: int = 3) -> List[Dict[str, Any]]:
        """Find past builds of the same genre for context injection."""
        builds = self.memory.get("game_builds", [])
        matches = [b for b in builds if b.get("genre", "").lower() == genre.lower() and b.get("build_success")]
        # Sort by most recent
        matches.sort(key=lambda b: b.get("timestamp", ""), reverse=True)
        return matches[:limit]

    def get_build_context_for_genre(self, genre: str) -> str:
        """Get a text summary of past similar builds for the Director agent."""
        similar = self.find_similar_builds(genre)
        if not similar:
            return ""
        lines = [f"Past successful {genre} builds:"]
        for b in similar:
            summary = b.get("gdd_summary", {})
            title = summary.get("title", "Untitled")
            ents = ", ".join(summary.get("entity_names", [])[:6])
            scripts = ", ".join(summary.get("script_names", [])[:6])
            lines.append(
                f"- {title}: {b.get('entities_created', 0)} entities, "
                f"{b.get('scripts_written', 0)} scripts ({b.get('total_lines', 0)} lines), "
                f"{b.get('fix_cycles', 0)} fix cycles"
            )
            if ents:
                lines.append(f"  Entities: {ents}")
            if scripts:
                lines.append(f"  Scripts: {scripts}")
        return "\n".join(lines)
