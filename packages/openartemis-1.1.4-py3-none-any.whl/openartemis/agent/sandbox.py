"""Sandboxed container/VM per job — Docker-based isolation with workspace mount."""

import os
import subprocess
from pathlib import Path
from typing import Optional

# Default image: Python + common runtimes (user can override via OPENARTEMIS_AGENT_SANDBOX_IMAGE)
DEFAULT_IMAGE = "python:3.11-slim"
WORKSPACE_MOUNT = "/workspace"


def _docker_available() -> bool:
    try:
        subprocess.run(
            ["docker", "info"],
            capture_output=True,
            timeout=10,
            check=False,
        )
        return True
    except (FileNotFoundError, subprocess.TimeoutExpired):
        return False


def _image() -> str:
    return os.environ.get("OPENARTEMIS_AGENT_SANDBOX_IMAGE", "").strip() or DEFAULT_IMAGE


def create_job_container(workspace_host_path: Path, job_id: str) -> Optional[str]:
    """
    Create a long-lived container with workspace mounted at /workspace.
    Returns container_id (same as job_id) or None on failure.
    """
    if not _docker_available():
        return None
    path_str = str(Path(workspace_host_path).resolve())
    try:
        subprocess.run(
            [
                "docker", "run", "-d",
                "--name", job_id,
                "-v", f"{path_str}:{WORKSPACE_MOUNT}",
                "-w", WORKSPACE_MOUNT,
                _image(),
                "sleep", "infinity",
            ],
            capture_output=True,
            text=True,
            timeout=60,
            check=True,
        )
        return job_id
    except (subprocess.CalledProcessError, subprocess.TimeoutExpired, OSError):
        return None


def exec_in_container(container_id: str, command: str, timeout: int = 300) -> tuple[str, int]:
    """
    Run command in container at /workspace. Returns (stdout+stderr, returncode).
    """
    try:
        result = subprocess.run(
            ["docker", "exec", "-w", WORKSPACE_MOUNT, container_id, "sh", "-c", command],
            capture_output=True,
            text=True,
            timeout=timeout,
            encoding="utf-8",
            errors="replace",
        )
        out = (result.stdout or "") + ((result.stderr and f"\n[stderr]\n{result.stderr}") or "")
        return out.strip() or f"(exit {result.returncode})", result.returncode
    except subprocess.TimeoutExpired:
        return f"Error: Command timed out ({timeout}s)", -1
    except Exception as e:
        return f"Error: {e}", -1


def destroy_job_container(container_id: str) -> bool:
    """Remove the job container. Returns True on success."""
    try:
        subprocess.run(
            ["docker", "rm", "-f", container_id],
            capture_output=True,
            timeout=30,
            check=False,
        )
        return True
    except (subprocess.TimeoutExpired, OSError):
        return False


def is_sandbox_enabled() -> bool:
    """True when OPENARTEMIS_AGENT_SANDBOX=docker and Docker is available."""
    return (
        os.environ.get("OPENARTEMIS_AGENT_SANDBOX", "").strip().lower() == "docker"
        and _docker_available()
    )
