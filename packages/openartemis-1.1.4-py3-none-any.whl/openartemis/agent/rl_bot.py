"""RL Bot — base agent template customized per task."""

import json
import os
from pathlib import Path
from typing import Any

from dotenv import load_dotenv
from openartemis.config import get_anthropic_client as _get_openai_client

load_dotenv(Path(__file__).resolve().parents[2] / ".env")

from openartemis.config import resolve_artemis_model

RL_BOT_BASE = """You are a coding agent with tools: read_file, write_file, list_dir, run_terminal, take_screenshot.
The lead role plans step-by-step; the worker executes one step at a time. The lead must commit to one stack and list exact file names.
Customize the lead and worker prompts for this task. Lead must require one stack and explicit steps with file names; same JSON format."""

CUSTOMIZE_PROMPT = """Given this user request: {user_request}

Customize the base agent for this task. Return a JSON object with two keys:
- "lead": system prompt for the planning role. It MUST require: (1) commit to ONE stack only (e.g. Vanilla Canvas single HTML, or Phaser + Vite), no alternatives; (2) output JSON with "stack" and "steps" where each step has id, action, and "file" with exact filename (e.g. index.html, game.js). For single-file projects use fewer, chunkier steps (5-15) so each step can be a full feature; for multi-file use small concrete steps; max 50 steps; output ONLY valid JSON.
- "worker": system prompt for the execution role (must still describe tools: read_file, write_file, list_dir, run_terminal, take_screenshot)

Keep both prompts concise. No generic research style; the lead must produce a build-ready plan with one stack and concrete files.
Output ONLY valid JSON, no markdown."""


def customize_for_task(
    user_request: str,
    model: str | None = None,
) -> dict[str, str]:
    """
    Call the model to produce task-specific lead_system and worker_system.
    Returns {"lead": "...", "worker": "..."}. Falls back to defaults if customization fails.
    """
    from openartemis.agent.agent_orchestrator import LEAD_SYSTEM, WORKER_SYSTEM

    default = {"lead": LEAD_SYSTEM, "worker": WORKER_SYSTEM}
    client = _get_openai_client()
    if not getattr(client, 'api_key', None):
        return default
    from openartemis.config import DEFAULT_BASE_MODEL
    from openartemis.token_budget import create_with_budget
    model = (model or DEFAULT_BASE_MODEL)
    model = resolve_artemis_model(model) if isinstance(model, str) and "artemis" in model.lower() else model
    try:
        resp = create_with_budget(
            client,
            model,
            [
                {"role": "system", "content": RL_BOT_BASE},
                {"role": "user", "content": CUSTOMIZE_PROMPT.format(user_request=user_request)},
            ],
            max_tokens=1024,
        )
        content = (resp.choices[0].message.content or "").strip()
        from openartemis.agent.agent_orchestrator import _extract_json_object
        data = _extract_json_object(content)
        if data is not None:
            lead = (data.get("lead") or "").strip()
            worker = (data.get("worker") or "").strip()
            if lead and worker:
                return {"lead": lead, "worker": worker}
    except Exception:
        pass
    return default
