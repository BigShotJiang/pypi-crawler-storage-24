"""Circuit Breaker — prevents hallucination spirals via mechanical failure tracking.

Tracks test failures per test ID. If the same test fails 3 times consecutively:
  1. Roll back to the last known-good Git state in the E2B sandbox
  2. Escalate the model tier (Haiku → Sonnet → Opus)
  3. Inject failure context so the higher-tier model avoids the same mistake

Usage:
    from openartemis.agent.circuit_breaker import CircuitBreaker, Action
    cb = CircuitBreaker()
    cb.save_checkpoint(sandbox)  # after successful test pass
    action = cb.record_failure("js_syntax", "SyntaxError at line 42")
    if action == Action.ROLLBACK_AND_ESCALATE:
        cb.rollback(sandbox)
        model = cb.get_current_model()
"""

from __future__ import annotations

import json
from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Optional


class Action(Enum):
    """Action the orchestrator should take after a test result."""
    CONTINUE = "continue"              # Tests passed or failure is new — keep going
    RETRY = "retry"                    # Same failure seen before but under threshold — retry
    ROLLBACK_AND_ESCALATE = "escalate" # 3 consecutive failures — rollback + upgrade model
    HARD_FAIL = "hard_fail"            # Opus also failed 3x — give up


# Model escalation ladder (cheapest → most capable)
MODEL_LADDER = [
    "claude-haiku-4-5",     # Tier 0: fast, cheap — default for builds
    "claude-sonnet-4-5",    # Tier 1: balanced — escalation target
    "claude-opus-4-5",      # Tier 2: flagship — last resort
]


@dataclass
class FailureRecord:
    """Tracks consecutive failures for a single test ID."""
    test_id: str
    count: int = 0
    last_error: str = ""


@dataclass
class CircuitBreaker:
    """Mechanical guardrail that prevents infinite fix loops.

    - Tracks per-test failure counts
    - Manages Git checkpoints in the E2B sandbox
    - Escalates model tier after repeated failures
    - Forces hard rollback to last known-good state
    """
    max_failures: int = 3
    model_tier: int = 1  # Start at Sonnet (tier 1) since that's the default build model
    _failures: dict[str, FailureRecord] = field(default_factory=dict)
    _checkpoints: list[str] = field(default_factory=list)  # Git commit hashes
    _escalation_context: list[str] = field(default_factory=list)  # Failure messages for next model
    _total_escalations: int = 0
    _git_initialized: bool = False

    def get_current_model(self) -> str:
        """Return the model for the current tier."""
        idx = min(self.model_tier, len(MODEL_LADDER) - 1)
        return MODEL_LADDER[idx]

    def record_result(self, test_id: str, passed: bool, error_msg: str = "") -> Action:
        """Record a test result and return the action to take.

        Args:
            test_id: Unique test identifier (e.g. "js_syntax", "has_canvas")
            passed: Whether the test passed
            error_msg: Error message if failed

        Returns:
            Action enum indicating what the orchestrator should do
        """
        if passed:
            # Clear failure count for this test on success
            if test_id in self._failures:
                del self._failures[test_id]
            return Action.CONTINUE

        # Record failure
        if test_id not in self._failures:
            self._failures[test_id] = FailureRecord(test_id=test_id)

        rec = self._failures[test_id]
        rec.count += 1
        rec.last_error = error_msg

        if rec.count >= self.max_failures:
            # Check if we can escalate
            if self.model_tier < len(MODEL_LADDER) - 1:
                self._escalation_context.append(
                    f"Test '{test_id}' failed {rec.count}x with: {error_msg}"
                )
                self.model_tier += 1
                self._total_escalations += 1
                # Reset failure count so the new model gets fresh attempts
                rec.count = 0
                return Action.ROLLBACK_AND_ESCALATE
            else:
                # Already at highest tier — hard fail
                return Action.HARD_FAIL

        return Action.RETRY

    def record_batch_results(self, results: dict) -> Action:
        """Process a batch of test results (from the test script JSON output).

        Args:
            results: {"passed": N, "failed": N, "errors": ["test_id: reason", ...]}

        Returns:
            The most severe Action from all test results
        """
        errors = results.get("errors", [])
        if not errors:
            return Action.CONTINUE

        worst_action = Action.CONTINUE
        for err_str in errors:
            # Parse "test_id: reason" format
            parts = err_str.split(": ", 1)
            test_id = parts[0].strip()
            reason = parts[1].strip() if len(parts) > 1 else "failed"

            action = self.record_result(test_id, passed=False, error_msg=reason)
            if action.value > worst_action.value:
                worst_action = action

        return worst_action

    def all_passed(self, results: dict) -> bool:
        """Check if all tests passed."""
        return results.get("failed", 0) == 0 and not results.get("errors")

    def get_escalation_context(self) -> str:
        """Get failure context to inject into the next model's prompt."""
        if not self._escalation_context:
            return ""
        lines = [
            "=== CIRCUIT BREAKER: PREVIOUS FAILURES ===",
            f"Model escalated to {self.get_current_model()} after repeated failures.",
            "The code has been rolled back to the last working state.",
            "Previous failures:",
        ]
        for ctx in self._escalation_context[-5:]:  # Cap at 5 most recent
            lines.append(f"  - {ctx}")
        lines.append("Fix the ROOT CAUSE. Do NOT repeat the same approach.")
        lines.append("=== END CIRCUIT BREAKER ===")
        return "\n".join(lines)

    def clear_escalation_context(self) -> None:
        """Clear escalation context after it has been consumed."""
        self._escalation_context.clear()

    # ── Git checkpoint management ──

    def init_git(self, sandbox: Any) -> bool:
        """Initialize Git repo in the E2B sandbox for state tracking."""
        try:
            sandbox.run_terminal("git init && git add -A && git commit -m 'init' --allow-empty")
            self._git_initialized = True
            return True
        except Exception:
            return False

    def save_checkpoint(self, sandbox: Any) -> str | None:
        """Git commit the current state as a checkpoint. Returns commit hash or None."""
        if not self._git_initialized:
            self.init_git(sandbox)

        try:
            n = len(self._checkpoints)
            result = sandbox.run_terminal(
                f"git add -A && git commit -m 'checkpoint-{n}' --allow-empty 2>&1 && git rev-parse HEAD"
            )
            # Extract the commit hash (last line of output)
            lines = [l.strip() for l in (result or "").strip().split("\n") if l.strip()]
            if lines:
                commit_hash = lines[-1]
                if len(commit_hash) >= 7 and all(c in "0123456789abcdef" for c in commit_hash[:7]):
                    self._checkpoints.append(commit_hash)
                    return commit_hash
        except Exception:
            pass
        return None

    def rollback(self, sandbox: Any) -> bool:
        """Roll back to the last checkpoint."""
        if not self._checkpoints:
            # No checkpoint — try to reset to initial commit
            try:
                sandbox.run_terminal("git reset --hard HEAD~1 2>&1 || git checkout -- . 2>&1")
                return True
            except Exception:
                return False

        target = self._checkpoints[-1]
        try:
            sandbox.run_terminal(f"git reset --hard {target} 2>&1")
            return True
        except Exception:
            return False

    def run_tests(self, sandbox: Any, test_script: str) -> dict:
        """Write and execute a test script in the sandbox. Returns parsed JSON results.

        Args:
            sandbox: E2BSandbox instance
            test_script: Node.js test script content

        Returns:
            {"passed": N, "failed": N, "errors": [...]} or error dict
        """
        try:
            sandbox.write_file("_artemis_tests.js", test_script)
            result = sandbox.run_terminal("node /home/user/ArtemisProject/_artemis_tests.js 2>&1")

            # Parse JSON from stdout
            stdout = (result or "").strip()
            # Find the JSON line (last line that starts with {)
            for line in reversed(stdout.split("\n")):
                line = line.strip()
                if line.startswith("{"):
                    try:
                        parsed = json.loads(line)
                        return parsed
                    except (json.JSONDecodeError, ValueError):
                        continue

            return {"passed": 0, "failed": 1, "errors": ["test_runner: Could not parse test output"]}
        except Exception as e:
            return {"passed": 0, "failed": 1, "errors": [f"test_runner: {e}"]}

    # ── Status ──

    def get_status(self) -> dict:
        """Return current circuit breaker state for logging."""
        return {
            "model_tier": self.model_tier,
            "current_model": self.get_current_model(),
            "total_escalations": self._total_escalations,
            "active_failures": {k: v.count for k, v in self._failures.items()},
            "checkpoints": len(self._checkpoints),
            "git_initialized": self._git_initialized,
        }
