"""O3DE Agent Tools — tool functions and OpenAI function schemas for O3DE game development.

These tools allow the Artemis AI agent to control Open 3D Engine programmatically,
creating levels, entities, components, materials, physics, lighting, and building games.
"""

import json
from pathlib import Path
from typing import Any, Optional

from openartemis.o3de_bridge import O3DEBridge

# Module-level bridge instance (set by CLI when entering O3DE mode)
_bridge: Optional[O3DEBridge] = None


def set_bridge(bridge: O3DEBridge) -> None:
    """Set the active O3DE bridge instance."""
    global _bridge
    _bridge = bridge


def get_bridge() -> O3DEBridge:
    """Get the active O3DE bridge, raising if not set."""
    if _bridge is None:
        raise RuntimeError("O3DE bridge not initialized. Enter O3DE mode first.")
    return _bridge


# ── Tool Functions ──

def o3de_create_project(name: str, template: str = "Standard") -> str:
    """Create a new O3DE project with required gems enabled."""
    try:
        bridge = get_bridge()
        path = bridge.create_project(name, template=template)
        return f"Project created: {path}"
    except Exception as e:
        return f"Error: {e}"


def o3de_create_level(name: str, size: int = 1024, use_terrain: bool = True) -> str:
    """Create a new level in the current O3DE project (headless)."""
    try:
        bridge = get_bridge()
        return bridge.write_level_prefab(name, terrain=use_terrain, terrain_size=size)
    except Exception as e:
        return f"Error: {e}"


def o3de_create_entity(
    name: str,
    components: str = "",
    position: str = "0,0,0",
    parent: str = "",
) -> str:
    """Create an entity with optional components and position (headless)."""
    try:
        bridge = get_bridge()
        comp_list = [c.strip() for c in components.split(",") if c.strip()] if components else []
        pos = tuple(float(x) for x in position.split(","))
        if len(pos) != 3:
            pos = (0.0, 0.0, 0.0)
        level_name = bridge.get_current_level_name()
        return bridge.write_entity_to_level(level_name, name, comp_list, pos, parent if parent else None)
    except Exception as e:
        return f"Error: {e}"


def o3de_add_component(entity_name: str, component_type: str) -> str:
    """Add a component to an existing entity (headless)."""
    try:
        bridge = get_bridge()
        level_name = bridge.get_current_level_name()
        prefab = bridge._load_or_create_prefab(level_name)
        for eid, ent in prefab.get("Entities", {}).items():
            if ent.get("Name") == entity_name:
                comps = ent.get("Components", {})
                comp_key = component_type.replace(" ", "")
                comps[comp_key] = {"$type": component_type, "Id": bridge._new_uuid()}
                bridge._save_prefab(level_name, prefab)
                return f"Added '{component_type}' to '{entity_name}'"
        return f"Entity '{entity_name}' not found in level '{level_name}'"
    except Exception as e:
        return f"Error: {e}"


def o3de_set_property(entity_name: str, component: str, property_path: str, value: str) -> str:
    """Set a property on an entity's component (headless)."""
    try:
        bridge = get_bridge()
        level_name = bridge.get_current_level_name()
        prefab = bridge._load_or_create_prefab(level_name)
        for eid, ent in prefab.get("Entities", {}).items():
            if ent.get("Name") == entity_name:
                comps = ent.get("Components", {})
                comp_key = component.replace(" ", "")
                if comp_key in comps:
                    comps[comp_key][property_path] = value
                    bridge._save_prefab(level_name, prefab)
                    return f"Set {entity_name}.{component}.{property_path} = {value}"
                return f"Component '{component}' not found on '{entity_name}'"
        return f"Entity '{entity_name}' not found in level '{level_name}'"
    except Exception as e:
        return f"Error: {e}"


def o3de_import_asset(source_path: str, asset_type: str = "auto") -> str:
    """Import an asset (FBX, texture, audio) into the project."""
    try:
        bridge = get_bridge()
        if not bridge.project_path:
            return "Error: No project open"
        
        src = Path(source_path)
        if not src.exists():
            return f"Error: Source file not found: {source_path}"
        
        assets_dir = bridge.project_path / "Assets"
        assets_dir.mkdir(exist_ok=True)
        
        import shutil
        dest = assets_dir / src.name
        shutil.copy2(str(src), str(dest))
        
        return f"Asset imported: {dest.name} → Assets/{src.name}"
    except Exception as e:
        return f"Error: {e}"


def o3de_set_material(entity_name: str, material_path: str) -> str:
    """Assign a material to an entity's mesh component (headless)."""
    try:
        bridge = get_bridge()
        level_name = bridge.get_current_level_name()
        return bridge.set_material_on_entity(level_name, entity_name, material_path)
    except Exception as e:
        return f"Error: {e}"


def o3de_create_terrain(size: int = 1024, height_scale: float = 100.0) -> str:
    """Create terrain in the current level (headless)."""
    try:
        bridge = get_bridge()
        level_name = bridge.get_current_level_name()
        prefab = bridge._load_or_create_prefab(level_name)
        bridge._add_entity_to_prefab(
            prefab, "Terrain",
            ["Axis Aligned Box Shape", "Terrain Layer Spawner",
             "Terrain Height Gradient List", "Terrain Surface Gradient List"],
            extra_component_data={"AxisAlignedBoxShape": {"Dimensions": [size, size, height_scale]}},
        )
        bridge._save_prefab(level_name, prefab)
        return f"Terrain created ({size}x{size}, height {height_scale})"
    except Exception as e:
        return f"Error: {e}"


def o3de_setup_lighting(
    light_type: str = "Directional",
    color: str = "1.0,1.0,0.9",
    intensity: float = 4.0,
) -> str:
    """Set up scene lighting (headless)."""
    try:
        bridge = get_bridge()
        level_name = bridge.get_current_level_name()
        prefab = bridge._load_or_create_prefab(level_name)
        c = tuple(float(x) for x in color.split(","))
        if len(c) != 3:
            c = (1.0, 1.0, 0.9)
        bridge._add_entity_to_prefab(
            prefab, f"{light_type}Light", [f"{light_type} Light"],
            position=(0, 50, 0),
            extra_component_data={
                f"{light_type}Light": {"Color": list(c), "Intensity": intensity},
            },
        )
        bridge._add_entity_to_prefab(prefab, "Sky", ["HDRi Skybox", "Global Skylight (IBL)"])
        bridge._save_prefab(level_name, prefab)
        return f"Lighting set up: {light_type} light + Sky"
    except Exception as e:
        return f"Error: {e}"


def o3de_add_physics(
    entity_name: str,
    body_type: str = "Dynamic",
    collider_shape: str = "Box",
) -> str:
    """Add physics (rigid body + collider) to an entity (headless)."""
    try:
        bridge = get_bridge()
        level_name = bridge.get_current_level_name()
        return bridge.add_physics_to_entity(level_name, entity_name, body_type, collider_shape)
    except Exception as e:
        return f"Error: {e}"


def o3de_write_script(name: str, content: str, script_type: str = "lua") -> str:
    """Write a gameplay script (Lua or Python) to the project."""
    try:
        bridge = get_bridge()
        if not bridge.project_path:
            return "Error: No project open"
        
        if script_type == "lua":
            scripts_dir = bridge.project_path / "Scripts"
        else:
            scripts_dir = bridge.project_path / "Editor" / "Scripts"
        
        scripts_dir.mkdir(parents=True, exist_ok=True)
        ext = ".lua" if script_type == "lua" else ".py"
        path = scripts_dir / f"{name}{ext}"
        path.write_text(content, encoding="utf-8")
        
        return f"Script written: {path.relative_to(bridge.project_path)}"
    except Exception as e:
        return f"Error: {e}"


def o3de_run_editor_script(script_content: str) -> str:
    """Write a Python script to the project's Editor/Scripts folder (headless)."""
    try:
        bridge = get_bridge()
        if not bridge.project_path:
            return "Error: No project open"
        scripts_dir = bridge.project_path / "Editor" / "Scripts"
        scripts_dir.mkdir(parents=True, exist_ok=True)
        path = scripts_dir / "artemis_auto.py"
        path.write_text(script_content, encoding="utf-8")
        return f"Script written to {path} (will execute when Editor opens)"
    except Exception as e:
        return f"Error: {e}"


def o3de_build_game(platform: str = "PC", config: str = "profile") -> str:
    """Build the game for the target platform."""
    try:
        bridge = get_bridge()
        ok, msg = bridge.build_game(platform=platform, config=config)
        return msg
    except Exception as e:
        return f"Error: {e}"


def o3de_save_level() -> str:
    """Save the current level (headless — already saved to disk)."""
    try:
        bridge = get_bridge()
        level_name = bridge.get_current_level_name()
        prefab_path = bridge._get_prefab_path(level_name)
        if prefab_path.exists():
            return f"Level '{level_name}' is saved: {prefab_path}"
        return "No level to save."
    except Exception as e:
        return f"Error: {e}"


def o3de_project_info() -> str:
    """Get current O3DE project information."""
    try:
        bridge = get_bridge()
        info = bridge.get_project_info()
        return json.dumps(info, indent=2, default=str)
    except Exception as e:
        return f"Error: {e}"


# ── Tool Dispatch ──

def execute_o3de_tool(name: str, args: dict) -> str:
    """Execute an O3DE tool by name."""
    dispatch = {
        "o3de_create_project": lambda: o3de_create_project(args.get("name", ""), args.get("template", "Standard")),
        "o3de_create_level": lambda: o3de_create_level(args.get("name", ""), args.get("size", 1024), args.get("use_terrain", True)),
        "o3de_create_entity": lambda: o3de_create_entity(args.get("name", ""), args.get("components", ""), args.get("position", "0,0,0"), args.get("parent", "")),
        "o3de_add_component": lambda: o3de_add_component(args.get("entity_name", ""), args.get("component_type", "")),
        "o3de_set_property": lambda: o3de_set_property(args.get("entity_name", ""), args.get("component", ""), args.get("property_path", ""), args.get("value", "")),
        "o3de_import_asset": lambda: o3de_import_asset(args.get("source_path", ""), args.get("asset_type", "auto")),
        "o3de_set_material": lambda: o3de_set_material(args.get("entity_name", ""), args.get("material_path", "")),
        "o3de_create_terrain": lambda: o3de_create_terrain(args.get("size", 1024), args.get("height_scale", 100.0)),
        "o3de_setup_lighting": lambda: o3de_setup_lighting(args.get("light_type", "Directional"), args.get("color", "1.0,1.0,0.9"), args.get("intensity", 4.0)),
        "o3de_add_physics": lambda: o3de_add_physics(args.get("entity_name", ""), args.get("body_type", "Dynamic"), args.get("collider_shape", "Box")),
        "o3de_write_script": lambda: o3de_write_script(args.get("name", ""), args.get("content", ""), args.get("script_type", "lua")),
        "o3de_run_editor_script": lambda: o3de_run_editor_script(args.get("script_content", "")),
        "o3de_build_game": lambda: o3de_build_game(args.get("platform", "PC"), args.get("config", "profile")),
        "o3de_save_level": lambda: o3de_save_level(),
        "o3de_project_info": lambda: o3de_project_info(),
    }
    
    handler = dispatch.get(name)
    if handler:
        return handler()
    return f"Unknown O3DE tool: {name}"


# ── OpenAI Function Schemas ──

O3DE_TOOL_SCHEMAS = [
    {
        "type": "function",
        "function": {
            "name": "o3de_create_project",
            "description": "Create a new O3DE game project with required gems enabled. Templates: Standard, Minimal, Multiplayer.",
            "parameters": {
                "type": "object",
                "properties": {
                    "name": {"type": "string", "description": "Project name (e.g. 'MyRPG')"},
                    "template": {"type": "string", "description": "Template: Standard, Minimal, or Multiplayer", "default": "Standard"},
                },
                "required": ["name"],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "o3de_create_level",
            "description": "Create a new level/map in the O3DE project.",
            "parameters": {
                "type": "object",
                "properties": {
                    "name": {"type": "string", "description": "Level name (e.g. 'MainLevel', 'Arena')"},
                    "size": {"type": "integer", "description": "Terrain resolution (default 1024)", "default": 1024},
                    "use_terrain": {"type": "boolean", "description": "Enable terrain (default true)", "default": True},
                },
                "required": ["name"],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "o3de_create_entity",
            "description": "Create a game entity with components. Components: Transform, Mesh, Light, Camera, PhysX Rigid Body, PhysX Collider, Script Canvas, Lua Script, Audio, Particle, etc.",
            "parameters": {
                "type": "object",
                "properties": {
                    "name": {"type": "string", "description": "Entity name (e.g. 'Player', 'Enemy', 'Tree')"},
                    "components": {"type": "string", "description": "Comma-separated component names (e.g. 'Transform,Mesh,PhysX Dynamic Rigid Body')"},
                    "position": {"type": "string", "description": "Position as x,y,z (e.g. '0,5,0')", "default": "0,0,0"},
                    "parent": {"type": "string", "description": "Parent entity name (optional)"},
                },
                "required": ["name"],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "o3de_add_component",
            "description": "Add a component to an existing entity. Common components: Mesh, Light, Camera, PhysX Dynamic Rigid Body, PhysX Static Rigid Body, PhysX Box Collider, PhysX Sphere Collider, Script Canvas, Lua Script, Audio Trigger, Particle Emitter, Decal, Comment.",
            "parameters": {
                "type": "object",
                "properties": {
                    "entity_name": {"type": "string", "description": "Name of the entity to modify"},
                    "component_type": {"type": "string", "description": "Component type to add"},
                },
                "required": ["entity_name", "component_type"],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "o3de_set_property",
            "description": "Set a property value on an entity's component (position, scale, material, color, etc.).",
            "parameters": {
                "type": "object",
                "properties": {
                    "entity_name": {"type": "string", "description": "Entity name"},
                    "component": {"type": "string", "description": "Component type name"},
                    "property_path": {"type": "string", "description": "Property path (e.g. 'Settings|Color', 'Transform|Scale')"},
                    "value": {"type": "string", "description": "Value to set (Python expression)"},
                },
                "required": ["entity_name", "component", "property_path", "value"],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "o3de_import_asset",
            "description": "Import an external asset (FBX model, texture, audio file) into the project's Assets folder.",
            "parameters": {
                "type": "object",
                "properties": {
                    "source_path": {"type": "string", "description": "Path to the asset file"},
                    "asset_type": {"type": "string", "description": "Asset type hint: model, texture, audio, auto", "default": "auto"},
                },
                "required": ["source_path"],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "o3de_set_material",
            "description": "Assign a material to an entity's mesh component.",
            "parameters": {
                "type": "object",
                "properties": {
                    "entity_name": {"type": "string", "description": "Entity with a Mesh component"},
                    "material_path": {"type": "string", "description": "Material asset path (e.g. 'materials/metal.azmaterial')"},
                },
                "required": ["entity_name", "material_path"],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "o3de_create_terrain",
            "description": "Create terrain with configurable size and height scale.",
            "parameters": {
                "type": "object",
                "properties": {
                    "size": {"type": "integer", "description": "Terrain size (default 1024)", "default": 1024},
                    "height_scale": {"type": "number", "description": "Max terrain height (default 100.0)", "default": 100.0},
                },
                "required": [],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "o3de_setup_lighting",
            "description": "Set up scene lighting with type, color, and intensity. Also creates skybox.",
            "parameters": {
                "type": "object",
                "properties": {
                    "light_type": {"type": "string", "description": "Light type: Directional, Point, Spot, Area", "default": "Directional"},
                    "color": {"type": "string", "description": "RGB color as r,g,b (0-1 range, e.g. '1.0,0.9,0.8')", "default": "1.0,1.0,0.9"},
                    "intensity": {"type": "number", "description": "Light intensity (default 4.0)", "default": 4.0},
                },
                "required": [],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "o3de_add_physics",
            "description": "Add physics (rigid body + collider) to an entity.",
            "parameters": {
                "type": "object",
                "properties": {
                    "entity_name": {"type": "string", "description": "Entity to add physics to"},
                    "body_type": {"type": "string", "description": "Body type: Dynamic, Static, Kinematic", "default": "Dynamic"},
                    "collider_shape": {"type": "string", "description": "Collider shape: Box, Sphere, Capsule, Mesh", "default": "Box"},
                },
                "required": ["entity_name"],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "o3de_write_script",
            "description": "Write a gameplay script (Lua for runtime logic, Python for editor automation) to the project.",
            "parameters": {
                "type": "object",
                "properties": {
                    "name": {"type": "string", "description": "Script name without extension (e.g. 'player_controller')"},
                    "content": {"type": "string", "description": "Full script content"},
                    "script_type": {"type": "string", "description": "Script type: lua or python", "default": "lua"},
                },
                "required": ["name", "content"],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "o3de_run_editor_script",
            "description": "Write a Python script to the project (saved to Editor/Scripts). Will execute when the Editor is opened later. Use for azlmbr.* API operations not covered by other tools.",
            "parameters": {
                "type": "object",
                "properties": {
                    "script_content": {"type": "string", "description": "Python code using azlmbr APIs (written to disk, runs when Editor opens)"},
                },
                "required": ["script_content"],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "o3de_build_game",
            "description": "Build/compile the game for a target platform.",
            "parameters": {
                "type": "object",
                "properties": {
                    "platform": {"type": "string", "description": "Target platform: PC, Linux, Android, iOS", "default": "PC"},
                    "config": {"type": "string", "description": "Build config: debug, profile, release", "default": "profile"},
                },
                "required": [],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "o3de_save_level",
            "description": "Save the current level in the editor.",
            "parameters": {"type": "object", "properties": {}, "required": []},
        },
    },
    {
        "type": "function",
        "function": {
            "name": "o3de_project_info",
            "description": "Get current project information: name, path, asset count, levels, build status.",
            "parameters": {"type": "object", "properties": {}, "required": []},
        },
    },
]
