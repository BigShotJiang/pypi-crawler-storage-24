"""Worker agent — runs one task with full tool access, returns summary and findings."""

import json
import re
import os
from pathlib import Path
from typing import Any, Callable

from dotenv import load_dotenv
from openartemis.config import get_anthropic_client as _get_anthropic_client

load_dotenv(Path(__file__).resolve().parents[2] / ".env")

from openartemis.agent.detective import TOOLS, DetectiveAgent
from openartemis.config import get_max_tokens_or_default
from openartemis.token_budget import create_with_budget

WORKER_SYSTEM = """You are a research worker. You receive ONE sub-question and must answer it using your tools.

Tools: harvest_transcripts, list_transcripts, read_transcript, brave_search, fetch_webpage, browse_webpage.

Pull relevant passages from the sources you find. When done, provide a concise summary and list key findings with sources (URLs). Be thorough but focused on the sub-question."""

# Match http(s) URLs for source extraction from tool results and content
_URL_PATTERN = re.compile(r"https?://[^\s\]\)\"\'<>]+", re.IGNORECASE)


def _extract_urls(text: str) -> list[str]:
    """Extract URLs from a string (tool result or assistant content)."""
    if not text or "http" not in text:
        return []
    return list(dict.fromkeys(_URL_PATTERN.findall(text)))


def run_worker(
    task: dict,
    agent: DetectiveAgent,
    on_tool_call: Callable[[str, dict], None] | None = None,
    max_turns: int = 10,
) -> dict[str, Any]:
    """Run a single worker on one task. Returns {task_id, summary, findings, sources}."""
    task_id = task.get("id", 0)
    description = task.get("description", "")
    hint = task.get("hint", "")
    url = task.get("url", "")

    # Build user message with task context
    user_msg = f"Task: {description}"
    if hint:
        user_msg += f"\nHint: use {hint}"
    if url:
        user_msg += f"\nURL: {url}"

    messages = [
        {"role": "system", "content": WORKER_SYSTEM},
        {"role": "user", "content": user_msg},
    ]
    collected_urls: list[str] = []

    for _ in range(max_turns):
        messages_to_send = agent._trim_messages_for_budget(
            messages, max_chars=8000, tool_content_max=1500
        )
        response = create_with_budget(
            agent.client,
            agent.model,
            messages_to_send,
            max_tokens=get_max_tokens_or_default(),
        )
        content = response.choices[0].message.content or ""
        tool_calls = getattr(response, "_tool_calls", [])
        messages.append({"role": "assistant", "content": content})

        if not tool_calls:
            content = content.strip()
            # Extract findings from content
            findings = []
            for line in content.split("\n"):
                if line.strip().startswith("-") or line.strip().startswith("*"):
                    findings.append(line.strip())
            # Merge URLs from tool results (collected_urls) with URLs parsed from final content
            content_urls = _extract_urls(content)
            sources = list(dict.fromkeys(collected_urls + content_urls))[:15]
            return {
                "task_id": task_id,
                "summary": content[:2000],
                "findings": findings[:20],
                "sources": sources,
            }

        for tc in tool_calls:
            name = tc["name"]
            args = tc["input"] if isinstance(tc["input"], dict) else json.loads(tc["input"])
            if on_tool_call:
                on_tool_call(name, args)
            result = agent._execute_tool(name, args)
            # Extract URLs from this tool result for source validation
            collected_urls.extend(_extract_urls(result))
            messages.append({
                "role": "user",
                "content": f"Tool {name} returned: {result}",
            })

    return {
        "task_id": task_id,
        "summary": "Max turns reached.",
        "findings": [],
        "sources": list(dict.fromkeys(collected_urls))[:15],
    }
