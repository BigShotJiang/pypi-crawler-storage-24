"""Multi-agent pipeline — plan, run workers in parallel, verify, synthesize report (gather → filter → verify → synthesize → cite)."""

import os
import re
import time
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path
from typing import Any, Callable

from dotenv import load_dotenv
from openartemis.config import get_anthropic_client as _get_anthropic_client

load_dotenv(Path(__file__).resolve().parents[2] / ".env")

from openartemis.agent.detective import DetectiveAgent
from openartemis.agent.orchestrator import create_plan
from openartemis.agent.worker import run_worker
from openartemis.config import DEFAULT_BASE_MODEL, get_max_tokens_or_default
from openartemis.retry import retry_with_backoff
from openartemis.token_budget import create_with_budget

VERIFY_PROMPT = """You are verifying and cross-checking research results from multiple workers.

The user asked: {user_request}

Worker results (each worker answered one sub-question):

{worker_results}

Your job:
1. Identify claims that appear in multiple sources (agreement).
2. Flag any conflicts between sources (e.g. different dates, contradictory facts).
3. Resolve or note conflicts: prefer the best-sourced claim or state "sources disagree: X vs Y".

Output a single text block with two sections:
## Verified findings
(Bullet points: claim [sources that support it]. Resolve conflicts here.)
## Conflicts resolved
(Short note on any conflicts and how you resolved them, or "None found.")

Do not invent information. Use only what is in the worker results."""

SYNTHESIS_PROMPT = """You are writing a final sourced report from verified research.

The user asked: {user_request}

Verified findings (already cross-checked):

{verified_text}

Write a single report with:
- **Executive summary** (2-4 sentences)
- **Key findings** — each finding must include inline citations like [1], [2] referring to the numbered Sources list
- **Conclusions**
- **Sources** — numbered list of URLs/sources cited in the report (match the [1], [2] numbers)

Rules:
- Every factual claim in Key findings must have a citation [N].
- Sources section must be numbered and match the citations.
- Be concise. Do not add information not present in the verified findings."""


class ResearchPipeline:
    """Multi-agent research: plan → parallel workers (gather) → verify → synthesize → cite."""

    def __init__(
        self,
        anthropic_api_key: str | None = None,
        youtube_api_key: str | None = None,
        scrapingdog_api_key: str | None = None,
        transcriptapi_api_key: str | None = None,
        model: str | None = None,
        plan_model: str | None = None,
        worker_model: str | None = None,
        out_dir: Path | None = None,
        max_workers: int = 8,
    ):
        base = model or DEFAULT_BASE_MODEL
        self.plan_model = plan_model if plan_model is not None else base
        self.worker_model = worker_model if worker_model is not None else base
        self.model = base
        self.agent = DetectiveAgent(
            anthropic_api_key=anthropic_api_key,
            youtube_api_key=youtube_api_key or os.environ.get("YOUTUBE_API_KEY"),
            scrapingdog_api_key=scrapingdog_api_key or os.environ.get("SCRAPINGDOG_API_KEY"),
            transcriptapi_api_key=transcriptapi_api_key or os.environ.get("TRANSCRIPTAPI_API_KEY"),
            model=self.worker_model,
            out_dir=out_dir or Path("./detective_output"),
        )
        self.client = _get_anthropic_client()
        from openartemis.config import get_profile_setting
        profile_workers = get_profile_setting("max_workers")
        self.max_workers = int(profile_workers) if profile_workers is not None else max_workers

    def run(
        self,
        user_request: str,
        on_tool_call: Callable[[str, dict], None] | None = None,
        on_stage: Callable[[str], None] | None = None,
        on_plan_done: Callable[[int], None] | None = None,
        on_task_done: Callable[[int, int], None] | None = None,
        on_log: Callable[[str], None] | None = None,
        approve_before_phase: Callable[[str], bool] | None = None,
    ) -> str:
        """Run full pipeline: plan → workers (parallel) → verify → synthesize. Returns final report.
        If approve_before_phase is set, it is called after plan and after gather with phase name;
        if it returns False, the run exits early with a partial result."""
        def _stage(s: str) -> None:
            if on_stage:
                on_stage(s)
        def _log(msg: str) -> None:
            if on_log:
                on_log(msg)

        _stage("Planning…")
        # Try to generate a plan via research/LLM, fall back to template if proxy unavailable
        try:
            tasks = create_plan(user_request, model=self.plan_model)
        except Exception as e:
            # If proxy/network fails, generate a simple template plan
            if "getaddrinfo" in str(e).lower() or "proxy" in str(e).lower():
                tasks = [
                    {"task": "Choose tech stack", "description": "Select appropriate framework (React/Vue/Vanilla JS + Node/Python backend)", "tools": []},
                    {"task": "Design UI layout", "description": "Create wireframe and component structure for chat interface", "tools": []},
                    {"task": "Build frontend", "description": "Implement chat UI with message history, input field, and send functionality", "tools": ["write_file"]},
                    {"task": "Build backend", "description": "Create API endpoints for sending/receiving messages", "tools": ["write_file"]},
                    {"task": "Connect frontend-backend", "description": "Wire up API calls between UI and server", "tools": ["write_file"]},
                ]
            else:
                raise
        if not tasks:
            return "Could not create a research plan. Please try rephrasing your request."
        if on_plan_done:
            on_plan_done(len(tasks))
        _log(f"Created {len(tasks)} sub-questions")
        if approve_before_phase and not approve_before_phase("plan"):
            return "Research stopped after plan (user chose not to continue)."
        _stage("Gathering…")

        worker_results: list[dict[str, Any]] = []
        total_sources_so_far = 0

        def run_one(task: dict) -> dict[str, Any]:
            def _run() -> dict[str, Any]:
                return run_worker(task, self.agent, on_tool_call=on_tool_call)
            return retry_with_backoff(
                _run,
                max_attempts=3,
                backoff_base=2.0,
                on_retry=lambda attempt, e: _log(f"Retry {attempt} for task {task.get('id')}: {e}") if on_log else None,
            )

        # For gpt-4o workers, run only 1 at a time to stay under TPM
        gather_workers = 1 if self.worker_model == "gpt-4o" else self.max_workers
        with ThreadPoolExecutor(max_workers=gather_workers) as executor:
            futures = {executor.submit(run_one, t): t for t in tasks}
            for future in as_completed(futures):
                try:
                    result = future.result()
                    worker_results.append(result)
                    n_sources = len(result.get("sources", []))
                    total_sources_so_far += n_sources
                    if on_task_done:
                        on_task_done(result.get("task_id", 0), total_sources_so_far)
                    _log(f"Sub-question {result.get('task_id', '?')} done — {n_sources} sources")
                except Exception as e:
                    from openartemis.errors import ErrorType, classify_exception
                    task = futures[future]
                    err_type = classify_exception(e)
                    worker_results.append({
                        "task_id": task.get("id", 0),
                        "summary": f"[{err_type.value}] {e}",
                        "findings": [],
                        "sources": [],
                    })
                    if on_task_done:
                        on_task_done(task.get("id", 0), total_sources_so_far)
                    _log(f"Sub-question {task.get('id', '?')} error ({err_type.value}): {e}")
                    if err_type == ErrorType.RATE_LIMIT:
                        time.sleep(2.0)

        # Sort by task_id for consistent ordering
        worker_results.sort(key=lambda r: r.get("task_id", 0))
        if approve_before_phase and not approve_before_phase("gather"):
            # Partial export: raw worker summaries
            parts = [f"## Partial (stopped after gather)\n\nUser asked: {user_request}\n"]
            for r in worker_results:
                parts.append(f"\n### Task {r.get('task_id')}\n{r.get('summary', '')}\n")
            return "\n".join(parts)

        _stage("Verifying…")
        _log("Cross-checking claims and resolving conflicts…")

        # Build text for verify step; cap to stay under TPM, strip log lines
        _MAX_VERIFY_CHARS = 12_000

        def _strip_log_lines(text: str) -> str:
            """Drop lines that look like status/log (e.g. '  10:09:46 ...', 'Log:', 'Retry N for task')."""
            lines = text.split("\n")
            out = []
            for line in lines:
                stripped = line.strip()
                if re.match(r"^\d{1,2}:\d{2}:\d{2}\s", stripped) or stripped.startswith("Log:") or re.match(r"^Retry\s+\d+", stripped, re.I):
                    continue
                out.append(line)
            return "\n".join(out)

        results_text = "\n\n---\n\n".join(
            f"Task {r['task_id']}:\n{r['summary']}\n\nFindings: {r.get('findings', [])}\nSources: {r.get('sources', [])}"
            for r in worker_results
        )
        results_text = _strip_log_lines(results_text)
        if len(results_text) > _MAX_VERIFY_CHARS:
            results_text = results_text[:_MAX_VERIFY_CHARS] + "\n\n[truncated for length]"

        # Verify: cross-check claims, resolve conflicts
        verify_messages = [
            {"role": "system", "content": "You verify and cross-check research; resolve conflicts."},
            {"role": "user", "content": VERIFY_PROMPT.format(
                user_request=user_request,
                worker_results=results_text,
            )},
        ]
        verify_resp = create_with_budget(
            self.client,
            self.worker_model,
            verify_messages,
            max_tokens=get_max_tokens_or_default(),
        )
        verified_text = (verify_resp.choices[0].message.content or "").strip()
        if not verified_text:
            verified_text = results_text
        if len(verified_text) > _MAX_VERIFY_CHARS:
            verified_text = verified_text[:_MAX_VERIFY_CHARS] + "\n\n[truncated]"

        _stage("Synthesizing…")
        _log("Writing sourced report…")

        # Synthesize: final report with inline citations [1], [2] and Sources list
        synthesis_messages = [
            {"role": "system", "content": "You write sourced reports with inline citations and a numbered Sources list."},
            {"role": "user", "content": SYNTHESIS_PROMPT.format(
                user_request=user_request,
                verified_text=verified_text,
            )},
        ]
        synthesis_resp = create_with_budget(
            self.client,
            self.worker_model,
            synthesis_messages,
            max_tokens=get_max_tokens_or_default(),
        )
        report = (synthesis_resp.choices[0].message.content or "").strip()
        if not report:
            # Fallback: if synthesis comes back empty, return the verified findings instead
            report = "Synthesis returned no content. Showing verified findings instead:\n\n" + verified_text
        try:
            from openartemis.self_eval import self_eval_enabled, score_report
            if self_eval_enabled():
                _log("Running self-eval rubric…")
                scores = score_report(report, user_request, model=self.worker_model)
                if scores:
                    overall = scores.get("overall", 0)
                    _log(f"Self-eval: {overall}/5 overall — {scores.get('feedback', '')[:80]}")
                    report = report + f"\n\n---\n**Self-eval:** {overall}/5 overall (completeness {scores.get('completeness', 0)}, citations {scores.get('citations', 0)}, clarity {scores.get('clarity', 0)})."
        except Exception:
            pass
        _stage("Done")
        return report
