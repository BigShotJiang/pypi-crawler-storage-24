"""Per-run audit / replay log — one JSON object per line for debugging and replay."""

import json
from datetime import datetime, timezone
from pathlib import Path
from typing import Any


def replay_path_for(output_path: Path | None) -> Path | None:
    """Path to the .replay.jsonl file for this run."""
    if output_path is None:
        return None
    return output_path.parent / (output_path.stem + ".replay.jsonl")


def _now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()


def append_replay_line(path: Path | None, obj: dict[str, Any]) -> None:
    """Append one JSON object as a single line to the replay log."""
    if path is None:
        return
    try:
        path.parent.mkdir(parents=True, exist_ok=True)
        line = json.dumps(obj, ensure_ascii=False) + "\n"
        with open(path, "a", encoding="utf-8") as f:
            f.write(line)
    except OSError:
        pass


def log_phase(replay_path: Path | None, phase: str, message: str, step: int | None = None) -> None:
    """Log a phase/transition (e.g. plan created, step started)."""
    append_replay_line(replay_path, {
        "t": _now_iso(),
        "phase": phase,
        "message": message,
        **({"step": step} if step is not None else {}),
    })


def log_tool(
    replay_path: Path | None,
    step: int,
    phase: str,
    tool: str,
    args: dict[str, Any],
    result_preview: str,
) -> None:
    """Log a tool call with result preview (truncate result for readability)."""
    preview = (result_preview or "")[:500]
    if len(result_preview or "") > 500:
        preview += "..."
    append_replay_line(replay_path, {
        "t": _now_iso(),
        "step": step,
        "phase": phase,
        "tool": tool,
        "args": args,
        "result_preview": preview,
    })


def log_audit(
    replay_path: Path | None,
    event: str,
    **kwargs: Any,
) -> None:
    """Log a generic audit event (e.g. error, canceled, paused, rate_limit, retry)."""
    append_replay_line(replay_path, {"t": _now_iso(), "event": event, **kwargs})
