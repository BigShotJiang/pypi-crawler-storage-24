"""Artemis Proxy Client — routes all AI/search calls through the Artemis proxy server.

The client NEVER has API keys. It only holds a session token obtained at login.
All real keys live on the server (server/proxy.py).
"""

from __future__ import annotations

import json
import os
from pathlib import Path
from typing import Any, Generator, Iterator

import httpx

# Session token stored at ~/.openartemis/session.json (same file auth uses)
_SESSION_FILE = Path.home() / ".openartemis" / "session.json"


def _proxy_url() -> str:
    return os.environ.get("ARTEMIS_PROXY_URL", "https://openartemis.com").rstrip("/")


def _get_token() -> str | None:
    """Read client key: env var ARTEMIS_CLIENT_KEY first, then session file."""
    # Env var takes priority (E2B-style — user sets once in .env)
    env_key = os.environ.get("ARTEMIS_CLIENT_KEY", "").strip()
    if env_key:
        return env_key
    # Fall back to session file (saved by login flow)
    try:
        if _SESSION_FILE.exists():
            data = json.loads(_SESSION_FILE.read_text(encoding="utf-8"))
            return data.get("token")
    except Exception:
        pass
    return None


def _auth_headers() -> dict[str, str]:
    token = _get_token()
    if not token:
        raise RuntimeError(
            "Not logged in. Run 'openartemis' and log in first."
        )
    return {"Authorization": f"Bearer {token}", "Content-Type": "application/json"}


def is_authenticated() -> bool:
    """Check if a valid session token exists."""
    return bool(_get_token())


def save_session(token: str, user_id: str, role: str = "user") -> None:
    """Save session token to disk after login."""
    _SESSION_FILE.parent.mkdir(parents=True, exist_ok=True)
    _SESSION_FILE.write_text(
        json.dumps({"token": token, "user_id": user_id, "role": role}),
        encoding="utf-8",
    )


def clear_session() -> None:
    """Remove session token from disk (logout)."""
    try:
        _SESSION_FILE.unlink(missing_ok=True)
    except Exception:
        pass


# ── OpenAI-compatible proxy calls ─────────────────────────────────────────────

class ProxyCompletionChunk:
    """Minimal wrapper to mimic openai.types.chat.ChatCompletionChunk."""
    def __init__(self, data: dict):
        self._data = data
        # delta.content accessor
        choices = data.get("choices", [{}])
        delta = choices[0].get("delta", {}) if choices else {}
        self.choices = [type("C", (), {
            "delta": type("D", (), {
                "content": delta.get("content"),
                "tool_calls": delta.get("tool_calls"),
                "role": delta.get("role"),
            })(),
            "finish_reason": choices[0].get("finish_reason") if choices else None,
        })()]


class ProxyMessage:
    """Minimal wrapper to mimic openai message object."""
    def __init__(self, data: dict):
        self.content = data.get("content")
        self.role = data.get("role", "assistant")
        tc_raw = data.get("tool_calls")
        if tc_raw:
            self.tool_calls = [_make_tool_call(tc) for tc in tc_raw]
        else:
            self.tool_calls = None


def _make_tool_call(tc: dict):
    fn = tc.get("function", {})
    return type("TC", (), {
        "id": tc.get("id", ""),
        "type": tc.get("type", "function"),
        "function": type("F", (), {
            "name": fn.get("name", ""),
            "arguments": fn.get("arguments", "{}"),
        })(),
    })()


class ProxyResponse:
    """Minimal wrapper to mimic openai.types.chat.ChatCompletion."""
    def __init__(self, data: dict):
        self._data = data
        choices = data.get("choices", [{}])
        msg_data = choices[0].get("message", {}) if choices else {}
        self.choices = [type("C", (), {
            "message": ProxyMessage(msg_data),
            "finish_reason": choices[0].get("finish_reason") if choices else None,
        })()]
        usage = data.get("usage", {})
        self.usage = type("U", (), {
            "prompt_tokens": usage.get("prompt_tokens", 0),
            "completion_tokens": usage.get("completion_tokens", 0),
            "total_tokens": usage.get("total_tokens", 0),
        })()


def chat_completions_create(
    model: str,
    messages: list[dict],
    stream: bool = False,
    **kwargs,
) -> ProxyResponse | Iterator[ProxyCompletionChunk]:
    """Drop-in replacement for openai_client.chat.completions.create().
    Routes through proxy server — no API key on client side."""
    url = f"{_proxy_url()}/v1/chat/completions"
    payload: dict[str, Any] = {"model": model, "messages": messages, "stream": stream, **kwargs}

    if stream:
        return _stream_completions(url, payload)
    else:
        resp = httpx.post(url, headers=_auth_headers(), json=payload, timeout=120.0)
        if resp.status_code == 401:
            raise RuntimeError("Session expired. Please log in again.")
        if resp.status_code == 429:
            raise RuntimeError("Rate limit exceeded. Slow down requests.")
        if resp.status_code != 200:
            raise RuntimeError(f"Proxy error {resp.status_code}: {resp.text[:200]}")
        return ProxyResponse(resp.json())


def _stream_completions(url: str, payload: dict) -> Iterator[ProxyCompletionChunk]:
    """Stream SSE chunks from proxy, yield ProxyCompletionChunk objects."""
    with httpx.stream(
        "POST", url, headers=_auth_headers(), json=payload, timeout=120.0
    ) as resp:
        if resp.status_code == 401:
            raise RuntimeError("Session expired. Please log in again.")
        if resp.status_code != 200:
            raise RuntimeError(f"Proxy error {resp.status_code}")
        for line in resp.iter_lines():
            if not line or line == "data: [DONE]":
                continue
            if line.startswith("data: "):
                try:
                    chunk_data = json.loads(line[6:])
                    yield ProxyCompletionChunk(chunk_data)
                except json.JSONDecodeError:
                    continue


# ── Search proxy ───────────────────────────────────────────────────────────────

def brave_search(query: str, count: int = 10) -> dict:
    """Search via proxy — no Brave API key on client."""
    url = f"{_proxy_url()}/v1/search"
    resp = httpx.post(
        url, headers=_auth_headers(), json={"query": query, "count": count}, timeout=15.0
    )
    if resp.status_code != 200:
        raise RuntimeError(f"Search proxy error {resp.status_code}: {resp.text[:200]}")
    return resp.json()


def scrape_url(url: str) -> str:
    """Scrape a URL via proxy — no ScrapingDog key on client."""
    resp = httpx.post(
        f"{_proxy_url()}/v1/scrape",
        headers=_auth_headers(),
        json={"url": url},
        timeout=30.0,
    )
    if resp.status_code != 200:
        raise RuntimeError(f"Scrape proxy error {resp.status_code}")
    return resp.text


# ── ProxyOpenAIClient — drop-in replacement for openai.OpenAI() ──────────────

class _ChatCompletions:
    """Mimics openai_client.chat.completions interface."""

    def create(self, model: str, messages: list, stream: bool = False, **kwargs):
        return chat_completions_create(model, messages, stream=stream, **kwargs)


class _Chat:
    def __init__(self):
        self.completions = _ChatCompletions()


class ProxyOpenAIClient:
    """Drop-in replacement for openai.OpenAI() that routes through proxy server.
    
    Usage:
        client = ProxyOpenAIClient()
        resp = client.chat.completions.create(model="gpt-4.1-mini", messages=[...])
    """

    def __init__(self, **kwargs):
        # Ignore any api_key passed — we use the proxy
        self.chat = _Chat()
        # Expose api_key attribute so existing checks like `if not client.api_key` work
        self.api_key = "proxy"  # truthy sentinel — not a real key
