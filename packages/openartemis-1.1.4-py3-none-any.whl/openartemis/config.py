"""Config loading — .env from project, ~/.openartemis, or cwd. Default keys for zero-setup."""

import os
from pathlib import Path

from dotenv import load_dotenv

# OpenArtemis data dir (same as auth)
CONFIG_DIR = Path.home() / ".openartemis"
CONFIG_ENV = CONFIG_DIR / ".env"

# Artemis model aliases — never expose real model names in UI
# Powered by Anthropic Claude
DEFAULT_BASE_MODEL = "claude-sonnet-4-5"
ARTEMIS_MODEL_MAP = {
    # Flagship — Artemis-1 (Opus 4.5 — most capable)
    "artemis-1": "claude-opus-4-5",
    "artemis-1-flagship": "claude-opus-4-5",
    "opus-4.5": "claude-opus-4-5",
    # Balanced — Artemis-0.5 (Sonnet 4.5 — fast & smart)
    "artemis-0.5": "claude-sonnet-4-5",
    "artemis-1-mini": "claude-sonnet-4-5",
    "sonnet-4.5": "claude-sonnet-4-5",
    # Vision-capable (same as flagship)
    "artemis-1-vision": "claude-opus-4-5",
}


def resolve_artemis_model(alias: str | None) -> str:
    """Resolve Artemis alias to real model ID. Default: gpt-5-mini.

    For fine-tuned models, you can either:
    - Add a new key to ARTEMIS_MODEL_MAP (e.g. \"artemis-1-agent-ft\")
      pointing at the concrete fine-tuned model ID, or
    - Set OPENARTEMIS_AGENT_MODEL to the full model ID and bypass the map.
    """
    if not alias:
        return DEFAULT_BASE_MODEL
    key = (alias or "").strip().lower()
    return ARTEMIS_MODEL_MAP.get(key, DEFAULT_BASE_MODEL)


# Default max output tokens per completion when OPENARTEMIS_MAX_TOKENS is unset (avoids huge TPM reservation)
DEFAULT_MAX_TOKENS = 1500
# Higher cap for single-file builds (e.g. one index.html) so worker can output full file in one go
DEFAULT_MAX_TOKENS_FULL_FILE = 6000


def get_max_tokens() -> int | None:
    """Return OPENARTEMIS_MAX_TOKENS if set (per-completion cap), else None (no cap)."""
    v = os.environ.get("OPENARTEMIS_MAX_TOKENS", "").strip()
    if not v:
        return None
    try:
        n = int(v)
        return n if n > 0 else None
    except ValueError:
        return None


def get_max_tokens_or_default() -> int:
    """Return get_max_tokens() or DEFAULT_MAX_TOKENS. Use for all chat completions to cap output reservation."""
    return get_max_tokens() or DEFAULT_MAX_TOKENS


def _model_uses_max_completion_tokens(model: str) -> bool:
    """True if this model uses the newer max_completion_tokens param."""
    m = (model or DEFAULT_BASE_MODEL).strip().lower()
    # Fine-tuned models: check the base model after "ft:"
    if m.startswith("ft:"):
        m = m[3:]  # e.g. "gpt-4.1-mini-2025-..."
    # Modern model families that use max_completion_tokens
    for prefix in ("gpt-5", "gpt-4.1", "gpt-4o", "gpt-4.5", "o1", "o3", "o4"):
        if m.startswith(prefix):
            return True
    return False


def completion_tokens_kwarg(value: int, model: str | None = None) -> dict:
    """Return kwargs for chat.completions.create: use max_completion_tokens for modern models, else max_tokens."""
    use_new = _model_uses_max_completion_tokens(model or DEFAULT_BASE_MODEL)
    return {"max_completion_tokens" if use_new else "max_tokens": value}


def get_build_model() -> str:
    """Return the cheap model used for build/tool turns in Agent OS.

    Defaults to claude-haiku-4-5 (fast, cheap). Override with OPENARTEMIS_BUILD_MODEL.
    """
    v = os.environ.get("OPENARTEMIS_BUILD_MODEL", "").strip()
    if v:
        return resolve_artemis_model(v) if "artemis" in v.lower() else v
    return "claude-haiku-4-5"  # fast/cheap build turns


def get_max_turns_per_step() -> int:
    """Return OPENARTEMIS_MAX_TURNS_PER_STEP (default 12). Caps tool-call rounds per worker step."""
    v = os.environ.get("OPENARTEMIS_MAX_TURNS_PER_STEP", "").strip()
    if v:
        try:
            n = int(v)
            return max(1, min(n, 20))
        except ValueError:
            pass
    return 12


def get_max_tokens_full_file() -> int:
    """Return OPENARTEMIS_MAX_TOKENS_FULL_FILE or DEFAULT_MAX_TOKENS_FULL_FILE. Use for worker when plan is single-file."""
    v = os.environ.get("OPENARTEMIS_MAX_TOKENS_FULL_FILE", "").strip()
    if v:
        try:
            n = int(v)
            return max(2048, min(n, 32768))
        except ValueError:
            pass
    return DEFAULT_MAX_TOKENS_FULL_FILE


def get_max_credits() -> int | None:
    """Return OPENARTEMIS_MAX_CREDITS if set (per-session credits cap), else None (no cap)."""
    v = os.environ.get("OPENARTEMIS_MAX_CREDITS", "").strip()
    if not v:
        return None
    try:
        n = int(v)
        return n if n > 0 else None
    except ValueError:
        return None


# Permission mode for agent: ask (prompt before edit/run), auto-edit (allow edits, ask for run), auto-all (allow all), deny-writes (read-only)
PERMISSION_MODES = ("ask", "auto-edit", "auto-all", "deny-writes")


def get_permission_mode() -> str:
    """Return OPENARTEMIS_PERMISSION_MODE: ask, auto-edit, auto-all, or deny-writes. Default: ask."""
    v = os.environ.get("OPENARTEMIS_PERMISSION_MODE", "ask").strip().lower()
    if v in PERMISSION_MODES:
        return v
    return "ask"


def _flag_enabled(env_name: str, default: bool = True) -> bool:
    """Return a boolean feature flag from an env var.

    Truthy: 1, true, yes, on
    Falsy: 0, false, no, off
    Anything else falls back to the provided default.
    """
    raw = os.environ.get(env_name, "").strip().lower()
    if not raw:
        return default
    if raw in ("1", "true", "yes", "on"):
        return True
    if raw in ("0", "false", "no", "off"):
        return False
    return default


def agent_clarify_and_prd_enabled() -> bool:
    """Whether the agent should run a Clarify+PRD phase before planning.

    Controlled by OPENARTEMIS_AGENT_ENABLE_CLARIFY_PRD (default: on).
    """
    return _flag_enabled("OPENARTEMIS_AGENT_ENABLE_CLARIFY_PRD", default=True)


def agent_reviewer_enabled() -> bool:
    """Whether the final rubric-based reviewer pass should run.

    Controlled by OPENARTEMIS_AGENT_ENABLE_REVIEWER (default: on).
    """
    return _flag_enabled("OPENARTEMIS_AGENT_ENABLE_REVIEWER", default=True)


def get_plan_model() -> str:
    """Return OPENARTEMIS_PLAN_MODEL (lead/planning). Default: artemis-1 (gpt-5-mini).

    If OPENARTEMIS_AGENT_MODEL is set, it overrides the default alias so that
    a fine-tuned agent model can be used for both plan and exec without
    changing code.
    """
    override = os.environ.get("OPENARTEMIS_AGENT_MODEL", "").strip()
    if override:
        return resolve_artemis_model(override) if "artemis" in override.lower() else override
    v = os.environ.get("OPENARTEMIS_PLAN_MODEL", "").strip() or "artemis-1"
    return resolve_artemis_model(v) if ("artemis" in v.lower() or not v) else v


def get_exec_model() -> str:
    """Return OPENARTEMIS_EXEC_MODEL (worker/execution). Default: artemis-1-mini (gpt-5-mini).

    If OPENARTEMIS_AGENT_MODEL is set, it overrides the default alias so that
    a fine-tuned agent model can be used for both plan and exec without
    changing code.
    """
    override = os.environ.get("OPENARTEMIS_AGENT_MODEL", "").strip()
    if override:
        return resolve_artemis_model(override) if "artemis" in override.lower() else override
    v = os.environ.get("OPENARTEMIS_EXEC_MODEL", "").strip() or "artemis-1-mini"
    return resolve_artemis_model(v) if ("artemis" in v.lower() or not v) else v


# API keys are stored encrypted in the vault module (_vault.py).
# They are never present in plaintext anywhere in the package.
_DEFAULTS: dict[str, str] = {}  # kept for backward compat; vault overrides all

# Proxy server endpoint — set ARTEMIS_PROXY_URL to override (e.g. for self-hosting)
ARTEMIS_PROXY_URL = os.environ.get("ARTEMIS_PROXY_URL", "https://openartemis.com").rstrip("/")


def _ensure_default_config() -> None:
    """Create ~/.openartemis/.env placeholder if missing."""
    if not CONFIG_ENV.exists():
        CONFIG_DIR.mkdir(parents=True, exist_ok=True)
        CONFIG_ENV.write_text(
            "# OpenArtemis config\n"
            "# Keys are managed server-side. No API keys needed here.\n"
            "# Override proxy server: ARTEMIS_PROXY_URL=https://your-server.com\n",
            encoding="utf-8",
        )


def _apply_defaults() -> None:
    """Inject API keys from the bundled configuration."""
    try:
        from openartemis._cfg import inject
        inject()
    except Exception:
        pass


# Profile-driven defaults (OPENARTEMIS_PROFILE=local|cloud|rl-heavy)
PROFILE_CONFIGS: dict[str, dict[str, int | str]] = {
    "local": {"max_workers": 3, "default_model": "artemis-1-mini"},
    "cloud": {"max_workers": 8, "default_model": "artemis-1-mini"},
    "rl-heavy": {"max_workers": 4, "default_model": "artemis-1-mini"},
}


def get_profile() -> str:
    """Current profile from OPENARTEMIS_PROFILE. Default: cloud."""
    v = os.environ.get("OPENARTEMIS_PROFILE", "").strip().lower()
    if v in PROFILE_CONFIGS:
        return v
    return "cloud"


def get_profile_setting(key: str, default: int | str | None = None) -> int | str | None:
    """Get a profile-specific setting (e.g. max_workers, default_model)."""
    profile = get_profile()
    cfg = PROFILE_CONFIGS.get(profile, {})
    if key in cfg:
        return cfg[key]
    return default


def load_config() -> None:
    """Load .env from project root, ~/.openartemis, then cwd. Apply defaults for zero-setup."""
    pkg_root = Path(__file__).resolve().parents[1]
    load_dotenv(pkg_root / ".env")
    load_dotenv(CONFIG_ENV)
    load_dotenv(Path.cwd() / ".env")
    _ensure_default_config()
    _apply_defaults()


def get_anthropic_client(**kwargs):
    """Return an Anthropic client using the configured API key."""
    api_key = os.environ.get("ANTHROPIC_API_KEY", "").strip()
    from anthropic import Anthropic
    return Anthropic(api_key=api_key, **kwargs)


def get_openai_client(**kwargs):
    """Return an OpenAI client using the configured API key. Kept for legacy callers."""
    api_key = os.environ.get("OPENAI_API_KEY", "").strip()
    from openai import OpenAI
    return OpenAI(api_key=api_key, **kwargs)
