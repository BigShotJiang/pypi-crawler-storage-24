"""Autonomous project launcher for non-technical users."""

import os
import sys
import time
import subprocess
import webbrowser
from pathlib import Path
from typing import Dict, List, Optional, Tuple
import questionary
import json
import threading
from rich.console import Console
from rich.panel import Panel
from rich.text import Text
from rich import print as rprint

console = Console()


class ProjectLauncher:
    """Manages project detection, launching, and process management."""
    
    def __init__(self, project_path: Path):
        self.project_path = project_path
        self.processes: Dict[str, subprocess.Popen] = {}
        self.status = "Stopped"
        self.url = None
        self.port = None
        self.project_type = None
        
    def detect_project_type(self) -> str:
        """Detect the type of project based on files."""
        files = list(self.project_path.rglob("*"))
        file_names = [f.name.lower() for f in files if f.is_file()]
        
        # Check for HTML
        if any(f.endswith('.html') for f in file_names):
            return "html"
        
        # Check for React/Vue/Angular
        if 'package.json' in file_names:
            with open(self.project_path / 'package.json', 'r') as f:
                package = json.load(f)
                deps = {**package.get('dependencies', {}), **package.get('devDependencies', {})}
                if 'react' in deps:
                    return "react"
                elif 'vue' in deps:
                    return "vue"
                elif '@angular/core' in deps:
                    return "angular"
                else:
                    return "nodejs"
        
        # Check for Python
        if any(f.endswith('.py') for f in file_names):
            if 'requirements.txt' in file_names or 'pyproject.toml' in file_names:
                return "python-app"
            return "python-script"
        
        # Check for other types
        if 'cargo.toml' in file_names:
            return "rust"
        if 'go.mod' in file_names:
            return "go"
        if 'pom.xml' in file_names:
            return "java"
        
        # Check for O3DE project
        if 'project.json' in file_names and any('gamelauncher' in f for f in file_names):
            return "o3de"
        if any(f == 'editor' for f in [d.name.lower() for d in self.project_path.iterdir() if d.is_dir()]):
            if (self.project_path / "Gem").exists() or (self.project_path / "project.json").exists():
                return "o3de"
        
        return "unknown"
    
    def get_launch_commands(self, project_type: str) -> List[Dict]:
        """Get available commands for the project type."""
        commands = []
        
        if project_type == "html":
            commands = [
                {"name": "Open in Browser", "cmd": self._open_html_in_browser, "type": "primary"},
                {"name": "Start Local Server", "cmd": self._start_html_server, "type": "secondary"}
            ]
        
        elif project_type == "react":
            commands = [
                {"name": "Start Development Server", "cmd": self._start_react_dev, "type": "primary"},
                {"name": "Build for Production", "cmd": self._build_react, "type": "secondary"},
                {"name": "Install Dependencies", "cmd": self._npm_install, "type": "setup"}
            ]
        
        elif project_type == "vue":
            commands = [
                {"name": "Start Development Server", "cmd": self._start_vue_dev, "type": "primary"},
                {"name": "Build for Production", "cmd": self._build_vue, "type": "secondary"},
                {"name": "Install Dependencies", "cmd": self._npm_install, "type": "setup"}
            ]
        
        elif project_type == "nodejs":
            commands = [
                {"name": "Start Application", "cmd": self._start_node_app, "type": "primary"},
                {"name": "Install Dependencies", "cmd": self._npm_install, "type": "setup"}
            ]
        
        elif project_type == "python-app":
            commands = [
                {"name": "Run Application", "cmd": self._run_python_app, "type": "primary"},
                {"name": "Install Dependencies", "cmd": self._pip_install, "type": "setup"}
            ]
        
        elif project_type == "python-script":
            commands = [
                {"name": "Run Script", "cmd": self._run_python_script, "type": "primary"}
            ]
        
        elif project_type == "o3de":
            commands = [
                {"name": "Launch Game", "cmd": self._launch_o3de_game, "type": "primary"},
                {"name": "Open in O3DE Editor", "cmd": self._open_o3de_editor, "type": "secondary"},
                {"name": "Build Game", "cmd": self._build_o3de_game, "type": "setup"},
            ]
        
        return commands
    
    def _open_html_in_browser(self) -> Tuple[bool, str]:
        """Open HTML file in browser."""
        html_files = list(self.project_path.glob("*.html"))
        if not html_files:
            html_files = list(self.project_path.rglob("*.html"))
        
        if html_files:
            html_file = html_files[0]
            file_url = f"file://{html_file.absolute()}"
            webbrowser.open(file_url)
            self.url = file_url
            self.status = "Opened in Browser"
            return True, f"Opened {html_file.name} in browser"
        
        return False, "No HTML file found"
    
    def _start_html_server(self) -> Tuple[bool, str]:
        """Start a local HTTP server for HTML files."""
        try:
            # Try Python 3 first
            cmd = [sys.executable, "-m", "http.server", "8000"]
            process = subprocess.Popen(
                cmd,
                cwd=self.project_path,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                creationflags=subprocess.CREATE_NEW_PROCESS_GROUP if os.name == 'nt' else 0
            )
            self.processes["server"] = process
            self.url = "http://localhost:8000"
            self.port = 8000
            self.status = "Running"
            
            # Open browser after a short delay
            threading.Timer(2.0, lambda: webbrowser.open(self.url)).start()
            
            return True, "Server started at http://localhost:8000"
        except Exception as e:
            return False, f"Failed to start server: {e}"
    
    def _start_react_dev(self) -> Tuple[bool, str]:
        """Start React development server."""
        return self._run_npm_command("start", "Starting React dev server...")
    
    def _build_react(self) -> Tuple[bool, str]:
        """Build React app for production."""
        return self._run_npm_command("build", "Building React app...")
    
    def _start_vue_dev(self) -> Tuple[bool, str]:
        """Start Vue development server."""
        return self._run_npm_command("dev", "Starting Vue dev server...")
    
    def _build_vue(self) -> Tuple[bool, str]:
        """Build Vue app for production."""
        return self._run_npm_command("build", "Building Vue app...")
    
    def _start_node_app(self) -> Tuple[bool, str]:
        """Start Node.js application."""
        package_json = self.project_path / "package.json"
        if package_json.exists():
            with open(package_json, 'r') as f:
                package = json.load(f)
                main_file = package.get('main', 'index.js')
                
            cmd = [sys.executable, "-c", f"import subprocess; subprocess.run(['node', '{main_file}'])"]
            try:
                process = subprocess.Popen(
                    ["node", main_file],
                    cwd=self.project_path,
                    stdout=subprocess.PIPE,
                    stderr=subprocess.PIPE,
                    creationflags=subprocess.CREATE_NEW_PROCESS_GROUP if os.name == 'nt' else 0
                )
                self.processes["app"] = process
                self.status = "Running"
                return True, f"Started {main_file}"
            except Exception as e:
                return False, f"Failed to start: {e}"
        
        return False, "No main file found in package.json"
    
    def _run_python_app(self) -> Tuple[bool, str]:
        """Run Python application."""
        # Look for main.py, app.py, or index.py
        main_files = ["main.py", "app.py", "index.py"]
        for main_file in main_files:
            if (self.project_path / main_file).exists():
                return self._run_python_file(main_file)
        
        return False, "No main Python file found"
    
    def _run_python_script(self) -> Tuple[bool, str]:
        """Run any Python script."""
        py_files = list(self.project_path.glob("*.py"))
        if py_files:
            return self._run_python_file(py_files[0].name)
        
        return False, "No Python file found"
    
    def _run_python_file(self, filename: str) -> Tuple[bool, str]:
        """Run a specific Python file."""
        try:
            process = subprocess.Popen(
                [sys.executable, filename],
                cwd=self.project_path,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                creationflags=subprocess.CREATE_NEW_PROCESS_GROUP if os.name == 'nt' else 0
            )
            self.processes["app"] = process
            self.status = "Running"
            return True, f"Running {filename}"
        except Exception as e:
            return False, f"Failed to run: {e}"
    
    def _npm_install(self) -> Tuple[bool, str]:
        """Install npm dependencies."""
        return self._run_npm_command("install", "Installing dependencies...")
    
    def _pip_install(self) -> Tuple[bool, str]:
        """Install Python dependencies."""
        if (self.project_path / "requirements.txt").exists():
            try:
                subprocess.run(
                    [sys.executable, "-m", "pip", "install", "-r", "requirements.txt"],
                    cwd=self.project_path,
                    check=True
                )
                return True, "Dependencies installed"
            except subprocess.CalledProcessError as e:
                return False, f"Failed to install: {e}"
        
        return False, "No requirements.txt found"
    
    def _run_npm_command(self, command: str, description: str) -> Tuple[bool, str]:
        """Run an npm command."""
        try:
            # Check if npm is available
            subprocess.run(["npm", "--version"], check=True, capture_output=True)
            
            process = subprocess.Popen(
                ["npm", "run", command],
                cwd=self.project_path,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                creationflags=subprocess.CREATE_NEW_PROCESS_GROUP if os.name == 'nt' else 0
            )
            self.processes["npm"] = process
            self.status = "Running"
            
            # Try to detect URL from output
            if command in ["start", "dev"]:
                threading.Timer(3.0, self._detect_url_from_output).start()
            
            return True, f"{description}"
        except subprocess.CalledProcessError:
            return False, "npm not available"
        except Exception as e:
            return False, f"Failed to run: {e}"
    
    def _detect_url_from_output(self):
        """Try to detect URL from npm output."""
        if "npm" in self.processes:
            process = self.processes["npm"]
            if process.poll() is None:  # Still running
                # Read output without blocking
                try:
                    import select
                    if os.name == 'nt':
                        # Windows doesn't support select on pipes
                        return
                    ready, _, _ = select.select([process.stdout], [], [], 0.1)
                    if ready:
                        output = process.stdout.read(1024).decode()
                        if "localhost:" in output:
                            import re
                            match = re.search(r'(http://localhost:\d+)', output)
                            if match:
                                self.url = match.group(1)
                                webbrowser.open(self.url)
                except:
                    pass
    
    def stop_all(self):
        """Stop all running processes."""
        for name, process in self.processes.items():
            try:
                if os.name == 'nt':
                    process.terminate()
                else:
                    process.terminate()
                process.wait(timeout=5)
            except:
                try:
                    process.kill()
                except:
                    pass
        self.processes.clear()
        self.status = "Stopped"
    
    # ── O3DE Launch Methods ──
    
    def _launch_o3de_game(self) -> Tuple[bool, str]:
        """Launch the built O3DE game."""
        try:
            from openartemis.o3de_bridge import O3DEBridge
            bridge = O3DEBridge()
            bridge.open_project(self.project_path)
            launcher = bridge.get_game_launcher()
            if launcher:
                process = subprocess.Popen(
                    [str(launcher)],
                    cwd=str(launcher.parent),
                    creationflags=subprocess.CREATE_NEW_PROCESS_GROUP if os.name == 'nt' else 0,
                )
                self.processes["o3de_game"] = process
                self.status = "Game Running"
                return True, f"Game launched: {launcher.name}"
            return False, "Game not built yet. Use 'Build Game' first."
        except Exception as e:
            return False, f"Failed to launch game: {e}"
    
    def _open_o3de_editor(self) -> Tuple[bool, str]:
        """Open the project in O3DE Editor."""
        try:
            from openartemis.o3de_bridge import O3DEBridge
            bridge = O3DEBridge()
            bridge.open_project(self.project_path)
            editor = bridge.get_editor_exe()
            process = subprocess.Popen(
                [editor, f"--project-path={self.project_path}"],
                cwd=str(self.project_path),
                creationflags=subprocess.CREATE_NEW_PROCESS_GROUP if os.name == 'nt' else 0,
            )
            self.processes["o3de_editor"] = process
            self.status = "Editor Open"
            return True, "O3DE Editor launched"
        except Exception as e:
            return False, f"Failed to open editor: {e}"
    
    def _build_o3de_game(self) -> Tuple[bool, str]:
        """Build the O3DE game executable."""
        try:
            from openartemis.o3de_bridge import O3DEBridge
            bridge = O3DEBridge()
            bridge.open_project(self.project_path)
            ok, msg = bridge.build_game()
            if ok:
                self.status = "Built"
            return ok, msg
        except Exception as e:
            return False, f"Build failed: {e}"

    def get_status_display(self) -> str:
        """Get formatted status display."""
        status_color = {
            "Running": "green",
            "Stopped": "red",
            "Starting": "yellow",
            "Opened in Browser": "blue"
        }.get(self.status, "dim")
        
        lines = [f"Status: [{status_color}]{self.status}[/{status_color}]"]
        
        if self.url:
            lines.append(f"URL: {self.url}")
        
        if self.port:
            lines.append(f"Port: {self.port}")
        
        return "\n".join(lines)


def auto_start_project(project_path: Path) -> bool:
    """Auto-start the project with zero user interaction."""
    launcher = ProjectLauncher(project_path)
    launcher.project_type = launcher.detect_project_type()
    
    console.print(f"\n[cyan]🚀 Auto-starting {launcher.project_type} project...[/cyan]")
    
    # Get the primary command for this project type
    commands = launcher.get_launch_commands(launcher.project_type)
    primary_cmd = next((cmd for cmd in commands if cmd["type"] == "primary"), None)
    
    if primary_cmd:
        success, message = primary_cmd["cmd"]()
        if success:
            console.print(f"[green]✅ {message}[/green]")
            
            # Show brief instructions
            console.print("\n[dim]Your project is running![/dim]")
            if launcher.url:
                console.print(f"[dim]URL: {launcher.url}[/dim]")
            console.print("[dim]Press Ctrl+C to stop when you're done.[/dim]")
            
            # Keep running until user stops it
            try:
                while True:
                    time.sleep(1)
            except KeyboardInterrupt:
                console.print("\n[dim]Stopping project...[/dim]")
                launcher.stop_all()
                console.print("[green]✅ Project stopped[/green]")
            
            return True
        else:
            console.print(f"[red]❌ {message}[/red]")
            return False
    else:
        console.print(f"[yellow]⚠️ No auto-start available for {launcher.project_type} projects[/yellow]")
        console.print("[dim]Use the interactive menu for more options.[/dim]")
        return False


def show_project_menu(project_path: Path):
    """Show the interactive project management menu."""
    launcher = ProjectLauncher(project_path)
    launcher.project_type = launcher.detect_project_type()
    
    while True:
        console.clear()
        
        # Title
        console.print(Panel(
            f"[bold cyan]🚀 Project Ready![/bold cyan]\n\n"
            f"Type: [bold]{launcher.project_type.title()}[/bold]\n"
            f"Location: {project_path}\n\n"
            f"{launcher.get_status_display()}",
            title="Project Management",
            border_style="cyan"
        ))
        
        # Get available commands
        commands = launcher.get_launch_commands(launcher.project_type)
        
        # Build menu choices
        choices = []
        for cmd in commands:
            icon = "▶️" if cmd["type"] == "primary" else "⚙️"
            choices.append(questionary.Choice(f"{icon} {cmd['name']}", value=cmd['cmd']))
        
        choices.extend([
            questionary.Choice("📁 Open Folder", value="open_folder"),
            questionary.Choice("📋 View Instructions", value="instructions"),
            questionary.Choice("❌ Exit", value="exit")
        ])
        
        # Show menu
        action = questionary.select(
            "\nWhat would you like to do?",
            choices=choices,
        ).ask()
        
        if action == "exit":
            launcher.stop_all()
            console.print("[dim]Goodbye![/dim]")
            break
        
        elif action == "open_folder":
            os.startfile(project_path) if os.name == 'nt' else os.system(f'open "{project_path}"')
        
        elif action == "instructions":
            show_instructions(launcher.project_type)
        
        else:
            # Execute command
            success, message = action()
            if success:
                console.print(f"[green]✅ {message}[/green]")
                if launcher.url and launcher.status == "Running":
                    console.print(f"[dim]Opening in browser...[/dim]")
            else:
                console.print(f"[red]❌ {message}[/red]")
            
            if action != "exit":
                console.print("\n[dim]Press Enter to continue...[/dim]")
                input()


def show_instructions(project_type: str):
    """Show instructions for the project type."""
    instructions = {
        "html": (
            "📄 HTML Project\n\n"
            "This is a simple HTML project.\n"
            "• It will open directly in your browser\n"
            "• No installation required\n"
            "• Edit files to see changes"
        ),
        "react": (
            "⚛️ React Project\n\n"
            "This is a React web application.\n"
            "• 'Start Development Server' runs it locally\n"
            "• Changes will auto-reload in the browser\n"
            "• 'Build for Production' creates optimized files"
        ),
        "vue": (
            "💚 Vue Project\n\n"
            "This is a Vue web application.\n"
            "• 'Start Development Server' runs it locally\n"
            "• Changes will auto-reload in the browser\n"
            "• 'Build for Production' creates optimized files"
        ),
        "python-app": (
            "🐍 Python Application\n\n"
            "This is a Python application.\n"
            "• 'Run Application' starts the program\n"
            "• May need dependencies installed first\n"
            "• Check the terminal for output"
        ),
        "python-script": (
            "🐍 Python Script\n\n"
            "This is a simple Python script.\n"
            "• 'Run Script' executes the code\n"
            "• Output appears in the terminal\n"
            "• No installation needed"
        )
    }
    
    instruction = instructions.get(project_type, "📁 Project Files\n\nNo specific instructions available.")
    
    console.print(Panel(
        instruction,
        title="Instructions",
        border_style="blue"
    ))
    
    console.print("\n[dim]Press Enter to go back...[/dim]")
    input()
