#!/usr/bin/env python3
"""Run slice pipeline. Usage: uv run python scripts/test_slice.py [path]"""
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
if str(ROOT / "src") not in sys.path:
    sys.path.insert(0, str(ROOT / "src"))

def main():

    from hecvec import Slicer
    path = Path(sys.argv[1]).expanduser().resolve() if len(sys.argv) >= 2 else (ROOT / "tests/CNSF-S0043-0032-2025_CONDUSEF-005190-08.txt")
    slicer = Slicer()
    print(slicer.slice(path=path, chroma_mode="server"))
    return 0

if __name__ == "__main__":
    sys.exit(main())
