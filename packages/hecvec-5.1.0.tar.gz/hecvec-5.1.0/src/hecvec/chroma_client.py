"""
Chroma client and collection operations. One module = one responsibility: connect and add documents.
Requires: pip install hecvec[chroma] (chromadb).
"""
from __future__ import annotations

import logging
import socket
from typing import TYPE_CHECKING, Literal

if TYPE_CHECKING:
    import chromadb

DEFAULT_HOST = "localhost"
DEFAULT_PORT = 8000

ChromaMode = Literal["auto", "server", "ephemeral"]

logger = logging.getLogger(__name__)


def _is_port_listening(host: str, port: int, timeout: float = 2.0) -> bool:
    """Return True if something is listening on host:port."""
    try:
        with socket.create_connection((host, port), timeout=timeout):
            return True
    except (OSError, socket.error):
        return False


def get_client(
    host: str = DEFAULT_HOST,
    port: int = DEFAULT_PORT,
    persist_path: str | None = None,
    mode: ChromaMode = "auto",
):
    """
    Return a Chroma client and mode. All backends use the same Chroma API (same add/query methods).

    - persist_path set: use PersistentClient(path). Data on disk. Returns (client, "persistent").
    - mode "ephemeral": use EphemeralClient(). In-memory, no persistence. Returns (client, "ephemeral").
    - mode "server": use HttpClient(host, port) only. Raises if server unreachable. Returns (client, "server").
    - mode "auto": try server, then fall back to ephemeral. Returns (client, "server") or (client, "ephemeral").
    """
    import chromadb
    if persist_path is not None:
        client = chromadb.PersistentClient(path=persist_path)
        return client, "persistent"
    if mode == "ephemeral":
        return chromadb.EphemeralClient(), "ephemeral"
    if mode == "server":
        logger.info("[5/5] Checking if Chroma server is listening at %s:%s...", host, port)
        if not _is_port_listening(host, port):
            logger.error("[5/5] Nothing is listening at %s:%s", host, port)
            raise RuntimeError(
                f"Nothing is listening on {host}:{port} (chroma_mode='server' requires a running Chroma server). "
                f"Start one with: docker run -p 8000:8000 chromadb/chroma"
            )
        logger.info("[5/5] Chroma server is reachable at %s:%s", host, port)
        client = chromadb.HttpClient(host=host, port=port)
        return client, "server"
    # auto: try server, fall back to ephemeral
    try:
        client = chromadb.HttpClient(host=host, port=port)
        return client, "server"
    except Exception:
        return chromadb.EphemeralClient(), "ephemeral"


def get_or_create_collection(
    client: "chromadb.HttpClient",
    name: str,
    metadata: dict | None = None,
):
    """Get or create a collection (cosine similarity by default)."""
    if metadata is None:
        metadata = {"hnsw:space": "cosine"}
    return client.get_or_create_collection(name=name, metadata=metadata)


def add_documents(
    client: "chromadb.HttpClient",
    collection_name: str,
    ids: list[str],
    embeddings: list[list[float]],
    documents: list[str],
) -> dict:
    """
    Add documents to a collection. If dimension mismatch, deletes and recreates the collection.
    Returns {"collection_existed": bool} so the caller can log whether the collection was pre-existing.
    """
    import chromadb
    existing_names = [c.name for c in client.list_collections()]
    collection_existed = collection_name in existing_names
    coll = get_or_create_collection(client, collection_name)
    try:
        coll.add(ids=ids, embeddings=embeddings, documents=documents)
    except chromadb.errors.InvalidArgumentError as e:
        if "dimension" not in str(e).lower():
            raise
        client.delete_collection(name=collection_name)
        coll = client.create_collection(
            name=collection_name,
            metadata={"hnsw:space": "cosine"},
        )
        coll.add(ids=ids, embeddings=embeddings, documents=documents)
        collection_existed = False  # we recreated it
    return {"collection_existed": collection_existed}
