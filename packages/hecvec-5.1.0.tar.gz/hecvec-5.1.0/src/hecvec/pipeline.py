"""
Pipeline: composes listdir → read → token-chunk → embed → Chroma.
One module = one responsibility: orchestrate the full slice() flow.
"""
from __future__ import annotations

import logging
import sys
from pathlib import Path
from time import perf_counter
from typing import Any

from hecvec.chroma_client import add_documents, get_client
from hecvec.chroma_client import ChromaMode
from hecvec.chunkers import ChunkingMethod, chunk_documents as chunk_documents_by_method
from hecvec.embeddings import embed_texts
from hecvec.env import load_openai_key
from hecvec.listdir import ListDirTextFiles
from hecvec.reading import ReadText

logger = logging.getLogger(__name__)


def _ensure_slice_logging() -> None:
    """If hecvec logging has no handlers, attach a stream handler at INFO so slice() progress is visible."""
    hecvec_logger = logging.getLogger("hecvec")
    if not hecvec_logger.handlers:
        handler = logging.StreamHandler(sys.stdout)
        handler.setLevel(logging.INFO)
        handler.setFormatter(logging.Formatter("%(message)s"))
        hecvec_logger.setLevel(logging.INFO)
        hecvec_logger.addHandler(handler)
    elif hecvec_logger.level == logging.NOTSET:
        hecvec_logger.setLevel(logging.INFO)


def _check_chroma_deps() -> None:
    try:
        import chromadb  # noqa: F401
        from langchain_text_splitters import TokenTextSplitter  # noqa: F401
        from openai import OpenAI  # noqa: F401
    except ImportError as e:
        raise ImportError(
            "Chroma pipeline requires chromadb and other deps. Install with:\n"
            "  pip install hecvec[chroma]\n"
            "Then run your script with the same Python (or same venv) you used to install. "
            "If you're in the HecVec repo, use: uv run python scripts/test_slice.py ..."
        ) from e


class Slicer:
    """
    Library-only pipeline. No API.
    Call slice(path=...) to: list path → filter .txt/.md → token-chunk → push to Chroma.
    """

    def __init__(
        self,
        *,
        root: str | Path | None = None,
        collection_name: str = "hecvec",
        chroma_host: str = "localhost",
        chroma_port: int = 8000,
        chroma_mode: ChromaMode = "auto",
        chroma_persist_path: str | Path | None = None,
        embedding_model: str = "text-embedding-3-small",
        chunk_size: int = 200,
        chunk_overlap: int = 0,
        encoding_name: str = "cl100k_base",
        batch_size: int = 100,
        openai_api_key: str | None = None,
        dotenv_path: str | Path | None = None,
    ):
        self.root = Path(root).resolve() if root else Path.cwd()
        self.collection_name = collection_name
        self.chroma_host = chroma_host
        self.chroma_port = chroma_port
        self.chroma_mode = chroma_mode
        self.chroma_persist_path = chroma_persist_path
        self.embedding_model = embedding_model
        self.chunk_size = chunk_size
        self.chunk_overlap = chunk_overlap
        self.encoding_name = encoding_name
        self.batch_size = batch_size
        self._dotenv_path = dotenv_path
        self._openai_api_key = openai_api_key or load_openai_key(dotenv_path)

    def slice(
        self,
        path: str | Path,
        **kwargs: Any,
    ) -> dict[str, Any]:
        """Run the pipeline for this instance (uses instance config)."""
        return Slicer.slice(
            path,
            root=kwargs.pop("root", self.root),
            collection_name=kwargs.pop("collection_name", self.collection_name),
            chroma_host=kwargs.pop("chroma_host", self.chroma_host),
            chroma_port=kwargs.pop("chroma_port", self.chroma_port),
            chroma_mode=kwargs.pop("chroma_mode", self.chroma_mode),
            chroma_persist_path=kwargs.pop("chroma_persist_path", self.chroma_persist_path),
            embedding_model=kwargs.pop("embedding_model", self.embedding_model),
            chunk_size=kwargs.pop("chunk_size", self.chunk_size),
            chunk_overlap=kwargs.pop("chunk_overlap", self.chunk_overlap),
            encoding_name=kwargs.pop("encoding_name", self.encoding_name),
            batch_size=kwargs.pop("batch_size", self.batch_size),
            chunking_method=kwargs.pop("chunking_method", "token"),
            openai_api_key=kwargs.pop("openai_api_key", self._openai_api_key),
            dotenv_path=kwargs.pop("dotenv_path", self._dotenv_path),
            **kwargs,
        )

    @classmethod
    def slice(
        cls,
        path: str | Path,
        *,
        root: str | Path | None = None,
        collection_name: str = "hecvec",
        chroma_host: str = "localhost",
        chroma_port: int = 8000,
        chroma_mode: ChromaMode = "auto",
        chroma_persist_path: str | Path | None = None,
        embedding_model: str = "text-embedding-3-small",
        chunk_size: int = 200,
        chunk_overlap: int = 0,
        encoding_name: str = "cl100k_base",
        batch_size: int = 100,
        chunking_method: ChunkingMethod = "token",
        openai_api_key: str | None = None,
        dotenv_path: str | Path | None = None,
        **kwargs: Any,
    ) -> dict[str, Any]:
        """
        Run the full pipeline: find path → listdir → filter .txt/.md → token-chunk → push to Chroma.
        No API; everything runs in the library.
        """
        _check_chroma_deps()
        _ensure_slice_logging()

        total_start = perf_counter()
        logger.info("[0/5] Starting slice | path=%s | method=%s | model=%s", path, chunking_method, embedding_model)

        path = Path(path).resolve()
        if not path.exists():
            raise ValueError(f"path does not exist: {path}")

        if collection_name == "hecvec":
            collection_name = path.stem if path.is_file() else path.name
        collection_name = f"{collection_name}_{chunking_method}"

        logger.info("Resolved collection name: %s", collection_name)

        stage_start = perf_counter()
        if path.is_file():
            if path.suffix.lower() not in (".txt", ".md"):
                raise ValueError(f"File must be .txt or .md: {path}")
            root = path.parent
            paths = [path]
            logger.info("Single file: %s", path)
        else:
            root = Path(root).resolve() if root else path
            if not root.is_dir():
                raise ValueError(f"path must be an existing directory: {root}")
            logger.info("Scanning directory: %s", root)
            lister = ListDirTextFiles(root=root)
            paths = lister.listdir_recursive_txt_md(path)
            if not paths:
                logger.warning("No .txt/.md files found under %s", path)
                return {"files": 0, "chunks": 0, "collection": collection_name, "message": "No .txt/.md files found"}
            logger.info("Found %d .txt/.md file(s)", len(paths))
            for p in paths[:10]:
                logger.info("  %s", p)
            if len(paths) > 10:
                logger.info("  ... and %d more", len(paths) - 10)

        logger.info("[1/5] File discovery completed in %.2fs (%d file(s))", perf_counter() - stage_start, len(paths))

        # 2/5 Read as text
        stage_start = perf_counter()
        logger.info("[2/5] Reading content from %d file(s)...", len(paths))
        reader = ReadText(paths)
        path_and_text = reader.read_all()
        logger.info("[2/5] Read completed in %.2fs (%d/%d file(s) read)", perf_counter() - stage_start, len(path_and_text), len(paths))
        if len(path_and_text) < len(paths):
            logger.warning("Some files could not be read and were skipped (%d skipped)", len(paths) - len(path_and_text))

        # 3/5 Chunk (token, text, semantic, or llm)
        stage_start = perf_counter()
        api_key = openai_api_key or load_openai_key(dotenv_path)
        logger.info("[3/5] Chunking | method=%s | chunk_size=%d | overlap=%d", chunking_method, chunk_size, chunk_overlap)
        ids, documents = chunk_documents_by_method(
            path_and_text,
            method=chunking_method,
            chunk_size=chunk_size,
            chunk_overlap=chunk_overlap,
            encoding_name=encoding_name,
            openai_api_key=api_key,
        )
        if not documents:
            logger.warning("[3/5] No chunks generated (empty or non-text content)")
            return {"files": len(path_and_text), "chunks": 0, "collection": collection_name}

        logger.info("[3/5] Chunking completed in %.2fs (%d chunk(s))", perf_counter() - stage_start, len(documents))

        # 4/5 Embed
        api_key = openai_api_key or load_openai_key(dotenv_path)
        if not api_key:
            raise ValueError(
                "OPENAI_API_KEY required for embeddings. "
                "Set it in .env, pass openai_api_key=, or set the OPENAI_API_KEY env var."
            )
        stage_start = perf_counter()
        logger.info("[4/5] Generating embeddings | model=%s | batch_size=%d | chunk_count=%d", embedding_model, batch_size, len(documents))
        embeddings = embed_texts(
            documents,
            api_key=api_key,
            model=embedding_model,
            batch_size=batch_size,
        )
        logger.info("[4/5] Embeddings completed in %.2fs (%d vector(s))", perf_counter() - stage_start, len(embeddings))

        # 5/5 Push to Chroma
        stage_start = perf_counter()
        logger.info("[5/5] Chroma | host=%s | port=%s | collection=%s | chroma_mode=%s", chroma_host, chroma_port, collection_name, chroma_mode)
        client, chroma_mode_used = get_client(
            host=chroma_host,
            port=chroma_port,
            persist_path=str(chroma_persist_path) if chroma_persist_path is not None else None,
            mode=chroma_mode,
        )
        if chroma_mode_used == "server":
            logger.info("[5/5] Chroma: connected to server at %s:%s (data can persist)", chroma_host, chroma_port)
        elif chroma_mode_used == "persistent":
            logger.info("[5/5] Chroma: using persistent storage at %s (data persists on disk)", chroma_persist_path)
        else:
            logger.info("[5/5] Chroma: not connected to server; using in-memory (ephemeral). Data is lost when this process exits.")
        existing_names = [c.name for c in client.list_collections()]
        if collection_name in existing_names:
            logger.info("[5/5] Collection %r already exists; skipping (no new documents added).", collection_name)
            logger.info("Slice finished in %.2fs | files=%d | chunks=0 | collection=%s | (skipped: already exists)", perf_counter() - total_start, len(path_and_text), collection_name)
            return {
                "files": len(path_and_text),
                "chunks": 0,
                "collection": collection_name,
                "message": "Collection already exists; no documents added.",
            }
        logger.info("[5/5] Adding %d document chunk(s) to collection...", len(documents))
        add_documents(client, collection_name, ids, embeddings, documents)
        logger.info("[5/5] Collection %r created (new)", collection_name)
        logger.info("[5/5] Chroma write completed in %.2fs", perf_counter() - stage_start)

        logger.info("Slice finished in %.2fs | files=%d | chunks=%d | collection=%s", perf_counter() - total_start, len(path_and_text), len(documents), collection_name)

        return {
            "files": len(path_and_text),
            "chunks": len(documents),
            "collection": collection_name,
        }

