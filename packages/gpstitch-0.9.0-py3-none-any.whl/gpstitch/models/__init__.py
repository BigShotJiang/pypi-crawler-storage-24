"""Data models for GPStitch."""
