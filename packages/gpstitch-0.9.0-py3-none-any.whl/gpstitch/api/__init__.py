"""API endpoints for GPStitch."""
