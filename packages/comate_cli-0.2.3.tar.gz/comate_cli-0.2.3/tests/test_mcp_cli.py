from __future__ import annotations

import json
from pathlib import Path

import pytest

from comate_agent_sdk.mcp.health import McpServerHealth
from comate_cli.mcp_cli import McpCliError, run_mcp_command


def _read_json(path: Path) -> dict:
    return json.loads(path.read_text(encoding="utf-8"))


def test_mcp_add_http_writes_user_scope(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    home = tmp_path / "home"
    project = tmp_path / "project"
    monkeypatch.setattr(Path, "home", lambda: home)

    run_mcp_command(
        [
            "add",
            "--transport",
            "http",
            "context7",
            "https://mcp.context7.com/mcp",
            "--header",
            "CONTEXT7_API_KEY: abc",
        ],
        project_root=project,
    )

    path = home / ".agent" / ".mcp.json"
    payload = _read_json(path)
    assert payload["mcpServers"]["context7"]["type"] == "http"
    assert payload["mcpServers"]["context7"]["headers"]["CONTEXT7_API_KEY"] == "abc"


def test_mcp_add_stdio_writes_project_scope(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    home = tmp_path / "home"
    project = tmp_path / "project"
    monkeypatch.setattr(Path, "home", lambda: home)

    run_mcp_command(
        [
            "add",
            "--scope",
            "project",
            "-e",
            "API_KEY=xyz",
            "firecrawl",
            "--",
            "npx",
            "-y",
            "firecrawl-mcp",
        ],
        project_root=project,
    )

    path = project / ".agent" / ".mcp.json"
    payload = _read_json(path)
    firecrawl = payload["mcpServers"]["firecrawl"]
    assert firecrawl["command"] == "npx"
    assert firecrawl["args"] == ["-y", "firecrawl-mcp"]
    assert firecrawl["env"]["API_KEY"] == "xyz"


def test_mcp_command_accepts_str_project_root(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    home = tmp_path / "home"
    project = tmp_path / "project"
    monkeypatch.setattr(Path, "home", lambda: home)

    run_mcp_command(
        ["add", "--scope", "project", "github", "--", "npx", "github-mcp"],
        project_root=str(project),
    )

    path = project / ".agent" / ".mcp.json"
    payload = _read_json(path)
    assert payload["mcpServers"]["github"]["command"] == "npx"


def test_mcp_list_effective_prefers_project_scope(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
    capsys: pytest.CaptureFixture[str],
) -> None:
    home = tmp_path / "home"
    project = tmp_path / "project"
    monkeypatch.setattr(Path, "home", lambda: home)

    user_path = home / ".agent" / ".mcp.json"
    project_path = project / ".agent" / ".mcp.json"
    user_path.parent.mkdir(parents=True, exist_ok=True)
    project_path.parent.mkdir(parents=True, exist_ok=True)
    user_path.write_text(
        json.dumps(
            {"mcpServers": {"github": {"type": "http", "url": "https://user.example/mcp"}}}
        ),
        encoding="utf-8",
    )
    project_path.write_text(
        json.dumps(
            {
                "mcpServers": {
                    "github": {"type": "http", "url": "https://project.example/mcp"}
                }
            }
        ),
        encoding="utf-8",
    )

    async def _fake_health(*, servers, connect_timeout_s=10.0, call_timeout_s=60.0):  # type: ignore[no-untyped-def]
        del connect_timeout_s, call_timeout_s
        return [
            McpServerHealth(
                alias="github",
                server_type="http",
                endpoint=servers["github"]["url"],  # type: ignore[index]
                connected=True,
                reason=None,
                tool_count=1,
            )
        ]

    monkeypatch.setattr("comate_cli.mcp_cli.collect_mcp_server_health", _fake_health)
    run_mcp_command(["list"], project_root=project)

    out = capsys.readouterr().out
    assert "https://project.example/mcp" in out
    assert "✓ Connected" in out


def test_mcp_get_effective_reports_source_scope(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
    capsys: pytest.CaptureFixture[str],
) -> None:
    home = tmp_path / "home"
    project = tmp_path / "project"
    monkeypatch.setattr(Path, "home", lambda: home)

    project_path = project / ".agent" / ".mcp.json"
    project_path.parent.mkdir(parents=True, exist_ok=True)
    project_path.write_text(
        json.dumps(
            {
                "mcpServers": {
                    "context7": {
                        "type": "http",
                        "url": "https://mcp.context7.com/mcp",
                        "headers": {"CONTEXT7_API_KEY": "ctx7-token"},
                    }
                }
            }
        ),
        encoding="utf-8",
    )

    async def _fake_health(*, servers, connect_timeout_s=10.0, call_timeout_s=60.0):  # type: ignore[no-untyped-def]
        del connect_timeout_s, call_timeout_s
        return [
            McpServerHealth(
                alias="context7",
                server_type="http",
                endpoint=servers["context7"]["url"],  # type: ignore[index]
                connected=True,
                reason=None,
                tool_count=1,
            )
        ]

    monkeypatch.setattr("comate_cli.mcp_cli.collect_mcp_server_health", _fake_health)
    run_mcp_command(["get", "context7"], project_root=project)

    out = capsys.readouterr().out
    assert "Scope: Project config" in out
    assert "CONTEXT7_API_KEY: ctx7-token" in out


def test_mcp_remove_default_scope_is_user(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    home = tmp_path / "home"
    project = tmp_path / "project"
    monkeypatch.setattr(Path, "home", lambda: home)

    user_path = home / ".agent" / ".mcp.json"
    project_path = project / ".agent" / ".mcp.json"
    user_path.parent.mkdir(parents=True, exist_ok=True)
    project_path.parent.mkdir(parents=True, exist_ok=True)
    user_path.write_text(
        json.dumps({"mcpServers": {"github": {"command": "npx"}}}),
        encoding="utf-8",
    )
    project_path.write_text(
        json.dumps({"mcpServers": {"github": {"command": "node"}}}),
        encoding="utf-8",
    )

    run_mcp_command(["remove", "github"], project_root=project)

    user_payload = _read_json(user_path)
    project_payload = _read_json(project_path)
    assert "github" not in user_payload["mcpServers"]
    assert "github" in project_payload["mcpServers"]


def test_mcp_remove_missing_server_raises_error(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    home = tmp_path / "home"
    project = tmp_path / "project"
    monkeypatch.setattr(Path, "home", lambda: home)

    with pytest.raises(McpCliError, match="not found"):
        run_mcp_command(["remove", "missing"], project_root=project)


def test_mcp_add_rejects_unknown_option_instead_of_writing_shifted_config(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    home = tmp_path / "home"
    project = tmp_path / "project"
    monkeypatch.setattr(Path, "home", lambda: home)

    with pytest.raises(McpCliError, match="unrecognized arguments: --heder token"):
        run_mcp_command(
            [
                "add",
                "--transport",
                "http",
                "context7",
                "https://mcp.context7.com/mcp",
                "--heder",
                "token",
            ],
            project_root=project,
        )

    assert not (home / ".agent" / ".mcp.json").exists()


def test_mcp_add_requires_separator_for_stdio_trailing_args(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    home = tmp_path / "home"
    project = tmp_path / "project"
    monkeypatch.setattr(Path, "home", lambda: home)

    with pytest.raises(McpCliError, match="unrecognized arguments: -y firecrawl-mcp"):
        run_mcp_command(
            ["add", "firecrawl", "npx", "-y", "firecrawl-mcp"],
            project_root=project,
        )
