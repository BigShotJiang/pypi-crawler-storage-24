from __future__ import annotations

import asyncio
import types
import unittest

from comate_cli.terminal_agent.app import _preload_mcp_in_tui


class _FakeRuntime:
    def __init__(self) -> None:
        self.options = types.SimpleNamespace(mcp_enabled=True)
        self._mcp_manager = types.SimpleNamespace(
            failed_servers=[],
            tool_infos=[types.SimpleNamespace(server_alias="ctx7")],
        )
        self.start_calls = 0
        self.awaited = asyncio.Event()

    def start_mcp_preload(self) -> asyncio.Task[None]:
        self.start_calls += 1

        async def _worker() -> None:
            await asyncio.sleep(0)
            self.awaited.set()

        return asyncio.create_task(_worker())


class _FakeSession:
    def __init__(self, runtime: _FakeRuntime) -> None:
        self.runtime = runtime
        self._agent = None


class TestAppMcpPreload(unittest.IsolatedAsyncioTestCase):
    async def test_preload_mcp_in_tui_uses_runtime_public_entry(self) -> None:
        runtime = _FakeRuntime()
        session = _FakeSession(runtime)

        await _preload_mcp_in_tui(session)  # type: ignore[arg-type]

        self.assertEqual(runtime.start_calls, 1)
        self.assertTrue(runtime.awaited.is_set())


if __name__ == "__main__":
    unittest.main(verbosity=2)
