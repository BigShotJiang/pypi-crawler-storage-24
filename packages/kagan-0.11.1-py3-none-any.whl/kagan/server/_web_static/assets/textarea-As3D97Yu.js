import{l as o,j as a,m as i}from"./index-C2TuB5Ti.js";/**
 * @license lucide-react v0.469.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const n=o("ChevronDown",[["path",{d:"m6 9 6 6 6-6",key:"qrunsl"}]]);function s({className:r,...e}){return a.jsx("textarea",{"data-slot":"textarea",className:i("flex field-sizing-content min-h-16 w-full border border-input bg-[color:var(--surface-1)] px-3 py-2 text-base shadow-[var(--inset-shadow)] transition-[border-color,color,box-shadow,background-color] outline-none placeholder:text-muted-foreground focus-visible:border-ring focus-visible:ring-[3px] focus-visible:ring-ring/50 disabled:cursor-not-allowed disabled:opacity-50 aria-invalid:border-destructive aria-invalid:ring-destructive/20 md:text-sm dark:aria-invalid:ring-destructive/40",r),...e})}export{n as C,s as T};
