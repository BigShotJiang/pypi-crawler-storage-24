## Typing stubs for docutils

This is a [type stub package](https://typing.python.org/en/latest/tutorials/external_libraries.html)
for the [`docutils`](https://sourceforge.net/p/docutils/code) package. It can be used by type checkers
to check code that uses `docutils`. This version of
`types-docutils` aims to provide accurate annotations for
`docutils==0.22.3`.

This package is part of the [typeshed project](https://github.com/python/typeshed).
All fixes for types and metadata should be contributed there.
See [the README](https://github.com/python/typeshed/blob/main/README.md)
for more details. The source for this package can be found in the
[`stubs/docutils`](https://github.com/python/typeshed/tree/main/stubs/docutils)
directory.

This package was tested with the following type checkers:
* [mypy](https://github.com/python/mypy/) 1.19.1
* [pyright](https://github.com/microsoft/pyright) 1.1.408

It was generated from typeshed commit
[`61524fab4e1804462cc31d2e6b43ff7279188f85`](https://github.com/python/typeshed/commit/61524fab4e1804462cc31d2e6b43ff7279188f85).