from __future__ import annotations

import base64
import json
import re
import threading
import time
from collections import deque
from dataclasses import dataclass
from datetime import datetime, timedelta, timezone
from typing import Any, Callable, Dict, List, Optional, Protocol
from uuid import uuid4


TrackingPayload = Dict[str, Any]


@dataclass(frozen=True)
class FailedResponseReportRow:
    occurred_utc: datetime
    scenario_name: str
    source_endpoint: str
    destination_endpoint: str
    run_mode: str
    status_code: str
    tracking_id: Optional[str] = None
    event_id: Optional[str] = None
    message: Optional[str] = None
    source_timestamp_utc: Optional[datetime] = None
    destination_timestamp_utc: Optional[datetime] = None
    latency_ms: Optional[float] = None


@dataclass(frozen=True)
class CorrelationReportRow:
    occurred_utc: datetime
    scenario_name: str
    source_endpoint: str
    destination_endpoint: str
    run_mode: str
    status_code: str
    tracking_id: Optional[str] = None
    event_id: Optional[str] = None
    gather_by_field: Optional[str] = None
    gather_by_value: Optional[str] = None
    message: Optional[str] = None
    source_timestamp_utc: Optional[datetime] = None
    destination_timestamp_utc: Optional[datetime] = None
    latency_ms: Optional[float] = None
    is_success: bool = False
    is_failure: bool = False


class FailedResponseReportRegistry:
    _max_rows = 50_000
    _rows: List[FailedResponseReportRow] = []
    _lock = threading.Lock()

    @classmethod
    def reset(cls) -> None:
        with cls._lock:
            cls._rows = []

    @classmethod
    def add(cls, row: FailedResponseReportRow) -> None:
        with cls._lock:
            cls._rows.append(row)
            if len(cls._rows) > cls._max_rows:
                del cls._rows[: len(cls._rows) - cls._max_rows]

    @classmethod
    def snapshot(cls) -> List[FailedResponseReportRow]:
        with cls._lock:
            return list(cls._rows)


class CorrelationReportRegistry:
    _max_rows = 50_000
    _rows: List[CorrelationReportRow] = []
    _lock = threading.Lock()

    @classmethod
    def reset(cls) -> None:
        with cls._lock:
            cls._rows = []

    @classmethod
    def add(cls, row: CorrelationReportRow) -> None:
        with cls._lock:
            cls._rows.append(row)
            if len(cls._rows) > cls._max_rows:
                del cls._rows[: len(cls._rows) - cls._max_rows]

    @classmethod
    def snapshot(cls) -> List[CorrelationReportRow]:
        with cls._lock:
            return list(cls._rows)


class TrackingPayloadBuilder:
    def __init__(self) -> None:
        self.headers: Dict[str, str] = {}
        self.content_type: Optional[str] = None
        self.message_payload_type: Optional[str] = None
        self.json_settings: Optional[Dict[str, Any]] = None
        self.json_convert_settings: Optional[Dict[str, Any]] = None
        self._body = b""

    @property
    def body(self) -> bytes:
        return bytes(self._body)

    def set_body(self, body: Any) -> None:
        if body is None:
            self._body = b""
            return
        if isinstance(body, memoryview):
            self._body = body.tobytes()
            return
        if isinstance(body, bytearray):
            self._body = bytes(body)
            return
        if isinstance(body, bytes):
            self._body = bytes(body)
            return
        if isinstance(body, str):
            self._body = body.encode("utf-8")
            return
        self._body = json.dumps(body).encode("utf-8")

    def build(self) -> TrackingPayload:
        body = bytes(self._body)
        return {
            "headers": dict(self.headers),
            "body": body,
            "contentType": self.content_type,
            "messagePayloadType": self.message_payload_type,
            "jsonSettings": _clone_payload_value(self.json_settings),
            "jsonConvertSettings": _clone_payload_value(self.json_convert_settings),
            "getBodyAsUtf8": lambda: body.decode("utf-8", errors="replace"),
        }

    Headers = property(lambda self: self.headers)
    ContentType = property(
        lambda self: self.content_type,
        lambda self, value: setattr(self, "content_type", None if value is None else str(value)),
    )
    MessagePayloadType = property(
        lambda self: self.message_payload_type,
        lambda self, value: setattr(self, "message_payload_type", None if value is None else str(value)),
    )
    JsonSettings = property(
        lambda self: self.json_settings,
        lambda self, value: setattr(self, "json_settings", dict(value) if isinstance(value, dict) else None),
    )
    JsonConvertSettings = property(
        lambda self: self.json_convert_settings,
        lambda self, value: setattr(self, "json_convert_settings", dict(value) if isinstance(value, dict) else None),
    )
    Body = property(lambda self: self.body)
    SetBody = set_body
    Build = build


@dataclass
class RedisCorrelationStoreOptions:
    connection_string: str = ""
    database: int = -1
    key_prefix: str = "loadstrike"
    entry_ttl_seconds: float = 60 * 60

    @property
    def entry_ttl(self) -> float:
        return float(self.entry_ttl_seconds)

    @entry_ttl.setter
    def entry_ttl(self, value: float) -> None:
        self.entry_ttl_seconds = float(value)

    def validate(self) -> None:
        if not str(self.connection_string or "").strip():
            raise ValueError("Redis ConnectionString must be provided.")
        if not str(self.key_prefix or "").strip():
            raise ValueError("Redis KeyPrefix must be provided.")
        if float(self.entry_ttl_seconds) <= 0:
            raise ValueError("Redis EntryTtl must be greater than zero.")

    ConnectionString = property(
        lambda self: self.connection_string,
        lambda self, value: setattr(self, "connection_string", str(value or "")),
    )
    Database = property(
        lambda self: self.database,
        lambda self, value: setattr(self, "database", int(value)),
    )
    KeyPrefix = property(
        lambda self: self.key_prefix,
        lambda self, value: setattr(self, "key_prefix", str(value or "")),
    )
    EntryTtl = property(lambda self: self.entry_ttl, lambda self, value: setattr(self, "entry_ttl", value))
    EntryTtlSeconds = property(
        lambda self: self.entry_ttl_seconds,
        lambda self, value: setattr(self, "entry_ttl_seconds", float(value)),
    )
    Validate = validate


@dataclass
class CorrelationStoreConfiguration:
    kind: str = "InMemory"
    redis: Optional[RedisCorrelationStoreOptions] = None

    @staticmethod
    def in_memory() -> "CorrelationStoreConfiguration":
        return CorrelationStoreConfiguration(kind="InMemory")

    @staticmethod
    def redis_store(options: RedisCorrelationStoreOptions) -> "CorrelationStoreConfiguration":
        if not isinstance(options, RedisCorrelationStoreOptions):
            raise TypeError("Redis correlation store options must be provided.")
        return CorrelationStoreConfiguration(kind="Redis", redis=options)

    def validate(self) -> None:
        if str(self.kind or "").strip().lower() == "redis":
            if not isinstance(self.redis, RedisCorrelationStoreOptions):
                raise ValueError("Redis options must be provided for Redis correlation store.")
            self.redis.validate()

    Kind = property(lambda self: self.kind, lambda self, value: setattr(self, "kind", str(value or "")))
    Redis = property(lambda self: self.redis, lambda self, value: setattr(self, "redis", value))
    InMemory = in_memory
    RedisStore = redis_store
    Validate = validate


@dataclass
class CorrelationEntry:
    tracking_id: str
    produced_utc: int
    payload: TrackingPayload
    event_id: Optional[str] = None
    source_timestamp_utc: Optional[int] = None
    destination_timestamp_utc: Optional[int] = None


class CorrelationStore(Protocol):
    def set(self, entry: CorrelationEntry) -> None:
        ...

    def get(self, tracking_id: str) -> Optional[CorrelationEntry]:
        ...

    def delete(self, tracking_id: str) -> None:
        ...

    def all(self) -> List[CorrelationEntry]:
        ...

    def collect_expired(self, now_ms: int, max_count: Optional[int] = None) -> List[CorrelationEntry]:
        ...

    def increment_source_occurrences(self, tracking_id: str) -> int:
        ...

    def increment_destination_occurrences(self, tracking_id: str) -> int:
        ...

    def register_source(self, tracking_id: str, source_timestamp_utc: int) -> CorrelationEntry:
        ...

    def try_match_destination(self, tracking_id: str, destination_timestamp_utc: int) -> Optional[CorrelationEntry]:
        ...

    def try_expire(self, event_id: str) -> bool:
        ...


class InMemoryCorrelationStore:
    def __init__(self) -> None:
        self._pending_by_tracking_id: Dict[str, deque[CorrelationEntry]] = {}
        self._pending_by_event_id: Dict[str, CorrelationEntry] = {}
        self._source_occurrences: Dict[str, int] = {}
        self._destination_occurrences: Dict[str, int] = {}

    def set(self, entry: CorrelationEntry) -> None:
        normalized = _normalize_correlation_entry(entry)
        if not normalized.tracking_id:
            return
        queue = self._pending_by_tracking_id.setdefault(normalized.tracking_id, deque())
        queue.append(normalized)
        self._pending_by_event_id[normalized.event_id or ""] = normalized

    def get(self, tracking_id: str) -> Optional[CorrelationEntry]:
        queue = self._pending_by_tracking_id.get(str(tracking_id or "").strip())
        if not queue:
            return None
        return _normalize_correlation_entry(queue[0])

    def delete(self, tracking_id: str) -> None:
        queue = self._pending_by_tracking_id.get(str(tracking_id or "").strip())
        if not queue:
            return
        removed = queue.popleft()
        if removed.event_id:
            self._pending_by_event_id.pop(removed.event_id, None)
        if not queue:
            self._pending_by_tracking_id.pop(removed.tracking_id, None)

    def all(self) -> List[CorrelationEntry]:
        rows: List[CorrelationEntry] = []
        for queue in self._pending_by_tracking_id.values():
            rows.extend(_normalize_correlation_entry(entry) for entry in queue)
        return rows

    def collect_expired(self, _now_ms: int, _max_count: Optional[int] = None) -> List[CorrelationEntry]:
        return []

    def increment_source_occurrences(self, tracking_id: str) -> int:
        tracking_key = str(tracking_id or "").strip()
        next_value = self._source_occurrences.get(tracking_key, 0) + 1
        self._source_occurrences[tracking_key] = next_value
        return next_value

    def increment_destination_occurrences(self, tracking_id: str) -> int:
        tracking_key = str(tracking_id or "").strip()
        next_value = self._destination_occurrences.get(tracking_key, 0) + 1
        self._destination_occurrences[tracking_key] = next_value
        return next_value

    def register_source(self, tracking_id: str, source_timestamp_utc: int) -> CorrelationEntry:
        entry = _normalize_correlation_entry(
            CorrelationEntry(
                tracking_id=str(tracking_id or "").strip(),
                event_id=_generate_correlation_event_id(str(tracking_id or "").strip(), int(source_timestamp_utc)),
                source_timestamp_utc=int(source_timestamp_utc),
                destination_timestamp_utc=None,
                produced_utc=int(source_timestamp_utc),
                payload={},
            )
        )
        self.set(entry)
        return entry

    def try_match_destination(self, tracking_id: str, destination_timestamp_utc: int) -> Optional[CorrelationEntry]:
        source = self.get(tracking_id)
        if source is None:
            return None
        self.delete(tracking_id)
        return _normalize_correlation_entry(
            CorrelationEntry(
                tracking_id=source.tracking_id,
                event_id=source.event_id,
                source_timestamp_utc=source.source_timestamp_utc,
                destination_timestamp_utc=int(destination_timestamp_utc),
                produced_utc=source.produced_utc,
                payload=source.payload,
            )
        )

    def try_expire(self, event_id: str) -> bool:
        target = str(event_id or "").strip()
        if not target:
            return False
        entry = self._pending_by_event_id.pop(target, None)
        if entry is None:
            return False
        queue = self._pending_by_tracking_id.get(entry.tracking_id)
        if queue is not None:
            remaining = deque(row for row in queue if (row.event_id or "") != target)
            if remaining:
                self._pending_by_tracking_id[entry.tracking_id] = remaining
            else:
                self._pending_by_tracking_id.pop(entry.tracking_id, None)
        return True


class RedisCorrelationStore:
    def __init__(
        self,
        client: Optional[Any] = None,
        prefix: str = "loadstrike",
        *,
        entry_ttl_ms: int = 3_600_000,
        now: Optional[Callable[[], int]] = None,
    ) -> None:
        self._client = client
        self._prefix = str(prefix or "loadstrike").strip() or "loadstrike"
        self._pending_index_key = f"{self._prefix}:pending:index"
        self._entry_ttl_ms = max(int(entry_ttl_ms), 0)
        self._now = now or (lambda: int(time.time() * 1000))
        self._fallback = InMemoryCorrelationStore()
        self._fallback_expiry: Dict[str, int] = {}
        self._source_occurrences: Dict[str, int] = {}
        self._destination_occurrences: Dict[str, int] = {}

    @staticmethod
    def from_options(options: RedisCorrelationStoreOptions, run_namespace: str) -> "RedisCorrelationStore":
        if not isinstance(options, RedisCorrelationStoreOptions):
            raise TypeError("Redis correlation store options must be provided.")
        options.validate()
        prefix = f"{options.key_prefix}:{str(run_namespace or '').strip() or 'default'}"
        client = _create_redis_store_client(options.connection_string, options.database)
        return RedisCorrelationStore(
            client=client,
            prefix=prefix,
            entry_ttl_ms=max(int(float(options.entry_ttl_seconds) * 1000), 1),
        )

    FromOptions = from_options

    def set(self, entry: CorrelationEntry) -> None:
        normalized = _normalize_correlation_entry(entry)
        if not self._supports_client_storage():
            self._fallback.set(normalized)
            if normalized.event_id:
                if self._entry_ttl_ms > 0:
                    self._fallback_expiry[normalized.event_id] = self._now() + self._entry_ttl_ms
                else:
                    self._fallback_expiry.pop(normalized.event_id, None)
            return
        expires_utc = self._now() + self._entry_ttl_ms if self._entry_ttl_ms > 0 else None
        self._client_set(
            self._event_key(normalized.event_id or ""),
            json.dumps(
                {
                    "tracking_id": normalized.tracking_id,
                    "event_id": normalized.event_id,
                    "source_timestamp_utc": normalized.source_timestamp_utc,
                    "destination_timestamp_utc": normalized.destination_timestamp_utc,
                    "produced_utc": normalized.produced_utc,
                    "expires_utc": expires_utc,
                    "payload": _serialize_tracking_payload(normalized.payload),
                }
            ),
        )
        queue = self._read_queue(normalized.tracking_id)
        queue.append(normalized.event_id or "")
        self._write_queue(normalized.tracking_id, queue)
        pending = self._read_pending_index_ids()
        pending.append(normalized.event_id or "")
        self._write_pending_index_ids(pending)

    def get(self, tracking_id: str) -> Optional[CorrelationEntry]:
        tracking_key = str(tracking_id or "").strip()
        if not self._supports_client_storage():
            while True:
                entry = self._fallback.get(tracking_key)
                if entry is None:
                    return None
                event_id = entry.event_id or ""
                if not _is_entry_expired(entry, self._fallback_expiry.get(event_id), self._now()):
                    return entry
                if event_id and self._fallback.try_expire(event_id):
                    self._fallback_expiry.pop(event_id, None)
                    continue
                self._fallback.delete(tracking_key)
                return None

        queue = self._read_queue(tracking_key)
        while queue:
            event_id = queue[0]
            entry, expires_utc = self._read_event_entry(event_id)
            if entry is None:
                queue.pop(0)
                self._write_queue(tracking_key, queue)
                self._remove_pending_index_id(event_id)
                continue
            if _is_entry_expired(entry, expires_utc, self._now()):
                self.try_expire(event_id)
                queue = self._read_queue(tracking_key)
                continue
            return entry
        return None

    def delete(self, tracking_id: str) -> None:
        tracking_key = str(tracking_id or "").strip()
        if not self._supports_client_storage():
            existing = self._fallback.get(tracking_key)
            self._fallback.delete(tracking_key)
            if existing is not None and existing.event_id:
                self._fallback_expiry.pop(existing.event_id, None)
            return
        queue = self._read_queue(tracking_key)
        event_id = queue.pop(0) if queue else ""
        if not event_id:
            return
        self._write_queue(tracking_key, queue)
        self._client_delete(self._event_key(event_id))
        self._remove_pending_index_id(event_id)

    def all(self) -> List[CorrelationEntry]:
        if not self._supports_client_storage():
            self.collect_expired(self._now())
            return self._fallback.all()

        pending_ids = self._read_pending_index_ids()
        rows: List[CorrelationEntry] = []
        active_ids: List[str] = []
        for event_id in pending_ids:
            entry, expires_utc = self._read_event_entry(event_id)
            if entry is None:
                continue
            if _is_entry_expired(entry, expires_utc, self._now()):
                self.try_expire(event_id)
                continue
            rows.append(entry)
            active_ids.append(event_id)

        if active_ids != pending_ids:
            self._write_pending_index_ids(active_ids)
        return rows

    def collect_expired(self, now_ms: int, max_count: Optional[int] = None) -> List[CorrelationEntry]:
        expired: List[CorrelationEntry] = []
        limit = int(max_count) if isinstance(max_count, int) and max_count > 0 else 0
        if not self._supports_client_storage():
            for entry in self._fallback.all():
                if limit > 0 and len(expired) >= limit:
                    break
                event_id = entry.event_id or ""
                if not _is_entry_expired(entry, self._fallback_expiry.get(event_id), now_ms):
                    continue
                if event_id and self._fallback.try_expire(event_id):
                    self._fallback_expiry.pop(event_id, None)
                    expired.append(entry)
            return expired

        pending_ids = self._read_pending_index_ids()
        active_ids: List[str] = []
        for event_id in pending_ids:
            if limit > 0 and len(expired) >= limit:
                active_ids.append(event_id)
                continue
            entry, expires_utc = self._read_event_entry(event_id)
            if entry is None:
                continue
            if not _is_entry_expired(entry, expires_utc, now_ms):
                active_ids.append(event_id)
                continue
            self.try_expire(event_id)
            expired.append(entry)
        if active_ids != pending_ids:
            self._write_pending_index_ids(active_ids)
        return expired

    def increment_source_occurrences(self, tracking_id: str) -> int:
        tracking_key = str(tracking_id or "").strip()
        if not self._supports_client_storage():
            return self._fallback.increment_source_occurrences(tracking_key)
        return self._increment_counter(self._source_occurrence_key(tracking_key), self._source_occurrences)

    def increment_destination_occurrences(self, tracking_id: str) -> int:
        tracking_key = str(tracking_id or "").strip()
        if not self._supports_client_storage():
            return self._fallback.increment_destination_occurrences(tracking_key)
        return self._increment_counter(self._destination_occurrence_key(tracking_key), self._destination_occurrences)

    def register_source(self, tracking_id: str, source_timestamp_utc: int) -> CorrelationEntry:
        entry = _normalize_correlation_entry(
            CorrelationEntry(
                tracking_id=str(tracking_id or "").strip(),
                event_id=_generate_correlation_event_id(str(tracking_id or "").strip(), int(source_timestamp_utc)),
                source_timestamp_utc=int(source_timestamp_utc),
                destination_timestamp_utc=None,
                produced_utc=int(source_timestamp_utc),
                payload={},
            )
        )
        self.set(entry)
        return entry

    def try_match_destination(self, tracking_id: str, destination_timestamp_utc: int) -> Optional[CorrelationEntry]:
        if not self._supports_client_storage():
            source = self._fallback.try_match_destination(tracking_id, int(destination_timestamp_utc))
            if source is not None and source.event_id:
                self._fallback_expiry.pop(source.event_id, None)
            return source
        source = self.get(tracking_id)
        if source is None:
            return None
        self.delete(tracking_id)
        return _normalize_correlation_entry(
            CorrelationEntry(
                tracking_id=source.tracking_id,
                event_id=source.event_id,
                source_timestamp_utc=source.source_timestamp_utc,
                destination_timestamp_utc=int(destination_timestamp_utc),
                produced_utc=source.produced_utc,
                payload=source.payload,
            )
        )

    def try_expire(self, event_id: str) -> bool:
        target = str(event_id or "").strip()
        if not target:
            return False
        if not self._supports_client_storage():
            expired = self._fallback.try_expire(target)
            if expired:
                self._fallback_expiry.pop(target, None)
            return expired

        entry, _expires_utc = self._read_event_entry(target)
        if entry is None:
            return False
        self._client_delete(self._event_key(target))
        self._remove_pending_index_id(target)
        self._remove_queue_id(entry.tracking_id, target)
        return True

    def _supports_client_storage(self) -> bool:
        return callable(getattr(self._client, "set", None)) and callable(getattr(self._client, "get", None)) and callable(self._resolve_client_delete())

    def _resolve_client_delete(self) -> Optional[Callable[..., Any]]:
        delete_fn = getattr(self._client, "del", None)
        if callable(delete_fn):
            return delete_fn
        delete_fn = getattr(self._client, "delete", None)
        if callable(delete_fn):
            return delete_fn
        return None

    def _client_set(self, key: str, value: str) -> None:
        set_fn = getattr(self._client, "set", None)
        if callable(set_fn):
            set_fn(key, value)

    def _client_get(self, key: str) -> Optional[str]:
        get_fn = getattr(self._client, "get", None)
        if not callable(get_fn):
            return None
        raw = get_fn(key)
        if isinstance(raw, bytes):
            return raw.decode("utf-8", errors="replace")
        return raw if isinstance(raw, str) else None

    def _client_delete(self, key: str) -> None:
        delete_fn = self._resolve_client_delete()
        if callable(delete_fn):
            delete_fn(key)

    def _increment_counter(self, key: str, cache: Dict[str, int]) -> int:
        raw = self._client_get(key)
        if raw is None:
            next_value = cache.get(key, 0) + 1
        else:
            try:
                next_value = int(raw) + 1
            except ValueError:
                next_value = 1
        cache[key] = next_value
        self._client_set(key, str(next_value))
        return next_value

    def _read_pending_index_ids(self) -> List[str]:
        raw = self._client_get(self._pending_index_key)
        if not raw:
            return []
        try:
            parsed = json.loads(raw)
        except json.JSONDecodeError:
            return []
        if not isinstance(parsed, list):
            return []
        return [str(value).strip() for value in parsed if str(value).strip()]

    def _write_pending_index_ids(self, values: List[str]) -> None:
        deduped = []
        seen = set()
        for value in values:
            text = str(value or "").strip()
            if text and text not in seen:
                seen.add(text)
                deduped.append(text)
        self._client_set(self._pending_index_key, json.dumps(deduped))

    def _remove_pending_index_id(self, event_id: str) -> None:
        pending = self._read_pending_index_ids()
        self._write_pending_index_ids([value for value in pending if value != event_id])

    def _read_queue(self, tracking_id: str) -> List[str]:
        raw = self._client_get(self._queue_key(tracking_id))
        if not raw:
            return []
        try:
            parsed = json.loads(raw)
        except json.JSONDecodeError:
            return []
        if not isinstance(parsed, list):
            return []
        return [str(value).strip() for value in parsed if str(value).strip()]

    def _write_queue(self, tracking_id: str, values: List[str]) -> None:
        queue_key = self._queue_key(tracking_id)
        filtered = [str(value).strip() for value in values if str(value).strip()]
        if not filtered:
            self._client_delete(queue_key)
            return
        self._client_set(queue_key, json.dumps(filtered))

    def _remove_queue_id(self, tracking_id: str, event_id: str) -> None:
        queue = self._read_queue(tracking_id)
        self._write_queue(tracking_id, [value for value in queue if value != event_id])

    def _read_event_entry(self, event_id: str) -> tuple[Optional[CorrelationEntry], Optional[int]]:
        raw = self._client_get(self._event_key(event_id))
        if not raw:
            return None, None
        try:
            parsed = json.loads(raw)
        except json.JSONDecodeError:
            return None, None
        if not isinstance(parsed, dict):
            return None, None
        payload = _deserialize_tracking_payload(parsed.get("payload"))
        entry = _normalize_correlation_entry(
            CorrelationEntry(
                tracking_id=str(parsed.get("tracking_id", "")),
                event_id=str(parsed.get("event_id", "") or event_id),
                source_timestamp_utc=_read_optional_int(parsed.get("source_timestamp_utc")),
                destination_timestamp_utc=_read_optional_int(parsed.get("destination_timestamp_utc")),
                produced_utc=int(parsed.get("produced_utc", 0) or 0),
                payload=payload,
            )
        )
        return entry, _read_optional_int(parsed.get("expires_utc"))

    def _queue_key(self, tracking_id: str) -> str:
        return f"{self._prefix}:pending:queue:{tracking_id}"

    def _event_key(self, event_id: str) -> str:
        return f"{self._prefix}:pending:event:{event_id}"

    def _source_occurrence_key(self, tracking_id: str) -> str:
        return f"{self._prefix}:occ:src:{tracking_id}"

    def _destination_occurrence_key(self, tracking_id: str) -> str:
        return f"{self._prefix}:occ:dst:{tracking_id}"


class TrackingFieldSelector:
    def __init__(self, location: str, path: str) -> None:
        normalized_location = str(location or "").strip().lower()
        if normalized_location not in {"header", "json"}:
            raise ValueError("Tracking field location must be Header or Json.")
        self.kind = normalized_location
        self.path = str(path or "")

    @staticmethod
    def parse(value: Any) -> "TrackingFieldSelector":
        if isinstance(value, TrackingFieldSelector):
            return TrackingFieldSelector(value.kind, value.path)
        normalized = str(value or "").strip()
        parts = normalized.split(":")
        kind = parts[0].strip().lower() if parts else ""
        path = ":".join(parts[1:]).strip() if len(parts) > 1 else ""
        if kind not in {"header", "json"} or not path:
            raise ValueError(
                "Tracking field expression is invalid. Use `header:<name>` or `json:$.<path>`."
            )
        return TrackingFieldSelector(kind, path)

    @staticmethod
    def try_parse(value: Any) -> tuple[bool, Optional["TrackingFieldSelector"]]:
        try:
            return True, TrackingFieldSelector.parse(value)
        except ValueError:
            return False, None

    @property
    def location(self) -> str:
        return "Header" if self.kind == "header" else "Json"

    @property
    def Location(self) -> str:  # noqa: N802
        return self.location

    @property
    def Path(self) -> str:  # noqa: N802
        return self.path

    def extract(self, payload: TrackingPayload) -> Optional[str]:
        if self.kind == "header":
            headers = payload.get("headers", {})
            if not isinstance(headers, dict):
                return None
            expected = self.path.lower()
            for key, value in headers.items():
                if str(key).lower() == expected:
                    parsed = str(value).strip()
                    if parsed:
                        return parsed
            return None

        body = _normalize_json_body(payload.get("body"))
        if not isinstance(body, dict):
            return None

        json_path = self.path[2:] if self.path.startswith("$.") else self.path
        current: Any = body
        for segment in [x for x in json_path.split(".") if x]:
            current = _read_path_segment(current, segment)
            if current is _MISSING:
                return None

        if current is None:
            return None
        return str(current)

    def __str__(self) -> str:
        return f"{self.kind}:{self.path}"

    Parse = parse
    TryParse = try_parse
    ToString = __str__


class CorrelationRuntimePlugin(Protocol):
    def on_produced(self, tracking_id: str, payload: TrackingPayload) -> None:
        ...

    def on_matched(
        self,
        tracking_id: str,
        source_payload: TrackingPayload,
        destination_payload: TrackingPayload,
        latency_ms: int,
    ) -> None:
        ...

    def on_timeout(self, tracking_id: str, source_payload: TrackingPayload) -> None:
        ...


class CrossPlatformTrackingRuntime:
    def __init__(
        self,
        *,
        source_tracking_field: str,
        destination_tracking_field: Optional[str] = None,
        destination_gather_by_field: Optional[str] = None,
        correlation_timeout_ms: int = 30_000,
        timeout_counts_as_failure: bool = True,
        store: Optional[CorrelationStore] = None,
        plugins: Optional[List[CorrelationRuntimePlugin]] = None,
    ) -> None:
        self._source_selector = TrackingFieldSelector.parse(source_tracking_field)
        self._destination_selector = TrackingFieldSelector.parse(destination_tracking_field or source_tracking_field)
        self._gather_selector = (
            TrackingFieldSelector.parse(destination_gather_by_field)
            if destination_gather_by_field
            else None
        )
        self._timeout_ms = max(int(correlation_timeout_ms), 1)
        self._timeout_counts_as_failure = timeout_counts_as_failure
        self._store = store or InMemoryCorrelationStore()
        self._plugins = list(plugins or [])

        self._produced_count = 0
        self._consumed_count = 0
        self._matched_count = 0
        self._timeout_count = 0
        self._duplicate_source_count = 0
        self._duplicate_destination_count = 0
        self._total_latency_ms = 0
        self._gathered: Dict[str, Dict[str, int]] = {}

    def on_source_produced(self, payload: TrackingPayload, now_ms: int) -> Optional[str]:
        self._produced_count += 1
        tracking_id = self._source_selector.extract(payload)
        if not tracking_id:
            return None

        increment_source = getattr(self._store, "increment_source_occurrences", None)
        source_occurrences = int(increment_source(tracking_id)) if callable(increment_source) else 1
        if source_occurrences > 1:
            self._duplicate_source_count += 1

        self._store.set(
            CorrelationEntry(
                tracking_id=tracking_id,
                event_id=_generate_correlation_event_id(tracking_id, int(now_ms)),
                source_timestamp_utc=int(now_ms),
                destination_timestamp_utc=None,
                produced_utc=int(now_ms),
                payload=payload,
            )
        )
        for plugin in self._plugins:
            callback = getattr(plugin, "on_produced", None)
            if callable(callback):
                callback(tracking_id, payload)
        return tracking_id

    def on_destination_consumed(self, payload: TrackingPayload, now_ms: int) -> bool:
        self._consumed_count += 1
        tracking_id = self._destination_selector.extract(payload)
        if not tracking_id:
            return False

        increment_destination = getattr(self._store, "increment_destination_occurrences", None)
        destination_occurrences = int(increment_destination(tracking_id)) if callable(increment_destination) else 1
        if destination_occurrences > 1:
            self._duplicate_destination_count += 1

        try_match_destination = getattr(self._store, "try_match_destination", None)
        if callable(try_match_destination):
            source_entry = try_match_destination(tracking_id, int(now_ms))
        else:
            source_entry = self._store.get(tracking_id)
            if source_entry is not None:
                self._store.delete(tracking_id)
        if source_entry is None:
            return False

        self._matched_count += 1
        latency_ms = max(now_ms - source_entry.produced_utc, 0)
        self._total_latency_ms += latency_ms

        gather_key = self._resolve_gather_key(payload)
        row = self._gathered.setdefault(gather_key, {"total": 0, "matched": 0, "timedOut": 0})
        row["total"] += 1
        row["matched"] += 1

        for plugin in self._plugins:
            callback = getattr(plugin, "on_matched", None)
            if callable(callback):
                callback(tracking_id, source_entry.payload, payload, latency_ms)
        return True

    def sweep_timeouts(self, now_ms: int, batch_size: Optional[int] = None) -> int:
        expired_entries: List[CorrelationEntry] = []
        limit = int(batch_size) if isinstance(batch_size, int) and batch_size > 0 else None
        collect_expired = getattr(self._store, "collect_expired", None)
        if callable(collect_expired):
            try:
                rows = collect_expired(now_ms, limit)
            except TypeError:
                rows = collect_expired(now_ms)
            if isinstance(rows, list):
                expired_entries.extend(rows)

        seen: set[str] = set()
        for entry in expired_entries:
            dedupe_key = _correlation_entry_dedupe_key(entry)
            if dedupe_key:
                seen.add(dedupe_key)
        for entry in self._store.all():
            if limit is not None and len(expired_entries) >= limit:
                break
            if now_ms - entry.produced_utc < self._timeout_ms:
                continue

            try_expire = getattr(self._store, "try_expire", None)
            if callable(try_expire) and entry.event_id:
                if not try_expire(entry.event_id):
                    self._store.delete(entry.tracking_id)
            else:
                self._store.delete(entry.tracking_id)

            dedupe_key = _correlation_entry_dedupe_key(entry)
            if dedupe_key not in seen:
                expired_entries.append(entry)
                if dedupe_key:
                    seen.add(dedupe_key)

        for entry in expired_entries:
            self._timeout_count += 1
            gather_key = self._resolve_gather_key(entry.payload)
            row = self._gathered.setdefault(gather_key, {"total": 0, "matched": 0, "timedOut": 0})
            row["total"] += 1
            row["timedOut"] += 1

            for plugin in self._plugins:
                callback = getattr(plugin, "on_timeout", None)
                if callable(callback):
                    callback(entry.tracking_id, entry.payload)
        return len(expired_entries)

    def get_stats(self) -> Dict[str, Any]:
        inflight_count = len(self._store.all())
        average_latency_ms = (
            self._total_latency_ms / self._matched_count
            if self._matched_count > 0
            else 0
        )
        gathered = {
            key: {"total": value["total"], "matched": value["matched"], "timedOut": value["timedOut"]}
            for key, value in self._gathered.items()
        }
        return {
            "producedCount": self._produced_count,
            "consumedCount": self._consumed_count,
            "matchedCount": self._matched_count,
            "timeoutCount": self._timeout_count,
            "duplicateSourceCount": self._duplicate_source_count,
            "duplicateDestinationCount": self._duplicate_destination_count,
            "inflightCount": inflight_count,
            "averageLatencyMs": average_latency_ms,
            "gathered": gathered,
        }

    def is_timeout_counted_as_failure(self) -> bool:
        return self._timeout_counts_as_failure

    def _resolve_gather_key(self, payload: TrackingPayload) -> str:
        if self._gather_selector is None:
            return "__ungrouped__"
        return self._gather_selector.extract(payload) or "__unknown__"


_MISSING = object()


def _generate_correlation_event_id(tracking_id: str, source_timestamp_utc: int) -> str:
    return f"{tracking_id}:{int(source_timestamp_utc)}:{uuid4()}"


def _correlation_entry_dedupe_key(entry: CorrelationEntry) -> str:
    if str(entry.event_id or "").strip():
        return str(entry.event_id).strip()
    return f"{entry.tracking_id}:{entry.source_timestamp_utc or entry.produced_utc}"


def _is_entry_expired(
    entry: CorrelationEntry,
    expires_utc: Optional[int],
    now_ms: int,
) -> bool:
    del entry
    return isinstance(expires_utc, int) and now_ms >= expires_utc


def _normalize_correlation_entry(entry: CorrelationEntry) -> CorrelationEntry:
    tracking_id = str(entry.tracking_id or "").strip()
    produced_utc = int(entry.produced_utc or entry.source_timestamp_utc or 0)
    source_timestamp_utc = int(entry.source_timestamp_utc if entry.source_timestamp_utc is not None else produced_utc)
    destination_timestamp_utc = (
        None
        if entry.destination_timestamp_utc is None
        else int(entry.destination_timestamp_utc)
    )
    event_id = str(entry.event_id or "").strip() or _generate_correlation_event_id(tracking_id, source_timestamp_utc)
    return CorrelationEntry(
        tracking_id=tracking_id,
        event_id=event_id,
        source_timestamp_utc=source_timestamp_utc,
        destination_timestamp_utc=destination_timestamp_utc,
        produced_utc=produced_utc,
        payload=_clone_tracking_payload(entry.payload),
    )


def _read_optional_int(value: Any) -> Optional[int]:
    if value is None:
        return None
    try:
        return int(value)
    except (TypeError, ValueError):
        return None


def _clone_payload_value(value: Any) -> Any:
    if isinstance(value, dict):
        return {str(key): _clone_payload_value(item) for key, item in value.items()}
    if isinstance(value, list):
        return [_clone_payload_value(item) for item in value]
    if isinstance(value, tuple):
        return [_clone_payload_value(item) for item in value]
    if isinstance(value, memoryview):
        return value.tobytes()
    if isinstance(value, bytearray):
        return bytes(value)
    if isinstance(value, bytes):
        return bytes(value)
    return value


def _clone_tracking_payload(payload: Any) -> TrackingPayload:
    if not isinstance(payload, dict):
        return {"headers": {}, "body": _clone_payload_value(payload)}
    cloned = {
        "headers": {
            str(key): str(value or "")
            for key, value in dict(payload.get("headers") or {}).items()
        },
        "body": _clone_payload_value(payload.get("body")),
        "producedUtc": payload.get("producedUtc"),
        "contentType": payload.get("contentType") or payload.get("ContentType"),
    }
    for key in ("messagePayloadType", "jsonSettings", "jsonConvertSettings", "getBodyAsUtf8"):
        if key in payload:
            cloned[key] = payload.get(key)
    return cloned


def _serialize_tracking_payload(payload: Any) -> Dict[str, Any]:
    normalized = _clone_tracking_payload(payload)
    serialized: Dict[str, Any] = {
        "headers": dict(normalized.get("headers") or {}),
        "producedUtc": normalized.get("producedUtc"),
        "contentType": normalized.get("contentType"),
        "messagePayloadType": normalized.get("messagePayloadType"),
        "jsonSettings": _clone_payload_value(normalized.get("jsonSettings")),
        "jsonConvertSettings": _clone_payload_value(normalized.get("jsonConvertSettings")),
    }
    body = normalized.get("body")
    if isinstance(body, memoryview):
        body = body.tobytes()
    if isinstance(body, bytearray):
        body = bytes(body)
    if isinstance(body, bytes):
        serialized["bodyBase64"] = base64.b64encode(body).decode("ascii")
    else:
        serialized["body"] = _clone_payload_value(body)
    return serialized


def _deserialize_tracking_payload(value: Any) -> TrackingPayload:
    if not isinstance(value, dict):
        return {"headers": {}, "body": None}
    body = value.get("body")
    body_base64 = value.get("bodyBase64")
    if isinstance(body_base64, str) and body_base64:
        try:
            body = base64.b64decode(body_base64)
        except (ValueError, TypeError):
            body = b""
    payload = {
        "headers": {
            str(key): str(item or "")
            for key, item in dict(value.get("headers") or {}).items()
        },
        "body": _clone_payload_value(body),
        "producedUtc": value.get("producedUtc"),
        "contentType": value.get("contentType"),
        "messagePayloadType": value.get("messagePayloadType"),
        "jsonSettings": _clone_payload_value(value.get("jsonSettings")),
        "jsonConvertSettings": _clone_payload_value(value.get("jsonConvertSettings")),
    }
    if isinstance(payload["body"], (bytes, bytearray)):
        payload["getBodyAsUtf8"] = lambda: bytes(payload["body"]).decode("utf-8", errors="replace")
    return payload


def _create_redis_store_client(connection_string: str, database: int) -> Any:
    try:
        import redis  # type: ignore
    except ImportError as error:  # pragma: no cover - exercised only with redis installed
        raise RuntimeError("Redis correlation store requires redis.Redis.") from error

    factory = getattr(getattr(redis, "Redis", None), "from_url", None)
    if not callable(factory):  # pragma: no cover - defensive fallback for incompatible redis clients
        raise RuntimeError("Redis correlation store requires redis.Redis.from_url.")

    client = factory(
        connection_string,
        db=database if int(database) >= 0 else None,
        decode_responses=True,
    )

    class _RedisStoreClient:
        def set(self, key: str, value: str) -> None:
            client.set(key, value)

        def get(self, key: str) -> Optional[str]:
            return client.get(key)

        def delete(self, key: str) -> None:
            client.delete(key)

        def keys(self, pattern: str) -> List[str]:
            return [str(value) for value in client.keys(pattern)]

    return _RedisStoreClient()


def _normalize_json_body(body: Any) -> Optional[Dict[str, Any]]:
    if isinstance(body, dict):
        return body
    if isinstance(body, memoryview):
        body = body.tobytes()
    if isinstance(body, bytearray):
        body = bytes(body)
    if isinstance(body, bytes):
        body = body.decode("utf-8", errors="replace")
    if not isinstance(body, str) or not body.strip():
        return None

    direct = _try_parse_json_object(body)
    if direct is not None:
        return direct
    relaxed = re.sub(r",\s*([}\]])", r"\1", body.strip())
    relaxed = re.sub(r"'([^']*)'", lambda match: '"' + match.group(1).replace('"', '\\"') + '"', relaxed)
    return _try_parse_json_object(relaxed)


def _try_parse_json_object(value: str) -> Optional[Dict[str, Any]]:
    try:
        parsed = json.loads(value)
    except json.JSONDecodeError:
        return None
    return parsed if isinstance(parsed, dict) else None


def _read_path_segment(current: Any, segment: str) -> Any:
    token = segment.strip()
    indexed = re.match(r"^([^\[\]]+)\[(\d+)\]$", token)
    if indexed:
        field = indexed.group(1)
        index = int(indexed.group(2))
        if not isinstance(current, dict):
            return _MISSING
        row = _get_case_insensitive_dict_value(current, field)
        if not isinstance(row, list) or index < 0 or index >= len(row):
            return _MISSING
        return row[index]

    if isinstance(current, list):
        if token.isdigit():
            index = int(token)
            if 0 <= index < len(current):
                return current[index]
        return _MISSING

    if isinstance(current, dict):
        return _get_case_insensitive_dict_value(current, token)
    return _MISSING


def _get_case_insensitive_dict_value(values: Dict[str, Any], key: str) -> Any:
    if key in values:
        return values[key]
    expected = str(key or "").lower()
    for candidate, value in values.items():
        if str(candidate).lower() == expected:
            return value
    return _MISSING
