from __future__ import annotations

import asyncio
import base64
import csv
import inspect
import json
import math
import os
import random
import re
import threading
import time
from collections import deque
from collections.abc import Iterator, MutableMapping
from concurrent.futures import ThreadPoolExecutor
from dataclasses import dataclass, field
from datetime import datetime, timedelta, timezone
from enum import Enum
from pathlib import Path
from queue import Empty as QueueEmpty, Queue
from threading import Event
from typing import Any, Callable, Dict, List, Optional, Protocol, Union

from .cluster import DistributedClusterAgent, DistributedClusterCoordinator, plan_agent_scenario_assignments
from .client import LoadStrikeLocalClient
from .correlation import (
    CorrelationReportRegistry,
    CorrelationReportRow,
    CrossPlatformTrackingRuntime,
    FailedResponseReportRegistry,
    FailedResponseReportRow,
)
from .transports import EndpointAdapterFactory, _normalize_tracking_payload, _validate_endpoint_definition

_RESPONSE_ARGUMENT_UNSET = object()


class _LoadStrikeStringEnum(str, Enum):
    def __str__(self) -> str:
        return str(self.value)


class LoadStrikeNodeType(_LoadStrikeStringEnum):
    SingleNode = "SingleNode"
    Coordinator = "Coordinator"
    Agent = "Agent"


class LoadStrikeScenarioOperation(_LoadStrikeStringEnum):
    Init = "Init"
    Clean = "Clean"
    WarmUp = "WarmUp"
    Bombing = "Bombing"


class LoadStrikeOperationType(_LoadStrikeStringEnum):
    None_ = "None"
    Init = "Init"
    WarmUp = "WarmUp"
    Bombing = "Bombing"
    Stop = "Stop"
    Complete = "Complete"
    Error = "Error"


class LoadStrikeReportFormat(_LoadStrikeStringEnum):
    Txt = "Txt"
    Html = "Html"
    Csv = "Csv"
    Md = "Md"


class LoadStrikeLogLevel(_LoadStrikeStringEnum):
    Verbose = "Verbose"
    Debug = "Debug"
    Information = "Information"
    Warning = "Warning"
    Error = "Error"
    Fatal = "Fatal"


def _string_value(value: Any) -> str:
    if isinstance(value, Enum):
        return str(value.value)
    return str(value)


def _normalize_report_formats_value(value: Any) -> List[str]:
    canonical_formats = {
        "txt": "txt",
        "html": "html",
        "csv": "csv",
        "md": "md",
        "markdown": "md",
    }

    if isinstance(value, (list, tuple, set)):
        raw_values = list(value)
    else:
        raw_values = [value]

    if not raw_values:
        raise ValueError("At least one report format should be provided.")

    normalized: List[str] = []
    for item in raw_values:
        if item is None:
            raise ValueError("Report format collection cannot contain null or whitespace values.")
        text = _string_value(item).strip()
        if not text:
            raise ValueError("Report format collection cannot contain null or whitespace values.")
        normalized.append(canonical_formats.get(text.lower(), text))
    return normalized


def _reject_disable_license_enforcement_option(value: Any, source: str) -> None:
    if not isinstance(value, dict):
        return

    for key in value.keys():
        normalized = re.sub(r"[^a-z0-9]", "", str(key or "").lower())
        if normalized == "disablelicenseenforcement":
            raise ValueError(
                f"{source} cannot include disable license enforcement options."
            )


def _require_string_or_enum_value(value: Any, message: str) -> str:
    if value is None:
        raise ValueError(message)
    return _require_non_empty(_string_value(value), message)


def _enum_or_string(enum_type: type[_LoadStrikeStringEnum], value: Any) -> Union[_LoadStrikeStringEnum, str]:
    raw = _string_value(value).strip()
    if not raw:
        return ""
    lowered = raw.lower()
    if enum_type is LoadStrikeNodeType:
        if lowered in {"single", "singlenode", "0"}:
            return LoadStrikeNodeType.SingleNode
        if lowered in {"coordinator", "1"}:
            return LoadStrikeNodeType.Coordinator
        if lowered in {"agent", "2"}:
            return LoadStrikeNodeType.Agent
    for member in enum_type:
        if member.name.lower() == lowered or str(member).lower() == lowered:
            return member
    return raw


def _canonical_node_type_name(value: Any) -> str:
    resolved = _enum_or_string(LoadStrikeNodeType, value or LoadStrikeNodeType.SingleNode)
    return str(resolved or LoadStrikeNodeType.SingleNode)


def _canonical_minimum_log_level_name(value: Any) -> str:
    resolved = _parse_cli_log_level(_string_value(value))
    if resolved:
        return resolved
    enum_value = _enum_or_string(LoadStrikeLogLevel, value or LoadStrikeLogLevel.Information)
    return str(enum_value or LoadStrikeLogLevel.Information)


@dataclass(frozen=True)
class LoadStrikeStepReply:
    is_success: bool
    status_code: str = "200"
    message: str = ""
    size_bytes: int = 0
    custom_latency_ms: Optional[float] = None
    payload: Any = None

    @property
    def is_error(self) -> bool:
        return not self.is_success

    def as_reply(self) -> "LoadStrikeReply":
        return LoadStrikeReply(
            is_success=self.is_success,
            status_code=self.status_code,
            message=self.message,
            size_bytes=self.size_bytes,
            custom_latency_ms=self.custom_latency_ms,
            payload=self.payload,
        )

    def __getitem__(self, key: str) -> Any:
        if key == "reply":
            return self
        if key == "as_reply":
            return self.as_reply
        raise KeyError(key)

    IsError = property(lambda self: self.is_error)
    StatusCode = property(lambda self: self.status_code)
    Message = property(lambda self: self.message)
    SizeBytes = property(lambda self: self.size_bytes)
    CustomLatencyMs = property(lambda self: 0.0 if self.custom_latency_ms is None else float(self.custom_latency_ms))
    Payload = property(lambda self: self.payload)
    AsReply = as_reply


LoadStrikeReply = LoadStrikeStepReply


class LoadStrikeInvalidOperationError(RuntimeError):
    pass


def _clone_nested(value: Any) -> Any:
    if isinstance(value, _LoadStrikeMappingView):
        return value.to_dict()
    if isinstance(value, list):
        return [_clone_nested(item) for item in value]
    if isinstance(value, dict):
        return {str(key): _clone_nested(item) for key, item in value.items()}
    return value


def _mapping_aliases(key: str) -> List[str]:
    if not key:
        return []

    aliases: List[str] = [key]
    if key == "os":
        aliases.append("OS")
    elif key == "OS":
        aliases.append("os")

    if key[0].islower():
        aliases.append(key[0].upper() + key[1:])
    elif key[0].isupper():
        aliases.append(key[0].lower() + key[1:])

    seen: set[str] = set()
    ordered: List[str] = []
    for candidate in aliases:
        if candidate not in seen:
            seen.add(candidate)
            ordered.append(candidate)
    return ordered


def _mapping_value(mapping: Any, *keys: str) -> Any:
    if not isinstance(mapping, dict):
        return None

    for key in keys:
        for candidate in _mapping_aliases(key):
            if candidate in mapping:
                return mapping[candidate]
    return None


class _LoadStrikeMappingView(MutableMapping[str, Any]):
    def __init__(self, raw: Optional[Dict[str, Any]] = None) -> None:
        self._raw: Dict[str, Any] = raw if isinstance(raw, dict) else {}

    def __getitem__(self, key: str) -> Any:
        return self._raw[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self._raw[key] = _clone_nested(value)

    def __delitem__(self, key: str) -> None:
        del self._raw[key]

    def __iter__(self) -> Iterator[str]:
        return iter(self._raw)

    def __len__(self) -> int:
        return len(self._raw)

    def to_dict(self) -> Dict[str, Any]:
        return _clone_nested(self._raw)

    def __repr__(self) -> str:
        return f"{self.__class__.__name__}({self._raw!r})"

    def _value(self, *keys: str) -> Any:
        return _mapping_value(self._raw, *keys)

    def _dict(self, *keys: str) -> Dict[str, Any]:
        value = self._value(*keys)
        return value if isinstance(value, dict) else {}

    def _list(self, *keys: str) -> List[Any]:
        value = self._value(*keys)
        return value if isinstance(value, list) else []


class LoadStrikeNodeInfo(_LoadStrikeMappingView):
    def __init__(self, raw: Optional[Dict[str, Any]] = None) -> None:
        super().__init__(raw if isinstance(raw, dict) else {})

    @property
    def cores_count(self) -> int:
        return _as_int(self._value("coresCount"))

    @property
    def current_operation(self) -> str:
        return _enum_or_string(LoadStrikeOperationType, self._value("currentOperation"))

    @property
    def dotnet_version(self) -> str:
        return str(self._value("dotNetVersion") or "")

    @property
    def machine_name(self) -> str:
        return str(self._value("machineName") or "")

    @property
    def engine_version(self) -> str:
        return str(self._value("engineVersion", "loadStrikeVersion") or "")

    @property
    def node_type(self) -> str:
        return _enum_or_string(LoadStrikeNodeType, self._value("nodeType"))

    @property
    def os(self) -> str:
        return str(self._value("os", "OS") or "")

    @property
    def processor(self) -> str:
        return str(self._value("processor") or "")

    CoresCount = property(lambda self: self.cores_count)
    CurrentOperation = property(lambda self: self.current_operation)
    DotNetVersion = property(lambda self: self.dotnet_version)
    MachineName = property(lambda self: self.machine_name)
    EngineVersion = property(lambda self: self.engine_version)
    NodeType = property(lambda self: self.node_type)
    OS = property(lambda self: self.os)
    Processor = property(lambda self: self.processor)


class LoadStrikeTestInfo(_LoadStrikeMappingView):
    def __init__(self, raw: Optional[Dict[str, Any]] = None) -> None:
        super().__init__(raw if isinstance(raw, dict) else {})

    @property
    def cluster_id(self) -> str:
        return str(self._value("clusterId") or "")

    @property
    def created(self) -> Optional[datetime]:
        return _parse_datetime_utc(self._value("createdUtc", "created"))

    @property
    def created_datetime(self) -> Optional[datetime]:
        return self.created

    @property
    def session_id(self) -> str:
        return str(self._value("sessionId") or "")

    @property
    def test_name(self) -> str:
        return str(self._value("testName") or "")

    @property
    def test_suite(self) -> str:
        return str(self._value("testSuite") or "")

    ClusterId = property(lambda self: self.cluster_id)
    Created = property(lambda self: self.created)
    CreatedDateTime = property(lambda self: self.created_datetime)
    SessionId = property(lambda self: self.session_id)
    TestName = property(lambda self: self.test_name)
    TestSuite = property(lambda self: self.test_suite)


class LoadStrikeScenarioInfo(_LoadStrikeMappingView):
    def __init__(self, raw: Optional[Dict[str, Any]] = None) -> None:
        super().__init__(raw if isinstance(raw, dict) else {})

    @property
    def instance_id(self) -> str:
        return str(self._value("instanceId") or "")

    @property
    def instance_number(self) -> int:
        return _as_int(self._value("instanceNumber"))

    @property
    def scenario_duration_ms(self) -> int:
        return _as_int(_duration_ms_from_value(self._value("scenarioDurationMs", "scenarioDuration")))

    @property
    def scenario_duration(self) -> timedelta:
        return _timedelta_from_ms(self._value("scenarioDurationMs", "scenarioDuration"))

    @property
    def scenario_name(self) -> str:
        return str(self._value("scenarioName") or "")

    @property
    def scenario_operation(self) -> str:
        return _enum_or_string(LoadStrikeScenarioOperation, self._value("scenarioOperation"))

    InstanceId = property(lambda self: self.instance_id)
    InstanceNumber = property(lambda self: self.instance_number)
    ScenarioDuration = property(lambda self: self.scenario_duration)
    ScenarioDurationMs = property(lambda self: self.scenario_duration_ms)
    ScenarioName = property(lambda self: self.scenario_name)
    ScenarioOperation = property(lambda self: self.scenario_operation)


class LoadStrikeScenarioStartInfo(_LoadStrikeMappingView):
    def __init__(self, raw: Optional[Dict[str, Any]] = None) -> None:
        super().__init__(raw if isinstance(raw, dict) else {})

    @property
    def scenario_name(self) -> str:
        return str(self._value("scenarioName") or "")

    @property
    def sort_index(self) -> int:
        return _as_int(self._value("sortIndex"))

    ScenarioName = property(lambda self: self.scenario_name)
    SortIndex = property(lambda self: self.sort_index)


class LoadStrikeSessionStartInfo(_LoadStrikeMappingView):
    def __init__(self, raw: Optional[Dict[str, Any]] = None) -> None:
        super().__init__(raw if isinstance(raw, dict) else {})

    @property
    def scenarios(self) -> List[LoadStrikeScenarioStartInfo]:
        rows = self._list("scenarios")
        return [LoadStrikeScenarioStartInfo(row) for row in rows if isinstance(row, dict)]

    Scenarios = property(lambda self: self.scenarios)


class LoadStrikeBaseContext(_LoadStrikeMappingView):
    def __init__(
        self,
        *,
        logger: Any,
        test_info: LoadStrikeTestInfo,
        node_info: LoadStrikeNodeInfo,
    ) -> None:
        super().__init__(
            {
                "logger": logger,
                "testInfo": test_info.to_dict(),
                "nodeInfo": node_info.to_dict(),
            }
        )

    @property
    def logger(self) -> Any:
        return self._value("logger")

    @property
    def test_info(self) -> LoadStrikeTestInfo:
        return LoadStrikeTestInfo(self._dict("testInfo"))

    @property
    def node_info(self) -> LoadStrikeNodeInfo:
        return LoadStrikeNodeInfo(self._dict("nodeInfo"))

    def get_node_info(self) -> LoadStrikeNodeInfo:
        return LoadStrikeNodeInfo(self._dict("nodeInfo"))

    Logger = property(lambda self: self.logger)
    NodeInfo = property(lambda self: self.node_info)
    TestInfo = property(lambda self: self.test_info)
    GetNodeInfo = get_node_info


class LoadStrikePluginDataTable(_LoadStrikeMappingView):
    def __init__(
        self,
        table_name: str,
        rows: Optional[List[Dict[str, Any]]] = None,
        headers: Optional[List[str]] = None,
    ) -> None:
        resolved = _require_non_empty(table_name, "Table name must be provided.")
        super().__init__(
            {
                "tableName": resolved,
                "headers": [str(value) for value in list(headers or [])],
                "rows": [dict(row) for row in list(rows or []) if isinstance(row, dict)],
            }
        )

    @staticmethod
    def create(table_name: str) -> "LoadStrikePluginDataTable":
        return LoadStrikePluginDataTable(table_name)

    def add_row(self, row: Dict[str, Any]) -> "LoadStrikePluginDataTable":
        if isinstance(row, dict):
            self._raw.setdefault("rows", []).append(dict(row))
        return self

    @property
    def table_name(self) -> str:
        return str(self._value("tableName") or "")

    @property
    def rows(self) -> List[Dict[str, Any]]:
        values = self._list("rows")
        if values:
            return values
        values = self._raw.setdefault("rows", [])
        return values if isinstance(values, list) else []

    @property
    def headers(self) -> List[str]:
        values = self._list("headers")
        if values:
            return values
        values = self._raw.setdefault("headers", [])
        return values if isinstance(values, list) else []

    Create = create
    AddRow = add_row
    TableName = property(lambda self: self.table_name)
    Rows = property(lambda self: self.rows)
    Headers = property(lambda self: self.headers)


class LoadStrikePluginData(_LoadStrikeMappingView):
    def __init__(
        self,
        plugin_name: str,
        *,
        hints: Optional[List[str]] = None,
        tables: Optional[List[Dict[str, Any]]] = None,
    ) -> None:
        resolved = _require_non_empty(plugin_name, "Plugin name must be provided.")
        super().__init__(
            {
                "pluginName": resolved,
                "hints": [str(value) for value in list(hints or [])],
                "tables": [dict(table) for table in list(tables or []) if isinstance(table, dict)],
            }
        )

    @staticmethod
    def create(plugin_name: str) -> "LoadStrikePluginData":
        return LoadStrikePluginData(plugin_name)

    def add_table(self, table: LoadStrikePluginDataTable | Dict[str, Any]) -> "LoadStrikePluginData":
        if isinstance(table, LoadStrikePluginDataTable):
            self._raw.setdefault("tables", []).append(table.to_dict())
        elif isinstance(table, dict):
            self._raw.setdefault("tables", []).append(dict(table))
        return self

    @property
    def plugin_name(self) -> str:
        return str(self._value("pluginName") or "")

    @property
    def hints(self) -> List[str]:
        values = self._list("hints")
        if values:
            return values
        values = self._raw.setdefault("hints", [])
        return values if isinstance(values, list) else []

    @property
    def tables(self) -> List[LoadStrikePluginDataTable]:
        rows = self._list("tables")
        return [
            LoadStrikePluginDataTable(
                str(_mapping_value(row, "tableName") or "table"),
                _mapping_value(row, "rows"),
                _mapping_value(row, "headers"),
            )
            for row in rows
            if isinstance(row, dict)
        ]

    Create = create
    AddTable = add_table
    PluginName = property(lambda self: self.plugin_name)
    Hints = property(lambda self: self.hints)
    Tables = property(lambda self: self.tables)


class LoadStrikeRequestStats(_LoadStrikeMappingView):
    def __init__(self, raw: Optional[Dict[str, Any]] = None) -> None:
        super().__init__(raw if isinstance(raw, dict) else {})

    @property
    def count(self) -> int:
        return _as_int(self._value("count"))

    @property
    def percent(self) -> int:
        return _as_int(self._value("percent"))

    @property
    def rps(self) -> float:
        return _as_float(self._value("rps"))

    Count = property(lambda self: self.count)
    Percent = property(lambda self: self.percent)
    RPS = property(lambda self: self.rps)


class LoadStrikeDataTransferStats(_LoadStrikeMappingView):
    def __init__(self, raw: Optional[Dict[str, Any]] = None) -> None:
        super().__init__(raw if isinstance(raw, dict) else {})

    @property
    def all_bytes(self) -> int:
        return _as_int(self._value("allBytes"))

    @property
    def max_bytes(self) -> int:
        return _as_int(self._value("maxBytes"))

    @property
    def mean_bytes(self) -> int:
        return _as_int(self._value("meanBytes"))

    @property
    def min_bytes(self) -> int:
        return _as_int(self._value("minBytes"))

    @property
    def percent50(self) -> int:
        return _as_int(self._value("percent50"))

    @property
    def percent75(self) -> int:
        return _as_int(self._value("percent75"))

    @property
    def percent95(self) -> int:
        return _as_int(self._value("percent95"))

    @property
    def percent99(self) -> int:
        return _as_int(self._value("percent99"))

    @property
    def std_dev(self) -> float:
        return _as_float(self._value("stdDev"))

    AllBytes = property(lambda self: self.all_bytes)
    MaxBytes = property(lambda self: self.max_bytes)
    MeanBytes = property(lambda self: self.mean_bytes)
    MinBytes = property(lambda self: self.min_bytes)
    Percent50 = property(lambda self: self.percent50)
    Percent75 = property(lambda self: self.percent75)
    Percent95 = property(lambda self: self.percent95)
    Percent99 = property(lambda self: self.percent99)
    StdDev = property(lambda self: self.std_dev)


class LoadStrikeLatencyCount(_LoadStrikeMappingView):
    def __init__(self, raw: Optional[Dict[str, Any]] = None) -> None:
        super().__init__(raw if isinstance(raw, dict) else {})

    @property
    def less_or_eq_800(self) -> int:
        return _as_int(self._value("lessOrEq800"))

    @property
    def more_800_less_1200(self) -> int:
        return _as_int(self._value("more800Less1200"))

    @property
    def more_or_eq_1200(self) -> int:
        return _as_int(self._value("moreOrEq1200"))

    LessOrEq800 = property(lambda self: self.less_or_eq_800)
    More800Less1200 = property(lambda self: self.more_800_less_1200)
    MoreOrEq1200 = property(lambda self: self.more_or_eq_1200)


class LoadStrikeLatencyStats(_LoadStrikeMappingView):
    def __init__(self, raw: Optional[Dict[str, Any]] = None) -> None:
        super().__init__(raw if isinstance(raw, dict) else {})

    @property
    def latency_count(self) -> LoadStrikeLatencyCount:
        return LoadStrikeLatencyCount(self._dict("latencyCount"))

    @property
    def max_ms(self) -> float:
        return _as_float(self._value("maxMs"))

    @property
    def mean_ms(self) -> float:
        return _as_float(self._value("meanMs"))

    @property
    def min_ms(self) -> float:
        return _as_float(self._value("minMs"))

    @property
    def percent50(self) -> float:
        return _as_float(self._value("percent50"))

    @property
    def percent75(self) -> float:
        return _as_float(self._value("percent75"))

    @property
    def percent95(self) -> float:
        return _as_float(self._value("percent95"))

    @property
    def percent99(self) -> float:
        return _as_float(self._value("percent99"))

    @property
    def std_dev(self) -> float:
        return _as_float(self._value("stdDev"))

    LatencyCount = property(lambda self: self.latency_count)
    MaxMs = property(lambda self: self.max_ms)
    MeanMs = property(lambda self: self.mean_ms)
    MinMs = property(lambda self: self.min_ms)
    Percent50 = property(lambda self: self.percent50)
    Percent75 = property(lambda self: self.percent75)
    Percent95 = property(lambda self: self.percent95)
    Percent99 = property(lambda self: self.percent99)
    StdDev = property(lambda self: self.std_dev)


class LoadStrikeStatusCodeStats(_LoadStrikeMappingView):
    def __init__(self, raw: Optional[Dict[str, Any]] = None) -> None:
        super().__init__(raw if isinstance(raw, dict) else {})

    @property
    def count(self) -> int:
        return _as_int(self._value("count"))

    @property
    def is_error(self) -> bool:
        return bool(self._value("isError"))

    @property
    def message(self) -> str:
        return str(self._value("message") or "")

    @property
    def percent(self) -> int:
        return _as_int(self._value("percent"))

    @property
    def status_code(self) -> str:
        return str(self._value("statusCode") or "")

    Count = property(lambda self: self.count)
    IsError = property(lambda self: self.is_error)
    Message = property(lambda self: self.message)
    Percent = property(lambda self: self.percent)
    StatusCode = property(lambda self: self.status_code)


class LoadStrikeMeasurementStats(_LoadStrikeMappingView):
    def __init__(self, raw: Optional[Dict[str, Any]] = None) -> None:
        super().__init__(raw if isinstance(raw, dict) else {})

    @property
    def data_transfer(self) -> LoadStrikeDataTransferStats:
        return LoadStrikeDataTransferStats(self._dict("dataTransfer"))

    @property
    def latency(self) -> LoadStrikeLatencyStats:
        return LoadStrikeLatencyStats(self._dict("latency"))

    @property
    def request(self) -> LoadStrikeRequestStats:
        return LoadStrikeRequestStats(self._dict("request"))

    @property
    def status_codes(self) -> List[LoadStrikeStatusCodeStats]:
        rows = self._list("statusCodes")
        return [LoadStrikeStatusCodeStats(row) for row in rows if isinstance(row, dict)]

    DataTransfer = property(lambda self: self.data_transfer)
    Latency = property(lambda self: self.latency)
    Request = property(lambda self: self.request)
    StatusCodes = property(lambda self: self.status_codes)


class LoadStrikeLoadSimulationStats(_LoadStrikeMappingView):
    def __init__(self, raw: Optional[Dict[str, Any]] = None) -> None:
        super().__init__(raw if isinstance(raw, dict) else {})

    @property
    def simulation_name(self) -> str:
        return str(self._value("simulationName") or "")

    @property
    def value(self) -> int:
        return _as_int(self._value("value"))

    SimulationName = property(lambda self: self.simulation_name)
    Value = property(lambda self: self.value)


class LoadStrikeThresholdResult(_LoadStrikeMappingView):
    def __init__(self, raw: Optional[Dict[str, Any]] = None) -> None:
        super().__init__(raw if isinstance(raw, dict) else {})

    @property
    def check_expression(self) -> str:
        return str(self._value("checkExpression") or "")

    @property
    def error_count(self) -> int:
        return _as_int(self._value("errorCount"))

    @property
    def exception_msg(self) -> str:
        return str(self._value("exceptionMsg", "exceptionMessage") or "")

    @property
    def is_failed(self) -> bool:
        return bool(self._value("isFailed"))

    @property
    def scenario_name(self) -> str:
        return str(self._value("scenarioName") or "")

    @property
    def step_name(self) -> str:
        return str(self._value("stepName") or "")

    CheckExpression = property(lambda self: self.check_expression)
    ErrorCount = property(lambda self: self.error_count)
    ExceptionMsg = property(lambda self: self.exception_msg)
    IsFailed = property(lambda self: self.is_failed)
    ScenarioName = property(lambda self: self.scenario_name)
    StepName = property(lambda self: self.step_name)


class LoadStrikeCounterStats(_LoadStrikeMappingView):
    def __init__(self, raw: Optional[Dict[str, Any]] = None) -> None:
        super().__init__(raw if isinstance(raw, dict) else {})

    @property
    def metric_name(self) -> str:
        return str(self._value("metricName", "name") or "")

    @property
    def scenario_name(self) -> str:
        return str(self._value("scenarioName") or "")

    @property
    def unit_of_measure(self) -> str:
        return str(self._value("unitOfMeasure") or "")

    @property
    def value(self) -> int:
        return _as_int(self._value("value"))

    MetricName = property(lambda self: self.metric_name)
    ScenarioName = property(lambda self: self.scenario_name)
    UnitOfMeasure = property(lambda self: self.unit_of_measure)
    Value = property(lambda self: self.value)


class LoadStrikeGaugeStats(_LoadStrikeMappingView):
    def __init__(self, raw: Optional[Dict[str, Any]] = None) -> None:
        super().__init__(raw if isinstance(raw, dict) else {})

    @property
    def metric_name(self) -> str:
        return str(self._value("metricName", "name") or "")

    @property
    def scenario_name(self) -> str:
        return str(self._value("scenarioName") or "")

    @property
    def unit_of_measure(self) -> str:
        return str(self._value("unitOfMeasure") or "")

    @property
    def value(self) -> float:
        return _as_float(self._value("value"))

    MetricName = property(lambda self: self.metric_name)
    ScenarioName = property(lambda self: self.scenario_name)
    UnitOfMeasure = property(lambda self: self.unit_of_measure)
    Value = property(lambda self: self.value)


class LoadStrikeMetricStats(_LoadStrikeMappingView):
    def __init__(self, raw: Optional[Dict[str, Any]] = None) -> None:
        super().__init__(raw if isinstance(raw, dict) else {})

    @property
    def duration(self) -> timedelta:
        return _timedelta_from_ms(self._value("durationMs", "duration"))

    @property
    def counters(self) -> List[LoadStrikeCounterStats]:
        rows = self._list("counters")
        return [LoadStrikeCounterStats(row) for row in rows if isinstance(row, dict)]

    @property
    def gauges(self) -> List[LoadStrikeGaugeStats]:
        rows = self._list("gauges")
        return [LoadStrikeGaugeStats(row) for row in rows if isinstance(row, dict)]

    Duration = property(lambda self: self.duration)
    Counters = property(lambda self: self.counters)
    Gauges = property(lambda self: self.gauges)


class LoadStrikeStepStats(_LoadStrikeMappingView):
    def __init__(self, raw: Optional[Dict[str, Any]] = None) -> None:
        super().__init__(raw if isinstance(raw, dict) else {})

    @property
    def fail(self) -> LoadStrikeMeasurementStats:
        return LoadStrikeMeasurementStats(self._dict("fail"))

    @property
    def ok(self) -> LoadStrikeMeasurementStats:
        return LoadStrikeMeasurementStats(self._dict("ok"))

    @property
    def sort_index(self) -> int:
        return _as_int(self._value("sortIndex"))

    @property
    def step_name(self) -> str:
        return str(self._value("stepName") or "")

    Fail = property(lambda self: self.fail)
    Ok = property(lambda self: self.ok)
    SortIndex = property(lambda self: self.sort_index)
    StepName = property(lambda self: self.step_name)


class LoadStrikeScenarioStats(_LoadStrikeMappingView):
    def __init__(self, raw: Optional[Dict[str, Any]] = None) -> None:
        super().__init__(raw if isinstance(raw, dict) else {})

    @property
    def all_bytes(self) -> int:
        return _as_int(self._value("allBytes"))

    @property
    def all_fail_count(self) -> int:
        return _as_int(self._value("allFailCount"))

    @property
    def all_ok_count(self) -> int:
        return _as_int(self._value("allOkCount"))

    @property
    def all_request_count(self) -> int:
        return _as_int(self._value("allRequestCount"))

    @property
    def current_operation(self) -> str:
        return _enum_or_string(LoadStrikeOperationType, self._value("currentOperation"))

    @property
    def duration(self) -> timedelta:
        return _timedelta_from_ms(self._value("durationMs", "duration"))

    @property
    def fail(self) -> LoadStrikeMeasurementStats:
        return LoadStrikeMeasurementStats(self._dict("fail"))

    @property
    def load_simulation_stats(self) -> LoadStrikeLoadSimulationStats:
        return LoadStrikeLoadSimulationStats(self._dict("loadSimulationStats"))

    @property
    def ok(self) -> LoadStrikeMeasurementStats:
        return LoadStrikeMeasurementStats(self._dict("ok"))

    @property
    def scenario_name(self) -> str:
        return str(self._value("scenarioName") or "")

    @property
    def sort_index(self) -> int:
        return _as_int(self._value("sortIndex"))

    @property
    def step_stats(self) -> List[LoadStrikeStepStats]:
        rows = self._list("stepStats")
        return [LoadStrikeStepStats(row) for row in rows if isinstance(row, dict)]

    def find_step_stats(self, step_name: str) -> Optional[LoadStrikeStepStats]:
        for row in self.step_stats:
            if row.step_name == step_name:
                return row
        return None

    def get_step_stats(self, step_name: str) -> LoadStrikeStepStats:
        row = self.find_step_stats(step_name)
        if row is None:
            raise LoadStrikeInvalidOperationError(f"Step stats not found: {step_name}.")
        return row

    AllBytes = property(lambda self: self.all_bytes)
    AllFailCount = property(lambda self: self.all_fail_count)
    AllOkCount = property(lambda self: self.all_ok_count)
    AllRequestCount = property(lambda self: self.all_request_count)
    CurrentOperation = property(lambda self: self.current_operation)
    Duration = property(lambda self: self.duration)
    Fail = property(lambda self: self.fail)
    LoadSimulationStats = property(lambda self: self.load_simulation_stats)
    Ok = property(lambda self: self.ok)
    ScenarioName = property(lambda self: self.scenario_name)
    SortIndex = property(lambda self: self.sort_index)
    StepStats = property(lambda self: self.step_stats)
    FindStepStats = find_step_stats
    GetStepStats = get_step_stats


class LoadStrikeReportData(_LoadStrikeMappingView):
    def __init__(self, raw: Optional[Dict[str, Any]] = None) -> None:
        super().__init__(raw if isinstance(raw, dict) else {"scenarioStats": []})
        if not isinstance(self._value("scenarioStats"), list):
            self._raw["scenarioStats"] = []

    @staticmethod
    def create(*scenario_stats: LoadStrikeScenarioStats | Dict[str, Any]) -> "LoadStrikeReportData":
        rows = []
        for item in scenario_stats:
            if item is None:
                raise TypeError("scenario_stats cannot contain None.")
            if isinstance(item, LoadStrikeScenarioStats):
                rows.append(item.to_dict())
            elif isinstance(item, dict):
                rows.append(dict(item))
            else:
                raise TypeError("scenario_stats must contain LoadStrikeScenarioStats or dict values.")
        return LoadStrikeReportData({"scenarioStats": rows})

    @property
    def scenario_stats(self) -> List[LoadStrikeScenarioStats]:
        rows = self._list("scenarioStats")
        return [LoadStrikeScenarioStats(row) for row in rows if isinstance(row, dict)]

    def find_scenario_stats(self, scenario_name: str) -> Optional[LoadStrikeScenarioStats]:
        for row in self.scenario_stats:
            if row.scenario_name == scenario_name:
                return row
        return None

    def get_scenario_stats(self, scenario_name: str) -> LoadStrikeScenarioStats:
        row = self.find_scenario_stats(scenario_name)
        if row is None:
            raise LoadStrikeInvalidOperationError(f"Scenario stats not found: {scenario_name}.")
        return row

    Create = create
    ScenarioStats = property(lambda self: self.scenario_stats)
    FindScenarioStats = find_scenario_stats
    GetScenarioStats = get_scenario_stats


class LoadStrikeNodeStats(_LoadStrikeMappingView):
    def __init__(self, raw: Optional[Dict[str, Any]] = None) -> None:
        super().__init__(raw if isinstance(raw, dict) else {})

    @property
    def all_bytes(self) -> int:
        return _as_int(self._value("allBytes"))

    @property
    def all_fail_count(self) -> int:
        return _as_int(self._value("allFailCount"))

    @property
    def all_ok_count(self) -> int:
        return _as_int(self._value("allOkCount"))

    @property
    def all_request_count(self) -> int:
        return _as_int(self._value("allRequestCount"))

    @property
    def duration(self) -> timedelta:
        return _timedelta_from_ms(self._value("durationMs", "duration"))

    @property
    def metrics(self) -> LoadStrikeMetricStats:
        payload = self._value("metricStats")
        if not isinstance(payload, dict):
            raw_metrics = self._value("metrics")
            if isinstance(raw_metrics, dict):
                payload = raw_metrics
            else:
                payload = _build_metric_stats_payload(
                    raw_metrics,
                    _duration_ms_from_value(self._value("durationMs", "duration")),
                )
        return LoadStrikeMetricStats(payload)

    @property
    def node_info(self) -> LoadStrikeNodeInfo:
        return LoadStrikeNodeInfo(self._dict("nodeInfo"))

    @property
    def test_info(self) -> LoadStrikeTestInfo:
        return LoadStrikeTestInfo(self._dict("testInfo"))

    @property
    def thresholds(self) -> List[LoadStrikeThresholdResult]:
        rows = self._list("thresholdResults") or self._list("thresholds")
        return [LoadStrikeThresholdResult(row) for row in rows if isinstance(row, dict)]

    @property
    def scenario_stats(self) -> List[LoadStrikeScenarioStats]:
        rows = self._list("scenarioStats")
        return [LoadStrikeScenarioStats(row) for row in rows if isinstance(row, dict)]

    @property
    def plugins_data(self) -> List[LoadStrikePluginData]:
        rows = self._list("pluginsData")
        values: List[LoadStrikePluginData] = []
        for row in rows:
            if isinstance(row, dict):
                values.append(
                    LoadStrikePluginData(
                        str(_mapping_value(row, "pluginName") or "unnamed-plugin"),
                        hints=_mapping_value(row, "hints"),
                        tables=_mapping_value(row, "tables"),
                    )
                )
        return values

    def find_scenario_stats(self, scenario_name: str) -> Optional[LoadStrikeScenarioStats]:
        for row in self.scenario_stats:
            if row.scenario_name == scenario_name:
                return row
        return None

    def get_scenario_stats(self, scenario_name: str) -> LoadStrikeScenarioStats:
        row = self.find_scenario_stats(scenario_name)
        if row is None:
            raise LoadStrikeInvalidOperationError(f"Scenario stats not found: {scenario_name}.")
        return row

    AllBytes = property(lambda self: self.all_bytes)
    AllFailCount = property(lambda self: self.all_fail_count)
    AllOkCount = property(lambda self: self.all_ok_count)
    AllRequestCount = property(lambda self: self.all_request_count)
    Duration = property(lambda self: self.duration)
    Metrics = property(lambda self: self.metrics)
    NodeInfo = property(lambda self: self.node_info)
    Thresholds = property(lambda self: self.thresholds)
    TestInfo = property(lambda self: self.test_info)
    ScenarioStats = property(lambda self: self.scenario_stats)
    PluginsData = property(lambda self: self.plugins_data)
    FindScenarioStats = find_scenario_stats
    GetScenarioStats = get_scenario_stats


def _coerce_report_finalizer_result(finalized: Any) -> LoadStrikeReportData:
    if isinstance(finalized, LoadStrikeReportData):
        return finalized
    raise TypeError("Report finalizer must return LoadStrikeReportData.")


def _report_data_from_result(result: LoadStrikeNodeStats | Dict[str, Any]) -> LoadStrikeReportData:
    node_stats = result if isinstance(result, LoadStrikeNodeStats) else LoadStrikeNodeStats(result)
    return LoadStrikeReportData.create(
        *[
            dict(row)
            for row in node_stats._list("scenarioStats")
            if isinstance(row, dict)
        ]
    )


def _apply_report_data_to_result(result: Dict[str, Any], updated: LoadStrikeReportData) -> None:
    scenario_rows = [
        dict(row)
        for row in updated.get("scenarioStats", [])
        if isinstance(row, dict)
    ]
    result["scenarioStats"] = scenario_rows
    result["stepStats"] = _flatten_step_stats(scenario_rows)
    result["allRequestCount"] = sum(_as_int(row.get("allRequestCount")) for row in scenario_rows)
    result["allOkCount"] = sum(_as_int(row.get("allOkCount")) for row in scenario_rows)
    result["allFailCount"] = sum(_as_int(row.get("allFailCount")) for row in scenario_rows)
    result["allBytes"] = sum(_as_int(row.get("allBytes")) for row in scenario_rows)

    scenario_names = {
        str(row.get("scenarioName") or "")
        for row in scenario_rows
        if str(row.get("scenarioName") or "").strip()
    }
    threshold_rows = [
        dict(row)
        for row in (result.get("thresholdResults") or result.get("thresholds") or [])
        if isinstance(row, dict)
    ]
    filtered_thresholds = [
        row
        for row in threshold_rows
        if not str(row.get("scenarioName") or "").strip()
        or str(row.get("scenarioName") or "") in scenario_names
    ]
    result["thresholdResults"] = filtered_thresholds
    result["thresholds"] = filtered_thresholds
    result["failedThresholds"] = sum(1 for row in filtered_thresholds if _as_bool(row.get("isFailed") or row.get("IsFailed")))


def _coerce_detailed_report_finalizer_result(finalized: Any) -> Dict[str, Any]:
    if isinstance(finalized, LoadStrikeNodeStats):
        return finalized.to_dict()
    if isinstance(finalized, dict):
        return dict(finalized)
    raise TypeError("Detailed report finalizer must return LoadStrikeNodeStats or dict.")


def _build_report_finalizer_adapter(
    report_finalizer: Callable[[LoadStrikeReportData], LoadStrikeReportData],
) -> Callable[[LoadStrikeNodeStats], LoadStrikeNodeStats]:
    def _adapter(result: LoadStrikeNodeStats) -> LoadStrikeNodeStats:
        node_stats = result if isinstance(result, LoadStrikeNodeStats) else LoadStrikeNodeStats(result)
        updated = _coerce_report_finalizer_result(
            _invoke_maybe_async(report_finalizer, _report_data_from_result(node_stats))
        )
        raw = node_stats.to_dict()
        _apply_report_data_to_result(raw, updated)
        return LoadStrikeNodeStats(raw)

    setattr(_adapter, "_loadstrike_report_finalizer_adapter", True)
    return _adapter


def _build_detailed_report_finalizer_adapter(
    report_finalizer: Callable[[LoadStrikeNodeStats], LoadStrikeNodeStats | Dict[str, Any]],
) -> Callable[[LoadStrikeNodeStats], LoadStrikeNodeStats | Dict[str, Any]]:
    def _adapter(result: LoadStrikeNodeStats) -> LoadStrikeNodeStats | Dict[str, Any]:
        return _invoke_maybe_async(report_finalizer, result)

    setattr(_adapter, "_loadstrike_detailed_report_finalizer", True)
    return _adapter


def _normalize_runner_option_finalizers(options: Dict[str, Any]) -> Dict[str, Any]:
    normalized = dict(options)
    detailed_report_finalizer = normalized.pop("detailed_report_finalizer", None)
    if callable(detailed_report_finalizer):
        normalized["report_finalizer"] = _build_detailed_report_finalizer_adapter(detailed_report_finalizer)

    report_finalizer = normalized.get("report_finalizer")
    if callable(report_finalizer):
        if getattr(report_finalizer, "_loadstrike_report_finalizer_adapter", False):
            return normalized
        if getattr(report_finalizer, "_loadstrike_detailed_report_finalizer", False):
            return normalized
        normalized["report_finalizer"] = _build_report_finalizer_adapter(report_finalizer)

    return normalized


def _resolve_response_custom_latency(custom_latency_ms: Any, uses_overload_defaults: bool) -> float:
    if custom_latency_ms is _RESPONSE_ARGUMENT_UNSET or custom_latency_ms is None:
        return -1.0 if uses_overload_defaults else 0.0
    return _as_float(custom_latency_ms)


def _resolve_runtime_latency(custom_latency_ms: Optional[float], elapsed_ms: float) -> float:
    if custom_latency_ms is None:
        return 0.0
    resolved = _as_float(custom_latency_ms)
    if resolved >= 0:
        return resolved
    return max(float(elapsed_ms), 0.0)


class LoadStrikeResponse:
    @staticmethod
    def ok(
        *args: Any,
        payload: Any = _RESPONSE_ARGUMENT_UNSET,
        status_code: Any = _RESPONSE_ARGUMENT_UNSET,
        size_bytes: Any = _RESPONSE_ARGUMENT_UNSET,
        message: Any = _RESPONSE_ARGUMENT_UNSET,
        custom_latency_ms: Any = _RESPONSE_ARGUMENT_UNSET,
    ) -> LoadStrikeReply:
        payload_provided = payload is not _RESPONSE_ARGUMENT_UNSET
        status_provided = status_code is not _RESPONSE_ARGUMENT_UNSET
        size_provided = size_bytes is not _RESPONSE_ARGUMENT_UNSET
        message_provided = message is not _RESPONSE_ARGUMENT_UNSET

        resolved_payload = None if payload is _RESPONSE_ARGUMENT_UNSET else payload
        resolved_status_code = "200" if status_code is _RESPONSE_ARGUMENT_UNSET else str(status_code)
        resolved_size_bytes = 0 if size_bytes is _RESPONSE_ARGUMENT_UNSET else _as_int(size_bytes)
        resolved_message = "" if message is _RESPONSE_ARGUMENT_UNSET else str(message)

        if args:
            positional = list(args)
            if (
                not payload_provided
                and positional
                and not isinstance(positional[0], str)
                and (len(positional) == 1 or isinstance(positional[1], str))
            ):
                resolved_payload = positional.pop(0)
                payload_provided = True
            if positional:
                if len(positional) >= 1:
                    resolved_status_code = str(positional[0])
                    status_provided = True
                if len(positional) >= 2:
                    resolved_size_bytes = _as_int(positional[1])
                    size_provided = True
                if len(positional) >= 3:
                    resolved_message = str(positional[2])
                    message_provided = True
                if len(positional) >= 4:
                    custom_latency_ms = positional[3]

        resolved_custom_latency_ms = _resolve_response_custom_latency(
            custom_latency_ms,
            payload_provided or status_provided or size_provided or message_provided,
        )

        return LoadStrikeReply(
            is_success=True,
            status_code=resolved_status_code,
            message=resolved_message,
            size_bytes=resolved_size_bytes,
            custom_latency_ms=resolved_custom_latency_ms,
            payload=resolved_payload,
        )

    @staticmethod
    def fail(
        *args: Any,
        payload: Any = _RESPONSE_ARGUMENT_UNSET,
        status_code: Any = _RESPONSE_ARGUMENT_UNSET,
        message: Any = _RESPONSE_ARGUMENT_UNSET,
        size_bytes: Any = _RESPONSE_ARGUMENT_UNSET,
        custom_latency_ms: Any = _RESPONSE_ARGUMENT_UNSET,
    ) -> LoadStrikeReply:
        payload_provided = payload is not _RESPONSE_ARGUMENT_UNSET
        status_provided = status_code is not _RESPONSE_ARGUMENT_UNSET
        message_provided = message is not _RESPONSE_ARGUMENT_UNSET
        size_provided = size_bytes is not _RESPONSE_ARGUMENT_UNSET

        resolved_payload = None if payload is _RESPONSE_ARGUMENT_UNSET else payload
        resolved_status_code = "500" if status_code is _RESPONSE_ARGUMENT_UNSET else str(status_code)
        resolved_message = "" if message is _RESPONSE_ARGUMENT_UNSET else str(message)
        resolved_size_bytes = 0 if size_bytes is _RESPONSE_ARGUMENT_UNSET else _as_int(size_bytes)

        if args:
            positional = list(args)
            if (
                not payload_provided
                and positional
                and not isinstance(positional[0], str)
                and (len(positional) == 1 or isinstance(positional[1], str))
            ):
                resolved_payload = positional.pop(0)
                payload_provided = True
            if positional:
                if len(positional) >= 1:
                    resolved_status_code = str(positional[0])
                    status_provided = True
                if len(positional) >= 2:
                    resolved_message = str(positional[1])
                    message_provided = True
                if len(positional) >= 3:
                    resolved_size_bytes = _as_int(positional[2])
                    size_provided = True
                if len(positional) >= 4:
                    custom_latency_ms = positional[3]

        resolved_custom_latency_ms = _resolve_response_custom_latency(
            custom_latency_ms,
            payload_provided or status_provided or message_provided or size_provided,
        )

        return LoadStrikeReply(
            is_success=False,
            status_code=resolved_status_code,
            message=resolved_message,
            size_bytes=resolved_size_bytes,
            custom_latency_ms=resolved_custom_latency_ms,
            payload=resolved_payload,
        )

    @staticmethod
    def ok_with_payload(
        payload: Any,
        status_code: str = "200",
        size_bytes: int = 0,
        message: str = "",
        custom_latency_ms: Any = _RESPONSE_ARGUMENT_UNSET,
    ) -> LoadStrikeReply:
        return LoadStrikeResponse.ok(
            payload=payload,
            status_code=status_code,
            size_bytes=size_bytes,
            message=message,
            custom_latency_ms=custom_latency_ms,
        )

    @staticmethod
    def fail_with_payload(
        payload: Any,
        status_code: str = "500",
        message: str = "",
        size_bytes: int = 0,
        custom_latency_ms: Any = _RESPONSE_ARGUMENT_UNSET,
    ) -> LoadStrikeReply:
        return LoadStrikeResponse.fail(
            payload=payload,
            status_code=status_code,
            message=message,
            size_bytes=size_bytes,
            custom_latency_ms=custom_latency_ms,
        )

    Ok = ok
    Fail = fail
    OkWithPayload = ok_with_payload
    FailWithPayload = fail_with_payload


@dataclass
class LoadStrikeSinkSession:
    started_utc: str
    scenario_names: List[str]
    config_path: Optional[str] = None
    infra_config_path: Optional[str] = None
    infra_config: Optional[Dict[str, Any]] = None


class LoadStrikeReportingSink(Protocol):
    @property
    def sink_name(self) -> str:
        ...

    @property
    def SinkName(self) -> str:
        ...

    def init(self, context: LoadStrikeBaseContext, infra_config: Dict[str, Any]) -> None:
        ...

    def start(self, session: LoadStrikeSessionStartInfo) -> None:
        ...

    def save_realtime_stats(self, scenario_stats: List[Dict[str, Any]]) -> None:
        ...

    def save_realtime_metrics(self, metrics: List[Dict[str, Any]]) -> None:
        ...

    def save_final_stats(self, result: LoadStrikeNodeStats) -> None:
        ...

    def save_run_result(self, result: Dict[str, Any]) -> None:
        ...

    def stop(self) -> None:
        ...


class LoadStrikeRuntimePolicy(Protocol):
    def should_run_scenario(self, scenario_name: str) -> bool:
        ...

    def before_scenario(self, scenario_name: str) -> None:
        ...

    def after_scenario(self, scenario_name: str, stats: Dict[str, Any]) -> None:
        ...

    def before_step(self, scenario_name: str, step_name: str) -> None:
        ...

    def after_step(self, scenario_name: str, step_name: str, reply: LoadStrikeStepReply) -> None:
        ...


class LoadStrikeWorkerPlugin(Protocol):
    plugin_name: str
    PluginName: str

    def init(self, context: LoadStrikeBaseContext, infra_config: Dict[str, Any]) -> None:
        ...

    def start(self, session: LoadStrikeSessionStartInfo) -> None:
        ...

    def stop(self) -> None:
        ...

    def get_data(self, result: LoadStrikeNodeStats) -> Optional[LoadStrikePluginData | Dict[str, Any]]:
        ...


@dataclass
class LoadStrikeScenarioPartition:
    number: int
    count: int

    Number = property(lambda self: self.number)
    Count = property(lambda self: self.count)


@dataclass
class LoadStrikeScenarioInitContext:
    custom_settings: Dict[str, Any]
    global_custom_settings: Dict[str, Any]
    logger: Any
    node_info: LoadStrikeNodeInfo
    test_info: LoadStrikeTestInfo
    scenario_info: LoadStrikeScenarioInfo
    scenario_partition: LoadStrikeScenarioPartition
    registered_metrics: List[Any] = field(default_factory=list)

    def register_metric(self, metric: Any) -> None:
        if metric is None:
            raise TypeError("metric must be provided.")
        self.registered_metrics.append(metric)

    CustomSettings = property(lambda self: self.custom_settings)
    GlobalCustomSettings = property(lambda self: self.global_custom_settings)
    Logger = property(lambda self: self.logger)
    NodeInfo = property(lambda self: self.node_info)
    TestInfo = property(lambda self: self.test_info)
    ScenarioInfo = property(lambda self: self.scenario_info)
    ScenarioPartition = property(lambda self: self.scenario_partition)
    RegisterMetric = register_metric


class LoadStrikeContext:
    def __init__(
        self,
        values: Optional[Dict[str, Any]] = None,
        *,
        scenarios: Optional[List["LoadStrikeScenario"]] = None,
    ) -> None:
        self._values: Dict[str, Any] = dict(values or {})
        _reject_disable_license_enforcement_option(self._values, "LoadStrikeContext")
        self._scenarios: List["LoadStrikeScenario"] = list(scenarios or [])

    @staticmethod
    def create() -> "LoadStrikeContext":
        return LoadStrikeContext()

    def to_dict(self) -> Dict[str, Any]:
        return dict(self._values)

    def run(self, *args: str) -> LoadStrikeNodeStats:
        return LoadStrikeNodeStats(self.run_detailed(*args))

    def run_detailed(self, *args: str) -> Dict[str, Any]:
        if not self._scenarios:
            raise LoadStrikeInvalidOperationError("At least one scenario must be added before building the runner context.")
        result = LoadStrikeRunner(self._scenarios, self.to_runner_options()).run_detailed(*args)
        if args:
            self._values = _runner_options_to_context_values(
                _apply_run_args(self.to_runner_options(), list(args))
            )
        return result

    def to_runner_options(self) -> Dict[str, Any]:
        _reject_disable_license_enforcement_option(self._values, "LoadStrikeContext")
        report_formats = self._values.get("ReportFormats")
        options = {
            "node_type": (
                _canonical_node_type_name(self._values.get("NodeType"))
                if self._values.get("NodeType") is not None
                else None
            ),
            "console_metrics_enabled": self._values.get("ConsoleMetricsEnabled"),
            "local_dev_cluster_enabled": self._values.get("LocalDevClusterEnabled"),
            "agent_group": self._values.get("AgentGroup"),
            "agents_count": self._values.get("AgentsCount"),
            "target_scenarios": self._values.get("TargetScenarios"),
            "agent_target_scenarios": self._values.get("AgentTargetScenarios"),
            "coordinator_target_scenarios": self._values.get("CoordinatorTargetScenarios"),
            "nats_server_url": self._values.get("NatsServerUrl"),
            "runner_key": self._values.get("RunnerKey"),
            "license_validation_server_url": self._values.get("LicenseValidationServerUrl"),
            "license_validation_timeout_seconds": self._values.get("LicenseValidationTimeoutSeconds"),
            "config_path": self._values.get("ConfigPath"),
            "infra_config_path": self._values.get("InfraConfigPath"),
            "infra_config": self._values.get("InfraConfig"),
            "cluster_id": self._values.get("ClusterId"),
            "session_id": self._values.get("SessionId"),
            "test_suite": self._values.get("TestSuite"),
            "test_name": self._values.get("TestName"),
            "reports_enabled": self._values.get("ReportsEnabled"),
            "report_file_name": self._values.get("ReportFileName"),
            "report_folder_path": self._values.get("ReportFolderPath"),
            "report_formats": (
                _normalize_report_formats_value(report_formats) if report_formats is not None else None
            ),
            "report_finalizer": self._values.get("ReportFinalizer"),
            "reporting_interval_seconds": self._values.get("ReportingIntervalSeconds"),
            "minimum_log_level": (
                _canonical_minimum_log_level_name(self._values.get("MinimumLogLevel"))
                if self._values.get("MinimumLogLevel") is not None
                else None
            ),
            "logger_config": self._values.get("LoggerConfig"),
            "reporting_sinks": self._values.get("ReportingSinks"),
            "runtime_policies": self._values.get("RuntimePolicies"),
            "scenario_completion_timeout_seconds": self._values.get("ScenarioCompletionTimeoutSeconds"),
            "cluster_command_timeout_seconds": self._values.get("ClusterCommandTimeoutSeconds"),
            "restart_iteration_max_attempts": self._values.get("RestartIterationMaxAttempts"),
            "worker_plugins": self._values.get("WorkerPlugins"),
            "custom_settings": self._values.get("CustomSettings"),
            "global_custom_settings": self._values.get("GlobalCustomSettings"),
        }
        if "SinkRetryCount" in self._values:
            options["sink_retry_count"] = self._values.get("SinkRetryCount")
        if "SinkRetryBackoffMs" in self._values:
            options["sink_retry_backoff_ms"] = self._values.get("SinkRetryBackoffMs")
        return options

    def display_console_metrics(self, enable: bool) -> "LoadStrikeContext":
        return self._clone_with(ConsoleMetricsEnabled=bool(enable))

    def enable_local_dev_cluster(self, enable: bool) -> "LoadStrikeContext":
        return self._clone_with(LocalDevClusterEnabled=bool(enable))

    def load_config(self, path: str) -> "LoadStrikeContext":
        config_path = _require_non_empty(path, "Config path must be provided.")
        loaded = _load_json_object(config_path)
        return self._clone_with(
            ConfigPath=config_path,
            CustomSettings=loaded,
            **_extract_context_overrides_from_config(loaded),
        )

    def load_infra_config(self, path: str) -> "LoadStrikeContext":
        infra_config_path = _require_non_empty(path, "Infra config path must be provided.")
        return self._clone_with(
            InfraConfigPath=infra_config_path,
            InfraConfig=_load_json_object(infra_config_path),
        )

    def with_runner_key(self, runner_key: str) -> "LoadStrikeContext":
        return self._clone_with(RunnerKey=_require_non_empty(runner_key, "Runner key must be provided."))

    def with_license_validation_server_url(self, server_url: str) -> "LoadStrikeContext":
        return self._clone_with(
            LicenseValidationServerUrl=_require_non_empty(
                server_url, "License validation server URL must be provided."
            )
        )

    def with_license_validation_timeout(self, timeout_seconds: float) -> "LoadStrikeContext":
        if timeout_seconds <= 0:
            raise ValueError("License validation timeout should be greater than zero.")
        return self._clone_with(LicenseValidationTimeoutSeconds=float(timeout_seconds))

    def with_node_type(self, node_type: str) -> "LoadStrikeContext":
        return self._clone_with(NodeType=_require_string_or_enum_value(node_type, "Node type must be provided."))

    def with_nats_server_url(self, nats_url: str) -> "LoadStrikeContext":
        return self._clone_with(NatsServerUrl=_require_non_empty(nats_url, "NATS server URL must be provided."))

    def with_agents_count(self, agents_count: int) -> "LoadStrikeContext":
        if agents_count <= 0:
            raise ValueError("Agents count should be greater than zero.")
        return self._clone_with(AgentsCount=int(agents_count))

    def with_agent_group(self, agent_group: str) -> "LoadStrikeContext":
        return self._clone_with(AgentGroup=_require_non_empty(agent_group, "Agent group must be provided."))

    def with_target_scenarios(self, *scenario_names: str) -> "LoadStrikeContext":
        return self._clone_with(TargetScenarios=_validate_scenario_names(list(scenario_names)))

    def with_agent_target_scenarios(self, *scenario_names: str) -> "LoadStrikeContext":
        return self._clone_with(AgentTargetScenarios=_validate_scenario_names(list(scenario_names)))

    def with_coordinator_target_scenarios(self, *scenario_names: str) -> "LoadStrikeContext":
        return self._clone_with(CoordinatorTargetScenarios=_validate_scenario_names(list(scenario_names)))

    def with_report_finalizer(
        self,
        report_finalizer: Callable[[LoadStrikeReportData], LoadStrikeReportData],
    ) -> "LoadStrikeContext":
        if not callable(report_finalizer):
            raise ValueError("Report finalizer must be provided.")
        return self._clone_with(ReportFinalizer=_build_report_finalizer_adapter(report_finalizer))

    def with_detailed_report_finalizer(
        self,
        report_finalizer: Callable[[LoadStrikeNodeStats], LoadStrikeNodeStats | Dict[str, Any]],
    ) -> "LoadStrikeContext":
        if not callable(report_finalizer):
            raise ValueError("Detailed report finalizer must be provided.")
        return self._clone_with(ReportFinalizer=_build_detailed_report_finalizer_adapter(report_finalizer))

    def with_reporting_interval(self, interval_seconds: float) -> "LoadStrikeContext":
        if interval_seconds <= 0:
            raise ValueError("Reporting interval should be greater than zero.")
        return self._clone_with(ReportingIntervalSeconds=float(interval_seconds))

    def with_reporting_sinks(self, *reporting_sinks: Any) -> "LoadStrikeContext":
        if not reporting_sinks:
            raise ValueError("At least one reporting sink should be provided.")
        if any(sink is None for sink in reporting_sinks):
            raise ValueError("Reporting sink collection cannot contain null values.")
        return self._clone_with(ReportingSinks=list(reporting_sinks))

    def with_worker_plugins(self, *plugins: Any) -> "LoadStrikeContext":
        if not plugins:
            raise ValueError("At least one worker plugin should be provided.")
        if any(plugin is None for plugin in plugins):
            raise ValueError("Worker plugin collection cannot contain null values.")
        return self._clone_with(WorkerPlugins=list(plugins))

    def with_minimum_log_level(self, minimum_log_level: str | LoadStrikeLogLevel) -> "LoadStrikeContext":
        return self._clone_with(
            MinimumLogLevel=_require_string_or_enum_value(
                minimum_log_level,
                "Minimum log level must be provided.",
            )
        )

    def with_logger_config(self, logger_config: Callable[[], Any]) -> "LoadStrikeContext":
        if not callable(logger_config):
            raise ValueError("Logger config must be provided.")
        return self._clone_with(LoggerConfig=logger_config)

    def without_reports(self) -> "LoadStrikeContext":
        return self._clone_with(ReportsEnabled=False)

    def with_report_file_name(self, report_file_name: str) -> "LoadStrikeContext":
        return self._clone_with(
            ReportFileName=_require_non_empty(report_file_name, "Report file name must be provided.")
        )

    def with_report_folder(self, report_folder_path: str) -> "LoadStrikeContext":
        return self._clone_with(
            ReportFolderPath=_require_non_empty(report_folder_path, "Report folder path must be provided.")
        )

    def with_report_formats(self, *report_formats: str) -> "LoadStrikeContext":
        return self._clone_with(ReportFormats=_normalize_report_formats_value(report_formats))

    def with_scenario_completion_timeout(self, timeout_seconds: float) -> "LoadStrikeContext":
        if timeout_seconds <= 0:
            raise ValueError("Scenario completion timeout should be greater than zero.")
        return self._clone_with(ScenarioCompletionTimeoutSeconds=float(timeout_seconds))

    def with_cluster_command_timeout(self, timeout_seconds: float) -> "LoadStrikeContext":
        if timeout_seconds <= 0:
            raise ValueError("Cluster command timeout should be greater than zero.")
        return self._clone_with(ClusterCommandTimeoutSeconds=float(timeout_seconds))

    def with_restart_iteration_max_attempts(self, attempts: int) -> "LoadStrikeContext":
        if attempts < 0:
            raise ValueError("Restart iteration max attempts should be zero or greater.")
        return self._clone_with(RestartIterationMaxAttempts=int(attempts))

    def with_session_id(self, session_id: str) -> "LoadStrikeContext":
        return self._clone_with(SessionId=_require_non_empty(session_id, "Session id must be provided."))

    def with_test_name(self, test_name: str) -> "LoadStrikeContext":
        return self._clone_with(TestName=_require_non_empty(test_name, "Test name must be provided."))

    def with_test_suite(self, test_suite: str) -> "LoadStrikeContext":
        return self._clone_with(TestSuite=_require_non_empty(test_suite, "Test suite must be provided."))

    def with_cluster_id(self, cluster_id: str) -> "LoadStrikeContext":
        return self._clone_with(ClusterId=_require_non_empty(cluster_id, "Cluster id must be provided."))

    # .NET-style aliases
    DisplayConsoleMetrics = display_console_metrics
    EnableLocalDevCluster = enable_local_dev_cluster
    LoadConfig = load_config
    LoadInfraConfig = load_infra_config
    WithRunnerKey = with_runner_key
    WithLicenseValidationServerUrl = with_license_validation_server_url
    WithLicenseValidationTimeout = with_license_validation_timeout
    WithNodeType = with_node_type
    WithNatsServerUrl = with_nats_server_url
    WithAgentsCount = with_agents_count
    WithAgentGroup = with_agent_group
    WithTargetScenarios = with_target_scenarios
    WithAgentTargetScenarios = with_agent_target_scenarios
    WithCoordinatorTargetScenarios = with_coordinator_target_scenarios
    WithReportFinalizer = with_report_finalizer
    WithDetailedReportFinalizer = with_detailed_report_finalizer
    WithReportingInterval = with_reporting_interval
    WithReportingSinks = with_reporting_sinks
    WithWorkerPlugins = with_worker_plugins
    WithMinimumLogLevel = with_minimum_log_level
    WithLoggerConfig = with_logger_config
    WithoutReports = without_reports
    WithReportFileName = with_report_file_name
    WithReportFolder = with_report_folder
    WithReportFormats = with_report_formats
    WithScenarioCompletionTimeout = with_scenario_completion_timeout
    WithClusterCommandTimeout = with_cluster_command_timeout
    WithRestartIterationMaxAttempts = with_restart_iteration_max_attempts
    WithSessionId = with_session_id
    WithTestName = with_test_name
    WithTestSuite = with_test_suite
    WithClusterId = with_cluster_id
    Create = create
    Run = run
    RunDetailed = run_detailed

    def _clone_with(self, **patch: Any) -> "LoadStrikeContext":
        self._values.update(patch)
        return self


class LoadStrikeScenarioContext:
    def __init__(
        self,
        scenario_name: str,
        record_step: Callable[[str, LoadStrikeStepReply, float], None],
        runtime_policies: Optional[List[LoadStrikeRuntimePolicy]] = None,
        *,
        invocation_number: int = 0,
        logger: Any = None,
        node_info: Optional[Dict[str, Any] | LoadStrikeNodeInfo] = None,
        test_info: Optional[Dict[str, Any] | LoadStrikeTestInfo] = None,
        scenario_info: Optional[Dict[str, Any] | LoadStrikeScenarioInfo] = None,
        scenario_timer_start_ms: Optional[int] = None,
        cancellation_event: Optional[Event] = None,
        test_cancellation_event: Optional[Event] = None,
        allow_policy_callbacks: bool = True,
    ):
        self.scenario_name = scenario_name
        self.data: Dict[str, Any] = {}
        self.scenario_instance_data: Dict[str, Any] = {}
        self.invocation_number = invocation_number
        self.logger = logger or _create_logger()
        self.node_info = node_info if isinstance(node_info, LoadStrikeNodeInfo) else LoadStrikeNodeInfo(node_info)
        self.test_info = test_info if isinstance(test_info, LoadStrikeTestInfo) else LoadStrikeTestInfo(test_info)
        self.scenario_info = (
            scenario_info
            if isinstance(scenario_info, LoadStrikeScenarioInfo)
            else LoadStrikeScenarioInfo(scenario_info)
        )
        self.scenario_cancellation_token = cancellation_event or Event()
        self._test_cancellation_event = test_cancellation_event
        self._scenario_timer_start_ms = scenario_timer_start_ms or int(time.time() * 1000)
        self._record_step = record_step
        self._stop_scenario = False
        self._stop_test = False
        self._allow_policy_callbacks = allow_policy_callbacks
        self._runtime_policies = list(runtime_policies or [])
        self.random = random.Random()

    def stop_scenario(self, scenario_name_or_reason: str = "", reason: str = "") -> None:
        has_named_stop = bool(reason)
        if has_named_stop and scenario_name_or_reason and scenario_name_or_reason != self.scenario_name:
            return
        self._stop_scenario = True
        self.scenario_cancellation_token.set()

    def stop_current_test(self, _reason: str = "") -> None:
        self._stop_test = True
        self.scenario_cancellation_token.set()
        if self._test_cancellation_event is not None:
            self._test_cancellation_event.set()

    def get_scenario_timer_time(self) -> int:
        return max(int(time.time() * 1000) - self._scenario_timer_start_ms, 0)

    ScenarioName = property(lambda self: self.scenario_name)
    Data = property(lambda self: self.data)
    ScenarioInstanceData = property(lambda self: self.scenario_instance_data)
    InvocationNumber = property(lambda self: self.invocation_number)
    Logger = property(lambda self: self.logger)
    NodeInfo = property(lambda self: self.node_info)
    Random = property(lambda self: self.random)
    TestInfo = property(lambda self: self.test_info)
    ScenarioInfo = property(lambda self: self.scenario_info)
    ScenarioCancellationToken = property(lambda self: self.scenario_cancellation_token)
    StopScenario = stop_scenario
    StopCurrentTest = stop_current_test
    GetScenarioTimerTime = get_scenario_timer_time

    def _invoke_before_step(self, step_name: str) -> None:
        if not self._allow_policy_callbacks:
            return
        for policy in self._runtime_policies:
            callback = getattr(policy, "before_step", None)
            if callable(callback):
                _invoke_maybe_async(callback, self.scenario_name, step_name)

    def _invoke_after_step(self, step_name: str, reply: LoadStrikeStepReply) -> None:
        if not self._allow_policy_callbacks:
            return
        for policy in self._runtime_policies:
            callback = getattr(policy, "after_step", None)
            if callable(callback):
                _invoke_maybe_async(callback, self.scenario_name, step_name, reply)


class LoadStrikeStep:
    @staticmethod
    def run(
        step_name: str,
        context: LoadStrikeScenarioContext,
        run: Callable[[], LoadStrikeReply],
    ) -> LoadStrikeReply:
        if not str(step_name or "").strip():
            raise ValueError("Step name must be provided.")
        if context is None:
            raise ValueError("context must be provided.")
        if not callable(run):
            raise ValueError("run must be provided.")

        context._invoke_before_step(step_name)
        started_at = time.perf_counter()
        try:
            reply = _invoke_maybe_async(run)
            if not isinstance(reply, LoadStrikeReply):
                raise TypeError("Step callback must return LoadStrikeReply.")
        except Exception as error:  # noqa: BLE001
            reply = LoadStrikeResponse.fail(status_code="step_exception", message=str(error))
        elapsed_ms = max((time.perf_counter() - started_at) * 1000.0, 0.0)

        context._record_step(step_name, reply, elapsed_ms)
        context._invoke_after_step(step_name, reply)
        return reply

    Run = run


class LoadStrikeSimulation:
    @staticmethod
    def inject(rate: int, interval_seconds: float, during_seconds: float) -> Dict[str, Any]:
        return {
            "Kind": "Inject",
            "Rate": rate,
            "IntervalSeconds": interval_seconds,
            "DuringSeconds": during_seconds,
        }

    @staticmethod
    def iterations_for_constant(copies: int, iterations: int) -> Dict[str, Any]:
        return {
            "Kind": "IterationsForConstant",
            "Copies": copies,
            "Iterations": iterations,
        }

    @staticmethod
    def iterations_for_inject(rate: int, iterations: int) -> Dict[str, Any]:
        return {
            "Kind": "IterationsForInject",
            "Rate": rate,
            "Iterations": iterations,
        }

    @staticmethod
    def keep_constant(copies: int, during_seconds: float) -> Dict[str, Any]:
        return {
            "Kind": "KeepConstant",
            "Copies": copies,
            "DuringSeconds": during_seconds,
        }

    @staticmethod
    def inject_random(
        min_rate: int,
        max_rate: int,
        interval_seconds: float,
        during_seconds: float,
    ) -> Dict[str, Any]:
        return {
            "Kind": "InjectRandom",
            "MinRate": min_rate,
            "MaxRate": max_rate,
            "IntervalSeconds": interval_seconds,
            "DuringSeconds": during_seconds,
        }

    @staticmethod
    def ramping_inject(rate: int, interval_seconds: float, during_seconds: float) -> Dict[str, Any]:
        return {
            "Kind": "RampingInject",
            "Rate": rate,
            "IntervalSeconds": interval_seconds,
            "DuringSeconds": during_seconds,
        }

    @staticmethod
    def ramping_constant(copies: int, during_seconds: float) -> Dict[str, Any]:
        return {
            "Kind": "RampingConstant",
            "Copies": copies,
            "DuringSeconds": during_seconds,
        }

    @staticmethod
    def pause(during_seconds: float) -> Dict[str, Any]:
        return {
            "Kind": "Pause",
            "DuringSeconds": during_seconds,
        }

    Inject = inject
    IterationsForConstant = iterations_for_constant
    IterationsForInject = iterations_for_inject
    KeepConstant = keep_constant
    InjectRandom = inject_random
    RampingInject = ramping_inject
    RampingConstant = ramping_constant
    Pause = pause


class LoadStrikeCounter:
    def __init__(self, name: str, unit_of_measure: Any = "", *, initial_value: float = 0) -> None:
        self.name = _require_non_empty(name, "Metric name is required.")
        self.type = "counter"
        if isinstance(unit_of_measure, (int, float)) and not isinstance(unit_of_measure, bool):
            initial_value = float(unit_of_measure)
            unit_of_measure = ""
        self.unit_of_measure = str(unit_of_measure or "").strip()
        self.scenario_name = ""
        self._value = float(initial_value)

    def add(self, value: float) -> float:
        self._value += float(value)
        return self._value

    def increment(self, by: float = 1) -> float:
        return self.add(by)

    def value(self) -> float:
        return self._value

    Add = add
    Increment = increment
    Value = property(lambda self: self.value())
    UnitOfMeasure = property(lambda self: self.unit_of_measure)
    ScenarioName = property(lambda self: self.scenario_name)


class LoadStrikeGauge:
    def __init__(self, name: str, unit_of_measure: Any = "", *, initial_value: float = 0) -> None:
        self.name = _require_non_empty(name, "Metric name is required.")
        self.type = "gauge"
        if isinstance(unit_of_measure, (int, float)) and not isinstance(unit_of_measure, bool):
            initial_value = float(unit_of_measure)
            unit_of_measure = ""
        self.unit_of_measure = str(unit_of_measure or "").strip()
        self.scenario_name = ""
        self._value = float(initial_value)

    def set(self, value: float) -> float:
        self._value = float(value)
        return self._value

    def add(self, value: float) -> float:
        self._value += float(value)
        return self._value

    def increment(self, by: float = 1) -> float:
        return self.add(by)

    def decrement(self, by: float = 1) -> float:
        return self.add(-float(by))

    def value(self) -> float:
        return self._value

    Set = set
    Add = add
    Increment = increment
    Decrement = decrement
    Value = property(lambda self: self.value())
    UnitOfMeasure = property(lambda self: self.unit_of_measure)
    ScenarioName = property(lambda self: self.scenario_name)


class LoadStrikeMetric:
    @staticmethod
    def counter(name: str, unit_of_measure: Any = "", *, initial_value: float = 0) -> LoadStrikeCounter:
        return LoadStrikeCounter(name, unit_of_measure, initial_value=initial_value)

    @staticmethod
    def gauge(name: str, unit_of_measure: Any = "", *, initial_value: float = 0) -> LoadStrikeGauge:
        return LoadStrikeGauge(name, unit_of_measure, initial_value=initial_value)

    Counter = counter
    Gauge = gauge
    CreateCounter = counter
    CreateGauge = gauge


class LoadStrikeThreshold:
    @staticmethod
    def create_scenario(
        check_scenario: Callable[[LoadStrikeScenarioStats], bool],
        abort_when_error_count: Optional[int] = None,
        start_check_after_seconds: Optional[float] = None,
    ) -> Dict[str, Any]:
        if not callable(check_scenario):
            raise ValueError("check_scenario must be provided.")
        return {
            "Scope": "Scenario",
            "Predicate": check_scenario,
            "TypedStatsFactory": "scenario",
            "AbortWhenErrorCount": abort_when_error_count,
            "StartCheckAfterSeconds": start_check_after_seconds,
        }

    @staticmethod
    def create_step(
        step_name: str,
        check_step: Callable[[LoadStrikeStepStats], bool],
        abort_when_error_count: Optional[int] = None,
        start_check_after_seconds: Optional[float] = None,
    ) -> Dict[str, Any]:
        if not callable(check_step):
            raise ValueError("check_step must be provided.")
        return {
            "Scope": "Step",
            "StepName": _require_non_empty(step_name, "Step name must be provided."),
            "Predicate": check_step,
            "TypedStatsFactory": "step",
            "AbortWhenErrorCount": abort_when_error_count,
            "StartCheckAfterSeconds": start_check_after_seconds,
        }

    @staticmethod
    def create_metric(
        check_metric: Callable[[LoadStrikeMetricStats], bool],
        abort_when_error_count: Optional[int] = None,
        start_check_after_seconds: Optional[float] = None,
    ) -> Dict[str, Any]:
        if not callable(check_metric):
            raise ValueError("check_metric must be provided.")
        return {
            "Scope": "Metric",
            "Predicate": check_metric,
            "TypedStatsFactory": "metric",
            "AbortWhenErrorCount": abort_when_error_count,
            "StartCheckAfterSeconds": start_check_after_seconds,
        }

    @staticmethod
    def scenario(
        field: str,
        operator: str,
        value: float,
        *,
        abort_when_error_count: Optional[int] = None,
        start_check_after_seconds: Optional[float] = None,
    ) -> Dict[str, Any]:
        return {
            "Scope": "Scenario",
            "Field": field,
            "Operator": operator,
            "Value": value,
            "AbortWhenErrorCount": abort_when_error_count,
            "StartCheckAfterSeconds": start_check_after_seconds,
        }

    @staticmethod
    def step(
        step_name: str,
        field: str,
        operator: str,
        value: float,
        *,
        abort_when_error_count: Optional[int] = None,
        start_check_after_seconds: Optional[float] = None,
    ) -> Dict[str, Any]:
        return {
            "Scope": "Step",
            "StepName": _require_non_empty(step_name, "Step name must be provided."),
            "Field": field,
            "Operator": operator,
            "Value": value,
            "AbortWhenErrorCount": abort_when_error_count,
            "StartCheckAfterSeconds": start_check_after_seconds,
        }

    @staticmethod
    def metric(
        field: str,
        operator: str,
        value: float,
        *,
        abort_when_error_count: Optional[int] = None,
        start_check_after_seconds: Optional[float] = None,
    ) -> Dict[str, Any]:
        return {
            "Scope": "Metric",
            "Field": field,
            "Operator": operator,
            "Value": value,
            "AbortWhenErrorCount": abort_when_error_count,
            "StartCheckAfterSeconds": start_check_after_seconds,
        }

    @staticmethod
    def scenario_predicate(
        check_expression: str,
        predicate: Callable[[Dict[str, Any]], bool],
        *,
        abort_when_error_count: Optional[int] = None,
        start_check_after_seconds: Optional[float] = None,
    ) -> Dict[str, Any]:
        if not callable(predicate):
            raise ValueError("predicate must be provided.")
        return {
            "Scope": "Scenario",
            "CheckExpression": _require_non_empty(check_expression, "check_expression is required."),
            "Predicate": predicate,
            "AbortWhenErrorCount": abort_when_error_count,
            "StartCheckAfterSeconds": start_check_after_seconds,
        }

    @staticmethod
    def step_predicate(
        step_name: str,
        check_expression: str,
        predicate: Callable[[Dict[str, Any]], bool],
        *,
        abort_when_error_count: Optional[int] = None,
        start_check_after_seconds: Optional[float] = None,
    ) -> Dict[str, Any]:
        if not callable(predicate):
            raise ValueError("predicate must be provided.")
        return {
            "Scope": "Step",
            "StepName": _require_non_empty(step_name, "Step name must be provided."),
            "CheckExpression": _require_non_empty(check_expression, "check_expression is required."),
            "Predicate": predicate,
            "AbortWhenErrorCount": abort_when_error_count,
            "StartCheckAfterSeconds": start_check_after_seconds,
        }

    @staticmethod
    def metric_predicate(
        check_expression: str,
        predicate: Callable[[Dict[str, Any]], bool],
        *,
        abort_when_error_count: Optional[int] = None,
        start_check_after_seconds: Optional[float] = None,
    ) -> Dict[str, Any]:
        if not callable(predicate):
            raise ValueError("predicate must be provided.")
        return {
            "Scope": "Metric",
            "CheckExpression": _require_non_empty(check_expression, "check_expression is required."),
            "Predicate": predicate,
            "AbortWhenErrorCount": abort_when_error_count,
            "StartCheckAfterSeconds": start_check_after_seconds,
        }

    Scenario = scenario
    Step = step
    Metric = metric
    CreateScenario = create_scenario
    CreateStep = create_step
    CreateMetric = create_metric
    ScenarioPredicate = scenario_predicate
    StepPredicate = step_predicate
    MetricPredicate = metric_predicate


class LoadStrikeScenario:
    def __init__(
        self,
        name: str,
        run: Optional[Callable[[LoadStrikeScenarioContext], LoadStrikeReply]] = None,
        init: Optional[Callable[[LoadStrikeScenarioInitContext], None]] = None,
        clean: Optional[Callable[[LoadStrikeScenarioInitContext], None]] = None,
        load_simulations: Optional[List[Dict[str, Any]]] = None,
        thresholds: Optional[List[Dict[str, Any]]] = None,
        cross_platform_tracking: Optional[Dict[str, Any]] = None,
        max_fail_count: int = 0,
        without_warm_up: bool = False,
        warm_up_duration_seconds: float = 0.0,
        weight: int = 1,
        restart_iteration_on_fail: bool = False,
        license_features: Optional[List[str]] = None,
    ) -> None:
        self.name = name
        self._run = run
        self._init = init
        self._clean = clean
        self._load_simulations = load_simulations or []
        self._thresholds = thresholds or []
        self._cross_platform_tracking = (
            dict(cross_platform_tracking)
            if isinstance(cross_platform_tracking, dict)
            else None
        )
        self._max_fail_count = max(0, int(max_fail_count))
        self._without_warm_up = bool(without_warm_up)
        self._warm_up_duration_seconds = max(float(warm_up_duration_seconds), 0.0)
        self._weight = max(int(weight), 1)
        self._restart_iteration_on_fail = bool(restart_iteration_on_fail)
        self._license_features = [
            str(value).strip()
            for value in list(license_features or [])
            if str(value).strip()
        ]

    @staticmethod
    def create(
        name: str,
        run: Callable[[LoadStrikeScenarioContext], LoadStrikeReply],
    ) -> "LoadStrikeScenario":
        if not name.strip():
            raise ValueError("Scenario name must be provided.")
        if not callable(run):
            raise ValueError("Scenario callback must be provided.")
        return LoadStrikeScenario(name=name, run=run)

    @staticmethod
    def empty(name: str) -> "LoadStrikeScenario":
        if not name.strip():
            raise ValueError("Scenario name must be provided.")
        return LoadStrikeScenario(name=name, run=None)

    def with_init(self, init: Callable[[LoadStrikeScenarioInitContext], None]) -> "LoadStrikeScenario":
        if not callable(init):
            raise ValueError("Init handler must be provided.")
        return LoadStrikeScenario(
            name=self.name,
            run=self._run,
            init=init,
            clean=self._clean,
            load_simulations=self._load_simulations,
            thresholds=self._thresholds,
            cross_platform_tracking=self._cross_platform_tracking,
            max_fail_count=self._max_fail_count,
            without_warm_up=self._without_warm_up,
            warm_up_duration_seconds=self._warm_up_duration_seconds,
            weight=self._weight,
            restart_iteration_on_fail=self._restart_iteration_on_fail,
            license_features=self._license_features,
        )

    def with_clean(self, clean: Callable[[LoadStrikeScenarioInitContext], None]) -> "LoadStrikeScenario":
        if not callable(clean):
            raise ValueError("Clean handler must be provided.")
        return LoadStrikeScenario(
            name=self.name,
            run=self._run,
            init=self._init,
            clean=clean,
            load_simulations=self._load_simulations,
            thresholds=self._thresholds,
            cross_platform_tracking=self._cross_platform_tracking,
            max_fail_count=self._max_fail_count,
            without_warm_up=self._without_warm_up,
            warm_up_duration_seconds=self._warm_up_duration_seconds,
            weight=self._weight,
            restart_iteration_on_fail=self._restart_iteration_on_fail,
            license_features=self._license_features,
        )

    def with_max_fail_count(self, max_fail_count: int) -> "LoadStrikeScenario":
        if max_fail_count < 0:
            raise ValueError("max_fail_count should be zero or greater.")
        return LoadStrikeScenario(
            name=self.name,
            run=self._run,
            init=self._init,
            clean=self._clean,
            load_simulations=self._load_simulations,
            thresholds=self._thresholds,
            cross_platform_tracking=self._cross_platform_tracking,
            max_fail_count=max_fail_count,
            without_warm_up=self._without_warm_up,
            warm_up_duration_seconds=self._warm_up_duration_seconds,
            weight=self._weight,
            restart_iteration_on_fail=self._restart_iteration_on_fail,
            license_features=self._license_features,
        )

    def without_warm_up(self) -> "LoadStrikeScenario":
        return LoadStrikeScenario(
            name=self.name,
            run=self._run,
            init=self._init,
            clean=self._clean,
            load_simulations=self._load_simulations,
            thresholds=self._thresholds,
            cross_platform_tracking=self._cross_platform_tracking,
            max_fail_count=self._max_fail_count,
            without_warm_up=True,
            warm_up_duration_seconds=self._warm_up_duration_seconds,
            weight=self._weight,
            restart_iteration_on_fail=self._restart_iteration_on_fail,
            license_features=self._license_features,
        )

    def with_warm_up_duration(self, duration_seconds: float) -> "LoadStrikeScenario":
        if duration_seconds <= 0:
            raise ValueError("Warmup duration should be greater than zero.")
        return LoadStrikeScenario(
            name=self.name,
            run=self._run,
            init=self._init,
            clean=self._clean,
            load_simulations=self._load_simulations,
            thresholds=self._thresholds,
            cross_platform_tracking=self._cross_platform_tracking,
            max_fail_count=self._max_fail_count,
            without_warm_up=self._without_warm_up,
            warm_up_duration_seconds=duration_seconds,
            weight=self._weight,
            restart_iteration_on_fail=self._restart_iteration_on_fail,
            license_features=self._license_features,
        )

    def with_weight(self, weight: int) -> "LoadStrikeScenario":
        if weight <= 0:
            raise ValueError("Weight should be greater than zero.")
        return LoadStrikeScenario(
            name=self.name,
            run=self._run,
            init=self._init,
            clean=self._clean,
            load_simulations=self._load_simulations,
            thresholds=self._thresholds,
            cross_platform_tracking=self._cross_platform_tracking,
            max_fail_count=self._max_fail_count,
            without_warm_up=self._without_warm_up,
            warm_up_duration_seconds=self._warm_up_duration_seconds,
            weight=weight,
            restart_iteration_on_fail=self._restart_iteration_on_fail,
            license_features=self._license_features,
        )

    def with_restart_iteration_on_fail(self, should_restart: bool) -> "LoadStrikeScenario":
        return LoadStrikeScenario(
            name=self.name,
            run=self._run,
            init=self._init,
            clean=self._clean,
            load_simulations=self._load_simulations,
            thresholds=self._thresholds,
            cross_platform_tracking=self._cross_platform_tracking,
            max_fail_count=self._max_fail_count,
            without_warm_up=self._without_warm_up,
            warm_up_duration_seconds=self._warm_up_duration_seconds,
            weight=self._weight,
            restart_iteration_on_fail=bool(should_restart),
            license_features=self._license_features,
        )

    def with_cross_platform_tracking(self, tracking: Dict[str, Any]) -> "LoadStrikeScenario":
        validated_tracking = _validate_cross_platform_tracking_configuration(tracking)
        return LoadStrikeScenario(
            name=self.name,
            run=self._run,
            init=self._init,
            clean=self._clean,
            load_simulations=self._load_simulations,
            thresholds=self._thresholds,
            cross_platform_tracking=validated_tracking,
            max_fail_count=self._max_fail_count,
            without_warm_up=self._without_warm_up,
            warm_up_duration_seconds=self._warm_up_duration_seconds,
            weight=self._weight,
            restart_iteration_on_fail=self._restart_iteration_on_fail,
            license_features=self._license_features,
        )

    def with_load_simulations(self, *simulations: Dict[str, Any]) -> "LoadStrikeScenario":
        if not simulations:
            raise ValueError("At least one load simulation should be provided.")
        return LoadStrikeScenario(
            name=self.name,
            run=self._run,
            init=self._init,
            clean=self._clean,
            load_simulations=list(simulations),
            thresholds=self._thresholds,
            cross_platform_tracking=self._cross_platform_tracking,
            max_fail_count=self._max_fail_count,
            without_warm_up=self._without_warm_up,
            warm_up_duration_seconds=self._warm_up_duration_seconds,
            weight=self._weight,
            restart_iteration_on_fail=self._restart_iteration_on_fail,
            license_features=self._license_features,
        )

    def with_thresholds(self, *thresholds: Dict[str, Any]) -> "LoadStrikeScenario":
        if not thresholds:
            raise ValueError("At least one threshold should be provided.")
        return LoadStrikeScenario(
            name=self.name,
            run=self._run,
            init=self._init,
            clean=self._clean,
            load_simulations=self._load_simulations,
            thresholds=list(thresholds),
            cross_platform_tracking=self._cross_platform_tracking,
            max_fail_count=self._max_fail_count,
            without_warm_up=self._without_warm_up,
            warm_up_duration_seconds=self._warm_up_duration_seconds,
            weight=self._weight,
            restart_iteration_on_fail=self._restart_iteration_on_fail,
            license_features=self._license_features,
        )

    def with_license_features(self, *features: str) -> "LoadStrikeScenario":
        normalized = [
            str(value).strip()
            for value in features
            if isinstance(value, str) and value.strip()
        ]
        return LoadStrikeScenario(
            name=self.name,
            run=self._run,
            init=self._init,
            clean=self._clean,
            load_simulations=self._load_simulations,
            thresholds=self._thresholds,
            cross_platform_tracking=self._cross_platform_tracking,
            max_fail_count=self._max_fail_count,
            without_warm_up=self._without_warm_up,
            warm_up_duration_seconds=self._warm_up_duration_seconds,
            weight=self._weight,
            restart_iteration_on_fail=self._restart_iteration_on_fail,
            license_features=self._license_features + normalized,
        )

    @property
    def load_simulations(self) -> List[Dict[str, Any]]:
        return self._load_simulations

    @property
    def thresholds(self) -> List[Dict[str, Any]]:
        return self._thresholds

    @property
    def cross_platform_tracking(self) -> Optional[Dict[str, Any]]:
        return dict(self._cross_platform_tracking) if self._cross_platform_tracking else None

    @property
    def max_fail_count(self) -> int:
        return self._max_fail_count

    @property
    def without_warm_up_enabled(self) -> bool:
        return self._without_warm_up

    @property
    def warm_up_duration_seconds(self) -> float:
        return self._warm_up_duration_seconds

    @property
    def weight(self) -> int:
        return self._weight

    @property
    def restart_iteration_on_fail(self) -> bool:
        return self._restart_iteration_on_fail

    @property
    def license_features(self) -> List[str]:
        return list(self._license_features)

    def invoke_init(self, context: LoadStrikeScenarioInitContext) -> None:
        if callable(self._init):
            _invoke_maybe_async(self._init, context)

    def invoke_clean(self, context: LoadStrikeScenarioInitContext) -> None:
        if callable(self._clean):
            _invoke_maybe_async(self._clean, context)

    # .NET-style aliases
    WithInit = with_init
    WithClean = with_clean
    WithMaxFailCount = with_max_fail_count
    WithoutWarmUp = without_warm_up
    WithWarmUpDuration = with_warm_up_duration
    WithWeight = with_weight
    WithRestartIterationOnFail = with_restart_iteration_on_fail
    WithLicenseFeatures = with_license_features
    WithCrossPlatformTracking = with_cross_platform_tracking
    WithLoadSimulations = with_load_simulations
    WithThresholds = with_thresholds
    Create = create
    Empty = empty

    def execute(self, context: LoadStrikeScenarioContext) -> LoadStrikeStepReply:
        if not callable(self._run):
            return LoadStrikeResponse.ok()
        try:
            reply = _invoke_maybe_async(self._run, context)
            if reply is None:
                return LoadStrikeResponse.fail(
                    status_code="null_response",
                    message="Scenario run returned null response.",
                )
            if not isinstance(reply, LoadStrikeReply):
                raise TypeError("Scenario callback must return LoadStrikeReply.")
            return reply
        except Exception as error:  # noqa: BLE001
            return LoadStrikeResponse.fail(status_code="exception", message=str(error))


class CrossPlatformScenarioConfigurator:
    @staticmethod
    def configure(scenario: "LoadStrikeScenario", configuration: Dict[str, Any]) -> "LoadStrikeScenario":
        if not isinstance(scenario, LoadStrikeScenario):
            raise TypeError("Scenario must be provided.")
        return scenario.with_cross_platform_tracking(configuration)

    Configure = configure


class ScenarioTrackingExtensions:
    @staticmethod
    def configure_cross_platform_tracking(
        scenario: "LoadStrikeScenario",
        configuration: Dict[str, Any],
    ) -> "LoadStrikeScenario":
        return CrossPlatformScenarioConfigurator.configure(scenario, configuration)

    @staticmethod
    def with_cross_platform_tracking(
        scenario: "LoadStrikeScenario",
        configuration: Dict[str, Any],
    ) -> "LoadStrikeScenario":
        if not isinstance(scenario, LoadStrikeScenario):
            raise TypeError("Scenario must be provided.")
        return scenario.with_cross_platform_tracking(configuration)

    ConfigureCrossPlatformTracking = configure_cross_platform_tracking
    WithCrossPlatformTracking = with_cross_platform_tracking


class LoadStrikeRunner:
    def __init__(
        self,
        scenarios: List[LoadStrikeScenario],
        options: Optional[Dict[str, Any]] = None,
    ) -> None:
        self._scenarios = list(scenarios)
        self._options = dict(options or {})
        _reject_disable_license_enforcement_option(self._options, "LoadStrikeRunner")
        if "report_formats" in self._options and self._options.get("report_formats") is not None:
            self._options["report_formats"] = _normalize_report_formats_value(self._options.get("report_formats"))

    @staticmethod
    def create() -> "LoadStrikeRunner":
        return LoadStrikeRunner([], {})

    @staticmethod
    def register_scenarios(*scenarios: LoadStrikeScenario) -> "LoadStrikeRunner":
        if not scenarios:
            raise ValueError("At least one scenario must be provided.")
        if any(scenario is None for scenario in scenarios):
            raise ValueError("Scenario collection cannot contain null values.")
        return LoadStrikeRunner(list(scenarios), {})

    @staticmethod
    def RegisterScenarios(*scenarios: LoadStrikeScenario) -> LoadStrikeContext:
        return LoadStrikeRunner.create().add_scenarios(*scenarios).build_context()

    def add_scenario(self, scenario: LoadStrikeScenario) -> "LoadStrikeRunner":
        if scenario is None:
            raise ValueError("Scenario must be provided.")
        self._scenarios.append(scenario)
        return self

    def add_scenarios(self, *scenarios: LoadStrikeScenario) -> "LoadStrikeRunner":
        if not scenarios:
            raise ValueError("At least one scenario must be provided.")
        if any(scenario is None for scenario in scenarios):
            raise ValueError("Scenario collection cannot contain null values.")
        self._scenarios.extend(list(scenarios))
        return self

    def configure(self, *configurators: Any, **options: Any) -> "LoadStrikeRunner":
        merged = dict(self._options)
        _reject_disable_license_enforcement_option(options, "LoadStrikeRunner.configure")
        merged.update(options)
        if "report_formats" in merged and merged.get("report_formats") is not None:
            merged["report_formats"] = _normalize_report_formats_value(merged.get("report_formats"))
        merged = _normalize_runner_option_finalizers(merged)
        configured_scenarios = list(self._scenarios)
        for configurator in configurators:
            if isinstance(configurator, LoadStrikeContext):
                resolved = configurator
                merged.update(resolved.to_runner_options())
                merged = _normalize_runner_option_finalizers(merged)
                if resolved._scenarios:
                    configured_scenarios = list(resolved._scenarios)
                continue
            if isinstance(configurator, dict):
                resolved = LoadStrikeContext(configurator)
                merged.update(resolved.to_runner_options())
                merged = _normalize_runner_option_finalizers(merged)
                continue
            if callable(configurator):
                resolved = configurator(
                    LoadStrikeContext(
                        values=_runner_options_to_context_values(merged),
                        scenarios=configured_scenarios,
                    )
                )
                if not isinstance(resolved, LoadStrikeContext):
                    raise ValueError("Configure function must return LoadStrikeContext.")
                merged.update(resolved.to_runner_options())
                merged = _normalize_runner_option_finalizers(merged)
                if resolved._scenarios:
                    configured_scenarios = list(resolved._scenarios)
                continue
            raise ValueError("Configure accepts a context, dictionary, or callable.")
        self._scenarios = configured_scenarios
        self._options = merged
        return self

    def configure_context(self, context: LoadStrikeContext | Dict[str, Any]) -> "LoadStrikeRunner":
        resolved = context if isinstance(context, LoadStrikeContext) else LoadStrikeContext(context)
        return self.configure(resolved)

    def display_console_metrics(self, enable: bool) -> "LoadStrikeRunner":
        return self.configure(lambda context: context.display_console_metrics(enable))

    def enable_local_dev_cluster(self, enable: bool) -> "LoadStrikeRunner":
        return self.configure(lambda context: context.enable_local_dev_cluster(enable))

    def load_config(self, path: str) -> "LoadStrikeRunner":
        return self.configure(lambda context: context.load_config(path))

    def load_infra_config(self, path: str) -> "LoadStrikeRunner":
        return self.configure(lambda context: context.load_infra_config(path))

    def with_agent_group(self, agent_group: str) -> "LoadStrikeRunner":
        return self.configure(lambda context: context.with_agent_group(agent_group))

    def with_agents_count(self, agents_count: int) -> "LoadStrikeRunner":
        return self.configure(lambda context: context.with_agents_count(agents_count))

    def with_agent_target_scenarios(self, *scenario_names: str) -> "LoadStrikeRunner":
        return self.configure(lambda context: context.with_agent_target_scenarios(*scenario_names))

    def with_cluster_id(self, cluster_id: str) -> "LoadStrikeRunner":
        return self.configure(lambda context: context.with_cluster_id(cluster_id))

    def with_coordinator_target_scenarios(self, *scenario_names: str) -> "LoadStrikeRunner":
        return self.configure(lambda context: context.with_coordinator_target_scenarios(*scenario_names))

    def with_runner_key(self, runner_key: str) -> "LoadStrikeRunner":
        return self.configure(lambda context: context.with_runner_key(runner_key))

    def with_license_validation_server_url(self, server_url: str) -> "LoadStrikeRunner":
        return self.configure(lambda context: context.with_license_validation_server_url(server_url))

    def with_license_validation_timeout(self, timeout_seconds: float) -> "LoadStrikeRunner":
        return self.configure(lambda context: context.with_license_validation_timeout(timeout_seconds))

    def with_logger_config(self, logger_config: Callable[[], Any]) -> "LoadStrikeRunner":
        return self.configure(lambda context: context.with_logger_config(logger_config))

    def with_minimum_log_level(self, minimum_log_level: str | LoadStrikeLogLevel) -> "LoadStrikeRunner":
        return self.configure(lambda context: context.with_minimum_log_level(minimum_log_level))

    def with_nats_server_url(self, nats_url: str) -> "LoadStrikeRunner":
        return self.configure(lambda context: context.with_nats_server_url(nats_url))

    def with_node_type(self, node_type: str | LoadStrikeNodeType) -> "LoadStrikeRunner":
        return self.configure(lambda context: context.with_node_type(node_type))

    def with_test_suite(self, test_suite: str) -> "LoadStrikeRunner":
        return self.configure(lambda context: context.with_test_suite(test_suite))

    def with_test_name(self, test_name: str) -> "LoadStrikeRunner":
        return self.configure(lambda context: context.with_test_name(test_name))

    def with_session_id(self, session_id: str) -> "LoadStrikeRunner":
        return self.configure(lambda context: context.with_session_id(session_id))

    def with_report_folder(self, report_folder_path: str) -> "LoadStrikeRunner":
        return self.configure(lambda context: context.with_report_folder(report_folder_path))

    def with_report_file_name(self, report_file_name: str) -> "LoadStrikeRunner":
        return self.configure(lambda context: context.with_report_file_name(report_file_name))

    def with_report_formats(self, *report_formats: str | LoadStrikeReportFormat) -> "LoadStrikeRunner":
        return self.configure(lambda context: context.with_report_formats(*report_formats))

    def with_report_finalizer(
        self,
        report_finalizer: Callable[[LoadStrikeReportData], LoadStrikeReportData],
    ) -> "LoadStrikeRunner":
        return self.configure(lambda context: context.with_report_finalizer(report_finalizer))

    def with_detailed_report_finalizer(
        self,
        report_finalizer: Callable[[LoadStrikeNodeStats], LoadStrikeNodeStats | Dict[str, Any]],
    ) -> "LoadStrikeRunner":
        return self.configure(lambda context: context.with_detailed_report_finalizer(report_finalizer))

    def with_reporting_interval(self, interval_seconds: float) -> "LoadStrikeRunner":
        return self.configure(lambda context: context.with_reporting_interval(interval_seconds))

    def with_reporting_sinks(self, *reporting_sinks: Any) -> "LoadStrikeRunner":
        return self.configure(lambda context: context.with_reporting_sinks(*reporting_sinks))

    def with_worker_plugins(self, *plugins: Any) -> "LoadStrikeRunner":
        return self.configure(lambda context: context.with_worker_plugins(*plugins))

    def with_scenario_completion_timeout(self, timeout_seconds: float) -> "LoadStrikeRunner":
        return self.configure(lambda context: context.with_scenario_completion_timeout(timeout_seconds))

    def with_cluster_command_timeout(self, timeout_seconds: float) -> "LoadStrikeRunner":
        return self.configure(lambda context: context.with_cluster_command_timeout(timeout_seconds))

    def with_restart_iteration_max_attempts(self, attempts: int) -> "LoadStrikeRunner":
        return self.configure(lambda context: context.with_restart_iteration_max_attempts(attempts))

    def with_target_scenarios(self, *scenario_names: str) -> "LoadStrikeRunner":
        return self.configure(lambda context: context.with_target_scenarios(*scenario_names))

    def without_reports(self) -> "LoadStrikeRunner":
        return self.configure(lambda context: context.without_reports())

    def build_context(self) -> LoadStrikeContext:
        if not self._scenarios:
            raise LoadStrikeInvalidOperationError("At least one scenario must be added before building the runner context.")
        return LoadStrikeContext(
            values=_runner_options_to_context_values(self._options),
            scenarios=self._scenarios,
        )

    def run(self, *args: str) -> LoadStrikeNodeStats:
        return LoadStrikeNodeStats(self.run_detailed(*args))

    def run_detailed(self, *args: str) -> Dict[str, Any]:
        if not self._scenarios:
            raise LoadStrikeInvalidOperationError("At least one scenario must be added before building the runner context.")
        if args:
            return LoadStrikeRunner(self._scenarios, _apply_run_args(self._options, list(args)))._execute_detailed()
        return self._execute_detailed()

    Create = create
    AddScenario = add_scenario
    AddScenarios = add_scenarios
    Configure = configure
    DisplayConsoleMetrics = display_console_metrics
    EnableLocalDevCluster = enable_local_dev_cluster
    LoadConfig = load_config
    LoadInfraConfig = load_infra_config
    WithAgentGroup = with_agent_group
    WithAgentsCount = with_agents_count
    WithAgentTargetScenarios = with_agent_target_scenarios
    WithClusterId = with_cluster_id
    WithCoordinatorTargetScenarios = with_coordinator_target_scenarios
    WithRunnerKey = with_runner_key
    WithLicenseValidationServerUrl = with_license_validation_server_url
    WithLicenseValidationTimeout = with_license_validation_timeout
    WithLoggerConfig = with_logger_config
    WithMinimumLogLevel = with_minimum_log_level
    WithNatsServerUrl = with_nats_server_url
    WithNodeType = with_node_type
    WithTestSuite = with_test_suite
    WithTestName = with_test_name
    WithSessionId = with_session_id
    WithReportFileName = with_report_file_name
    WithReportFolder = with_report_folder
    WithReportFormats = with_report_formats
    WithReportFinalizer = with_report_finalizer
    WithDetailedReportFinalizer = with_detailed_report_finalizer
    WithReportingInterval = with_reporting_interval
    WithReportingSinks = with_reporting_sinks
    WithWorkerPlugins = with_worker_plugins
    WithScenarioCompletionTimeout = with_scenario_completion_timeout
    WithClusterCommandTimeout = with_cluster_command_timeout
    WithRestartIterationMaxAttempts = with_restart_iteration_max_attempts
    WithTargetScenarios = with_target_scenarios
    WithoutReports = without_reports
    BuildContext = build_context
    ConfigureContext = configure_context
    Run = run
    RunDetailed = run_detailed

    def _execute_detailed(self) -> Dict[str, Any]:
        execution_mode = self._resolve_execution_mode()
        if execution_mode == "local_dev_cluster":
            return self._execute_local_dev_cluster_detailed()
        if execution_mode == "distributed_coordinator":
            return self._execute_distributed_coordinator_detailed()
        if execution_mode == "distributed_agent":
            return self._execute_distributed_agent_detailed()
        return self._execute_local_detailed()

    def _execute_local_detailed(self) -> Dict[str, Any]:
        started_dt = datetime.now(timezone.utc)
        started = started_dt.isoformat()
        console_metrics_enabled = _as_bool(self._options.get("console_metrics_enabled"), True)
        reporting_interval_seconds = max(_as_float(self._options.get("reporting_interval_seconds", 5.0)), 0.001)
        runtime_policies = list(self._options.get("runtime_policies") or [])
        worker_plugins = _resolve_worker_plugins(
            list(self._options.get("worker_plugins") or []),
        )
        selected_scenarios = self._select_scenarios(runtime_policies)
        scenario_stats: Dict[str, Dict[str, Any]] = {
            scenario.name: _new_scenario_accumulator(scenario.name, index + 1)
            for index, scenario in enumerate(selected_scenarios)
        }
        scenario_durations_ms: Dict[str, int] = {scenario.name: 0 for scenario in selected_scenarios}
        registered_metrics: List[Any] = []
        registered_metrics_lock = threading.Lock()
        sinks = list(self._options.get("reporting_sinks") or [])
        _validate_reporting_sink_names(sinks)
        sink_states = [
            {"sink": sink, "disabled": False, "name": _resolve_sink_name(sink, index)}
            for index, sink in enumerate(sinks)
        ]
        sink_errors: List[Dict[str, Any]] = []
        sink_retry_count = max(int(self._options.get("sink_retry_count", 2)), 0)
        sink_retry_backoff_ms = max(int(self._options.get("sink_retry_backoff_ms", 25)), 0)
        restart_iteration_max_attempts = max(_as_int(self._options.get("restart_iteration_max_attempts", 3)), 0)
        created_utc = started
        test_info = _build_test_info(self._options, created_utc)
        node_info = _build_node_info(self._options)
        node_info["currentOperation"] = "Init"
        base_logger = _create_logger(
            self._options.get("logger_config"),
            self._options.get("minimum_log_level"),
        )
        base_context = LoadStrikeBaseContext(
            logger=base_logger,
            test_info=LoadStrikeTestInfo(test_info),
            node_info=LoadStrikeNodeInfo(node_info),
        )
        plugin_lifecycle_errors: Dict[str, List[str]] = {}
        plugins_stopped = False
        sinks_stopped = False
        stop_test = False
        stop_test_event = Event()
        license_client: Optional[LoadStrikeLocalClient] = None
        license_payload: Dict[str, Any] = {}
        license_session: Any = None
        realtime_stop_event = Event()
        realtime_thread: Optional[threading.Thread] = None
        realtime_emissions = {"count": 0}
        infra_config = dict(self._options.get("infra_config") or {})
        session_start_info = LoadStrikeSessionStartInfo(
            {
                "startedUtc": started,
                "scenarioNames": [scenario.name for scenario in selected_scenarios],
                "configPath": self._options.get("config_path"),
                "infraConfigPath": self._options.get("infra_config_path"),
                "infraConfig": dict(infra_config) or None,
                "scenarios": [
                    {"scenarioName": scenario.name, "sortIndex": index + 1}
                    for index, scenario in enumerate(selected_scenarios)
                ],
            }
        )

        license_payload = self._build_license_payload()
        license_client = LoadStrikeLocalClient(
            licensing_api_base_url=str(
                self._options.get("license_validation_server_url")
                or "https://licensing.loadstrike.com"
            ),
            license_validation_timeout_seconds=max(
                _as_float(self._options.get("license_validation_timeout_seconds")), 10.0
            ),
        )
        license_session = license_client._validate_license_if_required(license_payload)

        self._emit_sink_lifecycle(
            sink_states=sink_states,
            phase="init",
            sink_retry_count=sink_retry_count,
            sink_retry_backoff_ms=sink_retry_backoff_ms,
            sink_errors=sink_errors,
            action=lambda sink: _invoke_sink_init(sink, base_context, infra_config),
        )
        self._emit_sink_lifecycle(
            sink_states=sink_states,
            phase="start",
            sink_retry_count=sink_retry_count,
            sink_retry_backoff_ms=sink_retry_backoff_ms,
            sink_errors=sink_errors,
            action=lambda sink: _invoke_sink_start(sink, session_start_info),
        )

        for plugin in worker_plugins:
            callback = getattr(plugin, "init", None)
            if callable(callback):
                try:
                    _invoke_plugin_init(plugin, base_context, infra_config)
                except Exception as error:  # noqa: BLE001
                    _record_plugin_lifecycle_error(plugin_lifecycle_errors, _plugin_name(plugin), "init", error)
        for plugin in worker_plugins:
            callback = getattr(plugin, "start", None)
            if callable(callback):
                try:
                    _invoke_plugin_start(plugin, session_start_info)
                except Exception as error:  # noqa: BLE001
                    _record_plugin_lifecycle_error(plugin_lifecycle_errors, _plugin_name(plugin), "start", error)

        def build_snapshot_rows(now_ms: Optional[int] = None) -> List[Dict[str, Any]]:
            resolved_now_ms = int(time.time() * 1000) if now_ms is None else int(now_ms)
            rows: List[Dict[str, Any]] = []
            for index, scenario in enumerate(selected_scenarios):
                runtime = scenario_stats.setdefault(
                    scenario.name,
                    _new_scenario_accumulator(scenario.name, index + 1),
                )
                started_ms = _as_int(runtime.get("_startedMs"))
                elapsed_ms = max(resolved_now_ms - started_ms, 0) if started_ms > 0 else 0
                duration_ms = max(_as_int(scenario_durations_ms.get(scenario.name)), elapsed_ms)
                rows.append(_scenario_row_from_accumulator(runtime, duration_ms))
            return rows

        def build_metric_values(duration_ms: int) -> List[Dict[str, Any]]:
            with registered_metrics_lock:
                metrics_snapshot = list(registered_metrics)
            return _collect_metric_values(metrics_snapshot, duration_ms=duration_ms)

        if any(not bool(state.get("disabled")) for state in sink_states):
            def realtime_loop() -> None:
                while not realtime_stop_event.wait(reporting_interval_seconds):
                    duration_ms = max(int((time.time() - started_dt.timestamp()) * 1000), 0)
                    snapshot_rows = build_snapshot_rows(int(time.time() * 1000))
                    realtime_emissions["count"] += 1
                    self._emit_realtime_stats(
                        sink_states=sink_states,
                        scenario_stats=snapshot_rows,
                        metric_values=build_metric_values(duration_ms),
                        sink_retry_count=sink_retry_count,
                        sink_retry_backoff_ms=sink_retry_backoff_ms,
                        sink_errors=sink_errors,
                    )
                    if console_metrics_enabled:
                        _print_console_snapshot(base_logger, snapshot_rows)

            realtime_thread = threading.Thread(target=realtime_loop, name="loadstrike-python-realtime", daemon=True)
            realtime_thread.start()

        try:
            node_info["currentOperation"] = "Bombing"
            for scenario_index, scenario in enumerate(selected_scenarios):
                scenario_started_ms = int(time.time() * 1000)
                runtime = scenario_stats.setdefault(
                    scenario.name,
                    _new_scenario_accumulator(scenario.name, scenario_index + 1),
                )
                runtime["_startedMs"] = scenario_started_ms
                runtime["currentOperation"] = "Init"
                runtime["loadSimulationStats"] = _resolve_load_simulation_stats(scenario.load_simulations, scenario.weight)
                stop_scenario = False
                scenario_context_data: Dict[str, Any] = {}
                scenario_partition = LoadStrikeScenarioPartition(
                    number=0,
                    count=1,
                )
                logger = base_logger
                cancellation_event = Event()
                invocation_number = 0
                invocation_lock = threading.Lock()
                instance_number = 0
                instance_lock = threading.Lock()
                scenario_completion_timeout_seconds = max(
                    _as_float(self._options.get("scenario_completion_timeout_seconds", 30.0)),
                    0.0,
                )
                tracking_runtime: Optional[_ScenarioTrackingRuntimeBridge] = None

                def should_stop() -> bool:
                    return stop_scenario or stop_test_event.is_set() or cancellation_event.is_set()

                def next_invocation_number() -> int:
                    nonlocal invocation_number
                    with invocation_lock:
                        invocation_number += 1
                        return invocation_number

                def next_instance_info() -> tuple[int, str]:
                    nonlocal instance_number
                    with instance_lock:
                        instance_number += 1
                        value = instance_number
                    return value, f"{scenario.name}-{value}"

                def run_invocation(
                    operation: str,
                    *,
                    record_steps_and_policies: bool,
                    instance_data: Dict[str, Any],
                    instance_info: tuple[int, str],
                ) -> tuple[LoadStrikeReply, float]:
                    nonlocal stop_scenario
                    nonlocal stop_test
                    invocation = next_invocation_number()
                    instance_number_value, instance_id = instance_info
                    if record_steps_and_policies:
                        def record_step(step_name: str, reply: LoadStrikeReply, elapsed_ms: float) -> None:
                            _record_step(runtime, step_name, reply, elapsed_ms)
                    else:
                        def record_step(step_name: str, reply: LoadStrikeReply, elapsed_ms: float) -> None:
                            _ = step_name
                            _ = reply
                            _ = elapsed_ms

                    context = LoadStrikeScenarioContext(
                        scenario_name=scenario.name,
                        record_step=record_step,
                        runtime_policies=runtime_policies,
                        invocation_number=invocation,
                        logger=logger,
                        node_info=node_info,
                        test_info=test_info,
                        scenario_info=_build_scenario_info(
                            scenario.name,
                            operation,
                            instance_number=instance_number_value,
                            instance_id=instance_id,
                            scenario_started_ms=scenario_started_ms,
                        ),
                        scenario_timer_start_ms=scenario_started_ms,
                        cancellation_event=cancellation_event,
                        test_cancellation_event=stop_test_event,
                        allow_policy_callbacks=record_steps_and_policies,
                    )
                    context.data = scenario_context_data
                    context.scenario_instance_data = instance_data
                    started_at = time.perf_counter()
                    if tracking_runtime is not None:
                        reply = tracking_runtime.execute_iteration(
                            context,
                            invocation_index=invocation,
                            original_run=scenario.execute,
                        )
                    else:
                        reply = scenario.execute(context)
                    elapsed_ms = max((time.perf_counter() - started_at) * 1000.0, 0.0)
                    stop_scenario = bool(context._stop_scenario)
                    stop_test = bool(context._stop_test)
                    if stop_test:
                        stop_test_event.set()
                        cancellation_event.set()
                    if stop_scenario:
                        cancellation_event.set()
                    return reply, elapsed_ms

                def set_runtime_operation(value: str) -> None:
                    sync = runtime.get("_sync")
                    if hasattr(sync, "acquire") and hasattr(sync, "release"):
                        sync.acquire()
                    try:
                        runtime["currentOperation"] = value
                    finally:
                        if hasattr(sync, "release"):
                            sync.release()

                def set_runtime_load_simulation(simulations: List[Dict[str, Any]]) -> None:
                    sync = runtime.get("_sync")
                    if hasattr(sync, "acquire") and hasattr(sync, "release"):
                        sync.acquire()
                    try:
                        runtime["loadSimulationStats"] = _resolve_load_simulation_stats(simulations, scenario.weight)
                    finally:
                        if hasattr(sync, "release"):
                            sync.release()

                init_context = LoadStrikeScenarioInitContext(
                    custom_settings=dict(self._options.get("custom_settings", {}) or {}),
                    global_custom_settings=dict(self._options.get("global_custom_settings", {}) or {}),
                    logger=logger,
                    node_info=LoadStrikeNodeInfo(node_info),
                    test_info=LoadStrikeTestInfo(test_info),
                    scenario_info=LoadStrikeScenarioInfo(
                        _build_scenario_info(
                            scenario.name,
                            "Init",
                            instance_number=0,
                            instance_id="init",
                            scenario_started_ms=scenario_started_ms,
                        )
                    ),
                    scenario_partition=scenario_partition,
                )

                try:
                    scenario.invoke_init(init_context)
                    if scenario.cross_platform_tracking:
                        tracking_runtime = _ScenarioTrackingRuntimeBridge(
                            scenario_name=scenario.name,
                            tracking=scenario.cross_platform_tracking,
                            init_context=init_context,
                        )
                        tracking_runtime.start()
                    with registered_metrics_lock:
                        registered_metrics.extend(
                            {
                                "metric": metric,
                                "scenarioName": scenario.name,
                            }
                            for metric in init_context.registered_metrics
                        )
                    self._invoke_policy_callbacks(runtime_policies, "before_scenario", scenario.name)

                    def sleep_interruptible(duration_seconds: float) -> None:
                        end_time = time.time() + max(duration_seconds, 0.0)
                        while time.time() < end_time and not should_stop():
                            time.sleep(min(max(end_time - time.time(), 0.0), 0.01))

                    def record_final_reply(final_reply: LoadStrikeReply, elapsed_ms: float) -> None:
                        latency_ms = _resolve_runtime_latency(final_reply.custom_latency_ms, elapsed_ms)
                        _record_measurement(
                            runtime["_fail"] if not final_reply.is_success else runtime["_ok"],
                            final_reply,
                            latency_ms,
                        )

                    def run_recorded_invocation(
                        operation: str,
                        *,
                        record_steps_and_policies: bool,
                        instance_data: Dict[str, Any],
                        instance_info: tuple[int, str],
                    ) -> None:
                        nonlocal stop_scenario
                        restart_attempts_left = restart_iteration_max_attempts
                        final_reply: Optional[LoadStrikeReply] = None
                        final_elapsed_ms = 0.0
                        while not should_stop():
                            reply, elapsed_ms = run_invocation(
                                operation,
                                record_steps_and_policies=record_steps_and_policies,
                                instance_data=instance_data,
                                instance_info=instance_info,
                            )
                            should_retry = (
                                record_steps_and_policies
                                and not reply.is_success
                                and scenario.restart_iteration_on_fail
                                and restart_attempts_left > 0
                                and not should_stop()
                            )
                            if should_retry:
                                restart_attempts_left -= 1
                                continue
                            final_reply = reply
                            final_elapsed_ms = elapsed_ms
                            break

                        if not record_steps_and_policies:
                            return

                        if final_reply is None:
                            final_reply = LoadStrikeResponse.fail(
                                message="Scenario iteration returned no final reply."
                            )
                        record_final_reply(final_reply, final_elapsed_ms)
                        if scenario.max_fail_count > 0 and _measurement_count(runtime["_fail"]) >= scenario.max_fail_count:
                            stop_scenario = True
                            cancellation_event.set()

                    def wait_for_threads(threads: List[threading.Thread]) -> None:
                        if not threads:
                            return
                        if scenario_completion_timeout_seconds <= 0:
                            for thread in threads:
                                thread.join()
                            return
                        deadline = time.time() + scenario_completion_timeout_seconds
                        for thread in threads:
                            remaining = max(deadline - time.time(), 0.0)
                            if remaining <= 0:
                                break
                            thread.join(remaining)
                        if any(thread.is_alive() for thread in threads):
                            logger.warn(
                                f"Scenario {scenario.name} timed out while waiting for completion "
                                f"({scenario_completion_timeout_seconds}s)."
                            )

                    if not scenario.without_warm_up_enabled and _as_float(scenario.warm_up_duration_seconds) > 0:
                        set_runtime_operation("WarmUp")
                        warmup_instance = (1, f"{scenario.name}-1")
                        warmup_data: Dict[str, Any] = {}
                        warmup_end = time.time() + _as_float(scenario.warm_up_duration_seconds)
                        while time.time() < warmup_end and not should_stop():
                            run_recorded_invocation(
                                "WarmUp",
                                record_steps_and_policies=False,
                                instance_data=warmup_data,
                                instance_info=warmup_instance,
                            )

                    set_runtime_operation("Bombing")
                    if not scenario.load_simulations:
                        run_recorded_invocation(
                            "Bombing",
                            record_steps_and_policies=True,
                            instance_data={},
                            instance_info=(1, f"{scenario.name}-1"),
                        )
                    else:
                        for simulation in scenario.load_simulations:
                            if should_stop() or not isinstance(simulation, dict):
                                break
                            set_runtime_load_simulation([simulation])
                            kind = str(simulation.get("Kind") or "")
                            weight = max(int(scenario.weight), 1)
                            copies = max(_as_int(simulation.get("Copies")), 0) * weight
                            rate = max(_as_int(simulation.get("Rate")), 0) * weight
                            min_rate = max(_as_int(simulation.get("MinRate")), 0) * weight
                            max_rate = max(_as_int(simulation.get("MaxRate")), 0) * weight
                            iterations = max(_as_int(simulation.get("Iterations")), 0) * weight
                            interval_seconds = max(_as_float(simulation.get("IntervalSeconds")), 0.0)
                            during_seconds = max(_as_float(simulation.get("DuringSeconds")), 0.0)

                            if kind == "Pause":
                                sleep_interruptible(during_seconds)
                                continue

                            threads: List[threading.Thread] = []

                            def start_thread(callback: Callable[[], None]) -> None:
                                thread = threading.Thread(target=callback, daemon=True)
                                thread.start()
                                threads.append(thread)

                            if kind == "KeepConstant" and copies > 0 and during_seconds > 0:
                                end_time = time.time() + during_seconds
                                for _ in range(copies):
                                    instance_info = next_instance_info()
                                    instance_data = {}
                                    def keep_constant_worker(
                                        data: Dict[str, Any] = instance_data,
                                        info: tuple[int, str] = instance_info,
                                        end: float = end_time,
                                    ) -> None:
                                        while time.time() < end and not should_stop():
                                            run_recorded_invocation(
                                                "Bombing",
                                                record_steps_and_policies=True,
                                                instance_data=data,
                                                instance_info=info,
                                            )
                                    start_thread(keep_constant_worker)
                                wait_for_threads(threads)
                                continue

                            if kind == "RampingConstant" and copies > 0 and during_seconds > 0:
                                end_time = time.time() + during_seconds
                                start_interval = 0.0 if copies <= 1 else during_seconds / copies
                                for copy_index in range(copies):
                                    if should_stop():
                                        break
                                    instance_info = next_instance_info()
                                    instance_data = {}
                                    def ramping_constant_worker(
                                        data: Dict[str, Any] = instance_data,
                                        info: tuple[int, str] = instance_info,
                                        end: float = end_time,
                                    ) -> None:
                                        while time.time() < end and not should_stop():
                                            run_recorded_invocation(
                                                "Bombing",
                                                record_steps_and_policies=True,
                                                instance_data=data,
                                                instance_info=info,
                                            )
                                    start_thread(ramping_constant_worker)
                                    if copy_index < copies - 1 and start_interval > 0:
                                        sleep_interruptible(start_interval)
                                wait_for_threads(threads)
                                continue

                            if kind == "Inject" and rate > 0 and interval_seconds > 0 and during_seconds > 0:
                                end_time = time.time() + during_seconds
                                while time.time() < end_time and not should_stop():
                                    for _ in range(rate):
                                        instance_info = next_instance_info()
                                        start_thread(
                                            lambda info=instance_info: run_recorded_invocation(
                                                "Bombing",
                                                record_steps_and_policies=True,
                                                instance_data={},
                                                instance_info=info,
                                            )
                                        )
                                    sleep_interruptible(interval_seconds)
                                wait_for_threads(threads)
                                continue

                            if kind == "RampingInject" and rate > 0 and interval_seconds > 0 and during_seconds > 0:
                                started_at = time.time()
                                end_time = started_at + during_seconds
                                while time.time() < end_time and not should_stop():
                                    elapsed = time.time() - started_at
                                    progress = 0.0 if during_seconds <= 0 else min(max(elapsed / during_seconds, 0.0), 1.0)
                                    current_rate = max(1, int(math.ceil(rate * progress)))
                                    for _ in range(current_rate):
                                        instance_info = next_instance_info()
                                        start_thread(
                                            lambda info=instance_info: run_recorded_invocation(
                                                "Bombing",
                                                record_steps_and_policies=True,
                                                instance_data={},
                                                instance_info=info,
                                            )
                                        )
                                    sleep_interruptible(interval_seconds)
                                wait_for_threads(threads)
                                continue

                            if kind == "InjectRandom" and max_rate > 0 and interval_seconds > 0 and during_seconds > 0:
                                lower = max(1, min_rate)
                                upper = max(lower, max_rate)
                                end_time = time.time() + during_seconds
                                while time.time() < end_time and not should_stop():
                                    current_rate = random.randint(lower, upper)
                                    for _ in range(current_rate):
                                        instance_info = next_instance_info()
                                        start_thread(
                                            lambda info=instance_info: run_recorded_invocation(
                                                "Bombing",
                                                record_steps_and_policies=True,
                                                instance_data={},
                                                instance_info=info,
                                            )
                                        )
                                    sleep_interruptible(interval_seconds)
                                wait_for_threads(threads)
                                continue

                            if kind == "IterationsForConstant" and copies > 0 and iterations > 0:
                                remaining = {"value": iterations}
                                remaining_lock = threading.Lock()
                                for _ in range(copies):
                                    instance_info = next_instance_info()
                                    instance_data = {}
                                    def constant_iterations_worker(
                                        data: Dict[str, Any] = instance_data,
                                        info: tuple[int, str] = instance_info,
                                    ) -> None:
                                        while not should_stop():
                                            with remaining_lock:
                                                if remaining["value"] <= 0:
                                                    break
                                                remaining["value"] -= 1
                                            run_recorded_invocation(
                                                "Bombing",
                                                record_steps_and_policies=True,
                                                instance_data=data,
                                                instance_info=info,
                                            )
                                    start_thread(constant_iterations_worker)
                                wait_for_threads(threads)
                                continue

                            if kind == "IterationsForInject" and rate > 0 and interval_seconds > 0 and iterations > 0:
                                remaining = iterations
                                while remaining > 0 and not should_stop():
                                    batch = min(rate, remaining)
                                    for _ in range(batch):
                                        instance_info = next_instance_info()
                                        start_thread(
                                            lambda info=instance_info: run_recorded_invocation(
                                                "Bombing",
                                                record_steps_and_policies=True,
                                                instance_data={},
                                                instance_info=info,
                                            )
                                        )
                                    remaining -= batch
                                    if remaining > 0:
                                        sleep_interruptible(interval_seconds)
                                wait_for_threads(threads)
                                continue

                    scenario_durations_ms[scenario.name] = max(int(time.time() * 1000) - scenario_started_ms, 0)
                    set_runtime_operation("Stop" if (stop_test or stop_scenario or stop_test_event.is_set()) else "Complete")
                    self._invoke_policy_callbacks(
                        runtime_policies,
                        "after_scenario",
                        scenario.name,
                        _scenario_row_from_accumulator(runtime, scenario_durations_ms[scenario.name]),
                    )
                except Exception as error:  # noqa: BLE001
                    set_runtime_operation("Error")
                    logger.error(str(error))
                finally:
                    try:
                        scenario.invoke_clean(init_context)
                    except Exception as error:  # noqa: BLE001
                        set_runtime_operation("Error")
                        logger.error(str(error))
                    if tracking_runtime is not None:
                        tracking_runtime.dispose()

            realtime_stop_event.set()
            if realtime_thread is not None and realtime_thread.is_alive():
                realtime_thread.join(timeout=max(reporting_interval_seconds, 0.5))

            stop_test = stop_test or stop_test_event.is_set()
            node_info["currentOperation"] = "Stop" if stop_test else "Complete"
            run_duration_ms = max(int((time.time() - started_dt.timestamp()) * 1000), 0)
            metric_values = build_metric_values(run_duration_ms)
            if any(not bool(state.get("disabled")) for state in sink_states) and realtime_emissions["count"] == 0:
                snapshot_rows = build_snapshot_rows(int(time.time() * 1000))
                realtime_emissions["count"] += 1
                self._emit_realtime_stats(
                    sink_states=sink_states,
                    scenario_stats=snapshot_rows,
                    metric_values=metric_values,
                    sink_retry_count=sink_retry_count,
                    sink_retry_backoff_ms=sink_retry_backoff_ms,
                    sink_errors=sink_errors,
                )
                if console_metrics_enabled:
                    _print_console_snapshot(base_logger, snapshot_rows)
            metrics_by_name = {str(x.get("name", "")).lower(): _as_float(x.get("value")) for x in metric_values}
            finalized_scenario_rows = [
                dict(row)
                for row in build_snapshot_rows()
                if isinstance(row, dict)
            ]
            finalized_step_rows = _flatten_step_stats(finalized_scenario_rows)
            scenario_stats = {
                str(row.get("scenarioName") or ""): row
                for row in finalized_scenario_rows
                if str(row.get("scenarioName") or "").strip()
            }
            step_stats = {
                f"{str(row.get('scenarioName') or '')}::{str(row.get('stepName') or '')}": row
                for row in finalized_step_rows
                if str(row.get("scenarioName") or "").strip() and str(row.get("stepName") or "").strip()
            }
            threshold_eval = _evaluate_thresholds(
                selected_scenarios,
                scenario_stats,
                scenario_durations_ms,
                step_stats=step_stats,
                run_duration_ms=run_duration_ms,
                metrics_by_name=metrics_by_name,
                metric_values=metric_values,
            )
            result = {
                "startedUtc": started,
                "completedUtc": datetime.now(timezone.utc).isoformat(),
                "allRequestCount": sum(x["allRequestCount"] for x in scenario_stats.values()),
                "allOkCount": sum(x["allOkCount"] for x in scenario_stats.values()),
                "allFailCount": sum(x["allFailCount"] for x in scenario_stats.values()),
                "allBytes": sum(_as_int(x.get("allBytes")) for x in scenario_stats.values()),
                "durationMs": run_duration_ms,
                "failedThresholds": threshold_eval["failedCount"],
                "thresholdResults": threshold_eval["results"],
                "metricStats": _build_metric_stats_payload(metric_values, run_duration_ms),
                "metrics": metric_values,
                "scenarioStats": finalized_scenario_rows,
                "stepStats": finalized_step_rows,
                "scenarioDurationsMs": dict(scenario_durations_ms),
                "nodeInfo": dict(node_info),
                "testInfo": dict(test_info),
                "pluginsData": [],
                "disabledSinks": [],
                "sinkErrors": sink_errors,
                "reportFiles": [],
            }

            base_node_stats = LoadStrikeNodeStats(result)
            result["pluginsData"] = self._collect_plugin_data(
                worker_plugins,
                base_node_stats,
                plugin_lifecycle_errors,
            )
            detailed_report_finalizer = self._options.get("report_finalizer")
            if callable(detailed_report_finalizer):
                result = _coerce_detailed_report_finalizer_result(
                    _invoke_maybe_async(detailed_report_finalizer, LoadStrikeNodeStats(result))
                )
            final_node_stats = LoadStrikeNodeStats(result)
            result["reportFiles"] = self._write_reports(final_node_stats.to_dict())
            result["disabledSinks"] = [x["name"] for x in sink_states if x["disabled"]]
            self._emit_final_stats(
                sink_states=sink_states,
                result=final_node_stats,
                sink_retry_count=sink_retry_count,
                sink_retry_backoff_ms=sink_retry_backoff_ms,
                sink_errors=sink_errors,
            )
            self._emit_run_result(
                sink_states=sink_states,
                result=result,
                sink_retry_count=sink_retry_count,
                sink_retry_backoff_ms=sink_retry_backoff_ms,
                sink_errors=sink_errors,
            )
            self._emit_sink_lifecycle(
                sink_states=sink_states,
                phase="stop",
                sink_retry_count=sink_retry_count,
                sink_retry_backoff_ms=sink_retry_backoff_ms,
                sink_errors=sink_errors,
                action=lambda sink: _call_if_exists(sink, "stop"),
                ignore_disabled=True,
            )
            sinks_stopped = True
            self._stop_plugins(worker_plugins, plugin_lifecycle_errors)
            plugins_stopped = True
            result["disabledSinks"] = [x["name"] for x in sink_states if x["disabled"]]

            return result
        except Exception:  # noqa: BLE001
            node_info["currentOperation"] = "Error"
            raise
        finally:
            realtime_stop_event.set()
            if realtime_thread is not None and realtime_thread.is_alive():
                realtime_thread.join(timeout=max(reporting_interval_seconds, 0.5))
            if not plugins_stopped:
                self._stop_plugins(worker_plugins, plugin_lifecycle_errors)
            if not sinks_stopped:
                self._emit_sink_lifecycle(
                    sink_states=sink_states,
                    phase="stop",
                    sink_retry_count=sink_retry_count,
                    sink_retry_backoff_ms=sink_retry_backoff_ms,
                    sink_errors=sink_errors,
                    action=lambda sink: _call_if_exists(sink, "stop"),
                    ignore_disabled=True,
                )
            if license_client is not None and license_session is not None:
                license_client._stop_license_lease_if_required(license_session, license_payload)

    def _resolve_execution_mode(self) -> str:
        node_type = _normalize_node_type_value(self._options.get("node_type"))
        if node_type == "coordinator":
            if _as_bool(self._options.get("local_dev_cluster_enabled"), False) and _as_int(
                self._options.get("agents_count") or 1
            ) > 0:
                return "local_dev_cluster"
            if _is_non_empty_string(self._options.get("nats_server_url")):
                return "distributed_coordinator"
        if node_type == "agent" and _is_non_empty_string(self._options.get("nats_server_url")):
            return "distributed_agent"
        return "local"

    def _execute_local_dev_cluster_detailed(self) -> Dict[str, Any]:
        assignments = _plan_cluster_agent_assignments(self._scenarios, self._options)
        node_results = [
            self._execute_child_runner_detailed(
                assignment,
                node_type="Agent",
                machine_name=f"local-agent-{index + 1}",
            )
            for index, assignment in enumerate(assignments)
        ]
        coordinator_targets = _normalize_string_list(self._options.get("coordinator_target_scenarios"))
        if coordinator_targets:
            node_results.append(
                self._execute_child_runner_detailed(
                    coordinator_targets,
                    node_type="Coordinator",
                    machine_name=_build_node_info({**self._options, "node_type": "Coordinator"}).get("machineName", "local-machine"),
                )
            )
        aggregated = _aggregate_node_detailed_results(node_results, self._options, "Coordinator")
        return self._finalize_cluster_result(aggregated, [])

    def _execute_distributed_coordinator_detailed(self) -> Dict[str, Any]:
        coordinator = DistributedClusterCoordinator(
            cluster_id=str(self._options.get("cluster_id") or "local"),
            session_id=str(self._options.get("session_id") or _generate_session_id()),
            test_suite=str(self._options.get("test_suite") or "loadstrike"),
            test_name=str(self._options.get("test_name") or "loadstrike-test"),
            expected_agent_results=max(_as_int(self._options.get("agents_count") or 1), 1),
            agent_group=str(self._options.get("agent_group") or "default"),
            command_timeout_ms=max(
                int(_as_float(self._options.get("cluster_command_timeout_seconds") or 120.0) * 1000),
                1,
            ),
            nats_options={"ServerUrl": str(self._options.get("nats_server_url") or "")},
        )
        dispatch_result = coordinator.dispatch(_plan_cluster_agent_assignments(self._scenarios, self._options))
        node_results = [
            dict(row.get("details"))
            for row in dispatch_result.get("nodeResults", [])
            if isinstance(row, dict) and isinstance(row.get("details"), dict)
        ]
        for row in dispatch_result.get("nodeResults", []):
            if not isinstance(row, dict) or isinstance(row.get("details"), dict):
                continue
            node_results.append(_synthetic_cluster_failure_result(self._options, row))
        coordinator_targets = _normalize_string_list(self._options.get("coordinator_target_scenarios"))
        if coordinator_targets:
            node_results.append(
                self._execute_child_runner_detailed(
                    coordinator_targets,
                    node_type="Coordinator",
                    machine_name=_build_node_info({**self._options, "node_type": "Coordinator"}).get("machineName", "local-machine"),
                )
            )
        aggregated = _aggregate_node_detailed_results(node_results, self._options, "Coordinator")
        hints: List[str] = []
        missing_nodes = _as_int(dispatch_result.get("missingNodes"))
        if missing_nodes > 0:
            hints.append(f"Timed out waiting for {missing_nodes} agent node result(s).")
        return self._finalize_cluster_result(aggregated, hints)

    def _execute_distributed_agent_detailed(self) -> Dict[str, Any]:
        timeout_seconds = max(_as_float(self._options.get("cluster_command_timeout_seconds") or 120.0), 0.1)
        agent = DistributedClusterAgent(
            cluster_id=str(self._options.get("cluster_id") or "local"),
            session_id=str(self._options.get("session_id") or ""),
            agent_id=f"{_build_node_info(self._options).get('machineName', 'local-machine')}-{_generate_session_id()}",
            agent_group=str(self._options.get("agent_group") or "default"),
            nats_options={"ServerUrl": str(self._options.get("nats_server_url") or "")},
        )
        holder: Dict[str, Dict[str, Any]] = {}
        deadline = time.time() + timeout_seconds

        class _AgentResult:
            def __init__(self, detail: Dict[str, Any]) -> None:
                self.details = detail
                self.node_id = str(detail.get("nodeInfo", {}).get("machineName") or "agent")
                self.success = _as_int(detail.get("allFailCount")) == 0 and _as_int(detail.get("failedThresholds")) == 0
                self.all_request_count = _as_int(detail.get("allRequestCount"))
                self.all_ok_count = _as_int(detail.get("allOkCount"))
                self.all_fail_count = _as_int(detail.get("allFailCount"))
                self.error = ""

        while time.time() < deadline:
            handled = agent.poll_and_execute_once(
                lambda dispatch: _AgentResult(
                    holder.setdefault(
                        "detail",
                        self._execute_child_runner_detailed(
                            dispatch.scenario_names,
                            node_type="Agent",
                            machine_name=_build_node_info({**self._options, "node_type": "Agent"}).get("machineName", "local-machine"),
                        ),
                    )
                )
            )
            if handled:
                return holder.get("detail", _build_empty_node_result(self._options, "Agent", "local-agent"))
            time.sleep(0.01)
        raise TimeoutError(
            f"No coordinator command received within {int(timeout_seconds * 1000)}ms."
        )

    def _execute_child_runner_detailed(
        self,
        target_scenarios: List[str],
        *,
        node_type: str,
        machine_name: str,
    ) -> Dict[str, Any]:
        if not target_scenarios:
            return _build_empty_node_result(self._options, node_type, machine_name)
        child_options = dict(self._options)
        child_options.update(
            {
                "local_dev_cluster_enabled": False,
                "nats_server_url": None,
                "reports_enabled": False,
                "reporting_sinks": [],
                "worker_plugins": [],
                "console_metrics_enabled": False,
                "node_type": node_type,
                "machine_name": machine_name,
                "target_scenarios": list(target_scenarios),
                "agent_target_scenarios": list(target_scenarios) if _normalize_node_type_value(node_type) == "agent" else [],
                "coordinator_target_scenarios": [],
            }
        )
        result = LoadStrikeRunner(self._scenarios, child_options)._execute_local_detailed()
        node_info = dict(result.get("nodeInfo") or {})
        node_info["nodeType"] = node_type
        node_info["machineName"] = machine_name
        result["nodeInfo"] = node_info
        return result

    def _finalize_cluster_result(self, aggregated: Dict[str, Any], cluster_hints: List[str]) -> Dict[str, Any]:
        worker_plugins = _resolve_worker_plugins(
            list(self._options.get("worker_plugins") or []),
        )
        sinks = list(self._options.get("reporting_sinks") or [])
        _validate_reporting_sink_names(sinks)
        sink_states = [
            {"sink": sink, "disabled": False, "name": _resolve_sink_name(sink, index)}
            for index, sink in enumerate(sinks)
        ]
        sink_errors: List[Dict[str, Any]] = []
        sink_retry_count = max(int(self._options.get("sink_retry_count", 2)), 0)
        sink_retry_backoff_ms = max(int(self._options.get("sink_retry_backoff_ms", 25)), 0)
        started = str(aggregated.get("startedUtc") or datetime.now(timezone.utc).isoformat())
        selected_scenarios = [
            str(row.get("scenarioName"))
            for row in aggregated.get("scenarioStats", [])
            if isinstance(row, dict) and str(row.get("scenarioName") or "").strip()
        ]
        base_logger = _create_logger(self._options.get("logger_config"), self._options.get("minimum_log_level"))
        test_info = dict(aggregated.get("testInfo") or _build_test_info(self._options, started))
        node_info = dict(aggregated.get("nodeInfo") or _build_node_info({**self._options, "node_type": "Coordinator"}))
        base_context = LoadStrikeBaseContext(
            logger=base_logger,
            test_info=LoadStrikeTestInfo(test_info),
            node_info=LoadStrikeNodeInfo(node_info),
        )
        infra_config = dict(self._options.get("infra_config") or {})
        session_start_info = LoadStrikeSessionStartInfo(
            {
                "startedUtc": started,
                "scenarioNames": selected_scenarios,
                "configPath": self._options.get("config_path"),
                "infraConfigPath": self._options.get("infra_config_path"),
                "infraConfig": dict(infra_config) or None,
                "scenarios": [
                    {"scenarioName": scenario.name, "sortIndex": index + 1}
                    for index, scenario in enumerate(self._scenarios)
                ],
            }
        )
        plugin_lifecycle_errors: Dict[str, List[str]] = {}
        plugins_stopped = False
        sinks_stopped = False
        license_client: Optional[LoadStrikeLocalClient] = None
        license_payload: Dict[str, Any] = {}
        license_session: Any = None

        try:
            license_payload = self._build_license_payload()
            license_client = LoadStrikeLocalClient(
                licensing_api_base_url=str(
                    self._options.get("license_validation_server_url")
                    or "https://licensing.loadstrike.com"
                ),
                license_validation_timeout_seconds=max(
                    _as_float(self._options.get("license_validation_timeout_seconds")), 10.0
                ),
            )
            license_session = license_client._validate_license_if_required(license_payload)

            self._emit_sink_lifecycle(
                sink_states=sink_states,
                phase="init",
                sink_retry_count=sink_retry_count,
                sink_retry_backoff_ms=sink_retry_backoff_ms,
                sink_errors=sink_errors,
                action=lambda sink: _invoke_sink_init(sink, base_context, infra_config),
            )
            self._emit_sink_lifecycle(
                sink_states=sink_states,
                phase="start",
                sink_retry_count=sink_retry_count,
                sink_retry_backoff_ms=sink_retry_backoff_ms,
                sink_errors=sink_errors,
                action=lambda sink: _invoke_sink_start(sink, session_start_info),
            )
            for plugin in worker_plugins:
                callback = getattr(plugin, "init", None)
                if callable(callback):
                    try:
                        _invoke_plugin_init(plugin, base_context, infra_config)
                    except Exception as error:  # noqa: BLE001
                        _record_plugin_lifecycle_error(plugin_lifecycle_errors, _plugin_name(plugin), "init", error)
            for plugin in worker_plugins:
                callback = getattr(plugin, "start", None)
                if callable(callback):
                    try:
                        _invoke_plugin_start(plugin, session_start_info)
                    except Exception as error:  # noqa: BLE001
                        _record_plugin_lifecycle_error(plugin_lifecycle_errors, _plugin_name(plugin), "start", error)

            finalized_scenario_rows = [
                dict(row)
                for row in aggregated.get("scenarioStats", [])
                if isinstance(row, dict)
            ]
            finalized_step_rows = _flatten_step_stats(finalized_scenario_rows)
            scenario_stats = {
                str(row.get("scenarioName") or ""): row
                for row in finalized_scenario_rows
                if str(row.get("scenarioName") or "").strip()
            }
            step_stats = {
                f"{row.get('scenarioName')}::{row.get('stepName')}": dict(row)
                for row in finalized_step_rows
                if isinstance(row, dict)
                and str(row.get("scenarioName") or "").strip()
                and str(row.get("stepName") or "").strip()
            }
            metrics_by_name = {
                str(row.get("name") or "").lower(): _as_float(row.get("value"))
                for row in aggregated.get("metrics", [])
                if isinstance(row, dict) and str(row.get("name") or "").strip()
            }
            threshold_eval = _evaluate_thresholds(
                self._scenarios,
                scenario_stats,
                dict(aggregated.get("scenarioDurationsMs") or {}),
                step_stats=step_stats,
                run_duration_ms=max(_as_int(aggregated.get("runDurationMs")), 0),
                metrics_by_name=metrics_by_name,
                metric_values=[
                    dict(row)
                    for row in aggregated.get("metrics", [])
                    if isinstance(row, dict)
                ],
            )
            aggregated["scenarioStats"] = finalized_scenario_rows
            aggregated["stepStats"] = finalized_step_rows
            aggregated["thresholdResults"] = threshold_eval["results"]
            aggregated["failedThresholds"] = threshold_eval["failedCount"]
            aggregated["allRequestCount"] = sum(_as_int(x.get("allRequestCount")) for x in finalized_scenario_rows)
            aggregated["allOkCount"] = sum(_as_int(x.get("allOkCount")) for x in finalized_scenario_rows)
            aggregated["allFailCount"] = sum(_as_int(x.get("allFailCount")) for x in finalized_scenario_rows)
            aggregated["allBytes"] = sum(_as_int(x.get("allBytes")) for x in finalized_scenario_rows)
            aggregated["metricStats"] = _build_metric_stats_payload(
                aggregated.get("metrics", []),
                max(_as_int(aggregated.get("runDurationMs")), 0),
            )
            aggregated["nodeInfo"] = {
                **node_info,
                "currentOperation": str(node_info.get("currentOperation") or "Complete"),
            }
            if _as_bool(self._options.get("console_metrics_enabled"), True):
                _print_console_snapshot(base_logger, finalized_scenario_rows)

            base_node_stats = LoadStrikeNodeStats(aggregated)
            plugin_rows = self._collect_plugin_data(worker_plugins, base_node_stats, plugin_lifecycle_errors)
            if cluster_hints:
                cluster_plugin = LoadStrikePluginData.create("Cluster Runtime")
                cluster_plugin["hints"] = list(cluster_hints)
                plugin_rows.append(cluster_plugin.to_dict())
            aggregated["pluginsData"] = plugin_rows
            aggregated["sinkErrors"] = sink_errors
            aggregated["disabledSinks"] = []
            aggregated["reportFiles"] = []
            detailed_report_finalizer = self._options.get("report_finalizer")
            if callable(detailed_report_finalizer):
                aggregated = _coerce_detailed_report_finalizer_result(
                    _invoke_maybe_async(detailed_report_finalizer, LoadStrikeNodeStats(aggregated))
                )
            final_node_stats = LoadStrikeNodeStats(aggregated)
            aggregated["reportFiles"] = self._write_reports(final_node_stats.to_dict())
            aggregated["disabledSinks"] = [x["name"] for x in sink_states if x["disabled"]]
            self._emit_final_stats(
                sink_states=sink_states,
                result=final_node_stats,
                sink_retry_count=sink_retry_count,
                sink_retry_backoff_ms=sink_retry_backoff_ms,
                sink_errors=sink_errors,
            )
            self._emit_run_result(
                sink_states=sink_states,
                result=aggregated,
                sink_retry_count=sink_retry_count,
                sink_retry_backoff_ms=sink_retry_backoff_ms,
                sink_errors=sink_errors,
            )
            self._emit_sink_lifecycle(
                sink_states=sink_states,
                phase="stop",
                sink_retry_count=sink_retry_count,
                sink_retry_backoff_ms=sink_retry_backoff_ms,
                sink_errors=sink_errors,
                action=lambda sink: _call_if_exists(sink, "stop"),
                ignore_disabled=True,
            )
            sinks_stopped = True
            self._stop_plugins(worker_plugins, plugin_lifecycle_errors)
            plugins_stopped = True
            aggregated["disabledSinks"] = [x["name"] for x in sink_states if x["disabled"]]
            aggregated["sinkErrors"] = sink_errors
            return aggregated
        finally:
            if not plugins_stopped:
                self._stop_plugins(worker_plugins, plugin_lifecycle_errors)
            if not sinks_stopped:
                self._emit_sink_lifecycle(
                    sink_states=sink_states,
                    phase="stop",
                    sink_retry_count=sink_retry_count,
                    sink_retry_backoff_ms=sink_retry_backoff_ms,
                    sink_errors=sink_errors,
                    action=lambda sink: _call_if_exists(sink, "stop"),
                    ignore_disabled=True,
                )
            if license_client is not None and license_session is not None:
                license_client._stop_license_lease_if_required(license_session, license_payload)

    @staticmethod
    def _stop_plugins(
        plugins: List[LoadStrikeWorkerPlugin],
        plugin_lifecycle_errors: Dict[str, List[str]],
    ) -> None:
        for plugin in plugins:
            callback = getattr(plugin, "stop", None)
            if callable(callback):
                try:
                    _invoke_maybe_async(callback)
                except Exception as error:  # noqa: BLE001
                    _record_plugin_lifecycle_error(plugin_lifecycle_errors, _plugin_name(plugin), "stop", error)

    def _select_scenarios(self, runtime_policies: List[LoadStrikeRuntimePolicy]) -> List[LoadStrikeScenario]:
        empty_selection_error = "At least one scenario must be selected for execution."
        scenario_by_name = {x.name: x for x in self._scenarios}
        node_type = str(self._options.get("node_type", "Single")).lower()

        selected_names = self._options.get("target_scenarios")
        if node_type == "agent" and self._options.get("agent_target_scenarios"):
            selected_names = self._options["agent_target_scenarios"]
        elif node_type == "coordinator" and self._options.get("coordinator_target_scenarios"):
            selected_names = self._options["coordinator_target_scenarios"]

        selected = (
            list(self._scenarios)
            if not selected_names
            else [
                scenario_by_name[name]
                for name in selected_names
                if name in scenario_by_name
            ]
        )
        if not selected:
            raise LoadStrikeInvalidOperationError(empty_selection_error)
        if not runtime_policies:
            return selected

        filtered: List[LoadStrikeScenario] = []
        for scenario in selected:
            should_run = True
            for policy in runtime_policies:
                callback = getattr(policy, "should_run_scenario", None)
                if callable(callback) and _invoke_maybe_async(callback, scenario.name) is False:
                    should_run = False
                    break
            if should_run:
                filtered.append(scenario)

        if not filtered:
            raise LoadStrikeInvalidOperationError(empty_selection_error)
        return filtered

    def _build_license_payload(self) -> Dict[str, Any]:
        context = _runner_options_to_context_values(self._options)

        scenarios: List[Dict[str, Any]] = []
        for scenario in self._scenarios:
            scenarios.append(
                {
                    "Name": scenario.name,
                    "MaxFailCount": scenario.max_fail_count,
                    "RestartIterationOnFail": scenario.restart_iteration_on_fail,
                    "WithoutWarmUp": scenario.without_warm_up_enabled,
                    "WarmUpDurationSeconds": scenario.warm_up_duration_seconds,
                    "Weight": scenario.weight,
                    "LoadSimulations": list(scenario.load_simulations or []),
                    "Thresholds": list(scenario.thresholds or []),
                    "Tracking": scenario.cross_platform_tracking or {},
                    "LicenseFeatures": list(scenario.license_features or []),
                }
            )

        return {
            "Context": context,
            "Scenarios": scenarios,
            "RunArgs": list(self._options.get("run_args") or []),
        }

    @staticmethod
    def _invoke_policy_callbacks(
        runtime_policies: List[LoadStrikeRuntimePolicy],
        callback_name: str,
        *args: Any,
    ) -> None:
        for policy in runtime_policies:
            callback = getattr(policy, callback_name, None)
            if callable(callback):
                _invoke_maybe_async(callback, *args)

    def _emit_realtime_stats(
        self,
        *,
        sink_states: List[Dict[str, Any]],
        scenario_stats: List[Dict[str, Any]],
        metric_values: List[Dict[str, Any]],
        sink_retry_count: int,
        sink_retry_backoff_ms: int,
        sink_errors: List[Dict[str, Any]],
    ) -> None:
        for state in sink_states:
            self._invoke_sink_action(
                state=state,
                phase="realtime",
                sink_retry_count=sink_retry_count,
                sink_retry_backoff_ms=sink_retry_backoff_ms,
                sink_errors=sink_errors,
                action=lambda sink=state["sink"]: _call_if_exists(sink, "save_realtime_stats", scenario_stats),
            )
            self._invoke_sink_action(
                state=state,
                phase="realtime",
                sink_retry_count=sink_retry_count,
                sink_retry_backoff_ms=sink_retry_backoff_ms,
                sink_errors=sink_errors,
                action=lambda sink=state["sink"]: _call_if_exists(
                    sink, "save_realtime_metrics", metric_values
                ),
            )

    def _emit_sink_lifecycle(
        self,
        *,
        sink_states: List[Dict[str, Any]],
        phase: str,
        sink_retry_count: int,
        sink_retry_backoff_ms: int,
        sink_errors: List[Dict[str, Any]],
        action: Callable[[Any], None],
        ignore_disabled: bool = False,
    ) -> None:
        for state in sink_states:
            self._invoke_sink_action(
                state=state,
                phase=phase,
                sink_retry_count=sink_retry_count,
                sink_retry_backoff_ms=sink_retry_backoff_ms,
                sink_errors=sink_errors,
                action=lambda sink=state["sink"]: action(sink),
                ignore_disabled=ignore_disabled,
            )

    def _emit_final_stats(
        self,
        *,
        sink_states: List[Dict[str, Any]],
        result: LoadStrikeNodeStats,
        sink_retry_count: int,
        sink_retry_backoff_ms: int,
        sink_errors: List[Dict[str, Any]],
    ) -> None:
        for state in sink_states:
            self._invoke_sink_action(
                state=state,
                phase="final",
                sink_retry_count=sink_retry_count,
                sink_retry_backoff_ms=sink_retry_backoff_ms,
                sink_errors=sink_errors,
                action=lambda sink=state["sink"]: _call_if_exists(sink, "save_final_stats", result),
            )

    def _emit_run_result(
        self,
        *,
        sink_states: List[Dict[str, Any]],
        result: Dict[str, Any],
        sink_retry_count: int,
        sink_retry_backoff_ms: int,
        sink_errors: List[Dict[str, Any]],
    ) -> None:
        for state in sink_states:
            self._invoke_sink_action(
                state=state,
                phase="run-result",
                sink_retry_count=sink_retry_count,
                sink_retry_backoff_ms=sink_retry_backoff_ms,
                sink_errors=sink_errors,
                action=lambda sink=state["sink"]: _call_if_exists(sink, "save_run_result", result),
            )

    def _invoke_sink_action(
        self,
        *,
        state: Dict[str, Any],
        phase: str,
        sink_retry_count: int,
        sink_retry_backoff_ms: int,
        sink_errors: List[Dict[str, Any]],
        action: Callable[[], None],
        ignore_disabled: bool = False,
    ) -> None:
        if bool(state.get("disabled")) and not ignore_disabled:
            return

        attempts = 0
        while attempts <= sink_retry_count:
            attempts += 1
            try:
                action()
                return
            except Exception as error:  # noqa: BLE001
                if attempts > sink_retry_count:
                    state["disabled"] = True
                    sink_errors.append(
                        {
                            "sinkName": state.get("name", "sink"),
                            "phase": phase,
                            "message": str(error),
                            "attempts": attempts,
                        }
                    )
                    return
                if sink_retry_backoff_ms > 0:
                    time.sleep((sink_retry_backoff_ms * attempts) / 1000.0)

    def _collect_plugin_data(
        self,
        plugins: List[LoadStrikeWorkerPlugin],
        result: LoadStrikeNodeStats,
        plugin_lifecycle_errors: Dict[str, List[str]],
    ) -> List[Dict[str, Any]]:
        rows: List[Dict[str, Any]] = []
        for plugin in plugins:
            plugin_name = _plugin_name(plugin)
            callback = getattr(plugin, "get_data", None)
            if not callable(callback):
                rows.append(
                    _with_lifecycle_errors(
                        {"pluginName": plugin_name, "tables": []},
                        plugin_name,
                        plugin_lifecycle_errors,
                    )
                )
                continue

            try:
                payload = _invoke_plugin_get_data(plugin, result)
                rows.append(
                    _with_lifecycle_errors(
                        _normalize_plugin_data(plugin_name, payload),
                        plugin_name,
                        plugin_lifecycle_errors,
                    )
                )
            except Exception as error:  # noqa: BLE001
                rows.append(
                    _with_lifecycle_errors(
                        {
                            "pluginName": plugin_name,
                            "tables": [
                                {
                                    "tableName": "errors",
                                    "headers": ["message"],
                                    "rows": [{"message": str(error)}],
                                }
                            ],
                        },
                        plugin_name,
                        plugin_lifecycle_errors,
                    )
                )
        return rows

    def _write_reports(self, result: Dict[str, Any]) -> List[str]:
        if not bool(self._options.get("reports_enabled", True)):
            return []

        report_folder = Path(str(self._options.get("report_folder_path", "./reports"))).resolve()
        report_file_name = _resolve_report_file_name(self._options, result)
        report_formats = _normalize_report_formats_value(
            self._options.get("report_formats") or ["html", "txt", "csv", "md"]
        )
        report_folder.mkdir(parents=True, exist_ok=True)
        node_stats = LoadStrikeNodeStats(result)

        written: List[str] = []
        for report_format in report_formats:
            path = report_folder / f"{report_file_name}.{report_format}"
            if report_format == "json":
                path.write_text(json.dumps(result, indent=2) + os.linesep, encoding="utf-8")
            elif report_format == "txt":
                path.write_text(_build_dotnet_txt_report(node_stats), encoding="utf-8")
            elif report_format == "csv":
                path.write_text(_build_dotnet_csv_report(node_stats), encoding="utf-8")
            elif report_format == "md":
                path.write_text(_build_dotnet_markdown_report(node_stats), encoding="utf-8")
            elif report_format == "html":
                path.write_text(_build_rich_html_report(result), encoding="utf-8")
            written.append(str(path))

        return written


class _LoadStrikeRunnerDualMethod:
    def __init__(self, instance_handler: Callable[..., Any], class_handler: Callable[..., Any]) -> None:
        self._instance_handler = instance_handler
        self._class_handler = class_handler

    def __get__(self, instance: Optional[LoadStrikeRunner], owner: type[LoadStrikeRunner]) -> Callable[..., Any]:
        if instance is None:
            return self._class_handler
        return self._instance_handler.__get__(instance, owner)


def _runner_static_run(context: LoadStrikeContext, *args: str) -> LoadStrikeNodeStats:
    if context is None:
        raise ValueError("context must be provided.")
    return context.run(*args)


def _runner_static_display_console_metrics(context: LoadStrikeContext, enable: bool) -> LoadStrikeContext:
    return context.display_console_metrics(enable)


def _runner_static_enable_local_dev_cluster(context: LoadStrikeContext, enable: bool) -> LoadStrikeContext:
    return context.enable_local_dev_cluster(enable)


def _runner_static_load_config(context: LoadStrikeContext, path: str) -> LoadStrikeContext:
    return context.load_config(path)


def _runner_static_load_infra_config(context: LoadStrikeContext, path: str) -> LoadStrikeContext:
    return context.load_infra_config(path)


def _runner_instance_with_agent_group(self: LoadStrikeRunner, agent_group: str) -> LoadStrikeRunner:
    return self.configure(lambda context: context.with_agent_group(agent_group))


def _runner_static_with_agent_group(context: LoadStrikeContext, agent_group: str) -> LoadStrikeContext:
    return context.with_agent_group(agent_group)


def _runner_instance_with_agents_count(self: LoadStrikeRunner, agents_count: int) -> LoadStrikeRunner:
    return self.configure(lambda context: context.with_agents_count(agents_count))


def _runner_static_with_agents_count(context: LoadStrikeContext, agents_count: int) -> LoadStrikeContext:
    return context.with_agents_count(agents_count)


def _runner_instance_with_agent_target_scenarios(
    self: LoadStrikeRunner,
    *scenario_names: str,
) -> LoadStrikeRunner:
    return self.configure(lambda context: context.with_agent_target_scenarios(*scenario_names))


def _runner_static_with_agent_target_scenarios(
    context: LoadStrikeContext,
    *scenario_names: str,
) -> LoadStrikeContext:
    return context.with_agent_target_scenarios(*scenario_names)


def _runner_instance_with_cluster_id(self: LoadStrikeRunner, cluster_id: str) -> LoadStrikeRunner:
    return self.configure(lambda context: context.with_cluster_id(cluster_id))


def _runner_static_with_cluster_id(context: LoadStrikeContext, cluster_id: str) -> LoadStrikeContext:
    return context.with_cluster_id(cluster_id)


def _runner_instance_with_coordinator_target_scenarios(
    self: LoadStrikeRunner,
    *scenario_names: str,
) -> LoadStrikeRunner:
    return self.configure(lambda context: context.with_coordinator_target_scenarios(*scenario_names))


def _runner_static_with_coordinator_target_scenarios(
    context: LoadStrikeContext,
    *scenario_names: str,
) -> LoadStrikeContext:
    return context.with_coordinator_target_scenarios(*scenario_names)


def _runner_instance_with_runner_key(self: LoadStrikeRunner, runner_key: str) -> LoadStrikeRunner:
    return self.configure(lambda context: context.with_runner_key(runner_key))


def _runner_static_with_runner_key(context: LoadStrikeContext, runner_key: str) -> LoadStrikeContext:
    return context.with_runner_key(runner_key)


def _runner_instance_with_license_validation_server_url(
    self: LoadStrikeRunner,
    server_url: str,
) -> LoadStrikeRunner:
    return self.configure(lambda context: context.with_license_validation_server_url(server_url))


def _runner_static_with_license_validation_server_url(
    context: LoadStrikeContext,
    server_url: str,
) -> LoadStrikeContext:
    return context.with_license_validation_server_url(server_url)


def _runner_instance_with_license_validation_timeout(
    self: LoadStrikeRunner,
    timeout_seconds: float,
) -> LoadStrikeRunner:
    return self.configure(lambda context: context.with_license_validation_timeout(timeout_seconds))


def _runner_static_with_license_validation_timeout(
    context: LoadStrikeContext,
    timeout_seconds: float,
) -> LoadStrikeContext:
    return context.with_license_validation_timeout(timeout_seconds)


def _runner_instance_with_logger_config(
    self: LoadStrikeRunner,
    logger_config: Callable[[], Any],
) -> LoadStrikeRunner:
    return self.configure(lambda context: context.with_logger_config(logger_config))


def _runner_static_with_logger_config(
    context: LoadStrikeContext,
    logger_config: Callable[[], Any],
) -> LoadStrikeContext:
    return context.with_logger_config(logger_config)


def _runner_instance_with_minimum_log_level(
    self: LoadStrikeRunner,
    minimum_log_level: str | LoadStrikeLogLevel,
) -> LoadStrikeRunner:
    return self.configure(lambda context: context.with_minimum_log_level(minimum_log_level))


def _runner_static_with_minimum_log_level(
    context: LoadStrikeContext,
    minimum_log_level: str | LoadStrikeLogLevel,
) -> LoadStrikeContext:
    return context.with_minimum_log_level(minimum_log_level)


def _runner_instance_with_nats_server_url(self: LoadStrikeRunner, nats_url: str) -> LoadStrikeRunner:
    return self.configure(lambda context: context.with_nats_server_url(nats_url))


def _runner_static_with_nats_server_url(context: LoadStrikeContext, nats_url: str) -> LoadStrikeContext:
    return context.with_nats_server_url(nats_url)


def _runner_instance_with_node_type(self: LoadStrikeRunner, node_type: str) -> LoadStrikeRunner:
    return self.configure(lambda context: context.with_node_type(node_type))


def _runner_static_with_node_type(context: LoadStrikeContext, node_type: str) -> LoadStrikeContext:
    return context.with_node_type(node_type)


def _runner_static_without_reports(context: LoadStrikeContext) -> LoadStrikeContext:
    return context.without_reports()


def _runner_instance_with_report_file_name(
    self: LoadStrikeRunner,
    report_file_name: str,
) -> LoadStrikeRunner:
    return self.configure(lambda context: context.with_report_file_name(report_file_name))


def _runner_static_with_report_file_name(context: LoadStrikeContext, report_file_name: str) -> LoadStrikeContext:
    return context.with_report_file_name(report_file_name)


def _runner_instance_with_report_finalizer(
    self: LoadStrikeRunner,
    handler: Callable[[LoadStrikeReportData], LoadStrikeReportData | Dict[str, Any]],
) -> LoadStrikeRunner:
    return self.configure(lambda context: context.with_report_finalizer(handler))


def _runner_static_with_report_finalizer(
    context: LoadStrikeContext,
    handler: Callable[[LoadStrikeReportData], LoadStrikeReportData | Dict[str, Any]],
) -> LoadStrikeContext:
    return context.with_report_finalizer(handler)


def _runner_instance_with_detailed_report_finalizer(
    self: LoadStrikeRunner,
    handler: Callable[[LoadStrikeNodeStats], LoadStrikeNodeStats | Dict[str, Any]],
) -> LoadStrikeRunner:
    return self.configure(lambda context: context.with_detailed_report_finalizer(handler))


def _runner_static_with_detailed_report_finalizer(
    context: LoadStrikeContext,
    handler: Callable[[LoadStrikeNodeStats], LoadStrikeNodeStats | Dict[str, Any]],
) -> LoadStrikeContext:
    return context.with_detailed_report_finalizer(handler)


def _runner_static_with_report_folder(context: LoadStrikeContext, report_folder_path: str) -> LoadStrikeContext:
    return context.with_report_folder(report_folder_path)


def _runner_instance_with_report_formats(self: LoadStrikeRunner, *report_formats: str) -> LoadStrikeRunner:
    return self.configure(lambda context: context.with_report_formats(*report_formats))


def _runner_static_with_report_formats(context: LoadStrikeContext, *report_formats: str) -> LoadStrikeContext:
    return context.with_report_formats(*report_formats)


def _runner_static_with_reporting_interval(
    context: LoadStrikeContext,
    interval_seconds: float,
) -> LoadStrikeContext:
    return context.with_reporting_interval(interval_seconds)


def _runner_instance_with_reporting_sinks(self: LoadStrikeRunner, *reporting_sinks: Any) -> LoadStrikeRunner:
    return self.configure(lambda context: context.with_reporting_sinks(*reporting_sinks))


def _runner_static_with_reporting_sinks(context: LoadStrikeContext, *reporting_sinks: Any) -> LoadStrikeContext:
    return context.with_reporting_sinks(*reporting_sinks)


def _runner_instance_with_scenario_completion_timeout(
    self: LoadStrikeRunner,
    timeout_seconds: float,
) -> LoadStrikeRunner:
    return self.configure(lambda context: context.with_scenario_completion_timeout(timeout_seconds))


def _runner_static_with_scenario_completion_timeout(
    context: LoadStrikeContext,
    timeout_seconds: float,
) -> LoadStrikeContext:
    return context.with_scenario_completion_timeout(timeout_seconds)


def _runner_static_with_cluster_command_timeout(
    context: LoadStrikeContext,
    timeout_seconds: float,
) -> LoadStrikeContext:
    return context.with_cluster_command_timeout(timeout_seconds)


def _runner_static_with_restart_iteration_max_attempts(
    context: LoadStrikeContext,
    attempts: int,
) -> LoadStrikeContext:
    return context.with_restart_iteration_max_attempts(attempts)


def _runner_static_with_session_id(context: LoadStrikeContext, session_id: str) -> LoadStrikeContext:
    return context.with_session_id(session_id)


def _runner_instance_with_target_scenarios(
    self: LoadStrikeRunner,
    *scenario_names: str,
) -> LoadStrikeRunner:
    return self.configure(lambda context: context.with_target_scenarios(*scenario_names))


def _runner_static_with_target_scenarios(context: LoadStrikeContext, *scenario_names: str) -> LoadStrikeContext:
    return context.with_target_scenarios(*scenario_names)


def _runner_static_with_test_name(context: LoadStrikeContext, test_name: str) -> LoadStrikeContext:
    return context.with_test_name(test_name)


def _runner_static_with_test_suite(context: LoadStrikeContext, test_suite: str) -> LoadStrikeContext:
    return context.with_test_suite(test_suite)


def _runner_instance_with_worker_plugins(self: LoadStrikeRunner, *plugins: Any) -> LoadStrikeRunner:
    return self.configure(lambda context: context.with_worker_plugins(*plugins))


def _runner_static_with_worker_plugins(context: LoadStrikeContext, *plugins: Any) -> LoadStrikeContext:
    return context.with_worker_plugins(*plugins)


LoadStrikeRunner.Run = _LoadStrikeRunnerDualMethod(LoadStrikeRunner.run, _runner_static_run)
LoadStrikeRunner.DisplayConsoleMetrics = _LoadStrikeRunnerDualMethod(
    LoadStrikeRunner.display_console_metrics,
    _runner_static_display_console_metrics,
)
LoadStrikeRunner.EnableLocalDevCluster = _LoadStrikeRunnerDualMethod(
    LoadStrikeRunner.enable_local_dev_cluster,
    _runner_static_enable_local_dev_cluster,
)
LoadStrikeRunner.LoadConfig = _LoadStrikeRunnerDualMethod(
    LoadStrikeRunner.load_config,
    _runner_static_load_config,
)
LoadStrikeRunner.LoadInfraConfig = _LoadStrikeRunnerDualMethod(
    LoadStrikeRunner.load_infra_config,
    _runner_static_load_infra_config,
)
LoadStrikeRunner.WithAgentGroup = _LoadStrikeRunnerDualMethod(
    _runner_instance_with_agent_group,
    _runner_static_with_agent_group,
)
LoadStrikeRunner.WithAgentsCount = _LoadStrikeRunnerDualMethod(
    _runner_instance_with_agents_count,
    _runner_static_with_agents_count,
)
LoadStrikeRunner.WithAgentTargetScenarios = _LoadStrikeRunnerDualMethod(
    _runner_instance_with_agent_target_scenarios,
    _runner_static_with_agent_target_scenarios,
)
LoadStrikeRunner.WithClusterId = _LoadStrikeRunnerDualMethod(
    _runner_instance_with_cluster_id,
    _runner_static_with_cluster_id,
)
LoadStrikeRunner.WithCoordinatorTargetScenarios = _LoadStrikeRunnerDualMethod(
    _runner_instance_with_coordinator_target_scenarios,
    _runner_static_with_coordinator_target_scenarios,
)
LoadStrikeRunner.WithRunnerKey = _LoadStrikeRunnerDualMethod(
    _runner_instance_with_runner_key,
    _runner_static_with_runner_key,
)
LoadStrikeRunner.WithLicenseValidationServerUrl = _LoadStrikeRunnerDualMethod(
    _runner_instance_with_license_validation_server_url,
    _runner_static_with_license_validation_server_url,
)
LoadStrikeRunner.WithLicenseValidationTimeout = _LoadStrikeRunnerDualMethod(
    _runner_instance_with_license_validation_timeout,
    _runner_static_with_license_validation_timeout,
)
LoadStrikeRunner.WithLoggerConfig = _LoadStrikeRunnerDualMethod(
    _runner_instance_with_logger_config,
    _runner_static_with_logger_config,
)
LoadStrikeRunner.WithMinimumLogLevel = _LoadStrikeRunnerDualMethod(
    _runner_instance_with_minimum_log_level,
    _runner_static_with_minimum_log_level,
)
LoadStrikeRunner.WithNatsServerUrl = _LoadStrikeRunnerDualMethod(
    _runner_instance_with_nats_server_url,
    _runner_static_with_nats_server_url,
)
LoadStrikeRunner.WithNodeType = _LoadStrikeRunnerDualMethod(
    _runner_instance_with_node_type,
    _runner_static_with_node_type,
)
LoadStrikeRunner.WithoutReports = _LoadStrikeRunnerDualMethod(
    LoadStrikeRunner.without_reports,
    _runner_static_without_reports,
)
LoadStrikeRunner.WithReportFileName = _LoadStrikeRunnerDualMethod(
    _runner_instance_with_report_file_name,
    _runner_static_with_report_file_name,
)
LoadStrikeRunner.WithReportFinalizer = _LoadStrikeRunnerDualMethod(
    _runner_instance_with_report_finalizer,
    _runner_static_with_report_finalizer,
)
LoadStrikeRunner.WithDetailedReportFinalizer = _LoadStrikeRunnerDualMethod(
    _runner_instance_with_detailed_report_finalizer,
    _runner_static_with_detailed_report_finalizer,
)
LoadStrikeRunner.WithReportFolder = _LoadStrikeRunnerDualMethod(
    LoadStrikeRunner.with_report_folder,
    _runner_static_with_report_folder,
)
LoadStrikeRunner.WithReportFormats = _LoadStrikeRunnerDualMethod(
    _runner_instance_with_report_formats,
    _runner_static_with_report_formats,
)
LoadStrikeRunner.WithReportingInterval = _LoadStrikeRunnerDualMethod(
    LoadStrikeRunner.with_reporting_interval,
    _runner_static_with_reporting_interval,
)
LoadStrikeRunner.WithReportingSinks = _LoadStrikeRunnerDualMethod(
    _runner_instance_with_reporting_sinks,
    _runner_static_with_reporting_sinks,
)
LoadStrikeRunner.WithScenarioCompletionTimeout = _LoadStrikeRunnerDualMethod(
    _runner_instance_with_scenario_completion_timeout,
    _runner_static_with_scenario_completion_timeout,
)
LoadStrikeRunner.WithClusterCommandTimeout = _LoadStrikeRunnerDualMethod(
    LoadStrikeRunner.with_cluster_command_timeout,
    _runner_static_with_cluster_command_timeout,
)
LoadStrikeRunner.WithRestartIterationMaxAttempts = _LoadStrikeRunnerDualMethod(
    LoadStrikeRunner.with_restart_iteration_max_attempts,
    _runner_static_with_restart_iteration_max_attempts,
)
LoadStrikeRunner.WithSessionId = _LoadStrikeRunnerDualMethod(
    LoadStrikeRunner.with_session_id,
    _runner_static_with_session_id,
)
LoadStrikeRunner.WithTargetScenarios = _LoadStrikeRunnerDualMethod(
    _runner_instance_with_target_scenarios,
    _runner_static_with_target_scenarios,
)
LoadStrikeRunner.WithTestName = _LoadStrikeRunnerDualMethod(
    LoadStrikeRunner.with_test_name,
    _runner_static_with_test_name,
)
LoadStrikeRunner.WithTestSuite = _LoadStrikeRunnerDualMethod(
    LoadStrikeRunner.with_test_suite,
    _runner_static_with_test_suite,
)
LoadStrikeRunner.WithWorkerPlugins = _LoadStrikeRunnerDualMethod(
    _runner_instance_with_worker_plugins,
    _runner_static_with_worker_plugins,
)


def _normalize_node_type_value(value: Any) -> str:
    normalized = str(value or "").strip().lower()
    if normalized in {"1", "coordinator"}:
        return "coordinator"
    if normalized in {"2", "agent"}:
        return "agent"
    return "singlenode"


def _plan_cluster_agent_assignments(
    scenarios: List[LoadStrikeScenario],
    options: Dict[str, Any],
) -> List[List[str]]:
    agent_count = max(_as_int(options.get("agents_count") or 1), 0)
    selected_names = _normalize_string_list(options.get("agent_target_scenarios"))
    if not selected_names:
        selected_names = _normalize_string_list(options.get("target_scenarios"))
    coordinator_names = {name.lower() for name in _normalize_string_list(options.get("coordinator_target_scenarios"))}
    if coordinator_names:
        if selected_names:
            selected_names = [name for name in selected_names if name.lower() not in coordinator_names]
        else:
            selected_names = [
                scenario.name
                for scenario in scenarios
                if scenario.name.lower() not in coordinator_names
            ]
    return plan_agent_scenario_assignments(
        scenario_names=[scenario.name for scenario in scenarios],
        agent_count=agent_count,
        options={"selectedScenarioNames": selected_names} if selected_names else None,
    )


def _build_empty_node_result(
    options: Dict[str, Any],
    node_type: str,
    machine_name: str,
) -> Dict[str, Any]:
    now = datetime.now(timezone.utc).isoformat()
    test_info = _build_test_info(options, now)
    node_info = _build_node_info({**options, "node_type": node_type, "machine_name": machine_name})
    return {
        "startedUtc": now,
        "completedUtc": now,
        "allRequestCount": 0,
        "allOkCount": 0,
        "allFailCount": 0,
        "allBytes": 0,
        "durationMs": 0,
        "failedThresholds": 0,
        "thresholdResults": [],
        "metricStats": _build_metric_stats_payload([], 0),
        "metrics": [],
        "scenarioStats": [],
        "stepStats": [],
        "scenarioDurationsMs": {},
        "nodeInfo": node_info,
        "testInfo": test_info,
        "pluginsData": [],
        "disabledSinks": [],
        "sinkErrors": [],
        "reportFiles": [],
    }


def _synthetic_cluster_failure_result(
    options: Dict[str, Any],
    node_row: Dict[str, Any],
) -> Dict[str, Any]:
    machine_name = str(node_row.get("nodeId") or "cluster-node")
    result = _build_empty_node_result(options, "Agent", machine_name)
    result["completedUtc"] = datetime.now(timezone.utc).isoformat()
    result["failedThresholds"] = 1
    result["thresholdResults"] = [
        {
            "scenarioName": "",
            "scope": "scenario",
            "stepName": "",
            "checkExpression": "cluster-node-runtime",
            "isFailed": True,
            "errorCount": 1,
            "exceptionMessage": str(node_row.get("error") or "Cluster node failed to produce a detailed result."),
            "exceptionMsg": str(node_row.get("error") or "Cluster node failed to produce a detailed result."),
        }
    ]
    result["nodeInfo"]["nodeType"] = "Agent"
    result["nodeInfo"]["machineName"] = machine_name
    result["nodeInfo"]["currentOperation"] = "Error"
    return result


def _aggregate_node_detailed_results(
    node_results: List[Dict[str, Any]],
    options: Dict[str, Any],
    coordinator_node_type: str,
) -> Dict[str, Any]:
    valid_nodes = [dict(node) for node in node_results if isinstance(node, dict)]
    if not valid_nodes:
        return _build_empty_node_result(options, coordinator_node_type, _build_node_info(options).get("machineName", "local-machine"))

    scenario_order: Dict[str, int] = {}
    for index, scenario_name in enumerate(
        _normalize_string_list(options.get("target_scenarios"))
        or _normalize_string_list(options.get("agent_target_scenarios"))
        or [str(row.get("scenarioName") or "") for node in valid_nodes for row in node.get("scenarioStats", []) if isinstance(row, dict)]
    ):
        if scenario_name and scenario_name not in scenario_order:
            scenario_order[scenario_name] = index

    scenario_durations_ms: Dict[str, int] = {}
    scenario_groups: Dict[str, List[Dict[str, Any]]] = {}
    metric_groups: Dict[str, List[Dict[str, Any]]] = {}
    threshold_groups: Dict[str, Dict[str, Any]] = {}
    plugin_groups: Dict[str, Dict[str, Any]] = {}
    started_values: List[datetime] = []
    completed_values: List[datetime] = []
    all_bytes = 0
    duration_candidates_ms: List[int] = []

    for node in valid_nodes:
        started_dt = _try_parse_datetime(node.get("startedUtc"))
        completed_dt = _try_parse_datetime(node.get("completedUtc"))
        if started_dt is not None:
            started_values.append(started_dt)
        if completed_dt is not None:
            completed_values.append(completed_dt)

        all_bytes += _as_int(node.get("allBytes"))
        duration_candidates_ms.append(_as_int(node.get("durationMs")))

        for name, duration in dict(node.get("scenarioDurationsMs") or {}).items():
            scenario_name = str(name or "").strip()
            if scenario_name:
                scenario_durations_ms[scenario_name] = max(
                    scenario_durations_ms.get(scenario_name, 0),
                    _as_int(duration),
                )

        for row in node.get("scenarioStats", []):
            if not isinstance(row, dict):
                continue
            scenario_name = str(row.get("scenarioName") or "").strip()
            if not scenario_name:
                continue
            scenario_groups.setdefault(scenario_name, []).append(dict(row))

        for metric in node.get("metrics", []):
            if not isinstance(metric, dict):
                continue
            normalized = _normalize_metric_value(metric)
            if normalized is None:
                continue
            metric_groups.setdefault(_metric_merge_key(normalized), []).append(dict(normalized))

        for threshold in node.get("thresholdResults", []):
            if not isinstance(threshold, dict):
                continue
            key = "|".join(
                [
                    str(threshold.get("scenarioName") or ""),
                    str(threshold.get("stepName") or ""),
                    str(threshold.get("checkExpression") or ""),
                ]
            )
            existing = threshold_groups.get(key)
            if existing is None:
                existing = {
                    "scenarioName": str(threshold.get("scenarioName") or ""),
                    "scope": str(threshold.get("scope") or "scenario"),
                    "stepName": str(threshold.get("stepName") or ""),
                    "checkExpression": str(threshold.get("checkExpression") or ""),
                    "isFailed": bool(threshold.get("isFailed")),
                    "errorCount": 0,
                    "exceptionMessage": "",
                    "exceptionMsg": "",
                }
                threshold_groups[key] = existing
            existing["errorCount"] = _as_int(existing.get("errorCount")) + _as_int(threshold.get("errorCount"))
            existing["isFailed"] = bool(existing.get("isFailed")) or bool(threshold.get("isFailed"))
            messages = [
                str(existing.get("exceptionMsg") or existing.get("exceptionMessage") or "").strip(),
                str(threshold.get("exceptionMsg") or threshold.get("exceptionMessage") or "").strip(),
            ]
            merged_message = " | ".join(dict.fromkeys([message for message in messages if message]))
            existing["exceptionMessage"] = merged_message
            existing["exceptionMsg"] = merged_message

        for plugin in node.get("pluginsData", []):
            if not isinstance(plugin, dict):
                continue
            plugin_name = str(plugin.get("pluginName") or "unnamed-plugin")
            merged_plugin = plugin_groups.setdefault(
                plugin_name,
                {"pluginName": plugin_name, "hints": [], "tables": {}},
            )
            for hint in plugin.get("hints", []) or []:
                text = str(hint or "").strip()
                if text and text not in merged_plugin["hints"]:
                    merged_plugin["hints"].append(text)
            for table in plugin.get("tables", []) or []:
                if not isinstance(table, dict):
                    continue
                table_name = str(table.get("tableName") or "table")
                merged_table = merged_plugin["tables"].setdefault(
                    table_name,
                    {
                        "tableName": table_name,
                        "headers": list(table.get("headers") or []),
                        "rows": [],
                    },
                )
                merged_table["rows"].extend(
                    dict(row)
                    for row in list(table.get("rows") or [])
                    if isinstance(row, dict)
                )

    started_dt = min(started_values) if started_values else datetime.now(timezone.utc)
    completed_dt = max(completed_values) if completed_values else datetime.now(timezone.utc)
    started_utc = started_dt.isoformat()
    completed_utc = completed_dt.isoformat()
    test_info = dict(valid_nodes[0].get("testInfo") or _build_test_info(options, started_utc))
    node_info = _build_node_info({**options, "node_type": coordinator_node_type})
    node_info["nodeType"] = coordinator_node_type

    ordered_scenario_rows: List[Dict[str, Any]] = []
    for scenario_name, items in sorted(
        scenario_groups.items(),
        key=lambda pair: scenario_order.get(pair[0], len(scenario_order)),
    ):
        duration_ms = max(
            max(_as_int(item.get("durationMs")) for item in items),
            _as_int(scenario_durations_ms.get(scenario_name)),
        )
        all_request_count = sum(_as_int(item.get("allRequestCount")) for item in items)
        ok = _aggregate_measurement_rows(
            [item.get("ok") for item in items if isinstance(item.get("ok"), dict)],
            all_request_count,
            duration_ms,
        )
        fail = _aggregate_measurement_rows(
            [item.get("fail") for item in items if isinstance(item.get("fail"), dict)],
            all_request_count,
            duration_ms,
        )

        step_groups: Dict[str, List[Dict[str, Any]]] = {}
        for item in items:
            for step in item.get("stepStats", []) or []:
                if not isinstance(step, dict):
                    continue
                step_name = str(step.get("stepName") or "").strip()
                if step_name:
                    step_groups.setdefault(step_name, []).append(dict(step))

        step_rows: List[Dict[str, Any]] = []
        for step_name, step_items in sorted(
            step_groups.items(),
            key=lambda pair: min(_as_int(item.get("sortIndex")) for item in pair[1]),
        ):
            step_ok = _aggregate_measurement_rows(
                [item.get("ok") for item in step_items if isinstance(item.get("ok"), dict)],
                all_request_count,
                duration_ms,
            )
            step_fail = _aggregate_measurement_rows(
                [item.get("fail") for item in step_items if isinstance(item.get("fail"), dict)],
                all_request_count,
                duration_ms,
            )
            step_rows.append(
                _step_row_from_measurements(
                    scenario_name=scenario_name,
                    step_name=step_name,
                    sort_index=min(_as_int(item.get("sortIndex")) for item in step_items),
                    ok=step_ok,
                    fail=step_fail,
                )
            )

        load_simulation_stats = next(
            (
                dict(item.get("loadSimulationStats"))
                for item in items
                if isinstance(item.get("loadSimulationStats"), dict)
                and str(item.get("loadSimulationStats", {}).get("simulationName") or "").strip()
            ),
            {"simulationName": "", "value": 0},
        )

        ordered_scenario_rows.append(
            _scenario_row_from_measurements(
                scenario_name=scenario_name,
                sort_index=min(_as_int(item.get("sortIndex")) for item in items),
                current_operation=_select_operation(str(item.get("currentOperation") or "") for item in items),
                duration_ms=duration_ms,
                load_simulation_stats=load_simulation_stats,
                ok=ok,
                fail=fail,
                step_rows=step_rows,
            )
        )

    ordered_step_rows = _flatten_step_stats(ordered_scenario_rows)
    aggregated_metrics: List[Dict[str, Any]] = []
    for key in sorted(metric_groups):
        rows = metric_groups[key]
        if not rows:
            continue
        first = dict(rows[0])
        if str(first.get("type") or "").lower() == "counter":
            first["value"] = sum(_as_float(row.get("value")) for row in rows)
        else:
            first["value"] = _weighted_average(
                [_as_float(row.get("value")) for row in rows],
                [1 for _ in rows],
            )
        aggregated_metrics.append(first)

    aggregated_thresholds = list(threshold_groups.values())
    aggregated_plugins = [
        {
            "pluginName": plugin_name,
            "hints": list(payload.get("hints") or []),
            "tables": list((payload.get("tables") or {}).values()),
        }
        for plugin_name, payload in plugin_groups.items()
    ]
    duration_ms = max([max(duration_candidates_ms or [0]), int((completed_dt - started_dt).total_seconds() * 1000)])
    return {
        "startedUtc": started_utc,
        "completedUtc": completed_utc,
        "allRequestCount": sum(_as_int(x.get("allRequestCount")) for x in ordered_scenario_rows),
        "allOkCount": sum(_as_int(x.get("allOkCount")) for x in ordered_scenario_rows),
        "allFailCount": sum(_as_int(x.get("allFailCount")) for x in ordered_scenario_rows),
        "allBytes": all_bytes or sum(_as_int(x.get("allBytes")) for x in ordered_scenario_rows),
        "durationMs": duration_ms,
        "runDurationMs": duration_ms,
        "failedThresholds": sum(1 for row in aggregated_thresholds if bool(row.get("isFailed"))),
        "thresholdResults": aggregated_thresholds,
        "metricStats": _build_metric_stats_payload(aggregated_metrics, duration_ms),
        "metrics": aggregated_metrics,
        "scenarioStats": ordered_scenario_rows,
        "stepStats": ordered_step_rows,
        "scenarioDurationsMs": scenario_durations_ms,
        "nodeInfo": node_info,
        "testInfo": test_info,
        "pluginsData": aggregated_plugins,
        "disabledSinks": [],
        "sinkErrors": [],
        "reportFiles": [],
        "nodeResults": valid_nodes,
    }

def _weighted_average(values: List[float], weights: List[int]) -> float:
    if not values or not weights or len(values) != len(weights):
        return 0.0
    weighted_sum = 0.0
    total_weight = 0
    for value, weight in zip(values, weights):
        normalized_weight = max(int(weight), 0)
        weighted_sum += float(value) * normalized_weight
        total_weight += normalized_weight
    return 0.0 if total_weight <= 0 else weighted_sum / total_weight


def _aggregate_measurement_rows(
    measurements: List[Any],
    all_request_count: int,
    duration_ms: int,
) -> Dict[str, Any]:
    normalized_measurements = [dict(measurement) for measurement in measurements if isinstance(measurement, dict)]
    if not normalized_measurements:
        return {
            "request": {"count": 0, "percent": 0, "rps": 0.0},
            "dataTransfer": {
                "allBytes": 0,
                "minBytes": 0,
                "maxBytes": 0,
                "meanBytes": 0,
                "percent50": 0,
                "percent75": 0,
                "percent95": 0,
                "percent99": 0,
                "stdDev": 0.0,
            },
            "latency": {
                "latencyCount": {"lessOrEq800": 0, "more800Less1200": 0, "moreOrEq1200": 0},
                "minMs": 0.0,
                "maxMs": 0.0,
                "meanMs": 0.0,
                "percent50": 0.0,
                "percent75": 0.0,
                "percent95": 0.0,
                "percent99": 0.0,
                "stdDev": 0.0,
            },
            "statusCodes": [],
        }

    counts = [
        _as_int(measurement.get("request", {}).get("count"))
        for measurement in normalized_measurements
    ]
    total_count = sum(counts)
    data_transfer_rows = [
        measurement.get("dataTransfer", {})
        if isinstance(measurement.get("dataTransfer"), dict)
        else {}
        for measurement in normalized_measurements
    ]
    latency_rows = [
        measurement.get("latency", {})
        if isinstance(measurement.get("latency"), dict)
        else {}
        for measurement in normalized_measurements
    ]
    status_code_groups: Dict[str, Dict[str, Any]] = {}
    for measurement in normalized_measurements:
        for status_row in measurement.get("statusCodes", []) or []:
            if not isinstance(status_row, dict):
                continue
            key = "|".join(
                [
                    str(status_row.get("statusCode") or ""),
                    str(status_row.get("message") or ""),
                    "1" if bool(status_row.get("isError")) else "0",
                ]
            )
            existing = status_code_groups.get(key)
            if existing is None:
                existing = {
                    "statusCode": str(status_row.get("statusCode") or ""),
                    "message": str(status_row.get("message") or ""),
                    "isError": bool(status_row.get("isError")),
                    "count": 0,
                    "percent": 0,
                }
                status_code_groups[key] = existing
            existing["count"] = _as_int(existing.get("count")) + _as_int(status_row.get("count"))

    status_codes = list(status_code_groups.values())
    status_codes.sort(key=lambda row: -_as_int(row.get("count")))
    for row in status_codes:
        row["percent"] = 0 if total_count <= 0 else _round_midpoint_away_from_zero(100.0 * _as_int(row.get("count")) / total_count)

    duration_seconds = max(duration_ms, 0) / 1000.0
    return {
        "request": {
            "count": total_count,
            "percent": 0 if all_request_count <= 0 else _round_midpoint_away_from_zero(100.0 * total_count / all_request_count),
            "rps": 0.0 if duration_seconds <= 0 else total_count / duration_seconds,
        },
        "dataTransfer": {
            "allBytes": sum(_as_int(row.get("allBytes")) for row in data_transfer_rows),
            "minBytes": min((_as_int(row.get("minBytes")) for row in data_transfer_rows), default=0),
            "maxBytes": max((_as_int(row.get("maxBytes")) for row in data_transfer_rows), default=0),
            "meanBytes": _round_midpoint_away_from_zero(_weighted_average([_as_float(row.get("meanBytes")) for row in data_transfer_rows], counts)),
            "percent50": _round_midpoint_away_from_zero(_weighted_average([_as_float(row.get("percent50")) for row in data_transfer_rows], counts)),
            "percent75": _round_midpoint_away_from_zero(_weighted_average([_as_float(row.get("percent75")) for row in data_transfer_rows], counts)),
            "percent95": _round_midpoint_away_from_zero(_weighted_average([_as_float(row.get("percent95")) for row in data_transfer_rows], counts)),
            "percent99": _round_midpoint_away_from_zero(_weighted_average([_as_float(row.get("percent99")) for row in data_transfer_rows], counts)),
            "stdDev": _weighted_average([_as_float(row.get("stdDev")) for row in data_transfer_rows], counts),
        },
        "latency": {
            "latencyCount": {
                "lessOrEq800": sum(_as_int((row.get("latencyCount") or {}).get("lessOrEq800")) for row in latency_rows),
                "more800Less1200": sum(_as_int((row.get("latencyCount") or {}).get("more800Less1200")) for row in latency_rows),
                "moreOrEq1200": sum(_as_int((row.get("latencyCount") or {}).get("moreOrEq1200")) for row in latency_rows),
            },
            "minMs": min((_as_float(row.get("minMs")) for row in latency_rows), default=0.0),
            "maxMs": max((_as_float(row.get("maxMs")) for row in latency_rows), default=0.0),
            "meanMs": _weighted_average([_as_float(row.get("meanMs")) for row in latency_rows], counts),
            "percent50": _weighted_average([_as_float(row.get("percent50")) for row in latency_rows], counts),
            "percent75": _weighted_average([_as_float(row.get("percent75")) for row in latency_rows], counts),
            "percent95": _weighted_average([_as_float(row.get("percent95")) for row in latency_rows], counts),
            "percent99": _weighted_average([_as_float(row.get("percent99")) for row in latency_rows], counts),
            "stdDev": _weighted_average([_as_float(row.get("stdDev")) for row in latency_rows], counts),
        },
        "statusCodes": status_codes,
    }


def _scenario_row_from_measurements(
    *,
    scenario_name: str,
    sort_index: int,
    current_operation: str,
    duration_ms: int,
    load_simulation_stats: Dict[str, Any],
    ok: Dict[str, Any],
    fail: Dict[str, Any],
    step_rows: List[Dict[str, Any]],
) -> Dict[str, Any]:
    ok_totals = _measurement_totals(ok)
    fail_totals = _measurement_totals(fail)
    total_count = ok_totals["count"] + fail_totals["count"]
    min_latency_candidates = [
        value
        for value, count in (
            (ok_totals["minLatencyMs"], ok_totals["count"]),
            (fail_totals["minLatencyMs"], fail_totals["count"]),
        )
        if count > 0
    ]
    total_latency_ms = ok_totals["totalLatencyMs"] + fail_totals["totalLatencyMs"]
    return {
        "scenarioName": scenario_name,
        "sortIndex": sort_index,
        "currentOperation": current_operation or "None",
        "durationMs": max(int(duration_ms), 0),
        "loadSimulationStats": dict(load_simulation_stats or {"simulationName": "", "value": 0}),
        "ok": ok,
        "fail": fail,
        "stepStats": step_rows,
        "allBytes": ok_totals["allBytes"] + fail_totals["allBytes"],
        "allFailCount": fail_totals["count"],
        "allOkCount": ok_totals["count"],
        "allRequestCount": total_count,
        "totalBytes": ok_totals["allBytes"] + fail_totals["allBytes"],
        "totalLatencyMs": total_latency_ms,
        "avgLatencyMs": 0.0 if total_count <= 0 else total_latency_ms / total_count,
        "minLatencyMs": 0.0 if not min_latency_candidates else min(min_latency_candidates),
        "maxLatencyMs": max(ok_totals["maxLatencyMs"], fail_totals["maxLatencyMs"]),
        "statusCodes": _merge_status_code_counts(ok, fail),
    }


def _step_row_from_measurements(
    *,
    scenario_name: str,
    step_name: str,
    sort_index: int,
    ok: Dict[str, Any],
    fail: Dict[str, Any],
) -> Dict[str, Any]:
    ok_totals = _measurement_totals(ok)
    fail_totals = _measurement_totals(fail)
    total_count = ok_totals["count"] + fail_totals["count"]
    min_latency_candidates = [
        value
        for value, count in (
            (ok_totals["minLatencyMs"], ok_totals["count"]),
            (fail_totals["minLatencyMs"], fail_totals["count"]),
        )
        if count > 0
    ]
    total_latency_ms = ok_totals["totalLatencyMs"] + fail_totals["totalLatencyMs"]
    return {
        "scenarioName": scenario_name,
        "stepName": step_name,
        "sortIndex": sort_index,
        "ok": ok,
        "fail": fail,
        "okCount": ok_totals["count"],
        "failCount": fail_totals["count"],
        "requestCount": total_count,
        "allBytes": ok_totals["allBytes"] + fail_totals["allBytes"],
        "totalBytes": ok_totals["allBytes"] + fail_totals["allBytes"],
        "totalLatencyMs": total_latency_ms,
        "avgLatencyMs": 0.0 if total_count <= 0 else total_latency_ms / total_count,
        "minLatencyMs": 0.0 if not min_latency_candidates else min(min_latency_candidates),
        "maxLatencyMs": max(ok_totals["maxLatencyMs"], fail_totals["maxLatencyMs"]),
        "statusCodes": _merge_status_code_counts(ok, fail),
    }


def _select_operation(values: Any) -> str:
    operations = [str(value or "").strip() for value in list(values) if str(value or "").strip()]
    for candidate in ("Error", "Stop", "Bombing", "WarmUp", "Init", "Complete", "None"):
        if candidate in operations:
            return candidate
    return "None"


def _print_console_snapshot(base_logger: Any, scenario_stats: List[Dict[str, Any]]) -> None:
    all_ok = sum(_as_int(row.get("allOkCount")) for row in scenario_stats if isinstance(row, dict))
    all_fail = sum(_as_int(row.get("allFailCount")) for row in scenario_stats if isinstance(row, dict))
    all_requests = sum(_as_int(row.get("allRequestCount")) for row in scenario_stats if isinstance(row, dict))
    message = f"[{datetime.now().strftime('%H:%M:%S')}] requests={all_requests} ok={all_ok} fail={all_fail}"
    callback = getattr(base_logger, "info", None)
    if callable(callback):
        try:
            callback(message)
        except Exception:  # noqa: BLE001
            pass
    print(message)


def _resolve_report_file_name(options: Dict[str, Any], result: Dict[str, Any]) -> str:
    raw_explicit = "" if options.get("report_file_name") is None else str(options.get("report_file_name"))
    if raw_explicit.strip():
        return _sanitize_report_file_name(raw_explicit)

    test_info = result.get("testInfo") if isinstance(result.get("testInfo"), dict) else {}
    base_name = (
        f"{str(test_info.get('testSuite') or 'loadstrike')}_"
        f"{str(test_info.get('testName') or 'loadstrike-test')}_"
        f"{datetime.now(timezone.utc):%Y%m%d_%H%M%S}"
    )
    return _sanitize_report_file_name(base_name)


def _sanitize_report_file_name(value: str) -> str:
    sanitized = "".join(
        "_" if ch in '<>:"/\\|?*' or ord(ch) < 32 else ch
        for ch in str(value or "")
    )
    return sanitized or "loadstrike-report"


def _try_parse_datetime(value: Any) -> Optional[datetime]:
    text = str(value or "").strip()
    if not text:
        return None
    try:
        return datetime.fromisoformat(text.replace("Z", "+00:00"))
    except ValueError:
        return None


def _compute_warm_up_iterations(scenario: LoadStrikeScenario, bombing_iterations: int) -> int:
    if scenario.without_warm_up_enabled:
        return 0
    if scenario.warm_up_duration_seconds > 0:
        return max(int(scenario.warm_up_duration_seconds + 0.999999), 1)
    _ = bombing_iterations
    return 0


def _build_test_info(options: Dict[str, Any], created_utc: str) -> Dict[str, Any]:
    session_id = str(options.get("session_id") or "").strip()
    if not session_id:
        session_id = _generate_session_id()
    return {
        "clusterId": str(options.get("cluster_id") or "local"),
        "sessionId": session_id,
        "testSuite": str(options.get("test_suite") or "loadstrike"),
        "testName": str(options.get("test_name") or "loadstrike-test"),
        "createdUtc": created_utc,
    }


def _build_node_info(options: Dict[str, Any]) -> Dict[str, Any]:
    return {
        "machineName": str(options.get("machine_name") or "local-machine"),
        "nodeType": _canonical_node_type_name(options.get("node_type")),
        "engineVersion": "loadstrike-python-sdk",
        "currentOperation": "Complete",
        "coresCount": max(os.cpu_count() or 1, 1),
        "os": os.name,
        "processor": "",
        "dotNetVersion": "",
    }


def _build_scenario_info(
    scenario_name: str,
    operation: str,
    *,
    instance_number: int = 1,
    instance_id: Optional[str] = None,
    scenario_started_ms: Optional[int] = None,
) -> Dict[str, Any]:
    elapsed_ms = 0
    if scenario_started_ms is not None and scenario_started_ms > 0:
        elapsed_ms = max(int(time.time() * 1000) - int(scenario_started_ms), 0)
    return {
        "scenarioName": scenario_name,
        "instanceId": str(instance_id or f"{scenario_name}-{max(int(instance_number), 1)}"),
        "instanceNumber": max(int(instance_number), 0),
        "scenarioOperation": operation,
        "scenarioDurationMs": elapsed_ms,
        "scenarioDuration": _timedelta_from_ms(elapsed_ms),
    }


def _create_logger(
    logger_config: Any = None,
    minimum_log_level: Any = None,
) -> Any:
    class _NoopLogger:
        def debug(self, _message: str) -> None:
            return

        def info(self, _message: str) -> None:
            return

        def warn(self, _message: str) -> None:
            return

        def error(self, _message: str) -> None:
            return

    base_logger: Any = _NoopLogger()
    if callable(logger_config):
        try:
            configured = logger_config()
            if configured is not None:
                base_logger = configured
        except Exception:  # noqa: BLE001
            base_logger = _NoopLogger()

    threshold = _log_level_order(minimum_log_level)

    class _FilteredLogger:
        def debug(self, message: str) -> None:
            if threshold <= 1 and hasattr(base_logger, "debug"):
                base_logger.debug(message)

        def info(self, message: str) -> None:
            if threshold <= 2 and hasattr(base_logger, "info"):
                base_logger.info(message)

        def warn(self, message: str) -> None:
            if threshold <= 3 and hasattr(base_logger, "warn"):
                base_logger.warn(message)

        def error(self, message: str) -> None:
            if threshold <= 4 and hasattr(base_logger, "error"):
                base_logger.error(message)

    return _FilteredLogger()


def _log_level_order(value: Any) -> int:
    normalized = str(value or "").strip().lower()
    if not normalized:
        return 1
    if normalized == "verbose":
        return 0
    if normalized == "debug":
        return 1
    if normalized in {"information", "info"}:
        return 2
    if normalized in {"warning", "warn"}:
        return 3
    if normalized == "error":
        return 4
    if normalized in {"fatal", "critical"}:
        return 5
    return 0


def _load_json_object(path: str) -> Dict[str, Any]:
    try:
        raw = Path(path).expanduser().resolve().read_text(encoding="utf-8")
        parsed = json.loads(raw)
        if not isinstance(parsed, dict):
            raise ValueError("Configuration file must contain a JSON object.")
        return dict(parsed)
    except Exception as error:  # noqa: BLE001
        raise ValueError(f"Could not load configuration file '{path}': {error}") from error


def _extract_context_overrides_from_config(config: Dict[str, Any]) -> Dict[str, Any]:
    section = config.get("LoadStrike")
    loadstrike = section if isinstance(section, dict) else {}

    def _pick(*keys: str) -> Any:
        for key in keys:
            if key in loadstrike:
                return loadstrike[key]
            if key in config:
                return config[key]
        return None

    disable_license_enforcement = _pick(
        "DisableLicenseEnforcement",
        "LoadStrike:DisableLicenseEnforcement",
    )
    if disable_license_enforcement is not None:
        raise ValueError(
            "LoadStrike configuration cannot include disable license enforcement options."
        )

    patch: Dict[str, Any] = {}

    def _set_string(field: str, *keys: str) -> None:
        value = _pick(*keys)
        if isinstance(value, str) and value.strip():
            patch[field] = value.strip()

    def _set_positive_number(field: str, *keys: str) -> None:
        value = _as_float(_pick(*keys))
        if value > 0:
            patch[field] = value

    _set_string("TestSuite", "TestSuite", "LoadStrike:TestSuite")
    _set_string("TestName", "TestName", "LoadStrike:TestName")
    _set_string("SessionId", "SessionId", "LoadStrike:SessionId")
    _set_string("ReportFolderPath", "ReportFolder", "ReportFolderPath", "LoadStrike:ReportFolder")
    _set_string("ReportFileName", "ReportFileName", "LoadStrike:ReportFileName")
    _set_string("ClusterId", "ClusterId", "LoadStrike:ClusterId")
    _set_string("AgentGroup", "AgentGroup", "LoadStrike:AgentGroup")
    _set_string("NatsServerUrl", "NatsServerUrl", "LoadStrike:NatsServerUrl")
    _set_string("RunnerKey", "RunnerKey", "LoadStrike:RunnerKey")
    _set_string("NodeType", "NodeType", "LoadStrike:NodeType")
    _set_string("MinimumLogLevel", "MinimumLogLevel", "LoadStrike:MinimumLogLevel")
    _set_string(
        "LicenseValidationServerUrl",
        "LicenseValidationServerUrl",
        "LoadStrike:LicenseValidation:ServerUrl",
        "LicenseValidation:ServerUrl",
    )

    agents_count = _as_int(_pick("AgentsCount", "LoadStrike:AgentsCount"))
    if agents_count > 0:
        patch["AgentsCount"] = agents_count
    restart_attempts_raw = _pick("RestartIterationMaxAttempts", "LoadStrike:RestartIterationMaxAttempts")
    if restart_attempts_raw is not None:
        restart_attempts = _as_int(restart_attempts_raw)
        if restart_attempts >= 0:
            patch["RestartIterationMaxAttempts"] = restart_attempts

    _set_positive_number("ReportingIntervalSeconds", "ReportingIntervalSeconds", "LoadStrike:ReportingIntervalSeconds")
    _set_positive_number(
        "ScenarioCompletionTimeoutSeconds",
        "ScenarioCompletionTimeoutSeconds",
        "LoadStrike:ScenarioCompletionTimeoutSeconds",
    )
    _set_positive_number(
        "ClusterCommandTimeoutSeconds",
        "ClusterCommandTimeoutSeconds",
        "LoadStrike:ClusterCommandTimeoutSeconds",
    )
    _set_positive_number(
        "LicenseValidationTimeoutSeconds",
        "LicenseValidationTimeoutSeconds",
        "LoadStrike:LicenseValidation:TimeoutSeconds",
    )

    reporting_interval_ms = _as_float(_pick("ReportingIntervalMs", "LoadStrike:ReportingIntervalMs"))
    if reporting_interval_ms > 0:
        patch["ReportingIntervalSeconds"] = reporting_interval_ms / 1000.0
    scenario_completion_ms = _as_float(
        _pick("ScenarioCompletionTimeoutMs", "LoadStrike:ScenarioCompletionTimeoutMs")
    )
    if scenario_completion_ms > 0:
        patch["ScenarioCompletionTimeoutSeconds"] = scenario_completion_ms / 1000.0
    cluster_command_ms = _as_float(
        _pick("ClusterCommandTimeoutMs", "LoadStrike:ClusterCommandTimeoutMs")
    )
    if cluster_command_ms > 0:
        patch["ClusterCommandTimeoutSeconds"] = cluster_command_ms / 1000.0
    license_validation_ms = _as_float(
        _pick("LicenseValidation:TimeoutMs", "LoadStrike:LicenseValidation:TimeoutMs")
    )
    if license_validation_ms > 0:
        patch["LicenseValidationTimeoutSeconds"] = license_validation_ms / 1000.0

    console_metrics = _pick("DisplayConsoleMetrics", "LoadStrike:DisplayConsoleMetrics")
    if console_metrics is not None:
        patch["ConsoleMetricsEnabled"] = _as_bool(console_metrics, False)
    local_dev_cluster = _pick("EnableLocalDevCluster", "LoadStrike:EnableLocalDevCluster")
    if local_dev_cluster is not None:
        patch["LocalDevClusterEnabled"] = _as_bool(local_dev_cluster, False)
    without_reports = _pick("WithoutReports", "LoadStrike:WithoutReports")
    if without_reports is not None:
        patch["ReportsEnabled"] = not _as_bool(without_reports, False)
    sink_retry_count_raw = _pick("SinkRetryCount", "LoadStrike:SinkRetryCount")
    if sink_retry_count_raw is not None:
        sink_retry_count = _as_int(sink_retry_count_raw)
        if sink_retry_count >= 0:
            patch["SinkRetryCount"] = sink_retry_count
    sink_retry_backoff_ms_raw = _pick("SinkRetryBackoffMs", "LoadStrike:SinkRetryBackoffMs")
    if sink_retry_backoff_ms_raw is not None:
        sink_retry_backoff_ms = _as_int(sink_retry_backoff_ms_raw)
        if sink_retry_backoff_ms >= 0:
            patch["SinkRetryBackoffMs"] = sink_retry_backoff_ms

    report_formats = _normalize_string_list(_pick("ReportFormats", "LoadStrike:ReportFormats"))
    if report_formats:
        patch["ReportFormats"] = report_formats
    target_scenarios = _normalize_string_list(_pick("TargetScenarios", "LoadStrike:TargetScenarios"))
    if target_scenarios:
        patch["TargetScenarios"] = target_scenarios
    agent_target_scenarios = _normalize_string_list(
        _pick("AgentTargetScenarios", "LoadStrike:AgentTargetScenarios")
    )
    if agent_target_scenarios:
        patch["AgentTargetScenarios"] = agent_target_scenarios
    coordinator_target_scenarios = _normalize_string_list(
        _pick("CoordinatorTargetScenarios", "LoadStrike:CoordinatorTargetScenarios")
    )
    if coordinator_target_scenarios:
        patch["CoordinatorTargetScenarios"] = coordinator_target_scenarios

    return patch


def _runner_options_to_context_values(options: Dict[str, Any]) -> Dict[str, Any]:
    report_formats = options.get("report_formats")
    values = {
        "NodeType": (
            _canonical_node_type_name(options.get("node_type"))
            if options.get("node_type") is not None
            else None
        ),
        "ConsoleMetricsEnabled": options.get("console_metrics_enabled"),
        "LocalDevClusterEnabled": options.get("local_dev_cluster_enabled"),
        "AgentGroup": options.get("agent_group"),
        "AgentsCount": options.get("agents_count"),
        "TargetScenarios": options.get("target_scenarios"),
        "AgentTargetScenarios": options.get("agent_target_scenarios"),
        "CoordinatorTargetScenarios": options.get("coordinator_target_scenarios"),
        "NatsServerUrl": options.get("nats_server_url"),
        "RunnerKey": options.get("runner_key"),
        "LicenseValidationServerUrl": options.get("license_validation_server_url"),
        "LicenseValidationTimeoutSeconds": options.get("license_validation_timeout_seconds"),
        "ConfigPath": options.get("config_path"),
        "InfraConfigPath": options.get("infra_config_path"),
        "InfraConfig": options.get("infra_config"),
        "ClusterId": options.get("cluster_id"),
        "SessionId": options.get("session_id"),
        "TestSuite": options.get("test_suite"),
        "TestName": options.get("test_name"),
        "ReportsEnabled": options.get("reports_enabled"),
        "ReportFileName": options.get("report_file_name"),
        "ReportFolderPath": options.get("report_folder_path"),
        "ReportFormats": _normalize_report_formats_value(report_formats) if report_formats is not None else None,
        "ReportFinalizer": options.get("report_finalizer"),
        "ReportingIntervalSeconds": options.get("reporting_interval_seconds"),
        "MinimumLogLevel": options.get("minimum_log_level"),
        "LoggerConfig": options.get("logger_config"),
        "ReportingSinks": options.get("reporting_sinks"),
        "RuntimePolicies": options.get("runtime_policies"),
        "ScenarioCompletionTimeoutSeconds": options.get("scenario_completion_timeout_seconds"),
        "ClusterCommandTimeoutSeconds": options.get("cluster_command_timeout_seconds"),
        "RestartIterationMaxAttempts": options.get("restart_iteration_max_attempts"),
        "WorkerPlugins": options.get("worker_plugins"),
        "CustomSettings": options.get("custom_settings"),
        "GlobalCustomSettings": options.get("global_custom_settings"),
    }
    if "sink_retry_count" in options:
        values["SinkRetryCount"] = options.get("sink_retry_count")
    if "sink_retry_backoff_ms" in options:
        values["SinkRetryBackoffMs"] = options.get("sink_retry_backoff_ms")
    return values


def _apply_run_args(options: Dict[str, Any], args: List[str]) -> Dict[str, Any]:
    if not args:
        return dict(options)

    merged = dict(options)
    merged["run_args"] = list(args)
    for arg in args:
        if not isinstance(arg, str) or not arg.strip() or not arg.startswith("--"):
            continue

        key, _, raw_value = arg[2:].partition("=")
        value = raw_value.strip()
        normalized_key = key.strip().lower()

        if normalized_key == "disablelicenseenforcement":
            raise ValueError(
                "Run arguments cannot include disable license enforcement options."
            )

        if normalized_key == "config" and value:
            loaded = _load_json_object(value)
            merged.update(
                LoadStrikeContext(
                    {
                        "ConfigPath": value,
                        "CustomSettings": loaded,
                        **_extract_context_overrides_from_config(loaded),
                    }
                ).to_runner_options()
            )
            continue
        if normalized_key == "infraconfig" and value:
            merged["infra_config_path"] = value
            merged["infra_config"] = _load_json_object(value)
            continue
        if normalized_key == "testsuite" and value:
            merged["test_suite"] = value
            continue
        if normalized_key == "testname" and value:
            merged["test_name"] = value
            continue
        if normalized_key == "sessionid" and value:
            merged["session_id"] = value
            continue
        if normalized_key == "reportfolder" and value:
            merged["report_folder_path"] = value
            continue
        if normalized_key == "reportfilename" and value:
            merged["report_file_name"] = value
            continue
        if normalized_key == "withoutreports":
            parsed = _try_parse_cli_bool(value)
            if parsed is not None:
                merged["reports_enabled"] = not parsed
            continue
        if normalized_key == "reportformats":
            parsed = _parse_cli_report_formats(value)
            if parsed:
                merged["report_formats"] = parsed
            continue
        if normalized_key == "reportingintervalms":
            parsed = _try_parse_positive_int(value)
            if parsed is not None:
                merged["reporting_interval_seconds"] = parsed / 1000.0
            continue
        if normalized_key == "scenariocompletiontimeoutms":
            parsed = _try_parse_positive_int(value)
            if parsed is not None:
                merged["scenario_completion_timeout_seconds"] = parsed / 1000.0
            continue
        if normalized_key == "clustercommandtimeoutms":
            parsed = _try_parse_positive_int(value)
            if parsed is not None:
                merged["cluster_command_timeout_seconds"] = parsed / 1000.0
            continue
        if normalized_key == "nodetype":
            parsed = _parse_cli_node_type(value)
            if parsed:
                merged["node_type"] = parsed
            continue
        if normalized_key in {"clusteid", "clusterid"} and value:
            merged["cluster_id"] = value
            continue
        if normalized_key == "agentgroup" and value:
            merged["agent_group"] = value
            continue
        if normalized_key == "agentscount":
            parsed = _try_parse_positive_int(value)
            if parsed is not None:
                merged["agents_count"] = parsed
            continue
        if normalized_key == "targetscenarios":
            parsed = _split_cli_list(value)
            if parsed:
                merged["target_scenarios"] = parsed
            continue
        if normalized_key == "agenttargetscenarios":
            parsed = _split_cli_list(value)
            if parsed:
                merged["agent_target_scenarios"] = parsed
            continue
        if normalized_key == "coordinatortargetscenarios":
            parsed = _split_cli_list(value)
            if parsed:
                merged["coordinator_target_scenarios"] = parsed
            continue
        if normalized_key == "natsserverurl" and value:
            merged["nats_server_url"] = value
            continue
        if normalized_key == "minimumloglevel":
            parsed = _parse_cli_log_level(value)
            if parsed:
                merged["minimum_log_level"] = parsed
            continue
        if normalized_key == "displayconsolemetrics":
            parsed = _try_parse_cli_bool(value)
            if parsed is not None:
                merged["console_metrics_enabled"] = parsed
            continue
        if normalized_key == "enablelocaldevcluster":
            parsed = _try_parse_cli_bool(value)
            if parsed is not None:
                merged["local_dev_cluster_enabled"] = parsed
            continue
        if normalized_key == "restartiterationmaxattempts":
            parsed = _try_parse_non_negative_int(value)
            if parsed is not None:
                merged["restart_iteration_max_attempts"] = parsed
            continue
        if normalized_key == "runnerkey" and value:
            merged["runner_key"] = value
            continue
        if normalized_key == "licensevalidationserverurl" and value:
            merged["license_validation_server_url"] = value
            continue
        if normalized_key == "licensevalidationtimeoutms":
            parsed = _try_parse_positive_int(value)
            if parsed is not None:
                merged["license_validation_timeout_seconds"] = parsed / 1000.0

    return merged


def _require_non_empty(value: str, message: str) -> str:
    resolved = "" if value is None else str(value)
    if not resolved.strip():
        raise ValueError(message)
    return resolved


def _validate_scenario_names(values: List[str]) -> List[str]:
    if not values:
        raise ValueError("At least one value should be provided.")
    if any(not str(x or "").strip() for x in values):
        raise ValueError("Value collection cannot contain null or whitespace values.")
    return [str(x).strip() for x in values]


def _normalize_plugin_data(plugin_name: str, payload: Any) -> Dict[str, Any]:
    if isinstance(payload, LoadStrikePluginData):
        payload = payload.to_dict()
    elif isinstance(payload, _LoadStrikeMappingView):
        payload = payload.to_dict()

    if not isinstance(payload, dict):
        return {"pluginName": _normalize_plugin_name(plugin_name), "hints": [], "tables": []}

    tables = _mapping_value(payload, "tables")
    if not isinstance(tables, list):
        tables = []
    hints = _mapping_value(payload, "hints")
    if not isinstance(hints, list):
        hints = []

    normalized_tables: List[Dict[str, Any]] = []
    for table in tables:
        if not isinstance(table, dict):
            continue
        rows = _mapping_value(table, "rows")
        if not isinstance(rows, list):
            rows = []
        headers = _mapping_value(table, "headers")
        if not isinstance(headers, list):
            headers = []
        normalized_tables.append(
            {
                "tableName": str(_mapping_value(table, "tableName") or "table"),
                "headers": [str(x) for x in headers],
                "rows": [dict(row) if isinstance(row, dict) else {} for row in rows],
            }
        )

    return {
        "pluginName": _normalize_plugin_name(_mapping_value(payload, "pluginName") or plugin_name),
        "hints": [str(value) for value in hints],
        "tables": normalized_tables,
    }


def _with_lifecycle_errors(
    payload: Dict[str, Any],
    plugin_name: str,
    lifecycle_errors: Dict[str, List[str]],
) -> Dict[str, Any]:
    resolved_name = _normalize_plugin_name(plugin_name)
    messages = list(lifecycle_errors.get(resolved_name, []))
    if not messages:
        return payload

    payload_tables = _mapping_value(payload, "tables")
    tables = list(payload_tables) if isinstance(payload_tables, list) else []
    tables.append(
        {
            "tableName": "lifecycle-errors",
            "headers": ["message"],
            "rows": [{"message": message} for message in messages],
        }
    )
    merged = dict(payload)
    merged["pluginName"] = _normalize_plugin_name(_mapping_value(payload, "pluginName") or resolved_name)
    merged["tables"] = tables
    return merged


def _record_plugin_lifecycle_error(
    lifecycle_errors: Dict[str, List[str]],
    plugin_name: str,
    phase: str,
    error: Exception,
) -> None:
    rows = lifecycle_errors.setdefault(_normalize_plugin_name(plugin_name), [])
    rows.append(f"{phase}: {error}")


def _read_text_member(target: Any, *names: str) -> str:
    for name in names:
        member = getattr(target, name, None)
        if member is None:
            continue
        if callable(member):
            try:
                member = member()
            except TypeError:
                continue
            except Exception:  # noqa: BLE001
                member = None
        text = str(member or "").strip()
        if text:
            return text
    return ""


def _plugin_name(plugin: LoadStrikeWorkerPlugin) -> str:
    return _normalize_plugin_name(_read_text_member(plugin, "plugin_name", "pluginName", "PluginName"))


def _validate_reporting_sink_names(sinks: List[LoadStrikeReportingSink]) -> None:
    for index, sink in enumerate(sinks):
        if _resolve_sink_name(sink, index):
            continue
        raise ValueError(
            f"Reporting sink name must be provided via sink_name or SinkName. Index={index + 1}"
        )


def _resolve_sink_name(sink: LoadStrikeReportingSink, index: int) -> str:
    _ = index
    return _read_text_member(sink, "sink_name", "sinkName", "SinkName")


def _call_if_exists(target: Any, method_name: str, *args: Any) -> None:
    callback = getattr(target, method_name, None)
    if callable(callback):
        _invoke_maybe_async(callback, *args)


def _invoke_callback_compatible(callback: Callable[..., Any], *preferred_args: Any) -> Any:
    try:
        signature = inspect.signature(callback)
    except (TypeError, ValueError):
        return _invoke_maybe_async(callback, *preferred_args)

    parameters = list(signature.parameters.values())
    if any(parameter.kind == inspect.Parameter.VAR_POSITIONAL for parameter in parameters):
        return _invoke_maybe_async(callback, *preferred_args)

    positional = [
        parameter
        for parameter in parameters
        if parameter.kind in (inspect.Parameter.POSITIONAL_ONLY, inspect.Parameter.POSITIONAL_OR_KEYWORD)
    ]
    if not positional:
        return _invoke_maybe_async(callback)

    return _invoke_maybe_async(callback, *preferred_args[: min(len(preferred_args), len(positional))])


def _invoke_sink_init(sink: Any, base_context: LoadStrikeBaseContext, infra_config: Dict[str, Any]) -> None:
    callback = getattr(sink, "init", None)
    if callable(callback):
        _invoke_callback_compatible(callback, base_context, dict(infra_config))


def _invoke_sink_start(sink: Any, session_info: LoadStrikeSessionStartInfo) -> None:
    callback = getattr(sink, "start", None)
    if callable(callback):
        _invoke_callback_compatible(callback, session_info)


def _invoke_plugin_init(plugin: Any, base_context: LoadStrikeBaseContext, infra_config: Dict[str, Any]) -> None:
    callback = getattr(plugin, "init", None)
    if callable(callback):
        _invoke_callback_compatible(callback, base_context, dict(infra_config))


def _invoke_plugin_start(plugin: Any, session_info: LoadStrikeSessionStartInfo) -> None:
    callback = getattr(plugin, "start", None)
    if callable(callback):
        _invoke_callback_compatible(callback, session_info)


def _invoke_plugin_get_data(plugin: Any, result: LoadStrikeNodeStats) -> Any:
    callback = getattr(plugin, "get_data", None)
    if not callable(callback):
        return None
    return _invoke_callback_compatible(callback, result)


def _invoke_maybe_async(callback: Callable[..., Any], *args: Any) -> Any:
    result = callback(*args)
    if inspect.isawaitable(result):
        return _run_awaitable(result)
    return result


def _run_awaitable(awaitable: Any) -> Any:
    try:
        loop = asyncio.get_running_loop()
    except RuntimeError:
        return asyncio.run(awaitable)

    if not loop.is_running():
        return loop.run_until_complete(awaitable)

    outcome: Dict[str, Any] = {}

    def runner() -> None:
        try:
            outcome["value"] = asyncio.run(awaitable)
        except Exception as error:  # noqa: BLE001
            outcome["error"] = error

    thread = threading.Thread(target=runner, daemon=True)
    thread.start()
    thread.join()
    if "error" in outcome:
        raise outcome["error"]
    return outcome.get("value")


def _new_measurement_accumulator() -> Dict[str, Any]:
    return {
        "_sync": threading.Lock(),
        "count": 0,
        "allBytes": 0,
        "totalLatencyMs": 0.0,
        "latenciesMs": [],
        "sizesBytes": [],
        "statusCodes": {},
    }


def _new_scenario_accumulator(scenario_name: str, sort_index: int) -> Dict[str, Any]:
    return {
        "scenarioName": scenario_name,
        "sortIndex": sort_index,
        "currentOperation": "Init",
        "loadSimulationStats": {"simulationName": "", "value": 0},
        "_sync": threading.Lock(),
        "_ok": _new_measurement_accumulator(),
        "_fail": _new_measurement_accumulator(),
        "_stepMap": {},
        "_nextStepSortIndex": 0,
        "_startedMs": 0,
    }


def _new_step_accumulator(scenario_name: str, step_name: str, sort_index: int) -> Dict[str, Any]:
    return {
        "scenarioName": scenario_name,
        "stepName": step_name,
        "sortIndex": sort_index,
        "_sync": threading.Lock(),
        "_ok": _new_measurement_accumulator(),
        "_fail": _new_measurement_accumulator(),
    }


def _round_midpoint_away_from_zero(value: float) -> int:
    if value >= 0:
        return int(math.floor(value + 0.5))
    return int(math.ceil(value - 0.5))


def _mean_numeric(values: List[Union[float, int]]) -> float:
    if not values:
        return 0.0
    return float(sum(float(value) for value in values) / len(values))


def _std_dev_numeric(values: List[Union[float, int]]) -> float:
    if len(values) <= 1:
        return 0.0
    mean = _mean_numeric(values)
    variance = sum((float(value) - mean) ** 2 for value in values) / len(values)
    return math.sqrt(variance)


def _percentile_numeric(values: List[Union[float, int]], percentile: float) -> float:
    if not values:
        return 0.0
    ordered = sorted(float(value) for value in values)
    index = int(math.ceil(percentile * len(ordered))) - 1
    index = max(0, min(index, len(ordered) - 1))
    return ordered[index]


def _timedelta_from_ms(value: Any) -> timedelta:
    return timedelta(milliseconds=_duration_ms_from_value(value))


def _parse_datetime_utc(value: Any) -> Optional[datetime]:
    if isinstance(value, datetime):
        return value.astimezone(timezone.utc)
    text = str(value or "").strip()
    if not text:
        return None
    try:
        return datetime.fromisoformat(text.replace("Z", "+00:00")).astimezone(timezone.utc)
    except ValueError:
        return None


def _parse_timespan_text(value: Any) -> timedelta:
    text = str(value or "").strip()
    if not text:
        return timedelta(0)
    if ":" not in text:
        return timedelta(0)
    days = 0
    time_part = text
    if "." in text:
        day_part, possible_time = text.split(".", 1)
        if day_part.isdigit() and possible_time.count(":") == 2:
            days = int(day_part)
            time_part = possible_time
    parts = time_part.split(":")
    if len(parts) != 3:
        return timedelta(0)
    try:
        hours = int(parts[0])
        minutes = int(parts[1])
        seconds = float(parts[2])
    except ValueError:
        return timedelta(0)
    return timedelta(days=days, hours=hours, minutes=minutes, seconds=seconds)


def _duration_ms_from_value(value: Any) -> float:
    if isinstance(value, timedelta):
        return max(value.total_seconds() * 1000.0, 0.0)

    text = str(value or "").strip()
    if ":" in text:
        return max(_parse_timespan_text(text).total_seconds() * 1000.0, 0.0)

    return max(_as_float(value), 0.0)


def _measurement_count(accumulator: Dict[str, Any]) -> int:
    return _as_int(accumulator.get("count"))


def _aggregate_status_code_counts(measurement: Dict[str, Any]) -> Dict[str, int]:
    values = measurement.get("statusCodes")
    if not isinstance(values, list):
        return {}
    aggregated: Dict[str, int] = {}
    for row in values:
        if not isinstance(row, dict):
            continue
        status_code = str(row.get("statusCode") or "")
        if not status_code:
            continue
        aggregated[status_code] = aggregated.get(status_code, 0) + _as_int(row.get("count"))
    return aggregated


def _merge_status_code_counts(*measurements: Dict[str, Any]) -> Dict[str, int]:
    merged: Dict[str, int] = {}
    for measurement in measurements:
        for status_code, count in _aggregate_status_code_counts(measurement).items():
            merged[status_code] = merged.get(status_code, 0) + count
    return merged


def _record_measurement(accumulator: Dict[str, Any], reply: LoadStrikeStepReply, latency_ms: float) -> None:
    sync = accumulator.get("_sync")
    if hasattr(sync, "acquire") and hasattr(sync, "release"):
        sync.acquire()
    try:
        accumulator["count"] = _measurement_count(accumulator) + 1
        size_bytes = max(_as_int(reply.size_bytes), 0)
        accumulator["allBytes"] = _as_int(accumulator.get("allBytes")) + size_bytes
        accumulator["totalLatencyMs"] = _as_float(accumulator.get("totalLatencyMs")) + latency_ms
        accumulator.setdefault("latenciesMs", []).append(latency_ms)
        accumulator.setdefault("sizesBytes", []).append(size_bytes)

        status_code = _normalize_status_code(reply.status_code, reply.is_success)
        status_message = str(reply.message or "")
        is_error = not reply.is_success
        key = f"{status_code}|{status_message}|{1 if is_error else 0}"
        status_rows = accumulator.setdefault("statusCodes", {})
        existing = status_rows.get(key)
        if not isinstance(existing, dict):
            existing = {
                "statusCode": status_code,
                "message": status_message,
                "isError": is_error,
                "count": 0,
            }
        existing["count"] = _as_int(existing.get("count")) + 1
        status_rows[key] = existing
    finally:
        if hasattr(sync, "release"):
            sync.release()


def _measurement_stats_from_accumulator(
    accumulator: Dict[str, Any],
    all_count: int,
    duration_ms: int,
) -> Dict[str, Any]:
    sync = accumulator.get("_sync")
    if hasattr(sync, "acquire") and hasattr(sync, "release"):
        sync.acquire()
    try:
        count = _measurement_count(accumulator)
        all_bytes = _as_int(accumulator.get("allBytes"))
        latencies = [max(_as_float(value), 0.0) for value in list(accumulator.get("latenciesMs") or [])]
        sizes = [max(_as_int(value), 0) for value in list(accumulator.get("sizesBytes") or [])]
        status_rows = accumulator.get("statusCodes")
        normalized_rows = []
        if isinstance(status_rows, dict):
            for row in status_rows.values():
                if isinstance(row, dict):
                    normalized_rows.append(dict(row))
    finally:
        if hasattr(sync, "release"):
            sync.release()
    duration_seconds = max(duration_ms, 0) / 1000.0

    request = {
        "count": count,
        "percent": 0 if all_count <= 0 else _round_midpoint_away_from_zero(100.0 * count / all_count),
        "rps": 0.0 if duration_seconds <= 0 else count / duration_seconds,
    }

    data_transfer = {
        "allBytes": all_bytes,
        "maxBytes": 0 if not sizes else max(sizes),
        "meanBytes": 0 if not sizes else _round_midpoint_away_from_zero(_mean_numeric(sizes)),
        "minBytes": 0 if not sizes else min(sizes),
        "percent50": 0 if not sizes else _round_midpoint_away_from_zero(_percentile_numeric(sizes, 0.50)),
        "percent75": 0 if not sizes else _round_midpoint_away_from_zero(_percentile_numeric(sizes, 0.75)),
        "percent95": 0 if not sizes else _round_midpoint_away_from_zero(_percentile_numeric(sizes, 0.95)),
        "percent99": 0 if not sizes else _round_midpoint_away_from_zero(_percentile_numeric(sizes, 0.99)),
        "stdDev": _std_dev_numeric(sizes),
    }

    latency = {
        "latencyCount": {
            "lessOrEq800": sum(1 for value in latencies if value <= 800),
            "more800Less1200": sum(1 for value in latencies if 800 < value < 1200),
            "moreOrEq1200": sum(1 for value in latencies if value >= 1200),
        },
        "maxMs": 0.0 if not latencies else max(latencies),
        "meanMs": _mean_numeric(latencies),
        "minMs": 0.0 if not latencies else min(latencies),
        "percent50": _percentile_numeric(latencies, 0.50),
        "percent75": _percentile_numeric(latencies, 0.75),
        "percent95": _percentile_numeric(latencies, 0.95),
        "percent99": _percentile_numeric(latencies, 0.99),
        "stdDev": _std_dev_numeric(latencies),
    }

    normalized_rows.sort(key=lambda row: -_as_int(row.get("count")))
    for row in normalized_rows:
        row["percent"] = (
            0 if count <= 0 else _round_midpoint_away_from_zero(100.0 * _as_int(row.get("count")) / count)
        )

    return {
        "request": request,
        "dataTransfer": data_transfer,
        "latency": latency,
        "statusCodes": normalized_rows,
    }


def _measurement_totals(measurement: Dict[str, Any]) -> Dict[str, Any]:
    request = measurement.get("request") if isinstance(measurement.get("request"), dict) else {}
    latency = measurement.get("latency") if isinstance(measurement.get("latency"), dict) else {}
    data_transfer = measurement.get("dataTransfer") if isinstance(measurement.get("dataTransfer"), dict) else {}
    return {
        "count": _as_int(request.get("count")),
        "allBytes": _as_int(data_transfer.get("allBytes")),
        "totalLatencyMs": _as_float(request.get("count")) * _as_float(latency.get("meanMs")),
        "avgLatencyMs": _as_float(latency.get("meanMs")),
        "minLatencyMs": _as_float(latency.get("minMs")),
        "maxLatencyMs": _as_float(latency.get("maxMs")),
    }


def _step_row_from_accumulator(step: Dict[str, Any], duration_ms: int) -> Dict[str, Any]:
    total_count = _measurement_count(step.get("_ok", {})) + _measurement_count(step.get("_fail", {}))
    ok = _measurement_stats_from_accumulator(step.get("_ok", {}), total_count, duration_ms)
    fail = _measurement_stats_from_accumulator(step.get("_fail", {}), total_count, duration_ms)
    ok_totals = _measurement_totals(ok)
    fail_totals = _measurement_totals(fail)
    request_count = ok_totals["count"] + fail_totals["count"]
    total_latency_ms = ok_totals["totalLatencyMs"] + fail_totals["totalLatencyMs"]
    min_latency_candidates = [
        value
        for value, count in (
            (ok_totals["minLatencyMs"], ok_totals["count"]),
            (fail_totals["minLatencyMs"], fail_totals["count"]),
        )
        if count > 0
    ]
    return {
        "scenarioName": str(step.get("scenarioName") or ""),
        "stepName": str(step.get("stepName") or ""),
        "sortIndex": _as_int(step.get("sortIndex")),
        "ok": ok,
        "fail": fail,
        "okCount": ok_totals["count"],
        "failCount": fail_totals["count"],
        "requestCount": request_count,
        "allBytes": ok_totals["allBytes"] + fail_totals["allBytes"],
        "totalBytes": ok_totals["allBytes"] + fail_totals["allBytes"],
        "totalLatencyMs": total_latency_ms,
        "avgLatencyMs": 0.0 if request_count <= 0 else total_latency_ms / request_count,
        "minLatencyMs": 0.0 if not min_latency_candidates else min(min_latency_candidates),
        "maxLatencyMs": max(ok_totals["maxLatencyMs"], fail_totals["maxLatencyMs"]),
        "statusCodes": _merge_status_code_counts(ok, fail),
    }


def _scenario_row_from_accumulator(runtime: Dict[str, Any], duration_ms: int) -> Dict[str, Any]:
    sync = runtime.get("_sync")
    if hasattr(sync, "acquire") and hasattr(sync, "release"):
        sync.acquire()
    try:
        current_operation = str(runtime.get("currentOperation") or "None")
        load_simulation_stats = dict(runtime.get("loadSimulationStats") or {"simulationName": "", "value": 0})
        steps_snapshot = [
            value
            for value in (runtime.get("_stepMap") or {}).values()
            if isinstance(value, dict)
        ]
    finally:
        if hasattr(sync, "release"):
            sync.release()
    total_count = _measurement_count(runtime.get("_ok", {})) + _measurement_count(runtime.get("_fail", {}))
    ok = _measurement_stats_from_accumulator(runtime.get("_ok", {}), total_count, duration_ms)
    fail = _measurement_stats_from_accumulator(runtime.get("_fail", {}), total_count, duration_ms)
    ok_totals = _measurement_totals(ok)
    fail_totals = _measurement_totals(fail)
    step_rows = [
        _step_row_from_accumulator(step, duration_ms)
        for step in sorted(
            steps_snapshot,
            key=lambda row: _as_int(row.get("sortIndex")),
        )
    ]
    total_latency_ms = ok_totals["totalLatencyMs"] + fail_totals["totalLatencyMs"]
    min_latency_candidates = [
        value
        for value, count in (
            (ok_totals["minLatencyMs"], ok_totals["count"]),
            (fail_totals["minLatencyMs"], fail_totals["count"]),
        )
        if count > 0
    ]
    return {
        "scenarioName": str(runtime.get("scenarioName") or ""),
        "sortIndex": _as_int(runtime.get("sortIndex")),
        "currentOperation": current_operation,
        "durationMs": max(int(duration_ms), 0),
        "loadSimulationStats": load_simulation_stats,
        "ok": ok,
        "fail": fail,
        "stepStats": step_rows,
        "allBytes": ok_totals["allBytes"] + fail_totals["allBytes"],
        "allFailCount": fail_totals["count"],
        "allOkCount": ok_totals["count"],
        "allRequestCount": total_count,
        "totalBytes": ok_totals["allBytes"] + fail_totals["allBytes"],
        "totalLatencyMs": total_latency_ms,
        "avgLatencyMs": 0.0 if total_count <= 0 else total_latency_ms / total_count,
        "minLatencyMs": 0.0 if not min_latency_candidates else min(min_latency_candidates),
        "maxLatencyMs": max(ok_totals["maxLatencyMs"], fail_totals["maxLatencyMs"]),
        "statusCodes": _merge_status_code_counts(ok, fail),
    }


def _flatten_step_stats(scenario_rows: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    flattened: List[Dict[str, Any]] = []
    for scenario in scenario_rows:
        if not isinstance(scenario, dict):
            continue
        scenario_name = str(scenario.get("scenarioName") or "")
        step_rows = scenario.get("stepStats")
        if not isinstance(step_rows, list):
            continue
        for row in step_rows:
            if not isinstance(row, dict):
                continue
            step_row = dict(row)
            step_row["scenarioName"] = scenario_name
            flattened.append(step_row)
    return flattened


def _metric_merge_key(metric: Dict[str, Any]) -> str:
    return "||".join(
        [
            str(metric.get("type") or "").lower(),
            str(metric.get("scenarioName") or ""),
            str(metric.get("name") or ""),
            str(metric.get("unitOfMeasure") or metric.get("unit_of_measure") or ""),
        ]
    )


def _build_metric_stats_payload(metrics: Any, duration_ms: Any) -> Dict[str, Any]:
    values = [dict(metric) for metric in list(metrics or []) if isinstance(metric, dict)]
    counters = [metric for metric in values if str(metric.get("type") or "").lower() == "counter"]
    gauges = [metric for metric in values if str(metric.get("type") or "").lower() != "counter"]
    return {
        "durationMs": max(_as_int(duration_ms), 0),
        "counters": [
            {
                "metricName": str(metric.get("name") or ""),
                "scenarioName": str(metric.get("scenarioName") or ""),
                "unitOfMeasure": str(metric.get("unitOfMeasure") or metric.get("unit_of_measure") or ""),
                "value": _as_int(metric.get("value")),
            }
            for metric in counters
        ],
        "gauges": [
            {
                "metricName": str(metric.get("name") or ""),
                "scenarioName": str(metric.get("scenarioName") or ""),
                "unitOfMeasure": str(metric.get("unitOfMeasure") or metric.get("unit_of_measure") or ""),
                "value": _as_float(metric.get("value")),
            }
            for metric in gauges
        ],
    }


def _resolve_load_simulation_stats(load_simulations: List[Dict[str, Any]], weight: int) -> Dict[str, Any]:
    simulation_name = ""
    simulation_value = 0
    for simulation in load_simulations:
        if not isinstance(simulation, dict):
            continue
        simulation_name = str(simulation.get("Kind") or "")
        if _as_int(simulation.get("Rate")) > 0:
            simulation_value = _as_int(simulation.get("Rate")) * max(int(weight), 1)
        elif _as_int(simulation.get("Copies")) > 0:
            simulation_value = _as_int(simulation.get("Copies")) * max(int(weight), 1)
        elif _as_int(simulation.get("Iterations")) > 0:
            simulation_value = _as_int(simulation.get("Iterations")) * max(int(weight), 1)
        else:
            simulation_value = 0
    return {"simulationName": simulation_name, "value": simulation_value}


def _record_step(
    runtime: Dict[str, Any],
    step_name: str,
    reply: LoadStrikeStepReply,
    elapsed_ms: float,
) -> None:
    latency_ms = _resolve_runtime_latency(reply.custom_latency_ms, elapsed_ms)
    sync = runtime.get("_sync")
    if hasattr(sync, "acquire") and hasattr(sync, "release"):
        sync.acquire()
    try:
        steps = runtime.setdefault("_stepMap", {})
        row = steps.get(step_name)
        if not isinstance(row, dict):
            next_sort_index = _as_int(runtime.get("_nextStepSortIndex")) + 1
            runtime["_nextStepSortIndex"] = next_sort_index
            row = _new_step_accumulator(str(runtime.get("scenarioName") or ""), step_name, next_sort_index)
            steps[step_name] = row
    finally:
        if hasattr(sync, "release"):
            sync.release()
    _record_measurement(row["_fail"] if not reply.is_success else row["_ok"], reply, latency_ms)


def _tracking_helper() -> LoadStrikeLocalClient:
    return LoadStrikeLocalClient()


def _read_tracking_option(tracking: Dict[str, Any], *keys: str) -> Any:
    for key in keys:
        if key in tracking:
            return tracking.get(key)
    return None


def _normalize_tracking_run_mode(tracking: Dict[str, Any]) -> str:
    raw = str(_read_tracking_option(tracking, "RunMode", "runMode") or "GenerateAndCorrelate").strip()
    normalized = raw.lower()
    if normalized in {"generateandcorrelate", "sourceonly", "correlateexistingtraffic"}:
        return normalized
    raise ValueError("Unsupported tracking run mode.")


def _validate_cross_platform_tracking_configuration(tracking: Dict[str, Any]) -> Dict[str, Any]:
    if not isinstance(tracking, dict):
        raise ValueError("tracking must be provided.")

    helper = _tracking_helper()
    source_spec = helper._as_dict(helper._pick_value(tracking, "Source", "source"))
    if not source_spec:
        raise ValueError("Source endpoint must be provided.")

    source_endpoint = helper._map_endpoint_spec(source_spec)
    _validate_endpoint_definition(source_endpoint)

    destination_spec = helper._as_dict(helper._pick_value(tracking, "Destination", "destination"))
    destination_endpoint = None
    if destination_spec:
        destination_endpoint = helper._map_endpoint_spec(destination_spec)
        _validate_endpoint_definition(destination_endpoint)

    if source_endpoint.gather_by_field:
        raise ValueError("GatherByField is supported on destination endpoint only.")

    correlation_timeout_seconds = _as_float(
        helper._pick_value(
            tracking,
            "CorrelationTimeoutSeconds",
            "correlationTimeoutSeconds",
            "CorrelationTimeout",
        )
        or 30.0
    )
    if correlation_timeout_seconds <= 0:
        raise ValueError("CorrelationTimeout must be greater than zero.")

    timeout_sweep_interval_seconds = _as_float(
        helper._pick_value(
            tracking,
            "TimeoutSweepIntervalSeconds",
            "timeoutSweepIntervalSeconds",
            "TimeoutSweepInterval",
        )
        or 1.0
    )
    if timeout_sweep_interval_seconds <= 0:
        raise ValueError("TimeoutSweepInterval must be greater than zero.")

    timeout_batch_size = _as_int(
        helper._pick_value(tracking, "TimeoutBatchSize", "timeoutBatchSize") or 200
    )
    if timeout_batch_size <= 0:
        raise ValueError("TimeoutBatchSize must be greater than zero.")

    metric_prefix = str(_read_tracking_option(tracking, "MetricPrefix", "metricPrefix") or "tracking").strip()
    if not metric_prefix:
        raise ValueError("MetricPrefix must be provided.")

    run_mode = _normalize_tracking_run_mode(tracking)
    if run_mode in {"generateandcorrelate", "sourceonly"}:
        if source_endpoint.mode != "Produce":
            raise ValueError("Source endpoint mode must be Produce for GenerateAndCorrelate mode.")
        if destination_endpoint is not None and destination_endpoint.mode != "Consume":
            raise ValueError("Destination endpoint mode must be Consume for GenerateAndCorrelate mode.")
    elif run_mode == "correlateexistingtraffic":
        if destination_endpoint is None:
            raise ValueError("Destination endpoint must be provided for CorrelateExistingTraffic mode.")
        if source_endpoint.mode != "Consume":
            raise ValueError("Source endpoint mode must be Consume for CorrelateExistingTraffic mode.")
        if destination_endpoint.mode != "Consume":
            raise ValueError("Destination endpoint mode must be Consume for CorrelateExistingTraffic mode.")

    return dict(tracking)


def _configure_metric(metric: LoadStrikeCounter | LoadStrikeGauge, scenario_name: str, unit_of_measure: str) -> None:
    metric.scenario_name = scenario_name
    metric.unit_of_measure = unit_of_measure


def _calculate_tracking_percentile(values: deque[float], percentile: float) -> float:
    if not values:
        return 0.0
    ordered = sorted(values)
    index = max(min(int(math.ceil(percentile * len(ordered))) - 1, len(ordered) - 1), 0)
    return float(ordered[index])


class _TrackingMetricsRecorder:
    def __init__(self, scenario_name: str, metric_prefix: str, timeout_counts_as_failure: bool) -> None:
        self._timeout_counts_as_failure = timeout_counts_as_failure
        self._latency_samples: deque[float] = deque(maxlen=50_000)
        self._inflight = 0

        self._source_total = LoadStrikeMetric.counter(f"{metric_prefix}_source_total")
        self._destination_total = LoadStrikeMetric.counter(f"{metric_prefix}_destination_total")
        self._matched_total = LoadStrikeMetric.counter(f"{metric_prefix}_matched_total")
        self._unmatched_destination_total = LoadStrikeMetric.counter(f"{metric_prefix}_unmatched_destination_total")
        self._timeout_total = LoadStrikeMetric.counter(f"{metric_prefix}_timeout_total")
        self._failure_total = LoadStrikeMetric.counter(f"{metric_prefix}_failure_total")
        self._success_total = LoadStrikeMetric.counter(f"{metric_prefix}_success_total")
        self._duplicate_source_total = LoadStrikeMetric.counter(f"{metric_prefix}_duplicate_source_total")
        self._duplicate_destination_total = LoadStrikeMetric.counter(f"{metric_prefix}_duplicate_destination_total")
        self._inflight_gauge = LoadStrikeMetric.gauge(f"{metric_prefix}_inflight_current")
        self._latency_last_gauge = LoadStrikeMetric.gauge(f"{metric_prefix}_latency_last_ms")
        self._latency_p50_gauge = LoadStrikeMetric.gauge(f"{metric_prefix}_latency_p50_ms")
        self._latency_p95_gauge = LoadStrikeMetric.gauge(f"{metric_prefix}_latency_p95_ms")
        self._latency_p99_gauge = LoadStrikeMetric.gauge(f"{metric_prefix}_latency_p99_ms")

        for metric in (
            self._source_total,
            self._destination_total,
            self._matched_total,
            self._unmatched_destination_total,
            self._timeout_total,
            self._failure_total,
            self._success_total,
            self._duplicate_source_total,
            self._duplicate_destination_total,
            self._inflight_gauge,
            self._latency_last_gauge,
            self._latency_p50_gauge,
            self._latency_p95_gauge,
            self._latency_p99_gauge,
        ):
            _configure_metric(metric, scenario_name, "count" if metric.type == "counter" else "ms")
        _configure_metric(self._inflight_gauge, scenario_name, "count")

    def register(self, init_context: LoadStrikeScenarioInitContext) -> None:
        for metric in (
            self._source_total,
            self._destination_total,
            self._matched_total,
            self._unmatched_destination_total,
            self._timeout_total,
            self._failure_total,
            self._success_total,
            self._duplicate_source_total,
            self._duplicate_destination_total,
            self._inflight_gauge,
            self._latency_last_gauge,
            self._latency_p50_gauge,
            self._latency_p95_gauge,
            self._latency_p99_gauge,
        ):
            init_context.register_metric(metric)

    def on_source_registered(self, source_occurrence_count: int) -> None:
        self._source_total.increment()
        if source_occurrence_count > 1:
            self._duplicate_source_total.increment()
        self._inflight += 1
        self._inflight_gauge.set(max(self._inflight, 0))

    def on_destination_seen(self, destination_occurrence_count: int) -> None:
        self._destination_total.increment()
        if destination_occurrence_count > 1:
            self._duplicate_destination_total.increment()

    def on_matched(self, latency_ms: float) -> None:
        self._matched_total.increment()
        self._success_total.increment()
        self._latency_samples.append(max(float(latency_ms), 0.0))
        self._latency_last_gauge.set(max(float(latency_ms), 0.0))
        self._latency_p50_gauge.set(_calculate_tracking_percentile(self._latency_samples, 0.50))
        self._latency_p95_gauge.set(_calculate_tracking_percentile(self._latency_samples, 0.95))
        self._latency_p99_gauge.set(_calculate_tracking_percentile(self._latency_samples, 0.99))
        self._decrement_inflight()

    def on_unmatched_destination(self) -> None:
        self._unmatched_destination_total.increment()
        self._failure_total.increment()

    def on_timeout(self) -> None:
        self._timeout_total.increment()
        if self._timeout_counts_as_failure:
            self._failure_total.increment()
        self._decrement_inflight()

    def on_failure(self) -> None:
        self._failure_total.increment()

    def on_success(self) -> None:
        self._success_total.increment()

    def _decrement_inflight(self) -> None:
        self._inflight = max(self._inflight - 1, 0)
        self._inflight_gauge.set(self._inflight)


class _ScenarioTrackingRuntimeBridge:
    def __init__(
        self,
        *,
        scenario_name: str,
        tracking: Dict[str, Any],
        init_context: LoadStrikeScenarioInitContext,
    ) -> None:
        self._scenario_name = scenario_name
        self._tracking = dict(tracking)
        self._helper = _tracking_helper()
        self._source_endpoint = self._helper._map_endpoint_spec(
            self._helper._as_dict(self._helper._pick_value(self._tracking, "Source", "source"))
        )
        destination_spec = self._helper._as_dict(
            self._helper._pick_value(self._tracking, "Destination", "destination")
        )
        self._destination_endpoint = self._helper._map_endpoint_spec(destination_spec) if destination_spec else None
        self._run_mode = _normalize_tracking_run_mode(self._tracking)
        self._run_mode_text = str(_read_tracking_option(self._tracking, "RunMode", "runMode") or "GenerateAndCorrelate")
        self._source_only_mode = self._destination_endpoint is None
        self._timeout_seconds = max(
            _as_float(
                self._helper._pick_value(
                    self._tracking,
                    "CorrelationTimeoutSeconds",
                    "correlationTimeoutSeconds",
                    "CorrelationTimeout",
                )
                or 30.0
            ),
            0.001,
        )
        self._timeout_sweep_interval_seconds = max(
            _as_float(
                self._helper._pick_value(
                    self._tracking,
                    "TimeoutSweepIntervalSeconds",
                    "timeoutSweepIntervalSeconds",
                    "TimeoutSweepInterval",
                )
                or 1.0
            ),
            0.001,
        )
        self._timeout_batch_size = max(
            _as_int(self._helper._pick_value(self._tracking, "TimeoutBatchSize", "timeoutBatchSize") or 200),
            1,
        )
        self._timeout_counts_as_failure = _as_bool(
            self._helper._pick_value(self._tracking, "TimeoutCountsAsFailure", "timeoutCountsAsFailure"),
            True,
        )
        self._execute_original_scenario_run = _as_bool(
            _read_tracking_option(self._tracking, "ExecuteOriginalScenarioRun", "executeOriginalScenarioRun"),
            False,
        )
        self._gather_selector = (
            self._destination_endpoint.gather_by_field
            if self._destination_endpoint and self._destination_endpoint.gather_by_field
            else None
        )
        metric_prefix = str(_read_tracking_option(self._tracking, "MetricPrefix", "metricPrefix") or "tracking").strip()
        self._metrics = _TrackingMetricsRecorder(
            scenario_name,
            metric_prefix or "tracking",
            self._timeout_counts_as_failure,
        )
        self._metrics.register(init_context)

        self._source_adapter = EndpointAdapterFactory.create(self._source_endpoint)
        self._destination_adapter = (
            EndpointAdapterFactory.create(self._destination_endpoint)
            if self._destination_endpoint is not None
            else None
        )
        self._runtime_lock = threading.Lock()
        self._waiters_lock = threading.Lock()
        self._waiters: Dict[str, deque[Queue]] = {}
        self._outcomes: Queue = Queue()
        self._stop_event = Event()
        self._threads: List[threading.Thread] = []
        self._source_occurrences: Dict[str, int] = {}
        self._destination_occurrences: Dict[str, int] = {}
        self._runtime = CrossPlatformTrackingRuntime(
            source_tracking_field=self._source_endpoint.tracking_field,
            destination_tracking_field=(
                self._destination_endpoint.tracking_field if self._destination_endpoint else None
            ),
            destination_gather_by_field=self._gather_selector,
            correlation_timeout_ms=max(int(self._timeout_seconds * 1000), 1),
            timeout_counts_as_failure=self._timeout_counts_as_failure,
            store=self._helper._map_correlation_store(self._tracking),
            plugins=[_ScenarioTrackingRuntimeCallbacks(self)],
        )

    def start(self) -> None:
        if self._destination_adapter is None:
            return
        self._start_thread(self._destination_loop, "loadstrike-tracking-destination")
        if self._run_mode == "correlateexistingtraffic":
            self._start_thread(self._source_loop, "loadstrike-tracking-source")
        self._start_thread(self._timeout_loop, "loadstrike-tracking-timeout")

    def dispose(self) -> None:
        self._stop_event.set()
        for thread in self._threads:
            thread.join(timeout=max(self._timeout_sweep_interval_seconds, 0.5))

    def execute_iteration(
        self,
        context: LoadStrikeScenarioContext,
        *,
        invocation_index: int,
        original_run: Callable[[LoadStrikeScenarioContext], LoadStrikeStepReply],
    ) -> LoadStrikeStepReply:
        source_response: Optional[LoadStrikeStepReply] = None
        if self._execute_original_scenario_run and callable(original_run):
            source_response = original_run(context)
            if not source_response.is_success:
                self._metrics.on_failure()
                return source_response

        if self._source_only_mode:
            if source_response is not None and self._execute_original_scenario_run:
                self._metrics.on_success()
                self._record_correlation_row(
                    status_code="source_success",
                    tracking_id=None,
                    is_success=True,
                    is_failure=False,
                    message="Original source scenario run completed successfully.",
                )
                return source_response
            return self._execute_source_only(invocation_index)

        if self._run_mode == "correlateexistingtraffic":
            return self._await_outcome(self._timeout_seconds + self._timeout_sweep_interval_seconds + 0.1)

        return self._execute_generate_and_correlate(invocation_index)

    def _execute_source_only(self, invocation_index: int) -> LoadStrikeStepReply:
        now_utc = datetime.now(timezone.utc)
        try:
            source_payload = self._helper._normalize_payload(None, self._source_endpoint, invocation_index - 1)
            produced = self._source_adapter.produce(source_payload)
            if isinstance(produced, dict) and produced.get("__delegateSuccess") is False:
                raise RuntimeError(
                    str(produced.get("__delegateErrorMessage") or "Delegate stream producer reported an unknown failure.")
                )
            normalized_source = _normalize_tracking_payload(produced if produced is not None else source_payload)
        except Exception as error:  # noqa: BLE001
            self._metrics.on_failure()
            self._record_failed_response(
                status_code="source_error",
                tracking_id=None,
                message=str(error),
                source_timestamp_utc=now_utc,
            )
            self._record_correlation_row(
                status_code="source_error",
                tracking_id=None,
                is_success=False,
                is_failure=True,
                message=str(error),
                source_timestamp_utc=now_utc,
            )
            return LoadStrikeResponse.fail(status_code="source_error", message=str(error))

        tracking_id = self._extract_tracking_id(normalized_source, self._source_endpoint.tracking_field)
        if not tracking_id:
            message = "Source endpoint did not produce a valid tracking id."
            self._metrics.on_failure()
            self._record_failed_response(
                status_code="source_error",
                tracking_id=None,
                message=message,
                source_timestamp_utc=now_utc,
            )
            self._record_correlation_row(
                status_code="source_error",
                tracking_id=None,
                is_success=False,
                is_failure=True,
                message=message,
                source_timestamp_utc=now_utc,
            )
            return LoadStrikeResponse.fail(status_code="source_error", message=message)

        self._metrics.on_success()
        self._record_correlation_row(
            status_code="source_success",
            tracking_id=tracking_id,
            is_success=True,
            is_failure=False,
            source_timestamp_utc=now_utc,
        )
        return LoadStrikeResponse.ok(status_code="source_success")

    def _execute_generate_and_correlate(self, invocation_index: int) -> LoadStrikeStepReply:
        now_ms = int(time.time() * 1000)
        now_utc = datetime.now(timezone.utc)
        try:
            source_payload = self._helper._normalize_payload(None, self._source_endpoint, invocation_index - 1)
            produced = self._source_adapter.produce(source_payload)
            if isinstance(produced, dict) and produced.get("__delegateSuccess") is False:
                raise RuntimeError(
                    str(produced.get("__delegateErrorMessage") or "Delegate stream producer reported an unknown failure.")
                )
            normalized_source = _normalize_tracking_payload(produced if produced is not None else source_payload)
        except Exception as error:  # noqa: BLE001
            self._metrics.on_failure()
            self._record_failed_response(
                status_code="source_error",
                tracking_id=None,
                message=str(error),
                source_timestamp_utc=now_utc,
            )
            self._record_correlation_row(
                status_code="source_error",
                tracking_id=None,
                is_success=False,
                is_failure=True,
                message=str(error),
                source_timestamp_utc=now_utc,
            )
            return LoadStrikeResponse.fail(status_code="source_error", message=str(error))

        tracking_id = self._extract_tracking_id(normalized_source, self._source_endpoint.tracking_field)
        if not tracking_id:
            message = "Source endpoint did not produce a valid tracking id."
            self._metrics.on_failure()
            self._record_failed_response(
                status_code="source_error",
                tracking_id=None,
                message=message,
                source_timestamp_utc=now_utc,
            )
            self._record_correlation_row(
                status_code="source_error",
                tracking_id=None,
                is_success=False,
                is_failure=True,
                message=message,
                source_timestamp_utc=now_utc,
            )
            return LoadStrikeResponse.fail(status_code="source_error", message=message)

        waiter = self._push_waiter(tracking_id)
        self._metrics.on_source_registered(self._next_occurrence(self._source_occurrences, tracking_id))
        with self._runtime_lock:
            self._runtime.on_source_produced(normalized_source, now_ms)

        wait_timeout = self._timeout_seconds + self._timeout_sweep_interval_seconds + 0.1
        try:
            outcome = waiter.get(timeout=max(wait_timeout, 0.1))
        except QueueEmpty:
            with self._runtime_lock:
                self._runtime.sweep_timeouts(
                    now_ms + max(int(self._timeout_seconds * 1000), 1) + 1,
                    self._timeout_batch_size,
                )
            try:
                outcome = waiter.get(timeout=0.05)
            except QueueEmpty:
                outcome = {
                    "status": "timeout",
                    "trackingId": tracking_id,
                    "message": f"Timeout waiting for destination event for trackingId `{tracking_id}`.",
                }
        return self._reply_from_outcome(outcome)

    def _await_outcome(self, timeout_seconds: float) -> LoadStrikeStepReply:
        try:
            outcome = self._outcomes.get(timeout=max(timeout_seconds, 0.1))
        except QueueEmpty:
            return LoadStrikeResponse.fail(
                status_code="timeout",
                message="Timeout waiting for correlation outcome.",
            )
        return self._reply_from_outcome(outcome)

    def _destination_loop(self) -> None:
        while not self._stop_event.is_set():
            try:
                raw_payload = self._destination_adapter.consume() if self._destination_adapter is not None else None
            except Exception:  # noqa: BLE001
                self._pause(self._destination_endpoint)
                continue
            if raw_payload is None:
                self._pause(self._destination_endpoint)
                continue

            payload = _normalize_tracking_payload(raw_payload)
            tracking_id = self._extract_tracking_id(
                payload,
                self._destination_endpoint.tracking_field if self._destination_endpoint else None,
            )
            if not tracking_id:
                continue

            self._metrics.on_destination_seen(self._next_occurrence(self._destination_occurrences, tracking_id))
            with self._runtime_lock:
                matched = self._runtime.on_destination_consumed(payload, int(time.time() * 1000))
            if matched:
                continue

            self._metrics.on_unmatched_destination()
            now_utc = datetime.now(timezone.utc)
            message = f"Destination event `{tracking_id}` had no matching source event."
            self._record_failed_response(
                status_code="unmatched_destination",
                tracking_id=tracking_id,
                message=message,
                destination_timestamp_utc=now_utc,
            )
            self._record_correlation_row(
                status_code="unmatched_destination",
                tracking_id=tracking_id,
                is_success=False,
                is_failure=True,
                gather_by_value=self._resolve_gather_by_value(payload),
                message=message,
                destination_timestamp_utc=now_utc,
            )
            if self._run_mode == "correlateexistingtraffic":
                self._outcomes.put(
                    {
                        "status": "unmatched_destination",
                        "trackingId": tracking_id,
                        "message": message,
                    }
                )

    def _source_loop(self) -> None:
        while not self._stop_event.is_set():
            try:
                raw_payload = self._source_adapter.consume()
            except Exception:  # noqa: BLE001
                self._pause(self._source_endpoint)
                continue
            if raw_payload is None:
                self._pause(self._source_endpoint)
                continue

            payload = _normalize_tracking_payload(raw_payload)
            tracking_id = self._extract_tracking_id(payload, self._source_endpoint.tracking_field)
            if not tracking_id:
                continue

            self._metrics.on_source_registered(self._next_occurrence(self._source_occurrences, tracking_id))
            with self._runtime_lock:
                self._runtime.on_source_produced(payload, int(time.time() * 1000))

    def _timeout_loop(self) -> None:
        while not self._stop_event.wait(self._timeout_sweep_interval_seconds):
            try:
                with self._runtime_lock:
                    self._runtime.sweep_timeouts(
                        int(time.time() * 1000),
                        self._timeout_batch_size,
                    )
            except Exception:  # noqa: BLE001
                continue

    def _on_matched(
        self,
        tracking_id: str,
        source_payload: Dict[str, Any],
        destination_payload: Dict[str, Any],
        latency_ms: int,
    ) -> None:
        resolved_latency_ms = max(int(latency_ms), 0)
        self._metrics.on_matched(resolved_latency_ms)

        destination_timestamp_utc = self._payload_timestamp_utc(destination_payload) or datetime.now(timezone.utc)
        source_timestamp_utc = self._payload_timestamp_utc(source_payload)
        if source_timestamp_utc is None:
            source_timestamp_utc = destination_timestamp_utc - timedelta(milliseconds=resolved_latency_ms)

        outcome = {
            "status": "matched",
            "trackingId": tracking_id,
            "eventId": tracking_id,
            "latencyMs": float(resolved_latency_ms),
        }
        self._record_correlation_row(
            status_code="matched",
            tracking_id=tracking_id,
            event_id=tracking_id,
            is_success=True,
            is_failure=False,
            gather_by_value=self._resolve_gather_by_value(destination_payload),
            source_timestamp_utc=source_timestamp_utc,
            destination_timestamp_utc=destination_timestamp_utc,
            latency_ms=float(resolved_latency_ms),
        )

        waiter = self._pop_waiter(tracking_id)
        if waiter is not None:
            waiter.put(outcome)
            return

        if self._run_mode == "correlateexistingtraffic":
            self._outcomes.put(outcome)

    def _on_timeout(self, tracking_id: str, source_payload: Dict[str, Any]) -> None:
        self._metrics.on_timeout()
        source_timestamp_utc = self._payload_timestamp_utc(source_payload)
        timeout_message = f"TrackingId `{tracking_id}` timed out."
        outcome = {
            "status": "timeout",
            "trackingId": tracking_id,
            "eventId": tracking_id,
            "message": timeout_message,
        }
        self._record_failed_response(
            status_code="timeout",
            tracking_id=tracking_id,
            event_id=tracking_id,
            message=timeout_message,
            source_timestamp_utc=source_timestamp_utc,
        )
        self._record_correlation_row(
            status_code="timeout",
            tracking_id=tracking_id,
            event_id=tracking_id,
            is_success=False,
            is_failure=self._timeout_counts_as_failure,
            message=timeout_message,
            source_timestamp_utc=source_timestamp_utc,
        )

        waiter = self._pop_waiter(tracking_id)
        if waiter is not None:
            waiter.put(outcome)
            return

        if self._run_mode == "correlateexistingtraffic":
            self._outcomes.put(outcome)

    def _record_failed_response(
        self,
        *,
        status_code: str,
        tracking_id: Optional[str],
        event_id: Optional[str] = None,
        message: Optional[str] = None,
        source_timestamp_utc: Optional[datetime] = None,
        destination_timestamp_utc: Optional[datetime] = None,
        latency_ms: Optional[float] = None,
    ) -> None:
        FailedResponseReportRegistry.add(
            FailedResponseReportRow(
                occurred_utc=datetime.now(timezone.utc),
                scenario_name=self._scenario_name,
                source_endpoint=self._source_endpoint.name,
                destination_endpoint=(
                    self._destination_endpoint.name if self._destination_endpoint is not None else "<source-only>"
                ),
                run_mode=self._run_mode_text,
                status_code=status_code,
                tracking_id=tracking_id,
                event_id=event_id,
                message=message,
                source_timestamp_utc=source_timestamp_utc,
                destination_timestamp_utc=destination_timestamp_utc,
                latency_ms=latency_ms,
            )
        )

    def _record_correlation_row(
        self,
        *,
        status_code: str,
        tracking_id: Optional[str],
        is_success: bool,
        is_failure: bool,
        event_id: Optional[str] = None,
        gather_by_value: Optional[str] = None,
        message: Optional[str] = None,
        source_timestamp_utc: Optional[datetime] = None,
        destination_timestamp_utc: Optional[datetime] = None,
        latency_ms: Optional[float] = None,
    ) -> None:
        CorrelationReportRegistry.add(
            CorrelationReportRow(
                occurred_utc=datetime.now(timezone.utc),
                scenario_name=self._scenario_name,
                source_endpoint=self._source_endpoint.name,
                destination_endpoint=(
                    self._destination_endpoint.name if self._destination_endpoint is not None else "<source-only>"
                ),
                run_mode=self._run_mode_text,
                status_code=status_code,
                tracking_id=tracking_id,
                event_id=event_id,
                gather_by_field=self._gather_selector,
                gather_by_value=gather_by_value,
                message=message,
                source_timestamp_utc=source_timestamp_utc,
                destination_timestamp_utc=destination_timestamp_utc,
                latency_ms=latency_ms,
                is_success=is_success,
                is_failure=is_failure,
            )
        )

    def _resolve_gather_by_value(self, payload: Dict[str, Any]) -> Optional[str]:
        if not self._gather_selector:
            return None
        return self._helper._read_tracking_id(payload, self._gather_selector)

    def _reply_from_outcome(self, outcome: Dict[str, Any]) -> LoadStrikeStepReply:
        status = str(outcome.get("status") or "").strip().lower()
        if status == "matched":
            return LoadStrikeResponse.ok(
                status_code="matched",
                custom_latency_ms=_as_float(outcome.get("latencyMs")),
            )
        if status == "timeout":
            return LoadStrikeResponse.fail(
                status_code="timeout",
                message=str(outcome.get("message") or "Timed out waiting for correlated destination event."),
            )
        if status == "unmatched_destination":
            return LoadStrikeResponse.fail(
                status_code="unmatched_destination",
                message=str(outcome.get("message") or "Destination message had no source match."),
            )
        if status == "source_error":
            return LoadStrikeResponse.fail(
                status_code="source_error",
                message=str(outcome.get("message") or "Source transport error."),
            )
        return LoadStrikeResponse.fail(status_code="unknown", message="Unknown correlation outcome.")

    def _push_waiter(self, tracking_id: str) -> Queue:
        waiter: Queue = Queue(maxsize=1)
        with self._waiters_lock:
            self._waiters.setdefault(tracking_id, deque()).append(waiter)
        return waiter

    def _pop_waiter(self, tracking_id: str) -> Optional[Queue]:
        with self._waiters_lock:
            queues = self._waiters.get(tracking_id)
            if not queues:
                return None
            waiter = queues.popleft()
            if not queues:
                self._waiters.pop(tracking_id, None)
            return waiter

    @staticmethod
    def _next_occurrence(occurrences: Dict[str, int], tracking_id: str) -> int:
        next_value = _as_int(occurrences.get(tracking_id)) + 1
        occurrences[tracking_id] = next_value
        return next_value

    def _extract_tracking_id(self, payload: Dict[str, Any], selector: Optional[str]) -> Optional[str]:
        if not selector:
            return None
        return self._helper._read_tracking_id(payload, selector)

    def _payload_timestamp_utc(self, payload: Dict[str, Any]) -> Optional[datetime]:
        value = payload.get("producedUtc")
        if isinstance(value, datetime):
            return value.astimezone(timezone.utc)
        if isinstance(value, (int, float)):
            seconds_value = float(value)
            if seconds_value > 1_000_000_000_000:
                seconds_value = seconds_value / 1000.0
            return datetime.fromtimestamp(seconds_value, timezone.utc)
        return _try_parse_datetime(value)

    def _pause(self, endpoint: Optional[Any]) -> None:
        poll_interval_ms = max(_as_int(getattr(endpoint, "poll_interval_ms", 250) or 250), 1)
        time.sleep(poll_interval_ms / 1000.0)

    def _start_thread(self, target: Callable[[], None], name: str) -> None:
        thread = threading.Thread(target=target, name=f"{name}-{self._scenario_name}", daemon=True)
        self._threads.append(thread)
        thread.start()


class _ScenarioTrackingRuntimeCallbacks:
    def __init__(self, runtime_bridge: _ScenarioTrackingRuntimeBridge) -> None:
        self._runtime_bridge = runtime_bridge

    def on_matched(
        self,
        tracking_id: str,
        source_payload: Dict[str, Any],
        destination_payload: Dict[str, Any],
        latency_ms: int,
    ) -> None:
        self._runtime_bridge._on_matched(tracking_id, source_payload, destination_payload, latency_ms)

    def on_timeout(self, tracking_id: str, source_payload: Dict[str, Any]) -> None:
        self._runtime_bridge._on_timeout(tracking_id, source_payload)


def _compute_scenario_request_count(scenario: Dict[str, Any], weight: int = 1) -> int:
    simulations = scenario.get("LoadSimulations", [])
    if not isinstance(simulations, list):
        return 0

    total = 0
    for item in simulations:
        sim = item if isinstance(item, dict) else {}
        kind = str(sim.get("Kind", ""))
        rate = _as_int(sim.get("Rate"))
        min_rate = _as_int(sim.get("MinRate"))
        max_rate = _as_int(sim.get("MaxRate"))
        copies = max(_as_int(sim.get("Copies")), 1)
        iterations = max(_as_int(sim.get("Iterations")), 0)
        interval_seconds = max(_as_float(sim.get("IntervalSeconds")), 1.0)
        during_seconds = max(_as_float(sim.get("DuringSeconds")), 0.0)

        if kind == "IterationsForConstant":
            total += copies * iterations
        elif kind == "IterationsForInject":
            total += max(rate, 0) * iterations
        elif kind == "Inject":
            total += int((during_seconds / interval_seconds) * max(rate, 0) + 0.999999)
        elif kind == "InjectRandom":
            total += int(
                (during_seconds / interval_seconds) * ((max(min_rate, 0) + max(max_rate, 0)) / 2.0) + 0.999999
            )
        elif kind == "RampingInject":
            total += int((during_seconds / interval_seconds) * max(rate, 0) * 0.5 + 0.999999)
        elif kind == "KeepConstant":
            total += int(during_seconds + 0.999999) * copies
        elif kind == "RampingConstant":
            total += int(during_seconds + 0.999999) * max(int(copies * 0.5 + 0.999999), 1)

    return max(total, 0) * max(int(weight), 1)


def _count_failed_thresholds(
    scenarios: List[LoadStrikeScenario],
    scenario_stats: Dict[str, Dict[str, Any]],
    scenario_durations_ms: Dict[str, int],
    step_stats: Optional[Dict[str, Dict[str, Any]]] = None,
    run_duration_ms: int = 0,
    metric_values: Optional[List[Dict[str, Any]]] = None,
) -> int:
    return _as_int(
        _evaluate_thresholds(
            scenarios,
            scenario_stats,
            scenario_durations_ms,
            step_stats=step_stats,
            run_duration_ms=run_duration_ms,
            metric_values=metric_values,
        ).get("failedCount")
    )


def _evaluate_thresholds(
    scenarios: List[LoadStrikeScenario],
    scenario_stats: Dict[str, Dict[str, Any]],
    scenario_durations_ms: Dict[str, int],
    step_stats: Optional[Dict[str, Dict[str, Any]]] = None,
    run_duration_ms: int = 0,
    metrics_by_name: Optional[Dict[str, float]] = None,
    metric_values: Optional[List[Dict[str, Any]]] = None,
) -> Dict[str, Any]:
    failed = 0
    results: List[Dict[str, Any]] = []
    step_stats = step_stats or {}
    metrics_by_name = {str(k).lower(): _as_float(v) for k, v in (metrics_by_name or {}).items()}
    total_request_count = sum(_as_int(x.get("allRequestCount")) for x in scenario_stats.values())
    total_ok_count = sum(_as_int(x.get("allOkCount")) for x in scenario_stats.values())
    total_fail_count = sum(_as_int(x.get("allFailCount")) for x in scenario_stats.values())

    for scenario in scenarios:
        stats = scenario_stats.get(
            scenario.name,
            {
                "allRequestCount": 0,
                "allOkCount": 0,
                "allFailCount": 0,
                "totalBytes": 0,
                "totalLatencyMs": 0.0,
                "avgLatencyMs": 0.0,
                "minLatencyMs": 0.0,
                "maxLatencyMs": 0.0,
                "statusCodes": {},
            },
        )
        duration_ms = max(int(scenario_durations_ms.get(scenario.name, 0)), 0)
        scenario_step_stats = [x for x in step_stats.values() if str(x.get("scenarioName")) == scenario.name]
        for threshold in scenario.thresholds:
            scope = _normalize_threshold_scope(str(threshold.get("Scope", "Scenario")))
            step_name = str(threshold.get("StepName", "")).strip()
            field = str(threshold.get("Field", "")).lower()
            operator = str(threshold.get("Operator", "")).lower()
            expected = _as_float(threshold.get("Value"))
            abort_when_error_count = threshold.get("AbortWhenErrorCount")
            check_expression = str(
                threshold.get("CheckExpression")
                or _build_threshold_expression(scope=scope, step_name=step_name, field=field)
            ).strip()
            if not check_expression:
                check_expression = _build_threshold_expression(scope=scope, step_name=step_name, field=field)
            start_check_after_seconds = max(_as_float(threshold.get("StartCheckAfterSeconds")), 0.0)
            if start_check_after_seconds > 0 and duration_ms < int(start_check_after_seconds * 1000):
                continue

            error_count = 0
            exception_message = ""
            predicate = threshold.get("Predicate")
            typed_stats_factory = str(threshold.get("TypedStatsFactory") or "").strip().lower()
            if callable(predicate):
                try:
                    if typed_stats_factory == "scenario":
                        passed = bool(predicate(LoadStrikeScenarioStats(dict(stats))))
                    elif typed_stats_factory == "step":
                        passed = bool(
                            predicate(
                                LoadStrikeStepStats(
                                    dict(step_stats.get(f"{scenario.name}::{step_name}", {}))
                                )
                            )
                        )
                    elif typed_stats_factory == "metric":
                        passed = bool(
                            predicate(
                                LoadStrikeMetricStats(
                                    _build_metric_stats_payload(metric_values or [], run_duration_ms)
                                )
                            )
                        )
                    else:
                        passed = bool(
                            predicate(
                                {
                                    "scenarioName": scenario.name,
                                    "scope": scope,
                                    "stepName": step_name,
                                    "checkExpression": check_expression,
                                    "scenarioStats": dict(stats),
                                    "stepStats": [dict(x) for x in scenario_step_stats],
                                    "runStats": {
                                        "allRequestCount": total_request_count,
                                        "allOkCount": total_ok_count,
                                        "allFailCount": total_fail_count,
                                        "durationMs": max(run_duration_ms, 0),
                                    },
                                    "metrics": dict(metrics_by_name),
                                }
                            )
                        )
                    if not passed:
                        error_count += 1
                except Exception as error:  # noqa: BLE001
                    error_count += 1
                    exception_message = str(error)
            else:
                actual = _resolve_threshold_actual_value(
                    scope=scope,
                    field=field,
                    scenario_name=scenario.name,
                    step_name=step_name,
                    scenario_stats_row=stats,
                    step_stats=step_stats,
                    total_request_count=total_request_count,
                    total_ok_count=total_ok_count,
                    total_fail_count=total_fail_count,
                    run_duration_ms=run_duration_ms,
                    metrics_by_name=metrics_by_name,
                )

                if scope == "step" and step_name and f"{scenario.name}::{step_name}" not in step_stats:
                    error_count += 1
                elif _is_comparison_failed(actual, operator, expected):
                    error_count += 1

            final_failed = error_count > 0
            if abort_when_error_count is not None and error_count >= _as_int(abort_when_error_count):
                final_failed = True

            results.append(
                {
                    "scenarioName": scenario.name,
                    "scope": scope,
                    "stepName": step_name,
                    "checkExpression": check_expression,
                    "isFailed": final_failed,
                    "errorCount": error_count,
                    "exceptionMessage": exception_message or None,
                    "exceptionMsg": exception_message or None,
                }
            )
            if final_failed:
                failed += 1

    return {"failedCount": failed, "results": results}


def _normalize_threshold_scope(scope: str) -> str:
    value = str(scope or "").strip().lower()
    if value in {"step", "metric"}:
        return value
    return "scenario"


def _build_threshold_expression(*, scope: str, step_name: str, field: str) -> str:
    if scope == "step":
        return f"step-threshold:{step_name or field or 'step'}"
    if scope == "metric":
        return "metric-threshold"
    return "scenario-threshold"


def _resolve_threshold_actual_value(
    *,
    scope: str,
    field: str,
    scenario_name: str,
    step_name: str,
    scenario_stats_row: Dict[str, Any],
    step_stats: Dict[str, Dict[str, Any]],
    total_request_count: int,
    total_ok_count: int,
    total_fail_count: int,
    run_duration_ms: int,
    metrics_by_name: Dict[str, float],
) -> float:
    field = str(field or "").lower()
    if scope == "step":
        row = step_stats.get(f"{scenario_name}::{step_name}", {})
        step_ok = _as_int(row.get("okCount"))
        step_fail = _as_int(row.get("failCount"))
        step_requests = _as_int(row.get("requestCount")) or (step_ok + step_fail)
        if field == "allokcount":
            return float(step_ok)
        if field == "allfailcount":
            return float(step_fail)
        if field == "allrequestcount":
            return float(step_requests)
        if field in {"totalbytes", "sizebytes"}:
            return float(_as_int(row.get("totalBytes")))
        if field == "avglatencyms":
            return float(_as_float(row.get("avgLatencyMs")))
        if field == "minlatencyms":
            return float(_as_float(row.get("minLatencyMs")))
        if field == "maxlatencyms":
            return float(_as_float(row.get("maxLatencyMs")))
        if field == "durationms":
            return float(_as_float(row.get("totalLatencyMs")))
        if field.startswith("statuscode:") or field.startswith("statuscode."):
            separator = ":" if ":" in field else "."
            status_code = field.split(separator, 1)[1]
            status_codes = row.get("statusCodes") if isinstance(row.get("statusCodes"), dict) else {}
            return float(_as_int(status_codes.get(status_code)))
        return float(step_requests)

    if scope == "metric":
        if field in metrics_by_name:
            return float(_as_float(metrics_by_name.get(field)))
        if field == "allrequestcount":
            return float(total_request_count)
        if field == "allokcount":
            return float(total_ok_count)
        if field == "allfailcount":
            return float(total_fail_count)
        if field == "durationms":
            return float(max(run_duration_ms, 0))
        return float(total_request_count)

    if field == "allokcount":
        return float(_as_int(scenario_stats_row.get("allOkCount")))
    if field == "allfailcount":
        return float(_as_int(scenario_stats_row.get("allFailCount")))
    if field in {"totalbytes", "sizebytes"}:
        return float(_as_int(scenario_stats_row.get("totalBytes")))
    if field == "avglatencyms":
        return float(_as_float(scenario_stats_row.get("avgLatencyMs")))
    if field == "minlatencyms":
        return float(_as_float(scenario_stats_row.get("minLatencyMs")))
    if field == "maxlatencyms":
        return float(_as_float(scenario_stats_row.get("maxLatencyMs")))
    if field == "durationms":
        return float(_as_float(scenario_stats_row.get("totalLatencyMs")))
    if field.startswith("statuscode:") or field.startswith("statuscode."):
        separator = ":" if ":" in field else "."
        status_code = field.split(separator, 1)[1]
        status_codes = (
            scenario_stats_row.get("statusCodes")
            if isinstance(scenario_stats_row.get("statusCodes"), dict)
            else {}
        )
        return float(_as_int(status_codes.get(status_code)))
    return float(_as_int(scenario_stats_row.get("allRequestCount")))


def _is_comparison_failed(actual: float, operator: str, expected: float) -> bool:
    if operator == "gt":
        return not (actual > expected)
    if operator == "gte":
        return not (actual >= expected)
    if operator == "lt":
        return not (actual < expected)
    if operator == "lte":
        return not (actual <= expected)
    if operator == "eq":
        return actual != expected
    if operator == "neq":
        return actual == expected
    return False


def _collect_metric_values(values: List[Any], duration_ms: int = 0) -> List[Dict[str, Any]]:
    merged: Dict[str, Dict[str, Any]] = {}
    for item in values:
        normalized = _normalize_metric_value(item)
        if normalized is None:
            continue
        normalized["durationMs"] = max(int(duration_ms), 0)
        key = _metric_merge_key(normalized)
        existing = merged.get(key)
        if existing is None:
            merged[key] = normalized
            continue
        if existing.get("type") == "counter" and normalized.get("type") == "counter":
            existing["value"] = _as_float(existing.get("value")) + _as_float(normalized.get("value"))
        else:
            existing["type"] = normalized.get("type")
            existing["value"] = normalized.get("value")
    return list(merged.values())


def _normalize_metric_value(value: Any) -> Optional[Dict[str, Any]]:
    if isinstance(value, dict) and "metric" in value:
        normalized = _normalize_metric_value(value.get("metric"))
        if normalized is None:
            return None
        if not str(normalized.get("scenarioName") or "").strip():
            normalized["scenarioName"] = str(value.get("scenarioName") or "")
        if not str(normalized.get("unitOfMeasure") or "").strip():
            normalized["unitOfMeasure"] = str(value.get("unitOfMeasure") or value.get("unit_of_measure") or "")
        return normalized

    if isinstance(value, (LoadStrikeCounter, LoadStrikeGauge)):
        return {
            "name": value.name,
            "type": value.type,
            "value": value.value(),
            "scenarioName": str(getattr(value, "scenario_name", "") or ""),
            "unitOfMeasure": str(getattr(value, "unit_of_measure", "") or getattr(value, "unitOfMeasure", "") or ""),
        }

    if not isinstance(value, dict):
        return None

    name = str(value.get("name") or value.get("Name") or "").strip()
    if not name:
        return None

    metric_type = str(value.get("type") or value.get("Type") or value.get("kind") or value.get("Kind") or "gauge").strip().lower()
    normalized_type = "counter" if metric_type == "counter" else "gauge"
    raw_value = value.get("value")
    if callable(raw_value):
        try:
            raw_value = raw_value()
        except Exception:  # noqa: BLE001
            raw_value = 0
    if raw_value is None:
        raw_value = value.get("Value", value.get("current", value.get("Current", 0)))

    return {
        "name": name,
        "type": normalized_type,
        "value": _as_float(raw_value),
        "scenarioName": str(value.get("scenarioName") or value.get("ScenarioName") or ""),
        "unitOfMeasure": str(value.get("unitOfMeasure") or value.get("UnitOfMeasure") or value.get("unit") or ""),
    }


def _normalize_status_code(status_code: Any, is_success: bool) -> str:
    resolved = str(status_code or "").strip()
    if resolved:
        return resolved
    return "200" if is_success else "500"


def _normalize_plugin_name(name: Any) -> str:
    resolved = str(name or "").strip()
    return resolved or "unnamed-plugin"


def _resolve_worker_plugins(
    custom_plugins: List[LoadStrikeWorkerPlugin],
) -> List[LoadStrikeWorkerPlugin]:
    registry: Dict[str, LoadStrikeWorkerPlugin] = {}
    for plugin in _create_built_in_worker_plugins():
        registry[_normalize_plugin_name(_plugin_name(plugin)).lower()] = plugin
    for plugin in custom_plugins:
        key = _normalize_plugin_name(_plugin_name(plugin)).lower()
        if key not in registry:
            registry[key] = plugin
    return list(registry.values())


def _create_built_in_worker_plugins() -> List[LoadStrikeWorkerPlugin]:
    class _FailedResponsesPlugin:
        plugin_name = "LoadStrike Failed Responses"
        PluginName = property(lambda self: self.plugin_name)

        def start(self, _session: LoadStrikeSessionStartInfo) -> None:
            FailedResponseReportRegistry.reset()

        def get_data(self, _result: Dict[str, Any]) -> LoadStrikePluginData:
            data = LoadStrikePluginData.create(self.plugin_name)
            rows = sorted(
                FailedResponseReportRegistry.snapshot(),
                key=lambda row: row.occurred_utc,
                reverse=True,
            )
            if not rows:
                data.hints.append("No failed or timed out cross-platform rows were captured.")
                return data

            data.hints.append(f"Captured rows: {len(rows)}")
            data.hints.append("Includes timeout, source_error, and unmatched_destination outcomes.")
            table = LoadStrikePluginDataTable.create("Failed and Timed Out Rows")
            for row in rows:
                table.add_row(
                    {
                        "OccurredUtc": _format_report_datetime(row.occurred_utc),
                        "Scenario": row.scenario_name,
                        "Source": row.source_endpoint,
                        "Destination": row.destination_endpoint,
                        "RunMode": row.run_mode,
                        "StatusCode": row.status_code,
                        "TrackingId": row.tracking_id or "",
                        "EventId": row.event_id or "",
                        "SourceTimestampUtc": _format_report_datetime(row.source_timestamp_utc),
                        "DestinationTimestampUtc": _format_report_datetime(row.destination_timestamp_utc),
                        "LatencyMs": _format_report_number(row.latency_ms),
                        "Message": row.message or "",
                    }
                )
            data.add_table(table)
            return data

    class _CorrelationReportPlugin:
        plugin_name = "LoadStrike Correlation"
        PluginName = property(lambda self: self.plugin_name)

        def start(self, _session: LoadStrikeSessionStartInfo) -> None:
            CorrelationReportRegistry.reset()

        def get_data(self, _result: Dict[str, Any]) -> LoadStrikePluginData:
            data = LoadStrikePluginData.create(self.plugin_name)
            rows = sorted(
                CorrelationReportRegistry.snapshot(),
                key=lambda row: row.occurred_utc,
                reverse=True,
            )
            if not rows:
                data.hints.append("No cross-platform correlation rows were captured.")
                return data

            data.hints.append(f"Captured correlation rows: {len(rows)}")

            ungrouped = LoadStrikePluginDataTable.create("Ungrouped Correlation Rows")
            for row in rows:
                ungrouped.add_row(
                    {
                        "OccurredUtc": _format_report_datetime(row.occurred_utc),
                        "Scenario": row.scenario_name,
                        "Source": row.source_endpoint,
                        "Destination": row.destination_endpoint,
                        "RunMode": row.run_mode,
                        "StatusCode": row.status_code,
                        "IsSuccess": row.is_success,
                        "IsFailure": row.is_failure,
                        "GatherByField": row.gather_by_field or "",
                        "GatherByValue": row.gather_by_value or "",
                        "TrackingId": row.tracking_id or "",
                        "EventId": row.event_id or "",
                        "SourceTimestampUtc": _format_report_datetime(row.source_timestamp_utc),
                        "DestinationTimestampUtc": _format_report_datetime(row.destination_timestamp_utc),
                        "LatencyMs": _format_report_number(row.latency_ms),
                        "Message": row.message or "",
                    }
                )
            data.add_table(ungrouped)

            grouped_rows = _build_grouped_correlation_summary_rows(rows)
            grouped = LoadStrikePluginDataTable.create("Grouped Correlation Summary (GatherByField)")
            for grouped_row in grouped_rows:
                grouped.add_row(grouped_row)
            if not grouped_rows:
                data.hints.append(
                    "No GatherByField grouping data was captured. Configure Destination.GatherByField to enable grouped summaries."
                )
            else:
                data.hints.append(f"GatherBy groups: {len(grouped_rows)}")
            data.add_table(grouped)
            return data

    return [_FailedResponsesPlugin(), _CorrelationReportPlugin()]


def _format_report_datetime(value: Optional[datetime]) -> str:
    if value is None:
        return ""
    return value.astimezone(timezone.utc).isoformat()


def _format_report_number(value: Optional[float]) -> str:
    if value is None:
        return ""
    return f"{float(value):0.3f}".rstrip("0").rstrip(".")


def _format_dotnet_timedelta(value: Any) -> str:
    value = _coerce_report_timedelta(value)
    total_ticks = int(round(value.total_seconds() * 10_000_000))
    sign = "-" if total_ticks < 0 else ""
    total_ticks = abs(total_ticks)
    ticks_per_day = 24 * 60 * 60 * 10_000_000
    ticks_per_hour = 60 * 60 * 10_000_000
    ticks_per_minute = 60 * 10_000_000
    ticks_per_second = 10_000_000
    days, remainder = divmod(total_ticks, ticks_per_day)
    hours, remainder = divmod(remainder, ticks_per_hour)
    minutes, remainder = divmod(remainder, ticks_per_minute)
    seconds, ticks = divmod(remainder, ticks_per_second)
    base = f"{sign}{days}." if days else sign
    base += f"{hours:02}:{minutes:02}:{seconds:02}"
    if ticks == 0:
        return base
    return f"{base}.{ticks:07d}"


def _parse_dotnet_timedelta(value: str) -> Optional[timedelta]:
    text = value.strip()
    if not text:
        return None
    sign = -1 if text.startswith("-") else 1
    if text[0] in "+-":
        text = text[1:]
    day_count = 0
    if "." in text and text.count(":") == 2 and text.find(".") < text.find(":"):
        day_text, text = text.split(".", 1)
        if not day_text.isdigit():
            return None
        day_count = int(day_text)
    parts = text.split(":")
    if len(parts) != 3:
        return None
    hour_text, minute_text, second_text = parts
    if "." in second_text:
        second_text, fraction_text = second_text.split(".", 1)
    else:
        fraction_text = ""
    if not (hour_text.isdigit() and minute_text.isdigit() and second_text.isdigit()):
        return None
    hours = int(hour_text)
    minutes = int(minute_text)
    seconds = int(second_text)
    fraction = int((fraction_text + "0000000")[:7]) if fraction_text else 0
    microseconds = fraction // 10
    value_delta = timedelta(
        days=day_count,
        hours=hours,
        minutes=minutes,
        seconds=seconds,
        microseconds=microseconds,
    )
    return -value_delta if sign < 0 else value_delta


def _coerce_report_timedelta(value: Any) -> timedelta:
    if isinstance(value, timedelta):
        return value
    if isinstance(value, str):
        parsed = _parse_dotnet_timedelta(value)
        if parsed is not None:
            return parsed
    return _timedelta_from_ms(value)


def _report_duration_seconds(value: Any) -> float:
    return max(_coerce_report_timedelta(value).total_seconds(), 0.0)


def _loadstrike_node_type_tag(value: Any) -> int:
    if isinstance(value, dict):
        if "tag" in value:
            return _as_int(value.get("tag"))
        if "Tag" in value:
            return _as_int(value.get("Tag"))
    text = str(value or "").strip()
    return {
        "SingleNode": 0,
        "Coordinator": 1,
        "Agent": 2,
    }.get(text, _as_int(value))


def _dotnet_report_lines(lines: List[str]) -> str:
    return os.linesep.join(lines) + os.linesep


def _escape_csv(value: Any) -> str:
    text = str(value or "")
    if any(marker in text for marker in [",", '"', "\n", "\r"]):
        escaped = text.replace('"', '""')
        return f'"{escaped}"'
    return text


def _build_dotnet_txt_report(node_stats: LoadStrikeNodeStats) -> str:
    scenarios = sorted(node_stats.scenario_stats, key=lambda row: row.sort_index)
    lines = [
        f"TestSuite: {node_stats.test_info.test_suite}",
        f"TestName: {node_stats.test_info.test_name}",
        f"SessionId: {node_stats.test_info.session_id}",
        f"NodeType: {_loadstrike_node_type_tag(node_stats._dict('nodeInfo').get('nodeType'))}",
        f"Duration: {_format_dotnet_timedelta(node_stats._value('duration', 'durationMs'))}",
        f"Requests: {node_stats.all_request_count}  OK: {node_stats.all_ok_count}  FAIL: {node_stats.all_fail_count}",
        "",
        "Scenarios:",
    ]

    for scenario in scenarios:
        lines.append(
            f"- {scenario.scenario_name}: req={scenario.all_request_count} "
            f"ok={scenario.all_ok_count} fail={scenario.all_fail_count} "
            f"duration={_format_dotnet_timedelta(scenario._value('duration', 'durationMs'))}"
        )

    if any(scenario.step_stats for scenario in scenarios):
        lines.extend(["", "Steps:"])
        for scenario in scenarios:
            for step in sorted(scenario.step_stats, key=lambda row: row.sort_index):
                total = step.ok.request.count + step.fail.request.count
                lines.append(
                    f"- {scenario.scenario_name}.{step.step_name}: req={total} "
                    f"ok={step.ok.request.count} fail={step.fail.request.count}"
                )

    if node_stats.thresholds:
        lines.extend(["", "Thresholds:"])
        for threshold in node_stats.thresholds:
            lines.append(
                f"- scenario={threshold.scenario_name} step={threshold.step_name} "
                f"check={threshold.check_expression} failed={threshold.is_failed} "
                f"errors={threshold.error_count} message={threshold.exception_msg}"
            )

    if node_stats.plugins_data:
        lines.extend(["", "Plugin Tables:"])
        for plugin in node_stats.plugins_data:
            lines.append(f"- {plugin.plugin_name}")
            for table in plugin.tables:
                lines.append(f"  Table: {table.table_name} rows={len(table.rows)}")

    return _dotnet_report_lines(lines)


def _build_dotnet_csv_report(node_stats: LoadStrikeNodeStats) -> str:
    lines = ["ScenarioName,Requests,Ok,Fail,DurationSeconds,Rps"]
    for scenario in sorted(node_stats.scenario_stats, key=lambda row: row.sort_index):
        duration_seconds = _report_duration_seconds(scenario._value("duration", "durationMs"))
        rps = 0.0 if duration_seconds <= 0 else scenario.all_request_count / duration_seconds
        lines.append(
            f"{_escape_csv(scenario.scenario_name)},{scenario.all_request_count},{scenario.all_ok_count},"
            f"{scenario.all_fail_count},{_format_report_number(duration_seconds)},{_format_report_number(rps)}"
        )
    return _dotnet_report_lines(lines)


def _build_dotnet_markdown_report(node_stats: LoadStrikeNodeStats) -> str:
    scenarios = sorted(node_stats.scenario_stats, key=lambda row: row.sort_index)
    lines = [
        f"# {node_stats.test_info.test_suite} / {node_stats.test_info.test_name}",
        "",
        f"- Session: `{node_stats.test_info.session_id}`",
        f"- Duration: `{_format_dotnet_timedelta(node_stats._value('duration', 'durationMs'))}`",
        f"- Total Requests: `{node_stats.all_request_count}`",
        f"- OK: `{node_stats.all_ok_count}`",
        f"- FAIL: `{node_stats.all_fail_count}`",
        "",
        "## Scenarios",
        "",
        "| Scenario | Requests | OK | FAIL | Duration |",
        "|---|---:|---:|---:|---:|",
    ]

    for scenario in scenarios:
        lines.append(
                f"| {scenario.scenario_name} | {scenario.all_request_count} | {scenario.all_ok_count} | "
            f"{scenario.all_fail_count} | {_format_report_number(_report_duration_seconds(scenario._value('duration', 'durationMs')))}s |"
        )

    if any(scenario.step_stats for scenario in scenarios):
        lines.extend(["", "## Steps", "", "| Scenario | Step | Requests | OK | FAIL |", "|---|---|---:|---:|---:|"])
        for scenario in scenarios:
            for step in sorted(scenario.step_stats, key=lambda row: row.sort_index):
                total = step.ok.request.count + step.fail.request.count
                lines.append(
                    f"| {scenario.scenario_name} | {step.step_name} | {total} | "
                    f"{step.ok.request.count} | {step.fail.request.count} |"
                )

    if node_stats.thresholds:
        lines.extend(
            [
                "",
                "## Thresholds",
                "",
                "| Scenario | Step | Check | Failed | Errors | Exception |",
                "|---|---|---|---:|---:|---|",
            ]
        )
        for threshold in node_stats.thresholds:
            lines.append(
                f"| {threshold.scenario_name} | {threshold.step_name} | {threshold.check_expression} | "
                f"{threshold.is_failed} | {threshold.error_count} | {threshold.exception_msg} |"
            )

    return _dotnet_report_lines(lines)


def _build_grouped_correlation_summary_rows(rows: List[Any]) -> List[Dict[str, Any]]:
    grouped: Dict[tuple[str, str, str, str], List[Any]] = {}
    for row in rows:
        gather_by_field = str(getattr(row, "gather_by_field", "") or "").strip()
        if not gather_by_field:
            continue
        gather_by_value = str(getattr(row, "gather_by_value", "") or "").strip() or "<missing>"
        key = (
            str(getattr(row, "scenario_name", "") or ""),
            str(getattr(row, "destination_endpoint", "") or ""),
            gather_by_field,
            gather_by_value,
        )
        grouped.setdefault(key, []).append(row)

    summary_rows: List[Dict[str, Any]] = []
    for key in sorted(grouped, key=lambda value: value):
        scenario_name, destination_endpoint, gather_by_field, gather_by_value = key
        items = grouped[key]
        total = len(items)
        success = sum(1 for item in items if bool(getattr(item, "is_success", False)))
        failure = sum(1 for item in items if bool(getattr(item, "is_failure", False)))
        statuses = [str(getattr(item, "status_code", "") or "").strip().lower() for item in items]
        latencies = sorted(
            float(getattr(item, "latency_ms"))
            for item in items
            if getattr(item, "latency_ms", None) is not None
        )
        latency_count = len(latencies)
        summary_rows.append(
            {
                "Scenario": scenario_name,
                "Destination": destination_endpoint,
                "GatherByField": gather_by_field,
                "GatherByValue": gather_by_value,
                "Total": total,
                "Success": success,
                "Failure": failure,
                "SuccessRatePercent": _format_report_number(0.0 if total <= 0 else (100.0 * success / total)),
                "FailureRatePercent": _format_report_number(0.0 if total <= 0 else (100.0 * failure / total)),
                "Matched": sum(1 for status in statuses if status == "matched"),
                "Timeout": sum(1 for status in statuses if status == "timeout"),
                "UnmatchedDestination": sum(1 for status in statuses if status == "unmatched_destination"),
                "SourceError": sum(1 for status in statuses if status == "source_error"),
                "SourceSuccess": sum(1 for status in statuses if status == "source_success"),
                "OtherStatus": max(
                    0,
                    total
                    - sum(
                        1
                        for status in statuses
                        if status in {"matched", "timeout", "unmatched_destination", "source_error", "source_success"}
                    ),
                ),
                "LatencySamples": latency_count,
                "LatencyMinMs": _format_report_number(latencies[0]) if latency_count else "",
                "LatencyMeanMs": _format_report_number(sum(latencies) / latency_count) if latency_count else "",
                "LatencyP50Ms": _format_report_number(_percentile_numeric(latencies, 50)) if latency_count else "",
                "LatencyP80Ms": _format_report_number(_percentile_numeric(latencies, 80)) if latency_count else "",
                "LatencyP85Ms": _format_report_number(_percentile_numeric(latencies, 85)) if latency_count else "",
                "LatencyP90Ms": _format_report_number(_percentile_numeric(latencies, 90)) if latency_count else "",
                "LatencyP95Ms": _format_report_number(_percentile_numeric(latencies, 95)) if latency_count else "",
                "LatencyP99Ms": _format_report_number(_percentile_numeric(latencies, 99)) if latency_count else "",
                "LatencyMaxMs": _format_report_number(latencies[-1]) if latency_count else "",
            }
        )
    return summary_rows


def _build_html_table(
    rows: List[Dict[str, Any]],
    headers: Optional[List[str]] = None,
) -> str:
    resolved_rows = [dict(row) for row in rows if isinstance(row, dict)]
    resolved_headers = list(headers or [])
    if not resolved_headers:
        seen: List[str] = []
        for row in resolved_rows:
            for key in row.keys():
                text = str(key)
                if text not in seen:
                    seen.append(text)
        resolved_headers = seen
    return _render_plugin_table({"headers": resolved_headers, "rows": resolved_rows})


def _measurement_payload(row: Dict[str, Any], name: str) -> Dict[str, Any]:
    value = row.get(name)
    return value if isinstance(value, dict) else {}


def _build_measurement_table_rows(
    scenarios: List[Dict[str, Any]],
    *,
    include_steps: bool,
) -> List[Dict[str, Any]]:
    rows: List[Dict[str, Any]] = []
    for scenario in scenarios:
        scenario_name = str(scenario.get("scenarioName") or "")
        if include_steps:
            step_rows = [
                dict(step)
                for step in scenario.get("stepStats", [])
                if isinstance(step, dict)
            ]
            for step in sorted(step_rows, key=lambda row: _as_int(row.get("sortIndex"))):
                for result_name in ("OK", "FAIL"):
                    measurement = _measurement_payload(step, result_name.lower())
                    rows.append(
                        {
                            "Scope": "Step",
                            "Scenario": scenario_name,
                            "Step": str(step.get("stepName") or ""),
                            "Result": result_name,
                            "Count": _as_int(measurement.get("request", {}).get("count")),
                            "Percent": _as_int(measurement.get("request", {}).get("percent")),
                            "RPS": _format_report_number(_as_float(measurement.get("request", {}).get("rps"))),
                            "LatencyMinMs": _format_report_number(_as_float(measurement.get("latency", {}).get("minMs"))),
                            "LatencyMeanMs": _format_report_number(_as_float(measurement.get("latency", {}).get("meanMs"))),
                            "LatencyP50Ms": _format_report_number(_as_float(measurement.get("latency", {}).get("percent50"))),
                            "LatencyP75Ms": _format_report_number(_as_float(measurement.get("latency", {}).get("percent75"))),
                            "LatencyP95Ms": _format_report_number(_as_float(measurement.get("latency", {}).get("percent95"))),
                            "LatencyP99Ms": _format_report_number(_as_float(measurement.get("latency", {}).get("percent99"))),
                            "LatencyMaxMs": _format_report_number(_as_float(measurement.get("latency", {}).get("maxMs"))),
                            "LatencyStdDev": _format_report_number(_as_float(measurement.get("latency", {}).get("stdDev"))),
                            "Latency<=800ms": _as_int(
                                measurement.get("latency", {}).get("latencyCount", {}).get("lessOrEq800")
                            ),
                            "Latency800-1200ms": _as_int(
                                measurement.get("latency", {}).get("latencyCount", {}).get("more800Less1200")
                            ),
                            "Latency>=1200ms": _as_int(
                                measurement.get("latency", {}).get("latencyCount", {}).get("moreOrEq1200")
                            ),
                            "BytesTotal": _as_int(measurement.get("dataTransfer", {}).get("allBytes")),
                            "BytesMin": _as_int(measurement.get("dataTransfer", {}).get("minBytes")),
                            "BytesMean": _as_int(measurement.get("dataTransfer", {}).get("meanBytes")),
                            "BytesP50": _as_int(measurement.get("dataTransfer", {}).get("percent50")),
                            "BytesP75": _as_int(measurement.get("dataTransfer", {}).get("percent75")),
                            "BytesP95": _as_int(measurement.get("dataTransfer", {}).get("percent95")),
                            "BytesP99": _as_int(measurement.get("dataTransfer", {}).get("percent99")),
                            "BytesMax": _as_int(measurement.get("dataTransfer", {}).get("maxBytes")),
                            "BytesStdDev": _format_report_number(_as_float(measurement.get("dataTransfer", {}).get("stdDev"))),
                        }
                    )
            continue

        for result_name in ("OK", "FAIL"):
            measurement = _measurement_payload(scenario, result_name.lower())
            rows.append(
                {
                    "Scope": "Scenario",
                    "Scenario": scenario_name,
                    "Step": "",
                    "Result": result_name,
                    "Count": _as_int(measurement.get("request", {}).get("count")),
                    "Percent": _as_int(measurement.get("request", {}).get("percent")),
                    "RPS": _format_report_number(_as_float(measurement.get("request", {}).get("rps"))),
                    "LatencyMinMs": _format_report_number(_as_float(measurement.get("latency", {}).get("minMs"))),
                    "LatencyMeanMs": _format_report_number(_as_float(measurement.get("latency", {}).get("meanMs"))),
                    "LatencyP50Ms": _format_report_number(_as_float(measurement.get("latency", {}).get("percent50"))),
                    "LatencyP75Ms": _format_report_number(_as_float(measurement.get("latency", {}).get("percent75"))),
                    "LatencyP95Ms": _format_report_number(_as_float(measurement.get("latency", {}).get("percent95"))),
                    "LatencyP99Ms": _format_report_number(_as_float(measurement.get("latency", {}).get("percent99"))),
                    "LatencyMaxMs": _format_report_number(_as_float(measurement.get("latency", {}).get("maxMs"))),
                    "LatencyStdDev": _format_report_number(_as_float(measurement.get("latency", {}).get("stdDev"))),
                    "Latency<=800ms": _as_int(
                        measurement.get("latency", {}).get("latencyCount", {}).get("lessOrEq800")
                    ),
                    "Latency800-1200ms": _as_int(
                        measurement.get("latency", {}).get("latencyCount", {}).get("more800Less1200")
                    ),
                    "Latency>=1200ms": _as_int(
                        measurement.get("latency", {}).get("latencyCount", {}).get("moreOrEq1200")
                    ),
                    "BytesTotal": _as_int(measurement.get("dataTransfer", {}).get("allBytes")),
                    "BytesMin": _as_int(measurement.get("dataTransfer", {}).get("minBytes")),
                    "BytesMean": _as_int(measurement.get("dataTransfer", {}).get("meanBytes")),
                    "BytesP50": _as_int(measurement.get("dataTransfer", {}).get("percent50")),
                    "BytesP75": _as_int(measurement.get("dataTransfer", {}).get("percent75")),
                    "BytesP95": _as_int(measurement.get("dataTransfer", {}).get("percent95")),
                    "BytesP99": _as_int(measurement.get("dataTransfer", {}).get("percent99")),
                    "BytesMax": _as_int(measurement.get("dataTransfer", {}).get("maxBytes")),
                    "BytesStdDev": _format_report_number(_as_float(measurement.get("dataTransfer", {}).get("stdDev"))),
                }
            )
    return rows


def _build_status_code_table_rows(scenarios: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    rows: List[Dict[str, Any]] = []
    for scenario in scenarios:
        scenario_name = str(scenario.get("scenarioName") or "")
        for result_name in ("OK", "FAIL"):
            measurement = _measurement_payload(scenario, result_name.lower())
            for code in measurement.get("statusCodes", []) or []:
                if not isinstance(code, dict):
                    continue
                rows.append(
                    {
                        "Scope": "Scenario",
                        "Scenario": scenario_name,
                        "Step": "",
                        "Result": result_name,
                        "StatusCode": str(code.get("statusCode") or ""),
                        "Message": str(code.get("message") or ""),
                        "Count": _as_int(code.get("count")),
                        "Percent": _as_int(code.get("percent")),
                        "IsError": bool(code.get("isError")),
                    }
                )
        for step in scenario.get("stepStats", []) or []:
            if not isinstance(step, dict):
                continue
            for result_name in ("OK", "FAIL"):
                measurement = _measurement_payload(step, result_name.lower())
                for code in measurement.get("statusCodes", []) or []:
                    if not isinstance(code, dict):
                        continue
                    rows.append(
                        {
                            "Scope": "Step",
                            "Scenario": scenario_name,
                            "Step": str(step.get("stepName") or ""),
                            "Result": result_name,
                            "StatusCode": str(code.get("statusCode") or ""),
                            "Message": str(code.get("message") or ""),
                            "Count": _as_int(code.get("count")),
                            "Percent": _as_int(code.get("percent")),
                            "IsError": bool(code.get("isError")),
                        }
                    )
    return rows


def _build_failed_status_rows(scenarios: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    rows: List[Dict[str, Any]] = []
    for scenario in scenarios:
        if not isinstance(scenario, dict):
            continue
        scenario_name = str(scenario.get("scenarioName") or "")
        fail_block = scenario.get("fail") if isinstance(scenario.get("fail"), dict) else {}
        for code in fail_block.get("statusCodes", []) or []:
            if not isinstance(code, dict):
                continue
            count = _as_int(code.get("count"))
            is_error = bool(code.get("isError"))
            if count <= 0 and not is_error:
                continue
            rows.append(
                {
                    "Scope": "Scenario",
                    "Scenario": scenario_name,
                    "Step": "",
                    "StatusCode": str(code.get("statusCode") or ""),
                    "Message": str(code.get("message") or ""),
                    "Count": count,
                    "Percent": _as_int(code.get("percent")),
                    "IsError": is_error,
                }
            )
        for step in sorted(scenario.get("stepStats", []) or [], key=lambda item: _as_int((item or {}).get("sortIndex"))):
            if not isinstance(step, dict):
                continue
            step_name = str(step.get("stepName") or "")
            step_fail = step.get("fail") if isinstance(step.get("fail"), dict) else {}
            for code in step_fail.get("statusCodes", []) or []:
                if not isinstance(code, dict):
                    continue
                count = _as_int(code.get("count"))
                is_error = bool(code.get("isError"))
                if count <= 0 and not is_error:
                    continue
                rows.append(
                    {
                        "Scope": "Step",
                        "Scenario": scenario_name,
                        "Step": step_name,
                        "StatusCode": str(code.get("statusCode") or ""),
                        "Message": str(code.get("message") or ""),
                        "Count": count,
                        "Percent": _as_int(code.get("percent")),
                        "IsError": is_error,
                    }
                )
    return rows


def _build_failed_event_rows(plugins: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    rows: List[Dict[str, Any]] = []
    for plugin in plugins:
        plugin_name = str(plugin.get("pluginName") or "")
        for table in plugin.get("tables", []) or []:
            if not isinstance(table, dict):
                continue
            table_name = str(table.get("tableName") or "")
            is_failed_table = (
                "fail" in plugin_name.lower()
                or "timeout" in plugin_name.lower()
                or "fail" in table_name.lower()
                or "timeout" in table_name.lower()
            )
            if not is_failed_table:
                continue
            for row in table.get("rows", []) or []:
                if not isinstance(row, dict):
                    continue
                rows.append(
                    {
                        "Category": f"{plugin_name}: {table_name}",
                        "OccurredUtc": _read_report_row_text(row, "OccurredUtc"),
                        "Scenario": _read_report_row_text(row, "Scenario", "scenarioName"),
                        "Step": _read_report_row_text(row, "Step", "stepName"),
                        "Source": _read_report_row_text(row, "Source"),
                        "Destination": _read_report_row_text(row, "Destination"),
                        "StatusCode": _read_report_row_text(row, "StatusCode"),
                        "Message": _read_report_row_text(row, "Message", "message"),
                        "TrackingId": _read_report_row_text(row, "TrackingId"),
                        "EventId": _read_report_row_text(row, "EventId"),
                        "LatencyMs": _read_report_row_text(row, "LatencyMs"),
                    }
                )
    return rows


def _build_metric_table_rows(metrics: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    rows: List[Dict[str, Any]] = []
    for metric in metrics:
        metric_type = str(metric.get("type") or "gauge").lower()
        rows.append(
            {
                "Type": "Counter" if metric_type == "counter" else "Gauge",
                "Scenario": str(metric.get("scenarioName") or ""),
                "Name": str(metric.get("name") or ""),
                "Unit": str(metric.get("unitOfMeasure") or metric.get("unit_of_measure") or ""),
                "Value": _format_report_number(_as_float(metric.get("value"))),
            }
        )
    return rows


def _classify_status_code_bucket(status_code: Any) -> str:
    text = str(status_code or "").strip()
    if len(text) >= 3 and text[0].isdigit():
        if text[0] == "2":
            return "2xx"
        if text[0] == "3":
            return "3xx"
        if text[0] == "4":
            return "4xx"
        if text[0] == "5":
            return "5xx"
    return "Other"


def _build_report_chart_data(result: Dict[str, Any], scenarios: List[Dict[str, Any]]) -> Dict[str, Any]:
    ordered = sorted(scenarios, key=lambda row: _as_int(row.get("sortIndex")))
    status_buckets = {"2xx": 0, "3xx": 0, "4xx": 0, "5xx": 0, "Other": 0}
    for row in ordered:
        for measurement_name in ("ok", "fail"):
            for code in _measurement_payload(row, measurement_name).get("statusCodes", []) or []:
                if not isinstance(code, dict):
                    continue
                bucket = _classify_status_code_bucket(code.get("statusCode"))
                status_buckets[bucket] += _as_int(code.get("count"))

    return {
        "overallOutcome": [
            {"label": "OK", "value": _as_int(result.get("allOkCount")), "color": "#18a957"},
            {"label": "FAIL", "value": _as_int(result.get("allFailCount")), "color": "#d14343"},
        ],
        "scenarioRequests": [
            {"label": str(row.get("scenarioName") or ""), "value": _as_int(row.get("allRequestCount")), "color": "#3b82f6"}
            for row in ordered
        ],
        "scenarioP95Latency": [
            {
                "label": str(row.get("scenarioName") or ""),
                "value": max(
                    _as_float(_measurement_payload(row, "ok").get("latency", {}).get("percent95")),
                    _as_float(_measurement_payload(row, "fail").get("latency", {}).get("percent95")),
                ),
                "color": "#8b5cf6",
            }
            for row in ordered
        ],
        "scenarioRps": [
            {
                "label": str(row.get("scenarioName") or ""),
                "value": 0.0
                if _as_float(row.get("durationMs")) <= 0
                else _as_int(row.get("allRequestCount")) / (_as_float(row.get("durationMs")) / 1000.0),
                "color": "#10b981",
            }
            for row in ordered
        ],
        "scenarioFailRate": [
            {
                "label": str(row.get("scenarioName") or ""),
                "value": 0.0
                if _as_int(row.get("allRequestCount")) <= 0
                else (100.0 * _as_int(row.get("allFailCount")) / _as_int(row.get("allRequestCount"))),
                "color": "#ef4444",
            }
            for row in ordered
        ],
        "scenarioBytes": [
            {"label": str(row.get("scenarioName") or ""), "value": _as_int(row.get("allBytes")), "color": "#0ea5e9"}
            for row in ordered
        ],
        "statusCodeClasses": [
            {"label": key, "value": value, "color": color}
            for key, value, color in (
                ("2xx", status_buckets["2xx"], "#16a34a"),
                ("3xx", status_buckets["3xx"], "#0ea5e9"),
                ("4xx", status_buckets["4xx"], "#f59e0b"),
                ("5xx", status_buckets["5xx"], "#dc2626"),
                ("Other", status_buckets["Other"], "#8b5cf6"),
            )
            if value > 0
        ],
        "scenarioLatencyTrend": {
            "labels": [str(row.get("scenarioName") or "") for row in ordered],
            "series": [
                {
                    "name": "P50",
                    "color": "#38bdf8",
                    "values": [
                        max(
                            _as_float(_measurement_payload(row, "ok").get("latency", {}).get("percent50")),
                            _as_float(_measurement_payload(row, "fail").get("latency", {}).get("percent50")),
                        )
                        for row in ordered
                    ],
                },
                {
                    "name": "P75",
                    "color": "#22c55e",
                    "values": [
                        max(
                            _as_float(_measurement_payload(row, "ok").get("latency", {}).get("percent75")),
                            _as_float(_measurement_payload(row, "fail").get("latency", {}).get("percent75")),
                        )
                        for row in ordered
                    ],
                },
                {
                    "name": "P95",
                    "color": "#f59e0b",
                    "values": [
                        max(
                            _as_float(_measurement_payload(row, "ok").get("latency", {}).get("percent95")),
                            _as_float(_measurement_payload(row, "fail").get("latency", {}).get("percent95")),
                        )
                        for row in ordered
                    ],
                },
                {
                    "name": "P99",
                    "color": "#f43f5e",
                    "values": [
                        max(
                            _as_float(_measurement_payload(row, "ok").get("latency", {}).get("percent99")),
                            _as_float(_measurement_payload(row, "fail").get("latency", {}).get("percent99")),
                        )
                        for row in ordered
                    ],
                },
            ],
        },
    }


def _read_report_row_text(row: Dict[str, Any], *keys: str) -> str:
    for key in keys:
        if key in row:
            return str(row.get(key) or "")
    return ""


def _try_parse_report_float(value: Any) -> Optional[float]:
    if value is None:
        return None
    try:
        return float(str(value))
    except (TypeError, ValueError):
        return None


def _normalize_chart_number(value: Optional[float]) -> Union[int, float, None]:
    if value is None:
        return None
    number = float(value)
    if math.isnan(number) or math.isinf(number):
        return number
    if number.is_integer():
        return int(number)
    return number


def _build_grouped_correlation_chart_payloads(rows: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    grouped: Dict[tuple[str, str], List[Dict[str, Any]]] = {}
    palette = ["#38bdf8", "#22c55e", "#f59e0b", "#a855f7", "#f43f5e", "#06b6d4", "#14b8a6", "#eab308", "#818cf8", "#84cc16"]
    for row in rows:
        gather_field = _read_report_row_text(row, "GatherByField") or "<none>"
        gather_value = _read_report_row_text(row, "GatherByValue") or "<missing>"
        key = (gather_field, gather_value)
        grouped.setdefault(key, []).append(row)

    payloads: List[Dict[str, Any]] = []
    for index, key in enumerate(sorted(grouped, key=lambda value: value)):
        gather_field, gather_value = key
        samples = grouped[key]
        p50_values = [
            _try_parse_report_float(sample.get("LatencyP50Ms"))
            for sample in samples
            if _try_parse_report_float(sample.get("LatencyP50Ms")) is not None
        ]
        p80_values = [
            _try_parse_report_float(sample.get("LatencyP80Ms"))
            for sample in samples
            if _try_parse_report_float(sample.get("LatencyP80Ms")) is not None
        ]
        p85_values = [
            _try_parse_report_float(sample.get("LatencyP85Ms"))
            for sample in samples
            if _try_parse_report_float(sample.get("LatencyP85Ms")) is not None
        ]
        p90_values = [
            _try_parse_report_float(sample.get("LatencyP90Ms"))
            for sample in samples
            if _try_parse_report_float(sample.get("LatencyP90Ms")) is not None
        ]
        p95_values = [
            _try_parse_report_float(sample.get("LatencyP95Ms"))
            for sample in samples
            if _try_parse_report_float(sample.get("LatencyP95Ms")) is not None
        ]
        p99_values = [
            _try_parse_report_float(sample.get("LatencyP99Ms"))
            for sample in samples
            if _try_parse_report_float(sample.get("LatencyP99Ms")) is not None
        ]
        if not any((p50_values, p80_values, p85_values, p90_values, p95_values, p99_values)):
            continue
        payloads.append(
            {
                "key": f"grouped-correlation-{index}",
                "title": f"{gather_field}: {gather_value}",
                "subtitle": (
                    f"Averaged across {len(samples)} grouped rows."
                    if len(samples) > 1
                    else "Single grouped row."
                ),
                "chart": {
                    "labels": ["P50", "P80", "P85", "P90", "P95", "P99"],
                    "series": [
                        {
                            "name": "Latency",
                            "color": palette[index % len(palette)],
                            "values": [
                                _normalize_chart_number(_mean_numeric(p50_values)),
                                _normalize_chart_number(_mean_numeric(p80_values)),
                                _normalize_chart_number(_mean_numeric(p85_values)),
                                _normalize_chart_number(_mean_numeric(p90_values)),
                                _normalize_chart_number(_mean_numeric(p95_values)),
                                _normalize_chart_number(_mean_numeric(p99_values)),
                            ],
                        }
                    ],
                },
            }
        )
    return payloads


def _build_ungrouped_correlation_chart_payload(rows: List[Dict[str, Any]]) -> Dict[str, Any]:
    grouped: Dict[tuple[str, str, str], List[float]] = {}
    for row in rows:
        scenario = _read_report_row_text(row, "Scenario")
        destination = _read_report_row_text(row, "Destination")
        status_code = _read_report_row_text(row, "StatusCode")
        latency = _try_parse_report_float(row.get("LatencyMs"))
        if not scenario or not destination or not status_code or latency is None:
            continue
        grouped.setdefault((scenario, destination, status_code), []).append(latency)

    series: List[Dict[str, Any]] = []
    palette = ["#38bdf8", "#22c55e", "#f59e0b", "#a855f7", "#f43f5e", "#06b6d4", "#14b8a6"]
    name_count: Dict[str, int] = {}
    ordered_rows: List[Dict[str, Any]] = []
    for scenario, destination, status_code in sorted(grouped, key=lambda value: value):
        latencies = sorted(grouped[(scenario, destination, status_code)])
        ordered_rows.append(
            {
                "GroupLabel": f"{scenario} | {destination}",
                "GatherByField": status_code,
                "GatherByValue": status_code,
                "LatencyP50Ms": _percentile_numeric(latencies, 0.50),
                "LatencyP80Ms": _percentile_numeric(latencies, 0.80),
                "LatencyP85Ms": _percentile_numeric(latencies, 0.85),
                "LatencyP90Ms": _percentile_numeric(latencies, 0.90),
                "LatencyP95Ms": _percentile_numeric(latencies, 0.95),
                "LatencyP99Ms": _percentile_numeric(latencies, 0.99),
            }
        )

    for index, row in enumerate(ordered_rows):
        base_name = _read_report_row_text(row, "GatherByField") or "status"
        count = name_count.get(base_name.lower(), 0)
        name_count[base_name.lower()] = count + 1
        series_name = base_name if count == 0 else f"{base_name}-{count + 1}"
        series.append(
            {
                "name": series_name,
                "color": palette[index % len(palette)],
                "values": [
                    _normalize_chart_number(_try_parse_report_float(row.get("LatencyP50Ms"))),
                    _normalize_chart_number(_try_parse_report_float(row.get("LatencyP80Ms"))),
                    _normalize_chart_number(_try_parse_report_float(row.get("LatencyP85Ms"))),
                    _normalize_chart_number(_try_parse_report_float(row.get("LatencyP90Ms"))),
                    _normalize_chart_number(_try_parse_report_float(row.get("LatencyP95Ms"))),
                    _normalize_chart_number(_try_parse_report_float(row.get("LatencyP99Ms"))),
                ],
            }
        )
    return {"labels": ["P50", "P80", "P85", "P90", "P95", "P99"], "series": series}


def _build_rich_html_report(result: Dict[str, Any]) -> str:
    scenarios = [row for row in result.get("scenarioStats", []) if isinstance(row, dict)]
    steps = [row for row in result.get("stepStats", []) if isinstance(row, dict)]
    thresholds = [row for row in result.get("thresholdResults", []) if isinstance(row, dict)]
    metrics = [row for row in result.get("metrics", []) if isinstance(row, dict)]
    plugins = [row for row in result.get("pluginsData", []) if isinstance(row, dict)]

    scenario_rows = "".join(
        f"<tr><td>{_escape_html(row.get('scenarioName'))}</td><td>{_as_int(row.get('allRequestCount'))}</td>"
        f"<td>{_as_int(row.get('allOkCount'))}</td><td>{_as_int(row.get('allFailCount'))}</td>"
        f"<td>{_as_int(row.get('totalBytes'))}</td><td>{_as_float(row.get('minLatencyMs')):.2f}</td>"
        f"<td>{_as_float(row.get('avgLatencyMs')):.2f}</td><td>{_as_float(row.get('maxLatencyMs')):.2f}</td></tr>"
        for row in scenarios
    )
    step_rows = "".join(
        f"<tr><td>{_escape_html(row.get('scenarioName'))}</td><td>{_escape_html(row.get('stepName'))}</td>"
        f"<td>{_as_int(row.get('requestCount'))}</td><td>{_as_int(row.get('okCount'))}</td>"
        f"<td>{_as_int(row.get('failCount'))}</td><td>{_as_float(row.get('avgLatencyMs')):.2f}</td></tr>"
        for row in steps
    )
    threshold_rows = "".join(
        f"<tr><td>{_escape_html(row.get('scenarioName'))}</td><td>{_escape_html(row.get('scope'))}</td>"
        f"<td>{_escape_html(row.get('stepName'))}</td><td>{_escape_html(row.get('checkExpression'))}</td>"
        f"<td>{_as_int(row.get('errorCount'))}</td><td>{'failed' if bool(row.get('isFailed')) else 'passed'}</td>"
        f"<td>{_escape_html(row.get('exceptionMessage') or '')}</td></tr>"
        for row in thresholds
    )
    metric_rows = "".join(
        f"<tr><td>{_escape_html(row.get('name'))}</td><td>{_escape_html(row.get('type'))}</td>"
        f"<td>{_as_float(row.get('value')):.3f}</td></tr>"
        for row in metrics
    )
    plugin_rows = "".join(
        f"<tr><td>{_escape_html(plugin.get('pluginName'))}</td><td>{_escape_html(table.get('tableName'))}</td>"
        f"<td>{len(table.get('rows', []))}</td><td>{', '.join(_escape_html(header) for header in table.get('headers', []))}</td></tr>"
        for plugin in plugins
        for table in plugin.get("tables", [])
        if isinstance(table, dict)
    )
    status_rows = "".join(
        f"<tr><td>{_escape_html(scope)}</td><td>{_escape_html(owner)}</td><td>{_escape_html(code)}</td><td>{count}</td></tr>"
        for scope, owner, code, count in _extract_status_code_rows(scenarios, steps)
    )
    correlation_rows = "".join(
        f"<tr><td>{_escape_html(plugin.get('pluginName'))}</td><td>{_escape_html(table.get('tableName'))}</td>"
        f"<td>{len(table.get('rows', []))}</td></tr>"
        for plugin in plugins
        for table in plugin.get("tables", [])
        if isinstance(table, dict) and "correlation" in str(table.get("tableName", "")).lower()
    )
    max_requests = max([_as_int(x.get("allRequestCount")) for x in scenarios] or [1])
    bars = "".join(
        f"<div class='bar-row'><span>{_escape_html(row.get('scenarioName'))}</span>"
        f"<div class='bar'><i style='width:{(_as_int(row.get('allRequestCount')) / max_requests) * 100}%'></i></div>"
        f"<strong>{_as_int(row.get('allRequestCount'))}</strong></div>"
        for row in scenarios
    )
    plugin_detail_cards = "".join(
        f"<section class='table-card'><h3>{_escape_html(plugin.get('pluginName'))} / { _escape_html(table.get('tableName')) }</h3>"
        f"{_render_plugin_table(table)}</section>"
        for plugin in plugins
        for table in plugin.get("tables", [])
        if isinstance(table, dict)
    )
    return f"""<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width,initial-scale=1" />
  <title>LoadStrike Rich Report</title>
  <style>
    :root {{ --bg:#f4f7fb; --ink:#0f172a; --muted:#475569; --card:#fff; --line:#dbe4ef; --accent:#0f766e; --accent-soft:#d7f3ef; }}
    body {{ margin:0; background:linear-gradient(180deg,#f8fbff,#edf3fb); color:var(--ink); font:14px/1.45 "Segoe UI",Tahoma,sans-serif; }}
    .wrap {{ max-width:1280px; margin:0 auto; padding:20px; }}
    .cards {{ display:grid; grid-template-columns:repeat(auto-fit,minmax(150px,1fr)); gap:10px; margin:10px 0 15px; }}
    .card {{ background:var(--card); border:1px solid var(--line); border-radius:10px; padding:10px; }}
    .tabs {{ display:flex; flex-wrap:wrap; gap:8px; margin-bottom:10px; }}
    .tabs button {{ border:1px solid var(--line); border-radius:999px; background:#fff; padding:6px 10px; cursor:pointer; }}
    .tabs button.active {{ background:var(--accent); border-color:var(--accent); color:#fff; }}
    .panel {{ display:none; background:#fff; border:1px solid var(--line); border-radius:10px; padding:12px; }}
    .panel.active {{ display:block; }}
    table {{ width:100%; border-collapse:collapse; }}
    th,td {{ border-bottom:1px solid var(--line); padding:6px 8px; text-align:left; font-size:12px; }}
    .bar-row {{ display:grid; grid-template-columns:170px 1fr 70px; gap:8px; align-items:center; margin:6px 0; }}
    .bar {{ height:10px; background:#e2e8f0; border-radius:999px; overflow:hidden; }}
    .bar i {{ display:block; height:100%; background:linear-gradient(90deg,#0f766e,#14b8a6); }}
    .overview-grid {{ display:grid; grid-template-columns:2fr 1fr; gap:12px; }}
    .table-card {{ background:#f8fafc; border:1px solid var(--line); border-radius:10px; padding:12px; margin:0 0 12px; }}
    .pill {{ display:inline-block; margin-right:8px; padding:4px 8px; border-radius:999px; background:var(--accent-soft); color:var(--accent); font-size:12px; }}
    .muted {{ color:var(--muted); }}
    @media (max-width: 900px) {{ .overview-grid {{ grid-template-columns:1fr; }} }}
  </style>
</head>
<body>
  <div class="wrap">
    <h1>LoadStrike Rich Report</h1>
    <div class="muted">started {_escape_html(result.get('startedUtc'))} | completed {_escape_html(result.get('completedUtc'))}</div>
    <div class="cards">
      <div class="card"><strong>Requests:</strong> {_as_int(result.get('allRequestCount'))}</div>
      <div class="card"><strong>OK:</strong> {_as_int(result.get('allOkCount'))}</div>
      <div class="card"><strong>Fail:</strong> {_as_int(result.get('allFailCount'))}</div>
      <div class="card"><strong>Bytes:</strong> {_as_int(result.get('allBytes'))}</div>
      <div class="card"><strong>Failed Thresholds:</strong> {_as_int(result.get('failedThresholds'))}</div>
    </div>
    <div class="tabs">
      <button class="tab active" data-tab="overview">Overview</button>
      <button class="tab" data-tab="scenarios">Scenarios</button>
      <button class="tab" data-tab="steps">Steps</button>
      <button class="tab" data-tab="status-codes">Status Codes</button>
      <button class="tab" data-tab="thresholds">Thresholds</button>
      <button class="tab" data-tab="metrics">Metrics</button>
      <button class="tab" data-tab="plugins">Plugins</button>
      <button class="tab" data-tab="correlation">Correlation</button>
    </div>
    <section id="overview" class="panel active">
      <div class="overview-grid">
        <div class="table-card">
          <h2>Scenario Throughput</h2>
          {bars or "<div>No scenario data.</div>"}
        </div>
        <div class="table-card">
          <h2>Run Metadata</h2>
          <div class="pill">Session {_escape_html((result.get('testInfo') or {{}}).get('sessionId'))}</div>
          <div class="pill">Suite {_escape_html((result.get('testInfo') or {{}}).get('testSuite'))}</div>
          <div class="pill">Test {_escape_html((result.get('testInfo') or {{}}).get('testName'))}</div>
          <div class="pill">Node {_escape_html((result.get('nodeInfo') or {{}}).get('nodeType'))}</div>
        </div>
      </div>
    </section>
    <section id="scenarios" class="panel">
      <table><thead><tr><th>Scenario</th><th>Requests</th><th>OK</th><th>Fail</th><th>TotalBytes</th><th>MinLatencyMs</th><th>AvgLatencyMs</th><th>MaxLatencyMs</th></tr></thead>
      <tbody>{scenario_rows or "<tr><td colspan='8'>No rows</td></tr>"}</tbody></table>
    </section>
    <section id="steps" class="panel">
      <table><thead><tr><th>Scenario</th><th>Step</th><th>Requests</th><th>OK</th><th>Fail</th><th>AvgLatencyMs</th></tr></thead>
      <tbody>{step_rows or "<tr><td colspan='6'>No step rows</td></tr>"}</tbody></table>
    </section>
    <section id="status-codes" class="panel">
      <table><thead><tr><th>Scope</th><th>Owner</th><th>Status Code</th><th>Count</th></tr></thead>
      <tbody>{status_rows or "<tr><td colspan='4'>No status code rows</td></tr>"}</tbody></table>
    </section>
    <section id="thresholds" class="panel">
      <table><thead><tr><th>Scenario</th><th>Scope</th><th>Step</th><th>Expression</th><th>ErrorCount</th><th>Status</th><th>Exception</th></tr></thead>
      <tbody>{threshold_rows or "<tr><td colspan='7'>No threshold rows</td></tr>"}</tbody></table>
    </section>
    <section id="metrics" class="panel">
      <table><thead><tr><th>Name</th><th>Type</th><th>Value</th></tr></thead>
      <tbody>{metric_rows or "<tr><td colspan='3'>No metrics</td></tr>"}</tbody></table>
    </section>
    <section id="plugins" class="panel">
      <table><thead><tr><th>Plugin</th><th>Table</th><th>Rows</th><th>Headers</th></tr></thead>
      <tbody>{plugin_rows or "<tr><td colspan='4'>No plugin rows</td></tr>"}</tbody></table>
      <div>{plugin_detail_cards or "<div class='table-card'>No plugin table rows.</div>"}</div>
    </section>
    <section id="correlation" class="panel">
      <h2>Grouped Correlation</h2>
      <table><thead><tr><th>Plugin</th><th>Table</th><th>Rows</th></tr></thead>
      <tbody>{correlation_rows or "<tr><td colspan='3'>No grouped correlation tables.</td></tr>"}</tbody></table>
    </section>
  </div>
  <script>
    for (const button of document.querySelectorAll(".tab")) {{
      button.addEventListener("click", () => {{
        document.querySelectorAll(".tab").forEach((x) => x.classList.remove("active"));
        document.querySelectorAll(".panel").forEach((x) => x.classList.remove("active"));
        button.classList.add("active");
        const target = document.getElementById(button.dataset.tab);
        if (target) target.classList.add("active");
      }});
    }}
  </script>
</body>
</html>
"""


def _rich_report_plugin_sections(
    plugins: List[Dict[str, Any]],
) -> tuple[str, str, Dict[str, Dict[str, Any]], Dict[str, Dict[str, Any]]]:
    correlation_plugins = [
        plugin
        for plugin in plugins
        if "correlation" in str(plugin.get("pluginName") or "").lower()
    ]
    failed_plugins = [
        plugin
        for plugin in plugins
        if "fail" in str(plugin.get("pluginName") or "").lower()
        or "timeout" in str(plugin.get("pluginName") or "").lower()
    ]
    regular_plugins = [
        plugin
        for plugin in plugins
        if plugin not in correlation_plugins and plugin not in failed_plugins
    ]

    grouped_chart_payloads: Dict[str, Dict[str, Any]] = {}
    ungrouped_chart_payloads: Dict[str, Dict[str, Any]] = {}
    regular_sections: List[str] = []
    correlation_sections: List[str] = []

    for plugin in regular_plugins:
        hints = "".join(
            f"<li>{_escape_html(hint)}</li>"
            for hint in plugin.get("hints", []) or []
            if str(hint or "").strip()
        )
        if hints:
            regular_sections.append(
                f"<div class='card'><h3>{_escape_html(plugin.get('pluginName'))}</h3><ul>{hints}</ul></div>"
            )
        for table in plugin.get("tables", []) or []:
            if not isinstance(table, dict):
                continue
            regular_sections.append(
                f"<div class='card'><h3>{_escape_html(plugin.get('pluginName'))}: {_escape_html(table.get('tableName'))}</h3>"
                f"{_render_plugin_table(table)}</div>"
            )

    for plugin_index, plugin in enumerate(correlation_plugins):
        hints = "".join(
            f"<li>{_escape_html(hint)}</li>"
            for hint in plugin.get("hints", []) or []
            if str(hint or "").strip()
        )
        if hints:
            correlation_sections.append(
                f"<div class='card'><h3>{_escape_html(plugin.get('pluginName'))}</h3><ul>{hints}</ul></div>"
            )
        for table_index, table in enumerate(plugin.get("tables", []) or []):
            if not isinstance(table, dict):
                continue
            table_name = str(table.get("tableName") or "table")
            rows = [dict(row) for row in table.get("rows", []) if isinstance(row, dict)]
            correlation_sections.append(
                f"<div class='card'><h3>{_escape_html(plugin.get('pluginName'))}: {_escape_html(table_name)}</h3>"
                f"{_render_plugin_table(table)}</div>"
            )
            if "grouped correlation summary" in table_name.lower():
                for payload in _build_grouped_correlation_chart_payloads(rows):
                    grouped_chart_payloads[payload["key"]] = payload["chart"]
                    correlation_sections.append(
                        f"<div class='card chart-card'><h3>{_escape_html(payload['title'])}</h3><p>{_escape_html(payload['subtitle'])}</p>"
                        f"<canvas class='chart-canvas grouped-correlation-canvas' data-grouped-key='{_escape_html(payload['key'])}'></canvas></div>"
                    )
            elif "ungrouped correlation rows" in table_name.lower():
                payload_key = f"ungrouped-correlation-{plugin_index}-{table_index}"
                ungrouped_chart_payloads[payload_key] = _build_ungrouped_correlation_chart_payload(rows)
                correlation_sections.append(
                    "<div class='card'><h3>Ungrouped Correlation Percentile Trends</h3>"
                    "<p>All percentile lines are shown in one graph for direct comparison.</p>"
                    f"<canvas class='chart-canvas ungrouped-correlation-canvas' data-ungrouped-key='{_escape_html(payload_key)}'></canvas></div>"
                )

    return (
        "".join(regular_sections) if regular_sections else "<div class='card'>No plugin table data.</div>",
        "".join(correlation_sections) if correlation_sections else "<div class='card'>No cross-platform correlation rows were captured.</div>",
        grouped_chart_payloads,
        ungrouped_chart_payloads,
    )


def _rich_report_sections(
    result: Dict[str, Any],
    scenarios: List[Dict[str, Any]],
    thresholds: List[Dict[str, Any]],
    metrics: List[Dict[str, Any]],
    plugins: List[Dict[str, Any]],
) -> tuple[List[tuple[str, str, str]], Dict[str, Dict[str, Any]], Dict[str, Dict[str, Any]], Dict[str, Any]]:
    test_info = result.get("testInfo") if isinstance(result.get("testInfo"), dict) else {}
    node_info = result.get("nodeInfo") if isinstance(result.get("nodeInfo"), dict) else {}
    scenario_rows = [
        {
            "Scenario": str(row.get("scenarioName") or ""),
            "Simulation": str(row.get("loadSimulationStats", {}).get("simulationName") or ""),
            "SimulationValue": _as_int(row.get("loadSimulationStats", {}).get("value")),
            "Requests": _as_int(row.get("allRequestCount")),
            "OK": _as_int(row.get("allOkCount")),
            "FAIL": _as_int(row.get("allFailCount")),
            "Duration": str(_timedelta_from_ms(row.get("durationMs"))),
            "RPS": _format_report_number(
                0.0
                if _as_float(row.get("durationMs")) <= 0
                else _as_int(row.get("allRequestCount")) / (_as_float(row.get("durationMs")) / 1000.0)
            ),
            "LatencyP95Ms": _format_report_number(
                max(
                    _as_float(_measurement_payload(row, "ok").get("latency", {}).get("percent95")),
                    _as_float(_measurement_payload(row, "fail").get("latency", {}).get("percent95")),
                )
            ),
            "LatencyP99Ms": _format_report_number(
                max(
                    _as_float(_measurement_payload(row, "ok").get("latency", {}).get("percent99")),
                    _as_float(_measurement_payload(row, "fail").get("latency", {}).get("percent99")),
                )
            ),
            "CurrentOperation": str(row.get("currentOperation") or ""),
        }
        for row in scenarios
    ]
    step_rows = [
        {
            "Scenario": str(scenario.get("scenarioName") or ""),
            "Step": str(step.get("stepName") or ""),
            "Requests": _as_int(_measurement_payload(step, "ok").get("request", {}).get("count"))
            + _as_int(_measurement_payload(step, "fail").get("request", {}).get("count")),
            "OK": _as_int(_measurement_payload(step, "ok").get("request", {}).get("count")),
            "FAIL": _as_int(_measurement_payload(step, "fail").get("request", {}).get("count")),
            "OK_RPS": _format_report_number(_as_float(_measurement_payload(step, "ok").get("request", {}).get("rps"))),
            "FAIL_RPS": _format_report_number(_as_float(_measurement_payload(step, "fail").get("request", {}).get("rps"))),
            "LatencyMeanMs": _format_report_number(
                max(
                    _as_float(_measurement_payload(step, "ok").get("latency", {}).get("meanMs")),
                    _as_float(_measurement_payload(step, "fail").get("latency", {}).get("meanMs")),
                )
            ),
            "P95LatencyMs": _format_report_number(
                max(
                    _as_float(_measurement_payload(step, "ok").get("latency", {}).get("percent95")),
                    _as_float(_measurement_payload(step, "fail").get("latency", {}).get("percent95")),
                )
            ),
        }
        for scenario in scenarios
        for step in sorted(
            [row for row in scenario.get("stepStats", []) if isinstance(row, dict)],
            key=lambda row: _as_int(row.get("sortIndex")),
        )
    ]
    scenario_measurement_rows = _build_measurement_table_rows(scenarios, include_steps=False)
    step_measurement_rows = _build_measurement_table_rows(scenarios, include_steps=True)
    status_code_rows = _build_status_code_table_rows(scenarios)
    failed_status_rows = _build_failed_status_rows(scenarios)
    failed_event_rows = _build_failed_event_rows(plugins)
    threshold_rows = [
        {
            "Scenario": str(row.get("scenarioName") or ""),
            "Step": str(row.get("stepName") or ""),
            "Check": str(row.get("checkExpression") or ""),
            "Failed": bool(row.get("isFailed")),
            "ErrorCount": _as_int(row.get("errorCount")),
            "Exception": str(row.get("exceptionMsg") or row.get("exceptionMessage") or ""),
        }
        for row in thresholds
    ]
    metric_rows = _build_metric_table_rows(metrics)
    regular_plugins_html, correlation_html, grouped_charts, ungrouped_charts = _rich_report_plugin_sections(plugins)
    chart_data = _build_report_chart_data(result, scenarios)
    summary_cards = (
        f"<div class='stat-card'><div class='stat-label'>Total Requests</div><div class='stat-value'>{_as_int(result.get('allRequestCount'))}</div></div>"
        f"<div class='stat-card'><div class='stat-label'>Success</div><div class='stat-value ok'>{_as_int(result.get('allOkCount'))}</div></div>"
        f"<div class='stat-card'><div class='stat-label'>Fail</div><div class='stat-value fail'>{_as_int(result.get('allFailCount'))}</div></div>"
        f"<div class='stat-card'><div class='stat-label'>Duration</div><div class='stat-value'>{_escape_html(str(_timedelta_from_ms(result.get('durationMs'))))}</div></div>"
        f"<div class='stat-card'><div class='stat-label'>Total Bytes</div><div class='stat-value'>{_as_int(result.get('allBytes'))}</div></div>"
        f"<div class='stat-card'><div class='stat-label'>Failed Thresholds</div><div class='stat-value'>{_as_int(result.get('failedThresholds'))}</div></div>"
    )
    summary_latency_rows = [
        {
            "Scenario": row.get("Scenario"),
            "Result": row.get("Result"),
            "Count": row.get("Count"),
            "LatencyMinMs": row.get("LatencyMinMs"),
            "LatencyMeanMs": row.get("LatencyMeanMs"),
            "LatencyP50Ms": row.get("LatencyP50Ms"),
            "LatencyP75Ms": row.get("LatencyP75Ms"),
            "LatencyP95Ms": row.get("LatencyP95Ms"),
            "LatencyP99Ms": row.get("LatencyP99Ms"),
            "LatencyMaxMs": row.get("LatencyMaxMs"),
            "LatencyStdDev": row.get("LatencyStdDev"),
        }
        for row in scenario_measurement_rows
    ]
    sections = [
        (
            "summary",
            "Summary",
            "<div class='card-grid'>"
            + summary_cards
            + "</div>"
            + "<div class='card'><h2>Charts</h2><div class='chart-grid'>"
            + "<div class='chart-card'><h3>Success vs Fail</h3><canvas id='chart-outcome' class='chart-canvas'></canvas></div>"
            + "<div class='chart-card'><h3>Requests by Scenario</h3><canvas id='chart-scenario-requests' class='chart-canvas'></canvas></div>"
            + "<div class='chart-card'><h3>P95 Latency by Scenario (ms)</h3><canvas id='chart-scenario-p95' class='chart-canvas'></canvas></div>"
            + "<div class='chart-card'><h3>RPS by Scenario</h3><canvas id='chart-scenario-rps' class='chart-canvas'></canvas></div>"
            + "<div class='chart-card'><h3>Failure Rate by Scenario (%)</h3><canvas id='chart-scenario-fail-rate' class='chart-canvas'></canvas></div>"
            + "<div class='chart-card'><h3>Bytes by Scenario</h3><canvas id='chart-scenario-bytes' class='chart-canvas'></canvas></div>"
            + "<div class='chart-card'><h3>Status Code Class Mix</h3><canvas id='chart-status-code-classes' class='chart-canvas'></canvas></div>"
            + "<div class='chart-card'><h3>Latency Trend by Scenario (ms)</h3><canvas id='chart-scenario-latency-lines' class='chart-canvas'></canvas></div>"
            + "</div></div>"
            + "<div class='card'><h2>Latency by Scenario (Table)</h2>"
            + _build_html_table(summary_latency_rows)
            + "</div>"
            + "<div class='card'><h2>Environment</h2>"
            + _build_html_table(
                [
                    {"Name": "Cluster Id", "Value": test_info.get("clusterId")},
                    {"Name": "Created (UTC)", "Value": test_info.get("createdUtc") or test_info.get("created")},
                    {"Name": "Machine", "Value": node_info.get("machineName")},
                    {"Name": "OS", "Value": node_info.get("os")},
                    {"Name": "Runtime", "Value": node_info.get("pythonVersion") or node_info.get("dotNetVersion")},
                    {"Name": "Processor", "Value": node_info.get("processor")},
                    {"Name": "Cores", "Value": node_info.get("coresCount")},
                    {"Name": "Operation", "Value": node_info.get("currentOperation")},
                ]
            )
            + "</div>",
        ),
        ("scenarios", "Scenarios", _build_html_table(scenario_rows)),
        ("steps", "Steps", _build_html_table(step_rows)),
        ("scenario-measurements", "Scenario Measurements", _build_html_table(scenario_measurement_rows)),
        ("step-measurements", "Step Measurements", _build_html_table(step_measurement_rows)),
        ("status-codes", "Status Codes", _build_html_table(status_code_rows)),
        (
            "failed-responses",
            "Failed Responses",
            "<div class='card'><h2>Failed Status Codes</h2>"
            + _build_html_table(failed_status_rows)
            + "</div>"
            + "<div class='card'><h2>Failed and Timed Out Rows</h2>"
            + _build_html_table(failed_event_rows)
            + "</div>",
        ),
        ("thresholds", "Thresholds", _build_html_table(threshold_rows)),
        ("metrics", "Metrics", _build_html_table(metric_rows)),
        ("plugins", "Plugins", regular_plugins_html),
        ("correlation", "Correlation", correlation_html),
    ]
    return sections, grouped_charts, ungrouped_charts, chart_data


def _rich_report_document(
    result: Dict[str, Any],
    sections: List[tuple[str, str, str]],
    grouped_charts: Dict[str, Dict[str, Any]],
    ungrouped_charts: Dict[str, Dict[str, Any]],
    chart_data: Dict[str, Any],
) -> str:
    test_info = result.get("testInfo") if isinstance(result.get("testInfo"), dict) else {}
    buttons_html = "".join(
        f"<button class='tab-btn{' active' if index == 0 else ''}' data-tab='{_escape_html(tab_id)}'>{_escape_html(title)}</button>"
        for index, (tab_id, title, _html) in enumerate(sections)
    )
    sections_html = "".join(
        f"<section id='{_escape_html(tab_id)}' class='tab-panel{' active' if index == 0 else ''}'>{html}</section>"
        for index, (tab_id, _title, html) in enumerate(sections)
    )
    return f"""<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>LoadStrike Report</title>
  <style>
    :root {{ --bg:#f4f7fc; --panel:#ffffff; --panel-alt:#eef3fb; --line:#d3deed; --text:#0f172a; --muted:#4b5563; --accent:#2563eb; --ok:#138a4a; --fail:#c63636; --shadow:0 10px 24px rgba(15,23,42,.10); }}
    body {{ margin:0; background:linear-gradient(180deg,#f8fbff,#edf3fb); color:var(--text); font:14px/1.45 "Segoe UI",Tahoma,sans-serif; }}
    .wrap {{ max-width:1440px; margin:0 auto; padding:20px; }}
    h1 {{ margin:0 0 8px; font-size:30px; }}
    h2 {{ margin:0 0 12px; font-size:18px; }}
    h3 {{ margin:0 0 10px; font-size:15px; }}
    .meta {{ display:flex; flex-wrap:wrap; gap:10px; margin-bottom:14px; color:var(--muted); }}
    .meta span {{ background:var(--panel); border:1px solid var(--line); border-radius:999px; padding:6px 10px; }}
    .tabs {{ display:flex; flex-wrap:wrap; gap:8px; margin:0 0 14px; }}
    .tab-btn {{ border:1px solid var(--line); border-radius:999px; background:var(--panel); color:var(--text); padding:7px 12px; cursor:pointer; }}
    .tab-btn.active {{ background:var(--accent); border-color:var(--accent); color:#fff; }}
    .tab-panel {{ display:none; }}
    .tab-panel.active {{ display:block; }}
    .card {{ background:var(--panel); border:1px solid var(--line); border-radius:12px; padding:14px; margin-bottom:14px; box-shadow:var(--shadow); }}
    .card-grid {{ display:grid; grid-template-columns:repeat(auto-fit,minmax(220px,1fr)); gap:10px; }}
    .stat-card {{ background:var(--panel-alt); border:1px solid var(--line); border-radius:10px; padding:10px 12px; }}
    .stat-label {{ font-size:12px; color:var(--muted); }}
    .stat-value {{ font-size:22px; font-weight:700; margin-top:4px; }}
    .stat-value.ok {{ color:var(--ok); }}
    .stat-value.fail {{ color:var(--fail); }}
    .chart-grid {{ display:grid; grid-template-columns:repeat(auto-fit,minmax(360px,1fr)); gap:12px; }}
    .chart-card {{ background:#0f172a; color:#e6edf3; border:1px solid #263241; border-radius:12px; padding:12px; }}
    .chart-canvas {{ width:100%; height:260px; display:block; }}
    .table-wrap {{ overflow:auto; max-height:70vh; }}
    table {{ width:100%; border-collapse:collapse; font-size:12px; }}
    th,td {{ border:1px solid var(--line); padding:7px 8px; text-align:left; vertical-align:top; }}
    th {{ background:var(--panel-alt); position:sticky; top:0; }}
    ul {{ margin:8px 0 0 20px; padding:0; }}
    p {{ margin:0 0 10px; color:var(--muted); }}
    @media (max-width:980px) {{ .wrap {{ padding:14px; }} .chart-canvas {{ height:220px; }} .stat-value {{ font-size:18px; }} }}
  </style>
</head>
<body>
  <div class="wrap">
    <h1>LoadStrike Report</h1>
    <div class="meta">
      <span>Suite: <strong>{_escape_html(test_info.get("testSuite"))}</strong></span>
      <span>Name: <strong>{_escape_html(test_info.get("testName"))}</strong></span>
      <span>Session: <strong>{_escape_html(test_info.get("sessionId"))}</strong></span>
      <span>Duration: <strong>{_escape_html(str(_timedelta_from_ms(result.get("durationMs"))))}</strong></span>
    </div>
    <div class="tabs">{buttons_html}</div>
    {sections_html}
  </div>
  <script>
    const reportCharts = {json.dumps(chart_data, separators=(",", ":"))};
    const groupedCorrelationCharts = {json.dumps(grouped_charts, separators=(",", ":"))};
    const ungroupedCorrelationCharts = {json.dumps(ungrouped_charts, separators=(",", ":"))};
    const palette = ["#38bdf8","#22c55e","#f59e0b","#a855f7","#f43f5e","#06b6d4","#14b8a6","#eab308","#818cf8","#84cc16"];
    function activateTab(id) {{
      document.querySelectorAll(".tab-btn").forEach((button) => button.classList.toggle("active", button.dataset.tab === id));
      document.querySelectorAll(".tab-panel").forEach((panel) => panel.classList.toggle("active", panel.id === id));
    }}
    document.querySelectorAll(".tab-btn").forEach((button) => button.addEventListener("click", () => activateTab(button.dataset.tab)));
    function setupCanvas(canvas) {{
      const dpr = window.devicePixelRatio || 1;
      const width = Math.max(320, Math.floor(canvas.getBoundingClientRect().width || 320));
      const height = Math.max(220, Math.floor(canvas.getBoundingClientRect().height || 220));
      canvas.width = Math.floor(width * dpr);
      canvas.height = Math.floor(height * dpr);
      const ctx = canvas.getContext("2d");
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
      return {{ ctx, width, height }};
    }}
    function drawEmpty(ctx, width, height, message) {{
      ctx.fillStyle = "#9fb0c3";
      ctx.font = "13px Segoe UI";
      ctx.textAlign = "center";
      ctx.fillText(message, width / 2, height / 2);
    }}
    function drawBars(canvasId, points, suffix = "") {{
      const canvas = document.getElementById(canvasId);
      if (!canvas) return;
      const {{ ctx, width, height }} = setupCanvas(canvas);
      ctx.clearRect(0, 0, width, height);
      if (!Array.isArray(points) || points.length === 0) return drawEmpty(ctx, width, height, "No data");
      const margin = {{ top: 20, right: 10, bottom: 60, left: 42 }};
      const plotWidth = width - margin.left - margin.right;
      const plotHeight = height - margin.top - margin.bottom;
      const maxValue = Math.max(...points.map((point) => Number(point.value) || 0), 1);
      const barWidth = Math.max(18, plotWidth / Math.max(points.length, 1) - 12);
      ctx.strokeStyle = "#334155";
      ctx.fillStyle = "#b5c2d3";
      ctx.font = "11px Segoe UI";
      for (let tick = 0; tick <= 4; tick += 1) {{
        const y = margin.top + (plotHeight * tick) / 4;
        ctx.beginPath(); ctx.moveTo(margin.left, y); ctx.lineTo(width - margin.right, y); ctx.stroke();
      }}
      points.forEach((point, index) => {{
        const value = Number(point.value) || 0;
        const x = margin.left + index * (plotWidth / Math.max(points.length, 1)) + 6;
        const barHeight = plotHeight * (value / maxValue);
        const y = margin.top + plotHeight - barHeight;
        ctx.fillStyle = point.color || palette[index % palette.length];
        ctx.fillRect(x, y, barWidth, barHeight);
        ctx.fillStyle = "#e6edf3";
        ctx.textAlign = "center";
        ctx.fillText((Math.round(value * 100) / 100).toString() + suffix, x + barWidth / 2, Math.max(14, y - 6));
        ctx.save(); ctx.translate(x + barWidth / 2, height - 10); ctx.rotate(-0.45); ctx.fillText((point.label || "").toString(), 0, 0); ctx.restore();
      }});
    }}
    function drawPie(canvasId, points) {{
      const canvas = document.getElementById(canvasId);
      if (!canvas) return;
      const {{ ctx, width, height }} = setupCanvas(canvas);
      ctx.clearRect(0, 0, width, height);
      if (!Array.isArray(points) || points.length === 0) return drawEmpty(ctx, width, height, "No data");
      const total = points.reduce((sum, point) => sum + (Number(point.value) || 0), 0);
      if (total <= 0) return drawEmpty(ctx, width, height, "No data");
      const centerX = width / 2;
      const centerY = height / 2 - 10;
      const radius = Math.min(width, height) * 0.28;
      let start = -Math.PI / 2;
      points.forEach((point, index) => {{
        const value = Number(point.value) || 0;
        const angle = (value / total) * Math.PI * 2;
        ctx.beginPath(); ctx.moveTo(centerX, centerY); ctx.fillStyle = point.color || palette[index % palette.length];
        ctx.arc(centerX, centerY, radius, start, start + angle); ctx.closePath(); ctx.fill(); start += angle;
      }});
      ctx.fillStyle = "#0f172a"; ctx.beginPath(); ctx.arc(centerX, centerY, radius * 0.55, 0, Math.PI * 2); ctx.fill();
      ctx.fillStyle = "#e6edf3"; ctx.textAlign = "center"; ctx.font = "13px Segoe UI"; ctx.fillText("Total", centerX, centerY - 2);
      ctx.font = "bold 18px Segoe UI"; ctx.fillText(total.toString(), centerX, centerY + 18);
    }}
    function drawLine(canvas, chart) {{
      const {{ ctx, width, height }} = setupCanvas(canvas);
      ctx.clearRect(0, 0, width, height);
      if (!chart || !Array.isArray(chart.labels) || !Array.isArray(chart.series) || chart.series.length === 0) return drawEmpty(ctx, width, height, "No data");
      const margin = {{ top: 20, right: 18, bottom: 40, left: 42 }};
      const plotWidth = width - margin.left - margin.right;
      const plotHeight = height - margin.top - margin.bottom;
      const values = chart.series.flatMap((series) => Array.isArray(series.values) ? series.values : []).filter((value) => Number.isFinite(value));
      const maxValue = Math.max(...values, 1);
      ctx.strokeStyle = "#334155"; ctx.font = "11px Segoe UI"; ctx.fillStyle = "#b5c2d3";
      for (let tick = 0; tick <= 4; tick += 1) {{
        const y = margin.top + (plotHeight * tick) / 4;
        ctx.beginPath(); ctx.moveTo(margin.left, y); ctx.lineTo(width - margin.right, y); ctx.stroke();
      }}
      chart.series.forEach((series, index) => {{
        const values = Array.isArray(series.values) ? series.values : [];
        ctx.strokeStyle = series.color || palette[index % palette.length]; ctx.lineWidth = 2; ctx.beginPath();
        values.forEach((raw, pointIndex) => {{
          const value = Number(raw);
          const x = margin.left + (plotWidth * pointIndex) / Math.max(values.length - 1, 1);
          const y = margin.top + plotHeight - (plotHeight * (Number.isFinite(value) ? value : 0)) / maxValue;
          if (pointIndex === 0) ctx.moveTo(x, y); else ctx.lineTo(x, y);
        }});
        ctx.stroke();
      }});
      ctx.fillStyle = "#b5c2d3"; ctx.textAlign = "center";
      chart.labels.forEach((label, index) => {{
        const x = margin.left + (plotWidth * index) / Math.max(chart.labels.length - 1, 1);
        ctx.fillText((label || "").toString(), x, height - 10);
      }});
    }}
    function renderCharts() {{
      drawPie("chart-outcome", reportCharts.overallOutcome);
      drawBars("chart-scenario-requests", reportCharts.scenarioRequests);
      drawBars("chart-scenario-p95", reportCharts.scenarioP95Latency, "ms");
      drawBars("chart-scenario-rps", reportCharts.scenarioRps);
      drawBars("chart-scenario-fail-rate", reportCharts.scenarioFailRate, "%");
      drawBars("chart-scenario-bytes", reportCharts.scenarioBytes);
      drawBars("chart-status-code-classes", reportCharts.statusCodeClasses);
      const latencyCanvas = document.getElementById("chart-scenario-latency-lines");
      if (latencyCanvas) drawLine(latencyCanvas, reportCharts.scenarioLatencyTrend);
      document.querySelectorAll(".grouped-correlation-canvas").forEach((canvas) => drawLine(canvas, groupedCorrelationCharts[canvas.dataset.groupedKey || ""]));
      document.querySelectorAll(".ungrouped-correlation-canvas").forEach((canvas) => drawLine(canvas, ungroupedCorrelationCharts[canvas.dataset.ungroupedKey || ""]));
    }}
    window.addEventListener("load", renderCharts);
    window.addEventListener("resize", renderCharts);
  </script>
</body>
</html>
"""


def _build_rich_html_report(result: Dict[str, Any]) -> str:
    return _build_dotnet_html_report(LoadStrikeNodeStats(result))


def _extract_status_code_rows(
    scenarios: List[Dict[str, Any]],
    steps: List[Dict[str, Any]],
) -> List[tuple[str, str, str, int]]:
    rows: List[tuple[str, str, str, int]] = []
    for scenario in scenarios:
        scenario_name = str(scenario.get("scenarioName") or "")
        status_codes = scenario.get("statusCodes") if isinstance(scenario.get("statusCodes"), dict) else {}
        for code, count in status_codes.items():
            rows.append(("scenario", scenario_name, str(code), _as_int(count)))
    for step in steps:
        owner = f"{step.get('scenarioName')}.{step.get('stepName')}"
        status_codes = step.get("statusCodes") if isinstance(step.get("statusCodes"), dict) else {}
        for code, count in status_codes.items():
            rows.append(("step", owner, str(code), _as_int(count)))
    return rows


def _render_plugin_table(table: Dict[str, Any]) -> str:
    headers = [str(header) for header in table.get("headers", []) if str(header or "").strip()]
    rows = [row for row in table.get("rows", []) if isinstance(row, dict)]
    if not headers:
        seen: List[str] = []
        for row in rows:
            for key in row.keys():
                key_text = str(key)
                if key_text not in seen:
                    seen.append(key_text)
        headers = seen
    if not headers:
        return "<div class='muted'>No table rows.</div>"
    head_html = "".join(f"<th>{_escape_html(header)}</th>" for header in headers)
    body_html = "".join(
        "<tr>" + "".join(f"<td>{_escape_html(row.get(header))}</td>" for header in headers) + "</tr>"
        for row in rows
    )
    if not body_html:
        body_html = f"<tr><td colspan='{len(headers)}'>No rows</td></tr>"
    return f"<table><thead><tr>{head_html}</tr></thead><tbody>{body_html}</tbody></table>"


def _escape_html(value: Any) -> str:
    return (
        str("" if value is None else value)
        .replace("&", "&amp;")
        .replace("<", "&lt;")
        .replace(">", "&gt;")
        .replace('"', "&quot;")
        .replace("'", "&#39;")
    )


_REPORT_FALLBACK_SVG = (
    "<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 128 128'>"
    "<defs><linearGradient id='g' x1='0' y1='0' x2='1' y2='1'>"
    "<stop offset='0' stop-color='#64b5ff'/>"
    "<stop offset='1' stop-color='#2f66db'/></linearGradient></defs>"
    "<rect width='128' height='128' rx='24' fill='#081325'/>"
    "<path d='M24 94L56 24l16 34 14-22 18 58h-16l-7-23-9 13-10-21-14 31H24z' fill='url(#g)'/>"
    "</svg>"
)
_REPORT_LOGO_CACHE: Dict[str, str] = {}


def _append_report_line(parts: List[str], text: str = "") -> None:
    parts.append(text)
    parts.append(os.linesep)


def _format_dotnet_datetime(value: Any) -> str:
    dt = _parse_datetime_utc(value)
    if dt is None:
        return ""
    dt = dt.astimezone(timezone.utc)
    fraction = f"{dt.microsecond:06d}0"
    return dt.strftime("%Y-%m-%dT%H:%M:%S") + f".{fraction}Z"


def _escape_json_for_html_script(value: str) -> str:
    return value.replace("</", "<\\/").replace("<!--", "<\\!--")


def _build_report_logo_data_uri(resource_name: str) -> str:
    cached = _REPORT_LOGO_CACHE.get(resource_name)
    if cached:
        return cached

    filename = "logo-dark-theme.png" if "dark" in resource_name else "logo-light-theme.png"
    candidates = [
        Path(__file__).resolve().parent / "assets" / filename,
    ]
    for candidate in candidates:
        try:
            if candidate.is_file():
                data_uri = "data:image/png;base64," + base64.b64encode(candidate.read_bytes()).decode("ascii")
                _REPORT_LOGO_CACHE[resource_name] = data_uri
                return data_uri
        except OSError:
            continue

    fallback = "data:image/svg+xml;base64," + base64.b64encode(_REPORT_FALLBACK_SVG.encode("utf-8")).decode("ascii")
    _REPORT_LOGO_CACHE[resource_name] = fallback
    return fallback


def _get_report_logo_light_data_uri() -> str:
    return _build_report_logo_data_uri("LoadStrike.Assets.logo.light.png")


def _get_report_logo_dark_data_uri() -> str:
    return _build_report_logo_data_uri("LoadStrike.Assets.logo.dark.png")


def _build_dotnet_table_html(rows: List[Dict[str, Any]], wrap_in_card: bool = True) -> str:
    if not rows:
        if wrap_in_card:
            return f'<div class="card"><div class="table-wrap"><table><tbody><tr><td>No rows.</td></tr></tbody></table></div></div>{os.linesep}'
        return f'<div class="table-wrap"><table><tbody><tr><td>No rows.</td></tr></tbody></table></div>{os.linesep}'

    headers: List[str] = []
    for row in rows:
        for key in row.keys():
            text = str(key)
            if text not in headers:
                headers.append(text)

    parts: List[str] = []
    if wrap_in_card:
        _append_report_line(parts, '<div class="card">')
    _append_report_line(parts, '<div class="table-wrap">')
    _append_report_line(parts, "<table>")
    _append_report_line(parts, "<thead><tr>")
    for header in headers:
        _append_report_line(parts, f"<th>{_escape_html(header)}</th>")
    _append_report_line(parts, "</tr></thead><tbody>")
    for row in rows:
        _append_report_line(parts, "<tr>")
        for header in headers:
            _append_report_line(parts, f"<td>{_escape_html(row.get(header))}</td>")
        _append_report_line(parts, "</tr>")
    _append_report_line(parts, "</tbody></table></div>")
    if wrap_in_card:
        _append_report_line(parts, "</div>")
    return "".join(parts)


def _build_dotnet_summary_latency_row(
    scenario_name: str,
    result_name: str,
    measurement: LoadStrikeMeasurementStats,
) -> Dict[str, Any]:
    return {
        "Scenario": scenario_name,
        "Result": result_name,
        "Count": measurement.request.count,
        "LatencyMinMs": _format_report_number(measurement.latency.min_ms),
        "LatencyMeanMs": _format_report_number(measurement.latency.mean_ms),
        "LatencyP50Ms": _format_report_number(measurement.latency.percent50),
        "LatencyP75Ms": _format_report_number(measurement.latency.percent75),
        "LatencyP95Ms": _format_report_number(measurement.latency.percent95),
        "LatencyP99Ms": _format_report_number(measurement.latency.percent99),
        "LatencyMaxMs": _format_report_number(measurement.latency.max_ms),
        "LatencyStdDev": _format_report_number(measurement.latency.std_dev),
    }


def _build_dotnet_measurement_row(
    scope: str,
    scenario_name: str,
    step_name: str,
    result_name: str,
    measurement: LoadStrikeMeasurementStats,
) -> Dict[str, Any]:
    return {
        "Scope": scope,
        "Scenario": scenario_name,
        "Step": step_name,
        "Result": result_name,
        "Count": measurement.request.count,
        "Percent": measurement.request.percent,
        "RPS": _format_report_number(measurement.request.rps),
        "LatencyMinMs": _format_report_number(measurement.latency.min_ms),
        "LatencyMeanMs": _format_report_number(measurement.latency.mean_ms),
        "LatencyP50Ms": _format_report_number(measurement.latency.percent50),
        "LatencyP75Ms": _format_report_number(measurement.latency.percent75),
        "LatencyP95Ms": _format_report_number(measurement.latency.percent95),
        "LatencyP99Ms": _format_report_number(measurement.latency.percent99),
        "LatencyMaxMs": _format_report_number(measurement.latency.max_ms),
        "LatencyStdDev": _format_report_number(measurement.latency.std_dev),
        "Latency<=800ms": measurement.latency.latency_count.less_or_eq_800,
        "Latency800-1200ms": measurement.latency.latency_count.more_800_less_1200,
        "Latency>=1200ms": measurement.latency.latency_count.more_or_eq_1200,
        "BytesTotal": measurement.data_transfer.all_bytes,
        "BytesMin": measurement.data_transfer.min_bytes,
        "BytesMean": measurement.data_transfer.mean_bytes,
        "BytesP50": measurement.data_transfer.percent50,
        "BytesP75": measurement.data_transfer.percent75,
        "BytesP95": measurement.data_transfer.percent95,
        "BytesP99": measurement.data_transfer.percent99,
        "BytesMax": measurement.data_transfer.max_bytes,
        "BytesStdDev": _format_report_number(measurement.data_transfer.std_dev),
    }


def _append_chart_card(parts: List[str], chart_id: str, title: str) -> None:
    _append_report_line(parts, f'<div class="chart-card"><h3>{_escape_html(title)}</h3><canvas id="{_escape_html(chart_id)}" class="chart-canvas"></canvas></div>')


def _has_chart_point_data(points: Any) -> bool:
    return isinstance(points, list) and len(points) > 0


def _has_pie_chart_data(points: Any) -> bool:
    return isinstance(points, list) and any(
        isinstance(point, dict) and abs(float(point.get("value", 0) or 0)) > 0
        for point in points
    )


def _has_latency_trend_data(chart: Any) -> bool:
    if not isinstance(chart, dict):
        return False
    labels = chart.get("labels") or []
    series = chart.get("series") or []
    return bool(labels) and any(
        isinstance(series_entry, dict)
        and any(
            isinstance(value, (int, float)) and math.isfinite(float(value))
            for value in (series_entry.get("values") or [])
        )
        for series_entry in series
    )


def _has_non_empty_hints(plugin: LoadStrikePluginData) -> bool:
    return any(str(hint or "").strip() for hint in plugin.hints)


def _build_dotnet_chart_data(node_stats: LoadStrikeNodeStats) -> Dict[str, Any]:
    ordered = sorted(node_stats.scenario_stats, key=lambda row: row.sort_index)
    return {
        "overallOutcome": [
            {"label": "OK", "value": node_stats.all_ok_count, "color": "#18a957"},
            {"label": "FAIL", "value": node_stats.all_fail_count, "color": "#d14343"},
        ],
        "scenarioRequests": [
            {"label": row.scenario_name, "value": row.all_request_count, "color": "#3b82f6"}
            for row in ordered
        ],
        "scenarioP95Latency": [
            {
                "label": row.scenario_name,
                "value": _normalize_chart_number(max(row.ok.latency.percent95, row.fail.latency.percent95)),
                "color": "#8b5cf6",
            }
            for row in ordered
        ],
        "scenarioRps": [
            {
                "label": row.scenario_name,
                "value": 0 if _report_duration_seconds(row._value("duration", "durationMs")) <= 0 else row.all_request_count / _report_duration_seconds(row._value("duration", "durationMs")),
                "color": "#10b981",
            }
            for row in ordered
        ],
        "scenarioFailRate": [
            {
                "label": row.scenario_name,
                "value": _normalize_chart_number(0 if row.all_request_count <= 0 else (row.all_fail_count * 100 / row.all_request_count)),
                "color": "#ef4444",
            }
            for row in ordered
        ],
        "scenarioBytes": [
            {"label": row.scenario_name, "value": row.all_bytes, "color": "#0ea5e9"}
            for row in ordered
        ],
        "statusCodeClasses": _build_dotnet_status_code_class_chart(ordered),
        "scenarioLatencyTrend": {
            "labels": [row.scenario_name for row in ordered],
            "series": [
                {"name": "P50", "color": "#38bdf8", "values": [_normalize_chart_number(max(row.ok.latency.percent50, row.fail.latency.percent50)) for row in ordered]},
                {"name": "P75", "color": "#22c55e", "values": [_normalize_chart_number(max(row.ok.latency.percent75, row.fail.latency.percent75)) for row in ordered]},
                {"name": "P95", "color": "#f59e0b", "values": [_normalize_chart_number(max(row.ok.latency.percent95, row.fail.latency.percent95)) for row in ordered]},
                {"name": "P99", "color": "#f43f5e", "values": [_normalize_chart_number(max(row.ok.latency.percent99, row.fail.latency.percent99)) for row in ordered]},
            ],
        },
    }


def _build_dotnet_status_code_class_chart(scenarios: List[LoadStrikeScenarioStats]) -> List[Dict[str, Any]]:
    buckets = {"2xx": 0, "3xx": 0, "4xx": 0, "5xx": 0, "Other": 0}
    for scenario in scenarios:
        for code in [*scenario.ok.status_codes, *scenario.fail.status_codes]:
            buckets[_classify_status_code_bucket(code.status_code)] += code.count
    return [
        {"label": label, "value": value, "color": color}
        for label, value, color in (
            ("2xx", buckets["2xx"], "#16a34a"),
            ("3xx", buckets["3xx"], "#0ea5e9"),
            ("4xx", buckets["4xx"], "#f59e0b"),
            ("5xx", buckets["5xx"], "#dc2626"),
            ("Other", buckets["Other"], "#8b5cf6"),
        )
        if value > 0
    ]


def _format_dotnet_percent(value: float) -> str:
    return f"{float(value):0.2f}".rstrip("0").rstrip(".")


def _build_dotnet_scenario_rows(node_stats: LoadStrikeNodeStats) -> List[Dict[str, Any]]:
    return [
        {
            "Scenario": scenario.scenario_name,
            "Simulation": scenario.load_simulation_stats.simulation_name,
            "SimulationValue": scenario.load_simulation_stats.value,
            "Requests": scenario.all_request_count,
            "OK": scenario.all_ok_count,
            "FAIL": scenario.all_fail_count,
            "Duration": _format_dotnet_timedelta(scenario._value("duration", "durationMs")),
            "RPS": _format_report_number(0 if _report_duration_seconds(scenario._value("duration", "durationMs")) <= 0 else scenario.all_request_count / _report_duration_seconds(scenario._value("duration", "durationMs"))),
            "LatencyP95Ms": _format_report_number(max(scenario.ok.latency.percent95, scenario.fail.latency.percent95)),
            "LatencyP99Ms": _format_report_number(max(scenario.ok.latency.percent99, scenario.fail.latency.percent99)),
            "CurrentOperation": scenario.current_operation,
        }
        for scenario in sorted(node_stats.scenario_stats, key=lambda row: row.sort_index)
    ]


def _build_dotnet_step_rows(node_stats: LoadStrikeNodeStats) -> List[Dict[str, Any]]:
    rows: List[Dict[str, Any]] = []
    for scenario in sorted(node_stats.scenario_stats, key=lambda row: row.sort_index):
        for step in sorted(scenario.step_stats, key=lambda row: row.sort_index):
            rows.append(
                {
                    "Scenario": scenario.scenario_name,
                    "Step": step.step_name,
                    "Requests": step.ok.request.count + step.fail.request.count,
                    "OK": step.ok.request.count,
                    "FAIL": step.fail.request.count,
                    "OK_RPS": _format_report_number(step.ok.request.rps),
                    "FAIL_RPS": _format_report_number(step.fail.request.rps),
                    "LatencyMeanMs": _format_report_number(max(step.ok.latency.mean_ms, step.fail.latency.mean_ms)),
                    "P95LatencyMs": _format_report_number(max(step.ok.latency.percent95, step.fail.latency.percent95)),
                }
            )
    return rows


def _build_dotnet_scenario_measurement_rows(node_stats: LoadStrikeNodeStats) -> List[Dict[str, Any]]:
    rows: List[Dict[str, Any]] = []
    for scenario in sorted(node_stats.scenario_stats, key=lambda row: row.sort_index):
        rows.append(_build_dotnet_measurement_row("Scenario", scenario.scenario_name, "", "OK", scenario.ok))
        rows.append(_build_dotnet_measurement_row("Scenario", scenario.scenario_name, "", "FAIL", scenario.fail))
    return rows


def _build_dotnet_step_measurement_rows(node_stats: LoadStrikeNodeStats) -> List[Dict[str, Any]]:
    rows: List[Dict[str, Any]] = []
    for scenario in sorted(node_stats.scenario_stats, key=lambda row: row.sort_index):
        for step in sorted(scenario.step_stats, key=lambda row: row.sort_index):
            rows.append(_build_dotnet_measurement_row("Step", scenario.scenario_name, step.step_name, "OK", step.ok))
            rows.append(_build_dotnet_measurement_row("Step", scenario.scenario_name, step.step_name, "FAIL", step.fail))
    return rows


def _build_dotnet_status_code_rows(node_stats: LoadStrikeNodeStats) -> List[Dict[str, Any]]:
    rows: List[Dict[str, Any]] = []
    for scenario in sorted(node_stats.scenario_stats, key=lambda row: row.sort_index):
        for code in scenario.ok.status_codes:
            rows.append({"Scope": "Scenario", "Scenario": scenario.scenario_name, "Step": "", "Result": "OK", "StatusCode": code.status_code, "Message": code.message, "Count": code.count, "Percent": code.percent, "IsError": code.is_error})
        for code in scenario.fail.status_codes:
            rows.append({"Scope": "Scenario", "Scenario": scenario.scenario_name, "Step": "", "Result": "FAIL", "StatusCode": code.status_code, "Message": code.message, "Count": code.count, "Percent": code.percent, "IsError": code.is_error})
        for step in sorted(scenario.step_stats, key=lambda row: row.sort_index):
            for code in step.ok.status_codes:
                rows.append({"Scope": "Step", "Scenario": scenario.scenario_name, "Step": step.step_name, "Result": "OK", "StatusCode": code.status_code, "Message": code.message, "Count": code.count, "Percent": code.percent, "IsError": code.is_error})
            for code in step.fail.status_codes:
                rows.append({"Scope": "Step", "Scenario": scenario.scenario_name, "Step": step.step_name, "Result": "FAIL", "StatusCode": code.status_code, "Message": code.message, "Count": code.count, "Percent": code.percent, "IsError": code.is_error})
    return rows


def _build_dotnet_threshold_rows(node_stats: LoadStrikeNodeStats) -> List[Dict[str, Any]]:
    return [
        {
            "Scenario": threshold.scenario_name,
            "Step": threshold.step_name,
            "Check": threshold.check_expression,
            "Failed": threshold.is_failed,
            "ErrorCount": threshold.error_count,
            "Exception": threshold.exception_msg,
        }
        for threshold in node_stats.thresholds
    ]


def _build_dotnet_metric_rows(node_stats: LoadStrikeNodeStats) -> List[Dict[str, Any]]:
    rows: List[Dict[str, Any]] = []
    for counter in node_stats.metrics.counters:
        rows.append(
            {
                "Type": "Counter",
                "Scenario": counter.scenario_name,
                "Name": counter.metric_name,
                "Unit": counter.unit_of_measure,
                "Value": counter.value,
            }
        )
    for gauge in node_stats.metrics.gauges:
        rows.append(
            {
                "Type": "Gauge",
                "Scenario": gauge.scenario_name,
                "Name": gauge.metric_name,
                "Unit": gauge.unit_of_measure,
                "Value": _format_report_number(gauge.value),
            }
        )
    return rows


def _build_dotnet_summary_html(node_stats: LoadStrikeNodeStats) -> str:
    success_rate = 0 if node_stats.all_request_count <= 0 else (node_stats.all_ok_count * 100 / node_stats.all_request_count)
    fail_rate = 0 if node_stats.all_request_count <= 0 else (node_stats.all_fail_count * 100 / node_stats.all_request_count)
    overall_rps = 0 if _report_duration_seconds(node_stats._value("duration", "durationMs")) <= 0 else node_stats.all_request_count / _report_duration_seconds(node_stats._value("duration", "durationMs"))
    top_scenario = None
    for scenario in node_stats.scenario_stats:
        if top_scenario is None or scenario.all_request_count > top_scenario.all_request_count:
            top_scenario = scenario
    latency_rows = []
    for scenario in sorted(node_stats.scenario_stats, key=lambda row: row.sort_index):
        latency_rows.append(_build_dotnet_summary_latency_row(scenario.scenario_name, "OK", scenario.ok))
        latency_rows.append(_build_dotnet_summary_latency_row(scenario.scenario_name, "FAIL", scenario.fail))
    chart_data = _build_dotnet_chart_data(node_stats)

    parts: List[str] = []
    _append_report_line(parts, '<div class="card-grid">')
    _append_report_line(parts, f'<div class="stat-card"><div class="stat-label">Total Requests</div><div class="stat-value">{node_stats.all_request_count}</div></div>')
    _append_report_line(parts, f'<div class="stat-card"><div class="stat-label">Success</div><div class="stat-value value-ok">{node_stats.all_ok_count} ({_format_dotnet_percent(success_rate)}%)</div></div>')
    _append_report_line(parts, f'<div class="stat-card"><div class="stat-label">Fail</div><div class="stat-value value-fail">{node_stats.all_fail_count} ({_format_dotnet_percent(fail_rate)}%)</div></div>')
    _append_report_line(parts, f'<div class="stat-card"><div class="stat-label">Overall RPS</div><div class="stat-value">{_format_report_number(overall_rps)}</div></div>')
    _append_report_line(parts, f'<div class="stat-card"><div class="stat-label">Duration</div><div class="stat-value">{_escape_html(_format_dotnet_timedelta(node_stats._value("duration", "durationMs")))}</div></div>')
    _append_report_line(parts, f'<div class="stat-card"><div class="stat-label">Total Bytes</div><div class="stat-value">{node_stats.all_bytes}</div></div>')
    _append_report_line(parts, f'<div class="stat-card"><div class="stat-label">Top Scenario</div><div class="stat-value">{_escape_html(top_scenario.scenario_name if top_scenario else "n/a")}</div></div>')
    _append_report_line(parts, f'<div class="stat-card"><div class="stat-label">Node</div><div class="stat-value">{_loadstrike_node_type_tag(node_stats._dict("nodeInfo").get("nodeType"))}</div></div>')
    _append_report_line(parts, "</div>")
    charts: List[str] = []
    if _has_pie_chart_data(chart_data.get("overallOutcome")):
        _append_chart_card(charts, "chart-outcome", "Success vs Fail")
    if _has_chart_point_data(chart_data.get("scenarioRequests")):
        _append_chart_card(charts, "chart-scenario-requests", "Requests by Scenario")
    if _has_chart_point_data(chart_data.get("scenarioP95Latency")):
        _append_chart_card(charts, "chart-scenario-p95", "P95 Latency by Scenario (ms)")
    if _has_chart_point_data(chart_data.get("scenarioRps")):
        _append_chart_card(charts, "chart-scenario-rps", "RPS by Scenario")
    if _has_chart_point_data(chart_data.get("scenarioFailRate")):
        _append_chart_card(charts, "chart-scenario-fail-rate", "Failure Rate by Scenario (%)")
    if _has_chart_point_data(chart_data.get("scenarioBytes")):
        _append_chart_card(charts, "chart-scenario-bytes", "Bytes by Scenario")
    if _has_pie_chart_data(chart_data.get("statusCodeClasses")):
        _append_chart_card(charts, "chart-status-code-classes", "Status Code Class Mix")
    if _has_latency_trend_data(chart_data.get("scenarioLatencyTrend")):
        _append_chart_card(charts, "chart-scenario-latency-lines", "Latency Trend by Scenario (ms)")
    if charts:
        _append_report_line(parts, '<div class="card">')
        _append_report_line(parts, "<h2>Charts</h2>")
        _append_report_line(parts, '<div class="chart-grid">')
        parts.extend(charts)
        _append_report_line(parts, "</div>")
        _append_report_line(parts, "</div>")
    if latency_rows:
        _append_report_line(parts, '<div class="card">')
        _append_report_line(parts, "<h2>Latency by Scenario (Table)</h2>")
        parts.append(_build_dotnet_table_html(latency_rows, wrap_in_card=False))
        _append_report_line(parts)
        _append_report_line(parts, "</div>")
    _append_report_line(parts, '<div class="card">')
    _append_report_line(parts, "<h2>Environment</h2>")
    _append_report_line(parts, '<div class="table-wrap"><table><tbody>')
    _append_report_line(parts, f"<tr><th>Cluster Id</th><td>{_escape_html(node_stats.test_info.cluster_id)}</td></tr>")
    _append_report_line(parts, f"<tr><th>Created (UTC)</th><td>{_escape_html(_format_dotnet_datetime(node_stats._dict('testInfo').get('createdUtc') or node_stats._dict('testInfo').get('created')))}</td></tr>")
    _append_report_line(parts, f"<tr><th>Machine</th><td>{_escape_html(node_stats.node_info.machine_name)}</td></tr>")
    _append_report_line(parts, f"<tr><th>OS</th><td>{_escape_html(node_stats.node_info.os)}</td></tr>")
    _append_report_line(parts, f"<tr><th>DotNet</th><td>{_escape_html(node_stats.node_info.dotnet_version)}</td></tr>")
    _append_report_line(parts, f"<tr><th>Processor</th><td>{_escape_html(node_stats.node_info.processor)}</td></tr>")
    _append_report_line(parts, f"<tr><th>Cores</th><td>{node_stats.node_info.cores_count}</td></tr>")
    _append_report_line(parts, f"<tr><th>Operation</th><td>{_escape_html(node_stats.node_info.current_operation)}</td></tr>")
    _append_report_line(parts, "</tbody></table></div>")
    _append_report_line(parts, "</div>")
    return "".join(parts)


def _build_dotnet_scenario_html(node_stats: LoadStrikeNodeStats) -> str:
    return _build_dotnet_table_html(_build_dotnet_scenario_rows(node_stats))


def _build_dotnet_step_html(node_stats: LoadStrikeNodeStats) -> str:
    return _build_dotnet_table_html(_build_dotnet_step_rows(node_stats))


def _build_dotnet_scenario_measurement_html(node_stats: LoadStrikeNodeStats) -> str:
    return _build_dotnet_table_html(_build_dotnet_scenario_measurement_rows(node_stats))


def _build_dotnet_step_measurement_html(node_stats: LoadStrikeNodeStats) -> str:
    return _build_dotnet_table_html(_build_dotnet_step_measurement_rows(node_stats))


def _build_dotnet_status_code_html(node_stats: LoadStrikeNodeStats) -> str:
    return _build_dotnet_table_html(_build_dotnet_status_code_rows(node_stats))


def _build_dotnet_failed_response_html(node_stats: LoadStrikeNodeStats) -> str:
    scenario_dicts = [scenario.to_dict() for scenario in sorted(node_stats.scenario_stats, key=lambda row: row.sort_index)]
    plugin_dicts = [plugin.to_dict() for plugin in node_stats.plugins_data]
    failed_status_rows = _build_failed_status_rows(scenario_dicts)
    failed_event_rows = _build_failed_event_rows(plugin_dicts)
    return _build_dotnet_failed_response_content(failed_status_rows, failed_event_rows)


def _build_dotnet_failed_response_content(failed_status_rows: List[Dict[str, Any]], failed_event_rows: List[Dict[str, Any]]) -> str:
    parts: List[str] = []
    if failed_status_rows:
        _append_report_line(parts, '<div class="card">')
        _append_report_line(parts, "<h2>Failed Status Codes</h2>")
        parts.append(_build_dotnet_table_html(failed_status_rows, wrap_in_card=False))
        _append_report_line(parts)
        _append_report_line(parts, "</div>")
    if failed_event_rows:
        _append_report_line(parts, '<div class="card">')
        _append_report_line(parts, "<h2>Failed and Timed Out Rows</h2>")
        parts.append(_build_dotnet_table_html(failed_event_rows, wrap_in_card=False))
        _append_report_line(parts)
        _append_report_line(parts, "</div>")
    return "".join(parts)


def _build_dotnet_threshold_html(node_stats: LoadStrikeNodeStats) -> str:
    return _build_dotnet_table_html(_build_dotnet_threshold_rows(node_stats))


def _build_dotnet_metric_html(node_stats: LoadStrikeNodeStats) -> str:
    return _build_dotnet_table_html(_build_dotnet_metric_rows(node_stats))


def _build_dotnet_grouped_correlation_summary_html(rows: List[Dict[str, Any]], grouped_chart_key: str) -> str:
    parts: List[str] = []
    payloads = _build_grouped_correlation_chart_payloads(rows)
    parts.append(_build_dotnet_table_html(rows))
    if not payloads:
        return "".join(parts)
    _append_report_line(parts)
    _append_report_line(parts, '<div class="card"><h2>Grouped Correlation Percentile Trends</h2><p>Each chart is one GatherBy value. The line shows latency progression across P50 to P99.</p></div>')
    _append_report_line(parts, '<div class="chart-grid correlation-chart-grid">')
    for index, payload in enumerate(payloads):
        chart_key = f"{grouped_chart_key}-value-{index}"
        chart_json = _escape_json_for_html_script(json.dumps(payload["chart"], separators=(",", ":")))
        _append_report_line(parts, f'<script type="application/json" data-grouped-correlation-chart="{_escape_html(chart_key)}">{chart_json}</script>')
        _append_report_line(parts, f'<div class="chart-card correlation-chart-card"><h3>{_escape_html(payload["title"])}</h3><p>{_escape_html(payload["subtitle"])}</p><canvas class="chart-canvas grouped-correlation-canvas" data-grouped-key="{_escape_html(chart_key)}"></canvas></div>')
    _append_report_line(parts, "</div>")
    return "".join(parts)


def _build_dotnet_ungrouped_correlation_summary_html(rows: List[Dict[str, Any]], grouped_chart_key: str) -> str:
    chart = _build_ungrouped_correlation_chart_payload(rows)
    parts: List[str] = []
    parts.append(_build_dotnet_table_html(rows))
    if _has_latency_trend_data(chart):
        chart_json = _escape_json_for_html_script(json.dumps(chart, separators=(",", ":")))
        _append_report_line(parts)
        _append_report_line(parts, '<div class="card"><h2>Ungrouped Correlation Percentile Trends</h2><p>All percentile lines are shown in one graph for direct comparison.</p></div>')
        _append_report_line(parts, f'<script type="application/json" data-ungrouped-correlation="{_escape_html(grouped_chart_key)}">{chart_json}</script>')
        _append_report_line(parts, '<div class="chart-grid correlation-chart-grid">')
        _append_report_line(parts, f'<div class="chart-card correlation-chart-card"><h3>Ungrouped Correlation Percentiles</h3><canvas class="chart-canvas ungrouped-correlation-canvas" data-ungrouped-key="{_escape_html(grouped_chart_key)}"></canvas></div>')
        _append_report_line(parts, "</div>")
    return "".join(parts)


def _build_dotnet_plugin_hints(plugin: LoadStrikePluginData) -> str:
    if not _has_non_empty_hints(plugin):
        return ""
    items = "".join(f"<li>{_escape_html(hint)}</li>" for hint in plugin.hints if str(hint or "").strip())
    return f'<div class="card"><strong>Hints</strong><ul>{items}</ul></div>'


def _build_dotnet_html_tabs(node_stats: LoadStrikeNodeStats) -> List[tuple[str, str, str]]:
    tabs: List[tuple[str, str, str]] = [("summary", "Summary", _build_dotnet_summary_html(node_stats))]

    scenario_rows = _build_dotnet_scenario_rows(node_stats)
    if scenario_rows:
        tabs.append(("scenarios", "Scenarios", _build_dotnet_table_html(scenario_rows)))

    scenario_measurement_rows = _build_dotnet_scenario_measurement_rows(node_stats)
    if scenario_measurement_rows:
        tabs.append(("scenario-measurements", "Scenario Measurements", _build_dotnet_table_html(scenario_measurement_rows)))

    step_rows = _build_dotnet_step_rows(node_stats)
    if step_rows:
        tabs.append(("steps", "Steps", _build_dotnet_table_html(step_rows)))

    step_measurement_rows = _build_dotnet_step_measurement_rows(node_stats)
    if step_measurement_rows:
        tabs.append(("step-measurements", "Step Measurements", _build_dotnet_table_html(step_measurement_rows)))

    status_code_rows = _build_dotnet_status_code_rows(node_stats)
    if status_code_rows:
        tabs.append(("status-codes", "Status Codes", _build_dotnet_table_html(status_code_rows)))

    failed_status_rows = _build_failed_status_rows([scenario.to_dict() for scenario in sorted(node_stats.scenario_stats, key=lambda row: row.sort_index)])
    failed_event_rows = _build_failed_event_rows([plugin.to_dict() for plugin in node_stats.plugins_data])
    if failed_status_rows or failed_event_rows:
        tabs.append(("failed-responses", "Failed Responses", _build_dotnet_failed_response_content(failed_status_rows, failed_event_rows)))

    threshold_rows = _build_dotnet_threshold_rows(node_stats)
    if threshold_rows:
        tabs.append(("thresholds", "Thresholds", _build_dotnet_table_html(threshold_rows)))

    metric_rows = _build_dotnet_metric_rows(node_stats)
    if metric_rows:
        tabs.append(("metrics", "Metrics", _build_dotnet_table_html(metric_rows)))

    for plugin in node_stats.plugins_data:
        hints = _build_dotnet_plugin_hints(plugin)
        skip_merged_plugin_tab = "failed" in plugin.plugin_name.lower() or "correlation" in plugin.plugin_name.lower()
        if not plugin.tables:
            if skip_merged_plugin_tab:
                continue
            if not hints:
                continue
            tabs.append((f"plugin-{len(tabs)}", plugin.plugin_name, hints))
            continue
        for table in plugin.tables:
            is_failed_responses = "failed" in plugin.plugin_name.lower() or "failed" in table.table_name.lower()
            is_grouped = "correlation" in plugin.plugin_name.lower() and "grouped correlation summary" in table.table_name.lower()
            is_ungrouped = "correlation" in plugin.plugin_name.lower() and "ungrouped correlation rows" in table.table_name.lower()
            if is_failed_responses:
                continue
            body_rows = [dict(row) for row in table.rows]
            if not body_rows:
                continue
            if is_grouped:
                title = "Grouped Correlation Summary"
                body = _build_dotnet_grouped_correlation_summary_html(body_rows, f"grouped-correlation-{len(tabs)}")
            elif is_ungrouped:
                title = "Ungrouped Corelation Summary"
                body = _build_dotnet_ungrouped_correlation_summary_html(body_rows, f"ungrouped-correlation-{len(tabs)}")
            else:
                title = f"{plugin.plugin_name}: {table.table_name}"
                body = _build_dotnet_table_html(body_rows)
            tabs.append((f"plugin-{len(tabs)}", title, f"{hints}{body}"))
    return tabs


def _build_dotnet_html_report(node_stats: LoadStrikeNodeStats) -> str:
    tabs = _build_dotnet_html_tabs(node_stats)
    buttons_html = "".join(
        f'<button class="tab-btn" data-tab="{tab_id}">{_escape_html(title)}</button>{os.linesep}'
        for tab_id, title, _html in tabs
    )
    sections_html = "".join(
        f'<section id="{tab_id}" class="tab">{html}</section>{os.linesep}'
        for tab_id, _title, html in tabs
    )
    chart_data_json = json.dumps(_build_dotnet_chart_data(node_stats), separators=(",", ":"))
    template = """<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1" />
<title>LoadStrike Report</title>
<style>
:root{--bg:#f4f7fc;--bgTop:#fff3d0;--bgRight:#dbe8ff;--bgBottom:#edf2fb;--panel:#ffffff;--panelAlt:#eef3fb;--line:#d3deed;--text:#0f172a;--muted:#4b5563;--accent:#2563eb;--ok:#138a4a;--fail:#c63636;--warn:#b7791f;--chip:#edf3fc;--card:#ffffff;--stat:#f5f9ff;--chartPanel:#0f172a;--chartGrid:#334155;--chartAxis:#b5c2d3;--chartLabel:#dbe6f4;--chartDot:#0f172a;--chartPieCenter:#0f172a;--chartPieCenterText:#e5eefc;--chartLegendText:#e6edf3;--shadow:0 10px 24px rgba(15,23,42,.1)}
body[data-theme='dark']{--bg:#0d1117;--bgTop:#18243b;--bgRight:#102235;--bgBottom:#0b0f14;--panel:#111827;--panelAlt:#0f172a;--line:#263241;--text:#e6edf3;--muted:#9fb0c3;--accent:#2563eb;--ok:#18a957;--fail:#d14343;--warn:#f59e0b;--chip:rgba(31,41,55,.45);--card:linear-gradient(180deg,rgba(17,24,39,.92) 0,rgba(13,19,32,.92) 100%);--stat:rgba(20,30,47,.65);--chartPanel:rgba(15,23,42,.72);--chartGrid:#334155;--chartAxis:#b5c2d3;--chartLabel:#dbe6f4;--chartDot:#0f172a;--chartPieCenter:#0f172a;--chartPieCenterText:#e5eefc;--chartLegendText:#e6edf3;--shadow:0 10px 24px rgba(0,0,0,.2)}
body{margin:0;background:radial-gradient(1200px 700px at 10% -10%,var(--bgTop) 0,transparent 58%),radial-gradient(900px 620px at 100% 0,var(--bgRight) 0,transparent 57%),var(--bgBottom);color:var(--text);font-family:'Segoe UI',Tahoma,sans-serif}
.wrap{max-width:1440px;margin:0 auto;padding:20px}
.report-brand{display:flex;align-items:center;gap:16px;margin:0 0 10px 0;overflow:visible;padding-top:8px;flex-wrap:wrap}
.report-logo-slot{width:380px;height:184px;max-width:100%;flex:0 0 auto;display:flex;align-items:flex-start;justify-content:flex-start;overflow:visible}
.report-logo{width:100%;height:100%;object-fit:contain;object-position:left top;border:none;background:transparent;box-shadow:none;border-radius:0;padding:0;margin:0;overflow:visible;transform:scale(var(--report-logo-scale,1));transform-origin:left top;transition:transform .2s ease}
body[data-theme='dark'] .report-logo{--report-logo-scale:1.175}
.theme-toggle-report{position:fixed;top:12px;right:12px;z-index:1200;display:inline-flex;align-items:center;justify-content:center;width:40px;height:40px;appearance:none;border:1px solid var(--line);background:var(--chip);color:var(--text);padding:0;border-radius:999px;font-size:18px;font-weight:700;cursor:pointer;transition:all .2s ease}
.theme-toggle-report:hover{border-color:var(--accent);transform:translateY(-1px)}
.theme-toggle-report span{line-height:1;pointer-events:none}
h1{margin:0 0 10px 0;font-size:28px;letter-spacing:.2px}
h2{margin:0 0 12px 0;font-size:18px}
h3{margin:0 0 10px 0;font-size:15px;color:var(--text)}
.meta{display:flex;gap:14px;flex-wrap:wrap;color:var(--muted);font-size:13px;margin-bottom:16px}
.meta span{background:var(--chip);border:1px solid var(--line);padding:6px 10px;border-radius:999px}
.report-layout{display:grid;grid-template-columns:280px minmax(0,1fr);gap:14px;align-items:start}
.tabs-pane{position:sticky;top:12px;max-height:calc(100vh - 24px);overflow:auto;overscroll-behavior:contain;padding-right:4px;cursor:grab}
.tabs-pane.panning{cursor:grabbing;user-select:none}
.tabs{display:flex;flex-direction:column;gap:8px;margin:12px 0 14px 0}
.tab-btn{background:var(--panelAlt);color:var(--text);border:1px solid var(--line);padding:8px 12px;border-radius:8px;cursor:pointer;transition:all .2s ease;text-align:left;width:100%}
.tab-btn:hover{border-color:var(--accent);background:var(--chip)}
.tab-btn.active{background:linear-gradient(180deg,#2f66db 0,#2754b8 100%);border-color:#3f73e0}
.tabs-content{min-width:0}
.tab{display:none}
.tab.active{display:block}
table{width:100%;border-collapse:collapse;font-size:12px}
th,td{border:1px solid var(--line);padding:7px 8px;text-align:left;vertical-align:top}
th{background:var(--panelAlt);position:sticky;top:0;z-index:1}
.card{background:var(--card);border:1px solid var(--line);border-radius:12px;padding:14px;margin-bottom:14px;box-shadow:var(--shadow)}
.card-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(220px,1fr));gap:10px;margin-bottom:14px}
.stat-card{padding:10px 12px;border-radius:10px;border:1px solid var(--line);background:var(--stat)}
.stat-label{font-size:12px;color:var(--muted)}
.stat-value{font-size:22px;font-weight:700;margin-top:4px}
.value-ok{color:var(--ok)}
.value-fail{color:var(--fail)}
.chart-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(360px,1fr));gap:12px}
.chart-card{padding:12px;border:1px solid var(--line);border-radius:10px;background:var(--chartPanel)}
.chart-canvas{width:100%;height:260px;display:block}
.correlation-chart-grid{grid-template-columns:repeat(auto-fit,minmax(420px,720px));justify-content:center}
.correlation-chart-card{max-width:720px;width:100%}
.correlation-chart-card .chart-canvas{height:320px}
.chart-card h3,.chart-card p{color:var(--chartLegendText)}
.table-wrap{overflow:auto;max-height:70vh}
@media (max-width:980px){.wrap{padding:14px}.report-brand{margin-bottom:8px;padding-top:4px}.report-logo-slot{width:300px;height:146px}.theme-toggle-report{top:10px;right:10px}.report-layout{grid-template-columns:1fr}.tabs-pane{position:static;max-height:none;cursor:auto}.tabs{flex-direction:row;flex-wrap:wrap}.tab-btn{width:auto}.chart-canvas{height:220px}.correlation-chart-grid{grid-template-columns:1fr;justify-content:stretch}.correlation-chart-card{max-width:none}.correlation-chart-card .chart-canvas{height:280px}.stat-value{font-size:18px}}
</style>
</head>
<body data-theme="light">
<div class="wrap">
<button type="button" class="theme-toggle-report" data-report-theme-toggle aria-label="Switch to dark theme" aria-pressed="false" title="Switch to dark theme"><span aria-hidden="true">&#x263E;</span></button>
<div class="report-brand">
<div class="report-logo-slot">
<img src="__LOGO_LIGHT__" alt="LoadStrike logo" class="report-logo" data-report-logo data-logo-light="__LOGO_LIGHT__" data-logo-dark="__LOGO_DARK__" />
</div>
<h1>LoadStrike Report</h1>
</div>
<div class="meta">
<span>Suite: <strong>__TEST_SUITE__</strong></span>
<span>Name: <strong>__TEST_NAME__</strong></span>
<span>Session: <strong>__SESSION_ID__</strong></span>
<span>Duration: <strong>__DURATION__</strong></span>
</div>
<div class="report-layout">
<aside class="tabs-pane" id="tab-pane">
<div class="tabs">
__BUTTONS__</div>
</aside>
<div class="tabs-content">
__SECTIONS__</div>
</div>
</div>
<script>
const reportCharts=__CHART_DATA__;
const btns=[...document.querySelectorAll('.tab-btn')];
const tabSections=[...document.querySelectorAll('.tab')];
const tabsPane=document.getElementById('tab-pane');
const linePalette=['#38bdf8','#22c55e','#f59e0b','#a855f7','#f43f5e','#14b8a6','#eab308','#818cf8','#06b6d4','#84cc16'];
const reportThemeKey='loadstrike-report-theme';
const reportThemeToggle=document.querySelector('[data-report-theme-toggle]');
const reportLogo=document.querySelector('[data-report-logo]');
function applyReportTheme(theme){const normalized=theme==='dark'?'dark':'light';document.body.setAttribute('data-theme',normalized);if(reportLogo){const lightLogo=reportLogo.dataset.logoLight||reportLogo.getAttribute('src');const darkLogo=reportLogo.dataset.logoDark||reportLogo.getAttribute('src');reportLogo.setAttribute('src',normalized==='dark'?darkLogo:lightLogo);}if(reportThemeToggle){const darkActive=normalized==='dark';const nextLabel=darkActive?'light':'dark';reportThemeToggle.innerHTML=darkActive?'&#x2600;':'&#x263E;';reportThemeToggle.setAttribute('aria-pressed',darkActive?'true':'false');reportThemeToggle.setAttribute('aria-label','Switch to '+nextLabel+' theme');reportThemeToggle.setAttribute('title','Switch to '+nextLabel+' theme');}}
function show(id){btns.forEach(b=>b.classList.toggle('active',b.dataset.tab===id));tabSections.forEach(t=>t.classList.toggle('active',t.id===id));}
function formatMetric(v){if(!Number.isFinite(v))return '0';return Math.abs(v)>=100?v.toFixed(0):v.toFixed(2);}
function setupCanvas(canvas){const dpr=window.devicePixelRatio||1;const w=Math.max(320,canvas.clientWidth||320);const h=Math.max(220,canvas.clientHeight||220);canvas.width=Math.floor(w*dpr);canvas.height=Math.floor(h*dpr);const ctx=canvas.getContext('2d');ctx.setTransform(dpr,0,0,dpr,0,0);return {ctx,w,h};}
function drawNoData(ctx,w,h,msg){ctx.fillStyle='#9fb0c3';ctx.font='13px Segoe UI';ctx.textAlign='center';ctx.fillText(msg,w/2,h/2);}
function drawBar(canvasId,points){const canvas=document.getElementById(canvasId);if(!canvas)return;const c=setupCanvas(canvas);const ctx=c.ctx,w=c.w,h=c.h;ctx.clearRect(0,0,w,h);if(!points||points.length===0){drawNoData(ctx,w,h,'No data');return;}const left=46,right=14,top=16,bottom=62;const pw=w-left-right;const ph=h-top-bottom;const max=Math.max(...points.map(p=>p.value),1);ctx.strokeStyle='#334155';ctx.lineWidth=1;for(let i=0;i<=4;i++){const y=top+(ph*(i/4));ctx.beginPath();ctx.moveTo(left,y);ctx.lineTo(w-right,y);ctx.stroke();}const slot=pw/points.length;const bar=Math.max(8,slot*0.58);ctx.font='11px Segoe UI';for(let i=0;i<points.length;i++){const p=points[i];const x=left+i*slot+(slot-bar)/2;const bh=(p.value/max)*ph;const y=top+ph-bh;ctx.fillStyle=p.color||'#3b82f6';ctx.fillRect(x,y,bar,bh);ctx.fillStyle='#dbe6f4';ctx.textAlign='center';ctx.fillText(formatMetric(p.value),x+bar/2,Math.max(12,y-4));ctx.save();ctx.translate(x+bar/2,h-bottom+14);ctx.rotate(-0.6);ctx.fillStyle='#b5c2d3';ctx.fillText((p.label||'').slice(0,26),0,0);ctx.restore();}ctx.fillStyle='#b5c2d3';ctx.textAlign='right';for(let i=0;i<=4;i++){const value=max*(1-i/4);const y=top+(ph*(i/4))+4;ctx.fillText(formatMetric(value),left-6,y);}}
function drawPie(canvasId,points){const canvas=document.getElementById(canvasId);if(!canvas)return;const c=setupCanvas(canvas);const ctx=c.ctx,w=c.w,h=c.h;ctx.clearRect(0,0,w,h);if(!points||points.length===0){drawNoData(ctx,w,h,'No data');return;}const total=points.reduce((s,p)=>s+(p.value||0),0);if(total<=0){drawNoData(ctx,w,h,'No data');return;}const cx=w*0.35,cy=h*0.5,r=Math.min(w,h)*0.28;let angle=-Math.PI/2;for(const p of points){const val=Math.max(0,p.value||0);const delta=(val/total)*Math.PI*2;ctx.beginPath();ctx.moveTo(cx,cy);ctx.arc(cx,cy,r,angle,angle+delta);ctx.closePath();ctx.fillStyle=p.color||'#3b82f6';ctx.fill();angle+=delta;}ctx.fillStyle='#0f172a';ctx.beginPath();ctx.arc(cx,cy,r*0.54,0,Math.PI*2);ctx.fill();ctx.fillStyle='#e5eefc';ctx.font='bold 18px Segoe UI';ctx.textAlign='center';ctx.fillText(total.toString(),cx,cy+6);ctx.font='12px Segoe UI';ctx.fillStyle='#9fb0c3';ctx.fillText('requests',cx,cy+24);ctx.textAlign='left';let y=cy-r+10;for(const p of points){ctx.fillStyle=p.color||'#3b82f6';ctx.fillRect(w*0.64,y-10,12,12);ctx.fillStyle='#e6edf3';ctx.font='12px Segoe UI';const pct=total<=0?0:((p.value/total)*100);ctx.fillText(`${p.label}: ${p.value} (${pct.toFixed(1)}%)`,w*0.64+18,y);y+=20;}}
function drawLatencyLine(canvasRef,chart){const canvas=typeof canvasRef==='string'?document.getElementById(canvasRef):canvasRef;if(!canvas)return;const c=setupCanvas(canvas);const ctx=c.ctx,w=c.w,h=c.h;ctx.clearRect(0,0,w,h);if(!chart||!Array.isArray(chart.labels)||chart.labels.length===0||!Array.isArray(chart.series)||chart.series.length===0){drawNoData(ctx,w,h,'No latency data');return;}const labels=chart.labels;const seriesList=chart.series;const allValues=seriesList.flatMap(s=>(s.values||[]).filter(v=>Number.isFinite(v)));if(allValues.length===0){drawNoData(ctx,w,h,'No latency data');return;}const shortAxisLabels=labels.every(label=>((label||'').toString().length<=4));const rotateAxisLabels=!shortAxisLabels&&labels.length>4;const left=52,right=18,bottom=rotateAxisLabels?78:52;const legendItemWidth=150,legendLineHeight=14,legendTop=12;const plotWidth=Math.max(120,w-left-right);const legendCols=Math.max(1,Math.floor(plotWidth/legendItemWidth));const legendRows=Math.max(1,Math.ceil(seriesList.length/legendCols));const legendHeight=legendRows*legendLineHeight;const top=legendTop+legendHeight+16;const pw=w-left-right;const ph=h-top-bottom;if(ph<=20){drawNoData(ctx,w,h,'No latency data');return;}const max=Math.max(...allValues,1);const scaleMax=max*1.08;ctx.strokeStyle='#334155';ctx.lineWidth=1;for(let i=0;i<=4;i++){const y=top+(ph*(i/4));ctx.beginPath();ctx.moveTo(left,y);ctx.lineTo(w-right,y);ctx.stroke();}ctx.fillStyle='#b5c2d3';ctx.font='11px Segoe UI';ctx.textAlign='right';for(let i=0;i<=4;i++){const value=max*(1-i/4);const y=top+(ph*(i/4))+4;ctx.fillText(formatMetric(value),left-6,y);}const xStep=labels.length<=1?0:pw/(labels.length-1);const xAt=i=>labels.length<=1?left+(pw/2):left+(xStep*i);const overlapOffset=new Map();const epsilon=Math.max(max*0.0005,0.001);for(let pointIndex=0;pointIndex<labels.length;pointIndex++){const points=[];for(let seriesIndex=0;seriesIndex<seriesList.length;seriesIndex++){const value=(seriesList[seriesIndex].values||[])[pointIndex];if(Number.isFinite(value)){points.push({seriesIndex,value});}}points.sort((a,b)=>a.value===b.value?a.seriesIndex-b.seriesIndex:a.value-b.value);let start=0;while(start<points.length){let end=start+1;while(end<points.length&&Math.abs(points[end].value-points[start].value)<=epsilon){end++;}const count=end-start;if(count>1){const mid=(count-1)/2;for(let k=0;k<count;k++){overlapOffset.set(points[start+k].seriesIndex+'|'+pointIndex,(k-mid)*3);}}start=end;}}const dashPatterns=[[0,0],[7,4],[2,3],[10,3,2,3]];for(let seriesIndex=0;seriesIndex<seriesList.length;seriesIndex++){const series=seriesList[seriesIndex];ctx.beginPath();ctx.strokeStyle=series.color||'#38bdf8';ctx.lineWidth=2.2;const dash=dashPatterns[seriesIndex%dashPatterns.length];if(dash[0]===0){ctx.setLineDash([]);}else{ctx.setLineDash(dash);}let started=false;(series.values||[]).forEach((value,index)=>{if(!Number.isFinite(value)){started=false;return;}const x=xAt(index);const offset=overlapOffset.get(seriesIndex+'|'+index)||0;const y=top+ph-((value/scaleMax)*ph)+offset;if(!started){ctx.moveTo(x,y);started=true;}else{ctx.lineTo(x,y);}});ctx.stroke();ctx.setLineDash([]);(series.values||[]).forEach((value,index)=>{if(!Number.isFinite(value))return;const x=xAt(index);const offset=overlapOffset.get(seriesIndex+'|'+index)||0;const y=top+ph-((value/scaleMax)*ph)+offset;ctx.beginPath();ctx.fillStyle='#0f172a';ctx.arc(x,y,3.2,0,Math.PI*2);ctx.fill();ctx.beginPath();ctx.strokeStyle=series.color||'#38bdf8';ctx.lineWidth=2;ctx.arc(x,y,3.2,0,Math.PI*2);ctx.stroke();});}ctx.fillStyle='#b5c2d3';ctx.font='10px Segoe UI';ctx.textAlign='center';labels.forEach((label,index)=>{const x=xAt(index);const text=(label||'').toString().slice(0,34);if(rotateAxisLabels){ctx.save();ctx.translate(x,h-bottom+12);ctx.rotate(-0.6);ctx.fillText(text,0,0);ctx.restore();}else{ctx.fillText(text,x,h-bottom+16);}});let lx=left,ly=legendTop+2;for(let seriesIndex=0;seriesIndex<seriesList.length;seriesIndex++){const series=seriesList[seriesIndex];const rawName=(series.name||'Series').toString();const legendName=rawName.length>30?rawName.slice(0,27)+'...':rawName;ctx.strokeStyle=series.color||'#38bdf8';ctx.lineWidth=2.2;const dash=dashPatterns[seriesIndex%dashPatterns.length];if(dash[0]===0){ctx.setLineDash([]);}else{ctx.setLineDash(dash);}ctx.beginPath();ctx.moveTo(lx,ly+1.5);ctx.lineTo(lx+12,ly+1.5);ctx.stroke();ctx.setLineDash([]);ctx.fillStyle='#b5c2d3';ctx.font='11px Segoe UI';ctx.textAlign='left';ctx.fillText(legendName,lx+16,ly+4);lx+=legendItemWidth;if(lx>w-right-legendItemWidth){lx=left;ly+=legendLineHeight;}}}
function renderCharts(){drawPie('chart-outcome',reportCharts.overallOutcome);drawBar('chart-scenario-requests',reportCharts.scenarioRequests);drawBar('chart-scenario-p95',reportCharts.scenarioP95Latency);drawBar('chart-scenario-rps',reportCharts.scenarioRps);drawBar('chart-scenario-fail-rate',reportCharts.scenarioFailRate);drawBar('chart-scenario-bytes',reportCharts.scenarioBytes);drawPie('chart-status-code-classes',reportCharts.statusCodeClasses);drawLatencyLine('chart-scenario-latency-lines',reportCharts.scenarioLatencyTrend);}
function getGroupedCorrelationChart(key){const node=document.querySelector('script[type="application/json"][data-grouped-correlation-chart="'+key+'"]');if(!node)return {labels:[],series:[]};try{return JSON.parse(node.textContent||'{"labels":[],"series":[]}');}catch{return {labels:[],series:[]};}}
function getUngroupedCorrelationChart(key){const node=document.querySelector('script[type="application/json"][data-ungrouped-correlation="'+key+'"]');if(!node)return {labels:[],series:[]};try{return JSON.parse(node.textContent||'{"labels":[],"series":[]}');}catch{return {labels:[],series:[]};}}
function normalizeUngroupedCorrelationChart(chart){if(!chart||!Array.isArray(chart.labels)||!Array.isArray(chart.series))return {labels:[],series:[]};const compactName=input=>{const raw=(input||'Series').toString();const parts=raw.split('|').map(x=>x.trim()).filter(x=>x.length>0);const tail=parts.length>0?parts[parts.length-1]:raw.trim();if(tail.length===0)return 'Series';return tail.length>22?tail.slice(0,19)+'...':tail;};const labels=chart.labels||[];const series=chart.series||[];const normalizedSeries=series.map((item,index)=>({name:compactName(item&&item.name),color:(item&&item.color)||linePalette[index%linePalette.length],values:Array.isArray(item&&item.values)?item.values.map(v=>Number.isFinite(v)?v:NaN):[]})).filter(s=>s.values.some(v=>Number.isFinite(v)));const isPercentile=value=>/^p\\d+$/i.test((value||'').toString().trim());const labelsArePercentiles=labels.length>0&&labels.every(isPercentile);if(labelsArePercentiles){return {labels,series:normalizedSeries};}const seriesArePercentiles=normalizedSeries.length>0&&normalizedSeries.every(s=>isPercentile(s.name));if(!seriesArePercentiles||labels.length===0){return {labels,series:normalizedSeries};}const percentileLabels=normalizedSeries.map(s=>s.name.toUpperCase());const reshaped=labels.map((label,labelIndex)=>{const values=normalizedSeries.map(s=>{const value=s.values[labelIndex];return Number.isFinite(value)?value:NaN;});return {name:compactName(label||('Series '+(labelIndex+1))),color:linePalette[labelIndex%linePalette.length],values};}).filter(s=>s.values.some(v=>Number.isFinite(v)));if(reshaped.length===0){return {labels:percentileLabels,series:[]};}return {labels:percentileLabels,series:reshaped};}
function renderGroupedCorrelationCharts(){const canvases=[...document.querySelectorAll('.grouped-correlation-canvas')];if(canvases.length===0)return;canvases.forEach(canvas=>{const key=canvas.dataset.groupedKey||'';const chart=getGroupedCorrelationChart(key);drawLatencyLine(canvas,chart);});}
function renderUngroupedCorrelationCharts(){const canvases=[...document.querySelectorAll('.ungrouped-correlation-canvas')];if(canvases.length===0)return;canvases.forEach(canvas=>{const key=canvas.dataset.ungroupedKey||'';const rawChart=getUngroupedCorrelationChart(key);const chart=normalizeUngroupedCorrelationChart(rawChart);drawLatencyLine(canvas,chart);});}
function initPanePan(){if(!tabsPane)return;let activePointerId=null;let startY=0;let startScroll=0;tabsPane.addEventListener('pointerdown',event=>{if(event.button!==0)return;if(event.target&&event.target.closest&&event.target.closest('button,a,input,textarea,select,label'))return;activePointerId=event.pointerId;startY=event.clientY;startScroll=tabsPane.scrollTop;tabsPane.classList.add('panning');tabsPane.setPointerCapture(event.pointerId);});tabsPane.addEventListener('pointermove',event=>{if(activePointerId!==event.pointerId)return;const delta=event.clientY-startY;tabsPane.scrollTop=startScroll-delta;});const stopPan=event=>{if(activePointerId!==event.pointerId)return;activePointerId=null;tabsPane.classList.remove('panning');};tabsPane.addEventListener('pointerup',stopPan);tabsPane.addEventListener('pointercancel',stopPan);tabsPane.addEventListener('lostpointercapture',()=>{activePointerId=null;tabsPane.classList.remove('panning');});}
function renderAllCharts(){renderCharts();renderUngroupedCorrelationCharts();renderGroupedCorrelationCharts();}
const storedReportTheme=(()=>{try{return localStorage.getItem(reportThemeKey);}catch{return null;}})();
applyReportTheme(storedReportTheme==='dark'?'dark':'light');
if(reportThemeToggle){reportThemeToggle.addEventListener('click',()=>{const next=document.body.getAttribute('data-theme')==='dark'?'light':'dark';applyReportTheme(next);try{localStorage.setItem(reportThemeKey,next);}catch{}renderAllCharts();});}
btns.forEach(b=>b.addEventListener('click',()=>show(b.dataset.tab)));
if(btns.length>0){show(btns[0].dataset.tab);}renderAllCharts();initPanePan();window.addEventListener('resize',renderAllCharts);
</script>
</body>
</html>
"""
    template = template.replace("\n", os.linesep)
    return template.replace("__LOGO_LIGHT__", _escape_html(_get_report_logo_light_data_uri())).replace("__LOGO_DARK__", _escape_html(_get_report_logo_dark_data_uri())).replace("__TEST_SUITE__", _escape_html(node_stats.test_info.test_suite)).replace("__TEST_NAME__", _escape_html(node_stats.test_info.test_name)).replace("__SESSION_ID__", _escape_html(node_stats.test_info.session_id)).replace("__DURATION__", _escape_html(_format_dotnet_timedelta(node_stats._value("duration", "durationMs")))).replace("__BUTTONS__", buttons_html).replace("__SECTIONS__", sections_html).replace("__CHART_DATA__", chart_data_json)


def _as_int(value: Any) -> int:
    if isinstance(value, bool):
        return int(value)
    if isinstance(value, (int, float)):
        return int(value)
    try:
        return int(str(value))
    except (TypeError, ValueError):
        return 0


def _as_float(value: Any) -> float:
    if isinstance(value, bool):
        return float(value)
    if isinstance(value, (int, float)):
        return float(value)
    try:
        return float(str(value))
    except (TypeError, ValueError):
        return 0.0


def _generate_session_id() -> str:
    return f"{time.time_ns():032x}"[-32:]


def _as_bool(value: Any, default: bool = False) -> bool:
    if isinstance(value, bool):
        return value
    if isinstance(value, (int, float)):
        return bool(value)
    if isinstance(value, str):
        normalized = value.strip().lower()
        if normalized in {"1", "true", "yes", "y", "on"}:
            return True
        if normalized in {"0", "false", "no", "n", "off"}:
            return False
    return default


def _normalize_string_list(value: Any) -> List[str]:
    if isinstance(value, list):
        raw = value
    elif isinstance(value, tuple):
        raw = list(value)
    elif isinstance(value, set):
        raw = list(value)
    elif isinstance(value, str):
        raw = value.split(",")
    else:
        return []

    normalized: List[str] = []
    seen: set[str] = set()
    for item in raw:
        text = str(item or "").strip()
        if not text:
            continue
        key = text.lower()
        if key in seen:
            continue
        seen.add(key)
        normalized.append(text)
    return normalized


def _is_non_empty_string(value: Any) -> bool:
    return bool(str(value or "").strip())


def _try_parse_cli_bool(value: str) -> Optional[bool]:
    normalized = str(value or "").strip().lower()
    if normalized == "true":
        return True
    if normalized == "false":
        return False
    return None


def _try_parse_positive_int(value: str) -> Optional[int]:
    try:
        parsed = int(str(value or "").strip())
    except (TypeError, ValueError):
        return None
    return parsed if parsed > 0 else None


def _try_parse_non_negative_int(value: str) -> Optional[int]:
    try:
        parsed = int(str(value or "").strip())
    except (TypeError, ValueError):
        return None
    return parsed if parsed >= 0 else None


def _split_cli_list(value: str) -> List[str]:
    parts = [part.strip() for part in str(value or "").split(",")]
    normalized: List[str] = []
    seen: set[str] = set()
    for part in parts:
        if not part or part in seen:
            continue
        seen.add(part)
        normalized.append(part)
    return normalized


def _parse_cli_report_formats(value: str) -> List[str]:
    normalized: List[str] = []
    seen: set[str] = set()
    for part in _split_cli_list(value):
        lowered = part.lower()
        if lowered == "markdown":
            lowered = "md"
        if lowered not in {"txt", "html", "csv", "md"} or lowered in seen:
            continue
        seen.add(lowered)
        normalized.append(lowered)
    return normalized


def _parse_cli_node_type(value: str) -> Optional[str]:
    normalized = str(value or "").strip().lower()
    if normalized in {"single", "singlenode", "0"}:
        return "SingleNode"
    if normalized in {"coordinator", "1"}:
        return "Coordinator"
    if normalized in {"agent", "2"}:
        return "Agent"
    return None

def _parse_cli_log_level(value: str) -> Optional[str]:
    normalized = str(value or "").strip().lower()
    mapping = {
        "0": "Verbose",
        "verbose": "Verbose",
        "1": "Debug",
        "debug": "Debug",
        "2": "Information",
        "information": "Information",
        "info": "Information",
        "3": "Warning",
        "warning": "Warning",
        "warn": "Warning",
        "4": "Error",
        "error": "Error",
        "5": "Fatal",
        "fatal": "Fatal",
        "critical": "Fatal",
    }
    return mapping.get(normalized)
