from __future__ import annotations

import time
import uuid
from concurrent.futures import ThreadPoolExecutor, TimeoutError
from dataclasses import dataclass
from typing import Any, Callable, Dict, List, Optional

from .transports import EndpointAdapterFactory, EndpointDefinition


@dataclass
class ClusterScenarioDispatch:
    scenario_names: List[str]


@dataclass
class ClusterNodeResult:
    node_id: str
    success: bool
    all_request_count: int
    all_ok_count: int
    all_fail_count: int
    error: str = ""
    details: Optional[Dict[str, Any]] = None


@dataclass
class ClusterAgent:
    node_id: str
    execute: Callable[[ClusterScenarioDispatch], ClusterNodeResult]


class LocalClusterCoordinator:
    def __init__(self, command_timeout_ms: int = 120_000, retry_count: int = 0) -> None:
        self._command_timeout_ms = max(int(command_timeout_ms), 1)
        self._retry_count = max(int(retry_count), 0)

    def dispatch(
        self,
        agents: List[ClusterAgent],
        scenario_names: List[str],
        assignment_options: Optional[Dict[str, Any]] = None,
    ) -> Dict[str, object]:
        assignment_options = dict(assignment_options or {})
        retry_count = max(
            int(_pick_option(assignment_options, "retry_count", "retryCount", default=self._retry_count)),
            0,
        )
        assignments = plan_agent_scenario_assignments(
            scenario_names=scenario_names,
            agent_count=len(agents),
            options=assignment_options,
        )
        timeout_seconds = self._command_timeout_ms / 1000.0
        node_results: List[ClusterNodeResult] = []
        for index, agent in enumerate(agents):
            dispatch = ClusterScenarioDispatch(scenario_names=list(assignments[index] if index < len(assignments) else []))
            node_results.append(
                self._execute_with_retry(
                    agent=agent,
                    dispatch=dispatch,
                    timeout_seconds=timeout_seconds,
                    retry_count=retry_count,
                )
            )

        return {
            "nodeResults": [self._to_row(x) for x in node_results],
            "allRequestCount": sum(x.all_request_count for x in node_results),
            "allOkCount": sum(x.all_ok_count for x in node_results),
            "allFailCount": sum(x.all_fail_count for x in node_results),
            "failedNodes": sum(1 for x in node_results if not x.success),
        }

    @staticmethod
    def _execute_with_retry(
        *,
        agent: ClusterAgent,
        dispatch: ClusterScenarioDispatch,
        timeout_seconds: float,
        retry_count: int,
    ) -> ClusterNodeResult:
        last = ClusterNodeResult(
            node_id=agent.node_id,
            success=False,
            all_request_count=0,
            all_ok_count=0,
            all_fail_count=0,
            error="agent did not execute",
        )
        for _attempt in range(retry_count + 1):
            with ThreadPoolExecutor(max_workers=1) as executor:
                future = executor.submit(agent.execute, dispatch)
                try:
                    result = future.result(timeout=timeout_seconds)
                    if bool(getattr(result, "success", False)):
                        return result
                    last = ClusterNodeResult(
                        node_id=agent.node_id,
                        success=False,
                        all_request_count=int(getattr(result, "all_request_count", 0)),
                        all_ok_count=int(getattr(result, "all_ok_count", 0)),
                        all_fail_count=int(getattr(result, "all_fail_count", 0)),
                        error=str(getattr(result, "error", "agent execution failed")),
                        details=(
                            dict(getattr(result, "details"))
                            if isinstance(getattr(result, "details", None), dict)
                            else None
                        ),
                    )
                except TimeoutError:
                    last = ClusterNodeResult(
                        node_id=agent.node_id,
                        success=False,
                        all_request_count=0,
                        all_ok_count=0,
                        all_fail_count=0,
                        error=f"node timed out after {int(timeout_seconds * 1000)}ms",
                    )
                except Exception as error:  # noqa: BLE001
                    last = ClusterNodeResult(
                        node_id=agent.node_id,
                        success=False,
                        all_request_count=0,
                        all_ok_count=0,
                        all_fail_count=0,
                        error=str(error),
                    )
        return last

    @staticmethod
    def _to_row(result: ClusterNodeResult) -> Dict[str, object]:
        return {
            "nodeId": result.node_id,
            "success": result.success,
            "allRequestCount": result.all_request_count,
            "allOkCount": result.all_ok_count,
            "allFailCount": result.all_fail_count,
            "error": result.error,
            "details": (
                dict(getattr(result, "details"))
                if isinstance(getattr(result, "details", None), dict)
                else None
            ),
        }


class DistributedClusterCoordinator:
    def __init__(
        self,
        *,
        cluster_id: str,
        session_id: str,
        test_suite: str,
        test_name: str,
        expected_agent_results: int,
        agent_group: str = "default",
        command_timeout_ms: int = 120_000,
        nats_options: Optional[Dict[str, Any]] = None,
    ) -> None:
        self._cluster_id = cluster_id
        self._session_id = session_id
        self._test_suite = test_suite
        self._test_name = test_name
        self._expected_agent_results = max(int(expected_agent_results), 0)
        self._agent_group = agent_group
        self._command_timeout_ms = max(int(command_timeout_ms), 1)
        self._nats_options = dict(nats_options or {})

    def dispatch(self, assignments: List[List[str]]) -> Dict[str, object]:
        run_subject = self._build_run_subject()
        reply_subject = self._build_reply_subject()

        command_producer = EndpointAdapterFactory.create(
            self._nats_endpoint(mode="Produce", name="coordinator-command", subject=run_subject)
        )
        result_consumer = EndpointAdapterFactory.create(
            self._nats_endpoint(mode="Consume", name="coordinator-result", subject=reply_subject)
        )
        try:
            # Prime the reply consumer before publishing commands because NATS subjects do not retain replies.
            result_consumer.consume()

            for index, scenarios in enumerate(assignments):
                command_id = uuid.uuid4().hex
                command = {
                    "commandId": command_id,
                    "sessionId": self._session_id,
                    "testSuite": self._test_suite,
                    "testName": self._test_name,
                    "agentIndex": index,
                    "agentCount": self._expected_agent_results,
                    "targetScenarios": list(scenarios),
                    "replySubject": reply_subject,
                }
                command_producer.produce(
                    {
                        "headers": {
                            "x-cluster-command-id": command_id,
                            "x-cluster-reply-subject": reply_subject,
                        },
                        "body": command,
                    }
                )

            by_command: Dict[str, Dict[str, Any]] = {}
            deadline = _now_ms() + self._command_timeout_ms
            while len(by_command) < self._expected_agent_results and _now_ms() < deadline:
                payload = result_consumer.consume()
                if not isinstance(payload, dict):
                    _sleep_ms(5)
                    continue

                body = payload.get("body")
                if not isinstance(body, dict):
                    _sleep_ms(5)
                    continue

                result = _parse_run_result(body)
                command_id = result.get("commandId", "")
                if command_id:
                    by_command[command_id] = result

            node_rows = [_convert_run_result(row) for row in by_command.values()]
            all_request_count = sum(int(x["allRequestCount"]) for x in node_rows)
            all_ok_count = sum(int(x["allOkCount"]) for x in node_rows)
            all_fail_count = sum(int(x["allFailCount"]) for x in node_rows)
            missing_nodes = max(self._expected_agent_results - len(node_rows), 0)
            failed_nodes = sum(1 for x in node_rows if not bool(x["success"])) + missing_nodes

            return {
                "nodeResults": node_rows,
                "allRequestCount": all_request_count,
                "allOkCount": all_ok_count,
                "allFailCount": all_fail_count,
                "failedNodes": failed_nodes,
                "missingNodes": missing_nodes,
                "runSubject": run_subject,
                "replySubject": reply_subject,
            }
        finally:
            _dispose_adapter(result_consumer)
            _dispose_adapter(command_producer)

    def _nats_endpoint(self, *, mode: str, name: str, subject: str) -> EndpointDefinition:
        nats = dict(self._nats_options)
        nats["Subject"] = subject
        nats["StartFromEarliest"] = True
        return EndpointDefinition(
            kind="Nats",
            mode=mode,
            name=name,
            tracking_field="header:x-cluster-command-id",
            nats=nats,
        )

    def _build_run_subject(self) -> str:
        return f"loadstrike.{_sanitize_token(self._cluster_id)}.{_sanitize_token(self._agent_group)}.run"

    def _build_reply_subject(self) -> str:
        return (
            f"loadstrike.{_sanitize_token(self._cluster_id)}."
            f"{_sanitize_token(self._session_id)}.reply.{uuid.uuid4().hex}"
        )


class DistributedClusterAgent:
    def __init__(
        self,
        *,
        cluster_id: str,
        session_id: str,
        agent_id: str,
        agent_group: str = "default",
        nats_options: Optional[Dict[str, Any]] = None,
    ) -> None:
        self._cluster_id = cluster_id
        self._session_id = session_id
        self._agent_id = agent_id
        self._agent_group = agent_group
        self._nats_options = dict(nats_options or {})
        self._command_consumer: Optional[Any] = None

    def dispose(self) -> None:
        _dispose_adapter(self._command_consumer)
        self._command_consumer = None

    def poll_and_execute_once(
        self,
        execute: Callable[[ClusterScenarioDispatch], ClusterNodeResult],
    ) -> bool:
        command_consumer = self._ensure_command_consumer()
        payload = command_consumer.consume()
        if not isinstance(payload, dict):
            return False

        body = payload.get("body")
        if not isinstance(body, dict):
            return False

        command = _parse_run_command(body)
        command_id = str(command.get("commandId", "")).strip()
        if not command_id:
            return False

        headers = payload.get("headers", {})
        reply_subject = ""
        if isinstance(headers, dict):
            reply_subject = str(headers.get("x-cluster-reply-subject", "")).strip()
        if not reply_subject:
            reply_subject = str(command.get("replySubject", "")).strip()

        result_payload: Dict[str, Any]
        try:
            execution_result = execute(
                ClusterScenarioDispatch(scenario_names=list(command.get("targetScenarios", [])))
            )
            result_payload = {
                "commandId": command_id,
                "agentId": self._agent_id,
                "isSuccess": bool(execution_result.success),
                "errorMessage": execution_result.error,
                "stats": {
                    "allRequestCount": int(execution_result.all_request_count),
                    "allOkCount": int(execution_result.all_ok_count),
                    "allFailCount": int(execution_result.all_fail_count),
                },
                "details": (
                    dict(execution_result.details)
                    if isinstance(getattr(execution_result, "details", None), dict)
                    else None
                ),
            }
        except Exception as error:  # noqa: BLE001
            result_payload = {
                "commandId": command_id,
                "agentId": self._agent_id,
                "isSuccess": False,
                "errorMessage": str(error),
            }

        if reply_subject:
            produce_options = dict(self._nats_options)
            produce_options["Subject"] = reply_subject
            result_producer = EndpointAdapterFactory.create(
                EndpointDefinition(
                    kind="Nats",
                    mode="Produce",
                    name=f"agent-{self._agent_id}-result",
                    tracking_field="header:x-cluster-command-id",
                    nats=produce_options,
                )
            )
            try:
                result_producer.produce(
                    {
                        "headers": {"x-cluster-command-id": command_id},
                        "body": result_payload,
                    }
                )
            finally:
                _dispose_adapter(result_producer)

        return True

    def _ensure_command_consumer(self) -> Any:
        if self._command_consumer is not None:
            return self._command_consumer

        run_subject = f"loadstrike.{_sanitize_token(self._cluster_id)}.{_sanitize_token(self._agent_group)}.run"
        queue_group = (
            f"loadstrike.{_sanitize_token(self._cluster_id)}.{_sanitize_token(self._agent_group)}.agents"
        )
        consume_options = dict(self._nats_options)
        consume_options["Subject"] = run_subject
        consume_options["QueueGroup"] = queue_group
        consume_options["StartFromEarliest"] = True
        self._command_consumer = EndpointAdapterFactory.create(
            EndpointDefinition(
                kind="Nats",
                mode="Consume",
                name=f"agent-{self._agent_id}",
                tracking_field="header:x-cluster-command-id",
                nats=consume_options,
            )
        )
        return self._command_consumer


def plan_agent_scenario_assignments(
    *,
    scenario_names: List[str],
    agent_count: int,
    options: Optional[Dict[str, Any]] = None,
) -> List[List[str]]:
    options = dict(options or {})
    total_agents = max(int(agent_count), 0)
    assignments: List[List[str]] = [[] for _ in range(total_agents)]
    if total_agents == 0:
        return assignments

    explicit = _pick_option(options, "explicit_assignments", "explicitAssignments")
    if isinstance(explicit, list) and explicit:
        for index in range(total_agents):
            value = explicit[index] if index < len(explicit) else []
            assignments[index] = [str(x) for x in value] if isinstance(value, list) else []
        return assignments

    selected_names = _pick_option(options, "selected_scenario_names", "selectedScenarioNames")
    selected = (
        {str(x) for x in selected_names}
        if isinstance(selected_names, list) and selected_names
        else {str(x) for x in scenario_names}
    )
    ordered = [str(name) for name in scenario_names if str(name) in selected]
    if not ordered:
        return assignments

    raw_weights = _pick_option(options, "agent_weights", "agentWeights")
    weights: List[int] = []
    for index in range(total_agents):
        value = raw_weights[index] if isinstance(raw_weights, list) and index < len(raw_weights) else 1
        try:
            parsed = int(value)
        except (TypeError, ValueError):
            parsed = 1
        weights.append(max(parsed, 1))
    weighted_cycle = [index for index, weight in enumerate(weights) for _ in range(weight)] or [0]

    raw_targets = _pick_option(options, "agent_targets", "agentTargets")
    targets: List[Optional[set[str]]] = []
    for index in range(total_agents):
        if isinstance(raw_targets, list) and index < len(raw_targets) and isinstance(raw_targets[index], list):
            targets.append({str(x) for x in raw_targets[index]})
        else:
            targets.append(None)

    cycle_index = 0
    for scenario in ordered:
        eligible = [i for i in range(total_agents) if targets[i] is None or scenario in targets[i]]
        if not eligible:
            continue

        selected_agent = eligible[0]
        for attempt in range(len(weighted_cycle)):
            candidate = weighted_cycle[(cycle_index + attempt) % len(weighted_cycle)]
            if candidate in eligible:
                selected_agent = candidate
                cycle_index = (cycle_index + attempt + 1) % len(weighted_cycle)
                break

        assignments[selected_agent].append(scenario)

    return assignments


def _parse_run_command(value: Dict[str, Any]) -> Dict[str, Any]:
    target_scenarios = value.get("targetScenarios")
    if not isinstance(target_scenarios, list):
        target_scenarios = value.get("TargetScenarios")
    if not isinstance(target_scenarios, list):
        target_scenarios = []

    return {
        "commandId": str(value.get("commandId") or value.get("CommandId") or ""),
        "sessionId": str(value.get("sessionId") or value.get("SessionId") or ""),
        "testSuite": str(value.get("testSuite") or value.get("TestSuite") or ""),
        "testName": str(value.get("testName") or value.get("TestName") or ""),
        "agentIndex": int(value.get("agentIndex") or value.get("AgentIndex") or 0),
        "agentCount": int(value.get("agentCount") or value.get("AgentCount") or 0),
        "targetScenarios": [str(x) for x in target_scenarios],
        "replySubject": str(value.get("replySubject") or value.get("ReplySubject") or ""),
    }


def _parse_run_result(value: Dict[str, Any]) -> Dict[str, Any]:
    stats = value.get("stats")
    if not isinstance(stats, dict):
        stats = value.get("Stats")
    if not isinstance(stats, dict):
        stats = {}

    return {
        "commandId": str(value.get("commandId") or value.get("CommandId") or ""),
        "agentId": str(value.get("agentId") or value.get("AgentId") or ""),
        "isSuccess": bool(value.get("isSuccess") if "isSuccess" in value else value.get("IsSuccess", False)),
        "errorMessage": str(value.get("errorMessage") or value.get("ErrorMessage") or ""),
        "stats": {
            "allRequestCount": int(stats.get("allRequestCount") or stats.get("AllRequestCount") or 0),
            "allOkCount": int(stats.get("allOkCount") or stats.get("AllOkCount") or 0),
            "allFailCount": int(stats.get("allFailCount") or stats.get("AllFailCount") or 0),
        }
        if stats
        else None,
        "details": dict(value.get("details")) if isinstance(value.get("details"), dict) else (
            dict(value.get("Details")) if isinstance(value.get("Details"), dict) else None
        ),
    }


def _convert_run_result(value: Dict[str, Any]) -> Dict[str, Any]:
    stats = value.get("stats") if isinstance(value.get("stats"), dict) else {}
    return {
        "nodeId": str(value.get("agentId") or "unknown-agent"),
        "success": bool(value.get("isSuccess", False)),
        "allRequestCount": int(stats.get("allRequestCount", 0)),
        "allOkCount": int(stats.get("allOkCount", 0)),
        "allFailCount": int(stats.get("allFailCount", 0)),
        "error": str(value.get("errorMessage") or ""),
        "details": dict(value.get("details")) if isinstance(value.get("details"), dict) else None,
    }


def _sanitize_token(value: str) -> str:
    if not value or not value.strip():
        return "default"
    return "".join(ch if ch.isalnum() or ch in {"-", "_"} else "_" for ch in value.strip())


def _sleep_ms(value: int) -> None:
    time.sleep(max(int(value), 1) / 1000.0)


def _now_ms() -> int:
    return int(time.time() * 1000)


def _dispose_adapter(adapter: Any) -> None:
    dispose = getattr(adapter, "dispose", None)
    if callable(dispose):
        try:
            dispose()
        except Exception:  # noqa: BLE001
            return


def _pick_option(source: Dict[str, Any], *keys: str, default: Any = None) -> Any:
    for key in keys:
        if key in source and source[key] is not None:
            return source[key]
    return default
