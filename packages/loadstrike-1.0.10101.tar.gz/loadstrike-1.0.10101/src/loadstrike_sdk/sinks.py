from __future__ import annotations

import base64
import copy
import json
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Any, Callable, Dict, List, Optional, Protocol
from urllib.error import HTTPError, URLError
from urllib.request import Request, urlopen


class ReportingSink(Protocol):
    @property
    def sink_name(self) -> str:
        ...

    @property
    def SinkName(self) -> str:
        ...

    def init(self, session: Dict[str, Any]) -> None:
        ...

    def start(self, session: Dict[str, Any]) -> None:
        ...

    def save_realtime_stats(self, scenario_stats: List[Dict[str, Any]]) -> None:
        ...

    def save_realtime_metrics(self, metrics: List[Dict[str, Any]]) -> None:
        ...

    def save_final_stats(self, result: Dict[str, Any]) -> None:
        ...

    def save_run_result(self, result: Dict[str, Any]) -> None:
        ...

    def stop(self) -> None:
        ...


@dataclass
class MemoryReportingSink:
    realtime_snapshots: List[List[Dict[str, Any]]] = field(default_factory=list)
    realtime_metric_snapshots: List[List[Dict[str, Any]]] = field(default_factory=list)
    final_results: List[Dict[str, Any]] = field(default_factory=list)
    run_results: List[Dict[str, Any]] = field(default_factory=list)
    sessions: List[Dict[str, Any]] = field(default_factory=list)
    stop_count: int = 0

    @property
    def sink_name(self) -> str:
        return "memory"

    SinkName = property(lambda self: self.sink_name)

    def init(self, session: Dict[str, Any]) -> None:
        self.sessions.append(_session_to_dict(session))

    def start(self, session: Dict[str, Any]) -> None:
        self.sessions.append(_session_to_dict(session))

    def save_realtime_stats(self, scenario_stats: List[Dict[str, Any]]) -> None:
        self.realtime_snapshots.append([dict(row) for row in scenario_stats if isinstance(row, dict)])

    def save_realtime_metrics(self, metrics: List[Dict[str, Any]]) -> None:
        self.realtime_metric_snapshots.append([dict(row) for row in metrics if isinstance(row, dict)])

    def save_final_stats(self, result: Dict[str, Any]) -> None:
        self.final_results.append(copy.deepcopy(_session_to_dict(result)))

    def save_run_result(self, result: Dict[str, Any]) -> None:
        self.run_results.append(copy.deepcopy(_session_to_dict(result)))

    def stop(self) -> None:
        self.stop_count += 1


class ConsoleReportingSink:
    def __init__(self, write_line: Callable[[str], None] = print) -> None:
        self._write_line = write_line

    @property
    def sink_name(self) -> str:
        return "console"

    SinkName = property(lambda self: self.sink_name)

    def init(self, _session: Dict[str, Any]) -> None:
        return

    def start(self, _session: Dict[str, Any]) -> None:
        return

    def save_realtime_stats(self, scenario_stats: List[Dict[str, Any]]) -> None:
        request_count = sum(_as_int(row.get("allRequestCount")) for row in scenario_stats if isinstance(row, dict))
        ok_count = sum(_as_int(row.get("allOkCount")) for row in scenario_stats if isinstance(row, dict))
        fail_count = sum(_as_int(row.get("allFailCount")) for row in scenario_stats if isinstance(row, dict))
        self._write_line(f"realtime requests={request_count} ok={ok_count} fail={fail_count}")

    def save_realtime_metrics(self, metrics: List[Dict[str, Any]]) -> None:
        self._write_line(f"realtime-metrics count={len(metrics)}")

    def save_final_stats(self, result: Dict[str, Any]) -> None:
        payload = _session_to_dict(result)
        self._write_line(
            "final requests="
            f"{_as_int(payload.get('allRequestCount'))} "
            f"ok={_as_int(payload.get('allOkCount'))} "
            f"fail={_as_int(payload.get('allFailCount'))} "
            f"failedThresholds={_as_int(payload.get('failedThresholds'))}"
        )

    def save_run_result(self, _result: Dict[str, Any]) -> None:
        return

    def stop(self) -> None:
        return


class CompositeReportingSink:
    def __init__(self, *sinks: ReportingSink) -> None:
        self._sinks = list(sinks)

    @property
    def sink_name(self) -> str:
        return "composite"

    SinkName = property(lambda self: self.sink_name)

    def init(self, session: Dict[str, Any]) -> None:
        for sink in self._sinks:
            callback = getattr(sink, "init", None)
            if callable(callback):
                callback(session)

    def start(self, session: Dict[str, Any]) -> None:
        for sink in self._sinks:
            callback = getattr(sink, "start", None)
            if callable(callback):
                callback(session)

    def save_realtime_stats(self, scenario_stats: List[Dict[str, Any]]) -> None:
        for sink in self._sinks:
            callback = getattr(sink, "save_realtime_stats", None)
            if callable(callback):
                callback(scenario_stats)

    def save_realtime_metrics(self, metrics: List[Dict[str, Any]]) -> None:
        for sink in self._sinks:
            callback = getattr(sink, "save_realtime_metrics", None)
            if callable(callback):
                callback(metrics)

    def save_final_stats(self, result: Dict[str, Any]) -> None:
        for sink in self._sinks:
            callback = getattr(sink, "save_final_stats", None)
            if callable(callback):
                callback(result)

    def save_run_result(self, result: Dict[str, Any]) -> None:
        for sink in self._sinks:
            callback = getattr(sink, "save_run_result", None)
            if callable(callback):
                callback(result)

    def stop(self) -> None:
        for sink in self._sinks:
            callback = getattr(sink, "stop", None)
            if callable(callback):
                callback()


@dataclass
class _SinkSessionMetadata:
    session_id: str
    test_suite: str
    test_name: str
    cluster_id: str
    node_type: str
    machine_name: str
    started_utc: str


@dataclass
class _ReportingSinkMetricPoint:
    metric_name: str
    metric_kind: str
    occurred_utc: datetime
    value: float
    unit_of_measure: Optional[str]
    tags: Dict[str, str]


class InfluxDbReportingSink:
    default_configuration_section_path = "LoadStrike:ReportingSinks:InfluxDb"

    def __init__(
        self,
        *,
        configuration_section_path: str = default_configuration_section_path,
        base_url: str = "",
        write_endpoint_path: str = "/api/v2/write",
        organization: str = "",
        bucket: str = "",
        token: str = "",
        measurement_name: str = "loadstrike",
        metrics_measurement_name: str = "loadstrike_metrics",
        timeout_seconds: float = 30.0,
        static_tags: Optional[Dict[str, str]] = None,
    ) -> None:
        self._configuration_section_path = configuration_section_path or self.default_configuration_section_path
        self._base_url = str(base_url).rstrip("/")
        self._write_endpoint_path = _normalize_path(write_endpoint_path)
        self._organization = str(organization or "")
        self._bucket = str(bucket or "")
        self._token = str(token or "")
        self._measurement_name = measurement_name or "loadstrike"
        self._metrics_measurement_name = metrics_measurement_name or "loadstrike_metrics"
        self._timeout_seconds = max(float(timeout_seconds), 0.1)
        self._static_tags = _to_string_dict(static_tags)
        self._session: Optional[_SinkSessionMetadata] = None
        self._base_context: Optional[Dict[str, Any]] = None

    @property
    def sink_name(self) -> str:
        return "influxdb"

    @property
    def license_feature(self) -> str:
        return "extensions.reporting_sinks.influxdb"

    SinkName = property(lambda self: self.sink_name)
    LicenseFeature = property(lambda self: self.license_feature)

    def init(self, context: Dict[str, Any], infra_config: Dict[str, Any]) -> None:
        self._base_context = _session_to_dict(context)
        configured = _get_config_section(infra_config, self._configuration_section_path)
        self._base_url = self._base_url or str(configured.get("BaseUrl") or "").rstrip("/")
        self._write_endpoint_path = _normalize_path(
            str(configured.get("WriteEndpointPath") or configured.get("writeEndpointPath") or self._write_endpoint_path)
        )
        self._organization = self._organization or str(configured.get("Organization") or "")
        self._bucket = self._bucket or str(configured.get("Bucket") or "")
        self._token = self._token or str(configured.get("Token") or "")
        self._measurement_name = self._measurement_name or str(configured.get("MeasurementName") or "loadstrike")
        self._metrics_measurement_name = self._metrics_measurement_name or str(
            configured.get("MetricsMeasurementName") or "loadstrike_metrics"
        )
        if self._measurement_name == "loadstrike_scenario":
            self._measurement_name = "loadstrike"
        if not self._static_tags:
            self._static_tags = _to_string_dict(configured.get("StaticTags"))
        if self._timeout_seconds <= 0.1:
            self._timeout_seconds = max(_as_float(configured.get("TimeoutSeconds")), 30.0)
        if not self._base_url:
            raise RuntimeError("InfluxDbReportingSink requires BaseUrl.")
        if not self._organization:
            raise RuntimeError("InfluxDbReportingSink requires Organization.")
        if not self._bucket:
            raise RuntimeError("InfluxDbReportingSink requires Bucket.")

    def start(self, _session: Dict[str, Any]) -> None:
        self._session = _session_metadata_from_context(self._base_context, _session)

    def save_realtime_stats(self, scenario_stats: List[Dict[str, Any]]) -> None:
        self._persist_events(_build_realtime_events(self._require_session(), scenario_stats))

    def save_realtime_metrics(self, metrics: List[Dict[str, Any]]) -> None:
        self._persist_events(_build_metric_events(self._require_session(), metrics))

    def save_final_stats(self, result: Dict[str, Any]) -> None:
        self._persist_events(_build_final_events(self._require_session(), result))

    def save_run_result(self, result: Dict[str, Any]) -> None:
        self._persist_events(_build_run_result_events(self._require_session(), result))

    def stop(self) -> None:
        return

    def _require_session(self) -> _SinkSessionMetadata:
        if self._session is None:
            raise RuntimeError(f"{self.sink_name} has not been started.")
        return self._session

    def _persist_events(self, events: List[Dict[str, Any]]) -> None:
        self._post_lines(
            [
                _event_to_influx_line(
                    self._metrics_measurement_name if _is_metric_event_type(str(evt.get("eventType") or "")) else self._measurement_name,
                    evt,
                    self._static_tags,
                )
                for evt in events
            ]
        )

    def _post_lines(self, lines: List[str]) -> None:
        payload_lines = [line for line in lines if line]
        if not payload_lines:
            return
        url = f"{self._base_url}{self._write_endpoint_path}?org={self._organization}&bucket={self._bucket}&precision=ns"
        headers = {"Content-Type": "text/plain; charset=utf-8"}
        if self._token:
            headers["Authorization"] = f"Token {self._token}"
        body = ("\n".join(payload_lines) + "\n").encode("utf-8")
        request = Request(url, method="POST", data=body, headers=headers)
        with urlopen(request, timeout=self._timeout_seconds) as response:
            if int(getattr(response, "status", 200)) >= 400:
                raise RuntimeError(f"Influx sink request failed with status {response.status}")


class GrafanaLokiReportingSink:
    default_configuration_section_path = "LoadStrike:ReportingSinks:GrafanaLoki"

    def __init__(
        self,
        *,
        configuration_section_path: str = default_configuration_section_path,
        base_url: str = "",
        push_endpoint_path: str = "/loki/api/v1/push",
        metrics_base_url: str = "",
        metrics_endpoint_path: str = "/v1/metrics",
        bearer_token: str = "",
        username: str = "",
        password: str = "",
        tenant_id: str = "",
        timeout_seconds: float = 30.0,
        static_labels: Optional[Dict[str, str]] = None,
        metrics_headers: Optional[Dict[str, str]] = None,
    ) -> None:
        self._configuration_section_path = configuration_section_path or self.default_configuration_section_path
        self._base_url = str(base_url).rstrip("/")
        self._push_endpoint_path = _normalize_path(push_endpoint_path)
        self._metrics_base_url = str(metrics_base_url).rstrip("/")
        self._metrics_endpoint_path = _normalize_path(metrics_endpoint_path)
        self._bearer_token = str(bearer_token or "")
        self._username = str(username or "")
        self._password = str(password or "")
        self._tenant_id = str(tenant_id or "")
        self._timeout_seconds = max(float(timeout_seconds), 0.1)
        self._static_labels = _to_string_dict(static_labels)
        self._metrics_headers = _to_string_dict(metrics_headers)
        self._session: Optional[_SinkSessionMetadata] = None
        self._base_context: Optional[Dict[str, Any]] = None

    @property
    def sink_name(self) -> str:
        return "grafana-loki"

    @property
    def license_feature(self) -> str:
        return "extensions.reporting_sinks.grafana_loki"

    SinkName = property(lambda self: self.sink_name)
    LicenseFeature = property(lambda self: self.license_feature)

    def init(self, context: Dict[str, Any], infra_config: Dict[str, Any]) -> None:
        self._base_context = _session_to_dict(context)
        configured = _get_config_section(infra_config, self._configuration_section_path)
        self._base_url = self._base_url or str(configured.get("BaseUrl") or "").rstrip("/")
        self._push_endpoint_path = _normalize_path(
            str(configured.get("PushEndpointPath") or configured.get("pushEndpointPath") or self._push_endpoint_path)
        )
        self._metrics_base_url = self._metrics_base_url or str(configured.get("MetricsBaseUrl") or "").rstrip("/")
        self._metrics_endpoint_path = _normalize_path(
            str(configured.get("MetricsEndpointPath") or configured.get("metricsEndpointPath") or self._metrics_endpoint_path)
        )
        self._bearer_token = self._bearer_token or str(configured.get("BearerToken") or "")
        self._username = self._username or str(configured.get("Username") or "")
        self._password = self._password or str(configured.get("Password") or "")
        self._tenant_id = self._tenant_id or str(configured.get("TenantId") or "")
        if not self._static_labels:
            self._static_labels = _to_string_dict(configured.get("StaticLabels"))
        if not self._metrics_headers:
            self._metrics_headers = _to_string_dict(configured.get("MetricsHeaders"))
        if self._timeout_seconds <= 0.1:
            self._timeout_seconds = max(_as_float(configured.get("TimeoutSeconds")), 30.0)
        if not self._base_url:
            raise RuntimeError("GrafanaLokiReportingSink requires BaseUrl.")

    def start(self, _session: Dict[str, Any]) -> None:
        self._session = _session_metadata_from_context(self._base_context, _session)

    def save_realtime_stats(self, scenario_stats: List[Dict[str, Any]]) -> None:
        self._push(_build_realtime_events(self._require_session(), scenario_stats))

    def save_realtime_metrics(self, metrics: List[Dict[str, Any]]) -> None:
        self._push(_build_metric_events(self._require_session(), metrics))

    def save_final_stats(self, result: Dict[str, Any]) -> None:
        self._push(_build_final_events(self._require_session(), result))

    def save_run_result(self, result: Dict[str, Any]) -> None:
        self._push(_build_run_result_events(self._require_session(), result))

    def stop(self) -> None:
        return

    def _require_session(self) -> _SinkSessionMetadata:
        if self._session is None:
            raise RuntimeError(f"{self.sink_name} has not been started.")
        return self._session

    def _push(self, events: List[Dict[str, Any]]) -> None:
        if not events:
            return
        grouped: Dict[str, Dict[str, Any]] = {}
        for event in events:
            labels = _merge_event_labels(event, self._static_labels)
            key = "|".join(f"{name}={labels[name]}" for name in sorted(labels))
            bucket = grouped.setdefault(key, {"stream": labels, "values": []})
            bucket["values"].append([str(_to_unix_nanoseconds(event["occurredUtc"])), _event_to_json(event)])
        body = json.dumps({"streams": list(grouped.values())}).encode("utf-8")
        headers = {"Content-Type": "application/json"}
        if self._bearer_token:
            headers["Authorization"] = f"Bearer {self._bearer_token}"
        elif self._username:
            token = base64.b64encode(f"{self._username}:{self._password}".encode("utf-8")).decode("ascii")
            headers["Authorization"] = f"Basic {token}"
        if self._tenant_id:
            headers["X-Scope-OrgID"] = self._tenant_id
        request = Request(f"{self._base_url}{self._push_endpoint_path}", method="POST", data=body, headers=headers)
        with urlopen(request, timeout=self._timeout_seconds) as response:
            if int(getattr(response, "status", 200)) >= 400:
                raise RuntimeError(f"Loki sink request failed with status {response.status}")
        self._push_metrics(events)

    def _push_metrics(self, events: List[Dict[str, Any]]) -> None:
        points = _create_metric_projection_points(self.sink_name, events, self._static_labels)
        if not points:
            return
        grouped: Dict[tuple[str, str, Optional[str]], List[_ReportingSinkMetricPoint]] = {}
        for point in points:
            grouped.setdefault((point.metric_name, point.metric_kind, point.unit_of_measure), []).append(point)
        payload = {
            "resourceMetrics": [
                {
                    "resource": {"attributes": _build_otel_resource_attributes(self.sink_name, self._static_labels)},
                    "scopeMetrics": [
                        {
                            "scope": {"name": "loadstrike.reporting", "version": "1.0.0"},
                            "metrics": [
                                _build_otel_metric(group_points[0], group_points)
                                for group_points in grouped.values()
                            ],
                        }
                    ],
                }
            ]
        }
        _send_json_request(
            f"{(self._metrics_base_url or self._base_url)}{self._metrics_endpoint_path}",
            payload,
            headers=self._metrics_headers,
            timeout_seconds=self._timeout_seconds,
            error_prefix="GrafanaLokiReportingSink metrics",
        )


class TimescaleDbReportingSink:
    default_configuration_section_path = "LoadStrike:ReportingSinks:TimescaleDb"

    def __init__(
        self,
        *,
        configuration_section_path: str = default_configuration_section_path,
        connection_string: str = "",
        schema: str = "public",
        table_name: str = "loadstrike_reporting_events",
        metrics_table_name: str = "loadstrike_reporting_metrics",
        create_schema_if_missing: bool = True,
        enable_hypertable_if_available: bool = True,
        static_tags: Optional[Dict[str, str]] = None,
        insert: Optional[Callable[[str, List[Dict[str, Any]]], None]] = None,
        insert_metrics: Optional[Callable[[str, List[Dict[str, Any]]], None]] = None,
    ) -> None:
        self._configuration_section_path = configuration_section_path or self.default_configuration_section_path
        self.connection_string = connection_string
        self.schema = schema or "public"
        self.table_name = table_name or "loadstrike_reporting_events"
        self.metrics_table_name = metrics_table_name or "loadstrike_reporting_metrics"
        self.create_schema_if_missing = bool(create_schema_if_missing)
        self.enable_hypertable_if_available = bool(enable_hypertable_if_available)
        self.static_tags = _to_string_dict(static_tags)
        self._insert = insert
        self._insert_metrics = insert_metrics
        self._buffered_rows: List[Dict[str, Any]] = []
        self._session: Optional[_SinkSessionMetadata] = None
        self._base_context: Optional[Dict[str, Any]] = None

    @property
    def sink_name(self) -> str:
        return "timescaledb"

    @property
    def license_feature(self) -> str:
        return "extensions.reporting_sinks.timescaledb"

    SinkName = property(lambda self: self.sink_name)
    LicenseFeature = property(lambda self: self.license_feature)

    def init(self, context: Dict[str, Any], infra_config: Dict[str, Any]) -> None:
        self._base_context = _session_to_dict(context)
        configured = _get_config_section(infra_config, self._configuration_section_path)
        self.connection_string = self.connection_string or str(configured.get("ConnectionString") or "")
        self.schema = self.schema or str(configured.get("Schema") or "public")
        self.table_name = self.table_name or str(configured.get("TableName") or "loadstrike_reporting_events")
        self.metrics_table_name = self.metrics_table_name or str(configured.get("MetricsTableName") or "loadstrike_reporting_metrics")
        if not self.static_tags:
            self.static_tags = _to_string_dict(configured.get("StaticTags"))
        if not self.connection_string and not callable(self._insert):
            raise RuntimeError("TimescaleDbReportingSink requires ConnectionString.")

    def start(self, _session: Dict[str, Any]) -> None:
        self._session = _session_metadata_from_context(self._base_context, _session)

    def save_realtime_stats(self, scenario_stats: List[Dict[str, Any]]) -> None:
        self._persist(_build_realtime_events(self._require_session(), scenario_stats))

    def save_realtime_metrics(self, metrics: List[Dict[str, Any]]) -> None:
        self._persist(_build_metric_events(self._require_session(), metrics))

    def save_final_stats(self, result: Dict[str, Any]) -> None:
        self._persist(_build_final_events(self._require_session(), result))

    def save_run_result(self, result: Dict[str, Any]) -> None:
        self._persist(_build_run_result_events(self._require_session(), result))

    def stop(self) -> None:
        return

    @property
    def buffered_rows(self) -> List[Dict[str, Any]]:
        return [dict(row) for row in self._buffered_rows]

    def _require_session(self) -> _SinkSessionMetadata:
        if self._session is None:
            raise RuntimeError(f"{self.sink_name} has not been started.")
        return self._session

    def _persist(self, events: List[Dict[str, Any]]) -> None:
        if not events:
            return
        rows = [_event_to_timescale_row(event, self.static_tags) for event in events]
        metric_rows = [
            {
                "occurredUtc": _iso_utc(point.occurred_utc),
                "metricName": point.metric_name,
                "metricKind": point.metric_kind,
                "value": point.value,
                "unitOfMeasure": point.unit_of_measure,
                "tags": copy.deepcopy(point.tags),
            }
            for point in _create_metric_projection_points(self.sink_name, events, self.static_tags)
        ]
        qualified_table = f"{self.schema}.{self.table_name}"
        qualified_metrics_table = f"{self.schema}.{self.metrics_table_name}"
        if callable(self._insert):
            self._insert(qualified_table, rows)
            if metric_rows and callable(self._insert_metrics):
                self._insert_metrics(qualified_metrics_table, metric_rows)
            return
        self._buffered_rows.extend(rows)
        self._buffered_rows.extend(copy.deepcopy(metric_rows))


class DatadogReportingSink:
    default_configuration_section_path = "LoadStrike:ReportingSinks:Datadog"

    def __init__(
        self,
        *,
        configuration_section_path: str = default_configuration_section_path,
        base_url: str = "",
        logs_endpoint_path: str = "/api/v2/logs",
        metrics_endpoint_path: str = "/api/v2/series",
        api_key: str = "",
        application_key: str = "",
        source: str = "loadstrike",
        service: str = "loadstrike",
        host: str = "",
        timeout_seconds: float = 30.0,
        static_tags: Optional[Dict[str, str]] = None,
        static_attributes: Optional[Dict[str, str]] = None,
    ) -> None:
        self._configuration_section_path = configuration_section_path or self.default_configuration_section_path
        self._base_url = str(base_url).rstrip("/")
        self._logs_endpoint_path = _normalize_path(logs_endpoint_path)
        self._metrics_endpoint_path = _normalize_path(metrics_endpoint_path)
        self._api_key = str(api_key or "")
        self._application_key = str(application_key or "")
        self._source = str(source or "loadstrike")
        self._service = str(service or "loadstrike")
        self._host = str(host or "")
        self._timeout_seconds = max(float(timeout_seconds), 0.1)
        self._static_tags = _to_string_dict(static_tags)
        self._static_attributes = _to_string_dict(static_attributes)
        self._session: Optional[_SinkSessionMetadata] = None
        self._base_context: Optional[Dict[str, Any]] = None

    @property
    def sink_name(self) -> str:
        return "datadog"

    @property
    def license_feature(self) -> str:
        return "extensions.reporting_sinks.datadog"

    SinkName = property(lambda self: self.sink_name)
    LicenseFeature = property(lambda self: self.license_feature)

    def init(self, context: Dict[str, Any], infra_config: Dict[str, Any]) -> None:
        self._base_context = _session_to_dict(context)
        configured = _get_config_section(infra_config, self._configuration_section_path)
        self._base_url = self._base_url or str(configured.get("BaseUrl") or "").rstrip("/")
        self._logs_endpoint_path = _normalize_path(
            str(configured.get("LogsEndpointPath") or configured.get("logsEndpointPath") or self._logs_endpoint_path)
        )
        self._metrics_endpoint_path = _normalize_path(
            str(configured.get("MetricsEndpointPath") or configured.get("metricsEndpointPath") or self._metrics_endpoint_path)
        )
        self._api_key = self._api_key or str(configured.get("ApiKey") or "")
        self._application_key = self._application_key or str(configured.get("ApplicationKey") or "")
        self._source = self._source or str(configured.get("Source") or "loadstrike")
        self._service = self._service or str(configured.get("Service") or "loadstrike")
        self._host = self._host or str(configured.get("Host") or "")
        if not self._static_tags:
            self._static_tags = _to_string_dict(configured.get("StaticTags"))
        if not self._static_attributes:
            self._static_attributes = _to_string_dict(configured.get("StaticAttributes"))
        if self._timeout_seconds <= 0.1:
            self._timeout_seconds = max(_as_float(configured.get("TimeoutSeconds")), 30.0)
        if not self._base_url:
            raise RuntimeError("DatadogReportingSink requires BaseUrl.")
        if not self._api_key:
            raise RuntimeError("DatadogReportingSink requires ApiKey.")

    def start(self, _session: Dict[str, Any]) -> None:
        self._session = _session_metadata_from_context(self._base_context, _session)

    def save_realtime_stats(self, scenario_stats: List[Dict[str, Any]]) -> None:
        self._persist(_build_realtime_events(self._require_session(), scenario_stats))

    def save_realtime_metrics(self, metrics: List[Dict[str, Any]]) -> None:
        self._persist(_build_metric_events(self._require_session(), metrics))

    def save_final_stats(self, result: Dict[str, Any]) -> None:
        self._persist(_build_final_events(self._require_session(), result))

    def save_run_result(self, result: Dict[str, Any]) -> None:
        self._persist(_build_run_result_events(self._require_session(), result))

    def stop(self) -> None:
        return

    def _require_session(self) -> _SinkSessionMetadata:
        if self._session is None:
            raise RuntimeError(f"{self.sink_name} has not been started.")
        return self._session

    def _persist(self, events: List[Dict[str, Any]]) -> None:
        if not events:
            return
        headers = {"DD-API-KEY": self._api_key}
        if self._application_key:
            headers["DD-APPLICATION-KEY"] = self._application_key

        logs = [_build_datadog_log_entry(self, event) for event in events]
        _send_json_request(
            f"{self._base_url}{self._logs_endpoint_path}",
            logs,
            headers=headers,
            timeout_seconds=self._timeout_seconds,
            error_prefix="DatadogReportingSink logs",
        )

        points = _create_metric_projection_points(self.sink_name, events, self._static_tags)
        if not points:
            return
        series = [
            {
                "metric": point.metric_name,
                "type": point.metric_kind,
                "points": [[_to_unix_seconds(point.occurred_utc), point.value]],
                "tags": [
                    f"{_sanitize_datadog_tag_component(key)}:{_sanitize_datadog_tag_component(value)}"
                    for key, value in sorted(point.tags.items())
                ],
            }
            for point in points
        ]
        _send_json_request(
            f"{self._base_url}{self._metrics_endpoint_path}",
            {"series": series},
            headers=headers,
            timeout_seconds=self._timeout_seconds,
            error_prefix="DatadogReportingSink metrics",
        )


class SplunkReportingSink:
    default_configuration_section_path = "LoadStrike:ReportingSinks:Splunk"

    def __init__(
        self,
        *,
        configuration_section_path: str = default_configuration_section_path,
        base_url: str = "",
        event_endpoint_path: str = "/services/collector/event",
        token: str = "",
        source: str = "loadstrike",
        sourcetype: str = "_json",
        index: str = "",
        host: str = "",
        timeout_seconds: float = 30.0,
        static_fields: Optional[Dict[str, str]] = None,
    ) -> None:
        self._configuration_section_path = configuration_section_path or self.default_configuration_section_path
        self._base_url = str(base_url).rstrip("/")
        self._event_endpoint_path = _normalize_path(event_endpoint_path)
        self._token = str(token or "")
        self._source = str(source or "loadstrike")
        self._sourcetype = str(sourcetype or "_json")
        self._index = str(index or "")
        self._host = str(host or "")
        self._timeout_seconds = max(float(timeout_seconds), 0.1)
        self._static_fields = _to_string_dict(static_fields)
        self._session: Optional[_SinkSessionMetadata] = None
        self._base_context: Optional[Dict[str, Any]] = None

    @property
    def sink_name(self) -> str:
        return "splunk"

    @property
    def license_feature(self) -> str:
        return "extensions.reporting_sinks.splunk"

    SinkName = property(lambda self: self.sink_name)
    LicenseFeature = property(lambda self: self.license_feature)

    def init(self, context: Dict[str, Any], infra_config: Dict[str, Any]) -> None:
        self._base_context = _session_to_dict(context)
        configured = _get_config_section(infra_config, self._configuration_section_path)
        self._base_url = self._base_url or str(configured.get("BaseUrl") or "").rstrip("/")
        self._event_endpoint_path = _normalize_path(
            str(configured.get("EventEndpointPath") or configured.get("eventEndpointPath") or self._event_endpoint_path)
        )
        self._token = self._token or str(configured.get("Token") or "")
        self._source = self._source or str(configured.get("Source") or "loadstrike")
        self._sourcetype = self._sourcetype or str(configured.get("Sourcetype") or "_json")
        self._index = self._index or str(configured.get("Index") or "")
        self._host = self._host or str(configured.get("Host") or "")
        if not self._static_fields:
            self._static_fields = _to_string_dict(configured.get("StaticFields"))
        if self._timeout_seconds <= 0.1:
            self._timeout_seconds = max(_as_float(configured.get("TimeoutSeconds")), 30.0)
        if not self._base_url:
            raise RuntimeError("SplunkReportingSink requires BaseUrl.")
        if not self._token:
            raise RuntimeError("SplunkReportingSink requires Token.")

    def start(self, _session: Dict[str, Any]) -> None:
        self._session = _session_metadata_from_context(self._base_context, _session)

    def save_realtime_stats(self, scenario_stats: List[Dict[str, Any]]) -> None:
        self._persist(_build_realtime_events(self._require_session(), scenario_stats))

    def save_realtime_metrics(self, metrics: List[Dict[str, Any]]) -> None:
        self._persist(_build_metric_events(self._require_session(), metrics))

    def save_final_stats(self, result: Dict[str, Any]) -> None:
        self._persist(_build_final_events(self._require_session(), result))

    def save_run_result(self, result: Dict[str, Any]) -> None:
        self._persist(_build_run_result_events(self._require_session(), result))

    def stop(self) -> None:
        return

    def _require_session(self) -> _SinkSessionMetadata:
        if self._session is None:
            raise RuntimeError(f"{self.sink_name} has not been started.")
        return self._session

    def _persist(self, events: List[Dict[str, Any]]) -> None:
        if not events:
            return
        payloads = [
            json.dumps(_build_splunk_log_envelope(self, event), separators=(",", ":"))
            for event in events
        ]
        payloads.extend(
            json.dumps(_build_splunk_metric_envelope(self, point), separators=(",", ":"))
            for point in _create_metric_projection_points(self.sink_name, events, {})
        )
        if not payloads:
            return
        _send_text_request(
            f"{self._base_url}{self._event_endpoint_path}",
            "\n".join(payloads),
            headers={
                "Authorization": f"Splunk {self._token}",
            },
            content_type="application/json",
            timeout_seconds=self._timeout_seconds,
            error_prefix="SplunkReportingSink",
        )


class OtelCollectorReportingSink:
    default_configuration_section_path = "LoadStrike:ReportingSinks:OtelCollector"

    def __init__(
        self,
        *,
        configuration_section_path: str = default_configuration_section_path,
        base_url: str = "",
        logs_endpoint_path: str = "/v1/logs",
        metrics_endpoint_path: str = "/v1/metrics",
        timeout_seconds: float = 30.0,
        headers: Optional[Dict[str, str]] = None,
        static_resource_attributes: Optional[Dict[str, str]] = None,
    ) -> None:
        self._configuration_section_path = configuration_section_path or self.default_configuration_section_path
        self._base_url = str(base_url).rstrip("/")
        self._logs_endpoint_path = _normalize_path(logs_endpoint_path)
        self._metrics_endpoint_path = _normalize_path(metrics_endpoint_path)
        self._timeout_seconds = max(float(timeout_seconds), 0.1)
        self._headers = _to_string_dict(headers)
        self._static_resource_attributes = _to_string_dict(static_resource_attributes)
        self._session: Optional[_SinkSessionMetadata] = None
        self._base_context: Optional[Dict[str, Any]] = None

    @property
    def sink_name(self) -> str:
        return "otel-collector"

    @property
    def license_feature(self) -> str:
        return "extensions.reporting_sinks.otel_collector"

    SinkName = property(lambda self: self.sink_name)
    LicenseFeature = property(lambda self: self.license_feature)

    def init(self, context: Dict[str, Any], infra_config: Dict[str, Any]) -> None:
        self._base_context = _session_to_dict(context)
        configured = _get_config_section(infra_config, self._configuration_section_path)
        self._base_url = self._base_url or str(configured.get("BaseUrl") or "").rstrip("/")
        self._logs_endpoint_path = _normalize_path(
            str(configured.get("LogsEndpointPath") or configured.get("logsEndpointPath") or self._logs_endpoint_path)
        )
        self._metrics_endpoint_path = _normalize_path(
            str(configured.get("MetricsEndpointPath") or configured.get("metricsEndpointPath") or self._metrics_endpoint_path)
        )
        if not self._headers:
            self._headers = _to_string_dict(configured.get("Headers"))
        if not self._static_resource_attributes:
            self._static_resource_attributes = _to_string_dict(configured.get("StaticResourceAttributes"))
        if self._timeout_seconds <= 0.1:
            self._timeout_seconds = max(_as_float(configured.get("TimeoutSeconds")), 30.0)
        if not self._base_url:
            raise RuntimeError("OtelCollectorReportingSink requires BaseUrl.")

    def start(self, _session: Dict[str, Any]) -> None:
        self._session = _session_metadata_from_context(self._base_context, _session)

    def save_realtime_stats(self, scenario_stats: List[Dict[str, Any]]) -> None:
        self._persist(_build_realtime_events(self._require_session(), scenario_stats))

    def save_realtime_metrics(self, metrics: List[Dict[str, Any]]) -> None:
        self._persist(_build_metric_events(self._require_session(), metrics))

    def save_final_stats(self, result: Dict[str, Any]) -> None:
        self._persist(_build_final_events(self._require_session(), result))

    def save_run_result(self, result: Dict[str, Any]) -> None:
        self._persist(_build_run_result_events(self._require_session(), result))

    def stop(self) -> None:
        return

    def _require_session(self) -> _SinkSessionMetadata:
        if self._session is None:
            raise RuntimeError(f"{self.sink_name} has not been started.")
        return self._session

    def _persist(self, events: List[Dict[str, Any]]) -> None:
        if not events:
            return
        headers = {"Content-Type": "application/json", **self._headers}
        resource_attributes = _build_otel_resource_attributes(self.sink_name, self._static_resource_attributes)
        logs_payload = {
            "resourceLogs": [
                {
                    "resource": {"attributes": resource_attributes},
                    "scopeLogs": [
                        {
                            "scope": {"name": "loadstrike.reporting", "version": "1.0.0"},
                            "logRecords": [_build_otel_log_record(event) for event in events],
                        }
                    ],
                }
            ]
        }
        _send_json_request(
            f"{self._base_url}{self._logs_endpoint_path}",
            logs_payload,
            headers=headers,
            timeout_seconds=self._timeout_seconds,
            error_prefix="OtelCollectorReportingSink logs",
        )
        points = _create_metric_projection_points(self.sink_name, events, {})
        if not points:
            return
        grouped: Dict[tuple[str, str, Optional[str]], List[_ReportingSinkMetricPoint]] = {}
        for point in points:
            key = (point.metric_name, point.metric_kind, point.unit_of_measure)
            grouped.setdefault(key, []).append(point)
        metrics_payload = {
            "resourceMetrics": [
                {
                    "resource": {"attributes": resource_attributes},
                    "scopeMetrics": [
                        {
                            "scope": {"name": "loadstrike.reporting", "version": "1.0.0"},
                            "metrics": [
                                _build_otel_metric(group_points[0], group_points)
                                for group_points in grouped.values()
                            ],
                        }
                    ],
                }
            ]
        }
        _send_json_request(
            f"{self._base_url}{self._metrics_endpoint_path}",
            metrics_payload,
            headers=headers,
            timeout_seconds=self._timeout_seconds,
            error_prefix="OtelCollectorReportingSink metrics",
        )


def _build_realtime_events(
    session: _SinkSessionMetadata,
    scenario_stats: List[Dict[str, Any]],
) -> List[Dict[str, Any]]:
    occurred_utc = datetime.now(timezone.utc)
    events: List[Dict[str, Any]] = []
    for row in scenario_stats:
        if not isinstance(row, dict):
            continue
        scenario_name = str(row.get("scenarioName") or "")
        events.append(
            _create_event(
                session,
                occurred_utc,
                event_type="scenario.realtime",
                scenario_name=scenario_name,
                step_name=None,
                tags={"phase": "realtime", "entity": "scenario"},
                fields=_scenario_fields(row),
            )
        )
        events.extend(_build_status_code_events(session, occurred_utc, "realtime", row, step_name=None))
        for step in _step_rows_for_scenario(row):
            events.append(
                _create_event(
                    session,
                    occurred_utc,
                    event_type="step.realtime",
                    scenario_name=scenario_name,
                    step_name=str(step.get("stepName") or ""),
                    tags={"phase": "realtime", "entity": "step"},
                    fields=_step_fields(step),
                )
            )
            events.extend(_build_status_code_events(session, occurred_utc, "realtime", step, step_name=str(step.get("stepName") or "")))
    return events


def _build_metric_events(
    session: _SinkSessionMetadata,
    metrics: Any,
    *,
    phase: str = "realtime",
    occurred_utc: Optional[datetime] = None,
) -> List[Dict[str, Any]]:
    payload = _session_to_dict(metrics)
    metric_rows: List[Dict[str, Any]] = []

    if isinstance(metrics, list):
        metric_rows.extend(row for row in metrics if isinstance(row, dict))
    elif isinstance(payload.get("counters"), list) or isinstance(payload.get("gauges"), list):
        duration_ms = payload.get("durationMs") or payload.get("duration_ms")

        for counter in payload.get("counters", []) or []:
            if not isinstance(counter, dict):
                continue
            metric_rows.append({
                "name": counter.get("metricName") or counter.get("metric_name"),
                "type": "counter",
                "scenarioName": counter.get("scenarioName") or counter.get("scenario_name"),
                "unitOfMeasure": counter.get("unitOfMeasure") or counter.get("unit_of_measure"),
                "value": counter.get("value"),
                "durationMs": duration_ms,
            })

        for gauge in payload.get("gauges", []) or []:
            if not isinstance(gauge, dict):
                continue
            metric_rows.append({
                "name": gauge.get("metricName") or gauge.get("metric_name"),
                "type": "gauge",
                "scenarioName": gauge.get("scenarioName") or gauge.get("scenario_name"),
                "unitOfMeasure": gauge.get("unitOfMeasure") or gauge.get("unit_of_measure"),
                "value": gauge.get("value"),
                "durationMs": duration_ms,
            })

    occurred_utc = occurred_utc or datetime.now(timezone.utc)
    events: List[Dict[str, Any]] = []
    for metric in metric_rows:
        if not isinstance(metric, dict):
            continue
        metric_name = str(metric.get("name") or "")
        if not metric_name:
            continue
        metric_type = str(metric.get("type") or "gauge").lower()
        events.append(
            _create_event(
                session,
                occurred_utc,
                event_type=f"metric.{metric_type}.final" if phase == "final" else f"metric.{metric_type}",
                scenario_name=str(metric.get("scenarioName") or ""),
                step_name=None,
                tags={
                    "phase": phase,
                    "metric_name": metric_name,
                    "metric_type": metric_type,
                },
                fields={
                    "value": metric.get("value"),
                    "unit_of_measure": metric.get("unitOfMeasure") or metric.get("unit_of_measure"),
                    "duration_ms": metric.get("durationMs"),
                },
            )
        )
    return events


def _build_final_events(
    session: _SinkSessionMetadata,
    result: Dict[str, Any],
) -> List[Dict[str, Any]]:
    payload = _session_to_dict(result)
    occurred_utc = datetime.now(timezone.utc)
    events: List[Dict[str, Any]] = [
        _create_event(
            session,
            occurred_utc,
            event_type="test.final",
            scenario_name=None,
            step_name=None,
            tags={"phase": "final", "entity": "test"},
            fields={
                "all_request_count": payload.get("allRequestCount"),
                "all_ok_count": payload.get("allOkCount"),
                "all_fail_count": payload.get("allFailCount"),
                "all_bytes": payload.get("allBytes"),
                "duration_ms": payload.get("durationMs"),
                "scenario_count": len(payload.get("scenarioStats", [])),
                "threshold_count": len(payload.get("thresholdResults", [])),
            },
        )
    ]

    for row in payload.get("scenarioStats", []):
        if not isinstance(row, dict):
            continue
        scenario_name = str(row.get("scenarioName") or "")
        events.append(
            _create_event(
                session,
                occurred_utc,
                event_type="scenario.final",
                scenario_name=scenario_name,
                step_name=None,
                tags={"phase": "final", "entity": "scenario"},
                fields=_scenario_fields(row),
            )
        )
        events.extend(_build_status_code_events(session, occurred_utc, "final", row, step_name=None))
        for step in _step_rows_for_scenario(row):
            events.append(
                _create_event(
                    session,
                    occurred_utc,
                    event_type="step.final",
                    scenario_name=scenario_name,
                    step_name=str(step.get("stepName") or ""),
                    tags={"phase": "final", "entity": "step"},
                    fields=_step_fields(step),
                )
            )
            events.extend(_build_status_code_events(session, occurred_utc, "final", step, step_name=str(step.get("stepName") or "")))

    events.extend(_build_metric_events(session, payload.get("metrics"), phase="final", occurred_utc=occurred_utc))

    for row in payload.get("thresholdResults", []):
        if not isinstance(row, dict):
            continue
        events.append(
            _create_event(
                session,
                occurred_utc,
                event_type="threshold.final",
                scenario_name=str(row.get("scenarioName") or ""),
                step_name=str(row.get("stepName") or ""),
                tags={"phase": "final", "entity": "threshold"},
                fields={
                    "check_expression": row.get("checkExpression"),
                    "is_failed": row.get("isFailed"),
                    "error_count": row.get("errorCount"),
                    "exception_message": row.get("exceptionMsg") or row.get("exceptionMessage"),
                },
            )
        )

    for plugin in payload.get("pluginsData", []):
        if not isinstance(plugin, dict):
            continue
        plugin_name = str(plugin.get("pluginName") or "unnamed-plugin")
        for hint in plugin.get("hints", []) or []:
            if not str(hint or "").strip():
                continue
            events.append(
                _create_event(
                    session,
                    occurred_utc,
                    event_type="plugin.hint.final",
                    scenario_name=None,
                    step_name=None,
                    tags={"phase": "final", "entity": "plugin-hint", "plugin_name": plugin_name},
                    fields={"hint": hint},
                )
            )
        for table in plugin.get("tables", []) or []:
            if not isinstance(table, dict):
                continue
            table_name = str(table.get("tableName") or "table")
            for index, row in enumerate(table.get("rows", []) or []):
                if not isinstance(row, dict):
                    continue
                fields = {"row_index": index}
                for key, value in row.items():
                    fields[_normalize_field_name(key)] = _normalize_field_value(value)
                events.append(
                    _create_event(
                        session,
                        occurred_utc,
                        event_type="plugin.table.final",
                        scenario_name=_try_read_text(row, "scenarioName", "Scenario"),
                        step_name=_try_read_text(row, "stepName", "Step"),
                        tags={
                            "phase": "final",
                            "entity": "plugin-table-row",
                            "plugin_name": plugin_name,
                            "table_name": table_name,
                        },
                        fields=fields,
                    )
                )
    return events


def _build_run_result_events(
    session: _SinkSessionMetadata,
    result: Dict[str, Any],
) -> List[Dict[str, Any]]:
    payload = _session_to_dict(result)
    occurred_utc = datetime.now(timezone.utc)
    events: List[Dict[str, Any]] = [
        _create_event(
            session,
            occurred_utc,
            event_type="run.result.final",
            scenario_name=None,
            step_name=None,
            tags={"phase": "final", "entity": "run-result"},
            fields={
                "started_utc": payload.get("startedUtc"),
                "completed_utc": payload.get("completedUtc"),
                "report_file_count": len(payload.get("reportFiles") or []),
                "disabled_sink_count": len(payload.get("disabledSinks") or []),
                "sink_error_count": len(payload.get("sinkErrors") or []),
            },
        )
    ]
    for report_file in payload.get("reportFiles") or []:
        events.append(
            _create_event(
                session,
                occurred_utc,
                event_type="run.report.final",
                scenario_name=None,
                step_name=None,
                tags={"phase": "final", "entity": "run-report"},
                fields={"path": report_file},
            )
        )
    for disabled_sink in payload.get("disabledSinks") or []:
        events.append(
            _create_event(
                session,
                occurred_utc,
                event_type="run.disabled-sink.final",
                scenario_name=None,
                step_name=None,
                tags={"phase": "final", "entity": "disabled-sink", "sink_name": str(disabled_sink or "")},
                fields={"sink_name": disabled_sink},
            )
        )
    for sink_error in payload.get("sinkErrors") or []:
        if not isinstance(sink_error, dict):
            continue
        events.append(
            _create_event(
                session,
                occurred_utc,
                event_type="run.sink-error.final",
                scenario_name=None,
                step_name=None,
                tags={
                    "phase": "final",
                    "entity": "sink-error",
                    "sink_name": str(sink_error.get("sinkName") or ""),
                    "sink_phase": str(sink_error.get("phase") or ""),
                },
                fields={
                    "sink_name": sink_error.get("sinkName"),
                    "phase": sink_error.get("phase"),
                    "message": sink_error.get("message"),
                    "attempts": sink_error.get("attempts"),
                },
            )
        )
    return events


def _create_event(
    session: _SinkSessionMetadata,
    occurred_utc: datetime,
    *,
    event_type: str,
    scenario_name: Optional[str],
    step_name: Optional[str],
    tags: Dict[str, str],
    fields: Dict[str, Any],
) -> Dict[str, Any]:
    merged_tags = {
        "event_type": event_type,
        "session_id": session.session_id or "default",
        "test_suite": session.test_suite or "default",
        "test_name": session.test_name or "loadstrike",
        "cluster_id": session.cluster_id or "default",
        "node_type": session.node_type or "SingleNode",
        "machine_name": session.machine_name or "local-machine",
        "started_utc": session.started_utc,
    }
    if scenario_name:
        merged_tags["scenario_name"] = scenario_name
    if step_name:
        merged_tags["step_name"] = step_name
    for key, value in tags.items():
        if str(value or "").strip():
            merged_tags[str(key)] = str(value)
    if merged_tags.get("phase", "").lower() == "final":
        merged_tags["completed_utc"] = _iso_utc(occurred_utc)
    event_fields = {
        "started_utc": session.started_utc,
        **{str(key): value for key, value in fields.items()},
    }
    if merged_tags.get("phase", "").lower() == "final":
        event_fields["completed_utc"] = _iso_utc(occurred_utc)
    return {
        "eventType": event_type,
        "occurredUtc": occurred_utc,
        "sessionId": session.session_id,
        "testSuite": session.test_suite,
        "testName": session.test_name,
        "clusterId": session.cluster_id,
        "nodeType": session.node_type,
        "machineName": session.machine_name,
        "scenarioName": scenario_name,
        "stepName": step_name,
        "tags": merged_tags,
        "fields": event_fields,
    }


def _measurement_payload(row: Dict[str, Any], name: str) -> Dict[str, Any]:
    value = row.get(name)
    return value if isinstance(value, dict) else {}


def _measurement_fields(prefix: str, measurement: Dict[str, Any]) -> Dict[str, Any]:
    request = measurement.get("request") if isinstance(measurement.get("request"), dict) else {}
    latency = measurement.get("latency") if isinstance(measurement.get("latency"), dict) else {}
    latency_count = latency.get("latencyCount") if isinstance(latency.get("latencyCount"), dict) else {}
    data_transfer = measurement.get("dataTransfer") if isinstance(measurement.get("dataTransfer"), dict) else {}
    status_codes = measurement.get("statusCodes") if isinstance(measurement.get("statusCodes"), list) else []
    return {
        f"{prefix}_request_count": request.get("count"),
        f"{prefix}_request_percent": request.get("percent"),
        f"{prefix}_request_rps": request.get("rps"),
        f"{prefix}_latency_min_ms": latency.get("minMs"),
        f"{prefix}_latency_mean_ms": latency.get("meanMs"),
        f"{prefix}_latency_max_ms": latency.get("maxMs"),
        f"{prefix}_latency_p50_ms": latency.get("percent50"),
        f"{prefix}_latency_p75_ms": latency.get("percent75"),
        f"{prefix}_latency_p95_ms": latency.get("percent95"),
        f"{prefix}_latency_p99_ms": latency.get("percent99"),
        f"{prefix}_latency_std_dev": latency.get("stdDev"),
        f"{prefix}_latency_le_800_count": latency_count.get("lessOrEq800"),
        f"{prefix}_latency_gt_800_lt_1200_count": latency_count.get("more800Less1200"),
        f"{prefix}_latency_ge_1200_count": latency_count.get("moreOrEq1200"),
        f"{prefix}_bytes_all": data_transfer.get("allBytes"),
        f"{prefix}_bytes_min": data_transfer.get("minBytes"),
        f"{prefix}_bytes_mean": data_transfer.get("meanBytes"),
        f"{prefix}_bytes_max": data_transfer.get("maxBytes"),
        f"{prefix}_bytes_p50": data_transfer.get("percent50"),
        f"{prefix}_bytes_p75": data_transfer.get("percent75"),
        f"{prefix}_bytes_p95": data_transfer.get("percent95"),
        f"{prefix}_bytes_p99": data_transfer.get("percent99"),
        f"{prefix}_bytes_std_dev": data_transfer.get("stdDev"),
        f"{prefix}_status_code_count": len(status_codes),
    }


def _step_rows_for_scenario(row: Dict[str, Any]) -> List[Dict[str, Any]]:
    values = row.get("stepStats")
    if not isinstance(values, list):
        return []
    return [dict(item) for item in values if isinstance(item, dict)]


def _build_status_code_events(
    session: _SinkSessionMetadata,
    occurred_utc: datetime,
    phase: str,
    row: Dict[str, Any],
    *,
    step_name: Optional[str],
) -> List[Dict[str, Any]]:
    scenario_name = str(row.get("scenarioName") or "")
    entity = "scenario-status-code" if not step_name else "step-status-code"
    events: List[Dict[str, Any]] = []
    for result_kind in ("ok", "fail"):
        measurement = _measurement_payload(row, result_kind)
        status_rows = measurement.get("statusCodes")
        if not isinstance(status_rows, list):
            continue
        for status_row in status_rows:
            if not isinstance(status_row, dict):
                continue
            events.append(
                _create_event(
                    session,
                    occurred_utc,
                    event_type=f"status-code.{phase}",
                    scenario_name=scenario_name,
                    step_name=step_name,
                    tags={
                        "phase": phase,
                        "entity": entity,
                        "result_kind": result_kind,
                        "status_code": str(status_row.get("statusCode") or ""),
                    },
                    fields={
                        "count": status_row.get("count"),
                        "percent": status_row.get("percent"),
                        "is_error": status_row.get("isError"),
                        "message": status_row.get("message"),
                    },
                )
            )
    return events


def _scenario_fields(row: Dict[str, Any]) -> Dict[str, Any]:
    fields = {
        "all_request_count": row.get("allRequestCount"),
        "all_ok_count": row.get("allOkCount"),
        "all_fail_count": row.get("allFailCount"),
        "all_bytes": row.get("allBytes") or row.get("totalBytes"),
        "duration_ms": row.get("durationMs") or row.get("totalLatencyMs"),
        "sort_index": row.get("sortIndex"),
        "operation": row.get("currentOperation"),
        "load_simulation_name": (
            row.get("loadSimulationStats", {}).get("simulationName")
            if isinstance(row.get("loadSimulationStats"), dict)
            else None
        ),
        "load_simulation_value": (
            row.get("loadSimulationStats", {}).get("value")
            if isinstance(row.get("loadSimulationStats"), dict)
            else None
        ),
    }
    fields.update(_measurement_fields("ok", _measurement_payload(row, "ok")))
    fields.update(_measurement_fields("fail", _measurement_payload(row, "fail")))
    return fields


def _step_fields(row: Dict[str, Any]) -> Dict[str, Any]:
    fields = {
        "sort_index": row.get("sortIndex"),
    }
    fields.update(_measurement_fields("ok", _measurement_payload(row, "ok")))
    fields.update(_measurement_fields("fail", _measurement_payload(row, "fail")))
    return fields


def _merge_event_labels(event: Dict[str, Any], static_labels: Dict[str, str]) -> Dict[str, str]:
    labels = {"source": "loadstrike", "sink": "grafana_loki"}
    for key, value in static_labels.items():
        if str(value or "").strip():
            labels[_sanitize_label_key(key)] = _sanitize_label_value(value)
    for key, value in _to_string_dict(event.get("tags")).items():
        if str(value or "").strip():
            labels[_sanitize_label_key(key)] = _sanitize_label_value(value)
    return labels


def _event_to_influx_line(measurement: str, event: Dict[str, Any], static_tags: Dict[str, str]) -> str:
    tags = {"source": "loadstrike", "sink": "influxdb"}
    tags.update({key: value for key, value in static_tags.items() if str(value or "").strip()})
    tags.update(_to_string_dict(event.get("tags")))
    fields = event.get("fields") if isinstance(event.get("fields"), dict) else {}
    formatted_fields = _format_influx_fields(fields)
    if not formatted_fields:
        return ""
    tag_text = ",".join(
        f"{_escape_influx_token(key)}={_escape_influx_token(value)}"
        for key, value in sorted(tags.items())
        if str(value or "").strip()
    )
    prefix = _escape_influx_token(measurement)
    if tag_text:
        prefix = f"{prefix},{tag_text}"
    return f"{prefix} {formatted_fields} {_to_unix_nanoseconds(event['occurredUtc'])}"


def _is_metric_event_type(event_type: str) -> bool:
    normalized = str(event_type or "").lower()
    return normalized.startswith("metric.counter") or normalized.startswith("metric.gauge")


def _event_to_json(event: Dict[str, Any]) -> str:
    return json.dumps(
        {
            "eventType": event.get("eventType"),
            "occurredUtc": _iso_utc(event.get("occurredUtc")),
            "sessionId": event.get("sessionId"),
            "testSuite": event.get("testSuite"),
            "testName": event.get("testName"),
            "clusterId": event.get("clusterId"),
            "nodeType": event.get("nodeType"),
            "machineName": event.get("machineName"),
            "scenarioName": event.get("scenarioName"),
            "stepName": event.get("stepName"),
            "tags": event.get("tags"),
            "fields": event.get("fields"),
        },
        separators=(",", ":"),
    )


def _event_to_timescale_row(event: Dict[str, Any], static_tags: Dict[str, str]) -> Dict[str, Any]:
    merged_tags = {"source": "loadstrike", "sink": "timescaledb"}
    merged_tags.update({key: value for key, value in static_tags.items() if str(value or "").strip()})
    merged_tags.update(_to_string_dict(event.get("tags")))
    return {
        "occurredUtc": _iso_utc(event.get("occurredUtc")),
        "sessionId": event.get("sessionId"),
        "testSuite": event.get("testSuite"),
        "testName": event.get("testName"),
        "clusterId": event.get("clusterId"),
        "nodeType": event.get("nodeType"),
        "machineName": event.get("machineName"),
        "scenarioName": event.get("scenarioName"),
        "stepName": event.get("stepName"),
        "eventType": event.get("eventType"),
        "tags": merged_tags,
        "fields": copy.deepcopy(event.get("fields", {})),
    }


def _create_metric_projection_points(
    sink_name: str,
    events: List[Dict[str, Any]],
    static_tags: Dict[str, str],
) -> List[_ReportingSinkMetricPoint]:
    points: List[_ReportingSinkMetricPoint] = []
    for event in events:
        metric_tags = _build_metric_projection_tags(sink_name, event, static_tags)
        event_type = str(event.get("eventType") or "")
        is_counter_event = event_type.lower().startswith("metric.counter")
        is_gauge_event = event_type.lower().startswith("metric.gauge")
        tags = _to_string_dict(event.get("tags"))
        fields = event.get("fields") if isinstance(event.get("fields"), dict) else {}
        metric_name = tags.get("metric_name")
        unit_of_measure = str(fields.get("unit_of_measure") or "").strip() or None

        if (is_counter_event or is_gauge_event) and _is_finite_number_like(fields.get("value")):
            points.append(
                _ReportingSinkMetricPoint(
                    metric_name=_build_custom_metric_name(metric_name),
                    metric_kind="count" if is_counter_event else "gauge",
                    occurred_utc=event.get("occurredUtc")
                    if isinstance(event.get("occurredUtc"), datetime)
                    else datetime.now(timezone.utc),
                    value=_to_numeric_value(fields.get("value")),
                    unit_of_measure=unit_of_measure,
                    tags=metric_tags,
                )
            )

        for field_name, field_value in fields.items():
            normalized_field_name = str(field_name)
            if normalized_field_name.lower() == "unit_of_measure":
                continue
            if (is_counter_event or is_gauge_event) and normalized_field_name.lower() == "value":
                continue
            if not _is_finite_number_like(field_value):
                continue
            points.append(
                _ReportingSinkMetricPoint(
                    metric_name=_build_event_metric_name(event_type, normalized_field_name),
                    metric_kind="gauge",
                    occurred_utc=event.get("occurredUtc")
                    if isinstance(event.get("occurredUtc"), datetime)
                    else datetime.now(timezone.utc),
                    value=_to_numeric_value(field_value),
                    unit_of_measure=_infer_unit_of_measure(normalized_field_name),
                    tags=metric_tags,
                )
            )
    return points


def _build_metric_projection_tags(
    sink_name: str,
    event: Dict[str, Any],
    static_tags: Dict[str, str],
) -> Dict[str, str]:
    merged = {
        "source": "loadstrike",
        "sink": sink_name,
        "event_type": str(event.get("eventType") or ""),
        "session_id": str(event.get("sessionId") or ""),
        "test_suite": str(event.get("testSuite") or "").strip() or "default",
        "test_name": str(event.get("testName") or "").strip() or "loadstrike",
        "cluster_id": str(event.get("clusterId") or "").strip() or "default",
        "node_type": str(event.get("nodeType") or "").strip() or "SingleNode",
        "machine_name": str(event.get("machineName") or "").strip() or "local-machine",
    }
    scenario_name = str(event.get("scenarioName") or "").strip()
    step_name = str(event.get("stepName") or "").strip()
    if scenario_name:
        merged["scenario_name"] = scenario_name
    if step_name:
        merged["step_name"] = step_name
    merged.update({key: value for key, value in static_tags.items() if str(value or "").strip()})
    merged.update(_to_string_dict(event.get("tags")))
    return merged


def _build_custom_metric_name(metric_name: Optional[str]) -> str:
    normalized = _normalize_metric_path(metric_name or "")
    return f"loadstrike.metric.{normalized}" if normalized else "loadstrike.metric.value"


def _build_event_metric_name(event_type: str, field_name: str) -> str:
    return f"loadstrike.{_normalize_metric_path(event_type)}.{_normalize_metric_path(field_name)}"


def _normalize_metric_path(value: str) -> str:
    segments = [
        _normalize_metric_segment(segment)
        for segment in str(value or "").split(".")
        if _normalize_metric_segment(segment)
    ]
    return ".".join(segments) if segments else "value"


def _normalize_metric_segment(value: str) -> str:
    normalized: list[str] = []
    previous_underscore = False
    for ch in str(value or ""):
        if ch.isalnum():
            normalized.append(ch.lower())
            previous_underscore = False
        elif not previous_underscore:
            normalized.append("_")
            previous_underscore = True
    return "".join(normalized).strip("_")


def _is_finite_number_like(value: Any) -> bool:
    if isinstance(value, bool):
        return False
    return isinstance(value, (int, float)) and float(value) == float(value) and value not in (float("inf"), float("-inf"))


def _to_numeric_value(value: Any) -> float:
    return float(value)


def _infer_unit_of_measure(field_name: str) -> Optional[str]:
    normalized = str(field_name or "").lower()
    if normalized.endswith("_ms"):
        return "ms"
    if normalized.endswith("_bytes") or normalized.endswith("_byte"):
        return "bytes"
    return None


def _build_datadog_log_entry(sink: DatadogReportingSink, event: Dict[str, Any]) -> Dict[str, Any]:
    attributes: Dict[str, Any] = {
        "intake_type": "log",
        "event_type": event.get("eventType"),
        "occurred_utc": _iso_utc(event.get("occurredUtc")),
        "session_id": event.get("sessionId"),
        "test_suite": event.get("testSuite"),
        "test_name": event.get("testName"),
        "cluster_id": event.get("clusterId"),
        "node_type": event.get("nodeType"),
        "machine_name": event.get("machineName"),
        "scenario_name": event.get("scenarioName"),
        "step_name": event.get("stepName"),
        "tags": event.get("tags"),
        "fields": event.get("fields"),
    }
    for key, value in sink._static_attributes.items():
        if str(value or "").strip():
            attributes[key] = value
    return {
        "message": _event_to_json(event),
        "ddsource": sink._source.strip() or "loadstrike",
        "service": sink._service.strip() or "loadstrike",
        "hostname": sink._host.strip() or str(event.get("machineName") or ""),
        "status": "info",
        "ddtags": _build_datadog_tag_string(_to_string_dict(event.get("tags")), sink._static_tags),
        "attributes": attributes,
    }


def _build_datadog_tag_string(event_tags: Dict[str, str], static_tags: Dict[str, str]) -> str:
    tags = {"source": "loadstrike"}
    tags.update({key: value for key, value in static_tags.items() if str(value or "").strip()})
    tags.update({key: value for key, value in event_tags.items() if str(value or "").strip()})
    return ",".join(
        f"{_sanitize_datadog_tag_component(key)}:{_sanitize_datadog_tag_component(value)}"
        for key, value in sorted(tags.items())
    )


def _sanitize_datadog_tag_component(value: str) -> str:
    return str(value or "").strip().replace(":", "_").replace(",", "_").replace("|", "_")


def _build_splunk_base_fields(sink: SplunkReportingSink, intake_type: str) -> Dict[str, str]:
    fields = {"intake_type": intake_type}
    fields.update({key: value for key, value in sink._static_fields.items() if str(value or "").strip()})
    return fields


def _build_splunk_log_envelope(sink: SplunkReportingSink, event: Dict[str, Any]) -> Dict[str, Any]:
    fields = _build_splunk_base_fields(sink, "log")
    fields["event_type"] = str(event.get("eventType") or "")
    return {
        "time": _to_unix_seconds(event.get("occurredUtc") if isinstance(event.get("occurredUtc"), datetime) else datetime.now(timezone.utc)),
        "host": sink._host.strip() or str(event.get("machineName") or ""),
        "source": sink._source.strip() or "loadstrike",
        "sourcetype": sink._sourcetype.strip() or "_json",
        "index": sink._index.strip() or None,
        "event": {
            "intake_type": "log",
            "event_type": event.get("eventType"),
            "occurred_utc": _iso_utc(event.get("occurredUtc")),
            "session_id": event.get("sessionId"),
            "test_suite": event.get("testSuite"),
            "test_name": event.get("testName"),
            "cluster_id": event.get("clusterId"),
            "node_type": event.get("nodeType"),
            "machine_name": event.get("machineName"),
            "scenario_name": event.get("scenarioName"),
            "step_name": event.get("stepName"),
            "tags": event.get("tags"),
            "fields": event.get("fields"),
        },
        "fields": fields,
    }


def _build_splunk_metric_envelope(sink: SplunkReportingSink, point: _ReportingSinkMetricPoint) -> Dict[str, Any]:
    fields = _build_splunk_base_fields(sink, "metric")
    fields["metric_name"] = point.metric_name
    fields["metric_kind"] = point.metric_kind
    return {
        "time": _to_unix_seconds(point.occurred_utc),
        "host": sink._host.strip() or point.tags.get("machine_name") or "local-machine",
        "source": sink._source.strip() or "loadstrike",
        "sourcetype": sink._sourcetype.strip() or "_json",
        "index": sink._index.strip() or None,
        "event": {
            "intake_type": "metric",
            "metric_name": point.metric_name,
            "metric_kind": point.metric_kind,
            "occurred_utc": _iso_utc(point.occurred_utc),
            "value": point.value,
            "unit_of_measure": point.unit_of_measure,
            "tags": point.tags,
        },
        "fields": fields,
    }


def _build_otel_resource_attributes(sink_name: str, static_attributes: Dict[str, str]) -> List[Dict[str, Any]]:
    attributes = {
        "service.name": "loadstrike",
        "service.namespace": "loadstrike",
        "loadstrike.sink": sink_name,
    }
    attributes.update({key: value for key, value in static_attributes.items() if str(value or "").strip()})
    return [
        {"key": key, "value": {"stringValue": value}}
        for key, value in sorted(attributes.items())
    ]


def _build_otel_log_record(event: Dict[str, Any]) -> Dict[str, Any]:
    occurred = event.get("occurredUtc") if isinstance(event.get("occurredUtc"), datetime) else datetime.now(timezone.utc)
    return {
        "timeUnixNano": str(_to_unix_nanoseconds(occurred)),
        "observedTimeUnixNano": str(_to_unix_nanoseconds(occurred)),
        "severityText": "INFO",
        "body": {"stringValue": _event_to_json(event)},
        "attributes": _build_otel_attributes(
            {
                "intake_type": "log",
                "event_type": event.get("eventType"),
                "session_id": event.get("sessionId"),
                "test_suite": event.get("testSuite"),
                "test_name": event.get("testName"),
                "cluster_id": event.get("clusterId"),
                "node_type": event.get("nodeType"),
                "machine_name": event.get("machineName"),
                "scenario_name": event.get("scenarioName"),
                "step_name": event.get("stepName"),
                "tags": event.get("tags"),
                "fields": event.get("fields"),
            }
        ),
    }


def _build_otel_metric(
    point: _ReportingSinkMetricPoint,
    points: List[_ReportingSinkMetricPoint],
) -> Dict[str, Any]:
    data_points = [_build_otel_metric_data_point(entry) for entry in points]
    payload: Dict[str, Any] = {
        "name": point.metric_name,
        "description": "LoadStrike reporting sink metric projection",
        "unit": point.unit_of_measure,
    }
    if point.metric_kind == "gauge":
        payload["gauge"] = {"dataPoints": data_points}
    else:
        payload["sum"] = {
            "aggregationTemporality": 2,
            "isMonotonic": True,
            "dataPoints": data_points,
        }
    return payload


def _build_otel_metric_data_point(point: _ReportingSinkMetricPoint) -> Dict[str, Any]:
    return {
        "timeUnixNano": str(_to_unix_nanoseconds(point.occurred_utc)),
        "asDouble": point.value,
        "attributes": _build_otel_attributes(
            {
                **point.tags,
                "intake_type": "metric",
                "metric_kind": point.metric_kind,
            }
        ),
    }


def _build_otel_attributes(values: Dict[str, Any]) -> List[Dict[str, Any]]:
    return [
        {"key": key, "value": _to_otel_any_value(value)}
        for key, value in sorted(values.items())
        if value is not None
    ]


def _to_otel_any_value(value: Any) -> Dict[str, Any]:
    if value is None:
        return {"stringValue": ""}
    if isinstance(value, bool):
        return {"boolValue": value}
    if isinstance(value, int) and not isinstance(value, bool):
        return {"intValue": str(value)}
    if isinstance(value, float):
        return {"doubleValue": value}
    if isinstance(value, datetime):
        return {"stringValue": _iso_utc(value)}
    if isinstance(value, dict):
        return {"stringValue": json.dumps(value, separators=(",", ":"))}
    return {"stringValue": str(value)}


def _session_metadata_from_context(
    context: Optional[Dict[str, Any]],
    session: Optional[Dict[str, Any]] = None,
) -> _SinkSessionMetadata:
    payload = context or {}
    test_info = payload.get("test_info") if isinstance(payload.get("test_info"), dict) else (
        payload.get("testInfo") if isinstance(payload.get("testInfo"), dict) else {}
    )
    node_info = payload.get("node_info") if isinstance(payload.get("node_info"), dict) else (
        payload.get("nodeInfo") if isinstance(payload.get("nodeInfo"), dict) else {}
    )
    session_payload = _session_to_dict(session) if session is not None else {}
    started_utc = str(
        session_payload.get("startedUtc")
        or session_payload.get("started_utc")
        or test_info.get("createdUtc")
        or test_info.get("created_utc")
        or ""
    )
    return _SinkSessionMetadata(
        session_id=str(test_info.get("sessionId") or test_info.get("session_id") or ""),
        test_suite=str(test_info.get("testSuite") or test_info.get("test_suite") or ""),
        test_name=str(test_info.get("testName") or test_info.get("test_name") or ""),
        cluster_id=str(test_info.get("clusterId") or test_info.get("cluster_id") or ""),
        node_type=str(node_info.get("nodeType") or node_info.get("node_type") or ""),
        machine_name=str(node_info.get("machineName") or node_info.get("machine_name") or ""),
        started_utc=started_utc or datetime.now(timezone.utc).isoformat(),
    )


def _get_config_section(infra_config: Dict[str, Any], section_path: str) -> Dict[str, Any]:
    if not isinstance(infra_config, dict):
        return {}
    current: Any = infra_config
    for part in [segment for segment in str(section_path or "").split(":") if segment]:
        if isinstance(current, dict) and part in current:
            current = current[part]
            continue
        if isinstance(current, dict):
            lowered = {str(key).lower(): value for key, value in current.items()}
            current = lowered.get(part.lower())
            continue
        return {}
    return _session_to_dict(current) if isinstance(current, dict) or hasattr(current, "__dict__") else {}


def _status_code_items(value: Any) -> List[tuple[str, int]]:
    if not isinstance(value, dict):
        return []
    return [(str(key), _as_int(count)) for key, count in value.items()]


def _format_influx_fields(fields: Dict[str, Any]) -> str:
    parts: List[str] = []
    for key, value in sorted(fields.items()):
        if value is None:
            continue
        if isinstance(value, bool):
            encoded = "true" if value else "false"
        elif isinstance(value, int) and not isinstance(value, bool):
            encoded = f"{value}i"
        elif isinstance(value, float):
            encoded = format(value, "g")
        else:
            text = json.dumps(value, separators=(",", ":")) if isinstance(value, (dict, list)) else str(value)
            text = text.replace("\\", "\\\\").replace("\"", "\\\"")
            encoded = f"\"{text}\""
        parts.append(f"{_escape_influx_token(key)}={encoded}")
    return ",".join(parts)


def _normalize_field_name(value: Any) -> str:
    text = str(value or "").strip()
    if not text:
        return "value"
    normalized = []
    last_was_separator = False
    for ch in text:
        if ch.isalnum():
            normalized.append(ch.lower())
            last_was_separator = False
        elif not last_was_separator:
            normalized.append("_")
            last_was_separator = True
    return "".join(normalized).strip("_") or "value"


def _normalize_field_value(value: Any) -> Any:
    if isinstance(value, (str, bool, int, float)) or value is None:
        return value
    if isinstance(value, datetime):
        return _iso_utc(value)
    return json.dumps(value, separators=(",", ":"))


def _sanitize_label_key(value: str) -> str:
    sanitized = "".join(ch if ch.isalnum() or ch == "_" else "_" for ch in str(value or ""))
    if not sanitized or (not sanitized[0].isalpha() and sanitized[0] != "_"):
        sanitized = f"_{sanitized}"
    return sanitized


def _sanitize_label_value(value: str) -> str:
    return str(value or "").replace("\r", " ").replace("\n", " ").strip()


def _try_read_text(row: Dict[str, Any], *keys: str) -> Optional[str]:
    for key in keys:
        raw = row.get(key)
        text = str(raw or "").strip()
        if text:
            return text
    return None


def _to_unix_nanoseconds(value: Any) -> int:
    if isinstance(value, datetime):
        dt = value.astimezone(timezone.utc)
    else:
        dt = datetime.now(timezone.utc)
    return int(dt.timestamp() * 1_000_000_000)


def _iso_utc(value: Any) -> str:
    if isinstance(value, datetime):
        return value.astimezone(timezone.utc).isoformat()
    return str(value or "")


def _normalize_path(value: str) -> str:
    text = str(value or "").strip()
    if not text:
        return "/"
    return text if text.startswith("/") else f"/{text}"


def _to_unix_seconds(value: datetime) -> float:
    return value.astimezone(timezone.utc).timestamp()


def _send_json_request(
    url: str,
    payload: Any,
    *,
    headers: Optional[Dict[str, str]] = None,
    timeout_seconds: float,
    error_prefix: str,
) -> None:
    body = json.dumps(payload, separators=(",", ":")).encode("utf-8")
    _send_request(
        url,
        body,
        headers=headers,
        content_type="application/json",
        timeout_seconds=timeout_seconds,
        error_prefix=error_prefix,
    )


def _send_text_request(
    url: str,
    payload: str,
    *,
    headers: Optional[Dict[str, str]] = None,
    content_type: str,
    timeout_seconds: float,
    error_prefix: str,
) -> None:
    _send_request(
        url,
        payload.encode("utf-8"),
        headers=headers,
        content_type=content_type,
        timeout_seconds=timeout_seconds,
        error_prefix=error_prefix,
    )


def _send_request(
    url: str,
    body: bytes,
    *,
    headers: Optional[Dict[str, str]],
    content_type: str,
    timeout_seconds: float,
    error_prefix: str,
) -> None:
    request_headers = {"Content-Type": content_type}
    if headers:
        request_headers.update(headers)
    request = Request(url, method="POST", data=body, headers=request_headers)
    try:
        with urlopen(request, timeout=timeout_seconds) as response:
            if int(getattr(response, "status", 200)) >= 400:
                response_body = response.read().decode("utf-8", errors="replace")
                raise RuntimeError(f"{error_prefix} write failed with status {response.status}: {response_body}")
    except HTTPError as error:
        response_body = error.read().decode("utf-8", errors="replace")
        raise RuntimeError(f"{error_prefix} write failed with status {error.code}: {response_body}") from error
    except URLError as error:
        raise RuntimeError(f"{error_prefix} write failed: {error}") from error


def _escape_influx_token(value: str) -> str:
    return (
        str(value or "")
        .replace("\\", "\\\\")
        .replace(",", "\\,")
        .replace(" ", "\\ ")
        .replace("=", "\\=")
    )


def _session_to_dict(session: Any) -> Dict[str, Any]:
    if isinstance(session, dict):
        return dict(session)
    if hasattr(session, "to_dict") and callable(session.to_dict):
        value = session.to_dict()
        if isinstance(value, dict):
            return dict(value)
    data = getattr(session, "__dict__", None)
    if isinstance(data, dict):
        return dict(data)
    return {"value": session}


def _to_string_dict(value: Any) -> Dict[str, str]:
    if not isinstance(value, dict):
        return {}
    return {
        str(key): str(item)
        for key, item in value.items()
        if str(key or "").strip() and item is not None and str(item).strip()
    }


def _as_int(value: Any) -> int:
    if isinstance(value, bool):
        return int(value)
    if isinstance(value, (int, float)):
        return int(value)
    try:
        return int(str(value))
    except (TypeError, ValueError):
        return 0


def _as_float(value: Any) -> float:
    if isinstance(value, bool):
        return float(value)
    if isinstance(value, (int, float)):
        return float(value)
    try:
        return float(str(value))
    except (TypeError, ValueError):
        return 0.0
