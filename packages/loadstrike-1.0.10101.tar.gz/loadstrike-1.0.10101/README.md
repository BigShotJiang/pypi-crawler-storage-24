# LoadStrike for Python

LoadStrike is a Python SDK for defining and running load, traffic-correlation, and reporting scenarios directly inside your application or test process.

## Requirements

- Python 3.9 or later

## Install

```bash
pip install LoadStrike
```

## What It Provides

- Scenario, step, load-simulation, threshold, and metric primitives
- Native in-process execution with structured run results
- Local and distributed cluster execution helpers
- HTML, TXT, CSV, and Markdown report generation

## Supported Transports

- HTTP
- Kafka
- RabbitMQ
- NATS
- Redis Streams
- Azure Event Hubs
- Push Diffusion
- Delegate and custom stream endpoints

## Supported Reporting Sinks

- InfluxDB
- TimescaleDB
- Grafana Loki
- Datadog
- Splunk HEC
- OpenTelemetry Collector

## Quick Start

```python
from loadstrike_sdk import (
    LoadStrikeResponse,
    LoadStrikeRunner,
    LoadStrikeScenario,
    LoadStrikeSimulation,
    LoadStrikeStep,
)

scenario = (
    LoadStrikeScenario.create(
        "orders",
        lambda context: LoadStrikeStep.run(
            "publish-order",
            context,
            lambda: LoadStrikeResponse.ok("200"),
        )["as_reply"](),
    )
    .with_load_simulations(LoadStrikeSimulation.inject(10, 1, 20))
)

result = (
    LoadStrikeRunner.register_scenarios(scenario)
    .with_runner_key("rkl_your_runner_key")
    .run()
)
```

A valid `RunnerKey` is required to execute live workloads.

## Documentation

https://loadstrike.com/documentation
