"""
Geode-Hybrid_Geosciences Python binding for Pillar
"""
from __future__ import annotations
import collections.abc
import opengeode.lib64.opengeode_py_basic
__all__: list[str] = ['HybridGeosciencesPillarLibrary', 'PillarStructuralModelBuilder', 'PillarStructuralModelBuilderResult', 'PillarStructuralModelInspectionResult', 'PillarStructuralModelOptions']
class HybridGeosciencesPillarLibrary:
    @staticmethod
    def initialize() -> None:
        ...
class PillarStructuralModelBuilder:
    def build(self, arg0: PillarStructuralModelOptions) -> PillarStructuralModelBuilderResult:
        ...
    def is_model_construction_possible(self) -> PillarStructuralModelInspectionResult:
        ...
class PillarStructuralModelBuilderResult:
    @property
    def slice_collection_order(self) -> list[opengeode.lib64.opengeode_py_basic.uuid]:
        ...
    @slice_collection_order.setter
    def slice_collection_order(self, arg0: collections.abc.Sequence[opengeode.lib64.opengeode_py_basic.uuid]) -> None:
        ...
class PillarStructuralModelInspectionResult:
    def string(self) -> str:
        ...
class PillarStructuralModelOptions:
    add_block_mesh: bool
