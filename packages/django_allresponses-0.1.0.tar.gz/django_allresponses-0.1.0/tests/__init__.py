"""
Test package for django-allresponses.
"""
