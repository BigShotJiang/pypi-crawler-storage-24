"""
Test app configuration for django-allresponses.
"""

from django.apps import AppConfig


class TestsConfig(AppConfig):
    """Test app configuration."""

    name = "tests"
    label = "tests"
