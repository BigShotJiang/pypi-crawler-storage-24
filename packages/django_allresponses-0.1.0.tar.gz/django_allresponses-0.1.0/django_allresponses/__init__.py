"""
Response classes for every HTTP status code (RFC 9110).

All classes are subclasses of Django’s `HttpResponse <https://docs.djangoproject.com/en/stable/ref/request-response/#django.http.HttpResponse>`_.
Import from here to get every status-code class in one place; see each
class’s docstring for when to use it.

**HttpResponse\\*** — For HTML, plain text, or arbitrary content. These
classes (e.g. :class:`HttpResponseOK`, :class:`HttpResponseCreated`) extend
`HttpResponse <https://docs.djangoproject.com/en/stable/ref/request-response/#django.http.HttpResponse>`_ and set the appropriate status code (and
headers where the spec requires it).

**JsonResponse\\*** — For JSON APIs. These classes (e.g. :class:`JsonResponseOK`,
:class:`JsonResponseCreated`, :class:`JsonResponseBadRequest`) extend Django’s
`JsonResponse <https://docs.djangoproject.com/en/stable/ref/request-response/#django.http.JsonResponse>`_ and set the status code; pass a dict (or
other JSON-serialisable data) as the first argument.

Example (HttpResponse)::

    from django_allresponses import (
        HttpResponseOK,
        HttpResponseNoContent,
        HttpResponseCreated,
    )

    def my_view(request):
        if request.method == "GET":
            return HttpResponseOK("<html>...</html>")
        if request.method == "DELETE":
            do_delete()
            return HttpResponseNoContent()
        new = create_resource()
        return HttpResponseCreated(location=new.get_absolute_url(), created_document=new.get_created_document())

Example (JsonResponse)::

    from django_allresponses import JsonResponseOK, JsonResponseCreated

    def api_view(request):
        return JsonResponseCreated({"id": 1, "name": "New"}, location="/api/items/1")
"""

__version__ = "0.1.0"

# Order by status code (100, 101, 200, 201, ...), not alphabetically
# isort:off
from django_allresponses.responses import (
    HttpResponse,
    retry_after_value,
    set_content_location,
    HttpResponseContinue,  # 100
    HttpResponseSwitchingProtocols,  # 101
    HttpResponseOK,  # 200
    HttpResponseCreated,  # 201
    HttpResponseAccepted,  # 202
    HttpResponseNonAuthoritativeInformation,  # 203
    HttpResponseNoContent,  # 204
    HttpResponseResetContent,  # 205
    HttpResponsePartialContent,  # 206
    HttpResponseMultipleChoices,  # 300
    HttpResponseMovedPermanently,  # 301
    HttpResponseFound,  # 302
    HttpResponseSeeOther,  # 303
    HttpResponseNotModified,  # 304
    HttpResponseUseProxy,  # 305
    HttpResponseTemporaryRedirect,  # 307
    HttpResponsePermanentRedirect,  # 308
    HttpResponseBadRequest,  # 400
    HttpResponseUnauthorized,  # 401
    HttpResponsePaymentRequired,  # 402
    HttpResponseForbidden,  # 403
    HttpResponseNotFound,  # 404
    HttpResponseNotAllowed,  # 405
    HttpResponseNotAcceptable,  # 406
    HttpResponseProxyAuthenticationRequired,  # 407
    HttpResponseRequestTimeout,  # 408
    HttpResponseConflict,  # 409
    HttpResponseGone,  # 410
    HttpResponseLengthRequired,  # 411
    HttpResponsePreconditionFailed,  # 412
    HttpResponseContentTooLarge,  # 413
    HttpResponseUriTooLong,  # 414
    HttpResponseUnsupportedMediaType,  # 415
    HttpResponseRangeNotSatisfiable,  # 416
    HttpResponseExpectationFailed,  # 417
    HttpResponseMisdirectedRequest,  # 421
    HttpResponseUnprocessableContent,  # 422
    HttpResponseUpgradeRequired,  # 426
    HttpResponseInternalServerError,  # 500
    HttpResponseNotImplemented,  # 501
    HttpResponseBadGateway,  # 502
    HttpResponseServiceUnavailable,  # 503
    HttpResponseGatewayTimeout,  # 504
    HttpResponseHttpVersionNotSupported,  # 505
)
# isort:on

from django_allresponses.jsonresponses import (
    JsonResponseOK,
    JsonResponseCreated,
    JsonResponseBadRequest,
    JsonResponseUnauthorized,
    JsonResponsePaymentRequired,
    JsonResponseForbidden,
    JsonResponseNotFound,
    JsonResponseNotAllowed,
    JsonResponseNotAcceptable,
    JsonResponseConflict,
    JsonResponseUnprocessableContent,
    JsonResponseServerError,
    JsonResponseServiceUnavailable,
)

__all__ = [
    "HttpResponse",
    "retry_after_value",
    "set_content_location",
    "HttpResponseContinue",
    "HttpResponseSwitchingProtocols",
    "HttpResponseOK",
    "HttpResponseCreated",
    "HttpResponseAccepted",
    "HttpResponseNonAuthoritativeInformation",
    "HttpResponseNoContent",
    "HttpResponseResetContent",
    "HttpResponsePartialContent",
    "HttpResponseMultipleChoices",
    "HttpResponseMovedPermanently",
    "HttpResponseFound",
    "HttpResponseSeeOther",
    "HttpResponseNotModified",
    "HttpResponseUseProxy",
    "HttpResponseTemporaryRedirect",
    "HttpResponsePermanentRedirect",
    "HttpResponseBadRequest",
    "HttpResponseUnauthorized",
    "HttpResponsePaymentRequired",
    "HttpResponseForbidden",
    "HttpResponseNotFound",
    "HttpResponseNotAllowed",
    "HttpResponseNotAcceptable",
    "HttpResponseProxyAuthenticationRequired",
    "HttpResponseRequestTimeout",
    "HttpResponseConflict",
    "HttpResponseGone",
    "HttpResponseLengthRequired",
    "HttpResponsePreconditionFailed",
    "HttpResponseContentTooLarge",
    "HttpResponseUriTooLong",
    "HttpResponseUnsupportedMediaType",
    "HttpResponseRangeNotSatisfiable",
    "HttpResponseExpectationFailed",
    "HttpResponseMisdirectedRequest",
    "HttpResponseUnprocessableContent",
    "HttpResponseUpgradeRequired",
    "HttpResponseInternalServerError",
    "HttpResponseNotImplemented",
    "HttpResponseBadGateway",
    "HttpResponseServiceUnavailable",
    "HttpResponseGatewayTimeout",
    "HttpResponseHttpVersionNotSupported",
    "JsonResponseOK",
    "JsonResponseCreated",
    "JsonResponseBadRequest",
    "JsonResponseUnauthorized",
    "JsonResponsePaymentRequired",
    "JsonResponseForbidden",
    "JsonResponseNotFound",
    "JsonResponseNotAllowed",
    "JsonResponseNotAcceptable",
    "JsonResponseConflict",
    "JsonResponseUnprocessableContent",
    "JsonResponseServerError",
    "JsonResponseServiceUnavailable",
]
