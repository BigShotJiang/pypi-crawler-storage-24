# Open Source Attributions

Thetis uses third-party components which we list in this document. We
provide the full license terms for each of these components in the
corresponding subdirectories in the directory thirdparty-licenses.

Some licenses require the provision of physical copies of source or object
code. In this case, you may obtain a copy of the source codes by contacting us
at info@efs-techhub.com. Furthermore please contact us under the foregoing
email-address in case you need assistance regarding the exercise of rights
guaranteed by an Open Source License. A nominal fee (i.e., the cost of
physically performing the distribution) will be charged for these services.

Note: your copy of this product may not contain code covered by one or more of
the licenses listed here, depending on the exact product and version you
choose.

## absl-py

* Version: 2.4.0
* URL: https://github.com/abseil/abseil-py
* License: Apache License 2.0
* Full license text: thirdparty-licenses/absl-py-2.4.0

## aiohappyeyeballs

* Version: 2.6.1
* URL: https://github.com/aio-libs/aiohappyeyeballs
* License: Python Software Foundation License 2.0
* Full license text: thirdparty-licenses/aiohappyeyeballs-2.6.1

## aiohttp

* Version: 3.13.3
* URL: https://github.com/aio-libs/aiohttp
* License: Apache License 2.0
* Full license text: thirdparty-licenses/aiohttp-3.13.3

## aiosignal

* Version: 1.4.0
* URL: https://github.com/aio-libs/aiosignal
* License: Apache License 2.0
* Full license text: thirdparty-licenses/aiosignal-1.4.0

## annotated-doc

* Version: 0.0.4
* URL: https://github.com/fastapi/annotated-doc
* License: MIT License
* Full license text: thirdparty-licenses/annotated-doc-0.0.4

## annotated-types

* Version: 0.7.0
* URL: https://github.com/annotated-types/annotated-types
* License: MIT License
* Full license text: thirdparty-licenses/annotated-types-0.7.0

## anyio

* Version: 4.12.1
* URL: https://anyio.readthedocs.io/en/stable/versionhistory.html
* License: MIT License
* Full license text: thirdparty-licenses/anyio-4.12.1

## async-timeout

* Version: 5.0.1
* URL: https://github.com/aio-libs/async-timeout
* License: Apache License 2.0
* Full license text: thirdparty-licenses/async-timeout-5.0.1

## attrs

* Version: 25.4.0
* URL: https://www.attrs.org/en/stable/changelog.html
* License: MIT License
* Full license text: thirdparty-licenses/attrs-25.4.0

## backoff

* Version: 2.2.1
* URL: https://github.com/litl/backoff
* License: MIT License
* Full license text: thirdparty-licenses/backoff-2.2.1

## backports.asyncio.runner

* Version: 1.2.0
* URL: https://github.com/samypr100/backports.asyncio.runner
* License: Python Software Foundation License 2.0
* Full license text: thirdparty-licenses/backports.asyncio.runner-1.2.0

## certifi

* Version: 2026.2.25
* URL: https://github.com/certifi/python-certifi
* License: Mozilla Public License 2.0
* Full license text: thirdparty-licenses/certifi-2026.2.25

## charset-normalizer

* Version: 3.4.4
* URL: https://github.com/jawah/charset_normalizer/blob/master/CHANGELOG.md
* License: MIT License
* Full license text: thirdparty-licenses/charset-normalizer-3.4.4

## click

* Version: 8.3.1
* URL: https://github.com/pallets/click/
* License: BSD 3-Clause "New" or "Revised" License
* Full license text: thirdparty-licenses/click-8.3.1

## colorama

* Version: 0.4.6
* URL: https://github.com/tartley/colorama
* License: BSD 3-Clause "New" or "Revised" License
* Full license text: thirdparty-licenses/colorama-0.4.6

## contourpy

* Version: 1.3.2
* URL: https://github.com/contourpy/contourpy
* License: BSD 3-Clause "New" or "Revised" License
* Full license text: thirdparty-licenses/contourpy-1.3.2

## cycler

* Version: 0.12.1
* URL: https://matplotlib.org/cycler/
* License: BSD 3-Clause "New" or "Revised" License
* Full license text: thirdparty-licenses/cycler-0.12.1

## deepeval

* Version: 3.8.8
* URL: https://github.com/confident-ai/deepeval
* License: Apache License 2.0
* Full license text: thirdparty-licenses/deepeval-3.8.8

## distro

* Version: 1.9.0
* URL: https://github.com/python-distro/distro
* License: Apache License 2.0
* Full license text: thirdparty-licenses/distro-1.9.0

## docutils

* Version: 0.20.1
* URL: https://docutils.sourceforge.io/
* Full license text: thirdparty-licenses/docutils-0.20.1

## exceptiongroup

* Version: 1.3.1
* URL: https://github.com/agronholm/exceptiongroup/blob/main/CHANGES.rst
* License: MIT License
* Full license text: thirdparty-licenses/exceptiongroup-1.3.1

## filelock

* Version: 3.24.3
* URL: https://github.com/tox-dev/py-filelock
* License: MIT License
* Full license text: thirdparty-licenses/filelock-3.24.3

## frozenlist

* Version: 1.8.0
* URL: https://github.com/aio-libs/frozenlist
* License: Apache License 2.0
* Full license text: thirdparty-licenses/frozenlist-1.8.0

## fsspec

* Version: 2026.2.0
* URL: https://github.com/fsspec/filesystem_spec
* License: BSD 3-Clause "New" or "Revised" License
* Full license text: thirdparty-licenses/fsspec-2026.2.0

## grpcio

* Version: 1.78.0
* URL: https://grpc.io
* License: Apache License 2.0
* Full license text: thirdparty-licenses/grpcio-1.78.0

## h11

* Version: 0.16.0
* URL: https://github.com/python-hyper/h11
* License: MIT License
* Full license text: thirdparty-licenses/h11-0.16.0

## hf-xet

* Version: 1.3.1
* URL: https://github.com/huggingface/xet-core
* License: Apache License 2.0
* Full license text: thirdparty-licenses/hf-xet-1.3.1

## httpcore

* Version: 1.0.9
* URL: https://www.encode.io/httpcore/
* License: BSD 3-Clause "New" or "Revised" License
* Full license text: thirdparty-licenses/httpcore-1.0.9

## httpx

* Version: 0.28.1
* URL: https://github.com/encode/httpx
* License: BSD 2-Clause "Simplified" License
* Full license text: thirdparty-licenses/httpx-0.28.1

## huggingface_hub

* Version: 1.5.0
* URL: https://github.com/huggingface/huggingface_hub
* License: Apache License 2.0
* Full license text: thirdparty-licenses/huggingface_hub-1.5.0

## idna

* Version: 3.11
* URL: https://github.com/kjd/idna
* License: BSD 3-Clause "New" or "Revised" License
* Full license text: thirdparty-licenses/idna-3.11

## importlib_metadata

* Version: 8.7.1
* URL: https://github.com/python/importlib_metadata
* License: Apache License 2.0
* Full license text: thirdparty-licenses/importlib_metadata-8.7.1

## Jinja2

* Version: 3.1.6
* URL: https://github.com/pallets/jinja/
* License: BSD 3-Clause "New" or "Revised" License
* Full license text: thirdparty-licenses/Jinja2-3.1.6

## jiter

* Version: 0.13.0
* URL: https://github.com/pydantic/jiter/
* License: MIT License
* Full license text: thirdparty-licenses/jiter-0.13.0

## joblib

* Version: 1.5.3
* URL: https://joblib.readthedocs.io
* License: BSD 3-Clause "New" or "Revised" License
* Full license text: thirdparty-licenses/joblib-1.5.3

## kiwisolver

* Version: 1.4.9
* URL: https://github.com/nucleic/kiwi
* License: BSD 3-Clause "New" or "Revised" License
* Full license text: thirdparty-licenses/kiwisolver-1.4.9

## markdown-it-py

* Version: 4.0.0
* URL: https://github.com/executablebooks/markdown-it-py
* License: MIT License
* Full license text: thirdparty-licenses/markdown-it-py-4.0.0

## MarkupSafe

* Version: 3.0.3
* URL: https://github.com/pallets/markupsafe/
* License: BSD 3-Clause "New" or "Revised" License
* Full license text: thirdparty-licenses/MarkupSafe-3.0.3

## matplotlib

* Version: 3.10.8
* URL: https://matplotlib.org
* Full license text: thirdparty-licenses/matplotlib-3.10.8

## mdurl

* Version: 0.1.2
* URL: https://github.com/executablebooks/mdurl
* License: MIT License
* Full license text: thirdparty-licenses/mdurl-0.1.2

## multidict

* Version: 6.7.1
* URL: https://github.com/aio-libs/multidict
* License: Apache License 2.0
* Full license text: thirdparty-licenses/multidict-6.7.1

## nest-asyncio

* Version: 1.6.0
* URL: https://github.com/erdewit/nest_asyncio
* License: BSD 2-Clause "Simplified" License
* Full license text: thirdparty-licenses/nest-asyncio-1.6.0

## nltk

* Version: 3.9.3
* URL: https://www.nltk.org/
* License: Apache License 2.0
* Full license text: thirdparty-licenses/nltk-3.9.3

## ntplib

* Version: 0.4.0
* URL: https://github.com/cf-natali/ntplib
* License: MIT License
* Full license text: thirdparty-licenses/ntplib-0.4.0

## Nuitka

* Version: 4.0.1
* URL: https://nuitka.net/
* License: Apache License 2.0
* Full license text: thirdparty-licenses/Nuitka-4.0.1

## numpy

* Version: 2.2.6
* URL: https://numpy.org
* Full license text: thirdparty-licenses/numpy-2.2.6

## openai

* Version: 2.24.0
* URL: https://github.com/openai/openai-python
* License: Apache License 2.0
* Full license text: thirdparty-licenses/openai-2.24.0

## opentelemetry-api

* Version: 1.39.1
* URL: https://github.com/open-telemetry/opentelemetry-python/tree/main/opentelemetry-api
* License: Apache License 2.0
* Full license text: thirdparty-licenses/opentelemetry-api-1.39.1

## opentelemetry-sdk

* Version: 1.39.1
* URL: https://github.com/open-telemetry/opentelemetry-python/tree/main/opentelemetry-sdk
* License: Apache License 2.0
* Full license text: thirdparty-licenses/opentelemetry-sdk-1.39.1

## opentelemetry-semantic-conventions

* Version: 0.60b1
* URL: https://github.com/open-telemetry/opentelemetry-python/tree/main/opentelemetry-semantic-conventions
* License: Apache License 2.0
* Full license text: thirdparty-licenses/opentelemetry-semantic-conventions-0.60b1

## packaging

* Version: 26.0
* URL: https://github.com/pypa/packaging
* Full license text: thirdparty-licenses/packaging-26.0

## pandas

* Version: 2.3.3
* URL: https://pandas.pydata.org
* Full license text: thirdparty-licenses/pandas-2.3.3

## pillow

* Version: 12.1.1
* URL: https://python-pillow.github.io
* Full license text: thirdparty-licenses/pillow-12.1.1
* Note: Portions of this software are based on the FreeType Project (www.freetype.org) and on the work of the Independent JPEG Group.

## portalocker

* Version: 3.2.0
* URL: https://github.com/wolph/portalocker/
* License: BSD 3-Clause "New" or "Revised" License
* Full license text: thirdparty-licenses/portalocker-3.2.0

## posthog

* Version: 5.4.0
* URL: https://github.com/posthog/posthog-python
* License: MIT License
* Full license text: thirdparty-licenses/posthog-5.4.0

## propcache

* Version: 0.4.1
* URL: https://github.com/aio-libs/propcache
* License: Apache License 2.0
* Full license text: thirdparty-licenses/propcache-0.4.1

## pyarrow

* Version: 23.0.1
* URL: https://arrow.apache.org/
* License: Apache License 2.0
* Full license text: thirdparty-licenses/pyarrow-23.0.1

## pycryptodome

* Version: 3.23.0
* URL: https://www.pycryptodome.org
* Full license text: thirdparty-licenses/pycryptodome-3.23.0

## pydantic

* Version: 2.12.5
* URL: https://github.com/pydantic/pydantic
* License: MIT License
* Full license text: thirdparty-licenses/pydantic-2.12.5

## pydantic-settings

* Version: 2.13.1
* URL: https://github.com/pydantic/pydantic-settings
* License: MIT License
* Full license text: thirdparty-licenses/pydantic-settings-2.13.1

## pydantic_core

* Version: 2.41.5
* URL: https://github.com/pydantic/pydantic-core
* License: MIT License
* Full license text: thirdparty-licenses/pydantic_core-2.41.5

## Pygments

* Version: 2.19.2
* URL: https://pygments.org
* License: BSD 2-Clause "Simplified" License
* Full license text: thirdparty-licenses/Pygments-2.19.2

## pyparsing

* Version: 3.3.2
* URL: https://github.com/pyparsing/pyparsing/
* License: MIT License
* Full license text: thirdparty-licenses/pyparsing-3.3.2

## Python

* Version: 3.10.12
* URL: https://www.python.org/
* License: Python License 2.0.1
* Full license text: thirdparty-licenses/Python-3.10.12

## python-dateutil

* Version: 2.9.0.post0
* URL: https://github.com/dateutil/dateutil
* Full license text: thirdparty-licenses/python-dateutil-2.9.0.post0

## python-dotenv

* Version: 1.2.1
* URL: https://github.com/theskumar/python-dotenv
* License: BSD 3-Clause "New" or "Revised" License
* Full license text: thirdparty-licenses/python-dotenv-1.2.1

## pytz

* Version: 2025.2
* URL: http://pythonhosted.org/pytz
* License: MIT License
* Full license text: thirdparty-licenses/pytz-2025.2

## PyYAML

* Version: 6.0.3
* URL: https://pyyaml.org/
* License: MIT License
* Full license text: thirdparty-licenses/PyYAML-6.0.3

## regex

* Version: 2026.2.19
* URL: https://github.com/mrabarnett/mrab-regex
* Full license text: thirdparty-licenses/regex-2026.2.19

## reportlab

* Version: 4.0.7
* URL: https://www.reportlab.com/
* License: BSD 3-Clause "New" or "Revised" License
* Full license text: thirdparty-licenses/reportlab-4.0.7

## requests

* Version: 2.32.5
* URL: https://requests.readthedocs.io
* License: Apache License 2.0
* Full license text: thirdparty-licenses/requests-2.32.5

## rich

* Version: 14.3.3
* URL: https://github.com/Textualize/rich
* License: MIT License
* Full license text: thirdparty-licenses/rich-14.3.3

## rouge_score

* Version: 0.1.2
* URL: https://github.com/google-research/google-research/tree/master/rouge
* License: Apache License 2.0
* Full license text: thirdparty-licenses/rouge_score-0.1.2

## rst2pdf

* Version: 0.102
* URL: https://rst2pdf.org
* License: MIT License
* Full license text: thirdparty-licenses/rst2pdf-0.102

## scikit-learn

* Version: 1.7.2
* URL: https://scikit-learn.org
* Full license text: thirdparty-licenses/scikit-learn-1.7.2

## scipy

* Version: 1.15.3
* URL: https://scipy.org/
* Full license text: thirdparty-licenses/scipy-1.15.3

## sentry-sdk

* Version: 2.53.0
* URL: https://github.com/getsentry/sentry-python
* License: MIT License
* Full license text: thirdparty-licenses/sentry-sdk-2.53.0

## shellingham

* Version: 1.5.4
* URL: https://github.com/sarugaku/shellingham
* License: ISC License
* Full license text: thirdparty-licenses/shellingham-1.5.4

## six

* Version: 1.17.0
* URL: https://github.com/benjaminp/six
* License: MIT License
* Full license text: thirdparty-licenses/six-1.17.0

## smartypants

* Version: 2.0.2
* URL: https://github.com/justinmayer/smartypants.py
* Full license text: thirdparty-licenses/smartypants-2.0.2

## sniffio

* Version: 1.3.1
* URL: https://github.com/python-trio/sniffio
* License: Apache License 2.0
* Full license text: thirdparty-licenses/sniffio-1.3.1

## strictyaml

* Version: 1.7.3
* URL: https://hitchdev.com/strictyaml
* License: MIT License
* Full license text: thirdparty-licenses/strictyaml-1.7.3

## tenacity

* Version: 9.1.4
* URL: https://github.com/jd/tenacity
* License: Apache License 2.0
* Full license text: thirdparty-licenses/tenacity-9.1.4

## threadpoolctl

* Version: 3.6.0
* URL: https://github.com/joblib/threadpoolctl
* License: BSD 3-Clause "New" or "Revised" License
* Full license text: thirdparty-licenses/threadpoolctl-3.6.0

## tomli

* Version: 2.4.0
* URL: https://github.com/hukkin/tomli
* License: MIT License
* Full license text: thirdparty-licenses/tomli-2.4.0

## tqdm

* Version: 4.67.3
* URL: https://tqdm.github.io
* Full license text: thirdparty-licenses/tqdm-4.67.3

## typer

* Version: 0.24.1
* URL: https://github.com/fastapi/typer
* License: MIT License
* Full license text: thirdparty-licenses/typer-0.24.1

## typing-inspection

* Version: 0.4.2
* URL: https://github.com/pydantic/typing-inspection
* License: MIT License
* Full license text: thirdparty-licenses/typing-inspection-0.4.2

## typing_extensions

* Version: 4.15.0
* URL: https://github.com/python/typing_extensions
* License: Python Software Foundation License 2.0
* Full license text: thirdparty-licenses/typing_extensions-4.15.0

## urllib3

* Version: 2.6.3
* URL: https://github.com/urllib3/urllib3/blob/main/CHANGES.rst
* License: MIT License
* Full license text: thirdparty-licenses/urllib3-2.6.3

## yarl

* Version: 1.22.0
* URL: https://github.com/aio-libs/yarl
* License: Apache License 2.0
* Full license text: thirdparty-licenses/yarl-1.22.0

## zipp

* Version: 3.23.0
* URL: https://github.com/jaraco/zipp
* License: MIT License
* Full license text: thirdparty-licenses/zipp-3.23.0

