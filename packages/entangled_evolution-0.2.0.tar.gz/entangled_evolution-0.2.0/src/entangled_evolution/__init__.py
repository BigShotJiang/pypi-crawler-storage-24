from importlib.metadata import PackageNotFoundError, version

# ---------------- Version ----------------

try:
    __version__ = version("entangled_evolution")
except PackageNotFoundError:
    __version__ = "0.0.0"


# ---------------- Models ----------------

from .models import (
    clv_replicator,
    core_replicator,
)

# Explicit, descriptive aliases (recommended for users / papers)
competitive_lotka_volterra_replicator = clv_replicator
consumer_resource_replicator = core_replicator
standard_replicator = clv_replicator
soft_replicator = core_replicator


# ---------------- Entanglement ----------------

from .entanglement import (
    angular_entanglement,
    abcn_entanglement,
    an_entanglement,
    add_archetype
)


# ---------------- Simulation ----------------

from .sim import (
    simulate,
    simulate_ensemble,
)


# ---------------- Parameters ----------------

from .params import (
    SimulationParams,
    EnsembleParams,
    StatsParams,
)


# ---------------- Statistics ----------------

from .stats import (
    compute_stats,
    compute_fixation_fraction,
    compute_fixation_frequency,
    compute_extinction_rank,
    compute_hmean_extinction_time,
    compute_mean_extinction_time,
    compute_mean_extinction_rate,
)

# ---------------- Public API ----------------

__all__ = [
    "__version__",

    # models
    "clv_replicator",
    "core_replicator",
    "competitive_lotka_volterra_replicator",
    "consumer_resource_replicator",
    "standard_replicator",
    "soft_replicator",

    # entanglement
    "angular_entanglement",
    "abcn_entanglement",
    "an_entanglement",
    "add_archetype",

    # simulation
    "simulate",
    "simulate_ensemble",

    # parameters
    "SimulationParams",
    "EnsembleParams",
    "StatsParams",

    # statistics
    "compute_stats",
    "compute_fixation_fraction",
    "compute_fixation_frequency",
    "compute_extinction_rank",
    "compute_hmean_extinction_time",
    "compute_mean_extinction_time",
    "compute_mean_extinction_rate",
]