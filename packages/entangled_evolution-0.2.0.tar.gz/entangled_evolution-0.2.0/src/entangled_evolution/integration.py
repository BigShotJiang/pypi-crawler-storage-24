import numpy as np
from .models import fitness_function

def noise_increment(z, entanglement, dt, tau,rng):
    (N, M) = entanglement.shape
    a = np.exp(-dt / tau)
    dz = (a - 1) * z + np.sqrt(1 - a*a) * entanglement @ rng.standard_normal(M)
    return dz


def euler_step(model, x, z, dt, mean_fitness, coeff_var_fitness, reproduction_rate, entanglement, tau,rng):
    fitness = fitness_function(z, mean_fitness, coeff_var_fitness)
    x_new = x + dt * reproduction_rate * model(x, fitness=fitness)
    z_new = z + noise_increment(z, entanglement=entanglement, dt=dt, tau=tau,rng=rng)
    return x_new, z_new


def rk4_step(model, x, z, dt, mean_fitness, coeff_var_fitness, reproduction_rate, entanglement, tau, rng):
    fitness = fitness_function(z, mean_fitness, coeff_var_fitness)
    def f(x_):
        return reproduction_rate * model(x_, fitness=fitness)
    k1 = f(x)
    k2 = f(x + 0.5 * dt * k1)
    k3 = f(x + 0.5 * dt * k2)
    k4 = f(x + dt * k3)
    x_new = x + (dt / 6.0) * (k1 + 2*k2 + 2*k3 + k4)
    z_new = z + noise_increment(z, entanglement=entanglement, dt=dt, tau=tau,rng=rng)
    return x_new, z_new

def integrate_step(model, reproduction_rate, x, z, mean_fitness, coeff_var_fitness, entanglement, dt, tau, method,rng):
    """
    Wrapper for integration methods. Defaults to rk4 (RK4 for x, exact OUP for z).
    """
    if method == "rk4":
        return rk4_step(model, x, z, dt, mean_fitness, coeff_var_fitness, reproduction_rate, entanglement, tau,rng)    
    elif method == "euler":
        return euler_step(model, x, z, dt, mean_fitness, coeff_var_fitness, reproduction_rate, entanglement, tau, rng)
    else:
        raise ValueError(f"Unknown integration method: {method}. Use 'rk4' or 'euler'.")

