# -*- coding: utf-8 -*-
"""
Contains functions for replicator models
"""

import numpy as np


def fitness_function(z, mean_fitness, coeff_var_fitness):
    A = mean_fitness / np.sqrt(1 + coeff_var_fitness**2)
    B = np.sqrt(np.log(1 + coeff_var_fitness**2))
    return A * np.exp(B * z)


# traditional replicator model based on competitive Lotka Volterra model

def clv_replicator(x,fitness):
    """
    The standard replicator model ODE dx = (alpha - phi) x
    
    Parameters
    ----------
    x : np.array
        state vector the system
    fitness : np.array
        fitness vector

    Returns
    -------
    dx : np.array
        differential of the model
    """
    phi = np.dot(fitness,x)
    dx = (fitness-phi)*x  
    return dx

# replicator model derived from consumer producer dynamics

def core_replicator(x,fitness):
    """
    The soft replicator model ODE dx = (alpha / phi - 1) x

    Parameters
    ----------
    x : np.array
        state vector the system
    fitness : np.array
        fitness vector

    Returns
    -------
    dx : np.array
        differential of the model
    """    
    phi = np.dot(fitness,x)
    dx = (fitness/phi-1)*x
    return dx
    

