# -*- coding: utf-8 -*-
"""
Contains helper functions for generating common entangled noise processes
"""

import numpy as np

def angular_entanglement(theta):
    return np.array([[np.cos(x),np.sin(x)] for x in theta])

def abcn_entanglement(N):
    S=np.identity(N-1) 
    s=np.zeros(N-1) 
    s[0]=1/np.sqrt(2) 
    s[1]=1/np.sqrt(2) 
    S=np.insert(S,0,s,axis=0)
    return S

def an_entanglement(N):
    S=np.identity(N-1) 
    s=np.zeros(N-1) 
    for i in range(N-1):
        s[i]=1/np.sqrt(N-1) 
    S=np.insert(S,0,s,axis=0) 
    return S


def add_archetype(A):
    
    A = np.asarray(A)
    
    if A.ndim != 2:
        raise ValueError("Input must be a 2D array.")
    
    N, M = A.shape
    
    B = np.zeros((N + 1, M + 1), dtype=A.dtype)
    B[:N, :M] = A
    B[N, M] = 1
    
    return B