import numpy as np
from scipy.stats import hmean


def compute_stats(ensemble, fixed: bool = False, ignore_inf: bool = False):
    """
    Compute and store ensemble statistics in ensemble["stats"].

    Uses:
      ensemble["parameters"]["extinctions_enabled"] (bool)

    Policy:
    - Never crash on missing/empty events; store None for undefined stats.
    - Store stats["meta"] with counts and flags for interpretability.
    - Create a *fresh* stats dict each call (avoids aliasing when recomputing stats).
    """
    # --- create a fresh dict each call (fixes the A/B aliasing surprise) ---
    stats = {}
    ensemble["stats"] = stats

    params = ensemble.get("parameters", {})
    events = ensemble.get("events", [])

    N = params.get("N", None)
    ext_enabled = bool(params.get("extinctions_enabled", False))

    n_events = len(events)
    n_fix = sum(bool(e.get("fixation", False)) for e in events) if n_events > 0 else 0

    stats["meta"] = {
        "N": N,
        "n_events": n_events,
        "n_fixations": n_fix,
        "fixed_filter": fixed,
        "ignore_inf": ignore_inf,
        "extinctions_enabled": ext_enabled,
    }

    # No events or missing N -> everything undefined
    if N is None or n_events == 0:
        stats["fixation_fraction"] = None
        stats["fixation_frequency"] = None
        stats["extinction_rank"] = None
        stats["mean_survival_time"] = None
        stats["hmean_survival_time"] = None
        stats["mean_extinction_rate"] = None
        return stats

    # Always-defined given events exist (0.0 if no fixation)
    compute_fixation_fraction(ensemble)

    # Useful even if no fixation: returns zeros
    compute_fixation_frequency(ensemble)

    # Fixation-conditioned stats
    if n_fix == 0:
        stats["extinction_rank"] = None
        stats["mean_survival_time"] = None
    else:
        compute_extinction_rank(ensemble)
        compute_mean_extinction_time(ensemble)

    # Extinction-time summaries: only meaningful if extinction mechanism enabled
    if not ext_enabled:
        stats["hmean_survival_time"] = None
        stats["mean_extinction_rate"] = None
    else:
        # (Keep if you still want it; remove this call if you don't want to store hmean time.)
        compute_hmean_extinction_time(ensemble, fixed=fixed, ignore_inf=ignore_inf)

        # Compute rate directly (does NOT depend on hmean_survival_time)
        compute_mean_extinction_rate(ensemble, fixed=fixed, ignore_inf=ignore_inf)

    return stats


def compute_fixation_fraction(ensemble):
    events = ensemble.get("events", [])
    if len(events) == 0:
        ensemble["stats"]["fixation_fraction"] = None
        return None

    fixed_frac = sum(bool(e.get("fixation", False)) for e in events) / len(events)
    ensemble["stats"]["fixation_fraction"] = float(fixed_frac)
    return fixed_frac


def compute_fixation_frequency(ensemble):
    """
    Frequency (distribution) of which type fixes *among fixation events*.
    If there are no fixation events, returns zeros.
    """
    N = ensemble["parameters"]["N"]
    events = ensemble.get("events", [])
    fixed_events = [e for e in events if e.get("fixation", False)]

    freq = np.zeros(N, dtype=float)

    if len(fixed_events) == 0:
        ensemble["stats"]["fixation_frequency"] = freq
        return freq

    winners = []
    for ev in fixed_events:
        extinct = ev.get("extinct", None)
        if extinct is None or len(extinct) != N:
            continue
        alive = [ix for ix, ext in enumerate(extinct) if not ext]
        if len(alive) == 1:
            winners.append(alive[0])

    if len(winners) > 0:
        for i in range(N):
            freq[i] = winners.count(i) / len(winners)

    ensemble["stats"]["fixation_frequency"] = freq
    return freq


def compute_extinction_rank(ensemble):
    """
    Extinction rank counts, conditioned on fixation events.

    Returns:
      rank: (N, N) int array where rank[i, r-1] counts how often species i had extinction_rank r.
      (Here r=N corresponds to "never extinct" / winner if you encoded None -> N.)
    """
    N = ensemble["parameters"]["N"]
    events = ensemble.get("events", [])
    fixed_events = [e for e in events if e.get("fixation", False)]

    if len(fixed_events) == 0:
        ensemble["stats"]["extinction_rank"] = None
        return None

    rank = np.zeros((N, N), dtype=int)

    for ev in fixed_events:
        er = ev.get("extinction_rank", None)
        if er is None or len(er) != N:
            continue

        # None -> N (meaning "never extinct" / winner)
        er = [r if r is not None else N for r in er]

        for species_idx, r in enumerate(er):
            if 1 <= r <= N:
                rank[species_idx, r - 1] += 1

    ensemble["stats"]["extinction_rank"] = rank
    return rank


def compute_hmean_extinction_time(ensemble, fixed: bool = False, ignore_inf: bool = False):
    """
    Harmonic mean of extinction times (your 'survival time').

    Selection:
      fixed=False -> use all events
      fixed=True  -> only fixation events

    Behavior:
      - If selection is empty: returns None
      - If ignore_inf=True: computes hmean over finite times; if none finite -> np.nan for that species
      - If ignore_inf=False: returns None if any species has reciprocal sum 0
    """
    N = ensemble["parameters"]["N"]
    events = ensemble.get("events", [])

    rows = (
        [e.get("extinction_time", None) for e in events if e.get("fixation", False)]
        if fixed else
        [e.get("extinction_time", None) for e in events]
    )
    rows = [r for r in rows if r is not None]

    if len(rows) == 0:
        ensemble["stats"]["hmean_survival_time"] = None
        return None

    a = np.asarray(rows, dtype=float)
    if a.ndim != 2 or a.shape[1] != N:
        raise ValueError(f"extinction_time array has shape {a.shape}, expected (n_events, {N}).")

    if ignore_inf:
        hm = np.empty(N, dtype=float)
        for i in range(N):
            v = a[:, i]
            v = v[np.isfinite(v)]
            hm[i] = hmean(v) if v.size > 0 else np.nan
        ensemble["stats"]["hmean_survival_time"] = hm
        return hm

    with np.errstate(divide="ignore", invalid="ignore"):
        recip_sum = np.sum(1.0 / a, axis=0)

    if np.any(recip_sum == 0.0):
        ensemble["stats"]["hmean_survival_time"] = None
        return None

    hm = hmean(a, axis=0)
    ensemble["stats"]["hmean_survival_time"] = hm
    return hm


def compute_mean_extinction_rate(ensemble, fixed: bool = False, ignore_inf: bool = False):
    """
    Mean extinction rate per species defined as mean(1 / extinction_time).

    Selection:
      fixed=False -> use all events
      fixed=True  -> only fixation events

    Notes:
      - If ignore_inf=False: inf times contribute 0 automatically via 1/inf -> 0
      - If ignore_inf=True: drop inf; if none finite -> np.nan for that species
    """
    N = ensemble["parameters"]["N"]
    events = ensemble.get("events", [])

    rows = (
        [e.get("extinction_time", None) for e in events if e.get("fixation", False)]
        if fixed else
        [e.get("extinction_time", None) for e in events]
    )
    rows = [r for r in rows if r is not None]

    if len(rows) == 0:
        ensemble["stats"]["mean_extinction_rate"] = None
        return None

    a = np.asarray(rows, dtype=float)
    if a.ndim != 2 or a.shape[1] != N:
        raise ValueError(f"extinction_time array has shape {a.shape}, expected (n_events, {N}).")

    if ignore_inf:
        rate = np.empty(N, dtype=float)
        for i in range(N):
            v = a[:, i]
            v = v[np.isfinite(v)]
            rate[i] = np.mean(1.0 / v) if v.size > 0 else np.nan
    else:
        with np.errstate(divide="ignore", invalid="ignore"):
            rate = np.mean(1.0 / a, axis=0)

    ensemble["stats"]["mean_extinction_rate"] = rate
    return rate


def compute_mean_extinction_time(ensemble):
    """
    Mean survival time conditioned on fixation events.

    Returns:
      - None if no fixation events
      - np.ndarray (N,) with np.nan for species with no finite extinction times in selection
    """
    N = ensemble["parameters"]["N"]
    events = ensemble.get("events", [])
    fixed_events = [e for e in events if e.get("fixation", False)]

    if len(fixed_events) == 0:
        ensemble["stats"]["mean_survival_time"] = None
        return None

    rows = [e.get("extinction_time", None) for e in fixed_events]
    rows = [r for r in rows if r is not None]

    if len(rows) == 0:
        ensemble["stats"]["mean_survival_time"] = None
        return None

    a = np.asarray(rows, dtype=float)
    if a.ndim != 2 or a.shape[1] != N:
        raise ValueError(f"extinction_time array has shape {a.shape}, expected (n_events, {N}).")

    m = np.empty(N, dtype=float)
    for i in range(N):
        v = a[:, i]
        v = v[np.isfinite(v)]
        m[i] = np.mean(v) if v.size > 0 else np.nan

    ensemble["stats"]["mean_survival_time"] = m
    return m