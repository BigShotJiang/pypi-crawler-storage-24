# entangled_evolution


Examples and documentation are provided as Jupyter notebooks.

---

## Quick start (recommended)

This project uses **uv**, a fast Python package manager and virtual environment
tool. You need to install uv on your system first. When that's done:

```bash
git clone https://github.com/dirkbrockmann/entangled_evolution.git
cd entangled_evolution
make notebook
```

---

## Using entangled_evolution n your own code

```python
import entangled_evolution
```

---



## Installation via pip

You can now install entangled_evolution directly from PyPI:

```bash
pip install entangled_evolution
```

To install the latest development version from source:

```bash
pip install git+https://github.com/dirkbrockmann/entangled_evolution.git
```


Or clone and work with the code locally:

```bash
git clone https://github.com/dirkbrockmann/entangled_evolution.git
cd entangled_evolution
pip install -e .
```

---

## Running the examples

To run the Jupyter notebook examples, install entangled_evolution with the extra dependencies:

```bash
pip install "entangled_evolution[examples]"
```

This will install all required packages for the example notebooks.

## Running the benchmarks

To run the Jupyter notebook examples, install entangled_evolution with the extra dependencies:

```bash
pip install "entangled_evolution[bench]"
```

This will install all required packages for the example notebooks.

---

## License

MIT
