<!-- mcp-name: io.github.stucchi/telnyx -->

# telnyx-mcp

MCP server for the [Telnyx API](https://developers.telnyx.com) — billing, phone numbers, and messaging.

## Tools

### Billing
- `get_balance` — Account balance, pending charges, credit limit
- `list_invoices` — List all invoices
- `get_invoice` — Get a specific invoice
- `get_charges_breakdown` — Charges breakdown for a date range (max 60 days)
- `get_charges_summary` — Charges summary for a date range

### Phone Numbers
- `list_phone_numbers` — List all phone numbers on the account
- `get_phone_number` — Get details of a specific phone number
- `search_available_numbers` — Search available numbers to purchase
- `order_phone_number` — Order/purchase a phone number

### Messaging
- `send_message` — Send an SMS message
- `list_messages` — List sent and received messages
- `list_messaging_profiles` — List messaging profiles

## Installation

```bash
uvx telnyx-mcp
```

### Claude Code

```json
{
  "mcpServers": {
    "telnyx": {
      "command": "uvx",
      "args": ["telnyx-mcp"],
      "env": {
        "TELNYX_API_KEY": "<your-api-key>"
      }
    }
  }
}
```

Get your API key from [portal.telnyx.com](https://portal.telnyx.com/#/app/api-keys).

## License

MIT
