from __future__ import annotations

from typing import Any

import httpx

from telnyx_mcp.config import get_config


class TelnyxError(Exception):
    def __init__(self, message: str, status_code: int = 0):
        super().__init__(message)
        self.status_code = status_code


async def _request(
    method: str,
    endpoint: str,
    params: dict[str, Any] | None = None,
    json_body: dict[str, Any] | None = None,
) -> dict[str, Any]:
    cfg = get_config()
    url = f"{cfg.base_url}{endpoint}"
    headers = {
        "Authorization": f"Bearer {cfg.api_key}",
        "Content-Type": "application/json",
        "Accept": "application/json",
    }

    async with httpx.AsyncClient(timeout=30.0) as client:
        try:
            resp = await client.request(
                method, url, headers=headers, params=params, json=json_body
            )
            resp.raise_for_status()
            return resp.json()
        except httpx.HTTPStatusError as exc:
            try:
                detail = exc.response.json()
            except Exception:
                detail = exc.response.text
            raise TelnyxError(
                f"HTTP {exc.response.status_code}: {detail}",
                status_code=exc.response.status_code,
            )
        except httpx.RequestError as exc:
            raise TelnyxError(f"Connection failed: {exc}")


async def get(endpoint: str, params: dict[str, Any] | None = None) -> dict[str, Any]:
    return await _request("GET", endpoint, params=params)


async def post(endpoint: str, json_body: dict[str, Any] | None = None) -> dict[str, Any]:
    return await _request("POST", endpoint, json_body=json_body)


async def patch(endpoint: str, json_body: dict[str, Any] | None = None) -> dict[str, Any]:
    return await _request("PATCH", endpoint, json_body=json_body)


async def delete(endpoint: str) -> dict[str, Any]:
    return await _request("DELETE", endpoint)
