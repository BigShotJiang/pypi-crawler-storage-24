from __future__ import annotations

import json
from typing import Annotated

from mcp.server.fastmcp import FastMCP

from telnyx_mcp import client

mcp = FastMCP("telnyx")


def _json(data: object) -> str:
    return json.dumps(data, indent=2, default=str)


# ── Billing ──────────────────────────────────────────────────


@mcp.tool()
async def get_balance() -> str:
    """Get current account balance, pending charges, credit limit, and available credit."""
    result = await client.get("/balance")
    return _json(result)


@mcp.tool()
async def list_invoices(
    page_number: Annotated[int, "Page number (1-based)"] = 1,
    page_size: Annotated[int, "Results per page"] = 20,
) -> str:
    """List all invoices for the account."""
    result = await client.get(
        "/invoices",
        params={"page[number]": page_number, "page[size]": page_size},
    )
    return _json(result)


@mcp.tool()
async def get_invoice(
    invoice_id: Annotated[str, "The invoice ID"],
) -> str:
    """Get details of a specific invoice."""
    result = await client.get(f"/invoices/{invoice_id}")
    return _json(result)


@mcp.tool()
async def get_charges_breakdown(
    start_date: Annotated[str, "Start date in YYYY-MM-DD format"],
    end_date: Annotated[str, "End date in YYYY-MM-DD format"],
) -> str:
    """Get monthly charges breakdown for a date range."""
    result = await client.get(
        "/charges_breakdown",
        params={"start_date": start_date, "end_date": end_date, "format": "json"},
    )
    return _json(result)


@mcp.tool()
async def get_charges_summary(
    start_date: Annotated[str, "Start date in YYYY-MM-DD format"],
    end_date: Annotated[str, "End date in YYYY-MM-DD format"],
) -> str:
    """Get monthly charges summary for a date range."""
    result = await client.get(
        "/charges_summary",
        params={"start_date": start_date, "end_date": end_date},
    )
    return _json(result)


# ── Phone Numbers ────────────────────────────────────────────


@mcp.tool()
async def list_phone_numbers(
    page_number: Annotated[int, "Page number (1-based)"] = 1,
    page_size: Annotated[int, "Results per page"] = 20,
    tag: Annotated[str | None, "Filter by tag"] = None,
    status: Annotated[str | None, "Filter by status (active, deleted, etc.)"] = None,
) -> str:
    """List all phone numbers on the account."""
    params: dict = {"page[number]": page_number, "page[size]": page_size}
    if tag:
        params["filter[tag]"] = tag
    if status:
        params["filter[status]"] = status
    result = await client.get("/phone_numbers", params=params)
    return _json(result)


@mcp.tool()
async def get_phone_number(
    phone_number_id: Annotated[str, "The phone number ID"],
) -> str:
    """Get details of a specific phone number."""
    result = await client.get(f"/phone_numbers/{phone_number_id}")
    return _json(result)


@mcp.tool()
async def search_available_numbers(
    country_code: Annotated[str, "ISO 3166-1 alpha-2 country code (e.g. US, IT, DE)"],
    locality: Annotated[str | None, "Filter by city/locality"] = None,
    phone_number_type: Annotated[str | None, "Type: local, toll_free, national"] = None,
    limit: Annotated[int, "Max results to return"] = 10,
) -> str:
    """Search for available phone numbers to purchase."""
    params: dict = {
        "filter[country_code]": country_code,
        "filter[limit]": limit,
    }
    if locality:
        params["filter[locality]"] = locality
    if phone_number_type:
        params["filter[phone_number_type]"] = phone_number_type
    result = await client.get("/available_phone_numbers", params=params)
    return _json(result)


@mcp.tool()
async def order_phone_number(
    phone_number: Annotated[str, "The phone number to order (E.164 format, e.g. +15551234567)"],
) -> str:
    """Order/purchase a phone number."""
    result = await client.post(
        "/number_orders",
        json_body={"phone_numbers": [{"phone_number": phone_number}]},
    )
    return _json(result)


# ── Messaging ────────────────────────────────────────────────


@mcp.tool()
async def send_message(
    to: Annotated[str, "Destination phone number in E.164 format (e.g. +15551234567)"],
    text: Annotated[str, "Message text to send"],
    from_number: Annotated[str, "Sender phone number in E.164 format"],
    messaging_profile_id: Annotated[str | None, "Messaging profile ID (optional)"] = None,
) -> str:
    """Send an SMS message."""
    body: dict = {
        "to": to,
        "text": text,
        "from": from_number,
        "type": "SMS",
    }
    if messaging_profile_id:
        body["messaging_profile_id"] = messaging_profile_id
    result = await client.post("/messages", json_body=body)
    return _json(result)


@mcp.tool()
async def list_messages(
    page_number: Annotated[int, "Page number (1-based)"] = 1,
    page_size: Annotated[int, "Results per page"] = 20,
) -> str:
    """List sent and received messages."""
    result = await client.get(
        "/messages",
        params={"page[number]": page_number, "page[size]": page_size},
    )
    return _json(result)


# ── Messaging Profiles ──────────────────────────────────────


@mcp.tool()
async def list_messaging_profiles(
    page_number: Annotated[int, "Page number (1-based)"] = 1,
    page_size: Annotated[int, "Results per page"] = 20,
) -> str:
    """List all messaging profiles."""
    result = await client.get(
        "/messaging_profiles",
        params={"page[number]": page_number, "page[size]": page_size},
    )
    return _json(result)


# ── Entry Point ──────────────────────────────────────────────


def main() -> None:
    mcp.run(transport="stdio")
