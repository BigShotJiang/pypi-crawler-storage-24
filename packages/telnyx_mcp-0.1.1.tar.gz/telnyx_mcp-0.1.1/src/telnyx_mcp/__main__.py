from telnyx_mcp.server import main

main()
