from __future__ import annotations

import os
from dataclasses import dataclass


@dataclass(frozen=True)
class Config:
    api_key: str
    base_url: str = "https://api.telnyx.com/v2"

    @staticmethod
    def from_env() -> Config:
        api_key = os.environ.get("TELNYX_API_KEY", "")
        if not api_key:
            raise RuntimeError(
                "Missing required env var: TELNYX_API_KEY\n\n"
                "Get your API key from https://portal.telnyx.com/#/app/api-keys\n"
                "Then configure:\n"
                '  "telnyx": {\n'
                '    "command": "uvx",\n'
                '    "args": ["telnyx-mcp"],\n'
                '    "env": { "TELNYX_API_KEY": "KEYxxx" }\n'
                "  }"
            )
        return Config(api_key=api_key)


_config: Config | None = None


def get_config() -> Config:
    global _config
    if _config is None:
        _config = Config.from_env()
    return _config
