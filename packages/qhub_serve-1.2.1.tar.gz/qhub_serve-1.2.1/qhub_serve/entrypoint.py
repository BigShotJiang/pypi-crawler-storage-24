import os
import traceback
from tempfile import TemporaryDirectory
from typing import Any, Dict

from loguru import logger
from qhub.commons.constants import (
    INPUT_DIRECTORY_ENV,
    OUTPUT_DIRECTORY_ENV,
    DEFAULT_INPUT_DIRECTORY,
    DEFAULT_OUTPUT_DIRECTORY,
)
from qhub.commons.entrypoint import run_entrypoint
from qhub.commons.file import write_str_to_file, list_directory_files
from qhub.commons.json import any_to_json
from qhub.commons.parameters import files_to_parameters, is_simple_type
from qhub.commons.reflection import resolve_signature


def run_entrypoint_wrapper(
    entrypoint: str,
    raw_input: Dict[str, Any],
    input_directory: TemporaryDirectory,
    output_directory: TemporaryDirectory,
) -> Any:
    logger.info(f"Running entrypoint {entrypoint}...")

    os.environ[INPUT_DIRECTORY_ENV] = input_directory.name
    os.environ[OUTPUT_DIRECTORY_ENV] = output_directory.name

    logger.info(f"Input directory: {input_directory.name}")
    logger.info(f"Output directory: {output_directory.name}")

    try:
        entrypoint_signature = resolve_signature(entrypoint)

        for key in raw_input.keys():
            file_content = any_to_json(raw_input[key])
            write_str_to_file(input_directory.name, key, file_content)

        input_files = list_directory_files(input_directory.name)
        logger.debug(f"Input files: {list(input_files.values())}")

        input_parameters = files_to_parameters(input_files, entrypoint_signature)

        return_value = run_entrypoint(entrypoint, input_parameters)

        os.environ[INPUT_DIRECTORY_ENV] = DEFAULT_INPUT_DIRECTORY
        os.environ[OUTPUT_DIRECTORY_ENV] = DEFAULT_OUTPUT_DIRECTORY

        logger.debug(f"Return type: {type(return_value)}")

        string_value = any_to_json(return_value)
        if string_value is None:
            return 0

        if is_simple_type(return_value):
            file_path = write_str_to_file(
                output_directory.name, "output.txt", string_value
            )
        else:
            file_path = write_str_to_file(
                output_directory.name, "output.json", string_value
            )
        logger.debug(f"Output file: {file_path}")

        return return_value
    except Exception as e:
        logger.error(f"{e}")
        traceback.print_exc()
        raise e
