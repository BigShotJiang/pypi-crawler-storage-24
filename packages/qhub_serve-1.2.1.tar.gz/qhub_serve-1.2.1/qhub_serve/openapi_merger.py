"""
Merges schema fragments from a workspace openapi.yaml into FastAPI's generated
OpenAPI spec via the `openapi_extra` decorator parameter.

Only two fragments are extracted and injected:
  - POST /  → requestBody schema
  - GET /{id}/result → 200 response schema
"""

import os
from typing import Any, Dict, Optional

import yaml


def _load_workspace_spec() -> Optional[Dict[str, Any]]:
    workspace = os.environ.get("WORKSPACE")
    if not workspace:
        return None
    path = os.path.join(workspace, "openapi.yaml")
    if not os.path.isfile(path):
        path = os.path.join(workspace, "openapi.yml")
    if not os.path.isfile(path):
        return None
    with open(path) as f:
        return yaml.safe_load(f)


def _resolve_refs(obj: Any, components: Dict[str, Any]) -> Any:
    """Recursively inline $ref entries from the components/schemas section."""
    if isinstance(obj, dict):
        if "$ref" in obj:
            ref: str = obj["$ref"]
            if ref.startswith("#/components/schemas/"):
                name = ref.removeprefix("#/components/schemas/")
                schema = components.get("schemas", {}).get(name, {})
                return _resolve_refs(schema, components)
        return {k: _resolve_refs(v, components) for k, v in obj.items()}
    if isinstance(obj, list):
        return [_resolve_refs(item, components) for item in obj]
    return obj


def _build_extra(spec: Dict[str, Any], path: str, method: str) -> Dict[str, Any]:
    components = spec.get("components", {})
    operation = spec.get("paths", {}).get(path, {}).get(method, {})
    resolved = _resolve_refs(operation, components)

    extra: Dict[str, Any] = {}

    if "requestBody" in resolved:
        extra["requestBody"] = resolved["requestBody"]

    if "responses" in resolved:
        extra["responses"] = resolved["responses"]

    return extra


# Eagerly evaluated once at import time so FastAPI picks them up at route
# registration, before the first request arrives.
_spec = _load_workspace_spec()

post_root_extra: Dict[str, Any] = _build_extra(_spec, "/", "post") if _spec else {}
get_result_extra: Dict[str, Any] = (
    _build_extra(_spec, "/{id}/result", "get") if _spec else {}
)
