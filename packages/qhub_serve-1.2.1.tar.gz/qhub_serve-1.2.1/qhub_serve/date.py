from datetime import datetime


def format_timestamp(timestamp: float | None):
    if timestamp is None:
        return None
    timestamp_datetime = datetime.fromtimestamp(timestamp)
    return timestamp_datetime.strftime("%Y-%m-%d %H:%M:%S")
