import logging
import time
import uuid
from typing import Annotated, Any, Dict, List, Optional

from fastapi import Body, FastAPI, Path, BackgroundTasks, Response
from qhub.api.service.types import LogEntry, ResultResponse, ServiceExecution
from qhub.commons.logging import init_logging
from starlette.responses import StreamingResponse

logging.getLogger("fastapi").addFilter(
    type(
        "",
        (logging.Filter,),
        {"filter": lambda self, r: "email-validator" not in r.getMessage()},
    )()
)

from .date import format_timestamp
from .openapi_merger import get_result_extra, post_root_extra
from .schemas import LogEntrySchema, ResultResponseSchema, ServiceExecutionSchema
from .service_executor import ServiceExecutor

app = FastAPI(
    title="Hub Service API",
    version="1.0",
    description="API description for a managed services on the Kipu Quantum Hub.",
    contact={
        "name": "Kipu Quantum GmbH",
        "url": "https://kipu-quantum.com",
        "email": "support-hub@kipu-quantum.com",
    },
)

init_logging()

service_executor = ServiceExecutor()


@app.get(
    "/",
    summary="List of service executions",
    response_model=List[ServiceExecutionSchema],
    tags=["Service API"],
)
def get_service_executions() -> List[ServiceExecution]:
    return service_executor.list()


@app.post(
    "/",
    summary="Asynchronous execution of the service",
    status_code=201,
    response_model=ServiceExecutionSchema,
    openapi_extra=post_root_extra,
    tags=["Service API"],
)
async def start_execution(
    request_body: Annotated[Dict[str, Any], Body()],
    response: Response,
    background_tasks: BackgroundTasks,
) -> ServiceExecution:
    id = str(uuid.uuid4())
    background_tasks.add_task(service_executor.run, id, request_body)
    response.headers["Location"] = f"/{id}"
    return ServiceExecution(
        id=id,
        status="PENDING",
        created_at=format_timestamp(time.time()),
        started_at=None,
        ended_at=None,
    )


@app.get(
    "/{id}",
    summary="Check the status of a service execution",
    response_model=ServiceExecutionSchema,
    tags=["Service API"],
)
def get_status(
    id: str = Path(description="The id of a service execution"),
) -> ServiceExecution:
    return service_executor.get_status(id)


@app.get(
    "/{id}/result",
    summary="Get the result of a service execution",
    response_model=ResultResponseSchema,
    response_model_exclude_none=True,
    openapi_extra=get_result_extra,
    tags=["Service API"],
)
def get_result(
    id: str = Path(description="The id of a service execution"),
) -> ResultResponse:
    return service_executor.get_result(id)


@app.get(
    "/{id}/result/{file}",
    summary="Download a result file of a service execution",
    response_class=StreamingResponse,
    responses={
        200: {
            "content": {"application/octet-stream": {}},
            "description": "Binary file download",
        }
    },
    tags=["Service API"],
)
def get_result_file(
    id: str = Path(description="The id of a service execution"),
    file: str = Path(description="The name of the result file"),
) -> StreamingResponse:
    return service_executor.get_result_file(id, file)


@app.get(
    "/{id}/log",
    summary="Get the log output of a service execution",
    response_model=Optional[List[LogEntrySchema]],
    responses={
        200: {"description": "List of log entries"},
        204: {"description": "No log entries available, retry later"},
    },
    tags=["Service API"],
)
def get_log(
    id: str = Path(description="The id of a service execution"),
) -> Optional[List[LogEntry]]:
    return None


@app.put(
    "/{id}/cancel",
    summary="Cancel a service execution",
    status_code=204,
    tags=["Service API"],
)
def cancel_execution(
    id: str = Path(description="The id of a service execution"),
) -> None:
    service_executor.cancel(id)
