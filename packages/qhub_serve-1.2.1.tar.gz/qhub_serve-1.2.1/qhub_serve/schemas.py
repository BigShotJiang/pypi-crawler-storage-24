"""
Clean Pydantic BaseModel mirrors of the Fern-generated qhub types.

The generated types use `extra="allow"` and `Union[Literal[...], Any]` for
enums, which causes FastAPI/OpenAPI to render fields as "any". These mirrors
use standard BaseModel with proper Literal types so the generated OpenAPI
schema is accurate and human-readable.
"""

import datetime
from typing import Any, Literal, Optional

from pydantic import BaseModel, Field, model_validator


class ServiceExecutionSchema(BaseModel):
    id: Optional[str] = Field(
        default=None, description="Unique identifier of the service execution."
    )
    created_at: Optional[str] = Field(
        default=None,
        alias="createdAt",
        description="Timestamp when the service execution was created.",
    )
    started_at: Optional[str] = Field(
        default=None,
        alias="startedAt",
        description="Timestamp when the service execution started.",
    )
    ended_at: Optional[str] = Field(
        default=None,
        alias="endedAt",
        description="Timestamp when the service execution ended.",
    )
    status: Optional[
        Literal["UNKNOWN", "PENDING", "RUNNING", "SUCCEEDED", "CANCELLED", "FAILED"]
    ] = Field(default=None, description="Status of the service execution.")
    type: Optional[Literal["MANAGED", "WORKFLOW"]] = Field(
        default=None,
        description="Type identifier indicating whether the underlying service is a 'managed' or 'workflow' service.",
    )
    service_id: Optional[str] = Field(
        default=None,
        alias="serviceId",
        description="The ID of the service for which this service execution was created.",
    )
    service_definition_id: Optional[str] = Field(
        default=None,
        alias="serviceDefinitionId",
        description="The ID of the service definition for which this service execution was created.",
    )
    application_id: Optional[str] = Field(
        default=None,
        alias="applicationId",
        description="The ID of the application for which this service execution was created.",
    )

    model_config = {"populate_by_name": True}


class LogEntrySchema(BaseModel):
    message: Optional[str] = Field(default=None, description="Log message content.")
    severity: Optional[Literal["DEBUG", "NOTICE", "INFO", "WARNING", "ERROR"]] = Field(
        default=None, description="Severity of the log entry."
    )
    timestamp: Optional[datetime.datetime] = Field(
        default=None, description="Timestamp when the entry was logged."
    )


class HalLinkSchema(BaseModel):
    href: Optional[str] = Field(default=None, description="The URL of the link.")
    templated: Optional[bool] = Field(
        default=None, description="Whether the link is templated."
    )
    type: Optional[str] = Field(default=None, description="The media type of the link.")
    deprecation: Optional[str] = Field(
        default=None,
        description="A URL that provides further information about the deprecation of the link.",
    )
    name: Optional[str] = Field(default=None, description="The name of the link.")
    profile: Optional[str] = Field(
        default=None,
        description="A URL that provides further information about the profile of the link.",
    )
    title: Optional[str] = Field(default=None, description="The title of the link.")
    hreflang: Optional[str] = Field(
        default=None, description="The language of the link's target resource."
    )


class ResultResponseLinksSchema(BaseModel):
    status: Optional[HalLinkSchema] = Field(default=None, alias="_links")

    model_config = {"populate_by_name": True}


class ResultResponseEmbeddedSchema(BaseModel):
    status: Optional[ServiceExecutionSchema] = Field(default=None, alias="_embedded")

    model_config = {"populate_by_name": True}


class ResultResponseSchema(BaseModel):
    links: Optional[ResultResponseLinksSchema] = Field(default=None, alias="_links")
    embedded: Optional[ResultResponseEmbeddedSchema] = Field(
        default=None, alias="_embedded"
    )

    model_config = {"populate_by_name": True, "extra": "allow"}

    @model_validator(mode="before")
    @classmethod
    def _capture_pydantic_extra(cls, data: Any) -> Any:
        """
        When validating from a Pydantic model instance (from_attributes=True),
        Pydantic v2 only reads declared fields and does not transfer __pydantic_extra__
        entries. This validator explicitly merges those extra fields so that dynamic
        result fields (e.g. 'sum' written to output.json by the user's entrypoint)
        are preserved in the serialized HTTP response.
        """
        if hasattr(data, "__pydantic_extra__") and data.__pydantic_extra__:
            merged: dict = {}
            for k, v in data.__dict__.items():
                if not k.startswith("__"):
                    merged[k] = v
            merged.update(data.__pydantic_extra__)
            return merged
        return data
