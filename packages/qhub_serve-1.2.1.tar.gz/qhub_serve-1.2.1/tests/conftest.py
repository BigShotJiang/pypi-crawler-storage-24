import sys
from pathlib import Path

# Make the sample workspace importable as `src.program` during tests,
# mirroring what `qhub-serve --workspace <path>` does at runtime.
workspace = Path(__file__).parent.parent / "workspace"
if str(workspace) not in sys.path:
    sys.path.insert(0, str(workspace))
