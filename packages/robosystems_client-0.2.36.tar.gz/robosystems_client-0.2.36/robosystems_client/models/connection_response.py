from __future__ import annotations

import datetime
from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field
from dateutil.parser import isoparse

from ..types import UNSET, Unset

if TYPE_CHECKING:
  from ..models.connection_response_metadata import ConnectionResponseMetadata


T = TypeVar("T", bound="ConnectionResponse")


@_attrs_define
class ConnectionResponse:
  """Connection response model.

  Attributes:
      connection_id (str): Unique connection identifier
      provider (str): Connection provider type
      status (str): Connection status
      created_at (datetime.datetime | str): Creation timestamp
      metadata (ConnectionResponseMetadata): Provider-specific metadata
      entity_id (None | str | Unset): Entity identifier
      updated_at (datetime.datetime | None | str | Unset): Last update timestamp
      last_sync (datetime.datetime | None | str | Unset): Last sync timestamp
  """

  connection_id: str
  provider: str
  status: str
  created_at: datetime.datetime | str
  metadata: ConnectionResponseMetadata
  entity_id: None | str | Unset = UNSET
  updated_at: datetime.datetime | None | str | Unset = UNSET
  last_sync: datetime.datetime | None | str | Unset = UNSET
  additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

  def to_dict(self) -> dict[str, Any]:
    connection_id = self.connection_id

    provider = self.provider

    status = self.status

    created_at: str
    if isinstance(self.created_at, datetime.datetime):
      created_at = self.created_at.isoformat()
    else:
      created_at = self.created_at

    metadata = self.metadata.to_dict()

    entity_id: None | str | Unset
    if isinstance(self.entity_id, Unset):
      entity_id = UNSET
    else:
      entity_id = self.entity_id

    updated_at: None | str | Unset
    if isinstance(self.updated_at, Unset):
      updated_at = UNSET
    elif isinstance(self.updated_at, datetime.datetime):
      updated_at = self.updated_at.isoformat()
    else:
      updated_at = self.updated_at

    last_sync: None | str | Unset
    if isinstance(self.last_sync, Unset):
      last_sync = UNSET
    elif isinstance(self.last_sync, datetime.datetime):
      last_sync = self.last_sync.isoformat()
    else:
      last_sync = self.last_sync

    field_dict: dict[str, Any] = {}
    field_dict.update(self.additional_properties)
    field_dict.update(
      {
        "connection_id": connection_id,
        "provider": provider,
        "status": status,
        "created_at": created_at,
        "metadata": metadata,
      }
    )
    if entity_id is not UNSET:
      field_dict["entity_id"] = entity_id
    if updated_at is not UNSET:
      field_dict["updated_at"] = updated_at
    if last_sync is not UNSET:
      field_dict["last_sync"] = last_sync

    return field_dict

  @classmethod
  def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
    from ..models.connection_response_metadata import ConnectionResponseMetadata

    d = dict(src_dict)
    connection_id = d.pop("connection_id")

    provider = d.pop("provider")

    status = d.pop("status")

    def _parse_created_at(data: object) -> datetime.datetime | str:
      try:
        if not isinstance(data, str):
          raise TypeError()
        created_at_type_0 = isoparse(data)

        return created_at_type_0
      except (TypeError, ValueError, AttributeError, KeyError):
        pass
      return cast(datetime.datetime | str, data)

    created_at = _parse_created_at(d.pop("created_at"))

    metadata = ConnectionResponseMetadata.from_dict(d.pop("metadata"))

    def _parse_entity_id(data: object) -> None | str | Unset:
      if data is None:
        return data
      if isinstance(data, Unset):
        return data
      return cast(None | str | Unset, data)

    entity_id = _parse_entity_id(d.pop("entity_id", UNSET))

    def _parse_updated_at(data: object) -> datetime.datetime | None | str | Unset:
      if data is None:
        return data
      if isinstance(data, Unset):
        return data
      try:
        if not isinstance(data, str):
          raise TypeError()
        updated_at_type_0 = isoparse(data)

        return updated_at_type_0
      except (TypeError, ValueError, AttributeError, KeyError):
        pass
      return cast(datetime.datetime | None | str | Unset, data)

    updated_at = _parse_updated_at(d.pop("updated_at", UNSET))

    def _parse_last_sync(data: object) -> datetime.datetime | None | str | Unset:
      if data is None:
        return data
      if isinstance(data, Unset):
        return data
      try:
        if not isinstance(data, str):
          raise TypeError()
        last_sync_type_0 = isoparse(data)

        return last_sync_type_0
      except (TypeError, ValueError, AttributeError, KeyError):
        pass
      return cast(datetime.datetime | None | str | Unset, data)

    last_sync = _parse_last_sync(d.pop("last_sync", UNSET))

    connection_response = cls(
      connection_id=connection_id,
      provider=provider,
      status=status,
      created_at=created_at,
      metadata=metadata,
      entity_id=entity_id,
      updated_at=updated_at,
      last_sync=last_sync,
    )

    connection_response.additional_properties = d
    return connection_response

  @property
  def additional_keys(self) -> list[str]:
    return list(self.additional_properties.keys())

  def __getitem__(self, key: str) -> Any:
    return self.additional_properties[key]

  def __setitem__(self, key: str, value: Any) -> None:
    self.additional_properties[key] = value

  def __delitem__(self, key: str) -> None:
    del self.additional_properties[key]

  def __contains__(self, key: str) -> bool:
    return key in self.additional_properties
