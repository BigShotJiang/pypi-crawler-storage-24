"""Shared utilities for neo-cortex."""

import importlib.resources
import os


def load_mbel_grammar() -> str:
    """Load MBEL grammar from package data.

    Primary: importlib.resources (works with wheel/uvx installs).
    Fallback: relative to source tree (editable installs).
    """
    try:
        return importlib.resources.files("neo_cortex").joinpath("mbel.md").read_text(encoding="utf-8").strip()
    except Exception:
        pass
    pkg_dir = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    mbel_path = os.path.join(pkg_dir, "mbel.md")
    try:
        with open(mbel_path, "r", encoding="utf-8") as f:
            return f.read().strip()
    except FileNotFoundError:
        return "(MBEL grammar not found)"
