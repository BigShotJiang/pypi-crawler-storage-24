"""CortexService — orchestrator for ingest, recall, dream, stats, timeline."""

import logging
import os
import threading
import time

from neo_cortex.classifier import Classifier
from neo_cortex.embedder import JinaEmbedder
from neo_cortex.memory_index import MemoryIndex
from neo_cortex.models import (
    Activity,
    DreamResult,
    IngestRequest,
    MemoryRecord,
    RecalledMemory,
    RecallResult,
    StructuredFields,
    TimelineResult,
)
from neo_cortex.decay import reinforce as reinforce_stability
from neo_cortex.store import MemoryStore

logger = logging.getLogger(__name__)

from functools import partial
from neo_cortex._log import boot_log
_bl = partial(boot_log, "CORTEX")

TYPE_TO_ACTIVITY = {
    "bugfix": Activity.BUGFIX,
    "feature": Activity.FEATURE,
    "architecture": Activity.RESEARCH,
    "decision": Activity.DISCUSSION,
    "config": Activity.CONFIG,
    "lesson": Activity.LEARNING,
    "preference": Activity.BEHAVIOR,
}

# Static noise patterns — tier 1 filter (free, instant)
_id_counter = 0
_id_lock = threading.Lock()


def _next_id_suffix() -> int:
    """Thread-safe monotonic counter for unique memory IDs."""
    global _id_counter
    with _id_lock:
        _id_counter += 1
        return _id_counter


# Static noise patterns — tier 1 filter (free, instant)
NOISE_PATTERNS = frozenset({
    "ciao", "/clear", "eccoti", "kill", "kill?", "esci", "killa ti",
    "puoi killare", "restarta ti", "indovina", "laco",
    "hey", "hello", "hi", "buongiorno", "buonasera", "salve",
    "ok", "si", "no", "va bene", "grazie", "thanks", "yes", "yep",
    "nope", "nah", "sure", "done", "fatto", "perfetto", "bene",
    "vai", "avanti", "continua", "stop",
})


class CortexService:
    """Orchestrates memory ingestion, recall, and lifecycle."""

    def __init__(
        self,
        store: MemoryStore,
        embedder: JinaEmbedder,
        classifier: Classifier,
        index: MemoryIndex | None = None,
        dedup: 'DedupStore | None' = None,
        graph: 'ConceptGraph | None' = None,
    ):
        self._store = store
        self._embedder = embedder
        self._classifier = classifier
        self._index = index
        self._dedup = dedup
        self._graph = graph
        self._dream_count = 0

    @property
    def index(self) -> MemoryIndex | None:
        return self._index

    @property
    def dream_count(self) -> int:
        return self._dream_count

    async def _resolve_conflicts(
        self, text: str, embedding: list[float]
    ) -> dict:
        """Query similar memories, ask LLM to decide ADD/UPDATE/NOOP."""
        if not self._index or self._store.count() == 0:
            return {"action": "add", "target_id": None, "reason": "no index"}

        similar = self._store.query(embedding, n=3)
        strong = [(r, s) for r, s in similar if s > 0.7]
        if not strong:
            return {"action": "add", "target_id": None, "reason": "no conflict"}

        enriched = [(rec, sim, self._index.get_structured(rec.id)) for rec, sim in strong]
        _bl(f"conflict check against {len(enriched)} similar memories")
        for rec, sim, sf in enriched:
            title = sf.title if sf else rec.topic
            _bl(f"  candidate: {rec.id} sim={sim:.3f} title='{title}'")

        decision = await self._classifier.resolve_conflict(text, enriched)
        _bl(f"conflict decision → {decision['action']} ({decision.get('reason', '')})")
        return decision

    async def _core_ingest(
        self,
        *,
        content: str,
        embedding: list[float],
        record: MemoryRecord,
        structured: StructuredFields | None,
        resolve_conflicts: bool = True,
        record_merges: bool = False,
    ) -> str | None:
        """Shared ingest core: dedup → conflicts → store → index → graph.

        Returns memory_id on success, None if filtered.
        """
        # 1. Dedup check
        if self._dedup and self._dedup.is_duplicate(content):
            _bl(f"_core_ingest: filtered by dedup ({record.id})")
            return None

        # 2. Optional conflict resolution
        if resolve_conflicts:
            decision = await self._resolve_conflicts(content, embedding)
            if decision["action"] == "noop":
                _bl(f"_core_ingest: filtered by conflict resolution ({record.id})")
                if self._dedup:
                    self._dedup.add(content, "noop")
                return None
            if decision["action"] == "update" and decision.get("target_id"):
                target_id = decision["target_id"]
                _bl(f"_core_ingest: updating {target_id}")
                update_record = record.model_copy(update={"id": target_id})
                self._store.update(target_id, update_record, embedding)
                if self._index:
                    self._index.update(update_record, structured)
                if self._dedup:
                    self._dedup.add(content, target_id)
                if self._graph and structured and structured.concepts:
                    self._graph.add_memory(target_id, structured.concepts)
                return target_id

        # 3. Store in ChromaDB
        _bl(f"_core_ingest: storing {record.id}")
        self._store.insert(record, embedding)

        # 4. Dedup hash
        if self._dedup:
            self._dedup.add(content, record.id)

        # 5. SQLite index
        if self._index:
            self._index.insert(record, structured)

        # 6. Concept graph
        if self._graph and structured and structured.concepts:
            self._graph.add_memory(record.id, structured.concepts)
            _bl(f"_core_ingest: graph updated with {len(structured.concepts)} concepts")

        # 7. Optional pending merges (fast mode)
        if record_merges and self._index and self._store.count() > 1:
            from neo_cortex.config import CONSOLIDATION_SIMILARITY_THRESHOLD
            similar = self._store.query(embedding, n=5)
            for sim_rec, sim_score in similar:
                if sim_rec.id != record.id and sim_score > CONSOLIDATION_SIMILARITY_THRESHOLD:
                    self._index.add_pending_merge(record.id, sim_rec.id, sim_score)
                    _bl(f"_core_ingest: pending_merge {record.id} ↔ {sim_rec.id} sim={sim_score:.3f}")

        _bl(f"_core_ingest: DONE → {record.id}")
        return record.id

    async def ingest(self, request: IngestRequest) -> str | None:
        """Ingest a conversation turn.

        Flow: noise check → embed → classify → store.
        Returns memory ID or None if filtered as noise.
        """
        _bl(f"ingest: session={request.session_id[:8]}, turn={request.turn_number}")

        # Tier 1: static noise filter
        q = request.question.strip().lower()
        if q.startswith("[system]"):
            _bl("ingest: filtered [system]")
            return None
        if q.rstrip("!?.,;:") in NOISE_PATTERNS:
            _bl(f"ingest: filtered noise pattern '{q[:30]}'")
            return None

        # Tier 2: LLM noise filter for short ambiguous messages
        if len(q) <= 50:
            if await self._classifier.is_noise(request.question):
                _bl("ingest: filtered by Groq noise")
                return None

        combined = f"Q: {request.question}\nA: {request.answer}"
        if len(combined) > 8000:
            combined = combined[:8000]

        _bl("ingest: calling embed_passage")
        embedding = await self._embedder.embed_passage(combined)

        classification = await self._classifier.classify(request.question, request.answer)
        _bl(f"ingest: classify OK → {classification.project}/{classification.topic}")

        ts = time.time()
        memory_id = f"v3_{request.session_id[:8]}_{request.turn_number}_{int(ts) % 100000}"

        record = MemoryRecord(
            id=memory_id,
            session_id=request.session_id,
            timestamp=ts,
            turn_number=request.turn_number,
            question=request.question[:500],
            answer_preview=request.answer[:500],
            document=combined,
            project=classification.project,
            topic=classification.topic,
            activity=classification.activity,
            energy=1.0,
            model=request.model,
            source=request.source,
            tools_used=request.tools_used,
        )
        structured = StructuredFields(
            title=classification.title,
            summary=classification.summary,
            facts=classification.facts,
            concepts=classification.concepts,
            files_touched=classification.files_touched,
        )

        result = await self._core_ingest(
            content=combined,
            embedding=embedding,
            record=record,
            structured=structured,
            resolve_conflicts=True,
        )
        if result:
            logger.info("Ingested memory %s [%s/%s]", result, classification.project, classification.topic)
        return result

    async def ingest_knowledge(self, topic: str, content: str,
                               entry_type: str = "feature",
                               project: str = "general",
                               session_id: str = "distiller",
                               concepts: list[str] | None = None) -> str | None:
        """Ingest a single distilled knowledge entry (from Gemini).

        No Groq classify call needed — Gemini already provided structured fields.
        Still runs: embed, dedup, conflict resolution, store, index, graph.
        """
        if not content.strip():
            return None

        _bl(f"ingest_knowledge: topic='{topic}', project={project}")

        embedding = await self._embedder.embed_passage(content)
        activity = TYPE_TO_ACTIVITY.get(entry_type, Activity.DISCUSSION)
        ts = time.time()
        memory_id = f"kn_{session_id[:8]}_{int(ts) % 100000}"
        real_concepts = concepts if concepts else [project, entry_type]

        record = MemoryRecord(
            id=memory_id,
            session_id=session_id,
            timestamp=ts,
            question=topic,
            answer_preview=content[:500],
            document=content,
            project=project,
            topic=topic[:100],
            activity=activity,
            energy=1.0,
            source="distiller",
        )
        structured = StructuredFields(
            title=topic,
            summary=content[:300],
            facts=[content],
            concepts=real_concepts,
        )

        result = await self._core_ingest(
            content=content,
            embedding=embedding,
            record=record,
            structured=structured,
            resolve_conflicts=True,
        )
        if result:
            logger.info("Ingested knowledge %s [%s/%s]", result, project, topic[:50])
        return result

    async def ingest_knowledge_fast(self, topic: str, content: str,
                                     entry_type: str = "feature",
                                     project: str = "general",
                                     session_id: str = "distiller",
                                     concepts: list[str] | None = None) -> str | None:
        """Ingest knowledge entry — always ADD, no conflict resolution.

        Records similar pairs in pending_merges for later consolidation.
        Used by the digestor for phase-1 fast ingest.
        """
        if not content.strip():
            return None

        _bl(f"ingest_knowledge_fast: topic='{topic}', project={project}")

        embedding = await self._embedder.embed_passage(content)
        activity = TYPE_TO_ACTIVITY.get(entry_type, Activity.DISCUSSION)
        ts = time.time()
        seq = _next_id_suffix()
        memory_id = f"kn_{session_id[:8]}_{int(ts) % 100000}_{seq}"
        real_concepts = concepts if concepts else [project, entry_type]

        record = MemoryRecord(
            id=memory_id,
            session_id=session_id,
            timestamp=ts,
            question=topic,
            answer_preview=content[:500],
            document=content,
            project=project,
            topic=topic[:100],
            activity=activity,
            energy=1.0,
            source="distiller",
        )
        structured = StructuredFields(
            title=topic,
            summary=content[:300],
            facts=[content],
            concepts=real_concepts,
        )

        result = await self._core_ingest(
            content=content,
            embedding=embedding,
            record=record,
            structured=structured,
            resolve_conflicts=False,
            record_merges=True,
        )
        if result:
            logger.info("Fast-ingested knowledge %s [%s/%s]", result, project, topic[:50])
        return result

    async def recall(self, query: str, n: int = 5, smart: bool = True) -> RecallResult:
        """Recall memories relevant to a query.

        Smart mode: analyze query → embed refined → search with filters → aggregate.
        Basic mode: embed query → vector search → return.
        """
        if smart:
            return await self._smart_recall(query, n)
        return await self._basic_recall(query, n)

    async def _basic_recall(self, query: str, n: int) -> RecallResult:
        try:
            embedding = await self._embedder.embed_query(query)
            results = self._store.query(embedding, n=n)
            memories = [RecalledMemory(record=r, similarity=s) for r, s in results]
            if self._graph:
                memories = self._graph_boost(memories, query)
            self._reinforce(memories)
            return RecallResult(query=query, count=len(memories), memories=memories)
        except Exception as e:
            logger.warning("Embedding failed, falling back to FTS: %s", e)
            return self._fts_recall(query, n)

    def _fts_recall(self, query: str, n: int) -> RecallResult:
        if not self._index:
            return RecallResult(query=query, count=0, memories=[])
        compact = self._index.search_fts(query, n=n)
        ids = [c.id for c in compact]
        records = self._index.get_by_ids(ids)
        memories = [RecalledMemory(record=r, similarity=0.5) for r in records]
        return RecallResult(query=query, count=len(memories), memories=memories)

    async def _smart_recall(self, query: str, n: int) -> RecallResult:
        MIN_SIMILARITY = 0.2   # discard garbage results below this

        # Analyze query
        analysis = await self._classifier.analyze_query(query)

        try:
            # Embed refined query
            embedding = await self._embedder.embed_query(analysis.refined_query)

            # Build where filters
            where = self._build_where(analysis)

            # Fetch 3x candidates for re-ranking
            fetch_n = min(n * 3, 20)
            results = self._store.query(embedding, n=fetch_n, where=where)

            # If filtered returns too few, retry without filter
            if len(results) < 2 and where:
                results = self._store.query(embedding, n=fetch_n)

            # Filter garbage: drop results below MIN_SIMILARITY
            results = [(r, s) for r, s in results if s >= MIN_SIMILARITY]

            memories = [RecalledMemory(record=r, similarity=s) for r, s in results]

            # FTS5 blend: always merge keyword matches (RRF handles ranking)
            if self._index:
                memories = self._fts_blend(memories, analysis.refined_query, n)

            # Concept boost: merge in concept-matched memories from index
            if self._index:
                memories = self._concept_boost(memories, analysis.refined_query, fetch_n)

            # Graph boost: spreading activation finds related memories
            if self._graph:
                memories = self._graph_boost(memories, analysis.refined_query)

        except Exception as e:
            logger.warning("Smart recall embedding failed, falling back to FTS: %s", e)
            fts_result = self._fts_recall(query, n)
            memories = fts_result.memories

        # Reinforce recalled memories
        self._reinforce(memories[:n])

        # Aggregate to MBEL
        mbel = await self._classifier.aggregate_to_mbel(memories[:n])

        return RecallResult(
            query=query,
            count=len(memories[:n]),
            memories=memories[:n],
            mbel=mbel,
        )

    def _fts_blend(
        self, memories: list[RecalledMemory], query: str, n: int
    ) -> list[RecalledMemory]:
        """Blend FTS5 keyword results using Reciprocal Rank Fusion."""
        from neo_cortex.recall_fusion import reciprocal_rank_fusion

        fts_hits = self._index.search_fts(query, n=n)
        if not fts_hits:
            return memories

        # search_fts returns CompactMemory — fetch full MemoryRecords by ID
        fts_ids = [h.id for h in fts_hits]
        fts_records = self._index.get_by_ids(fts_ids)
        fts_recalled = [
            RecalledMemory(record=r, similarity=0.5) for r in fts_records
        ]
        return reciprocal_rank_fusion(memories, fts_recalled, k=60, n=n)

    def _concept_boost(
        self, memories: list[RecalledMemory], query: str, max_n: int
    ) -> list[RecalledMemory]:
        """Boost recall results using concept-based search from SQLite index."""
        CONCEPT_BOOST = 0.15

        # Extract keywords from query as concept candidates
        words = [w.lower().strip() for w in query.split() if len(w) > 2]

        # Find concept-matched memory IDs
        concept_ids: set[str] = set()
        for word in words:
            hits = self._index.search_by_concept(word, n=max_n)
            concept_ids.update(h.id for h in hits)

        if not concept_ids:
            return memories

        # Boost similarity for memories that also match concepts
        boosted = []
        seen_ids: set[str] = set()
        for m in memories:
            new_sim = m.similarity
            if m.record.id in concept_ids:
                new_sim = min(1.0, m.similarity + CONCEPT_BOOST)
            boosted.append(RecalledMemory(record=m.record, similarity=new_sim))
            seen_ids.add(m.record.id)

        # Add concept-only matches not in vector results
        missing_ids = concept_ids - seen_ids
        if missing_ids:
            records = self._index.get_by_ids(list(missing_ids)[:5])
            for rec in records:
                boosted.append(RecalledMemory(record=rec, similarity=CONCEPT_BOOST))

        # Re-sort by similarity descending
        boosted.sort(key=lambda m: m.similarity, reverse=True)
        return boosted

    def _reinforce(self, memories: list[RecalledMemory]) -> None:
        """Boost energy of recalled memories (retrieval reinforcement)."""
        REINFORCEMENT_ETA = 0.1
        for m in memories:
            old_energy = m.record.energy
            new_energy = min(1.0, old_energy + REINFORCEMENT_ETA * (1.0 - old_energy))
            if abs(new_energy - old_energy) > 0.001:
                self._store.update_energy(m.record.id, new_energy)
                if self._index:
                    self._index.update_energy(m.record.id, new_energy)
            # Reinforce stability + track access (with current runtime day)
            if self._index:
                current_rd = self._index.get_runtime_day_count()
                self._index.update_last_accessed(m.record.id, time.time(), runtime_day=current_rd)
                current_stability = self._index.get_stability(m.record.id)
                new_stability = reinforce_stability(current_stability, increment=0.1)
                self._index.update_stability(m.record.id, new_stability)

    def _graph_boost(
        self, memories: list[RecalledMemory], query: str
    ) -> list[RecalledMemory]:
        """Boost results using spreading activation from the concept graph."""
        GRAPH_BOOST = 0.1

        words = [w.lower().strip() for w in query.split() if len(w) > 2]
        related_mids = self._graph.get_related_memories(words, n=10)
        if not related_mids:
            return memories

        related_set = set(related_mids)
        for i, m in enumerate(memories):
            if m.record.id in related_set:
                memories[i] = RecalledMemory(
                    record=m.record,
                    similarity=min(1.0, m.similarity + GRAPH_BOOST),
                )

        memories.sort(key=lambda m: m.similarity, reverse=True)
        return memories

    def _build_where(self, analysis: 'QueryAnalysis') -> dict | None:
        from neo_cortex.models import QueryAnalysis as _QA  # noqa: avoid circular at module level

        conditions = []
        if analysis.project:
            conditions.append({"project": {"$eq": analysis.project}})
        if analysis.activity_filter:
            conditions.append({"activity": {"$eq": analysis.activity_filter}})
        if analysis.time_hint == "recent":
            cutoff = time.time() - (7 * 24 * 3600)
            conditions.append({"timestamp": {"$gte": cutoff}})
        elif analysis.time_hint == "old":
            cutoff = time.time() - (7 * 24 * 3600)
            conditions.append({"timestamp": {"$lt": cutoff}})

        if not conditions:
            return None
        if len(conditions) == 1:
            return conditions[0]
        return {"$and": conditions}

    async def dream(self) -> DreamResult:
        """Run one dream cycle: apply Ebbinghaus decay to all memories."""
        from neo_cortex.decay import ebbinghaus_weight
        from neo_cortex.surprisal import select_by_surprisal

        all_meta = self._store.get_all_metadata()
        if len(all_meta) < 2:
            return DreamResult(status="skipped", dream_count=self._dream_count, cluster=[])

        high_energy_ids = []

        # Fetch dream data once (stability, access_count, runtime days, etc.)
        dream_data = self._index.get_all_for_dream() if self._index else []
        stability_map = {d["id"]: d["stability"] for d in dream_data}
        rd_map = {d["id"]: d["last_accessed_rd"] for d in dream_data}

        # Current runtime day counter (0 if no index)
        current_rd = self._index.get_runtime_day_count() if self._index else 0

        for meta in all_meta:
            mid = meta["id"]
            old_energy = meta.get("energy", 1.0)

            stability = stability_map.get(mid, 1.0)
            last_rd = rd_map.get(mid, 0)
            execution_days = max(0, current_rd - last_rd)

            new_energy = ebbinghaus_weight(execution_days, stability, slowdown=10)
            if abs(new_energy - old_energy) > 0.001:
                self._store.update_energy(mid, new_energy)
                if self._index:
                    self._index.update_energy(mid, new_energy)

            if new_energy >= 0.7:
                high_energy_ids.append(mid)

        # Surprisal sampling: identify novel/underexplored memories
        surprisal_ids = select_by_surprisal(dream_data, n=5) if dream_data else []
        if surprisal_ids:
            logger.info("Dream surprisal: %d novel memories identified", len(surprisal_ids))

        self._dream_count += 1
        return DreamResult(
            status="completed",
            dream_count=self._dream_count,
            cluster=high_energy_ids,
            surprisal=surprisal_ids,
        )

    async def spontaneous(self, n: int = 3) -> list[MemoryRecord]:
        """Surface important memories not accessed recently (spontaneous recall)."""
        if not self._index:
            return []
        dream_data = self._index.get_all_for_dream()
        if not dream_data:
            return []

        now = time.time()
        seven_days = 7 * 24 * 3600
        candidates = []
        for d in dream_data:
            if d["energy"] < 0.5:
                continue
            last = d["last_accessed"] or d["timestamp"]
            if (now - last) < seven_days:
                continue
            # Score: energy * staleness_factor
            staleness = min((now - last) / seven_days, 10.0)
            score = d["energy"] * staleness
            candidates.append((d["id"], score))

        candidates.sort(key=lambda x: x[1], reverse=True)
        ids = [c[0] for c in candidates[:n]]
        if not ids:
            return []
        return self._index.get_by_ids(ids)

    def stats(self) -> 'CortexStats':
        from neo_cortex.models import CortexStats as _CS  # noqa
        return self._store.stats(self._dream_count)

    async def timeline(self, n: int = 10, project: str | None = None, smart: bool = False) -> TimelineResult:
        memories = self._store.timeline(limit=n, project=project)
        mbel = None
        if smart and memories:
            recalled = [RecalledMemory(record=m, similarity=1.0) for m in memories]
            mbel = await self._classifier.aggregate_to_mbel(recalled)
        return TimelineResult(count=len(memories), memories=memories, mbel=mbel)
