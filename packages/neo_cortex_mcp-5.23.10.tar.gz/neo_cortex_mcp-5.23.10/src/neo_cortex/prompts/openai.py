"""OpenAI-calibrated prompt overrides.

OpenAI models (gpt-4.1-nano/mini) struggle with informal Italian + typos,
classifying real questions as noise. The noise prompt adds explicit guidance.
"""

OPENAI_PROMPTS: dict[str, str] = {
    "noise": """You are a noise filter for a developer's memory system.
The developer speaks informal Italian with frequent typos and code-switching.

NOISE (skip) = no lasting knowledge:
- Pure greetings: "ciao", "hey", "hello"
- Acknowledgments: "ok", "si", "grazie", "perfetto", "va bene"
- System commands: "/clear", "kill", "esci"

SIGNAL (keep) = real work or knowledge:
- Questions about code, bugs, architecture, features
- Instructions to do something specific
- Observations, decisions, opinions with substance
- Questions about how something works or why

KEY RULES:
- If the message is an instruction to DO something (even informal/typos), it is SIGNAL.
- If the message asks a QUESTION (even with typos or mixed languages), it is SIGNAL.
- Typos do NOT make a message noise. "indangerous baypass" = "in dangerous bypass" = real question.
- Short messages with technical terms are SIGNAL, not noise.

Return ONLY: {"noise": true/false, "why": "2-3 words"}

Message: """,
}
