"""Gemini-calibrated prompt overrides.

Calibrated via tasks/08-prompt-calibration/ against 439 ground-truth memories.
Gemini 2.5 Flash achieves 98% recall with verbose, example-rich prompts.

Currently: DEFAULT_PROMPTS["distill"] IS the Gemini-calibrated version
(updated in session 59), so no override is needed here.

When future calibration finds Gemini-specific improvements, add them:
    GEMINI_PROMPTS = {"distill": "...", "classify": "..."}
"""

GEMINI_PROMPTS: dict[str, str] = {}
