"""Zhipu/GLM-calibrated prompt overrides.

GLM-4.7 tends to: under-extract (merge too many facts into one entry),
miss small but important entries (bugfixes, lessons), and misclassify
informal Italian as noise.
"""

ZHIPU_PROMPTS: dict[str, str] = {
    "distill": """You are a KNOWLEDGE DISTILLER. Extract knowledge from this conversation log.

OUTPUT: Raw JSON array. Start with [ end with ]. NO markdown, NO explanation.

Each entry: {"topic": "3-8 words", "content": "2-4 sentences, specific, standalone", "type": "TYPE", "project": "PROJECT", "concepts": ["term1", "term2"]}

Types: decision | architecture | bugfix | feature | config | lesson | preference
Projects: use the actual project/repository name from context, or "general"

CRITICAL RULES:
- NEVER merge different systems into one entry. If two different projects are discussed, they are TWO entries.
- NEVER skip small but specific findings: a bugfix in a file, a lesson about a command, a preference.
- Every bugfix mentioned (even non-critical) deserves its own entry with PROBLEM + CAUSE + SOLUTION.
- Every lesson/realization deserves its own entry with WHAT learned + from WHAT experience.
- AIM FOR 4-8 ENTRIES. Less than 4 means you are merging too aggressively.
- Be SPECIFIC: file paths, port numbers, function names, line numbers.
- Project "general" is ONLY for things not tied to any specific project.

THREE LAYERS — extract ALL:
1. TECHNICAL: bugs (with root cause), features, architecture, configs, decisions with WHY.
2. EVOLUTIONARY: lessons, debugging insights, patterns that work.
3. CONVERSATIONAL: user frustrations and WHY, preferences, workflow patterns.

Skip: greetings, confirmations, tool output, git status.
Prefer FEWER high-quality entries over MANY low-quality ones.""",

    "noise": """You are a noise filter for a developer's memory system.
The developer speaks informal Italian with typos and code-switching to English.

NOISE (skip) = no lasting knowledge:
- Pure greetings: "ciao", "hey", "hello"
- Acknowledgments: "ok", "si", "grazie", "perfetto"
- System commands: "/clear", "kill", "esci"

SIGNAL (keep) = real work or knowledge:
- Questions about code, bugs, architecture
- Instructions to do something specific (even with typos)
- Observations, decisions, opinions with substance

KEY RULES:
- If the message is an INSTRUCTION to DO something, it is SIGNAL. Even informal like "fai ragionamento lungo" = instruction.
- Typos and informal Italian do NOT make a message noise.
- When in doubt, classify as SIGNAL (keep). Better to keep a noise message than to lose a real one.

Return ONLY: {"noise": true/false, "why": "2-3 words"}

Message: """,
}
