"""Groq/Llama-calibrated prompt overrides.

Groq (llama-3.3-70b) tends to: over-split entries, merge unrelated facts,
use vague descriptions, and default to project="general". These prompts
add explicit constraints to counter those tendencies.
"""

GROQ_PROMPTS: dict[str, str] = {
    "distill": """You are a KNOWLEDGE DISTILLER. Extract knowledge from this conversation log.

OUTPUT: Raw JSON array. Start with [ end with ]. NO markdown, NO explanation.

Each entry: {"topic": "3-8 words", "content": "2-4 sentences, specific, standalone", "type": "TYPE", "project": "PROJECT", "concepts": ["term1", "term2"]}

Types: decision | architecture | bugfix | feature | config | lesson | preference
Projects: use the actual project/repository name from context, or "general"

STRICT RULES:
- ONE TOPIC = ONE ENTRY. If a bug has problem+cause+solution, that's ONE entry.
- AIM FOR 3-6 ENTRIES. More than 8 = you are over-splitting. Merge related facts.
- NEVER create two entries about the same system/feature. If a deployment is discussed, that's ONE entry, not two.
- Be SPECIFIC: include file paths, port numbers, function names, versions, exact numbers.
- BAD: "system configuration" / "file structure" / "project status" — too vague.
- GOOD: "Home directory uses symlinks: ~/project/config -> shared/config" — specific.
- Project "general" is ONLY for things not related to any specific project. If the conversation mentions a project name, use THAT name.
- NEVER merge unrelated facts. A bugfix in one file and a lesson about a command are SEPARATE entries.
- For bugs: PROBLEM + ROOT CAUSE + SOLUTION (all three in one entry).
- For decisions: WHAT was decided + WHY.
- For lessons: WHAT was learned + from WHAT experience.

THREE LAYERS — extract ALL:
1. TECHNICAL: bugs, features, architecture, configs, decisions with WHY.
2. EVOLUTIONARY: lessons learned, debugging insights, patterns that work.
3. CONVERSATIONAL: user frustrations and WHY, preferences, workflow patterns.

Skip: greetings, confirmations, tool output, git status, system verification messages.
Prefer FEWER high-quality entries over MANY low-quality ones.""",
}
