"""Tests for distiller wiring — DISTILLER_PROVIDER config + create_client usage."""
import os
import importlib
from unittest.mock import patch, MagicMock


class TestDistillerProviderConfig:
    def test_distiller_provider_defaults_to_llm_provider(self):
        with patch.dict(os.environ, {}, clear=True):
            from neo_cortex import config
            importlib.reload(config)
            assert config.DISTILLER_PROVIDER == config.LLM_PROVIDER

    def test_distiller_provider_can_be_separate(self):
        with patch.dict(os.environ, {
            "LLM_PROVIDER": "openai-compatible",
            "DISTILLER_PROVIDER": "gemini",
        }, clear=True):
            from neo_cortex import config
            importlib.reload(config)
            assert config.LLM_PROVIDER == "openai-compatible"
            assert config.DISTILLER_PROVIDER == "gemini"

    def test_distiller_provider_in_all(self):
        from neo_cortex import config
        assert "DISTILLER_PROVIDER" in config.__all__


class TestDistillerWiring:
    def test_distiller_accepts_llm_client(self):
        """Distiller takes LLMClient, not api_key string."""
        from neo_cortex.distiller import Distiller
        from neo_cortex.llm import LLMClient
        mock_llm = MagicMock(spec=LLMClient)
        mock_llm.name = "gemini/gemini-2.0-flash"
        d = Distiller(mock_llm)
        assert d._llm is mock_llm

    def test_create_client_respects_provider_arg(self):
        """create_client(provider) creates the right client type."""
        with patch.dict(os.environ, {"GEMINI_API_KEY": "test-key"}):
            from neo_cortex.llm import create_client, GeminiClient
            client = create_client("gemini")
            assert isinstance(client, GeminiClient)

    def test_create_client_with_groq_for_distiller(self):
        """When DISTILLER_PROVIDER=groq, create_client('groq') returns GroqClient."""
        with patch.dict(os.environ, {"GROQ_API_KEY": "test-key"}):
            from neo_cortex.llm import create_client, GroqClient
            client = create_client("groq")
            assert isinstance(client, GroqClient)
