"""Tests for AnthropicClient — uses anthropic SDK with system/user messages."""
import pytest
from unittest.mock import AsyncMock, MagicMock, patch


class TestAnthropicClientFormat:
    @pytest.mark.asyncio
    async def test_call_uses_system_and_user(self):
        """AnthropicClient sends system as system param, text as user message."""
        mock_client = AsyncMock()
        mock_response = MagicMock()
        mock_response.content = [MagicMock(text="ok")]
        mock_client.messages.create = AsyncMock(return_value=mock_response)

        with patch("neo_cortex.llm.AsyncAnthropic", return_value=mock_client):
            from neo_cortex.llm import AnthropicClient
            client = AnthropicClient("fake-key")
            client._client = mock_client

            result = await client.call("System prompt", "User text", max_tokens=100)

            mock_client.messages.create.assert_called_once()
            call_kwargs = mock_client.messages.create.call_args[1]
            assert call_kwargs["system"] == "System prompt"
            assert call_kwargs["messages"] == [{"role": "user", "content": "User text"}]
            assert call_kwargs["max_tokens"] == 100
            assert result == "ok"

    @pytest.mark.asyncio
    async def test_call_with_empty_text(self):
        """When text is empty, send prompt as single user message, no system."""
        mock_client = AsyncMock()
        mock_response = MagicMock()
        mock_response.content = [MagicMock(text="ok")]
        mock_client.messages.create = AsyncMock(return_value=mock_response)

        with patch("neo_cortex.llm.AsyncAnthropic", return_value=mock_client):
            from neo_cortex.llm import AnthropicClient
            client = AnthropicClient("fake-key")
            client._client = mock_client

            await client.call("Just a prompt", "")

            call_kwargs = mock_client.messages.create.call_args[1]
            assert "system" not in call_kwargs or call_kwargs.get("system") is None
            assert call_kwargs["messages"] == [{"role": "user", "content": "Just a prompt"}]

    @pytest.mark.asyncio
    async def test_name_property(self):
        mock_client = AsyncMock()
        with patch("neo_cortex.llm.AsyncAnthropic", return_value=mock_client):
            from neo_cortex.llm import AnthropicClient
            client = AnthropicClient("fake-key", model="claude-haiku-4-5-20251001")
            assert client.name == "anthropic/claude-haiku-4-5-20251001"

    @pytest.mark.asyncio
    async def test_provider_entries_in_providers_dict(self):
        """All new providers must be in _PROVIDERS dict."""
        from neo_cortex.llm import _PROVIDERS
        assert "anthropic" in _PROVIDERS
        assert "openai" in _PROVIDERS
        assert "x.ai" in _PROVIDERS
        assert "z.ai" in _PROVIDERS
