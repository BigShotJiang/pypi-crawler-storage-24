"""Tests for audit cleanup — dead code removal, DRY fix, security."""

import inspect

from neo_cortex.llm import LLMClient


def test_no_gemini_classifier_alias():
    """GeminiClassifier removed — never imported anywhere."""
    from neo_cortex import classifier
    assert not hasattr(classifier, "GeminiClassifier")


def test_no_gemini_distiller_alias():
    """GeminiDistiller removed — never imported anywhere."""
    from neo_cortex import distiller
    assert not hasattr(distiller, "GeminiDistiller")


def test_subscriber_uses_classifier_not_alias():
    """subscriber.py imports Classifier, not GroqClassifier."""
    from neo_cortex import subscriber
    source = inspect.getsource(subscriber)
    assert "GroqClassifier" not in source


def test_no_summarize_pattern_on_classifier():
    """summarize_pattern removed from Classifier — never called."""
    from neo_cortex.classifier import Classifier
    assert not hasattr(Classifier, "summarize_pattern")


def test_no_classify_mb_target_on_classifier():
    """classify_mb_target removed from Classifier — never called."""
    from neo_cortex.classifier import Classifier
    assert not hasattr(Classifier, "classify_mb_target")


def test_no_summarize_pattern_on_llm():
    """summarize_pattern task method removed from LLMClient."""
    assert not hasattr(LLMClient, "summarize_pattern")


def test_no_classify_mb_target_on_llm():
    """classify_mb_target task method removed from LLMClient."""
    assert not hasattr(LLMClient, "classify_mb_target")


def test_no_dead_prompt_keys():
    """DEFAULT_PROMPTS has no dead keys."""
    from neo_cortex.prompts import DEFAULT_PROMPTS
    assert "summarize_pattern" not in DEFAULT_PROMPTS
    assert "classify_mb_target" not in DEFAULT_PROMPTS


def test_load_mbel_grammar_shared():
    """Single shared function for mbel grammar loading."""
    from neo_cortex.utils import load_mbel_grammar
    result = load_mbel_grammar()
    assert "MBEL" in result or "grammar" in result.lower()


def test_redact_anthropic_keys():
    """_redact_secrets strips Anthropic API keys."""
    from neo_cortex.timeline_cli import _redact_secrets
    assert "sk-ant" not in _redact_secrets("key=sk-ant-api03-abcdefghijklmnopqrstuvwxyz123456")
