"""Tests verifying API keys are never sent in URLs."""

from unittest.mock import AsyncMock, MagicMock, patch

import pytest


class TestDistillerSecurity:
    @pytest.mark.asyncio
    async def test_distiller_delegates_to_llm_client(self):
        """Distiller must not handle API keys — delegates to LLMClient."""
        from neo_cortex.distiller import Distiller
        from neo_cortex.llm import LLMClient

        mock_llm = MagicMock(spec=LLMClient)
        mock_llm.name = "test/mock"
        mock_llm.distill = AsyncMock(return_value="[]")

        d = Distiller(mock_llm)
        await d.distill(["Q: test\nA: answer"])

        mock_llm.distill.assert_called_once()
        # Distiller has no _api_key or _client attributes
        assert not hasattr(d, "_api_key")
        assert not hasattr(d, "_client")

    @pytest.mark.asyncio
    async def test_gemini_client_key_in_header_not_url(self):
        """GeminiClient must send API key via header, not URL."""
        from neo_cortex.llm import GeminiClient

        mock_client = AsyncMock()
        mock_response = MagicMock()
        mock_response.raise_for_status = MagicMock()
        mock_response.json.return_value = {
            "candidates": [{"content": {"parts": [{"text": "[]"}]}}]
        }
        mock_client.post = AsyncMock(return_value=mock_response)

        client = GeminiClient("test-secret-key")
        client._client = mock_client
        await client.call("prompt", "text")

        call_args = mock_client.post.call_args
        url = call_args[0][0] if call_args[0] else call_args[1].get("url", "")
        assert "key=" not in url
        assert "test-secret-key" not in url
        headers = call_args[1].get("headers", {})
        assert headers.get("x-goog-api-key") == "test-secret-key"


class TestLlmSecurity:
    @pytest.mark.asyncio
    async def test_gemini_api_key_not_in_url(self):
        """GeminiClient must not put API key in URL query string."""
        from neo_cortex.llm import GeminiClient

        mock_client = AsyncMock()
        mock_response = MagicMock()
        mock_response.raise_for_status = MagicMock()
        mock_response.json.return_value = {
            "candidates": [{"content": {"parts": [{"text": "result"}]}}]
        }
        mock_client.post = AsyncMock(return_value=mock_response)

        client = GeminiClient.__new__(GeminiClient)
        client._client = mock_client
        client._api_key = "test-secret-key"
        client._model = "gemini-2.0-flash"

        await client.call(prompt="classify:", text="test")

        call_args = mock_client.post.call_args
        url = call_args[0][0] if call_args[0] else call_args.kwargs.get("url", "")
        assert "key=" not in url
        assert "test-secret-key" not in url
