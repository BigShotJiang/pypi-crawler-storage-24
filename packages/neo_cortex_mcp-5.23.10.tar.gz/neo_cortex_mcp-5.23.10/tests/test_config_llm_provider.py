"""Tests for LLM_PROVIDER config with backward compatibility."""
import os
import importlib
from unittest.mock import patch


class TestLLMProviderConfig:
    def test_default_is_gemini(self):
        with patch.dict(os.environ, {}, clear=True):
            from neo_cortex import config
            importlib.reload(config)
            assert config.LLM_PROVIDER == "gemini"

    def test_llm_provider_env_var(self):
        with patch.dict(os.environ, {"LLM_PROVIDER": "openai-compatible"}, clear=True):
            from neo_cortex import config
            importlib.reload(config)
            assert config.LLM_PROVIDER == "openai-compatible"

    def test_classifier_provider_backward_compat(self):
        """CLASSIFIER_PROVIDER should still work as fallback."""
        with patch.dict(os.environ, {"CLASSIFIER_PROVIDER": "groq"}, clear=True):
            from neo_cortex import config
            importlib.reload(config)
            assert config.LLM_PROVIDER == "groq"

    def test_llm_provider_takes_precedence(self):
        """LLM_PROVIDER wins over CLASSIFIER_PROVIDER."""
        with patch.dict(os.environ, {"LLM_PROVIDER": "openai-compatible", "CLASSIFIER_PROVIDER": "groq"}, clear=True):
            from neo_cortex import config
            importlib.reload(config)
            assert config.LLM_PROVIDER == "openai-compatible"

    def test_llm_base_url_default(self):
        with patch.dict(os.environ, {}, clear=True):
            from neo_cortex import config
            importlib.reload(config)
            assert config.LLM_BASE_URL == ""

    def test_llm_model_default(self):
        with patch.dict(os.environ, {}, clear=True):
            from neo_cortex import config
            importlib.reload(config)
            assert config.LLM_MODEL == ""
