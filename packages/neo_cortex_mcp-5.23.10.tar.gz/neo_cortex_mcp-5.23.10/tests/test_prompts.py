"""Tests for the prompts package — TDDAB-1."""

from neo_cortex.prompts import DEFAULT_PROMPTS


def test_default_prompts_has_all_keys():
    expected = {
        "classify", "noise", "query_analyze", "conflict_prefix",
        "aggregate", "distill", "merge", "focal_points", "insight",
        "truthfulness", "identity_proposal", "coherence_check", "timeline_resume",
    }
    assert set(DEFAULT_PROMPTS.keys()) == expected


def test_default_prompts_not_empty():
    for key, value in DEFAULT_PROMPTS.items():
        assert isinstance(value, str) and len(value) >= 20, f"{key} too short"


def test_template_prompts_have_placeholders():
    assert "{focal_point}" in DEFAULT_PROMPTS["insight"]
    assert "{claim}" in DEFAULT_PROMPTS["truthfulness"]


def test_aggregate_prompt_contains_mbel():
    assert "MBEL" in DEFAULT_PROMPTS["aggregate"]


def test_gemini_prompts_importable():
    from neo_cortex.prompts.gemini import GEMINI_PROMPTS
    assert isinstance(GEMINI_PROMPTS, dict)


def test_anthropic_overrides_distill():
    from neo_cortex.prompts.anthropic import ANTHROPIC_PROMPTS
    assert "distill" in ANTHROPIC_PROMPTS
    assert ANTHROPIC_PROMPTS["distill"] != DEFAULT_PROMPTS["distill"]
    assert len(ANTHROPIC_PROMPTS["distill"]) < len(DEFAULT_PROMPTS["distill"])


def test_timeline_resume_has_placeholders():
    assert "{grammar}" in DEFAULT_PROMPTS["timeline_resume"]
    assert "{memories_text}" in DEFAULT_PROMPTS["timeline_resume"]
