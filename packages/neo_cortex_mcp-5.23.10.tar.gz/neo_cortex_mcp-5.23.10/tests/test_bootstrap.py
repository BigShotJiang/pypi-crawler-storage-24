"""Tests for bootstrap — auto-install hooks into .claude/settings.json."""

import json

from neo_cortex.bootstrap import BootstrapResult, ensure_hooks


def test_no_mcp_json(tmp_path):
    """Skip bootstrap if no .mcp.json at project root."""
    result = ensure_hooks(tmp_path)
    assert result.error == "no .mcp.json at project root"
    assert not result.session_start_installed
    assert not result.stop_installed


def test_fresh_install(tmp_path):
    """Install both hooks from scratch."""
    (tmp_path / ".mcp.json").write_text("{}")
    result = ensure_hooks(tmp_path)
    assert result.error is None
    assert result.created_dir
    assert result.created_file
    assert result.session_start_installed
    assert result.stop_installed
    assert not result.already_present
    data = json.loads((tmp_path / ".claude" / "settings.json").read_text())
    assert len(data["hooks"]["SessionStart"]) == 1
    assert "neo-cortex-timeline" in data["hooks"]["SessionStart"][0]["hooks"][0]["command"]
    assert len(data["hooks"]["Stop"]) == 1
    assert "neo-cortex-stop-hook" in data["hooks"]["Stop"][0]["hooks"][0]["command"]


def test_already_installed(tmp_path):
    """Skip if hooks already present."""
    (tmp_path / ".mcp.json").write_text("{}")
    (tmp_path / ".claude").mkdir()
    (tmp_path / ".claude" / "settings.json").write_text(json.dumps({
        "hooks": {
            "SessionStart": [{"matcher": "*", "hooks": [{"type": "command", "command": "uvx --from neo-cortex-mcp@latest neo-cortex-timeline --n 10", "timeout": 15}]}],
            "Stop": [{"matcher": "*", "hooks": [{"type": "command", "command": "uvx --from neo-cortex-mcp@latest neo-cortex-stop-hook", "timeout": 10}]}],
        }
    }))
    result = ensure_hooks(tmp_path)
    assert result.already_present
    assert not result.session_start_installed
    assert not result.stop_installed


def test_partial_install_missing_session_start(tmp_path):
    """Install only SessionStart when Stop already present."""
    (tmp_path / ".mcp.json").write_text("{}")
    (tmp_path / ".claude").mkdir()
    (tmp_path / ".claude" / "settings.json").write_text(json.dumps({
        "hooks": {
            "Stop": [{"matcher": "*", "hooks": [{"type": "command", "command": "neo-cortex-stop-hook", "timeout": 10}]}],
        }
    }))
    result = ensure_hooks(tmp_path)
    assert result.session_start_installed
    assert not result.stop_installed
    data = json.loads((tmp_path / ".claude" / "settings.json").read_text())
    assert len(data["hooks"]["SessionStart"]) == 1
    assert len(data["hooks"]["Stop"]) == 1


def test_preserves_existing_hooks_and_permissions(tmp_path):
    """Other hooks and permissions must survive."""
    (tmp_path / ".mcp.json").write_text("{}")
    (tmp_path / ".claude").mkdir()
    (tmp_path / ".claude" / "settings.json").write_text(json.dumps({
        "permissions": {"allow": ["Read"]},
        "hooks": {
            "SessionStart": [{"matcher": "*", "hooks": [{"type": "command", "command": "echo hello"}]}],
        }
    }))
    result = ensure_hooks(tmp_path)
    assert result.session_start_installed
    assert result.stop_installed
    data = json.loads((tmp_path / ".claude" / "settings.json").read_text())
    assert len(data["hooks"]["SessionStart"]) == 2
    assert data["hooks"]["SessionStart"][0]["hooks"][0]["command"] == "echo hello"
    assert "neo-cortex-timeline" in data["hooks"]["SessionStart"][1]["hooks"][0]["command"]
    assert data["permissions"] == {"allow": ["Read"]}


def test_corrupted_json(tmp_path):
    """Handle corrupted settings.json gracefully."""
    (tmp_path / ".mcp.json").write_text("{}")
    (tmp_path / ".claude").mkdir()
    (tmp_path / ".claude" / "settings.json").write_text("not json {{{")
    result = ensure_hooks(tmp_path)
    assert result.session_start_installed
    assert result.stop_installed
    data = json.loads((tmp_path / ".claude" / "settings.json").read_text())
    assert "hooks" in data


def test_idempotent(tmp_path):
    """Running twice produces same result."""
    (tmp_path / ".mcp.json").write_text("{}")
    r1 = ensure_hooks(tmp_path)
    assert r1.session_start_installed
    r2 = ensure_hooks(tmp_path)
    assert r2.already_present
    assert not r2.session_start_installed
    data = json.loads((tmp_path / ".claude" / "settings.json").read_text())
    assert len(data["hooks"]["SessionStart"]) == 1
    assert len(data["hooks"]["Stop"]) == 1


def test_gitignore_created_when_cortex_db_exists(tmp_path):
    """Bootstrap creates cortex_db/.gitignore if cortex_db/ exists."""
    (tmp_path / ".mcp.json").write_text("{}")
    (tmp_path / "cortex_db").mkdir()
    ensure_hooks(tmp_path)
    gitignore = tmp_path / "cortex_db" / ".gitignore"
    assert gitignore.exists()
    content = gitignore.read_text()
    # Transient files ignored
    assert "*.db-shm" in content
    assert "*.db-wal" in content
    assert "*.log" in content
    assert "stop-hook-state/" in content
    # Data files NOT ignored (they ARE the memory)
    # Check only non-comment lines for patterns
    rules = [l.strip() for l in content.splitlines() if l.strip() and not l.strip().startswith("#")]
    assert "*.sqlite3" not in rules
    assert "*.db" not in rules
    assert "concept_graph.json" not in rules


def test_gitignore_not_overwritten(tmp_path):
    """Bootstrap does not overwrite existing cortex_db/.gitignore."""
    (tmp_path / ".mcp.json").write_text("{}")
    (tmp_path / "cortex_db").mkdir()
    (tmp_path / "cortex_db" / ".gitignore").write_text("custom\n")
    ensure_hooks(tmp_path)
    assert (tmp_path / "cortex_db" / ".gitignore").read_text() == "custom\n"


def test_gitignore_created_when_hooks_already_present(tmp_path):
    """Bootstrap creates cortex_db/.gitignore even when hooks are already installed."""
    (tmp_path / ".mcp.json").write_text("{}")
    (tmp_path / "cortex_db").mkdir()
    # First call installs hooks
    r1 = ensure_hooks(tmp_path)
    assert r1.session_start_installed
    # Remove .gitignore to simulate pre-5.19.0 upgrade
    (tmp_path / "cortex_db" / ".gitignore").unlink()
    # Second call finds hooks already present but should still create .gitignore
    r2 = ensure_hooks(tmp_path)
    assert r2.already_present
    assert (tmp_path / "cortex_db" / ".gitignore").exists()


def test_gitignore_skipped_without_cortex_db(tmp_path):
    """Bootstrap skips .gitignore if cortex_db/ doesn't exist yet."""
    (tmp_path / ".mcp.json").write_text("{}")
    ensure_hooks(tmp_path)
    assert not (tmp_path / "cortex_db" / ".gitignore").exists()
