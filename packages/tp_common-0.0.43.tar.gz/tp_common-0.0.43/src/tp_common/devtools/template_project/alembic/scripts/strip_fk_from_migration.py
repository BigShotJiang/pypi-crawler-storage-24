"""Удаляет все sa.ForeignKeyConstraint из файла миграции (для двухпроходного init)."""

import sys
from pathlib import Path


def _find_project_root(start: Path) -> Path:
    """Ищет корень проекта (каталог с pyproject.toml или alembic.ini)."""
    for parent in [start, *start.parents]:
        if (parent / "pyproject.toml").exists() or (parent / "alembic.ini").exists():
            return parent
    return start


def strip_foreign_keys(file_path: Path) -> None:
    content = file_path.read_text(encoding="utf-8")
    lines = content.splitlines(keepends=True)
    new_lines = []
    for line in lines:
        if "sa.ForeignKeyConstraint" in line or "ForeignKeyConstraint(" in line:
            continue
        new_lines.append(line)
    file_path.write_text("".join(new_lines), encoding="utf-8")
    print(f"Removed FK constraint lines from {file_path}")


def main() -> None:
    if len(sys.argv) < 2:
        print("Usage: python strip_fk_from_migration.py <migration_file.py>")
        sys.exit(1)
    path = Path(sys.argv[1])
    if not path.is_absolute():
        root = _find_project_root(Path(__file__).resolve().parent)
        path = (root / path).resolve()
    if not path.exists():
        print(f"File not found: {path}")
        sys.exit(1)
    strip_foreign_keys(path)


if __name__ == "__main__":
    main()
