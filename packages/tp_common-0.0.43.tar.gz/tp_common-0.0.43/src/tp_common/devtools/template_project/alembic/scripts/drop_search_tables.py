#!/usr/bin/env python3
"""
Скрипт удаления всех таблиц, заканчивающихся на _search.

Примеры: vehicle_diagnostic_cards_search, companies_search, user_search, driver_search.

Использование:
    poetry run python alembic/scripts/drop_search_tables.py
    poetry run python alembic/scripts/drop_search_tables.py --dry-run  # только показать, без удаления
"""

import argparse
import asyncio
import sys
from pathlib import Path

project_root = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(project_root))

from sqlalchemy import text
from sqlalchemy.ext.asyncio import create_async_engine
from src.config import config as project_config


async def get_search_tables(engine) -> list[str]:
    """Находит все таблицы в public, заканчивающиеся на _search."""
    query = text(
        """
        SELECT table_name
        FROM information_schema.tables
        WHERE table_schema = 'public'
          AND table_name LIKE '%_search'
        ORDER BY table_name;
    """
    )
    async with engine.connect() as conn:
        result = await conn.execute(query)
        return [row[0] for row in result]


async def drop_search_tables(dry_run: bool = False) -> None:
    engine_url = project_config.get_async_postgres_url_connection()
    engine = create_async_engine(engine_url, echo=True)

    try:
        tables = await get_search_tables(engine)
        if not tables:
            print("Таблицы *_search не найдены.")
            return

        print(f"Найдено таблиц *_search: {', '.join(tables)}")

        if dry_run:
            print("[--dry-run] Удаление не выполнено.")
            return

        async with engine.begin() as conn:
            for table in tables:
                await conn.execute(
                    text(f'DROP TABLE IF EXISTS public."{table}" CASCADE')
                )
                print(f"Удалено: {table}")
        print("Готово.")

    finally:
        await engine.dispose()


def main() -> None:
    parser = argparse.ArgumentParser(
        description="Удалить все таблицы, заканчивающиеся на _search."
    )
    parser.add_argument(
        "--dry-run",
        action="store_true",
        help="Только показать найденные таблицы, не удалять",
    )
    args = parser.parse_args()
    asyncio.run(drop_search_tables(dry_run=args.dry_run))


if __name__ == "__main__":
    main()
