# aisip-sdk

AISIP SDK — AI Structured Instruction Protocol SDK

- Protocol: https://aisip.dev
- License: MIT
