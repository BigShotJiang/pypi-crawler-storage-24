"""Run insurance-gas tests on Databricks using serverless compute."""

import os
import sys
import time

os.environ["DATABRICKS_HOST"] = "https://dbc-150a27f5-e1e7.cloud.databricks.com/"
os.environ["DATABRICKS_TOKEN"] = "dapi895b482f1aaae1b0cfaab97cbfe4546b"

from databricks.sdk import WorkspaceClient
from databricks.sdk.service import jobs as jobs_sdk

w = WorkspaceClient()

NOTEBOOK_PATH = "/Workspace/insurance-gas-tests"

# Submit one-time job run using serverless compute
run = w.jobs.submit(
    run_name="insurance-gas-tests",
    tasks=[
        jobs_sdk.SubmitTask(
            task_key="run_tests",
            notebook_task=jobs_sdk.NotebookTask(
                notebook_path=NOTEBOOK_PATH,
                source=jobs_sdk.Source.WORKSPACE,
            ),
        )
    ],
)

run_id = run.run_id
print(f"Run submitted: run_id={run_id}")
print(f"Track at: https://dbc-150a27f5-e1e7.cloud.databricks.com/#job/run/{run_id}")

# Poll until done
while True:
    state = w.jobs.get_run(run_id=run_id)
    lc = state.state.life_cycle_state.value
    print(f"  {lc}", flush=True)
    if lc in ("TERMINATED", "SKIPPED", "INTERNAL_ERROR"):
        break
    time.sleep(20)

result_state = state.state.result_state
print(f"\nResult: {result_state.value if result_state else 'UNKNOWN'}")

# Retrieve output
try:
    output = w.jobs.get_run_output(run_id=run_id)
    if output.notebook_output and output.notebook_output.result:
        print("\n--- Output ---")
        txt = output.notebook_output.result
        print(txt[:10000])
    if output.error:
        print(f"\nError: {output.error}")
    if output.error_trace:
        print(f"\nTrace:\n{output.error_trace[:5000]}")
except Exception as e:
    print(f"Could not get output: {e}")

success = result_state and result_state.value == "SUCCESS"
print("\nTESTS PASSED" if success else "\nTESTS FAILED")
sys.exit(0 if success else 1)
