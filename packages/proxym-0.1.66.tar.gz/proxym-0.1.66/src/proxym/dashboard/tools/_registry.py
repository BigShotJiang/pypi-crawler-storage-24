"""Tool registry endpoints: list, summary, get."""

from typing import Any

from fastapi import APIRouter, HTTPException, Query

from proxym.dashboard._environments_api import get_environment_registry
from proxym.tools import ToolCategory, ToolRegistry

router = APIRouter(tags=["tools"])


def _tool_payload(tool, tools_by_environment: dict[str, list[str]], registry) -> dict[str, Any]:
    payload = tool.summary()
    environment = registry.get_tool_environment(tool.name)
    payload["environment_id"] = environment.id if environment else ""
    payload["environment"] = environment.summary(tools_by_environment.get(environment.id, [])) if environment else None
    return payload


@router.get("/")
async def list_tools(
    category: str | None = Query(None, description="Filter by category: ide, agent_cli, browser"),
    available_only: bool = Query(False, description="Only show tools with an available host or docker-backed instance"),
) -> dict[str, Any]:
    """List all registered tools."""
    reg = ToolRegistry.get()
    env_registry = get_environment_registry()
    cat = ToolCategory(category) if category else None
    tools = reg.list_tools(category=cat, available_only=available_only)
    tools_by_environment = env_registry._tools_by_environment()
    return {"tools": [_tool_payload(t, tools_by_environment, env_registry) for t in tools], "count": len(tools)}


@router.get("/summary")
async def tools_summary() -> dict[str, Any]:
    """Summary of tool availability."""
    reg = ToolRegistry.get()
    env_registry = get_environment_registry()
    tools = reg.list_tools()
    tools_by_environment = env_registry._tools_by_environment()
    return {
        "total": len(tools),
        "available": len([tool for tool in tools if tool.is_available]),
        "tools": [_tool_payload(tool, tools_by_environment, env_registry) for tool in tools],
        "environments": env_registry.summary(),
    }


# NOTE: Dynamic route MUST be registered last (after queue_router etc.).
@router.get("/{tool_name}")
async def get_tool(tool_name: str) -> dict[str, Any]:
    """Get details for a specific tool."""
    tool = ToolRegistry.get().get_tool(tool_name)
    if not tool:
        raise HTTPException(404, f"Tool '{tool_name}' not found")
    env_registry = get_environment_registry()
    tools_by_environment = env_registry._tools_by_environment()
    return _tool_payload(tool, tools_by_environment, env_registry)
