"""AI Proxy — Intelligent multi-provider LLM gateway with semantic caching and delta context."""

__version__ = "0.1.66"
