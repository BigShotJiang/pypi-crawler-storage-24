# System Architecture Analysis

## Overview

- **Project**: /home/tom/github/wronai/proxy
- **Primary Language**: python
- **Languages**: python: 156, javascript: 67, shell: 8
- **Analysis Mode**: static
- **Total Functions**: 1783
- **Total Classes**: 140
- **Modules**: 231
- **Entry Points**: 1382

## Architecture by Module

### src.proxym.dashboard.components.tools
- **Functions**: 123
- **File**: `tools.jsx`

### src.proxym.dashboard.components.tickets
- **Functions**: 98
- **File**: `tickets.jsx`

### htmlcov.coverage_html_cb_dd2e7eb5
- **Functions**: 77
- **File**: `coverage_html_cb_dd2e7eb5.js`

### src.proxym.dashboard.components.tasks
- **Functions**: 70
- **File**: `tasks.jsx`

### src.proxym.dashboard.hooks.useDashboardData
- **Functions**: 51
- **File**: `useDashboardData.js`

### src.proxym.dashboard.components.home
- **Functions**: 41
- **File**: `home.jsx`

### src.proxym.dashboard.tickets._manager
- **Functions**: 33
- **Classes**: 1
- **File**: `_manager.py`

### src.proxym.dashboard.components.voice_engine
- **Functions**: 31
- **File**: `voice_engine.jsx`

### src.proxym.dashboard.components.voice
- **Functions**: 30
- **File**: `voice.jsx`

### src.proxym.dashboard.components.vms
- **Functions**: 30
- **File**: `vms.jsx`

### src.proxym.dashboard._environments_api
- **Functions**: 29
- **Classes**: 6
- **File**: `_environments_api.py`

### src.proxym.dashboard.components.setup
- **Functions**: 27
- **File**: `setup.jsx`

### src.proxym.dashboard.tickets.TicketManagerRefactored
- **Functions**: 26
- **Classes**: 4
- **File**: `TicketManagerRefactored.py`

### src.proxym.dashboard.components.projects
- **Functions**: 23
- **File**: `projects.jsx`

### src.proxym.dashboard.components.environments
- **Functions**: 23
- **File**: `environments.jsx`

### src.proxym.dashboard.components.users
- **Functions**: 23
- **File**: `users.jsx`

### src.proxym.dashboard.components.models
- **Functions**: 21
- **File**: `models.jsx`

### src.proxym.dashboard.components.tickets.TicketsPanelRefactored
- **Functions**: 21
- **File**: `TicketsPanelRefactored.jsx`

### src.proxym.dashboard._tickets_api
- **Functions**: 20
- **Classes**: 8
- **File**: `_tickets_api.py`

### src.proxym.accounts
- **Functions**: 20
- **Classes**: 8
- **File**: `__init__.py`

## Key Entry Points

Main execution flows into the system:

### src.proxym.api.diagnostics.run_all_tests
> Run all diagnostic tests and return comprehensive status.
- **Calls**: router.get, enumerate, sum, src.proxym.api._diag_vscode.check_vscode_status, src.proxym.api._diag_proxy.check_llm_proxy, src.proxym.api._diag_roo.check_roo_cline_config, src.proxym.api._diag_vscode.check_extensions, src.proxym.api._diag_providers.check_providers_config

### src.proxym.dashboard.components.tickets.TicketsPanel
- **Calls**: src.proxym.dashboard.components.tickets.useTickets, src.proxym.dashboard.components.tickets.useState, src.proxym.dashboard.components.tickets.Set, src.proxym.dashboard.components.tickets.useCallback, src.proxym.dashboard.components.tickets.setSelectedTicketDetails, src.proxym.dashboard.components.tickets.setSelectedTicketError, src.proxym.dashboard.components.tickets.setSelectedTicketLoading, src.proxym.dashboard.components.tickets.get

### src.proxym.api.completions.chat_completions
> OpenAI-compatible chat completions with intelligent routing.

Extra headers:
  X-Task-Tier: trivial|operational|standard|complex|deep
  X-Inject-Conte
- **Calls**: router.post, src.proxym.observability.log_call, Header, src.proxym.api.completions._route_to_model, src.proxym.api.completions._analyze_request, isinstance, src.proxym.api.completions._inject_provider_key, src.proxym.config.get_settings

### src.proxym.dashboard.components.environments.EnvironmentsPanel
- **Calls**: src.proxym.dashboard.components.environments.useState, src.proxym.dashboard.components.environments.useMemo, src.proxym.dashboard.components.environments.fromEntries, src.proxym.dashboard.components.environments.map, src.proxym.dashboard.components.environments.useCallback, src.proxym.dashboard.components.environments.setLoading, src.proxym.dashboard.components.environments.setError, src.proxym.dashboard.components.environments.all

### src.proxym.dashboard.hooks.useDashboardData.useDashboardData
- **Calls**: src.proxym.dashboard.hooks.useDashboardData.replace, src.proxym.dashboard.hooks.useDashboardData.normalizeDashboardTab, src.proxym.dashboard.hooks.useDashboardData.getInitialRoute, src.proxym.dashboard.hooks.useDashboardData.useState, src.proxym.dashboard.hooks.useDashboardData.getUrlParams, src.proxym.dashboard.hooks.useDashboardData.useCallback, src.proxym.dashboard.hooks.useDashboardData.setTabState, src.proxym.dashboard.hooks.useDashboardData.setSystemSection

### src.proxym.cache.DeltaBuffer.compute_delta
> Compare current files against last-sent snapshots, return delta.
- **Calls**: self.scan, self._classify_changes, max, self._build_diff_text, self._estimate_tokens, logger.info, DeltaPayload, self._make_full_payload

### src.proxym.dashboard.components.voice.VoiceChat
- **Calls**: src.proxym.dashboard.components.voice.setVoiceCredentials, src.proxym.dashboard.components.voice.useState, src.proxym.dashboard.components.voice.useRef, src.proxym.dashboard.components.voice.setHistory, src.proxym.dashboard.components.voice.slice, src.proxym.dashboard.components.voice.setState, src.proxym.dashboard.components.voice._speakTTS, src.proxym.dashboard.components.voice.trim

### src.proxym.accounts.AccountManager._load
- **Calls**: src.proxym.storage.is_sqlite_database, json.loads, logger.info, self.config_path.exists, data.values, logger.info, json.loads, logger.info

### scripts.seed_sprint8.main
- **Calls**: argparse.ArgumentParser, parser.add_argument, parser.add_argument, parser.add_argument, parser.parse_args, args.base.rstrip, httpx.post, services.vscode.entrypoint.print

### src.proxym.cli.tickets.cmd_ticket_show
> Show ticket details.
- **Calls**: services.vscode.entrypoint.print, services.vscode.entrypoint.print, data.get, data.get, data.get, data.get, data.get, data.get

### src.proxym.dashboard.components.tasks.QuickTaskCreator
- **Calls**: src.proxym.dashboard.components.tasks.useState, src.proxym.dashboard.components.tasks.useEffect, src.proxym.dashboard.components.tasks.setAutoTags, src.proxym.dashboard.components.tasks._extractTags, src.proxym.dashboard.components.tasks.filter, src.proxym.dashboard.components.tasks.trim, src.proxym.dashboard.components.tasks.setSubmitting, src.proxym.dashboard.components.tasks.setFeedback

### src.proxym.dashboard.components.tools.TicketDispatchTable
- **Calls**: src.proxym.dashboard.components.tools.useState, src.proxym.dashboard.components.tools.filter, src.proxym.dashboard.components.tools.useEffect, src.proxym.dashboard.components.tools.get, src.proxym.dashboard.components.tools.setTickets, src.proxym.dashboard.components.tools.error, src.proxym.dashboard.components.tools.setLoading, src.proxym.dashboard.components.tools.setProjects

### src.proxym.dashboard.components.tools.ToolHealthPanel
- **Calls**: src.proxym.dashboard.components.tools.useState, src.proxym.dashboard.components.tools.useCallback, src.proxym.dashboard.components.tools.setLoading, src.proxym.dashboard.components.tools.get, src.proxym.dashboard.components.tools.setHealth, src.proxym.dashboard.components.tools.setProviders, src.proxym.dashboard.components.tools.setAvailableProviders, src.proxym.dashboard.components.tools.error

### src.proxym.projects.ProjectRegistry._enrich_local
> Wzbogać metadata lokalnego projektu.
- **Calls**: Path, None.exists, markers.items, None.exists, None.exists, path.exists, None.exists, json.loads

### src.proxym.cli._groups.projects_ctl.project_show
> Show project details.
- **Calls**: project.command, click.argument, src.proxym.ctl._make_args, click.echo, click.echo, click.echo, data.get, data.get

### scripts.proxym-voice-chat.main
- **Calls**: argparse.ArgumentParser, parser.add_argument, parser.add_argument, parser.add_argument, parser.add_argument, parser.parse_args, services.vscode.entrypoint.print, services.vscode.entrypoint.print

### src.proxym.dashboard.tickets._manager.TicketManager._load
- **Calls**: src.proxym.storage.is_sqlite_database, json.loads, isinstance, self._persist_path.exists, tickets_data.items, sprints_data.items, milestones_data.items, self._persist_path.read_text

### src.proxym.tools.executor.ToolExecutor._sync_ticket_execution
> Write job status back to the ticket's last_execution field.
- **Calls**: src.proxym.dashboard._tickets_api._tickets, JobExecution, mgr.get_ticket, mgr.update_ticket, len, len, bool, int

### src.proxym.dashboard.components.tasks.TableExport
- **Calls**: src.proxym.dashboard.components.tasks.useState, src.proxym.dashboard.components.tasks.keys, src.proxym.dashboard.components.tasks.join, src.proxym.dashboard.components.tasks.map, src.proxym.dashboard.components.tasks.stringify, src.proxym.dashboard.components.tasks.replaceAll, src.proxym.dashboard.components.tasks.includes, src.proxym.dashboard.components.tasks.convertToCSV

### src.proxym.dashboard.components.models.TableExport
- **Calls**: src.proxym.dashboard.components.models.useState, src.proxym.dashboard.components.models.keys, src.proxym.dashboard.components.models.join, src.proxym.dashboard.components.models.map, src.proxym.dashboard.components.models.stringify, src.proxym.dashboard.components.models.replaceAll, src.proxym.dashboard.components.models.includes, src.proxym.dashboard.components.models.convertToCSV

### src.proxym.dashboard.components.tools.TableExport
- **Calls**: src.proxym.dashboard.components.tools.useState, src.proxym.dashboard.components.tools.keys, src.proxym.dashboard.components.tools.join, src.proxym.dashboard.components.tools.map, src.proxym.dashboard.components.tools.stringify, src.proxym.dashboard.components.tools.replaceAll, src.proxym.dashboard.components.tools.includes, src.proxym.dashboard.components.tools.convertToCSV

### src.proxym.ctl.queue_shortcut
> Shortcut: show task queue.  = proxym tools queue
- **Calls**: cli.command, src.proxym.ctl._make_args, src.proxym.cli._client.make_client, c.get, r.json, src.proxym.cli._client.print_json_if_yaml, click.echo, data.get

### src.proxym.api.console.ollama_status
> Check Ollama connectivity and list available local models.
- **Calls**: router.get, src.proxym.config.get_settings, settings.model_aliases.get, local_model.startswith, any, httpx.AsyncClient, str, local_model.split

### src.proxym.cli._groups.tickets_ctl.ticket_add
> Create a ticket (minimalistic). Example: proxym ticket add 'fix the router bug'
- **Calls**: ticket.command, click.argument, click.option, click.option, click.option, click.option, click.option, src.proxym.ctl._make_args

### src.proxym.cli._groups.do_ctl.do_cmd
> One command to rule them all.


Examples:
  proxym do "fix crash in /health endpoint"
  proxym do "refactor panel.jsx" --on proxym --with claude-code
- **Calls**: click.command, click.argument, click.option, click.option, click.option, click.option, click.option, click.option

### src.proxym.tools.adapters._vscode.VSCodeAdapter.run
> Start VS Code Web container and verify it's running.
- **Calls**: logger.info, time.monotonic, self._find_compose_dir, self.build_args, shutil.which, logger.warning, ToolResult, stdout_b.decode

### src.proxym.tools.adapters._base.BaseAdapter.run
> Launch the tool and wait for completion.

If the tool binary is not found, delegates to LLM fallback
for real execution via the proxy API.
- **Calls**: self.build_args, logger.info, time.monotonic, shutil.which, logger.info, ToolResult, logger.info, src.proxym.tools.adapters._llm_fallback._llm_fallback_execute

### src.proxym.dashboard.components.diagnostics.DiagnosticsPanel
- **Calls**: src.proxym.dashboard.components.diagnostics.useState, src.proxym.dashboard.components.diagnostics.useCallback, src.proxym.dashboard.components.diagnostics.setLoading, src.proxym.dashboard.components.diagnostics.setError, src.proxym.dashboard.components.diagnostics.fetch, src.proxym.dashboard.components.diagnostics._api, src.proxym.dashboard.components.diagnostics._headers, src.proxym.dashboard.components.diagnostics.Error

### src.proxym.dashboard._projects_api.add_project
> Dodaj projekt — auto-detect typu z podanych parametrów.
- **Calls**: router.post, src.proxym.observability.log_call, src.proxym.dashboard._projects_api._get_registry, str, Project, None.model_dump, None.resolve, src.proxym.config.get_settings

### src.proxym.cli.accounts.cmd_accounts_costs
- **Calls**: src.proxym.cli._client.make_client, None.json, data.get, services.vscode.entrypoint.print, services.vscode.entrypoint.print, services.vscode.entrypoint.print, services.vscode.entrypoint.print, services.vscode.entrypoint.print

## Process Flows

Key execution flows identified:

### Flow 1: run_all_tests
```
run_all_tests [src.proxym.api.diagnostics]
  └─ →> check_vscode_status
      └─ →> get_settings
          └─ →> get_singleton
      └─ →> _probe_first_ok
  └─ →> check_llm_proxy
      └─ →> get_settings
          └─ →> get_singleton
```

### Flow 2: TicketsPanel
```
TicketsPanel [src.proxym.dashboard.components.tickets]
  └─> useTickets
```

### Flow 3: chat_completions
```
chat_completions [src.proxym.api.completions]
  └─> _route_to_model
      └─> _resolve_model
          └─ →> get_settings
      └─> _analyze_request
  └─> _analyze_request
      └─ →> analyze_request
          └─> _extract_user_text
          └─ →> log_call
  └─ →> log_call
      └─> _safe_args
          └─> _truncate
```

### Flow 4: EnvironmentsPanel
```
EnvironmentsPanel [src.proxym.dashboard.components.environments]
  └─> useState
  └─> useMemo
```

### Flow 5: useDashboardData
```
useDashboardData [src.proxym.dashboard.hooks.useDashboardData]
  └─> normalizeDashboardTab
```

### Flow 6: compute_delta
```
compute_delta [src.proxym.cache.DeltaBuffer]
```

### Flow 7: VoiceChat
```
VoiceChat [src.proxym.dashboard.components.voice]
```

### Flow 8: _load
```
_load [src.proxym.accounts.AccountManager]
  └─ →> is_sqlite_database
```

### Flow 9: main
```
main [scripts.seed_sprint8]
```

### Flow 10: cmd_ticket_show
```
cmd_ticket_show [src.proxym.cli.tickets]
  └─ →> print
  └─ →> print
```

## Key Classes

### src.proxym.dashboard.tickets._manager.TicketManager
> In-memory ticket & sprint store with optional JSON persistence.
- **Methods**: 33
- **Key Methods**: src.proxym.dashboard.tickets._manager.TicketManager.__init__, src.proxym.dashboard.tickets._manager.TicketManager.create_ticket, src.proxym.dashboard.tickets._manager.TicketManager.get_ticket, src.proxym.dashboard.tickets._manager.TicketManager.list_tickets, src.proxym.dashboard.tickets._manager.TicketManager._apply_filters, src.proxym.dashboard.tickets._manager.TicketManager._sort_tickets, src.proxym.dashboard.tickets._manager.TicketManager.update_ticket, src.proxym.dashboard.tickets._manager.TicketManager.delete_ticket, src.proxym.dashboard.tickets._manager.TicketManager.add_comment, src.proxym.dashboard.tickets._manager.TicketManager.assign_tool

### src.proxym.dashboard.users.UserManager
> In-memory user store with SQLite persistence and git integration.
- **Methods**: 18
- **Key Methods**: src.proxym.dashboard.users.UserManager.get, src.proxym.dashboard.users.UserManager.reset, src.proxym.dashboard.users.UserManager.__init__, src.proxym.dashboard.users.UserManager._discover_git_user, src.proxym.dashboard.users.UserManager.create_user, src.proxym.dashboard.users.UserManager.get_user, src.proxym.dashboard.users.UserManager.find_by_email, src.proxym.dashboard.users.UserManager.find_by_username, src.proxym.dashboard.users.UserManager.list_users, src.proxym.dashboard.users.UserManager.get_default_user

### src.proxym.virt.clonebox_adapter.CloneBoxAdapter
> Adapter wrapping the clonebox CLI for VM operations.

All operations use `--user` flag for rootless/
- **Methods**: 17
- **Key Methods**: src.proxym.virt.clonebox_adapter.CloneBoxAdapter.__init__, src.proxym.virt.clonebox_adapter.CloneBoxAdapter.is_available, src.proxym.virt.clonebox_adapter.CloneBoxAdapter.version, src.proxym.virt.clonebox_adapter.CloneBoxAdapter.create_vm, src.proxym.virt.clonebox_adapter.CloneBoxAdapter.start_vm, src.proxym.virt.clonebox_adapter.CloneBoxAdapter.stop_vm, src.proxym.virt.clonebox_adapter.CloneBoxAdapter.snapshot, src.proxym.virt.clonebox_adapter.CloneBoxAdapter.restore_snapshot, src.proxym.virt.clonebox_adapter.CloneBoxAdapter.health, src.proxym.virt.clonebox_adapter.CloneBoxAdapter.delete_vm

### src.proxym.accounts.AccountManager
> Central account registry.

Persists to a JSON file, with live metrics in memory (optionally Redis).
- **Methods**: 15
- **Key Methods**: src.proxym.accounts.AccountManager.__init__, src.proxym.accounts.AccountManager._load, src.proxym.accounts.AccountManager._save, src.proxym.accounts.AccountManager.add_account, src.proxym.accounts.AccountManager.remove_account, src.proxym.accounts.AccountManager.get_account, src.proxym.accounts.AccountManager.list_accounts, src.proxym.accounts.AccountManager.find_cheapest_active, src.proxym.accounts.AccountManager.record_usage, src.proxym.accounts.AccountManager.bind_tool

### src.proxym.dashboard._environments_api.EnvironmentRegistry
- **Methods**: 14
- **Key Methods**: src.proxym.dashboard._environments_api.EnvironmentRegistry.__init__, src.proxym.dashboard._environments_api.EnvironmentRegistry._load, src.proxym.dashboard._environments_api.EnvironmentRegistry._save, src.proxym.dashboard._environments_api.EnvironmentRegistry._tools_by_environment, src.proxym.dashboard._environments_api.EnvironmentRegistry.list_environments, src.proxym.dashboard._environments_api.EnvironmentRegistry.list_payloads, src.proxym.dashboard._environments_api.EnvironmentRegistry.get, src.proxym.dashboard._environments_api.EnvironmentRegistry.create, src.proxym.dashboard._environments_api.EnvironmentRegistry.update, src.proxym.dashboard._environments_api.EnvironmentRegistry.delete

### src.proxym.projects.ProjectRegistry
> Rejestr projektów z persystencją JSON.
- **Methods**: 14
- **Key Methods**: src.proxym.projects.ProjectRegistry.__init__, src.proxym.projects.ProjectRegistry.add, src.proxym.projects.ProjectRegistry.get, src.proxym.projects.ProjectRegistry.find_by_name, src.proxym.projects.ProjectRegistry.find_by_path, src.proxym.projects.ProjectRegistry.list_projects, src.proxym.projects.ProjectRegistry.update, src.proxym.projects.ProjectRegistry.remove, src.proxym.projects.ProjectRegistry.scan_directory, src.proxym.projects.ProjectRegistry.add_git_repo

### src.proxym.tools.executor.ToolExecutor
> Async executor for tool jobs with a bounded queue.
- **Methods**: 13
- **Key Methods**: src.proxym.tools.executor.ToolExecutor.__init__, src.proxym.tools.executor.ToolExecutor.get, src.proxym.tools.executor.ToolExecutor.start, src.proxym.tools.executor.ToolExecutor.stop, src.proxym.tools.executor.ToolExecutor.enqueue, src.proxym.tools.executor.ToolExecutor.get_job, src.proxym.tools.executor.ToolExecutor.get_jobs_for_ticket, src.proxym.tools.executor.ToolExecutor.list_jobs, src.proxym.tools.executor.ToolExecutor.cancel_job, src.proxym.tools.executor.ToolExecutor.queue_summary

### src.proxym.observability.watchdog.HealthWatchdog
> Daemon sprawdzający zdrowie systemu w pętli.

Checks:
  - proxy /health
  - provider connectivity (n
- **Methods**: 13
- **Key Methods**: src.proxym.observability.watchdog.HealthWatchdog.__init__, src.proxym.observability.watchdog.HealthWatchdog.start, src.proxym.observability.watchdog.HealthWatchdog.stop, src.proxym.observability.watchdog.HealthWatchdog._loop, src.proxym.observability.watchdog.HealthWatchdog._run_checks, src.proxym.observability.watchdog.HealthWatchdog._check_proxy_health, src.proxym.observability.watchdog.HealthWatchdog._check_providers, src.proxym.observability.watchdog.HealthWatchdog._check_vscode, src.proxym.observability.watchdog.HealthWatchdog._check_budget, src.proxym.observability.watchdog.HealthWatchdog._check_error_rate

### src.proxym.dashboard.tickets.TicketManagerRefactored.TicketManagerRefactored
> Refactored ticket & sprint store with separated concerns.
- **Methods**: 13
- **Key Methods**: src.proxym.dashboard.tickets.TicketManagerRefactored.TicketManagerRefactored.__init__, src.proxym.dashboard.tickets.TicketManagerRefactored.TicketManagerRefactored.create_ticket, src.proxym.dashboard.tickets.TicketManagerRefactored.TicketManagerRefactored.get_ticket, src.proxym.dashboard.tickets.TicketManagerRefactored.TicketManagerRefactored.list_tickets, src.proxym.dashboard.tickets.TicketManagerRefactored.TicketManagerRefactored.update_ticket, src.proxym.dashboard.tickets.TicketManagerRefactored.TicketManagerRefactored.delete_ticket, src.proxym.dashboard.tickets.TicketManagerRefactored.TicketManagerRefactored.create_sprint, src.proxym.dashboard.tickets.TicketManagerRefactored.TicketManagerRefactored.list_sprints, src.proxym.dashboard.tickets.TicketManagerRefactored.TicketManagerRefactored.create_milestone, src.proxym.dashboard.tickets.TicketManagerRefactored.TicketManagerRefactored.list_milestones

### src.proxym.api._pipeline.CompletionPipeline
> Structured pipeline for processing a chat completion request.

Stages:
  1. build_context  — inject 
- **Methods**: 12
- **Key Methods**: src.proxym.api._pipeline.CompletionPipeline.__init__, src.proxym.api._pipeline.CompletionPipeline.execute, src.proxym.api._pipeline.CompletionPipeline._build_context, src.proxym.api._pipeline.CompletionPipeline._route, src.proxym.api._pipeline.CompletionPipeline._inject_tools, src.proxym.api._pipeline.CompletionPipeline._touch_session, src.proxym.api._pipeline.CompletionPipeline._run, src.proxym.api._pipeline.CompletionPipeline._build_kwargs, src.proxym.api._pipeline.CompletionPipeline._execute_with_fallbacks, src.proxym.api._pipeline.CompletionPipeline._make_stream_response

### src.proxym.virt._lifecycle._LifecycleMixin
> VM creation, start, stop, pause, resume.
- **Methods**: 11
- **Key Methods**: src.proxym.virt._lifecycle._LifecycleMixin.create_vm, src.proxym.virt._lifecycle._LifecycleMixin._prepare_clonebox_args, src.proxym.virt._lifecycle._LifecycleMixin._write_cloud_init_file, src.proxym.virt._lifecycle._LifecycleMixin._create_vm_clonebox, src.proxym.virt._lifecycle._LifecycleMixin._create_vm_virsh, src.proxym.virt._lifecycle._LifecycleMixin.start_vm, src.proxym.virt._lifecycle._LifecycleMixin._start_vm_clonebox, src.proxym.virt._lifecycle._LifecycleMixin.stop_vm, src.proxym.virt._lifecycle._LifecycleMixin._stop_vm_clonebox, src.proxym.virt._lifecycle._LifecycleMixin.pause_vm

### src.proxym.context.session.SessionStore
> In-memory session store with TTL-based expiry.

Parameters
----------
max_idle_seconds : float
    S
- **Methods**: 10
- **Key Methods**: src.proxym.context.session.SessionStore.__init__, src.proxym.context.session.SessionStore.get_or_create, src.proxym.context.session.SessionStore.get, src.proxym.context.session.SessionStore.delete, src.proxym.context.session.SessionStore.list_sessions, src.proxym.context.session.SessionStore.clear, src.proxym.context.session.SessionStore._evict_expired, src.proxym.context.session.SessionStore._session_path, src.proxym.context.session.SessionStore._persist_session, src.proxym.context.session.SessionStore._load_sessions

### src.proxym.tools.ToolRegistry
> Singleton registry of available development tools.
- **Methods**: 9
- **Key Methods**: src.proxym.tools.ToolRegistry.__init__, src.proxym.tools.ToolRegistry._apply_env_overrides, src.proxym.tools.ToolRegistry.get, src.proxym.tools.ToolRegistry.register, src.proxym.tools.ToolRegistry.unregister, src.proxym.tools.ToolRegistry.get_tool, src.proxym.tools.ToolRegistry.list_tools, src.proxym.tools.ToolRegistry.list_available, src.proxym.tools.ToolRegistry.summary

### src.proxym.cache.DeltaBuffer
> Maintains file snapshots and computes minimal diffs.

Parameters
----------
watch_dir : str
    Dire
- **Methods**: 9
- **Key Methods**: src.proxym.cache.DeltaBuffer.__init__, src.proxym.cache.DeltaBuffer.scan, src.proxym.cache.DeltaBuffer.compute_delta, src.proxym.cache.DeltaBuffer._make_full_payload, src.proxym.cache.DeltaBuffer._classify_changes, src.proxym.cache.DeltaBuffer._build_diff_text, src.proxym.cache.DeltaBuffer._build_full_context, src.proxym.cache.DeltaBuffer._estimate_tokens, src.proxym.cache.DeltaBuffer.get_stats

### src.proxym.observability.repair_agent.RepairAgent
> Agent naprawiający błędy w kodzie proxym za pomocą LLM.

Tryby:
  suggest — diagnoza + propozycja (d
- **Methods**: 9
- **Key Methods**: src.proxym.observability.repair_agent.RepairAgent.__init__, src.proxym.observability.repair_agent.RepairAgent.diagnose_and_repair, src.proxym.observability.repair_agent.RepairAgent.diagnose_from_logs, src.proxym.observability.repair_agent.RepairAgent.get_history, src.proxym.observability.repair_agent.RepairAgent._build_context, src.proxym.observability.repair_agent.RepairAgent._build_prompt, src.proxym.observability.repair_agent.RepairAgent._call_llm, src.proxym.observability.repair_agent.RepairAgent._apply_fix, src.proxym.observability.repair_agent.RepairAgent._maybe_reset_daily_budget

### src.proxym.cli.dsl.DSLParser
> Parse natural language phrases into proxym API calls.

Works without LLM — pure pattern matching aga
- **Methods**: 8
- **Key Methods**: src.proxym.cli.dsl.DSLParser.__init__, src.proxym.cli.dsl.DSLParser._load_dsl, src.proxym.cli.dsl.DSLParser._compile_patterns, src.proxym.cli.dsl.DSLParser.parse, src.proxym.cli.dsl.DSLParser._resolve_default, src.proxym.cli.dsl.DSLParser._build_command, src.proxym.cli.dsl.DSLParser.execute, src.proxym.cli.dsl.DSLParser.list_patterns

### src.proxym.mcp.registry.MCPRegistry
> Registry of available MCP servers.

Servers can be registered programmatically or loaded from config
- **Methods**: 8
- **Key Methods**: src.proxym.mcp.registry.MCPRegistry.__init__, src.proxym.mcp.registry.MCPRegistry.register, src.proxym.mcp.registry.MCPRegistry.unregister, src.proxym.mcp.registry.MCPRegistry.get, src.proxym.mcp.registry.MCPRegistry.list_servers, src.proxym.mcp.registry.MCPRegistry.available_names, src.proxym.mcp.registry.MCPRegistry.servers_for_tool, src.proxym.mcp.registry.MCPRegistry.load_from_config

### src.proxym.dashboard.tickets.TicketManagerRefactored.TicketFilter
> Extracted filtering logic from TicketManager.
- **Methods**: 8
- **Key Methods**: src.proxym.dashboard.tickets.TicketManagerRefactored.TicketFilter.__init__, src.proxym.dashboard.tickets.TicketManagerRefactored.TicketFilter.apply_sprint_filter, src.proxym.dashboard.tickets.TicketManagerRefactored.TicketFilter.apply_milestone_filter, src.proxym.dashboard.tickets.TicketManagerRefactored.TicketFilter.apply_status_filter, src.proxym.dashboard.tickets.TicketManagerRefactored.TicketFilter.apply_priority_filter, src.proxym.dashboard.tickets.TicketManagerRefactored.TicketFilter.apply_tool_filter, src.proxym.dashboard.tickets.TicketManagerRefactored.TicketFilter.apply_tag_filter, src.proxym.dashboard.tickets.TicketManagerRefactored.TicketFilter.apply_all_filters

### docs.open-webui-tools.proxym_tools.ProxymTools
> Tools for managing proxym AI proxy from Open WebUI.
- **Methods**: 8
- **Key Methods**: docs.open-webui-tools.proxym_tools.ProxymTools.get_status, docs.open-webui-tools.proxym_tools.ProxymTools.list_vms, docs.open-webui-tools.proxym_tools.ProxymTools.create_vm, docs.open-webui-tools.proxym_tools.ProxymTools.start_vm, docs.open-webui-tools.proxym_tools.ProxymTools.stop_vm, docs.open-webui-tools.proxym_tools.ProxymTools.get_costs, docs.open-webui-tools.proxym_tools.ProxymTools.get_logs, docs.open-webui-tools.proxym_tools.ProxymTools.list_models

### src.proxym.virt._vm_config._ConfigMixin
> VM configuration injection: API keys, templates, cloud-init rendering.
- **Methods**: 7
- **Key Methods**: src.proxym.virt._vm_config._ConfigMixin._generate_vm_key, src.proxym.virt._vm_config._ConfigMixin._get_git_config, src.proxym.virt._vm_config._ConfigMixin._render_template, src.proxym.virt._vm_config._ConfigMixin._load_profile_cloud_init, src.proxym.virt._vm_config._ConfigMixin._inject_vm_config, src.proxym.virt._vm_config._ConfigMixin._save_vm_key_mapping, src.proxym.virt._vm_config._ConfigMixin.resolve_vm_key_account

## Data Transformation Functions

Key functions that process and transform data:

### validate_dispatch_table_refactoring.validate_jsx_component
- **Output to**: os.path.exists, open, f.read, missing_exports.append, None.join

### validate_tasks_panel_refactoring.validate_jsx_component
> Validate that a JSX component exists and has expected exports.
- **Output to**: os.path.exists, open, f.read, missing_exports.append, None.join

### validate_human_task_refactoring.validate_jsx_component
> Validate that a JSX component exists and has expected exports.
- **Output to**: os.path.exists, open, f.read, missing_exports.append, None.join

### validate_refactoring.validate_jsx_component
> Validate that a JSX component exists and has expected exports.
- **Output to**: os.path.exists, open, f.read, missing_exports.append, None.join

### validate_tool_health_refactoring.validate_jsx_component
- **Output to**: os.path.exists, open, f.read, missing_exports.append, None.join

### validate_tools_panel_refactoring.validate_jsx_component
> Validate that a JSX component exists and has expected exports.
- **Output to**: os.path.exists, open, f.read, missing_exports.append, None.join

### utils.validation_common.validate_jsx_component
> Validate that a JSX component exists and has expected exports.
- **Output to**: os.path.exists, open, f.read, missing_exports.append, None.join

### src.proxym.dashboard.users.UserManager._parse_git_log_authors
> Parse unique author/email pairs from git log output.
- **Output to**: set, log_output.splitlines, line.split, None.lower, seen.add

### src.proxym.cli.system._format_status_data
> Transform raw API responses into a structured status dict.
- **Output to**: health.get, round, round, round, round

### src.proxym.cli.observability._format_entry
> Format a structured observability entry for CLI display.
- **Output to**: entry.get, isinstance, None.upper, src.proxym.cli.observability._short_value, src.proxym.cli.observability._short_value

### src.proxym.cli.chat._format_result
> Format API response for human-readable chat output.
- **Output to**: _FORMATTERS.get, json.dumps, fmt

### src.proxym.cli.chat._process_input
> Route text through DSL or LLM and return formatted response.
- **Output to**: dsl.parse, src.proxym.cli.chat._ask_proxym_llm, dsl.execute, src.proxym.cli.chat._format_result

### src.proxym.cli.tts.TTSEngine._validate
> Check that the chosen backend is available.
- **Output to**: shutil.which, logger.warning, shutil.which, logger.warning

### src.proxym.cli.dsl.DSLParser.parse
> Try to match *text* against DSL patterns.

Returns ``None`` if no pattern matches — caller should fo
- **Output to**: text.strip, regex.fullmatch, regex.match, self._build_command, m.groupdict

### src.proxym.mcp.client.MCPClient._parse_response
> Parse a successful JSON-RPC response into MCPToolResult.
- **Output to**: data.get, isinstance, MCPToolResult, result.get, isinstance

### src.proxym.api.completions._format_response
> Format completion response with metadata.
- **Output to**: src.proxym.api.completions._usage_tokens, ledger.record, src.proxym.api.completions._response_to_dict, JSONResponse, src.proxym.api.completions._resolve_model

### src.proxym.dashboard.tickets.TicketManagerRefactored.TicketValidator.validate_ticket_data
> Validate ticket data and return list of errors.
- **Output to**: errors.append, errors.append, errors.append, errors.append

### src.proxym.dashboard.tickets.TicketManagerRefactored.TicketValidator.validate_ticket_update
> Validate ticket update data.
- **Output to**: errors.append, errors.append

### src.proxym.dashboard.tools._autofix._process_bulk_fix
> Handle a single fix entry from bulk auto-fix.
- **Output to**: fix.get, fix.get, src.proxym.dashboard.tools._autofix._create_human_action_ticket, AutoFixRequest, fix.get

### src.proxym.dashboard.api._parseBody
- **Output to**: src.proxym.dashboard.api.get, src.proxym.dashboard.api.includes, src.proxym.dashboard.api.json, src.proxym.dashboard.api.text

### src.proxym.dashboard.utils.formatters.formatDate
- **Output to**: src.proxym.dashboard.utils.formatters.Date, src.proxym.dashboard.utils.formatters.floor, src.proxym.dashboard.utils.formatters.toLocaleDateString

### src.proxym.dashboard.utils.formatters.formatDuration
- **Output to**: src.proxym.dashboard.utils.formatters.floor

### src.proxym.dashboard.utils.formatters.formatSize
- **Output to**: src.proxym.dashboard.utils.formatters.toFixed

### src.proxym.dashboard.components.voice_engine.formatToolResult
- **Output to**: src.proxym.dashboard.components.voice_engine.fn, src.proxym.dashboard.components.voice_engine.stringify, src.proxym.dashboard.components.voice_engine.slice

### src.proxym.dashboard.components.voice_engine.processVoiceInput
- **Output to**: src.proxym.dashboard.components.voice_engine.trim, src.proxym.dashboard.components.voice_engine._handleDSL, src.proxym.dashboard.components.voice_engine.onStatus, src.proxym.dashboard.components.voice_engine._buildMessages, src.proxym.dashboard.components.voice_engine._callLLM

## Behavioral Patterns

### recursion_delete_vm
- **Type**: recursion
- **Confidence**: 0.90
- **Functions**: src.proxym.dashboard._vms.delete_vm

### recursion_merge_profiles
- **Type**: recursion
- **Confidence**: 0.90
- **Functions**: src.proxym.virt.profiles.merge_profiles

### state_machine__StateMixin
- **Type**: state_machine
- **Confidence**: 0.70
- **Functions**: src.proxym.virt._state._StateMixin.get_status, src.proxym.virt._state._StateMixin._refresh_state_clonebox, src.proxym.virt._state._StateMixin._refresh_state_virsh, src.proxym.virt._state._StateMixin._get_vm_ip, src.proxym.virt._state._StateMixin.list_vms

## Public API Surface

Functions exposed as public API (no underscore prefix):

- `src.proxym.api.diagnostics.run_all_tests` - 111 calls
- `src.proxym.dashboard.components.tickets.TicketsPanel` - 56 calls
- `src.proxym.dashboard._tickets_api.create_ticket` - 45 calls
- `src.proxym.observability.log_call` - 41 calls
- `src.proxym.api.completions.chat_completions` - 38 calls
- `src.proxym.dashboard.components.environments.EnvironmentsPanel` - 37 calls
- `src.proxym.dashboard.hooks.useDashboardData.useDashboardData` - 33 calls
- `src.proxym.cache.DeltaBuffer.compute_delta` - 31 calls
- `src.proxym.dashboard.components.voice.VoiceChat` - 31 calls
- `src.proxym.api._diag_agent.check_agent_setup` - 30 calls
- `scripts.seed_sprint8.main` - 29 calls
- `src.proxym.api._diag_roo.check_roo_cline_config` - 29 calls
- `src.proxym.cli.tickets.cmd_ticket_show` - 27 calls
- `src.proxym.dashboard.components.tasks.QuickTaskCreator` - 27 calls
- `src.proxym.dashboard.components.tools.TicketDispatchTable` - 27 calls
- `src.proxym.dashboard.components.tools.ToolHealthPanel` - 26 calls
- `src.proxym.cli._groups.projects_ctl.project_show` - 25 calls
- `scripts.proxym-voice-chat.main` - 24 calls
- `src.proxym.dashboard.components.tasks.TableExport` - 23 calls
- `src.proxym.dashboard.components.models.TableExport` - 23 calls
- `src.proxym.dashboard.components.tools.TableExport` - 23 calls
- `src.proxym.ctl.queue_shortcut` - 22 calls
- `src.proxym.api.console.ollama_status` - 22 calls
- `src.proxym.cli._groups.tickets_ctl.ticket_add` - 22 calls
- `src.proxym.cli._groups.do_ctl.do_cmd` - 22 calls
- `src.proxym.tools.adapters._vscode.VSCodeAdapter.run` - 22 calls
- `src.proxym.tools.adapters._base.BaseAdapter.run` - 22 calls
- `src.proxym.dashboard.components.diagnostics.DiagnosticsPanel` - 22 calls
- `src.proxym.dashboard._system.system_status` - 21 calls
- `src.proxym.dashboard._projects_api.add_project` - 21 calls
- `src.proxym.cli.accounts.cmd_accounts_costs` - 21 calls
- `src.proxym.cli._groups.projects_ctl.project_task` - 21 calls
- `src.proxym.tools.adapters._shell.ShellAdapter.run` - 21 calls
- `src.proxym.dashboard.components.setup.SetupPanel` - 21 calls
- `validate_dispatch_table_refactoring.run_validation` - 20 calls
- `validate_tasks_panel_refactoring.run_validation` - 20 calls
- `validate_human_task_refactoring.run_validation` - 20 calls
- `validate_refactoring.run_validation` - 20 calls
- `validate_tool_health_refactoring.run_validation` - 20 calls
- `validate_tools_panel_refactoring.run_validation` - 20 calls

## System Interactions

How components interact:

```mermaid
graph TD
    run_all_tests --> get
    run_all_tests --> enumerate
    run_all_tests --> sum
    run_all_tests --> check_vscode_status
    run_all_tests --> check_llm_proxy
    TicketsPanel --> useTickets
    TicketsPanel --> useState
    TicketsPanel --> Set
    TicketsPanel --> useCallback
    TicketsPanel --> setSelectedTicketDet
    chat_completions --> post
    chat_completions --> log_call
    chat_completions --> Header
    chat_completions --> _route_to_model
    chat_completions --> _analyze_request
    EnvironmentsPanel --> useState
    EnvironmentsPanel --> useMemo
    EnvironmentsPanel --> fromEntries
    EnvironmentsPanel --> map
    EnvironmentsPanel --> useCallback
    useDashboardData --> replace
    useDashboardData --> normalizeDashboardTa
    useDashboardData --> getInitialRoute
    useDashboardData --> useState
    useDashboardData --> getUrlParams
    compute_delta --> scan
    compute_delta --> _classify_changes
    compute_delta --> max
    compute_delta --> _build_diff_text
    compute_delta --> _estimate_tokens
```

## Reverse Engineering Guidelines

1. **Entry Points**: Start analysis from the entry points listed above
2. **Core Logic**: Focus on classes with many methods
3. **Data Flow**: Follow data transformation functions
4. **Process Flows**: Use the flow diagrams for execution paths
5. **API Surface**: Public API functions reveal the interface

## Context for LLM

Maintain the identified architectural patterns and public API surface when suggesting changes.