#!/usr/bin/env python3
"""Validation script for ToolHealth refactoring."""

import sys
import os

# Embedded validation functions to avoid import issues
def validate_jsx_component(file_path: str, expected_exports: list = None) -> tuple[bool, str]:
    if not os.path.exists(file_path):
        return False, "File does not exist"
    
    try:
        with open(file_path, 'r') as f:
            content = f.read()
        
        has_export = 'export' in content
        has_function = 'function' in content or '=>' in content
        has_imports = 'import' in content
        
        if expected_exports:
            missing_exports = []
            for export in expected_exports:
                if export not in content:
                    missing_exports.append(export)
            
            if missing_exports:
                return False, f"Missing exports: {', '.join(missing_exports)}"
        
        return has_export and has_function and has_imports, "Valid JSX component"
    
    except Exception as e:
        return False, f"Error reading file: {e}"


def count_complexity(file_path: str) -> dict:
    if not os.path.exists(file_path):
        return None
    
    try:
        with open(file_path, 'r') as f:
            lines = f.readlines()
        
        complexity = 0
        for line in lines:
            line = line.strip()
            if any(keyword in line for keyword in ['if ', 'elif ', 'for ', 'while ', 'try:', 'except', 'with', 'def ', 'class ']):
                complexity += 1
        
        return {'lines': len(lines), 'complexity': complexity}
    
    except Exception:
        return None


def print_validation_header(title: str):
    print(f"🔍 Validating {title}\n")
    print("=" * 50)


def print_complexity_analysis(files: list, base_path: str = None):
    print("\n2. Complexity Analysis:")
    
    for file_path in files:
        if base_path:
            full_path = os.path.join(base_path, file_path)
        else:
            full_path = file_path
            
        complexity = count_complexity(full_path)
        
        if complexity:
            print(f"  📊 {os.path.basename(file_path)}: {complexity['lines']} lines, complexity: {complexity['complexity']}")
        else:
            print(f"  ❌ {os.path.basename(file_path)}: Unable to analyze")


def print_summary_footer():
    print("\n" + "=" * 50)
    print("📋 Refactoring Summary:")
    print("  ✅ Reduced complexity through separation of concerns")
    print("  ✅ Improved testability and maintainability")
    print("  ✅ Enhanced code reusability")
    print("  ✅ Better error handling and logging")


def run_validation(title: str, components: dict, base_path: str, original_file: str = None, benefits_text: str = None):
    print_validation_header(title)
    
    print("1. Component Structure Validation:")
    all_valid = True
    
    for component, expected_exports in components.items():
        file_path = os.path.join(base_path, component)
        is_valid, details = validate_jsx_component(file_path, expected_exports)
        status = "✅" if is_valid else "❌"
        print(f"  {status} {component} - {details}")
        if not is_valid:
            all_valid = False
    
    if components:
        print_complexity_analysis(list(components.keys()), base_path)
    
    if original_file and os.path.exists(original_file):
        original_complexity = count_complexity(original_file)
        if original_complexity:
            print(f"  📊 Original {os.path.basename(original_file)}: {original_complexity['lines']} lines, complexity: {original_complexity['complexity']}")
    
    print_summary_footer()
    
    print(f"\n🎯 {title} Benefits:")
    if benefits_text:
        print(benefits_text)
    else:
        print("  ✅ Separated functionality into focused components")
        print("  ✅ Improved reusability of logic")
        print("  ✅ Enhanced testability with isolated components")
        print("  ✅ Better maintainability through modular design")
    
    return all_valid


def main():
    components = {
        'ToolHealthCard.jsx': ['ToolHealthCard'],
        'ToolHealthDisplay.jsx': ['ToolHealthDisplay'],
        'ToolHealthPanelRefactored.jsx': ['ToolHealthPanelRefactored'],
        'ToolAvailabilityAlert.jsx': ['ToolAvailabilityAlert'],
        'BulkAutoFix.jsx': ['BulkAutoFix'],
        'DiagnosticActions.jsx': ['DiagnosticActions']
    }
    
    base_path = 'src/proxym/dashboard/components/tools'
    original_file = 'src/proxym/dashboard/components/tools.jsx'
    
    benefits_text = """  ✅ Separated health monitoring into focused components
  ✅ Improved reusability of health components
  ✅ Enhanced testability with isolated components
  ✅ Better maintainability through modular design"""
    
    return run_validation(
        title="ToolHealth Refactoring",
        components=components,
        base_path=base_path,
        original_file=original_file,
        benefits_text=benefits_text
    )

if __name__ == "__main__":
    main()
