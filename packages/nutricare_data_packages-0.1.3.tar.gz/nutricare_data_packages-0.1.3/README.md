# nutricare-data-packages

Nutricare 的数据访问基础包，封装 MongoDB 仓储与本地存储抽象基类。

## 安装

```bash
pip install nutricare-data-packages
```

## 快速使用

```python
from pathlib import Path

from nutricare_data_packages import StorageBase


class ReportStorage(StorageBase):
    @property
    def storage_subdir(self) -> str:
        return "reports"

    def _write_impl(self, relative_path: str, data: bytes) -> Path:
        target = self.resolve_path(relative_path)
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes(data)
        return target


storage = ReportStorage()
storage.write_metadata(
        relative_path=relative_path,
        size=len(content),
        status="pending",
    )
path = storage.write(relative_path, content)
```

## 本地构建与发布

```bash
python -m pip install --upgrade build twine
python -m build
python -m twine check dist/*
python -m twine upload dist/*
```
