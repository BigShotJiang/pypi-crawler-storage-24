from .script01 import Script01
#=======================================================================

class Scripted(Script01):

    TIMES01 = "{}Y, "
    TIMES02 = "{}w, "
    TIMES03 = "{}d, "
    TIMES04 = "{}h, "
    TIMES05 = "{}m, "
    TIMES06 = "{}s"

    TIMES07 = "{}Y, "
    TIMES08 = "{}w, "
    TIMES09 = "{}𝚍, "
    TIMES10 = "{}𝚑, "
    TIMES11 = "{}𝚖, "
    TIMES12 = "{}𝚜"

    TIMES13 = "{}Year, "
    TIMES14 = "{}week, "
    TIMES15 = "{}days, "
    TIMES16 = "{}hours, "
    TIMES17 = "{}minutes, "
    TIMES18 = "{}seconds"

    ERROR01 = "File extension invalid"

#=======================================================================
