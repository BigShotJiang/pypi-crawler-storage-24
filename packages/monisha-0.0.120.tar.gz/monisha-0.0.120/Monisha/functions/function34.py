import re

class Cleantxts:

    @staticmethod
    def get01(incoming):
        moonos = re.sub(r"[_\-]+", " ", incoming)
        moonus = re.sub(r"\s+", " ", moonos).strip()
        return moonus
