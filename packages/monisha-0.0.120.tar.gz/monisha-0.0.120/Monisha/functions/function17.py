import os
import time
import random
from ..scripts import Scripted
from urllib.parse import unquote
from urllib.parse import urlparse
from .collections import SMessage
#=========================================================================

class Filename:

    @staticmethod
    async def get01(extension=None):
        mainos = str(random.randint(10000, 100000000000000))
        moonus = mainos + extension if extension else mainos
        return moonus

#=========================================================================

    @staticmethod
    async def get02(filename, extension=Scripted.DATA06):
        nameas = str(filename)
        finame = os.path.splitext(nameas)[0]
        exexon = os.path.splitext(nameas)[1]
        exoexo = exexon if exexon else str(extension)
        moonus = finame if finame else Scripted.DATA13
        return SMessage(filename=moonus, extension=exoexo)

#=========================================================================
