from ..scripts import Humon, Scripted
#=============================================================================

def Dbytes(sizes, second=Scripted.DATA01):
    if not sizes:
        return Scripted.DATA09 + second
    nomos = 0
    moweo = 1024
    sizes = int(sizes)
    while sizes > moweo:
        sizes /= moweo
        nomos += 1
    moonus = round(sizes, 2)
    moones = Humon.DATA01[nomos]
    return str(moonus) + Scripted.DATA02 + moones + second

#=============================================================================

def Hbytes(sizes, second=Scripted.DATA01):
    if not sizes:
        return Scripted.DATA08 + second
    nomos = 0
    moweo = 1024
    sizes = int(sizes)
    while sizes > moweo:
        sizes /= moweo
        nomos += 1
    moonus = round(sizes, 2)
    moones = Humon.DATA01[nomos]
    return str(moonus) + Scripted.DATA02 + moones + second

#=============================================================================

def Gbytes(sizes, second=Scripted.DATA01):
    if not sizes:
        return Scripted.DATA01 + second
    nomos = 0
    moweo = 1024
    sizes = int(sizes)
    while sizes > moweo:
        sizes /= moweo
        nomos += 1
    moonus = round(sizes, 2)
    moones = Humon.DATA01[nomos]
    return str(moonus) + Scripted.DATA02 + moones + second

#=============================================================================
