import time
import pytz
from datetime import datetime
from ..scripts import Scripted
#=================================================================================

def timend(tsize, dsize, speed):
    moonuo = round((tsize - dsize) / speed)
    return moonuo

#=================================================================================

def uptime(incoming):
    timetaken = time.time() - incoming
    hours, houro = divmod(timetaken, 3600)
    minutes, seconds = divmod(houro, 60)
    return int(hours), int(minutes), int(seconds)

#=================================================================================

def tzone(location="Asia/Kolkata"):
    moonus = datetime.now(tz=pytz.timezone(location))
    return moonus

#=================================================================================

def tveries(moonos):
    moonas = moonos if moonos else 0
    try: moones = moonas if moonas >= 1 else 0
    except Exception: moones = 0
    return moones

#=================================================================================

def Timesed(moonos: int) -> str:
    moonse = tveries(moonos)
    if moonse == 0:
        return Scripted.DATA15
    minute, seconds = divmod(moonse, 60)
    hours, minute = divmod(minute, 60)
    days, hours = divmod(hours, 24)
    week, days = divmod(days, 7)
    year, week = divmod(week, 52)
    mos = (Scripted.TIMES01.format(year) if year else Scripted.DATA01)
    mos += (Scripted.TIMES02.format(week) if week else Scripted.DATA01)
    mos += (Scripted.TIMES03.format(days) if days else Scripted.DATA01)
    mos += (Scripted.TIMES04.format(hours) if hours else Scripted.DATA01)
    mos += (Scripted.TIMES05.format(minute) if minute else Scripted.DATA01)
    mos += (Scripted.TIMES06.format(seconds) if seconds else Scripted.DATA01)
    return mos.rstrip(Scripted.DATA16) if mos else Scripted.DATA15

#=================================================================================

def Timemod(moonos: int) -> str:
    moonse = tveries(moonos)
    if moonse == 0:
        return Scripted.DATA15
    minute, seconds = divmod(moonse, 60)
    hours, minute = divmod(minute, 60)
    days, hours = divmod(hours, 24)
    week, days = divmod(days, 7)
    year, week = divmod(week, 52)
    mos = (Scripted.TIMES07.format(year) if year else Scripted.DATA01)
    mos += (Scripted.TIMES08.format(week) if week else Scripted.DATA01)
    mos += (Scripted.TIMES09.format(days) if days else Scripted.DATA01)
    mos += (Scripted.TIMES10.format(hours) if hours else Scripted.DATA01)
    mos += (Scripted.TIMES11.format(minute) if minute else Scripted.DATA01)
    mos += (Scripted.TIMES12.format(seconds) if seconds else Scripted.DATA01)
    return mos.rstrip(Scripted.DATA16) if mos else Scripted.DATA15

#=================================================================================

def Timesod(moonos: int) -> str:
    moonse = tveries(moonos)
    if moonse == 0:
        return Scripted.DATA15
    minute, seconds = divmod(moonse, 60)
    hours, minute = divmod(minute, 60)
    days, hours = divmod(hours, 24)
    week, days = divmod(days, 7)
    year, week = divmod(week, 52)
    mos = (Scripted.TIMES13.format(year) if year else Scripted.DATA01)
    mos += (Scripted.TIMES14.format(week) if week else Scripted.DATA01)
    mos += (Scripted.TIMES15.format(days) if days else Scripted.DATA01)
    mos += (Scripted.TIMES16.format(hours) if hours else Scripted.DATA01)
    mos += (Scripted.TIMES17.format(minute) if minute else Scripted.DATA01)
    mos += (Scripted.TIMES18.format(seconds) if seconds else Scripted.DATA01)
    return mos.rstrip(Scripted.DATA16) if mos else Scripted.DATA15

#=================================================================================
