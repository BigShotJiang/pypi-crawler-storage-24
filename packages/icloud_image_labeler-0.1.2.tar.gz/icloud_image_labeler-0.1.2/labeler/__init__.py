"""iCloud Image Labeler package."""
