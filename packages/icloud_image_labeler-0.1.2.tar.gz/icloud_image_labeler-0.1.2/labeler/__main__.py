"""Entry point for python -m labeler."""

from labeler.cli import main

main()
