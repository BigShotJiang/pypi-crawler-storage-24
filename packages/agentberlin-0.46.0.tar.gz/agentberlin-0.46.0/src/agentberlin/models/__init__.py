"""Pydantic models for Agent Berlin API responses."""

from .analytics import (
    AnalyticsResponse,
    ChannelBreakdown,
    CompetitorSummary,
    DailyTraffic,
    DataRange,
    TopicSummary,
    TrafficData,
    VisibilityData,
    VisibilityPoint,
)
from .brand import BrandProfileResponse, BrandProfileUpdateResponse, Topic
from .files import FileMetadata, FileUploadResponse
from .search import (
    ClusterKeywordResult,
    ClusterKeywordsResponse,
    ClusterListResponse,
    ClusterSummary,
    KeywordListResponse,
    KeywordResult,
    KeywordSearchResponse,
    PageDetailResponse,
    PageLink,
    PageLinksDetail,
    PageSearchResponse,
    PageTopicInfo,
    SimilarChunkSet,
    SimilarPage,
)
from .gsc import (
    SearchAnalyticsResponse,
    SearchAnalyticsRow,
    SiteInfo,
    Sitemap,
    SitemapContent,
    SitemapListResponse,
    UrlInspectionResponse,
    UrlInspectionResult,
)
from .google_cse import GoogleCSEResponse, GoogleCSEResult
from .reddit import (
    PostCommentsResponse,
    RedditComment,
    RedditPost,
    RedditSearchResponse,
    SubredditInfo,
    SubredditPostsResponse,
)
from .serpapi import SerpApiMetadata, SerpApiResponse, SerpApiResult
from .llm_search import (
    LLMSearchCitation,
    LLMSearchResponse,
    LLMSearchResult,
    LLMSearchUsage,
)

__all__ = [
    # Analytics
    "AnalyticsResponse",
    "VisibilityData",
    "VisibilityPoint",
    "TrafficData",
    "ChannelBreakdown",
    "DailyTraffic",
    "TopicSummary",
    "CompetitorSummary",
    "DataRange",
    # Search
    "PageSearchResponse",
    "SimilarPage",
    "SimilarChunkSet",
    "KeywordSearchResponse",
    "KeywordListResponse",
    "KeywordResult",
    "ClusterListResponse",
    "ClusterSummary",
    "ClusterKeywordsResponse",
    "ClusterKeywordResult",
    "PageDetailResponse",
    "PageLinksDetail",
    "PageLink",
    "PageTopicInfo",
    # Brand
    "BrandProfileResponse",
    "BrandProfileUpdateResponse",
    "Topic",
    # Files
    "FileMetadata",
    "FileUploadResponse",
    # Google Custom Search
    "GoogleCSEResponse",
    "GoogleCSEResult",
    # SerpApi
    "SerpApiResponse",
    "SerpApiResult",
    "SerpApiMetadata",
    # GSC (Google Search Console)
    "SearchAnalyticsResponse",
    "SearchAnalyticsRow",
    "SiteInfo",
    "Sitemap",
    "SitemapContent",
    "SitemapListResponse",
    "UrlInspectionResponse",
    "UrlInspectionResult",
    # Reddit
    "RedditPost",
    "RedditComment",
    "SubredditInfo",
    "SubredditPostsResponse",
    "RedditSearchResponse",
    "PostCommentsResponse",
    # LLM Search
    "LLMSearchCitation",
    "LLMSearchResponse",
    "LLMSearchResult",
    "LLMSearchUsage",
]
