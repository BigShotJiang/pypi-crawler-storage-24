"""LLM Search resource for Agent Berlin SDK."""

from typing import List, Optional

from .._http import HTTPClient
from ..models.llm_search import LLMSearchResponse


class LLMSearchResource:
    """Resource for LLM-powered web search operations.

    Provides AI-powered web search using Perplexity, ChatGPT, or Gemini.
    Each provider offers different capabilities for grounded, cited responses.

    Example:
        # Perplexity search
        result = client.llm_search.search(
            model="sonar",
            user_query="What are the best SEO practices for 2024?",
        )
        print(result.content)
        for citation in result.citations:
            print(f"  Source: {citation.url}")

        # OpenAI search
        result = client.llm_search.search(
            model="gpt-5-mini",
            user_query="Latest AI developments",
            system_prompt="Be concise and focus on key points.",
        )

        # Gemini search
        result = client.llm_search.search(
            model="gemini-2.5-flash",
            user_query="Current trends in digital marketing",
        )
    """

    def __init__(self, http: HTTPClient) -> None:
        self._http = http

    def search(
        self,
        model: str,
        user_query: str,
        *,
        system_prompt: Optional[str] = None,
        search_context_size: Optional[str] = None,
        domain_filter: Optional[List[str]] = None,
        recency_filter: Optional[str] = None,
        max_tokens: Optional[int] = None,
        temperature: Optional[float] = None,
        include_citations: Optional[bool] = None,
    ) -> LLMSearchResponse:
        """Perform an LLM-powered web search with citations.

        Supports multiple AI providers (Perplexity, OpenAI, Gemini) with
        automatic routing based on the model name.

        Args:
            model: Model to use for the search. Supported models:
                   - Perplexity: sonar, sonar-pro
                   - OpenAI: gpt-5-mini, gpt-5.4
                   - Gemini: gemini-2.5-flash, gemini-2.5-pro, gemini-3-flash, gemini-3-pro-preview
            user_query: The search query or question to answer.
            system_prompt: Optional system prompt to guide the AI's behavior.
            search_context_size: Amount of search context to include.
                                 Options: 'low', 'medium', 'high'.
                                 Supported by Perplexity and OpenAI.
            domain_filter: List of domains to restrict search to.
                          Prefix with '-' to exclude a domain.
                          Perplexity only.
            recency_filter: Limit results to recent content.
                           Options: 'hour', 'day', 'week', 'month'.
                           Perplexity only.
            max_tokens: Maximum tokens in the response.
            temperature: Randomness of the response (0.0 = deterministic, 1.0 = creative).
            include_citations: Whether to include source citations (default: True).

        Returns:
            LLMSearchResponse with generated content, citations, and usage stats.
        """
        payload: dict[str, object] = {
            "model": model,
            "user_query": user_query,
        }
        if system_prompt is not None:
            payload["system_prompt"] = system_prompt
        if search_context_size is not None:
            payload["search_context_size"] = search_context_size
        if domain_filter is not None:
            payload["domain_filter"] = domain_filter
        if recency_filter is not None:
            payload["recency_filter"] = recency_filter
        if max_tokens is not None:
            payload["max_tokens"] = max_tokens
        if temperature is not None:
            payload["temperature"] = temperature
        if include_citations is not None:
            payload["include_citations"] = include_citations

        data = self._http.post("/llm-search/search", json=payload)
        return LLMSearchResponse.model_validate(data)
