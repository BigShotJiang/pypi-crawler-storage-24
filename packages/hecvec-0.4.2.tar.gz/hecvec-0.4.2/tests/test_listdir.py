"""Tests for hecvec.listdir (no external deps)."""
import tempfile
from pathlib import Path

import pytest

from hecvec.listdir import ALLOWED_EXTENSIONS, ListDir, ListDirTextFiles


def test_listdir_empty_root(tmp_path: Path) -> None:
    """List empty dir returns []."""
    lister = ListDir(tmp_path)
    assert lister.listdir(".") == []


def test_listdir_one_level(tmp_path: Path) -> None:
    """List dir returns sorted entries (dirs first)."""
    (tmp_path / "b.txt").write_text("b")
    (tmp_path / "a").mkdir()
    (tmp_path / "c.md").write_text("c")
    lister = ListDir(tmp_path)
    entries = lister.listdir(".")
    assert entries == ["a", "b.txt", "c.md"]


def test_listdir_root_must_exist() -> None:
    """ListDir(root=...) requires an existing directory."""
    with pytest.raises(ValueError, match="root must be an existing directory"):
        ListDir("/nonexistent/path")


def test_listdir_text_files_only_txt_md(tmp_path: Path) -> None:
    """ListDirTextFiles returns only .txt and .md full paths."""
    (tmp_path / "a.txt").write_text("a")
    (tmp_path / "b.md").write_text("b")
    (tmp_path / "c.pdf").write_text("c")
    lister = ListDirTextFiles(tmp_path)
    paths = lister.listdir_recursive_txt_md(".")
    assert len(paths) == 2
    assert paths[0].name in ("a.txt", "b.md")
    assert paths[1].name in ("a.txt", "b.md")
    assert all(p.suffix.lower() in ALLOWED_EXTENSIONS for p in paths)


def test_listdir_recursive_txt_md(tmp_path: Path) -> None:
    """Recursive list finds .txt in subdirs."""
    sub = tmp_path / "sub"
    sub.mkdir()
    (sub / "inner.txt").write_text("inner")
    lister = ListDirTextFiles(tmp_path)
    paths = lister.listdir_recursive_txt_md(".")
    assert len(paths) == 1
    assert paths[0].name == "inner.txt"
