"""
Load environment and secrets (e.g. OPENAI_API_KEY from .env).
Use this module to centralize dotenv and env access.
"""
from __future__ import annotations

import os
from pathlib import Path


def load_dotenv_if_available(dotenv_path: str | Path | None = None) -> None:
    """Load .env into os.environ if python-dotenv is installed. No-op otherwise."""
    try:
        from dotenv import load_dotenv
        load_dotenv(dotenv_path)
    except ImportError:
        pass


def load_openai_key(dotenv_path: str | Path | None = None) -> str | None:
    """
    Load OPENAI_API_KEY from the environment.
    If dotenv_path is given (or python-dotenv is available), loads .env first.
    """
    load_dotenv_if_available(dotenv_path)
    return os.environ.get("OPENAI_API_KEY")
