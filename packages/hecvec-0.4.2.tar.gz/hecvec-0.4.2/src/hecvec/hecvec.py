"""
Pipeline entrypoint. Re-exports Slicer from pipeline.
"""
from hecvec.pipeline import Slicer

__all__ = ["Slicer"]
