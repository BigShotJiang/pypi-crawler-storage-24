"""
OpenAI embeddings. One module = one responsibility: turn text list into embedding vectors.
Requires: pip install hecvec[chroma] (openai).
"""
from __future__ import annotations

from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from openai import OpenAI

DEFAULT_MODEL = "text-embedding-3-small"
DEFAULT_BATCH_SIZE = 100


def _get_openai_client(api_key: str | None = None) -> "OpenAI":
    from openai import OpenAI
    if not api_key:
        raise ValueError("api_key is required for embeddings")
    return OpenAI(api_key=api_key)


def embed_texts(
    texts: list[str],
    api_key: str,
    model: str = DEFAULT_MODEL,
    batch_size: int = DEFAULT_BATCH_SIZE,
) -> list[list[float]]:
    """
    Embed a list of text strings with OpenAI.
    Returns a list of embedding vectors (same order as texts).
    """
    client = _get_openai_client(api_key)
    out: list[list[float]] = []
    for start in range(0, len(texts), batch_size):
        batch = texts[start : start + batch_size]
        response = client.embeddings.create(model=model, input=batch)
        out.extend([item.embedding for item in response.data])
    return out
