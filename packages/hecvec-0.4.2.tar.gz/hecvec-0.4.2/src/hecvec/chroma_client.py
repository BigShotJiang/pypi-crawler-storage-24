"""
Chroma client and collection operations. One module = one responsibility: connect and add documents.
Requires: pip install hecvec[chroma] (chromadb).
"""
from __future__ import annotations

from typing import TYPE_CHECKING

if TYPE_CHECKING:
    import chromadb

DEFAULT_HOST = "localhost"
DEFAULT_PORT = 8000


def get_client(host: str = DEFAULT_HOST, port: int = DEFAULT_PORT):
    """Return a Chroma HTTP client, or an in-memory client if the server is not reachable."""
    import chromadb
    try:
        return chromadb.HttpClient(host=host, port=port)
    except Exception:
        return chromadb.EphemeralClient()


def get_or_create_collection(
    client: "chromadb.HttpClient",
    name: str,
    metadata: dict | None = None,
):
    """Get or create a collection (cosine similarity by default)."""
    if metadata is None:
        metadata = {"hnsw:space": "cosine"}
    return client.get_or_create_collection(name=name, metadata=metadata)


def add_documents(
    client: "chromadb.HttpClient",
    collection_name: str,
    ids: list[str],
    embeddings: list[list[float]],
    documents: list[str],
) -> None:
    """
    Add documents to a collection. If dimension mismatch, deletes and recreates the collection.
    """
    import chromadb
    coll = get_or_create_collection(client, collection_name)
    try:
        coll.add(ids=ids, embeddings=embeddings, documents=documents)
    except chromadb.errors.InvalidArgumentError as e:
        if "dimension" not in str(e).lower():
            raise
        client.delete_collection(name=collection_name)
        coll = client.create_collection(
            name=collection_name,
            metadata={"hnsw:space": "cosine"},
        )
        coll.add(ids=ids, embeddings=embeddings, documents=documents)
