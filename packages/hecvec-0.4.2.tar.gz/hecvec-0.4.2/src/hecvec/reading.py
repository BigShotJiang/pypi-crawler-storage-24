"""Read text files and expose content as strings."""
from __future__ import annotations

import logging
from pathlib import Path

logger = logging.getLogger(__name__)

# Fallback encodings to try if UTF-8 fails (e.g. Windows Latin-1 / CP1252)
FALLBACK_ENCODINGS = ("utf-8", "latin-1", "cp1252")


class ReadText:
    """
    Given a list of file paths (.txt and .md), reads each as text.
    Returns (path, text) pairs. Tries UTF-8 first, then latin-1, then cp1252.
    """

    def __init__(self, paths: list[str] | list[Path], encoding: str = "utf-8"):
        self.paths = [Path(p) for p in paths]
        self.encoding = encoding

    def read_all(self) -> list[tuple[Path, str]]:
        """
        Read each file as text.
        Returns a list of (path, text). Skips non-files and missing paths.
        """
        out = []
        for p in self.paths:
            if not p.is_file():
                logger.debug("Saltando (no es archivo): %s", p)
                continue
            text = None
            for enc in FALLBACK_ENCODINGS:
                try:
                    text = p.read_text(encoding=enc)
                    if enc != "utf-8":
                        logger.info("Leído con encoding %s: %s", enc, p.name)
                    break
                except (OSError, UnicodeDecodeError) as e:
                    if enc == FALLBACK_ENCODINGS[-1]:
                        logger.warning("No se pudo leer %s: %s", p, e)
                    continue
            if text is not None:
                out.append((p.resolve(), text))
        return out

    def __iter__(self):
        """Iterate over (path, text)."""
        for p in self.paths:
            if not p.is_file():
                continue
            for enc in FALLBACK_ENCODINGS:
                try:
                    text = p.read_text(encoding=enc)
                    yield p.resolve(), text
                    break
                except (OSError, UnicodeDecodeError):
                    continue
