"""
Token-based text chunking (TokenTextSplitter from langchain).
One module = one responsibility: split text by token count.
Requires: pip install hecvec[chunk] or hecvec[chroma]
"""
from __future__ import annotations

from pathlib import Path
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from langchain_text_splitters import TokenTextSplitter

DEFAULT_CHUNK_SIZE = 200
DEFAULT_CHUNK_OVERLAP = 0
DEFAULT_ENCODING_NAME = "cl100k_base"


def _get_token_splitter(
    chunk_size: int = DEFAULT_CHUNK_SIZE,
    chunk_overlap: int = DEFAULT_CHUNK_OVERLAP,
    encoding_name: str = DEFAULT_ENCODING_NAME,
) -> "TokenTextSplitter":
    try:
        from langchain_text_splitters import TokenTextSplitter
    except ImportError as e:
        raise ImportError(
            "Token splitting requires langchain-text-splitters. Install with: pip install hecvec[chunk]"
        ) from e
    return TokenTextSplitter(
        chunk_size=chunk_size,
        chunk_overlap=chunk_overlap,
        encoding_name=encoding_name,
    )


def token_chunk_text(
    text: str,
    chunk_size: int = DEFAULT_CHUNK_SIZE,
    chunk_overlap: int = DEFAULT_CHUNK_OVERLAP,
    encoding_name: str = DEFAULT_ENCODING_NAME,
) -> list[str]:
    """Split a single document text into chunks by token count."""
    splitter = _get_token_splitter(chunk_size, chunk_overlap, encoding_name)
    return splitter.split_text(text)


def token_chunk_documents(
    path_and_texts: list[tuple[str | Path, str]],
    chunk_size: int = DEFAULT_CHUNK_SIZE,
    chunk_overlap: int = DEFAULT_CHUNK_OVERLAP,
    encoding_name: str = DEFAULT_ENCODING_NAME,
) -> tuple[list[str], list[str]]:
    """
    Chunk multiple documents by token count.
    Returns (ids, documents) where ids are chunk_0, chunk_1, ...
    """
    splitter = _get_token_splitter(chunk_size, chunk_overlap, encoding_name)
    documents: list[str] = []
    ids: list[str] = []
    for path, text in path_and_texts:
        for content in splitter.split_text(text):
            if not content.strip():
                continue
            ids.append(f"chunk_{len(ids)}")
            documents.append(content)
    return ids, documents
