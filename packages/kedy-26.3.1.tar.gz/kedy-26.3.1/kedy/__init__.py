"""
Kedy - Dataset generation, model training, and deployment CLI.
"""

__version__ = "2.1.62"
__author__ = "Kedy"
__description__ = "Generate datasets, train models, and deploy APIs from the terminal."


def main():
    from kedy.cli import main as _main
    _main()