Hello User!!

Kedy hasn't released yet. Go to https://www.kedy.dev/#waitlist to join our waitlist!!

Thank you,
Kedy Team