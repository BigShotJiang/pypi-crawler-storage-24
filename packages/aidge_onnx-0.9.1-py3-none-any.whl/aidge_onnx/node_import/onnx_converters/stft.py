"""
Copyright (c) 2024 CEA-List

This program and the accompanying materials are made available under the
terms of the Eclipse Public License 2.0 which is available at
http://www.eclipse.org/legal/epl-2.0.

SPDX-License-Identifier: EPL-2.0
"""

import onnx
from onnx import NodeProto

import aidge_core
from aidge_core import Log
from aidge_onnx.node_import import auto_register_import
from aidge_onnx.utils import get_node_attributes


@auto_register_import("stft")
def import_stft(
    onnx_node: NodeProto,
    input_nodes: list[tuple[aidge_core.Node, int]],
    opset: int,
    inputs_tensor_info: list[onnx.ValueInfoProto | None],
) -> aidge_core.Node:
    """
    :param onnx_node: ONNX node to convert
    :type onnx_node: onnx.NodeProto
    :param input_nodes: List of Aidge nodes which constitute the input of the current node
    :type input_nodes: list[aidge_core.Node]
    """
    node_name = onnx_node.output[0]
    onnx_attrs = get_node_attributes(onnx_node, opset)
    stft_attrs: dict = {"onesided": False}

    if "onesided" in onnx_attrs:
        stft_attrs["onesided"] = onnx_attrs["onesided"]
        del onnx_attrs["onesided"]

    if len(onnx_attrs) > 0:
        Log.warn(
            f"Warning: Attribute {onnx_attrs.keys()} is not supported for operator stft."
        )
        return None

    stft_op = aidge_core.STFTOp(**stft_attrs)
    stft = aidge_core.Node(stft_op, name=node_name)
    input_complex = aidge_core.InnerPairToComplex()
    input_complex.add_child(stft, 0, 0)
    output_complex = aidge_core.ComplexToInnerPair()
    stft.add_child(output_complex, 0, 0)
    graph = aidge_core.get_connected_graph_view(stft)

    my_node = aidge_core.meta_operator("STFT_ONNX", graph, name=node_name)
    Log.info(
        f"Loaded node [\033[1m\033[3m{node_name}\033[0m] of type [\033[1m\033[3m{onnx_node.op_type}\033[0m]"
    )
    return my_node
