"""
Copyright (c) 2023 CEA-List

This program and the accompanying materials are made available under the
terms of the Eclipse Public License 2.0 which is available at
http://www.eclipse.org/legal/epl-2.0.

SPDX-License-Identifier: EPL-2.0
"""

import onnx
from onnx import NodeProto

import aidge_core
from aidge_core import Log
from aidge_onnx.node_import import auto_register_import
from aidge_onnx.utils import get_node_attributes


@auto_register_import("layernormalization")
def import_sub(
    onnx_node: NodeProto,
    input_nodes: list[tuple[aidge_core.Node, int]],
    opset: int,
    inputs_tensor_info: list[onnx.ValueInfoProto | None],
) -> aidge_core.Node:
    """
    :param onnx_node: ONNX node to convert
    :type onnx_node: onnx.NodeProto
    :param input_nodes: List of Aidge nodes which constitute the input of the current node
    :type input_nodes: list[aidge_core.Node]
    :param opset: Indicate opset version of the ONNX model, default=None
    :type opset: int, optional
    """
    node_name = onnx_node.name if onnx_node.name else onnx_node.output[0]
    onnx_attrs = get_node_attributes(onnx_node, opset)

    if len(input_nodes) != 3:
        Log.warn(
            f"Warning: LayerNormalization expects exactly 3 inputs (input, scale, bias), got {len(input_nodes)}. This node will be filled by a GenericOperator."
        )
        return None

    layernorm_attrs: dict = {"axis": -1, "epsilon": 1e-05}

    if "axis" in onnx_attrs:
        layernorm_attrs["axis"] = onnx_attrs["axis"]
        del onnx_attrs["axis"]

    if "epsilon" in onnx_attrs:
        layernorm_attrs["epsilon"] = onnx_attrs["epsilon"]
        del onnx_attrs["epsilon"]

    if "stash_type" in onnx_attrs:
        if onnx_attrs["stash_type"] == 1:
            del onnx_attrs["stash_type"]

    if len(onnx_attrs) > 0:
        Log.warn(
            f"Warning: unsupported attribute(s): {onnx_attrs.keys()} for operator 'LayerNormalization' with opset {opset}.\nThis node will be filled by a GenericOperator."
        )
        return None

    try:
        scale_node, _ = input_nodes[1]
        bias_node, bias_output_idx = input_nodes[2]
        if not scale_node or not bias_node:
            raise ValueError("Missing scale or bias input")
    except (IndexError, AttributeError, ValueError) as e:
        Log.warn(
            f"Warning: Invalid input configuration for LayerNormalization: {e}. This node will be filled by a GenericOperator."
        )
        return None

    nb_features = bias_node.get_operator().get_output(bias_output_idx).dims[0]

    my_node = aidge_core.LayerNorm(
        nb_features=nb_features,
        axis=layernorm_attrs["axis"],
        epsilon=layernorm_attrs["epsilon"],
        name=node_name,
    )
    Log.info(
        f"Loaded node [\033[1m\033[3m{node_name}\033[0m] of type [\033[1m\033[3m{onnx_node.op_type}\033[0m]"
    )
    return my_node
