"""
Copyright (c) 2023 CEA-List

This program and the accompanying materials are made available under the
terms of the Eclipse Public License 2.0 which is available at
http://www.eclipse.org/legal/epl-2.0.

SPDX-License-Identifier: EPL-2.0
"""

from onnx import NodeProto, ValueInfoProto

from aidge_core import Log, Node, RandomNormalLikeOp
from aidge_onnx.dtype_converter import onnx_to_aidge
from aidge_onnx.node_import import auto_register_import
from aidge_onnx.utils import get_node_attributes


@auto_register_import("randomnormallike")
def import_random_normal_like(
    onnx_node: NodeProto,
    input_nodes: list[tuple[Node, int]],
    opset: int,
    inputs_tensor_info: list[ValueInfoProto | None],
) -> Node:
    """
    :param onnx_node: ONNX node to convert
    :type onnx_node: onnx.NodeProto
    :param input_nodes: List of Aidge nodes which constitute the input of the current node
    :type input_nodes: list[aidge_core.Node]
    :param opset: Indicate opset version of the ONNX model, default=None
    :type opset: int, optional
    """
    node_name = onnx_node.name if onnx_node.name else onnx_node.output[0]
    onnx_attrs = get_node_attributes(onnx_node, opset)
    rnl_attrs = {"mean": 0.0, "scale": 1.0}  # Default values

    if "mean" in onnx_attrs:
        rnl_attrs["mean"] = onnx_attrs["mean"]
        del onnx_attrs["mean"]

    if "scale" in onnx_attrs:
        rnl_attrs["scale"] = onnx_attrs["scale"]
        del onnx_attrs["scale"]

    if "seed" in onnx_attrs:
        rnl_attrs["seed"] = onnx_attrs["seed"]
        del onnx_attrs["seed"]

    if "dtype" in onnx_attrs:
        rnl_attrs["dtype"] = onnx_to_aidge(onnx_attrs["dtype"])
        del onnx_attrs["dtype"]

    if len(onnx_attrs) > 0:
        Log.warn(
            f"Warning: unsupported attribute(s): {onnx_attrs.keys()} for operator 'RandomNormalLike' with opset {opset}.\nThis node will be filled by a GenericOperator."
        )
        return None

    my_node = Node(RandomNormalLikeOp(**rnl_attrs), name=node_name)
    Log.info(
        f"Loaded node [\033[1m\033[3m{node_name}\033[0m] of type [\033[1m\033[3m{onnx_node.op_type}\033[0m]"
    )
    return my_node
