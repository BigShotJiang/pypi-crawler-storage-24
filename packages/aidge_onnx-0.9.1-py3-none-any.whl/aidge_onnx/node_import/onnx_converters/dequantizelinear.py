"""
Copyright (c) 2023 CEA-List

This program and the accompanying materials are made available under the
terms of the Eclipse Public License 2.0 which is available at
http://www.eclipse.org/legal/epl-2.0.

SPDX-License-Identifier: EPL-2.0
"""

import onnx
from onnx import NodeProto

import aidge_core
from aidge_core import Log
from aidge_onnx.node_import import auto_register_import
from aidge_onnx.utils import get_node_attributes, warn_unsupported_attr


@auto_register_import("dequantizelinear")
def import_dequantizelinear(
    onnx_node: NodeProto,
    input_nodes: list[tuple[aidge_core.Node, int]],
    opset: int,
    inputs_tensor_info: list[onnx.ValueInfoProto | None],
) -> aidge_core.Node:
    """
    :param onnx_node: ONNX node to convert
    :type onnx_node: onnx.NodeProto
    :param input_nodes: List of Aidge nodes which constitute the input of the current node
    :type input_nodes: list[aidge_core.Node]
    :param opset: Indicate opset version of the ONNX model, default=None
    :type opset: int, optional
    """
    # DequantizeLinear is originally an Onnx operator used to dequantize a quantized tensor
    # dequantization uses the following formula : y = (x - x_zero_point) * x_scale
    # Inputs descriptions:
    # x: quantized input tensor
    # y_scale: scaling factor used in the dequantization
    # y_zero_point (optional): zero point used in the dequantization

    node_name = onnx_node.name if onnx_node.name else onnx_node.output[0]
    onnx_attrs = get_node_attributes(onnx_node, opset)

    if opset >= 13:
        if "axis" in onnx_attrs:
            if onnx_attrs["axis"] != 1:
                warn_unsupported_attr(
                    "axis", "DequantizeLinear", opset, onnx_attrs["axis"]
                )
                return None
            del onnx_attrs["axis"]

    if opset >= 21:
        if "block_size" in onnx_attrs:
            if onnx_attrs["block_size"] != 0:
                warn_unsupported_attr(
                    "block_size", "DequantizeLinear", opset, onnx_attrs["block_size"]
                )
                return None
            del onnx_attrs["block_size"]

    if opset >= 23:
        if "output_dtype" in onnx_attrs:
            if onnx_attrs["output_dtype"] != 0:
                warn_unsupported_attr(
                    "output_dtype",
                    "DequantizeLinear",
                    opset,
                    onnx_attrs["output_dtype"],
                )
                return None
            del onnx_attrs["output_dtype"]

    if len(onnx_attrs) > 0:
        Log.warn(
            f"Warning: unsupported attribute(s): {onnx_attrs.keys()} for operator 'DequantizeLinear' with opset {opset}.\nThis node will be filled by a GenericOperator."
        )
        return None

    # get all the onnx initializers
    quantif_inputs = []
    for idx, inp in enumerate(input_nodes[1:]):
        prod_node = inp[0]
        if prod_node is None:
            Log.warning(
                f"Input {idx-1} is not available at import time for node Dequantizelinear, This node will be filled by a GenericOperator."
            )
            return None
        quantif_inputs.append(prod_node.get_operator().get_output(0))

    # check if zero point is in the initializers, if yes, get value
    zero_point_value = quantif_inputs[1][0] if len(quantif_inputs) == 2 else 0

    # output dtype of dequantize operator is determined by the scaling factor dtype
    cast_output_dtype = quantif_inputs[0].dtype

    scale_array = quantif_inputs[0]
    scale_value = scale_array[0]
    if not all([s == scale_value for s in scale_array]):
        Log.warn(
            f"Aidge currently only supports layerwise scaling and not channelwise for DequantizeLinear node. This node will be filled by a GenericOperator."
        )
        return None

    dequantizer_node = aidge_core.Dequantizer(
        scale_value,
        name=node_name,
        zero_point=zero_point_value,
        to_type=cast_output_dtype,
        internal_type=cast_output_dtype,
    )

    Log.info(
        f"Loaded node [\033[1m\033[3m{node_name}\033[0m] of type [\033[1m\033[3m{onnx_node.op_type}\033[0m]"
    )
    return dequantizer_node
