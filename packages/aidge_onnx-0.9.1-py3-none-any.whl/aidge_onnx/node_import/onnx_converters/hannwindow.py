"""
Copyright (c) 2023 CEA-List

This program and the accompanying materials are made available under the
terms of the Eclipse Public License 2.0 which is available at
http://www.eclipse.org/legal/epl-2.0.

SPDX-License-Identifier: EPL-2.0
"""

import onnx
from onnx import NodeProto

import aidge_core
from aidge_core import Log
from aidge_onnx.dtype_converter import onnx_to_aidge
from aidge_onnx.node_import import auto_register_import


@auto_register_import("hannwindow")
def import_sigmoid(
    onnx_node: NodeProto,
    input_nodes: list[tuple[aidge_core.Node, int]],
    opset: int,
    inputs_tensor_info: list[onnx.ValueInfoProto | None],
) -> aidge_core.Node:
    """
    :param onnx_node: ONNX node to convert
    :type onnx_node: onnx.NodeProto
    :param input_nodes: List of Aidge nodes which constitute the input of the current node
    :type input_nodes: list[aidge_core.Node]
    :param opset: Indicate opset version of the ONNX model, default=None
    :type opset: int, optional
    """
    node_name = onnx_node.name if onnx_node.name else onnx_node.output[0]
    onnx_attrs = {attr.name: attr for attr in onnx_node.attribute}
    hannwindow_attrs: dict = {
        "output_datatype": aidge_core.dtype.float32,
        "periodic": True,
    }

    if "output_datatype" in onnx_attrs:
        # Convert ONNX data type to Aidge data type
        try:
            hannwindow_attrs["output_datatype"] = onnx_to_aidge(
                onnx_attrs["output_datatype"]
            )
        except ValueError as e:
            Log.warn(f"Warning: {e} for HannWindow operation in node {node_name}")
            return None

    if "periodic" in onnx_attrs:
        hannwindow_attrs["periodic"] = onnx_attrs["periodic"].i
        del onnx_attrs["periodic"]

    if len(onnx_attrs) > 0:
        Log.warn(
            f"Warning: unsupported attribute(s): {onnx_attrs.keys()} for operator 'HannWindow' with opset {opset}.\nThis node will be filled by a GenericOperator."
        )
        return None

    my_node = aidge_core.HannWindow(name=node_name, **hannwindow_attrs)
    Log.info(
        f"Loaded node [\033[1m\033[3m{node_name}\033[0m] of type [\033[1m\033[3m{onnx_node.op_type}\033[0m]"
    )
    return my_node
