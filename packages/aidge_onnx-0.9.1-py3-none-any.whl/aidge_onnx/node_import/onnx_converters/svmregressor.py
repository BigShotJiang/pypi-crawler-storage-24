"""
ONNX converter for SVMRegressor (ai.onnx.ml domain).
"""

import onnx
from onnx import NodeProto

import aidge_core
from aidge_onnx.node_import import auto_register_import


@auto_register_import("svmregressor")
def import_svmregressor(
    onnx_node: NodeProto, input_nodes: list[tuple[aidge_core.Node, int]], opset: int
) -> aidge_core.Node:
    """Convert ONNX SVMRegressor node to AIDGE SVMRegressor_Op.

    :param onnx_node: ONNX node to convert
    :type onnx_node: onnx.NodeProto
    :param input_nodes: List of pairs of Aidge Nodes which constitute the input
        of the current node and their associated output index
    :type input_nodes: list[aidge_core.Node, int]
    :param opset: Indicate opset version of the ONNX model
    :type opset: int
    """
    node_name = onnx_node.name if onnx_node.name else onnx_node.output[0]

    # Extract attributes using ONNX helper
    onnx_attrs = {
        attr.name: onnx.helper.get_attribute_value(attr) for attr in onnx_node.attribute
    }

    # Extract required attributes with defaults
    coefficients = list(onnx_attrs.get("coefficients", []))
    support_vectors = list(onnx_attrs.get("support_vectors", []))
    kernel_params = list(onnx_attrs.get("kernel_params", [0.0, 0.0, 3.0]))
    kernel_type = onnx_attrs.get("kernel_type", b"RBF")
    rho = list(onnx_attrs.get("rho", [0.0]))
    n_supports = int(onnx_attrs.get("n_supports", 1))

    # Decode bytes to string if needed
    if isinstance(kernel_type, bytes):
        kernel_type = kernel_type.decode("utf-8")

    # Create native AIDGE node
    aidge_node = aidge_core.SVMRegressor(
        coefficients=coefficients,
        support_vectors=support_vectors,
        kernel_params=kernel_params,
        kernel_type=kernel_type,
        rho=rho,
        n_supports=n_supports,
        name=node_name,
    )

    return aidge_node
