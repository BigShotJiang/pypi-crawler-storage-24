"""
Copyright (c) 2023 CEA-List

This program and the accompanying materials are made available under the
terms of the Eclipse Public License 2.0 which is available at
http://www.eclipse.org/legal/epl-2.0.

SPDX-License-Identifier: EPL-2.0
"""

from onnx import TensorProto, helper

import aidge_core
from aidge_onnx.node_export import auto_register_export


@auto_register_export("Div")
def export_div(
    aidge_node: aidge_core.Node,
    node_inputs_name: list[str],
    node_outputs_name: list[str],
    initializer_list: list[TensorProto],
    opset: int | None = None,
    **kwargs
) -> list[helper.NodeProto]:

    aidge_operator = aidge_node.get_operator()
    onnx_node = helper.make_node(
        name=aidge_node.name(),
        op_type="Div",
        inputs=node_inputs_name,
        outputs=node_outputs_name,
    )

    if aidge_operator.attr:
        onnx_node.attribute.append(
            helper.make_attribute("axis", aidge_operator.attr.get_attr("axis"))
        )
        onnx_node.attribute.append(
            helper.make_attribute(
                "broadcast", aidge_operator.attr.get_attr("broadcast")
            )
        )

    return [onnx_node]
