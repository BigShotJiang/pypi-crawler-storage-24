"""
Copyright (c) 2023 CEA-List

This program and the accompanying materials are made available under the
terms of the Eclipse Public License 2.0 which is available at
http://www.eclipse.org/legal/epl-2.0.

SPDX-License-Identifier: EPL-2.0
"""

from onnx import TensorProto, helper

import aidge_core
from aidge_onnx.node_export import auto_register_export


@auto_register_export("MaxPooling1D", "MaxPooling2D", "MaxPooling3D")
def export_maxpooling(
    aidge_node: aidge_core.Node,
    node_inputs_name: list[str],
    node_outputs_name: list[str],
    initializer_list: list[TensorProto],
    opset: int | None = None,
    **kwargs
) -> list[helper.NodeProto]:
    aidge_operator = aidge_node.get_operator()
    onnx_node = helper.make_node(
        name=aidge_node.name(),
        op_type="MaxPool",
        inputs=node_inputs_name,
        outputs=node_outputs_name,
    )

    onnx_node.attribute.append(
        helper.make_attribute(
            "kernel_shape", aidge_operator.attr.get_attr("kernel_dims")
        )
    )
    onnx_node.attribute.append(
        helper.make_attribute("strides", aidge_operator.attr.get_attr("stride_dims"))
    )

    if opset >= 8:
        onnx_node.attribute.append(
            helper.make_attribute(
                "storage_order", aidge_operator.attr.get_attr("storage_order")
            )
        )

    if opset >= 10:
        onnx_node.attribute.append(
            helper.make_attribute(
                "ceil_mode", aidge_operator.attr.get_attr("ceil_mode")
            )
        )
        onnx_node.attribute.append(
            helper.make_attribute(
                "dilations", aidge_operator.attr.get_attr("dilations")
            )
        )
    return [onnx_node]
