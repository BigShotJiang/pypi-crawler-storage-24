"""
Copyright (c) 2023 CEA-List

This program and the accompanying materials are made available under the
terms of the Eclipse Public License 2.0 which is available at
http://www.eclipse.org/legal/epl-2.0.

SPDX-License-Identifier: EPL-2.0
"""

from onnx import TensorProto, helper

import aidge_core
from aidge_onnx.node_export import auto_register_export


@auto_register_export("ReduceSum")
def export_reducesum(
    aidge_node: aidge_core.Node,
    node_inputs_name: list[str],
    node_outputs_name: list[str],
    initializer_list: list[TensorProto],
    opset: int | None = None,
    **kwargs,
) -> list[helper.NodeProto]:
    onnx_nodes = []
    aidge_operator = aidge_node.get_operator()

    # Since Axes is optional, its `node_inputs_name` can be empty which causes problems in the graph
    if len(node_inputs_name) == 2:
        if len(node_inputs_name[1]) == 0:
            node_inputs_name[1] = node_inputs_name[0] + "_axes"

    if opset > 12:
        if aidge_operator.attr.axes and aidge_node.get_operator().get_input(1) is None:
            aidge_core.Log.debug(
                f"Creating constant node for axes attribute in ReduceSum node {aidge_node.name()}"
            )
            # No producer input for indices, create a constant node
            axes_node = helper.make_node(
                name=f"{node_inputs_name[1]}_constant",
                op_type="Constant",
                inputs=[],
                outputs=[node_inputs_name[1]],
            )
            axes_node.attribute.append(
                helper.make_attribute(
                    "value",
                    helper.make_tensor(
                        f"{node_inputs_name[1]}_tensor",
                        TensorProto.INT64,
                        [len(aidge_operator.attr.axes)],
                        aidge_operator.attr.axes,
                    ),
                )
            )
            onnx_nodes.append(axes_node)

    onnx_node = helper.make_node(
        name=aidge_node.name(),
        op_type="ReduceSum",
        inputs=node_inputs_name,
        outputs=node_outputs_name,
    )

    if opset < 13:
        onnx_node.attribute.append(
            helper.make_attribute("axes", aidge_operator.attr.get_attr("axes"))
        )

    onnx_node.attribute.append(
        helper.make_attribute("keepdims", aidge_operator.attr.get_attr("keep_dims"))
    )

    if opset > 12:
        onnx_node.attribute.append(
            helper.make_attribute(
                "noop_with_empty_axes",
                aidge_operator.attr.get_attr("noop_with_empty_axes"),
            )
        )
    return [onnx_node]
