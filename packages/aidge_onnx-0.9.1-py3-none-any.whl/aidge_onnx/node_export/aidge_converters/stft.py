"""
Copyright (c) 2023 CEA-List

This program and the accompanying materials are made available under the
terms of the Eclipse Public License 2.0 which is available at
http://www.eclipse.org/legal/epl-2.0.

SPDX-License-Identifier: EPL-2.0
"""

from onnx import TensorProto, helper

import aidge_core
from aidge_onnx.node_export import auto_register_export


@auto_register_export("STFT", "STFT_ONNX")
def export_stft(
    aidge_node: aidge_core.Node,
    node_inputs_name: list[str],
    node_outputs_name: list[str],
    initializer_list: list[TensorProto],
    opset: int | None = None,
    **kwargs,
) -> list[helper.NodeProto]:
    aidge_operator = aidge_node.get_operator()
    onnx_node = helper.make_node(
        name=aidge_node.name(),
        op_type="STFT",
        inputs=node_inputs_name,
        outputs=node_outputs_name,
    )

    if not aidge_operator.is_atomic():
        micro_graph = aidge_operator.get_micro_graph()

        for node in micro_graph.get_nodes():
            if node.type() == "STFT":
                aidge_operator = node.get_operator()

    onnx_node.attribute.append(
        helper.make_attribute("onesided", aidge_operator.attr.onesided)
    )
    return [onnx_node]
