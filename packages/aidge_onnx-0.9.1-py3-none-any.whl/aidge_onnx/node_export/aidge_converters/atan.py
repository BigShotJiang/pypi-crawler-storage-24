"""
Copyright (c) 2023 CEA-List

This program and the accompanying materials are made available under the
terms of the Eclipse Public License 2.0 which is available at
http://www.eclipse.org/legal/epl-2.0.

SPDX-License-Identifier: EPL-2.0
"""

from onnx import helper

import aidge_core
from aidge_onnx.node_export import auto_register_export


@auto_register_export("Atan")
def export_atan(
    aidge_node: aidge_core.Node,
    node_inputs_name: list[str],
    node_outputs_name: list[str],
    opset: int | None = None,
    **kwargs
) -> list[helper.NodeProto]:

    onnx_node = helper.make_node(
        name=aidge_node.name(),
        op_type="Atan",
        inputs=node_inputs_name,
        outputs=node_outputs_name,
    )
    return [onnx_node]
