# riskbypass

Python SDK for the [RiskByPass](https://riskbypass.com) task API.

## Install

```bash
pip install riskbypass
```

## Quick Start

```python
from riskbypass import RiskByPassClient

client = RiskByPassClient("your-api-key")

# Check balance
print(client.check_balance())

# Run a task
result = client.run_task({
    "task_type": "kasada",
    "proxy": "http://user:pass@host:port",
    "target_url": "https://example.com/",
    "protected_api_domain": "example.com",
    "kasada_js_domain": "example.com",
})
print(result)

# Tls requests
response = client.tls_get(url="xxx", headers={"xx":"xxx"})
print(response.text)
```

## API

### `RiskByPassClient(token, base_url="https://riskbypass.com")`

| Method | Description |
|---|---|
| `run_task(payload, timeout=180)` | Submit a task and wait for the result |
| `check_balance()` | Get current account balance |
| `get_topup_address()` | Get TRC-20 USDT top-up wallet address |
| `tls_get(xxx)/tls_post(xxx)` | Tls Requests |