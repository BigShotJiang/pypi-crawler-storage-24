# -*- coding: utf-8 -*-
"""RiskByPass API Client"""

import time
import requests
import base64
import json
from json import dumps as json_dumps
from urllib.parse import urlencode

class RiskByPassResponse:
    def __init__(self, response_dict):
        # 将字典转换为响应对象
        self.body = base64.b64decode(response_dict.get('body_base64').encode())
        self.cookies = response_dict.get('cookies', {})
        self.elapsed = response_dict.get('elapsed', 0)
        self.error = response_dict.get('error', None)
        self.headers = response_dict.get('headers', {})
        self.ok = response_dict.get('ok', False)
        self.reason = response_dict.get('reason', '')
        self.status_code = response_dict.get('status_code', 0)
        self.text = response_dict.get('text', '')
        self.url = response_dict.get('url', '')
    
    def json(self):
        return json.loads(self.body)

class RiskByPassClient:
    """Client for the RiskByPass task API.

    Args:
        token: Your API key.
        base_url: API base URL (default: https://riskbypass.com).
    """

    def __init__(self, token: str, base_url: str = "https://riskbypass.com"):
        self._token = token
        self._base_url = base_url.rstrip("/")

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _headers(self):
        return {
            "Content-Type": "application/json",
            "x-api-key": self._token,
        }

    def _submit_task(self, payload: dict) -> dict:
        url = f"{self._base_url}/task/submit"
        return requests.post(url, headers=self._headers(), json=payload, verify=False).json()

    def _get_task_result(self, task_id: str) -> dict:
        url = f"{self._base_url}/task/result/{task_id}"
        return requests.get(url, headers=self._headers(), verify=False).json()

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def run_task(self, payload: dict, timeout: int = 180) -> dict:
        """Submit a task and poll until completion.

        Args:
            payload: Task parameters (must include ``task_type``).
            timeout: Max seconds to wait before raising an error.

        Returns:
            The task result dict on success.

        Raises:
            Exception: On submission failure, timeout, or task failure.
        """
        try:
            result = self._submit_task(payload)
        except Exception as e:
            raise Exception(f"Failed to submit task: {e}")

        if not result.get("ok"):
            raise Exception(f"Failed to submit task: {result}")

        task_id = result.get("task_id")
        if not task_id:
            raise Exception(f"No task_id in response: {result}")

        start_time = time.time()
        while True:
            if time.time() - start_time > timeout:
                raise Exception(f"Task timed out after {timeout} seconds")
            time.sleep(1)
            try:
                res = self._get_task_result(task_id)
            except Exception:
                continue

            status = res.get("status")
            if status == "SUCCESS":
                return res.get("result")
            elif status in ("RUNNING", "QUEUED"):
                continue
            elif status == "FAILED":
                raise Exception(res.get("error"))
            elif status == "NOT_FOUND":
                raise Exception(f"Task expired or not exists: {task_id}")
            else:
                raise Exception(f"Unknown task status: {status}")

    def check_balance(self) -> float:
        """Return the current account balance."""
        url = f"{self._base_url}/api/user/balance"
        try:
            r = requests.post(url, json={"token": self._token}, timeout=5, verify=False)
            data = r.json()
            if data.get("ok"):
                return data.get("balance")
            raise Exception(data.get("error"))
        except Exception as e:
            raise Exception(f"Failed to check balance: {e}")

    def get_topup_address(self) -> str:
        """Return the TRC-20 USDT top-up address."""
        url = f"{self._base_url}/api/usdt/wallet"
        try:
            r = requests.post(url, json={"token": self._token}, timeout=5, verify=False)
            data = r.json()
            if data.get("ok"):
                return data.get("wallet", {}).get("trc20_address")
            raise Exception(data.get("error"))
        except Exception as e:
            raise Exception(f"Failed to get topup address: {e}")

    def _tls_forward(self, url, method="GET", headers={}, json={}, data='', cookies={}, proxy=None, timeout=30, proxies={}):
        use_proxy = proxies.get('all') or proxies.get('https') or proxy
        if json:
            data = json_dumps(json, separators=(', ', ':'), ensure_ascii=False)
        if type(data) == str:
            body_base64 = base64.b64encode(data.encode()).decode()
        elif type(data) == bytes:
            body_base64 = base64.b64encode(data).decode()
        elif type(data) == dict:
            network_data = urlencode(data)
            body_base64 = base64.b64encode(network_data.encode()).decode()
        else:
            body_base64 = None
        payload = {
            "task_type": "tls_forward",
            "proxy": use_proxy,
            "url": url,
            "method": method,
            "headers": headers,
            "body_base64": body_base64,
            "cookies_dict": cookies,
            "timeout": timeout
        }
        if headers.get('user-agent'):
            payload['user_agent'] = headers.get('user-agent')
        result = self.run_task(payload)
        if not result:
            raise Exception('TLS Forward Error')
        else:
            return RiskByPassResponse(result)

    def tls_get(self, url, headers={}, json={}, data='', cookies={}, proxy=None, timeout=30, proxies={}, params={}):
        if isinstance(params, dict) and params:
            urlparams = urlencode(params)
            url += '?' + urlparams
        return self._tls_forward(url, 'GET', headers, json, data, cookies, proxy, timeout, proxies)


    def tls_post(self, url, headers={}, json={}, data='', cookies={}, proxy=None, timeout=30, proxies={}, params={}):
        if isinstance(params, dict) and params:
            urlparams = urlencode(params)
            url += '?' + urlparams
        return self._tls_forward(url, 'POST', headers, json, data, cookies, proxy, timeout, proxies)