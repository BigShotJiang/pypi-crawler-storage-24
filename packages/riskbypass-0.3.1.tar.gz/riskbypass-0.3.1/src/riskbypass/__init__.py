# -*- coding: utf-8 -*-
"""RiskByPass Python SDK - API client for riskbypass.com"""

from .client import RiskByPassClient

__version__ = "0.3.1"
__all__ = ["RiskByPassClient"]
