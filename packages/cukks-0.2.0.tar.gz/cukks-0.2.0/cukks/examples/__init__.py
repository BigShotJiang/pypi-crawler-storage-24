"""Examples for cukks."""
