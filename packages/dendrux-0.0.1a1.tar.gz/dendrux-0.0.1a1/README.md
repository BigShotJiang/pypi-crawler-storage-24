# Dendrux

The runtime for agents that act in the real world.

> Coming soon. This is an early placeholder release.
