"""Dendrux - The runtime for agents that act in the real world."""

__version__ = "0.0.1a1"
