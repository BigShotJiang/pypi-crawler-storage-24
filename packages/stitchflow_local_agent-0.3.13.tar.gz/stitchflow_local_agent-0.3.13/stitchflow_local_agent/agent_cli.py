#!/usr/bin/env python3
"""Stitchflow local agent CLI (action execution: setup, login, run, daemon, status)."""

from __future__ import annotations

import asyncio
import signal
import sys
from typing import Any

from stitchflow_local_agent.common import config
from stitchflow_local_agent.common.daemon import (
    acquire_pid_file,
    release_pid_file,
)
from stitchflow_local_agent.common.browser import BrowserManager
from stitchflow_local_agent.actions.api_client import StitchflowAPIClient
from stitchflow_local_agent.actions.dispatcher import process_pending_operations
from stitchflow_local_agent.integrations import register_all_operations

PID_FILE_PATH = config.STITCHFLOW_HOME_DIR / "agent-daemon.pid"


async def _discover_connections(api: StitchflowAPIClient) -> list[dict[str, Any]]:
    """Fetch connections from the API, let the user confirm."""
    print("\nFetching browser-managed connections for your workspace...")
    try:
        connections = await api.get_connections()
    except Exception as exc:
        print(f"  Could not fetch connections: {exc}")
        print("  You can add connections manually later in ~/.stitchflow/connections.json")
        return []

    if not connections:
        print("  No connections found for this workspace.")
        return []

    print(f"\n  Found {len(connections)} connection(s):")
    for i, conn in enumerate(connections, 1):
        print(f"    {i}. {conn.get('name', 'unnamed')} ({conn.get('integration_key', '?')})")

    print("\n  Enter the numbers of the connections to manage, separated by commas.")
    choice = input("  Selection (e.g. 1,3,5 or 'all') [all]: ").strip().lower()
    if choice and choice != "all":
        try:
            indices = [int(x.strip()) - 1 for x in choice.split(",")]
            selected = [connections[i] for i in indices if 0 <= i < len(connections)]
            if not selected:
                print("  No valid selections. Using all connections.")
            else:
                connections = selected
        except (ValueError, IndexError):
            print("  Invalid input. Using all connections.")

    config.save_connections(connections)
    print(f"  Saved {len(connections)} connection(s) to {config.CONNECTIONS_FILE}")
    return connections


async def run_all_tasks() -> None:
    if not config.WORKSPACE_ID:
        print("ERROR: STITCHFLOW_WORKSPACE_ID not set. Run 'stitchflow-agent setup' first.")
        sys.exit(1)

    config.ensure_dirs()
    register_all_operations()

    connection_metadata = config.get_connection_metadata()
    api = StitchflowAPIClient(config.API_URL, config.API_KEY, config.WORKSPACE_ID)
    try:
        await process_pending_operations(api, connection_metadata)
    finally:
        await api.aclose()


async def run_daemon() -> None:
    if not config.WORKSPACE_ID:
        print("ERROR: STITCHFLOW_WORKSPACE_ID not set. Run 'stitchflow-agent setup' first.")
        sys.exit(1)

    if not acquire_pid_file(PID_FILE_PATH):
        sys.exit(1)

    config.ensure_dirs()
    register_all_operations()

    connection_metadata = config.get_connection_metadata()

    loop = asyncio.get_running_loop()
    shutdown_event = asyncio.Event()

    def _handle_sigterm() -> None:
        print("\nReceived shutdown signal, finishing current operation...")
        shutdown_event.set()

    loop.add_signal_handler(signal.SIGTERM, _handle_sigterm)
    loop.add_signal_handler(signal.SIGINT, _handle_sigterm)

    api = StitchflowAPIClient(config.API_URL, config.API_KEY, config.WORKSPACE_ID)
    print("Daemon started. Press Ctrl+C to stop.")
    sleep_seconds = config.POLL_INTERVAL_SECONDS
    cycle = 0
    try:
        while not shutdown_event.is_set():
            cycle += 1
            print(f"\n-- poll cycle {cycle} --")
            try:
                res = await process_pending_operations(api, connection_metadata)
                total = res.get("total", 0)
                completed_count = res.get("completed", 0)
                failed_count = res.get("failed", 0)
                if completed_count > 0:
                    sleep_seconds = config.POLL_INTERVAL_SECONDS
                elif failed_count > 0:
                    sleep_seconds = min(
                        max(config.POLL_INTERVAL_SECONDS, sleep_seconds * 2),
                        config.POLL_MAX_ERROR_SECONDS,
                    )
                elif total == 0:
                    sleep_seconds = min(
                        max(config.POLL_INTERVAL_SECONDS, sleep_seconds * 2),
                        config.POLL_MAX_IDLE_SECONDS,
                    )
            except Exception as exc:
                print(f"Daemon cycle error: {exc}")
                sleep_seconds = min(
                    max(config.POLL_INTERVAL_SECONDS, sleep_seconds * 2),
                    config.POLL_MAX_ERROR_SECONDS,
                )
            print(f"Sleeping {sleep_seconds}s")
            try:
                await asyncio.wait_for(shutdown_event.wait(), timeout=sleep_seconds)
            except asyncio.TimeoutError:
                pass
        print("Daemon stopped.")
    finally:
        await api.aclose()
        release_pid_file(PID_FILE_PATH)


async def _setup_login(connections: list[dict[str, Any]]) -> None:
    """Open a single browser session and walk through each integration login."""
    browser_mgr = BrowserManager()
    integrations_seen: set[str] = set()

    login_urls: list[tuple[str, str]] = []
    for conn in connections:
        raw_key = conn.get("integration_key", "")
        if not raw_key:
            continue
        integration = config.normalize_integration_key(raw_key)
        if integration in integrations_seen:
            continue
        integrations_seen.add(integration)

        url = config.INTEGRATION_LOGIN_URLS.get(integration, "")
        if not url:
            print(f"\n  Skipping {raw_key} — no browser login required.")
            continue
        login_urls.append((integration, url))

    if not login_urls:
        print("  No integrations require browser login.")
        return

    driver = browser_mgr.initialize("shared", config.BROWSER_PROFILE_DIR)
    try:
        for integration, url in login_urls:
            print(f"\nOpening {integration} login page: {url}")
            print("  Please log in to your account in the browser window.")
            driver.get(url)
            input(f"  Press Enter after you have logged in to {integration}...")
    finally:
        browser_mgr.shutdown()


async def _setup_async(api_url: str, api_key: str, workspace_id: str) -> list[dict[str, Any]]:
    api = StitchflowAPIClient(api_url, api_key, workspace_id)
    try:
        return await _discover_connections(api)
    finally:
        await api.aclose()


def setup() -> None:
    print("Running one-time setup...\n")
    api_url, api_key, workspace_id = config.configure_agent_env_interactive()
    config.ensure_dirs()

    connections = asyncio.run(_setup_async(api_url, api_key, workspace_id))

    if connections:
        do_login = input("\n  Log in to integrations now? (y/n) [y]: ").strip().lower()
        if do_login != "n":
            asyncio.run(_setup_login(connections))

    # Auto-install menu bar app on macOS.
    import platform
    tray_enabled = False
    if platform.system() == "Darwin":
        try:
            from stitchflow_local_agent.tray.app import install_launchagent
            tray_enabled = install_launchagent()
        except Exception as exc:
            print(f"\nNote: Could not auto-start menu bar app: {exc}")
            print("  You can start it manually with: stitchflow-tray")

    print("\nSetup complete!")
    if tray_enabled:
        print("Menu bar app installed — look for the Stitchflow icon in your menu bar.")
    print("\nNext steps:")
    print("  stitchflow-agent login    — open browser to authenticate integrations")
    print("  stitchflow-agent run      — process pending operations once")
    print("  stitchflow-agent daemon   — start the polling daemon")
    print("  stitchflow-agent status   — check configuration")


def login() -> None:
    config.ensure_dirs()
    connections = config.load_connections()
    if not connections:
        print("No connections configured. Run 'stitchflow-agent setup' first.")
        sys.exit(1)
    asyncio.run(_setup_login(connections))


def status() -> None:
    config.ensure_dirs()
    connections = config.load_connections()
    key_present = bool(config.API_KEY or config._get_api_key_from_keyring(config.WORKSPACE_ID))
    print(f"API URL:        {config.API_URL}")
    print(f"Workspace ID:   {config.WORKSPACE_ID or '(not set)'}")
    print(f"API key set:    {key_present}")
    print(f"Keyring ready:  {bool(config.keyring)}")
    print(f"Machine ID:     {config.MACHINE_ID}")
    print(f"Browser profile: {config.BROWSER_PROFILE_DIR} (exists={config.BROWSER_PROFILE_DIR.exists()})")
    print(f"Connections:    {len(connections)}")
    for conn in connections:
        cid = conn.get("connection_id", "?")
        name = conn.get("name", "unnamed")
        integration = conn.get("integration_key", "?")
        print(f"  - {name} ({integration}) id={cid}")


def main() -> None:
    try:
        sys.stdout.reconfigure(line_buffering=True)  # type: ignore[attr-defined]
        sys.stderr.reconfigure(line_buffering=True)  # type: ignore[attr-defined]
    except Exception:
        pass

    config.init_config()

    if len(sys.argv) < 2:
        print("Stitchflow Local Agent v0.3")
        print("Usage:")
        print("  stitchflow-agent setup        Interactive first-time configuration")
        print("  stitchflow-agent login         Re-authenticate browser sessions")
        print("  stitchflow-agent run           Process pending operations once and exit")
        print("  stitchflow-agent daemon        Start polling daemon")
        print("  stitchflow-agent status        Show configuration and connection status")
        return

    command = sys.argv[1]
    if command == "setup":
        setup()
    elif command == "login":
        login()
    elif command == "run":
        asyncio.run(run_all_tasks())
    elif command == "daemon":
        try:
            asyncio.run(run_daemon())
        except KeyboardInterrupt:
            print("\nDaemon stopped.")
    elif command == "status":
        status()
    else:
        print(f"Unknown command: {command}")
        sys.exit(1)


if __name__ == "__main__":
    main()
