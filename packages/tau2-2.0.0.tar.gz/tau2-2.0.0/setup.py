import setuptools
  
with open("README.md", "r", encoding="utf-8") as fh:
    long_description = fh.read()

# DO NOT EDIT THIS NUMBER!
# IT IS AUTOMATICALLY CHANGED BY python-semantic-release
__version__ = "2.0.0"

setuptools.setup(
    name="tau2",
    version=__version__,
    author="Ben Atkinson",
    author_email="benjamin.atkinson@anu.edu.au",
    description="A package for calculating magnetic relaxation rates", # noqa
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://gitlab.com/chilton-group/tau2",
    project_urls={
        "Bug Tracker": "https://gitlab.com/chilton-group/tau2/issues",
        "Documentation": "https://chilton-group.gitlab.io/tau2"
    },
    classifiers=[
        'Programming Language :: Python :: 3',
        'Programming Language :: Python :: 3.8',
        'Programming Language :: Python :: 3.9',
        'Programming Language :: Python :: 3.10',
        'Programming Language :: Python :: 3.11',
        'License :: OSI Approved :: MIT License',
        'Operating System :: OS Independent',
        'Intended Audience :: Science/Research',
        'Topic :: Scientific/Engineering :: Chemistry',
        'Topic :: Scientific/Engineering :: Physics',
    ],
    package_dir={"":"."},
    packages=setuptools.find_packages(),
    entry_points={
        'console_scripts': [
            'tau2=tau2.__main__:main',
        ],
    },
    python_requires=">=3.8",
    install_requires=[
        'numpy',
        'scipy',
        'h5py',
        'dask[distributed]', 
        'matplotlib',
        'numba',
        'python-flint',
        'mpmath',
        'argcomplete'
    ],
)
