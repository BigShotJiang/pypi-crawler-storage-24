"""
Defines parameter objects for calculations to avoid passing long argument lists.
"""
from dataclasses import dataclass

@dataclass(frozen=True)
class RamanParams:
    """
    Holds all static parameters for a Raman relaxation calculation.
    """
    # --- Core calculation options ---
    max_state: int
    raman_states: list
    num_modes: int
    temperatures: float

    # --- Lineshape & integration parameters ---
    fwhm: float
    lineshape: str
    grid_variable: str
    width: float
    hwhm: float
    window_type: str

    # --- Debugging & special flags ---
    debug_summary: bool
    debug_verbose: bool
    debug_top_n: int
    

@dataclass(frozen=True)
class OrbachParams:
    """
    Holds all static parameters for an Orbach relaxation calculation.
    """
    # --- Core Calculation Scope ---
    max_state: int
    max_modes: int
    temperatures: float

    # --- Lineshape & Integration Parameters ---
    fwhm: float
    lineshape: str
    width: float
    hwhm: float
    gamma_diagonalisation: str
    gamma_precision: int

