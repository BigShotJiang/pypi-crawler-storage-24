"""pockit — modern cloud storage CLI."""

from pockit.main import app

__all__ = ["app"]