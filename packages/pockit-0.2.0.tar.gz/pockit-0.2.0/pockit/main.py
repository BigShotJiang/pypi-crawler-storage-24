"""
pockit — a modern, interactive CLI for pockit-cloud storage.
"""

import hashlib
import json
import os
import platform
import shutil
import signal
import time
from pathlib import Path
from typing import Optional

import questionary
import typer
from gradio_client import Client, handle_file
from rich import box
from rich.console import Console
from rich.panel import Panel
from rich.progress import Progress, SpinnerColumn, TextColumn, BarColumn
from rich.table import Table
from rich.theme import Theme

# ---------------------------------------------------------------------------
# Theme & console
# ---------------------------------------------------------------------------

THEME = Theme(
    {
        "primary":  "bold cyan",
        "success":  "bold green",
        "error":    "bold red",
        "warning":  "bold yellow",
        "muted":    "dim white",
        "filename": "bold magenta",
        "header":   "bold white on #1a1a2e",
        "label":    "cyan",
    }
)

console = Console(theme=THEME, highlight=False)

LOGO = """[bold cyan]
 ██████╗  ██████╗  ██████╗██╗  ██╗██╗████████╗
 ██╔══██╗██╔═══██╗██╔════╝██║ ██╔╝██║╚══██╔══╝
 ██████╔╝██║   ██║██║     █████╔╝ ██║   ██║   
 ██╔═══╝ ██║   ██║██║     ██╔═██╗ ██║   ██║   
 ██║     ╚██████╔╝╚██████╗██║  ██╗██║   ██║   
 ╚═╝      ╚═════╝  ╚═════╝╚═╝  ╚═╝╚═╝   ╚═╝  
[/bold cyan][muted]  Cloud storage for developers[/muted]
    (Don't have an account? Sign up at [underline]https://pockit-cloud.github.io/home/[/underline])
"""

# ---------------------------------------------------------------------------
# Credential cache  (~/.pockit/session.json)
# ---------------------------------------------------------------------------

CACHE_DIR  = Path.home() / ".pockit"
CACHE_FILE = CACHE_DIR / "session.json"

QSTYLE = questionary.Style([
    ("qmark",       "fg:#00d7ff bold"),
    ("question",    "bold"),
    ("answer",      "fg:#ff79c6 bold"),
    ("pointer",     "fg:#00d7ff bold"),
    ("highlighted", "fg:#00d7ff bold"),
    ("selected",    "fg:#50fa7b"),
])


def _save_creds(user_id: str, password: str) -> None:
    CACHE_DIR.mkdir(parents=True, exist_ok=True)
    CACHE_FILE.write_text(json.dumps({"user_id": user_id, "password": password}))
    CACHE_FILE.chmod(0o600)


def _load_creds() -> Optional[dict]:
    if CACHE_FILE.exists():
        try:
            return json.loads(CACHE_FILE.read_text())
        except Exception:
            pass
    return None


def _clear_creds() -> None:
    if CACHE_FILE.exists():
        CACHE_FILE.unlink()


def ensure_logged_in() -> dict:
    """Return cached credentials, or interactively prompt + validate them."""
    creds = _load_creds()
    if creds:
        return creds

    console.print(LOGO)
    console.print("  [muted]Please log in to continue.[/muted]\n")

    user_id = questionary.text("👤 User ID:", style=QSTYLE).ask()
    if not user_id:
        raise typer.Exit()

    password = questionary.password("🔑 Password:", style=QSTYLE).ask()
    if not password:
        raise typer.Exit()

    user_id  = user_id.strip()
    password = password.strip()

    with _spinner("Authenticating…"):
        client = get_client()
        result = client.predict(user_id, password, api_name="/login")

    status = extract_status(result, 0)

    # Allow-list: backend returns "Found N files." on success, "Access Denied" on failure.
    SUCCESS_KEYWORDS = ("success", "welcome", "logged in", "login ok",
                        "authenticated", "found")
    if not any(kw in status.lower() for kw in SUCCESS_KEYWORDS):
        console.print(f"\n  [error]✗  {status}[/error]\n")
        raise typer.Exit(code=1)

    _save_creds(user_id, password)
    console.print(f"\n  [success]✓  Logged in as [bold]{user_id}[/bold][/success]\n")
    return {"user_id": user_id, "password": password}


# ---------------------------------------------------------------------------
# Gradio client factory
# ---------------------------------------------------------------------------

def get_client() -> Client:
    """Return a fresh Gradio client on every call."""
    try:
        return Client("pockit-cloud/cli-backend", verbose=False)
    except Exception as exc:
        console.print(f"\n  [error]✗  Could not reach the backend: {exc}[/error]\n")
        raise typer.Exit(code=1)


# ---------------------------------------------------------------------------
# Response parsers
# ---------------------------------------------------------------------------

def extract_status(result, index: int = 0) -> str:
    raw = result[index] if isinstance(result, (list, tuple)) else result
    if isinstance(raw, dict):
        for key in ("value", "choices"):
            if key in raw:
                inner = raw[key]
                if isinstance(inner, list):
                    return ", ".join(str(v) for v in inner) if inner else "(empty)"
                return str(inner)
        return str(raw)
    return str(raw) if raw is not None else "(no response)"


def extract_files(raw) -> list[str]:
    # Unwrap Gradio metadata dict e.g. {'choices': [...], '__type__': 'update'}
    if isinstance(raw, dict):
        choices = raw.get("choices", raw.get("value", []))
        raw = choices if isinstance(choices, list) else [str(choices)]
    if not isinstance(raw, list):
        return []
    # Flatten one wrapper level: [[f1, f2, ...]] → [f1, f2, ...]
    if len(raw) == 1 and isinstance(raw[0], list) and len(raw[0]) > 2:
        raw = raw[0]
    seen: set = set()
    result: list[str] = []
    for item in raw:
        # Gradio [value, label] pair → take value at index 0
        if isinstance(item, (list, tuple)) and len(item) >= 1:
            s = str(item[0]).strip()
        elif isinstance(item, dict):
            s = str(item.get("value", item.get("label", ""))).strip()
        else:
            s = str(item).strip()
        if s and s not in seen:
            seen.add(s)
            result.append(s)
    return result


# ---------------------------------------------------------------------------
# UI helpers
# ---------------------------------------------------------------------------

def _spinner(label: str) -> Progress:
    return Progress(
        SpinnerColumn(spinner_name="dots", style="primary"),
        TextColumn(f"[muted]{label}[/muted]"),
        transient=True,
        console=console,
    )


def _render_file_table(files: list[str], title: str = "Your Files") -> None:
    table = Table(
        box=box.ROUNDED,
        border_style="cyan",
        header_style="bold cyan",
        title=f"[bold white]{title}[/bold white]",
        title_justify="left",
        show_lines=False,
        padding=(0, 1),
    )
    table.add_column("#",        style="muted",    width=4, justify="right")
    table.add_column("Filename", style="filename", min_width=30)
    for i, name in enumerate(files, 1):
        table.add_row(str(i), name)
    console.print()
    console.print(table)
    console.print()


# ---------------------------------------------------------------------------
# Typer app
# ---------------------------------------------------------------------------

app = typer.Typer(
    name="pockit",
    help="☁  pockit-cloud — your files, anywhere.",
    add_completion=False,
    rich_markup_mode="rich",
    pretty_exceptions_enable=False,
)


# ---------------------------------------------------------------------------
# Commands
# ---------------------------------------------------------------------------

@app.command()
def login():
    """🔑 Log in to pockit-cloud (saves session locally)."""
    _clear_creds()          # force re-auth even if already cached
    ensure_logged_in()


@app.command()
def logout():
    """🚪 Clear your saved session."""
    _clear_creds()
    console.print("\n  [success]✓  Logged out.[/success]\n")


@app.command()
def ls():
    """📂 List all files in your cloud storage."""
    creds  = ensure_logged_in()
    client = get_client()

    with _spinner("Fetching file list…"):
        result = client.predict(creds["user_id"], creds["password"], api_name="/list_files")

    status = extract_status(result, 0)
    files  = extract_files(result[1])

    if "invalid" in status.lower():
        console.print(f"\n  [error]✗  {status}[/error]\n")
        _clear_creds()
        raise typer.Exit(code=1)

    if not files:
        console.print(Panel(
            "[muted]Your cloud storage is empty.\nUpload something with [bold]pockit upload[/bold].[/muted]",
            title="[header] ☁  Your Files [/header]",
            border_style="cyan",
            padding=(1, 2),
        ))
        return

    _render_file_table(files, title=f"☁  Your Files  ({len(files)} item{'s' if len(files) != 1 else ''})")


@app.command()
def download():
    """📥 Interactively select and download a file."""
    creds  = ensure_logged_in()
    client = get_client()

    # 1. Fetch file list
    with _spinner("Fetching file list…"):
        response = client.predict(creds["user_id"], creds["password"], api_name="/list_files")

    files = extract_files(response[1])

    if not files:
        console.print("\n  [error]✗  No files found in your account.[/error]\n")
        return

    # 2. Interactive autocomplete picker
    console.print()
    selected_file = questionary.autocomplete(
        "🔍 Select file to download:",
        choices=files,
        style=QSTYLE,
    ).ask()

    if not selected_file:
        return

    # 3. Ask where to save
    default_dest = str(Path.cwd() / selected_file)
    dest_str = questionary.text(
        "💾 Save as:",
        default=default_dest,
        style=QSTYLE,
    ).ask()

    if not dest_str:
        return

    destination = Path(dest_str.strip())

    # 4. Download
    console.print(f"\n  [muted]Requesting[/muted] [filename]{selected_file}[/filename][muted]…[/muted]")

    with _spinner(f"Downloading {selected_file}…"):
        result = client.predict(
            creds["user_id"],
            creds["password"],
            selected_file,
            api_name="/download_file",
        )

    # /download_file now returns a filepath (temp file on the Gradio server)
    tmp_path = result[0] if isinstance(result, (list, tuple)) else result
    tmp_path = str(tmp_path).strip() if tmp_path else ""

    # 5. Validate the returned path
    if not tmp_path:
        console.print(f"\n  [error]✗  Server did not return a file.[/error]\n")
        return

    tmp = Path(tmp_path)
    if not tmp.exists():
        console.print(f"\n  [error]✗  Downloaded temp file not found: {tmp_path!r}[/error]\n")
        return

    file_size = tmp.stat().st_size

    if file_size == 0:
        console.print(
            f"\n  [error]✗  Download aborted — server returned an empty file.\n"
            f"     Check your credentials or that [filename]{selected_file}[/filename] exists.[/error]\n"
        )
        return

    # 6. Copy temp file to destination
    destination.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(tmp_path, destination)

    console.print(Panel(
        f"[label]File:[/label]     [filename]{selected_file}[/filename]\n"
        f"[label]Saved to:[/label] [bold white]{destination}[/bold white]\n"
        f"[label]Size:[/label]     {file_size / 1024:.1f} KB",
        title="[header] ⬇  Download Complete [/header]",
        border_style="green",
        padding=(1, 2),
    ))


@app.command()
def upload():
    """⬆  Interactively select and upload a local file."""
    creds = ensure_logged_in()

    # 1. File path with tab-completion
    console.print()
    filepath_str = questionary.path(
        "📁 Select file to upload:",
        style=QSTYLE,
    ).ask()

    if not filepath_str:
        return

    filepath = Path(filepath_str.strip())
    if not filepath.is_file():
        console.print(f"\n  [error]✗  File not found: {filepath}[/error]\n")
        return

    # 2. Optional custom cloud name
    custom_name = questionary.text(
        "✏️  Custom cloud name (leave blank to keep original):",
        default="",
        style=QSTYLE,
    ).ask()

    if custom_name is None:
        return

    custom_name  = custom_name.strip()
    display_name = custom_name or filepath.name
    file_size_kb = filepath.stat().st_size / 1024

    # 3. Upload with progress bar
    with Progress(
        SpinnerColumn(spinner_name="dots", style="primary"),
        TextColumn(f"[muted]Uploading[/muted] [filename]{display_name}[/filename]…"),
        BarColumn(bar_width=28, style="cyan", complete_style="green"),
        transient=True,
        console=console,
    ) as progress:
        progress.add_task("upload", total=None)
        client = get_client()
        result = client.predict(
            creds["user_id"],
            creds["password"],
            handle_file(str(filepath)),
            custom_name,
            api_name="/upload_file",
        )

    status = extract_status(result, 0)

    console.print(Panel(
        f"[label]Local:[/label]   [bold white]{filepath}[/bold white]\n"
        f"[label]Name:[/label]    [filename]{display_name}[/filename]\n"
        f"[label]Size:[/label]    {file_size_kb:.1f} KB\n"
        f"[label]Status:[/label]  {status}",
        title="[header] ⬆  Upload Complete [/header]",
        border_style="green",
        padding=(1, 2),
    ))


@app.command()
def chpasswd():
    """🔒 Change your account password."""
    creds = ensure_logged_in()

    console.print()
    new_password = questionary.password("🔑 New password:", style=QSTYLE).ask()
    if not new_password:
        return

    confirm = questionary.password("🔑 Confirm new password:", style=QSTYLE).ask()
    if not confirm:
        return

    if new_password.strip() != confirm.strip():
        console.print("\n  [error]✗  Passwords do not match.[/error]\n")
        return

    new_password = new_password.strip()

    with _spinner("Updating password…"):
        client = get_client()
        result = client.predict(
            creds["user_id"],
            creds["password"],
            new_password,
            api_name="/change_password",
        )

    status = extract_status(result, 0)
    ok     = "invalid" not in status.lower() and "error" not in status.lower()

    console.print(Panel(
        f"[label]User:[/label]    {creds['user_id']}\n[label]Status:[/label]  {status}",
        title=f"[header] {'✓' if ok else '✗'}  Password Change [/header]",
        border_style="green" if ok else "red",
        padding=(1, 2),
    ))

    if ok:
        _save_creds(creds["user_id"], new_password)


@app.command()
def delete():
    """🗑  Interactively select and delete a file."""
    creds  = ensure_logged_in()
    client = get_client()

    # 1. Fetch file list
    with _spinner("Fetching file list…"):
        response = client.predict(creds["user_id"], creds["password"], api_name="/list_files")

    files = extract_files(response[1])

    if not files:
        console.print("\n  [error]✗  No files found in your account.[/error]\n")
        return

    # 2. Select file
    console.print()
    selected_file = questionary.select(
        "🗑  Select file to delete:",
        choices=files,
        style=QSTYLE,
    ).ask()

    if not selected_file:
        return

    # 3. Confirm — shown in red so it feels serious
    console.print()
    confirmed = questionary.confirm(
        f"⚠  Permanently delete '{selected_file}'? This cannot be undone.",
        default=False,
        style=questionary.Style([
            ("qmark",    "fg:#ff5555 bold"),
            ("question", "bold"),
            ("answer",   "fg:#ff5555 bold"),
        ]),
    ).ask()

    if not confirmed:
        console.print("\n  [muted]Cancelled.[/muted]\n")
        return

    # 4. Delete
    with _spinner(f"Deleting {selected_file}…"):
        result = client.predict(
            creds["user_id"],
            creds["password"],
            selected_file,
            api_name="/delete_file",
        )

    status = extract_status(result, 0)
    ok     = any(w in status.lower() for w in ("delet", "success", "removed"))

    console.print(Panel(
        f"[label]File:[/label]    [filename]{selected_file}[/filename]\n"
        f"[label]Status:[/label]  {status}",
        title=f"[header] {'🗑  Deleted' if ok else '✗  Delete Failed'} [/header]",
        border_style="green" if ok else "red",
        padding=(1, 2),
    ))


# ---------------------------------------------------------------------------
# Magic Sync helpers
# ---------------------------------------------------------------------------

SYNC_INTERVAL = 10  # seconds between cloud polls


def _get_sync_folder() -> Path:
    """Return the platform-appropriate Magic Sync folder, creating it if needed."""
    system = platform.system()
    if system == "Darwin":
        folder = Path.home() / "Desktop" / "Pockit-magicSync"
    elif system == "Windows":
        folder = Path.home() / "Desktop" / "Pockit-magicSync"
    else:
        # Linux: respect XDG_DESKTOP_DIR, fall back to ~/Desktop, then ~/Pockit-magicSync
        xdg = os.environ.get("XDG_DESKTOP_DIR", "")
        if xdg and Path(xdg).is_dir():
            folder = Path(xdg) / "Pockit-magicSync"
        elif (Path.home() / "Desktop").is_dir():
            folder = Path.home() / "Desktop" / "Pockit-magicSync"
        else:
            folder = Path.home() / "Pockit-magicSync"
    folder.mkdir(parents=True, exist_ok=True)
    return folder


def _file_hash(path: Path) -> str:
    """MD5 hash of a local file's contents."""
    h = hashlib.md5()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(65536), b""):
            h.update(chunk)
    return h.hexdigest()


def _local_snapshot(folder: Path) -> dict:
    """Return {filename: md5_hash} for every file directly inside folder."""
    snap = {}
    for p in folder.iterdir():
        if p.is_file() and not p.name.startswith(".pockit_tmp_"):
            try:
                snap[p.name] = _file_hash(p)
            except OSError:
                pass
    return snap


def _cloud_list_sync(client: Client, creds: dict) -> list:
    """Return list of filenames currently in the cloud (sync version)."""
    try:
        result = client.predict(creds["user_id"], creds["password"], api_name="/list_files")
        return extract_files(result[1])
    except Exception:
        return []


def _cloud_download_sync(client: Client, creds: dict, filename: str, dest: Path) -> bool:
    """Download a single cloud file to dest. Returns True on success."""
    try:
        result = client.predict(
            creds["user_id"], creds["password"], filename,
            api_name="/download_file",
        )
        tmp_path = result[0] if isinstance(result, (list, tuple)) else result
        tmp_path = str(tmp_path).strip() if tmp_path else ""
        if not tmp_path or not Path(tmp_path).exists():
            return False
        shutil.copy2(tmp_path, dest)
        return True
    except Exception:
        return False


def _cloud_upload_sync(client: Client, creds: dict, filepath: Path) -> bool:
    """Upload a local file to the cloud. Returns True on success."""
    try:
        result = client.predict(
            creds["user_id"], creds["password"],
            handle_file(str(filepath)),
            filepath.name,
            api_name="/upload_file",
        )
        status = extract_status(result, 0)
        return "error" not in status.lower() and "invalid" not in status.lower()
    except Exception:
        return False


def _cloud_delete_sync(client: Client, creds: dict, filename: str) -> bool:
    """Delete a file from the cloud. Returns True on success."""
    try:
        result = client.predict(
            creds["user_id"], creds["password"], filename,
            api_name="/delete_file",
        )
        status = extract_status(result, 0)
        return any(w in status.lower() for w in ("delet", "success", "removed"))
    except Exception:
        return False


def _sync_log(icon: str, style: str, msg: str) -> None:
    ts = time.strftime("%H:%M:%S")
    console.print(f"  [muted]{ts}[/muted]  {icon}  [{style}]{msg}[/{style}]")


# ---------------------------------------------------------------------------
# Magic Sync command
# ---------------------------------------------------------------------------

@app.command()
def magicsync():
    """✨ Magic Sync — keep a local folder in sync with your cloud 24/7."""
    creds  = ensure_logged_in()
    folder = _get_sync_folder()

    console.print(Panel(
        f"[label]Folder:[/label]  [bold white]{folder}[/bold white]\n"
        f"[label]User:[/label]    [bold white]{creds['user_id']}[/bold white]\n\n"
        f"[muted]Changes in the folder sync to the cloud, and vice versa.\n"
        f"Press [bold]Ctrl+C[/bold] to stop.[/muted]",
        title="[header] ✨ Magic Sync Active [/header]",
        border_style="cyan",
        padding=(1, 2),
    ))

    # Graceful Ctrl+C
    stop = {"flag": False}

    def _handle_sigint(sig, frame):
        stop["flag"] = True

    signal.signal(signal.SIGINT, _handle_sigint)

    # ── Initial pull: download everything from cloud into the folder ─────────
    client = get_client()
    initial_cloud = _cloud_list_sync(client, creds)
    for fname in initial_cloud:
        dest = folder / fname
        if not dest.exists():
            ok = _cloud_download_sync(client, creds, fname, dest)
            if ok:
                _sync_log("⬇", "success", f"Initial pull: {fname}")
            else:
                _sync_log("✗", "error", f"Failed initial pull: {fname}")

    # Seed state after initial pull
    prev_local = _local_snapshot(folder)
    prev_cloud = list(initial_cloud)

    _sync_log("✓", "success", "Initial sync complete — watching for changes…")
    console.print()

    # ── Main loop ────────────────────────────────────────────────────────────
    while not stop["flag"]:
        # Sleep in small increments so Ctrl+C is responsive
        for _ in range(SYNC_INTERVAL * 10):
            if stop["flag"]:
                break
            time.sleep(0.1)

        if stop["flag"]:
            break

        try:
            client = get_client()
        except Exception:
            _sync_log("✗", "error", "Could not reach backend, retrying…")
            continue

        curr_local     = _local_snapshot(folder)
        curr_cloud     = _cloud_list_sync(client, creds)
        curr_cloud_set = set(curr_cloud)
        prev_cloud_set = set(prev_cloud)
        prev_local_set = set(prev_local)
        curr_local_set = set(curr_local)

        # Track files uploaded this cycle to avoid re-downloading them
        uploaded_this_cycle: set = set()

        # ── LOCAL → CLOUD ──────────────────────────────────────────────────

        # New local files → upload
        for fname in curr_local_set - prev_local_set:
            ok = _cloud_upload_sync(client, creds, folder / fname)
            uploaded_this_cycle.add(fname)
            _sync_log("⬆", "success" if ok else "error",
                      f"{'Uploaded' if ok else 'Upload failed'}: {fname}")

        # Modified local files → re-upload
        for fname in curr_local_set & prev_local_set:
            if curr_local[fname] != prev_local[fname]:
                ok = _cloud_upload_sync(client, creds, folder / fname)
                uploaded_this_cycle.add(fname)
                _sync_log("⬆", "success" if ok else "error",
                          f"{'Updated cloud' if ok else 'Update failed'}: {fname}")

        # Locally deleted files → delete from cloud
        for fname in prev_local_set - curr_local_set:
            if fname in curr_cloud_set:
                ok = _cloud_delete_sync(client, creds, fname)
                _sync_log("🗑", "warning" if ok else "error",
                          f"{'Deleted from cloud' if ok else 'Cloud delete failed'}: {fname}")

        # ── CLOUD → LOCAL ──────────────────────────────────────────────────

        # New cloud files → download
        for fname in curr_cloud_set - prev_cloud_set:
            if fname not in curr_local_set:
                ok = _cloud_download_sync(client, creds, fname, folder / fname)
                _sync_log("⬇", "success" if ok else "error",
                          f"{'Downloaded' if ok else 'Download failed'}: {fname}")

        # Cloud-deleted files → delete locally
        for fname in prev_cloud_set - curr_cloud_set:
            local_path = folder / fname
            if local_path.exists() and fname not in uploaded_this_cycle:
                local_path.unlink()
                _sync_log("🗑", "warning", f"Removed locally (deleted from cloud): {fname}")

        # Files present in both cloud and local — check if cloud version changed
        for fname in curr_cloud_set & curr_local_set - uploaded_this_cycle:
            tmp_dest = folder / f".pockit_tmp_{fname}"
            ok = _cloud_download_sync(client, creds, fname, tmp_dest)
            if ok and tmp_dest.exists():
                try:
                    remote_hash = _file_hash(tmp_dest)
                    local_hash  = curr_local.get(fname, "")
                    if remote_hash != local_hash:
                        shutil.move(str(tmp_dest), str(folder / fname))
                        _sync_log("⬇", "success", f"Updated locally (cloud changed): {fname}")
                    else:
                        tmp_dest.unlink(missing_ok=True)
                except OSError:
                    tmp_dest.unlink(missing_ok=True)
            elif tmp_dest.exists():
                tmp_dest.unlink(missing_ok=True)

        # ── Update state ───────────────────────────────────────────────────
        prev_local = _local_snapshot(folder)
        prev_cloud = curr_cloud

    console.print("\n  [success]✓  Magic Sync stopped.[/success]\n")

# ---------------------------------------------------------------------------
# Entry point
# ---------------------------------------------------------------------------

if __name__ == "__main__":
    app()