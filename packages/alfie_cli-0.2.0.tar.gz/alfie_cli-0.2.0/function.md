# ALFIE Functionality

## General Capabilities
- Answer natural language questions.
- Provide concise information and summaries.

## File Management
- **List files** in a directory.
- **Read** contents of a file.
- **Write** content to a file.
- **Edit** existing files by replacing text.

## System Interaction
- Execute shell commands using PowerShell.
- Gather information about system parameters such as IP addresses.

## Multi-tool Operations

---

Created by: Edmond Musiitwa
- Execute multiple tasks in parallel for efficiency.