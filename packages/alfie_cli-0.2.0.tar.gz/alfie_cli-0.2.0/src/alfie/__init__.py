"""ALFIE_CLI — Artificial Lifeform Intelligent Entity."""

__version__ = "0.0.1"

from alfie.runner import RunResult, TaskResult, execute, run, run_agent

__all__ = ["__version__", "run", "run_agent", "execute", "RunResult", "TaskResult"]
