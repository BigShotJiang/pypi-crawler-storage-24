"""Configuration management for ALFIE_CLI."""

from __future__ import annotations

import sys
from pathlib import Path
from typing import Any

from pydantic import BaseModel, Field

if sys.version_info >= (3, 11):
    import tomllib
else:
    import tomli as tomllib


ALFIE_DIR = Path.home() / ".alfie"
CONFIG_FILE = ALFIE_DIR / "config.toml"

DEFAULT_CONFIG = """\
# ALFIE_CLI configuration
# See: https://github.com/p-typed/alfie-cli

[general]
default_model = "gpt-4o-mini"

[ai_gateway]
base_url = "https://ai-gateway.vercel.sh/v1"
api_key_env = "AI_GATEWAY_API_KEY"
max_tokens = 4096
temperature = 0.2

[safety]
confirm_destructive = true
max_panes = 6
max_session_runtime_sec = 1800
max_single_task_sec = 300
max_llm_calls_per_session = 50
max_retry_per_task = 3

[watcher]
poll_interval_sec = 3

[logging]
level = "INFO"
log_dir = "~/.alfie/logs"
"""


class GeneralConfig(BaseModel):
    default_model: str = "gpt-4o-mini"


class AIGatewayConfig(BaseModel):
    base_url: str = "https://ai-gateway.vercel.sh/v1"
    api_key_env: str = "AI_GATEWAY_API_KEY"
    max_tokens: int = 4096
    temperature: float = 0.2


class SafetySettings(BaseModel):
    confirm_destructive: bool = True
    max_panes: int = 6
    max_session_runtime_sec: int = 1800
    max_single_task_sec: int = 300
    max_llm_calls_per_session: int = 50
    max_retry_per_task: int = 3


class WatcherSettings(BaseModel):
    poll_interval_sec: float = 3.0


class LoggingSettings(BaseModel):
    level: str = "INFO"
    log_dir: str = "~/.alfie/logs"


class AlfieConfig(BaseModel):
    general: GeneralConfig = Field(default_factory=GeneralConfig)
    ai_gateway: AIGatewayConfig = Field(default_factory=AIGatewayConfig)
    safety: SafetySettings = Field(default_factory=SafetySettings)
    watcher: WatcherSettings = Field(default_factory=WatcherSettings)
    logging: LoggingSettings = Field(default_factory=LoggingSettings)
    config_path: str | None = None


def load_config() -> AlfieConfig:
    """Load config from ~/.alfie/config.toml, falling back to defaults."""
    if CONFIG_FILE.exists():
        raw = CONFIG_FILE.read_bytes()
        data = tomllib.loads(raw.decode("utf-8"))
        cfg = AlfieConfig(**data)
        cfg.config_path = str(CONFIG_FILE)
        return cfg
    return AlfieConfig()


def init_config() -> Path:
    """Create ~/.alfie/ directory and default config.toml if they don't exist."""
    ALFIE_DIR.mkdir(parents=True, exist_ok=True)
    if not CONFIG_FILE.exists():
        CONFIG_FILE.write_text(DEFAULT_CONFIG, encoding="utf-8")
    return CONFIG_FILE
