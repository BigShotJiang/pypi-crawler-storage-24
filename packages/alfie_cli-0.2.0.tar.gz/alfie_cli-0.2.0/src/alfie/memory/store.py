"""Lightweight JSON-backed conversation memory.

Stores conversation turns and session summaries in ``~/.alfie/memory/``.
Each conversation gets its own file keyed by a session ID.

Design goals:
  - Zero extra dependencies (JSON + filesystem)
  - Automatic context-window trimming (keeps last N turns)
  - Summary extraction for long conversations
  - Thread-safe file writes
"""

from __future__ import annotations

import json
import time
import uuid
from pathlib import Path
from typing import Any


class MemoryStore:
    """Manages multi-turn conversation memory on disk.

    Each conversation is persisted as a JSON file in ``~/.alfie/memory/``.
    Messages follow the OpenAI chat format: ``{"role": ..., "content": ...}``.
    """

    def __init__(
        self,
        session_id: str | None = None,
        memory_dir: Path | None = None,
        max_turns: int = 50,
    ) -> None:
        self.session_id = session_id or uuid.uuid4().hex[:12]
        self._dir = memory_dir or (Path.home() / ".alfie" / "memory")
        self._dir.mkdir(parents=True, exist_ok=True)
        self._max_turns = max_turns
        self._messages: list[dict[str, str]] = []
        self._metadata: dict[str, Any] = {
            "session_id": self.session_id,
            "created_at": time.time(),
            "updated_at": time.time(),
            "model": None,
            "turn_count": 0,
        }
        # Load existing session if present
        if self._file_path.exists():
            self._load()

    @property
    def _file_path(self) -> Path:
        return self._dir / f"{self.session_id}.json"

    @property
    def messages(self) -> list[dict[str, str]]:
        """All messages in the conversation so far."""
        return list(self._messages)

    @property
    def turn_count(self) -> int:
        """Number of user/assistant turn *pairs*."""
        return sum(1 for m in self._messages if m["role"] == "user")

    def add(self, role: str, content: str) -> None:
        """Append a message and auto-trim if over max_turns."""
        self._messages.append({"role": role, "content": content})
        self._metadata["updated_at"] = time.time()
        self._metadata["turn_count"] = self.turn_count
        self._trim()
        self._save()

    def get_context_messages(
        self, system_prompt: str | None = None
    ) -> list[dict[str, str]]:
        """Return messages ready for an LLM call (optionally prepend system prompt)."""
        msgs: list[dict[str, str]] = []
        if system_prompt:
            msgs.append({"role": "system", "content": system_prompt})
        msgs.extend(self._messages)
        return msgs

    def set_model(self, model: str) -> None:
        self._metadata["model"] = model
        self._save()

    def clear(self) -> None:
        """Wipe conversation history (keeps session file)."""
        self._messages.clear()
        self._metadata["updated_at"] = time.time()
        self._metadata["turn_count"] = 0
        self._save()

    def list_sessions(self) -> list[dict[str, Any]]:
        """Return metadata for all saved sessions, newest first."""
        sessions = []
        for f in sorted(self._dir.glob("*.json"), reverse=True):
            try:
                data = json.loads(f.read_text(encoding="utf-8"))
                sessions.append(data.get("metadata", {"session_id": f.stem}))
            except (json.JSONDecodeError, KeyError):
                continue
        return sessions

    def delete(self) -> None:
        """Remove this session's file from disk."""
        if self._file_path.exists():
            self._file_path.unlink()
        self._messages.clear()

    # ── Internal ──────────────────────────────────────────────────────────

    def _trim(self) -> None:
        """Keep only the last ``max_turns`` user/assistant pairs.

        Trims from the front, ensuring we always start with a user message.
        """
        user_count = sum(1 for m in self._messages if m["role"] == "user")
        if user_count <= self._max_turns:
            return

        # Keep last max_turns*2 messages, then trim any leading assistant orphan
        keep = self._max_turns * 2
        self._messages = self._messages[-keep:]
        # Ensure we start with a user message
        while self._messages and self._messages[0]["role"] != "user":
            self._messages.pop(0)

    def _save(self) -> None:
        data = {
            "metadata": self._metadata,
            "messages": self._messages,
        }
        self._file_path.write_text(
            json.dumps(data, indent=2, ensure_ascii=False), encoding="utf-8"
        )

    def _load(self) -> None:
        try:
            data = json.loads(self._file_path.read_text(encoding="utf-8"))
            self._metadata = data.get("metadata", self._metadata)
            self._messages = data.get("messages", [])
        except (json.JSONDecodeError, KeyError):
            pass  # start fresh
