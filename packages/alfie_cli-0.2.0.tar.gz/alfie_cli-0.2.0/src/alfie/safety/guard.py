"""Safety guard — command blocklist and confirmation logic."""

from __future__ import annotations

import re

from alfie.models import SafetyConfig


# Commands that always require user confirmation before execution
SOFT_BLOCK_PATTERNS = [
    r"\bgit\s+push\b",
    r"\bgit\s+push\s+.*--force\b",
    r"\brm\b",
    r"\bdel\b",
    r"\bsudo\b",
    r"\bpip\s+install\b",
    r"\bnpm\s+install\b",
    r"\bapt\s+install\b",
    r"\bapt-get\s+install\b",
]


class SafetyGuard:
    """Validates commands against safety rules before execution."""

    def __init__(self, config: SafetyConfig | None = None) -> None:
        self.config = config or SafetyConfig()
        self._blocked = [re.compile(p, re.IGNORECASE) for p in self.config.blocked_patterns]
        self._soft = [re.compile(p, re.IGNORECASE) for p in SOFT_BLOCK_PATTERNS]

    def is_blocked(self, cmd: str) -> str | None:
        """Check if a command is hard-blocked. Returns the matching pattern or None."""
        for pattern in self._blocked:
            if pattern.search(cmd):
                return pattern.pattern
        return None

    def needs_confirmation(self, cmd: str) -> bool:
        """Check if a command requires user confirmation."""
        if not self.config.confirm_destructive:
            return False
        return any(pattern.search(cmd) for pattern in self._soft)

    def validate(self, cmd: str) -> tuple[bool, str]:
        """Validate a command. Returns (allowed, reason).

        Returns:
            (True, "ok")             — safe to execute
            (True, "confirm: ...")   — allowed but needs user confirmation
            (False, "blocked: ...")  — hard blocked, never execute
        """
        blocked_by = self.is_blocked(cmd)
        if blocked_by:
            return False, f"blocked: matches safety pattern '{blocked_by}'"

        if self.needs_confirmation(cmd):
            return True, f"confirm: command matches destructive pattern"

        return True, "ok"
