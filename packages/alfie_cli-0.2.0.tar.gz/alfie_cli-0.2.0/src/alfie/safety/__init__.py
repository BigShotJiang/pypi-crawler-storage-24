"""ALFIE safety module."""
