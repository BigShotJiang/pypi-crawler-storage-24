"""Agent loop — reactive tool-calling execution engine.

Implements the standard LLM agent pattern:

    User message
         ↓
    ┌──► LLM decides (text response  OR  tool calls)
    │         │                            │
    │    [final answer]           [execute tools]
    │                                      │
    └──────────────────── results ◄────────┘

The loop continues until the LLM produces a text response (no tool calls)
or a safety limit is reached.
"""

from __future__ import annotations

import json
import logging
from dataclasses import dataclass, field
from typing import Any, Callable

from alfie.safety.guard import SafetyGuard
from alfie.tools import registry
from alfie.tools.base import ToolResult

logger = logging.getLogger("alfie.agent")


@dataclass
class AgentResponse:
    """Final response from an agent loop run."""

    content: str
    tool_calls_made: list[dict[str, Any]] = field(default_factory=list)
    total_llm_calls: int = 0
    stopped_reason: str = "complete"  # complete | max_iterations | error


def run_agent_loop(
    *,
    client: Any,
    model: str,
    messages: list[dict[str, Any]],
    safety: SafetyGuard | None = None,
    max_iterations: int = 25,
    temperature: float = 0.7,
    max_tokens: int = 4096,
    on_tool_start: Callable[[str, dict], None] | None = None,
    on_tool_end: Callable[[str, ToolResult], None] | None = None,
    on_thinking: Callable[[], None] | None = None,
) -> AgentResponse:
    """Run the agent loop synchronously.

    Args:
        client: OpenAI-compatible client.
        model: Model name.
        messages: Conversation history (will be mutated — tool results appended).
        safety: Optional SafetyGuard for shell command validation.
        max_iterations: Hard cap on LLM calls to prevent runaway.
        temperature: LLM temperature.
        max_tokens: Max tokens per LLM response.
        on_tool_start: Callback(tool_name, args) fired before each tool call.
        on_tool_end: Callback(tool_name, result) fired after each tool call.
        on_thinking: Callback() fired when waiting for LLM response.

    Returns:
        AgentResponse with the final text and metadata.
    """
    tools_schema = registry.to_openai_tools()
    all_tool_calls: list[dict[str, Any]] = []
    llm_calls = 0

    for iteration in range(max_iterations):
        if on_thinking:
            on_thinking()

        # ── Call LLM ──────────────────────────────────────────────────────
        try:
            kwargs: dict[str, Any] = {
                "model": model,
                "messages": messages,
                "temperature": temperature,
                "max_tokens": max_tokens,
            }
            if tools_schema:
                kwargs["tools"] = tools_schema
                kwargs["tool_choice"] = "auto"

            response = client.chat.completions.create(**kwargs)
            llm_calls += 1
        except Exception as exc:
            logger.exception("LLM call failed")
            return AgentResponse(
                content=f"LLM error: {exc}",
                tool_calls_made=all_tool_calls,
                total_llm_calls=llm_calls,
                stopped_reason="error",
            )

        choice = response.choices[0]
        message = choice.message

        # ── No tool calls → final answer ──────────────────────────────────
        if not message.tool_calls:
            content = message.content or ""
            messages.append({"role": "assistant", "content": content})
            return AgentResponse(
                content=content,
                tool_calls_made=all_tool_calls,
                total_llm_calls=llm_calls,
                stopped_reason="complete",
            )

        # ── Tool calls requested ──────────────────────────────────────────
        # Append the assistant message with tool_calls (OpenAI format)
        messages.append(message.model_dump(exclude_none=True))

        for tool_call in message.tool_calls:
            fn = tool_call.function
            tool_name = fn.name
            try:
                arguments = json.loads(fn.arguments)
            except json.JSONDecodeError:
                arguments = {}

            if on_tool_start:
                on_tool_start(tool_name, arguments)

            # Safety check for shell commands
            if tool_name == "run_shell" and safety:
                cmd = arguments.get("command", "")
                allowed, reason = safety.validate(cmd)
                if not allowed:
                    result = ToolResult(
                        tool_name=tool_name,
                        output=f"BLOCKED by safety guard: {reason}",
                        success=False,
                    )
                    logger.warning("Blocked command: %s — %s", cmd, reason)
                else:
                    result = registry.call(tool_name, arguments)
            else:
                result = registry.call(tool_name, arguments)

            if on_tool_end:
                on_tool_end(tool_name, result)

            all_tool_calls.append({
                "tool_name": tool_name,
                "arguments": arguments,
                "output": result.output[:2000],  # truncate for context window
                "success": result.success,
            })

            # Append tool result message (OpenAI format)
            messages.append({
                "role": "tool",
                "tool_call_id": tool_call.id,
                "content": result.output[:4000],
            })

    # Hit max iterations
    return AgentResponse(
        content="I reached the maximum number of steps. Here's what I've done so far.",
        tool_calls_made=all_tool_calls,
        total_llm_calls=llm_calls,
        stopped_reason="max_iterations",
    )
