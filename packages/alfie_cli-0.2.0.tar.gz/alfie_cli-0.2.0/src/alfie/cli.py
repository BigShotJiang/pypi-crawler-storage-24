"""ALFIE_CLI — command-line interface."""

from __future__ import annotations

import asyncio
from pathlib import Path
from typing import Optional

from dotenv import load_dotenv
import typer

# Load .env from project root (walk up from cli.py)
_env_file = Path(__file__).resolve().parents[2] / ".env"
if _env_file.exists():
    load_dotenv(_env_file)
else:
    load_dotenv()  # search cwd and parents
from rich.console import Console
from rich.live import Live
from rich.panel import Panel
from rich.table import Table

from alfie import __version__
from alfie.config import load_config

app = typer.Typer(
    name="alfie",
    help="ALFIE — Artificial Lifeform Intelligent Entity",
    no_args_is_help=True,
    rich_markup_mode="rich",
)
console = Console()


# ── Global options ────────────────────────────────────────────────────────────

ModelOption = typer.Option("gpt-4o-mini", "--model", "-m", help="LLM model to use")


# ── Commands ──────────────────────────────────────────────────────────────────


@app.command()
def version():
    """Show ALFIE_CLI version."""
    console.print(f"[bold cyan]ALFIE_CLI[/bold cyan] v{__version__}")


@app.command()
def doctor():
    """Check system requirements and configuration."""
    import shutil

    cfg = load_config()

    table = Table(title="ALFIE System Check", show_lines=True)
    table.add_column("Check", style="bold")
    table.add_column("Status")
    table.add_column("Details")

    # Python version
    import sys
    py_ver = f"{sys.version_info.major}.{sys.version_info.minor}.{sys.version_info.micro}"
    py_ok = sys.version_info >= (3, 11)
    table.add_row(
        "Python",
        "[green]✓[/green]" if py_ok else "[red]✗[/red]",
        f"v{py_ver}" + ("" if py_ok else " (need 3.11+)"),
    )

    # tmux
    tmux_path = shutil.which("tmux")
    if tmux_path:
        import subprocess
        result = subprocess.run(["tmux", "-V"], capture_output=True, text=True)
        tmux_ver = result.stdout.strip()
        table.add_row("tmux", "[green]✓[/green]", tmux_ver)
    else:
        table.add_row("tmux", "[red]✗[/red]", "Not found — install tmux")

    # Config
    table.add_row(
        "Config",
        "[green]✓[/green]" if cfg else "[yellow]~[/yellow]",
        str(cfg.config_path) if cfg.config_path else "Using defaults",
    )

    console.print(table)


@app.command()
def config():
    """Show current configuration."""
    cfg = load_config()
    console.print_json(cfg.model_dump_json(indent=2))


@app.command()
def run(
    intent: str = typer.Argument(..., help="What you want ALFIE to do"),
    model: str = ModelOption,
    plan_file: Optional[str] = typer.Option(None, "--plan", "-p", help="Execute a JSON plan file"),
    dry_run: bool = typer.Option(False, "--dry-run", help="Validate plan without executing"),
):
    """Execute a task — natural language or from a plan file."""
    if plan_file:
        _run_from_plan(plan_file, intent, model, dry_run)
    else:
        _run_from_intent(intent, model, dry_run)


def _run_from_intent(intent: str, model: str, dry_run: bool) -> None:
    """Use the LLM planner to generate a plan from natural language, then execute."""
    from alfie.planner import Planner, PlannerError

    console.print(
        Panel(
            f"[bold]{intent}[/bold]\n\nModel: [cyan]{model}[/cyan]",
            title="[bold green]ALFIE — Planning[/bold green]",
            border_style="green",
        )
    )

    with console.status("[bold cyan]Thinking...[/bold cyan]", spinner="dots"):
        try:
            planner = Planner(model=model)
            plan = planner.generate(intent)
        except RuntimeError as exc:
            # API key not set
            console.print(f"\n[red]✗ {exc}[/red]")
            console.print(
                "[dim]Set your API key: "
                "[cyan]$env:AI_GATEWAY_API_KEY = 'your-key'[/cyan] (PowerShell) or "
                "[cyan]export AI_GATEWAY_API_KEY=your-key[/cyan] (bash)[/dim]"
            )
            raise typer.Exit(1)
        except PlannerError as exc:
            console.print(f"\n[red]✗ Planner failed: {exc}[/red]")
            raise typer.Exit(1)

    console.print(f"\n[green]✓ Plan generated: {len(plan.tasks)} tasks[/green]\n")

    # Save the generated plan for reproducibility
    import json
    import time
    from pathlib import Path

    plans_dir = Path.home() / ".alfie" / "plans"
    plans_dir.mkdir(parents=True, exist_ok=True)
    plan_path = plans_dir / f"plan_{int(time.time())}.json"
    plan_path.write_text(plan.model_dump_json(indent=2), encoding="utf-8")
    console.print(f"[dim]Plan saved: {plan_path}[/dim]\n")

    # Now execute via the same plan-execution path
    _execute_plan(plan, model, dry_run)


def _run_from_plan(plan_file: str, intent: str, model: str, dry_run: bool) -> None:
    """Load a JSON plan file and execute it through the scheduler."""
    import json
    from pathlib import Path

    from alfie.models import Plan

    path = Path(plan_file)
    if not path.exists():
        console.print(f"[red]Plan file not found: {plan_file}[/red]")
        raise typer.Exit(1)

    try:
        raw = json.loads(path.read_text(encoding="utf-8"))
        plan = Plan(**raw)
    except (json.JSONDecodeError, Exception) as exc:
        console.print(f"[red]Failed to parse plan file: {exc}[/red]")
        raise typer.Exit(1)

    if intent:
        plan.intent = intent
    if model != "gpt-4o-mini":
        plan.model = model

    _execute_plan(plan, model, dry_run)


def _execute_plan(plan: "Plan", model: str, dry_run: bool) -> None:
    """Show plan summary, optionally dry-run, then execute via scheduler."""
    import subprocess as sp
    import time

    from alfie.events.bus import EventBus
    from alfie.models import Plan, Session, SessionStatus, TaskStatus
    from alfie.safety.guard import SafetyGuard
    from alfie.scheduler.dag import PanePool, TaskScheduler, topological_sort

    # Show plan summary
    layers = topological_sort(plan.tasks)
    table = Table(title="Execution Plan", show_lines=True)
    table.add_column("Layer", style="bold", justify="center")
    table.add_column("Task ID", style="cyan")
    table.add_column("Command")
    table.add_column("Depends On")
    table.add_column("On Failure")

    for i, layer in enumerate(layers):
        for task_id in layer:
            task = next(t for t in plan.tasks if t.id == task_id)
            deps = ", ".join(task.depends_on) if task.depends_on else "—"
            table.add_row(str(i), task.id, task.cmd[:60], deps, task.on_failure.value)

    console.print(Panel(
        f"[bold]{plan.intent or 'No intent specified'}[/bold]\n"
        f"Tasks: [bold]{len(plan.tasks)}[/bold] | "
        f"Layers: [bold]{len(layers)}[/bold] | "
        f"Model: [cyan]{plan.model}[/cyan] | "
        f"Max panes: [bold]{plan.safety.max_panes}[/bold]",
        title="[bold green]ALFIE — Plan Loaded[/bold green]",
        border_style="green",
    ))
    console.print(table)

    if dry_run:
        guard = SafetyGuard(plan.safety)
        all_ok = True
        for task in plan.tasks:
            allowed, reason = guard.validate(task.cmd)
            if not allowed:
                console.print(f"  [red]✗ {task.id}:[/red] {reason}")
                all_ok = False
            else:
                status = "[yellow]⚠ confirm[/yellow]" if guard.needs_confirmation(task.cmd) else "[green]✓ safe[/green]"
                console.print(f"  {status} {task.id}: {task.cmd[:60]}")
        if all_ok:
            console.print("\n[green]✓ Plan is valid and safe to execute.[/green]")
        else:
            console.print("\n[red]✗ Plan has blocked commands. Fix before executing.[/red]")
        return

    # Build scheduler components
    bus = EventBus()
    session = Session(id=plan.session_id, intent=plan.intent, plan=plan, model=plan.model)
    pool = PanePool(max_panes=plan.safety.max_panes)
    guard = SafetyGuard(plan.safety)

    class _LocalPane:
        """Lightweight pane substitute for local subprocess execution."""

        def __init__(self, pane_id: str) -> None:
            self.pane_id = pane_id

        def send(self, cmd: str, press_enter: bool = True) -> None:
            pass

        def capture(self, lines: int = 50) -> str:
            return ""

        def send_ctrl_c(self) -> None:
            pass

        def kill(self) -> None:
            pass

        def is_alive(self) -> bool:
            return True

    for i in range(plan.safety.max_panes):
        pool.add_pane(_LocalPane(f"%local_{i}"))

    scheduler = TaskScheduler(
        plan=plan,
        session=session,
        pane_pool=pool,
        event_bus=bus,
        safety=guard,
    )

    console.print("\n[bold cyan]Executing plan...[/bold cyan]\n")

    scheduler.queue_ready_tasks()
    max_iters = len(plan.tasks) * 10

    for _ in range(max_iters):
        if scheduler.is_complete:
            break

        assignments = scheduler.assign_tasks()
        for task_id, pane_id in assignments:
            task = scheduler.task_map[task_id]
            console.print(f"  [cyan]▶ {task_id}:[/cyan] {task.cmd}")

            try:
                import sys
                if sys.platform == "win32":
                    run_args = ["powershell", "-NoProfile", "-Command", task.cmd]
                    result = sp.run(
                        run_args,
                        capture_output=True,
                        text=True,
                        timeout=task.timeout_sec,
                    )
                else:
                    result = sp.run(
                        task.cmd,
                        shell=True,
                        capture_output=True,
                        text=True,
                        timeout=task.timeout_sec,
                    )
                output = result.stdout + result.stderr
                if result.returncode == 0:
                    console.print(f"  [green]✓ {task_id}[/green] (exit 0)")
                    scheduler.on_task_completed(pane_id, task_id, output)
                else:
                    console.print(f"  [red]✗ {task_id}[/red] (exit {result.returncode})")
                    scheduler.on_task_failed(pane_id, task_id, output, "none")
            except sp.TimeoutExpired:
                console.print(f"  [yellow]⏱ {task_id}[/yellow] timed out")
                scheduler.on_task_stuck(pane_id, task_id, float(task.timeout_sec))

        running = sum(1 for t in scheduler.task_map.values() if t.status == TaskStatus.RUNNING)
        if not assignments and running == 0 and not scheduler.is_complete:
            scheduler._abort_remaining("No runnable tasks")
            break

    session.finished_at = time.time()
    all_ok = all(t.status == TaskStatus.COMPLETED for t in scheduler.task_map.values())
    session.status = SessionStatus.COMPLETED if all_ok else SessionStatus.FAILED

    console.print()
    summary_table = Table(title="Execution Summary", show_lines=True)
    summary_table.add_column("Task ID", style="bold")
    summary_table.add_column("Status")
    summary_table.add_column("Duration")
    summary_table.add_column("Output (tail)")

    for task in plan.tasks:
        t = scheduler.task_map[task.id]
        color = {"completed": "green", "failed": "red", "skipped": "yellow", "timeout": "yellow"}.get(t.status.value, "white")
        dur = f"{t.duration:.1f}s" if t.duration else "—"
        tail = t.output.strip().splitlines()[-1][:60] if t.output.strip() else "—"
        summary_table.add_row(t.id, f"[{color}]{t.status.value.upper()}[/{color}]", dur, tail)

    console.print(summary_table)

    if all_ok:
        console.print(f"\n[bold green]✓ All {len(plan.tasks)} tasks completed successfully.[/bold green]")
    else:
        failed = sum(1 for t in scheduler.task_map.values() if t.status in (TaskStatus.FAILED, TaskStatus.TIMEOUT))
        skipped = sum(1 for t in scheduler.task_map.values() if t.status == TaskStatus.SKIPPED)
        console.print(f"\n[bold red]✗ Session failed: {failed} failed, {skipped} skipped.[/bold red]")
    raise typer.Exit(0 if all_ok else 1)


@app.command()
def status():
    """Check the status of the current running session."""
    console.print("[yellow]No active session.[/yellow]")


@app.command()
def kill(
    force: bool = typer.Option(False, "--force", "-f", help="Immediately kill all panes"),
):
    """Emergency stop — kill all running tasks."""
    if force:
        console.print("[red]Force killing all panes...[/red]")
    else:
        console.print("[yellow]Gracefully stopping session...[/yellow]")
    console.print("[yellow]No active session to kill.[/yellow]")


@app.command()
def history():
    """Show past sessions."""
    console.print("[yellow]No session history yet (Phase 5).[/yellow]")


@app.command()
def logs(
    session_id: Optional[str] = typer.Argument(None, help="Session ID to show logs for"),
):
    """Tail audit log."""
    console.print("[yellow]No logs yet (Phase 5).[/yellow]")


@app.command()
def watch(
    session_name: str = typer.Argument(..., help="Name of the tmux session to watch"),
    poll: float = typer.Option(3.0, "--poll", "-p", help="Poll interval in seconds"),
    timeout: float = typer.Option(300.0, "--timeout", "-t", help="Default task timeout in seconds"),
):
    """Watch a running tmux session — monitor panes and report state changes."""
    from alfie.events.bus import EventBus
    from alfie.tmux.session import TmuxSession
    from alfie.watcher.engine import WatcherEngine

    # Verify session exists
    if not TmuxSession.exists(session_name):
        console.print(f"[red]tmux session '{session_name}' not found.[/red]")
        console.print("Create one with: [cyan]tmux new-session -d -s {name}[/cyan]")
        raise typer.Exit(1)

    session = TmuxSession.attach_existing(session_name)
    panes = session.list_panes()

    if not panes:
        console.print("[red]No panes found in session.[/red]")
        raise typer.Exit(1)

    console.print(Panel(
        f"Session: [bold cyan]{session_name}[/bold cyan]\n"
        f"Panes: [bold]{len(panes)}[/bold]\n"
        f"Poll interval: [bold]{poll}s[/bold]\n"
        f"Timeout: [bold]{timeout}s[/bold]",
        title="[bold green]ALFIE Watcher[/bold green]",
        border_style="green",
    ))

    bus = EventBus()
    watcher = WatcherEngine(
        event_bus=bus,
        poll_interval=poll,
        default_timeout=timeout,
    )

    # Track all panes with auto-generated task IDs
    for i, pane in enumerate(panes):
        watcher.track(pane, task_id=f"pane_{i}")

    # Run with live display
    async def _run_watch() -> None:
        try:
            with Live(console=console, refresh_per_second=1) as live:
                watcher._running = True
                while watcher.is_running:
                    watcher.poll_once()

                    # Build status table
                    table = Table(title="Pane Status", show_lines=True)
                    table.add_column("Pane", style="bold")
                    table.add_column("Task")
                    table.add_column("Status")
                    table.add_column("Last Active")
                    table.add_column("Output (tail)")

                    for pid, state in watcher.tracked_panes.items():
                        status_color = {
                            "idle": "green",
                            "running": "cyan",
                            "done": "bold green",
                            "error": "bold red",
                            "stuck": "bold yellow",
                            "interactive": "magenta",
                            "unknown": "dim",
                        }.get(state.status.value, "white")

                        tail = state.last_output.strip().splitlines()[-1][:60] if state.last_output.strip() else "—"

                        table.add_row(
                            pid,
                            state.task_id or "—",
                            f"[{status_color}]{state.status.value.upper()}[/{status_color}]",
                            f"{state.heartbeat_count} beats",
                            tail,
                        )

                    live.update(table)
                    await asyncio.sleep(poll)
        except KeyboardInterrupt:
            watcher.stop()
            console.print("\n[yellow]Watcher stopped.[/yellow]")

    try:
        asyncio.run(_run_watch())
    except KeyboardInterrupt:
        console.print("\n[yellow]Watcher stopped.[/yellow]")


# ── Interactive Chat ──────────────────────────────────────────────────────────


@app.command()
def chat(
    model: str = ModelOption,
    session_id: Optional[str] = typer.Option(None, "--session", "-s", help="Resume a session by ID"),
    max_turns: int = typer.Option(50, "--max-turns", help="Max conversation turns to remember"),
):
    """Interactive multi-turn conversation with ALFIE."""
    from alfie.agent import run_agent_loop
    from alfie.memory.prompts import CHAT_SYSTEM_PROMPT
    from alfie.memory.store import MemoryStore
    from alfie.models import SafetyConfig
    from alfie.planner.client import build_client
    from alfie.safety.guard import SafetyGuard

    # Ensure tools are registered
    import alfie.tools  # noqa: F401

    mem = MemoryStore(session_id=session_id, max_turns=max_turns)
    mem.set_model(model)
    safety = SafetyGuard(SafetyConfig())

    console.print(Panel(
        f"[bold]ALFIE — Interactive Chat[/bold]\n"
        f"Model: [cyan]{model}[/cyan] | "
        f"Session: [dim]{mem.session_id}[/dim] | "
        f"History: {mem.turn_count} turns\n\n"
        f"[dim]ALFIE now uses real tool-calling — it can run commands, "
        f"read/write files, and explore your system.\n"
        f"Commands:  /clear — clear conversation history\n"
        f"           /info  — show session info\n"
        f"           /exit  — quit (or Ctrl+C)[/dim]",
        title="[bold green]ALFIE Chat[/bold green]",
        border_style="green",
    ))

    client, resolved_model = build_client(model)

    while True:
        try:
            console.print()
            user_input = console.input("[bold cyan]You:[/bold cyan] ").strip()
        except (KeyboardInterrupt, EOFError):
            console.print("\n[dim]Goodbye![/dim]")
            break

        if not user_input:
            continue

        # Slash commands
        if user_input.startswith("/"):
            cmd = user_input.lower().split()[0]

            if cmd in ("/exit", "/quit", "/q"):
                console.print("[dim]Goodbye![/dim]")
                break

            elif cmd == "/clear":
                mem.clear()
                console.print("[green]✓ Conversation cleared.[/green]")
                continue

            elif cmd == "/info":
                from alfie.tools import registry
                console.print(Panel(
                    f"Session: [cyan]{mem.session_id}[/cyan]\n"
                    f"Model: [cyan]{model}[/cyan]\n"
                    f"Turns: {mem.turn_count}\n"
                    f"Messages: {len(mem.messages)}\n"
                    f"Tools: [cyan]{', '.join(registry.names)}[/cyan]",
                    title="Session Info",
                    border_style="blue",
                ))
                continue

            else:
                console.print(f"[yellow]Unknown command: {cmd}[/yellow]")
                continue

        # Add user message to memory
        mem.add("user", user_input)

        # Build messages for LLM (system prompt + conversation history)
        messages = mem.get_context_messages(system_prompt=CHAT_SYSTEM_PROMPT)

        # Run agent loop — LLM can call tools, see results, and iterate
        def _on_tool_start(name: str, args: dict) -> None:
            if name == "run_shell":
                console.print(f"  [cyan]▶ run_shell:[/cyan] {args.get('command', '')[:80]}")
            elif name == "read_file":
                console.print(f"  [cyan]▶ read_file:[/cyan] {args.get('path', '')}")
            elif name == "write_file":
                console.print(f"  [cyan]▶ write_file:[/cyan] {args.get('path', '')}")
            elif name == "edit_file":
                console.print(f"  [cyan]▶ edit_file:[/cyan] {args.get('path', '')}")
            elif name == "list_directory":
                console.print(f"  [cyan]▶ list_directory:[/cyan] {args.get('path', '.')}")
            else:
                console.print(f"  [cyan]▶ {name}[/cyan]")

        def _on_tool_end(name: str, result: "ToolResult") -> None:
            status = "[green]✓[/green]" if result.success else "[red]✗[/red]"
            # Show a brief snippet of the output
            snippet = result.output.strip().splitlines()[0][:80] if result.output.strip() else "(no output)"
            console.print(f"  {status} {snippet}")

        agent_result = run_agent_loop(
            client=client,
            model=resolved_model,
            messages=messages,
            safety=safety,
            temperature=0.7,
            max_tokens=4096,
            on_tool_start=_on_tool_start,
            on_tool_end=_on_tool_end,
            on_thinking=lambda: None,  # could show spinner per iteration
        )

        # Save assistant response to memory
        mem.add("assistant", agent_result.content)

        # Display response
        console.print(f"\n[bold green]ALFIE:[/bold green] {agent_result.content}")

        if agent_result.stopped_reason == "max_iterations":
            console.print("[yellow]⚠ Reached max tool-calling iterations.[/yellow]")
        elif agent_result.stopped_reason == "error":
            console.print("[red]⚠ Agent encountered an error.[/red]")


# ── Memory Management ────────────────────────────────────────────────────────


@app.command(name="memory")
def memory_cmd(
    action: str = typer.Argument("list", help="Action: list, show, delete, clear"),
    session_id: Optional[str] = typer.Argument(None, help="Session ID for show/delete"),
):
    """Manage conversation memory — list, show, or delete sessions."""
    from alfie.memory.store import MemoryStore

    if action == "list":
        mem = MemoryStore()
        sessions = mem.list_sessions()
        if not sessions:
            console.print("[yellow]No saved conversations.[/yellow]")
            return

        table = Table(title="Conversation History", show_lines=True)
        table.add_column("Session ID", style="cyan")
        table.add_column("Model")
        table.add_column("Turns", justify="center")
        table.add_column("Last Updated")

        for s in sessions:
            import time
            updated = time.strftime(
                "%Y-%m-%d %H:%M", time.localtime(s.get("updated_at", 0))
            )
            table.add_row(
                s.get("session_id", "?"),
                s.get("model", "?") or "—",
                str(s.get("turn_count", 0)),
                updated,
            )

        console.print(table)

    elif action == "show":
        if not session_id:
            console.print("[red]Usage: alfie memory show <session-id>[/red]")
            return
        mem = MemoryStore(session_id=session_id)
        if not mem.messages:
            console.print(f"[yellow]No messages in session {session_id}.[/yellow]")
            return
        for msg in mem.messages:
            role = msg["role"]
            color = {"user": "cyan", "assistant": "green", "system": "dim"}.get(role, "white")
            label = {"user": "You", "assistant": "ALFIE", "system": "System"}.get(role, role)
            console.print(f"[bold {color}]{label}:[/bold {color}] {msg['content']}\n")

    elif action == "delete":
        if not session_id:
            console.print("[red]Usage: alfie memory delete <session-id>[/red]")
            return
        mem = MemoryStore(session_id=session_id)
        mem.delete()
        console.print(f"[green]✓ Session {session_id} deleted.[/green]")

    elif action == "clear":
        mem = MemoryStore()
        sessions = mem.list_sessions()
        count = 0
        for s in sessions:
            sid = s.get("session_id", "")
            if sid:
                m = MemoryStore(session_id=sid)
                m.delete()
                count += 1
        console.print(f"[green]✓ Deleted {count} conversation(s).[/green]")

    else:
        console.print(f"[red]Unknown action: {action}. Use list, show, delete, or clear.[/red]")


if __name__ == "__main__":
    app()
