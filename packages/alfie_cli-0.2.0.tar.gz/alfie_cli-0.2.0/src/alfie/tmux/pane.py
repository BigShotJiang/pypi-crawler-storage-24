"""TmuxPane — represents a single tmux pane."""

from __future__ import annotations

import subprocess
import time
from dataclasses import dataclass


@dataclass
class TmuxPane:
    """Wrapper around a single tmux pane."""

    session_name: str
    pane_id: str       # e.g. "%0", "%1"
    pane_index: int    # 0-based index within the window

    @property
    def target(self) -> str:
        """tmux target string for this pane."""
        return f"{self.session_name}:0.{self.pane_index}"

    def send(self, cmd: str, press_enter: bool = True) -> None:
        """Send a command (keystrokes) to this pane."""
        args = ["tmux", "send-keys", "-t", self.target, cmd]
        if press_enter:
            args.append("Enter")
        subprocess.run(args, check=True, capture_output=True)

    def capture(self, lines: int = 50) -> str:
        """Capture the last N lines of visible output from this pane."""
        result = subprocess.run(
            ["tmux", "capture-pane", "-p", "-t", self.target, "-S", f"-{lines}"],
            capture_output=True,
            text=True,
        )
        return result.stdout.rstrip()

    def send_ctrl_c(self) -> None:
        """Send Ctrl+C to interrupt the current process."""
        subprocess.run(
            ["tmux", "send-keys", "-t", self.target, "C-c"],
            capture_output=True,
        )

    def kill(self) -> None:
        """Kill this pane."""
        subprocess.run(
            ["tmux", "kill-pane", "-t", self.target],
            capture_output=True,
        )

    def is_alive(self) -> bool:
        """Check if this pane still exists."""
        result = subprocess.run(
            ["tmux", "list-panes", "-t", self.session_name, "-F", "#{pane_id}"],
            capture_output=True,
            text=True,
        )
        return self.pane_id in result.stdout

    def wait_for_output(self, marker: str, timeout_sec: float = 30, poll_sec: float = 0.5) -> str:
        """Poll pane output until a marker string appears or timeout."""
        deadline = time.time() + timeout_sec
        while time.time() < deadline:
            output = self.capture()
            if marker in output:
                return output
            time.sleep(poll_sec)
        raise TimeoutError(
            f"Marker '{marker}' not found in pane {self.pane_id} after {timeout_sec}s"
        )
