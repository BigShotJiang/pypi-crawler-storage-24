"""TmuxSession — manages a tmux session lifecycle."""

from __future__ import annotations

import subprocess
from dataclasses import dataclass, field

from alfie.tmux.pane import TmuxPane


@dataclass
class TmuxSession:
    """Wrapper around a tmux session."""

    name: str
    _alive: bool = field(default=False, repr=False)

    # ── Lifecycle ─────────────────────────────────────────────────────────────

    @classmethod
    def create(cls, name: str, width: int = 220, height: int = 50) -> TmuxSession:
        """Create a new detached tmux session."""
        subprocess.run(
            ["tmux", "new-session", "-d", "-s", name, "-x", str(width), "-y", str(height)],
            check=True,
            capture_output=True,
        )
        session = cls(name=name, _alive=True)
        return session

    @classmethod
    def exists(cls, name: str) -> bool:
        """Check if a tmux session with the given name exists."""
        result = subprocess.run(
            ["tmux", "has-session", "-t", name],
            capture_output=True,
        )
        return result.returncode == 0

    @classmethod
    def attach_existing(cls, name: str) -> TmuxSession:
        """Attach to an already-running tmux session."""
        if not cls.exists(name):
            raise RuntimeError(f"tmux session '{name}' does not exist")
        return cls(name=name, _alive=True)

    def destroy(self) -> None:
        """Kill the entire tmux session."""
        if self._alive:
            subprocess.run(
                ["tmux", "kill-session", "-t", self.name],
                capture_output=True,
            )
            self._alive = False

    # ── Pane Management ───────────────────────────────────────────────────────

    def add_pane(self, vertical: bool = False) -> TmuxPane:
        """Split the current window to create a new pane. Returns the new pane."""
        split_flag = "-v" if vertical else "-h"
        subprocess.run(
            ["tmux", "split-window", split_flag, "-t", self.name],
            check=True,
            capture_output=True,
        )
        # The new pane is the last one in the list
        panes = self.list_panes()
        return panes[-1]

    def list_panes(self) -> list[TmuxPane]:
        """List all panes in this session."""
        result = subprocess.run(
            ["tmux", "list-panes", "-t", self.name, "-F", "#{pane_id} #{pane_index}"],
            capture_output=True,
            text=True,
            check=True,
        )
        panes = []
        for line in result.stdout.strip().splitlines():
            parts = line.split()
            if len(parts) == 2:
                pane_id, pane_index = parts
                panes.append(TmuxPane(
                    session_name=self.name,
                    pane_id=pane_id,
                    pane_index=int(pane_index),
                ))
        return panes

    def get_pane(self, index: int) -> TmuxPane:
        """Get a specific pane by index."""
        panes = self.list_panes()
        for pane in panes:
            if pane.pane_index == index:
                return pane
        raise IndexError(f"Pane index {index} not found in session '{self.name}'")

    @property
    def pane_count(self) -> int:
        return len(self.list_panes())

    # ── Context Manager ───────────────────────────────────────────────────────

    def __enter__(self) -> TmuxSession:
        return self

    def __exit__(self, *exc: object) -> None:
        self.destroy()
