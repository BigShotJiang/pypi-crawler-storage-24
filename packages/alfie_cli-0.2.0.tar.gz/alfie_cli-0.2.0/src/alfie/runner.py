"""High-level API — single function call from intent to results.

Supports two execution modes:

1. **Plan mode** (default for `alfie run`):
   LLM generates a DAG plan → scheduler executes shell commands in order.
   Best for known multi-step workflows.

2. **Agent mode** (default for `alfie chat`, also available via API):
   LLM calls tools reactively in a loop, seeing results and adapting.
   Best for exploratory tasks, file operations, and interactive work.
"""

from __future__ import annotations

import subprocess as sp
import sys
import time
from dataclasses import dataclass, field

from alfie.events.bus import EventBus
from alfie.models import (
    Plan,
    SafetyConfig,
    Session,
    SessionStatus,
    TaskStatus,
)
from alfie.planner import Planner, PlannerError
from alfie.safety.guard import SafetyGuard
from alfie.scheduler.dag import PanePool, TaskScheduler, topological_sort


@dataclass
class TaskResult:
    """Result of a single executed task."""

    id: str
    cmd: str
    status: str
    exit_code: int | None
    output: str
    duration: float | None


@dataclass
class RunResult:
    """Result of a full alfie.run() execution."""

    success: bool
    intent: str
    model: str
    plan: Plan
    tasks: list[TaskResult] = field(default_factory=list)
    duration: float | None = None
    error: str | None = None

    @property
    def output(self) -> str:
        """Combined stdout/stderr from all completed tasks."""
        return "\n".join(
            t.output for t in self.tasks
            if t.status == "completed" and t.output.strip()
        )

    def __str__(self) -> str:
        status = "SUCCESS" if self.success else "FAILED"
        lines = [f"[{status}] {self.intent} ({len(self.tasks)} tasks)"]
        for t in self.tasks:
            lines.append(f"  {t.id}: {t.status.upper()} — {t.cmd[:60]}")
        return "\n".join(lines)


def run(
    intent: str,
    *,
    model: str = "gpt-4o-mini",
    dry_run: bool = False,
    timeout_sec: int = 300,
    max_panes: int = 6,
) -> RunResult:
    """Plan and execute a natural-language intent in one call.

    Args:
        intent: What you want ALFIE to do, in plain English.
        model: LLM model for planning (default: gpt-4o-mini).
        dry_run: If True, generate the plan but don't execute.
        timeout_sec: Per-task timeout in seconds.
        max_panes: Maximum parallel execution slots.

    Returns:
        RunResult with task outputs, statuses, and overall success flag.

    Example::

        import alfie
        result = alfie.run("list all .py files and count them")
        print(result.output)
        print(result.success)  # True / False
    """
    # ── Plan ──────────────────────────────────────────────────────────────
    try:
        planner = Planner(model=model)
        plan = planner.generate(intent)
    except (PlannerError, RuntimeError) as exc:
        return RunResult(
            success=False,
            intent=intent,
            model=model,
            plan=Plan(intent=intent, model=model),
            error=str(exc),
        )

    # Override per-task timeout if requested
    for task in plan.tasks:
        task.timeout_sec = timeout_sec

    if dry_run:
        return RunResult(
            success=True,
            intent=intent,
            model=model,
            plan=plan,
            tasks=[
                TaskResult(
                    id=t.id, cmd=t.cmd, status="pending",
                    exit_code=None, output="", duration=None,
                )
                for t in plan.tasks
            ],
        )

    # ── Execute ───────────────────────────────────────────────────────────
    return execute(plan, model=model, max_panes=max_panes)


def execute(
    plan: Plan,
    *,
    model: str | None = None,
    max_panes: int = 6,
) -> RunResult:
    """Execute a pre-built Plan and return results.

    Useful when you already have a Plan object (e.g. loaded from JSON).

    Args:
        plan: A Plan object with tasks.
        model: Override the model recorded in the plan.
        max_panes: Maximum parallel execution slots.

    Returns:
        RunResult with task outputs, statuses, and overall success flag.
    """
    used_model = model or plan.model
    start_time = time.time()

    bus = EventBus()
    session = Session(
        id=plan.session_id, intent=plan.intent, plan=plan, model=used_model,
    )
    guard = SafetyGuard(plan.safety)
    pool = PanePool(max_panes=max_panes)

    # Lightweight local pane stubs
    class _Pane:
        def __init__(self, pane_id: str) -> None:
            self.pane_id = pane_id
        def send(self, cmd: str, press_enter: bool = True) -> None: pass
        def capture(self, lines: int = 50) -> str: return ""
        def send_ctrl_c(self) -> None: pass
        def kill(self) -> None: pass
        def is_alive(self) -> bool: return True

    for i in range(max_panes):
        pool.add_pane(_Pane(f"%local_{i}"))

    scheduler = TaskScheduler(
        plan=plan, session=session, pane_pool=pool,
        event_bus=bus, safety=guard,
    )
    scheduler.queue_ready_tasks()

    max_iters = len(plan.tasks) * 10
    for _ in range(max_iters):
        if scheduler.is_complete:
            break

        assignments = scheduler.assign_tasks()
        for task_id, pane_id in assignments:
            task = scheduler.task_map[task_id]
            try:
                if sys.platform == "win32":
                    result = sp.run(
                        ["powershell", "-NoProfile", "-Command", task.cmd],
                        capture_output=True, text=True, timeout=task.timeout_sec,
                    )
                else:
                    result = sp.run(
                        task.cmd, shell=True,
                        capture_output=True, text=True, timeout=task.timeout_sec,
                    )
                output = result.stdout + result.stderr
                if result.returncode == 0:
                    scheduler.on_task_completed(pane_id, task_id, output)
                else:
                    scheduler.on_task_failed(pane_id, task_id, output, "none")
            except sp.TimeoutExpired:
                scheduler.on_task_stuck(pane_id, task_id, float(task.timeout_sec))

        running = sum(
            1 for t in scheduler.task_map.values() if t.status == TaskStatus.RUNNING
        )
        if not assignments and running == 0 and not scheduler.is_complete:
            scheduler._abort_remaining("No runnable tasks")
            break

    elapsed = time.time() - start_time
    all_ok = all(t.status == TaskStatus.COMPLETED for t in scheduler.task_map.values())

    task_results = []
    for task in plan.tasks:
        t = scheduler.task_map[task.id]
        task_results.append(TaskResult(
            id=t.id,
            cmd=t.cmd,
            status=t.status.value,
            exit_code=t.exit_code,
            output=t.output,
            duration=t.duration,
        ))

    return RunResult(
        success=all_ok,
        intent=plan.intent,
        model=used_model,
        plan=plan,
        tasks=task_results,
        duration=elapsed,
    )


def run_agent(
    intent: str,
    *,
    model: str = "gpt-4o-mini",
    max_iterations: int = 25,
) -> "AgentResponse":
    """Execute an intent using the reactive agent loop (tool-calling).

    Unlike run(), this keeps the LLM in the loop — it can call tools,
    see results, and decide what to do next.

    Args:
        intent: What you want ALFIE to do, in plain English.
        model: LLM model to use.
        max_iterations: Max LLM calls before stopping.

    Returns:
        AgentResponse with final text and tool call history.
    """
    from alfie.agent import AgentResponse, run_agent_loop
    from alfie.memory.prompts import CHAT_SYSTEM_PROMPT
    from alfie.planner.client import build_client

    # Ensure tools are registered
    import alfie.tools  # noqa: F401

    client, resolved_model = build_client(model)
    safety = SafetyGuard(SafetyConfig())

    messages: list[dict] = [
        {"role": "system", "content": CHAT_SYSTEM_PROMPT},
        {"role": "user", "content": intent},
    ]

    return run_agent_loop(
        client=client,
        model=resolved_model,
        messages=messages,
        safety=safety,
        max_iterations=max_iterations,
    )
