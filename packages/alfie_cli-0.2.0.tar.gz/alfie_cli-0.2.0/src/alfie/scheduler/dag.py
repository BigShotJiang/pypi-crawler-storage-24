"""DAG-based task scheduler.

Owns the full task lifecycle: topological ordering, pane assignment,
state machine transitions, retry logic, and watcher integration.
"""

from __future__ import annotations

import asyncio
import logging
import time
from typing import TYPE_CHECKING, Any

from alfie.models import (
    FailureStrategy,
    Plan,
    Session,
    SessionStatus,
    Task,
    TaskResult,
    TaskStatus,
)
from alfie.safety.guard import SafetyGuard

if TYPE_CHECKING:
    from alfie.events.bus import EventBus
    from alfie.tmux.pane import TmuxPane
    from alfie.tmux.session import TmuxSession
    from alfie.watcher.engine import WatcherEngine

logger = logging.getLogger("alfie.scheduler")


# ═══════════════════════════════════════════════════════════════════════════════
# Topological sort (unchanged from Phase 0)
# ═══════════════════════════════════════════════════════════════════════════════


def topological_sort(tasks: list[Task]) -> list[list[str]]:
    """Return tasks grouped into parallel execution layers (topological order).

    Each layer is a list of task IDs that can run concurrently.
    Tasks in layer N+1 depend on tasks in layer N or earlier.
    """
    task_map = {t.id: t for t in tasks}
    in_degree: dict[str, int] = {t.id: 0 for t in tasks}
    dependents: dict[str, list[str]] = {t.id: [] for t in tasks}

    for t in tasks:
        for dep_id in t.depends_on:
            if dep_id in task_map:
                in_degree[t.id] += 1
                dependents[dep_id].append(t.id)

    layers: list[list[str]] = []
    ready = [tid for tid, deg in in_degree.items() if deg == 0]

    while ready:
        layers.append(sorted(ready))  # sorted for determinism
        next_ready = []
        for tid in ready:
            for dep_tid in dependents[tid]:
                in_degree[dep_tid] -= 1
                if in_degree[dep_tid] == 0:
                    next_ready.append(dep_tid)
        ready = next_ready

    scheduled = sum(len(layer) for layer in layers)
    if scheduled != len(tasks):
        raise ValueError("Cycle detected in task dependencies")

    return layers


# ═══════════════════════════════════════════════════════════════════════════════
# Pane Pool — manages a fixed set of tmux panes
# ═══════════════════════════════════════════════════════════════════════════════


class PanePool:
    """Manages a pool of tmux panes with a max concurrency limit."""

    def __init__(self, max_panes: int = 6) -> None:
        self.max_panes = max_panes
        self._free: list[TmuxPane] = []
        self._busy: dict[str, TmuxPane] = {}  # task_id → pane

    @property
    def available(self) -> int:
        return len(self._free)

    @property
    def busy_count(self) -> int:
        return len(self._busy)

    @property
    def total(self) -> int:
        return len(self._free) + len(self._busy)

    def add_pane(self, pane: TmuxPane) -> None:
        """Add a pane to the free pool."""
        self._free.append(pane)

    def acquire(self, task_id: str) -> TmuxPane | None:
        """Try to get a free pane. Returns None if none available."""
        if not self._free:
            return None
        pane = self._free.pop(0)
        self._busy[task_id] = pane
        return pane

    def release(self, task_id: str) -> TmuxPane | None:
        """Return a pane to the free pool. Returns the pane or None."""
        pane = self._busy.pop(task_id, None)
        if pane:
            self._free.append(pane)
        return pane

    def get_pane(self, task_id: str) -> TmuxPane | None:
        """Get the pane assigned to a task (if any)."""
        return self._busy.get(task_id)

    def release_all(self) -> None:
        """Return all busy panes to the free pool."""
        for pane in self._busy.values():
            self._free.append(pane)
        self._busy.clear()


# ═══════════════════════════════════════════════════════════════════════════════
# Task Scheduler — the brain that drives execution
# ═══════════════════════════════════════════════════════════════════════════════


class TaskScheduler:
    """Executes a Plan by scheduling tasks across tmux panes.

    Workflow:
        scheduler = TaskScheduler(plan, session, watcher, pane_pool, event_bus)
        await scheduler.run()  # blocks until all tasks done or session killed

    The scheduler:
    1. Computes topological order
    2. Queues root tasks
    3. Assigns queued tasks to free panes
    4. Sends commands to panes
    5. Watcher reports state → scheduler transitions tasks
    6. When a task completes → queue its dependents if all deps met
    7. Repeat until all tasks are terminal
    """

    def __init__(
        self,
        plan: Plan,
        session: Session,
        watcher: WatcherEngine | None = None,
        pane_pool: PanePool | None = None,
        event_bus: EventBus | None = None,
        safety: SafetyGuard | None = None,
    ) -> None:
        self.plan = plan
        self.session = session
        self._watcher = watcher
        self._pool = pane_pool or PanePool(max_panes=plan.safety.max_panes)
        self._event_bus = event_bus
        self._safety = safety or SafetyGuard(plan.safety)

        # Indexes
        self._task_map: dict[str, Task] = {t.id: t for t in plan.tasks}
        self._dependents: dict[str, list[str]] = {t.id: [] for t in plan.tasks}
        for t in plan.tasks:
            for dep_id in t.depends_on:
                if dep_id in self._dependents:
                    self._dependents[dep_id].append(t.id)

        # Queues
        self._queue: list[str] = []  # task IDs ready to run

        # Compute layers for reference
        self._layers = topological_sort(plan.tasks)

        # Results collected
        self._results: dict[str, TaskResult] = {}

    # ── Public API ────────────────────────────────────────────────────────

    @property
    def task_map(self) -> dict[str, Task]:
        return self._task_map

    @property
    def results(self) -> dict[str, TaskResult]:
        return dict(self._results)

    @property
    def is_complete(self) -> bool:
        """True when all tasks are in a terminal state."""
        return all(t.is_terminal for t in self._task_map.values())

    @property
    def summary(self) -> dict[str, int]:
        """Count tasks by status."""
        counts: dict[str, int] = {}
        for t in self._task_map.values():
            key = t.status.value
            counts[key] = counts.get(key, 0) + 1
        return counts

    def queue_ready_tasks(self) -> list[str]:
        """Move all tasks whose dependencies are met from PENDING → QUEUED."""
        newly_queued = []
        for task in self._task_map.values():
            if task.status != TaskStatus.PENDING:
                continue
            if self._deps_satisfied(task.id):
                task.status = TaskStatus.QUEUED
                self._queue.append(task.id)
                newly_queued.append(task.id)
                self._emit("task.queued", {"task_id": task.id, "cmd": task.cmd})
        return newly_queued

    def assign_tasks(self) -> list[tuple[str, str]]:
        """Assign queued tasks to free panes. Returns list of (task_id, pane_id)."""
        assigned = []
        remaining_queue = []

        for task_id in self._queue:
            task = self._task_map[task_id]

            # Safety check
            allowed, reason = self._safety.validate(task.cmd)
            if not allowed:
                logger.warning("Task %s BLOCKED: %s", task_id, reason)
                task.status = TaskStatus.SKIPPED
                task.output = f"Blocked by safety guard: {reason}"
                self._emit("safety.blocked", {"task_id": task_id, "reason": reason, "cmd": task.cmd})
                continue

            pane = self._pool.acquire(task_id)
            if pane is None:
                remaining_queue.append(task_id)
                continue

            # Launch task
            task.status = TaskStatus.RUNNING
            task.started_at = time.time()
            task.attempt += 1
            task.pane_id = pane.pane_id

            # Register with watcher
            if self._watcher:
                self._watcher.track(
                    pane,
                    task_id=task_id,
                    timeout_sec=float(task.timeout_sec),
                    retry_cmd=task.cmd if task.retry.max_attempts > 1 else None,
                )

            assigned.append((task_id, pane.pane_id))
            self._emit("task.started", {
                "task_id": task_id,
                "pane_id": pane.pane_id,
                "cmd": task.cmd,
                "attempt": task.attempt,
            })
            logger.info("Task %s → pane %s: %s", task_id, pane.pane_id, task.cmd[:80])

        self._queue = remaining_queue
        return assigned

    def send_commands(self, assignments: list[tuple[str, str]]) -> None:
        """Send the actual commands to panes. Separate from assign for testability."""
        for task_id, pane_id in assignments:
            task = self._task_map[task_id]
            pane = self._pool.get_pane(task_id)
            if pane:
                sentinel_cmd = f"{task.cmd} && echo TASK_COMPLETE || echo TASK_FAILED"
                pane.send(sentinel_cmd)

    # ── Watcher callbacks (implements PaneObserver protocol) ──────────────

    def on_task_completed(self, pane_id: str, task_id: str, output: str) -> None:
        """Called by watcher when a pane's task finishes successfully."""
        task = self._task_map.get(task_id)
        if not task or task.is_terminal:
            return

        task.status = TaskStatus.COMPLETED
        task.finished_at = time.time()
        task.output = output[-2000:] if len(output) > 2000 else output

        self._results[task_id] = TaskResult(
            task_id=task_id,
            exit_code=0,
            output=task.output,
            duration_sec=task.duration or 0.0,
            status=TaskStatus.COMPLETED,
        )

        # Release pane
        self._pool.release(task_id)
        if self._watcher:
            self._watcher.untrack(pane_id)

        self._emit("task.completed", {
            "task_id": task_id,
            "duration": task.duration,
        })
        logger.info("Task %s completed (%.1fs)", task_id, task.duration or 0)

        # Queue newly-ready dependents
        self.queue_ready_tasks()

    def on_task_failed(self, pane_id: str, task_id: str, output: str, recovery: str) -> None:
        """Called by watcher when a pane errors out."""
        task = self._task_map.get(task_id)
        if not task or task.is_terminal:
            return

        if recovery == "retry" and task.attempt < task.retry.max_attempts:
            # Watcher already sent retry command — stay in RUNNING
            logger.info("Task %s retry attempt %d/%d", task_id, task.attempt, task.retry.max_attempts)
            return

        # Terminal failure
        task.status = TaskStatus.FAILED
        task.finished_at = time.time()
        task.output = output[-2000:] if len(output) > 2000 else output

        self._results[task_id] = TaskResult(
            task_id=task_id,
            exit_code=1,
            output=task.output,
            duration_sec=task.duration or 0.0,
            status=TaskStatus.FAILED,
        )

        self._pool.release(task_id)
        if self._watcher:
            self._watcher.untrack(pane_id)

        self._emit("task.failed", {"task_id": task_id, "output_tail": output[-500:]})
        logger.warning("Task %s FAILED", task_id)

        # Handle downstream tasks based on failure strategy
        self._handle_downstream_on_failure(task)

        # Queue any tasks that are now unblocked
        self.queue_ready_tasks()

    def on_task_stuck(self, pane_id: str, task_id: str, duration: float) -> None:
        """Called by watcher when a pane is stuck (no output for too long)."""
        task = self._task_map.get(task_id)
        if not task or task.is_terminal:
            return

        if task.attempt < task.retry.max_attempts:
            logger.info("Task %s stuck — watcher handling retry", task_id)
            return

        task.status = TaskStatus.TIMEOUT
        task.finished_at = time.time()

        self._results[task_id] = TaskResult(
            task_id=task_id,
            exit_code=-1,
            output=f"Timed out after {duration:.0f}s",
            duration_sec=task.duration or 0.0,
            status=TaskStatus.TIMEOUT,
        )

        self._pool.release(task_id)
        if self._watcher:
            self._watcher.untrack(pane_id)

        self._emit("task.timeout", {"task_id": task_id, "stuck_sec": duration})
        logger.warning("Task %s TIMEOUT after %.0fs", task_id, duration)

        self._handle_downstream_on_failure(task)
        self.queue_ready_tasks()

    def on_interactive(self, pane_id: str, task_id: str, prompt_line: str) -> None:
        """Called when a pane shows an interactive prompt."""
        self._emit("watcher.interactive", {
            "task_id": task_id,
            "pane_id": pane_id,
            "prompt": prompt_line,
        })
        logger.info("Task %s has interactive prompt: %s", task_id, prompt_line)

    # ── Async execution loop ──────────────────────────────────────────────

    async def run(self, poll_interval: float = 1.0) -> Session:
        """Main execution loop. Blocks until all tasks are done.

        1. Queue root tasks
        2. Assign to panes + send commands
        3. Poll watcher
        4. Repeat until complete
        """
        self.session.status = SessionStatus.RUNNING
        self._emit("session.started", {"session_id": self.session.id, "task_count": len(self._task_map)})

        # Initial queue
        self.queue_ready_tasks()

        while not self.is_complete:
            # Assign queued tasks to free panes
            assignments = self.assign_tasks()
            if assignments:
                self.send_commands(assignments)

            # Let watcher poll (it calls our on_task_* methods)
            if self._watcher:
                self._watcher.poll_once()

            # Check for session-level timeout
            elapsed = time.time() - self.session.started_at
            if elapsed > self.plan.safety.max_runtime_sec:
                logger.error("Session timeout after %.0fs", elapsed)
                self._abort_remaining("Session timeout")
                break

            # Check if we're stuck: nothing in queue, nothing running, but tasks remain
            running = sum(1 for t in self._task_map.values() if t.status == TaskStatus.RUNNING)
            queued = len(self._queue)
            if running == 0 and queued == 0 and not self.is_complete:
                logger.warning("Deadlock: no running/queued tasks but not complete")
                self._abort_remaining("No runnable tasks — possible dependency deadlock")
                break

            await asyncio.sleep(poll_interval)

        # Finalize
        self.session.finished_at = time.time()
        all_ok = all(t.status == TaskStatus.COMPLETED for t in self._task_map.values())
        self.session.status = SessionStatus.COMPLETED if all_ok else SessionStatus.FAILED

        self._emit("session.finished", {
            "session_id": self.session.id,
            "status": self.session.status.value,
            "summary": self.summary,
            "duration": self.session.duration,
        })
        return self.session

    def run_sync(self) -> Session:
        """Synchronous step-through for testing without asyncio.

        Runs queue → assign → poll cycles until complete or stuck.
        No sleeps — pure state machine stepping.
        """
        self.session.status = SessionStatus.RUNNING
        self.queue_ready_tasks()

        max_iterations = len(self._task_map) * 10  # safety valve
        for _ in range(max_iterations):
            if self.is_complete:
                break

            assignments = self.assign_tasks()
            if assignments:
                self.send_commands(assignments)

            if self._watcher:
                self._watcher.poll_once()

            running = sum(1 for t in self._task_map.values() if t.status == TaskStatus.RUNNING)
            if running == 0 and not self._queue and not self.is_complete:
                self._abort_remaining("Deadlock")
                break

        self.session.finished_at = time.time()
        all_ok = all(t.status == TaskStatus.COMPLETED for t in self._task_map.values())
        self.session.status = SessionStatus.COMPLETED if all_ok else SessionStatus.FAILED
        return self.session

    # ── Internal helpers ──────────────────────────────────────────────────

    def _deps_satisfied(self, task_id: str) -> bool:
        """Check if all dependencies of a task are completed."""
        task = self._task_map[task_id]
        for dep_id in task.depends_on:
            dep = self._task_map.get(dep_id)
            if dep is None or dep.status != TaskStatus.COMPLETED:
                return False
        return True

    def _handle_downstream_on_failure(self, failed_task: Task) -> None:
        """Skip or abort downstream tasks when a task fails."""
        strategy = failed_task.on_failure

        if strategy == FailureStrategy.ABORT:
            self._abort_remaining(f"Task {failed_task.id} failed (abort strategy)")
        elif strategy == FailureStrategy.SKIP:
            # Only skip direct dependents
            for dep_id in self._dependents.get(failed_task.id, []):
                dep_task = self._task_map.get(dep_id)
                if dep_task and not dep_task.is_terminal:
                    dep_task.status = TaskStatus.SKIPPED
                    dep_task.output = f"Skipped: dependency {failed_task.id} failed"
                    self._emit("task.skipped", {"task_id": dep_id, "reason": f"dep {failed_task.id} failed"})
        elif strategy == FailureStrategy.ESCALATE:
            # Mark dependents that can't possibly run as skipped
            self._skip_unreachable()

    def _abort_remaining(self, reason: str) -> None:
        """Mark all non-terminal tasks as SKIPPED."""
        for task in self._task_map.values():
            if not task.is_terminal:
                task.status = TaskStatus.SKIPPED
                task.output = f"Aborted: {reason}"
        self._queue.clear()
        logger.warning("Aborted remaining tasks: %s", reason)

    def _skip_unreachable(self) -> None:
        """Skip tasks whose dependencies can never be satisfied."""
        changed = True
        while changed:
            changed = False
            for task in self._task_map.values():
                if task.status != TaskStatus.PENDING:
                    continue
                for dep_id in task.depends_on:
                    dep = self._task_map.get(dep_id)
                    if dep and dep.status in (TaskStatus.FAILED, TaskStatus.TIMEOUT, TaskStatus.SKIPPED):
                        task.status = TaskStatus.SKIPPED
                        task.output = f"Skipped: dependency {dep_id} is {dep.status.value}"
                        self._emit("task.skipped", {"task_id": task.id, "reason": task.output})
                        changed = True
                        break

    def _emit(self, event_type: str, data: dict[str, Any]) -> None:
        if self._event_bus:
            self._event_bus.emit(event_type, data)
