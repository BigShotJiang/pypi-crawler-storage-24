"""Built-in tools — shell execution, file I/O, directory listing.

These are the foundational tools every ALFIE agent session has access to.
Each tool is registered in the module-level `registry` on import.
"""

from __future__ import annotations

import os
import subprocess as sp
import sys
from pathlib import Path
from typing import Any

from alfie.tools.base import Tool, ToolResult


# ── run_shell ─────────────────────────────────────────────────────────────────

class RunShellTool(Tool):
    name = "run_shell"
    description = (
        "Execute a shell command on the host system and return its output. "
        "Uses PowerShell on Windows and bash on Linux/macOS."
    )
    parameters = {
        "type": "object",
        "properties": {
            "command": {
                "type": "string",
                "description": "The shell command to execute.",
            },
            "timeout_sec": {
                "type": "integer",
                "description": "Max seconds to wait (default 120).",
            },
        },
        "required": ["command"],
    }

    def execute(self, *, command: str, timeout_sec: int = 120, **_: Any) -> ToolResult:
        try:
            if sys.platform == "win32":
                result = sp.run(
                    ["powershell", "-NoProfile", "-Command", command],
                    capture_output=True, text=True, timeout=timeout_sec,
                )
            else:
                result = sp.run(
                    command, shell=True,
                    capture_output=True, text=True, timeout=timeout_sec,
                )
            output = result.stdout + result.stderr
            return ToolResult(
                tool_name=self.name,
                output=output.strip() or "(no output)",
                success=result.returncode == 0,
            )
        except sp.TimeoutExpired:
            return ToolResult(
                tool_name=self.name,
                output=f"Command timed out after {timeout_sec}s",
                success=False,
            )


# ── read_file ─────────────────────────────────────────────────────────────────

class ReadFileTool(Tool):
    name = "read_file"
    description = (
        "Read the contents of a file. Optionally specify start_line and end_line "
        "(1-based) to read a range."
    )
    parameters = {
        "type": "object",
        "properties": {
            "path": {
                "type": "string",
                "description": "Absolute or relative file path to read.",
            },
            "start_line": {
                "type": "integer",
                "description": "First line to read (1-based, inclusive). Omit to read from start.",
            },
            "end_line": {
                "type": "integer",
                "description": "Last line to read (1-based, inclusive). Omit to read to end.",
            },
        },
        "required": ["path"],
    }

    def execute(
        self, *, path: str, start_line: int | None = None, end_line: int | None = None, **_: Any,
    ) -> ToolResult:
        p = Path(path).expanduser()
        if not p.is_file():
            return ToolResult(tool_name=self.name, output=f"File not found: {path}", success=False)

        try:
            lines = p.read_text(encoding="utf-8", errors="replace").splitlines(keepends=True)
        except Exception as exc:
            return ToolResult(tool_name=self.name, output=f"Read error: {exc}", success=False)

        # Slice if range requested
        start = (start_line - 1) if start_line and start_line >= 1 else 0
        end = end_line if end_line else len(lines)
        selected = lines[start:end]

        return ToolResult(
            tool_name=self.name,
            output="".join(selected) or "(empty file)",
            success=True,
        )


# ── write_file ────────────────────────────────────────────────────────────────

class WriteFileTool(Tool):
    name = "write_file"
    description = (
        "Write content to a file. Creates the file (and parent directories) if "
        "they don't exist. Overwrites existing content."
    )
    parameters = {
        "type": "object",
        "properties": {
            "path": {
                "type": "string",
                "description": "File path to write to.",
            },
            "content": {
                "type": "string",
                "description": "The full text content to write.",
            },
        },
        "required": ["path", "content"],
    }

    def execute(self, *, path: str, content: str, **_: Any) -> ToolResult:
        p = Path(path).expanduser()
        try:
            p.parent.mkdir(parents=True, exist_ok=True)
            p.write_text(content, encoding="utf-8")
            return ToolResult(
                tool_name=self.name,
                output=f"Wrote {len(content)} chars to {p}",
                success=True,
            )
        except Exception as exc:
            return ToolResult(tool_name=self.name, output=f"Write error: {exc}", success=False)


# ── edit_file ─────────────────────────────────────────────────────────────────

class EditFileTool(Tool):
    name = "edit_file"
    description = (
        "Replace an exact string in a file with new text. The old_text must "
        "appear exactly once in the file."
    )
    parameters = {
        "type": "object",
        "properties": {
            "path": {
                "type": "string",
                "description": "File path to edit.",
            },
            "old_text": {
                "type": "string",
                "description": "The exact text to find (must appear exactly once).",
            },
            "new_text": {
                "type": "string",
                "description": "The replacement text.",
            },
        },
        "required": ["path", "old_text", "new_text"],
    }

    def execute(self, *, path: str, old_text: str, new_text: str, **_: Any) -> ToolResult:
        p = Path(path).expanduser()
        if not p.is_file():
            return ToolResult(tool_name=self.name, output=f"File not found: {path}", success=False)

        try:
            content = p.read_text(encoding="utf-8")
        except Exception as exc:
            return ToolResult(tool_name=self.name, output=f"Read error: {exc}", success=False)

        count = content.count(old_text)
        if count == 0:
            return ToolResult(
                tool_name=self.name, output="old_text not found in file.", success=False,
            )
        if count > 1:
            return ToolResult(
                tool_name=self.name,
                output=f"old_text found {count} times — must be unique. Add more context.",
                success=False,
            )

        new_content = content.replace(old_text, new_text, 1)
        p.write_text(new_content, encoding="utf-8")
        return ToolResult(
            tool_name=self.name,
            output=f"Replaced text in {p}",
            success=True,
        )


# ── list_directory ────────────────────────────────────────────────────────────

class ListDirectoryTool(Tool):
    name = "list_directory"
    description = (
        "List files and subdirectories in a directory. "
        "Returns names with '/' suffix for directories."
    )
    parameters = {
        "type": "object",
        "properties": {
            "path": {
                "type": "string",
                "description": "Directory path to list. Defaults to current directory.",
            },
        },
        "required": [],
    }

    def execute(self, *, path: str = ".", **_: Any) -> ToolResult:
        p = Path(path).expanduser()
        if not p.is_dir():
            return ToolResult(
                tool_name=self.name, output=f"Not a directory: {path}", success=False,
            )

        try:
            entries = sorted(p.iterdir(), key=lambda e: (not e.is_dir(), e.name.lower()))
            lines = []
            for entry in entries:
                name = entry.name + ("/" if entry.is_dir() else "")
                lines.append(name)
            return ToolResult(
                tool_name=self.name,
                output="\n".join(lines) or "(empty directory)",
                success=True,
            )
        except Exception as exc:
            return ToolResult(tool_name=self.name, output=f"Error: {exc}", success=False)


# ── Collect all built-in tools ────────────────────────────────────────────────

ALL_BUILTIN_TOOLS: list[Tool] = [
    RunShellTool(),
    ReadFileTool(),
    WriteFileTool(),
    EditFileTool(),
    ListDirectoryTool(),
]
