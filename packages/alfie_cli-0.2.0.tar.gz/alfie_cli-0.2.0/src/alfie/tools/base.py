"""Base tool interface for ALFIE agents.

Every tool the LLM can invoke inherits from Tool and declares its
parameters via the `parameters` class-attribute (a JSON Schema dict).
The registry converts these into OpenAI function-calling definitions.
"""

from __future__ import annotations

from abc import ABC, abstractmethod
from typing import Any

from pydantic import BaseModel


class ToolResult(BaseModel):
    """Result returned by a tool execution."""

    tool_name: str = ""
    output: str = ""
    success: bool = True


class Tool(ABC):
    """Base class for all ALFIE tools.

    Subclasses must set:
        name         — unique tool name (e.g. "run_shell")
        description  — one-line description for the LLM
        parameters   — JSON Schema dict describing keyword args to execute()
    """

    name: str = "unnamed"
    description: str = ""
    parameters: dict[str, Any] = {
        "type": "object",
        "properties": {},
        "required": [],
    }

    def openai_schema(self) -> dict[str, Any]:
        """Return the OpenAI function-calling tool definition."""
        return {
            "type": "function",
            "function": {
                "name": self.name,
                "description": self.description,
                "parameters": self.parameters,
            },
        }

    @abstractmethod
    def execute(self, **kwargs: Any) -> ToolResult:
        """Execute the tool. kwargs come from the LLM's parsed arguments."""
        ...
