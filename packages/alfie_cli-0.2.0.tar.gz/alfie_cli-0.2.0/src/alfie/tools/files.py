"""File system index and management tools for ALFIE.

Provides an IndexEngine (SQLite-backed file catalog) and FileManager
that adds move/copy/rename/organize with automatic index sync.

Only wraps operations that the existing builtins can't do —
file I/O (read, write, edit, list) stays in builtin.py.
"""

from __future__ import annotations

import datetime
import json
import os
import shutil
import sqlite3
from pathlib import Path
from typing import Any

from alfie.tools.base import Tool, ToolResult


# ─────────────────────────────────────────────────────────────────────────────
# Index Engine — SQLite-backed file catalog
# ─────────────────────────────────────────────────────────────────────────────

_DEFAULT_DB_DIR = Path.home() / ".alfie"

# Extension → category mapping for organize()
_TYPE_MAP: dict[str, list[str]] = {
    "Documents": [".pdf", ".docx", ".doc", ".txt", ".md", ".xlsx", ".pptx", ".csv", ".rtf"],
    "Images":    [".jpg", ".jpeg", ".png", ".gif", ".svg", ".webp", ".bmp", ".ico", ".tiff"],
    "Videos":    [".mp4", ".mov", ".avi", ".mkv", ".wmv", ".webm"],
    "Audio":     [".mp3", ".wav", ".aac", ".flac", ".ogg", ".wma"],
    "Code":      [".py", ".js", ".ts", ".html", ".css", ".json", ".yaml", ".yml",
                  ".sh", ".bat", ".ps1", ".toml", ".ini", ".cfg", ".xml"],
    "Archives":  [".zip", ".rar", ".tar", ".gz", ".7z", ".bz2"],
}

# Max files per scan to prevent accidental full-drive indexing
_SCAN_FILE_LIMIT = 50_000


class IndexEngine:
    """Builds and maintains a local SQLite index of files.

    Database lives at ``~/.alfie/alfie_files.db`` by default.
    """

    def __init__(self, db_dir: Path | None = None):
        self.db_dir = db_dir or _DEFAULT_DB_DIR
        self.db_dir.mkdir(parents=True, exist_ok=True)
        self.db_path = self.db_dir / "alfie_files.db"
        self._init_db()

    def _conn(self) -> sqlite3.Connection:
        return sqlite3.connect(str(self.db_path))

    def _init_db(self) -> None:
        with self._conn() as conn:
            conn.execute("""
                CREATE TABLE IF NOT EXISTS file_index (
                    id          INTEGER PRIMARY KEY AUTOINCREMENT,
                    filename    TEXT NOT NULL,
                    extension   TEXT,
                    full_path   TEXT UNIQUE NOT NULL,
                    directory   TEXT,
                    size_bytes  INTEGER,
                    created_at  TEXT,
                    modified_at TEXT,
                    indexed_at  TEXT,
                    tags        TEXT
                )
            """)
            conn.commit()

    # ── Scan ──────────────────────────────────────────────────────────────

    def scan(self, root_path: str, limit: int = _SCAN_FILE_LIMIT) -> dict:
        """Recursively scan *root_path* and upsert every file into the index.

        Returns summary dict with counts.
        """
        root = Path(root_path).resolve()
        indexed = 0
        skipped = 0
        now = datetime.datetime.now().isoformat()

        with self._conn() as conn:
            for file in root.rglob("*"):
                if indexed >= limit:
                    break
                if not file.is_file():
                    continue
                try:
                    stat = file.stat()
                    conn.execute("""
                        INSERT OR REPLACE INTO file_index
                        (filename, extension, full_path, directory,
                         size_bytes, created_at, modified_at, indexed_at)
                        VALUES (?, ?, ?, ?, ?, ?, ?, ?)
                    """, (
                        file.name,
                        file.suffix.lower() or None,
                        str(file.resolve()),
                        str(file.parent.resolve()),
                        stat.st_size,
                        datetime.datetime.fromtimestamp(stat.st_ctime).isoformat(),
                        datetime.datetime.fromtimestamp(stat.st_mtime).isoformat(),
                        now,
                    ))
                    indexed += 1
                except Exception:
                    skipped += 1
            conn.commit()

        return {
            "root": str(root),
            "indexed": indexed,
            "skipped": skipped,
            "database": str(self.db_path),
        }

    # ── Search ────────────────────────────────────────────────────────────

    def search(self, query: str, limit: int = 50) -> list[dict]:
        """Search the index by filename, extension, directory, or tags."""
        q = f"%{query}%"
        with self._conn() as conn:
            conn.row_factory = sqlite3.Row
            cursor = conn.execute("""
                SELECT * FROM file_index
                WHERE filename  LIKE ?
                   OR extension LIKE ?
                   OR directory LIKE ?
                   OR tags      LIKE ?
                ORDER BY modified_at DESC
                LIMIT ?
            """, (q, q, q, q, limit))
            return [dict(row) for row in cursor.fetchall()]

    # ── Tag ───────────────────────────────────────────────────────────────

    def tag(self, full_path: str, tags: str) -> str:
        with self._conn() as conn:
            cur = conn.execute(
                "UPDATE file_index SET tags = ? WHERE full_path = ?",
                (tags, full_path),
            )
            conn.commit()
        if cur.rowcount == 0:
            return f"File not in index: {full_path}"
        return f"Tagged '{full_path}' → {tags}"

    # ── Remove ────────────────────────────────────────────────────────────

    def remove(self, full_path: str) -> None:
        with self._conn() as conn:
            conn.execute("DELETE FROM file_index WHERE full_path = ?", (full_path,))
            conn.commit()

    # ── Stats ─────────────────────────────────────────────────────────────

    def stats(self) -> dict:
        with self._conn() as conn:
            total = conn.execute("SELECT COUNT(*) FROM file_index").fetchone()[0]
            by_type = conn.execute("""
                SELECT extension, COUNT(*) as count
                FROM file_index
                GROUP BY extension
                ORDER BY count DESC
                LIMIT 10
            """).fetchall()
        return {
            "total_files_indexed": total,
            "top_file_types": [{"extension": r[0], "count": r[1]} for r in by_type],
            "database": str(self.db_path),
        }

    # ── Clear ─────────────────────────────────────────────────────────────

    def clear(self) -> str:
        with self._conn() as conn:
            conn.execute("DELETE FROM file_index")
            conn.commit()
        return "Index cleared."


# ─────────────────────────────────────────────────────────────────────────────
# File Manager — operations that sync with the index
# ─────────────────────────────────────────────────────────────────────────────

class FileManager:
    """File system operations with automatic index synchronization."""

    def __init__(self, index: IndexEngine | None = None):
        self.index = index or IndexEngine()

    def move(self, source: str, destination: str) -> str:
        src = Path(source).resolve()
        dst = Path(destination).resolve()
        if not src.is_file():
            return f"File not found: {source}"
        dst.parent.mkdir(parents=True, exist_ok=True)
        shutil.move(str(src), str(dst))
        self.index.remove(str(src))
        self.index.scan(str(dst.parent))
        return f"Moved: {source} → {destination}"

    def copy(self, source: str, destination: str) -> str:
        src = Path(source).resolve()
        dst = Path(destination).resolve()
        if not src.is_file():
            return f"File not found: {source}"
        dst.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(str(src), str(dst))
        self.index.scan(str(dst.parent))
        return f"Copied: {source} → {destination}"

    def rename(self, path: str, new_name: str) -> str:
        file = Path(path).resolve()
        if not file.is_file():
            return f"File not found: {path}"
        new_file = file.parent / new_name
        self.index.remove(str(file))
        file.rename(new_file)
        self.index.scan(str(new_file.parent))
        return f"Renamed: {file.name} → {new_name}"

    def organize(self, path: str) -> dict:
        """Auto-sort files in *path* into subfolders by type."""
        directory = Path(path).resolve()
        if not directory.is_dir():
            raise FileNotFoundError(f"Directory not found: {path}")

        moved: dict[str, list[str]] = {}
        for file in list(directory.iterdir()):
            if not file.is_file():
                continue
            target_folder = "Other"
            for folder, extensions in _TYPE_MAP.items():
                if file.suffix.lower() in extensions:
                    target_folder = folder
                    break
            dest_dir = directory / target_folder
            dest_dir.mkdir(exist_ok=True)
            dest = dest_dir / file.name
            shutil.move(str(file), str(dest))
            moved.setdefault(target_folder, []).append(file.name)

        self.index.scan(str(directory))
        return {"organized": str(directory), "moved": moved}


# Module-level singleton (uses default ~/.alfie/ DB)
_manager = FileManager()


# ─────────────────────────────────────────────────────────────────────────────
# Path safety
# ─────────────────────────────────────────────────────────────────────────────

def _resolve(path: str) -> str:
    """Resolve to absolute path within CWD."""
    resolved = os.path.abspath(path)
    cwd = os.getcwd()
    if not resolved.startswith(cwd):
        raise ValueError(f"Path escapes working directory: {path}")
    return resolved


# ─────────────────────────────────────────────────────────────────────────────
# Tool wrappers — 8 tools for the agent
# ─────────────────────────────────────────────────────────────────────────────

class ScanFilesTool(Tool):
    name = "scan_files"
    description = (
        "Scan a directory recursively and build a searchable file index. "
        "Run this before using search_files. Indexes file names, types, "
        "paths, sizes, and timestamps into a local SQLite database."
    )
    parameters = {
        "type": "object",
        "properties": {
            "path": {
                "type": "string",
                "description": "Directory path to scan recursively.",
            },
        },
        "required": ["path"],
    }

    def execute(self, *, path: str, **_: Any) -> ToolResult:
        try:
            resolved = _resolve(path)
            result = _manager.index.scan(resolved)
            return ToolResult(
                tool_name=self.name,
                output=json.dumps(result, indent=2),
                success=True,
            )
        except Exception as exc:
            return ToolResult(tool_name=self.name, output=str(exc), success=False)


class SearchFilesTool(Tool):
    name = "search_files"
    description = (
        "Search the file index for files matching a query. "
        "Searches across file names, extensions, directory paths, and tags. "
        "Returns matching files with full paths and metadata."
    )
    parameters = {
        "type": "object",
        "properties": {
            "query": {
                "type": "string",
                "description": "Search term — matches file name, extension, directory, or tag.",
            },
        },
        "required": ["query"],
    }

    def execute(self, *, query: str, **_: Any) -> ToolResult:
        try:
            results = _manager.index.search(query)
            if not results:
                return ToolResult(
                    tool_name=self.name,
                    output=f"No files found matching '{query}'.",
                    success=True,
                )
            return ToolResult(
                tool_name=self.name,
                output=json.dumps(results, indent=2, default=str),
                success=True,
            )
        except Exception as exc:
            return ToolResult(tool_name=self.name, output=str(exc), success=False)


class TagFileTool(Tool):
    name = "tag_file"
    description = (
        "Add searchable tags to a file in the index. Tags are comma-separated "
        "strings that make the file findable by topic, project, or category."
    )
    parameters = {
        "type": "object",
        "properties": {
            "path": {
                "type": "string",
                "description": "Full path to the file to tag.",
            },
            "tags": {
                "type": "string",
                "description": "Comma-separated tags (e.g. 'legal, contract, 2026').",
            },
        },
        "required": ["path", "tags"],
    }

    def execute(self, *, path: str, tags: str, **_: Any) -> ToolResult:
        try:
            resolved = str(Path(path).resolve())
            msg = _manager.index.tag(resolved, tags)
            ok = "not in index" not in msg.lower()
            return ToolResult(tool_name=self.name, output=msg, success=ok)
        except Exception as exc:
            return ToolResult(tool_name=self.name, output=str(exc), success=False)


class IndexStatsTool(Tool):
    name = "index_stats"
    description = (
        "Show file index statistics — total files indexed and top file types."
    )
    parameters = {
        "type": "object",
        "properties": {},
    }

    def execute(self, **_: Any) -> ToolResult:
        try:
            stats = _manager.index.stats()
            return ToolResult(
                tool_name=self.name,
                output=json.dumps(stats, indent=2),
                success=True,
            )
        except Exception as exc:
            return ToolResult(tool_name=self.name, output=str(exc), success=False)


class MoveFileTool(Tool):
    name = "move_file"
    description = (
        "Move a file to a new location. Creates destination directories "
        "if needed. Automatically updates the file index."
    )
    parameters = {
        "type": "object",
        "properties": {
            "source": {
                "type": "string",
                "description": "Path to the file to move.",
            },
            "destination": {
                "type": "string",
                "description": "Destination path (including filename).",
            },
        },
        "required": ["source", "destination"],
    }

    def execute(self, *, source: str, destination: str, **_: Any) -> ToolResult:
        try:
            src = _resolve(source)
            dst = _resolve(destination)
            msg = _manager.move(src, dst)
            ok = msg.startswith("Moved")
            return ToolResult(tool_name=self.name, output=msg, success=ok)
        except Exception as exc:
            return ToolResult(tool_name=self.name, output=str(exc), success=False)


class CopyFileTool(Tool):
    name = "copy_file"
    description = (
        "Copy a file to a new location. Creates destination directories "
        "if needed. Automatically updates the file index."
    )
    parameters = {
        "type": "object",
        "properties": {
            "source": {
                "type": "string",
                "description": "Path to the file to copy.",
            },
            "destination": {
                "type": "string",
                "description": "Destination path (including filename).",
            },
        },
        "required": ["source", "destination"],
    }

    def execute(self, *, source: str, destination: str, **_: Any) -> ToolResult:
        try:
            src = _resolve(source)
            dst = _resolve(destination)
            msg = _manager.copy(src, dst)
            ok = msg.startswith("Copied")
            return ToolResult(tool_name=self.name, output=msg, success=ok)
        except Exception as exc:
            return ToolResult(tool_name=self.name, output=str(exc), success=False)


class RenameFileTool(Tool):
    name = "rename_file"
    description = "Rename a file. Keeps the file in the same directory. Updates the file index."
    parameters = {
        "type": "object",
        "properties": {
            "path": {
                "type": "string",
                "description": "Path to the file to rename.",
            },
            "new_name": {
                "type": "string",
                "description": "The new filename (not a full path, just the name).",
            },
        },
        "required": ["path", "new_name"],
    }

    def execute(self, *, path: str, new_name: str, **_: Any) -> ToolResult:
        try:
            resolved = _resolve(path)
            msg = _manager.rename(resolved, new_name)
            ok = msg.startswith("Renamed")
            return ToolResult(tool_name=self.name, output=msg, success=ok)
        except Exception as exc:
            return ToolResult(tool_name=self.name, output=str(exc), success=False)


class OrganizeFilesTool(Tool):
    name = "organize_files"
    description = (
        "Auto-sort files in a directory into subfolders by type: "
        "Documents, Images, Videos, Audio, Code, Archives, Other. "
        "Only organizes top-level files, not subdirectories."
    )
    parameters = {
        "type": "object",
        "properties": {
            "path": {
                "type": "string",
                "description": "Directory path to organize.",
            },
        },
        "required": ["path"],
    }

    def execute(self, *, path: str, **_: Any) -> ToolResult:
        try:
            resolved = _resolve(path)
            result = _manager.organize(resolved)
            return ToolResult(
                tool_name=self.name,
                output=json.dumps(result, indent=2),
                success=True,
            )
        except Exception as exc:
            return ToolResult(tool_name=self.name, output=str(exc), success=False)


# ─────────────────────────────────────────────────────────────────────────────
# Collect all file tools for registration
# ─────────────────────────────────────────────────────────────────────────────

ALL_FILE_TOOLS: list[Tool] = [
    ScanFilesTool(),
    SearchFilesTool(),
    TagFileTool(),
    IndexStatsTool(),
    MoveFileTool(),
    CopyFileTool(),
    RenameFileTool(),
    OrganizeFilesTool(),
]
