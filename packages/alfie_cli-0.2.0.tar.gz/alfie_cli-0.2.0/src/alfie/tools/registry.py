"""Tool registry — central catalog of all tools available to the agent.

Tools self-register via the @register decorator or by calling registry.register().
The registry produces OpenAI-compatible function definitions for the LLM and
dispatches calls by name.
"""

from __future__ import annotations

import logging
from typing import Any, Callable

from alfie.tools.base import Tool, ToolResult

logger = logging.getLogger("alfie.tools.registry")


class ToolRegistry:
    """Holds all registered tools and dispatches calls by name."""

    def __init__(self) -> None:
        self._tools: dict[str, Tool] = {}

    # ── Registration ──────────────────────────────────────────────────────

    def register(self, tool: Tool) -> None:
        """Add a tool to the registry."""
        if tool.name in self._tools:
            logger.warning("Overwriting tool %r", tool.name)
        self._tools[tool.name] = tool
        logger.debug("Registered tool: %s", tool.name)

    # ── Lookup ────────────────────────────────────────────────────────────

    def get(self, name: str) -> Tool | None:
        return self._tools.get(name)

    def __contains__(self, name: str) -> bool:
        return name in self._tools

    def __len__(self) -> int:
        return len(self._tools)

    @property
    def names(self) -> list[str]:
        return list(self._tools)

    # ── OpenAI function-calling schema ────────────────────────────────────

    def to_openai_tools(self) -> list[dict[str, Any]]:
        """Return the list of tool definitions in OpenAI function-calling format."""
        return [tool.openai_schema() for tool in self._tools.values()]

    # ── Dispatch ──────────────────────────────────────────────────────────

    def call(self, name: str, arguments: dict[str, Any]) -> ToolResult:
        """Execute a tool by name with the given arguments.

        Returns a ToolResult — always safe, never raises from tool internals.
        """
        tool = self._tools.get(name)
        if tool is None:
            return ToolResult(
                tool_name=name,
                output=f"Unknown tool: {name}",
                success=False,
            )
        try:
            return tool.execute(**arguments)
        except Exception as exc:
            logger.exception("Tool %s failed", name)
            return ToolResult(
                tool_name=name,
                output=f"Tool error: {exc}",
                success=False,
            )


# Module-level singleton — import and use directly.
registry = ToolRegistry()
