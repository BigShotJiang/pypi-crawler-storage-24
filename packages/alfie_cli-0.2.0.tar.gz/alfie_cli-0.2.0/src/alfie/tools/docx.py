"""Document management tools for Microsoft Word (.docx) files.

Provides a DocumentManager class as the engine and 10 Tool subclasses
that wrap each operation for the LLM agent loop.

Markdown content passed to create/append is automatically converted to
native Word formatting (headings, bold, italic, lists, tables).
"""

from __future__ import annotations

import os
import re
from pathlib import Path
from typing import Any

from docx import Document
from docx.shared import Pt, RGBColor

from alfie.tools.base import Tool, ToolResult


# ─────────────────────────────────────────────────────────────────────────────
# Markdown → Word converter
# ─────────────────────────────────────────────────────────────────────────────

_HEADING_RE = re.compile(r"^(#{1,6})\s+(.+)$")
_BULLET_RE = re.compile(r"^[-*+]\s+(.+)$")
_ORDERED_RE = re.compile(r"^\d+[.)]\s+(.+)$")
# Require at least 2 columns: | cell | cell | (3+ pipes)
_TABLE_ROW_RE = re.compile(r"^\|[^|]+\|[^|]+\|")
_SEPARATOR_RE = re.compile(r"^\|[\s:-]+\|[\s:-]+\|")
# Inline patterns — order matters (bold-italic before bold before italic)
_INLINE_BOLD_ITALIC = re.compile(r"\*\*\*(.+?)\*\*\*")
_INLINE_BOLD = re.compile(r"\*\*(.+?)\*\*")
_INLINE_ITALIC = re.compile(r"\*(.+?)\*")


def _add_inline_runs(paragraph, text: str) -> None:
    """Parse inline markdown (bold, italic) and add styled runs to a paragraph."""
    # Split text into segments: (text, bold, italic)
    segments: list[tuple[str, bool, bool]] = []
    pos = 0
    while pos < len(text):
        # Try bold-italic first
        m = _INLINE_BOLD_ITALIC.search(text, pos)
        mb = _INLINE_BOLD.search(text, pos)
        mi = _INLINE_ITALIC.search(text, pos)

        # Pick the earliest match
        candidates = []
        if m:
            candidates.append(("bi", m))
        if mb:
            candidates.append(("b", mb))
        if mi:
            candidates.append(("i", mi))

        if not candidates:
            segments.append((text[pos:], False, False))
            break

        candidates.sort(key=lambda c: c[1].start())
        kind, match = candidates[0]

        # Text before the match
        if match.start() > pos:
            segments.append((text[pos:match.start()], False, False))

        inner = match.group(1)
        if kind == "bi":
            segments.append((inner, True, True))
        elif kind == "b":
            segments.append((inner, True, False))
        else:
            segments.append((inner, False, True))

        pos = match.end()

    for seg_text, bold, italic in segments:
        if not seg_text:
            continue
        run = paragraph.add_run(seg_text)
        if bold:
            run.bold = True
        if italic:
            run.italic = True


def _parse_table_row(line: str) -> list[str]:
    """Extract cell values from a markdown table row like '| a | b |'."""
    return [cell.strip() for cell in line.strip().strip("|").split("|")]


def _markdown_to_docx(doc: Document, content: str) -> None:
    """Convert markdown-formatted text into native Word elements on *doc*.

    Supported:
        # Heading 1 .. ###### Heading 6
        **bold**, *italic*, ***bold italic***
        - bullet lists
        1. numbered lists
        | col | col |  tables (with separator row skipped)
        blank lines  → ignored
        plain text   → Normal paragraph
    """
    lines = content.split("\n")
    i = 0
    while i < len(lines):
        line = lines[i]
        stripped = line.strip()

        # Skip blank lines
        if not stripped:
            i += 1
            continue

        # ── Heading ──
        m = _HEADING_RE.match(stripped)
        if m:
            level = len(m.group(1))
            heading_text = m.group(2).strip()
            para = doc.add_heading(level=level)
            _add_inline_runs(para, heading_text)
            i += 1
            continue

        # ── Table block ──
        if _TABLE_ROW_RE.match(stripped):
            rows: list[list[str]] = []
            while i < len(lines):
                row_line = lines[i].strip()
                if not _TABLE_ROW_RE.match(row_line):
                    # Also skip separator-only rows
                    if _SEPARATOR_RE.match(row_line):
                        i += 1
                        continue
                    break
                # Skip separator rows (|---|---|)
                if _SEPARATOR_RE.match(row_line):
                    i += 1
                    continue
                rows.append(_parse_table_row(row_line))
                i += 1
            if rows:
                cols = max(len(r) for r in rows)
                table = doc.add_table(rows=len(rows), cols=cols)
                table.style = "Table Grid"
                for ri, row_data in enumerate(rows):
                    for ci, cell_text in enumerate(row_data):
                        if ci < cols:
                            table.rows[ri].cells[ci].text = cell_text
            continue

        # ── Bullet list ──
        m = _BULLET_RE.match(stripped)
        if m:
            para = doc.add_paragraph(style="List Bullet")
            _add_inline_runs(para, m.group(1))
            i += 1
            continue

        # ── Numbered list ──
        m = _ORDERED_RE.match(stripped)
        if m:
            para = doc.add_paragraph(style="List Number")
            _add_inline_runs(para, m.group(1))
            i += 1
            continue

        # ── Normal paragraph ──
        para = doc.add_paragraph()
        _add_inline_runs(para, stripped)
        i += 1


# ─────────────────────────────────────────────────────────────────────────────
# Table data normalization
# ─────────────────────────────────────────────────────────────────────────────

def _normalize_table_data(data: Any) -> list[list[str]]:
    """Coerce whatever the LLM sends into a proper list[list[str]].

    Handles common LLM mistakes:
      - JSON string instead of array  →  parse it
      - Flat list of strings          →  single-column table
      - Mixed list (some str, some list) → wrap bare strings
    """
    import json as _json

    # String → try JSON parse
    if isinstance(data, str):
        try:
            data = _json.loads(data)
        except (_json.JSONDecodeError, TypeError):
            return [[data]]

    if not isinstance(data, list) or not data:
        return [[str(data)]]

    # Flat list of scalars → single-column table
    if all(isinstance(item, str) for item in data):
        return [[item] for item in data]

    # Normalize each row: ensure inner items are lists
    normalized: list[list[str]] = []
    for row in data:
        if isinstance(row, list):
            normalized.append([str(cell) for cell in row])
        elif isinstance(row, str):
            normalized.append([row])
        else:
            normalized.append([str(row)])

    return normalized


# ─────────────────────────────────────────────────────────────────────────────
# Document defaults
# ─────────────────────────────────────────────────────────────────────────────

DEFAULT_FONT = "Segoe UI"
DEFAULT_FONT_SIZE = 11.5  # points


def _apply_defaults(
    doc: Document,
    font_name: str = DEFAULT_FONT,
    font_size: float = DEFAULT_FONT_SIZE,
) -> None:
    """Set the Normal style's font so every element inherits it."""
    style = doc.styles["Normal"]
    style.font.name = font_name
    style.font.size = Pt(font_size)


# ─────────────────────────────────────────────────────────────────────────────
# Engine
# ─────────────────────────────────────────────────────────────────────────────

class DocumentManager:
    """Low-level Word document operations. Tools delegate here."""

    def create(
        self,
        filename: str,
        content: str = "",
        title: str = "",
        font_name: str = DEFAULT_FONT,
        font_size: float = DEFAULT_FONT_SIZE,
    ) -> str:
        doc = Document()
        _apply_defaults(doc, font_name=font_name, font_size=font_size)
        if title:
            doc.add_heading(title, level=1)
        if content:
            _markdown_to_docx(doc, content)
        Path(filename).parent.mkdir(parents=True, exist_ok=True)
        doc.save(filename)
        return f"Created: {filename}"

    def read(self, filename: str) -> dict:
        doc = Document(filename)
        structure = [
            {"style": p.style.name, "text": p.text} for p in doc.paragraphs
        ]
        tables = [
            [
                [cell.text for cell in row.cells]
                for row in table.rows
            ]
            for table in doc.tables
        ]
        return {
            "filename": filename,
            "paragraphs": structure,
            "tables": tables,
            "full_text": "\n".join(p.text for p in doc.paragraphs),
        }

    def edit(self, filename: str, find: str, replace: str) -> str:
        doc = Document(filename)
        for para in doc.paragraphs:
            if find in para.text:
                for run in para.runs:
                    if find in run.text:
                        run.text = run.text.replace(find, replace)
        doc.save(filename)
        return f"Edited: '{find}' → '{replace}' in {filename}"

    def append(self, filename: str, content: str, style: str = "Normal") -> str:
        doc = Document(filename)
        if style != "Normal":
            doc.add_paragraph(content, style=style)
        else:
            _markdown_to_docx(doc, content)
        doc.save(filename)
        return f"Appended content to {filename}"

    def add_heading(self, filename: str, text: str, level: int = 1) -> str:
        doc = Document(filename)
        doc.add_heading(text, level=level)
        doc.save(filename)
        return f"Added heading '{text}' (level {level}) to {filename}"

    def add_table(self, filename: str, data: list[list[str]]) -> str:
        doc = Document(filename)
        data = _normalize_table_data(data)
        table = doc.add_table(rows=len(data), cols=len(data[0]))
        table.style = "Table Grid"
        for i, row in enumerate(data):
            for j, cell_text in enumerate(row):
                table.rows[i].cells[j].text = str(cell_text)
        doc.save(filename)
        return f"Added table ({len(data)} rows) to {filename}"

    def format_text(
        self,
        filename: str,
        find: str,
        bold: bool = False,
        italic: bool = False,
        font_size: int | None = None,
        color: tuple[int, int, int] | None = None,
    ) -> str:
        doc = Document(filename)
        for para in doc.paragraphs:
            for run in para.runs:
                if find in run.text:
                    run.bold = bold
                    run.italic = italic
                    if font_size:
                        run.font.size = Pt(font_size)
                    if color:
                        run.font.color.rgb = RGBColor(*color)
        doc.save(filename)
        return f"Formatted '{find}' in {filename}"

    def delete_paragraph(self, filename: str, find: str) -> str:
        doc = Document(filename)
        for para in doc.paragraphs:
            if find in para.text:
                para._element.getparent().remove(para._element)
                break
        doc.save(filename)
        return f"Deleted paragraph containing '{find}' from {filename}"

    def delete_file(self, filename: str) -> str:
        if os.path.exists(filename):
            os.remove(filename)
            return f"Deleted file: {filename}"
        return f"File not found: {filename}"

    def save_as(self, filename: str, new_filename: str) -> str:
        doc = Document(filename)
        Path(new_filename).parent.mkdir(parents=True, exist_ok=True)
        doc.save(new_filename)
        return f"Saved as: {new_filename}"


# Module-level singleton
_manager = DocumentManager()


# ─────────────────────────────────────────────────────────────────────────────
# Helper to validate .docx paths
# ─────────────────────────────────────────────────────────────────────────────

def _resolve(filename: str) -> str:
    """Resolve to absolute and verify it stays under CWD."""
    resolved = os.path.abspath(filename)
    cwd = os.getcwd()
    if not resolved.startswith(cwd):
        raise ValueError(f"Path escapes working directory: {filename}")
    return resolved


def _require_exists(filename: str) -> str:
    """Resolve path and check it exists."""
    resolved = _resolve(filename)
    if not os.path.isfile(resolved):
        raise FileNotFoundError(f"File not found: {filename}")
    return resolved


# ─────────────────────────────────────────────────────────────────────────────
# Tool wrappers — one per DocumentManager method
# ─────────────────────────────────────────────────────────────────────────────

class CreateDocxTool(Tool):
    name = "create_docx"
    description = "Create a new Word (.docx) document with optional title and body content."
    parameters = {
        "type": "object",
        "properties": {
            "filename": {
                "type": "string",
                "description": "Path for the new .docx file (e.g. 'report.docx').",
            },
            "title": {
                "type": "string",
                "description": "Optional heading title for the document.",
            },
            "content": {
                "type": "string",
                "description": "Optional body text to add below the title (supports markdown).",
            },
            "font_name": {
                "type": "string",
                "description": "Font family name (default: Segoe UI).",
            },
            "font_size": {
                "type": "number",
                "description": "Font size in points (default: 11.5).",
            },
        },
        "required": ["filename"],
    }

    def execute(
        self,
        *,
        filename: str,
        title: str = "",
        content: str = "",
        font_name: str = DEFAULT_FONT,
        font_size: float = DEFAULT_FONT_SIZE,
        **_: Any,
    ) -> ToolResult:
        try:
            path = _resolve(filename)
            msg = _manager.create(
                path, content=content, title=title,
                font_name=font_name, font_size=font_size,
            )
            return ToolResult(tool_name=self.name, output=msg, success=True)
        except Exception as exc:
            return ToolResult(tool_name=self.name, output=str(exc), success=False)


class ReadDocxTool(Tool):
    name = "read_docx"
    description = (
        "Read a Word document and return its full text, paragraph structure, "
        "and any tables."
    )
    parameters = {
        "type": "object",
        "properties": {
            "filename": {
                "type": "string",
                "description": "Path to the .docx file to read.",
            },
        },
        "required": ["filename"],
    }

    def execute(self, *, filename: str, **_: Any) -> ToolResult:
        try:
            path = _require_exists(filename)
            data = _manager.read(path)
            import json
            return ToolResult(
                tool_name=self.name,
                output=json.dumps(data, indent=2, ensure_ascii=False),
                success=True,
            )
        except Exception as exc:
            return ToolResult(tool_name=self.name, output=str(exc), success=False)


class EditDocxTool(Tool):
    name = "edit_docx"
    description = "Find specific text in a Word document and replace it with new text."
    parameters = {
        "type": "object",
        "properties": {
            "filename": {
                "type": "string",
                "description": "Path to the .docx file.",
            },
            "find": {
                "type": "string",
                "description": "The exact text to search for.",
            },
            "replace": {
                "type": "string",
                "description": "The replacement text.",
            },
        },
        "required": ["filename", "find", "replace"],
    }

    def execute(self, *, filename: str, find: str, replace: str, **_: Any) -> ToolResult:
        try:
            path = _require_exists(filename)
            msg = _manager.edit(path, find, replace)
            return ToolResult(tool_name=self.name, output=msg, success=True)
        except Exception as exc:
            return ToolResult(tool_name=self.name, output=str(exc), success=False)


class AppendDocxTool(Tool):
    name = "append_docx"
    description = "Append a new paragraph to the end of a Word document."
    parameters = {
        "type": "object",
        "properties": {
            "filename": {
                "type": "string",
                "description": "Path to the .docx file.",
            },
            "content": {
                "type": "string",
                "description": "The text to append.",
            },
            "style": {
                "type": "string",
                "description": "Paragraph style name (default: 'Normal'). E.g. 'List Bullet', 'Quote'.",
            },
        },
        "required": ["filename", "content"],
    }

    def execute(self, *, filename: str, content: str, style: str = "Normal", **_: Any) -> ToolResult:
        try:
            path = _require_exists(filename)
            msg = _manager.append(path, content, style=style)
            return ToolResult(tool_name=self.name, output=msg, success=True)
        except Exception as exc:
            return ToolResult(tool_name=self.name, output=str(exc), success=False)


class AddDocxHeadingTool(Tool):
    name = "add_docx_heading"
    description = "Add a heading to a Word document at a specified level (1–6)."
    parameters = {
        "type": "object",
        "properties": {
            "filename": {
                "type": "string",
                "description": "Path to the .docx file.",
            },
            "text": {
                "type": "string",
                "description": "The heading text.",
            },
            "level": {
                "type": "integer",
                "description": "Heading level 1–6 (default: 1).",
            },
        },
        "required": ["filename", "text"],
    }

    def execute(self, *, filename: str, text: str, level: int = 1, **_: Any) -> ToolResult:
        try:
            path = _require_exists(filename)
            msg = _manager.add_heading(path, text, level=level)
            return ToolResult(tool_name=self.name, output=msg, success=True)
        except Exception as exc:
            return ToolResult(tool_name=self.name, output=str(exc), success=False)


class AddDocxTableTool(Tool):
    name = "add_docx_table"
    description = (
        "Insert a table into a Word document. Provide data as a 2D array "
        "where the first row is headers."
    )
    parameters = {
        "type": "object",
        "properties": {
            "filename": {
                "type": "string",
                "description": "Path to the .docx file.",
            },
            "data": {
                "type": "array",
                "description": "2D array of strings, e.g. [[\"Name\",\"Age\"],[\"Alice\",\"30\"]].",
                "items": {
                    "type": "array",
                    "items": {"type": "string"},
                },
            },
        },
        "required": ["filename", "data"],
    }

    def execute(self, *, filename: str, data: Any = None, **_: Any) -> ToolResult:
        try:
            path = _require_exists(filename)
            if not data:
                return ToolResult(tool_name=self.name, output="Data must be non-empty.", success=False)
            normalized = _normalize_table_data(data)
            if not normalized or not normalized[0]:
                return ToolResult(tool_name=self.name, output="Data must be non-empty 2D array.", success=False)
            msg = _manager.add_table(path, normalized)
            return ToolResult(tool_name=self.name, output=msg, success=True)
        except Exception as exc:
            return ToolResult(tool_name=self.name, output=str(exc), success=False)


class FormatDocxTextTool(Tool):
    name = "format_docx_text"
    description = (
        "Find text in a Word document and apply formatting: bold, italic, "
        "font size, and/or font color."
    )
    parameters = {
        "type": "object",
        "properties": {
            "filename": {
                "type": "string",
                "description": "Path to the .docx file.",
            },
            "find": {
                "type": "string",
                "description": "The text to format.",
            },
            "bold": {
                "type": "boolean",
                "description": "Set the text bold (default: false).",
            },
            "italic": {
                "type": "boolean",
                "description": "Set the text italic (default: false).",
            },
            "font_size": {
                "type": "integer",
                "description": "Font size in points (e.g. 14).",
            },
            "color": {
                "type": "array",
                "description": "RGB color as [R, G, B] integers 0–255.",
                "items": {"type": "integer"},
                "minItems": 3,
                "maxItems": 3,
            },
        },
        "required": ["filename", "find"],
    }

    def execute(
        self,
        *,
        filename: str,
        find: str,
        bold: bool = False,
        italic: bool = False,
        font_size: int | None = None,
        color: list[int] | None = None,
        **_: Any,
    ) -> ToolResult:
        try:
            path = _require_exists(filename)
            color_tuple = tuple(color) if color else None
            msg = _manager.format_text(
                path, find, bold=bold, italic=italic,
                font_size=font_size, color=color_tuple,
            )
            return ToolResult(tool_name=self.name, output=msg, success=True)
        except Exception as exc:
            return ToolResult(tool_name=self.name, output=str(exc), success=False)


class DeleteDocxParagraphTool(Tool):
    name = "delete_docx_paragraph"
    description = "Delete the first paragraph that contains the specified text from a Word document."
    parameters = {
        "type": "object",
        "properties": {
            "filename": {
                "type": "string",
                "description": "Path to the .docx file.",
            },
            "find": {
                "type": "string",
                "description": "Text to match — the first paragraph containing this will be deleted.",
            },
        },
        "required": ["filename", "find"],
    }

    def execute(self, *, filename: str, find: str, **_: Any) -> ToolResult:
        try:
            path = _require_exists(filename)
            msg = _manager.delete_paragraph(path, find)
            return ToolResult(tool_name=self.name, output=msg, success=True)
        except Exception as exc:
            return ToolResult(tool_name=self.name, output=str(exc), success=False)


class DeleteDocxFileTool(Tool):
    name = "delete_docx_file"
    description = "Permanently delete a .docx file from disk."
    parameters = {
        "type": "object",
        "properties": {
            "filename": {
                "type": "string",
                "description": "Path to the .docx file to delete.",
            },
        },
        "required": ["filename"],
    }

    def execute(self, *, filename: str, **_: Any) -> ToolResult:
        try:
            path = _resolve(filename)
            msg = _manager.delete_file(path)
            ok = msg.startswith("Deleted file")
            return ToolResult(tool_name=self.name, output=msg, success=ok)
        except Exception as exc:
            return ToolResult(tool_name=self.name, output=str(exc), success=False)


class SaveDocxAsTool(Tool):
    name = "save_docx_as"
    description = "Save a copy of a Word document under a new filename."
    parameters = {
        "type": "object",
        "properties": {
            "filename": {
                "type": "string",
                "description": "Path to the existing .docx file.",
            },
            "new_filename": {
                "type": "string",
                "description": "Path for the new copy.",
            },
        },
        "required": ["filename", "new_filename"],
    }

    def execute(self, *, filename: str, new_filename: str, **_: Any) -> ToolResult:
        try:
            path = _require_exists(filename)
            new_path = _resolve(new_filename)
            msg = _manager.save_as(path, new_path)
            return ToolResult(tool_name=self.name, output=msg, success=True)
        except Exception as exc:
            return ToolResult(tool_name=self.name, output=str(exc), success=False)


# ─────────────────────────────────────────────────────────────────────────────
# Collect all docx tools for registration
# ─────────────────────────────────────────────────────────────────────────────

ALL_DOCX_TOOLS: list[Tool] = [
    CreateDocxTool(),
    ReadDocxTool(),
    EditDocxTool(),
    AppendDocxTool(),
    AddDocxHeadingTool(),
    AddDocxTableTool(),
    FormatDocxTextTool(),
    DeleteDocxParagraphTool(),
    DeleteDocxFileTool(),
    SaveDocxAsTool(),
]
