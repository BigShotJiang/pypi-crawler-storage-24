"""ALFIE tool system.

Importing this module registers all built-in tools in the global registry.
"""

from alfie.tools.base import Tool, ToolResult
from alfie.tools.registry import ToolRegistry, registry

# Register built-in tools on first import
from alfie.tools.builtin import ALL_BUILTIN_TOOLS as _builtins
from alfie.tools.docx import ALL_DOCX_TOOLS as _docx_tools
from alfie.tools.files import ALL_FILE_TOOLS as _file_tools

for _tool in _builtins:
    registry.register(_tool)

for _tool in _docx_tools:
    registry.register(_tool)

for _tool in _file_tools:
    registry.register(_tool)

__all__ = ["Tool", "ToolResult", "ToolRegistry", "registry"]
