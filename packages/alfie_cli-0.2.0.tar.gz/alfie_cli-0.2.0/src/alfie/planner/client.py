"""LLM client — OpenAI SDK wired to Vercel AI Gateway.

Provides both sync and async clients, streaming support,
structured outputs (JSON schema), and tool calling.

Configuration:
    base_url: Vercel AI Gateway endpoint (default: https://ai-gateway.vercel.sh/v1)
    api_key:  Read from env var configured in config.toml (default: AI_GATEWAY_API_KEY)
    model:    Any model routed through the gateway (e.g. gpt-4o-mini, anthropic/claude-sonnet-4.6)

See: https://vercel.com/docs/ai-gateway/sdks-and-apis/python
"""

from __future__ import annotations

import logging
import os
from typing import Any

from openai import AsyncOpenAI, OpenAI

from alfie.config import AIGatewayConfig, load_config

logger = logging.getLogger("alfie.planner.client")


def _resolve_api_key(config: AIGatewayConfig) -> str:
    """Resolve the API key from environment variables.

    Checks the configured env var name, then falls back to OPENAI_API_KEY.
    """
    key = os.environ.get(config.api_key_env) or os.environ.get("OPENAI_API_KEY", "")
    if not key:
        raise RuntimeError(
            f"No API key found. Set the {config.api_key_env} or OPENAI_API_KEY "
            "environment variable."
        )
    return key


def build_client(
    model: str | None = None,
    config: AIGatewayConfig | None = None,
) -> tuple[OpenAI, str]:
    """Build a synchronous OpenAI client pointed at Vercel AI Gateway.

    Returns (client, resolved_model).
    """
    cfg = config or load_config().ai_gateway
    api_key = _resolve_api_key(cfg)
    resolved_model = model or load_config().general.default_model

    client = OpenAI(
        api_key=api_key,
        base_url=cfg.base_url,
    )
    logger.info("Client ready: base=%s model=%s", cfg.base_url, resolved_model)
    return client, resolved_model


def build_async_client(
    model: str | None = None,
    config: AIGatewayConfig | None = None,
) -> tuple[AsyncOpenAI, str]:
    """Build an async OpenAI client pointed at Vercel AI Gateway.

    Returns (async_client, resolved_model).
    """
    cfg = config or load_config().ai_gateway
    api_key = _resolve_api_key(cfg)
    resolved_model = model or load_config().general.default_model

    client = AsyncOpenAI(
        api_key=api_key,
        base_url=cfg.base_url,
    )
    return client, resolved_model


def chat(
    messages: list[dict[str, str]],
    model: str | None = None,
    config: AIGatewayConfig | None = None,
    response_format: dict[str, Any] | None = None,
    temperature: float | None = None,
    max_tokens: int | None = None,
) -> str:
    """One-shot chat completion. Returns the assistant message content."""
    cfg = config or load_config().ai_gateway
    client, resolved_model = build_client(model, cfg)

    kwargs: dict[str, Any] = {
        "model": resolved_model,
        "messages": messages,
        "temperature": temperature if temperature is not None else cfg.temperature,
        "max_tokens": max_tokens or cfg.max_tokens,
    }
    if response_format:
        kwargs["response_format"] = response_format

    response = client.chat.completions.create(**kwargs)
    content = response.choices[0].message.content or ""
    logger.debug("Chat response (%d chars): %s...", len(content), content[:200])
    return content


async def achat(
    messages: list[dict[str, str]],
    model: str | None = None,
    config: AIGatewayConfig | None = None,
    response_format: dict[str, Any] | None = None,
    temperature: float | None = None,
    max_tokens: int | None = None,
) -> str:
    """Async one-shot chat completion. Returns the assistant message content."""
    cfg = config or load_config().ai_gateway
    client, resolved_model = build_async_client(model, cfg)

    kwargs: dict[str, Any] = {
        "model": resolved_model,
        "messages": messages,
        "temperature": temperature if temperature is not None else cfg.temperature,
        "max_tokens": max_tokens or cfg.max_tokens,
    }
    if response_format:
        kwargs["response_format"] = response_format

    response = await client.chat.completions.create(**kwargs)
    content = response.choices[0].message.content or ""
    return content
