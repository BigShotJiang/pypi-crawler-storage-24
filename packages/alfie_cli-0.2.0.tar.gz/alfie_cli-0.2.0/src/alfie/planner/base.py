"""LLM planner prompts and JSON schema for structured outputs.

Defines the system prompt that instructs the LLM how to decompose
user intent into an executable task DAG, and the JSON schema used
with Vercel AI Gateway's structured outputs feature.

See: https://vercel.com/docs/ai-gateway/sdks-and-apis/python#structured-outputs
"""

from __future__ import annotations

import platform

_OS_NAME = platform.system()  # "Windows", "Linux", "Darwin"
_OS_RELEASE = platform.release()

SYSTEM_PROMPT = f"""\
You are ALFIE — Artificial Lifeform Intelligent Entity, an autonomous \
system-level AI agent that plans and orchestrates shell-level tasks.

Given a user request, decompose it into a directed acyclic graph (DAG) of \
atomic shell commands that can be scheduled.

HOST ENVIRONMENT:
- Operating System: {_OS_NAME} {_OS_RELEASE}
- Shell: {"PowerShell" if _OS_NAME == "Windows" else "bash"}
- IMPORTANT: Generate commands that work natively on the host OS and shell.
  {'On Windows, use PowerShell cmdlets (Get-ChildItem, Get-CimInstance, etc.) and Windows CLI tools (systeminfo, wmic, etc.). Do NOT generate Linux commands like ls, cat, grep, lscpu, free, lspci, ip.' if _OS_NAME == 'Windows' else 'On Linux/macOS, use standard POSIX utilities (ls, cat, grep, etc.).'}

RULES:
1. Break complex requests into small, atomic shell tasks (one command each).
2. Use `depends_on` to express ordering. Tasks with no dependencies run in parallel.
3. Each task `id` must be unique and short (e.g. "t1", "install_deps", "run_tests").
4. Each `cmd` must be a valid command for the host shell described above.
5. Set reasonable `timeout_sec` — default 120s for quick tasks, up to 600s for builds.
6. Choose `on_failure` strategy:
   - "retry"    — retry the task (default for flaky commands like network calls)
   - "skip"     — skip dependent tasks and continue others
   - "abort"    — stop the entire plan
   - "escalate" — skip unreachable dependents, continue independent tasks
7. For commands that need output from a prior task, set task_type to "dynamic" \
   and describe what's needed in the description field.
8. NEVER include destructive commands (rm -rf /, dd, mkfs, Format-Volume) — they will be blocked.
9. Prefer idempotent commands when possible.

Your response MUST be ONLY valid JSON matching the schema — no markdown fences, \
no explanation, no commentary. JUST the JSON object.
"""

PLAN_SCHEMA = {
    "type": "json_schema",
    "json_schema": {
        "name": "task_plan",
        "strict": True,
        "schema": {
            "type": "object",
            "properties": {
                "intent": {
                    "type": "string",
                    "description": "Restatement of what the user wants",
                },
                "tasks": {
                    "type": "array",
                    "items": {
                        "type": "object",
                        "properties": {
                            "id": {
                                "type": "string",
                                "description": "Unique short task identifier",
                            },
                            "cmd": {
                                "type": "string",
                                "description": "Shell command to execute",
                            },
                            "description": {
                                "type": "string",
                                "description": "Human-readable description of the task",
                            },
                            "depends_on": {
                                "type": "array",
                                "items": {"type": "string"},
                                "description": "List of task IDs this depends on",
                            },
                            "task_type": {
                                "type": "string",
                                "enum": ["shell", "llm_step", "dynamic"],
                                "description": "Type of task",
                            },
                            "timeout_sec": {
                                "type": "integer",
                                "description": "Max seconds before timeout",
                            },
                            "on_failure": {
                                "type": "string",
                                "enum": ["retry", "skip", "abort", "escalate"],
                                "description": "What to do if task fails",
                            },
                        },
                        "required": ["id", "cmd", "description", "depends_on"],
                        "additionalProperties": False,
                    },
                    "description": "Ordered list of tasks forming a DAG",
                },
            },
            "required": ["intent", "tasks"],
            "additionalProperties": False,
        },
    },
}


def build_user_message(intent: str, context: str | None = None) -> str:
    """Build the user message from intent + optional context."""
    msg = f"USER REQUEST: {intent}"
    if context:
        msg += f"\n\nADDITIONAL CONTEXT:\n{context}"
    return msg

