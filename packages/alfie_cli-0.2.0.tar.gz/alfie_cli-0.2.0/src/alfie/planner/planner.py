"""Planner engine — converts natural-language intent into a validated Plan.

Uses the Vercel AI Gateway (OpenAI SDK + custom base_url) for LLM access
with structured outputs to guarantee valid JSON responses.

Usage:
    from alfie.planner import Planner

    planner = Planner(model="gpt-4o-mini")
    plan = planner.generate("set up a Python project with pytest")
    plan = await planner.agenerate("deploy to staging")
"""

from __future__ import annotations

import json
import logging
from typing import Any

from alfie.config import AIGatewayConfig, load_config
from alfie.models import FailureStrategy, Plan, RetryPolicy, Task
from alfie.planner.base import PLAN_SCHEMA, SYSTEM_PROMPT, build_user_message
from alfie.planner.client import achat, chat
from alfie.scheduler.dag import topological_sort

logger = logging.getLogger("alfie.planner")


class PlannerError(Exception):
    """Raised when the planner fails to generate a valid plan."""


class Planner:
    """LLM-powered planner that decomposes intent into a task DAG.

    The planner:
    1. Sends the user intent to the LLM with a structured output schema
    2. Parses the JSON response into Task objects
    3. Validates the DAG (no cycles, valid deps)
    4. Returns a Plan ready for the scheduler
    """

    def __init__(
        self,
        model: str | None = None,
        config: AIGatewayConfig | None = None,
        temperature: float | None = None,
        max_retries: int = 2,
    ) -> None:
        cfg = load_config()
        self._config = config or cfg.ai_gateway
        self._model = model or cfg.general.default_model
        self._temperature = temperature
        self._max_retries = max_retries

    @property
    def model(self) -> str:
        return self._model

    def generate(self, intent: str, context: str | None = None) -> Plan:
        """Synchronously generate a Plan from natural-language intent."""
        messages = self._build_messages(intent, context)

        last_error: Exception | None = None
        for attempt in range(1, self._max_retries + 1):
            try:
                raw = chat(
                    messages=messages,
                    model=self._model,
                    config=self._config,
                    response_format=PLAN_SCHEMA,
                    temperature=self._temperature,
                )
                return self._parse_response(raw, intent)
            except (json.JSONDecodeError, PlannerError, KeyError) as exc:
                last_error = exc
                logger.warning(
                    "Planner attempt %d/%d failed: %s",
                    attempt, self._max_retries, exc,
                )
                # Add correction hint for retry
                messages.append({"role": "assistant", "content": raw if "raw" in dir() else ""})
                messages.append({
                    "role": "user",
                    "content": (
                        f"Your response was invalid: {exc}. "
                        "Please return ONLY valid JSON matching the schema."
                    ),
                })

        raise PlannerError(f"Failed after {self._max_retries} attempts: {last_error}")

    async def agenerate(self, intent: str, context: str | None = None) -> Plan:
        """Asynchronously generate a Plan from natural-language intent."""
        messages = self._build_messages(intent, context)

        last_error: Exception | None = None
        for attempt in range(1, self._max_retries + 1):
            try:
                raw = await achat(
                    messages=messages,
                    model=self._model,
                    config=self._config,
                    response_format=PLAN_SCHEMA,
                    temperature=self._temperature,
                )
                return self._parse_response(raw, intent)
            except (json.JSONDecodeError, PlannerError, KeyError) as exc:
                last_error = exc
                logger.warning(
                    "Planner attempt %d/%d failed: %s",
                    attempt, self._max_retries, exc,
                )
                messages.append({"role": "assistant", "content": raw if "raw" in dir() else ""})
                messages.append({
                    "role": "user",
                    "content": (
                        f"Your response was invalid: {exc}. "
                        "Please return ONLY valid JSON matching the schema."
                    ),
                })

        raise PlannerError(f"Failed after {self._max_retries} attempts: {last_error}")

    # ── Internal ──────────────────────────────────────────────────────────

    def _build_messages(
        self, intent: str, context: str | None = None
    ) -> list[dict[str, str]]:
        return [
            {"role": "system", "content": SYSTEM_PROMPT},
            {"role": "user", "content": build_user_message(intent, context)},
        ]

    def _parse_response(self, raw: str, intent: str) -> Plan:
        """Parse raw LLM JSON into a validated Plan."""
        # Strip markdown fences if the model wraps them anyway
        cleaned = raw.strip()
        if cleaned.startswith("```"):
            cleaned = cleaned.split("\n", 1)[1] if "\n" in cleaned else cleaned[3:]
            if cleaned.endswith("```"):
                cleaned = cleaned[:-3]
            cleaned = cleaned.strip()

        data = json.loads(cleaned)

        if "tasks" not in data or not isinstance(data["tasks"], list):
            raise PlannerError("Response missing 'tasks' array")

        if not data["tasks"]:
            raise PlannerError("Plan has no tasks")

        # Build Task objects
        tasks: list[Task] = []
        seen_ids: set[str] = set()

        for raw_task in data["tasks"]:
            tid = raw_task.get("id", "")
            if not tid:
                raise PlannerError(f"Task missing 'id': {raw_task}")
            if tid in seen_ids:
                raise PlannerError(f"Duplicate task id: {tid}")
            seen_ids.add(tid)

            # Map on_failure string to enum
            failure_str = raw_task.get("on_failure", "escalate")
            try:
                on_failure = FailureStrategy(failure_str)
            except ValueError:
                on_failure = FailureStrategy.ESCALATE

            task = Task(
                id=tid,
                cmd=raw_task.get("cmd", ""),
                description=raw_task.get("description", ""),
                depends_on=raw_task.get("depends_on", []),
                task_type=raw_task.get("task_type", "shell"),
                timeout_sec=raw_task.get("timeout_sec", 300),
                on_failure=on_failure,
            )

            if not task.cmd:
                raise PlannerError(f"Task {tid} has empty cmd")

            tasks.append(task)

        # Validate all depends_on references exist
        for task in tasks:
            for dep_id in task.depends_on:
                if dep_id not in seen_ids:
                    raise PlannerError(
                        f"Task {task.id} depends on unknown task: {dep_id}"
                    )

        # Validate DAG (no cycles)
        try:
            topological_sort(tasks)
        except ValueError as exc:
            raise PlannerError(f"Invalid DAG: {exc}") from exc

        plan = Plan(
            intent=data.get("intent", intent),
            tasks=tasks,
            model=self._model,
        )

        logger.info(
            "Plan generated: %d tasks, %d layers",
            len(tasks),
            len(topological_sort(tasks)),
        )
        return plan
