"""Core data models for ALFIE_CLI."""

from __future__ import annotations

import enum
import time
import uuid
from typing import Any

from pydantic import BaseModel, Field


# ── Enums ─────────────────────────────────────────────────────────────────────


class TaskStatus(str, enum.Enum):
    PENDING = "pending"
    QUEUED = "queued"
    RUNNING = "running"
    COMPLETED = "completed"
    FAILED = "failed"
    TIMEOUT = "timeout"
    SKIPPED = "skipped"


class PaneStatus(str, enum.Enum):
    IDLE = "idle"
    RUNNING = "running"
    ERROR = "error"
    DONE = "done"
    STUCK = "stuck"
    INTERACTIVE = "interactive"
    UNKNOWN = "unknown"


class FailureStrategy(str, enum.Enum):
    RETRY = "retry"
    ESCALATE = "escalate"
    SKIP = "skip"
    ABORT = "abort"


# ── Task Models ───────────────────────────────────────────────────────────────


class RetryPolicy(BaseModel):
    max_attempts: int = 3
    backoff: str = "exponential"  # "fixed" | "linear" | "exponential"
    delay_sec: float = 2.0


class Task(BaseModel):
    id: str = Field(default_factory=lambda: f"t{uuid.uuid4().hex[:8]}")
    cmd: str
    description: str = ""
    depends_on: list[str] = Field(default_factory=list)
    task_type: str = "shell"  # "shell" | "llm_step" | "dynamic"
    input_from: str | None = None
    timeout_sec: int = 300
    retry: RetryPolicy = Field(default_factory=RetryPolicy)
    on_failure: FailureStrategy = FailureStrategy.ESCALATE
    status: TaskStatus = TaskStatus.PENDING
    pane_id: str | None = None
    output: str = ""
    exit_code: int | None = None
    attempt: int = 0
    started_at: float | None = None
    finished_at: float | None = None

    @property
    def duration(self) -> float | None:
        if self.started_at and self.finished_at:
            return self.finished_at - self.started_at
        return None

    @property
    def is_terminal(self) -> bool:
        return self.status in (
            TaskStatus.COMPLETED,
            TaskStatus.FAILED,
            TaskStatus.TIMEOUT,
            TaskStatus.SKIPPED,
        )


class TaskResult(BaseModel):
    task_id: str
    exit_code: int
    output: str
    duration_sec: float
    status: TaskStatus


# ── Plan / Session Models ─────────────────────────────────────────────────────


class SafetyConfig(BaseModel):
    confirm_destructive: bool = True
    max_panes: int = 6
    max_runtime_sec: int = 1800
    max_single_task_sec: int = 300
    max_llm_calls: int = 50
    max_retry_per_task: int = 3
    blocked_patterns: list[str] = Field(default_factory=lambda: [
        r"rm\s+-rf\s+/",
        r":\(\)\s*\{",
        r"dd\s+if=.*/dev/",
        r"mkfs\.",
        r">\s*/dev/sd",
        r"chmod\s+-R\s+777\s+/",
        r"curl.*\|\s*sh",
        r"wget.*\|\s*bash",
    ])


class Plan(BaseModel):
    session_id: str = Field(default_factory=lambda: f"alfie_{int(time.time())}")
    intent: str = ""
    tasks: list[Task] = Field(default_factory=list)
    parallel_groups: list[list[str]] = Field(default_factory=list)
    safety: SafetyConfig = Field(default_factory=SafetyConfig)
    model: str = "gpt-4o-mini"
    created_at: float = Field(default_factory=time.time)


class SessionStatus(str, enum.Enum):
    PLANNING = "planning"
    CONFIRMING = "confirming"
    RUNNING = "running"
    COMPLETED = "completed"
    FAILED = "failed"
    KILLED = "killed"


class Session(BaseModel):
    id: str = Field(default_factory=lambda: f"alfie_{int(time.time())}")
    intent: str = ""
    plan: Plan | None = None
    status: SessionStatus = SessionStatus.PLANNING
    model: str = "gpt-4o-mini"
    started_at: float = Field(default_factory=time.time)
    finished_at: float | None = None
    tmux_session_name: str = ""

    @property
    def duration(self) -> float | None:
        if self.finished_at:
            return self.finished_at - self.started_at
        return None


# ── Pane State ────────────────────────────────────────────────────────────────


class PaneState(BaseModel):
    pane_id: str
    task_id: str | None = None
    status: PaneStatus = PaneStatus.UNKNOWN
    last_output: str = ""
    last_active: float = Field(default_factory=time.time)
    heartbeat_count: int = 0


# ── Event Models ──────────────────────────────────────────────────────────────


class Event(BaseModel):
    event_type: str
    timestamp: float = Field(default_factory=time.time)
    data: dict[str, Any] = Field(default_factory=dict)
