"""ALFIE event bus."""
