"""Event bus — central pub/sub for inter-component communication.

Full implementation in Phase 5.
"""

from __future__ import annotations

import logging
from collections import defaultdict
from typing import Any, Callable

from alfie.models import Event

logger = logging.getLogger("alfie.events")

# Type alias for event handlers
EventHandler = Callable[[Event], None]


class EventBus:
    """Simple in-memory event bus with listeners."""

    def __init__(self) -> None:
        self._handlers: dict[str, list[EventHandler]] = defaultdict(list)
        self._history: list[Event] = []

    def on(self, event_type: str, handler: EventHandler) -> None:
        """Register a handler for an event type."""
        self._handlers[event_type].append(handler)

    def emit(self, event_type: str, data: dict[str, Any] | None = None) -> Event:
        """Emit an event and notify all registered handlers."""
        event = Event(event_type=event_type, data=data or {})
        self._history.append(event)
        logger.debug("Event: %s %s", event_type, data)

        for handler in self._handlers.get(event_type, []):
            handler(event)
        # Wildcard handlers
        for handler in self._handlers.get("*", []):
            handler(event)

        return event

    @property
    def history(self) -> list[Event]:
        return list(self._history)

    def clear(self) -> None:
        self._history.clear()
