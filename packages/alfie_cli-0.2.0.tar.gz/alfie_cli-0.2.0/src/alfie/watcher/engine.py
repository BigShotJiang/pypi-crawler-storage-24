"""Watcher engine — monitors tmux panes and classifies their state.

The Watcher is the nervous system of ALFIE. It continuously polls tmux panes,
classifies their output into states, detects errors/timeouts, and triggers
recovery actions. Emits events to the EventBus for observability.
"""

from __future__ import annotations

import asyncio
import logging
import time
from typing import TYPE_CHECKING, Protocol

from alfie.models import PaneState, PaneStatus

if TYPE_CHECKING:
    from alfie.events.bus import EventBus
    from alfie.tmux.pane import TmuxPane

logger = logging.getLogger("alfie.watcher")

# ── Output classification constants ───────────────────────────────────────────

IDLE_MARKERS = ("$ ", ">>> ", "# ")
ERROR_KEYWORDS = ("error", "traceback", "fatal", "failed", "exception", "killed", "exit 1")
DONE_MARKER = "TASK_COMPLETE"
INTERACTIVE_MARKERS = ("[y/n]", "[y/N]", "password:", "passphrase:", "press any key")


def classify_output(output: str) -> PaneStatus:
    """Classify pane state from its captured output."""
    if not output.strip():
        return PaneStatus.UNKNOWN

    last_line = output.strip().splitlines()[-1].strip().lower()
    output_lower = output.lower()

    if DONE_MARKER.lower() in output_lower:
        return PaneStatus.DONE

    if any(marker in last_line for marker in INTERACTIVE_MARKERS):
        return PaneStatus.INTERACTIVE

    if any(kw in output_lower for kw in ERROR_KEYWORDS):
        return PaneStatus.ERROR

    if any(last_line.endswith(m.strip()) for m in IDLE_MARKERS):
        return PaneStatus.IDLE

    return PaneStatus.RUNNING


# ── Recovery strategies ───────────────────────────────────────────────────────


class RecoveryAction:
    """Describes what the watcher should do when a pane enters a bad state."""

    RETRY = "retry"
    KILL = "kill"
    ESCALATE = "escalate"
    IGNORE = "ignore"


def pick_recovery(status: PaneStatus, attempt: int, max_retries: int) -> str:
    """Decide what recovery action to take based on state + retry count."""
    if status == PaneStatus.ERROR:
        if attempt < max_retries:
            return RecoveryAction.RETRY
        return RecoveryAction.ESCALATE

    if status == PaneStatus.STUCK:
        if attempt < max_retries:
            return RecoveryAction.KILL  # kill and retry
        return RecoveryAction.ESCALATE

    return RecoveryAction.IGNORE


# ── Pane observer callback protocol ──────────────────────────────────────────


class PaneObserver(Protocol):
    """Callback interface for scheduler/coordinator to react to watcher events."""

    def on_task_completed(self, pane_id: str, task_id: str, output: str) -> None: ...
    def on_task_failed(self, pane_id: str, task_id: str, output: str, recovery: str) -> None: ...
    def on_task_stuck(self, pane_id: str, task_id: str, duration: float) -> None: ...
    def on_interactive(self, pane_id: str, task_id: str, prompt_line: str) -> None: ...


class NullObserver:
    """Default no-op observer."""

    def on_task_completed(self, pane_id: str, task_id: str, output: str) -> None:
        pass

    def on_task_failed(self, pane_id: str, task_id: str, output: str, recovery: str) -> None:
        pass

    def on_task_stuck(self, pane_id: str, task_id: str, duration: float) -> None:
        pass

    def on_interactive(self, pane_id: str, task_id: str, prompt_line: str) -> None:
        pass


# ── Watcher Engine ────────────────────────────────────────────────────────────


class WatcherEngine:
    """Polls tmux panes, classifies state, emits events, triggers recovery.

    Usage:
        watcher = WatcherEngine(event_bus=bus, poll_interval=3.0)
        watcher.track(pane, task_id="t1", timeout_sec=300)
        await watcher.start()   # runs until stopped
        watcher.stop()
    """

    def __init__(
        self,
        event_bus: EventBus | None = None,
        observer: PaneObserver | None = None,
        poll_interval: float = 3.0,
        default_timeout: float = 300.0,
        max_retries: int = 3,
    ) -> None:
        self._event_bus = event_bus
        self._observer: PaneObserver = observer or NullObserver()
        self._poll_interval = poll_interval
        self._default_timeout = default_timeout
        self._max_retries = max_retries
        self._running = False

        # pane_id → tracked pane info
        self._tracked: dict[str, _TrackedPane] = {}

    # ── Tracking ──────────────────────────────────────────────────────────

    def track(
        self,
        pane: TmuxPane,
        task_id: str,
        timeout_sec: float | None = None,
        retry_cmd: str | None = None,
    ) -> None:
        """Start watching a pane. Call before starting the poll loop or during."""
        self._tracked[pane.pane_id] = _TrackedPane(
            pane=pane,
            task_id=task_id,
            timeout_sec=timeout_sec or self._default_timeout,
            retry_cmd=retry_cmd,
            state=PaneState(pane_id=pane.pane_id, task_id=task_id),
        )
        logger.info("Tracking pane %s for task %s", pane.pane_id, task_id)
        self._emit("watcher.tracking", {"pane_id": pane.pane_id, "task_id": task_id})

    def untrack(self, pane_id: str) -> None:
        """Stop watching a pane."""
        self._tracked.pop(pane_id, None)
        logger.info("Untracked pane %s", pane_id)

    @property
    def tracked_panes(self) -> dict[str, PaneState]:
        """Snapshot of all tracked pane states."""
        return {pid: tp.state.model_copy() for pid, tp in self._tracked.items()}

    @property
    def is_running(self) -> bool:
        return self._running

    # ── Main loop ─────────────────────────────────────────────────────────

    async def start(self) -> None:
        """Start the watcher poll loop. Runs until stop() is called."""
        self._running = True
        logger.info("Watcher started (poll=%.1fs)", self._poll_interval)
        self._emit("watcher.started", {"poll_interval": self._poll_interval})

        while self._running:
            self._poll_all()
            await asyncio.sleep(self._poll_interval)

        logger.info("Watcher stopped")
        self._emit("watcher.stopped", {})

    def stop(self) -> None:
        """Signal the watcher to stop after the current poll cycle."""
        self._running = False

    def poll_once(self) -> dict[str, PaneState]:
        """Run a single poll cycle (useful for testing and sync usage)."""
        self._poll_all()
        return self.tracked_panes

    # ── Internal poll logic ───────────────────────────────────────────────

    def _poll_all(self) -> None:
        """Poll every tracked pane once."""
        for pane_id in list(self._tracked):
            tp = self._tracked.get(pane_id)
            if tp is None:
                continue
            self._poll_one(tp)

    def _poll_one(self, tp: _TrackedPane) -> None:
        """Poll a single tracked pane and react to its state."""
        try:
            output = tp.pane.capture()
        except Exception:
            logger.warning("Failed to capture pane %s — may be dead", tp.pane.pane_id)
            tp.state.status = PaneStatus.ERROR
            self._handle_error(tp, "Pane capture failed — pane may be dead")
            return

        prev_status = tp.state.status
        new_status = classify_output(output)

        tp.state.last_output = output
        tp.state.status = new_status

        # Detect stuck: status is RUNNING but no output change for > timeout
        if new_status == PaneStatus.RUNNING:
            if output != tp.last_captured_output:
                tp.state.last_active = time.time()
                tp.state.heartbeat_count += 1
            else:
                idle_duration = time.time() - tp.state.last_active
                if idle_duration > tp.timeout_sec:
                    new_status = PaneStatus.STUCK
                    tp.state.status = PaneStatus.STUCK
            tp.last_captured_output = output

        # Only act on state transitions
        if new_status == prev_status:
            return

        logger.info(
            "Pane %s [task %s]: %s → %s",
            tp.pane.pane_id, tp.task_id, prev_status.value, new_status.value,
        )
        self._emit("watcher.state_change", {
            "pane_id": tp.pane.pane_id,
            "task_id": tp.task_id,
            "old_status": prev_status.value,
            "new_status": new_status.value,
        })

        # React to state
        match new_status:
            case PaneStatus.DONE:
                self._handle_done(tp, output)
            case PaneStatus.IDLE:
                self._handle_idle(tp, output)
            case PaneStatus.ERROR:
                self._handle_error(tp, output)
            case PaneStatus.STUCK:
                self._handle_stuck(tp)
            case PaneStatus.INTERACTIVE:
                self._handle_interactive(tp, output)
            case _:
                pass  # RUNNING, UNKNOWN — no action needed

    # ── State handlers ────────────────────────────────────────────────────

    def _handle_done(self, tp: _TrackedPane, output: str) -> None:
        logger.info("Pane %s: task %s completed", tp.pane.pane_id, tp.task_id)
        self._emit("task.completed", {
            "pane_id": tp.pane.pane_id,
            "task_id": tp.task_id,
            "output_tail": output[-500:] if len(output) > 500 else output,
        })
        self._observer.on_task_completed(tp.pane.pane_id, tp.task_id, output)

    def _handle_idle(self, tp: _TrackedPane, output: str) -> None:
        # If pane goes idle but we didn't see DONE_MARKER, the task
        # likely finished (command returned to prompt). Treat as complete.
        logger.info("Pane %s: task %s went idle (implicit completion)", tp.pane.pane_id, tp.task_id)
        self._emit("task.completed", {
            "pane_id": tp.pane.pane_id,
            "task_id": tp.task_id,
            "output_tail": output[-500:] if len(output) > 500 else output,
            "implicit": True,
        })
        self._observer.on_task_completed(tp.pane.pane_id, tp.task_id, output)

    def _handle_error(self, tp: _TrackedPane, output: str) -> None:
        tp.attempt += 1
        recovery = pick_recovery(PaneStatus.ERROR, tp.attempt, self._max_retries)

        logger.warning(
            "Pane %s: task %s ERROR (attempt %d/%d) → %s",
            tp.pane.pane_id, tp.task_id, tp.attempt, self._max_retries, recovery,
        )
        self._emit("task.failed", {
            "pane_id": tp.pane.pane_id,
            "task_id": tp.task_id,
            "attempt": tp.attempt,
            "recovery": recovery,
            "output_tail": output[-500:] if isinstance(output, str) and len(output) > 500 else output,
        })

        if recovery == RecoveryAction.RETRY and tp.retry_cmd:
            logger.info("Pane %s: retrying with: %s", tp.pane.pane_id, tp.retry_cmd)
            self._emit("task.retrying", {
                "pane_id": tp.pane.pane_id,
                "task_id": tp.task_id,
                "attempt": tp.attempt,
                "cmd": tp.retry_cmd,
            })
            try:
                tp.pane.send_ctrl_c()
                tp.pane.send(tp.retry_cmd)
                tp.state.status = PaneStatus.RUNNING
                tp.state.last_active = time.time()
            except Exception:
                logger.error("Retry send failed for pane %s", tp.pane.pane_id)

        self._observer.on_task_failed(tp.pane.pane_id, tp.task_id, str(output), recovery)

    def _handle_stuck(self, tp: _TrackedPane) -> None:
        stuck_duration = time.time() - tp.state.last_active
        tp.attempt += 1
        recovery = pick_recovery(PaneStatus.STUCK, tp.attempt, self._max_retries)

        logger.warning(
            "Pane %s: task %s STUCK for %.0fs (attempt %d/%d) → %s",
            tp.pane.pane_id, tp.task_id, stuck_duration,
            tp.attempt, self._max_retries, recovery,
        )
        self._emit("watcher.stuck", {
            "pane_id": tp.pane.pane_id,
            "task_id": tp.task_id,
            "stuck_sec": round(stuck_duration),
            "recovery": recovery,
        })

        if recovery == RecoveryAction.KILL and tp.retry_cmd:
            try:
                tp.pane.send_ctrl_c()
                tp.pane.send(tp.retry_cmd)
                tp.state.status = PaneStatus.RUNNING
                tp.state.last_active = time.time()
            except Exception:
                logger.error("Kill+retry failed for pane %s", tp.pane.pane_id)

        self._observer.on_task_stuck(tp.pane.pane_id, tp.task_id, stuck_duration)

    def _handle_interactive(self, tp: _TrackedPane, output: str) -> None:
        last_line = output.strip().splitlines()[-1] if output.strip() else ""
        logger.info("Pane %s: interactive prompt detected: %s", tp.pane.pane_id, last_line)
        self._emit("watcher.interactive", {
            "pane_id": tp.pane.pane_id,
            "task_id": tp.task_id,
            "prompt": last_line,
        })
        self._observer.on_interactive(tp.pane.pane_id, tp.task_id, last_line)

    # ── Event emission helper ─────────────────────────────────────────────

    def _emit(self, event_type: str, data: dict) -> None:
        if self._event_bus:
            self._event_bus.emit(event_type, data)


# ── Internal tracking dataclass ───────────────────────────────────────────────


class _TrackedPane:
    """Internal bookkeeping for a pane being watched."""

    __slots__ = (
        "pane", "task_id", "timeout_sec", "retry_cmd",
        "state", "attempt", "last_captured_output",
    )

    def __init__(
        self,
        pane: TmuxPane,
        task_id: str,
        timeout_sec: float,
        retry_cmd: str | None,
        state: PaneState,
    ) -> None:
        self.pane = pane
        self.task_id = task_id
        self.timeout_sec = timeout_sec
        self.retry_cmd = retry_cmd
        self.state = state
        self.attempt = 0
        self.last_captured_output = ""
