"""Tests for alfie.memory — MemoryStore and chat prompts."""

from __future__ import annotations

import json
from pathlib import Path

import pytest

from alfie.memory.store import MemoryStore


class TestMemoryStore:
    """Unit tests for the MemoryStore."""

    def test_create_new_session(self, tmp_path: Path):
        mem = MemoryStore(memory_dir=tmp_path)
        assert mem.session_id  # auto-generated
        assert mem.turn_count == 0
        assert mem.messages == []

    def test_create_with_custom_id(self, tmp_path: Path):
        mem = MemoryStore(session_id="test123", memory_dir=tmp_path)
        assert mem.session_id == "test123"

    def test_add_messages(self, tmp_path: Path):
        mem = MemoryStore(session_id="s1", memory_dir=tmp_path)
        mem.add("user", "Hello")
        mem.add("assistant", "Hi there!")
        assert mem.turn_count == 1
        assert len(mem.messages) == 2
        assert mem.messages[0] == {"role": "user", "content": "Hello"}
        assert mem.messages[1] == {"role": "assistant", "content": "Hi there!"}

    def test_persistence(self, tmp_path: Path):
        # Write
        mem1 = MemoryStore(session_id="persist", memory_dir=tmp_path)
        mem1.add("user", "Remember this")
        mem1.add("assistant", "I will remember")

        # Read back from disk
        mem2 = MemoryStore(session_id="persist", memory_dir=tmp_path)
        assert mem2.turn_count == 1
        assert len(mem2.messages) == 2
        assert mem2.messages[0]["content"] == "Remember this"

    def test_file_format(self, tmp_path: Path):
        mem = MemoryStore(session_id="fmt", memory_dir=tmp_path)
        mem.add("user", "test")

        raw = json.loads((tmp_path / "fmt.json").read_text(encoding="utf-8"))
        assert "metadata" in raw
        assert "messages" in raw
        assert raw["metadata"]["session_id"] == "fmt"
        assert len(raw["messages"]) == 1

    def test_get_context_messages_without_system(self, tmp_path: Path):
        mem = MemoryStore(session_id="ctx", memory_dir=tmp_path)
        mem.add("user", "Q1")
        mem.add("assistant", "A1")

        msgs = mem.get_context_messages()
        assert len(msgs) == 2
        assert msgs[0]["role"] == "user"

    def test_get_context_messages_with_system(self, tmp_path: Path):
        mem = MemoryStore(session_id="ctx2", memory_dir=tmp_path)
        mem.add("user", "Q1")

        msgs = mem.get_context_messages(system_prompt="You are ALFIE")
        assert len(msgs) == 2
        assert msgs[0] == {"role": "system", "content": "You are ALFIE"}
        assert msgs[1]["role"] == "user"

    def test_clear(self, tmp_path: Path):
        mem = MemoryStore(session_id="clr", memory_dir=tmp_path)
        mem.add("user", "Hello")
        mem.add("assistant", "Hi")
        assert mem.turn_count == 1

        mem.clear()
        assert mem.turn_count == 0
        assert mem.messages == []

        # Verify it's cleared on disk too
        mem2 = MemoryStore(session_id="clr", memory_dir=tmp_path)
        assert mem2.turn_count == 0

    def test_trim_old_messages(self, tmp_path: Path):
        mem = MemoryStore(session_id="trim", memory_dir=tmp_path, max_turns=3)
        for i in range(5):
            mem.add("user", f"Question {i}")
            mem.add("assistant", f"Answer {i}")

        # Should keep only last 3 turns (6 messages)
        assert mem.turn_count == 3
        assert len(mem.messages) == 6
        # First kept message should be Question 2
        assert mem.messages[0]["content"] == "Question 2"

    def test_set_model(self, tmp_path: Path):
        mem = MemoryStore(session_id="mdl", memory_dir=tmp_path)
        mem.set_model("gpt-4o-mini")

        # Reload and check
        mem2 = MemoryStore(session_id="mdl", memory_dir=tmp_path)
        assert mem2._metadata["model"] == "gpt-4o-mini"

    def test_list_sessions(self, tmp_path: Path):
        for name in ["session_a", "session_b", "session_c"]:
            m = MemoryStore(session_id=name, memory_dir=tmp_path)
            m.add("user", f"Hello from {name}")

        mem = MemoryStore(memory_dir=tmp_path)
        sessions = mem.list_sessions()
        assert len(sessions) >= 3
        session_ids = {s["session_id"] for s in sessions}
        assert "session_a" in session_ids
        assert "session_b" in session_ids
        assert "session_c" in session_ids

    def test_delete_session(self, tmp_path: Path):
        mem = MemoryStore(session_id="del_me", memory_dir=tmp_path)
        mem.add("user", "bye")
        assert (tmp_path / "del_me.json").exists()

        mem.delete()
        assert not (tmp_path / "del_me.json").exists()
        assert mem.messages == []

    def test_multi_turn_conversation(self, tmp_path: Path):
        mem = MemoryStore(session_id="multi", memory_dir=tmp_path)

        mem.add("user", "What is 2+2?")
        mem.add("assistant", "4")
        mem.add("user", "And 3+3?")
        mem.add("assistant", "6")
        mem.add("user", "What about 10+10?")
        mem.add("assistant", "20")

        assert mem.turn_count == 3
        assert len(mem.messages) == 6

        # Full context should have all messages
        ctx = mem.get_context_messages(system_prompt="Math tutor")
        assert len(ctx) == 7  # 1 system + 6 conversation
        assert ctx[0]["role"] == "system"
        assert ctx[-1]["content"] == "20"


class TestChatPrompt:
    """Tests for the chat system prompt."""

    def test_prompt_mentions_alfie(self):
        from alfie.memory.prompts import CHAT_SYSTEM_PROMPT
        assert "ALFIE" in CHAT_SYSTEM_PROMPT

    def test_prompt_includes_os_info(self):
        import platform
        from alfie.memory.prompts import CHAT_SYSTEM_PROMPT
        assert platform.system() in CHAT_SYSTEM_PROMPT

    def test_prompt_mentions_tools(self):
        from alfie.memory.prompts import CHAT_SYSTEM_PROMPT
        assert "tools" in CHAT_SYSTEM_PROMPT.lower() or "run_shell" in CHAT_SYSTEM_PROMPT

    def test_prompt_mentions_commands(self):
        from alfie.memory.prompts import CHAT_SYSTEM_PROMPT
        # Should mention either PowerShell or bash
        assert "PowerShell" in CHAT_SYSTEM_PROMPT or "bash" in CHAT_SYSTEM_PROMPT
