"""Tests for DAG scheduler."""

import time

import pytest

from alfie.events.bus import EventBus
from alfie.models import (
    FailureStrategy,
    Plan,
    RetryPolicy,
    Session,
    Task,
    TaskStatus,
)
from alfie.scheduler.dag import PanePool, TaskScheduler, topological_sort


# ── Shared test helpers ───────────────────────────────────────────────────────


class MockPane:
    """Fake TmuxPane for scheduler tests."""

    def __init__(self, pane_id: str = "%0"):
        self.pane_id = pane_id
        self._sent: list[str] = []

    def send(self, cmd: str, press_enter: bool = True) -> None:
        self._sent.append(cmd)

    def capture(self, lines: int = 50) -> str:
        return ""

    def send_ctrl_c(self) -> None:
        pass

    def kill(self) -> None:
        pass

    def is_alive(self) -> bool:
        return True


def _make_plan(tasks: list[Task]) -> Plan:
    return Plan(session_id="test-session", tasks=tasks, intent="test")


def _make_pool(pane_ids: list[str] | None = None) -> PanePool:
    pool = PanePool(max_panes=4)
    for pid in (pane_ids or ["%0", "%1", "%2", "%3"]):
        pool.add_pane(MockPane(pid))
    return pool


def _make_scheduler(
    tasks: list[Task],
    pool: PanePool | None = None,
    bus: EventBus | None = None,
) -> TaskScheduler:
    plan = _make_plan(tasks)
    session = Session(id="test-session", intent="test")
    return TaskScheduler(
        plan=plan,
        session=session,
        pane_pool=pool or _make_pool(),
        event_bus=bus,
    )


# ═══════════════════════════════════════════════════════════════════════════════
# Topological Sort
# ═══════════════════════════════════════════════════════════════════════════════


class TestTopologicalSort:

    def test_single_task(self):
        tasks = [Task(id="t1", cmd="echo hello")]
        layers = topological_sort(tasks)
        assert layers == [["t1"]]

    def test_independent_tasks_same_layer(self):
        tasks = [
            Task(id="t1", cmd="echo a"),
            Task(id="t2", cmd="echo b"),
            Task(id="t3", cmd="echo c"),
        ]
        layers = topological_sort(tasks)
        assert len(layers) == 1
        assert sorted(layers[0]) == ["t1", "t2", "t3"]

    def test_linear_chain(self):
        tasks = [
            Task(id="t1", cmd="echo first"),
            Task(id="t2", cmd="echo second", depends_on=["t1"]),
            Task(id="t3", cmd="echo third", depends_on=["t2"]),
        ]
        layers = topological_sort(tasks)
        assert layers == [["t1"], ["t2"], ["t3"]]

    def test_diamond_dependency(self):
        tasks = [
            Task(id="t1", cmd="start"),
            Task(id="t2", cmd="left", depends_on=["t1"]),
            Task(id="t3", cmd="right", depends_on=["t1"]),
            Task(id="t4", cmd="join", depends_on=["t2", "t3"]),
        ]
        layers = topological_sort(tasks)
        assert layers[0] == ["t1"]
        assert sorted(layers[1]) == ["t2", "t3"]
        assert layers[2] == ["t4"]

    def test_cycle_raises(self):
        tasks = [
            Task(id="t1", cmd="a", depends_on=["t2"]),
            Task(id="t2", cmd="b", depends_on=["t1"]),
        ]
        with pytest.raises(ValueError, match="Cycle"):
            topological_sort(tasks)

    def test_complex_dag(self):
        tasks = [
            Task(id="t1", cmd="a"),
            Task(id="t2", cmd="b"),
            Task(id="t3", cmd="c", depends_on=["t1"]),
            Task(id="t4", cmd="d", depends_on=["t1", "t2"]),
            Task(id="t5", cmd="e", depends_on=["t3", "t4"]),
        ]
        layers = topological_sort(tasks)
        assert layers[0] == ["t1", "t2"]
        assert sorted(layers[1]) == ["t3", "t4"]
        assert layers[2] == ["t5"]


# ═══════════════════════════════════════════════════════════════════════════════
# PanePool
# ═══════════════════════════════════════════════════════════════════════════════


class TestPanePool:

    def test_add_and_acquire(self):
        pool = PanePool(max_panes=2)
        p0 = MockPane("%0")
        pool.add_pane(p0)

        assert pool.available == 1
        assert pool.busy_count == 0

        pane = pool.acquire("t1")
        assert pane is p0
        assert pool.available == 0
        assert pool.busy_count == 1

    def test_acquire_returns_none_when_empty(self):
        pool = PanePool()
        assert pool.acquire("t1") is None

    def test_release_returns_pane_to_free(self):
        pool = PanePool()
        pool.add_pane(MockPane("%0"))
        pool.acquire("t1")

        released = pool.release("t1")
        assert released is not None
        assert pool.available == 1
        assert pool.busy_count == 0

    def test_release_unknown_task_returns_none(self):
        pool = PanePool()
        assert pool.release("unknown") is None

    def test_get_pane_for_active_task(self):
        pool = PanePool()
        p = MockPane("%0")
        pool.add_pane(p)
        pool.acquire("t1")
        assert pool.get_pane("t1") is p
        assert pool.get_pane("t2") is None

    def test_release_all(self):
        pool = PanePool()
        pool.add_pane(MockPane("%0"))
        pool.add_pane(MockPane("%1"))
        pool.acquire("t1")
        pool.acquire("t2")

        assert pool.busy_count == 2
        pool.release_all()
        assert pool.busy_count == 0
        assert pool.available == 2

    def test_total_property(self):
        pool = PanePool()
        pool.add_pane(MockPane("%0"))
        pool.add_pane(MockPane("%1"))
        pool.acquire("t1")
        assert pool.total == 2

    def test_fifo_ordering(self):
        """Panes are acquired in FIFO order."""
        pool = PanePool()
        p0, p1 = MockPane("%0"), MockPane("%1")
        pool.add_pane(p0)
        pool.add_pane(p1)
        assert pool.acquire("t1") is p0
        assert pool.acquire("t2") is p1


# ═══════════════════════════════════════════════════════════════════════════════
# TaskScheduler — queue_ready_tasks
# ═══════════════════════════════════════════════════════════════════════════════


class TestQueueReadyTasks:

    def test_roots_get_queued(self):
        tasks = [
            Task(id="t1", cmd="echo a"),
            Task(id="t2", cmd="echo b"),
            Task(id="t3", cmd="echo c", depends_on=["t1"]),
        ]
        sched = _make_scheduler(tasks)
        queued = sched.queue_ready_tasks()

        assert sorted(queued) == ["t1", "t2"]
        assert sched.task_map["t1"].status == TaskStatus.QUEUED
        assert sched.task_map["t2"].status == TaskStatus.QUEUED
        assert sched.task_map["t3"].status == TaskStatus.PENDING

    def test_no_double_queue(self):
        tasks = [Task(id="t1", cmd="echo a")]
        sched = _make_scheduler(tasks)
        sched.queue_ready_tasks()
        second = sched.queue_ready_tasks()
        assert second == []

    def test_dependent_queued_after_dep_completes(self):
        tasks = [
            Task(id="t1", cmd="echo a"),
            Task(id="t2", cmd="echo b", depends_on=["t1"]),
        ]
        sched = _make_scheduler(tasks)
        sched.queue_ready_tasks()

        # Simulate t1 completing
        sched.task_map["t1"].status = TaskStatus.COMPLETED
        queued = sched.queue_ready_tasks()
        assert queued == ["t2"]

    def test_dependent_not_queued_if_dep_still_running(self):
        tasks = [
            Task(id="t1", cmd="echo a"),
            Task(id="t2", cmd="echo b", depends_on=["t1"]),
        ]
        sched = _make_scheduler(tasks)
        sched.queue_ready_tasks()
        sched.task_map["t1"].status = TaskStatus.RUNNING
        queued = sched.queue_ready_tasks()
        assert queued == []


# ═══════════════════════════════════════════════════════════════════════════════
# TaskScheduler — assign_tasks
# ═══════════════════════════════════════════════════════════════════════════════


class TestAssignTasks:

    def test_assign_to_free_pane(self):
        tasks = [Task(id="t1", cmd="echo hello")]
        sched = _make_scheduler(tasks)
        sched.queue_ready_tasks()
        assignments = sched.assign_tasks()

        assert len(assignments) == 1
        task_id, pane_id = assignments[0]
        assert task_id == "t1"
        assert sched.task_map["t1"].status == TaskStatus.RUNNING
        assert sched.task_map["t1"].attempt == 1

    def test_no_assign_when_pool_empty(self):
        tasks = [Task(id="t1", cmd="echo a"), Task(id="t2", cmd="echo b")]
        pool = _make_pool(["%0"])  # only 1 pane
        sched = _make_scheduler(tasks, pool=pool)
        sched.queue_ready_tasks()
        assignments = sched.assign_tasks()

        assert len(assignments) == 1
        # Second task stays queued
        queued_count = sum(1 for t in sched.task_map.values() if t.status == TaskStatus.QUEUED)
        assert queued_count == 1

    def test_safety_blocks_dangerous_command(self):
        tasks = [Task(id="t1", cmd="rm -rf /")]
        sched = _make_scheduler(tasks)
        sched.queue_ready_tasks()
        assignments = sched.assign_tasks()

        assert assignments == []
        assert sched.task_map["t1"].status == TaskStatus.SKIPPED
        assert "safety" in sched.task_map["t1"].output.lower()

    def test_started_at_set_on_assign(self):
        tasks = [Task(id="t1", cmd="echo hello")]
        sched = _make_scheduler(tasks)
        before = time.time()
        sched.queue_ready_tasks()
        sched.assign_tasks()
        assert sched.task_map["t1"].started_at is not None
        assert sched.task_map["t1"].started_at >= before


# ═══════════════════════════════════════════════════════════════════════════════
# TaskScheduler — send_commands
# ═══════════════════════════════════════════════════════════════════════════════


class TestSendCommands:

    def test_sends_sentinel_command(self):
        tasks = [Task(id="t1", cmd="echo hello")]
        pool = _make_pool(["%0"])
        sched = _make_scheduler(tasks, pool=pool)
        sched.queue_ready_tasks()
        assignments = sched.assign_tasks()
        sched.send_commands(assignments)

        pane = pool.get_pane("t1")
        assert len(pane._sent) == 1
        assert "echo hello" in pane._sent[0]
        assert "TASK_COMPLETE" in pane._sent[0]
        assert "TASK_FAILED" in pane._sent[0]


# ═══════════════════════════════════════════════════════════════════════════════
# TaskScheduler — watcher callbacks
# ═══════════════════════════════════════════════════════════════════════════════


class TestOnTaskCompleted:

    def test_marks_task_completed(self):
        tasks = [Task(id="t1", cmd="echo hello")]
        sched = _make_scheduler(tasks)
        sched.queue_ready_tasks()
        sched.assign_tasks()

        sched.on_task_completed("%0", "t1", "hello")

        assert sched.task_map["t1"].status == TaskStatus.COMPLETED
        assert sched.task_map["t1"].finished_at is not None
        assert "t1" in sched.results
        assert sched.results["t1"].exit_code == 0

    def test_releases_pane_on_complete(self):
        tasks = [Task(id="t1", cmd="echo hello")]
        pool = _make_pool(["%0"])
        sched = _make_scheduler(tasks, pool=pool)
        sched.queue_ready_tasks()
        sched.assign_tasks()

        assert pool.busy_count == 1
        sched.on_task_completed("%0", "t1", "hello")
        assert pool.busy_count == 0
        assert pool.available == 1

    def test_queues_dependents_on_complete(self):
        tasks = [
            Task(id="t1", cmd="echo a"),
            Task(id="t2", cmd="echo b", depends_on=["t1"]),
        ]
        sched = _make_scheduler(tasks)
        sched.queue_ready_tasks()
        sched.assign_tasks()

        sched.on_task_completed("%0", "t1", "done")
        assert sched.task_map["t2"].status == TaskStatus.QUEUED

    def test_emits_events_on_complete(self):
        bus = EventBus()
        tasks = [Task(id="t1", cmd="echo hello")]
        sched = _make_scheduler(tasks, bus=bus)
        sched.queue_ready_tasks()
        sched.assign_tasks()
        sched.on_task_completed("%0", "t1", "hello")

        event_types = [e.event_type for e in bus.history]
        assert "task.completed" in event_types

    def test_ignores_already_terminal_task(self):
        tasks = [Task(id="t1", cmd="echo hello")]
        sched = _make_scheduler(tasks)
        sched.task_map["t1"].status = TaskStatus.FAILED
        # Should not raise or change status
        sched.on_task_completed("%0", "t1", "hello")
        assert sched.task_map["t1"].status == TaskStatus.FAILED

    def test_output_truncated_to_2000(self):
        tasks = [Task(id="t1", cmd="echo hello")]
        sched = _make_scheduler(tasks)
        sched.queue_ready_tasks()
        sched.assign_tasks()
        sched.on_task_completed("%0", "t1", "x" * 5000)
        assert len(sched.task_map["t1"].output) == 2000


class TestOnTaskFailed:

    def test_marks_task_failed(self):
        tasks = [Task(id="t1", cmd="bad_cmd", retry=RetryPolicy(max_attempts=1))]
        sched = _make_scheduler(tasks)
        sched.queue_ready_tasks()
        sched.assign_tasks()

        sched.on_task_failed("%0", "t1", "command not found", "none")

        assert sched.task_map["t1"].status == TaskStatus.FAILED
        assert "t1" in sched.results
        assert sched.results["t1"].exit_code == 1

    def test_retry_keeps_running(self):
        tasks = [Task(id="t1", cmd="flaky", retry=RetryPolicy(max_attempts=3))]
        sched = _make_scheduler(tasks)
        sched.queue_ready_tasks()
        sched.assign_tasks()

        # First failure with retry recovery — attempt is 1, max is 3
        sched.on_task_failed("%0", "t1", "error", "retry")
        assert sched.task_map["t1"].status == TaskStatus.RUNNING  # still running

    def test_abort_strategy_kills_all(self):
        tasks = [
            Task(id="t1", cmd="fail", on_failure=FailureStrategy.ABORT, retry=RetryPolicy(max_attempts=1)),
            Task(id="t2", cmd="echo ok"),
        ]
        sched = _make_scheduler(tasks)
        sched.queue_ready_tasks()
        sched.assign_tasks()

        sched.on_task_failed("%0", "t1", "error", "none")
        assert sched.task_map["t2"].status == TaskStatus.SKIPPED

    def test_skip_strategy_skips_direct_dependents(self):
        tasks = [
            Task(id="t1", cmd="fail", on_failure=FailureStrategy.SKIP, retry=RetryPolicy(max_attempts=1)),
            Task(id="t2", cmd="echo dep", depends_on=["t1"]),
            Task(id="t3", cmd="echo independent"),
        ]
        sched = _make_scheduler(tasks)
        sched.queue_ready_tasks()
        sched.assign_tasks()

        sched.on_task_failed("%0", "t1", "error", "none")
        assert sched.task_map["t2"].status == TaskStatus.SKIPPED
        # t3 should still be queued (was already queued as root), not skipped
        assert sched.task_map["t3"].status in (TaskStatus.QUEUED, TaskStatus.RUNNING)

    def test_escalate_skips_unreachable(self):
        tasks = [
            Task(id="t1", cmd="fail", on_failure=FailureStrategy.ESCALATE, retry=RetryPolicy(max_attempts=1)),
            Task(id="t2", cmd="echo dep", depends_on=["t1"]),
            Task(id="t3", cmd="echo free"),
        ]
        sched = _make_scheduler(tasks)
        sched.queue_ready_tasks()
        sched.assign_tasks()

        sched.on_task_failed("%0", "t1", "error", "none")
        assert sched.task_map["t2"].status == TaskStatus.SKIPPED
        # t3 is independent, should still be runnable
        assert sched.task_map["t3"].status in (TaskStatus.QUEUED, TaskStatus.RUNNING)


class TestOnTaskStuck:

    def test_timeout_after_retries_exhausted(self):
        tasks = [Task(id="t1", cmd="hang", retry=RetryPolicy(max_attempts=1))]
        sched = _make_scheduler(tasks)
        sched.queue_ready_tasks()
        sched.assign_tasks()

        sched.on_task_stuck("%0", "t1", 999.0)
        assert sched.task_map["t1"].status == TaskStatus.TIMEOUT
        assert sched.results["t1"].exit_code == -1

    def test_stuck_with_retries_remaining_keeps_running(self):
        tasks = [Task(id="t1", cmd="slow", retry=RetryPolicy(max_attempts=3))]
        sched = _make_scheduler(tasks)
        sched.queue_ready_tasks()
        sched.assign_tasks()

        # attempt is 1, max is 3 — watcher should handle retry
        sched.on_task_stuck("%0", "t1", 120.0)
        assert sched.task_map["t1"].status == TaskStatus.RUNNING


class TestOnInteractive:

    def test_emits_event(self):
        bus = EventBus()
        tasks = [Task(id="t1", cmd="ssh host")]
        sched = _make_scheduler(tasks, bus=bus)
        sched.on_interactive("%0", "t1", "password:")

        event_types = [e.event_type for e in bus.history]
        assert "watcher.interactive" in event_types


# ═══════════════════════════════════════════════════════════════════════════════
# TaskScheduler — properties / summary
# ═══════════════════════════════════════════════════════════════════════════════


class TestSchedulerProperties:

    def test_is_complete_when_all_terminal(self):
        tasks = [Task(id="t1", cmd="echo a")]
        sched = _make_scheduler(tasks)
        assert not sched.is_complete
        sched.task_map["t1"].status = TaskStatus.COMPLETED
        assert sched.is_complete

    def test_is_complete_mixed_terminal(self):
        tasks = [Task(id="t1", cmd="a"), Task(id="t2", cmd="b")]
        sched = _make_scheduler(tasks)
        sched.task_map["t1"].status = TaskStatus.COMPLETED
        sched.task_map["t2"].status = TaskStatus.SKIPPED
        assert sched.is_complete

    def test_summary_counts(self):
        tasks = [
            Task(id="t1", cmd="a"),
            Task(id="t2", cmd="b"),
            Task(id="t3", cmd="c"),
        ]
        sched = _make_scheduler(tasks)
        sched.task_map["t1"].status = TaskStatus.COMPLETED
        sched.task_map["t2"].status = TaskStatus.FAILED
        summary = sched.summary
        assert summary["completed"] == 1
        assert summary["failed"] == 1
        assert summary["pending"] == 1


# ═══════════════════════════════════════════════════════════════════════════════
# TaskScheduler — run_sync (integration)
# ═══════════════════════════════════════════════════════════════════════════════


class TestRunSync:

    def test_single_task_lifecycle(self):
        """complete a single task from pending → completed via run_sync"""
        tasks = [Task(id="t1", cmd="echo hello")]
        pool = _make_pool(["%0"])
        sched = _make_scheduler(tasks, pool=pool)

        # Manually queue → assign → complete to validate run_sync behavior
        sched.queue_ready_tasks()
        sched.assign_tasks()
        sched.on_task_completed("%0", "t1", "hello")

        assert sched.is_complete
        assert sched.task_map["t1"].status == TaskStatus.COMPLETED

    def test_deadlock_detection(self):
        """run_sync should abort on deadlock (circular-like blocked state)."""
        tasks = [
            Task(id="t1", cmd="echo a"),
            Task(id="t2", cmd="echo b", depends_on=["t1"]),
        ]
        sched = _make_scheduler(tasks)

        # Fail t1 with escalate strategy so t2 becomes skipped
        sched.queue_ready_tasks()
        sched.assign_tasks()

        # Mark t1 failed manually (simulating without watcher)
        sched.task_map["t1"].status = TaskStatus.FAILED
        sched.task_map["t1"].finished_at = time.time()
        sched._pool.release("t1")
        sched._skip_unreachable()

        # Now t2 should be skipped
        assert sched.task_map["t2"].status == TaskStatus.SKIPPED

    def test_diamond_dag_execution(self):
        """Exercise all layers of a diamond: root → parallels → join."""
        tasks = [
            Task(id="root", cmd="echo start"),
            Task(id="left", cmd="echo left", depends_on=["root"]),
            Task(id="right", cmd="echo right", depends_on=["root"]),
            Task(id="join", cmd="echo done", depends_on=["left", "right"]),
        ]
        bus = EventBus()
        sched = _make_scheduler(tasks, bus=bus)

        # Layer 0: root
        sched.queue_ready_tasks()
        sched.assign_tasks()
        sched.on_task_completed("%0", "root", "start")

        # Layer 1: left + right should be queued
        assert sched.task_map["left"].status == TaskStatus.QUEUED
        assert sched.task_map["right"].status == TaskStatus.QUEUED

        assignments = sched.assign_tasks()
        assert len(assignments) == 2

        sched.on_task_completed("%1", "left", "left")
        sched.on_task_completed("%2", "right", "right")

        # Layer 2: join
        assert sched.task_map["join"].status == TaskStatus.QUEUED
        sched.assign_tasks()
        sched.on_task_completed("%0", "join", "done")

        assert sched.is_complete
        assert all(t.status == TaskStatus.COMPLETED for t in sched.task_map.values())

        # Verify events were emitted
        completed_events = [e for e in bus.history if e.event_type == "task.completed"]
        assert len(completed_events) == 4

    def test_event_bus_records_all_transitions(self):
        tasks = [Task(id="t1", cmd="echo hello")]
        bus = EventBus()
        sched = _make_scheduler(tasks, bus=bus)

        sched.queue_ready_tasks()
        sched.assign_tasks()
        sched.on_task_completed("%0", "t1", "hello")

        event_types = [e.event_type for e in bus.history]
        assert "task.queued" in event_types
        assert "task.started" in event_types
        assert "task.completed" in event_types
