"""Tests for the LLM planner — client, prompts, and planner engine.

All LLM calls are mocked to avoid requiring an API key for tests.
"""

import json
import os
from unittest.mock import MagicMock, patch

import pytest

from alfie.config import AIGatewayConfig
from alfie.models import FailureStrategy, Plan, Task, TaskStatus
from alfie.planner.base import PLAN_SCHEMA, SYSTEM_PROMPT, build_user_message
from alfie.planner.planner import Planner, PlannerError


# ── Helpers ───────────────────────────────────────────────────────────────────


def _mock_llm_response(data: dict) -> str:
    """Convert a dict to the JSON string an LLM would return."""
    return json.dumps(data)


VALID_PLAN_JSON = {
    "intent": "Set up a Python project",
    "tasks": [
        {
            "id": "t1",
            "cmd": "echo step-one",
            "description": "First step",
            "depends_on": [],
        },
        {
            "id": "t2",
            "cmd": "echo step-two",
            "description": "Second step",
            "depends_on": ["t1"],
        },
        {
            "id": "t3",
            "cmd": "echo step-three",
            "description": "Third step",
            "depends_on": ["t2"],
        },
    ],
}

DIAMOND_PLAN_JSON = {
    "intent": "Build and test",
    "tasks": [
        {"id": "install", "cmd": "pip install -e .", "description": "Install", "depends_on": []},
        {"id": "lint", "cmd": "ruff check .", "description": "Lint", "depends_on": ["install"]},
        {"id": "test", "cmd": "pytest", "description": "Test", "depends_on": ["install"]},
        {"id": "report", "cmd": "echo done", "description": "Report", "depends_on": ["lint", "test"]},
    ],
}


# ═══════════════════════════════════════════════════════════════════════════════
# Prompts / base.py
# ═══════════════════════════════════════════════════════════════════════════════


class TestPrompts:

    def test_system_prompt_mentions_alfie(self):
        assert "ALFIE" in SYSTEM_PROMPT

    def test_system_prompt_mentions_json(self):
        assert "JSON" in SYSTEM_PROMPT

    def test_system_prompt_mentions_depends_on(self):
        assert "depends_on" in SYSTEM_PROMPT

    def test_plan_schema_has_required_fields(self):
        schema = PLAN_SCHEMA["json_schema"]["schema"]
        assert "intent" in schema["properties"]
        assert "tasks" in schema["properties"]
        task_schema = schema["properties"]["tasks"]["items"]
        assert "id" in task_schema["properties"]
        assert "cmd" in task_schema["properties"]
        assert "depends_on" in task_schema["properties"]

    def test_build_user_message_basic(self):
        msg = build_user_message("set up pytest")
        assert "set up pytest" in msg

    def test_build_user_message_with_context(self):
        msg = build_user_message("deploy", context="staging server on AWS")
        assert "deploy" in msg
        assert "staging server on AWS" in msg


# ═══════════════════════════════════════════════════════════════════════════════
# Client (alfie.planner.client)
# ═══════════════════════════════════════════════════════════════════════════════


class TestClientConfig:

    def test_resolve_api_key_from_gateway_env(self):
        from alfie.planner.client import _resolve_api_key

        cfg = AIGatewayConfig()
        with patch.dict(os.environ, {"AI_GATEWAY_API_KEY": "test-key-123"}, clear=False):
            key = _resolve_api_key(cfg)
            assert key == "test-key-123"

    def test_resolve_api_key_falls_back_to_openai(self):
        from alfie.planner.client import _resolve_api_key

        cfg = AIGatewayConfig()
        env = {"OPENAI_API_KEY": "openai-fallback"}
        # Remove AI_GATEWAY_API_KEY if set
        with patch.dict(os.environ, env, clear=False):
            os.environ.pop("AI_GATEWAY_API_KEY", None)
            key = _resolve_api_key(cfg)
            assert key == "openai-fallback"

    def test_resolve_api_key_raises_when_missing(self):
        from alfie.planner.client import _resolve_api_key

        cfg = AIGatewayConfig()
        with patch.dict(os.environ, {}, clear=True):
            with pytest.raises(RuntimeError, match="No API key"):
                _resolve_api_key(cfg)

    def test_build_client_sets_base_url(self):
        from alfie.planner.client import build_client

        cfg = AIGatewayConfig(base_url="https://test-gateway.example.com/v1")
        with patch.dict(os.environ, {"AI_GATEWAY_API_KEY": "test"}, clear=False):
            client, model = build_client(model="gpt-4o-mini", config=cfg)
            assert client.base_url.host == "test-gateway.example.com"
            assert model == "gpt-4o-mini"


# ═══════════════════════════════════════════════════════════════════════════════
# Planner._parse_response (unit tests — no LLM call)
# ═══════════════════════════════════════════════════════════════════════════════


class TestPlannerParse:

    def _make_planner(self) -> Planner:
        """Build a Planner without needing an API key."""
        cfg = AIGatewayConfig()
        return Planner.__new__(Planner)  # bypass __init__

    def _init_planner(self) -> Planner:
        p = self._make_planner()
        p._config = AIGatewayConfig()
        p._model = "gpt-4o-mini"
        p._temperature = None
        p._max_retries = 2
        return p

    def test_parse_valid_plan(self):
        p = self._init_planner()
        raw = _mock_llm_response(VALID_PLAN_JSON)
        plan = p._parse_response(raw, "test intent")

        assert isinstance(plan, Plan)
        assert len(plan.tasks) == 3
        assert plan.tasks[0].id == "t1"
        assert plan.tasks[1].depends_on == ["t1"]
        assert plan.model == "gpt-4o-mini"

    def test_parse_diamond_plan(self):
        p = self._init_planner()
        raw = _mock_llm_response(DIAMOND_PLAN_JSON)
        plan = p._parse_response(raw, "build and test")

        assert len(plan.tasks) == 4
        assert plan.tasks[3].depends_on == ["lint", "test"]

    def test_parse_with_markdown_fences(self):
        """LLMs sometimes wrap JSON in ```json ... ```"""
        p = self._init_planner()
        raw = "```json\n" + json.dumps(VALID_PLAN_JSON) + "\n```"
        plan = p._parse_response(raw, "test")
        assert len(plan.tasks) == 3

    def test_parse_with_on_failure(self):
        p = self._init_planner()
        data = {
            "intent": "test",
            "tasks": [{
                "id": "t1",
                "cmd": "echo hi",
                "description": "test",
                "depends_on": [],
                "on_failure": "abort",
            }],
        }
        plan = p._parse_response(json.dumps(data), "test")
        assert plan.tasks[0].on_failure == FailureStrategy.ABORT

    def test_parse_invalid_on_failure_defaults_to_escalate(self):
        p = self._init_planner()
        data = {
            "intent": "test",
            "tasks": [{
                "id": "t1",
                "cmd": "echo hi",
                "description": "test",
                "depends_on": [],
                "on_failure": "banana",
            }],
        }
        plan = p._parse_response(json.dumps(data), "test")
        assert plan.tasks[0].on_failure == FailureStrategy.ESCALATE

    def test_parse_rejects_missing_tasks(self):
        p = self._init_planner()
        with pytest.raises(PlannerError, match="missing 'tasks'"):
            p._parse_response('{"intent": "test"}', "test")

    def test_parse_rejects_empty_tasks(self):
        p = self._init_planner()
        with pytest.raises(PlannerError, match="no tasks"):
            p._parse_response('{"intent": "test", "tasks": []}', "test")

    def test_parse_rejects_duplicate_ids(self):
        p = self._init_planner()
        data = {
            "intent": "test",
            "tasks": [
                {"id": "t1", "cmd": "echo a", "description": "a", "depends_on": []},
                {"id": "t1", "cmd": "echo b", "description": "b", "depends_on": []},
            ],
        }
        with pytest.raises(PlannerError, match="Duplicate"):
            p._parse_response(json.dumps(data), "test")

    def test_parse_rejects_empty_cmd(self):
        p = self._init_planner()
        data = {
            "intent": "test",
            "tasks": [{"id": "t1", "cmd": "", "description": "a", "depends_on": []}],
        }
        with pytest.raises(PlannerError, match="empty cmd"):
            p._parse_response(json.dumps(data), "test")

    def test_parse_rejects_unknown_dependency(self):
        p = self._init_planner()
        data = {
            "intent": "test",
            "tasks": [
                {"id": "t1", "cmd": "echo a", "description": "a", "depends_on": ["t99"]},
            ],
        }
        with pytest.raises(PlannerError, match="unknown task"):
            p._parse_response(json.dumps(data), "test")

    def test_parse_rejects_cycle(self):
        p = self._init_planner()
        data = {
            "intent": "test",
            "tasks": [
                {"id": "t1", "cmd": "echo a", "description": "a", "depends_on": ["t2"]},
                {"id": "t2", "cmd": "echo b", "description": "b", "depends_on": ["t1"]},
            ],
        }
        with pytest.raises(PlannerError, match="Invalid DAG"):
            p._parse_response(json.dumps(data), "test")

    def test_parse_invalid_json_raises(self):
        p = self._init_planner()
        with pytest.raises(json.JSONDecodeError):
            p._parse_response("not json at all", "test")


# ═══════════════════════════════════════════════════════════════════════════════
# Planner.generate (mocked LLM)
# ═══════════════════════════════════════════════════════════════════════════════


class TestPlannerGenerate:

    @patch("alfie.planner.planner.chat")
    def test_generate_returns_plan(self, mock_chat):
        mock_chat.return_value = json.dumps(VALID_PLAN_JSON)

        with patch.dict(os.environ, {"AI_GATEWAY_API_KEY": "test"}, clear=False):
            planner = Planner(model="gpt-4o-mini")
            plan = planner.generate("set up a Python project")

        assert isinstance(plan, Plan)
        assert len(plan.tasks) == 3
        assert plan.intent == "Set up a Python project"
        mock_chat.assert_called_once()

    @patch("alfie.planner.planner.chat")
    def test_generate_retries_on_bad_json(self, mock_chat):
        """First call returns garbage, second returns valid JSON."""
        mock_chat.side_effect = [
            "oops not json",
            json.dumps(VALID_PLAN_JSON),
        ]

        with patch.dict(os.environ, {"AI_GATEWAY_API_KEY": "test"}, clear=False):
            planner = Planner(model="gpt-4o-mini", max_retries=2)
            plan = planner.generate("set up a project")

        assert isinstance(plan, Plan)
        assert mock_chat.call_count == 2

    @patch("alfie.planner.planner.chat")
    def test_generate_raises_after_max_retries(self, mock_chat):
        mock_chat.return_value = "always bad"

        with patch.dict(os.environ, {"AI_GATEWAY_API_KEY": "test"}, clear=False):
            planner = Planner(model="gpt-4o-mini", max_retries=2)
            with pytest.raises(PlannerError, match="Failed after 2 attempts"):
                planner.generate("impossible request")

    @patch("alfie.planner.planner.chat")
    def test_generate_passes_model_to_chat(self, mock_chat):
        mock_chat.return_value = json.dumps(VALID_PLAN_JSON)

        with patch.dict(os.environ, {"AI_GATEWAY_API_KEY": "test"}, clear=False):
            planner = Planner(model="anthropic/claude-sonnet-4.6")
            planner.generate("test")

        call_kwargs = mock_chat.call_args
        assert call_kwargs.kwargs["model"] == "anthropic/claude-sonnet-4.6"

    @patch("alfie.planner.planner.chat")
    def test_generate_uses_structured_output_schema(self, mock_chat):
        mock_chat.return_value = json.dumps(VALID_PLAN_JSON)

        with patch.dict(os.environ, {"AI_GATEWAY_API_KEY": "test"}, clear=False):
            planner = Planner()
            planner.generate("test")

        call_kwargs = mock_chat.call_args
        assert call_kwargs.kwargs["response_format"] == PLAN_SCHEMA


# ═══════════════════════════════════════════════════════════════════════════════
# CLI integration (mocked planner)
# ═══════════════════════════════════════════════════════════════════════════════


class TestCLIWithPlanner:

    @patch("alfie.planner.planner.chat")
    def test_run_without_plan_calls_planner(self, mock_chat):
        from typer.testing import CliRunner
        from alfie.cli import app

        mock_chat.return_value = json.dumps(VALID_PLAN_JSON)
        runner = CliRunner()

        with patch.dict(os.environ, {"AI_GATEWAY_API_KEY": "test"}, clear=False):
            result = runner.invoke(app, ["run", "set up a Python project"])

        assert "Plan generated" in result.output or "Executing plan" in result.output
        assert result.exit_code == 0

    def test_run_without_api_key_shows_helpful_error(self):
        from typer.testing import CliRunner
        from alfie.cli import app

        runner = CliRunner()

        with patch.dict(os.environ, {}, clear=True):
            result = runner.invoke(app, ["run", "do something"])

        assert "API key" in result.output or result.exit_code == 1
