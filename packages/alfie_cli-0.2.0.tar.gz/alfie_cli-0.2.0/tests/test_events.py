"""Tests for event bus."""

from alfie.events.bus import EventBus


class TestEventBus:

    def test_emit_and_history(self, event_bus: EventBus):
        event_bus.emit("task.started", {"task_id": "t1"})
        assert len(event_bus.history) == 1
        assert event_bus.history[0].event_type == "task.started"

    def test_handler_called(self, event_bus: EventBus):
        received = []
        event_bus.on("task.done", lambda e: received.append(e))
        event_bus.emit("task.done", {"task_id": "t1"})
        assert len(received) == 1
        assert received[0].data["task_id"] == "t1"

    def test_wildcard_handler(self, event_bus: EventBus):
        received = []
        event_bus.on("*", lambda e: received.append(e))
        event_bus.emit("task.started")
        event_bus.emit("task.done")
        assert len(received) == 2

    def test_handler_not_called_for_other_events(self, event_bus: EventBus):
        received = []
        event_bus.on("task.started", lambda e: received.append(e))
        event_bus.emit("task.done")
        assert len(received) == 0

    def test_clear_history(self, event_bus: EventBus):
        event_bus.emit("x")
        event_bus.emit("y")
        assert len(event_bus.history) == 2
        event_bus.clear()
        assert len(event_bus.history) == 0
