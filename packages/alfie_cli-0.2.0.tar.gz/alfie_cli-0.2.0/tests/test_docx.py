"""Tests for the docx document management tools."""

from __future__ import annotations

import json
import os
from pathlib import Path

import pytest
from docx import Document
from docx.shared import Pt

from alfie.tools.docx import (
    ALL_DOCX_TOOLS,
    AddDocxHeadingTool,
    AddDocxTableTool,
    AppendDocxTool,
    CreateDocxTool,
    DEFAULT_FONT,
    DEFAULT_FONT_SIZE,
    DeleteDocxFileTool,
    DeleteDocxParagraphTool,
    DocumentManager,
    EditDocxTool,
    FormatDocxTextTool,
    ReadDocxTool,
    SaveDocxAsTool,
    _markdown_to_docx,
    _normalize_table_data,
)


# ── fixtures ──────────────────────────────────────────────────────────────────

@pytest.fixture()
def work_dir(tmp_path, monkeypatch):
    """Switch CWD to a temp directory so path-safety checks pass."""
    monkeypatch.chdir(tmp_path)
    return tmp_path


def _make_docx(path: Path, body: str = "Hello world", title: str = "") -> Path:
    """Helper to create a minimal .docx for testing."""
    doc = Document()
    if title:
        doc.add_heading(title, level=1)
    doc.add_paragraph(body)
    doc.save(str(path))
    return path


# ── DocumentManager unit tests ───────────────────────────────────────────────

class TestDocumentManager:
    def test_create_empty(self, work_dir):
        mgr = DocumentManager()
        f = str(work_dir / "empty.docx")
        result = mgr.create(f)
        assert os.path.isfile(f)
        assert "Created" in result

    def test_create_default_font(self, work_dir):
        """Documents should use Segoe UI 11.5pt by default."""
        mgr = DocumentManager()
        f = str(work_dir / "defaults.docx")
        mgr.create(f, content="Test")
        doc = Document(f)
        normal = doc.styles["Normal"]
        assert normal.font.name == DEFAULT_FONT
        assert normal.font.size == Pt(DEFAULT_FONT_SIZE)

    def test_create_custom_font(self, work_dir):
        mgr = DocumentManager()
        f = str(work_dir / "custom.docx")
        mgr.create(f, content="Test", font_name="Arial", font_size=14)
        doc = Document(f)
        normal = doc.styles["Normal"]
        assert normal.font.name == "Arial"
        assert normal.font.size == Pt(14)

    def test_create_with_title_and_content(self, work_dir):
        mgr = DocumentManager()
        f = str(work_dir / "titled.docx")
        mgr.create(f, content="Body text", title="My Title")
        doc = Document(f)
        texts = [p.text for p in doc.paragraphs]
        assert "My Title" in texts
        assert "Body text" in texts

    def test_read(self, work_dir):
        mgr = DocumentManager()
        f = str(_make_docx(work_dir / "read.docx", body="Some content"))
        data = mgr.read(f)
        assert data["filename"] == f
        assert "Some content" in data["full_text"]
        assert len(data["paragraphs"]) >= 1

    def test_edit(self, work_dir):
        mgr = DocumentManager()
        f = str(_make_docx(work_dir / "edit.docx", body="old text here"))
        mgr.edit(f, "old text", "new text")
        doc = Document(f)
        assert "new text here" in doc.paragraphs[0].text

    def test_append(self, work_dir):
        mgr = DocumentManager()
        f = str(_make_docx(work_dir / "append.docx", body="first"))
        mgr.append(f, "second paragraph")
        doc = Document(f)
        texts = [p.text for p in doc.paragraphs]
        assert "second paragraph" in texts

    def test_add_heading(self, work_dir):
        mgr = DocumentManager()
        f = str(_make_docx(work_dir / "heading.docx"))
        mgr.add_heading(f, "Section Two", level=2)
        doc = Document(f)
        styles = [p.style.name for p in doc.paragraphs]
        assert "Heading 2" in styles

    def test_add_table(self, work_dir):
        mgr = DocumentManager()
        f = str(_make_docx(work_dir / "table.docx"))
        mgr.add_table(f, [["Name", "Age"], ["Alice", "30"]])
        doc = Document(f)
        assert len(doc.tables) == 1
        assert doc.tables[0].rows[1].cells[0].text == "Alice"

    def test_format_text_bold(self, work_dir):
        mgr = DocumentManager()
        f = str(_make_docx(work_dir / "fmt.docx", body="highlight me"))
        mgr.format_text(f, "highlight me", bold=True)
        doc = Document(f)
        for run in doc.paragraphs[0].runs:
            if "highlight" in run.text:
                assert run.bold is True

    def test_delete_paragraph(self, work_dir):
        mgr = DocumentManager()
        f = str(work_dir / "delpara.docx")
        doc = Document()
        doc.add_paragraph("keep this")
        doc.add_paragraph("delete this")
        doc.save(f)
        mgr.delete_paragraph(f, "delete this")
        doc2 = Document(f)
        texts = [p.text for p in doc2.paragraphs]
        assert "delete this" not in texts

    def test_delete_file(self, work_dir):
        mgr = DocumentManager()
        f = str(_make_docx(work_dir / "gone.docx"))
        assert os.path.isfile(f)
        mgr.delete_file(f)
        assert not os.path.isfile(f)

    def test_delete_file_not_found(self, work_dir):
        mgr = DocumentManager()
        result = mgr.delete_file(str(work_dir / "nope.docx"))
        assert "not found" in result.lower()

    def test_save_as(self, work_dir):
        mgr = DocumentManager()
        f = str(_make_docx(work_dir / "original.docx", body="content"))
        copy = str(work_dir / "copy.docx")
        mgr.save_as(f, copy)
        assert os.path.isfile(copy)
        doc = Document(copy)
        assert "content" in doc.paragraphs[0].text


# ── Tool wrapper tests ───────────────────────────────────────────────────────

class TestDocxTools:
    def test_all_tools_count(self):
        assert len(ALL_DOCX_TOOLS) == 10

    def test_all_have_openai_schema(self):
        for tool in ALL_DOCX_TOOLS:
            schema = tool.openai_schema()
            assert schema["type"] == "function"
            assert schema["function"]["name"] == tool.name
            assert "description" in schema["function"]

    def test_create_tool(self, work_dir):
        tool = CreateDocxTool()
        result = tool.execute(filename="test.docx", title="Hello", content="Body")
        assert result.success
        assert os.path.isfile(work_dir / "test.docx")

    def test_read_tool(self, work_dir):
        _make_docx(work_dir / "r.docx", body="read me")
        tool = ReadDocxTool()
        result = tool.execute(filename="r.docx")
        assert result.success
        data = json.loads(result.output)
        assert "read me" in data["full_text"]

    def test_edit_tool(self, work_dir):
        _make_docx(work_dir / "e.docx", body="alpha beta")
        tool = EditDocxTool()
        result = tool.execute(filename="e.docx", find="alpha", replace="omega")
        assert result.success

    def test_append_tool(self, work_dir):
        _make_docx(work_dir / "a.docx", body="first")
        tool = AppendDocxTool()
        result = tool.execute(filename="a.docx", content="appended line")
        assert result.success
        doc = Document(str(work_dir / "a.docx"))
        assert any("appended line" in p.text for p in doc.paragraphs)

    def test_add_heading_tool(self, work_dir):
        _make_docx(work_dir / "h.docx")
        tool = AddDocxHeadingTool()
        result = tool.execute(filename="h.docx", text="New Section", level=2)
        assert result.success
        assert "level 2" in result.output

    def test_add_table_tool(self, work_dir):
        _make_docx(work_dir / "t.docx")
        tool = AddDocxTableTool()
        result = tool.execute(filename="t.docx", data=[["A", "B"], ["1", "2"]])
        assert result.success

    def test_add_table_tool_empty_data(self, work_dir):
        _make_docx(work_dir / "te.docx")
        tool = AddDocxTableTool()
        result = tool.execute(filename="te.docx", data=[])
        assert not result.success

    def test_format_tool(self, work_dir):
        _make_docx(work_dir / "f.docx", body="bold me")
        tool = FormatDocxTextTool()
        result = tool.execute(filename="f.docx", find="bold me", bold=True, font_size=16)
        assert result.success

    def test_format_tool_color(self, work_dir):
        _make_docx(work_dir / "fc.docx", body="colorize")
        tool = FormatDocxTextTool()
        result = tool.execute(filename="fc.docx", find="colorize", color=[255, 0, 0])
        assert result.success

    def test_delete_paragraph_tool(self, work_dir):
        f = str(work_dir / "dp.docx")
        doc = Document()
        doc.add_paragraph("stay")
        doc.add_paragraph("go away")
        doc.save(f)
        tool = DeleteDocxParagraphTool()
        result = tool.execute(filename="dp.docx", find="go away")
        assert result.success
        doc2 = Document(f)
        assert all("go away" not in p.text for p in doc2.paragraphs)

    def test_delete_file_tool(self, work_dir):
        _make_docx(work_dir / "del.docx")
        tool = DeleteDocxFileTool()
        result = tool.execute(filename="del.docx")
        assert result.success
        assert not os.path.isfile(work_dir / "del.docx")

    def test_save_as_tool(self, work_dir):
        _make_docx(work_dir / "src.docx", body="original")
        tool = SaveDocxAsTool()
        result = tool.execute(filename="src.docx", new_filename="dst.docx")
        assert result.success
        assert os.path.isfile(work_dir / "dst.docx")

    def test_read_nonexistent(self, work_dir):
        tool = ReadDocxTool()
        result = tool.execute(filename="nope.docx")
        assert not result.success

    def test_path_escape_blocked(self, work_dir):
        tool = CreateDocxTool()
        result = tool.execute(filename="../../escape.docx")
        assert not result.success
        assert "escapes" in result.output.lower() or "escape" in result.output.lower()


# ── Registration test ─────────────────────────────────────────────────────────

def test_docx_tools_registered():
    from alfie.tools import registry
    for tool in ALL_DOCX_TOOLS:
        assert registry.get(tool.name) is not None, f"{tool.name} not registered"


# ── Markdown-to-docx converter tests ─────────────────────────────────────────

class TestMarkdownToDocx:
    def test_heading_levels(self, work_dir):
        doc = Document()
        _markdown_to_docx(doc, "# H1\n## H2\n### H3")
        styles = [p.style.name for p in doc.paragraphs]
        assert styles == ["Heading 1", "Heading 2", "Heading 3"]

    def test_bold_text(self, work_dir):
        doc = Document()
        _markdown_to_docx(doc, "This is **bold** text")
        runs = doc.paragraphs[0].runs
        texts = [(r.text, r.bold) for r in runs]
        assert ("bold", True) in texts
        # Non-bold parts should exist too
        assert any("This is " in r.text for r in runs)

    def test_italic_text(self, work_dir):
        doc = Document()
        _markdown_to_docx(doc, "This is *italic* text")
        runs = doc.paragraphs[0].runs
        assert any(r.italic is True and "italic" in r.text for r in runs)

    def test_bold_italic_text(self, work_dir):
        doc = Document()
        _markdown_to_docx(doc, "This is ***both*** styled")
        runs = doc.paragraphs[0].runs
        assert any(r.bold is True and r.italic is True and "both" in r.text for r in runs)

    def test_bullet_list(self, work_dir):
        doc = Document()
        _markdown_to_docx(doc, "- First item\n- Second item")
        assert len(doc.paragraphs) == 2
        assert doc.paragraphs[0].style.name == "List Bullet"
        assert doc.paragraphs[1].style.name == "List Bullet"
        assert "First item" in doc.paragraphs[0].text
        assert "Second item" in doc.paragraphs[1].text

    def test_numbered_list(self, work_dir):
        doc = Document()
        _markdown_to_docx(doc, "1. First\n2. Second")
        assert doc.paragraphs[0].style.name == "List Number"
        assert "First" in doc.paragraphs[0].text

    def test_table(self, work_dir):
        md = "| Name | Age |\n|------|-----|\n| Alice | 30 |\n| Bob | 25 |"
        doc = Document()
        _markdown_to_docx(doc, md)
        assert len(doc.tables) == 1
        table = doc.tables[0]
        assert len(table.rows) == 3  # header + 2 data rows
        assert table.rows[0].cells[0].text == "Name"
        assert table.rows[1].cells[0].text == "Alice"
        assert table.rows[2].cells[1].text == "25"

    def test_mixed_content(self, work_dir):
        md = "# Report\n\nSome **intro** text.\n\n- Item one\n- Item two\n\n| A | B |\n|---|---|\n| 1 | 2 |"
        doc = Document()
        _markdown_to_docx(doc, md)
        # Should have: heading, paragraph, 2 bullets — and 1 table
        styles = [p.style.name for p in doc.paragraphs]
        assert "Heading 1" in styles
        assert "List Bullet" in styles
        assert len(doc.tables) == 1

    def test_blank_lines_skipped(self, work_dir):
        doc = Document()
        _markdown_to_docx(doc, "\n\nHello\n\n")
        assert len(doc.paragraphs) == 1
        assert doc.paragraphs[0].text == "Hello"

    def test_inline_bold_in_bullet(self, work_dir):
        doc = Document()
        _markdown_to_docx(doc, "- **Create Files:** ALFIE can create new files")
        para = doc.paragraphs[0]
        assert para.style.name == "List Bullet"
        assert any(r.bold is True and "Create Files:" in r.text for r in para.runs)

    def test_create_uses_markdown(self, work_dir):
        """DocumentManager.create() should auto-convert markdown to Word formatting."""
        mgr = DocumentManager()
        f = str(work_dir / "md.docx")
        mgr.create(f, content="# Heading\n\n**Bold** text\n\n- Bullet", title="Title")
        doc = Document(f)
        styles = [p.style.name for p in doc.paragraphs]
        assert "Heading 1" in styles  # from markdown, not title
        assert "List Bullet" in styles
        # No raw asterisks in text
        for p in doc.paragraphs:
            assert "**" not in p.text

    def test_append_uses_markdown(self, work_dir):
        """DocumentManager.append() should auto-convert markdown when style is Normal."""
        mgr = DocumentManager()
        f = str(work_dir / "app.docx")
        mgr.create(f)
        mgr.append(f, "## Section\n\nSome *italic* word")
        doc = Document(f)
        styles = [p.style.name for p in doc.paragraphs]
        assert "Heading 2" in styles
        # Italic run exists
        all_runs = [r for p in doc.paragraphs for r in p.runs]
        assert any(r.italic is True and "italic" in r.text for r in all_runs)

    def test_single_pipe_not_a_table(self, work_dir):
        """A line with only one column (like '| x |') should NOT become a table."""
        doc = Document()
        _markdown_to_docx(doc, "| solo |")
        # Should be a normal paragraph, not a table
        assert len(doc.tables) == 0
        assert len(doc.paragraphs) == 1

    def test_json_not_table(self, work_dir):
        """JSON-like content should not become a character-per-cell table."""
        doc = Document()
        content = '["concept", "docs", "pyproject.toml"]'
        _markdown_to_docx(doc, content)
        assert len(doc.tables) == 0
        assert len(doc.paragraphs) >= 1


# ── Table data normalization tests ────────────────────────────────────────────

class TestNormalizeTableData:
    def test_proper_2d_array(self):
        data = [["Name", "Age"], ["Alice", "30"]]
        assert _normalize_table_data(data) == [["Name", "Age"], ["Alice", "30"]]

    def test_flat_list_becomes_single_column(self):
        data = ["concept", "docs", "tests"]
        result = _normalize_table_data(data)
        assert result == [["concept"], ["docs"], ["tests"]]

    def test_string_json_parsed(self):
        data = '[["A", "B"], ["1", "2"]]'
        result = _normalize_table_data(data)
        assert result == [["A", "B"], ["1", "2"]]

    def test_plain_string_becomes_single_cell(self):
        result = _normalize_table_data("hello")
        assert result == [["hello"]]

    def test_mixed_list(self):
        data = [["Name", "Age"], "oops"]
        result = _normalize_table_data(data)
        assert result == [["Name", "Age"], ["oops"]]

    def test_add_table_tool_flat_list(self, work_dir):
        """LLM sends flat list — should produce single-column table, not char-per-cell."""
        _make_docx(work_dir / "flat.docx")
        tool = AddDocxTableTool()
        result = tool.execute(filename="flat.docx", data=["concept", "docs", "tests"])
        assert result.success
        doc = Document(str(work_dir / "flat.docx"))
        assert len(doc.tables) == 1
        table = doc.tables[0]
        # Each row should have ONE cell with the full word
        assert table.rows[0].cells[0].text == "concept"
        assert table.rows[1].cells[0].text == "docs"
        assert table.rows[2].cells[0].text == "tests"

    def test_add_table_tool_json_string(self, work_dir):
        """LLM sends JSON string instead of array — should still produce correct table."""
        _make_docx(work_dir / "json.docx")
        tool = AddDocxTableTool()
        result = tool.execute(
            filename="json.docx",
            data='[["Path", "Description"], ["src/", "Source code"]]',
        )
        assert result.success
        doc = Document(str(work_dir / "json.docx"))
        table = doc.tables[0]
        assert table.rows[0].cells[0].text == "Path"
        assert table.rows[1].cells[0].text == "src/"
