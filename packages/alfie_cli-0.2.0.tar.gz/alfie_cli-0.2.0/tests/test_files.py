"""Tests for file index and file management tools."""

from __future__ import annotations

import json
import os
from pathlib import Path

import pytest

from alfie.tools.files import (
    ALL_FILE_TOOLS,
    CopyFileTool,
    FileManager,
    IndexEngine,
    IndexStatsTool,
    MoveFileTool,
    OrganizeFilesTool,
    RenameFileTool,
    ScanFilesTool,
    SearchFilesTool,
    TagFileTool,
)


# ── fixtures ──────────────────────────────────────────────────────────────────

@pytest.fixture()
def work_dir(tmp_path, monkeypatch):
    """CWD in a temp directory for path-safety checks."""
    wd = tmp_path / "workspace"
    wd.mkdir()
    monkeypatch.chdir(wd)
    return wd


@pytest.fixture()
def engine(tmp_path):
    """IndexEngine with DB outside the workspace scan area."""
    db_dir = tmp_path / "alfie_db"
    return IndexEngine(db_dir=db_dir)


@pytest.fixture()
def manager(engine):
    """FileManager wired to the test engine."""
    return FileManager(index=engine)


def _populate(work_dir: Path) -> None:
    """Create a handful of test files."""
    (work_dir / "readme.md").write_text("# Hello", encoding="utf-8")
    (work_dir / "app.py").write_text("print('hi')", encoding="utf-8")
    (work_dir / "photo.jpg").write_bytes(b"\xff\xd8fake-jpg")
    (work_dir / "data.csv").write_text("a,b\n1,2", encoding="utf-8")
    sub = work_dir / "sub"
    sub.mkdir()
    (sub / "nested.txt").write_text("deep", encoding="utf-8")


# ── IndexEngine tests ────────────────────────────────────────────────────────

class TestIndexEngine:
    def test_scan_counts(self, work_dir, engine):
        _populate(work_dir)
        result = engine.scan(str(work_dir))
        assert result["indexed"] == 5
        assert result["skipped"] == 0

    def test_scan_limit(self, work_dir, engine):
        _populate(work_dir)
        result = engine.scan(str(work_dir), limit=2)
        assert result["indexed"] == 2

    def test_search_by_name(self, work_dir, engine):
        _populate(work_dir)
        engine.scan(str(work_dir))
        results = engine.search("readme")
        assert len(results) >= 1
        assert any("readme.md" in r["filename"] for r in results)

    def test_search_by_extension(self, work_dir, engine):
        _populate(work_dir)
        engine.scan(str(work_dir))
        results = engine.search(".py")
        assert any(r["extension"] == ".py" for r in results)

    def test_search_no_results(self, work_dir, engine):
        _populate(work_dir)
        engine.scan(str(work_dir))
        results = engine.search("nonexistent_file_xyz")
        assert results == []

    def test_tag_and_search(self, work_dir, engine):
        _populate(work_dir)
        engine.scan(str(work_dir))
        full_path = str((work_dir / "readme.md").resolve())
        engine.tag(full_path, "docs, important, 2026")
        results = engine.search("important")
        assert len(results) == 1
        assert results[0]["tags"] == "docs, important, 2026"

    def test_tag_nonexistent(self, engine):
        msg = engine.tag("/fake/path.txt", "test")
        assert "not in index" in msg.lower()

    def test_remove(self, work_dir, engine):
        _populate(work_dir)
        engine.scan(str(work_dir))
        full_path = str((work_dir / "app.py").resolve())
        engine.remove(full_path)
        results = engine.search("app.py")
        assert not any(r["full_path"] == full_path for r in results)

    def test_stats(self, work_dir, engine):
        _populate(work_dir)
        engine.scan(str(work_dir))
        stats = engine.stats()
        assert stats["total_files_indexed"] == 5
        assert len(stats["top_file_types"]) >= 1

    def test_clear(self, work_dir, engine):
        _populate(work_dir)
        engine.scan(str(work_dir))
        engine.clear()
        stats = engine.stats()
        assert stats["total_files_indexed"] == 0

    def test_rescan_updates(self, work_dir, engine):
        """Scanning again after adding a file picks up the new file."""
        _populate(work_dir)
        engine.scan(str(work_dir))
        (work_dir / "new.txt").write_text("new", encoding="utf-8")
        engine.scan(str(work_dir))
        results = engine.search("new.txt")
        assert len(results) == 1


# ── FileManager tests ────────────────────────────────────────────────────────

class TestFileManager:
    def test_move(self, work_dir, manager):
        src = work_dir / "src.txt"
        src.write_text("content", encoding="utf-8")
        dst = work_dir / "moved" / "dst.txt"
        manager.index.scan(str(work_dir))
        msg = manager.move(str(src), str(dst))
        assert msg.startswith("Moved")
        assert dst.is_file()
        assert not src.exists()

    def test_move_not_found(self, work_dir, manager):
        msg = manager.move(str(work_dir / "nope.txt"), str(work_dir / "dst.txt"))
        assert "not found" in msg.lower()

    def test_copy(self, work_dir, manager):
        src = work_dir / "original.txt"
        src.write_text("data", encoding="utf-8")
        dst = work_dir / "copies" / "copy.txt"
        msg = manager.copy(str(src), str(dst))
        assert msg.startswith("Copied")
        assert dst.is_file()
        assert src.is_file()  # original still exists

    def test_copy_not_found(self, work_dir, manager):
        msg = manager.copy(str(work_dir / "nope.txt"), str(work_dir / "dst.txt"))
        assert "not found" in msg.lower()

    def test_rename(self, work_dir, manager):
        f = work_dir / "old_name.txt"
        f.write_text("rename me", encoding="utf-8")
        manager.index.scan(str(work_dir))
        msg = manager.rename(str(f), "new_name.txt")
        assert msg.startswith("Renamed")
        assert (work_dir / "new_name.txt").is_file()
        assert not f.exists()

    def test_rename_not_found(self, work_dir, manager):
        msg = manager.rename(str(work_dir / "nope.txt"), "x.txt")
        assert "not found" in msg.lower()

    def test_organize(self, work_dir, manager):
        (work_dir / "report.pdf").write_bytes(b"pdf")
        (work_dir / "pic.png").write_bytes(b"png")
        (work_dir / "script.py").write_text("code", encoding="utf-8")
        (work_dir / "random.xyz").write_text("other", encoding="utf-8")

        result = manager.organize(str(work_dir))
        assert "moved" in result
        assert (work_dir / "Documents" / "report.pdf").is_file()
        assert (work_dir / "Images" / "pic.png").is_file()
        assert (work_dir / "Code" / "script.py").is_file()
        assert (work_dir / "Other" / "random.xyz").is_file()

    def test_organize_not_found(self, work_dir, manager):
        with pytest.raises(FileNotFoundError):
            manager.organize(str(work_dir / "nonexistent"))

    def test_organize_skips_subdirs(self, work_dir, manager):
        sub = work_dir / "existing_folder"
        sub.mkdir()
        (sub / "keep.txt").write_text("keep", encoding="utf-8")
        (work_dir / "file.txt").write_text("move", encoding="utf-8")
        manager.organize(str(work_dir))
        # Subdirectory should NOT be moved
        assert sub.is_dir()
        assert (sub / "keep.txt").is_file()


# ── Tool wrapper tests ───────────────────────────────────────────────────────

class TestFileTools:
    def test_all_tools_count(self):
        assert len(ALL_FILE_TOOLS) == 8

    def test_all_have_openai_schema(self):
        for tool in ALL_FILE_TOOLS:
            schema = tool.openai_schema()
            assert schema["type"] == "function"
            assert "description" in schema["function"]

    def test_scan_tool(self, work_dir):
        _populate(work_dir)
        tool = ScanFilesTool()
        result = tool.execute(path=".")
        assert result.success
        data = json.loads(result.output)
        assert data["indexed"] >= 1

    def test_search_tool(self, work_dir):
        _populate(work_dir)
        # Must scan first via the module-level manager
        from alfie.tools.files import _manager
        _manager.index.scan(str(work_dir))
        tool = SearchFilesTool()
        result = tool.execute(query="readme")
        assert result.success

    def test_tag_tool(self, work_dir):
        _populate(work_dir)
        from alfie.tools.files import _manager
        _manager.index.scan(str(work_dir))
        full_path = str((work_dir / "readme.md").resolve())
        tool = TagFileTool()
        result = tool.execute(path=str(work_dir / "readme.md"), tags="docs, test")
        assert result.success

    def test_index_stats_tool(self, work_dir):
        tool = IndexStatsTool()
        result = tool.execute()
        assert result.success
        data = json.loads(result.output)
        assert "total_files_indexed" in data

    def test_move_tool(self, work_dir):
        src = work_dir / "m.txt"
        src.write_text("data", encoding="utf-8")
        tool = MoveFileTool()
        result = tool.execute(source="m.txt", destination="moved_m.txt")
        assert result.success
        assert (work_dir / "moved_m.txt").is_file()

    def test_copy_tool(self, work_dir):
        src = work_dir / "c.txt"
        src.write_text("data", encoding="utf-8")
        tool = CopyFileTool()
        result = tool.execute(source="c.txt", destination="c_copy.txt")
        assert result.success
        assert (work_dir / "c_copy.txt").is_file()
        assert src.is_file()

    def test_rename_tool(self, work_dir):
        f = work_dir / "old.txt"
        f.write_text("data", encoding="utf-8")
        tool = RenameFileTool()
        result = tool.execute(path="old.txt", new_name="new.txt")
        assert result.success
        assert (work_dir / "new.txt").is_file()

    def test_organize_tool(self, work_dir):
        (work_dir / "pic.jpg").write_bytes(b"jpg")
        (work_dir / "doc.pdf").write_bytes(b"pdf")
        tool = OrganizeFilesTool()
        result = tool.execute(path=".")
        assert result.success
        data = json.loads(result.output)
        assert "moved" in data

    def test_path_escape_blocked(self, work_dir):
        tool = ScanFilesTool()
        result = tool.execute(path="../../escape")
        assert not result.success

    def test_move_path_escape(self, work_dir):
        (work_dir / "x.txt").write_text("x", encoding="utf-8")
        tool = MoveFileTool()
        result = tool.execute(source="x.txt", destination="../../evil.txt")
        assert not result.success


# ── Registration test ─────────────────────────────────────────────────────────

def test_file_tools_registered():
    from alfie.tools import registry
    for tool in ALL_FILE_TOOLS:
        assert registry.get(tool.name) is not None, f"{tool.name} not registered"
