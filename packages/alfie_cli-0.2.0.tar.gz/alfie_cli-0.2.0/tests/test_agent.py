"""Tests for the agent loop."""

from __future__ import annotations

import json
from typing import Any
from unittest.mock import MagicMock, patch

import pytest

from alfie.agent import AgentResponse, run_agent_loop
from alfie.tools.base import ToolResult


def _make_mock_response(content: str | None = None, tool_calls: list | None = None):
    """Build a mock OpenAI ChatCompletion response."""
    message = MagicMock()
    message.content = content
    message.tool_calls = tool_calls

    if tool_calls is None:
        message.model_dump.return_value = {"role": "assistant", "content": content}
    else:
        message.model_dump.return_value = {
            "role": "assistant",
            "content": content,
            "tool_calls": [
                {
                    "id": tc.id,
                    "type": "function",
                    "function": {"name": tc.function.name, "arguments": tc.function.arguments},
                }
                for tc in tool_calls
            ],
        }

    choice = MagicMock()
    choice.message = message

    response = MagicMock()
    response.choices = [choice]
    return response


def _make_tool_call(call_id: str, name: str, arguments: dict) -> MagicMock:
    """Build a mock tool_call object."""
    tc = MagicMock()
    tc.id = call_id
    tc.function.name = name
    tc.function.arguments = json.dumps(arguments)
    return tc


class TestAgentLoop:
    """Test the run_agent_loop function."""

    def test_simple_text_response(self):
        """LLM responds with text only — no tool calls."""
        client = MagicMock()
        client.chat.completions.create.return_value = _make_mock_response(
            content="Hello! How can I help?"
        )

        messages = [{"role": "user", "content": "hi"}]
        result = run_agent_loop(client=client, model="test", messages=messages)

        assert isinstance(result, AgentResponse)
        assert result.content == "Hello! How can I help?"
        assert result.total_llm_calls == 1
        assert result.stopped_reason == "complete"
        assert len(result.tool_calls_made) == 0

    def test_single_tool_call(self):
        """LLM calls one tool, sees result, then gives final answer."""
        client = MagicMock()

        # First call: LLM wants to call list_directory
        tc = _make_tool_call("call_1", "list_directory", {"path": "."})
        resp1 = _make_mock_response(content=None, tool_calls=[tc])

        # Second call: LLM gives final answer
        resp2 = _make_mock_response(content="I found 3 files in the directory.")

        client.chat.completions.create.side_effect = [resp1, resp2]

        messages = [{"role": "user", "content": "list files"}]
        result = run_agent_loop(client=client, model="test", messages=messages)

        assert result.content == "I found 3 files in the directory."
        assert result.total_llm_calls == 2
        assert len(result.tool_calls_made) == 1
        assert result.tool_calls_made[0]["tool_name"] == "list_directory"
        assert result.tool_calls_made[0]["success"]

    def test_multiple_tool_calls_in_sequence(self):
        """LLM calls a tool, sees result, calls another tool, then responds."""
        client = MagicMock()

        # Call 1: list_directory
        tc1 = _make_tool_call("call_1", "list_directory", {"path": "."})
        resp1 = _make_mock_response(content=None, tool_calls=[tc1])

        # Call 2: read_file (after seeing directory listing)
        tc2 = _make_tool_call("call_2", "read_file", {"path": "test.txt"})
        resp2 = _make_mock_response(content=None, tool_calls=[tc2])

        # Call 3: final answer
        resp3 = _make_mock_response(content="Done! The file contains hello.")

        client.chat.completions.create.side_effect = [resp1, resp2, resp3]

        messages = [{"role": "user", "content": "read test.txt"}]
        result = run_agent_loop(client=client, model="test", messages=messages)

        assert result.total_llm_calls == 3
        assert len(result.tool_calls_made) == 2
        assert result.stopped_reason == "complete"

    def test_max_iterations_respected(self):
        """Agent stops after max_iterations even if LLM keeps calling tools."""
        client = MagicMock()

        # Always return a tool call — never give a final answer
        tc = _make_tool_call("call_x", "list_directory", {"path": "."})
        client.chat.completions.create.return_value = _make_mock_response(
            content=None, tool_calls=[tc]
        )

        messages = [{"role": "user", "content": "loop forever"}]
        result = run_agent_loop(
            client=client, model="test", messages=messages, max_iterations=3
        )

        assert result.stopped_reason == "max_iterations"
        assert result.total_llm_calls == 3

    def test_llm_error_handling(self):
        """Agent handles LLM errors gracefully."""
        client = MagicMock()
        client.chat.completions.create.side_effect = Exception("API down")

        messages = [{"role": "user", "content": "hi"}]
        result = run_agent_loop(client=client, model="test", messages=messages)

        assert result.stopped_reason == "error"
        assert "LLM error" in result.content

    def test_unknown_tool_handled(self):
        """Agent handles calls to unknown tools gracefully."""
        client = MagicMock()

        tc = _make_tool_call("call_1", "nonexistent_tool", {})
        resp1 = _make_mock_response(content=None, tool_calls=[tc])
        resp2 = _make_mock_response(content="That tool doesn't exist.")

        client.chat.completions.create.side_effect = [resp1, resp2]

        messages = [{"role": "user", "content": "do something"}]
        result = run_agent_loop(client=client, model="test", messages=messages)

        assert len(result.tool_calls_made) == 1
        assert not result.tool_calls_made[0]["success"]

    def test_safety_blocks_dangerous_shell_command(self):
        """Safety guard blocks dangerous shell commands."""
        from alfie.models import SafetyConfig
        from alfie.safety.guard import SafetyGuard

        client = MagicMock()
        safety = SafetyGuard(SafetyConfig())

        tc = _make_tool_call("call_1", "run_shell", {"command": "rm -rf /"})
        resp1 = _make_mock_response(content=None, tool_calls=[tc])
        resp2 = _make_mock_response(content="That command was blocked for safety.")

        client.chat.completions.create.side_effect = [resp1, resp2]

        messages = [{"role": "user", "content": "delete everything"}]
        result = run_agent_loop(
            client=client, model="test", messages=messages, safety=safety
        )

        assert len(result.tool_calls_made) == 1
        assert not result.tool_calls_made[0]["success"]
        assert "BLOCKED" in result.tool_calls_made[0]["output"]

    def test_callbacks_called(self):
        """on_tool_start and on_tool_end callbacks are invoked."""
        client = MagicMock()

        tc = _make_tool_call("call_1", "list_directory", {"path": "."})
        resp1 = _make_mock_response(content=None, tool_calls=[tc])
        resp2 = _make_mock_response(content="Done.")

        client.chat.completions.create.side_effect = [resp1, resp2]

        starts = []
        ends = []

        result = run_agent_loop(
            client=client,
            model="test",
            messages=[{"role": "user", "content": "list"}],
            on_tool_start=lambda name, args: starts.append(name),
            on_tool_end=lambda name, res: ends.append(name),
        )

        assert starts == ["list_directory"]
        assert ends == ["list_directory"]

    def test_messages_accumulate_correctly(self):
        """Tool results are appended to messages in OpenAI format."""
        client = MagicMock()

        tc = _make_tool_call("call_1", "list_directory", {"path": "."})
        resp1 = _make_mock_response(content=None, tool_calls=[tc])
        resp2 = _make_mock_response(content="Done.")

        client.chat.completions.create.side_effect = [resp1, resp2]

        messages = [{"role": "user", "content": "list"}]
        run_agent_loop(client=client, model="test", messages=messages)

        # Messages should have: user, assistant (tool_calls), tool result, assistant (final)
        roles = [m["role"] if isinstance(m, dict) else m.get("role", "?") for m in messages]
        assert "tool" in roles
        assert roles[-1] == "assistant"
