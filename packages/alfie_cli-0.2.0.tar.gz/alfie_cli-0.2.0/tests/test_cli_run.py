"""Tests for the ALFIE CLI run command with plan files."""

from pathlib import Path

import pytest
from typer.testing import CliRunner

from alfie.cli import app

runner = CliRunner()
FIXTURES = Path(__file__).parent / "fixtures"


class TestRunWithPlan:

    def test_simple_plan_succeeds(self):
        plan = str(FIXTURES / "simple_plan.json")
        result = runner.invoke(app, ["run", "test", "--plan", plan])
        assert "Execution Plan" in result.output
        assert "Executing plan" in result.output
        assert "t1" in result.output
        assert "t2" in result.output
        assert "COMPLETED" in result.output
        assert result.exit_code == 0

    def test_diamond_plan_succeeds(self):
        plan = str(FIXTURES / "diamond_plan.json")
        result = runner.invoke(app, ["run", "diamond", "--plan", plan])
        assert "root" in result.output
        assert "left" in result.output
        assert "right" in result.output
        assert "join" in result.output
        assert "All 4 tasks completed" in result.output
        assert result.exit_code == 0

    def test_fail_plan_reports_failure(self):
        plan = str(FIXTURES / "fail_plan.json")
        result = runner.invoke(app, ["run", "test-fail", "--plan", plan])
        assert "FAILED" in result.output
        assert "SKIPPED" in result.output
        assert result.exit_code == 1

    def test_dry_run_validates_without_executing(self):
        plan = str(FIXTURES / "simple_plan.json")
        result = runner.invoke(app, ["run", "test", "--plan", plan, "--dry-run"])
        assert "Execution Plan" in result.output
        assert "safe" in result.output.lower()
        # Should NOT have execution output
        assert "Executing plan" not in result.output
        assert result.exit_code == 0

    def test_missing_plan_file_exits(self):
        result = runner.invoke(app, ["run", "test", "--plan", "/nonexistent/plan.json"])
        assert "not found" in result.output.lower()
        assert result.exit_code == 1

    def test_invalid_json_plan_exits(self, tmp_path):
        bad = tmp_path / "bad.json"
        bad.write_text("not json at all")
        result = runner.invoke(app, ["run", "test", "--plan", str(bad)])
        assert "failed to parse" in result.output.lower()
        assert result.exit_code == 1

    def test_intent_override(self):
        plan = str(FIXTURES / "simple_plan.json")
        result = runner.invoke(app, ["run", "my-custom-intent", "--plan", plan])
        assert "my-custom-intent" in result.output
        assert result.exit_code == 0

    def test_run_without_plan_and_no_api_key_shows_error(self):
        """Without --plan and no API key, the planner path shows a helpful error."""
        import os
        from unittest.mock import patch

        with patch.dict(os.environ, {}, clear=True):
            result = runner.invoke(app, ["run", "do something cool"])
        assert "API key" in result.output or result.exit_code == 1
