"""Tests for watcher — state classification, engine poll logic, recovery, events."""

import time

import pytest

from alfie.events.bus import EventBus
from alfie.models import PaneState, PaneStatus
from alfie.watcher.engine import (
    RecoveryAction,
    WatcherEngine,
    _TrackedPane,
    classify_output,
    pick_recovery,
)


# ═══════════════════════════════════════════════════════════════════════════════
# classify_output tests
# ═══════════════════════════════════════════════════════════════════════════════


class TestClassifyOutput:

    def test_empty_output_is_unknown(self):
        assert classify_output("") == PaneStatus.UNKNOWN
        assert classify_output("   ") == PaneStatus.UNKNOWN

    def test_idle_bash_prompt(self):
        output = "some output\nuser@host:~$ "
        assert classify_output(output) == PaneStatus.IDLE

    def test_idle_python_prompt(self):
        output = "Python 3.11.0\n>>> "
        assert classify_output(output) == PaneStatus.IDLE

    def test_idle_root_prompt(self):
        output = "logged in\nroot@server:~# "
        assert classify_output(output) == PaneStatus.IDLE

    def test_done_marker(self):
        output = "Running...\nAll good\nTASK_COMPLETE\nuser@host:~$ "
        assert classify_output(output) == PaneStatus.DONE

    def test_done_marker_case_insensitive(self):
        output = "running...\ntask_complete"
        assert classify_output(output) == PaneStatus.DONE

    def test_done_marker_mid_output(self):
        output = "step 1 ok\nTASK_COMPLETE\nmore stuff"
        assert classify_output(output) == PaneStatus.DONE

    def test_error_traceback(self):
        output = "File 'test.py', line 1\nTraceback (most recent call last):\nNameError"
        assert classify_output(output) == PaneStatus.ERROR

    def test_error_keyword(self):
        output = "npm ERR! Failed to install\nError: something broke"
        assert classify_output(output) == PaneStatus.ERROR

    def test_error_fatal(self):
        output = "fatal: not a git repository"
        assert classify_output(output) == PaneStatus.ERROR

    def test_error_killed(self):
        output = "running process\nKilled"
        assert classify_output(output) == PaneStatus.ERROR

    def test_error_exit_1(self):
        output = "make: *** Error\nexit 1"
        assert classify_output(output) == PaneStatus.ERROR

    def test_interactive_yn_prompt(self):
        output = "Do you want to continue? [y/N]"
        assert classify_output(output) == PaneStatus.INTERACTIVE

    def test_interactive_password(self):
        output = "Enter password:"
        assert classify_output(output) == PaneStatus.INTERACTIVE

    def test_interactive_passphrase(self):
        output = "Enter passphrase:"
        assert classify_output(output) == PaneStatus.INTERACTIVE

    def test_interactive_press_any_key(self):
        output = "Press any key to continue"
        assert classify_output(output) == PaneStatus.INTERACTIVE

    def test_running_state(self):
        output = "Downloading packages...\n[####------] 40%"
        assert classify_output(output) == PaneStatus.RUNNING

    def test_running_long_output(self):
        output = "Building...\nstep 1 of 10\nCompiling module A\nstep 2 of 10"
        assert classify_output(output) == PaneStatus.RUNNING


# ═══════════════════════════════════════════════════════════════════════════════
# pick_recovery tests
# ═══════════════════════════════════════════════════════════════════════════════


class TestPickRecovery:

    def test_error_first_attempt_retries(self):
        assert pick_recovery(PaneStatus.ERROR, attempt=1, max_retries=3) == RecoveryAction.RETRY

    def test_error_at_max_escalates(self):
        assert pick_recovery(PaneStatus.ERROR, attempt=3, max_retries=3) == RecoveryAction.ESCALATE

    def test_error_over_max_escalates(self):
        assert pick_recovery(PaneStatus.ERROR, attempt=5, max_retries=3) == RecoveryAction.ESCALATE

    def test_stuck_first_attempt_kills(self):
        assert pick_recovery(PaneStatus.STUCK, attempt=0, max_retries=3) == RecoveryAction.KILL

    def test_stuck_at_max_escalates(self):
        assert pick_recovery(PaneStatus.STUCK, attempt=3, max_retries=3) == RecoveryAction.ESCALATE

    def test_running_is_ignored(self):
        assert pick_recovery(PaneStatus.RUNNING, attempt=0, max_retries=3) == RecoveryAction.IGNORE

    def test_idle_is_ignored(self):
        assert pick_recovery(PaneStatus.IDLE, attempt=0, max_retries=3) == RecoveryAction.IGNORE


# ═══════════════════════════════════════════════════════════════════════════════
# Mock pane for testing WatcherEngine without real tmux
# ═══════════════════════════════════════════════════════════════════════════════


class MockPane:
    """Fake TmuxPane that returns scripted output."""

    def __init__(self, pane_id: str = "%0", session_name: str = "test"):
        self.pane_id = pane_id
        self.session_name = session_name
        self.pane_index = 0
        self._output = ""
        self._sent_commands: list[str] = []
        self._ctrl_c_count = 0

    def set_output(self, text: str) -> None:
        self._output = text

    def capture(self, lines: int = 50) -> str:
        return self._output

    def send(self, cmd: str, press_enter: bool = True) -> None:
        self._sent_commands.append(cmd)

    def send_ctrl_c(self) -> None:
        self._ctrl_c_count += 1

    def kill(self) -> None:
        pass

    def is_alive(self) -> bool:
        return True

    @property
    def target(self) -> str:
        return f"{self.session_name}:0.{self.pane_index}"


class MockObserver:
    """Records all observer callbacks for assertions."""

    def __init__(self):
        self.completed: list[tuple] = []
        self.failed: list[tuple] = []
        self.stuck: list[tuple] = []
        self.interactive: list[tuple] = []

    def on_task_completed(self, pane_id, task_id, output):
        self.completed.append((pane_id, task_id, output))

    def on_task_failed(self, pane_id, task_id, output, recovery):
        self.failed.append((pane_id, task_id, output, recovery))

    def on_task_stuck(self, pane_id, task_id, duration):
        self.stuck.append((pane_id, task_id, duration))

    def on_interactive(self, pane_id, task_id, prompt_line):
        self.interactive.append((pane_id, task_id, prompt_line))


# ═══════════════════════════════════════════════════════════════════════════════
# WatcherEngine tests
# ═══════════════════════════════════════════════════════════════════════════════


class TestWatcherEngine:

    def _make_watcher(self, **kwargs) -> tuple[WatcherEngine, EventBus, MockObserver]:
        bus = EventBus()
        obs = MockObserver()
        watcher = WatcherEngine(event_bus=bus, observer=obs, poll_interval=0.1, **kwargs)
        return watcher, bus, obs

    # ── Tracking ──────────────────────────────────────────────────────────

    def test_track_pane(self):
        watcher, bus, obs = self._make_watcher()
        pane = MockPane(pane_id="%0")
        watcher.track(pane, task_id="t1")

        assert "%0" in watcher.tracked_panes
        assert watcher.tracked_panes["%0"].task_id == "t1"

    def test_untrack_pane(self):
        watcher, bus, obs = self._make_watcher()
        pane = MockPane(pane_id="%0")
        watcher.track(pane, task_id="t1")
        watcher.untrack("%0")

        assert "%0" not in watcher.tracked_panes

    def test_track_emits_event(self):
        watcher, bus, obs = self._make_watcher()
        pane = MockPane(pane_id="%0")
        watcher.track(pane, task_id="t1")

        assert any(e.event_type == "watcher.tracking" for e in bus.history)

    # ── poll_once: DONE ───────────────────────────────────────────────────

    def test_poll_detects_done(self):
        watcher, bus, obs = self._make_watcher()
        pane = MockPane(pane_id="%0")
        pane.set_output("running...\nTASK_COMPLETE\n$ ")
        watcher.track(pane, task_id="t1")

        watcher.poll_once()

        assert watcher.tracked_panes["%0"].status == PaneStatus.DONE
        assert len(obs.completed) == 1
        assert obs.completed[0][1] == "t1"

    def test_poll_done_emits_event(self):
        watcher, bus, obs = self._make_watcher()
        pane = MockPane(pane_id="%0")
        pane.set_output("TASK_COMPLETE")
        watcher.track(pane, task_id="t1")

        watcher.poll_once()

        completed_events = [e for e in bus.history if e.event_type == "task.completed"]
        assert len(completed_events) == 1
        assert completed_events[0].data["task_id"] == "t1"

    # ── poll_once: IDLE (implicit completion) ─────────────────────────────

    def test_poll_detects_idle_as_implicit_complete(self):
        watcher, bus, obs = self._make_watcher()
        pane = MockPane(pane_id="%0")
        pane.set_output("finished work\nuser@host:~$ ")
        watcher.track(pane, task_id="t1")

        watcher.poll_once()

        assert watcher.tracked_panes["%0"].status == PaneStatus.IDLE
        assert len(obs.completed) == 1

    # ── poll_once: ERROR ──────────────────────────────────────────────────

    def test_poll_detects_error(self):
        watcher, bus, obs = self._make_watcher()
        pane = MockPane(pane_id="%0")
        pane.set_output("Traceback (most recent call last):\nNameError: x not defined")
        watcher.track(pane, task_id="t1")

        watcher.poll_once()

        assert watcher.tracked_panes["%0"].status == PaneStatus.ERROR
        assert len(obs.failed) == 1

    def test_error_with_retry_cmd_sends_retry(self):
        watcher, bus, obs = self._make_watcher()
        pane = MockPane(pane_id="%0")
        pane.set_output("Error: something failed")
        watcher.track(pane, task_id="t1", retry_cmd="python retry.py")

        watcher.poll_once()

        assert pane._ctrl_c_count == 1
        assert "python retry.py" in pane._sent_commands

    def test_error_without_retry_cmd_no_send(self):
        watcher, bus, obs = self._make_watcher()
        pane = MockPane(pane_id="%0")
        pane.set_output("Error: something failed")
        watcher.track(pane, task_id="t1")  # no retry_cmd

        watcher.poll_once()

        assert pane._ctrl_c_count == 0
        assert len(pane._sent_commands) == 0

    def test_error_escalates_after_max_retries(self):
        watcher, bus, obs = self._make_watcher(max_retries=2)
        pane = MockPane(pane_id="%0")
        watcher.track(pane, task_id="t1", retry_cmd="python retry.py")

        # First error → retry
        pane.set_output("Error: attempt 1")
        watcher.poll_once()
        assert obs.failed[-1][3] == RecoveryAction.RETRY

        # Force back to RUNNING so next poll sees a state change
        watcher._tracked["%0"].state.status = PaneStatus.RUNNING

        # Second error → retry
        pane.set_output("Error: attempt 2")
        watcher.poll_once()
        assert obs.failed[-1][3] == RecoveryAction.ESCALATE

    # ── poll_once: INTERACTIVE ────────────────────────────────────────────

    def test_poll_detects_interactive(self):
        watcher, bus, obs = self._make_watcher()
        pane = MockPane(pane_id="%0")
        pane.set_output("Install packages? [y/N]")
        watcher.track(pane, task_id="t1")

        watcher.poll_once()

        assert watcher.tracked_panes["%0"].status == PaneStatus.INTERACTIVE
        assert len(obs.interactive) == 1
        assert "[y/N]" in obs.interactive[0][2]

    # ── poll_once: STUCK detection ────────────────────────────────────────

    def test_poll_detects_stuck_after_timeout(self):
        watcher, bus, obs = self._make_watcher(default_timeout=0.0)
        pane = MockPane(pane_id="%0")
        pane.set_output("still working...")
        watcher.track(pane, task_id="t1", timeout_sec=0.0)

        # First poll: RUNNING, records output
        watcher.poll_once()
        assert watcher.tracked_panes["%0"].status == PaneStatus.RUNNING

        # Force last_active to the past
        watcher._tracked["%0"].state.last_active = time.time() - 10

        # Second poll: same output + past deadline → STUCK
        watcher.poll_once()
        assert watcher.tracked_panes["%0"].status == PaneStatus.STUCK
        assert len(obs.stuck) == 1

    # ── poll_once: RUNNING heartbeat ──────────────────────────────────────

    def test_running_pane_heartbeat_increments(self):
        watcher, bus, obs = self._make_watcher()
        pane = MockPane(pane_id="%0")
        pane.set_output("working line 1")
        watcher.track(pane, task_id="t1")

        watcher.poll_once()
        assert watcher.tracked_panes["%0"].heartbeat_count == 1

        pane.set_output("working line 1\nworking line 2")  # output changed
        watcher.poll_once()
        assert watcher.tracked_panes["%0"].heartbeat_count == 2

    # ── No state change → no duplicate events ─────────────────────────────

    def test_same_state_does_not_re_emit(self):
        watcher, bus, obs = self._make_watcher()
        pane = MockPane(pane_id="%0")
        pane.set_output("Downloading...\n[####] 50%")
        watcher.track(pane, task_id="t1")

        watcher.poll_once()
        watcher.poll_once()  # same output, same state

        state_changes = [e for e in bus.history if e.event_type == "watcher.state_change"]
        # Only one state change (UNKNOWN → RUNNING), not two
        assert len(state_changes) == 1

    # ── Multiple panes ────────────────────────────────────────────────────

    def test_multiple_panes_tracked_independently(self):
        watcher, bus, obs = self._make_watcher()
        pane_a = MockPane(pane_id="%0")
        pane_b = MockPane(pane_id="%1")

        pane_a.set_output("TASK_COMPLETE")
        pane_b.set_output("still running 50%")

        watcher.track(pane_a, task_id="t1")
        watcher.track(pane_b, task_id="t2")

        watcher.poll_once()

        assert watcher.tracked_panes["%0"].status == PaneStatus.DONE
        assert watcher.tracked_panes["%1"].status == PaneStatus.RUNNING

    # ── Pane capture failure ──────────────────────────────────────────────

    def test_capture_failure_marks_error(self):
        watcher, bus, obs = self._make_watcher()

        class BrokenPane(MockPane):
            def capture(self, lines=50):
                raise RuntimeError("pane gone")

        pane = BrokenPane(pane_id="%0")
        watcher.track(pane, task_id="t1")

        watcher.poll_once()

        assert watcher.tracked_panes["%0"].status == PaneStatus.ERROR
        assert len(obs.failed) == 1

    # ── stop() ────────────────────────────────────────────────────────────

    def test_stop_sets_flag(self):
        watcher, bus, obs = self._make_watcher()
        watcher._running = True
        watcher.stop()
        assert not watcher.is_running


# ═══════════════════════════════════════════════════════════════════════════════
# Event bus integration
# ═══════════════════════════════════════════════════════════════════════════════


class TestWatcherEvents:

    def test_all_lifecycle_events_emitted(self):
        """Verify that a full lifecycle emits the expected event types."""
        bus = EventBus()
        watcher = WatcherEngine(event_bus=bus, poll_interval=0.1)

        pane = MockPane(pane_id="%0")
        pane.set_output("working...")
        watcher.track(pane, task_id="t1")

        # Poll 1: UNKNOWN → RUNNING
        watcher.poll_once()

        # Poll 2: RUNNING → DONE
        pane.set_output("TASK_COMPLETE")
        watcher.poll_once()

        event_types = [e.event_type for e in bus.history]
        assert "watcher.tracking" in event_types
        assert "watcher.state_change" in event_types
        assert "task.completed" in event_types

    def test_no_events_without_bus(self):
        """Watcher should work fine without an event bus (no crash)."""
        watcher = WatcherEngine(event_bus=None, poll_interval=0.1)
        pane = MockPane(pane_id="%0")
        pane.set_output("TASK_COMPLETE")
        watcher.track(pane, task_id="t1")
        watcher.poll_once()  # should not raise
