"""Tests for the tool registry and built-in tools."""

from __future__ import annotations

import os
import tempfile
from pathlib import Path

import pytest

from alfie.tools.base import Tool, ToolResult
from alfie.tools.registry import ToolRegistry


# ── Registry tests ────────────────────────────────────────────────────────────


class DummyTool(Tool):
    name = "dummy"
    description = "A test tool"
    parameters = {
        "type": "object",
        "properties": {
            "x": {"type": "integer", "description": "A number"},
        },
        "required": ["x"],
    }

    def execute(self, *, x: int = 0, **kwargs) -> ToolResult:
        return ToolResult(tool_name=self.name, output=str(x * 2), success=True)


class FailingTool(Tool):
    name = "fail_tool"
    description = "Always fails"
    parameters = {"type": "object", "properties": {}, "required": []}

    def execute(self, **kwargs) -> ToolResult:
        raise RuntimeError("boom")


def test_registry_register_and_lookup():
    reg = ToolRegistry()
    tool = DummyTool()
    reg.register(tool)

    assert "dummy" in reg
    assert reg.get("dummy") is tool
    assert len(reg) == 1
    assert reg.names == ["dummy"]


def test_registry_call_success():
    reg = ToolRegistry()
    reg.register(DummyTool())

    result = reg.call("dummy", {"x": 5})
    assert result.success
    assert result.output == "10"


def test_registry_call_unknown_tool():
    reg = ToolRegistry()
    result = reg.call("no_such_tool", {})
    assert not result.success
    assert "Unknown tool" in result.output


def test_registry_call_failing_tool():
    reg = ToolRegistry()
    reg.register(FailingTool())

    result = reg.call("fail_tool", {})
    assert not result.success
    assert "Tool error" in result.output


def test_registry_openai_schema():
    reg = ToolRegistry()
    reg.register(DummyTool())

    schemas = reg.to_openai_tools()
    assert len(schemas) == 1
    schema = schemas[0]
    assert schema["type"] == "function"
    assert schema["function"]["name"] == "dummy"
    assert "x" in schema["function"]["parameters"]["properties"]


# ── Built-in tool tests ──────────────────────────────────────────────────────


def test_run_shell_success():
    from alfie.tools.builtin import RunShellTool

    tool = RunShellTool()
    result = tool.execute(command="echo hello")  # works on both Windows and Unix
    assert result.success
    assert "hello" in result.output


def test_run_shell_failure():
    from alfie.tools.builtin import RunShellTool

    tool = RunShellTool()
    result = tool.execute(command="exit 1")
    assert not result.success


def test_run_shell_timeout():
    from alfie.tools.builtin import RunShellTool

    tool = RunShellTool()
    # sleep command that should timeout
    import sys
    if sys.platform == "win32":
        cmd = "Start-Sleep -Seconds 10"
    else:
        cmd = "sleep 10"
    result = tool.execute(command=cmd, timeout_sec=1)
    assert not result.success
    assert "timed out" in result.output


def test_read_file():
    from alfie.tools.builtin import ReadFileTool

    tool = ReadFileTool()
    with tempfile.NamedTemporaryFile(mode="w", suffix=".txt", delete=False, encoding="utf-8") as f:
        f.write("line1\nline2\nline3\n")
        f.flush()
        path = f.name

    try:
        # Full read
        result = tool.execute(path=path)
        assert result.success
        assert "line1" in result.output
        assert "line3" in result.output

        # Range read
        result = tool.execute(path=path, start_line=2, end_line=2)
        assert result.success
        assert "line2" in result.output
        assert "line1" not in result.output
    finally:
        os.unlink(path)


def test_read_file_not_found():
    from alfie.tools.builtin import ReadFileTool

    tool = ReadFileTool()
    result = tool.execute(path="/no/such/file.txt")
    assert not result.success
    assert "not found" in result.output.lower()


def test_write_file():
    from alfie.tools.builtin import WriteFileTool

    tool = WriteFileTool()
    with tempfile.TemporaryDirectory() as tmp:
        path = os.path.join(tmp, "sub", "test.txt")
        result = tool.execute(path=path, content="hello world")
        assert result.success
        assert Path(path).read_text() == "hello world"


def test_edit_file():
    from alfie.tools.builtin import EditFileTool

    tool = EditFileTool()
    with tempfile.NamedTemporaryFile(mode="w", suffix=".txt", delete=False, encoding="utf-8") as f:
        f.write("aaa bbb ccc")
        f.flush()
        path = f.name

    try:
        result = tool.execute(path=path, old_text="bbb", new_text="XXX")
        assert result.success
        assert Path(path).read_text() == "aaa XXX ccc"
    finally:
        os.unlink(path)


def test_edit_file_not_found():
    from alfie.tools.builtin import EditFileTool

    tool = EditFileTool()
    result = tool.execute(path="/no/such/file.txt", old_text="a", new_text="b")
    assert not result.success


def test_edit_file_no_match():
    from alfie.tools.builtin import EditFileTool

    tool = EditFileTool()
    with tempfile.NamedTemporaryFile(mode="w", suffix=".txt", delete=False, encoding="utf-8") as f:
        f.write("hello world")
        f.flush()
        path = f.name

    try:
        result = tool.execute(path=path, old_text="zzz", new_text="XXX")
        assert not result.success
        assert "not found" in result.output
    finally:
        os.unlink(path)


def test_edit_file_multiple_matches():
    from alfie.tools.builtin import EditFileTool

    tool = EditFileTool()
    with tempfile.NamedTemporaryFile(mode="w", suffix=".txt", delete=False, encoding="utf-8") as f:
        f.write("aaa aaa aaa")
        f.flush()
        path = f.name

    try:
        result = tool.execute(path=path, old_text="aaa", new_text="XXX")
        assert not result.success
        assert "3 times" in result.output
    finally:
        os.unlink(path)


def test_list_directory():
    from alfie.tools.builtin import ListDirectoryTool

    tool = ListDirectoryTool()
    with tempfile.TemporaryDirectory() as tmp:
        Path(tmp, "file.txt").touch()
        Path(tmp, "subdir").mkdir()

        result = tool.execute(path=tmp)
        assert result.success
        assert "subdir/" in result.output
        assert "file.txt" in result.output


def test_list_directory_not_found():
    from alfie.tools.builtin import ListDirectoryTool

    tool = ListDirectoryTool()
    result = tool.execute(path="/no/such/dir")
    assert not result.success


# ── Global registry integration ──────────────────────────────────────────────


def test_global_registry_has_builtins():
    from alfie.tools import registry

    assert "run_shell" in registry
    assert "read_file" in registry
    assert "write_file" in registry
    assert "edit_file" in registry
    assert "list_directory" in registry
    assert len(registry) >= 5
