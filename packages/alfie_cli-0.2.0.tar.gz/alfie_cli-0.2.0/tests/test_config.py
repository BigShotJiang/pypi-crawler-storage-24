"""Tests for config loading."""

from alfie.config import AlfieConfig, load_config


class TestConfig:

    def test_default_config(self):
        cfg = AlfieConfig()
        assert cfg.general.default_model == "gpt-4o-mini"
        assert cfg.safety.max_panes == 6
        assert cfg.watcher.poll_interval_sec == 3.0
        assert cfg.logging.level == "INFO"

    def test_load_config_returns_defaults_when_no_file(self):
        cfg = load_config()
        assert isinstance(cfg, AlfieConfig)
        assert cfg.general.default_model == "gpt-4o-mini"
