"""Shared fixtures for ALFIE tests."""

import pytest

from alfie.models import SafetyConfig
from alfie.safety.guard import SafetyGuard
from alfie.events.bus import EventBus


@pytest.fixture
def safety_config() -> SafetyConfig:
    return SafetyConfig()


@pytest.fixture
def guard(safety_config: SafetyConfig) -> SafetyGuard:
    return SafetyGuard(config=safety_config)


@pytest.fixture
def event_bus() -> EventBus:
    return EventBus()
