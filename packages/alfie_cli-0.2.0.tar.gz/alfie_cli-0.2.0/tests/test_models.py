"""Tests for data models."""

from alfie.models import (
    Task, Plan, Session, PaneState, Event, TaskResult,
    TaskStatus, PaneStatus, SessionStatus, SafetyConfig,
)


class TestTaskModel:

    def test_default_task(self):
        task = Task(cmd="echo hello")
        assert task.cmd == "echo hello"
        assert task.status == TaskStatus.PENDING
        assert task.id.startswith("t")
        assert task.depends_on == []
        assert task.timeout_sec == 300

    def test_task_is_terminal(self):
        task = Task(cmd="x", status=TaskStatus.COMPLETED)
        assert task.is_terminal is True

        task2 = Task(cmd="x", status=TaskStatus.RUNNING)
        assert task2.is_terminal is False

    def test_task_duration(self):
        task = Task(cmd="x", started_at=100.0, finished_at=105.5)
        assert task.duration == 5.5

    def test_task_duration_none_when_not_finished(self):
        task = Task(cmd="x", started_at=100.0)
        assert task.duration is None


class TestPlanModel:

    def test_default_plan(self):
        plan = Plan()
        assert plan.model == "gpt-4o-mini"
        assert plan.tasks == []
        assert plan.safety.max_panes == 6

    def test_plan_with_tasks(self):
        plan = Plan(
            intent="test stuff",
            tasks=[Task(cmd="echo a"), Task(cmd="echo b")],
        )
        assert len(plan.tasks) == 2
        assert plan.intent == "test stuff"


class TestSessionModel:

    def test_default_session(self):
        session = Session()
        assert session.status == SessionStatus.PLANNING
        assert session.model == "gpt-4o-mini"
        assert session.id.startswith("alfie_")


class TestEventModel:

    def test_event_creation(self):
        event = Event(event_type="task.started", data={"task_id": "t1"})
        assert event.event_type == "task.started"
        assert event.data["task_id"] == "t1"
        assert event.timestamp > 0


class TestSafetyConfig:

    def test_default_blocked_patterns(self):
        cfg = SafetyConfig()
        assert len(cfg.blocked_patterns) > 0
        assert any("rm" in p for p in cfg.blocked_patterns)
