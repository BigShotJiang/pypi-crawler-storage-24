"""Tests for alfie.runner — high-level run() and execute() API."""

from __future__ import annotations

from unittest.mock import MagicMock, patch

import pytest

from alfie.models import FailureStrategy, Plan, Task
from alfie.runner import RunResult, TaskResult, execute, run


# ── RunResult ─────────────────────────────────────────────────────────────────


class TestRunResult:
    def test_output_combines_completed_tasks(self):
        r = RunResult(
            success=True, intent="test", model="m",
            plan=Plan(intent="test"),
            tasks=[
                TaskResult(id="a", cmd="echo hi", status="completed", exit_code=0, output="hi\n", duration=0.1),
                TaskResult(id="b", cmd="echo bye", status="completed", exit_code=0, output="bye\n", duration=0.1),
                TaskResult(id="c", cmd="fail", status="failed", exit_code=1, output="err", duration=0.1),
            ],
        )
        assert "hi" in r.output
        assert "bye" in r.output
        assert "err" not in r.output  # failed tasks excluded

    def test_output_empty_when_no_completed(self):
        r = RunResult(
            success=False, intent="test", model="m",
            plan=Plan(intent="test"),
            tasks=[
                TaskResult(id="a", cmd="fail", status="failed", exit_code=1, output="err", duration=0.1),
            ],
        )
        assert r.output == ""

    def test_str_representation(self):
        r = RunResult(
            success=True, intent="do stuff", model="m",
            plan=Plan(intent="do stuff"),
            tasks=[
                TaskResult(id="t1", cmd="echo ok", status="completed", exit_code=0, output="ok", duration=0.1),
            ],
        )
        s = str(r)
        assert "SUCCESS" in s
        assert "do stuff" in s
        assert "t1" in s

    def test_str_failed(self):
        r = RunResult(
            success=False, intent="oops", model="m",
            plan=Plan(intent="oops"),
            error="bad key",
        )
        assert "FAILED" in str(r)


# ── execute() ─────────────────────────────────────────────────────────────────


class TestExecute:
    def test_single_task_success(self):
        plan = Plan(
            intent="say hello",
            tasks=[Task(id="t1", cmd="echo hello", on_failure=FailureStrategy.ABORT)],
        )
        result = execute(plan)
        assert result.success is True
        assert len(result.tasks) == 1
        assert result.tasks[0].status == "completed"
        assert "hello" in result.tasks[0].output
        assert result.duration is not None

    def test_multi_task_sequential(self):
        plan = Plan(
            intent="two steps",
            tasks=[
                Task(id="t1", cmd="echo first", on_failure=FailureStrategy.ABORT),
                Task(id="t2", cmd="echo second", depends_on=["t1"], on_failure=FailureStrategy.ABORT),
            ],
        )
        result = execute(plan)
        assert result.success is True
        assert len(result.tasks) == 2
        assert all(t.status == "completed" for t in result.tasks)

    def test_failing_task(self):
        plan = Plan(
            intent="fail",
            tasks=[
                Task(id="t1", cmd="exit 1", on_failure=FailureStrategy.ABORT),
            ],
        )
        result = execute(plan)
        assert result.success is False
        assert result.tasks[0].status == "failed"

    def test_model_override(self):
        plan = Plan(intent="test", model="old-model", tasks=[
            Task(id="t1", cmd="echo ok", on_failure=FailureStrategy.ABORT),
        ])
        result = execute(plan, model="new-model")
        assert result.model == "new-model"

    def test_empty_plan(self):
        plan = Plan(intent="nothing", tasks=[])
        result = execute(plan)
        assert result.success is True
        assert result.tasks == []


# ── run() ─────────────────────────────────────────────────────────────────────


class TestRun:
    @patch("alfie.runner.Planner")
    def test_run_plans_and_executes(self, MockPlanner):
        plan = Plan(
            intent="say hello",
            tasks=[Task(id="t1", cmd="echo hello", on_failure=FailureStrategy.ABORT)],
        )
        mock_instance = MagicMock()
        mock_instance.generate.return_value = plan
        MockPlanner.return_value = mock_instance

        result = run("say hello")
        assert result.success is True
        assert "hello" in result.output
        MockPlanner.assert_called_once_with(model="gpt-4o-mini")
        mock_instance.generate.assert_called_once_with("say hello")

    @patch("alfie.runner.Planner")
    def test_run_dry_run(self, MockPlanner):
        plan = Plan(
            intent="test",
            tasks=[Task(id="t1", cmd="echo hi", on_failure=FailureStrategy.ABORT)],
        )
        mock_instance = MagicMock()
        mock_instance.generate.return_value = plan
        MockPlanner.return_value = mock_instance

        result = run("test", dry_run=True)
        assert result.success is True
        assert result.tasks[0].status == "pending"
        assert result.tasks[0].output == ""  # nothing executed

    @patch("alfie.runner.Planner")
    def test_run_planner_error(self, MockPlanner):
        from alfie.planner import PlannerError

        mock_instance = MagicMock()
        mock_instance.generate.side_effect = PlannerError("no key")
        MockPlanner.return_value = mock_instance

        result = run("anything")
        assert result.success is False
        assert result.error == "no key"

    @patch("alfie.runner.Planner")
    def test_run_runtime_error(self, MockPlanner):
        mock_instance = MagicMock()
        mock_instance.generate.side_effect = RuntimeError("no API key configured")
        MockPlanner.return_value = mock_instance

        result = run("anything")
        assert result.success is False
        assert "API key" in result.error

    @patch("alfie.runner.Planner")
    def test_run_custom_model(self, MockPlanner):
        plan = Plan(
            intent="test",
            tasks=[Task(id="t1", cmd="echo ok", on_failure=FailureStrategy.ABORT)],
        )
        mock_instance = MagicMock()
        mock_instance.generate.return_value = plan
        MockPlanner.return_value = mock_instance

        result = run("test", model="anthropic/claude-sonnet-4-20250514")
        MockPlanner.assert_called_once_with(model="anthropic/claude-sonnet-4-20250514")
        assert result.success is True
