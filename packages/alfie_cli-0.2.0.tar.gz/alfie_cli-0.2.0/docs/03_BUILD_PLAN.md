# ALFIE_CLI — Build Plan & Roadmap

> Phased plan from bare prototype to enterprise-grade autonomous agent orchestrator.

---

## Project Independence

> **This project has ZERO dependencies on any other code in the workspace.**
> The `Agents/` and `PlayR/` folders (if they exist) are unrelated test projects.
> ALFIE_CLI is fully self-contained — all code lives in `src/alfie/`, all tools are built from scratch.
> Do not import, reference, or port code from any sibling directory.

---

## Guiding Philosophy

```
"Make it work → Make it right → Make it fast → Make it extensible"
```

Each phase delivers a **runnable artifact** — no phase is pure design. Every phase ends with something you can demo.

---

## Phase 0: Foundation (The Skeleton)

**Goal:** Project scaffolding, dev environment, core abstractions — zero AI yet.

### Deliverables

```
ALFIE_CLI/
├── pyproject.toml              # Project metadata, deps, entry point
├── README.md                   # Project overview
├── docs/                       # These design docs
├── src/
│   └── alfie/
│       ├── __init__.py
│       ├── cli.py              # CLI entry point (typer)
│       ├── config.py           # Config loader (~/.alfie/config.toml)
│       ├── models.py           # Data models (Task, Plan, Session, PaneState)
│       ├── tmux/
│       │   ├── __init__.py
│       │   ├── session.py      # TmuxSession wrapper
│       │   └── pane.py         # TmuxPane wrapper
│       ├── watcher/
│       │   ├── __init__.py
│       │   └── engine.py       # Watcher poll loop
│       ├── scheduler/
│       │   ├── __init__.py
│       │   └── dag.py          # DAG task scheduler
│       ├── planner/
│       │   ├── __init__.py
│       │   └── base.py         # LLM planner interface
│       ├── safety/
│       │   ├── __init__.py
│       │   └── guard.py        # Command blocklist + confirmation logic
│       ├── events/
│       │   ├── __init__.py
│       │   └── bus.py          # Event bus + logging
│       └── tools/
│           ├── __init__.py
│           └── base.py         # Tool interface
├── tests/
│   ├── conftest.py
│   ├── test_tmux.py
│   ├── test_scheduler.py
│   └── test_safety.py
└── .github/
    └── workflows/
        └── ci.yml              # Lint + test on push
```

### Tasks

- [ ] Initialize project with `pyproject.toml` (hatch/poetry)
- [ ] Define data models with Pydantic: `Task`, `Plan`, `Session`, `PaneState`, `TaskResult`
- [ ] Create minimal CLI with `typer`: `alfie --help`, `alfie version`
- [ ] Set up config system: `~/.alfie/config.toml` with defaults
- [ ] Set up `pytest` + basic CI
- [ ] Write `TmuxSession` and `TmuxPane` wrappers (subprocess or libtmux)
- [ ] Verify tmux bridge: create session, add pane, send command, capture output, kill

### Exit Criteria

```bash
alfie version          # prints "ALFIE_CLI v0.0.1"
alfie tmux-test        # creates a tmux session, runs `echo hello`, captures output, cleans up
pytest                 # all green
```

---

## Phase 1: The Watcher

**Goal:** A working watcher that monitors tmux panes and classifies their state.

### Tasks

- [ ] Implement Watcher poll loop in `watcher/engine.py`
- [ ] Implement state classifier: IDLE, RUNNING, ERROR, DONE, STUCK, INTERACTIVE
- [ ] Add timeout detection (configurable per-task)
- [ ] Add basic recovery: kill stuck pane, retry command
- [ ] Wire watcher to event bus: emit `task.started`, `task.completed`, `task.failed`
- [ ] CLI command: `alfie watch` — manually start watcher on existing tmux session
- [ ] Tests: mock tmux output, verify state transitions

### Exit Criteria

```bash
# In one terminal: start a tmux session with some commands
# In another: alfie watch --session my_session
# Watcher logs state changes as they happen in real-time
```

---

## Phase 2: The Scheduler

**Goal:** Execute a static JSON task plan with DAG ordering and parallel pane execution.

### Tasks

- [ ] Implement DAG engine: topological sort, dependency resolution
- [ ] Implement task state machine: PENDING → QUEUED → RUNNING → COMPLETED/FAILED
- [ ] Wire scheduler to executor: assign tasks to tmux panes
- [ ] Wire scheduler to watcher: watcher reports task completion → scheduler queues dependents
- [ ] Support `max_panes` limit — queue excess tasks
- [ ] Implement retry logic: configurable per-task
- [ ] CLI command: `alfie run --plan plan.json`
- [ ] Tests: verify DAG execution order, parallel groups, retry behavior

### Exit Criteria

```bash
# Create a plan.json with 5 tasks, some parallel, some sequential
alfie run --plan plan.json
# Watch tasks execute in correct order across multiple tmux panes
# All tasks complete, session summary printed
```

---

## Phase 3: The Brain (LLM Planner)

**Goal:** Natural language → task DAG. The AI can now plan work.

### Tasks

- [ ] Implement Planner using **Vercel AI SDK** (`ai` package) — single unified interface
- [ ] Default model: `gpt-4o-mini` — configurable via `alfie --model "model-name"`
- [ ] Model passed straight through to Vercel SDK (any Vercel-listed model works)
- [ ] Context gathering: inject cwd, file tree, git status, OS info into system prompt
- [ ] Structured output parsing: LLM returns JSON plan, validate with Pydantic
- [ ] Confirmation flow: display plan → user approves → scheduler executes
- [ ] Handle DYNAMIC tasks: after task N completes, send output to LLM for next command
- [ ] CLI command: `alfie "natural language request"`
- [ ] Tests: mock LLM responses, verify plan parsing

### Exit Criteria

```bash
alfie "list all Python files and count lines of code in each"
# Uses gpt-4o-mini by default

alfie --model "claude-opus-4-5" "refactor this module"
# User can override model per-invocation

# ALFIE shows plan → User confirms → executes → summary displayed
```

---

## Phase 4: Safety & Self-Healing

**Goal:** Production-grade safety layer and intelligent error recovery.

### Tasks

- [ ] Implement command blocklist (hard block patterns)
- [ ] Implement confirmation prompts for destructive commands
- [ ] Implement resource limits (max panes, max runtime, max LLM calls)
- [ ] Implement kill switch: `alfie kill`, `alfie kill --force`, Ctrl+C handler
- [ ] Self-healing Level 0: retry with same command
- [ ] Self-healing Level 1: retry with modifications (LLM suggests fix)
- [ ] Self-healing Level 2: LLM diagnosis — send error output to LLM, get resolution
- [ ] Self-healing Level 3: escalate to user with full context
- [ ] Interactive prompt detection: auto-handle `[y/N]`, `password:` etc.
- [ ] Tests: verify blocked commands never execute, retry cascades correctly

### Exit Criteria

```bash
alfie "delete all files in home directory"
# ALFIE blocks: "⛔ Blocked: destructive command detected"

alfie "run a failing test and fix it"
# Test fails → ALFIE detects error → LLM diagnoses → applies fix → re-runs → passes
```

---

## Phase 5: Persistence & History

**Goal:** Sessions survive crashes, full audit trail, queryable history.

### Tasks

- [ ] SQLite schema: sessions, tasks, events, outputs
- [ ] Persist session state on every state change (crash recovery)
- [ ] Resume interrupted sessions: `alfie resume <session_id>`
- [ ] Session history: `alfie history` — list past sessions with status
- [ ] Session detail: `alfie history <session_id>` — full task timeline
- [ ] Audit log: `alfie logs` — tail event stream
- [ ] Export: `alfie export <session_id> --format json|csv`

### Exit Criteria

```bash
alfie history
# Shows table of past sessions: ID, date, intent, status, duration

alfie logs --session alfie_20260311_143022
# Streams full event log for that session
```

---

## Phase 6: Tools & Plugins

**Goal:** Extensible tool system — users add domain-specific capabilities.

### Tasks

- [ ] Define `Tool` base class with `execute()` and `parse()` interface
- [ ] Build built-in tools: `shell`, `file_read`, `file_write`, `git`, `python_run`
- [ ] Build `web_search` and `web_crawl` tools **from scratch** (no porting from external code)
- [ ] Tool discovery: scan `~/.alfie/tools/` for custom tools
- [ ] Tool registry: `alfie tools list`, `alfie tools install`
- [ ] LLM tool selection: planner picks relevant tools for the task
- [ ] CLI: `alfie tools create` — scaffold a new tool

### Exit Criteria

```bash
alfie tools list
# shell, file_read, file_write, git, python_run, web_search, web_crawl

alfie "search the web for Python best practices 2026 and summarize"
# ALFIE selects web_search + web_crawl tools, executes, summarizes
```

---

## Phase 7: Developer Experience & Polish

**Goal:** Make it feel professional — a tool you'd proudly ship.

### Tasks

- [ ] Rich terminal UI: live dashboard showing pane states, progress bars, task tree
- [ ] Interactive mode: `alfie` with no args → REPL with streaming output
- [ ] Notifications: desktop notification on session complete (via `notify-send` / `osascript`)
- [ ] Shell completions: bash, zsh, fish
- [ ] Man page / rich `--help` output
- [ ] `alfie doctor` — check system requirements (tmux version, Python version, Vercel API key)
- [ ] `alfie init` — first-run setup wizard
- [ ] Comprehensive README with GIFs/screenshots
- [ ] PyPI publish: `pip install alfie-cli`

### Exit Criteria

```bash
pip install alfie-cli
alfie doctor     # ✅ tmux 3.x, ✅ Python 3.11+, ✅ Vercel AI API key
alfie init       # Creates ~/.alfie/ with default config
alfie "hello"    # Full working pipeline
```

---

## Milestone Summary

| Phase | Name | Core Deliverable | Priority |
|-------|------|-----------------|----------|
| 0 | Foundation | Project skeleton + tmux bridge | P0 — Start here |
| 1 | Watcher | Pane monitoring + state classification | P0 |
| 2 | Scheduler | DAG execution engine | P0 |
| 3 | Brain | LLM planning from natural language | P0 |
| 4 | Safety | Blocklist + self-healing + kill switch | P0 |
| 5 | Persistence | SQLite history + crash recovery | P1 |
| 6 | Tools | Plugin system + built-in tools | P1 |
| 7 | Polish | CLI UX, packaging, docs | P2 |

**v0.1 = Phase 0-3** (functional prototype — can plan and execute from natural language)
**v0.5 = Phase 0-5** (production-ready — safe, persistent, recoverable)
**v1.0 = Phase 0-7** (ship it — polished, extensible, published)

---

## Decisions Log (Resolved)

| # | Question | Decision |
|---|----------|----------|
| 1 | **Naming** | `alfie_cli` — CLI command is `alfie` |
| 2 | **LLM SDK** | Vercel AI SDK for Python (`ai`) — single API key, all models |
| 3 | **Default model** | `gpt-4o-mini` — user-configurable via `--model` |
| 4 | **WSL** | Deferred — build on Windows first, WSL support later |
| 5 | **Packaging** | Single `alfie` package |
| 6 | **License** | MIT |
| 7 | **Workspace** | `ALFIE_CLI/` in current workspace |
| 8 | **External code** | **Zero dependency** on Agents/, PlayR/, or any other workspace code |

---

*These docs live in `ALFIE_CLI/docs/`. All major decisions are finalized.*
*Ready to build. Start with Phase 0.*
