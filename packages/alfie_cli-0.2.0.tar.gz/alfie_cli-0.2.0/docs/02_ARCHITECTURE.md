# ALFIE_CLI — Architecture Deep Dive

> System design for a production-grade, self-healing terminal agent orchestrator.

---

## 1. High-Level Architecture

```
┌─────────────────────────────────────────────────────────────────────┐
│                          ALFIE_CLI                                  │
│                                                                     │
│  ┌──────────┐    ┌──────────────┐    ┌──────────────┐              │
│  │   CLI    │───▶│   Planner    │───▶│  Scheduler   │              │
│  │ Interface│    │  (LLM Core)  │    │  (DAG Engine)│              │
│  └──────────┘    └──────────────┘    └──────┬───────┘              │
│                                             │                       │
│                         ┌───────────────────┼───────────────────┐   │
│                         │                   │                   │   │
│                         ▼                   ▼                   ▼   │
│                  ┌────────────┐      ┌────────────┐     ┌──────────┐│
│                  │  Executor  │      │  Executor  │     │ Executor ││
│                  │  (Pane 0)  │      │  (Pane 1)  │     │ (Pane N) ││
│                  └─────┬──────┘      └─────┬──────┘     └────┬─────┘│
│                        │                   │                 │      │
│                  ┌─────▼───────────────────▼─────────────────▼─────┐│
│                  │              WATCHER ENGINE                      ││
│                  │  Monitors output · Detects states · Self-heals   ││
│                  └─────────────────────┬───────────────────────────┘│
│                                        │                            │
│                  ┌─────────────────────▼───────────────────────────┐│
│                  │              EVENT BUS / LOG STORE               ││
│                  │  Audit trail · Metrics · Status broadcasts       ││
│                  └─────────────────────────────────────────────────┘│
└─────────────────────────────────────────────────────────────────────┘
                              │
                    ┌─────────▼──────────┐
                    │   tmux (Runtime)   │
                    │   Real shell procs │
                    └────────────────────┘
```

---

## 2. Component Breakdown

### 2.1 CLI Interface

**Responsibility:** Parse user input, display progress, handle confirmations.

```
alfie "run tests and fix failures"        # Natural language
alfie run --plan plan.json                 # Pre-defined plan
alfie status                               # Check running session
alfie logs                                 # Tail audit log
alfie kill                                 # Emergency stop
alfie history                              # Past sessions
```

**Tech choices:**
- `click` or `typer` for CLI framework (type-safe, auto-help)
- `rich` for terminal UI (progress bars, tables, panels, live display)
- Config via `~/.alfie/config.toml`

---

### 2.2 Planner (LLM Core)

**Responsibility:** Convert natural language intent into a structured execution plan (DAG of tasks).

**Input:** User prompt + system context (current dir, OS, available tools, project type)

**Output:** A Task DAG in JSON:

```json
{
  "session_id": "alfie_20260311_143022",
  "intent": "run tests and fix failures",
  "tasks": [
    {
      "id": "t1",
      "cmd": "pytest --tb=short -q 2>&1 | tee /tmp/alfie_t1.log",
      "description": "Run test suite",
      "depends_on": [],
      "timeout_sec": 120,
      "retry": { "max": 2, "backoff": "exponential" },
      "on_failure": "escalate"
    },
    {
      "id": "t2",
      "cmd": "DYNAMIC",
      "description": "Analyze failures and generate fixes",
      "depends_on": ["t1"],
      "type": "llm_step",
      "input_from": "t1.output",
      "timeout_sec": 60
    },
    {
      "id": "t3",
      "cmd": "DYNAMIC",
      "description": "Apply fixes and re-run tests",
      "depends_on": ["t2"],
      "timeout_sec": 120,
      "retry": { "max": 3 }
    }
  ],
  "parallel_groups": [["t1"], ["t2"], ["t3"]],
  "safety": {
    "confirm_destructive": true,
    "max_panes": 4,
    "max_runtime_sec": 600,
    "blocked_patterns": ["rm -rf /", ":(){ :|:& };:", "dd if=", "> /dev/sd"]
  }
}
```

**Key design decisions:**
- **DAG, not linear list.** Tasks can have dependencies and run in parallel groups.
- **DYNAMIC commands.** Some tasks don't have a static command — the LLM generates the command at runtime based on previous task output. This is what makes ALFIE truly adaptive.
- **Safety metadata per task.** Each task carries retry policy, timeout, and failure strategy.

**LLM Provider — Vercel AI SDK:**

We use the **Vercel AI SDK for Python** (`ai` package) which provides a unified interface to all major model providers with a single API key. No need for separate provider classes.

```python
from ai import generate_text

response = generate_text(
    model="gpt-4o-mini",   # default — fast + cheap
    system=SYSTEM_PROMPT,
    prompt=user_request,
)
```

Users select their model at runtime:
```bash
alfie "scan for bugs"                        # uses default: gpt-4o-mini
alfie --model "claude-opus-4-5" "scan for bugs"    # user override
alfie --model "gpt-5.2" "scan for bugs"      # any Vercel-supported model
```

The model name is passed straight through to the Vercel SDK — if Vercel supports it, ALFIE supports it. Zero provider abstraction needed.

---

### 2.3 Scheduler (DAG Engine)

**Responsibility:** Execute the task DAG in correct order, respecting dependencies and parallelism.

```
States: PENDING → QUEUED → RUNNING → {COMPLETED | FAILED | TIMEOUT | SKIPPED}
```

**Behavior:**
- On session start: all root tasks (no dependencies) → QUEUED
- As each task completes: evaluate downstream dependents, queue them if all deps met
- Parallel tasks within the same group run in separate tmux panes
- Respects `max_panes` limit — excess tasks wait in queue

**Implementation approach:**
- Python `asyncio` event loop for scheduling
- Task state tracked in an in-memory state machine
- Persistent to disk (SQLite or JSON) for crash recovery

---

### 2.4 Executor (tmux Bridge)

**Responsibility:** Interface between ALFIE and tmux — create panes, send commands, capture output.

**Core operations:**

| Operation | tmux Command | Python Wrapper |
|-----------|-------------|----------------|
| Create session | `tmux new-session -d -s {name}` | `TmuxSession.create()` |
| Add pane | `tmux split-window` | `session.add_pane()` |
| Send command | `tmux send-keys -t {target} "{cmd}" Enter` | `pane.send(cmd)` |
| Capture output | `tmux capture-pane -p -t {target}` | `pane.capture()` |
| Kill pane | `tmux kill-pane -t {target}` | `pane.kill()` |
| Kill session | `tmux kill-session -t {name}` | `session.destroy()` |

**Abstraction layer:**
```python
class TmuxSession:
    """Manages a tmux session lifecycle."""
    def create(name: str, window_size: tuple) -> 'TmuxSession'
    def add_pane() -> 'TmuxPane'
    def list_panes() -> list['TmuxPane']
    def destroy() -> None

class TmuxPane:
    """Represents a single tmux pane (one agent/task workspace)."""
    def send(cmd: str) -> None
    def capture(lines: int = 50) -> str
    def kill() -> None
    def is_alive() -> bool
```

**Cross-platform note:**
- Linux/macOS: native tmux
- Windows: WSL2 required (tmux runs inside WSL)
- Future: abstract to support Windows Terminal panes natively (or ConPTY)

---

### 2.5 Watcher Engine

**Responsibility:** The nervous system — continuously monitors all active panes and reacts.

**Poll loop (every N seconds):**

```
for each active pane:
    output = pane.capture()
    state  = classify(output)

    match state:
        case IDLE:     → scheduler.task_complete(pane.task_id)
        case ERROR:    → attempt_recovery(pane)
        case TIMEOUT:  → kill_and_retry(pane)
        case RUNNING:  → update_heartbeat(pane)
        case WAITING:  → check_if_interactive_prompt(pane)
```

**State classification strategies:**

| Signal | Detection Method | Action |
|--------|-----------------|--------|
| Task done | Prompt returned (`$ `, `>>> `) or sentinel string `TASK_COMPLETE` | Mark complete, queue next |
| Error | Keywords: `error`, `traceback`, `fatal`, `FAILED`, exit code != 0 | Trigger recovery |
| Stuck | No output change for > timeout period | Kill + retry or escalate |
| Interactive prompt | Detected `[y/N]`, `password:`, `Press any key` | Auto-respond or escalate to user |
| OOM / crash | Process disappeared, `Killed`, `segfault` | Log, restart with lower resource config |

**Self-healing strategies:**

```
Level 0: Retry same command (transient failures)
Level 1: Retry with modifications (add flags, reduce batch size)
Level 2: Ask LLM to diagnose and suggest fix
Level 3: Escalate to user with full context
```

---

### 2.6 Event Bus / Log Store

**Responsibility:** Central nervous system for inter-component communication and audit trail.

**Events emitted:**
```
task.queued      { task_id, cmd, timestamp }
task.started     { task_id, pane_id, timestamp }
task.output      { task_id, line, timestamp }
task.completed   { task_id, exit_code, duration, output_summary }
task.failed      { task_id, error, retry_count }
task.retrying    { task_id, strategy, attempt }
session.started  { session_id, plan, timestamp }
session.finished { session_id, summary, duration }
watcher.alert    { pane_id, alert_type, details }
safety.blocked   { task_id, reason, cmd }
```

**Storage:**
- **Hot:** In-memory event queue (for watcher + scheduler real-time use)
- **Warm:** SQLite database at `~/.alfie/history.db` (for `alfie history`, `alfie logs`)
- **Cold (future):** Export to JSON/Parquet for analytics

---

## 3. Data Flow — Full Lifecycle

```
User: "alfie run tests and fix failures"
  │
  ▼
[CLI Interface]
  │ Parse input, gather context (cwd, project type, git status)
  ▼
[Planner / LLM]
  │ Generate task DAG
  │ Return JSON plan
  ▼
[CLI Interface]
  │ Display plan to user
  │ "Execute? (y/N)"
  ▼
[Scheduler]
  │ Create tmux session
  │ Queue root tasks
  │ Assign to panes
  ▼
[Executor] ←──────── [Watcher] (polling loop)
  │                       │
  │ pane.send(cmd)        │ pane.capture()
  │                       │ classify state
  ▼                       │ trigger actions
[tmux panes]              │
  │                       │
  │ output ───────────────┘
  │
  ▼
[Event Bus]
  │ Log everything
  │ Broadcast state changes
  ▼
[Scheduler]
  │ Evaluate DAG: queue downstream tasks
  │ When all done → session complete
  ▼
[CLI Interface]
  │ Display summary
  │ "✅ All tasks complete. 3/3 passed."
  ▼
[Log Store]
  │ Persist full session to ~/.alfie/history.db
  ▼
Done.
```

---

## 4. Safety Architecture

This is **non-negotiable** for an autonomous system.

### 4.1 Command Blocklist (Hard Block)

Commands matching these patterns are **never executed**, regardless of confirmation:

```python
BLOCKED_PATTERNS = [
    r"rm\s+-rf\s+/",           # nuke root
    r":\(\)\s*\{",              # fork bomb
    r"dd\s+if=.*/dev/",        # disk overwrite
    r"mkfs\.",                  # format filesystem
    r">\s*/dev/sd",             # write to raw disk
    r"chmod\s+-R\s+777\s+/",   # permission nuke
    r"curl.*\|\s*sh",          # pipe to shell (untrusted)
    r"wget.*\|\s*bash",        # pipe to shell (untrusted)
]
```

### 4.2 Confirmation Required (Soft Block)

These require explicit user `y` before execution:

- Any `git push` (especially `--force`)
- Any `rm` or `del` on non-temp paths
- Any `sudo` command
- Network calls to external hosts
- File writes outside project directory
- Package installs (`pip install`, `npm install`, `apt install`)

### 4.3 Resource Limits

```toml
# ~/.alfie/config.toml
[safety]
max_panes = 6                    # Don't fork-bomb your machine
max_session_runtime_sec = 1800   # 30 min hard cap
max_single_task_sec = 300        # 5 min per task
max_llm_calls_per_session = 50   # Budget guard
max_retry_per_task = 3           # Don't infinite loop
```

### 4.4 Kill Switch

```bash
alfie kill                       # Graceful: finish current, stop queue
alfie kill --force               # Immediate: kill all panes, destroy session
Ctrl+C during execution          # Same as alfie kill
```

### 4.5 Sandboxing (Future: v2+)

- Run tasks inside Docker containers for full isolation
- Use `firejail` or `bubblewrap` for lightweight sandboxing
- Network namespace isolation for untrusted commands

---

## 5. Plugin / Tool System

ALFIE should be **extensible** — users add domain-specific tools.

### Tool Interface

```python
from alfie.tools import Tool, ToolResult

class SecurityScanTool(Tool):
    name = "security_scan"
    description = "Run Bandit + Semgrep on Python codebase"

    def execute(self, context: dict) -> ToolResult:
        # This runs as a task in a tmux pane
        return ToolResult(
            cmd="bandit -r . -f json -o /tmp/bandit.json && semgrep --config auto -o /tmp/semgrep.json .",
            output_parser=self.parse_results
        )

    def parse_results(self, raw_output: str) -> dict:
        # Structured extraction from tool output
        ...
```

### Built-in Tools (v1.0)

| Tool | Purpose |
|------|---------|
| `shell` | Execute arbitrary shell commands |
| `file_read` | Read file contents (feeds to LLM) |
| `file_write` | Write/patch files |
| `git` | Git operations (status, commit, push, branch) |
| `python_run` | Execute Python scripts |
| `web_search` | Google search via API |
| `web_crawl` | Crawl and extract page content |

### Tool Discovery

```bash
alfie tools list                 # Show available tools
alfie tools install <name>       # Install from registry
alfie tools create               # Scaffold a new tool
```

---

## 6. Tech Stack Summary

| Layer | Technology | Why |
|-------|-----------|-----|
| CLI Framework | `typer` + `rich` | Type-safe, beautiful terminal UI |
| LLM Interface | **Vercel AI SDK** (`ai` package) | Single API key, all providers, unified interface |
| Process Management | `tmux` via `libtmux` | Battle-tested, scriptable terminal multiplexer |
| Task Scheduling | `asyncio` + custom DAG | Lightweight, no external deps |
| State Persistence | `SQLite` via `aiosqlite` | Zero-config, file-based, fast |
| Configuration | `tomli` / `tomllib` | Clean config format |
| Testing | `pytest` + `pytest-asyncio` | Standard Python testing |
| Packaging | `pyproject.toml` + `hatch` | Modern Python packaging, single `alfie` package |

---

## 7. Design Decisions (Resolved)

| # | Question | Decision | Notes |
|---|----------|----------|-------|
| 1 | tmux abstraction library? | `libtmux` (Python) | Cleaner API, well-maintained |
| 2 | LLM provider strategy? | **Vercel AI SDK** (`ai`) | Single API key, all models, zero provider wrappers |
| 3 | Default model? | `gpt-4o-mini` | Fast + cheap for dev; user overrides via `--model` |
| 4 | Task plan format? | JSON | LLMs output it natively |
| 5 | Watcher polling vs events? | Poll every 2-5 sec | Simpler, good enough |
| 6 | Session persistence? | Disk (SQLite) | Crash recovery + history |
| 7 | Windows support? | Build on Windows now; WSL deferred | Pragmatic — revisit later |
| 8 | Plugin security? | Trust-but-verify for v1 | Sandbox in v2 |
| 9 | External code dependencies? | **Zero** | No imports from Agents/, PlayR/, or any sibling folder |

---

*Next: [03_BUILD_PLAN.md](./03_BUILD_PLAN.md) — Phased build plan with milestones*
