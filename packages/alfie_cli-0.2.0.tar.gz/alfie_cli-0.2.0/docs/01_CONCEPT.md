# ALFIE_CLI — Concept Document

> **Artificial Lifeform Intelligent Entity**
> A terminal-native AI agent orchestrator that plans, executes, monitors, and self-heals shell-level tasks using LLM reasoning + tmux process management.

---

## 0. Project Independence

> **ALFIE_CLI is a fully standalone project.** It has **zero dependencies** on any other code in this workspace. The `Agents/` and `PlayR/` folders (or any other sibling directories) are unrelated test projects and must never be imported, referenced, or assumed to exist. ALFIE_CLI builds everything from scratch within its own `src/alfie/` package.

---

## 1. The Problem

Today's AI coding assistants (Copilot, Claude, ChatGPT) are **conversational** — they wait for you, respond, then wait again. They:

- Can't run persistent background processes
- Can't spawn parallel workers
- Can't monitor long-running tasks
- Can't self-recover from failures
- Can't operate autonomously on your system

You end up being the glue — copy-pasting commands, babysitting output, re-running on failure. That's wasted human time.

---

## 2. The Vision

**ALFIE_CLI** bridges the gap between *"AI that talks"* and *"AI that works."*

```
YOU: "alfie scan this repo for vulnerabilities, fix what you can, and open PRs for the rest"

ALFIE:
  1. Plans the work (LLM reasoning)
  2. Spawns tmux panes for parallel execution
  3. Runs security scanners, code fixers, git operations
  4. Monitors each pane via Watcher
  5. Self-heals on errors (retry, fallback, escalate)
  6. Reports back with a summary
```

The human gives **intent**. ALFIE handles **execution**.

---

## 3. Core Principles

| Principle | Description |
|-----------|-------------|
| **Intent-Driven** | User speaks in natural language. ALFIE translates to executable plans. |
| **Autonomous** | Once a plan is approved, ALFIE runs to completion without hand-holding. |
| **Observable** | Every action is logged, every pane is visible. Full transparency. |
| **Self-Healing** | Detects errors, retries with backoff, tries alternative approaches. |
| **Safe by Default** | Destructive commands require confirmation. Sandboxed execution. Kill switches. |
| **Composable** | Tasks, tools, and agents are modular building blocks. |
| **Local-First** | Runs on your machine. Your data stays yours. |

---

## 4. What ALFIE_CLI Is NOT

- **Not a chatbot.** It's an executor. Conversation is just the interface for giving intent.
- **Not a cloud service.** Runs locally on your terminal. No vendor lock-in.
- **Not an IDE plugin.** It's infrastructure-level — it orchestrates terminals, processes, and files.
- **Not a replacement for CI/CD.** It's for ad-hoc, dynamic, LLM-planned workflows — not static pipelines.

---

## 5. Key Use Cases

### Developer Workflows
- "Run my test suite, fix any failures, re-run until green, then commit"
- "Refactor all files in `src/` to use async/await"
- "Set up a new Python project with Poetry, pre-commit hooks, and CI config"

### DevOps / SysAdmin
- "Monitor my 3 servers — alert me if any go down"
- "Deploy this to staging, run smoke tests, promote to prod if green"
- "Audit all running Docker containers and clean up orphans"

### Research / Data
- "Scrape these 50 URLs, extract tables, combine into a CSV"
- "Run this training script on 3 different hyperparameter configs in parallel"
- "Download all papers from this ArXiv search and summarize each"

### Security
- "Scan this codebase with Bandit + Semgrep, triage findings by severity"
- "Check all dependencies for known CVEs"
- "Pen-test this local API endpoint with common attack vectors"

---

## 6. How It Differs From Existing Tools

| Tool | What It Does | ALFIE's Edge |
|------|-------------|--------------|
| **GitHub Copilot** | Autocompletes code in editor | ALFIE *executes* across your whole system |
| **Claude Code** | AI pair programmer in terminal | ALFIE orchestrates *multiple* parallel agents |
| **AutoGPT / CrewAI** | LLM agent loops | ALFIE uses *real shell processes*, not simulated tools |
| **Ansible / Terraform** | Infrastructure automation | ALFIE plans dynamically with LLM — no static playbooks |
| **tmux alone** | Terminal multiplexer | ALFIE adds AI brain + watcher + self-healing |

---

## 7. The "Why Now" Moment

- LLM APIs are cheap, fast, and capable of structured output (JSON task plans)
- tmux is battle-tested, free, and available everywhere
- Python's subprocess + asyncio make orchestration trivial
- The developer tooling market is exploding — there's a gap for *autonomous local agents*
- Open-source community would eat this up under P-Typed Research Labs

---

## 8. Key Technical Decisions

| Decision | Choice | Rationale |
|----------|--------|-----------|
| **Project Name** | `alfie_cli` (CLI command: `alfie`) | Clear, memorable, consistent |
| **LLM SDK** | **Vercel AI SDK for Python** (`ai` package) | Single API key, access to all providers (OpenAI, Anthropic, Google, etc.) |
| **Default Model** | `gpt-4o-mini` | Fast + cheap for dev/test; user-configurable via `--model` |
| **Packaging** | Single `alfie` package | Simple, no multi-package overhead |
| **License** | MIT | Maximum adoption, community-friendly |
| **Workspace** | Builds in `ALFIE_CLI/` within current workspace | No external repo needed initially |
| **Windows/WSL** | Build on Windows first; WSL support deferred | Pragmatic — work where we are |
| **External deps** | **Zero** dependency on any other workspace code | Fully standalone project |

---

## 9. Success Criteria for v1.0

- [ ] Single command (`alfie "do X"`) triggers full autonomous workflow
- [ ] User-configurable model via `alfie --model "model-name"` flag
- [ ] Parallel pane execution with real-time monitoring
- [ ] Self-healing with retry + fallback strategies
- [ ] Full audit log of every action taken
- [ ] Safety layer: confirmation for destructive ops, kill switch, resource limits
- [ ] Plugin system for custom tools/agents
- [ ] Works on Linux and macOS (Windows via WSL)
- [ ] Clean CLI UX with rich terminal output

---

*Next: [02_ARCHITECTURE.md](./02_ARCHITECTURE.md) — Deep dive into system design*
