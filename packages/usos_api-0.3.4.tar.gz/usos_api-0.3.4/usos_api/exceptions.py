class USOSAPIException(Exception):
    pass
