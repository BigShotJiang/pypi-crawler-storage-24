"""Run the MCP server with: python -m mysql_mcp"""
from .server import main

if __name__ == "__main__":
    main()
