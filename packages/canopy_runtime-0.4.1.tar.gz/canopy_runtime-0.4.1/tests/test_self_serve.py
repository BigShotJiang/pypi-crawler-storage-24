from __future__ import annotations

import subprocess
import venv
from pathlib import Path

import pytest
from fastapi.testclient import TestClient

from canopy.self_check import main as self_check_main
from canopy.service import app


def test_gateway_is_safe_by_default(monkeypatch, tmp_path: Path):
    monkeypatch.delenv("CANOPY_API_KEYS", raising=False)
    monkeypatch.delenv("CANOPY_ALLOW_INSECURE_GATEWAY", raising=False)
    monkeypatch.setenv("CANOPY_CONTROL_PLANE_DB", str(tmp_path / "control-plane.db"))
    client = TestClient(app)
    res = client.get("/v1/dashboard")
    assert res.status_code == 503
    assert "CANOPY_API_KEYS" in res.json()["detail"]


def test_gateway_can_run_in_explicit_insecure_local_mode(monkeypatch, tmp_path: Path):
    monkeypatch.delenv("CANOPY_API_KEYS", raising=False)
    monkeypatch.setenv("CANOPY_ALLOW_INSECURE_GATEWAY", "true")
    monkeypatch.setenv("CANOPY_CONTROL_PLANE_DB", str(tmp_path / "control-plane.db"))
    client = TestClient(app)
    health = client.get("/healthz")
    assert health.status_code == 200
    assert health.json()["auth_mode"] == "insecure_local"
    dashboard = client.get("/v1/dashboard")
    assert dashboard.status_code == 200


def test_self_check_runtime_passes(monkeypatch, tmp_path: Path, capsys):
    monkeypatch.delenv("CANOPY_POLICY_FILE", raising=False)
    rc = self_check_main(["--audit-log", str(tmp_path / "audit.log")])
    out = capsys.readouterr().out
    assert rc == 0
    assert "CANOPY SELF-CHECK" in out
    assert "[PASS] runtime" in out


def test_self_check_gateway_fails_without_auth(monkeypatch, tmp_path: Path, capsys):
    monkeypatch.delenv("CANOPY_API_KEYS", raising=False)
    monkeypatch.delenv("CANOPY_ALLOW_INSECURE_GATEWAY", raising=False)
    rc = self_check_main(["--gateway", "--audit-log", str(tmp_path / "audit.log")])
    out = capsys.readouterr().out
    assert rc == 1
    assert "[FAIL] gateway-auth" in out


def test_built_wheel_supports_clean_runtime_import(tmp_path: Path):
    repo = Path(__file__).resolve().parents[1]
    wheel = repo / "dist" / "canopy_runtime-0.4.0-py3-none-any.whl"
    if not wheel.exists():
        pytest.skip("wheel artifact not present; packaging smoke runs separately in CI")

    env_dir = tmp_path / "wheel-smoke"
    venv.EnvBuilder(with_pip=True).create(env_dir)
    python = env_dir / "bin" / "python"
    pip = env_dir / "bin" / "pip"

    subprocess.run([str(pip), "install", "--no-deps", str(wheel)], check=True, cwd=repo)
    probe = (
        "import canopy; "
        "from canopy.core import authorize_action; "
        "r=authorize_action({'public_key':'pk','created_at':'2026-01-01T00:00:00Z'},"
        "'execute_shell',{'command':'echo hi'}); "
        "print(r['decision'])"
    )
    result = subprocess.run([str(python), "-c", probe], check=True, cwd=repo, capture_output=True, text=True)
    assert result.stdout.strip() in {"ALLOW", "REQUIRE_APPROVAL", "DENY"}
