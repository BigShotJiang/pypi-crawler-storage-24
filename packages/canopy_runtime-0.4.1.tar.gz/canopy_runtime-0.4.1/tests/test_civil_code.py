from __future__ import annotations

from pathlib import Path

from canopy.core import authorize_action


CREATED_AT = "2026-03-15T00:00:00Z"


def test_title_ii_spend_requires_approval_without_limit(tmp_path: Path):
    audit_path = tmp_path / "audit.log"
    res = authorize_action(
        {"public_key": "pk", "created_at": CREATED_AT},
        "spend_money",
        {"amount": 25.0},
        audit_log_path=audit_path,
    )
    assert res["decision"] == "REQUIRE_APPROVAL"
    assert res["layers"]["civil_code"].startswith("blocked (Title II")
    assert res.get("override_possible") is True
    assert "spending_limit" in str(res.get("override_key") or "")


def test_title_ii_spend_allows_under_configured_limit(tmp_path: Path):
    audit_path = tmp_path / "audit.log"
    policy = tmp_path / "policy.yaml"
    policy.write_text('rules:\n  - action_type: "noop"\n    deny_if: "never"\n', encoding="utf-8")
    res = authorize_action(
        {"public_key": "pk", "created_at": CREATED_AT, "spending_limit": 100.0},
        "spend_money",
        {"amount": 50.0},
        audit_log_path=audit_path,
        policy_file=policy,
        skip_firewall=True,
    )
    assert res["decision"] == "ALLOW"


def test_title_ii_spend_unlimited_allows(tmp_path: Path):
    audit_path = tmp_path / "audit.log"
    policy = tmp_path / "policy.yaml"
    policy.write_text('rules:\n  - action_type: "noop"\n    deny_if: "never"\n', encoding="utf-8")
    res = authorize_action(
        {"public_key": "pk", "created_at": CREATED_AT, "spending_limit": "unlimited"},
        "spend_money",
        {"amount": 1_000_000.0},
        audit_log_path=audit_path,
        policy_file=policy,
        skip_firewall=True,
    )
    assert res["decision"] == "ALLOW"


def test_title_vi_mining_denied_without_authorization(tmp_path: Path):
    audit_path = tmp_path / "audit.log"
    res = authorize_action(
        {"public_key": "pk", "created_at": CREATED_AT, "autonomous_mode": True},
        "execute_shell",
        {"command": "xmrig --help"},
        audit_log_path=audit_path,
    )
    assert res["decision"] == "DENY"
    assert res["layers"]["civil_code"].startswith("blocked (Title VI")
    assert res.get("override_possible") is True
    assert res.get("override_key") == "agent_ctx['mining_authorized'] = True"


def test_title_vi_mining_allowed_with_authorization(tmp_path: Path):
    audit_path = tmp_path / "audit.log"
    res = authorize_action(
        {"public_key": "pk", "created_at": CREATED_AT, "autonomous_mode": True, "mining_authorized": True},
        "execute_shell",
        {"command": "xmrig --help"},
        audit_log_path=audit_path,
    )
    assert res["decision"] == "ALLOW"


def test_title_vii_drone_denied_without_physical_actions(tmp_path: Path):
    audit_path = tmp_path / "audit.log"
    res = authorize_action(
        {"public_key": "pk", "created_at": CREATED_AT},
        "deploy_drone",
        {"target": "x"},
        audit_log_path=audit_path,
    )
    assert res["decision"] == "DENY"
    assert res["layers"]["civil_code"].startswith("blocked (Title VII")


def test_title_ix_modify_constitution_denied_no_override(tmp_path: Path):
    audit_path = tmp_path / "audit.log"
    res = authorize_action(
        {"public_key": "pk", "created_at": CREATED_AT, "autonomous_mode": True},
        "modify_file",
        {"path": "/tmp/constitution.py", "content": "x"},
        audit_log_path=audit_path,
    )
    assert res["decision"] == "DENY"
    assert res["layers"]["civil_code"].startswith("blocked (Title IX")
    assert res.get("override_possible") is False
    assert res.get("override_key") is None
