from __future__ import annotations

import json
from pathlib import Path

import pytest

from canopy.approval import (
    approval_artifact_path,
    format_approval_request,
    format_approval_webhook,
    prompt_for_approval,
    write_approval_artifact,
)
from canopy.audit import HashChainAuditLog
from canopy.formatting import format_decision
from canopy.lint import lint_policy, main as lint_main
from canopy.verify import main as verify_main


def _sample_result() -> dict:
    return {
        "decision": "REQUIRE_APPROVAL",
        "reason": "Firewall: high-risk command requires approval (matched 'curl')",
        "severity": "high",
        "avid": "AVID-123",
        "action_type": "execute_shell",
        "authorization_id": "auth-123",
        "layers": {
            "constitution": "pass",
            "civil_code": "pass",
            "firewall": "blocked (require_approval)",
            "policy": "skipped",
        },
    }


def test_format_decision_human_readable():
    text = format_decision(
        {
            "decision": "DENY",
            "severity": "critical",
            "reason": "Destructive deletion from filesystem root.",
            "authorization_id": "9c2f3a",
            "layers": {
                "constitution": "blocked (Art.0)",
                "civil_code": "skipped",
                "firewall": "skipped",
                "policy": "skipped",
            },
        }
    )
    assert "Decision   : DENY [critical]" in text
    assert "Blocked by : Constitution (Art.0)" in text
    assert "Audit ID   : 9c2f3a" in text


def test_verify_cli_rich_output(capsys, tmp_path: Path):
    log = HashChainAuditLog(tmp_path / "audit.log")
    log.append(avid="AVID-1", action_type="t", decision="ALLOW", reason="ok")
    rc = verify_main([str(tmp_path / "audit.log")])
    out = capsys.readouterr().out
    assert rc == 0
    assert "Canopy Chain Verification" in out
    assert "Chain Status : ✓ VALID" in out
    assert "Entries      : 1" in out


def test_lint_policy_warns_and_errors(capsys, tmp_path: Path):
    policy = tmp_path / "policy.yaml"
    policy.write_text(
        "\n".join(
            [
                "rules:",
                "  - deny_if: 'oops'",
                "    when_all:",
                '      - \'agent_ctx.role = "admin"\'',
                '    deny_regex: "["',
            ]
        )
        + "\n",
        encoding="utf-8",
    )
    rc = lint_main([str(policy)])
    out = capsys.readouterr().out
    assert rc == 1
    assert "has no 'action_type'" in out
    assert "uses = instead of ==" in out
    assert "is not a valid regex" in out


def test_lint_policy_success_summary(capsys, tmp_path: Path):
    policy = tmp_path / "policy.yaml"
    policy.write_text(
        'rules:\n  - action_type: "execute_shell"\n    deny_if: "rm -rf"\n',
        encoding="utf-8",
    )
    rc = lint_main([str(policy)])
    out = capsys.readouterr().out
    assert rc == 0
    assert "✓ Policy valid" in out


def test_format_approval_helpers():
    result = _sample_result()
    text = format_approval_request(result)
    payload = format_approval_webhook(result)
    assert "APPROVAL REQUIRED" in text
    assert "Audit ID : auth-123" in text
    assert payload["audit_id"] == "auth-123"
    assert payload["severity"] == "high"


def test_prompt_for_approval_accepts_and_logs(monkeypatch, tmp_path: Path):
    monkeypatch.setenv("CANOPY_AUDIT_LOG_PATH", str(tmp_path / "audit.log"))
    monkeypatch.setattr("builtins.input", lambda _: "y")
    result = _sample_result()

    called = {"ok": False}

    def func(value: int) -> int:
        called["ok"] = True
        return value + 1

    out = prompt_for_approval(result, func, 4)
    assert out == 5
    assert called["ok"] is True

    lines = (tmp_path / "audit.log").read_text(encoding="utf-8").splitlines()
    last = json.loads(lines[-1])
    assert last["event"] == "approval_granted"
    assert last["authorization_id"] == "auth-123"


def test_prompt_for_approval_rejects_and_logs(monkeypatch, tmp_path: Path):
    monkeypatch.setenv("CANOPY_AUDIT_LOG_PATH", str(tmp_path / "audit.log"))
    monkeypatch.setattr("builtins.input", lambda _: "n")
    result = _sample_result()

    with pytest.raises(Exception):
        prompt_for_approval(result, lambda: "nope")

    lines = (tmp_path / "audit.log").read_text(encoding="utf-8").splitlines()
    last = json.loads(lines[-1])
    assert last["event"] == "approval_rejected"


def test_write_approval_artifact_creates_reusable_file(tmp_path: Path):
    result = _sample_result()
    log_path = tmp_path / "audit.log"
    artifact_path = write_approval_artifact(
        result,
        approved=True,
        reason="Approved for distributed execution.",
        audit_log_path=log_path,
    )
    assert artifact_path == approval_artifact_path(result, audit_log_path=log_path)
    payload = json.loads(artifact_path.read_text(encoding="utf-8"))
    assert payload["artifact_type"] == "canopy.approval_decision"
    assert payload["decision"] == "APPROVED"
    assert payload["authorization_id"] == "auth-123"
    assert payload["audit_log"] == str(log_path)


def test_lint_policy_function_returns_summary(tmp_path: Path):
    policy = tmp_path / "policy.yaml"
    policy.write_text(
        'rules:\n  - action_type: "a"\n    deny_if: "x"\n  - action_type: "b"\n    require_approval: true\n',
        encoding="utf-8",
    )
    warnings, errors, summary = lint_policy(policy)
    assert warnings == []
    assert errors == []
    assert summary == {"rule_count": 2, "action_type_count": 2}
