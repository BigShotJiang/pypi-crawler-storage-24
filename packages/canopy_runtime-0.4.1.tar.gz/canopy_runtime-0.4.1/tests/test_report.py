from __future__ import annotations

import sys
import types
from pathlib import Path

from canopy.audit import HashChainAuditLog
from canopy.report import main


def test_report_renders_latest_entry(capsys, tmp_path: Path):
    log = HashChainAuditLog(tmp_path / "audit.log")
    log.append(
        avid="AVID-1",
        action_type="execute_shell",
        decision="DENY",
        reason="Denied by constitution (Art.0): test",
        severity="critical",
        layers={
            "constitution": "blocked (Art.0)",
            "civil_code": "skipped",
            "firewall": "skipped",
            "policy": "skipped",
        },
        witness={
            "violated_article": "Art.0",
            "constitution_hash": "abc123",
            "signature": "sig1",
        },
        authorization_id="auth-1",
    )

    rc = main([str(tmp_path / "audit.log")])
    out = capsys.readouterr().out

    assert rc == 0
    assert "Canopy Audit Report" in out
    assert "Chain Status  : VALID" in out
    assert "Decision      : DENY [critical]" in out
    assert "constitution : blocked (Art.0)" in out
    assert "Article       : Art.0" in out


def test_report_shows_override_and_tool_result(capsys, tmp_path: Path):
    log = HashChainAuditLog(tmp_path / "audit.log")
    auth = log.append(
        avid="AVID-2",
        action_type="crypto_mining",
        decision="DENY",
        reason="Denied by Civil Code (Title VI): mining not authorized.",
        severity="high",
        layers={
            "constitution": "pass",
            "civil_code": "blocked (Title VI — Resource Accumulation)",
            "firewall": "skipped",
            "policy": "skipped",
        },
        witness={"violated_title": "Title VI", "civil_code_hash": "civil123", "signature": "sig2"},
        authorization_id="auth-2",
        override_possible=True,
        override_key="agent_ctx['mining_authorized'] = True",
        constitution_witness={"event": "constitution_allow", "violated_article": "", "signature": "sig-const"},
    )
    log.append_tool_result(
        authorization_id=auth.entry_hash,
        avid="AVID-2",
        action_type="crypto_mining",
        ok=True,
        result={"status": "blocked"},
    )

    rc = main([str(tmp_path / "audit.log"), "--all"])
    out = capsys.readouterr().out

    assert rc == 0
    assert "Override" in out
    assert "agent_ctx['mining_authorized'] = True" in out
    assert "Constitution Witness" in out
    assert "Tool Result" in out
    assert "Authorization : " in out


def test_report_export_requires_openpyxl(capsys, monkeypatch, tmp_path: Path):
    log = HashChainAuditLog(tmp_path / "audit.log")
    log.append(avid="AVID-1", action_type="execute_shell", decision="DENY", reason="x")

    def boom():
        raise RuntimeError("Excel export requires: pip install canopy-runtime[excel]")

    monkeypatch.setattr("canopy.report._require_openpyxl", boom)
    rc = main([str(tmp_path / "audit.log"), "--export", str(tmp_path / "audit.xlsx")])
    out = capsys.readouterr().out
    assert rc == 1
    assert "Excel export requires" in out


def test_report_export_xlsx_summary(monkeypatch, capsys, tmp_path: Path):
    class FakeCell:
        def __init__(self, worksheet, row, column, value=None):
            self.worksheet = worksheet
            self.row = row
            self.column = column
            self.value = value
            self.fill = None
            self.font = None

        @property
        def column_letter(self):
            return chr(64 + self.column)

    class FakeDimension:
        def __init__(self):
            self.width = None

    class FakeDimensions(dict):
        def __missing__(self, key):
            value = FakeDimension()
            self[key] = value
            return value

    class FakeWorksheet:
        def __init__(self, title="Sheet"):
            self.title = title
            self.rows = []
            self.freeze_panes = None
            self.column_dimensions = FakeDimensions()

        def append(self, row):
            self.rows.append(list(row))

        def cell(self, row, column, value=None):
            while len(self.rows) < row:
                self.rows.append([])
            while len(self.rows[row - 1]) < column:
                self.rows[row - 1].append(None)
            if value is not None:
                self.rows[row - 1][column - 1] = value
            return FakeCell(self, row, column, self.rows[row - 1][column - 1])

        @property
        def columns(self):
            width = max((len(r) for r in self.rows), default=0)
            cols = []
            for column in range(1, width + 1):
                cells = []
                for row in range(1, len(self.rows) + 1):
                    value = self.rows[row - 1][column - 1] if len(self.rows[row - 1]) >= column else None
                    cells.append(FakeCell(self, row, column, value))
                cols.append(cells)
            return cols

    class FakeWorkbook:
        def __init__(self):
            self.active = FakeWorksheet("Audit Log")
            self.sheets = [self.active]
            self.saved_path = None

        def create_sheet(self, title):
            ws = FakeWorksheet(title)
            self.sheets.append(ws)
            return ws

        def save(self, path):
            self.saved_path = Path(path)
            self.saved_path.write_text("fake-xlsx", encoding="utf-8")

    fake_module = types.SimpleNamespace(Workbook=FakeWorkbook)
    fake_styles = types.SimpleNamespace(
        Font=lambda **kwargs: ("Font", kwargs),
        PatternFill=lambda **kwargs: ("PatternFill", kwargs),
    )
    monkeypatch.setitem(sys.modules, "openpyxl", fake_module)
    monkeypatch.setitem(sys.modules, "openpyxl.styles", fake_styles)

    log = HashChainAuditLog(tmp_path / "audit.log")
    log.append(
        avid="AVID-1",
        action_type="execute_shell",
        decision="DENY",
        reason="Denied by constitution",
        severity="critical",
        layers={"constitution": "blocked (Art.0)", "civil_code": "skipped", "firewall": "skipped", "policy": "skipped"},
        authorization_id="auth-1",
    )
    log.append(
        avid="AVID-1",
        action_type="call_external_api",
        decision="REQUIRE_APPROVAL",
        reason="Firewall wants approval",
        severity="medium",
        layers={"constitution": "pass", "civil_code": "pass", "firewall": "blocked (require_approval)", "policy": "skipped"},
        authorization_id="auth-2",
    )

    rc = main([str(tmp_path / "audit.log"), "--all", "--export", str(tmp_path / "audit_report.xlsx")])
    out = capsys.readouterr().out
    assert rc == 0
    assert "✓ Exported 2 entries" in out
    assert "DENY         : 1" in out
    assert "REQUIRE_APPROVAL : 1" in out
    assert (tmp_path / "audit_report.xlsx").exists()
