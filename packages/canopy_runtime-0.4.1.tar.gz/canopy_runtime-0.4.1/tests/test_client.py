from __future__ import annotations

from fastapi.testclient import TestClient

from canopy.client import CanopyClient
from canopy.service import app


def test_client_against_service(monkeypatch, tmp_path):
    monkeypatch.setenv("CANOPY_AUDIT_LOG_PATH", str(tmp_path / "audit.log"))
    monkeypatch.setenv("CANOPY_CONTROL_PLANE_DB", str(tmp_path / "control-plane.db"))
    monkeypatch.setenv("CANOPY_ALLOW_INSECURE_GATEWAY", "true")
    http = TestClient(app)
    client = CanopyClient(http_client=http)
    res = client.authorize_action(
        {"public_key": "pk", "created_at": "2026-03-15T00:00:00Z", "tenant_id": "acme"},
        "call_external_api",
        {"url": "https://example.com"},
    )
    assert res["decision"] == "REQUIRE_APPROVAL"

    agents = client.list_agents("acme")
    assert agents["agents"][0]["tenant_id"] == "acme"


def test_client_supports_registration_and_dashboard(monkeypatch, tmp_path):
    monkeypatch.setenv("CANOPY_CONTROL_PLANE_DB", str(tmp_path / "control-plane.db"))
    monkeypatch.setenv("CANOPY_ALLOW_INSECURE_GATEWAY", "true")
    http = TestClient(app)
    client = CanopyClient(http_client=http)

    registered = client.register_agent(
        {
            "public_key": "pk-reg",
            "created_at": "2026-03-15T00:00:00Z",
            "tenant_id": "globex",
            "agent_name": "ops",
            "agent_reputation": 72,
        },
        metadata={"framework": "langgraph"},
    )
    assert registered["agent"]["status"] == "registered"

    dashboard = client.dashboard_summary("globex")
    assert dashboard["tenant_id"] == "globex"
    assert dashboard["agents"] == 1
