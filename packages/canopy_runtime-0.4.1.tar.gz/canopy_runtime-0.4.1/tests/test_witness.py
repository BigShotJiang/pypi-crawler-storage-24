from __future__ import annotations

import json
from pathlib import Path

from canopy import verify_witness
from canopy.constitution import evaluate
from canopy.core import authorize_action


def test_verify_witness_detects_tampering():
    res = evaluate(avid="AVID-test", action_type="execute_shell", action_payload={"command": "echo ok"})
    assert verify_witness(res.witness) is True

    tampered = dict(res.witness)
    tampered["explanation"] = "hacked"
    assert verify_witness(tampered) is False


def test_audit_log_includes_signed_witness(tmp_path: Path):
    audit_path = tmp_path / "audit.log"
    authorize_action(
        {
            "public_key": "pk",
            "created_at": "2026-03-15T00:00:00Z",
            "original_prompt_hash": "ph",
            "internal_reasoning": "ir",
        },
        "execute_shell",
        {"command": "echo ok"},
        audit_log_path=audit_path,
    )

    line = audit_path.read_text(encoding="utf-8").splitlines()[-1]
    entry = json.loads(line)
    witness = entry.get("witness")
    assert isinstance(witness, dict)
    assert "signature" in witness
    assert verify_witness(witness) is True
