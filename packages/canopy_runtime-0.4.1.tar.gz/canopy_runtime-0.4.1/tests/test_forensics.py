from __future__ import annotations

from pathlib import Path

from canopy import open_incident
from canopy.audit import HashChainAuditLog
from canopy.cli_incident import main as incident_main
from canopy.core import authorize_action
from canopy.decorators import safe_tool


def test_authorize_action_emits_trace_and_policy_snapshot(tmp_path: Path):
    audit_path = tmp_path / "audit.log"
    result = authorize_action(
        {
            "public_key": "pk-agent-001",
            "created_at": "2026-01-01T00:00:00Z",
            "trace_id": "trace-abc123",
        },
        "call_external_api",
        {"url": "https://example.com"},
        audit_log_path=audit_path,
    )
    assert result["trace_id"] == "trace-abc123"
    assert result["policy_snapshot"]["policy_hash"]

    entry = list(HashChainAuditLog(audit_path).iter_entries())[0]
    assert entry["trace_id"] == "trace-abc123"
    assert entry["policy_snapshot"]["policy_file"]


def test_tool_result_and_trace_lookup_share_trace_id(tmp_path: Path):
    audit_path = tmp_path / "audit.log"

    @safe_tool(
        action_type="execute_shell",
        agent_ctx={
            "public_key": "pk-agent-002",
            "created_at": "2026-01-01T00:00:00Z",
            "trace_id": "trace-run-1",
            "autonomous_mode": True,
        },
        audit_log_path=str(audit_path),
    )
    def fetch(command: str) -> str:
        return f"ok:{command}"

    fetch("echo hello")
    trace_entries = HashChainAuditLog(audit_path).get_trace("trace-run-1")
    assert len(trace_entries) == 2
    assert trace_entries[0]["event"] == "authorize_action"
    assert trace_entries[1]["event"] == "tool_result"
    assert trace_entries[1]["trace_id"] == "trace-run-1"


def test_open_incident_appends_incident_event(tmp_path: Path):
    audit_path = tmp_path / "audit.log"
    incident = open_incident(
        trace_id="trace-incident-1",
        agent_avid="AVID-123",
        description="Unexpected data exfiltration detected.",
        severity="critical",
        related_authorization_ids=["auth-1", "auth-2"],
        reporter="ciso-team",
        audit_log_path=audit_path,
    )
    entries = list(HashChainAuditLog(audit_path).iter_entries())
    assert incident["incident_id"].startswith("inc-")
    assert entries[0]["event"] == "incident_event"
    assert entries[0]["incident_id"] == incident["incident_id"]
    assert entries[0]["related_authorization_ids"] == ["auth-1", "auth-2"]


def test_canopy_incident_cli_renders_timeline(tmp_path: Path, capsys):
    audit_path = tmp_path / "audit.log"

    @safe_tool(
        action_type="execute_shell",
        agent_ctx={
            "public_key": "pk-agent-003",
            "created_at": "2026-01-01T00:00:00Z",
            "trace_id": "trace-cli-1",
        },
        audit_log_path=str(audit_path),
    )
    def run(command: str) -> str:
        return f"ran:{command}"

    run("echo hi")
    entries = list(HashChainAuditLog(audit_path).iter_entries())
    auth_entry = next(entry for entry in entries if entry["event"] == "authorize_action")
    open_incident(
        trace_id="trace-cli-1",
        agent_avid=str(auth_entry["avid"]),
        description="Unexpected outbound behavior detected.",
        severity="critical",
        related_authorization_ids=[str(auth_entry["entry_hash"])],
        reporter="soc",
        audit_log_path=audit_path,
    )

    rc = incident_main(["--trace", "trace-cli-1", str(audit_path)])
    out = capsys.readouterr().out
    assert rc == 0
    assert "CANOPY INCIDENT TIMELINE" in out
    assert "AUTHORIZE_ACTION" in out
    assert "TOOL_RESULT" in out
    assert "INCIDENT_EVENT" in out


def test_canopy_incident_cli_can_export_xlsx(tmp_path: Path):
    audit_path = tmp_path / "audit.log"
    export_path = tmp_path / "incident_report.xlsx"
    log = HashChainAuditLog(audit_path)
    auth = log.append(
        avid="AVID-123",
        action_type="execute_shell",
        decision="ALLOW",
        reason="Allowed by default",
        severity="low",
        layers={"constitution": "pass"},
        event="authorize_action",
        authorization_id="auth-123",
        trace_id="trace-export-1",
        policy_snapshot={"policy_file": "default.yaml", "policy_hash": "abc123", "policy_source": "default"},
    )
    log.append_tool_result(
        authorization_id=str(auth.authorization_id or "auth-123"),
        avid="AVID-123",
        action_type="execute_shell",
        ok=True,
        result={"ok": True},
        trace_id="trace-export-1",
    )
    open_incident(
        trace_id="trace-export-1",
        agent_avid="AVID-123",
        description="Unexpected shell output reviewed.",
        reporter="ops",
        audit_log_path=audit_path,
    )

    rc = incident_main(["--trace", "trace-export-1", str(audit_path), "--export", str(export_path)])
    assert rc == 0
    assert export_path.exists()
