from __future__ import annotations

from fastapi.testclient import TestClient

from canopy.service import app


def test_service_authorize_action(monkeypatch, tmp_path):
    monkeypatch.setenv("CANOPY_AUDIT_LOG_PATH", str(tmp_path / "audit.log"))
    monkeypatch.setenv("CANOPY_CONTROL_PLANE_DB", str(tmp_path / "control-plane.db"))
    monkeypatch.setenv("CANOPY_ALLOW_INSECURE_GATEWAY", "true")
    client = TestClient(app)
    res = client.post(
        "/v1/authorize",
        json={
            "agent_ctx": {
                "public_key": "pk",
                "created_at": "2026-03-15T00:00:00Z",
                "tenant_id": "acme",
                "agent_name": "ops-agent",
            },
            "action_type": "execute_shell",
            "action_payload": "rm -rf /",
        },
    )
    assert res.status_code == 200
    data = res.json()
    assert data["decision"] == "DENY"

    agents = client.get("/v1/agents", params={"tenant_id": "acme"})
    assert agents.status_code == 200
    assert agents.json()["agents"][0]["display_name"] == "ops-agent"

    audit = client.get("/v1/audit", params={"tenant_id": "acme"})
    assert audit.status_code == 200
    assert audit.json()["events"][0]["decision"] == "DENY"


def test_service_can_register_agent_and_record_approval(monkeypatch, tmp_path):
    monkeypatch.setenv("CANOPY_CONTROL_PLANE_DB", str(tmp_path / "control-plane.db"))
    monkeypatch.setenv("CANOPY_ALLOW_INSECURE_GATEWAY", "true")
    client = TestClient(app)

    reg = client.post(
        "/v1/agents/register",
        json={
            "agent_ctx": {
                "public_key": "pk-2",
                "created_at": "2026-03-15T00:00:00Z",
                "tenant_id": "globex",
                "agent_name": "finance-agent",
                "agent_reputation": 88,
            },
            "metadata": {"framework": "openai-agents", "environment": "prod"},
        },
    )
    assert reg.status_code == 200
    body = reg.json()
    assert body["agent"]["tenant_id"] == "globex"
    assert body["agent"]["trust_score"] == 88

    decision = client.post(
        "/v1/approvals/decide",
        json={
            "tenant_id": "globex",
            "authorization_id": "auth-123",
            "avid": body["agent"]["avid"],
            "decision": "APPROVED",
            "decided_by": "ciso@globex.test",
            "reason": "approved for incident response",
        },
    )
    assert decision.status_code == 200
    assert decision.json()["decision"] == "APPROVED"


def test_service_serves_dashboard_html(monkeypatch, tmp_path):
    monkeypatch.setenv("CANOPY_CONTROL_PLANE_DB", str(tmp_path / "control-plane.db"))
    client = TestClient(app)
    res = client.get("/dashboard")
    assert res.status_code == 200
    assert "Canopy Beta Dashboard" in res.text
    root = client.get("/")
    assert root.status_code == 200
    assert "Recent Audit Events" in root.text
