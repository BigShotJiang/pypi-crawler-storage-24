from __future__ import annotations

from canopy.firewall import ActionFirewall, evaluate


def test_firewall_modify_file_case_insensitive():
    res = evaluate("modify_file", {"path": "/ETC/passwd"}, agent_ctx={"safe_paths": ["/tmp/"]})
    assert res.decision == "deny"


def test_firewall_call_external_api_case_insensitive():
    res = evaluate("call_external_api", {"url": "LOCALHOST"}, agent_ctx={})
    assert res.decision == "deny"


def test_firewall_spending_limit_reads_agent_ctx():
    res = evaluate("spend_money", {"amount": 50}, agent_ctx={"spending_limit": 100})
    assert res.decision == "allow"


def test_action_firewall_execute_shell_respects_governance():
    firewall = ActionFirewall(agent_ctx={"public_key": "pk", "created_at": "2026-03-15T00:00:00Z"})
    res = firewall.execute_shell("rm -rf /")
    assert res["status"] == "blocked"
    assert res["decision"] == "DENY"
