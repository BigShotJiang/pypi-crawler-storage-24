from __future__ import annotations

import json
import multiprocessing
import threading
import warnings
from pathlib import Path

import pytest

from canopy.audit import HashChainAuditLog
from canopy.constitution import constitution_hash
from canopy.core import authorize_action
from canopy.errors import CanopyPermissionError
from canopy.identity import generate_avid


def _mp_append(audit_path_str: str, process_id: int, n: int) -> None:
    audit_path = Path(audit_path_str)
    log = HashChainAuditLog(audit_path)
    for i in range(n):
        log.append(
            avid=f"AVID-mp-{process_id}",
            action_type="t",
            decision="ALLOW",
            reason=f"ok-{i}",
        )


def test_deny_rm_rf(tmp_path: Path):
    policy = tmp_path / "policy.yaml"
    policy.write_text(
        "\n".join(
            [
                "rules:",
                '  - action_type: "execute_shell"',
                '    deny_if: "rm -rf"',
            ]
        )
        + "\n",
        encoding="utf-8",
    )
    audit_path = tmp_path / "audit.log"
    agent_ctx = {"public_key": "pk", "created_at": "2026-03-15T00:00:00Z"}
    res = authorize_action(agent_ctx, "execute_shell", "rm -rf /", policy_file=policy, audit_log_path=audit_path)
    assert res["decision"] == "DENY"
    assert res["avid"].startswith("AVID-")


def test_require_approval(tmp_path: Path):
    policy = tmp_path / "policy.yaml"
    policy.write_text(
        "\n".join(
            [
                "rules:",
                '  - action_type: "call_external_api"',
                "    require_approval: true",
            ]
        )
        + "\n",
        encoding="utf-8",
    )
    audit_path = tmp_path / "audit.log"
    agent_ctx = {"public_key": "pk", "created_at": "2026-03-15T00:00:00Z"}
    res = authorize_action(
        agent_ctx,
        "call_external_api",
        {"url": "https://example.com"},
        policy_file=policy,
        audit_log_path=audit_path,
    )
    assert res["decision"] == "REQUIRE_APPROVAL"


def test_conditions_when_all_agent_ctx_and_payload(tmp_path: Path):
    policy = tmp_path / "policy.yaml"
    policy.write_text(
        "\n".join(
            [
                "rules:",
                '  - action_type: "execute_shell"',
                "    when_all:",
                '      - \'agent_ctx.env == "production"\'',
                '      - \'payload contains "rm"\'',
                '    deny_if: \"rm\"',
            ]
        )
        + "\n",
        encoding="utf-8",
    )
    audit_path = tmp_path / "audit.log"

    denied = authorize_action(
        {"env": "production", "public_key": "pk", "created_at": "2026-03-15T00:00:00Z", "autonomous_mode": True},
        "execute_shell",
        {"command": "echo rm"},
        policy_file=policy,
        audit_log_path=audit_path,
    )
    assert denied["decision"] == "DENY"

    allowed = authorize_action(
        {"env": "staging", "public_key": "pk", "created_at": "2026-03-15T00:00:00Z", "autonomous_mode": True},
        "execute_shell",
        {"command": "echo rm"},
        policy_file=policy,
        audit_log_path=audit_path,
    )
    assert allowed["decision"] == "ALLOW"


def test_safe_paths(tmp_path: Path):
    policy = tmp_path / "policy.yaml"
    policy.write_text(
        "\n".join(
            [
                "rules:",
                '  - action_type: "modify_file"',
                '    allow_if: "safe_paths"',
            ]
        )
        + "\n",
        encoding="utf-8",
    )
    audit_path = tmp_path / "audit.log"
    agent_ctx = {
        "public_key": "pk",
        "created_at": "2026-03-15T00:00:00Z",
        "safe_paths": [str(tmp_path)],
        "autonomous_mode": True,
    }
    ok = authorize_action(
        agent_ctx,
        "modify_file",
        {"path": str(tmp_path / "x.txt")},
        policy_file=policy,
        audit_log_path=audit_path,
    )
    assert ok["decision"] == "ALLOW"
    bad = authorize_action(
        agent_ctx,
        "modify_file",
        {"path": "/etc/passwd"},
        policy_file=policy,
        audit_log_path=audit_path,
    )
    assert bad["decision"] == "DENY"


def test_avid_verified_if_provided(tmp_path: Path):
    policy = tmp_path / "policy.yaml"
    policy.write_text("rules:\n  - action_type: \"execute_shell\"\n    deny_if: \"rm -rf\"\n", encoding="utf-8")
    audit_path = tmp_path / "audit.log"

    ctx = {"public_key": "pk", "created_at": "2026-03-15T00:00:00Z", "env": "production"}
    expected = generate_avid(ctx, constitution_hash=constitution_hash(), require_stable=True)
    res = authorize_action(
        {**ctx, "avid": expected},
        "execute_shell",
        {"command": "echo ok"},
        policy_file=policy,
        audit_log_path=audit_path,
    )
    assert res["avid"] == expected


def test_avid_mismatch_raises(tmp_path: Path):
    policy = tmp_path / "policy.yaml"
    policy.write_text("rules:\n  - action_type: \"execute_shell\"\n    deny_if: \"rm -rf\"\n", encoding="utf-8")
    audit_path = tmp_path / "audit.log"

    ctx = {"public_key": "pk", "created_at": "2026-03-15T00:00:00Z"}
    bad = "AVID-0000"
    try:
        authorize_action(
            {**ctx, "avid": bad},
            "execute_shell",
            {"command": "echo ok"},
            policy_file=policy,
            audit_log_path=audit_path,
        )
        assert False, "expected ValueError"
    except ValueError as e:
        assert "avid mismatch" in str(e).lower()


def test_authorize_action_allows_ephemeral_avid_if_not_provided(tmp_path: Path):
    policy = tmp_path / "policy.yaml"
    policy.write_text("rules:\n  - action_type: \"execute_shell\"\n    deny_if: \"rm -rf\"\n", encoding="utf-8")
    audit_path = tmp_path / "audit.log"

    res = authorize_action(
        {"public_key": "pk"},
        "execute_shell",
        {"command": "echo ok"},
        policy_file=policy,
        audit_log_path=audit_path,
    )
    assert str(res["avid"]).startswith("AVID-")


def test_generate_avid_require_stable_raises():
    with pytest.raises(ValueError):
        generate_avid({"public_key": "pk"}, constitution_hash=constitution_hash(), require_stable=True)


def test_policy_multiple_rules_same_action_type_all_evaluated(tmp_path: Path):
    policy = tmp_path / "policy.yaml"
    policy.write_text(
        "\n".join(
            [
                "rules:",
                '  - action_type: "custom_action"',
                '    require_approval_if: "review-me"',
                '  - action_type: "custom_action"',
                '    deny_if: "block-me"',
            ]
        )
        + "\n",
        encoding="utf-8",
    )
    audit_path = tmp_path / "audit.log"

    res = authorize_action(
        {"public_key": "pk", "created_at": "2026-03-15T00:00:00Z"},
        "custom_action",
        {"text": "please review-me and then block-me"},
        policy_file=policy,
        audit_log_path=audit_path,
    )
    assert res["decision"] == "DENY"
    assert res["layers"]["policy"] == "deny"


def test_load_policies_raises_on_empty_rules(tmp_path: Path):
    policy = tmp_path / "policy.yaml"
    policy.write_text("rules:\n", encoding="utf-8")
    with pytest.raises(ValueError):
        authorize_action(
            {"public_key": "pk", "created_at": "2026-03-15T00:00:00Z"},
            "execute_shell",
            {"command": "echo ok"},
            policy_file=policy,
            audit_log_path=tmp_path / "audit.log",
        )


def test_unrecognized_predicate_warns(tmp_path: Path):
    policy = tmp_path / "policy.yaml"
    policy.write_text(
        "\n".join(
            [
                "rules:",
                '  - action_type: "execute_shell"',
                "    when_all:",
                '      - \'agent_ctx.role = "admin"\'',
                '    deny_if: "echo"',
            ]
        )
        + "\n",
        encoding="utf-8",
    )

    with warnings.catch_warnings(record=True) as caught:
        warnings.simplefilter("always")
        res = authorize_action(
            {"public_key": "pk", "created_at": "2026-03-15T00:00:00Z"},
            "execute_shell",
            {"command": "echo ok"},
            policy_file=policy,
            audit_log_path=tmp_path / "audit.log",
        )
    assert res["decision"] == "ALLOW"
    assert any("Unrecognized policy predicate" in str(w.message) for w in caught)


def test_audit_hash_chain_integrity(tmp_path: Path):
    audit_path = tmp_path / "audit.log"
    log = HashChainAuditLog(audit_path)
    log.append(avid="AVID-1", action_type="t1", decision="ALLOW", reason="ok", timestamp="2026-03-15T00:00:00Z")
    log.append(avid="AVID-1", action_type="t2", decision="DENY", reason="no", timestamp="2026-03-15T00:00:01Z")
    assert log.verify_integrity() is True

    lines = audit_path.read_text(encoding="utf-8").splitlines()
    obj = json.loads(lines[1])
    obj["reason"] = "tampered"
    lines[1] = json.dumps(obj, ensure_ascii=False)
    audit_path.write_text("\n".join(lines) + "\n", encoding="utf-8")
    assert HashChainAuditLog(audit_path).verify_integrity() is False


def test_audit_hash_chain_threadsafe_threads(tmp_path: Path):
    audit_path = tmp_path / "audit.log"
    n_threads = 16
    n_appends = 25

    def _worker(tid: int) -> None:
        log = HashChainAuditLog(audit_path)
        for i in range(n_appends):
            log.append(avid=f"AVID-th-{tid}", action_type="t", decision="ALLOW", reason=f"ok-{i}")

    threads = [threading.Thread(target=_worker, args=(i,)) for i in range(n_threads)]
    for t in threads:
        t.start()
    for t in threads:
        t.join()

    assert HashChainAuditLog(audit_path).verify_integrity() is True


def test_audit_hash_chain_threadsafe_multiprocess(tmp_path: Path):
    audit_path = tmp_path / "audit.log"
    ctx = multiprocessing.get_context("spawn")
    n_processes = 4
    n_appends = 30
    procs = [
        ctx.Process(target=_mp_append, args=(str(audit_path), pid, n_appends))
        for pid in range(n_processes)
    ]
    for p in procs:
        p.start()
    for p in procs:
        p.join(timeout=30)
        assert p.exitcode == 0

    assert HashChainAuditLog(audit_path).verify_integrity() is True
