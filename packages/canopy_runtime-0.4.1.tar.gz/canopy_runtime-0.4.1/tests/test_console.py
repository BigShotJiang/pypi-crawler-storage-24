from __future__ import annotations

import json
from pathlib import Path

from canopy.audit import HashChainAuditLog
from canopy.console import VERSION, main, render_screen


def test_render_screen_with_log_shows_valid_status(tmp_path: Path):
    log_path = tmp_path / "audit.log"
    HashChainAuditLog(log_path).append(
        avid="AVID-1",
        action_type="execute_shell",
        decision="DENY",
        reason="Denied",
        severity="critical",
        layers={
            "constitution": "blocked (Art.0)",
            "civil_code": "skipped",
            "firewall": "skipped",
            "policy": "skipped",
        },
    )
    text = render_screen(log_path)
    assert f"CANOPY OPERATOR CONSOLE v{VERSION}" in text
    assert "Chain : ✓ VALID" in text
    assert "Audit Log   : " in text
    assert "Decisions   : ALLOW 0   REQUIRE 0   DENY 1" in text
    assert "Top block   : Constitution (1)" in text
    assert "Operations" in text
    assert "Incident Response" in text
    assert "Integrity" in text
    assert "Setup" in text
    assert "[1]  Recent activity" in text
    assert "[2]  Pending approvals" in text
    assert "[3]  Agents" in text
    assert "[4]  Trace timeline" in text
    assert "[5]  Incident timeline" in text
    assert "[6]  Export evidence" in text
    assert "[10] Self-check install/config" in text
    assert "[11] Connect Canopy to your agent" in text


def test_render_screen_without_log_shows_not_found(tmp_path: Path):
    text = render_screen(tmp_path / "missing.log")
    assert "Audit Log   : not found" in text
    assert "canopy-console --audit-log path/to/audit.log" in text
    assert "[10] Self-check install/config" in text
    assert "[11] Connect Canopy to your agent" in text


def test_main_quit_exits_zero(monkeypatch, capsys, tmp_path: Path):
    answers = iter(["q"])

    class DummyConsole:
        def clear(self):
            return None

        def print(self, *args, **kwargs):
            print(*args)

        def input(self, prompt=""):
            print(prompt, end="")
            return next(answers)

    monkeypatch.setattr("canopy.console.Console", lambda: DummyConsole())
    rc = main(["--audit-log", str(tmp_path / "missing.log")])
    out = capsys.readouterr().out
    assert rc == 0
    assert "Goodbye. Your agents are governed." in out


def test_header_contains_version(tmp_path: Path):
    text = render_screen(tmp_path / "missing.log")
    assert f"v{VERSION}" in text


def test_console_can_open_integration_guide(monkeypatch, capsys, tmp_path: Path):
    answers = iter(["11", "1", "b", "b", "q"])

    class FakePanel:
        @staticmethod
        def fit(content, title=None, border_style=None):
            return f"{title or ''}\n{content}"

    class DummyConsole:
        def clear(self):
            return None

        def print(self, *args, **kwargs):
            print(*args)

        def input(self, prompt=""):
            print(prompt, end="")
            return next(answers)

    monkeypatch.setattr("canopy.console.Console", lambda: DummyConsole())
    monkeypatch.setattr("canopy.console.Panel", FakePanel)
    rc = main(["--audit-log", str(tmp_path / "missing.log")])
    out = capsys.readouterr().out
    assert rc == 0
    assert "How to connect Canopy to your agent" in out
    assert "LangChain Integration" in out


def test_console_can_run_self_check(monkeypatch, capsys, tmp_path: Path):
    answers = iter(["10", "n", "", "q"])

    class FakePanel:
        @staticmethod
        def fit(content, title=None, border_style=None):
            return f"{title or ''}\n{content}"

    class DummyConsole:
        def clear(self):
            return None

        def print(self, *args, **kwargs):
            print(*args)

        def input(self, prompt=""):
            print(prompt, end="")
            return next(answers)

    monkeypatch.setattr("canopy.console.Console", lambda: DummyConsole())
    monkeypatch.setattr("canopy.console.Panel", FakePanel)
    rc = main(["--audit-log", str(tmp_path / "missing.log")])
    out = capsys.readouterr().out
    assert rc == 0
    assert "Self-Check" in out
    assert "CANOPY SELF-CHECK" in out


def test_console_pending_approval_can_be_rejected(monkeypatch, capsys, tmp_path: Path):
    log_path = tmp_path / "audit.log"
    log = HashChainAuditLog(log_path)
    log.append(
        avid="AVID-1",
        action_type="execute_shell",
        decision="REQUIRE_APPROVAL",
        reason="Firewall: high-risk command requires approval",
        severity="high",
        layers={"constitution": "pass", "civil_code": "pass", "firewall": "blocked (require_approval)", "policy": "skipped"},
        authorization_id="auth-1",
    )
    answers = iter(["2", "1", "r", "", "", "q"])

    class FakePanel:
        @staticmethod
        def fit(content, title=None, border_style=None):
            return f"{title or ''}\n{content}"

    class DummyConsole:
        def clear(self):
            return None

        def print(self, *args, **kwargs):
            print(*args)

        def input(self, prompt=""):
            print(prompt, end="")
            return next(answers)

    monkeypatch.setattr("canopy.console.Console", lambda: DummyConsole())
    monkeypatch.setattr("canopy.console.Panel", FakePanel)
    rc = main(["--audit-log", str(log_path)])
    out = capsys.readouterr().out
    assert rc == 0
    assert "Pending Approvals" in out
    assert "Rejection Recorded" in out
    lines = log_path.read_text(encoding="utf-8").splitlines()
    assert any("approval_rejected" in line for line in lines)
    artifact_path = Path(str(log_path) + ".approvals") / "auth-1.json"
    assert artifact_path.exists()
    artifact = json.loads(artifact_path.read_text(encoding="utf-8"))
    assert artifact["decision"] == "REJECTED"
    assert artifact["authorization_id"] == "auth-1"


def test_console_agents_view(monkeypatch, capsys, tmp_path: Path):
    log_path = tmp_path / "audit.log"
    log = HashChainAuditLog(log_path)
    log.append(avid="AVID-1", action_type="execute_shell", decision="DENY", reason="Denied", authorization_id="a1")
    log.append(avid="AVID-1", action_type="call_external_api", decision="ALLOW", reason="Allowed", authorization_id="a2")
    answers = iter(["3", "1", "", "q"])

    class FakePanel:
        @staticmethod
        def fit(content, title=None, border_style=None):
            return f"{title or ''}\n{content}"

    class DummyConsole:
        def clear(self):
            return None

        def print(self, *args, **kwargs):
            print(*args)

        def input(self, prompt=""):
            print(prompt, end="")
            return next(answers)

    monkeypatch.setattr("canopy.console.Console", lambda: DummyConsole())
    monkeypatch.setattr("canopy.console.Panel", FakePanel)
    rc = main(["--audit-log", str(log_path)])
    out = capsys.readouterr().out
    assert rc == 0
    assert "Agents" in out
    assert "Agent History" in out
