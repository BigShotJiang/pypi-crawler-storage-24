from __future__ import annotations

import os
from functools import lru_cache
from pathlib import Path
from typing import Any, Dict, Optional

from fastapi import FastAPI, Header, HTTPException, Query
from fastapi.responses import HTMLResponse
from pydantic import BaseModel, Field

from .control_plane import ControlPlaneStore
from .core import authorize_action
from .identity import generate_avid


def _default_policy_file() -> Path:
    return Path(__file__).with_name("policies") / "default.yaml"


def _control_plane_db_path() -> str:
    return os.getenv("CANOPY_CONTROL_PLANE_DB", "canopy-control-plane.db")


def _audit_log_path() -> str:
    return os.getenv("CANOPY_AUDIT_LOG_PATH", "audit.log")


def _policy_file() -> Path:
    policy_file = os.getenv("CANOPY_POLICY_FILE")
    return Path(policy_file) if policy_file else _default_policy_file()


def _require_api_key(x_api_key: Optional[str]) -> None:
    configured = [item.strip() for item in os.getenv("CANOPY_API_KEYS", "").split(",") if item.strip()]
    insecure_allowed = str(os.getenv("CANOPY_ALLOW_INSECURE_GATEWAY", "")).strip().lower() in {"1", "true", "yes", "on"}
    if not configured:
        if insecure_allowed:
            return
        raise HTTPException(
            status_code=503,
            detail=(
                "gateway authentication is not configured; set CANOPY_API_KEYS "
                "or explicitly opt into local-only mode with CANOPY_ALLOW_INSECURE_GATEWAY=true"
            ),
        )
    if x_api_key in configured:
        return
    raise HTTPException(status_code=401, detail="missing or invalid API key")


@lru_cache(maxsize=8)
def _store(path: str) -> ControlPlaneStore:
    return ControlPlaneStore(path)


def _tenant_id_for(agent_ctx: Dict[str, Any]) -> str:
    tenant_id = str(agent_ctx.get("tenant_id") or "default").strip()
    return tenant_id or "default"


class ActionRequest(BaseModel):
    agent_ctx: Dict[str, Any] = Field(default_factory=dict)
    action_type: str
    action_payload: Any = Field(default_factory=dict)


class AgentRegisterRequest(BaseModel):
    agent_ctx: Dict[str, Any] = Field(default_factory=dict)
    metadata: Dict[str, Any] = Field(default_factory=dict)


class ApprovalDecisionRequest(BaseModel):
    tenant_id: str = "default"
    authorization_id: str
    avid: str
    decision: str
    decided_by: str
    reason: str = ""


app = FastAPI(title="Canopy Cloud Control Plane", version="0.4.0")


def _dashboard_html() -> str:
    return """<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Canopy Beta Dashboard</title>
  <style>
    * { box-sizing: border-box; }
    body {
      margin: 0;
      font-family: ui-sans-serif, -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif;
      background: #0b1020;
      color: #e5e7eb;
    }
    .shell {
      max-width: 1180px;
      margin: 0 auto;
      padding: 32px 20px 56px;
    }
    .hero {
      display: flex;
      justify-content: space-between;
      gap: 16px;
      align-items: end;
      margin-bottom: 24px;
      flex-wrap: wrap;
    }
    h1 {
      margin: 0;
      font-size: 2rem;
      line-height: 1.1;
    }
    .sub {
      margin-top: 8px;
      color: #94a3b8;
      max-width: 720px;
    }
    .panel, .metric {
      background: #11182d;
      border: 1px solid #22304d;
      border-radius: 16px;
      box-shadow: 0 10px 30px rgba(0, 0, 0, 0.18);
    }
    .controls {
      padding: 16px;
      display: grid;
      grid-template-columns: 1.1fr 1.1fr auto;
      gap: 12px;
      margin-bottom: 20px;
    }
    label {
      display: block;
      font-size: 0.82rem;
      color: #94a3b8;
      margin-bottom: 6px;
    }
    input {
      width: 100%;
      padding: 12px 14px;
      border-radius: 10px;
      border: 1px solid #314263;
      background: #0b1020;
      color: #e5e7eb;
    }
    button {
      align-self: end;
      padding: 12px 16px;
      border-radius: 10px;
      border: 0;
      background: #e5e7eb;
      color: #0b1020;
      font-weight: 700;
      cursor: pointer;
    }
    .metrics {
      display: grid;
      grid-template-columns: repeat(4, minmax(0, 1fr));
      gap: 14px;
      margin-bottom: 20px;
    }
    .metric {
      padding: 16px;
    }
    .metric .label {
      color: #94a3b8;
      font-size: 0.78rem;
      margin-bottom: 6px;
    }
    .metric .value {
      font-size: 1.7rem;
      font-weight: 700;
    }
    .grid {
      display: grid;
      grid-template-columns: 1.2fr 1fr;
      gap: 20px;
    }
    .stack {
      display: grid;
      gap: 20px;
    }
    .panel {
      padding: 18px;
    }
    .panel h2 {
      margin: 0 0 14px;
      font-size: 1rem;
    }
    .list {
      display: grid;
      gap: 10px;
    }
    .item {
      border: 1px solid #22304d;
      border-radius: 12px;
      padding: 12px 14px;
      background: rgba(255,255,255,0.02);
    }
    .item .meta {
      color: #94a3b8;
      font-size: 0.78rem;
      margin-top: 4px;
    }
    .badge {
      display: inline-block;
      border-radius: 999px;
      padding: 3px 8px;
      font-size: 0.72rem;
      font-weight: 700;
      margin-right: 6px;
    }
    .ALLOW { background: rgba(16,185,129,.15); color: #34d399; }
    .DENY { background: rgba(248,113,113,.14); color: #f87171; }
    .REQUIRE_APPROVAL { background: rgba(251,191,36,.14); color: #fbbf24; }
    .INCIDENT { background: rgba(244,114,182,.14); color: #f472b6; }
    .muted { color: #94a3b8; }
    .status {
      margin-bottom: 18px;
      color: #94a3b8;
      font-size: 0.9rem;
    }
    @media (max-width: 900px) {
      .metrics, .grid, .controls { grid-template-columns: 1fr; }
    }
  </style>
</head>
<body>
  <div class="shell">
    <div class="hero">
      <div>
        <h1>Canopy Beta Dashboard</h1>
        <div class="sub">A lightweight operator view for beta users: decisions, traces, incidents, and agent activity from the Canopy control plane.</div>
      </div>
    </div>

    <div class="panel controls">
      <div>
        <label for="tenant">Tenant ID</label>
        <input id="tenant" value="default" />
      </div>
      <div>
        <label for="apiKey">API Key (optional in local insecure mode)</label>
        <input id="apiKey" placeholder="paste key if gateway auth is enabled" />
      </div>
      <button id="refresh">Refresh</button>
    </div>

    <div id="status" class="status">Loading...</div>

    <div class="metrics">
      <div class="metric"><div class="label">Agents</div><div id="m-agents" class="value">-</div></div>
      <div class="metric"><div class="label">Pending Approvals</div><div id="m-pending" class="value">-</div></div>
      <div class="metric"><div class="label">Incidents</div><div id="m-incidents" class="value">-</div></div>
      <div class="metric"><div class="label">Traces</div><div id="m-traces" class="value">-</div></div>
    </div>

    <div class="grid">
      <div class="stack">
        <div class="panel">
          <h2>Recent Audit Events</h2>
          <div id="events" class="list"></div>
        </div>
        <div class="panel">
          <h2>Traces</h2>
          <div id="traces" class="list"></div>
        </div>
      </div>
      <div class="stack">
        <div class="panel">
          <h2>Agents</h2>
          <div id="agents" class="list"></div>
        </div>
        <div class="panel">
          <h2>Incidents</h2>
          <div id="incidents" class="list"></div>
        </div>
      </div>
    </div>
  </div>

  <script>
    const byId = id => document.getElementById(id);

    function headers() {
      const value = byId("apiKey").value.trim();
      return value ? { "x-api-key": value } : {};
    }

    async function fetchJson(path) {
      const response = await fetch(path, { headers: headers() });
      if (!response.ok) {
        const body = await response.text();
        throw new Error(`${response.status} ${response.statusText}: ${body}`);
      }
      return response.json();
    }

    function itemHtml(title, body, meta = "") {
      return `<div class="item"><div>${title}</div><div class="meta">${body}</div>${meta ? `<div class="meta">${meta}</div>` : ""}</div>`;
    }

    async function refresh() {
      const tenant = encodeURIComponent(byId("tenant").value.trim() || "default");
      byId("status").textContent = "Loading dashboard data...";
      try {
        const [health, dashboard, agents, audit] = await Promise.all([
          fetchJson("/healthz"),
          fetchJson(`/v1/dashboard?tenant_id=${tenant}`),
          fetchJson(`/v1/agents?tenant_id=${tenant}&limit=20`),
          fetchJson(`/v1/audit?tenant_id=${tenant}&limit=100`),
        ]);

        const events = audit.events || [];
        const incidentEvents = events.filter(e => e.event === "incident_event");
        const traces = {};
        events.forEach(event => {
          const traceId = event.trace_id || "";
          if (!traceId) return;
          traces[traceId] = traces[traceId] || [];
          traces[traceId].push(event);
        });

        byId("m-agents").textContent = dashboard.agents ?? 0;
        byId("m-pending").textContent = dashboard.pending_approvals ?? 0;
        byId("m-incidents").textContent = incidentEvents.length;
        byId("m-traces").textContent = Object.keys(traces).length;
        byId("status").textContent = `Gateway auth mode: ${health.auth_mode} · Tenant: ${dashboard.tenant_id}`;

        byId("agents").innerHTML = (agents.agents || []).length
          ? agents.agents.map(agent =>
              itemHtml(
                `<strong>${agent.display_name || agent.avid}</strong>`,
                `${agent.avid}`,
                `trust ${agent.trust_score} · last seen ${agent.last_seen_at}`
              )
            ).join("")
          : `<div class="muted">No agents registered yet.</div>`;

        byId("events").innerHTML = events.length
          ? events.slice(0, 20).map(event => {
              const badge = `<span class="badge ${event.decision}">${event.decision}</span>`;
              const title = `${badge}<strong>${event.action_type}</strong>`;
              const body = `${event.reason || event.description || ""}`;
              const meta = `${event.occurred_at || event.timestamp || ""} · ${event.trace_id || "no trace"} · ${event.authorization_id || event.incident_id || ""}`;
              return itemHtml(title, body, meta);
            }).join("")
          : `<div class="muted">No audit events yet.</div>`;

        byId("incidents").innerHTML = incidentEvents.length
          ? incidentEvents.map(event =>
              itemHtml(
                `<span class="badge INCIDENT">INCIDENT</span><strong>${event.severity}</strong>`,
                event.description || event.reason || "",
                `${event.trace_id || "no trace"} · reporter ${event.reporter || "unknown"}`
              )
            ).join("")
          : `<div class="muted">No incidents recorded yet.</div>`;

        const traceItems = Object.entries(traces)
          .sort((a, b) => (b[1][0].occurred_at || "").localeCompare(a[1][0].occurred_at || ""))
          .slice(0, 20);
        byId("traces").innerHTML = traceItems.length
          ? traceItems.map(([traceId, entries]) => {
              const latest = entries[0] || {};
              return itemHtml(
                `<strong>${traceId}</strong>`,
                `${entries.length} events`,
                `${latest.occurred_at || latest.timestamp || ""} · latest ${latest.event || "event"}`
              );
            }).join("")
          : `<div class="muted">No trace-linked events yet.</div>`;
      } catch (error) {
        byId("status").textContent = `Dashboard error: ${error.message}`;
      }
    }

    byId("refresh").addEventListener("click", refresh);
    refresh();
  </script>
</body>
</html>"""


@app.get("/", response_class=HTMLResponse)
async def dashboard_home():
    return _dashboard_html()


@app.get("/dashboard", response_class=HTMLResponse)
async def dashboard_page():
    return _dashboard_html()


@app.get("/healthz")
async def healthz():
    configured = [item.strip() for item in os.getenv("CANOPY_API_KEYS", "").split(",") if item.strip()]
    insecure_allowed = str(os.getenv("CANOPY_ALLOW_INSECURE_GATEWAY", "")).strip().lower() in {"1", "true", "yes", "on"}
    return {
        "status": "ok",
        "service": "canopy-control-plane",
        "policy_file": str(_policy_file()),
        "audit_log_path": _audit_log_path(),
        "control_plane_db": _control_plane_db_path(),
        "auth_mode": "api_key" if configured else ("insecure_local" if insecure_allowed else "unconfigured"),
    }


@app.post("/v1/agents/register")
async def register_agent(req: AgentRegisterRequest, x_api_key: Optional[str] = Header(default=None)):
    _require_api_key(x_api_key)
    agent_ctx = dict(req.agent_ctx)
    if not agent_ctx.get("public_key") or not agent_ctx.get("created_at"):
        raise HTTPException(status_code=400, detail="public_key and created_at are required")
    agent_ctx["avid"] = generate_avid(agent_ctx)
    record = _store(_control_plane_db_path()).register_agent(agent_ctx, req.metadata)
    return {
        "agent": record,
        "message": "agent registered in Canopy control plane",
    }


@app.get("/v1/agents")
async def list_agents(
    tenant_id: str = Query(default="default"),
    limit: int = Query(default=100, ge=1, le=500),
    x_api_key: Optional[str] = Header(default=None),
):
    _require_api_key(x_api_key)
    return {
        "tenant_id": tenant_id,
        "agents": _store(_control_plane_db_path()).list_agents(tenant_id, limit=limit),
    }


@app.get("/v1/audit")
async def list_audit_events(
    tenant_id: str = Query(default="default"),
    avid: Optional[str] = Query(default=None),
    limit: int = Query(default=100, ge=1, le=500),
    x_api_key: Optional[str] = Header(default=None),
):
    _require_api_key(x_api_key)
    return {
        "tenant_id": tenant_id,
        "events": _store(_control_plane_db_path()).list_audit_events(tenant_id, avid=avid, limit=limit),
    }


@app.get("/v1/dashboard")
async def dashboard_summary(
    tenant_id: str = Query(default="default"),
    x_api_key: Optional[str] = Header(default=None),
):
    _require_api_key(x_api_key)
    return _store(_control_plane_db_path()).dashboard_summary(tenant_id)


@app.post("/v1/approvals/decide")
async def decide_approval(req: ApprovalDecisionRequest, x_api_key: Optional[str] = Header(default=None)):
    _require_api_key(x_api_key)
    decision = req.decision.upper()
    if decision not in {"APPROVED", "REJECTED"}:
        raise HTTPException(status_code=400, detail="decision must be APPROVED or REJECTED")
    return _store(_control_plane_db_path()).record_approval_decision(
        tenant_id=req.tenant_id,
        authorization_id=req.authorization_id,
        avid=req.avid,
        decision=decision,
        decided_by=req.decided_by,
        reason=req.reason,
    )


@app.post("/v1/authorize")
async def authorize(req: ActionRequest, x_api_key: Optional[str] = Header(default=None)):
    _require_api_key(x_api_key)
    result = authorize_action(
        req.agent_ctx,
        req.action_type,
        req.action_payload,
        policy_file=_policy_file(),
        audit_log_path=_audit_log_path(),
    )
    agent_ctx = dict(req.agent_ctx)
    agent_ctx.setdefault("avid", result["avid"])
    if agent_ctx.get("public_key") and agent_ctx.get("created_at"):
        _store(_control_plane_db_path()).register_agent(agent_ctx)
    _store(_control_plane_db_path()).append_authorization(
        tenant_id=_tenant_id_for(agent_ctx),
        avid=result["avid"],
        authorization_id=str(result.get("authorization_id") or ""),
        action_type=req.action_type,
        decision=str(result["decision"]),
        reason=str(result["reason"]),
        severity=str(result["severity"]),
        trace_id=str(result.get("trace_id") or "") or None,
        layers=dict(result.get("layers") or {}),
        witness=result.get("witness"),
        policy_snapshot=result.get("policy_snapshot") if isinstance(result.get("policy_snapshot"), dict) else None,
        payload=req.action_payload,
    )
    return result


@app.post("/authorize_action")
async def authorize_legacy(req: ActionRequest):
    return await authorize(req)
