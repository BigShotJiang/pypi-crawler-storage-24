from __future__ import annotations

import argparse
import io
from contextlib import redirect_stdout
from collections import Counter
from importlib.metadata import PackageNotFoundError, version as package_version
from pathlib import Path
from typing import Any, Dict, List, Optional

from rich.console import Console
from rich.panel import Panel

from .approval import record_approval_decision, write_approval_artifact
from .audit import HashChainAuditLog
from .formatting import format_decision
from .cli_incident import main as incident_main
from .lint import main as lint_main
from .report import main as report_main
from .self_check import main as self_check_main
from .verify import main as verify_main


try:
    VERSION = package_version("canopy-runtime")
except PackageNotFoundError:  # pragma: no cover - local editable/dev usage
    VERSION = "0.4.0"
_QUIT = -999

_INTEGRATION_GUIDES: dict[str, dict[str, str]] = {
    "1": {
        "title": "LangChain Integration",
        "body": """Step 1 - Install
──────────────────
pip install canopy-runtime

Step 2 - Wrap your tool
────────────────────────
from canopy import safe_tool
from langchain.tools import tool

@safe_tool(
    action_type="execute_shell",
    agent_ctx={
        "public_key": "pk-your-agent",
        "created_at": "2026-01-01T00:00:00Z",
    }
)
@tool
def run_shell(command: str) -> str:
    import subprocess
    return subprocess.check_output(command, shell=True, text=True)

Step 3 - Check your audit log
─────────────────────────────
canopy-console  (you're already here)

⚠ REQUIRE_APPROVAL → ask a human, not the LLM""",
    },
    "2": {
        "title": "OpenAI Agents SDK Integration",
        "body": """Step 1 - Install
──────────────────
pip install canopy-runtime

Step 2 - Wrap your tool
────────────────────────
from agents import function_tool
from canopy import safe_tool

@function_tool
@safe_tool(
    action_type="execute_shell",
    agent_ctx={
        "public_key": "pk-your-agent",
        "created_at": "2026-01-01T00:00:00Z",
    }
)
def run_shell(command: str) -> str:
    import subprocess
    return subprocess.check_output(command, shell=True, text=True)

Step 3 - Review decisions
─────────────────────────
Use canopy-console to inspect the audit log after runs.

⚠ REQUIRE_APPROVAL → trigger human UX, not another model call""",
    },
    "3": {
        "title": "CrewAI Integration",
        "body": """Step 1 - Install
──────────────────
pip install canopy-runtime

Step 2 - Use the Canopy mixin
─────────────────────────────
from crewai.tools import BaseTool
from canopy import CanopyCrewAITool

class ShellTool(CanopyCrewAITool, BaseTool):
    name = "shell"
    description = "Runs shell commands"
    canopy_action_type = "execute_shell"
    canopy_agent_ctx = {
        "public_key": "pk-your-agent",
        "created_at": "2026-01-01T00:00:00Z",
    }

    def _run(self, command: str) -> str:
        import subprocess
        return subprocess.check_output(command, shell=True, text=True)

Step 3 - Review with canopy-console
───────────────────────────────────
Open the audit log and verify the chain after runs.""",
    },
    "4": {
        "title": "AutoGen Integration",
        "body": """Step 1 - Install
──────────────────
pip install canopy-runtime

Step 2 - Wrap before register_for_execution
───────────────────────────────────────────
from canopy import canopy_autogen_tool

@canopy_autogen_tool(
    action_type="execute_shell",
    agent_ctx={
        "public_key": "pk-your-agent",
        "created_at": "2026-01-01T00:00:00Z",
    },
)
def run_shell(command: str) -> str:
    import subprocess
    return subprocess.check_output(command, shell=True, text=True)

Step 3 - Register as usual
──────────────────────────
agent.register_for_execution()(run_shell)

⚠ Approval requests should go to a human callback, not back to the LLM""",
    },
    "5": {
        "title": "LangGraph Integration",
        "body": """Step 1 - Install
──────────────────
pip install canopy-runtime

Step 2 - Wrap the node
──────────────────────
from canopy import canopy_node

@canopy_node(
    action_type="execute_shell",
    agent_ctx={
        "public_key": "pk-your-agent",
        "created_at": "2026-01-01T00:00:00Z",
    },
    payload_extractor=lambda state: {"command": state["command"]},
)
def shell_node(state: dict) -> dict:
    import subprocess
    result = subprocess.run(state["command"], shell=True, capture_output=True, text=True)
    return {"output": result.stdout}

Step 3 - Inspect audit decisions
────────────────────────────────
Use canopy-console to review what the graph attempted.""",
    },
    "6": {
        "title": "Custom Runner / No Framework",
        "body": """Step 1 - Install
──────────────────
pip install canopy-runtime

Step 2 - Gate every action before execution
────────────────────────────────────────────
from canopy import authorize_action

result = authorize_action(
    agent_ctx={
        "public_key": "pk-your-agent",
        "created_at": "2026-01-01T00:00:00Z",
    },
    action_type="execute_shell",
    action_payload={"command": command},
)

if result["decision"] == "ALLOW":
    run_the_tool()
elif result["decision"] == "REQUIRE_APPROVAL":
    ask_a_human()
else:
    block_the_action()

Step 3 - Audit everything
─────────────────────────
Review audit.log with canopy-console / canopy-report / canopy-verify.""",
    },
}


def _capture(fn, argv: list[str]) -> tuple[int, str]:
    buffer = io.StringIO()
    with redirect_stdout(buffer):
        rc = fn(argv)
    return int(rc), buffer.getvalue().strip()


def _audit_status(path: Path) -> Dict[str, Any]:
    if not path.exists():
        return {
            "found": False,
            "entries": 0,
            "chain": "N/A",
            "last_timestamp": "",
            "last_decision": "",
            "last_severity": "",
        }

    log = HashChainAuditLog(path)
    entries = list(log.iter_entries())
    last = entries[-1] if entries else {}
    return {
        "found": True,
        "entries": len(entries),
        "chain": "✓ VALID" if log.verify_integrity() else "✗ INVALID",
        "last_timestamp": str(last.get("timestamp", "")),
        "last_decision": str(last.get("decision", "")),
        "last_severity": str(last.get("severity", "")),
        "pending_approvals": len(_pending_approvals(entries)),
    }


def _load_entries(path: Path) -> List[Dict[str, Any]]:
    if not path.exists():
        return []
    return list(HashChainAuditLog(path).iter_entries())


def _pending_approvals(entries: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    closed: set[str] = set()
    pending: List[Dict[str, Any]] = []
    for entry in entries:
        auth_id = str(entry.get("authorization_id") or "")
        event = str(entry.get("event") or "authorize_action")
        if auth_id and event in {"approval_granted", "approval_rejected", "approval_skipped"}:
            closed.add(auth_id)
    for entry in entries:
        auth_id = str(entry.get("authorization_id") or "")
        if (
            str(entry.get("decision") or "").upper() == "REQUIRE_APPROVAL"
            and str(entry.get("event") or "authorize_action") == "authorize_action"
            and auth_id
            and auth_id not in closed
        ):
            pending.append(entry)
    return pending


def _group_agents(entries: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    grouped: Dict[str, Dict[str, Any]] = {}
    for entry in entries:
        avid = str(entry.get("avid") or "")
        if not avid:
            continue
        info = grouped.setdefault(avid, {"avid": avid, "count": 0, "last_timestamp": "", "last_decision": ""})
        info["count"] += 1
        info["last_timestamp"] = str(entry.get("timestamp") or "")
        info["last_decision"] = str(entry.get("decision") or "")
    return sorted(grouped.values(), key=lambda item: (item["last_timestamp"], item["avid"]), reverse=True)


def _blocked_by(entry: Dict[str, Any]) -> str:
    layers = entry.get("layers") if isinstance(entry.get("layers"), dict) else {}
    labels = {
        "constitution": "Constitution",
        "civil_code": "Civil Code",
        "firewall": "Firewall",
        "policy": "Policy",
    }
    for key in ("constitution", "civil_code", "firewall", "policy"):
        value = str(layers.get(key) or "")
        if value.startswith("blocked") or value in {"deny", "require_approval"}:
            return labels.get(key, key)
    return "None"


def _dashboard_summary(entries: List[Dict[str, Any]]) -> Dict[str, Any]:
    authorize_entries = [entry for entry in entries if str(entry.get("event") or "authorize_action") == "authorize_action"]
    decisions = Counter(str(entry.get("decision") or "").upper() for entry in authorize_entries)
    blockers = Counter(
        _blocked_by(entry)
        for entry in authorize_entries
        if str(entry.get("decision") or "").upper() in {"DENY", "REQUIRE_APPROVAL"}
    )
    top_blocker, top_blocker_count = ("None", 0)
    if blockers:
        top_blocker, top_blocker_count = blockers.most_common(1)[0]
    return {
        "allow": decisions.get("ALLOW", 0),
        "require_approval": decisions.get("REQUIRE_APPROVAL", 0),
        "deny": decisions.get("DENY", 0),
        "top_blocker": top_blocker,
        "top_blocker_count": top_blocker_count,
        "incidents": sum(1 for entry in entries if str(entry.get("event") or "") == "incident_event"),
        "traces": len({str(entry.get("trace_id") or "") for entry in entries if str(entry.get("trace_id") or "")}),
    }


def render_screen(audit_log_path: Path, *, policy_file: Optional[str] = None, version: str = VERSION) -> str:
    status = _audit_status(audit_log_path)
    lines: list[str] = [
        "",
        f"        ▓▓▓ CANOPY OPERATOR CONSOLE v{version} ▓▓▓",
        "     Governance, Approvals, and Incident Response",
        "",
    ]
    if status["found"]:
        entries = _load_entries(audit_log_path)
        summary = _dashboard_summary(entries)
        lines.extend(
            [
                f"  Audit Log   : {audit_log_path}",
                f"  Entries     : {status['entries']}          Chain : {status['chain']}",
                f"  Last event  : {status['last_timestamp']}   Decision : {status['last_decision']} [{status['last_severity']}]",
                f"  Pending     : {status['pending_approvals']}",
                f"  Decisions   : ALLOW {summary['allow']}   REQUIRE {summary['require_approval']}   DENY {summary['deny']}",
                f"  Top block   : {summary['top_blocker']} ({summary['top_blocker_count']})",
                f"  Traces      : {summary['traces']}          Incidents : {summary['incidents']}",
                "",
                "  Operations",
                "",
                "  [1]  Recent activity",
                "  [2]  Pending approvals",
                "  [3]  Agents",
                "  [4]  Trace timeline",
                "",
                "  Incident Response",
                "",
                "  [5]  Incident timeline",
                "  [6]  Export evidence",
                "",
                "  Integrity",
                "",
                "  [7]  Verify chain integrity",
                "  [8]  Export audit log",
                "  [9]  Lint policy file",
                "",
                "  Setup",
                "",
                "  [10] Self-check install/config",
                "  [11] Connect Canopy to your agent",
                "",
                "  [q]  Quit",
            ]
        )
    else:
        lines.extend(
            [
                "  Audit Log   : not found",
                "  Connect Canopy to your runtime or point Canopy to your",
                "  existing audit log with:",
                "",
                "  canopy-console --audit-log path/to/audit.log",
                "",
            ]
        )
        if policy_file:
            lines.append(f"  Policy file : {policy_file}")
            lines.append("")
        lines.extend(
            [
                "  Setup",
                "",
                "  [9]  Lint policy file",
                "  [10] Self-check install/config",
                "  [11] Connect Canopy to your agent",
                "  [q]  Quit",
            ]
        )
    return "\n".join(lines)


def _show(console: Console, title: str, content: str) -> None:
    console.clear()
    console.print(Panel.fit(content or "(no output)", title=title, border_style="cyan"))
    console.input("\nPress Enter to return to menu")


def _pending_approvals_menu(console: Console, audit_log_path: Path) -> int | None:
    while True:
        entries = _load_entries(audit_log_path)
        pending = _pending_approvals(entries)
        if not pending:
            _show(console, "Pending Approvals", "No pending approvals.")
            return None

        body_lines = ["Pending approvals:", ""]
        for idx, entry in enumerate(pending, start=1):
            body_lines.append(
                f"  [{idx}] {entry.get('timestamp')} - {entry.get('action_type')} - {entry.get('severity')} - {entry.get('avid')}"
            )
        body_lines.extend(["", "  [b] Back", "  [q] Quit"])
        console.clear()
        console.print(Panel.fit("\n".join(body_lines), title="Pending Approvals", border_style="yellow"))
        choice = console.input(" → Select approval: ").strip().lower()
        if choice == "b":
            return None
        if choice == "q":
            return _QUIT
        if not choice.isdigit() or not (1 <= int(choice) <= len(pending)):
            _show(console, "Unknown Option", f"Unknown selection: {choice!r}")
            continue

        entry = pending[int(choice) - 1]
        while True:
            console.clear()
            detail = format_decision(entry)
            detail += "\n\n[a] Approve    [r] Reject    [b] Back    [q] Quit"
            console.print(Panel.fit(detail, title="Approval Detail", border_style="yellow"))
            action = console.input(" → Select option: ").strip().lower()
            if action == "b":
                break
            if action == "a":
                record_approval_decision(
                    entry, approved=True, reason="Approved via canopy-console.", audit_log_path=audit_log_path
                )
                artifact = write_approval_artifact(
                    entry, approved=True, reason="Approved via canopy-console.", audit_log_path=audit_log_path
                )
                _show(
                    console,
                    "Approval Recorded",
                    f"✓ Approval recorded in audit log.\n✓ Approval artifact written to:\n{artifact}",
                )
                break
            if action == "r":
                record_approval_decision(
                    entry, approved=False, reason="Rejected via canopy-console.", audit_log_path=audit_log_path
                )
                artifact = write_approval_artifact(
                    entry, approved=False, reason="Rejected via canopy-console.", audit_log_path=audit_log_path
                )
                _show(
                    console,
                    "Rejection Recorded",
                    f"✓ Rejection recorded in audit log.\n✓ Approval artifact written to:\n{artifact}",
                )
                break
            _show(console, "Unknown Option", f"Unknown selection: {action!r}")


def _agents_menu(console: Console, audit_log_path: Path) -> int | None:
    while True:
        entries = _load_entries(audit_log_path)
        agents = _group_agents(entries)
        if not agents:
            _show(console, "Agents", "No agent events found in this audit log.")
            return None

        lines = ["Tracked agents:", ""]
        for idx, item in enumerate(agents, start=1):
            lines.append(
                f"  [{idx}] {item['avid']} - {item['count']} events - last {item['last_timestamp']} ({item['last_decision']})"
            )
        lines.extend(["", "  [b] Back", "  [q] Quit"])
        console.clear()
        console.print(Panel.fit("\n".join(lines), title="Agents", border_style="green"))
        choice = console.input(" → Select agent: ").strip().lower()
        if choice == "b":
            return None
        if choice == "q":
            return _QUIT
        if not choice.isdigit() or not (1 <= int(choice) <= len(agents)):
            _show(console, "Unknown Option", f"Unknown selection: {choice!r}")
            continue

        avid = agents[int(choice) - 1]["avid"]
        selected = [entry for entry in entries if str(entry.get("avid") or "") == avid][-10:]
        body = [f"Agent: {avid}", ""]
        for entry in selected:
            body.append(f"- {entry.get('timestamp')} - {entry.get('decision')} - {entry.get('action_type')}")
            body.append(f"  {entry.get('reason')}")
        _show(console, "Agent History", "\n".join(body))


def _integration_menu(console: Console) -> int | None:
    while True:
        console.clear()
        body = "\n".join(
            [
                "  What are you using?",
                "",
                "  [1]  LangChain",
                "  [2]  OpenAI Agents SDK",
                "  [3]  CrewAI",
                "  [4]  AutoGen",
                "  [5]  LangGraph",
                "  [6]  My own runner / no framework",
                "",
                "  [b]  Back",
                "  [q]  Quit",
            ]
        )
        console.print(Panel.fit(body, title="How to connect Canopy to your agent", border_style="magenta"))
        choice = console.input(" → Select framework: ").strip().lower()
        if choice == "b":
            return None
        if choice == "q":
            return _QUIT
        guide = _INTEGRATION_GUIDES.get(choice)
        if guide is None:
            _show(console, "Unknown Option", f"Unknown framework selection: {choice!r}")
            continue

        while True:
            console.clear()
            content = guide["body"] + "\n\n[b] Back to frameworks    [q] Quit"
            console.print(Panel.fit(content, title=guide["title"], border_style="blue"))
            next_choice = console.input(" → Select option: ").strip().lower()
            if next_choice == "b":
                break
            if next_choice == "q":
                return _QUIT
            _show(console, "Unknown Option", f"Unknown selection: {next_choice!r}")


def _incident_menu(console: Console, audit_log_path: Path) -> int | None:
    trace_id = console.input("Incident trace ID (leave blank to cancel): ").strip()
    if not trace_id:
        return None
    rc, output = _capture(incident_main, ["--trace", trace_id, str(audit_log_path)])
    _show(console, "Incident Timeline", output)
    return rc


def _trace_menu(console: Console, audit_log_path: Path) -> int | None:
    trace_id = console.input("Trace ID (leave blank to cancel): ").strip()
    if not trace_id:
        return None
    rc, output = _capture(incident_main, ["--trace", trace_id, str(audit_log_path)])
    _show(console, "Trace Timeline", output)
    return rc


def _export_evidence_menu(console: Console, audit_log_path: Path) -> int | None:
    while True:
        console.clear()
        body = "\n".join(
            [
                "  Export evidence for review or postmortem.",
                "",
                "  [1]  Export incident/trace timeline",
                "  [2]  Export full audit log",
                "",
                "  [b]  Back",
                "  [q]  Quit",
            ]
        )
        console.print(Panel.fit(body, title="Export Evidence", border_style="cyan"))
        choice = console.input(" → Select export: ").strip().lower()
        if choice == "b":
            return None
        if choice == "q":
            return _QUIT
        if choice == "1":
            trace_id = console.input("Trace ID (leave blank to cancel): ").strip()
            if not trace_id:
                return None
            filename = console.input("Export filename [incident_report.xlsx]: ").strip() or "incident_report.xlsx"
            rc, output = _capture(incident_main, ["--trace", trace_id, str(audit_log_path), "--export", filename])
            _show(console, "Evidence Export", output)
            return rc
        if choice == "2":
            filename = console.input("Export filename [audit_report.xlsx]: ").strip() or "audit_report.xlsx"
            rc, output = _capture(report_main, [str(audit_log_path), "--all", "--export", filename])
            _show(console, "Evidence Export", output)
            return rc
        _show(console, "Unknown Option", f"Unknown selection: {choice!r}")


def _self_check_menu(console: Console) -> int | None:
    gateway = console.input("Check gateway as well? [y/N]: ").strip().lower().startswith("y")
    argv: list[str] = ["--gateway"] if gateway else []
    rc, output = _capture(self_check_main, argv)
    _show(console, "Self-Check", output)
    return rc


def _run_option(console: Console, choice: str, *, audit_log_path: Path, policy_file: Optional[str]) -> Optional[int]:
    if choice == "1":
        rc, output = _capture(report_main, [str(audit_log_path)])
        _show(console, "Audit Report", output)
        return rc

    if choice == "2":
        return _pending_approvals_menu(console, audit_log_path)

    if choice == "3":
        return _agents_menu(console, audit_log_path)

    if choice == "4":
        return _trace_menu(console, audit_log_path)

    if choice == "5":
        return _incident_menu(console, audit_log_path)

    if choice == "6":
        return _export_evidence_menu(console, audit_log_path)

    if choice == "7":
        rc, output = _capture(verify_main, [str(audit_log_path)])
        _show(console, "Chain Verification", output)
        return rc

    if choice == "8":
        filename = console.input("Export filename [audit_report.xlsx]: ").strip() or "audit_report.xlsx"
        rc, output = _capture(report_main, [str(audit_log_path), "--all", "--export", filename])
        _show(console, "Excel Export", output)
        return rc

    if choice == "9":
        default = policy_file or "src/canopy/policies/default.yaml"
        entered = console.input(f"Policy file path [{default}]: ").strip() or default
        rc, output = _capture(lint_main, [entered])
        _show(console, "Policy Lint", output)
        return rc

    if choice == "10":
        return _self_check_menu(console)

    if choice == "11":
        return _integration_menu(console)

    if choice.lower() == "q":
        console.print("\nGoodbye. Your agents are governed.")
        return 0

    _show(console, "Unknown Option", f"Unknown selection: {choice!r}")
    return None


def main(argv: Optional[list[str]] = None) -> int:
    parser = argparse.ArgumentParser(description="Interactive terminal console for Canopy governance tools.")
    parser.add_argument("--audit-log", default="audit.log", help="path to audit log (default: ./audit.log)")
    parser.add_argument("--policy", default=None, help="path to policy file for lint/demo shortcuts")
    args = parser.parse_args(argv)

    audit_log_path = Path(args.audit_log)
    policy_file = args.policy
    console = Console()

    while True:
        console.clear()
        body = render_screen(audit_log_path, policy_file=policy_file)
        console.print(Panel.fit(body, border_style="green"))
        choice = console.input(" → Select option: ").strip()
        rc = _run_option(console, choice, audit_log_path=audit_log_path, policy_file=policy_file)
        if rc == _QUIT or choice.lower() == "q":
            return 0


if __name__ == "__main__":
    raise SystemExit(main())
