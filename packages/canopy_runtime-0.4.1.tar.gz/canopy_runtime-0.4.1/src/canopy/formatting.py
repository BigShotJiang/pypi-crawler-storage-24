from __future__ import annotations

from typing import Any, Dict


def _blocked_by(layers: Dict[str, Any]) -> str:
    for key in ("constitution", "civil_code", "firewall", "policy"):
        value = str(layers.get(key) or "")
        if value.startswith("blocked "):
            detail = value.removeprefix("blocked ").strip()
            label = {
                "constitution": "Constitution",
                "civil_code": "Civil Code",
                "firewall": "Firewall",
                "policy": "Policy",
            }.get(key, key)
            return f"{label} {detail}".strip()
        if value in {"deny", "require_approval"}:
            label = {
                "constitution": "Constitution",
                "civil_code": "Civil Code",
                "firewall": "Firewall",
                "policy": "Policy",
            }.get(key, key)
            return label
    return "None"


def _compact_layers(layers: Dict[str, Any]) -> str:
    if not layers:
        return "(none)"
    order = ("constitution", "civil_code", "firewall", "policy")
    items = [f"{key}={layers[key]}" for key in order if key in layers]
    items.extend(f"{k}={v}" for k, v in layers.items() if k not in order)
    return ", ".join(items)


def format_decision(result: Dict[str, Any]) -> str:
    """Render a decision dict as a human-readable block."""
    decision = str(result.get("decision") or "")
    severity = str(result.get("severity") or "")
    reason = str(result.get("reason") or "")
    audit_id = str(result.get("authorization_id") or "")
    layers = result.get("layers") if isinstance(result.get("layers"), dict) else {}

    lines = [
        f"Decision   : {decision} [{severity}]".rstrip(),
        f"Blocked by : {_blocked_by(layers)}",
        f"Reason     : {reason}",
        f"Audit ID   : {audit_id}",
        f"Layers     : {_compact_layers(layers)}",
    ]
    if "override_key" in result and result.get("override_key") is not None:
        lines.append(f"Override   : {result.get('override_key')}")
    return "\n".join(lines)
