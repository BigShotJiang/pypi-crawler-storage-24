from __future__ import annotations

import argparse
import importlib
import os
from pathlib import Path


def _status_line(label: str, status: str, detail: str) -> str:
    return f"[{status}] {label}: {detail}"


def _importable(module_name: str) -> bool:
    try:
        importlib.import_module(module_name)
        return True
    except Exception:
        return False


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="Validate a Canopy self-serve installation and basic configuration.")
    parser.add_argument("--gateway", action="store_true", help="validate gateway/control-plane requirements as well")
    parser.add_argument("--policy-file", default=os.getenv("CANOPY_POLICY_FILE", ""), help="optional policy file to validate")
    parser.add_argument("--audit-log", default=os.getenv("CANOPY_AUDIT_LOG_PATH", "audit.log"), help="audit log path to validate")
    args = parser.parse_args(argv)

    failures = 0
    warnings = 0

    print("CANOPY SELF-CHECK")

    if _importable("canopy"):
        print(_status_line("runtime", "PASS", "core package importable"))
    else:  # pragma: no cover
        print(_status_line("runtime", "FAIL", "core package could not be imported"))
        return 2

    audit_path = Path(args.audit_log)
    audit_parent = audit_path.parent if str(audit_path.parent) else Path(".")
    if audit_parent.exists() and os.access(audit_parent, os.W_OK):
        print(_status_line("audit", "PASS", f"audit path parent writable: {audit_parent}"))
    else:
        failures += 1
        print(_status_line("audit", "FAIL", f"audit path parent is not writable: {audit_parent}"))

    if args.policy_file:
        policy_path = Path(args.policy_file)
        if policy_path.exists():
            print(_status_line("policy", "PASS", f"policy file found: {policy_path}"))
        else:
            failures += 1
            print(_status_line("policy", "FAIL", f"policy file not found: {policy_path}"))
    else:
        warnings += 1
        print(_status_line("policy", "WARN", "using bundled default policy"))

    if args.gateway:
        missing = [mod for mod in ("fastapi", "pydantic", "uvicorn") if not _importable(mod)]
        if missing:
            failures += 1
            print(_status_line("gateway-deps", "FAIL", f"missing gateway deps: {', '.join(missing)}"))
        else:
            print(_status_line("gateway-deps", "PASS", "gateway dependencies importable"))

        configured = [item.strip() for item in os.getenv("CANOPY_API_KEYS", "").split(",") if item.strip()]
        insecure_allowed = str(os.getenv("CANOPY_ALLOW_INSECURE_GATEWAY", "")).strip().lower() in {"1", "true", "yes", "on"}
        if configured:
            print(_status_line("gateway-auth", "PASS", f"{len(configured)} API key(s) configured"))
        elif insecure_allowed:
            warnings += 1
            print(_status_line("gateway-auth", "WARN", "running in explicit insecure local mode"))
        else:
            failures += 1
            print(_status_line("gateway-auth", "FAIL", "set CANOPY_API_KEYS or CANOPY_ALLOW_INSECURE_GATEWAY=true"))

    print(f"Summary: {failures} fail, {warnings} warn")
    return 1 if failures else 0


if __name__ == "__main__":  # pragma: no cover
    raise SystemExit(main())
