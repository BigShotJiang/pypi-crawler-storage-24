from __future__ import annotations

import contextlib
import hashlib
import json
import threading
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, Iterable, Iterator, Optional

try:
    import fcntl  # type: ignore
except Exception:  # pragma: no cover
    fcntl = None  # type: ignore

try:
    import msvcrt  # type: ignore
except Exception:  # pragma: no cover
    msvcrt = None  # type: ignore


_THREAD_LOCKS_GUARD = threading.Lock()
_THREAD_LOCKS: dict[str, threading.Lock] = {}

_GENESIS_MARKER = "Canopy Audit Log v1"
_GENESIS_HASH = hashlib.sha256(_GENESIS_MARKER.encode("utf-8")).hexdigest()


def _thread_lock_for(lock_path: Path) -> threading.Lock:
    key = str(lock_path.resolve())
    with _THREAD_LOCKS_GUARD:
        lock = _THREAD_LOCKS.get(key)
        if lock is None:
            lock = threading.Lock()
            _THREAD_LOCKS[key] = lock
        return lock


@contextlib.contextmanager
def _file_lock(lock_path: Path) -> Iterator[None]:
    lock_path.parent.mkdir(parents=True, exist_ok=True)
    # Lock an adjacent lockfile instead of the audit log itself so readers can
    # still stream the log without blocking on an exclusive lock.
    with lock_path.open("a+b") as f:
        if fcntl is not None:
            fcntl.flock(f.fileno(), fcntl.LOCK_EX)
            try:
                yield
            finally:
                fcntl.flock(f.fileno(), fcntl.LOCK_UN)
            return

        if msvcrt is not None:  # pragma: no cover (only runs on Windows)
            # Lock 1 byte; ensure the file is at least 1 byte long.
            f.seek(0, 2)
            if f.tell() == 0:
                f.write(b"\0")
                f.flush()
            f.seek(0)
            msvcrt.locking(f.fileno(), msvcrt.LK_LOCK, 1)
            try:
                yield
            finally:
                f.seek(0)
                msvcrt.locking(f.fileno(), msvcrt.LK_UNLCK, 1)
            return

        # Best-effort fallback: thread-only locking.
        yield


def _canonical_json(obj: Any) -> bytes:
    return json.dumps(obj, sort_keys=True, separators=(",", ":"), ensure_ascii=False, default=str).encode("utf-8")


def _sha256_hex(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def _now_iso() -> str:
    return datetime.now(timezone.utc).replace(microsecond=0).isoformat().replace("+00:00", "Z")


@dataclass(frozen=True)
class AuditEntry:
    timestamp: str
    avid: str
    action_type: str
    decision: str
    reason: str
    severity: str
    layers: Dict[str, Any]
    witness: Optional[Dict[str, Any]]
    event: str
    authorization_id: Optional[str]
    ok: Optional[bool]
    result_hash: Optional[str]
    error: Optional[str]
    override_possible: Optional[bool]
    override_key: Optional[str]
    constitution_witness: Optional[Dict[str, Any]]
    trace_id: Optional[str]
    policy_snapshot: Optional[Dict[str, Any]]
    incident_id: Optional[str]
    description: Optional[str]
    reporter: Optional[str]
    related_authorization_ids: Optional[list[str]]
    prev_hash: str
    entry_hash: str

    def as_dict(self) -> Dict[str, Any]:
        out: Dict[str, Any] = {
            "timestamp": self.timestamp,
            "avid": self.avid,
            "action_type": self.action_type,
            "decision": self.decision,
            "reason": self.reason,
            "severity": self.severity,
            "layers": self.layers,
            "witness": self.witness,
            "event": self.event,
            "prev_hash": self.prev_hash,
            "entry_hash": self.entry_hash,
        }
        if self.authorization_id is not None:
            out["authorization_id"] = self.authorization_id
        if self.ok is not None:
            out["ok"] = self.ok
        if self.result_hash is not None:
            out["result_hash"] = self.result_hash
        if self.error is not None:
            out["error"] = self.error
        if self.override_possible is not None:
            out["override_possible"] = self.override_possible
        if self.override_key is not None:
            out["override_key"] = self.override_key
        if self.constitution_witness is not None:
            out["constitution_witness"] = self.constitution_witness
        if self.trace_id is not None:
            out["trace_id"] = self.trace_id
        if self.policy_snapshot is not None:
            out["policy_snapshot"] = self.policy_snapshot
        if self.incident_id is not None:
            out["incident_id"] = self.incident_id
        if self.description is not None:
            out["description"] = self.description
        if self.reporter is not None:
            out["reporter"] = self.reporter
        if self.related_authorization_ids is not None:
            out["related_authorization_ids"] = self.related_authorization_ids
        return out


def _hash_result(value: Any) -> str:
    """Stable SHA-256 over a tool return value (without storing the value)."""
    if value is None:
        return _sha256_hex(b"null")
    if isinstance(value, bytes):
        return _sha256_hex(value)
    if isinstance(value, str):
        return _sha256_hex(value.encode("utf-8"))
    return _sha256_hex(_canonical_json(value))


class HashChainAuditLog:
    """Append-only JSONL audit log with a simple hash chain."""

    def __init__(self, path: str | Path = "audit.log"):
        self.path = Path(path)
        self._lock_path = Path(str(self.path) + ".lock")

    def _read_last_hash(self) -> str:
        if not self.path.exists():
            return ""
        last = ""
        with self.path.open("rb") as f:
            for line in f:
                if line.strip():
                    last = line.decode("utf-8")
        if not last:
            return ""
        try:
            obj = json.loads(last)
            return str(obj.get("entry_hash", "") or "")
        except Exception:
            return ""

    def append(
        self,
        *,
        avid: str,
        action_type: str,
        decision: str,
        reason: str,
        severity: str = "low",
        layers: Optional[Dict[str, Any]] = None,
        witness: Optional[Dict[str, Any]] = None,
        event: str = "authorize_action",
        authorization_id: Optional[str] = None,
        ok: Optional[bool] = None,
        result_hash: Optional[str] = None,
        error: Optional[str] = None,
        override_possible: Optional[bool] = None,
        override_key: Optional[str] = None,
        constitution_witness: Optional[Dict[str, Any]] = None,
        trace_id: Optional[str] = None,
        policy_snapshot: Optional[Dict[str, Any]] = None,
        incident_id: Optional[str] = None,
        description: Optional[str] = None,
        reporter: Optional[str] = None,
        related_authorization_ids: Optional[list[str]] = None,
        timestamp: Optional[str] = None,
    ) -> AuditEntry:
        # We must read the last hash and append atomically relative to other
        # writers, otherwise two writers can race and produce an invalid chain.
        thread_lock = _thread_lock_for(self._lock_path)
        with thread_lock:
            with _file_lock(self._lock_path):
                prev_hash = self._read_last_hash()
                if not prev_hash:
                    prev_hash = _GENESIS_HASH
                ts = timestamp or _now_iso()
                base = {
                    "timestamp": ts,
                    "avid": avid,
                    "action_type": action_type,
                    "decision": decision,
                    "reason": reason,
                    "severity": severity,
                    "layers": layers or {},
                    "witness": witness,
                    "event": event,
                    "prev_hash": prev_hash,
                }
                if authorization_id is not None:
                    base["authorization_id"] = authorization_id
                if ok is not None:
                    base["ok"] = ok
                if result_hash is not None:
                    base["result_hash"] = result_hash
                if error is not None:
                    base["error"] = error
                if override_possible is not None:
                    base["override_possible"] = override_possible
                if override_key is not None:
                    base["override_key"] = override_key
                if constitution_witness is not None:
                    base["constitution_witness"] = constitution_witness
                if trace_id is not None:
                    base["trace_id"] = trace_id
                if policy_snapshot is not None:
                    base["policy_snapshot"] = policy_snapshot
                if incident_id is not None:
                    base["incident_id"] = incident_id
                if description is not None:
                    base["description"] = description
                if reporter is not None:
                    base["reporter"] = reporter
                if related_authorization_ids is not None:
                    base["related_authorization_ids"] = related_authorization_ids
                entry_hash = _sha256_hex(prev_hash.encode("utf-8") + _canonical_json(base))
                entry = AuditEntry(
                    timestamp=ts,
                    avid=avid,
                    action_type=action_type,
                    decision=decision,
                    reason=reason,
                    severity=severity,
                    layers=layers or {},
                    witness=witness,
                    event=event,
                    authorization_id=authorization_id,
                    ok=ok,
                    result_hash=result_hash,
                    error=error,
                    override_possible=override_possible,
                    override_key=override_key,
                    constitution_witness=constitution_witness,
                    trace_id=trace_id,
                    policy_snapshot=policy_snapshot,
                    incident_id=incident_id,
                    description=description,
                    reporter=reporter,
                    related_authorization_ids=related_authorization_ids,
                    prev_hash=prev_hash,
                    entry_hash=entry_hash,
                )
                self.path.parent.mkdir(parents=True, exist_ok=True)
                with self.path.open("a", encoding="utf-8") as f:
                    f.write(json.dumps(entry.as_dict(), ensure_ascii=False) + "\n")
                return entry

    def append_tool_result(
        self,
        *,
        authorization_id: str,
        avid: str,
        action_type: str,
        ok: bool,
        result: Any = None,
        error: Optional[str] = None,
        trace_id: Optional[str] = None,
        timestamp: Optional[str] = None,
    ) -> AuditEntry:
        return self.append(
            avid=avid,
            action_type=action_type,
            decision="RESULT",
            reason="Tool returned successfully" if ok else "Tool raised an exception",
            severity="low",
            layers={},
            witness=None,
            event="tool_result",
            authorization_id=authorization_id,
            ok=ok,
            result_hash=_hash_result(result) if ok else None,
            error=error,
            trace_id=trace_id,
            timestamp=timestamp,
        )

    def iter_entries(self) -> Iterable[Dict[str, Any]]:
        if not self.path.exists():
            return []
        with self.path.open("r", encoding="utf-8") as f:
            for line in f:
                line = line.strip()
                if not line:
                    continue
                yield json.loads(line)

    def get_trace(self, trace_id: str) -> list[Dict[str, Any]]:
        target = str(trace_id or "").strip()
        if not target:
            return []
        return [entry for entry in self.iter_entries() if str(entry.get("trace_id") or "") == target]

    def verify_integrity(self) -> bool:
        prev_hash = ""
        first = True
        for entry in self.iter_entries():
            entry_prev = str(entry.get("prev_hash", ""))
            if first and entry_prev == _GENESIS_HASH:
                prev_hash = _GENESIS_HASH
            if str(entry.get("prev_hash", "")) != prev_hash:
                return False
            # Hash the entire entry minus entry_hash so new fields cannot be
            # silently omitted from integrity verification.
            base = dict(entry)
            base.pop("entry_hash", None)
            expected = _sha256_hex(prev_hash.encode("utf-8") + _canonical_json(base))
            if str(entry.get("entry_hash", "")) != expected:
                return False
            prev_hash = expected
            first = False
        return True
