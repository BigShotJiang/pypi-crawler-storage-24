"""Canopy adapter for LangChain.

Usage:
    from langchain.tools import tool
    from canopy.adapters.langchain import canopy_tool

    @canopy_tool(action_type="execute_shell", agent_ctx={...})
    @tool
    def run_shell(command: str) -> str:
        import subprocess
        return subprocess.check_output(command, shell=True, text=True)

Design:
    - No forced dependency: langchain is imported only when canopy_tool is called.
    - Works with either a LangChain BaseTool instance (returned by @tool) or a raw function.
"""

from __future__ import annotations

import inspect
from typing import Any, Callable, Optional, TypeVar

from canopy.decorators import safe_tool

T = TypeVar("T")


def canopy_tool(
    *,
    action_type: str,
    agent_ctx: Any = None,
    on_require_approval: str = "raise",
    approval_callback: Optional[Callable[..., Any]] = None,
    policy_file: Optional[str] = None,
    audit_log_path: Optional[str] = None,
) -> Callable[[Any], Any]:
    """Decorator that wraps a LangChain tool with Canopy governance.

    Apply ABOVE LangChain's @tool so that canopy_tool receives the BaseTool instance:

        @canopy_tool(...)
        @tool
        def my_tool(...): ...
    """
    try:
        from langchain.tools import BaseTool  # type: ignore
    except ImportError as e:  # pragma: no cover
        raise ImportError("langchain is required: pip install langchain") from e

    def _wrap_callable(fn: Callable[..., Any]) -> Callable[..., Any]:
        return safe_tool(
            action_type=action_type,
            agent_ctx=agent_ctx,
            on_require_approval=on_require_approval,
            approval_callback=approval_callback,
            policy_file=policy_file,
            audit_log_path=audit_log_path,
        )(fn)

    def decorator(obj: Any) -> Any:
        # Case 1: LangChain tool instance (BaseTool). Patch _run/_arun.
        if isinstance(obj, BaseTool):
            # Wrap _run (sync)
            if hasattr(obj, "_run") and callable(getattr(obj, "_run")):
                original_run = obj._run  # type: ignore[attr-defined]
                if action_type == "execute_shell":

                    def run_impl(command: str, *args: Any, **kwargs: Any) -> Any:
                        return original_run(command, *args, **kwargs)

                    obj._run = _wrap_callable(run_impl)  # type: ignore[attr-defined]
                elif action_type == "modify_file":

                    def run_impl(path: str, *args: Any, **kwargs: Any) -> Any:
                        return original_run(path, *args, **kwargs)

                    obj._run = _wrap_callable(run_impl)  # type: ignore[attr-defined]
                elif action_type == "call_external_api":

                    def run_impl(url: str, *args: Any, **kwargs: Any) -> Any:
                        return original_run(url, *args, **kwargs)

                    obj._run = _wrap_callable(run_impl)  # type: ignore[attr-defined]
                else:

                    def run_impl(*args: Any, **kwargs: Any) -> Any:
                        return original_run(*args, **kwargs)

                    obj._run = _wrap_callable(run_impl)  # type: ignore[attr-defined]

            # Wrap _arun (async) if present
            if hasattr(obj, "_arun") and callable(getattr(obj, "_arun")):
                original_arun = obj._arun  # type: ignore[attr-defined]
                if original_arun is not None:
                    if inspect.iscoroutinefunction(original_arun):
                        if action_type == "execute_shell":

                            async def arun_impl(command: str, *args: Any, **kwargs: Any) -> Any:
                                return await original_arun(command, *args, **kwargs)

                            obj._arun = _wrap_callable(arun_impl)  # type: ignore[attr-defined]
                        elif action_type == "modify_file":

                            async def arun_impl(path: str, *args: Any, **kwargs: Any) -> Any:
                                return await original_arun(path, *args, **kwargs)

                            obj._arun = _wrap_callable(arun_impl)  # type: ignore[attr-defined]
                        elif action_type == "call_external_api":

                            async def arun_impl(url: str, *args: Any, **kwargs: Any) -> Any:
                                return await original_arun(url, *args, **kwargs)

                            obj._arun = _wrap_callable(arun_impl)  # type: ignore[attr-defined]
                        else:

                            async def arun_impl(*args: Any, **kwargs: Any) -> Any:
                                return await original_arun(*args, **kwargs)

                            obj._arun = _wrap_callable(arun_impl)  # type: ignore[attr-defined]
            return obj

        # Case 2: raw callable (less common with @tool, but supported).
        if callable(obj):
            return _wrap_callable(obj)

        raise TypeError("canopy_tool must decorate a callable or a LangChain BaseTool instance")

    return decorator
