"""Canopy adapter for LangGraph.

LangGraph nodes are typically plain callables that accept a `state` dict.
This adapter authorizes based on the state (or a payload extracted from it)
before node execution.

Usage:
    from canopy.adapters.langgraph import canopy_node

    @canopy_node(
        action_type="execute_shell",
        payload_extractor=lambda state: {"command": state["command"]},
        agent_ctx={...},
    )
    def shell_node(state: dict) -> dict:
        ...
"""

from __future__ import annotations

import functools
import inspect
from typing import Any, Callable, Dict, Optional

from canopy.core import authorize_action
from canopy.errors import CanopyPermissionError


def canopy_node(
    *,
    action_type: str,
    agent_ctx: Any = None,
    payload_extractor: Optional[Callable[[Dict[str, Any]], Dict[str, Any]]] = None,
    on_require_approval: str = "raise",
    policy_file: Optional[str] = None,
    audit_log_path: Optional[str] = None,
) -> Callable[[Callable[..., Any]], Callable[..., Any]]:
    """Decorator for LangGraph node functions."""

    try:  # pragma: no cover
        import langgraph  # noqa: F401
    except ImportError as e:  # pragma: no cover
        raise ImportError("langgraph is required: pip install langgraph") from e

    def _resolve_ctx() -> Dict[str, Any]:
        if callable(agent_ctx):
            return dict(agent_ctx() or {})
        return dict(agent_ctx or {})

    def decorator(func: Callable[..., Any]) -> Callable[..., Any]:
        @functools.wraps(func)
        def sync_wrapper(state: Dict[str, Any], *args: Any, **kwargs: Any) -> Any:
            payload = payload_extractor(state) if payload_extractor else dict(state)
            result = authorize_action(
                agent_ctx=_resolve_ctx(),
                action_type=action_type,
                action_payload=payload,
                policy_file=policy_file,
                audit_log_path=audit_log_path,
            )
            decision = str(result.get("decision") or "").upper()
            if decision == "DENY":
                raise CanopyPermissionError(result)
            if decision == "REQUIRE_APPROVAL":
                mode = (on_require_approval or "raise").lower()
                if mode == "raise":
                    raise CanopyPermissionError(result)
                if mode == "skip":
                    return state
                raise ValueError("on_require_approval must be one of: 'raise', 'skip'")
            return func(state, *args, **kwargs)

        @functools.wraps(func)
        async def async_wrapper(state: Dict[str, Any], *args: Any, **kwargs: Any) -> Any:
            payload = payload_extractor(state) if payload_extractor else dict(state)
            result = authorize_action(
                agent_ctx=_resolve_ctx(),
                action_type=action_type,
                action_payload=payload,
                policy_file=policy_file,
                audit_log_path=audit_log_path,
            )
            decision = str(result.get("decision") or "").upper()
            if decision == "DENY":
                raise CanopyPermissionError(result)
            if decision == "REQUIRE_APPROVAL":
                mode = (on_require_approval or "raise").lower()
                if mode == "raise":
                    raise CanopyPermissionError(result)
                if mode == "skip":
                    return state
                raise ValueError("on_require_approval must be one of: 'raise', 'skip'")
            return await func(state, *args, **kwargs)

        return async_wrapper if inspect.iscoroutinefunction(func) else sync_wrapper

    return decorator
