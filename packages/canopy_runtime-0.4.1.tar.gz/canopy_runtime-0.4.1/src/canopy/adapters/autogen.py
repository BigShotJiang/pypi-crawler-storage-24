"""Canopy adapter for AutoGen (agentchat).

AutoGen tools are typically plain Python callables registered with an agent
via register_for_execution(). This adapter wraps the callable with Canopy.

Usage:
    from canopy.adapters.autogen import canopy_autogen_tool

    @canopy_autogen_tool(action_type="execute_shell", agent_ctx={...})
    def run_shell(command: str) -> str:
        ...

    agent.register_for_execution()(run_shell)
"""

from __future__ import annotations

from typing import Any, Callable, Optional

from canopy.decorators import safe_tool


def canopy_autogen_tool(
    *,
    action_type: str,
    agent_ctx: Any = None,
    on_require_approval: str = "raise",
    approval_callback: Optional[Callable[..., Any]] = None,
    policy_file: Optional[str] = None,
    audit_log_path: Optional[str] = None,
) -> Callable[[Callable[..., Any]], Callable[..., Any]]:
    """Decorator that adds Canopy governance to an AutoGen tool function."""

    try:  # pragma: no cover
        import autogen  # noqa: F401
    except ImportError as e:  # pragma: no cover
        raise ImportError("autogen is required: pip install pyautogen") from e

    def decorator(func: Callable[..., Any]) -> Callable[..., Any]:
        return safe_tool(
            action_type=action_type,
            agent_ctx=agent_ctx,
            on_require_approval=on_require_approval,
            approval_callback=approval_callback,
            policy_file=policy_file,
            audit_log_path=audit_log_path,
        )(func)

    return decorator
