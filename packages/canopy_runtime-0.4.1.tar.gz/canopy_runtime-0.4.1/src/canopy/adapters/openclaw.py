"""Canopy adapter for OpenClaw.

OpenClaw's public tool API is not standardized here. This adapter assumes
tools are registered as plain Python callables (similar to AutoGen).

If OpenClaw uses a different abstraction (classes, its own decorators, etc.),
adjust this adapter to wrap the concrete execution method the framework calls.
"""

from __future__ import annotations

from typing import Any, Callable, Optional

from canopy.decorators import safe_tool


def canopy_openclaw_tool(
    *,
    action_type: str,
    agent_ctx: Any = None,
    on_require_approval: str = "raise",
    approval_callback: Optional[Callable[..., Any]] = None,
    policy_file: Optional[str] = None,
    audit_log_path: Optional[str] = None,
) -> Callable[[Callable[..., Any]], Callable[..., Any]]:
    """Decorator that adds Canopy governance to an OpenClaw tool function."""

    try:  # pragma: no cover
        import openclaw  # noqa: F401
    except ImportError as e:  # pragma: no cover
        raise ImportError("openclaw is required (adapter is best-effort)") from e

    def decorator(func: Callable[..., Any]) -> Callable[..., Any]:
        return safe_tool(
            action_type=action_type,
            agent_ctx=agent_ctx,
            on_require_approval=on_require_approval,
            approval_callback=approval_callback,
            policy_file=policy_file,
            audit_log_path=audit_log_path,
        )(func)

    return decorator
