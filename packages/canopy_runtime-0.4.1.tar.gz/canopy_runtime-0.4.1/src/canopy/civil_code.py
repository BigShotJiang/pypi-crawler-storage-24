"""Canopy Civil Code — configurable operational governance layer.

Design principle:
    The Civil Code contains conservative defaults that a legitimate creator
    can relax explicitly via `agent_ctx`. It runs AFTER the immutable
    Constitution and BEFORE technical firewall patterns and user policy YAML.
"""

from __future__ import annotations

import hashlib
import hmac
import json
import re
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple
from urllib.parse import urlparse


CIVIL_CODE_ID = "Canopy-Civil-Code-v1.0"
CIVIL_CODE_VERSION = "1.0"

_TITLE_NAMES = {
    "Title I": "Autonomy and Agency Limits",
    "Title II": "Financial Actions",
    "Title III": "Personal Data and Privacy",
    "Title IV": "External Communication",
    "Title V": "Sub-agent Creation and Delegation",
    "Title VI": "Resource Accumulation",
    "Title VII": "Physical Systems and Actuators",
    "Title VIII": "Non-Aggression and Security",
    "Title IX": "Governance Integrity",
    "Title X": "Sustainability and Shared Resources",
}

CIVIL_CODE_SUMMARY = {
    "id": CIVIL_CODE_ID,
    "version": CIVIL_CODE_VERSION,
    "titles": [{"id": k, "name": v} for k, v in _TITLE_NAMES.items()],
}


def civil_code_hash() -> str:
    payload = json.dumps(CIVIL_CODE_SUMMARY, sort_keys=True, separators=(",", ":")).encode("utf-8")
    return hashlib.sha256(payload).hexdigest()


def title_label(title: str) -> str:
    name = _TITLE_NAMES.get(title)
    return f"{title} — {name}" if name else title


@dataclass(frozen=True)
class CivilCodeResult:
    allowed: bool
    violated_title: Optional[str]  # "Title II", "Title VI", etc.
    explanation: str
    severity: str
    witness: Dict[str, Any]
    override_possible: bool
    override_key: Optional[str]
    decision: str  # "ALLOW" | "DENY" | "REQUIRE_APPROVAL"


_WITNESS_HMAC_KEY = b"canopy-civil-code-v1"


def _canonical_json(obj: Any) -> bytes:
    return json.dumps(obj, sort_keys=True, separators=(",", ":"), ensure_ascii=False, default=str).encode("utf-8")


def _hmac_sign(unsigned_payload: Dict[str, Any]) -> str:
    return hmac.new(_WITNESS_HMAC_KEY, _canonical_json(unsigned_payload), hashlib.sha256).hexdigest()


def _now_iso() -> str:
    return datetime.now(timezone.utc).replace(microsecond=0).isoformat().replace("+00:00", "Z")


def _witness(
    *,
    event: str,
    avid: Optional[str],
    violated_title: str,
    explanation: str,
    context: Optional[Dict[str, Any]] = None,
    original_prompt_hash: Optional[str] = None,
    internal_reasoning: Optional[str] = None,
) -> Dict[str, Any]:
    base: Dict[str, Any] = {
        "event": event,
        "avid": avid or "unknown",
        "civil_code_id": CIVIL_CODE_ID,
        "civil_code_version": CIVIL_CODE_VERSION,
        "civil_code_hash": civil_code_hash(),
        "timestamp": _now_iso(),
        "violated_title": violated_title,
        "explanation": explanation,
        "original_prompt_hash": original_prompt_hash,
        "internal_reasoning": internal_reasoning,
        "context": context or {},
    }
    base["signature"] = _hmac_sign(base)
    return base


def verify_civil_witness(witness: Dict[str, Any]) -> bool:
    sig = witness.get("signature")
    if not isinstance(sig, str) or not sig:
        return False
    unsigned = {k: v for k, v in witness.items() if k != "signature"}
    expected = _hmac_sign(unsigned)
    return hmac.compare_digest(sig, expected)


_FIN_ACTION_TYPES = {"spend_money", "purchase", "pay", "transfer_funds", "invoice", "subscribe"}
_DEFAULT_SPEND_LIMIT = 10.0

_MINING_PATTERNS = ("xmrig", "ethminer", "minerd", "cryptominer")

_PHYSICAL_ACTION_MARKERS = ("robot", "drone", "actuator", "motor", "servo", "hardware")

_GOVERNANCE_PROTECTED_FILENAMES = {
    "constitution.py",
    "civil_code.py",
    "firewall.py",
    "default.yaml",
    "policy.yaml",
}

_SECURITY_DENY = ("ddos", "ransomware", "credential stuffing", "brute force")
_SECURITY_REQUIRE = ("nmap", "masscan", "sqlmap", "metasploit", "msfconsole")

_EMAIL_RX = re.compile(r"(?i)\b[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}\b")
_SSN_RX = re.compile(r"\b\d{3}-\d{2}-\d{4}\b")
_CC_RX = re.compile(r"(?<!\d)(?:\d[ -]*?){13,19}(?!\d)")

# Title I (Autonomy) high-impact action types.
# Intentionally excludes `execute_shell`: technical risk is handled by Firewall + Policy.
_TITLE_I_HIGH_IMPACT = {
    "spend_money",
    "purchase",
    "pay",
    "transfer_funds",
    "send_email",
    "post_to_social",
    "publish",
    "spawn_agent",
    "create_agent",
    "delegate_task",
    "deploy",
    "modify_file",  # gated only when outside safe_paths (see Title I logic)
}


def _payload_text(action_type: str, payload: Dict[str, Any]) -> str:
    at = (action_type or "").strip().lower()
    p = payload or {}
    if at in {"execute_shell", "execute_shell_command", "shell"}:
        return str(p.get("command") or p.get("cmd") or p.get("shell") or "")
    if at == "modify_file":
        return f"{p.get('path', '')} {str(p.get('content', ''))[:2000]}".strip()
    if at == "call_external_api":
        return f"{p.get('url') or p.get('endpoint') or ''} {str(p.get('body') or p.get('data') or '')[:2000]}".strip()
    return json.dumps(p, ensure_ascii=False, default=str)


def _domain_from_url(url: str) -> str:
    raw = (url or "").strip()
    if not raw:
        return ""
    if "://" not in raw:
        raw = "https://" + raw
    try:
        return (urlparse(raw).hostname or "").lower()
    except Exception:
        return ""


def _severity_for_spend(amount: float, threshold: float) -> str:
    if threshold <= 0:
        return "high"
    ratio = amount / threshold
    if ratio >= 10:
        return "critical"
    if ratio >= 2:
        return "high"
    return "medium"


def evaluate(
    *,
    avid: Optional[str],
    action_type: str,
    action_payload: Dict[str, Any],
    agent_ctx: Optional[Dict[str, Any]] = None,
    agent_reputation: Optional[float] = None,  # reserved for future titles
    original_prompt_hash: Optional[str] = None,
    internal_reasoning: Optional[str] = None,
) -> CivilCodeResult:
    # Security assumption: agent_ctx and action_payload are trusted runtime
    # inputs from the caller/integrator. In particular, payload fields like
    # `user_confirmed` are only meaningful if the caller sets them honestly.
    payload = action_payload or {}
    ctx = agent_ctx or {}
    action_norm = (action_type or "").strip().lower()
    text = _payload_text(action_type, payload)

    eval_ctx = {"action_type": action_type}

    def _allow(explanation: str = "Allowed: no civil code restriction triggered.") -> CivilCodeResult:
        return CivilCodeResult(
            allowed=True,
            violated_title=None,
            explanation=explanation,
            severity="low",
            witness=_witness(
                event="civil_allow",
                avid=avid,
                violated_title="",
                explanation=explanation,
                context=eval_ctx,
                original_prompt_hash=original_prompt_hash,
                internal_reasoning=internal_reasoning,
            ),
            override_possible=False,
            override_key=None,
            decision="ALLOW",
        )

    def _deny(
        title: str,
        explanation: str,
        severity: str,
        *,
        override_possible: bool,
        override_key: Optional[str],
        extra_ctx: Optional[Dict[str, Any]] = None,
    ) -> CivilCodeResult:
        return CivilCodeResult(
            allowed=False,
            violated_title=title,
            explanation=explanation,
            severity=severity,
            witness=_witness(
                event="civil_deny",
                avid=avid,
                violated_title=title,
                explanation=explanation,
                context={**eval_ctx, **(extra_ctx or {})},
                original_prompt_hash=original_prompt_hash,
                internal_reasoning=internal_reasoning,
            ),
            override_possible=override_possible,
            override_key=override_key,
            decision="DENY",
        )

    def _require(
        title: str,
        explanation: str,
        severity: str,
        *,
        override_possible: bool,
        override_key: Optional[str],
        extra_ctx: Optional[Dict[str, Any]] = None,
    ) -> CivilCodeResult:
        return CivilCodeResult(
            allowed=False,
            violated_title=title,
            explanation=explanation,
            severity=severity,
            witness=_witness(
                event="civil_require_approval",
                avid=avid,
                violated_title=title,
                explanation=explanation,
                context={**eval_ctx, **(extra_ctx or {})},
                original_prompt_hash=original_prompt_hash,
                internal_reasoning=internal_reasoning,
            ),
            override_possible=override_possible,
            override_key=override_key,
            decision="REQUIRE_APPROVAL",
        )

    # ── Title IX: Governance integrity (no override) ─────────────────────────
    # NOTE: Covers write operations only (modify_file). There is no standard
    # read_file action_type in v0.3.x. When a read action_type is introduced,
    # extend this title to cover read access to governance files as well.
    if action_norm == "modify_file":
        raw_path = str(payload.get("path") or "")
        filename = Path(raw_path).name.lower()
        if filename in _GOVERNANCE_PROTECTED_FILENAMES:
            return _deny(
                "Title IX",
                f"Denied by Civil Code (Title IX — Governance Integrity): modifying '{filename}' is forbidden.",
                "critical",
                override_possible=False,
                override_key=None,
                extra_ctx={"path": raw_path, "protected_file": filename},
            )

    # ── Title VII: Physical systems (default deny) ───────────────────────────
    if any(m in action_norm for m in _PHYSICAL_ACTION_MARKERS):
        allowed_actions = ctx.get("physical_actions")
        if isinstance(allowed_actions, list):
            allowed_set = {str(x) for x in allowed_actions}
            if action_type in allowed_set:
                return _allow("Allowed by Civil Code (Title VII): physical action is explicitly permitted.")
            return _require(
                "Title VII",
                "Requires approval (Title VII — Physical Systems): physical action not in agent_ctx['physical_actions'].",
                "high",
                override_possible=True,
                override_key="agent_ctx['physical_actions'] = ['...']",
            )
        return _deny(
            "Title VII",
            "Denied by Civil Code (Title VII — Physical Systems): physical actions are disabled by default.",
            "critical",
            override_possible=True,
            override_key="agent_ctx['physical_actions'] = ['...']",
        )

    # ── Title II: Financial actions ──────────────────────────────────────────
    if action_norm in _FIN_ACTION_TYPES:
        try:
            amount = float(payload.get("amount", 0) or 0)
        except (TypeError, ValueError):
            amount = 0.0

        limit = ctx.get("spending_limit")
        if isinstance(limit, str) and limit.strip().lower() == "unlimited":
            return _allow("Allowed by Civil Code (Title II): spending_limit is unlimited.")

        threshold = _DEFAULT_SPEND_LIMIT
        override_key = "agent_ctx['spending_limit'] = <number> | 'unlimited'"
        if limit is not None:
            try:
                threshold = float(limit)
            except (TypeError, ValueError):
                threshold = _DEFAULT_SPEND_LIMIT

        if amount > threshold:
            return _require(
                "Title II",
                f"Requires approval (Title II — Financial Actions): amount ${amount:.2f} exceeds spending_limit ${threshold:.2f}.",
                _severity_for_spend(amount, threshold),
                override_possible=True,
                override_key=override_key,
                extra_ctx={"amount": amount, "threshold": threshold},
            )
        return _allow("Allowed by Civil Code (Title II): amount within spending_limit.")

    # ── Title VI: Resource accumulation (mining default deny) ─────────────────
    if action_norm in {"execute_shell", "execute_shell_command", "shell"}:
        cmd_lower = text.lower()
        if any(p in cmd_lower for p in _MINING_PATTERNS):
            if ctx.get("mining_authorized") is True:
                return _allow("Allowed by Civil Code (Title VI): mining is explicitly authorized.")
            return _deny(
                "Title VI",
                "Denied by Civil Code (Title VI — Resource Accumulation): crypto mining not authorized.",
                "high",
                override_possible=True,
                override_key="agent_ctx['mining_authorized'] = True",
                extra_ctx={"matched": "mining_pattern"},
            )

    if action_norm in {"crypto_mining", "mine_crypto"}:
        if ctx.get("mining_authorized") is True:
            return _allow("Allowed by Civil Code (Title VI): mining is explicitly authorized.")
        return _deny(
            "Title VI",
            "Denied by Civil Code (Title VI — Resource Accumulation): crypto mining not authorized.",
            "high",
            override_possible=True,
            override_key="agent_ctx['mining_authorized'] = True",
        )

    # ── Title I: Autonomy & agency limits ────────────────────────────────────
    title_i_applies = action_norm in _TITLE_I_HIGH_IMPACT
    if action_norm == "modify_file":
        raw_path = str(payload.get("path") or "")
        safe_paths = ctx.get("safe_paths")
        safe_prefixes = [str(x) for x in safe_paths] if isinstance(safe_paths, list) else []
        # If the write is inside safe_paths, Title I does not gate it.
        if safe_prefixes and any(raw_path.startswith(p) for p in safe_prefixes):
            title_i_applies = False

    if title_i_applies:
        if ctx.get("autonomous_mode") is True:
            pass
        else:
            user_confirmed = payload.get("user_confirmed")
            if user_confirmed is not True:
                return _require(
                    "Title I",
                    "Requires approval (Title I — Autonomy): high-impact action missing payload['user_confirmed'].",
                    "medium",
                    override_possible=True,
                    override_key="agent_ctx['autonomous_mode'] = True",
                )

    # ── Title III: Personal data & privacy (minimal heuristic) ────────────────
    pii_hit = _EMAIL_RX.search(text) or _SSN_RX.search(text) or _CC_RX.search(text)
    if pii_hit:
        if action_norm == "call_external_api":
            url = str(payload.get("url") or payload.get("endpoint") or "")
            domain = _domain_from_url(url)
            trusted = ctx.get("trusted_domains", [])
            trusted_list = [str(x).strip().lower() for x in trusted] if isinstance(trusted, list) else []
            trusted_list = [t for t in trusted_list if t]

            # Strict by default: without an explicit allowlist, PII must not leave.
            if not trusted_list:
                return _deny(
                    "Title III",
                    "Denied by Civil Code (Title III — Privacy): PII transmission requires agent_ctx['trusted_domains'] allowlist.",
                    "high",
                    override_possible=True,
                    override_key="agent_ctx['trusted_domains'] = ['...']",
                    extra_ctx={"domain": domain or None},
                )

            allowed = False
            if domain:
                for t in trusted_list:
                    if domain == t or domain.endswith("." + t):
                        allowed = True
                        break
            if not allowed:
                return _deny(
                    "Title III",
                    "Denied by Civil Code (Title III — Privacy): PII cannot be transmitted to non-trusted domains.",
                    "high",
                    override_possible=True,
                    override_key="agent_ctx['trusted_domains'] = ['...']",
                    extra_ctx={"domain": domain},
                )
        return _require(
            "Title III",
            "Requires approval (Title III — Privacy): possible PII detected in payload.",
            "medium",
            override_possible=True,
            override_key="agent_ctx['privacy_scope'] = ['...']",
        )

    # ── Title IV: External communication (minimal) ────────────────────────────
    if action_norm in {"send_email", "post_to_social", "send_message", "publish"}:
        channels = ctx.get("communication_channels")
        allowed = {str(x) for x in channels} if isinstance(channels, list) else set()
        if allowed and action_type in allowed:
            return _allow("Allowed by Civil Code (Title IV): channel is explicitly permitted.")
        # bulk / broadcast heuristic
        if action_norm in {"bulk_email", "broadcast"} or (isinstance(payload.get("recipients"), list) and len(payload["recipients"]) > 10):
            if ctx.get("bulk_authorized") is True:
                return _allow("Allowed by Civil Code (Title IV): bulk communication is authorized.")
            return _deny(
                "Title IV",
                "Denied by Civil Code (Title IV — Communication): bulk/broadcast not authorized.",
                "high",
                override_possible=True,
                override_key="agent_ctx['bulk_authorized'] = True",
            )
        return _require(
            "Title IV",
            "Requires approval (Title IV — Communication): external communication requires approval by default.",
            "medium",
            override_possible=True,
            override_key="agent_ctx['communication_channels'] = ['...']",
        )

    # ── Title V: Sub-agent creation/delegation (minimal) ──────────────────────
    if action_norm in {"spawn_agent", "create_agent", "delegate_task"}:
        if ctx.get("can_spawn_agents") is True:
            # Deny privilege escalation: requested_permissions must be subset of parent permissions
            req = payload.get("requested_permissions")
            parent = ctx.get("permissions")
            if isinstance(req, list) and isinstance(parent, list):
                req_set = {str(x) for x in req}
                parent_set = {str(x) for x in parent}
                if not req_set.issubset(parent_set):
                    return _deny(
                        "Title V",
                        "Denied by Civil Code (Title V — Sub-agents): sub-agent would exceed parent permissions.",
                        "high",
                        override_possible=False,
                        override_key=None,
                    )
            return _allow("Allowed by Civil Code (Title V): creator authorized sub-agent creation.")
        return _require(
            "Title V",
            "Requires approval (Title V — Sub-agents): spawning/delegation requires creator authorization.",
            "medium",
            override_possible=True,
            override_key="agent_ctx['can_spawn_agents'] = True",
        )

    # ── Title VIII: Non-aggression and security (minimal) ─────────────────────
    text_lower = text.lower()
    if any(p in text_lower for p in _SECURITY_DENY):
        return _deny(
            "Title VIII",
            "Denied by Civil Code (Title VIII — Security): malicious security pattern detected.",
            "critical",
            override_possible=False,
            override_key=None,
        )
    if any(p in text_lower for p in _SECURITY_REQUIRE):
        if ctx.get("security_testing_authorized") is True:
            return _allow("Allowed by Civil Code (Title VIII): security testing is authorized.")
        return _require(
            "Title VIII",
            "Requires approval (Title VIII — Security): offensive security tooling requires explicit authorization.",
            "high",
            override_possible=True,
            override_key="agent_ctx['security_testing_authorized'] = True",
        )

    # Titles X (sustainability) is intentionally conservative and overlaps with Title VI;
    # it is reserved for future expansion (high-compute authorization, shared resources).

    return _allow()


def as_public_document() -> Dict[str, Any]:
    return {
        "civil_code_id": CIVIL_CODE_ID,
        "civil_code_version": CIVIL_CODE_VERSION,
        "civil_code_hash": civil_code_hash(),
        "summary": CIVIL_CODE_SUMMARY,
    }
