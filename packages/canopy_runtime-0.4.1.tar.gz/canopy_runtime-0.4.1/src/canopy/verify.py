from __future__ import annotations

import argparse
import sys
from pathlib import Path

from .audit import HashChainAuditLog, _GENESIS_HASH


def main(argv: list[str] | None = None) -> int:
    p = argparse.ArgumentParser(description="Verify a Canopy hash-chain audit log (JSONL).")
    p.add_argument("audit_log_path", nargs="?", default="audit.log", help="path to audit log (default: ./audit.log)")
    p.add_argument("--quiet", action="store_true", help="suppress output; use exit code only")
    args = p.parse_args(argv)

    path = Path(args.audit_log_path)
    log = HashChainAuditLog(path)
    ok = log.verify_integrity()
    entries = list(log.iter_entries())

    if not args.quiet:
        first_ts = str(entries[0].get("timestamp", "")) if entries else ""
        last_ts = str(entries[-1].get("timestamp", "")) if entries else ""
        genesis_valid = True
        if entries:
            genesis_valid = str(entries[0].get("prev_hash", "")) == _GENESIS_HASH

        print("Canopy Chain Verification")
        print("─────────────────────────")
        print(f"File         : {path}")
        print(f"Entries      : {len(entries)}")
        print(f"Genesis      : {'valid' if genesis_valid else 'invalid'}")
        print(f"First entry  : {first_ts}")
        print(f"Last entry   : {last_ts}")
        print(f"Chain Status : {'✓ VALID' if ok else '✗ INVALID'}")
        print("")
        if ok:
            print(f"All {len(entries)} entries verified. No tampering detected.")
        else:
            print("Verification failed. Audit chain appears tampered or inconsistent.")

    return 0 if ok else 1


if __name__ == "__main__":
    raise SystemExit(main())
