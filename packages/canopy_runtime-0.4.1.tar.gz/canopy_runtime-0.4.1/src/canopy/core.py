from __future__ import annotations

import hashlib
import os
import re
from enum import Enum
from pathlib import Path
from typing import Any, Dict, List, Optional

from .audit import HashChainAuditLog
from .civil_code import evaluate as _civil_code_evaluate
from .civil_code import title_label as _civil_title_label
from .constitution import constitution_hash as _constitution_hash
from .constitution import evaluate as _constitution_evaluate
from .firewall import evaluate as _firewall_evaluate
from .identity import generate_avid, verify_avid


class Decision(str, Enum):
    ALLOW = "ALLOW"
    DENY = "DENY"
    REQUIRE_APPROVAL = "REQUIRE_APPROVAL"


SEVERITY_LOW = "low"
SEVERITY_MEDIUM = "medium"
SEVERITY_HIGH = "high"
SEVERITY_CRITICAL = "critical"

_SEVERITY_RANK = {SEVERITY_LOW: 0, SEVERITY_MEDIUM: 1, SEVERITY_HIGH: 2, SEVERITY_CRITICAL: 3}


def _max_severity(a: str, b: str) -> str:
    return a if _SEVERITY_RANK.get(a, 0) >= _SEVERITY_RANK.get(b, 0) else b


def _parse_minimal_yaml(text: str) -> Dict[str, Any]:
    """Parse a tiny subset of YAML without external dependencies.

    Supports:
      rules:
        - action_type: "execute_shell"
          deny_if: "rm -rf"
        - action_type: "execute_shell"
          deny_if:
            - "sudo"
            - "mkfs"
          deny_regex: 'rm\\s+-rf'
        - action_type: "call_external_api"
          require_approval: true
    """
    raw_lines = text.splitlines()
    for idx, raw in enumerate(raw_lines, start=1):
        if "\t" in raw:
            raise ValueError(f"Tabs are not supported in policy YAML (line {idx})")

    lines = [ln.rstrip("\n") for ln in raw_lines if ln.strip() and not ln.strip().startswith("#")]
    out: Dict[str, Any] = {"rules": []}
    rules: List[Dict[str, Any]] = out["rules"]

    def parse_scalar(v: str) -> Any:
        v = v.strip()
        if v.lower() in {"true", "false"}:
            return v.lower() == "true"
        if (v.startswith('"') and v.endswith('"')) or (v.startswith("'") and v.endswith("'")):
            return v[1:-1]
        return v

    i = 0
    in_rules = False
    current: Optional[Dict[str, Any]] = None
    while i < len(lines):
        ln = lines[i]
        stripped = ln.lstrip(" ")
        indent = len(ln) - len(stripped)
        if indent == 0 and stripped == "rules:":
            in_rules = True
            current = None
            i += 1
            continue

        if not in_rules:
            i += 1
            continue

        if stripped.startswith("- "):
            current = {}
            rules.append(current)
            rest = stripped[2:].strip()
            if rest and ":" in rest:
                k, v = rest.split(":", 1)
                current[k.strip()] = parse_scalar(v)
            i += 1
            continue

        if current is not None and ":" in stripped:
            k, v = stripped.split(":", 1)
            key = k.strip()
            val = v.strip()
            if val == "":
                items: List[Any] = []
                i += 1
                while i < len(lines):
                    ln2 = lines[i]
                    stripped2 = ln2.lstrip(" ")
                    indent2 = len(ln2) - len(stripped2)
                    if indent2 <= indent:
                        break
                    if stripped2.startswith("- "):
                        items.append(parse_scalar(stripped2[2:]))
                    i += 1
                current[key] = items
                continue
            current[key] = parse_scalar(val)
        i += 1
    if not in_rules:
        raise ValueError("Policy YAML must include a top-level 'rules:' key")
    if not isinstance(out.get("rules"), list) or len(out["rules"]) == 0:
        raise ValueError("Policy YAML must define at least one rule")
    return out


def load_policies(policy_file: str | Path) -> Dict[str, Any]:
    return _parse_minimal_yaml(Path(policy_file).read_text(encoding="utf-8"))


def _default_policy_file() -> Path:
    return Path(__file__).with_name("policies") / "default.yaml"


def _payload_text(payload: Any) -> str:
    if payload is None:
        return ""
    if isinstance(payload, str):
        return payload
    if isinstance(payload, dict):
        # Prefer deterministic rendering for matching/logging.
        try:
            import json

            return json.dumps(payload, sort_keys=True, separators=(",", ":"), ensure_ascii=False, default=str)
        except Exception:
            return str(payload)
    return str(payload)


def _match_text(action_type: str, action_payload: Any) -> str:
    """Extract the primary matching string for a given action type.

    This keeps policies stable when payloads are structured dicts.
    """
    if isinstance(action_payload, dict):
        if action_type == "execute_shell":
            return str(action_payload.get("command", "") or "")
        if action_type == "modify_file":
            return str(action_payload.get("path", "") or "")
        if action_type == "call_external_api":
            return str(action_payload.get("url", "") or action_payload.get("endpoint", "") or "")
    return _payload_text(action_payload)


def _safe_paths(ctx: Dict[str, Any]) -> List[str]:
    sp = ctx.get("safe_paths")
    if isinstance(sp, list):
        return [str(x) for x in sp]
    return []


def _parse_condition_list(v: Any) -> List[str]:
    if isinstance(v, str):
        s = v.strip()
        return [s] if s else []
    if isinstance(v, list):
        out: List[str] = []
        for item in v:
            s = str(item).strip()
            if s:
                out.append(s)
        return out
    return []


def _parse_scalar_expr(text: str) -> Any:
    t = text.strip()
    if not t:
        return ""
    if t.lower() in {"true", "false"}:
        return t.lower() == "true"
    if (t.startswith('"') and t.endswith('"')) or (t.startswith("'") and t.endswith("'")):
        return t[1:-1]
    return t


def _eval_predicate(
    predicate: str,
    *,
    agent_ctx: Dict[str, Any],
    action_type: str,
    action_payload: Any,
    payload_text: str,
) -> bool:
    p = predicate.strip()
    negated = False
    if p.startswith("!"):
        negated = True
        p = p[1:].strip()
    elif p.lower().startswith("not "):
        negated = True
        p = p[4:].strip()

    m = re.match(r"^(?:agent_ctx|ctx)\.([A-Za-z_][\w-]*)\s*(==|!=)\s*(.+)$", p)
    if m:
        key, op, rhs = m.group(1), m.group(2), m.group(3)
        lhs = agent_ctx.get(key)
        rhs_val = _parse_scalar_expr(rhs)
        ok = (lhs == rhs_val) if op == "==" else (lhs != rhs_val)
        return (not ok) if negated else ok

    m = re.match(r"^payload\.([A-Za-z_][\w-]*)\s*(==|!=)\s*(.+)$", p)
    if m:
        key, op, rhs = m.group(1), m.group(2), m.group(3)
        lhs = action_payload.get(key) if isinstance(action_payload, dict) else None
        rhs_val = _parse_scalar_expr(rhs)
        ok = (lhs == rhs_val) if op == "==" else (lhs != rhs_val)
        return (not ok) if negated else ok

    m = re.match(r"^action_type\s*(==|!=)\s*(.+)$", p)
    if m:
        op, rhs = m.group(1), m.group(2)
        rhs_val = str(_parse_scalar_expr(rhs))
        ok = (action_type == rhs_val) if op == "==" else (action_type != rhs_val)
        return (not ok) if negated else ok

    m = re.match(r"^(?:payload|payload_text)\s+contains\s+(.+)$", p, flags=re.IGNORECASE)
    if m:
        needle = str(_parse_scalar_expr(m.group(1))).lower()
        ok = needle in payload_text.lower()
        return (not ok) if negated else ok

    m = re.match(r"^(?:payload|payload_text)\s+matches\s+(.+)$", p, flags=re.IGNORECASE)
    if m:
        raw = str(_parse_scalar_expr(m.group(1))).strip()
        if raw.startswith("/") and raw.endswith("/") and len(raw) >= 2:
            raw = raw[1:-1]
        ok = re.search(raw, payload_text) is not None
        return (not ok) if negated else ok

    import warnings

    warnings.warn(f"Unrecognized policy predicate ignored: {predicate!r}", RuntimeWarning, stacklevel=2)
    return False


def _apply_policy_rule(
    rule: Dict[str, Any],
    *,
    current_decision: Decision,
    current_reason: str,
    current_severity: str,
    current_layer_status: str,
    action_payload: Any,
    payload_text: str,
    ctx_for_avid: Dict[str, Any],
) -> tuple[Decision, str, str, str]:
    decision = current_decision
    reason = current_reason
    severity = current_severity
    layer_status = current_layer_status

    deny_regex = rule.get("deny_regex")
    regexes: List[str]
    if isinstance(deny_regex, str):
        regexes = [deny_regex]
    elif isinstance(deny_regex, list):
        regexes = [str(x) for x in deny_regex if str(x).strip()]
    else:
        regexes = []
    for rx in regexes:
        if re.search(rx, payload_text):
            return Decision.DENY, f"Denied by policy: matched /{rx}/", _max_severity(severity, SEVERITY_HIGH), "deny"

    deny_if = rule.get("deny_if")
    deny_items: List[str]
    if isinstance(deny_if, str):
        deny_items = [deny_if]
    elif isinstance(deny_if, list):
        deny_items = [str(x) for x in deny_if if str(x).strip()]
    else:
        deny_items = []
    for item in deny_items:
        if item.lower() in payload_text:
            return Decision.DENY, f"Denied by policy: matched '{item}'", _max_severity(severity, SEVERITY_HIGH), "deny"

    if rule.get("require_approval") is True:
        decision = Decision.REQUIRE_APPROVAL
        reason = "Policy requires approval"
        severity = _max_severity(severity, SEVERITY_MEDIUM)
        layer_status = "require_approval"

    require_regex = rule.get("require_approval_regex")
    req_regexes: List[str]
    if isinstance(require_regex, str):
        req_regexes = [require_regex]
    elif isinstance(require_regex, list):
        req_regexes = [str(x) for x in require_regex if str(x).strip()]
    else:
        req_regexes = []
    for rx in req_regexes:
        if re.search(rx, payload_text):
            decision = Decision.REQUIRE_APPROVAL
            reason = f"Policy requires approval: matched /{rx}/"
            severity = _max_severity(severity, SEVERITY_MEDIUM)
            layer_status = "require_approval"
            break

    require_if = rule.get("require_approval_if")
    require_items: List[str]
    if isinstance(require_if, str):
        require_items = [require_if]
    elif isinstance(require_if, list):
        require_items = [str(x) for x in require_if if str(x).strip()]
    else:
        require_items = []
    for item in require_items:
        if item.lower() in payload_text:
            decision = Decision.REQUIRE_APPROVAL
            reason = f"Policy requires approval: matched '{item}'"
            severity = _max_severity(severity, SEVERITY_MEDIUM)
            layer_status = "require_approval"
            break

    allow_if = rule.get("allow_if")
    if allow_if == "safe_paths":
        if isinstance(action_payload, dict):
            path = str(action_payload.get("path", "") or "")
        else:
            path = str(action_payload or "")
        safe_prefixes = _safe_paths(ctx_for_avid)
        if not safe_prefixes:
            if decision != Decision.REQUIRE_APPROVAL:
                decision = Decision.REQUIRE_APPROVAL
                reason = "Policy requires approval: safe_paths not configured"
                severity = _max_severity(severity, SEVERITY_MEDIUM)
                layer_status = "require_approval"
        elif any(path.startswith(prefix) for prefix in safe_prefixes):
            if decision == Decision.ALLOW:
                decision = Decision.ALLOW
                reason = "Allowed by policy: safe_paths"
                layer_status = "allow"
        else:
            return Decision.DENY, "Denied by policy: unsafe path", _max_severity(severity, SEVERITY_HIGH), "deny"

    return decision, reason, severity, layer_status


def _rule_conditions_match(
    rule: Dict[str, Any],
    *,
    agent_ctx: Dict[str, Any],
    action_type: str,
    action_payload: Any,
    payload_text: str,
) -> bool:
    when_all = _parse_condition_list(rule.get("when_all"))
    when_any = _parse_condition_list(rule.get("when_any"))
    when_not = _parse_condition_list(rule.get("when_not"))

    for pred in when_not:
        if _eval_predicate(
            pred,
            agent_ctx=agent_ctx,
            action_type=action_type,
            action_payload=action_payload,
            payload_text=payload_text,
        ):
            return False

    for pred in when_all:
        if not _eval_predicate(
            pred,
            agent_ctx=agent_ctx,
            action_type=action_type,
            action_payload=action_payload,
            payload_text=payload_text,
        ):
            return False

    if when_any:
        return any(
            _eval_predicate(
                pred,
                agent_ctx=agent_ctx,
                action_type=action_type,
                action_payload=action_payload,
                payload_text=payload_text,
            )
            for pred in when_any
        )

    return True


def _normalize_payload_dict(action_type: str, action_payload: Any) -> Dict[str, Any]:
    if isinstance(action_payload, dict):
        return dict(action_payload)
    if isinstance(action_payload, str):
        if action_type == "execute_shell":
            return {"command": action_payload}
        if action_type == "modify_file":
            return {"path": action_payload}
        if action_type == "call_external_api":
            return {"url": action_payload}
    return {}


def _result(
    decision: Decision,
    reason: str,
    avid: str,
    severity: str,
    layers: Dict[str, str],
    authorization_id: str | None = None,
    witness: Optional[Dict[str, Any]] = None,
    trace_id: str | None = None,
    policy_snapshot: Optional[Dict[str, Any]] = None,
) -> Dict[str, Any]:
    out: Dict[str, Any] = {"decision": decision.value, "reason": reason, "avid": avid, "severity": severity, "layers": layers}
    if authorization_id is not None:
        out["authorization_id"] = authorization_id
    if witness is not None:
        out["witness"] = witness
    if trace_id:
        out["trace_id"] = trace_id
    if policy_snapshot is not None:
        out["policy_snapshot"] = policy_snapshot
    return out


def _policy_snapshot(policy_file: Path) -> Dict[str, Any]:
    content = policy_file.read_text(encoding="utf-8")
    return {
        "policy_file": str(policy_file),
        "policy_hash": hashlib.sha256(content.encode("utf-8")).hexdigest()[:16],
        "policy_source": "env" if os.getenv("CANOPY_POLICY_FILE") else "default",
    }


def _write_audit(
    audit_log_path: str | Path | None,
    avid: str,
    action_type: str,
    decision: Decision,
    reason: str,
    severity: str,
    layers: Dict[str, str],
    witness: Optional[Dict[str, Any]] = None,
    *,
    override_possible: Optional[bool] = None,
    override_key: Optional[str] = None,
    constitution_witness: Optional[Dict[str, Any]] = None,
    trace_id: Optional[str] = None,
    policy_snapshot: Optional[Dict[str, Any]] = None,
) -> str:
    alp = Path(audit_log_path) if audit_log_path else Path(os.getenv("CANOPY_AUDIT_LOG_PATH", "audit.log"))
    entry = HashChainAuditLog(alp).append(
        avid=avid,
        action_type=action_type,
        decision=decision.value,
        reason=reason,
        severity=severity,
        layers=dict(layers or {}),
        witness=witness,
        event="authorize_action",
        override_possible=override_possible,
        override_key=override_key,
        constitution_witness=constitution_witness,
        trace_id=trace_id,
        policy_snapshot=policy_snapshot,
    )
    return entry.entry_hash


def authorize_action(
    agent_ctx: Dict[str, Any],
    action_type: str,
    action_payload: Any,
    *,
    policy_file: str | Path | None = None,
    audit_log_path: str | Path | None = None,
    skip_constitution: bool = False,
    skip_firewall: bool = False,
) -> Dict[str, Any]:
    ctx = dict(agent_ctx or {})
    constitution_hash = _constitution_hash()

    claimed_avid = str(ctx.pop("avid", "") or "")
    ctx_for_avid = dict(ctx)
    if claimed_avid:
        if not verify_avid(ctx_for_avid, claimed_avid, constitution_hash=constitution_hash, require_stable=True):
            expected = generate_avid(ctx_for_avid, constitution_hash=constitution_hash, require_stable=True)
            raise ValueError(f"avid mismatch: provided {claimed_avid!r}, expected {expected!r}")

    avid = generate_avid(ctx_for_avid, constitution_hash=constitution_hash, require_stable=False)

    pf_env = os.getenv("CANOPY_POLICY_FILE")
    pf = Path(policy_file) if policy_file else (Path(pf_env) if pf_env else _default_policy_file())
    policies = load_policies(pf)
    rules = policies.get("rules") if isinstance(policies.get("rules"), list) else []
    trace_id = str(ctx_for_avid.get("trace_id") or "").strip() or None
    current_policy_snapshot = _policy_snapshot(pf)

    decision = Decision.ALLOW
    reason = "Allowed by default"
    severity = SEVERITY_LOW
    layers: Dict[str, str] = {}
    witness: Optional[Dict[str, Any]] = None

    payload_dict = _normalize_payload_dict(action_type, action_payload)

    rep_raw = ctx_for_avid.get("agent_reputation", ctx_for_avid.get("reputation"))
    agent_reputation: Optional[float] = None
    try:
        if rep_raw is not None:
            agent_reputation = float(rep_raw)
    except (TypeError, ValueError):
        agent_reputation = None

    if not skip_constitution:
        constitution_result = _constitution_evaluate(
            avid=avid,
            action_type=action_type,
            action_payload=payload_dict,
            agent_ctx=ctx_for_avid,
            agent_reputation=agent_reputation,
            original_prompt_hash=ctx_for_avid.get("original_prompt_hash"),
            internal_reasoning=ctx_for_avid.get("internal_reasoning"),
        )
        witness = constitution_result.witness
        layers["constitution"] = "pass"
        if not constitution_result.allowed:
            decision = Decision.DENY
            reason = constitution_result.explanation
            severity = constitution_result.severity
            layers["constitution"] = f"blocked ({constitution_result.violated_article})"
            layers["civil_code"] = "skipped"
            layers["firewall"] = "skipped"
            layers["policy"] = "skipped"
            authorization_id = _write_audit(
                audit_log_path,
                avid,
                action_type,
                decision,
                reason,
                severity,
                layers,
                witness,
                override_possible=False,
                override_key=None,
                trace_id=trace_id,
                policy_snapshot=current_policy_snapshot,
            )
            return _result(decision, reason, avid, severity, layers, authorization_id, witness, trace_id, current_policy_snapshot)
    else:
        layers["constitution"] = "skipped"

    # ── Layer 2: Civil Code ──────────────────────────────────────────────────
    civil_code_result = _civil_code_evaluate(
        avid=avid,
        action_type=action_type,
        action_payload=payload_dict,
        agent_ctx=ctx_for_avid,
        agent_reputation=agent_reputation,
        original_prompt_hash=ctx_for_avid.get("original_prompt_hash"),
        internal_reasoning=ctx_for_avid.get("internal_reasoning"),
    )
    layers["civil_code"] = "pass"
    if not civil_code_result.allowed:
        decision = Decision.DENY if str(civil_code_result.decision).upper() == "DENY" else Decision.REQUIRE_APPROVAL
        reason = civil_code_result.explanation
        severity = civil_code_result.severity
        title = civil_code_result.violated_title or "Title"
        layers["civil_code"] = f"blocked ({_civil_title_label(title)})"
        layers["firewall"] = "skipped"
        layers["policy"] = "skipped"
        authorization_id = _write_audit(
            audit_log_path,
            avid,
            action_type,
            decision,
            reason,
            severity,
            layers,
            civil_code_result.witness,
            override_possible=bool(civil_code_result.override_possible),
            override_key=civil_code_result.override_key,
            constitution_witness=witness,
            trace_id=trace_id,
            policy_snapshot=current_policy_snapshot,
        )
        out = _result(
            decision,
            reason,
            avid,
            severity,
            layers,
            authorization_id,
            civil_code_result.witness,
            trace_id,
            current_policy_snapshot,
        )
        out["override_possible"] = bool(civil_code_result.override_possible)
        out["override_key"] = civil_code_result.override_key
        return out

    if not skip_firewall:
        firewall_result = _firewall_evaluate(action_type, payload_dict, agent_ctx=ctx_for_avid)
        layers["firewall"] = "pass"
        if firewall_result.decision != "allow":
            decision = Decision.DENY if firewall_result.decision == "deny" else Decision.REQUIRE_APPROVAL
            reason = firewall_result.reason
            severity = firewall_result.severity
            layers["firewall"] = f"blocked ({firewall_result.decision})"
            layers["policy"] = "skipped"
            authorization_id = _write_audit(
                audit_log_path,
                avid,
                action_type,
                decision,
                reason,
                severity,
                layers,
                witness,
                override_possible=False,
                override_key=None,
                trace_id=trace_id,
                policy_snapshot=current_policy_snapshot,
            )
            return _result(decision, reason, avid, severity, layers, authorization_id, witness, trace_id, current_policy_snapshot)
    else:
        layers["firewall"] = "skipped"

    payload_text = _match_text(action_type, action_payload).lower()
    layers["policy"] = "pass"
    for rule in rules:
        if not isinstance(rule, dict):
            continue
        if str(rule.get("action_type", "")).strip() != action_type:
            continue
        if not _rule_conditions_match(
            rule,
            agent_ctx=ctx_for_avid,
            action_type=action_type,
            action_payload=action_payload,
            payload_text=payload_text,
        ):
            continue
        decision, reason, severity, layers["policy"] = _apply_policy_rule(
            rule,
            current_decision=decision,
            current_reason=reason,
            current_severity=severity,
            current_layer_status=layers["policy"],
            action_payload=action_payload,
            payload_text=payload_text,
            ctx_for_avid=ctx_for_avid,
        )
        if decision == Decision.DENY:
            break

    authorization_id = _write_audit(
        audit_log_path,
        avid,
        action_type,
        decision,
        reason,
        severity,
        layers,
        witness,
        override_possible=False,
        override_key=None,
        trace_id=trace_id,
        policy_snapshot=current_policy_snapshot,
    )
    return _result(decision, reason, avid, severity, layers, authorization_id, witness, trace_id, current_policy_snapshot)
