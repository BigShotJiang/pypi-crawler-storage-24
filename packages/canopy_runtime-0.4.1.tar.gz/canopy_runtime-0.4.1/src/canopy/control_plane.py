from __future__ import annotations

import json
import sqlite3
import threading
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List, Optional


def _now_iso() -> str:
    return datetime.now(timezone.utc).replace(microsecond=0).isoformat().replace("+00:00", "Z")


def _normalize_tenant_id(value: Any) -> str:
    tenant_id = str(value or "default").strip()
    return tenant_id or "default"


def _json_dumps(value: Any) -> str:
    return json.dumps(value, sort_keys=True, ensure_ascii=False, separators=(",", ":"), default=str)


def _json_loads(value: str | None) -> Any:
    if not value:
        return None
    return json.loads(value)


def _clamp_trust_score(value: Any) -> int:
    try:
        score = int(float(value))
    except Exception:
        score = 50
    return max(0, min(100, score))


@dataclass(frozen=True)
class AgentRecord:
    tenant_id: str
    avid: str
    public_key: str
    created_at: str
    display_name: str
    framework: str
    environment: str
    owner: str
    trust_score: int
    first_seen_at: str
    last_seen_at: str
    metadata: Dict[str, Any]

    def as_dict(self) -> Dict[str, Any]:
        return {
            "tenant_id": self.tenant_id,
            "avid": self.avid,
            "public_key": self.public_key,
            "created_at": self.created_at,
            "display_name": self.display_name,
            "framework": self.framework,
            "environment": self.environment,
            "owner": self.owner,
            "trust_score": self.trust_score,
            "first_seen_at": self.first_seen_at,
            "last_seen_at": self.last_seen_at,
            "metadata": self.metadata,
        }


class ControlPlaneStore:
    """Small SQLite-backed control plane for enterprise workflows."""

    def __init__(self, path: str | Path):
        self.path = Path(path)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self._lock = threading.Lock()
        self._init_db()

    def _connect(self) -> sqlite3.Connection:
        conn = sqlite3.connect(str(self.path))
        conn.row_factory = sqlite3.Row
        return conn

    def _init_db(self) -> None:
        with self._lock:
            with self._connect() as conn:
                conn.executescript(
                    """
                    PRAGMA journal_mode=WAL;

                    CREATE TABLE IF NOT EXISTS agents (
                        tenant_id TEXT NOT NULL,
                        avid TEXT NOT NULL,
                        public_key TEXT NOT NULL,
                        created_at TEXT NOT NULL,
                        display_name TEXT NOT NULL DEFAULT '',
                        framework TEXT NOT NULL DEFAULT '',
                        environment TEXT NOT NULL DEFAULT '',
                        owner TEXT NOT NULL DEFAULT '',
                        trust_score INTEGER NOT NULL DEFAULT 50,
                        first_seen_at TEXT NOT NULL,
                        last_seen_at TEXT NOT NULL,
                        metadata_json TEXT NOT NULL DEFAULT '{}',
                        PRIMARY KEY (tenant_id, avid)
                    );

                    CREATE TABLE IF NOT EXISTS audit_events (
                        id INTEGER PRIMARY KEY AUTOINCREMENT,
                        tenant_id TEXT NOT NULL,
                        avid TEXT NOT NULL,
                        trace_id TEXT NOT NULL DEFAULT '',
                        authorization_id TEXT NOT NULL,
                        action_type TEXT NOT NULL,
                        decision TEXT NOT NULL,
                        reason TEXT NOT NULL,
                        severity TEXT NOT NULL,
                        event TEXT NOT NULL DEFAULT 'authorize_action',
                        occurred_at TEXT NOT NULL,
                        layers_json TEXT NOT NULL DEFAULT '{}',
                        witness_json TEXT,
                        policy_snapshot_json TEXT,
                        payload_json TEXT NOT NULL DEFAULT '{}'
                    );

                    CREATE INDEX IF NOT EXISTS idx_audit_events_tenant_time
                        ON audit_events (tenant_id, occurred_at DESC);

                    CREATE INDEX IF NOT EXISTS idx_audit_events_tenant_avid_time
                        ON audit_events (tenant_id, avid, occurred_at DESC);

                    CREATE TABLE IF NOT EXISTS approval_decisions (
                        id INTEGER PRIMARY KEY AUTOINCREMENT,
                        tenant_id TEXT NOT NULL,
                        authorization_id TEXT NOT NULL,
                        avid TEXT NOT NULL,
                        decision TEXT NOT NULL,
                        decided_by TEXT NOT NULL,
                        reason TEXT NOT NULL DEFAULT '',
                        decided_at TEXT NOT NULL,
                        UNIQUE (tenant_id, authorization_id)
                    );
                    """
                )

    def register_agent(self, agent_ctx: Dict[str, Any], metadata: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        metadata = dict(metadata or {})
        tenant_id = _normalize_tenant_id(agent_ctx.get("tenant_id"))
        public_key = str(agent_ctx.get("public_key") or "")
        created_at = str(agent_ctx.get("created_at") or "")
        avid = str(agent_ctx.get("avid") or "")
        if not public_key or not created_at or not avid:
            raise ValueError("agent registration requires public_key, created_at, and avid")

        now = _now_iso()
        display_name = str(agent_ctx.get("agent_name") or metadata.get("display_name") or "")
        framework = str(agent_ctx.get("framework") or metadata.get("framework") or "")
        environment = str(agent_ctx.get("environment") or metadata.get("environment") or "")
        owner = str(agent_ctx.get("owner") or metadata.get("owner") or "")
        trust_score = _clamp_trust_score(agent_ctx.get("agent_reputation", metadata.get("trust_score", 50)))

        with self._lock:
            with self._connect() as conn:
                row = conn.execute(
                    "SELECT first_seen_at FROM agents WHERE tenant_id = ? AND avid = ?",
                    (tenant_id, avid),
                ).fetchone()
                first_seen_at = str(row["first_seen_at"]) if row else now
                conn.execute(
                    """
                    INSERT INTO agents (
                        tenant_id, avid, public_key, created_at, display_name, framework,
                        environment, owner, trust_score, first_seen_at, last_seen_at, metadata_json
                    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                    ON CONFLICT(tenant_id, avid) DO UPDATE SET
                        public_key = excluded.public_key,
                        created_at = excluded.created_at,
                        display_name = excluded.display_name,
                        framework = excluded.framework,
                        environment = excluded.environment,
                        owner = excluded.owner,
                        trust_score = excluded.trust_score,
                        last_seen_at = excluded.last_seen_at,
                        metadata_json = excluded.metadata_json
                    """,
                    (
                        tenant_id,
                        avid,
                        public_key,
                        created_at,
                        display_name,
                        framework,
                        environment,
                        owner,
                        trust_score,
                        first_seen_at,
                        now,
                        _json_dumps(metadata),
                    ),
                )
                conn.commit()

        return {
            "tenant_id": tenant_id,
            "avid": avid,
            "status": "registered",
            "trust_score": trust_score,
            "first_seen_at": first_seen_at,
            "last_seen_at": now,
        }

    def list_agents(self, tenant_id: str, limit: int = 100) -> List[Dict[str, Any]]:
        tenant = _normalize_tenant_id(tenant_id)
        with self._connect() as conn:
            rows = conn.execute(
                """
                SELECT tenant_id, avid, public_key, created_at, display_name, framework,
                       environment, owner, trust_score, first_seen_at, last_seen_at, metadata_json
                FROM agents
                WHERE tenant_id = ?
                ORDER BY last_seen_at DESC
                LIMIT ?
                """,
                (tenant, max(1, min(limit, 500))),
            ).fetchall()
        return [
            AgentRecord(
                tenant_id=str(row["tenant_id"]),
                avid=str(row["avid"]),
                public_key=str(row["public_key"]),
                created_at=str(row["created_at"]),
                display_name=str(row["display_name"]),
                framework=str(row["framework"]),
                environment=str(row["environment"]),
                owner=str(row["owner"]),
                trust_score=int(row["trust_score"]),
                first_seen_at=str(row["first_seen_at"]),
                last_seen_at=str(row["last_seen_at"]),
                metadata=_json_loads(str(row["metadata_json"])) or {},
            ).as_dict()
            for row in rows
        ]

    def append_authorization(
        self,
        *,
        tenant_id: str,
        avid: str,
        authorization_id: str,
        action_type: str,
        decision: str,
        reason: str,
        severity: str,
        trace_id: Optional[str],
        layers: Dict[str, Any],
        witness: Optional[Dict[str, Any]],
        policy_snapshot: Optional[Dict[str, Any]],
        payload: Any,
        event: str = "authorize_action",
    ) -> None:
        with self._lock:
            with self._connect() as conn:
                conn.execute(
                    """
                    INSERT INTO audit_events (
                        tenant_id, avid, trace_id, authorization_id, action_type, decision, reason,
                        severity, event, occurred_at, layers_json, witness_json, policy_snapshot_json, payload_json
                    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                    """,
                    (
                        _normalize_tenant_id(tenant_id),
                        avid,
                        str(trace_id or ""),
                        authorization_id,
                        action_type,
                        decision,
                        reason,
                        severity,
                        event,
                        _now_iso(),
                        _json_dumps(layers),
                        _json_dumps(witness) if witness is not None else None,
                        _json_dumps(policy_snapshot) if policy_snapshot is not None else None,
                        _json_dumps(payload),
                    ),
                )
                conn.commit()

    def list_audit_events(self, tenant_id: str, avid: Optional[str] = None, limit: int = 100) -> List[Dict[str, Any]]:
        tenant = _normalize_tenant_id(tenant_id)
        sql = """
            SELECT tenant_id, avid, authorization_id, action_type, decision, reason,
                   severity, event, occurred_at, trace_id, layers_json, witness_json, policy_snapshot_json, payload_json
            FROM audit_events
            WHERE tenant_id = ?
        """
        params: list[Any] = [tenant]
        if avid:
            sql += " AND avid = ?"
            params.append(avid)
        sql += " ORDER BY occurred_at DESC LIMIT ?"
        params.append(max(1, min(limit, 500)))

        with self._connect() as conn:
            rows = conn.execute(sql, params).fetchall()

        events: List[Dict[str, Any]] = []
        for row in rows:
            events.append(
                {
                    "tenant_id": str(row["tenant_id"]),
                    "avid": str(row["avid"]),
                    "authorization_id": str(row["authorization_id"]),
                    "action_type": str(row["action_type"]),
                    "decision": str(row["decision"]),
                    "reason": str(row["reason"]),
                    "severity": str(row["severity"]),
                    "event": str(row["event"]),
                    "occurred_at": str(row["occurred_at"]),
                    "trace_id": str(row["trace_id"] or ""),
                    "layers": _json_loads(str(row["layers_json"])) or {},
                    "witness": _json_loads(row["witness_json"]) if row["witness_json"] else None,
                    "policy_snapshot": _json_loads(row["policy_snapshot_json"]) if row["policy_snapshot_json"] else None,
                    "payload": _json_loads(str(row["payload_json"])) or {},
                }
            )
        return events

    def record_approval_decision(
        self,
        *,
        tenant_id: str,
        authorization_id: str,
        avid: str,
        decision: str,
        decided_by: str,
        reason: str = "",
    ) -> Dict[str, Any]:
        decided_at = _now_iso()
        with self._lock:
            with self._connect() as conn:
                conn.execute(
                    """
                    INSERT INTO approval_decisions (
                        tenant_id, authorization_id, avid, decision, decided_by, reason, decided_at
                    ) VALUES (?, ?, ?, ?, ?, ?, ?)
                    ON CONFLICT(tenant_id, authorization_id) DO UPDATE SET
                        avid = excluded.avid,
                        decision = excluded.decision,
                        decided_by = excluded.decided_by,
                        reason = excluded.reason,
                        decided_at = excluded.decided_at
                    """,
                    (
                        _normalize_tenant_id(tenant_id),
                        authorization_id,
                        avid,
                        decision,
                        decided_by,
                        reason,
                        decided_at,
                    ),
                )
                conn.commit()
        return {
            "tenant_id": _normalize_tenant_id(tenant_id),
            "authorization_id": authorization_id,
            "avid": avid,
            "decision": decision,
            "decided_by": decided_by,
            "reason": reason,
            "decided_at": decided_at,
        }

    def dashboard_summary(self, tenant_id: str) -> Dict[str, Any]:
        tenant = _normalize_tenant_id(tenant_id)
        with self._connect() as conn:
            counts = conn.execute(
                """
                SELECT decision, COUNT(*) AS total
                FROM audit_events
                WHERE tenant_id = ?
                GROUP BY decision
                """,
                (tenant,),
            ).fetchall()
            agent_count = conn.execute(
                "SELECT COUNT(*) AS total FROM agents WHERE tenant_id = ?",
                (tenant,),
            ).fetchone()
            pending_approvals = conn.execute(
                """
                SELECT COUNT(*) AS total
                FROM audit_events e
                WHERE e.tenant_id = ?
                  AND e.decision = 'REQUIRE_APPROVAL'
                  AND NOT EXISTS (
                      SELECT 1
                      FROM approval_decisions a
                      WHERE a.tenant_id = e.tenant_id
                        AND a.authorization_id = e.authorization_id
                  )
                """,
                (tenant,),
            ).fetchone()

        decision_counts = {"ALLOW": 0, "DENY": 0, "REQUIRE_APPROVAL": 0}
        for row in counts:
            decision_counts[str(row["decision"])] = int(row["total"])

        return {
            "tenant_id": tenant,
            "agents": int(agent_count["total"]) if agent_count else 0,
            "pending_approvals": int(pending_approvals["total"]) if pending_approvals else 0,
            "decisions": decision_counts,
        }
