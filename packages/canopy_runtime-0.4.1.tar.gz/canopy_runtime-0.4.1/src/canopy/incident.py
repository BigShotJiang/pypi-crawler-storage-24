from __future__ import annotations

import hashlib
import os
from pathlib import Path
from typing import Any, Dict, Iterable, Optional

from .audit import HashChainAuditLog


def _incident_id(trace_id: str, avid: str, description: str, reporter: str) -> str:
    seed = f"{trace_id}|{avid}|{description}|{reporter}".encode("utf-8")
    return "inc-" + hashlib.sha256(seed).hexdigest()[:12]


def open_incident(
    *,
    trace_id: str,
    agent_avid: str,
    description: str,
    severity: str = "high",
    related_authorization_ids: Optional[Iterable[str]] = None,
    reporter: str = "unknown",
    audit_log_path: str | Path | None = None,
) -> Dict[str, Any]:
    if not str(trace_id or "").strip():
        raise ValueError("open_incident requires a non-empty trace_id")
    if not str(agent_avid or "").strip():
        raise ValueError("open_incident requires a non-empty agent_avid")
    if not str(description or "").strip():
        raise ValueError("open_incident requires a non-empty description")

    incident_id = _incident_id(str(trace_id), str(agent_avid), str(description), str(reporter))
    related = [str(item) for item in (related_authorization_ids or []) if str(item).strip()]
    log_path = Path(audit_log_path) if audit_log_path else Path(os.getenv("CANOPY_AUDIT_LOG_PATH", "audit.log"))
    entry = HashChainAuditLog(log_path).append(
        avid=str(agent_avid),
        action_type="incident",
        decision="INCIDENT",
        reason=str(description),
        severity=str(severity or "high"),
        layers={},
        witness=None,
        event="incident_event",
        trace_id=str(trace_id),
        incident_id=incident_id,
        description=str(description),
        reporter=str(reporter),
        related_authorization_ids=related,
    )
    return {
        "incident_id": incident_id,
        "trace_id": str(trace_id),
        "avid": str(agent_avid),
        "severity": str(severity or "high"),
        "description": str(description),
        "reporter": str(reporter),
        "related_authorization_ids": related,
        "timestamp": entry.timestamp,
        "entry_hash": entry.entry_hash,
    }
