from __future__ import annotations

import argparse
from pathlib import Path
from typing import Any, Dict, Iterable, List

from .audit import HashChainAuditLog


def _load_entries(path: Path) -> List[Dict[str, Any]]:
    return list(HashChainAuditLog(path).iter_entries())


def _resolve_trace(entries: List[Dict[str, Any]], trace_id: str | None, incident_id: str | None) -> tuple[str, List[Dict[str, Any]]]:
    if trace_id:
        target = str(trace_id)
        return target, [entry for entry in entries if str(entry.get("trace_id") or "") == target]

    if incident_id:
        for entry in entries:
            if str(entry.get("incident_id") or "") == incident_id:
                target = str(entry.get("trace_id") or "")
                if not target:
                    raise ValueError(f"incident {incident_id!r} does not include a trace_id")
                return target, [item for item in entries if str(item.get("trace_id") or "") == target]
        raise ValueError(f"incident {incident_id!r} not found")

    raise ValueError("either --trace or --incident is required")


def _sort_key(entry: Dict[str, Any]) -> tuple[str, str]:
    return (str(entry.get("timestamp") or ""), str(entry.get("event") or ""))


def _format_entry(entry: Dict[str, Any]) -> List[str]:
    event = str(entry.get("event") or "authorize_action").upper()
    lines = [f"[{entry.get('timestamp', '')}] {event}"]
    if event == "AUTHORIZE_ACTION":
        policy = entry.get("policy_snapshot") if isinstance(entry.get("policy_snapshot"), dict) else {}
        lines.extend(
            [
                f"  agent    : {entry.get('avid', '')}",
                f"  action   : {entry.get('action_type', '')}",
                f"  decision : {entry.get('decision', '')}",
                f"  policy   : {policy.get('policy_file', 'n/a')} ({policy.get('policy_hash', 'n/a')})",
                f"  auth_id  : {entry.get('authorization_id', entry.get('entry_hash', ''))}",
            ]
        )
    elif event == "TOOL_RESULT":
        result_hash = entry.get("result_hash", "")
        lines.extend(
            [
                f"  auth_id  : {entry.get('authorization_id', '')}",
                f"  ok       : {entry.get('ok', '')}",
                f"  result   : sha256:{str(result_hash)[:12]}..." if result_hash else "  result   : n/a",
            ]
        )
    elif event == "INCIDENT_EVENT":
        related = ", ".join(str(item) for item in (entry.get("related_authorization_ids") or []))
        lines.extend(
            [
                f"  severity : {entry.get('severity', '')}",
                f"  reporter : {entry.get('reporter', '')}",
                f"  desc     : {entry.get('description', '')}",
                f"  linked   : {related or 'n/a'}",
            ]
        )
    else:
        lines.append(f"  detail   : {entry.get('reason', '')}")
    return lines


def _export_xlsx(entries: Iterable[Dict[str, Any]], destination: Path) -> None:
    try:
        from openpyxl import Workbook  # type: ignore
    except ModuleNotFoundError as e:  # pragma: no cover
        raise ModuleNotFoundError("Excel export requires `pip install canopy-runtime[excel]`") from e

    wb = Workbook()
    ws = wb.active
    ws.title = "Incident Timeline"
    ws.append(["Timestamp", "Event", "Trace ID", "AVID", "Action", "Decision", "Severity", "Authorization ID", "Description"])
    for entry in entries:
        ws.append(
            [
                entry.get("timestamp", ""),
                entry.get("event", ""),
                entry.get("trace_id", ""),
                entry.get("avid", ""),
                entry.get("action_type", ""),
                entry.get("decision", ""),
                entry.get("severity", ""),
                entry.get("authorization_id", ""),
                entry.get("description") or entry.get("reason", ""),
            ]
        )
    wb.save(destination)


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="Render a Canopy incident timeline from an audit log.")
    parser.add_argument("audit_log_path", nargs="?", default="audit.log", help="path to audit log (default: ./audit.log)")
    parser.add_argument("--trace", dest="trace_id", help="trace_id to reconstruct")
    parser.add_argument("--incident", dest="incident_id", help="incident_id to reconstruct")
    parser.add_argument("--export", dest="export", help="optional .xlsx export path")
    args = parser.parse_args(argv)

    path = Path(args.audit_log_path)
    if not path.exists():
        print(f"Audit log not found: {path}")
        return 1

    entries = _load_entries(path)
    try:
        trace_id, trace_entries = _resolve_trace(entries, args.trace_id, args.incident_id)
    except ValueError as e:
        print(str(e))
        return 2

    trace_entries = sorted(trace_entries, key=_sort_key)
    incident_count = sum(1 for entry in trace_entries if str(entry.get("event") or "") == "incident_event")
    agents = sorted({str(entry.get("avid") or "") for entry in trace_entries if str(entry.get("avid") or "")})
    policy_files = sorted(
        {
            str((entry.get("policy_snapshot") or {}).get("policy_file"))
            for entry in trace_entries
            if isinstance(entry.get("policy_snapshot"), dict) and str((entry.get("policy_snapshot") or {}).get("policy_file") or "")
        }
    )

    print("CANOPY INCIDENT TIMELINE")
    print(f"trace_id: {trace_id}")
    print("─" * 48)
    print()
    for entry in trace_entries:
        for line in _format_entry(entry):
            print(line)
        print()
    print("─" * 48)
    policy_summary = ", ".join(policy_files) if policy_files else "n/a"
    print(f"{len(trace_entries)} events · {incident_count} incident{'s' if incident_count != 1 else ''} · {len(agents)} agent{'s' if len(agents) != 1 else ''} · policy: {policy_summary}")

    if args.export:
        _export_xlsx(trace_entries, Path(args.export))
        print(f"Exported incident timeline to {args.export}")

    return 0


if __name__ == "__main__":  # pragma: no cover
    raise SystemExit(main())
