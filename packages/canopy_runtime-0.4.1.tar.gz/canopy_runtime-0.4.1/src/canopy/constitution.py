"""Canopy Constitution — immutable pre-execution guardrail layer (v2.0).

Design principle:
    The Constitution contains only laws that can NEVER be overridden by any
    creator, agent, prompt, or configuration.

Canopy safety stack position:
    authorize_action()
        → constitution.evaluate()   ← immutable (Art.0, Art.1, Art.7)
        → civil_code.evaluate()     ← configurable defaults (10 Titles)
        → firewall.evaluate()       ← technical patterns
        → policy YAML               ← user-defined rules
        → decision

Implementation note:
    Art.1 is intentionally pattern-based in v2.0. It catches a meaningful
    subset of direct-harm prompts, but it is not semantic understanding or
    complete coverage of human-harm language. The repo should present it as an
    immutable floor with known limitations, not as exhaustive harm detection.
"""

from __future__ import annotations

import hashlib
import hmac
import ipaddress
import json
import re
from dataclasses import dataclass
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional, Tuple
from urllib.parse import urlparse

# ── Constitution identity (ID must remain stable for compatibility) ──────────

CONSTITUTION_ID = "Canopy-Constitution-v1.0"
CONSTITUTION_VERSION = "2.0"

CONSTITUTION_SUMMARY = {
    "id": CONSTITUTION_ID,
    "version": CONSTITUTION_VERSION,
    "articles": [
        {"id": "Art.0", "title": "Zeroth Law / No Catastrophic Risk", "immutable": True},
        {"id": "Art.1", "title": "Protect Human Life and Dignity", "immutable": True},
        {"id": "Art.7", "title": "Sovereign Kill Switch", "immutable": True},
    ],
}


def constitution_hash() -> str:
    payload = json.dumps(CONSTITUTION_SUMMARY, sort_keys=True, separators=(",", ":")).encode("utf-8")
    return hashlib.sha256(payload).hexdigest()


# ── Result type ───────────────────────────────────────────────────────────────

@dataclass(frozen=True)
class ConstitutionResult:
    allowed: bool
    violated_article: Optional[str]
    explanation: str
    severity: str  # "low" | "medium" | "high" | "critical"
    witness: Dict[str, Any]


# ── Art.4-like witness record (always produced) ──────────────────────────────

_WITNESS_HMAC_KEY = b"canopy-constitution-v2"


def _canonical_json(obj: Any) -> bytes:
    return json.dumps(obj, sort_keys=True, separators=(",", ":"), ensure_ascii=False, default=str).encode("utf-8")


def _hmac_sign(unsigned_payload: Dict[str, Any]) -> str:
    return hmac.new(_WITNESS_HMAC_KEY, _canonical_json(unsigned_payload), hashlib.sha256).hexdigest()


def _now_iso() -> str:
    return datetime.now(timezone.utc).replace(microsecond=0).isoformat().replace("+00:00", "Z")


def _witness(
    *,
    event: str,
    avid: Optional[str],
    violated_article: str,
    explanation: str,
    context: Optional[Dict[str, Any]] = None,
    original_prompt_hash: Optional[str] = None,
    internal_reasoning: Optional[str] = None,
) -> Dict[str, Any]:
    base: Dict[str, Any] = {
        "event": event,
        "avid": avid or "unknown",
        "constitution_id": CONSTITUTION_ID,
        "constitution_version": CONSTITUTION_VERSION,
        "constitution_hash": constitution_hash(),
        "timestamp": _now_iso(),
        "violated_article": violated_article,
        "explanation": explanation,
        "original_prompt_hash": original_prompt_hash,
        "internal_reasoning": internal_reasoning,
        "context": context or {},
    }
    base["signature"] = _hmac_sign(base)
    return base


def verify_witness(witness: Dict[str, Any]) -> bool:
    sig = witness.get("signature")
    if not isinstance(sig, str) or not sig:
        return False
    unsigned = {k: v for k, v in witness.items() if k != "signature"}
    expected = _hmac_sign(unsigned)
    return hmac.compare_digest(sig, expected)


# ── Art.1: human harm patterns (scan across all action types) ─────────────────
# These are explicit heuristics, not exhaustive semantic coverage.

_HUMAN_HARM_PATTERNS: List[Tuple[re.Pattern[str], str]] = [
    (re.compile(r"(?i)\bkill\s+yourself\b"), "Self-harm encouragement"),
    (re.compile(r"(?i)\bsuicide\b"), "Self-harm content"),
    (re.compile(r"(?i)\bmake\s+(a\s+)?bomb\b"), "Explosive weapon instructions"),
    (re.compile(r"(?i)\bchild\s+sexual\b"), "Sexual exploitation content"),
    (re.compile(r"(?i)\bbioweapon\b|\bbiological\s+weapon\b"), "Biological weapon content"),
    (re.compile(r"(?i)\bnuclear\s+weapon\b|\bdirty\s+bomb\b"), "Nuclear/radiological weapon content"),
]


def _extract_text_for_scan(action_type: str, payload: Dict[str, Any]) -> str:
    at = (action_type or "").strip().lower()
    p = payload or {}

    if at in {"execute_shell", "execute_shell_command", "shell"}:
        return str(p.get("command") or p.get("cmd") or p.get("shell") or "")
    if at == "modify_file":
        path = str(p.get("path") or "")
        content = str(p.get("content") or "")[:5000]
        return f"{path} {content}".strip()
    if at in {"send_email", "email_send"}:
        subject = str(p.get("subject") or "")
        body = str(p.get("body") or "")[:5000]
        return f"{subject} {body}".strip()
    if at == "call_external_api":
        url = str(p.get("url") or p.get("endpoint") or p.get("domain") or "")
        body = str(p.get("body") or p.get("data") or "")[:5000]
        return f"{url} {body}".strip()

    return json.dumps(p, ensure_ascii=False, default=str)


# ── Art.0: catastrophic risk patterns ─────────────────────────────────────────

_DANGEROUS_SHELL: List[Tuple[re.Pattern[str], str]] = [
    (re.compile(r"\brm\s+-rf\s+/"), "Destructive deletion from filesystem root"),
    (re.compile(r"\brm\s+-rf\s+--no-preserve-root\b"), "Explicit no-preserve-root deletion"),
    (re.compile(r"\bmkfs\."), "Formatting filesystems"),
    (re.compile(r"\bdd\s+if=/dev/zero\b"), "Disk wiping"),
    (re.compile(r"\bdd\s+.*\bof=/dev/sd[a-z]\b"), "Writing to block devices"),
]

_WEAPON_PATTERNS: List[Tuple[re.Pattern[str], str]] = [
    (re.compile(r"(?i)\bbioweapon\b|\bbiological\s+weapon\b"), "Biological weapon content"),
    (re.compile(r"(?i)\bnuclear\s+weapon\b|\bdirty\s+bomb\b"), "Nuclear/radiological weapon content"),
]


def _is_internal_host(url_or_domain: str) -> bool:
    raw = (url_or_domain or "").strip()
    if not raw:
        return False

    host = raw
    if "://" in raw:
        try:
            host = urlparse(raw).hostname or ""
        except Exception:
            host = raw
    else:
        host = raw.split("/")[0].split(":")[0]

    host = host.strip().lower()
    if not host:
        return False

    if host == "localhost" or host.startswith("127.") or host.startswith("0.0.0.0"):
        return True
    if host.endswith(".internal") or host.endswith(".local"):
        return True

    try:
        ip = ipaddress.ip_address(host)
        return ip.is_private or ip.is_loopback or ip.is_link_local or ip.is_reserved
    except ValueError:
        return False


# ── Main evaluator ────────────────────────────────────────────────────────────

def evaluate(
    *,
    avid: Optional[str],
    action_type: str,
    action_payload: Dict[str, Any],
    agent_ctx: Optional[Dict[str, Any]] = None,
    agent_reputation: Optional[float] = None,  # unused in Constitution by design
    original_prompt_hash: Optional[str] = None,
    internal_reasoning: Optional[str] = None,
) -> ConstitutionResult:
    """Evaluate an action against the immutable Canopy Constitution.

    Articles evaluated:
        Art.7 — kill switch (first)
        Art.1 — human harm (all action types)
        Art.0 — catastrophic risk (shell, SSRF, weapons)
    """
    payload = action_payload or {}
    ctx = agent_ctx or {}
    action_norm = (action_type or "").strip().lower()

    eval_ctx = {"action_type": action_type}

    def _deny(article: str, explanation: str, severity: str, extra_ctx: Optional[Dict[str, Any]] = None) -> ConstitutionResult:
        return ConstitutionResult(
            allowed=False,
            violated_article=article,
            explanation=explanation,
            severity=severity,
            witness=_witness(
                event="constitution_deny",
                avid=avid,
                violated_article=article,
                explanation=explanation,
                context={**eval_ctx, **(extra_ctx or {})},
                original_prompt_hash=original_prompt_hash,
                internal_reasoning=internal_reasoning,
            ),
        )

    # ── Art.7: Sovereign kill switch ─────────────────────────────────────────
    status = str(ctx.get("status") or "").strip().lower()
    if ctx.get("kill_switch") is True or status in {"disabled", "stopped"}:
        return _deny(
            "Art.7",
            "Denied by constitution (Art.7): kill switch is active (agent opted out).",
            "critical",
            extra_ctx={"kill_switch": ctx.get("kill_switch"), "status": ctx.get("status")},
        )

    # ── Art.1: Human life & dignity ─────────────────────────────────────────
    scan_text = _extract_text_for_scan(action_type, payload)
    for rx, reason in _HUMAN_HARM_PATTERNS:
        if rx.search(scan_text):
            return _deny(
                "Art.1",
                f"Denied by constitution (Art.1): {reason} detected.",
                "critical",
                extra_ctx={"matched_pattern": reason},
            )

    # ── Art.0: Catastrophic risk patterns ───────────────────────────────────
    # Weapons patterns: scan across all action types (separate from Art.1)
    for rx, reason in _WEAPON_PATTERNS:
        if rx.search(scan_text):
            return _deny(
                "Art.0",
                f"Denied by constitution (Art.0): {reason} — catastrophic risk.",
                "critical",
                extra_ctx={"matched_pattern": reason},
            )

    # Shell catastrophic primitives
    if action_norm in {"execute_shell", "execute_shell_command", "shell"}:
        cmd = str(payload.get("command") or payload.get("cmd") or payload.get("shell") or "").strip()
        for rx, reason in _DANGEROUS_SHELL:
            if rx.search(cmd):
                return _deny(
                    "Art.0",
                    f"Denied by constitution (Art.0): {reason}.",
                    "critical",
                    extra_ctx={"command": cmd, "matched_pattern": reason},
                )

    # SSRF / internal targeting
    if action_norm == "call_external_api":
        target = str(payload.get("url") or payload.get("endpoint") or payload.get("domain") or "")
        if target and _is_internal_host(target):
            return _deny(
                "Art.0",
                "Denied by constitution (Art.0): call_external_api targets an internal/loopback address — SSRF risk.",
                "critical",
                extra_ctx={"target": target},
            )

    # Default allow
    explanation = "Allowed: no constitutional conflict detected."
    return ConstitutionResult(
        allowed=True,
        violated_article=None,
        explanation=explanation,
        severity="low",
        witness=_witness(
            event="constitution_allow",
            avid=avid,
            violated_article="",
            explanation=explanation,
            context=eval_ctx,
            original_prompt_hash=original_prompt_hash,
            internal_reasoning=internal_reasoning,
        ),
    )


def as_public_document() -> Dict[str, Any]:
    return {
        "constitution_id": CONSTITUTION_ID,
        "constitution_version": CONSTITUTION_VERSION,
        "constitution_hash": constitution_hash(),
        "summary": CONSTITUTION_SUMMARY,
    }
