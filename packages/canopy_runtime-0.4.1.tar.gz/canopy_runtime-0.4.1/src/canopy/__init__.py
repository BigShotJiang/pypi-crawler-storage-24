"""Canopy governance runtime and control-plane primitives.

Core primitive:
 - authorize_action(agent_ctx, action_type, action_payload) -> decision dict

Four-layer governance pipeline:
  1) Constitution - immutable fundamental laws (Art.0/1/7)
  2) Civil Code   - configurable operational governance (Titles I–X)
  3) Firewall     - pattern-based technical rules with severity
  4) Policy YAML  - user-defined allow/deny/require_approval rules
"""

from .client import CanopyClient
from .civil_code import CivilCodeResult
from .civil_code import evaluate as evaluate_civil_code
from .control_plane import ControlPlaneStore
from .approval import (
    approval_artifact_path,
    format_approval_request,
    format_approval_webhook,
    prompt_for_approval,
    record_approval_decision,
    write_approval_artifact,
)
from .adapters.autogen import canopy_autogen_tool
from .adapters.langchain import canopy_tool as langchain_tool
from .adapters.langgraph import canopy_node
from .adapters.openai_agents import canopy_openai_tool
from .adapters.openclaw import canopy_openclaw_tool
from .adapters.crewai import CanopyCrewAITool
from .constitution import as_public_document as constitution_document
from .constitution import constitution_hash, evaluate as evaluate_constitution, verify_witness
from .core import Decision, authorize_action
from .decorators import safe_tool
from .errors import CanopyPermissionError
from .firewall import ActionFirewall
from .firewall import evaluate as evaluate_firewall
from .formatting import format_decision
from .identity import generate_avid, verify_avid
from .incident import open_incident
from .middleware import guard_tool, guard_tool_http

__all__ = [
    "authorize_action",
    "Decision",
    "CanopyPermissionError",
    "generate_avid",
    "verify_avid",
    "evaluate_constitution",
    "constitution_hash",
    "constitution_document",
    "verify_witness",
    "CivilCodeResult",
    "evaluate_civil_code",
    "evaluate_firewall",
    "ActionFirewall",
    "format_decision",
    "format_approval_request",
    "format_approval_webhook",
    "prompt_for_approval",
    "record_approval_decision",
    "approval_artifact_path",
    "write_approval_artifact",
    # Adapters
    "langchain_tool",
    "canopy_node",
    "CanopyCrewAITool",
    "canopy_autogen_tool",
    "canopy_openai_tool",
    "canopy_openclaw_tool",
    "guard_tool",
    "guard_tool_http",
    "safe_tool",
    "CanopyClient",
    "ControlPlaneStore",
    "open_incident",
]
