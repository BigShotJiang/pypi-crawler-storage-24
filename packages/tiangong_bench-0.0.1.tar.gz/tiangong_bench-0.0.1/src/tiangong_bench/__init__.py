"""
TianGong Bench -- Benchmarking suite for AI Agent performance evaluation.
"""
__version__ = "0.0.1"
