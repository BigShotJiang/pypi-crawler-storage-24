# tiangong-bench

> TianGong Bench -- Benchmarking suite for AI Agent performance evaluation.

Part of the [TianGong](https://github.com/JinNing6/TianGong) ecosystem.

## Status

Planning -- This package is under active development. Stay tuned!

## License

MIT
