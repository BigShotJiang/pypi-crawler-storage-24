"""CLI entrypoint for the minimal HoneyHive Claude Code daemon."""

from __future__ import annotations

import json
import os
import sys
import time
import uuid
from datetime import datetime, timezone
from pathlib import Path
from typing import Optional

import click

from .claude_hooks import (
    get_hook_command,
    install_claude_hooks,
    normalize_claude_payload,
)
from .config import (
    DEFAULT_BASE_URL,
    DaemonConfig,
    get_claude_settings_path,
    get_daemon_home,
    load_config,
    save_config,
)
from .exporter import export_event, export_events
from .git_hooks import (
    find_git_root,
    get_commit_link_payload,
    install_post_commit_hook,
)
from .state import (
    append_spool_event,
    get_sessions_needing_artifact,
    log_message,
    mark_session_artifact_pushed,
    read_spool_events,
    record_session_activity,
    replace_spool_events,
)


SESSION_IDLE_THRESHOLD_MS = 24 * 60 * 60 * 1000


@click.group()
def cli() -> None:
    """HoneyHive daemon for Claude Code telemetry."""


@cli.command()
@click.option(
    "--key",
    "api_key",
    envvar="HH_API_KEY",
    required=True,
    help="HoneyHive API key.",
)
@click.option(
    "--url",
    "base_url",
    envvar="HH_API_URL",
    default=DEFAULT_BASE_URL,
    show_default=True,
    help="HoneyHive base URL or OTLP traces endpoint.",
)
@click.option(
    "--project",
    envvar="HH_PROJECT",
    help="Optional HoneyHive project override.",
)
@click.option(
    "--repo",
    type=click.Path(file_okay=False, path_type=Path),
    help="Repo to attach git commit events to.",
)
@click.option("--ci", is_flag=True, help="Enable CI mode.")
def run(
    api_key: str,
    base_url: str,
    project: Optional[str],
    repo: Optional[Path],
    ci: bool,
) -> None:
    """Install Claude hooks, persist config, and keep retrying queued events."""
    repo_root = _resolve_repo(repo)
    resolved_project = project or _derive_project_name(repo_root)
    config = DaemonConfig(
        api_key=api_key,
        base_url=base_url,
        project=resolved_project,
        repo_path=str(repo_root) if repo_root else None,
        ci=ci,
    )
    save_config(config)

    hook_command = get_hook_command()
    settings_path = get_claude_settings_path()
    hooks_changed = install_claude_hooks(settings_path, hook_command)
    git_changed = False
    if repo_root is not None:
        git_changed = install_post_commit_hook(
            repo_root, "honeyhive-daemon ingest git-post-commit"
        )

    log_message(
        "daemon started "
        f"project={resolved_project} "
        f"repo={repo_root or '-'} "
        f"ci={ci}"
    )
    _flush_spool(config)

    click.echo(f"Daemon home: {get_daemon_home()}")
    click.echo(f"Claude settings: {settings_path}")
    click.echo(f"Project: {resolved_project}")
    if repo_root is not None:
        click.echo(f"Repo: {repo_root}")
    click.echo(f"Claude hooks {'updated' if hooks_changed else 'already installed'}")
    if repo_root is not None:
        click.echo(
            f"Git post-commit hook {'updated' if git_changed else 'already installed'}"
        )
    click.echo("HoneyHive daemon is running. Press Ctrl-C to stop.")

    try:
        while True:
            time.sleep(5)
            _flush_spool(config)
            _push_pending_session_artifacts(config)
    except KeyboardInterrupt:
        click.echo("\nStopping HoneyHive daemon.")


@cli.command()
def status() -> None:
    """Show daemon status."""
    config = load_config()
    pending = len(read_spool_events())
    click.echo(f"Daemon home: {get_daemon_home()}")
    click.echo(f"Configured: {'yes' if config else 'no'}")
    click.echo(f"Pending spool events: {pending}")
    if config:
        click.echo(f"Project: {config.project}")
        click.echo(f"Base URL: {config.base_url}")
        click.echo(f"Repo: {config.repo_path or '-'}")


@cli.command()
def doctor() -> None:
    """Run a lightweight daemon self-check."""
    config = load_config()
    settings_path = get_claude_settings_path()
    click.echo(f"Config present: {'yes' if config else 'no'}")
    click.echo(f"Claude settings exists: {'yes' if settings_path.exists() else 'no'}")
    installed = "yes" if _settings_have_command(settings_path) else "no"
    click.echo(f"Claude hook command installed: {installed}")
    repo_root = _resolve_repo(None)
    click.echo(f"Git repo detected: {'yes' if repo_root else 'no'}")


@cli.group()
def ingest() -> None:
    """Internal commands used by Claude and git hooks."""


@ingest.command("claude-hook")
def ingest_claude_hook() -> None:
    """Receive one Claude hook event from stdin and export it."""
    config = load_config()
    if config is None:
        log_message("skipped claude hook because daemon config is missing")
        return

    raw_text = sys.stdin.read()
    if not raw_text.strip():
        log_message("skipped empty claude hook payload")
        return

    try:
        payload = json.loads(raw_text)
    except json.JSONDecodeError:
        log_message("skipped malformed claude hook payload")
        return

    hook_event_name = payload.get("hook_event_name", "unknown")
    tool_name = payload.get("tool_name", "-")
    session_id = payload.get("session_id", "-")
    log_message(
        "received claude hook "
        f"hook_event_name={hook_event_name} "
        f"tool_name={tool_name} "
        f"session_id={session_id}"
    )

    event = normalize_claude_payload(payload)
    if event is None:
        log_message(
            "ignored claude hook "
            f"hook_event_name={hook_event_name} "
            f"tool_name={tool_name}"
        )
        return

    transcript_path = event.get("metadata", {}).get("transcript.path")
    record_session_activity(
        str(event["session_id"]),
        transcript_path=str(transcript_path) if transcript_path else None,
        last_activity_ms=int(event["end_time"]),
        ended=event["event_name"] == "session.end",
        session_end_event_id=(
            str(event["event_id"]) if event["event_name"] == "session.end" else None
        ),
    )

    try:
        export_event(config, event)
        log_message(
            "exported claude event "
            f"event_name={event['event_name']} "
            f"session_id={event['session_id']}"
        )
        if event["event_name"] == "session.end":
            _push_pending_session_artifacts(config, session_ids=[str(event["session_id"])])
    except Exception as exc:  # pragma: no cover
        event["spool_reason"] = str(exc)
        append_spool_event(event)
        log_message(f"spooled claude event {event['event_name']}: {exc}")


@ingest.command("git-post-commit")
@click.option(
    "--repo",
    type=click.Path(file_okay=False, path_type=Path),
    help="Repo to inspect.",
)
def ingest_git_post_commit(repo: Optional[Path]) -> None:
    """Emit a lightweight git commit-link event."""
    config = load_config()
    if config is None:
        log_message("skipped git post-commit because daemon config is missing")
        return

    repo_root = _resolve_repo(repo)
    if repo_root is None:
        log_message("skipped git post-commit because no repo was found")
        return

    payload = get_commit_link_payload(repo_root)
    if payload is None:
        return

    event = {
        "event_id": str(uuid.uuid4()),
        "session_id": str(uuid.uuid4()),
        "event_type": "chain",
        "event_name": "chain.commit_link",
        "start_time": _now_ms(),
        "end_time": _now_ms(),
        "duration": 0,
        "metadata": {
            "capture.source": "git_hook",
            "raw.format": "git_post_commit",
            "repo.path": payload["repo_path"],
            "git.commit_sha": payload["git.commit_sha"],
            "git.parent_sha": payload["git.parent_sha"],
        },
        "raw": payload,
    }

    try:
        export_event(config, event)
        log_message(
            "exported git commit-link "
            f"commit_sha={payload['git.commit_sha']} "
            f"repo={payload['repo_path']}"
        )
    except Exception as exc:  # pragma: no cover
        event["spool_reason"] = str(exc)
        append_spool_event(event)
        log_message(f"spooled git commit-link event: {exc}")


def _flush_spool(config: DaemonConfig) -> None:
    pending = read_spool_events()
    if not pending:
        return
    log_message(f"flushing spool event_count={len(pending)}")
    try:
        export_events(config, pending)
    except Exception as exc:
        log_message(f"flush failed: {exc}")
        return
    replace_spool_events([])
    log_message("flush succeeded")


def _push_pending_session_artifacts(
    config: DaemonConfig, session_ids: Optional[list[str]] = None
) -> None:
    from .exporter import update_event_outputs

    pending = get_sessions_needing_artifact(
        now_ms=_now_ms(),
        idle_threshold_ms=SESSION_IDLE_THRESHOLD_MS,
    )
    if session_ids is not None:
        allowed = set(session_ids)
        pending = [session for session in pending if session["session_id"] in allowed]
    for session in pending:
        transcript_path = session.get("transcript_path")
        if not transcript_path:
            continue
        transcript_content = _read_transcript_jsonl(transcript_path)
        if transcript_content is None:
            log_message(
                "skipped session artifact update "
                f"session_id={session['session_id']} "
                f"because transcript could not be read"
            )
            continue
        reason = "session_end" if session.get("ended") else "idle_timeout"
        outputs = {
            "artifact": {
                "type": "transcript",
                "format": "jsonl",
                "path": transcript_path,
                "content": transcript_content,
                "reason": reason,
            }
        }
        target_event_ids = [str(session["event_id"])]
        session_end_event_id = session.get("session_end_event_id")
        if session_end_event_id and session_end_event_id not in target_event_ids:
            target_event_ids.append(str(session_end_event_id))
        try:
            for event_id in target_event_ids:
                update_event_outputs(
                    config,
                    event_id=event_id,
                    outputs=outputs,
                )
            mark_session_artifact_pushed(session["session_id"], _now_ms())
            log_message(
                "updated session artifact "
                f"session_id={session['session_id']} "
                f"reason={reason}"
            )
        except Exception as exc:  # pragma: no cover
            log_message(
                "failed session artifact update "
                f"session_id={session['session_id']}: {exc}"
            )


def _read_transcript_jsonl(transcript_path: str) -> Optional[str]:
    path = Path(transcript_path)
    if not path.exists() or not path.is_file():
        return None
    return path.read_text(encoding="utf-8")


def _settings_have_command(settings_path: Path) -> bool:
    if not settings_path.exists():
        return False
    try:
        settings = json.loads(settings_path.read_text(encoding="utf-8"))
    except json.JSONDecodeError:
        return False
    hooks = settings.get("hooks", {})
    target = get_hook_command()
    for entries in hooks.values():
        if not isinstance(entries, list):
            continue
        for entry in entries:
            if not isinstance(entry, dict):
                continue
            for hook in entry.get("hooks", []):
                if hook.get("type") == "command" and hook.get("command") == target:
                    return True
    return False


def _derive_project_name(repo_root: Optional[Path]) -> str:
    env_project = os.getenv("HH_PROJECT")
    if env_project:
        return env_project
    if repo_root is not None:
        return repo_root.name
    return Path.cwd().name


def _resolve_repo(repo: Optional[Path]) -> Optional[Path]:
    if repo is not None:
        return find_git_root(repo) or repo.resolve()
    return find_git_root(Path.cwd())


def _now_ms() -> int:
    return int(datetime.now(timezone.utc).timestamp() * 1000)
