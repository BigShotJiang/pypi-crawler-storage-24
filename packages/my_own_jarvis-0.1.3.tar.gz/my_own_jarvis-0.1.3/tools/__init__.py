"""Jarvis tool integrations."""
