"""TuringPulse SDK integration for LangChain."""

from ._wrapper import instrument_langchain

__version__ = "1.0.0"
__all__ = ["instrument_langchain"]
