# turingpulse-sdk-langchain

TuringPulse SDK integration for LangChain — auto-instrumentation for chains, agents, and tools.

## Installation

```bash
pip install turingpulse-sdk-langchain
```

## Quick Start

```python
from turingpulse_sdk import init, TuringPulseConfig
from turingpulse_sdk_langchain import instrument_langchain

init(TuringPulseConfig(api_key="sk_live_...", workflow_name="my-project"))

instrumented = instrument_langchain(chain, name="my-langchain-workflow")
result = instrumented.invoke({"input": "Hello!"})
```

## Documentation

Full documentation: [turingpulse.ai/docs/sdk/langchain](https://turingpulse.ai/docs/sdk/langchain)

## Requirements

- Python >= 3.11
- turingpulse-sdk >= 1.0.0
- langchain-core >= 0.3.0
