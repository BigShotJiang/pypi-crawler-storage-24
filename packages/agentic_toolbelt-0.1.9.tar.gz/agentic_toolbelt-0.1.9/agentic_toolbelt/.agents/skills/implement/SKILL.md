---
name: implement
description: Execute the planned code change with the smallest coherent diff and run the relevant validation. Use when source, tests, or behavior must change. Do not use for planning-only or docs-only tasks.
---
## Use when
- code, tests, or config must change
- a bug fix needs a repro and validation
- a planned change is ready to execute

## Do not use when
- the task is still exploratory and needs planning first
- the work is docs-only
- the task is purely release-note or final-gate work

## Inputs
- agreed goal or plan
- touched files and invariants
- canonical repo commands
- shared JSON memory layer for agent coordination

## Outputs
- files changed
- reason the change is correct
- tests or validation run
- skipped checks and residual risk
- merged memory trail for implementation and review stages

## Success criteria
- the diff is minimal and follows local patterns
- validation matches the blast radius
- the result is ready for docs and final review

## Routing
Calling this skill means execute this agent chain in order:
1. coordinator reads the existing memory manifest or creates one if missing
2. split the requested change into independent implementation scopes
3. record owned scope for every spawned agent in `manifest.json`
4. spawn one `implementer` per scope only when those scopes are disjoint and can be edited safely in parallel
5. require every implementer to read and write the shared JSON memory layer
6. merge the implementation outputs into one result
7. spawn `test-engineer`, `clean-code-reviewer`, and `reviewer` concurrently with the merged result
8. require each review agent to write a synthetic summary to the shared JSON memory layer
9. merge their findings into one review summary
10. resolve any blocking findings before the skill completes

Do not emulate this chain in one thread. If any required subagent cannot be spawned, stop and report the skill as blocked.
If docs changed, call `docs` after this skill completes.
If the task is still unplanned, call `plan` before this skill.

## Shared memory contract
All spawned agents must use a physical JSON memory layer as a coordination mechanism.

Use:
- `.agent-memory/manifest.json`
- `.agent-memory/events/<timestamp>-<agent>-<stage>.json`

Each agent writes one compact event record with:
- `agent`
- `stage`
- `owned_scope`
- `files`
- `status`
- `findings`
- `outputs`
- `blockers`
- `handoff`

Keep the entry synthetic. Use it to share progress and handoffs between parallel agents.
Do not have multiple agents rewrite the same JSON file.
Do not let a write-capable agent edit files outside the `owned_scope` recorded in the manifest.
