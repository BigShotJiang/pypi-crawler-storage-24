# Signalab

A short description of the project.

## 🚀 Prerequisites

Before working with this project, make sure you have the following installed:

### 1. [uv](https://docs.astral.sh/uv/)  
Python project and environment management.  
👉 Install guide: [uv docs](https://docs.astral.sh/uv/getting-started/installation/)

### 2. [make](https://www.gnu.org/software/make/)  
Run common project tasks via the `Makefile`.
👉 Install guide:

#### macOS  

```sh
xcode-select --install
```

#### Windows  

```powershell
choco install make
```

#### Linux
Usually pre-installed. If not:

```sh
sudo apt install build-essential   # Debian/Ubuntu
sudo dnf groupinstall "Development Tools"   # Fedora
```



## ⚡ Getting Started

Install dependencies into a local virtual environment:

```bash
uv sync --all-groups
```

This will create a `.venv` folder and install everything declared in `pyproject.toml`.

Then, you can activate the environment manually depending on your shell/OS:

* **Linux / macOS (bash/zsh):**

  ```bash
  source .venv/bin/activate
  ```

* **Windows (PowerShell):**

  ```powershell
  .venv\Scripts\Activate.ps1
  ```

* **Windows (cmd.exe):**

  ```cmd
  .venv\Scripts\activate.bat
  ```

## 🛠️ Usage

### Set up your environment variables  

Make a copy of the `.env.example` file and edit it with your settings:

```bash
cp .env.example .env
```

### Run the project

Start the main entry-point of your package with:

```bash
make run
```

That’s it! Your project should now be up and running with your configured environment.

## 📦 Tools for Developers

Common development tasks are wrapped in the `Makefile` for convenience.

### Linting, Formatting, and Type Checking

```bash
make qa
```

Runs **Ruff** for linting and formatting, and **Mypy** for type checking.

### Running Unit Tests

Before running tests, override any required environment variables in the `.env.test` file.

```bash
make test
```

Executes the test suite using **Pytest**.

### Building the Project

```bash
make build
```

Generates a distribution package inside the `dist/` directory.

### Cleaning Up

```bash
make clean
```

Removes build artifacts, caches, and temporary files to keep your project directory clean.

### Updating project version

```bash
make version
```

Interactively prompts you to select the type of version update to apply (major, minor, patch, tag) 
and automatically updates the project version accordingly.



### Building docs

```bash
make docs
```

Generates the project documentation inside the `dist/docs` folder.

When building the project (`make build`) the docs will also be generated automatically and
included in the distribution package.



## 🤝 Contributing

Contributions are welcome!
Please ensure all QA checks and tests pass before opening a pull request.

---

<sub>🚀 Project starter provided by [Cookie Pyrate](https://github.com/gvieralopez/cookie-pyrate)</sub>
