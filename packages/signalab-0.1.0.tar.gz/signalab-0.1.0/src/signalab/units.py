Point = float
Pip = float
Lot = float


class Units:
    LOT_SIZE = 100_000
    PIP_SIZE = 0.0001
    POINT_SIZE = PIP_SIZE / 10

    @staticmethod
    def pip_value(lots: Lot) -> float:
        """Account currency value of 1 pip move for `lots` position size."""
        return lots * Units.LOT_SIZE * Units.PIP_SIZE

    @staticmethod
    def point_value(lots: Lot) -> float:
        """Account currency value of 1 point move for `lots` position size."""
        return lots * Units.LOT_SIZE * Units.POINT_SIZE

    @staticmethod
    def pips_to_value(pips: Pip, lots: Lot) -> float:
        """Convert a pip distance to account currency."""
        return pips * Units.pip_value(lots)

    @staticmethod
    def points_to_value(points: Point, lots: Lot) -> float:
        """Convert a point distance to account currency."""
        return points * Units.point_value(lots)
