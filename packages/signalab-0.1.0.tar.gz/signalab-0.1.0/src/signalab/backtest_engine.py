import logging
from typing import cast

import pandas as pd
from numpy import inf

from signalab.account import Account, SimpleMarketData
from signalab.data.market_data import MarketData
from signalab.indicator.base import Indicator
from signalab.strategies.base import Strategy

logger = logging.getLogger(__name__)


class BacktestEngine:
    def _setup_accounts(
        self,
        individual_accounts: bool,
        accounts: Account | dict[str, Account] | list[Account] | None,
        strategies: list[Strategy],
    ) -> dict[str, Account]:
        if accounts is None:
            accounts = Account(inf, label="common_account")

        if isinstance(accounts, Account):
            if individual_accounts:
                return {
                    strategy.label: accounts.copy_empty() for strategy in strategies
                }
            return {strategy.label: accounts for strategy in strategies}
        if isinstance(accounts, dict):
            key_labels = {key.lower().replace(" ", "_") for key in accounts.keys()}
            strategy_labels = {strategy.label for strategy in strategies}
            if key_labels != strategy_labels:
                raise ValueError(
                    "Account keys do not match strategy labels. "
                    f"Expected: {strategy_labels}, got: {key_labels}"
                )
            return {
                key.lower().replace(" ", "_"): account
                for key, account in accounts.items()
            }
        if isinstance(accounts, list):
            if len(accounts) != len(strategies):
                raise ValueError(
                    "Number of accounts does not match number of strategies. "
                    f"Expected: {len(strategies)}, got: {len(accounts)}"
                )
            return {
                strategy.label: account
                for strategy, account in zip(strategies, accounts, strict=True)
            }

        raise ValueError(
            "Invalid accounts parameter. Must be an Account instance, a dict of accounts, or a list of accounts."
        )

    def run(
        self,
        data: MarketData,
        indicators: list[Indicator],
        strategies: list[Strategy],
        from_date: pd.Timestamp | None = None,
        to_date: pd.Timestamp | None = None,
        individual_accounts: bool = False,
        accounts: Account | dict[str, Account] | list[Account] | None = None,
    ) -> pd.DataFrame:
        logger.info(
            "Running simulation from %s to %s",
            str(from_date),
            str(to_date),
        )
        data = data.filter(from_date, to_date)

        logger.info("Number of ticks: %d", len(data.ticks))

        tick_index = pd.DatetimeIndex(data.ticks.index)

        record_df = pd.DataFrame(index=tick_index)
        record_df["ask"] = data.ticks["ask"]
        record_df["bid"] = data.ticks["bid"]
        record_df.index.name = "timestamp"

        logger.info(
            "Indicators: \n    %s", "\n    ".join(str(ind) for ind in indicators)
        )

        for indicator in indicators:
            logger.info("Computing indicator: %s", indicator.name)
            indicator_label = indicator.label or ""
            indicator_df = indicator.compute(data)
            indicator_df.index = pd.DatetimeIndex(indicator_df.index)
            indicator_df.index.name = "timestamp"

            if indicator_label:
                indicator_label = indicator_label.lower().replace(" ", "_")
                indicator_df = indicator_df.rename(
                    columns={
                        col: f"{indicator_label}_{col}" for col in indicator_df.columns
                    }
                )

            record_df = record_df.sort_index()
            indicator_df = indicator_df.sort_index()

            record_df = pd.merge_asof(
                record_df.reset_index(),
                indicator_df.reset_index(),
                on="timestamp",
                direction="backward",
            ).set_index("timestamp")

        logger.info("Setting up accounts")
        accounts = self._setup_accounts(individual_accounts, accounts, strategies)

        for strategy in strategies:
            account = accounts[strategy.label]
            if individual_accounts:
                account.label = strategy.label
            strategy.set_account(accounts[strategy.label])

        account_set = set(accounts.values())

        assert not individual_accounts or len(account_set) == len(strategies), (
            "Individual accounts flag is set but multiple accounts provided."
        )

        logger.info("Preparing market data")
        external_records: dict = {}
        last_ts = None
        records_iter = list(record_df.itertuples())

        logger.info("Starting backtest loop")
        for i, current_market in enumerate(records_iter):
            ts = current_market.Index
            prev_market = records_iter[i - 1] if i > 0 else None

            day_changed = (
                prev_market is not None
                and cast(pd.Timestamp, prev_market.Index).day
                != cast(pd.Timestamp, current_market.Index).day
            )
            days_delta = 0
            if day_changed:
                assert prev_market is not None
                timedelta = cast(pd.Timestamp, current_market.Index) - cast(
                    pd.Timestamp, prev_market.Index
                )
                # +1 to ensure we account for the day change even if the time
                # difference is less than 24 hours
                days_delta = timedelta.days + 1

            for account in account_set:
                account.check_liquidation(cast(SimpleMarketData, current_market))
                if day_changed:
                    account.day_change(delta=days_delta)

            for strategy in strategies:
                strategy.perform(
                    current_market,
                    external_records[last_ts] if last_ts is not None else {},
                )

            row = {}
            for account in account_set:
                label = account.label
                row.update(
                    {
                        f"{label}_{k}": v
                        for k, v in account.report(
                            cast(SimpleMarketData, current_market)
                        ).items()
                    }
                )

            external_records[ts] = row
            last_ts = ts

            if (
                prev_market is not None
                and cast(pd.Timestamp, current_market.Index).hour
                != cast(pd.Timestamp, prev_market.Index).hour
            ):
                logger.info(
                    "Processed %d records up to %s",
                    i + 1,
                    str(current_market.Index),
                )

        logger.info("Backtest completed. Compiling results.")
        report_df = pd.DataFrame.from_dict(external_records, orient="index")
        report_df.index.name = "timestamp"
        record_df = pd.concat([record_df, report_df], axis=1).sort_index()
        external_records = {}
        logger.info("Final record head:\n%s", record_df.head())
        return record_df
