import abc

import pandas as pd

from signalab.data.market_data import MarketData


class Indicator(abc.ABC):
    """
    Abstract base class for Indicators.
    """

    def __init__(self, name: str, label: str | None = None):
        self.name = name
        self.label = label

    @abc.abstractmethod
    def compute(self, data: MarketData) -> pd.DataFrame:
        """
        Computes the indicator values for the given date and market data.

        Parameters
        ----------
        data : MarketData
            The market data to use for computing the indicator values.

        Returns
        -------
        dict[str, np.ndarray]
            A dictionary containing the computed indicator values for each timestamp.
        """
        raise NotImplementedError
