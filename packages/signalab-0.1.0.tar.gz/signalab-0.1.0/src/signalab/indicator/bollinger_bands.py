import pandas as pd

from signalab.data.market_data import MarketData
from signalab.indicator.base import Indicator


class BollingerBands(Indicator):
    def __init__(
        self,
        window: int = 20,
        std_multiplier: float = 2.0,
        candles_type: str = "15m",
        label: str = "bb",
    ):
        super().__init__(name="Bollinger Bands", label=label)
        self.window = window
        self.std_multiplier = std_multiplier
        self.candles_type = candles_type

    def compute(self, data: MarketData) -> pd.DataFrame:
        candle_data = data.query(
            self.candles_type,
        )

        df = pd.DataFrame(index=candle_data.index)

        df["price"] = (candle_data["ask_close"] + candle_data["bid_close"]) / 2
        df["avg"] = df["price"].rolling(window=self.window).mean()
        df["std"] = df["price"].rolling(window=self.window).std() * self.std_multiplier
        df["upper"] = df["avg"] + df["std"]
        df["lower"] = df["avg"] - df["std"]
        df["signal"] = 0
        df.loc[df["price"] < df["lower"], "signal"] = 1
        df.loc[df["price"] > df["upper"], "signal"] = -1

        df.dropna(inplace=True)

        df.drop(columns=["price", "std"], inplace=True)
        return df

    def __str__(self) -> str:
        return f"BollingerBands(candles={self.candles_type}, window={self.window}, std_multiplier={self.std_multiplier})"
