"""使用示例"""

from sneakydog_object_storage_service import OSSClient, OSSConfig

# ========== 方式 1: 快速初始化 ==========
client = OSSClient(
    backend_type='local',
    backend_config={
        'root_path': './my_storage'
    }
)

# 上传
client.upload('test/hello.txt', b'Hello World!', content_type='text/plain')

# 下载
data = client.download('test/hello.txt')
print(f"Downloaded: {data.decode()}")

# 检查存在
print(f"Exists: {client.exists('test/hello.txt')}")

# 列出对象
objects = client.list_objects(prefix='test/')
for obj in objects:
    print(f"  {obj.key} ({obj.size} bytes)")

# 删除
client.delete('test/hello.txt')

# ========== 方式 2: 多后端配置 ==========
config = OSSConfig(
    default_backend='local',
    backends={
        'local': {
            'type': 'local',
            'root_path': './storage'
        },
        'minio': {
            'type': 'minio',
            'endpoint': 'play.min.io',
            'access_key': 'Q3AM3UQ867SPQQA43P2F',
            'secret_key': 'zuf+tfteSlswRu7BJ86wekitnifILbZam1KYY3TG',
            'bucket_name': 'my-bucket',
            'secure': True
        },
        'rustfs': {
            'type': 'rustfs',
            'base_url': 'http://localhost:8080',
            'api_key': 'your-api-key'
        }
    }
)

client = OSSClient(config=config)

# 使用默认后端 (local)
client.upload('file1.txt', b'Local storage')

# 指定后端 (minio)
client.upload('file2.txt', b'MinIO storage', backend='minio')

# 跨后端复制
client.copy_to_backend('file1.txt', 'local', 'minio')

# 同步所有数据
count = client.sync_backends('local', 'minio')
print(f"Synced {count} objects")

# ========== 方式 3: 从配置文件加载 ==========
# config = OSSConfig.from_file('oss_config.yaml')
# client = OSSClient(config=config)

# ========== 方式 4: 从环境变量加载 ==========
# config = OSSConfig.from_env()
# client = OSSClient(config=config)