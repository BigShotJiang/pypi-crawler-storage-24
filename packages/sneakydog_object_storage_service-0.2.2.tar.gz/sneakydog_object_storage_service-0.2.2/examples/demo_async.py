"""异步客户端示例"""

import asyncio

from sneakydog_object_storage_service import OSSClient, OSSConfig
from sneakydog_object_storage_service.async_client import AsyncOSSClient
from sneakydog_object_storage_service.utils.progress import format_size, format_time


async def main():
    # 初始化同步客户端
    config = OSSConfig(
        default_backend="local",
        backends={
            "local": {"type": "local", "root_path": "./storage"},
            "minio": {
                "type": "minio",
                "endpoint": "play.min.io",
                "access_key": "Q3AM3UQ867SPQQA43P2F",
                "secret_key": "zuf+tfteSlswRu7BJ86wekitnifILbZam1KYY3TG",
                "bucket_name": "my-bucket",
                "secure": True,
            },
        },
    )

    sync_client = OSSClient(config=config)
    client = AsyncOSSClient(sync_client)

    # 进度回调
    def on_progress(progress):
        print(
            f"\r[{progress.percent:.1f}%] "
            f"{format_size(progress.speed)}/s | "
            f"ETA: {format_time(progress.eta)}",
            end="",
            flush=True,
        )

    # 并发上传多个文件
    tasks = []
    for i in range(5):
        key = f"async/test_{i}.txt"
        data = f"Hello Async {i}".encode() * 1000
        task = client.upload(key, data, progress_callback=on_progress)
        tasks.append(task)

    print("Uploading 5 files concurrently...")
    results = await asyncio.gather(*tasks, return_exceptions=True)

    print(f"\n✅ Completed: {sum(1 for r in results if r is True)}/5")

    # 并发下载
    tasks = []
    for i in range(5):
        key = f"async/test_{i}.txt"
        task = client.download(key)
        tasks.append(task)

    print("Downloading 5 files concurrently...")
    results = await asyncio.gather(*tasks, return_exceptions=True)

    for i, result in enumerate(results):
        if isinstance(result, bytes):
            print(f"  File {i}: {len(result)} bytes")
        else:
            print(f"  File {i}: Error - {result}")


if __name__ == "__main__":
    asyncio.run(main())
