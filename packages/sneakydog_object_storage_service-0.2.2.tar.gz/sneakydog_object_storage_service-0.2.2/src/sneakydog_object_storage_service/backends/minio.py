"""MinIO/S3 兼容存储后端 (纯 boto3 实现)"""

from io import BytesIO
from typing import Optional

from botocore.config import Config
from botocore.exceptions import ClientError, NoCredentialsError
from mypy_boto3_s3 import S3Client

from sneakydog_object_storage_service.base import ObjectInfo, StorageBackend, StorageConfig
from sneakydog_object_storage_service.exceptions import (
    ConfigError,
    DownloadError,
    ObjectNotFoundError,
    UploadError,
)


class MinIOStorage(StorageBackend):
    """MinIO/S3 存储 (纯 boto3 实现)"""

    def __init__(self, config: StorageConfig):
        super().__init__(config)
        cfg = config.config

        # 验证必要配置
        if not cfg.get("access_key") or not cfg.get("secret_key"):
            raise ConfigError("MinIO/S3 requires access_key and secret_key")

        # 构建 endpoint_url
        endpoint = cfg.get("endpoint")
        secure = cfg.get("secure", True)
        endpoint_url = f"https://{endpoint}" if secure else f"http://{endpoint}"

        # 创建 boto3 S3 客户端
        self.client = S3Client(
            "s3",
            endpoint=endpoint_url,
            aws_access_key_id=cfg.get("access_key"),
            aws_secret_access_key=cfg.get("secret_key"),
            region_name=cfg.get("region", "us-east-1"),  # MinIO 通常用 us-east-1
            config=Config(
                s3={
                    "addressing_style": "path"  # ⚠️ 关键：MinIO 推荐使用 path 风格
                },
                connect_timeout=cfg.get("connect_timeout", 30),
                read_timeout=cfg.get("read_timeout", 30),
                retries={"max_attempts": cfg.get("max_retries", 3)},
            ),
        )

        self.bucket_name = cfg.get("bucket_name", "oss-client")

        # 确保 bucket 存在 (可选)
        if cfg.get("create_bucket_if_not_exists", False):
            self._ensure_bucket_exists()

    def _ensure_bucket_exists(self):
        """确保 bucket 存在"""
        try:
            self.client.head_bucket(Bucket=self.bucket_name)
        except ClientError as e:
            error_code = e.response["Error"]["Code"]
            if error_code == "404":
                # Bucket 不存在，创建
                region = self.client.meta.region_name
                if region == "us-east-1":
                    self.client.create_bucket(Bucket=self.bucket_name)
                else:
                    self.client.create_bucket(
                        Bucket=self.bucket_name,
                        CreateBucketConfiguration={"LocationConstraint": region},
                    )
            elif error_code == "403":
                # 无权限，但 bucket 存在
                pass
            else:
                raise

    def upload(
        self,
        key: str,
        bytes,
        content_type: Optional[str] = None,
        metadata: Optional[dict[str, str]] = None,
    ) -> bool:
        """上传文件"""
        try:
            extra_args = {}
            if content_type:
                extra_args["ContentType"] = content_type
            if metadata:
                extra_args["Metadata"] = metadata

            self.client.put_object(
                Bucket=self.bucket_name, Key=key, Body=BytesIO(bytes), **extra_args
            )
            return True
        except NoCredentialsError:
            raise ConfigError("AWS/MinIO credentials not found")
        except ClientError as e:
            raise UploadError(f"MinIO upload failed: {str(e)}")

    def download(self, key: str) -> bytes:
        """下载文件"""
        try:
            response = self.client.get_object(Bucket=self.bucket_name, Key=key)
            return response["Body"].read()
        except ClientError as e:
            if e.response["Error"]["Code"] == "NoSuchKey":
                raise ObjectNotFoundError(f"Object not found: {key}")
            raise DownloadError(f"MinIO download failed: {str(e)}")

    def download_to_file(self, key: str, local_path: str) -> bool:
        """下载文件到本地"""
        try:
            self.client.download_file(Bucket=self.bucket_name, Key=key, Filename=local_path)
            return True
        except ClientError as e:
            if e.response["Error"]["Code"] == "NoSuchKey":
                raise ObjectNotFoundError(f"Object not found: {key}")
            raise DownloadError(f"MinIO download failed: {str(e)}")

    def delete(self, key: str) -> bool:
        """删除文件"""
        try:
            self.client.delete_object(Bucket=self.bucket_name, Key=key)
            return True
        except ClientError as e:
            if e.response["Error"]["Code"] == "NoSuchKey":
                raise ObjectNotFoundError(f"Object not found: {key}")
            raise Exception(f"MinIO delete failed: {str(e)}")

    def exists(self, key: str) -> bool:
        """检查文件是否存在"""
        try:
            self.client.head_object(Bucket=self.bucket_name, Key=key)
            return True
        except ClientError:
            return False

    def list_objects(self, prefix: Optional[str] = None, max_keys: int = 1000) -> list[ObjectInfo]:
        """列出对象"""
        objects = []
        try:
            paginator = self.client.get_paginator("list_objects_v2")
            page_iterator = paginator.paginate(
                Bucket=self.bucket_name, Prefix=prefix or "", MaxKeys=max_keys
            )

            for page in page_iterator:
                for obj in page.get("Contents", []):
                    objects.append(
                        ObjectInfo(
                            key=obj["Key"],
                            size=obj["Size"],
                            last_modified=obj["LastModified"],
                            etag=obj.get("ETag", "").strip('"'),
                            content_type=None,
                        )
                    )
                    if len(objects) >= max_keys:
                        break
                if len(objects) >= max_keys:
                    break
        except ClientError as e:
            raise Exception(f"MinIO list failed: {str(e)}")

        return objects

    def get_object_info(self, key: str) -> ObjectInfo:
        """获取对象元信息"""
        try:
            response = self.client.head_object(Bucket=self.bucket_name, Key=key)

            return ObjectInfo(
                key=key,
                size=response["ContentLength"],
                last_modified=response["LastModified"],
                etag=response.get("ETag", "").strip('"'),
                content_type=response.get("ContentType"),
                metadata=response.get("Metadata", {}),
            )
        except ClientError as e:
            if e.response["Error"]["Code"] == "404":
                raise ObjectNotFoundError(f"Object not found: {key}")
            raise Exception(f"MinIO stat failed: {str(e)}")

    def presigned_url(self, key: str, expires_in: int = 3600) -> str:
        """生成预签名 URL"""
        try:
            url = self.client.generate_presigned_url(
                "get_object", Params={"Bucket": self.bucket_name, "Key": key}, ExpiresIn=expires_in
            )
            return url
        except ClientError as e:
            raise Exception(f"MinIO presigned URL failed: {str(e)}")

    # ========== 分片上传支持 (原生 boto3) ==========

    def initiate_multipart_upload(
        self,
        key: str,
        content_type: Optional[str] = None,
        metadata: Optional[dict[str, str]] = None,
    ) -> str:
        """初始化分片上传"""
        try:
            kwargs = {"Bucket": self.bucket_name, "Key": key}
            if content_type:
                kwargs["ContentType"] = content_type
            if metadata:
                kwargs["Metadata"] = metadata

            response = self.client.create_multipart_upload(**kwargs)
            return response["UploadId"]
        except ClientError as e:
            raise UploadError(f"MinIO initiate multipart failed: {str(e)}")

    def upload_part(self, key: str, upload_id: str, part_number: int, bytes) -> str:
        """上传分片"""
        try:
            response = self.client.upload_part(
                Bucket=self.bucket_name,
                Key=key,
                PartNumber=part_number,
                UploadId=upload_id,
                Body=BytesIO(bytes),
            )
            return response["ETag"].strip('"')
        except ClientError as e:
            raise UploadError(f"MinIO upload part failed: {str(e)}")

    def complete_multipart_upload(self, key: str, upload_id: str, parts: list) -> str:
        """完成分片上传"""
        try:
            parts_list = {
                "Parts": [{"PartNumber": p["part_number"], "ETag": p["etag"]} for p in parts]
            }

            response = self.client.complete_multipart_upload(
                Bucket=self.bucket_name, Key=key, UploadId=upload_id, MultipartUpload=parts_list
            )
            return response.get("ETag", "").strip('"')
        except ClientError as e:
            raise UploadError(f"MinIO complete multipart failed: {str(e)}")

    def abort_multipart_upload(self, key: str, upload_id: str) -> bool:
        """取消分片上传"""
        try:
            self.client.abort_multipart_upload(Bucket=self.bucket_name, Key=key, UploadId=upload_id)
            return True
        except ClientError as e:
            raise Exception(f"MinIO abort multipart failed: {str(e)}")
