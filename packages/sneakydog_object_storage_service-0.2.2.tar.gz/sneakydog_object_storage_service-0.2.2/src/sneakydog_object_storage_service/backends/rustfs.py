"""RustFS 存储后端 (示例实现)"""

from datetime import datetime
from typing import Optional

import requests

from sneakydog_object_storage_service.base import ObjectInfo, StorageBackend, StorageConfig
from sneakydog_object_storage_service.exceptions import ObjectNotFoundError


class RustFSStorage(StorageBackend):
    """
    RustFS 存储后端

    假设 RustFS 提供 HTTP API 接口：
    - GET    /api/object/{key}      - 下载
    - PUT    /api/object/{key}      - 上传
    - DELETE /api/object/{key}      - 删除
    - GET    /api/object/{key}/meta - 元信息
    - GET    /api/list?prefix=xxx   - 列表
    """

    def __init__(self, config: StorageConfig):
        super().__init__(config)
        cfg = config.config

        self.base_url = cfg.get("base_url", "http://localhost:8080")
        self.api_key = cfg.get("api_key", "")
        self.timeout = cfg.get("timeout", 30)

        self.session = requests.Session()
        if self.api_key:
            self.session.headers["Authorization"] = f"Bearer {self.api_key}"

    def _request(self, method: str, path: str, **kwargs) -> requests.Response:
        """封装 HTTP 请求"""
        url = f"{self.base_url}{path}"
        kwargs.setdefault("timeout", self.timeout)
        response = self.session.request(method, url, **kwargs)
        response.raise_for_status()
        return response

    def upload(
        self,
        key: str,
        data: bytes,
        content_type: Optional[str] = None,
        metadata: Optional[dict[str, str]] = None,
    ) -> bool:
        """上传文件"""
        try:
            headers = {}
            if content_type:
                headers["Content-Type"] = content_type
            if metadata:
                for k, v in metadata.items():
                    headers[f"X-Meta-{k}"] = v

            self._request("PUT", f"/api/object/{key}", data=data, headers=headers)
            return True
        except requests.HTTPError as e:
            raise Exception(f"RustFS upload failed: {str(e)}")

    def download(self, key: str) -> bytes:
        """下载文件"""
        try:
            response = self._request("GET", f"/api/object/{key}")
            return response.content
        except requests.HTTPError as e:
            if e.response.status_code == 404:
                raise ObjectNotFoundError(f"Object not found: {key}")
            raise Exception(f"RustFS download failed: {str(e)}")

    def download_to_file(self, key: str, local_path: str) -> bool:
        """下载文件到本地"""
        from pathlib import Path

        data = self.download(key)
        Path(local_path).parent.mkdir(parents=True, exist_ok=True)
        with open(local_path, "wb") as f:
            f.write(data)
        return True

    def delete(self, key: str) -> bool:
        """删除文件"""
        try:
            self._request("DELETE", f"/api/object/{key}")
            return True
        except requests.HTTPError as e:
            if e.response.status_code == 404:
                raise ObjectNotFoundError(f"Object not found: {key}")
            raise Exception(f"RustFS delete failed: {str(e)}")

    def exists(self, key: str) -> bool:
        """检查文件是否存在"""
        try:
            self._request("HEAD", f"/api/object/{key}")
            return True
        except requests.HTTPError:
            return False

    def list_objects(self, prefix: Optional[str] = None, max_keys: int = 1000) -> list[ObjectInfo]:
        """列出对象"""
        try:
            params = {"max_keys": max_keys}
            if prefix:
                params["prefix"] = prefix

            response = self._request("GET", "/api/list", params=params)
            data = response.json()

            objects = []
            for item in data.get("objects", []):
                objects.append(
                    ObjectInfo(
                        key=item["key"],
                        size=item["size"],
                        last_modified=datetime.fromisoformat(item["last_modified"]),
                        etag=item.get("etag"),
                        content_type=item.get("content_type"),
                    )
                )

            return objects
        except Exception as e:
            raise Exception(f"RustFS list failed: {str(e)}")

    def get_object_info(self, key: str) -> ObjectInfo:
        """获取对象元信息"""
        try:
            response = self._request("GET", f"/api/object/{key}/meta")
            data = response.json()

            return ObjectInfo(
                key=key,
                size=data["size"],
                last_modified=datetime.fromisoformat(data["last_modified"]),
                etag=data.get("etag"),
                content_type=data.get("content_type"),
                metadata=data.get("metadata"),
            )
        except requests.HTTPError as e:
            if e.response.status_code == 404:
                raise ObjectNotFoundError(f"Object not found: {key}")
            raise Exception(f"RustFS meta failed: {str(e)}")

    def presigned_url(self, key: str, expires_in: int = 3600) -> str:
        """生成预签名 URL"""
        try:
            response = self._request(
                "POST", f"/api/object/{key}/presigned", json={"expires_in": expires_in}
            )
            data = response.json()
            return data["url"]
        except Exception as e:
            raise Exception(f"RustFS presigned URL failed: {str(e)}")
