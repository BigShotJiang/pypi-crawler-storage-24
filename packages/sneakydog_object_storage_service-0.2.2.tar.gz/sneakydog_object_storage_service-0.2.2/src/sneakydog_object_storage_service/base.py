from abc import ABC, abstractmethod
from dataclasses import dataclass
from datetime import datetime
from typing import Any, BinaryIO, Optional


@dataclass
class ObjectInfo:
    """对象元信息"""

    key: str
    size: int
    last_modified: datetime
    etag: Optional[str] = None
    content_type: Optional[str] = None
    metadata: Optional[dict[str, str]] = None


@dataclass
class StorageConfig:
    """存储配置"""

    backend_type: str
    name: str
    config: dict[str, Any]


class StorageBackend(ABC):
    """存储后端抽象基类"""

    def __init__(self, config: StorageConfig):
        self.name = config.name
        self.backend_type = config.backend_type
        self.config = config.config

    @abstractmethod
    def upload(
        self,
        key: str,
        data: bytes,
        content_type: Optional[str] = None,
        metadata: Optional[dict[str, str]] = None,
    ) -> bool:
        """上传文件"""
        pass

    @abstractmethod
    def download(self, key: str) -> bytes:
        """下载文件"""
        pass

    @abstractmethod
    def download_to_file(self, key: str, local_path: str) -> bool:
        """下载文件到本地"""
        pass

    @abstractmethod
    def delete(self, key: str) -> bool:
        """删除文件"""
        pass

    @abstractmethod
    def exists(self, key: str) -> bool:
        """检查文件是否存在"""
        pass

    @abstractmethod
    def list_objects(self, prefix: Optional[str] = None, max_keys: int = 1000) -> list[ObjectInfo]:
        """列出对象"""
        pass

    @abstractmethod
    def get_object_info(self, key: str) -> ObjectInfo:
        """获取对象元信息"""
        pass

    @abstractmethod
    def presigned_url(self, key: str, expires_in: int = 3600) -> str:
        """生成预签名 URL"""
        pass

    def upload_file(
        self,
        key: str,
        file_path: str,
        content_type: Optional[str] = None,
        metadata: Optional[dict[str, str]] = None,
    ) -> bool:
        """上传本地文件"""
        with open(file_path, "rb") as f:
            data = f.read()
        return self.upload(key, data, content_type, metadata)

    def upload_stream(
        self,
        key: str,
        stream: BinaryIO,
        content_type: Optional[str] = None,
        metadata: Optional[dict[str, str]] = None,
    ) -> bool:
        """上传流"""
        data = stream.read()
        return self.upload(key, data, content_type, metadata)
