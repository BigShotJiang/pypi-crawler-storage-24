
{
    "version": "2026.3.18",
    "target": "default",
    "variant": "cpu"
}
