"""Setup configuration for excalidraw-cli."""

from setuptools import setup, find_namespace_packages

setup(
    name="excalidraw-cli",
    version="0.1.1",
    description="CLI-Anything harness for Excalidraw — create and manipulate Excalidraw diagrams from the command line",
    long_description=(open("../README.md").read() if __import__("pathlib").Path("../README.md").exists() else ""),
    long_description_content_type="text/markdown",
    author="excalidraw-cli contributors",
    license="MIT",
    packages=find_namespace_packages(include=["cli_anything.*"]),
    python_requires=">=3.10",
    install_requires=[
        "click>=8.0",
        "prompt_toolkit>=3.0",
    ],
    extras_require={
        "export": [
            "cairosvg>=2.5",
            "Pillow>=9.0",
        ],
    },
    entry_points={
        "console_scripts": [
            "excalidraw-cli=cli_anything.excalidraw.cli:main",
        ],
    },
    classifiers=[
        "Development Status :: 4 - Beta",
        "Environment :: Console",
        "Intended Audience :: Developers",
        "License :: OSI Approved :: MIT License",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Programming Language :: Python :: 3.12",
        "Topic :: Multimedia :: Graphics",
        "Topic :: Software Development :: Libraries :: Python Modules",
    ],
)
