"""Color presets for Excalidraw elements.

Provides 12 built-in style presets and support for user-defined presets
stored in ~/.config/excalidraw-cli/presets/.
"""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any

# ---------------------------------------------------------------------------
# User preset directory
# ---------------------------------------------------------------------------

_CONFIG_DIR = Path.home() / ".config" / "excalidraw-cli" / "presets"


def _ensure_config_dir() -> Path:
    _CONFIG_DIR.mkdir(parents=True, exist_ok=True)
    return _CONFIG_DIR


# ---------------------------------------------------------------------------
# Built-in presets
# ---------------------------------------------------------------------------

BUILTIN_PRESETS: dict[str, dict[str, Any]] = {
    "blueprint": {
        "strokeColor": "#1971c2",
        "backgroundColor": "#a5d8ff",
        "fillStyle": "solid",
        "strokeWidth": 2,
        "roughness": 0,
    },
    "pastel-pink": {
        "strokeColor": "#c2255c",
        "backgroundColor": "#fcc2d7",
        "fillStyle": "solid",
        "strokeWidth": 2,
        "roughness": 1,
    },
    "pastel-green": {
        "strokeColor": "#2f9e44",
        "backgroundColor": "#b2f2bb",
        "fillStyle": "solid",
        "strokeWidth": 2,
        "roughness": 1,
    },
    "pastel-blue": {
        "strokeColor": "#1971c2",
        "backgroundColor": "#d0ebff",
        "fillStyle": "solid",
        "strokeWidth": 2,
        "roughness": 1,
    },
    "pastel-yellow": {
        "strokeColor": "#e67700",
        "backgroundColor": "#ffec99",
        "fillStyle": "solid",
        "strokeWidth": 2,
        "roughness": 1,
    },
    "dark": {
        "strokeColor": "#e9ecef",
        "backgroundColor": "#343a40",
        "fillStyle": "solid",
        "strokeWidth": 2,
        "roughness": 0,
    },
    "neon": {
        "strokeColor": "#00ff88",
        "backgroundColor": "#1a1a2e",
        "fillStyle": "solid",
        "strokeWidth": 3,
        "roughness": 0,
    },
    "sketch": {
        "strokeColor": "#1e1e1e",
        "backgroundColor": "transparent",
        "fillStyle": "hachure",
        "strokeWidth": 2,
        "roughness": 2,
    },
    "bold": {
        "strokeColor": "#000000",
        "backgroundColor": "#ffc078",
        "fillStyle": "solid",
        "strokeWidth": 4,
        "roughness": 0,
    },
    "minimal": {
        "strokeColor": "#868e96",
        "backgroundColor": "transparent",
        "fillStyle": "solid",
        "strokeWidth": 1,
        "roughness": 0,
    },
    "pastel-purple": {
        "strokeColor": "#7048e8",
        "backgroundColor": "#d0bfff",
        "fillStyle": "solid",
        "strokeWidth": 2,
        "roughness": 1,
    },
    "pastel-orange": {
        "strokeColor": "#d9480f",
        "backgroundColor": "#ffd8a8",
        "fillStyle": "solid",
        "strokeWidth": 2,
        "roughness": 1,
    },
}


# ---------------------------------------------------------------------------
# User-defined presets (file-based)
# ---------------------------------------------------------------------------

def _user_preset_path(name: str) -> Path:
    return _ensure_config_dir() / f"{name}.json"


def list_presets() -> dict[str, dict[str, Any]]:
    """Return all available presets (built-in + user-defined)."""
    all_presets: dict[str, dict[str, Any]] = dict(BUILTIN_PRESETS)
    config = _ensure_config_dir()
    for f in sorted(config.glob("*.json")):
        try:
            data = json.loads(f.read_text(encoding="utf-8"))
            all_presets[f.stem] = data
        except (json.JSONDecodeError, OSError):
            continue
    return all_presets


def get_preset(name: str) -> dict[str, Any] | None:
    """Get a preset by name (checks built-in first, then user-defined)."""
    if name in BUILTIN_PRESETS:
        return dict(BUILTIN_PRESETS[name])
    path = _user_preset_path(name)
    if path.exists():
        try:
            return json.loads(path.read_text(encoding="utf-8"))
        except (json.JSONDecodeError, OSError):
            return None
    return None


def create_preset(name: str, properties: dict[str, Any]) -> Path:
    """Save a user-defined preset. Raises ValueError if name is a built-in."""
    if name in BUILTIN_PRESETS:
        raise ValueError(f"Cannot overwrite built-in preset: {name!r}")
    path = _user_preset_path(name)
    path.write_text(json.dumps(properties, indent=2), encoding="utf-8")
    return path


def delete_preset(name: str) -> bool:
    """Delete a user-defined preset. Returns True if deleted."""
    if name in BUILTIN_PRESETS:
        raise ValueError(f"Cannot delete built-in preset: {name!r}")
    path = _user_preset_path(name)
    if path.exists():
        path.unlink()
        return True
    return False


def apply_preset(name: str, overrides: dict[str, Any]) -> dict[str, Any]:
    """Merge a preset's properties into overrides (preset values as defaults)."""
    preset = get_preset(name)
    if preset is None:
        raise ValueError(f"Unknown preset: {name!r}")
    merged = dict(preset)
    merged.update(overrides)
    return merged
