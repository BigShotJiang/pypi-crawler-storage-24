"""Custom template management for Excalidraw CLI.

Allows users to save, load, list, delete, and import custom diagram
templates stored in ~/.config/excalidraw-cli/templates/.
"""

from __future__ import annotations

import json
import shutil
from pathlib import Path
from typing import Any

# ---------------------------------------------------------------------------
# Template directory
# ---------------------------------------------------------------------------

_TEMPLATE_DIR = Path.home() / ".config" / "excalidraw-cli" / "templates"


def _ensure_template_dir() -> Path:
    _TEMPLATE_DIR.mkdir(parents=True, exist_ok=True)
    return _TEMPLATE_DIR


def _template_path(name: str) -> Path:
    return _ensure_template_dir() / f"{name}.excalidraw"


# ---------------------------------------------------------------------------
# CRUD operations
# ---------------------------------------------------------------------------

def save_template(name: str, scene_data: dict[str, Any]) -> Path:
    """Save a scene as a named template."""
    path = _template_path(name)
    path.write_text(json.dumps(scene_data, indent=2), encoding="utf-8")
    return path


def load_template(name: str) -> dict[str, Any]:
    """Load a named template. Raises FileNotFoundError if not found."""
    path = _template_path(name)
    if not path.exists():
        raise FileNotFoundError(f"Template not found: {name!r}")
    return json.loads(path.read_text(encoding="utf-8"))


def list_templates() -> list[dict[str, Any]]:
    """List all saved custom templates with metadata."""
    tdir = _ensure_template_dir()
    templates = []
    for f in sorted(tdir.glob("*.excalidraw")):
        try:
            data = json.loads(f.read_text(encoding="utf-8"))
            elem_count = len(data.get("elements", []))
            templates.append({
                "name": f.stem,
                "elements": elem_count,
                "file": str(f),
            })
        except (json.JSONDecodeError, OSError):
            templates.append({
                "name": f.stem,
                "elements": 0,
                "file": str(f),
                "error": "invalid file",
            })
    return templates


def delete_template(name: str) -> bool:
    """Delete a named template. Returns True if deleted."""
    path = _template_path(name)
    if path.exists():
        path.unlink()
        return True
    return False


def import_template(name: str, source_path: str | Path) -> Path:
    """Import an .excalidraw file as a named template."""
    source = Path(source_path)
    if not source.exists():
        raise FileNotFoundError(f"Source file not found: {source}")
    # Validate it's valid excalidraw JSON
    data = json.loads(source.read_text(encoding="utf-8"))
    if data.get("type") != "excalidraw":
        raise ValueError(f"Not a valid Excalidraw file: {source}")
    dest = _template_path(name)
    shutil.copy2(source, dest)
    return dest
