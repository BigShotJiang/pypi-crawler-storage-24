"""Pre-built diagram templates for common use cases.

Each template function returns a Scene with elements already placed.
"""

from __future__ import annotations

from .core import Scene


def flowchart(
    steps: list[str],
    *,
    direction: str = "vertical",
    node_width: float = 220,
    node_height: float = 80,
    gap: float = 60,
    decision_shape: str = "diamond",
) -> Scene:
    """Generate a simple linear flowchart.

    Parameters
    ----------
    steps : list[str]
        List of step labels.  Prefix with ``?`` to make a diamond (decision).
        Arrows leaving a decision node are automatically labelled "Yes".
    direction : "vertical" | "horizontal"
        Layout direction.
    """
    scene = Scene()
    prev_id: str | None = None
    prev_is_decision = False

    for i, step_text in enumerate(steps):
        is_decision = step_text.startswith("?")
        text = step_text.lstrip("? ")
        shape = decision_shape if is_decision else "rectangle"

        if direction == "vertical":
            x = 100
            y = 100 + i * (node_height + gap)
        else:
            x = 100 + i * (node_width + gap)
            y = 100

        nid = scene.add_flowchart_node(
            text, x=x, y=y, width=node_width, height=node_height, shape=shape
        )
        if prev_id:
            arrow_label = "Yes" if prev_is_decision else None
            scene.connect(prev_id, nid, label=arrow_label)
        prev_id = nid
        prev_is_decision = is_decision

    return scene


def sequence_diagram(
    actors: list[str],
    messages: list[tuple[int, int, str]],
    *,
    actor_width: float = 140,
    actor_gap: float = 100,
    message_gap: float = 60,
) -> Scene:
    """Generate a sequence diagram.

    Parameters
    ----------
    actors : list[str]
        Participant names.
    messages : list[tuple[int, int, str]]
        Each tuple is (from_actor_index, to_actor_index, label).
    """
    scene = Scene()
    actor_ids: list[str] = []
    x_positions: list[float] = []

    for i, name in enumerate(actors):
        x = 100 + i * (actor_width + actor_gap)
        x_positions.append(x)
        aid = scene.add_shape(
            "rectangle", x=x, y=60, width=actor_width, height=50, label=name
        )
        actor_ids.append(aid)
        # Lifeline
        cx = x + actor_width / 2
        scene.add_line(
            x=cx,
            y=110,
            points=[[0, 0], [0, 40 + len(messages) * message_gap]],
            strokeStyle="dashed",
            strokeWidth=1,
        )

    for idx, (fr, to, msg) in enumerate(messages):
        y = 150 + idx * message_gap
        sx = x_positions[fr] + actor_width / 2
        ex = x_positions[to] + actor_width / 2
        scene.add_arrow(x=sx, y=y, width=ex - sx, height=0)
        scene.add_text(msg, x=min(sx, ex) + 10, y=y - 22, font_size=16)

    return scene


def er_diagram(
    entities: list[dict],
    relations: list[tuple[str, str, str]],
) -> Scene:
    """Generate an entity-relationship diagram.

    Parameters
    ----------
    entities : list[dict]
        Each dict has ``name`` (str) and ``fields`` (list[str]).
    relations : list[tuple[str, str, str]]
        (entity_a_name, entity_b_name, label).
    """
    scene = Scene()
    entity_ids: dict[str, str] = {}
    box_w, box_h = 220, 120

    for i, ent in enumerate(entities):
        col = i % 3
        row = i // 3
        x = 80 + col * (box_w + 80)
        y = 80 + row * (box_h + 100)
        label_text = ent["name"] + "\n" + "\n".join(f"- {f}" for f in ent.get("fields", []))
        eid = scene.add_shape(
            "rectangle", x=x, y=y, width=box_w, height=box_h, label=label_text
        )
        entity_ids[ent["name"]] = eid

    for a_name, b_name, label in relations:
        aid = entity_ids.get(a_name)
        bid = entity_ids.get(b_name)
        if aid and bid:
            scene.connect(aid, bid, label=label)

    return scene


def mindmap(
    root: str,
    branches: dict[str, list[str]],
    *,
    center_x: float = 400,
    center_y: float = 300,
) -> Scene:
    """Generate a simple mind map.

    Parameters
    ----------
    root : str
        Central topic.
    branches : dict[str, list[str]]
        Mapping of branch label -> list of leaf labels.
    """
    import math

    scene = Scene()
    root_id = scene.add_shape(
        "ellipse",
        x=center_x - 80,
        y=center_y - 40,
        width=160,
        height=80,
        label=root,
        backgroundColor="#a5d8ff",
        fillStyle="solid",
    )

    branch_names = list(branches.keys())
    n = len(branch_names)
    # Scale radius with number of branches to avoid overlap
    max_leaves = max((len(v) for v in branches.values()), default=1)
    radius = max(260, 80 * n, 60 * max_leaves)

    branch_w, branch_h = 140, 60
    leaf_w, leaf_h = 120, 40
    leaf_gap = 54  # vertical gap between leaf centers

    for i, branch_label in enumerate(branch_names):
        angle = (2 * math.pi * i) / n - math.pi / 2
        bx = center_x + radius * math.cos(angle) - branch_w / 2
        by = center_y + radius * math.sin(angle) - branch_h / 2

        bid = scene.add_shape(
            "rectangle",
            x=bx,
            y=by,
            width=branch_w,
            height=branch_h,
            label=branch_label,
            backgroundColor="#d0bfff",
            fillStyle="solid",
        )
        scene.connect(root_id, bid)

        leaves = branches[branch_label]
        n_leaves = len(leaves)

        # Place leaves outward from the branch, away from center
        cos_a = math.cos(angle)
        sin_a = math.sin(angle)

        # Determine leaf direction: extend further outward from center
        if abs(cos_a) >= abs(sin_a):
            # Branch is predominantly left or right of center
            leaf_dx = 200 if cos_a >= 0 else -(leaf_w + 60)
            leaf_base_y = by + branch_h / 2 - (n_leaves - 1) * leaf_gap / 2
            for j, leaf in enumerate(leaves):
                lx = bx + leaf_dx
                ly = leaf_base_y + j * leaf_gap - leaf_h / 2
                lid = scene.add_shape(
                    "rectangle", x=lx, y=ly, width=leaf_w, height=leaf_h,
                    label=leaf, backgroundColor="#b2f2bb", fillStyle="solid",
                )
                scene.connect(bid, lid)
        else:
            # Branch is predominantly above or below center
            leaf_dy = 80 if sin_a >= 0 else -(leaf_h + 40)
            leaf_base_x = bx + branch_w / 2 - (n_leaves - 1) * 150 / 2
            for j, leaf in enumerate(leaves):
                lx = leaf_base_x + j * 150 - leaf_w / 2
                ly = by + leaf_dy
                lid = scene.add_shape(
                    "rectangle", x=lx, y=ly, width=leaf_w, height=leaf_h,
                    label=leaf, backgroundColor="#b2f2bb", fillStyle="solid",
                )
                scene.connect(bid, lid)

    return scene


def kanban_board(
    columns: dict[str, list[str]],
    *,
    col_width: float = 220,
    card_height: float = 50,
    gap: float = 20,
) -> Scene:
    """Generate a Kanban board layout.

    Parameters
    ----------
    columns : dict[str, list[str]]
        Column name -> list of card labels.
    """
    scene = Scene()
    for ci, (col_name, cards) in enumerate(columns.items()):
        cx = 60 + ci * (col_width + gap)
        col_h = 60 + len(cards) * (card_height + gap) + gap
        scene.add_shape(
            "rectangle",
            x=cx,
            y=40,
            width=col_width,
            height=col_h,
            strokeColor="#868e96",
            backgroundColor="#f8f9fa",
            fillStyle="solid",
        )
        scene.add_text(
            col_name,
            x=cx + 10,
            y=50,
            font_size=18,
        )
        for ri, card in enumerate(cards):
            scene.add_shape(
                "rectangle",
                x=cx + 10,
                y=90 + ri * (card_height + gap),
                width=col_width - 20,
                height=card_height,
                label=card,
                backgroundColor="#ffffff",
                fillStyle="solid",
            )
    return scene
