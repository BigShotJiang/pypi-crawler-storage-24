"""CLI-Anything harness for Excalidraw."""

__version__ = "0.1.0"
