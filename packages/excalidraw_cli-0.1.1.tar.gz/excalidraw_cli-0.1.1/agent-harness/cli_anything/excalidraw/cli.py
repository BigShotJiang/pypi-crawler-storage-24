"""Click-based CLI for Excalidraw.

Follows the CLI-Anything conventions:
  - ``--json`` flag on every command for machine-readable output
  - Hierarchical command groups: scene, element, template, export
  - REPL mode via bare invocation
"""

from __future__ import annotations

import json
import sys
from pathlib import Path
from typing import Any

import click

from . import __version__
from .core import Scene, create_element, ALL_TYPES, SHAPE_TYPES, LINEAR_TYPES
from .templates import (
    flowchart,
    sequence_diagram,
    er_diagram,
    mindmap,
    kanban_board,
)
from .presets import (
    list_presets,
    get_preset,
    create_preset,
    delete_preset,
    apply_preset,
)
from .custom_templates import (
    save_template,
    load_template,
    list_templates,
    delete_template,
    import_template,
)

# ---------------------------------------------------------------------------
# Session state – keeps the active scene between commands in REPL mode
# ---------------------------------------------------------------------------

_session: dict[str, Any] = {
    "scene": None,
    "path": None,
}


def _get_scene(create: bool = False) -> Scene:
    if _session["scene"] is None:
        if create:
            _session["scene"] = Scene()
        else:
            raise _JsonClickException(
                "No scene loaded. Use `scene new` or `scene load <file>` first.",
                "NO_SCENE",
            )
    return _session["scene"]


def _output(data: Any, ctx: click.Context) -> None:
    """Unified output: JSON when --json is set, otherwise human-readable."""
    use_json = ctx.find_root().params.get("json_output", False)
    if use_json:
        click.echo(json.dumps(data, indent=2))
    elif isinstance(data, dict):
        for k, v in data.items():
            click.echo(f"  {k}: {v}")
    elif isinstance(data, list):
        for item in data:
            if isinstance(item, dict):
                click.echo(f"  - {item.get('id', '?')}  type={item.get('type', '?')}  "
                           f"({item.get('x', 0):.0f},{item.get('y', 0):.0f})  "
                           f"{item.get('width', 0):.0f}x{item.get('height', 0):.0f}")
            else:
                click.echo(f"  - {item}")
    else:
        click.echo(str(data))


def _is_json_mode(ctx: click.Context | None = None) -> bool:
    """Check if --json flag is active, handling cases where ctx may be None."""
    if ctx is None:
        return False
    try:
        return ctx.find_root().params.get("json_output", False)
    except Exception:
        return False


class _JsonClickException(click.ClickException):
    """ClickException that outputs structured JSON when --json flag is set."""

    def __init__(self, message: str, code: str = "ERROR") -> None:
        super().__init__(message)
        self.error_code = code

    def format_message(self) -> str:
        return self.message

    def show(self, file: Any = None) -> None:
        # Check if we're in JSON mode by looking at the click context
        ctx = click.get_current_context(silent=True)
        if _is_json_mode(ctx):
            error_data = {
                "status": "error",
                "code": self.error_code,
                "message": self.format_message(),
            }
            click.echo(json.dumps(error_data, indent=2), file=file)
        else:
            click.echo(f"Error: {self.format_message()}", err=True)


# ═══════════════════════════════════════════════════════════════════════════
# Root group
# ═══════════════════════════════════════════════════════════════════════════

@click.group(invoke_without_command=True)
@click.option("--json", "json_output", is_flag=True, help="Output in JSON format.")
@click.version_option(__version__, prog_name="excalidraw-cli")
@click.pass_context
def cli(ctx: click.Context, json_output: bool) -> None:
    """Excalidraw CLI — create and manipulate Excalidraw diagrams from the terminal.

    Run without a subcommand to enter interactive REPL mode.
    """
    ctx.ensure_object(dict)
    ctx.obj["json"] = json_output
    if ctx.invoked_subcommand is None:
        _repl(ctx)


# ═══════════════════════════════════════════════════════════════════════════
# scene commands
# ═══════════════════════════════════════════════════════════════════════════

@cli.group()
def scene() -> None:
    """Manage Excalidraw scenes (new, load, save, info)."""


@scene.command("new")
@click.option("--background", "-bg", default="#ffffff", help="Background color.")
@click.option("--grid", type=int, default=None, help="Grid size (null = no grid).")
@click.pass_context
def scene_new(ctx: click.Context, background: str, grid: int | None) -> None:
    """Create a new empty scene."""
    s = Scene()
    s.set_background(background)
    if grid is not None:
        s.set_grid(grid)
    _session["scene"] = s
    _session["path"] = None
    _output({"status": "created", "background": background, "grid": grid}, ctx)


@scene.command("load")
@click.argument("file", type=click.Path(exists=True))
@click.pass_context
def scene_load(ctx: click.Context, file: str) -> None:
    """Load a scene from a .excalidraw file."""
    s = Scene.load(file)
    _session["scene"] = s
    _session["path"] = file
    info = s.summary()
    info["file"] = file
    info["status"] = "loaded"
    _output(info, ctx)


@scene.command("save")
@click.argument("file", type=click.Path(), required=False)
@click.pass_context
def scene_save(ctx: click.Context, file: str | None) -> None:
    """Save the current scene to a file."""
    s = _get_scene()
    path = file or _session.get("path")
    if not path:
        raise _JsonClickException("No file path specified and no previous save path.", "NO_PATH")
    saved = s.save(path)
    _session["path"] = str(saved)
    _output({"status": "saved", "file": str(saved)}, ctx)


@scene.command("info")
@click.pass_context
def scene_info(ctx: click.Context) -> None:
    """Show summary information about the current scene."""
    s = _get_scene()
    info = s.summary()
    info["file"] = _session.get("path")
    _output(info, ctx)


@scene.command("clear")
@click.pass_context
def scene_clear(ctx: click.Context) -> None:
    """Remove all elements from the current scene."""
    s = _get_scene()
    s.clear()
    _output({"status": "cleared"}, ctx)


@scene.command("background")
@click.argument("color")
@click.pass_context
def scene_background(ctx: click.Context, color: str) -> None:
    """Set the scene background color."""
    s = _get_scene()
    s.set_background(color)
    _output({"status": "updated", "background": color}, ctx)


@scene.command("undo")
@click.pass_context
def scene_undo(ctx: click.Context) -> None:
    """Undo the last scene modification."""
    s = _get_scene()
    ok = s.undo()
    _output({"status": "undo", "success": ok}, ctx)


@scene.command("redo")
@click.pass_context
def scene_redo(ctx: click.Context) -> None:
    """Redo the last undone modification."""
    s = _get_scene()
    ok = s.redo()
    _output({"status": "redo", "success": ok}, ctx)


# ═══════════════════════════════════════════════════════════════════════════
# element commands
# ═══════════════════════════════════════════════════════════════════════════

@cli.group()
def element() -> None:
    """Add, remove, list, and update diagram elements."""


@element.command("add")
@click.argument("element_type", type=click.Choice(list(ALL_TYPES), case_sensitive=False))
@click.option("--x", type=float, default=0, help="X position.")
@click.option("--y", type=float, default=0, help="Y position.")
@click.option("--width", "-w", type=float, default=200, help="Width.")
@click.option("--height", "-h", type=float, default=100, help="Height.")
@click.option("--label", "-l", type=str, default=None, help="Text label.")
@click.option("--stroke-color", type=str, default=None, help="Stroke color (hex).")
@click.option("--bg-color", type=str, default=None, help="Background color (hex).")
@click.option("--fill", type=click.Choice(["hachure", "cross-hatch", "solid"]),
              default=None, help="Fill style.")
@click.option("--stroke-width", type=float, default=None, help="Stroke width.")
@click.option("--roughness", type=int, default=None, help="Roughness (0=sharp, 1=normal, 2=rough).")
@click.option("--opacity", type=int, default=None, help="Opacity (0-100).")
@click.option("--preset", "-p", type=str, default=None,
              help="Apply a named color preset (e.g. blueprint, neon, dark).")
@click.pass_context
def element_add(
    ctx: click.Context,
    element_type: str,
    x: float,
    y: float,
    width: float,
    height: float,
    label: str | None,
    stroke_color: str | None,
    bg_color: str | None,
    fill: str | None,
    stroke_width: float | None,
    roughness: int | None,
    opacity: int | None,
    preset: str | None,
) -> None:
    """Add an element to the current scene."""
    s = _get_scene(create=True)
    overrides: dict[str, Any] = {}
    if stroke_color:
        overrides["strokeColor"] = stroke_color
    if bg_color:
        overrides["backgroundColor"] = bg_color
    if fill:
        overrides["fillStyle"] = fill
    if stroke_width is not None:
        overrides["strokeWidth"] = stroke_width
    if roughness is not None:
        overrides["roughness"] = roughness
    if opacity is not None:
        overrides["opacity"] = opacity

    if preset:
        try:
            overrides = apply_preset(preset, overrides)
        except ValueError as e:
            raise _JsonClickException(str(e), "INVALID_PRESET")

    result = create_element(
        element_type, x=x, y=y, width=width, height=height, label=label, **overrides
    )

    if isinstance(result, tuple):
        shape, text_elem = result
        s.add_elements([shape, text_elem])
        eid = shape["id"]
    else:
        s.add_element(result)
        eid = result["id"]

    _output({"status": "added", "id": eid, "type": element_type}, ctx)


@element.command("list")
@click.option("--type", "etype", type=str, default=None, help="Filter by element type.")
@click.pass_context
def element_list(ctx: click.Context, etype: str | None) -> None:
    """List elements in the current scene."""
    s = _get_scene()
    elems = s.list_elements(etype)
    _output(elems, ctx)


@element.command("remove")
@click.argument("element_id")
@click.pass_context
def element_remove(ctx: click.Context, element_id: str) -> None:
    """Remove an element by its ID."""
    s = _get_scene()
    removed = s.remove_element(element_id)
    if removed:
        _output({"status": "removed", "id": element_id}, ctx)
    else:
        raise _JsonClickException(f"Element not found: {element_id}", "ELEMENT_NOT_FOUND")


@element.command("update")
@click.argument("element_id")
@click.option("--x", type=float, default=None)
@click.option("--y", type=float, default=None)
@click.option("--width", type=float, default=None)
@click.option("--height", type=float, default=None)
@click.option("--stroke-color", type=str, default=None)
@click.option("--bg-color", type=str, default=None)
@click.option("--opacity", type=int, default=None)
@click.pass_context
def element_update(ctx: click.Context, element_id: str, **kwargs: Any) -> None:
    """Update properties of an existing element."""
    s = _get_scene()
    props: dict[str, Any] = {}
    mapping = {
        "stroke_color": "strokeColor",
        "bg_color": "backgroundColor",
    }
    for k, v in kwargs.items():
        if v is not None:
            key = mapping.get(k, k)
            props[key] = v
    if not props:
        raise _JsonClickException("No properties to update. Provide at least one option.", "NO_PROPERTIES")
    updated = s.update_element(element_id, **props)
    if updated:
        _output({"status": "updated", "id": element_id}, ctx)
    else:
        raise _JsonClickException(f"Element not found: {element_id}", "ELEMENT_NOT_FOUND")


@element.command("connect")
@click.argument("from_id")
@click.argument("to_id")
@click.option("--label", "-l", type=str, default=None, help="Arrow label.")
@click.pass_context
def element_connect(ctx: click.Context, from_id: str, to_id: str, label: str | None) -> None:
    """Draw an arrow connecting two elements."""
    s = _get_scene()
    aid = s.connect(from_id, to_id, label=label)
    if aid:
        _output({"status": "connected", "arrow_id": aid, "from": from_id, "to": to_id}, ctx)
    else:
        raise _JsonClickException("One or both elements not found.", "ELEMENT_NOT_FOUND")


# ═══════════════════════════════════════════════════════════════════════════
# template commands
# ═══════════════════════════════════════════════════════════════════════════

@cli.group()
def template() -> None:
    """Generate diagrams from pre-built templates."""


@template.command("flowchart")
@click.argument("steps", nargs=-1, required=True)
@click.option("--direction", "-d", type=click.Choice(["vertical", "horizontal"]),
              default="vertical", help="Layout direction.")
@click.option("--output", "-o", "outfile", type=click.Path(), default=None,
              help="Save to file.")
@click.pass_context
def template_flowchart(ctx: click.Context, steps: tuple[str, ...], direction: str,
                       outfile: str | None) -> None:
    """Generate a flowchart.  Prefix a step with '?' for decision diamonds.

    Example: excalidraw-cli template flowchart "Start" "?Is valid?" "Process" "End"
    """
    s = flowchart(list(steps), direction=direction)
    _session["scene"] = s
    result: dict[str, Any] = {"status": "created", "template": "flowchart",
                               "steps": len(steps), "direction": direction}
    if outfile:
        s.save(outfile)
        result["file"] = outfile
    _output(result, ctx)


@template.command("sequence")
@click.option("--actors", "-a", required=True, help="Comma-separated actor names.")
@click.option("--messages", "-m", multiple=True,
              help="Message in format 'from_idx:to_idx:text' (e.g. '0:1:Hello').")
@click.option("--output", "-o", "outfile", type=click.Path(), default=None)
@click.pass_context
def template_sequence(ctx: click.Context, actors: str, messages: tuple[str, ...],
                      outfile: str | None) -> None:
    """Generate a sequence diagram.

    Example: excalidraw-cli template sequence -a "Client,Server,DB" \\
             -m "0:1:Request" -m "1:2:Query" -m "2:1:Result" -m "1:0:Response"
    """
    actor_list = [a.strip() for a in actors.split(",")]
    msg_list: list[tuple[int, int, str]] = []
    for m in messages:
        parts = m.split(":", 2)
        if len(parts) != 3:
            raise _JsonClickException(f"Invalid message format: {m!r}. Use 'from:to:text'.", "INVALID_FORMAT")
        msg_list.append((int(parts[0]), int(parts[1]), parts[2]))

    s = sequence_diagram(actor_list, msg_list)
    _session["scene"] = s
    result: dict[str, Any] = {"status": "created", "template": "sequence",
                               "actors": len(actor_list), "messages": len(msg_list)}
    if outfile:
        s.save(outfile)
        result["file"] = outfile
    _output(result, ctx)


@template.command("er")
@click.option("--entity", "-e", multiple=True,
              help="Entity in format 'Name:field1,field2,...'.")
@click.option("--relation", "-r", multiple=True,
              help="Relation in format 'EntityA:EntityB:label'.")
@click.option("--output", "-o", "outfile", type=click.Path(), default=None)
@click.pass_context
def template_er(ctx: click.Context, entity: tuple[str, ...],
                relation: tuple[str, ...], outfile: str | None) -> None:
    """Generate an entity-relationship diagram.

    Example: excalidraw-cli template er \\
             -e "User:id,name,email" -e "Post:id,title,body" \\
             -r "User:Post:has many"
    """
    entities = []
    for e in entity:
        parts = e.split(":", 1)
        name = parts[0]
        fields = parts[1].split(",") if len(parts) > 1 else []
        entities.append({"name": name, "fields": fields})

    relations = []
    for r in relation:
        parts = r.split(":", 2)
        if len(parts) != 3:
            raise _JsonClickException(f"Invalid relation format: {r!r}. Use 'A:B:label'.", "INVALID_FORMAT")
        relations.append(tuple(parts))

    s = er_diagram(entities, relations)
    _session["scene"] = s
    result: dict[str, Any] = {"status": "created", "template": "er",
                               "entities": len(entities), "relations": len(relations)}
    if outfile:
        s.save(outfile)
        result["file"] = outfile
    _output(result, ctx)


@template.command("mindmap")
@click.argument("root")
@click.option("--branch", "-b", multiple=True,
              help="Branch in format 'Label:leaf1,leaf2,...'.")
@click.option("--output", "-o", "outfile", type=click.Path(), default=None)
@click.pass_context
def template_mindmap(ctx: click.Context, root: str, branch: tuple[str, ...],
                     outfile: str | None) -> None:
    """Generate a mind map.

    Example: excalidraw-cli template mindmap "Project" \\
             -b "Frontend:React,CSS,HTML" -b "Backend:Python,DB,API"
    """
    branches: dict[str, list[str]] = {}
    for b in branch:
        parts = b.split(":", 1)
        label = parts[0]
        leaves = parts[1].split(",") if len(parts) > 1 else []
        branches[label] = leaves

    s = mindmap(root, branches)
    _session["scene"] = s
    result: dict[str, Any] = {"status": "created", "template": "mindmap",
                               "branches": len(branches)}
    if outfile:
        s.save(outfile)
        result["file"] = outfile
    _output(result, ctx)


@template.command("kanban")
@click.option("--column", "-c", multiple=True,
              help="Column in format 'Name:card1,card2,...'.")
@click.option("--output", "-o", "outfile", type=click.Path(), default=None)
@click.pass_context
def template_kanban(ctx: click.Context, column: tuple[str, ...],
                    outfile: str | None) -> None:
    """Generate a Kanban board.

    Example: excalidraw-cli template kanban \\
             -c "Todo:Design,Implement" -c "In Progress:Review" -c "Done:Deploy"
    """
    columns: dict[str, list[str]] = {}
    for c in column:
        parts = c.split(":", 1)
        name = parts[0]
        cards = parts[1].split(",") if len(parts) > 1 else []
        columns[name] = cards

    s = kanban_board(columns)
    _session["scene"] = s
    result: dict[str, Any] = {"status": "created", "template": "kanban",
                               "columns": len(columns)}
    if outfile:
        s.save(outfile)
        result["file"] = outfile
    _output(result, ctx)


# ═══════════════════════════════════════════════════════════════════════════
# preset commands
# ═══════════════════════════════════════════════════════════════════════════

@cli.group("preset")
def preset_group() -> None:
    """Manage color presets (list, show, create, delete)."""


@preset_group.command("list")
@click.pass_context
def preset_list(ctx: click.Context) -> None:
    """List all available presets (built-in and user-defined)."""
    presets = list_presets()
    result = []
    for name, props in presets.items():
        entry = {"name": name, **props}
        result.append(entry)
    _output(result, ctx)


@preset_group.command("show")
@click.argument("name")
@click.pass_context
def preset_show(ctx: click.Context, name: str) -> None:
    """Show details of a specific preset."""
    p = get_preset(name)
    if p is None:
        raise _JsonClickException(f"Preset not found: {name!r}", "PRESET_NOT_FOUND")
    result = {"name": name, **p}
    _output(result, ctx)


@preset_group.command("create")
@click.argument("name")
@click.option("--stroke-color", required=True, help="Stroke color (hex).")
@click.option("--bg-color", required=True, help="Background color (hex).")
@click.option("--fill", type=click.Choice(["hachure", "cross-hatch", "solid"]),
              default="solid", help="Fill style.")
@click.option("--stroke-width", type=float, default=2, help="Stroke width.")
@click.option("--roughness", type=int, default=1, help="Roughness (0-2).")
@click.pass_context
def preset_create(ctx: click.Context, name: str, stroke_color: str, bg_color: str,
                  fill: str, stroke_width: float, roughness: int) -> None:
    """Create a user-defined preset."""
    props = {
        "strokeColor": stroke_color,
        "backgroundColor": bg_color,
        "fillStyle": fill,
        "strokeWidth": stroke_width,
        "roughness": roughness,
    }
    try:
        path = create_preset(name, props)
    except ValueError as e:
        raise _JsonClickException(str(e), "INVALID_PRESET")
    _output({"status": "created", "name": name, "file": str(path)}, ctx)


@preset_group.command("delete")
@click.argument("name")
@click.pass_context
def preset_delete(ctx: click.Context, name: str) -> None:
    """Delete a user-defined preset."""
    try:
        deleted = delete_preset(name)
    except ValueError as e:
        raise _JsonClickException(str(e), "INVALID_PRESET")
    if deleted:
        _output({"status": "deleted", "name": name}, ctx)
    else:
        raise _JsonClickException(f"Preset not found: {name!r}", "PRESET_NOT_FOUND")


# ═══════════════════════════════════════════════════════════════════════════
# custom template commands
# ═══════════════════════════════════════════════════════════════════════════

@cli.group("custom-template")
def custom_template_group() -> None:
    """Manage custom templates (save, load, list, delete, import)."""


@custom_template_group.command("save")
@click.argument("name")
@click.pass_context
def custom_template_save(ctx: click.Context, name: str) -> None:
    """Save the current scene as a named custom template."""
    s = _get_scene()
    path = save_template(name, s.to_dict())
    _output({"status": "saved", "name": name, "file": str(path)}, ctx)


@custom_template_group.command("load")
@click.argument("name")
@click.pass_context
def custom_template_load(ctx: click.Context, name: str) -> None:
    """Load a custom template into the current session."""
    try:
        data = load_template(name)
    except FileNotFoundError as e:
        raise _JsonClickException(str(e), "TEMPLATE_NOT_FOUND")
    from .core import Scene
    _session["scene"] = Scene(data)
    _session["path"] = None
    info = _session["scene"].summary()
    info["status"] = "loaded"
    info["template"] = name
    _output(info, ctx)


@custom_template_group.command("list")
@click.pass_context
def custom_template_list(ctx: click.Context) -> None:
    """List all saved custom templates."""
    templates = list_templates()
    _output(templates, ctx)


@custom_template_group.command("delete")
@click.argument("name")
@click.pass_context
def custom_template_delete(ctx: click.Context, name: str) -> None:
    """Delete a custom template."""
    deleted = delete_template(name)
    if deleted:
        _output({"status": "deleted", "name": name}, ctx)
    else:
        raise _JsonClickException(f"Template not found: {name!r}", "TEMPLATE_NOT_FOUND")


@custom_template_group.command("import")
@click.argument("name")
@click.argument("file", type=click.Path(exists=True))
@click.pass_context
def custom_template_import(ctx: click.Context, name: str, file: str) -> None:
    """Import an .excalidraw file as a named custom template."""
    try:
        path = import_template(name, file)
    except (FileNotFoundError, ValueError) as e:
        raise _JsonClickException(str(e), "IMPORT_FAILED")
    _output({"status": "imported", "name": name, "file": str(path)}, ctx)


# ═══════════════════════════════════════════════════════════════════════════
# export commands
# ═══════════════════════════════════════════════════════════════════════════

@cli.group()
def export() -> None:
    """Export the current scene to various formats.

    All export commands accept --input/-i to load from a .excalidraw file
    directly, so you can export in a single command without loading first.
    """


def _get_export_scene(input_file: str | None) -> Scene:
    """Return scene from --input file or from session."""
    if input_file:
        return Scene.load(input_file)
    return _get_scene()


@export.command("json")
@click.option("--input", "-i", "input_file", type=click.Path(exists=True), default=None,
              help="Input .excalidraw file (uses session scene if omitted).")
@click.option("--output", "-o", "outfile", type=click.Path(), default=None,
              help="Output file (stdout if omitted).")
@click.option("--pretty/--compact", default=True, help="Pretty-print JSON.")
@click.pass_context
def export_json(ctx: click.Context, input_file: str | None,
                outfile: str | None, pretty: bool) -> None:
    """Export the scene as raw JSON."""
    s = _get_export_scene(input_file)
    data = s.to_dict()
    indent = 2 if pretty else None
    text = json.dumps(data, indent=indent)
    if outfile:
        Path(outfile).write_text(text, encoding="utf-8")
        _output({"status": "exported", "format": "json", "file": outfile}, ctx)
    else:
        click.echo(text)


@export.command("excalidraw")
@click.argument("file", type=click.Path())
@click.option("--input", "-i", "input_file", type=click.Path(exists=True), default=None,
              help="Input .excalidraw file.")
@click.pass_context
def export_excalidraw(ctx: click.Context, file: str, input_file: str | None) -> None:
    """Export (save) the scene as a .excalidraw file."""
    s = _get_export_scene(input_file)
    s.save(file)
    _output({"status": "exported", "format": "excalidraw", "file": file}, ctx)


@export.command("svg")
@click.argument("file", type=click.Path())
@click.option("--input", "-i", "input_file", type=click.Path(exists=True), default=None,
              help="Input .excalidraw file.")
@click.option("--scale", type=float, default=1.0, help="Scale multiplier (default: 1.0).")
@click.option("--padding", type=float, default=40, help="Padding around diagram (default: 40).")
@click.pass_context
def export_svg(ctx: click.Context, file: str, input_file: str | None,
               scale: float, padding: float) -> None:
    """Export the scene as an SVG vector image."""
    from .render import export_svg as _export_svg
    s = _get_export_scene(input_file)
    _export_svg(s, file, scale=scale, padding=padding)
    _output({"status": "exported", "format": "svg", "file": file}, ctx)


@export.command("png")
@click.argument("file", type=click.Path())
@click.option("--input", "-i", "input_file", type=click.Path(exists=True), default=None,
              help="Input .excalidraw file.")
@click.option("--scale", type=float, default=2.0,
              help="Scale multiplier for resolution (default: 2.0 for high-DPI).")
@click.option("--padding", type=float, default=40, help="Padding around diagram.")
@click.pass_context
def export_png(ctx: click.Context, file: str, input_file: str | None,
               scale: float, padding: float) -> None:
    """Export the scene as a high-quality PNG image.

    Requires: pip install cairosvg
    """
    from .render import export_png as _export_png
    s = _get_export_scene(input_file)
    try:
        _export_png(s, file, scale=scale, padding=padding)
    except ImportError as e:
        raise _JsonClickException(str(e), "MISSING_DEPENDENCY")
    _output({"status": "exported", "format": "png", "file": file, "scale": scale}, ctx)


@export.command("jpg")
@click.argument("file", type=click.Path())
@click.option("--input", "-i", "input_file", type=click.Path(exists=True), default=None,
              help="Input .excalidraw file.")
@click.option("--scale", type=float, default=2.0,
              help="Scale multiplier for resolution (default: 2.0).")
@click.option("--quality", type=int, default=95,
              help="JPEG quality 1-100 (default: 95).")
@click.option("--padding", type=float, default=40, help="Padding around diagram.")
@click.pass_context
def export_jpg(ctx: click.Context, file: str, input_file: str | None,
               scale: float, quality: int, padding: float) -> None:
    """Export the scene as a high-quality JPG image.

    Requires: pip install cairosvg Pillow
    """
    from .render import export_jpg as _export_jpg
    s = _get_export_scene(input_file)
    try:
        _export_jpg(s, file, scale=scale, quality=quality, padding=padding)
    except ImportError as e:
        raise _JsonClickException(str(e), "MISSING_DEPENDENCY")
    _output({"status": "exported", "format": "jpg", "file": file,
             "scale": scale, "quality": quality}, ctx)


@export.command("pdf")
@click.argument("file", type=click.Path())
@click.option("--input", "-i", "input_file", type=click.Path(exists=True), default=None,
              help="Input .excalidraw file.")
@click.option("--scale", type=float, default=1.0, help="Scale multiplier (default: 1.0).")
@click.option("--padding", type=float, default=40, help="Padding around diagram.")
@click.pass_context
def export_pdf(ctx: click.Context, file: str, input_file: str | None,
               scale: float, padding: float) -> None:
    """Export the scene as a PDF document.

    Requires: pip install cairosvg
    """
    from .render import export_pdf as _export_pdf
    s = _get_export_scene(input_file)
    try:
        _export_pdf(s, file, scale=scale, padding=padding)
    except ImportError as e:
        raise _JsonClickException(str(e), "MISSING_DEPENDENCY")
    _output({"status": "exported", "format": "pdf", "file": file}, ctx)


# ═══════════════════════════════════════════════════════════════════════════
# REPL
# ═══════════════════════════════════════════════════════════════════════════

def _repl(ctx: click.Context) -> None:
    """Interactive REPL for excalidraw-cli."""
    try:
        from prompt_toolkit import PromptSession
        from prompt_toolkit.history import InMemoryHistory
        session = PromptSession(history=InMemoryHistory())
        readline_available = True
    except ImportError:
        readline_available = False

    click.echo(f"excalidraw-cli v{__version__} — interactive mode")
    click.echo("Type 'help' for commands, 'quit' to exit.\n")

    while True:
        try:
            if readline_available:
                line = session.prompt("excalidraw> ")
            else:
                line = input("excalidraw> ")
        except (EOFError, KeyboardInterrupt):
            click.echo("\nBye!")
            break

        line = line.strip()
        if not line:
            continue
        if line in ("quit", "exit", "q"):
            click.echo("Bye!")
            break
        if line == "help":
            click.echo(ctx.get_help())
            continue

        try:
            args = line.split()
            cli.main(args=args, standalone_mode=False, parent=ctx)
        except click.ClickException as e:
            click.echo(f"Error: {e.format_message()}", err=True)
        except SystemExit:
            pass
        except Exception as e:
            click.echo(f"Error: {e}", err=True)


# ═══════════════════════════════════════════════════════════════════════════
# Entry point
# ═══════════════════════════════════════════════════════════════════════════

def main() -> None:
    cli(standalone_mode=True)


if __name__ == "__main__":
    main()
