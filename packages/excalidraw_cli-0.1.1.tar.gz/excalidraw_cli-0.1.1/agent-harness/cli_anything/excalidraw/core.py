"""Core engine for Excalidraw file creation and manipulation.

Handles the .excalidraw JSON format: element creation, scene composition,
and file I/O.  Every public function returns plain Python dicts/lists so
callers (CLI commands, tests, agents) stay decoupled from Click.
"""

from __future__ import annotations

import copy
import json
import math
import random
import string
import time
import uuid
from pathlib import Path
from typing import Any

# ---------------------------------------------------------------------------
# ID helpers
# ---------------------------------------------------------------------------

def _rand_id(length: int = 21) -> str:
    """Generate a random alphanumeric ID similar to Excalidraw's nanoid."""
    alphabet = string.ascii_letters + string.digits
    return "".join(random.choices(alphabet, k=length))


def _seed() -> int:
    return random.randint(1, 2_000_000_000)


# ---------------------------------------------------------------------------
# Default element values
# ---------------------------------------------------------------------------

_BASE_DEFAULTS: dict[str, Any] = {
    "version": 1,
    "versionNonce": _seed,
    "isDeleted": False,
    "fillStyle": "hachure",
    "strokeWidth": 2,
    "strokeStyle": "solid",
    "roughness": 1,
    "opacity": 100,
    "angle": 0,
    "strokeColor": "#1e1e1e",
    "backgroundColor": "transparent",
    "width": 0,
    "height": 0,
    "seed": _seed,
    "groupIds": [],
    "frameId": None,
    "roundness": {"type": 3},
    "boundElements": [],
    "updated": lambda: int(time.time() * 1000),
    "link": None,
    "locked": False,
}


def _apply_defaults(element: dict, extra_defaults: dict | None = None) -> dict:
    """Fill in missing keys from _BASE_DEFAULTS (+ optional extras)."""
    if "id" not in element:
        element["id"] = _rand_id()
    for key, val in _BASE_DEFAULTS.items():
        if key not in element:
            element[key] = val() if callable(val) else copy.deepcopy(val)
    if extra_defaults:
        for key, val in extra_defaults.items():
            if key not in element:
                element[key] = val() if callable(val) else copy.deepcopy(val)
    return element


# ---------------------------------------------------------------------------
# Element factories
# ---------------------------------------------------------------------------

SHAPE_TYPES = ("rectangle", "ellipse", "diamond")
LINEAR_TYPES = ("arrow", "line")
ALL_TYPES = (*SHAPE_TYPES, *LINEAR_TYPES, "text", "freedraw", "image", "frame")


def create_element(
    element_type: str,
    *,
    x: float = 0,
    y: float = 0,
    width: float = 200,
    height: float = 100,
    label: str | None = None,
    **overrides: Any,
) -> dict:
    """Create a single Excalidraw element dict.

    Parameters
    ----------
    element_type : str
        One of the supported Excalidraw element types.
    x, y : float
        Canvas position.
    width, height : float
        Bounding box dimensions.
    label : str | None
        Optional text label (creates a bound text element for shapes).
    **overrides
        Any additional Excalidraw element properties.
    """
    element_type = element_type.lower()
    if element_type not in ALL_TYPES:
        raise ValueError(
            f"Unknown element type {element_type!r}. "
            f"Supported: {', '.join(ALL_TYPES)}"
        )

    elem: dict[str, Any] = {
        "type": element_type,
        "x": x,
        "y": y,
        "width": width,
        "height": height,
    }
    elem.update(overrides)

    if element_type == "text":
        elem.setdefault("text", label or "")
        elem.setdefault("originalText", elem["text"])
        elem.setdefault("fontSize", 20)
        elem.setdefault("fontFamily", 1)
        elem.setdefault("textAlign", "left")
        elem.setdefault("verticalAlign", "top")
        elem.setdefault("lineHeight", 1.25)
        elem.setdefault("autoResize", True)

    elif element_type in LINEAR_TYPES:
        if "points" not in elem:
            elem["points"] = [[0, 0], [width, height]]
        if element_type == "arrow":
            elem.setdefault("startArrowhead", None)
            elem.setdefault("endArrowhead", "arrow")
            elem.setdefault("startBinding", None)
            elem.setdefault("endBinding", None)
        elem.setdefault("lastCommittedPoint", None)

    elif element_type == "freedraw":
        if "points" not in elem:
            elem["points"] = [[0, 0]]
        elem.setdefault("pressures", [])
        elem.setdefault("simulatePressure", True)

    elif element_type == "frame":
        elem.setdefault("name", None)

    _apply_defaults(elem)

    # Remove roundness for types that don't support it
    if element_type in ("text", "freedraw"):
        elem.pop("roundness", None)

    # Handle label → bound text element
    bound_text = None
    if label and element_type in SHAPE_TYPES:
        bound_text = create_element(
            "text",
            x=x + 10,
            y=y + 10,
            width=width - 20,
            height=height - 20,
            label=label,
            containerId=elem["id"],
            textAlign="center",
            verticalAlign="middle",
        )
        elem["boundElements"] = [{"id": bound_text["id"], "type": "text"}]

    if bound_text:
        return elem, bound_text  # type: ignore[return-value]
    return elem


# ---------------------------------------------------------------------------
# Scene (project) management
# ---------------------------------------------------------------------------

_EMPTY_SCENE: dict[str, Any] = {
    "type": "excalidraw",
    "version": 2,
    "source": "https://excalidraw.com",
    "elements": [],
    "appState": {
        "gridSize": None,
        "viewBackgroundColor": "#ffffff",
    },
    "files": {},
}


class Scene:
    """In-memory representation of an Excalidraw scene (.excalidraw file).

    Supports undo/redo via snapshot stack.
    """

    def __init__(self, data: dict | None = None):
        self._data = copy.deepcopy(data) if data else copy.deepcopy(_EMPTY_SCENE)
        self._undo_stack: list[dict] = []
        self._redo_stack: list[dict] = []
        # Track how many arrows use each (element_id, side) pair for spreading
        self._port_counts: dict[tuple[str, str], int] = {}

    # -- Persistence ---------------------------------------------------------

    @classmethod
    def load(cls, path: str | Path) -> "Scene":
        """Load a scene from a .excalidraw JSON file."""
        path = Path(path)
        if not path.exists():
            raise FileNotFoundError(f"File not found: {path}")
        with open(path, "r", encoding="utf-8") as f:
            data = json.load(f)
        if data.get("type") != "excalidraw":
            raise ValueError(f"Not a valid Excalidraw file: {path}")
        return cls(data)

    def save(self, path: str | Path) -> Path:
        """Save the scene to a .excalidraw JSON file."""
        path = Path(path)
        path.parent.mkdir(parents=True, exist_ok=True)
        with open(path, "w", encoding="utf-8") as f:
            json.dump(self._data, f, indent=2)
        return path

    def to_dict(self) -> dict:
        return copy.deepcopy(self._data)

    # -- Element operations --------------------------------------------------

    @property
    def elements(self) -> list[dict]:
        return self._data["elements"]

    def add_element(self, element: dict) -> str:
        """Add an element and return its id."""
        self._push_undo()
        self._data["elements"].append(element)
        return element["id"]

    def add_elements(self, elements: list[dict]) -> list[str]:
        """Add multiple elements and return their ids."""
        self._push_undo()
        ids = []
        for elem in elements:
            self._data["elements"].append(elem)
            ids.append(elem["id"])
        return ids

    def remove_element(self, element_id: str) -> dict | None:
        """Remove an element by id and return it."""
        self._push_undo()
        for i, elem in enumerate(self._data["elements"]):
            if elem.get("id") == element_id:
                return self._data["elements"].pop(i)
        return None

    def get_element(self, element_id: str) -> dict | None:
        for elem in self._data["elements"]:
            if elem.get("id") == element_id:
                return elem
        return None

    def update_element(self, element_id: str, **props: Any) -> dict | None:
        """Update properties of an existing element."""
        self._push_undo()
        elem = self.get_element(element_id)
        if elem is None:
            return None
        elem.update(props)
        elem["version"] = elem.get("version", 0) + 1
        elem["updated"] = int(time.time() * 1000)
        return elem

    def list_elements(self, element_type: str | None = None) -> list[dict]:
        """Return elements, optionally filtered by type."""
        if element_type:
            return [e for e in self.elements if e.get("type") == element_type]
        return list(self.elements)

    def clear(self) -> None:
        self._push_undo()
        self._data["elements"] = []

    # -- App state -----------------------------------------------------------

    @property
    def app_state(self) -> dict:
        return self._data.get("appState", {})

    def set_background(self, color: str) -> None:
        self._push_undo()
        self._data.setdefault("appState", {})["viewBackgroundColor"] = color

    def set_grid(self, size: int | None) -> None:
        self._push_undo()
        self._data.setdefault("appState", {})["gridSize"] = size

    # -- Undo / Redo ---------------------------------------------------------

    def _push_undo(self) -> None:
        self._undo_stack.append(copy.deepcopy(self._data))
        self._redo_stack.clear()

    def undo(self) -> bool:
        if not self._undo_stack:
            return False
        self._redo_stack.append(copy.deepcopy(self._data))
        self._data = self._undo_stack.pop()
        return True

    def redo(self) -> bool:
        if not self._redo_stack:
            return False
        self._undo_stack.append(copy.deepcopy(self._data))
        self._data = self._redo_stack.pop()
        return True

    # -- High-level helpers --------------------------------------------------

    def add_shape(
        self,
        shape_type: str,
        *,
        x: float = 0,
        y: float = 0,
        width: float = 200,
        height: float = 100,
        label: str | None = None,
        **kwargs: Any,
    ) -> str:
        """Convenience: create a shape element and add it to the scene."""
        result = create_element(
            shape_type, x=x, y=y, width=width, height=height, label=label, **kwargs
        )
        if isinstance(result, tuple):
            shape, text_elem = result
            self.add_elements([shape, text_elem])
            return shape["id"]
        self.add_element(result)
        return result["id"]

    def add_text(
        self,
        text: str,
        *,
        x: float = 0,
        y: float = 0,
        font_size: int = 20,
        **kwargs: Any,
    ) -> str:
        """Convenience: add a text element."""
        elem = create_element(
            "text", x=x, y=y, label=text, fontSize=font_size, **kwargs
        )
        self.add_element(elem)
        return elem["id"]

    def add_arrow(
        self,
        *,
        x: float = 0,
        y: float = 0,
        width: float = 200,
        height: float = 0,
        label: str | None = None,
        start_arrowhead: str | None = None,
        end_arrowhead: str = "arrow",
        **kwargs: Any,
    ) -> str:
        """Convenience: add an arrow element."""
        elem = create_element(
            "arrow",
            x=x,
            y=y,
            width=width,
            height=height,
            startArrowhead=start_arrowhead,
            endArrowhead=end_arrowhead,
            **kwargs,
        )
        self.add_element(elem)
        return elem["id"]

    def add_line(
        self,
        *,
        x: float = 0,
        y: float = 0,
        points: list[list[float]] | None = None,
        **kwargs: Any,
    ) -> str:
        """Convenience: add a line element."""
        pts = points or [[0, 0], [200, 0]]
        elem = create_element("line", x=x, y=y, points=pts, **kwargs)
        self.add_element(elem)
        return elem["id"]

    # -- Diagram templates ---------------------------------------------------

    def add_flowchart_node(
        self,
        text: str,
        *,
        x: float = 0,
        y: float = 0,
        width: float = 200,
        height: float = 80,
        shape: str = "rectangle",
        **kwargs: Any,
    ) -> str:
        """Add a labeled shape suitable for flowcharts."""
        return self.add_shape(
            shape, x=x, y=y, width=width, height=height, label=text, **kwargs
        )

    @staticmethod
    def _is_dark_color(color: str) -> bool:
        """Return True if *color* is a dark hex color (luminance < 0.4)."""
        c = color.lstrip("#")
        if len(c) == 3:
            c = "".join(ch * 2 for ch in c)
        if len(c) != 6:
            return False
        try:
            r, g, b = int(c[0:2], 16), int(c[2:4], 16), int(c[4:6], 16)
        except ValueError:
            return False
        # Relative luminance (simplified sRGB)
        lum = (0.299 * r + 0.587 * g + 0.114 * b) / 255
        return lum < 0.4

    @staticmethod
    def _edge_point(elem: dict, target_cx: float, target_cy: float,
                    gap: float = 0.0) -> tuple[float, float]:
        """Pick the best connection point on an element's edge facing *target*.

        For ellipses, computes the actual perimeter point along the
        center-to-target ray.  For rectangles, uses the bounding-box
        edge midpoint.  The result is offset outward by *gap* pixels.
        """
        ex, ey = elem["x"], elem["y"]
        ew, eh = elem.get("width", 0), elem.get("height", 0)
        cx, cy = ex + ew / 2, ey + eh / 2

        dx = target_cx - cx
        dy = target_cy - cy

        if dx == 0 and dy == 0:
            dx, dy = 0, -1  # default: upward
        if ew == 0 or eh == 0:
            return cx, cy

        etype = elem.get("type", "rectangle")

        if etype == "ellipse":
            # Ellipse perimeter point along the direction (dx, dy)
            rx, ry = ew / 2, eh / 2
            length = math.sqrt(dx * dx + dy * dy)
            if length == 0:
                return cx, cy
            ndx, ndy = dx / length, dy / length
            # Parametric intersection with ellipse: (rx*cos, ry*sin)
            # Scale the unit direction to hit the ellipse:
            #   (ndx*t/rx)^2 + (ndy*t/ry)^2 = 1
            denom = math.sqrt((ndx / rx) ** 2 + (ndy / ry) ** 2)
            t = 1.0 / denom if denom > 0 else 0
            return cx + ndx * (t + gap), cy + ndy * (t + gap)

        # Rectangle: bounding-box edge midpoint
        if abs(dy) * ew > abs(dx) * eh:
            if dy > 0:
                return cx, ey + eh + gap   # bottom
            else:
                return cx, ey - gap        # top
        else:
            if dx > 0:
                return ex + ew + gap, cy   # right
            else:
                return ex - gap, cy        # left

    @staticmethod
    def _edge_point_on_side(
        elem: dict, side: str, offset: float = 0.5, gap: float = 0.0,
    ) -> tuple[float, float]:
        """Return a point on a specific edge of *elem*, offset outward by *gap*.

        *side* is one of ``"top"``, ``"bottom"``, ``"left"``, ``"right"``.
        *offset* is 0..1 along the edge (0.5 = midpoint).
        *gap* is the distance in pixels to push the point away from the edge
        so that arrows don't overlap with the shape boundary.

        For ellipses, computes the actual perimeter point for the given
        side direction, then offsets outward.
        """
        ex, ey = elem["x"], elem["y"]
        ew, eh = elem.get("width", 0), elem.get("height", 0)
        etype = elem.get("type", "rectangle")

        if etype == "ellipse":
            cx, cy = ex + ew / 2, ey + eh / 2
            rx, ry = ew / 2, eh / 2
            if side == "top":
                return cx, cy - ry - gap
            elif side == "bottom":
                return cx, cy + ry + gap
            elif side == "left":
                return cx - rx - gap, cy
            else:  # right
                return cx + rx + gap, cy

        if side == "top":
            return ex + ew * offset, ey - gap
        elif side == "bottom":
            return ex + ew * offset, ey + eh + gap
        elif side == "left":
            return ex - gap, ey + eh * offset
        else:  # right
            return ex + ew + gap, ey + eh * offset

    @staticmethod
    def _best_side(
        elem: dict, target_cx: float, target_cy: float,
    ) -> str:
        """Return the side name ("top"/"bottom"/"left"/"right") that
        ``_edge_point`` would choose for the given target."""
        ex, ey = elem["x"], elem["y"]
        ew, eh = elem.get("width", 0), elem.get("height", 0)
        cx, cy = ex + ew / 2, ey + eh / 2
        dx = target_cx - cx
        dy = target_cy - cy
        if dx == 0 and dy == 0:
            return "top"
        if ew == 0 or eh == 0:
            return "top"
        if abs(dy) * ew > abs(dx) * eh:
            return "bottom" if dy > 0 else "top"
        else:
            return "right" if dx > 0 else "left"

    # -- Obstacle-aware arrow routing ----------------------------------------

    @staticmethod
    def _line_hits_box(
        x1: float, y1: float, x2: float, y2: float,
        bx: float, by: float, bw: float, bh: float,
        margin: float = 6.0,
    ) -> bool:
        """Return True if the line segment (x1,y1)→(x2,y2) intersects the
        axis-aligned rectangle (bx, by, bw, bh) expanded by *margin*.

        Uses the Liang-Barsky algorithm for fast segment–AABB clipping.
        """
        # Expand box by margin
        rx = bx - margin
        ry = by - margin
        rw = bw + 2 * margin
        rh = bh + 2 * margin

        dx = x2 - x1
        dy = y2 - y1

        # p, q arrays for Liang-Barsky
        p = [-dx, dx, -dy, dy]
        q = [x1 - rx, rx + rw - x1, y1 - ry, ry + rh - y1]

        t0, t1 = 0.0, 1.0
        for pi, qi in zip(p, q):
            if pi == 0:
                if qi < 0:
                    return False  # parallel and outside
            else:
                t = qi / pi
                if pi < 0:
                    t0 = max(t0, t)
                else:
                    t1 = min(t1, t)
                if t0 > t1:
                    return False
        return True

    def _find_obstacles(
        self,
        x1: float, y1: float, x2: float, y2: float,
        exclude_ids: set[str],
    ) -> list[dict]:
        """Find scene elements whose bounding boxes are crossed by the
        line segment (x1,y1)→(x2,y2), excluding elements in *exclude_ids*
        and non-shape elements (arrows, lines, text, etc.).
        """
        obstacles = []
        for elem in self.elements:
            if elem["id"] in exclude_ids:
                continue
            etype = elem.get("type", "")
            if etype not in SHAPE_TYPES:
                continue
            ew = elem.get("width", 0)
            eh = elem.get("height", 0)
            if ew == 0 or eh == 0:
                continue
            if self._line_hits_box(x1, y1, x2, y2,
                                   elem["x"], elem["y"], ew, eh):
                obstacles.append(elem)
        return obstacles

    @staticmethod
    def _route_around(
        sx: float, sy: float, dx: float, dy: float,
        obstacles: list[dict],
        margin: float = 20.0,
    ) -> list[list[float]]:
        """Compute waypoints that route an arrow from (sx,sy) to (dx,dy)
        around *obstacles*.  Returns a points list (relative to sx,sy).

        Strategy: compute the combined bounding box of all obstacles, then
        evaluate above and below detour paths and pick the shortest.
        """
        # Compute bounding box that covers ALL obstacles
        min_y = min(o["y"] for o in obstacles)
        max_y = max(o["y"] + o.get("height", 0) for o in obstacles)

        def _path_len(pts: list[list[float]]) -> float:
            total = 0.0
            for i in range(1, len(pts)):
                pdx = pts[i][0] - pts[i - 1][0]
                pdy = pts[i][1] - pts[i - 1][1]
                total += math.sqrt(pdx * pdx + pdy * pdy)
            return total

        # Above: go up to clear the obstacle top, across, then down
        above_y = min_y - margin
        above_path = [
            [0, 0],
            [0, above_y - sy],
            [dx - sx, above_y - sy],
            [dx - sx, dy - sy],
        ]

        # Below: go down to clear the obstacle bottom, across, then up
        below_y = max_y + margin
        below_path = [
            [0, 0],
            [0, below_y - sy],
            [dx - sx, below_y - sy],
            [dx - sx, dy - sy],
        ]

        # Pick the shorter detour
        if _path_len(above_path) <= _path_len(below_path):
            return above_path
        return below_path

    def _pick_edge_pair(
        self,
        src: dict, dst: dict,
        from_id: str, to_id: str,
        exclude_ids: set[str],
    ) -> tuple[str, str, float, float, float, float, list[dict]]:
        """Choose the best (src_side, dst_side) and return the edge points.

        Strategy:
        1. Try the default center-to-center edge selection first.
        2. If the straight line hits obstacles, evaluate all sensible
           alternative edge combos and pick the one with the shortest
           obstacle-free path, or the shortest detour if none is clear.

        Returns (src_side, dst_side, sx, sy, ex, ey, obstacles).
        """
        src_cx = src["x"] + src.get("width", 0) / 2
        src_cy = src["y"] + src.get("height", 0) / 2
        dst_cx = dst["x"] + dst.get("width", 0) / 2
        dst_cy = dst["y"] + dst.get("height", 0) / 2

        # Default: center-to-center vector
        default_src_side = self._best_side(src, dst_cx, dst_cy)
        default_dst_side = self._best_side(dst, src_cx, src_cy)
        sx, sy = self._edge_point(src, dst_cx, dst_cy)
        ex, ey = self._edge_point(dst, src_cx, src_cy)

        obstacles = self._find_obstacles(sx, sy, ex, ey, exclude_ids)
        if not obstacles:
            return default_src_side, default_dst_side, sx, sy, ex, ey, []

        # The default path hits obstacles.  First, try all obstacle-free
        # edge combos and pick the shortest one if any exist.
        sides = ["top", "bottom", "left", "right"]
        best_clear = None
        best_clear_cost = float("inf")

        for s_side in sides:
            for d_side in sides:
                s_pt = self._edge_point_on_side(src, s_side)
                d_pt = self._edge_point_on_side(dst, d_side)

                # Skip combos that would route back through the source
                if s_side == "right" and d_pt[0] < s_pt[0]:
                    continue
                if s_side == "left" and d_pt[0] > s_pt[0]:
                    continue
                if s_side == "bottom" and d_pt[1] < s_pt[1]:
                    continue
                if s_side == "top" and d_pt[1] > s_pt[1]:
                    continue

                obs = self._find_obstacles(
                    s_pt[0], s_pt[1], d_pt[0], d_pt[1], exclude_ids,
                )
                if not obs:
                    dist = math.sqrt(
                        (d_pt[0] - s_pt[0]) ** 2
                        + (d_pt[1] - s_pt[1]) ** 2
                    )
                    if dist < best_clear_cost:
                        best_clear_cost = dist
                        best_clear = (
                            s_side, d_side,
                            s_pt[0], s_pt[1], d_pt[0], d_pt[1], [],
                        )

        if best_clear is not None:
            return best_clear

        # No obstacle-free path exists.  Determine whether the detour
        # should go above or below the obstacle region, then pick edges
        # that naturally align with that direction.
        ob_min_y = min(o["y"] for o in obstacles)
        ob_max_y = max(o["y"] + o.get("height", 0) for o in obstacles)

        above_y = ob_min_y - 20
        below_y = ob_max_y + 20
        above_dist = abs(src_cy - above_y) + abs(dst_cy - above_y)
        below_dist = abs(src_cy - below_y) + abs(dst_cy - below_y)

        if above_dist <= below_dist:
            # Route above → use top edges
            best_side = "top"
        else:
            # Route below → use bottom edges
            best_side = "bottom"

        s_pt = self._edge_point_on_side(src, best_side)
        d_pt = self._edge_point_on_side(dst, best_side)
        obs = self._find_obstacles(
            s_pt[0], s_pt[1], d_pt[0], d_pt[1], exclude_ids,
        )
        return (best_side, best_side,
                s_pt[0], s_pt[1], d_pt[0], d_pt[1], obs or obstacles)

    def _port_offset(self, elem_id: str, side: str) -> float:
        """Return 0..1 offset along an edge, spreading arrows evenly.

        Each call increments the count for (elem_id, side).
        """
        key = (elem_id, side)
        count = self._port_counts.get(key, 0)
        self._port_counts[key] = count + 1
        # For the first arrow, use 0.5 (midpoint).
        # For additional arrows, spread evenly: 1/(n+1), 2/(n+1), ...
        total = count + 1
        if total == 1:
            return 0.5
        # Recompute all positions for even spacing
        return total / (total + 1)

    def connect(
        self,
        from_id: str,
        to_id: str,
        *,
        label: str | None = None,
        arrow_style: str = "straight",
        **kwargs: Any,
    ) -> str | None:
        """Draw an arrow between two elements by their ids.

        Computes the best edge points on both source and destination so
        that the arrow exits/enters from the nearest sides.  If the
        straight-line path would cross any other shape elements, the
        arrow is routed around them with waypoints.

        Edge selection rules:
        1. Default: pick the side closest to the destination center.
        2. If that path crosses obstacles, try all viable edge combos
           and pick the shortest obstacle-free path.
        3. Multiple arrows on the same edge are spread evenly.

        Parameters
        ----------
        arrow_style : str
            ``"straight"`` (default) – polyline with sharp corners.
            ``"curved"`` – smooth bezier curve between endpoints.
            ``"elbowed"`` – right-angle path with rounded corners.
        """
        src = self.get_element(from_id)
        dst = self.get_element(to_id)
        if not src or not dst:
            return None

        # Auto-detect stroke color for arrows on dark backgrounds
        if "strokeColor" not in kwargs:
            bg = self.app_state.get("viewBackgroundColor", "#ffffff")
            if self._is_dark_color(bg):
                kwargs["strokeColor"] = "#cdd6f4"

        # Build set of IDs to exclude from obstacle detection:
        # source, destination, and any text elements bound to them
        exclude_ids = {from_id, to_id}
        for eid in (from_id, to_id):
            el = self.get_element(eid)
            if el:
                for be in el.get("boundElements", []):
                    if be.get("type") == "text":
                        exclude_ids.add(be["id"])
                for sub in self.elements:
                    if sub.get("containerId") == eid:
                        exclude_ids.add(sub["id"])

        # Pick best edge pair (obstacle-aware)
        src_side, dst_side, sx, sy, ex, ey, obstacles = (
            self._pick_edge_pair(src, dst, from_id, to_id, exclude_ids)
        )

        # Apply port spreading for multiple arrows on the same edge
        src_offset = self._port_offset(from_id, src_side)
        dst_offset = self._port_offset(to_id, dst_side)
        sx, sy = self._edge_point_on_side(src, src_side, src_offset)
        ex, ey = self._edge_point_on_side(dst, dst_side, dst_offset)

        # Re-check obstacles with final adjusted points
        if obstacles:
            obstacles = self._find_obstacles(sx, sy, ex, ey, exclude_ids)

        arrow_w = ex - sx
        arrow_h = ey - sy

        if arrow_style == "elbowed":
            if obstacles:
                points = self._route_around(sx, sy, ex, ey, obstacles)
            elif abs(arrow_w) > abs(arrow_h):
                mid_x = arrow_w / 2
                points = [[0, 0], [mid_x, 0], [mid_x, arrow_h], [arrow_w, arrow_h]]
            else:
                mid_y = arrow_h / 2
                points = [[0, 0], [0, mid_y], [arrow_w, mid_y], [arrow_w, arrow_h]]
        elif obstacles:
            points = self._route_around(sx, sy, ex, ey, obstacles)
        else:
            points = [[0, 0], [arrow_w, arrow_h]]

        # Store the style so the renderer can use it
        effective_style = arrow_style
        if arrow_style == "straight" and obstacles:
            effective_style = "elbowed"  # routed paths render as elbowed

        elem = create_element(
            "arrow",
            x=sx,
            y=sy,
            width=abs(arrow_w),
            height=abs(arrow_h),
            points=points,
            arrowStyle=effective_style,
            startBinding={"elementId": from_id, "focus": 0, "gap": 4},
            endBinding={"elementId": to_id, "focus": 0, "gap": 4},
            **kwargs,
        )
        # Update bound elements on source and destination
        src.setdefault("boundElements", []).append({"id": elem["id"], "type": "arrow"})
        dst.setdefault("boundElements", []).append({"id": elem["id"], "type": "arrow"})
        self.add_element(elem)

        # Add a text label on the arrow if requested
        if label:
            # Place label at the midpoint of the arrow path
            mid_idx = len(points) // 2
            if len(points) % 2 == 0:
                # Even number of points: average the two middle points
                p1 = points[mid_idx - 1]
                p2 = points[mid_idx]
                mid_rx = (p1[0] + p2[0]) / 2
                mid_ry = (p1[1] + p2[1]) / 2
            else:
                mid_rx = points[mid_idx][0]
                mid_ry = points[mid_idx][1]

            label_font_size = 16
            label_w = len(label) * label_font_size * 0.6
            label_h = label_font_size * 1.25
            label_x = sx + mid_rx - label_w / 2
            # Place the label well above the arrow line so text never
            # overlaps with the arrow path.  Use a generous gap that
            # accounts for the font's ascender height.
            label_y = sy + mid_ry - label_h - 10

            text_elem = create_element(
                "text",
                x=label_x,
                y=label_y,
                width=label_w,
                height=label_h,
                label=label,
                fontSize=label_font_size,
                containerId=elem["id"],
                textAlign="center",
                verticalAlign="middle",
            )
            elem.setdefault("boundElements", []).append(
                {"id": text_elem["id"], "type": "text"}
            )
            self.add_element(text_elem)

        return elem["id"]

    # -- Summary / stats -----------------------------------------------------

    def summary(self) -> dict[str, Any]:
        """Return a summary dict of the scene."""
        type_counts: dict[str, int] = {}
        for e in self.elements:
            t = e.get("type", "unknown")
            type_counts[t] = type_counts.get(t, 0) + 1
        return {
            "total_elements": len(self.elements),
            "element_types": type_counts,
            "background": self.app_state.get("viewBackgroundColor", "#ffffff"),
            "grid_size": self.app_state.get("gridSize"),
        }
