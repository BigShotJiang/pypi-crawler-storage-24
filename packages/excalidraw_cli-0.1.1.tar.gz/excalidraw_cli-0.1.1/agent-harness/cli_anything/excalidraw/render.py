"""SVG renderer for Excalidraw scenes.

Converts Scene elements to SVG markup, then optionally to PNG, JPG, or PDF
using cairosvg (optional dependency) and Pillow (optional dependency).

The renderer produces clean vector SVG that faithfully represents element
positions, sizes, colors, fills, and text.  For the hand-drawn "roughness"
look, open the .excalidraw file directly in excalidraw.com.
"""

from __future__ import annotations

import html
import io
import math
from pathlib import Path
from typing import Any
from xml.etree.ElementTree import Element, SubElement, tostring

from .core import Scene

# ---------------------------------------------------------------------------
# SVG generation
# ---------------------------------------------------------------------------

_SVG_NS = "http://www.w3.org/2000/svg"

# Excalidraw font family mapping
_FONT_MAP = {
    1: "'Virgil', 'Segoe Print', 'Bradley Hand', cursive",
    2: "'Helvetica', 'Arial', sans-serif",
    3: "'Cascadia', 'Fira Code', monospace",
}

# Hachure fill patterns
_HACHURE_DEFS_CACHE: dict[str, str] = {}


def _css_opacity(opacity: int) -> str:
    """Convert 0-100 integer opacity to CSS 0-1 float string."""
    return f"{opacity / 100:.2f}" if opacity < 100 else "1"


def _hex_or_transparent(color: str) -> str:
    """Return 'none' for transparent, otherwise the color string."""
    if color in ("transparent", "", "none"):
        return "none"
    return color


def _make_hachure_pattern(pattern_id: str, color: str, angle: float = -45) -> Element:
    """Create an SVG <pattern> element for hachure fill."""
    pattern = Element("pattern", {
        "id": pattern_id,
        "patternUnits": "userSpaceOnUse",
        "width": "10",
        "height": "10",
        "patternTransform": f"rotate({angle})",
    })
    line = SubElement(pattern, "line", {
        "x1": "0", "y1": "0", "x2": "0", "y2": "10",
        "stroke": color,
        "stroke-width": "1.5",
    })
    return pattern


def _make_crosshatch_pattern(pattern_id: str, color: str) -> Element:
    """Create an SVG <pattern> for cross-hatch fill."""
    pattern = Element("pattern", {
        "id": pattern_id,
        "patternUnits": "userSpaceOnUse",
        "width": "10",
        "height": "10",
    })
    SubElement(pattern, "line", {
        "x1": "0", "y1": "0", "x2": "10", "y2": "10",
        "stroke": color, "stroke-width": "1.5",
    })
    SubElement(pattern, "line", {
        "x1": "10", "y1": "0", "x2": "0", "y2": "10",
        "stroke": color, "stroke-width": "1.5",
    })
    return pattern


def _get_fill(elem: dict, defs: Element, pattern_counter: list[int]) -> str:
    """Return the SVG fill value for an element, adding patterns to defs if needed."""
    fill_style = elem.get("fillStyle", "hachure")
    bg = _hex_or_transparent(elem.get("backgroundColor", "transparent"))

    if bg == "none":
        return "none"

    if fill_style == "solid":
        return bg

    # Hachure or cross-hatch: create a pattern
    pattern_counter[0] += 1
    pid = f"pat{pattern_counter[0]}"

    if fill_style == "cross-hatch":
        pat = _make_crosshatch_pattern(pid, bg)
    else:
        pat = _make_hachure_pattern(pid, bg)

    defs.append(pat)
    return f"url(#{pid})"


def _common_style(elem: dict) -> dict[str, str]:
    """Extract common SVG style attributes from an element."""
    stroke = elem.get("strokeColor", "#1e1e1e")
    sw = elem.get("strokeWidth", 2)
    opacity = elem.get("opacity", 100)
    stroke_style = elem.get("strokeStyle", "solid")

    attrs: dict[str, str] = {
        "stroke": stroke,
        "stroke-width": str(sw),
    }
    if opacity < 100:
        attrs["opacity"] = _css_opacity(opacity)
    if stroke_style == "dashed":
        attrs["stroke-dasharray"] = f"{sw * 4},{sw * 3}"
    elif stroke_style == "dotted":
        attrs["stroke-dasharray"] = f"{sw},{sw * 2}"

    return attrs


def _render_rectangle(elem: dict, parent: Element, defs: Element,
                      pc: list[int]) -> None:
    x, y = elem["x"], elem["y"]
    w, h = elem.get("width", 0), elem.get("height", 0)
    fill = _get_fill(elem, defs, pc)
    style = _common_style(elem)

    roundness = elem.get("roundness")
    rx = "0"
    if roundness and isinstance(roundness, dict):
        # Approximate Excalidraw's roundness
        rx = str(min(w, h) * 0.1)

    SubElement(parent, "rect", {
        "x": str(x), "y": str(y),
        "width": str(w), "height": str(h),
        "rx": rx, "ry": rx,
        "fill": fill,
        **style,
    })


def _render_ellipse(elem: dict, parent: Element, defs: Element,
                    pc: list[int]) -> None:
    x, y = elem["x"], elem["y"]
    w, h = elem.get("width", 0), elem.get("height", 0)
    fill = _get_fill(elem, defs, pc)
    style = _common_style(elem)

    SubElement(parent, "ellipse", {
        "cx": str(x + w / 2), "cy": str(y + h / 2),
        "rx": str(w / 2), "ry": str(h / 2),
        "fill": fill,
        **style,
    })


def _render_diamond(elem: dict, parent: Element, defs: Element,
                    pc: list[int]) -> None:
    x, y = elem["x"], elem["y"]
    w, h = elem.get("width", 0), elem.get("height", 0)
    fill = _get_fill(elem, defs, pc)
    style = _common_style(elem)

    # Diamond: midpoints of bounding box sides
    points = f"{x + w / 2},{y} {x + w},{y + h / 2} {x + w / 2},{y + h} {x},{y + h / 2}"
    SubElement(parent, "polygon", {
        "points": points,
        "fill": fill,
        **style,
    })


def _render_text(elem: dict, parent: Element) -> None:
    x, y = elem["x"], elem["y"]
    w = elem.get("width", 0)
    h = elem.get("height", 0)
    text = elem.get("text", "")
    font_size = elem.get("fontSize", 20)
    font_family_id = elem.get("fontFamily", 1)
    font_family = _FONT_MAP.get(font_family_id, _FONT_MAP[1])
    text_align = elem.get("textAlign", "left")
    v_align = elem.get("verticalAlign", "top")
    opacity = elem.get("opacity", 100)
    color = elem.get("strokeColor", "#1e1e1e")

    # Horizontal anchor
    anchor_map = {"left": "start", "center": "middle", "right": "end"}
    anchor = anchor_map.get(text_align, "start")

    # X position based on alignment
    if text_align == "center":
        tx = x + w / 2
    elif text_align == "right":
        tx = x + w
    else:
        tx = x

    lines = text.split("\n")
    line_height = font_size * elem.get("lineHeight", 1.25)
    total_text_height = len(lines) * line_height

    # Y position based on vertical alignment
    if v_align == "middle":
        ty = y + (h - total_text_height) / 2 + font_size * 0.85
    elif v_align == "bottom":
        ty = y + h - total_text_height + font_size * 0.85
    else:
        ty = y + font_size * 0.85

    attrs: dict[str, str] = {
        "x": str(tx),
        "y": str(ty),
        "font-family": font_family,
        "font-size": str(font_size),
        "fill": color,
        "text-anchor": anchor,
        "dominant-baseline": "auto",
    }
    if opacity < 100:
        attrs["opacity"] = _css_opacity(opacity)

    text_el = SubElement(parent, "text", attrs)

    if len(lines) == 1:
        text_el.text = text
    else:
        for i, line in enumerate(lines):
            tspan = SubElement(text_el, "tspan", {
                "x": str(tx),
                "dy": str(line_height) if i > 0 else "0",
            })
            tspan.text = line


def _render_arrow(elem: dict, parent: Element) -> None:
    x, y = elem["x"], elem["y"]
    points = elem.get("points", [[0, 0], [200, 0]])
    style = _common_style(elem)
    arrow_style = elem.get("arrowStyle", "straight")

    if len(points) < 2:
        return

    # For curved arrows, the arrowhead direction must match the bezier
    # tangent, not the raw waypoint direction.  _render_curved_arrow
    # returns (end_tangent_from, start_tangent_from) as absolute coords
    # so we can orient the arrowheads correctly.
    end_tangent_from: tuple[float, float] | None = None
    start_tangent_from: tuple[float, float] | None = None

    if arrow_style == "curved":
        end_tangent_from, start_tangent_from = _render_curved_arrow(
            elem, parent, x, y, points, style,
        )
    elif arrow_style == "elbowed" and len(points) >= 3:
        _render_elbowed_arrow(elem, parent, x, y, points, style)
    else:
        # Straight polyline (default)
        point_str = " ".join(f"{x + p[0]},{y + p[1]}" for p in points)
        SubElement(parent, "polyline", {
            "points": point_str,
            "fill": "none",
            **style,
        })

    # Draw arrowheads
    end_arrowhead = elem.get("endArrowhead", "arrow")
    start_arrowhead = elem.get("startArrowhead")
    color = elem.get("strokeColor", "#1e1e1e")
    sw = elem.get("strokeWidth", 2)

    if end_arrowhead == "arrow" and len(points) >= 2:
        if end_tangent_from is not None:
            # Use bezier tangent: from_pt and to_pt in absolute coords
            tip = (x + points[-1][0], y + points[-1][1])
            _draw_arrowhead_abs(parent, end_tangent_from, tip, color, sw)
        else:
            _draw_arrowhead(parent, x, y, points[-2], points[-1], color, sw)

    if start_arrowhead == "arrow" and len(points) >= 2:
        if start_tangent_from is not None:
            tip = (x + points[0][0], y + points[0][1])
            _draw_arrowhead_abs(parent, start_tangent_from, tip, color, sw)
        else:
            _draw_arrowhead(parent, x, y, points[1], points[0], color, sw)


def _render_curved_arrow(
    elem: dict, parent: Element,
    x: float, y: float, points: list, style: dict,
) -> tuple[tuple[float, float], tuple[float, float]]:
    """Render arrow as a smooth cubic bezier SVG path.

    Returns (end_tangent_from, start_tangent_from) — the last/first
    bezier control points (absolute coords) so the caller can orient
    arrowheads along the curve tangent.
    """
    # Track the control points adjacent to the endpoints for tangent
    first_cp: tuple[float, float] = (0.0, 0.0)
    last_cp: tuple[float, float] = (0.0, 0.0)

    if len(points) == 2:
        p0 = points[0]
        p1 = points[1]
        ax0, ay0 = x + p0[0], y + p0[1]
        ax1, ay1 = x + p1[0], y + p1[1]

        # Control points offset perpendicular to the line
        mdx = (p1[0] - p0[0])
        mdy = (p1[1] - p0[1])
        curve_offset = 0.25
        cp1x = ax0 + mdx * 0.33 - mdy * curve_offset
        cp1y = ay0 + mdy * 0.33 + mdx * curve_offset
        cp2x = ax0 + mdx * 0.66 - mdy * curve_offset
        cp2y = ay0 + mdy * 0.66 + mdx * curve_offset

        d = f"M {ax0},{ay0} C {cp1x},{cp1y} {cp2x},{cp2y} {ax1},{ay1}"
        first_cp = (cp1x, cp1y)
        last_cp = (cp2x, cp2y)
    else:
        abs_pts = [(x + p[0], y + p[1]) for p in points]
        d = f"M {abs_pts[0][0]},{abs_pts[0][1]}"
        for i in range(1, len(abs_pts)):
            prev = abs_pts[i - 1]
            curr = abs_pts[i]
            cp1x = prev[0] + (curr[0] - prev[0]) * 0.33
            cp1y = prev[1] + (curr[1] - prev[1]) * 0.0
            cp2x = prev[0] + (curr[0] - prev[0]) * 0.66
            cp2y = curr[1] + (prev[1] - curr[1]) * 0.0
            d += f" C {cp1x},{cp1y} {cp2x},{cp2y} {curr[0]},{curr[1]}"
            if i == 1:
                first_cp = (cp1x, cp1y)
            last_cp = (cp2x, cp2y)

    SubElement(parent, "path", {
        "d": d,
        "fill": "none",
        **style,
    })

    # end_tangent_from = last control point (tangent direction into endpoint)
    # start_tangent_from = first control point (tangent direction into start)
    return last_cp, first_cp


def _render_elbowed_arrow(
    elem: dict, parent: Element,
    x: float, y: float, points: list, style: dict,
) -> None:
    """Render arrow as an orthogonal path with rounded corners."""
    abs_pts = [(x + p[0], y + p[1]) for p in points]
    radius = min(12.0, elem.get("strokeWidth", 2) * 6)

    d = f"M {abs_pts[0][0]},{abs_pts[0][1]}"

    for i in range(1, len(abs_pts) - 1):
        prev = abs_pts[i - 1]
        curr = abs_pts[i]
        nxt = abs_pts[i + 1]

        # Vectors into and out of the corner
        dx_in = curr[0] - prev[0]
        dy_in = curr[1] - prev[1]
        dx_out = nxt[0] - curr[0]
        dy_out = nxt[1] - curr[1]

        len_in = math.sqrt(dx_in * dx_in + dy_in * dy_in)
        len_out = math.sqrt(dx_out * dx_out + dy_out * dy_out)

        if len_in == 0 or len_out == 0:
            d += f" L {curr[0]},{curr[1]}"
            continue

        # Clamp radius to half the shorter segment
        r = min(radius, len_in / 2, len_out / 2)

        # Points just before and after the corner
        bx = curr[0] - (dx_in / len_in) * r
        by = curr[1] - (dy_in / len_in) * r
        ax = curr[0] + (dx_out / len_out) * r
        ay = curr[1] + (dy_out / len_out) * r

        # Determine sweep direction for the arc
        cross = dx_in * dy_out - dy_in * dx_out
        sweep = 1 if cross > 0 else 0

        d += f" L {bx},{by}"
        d += f" A {r},{r} 0 0 {sweep} {ax},{ay}"

    # Line to final point
    last = abs_pts[-1]
    d += f" L {last[0]},{last[1]}"

    SubElement(parent, "path", {
        "d": d,
        "fill": "none",
        **style,
    })


def _draw_arrowhead_abs(
    parent: Element,
    from_abs: tuple[float, float],
    to_abs: tuple[float, float],
    color: str, stroke_width: float,
) -> None:
    """Draw a triangular arrowhead using absolute coordinates.

    *from_abs* is the point the arrow is coming from (e.g. the last
    bezier control point), *to_abs* is the tip of the arrow.
    """
    dx = to_abs[0] - from_abs[0]
    dy = to_abs[1] - from_abs[1]
    length = math.sqrt(dx * dx + dy * dy)
    if length == 0:
        return
    dx, dy = dx / length, dy / length
    head_len = max(10, stroke_width * 5)

    ax, ay = to_abs
    bx = ax - head_len * dx + head_len * 0.4 * dy
    by = ay - head_len * dy - head_len * 0.4 * dx
    cx = ax - head_len * dx - head_len * 0.4 * dy
    cy = ay - head_len * dy + head_len * 0.4 * dx

    SubElement(parent, "polygon", {
        "points": f"{ax},{ay} {bx},{by} {cx},{cy}",
        "fill": color,
        "stroke": "none",
    })


def _draw_arrowhead(parent: Element, ox: float, oy: float,
                    from_pt: list[float], to_pt: list[float],
                    color: str, stroke_width: float) -> None:
    """Draw a triangular arrowhead at the to_pt."""
    dx = to_pt[0] - from_pt[0]
    dy = to_pt[1] - from_pt[1]
    length = math.sqrt(dx * dx + dy * dy)
    if length == 0:
        return

    # Normalize
    dx, dy = dx / length, dy / length
    head_len = max(10, stroke_width * 5)

    # Arrowhead points
    ax = ox + to_pt[0]
    ay = oy + to_pt[1]
    bx = ax - head_len * dx + head_len * 0.4 * dy
    by = ay - head_len * dy - head_len * 0.4 * dx
    cx = ax - head_len * dx - head_len * 0.4 * dy
    cy = ay - head_len * dy + head_len * 0.4 * dx

    SubElement(parent, "polygon", {
        "points": f"{ax},{ay} {bx},{by} {cx},{cy}",
        "fill": color,
        "stroke": "none",
    })


def _render_line(elem: dict, parent: Element) -> None:
    x, y = elem["x"], elem["y"]
    points = elem.get("points", [[0, 0], [200, 0]])
    style = _common_style(elem)

    point_str = " ".join(f"{x + p[0]},{y + p[1]}" for p in points)
    SubElement(parent, "polyline", {
        "points": point_str,
        "fill": "none",
        **style,
    })


def _render_freedraw(elem: dict, parent: Element) -> None:
    x, y = elem["x"], elem["y"]
    points = elem.get("points", [])
    style = _common_style(elem)

    if len(points) < 2:
        return

    # Build SVG path
    d = f"M {x + points[0][0]},{y + points[0][1]}"
    for p in points[1:]:
        d += f" L {x + p[0]},{y + p[1]}"

    SubElement(parent, "path", {
        "d": d,
        "fill": "none",
        **style,
        "stroke-linecap": "round",
        "stroke-linejoin": "round",
    })


def scene_to_svg(
    scene: Scene,
    *,
    padding: float = 40,
    scale: float = 1.0,
) -> str:
    """Render a Scene to an SVG string.

    Parameters
    ----------
    scene : Scene
        The scene to render.
    padding : float
        Padding around the diagram bounding box.
    scale : float
        Scale multiplier (2.0 = 2x resolution for raster export).

    Returns
    -------
    str
        Complete SVG document as a string.
    """
    elements = scene.list_elements()
    if not elements:
        # Empty scene
        return (
            '<?xml version="1.0" encoding="UTF-8"?>\n'
            f'<svg xmlns="{_SVG_NS}" width="200" height="200">'
            f'<rect width="200" height="200" fill="{scene.app_state.get("viewBackgroundColor", "#ffffff")}"/>'
            '</svg>'
        )

    # Compute bounding box
    min_x = min_y = float("inf")
    max_x = max_y = float("-inf")

    for elem in elements:
        ex, ey = elem.get("x", 0), elem.get("y", 0)
        ew = elem.get("width", 0)
        eh = elem.get("height", 0)

        # For linear elements, compute from points
        if elem.get("type") in ("arrow", "line", "freedraw"):
            pts = elem.get("points", [[0, 0]])
            for p in pts:
                px, py = ex + p[0], ey + p[1]
                min_x = min(min_x, px)
                min_y = min(min_y, py)
                max_x = max(max_x, px)
                max_y = max(max_y, py)
        else:
            min_x = min(min_x, ex)
            min_y = min(min_y, ey)
            max_x = max(max_x, ex + ew)
            max_y = max(max_y, ey + eh)

    vw = max_x - min_x + 2 * padding
    vh = max_y - min_y + 2 * padding
    svg_w = vw * scale
    svg_h = vh * scale

    svg = Element("svg", {
        "xmlns": _SVG_NS,
        "width": str(int(svg_w)),
        "height": str(int(svg_h)),
        "viewBox": f"{min_x - padding} {min_y - padding} {vw} {vh}",
    })

    # Background
    bg_color = scene.app_state.get("viewBackgroundColor", "#ffffff")
    SubElement(svg, "rect", {
        "x": str(min_x - padding),
        "y": str(min_y - padding),
        "width": str(vw),
        "height": str(vh),
        "fill": bg_color,
    })

    # Defs for patterns
    defs = SubElement(svg, "defs")
    pattern_counter = [0]

    # Render elements in order (back to front)
    for elem in elements:
        if elem.get("isDeleted"):
            continue
        etype = elem.get("type", "")

        if etype == "rectangle":
            _render_rectangle(elem, svg, defs, pattern_counter)
        elif etype == "ellipse":
            _render_ellipse(elem, svg, defs, pattern_counter)
        elif etype == "diamond":
            _render_diamond(elem, svg, defs, pattern_counter)
        elif etype == "text":
            _render_text(elem, svg)
        elif etype == "arrow":
            _render_arrow(elem, svg)
        elif etype == "line":
            _render_line(elem, svg)
        elif etype == "freedraw":
            _render_freedraw(elem, svg)
        # frame, image: skip (no rendering without actual image data)

    xml_bytes = tostring(svg, encoding="unicode")
    return f'<?xml version="1.0" encoding="UTF-8"?>\n{xml_bytes}'


# ---------------------------------------------------------------------------
# High-level export functions
# ---------------------------------------------------------------------------

def export_svg(scene: Scene, path: str | Path, **kwargs: Any) -> Path:
    """Export scene to SVG file."""
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    svg_str = scene_to_svg(scene, **kwargs)
    path.write_text(svg_str, encoding="utf-8")
    return path


def export_png(
    scene: Scene,
    path: str | Path,
    *,
    scale: float = 2.0,
    **kwargs: Any,
) -> Path:
    """Export scene to PNG file.

    Requires: ``pip install cairosvg``
    """
    try:
        import cairosvg
    except ImportError:
        raise ImportError(
            "PNG export requires cairosvg. Install it with: pip install cairosvg"
        )
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    svg_str = scene_to_svg(scene, scale=scale, **kwargs)
    cairosvg.svg2png(bytestring=svg_str.encode("utf-8"), write_to=str(path))
    return path


def export_jpg(
    scene: Scene,
    path: str | Path,
    *,
    scale: float = 2.0,
    quality: int = 95,
    **kwargs: Any,
) -> Path:
    """Export scene to JPG file.

    Requires: ``pip install cairosvg Pillow``
    """
    try:
        import cairosvg
    except ImportError:
        raise ImportError(
            "JPG export requires cairosvg. Install it with: pip install cairosvg"
        )
    try:
        from PIL import Image
    except ImportError:
        raise ImportError(
            "JPG export requires Pillow. Install it with: pip install Pillow"
        )
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)

    svg_str = scene_to_svg(scene, scale=scale, **kwargs)
    png_bytes = cairosvg.svg2png(bytestring=svg_str.encode("utf-8"))
    img = Image.open(io.BytesIO(png_bytes))
    # Convert RGBA to RGB (JPG doesn't support alpha)
    if img.mode in ("RGBA", "LA"):
        bg = Image.new("RGB", img.size, (255, 255, 255))
        bg.paste(img, mask=img.split()[-1])
        img = bg
    elif img.mode != "RGB":
        img = img.convert("RGB")
    img.save(str(path), "JPEG", quality=quality)
    return path


def export_pdf(
    scene: Scene,
    path: str | Path,
    *,
    scale: float = 1.0,
    **kwargs: Any,
) -> Path:
    """Export scene to PDF file.

    Requires: ``pip install cairosvg``
    """
    try:
        import cairosvg
    except ImportError:
        raise ImportError(
            "PDF export requires cairosvg. Install it with: pip install cairosvg"
        )
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    svg_str = scene_to_svg(scene, scale=scale, **kwargs)
    cairosvg.svg2pdf(bytestring=svg_str.encode("utf-8"), write_to=str(path))
    return path
