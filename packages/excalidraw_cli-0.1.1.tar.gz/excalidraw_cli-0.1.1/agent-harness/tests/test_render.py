"""Tests for the SVG renderer and image export (PNG, JPG, PDF)."""

import json
from pathlib import Path

import pytest

from cli_anything.excalidraw.core import Scene, create_element
from cli_anything.excalidraw.render import (
    scene_to_svg,
    export_svg,
    export_png,
    export_jpg,
    export_pdf,
)


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------

@pytest.fixture
def simple_scene():
    """Scene with one of each common element type."""
    s = Scene()
    s.set_background("#fafafa")
    s.add_shape("rectangle", x=50, y=50, width=200, height=100, label="Box")
    s.add_shape("ellipse", x=300, y=50, width=150, height=80)
    s.add_shape("diamond", x=500, y=50, width=120, height=120, label="Decision")
    s.add_text("Hello World", x=100, y=200, font_size=24)
    s.add_arrow(x=150, y=150, width=200, height=50)
    s.add_line(x=50, y=300, points=[[0, 0], [100, 0], [200, 50]])
    return s


@pytest.fixture
def styled_scene():
    """Scene with various fill styles and colors."""
    s = Scene()
    s.add_shape("rectangle", x=0, y=0, width=100, height=50,
                backgroundColor="#ff6b6b", fillStyle="solid")
    s.add_shape("rectangle", x=120, y=0, width=100, height=50,
                backgroundColor="#51cf66", fillStyle="hachure")
    s.add_shape("rectangle", x=240, y=0, width=100, height=50,
                backgroundColor="#339af0", fillStyle="cross-hatch")
    s.add_shape("ellipse", x=0, y=80, width=100, height=50,
                strokeColor="#e64980", strokeWidth=4, opacity=60)
    return s


@pytest.fixture
def empty_scene():
    return Scene()


# ---------------------------------------------------------------------------
# SVG generation
# ---------------------------------------------------------------------------

class TestSceneToSvg:
    def test_returns_valid_svg(self, simple_scene):
        svg = scene_to_svg(simple_scene)
        assert svg.startswith('<?xml version="1.0"')
        assert "<svg" in svg
        assert "</svg>" in svg
        assert 'xmlns="http://www.w3.org/2000/svg"' in svg

    def test_empty_scene(self, empty_scene):
        svg = scene_to_svg(empty_scene)
        assert "<svg" in svg
        assert "</svg>" in svg

    def test_contains_background(self, simple_scene):
        svg = scene_to_svg(simple_scene)
        assert "#fafafa" in svg

    def test_contains_rectangle(self, simple_scene):
        svg = scene_to_svg(simple_scene)
        assert "<rect" in svg

    def test_contains_ellipse(self, simple_scene):
        svg = scene_to_svg(simple_scene)
        assert "<ellipse" in svg

    def test_contains_diamond_polygon(self, simple_scene):
        svg = scene_to_svg(simple_scene)
        assert "<polygon" in svg

    def test_contains_text(self, simple_scene):
        svg = scene_to_svg(simple_scene)
        assert "Hello World" in svg

    def test_contains_arrow_polyline(self, simple_scene):
        svg = scene_to_svg(simple_scene)
        assert "<polyline" in svg

    def test_scale_affects_dimensions(self, simple_scene):
        svg_1x = scene_to_svg(simple_scene, scale=1.0)
        svg_2x = scene_to_svg(simple_scene, scale=2.0)
        # 2x should have larger width/height attributes
        def get_width(svg_str):
            import re
            m = re.search(r'width="(\d+)"', svg_str)
            return int(m.group(1)) if m else 0
        assert get_width(svg_2x) > get_width(svg_1x)

    def test_padding_affects_viewbox(self, simple_scene):
        svg_small = scene_to_svg(simple_scene, padding=10)
        svg_large = scene_to_svg(simple_scene, padding=100)
        assert len(svg_small) != len(svg_large)

    def test_hachure_fill_creates_pattern(self, styled_scene):
        svg = scene_to_svg(styled_scene)
        assert "<pattern" in svg

    def test_crosshatch_fill_creates_pattern(self, styled_scene):
        svg = scene_to_svg(styled_scene)
        # Cross-hatch generates patterns with two lines
        assert "url(#pat" in svg

    def test_solid_fill_no_pattern(self):
        s = Scene()
        s.add_shape("rectangle", x=0, y=0, width=100, height=50,
                    backgroundColor="#ff0000", fillStyle="solid")
        svg = scene_to_svg(s)
        assert "#ff0000" in svg

    def test_opacity(self, styled_scene):
        svg = scene_to_svg(styled_scene)
        assert 'opacity="0.60"' in svg

    def test_dashed_stroke(self):
        s = Scene()
        s.add_line(x=0, y=0, points=[[0, 0], [100, 0]])
        # Manually set dashed
        for e in s.elements:
            e["strokeStyle"] = "dashed"
        svg = scene_to_svg(s)
        assert "stroke-dasharray" in svg

    def test_text_with_multiline(self):
        s = Scene()
        elem = create_element("text", label="Line1\nLine2\nLine3")
        s.add_element(elem)
        svg = scene_to_svg(s)
        assert "<tspan" in svg
        assert "Line1" in svg
        assert "Line3" in svg

    def test_arrow_with_arrowhead(self):
        s = Scene()
        s.add_arrow(x=0, y=0, width=200, height=0)
        svg = scene_to_svg(s)
        # Should have a polygon for the arrowhead
        assert "<polygon" in svg

    def test_freedraw_element(self):
        s = Scene()
        elem = create_element("freedraw", points=[[0, 0], [10, 5], [20, 0]])
        s.add_element(elem)
        svg = scene_to_svg(s)
        assert "<path" in svg

    def test_deleted_elements_skipped(self):
        s = Scene()
        elem = create_element("rectangle", x=0, y=0, width=100, height=50)
        elem["isDeleted"] = True
        s.add_element(elem)
        s.add_shape("ellipse", x=0, y=0, width=50, height=50)
        svg = scene_to_svg(s)
        assert "<rect" not in svg or 'fill="#' in svg  # only bg rect


# ---------------------------------------------------------------------------
# SVG file export
# ---------------------------------------------------------------------------

class TestExportSvg:
    def test_creates_file(self, simple_scene, tmp_path):
        path = export_svg(simple_scene, tmp_path / "test.svg")
        assert path.exists()
        content = path.read_text()
        assert "<svg" in content

    def test_creates_parent_dirs(self, simple_scene, tmp_path):
        path = export_svg(simple_scene, tmp_path / "sub" / "dir" / "test.svg")
        assert path.exists()


# ---------------------------------------------------------------------------
# PNG export
# ---------------------------------------------------------------------------

class TestExportPng:
    def test_creates_file(self, simple_scene, tmp_path):
        path = export_png(simple_scene, tmp_path / "test.png")
        assert path.exists()
        assert path.stat().st_size > 0

    def test_png_magic_bytes(self, simple_scene, tmp_path):
        path = export_png(simple_scene, tmp_path / "test.png")
        data = path.read_bytes()
        # PNG magic: 89 50 4E 47
        assert data[:4] == b"\x89PNG"

    def test_scale_affects_size(self, simple_scene, tmp_path):
        p1 = export_png(simple_scene, tmp_path / "1x.png", scale=1.0)
        p2 = export_png(simple_scene, tmp_path / "2x.png", scale=2.0)
        # 2x should be larger file
        assert p2.stat().st_size > p1.stat().st_size

    def test_high_dpi_default(self, simple_scene, tmp_path):
        """Default scale=2.0 should produce high-res output."""
        path = export_png(simple_scene, tmp_path / "hd.png")
        from PIL import Image
        img = Image.open(path)
        # With scale=2.0, dimensions should be larger than the scene
        assert img.width > 100
        assert img.height > 100


# ---------------------------------------------------------------------------
# JPG export
# ---------------------------------------------------------------------------

class TestExportJpg:
    def test_creates_file(self, simple_scene, tmp_path):
        path = export_jpg(simple_scene, tmp_path / "test.jpg")
        assert path.exists()
        assert path.stat().st_size > 0

    def test_jpg_magic_bytes(self, simple_scene, tmp_path):
        path = export_jpg(simple_scene, tmp_path / "test.jpg")
        data = path.read_bytes()
        # JPEG magic: FF D8 FF
        assert data[:3] == b"\xff\xd8\xff"

    def test_quality_affects_size(self, simple_scene, tmp_path):
        p_low = export_jpg(simple_scene, tmp_path / "low.jpg", quality=10)
        p_high = export_jpg(simple_scene, tmp_path / "high.jpg", quality=95)
        assert p_high.stat().st_size > p_low.stat().st_size

    def test_rgb_mode(self, simple_scene, tmp_path):
        """JPG should be RGB (no alpha channel)."""
        path = export_jpg(simple_scene, tmp_path / "test.jpg")
        from PIL import Image
        img = Image.open(path)
        assert img.mode == "RGB"


# ---------------------------------------------------------------------------
# PDF export
# ---------------------------------------------------------------------------

class TestExportPdf:
    def test_creates_file(self, simple_scene, tmp_path):
        path = export_pdf(simple_scene, tmp_path / "test.pdf")
        assert path.exists()
        assert path.stat().st_size > 0

    def test_pdf_magic_bytes(self, simple_scene, tmp_path):
        path = export_pdf(simple_scene, tmp_path / "test.pdf")
        data = path.read_bytes()
        # PDF magic: %PDF
        assert data[:4] == b"%PDF"

    def test_pdf_with_styled_elements(self, styled_scene, tmp_path):
        path = export_pdf(styled_scene, tmp_path / "styled.pdf")
        assert path.exists()
        assert path.stat().st_size > 0


# ---------------------------------------------------------------------------
# CLI export commands (E2E)
# ---------------------------------------------------------------------------

from click.testing import CliRunner
from cli_anything.excalidraw.cli import cli, _session


@pytest.fixture(autouse=True)
def reset_cli_session():
    _session["scene"] = None
    _session["path"] = None
    yield
    _session["scene"] = None
    _session["path"] = None


class TestExportCli:
    @pytest.fixture
    def runner(self):
        return CliRunner()

    def _setup_scene(self, runner):
        runner.invoke(cli, ["scene", "new"])
        runner.invoke(cli, ["element", "add", "rectangle", "--x", "10", "--y", "10",
                            "-w", "100", "-h", "50"])

    def test_export_svg_cli(self, runner, tmp_path):
        self._setup_scene(runner)
        outfile = str(tmp_path / "out.svg")
        result = runner.invoke(cli, ["--json", "export", "svg", outfile])
        assert result.exit_code == 0
        data = json.loads(result.output)
        assert data["format"] == "svg"
        assert Path(outfile).exists()

    def test_export_png_cli(self, runner, tmp_path):
        self._setup_scene(runner)
        outfile = str(tmp_path / "out.png")
        result = runner.invoke(cli, ["--json", "export", "png", outfile])
        assert result.exit_code == 0
        data = json.loads(result.output)
        assert data["format"] == "png"
        assert data["scale"] == 2.0
        assert Path(outfile).exists()

    def test_export_png_custom_scale(self, runner, tmp_path):
        self._setup_scene(runner)
        outfile = str(tmp_path / "out.png")
        result = runner.invoke(cli, ["--json", "export", "png", outfile, "--scale", "4.0"])
        assert result.exit_code == 0
        data = json.loads(result.output)
        assert data["scale"] == 4.0

    def test_export_jpg_cli(self, runner, tmp_path):
        self._setup_scene(runner)
        outfile = str(tmp_path / "out.jpg")
        result = runner.invoke(cli, ["--json", "export", "jpg", outfile])
        assert result.exit_code == 0
        data = json.loads(result.output)
        assert data["format"] == "jpg"
        assert Path(outfile).exists()

    def test_export_jpg_custom_quality(self, runner, tmp_path):
        self._setup_scene(runner)
        outfile = str(tmp_path / "out.jpg")
        result = runner.invoke(cli, ["--json", "export", "jpg", outfile, "--quality", "50"])
        assert result.exit_code == 0
        data = json.loads(result.output)
        assert data["quality"] == 50

    def test_export_pdf_cli(self, runner, tmp_path):
        self._setup_scene(runner)
        outfile = str(tmp_path / "out.pdf")
        result = runner.invoke(cli, ["--json", "export", "pdf", outfile])
        assert result.exit_code == 0
        data = json.loads(result.output)
        assert data["format"] == "pdf"
        assert Path(outfile).exists()

    def test_export_no_scene_error(self, runner, tmp_path):
        result = runner.invoke(cli, ["export", "svg", str(tmp_path / "x.svg")])
        assert result.exit_code != 0

    def _make_input_file(self, tmp_path):
        """Create a .excalidraw file on disk for --input testing."""
        from cli_anything.excalidraw.core import Scene as _Scene
        s = _Scene()
        s.add_shape("rectangle", x=10, y=10, width=100, height=50)
        infile = tmp_path / "input.excalidraw"
        s.save(infile)
        return str(infile)

    def test_export_svg_with_input(self, runner, tmp_path):
        infile = self._make_input_file(tmp_path)
        outfile = str(tmp_path / "out.svg")
        result = runner.invoke(cli, ["--json", "export", "svg", outfile, "-i", infile])
        assert result.exit_code == 0
        assert Path(outfile).exists()

    def test_export_png_with_input(self, runner, tmp_path):
        infile = self._make_input_file(tmp_path)
        outfile = str(tmp_path / "out.png")
        result = runner.invoke(cli, ["--json", "export", "png", outfile, "-i", infile])
        assert result.exit_code == 0
        assert Path(outfile).read_bytes()[:4] == b"\x89PNG"

    def test_export_jpg_with_input(self, runner, tmp_path):
        infile = self._make_input_file(tmp_path)
        outfile = str(tmp_path / "out.jpg")
        result = runner.invoke(cli, ["--json", "export", "jpg", outfile, "-i", infile])
        assert result.exit_code == 0
        assert Path(outfile).read_bytes()[:3] == b"\xff\xd8\xff"

    def test_export_pdf_with_input(self, runner, tmp_path):
        infile = self._make_input_file(tmp_path)
        outfile = str(tmp_path / "out.pdf")
        result = runner.invoke(cli, ["--json", "export", "pdf", outfile, "-i", infile])
        assert result.exit_code == 0
        assert Path(outfile).read_bytes()[:4] == b"%PDF"
