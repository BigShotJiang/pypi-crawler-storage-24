"""Tests for color presets module."""

import json
import pytest
from pathlib import Path

from cli_anything.excalidraw.presets import (
    BUILTIN_PRESETS,
    list_presets,
    get_preset,
    create_preset,
    delete_preset,
    apply_preset,
    _CONFIG_DIR,
)


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------

@pytest.fixture(autouse=True)
def clean_user_presets(tmp_path, monkeypatch):
    """Redirect preset storage to a temp directory."""
    import cli_anything.excalidraw.presets as mod
    monkeypatch.setattr(mod, "_CONFIG_DIR", tmp_path / "presets")
    yield


# ---------------------------------------------------------------------------
# Built-in presets
# ---------------------------------------------------------------------------

class TestBuiltinPresets:
    def test_has_12_builtins(self):
        assert len(BUILTIN_PRESETS) == 12

    def test_blueprint_preset(self):
        p = BUILTIN_PRESETS["blueprint"]
        assert p["strokeColor"] == "#1971c2"
        assert p["backgroundColor"] == "#a5d8ff"
        assert p["fillStyle"] == "solid"

    def test_dark_preset(self):
        p = BUILTIN_PRESETS["dark"]
        assert p["strokeColor"] == "#e9ecef"
        assert p["backgroundColor"] == "#343a40"

    def test_neon_preset(self):
        p = BUILTIN_PRESETS["neon"]
        assert p["strokeColor"] == "#00ff88"
        assert p["roughness"] == 0

    def test_sketch_preset(self):
        p = BUILTIN_PRESETS["sketch"]
        assert p["fillStyle"] == "hachure"
        assert p["roughness"] == 2

    def test_bold_preset(self):
        p = BUILTIN_PRESETS["bold"]
        assert p["strokeWidth"] == 4

    def test_minimal_preset(self):
        p = BUILTIN_PRESETS["minimal"]
        assert p["strokeWidth"] == 1
        assert p["backgroundColor"] == "transparent"

    def test_all_pastel_presets_exist(self):
        pastels = ["pastel-pink", "pastel-green", "pastel-blue",
                    "pastel-yellow", "pastel-purple", "pastel-orange"]
        for name in pastels:
            assert name in BUILTIN_PRESETS

    def test_all_builtins_have_required_keys(self):
        required = {"strokeColor", "backgroundColor", "fillStyle", "strokeWidth", "roughness"}
        for name, preset in BUILTIN_PRESETS.items():
            assert required.issubset(preset.keys()), f"Preset {name!r} missing keys"


# ---------------------------------------------------------------------------
# get_preset
# ---------------------------------------------------------------------------

class TestGetPreset:
    def test_get_builtin(self):
        p = get_preset("blueprint")
        assert p is not None
        assert p["strokeColor"] == "#1971c2"

    def test_get_nonexistent(self):
        assert get_preset("nonexistent") is None

    def test_get_returns_copy(self):
        p1 = get_preset("blueprint")
        p2 = get_preset("blueprint")
        p1["strokeColor"] = "modified"
        assert p2["strokeColor"] == "#1971c2"


# ---------------------------------------------------------------------------
# User-defined presets (create / delete / list)
# ---------------------------------------------------------------------------

class TestUserPresets:
    def test_create_and_get(self):
        props = {"strokeColor": "#ff0000", "backgroundColor": "#00ff00",
                 "fillStyle": "solid", "strokeWidth": 3, "roughness": 0}
        create_preset("my-preset", props)
        p = get_preset("my-preset")
        assert p is not None
        assert p["strokeColor"] == "#ff0000"

    def test_create_builtin_name_raises(self):
        with pytest.raises(ValueError, match="built-in"):
            create_preset("blueprint", {})

    def test_delete_user_preset(self):
        create_preset("temp", {"strokeColor": "#000"})
        assert get_preset("temp") is not None
        assert delete_preset("temp") is True
        assert get_preset("temp") is None

    def test_delete_nonexistent(self):
        assert delete_preset("nope") is False

    def test_delete_builtin_raises(self):
        with pytest.raises(ValueError, match="built-in"):
            delete_preset("blueprint")

    def test_list_includes_builtins_and_user(self):
        create_preset("custom1", {"strokeColor": "#abc"})
        all_presets = list_presets()
        assert "blueprint" in all_presets
        assert "custom1" in all_presets
        assert len(all_presets) >= 13


# ---------------------------------------------------------------------------
# apply_preset
# ---------------------------------------------------------------------------

class TestApplyPreset:
    def test_apply_returns_preset_values(self):
        result = apply_preset("blueprint", {})
        assert result["strokeColor"] == "#1971c2"
        assert result["backgroundColor"] == "#a5d8ff"

    def test_overrides_take_precedence(self):
        result = apply_preset("blueprint", {"strokeColor": "#ff0000"})
        assert result["strokeColor"] == "#ff0000"
        assert result["backgroundColor"] == "#a5d8ff"

    def test_apply_unknown_raises(self):
        with pytest.raises(ValueError, match="Unknown preset"):
            apply_preset("nonexistent", {})
