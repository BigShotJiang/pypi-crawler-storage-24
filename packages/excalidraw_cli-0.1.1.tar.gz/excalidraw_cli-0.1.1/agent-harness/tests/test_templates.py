"""Unit tests for diagram templates."""

import json
import pytest

from cli_anything.excalidraw.templates import (
    flowchart,
    sequence_diagram,
    er_diagram,
    mindmap,
    kanban_board,
)


class TestFlowchart:
    def test_basic_flowchart(self):
        s = flowchart(["Start", "Process", "End"])
        elems = s.list_elements()
        # 3 nodes (each with label = 6 elements) + 2 arrows = 8
        assert len(elems) >= 8

    def test_decision_diamond(self):
        s = flowchart(["Start", "?Decision", "End"])
        diamonds = s.list_elements("diamond")
        assert len(diamonds) == 1

    def test_horizontal_layout(self):
        s = flowchart(["A", "B", "C"], direction="horizontal")
        rects = s.list_elements("rectangle")
        xs = [r["x"] for r in rects]
        assert xs == sorted(xs)  # x values increase

    def test_single_step(self):
        s = flowchart(["Only"])
        arrows = s.list_elements("arrow")
        assert len(arrows) == 0

    def test_save_produces_valid_file(self, tmp_path):
        s = flowchart(["A", "B"])
        path = tmp_path / "flow.excalidraw"
        s.save(path)
        data = json.loads(path.read_text())
        assert data["type"] == "excalidraw"


class TestSequenceDiagram:
    def test_basic_sequence(self):
        s = sequence_diagram(
            ["Client", "Server"],
            [(0, 1, "Request"), (1, 0, "Response")],
        )
        actors = s.list_elements("rectangle")
        arrows = s.list_elements("arrow")
        assert len(actors) == 2
        assert len(arrows) == 2

    def test_lifelines_are_dashed(self):
        s = sequence_diagram(["A", "B"], [(0, 1, "msg")])
        lines = s.list_elements("line")
        assert all(l.get("strokeStyle") == "dashed" for l in lines)


class TestERDiagram:
    def test_basic_er(self):
        s = er_diagram(
            [{"name": "User", "fields": ["id", "name"]},
             {"name": "Post", "fields": ["id", "title"]}],
            [("User", "Post", "has many")],
        )
        rects = s.list_elements("rectangle")
        assert len(rects) >= 2
        arrows = s.list_elements("arrow")
        assert len(arrows) >= 1

    def test_no_relations(self):
        s = er_diagram(
            [{"name": "Standalone", "fields": ["id"]}],
            [],
        )
        arrows = s.list_elements("arrow")
        assert len(arrows) == 0


class TestMindmap:
    def test_basic_mindmap(self):
        s = mindmap("Root", {"A": ["a1", "a2"], "B": ["b1"]})
        ellipses = s.list_elements("ellipse")
        assert len(ellipses) == 1  # root
        rects = s.list_elements("rectangle")
        assert len(rects) >= 5  # 2 branches + 3 leaves (+ bound text)

    def test_empty_branches(self):
        s = mindmap("Root", {})
        assert len(s.list_elements("ellipse")) == 1


class TestKanban:
    def test_basic_kanban(self):
        s = kanban_board({"Todo": ["A", "B"], "Done": ["C"]})
        texts = s.list_elements("text")
        assert len(texts) >= 2  # column headers
        rects = s.list_elements("rectangle")
        assert len(rects) >= 5  # 2 col bg + 3 cards (+ labels)
