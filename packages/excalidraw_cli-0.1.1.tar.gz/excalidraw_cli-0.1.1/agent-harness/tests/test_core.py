"""Unit tests for excalidraw-cli core module."""

import json
import tempfile
from pathlib import Path

import pytest

from cli_anything.excalidraw.core import (
    Scene,
    create_element,
    ALL_TYPES,
    SHAPE_TYPES,
    LINEAR_TYPES,
)


# ---------------------------------------------------------------------------
# create_element
# ---------------------------------------------------------------------------

class TestCreateElement:
    def test_rectangle_has_required_fields(self):
        elem = create_element("rectangle", x=10, y=20, width=100, height=50)
        assert elem["type"] == "rectangle"
        assert elem["x"] == 10
        assert elem["y"] == 20
        assert elem["width"] == 100
        assert elem["height"] == 50
        assert "id" in elem
        assert elem["strokeColor"] == "#1e1e1e"

    def test_all_shape_types(self):
        for t in SHAPE_TYPES:
            elem = create_element(t)
            assert elem["type"] == t

    def test_text_element(self):
        elem = create_element("text", label="Hello")
        assert elem["type"] == "text"
        assert elem["text"] == "Hello"
        assert elem["fontSize"] == 20
        assert "roundness" not in elem

    def test_arrow_element(self):
        elem = create_element("arrow", x=0, y=0, width=200, height=100)
        assert elem["type"] == "arrow"
        assert elem["endArrowhead"] == "arrow"
        assert elem["points"] == [[0, 0], [200, 100]]

    def test_line_element(self):
        elem = create_element("line")
        assert elem["type"] == "line"
        assert len(elem["points"]) == 2

    def test_freedraw_element(self):
        elem = create_element("freedraw")
        assert elem["type"] == "freedraw"
        assert elem["simulatePressure"] is True
        assert "roundness" not in elem

    def test_shape_with_label_returns_tuple(self):
        result = create_element("rectangle", label="Box")
        assert isinstance(result, tuple)
        shape, text = result
        assert shape["type"] == "rectangle"
        assert text["type"] == "text"
        assert text["containerId"] == shape["id"]

    def test_unknown_type_raises(self):
        with pytest.raises(ValueError, match="Unknown element type"):
            create_element("hexagon")

    def test_overrides_applied(self):
        elem = create_element("ellipse", strokeColor="#ff0000", opacity=50)
        assert elem["strokeColor"] == "#ff0000"
        assert elem["opacity"] == 50

    def test_unique_ids(self):
        ids = {create_element("rectangle")["id"] for _ in range(100)}
        assert len(ids) == 100


# ---------------------------------------------------------------------------
# Scene
# ---------------------------------------------------------------------------

class TestScene:
    def test_new_scene_is_empty(self):
        s = Scene()
        assert len(s.elements) == 0
        assert s.app_state["viewBackgroundColor"] == "#ffffff"

    def test_add_element(self):
        s = Scene()
        elem = create_element("rectangle")
        eid = s.add_element(elem)
        assert len(s.elements) == 1
        assert s.elements[0]["id"] == eid

    def test_remove_element(self):
        s = Scene()
        elem = create_element("rectangle")
        eid = s.add_element(elem)
        removed = s.remove_element(eid)
        assert removed is not None
        assert len(s.elements) == 0

    def test_remove_nonexistent(self):
        s = Scene()
        assert s.remove_element("nonexistent") is None

    def test_get_element(self):
        s = Scene()
        elem = create_element("ellipse")
        s.add_element(elem)
        found = s.get_element(elem["id"])
        assert found is not None
        assert found["type"] == "ellipse"

    def test_update_element(self):
        s = Scene()
        elem = create_element("rectangle")
        s.add_element(elem)
        updated = s.update_element(elem["id"], strokeColor="#00ff00")
        assert updated["strokeColor"] == "#00ff00"

    def test_list_elements_filter(self):
        s = Scene()
        s.add_element(create_element("rectangle"))
        s.add_element(create_element("ellipse"))
        s.add_element(create_element("rectangle"))
        rects = s.list_elements("rectangle")
        assert len(rects) == 2

    def test_set_background(self):
        s = Scene()
        s.set_background("#000000")
        assert s.app_state["viewBackgroundColor"] == "#000000"

    def test_set_grid(self):
        s = Scene()
        s.set_grid(20)
        assert s.app_state["gridSize"] == 20

    def test_clear(self):
        s = Scene()
        s.add_element(create_element("rectangle"))
        s.add_element(create_element("text", label="hi"))
        s.clear()
        assert len(s.elements) == 0


class TestScenePersistence:
    def test_save_and_load(self, tmp_path):
        s = Scene()
        s.add_shape("rectangle", x=10, y=20, width=100, height=50)
        filepath = tmp_path / "test.excalidraw"
        s.save(filepath)
        assert filepath.exists()

        loaded = Scene.load(filepath)
        assert len(loaded.elements) == 1
        assert loaded.elements[0]["type"] == "rectangle"

    def test_load_validates_type(self, tmp_path):
        filepath = tmp_path / "bad.excalidraw"
        filepath.write_text(json.dumps({"type": "not-excalidraw"}))
        with pytest.raises(ValueError, match="Not a valid Excalidraw file"):
            Scene.load(filepath)

    def test_load_nonexistent(self):
        with pytest.raises(FileNotFoundError):
            Scene.load("/nonexistent/file.excalidraw")

    def test_saved_file_is_valid_json(self, tmp_path):
        s = Scene()
        s.add_shape("diamond", label="Test")
        filepath = tmp_path / "out.excalidraw"
        s.save(filepath)
        data = json.loads(filepath.read_text())
        assert data["type"] == "excalidraw"
        assert data["version"] == 2
        assert isinstance(data["elements"], list)


class TestSceneUndoRedo:
    def test_undo(self):
        s = Scene()
        s.add_element(create_element("rectangle"))
        assert len(s.elements) == 1
        s.undo()
        assert len(s.elements) == 0

    def test_redo(self):
        s = Scene()
        s.add_element(create_element("rectangle"))
        s.undo()
        s.redo()
        assert len(s.elements) == 1

    def test_undo_empty(self):
        s = Scene()
        assert s.undo() is False

    def test_redo_empty(self):
        s = Scene()
        assert s.redo() is False

    def test_undo_clears_redo_on_new_action(self):
        s = Scene()
        s.add_element(create_element("rectangle"))
        s.undo()
        s.add_element(create_element("ellipse"))
        assert s.redo() is False


class TestSceneHelpers:
    def test_add_shape(self):
        s = Scene()
        eid = s.add_shape("rectangle", x=0, y=0)
        assert s.get_element(eid)["type"] == "rectangle"

    def test_add_shape_with_label(self):
        s = Scene()
        eid = s.add_shape("rectangle", label="Hello")
        assert len(s.elements) == 2  # shape + text
        text_elems = s.list_elements("text")
        assert len(text_elems) == 1
        assert text_elems[0]["containerId"] == eid

    def test_add_text(self):
        s = Scene()
        eid = s.add_text("Hello World", x=50, y=50)
        elem = s.get_element(eid)
        assert elem["text"] == "Hello World"

    def test_add_arrow(self):
        s = Scene()
        eid = s.add_arrow(x=0, y=0, width=200)
        elem = s.get_element(eid)
        assert elem["type"] == "arrow"

    def test_add_line(self):
        s = Scene()
        eid = s.add_line(x=0, y=0)
        elem = s.get_element(eid)
        assert elem["type"] == "line"

    def test_connect(self):
        s = Scene()
        a = s.add_shape("rectangle", x=100, y=100, width=100, height=50)
        b = s.add_shape("rectangle", x=100, y=300, width=100, height=50)
        arrow_id = s.connect(a, b)
        assert arrow_id is not None
        arrow = s.get_element(arrow_id)
        assert arrow["type"] == "arrow"
        assert arrow["startBinding"]["elementId"] == a
        assert arrow["endBinding"]["elementId"] == b

    def test_connect_invalid(self):
        s = Scene()
        assert s.connect("fake1", "fake2") is None

    def test_summary(self):
        s = Scene()
        s.add_shape("rectangle")
        s.add_shape("ellipse")
        s.add_text("hi")
        info = s.summary()
        assert info["total_elements"] == 3
        assert info["element_types"]["rectangle"] == 1
        assert info["element_types"]["ellipse"] == 1
        assert info["element_types"]["text"] == 1
