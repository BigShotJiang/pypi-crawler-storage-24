"""End-to-end tests for the Click CLI."""

import json
from pathlib import Path

import pytest
from click.testing import CliRunner

from cli_anything.excalidraw.cli import cli, _session


@pytest.fixture(autouse=True)
def reset_session():
    """Reset session state between tests."""
    _session["scene"] = None
    _session["path"] = None
    yield
    _session["scene"] = None
    _session["path"] = None


@pytest.fixture
def runner():
    return CliRunner()


# ---------------------------------------------------------------------------
# Scene commands
# ---------------------------------------------------------------------------

class TestSceneCommands:
    def test_scene_new(self, runner):
        result = runner.invoke(cli, ["scene", "new"])
        assert result.exit_code == 0
        assert "created" in result.output

    def test_scene_new_json(self, runner):
        result = runner.invoke(cli, ["--json", "scene", "new"])
        assert result.exit_code == 0
        data = json.loads(result.output)
        assert data["status"] == "created"

    def test_scene_new_with_options(self, runner):
        result = runner.invoke(cli, ["--json", "scene", "new", "--background", "#000", "--grid", "20"])
        assert result.exit_code == 0
        data = json.loads(result.output)
        assert data["background"] == "#000"
        assert data["grid"] == 20

    def test_scene_save_and_load(self, runner, tmp_path):
        outfile = str(tmp_path / "test.excalidraw")
        runner.invoke(cli, ["scene", "new"])
        result = runner.invoke(cli, ["scene", "save", outfile])
        assert result.exit_code == 0
        assert Path(outfile).exists()

        _session["scene"] = None
        result = runner.invoke(cli, ["--json", "scene", "load", outfile])
        assert result.exit_code == 0
        data = json.loads(result.output)
        assert data["status"] == "loaded"

    def test_scene_info(self, runner):
        runner.invoke(cli, ["scene", "new"])
        result = runner.invoke(cli, ["--json", "scene", "info"])
        assert result.exit_code == 0
        data = json.loads(result.output)
        assert "total_elements" in data

    def test_scene_clear(self, runner):
        runner.invoke(cli, ["scene", "new"])
        runner.invoke(cli, ["element", "add", "rectangle"])
        result = runner.invoke(cli, ["scene", "clear"])
        assert result.exit_code == 0

    def test_scene_background(self, runner):
        runner.invoke(cli, ["scene", "new"])
        result = runner.invoke(cli, ["scene", "background", "#ff0000"])
        assert result.exit_code == 0

    def test_scene_undo_redo(self, runner):
        runner.invoke(cli, ["scene", "new"])
        runner.invoke(cli, ["element", "add", "rectangle"])
        result = runner.invoke(cli, ["--json", "scene", "undo"])
        data = json.loads(result.output)
        assert data["success"] is True

        result = runner.invoke(cli, ["--json", "scene", "redo"])
        data = json.loads(result.output)
        assert data["success"] is True

    def test_scene_no_scene_error(self, runner):
        result = runner.invoke(cli, ["scene", "info"])
        assert result.exit_code != 0


# ---------------------------------------------------------------------------
# Element commands
# ---------------------------------------------------------------------------

class TestElementCommands:
    def test_element_add(self, runner):
        runner.invoke(cli, ["scene", "new"])
        result = runner.invoke(cli, ["--json", "element", "add", "rectangle",
                                      "--x", "10", "--y", "20"])
        assert result.exit_code == 0
        data = json.loads(result.output)
        assert data["status"] == "added"
        assert data["type"] == "rectangle"

    def test_element_add_auto_creates_scene(self, runner):
        result = runner.invoke(cli, ["--json", "element", "add", "ellipse"])
        assert result.exit_code == 0

    def test_element_add_with_label(self, runner):
        runner.invoke(cli, ["scene", "new"])
        result = runner.invoke(cli, ["--json", "element", "add", "rectangle", "--label", "Box"])
        assert result.exit_code == 0

    def test_element_add_with_style(self, runner):
        runner.invoke(cli, ["scene", "new"])
        result = runner.invoke(cli, ["--json", "element", "add", "rectangle",
                                      "--stroke-color", "#ff0000",
                                      "--bg-color", "#00ff00",
                                      "--fill", "solid",
                                      "--opacity", "80"])
        assert result.exit_code == 0

    def test_element_list(self, runner):
        runner.invoke(cli, ["scene", "new"])
        runner.invoke(cli, ["element", "add", "rectangle"])
        runner.invoke(cli, ["element", "add", "ellipse"])
        result = runner.invoke(cli, ["--json", "element", "list"])
        assert result.exit_code == 0
        data = json.loads(result.output)
        assert len(data) == 2

    def test_element_list_with_filter(self, runner):
        runner.invoke(cli, ["scene", "new"])
        runner.invoke(cli, ["element", "add", "rectangle"])
        runner.invoke(cli, ["element", "add", "ellipse"])
        result = runner.invoke(cli, ["--json", "element", "list", "--type", "rectangle"])
        assert result.exit_code == 0
        data = json.loads(result.output)
        assert len(data) == 1

    def test_element_remove(self, runner):
        runner.invoke(cli, ["scene", "new"])
        add_result = runner.invoke(cli, ["--json", "element", "add", "rectangle"])
        eid = json.loads(add_result.output)["id"]
        result = runner.invoke(cli, ["--json", "element", "remove", eid])
        assert result.exit_code == 0
        assert json.loads(result.output)["status"] == "removed"

    def test_element_remove_not_found(self, runner):
        runner.invoke(cli, ["scene", "new"])
        result = runner.invoke(cli, ["element", "remove", "nonexistent"])
        assert result.exit_code != 0

    def test_element_update(self, runner):
        runner.invoke(cli, ["scene", "new"])
        add_result = runner.invoke(cli, ["--json", "element", "add", "rectangle"])
        eid = json.loads(add_result.output)["id"]
        result = runner.invoke(cli, ["--json", "element", "update", eid, "--x", "50"])
        assert result.exit_code == 0

    def test_element_connect(self, runner):
        runner.invoke(cli, ["scene", "new"])
        r1 = json.loads(runner.invoke(cli, ["--json", "element", "add", "rectangle",
                                             "--x", "0", "--y", "0"]).output)["id"]
        r2 = json.loads(runner.invoke(cli, ["--json", "element", "add", "rectangle",
                                             "--x", "0", "--y", "300"]).output)["id"]
        result = runner.invoke(cli, ["--json", "element", "connect", r1, r2])
        assert result.exit_code == 0
        data = json.loads(result.output)
        assert data["status"] == "connected"

    def test_element_invalid_type(self, runner):
        runner.invoke(cli, ["scene", "new"])
        result = runner.invoke(cli, ["element", "add", "hexagon"])
        assert result.exit_code != 0


# ---------------------------------------------------------------------------
# Template commands
# ---------------------------------------------------------------------------

class TestTemplateCommands:
    def test_flowchart(self, runner, tmp_path):
        outfile = str(tmp_path / "flow.excalidraw")
        result = runner.invoke(cli, ["--json", "template", "flowchart",
                                      "Start", "Process", "End", "-o", outfile])
        assert result.exit_code == 0
        data = json.loads(result.output)
        assert data["template"] == "flowchart"
        assert Path(outfile).exists()

    def test_flowchart_horizontal(self, runner):
        result = runner.invoke(cli, ["--json", "template", "flowchart",
                                      "A", "B", "-d", "horizontal"])
        assert result.exit_code == 0

    def test_sequence(self, runner, tmp_path):
        outfile = str(tmp_path / "seq.excalidraw")
        result = runner.invoke(cli, ["--json", "template", "sequence",
                                      "-a", "Client,Server",
                                      "-m", "0:1:Request",
                                      "-m", "1:0:Response",
                                      "-o", outfile])
        assert result.exit_code == 0
        assert Path(outfile).exists()

    def test_er(self, runner):
        result = runner.invoke(cli, ["--json", "template", "er",
                                      "-e", "User:id,name",
                                      "-e", "Post:id,title",
                                      "-r", "User:Post:has many"])
        assert result.exit_code == 0
        data = json.loads(result.output)
        assert data["template"] == "er"

    def test_mindmap(self, runner):
        result = runner.invoke(cli, ["--json", "template", "mindmap", "Root",
                                      "-b", "A:a1,a2", "-b", "B:b1"])
        assert result.exit_code == 0
        data = json.loads(result.output)
        assert data["template"] == "mindmap"

    def test_kanban(self, runner):
        result = runner.invoke(cli, ["--json", "template", "kanban",
                                      "-c", "Todo:A,B", "-c", "Done:C"])
        assert result.exit_code == 0
        data = json.loads(result.output)
        assert data["template"] == "kanban"


# ---------------------------------------------------------------------------
# Export commands
# ---------------------------------------------------------------------------

class TestExportCommands:
    def test_export_json_stdout(self, runner):
        runner.invoke(cli, ["scene", "new"])
        runner.invoke(cli, ["element", "add", "rectangle"])
        result = runner.invoke(cli, ["export", "json"])
        assert result.exit_code == 0
        data = json.loads(result.output)
        assert data["type"] == "excalidraw"

    def test_export_json_file(self, runner, tmp_path):
        runner.invoke(cli, ["scene", "new"])
        outfile = str(tmp_path / "out.json")
        result = runner.invoke(cli, ["--json", "export", "json", "-o", outfile])
        assert result.exit_code == 0
        assert Path(outfile).exists()

    def test_export_excalidraw(self, runner, tmp_path):
        runner.invoke(cli, ["scene", "new"])
        outfile = str(tmp_path / "out.excalidraw")
        result = runner.invoke(cli, ["--json", "export", "excalidraw", outfile])
        assert result.exit_code == 0
        data = json.loads(Path(outfile).read_text())
        assert data["type"] == "excalidraw"


# ---------------------------------------------------------------------------
# Version
# ---------------------------------------------------------------------------

class TestMisc:
    def test_version(self, runner):
        result = runner.invoke(cli, ["--version"])
        assert result.exit_code == 0
        assert "excalidraw-cli" in result.output
