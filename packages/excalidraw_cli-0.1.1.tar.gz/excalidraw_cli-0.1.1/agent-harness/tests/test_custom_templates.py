"""Tests for custom template management."""

import json
import pytest
from pathlib import Path

from cli_anything.excalidraw.custom_templates import (
    save_template,
    load_template,
    list_templates,
    delete_template,
    import_template,
    _TEMPLATE_DIR,
)
from cli_anything.excalidraw.core import Scene


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------

@pytest.fixture(autouse=True)
def clean_template_dir(tmp_path, monkeypatch):
    """Redirect template storage to a temp directory."""
    import cli_anything.excalidraw.custom_templates as mod
    monkeypatch.setattr(mod, "_TEMPLATE_DIR", tmp_path / "templates")
    yield


@pytest.fixture
def sample_scene_data():
    return {
        "type": "excalidraw",
        "version": 2,
        "source": "https://excalidraw.com",
        "elements": [
            {"id": "test1", "type": "rectangle", "x": 0, "y": 0,
             "width": 100, "height": 50}
        ],
        "appState": {"gridSize": None, "viewBackgroundColor": "#ffffff"},
        "files": {},
    }


# ---------------------------------------------------------------------------
# save / load
# ---------------------------------------------------------------------------

class TestSaveLoad:
    def test_save_and_load(self, sample_scene_data):
        save_template("my-template", sample_scene_data)
        loaded = load_template("my-template")
        assert loaded["type"] == "excalidraw"
        assert len(loaded["elements"]) == 1

    def test_load_nonexistent_raises(self):
        with pytest.raises(FileNotFoundError, match="not found"):
            load_template("nonexistent")

    def test_save_overwrites(self, sample_scene_data):
        save_template("overwrite", sample_scene_data)
        sample_scene_data["elements"].append(
            {"id": "test2", "type": "ellipse", "x": 0, "y": 0,
             "width": 50, "height": 50}
        )
        save_template("overwrite", sample_scene_data)
        loaded = load_template("overwrite")
        assert len(loaded["elements"]) == 2


# ---------------------------------------------------------------------------
# list
# ---------------------------------------------------------------------------

class TestListTemplates:
    def test_empty_list(self):
        assert list_templates() == []

    def test_list_after_save(self, sample_scene_data):
        save_template("tmpl-a", sample_scene_data)
        save_template("tmpl-b", sample_scene_data)
        templates = list_templates()
        names = [t["name"] for t in templates]
        assert "tmpl-a" in names
        assert "tmpl-b" in names
        assert len(templates) == 2

    def test_list_includes_element_count(self, sample_scene_data):
        save_template("counted", sample_scene_data)
        templates = list_templates()
        t = next(t for t in templates if t["name"] == "counted")
        assert t["elements"] == 1


# ---------------------------------------------------------------------------
# delete
# ---------------------------------------------------------------------------

class TestDeleteTemplate:
    def test_delete_existing(self, sample_scene_data):
        save_template("to-delete", sample_scene_data)
        assert delete_template("to-delete") is True
        assert list_templates() == []

    def test_delete_nonexistent(self):
        assert delete_template("nope") is False


# ---------------------------------------------------------------------------
# import
# ---------------------------------------------------------------------------

class TestImportTemplate:
    def test_import_valid_file(self, tmp_path, sample_scene_data):
        source = tmp_path / "source.excalidraw"
        source.write_text(json.dumps(sample_scene_data))
        path = import_template("imported", str(source))
        assert path.exists()
        loaded = load_template("imported")
        assert loaded["type"] == "excalidraw"

    def test_import_nonexistent_raises(self):
        with pytest.raises(FileNotFoundError):
            import_template("bad", "/nonexistent/file.excalidraw")

    def test_import_invalid_json_raises(self, tmp_path):
        source = tmp_path / "bad.excalidraw"
        source.write_text(json.dumps({"not": "excalidraw"}))
        with pytest.raises(ValueError, match="Not a valid"):
            import_template("bad", str(source))
