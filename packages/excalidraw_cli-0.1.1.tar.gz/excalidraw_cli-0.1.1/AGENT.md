# Excalidraw CLI — AI Agent Guide

This guide teaches AI agents (Claude Code, GitHub Copilot, etc.) how to use
`excalidraw-cli` to create and manipulate Excalidraw diagrams programmatically.

## Quick Start

Always use `--json` for machine-readable output:

```bash
# Create a scene, add elements, save
excalidraw-cli --json scene new
excalidraw-cli --json element add rectangle --x 100 --y 100 -w 200 -h 80 -l "My Box"
excalidraw-cli --json scene save diagram.excalidraw
```

## Key Concepts

- **Session state**: The CLI keeps an in-memory scene between commands in the
  same process (REPL mode). For separate CLI invocations, use templates with
  `-o` to save directly, or use the Python API.
- **Element IDs**: Every `element add` returns an `id` in JSON. Track these IDs
  to connect elements or update them later.
- **Templates**: Use built-in templates (flowchart, sequence, er, mindmap,
  kanban) to avoid manual coordinate math.

## Command Reference

### Scene Management

```bash
excalidraw-cli --json scene new [--background COLOR] [--grid SIZE]
excalidraw-cli --json scene load FILE
excalidraw-cli --json scene save [FILE]
excalidraw-cli --json scene info
excalidraw-cli --json scene clear
excalidraw-cli --json scene background COLOR
excalidraw-cli --json scene undo
excalidraw-cli --json scene redo
```

### Element Operations

```bash
# Add element — types: rectangle, ellipse, diamond, arrow, line, text, freedraw, image, frame
excalidraw-cli --json element add TYPE [--x N] [--y N] [-w N] [-h N] [-l "Label"] \
  [--stroke-color "#hex"] [--bg-color "#hex"] [--fill solid|hachure|cross-hatch] \
  [--stroke-width N] [--roughness 0|1|2] [--opacity 0-100] [--preset NAME]

# List, remove, update, connect
excalidraw-cli --json element list [--type TYPE]
excalidraw-cli --json element remove ELEMENT_ID
excalidraw-cli --json element update ELEMENT_ID [--x N] [--y N] [--width N] [--height N] \
  [--stroke-color "#hex"] [--bg-color "#hex"] [--opacity N]
excalidraw-cli --json element connect FROM_ID TO_ID [--label "text"]
```

### Templates (Recommended for Agents)

Templates handle layout automatically — no manual x/y coordinates needed:

```bash
# Flowchart — prefix step with ? for decision diamond
excalidraw-cli --json template flowchart "Step 1" "?Decision?" "Step 2" "End" \
  [-d vertical|horizontal] [-o output.excalidraw]

# Sequence diagram
excalidraw-cli --json template sequence \
  -a "Actor1,Actor2,Actor3" \
  -m "0:1:Message" -m "1:2:Request" -m "2:1:Response" \
  [-o output.excalidraw]

# Entity-relationship diagram
excalidraw-cli --json template er \
  -e "User:id,name,email" -e "Post:id,title,body" \
  -r "User:Post:has many" \
  [-o output.excalidraw]

# Mind map
excalidraw-cli --json template mindmap "Root Topic" \
  -b "Branch1:leaf1,leaf2" -b "Branch2:leaf3,leaf4" \
  [-o output.excalidraw]

# Kanban board
excalidraw-cli --json template kanban \
  -c "Todo:task1,task2" -c "In Progress:task3" -c "Done:task4" \
  [-o output.excalidraw]
```

### Color Presets

12 built-in presets for consistent styling:

| Preset | Stroke | Background | Style |
|--------|--------|------------|-------|
| `blueprint` | #1971c2 | #a5d8ff | Solid, sharp |
| `dark` | #e9ecef | #343a40 | Solid, sharp |
| `neon` | #00ff88 | #1a1a2e | Solid, bold |
| `sketch` | #1e1e1e | transparent | Hachure, rough |
| `bold` | #000000 | #ffc078 | Solid, thick |
| `minimal` | #868e96 | transparent | Solid, thin |
| `pastel-pink` | #c2255c | #fcc2d7 | Solid |
| `pastel-green` | #2f9e44 | #b2f2bb | Solid |
| `pastel-blue` | #1971c2 | #d0ebff | Solid |
| `pastel-yellow` | #e67700 | #ffec99 | Solid |
| `pastel-purple` | #7048e8 | #d0bfff | Solid |
| `pastel-orange` | #d9480f | #ffd8a8 | Solid |

```bash
# Apply preset when adding elements
excalidraw-cli --json element add rectangle -l "Server" --preset blueprint

# Manage presets
excalidraw-cli --json preset list
excalidraw-cli --json preset show blueprint
excalidraw-cli --json preset create my-style --stroke-color "#ff0000" --bg-color "#ffe0e0"
excalidraw-cli --json preset delete my-style
```

### Export

```bash
excalidraw-cli --json export json [-o FILE] [--pretty/--compact]
excalidraw-cli --json export excalidraw FILE
excalidraw-cli --json export svg FILE [--scale N] [--padding N]
excalidraw-cli --json export png FILE [--scale N] [--padding N]   # requires cairosvg
excalidraw-cli --json export jpg FILE [--scale N] [--quality N]   # requires cairosvg + Pillow
excalidraw-cli --json export pdf FILE [--scale N] [--padding N]   # requires cairosvg

# All export commands accept --input/-i to skip loading:
excalidraw-cli --json export svg output.svg -i diagram.excalidraw
```

### Custom Templates

```bash
excalidraw-cli --json custom-template save NAME       # save current scene as template
excalidraw-cli --json custom-template load NAME       # load template into session
excalidraw-cli --json custom-template list
excalidraw-cli --json custom-template delete NAME
excalidraw-cli --json custom-template import NAME FILE  # import .excalidraw as template
```

## JSON Response Format

### Success responses

All successful commands return JSON with a `"status"` field:

```json
{"status": "created", "background": "#ffffff", "grid": null}
{"status": "added", "id": "abc123def456", "type": "rectangle"}
{"status": "connected", "arrow_id": "xyz789", "from": "id1", "to": "id2"}
{"status": "exported", "format": "svg", "file": "output.svg"}
```

### Error responses

When `--json` is set, errors return structured JSON to stderr:

```json
{"status": "error", "code": "NO_SCENE", "message": "No scene loaded. Use `scene new` or `scene load <file>` first."}
{"status": "error", "code": "ELEMENT_NOT_FOUND", "message": "Element not found: abc123"}
{"status": "error", "code": "INVALID_PRESET", "message": "Unknown preset: 'nonexistent'"}
```

Error codes: `NO_SCENE`, `NO_PATH`, `ELEMENT_NOT_FOUND`, `NO_PROPERTIES`,
`INVALID_PRESET`, `PRESET_NOT_FOUND`, `TEMPLATE_NOT_FOUND`, `INVALID_FORMAT`,
`IMPORT_FAILED`, `MISSING_DEPENDENCY`.

## Python API (Recommended for Complex Diagrams)

For multi-step diagrams, the Python API avoids subprocess overhead and session
state issues:

```python
from cli_anything.excalidraw.core import Scene
from cli_anything.excalidraw.templates import flowchart, sequence_diagram, er_diagram, mindmap, kanban_board
from cli_anything.excalidraw.presets import get_preset, apply_preset

# Using templates
scene = flowchart(["Start", "?Valid?", "Process", "End"])
scene.save("flow.excalidraw")

# Building custom diagrams
scene = Scene()
scene.set_background("#1e1e2e")

api = scene.add_shape("rectangle", x=200, y=50, width=200, height=70,
                       label="API Server", backgroundColor="#a6e3a1", fillStyle="solid")
db = scene.add_shape("rectangle", x=200, y=200, width=200, height=70,
                      label="Database", backgroundColor="#f9e2af", fillStyle="solid")
scene.connect(api, db)
scene.save("architecture.excalidraw")

# Using presets
preset = get_preset("blueprint")
scene.add_shape("rectangle", x=0, y=0, width=200, height=80, label="Box", **preset)
```

## Translating Natural Language to Commands

When a user describes a diagram in plain language, follow this decision tree:

### 1. Identify the diagram type

| User says | Use template |
|-----------|-------------|
| "flowchart", "process", "workflow", "steps" | `template flowchart` |
| "sequence", "interaction", "API flow", "request/response" | `template sequence` |
| "ER diagram", "database schema", "entities", "tables" | `template er` |
| "mind map", "brainstorm", "hierarchy", "breakdown" | `template mindmap` |
| "kanban", "board", "sprint", "tasks", "columns" | `template kanban` |
| "architecture", "system design", custom layout | Python API |

### 2. Extract components from the description

**Flowchart**: Look for sequential steps and decision points (if/then → use `?` prefix).

```
User: "Draw a CI/CD pipeline: push code, run tests, if tests pass deploy, otherwise fix"
Agent: excalidraw-cli --json template flowchart "Push Code" "Run Tests" "?Tests Pass?" "Deploy" "Fix & Retry" -o pipeline.excalidraw
```

**Sequence diagram**: Identify actors (nouns/services) and messages (verbs/actions).

```
User: "Show how a user logs in through the app to the auth server and database"
Agent: excalidraw-cli --json template sequence -a "User,App,Auth Server,Database" \
  -m "0:1:Login request" -m "1:2:Validate credentials" -m "2:3:Query user" \
  -m "3:2:User data" -m "2:1:Auth token" -m "1:0:Login success" -o login.excalidraw
```

**ER diagram**: Identify entities (nouns) with their fields and relationships.

```
User: "Database for an e-commerce site with users, products, and orders"
Agent: excalidraw-cli --json template er \
  -e "User:id,name,email" -e "Product:id,name,price" -e "Order:id,date,total" \
  -r "User:Order:places" -r "Order:Product:contains" -o ecommerce.excalidraw
```

**Mind map**: Identify central topic, main branches, and sub-items.

```
User: "Break down a web app into frontend, backend, and devops components"
Agent: excalidraw-cli --json template mindmap "Web App" \
  -b "Frontend:React,CSS,Components" -b "Backend:API,Auth,DB" \
  -b "DevOps:CI/CD,Docker,Monitoring" -o webapp.excalidraw
```

### 3. Choose styling

- Use `--preset` for consistent visual themes
- For dark backgrounds: use `dark` or `neon` preset
- For professional look: use `blueprint` or `minimal`
- For presentations: use pastel presets for color-coding

### 4. For complex custom diagrams, use the Python API

When the user needs a layout that doesn't fit a template (e.g., a custom
architecture diagram with specific positioning), generate a Python script using
the `Scene` class directly. This gives full control over coordinates, colors,
and connections.
