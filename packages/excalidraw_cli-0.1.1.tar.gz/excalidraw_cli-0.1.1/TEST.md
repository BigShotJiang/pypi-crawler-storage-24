# Test Documentation — excalidraw-cli

## Test Suite Overview

| Category | File | Tests | Description |
|----------|------|-------|-------------|
| Core Unit | `tests/test_core.py` | 39 | Element creation, Scene CRUD, persistence, undo/redo |
| Template Unit | `tests/test_templates.py` | 11 | All 5 diagram templates with edge cases |
| Render/Export | `tests/test_render.py` | 43 | SVG renderer, PNG/JPG/PDF export, format validation, --input flag |
| CLI E2E | `tests/test_cli.py` | 29 | Every CLI command with JSON output validation |
| **Total** | | **122** | **100% pass rate** |

## Running Tests

```bash
cd agent-harness
pip install pytest
python -m pytest tests/ -v
```

## Test Results

```
tests/test_cli.py::TestSceneCommands::test_scene_new PASSED
tests/test_cli.py::TestSceneCommands::test_scene_new_json PASSED
tests/test_cli.py::TestSceneCommands::test_scene_new_with_options PASSED
tests/test_cli.py::TestSceneCommands::test_scene_save_and_load PASSED
tests/test_cli.py::TestSceneCommands::test_scene_info PASSED
tests/test_cli.py::TestSceneCommands::test_scene_clear PASSED
tests/test_cli.py::TestSceneCommands::test_scene_background PASSED
tests/test_cli.py::TestSceneCommands::test_scene_undo_redo PASSED
tests/test_cli.py::TestSceneCommands::test_scene_no_scene_error PASSED
tests/test_cli.py::TestElementCommands::test_element_add PASSED
tests/test_cli.py::TestElementCommands::test_element_add_auto_creates_scene PASSED
tests/test_cli.py::TestElementCommands::test_element_add_with_label PASSED
tests/test_cli.py::TestElementCommands::test_element_add_with_style PASSED
tests/test_cli.py::TestElementCommands::test_element_list PASSED
tests/test_cli.py::TestElementCommands::test_element_list_with_filter PASSED
tests/test_cli.py::TestElementCommands::test_element_remove PASSED
tests/test_cli.py::TestElementCommands::test_element_remove_not_found PASSED
tests/test_cli.py::TestElementCommands::test_element_update PASSED
tests/test_cli.py::TestElementCommands::test_element_connect PASSED
tests/test_cli.py::TestElementCommands::test_element_invalid_type PASSED
tests/test_cli.py::TestTemplateCommands::test_flowchart PASSED
tests/test_cli.py::TestTemplateCommands::test_flowchart_horizontal PASSED
tests/test_cli.py::TestTemplateCommands::test_sequence PASSED
tests/test_cli.py::TestTemplateCommands::test_er PASSED
tests/test_cli.py::TestTemplateCommands::test_mindmap PASSED
tests/test_cli.py::TestTemplateCommands::test_kanban PASSED
tests/test_cli.py::TestExportCommands::test_export_json_stdout PASSED
tests/test_cli.py::TestExportCommands::test_export_json_file PASSED
tests/test_cli.py::TestExportCommands::test_export_excalidraw PASSED
tests/test_cli.py::TestMisc::test_version PASSED
tests/test_core.py — 39 tests PASSED
tests/test_render.py — 43 tests PASSED
tests/test_templates.py — 11 tests PASSED

122 passed in 0.84s
```

## Test Coverage by Feature

### Core Engine (`test_core.py`)
- Element creation for all 9 types (rectangle, ellipse, diamond, arrow, line, text, freedraw, image, frame)
- Property defaults and overrides
- Unique ID generation
- Label binding (shape + bound text element)
- Scene CRUD operations (add, remove, get, update, list, clear)
- File persistence (save/load `.excalidraw` JSON)
- File validation (rejects non-Excalidraw files)
- Undo/redo state management
- High-level helpers (add_shape, add_text, add_arrow, connect)
- Summary statistics

### Templates (`test_templates.py`)
- Flowchart with standard and decision nodes
- Horizontal vs vertical layout
- Sequence diagram with actors and lifelines
- ER diagram with entities and relations
- Mind map with branches and leaves
- Kanban board with columns and cards
- Edge cases (single node, empty branches, no relations)

### Render & Export (`test_render.py`)
- SVG generation for all element types (rectangle, ellipse, diamond, text, arrow, line, freedraw)
- Fill styles (solid, hachure, cross-hatch) with SVG pattern generation
- Opacity, dashed strokes, multiline text, arrowheads
- Deleted elements are skipped
- Scale and padding affect output dimensions
- PNG export with magic byte validation and high-DPI scaling
- JPG export with quality control and RGB mode verification
- PDF export with magic byte validation
- CLI `--input` flag for direct file-to-format conversion
- All export CLI commands with JSON output

### CLI End-to-End (`test_cli.py`)
- Every `scene` subcommand (new, load, save, info, clear, background, undo, redo)
- Every `element` subcommand (add, list, remove, update, connect)
- All 5 template commands with file output
- Export commands (json, excalidraw, svg, png, jpg, pdf)
- `--json` flag produces parseable JSON
- Error handling (missing scene, invalid element ID, bad type)
- Version flag
