# Contributing to excalidraw-cli

Thank you for considering contributing to excalidraw-cli! This document provides guidelines and instructions for contributing.

## Getting Started

1. **Fork** the repository on GitHub
2. **Clone** your fork locally:
   ```bash
   git clone https://github.com/YOUR_USERNAME/excalidraw-cli.git
   cd excalidraw-cli
   ```
3. **Install** in development mode:
   ```bash
   cd agent-harness
   pip install -e .
   pip install pytest
   ```
4. **Run tests** to verify your setup:
   ```bash
   python -m pytest tests/ -v
   ```

## Development Workflow

1. Create a feature branch from `main`:
   ```bash
   git checkout -b feature/your-feature-name
   ```
2. Make your changes
3. Write or update tests
4. Run the full test suite:
   ```bash
   python -m pytest tests/ -v
   ```
5. Commit with a clear message:
   ```bash
   git commit -m "Add: description of what you added"
   ```
6. Push and open a pull request

## Code Style

- Follow PEP 8 conventions
- Use type hints for function signatures
- Keep functions focused and single-purpose
- Add docstrings to public functions and classes

## Adding New Templates

Templates live in `agent-harness/cli_anything/excalidraw/templates.py`. To add a new template:

1. Create a function that returns a `Scene` object
2. Add a corresponding Click command in `cli.py` under the `template` group
3. Write tests in `tests/test_templates.py`
4. Add a shell script example in `examples/`
5. Update the README command reference table

## Adding New Element Types

If Excalidraw adds new element types:

1. Add the type to `ALL_TYPES` in `core.py`
2. Handle type-specific defaults in `create_element()`
3. Add tests in `tests/test_core.py`

## Reporting Issues

When reporting bugs, please include:
- Python version (`python --version`)
- OS and version
- Steps to reproduce
- Expected vs actual behavior
- The `.excalidraw` file if relevant

## Pull Request Checklist

- [ ] Tests pass (`python -m pytest tests/ -v`)
- [ ] New functionality has tests
- [ ] Code follows existing style conventions
- [ ] README updated if adding commands or templates
- [ ] Example scripts added for new features
