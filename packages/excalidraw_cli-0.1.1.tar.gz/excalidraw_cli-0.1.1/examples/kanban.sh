#!/usr/bin/env bash
# Example: Generate a sprint board
# Output: kanban.excalidraw

set -euo pipefail

excalidraw-cli template kanban \
  -c "Backlog:Auth flow,Dark mode,Search" \
  -c "In Progress:User profiles,API docs" \
  -c "Review:Payment integration" \
  -c "Done:Landing page,CI/CD pipeline" \
  -o kanban.excalidraw

echo "Created kanban.excalidraw"
