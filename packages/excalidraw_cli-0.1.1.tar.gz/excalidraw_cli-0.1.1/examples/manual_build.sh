#!/usr/bin/env bash
# Example: Build a diagram manually using element-level commands
# Shows how to use the CLI step by step for full control.
# Output: manual.excalidraw

set -euo pipefail

# 1. Create a new scene
excalidraw-cli scene new --background "#f5f5dc"

# 2. Add shapes with labels
excalidraw-cli element add rectangle --x 100 --y 50 -w 180 -h 80 -l "Client" \
  --bg-color "#a5d8ff" --fill solid

excalidraw-cli element add rectangle --x 100 --y 250 -w 180 -h 80 -l "Server" \
  --bg-color "#d0bfff" --fill solid

excalidraw-cli element add rectangle --x 100 --y 450 -w 180 -h 80 -l "Database" \
  --bg-color "#b2f2bb" --fill solid

# 3. Add a title
excalidraw-cli element add text --x 80 --y 10 -l "System Architecture"

# 4. Save
excalidraw-cli scene save manual.excalidraw

echo "Created manual.excalidraw"
