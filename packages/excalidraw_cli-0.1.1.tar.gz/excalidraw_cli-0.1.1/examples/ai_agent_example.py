#!/usr/bin/env python3
"""Example: Using excalidraw-cli programmatically from Python.

This demonstrates how an AI agent (or any Python script) can generate
Excalidraw diagrams using the core library directly — no subprocess needed.
"""

from cli_anything.excalidraw.core import Scene
from cli_anything.excalidraw.templates import flowchart, mindmap


def example_custom_architecture_diagram():
    """Build a custom architecture diagram from scratch."""
    scene = Scene()
    scene.set_background("#1e1e2e")

    # Add services
    web = scene.add_shape(
        "rectangle", x=300, y=50, width=200, height=70, label="Web App",
        backgroundColor="#89b4fa", fillStyle="solid", strokeColor="#cdd6f4",
    )
    api = scene.add_shape(
        "rectangle", x=300, y=200, width=200, height=70, label="API Server",
        backgroundColor="#a6e3a1", fillStyle="solid", strokeColor="#cdd6f4",
    )
    db = scene.add_shape(
        "rectangle", x=150, y=380, width=160, height=70, label="PostgreSQL",
        backgroundColor="#f9e2af", fillStyle="solid", strokeColor="#cdd6f4",
    )
    cache = scene.add_shape(
        "rectangle", x=500, y=380, width=160, height=70, label="Redis",
        backgroundColor="#f38ba8", fillStyle="solid", strokeColor="#cdd6f4",
    )

    # Connect them (curved arrows for a modern look)
    scene.connect(web, api, arrow_style="curved")
    scene.connect(api, db, arrow_style="curved")
    scene.connect(api, cache, arrow_style="curved")

    # Add a title
    scene.add_text(
        "Production Architecture",
        x=280, y=10, font_size=24,
        strokeColor="#cdd6f4",
    )

    scene.save("architecture.excalidraw")
    print(f"Saved architecture.excalidraw ({scene.summary()['total_elements']} elements)")


def example_with_template():
    """Build a flowchart with decision branching and labelled arrows."""
    scene = Scene()
    scene.set_background("#fafafa")

    # Nodes
    req = scene.add_flowchart_node("User Request", x=100, y=100, width=220, height=80)
    auth = scene.add_flowchart_node("Authenticated?", x=100, y=240, width=220, height=80, shape="diamond")
    dash = scene.add_flowchart_node("Load Dashboard", x=100, y=380, width=220, height=80)
    login = scene.add_flowchart_node("Show Login", x=400, y=240, width=220, height=80)

    # Connections with labels
    scene.connect(req, auth)
    scene.connect(auth, dash, label="Yes")
    scene.connect(auth, login, label="No")

    scene.add_text("Auth Flow", x=120, y=40, font_size=28)
    scene.save("auth_flow.excalidraw")
    print(f"Saved auth_flow.excalidraw ({scene.summary()['total_elements']} elements)")


def example_mindmap():
    """Generate a mind map for project planning."""
    scene = mindmap(
        "Q1 Goals",
        {
            "Engineering": ["Migrate to K8s", "API v2", "Monitoring"],
            "Product": ["User research", "Redesign", "Mobile app"],
            "Growth": ["SEO", "Content", "Partnerships"],
        },
    )
    scene.save("q1_goals.excalidraw")
    print(f"Saved q1_goals.excalidraw ({scene.summary()['total_elements']} elements)")


def example_arrow_styles():
    """Showcase all three arrow styles: straight, curved, elbowed."""
    scene = Scene()

    # Row 1: Straight arrows (default)
    scene.add_text("Straight", x=60, y=40, font_size=18)
    a = scene.add_shape(
        "rectangle", x=60, y=70, width=120, height=50, label="Start",
        backgroundColor="#a5d8ff", fillStyle="solid",
    )
    b = scene.add_shape(
        "rectangle", x=280, y=70, width=120, height=50, label="End",
        backgroundColor="#a5d8ff", fillStyle="solid",
    )
    scene.connect(a, b, arrow_style="straight")

    # Row 2: Curved arrows
    scene.add_text("Curved", x=60, y=160, font_size=18)
    c = scene.add_shape(
        "rectangle", x=60, y=190, width=120, height=50, label="Client",
        backgroundColor="#d0bfff", fillStyle="solid",
    )
    d = scene.add_shape(
        "rectangle", x=280, y=190, width=120, height=50, label="Server",
        backgroundColor="#d0bfff", fillStyle="solid",
    )
    scene.connect(c, d, arrow_style="curved")

    # Row 3: Elbowed arrows (rounded corners)
    scene.add_text("Elbowed", x=60, y=280, font_size=18)
    e = scene.add_shape(
        "rectangle", x=60, y=310, width=120, height=50, label="Input",
        backgroundColor="#b2f2bb", fillStyle="solid",
    )
    f = scene.add_shape(
        "rectangle", x=280, y=400, width=120, height=50, label="Output",
        backgroundColor="#b2f2bb", fillStyle="solid",
    )
    scene.connect(e, f, arrow_style="elbowed")

    # Row 4: Elbowed with obstacle avoidance
    scene.add_text("Routed (elbowed around obstacle)", x=60, y=490, font_size=18)
    g = scene.add_shape(
        "rectangle", x=60, y=520, width=120, height=50, label="Source",
        backgroundColor="#ffd8a8", fillStyle="solid",
    )
    blocker = scene.add_shape(
        "rectangle", x=240, y=520, width=120, height=50, label="Blocker",
        backgroundColor="#ffc9c9", fillStyle="solid",
    )
    h = scene.add_shape(
        "rectangle", x=420, y=520, width=120, height=50, label="Dest",
        backgroundColor="#ffd8a8", fillStyle="solid",
    )
    scene.connect(g, h, arrow_style="elbowed")

    scene.save("arrow_styles.excalidraw")
    print(f"Saved arrow_styles.excalidraw ({scene.summary()['total_elements']} elements)")


if __name__ == "__main__":
    example_custom_architecture_diagram()
    example_with_template()
    example_mindmap()
    example_arrow_styles()
