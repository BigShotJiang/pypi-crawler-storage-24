#!/usr/bin/env bash
# Example: Generate a database ER diagram for a blog platform
# Output: er_diagram.excalidraw

set -euo pipefail

excalidraw-cli template er \
  -e "User:id,username,email,created_at" \
  -e "Post:id,title,body,published_at" \
  -e "Comment:id,body,created_at" \
  -e "Tag:id,name" \
  -r "User:Post:writes" \
  -r "User:Comment:authors" \
  -r "Post:Comment:has many" \
  -r "Post:Tag:tagged with" \
  -o er_diagram.excalidraw

echo "Created er_diagram.excalidraw"
