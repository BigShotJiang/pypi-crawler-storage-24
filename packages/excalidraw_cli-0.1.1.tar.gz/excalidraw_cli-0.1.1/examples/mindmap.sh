#!/usr/bin/env bash
# Example: Generate a project architecture mind map
# Output: mindmap.excalidraw

set -euo pipefail

excalidraw-cli template mindmap "My SaaS App" \
  -b "Frontend:React,TypeScript,Tailwind" \
  -b "Backend:Python,FastAPI,SQLAlchemy" \
  -b "Infrastructure:AWS,Docker,Terraform" \
  -b "Data:PostgreSQL,Redis,S3" \
  -o mindmap.excalidraw

echo "Created mindmap.excalidraw"
