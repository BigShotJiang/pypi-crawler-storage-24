#!/usr/bin/env bash
# Example: Generate a software development lifecycle flowchart
# Output: flowchart.excalidraw (open in https://excalidraw.com)

set -euo pipefail

excalidraw-cli template flowchart \
  "Requirements" \
  "?Feasible?" \
  "Design" \
  "Implement" \
  "?Tests pass?" \
  "Deploy" \
  "Monitor" \
  -o flowchart.excalidraw

echo "Created flowchart.excalidraw — open it at https://excalidraw.com"
