#!/usr/bin/env bash
# Example: Generate a REST API sequence diagram
# Output: sequence.excalidraw

set -euo pipefail

excalidraw-cli template sequence \
  -a "Browser,API Gateway,Auth Service,Database" \
  -m "0:1:POST /login" \
  -m "1:2:Validate token" \
  -m "2:3:SELECT user" \
  -m "3:2:User row" \
  -m "2:1:JWT token" \
  -m "1:0:200 OK + token" \
  -o sequence.excalidraw

echo "Created sequence.excalidraw"
