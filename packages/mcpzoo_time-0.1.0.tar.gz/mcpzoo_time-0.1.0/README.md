# mcpzoo-time

> 时间查询 — 获取当前时间并支持时区转换

## Installation

```bash
uvx mcpzoo-time
```

## uvx JSON

```json
{
  "mcpServers": {
    "time": {
      "args": ["mcpzoo-time"],
      "command": "uvx"
    }
  }
}
```
