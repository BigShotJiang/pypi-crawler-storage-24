from datetime import datetime
try:
    import zoneinfo
except ImportError:
    from backports import zoneinfo  # Python < 3.9

from mcp.server.fastmcp import FastMCP

mcp = FastMCP("time")


@mcp.tool()
def get_time(timezone: str = "UTC", fmt: str = "%Y-%m-%d %H:%M:%S %Z") -> str:
    """获取当前时间并支持时区转换。"""
    try:
        tz = zoneinfo.ZoneInfo(timezone)
        now = datetime.now(tz)
        return now.strftime(fmt)
    except Exception as e:
        return f"获取时间失败，请检查时区（如 Asia/Shanghai）: {e}"


def main():
    mcp.run()


if __name__ == "__main__":
    main()
