"""
antaris-memory — Graph Intelligence Tests
==========================================

Tests for EntityExtractor and MemoryGraph.
"""

import json
import os
import tempfile

import pytest

from parsica_memory.entity_extractor import (
    EntityExtractor,
    Entity,
    PERSON, PROJECT, CONCEPT, DATE, VERSION, URL,
)
from parsica_memory.graph import MemoryGraph, GraphNode, GraphEdge


# ════════════════════════════════════════════════════════════════════════════
# ENTITY EXTRACTOR
# ════════════════════════════════════════════════════════════════════════════

class TestEntityExtractor:

    def setup_method(self):
        self.ex = EntityExtractor()

    # ── Basic extraction ───────────────────────────────────────────────────

    def test_extracts_version_numbers(self):
        entities = self.ex.extract("We shipped antaris-memory v4.7.0 today")
        types = {e.entity_type for e in entities}
        canonicals = {e.canonical for e in entities}
        assert VERSION in types
        assert any("4.7.0" in c for c in canonicals)

    def test_extracts_urls(self):
        entities = self.ex.extract("Check https://pypi.org/project/antaris-memory for details")
        urls = [e for e in entities if e.entity_type == URL]
        assert len(urls) >= 1
        assert "pypi.org" in urls[0].text

    def test_extracts_dates(self):
        entities = self.ex.extract("Shipped on 2026-03-02 after the sprint")
        date_ents = [e for e in entities if e.entity_type == DATE]
        assert len(date_ents) >= 1
        assert "2026-03-02" in date_ents[0].text

    def test_extracts_camelcase_identifiers(self):
        entities = self.ex.extract("MemorySystem and SearchEngine are the main classes")
        canonicals = {e.canonical for e in entities}
        assert any("memorysystem" in c for c in canonicals)
        assert any("searchengine" in c for c in canonicals)

    def test_extracts_allcaps_concepts(self):
        entities = self.ex.extract("BM25 outperforms TF-IDF on short queries")
        canonicals = {e.canonical for e in entities}
        assert "bm25" in canonicals

    def test_extracts_proper_noun_phrases(self):
        entities = self.ex.extract("Antaris Analytics built the memory system")
        canonicals = {e.canonical for e in entities}
        assert "antaris analytics" in canonicals

    def test_extracts_code_identifiers(self):
        entities = self.ex.extract("antaris-memory and antaris-guard are packages")
        canonicals = {e.canonical for e in entities}
        assert "antaris-memory" in canonicals
        assert "antaris-guard" in canonicals

    def test_empty_string_returns_empty(self):
        assert self.ex.extract("") == []

    def test_none_input_returns_empty(self):
        assert self.ex.extract(None) == []

    def test_stopwords_not_extracted(self):
        entities = self.ex.extract("the and or but is are was were")
        # Should be empty or near-empty
        assert len(entities) == 0

    def test_common_non_entities_filtered(self):
        entities = self.ex.extract("I said OK and YES to that")
        canonicals = {e.canonical for e in entities}
        assert "ok" not in canonicals
        assert "yes" not in canonicals

    # ── Alias merging ──────────────────────────────────────────────────────

    def test_alias_normalization(self):
        entities = self.ex.extract("antaris-memory and antaris_memory are the same")
        entities = self.ex.merge_aliases(entities)
        canonicals = {e.canonical for e in entities}
        # Both should resolve to the same canonical form
        assert "antaris-memory" in canonicals

    def test_merge_aliases_deduplicates(self):
        e1 = Entity("MemorySystem", PROJECT, "memorysystem", 0.8, [0])
        e2 = Entity("Memory System", PROJECT, "memorysystem", 0.6, [20])
        merged = self.ex.merge_aliases([e1, e2])
        canonicals = [e.canonical for e in merged]
        assert canonicals.count("memorysystem") == 1

    def test_merge_keeps_highest_confidence(self):
        e1 = Entity("MemorySystem", PROJECT, "memorysystem", 0.9, [0])
        e2 = Entity("Memory System", PROJECT, "memorysystem", 0.5, [20])
        merged = self.ex.merge_aliases([e1, e2])
        kept = next(e for e in merged if e.canonical == "memorysystem")
        assert kept.text == "MemorySystem"  # higher confidence wins

    # ── Relation extraction ────────────────────────────────────────────────

    def test_relation_co_mentioned(self):
        # Use kebab-case identifiers so they're extracted regardless of sentence position
        text = "antaris-memory and antaris-guard are both maintained by antaris-analytics"
        entities = self.ex.extract(text)
        relations = self.ex.extract_relations(text, entities)
        assert len(relations) > 0
        sources = {r[0] for r in relations}
        targets = {r[2] for r in relations}
        all_entities = sources | targets
        assert any("antaris-memory" in e or "antaris-guard" in e
                   for e in all_entities)

    def test_relation_empty_for_single_entity(self):
        text = "Moro is working"
        entities = self.ex.extract(text)
        relations = self.ex.extract_relations(text, entities)
        assert relations == []

    def test_relation_extraction_nonfatal_on_bad_input(self):
        result = self.ex.extract_relations(None, [])
        assert result == []


# ════════════════════════════════════════════════════════════════════════════
# MEMORY GRAPH
# ════════════════════════════════════════════════════════════════════════════

class TestMemoryGraph:

    def setup_method(self):
        self.tmpdir = tempfile.mkdtemp()
        self.graph = MemoryGraph(self.tmpdir)

    def teardown_method(self):
        import shutil
        shutil.rmtree(self.tmpdir, ignore_errors=True)

    # ── Indexing ───────────────────────────────────────────────────────────

    def test_index_entry_returns_entity_count(self):
        n = self.graph.index_entry("hash1",
            "antaris-memory v4.7.0 was shipped by Moro on 2026-03-02")
        assert n > 0

    def test_index_empty_content_returns_zero(self):
        n = self.graph.index_entry("hash1", "")
        assert n == 0

    def test_index_none_hash_returns_zero(self):
        n = self.graph.index_entry(None, "some content with entities")
        assert n == 0

    def test_node_created_after_indexing(self):
        self.graph.index_entry("hash1", "antaris-memory is a memory package")
        node = self.graph.get_node("antaris-memory")
        assert node is not None
        assert node.mention_count >= 1

    def test_mention_count_increments_on_second_entry(self):
        self.graph.index_entry("hash1", "antaris-memory is great")
        self.graph.index_entry("hash2", "antaris-memory is fast")
        node = self.graph.get_node("antaris-memory")
        assert node.mention_count >= 2

    def test_entry_ids_tracked_per_node(self):
        self.graph.index_entry("abc123", "antaris-memory is here")
        node = self.graph.get_node("antaris-memory")
        assert "abc123" in node.entry_ids

    # ── Persistence ────────────────────────────────────────────────────────

    def test_graph_persists_across_instances(self):
        self.graph.index_entry("hash1", "antaris-memory v4.7.0 is our package")
        self.graph.save()

        graph2 = MemoryGraph(self.tmpdir)
        node = graph2.get_node("antaris-memory")
        assert node is not None

    def test_corrupt_graph_file_starts_fresh(self):
        graph_path = os.path.join(self.tmpdir, ".memory_graph.json")
        with open(graph_path, "w") as f:
            f.write("{CORRUPTED{{{{")
        graph2 = MemoryGraph(self.tmpdir)
        # Should not raise and should work normally
        graph2.index_entry("hash1", "antaris-memory is a package")
        assert graph2.get_node("antaris-memory") is not None

    # ── Removal ────────────────────────────────────────────────────────────

    def test_remove_entry_decrements_mention_count(self):
        self.graph.index_entry("hash1", "antaris-memory is great")
        self.graph.index_entry("hash2", "antaris-memory is fast")
        self.graph.remove_entry("hash1")
        node = self.graph.get_node("antaris-memory")
        assert node is not None
        assert "hash1" not in node.entry_ids

    def test_remove_entry_cleans_up_isolated_nodes(self):
        self.graph.index_entry("solo123", "unique_identifier_xyz_solo is here")
        self.graph.remove_entry("solo123")
        node = self.graph.get_node("unique-identifier-xyz-solo")
        # Node should be gone or have 0 entries
        if node:
            assert len(node.entry_ids) == 0

    # ── Neighbors / traversal ──────────────────────────────────────────────

    def test_neighbors_returns_connected_entities(self):
        # Two entities co-mentioned in the same entry → should be connected
        self.graph.index_entry("h1",
            "antaris-memory and antaris-guard are both packages in antaris-suite")
        self.graph.save()

        # After indexing, neighbors of antaris-memory should include antaris-guard
        neighbors = self.graph.neighbors("antaris-memory")
        # At minimum, some neighbors should exist if entities co-appeared
        assert isinstance(neighbors, dict)

    def test_neighbors_empty_for_unknown_entity(self):
        neighbors = self.graph.neighbors("totally_unknown_entity_xyz")
        assert neighbors == {}

    def test_find_path_same_node(self):
        self.graph.index_entry("h1", "antaris-memory is the core package")
        path = self.graph.find_path("antaris-memory", "antaris-memory")
        assert path == ["antaris-memory"]

    def test_find_path_unknown_node_returns_none(self):
        path = self.graph.find_path("nonexistent_a", "nonexistent_b")
        assert path is None

    # ── Boost results ──────────────────────────────────────────────────────

    def test_boost_results_nonfatal_on_empty_list(self):
        result = self.graph.boost_results("antaris-memory", [])
        assert result == []

    def test_boost_results_returns_same_count(self):
        """Boost should not add or remove results."""
        from parsica_memory.search import SearchResult

        self.graph.index_entry("h1", "antaris-memory v4.7.0 package")
        self.graph.save()

        from parsica_memory.entry import MemoryEntry
        entry = MemoryEntry(content="antaris-memory details")
        entry.hash = "h1"

        # Mock SearchResult-like object
        class FakeResult:
            def __init__(self, entry, score):
                self.entry = entry
                self.score = score

        results = [FakeResult(entry, 0.5)]
        boosted = self.graph.boost_results("antaris-memory", results)
        assert len(boosted) == len(results)

    # ── Relationship search ────────────────────────────────────────────────

    def test_relationship_search_returns_list(self):
        self.graph.index_entry("h1",
            "Moro built antaris-memory for Antaris Analytics")
        results = self.graph.relationship_search("moro")
        assert isinstance(results, list)

    def test_relationship_search_unknown_entity(self):
        results = self.graph.relationship_search("totally_unknown_xyz")
        assert results == []

    # ── Stats ──────────────────────────────────────────────────────────────

    def test_stats_returns_dict(self):
        self.graph.index_entry("h1", "antaris-memory v4.7.0 BM25 search engine")
        stats = self.graph.get_stats()
        assert isinstance(stats, dict)
        assert "node_count" in stats
        assert stats["node_count"] > 0

    def test_stats_empty_graph(self):
        stats = self.graph.get_stats()
        assert stats["node_count"] == 0
        assert stats["edge_count"] == 0
