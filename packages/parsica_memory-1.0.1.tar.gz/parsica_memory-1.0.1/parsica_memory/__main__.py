"""python -m antaris_memory entry point."""
import sys
from parsica_memory.cli import main

if __name__ == "__main__":
    sys.exit(main())
