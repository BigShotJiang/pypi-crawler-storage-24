"""
antaris-memory — CLI
====================

Entry point for `python -m antaris_memory` commands.

Commands:
  init            Scaffold a new workspace and generate agent config
  status          Show live stats for an existing workspace
  rebuild-graph   Rebuild the memory graph from all loaded entries
  serve           Start the MCP server (stdio transport)

Usage:
  python -m antaris_memory init [--workspace PATH] [--agent-name NAME]
  python -m antaris_memory status [--workspace PATH]
  python -m antaris_memory rebuild-graph [--workspace PATH]
  python -m antaris_memory serve [--workspace PATH] [--agent-name NAME]
"""

import argparse
import json
import os
import sys
import uuid

from parsica_memory import __version__


# ── Helpers ──────────────────────────────────────────────────────────────────

def _print_header(title: str) -> None:
    print(f"\n⚡ antaris-memory — {title}")
    print("─" * 50)


def _print_stats(s: dict) -> None:
    """Pretty-print stats() output."""
    _print_header(f"v{s.get('version', '?')} status")
    print(f"  Workspace   : {s.get('workspace', '?')}")
    print(f"  Agent       : {s.get('agent_name') or '(unset)'}")
    print()
    print(f"  Entries     : {s.get('total_entries', 0):,} hot  "
          f"| {s.get('warm_entries', 0):,} warm "
          f"| {s.get('cold_entries', 0):,} cold")
    print(f"  WAL pending : {s.get('wal_size', 0):,}")
    print(f"  Enriched    : {s.get('enrichment_count', 0):,}  "
          f"(${s.get('enrichment_cost_usd', 0):.4f} lifetime)")
    print()
    if s.get('graph_enabled'):
        print(f"  Graph       : {s.get('graph_nodes', 0):,} nodes  "
              f"| {s.get('graph_edges', 0):,} edges")
    else:
        print("  Graph       : disabled")
    print(f"  Co-occ pairs: {s.get('cooccurrence_pairs', 0):,}")
    print(f"  Cache size  : {s.get('cache_size', 0):,}")
    print()


def _make_agent_name(provided: str = None) -> str:
    if provided:
        return provided
    # Derive from machine hostname
    import socket
    hostname = socket.gethostname().split('.')[0].lower()
    return f"agent-{hostname}"


# ── Commands ─────────────────────────────────────────────────────────────────

def cmd_init(args) -> int:
    """Scaffold a new antaris-memory workspace."""
    workspace = os.path.abspath(args.workspace)
    agent_name = _make_agent_name(args.agent_name)

    _print_header("init")
    print(f"  Workspace   : {workspace}")
    print(f"  Agent name  : {agent_name}")
    print()

    # Create workspace directory
    os.makedirs(workspace, exist_ok=True)

    # Write agent config
    config_path = os.path.join(workspace, "antaris_config.json")
    if os.path.exists(config_path) and not getattr(args, 'force', False):
        print(f"  Config already exists at {config_path}")
        print("  Use --force to overwrite.")
    else:
        config = {
            "agent_name": agent_name,
            "agent_id": str(uuid.uuid4()),
            "workspace": workspace,
            "version": __version__,
            "settings": {
                "half_life": 7.0,
                "tiered_storage": True,
                "graph_intelligence": True,
                "enricher": None,
            },
        }
        with open(config_path, 'w') as f:
            json.dump(config, f, indent=2)
        print(f"  ✅ Config written  : {config_path}")

    # Touch memory directories
    for d in ['.consolidated', '.shared_pools']:
        os.makedirs(os.path.join(workspace, d), exist_ok=True)

    # Quick smoke test — import MemorySystem
    try:
        from parsica_memory.core_v4 import MemorySystemV4
        ms = MemorySystemV4(workspace=workspace, agent_name=agent_name)
        ms.save()
        total = len(ms.memories)
        print(f"  ✅ MemorySystem OK  : {total:,} entries loaded")
    except Exception as e:
        print(f"  ⚠️  MemorySystem warning: {e}")

    print()
    print("  Ready! Run `python -m antaris_memory status` to see live stats.")
    print()
    return 0


def cmd_status(args) -> int:
    """Show live stats for an existing workspace."""
    workspace = os.path.abspath(args.workspace)

    # Try to get agent_name from config file
    agent_name = None
    config_path = os.path.join(workspace, "antaris_config.json")
    if os.path.exists(config_path):
        try:
            with open(config_path) as f:
                cfg = json.load(f)
            agent_name = cfg.get("agent_name")
        except Exception:
            pass

    try:
        from parsica_memory.core_v4 import MemorySystemV4
        ms = MemorySystemV4(workspace=workspace, agent_name=agent_name)
        ms.load()
        s = ms.stats()
        _print_stats(s)

        # Health check
        h = ms.get_health()
        status_icon = "✅" if h["status"] == "ok" else "⚠️"
        print(f"  {status_icon} Health: {h['status']}")
        for check, ok in h["checks"].items():
            icon = "✅" if ok else "❌"
            print(f"     {icon} {check}")
        print()
    except Exception as e:
        print(f"\n  ❌ Error loading workspace: {e}", file=sys.stderr)
        return 1

    return 0


def cmd_rebuild_graph(args) -> int:
    """Rebuild the memory graph from all loaded entries."""
    workspace = os.path.abspath(args.workspace)

    agent_name = None
    config_path = os.path.join(workspace, "antaris_config.json")
    if os.path.exists(config_path):
        try:
            with open(config_path) as f:
                cfg = json.load(f)
            agent_name = cfg.get("agent_name")
        except Exception:
            pass

    _print_header("rebuild-graph")
    print(f"  Workspace: {workspace}")
    print()

    try:
        from parsica_memory.core_v4 import MemorySystemV4
        ms = MemorySystemV4(workspace=workspace, agent_name=agent_name,
                            graph_intelligence=True)
        ms.load()
        total = len(ms.memories)
        print(f"  Loaded {total:,} entries — rebuilding graph...")
        count = ms.rebuild_graph()
        print(f"  ✅ Graph rebuilt: {count:,} entries indexed")

        g = ms.get_graph_stats()
        print(f"  Nodes: {g.get('node_count', 0):,}  |  Edges: {g.get('edge_count', 0):,}")
        print()
    except Exception as e:
        print(f"\n  ❌ Error: {e}", file=sys.stderr)
        return 1

    return 0


def cmd_serve(args) -> int:
    """Start the MCP server (stdio transport)."""
    workspace = os.path.abspath(args.workspace)
    agent_name = _make_agent_name(getattr(args, 'agent_name', None))

    try:
        from parsica_memory.mcp_server import AntarisMCPServer
        server = AntarisMCPServer(workspace=workspace, agent_name=agent_name)
        server.run_stdio()
    except ImportError:
        print("MCP server module not found.", file=sys.stderr)
        return 1
    except KeyboardInterrupt:
        pass

    return 0


# ── Main ─────────────────────────────────────────────────────────────────────

def main(argv=None) -> int:
    parser = argparse.ArgumentParser(
        prog="python -m antaris_memory",
        description="antaris-memory CLI",
    )
    subparsers = parser.add_subparsers(dest="command")

    # init
    p_init = subparsers.add_parser("init", help="Scaffold a new workspace")
    p_init.add_argument("--workspace", default=".", help="Workspace path (default: .)")
    p_init.add_argument("--agent-name", default=None, help="Agent name")
    p_init.add_argument("--force", action="store_true", help="Overwrite existing config")

    # status
    p_status = subparsers.add_parser("status", help="Show live stats")
    p_status.add_argument("--workspace", default=".", help="Workspace path")

    # rebuild-graph
    p_rebuild = subparsers.add_parser("rebuild-graph", help="Rebuild memory graph")
    p_rebuild.add_argument("--workspace", default=".", help="Workspace path")

    # serve (MCP)
    p_serve = subparsers.add_parser("serve", help="Start MCP server (stdio)")
    p_serve.add_argument("--workspace", default=".", help="Workspace path")
    p_serve.add_argument("--agent-name", default=None, help="Agent name")

    args = parser.parse_args(argv)

    if args.command == "init":
        return cmd_init(args)
    elif args.command == "status":
        return cmd_status(args)
    elif args.command == "rebuild-graph":
        return cmd_rebuild_graph(args)
    elif args.command == "serve":
        return cmd_serve(args)
    else:
        parser.print_help()
        return 0


if __name__ == "__main__":
    sys.exit(main())
