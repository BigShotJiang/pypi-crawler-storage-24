import textwrap

class create_file():
    detail_prompt: str = textwrap.dedent("""\
import os
import sys

# create_python が存在するディレクトリへのパス
pilot_generator_path = r"{{PILOT_GENERATOR_PATH}}"
if pilot_generator_path not in sys.path:
    sys.path.insert(0, pilot_generator_path)

from create_python.pilot_generator import PilotGenerator

if __name__ == "__main__":
    print("========================================")
    print("        add_job ツール実行          ")
    print("========================================")

    # Job追加のパラメーター (必要に応じて変更・または引数化してください)
    job_no = '020'
    base_class_type = 'generateText'
    
    # properties_file の相対パスが指定されている
    properties_file_rel = '../../../../../config/{{PROPERTIES_FILE_NAME}}'
    properties_file = os.path.abspath(os.path.join(os.path.dirname(__file__), properties_file_rel))
    
    try:
        print(f"[{properties_file_rel}] を元に Job {job_no} を追加します...")
        
        # インスタンスから add_job をcall
        generator = PilotGenerator()
        generator.add_job(
            properties_file=properties_file,
            job_no=job_no,
            base_class_type=base_class_type
        )
        print("Jobの追加処理が完了しました！\\n")
        
    except Exception as e:
        print("-" * 40)
        print(f"add_job エラーが発生しました: {e}")
""").strip()
