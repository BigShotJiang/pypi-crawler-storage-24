import textwrap

class create_file():
    detail_prompt: str = textwrap.dedent("""\
import os.path

from {{JOB_PACKAGE}} import Job
from pilot.job.base.generate.generatePromptBaseJob import GeneratePromptBaseJob
from pilot.job.base.generate.generateJsonBaseJob import GenerateJsonBaseJob
from pilot.job.base.generate.generateTextBaseJob import GenerateTextBaseJob

class {{JOB_NAME}}(GenerateTextBaseJob):

    def run(self):
        self.prompt_content = self.get_file_content()
        self.result_file_path = os.path.splitext(self.file_path)[0]
        super().run()
""").strip()
