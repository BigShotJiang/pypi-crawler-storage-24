import textwrap

class create_file():
    detail_prompt: str = textwrap.dedent("""\
import os.path

from {{JOB_PACKAGE}} import Job
from pilot.job.base.generate.generatePromptBaseJob import GeneratePromptBaseJob
from pilot.job.base.generate.generateTextBaseJob import GenerateTextBaseJob

class {{JOB_NAME}}(Job):

    def run(self):

        super().run()
""").strip()
