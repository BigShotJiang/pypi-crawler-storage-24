import textwrap

class create_file():
    detail_prompt: str = textwrap.dedent("""\
from pilot.unit.impl.base_unit import BaseUnit
from pilot.job.impl.base_job import BaseJob
from {{GYOMU_JOB_PACKAGE_000}} import Job_000
from {{GYOMU_JOB_PACKAGE_010}} import Job_010
from {{GYOMU_JOB_PACKAGE_011}} import Job_011

class Unit(BaseUnit):

    def run(self, index: int = 0):
        print(f'unit: {self.config_dto.steps[index]}')
        super().run(index)

    def _init_job(self, current_step):
        # 重要  stepe毎に　Jobを切り替える
        stepsList = self.config_dto.steps
        if current_step == stepsList[0]:
            return Job_000()
        elif current_step == stepsList[1]:
            return Job_010()
        elif current_step == stepsList[2]:
            return Job_011()
        else:
            print("不明なステップ")
        return BaseJob()
""").strip()
