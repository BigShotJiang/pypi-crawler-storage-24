import textwrap

class create_file():
    detail_prompt: str = textwrap.dedent("""\
from {{JOB_PACKAGE}} import Job


class Job_000(Job):
    # __init__ は省略。BaseJobのものを継承。
    def run(self):
        self.copy_current_file_to_next_step()
        self.create_next_step_todo_trg_file()
        super().run()
""").strip()
