import textwrap

class create_file():
    detail_prompt: str = textwrap.dedent("""\
work_space={{WORK_SPACE}}

project={{PROJECT_NAME}}
controller_file={{CONTROLLER_FILE}}
steps={{STEP_NAME}},step_end
runsteps={{STEP_NAME}}
multisteps = step_011
threads=4
""").strip()
