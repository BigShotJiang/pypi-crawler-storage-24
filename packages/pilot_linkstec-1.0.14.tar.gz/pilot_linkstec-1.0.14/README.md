# pilot

This is a simple example package. You can use
to write your content.

pip install build

.\.venv\Scripts\Activate.ps1

py -m build 

py -m twine upload  dist/*