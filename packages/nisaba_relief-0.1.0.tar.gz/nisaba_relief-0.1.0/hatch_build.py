"""Hatch build hook to strip HuggingFace YAML frontmatter from README."""

import re
from pathlib import Path

from hatchling.metadata.plugin.interface import MetadataHookInterface


class ReadmeHook(MetadataHookInterface):
    PLUGIN_NAME = "readme-strip-frontmatter"

    def update(self, metadata: dict) -> None:
        readme_path = Path(self.root) / "README.md"
        text = readme_path.read_text(encoding="utf-8")
        # Strip YAML frontmatter (--- ... ---)
        text = re.sub(r"\A---\n.*?\n---\n*", "", text, count=1, flags=re.DOTALL)
        metadata["readme"] = {
            "content-type": "text/markdown",
            "text": text,
        }
