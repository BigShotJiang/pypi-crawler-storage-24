"""Pure image and tensor helper functions for NisabaRelief."""

import math

import numpy as np
import torch
from PIL import Image
from torchvision import transforms

from .constants import (
    MAX_TILE,
    MIN_TILE,
    PATCH_SIZE,
    TARGET_TILES_PER_SIDE,
    TILE_OVERLAP_DIVISOR,
)

_to_tensor = transforms.ToTensor()


def round_to_patch(value: float) -> int:
    """Round a pixel value to the nearest multiple of PATCH_SIZE (minimum PATCH_SIZE)."""
    return max(PATCH_SIZE, PATCH_SIZE * round(value / PATCH_SIZE))


def ceil_to_patch(value: float) -> int:
    """Ceil a pixel value to the next multiple of PATCH_SIZE (minimum PATCH_SIZE)."""
    return max(PATCH_SIZE, PATCH_SIZE * math.ceil(value / PATCH_SIZE))


def compute_tile_size(max_side: int) -> int:
    """Compute the optimal square tile side length for a given image maximum side."""
    raw = ceil_to_patch(
        max_side
        * TILE_OVERLAP_DIVISOR
        / (TARGET_TILES_PER_SIDE * (TILE_OVERLAP_DIVISOR - 1) + 1)
    )
    return max(min(raw, MAX_TILE), MIN_TILE)


def compute_tile_grid(
    orig_w: int, orig_h: int, tile_size: int
) -> tuple[int, int, int, int, int, int, int, int]:
    """Compute tiled grid layout for an image.

    Returns (n_cols, n_rows, padded_w, padded_h, pad_left, pad_top, overlap, stride).
    """
    overlap = tile_size // TILE_OVERLAP_DIVISOR
    stride = tile_size - overlap
    n_cols = max(1, math.ceil((orig_w - overlap) / stride))
    n_rows = max(1, math.ceil((orig_h - overlap) / stride))
    padded_w = tile_size + (n_cols - 1) * stride
    padded_h = tile_size + (n_rows - 1) * stride
    pad_left = (padded_w - orig_w) // 2
    pad_top = (padded_h - orig_h) // 2
    return n_cols, n_rows, padded_w, padded_h, pad_left, pad_top, overlap, stride


def image_to_tensor(image: Image.Image, device: str) -> torch.Tensor:
    """Convert a PIL image to a normalised [-1, 1] float tensor on device."""
    return (2 * _to_tensor(image) - 1).to(device)


def tensor_to_image(tensor: torch.Tensor) -> Image.Image:
    """Convert a normalised [-1, 1] CHW tensor to a PIL RGB image."""
    img = (tensor.clamp(-1, 1) + 1) / 2
    img = img.permute(1, 2, 0).float().cpu().numpy()
    return Image.fromarray((img * 255).astype("uint8"))


def pad_to_patch_multiple(image: Image.Image) -> Image.Image:
    """Pad image width and height up to the next multiple of PATCH_SIZE."""
    w, h = image.size
    pad_w = (PATCH_SIZE - w % PATCH_SIZE) % PATCH_SIZE
    pad_h = (PATCH_SIZE - h % PATCH_SIZE) % PATCH_SIZE
    if pad_w == 0 and pad_h == 0:
        return image
    padded = Image.new("RGB", (w + pad_w, h + pad_h), (0, 0, 0))
    padded.paste(image, (0, 0))
    return padded


def postprocess(image: Image.Image, shadow_strength: float = 0.7) -> Image.Image:
    """Apply adaptive gamma correction and convert to grayscale."""
    arr = np.array(image, dtype=np.float32) / 255.0
    gamma = 1.0 + shadow_strength * (1.0 - arr)
    arr = np.power(arr, gamma)
    return Image.fromarray((arr * 255).clip(0, 255).astype(np.uint8)).convert("L")


def draw_tile_indicator(
    tensor: torch.Tensor,
    full_w: int,
    full_h: int,
    tile_x: int,
    tile_y: int,
    tile_w: int,
    tile_h: int,
    line_width: int = 1,
) -> torch.Tensor:
    """Draw a red rectangle on a CHW tensor to mark the current tile position."""
    C, H, W = tensor.shape
    result = tensor.clone()

    scale_x = W / full_w
    scale_y = H / full_h

    x1 = max(0, min(int(tile_x * scale_x), W - 1))
    y1 = max(0, min(int(tile_y * scale_y), H - 1))
    x2 = max(0, min(int((tile_x + tile_w) * scale_x), W))
    y2 = max(0, min(int((tile_y + tile_h) * scale_y), H))

    red = torch.tensor([1.0, -1.0, -1.0], device=tensor.device, dtype=tensor.dtype)

    for dy in range(line_width):
        if y1 + dy < H:
            result[:, y1 + dy, x1:x2] = red.view(3, 1)
        if 0 <= y2 - 1 - dy < H:
            result[:, y2 - 1 - dy, x1:x2] = red.view(3, 1)

    for dx in range(line_width):
        if x1 + dx < W:
            result[:, y1:y2, x1 + dx] = red.view(3, 1)
        if 0 <= x2 - 1 - dx < W:
            result[:, y1:y2, x2 - 1 - dx] = red.view(3, 1)

    return result


def create_blend_weights(
    tile_size: int,
    overlap: int,
    is_top: bool = False,
    is_bottom: bool = False,
    is_left: bool = False,
    is_right: bool = False,
    device: str = "cpu",
) -> torch.Tensor:
    """Create cosine blend weights for a tile, ramping down at non-edge overlaps."""
    weights = torch.ones(tile_size, tile_size, device=device)

    if overlap > 0:
        ramp = 0.5 * (1 - torch.cos(torch.linspace(0, torch.pi, overlap, device=device)))
        if not is_top:
            weights[:overlap, :] *= ramp.view(-1, 1)
        if not is_bottom:
            weights[-overlap:, :] *= ramp.flip(0).view(-1, 1)
        if not is_left:
            weights[:, :overlap] *= ramp.view(1, -1)
        if not is_right:
            weights[:, -overlap:] *= ramp.flip(0).view(1, -1)

    return weights
