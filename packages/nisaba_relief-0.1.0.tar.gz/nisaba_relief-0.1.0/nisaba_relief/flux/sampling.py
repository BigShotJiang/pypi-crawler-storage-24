import math

import torch
from einops import rearrange
from torch import Tensor

from .model import Flux2


def prc_img_batch(x: Tensor) -> tuple[Tensor, Tensor]:
    b, _, h, w = x.shape
    x_ids = torch.cartesian_prod(
        torch.arange(1),
        torch.arange(h),
        torch.arange(w),
        torch.arange(1),
    )
    x_ids = x_ids.unsqueeze(0).expand(b, -1, -1)
    x = rearrange(x, "b c h w -> b (h w) c")
    return x, x_ids.to(x.device)


def generalized_time_snr_shift(t: Tensor, mu: float, sigma: float) -> Tensor:
    return math.exp(mu) / (math.exp(mu) + (1 / t - 1) ** sigma)


def compute_empirical_mu(image_seq_len: int, num_steps: int) -> float:
    a1, b1 = 8.73809524e-05, 1.89833333
    a2, b2 = 0.00016927, 0.45666666

    if image_seq_len > 4300:
        mu = a2 * image_seq_len + b2
        return float(mu)

    m_200 = a2 * image_seq_len + b2
    m_10 = a1 * image_seq_len + b1

    a = (m_200 - m_10) / 190.0
    b = m_200 - 200.0 * a
    mu = a * num_steps + b

    return float(mu)


def get_schedule(num_steps: int, image_seq_len: int) -> list[float]:
    mu = compute_empirical_mu(image_seq_len, num_steps)
    timesteps = torch.linspace(1, 0, num_steps + 1)
    timesteps = generalized_time_snr_shift(timesteps, mu, 1.0)
    return timesteps.tolist()


def denoise(
    model: Flux2,
    img: Tensor,
    img_ids: Tensor,
    txt: Tensor,
    txt_ids: Tensor,
    timesteps: list[float],
    img_cond_seq: Tensor | None = None,
    img_cond_seq_ids: Tensor | None = None,
) -> Tensor:
    if img_cond_seq is not None:
        assert img_cond_seq_ids is not None, (
            "You need to provide either both or neither of the sequence conditioning"
        )
        combined_ids = torch.cat((img_ids, img_cond_seq_ids), dim=1)
    else:
        combined_ids = img_ids

    # Pre-compute positional embeddings once (constant across all timesteps)
    pe_x = model.pe_embedder(combined_ids)
    pe_ctx = model.pe_embedder(txt_ids)

    for t_curr, t_prev in zip(timesteps[:-1], timesteps[1:]):
        t_vec = torch.full((img.shape[0],), t_curr, dtype=img.dtype, device=img.device)
        img_input = img
        if img_cond_seq is not None:
            img_input = torch.cat((img_input, img_cond_seq), dim=1)
        pred = model(
            x=img_input,
            x_ids=combined_ids,
            timesteps=t_vec,
            ctx=txt,
            ctx_ids=txt_ids,
            pe_x=pe_x,
            pe_ctx=pe_ctx,
        )
        pred = pred[:, : img.shape[1]]

        img = img + (t_prev - t_curr) * pred

    return img
