"""
NisabaRelief inference model.
Transforms cuneiform tablet images into MSII visualizations.
"""

import contextlib
import logging
from os import PathLike
from pathlib import Path

import gc
import torch
from einops import rearrange
from PIL import Image
from tqdm.auto import tqdm
from safetensors.torch import load_file

from .constants import (
    COND_SEQ_ID,
    DECODE_BATCH_SIZE_DIVISOR,
    GLOBAL_CTX_ID,
    LATENT_CHANNELS,
    MAX_ASPECT_RATIO,
    MAX_GLOBAL_CONTEXT_SIZE,
    MIN_IMAGE_DIMENSION,
    VRAM_FIXED_OVERHEAD_MB,
    VRAM_HEADROOM_MB,
    VRAM_MB_PER_PIXEL,
    MIN_BATCH_SIZE,
    MAX_BATCH_SIZE,
)

from .image_utils import (
    _to_tensor,
    compute_tile_grid,
    compute_tile_size,
    create_blend_weights,
    draw_tile_indicator,
    image_to_tensor,
    pad_to_patch_multiple,
    postprocess,
    round_to_patch,
    tensor_to_image,
)
from .weights import WEIGHT_FILES, download_weights
from .flux.autoencoder import AutoEncoder
from .flux.model import Flux2
from .flux.sampling import (
    denoise,
    get_schedule,
    prc_img_batch,
)

logger = logging.getLogger(__name__)


class NisabaRelief:
    """Transform cuneiform tablet images into MSII relief visualizations.

    Args:
        device: Device to run inference on (default "cuda" if available).
        num_steps: Number of denoising steps (default 2).
        weights_dir: Optional local weights directory. If None, uses HuggingFace Hub (boatbomber/NisabaRelief).
        batch_size: Batch size for processing tiles during inference.
            None (default) = auto-select based on available GPU memory each call.
            Set an explicit int to override.
        seed: Optional random seed for reproducible noise generation (default None).
        compile: Whether to use torch.compile for faster repeated inference (default True).
            Requires Triton. Set to False if Triton is not installed or for one-off runs.
    """

    def __init__(
        self,
        device: str = "cuda" if torch.cuda.is_available() else "cpu",
        num_steps: int = 2,
        weights_dir: PathLike | None = None,
        batch_size: int | None = None,
        seed: int | None = None,
        compile: bool = True,
    ):
        if batch_size is not None and batch_size < 1:
            raise ValueError(f"batch_size must be >= 1 or None, got {batch_size}")

        self.num_steps = num_steps
        self.device = device
        self.batch_size = batch_size
        self.seed = seed

        if weights_dir is not None:
            weights_dir = Path(weights_dir)
            if not weights_dir.is_dir():
                raise FileNotFoundError(f"weights_dir does not exist: {weights_dir}")

            missing = [f for f in WEIGHT_FILES if not (weights_dir / f).exists()]
            if missing:
                raise FileNotFoundError(
                    f"Missing weight files in {weights_dir}: {missing}"
                )

            weight_paths = {f: str(weights_dir / f) for f in WEIGHT_FILES}
        else:
            logger.info("Downloading weights from HuggingFace Hub...")
            weight_paths = download_weights()

        # Load AutoEncoder
        logger.debug("Loading AutoEncoder...")
        with torch.device("meta"):
            self.ae = AutoEncoder()
        ae_weights = load_file(weight_paths["ae.safetensors"], device=device)
        self.ae.load_state_dict(ae_weights, strict=True, assign=True)
        self.ae.decoder = self.ae.decoder.to(self.dtype)
        self.ae.eval()

        # Load finetuned FLUX.2 model (merged weights)
        logger.debug("Loading Transformer...")
        with torch.device("meta"):
            self.model = Flux2().to(self.dtype)
        model_weights = load_file(weight_paths["model.safetensors"], device=device)
        self.model.load_state_dict(model_weights, strict=True, assign=True)
        self.model = self.model.to(device=device, dtype=self.dtype).eval()

        # Load pre-computed text embedding
        logger.debug("Loading text embedding...")
        text_data = load_file(weight_paths["prompt_embedding.safetensors"], device=device)
        self.prompt_embedding = text_data["prompt_embedding"].to(self.dtype)
        self.ctx_ids = text_data["ctx_ids"]

        if compile and self.device_type == "cuda":
            try:
                self.model = torch.compile(self.model)
                self.ae = torch.compile(self.ae)
                logger.debug(
                    "Model compile mode enabled. First run will be slow, but subsequent runs will be faster."
                )
            except Exception as e:
                logger.error("Error compiling model: %s", e, exc_info=True)
                logger.warning("Falling back to non-compiled model")

        logger.info("NisabaRelief model loaded and ready")

    @property
    def device_type(self) -> str:
        return self.device.split(":")[0]

    @property
    def dtype(self) -> torch.dtype:
        if self.device_type == "cuda":
            return torch.bfloat16
        return torch.float32

    def _pick_batch_size(self, tile_size: int) -> int:
        """Estimate the largest safe batch size for a given tile size."""
        if self.device_type != "cuda":
            return MIN_BATCH_SIZE

        gc.collect()
        torch.cuda.empty_cache()

        try:
            device_idx = torch.device(self.device).index or 0
            free_vram_mb = (
                torch.cuda.get_device_properties(device_idx).total_memory
                - torch.cuda.memory_allocated(device_idx)
            ) / (1024**2)
            available = free_vram_mb - VRAM_HEADROOM_MB
            per_tile = VRAM_MB_PER_PIXEL * tile_size**2 + VRAM_FIXED_OVERHEAD_MB
            batch = max(MIN_BATCH_SIZE, min(MAX_BATCH_SIZE, int(available / per_tile)))
            logger.debug(
                "Auto batch_size=%d (tile=%d, free=%.0f MB, per_tile=%.0f MB)",
                batch,
                tile_size,
                free_vram_mb,
                per_tile,
            )
            return batch
        except Exception as e:
            logger.error("Error picking batch size: %s", e, exc_info=True)
            return MIN_BATCH_SIZE

    def __repr__(self) -> str:
        return (
            f"NisabaRelief(device={self.device!r}, num_steps={self.num_steps}, "
            f"batch_size={self.batch_size}, seed={self.seed!r})"
        )

    def process(
        self,
        image: PathLike | Image.Image,
        show_pbar: bool | None = None,
    ) -> Image.Image:
        """Transform a cuneiform tablet image into MSII visualization.

        Args:
            image: Input image (path or PIL Image).
            show_pbar: Whether to show a progress bar during tiled inference.
                If None (default), shows the bar only when there are at least 2 batches to run.

        Returns:
            PIL Image (grayscale) with MSII visualization.
        """
        if isinstance(image, (str, PathLike)):
            image = Image.open(image)
        if image.mode != "RGB":
            image = image.convert("RGB")

        w, h = image.size
        max_side = max(w, h)
        min_side = min(w, h)
        if min_side < MIN_IMAGE_DIMENSION:
            raise ValueError(
                f"Image too small: {min_side}px minimum side (need >= {MIN_IMAGE_DIMENSION}px)"
            )
        if max_side / min_side > MAX_ASPECT_RATIO:
            raise ValueError(
                f"Aspect ratio too extreme: {max_side / min_side:.1f}:1 (max {MAX_ASPECT_RATIO:.0f}:1)"
            )

        tile_size = compute_tile_size(max_side)
        output_image = self._process_tiled(
            image, tile_size=tile_size, show_pbar=show_pbar
        )

        return postprocess(output_image)

    def _prepare_global_context_tensor(
        self,
        image: Image.Image,
        max_size: int = MAX_GLOBAL_CONTEXT_SIZE,
    ) -> torch.Tensor:
        w, h = image.size
        scale = min(max_size / w, max_size / h)
        new_w = round_to_patch(w * scale)
        new_h = round_to_patch(h * scale)

        resized = image.resize((new_w, new_h), Image.Resampling.LANCZOS)
        return image_to_tensor(resized, self.device)

    def _encode_global_context_batch(
        self,
        img_tensors: list[torch.Tensor],
    ) -> tuple[torch.Tensor, torch.Tensor]:
        batch = torch.stack(img_tensors)
        with torch.inference_mode():
            global_latent = self.ae.encode(batch)
            global_tokens, global_ids = prc_img_batch(global_latent)
            global_ids[..., 0] = GLOBAL_CTX_ID
        return global_tokens.to(self.dtype), global_ids

    def _process_tile_batch(
        self,
        tiles: list[Image.Image],
        global_ctx_tokens: torch.Tensor,
        global_ctx_ids: torch.Tensor,
        tile_index_offset: int = 0,
    ) -> list[Image.Image]:
        b = len(tiles)
        original_sizes = [tile.size for tile in tiles]

        padded_tiles = [pad_to_patch_multiple(tile) for tile in tiles]
        img_tensors = torch.stack(
            [image_to_tensor(tile, self.device) for tile in padded_tiles]
        )

        with torch.inference_mode():
            input_latent = self.ae.encode(img_tensors)

            input_tokens, input_ids = prc_img_batch(input_latent)
            input_ids_cond = input_ids.clone()
            input_ids_cond[..., 0] = COND_SEQ_ID

            cond_tokens = torch.cat([input_tokens, global_ctx_tokens], dim=1)
            cond_ids = torch.cat([input_ids_cond, global_ctx_ids], dim=1)

            latent_h = input_latent.shape[2]
            latent_w = input_latent.shape[3]

            if self.seed is None:
                noise = torch.randn(
                    b,
                    LATENT_CHANNELS,
                    latent_h,
                    latent_w,
                    device=self.device,
                    dtype=self.dtype,
                )
            else:
                noise_list = []
                for i in range(b):
                    tile_seed = self.seed ^ (tile_index_offset + i)
                    generator = torch.Generator(device=self.device).manual_seed(tile_seed)
                    noise_list.append(
                        torch.randn(
                            LATENT_CHANNELS,
                            latent_h,
                            latent_w,
                            device=self.device,
                            dtype=self.dtype,
                            generator=generator,
                        )
                    )
                noise = torch.stack(noise_list)

            noise_tokens, _ = prc_img_batch(noise)
            noise_ids = input_ids

            seq_len = noise_tokens.shape[1]
            timesteps = get_schedule(self.num_steps, seq_len)

            ctx = self.prompt_embedding.unsqueeze(0).expand(b, -1, -1)
            ctx_ids = self.ctx_ids.unsqueeze(0).expand(b, -1, -1)

            autocast_ctx = (
                torch.autocast(device_type=self.device_type, dtype=self.dtype)
                if self.device_type == "cuda"
                else contextlib.nullcontext()
            )
            with autocast_ctx:
                output_tokens = denoise(
                    model=self.model,
                    img=noise_tokens.to(self.dtype),
                    img_ids=noise_ids,
                    txt=ctx.to(self.dtype),
                    txt_ids=ctx_ids,
                    timesteps=timesteps,
                    img_cond_seq=cond_tokens.to(self.dtype),
                    img_cond_seq_ids=cond_ids,
                )

            output_latent = rearrange(
                output_tokens,
                "b (h w) c -> b c h w",
                h=latent_h,
                w=latent_w,
            )

            # Free tensors from encode/denoise phases before AE decode to
            # avoid CUDA memory fragmentation (the decoder needs large
            # full-resolution float32 allocations that differ in shape from
            # the transformer's cached blocks).
            del img_tensors, input_latent, input_tokens, input_ids
            del input_ids_cond, cond_tokens, cond_ids
            del noise, noise_tokens, noise_ids
            del output_tokens, ctx, ctx_ids
            if self.device_type == "cuda":
                torch.cuda.empty_cache()

            # The AE decoder operates at full pixel resolution in float32,
            # requiring much more VRAM per tile than the latent-space denoiser.
            # Sub-batch to avoid overflowing into shared memory.
            decode_bs = max(1, b // DECODE_BATCH_SIZE_DIVISOR)
            if decode_bs >= b:
                output_imgs = self.ae.decode(output_latent)
            else:
                chunks = []
                for i in range(0, b, decode_bs):
                    chunks.append(self.ae.decode(output_latent[i : i + decode_bs]))
                    if self.device_type == "cuda":
                        torch.cuda.empty_cache()
                output_imgs = torch.cat(chunks, dim=0)

        results = []
        for i, (orig_w, orig_h) in enumerate(original_sizes):
            result = tensor_to_image(output_imgs[i])
            if padded_tiles[i].size != (orig_w, orig_h):
                result = result.crop((0, 0, orig_w, orig_h))
            results.append(result)

        return results

    def _process_tiled(
        self, image: Image.Image, tile_size: int, show_pbar: bool | None = None
    ) -> Image.Image:
        orig_w, orig_h = image.size
        n_cols, n_rows, w, h, pad_left, pad_top, overlap, stride = compute_tile_grid(
            orig_w, orig_h, tile_size
        )

        # Pad canvas so tiles land at exact stride positions with uniform overlap.
        # Center the image so padding is distributed evenly on all sides.
        padded = Image.new("RGB", (w, h), (0, 0, 0))
        padded.paste(image, (pad_left, pad_top))
        image = padded

        global_base_tensor = self._prepare_global_context_tensor(image)

        output = torch.zeros(3, h, w, device=self.device)
        weights = torch.zeros(1, h, w, device=self.device)

        tile_specs = [
            (row, col, col * stride, row * stride)
            for row in range(n_rows)
            for col in range(n_cols)
        ]

        blend_cache: dict[tuple[bool, bool, bool, bool], torch.Tensor] = {}

        batch_size = (
            self.batch_size
            if self.batch_size is not None
            else self._pick_batch_size(tile_size)
        )

        if show_pbar is None:
            show_pbar = len(tile_specs) >= 2 * batch_size

        pbar = tqdm(
            total=len(tile_specs),
            desc=f"Processing {orig_w}x{orig_h} px image with {n_cols}x{n_rows} tiles ({tile_size} px each, {overlap} px overlap)",
            unit="tile",
            leave=False,
            disable=not show_pbar,
        )

        for batch_start in range(0, len(tile_specs), batch_size):
            batch_specs = tile_specs[batch_start : batch_start + batch_size]

            pbar.clear()
            logger.debug(
                "Processing %d batched tiles: %s",
                len(batch_specs),
                " + ".join([f"({row},{col})" for row, col, _, _ in batch_specs]),
            )
            pbar.refresh()

            ctx_tensors = [
                draw_tile_indicator(global_base_tensor, w, h, x, y, tile_size, tile_size)
                for (row, col, x, y) in batch_specs
            ]
            global_tokens, global_ids = self._encode_global_context_batch(ctx_tensors)

            tiles = [
                image.crop((x, y, x + tile_size, y + tile_size))
                for (row, col, x, y) in batch_specs
            ]

            result_tiles = self._process_tile_batch(
                tiles, global_tokens, global_ids, tile_index_offset=batch_start
            )

            for i, (row, col, x, y) in enumerate(batch_specs):
                edge_key = (
                    row == 0,
                    row == n_rows - 1,
                    col == 0,
                    col == n_cols - 1,
                )
                if edge_key not in blend_cache:
                    blend_cache[edge_key] = create_blend_weights(
                        tile_size,
                        overlap,
                        is_top=edge_key[0],
                        is_bottom=edge_key[1],
                        is_left=edge_key[2],
                        is_right=edge_key[3],
                        device=self.device,
                    )
                blend = blend_cache[edge_key]
                result_tensor = _to_tensor(result_tiles[i]).to(self.device)
                output[:, y : y + tile_size, x : x + tile_size] += result_tensor * blend
                weights[:, y : y + tile_size, x : x + tile_size] += blend

            if self.device_type == "cuda":
                torch.cuda.empty_cache()

            pbar.update(len(batch_specs))

        pbar.close()

        output = output / weights.clamp(min=1e-6)
        output = output.permute(1, 2, 0).cpu().numpy()
        output = (output * 255).clip(0, 255).astype("uint8")
        return Image.fromarray(output).crop(
            (pad_left, pad_top, pad_left + orig_w, pad_top + orig_h)
        )
