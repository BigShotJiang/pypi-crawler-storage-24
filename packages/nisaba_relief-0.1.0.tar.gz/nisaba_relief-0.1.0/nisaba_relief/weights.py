"""HuggingFace Hub weight downloading for NisabaRelief."""

from huggingface_hub import hf_hub_download

HF_REPO_ID = "boatbomber/NisabaRelief"
WEIGHT_FILES = [
    "ae.safetensors",
    "model.safetensors",
    "prompt_embedding.safetensors",
]


def download_weights(repo_id: str = HF_REPO_ID) -> dict[str, str]:
    """Download all weight files from HF Hub, returning {filename: local_path}."""
    paths = {}
    for filename in WEIGHT_FILES:
        try:
            paths[filename] = hf_hub_download(repo_id=repo_id, filename=filename)
        except Exception as e:
            raise RuntimeError(
                f"Failed to download {filename} from {repo_id}: {e}"
            ) from e
    return paths
