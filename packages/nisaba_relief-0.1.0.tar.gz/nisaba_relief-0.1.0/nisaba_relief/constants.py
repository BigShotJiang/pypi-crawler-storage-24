"""Named constants for NisabaRelief magic numbers."""

# Flux model processes images in 16×16 pixel patches
PATCH_SIZE = 16

# Tile size bounds: 12 patches (192px) to 64 patches (1024px)
MIN_TILE = PATCH_SIZE * 12  # 192
MAX_TILE = PATCH_SIZE * 64  # 1024

# Aims for ~4 tiles along the longest axis when computing tile size
TARGET_TILES_PER_SIDE = 4

# Overlap is 1/8 of the tile size, giving a smooth cosine blend region
TILE_OVERLAP_DIVISOR = 8

# Smallest accepted input side in pixels
MIN_IMAGE_DIMENSION = MIN_TILE * 2

# Maximum allowed aspect ratio (width:height or height:width)
MAX_ASPECT_RATIO = 8.0

# Maximum size (px) for the global context thumbnail
MAX_GLOBAL_CONTEXT_SIZE = 128

# Positional sequence ID for conditioning tokens (image being processed)
COND_SEQ_ID = 10

# Positional sequence ID for global context tokens (thumbnail overview)
GLOBAL_CTX_ID = 20

# Number of latent channels in the Flux model's latent space
LATENT_CHANNELS = 128

# Dynamic batch_size constants. Determined empirically on an RTX 3090.
MAX_BATCH_SIZE = 16
MIN_BATCH_SIZE = 1
VRAM_MB_PER_PIXEL = 0.0035
VRAM_FIXED_OVERHEAD_MB = 15.0
VRAM_HEADROOM_MB = 1024.0

# Divisor for AE decoder sub-batching (decoder needs more VRAM than denoiser)
DECODE_BATCH_SIZE_DIVISOR = 5
