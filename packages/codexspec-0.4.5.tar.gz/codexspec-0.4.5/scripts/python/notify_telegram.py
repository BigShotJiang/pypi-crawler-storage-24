#!/usr/bin/env python3
"""
Telegram Notifier for Claude Monitor
从 stdin 读取 claude_monitor.py --json 的输出，发送通知到 Telegram

Features:
- 丰富的日志输出（时间戳、Emoji、详细信息）
- 日志文件持久化和轮转
- 自动重试机制
- 降级处理

Usage:
    python claude_monitor.py --json | python notify_telegram.py
"""

import json
import os
import sys
import time
import urllib.error
import urllib.request
from datetime import datetime
from pathlib import Path
from typing import Any, Callable, Dict, Optional, Tuple

from dotenv import load_dotenv

# 从 .env 文件加载环境变量
load_dotenv()


# ============================================================================
# Config 类 - 配置管理
# ============================================================================


class Config:
    """
    集中管理所有配置参数，从环境变量读取

    Attributes:
        BOT_TOKEN: Telegram Bot Token（必需）
        CHAT_ID: Telegram Chat ID（必需）
        PROXY: 代理地址
        LOG_FILE: 自定义日志文件路径
        RETRY_COUNT: 最大重试次数
        RETRY_INTERVAL: 重试间隔（秒）
        NOTIFY_ON_COMPLETE: 任务完成通知开关
        NOTIFY_ON_USER_QUESTION: 用户询问通知开关
        NOTIFY_ON_ERROR: 错误通知开关
        NOTIFY_ON_PENDING_PERMISSION: 权限请求通知开关
    """

    def __init__(self):
        # 必需的环境变量
        self.BOT_TOKEN = os.environ.get("TELEGRAM_BOT_TOKEN")
        self.CHAT_ID = os.environ.get("TELEGRAM_CHAT_ID")

        # 验证必需变量
        if not self.BOT_TOKEN:
            raise ValueError("Missing required environment variable: TELEGRAM_BOT_TOKEN")
        if not self.CHAT_ID:
            raise ValueError("Missing required environment variable: TELEGRAM_CHAT_ID")

        # 可选环境变量（有默认值）
        self.PROXY = os.environ.get("TELEGRAM_PROXY", "http://127.0.0.1:7890")
        self.LOG_FILE: Optional[str] = os.environ.get("TELEGRAM_LOG_FILE")
        self.RETRY_COUNT = int(os.environ.get("TELEGRAM_RETRY_COUNT", "3"))
        self.RETRY_INTERVAL = int(os.environ.get("TELEGRAM_RETRY_INTERVAL", "1"))

        # 通知开关
        self.NOTIFY_ON_COMPLETE = os.environ.get("NOTIFY_ON_COMPLETE", "true").lower() == "true"
        self.NOTIFY_ON_USER_QUESTION = os.environ.get("NOTIFY_ON_USER_QUESTION", "true").lower() == "true"
        self.NOTIFY_ON_ERROR = os.environ.get("NOTIFY_ON_ERROR", "true").lower() == "true"
        self.NOTIFY_ON_PENDING_PERMISSION = os.environ.get("NOTIFY_ON_PENDING_PERMISSION", "true").lower() == "true"


# ============================================================================
# Logger 类 - 日志处理
# ============================================================================


class Logger:
    """
    日志处理器，支持：
    - 丰富的格式化输出（时间戳、Emoji、缩进详情）
    - 同时输出到 stderr 和文件
    - 日志文件轮转（按日期和大小）
    - 降级处理（文件不可写时仅输出 stderr）

    Attributes:
        config: Config 实例
        _file_enabled: 文件写入是否启用
        _file_handle: 当前日志文件句柄
        _current_log_path: 当前日志文件路径
        _current_date: 当前日期字符串
    """

    # Emoji 映射表
    _EMOJI_MAP = {
        "startup": "🚀",
        "waiting": "ℹ️",
        "success": "✅",
        "retry": "⚠️",
        "failure": "❌",
    }

    # 日志轮转配置
    _MAX_FILE_SIZE = 10 * 1024 * 1024  # 10MB
    _MAX_ERROR_LENGTH = 500  # 错误消息最大长度

    def __init__(self, config: Config):
        self.config = config
        self._file_enabled = True
        self._file_handle: Optional[Any] = None
        self._current_log_path: Optional[Path] = None
        self._current_date: Optional[str] = None

        # 初始化日志文件路径
        self._init_log_path()

    def _init_log_path(self) -> None:
        """初始化日志文件路径"""
        if self.config.LOG_FILE:
            # 使用自定义路径
            log_path = Path(self.config.LOG_FILE).expanduser()
        else:
            # 使用默认路径：脚本目录/logs/notify_YYYY-MM-DD.log
            script_dir = Path(__file__).parent
            logs_dir = script_dir / "logs"
            today = datetime.now().strftime("%Y-%m-%d")
            log_path = logs_dir / f"notify_{today}.log"

        self._base_log_path = log_path
        self._current_date = datetime.now().strftime("%Y-%m-%d")

    def _format_timestamp(self) -> str:
        """格式化当前时间戳"""
        return datetime.now().strftime("%Y-%m-%d %H:%M:%S")

    def _mask_chat_id(self, chat_id: str) -> str:
        """脱敏显示 Chat ID（只显示后4位）"""
        if len(chat_id) <= 4:
            return "*" * (len(chat_id) - 1) + chat_id[-1]
        return "****" + chat_id[-4:]

    def _format(self, level: str, message: str, details: Optional[Dict[str, Any]] = None) -> str:
        """
        格式化日志消息

        Args:
            level: 日志级别（startup/waiting/success/retry/failure）
            message: 主消息
            details: 详细信息键值对

        Returns:
            格式化的日志字符串
        """
        timestamp = self._format_timestamp()
        emoji = self._EMOJI_MAP.get(level, "ℹ️")

        lines = [f"[{timestamp}] {emoji} {message}"]

        if details:
            # 格式化详细信息为一行
            detail_str = " | ".join(f"{k}: {v}" for k, v in details.items())
            lines.append(f"    └─ {detail_str}")

        return "\n".join(lines)

    def _output(self, formatted_message: str) -> None:
        """
        输出日志到 stderr 和文件

        Args:
            formatted_message: 已格式化的日志消息
        """
        # 始终输出到 stderr
        print(formatted_message, file=sys.stderr)

        # 如果文件写入启用，同时写入文件
        if self._file_enabled:
            try:
                self._write_to_file(formatted_message)
            except Exception:
                # 文件写入失败，降级为仅 stderr
                self._file_enabled = False

    def _write_to_file(self, message: str) -> None:
        """写入日志到文件（延迟打开，追加模式）"""
        # 检查是否需要轮转
        self._check_rotation()

        # 确保文件已打开
        if self._file_handle is None:
            self._open_file()

        # 写入消息
        if self._file_handle:
            self._file_handle.write(message + "\n")
            self._file_handle.flush()

    def _open_file(self) -> None:
        """打开日志文件（延迟打开）"""
        try:
            # 确保目录存在
            log_dir = self._current_log_path.parent if self._current_log_path else self._base_log_path.parent
            log_dir.mkdir(parents=True, exist_ok=True)

            # 确定当前日志文件路径
            if self._current_log_path is None:
                self._current_log_path = self._base_log_path

            # 打开文件（追加模式）
            self._file_handle = open(self._current_log_path, "a", encoding="utf-8")
        except (IOError, OSError) as e:
            # 文件打开失败，降级为仅 stderr
            print(f"[WARNING] Cannot open log file: {e}", file=sys.stderr)
            self._file_enabled = False

    def _check_rotation(self) -> None:
        """检查是否需要轮转日志文件"""
        today = datetime.now().strftime("%Y-%m-%d")

        # 检查日期变化
        if self._current_date != today:
            self._rotate_by_date()
            self._current_date = today

        # 确定要检查的文件路径
        check_path = self._current_log_path or self._base_log_path

        # 检查文件大小
        if check_path and check_path.exists():
            if check_path.stat().st_size >= self._MAX_FILE_SIZE:
                self._rotate_by_size()

    def _rotate_by_date(self) -> None:
        """按日期轮转日志文件"""
        # 关闭当前文件
        if self._file_handle:
            self._file_handle.close()
            self._file_handle = None

        # 更新基础路径为新日期
        if not self.config.LOG_FILE:
            script_dir = Path(__file__).parent
            logs_dir = script_dir / "logs"
            today = datetime.now().strftime("%Y-%m-%d")
            self._base_log_path = logs_dir / f"notify_{today}.log"

        self._current_log_path = self._base_log_path

    def _rotate_by_size(self) -> None:
        """按大小轮转日志文件"""
        if self._file_handle:
            self._file_handle.close()
            self._file_handle = None

        # 找到下一个可用的序号
        next_index = self._get_next_rotation_index()

        # 创建新的日志文件路径
        stem = self._base_log_path.stem
        suffix = self._base_log_path.suffix
        parent = self._base_log_path.parent
        self._current_log_path = parent / f"{stem}_{next_index}{suffix}"

    def _get_next_rotation_index(self) -> int:
        """获取下一个轮转序号"""
        stem = self._base_log_path.stem
        suffix = self._base_log_path.suffix
        parent = self._base_log_path.parent

        index = 1
        while True:
            rotated_path = parent / f"{stem}_{index}{suffix}"
            if not rotated_path.exists():
                return index
            index += 1

    def _truncate_error(self, error: str) -> str:
        """截断过长的错误消息"""
        if len(error) > self._MAX_ERROR_LENGTH:
            return error[: self._MAX_ERROR_LENGTH] + "..."
        return error

    def _escape_special_chars(self, text: str) -> str:
        """转义特殊字符，确保单行日志可读性"""
        # 替换换行符和其他控制字符
        text = text.replace("\n", "\\n")
        text = text.replace("\r", "\\r")
        text = text.replace("\t", "\\t")
        return text

    # =========================================================================
    # 公共日志方法
    # =========================================================================

    def log_startup(self, chat_id: str, proxy: str, log_path: str) -> None:
        """
        记录启动日志

        Args:
            chat_id: Chat ID（将被脱敏）
            proxy: 代理地址
            log_path: 日志文件路径
        """
        masked_chat_id = self._mask_chat_id(chat_id)

        # 主消息
        main_msg = self._format("startup", "Telegram Notifier 启动")

        # 详细信息行
        details = [
            f"    └─ Chat ID: {masked_chat_id} | Proxy: {proxy}",
            f"    └─ 日志文件: {log_path}",
        ]

        full_msg = main_msg + "\n" + "\n".join(details)
        self._output(full_msg)

    def log_waiting(self) -> None:
        """记录等待状态日志"""
        formatted = self._format("waiting", "等待事件中...")
        self._output(formatted)

    def log_success(self, event_type: str, session_id: str, details: Dict[str, Any], retry_count: int = 0) -> None:
        """
        记录成功日志

        Args:
            event_type: 事件类型
            session_id: Session ID
            details: 详细信息
            retry_count: 重试次数（0 表示首次成功）
        """
        message = "通知发送成功" if retry_count == 0 else "通知发送成功 (重试后)"

        log_details = {"类型": event_type, "Session": session_id}
        log_details.update(details)

        if retry_count > 0:
            log_details["重试次数"] = str(retry_count)

        formatted = self._format("success", message, log_details)
        self._output(formatted)

    def log_retry(self, event_type: str, session_id: str, error: str, attempt: int, max_attempts: int) -> None:
        """
        记录重试日志

        Args:
            event_type: 事件类型
            session_id: Session ID
            error: 错误信息
            attempt: 当前重试次数
            max_attempts: 最大重试次数
        """
        message = f"发送失败 (重试 {attempt}/{max_attempts})"
        truncated_error = self._truncate_error(error)
        escaped_error = self._escape_special_chars(truncated_error)

        details = {"类型": event_type, "Session": session_id, "错误": escaped_error}
        formatted = self._format("retry", message, details)
        self._output(formatted)

    def log_failure(self, event_type: str, session_id: str, error: str, retry_count: int) -> None:
        """
        记录最终失败日志

        Args:
            event_type: 事件类型
            session_id: Session ID
            error: 错误信息
            retry_count: 总重试次数
        """
        message = "发送最终失败"
        truncated_error = self._truncate_error(error)
        escaped_error = self._escape_special_chars(truncated_error)

        details = {
            "类型": event_type,
            "Session": session_id,
            "错误": escaped_error,
            "重试次数": str(retry_count),
        }
        formatted = self._format("failure", message, details)
        self._output(formatted)

    def close(self) -> None:
        """关闭日志文件句柄"""
        if self._file_handle:
            self._file_handle.close()
            self._file_handle = None


# ============================================================================
# RetryHandler 类 - 重试逻辑
# ============================================================================


class RetryHandler:
    """
    封装重试逻辑

    Attributes:
        max_retries: 最大重试次数
        interval: 重试间隔（秒）
    """

    def __init__(self, max_retries: int = 3, interval: float = 1.0):
        self.max_retries = max_retries
        self.interval = interval

    def execute_with_retry(
        self,
        func: Callable[[], Tuple[bool, Optional[str]]],
        on_retry: Optional[Callable[[int, str], None]] = None,
    ) -> Tuple[bool, int, Optional[str]]:
        """
        执行函数并在失败时重试

        Args:
            func: 要执行的函数，返回 (success, error_message)
            on_retry: 重试时的回调函数，接收 (attempt, error_message)

        Returns:
            (success, retry_count, last_error)
        """
        last_error: Optional[str] = None
        retry_count = 0

        for attempt in range(self.max_retries + 1):
            success, error = func()

            if success:
                return (True, retry_count, None)

            last_error = error

            if attempt < self.max_retries:
                retry_count += 1
                if on_retry and error:
                    on_retry(retry_count, error)
                time.sleep(self.interval)

        return (False, retry_count, last_error)


# ============================================================================
# TelegramNotifier 类 - 通知发送
# ============================================================================


class TelegramNotifier:
    """
    Telegram 通知发送器，集成日志和重试机制
    """

    # 事件类型映射
    EVENT_TYPES = {
        "TASK_COMPLETE": "任务完成",
        "USER_QUESTION": "用户询问",
        "ERROR_STOP": "错误通知",
        "PENDING_PERMISSION": "权限请求",
    }

    def __init__(self, config: Config, logger: Logger, retry_handler: RetryHandler):
        self.config = config
        self.logger = logger
        self.retry_handler = retry_handler

    def send(self, message: str, event_type: str, session_id: str) -> Tuple[bool, int]:
        """
        发送 Telegram 消息（带重试）

        Args:
            message: 消息内容
            event_type: 事件类型
            session_id: Session ID

        Returns:
            (success, retry_count)
        """

        def do_send() -> Tuple[bool, Optional[str]]:
            return self._send_telegram_message(message)

        def on_retry(attempt: int, error: str) -> None:
            self.logger.log_retry(event_type, session_id[:8], error, attempt, self.retry_handler.max_retries)

        success, retry_count, last_error = self.retry_handler.execute_with_retry(do_send, on_retry)

        if success:
            self.logger.log_success(event_type, session_id[:8], {}, retry_count)
            return (True, retry_count)
        else:
            self.logger.log_failure(event_type, session_id[:8], last_error or "Unknown error", retry_count)
            return (False, retry_count)

    def _send_telegram_message(self, text: str, parse_mode: str = "HTML") -> Tuple[bool, Optional[str]]:
        """
        发送 Telegram 消息

        Args:
            text: 消息内容
            parse_mode: 解析模式

        Returns:
            (success, error_message)
        """
        url = f"https://api.telegram.org/bot{self.config.BOT_TOKEN}/sendMessage"

        payload = {
            "chat_id": self.config.CHAT_ID,
            "text": text,
            "parse_mode": parse_mode,
        }

        data = json.dumps(payload).encode("utf-8")
        headers = {"Content-Type": "application/json"}

        # 设置代理
        if self.config.PROXY:
            handler = urllib.request.ProxyHandler({"http": self.config.PROXY, "https": self.config.PROXY})
            opener = urllib.request.build_opener(handler)
        else:
            opener = urllib.request.build_opener()

        req = urllib.request.Request(url, data=data, headers=headers, method="POST")

        try:
            with opener.open(req, timeout=30) as response:
                result = json.loads(response.read().decode("utf-8"))
                if result.get("ok"):
                    return (True, None)
                else:
                    error_msg = f"Telegram API error: {result}"
                    return (False, error_msg)
        except urllib.error.URLError as e:
            return (False, str(e))
        except Exception as e:
            return (False, str(e))

    def process_event(self, line: str) -> Optional[str]:
        """
        处理单个事件

        Args:
            line: JSON 行

        Returns:
            格式化的消息，如果不需通知则返回 None
        """
        try:
            data = json.loads(line)
        except json.JSONDecodeError:
            return None

        status = data.get("status")
        session_id = data.get("session_id", "unknown")[:8]

        if status == "TASK_COMPLETE" and self.config.NOTIFY_ON_COMPLETE:
            return self.format_task_complete(data)
        elif status == "USER_QUESTION" and self.config.NOTIFY_ON_USER_QUESTION:
            return self.format_user_question(data)
        elif status == "ERROR_STOP" and self.config.NOTIFY_ON_ERROR:
            return self.format_error(data)
        elif status == "PENDING_PERMISSION" and self.config.NOTIFY_ON_PENDING_PERMISSION:
            return self.format_pending_permission(data)

        return None

    @staticmethod
    def escape_html(text: str) -> str:
        """转义 HTML 特殊字符"""
        return text.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")

    def format_task_complete(self, data: dict) -> str:
        """格式化任务完成通知"""
        session_id = data.get("session_id", "unknown")[:8]
        stop_reason = data.get("stop_reason", "unknown")
        output = data.get("output", "")

        # 截断输出
        if output and len(output) > 500:
            output = output[:500] + "\n... (已截断)"

        lines = [
            "✅ <b>Claude Code 任务完成</b>",
            "",
            f"📌 Session: <code>{session_id}</code>",
            f"🔄 Stop reason: {stop_reason}",
        ]

        if output:
            lines.append("")
            lines.append("📝 <b>输出:</b>")
            lines.append(f"<pre>{self.escape_html(output)}</pre>")

        return "\n".join(lines)

    def format_user_question(self, data: dict) -> str:
        """格式化用户询问通知"""
        session_id = data.get("session_id", "unknown")[:8]
        questions = data.get("questions", [])

        lines = [
            "❓ <b>Claude Code 需要你的输入</b>",
            "",
            f"📌 Session: <code>{session_id}</code>",
        ]

        for i, q in enumerate(questions, 1):
            question = q.get("question", "")
            header = q.get("header", "")
            options = q.get("options", [])
            multi_select = q.get("multi_select", False)

            lines.append("")
            lines.append(f"<b>问题 {i}:</b> {self.escape_html(question)}")
            if header:
                lines.append(f"📋 {self.escape_html(header)}")

            if options:
                lines.append("<b>选项:</b>")
                for opt in options:
                    label = opt.get("label", "")
                    desc = opt.get("description", "")
                    lines.append(f"  • {self.escape_html(label)} - {self.escape_html(desc)}")

            if multi_select:
                lines.append("☑️ 可多选")

        return "\n".join(lines)

    def format_error(self, data: dict) -> str:
        """格式化错误通知"""
        session_id = data.get("session_id", "unknown")[:8]
        error = data.get("error", {})

        error_type = error.get("type", "unknown")
        message = error.get("message", "Unknown error")
        tool_name = error.get("tool_name")

        lines = [
            "❌ <b>Claude Code 执行出错</b>",
            "",
            f"📌 Session: <code>{session_id}</code>",
            f"🔴 Error type: {error_type}",
            f"💬 Message: {self.escape_html(message)}",
        ]

        if tool_name:
            lines.append(f"🔧 Tool: {self.escape_html(tool_name)}")

        return "\n".join(lines)

    def format_pending_permission(self, data: dict) -> str:
        """格式化工具权限询问通知"""
        session_id = data.get("session_id", "unknown")[:8]
        tools = data.get("tools", [])

        lines = [
            "⏳ <b>Claude Code 等待权限确认</b>",
            "",
            f"📌 Session: <code>{session_id}</code>",
        ]

        for i, tool in enumerate(tools, 1):
            name = tool.get("name", "unknown")
            description = tool.get("description", "")
            tool_input = tool.get("input", {})

            lines.append("")
            lines.append(f"🔧 <b>工具 {i}:</b> {self.escape_html(name)}")

            if description:
                lines.append(f"📝 {self.escape_html(description)}")

            if tool_input:
                lines.append("<b>参数:</b>")
                for key, value in tool_input.items():
                    value_str = str(value)
                    if len(value_str) > 100:
                        value_str = value_str[:100] + "..."
                    lines.append(f"  • {key}: {self.escape_html(value_str)}")

        return "\n".join(lines)


# ============================================================================
# 主循环
# ============================================================================


def main():
    """主循环 - 从 stdin 读取 JSON 行并发送通知"""
    # 初始化配置
    try:
        config = Config()
    except ValueError as e:
        print(f"[ERROR] {e}", file=sys.stderr)
        print("[ERROR] Please set these in your .env file or environment", file=sys.stderr)
        sys.exit(1)

    # 初始化日志
    logger = Logger(config)

    # 初始化重试处理器
    retry_handler = RetryHandler(
        max_retries=config.RETRY_COUNT,
        interval=config.RETRY_INTERVAL,
    )

    # 初始化通知发送器
    notifier = TelegramNotifier(config, logger, retry_handler)

    # 输出启动日志
    log_path_str = str(logger._base_log_path) if logger._base_log_path else "N/A"
    logger.log_startup(config.CHAT_ID, config.PROXY, log_path_str)
    logger.log_waiting()

    # 主循环
    for line in sys.stdin:
        line = line.strip()
        if not line:
            continue

        message = notifier.process_event(line)
        if message:
            event_data = json.loads(line)
            event_type = TelegramNotifier.EVENT_TYPES.get(event_data.get("status"), "未知事件")
            session_id = event_data.get("session_id", "unknown")

            notifier.send(message, event_type, session_id)


if __name__ == "__main__":
    main()
