class KnownProviders:
    Anthropic = 'anthropic'