from abc import ABC
from HowdenLLM.providers.base_provider import BaseProvider
from anthropic import Anthropic
import os
from dotenv import load_dotenv

class AnthropicProvider(BaseProvider, ABC):
    provider = "anthropic"

    def __init__(self):
        load_dotenv()
        self.client = Anthropic(api_key=os.getenv("ANTHROPIC_API_KEY"))

    def complete(self, system: str, prompt: str, model: str, use_web_search_tool: bool) -> str:
        if model in ["claude-opus-4-6","claude-sonnet-4-6"]:
            message = self.client.messages.create(
                model=model,
                system=system,
                messages=[
                    {"role": "user","content": prompt}
                ],
                max_tokens=16000,
                temperature=0.0

            )
        else:
            raise Exception(f"Unsupported model: {model}")

        return message.content[0].text
