from abc import ABC
from HowdenLLM.providers.base_provider import BaseProvider
from openai import OpenAI, AsyncOpenAI
import os
from dotenv import load_dotenv
import asyncio


SEMAPHORE = asyncio.Semaphore(3)

class OpenAIProvider(BaseProvider, ABC):
    provider = "openai"

    def __init__(self):
        load_dotenv()
        self.client =  AsyncOpenAI(api_key=os.getenv("OPENAI_API_KEY"))

    async def complete(self, system: str, prompt: str, model: str, use_web_search_tool: bool) -> str:
        async with SEMAPHORE:
            if use_web_search_tool:
                tools = [
                    { "type": "web_search" }
                ]
            else:
                tools = None

            if model in ["gpt-5", "gpt-5-mini", "gpt-5-nano"]:
                response = await self.client.responses.create(
                    model=model,
                    input=[
                        {"role": "system", "content": system},
                        {"role": "user", "content": prompt}
                    ],
                    tools=tools,
                    max_output_tokens=16000
                )
            else:
                raise Exception(f"Unsupported model: {model}")

            return response.output_text
