"""Output formatting utilities."""

import json
import sys
from typing import Any

import pandas as pd


def format_output(data: Any, format_type: str = "json") -> None:
    """Format and print output data.

    Args:
        data: Data to output (dict, list, DataFrame, etc.)
        format_type: Output format - json, table, csv, or markdown
    """
    if format_type == "json":
        _output_json(data)
    elif format_type == "table":
        _output_table(data)
    elif format_type == "csv":
        _output_csv(data)
    elif format_type == "markdown" or format_type == "md":
        _output_markdown(data)
    else:
        print(f"Error: Unknown format type '{format_type}'", file=sys.stderr)
        sys.exit(1)


def _output_json(data: Any) -> None:
    """Output data as JSON."""
    if isinstance(data, pd.DataFrame):
        # Convert DataFrame to dict with orient='records'
        print(json.dumps(data.to_dict(orient="records"), indent=2, ensure_ascii=False))
    else:
        print(json.dumps(data, indent=2, ensure_ascii=False))


def _output_table(data: Any) -> None:
    """Output data as table."""
    if isinstance(data, pd.DataFrame):
        print(data.to_string())
    elif isinstance(data, list) and len(data) > 0:
        # Convert list of dicts to DataFrame
        df = pd.DataFrame(data)
        print(df.to_string())
    elif isinstance(data, dict):
        # Convert single dict to DataFrame
        df = pd.DataFrame([data])
        print(df.to_string())
    else:
        print(data)


def _output_csv(data: Any) -> None:
    """Output data as CSV."""
    if isinstance(data, pd.DataFrame):
        print(data.to_csv(index=False))
    elif isinstance(data, list) and len(data) > 0:
        # Convert list of dicts to DataFrame
        df = pd.DataFrame(data)
        print(df.to_csv(index=False))
    elif isinstance(data, dict):
        # Convert single dict to DataFrame
        df = pd.DataFrame([data])
        print(df.to_csv(index=False))
    else:
        print(data)


def _output_markdown(data: Any) -> None:
    """Output data as Markdown table."""
    if isinstance(data, pd.DataFrame):
        print(data.to_markdown(index=False))
    elif isinstance(data, list) and len(data) > 0:
        # Convert list of dicts to DataFrame
        df = pd.DataFrame(data)
        print(df.to_markdown(index=False))
    elif isinstance(data, dict):
        # Convert single dict to DataFrame
        df = pd.DataFrame([data])
        print(df.to_markdown(index=False))
    else:
        print(data)
