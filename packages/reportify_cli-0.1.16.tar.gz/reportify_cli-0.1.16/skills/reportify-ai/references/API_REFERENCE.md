# Reportify API Reference

## Common Parameters

### Symbol Format
Stock symbols must use `market:ticker` format:
- **Shanghai Exchange**: `SH:ticker` (e.g., `SH:600519` for Kweichow Moutai)
- **Shenzhen Exchange**: `SZ:ticker` (e.g., `SZ:000001` for Ping An Bank)
- **Hong Kong**: `HK:ticker` (e.g., `HK:00700` for Tencent)
- **US Market**: `US:ticker` (e.g., `US:AAPL` for Apple, `US:TSLA` for Tesla)

### Date/Time Format
- **Date**: `YYYY-MM-DD` (e.g., `2024-01-15`)
- **DateTime**: `YYYY-MM-DD HH:MM:SS` (e.g., `2024-01-15 09:30:00`)

### Output Formats
- `json` - JSON (default)
- `table` - Formatted table
- `csv` - CSV format
- `markdown` / `md` - Markdown table

---

## Search Module Parameters

### search query
| Parameter | Type | Required | Default | Description |
|-----------|------|----------|---------|-------------|
| `query` | string | ✓ | - | Search keywords |
| `num` | int | | 10 | Results count (max 100) |
| `categories` | list[str] | | - | Filter: news, reports, filings, transcripts, socials |
| `symbols` | list[str] | | - | Stock symbols in market:ticker format (e.g., US:AAPL, HK:00700) |
| `industries` | list[str] | | - | Industry filter |
| `channel_ids` | list[str] | | - | Channel ID filter |
| `start_datetime` | str | | - | Start time |
| `end_datetime` | str | | - | End time |

### search filings / conference_calls / earnings_pack
| Parameter | Type | Required | Default | Description |
|-----------|------|----------|---------|-------------|
| `query` | string | | - | Search keywords (optional, if not provided returns documents sorted by date desc; if provided, sorts by relevance) |
| `symbols` | list[str] | ✓ | - | Stock symbols in market:ticker format (required) |
| `num` | int | | 10 | Results count |
| `fiscal_year` | str | | - | Fiscal year (e.g., "2025") |
| `fiscal_quarter` | str | | - | Fiscal quarter (Q1-Q4) |

### search crawl
| Parameter | Type | Required | Default | Description                                                                 |
|-----------|------|----------|---------|-----------------------------------------------------------------------------|
| `urls` | list[str] | ✓ | - | List of URLs to crawl                                                       |
| `text` | bool/dict | | true | Extract full text content(set true), or pass dict for advanced options |
| `text.max_characters` | int | | - | Maximum characters to return per page                                       |
| `text.include_html_tags` | bool | | false | Whether to preserve HTML tags                                               |
| `text.verbosity` | string | | "full" | `compact` (removes boilerplate) or `full` (complete content)                |
| `highlights` | dict | | - | Extract query-relevant highlights                                           |
| `highlights.query` | string | | - | Query for extracting relevant highlights                                    |
| `highlights.max_characters` | int | | - | Max characters per highlight                                                |
| `highlights.num_sentences` | int | | 5 | Number of sentences per highlight                                           |
| `highlights.highlights_per_url` | int | | 1 | Number of highlights per URL                                                |
| `summary` | dict | | - | LLM-generated summary                                                       |
| `summary.query` | string | | - | Query instruction for summary                                               |
| `subpages` | int | | - | Max subpages to crawl per URL                                               |
| `subpage_target` | list[str] | | - | Keywords to prioritize when selecting subpages                              |
| `max_age_hours` | int | | - | Max age of cached content in hours                                          |
| `livecrawl_timeout` | int | | - | Timeout in ms for live crawling fallback                                    |

---

## Stock Module Parameters

### stock income_statement / balance_sheet / cashflow_statement
| Parameter | Type | Required | Default | Description |
|-----------|------|----------|---------|-------------|
| `symbol` | string | ✓ | - | Stock symbol |
| `period` | string | | annual | annual / quarterly |
| `limit` | int | | 8 | Number of periods |
| `start_date` | str | | - | Start date |
| `end_date` | str | | - | End date |
| `calendar` | str | | fiscal | calendar / fiscal |
| `fiscal_year` | str | | - | Specific fiscal year |
| `fiscal_quarter` | str | | - | Q1, Q2, Q3, Q4, FY, H1 |

---

## Quant Module Parameters

### quant ohlcv
| Parameter | Type | Required | Default | Description |
|-----------|------|----------|---------|-------------|
| `symbol` | str | ✓ | - | Stock code (e.g., 600519) |
| `market` | str | | cn | cn / hk / us |
| `start_date` | str | | 1 month ago | Start date |
| `end_date` | str | | today | End date |

### quant ohlcv_batch
| Parameter | Type | Required | Default | Description |
|-----------|------|----------|---------|-------------|
| `symbols` | list[str] | ✓ | - | Stock codes (e.g., [600519, 000001]) |
| `market` | str | | cn | cn / hk / us |
| `start_date` | str | | 1 month ago | Start date |
| `end_date` | str | | today | End date |

### quant kline_1m
| Parameter | Type | Required | Default | Description |
|-----------|------|----------|---------|-------------|
| `symbol` | str | ✓ | - | Stock code (e.g., 600519) |
| `start_datetime` | str | ✓ | - | Start datetime (YYYY-MM-DD HH:MM:SS) |
| `end_datetime` | str | ✓ | - | End datetime (YYYY-MM-DD HH:MM:SS) |
| `market` | str | | cn | cn / hk / us |

### quant kline_1m_batch
| Parameter | Type | Required | Default | Description |
|-----------|------|----------|---------|-------------|
| `symbols` | list[str] | ✓ | - | Stock codes (e.g., [600519, 000001]) |
| `start_datetime` | str | ✓ | - | Start datetime (YYYY-MM-DD HH:MM:SS) |
| `end_datetime` | str | ✓ | - | End datetime (YYYY-MM-DD HH:MM:SS) |
| `market` | str | | cn | cn / hk / us |

### quant minute
| Parameter | Type | Required | Default | Description |
|-----------|------|----------|---------|-------------|
| `symbol` | str | ✓ | - | Stock code (e.g., 600519) |
| `start_datetime` | str | ✓ | - | Start datetime (YYYY-MM-DD HH:MM:SS) |
| `end_datetime` | str | ✓ | - | End datetime (YYYY-MM-DD HH:MM:SS) |
| `market` | str | | cn | cn / hk / us |

### quant minute_batch
| Parameter | Type | Required | Default | Description |
|-----------|------|----------|---------|-------------|
| `symbols` | list[str] | ✓ | - | Stock codes (e.g., [600519, 000001]) |
| `start_datetime` | str | ✓ | - | Start datetime (YYYY-MM-DD HH:MM:SS) |
| `end_datetime` | str | ✓ | - | End datetime (YYYY-MM-DD HH:MM:SS) |
| `market` | str | | cn | cn / hk / us |

### quant indicators_compute / factors_compute
| Parameter | Type | Required | Default | Description |
|-----------|------|----------|---------|-------------|
| `symbols` | list[str] | ✓ | - | Stock codes (e.g., 600519 for CN market) |
| `formula` | str | ✓ | - | Formula expression. Both sides of &/\|/AND/OR must be wrapped in () |
| `market` | str | | cn | cn / hk / us |
| `start_date` | str | | 3 months ago | Start date |
| `end_date` | str | | today | End date |

### quant backtest
| Parameter | Type | Required | Default | Description |
|-----------|------|----------|---------|-------------|
| `symbol` | str | ✓ | - | Stock symbol |
| `start_date` | str | ✓ | - | Backtest start |
| `end_date` | str | ✓ | - | Backtest end |
| `entry_formula` | str | ✓ | - | Entry signal formula. Both sides of &/\|/AND/OR must be wrapped in () |
| `exit_formula` | str | | - | Exit signal formula. Both sides of &/\|/AND/OR must be wrapped in () |
| `market` | str | | cn | Market |
| `initial_cash` | float | | 100000 | Initial capital |
| `commission` | float | | 0 | Commission rate |
| `stop_loss` | float | | 0 | Stop loss % (0=disabled) |
| `sizer_percent` | int | | 99 | Position size % |

### quant factors_screen
| Parameter | Type | Required | Default | Description |
|-----------|------|----------|---------|-------------|
| `formula` | str | ✓ | - | Screening formula. Both sides of &/\|/AND/OR must be wrapped in () |
| `market` | str | | cn | Market |
| `check_date` | str | | latest | Check date |
| `symbols` | list[str] | | - | Stock codes pool (None=all market) |

---

## KB Module Parameters

### kb search
| Parameter | Type | Required | Default | Description |
|-----------|------|----------|---------|-------------|
| `query` | string | ✓ | - | Search keywords |
| `folder_ids` | list[str] | | - | Folder IDs |
| `doc_ids` | list[str] | | - | Document IDs |
| `start_date` | str | | - | Start date |
| `end_date` | str | | - | End date |
| `num` | int | | 10 | Results count |

---

## User Module Parameters

### user follow_company / unfollow_company
| Parameter | Type | Required | Default | Description |
|-----------|------|----------|---------|-------------|
| `symbol` | string | ✓ | - | Stock symbol, format: market:ticker (e.g. US:AAPL, HK:00700, SH:600519) |

---

## Agent Module Parameters

### agent create_conversation
| Parameter | Type | Required | Default | Description |
|-----------|------|----------|---------|-------------|
| `agent_id` | int | ✓ | - | Agent ID |
| `title` | string | | - | Conversation title |
| `conversation_type` | string | | - | Conversation type: agent_chat, task_chat, debug_chat, bot_chat |
| `meta` | dict | | - | Metadata dict |

### agent chat
| Parameter | Type | Required | Default | Description |
|-----------|------|----------|---------|-------------|
| `conversation_id` | int | ✓ | - | Conversation ID |
| `message` | string | ✓ | - | User message content |
| `documents` | list[dict] | | - | Related documents, each with doc_id, doc_title, file_type |
| `stream` | bool | | true | Whether to use streaming response |
| `background` | bool | | false | Run agent task in background, returns immediately when true |

### agent get_conversation
| Parameter | Type | Required | Default | Description |
|-----------|------|----------|---------|-------------|
| `conversation_id` | int | ✓ | - | Conversation ID |

### agent list_messages
| Parameter | Type | Required | Default | Description |
|-----------|------|----------|---------|-------------|
| `conversation_id` | int | ✓ | - | Conversation ID |
| `limit` | int | | 10 | Number of messages (max 100) |
| `before_message_id` | int | | - | Fetch messages before this ID |

### agent get_message_events
| Parameter | Type | Required | Default | Description |
|-----------|------|----------|---------|-------------|
| `conversation_id` | int | ✓ | - | Conversation ID |
| `assistant_message_id` | string | ✓ | - | Assistant message ID |
| `stream` | bool | | true | Stream events via SSE |
| `timeout` | int | | 1800 | Timeout in seconds |
| `from_offset` | int | | 0 | Start from specific offset |

### agent cancel_execution
| Parameter | Type | Required | Default | Description |
|-----------|------|----------|---------|-------------|
| `conversation_id` | int | ✓ | - | Conversation ID |
| `assistant_message_id` | string | ✓ | - | Assistant message ID to cancel |

### agent get_file
| Parameter | Type | Required | Default | Description |
|-----------|------|----------|---------|-------------|
| `file_id` | string | ✓ | - | Agent generated file ID |

---

## Macro Module Parameters

### macro commodities
| Parameter | Type | Required | Default | Description |
|-----------|------|----------|---------|-------------|
| `type` | string | ✓ | - | Commodity type: oil, gold, gas, silver, or platinum |
| `start_date` | str | ✓ | - | Start date (YYYY-MM-DD) |
| `end_date` | str | ✓ | - | End date (YYYY-MM-DD). Interval must not exceed 10 years. |

**Response fields (common):**
| Field | Type | Description |
|-------|------|-------------|
| date | string | Date of the data (e.g., `2026-02-06T00:00:00+08:00`) |

**type=oil return fields:**
| Field | Type | Description |
|-------|------|-------------|
| `wti_co_sp` | double | WTI crude oil spot price / WTI原油现货价格（USD/barrel, 美元/桶） |
| `brent_co_sp` | double | Brent crude oil spot price / 布伦特原油现货价格（USD/barrel, 美元/桶） |

**type=gold return fields:**
| Field | Type | Description |
|-------|------|-------------|
| `lbma_pm_usd` | double | London gold LBMA PM fixing price / 伦敦金价格，LBMA下午定盘价（USD/oz, 美元/盎司） |
| `sge_pm_cny` | double | Shanghai gold price / 上海金价格（CNY, 人民币） |

**type=gas return fields:**
| Field | Type | Description |
|-------|------|-------------|
| `hh_ng_sp` | double | Henry Hub natural gas spot price / 亨利港天然气现货价格（USD/MMBtu, 美元/百万英热单位） |

**type=silver return fields:**
| Field | Type | Description |
|-------|------|-------------|
| `si_eur` | double | London silver price / 伦敦银价格（USD/oz, 美元/盎司） |

**type=platinum return fields:**
| Field | Type | Description |
|-------|------|-------------|
| `pl_usd` | double | London platinum price / 伦敦铂金价格（USD/oz, 美元/盎司） |

---

## Following Module Parameters

### following create_follow_group
| Parameter | Type | Required | Default | Description |
|-----------|------|----------|---------|-------------|
| `name` | string | ✓ | - | Group name |
| `follow_values` | list[object] | ✓ | - | List of follow items with follow_type and follow_value |

### following get_follow_group / update_follow_group / delete_follow_group
| Parameter | Type | Required | Default | Description |
|-----------|------|----------|---------|-------------|
| `group_id` | string | ✓ | - | Group ID |
| `name` | string | | - | New group name (for update) |

### following add_follows_to_group / set_group_follows
| Parameter | Type | Required | Default | Description |
|-----------|------|----------|---------|-------------|
| `group_id` | string | ✓ | - | Group ID |
| `follow_values` | list[object] | ✓ | - | List of follow items with follow_type and follow_value |

### following remove_follows_from_group
| Parameter | Type | Required | Default | Description |
|-----------|------|----------|---------|-------------|
| `group_id` | string | ✓ | - | Group ID |
| `follow_values` | list[string] | ✓ | - | List of follow values to remove (e.g., ["AAPL", "MSFT"]) |

### following get_follow_group_docs
| Parameter | Type | Required | Default | Description |
|-----------|------|----------|---------|-------------|
| `group_id` | string | ✓ | - | Group ID |
| `page_num` | int | | 1 | Page number |
| `page_size` | int | | 10 | Page size |

**Follow Values Format:**
- Each follow_value object should have: `{"follow_type": int, "follow_value": string}`
- Follow types typically: 1 (stock), 2 (channel), etc.
- Example: `[{"follow_type": 1, "follow_value": "US:AAPL"}]`
