# Reportify API CLI Commands Reference

## Search Module

| Command | Description | Required Params |
|---------|-------------|-----------------|
| `query` | Search all document types | `query` |
| `news` | Search news articles | `query` |
| `reports` | Search research reports | `query` |
| `filings` | Search company filings | `symbols` |
| `conference_calls` | Search earnings conference call transcripts | `symbols` |
| `earnings_pack` | Search earnings-related exchange filings | `symbols` |
| `minutes` | Search conference calls and IR meetings | `query` |
| `socials` | Search social media posts | `query` |
| `webpages` | Search web pages | `query` |
| `crawl` | Crawl web content from URLs | `urls` |

## Docs Module

| Command | Description | Required Params |
|---------|-------------|-----------------|
| `get` | Get document details | `doc_id` |
| `summary` | Get document summary | `doc_id` |
| `list_by_symbols` | List documents by stock symbol | `symbol` |
| `raw_content` | Get document raw content | `doc_id` |
| `list` | List documents with filters | (optional) |
| `search` | Search documents (v1) | `query` |
| `search_chunks` | Search document chunks | `query` |
| `create_folder` | Create folder | `name` |
| `delete_folder` | Delete folder and all its files | `folder_id` |
| `upload` | Upload documents | `folder_id`, `file_paths` |
| `upload_async` | Upload documents asynchronously | `folder_id`, `file_paths` |
| `get_upload_status` | Get document upload status | `task_id` |
| `delete` | Delete documents | `doc_ids` |

## Stock Module

| Command | Description | Required Params |
|---------|-------------|-----------------|
| `overview` | Company overview | `symbols` or `names` |
| `shareholders` | Shareholder information | `symbol` |
| `income_statement` | Income statement | `symbol` |
| `balance_sheet` | Balance sheet | `symbol` |
| `cashflow_statement` | Cash flow statement | `symbol` |
| `revenue_breakdown` | Revenue breakdown | `symbol` |
| `quote` | Real-time quote | `symbol` |
| `index_constituents` | Index constituents | `symbol` |
| `index_tracking_funds` | Index tracking funds | `symbol` |
| `industry_constituents` | Industry constituents | `market`, `name` |
| `earnings_calendar` | Earnings calendar | `market` |
| `ipo_calendar_hk` | HK IPO calendar | (optional) |
| `index_quote` | Index quote data | `symbol` |

## Timeline Module

| Command | Description | Required Params |
|---------|-------------|-----------------|
| `companies` | Company timeline | (optional) |
| `topics` | Topic timeline | (optional) |
| `institutes` | Institute timeline | (optional) |
| `public_media` | Public media timeline | (optional) |
| `social_media` | Social media timeline | (optional) |

## Channels Module

| Command | Description | Required Params |
|---------|-------------|-----------------|
| `search` | Search channels | `query` |
| `followings` | List followed channels | (optional) |
| `follow` | Follow a channel | `channel_id` |
| `unfollow` | Unfollow a channel | `channel_id` |
| `get_docs` | Get documents from followed channels | (optional) |

## KB Module

| Command | Description | Required Params |
|---------|-------------|-----------------|
| `search` | Search knowledge base | `query` |

## User Module

| Command | Description | Required Params |
|---------|-------------|-----------------|
| `followed_companies` | Get followed companies | (none) |
| `follow_company` | Follow a company (add to watchlist) | `symbol` |
| `unfollow_company` | Unfollow a company (remove from watchlist) | `symbol` |

## Quant Module

| Command | Description | Required Params |
|---------|-------------|-----------------|
| `indicators` | List available indicators | (none) |
| `indicators_compute` | Compute technical indicators | `symbols`, `formula` |
| `factors` | List available factors | (none) |
| `factors_compute` | Compute factors | `symbols`, `formula` |
| `factors_screen` | Stock screening | `formula` |
| `ohlcv` | Get OHLCV data | `symbol` |
| `ohlcv_batch` | Batch OHLCV data | `symbols` |
| `kline_1m` | Get 1-minute kline data | `symbol`, `start_datetime`, `end_datetime` |
| `kline_1m_batch` | Batch 1-minute kline data | `symbols`, `start_datetime`, `end_datetime` |
| `minute` | Get minute data | `symbol`, `start_datetime`, `end_datetime` |
| `minute_batch` | Batch minute data | `symbols`, `start_datetime`, `end_datetime` |
| `backtest` | Run backtest | `symbol`, `start_date`, `end_date`, `entry_formula` |

## Concepts Module

| Command | Description | Required Params |
|---------|-------------|-----------------|
| `latest` | Latest concept dynamics | (optional) |
| `today` | Today's concepts | (none) |

## Agent Module

| Command | Description | Required Params |
|---------|-------------|-----------------|
| `create_conversation` | Create a new agent conversation | `agent_id` |
| `get_conversation` | Get conversation details | `conversation_id` |
| `chat` | Chat with agent | `conversation_id`, `message` |
| `list_messages` | List conversation messages | `conversation_id` |
| `get_message_events` | Get assistant message events | `conversation_id`, `assistant_message_id` |
| `cancel_execution` | Cancel agent execution | `conversation_id`, `assistant_message_id` |
| `get_file` | Get agent generated file | `file_id` |

## Following Module

| Command | Description | Required Params |
|---------|-------------|-----------------|
| `create_follow_group` | Create a follow group | `name`, `follow_values` |
| `get_follow_groups` | Get all follow groups | (none) |
| `get_follow_group` | Get a follow group by ID | `group_id` |
| `update_follow_group` | Update a follow group | `group_id`, `name` |
| `delete_follow_group` | Delete a follow group | `group_id` |
| `add_follows_to_group` | Add follows to a group | `group_id`, `follow_values` |
| `remove_follows_from_group` | Remove follows from a group | `group_id`, `follow_values` |
| `set_group_follows` | Set follows for a group (replace all) | `group_id`, `follow_values` |
| `get_follow_group_docs` | Get docs for a follow group | `group_id` |

