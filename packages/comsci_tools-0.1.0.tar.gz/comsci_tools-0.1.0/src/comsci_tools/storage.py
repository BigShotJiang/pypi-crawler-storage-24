def convert_bytes(size_in_bytes: float) -> str:
    """Convert raw bytes to human-readable format (KB, MB, GB, TB)."""
    for unit in ['B', 'KB', 'MB', 'GB', 'TB']:
        if size_in_bytes < 1024.0:
            return f"{round(size_in_bytes, 2)} {unit}"
        # Divide by exact 1024 for computer science standard
        size_in_bytes /= 1024.0
    return f"{round(size_in_bytes, 2)} PB"

def calculate_download_time(file_size_mb: float, speed_mbps: float) -> float:
    """
    Calculate exact download time in seconds.
    Note: Internet speed is in Megabits (Mb), File size is in Megabytes (MB).
    """
    # 1 Byte = 8 bits, so we divide speed by 8 to match MB
    speed_mb_per_sec = speed_mbps / 8.0
    time_seconds = file_size_mb / speed_mb_per_sec
    return round(time_seconds, 2)