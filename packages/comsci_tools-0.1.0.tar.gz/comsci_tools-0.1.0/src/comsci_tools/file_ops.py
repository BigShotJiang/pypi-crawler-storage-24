import os

def get_file_extension(filename: str) -> str:
    """Extract the extension from a filename (e.g., '.txt')."""
    _, extension = os.path.splitext(filename)
    return extension.lower()