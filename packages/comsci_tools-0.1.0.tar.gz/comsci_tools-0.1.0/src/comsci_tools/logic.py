def dec_to_bin(number: int) -> str:
    """Convert decimal to binary string."""
    return bin(number).replace("0b", "")

def dec_to_hex(number: int) -> str:
    """Convert decimal to uppercase hexadecimal string."""
    return hex(number).replace("0x", "").upper()

def base_converter(number_str: str, from_base: int, to_base: int) -> str:
    """Convert any base to any base (Basic version)."""
    # Step 1: Convert input to decimal
    decimal_num = int(number_str, from_base)
    # Step 2: Convert decimal to target base
    if to_base == 2: return bin(decimal_num).replace("0b", "")
    if to_base == 8: return oct(decimal_num).replace("0o", "")
    if to_base == 16: return hex(decimal_num).replace("0x", "").upper()
    return str(decimal_num)