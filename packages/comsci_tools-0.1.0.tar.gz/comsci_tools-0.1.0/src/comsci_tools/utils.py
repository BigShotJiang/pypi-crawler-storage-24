import os
import platform

def clear_console():
    """Clears the terminal screen regardless of OS."""
    if platform.system() == "Windows":
        os.system("cls")
    else:
        os.system("clear")