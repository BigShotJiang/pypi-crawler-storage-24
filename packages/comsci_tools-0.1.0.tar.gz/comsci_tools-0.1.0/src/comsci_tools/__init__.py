# 1. Logic & Math
from .logic import dec_to_bin, dec_to_hex, base_converter

# 2. Academic tools
from .academic import calculate_grade, gpa_calculator

# 3. Utilities
from .utils import clear_console

# 4. Cryptography
from .crypto import encrypt_caesar, hash_md5

# 5. Storage
from .storage import convert_bytes, calculate_download_time

# 6. Color (Web/UI)
from .color import rgb_to_hex, hex_to_rgb

# 7. Randomizer
from .randomizer import generate_password, coin_flip

# 8. Time Utils
from .time_utils import get_current_timestamp, format_seconds

# 9. Network
from .network import get_local_ip

# 10. File Operations
from .file_ops import get_file_extension

__version__ = "0.1.0"