import random
import string

def generate_password(length: int = 12) -> str:
    """Generate a secure random password."""
    if length < 4:
        raise ValueError("Password length must be at least 4")

    characters = string.ascii_letters + string.digits + string.punctuation
    # Ensure at least one of each type is theoretically possible
    return ''.join(random.choice(characters) for _ in range(length))

def coin_flip() -> str:
    """Simulate a 50/50 coin flip."""
    return random.choice(["Heads", "Tails"])