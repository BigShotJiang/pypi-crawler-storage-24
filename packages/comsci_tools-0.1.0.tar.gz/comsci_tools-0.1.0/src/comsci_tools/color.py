def rgb_to_hex(r: int, g: int, b: int) -> str:
    """Convert RGB values to a HEX color code."""
    # Ensure values are within 0-255 range
    r = max(0, min(255, r))
    g = max(0, min(255, g))
    b = max(0, min(255, b))
    return f"#{r:02X}{g:02X}{b:02X}"

def hex_to_rgb(hex_code: str) -> tuple:
    """Convert HEX color code to RGB tuple."""
    hex_code = hex_code.lstrip('#')
    if len(hex_code) != 6:
        raise ValueError("HEX code must be 6 characters long")
    return tuple(int(hex_code[i:i+2], 16) for i in (0, 2, 4))