import time

def get_current_timestamp() -> int:
    """Get the current Unix timestamp in seconds."""
    return int(time.time())

def format_seconds(seconds: int) -> str:
    """Convert raw seconds into HH:MM:SS format."""
    hours = seconds // 3600
    minutes = (seconds % 3600) // 60
    secs = seconds % 60
    return f"{hours:02d}:{minutes:02d}:{secs:02d}"