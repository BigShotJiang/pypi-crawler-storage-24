def calculate_grade(score: float) -> str:
    """Standard Thai University grading system."""
    if score >= 80: return "A"
    if score >= 75: return "B+"
    if score >= 70: return "B"
    if score >= 65: return "C+"
    if score >= 60: return "C"
    if score >= 55: return "D+"
    if score >= 50: return "D"
    return "F"

def gpa_calculator(grades_with_credits: list) -> float:
    """
    Calculate GPA.
    Input: [(grade_point, credit), (grade_point, credit)]
    Example: [(4.0, 3), (3.5, 3)]
    """
    total_points = sum(g * c for g, c in grades_with_credits)
    total_credits = sum(c for g, c in grades_with_credits)
    return round(total_points / total_credits, 2)