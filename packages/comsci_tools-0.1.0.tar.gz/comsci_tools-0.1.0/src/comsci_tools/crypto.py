import hashlib

def encrypt_caesar(text: str, shift: int) -> str:
    """Encrypt text using basic Caesar Cipher."""
    result = ""
    for char in text:
        if char.isalpha():
            # Check if uppercase or lowercase
            ascii_offset = 65 if char.isupper() else 97
            # Shift character and wrap around alphabet
            result += chr((ord(char) - ascii_offset + shift) % 26 + ascii_offset)
        else:
            result += char
    return result

def hash_md5(text: str) -> str:
    """Convert string text to an MD5 hash string."""
    # Encode text to bytes, then hash, then return as hex string
    return hashlib.md5(text.encode()).hexdigest()