# comsci-tools

A comprehensive utility toolkit designed to make the lives of Computer Science students and developers easier. Whether you are calculating GPA, converting number bases for Digital Logic class, or generating secure passwords, this package has you covered!

## Installation

You can easily install this package via pip:

```bash
pip install comsci-tools
```

## Quick Start & Examples

Here are some real-world examples of how to use the modules included in this package:

### 1. Base Converter (Digital Logic & Architecture)
Perfect for computer science math and architecture calculations.

```python
from comsci_tools import dec_to_bin, dec_to_hex

print(dec_to_bin(255))  # Output: 11111111
print(dec_to_hex(255))  # Output: FF
```

### 2. Academic Tools
Easily calculate your exact GPA using standard university formats.

```python
from comsci_tools import gpa_calculator

# Format: [(Grade Point, Credits), ...]
my_grades = [
    (4.0, 3),  # Programming (A)
    (3.5, 3),  # Mathematics (B+)
    (3.0, 3)   # English (B)
]
print(f"My GPA is: {gpa_calculator(my_grades)}")
# Output: My GPA is: 3.5
```

### 3. Web Development Tools (HTML/CSS)
Quickly convert RGB colors to HEX codes for web design.

```python
from comsci_tools import rgb_to_hex

color = rgb_to_hex(255, 99, 71)
print(f"Tomato color hex: {color}") 
# Output: Tomato color hex: #FF6347
```

### 4. Cryptography & Security
Generate secure passwords or use basic encryption.

```python
from comsci_tools import generate_password, hash_md5

# Generate a 16-character secure password
print(generate_password(16)) 

# Hash a string using MD5
print(hash_md5("my_secret_data"))
```

## Available Modules Included
This package contains 10 powerful modules:
1. `logic`: Base conversions (Bin, Oct, Hex)
2. `academic`: Grading and GPA calculations
3. `crypto`: Hashing and basic encryption
4. `storage`: Byte conversions and download time estimation
5. `color`: RGB and HEX color tools
6. `randomizer`: Password generators and coin flips
7. `time_utils`: Timestamps and formatting
8. `network`: Local IP fetching
9. `file_ops`: File extension extraction
10. `utils`: Cross-platform console clearing