import comsci_tools as tools

print("=== ComSci Tools Test Run ===")

# 1. Test Base Converter (Digital Logic)
decimal_number = 255
binary_result = tools.dec_to_bin(decimal_number)
hex_result = tools.dec_to_hex(decimal_number)
print(f"\n[1] Logic Test: {decimal_number} in Binary is {binary_result}, in Hex is {hex_result}")

# 2. Test GPA Calculator (Academic)
# Format: [(Grade Point, Credits)]
my_grades = [
    (4.0, 3),  # Programming (A)
    (3.5, 3),  # Mathematics (B+)
    (3.0, 3)   # English (B)
]
gpa = tools.gpa_calculator(my_grades)
print(f"\n[2] Academic Test: My calculated GPA is {gpa}")

# 3. Test RGB to HEX Converter (Web Development)
r, g, b = 255, 99, 71
hex_color = tools.rgb_to_hex(r, g, b)
print(f"\n[3] Color Test: RGB({r}, {g}, {b}) is HEX {hex_color}")

# 4. Test Password Generator (Security)
secure_pass = tools.generate_password(16)
print(f"\n[4] Security Test: Generated 16-char Password -> {secure_pass}")

# 5. Test Download Time Calculator (Storage & Network)
file_size = 1024.0  # 1024 MB (1 GB)
internet_speed = 500.0  # 500 Mbps
download_time = tools.calculate_download_time(file_size, internet_speed)
print(f"\n[5] Network Test: Time to download {file_size}MB at {internet_speed}Mbps is {download_time} seconds")

print("\n=============================")