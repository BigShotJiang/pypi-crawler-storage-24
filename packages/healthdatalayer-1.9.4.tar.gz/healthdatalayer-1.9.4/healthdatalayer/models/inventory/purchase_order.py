from datetime import datetime
import uuid
from typing import Optional, List, TYPE_CHECKING
from sqlmodel import SQLModel, Field, Relationship
from sqlalchemy import Column, Enum as SqlEnum
from healthdatalayer.models.bridge_area_floor_branch.branch import Branch
from healthdatalayer.models.inventory.purchase_order_status_enum import PurchaseOrderStatus

if TYPE_CHECKING:
    from healthdatalayer.models.inventory.purchase_order_detail import PurchaseOrderDetail

class PurchaseOrder(SQLModel, table=True):
    __tablename__ = "purchase_order"

    purchase_order_id: uuid.UUID = Field(default_factory=uuid.uuid4, primary_key=True)
    supplier_name: str = Field(max_length=255, nullable=False)
    branch_id: uuid.UUID = Field(foreign_key="branch.branch_id", nullable=False)
    order_date: Optional[datetime] = Field(default_factory=datetime.now)
    expected_delivery_date: Optional[datetime] = Field(default=None)
    status: PurchaseOrderStatus = Field(sa_column=Column(SqlEnum(PurchaseOrderStatus, native_enum=False), nullable=False, default=PurchaseOrderStatus.BORRADOR))
    total_amount: Optional[float] = Field(default=None)
    description: Optional[str] = Field(default=None)
    created_at: Optional[datetime] = Field(default_factory=datetime.now)
    updated_at: Optional[datetime] = Field(default=None)
    
    branch: Optional[Branch] = Relationship(back_populates="purchase_orders")
    details: List["PurchaseOrderDetail"] = Relationship(back_populates="purchase_order")