import uuid
from datetime import datetime
from typing import Optional, List, TYPE_CHECKING
from sqlmodel import SQLModel, Field, Relationship
from sqlalchemy import Column, Enum as SqlEnum
from healthdatalayer.models.inventory.transaction_type_enum import TransactionType

if TYPE_CHECKING:
    from healthdatalayer.models.inventory.supply import Supply
    from healthdatalayer.models.inventory.lot import Lot
    from healthdatalayer.models.bridge_area_floor_branch.branch import Branch

class Transaction(SQLModel, table=True):
    __tablename__ = "transaction"

    transaction_id: uuid.UUID = Field(default_factory=uuid.uuid4, primary_key=True)
    supply_id: uuid.UUID = Field(foreign_key="supply.supply_id", nullable=False)
    branch_id: uuid.UUID = Field(foreign_key="branch.branch_id", nullable=False)
    lot_id: uuid.UUID = Field(foreign_key="lot.lot_id", nullable=True)
    quantity: int = Field(nullable=False)
    finally_stock: int = Field(nullable=False)
    description: Optional[str] = Field(default=None)
    transaction_type: TransactionType = Field(sa_column=Column(SqlEnum(TransactionType, native_enum=False), nullable=False))
    reference_id: Optional[uuid.UUID] = Field(default=None)
    reference_type: Optional[str] = Field(default=None, max_length=255)
    date: Optional[datetime] = Field(default_factory=datetime.now)  
    created_at: Optional[datetime] = Field(default_factory=datetime.now)
    updated_at: Optional[datetime] = Field(default=None)
    supply: Optional["Supply"] = Relationship(back_populates="transactions")
    branch: Optional["Branch"] = Relationship(back_populates="transactions")
    lot: Optional["Lot"] = Relationship(back_populates="transactions")