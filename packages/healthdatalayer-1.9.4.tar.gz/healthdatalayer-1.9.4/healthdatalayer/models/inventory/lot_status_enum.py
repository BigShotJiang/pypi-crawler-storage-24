from enum import Enum

class StatusLotEnum(str, Enum):
    ACTIVO       = "ACTIVO"
    CUARENTENADO = "CUARENTENADO"
    VENCIDO      = "VENCIDO"
    AGOTADO      = "AGOTADO"