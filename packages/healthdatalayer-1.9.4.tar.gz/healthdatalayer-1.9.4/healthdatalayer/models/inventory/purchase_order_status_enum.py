from enum import Enum

class PurchaseOrderStatus(str, Enum):
    BORRADOR   = "BORRADOR"
    ENVIADA    = "ENVIADA"
    PARCIAL    = "PARCIAL"
    RECIBIDA   = "RECIBIDA"
    CANCELADA  = "CANCELADA"