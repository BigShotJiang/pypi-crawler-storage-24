import uuid
from sqlmodel import SQLModel, Field, Relationship
from typing import Optional, List, TYPE_CHECKING

from healthdatalayer.models import System

if TYPE_CHECKING:
    from healthdatalayer.models.inventory.stock_branch import StockBranch
    from healthdatalayer.models.inventory.transaction import Transaction
    from healthdatalayer.models.inventory.transfer import Transfer
    from healthdatalayer.models.inventory.purchase_order import PurchaseOrder
    from healthdatalayer.models.inventory.alert import Alert

class Branch(SQLModel, table=True):
    __tablename__ = "branch"
    
    branch_id: uuid.UUID = Field(default_factory=uuid.uuid4, primary_key=True)
    name: str
    location_x: Optional[float] = None
    location_y: Optional[float] = None
    
    system_id: Optional[uuid.UUID] = Field(default=None, foreign_key="system.system_id")
    system: Optional[System] = Relationship(back_populates="branches")
    
    # Inventory relationships
    stock_branches: List["StockBranch"] = Relationship(back_populates="branch")
    transactions: List["Transaction"] = Relationship(back_populates="branch")
    transfers_from: List["Transfer"] = Relationship(
        sa_relationship_kwargs= {"foreign_keys": "[Transfer.from_branch_id]"},
        back_populates="from_branch"
    )
    transfers_to: List["Transfer"] = Relationship(
        sa_relationship_kwargs={"foreign_keys": "[Transfer.to_branch_id]"},
        back_populates="to_branch"
    )
    purchase_orders: List["PurchaseOrder"] = Relationship(back_populates="branch")
    alerts: List["Alert"] = Relationship(back_populates="branch")