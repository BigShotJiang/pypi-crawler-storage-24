import uuid
from sqlmodel import SQLModel, Field, Relationship
from typing import List, TYPE_CHECKING

if TYPE_CHECKING:
    from healthdatalayer.models.bridge_area_floor_branch.branch import Branch

class System(SQLModel, table=True):
    __tablename__ = "system"
    
    system_id: uuid.UUID = Field(default_factory=uuid.uuid4, primary_key=True)
    name: str
    branches: List["Branch"] = Relationship(back_populates="system")