from typing import Optional, List
from uuid import UUID
from sqlmodel import select, or_
from sqlalchemy.orm import selectinload, joinedload

from healthdatalayer.models.inventory.category import Category
from healthdatalayer.repositories.base_repository import BaseRepository


class CategoryRepository(BaseRepository[Category]):
    def __init__(self, tenant: str):
        super().__init__(tenant, Category)

    def _detail_options(self):
        return (
            joinedload(Category.parent_category),
            selectinload(Category.subcategories),
        )

    def _apply_load_options(self, statement, load_details: bool):
        if load_details:
            return statement.options(*self._detail_options())
        return statement

    def get_by_id_command(
        self, category_id: UUID, load_details: bool = False, active_only: bool = True
    ) -> Optional[Category]:
        with self._get_session() as session:
            statement = select(Category).where(Category.category_id == category_id)
            statement = self._apply_active_filter(statement, active_only)
            statement = self._apply_load_options(statement, load_details)
            return session.exec(statement).first()

    def get_by_name_command(self, name: str, active_only: bool = True) -> Optional[Category]:
        with self._get_session() as session:
            statement = select(Category).where(Category.name == name)
            statement = self._apply_active_filter(statement, active_only)
            return session.exec(statement).first()

    def list_all_command(
        self, active_only: bool = True, load_details: bool = False
    ) -> List[Category]:
        with self._get_session() as session:
            statement = select(Category)
            statement = self._apply_active_filter(statement, active_only)
            statement = self._apply_load_options(statement, load_details)
            return session.exec(statement).all()

    def get_root_categories_command(
        self, active_only: bool = True, load_details: bool = False
    ) -> List[Category]:
        """Get categories without a parent (root level categories)."""
        with self._get_session() as session:
            statement = select(Category).where(Category.parent_category_id == None)
            statement = self._apply_active_filter(statement, active_only)
            statement = self._apply_load_options(statement, load_details)
            return session.exec(statement).all()

    def get_children_command(
        self, parent_id: UUID, active_only: bool = True, load_details: bool = False
    ) -> List[Category]:
        """Get subcategories of a specific parent category."""
        with self._get_session() as session:
            statement = select(Category).where(Category.parent_category_id == parent_id)
            statement = self._apply_active_filter(statement, active_only)
            statement = self._apply_load_options(statement, load_details)
            return session.exec(statement).all()

    def search_command(
        self, search_term: str, active_only: bool = True, load_details: bool = False
    ) -> List[Category]:
        """Search categories by name or description."""
        with self._get_session() as session:
            statement = select(Category).where(
                or_(
                    Category.name.ilike(f"%{search_term}%"),
                    Category.description.ilike(f"%{search_term}%")
                )
            )
            statement = self._apply_active_filter(statement, active_only)
            statement = self._apply_load_options(statement, load_details)
            return session.exec(statement).all()
