from typing import Optional, List
from uuid import UUID
from datetime import datetime
from sqlmodel import select, and_
from sqlalchemy.orm import selectinload, joinedload

from healthdatalayer.models.inventory.transfer import Transfer
from healthdatalayer.models.inventory.transfer_status_enum import TransferStatusEnum
from healthdatalayer.repositories.base_repository import BaseRepository


class TransferRepository(BaseRepository[Transfer]):
    def __init__(self, tenant: str):
        super().__init__(tenant, Transfer)

    def _detail_options(self):
        return (
            joinedload(Transfer.from_branch),
            joinedload(Transfer.to_branch),
            selectinload(Transfer.details),
        )

    def _apply_load_options(self, statement, load_details: bool):
        if load_details:
            return statement.options(*self._detail_options())
        return statement

    def _validate_status_transition(self, current_status: TransferStatusEnum, new_status: TransferStatusEnum) -> bool:
        """Validate that a status transition is allowed."""
        valid_transitions = {
            TransferStatusEnum.SOLICITADO: [TransferStatusEnum.APROBADO, TransferStatusEnum.RECHAZADO],
            TransferStatusEnum.APROBADO: [TransferStatusEnum.DESPACHADO, TransferStatusEnum.CANCELADO],
            TransferStatusEnum.DESPACHADO: [TransferStatusEnum.RECIBIDO],
        }
        
        if current_status in valid_transitions:
            return new_status in valid_transitions[current_status]
        return False

    def get_by_id_command(
        self, transfer_id: UUID, load_details: bool = False, active_only: bool = True
    ) -> Optional[Transfer]:
        with self._get_session() as session:
            statement = select(Transfer).where(Transfer.transfer_id == transfer_id)
            statement = self._apply_active_filter(statement, active_only)
            statement = self._apply_load_options(statement, load_details)
            return session.exec(statement).first()

    def get_by_transfer_number_command(
        self, transfer_number: str, load_details: bool = False
    ) -> Optional[Transfer]:
        """Get a transfer by its unique transfer number."""
        with self._get_session() as session:
            statement = select(Transfer).where(Transfer.transfer_number == transfer_number)
            statement = self._apply_load_options(statement, load_details)
            return session.exec(statement).first()

    def list_all_command(
        self, active_only: bool = True, load_details: bool = False
    ) -> List[Transfer]:
        with self._get_session() as session:
            statement = select(Transfer)
            statement = self._apply_active_filter(statement, active_only)
            statement = self._apply_load_options(statement, load_details)
            return session.exec(statement).all()

    def get_by_status_command(
        self, status: TransferStatusEnum, active_only: bool = True, load_details: bool = False
    ) -> List[Transfer]:
        """Get all transfers with a specific status."""
        with self._get_session() as session:
            statement = select(Transfer).where(Transfer.status == status)
            statement = self._apply_active_filter(statement, active_only)
            statement = self._apply_load_options(statement, load_details)
            return session.exec(statement).all()

    def get_by_origin_branch_command(
        self, branch_id: UUID, active_only: bool = True, load_details: bool = False
    ) -> List[Transfer]:
        """Get all transfers from a specific origin branch."""
        with self._get_session() as session:
            statement = select(Transfer).where(Transfer.from_branch_id == branch_id)
            statement = self._apply_active_filter(statement, active_only)
            statement = self._apply_load_options(statement, load_details)
            return session.exec(statement).all()

    def get_by_destination_branch_command(
        self, branch_id: UUID, active_only: bool = True, load_details: bool = False
    ) -> List[Transfer]:
        """Get all transfers to a specific destination branch."""
        with self._get_session() as session:
            statement = select(Transfer).where(Transfer.to_branch_id == branch_id)
            statement = self._apply_active_filter(statement, active_only)
            statement = self._apply_load_options(statement, load_details)
            return session.exec(statement).all()

    def get_pending_approval_command(
        self, branch_id: Optional[UUID] = None, load_details: bool = False
    ) -> List[Transfer]:
        """Get all transfers pending approval."""
        with self._get_session() as session:
            statement = select(Transfer).where(
                Transfer.status == TransferStatusEnum.SOLICITADO,
                Transfer.is_active == True
            )
            if branch_id:
                statement = statement.where(Transfer.from_branch_id == branch_id)
            statement = self._apply_load_options(statement, load_details)
            return session.exec(statement).all()

    def get_pending_dispatch_command(
        self, branch_id: Optional[UUID] = None, load_details: bool = False
    ) -> List[Transfer]:
        """Get all transfers pending dispatch (approved but not dispatched)."""
        with self._get_session() as session:
            statement = select(Transfer).where(
                Transfer.status == TransferStatusEnum.APROBADO,
                Transfer.is_active == True
            )
            if branch_id:
                statement = statement.where(Transfer.from_branch_id == branch_id)
            statement = self._apply_load_options(statement, load_details)
            return session.exec(statement).all()

    def get_pending_reception_command(
        self, branch_id: Optional[UUID] = None, load_details: bool = False
    ) -> List[Transfer]:
        """Get all transfers pending reception (dispatched but not received)."""
        with self._get_session() as session:
            statement = select(Transfer).where(
                Transfer.status == TransferStatusEnum.DESPACHADO,
                Transfer.is_active == True
            )
            if branch_id:
                statement = statement.where(Transfer.to_branch_id == branch_id)
            statement = self._apply_load_options(statement, load_details)
            return session.exec(statement).all()

    def update_status_command(
        self, transfer_id: UUID, new_status: TransferStatusEnum
    ) -> Transfer:
        """Update the status of a transfer with validation."""
        with self._get_session() as session:
            transfer = session.get(Transfer, transfer_id)
            if not transfer:
                raise ValueError(f"Transfer with id {transfer_id} does not exist")
            
            # Validate status transition
            if not self._validate_status_transition(transfer.status, new_status):
                raise ValueError(
                    f"Invalid status transition from {transfer.status.value} to {new_status.value}"
                )
            
            transfer.status = new_status
            
            # Update timestamps based on status
            if new_status == TransferStatusEnum.APROBADO:
                transfer.approval_date = datetime.now()
            elif new_status == TransferStatusEnum.DESPACHADO:
                transfer.dispatch_date = datetime.now()
            elif new_status == TransferStatusEnum.RECIBIDO:
                transfer.receive_date = datetime.now()
            
            session.add(transfer)
            session.commit()
            session.refresh(transfer)
            return transfer

    def approve_command(self, transfer_id: UUID) -> Transfer:
        """Approve a transfer (REQUESTED -> APPROVED)."""
        return self.update_status_command(transfer_id, TransferStatusEnum.APROBADO)

    def dispatch_command(self, transfer_id: UUID) -> Transfer:
        """Dispatch a transfer (APPROVED -> DESPACHADO)."""
        return self.update_status_command(transfer_id, TransferStatusEnum.DESPACHADO)

    def receive_command(self, transfer_id: UUID) -> Transfer:
        """Receive a transfer (DESPACHADO -> RECIBIDO)."""
        return self.update_status_command(transfer_id, TransferStatusEnum.RECIBIDO)

    def reject_command(self, transfer_id: UUID) -> Transfer:
        """Reject a transfer (REQUESTED -> RECHAZADO)."""
        return self.update_status_command(transfer_id, TransferStatusEnum.RECHAZADO)

    def cancel_command(self, transfer_id: UUID) -> Transfer:
        """Cancel a transfer (APPROVED -> CANCELADO)."""
        return self.update_status_command(transfer_id, TransferStatusEnum.CANCELADO)
