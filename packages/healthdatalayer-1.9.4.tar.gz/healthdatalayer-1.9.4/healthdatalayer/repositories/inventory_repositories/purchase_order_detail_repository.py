from typing import Optional, List
from uuid import UUID
from sqlmodel import select, and_
from sqlalchemy.orm import selectinload, joinedload

from healthdatalayer.models.inventory.purchase_order_detail import PurchaseOrderDetail
from healthdatalayer.repositories.base_repository import BaseRepository


class PurchaseOrderDetailRepository(BaseRepository[PurchaseOrderDetail]):
    def __init__(self, tenant: str):
        super().__init__(tenant, PurchaseOrderDetail)

    def _detail_options(self):
        return (
            joinedload(PurchaseOrderDetail.purchase_order),
            joinedload(PurchaseOrderDetail.supply),
        )

    def _apply_load_options(self, statement, load_details: bool):
        if load_details:
            return statement.options(*self._detail_options())
        return statement

    def get_by_id_command(
        self, detail_id: UUID, load_details: bool = False, active_only: bool = True
    ) -> Optional[PurchaseOrderDetail]:
        with self._get_session() as session:
            statement = select(PurchaseOrderDetail).where(PurchaseOrderDetail.purchase_order_detail_id == detail_id)
            statement = self._apply_active_filter(statement, active_only)
            statement = self._apply_load_options(statement, load_details)
            return session.exec(statement).first()

    def list_all_command(
        self, active_only: bool = True, load_details: bool = False
    ) -> List[PurchaseOrderDetail]:
        with self._get_session() as session:
            statement = select(PurchaseOrderDetail)
            statement = self._apply_active_filter(statement, active_only)
            statement = self._apply_load_options(statement, load_details)
            return session.exec(statement).all()

    def get_by_order_command(
        self, order_id: UUID, load_details: bool = False
    ) -> List[PurchaseOrderDetail]:
        """Get all details for a specific purchase order."""
        with self._get_session() as session:
            statement = select(PurchaseOrderDetail).where(
                PurchaseOrderDetail.purchase_order_id == order_id
            )
            statement = self._apply_load_options(statement, load_details)
            return session.exec(statement).all()

    def get_by_supply_command(
        self, supply_id: UUID, load_details: bool = False
    ) -> List[PurchaseOrderDetail]:
        """Get all purchase order details for a specific supply."""
        with self._get_session() as session:
            statement = select(PurchaseOrderDetail).where(
                PurchaseOrderDetail.supply_id == supply_id
            )
            statement = self._apply_load_options(statement, load_details)
            return session.exec(statement).all()

    def get_pending_reception_command(
        self, order_id: Optional[UUID] = None, load_details: bool = False
    ) -> List[PurchaseOrderDetail]:
        """Get all details that have pending quantities to receive."""
        with self._get_session() as session:
            statement = select(PurchaseOrderDetail).where(
                PurchaseOrderDetail.quantity_received < PurchaseOrderDetail.quantity_requested
            )
            if order_id:
                statement = statement.where(
                    PurchaseOrderDetail.purchase_order_id == order_id
                )
            statement = self._apply_load_options(statement, load_details)
            return session.exec(statement).all()

    def update_received_quantity_command(
        self, detail_id: UUID, received_qty: int
    ) -> PurchaseOrderDetail:
        """Update the received quantity for a detail."""
        with self._get_session() as session:
            detail = session.get(PurchaseOrderDetail, detail_id)
            if not detail:
                raise ValueError(f"PurchaseOrderDetail with id {detail_id} does not exist")
            
            detail.quantity_received = received_qty
            session.add(detail)
            session.commit()
            session.refresh(detail)
            return detail

    def add_received_quantity_command(
        self, detail_id: UUID, additional_qty: int
    ) -> PurchaseOrderDetail:
        """Add to the received quantity (for partial receipts)."""
        with self._get_session() as session:
            detail = session.get(PurchaseOrderDetail, detail_id)
            if not detail:
                raise ValueError(f"PurchaseOrderDetail with id {detail_id} does not exist")
            
            current_received = detail.quantity_received or 0
            detail.quantity_received = current_received + additional_qty
            
            session.add(detail)
            session.commit()
            session.refresh(detail)
            return detail
