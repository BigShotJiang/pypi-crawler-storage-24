/* stdbool.h - Boolean type for uc80 */
#ifndef _STDBOOL_H
#define _STDBOOL_H

#define bool _Bool
#define true 1
#define false 0
#define __bool_true_false_are_defined 1

#endif /* _STDBOOL_H */
