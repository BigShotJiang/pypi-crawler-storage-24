:::xwr.rsp.numpy
