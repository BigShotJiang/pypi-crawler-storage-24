::: xwr.radar.common
