"""
Parser correctness tests.

Each test gives the parser a known code snippet and asserts on the
extracted symbols, imports, and call sites — including the new
caller_name field that drives the call graph.
"""

from __future__ import annotations
import pytest

from codebase_mcp.parsers.python import PythonParser
from codebase_mcp.parsers.typescript import TypeScriptParser
from codebase_mcp.parsers.go import GoParser
from codebase_mcp.parsers.rust import RustParser


# ─── Python ───────────────────────────────────────────────────────────────────

class TestPythonParser:
    P = PythonParser()

    def _parse(self, src: str):
        return self.P.parse("test.py", src)

    def test_top_level_function(self):
        r = self._parse("def greet(name: str) -> str:\n    return f'hi {name}'\n")
        assert any(s.kind == "function" and s.name == "greet" for s in r.symbols)

    def test_class_and_methods(self):
        r = self._parse("""
class Foo:
    def bar(self):
        pass
    def _private(self):
        pass
""")
        names = {s.name: s for s in r.symbols}
        assert "Foo" in names and names["Foo"].kind == "class"
        assert "bar" in names and names["bar"].kind == "method"
        assert names["bar"].parent_name == "Foo"
        assert names["_private"].is_exported is False

    def test_async_function(self):
        r = self._parse("async def fetch(url):\n    pass\n")
        fn = next(s for s in r.symbols if s.name == "fetch")
        assert fn.is_async is True

    def test_module_import(self):
        r = self._parse("import os\nimport sys\n")
        names = {i.imported_name for i in r.imports}
        assert "os" in names
        assert "sys" in names

    def test_from_import(self):
        r = self._parse("from pathlib import Path\nfrom os.path import join, exists\n")
        names = {i.imported_name for i in r.imports}
        assert "pathlib.Path" in names
        assert "os.path.join" in names
        assert "os.path.exists" in names

    def test_call_site_recorded(self):
        r = self._parse("""
def main():
    do_work()
    validate()
""")
        callees = {c.callee_name for c in r.calls}
        assert "do_work" in callees
        assert "validate" in callees

    def test_caller_name_set(self):
        r = self._parse("""
def helper():
    pass

def main():
    helper()
    other()
""")
        main_calls = [c for c in r.calls if c.caller_name == "main"]
        assert len(main_calls) == 2
        assert {c.callee_name for c in main_calls} == {"helper", "other"}

    def test_caller_name_nested_function(self):
        r = self._parse("""
def outer():
    def inner():
        leaf()
    helper()
""")
        # leaf() is inside inner(), helper() is inside outer()
        leaf_call = next(c for c in r.calls if c.callee_name == "leaf")
        helper_call = next(c for c in r.calls if c.callee_name == "helper")
        assert leaf_call.caller_name == "inner"
        assert helper_call.caller_name == "outer"

    def test_builtin_calls_filtered(self):
        r = self._parse("""
def process(items):
    result = list(items)
    n = len(result)
    return str(n)
""")
        callees = {c.callee_name for c in r.calls}
        assert "list" not in callees
        assert "len" not in callees
        assert "str" not in callees

    def test_no_parse_error(self):
        r = self._parse("def foo():\n    return 1\n")
        assert r.parse_error is None

    def test_line_count(self):
        src = "a = 1\nb = 2\nc = 3\n"
        r = self._parse(src)
        assert r.line_count == 4

    def test_docstring_extracted(self):
        r = self._parse('''
def documented():
    """This is the docstring."""
    pass
''')
        fn = next(s for s in r.symbols if s.name == "documented")
        assert fn.docstring and "docstring" in fn.docstring


# ─── TypeScript ───────────────────────────────────────────────────────────────

class TestTypeScriptParser:
    P = TypeScriptParser()

    def _parse(self, src: str, path="test.ts"):
        return self.P.parse(path, src)

    def test_exported_function(self):
        r = self._parse("export function greet(name: string): string { return name; }\n")
        fn = next(s for s in r.symbols if s.name == "greet")
        assert fn.is_exported is True

    def test_class_with_methods(self):
        r = self._parse("""
class UserService {
  findById(id: number) { return null; }
  async createUser(data: any) { return null; }
}
""")
        names = {s.name: s for s in r.symbols}
        assert "UserService" in names and names["UserService"].kind == "class"
        assert "findById" in names and names["findById"].kind == "method"
        assert names["findById"].parent_name == "UserService"
        assert names["createUser"].is_async is True

    def test_method_parent_class_set(self):
        r = self._parse("""
class Auth {
  validateToken(t: string): boolean { return true; }
}
""")
        method = next(s for s in r.symbols if s.name == "validateToken")
        assert method.parent_name == "Auth"

    def test_interface_extracted(self):
        r = self._parse("interface IUser { id: number; name: string; }\n")
        iface = next(s for s in r.symbols if s.name == "IUser")
        assert iface.kind == "interface"

    def test_import_from_module(self):
        r = self._parse("import { useState } from 'react';\n")
        assert any(i.imported_name == "react" for i in r.imports)

    def test_call_with_caller_name(self):
        r = self._parse("""
function processOrder(order: any) {
  validateOrder(order);
  saveToDb(order);
}
""")
        calls = [c for c in r.calls if c.caller_name == "processOrder"]
        callees = {c.callee_name for c in calls}
        assert "validateOrder" in callees
        assert "saveToDb" in callees

    def test_method_call_caller_name(self):
        r = self._parse("""
class PaymentService {
  charge(amount: number) {
    this.validate(amount);
    logPayment(amount);
  }
  validate(amount: number) { }
}
""")
        calls_in_charge = [c for c in r.calls if c.caller_name == "charge"]
        callees = {c.callee_name for c in calls_in_charge}
        assert "validate" in callees or "logPayment" in callees

    def test_javascript_file(self):
        r = self._parse("function add(a, b) { return helper(a, b); }\n", "test.js")
        assert r.language == "javascript"
        assert any(s.name == "add" for s in r.symbols)

    def test_arrow_function_extracted(self):
        r = self._parse("const double = (x: number) => x * 2;\n")
        assert any(s.name == "double" for s in r.symbols)


# ─── Go ───────────────────────────────────────────────────────────────────────

class TestGoParser:
    P = GoParser()

    def _parse(self, src: str):
        return self.P.parse("main.go", src)

    def test_function_extracted(self):
        r = self._parse("package main\nfunc Hello() string { return \"hi\" }\n")
        fn = next(s for s in r.symbols if s.name == "Hello")
        assert fn.kind == "function"
        assert fn.is_exported is True  # starts with uppercase

    def test_unexported_function(self):
        r = self._parse("package main\nfunc helper() { }\n")
        fn = next(s for s in r.symbols if s.name == "helper")
        assert fn.is_exported is False

    def test_struct_and_method(self):
        r = self._parse("""
package main

type Server struct {
    port int
}

func (s *Server) Start() error {
    return nil
}
""")
        names = {sym.name: sym for sym in r.symbols}
        assert "Server" in names and names["Server"].kind == "struct"
        assert "Start" in names and names["Start"].kind == "method"
        assert names["Start"].parent_name == "Server"

    def test_interface_extracted(self):
        r = self._parse("""
package main

type Handler interface {
    ServeHTTP(w interface{}, r interface{})
}
""")
        iface = next(s for s in r.symbols if s.name == "Handler")
        assert iface.kind == "interface"

    def test_import_extracted(self):
        r = self._parse('package main\nimport "fmt"\nfunc main() { fmt.Println("hi") }\n')
        assert any(i.imported_name == "fmt" for i in r.imports)

    def test_caller_name_set(self):
        r = self._parse("""
package main

func processRequest(req string) {
    validate(req)
    respond(req)
}

func validate(s string) {}
func respond(s string) {}
""")
        process_calls = [c for c in r.calls if c.caller_name == "processRequest"]
        callees = {c.callee_name for c in process_calls}
        assert "validate" in callees
        assert "respond" in callees

    def test_builtin_calls_filtered(self):
        r = self._parse("""
package main

func work(items []int) []int {
    result := make([]int, 0)
    result = append(result, items...)
    return result
}
""")
        callees = {c.callee_name for c in r.calls}
        assert "make" not in callees
        assert "append" not in callees


# ─── Rust ─────────────────────────────────────────────────────────────────────

class TestRustParser:
    P = RustParser()

    def _parse(self, src: str):
        return self.P.parse("lib.rs", src)

    def test_function_extracted(self):
        r = self._parse("pub fn greet(name: &str) -> String { name.to_owned() }\n")
        fn = next(s for s in r.symbols if s.name == "greet")
        assert fn.kind == "function"
        assert fn.is_exported is True  # has pub

    def test_struct_extracted(self):
        r = self._parse("pub struct Config { pub port: u16 }\n")
        s = next(sym for sym in r.symbols if sym.name == "Config")
        assert s.kind == "struct"

    def test_impl_methods(self):
        r = self._parse("""
pub struct Server { port: u16 }

impl Server {
    pub fn new(port: u16) -> Self {
        Server { port }
    }
    fn start(&self) {
        self.connect();
    }
}
""")
        names = {s.name: s for s in r.symbols}
        assert "Server" in names
        assert "new" in names and names["new"].kind == "method"
        assert names["new"].parent_name == "Server"

    def test_caller_name_set(self):
        r = self._parse("""
fn handle_request(req: &str) {
    parse_request(req);
    send_response(req);
}

fn parse_request(s: &str) {}
fn send_response(s: &str) {}
""")
        handle_calls = [c for c in r.calls if c.caller_name == "handle_request"]
        callees = {c.callee_name for c in handle_calls}
        assert "parse_request" in callees
        assert "send_response" in callees

    def test_use_declaration(self):
        r = self._parse("use std::collections::HashMap;\n")
        assert any("HashMap" in i.imported_name for i in r.imports)
