"""
Indexer integration tests: incremental behaviour, deletion detection,
hash-based skip, FTS rebuild, and metadata.
"""

from __future__ import annotations
import os
import textwrap
import time

import pytest

from codebase_mcp.config import Config
from codebase_mcp.db import open_db
from codebase_mcp.indexer import run_index, find_stale_files


# ─── Helpers ──────────────────────────────────────────────────────────────────

def write(root: str, rel: str, content: str):
    full = os.path.join(root, rel.replace("/", os.sep))
    os.makedirs(os.path.dirname(full) if os.path.dirname(full) else root, exist_ok=True)
    with open(full, "w", encoding="utf-8") as f:
        f.write(textwrap.dedent(content))


def index(root: str, full=False):
    cfg = Config(project_root=root)
    result = run_index(cfg.db_path, root, cfg, full_reindex=full)
    conn = open_db(cfg.db_path)
    return conn, cfg, result


# ─── Initial index ────────────────────────────────────────────────────────────

class TestInitialIndex:
    def test_symbols_stored(self, tmp_path):
        root = str(tmp_path)
        write(root, "app.py", "def hello(): pass\nclass World: pass\n")
        conn, _, res = index(root)

        syms = conn.execute("SELECT name FROM symbols").fetchall()
        names = {r["name"] for r in syms}
        assert "hello" in names
        assert "World" in names

    def test_file_record_stored(self, tmp_path):
        root = str(tmp_path)
        write(root, "main.go", "package main\nfunc main() {}\n")
        conn, _, _ = index(root)

        row = conn.execute("SELECT * FROM files WHERE path='main.go'").fetchone()
        assert row is not None
        assert row["language"] == "go"
        assert row["sha256"] is not None

    def test_index_result_counts(self, tmp_path):
        root = str(tmp_path)
        write(root, "a.py", "def f(): pass\n")
        write(root, "b.py", "def g(): pass\n")
        _, _, res = index(root)

        assert res.files_scanned == 2
        assert res.files_reparsed == 2
        assert res.symbols_added >= 2
        assert res.files_errored == 0

    def test_metadata_stored(self, tmp_path):
        root = str(tmp_path)
        write(root, "x.py", "x = 1\n")
        conn, _, _ = index(root)

        last = conn.execute(
            "SELECT value FROM meta WHERE key='last_indexed'"
        ).fetchone()
        assert last is not None
        assert "Z" in last["value"]  # ISO timestamp with Z suffix

    def test_fts_searchable_after_index(self, tmp_path):
        root = str(tmp_path)
        write(root, "auth.py", """
            def authenticate_user(username, password):
                pass
        """)
        conn, _, _ = index(root)

        rows = conn.execute(
            "SELECT * FROM symbols_fts WHERE symbols_fts MATCH 'authenticate_user'"
        ).fetchall()
        assert len(rows) > 0


# ─── Incremental index (hash-based skip) ──────────────────────────────────────

class TestIncrementalIndex:
    def test_unchanged_file_not_reparsed(self, tmp_path):
        root = str(tmp_path)
        write(root, "stable.py", "def stable(): pass\n")

        # First index
        _, cfg, res1 = index(root)
        assert res1.files_reparsed == 1

        # Second index — nothing changed
        res2 = run_index(cfg.db_path, root, cfg, full_reindex=False)
        assert res2.files_reparsed == 0
        assert res2.files_changed == 0

    def test_modified_file_reparsed(self, tmp_path):
        root = str(tmp_path)
        write(root, "changing.py", "def v1(): pass\n")

        _, cfg, _ = index(root)

        # Modify file
        write(root, "changing.py", "def v1(): pass\ndef v2(): pass\n")
        res2 = run_index(cfg.db_path, root, cfg, full_reindex=False)

        assert res2.files_changed == 1
        assert res2.files_reparsed == 1

        conn = open_db(cfg.db_path)
        names = {r["name"] for r in conn.execute("SELECT name FROM symbols").fetchall()}
        assert "v2" in names

    def test_new_file_indexed(self, tmp_path):
        root = str(tmp_path)
        write(root, "existing.py", "def existing(): pass\n")
        _, cfg, _ = index(root)

        write(root, "new_module.py", "def brand_new(): pass\n")
        res2 = run_index(cfg.db_path, root, cfg, full_reindex=False)
        assert res2.files_changed == 1

        conn = open_db(cfg.db_path)
        names = {r["name"] for r in conn.execute("SELECT name FROM symbols").fetchall()}
        assert "brand_new" in names

    def test_symbol_removed_when_file_updated(self, tmp_path):
        root = str(tmp_path)
        write(root, "mod.py", "def old_func(): pass\ndef keep_func(): pass\n")
        _, cfg, _ = index(root)

        # Remove old_func from the file
        write(root, "mod.py", "def keep_func(): pass\n")
        run_index(cfg.db_path, root, cfg, full_reindex=False)

        conn = open_db(cfg.db_path)
        names = {r["name"] for r in conn.execute("SELECT name FROM symbols").fetchall()}
        assert "old_func" not in names
        assert "keep_func" in names


# ─── Deletion detection ───────────────────────────────────────────────────────

class TestDeletionDetection:
    def test_deleted_file_removed_from_db(self, tmp_path):
        root = str(tmp_path)
        write(root, "to_delete.py", "def doomed(): pass\n")
        write(root, "survivor.py", "def safe(): pass\n")
        _, cfg, _ = index(root)

        os.remove(os.path.join(root, "to_delete.py"))
        run_index(cfg.db_path, root, cfg, full_reindex=False)

        conn = open_db(cfg.db_path)
        files = {r["path"] for r in conn.execute("SELECT path FROM files").fetchall()}
        assert "to_delete.py" not in files
        assert "survivor.py" in files

    def test_deleted_file_symbols_cascade_deleted(self, tmp_path):
        root = str(tmp_path)
        write(root, "to_delete.py", "def doomed_symbol(): pass\n")
        write(root, "other.py", "x = 1\n")
        _, cfg, _ = index(root)

        os.remove(os.path.join(root, "to_delete.py"))
        run_index(cfg.db_path, root, cfg, full_reindex=False)

        conn = open_db(cfg.db_path)
        names = {r["name"] for r in conn.execute("SELECT name FROM symbols").fetchall()}
        assert "doomed_symbol" not in names

    def test_result_reports_deleted_count(self, tmp_path):
        root = str(tmp_path)
        write(root, "a.py", "x = 1\n")
        write(root, "b.py", "y = 2\n")
        _, cfg, _ = index(root)

        os.remove(os.path.join(root, "a.py"))
        res = run_index(cfg.db_path, root, cfg, full_reindex=False)
        assert res.files_deleted == 1


# ─── find_stale_files ─────────────────────────────────────────────────────────

class TestFindStaleFiles:
    def test_fresh_index_no_stale(self, tmp_path):
        root = str(tmp_path)
        write(root, "app.py", "x = 1\n")
        conn, cfg, _ = index(root)

        stale = find_stale_files(conn, root, cfg)
        assert stale == []

    def test_modified_file_detected_as_stale(self, tmp_path):
        root = str(tmp_path)
        write(root, "app.py", "x = 1\n")
        conn, cfg, _ = index(root)

        write(root, "app.py", "x = 2\n")  # change content
        stale = find_stale_files(conn, root, cfg)
        assert "app.py" in stale

    def test_new_file_detected_as_stale(self, tmp_path):
        root = str(tmp_path)
        write(root, "existing.py", "x = 1\n")
        conn, cfg, _ = index(root)

        write(root, "brand_new.py", "y = 2\n")
        stale = find_stale_files(conn, root, cfg)
        assert "brand_new.py" in stale


# ─── Full re-index ────────────────────────────────────────────────────────────

class TestFullReindex:
    def test_full_reindex_reparsed_all(self, tmp_path):
        root = str(tmp_path)
        write(root, "a.py", "def a(): pass\n")
        write(root, "b.py", "def b(): pass\n")
        _, cfg, _ = index(root)

        res = run_index(cfg.db_path, root, cfg, full_reindex=True)
        assert res.files_reparsed == 2

    def test_full_reindex_symbols_consistent(self, tmp_path):
        root = str(tmp_path)
        write(root, "mod.py", "def func_a(): pass\ndef func_b(): pass\n")

        conn, cfg, _ = index(root)
        run_index(cfg.db_path, root, cfg, full_reindex=True)

        names = {r["name"] for r in conn.execute("SELECT name FROM symbols").fetchall()}
        assert "func_a" in names
        assert "func_b" in names


# ─── Multi-language project ───────────────────────────────────────────────────

class TestMultiLanguageProject:
    def test_mixed_project_all_indexed(self, tmp_path):
        root = str(tmp_path)
        write(root, "backend/main.go", "package main\nfunc main() {}\n")
        write(root, "frontend/app.ts", "export function render() {}\n")
        write(root, "scripts/deploy.py", "def deploy(): pass\n")
        write(root, "Makefile", "build:\n\tgo build\n")

        conn, _, res = index(root)

        assert res.files_scanned == 4
        langs = {r["language"] for r in conn.execute("SELECT language FROM files").fetchall()}
        assert "go" in langs
        assert "typescript" in langs
        assert "python" in langs
        assert "makefile" in langs
