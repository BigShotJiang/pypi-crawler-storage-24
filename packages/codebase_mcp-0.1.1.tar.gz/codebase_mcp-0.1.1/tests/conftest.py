"""Shared pytest fixtures for codebase-mcp tests."""

from __future__ import annotations
import os
import sys
import tempfile
import textwrap

import pytest

# Ensure src/ is on the path so we can import without installing
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "src"))


# ─── Fixtures ─────────────────────────────────────────────────────────────────

@pytest.fixture
def tmp_project(tmp_path):
    """Return a fresh temporary directory — used as a fake project root."""
    return tmp_path


def write_file(root, rel_path: str, content: str) -> str:
    """Helper: write content to root/rel_path, creating directories as needed."""
    full = os.path.join(root, rel_path.replace("/", os.sep))
    os.makedirs(os.path.dirname(full), exist_ok=True)
    with open(full, "w", encoding="utf-8") as f:
        f.write(textwrap.dedent(content))
    return full


@pytest.fixture
def write(tmp_project):
    """Return a helper that writes files into tmp_project."""
    def _write(rel_path: str, content: str) -> str:
        return write_file(str(tmp_project), rel_path, content)
    return _write


@pytest.fixture
def fresh_db(tmp_path):
    """Return an open DB connection backed by a temp file."""
    from codebase_mcp.db import open_db
    db_path = str(tmp_path / "test.db")
    conn = open_db(db_path)
    return conn, db_path
