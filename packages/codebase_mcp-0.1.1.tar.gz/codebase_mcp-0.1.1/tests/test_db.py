"""
Database layer tests: schema, CRUD operations, FTS, decisions, notes, sessions.
"""

from __future__ import annotations
import pytest

from codebase_mcp.db import (
    open_db, transaction,
    upsert_file, get_file_by_path, get_file_sha256, delete_file, list_all_files,
    insert_symbol, get_file_symbols, get_symbol_by_qualified_name,
    insert_import, get_file_imports,
    insert_call, get_unresolved_calls, resolve_call, get_callers, get_callees,
    insert_decision, search_decisions_db, update_decision_db,
    insert_note, get_notes_db,
    upsert_session, touch_session,
    get_stats, set_meta, get_meta, get_all_meta,
    search_symbols_fts,
)


# ─── Helpers ──────────────────────────────────────────────────────────────────

def add_file(conn, path="src/foo.py", sha="abc123", lang="python") -> int:
    with transaction(conn):
        return upsert_file(conn, path, sha, 100, lang, 10)


def add_symbol(conn, file_id, name="my_func", kind="function", qname=None) -> int:
    with transaction(conn):
        return insert_symbol(
            conn, file_id=file_id, kind=kind, name=name,
            qualified_name=qname or f"src.foo.{name}",
            signature=f"def {name}():", docstring=None,
            line_start=1, line_end=5, col_start=0, col_end=0,
            parent_id=None, parent_name=None,
            is_exported=True, is_async=False, return_type=None,
        )


# ─── Schema & connection ──────────────────────────────────────────────────────

class TestDbConnection:
    def test_opens_without_error(self, fresh_db):
        conn, _ = fresh_db
        assert conn is not None

    def test_schema_tables_exist(self, fresh_db):
        conn, _ = fresh_db
        tables = {r[0] for r in conn.execute(
            "SELECT name FROM sqlite_master WHERE type='table'"
        ).fetchall()}
        for expected in ("files", "symbols", "imports", "calls",
                         "decisions", "notes", "sessions", "meta"):
            assert expected in tables, f"Table '{expected}' missing from schema"

    def test_fts_tables_exist(self, fresh_db):
        conn, _ = fresh_db
        tables = {r[0] for r in conn.execute(
            "SELECT name FROM sqlite_master WHERE type='table'"
        ).fetchall()}
        assert "symbols_fts" in tables
        assert "decisions_fts" in tables

    def test_schema_version_set(self, fresh_db):
        conn, _ = fresh_db
        v = get_meta(conn, "schema_version")
        assert v is not None


# ─── File CRUD ────────────────────────────────────────────────────────────────

class TestFileCRUD:
    def test_upsert_creates_file(self, fresh_db):
        conn, _ = fresh_db
        fid = add_file(conn)
        assert isinstance(fid, int) and fid > 0

    def test_get_file_by_path(self, fresh_db):
        conn, _ = fresh_db
        add_file(conn, path="main.py", sha="deadbeef")
        row = get_file_by_path(conn, "main.py")
        assert row is not None
        assert row["sha256"] == "deadbeef"
        assert row["language"] == "python"

    def test_get_file_sha256(self, fresh_db):
        conn, _ = fresh_db
        add_file(conn, path="utils.py", sha="cafebabe")
        sha = get_file_sha256(conn, "utils.py")
        assert sha == "cafebabe"

    def test_get_nonexistent_file_returns_none(self, fresh_db):
        conn, _ = fresh_db
        assert get_file_by_path(conn, "ghost.py") is None
        assert get_file_sha256(conn, "ghost.py") is None

    def test_upsert_updates_existing(self, fresh_db):
        conn, _ = fresh_db
        fid1 = add_file(conn, sha="v1")
        fid2 = add_file(conn, sha="v2")
        assert fid1 == fid2  # same id, just updated
        assert get_file_sha256(conn, "src/foo.py") == "v2"

    def test_delete_file(self, fresh_db):
        conn, _ = fresh_db
        add_file(conn, path="temp.py")
        with transaction(conn):
            delete_file(conn, "temp.py")
        assert get_file_by_path(conn, "temp.py") is None

    def test_list_all_files(self, fresh_db):
        conn, _ = fresh_db
        add_file(conn, path="a.py")
        add_file(conn, path="b.py")
        files = list_all_files(conn)
        paths = {r["path"] for r in files}
        assert "a.py" in paths
        assert "b.py" in paths


# ─── Symbol CRUD ──────────────────────────────────────────────────────────────

class TestSymbolCRUD:
    def test_insert_symbol(self, fresh_db):
        conn, _ = fresh_db
        fid = add_file(conn)
        sid = add_symbol(conn, fid, name="parse")
        assert isinstance(sid, int) and sid > 0

    def test_get_file_symbols(self, fresh_db):
        conn, _ = fresh_db
        fid = add_file(conn)
        add_symbol(conn, fid, name="foo")
        add_symbol(conn, fid, name="bar")
        syms = get_file_symbols(conn, fid)
        names = {s["name"] for s in syms}
        assert "foo" in names
        assert "bar" in names

    def test_get_symbol_by_qualified_name(self, fresh_db):
        conn, _ = fresh_db
        fid = add_file(conn)
        add_symbol(conn, fid, name="validate", qname="src.auth.validate")
        sym = get_symbol_by_qualified_name(conn, "src.auth.validate")
        assert sym is not None
        assert sym["name"] == "validate"

    def test_symbols_cascade_delete_with_file(self, fresh_db):
        conn, _ = fresh_db
        fid = add_file(conn, path="doomed.py")
        add_symbol(conn, fid, name="temporary")
        with transaction(conn):
            delete_file(conn, "doomed.py")
        syms = conn.execute("SELECT * FROM symbols WHERE file_id=?", (fid,)).fetchall()
        assert len(syms) == 0


# ─── Import CRUD ──────────────────────────────────────────────────────────────

class TestImportCRUD:
    def test_insert_and_get_imports(self, fresh_db):
        conn, _ = fresh_db
        fid = add_file(conn)
        with transaction(conn):
            insert_import(conn, fid, "os", None, 1, "module")
            insert_import(conn, fid, "pathlib.Path", None, 2, "from")
        imps = get_file_imports(conn, fid)
        names = {i["imported_name"] for i in imps}
        assert "os" in names
        assert "pathlib.Path" in names


# ─── Call CRUD & resolution ───────────────────────────────────────────────────

class TestCallCRUD:
    def test_insert_call_unresolved(self, fresh_db):
        conn, _ = fresh_db
        fid = add_file(conn)
        with transaction(conn):
            cid = insert_call(conn, fid, None, "target_func", 5, "direct")
        unresolved = get_unresolved_calls(conn)
        assert any(r["id"] == cid for r in unresolved)

    def test_resolve_call(self, fresh_db):
        conn, _ = fresh_db
        fid = add_file(conn)
        sid = add_symbol(conn, fid, name="target_func")
        with transaction(conn):
            cid = insert_call(conn, fid, None, "target_func", 5, "direct")
        with transaction(conn):
            resolve_call(conn, cid, sid)
        row = conn.execute("SELECT callee_id FROM calls WHERE id=?", (cid,)).fetchone()
        assert row["callee_id"] == sid

    def test_get_callers(self, fresh_db):
        conn, _ = fresh_db
        fid = add_file(conn)
        caller_id = add_symbol(conn, fid, name="caller_func")
        callee_id = add_symbol(conn, fid, name="callee_func")
        with transaction(conn):
            cid = insert_call(conn, fid, caller_id, "callee_func", 10, "direct")
            resolve_call(conn, cid, callee_id)
        callers = get_callers(conn, callee_id)
        assert any(r["caller_id"] == caller_id for r in callers)

    def test_get_callees(self, fresh_db):
        conn, _ = fresh_db
        fid = add_file(conn)
        caller_id = add_symbol(conn, fid, name="caller_func")
        callee_id = add_symbol(conn, fid, name="callee_func")
        with transaction(conn):
            cid = insert_call(conn, fid, caller_id, "callee_func", 10, "direct")
            resolve_call(conn, cid, callee_id)
        callees = get_callees(conn, caller_id)
        assert any(r["callee_id"] == callee_id for r in callees)


# ─── FTS search ───────────────────────────────────────────────────────────────

class TestFTSSearch:
    def test_search_symbols_finds_match(self, fresh_db, tmp_path):
        # FTS requires a real index run to populate
        from codebase_mcp.config import Config
        from codebase_mcp.indexer import run_index
        import os, textwrap

        root = str(tmp_path)
        with open(os.path.join(root, "auth.py"), "w") as f:
            f.write("def authenticate_user(u, p): pass\n")

        cfg = Config(project_root=root)
        run_index(cfg.db_path, root, cfg, full_reindex=True)
        conn = open_db(cfg.db_path)

        results = search_symbols_fts(conn, "authenticate_user")
        assert any(r["name"] == "authenticate_user" for r in results)

    def test_search_symbols_kind_filter(self, fresh_db, tmp_path):
        from codebase_mcp.config import Config
        from codebase_mcp.indexer import run_index
        import os

        root = str(tmp_path)
        with open(os.path.join(root, "models.py"), "w") as f:
            f.write("class UserModel: pass\ndef create_user(): pass\n")

        cfg = Config(project_root=root)
        run_index(cfg.db_path, root, cfg, full_reindex=True)
        conn = open_db(cfg.db_path)

        classes = search_symbols_fts(conn, "", kind="class")
        assert all(r["kind"] == "class" for r in classes)


# ─── Decisions ────────────────────────────────────────────────────────────────

class TestDecisions:
    def test_insert_and_search_decision(self, fresh_db):
        conn, _ = fresh_db
        with transaction(conn):
            did = insert_decision(
                conn, None, "Use SQLite for storage",
                "architecture", "SQLite is portable and zero-config.", [], [],
            )
            conn.execute("INSERT INTO decisions_fts(decisions_fts) VALUES('rebuild')")

        results = search_decisions_db(conn, query="SQLite")
        assert any(r["id"] == did for r in results)

    def test_update_decision_status(self, fresh_db):
        conn, _ = fresh_db
        with transaction(conn):
            did = insert_decision(conn, None, "Old decision", "general", "Body.", [], [])
        with transaction(conn):
            update_decision_db(conn, did, status="superseded", body=None)

        row = conn.execute("SELECT status FROM decisions WHERE id=?", (did,)).fetchone()
        assert row["status"] == "superseded"

    def test_active_decisions_default_filter(self, fresh_db):
        conn, _ = fresh_db
        with transaction(conn):
            d1 = insert_decision(conn, None, "Active one", "general", "Active.", [], [])
            d2 = insert_decision(conn, None, "Old one", "general", "Old.", [], [])
            update_decision_db(conn, d2, status="superseded", body=None)

        active = search_decisions_db(conn, status="active")
        ids = {r["id"] for r in active}
        assert d1 in ids
        assert d2 not in ids


# ─── Notes ────────────────────────────────────────────────────────────────────

class TestNotes:
    def test_insert_and_get_project_note(self, fresh_db):
        conn, _ = fresh_db
        with transaction(conn):
            nid = insert_note(conn, None, "project", None, "Remember to add auth.", [])
        notes = get_notes_db(conn, scope="project")
        assert any(n["id"] == nid for n in notes)

    def test_file_scoped_note(self, fresh_db):
        conn, _ = fresh_db
        with transaction(conn):
            insert_note(conn, None, "file", "src/auth.py", "Token expiry logic here.", [])
        notes = get_notes_db(conn, scope="file", scope_ref="src/auth.py")
        assert len(notes) == 1
        assert "Token expiry" in notes[0]["body"]

    def test_notes_not_leaked_across_scopes(self, fresh_db):
        conn, _ = fresh_db
        with transaction(conn):
            insert_note(conn, None, "file", "a.py", "Note for a.", [])
            insert_note(conn, None, "file", "b.py", "Note for b.", [])
        notes_a = get_notes_db(conn, scope="file", scope_ref="a.py")
        assert all("Note for a" in n["body"] for n in notes_a)


# ─── Stats ────────────────────────────────────────────────────────────────────

class TestStats:
    def test_stats_on_empty_db(self, fresh_db):
        conn, _ = fresh_db
        stats = get_stats(conn)
        assert stats["files_indexed"] == 0
        assert stats["symbols_total"] == 0

    def test_stats_after_inserts(self, fresh_db):
        conn, _ = fresh_db
        fid = add_file(conn)
        add_symbol(conn, fid, name="func1", kind="function")
        add_symbol(conn, fid, name="MyClass", kind="class")

        stats = get_stats(conn)
        assert stats["files_indexed"] == 1
        assert stats["symbols_total"] == 2
        assert stats["functions"] == 1
        assert stats["classes"] == 1


# ─── Sessions ─────────────────────────────────────────────────────────────────

class TestSessions:
    def test_upsert_session(self, fresh_db):
        conn, _ = fresh_db
        with transaction(conn):
            upsert_session(conn, "sess-001", "claude-code")
        row = conn.execute("SELECT * FROM sessions WHERE id='sess-001'").fetchone()
        assert row is not None
        assert row["agent_hint"] == "claude-code"

    def test_touch_session_updates_last_active(self, fresh_db):
        conn, _ = fresh_db
        with transaction(conn):
            upsert_session(conn, "sess-002", "cursor")
        t1 = conn.execute("SELECT last_active FROM sessions WHERE id='sess-002'").fetchone()["last_active"]
        import time; time.sleep(0.01)
        with transaction(conn):
            touch_session(conn, "sess-002")
        t2 = conn.execute("SELECT last_active FROM sessions WHERE id='sess-002'").fetchone()["last_active"]
        assert t2 >= t1


# ─── Meta ─────────────────────────────────────────────────────────────────────

class TestMeta:
    def test_set_and_get_meta(self, fresh_db):
        conn, _ = fresh_db
        with transaction(conn):
            set_meta(conn, "project_name", "my-app")
        assert get_meta(conn, "project_name") == "my-app"

    def test_get_all_meta(self, fresh_db):
        conn, _ = fresh_db
        with transaction(conn):
            set_meta(conn, "k1", "v1")
            set_meta(conn, "k2", "v2")
        m = get_all_meta(conn)
        assert m["k1"] == "v1"
        assert m["k2"] == "v2"

    def test_missing_key_returns_none(self, fresh_db):
        conn, _ = fresh_db
        assert get_meta(conn, "nonexistent") is None
