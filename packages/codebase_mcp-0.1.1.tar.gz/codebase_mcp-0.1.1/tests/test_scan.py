"""Tests for scan_files: extension mapping, basename mapping, exclusions, size limit."""

from __future__ import annotations
import os

import pytest

from codebase_mcp.config import Config
from codebase_mcp.indexer import scan_files


# ─── Helpers ──────────────────────────────────────────────────────────────────

def write(root, rel, content="# placeholder"):
    full = os.path.join(root, rel.replace("/", os.sep))
    os.makedirs(os.path.dirname(full) if os.path.dirname(full) else root, exist_ok=True)
    with open(full, "w") as f:
        f.write(content)


# ─── Extension mapping ────────────────────────────────────────────────────────

class TestExtensionMapping:
    def test_python_file_detected(self, tmp_path):
        write(str(tmp_path), "app.py")
        files = scan_files(str(tmp_path), Config(project_root=str(tmp_path)))
        assert "app.py" in files
        assert files["app.py"][2] == "python"

    def test_typescript_file_detected(self, tmp_path):
        write(str(tmp_path), "src/index.ts")
        files = scan_files(str(tmp_path), Config(project_root=str(tmp_path)))
        assert "src/index.ts" in files
        assert files["src/index.ts"][2] == "typescript"

    def test_go_file_detected(self, tmp_path):
        write(str(tmp_path), "main.go")
        files = scan_files(str(tmp_path), Config(project_root=str(tmp_path)))
        assert "main.go" in files
        assert files["main.go"][2] == "go"

    def test_rust_file_detected(self, tmp_path):
        write(str(tmp_path), "src/lib.rs")
        files = scan_files(str(tmp_path), Config(project_root=str(tmp_path)))
        assert "src/lib.rs" in files
        assert files["src/lib.rs"][2] == "rust"

    def test_jsx_mapped_to_javascript(self, tmp_path):
        write(str(tmp_path), "App.jsx")
        files = scan_files(str(tmp_path), Config(project_root=str(tmp_path)))
        assert "App.jsx" in files
        assert files["App.jsx"][2] == "javascript"

    def test_unknown_extension_skipped(self, tmp_path):
        write(str(tmp_path), "binary.exe")
        write(str(tmp_path), "data.parquet")
        files = scan_files(str(tmp_path), Config(project_root=str(tmp_path)))
        assert not any("binary" in p or "parquet" in p for p in files)


# ─── Basename mapping (extensionless files) ───────────────────────────────────

class TestBasenameMapping:
    def test_makefile_detected(self, tmp_path):
        write(str(tmp_path), "Makefile", "build:\n\techo ok\n")
        files = scan_files(str(tmp_path), Config(project_root=str(tmp_path)))
        assert "Makefile" in files
        assert files["Makefile"][2] == "makefile"

    def test_dockerfile_detected(self, tmp_path):
        write(str(tmp_path), "Dockerfile", "FROM python:3.11\n")
        files = scan_files(str(tmp_path), Config(project_root=str(tmp_path)))
        assert "Dockerfile" in files
        assert files["Dockerfile"][2] == "dockerfile"

    def test_vagrantfile_detected(self, tmp_path):
        write(str(tmp_path), "Vagrantfile", 'Vagrant.configure("2") do |c| end\n')
        files = scan_files(str(tmp_path), Config(project_root=str(tmp_path)))
        assert "Vagrantfile" in files
        assert files["Vagrantfile"][2] == "ruby"

    def test_gemfile_detected(self, tmp_path):
        write(str(tmp_path), "Gemfile", "source 'https://rubygems.org'\n")
        files = scan_files(str(tmp_path), Config(project_root=str(tmp_path)))
        assert "Gemfile" in files

    def test_random_extensionless_binary_skipped(self, tmp_path):
        write(str(tmp_path), "somebinary", "\x00\x01\x02")
        files = scan_files(str(tmp_path), Config(project_root=str(tmp_path)))
        assert "somebinary" not in files


# ─── Exclusion patterns ───────────────────────────────────────────────────────

class TestExclusionPatterns:
    def test_codebase_mcp_dir_excluded(self, tmp_path):
        write(str(tmp_path), ".codebase-mcp/index.db", "binary")
        write(str(tmp_path), "src/main.py")
        files = scan_files(str(tmp_path), Config(project_root=str(tmp_path)))
        assert not any(".codebase-mcp" in p for p in files)
        assert "src/main.py" in files

    def test_node_modules_excluded(self, tmp_path):
        write(str(tmp_path), "node_modules/lodash/index.js")
        write(str(tmp_path), "src/app.js")
        files = scan_files(str(tmp_path), Config(project_root=str(tmp_path)))
        assert not any("node_modules" in p for p in files)
        assert "src/app.js" in files

    def test_venv_excluded(self, tmp_path):
        write(str(tmp_path), ".venv/lib/site.py")
        write(str(tmp_path), "app.py")
        files = scan_files(str(tmp_path), Config(project_root=str(tmp_path)))
        assert not any(".venv" in p for p in files)
        assert "app.py" in files

    def test_pycache_excluded(self, tmp_path):
        write(str(tmp_path), "src/__pycache__/foo.cpython-311.pyc")
        write(str(tmp_path), "src/foo.py")
        files = scan_files(str(tmp_path), Config(project_root=str(tmp_path)))
        assert not any("__pycache__" in p for p in files)
        assert "src/foo.py" in files

    def test_custom_exclude_pattern(self, tmp_path):
        write(str(tmp_path), "generated/schema.py")
        write(str(tmp_path), "src/schema.py")
        cfg = Config(project_root=str(tmp_path),
                     exclude_patterns=["**/generated/**"])
        files = scan_files(str(tmp_path), cfg)
        assert "generated/schema.py" not in files
        assert "src/schema.py" in files

    def test_min_js_excluded(self, tmp_path):
        write(str(tmp_path), "static/jquery.min.js")
        write(str(tmp_path), "src/app.js")
        files = scan_files(str(tmp_path), Config(project_root=str(tmp_path)))
        assert "static/jquery.min.js" not in files
        assert "src/app.js" in files


# ─── File size limit ──────────────────────────────────────────────────────────

class TestSizeLimit:
    def test_large_file_skipped(self, tmp_path):
        big = os.path.join(str(tmp_path), "huge.py")
        with open(big, "wb") as f:
            f.write(b"x = 1\n" * 200_000)  # ~1.2 MB
        cfg = Config(project_root=str(tmp_path), max_file_size_bytes=1_000_000)
        files = scan_files(str(tmp_path), cfg)
        assert "huge.py" not in files

    def test_small_file_included(self, tmp_path):
        write(str(tmp_path), "small.py", "x = 1\n")
        files = scan_files(str(tmp_path), Config(project_root=str(tmp_path)))
        assert "small.py" in files


# ─── SHA256 stability ─────────────────────────────────────────────────────────

class TestHashStability:
    def test_same_content_same_hash(self, tmp_path):
        write(str(tmp_path), "a.py", "x = 1\n")
        write(str(tmp_path), "b.py", "x = 1\n")
        files = scan_files(str(tmp_path), Config(project_root=str(tmp_path)))
        assert files["a.py"][0] == files["b.py"][0]

    def test_different_content_different_hash(self, tmp_path):
        write(str(tmp_path), "a.py", "x = 1\n")
        write(str(tmp_path), "b.py", "y = 2\n")
        files = scan_files(str(tmp_path), Config(project_root=str(tmp_path)))
        assert files["a.py"][0] != files["b.py"][0]
