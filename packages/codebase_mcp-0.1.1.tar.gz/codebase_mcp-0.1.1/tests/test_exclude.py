"""Tests for _matches_any — the glob-based path exclusion helper."""

from __future__ import annotations
import pytest
from codebase_mcp.indexer import _matches_any


# ─── Default exclude patterns (subset) ────────────────────────────────────────

NODE_MODULES  = ["**/node_modules/**"]
CODEBASE_MCP  = ["**/.codebase-mcp/**"]
VENV          = ["**/.venv/**"]
PYCACHE       = ["**/__pycache__/**"]
DIST          = ["**/dist/**"]
ALL_DEFAULTS  = [
    "**/node_modules/**", "**/.venv/**", "**/__pycache__/**",
    "**/.git/**", "**/dist/**", "**/build/**", "**/.next/**",
    "**/target/**", "**/.cargo/**", "**/vendor/**",
    "**/*.min.js", "**/*.min.css", "**/.codebase-mcp/**",
    "**/coverage/**", "**/.pytest_cache/**", "**/*.egg-info/**",
]


# ─── .codebase-mcp exclusion ──────────────────────────────────────────────────

class TestCodebaseMcpExclusion:
    def test_root_relative_file(self):
        # Root-level .codebase-mcp/ — no leading path component
        assert _matches_any(".codebase-mcp/index.db", CODEBASE_MCP)

    def test_root_relative_nested_file(self):
        assert _matches_any(".codebase-mcp/exports/snapshot.json", CODEBASE_MCP)

    def test_bare_dirname_at_root(self):
        # dirname check: os.walk gives us just ".codebase-mcp"
        assert _matches_any(".codebase-mcp", CODEBASE_MCP)

    def test_dirname_with_dot_slash(self):
        # relpath from root produces "./.codebase-mcp"
        assert _matches_any("./.codebase-mcp", CODEBASE_MCP)

    def test_nested_in_subdir(self):
        assert _matches_any("deep/path/.codebase-mcp/foo.db", CODEBASE_MCP)

    def test_normal_file_not_excluded(self):
        assert not _matches_any("src/foo.py", CODEBASE_MCP)

    def test_similar_name_not_excluded(self):
        # ".codebase-mcp-backup" should not match
        assert not _matches_any("codebase-mcp-backup/foo.py", CODEBASE_MCP)


# ─── node_modules exclusion ───────────────────────────────────────────────────

class TestNodeModulesExclusion:
    def test_root_level_file(self):
        assert _matches_any("node_modules/lodash/index.js", NODE_MODULES)

    def test_nested(self):
        assert _matches_any("src/node_modules/foo.js", NODE_MODULES)

    def test_bare_dirname(self):
        assert _matches_any("node_modules", NODE_MODULES)

    def test_dot_slash_prefix(self):
        assert _matches_any("./node_modules", NODE_MODULES)

    def test_src_not_excluded(self):
        assert not _matches_any("src/auth/jwt.py", NODE_MODULES)


# ─── .venv / __pycache__ / dist exclusion ────────────────────────────────────

class TestCommonExclusions:
    def test_venv_file(self):
        assert _matches_any(".venv/lib/python3.11/site.py", VENV)

    def test_venv_dirname(self):
        assert _matches_any(".venv", VENV)

    def test_pycache_file(self):
        assert _matches_any("src/__pycache__/foo.cpython-311.pyc", PYCACHE)

    def test_pycache_dirname(self):
        assert _matches_any("__pycache__", PYCACHE)

    def test_dist_file(self):
        assert _matches_any("dist/bundle.js", DIST)

    def test_dist_nested(self):
        assert _matches_any("packages/core/dist/index.js", DIST)


# ─── Minified file glob ───────────────────────────────────────────────────────

class TestMinifiedGlob:
    def test_min_js(self):
        assert _matches_any("static/jquery.min.js", ["**/*.min.js"])

    def test_min_css(self):
        assert _matches_any("public/app.min.css", ["**/*.min.css"])

    def test_regular_js_not_excluded(self):
        assert not _matches_any("src/app.js", ["**/*.min.js"])


# ─── No false positives on real source paths ─────────────────────────────────

class TestNoFalsePositives:
    @pytest.mark.parametrize("path", [
        "src/auth/jwt.py",
        "src/main.go",
        "lib/utils.ts",
        "Makefile",
        "pyproject.toml",
        "README.md",
        "tests/test_foo.py",
    ])
    def test_source_file_not_excluded(self, path):
        assert not _matches_any(path, ALL_DEFAULTS)

    def test_path_containing_node_modules_as_substring(self):
        # "my_node_modules_helper.py" should NOT be excluded
        assert not _matches_any("src/my_node_modules_helper.py", NODE_MODULES)
