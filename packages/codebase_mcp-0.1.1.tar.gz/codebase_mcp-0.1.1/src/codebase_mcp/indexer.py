"""
Indexer: file scanning, incremental hash-based update, and call resolution.
This is the core engine that keeps the SQLite database in sync with the codebase.
"""

from __future__ import annotations
import fnmatch
import hashlib
import logging
import os
import time
from dataclasses import dataclass, field

from .config import Config, FULLY_SUPPORTED
from .db import (
    open_db, transaction, upsert_file, get_file_sha256, delete_file,
    delete_symbols_for_file, insert_symbol, insert_import, insert_call,
    get_unresolved_calls, resolve_call, get_file_by_path, list_all_files,
    search_symbols_fts, get_all_meta, set_meta, get_meta,
)
from .models import ParseResult, ParsedSymbol
from .parsers import get_parser_for_language

log = logging.getLogger(__name__)


@dataclass
class IndexResult:
    files_scanned: int = 0
    files_changed: int = 0
    files_reparsed: int = 0
    files_deleted: int = 0
    files_errored: int = 0
    symbols_added: int = 0
    symbols_removed: int = 0
    duration_ms: float = 0.0
    errors: list[dict] = field(default_factory=list)


# ─── File scanning ────────────────────────────────────────────────────────────

def _matches_any(path: str, patterns: list[str]) -> bool:
    """Check if path matches any of the given glob patterns."""
    normalized = path.replace("\\", "/")
    # Strip leading "./" that os.path.relpath produces for root-relative paths
    if normalized.startswith("./"):
        normalized = normalized[2:]
    # Three variants to cover all cases with fnmatch (which treats ** like *):
    # 1. normalized        — for paths that already have a leading dir component
    # 2. _/normalized      — for root-relative file paths: ".codebase-mcp/foo.json"
    # 3. _/normalized/_    — for bare directory names: ".codebase-mcp" (needs
    #                        content both before AND after in "**/.codebase-mcp/**")
    anchored = f"_/{normalized}"
    anchored_dir = f"_/{normalized}/_"
    for pat in patterns:
        if fnmatch.fnmatch(normalized, pat):
            return True
        if fnmatch.fnmatch(anchored, pat):
            return True
        if fnmatch.fnmatch(anchored_dir, pat):
            return True
    return False


def _sha256(content: bytes) -> str:
    return hashlib.sha256(content).hexdigest()


def scan_files(root: str, config: Config) -> dict[str, tuple[str, int, str | None]]:
    """
    Walk the project tree and return {rel_path: (sha256, size, language)} for all
    indexable files. Excludes paths matching config.exclude_patterns.
    """
    result: dict[str, tuple[str, int, str | None]] = {}

    for dirpath, dirnames, filenames in os.walk(root):
        # Prune excluded dirs in-place (prevents descending into them)
        rel_dir = os.path.relpath(dirpath, root).replace("\\", "/")
        dirnames[:] = [
            d for d in dirnames
            if not _matches_any(f"{rel_dir}/{d}", config.exclude_patterns)
            and not _matches_any(d, config.exclude_patterns)
        ]

        for fname in filenames:
            full_path = os.path.join(dirpath, fname)
            rel_path = os.path.relpath(full_path, root).replace("\\", "/")

            if _matches_any(rel_path, config.exclude_patterns):
                continue

            ext = os.path.splitext(fname)[1]
            language = config.language_for(ext) or config.language_for_basename(fname)
            if language is None:
                continue  # Not a code file we care about

            try:
                size = os.path.getsize(full_path)
                if size > config.max_file_size_bytes:
                    continue
                with open(full_path, "rb") as f:
                    content_bytes = f.read()
                sha = _sha256(content_bytes)
                result[rel_path] = (sha, size, language)
            except OSError:
                continue

    return result


# ─── Symbol storage ───────────────────────────────────────────────────────────

def _file_module_prefix(rel_path: str) -> str:
    """Convert 'src/auth/jwt.py' → 'src.auth.jwt'"""
    no_ext = os.path.splitext(rel_path)[0]
    return no_ext.replace("\\", "/").replace("/", ".")


def _store_parse_result(conn, file_id: int, rel_path: str, result: ParseResult) -> tuple[int, int]:
    """
    Persist a ParseResult to the database.
    Returns (symbols_added, calls_added).
    """
    prefix = _file_module_prefix(rel_path)

    # Track class name → symbol_id for method parent linking
    class_id_map: dict[str, int] = {}
    symbols_added = 0

    for sym in result.symbols:
        if sym.parent_name:
            qname = f"{prefix}.{sym.parent_name}.{sym.name}"
        else:
            qname = f"{prefix}.{sym.name}"

        parent_id = class_id_map.get(sym.parent_name) if sym.parent_name else None

        sid = insert_symbol(
            conn,
            file_id=file_id,
            kind=sym.kind,
            name=sym.name,
            qualified_name=qname,
            signature=sym.signature or "",
            docstring=sym.docstring,
            line_start=sym.line_start,
            line_end=sym.line_end,
            col_start=sym.col_start,
            col_end=sym.col_end,
            parent_id=parent_id,
            parent_name=sym.parent_name,
            is_exported=sym.is_exported,
            is_async=sym.is_async,
            return_type=sym.return_type,
        )
        symbols_added += 1

        if sym.kind in ("class", "struct", "trait", "interface", "enum"):
            class_id_map[sym.name] = sid

    for imp in result.imports:
        insert_import(
            conn,
            file_id=file_id,
            imported_name=imp.imported_name,
            alias=imp.alias,
            line_number=imp.line_number,
            import_kind=imp.import_kind,
        )

    calls_added = 0
    for call in result.calls:
        # Try to find the caller symbol (enclosing function)
        caller_id = None
        if call.caller_name:
            sym_match = conn.execute(
                "SELECT id FROM symbols WHERE file_id=? AND name=?",
                (file_id, call.caller_name),
            ).fetchone()
            if sym_match:
                caller_id = sym_match["id"]

        insert_call(
            conn,
            caller_file_id=file_id,
            caller_id=caller_id,
            callee_name=call.callee_name,
            line_number=call.line_number,
            call_kind=call.call_kind,
        )
        calls_added += 1

    return symbols_added, calls_added


# ─── Call resolution ──────────────────────────────────────────────────────────

def resolve_calls(conn) -> int:
    """
    Post-index pass: fill in callee_id for unresolved calls.

    Three strategies tried in order for each call site:

    1. Import-aware  — the callee name appears in the caller file's import list;
                       resolve it to a symbol in the imported module's file.
       Example: file A has `from utils.db import open_db`, calls `open_db()`
                → resolves to the `open_db` symbol in utils/db.py.

    2. Same-file     — the callee is defined in the same file as the call site.
       Catches intra-module helper calls that bypass imports entirely.

    3. Unique-global — only one symbol with that name exists in the whole index.
       Last resort; avoids false positives for common names.

    Returns the number of calls that were successfully resolved.
    """
    unresolved = conn.execute(
        "SELECT id, callee_name, caller_file_id FROM calls WHERE callee_id IS NULL"
    ).fetchall()
    if not unresolved:
        return 0

    # ── Pre-build symbol index: name → [(file_id, symbol_id), ...] ────────────
    all_symbols: dict[str, list[tuple[int, int]]] = {}
    for row in conn.execute("SELECT id, name, file_id FROM symbols"):
        all_symbols.setdefault(row["name"], []).append((row["file_id"], row["id"]))

    # ── Pre-build import context per file ─────────────────────────────────────
    # Maps file_id → {short_name: [candidate_file_id, ...]}
    # "short_name" is the last dotted component: "utils.db.open_db" → "open_db"
    file_import_map: dict[int, dict[str, list[int]]] = {}

    for imp in conn.execute(
        "SELECT file_id, imported_name, alias, resolved_file_id FROM imports"
    ):
        fid: int = imp["file_id"]
        iname: str = imp["imported_name"]
        parts = iname.split(".")
        short_name = parts[-1]
        if short_name in ("*", ""):
            continue

        if fid not in file_import_map:
            file_import_map[fid] = {}
        imap = file_import_map[fid]

        if imp["resolved_file_id"]:
            # Already resolved in a previous run — use directly
            imap.setdefault(short_name, []).append(imp["resolved_file_id"])
        elif len(parts) > 1:
            # Derive the file from the module path component(s).
            # "utils.db.open_db" → module = "utils.db" → try utils/db.py etc.
            module = ".".join(parts[:-1])
            slug = module.replace(".", "/")
            candidates = conn.execute(
                """SELECT id FROM files WHERE
                   path = ? OR path LIKE ? OR path LIKE ?
                   OR path = ? OR path LIKE ? OR path LIKE ?""",
                (
                    f"{slug}.py", f"%/{slug}.py", f"{slug}/__init__.py",
                    f"{slug}.ts", f"%/{slug}.ts", f"{slug}/index.ts",
                ),
            ).fetchall()
            for r in candidates:
                imap.setdefault(short_name, []).append(r["id"])
        # Also register alias if present
        if imp["alias"]:
            src = imap.get(short_name, [])
            if src:
                imap.setdefault(imp["alias"], []).extend(src)

    # ── Resolve each call ──────────────────────────────────────────────────────
    updates: list[tuple[int, int]] = []  # (callee_id, call_id)

    for call_row in unresolved:
        callee: str = call_row["callee_name"]
        caller_fid: int = call_row["caller_file_id"]
        callee_id: int | None = None

        # Strategy 1 — import-aware
        imap = file_import_map.get(caller_fid, {})
        if callee in imap:
            for target_fid in imap[callee]:
                hits = [sid for fid, sid in all_symbols.get(callee, [])
                        if fid == target_fid]
                if hits:
                    callee_id = hits[0]
                    break

        # Strategy 2 — same-file
        if callee_id is None:
            same = [sid for fid, sid in all_symbols.get(callee, [])
                    if fid == caller_fid]
            if same:
                callee_id = same[0]

        # Strategy 3 — unique global
        if callee_id is None:
            candidates = all_symbols.get(callee, [])
            if len(candidates) == 1:
                callee_id = candidates[0][1]

        if callee_id is not None:
            updates.append((callee_id, call_row["id"]))

    if updates:
        conn.executemany("UPDATE calls SET callee_id=? WHERE id=?", updates)

    return len(updates)


# ─── Stale detection ──────────────────────────────────────────────────────────

def find_stale_files(conn, root: str, config: Config) -> list[str]:
    """Return relative paths of files that have changed since last index."""
    disk_files = scan_files(root, config)
    stale = []
    for rel_path, (sha, _, _) in disk_files.items():
        stored_sha = get_file_sha256(conn, rel_path)
        if stored_sha != sha:
            stale.append(rel_path)
    return stale


# ─── Main index runner ────────────────────────────────────────────────────────

def run_index(db_path: str, project_root: str, config: Config,
              full_reindex: bool = False) -> IndexResult:
    """
    Full or incremental index run.
    - Scans all files in project_root
    - Skips files whose SHA256 hasn't changed (unless full_reindex=True)
    - Parses changed files, stores results in SQLite
    - Resolves call cross-references
    - Cleans up deleted files
    """
    t0 = time.monotonic()
    result = IndexResult()
    conn = open_db(db_path)

    disk_files = scan_files(project_root, config)
    result.files_scanned = len(disk_files)

    # Detect deleted files (in DB but not on disk)
    db_files = {r["path"]: r for r in list_all_files(conn)}
    for db_path_rel in db_files:
        if db_path_rel not in disk_files:
            with transaction(conn):
                delete_file(conn, db_path_rel)
            result.files_deleted += 1

    # Process each file on disk
    for rel_path, (sha, size, language) in disk_files.items():
        stored_sha = get_file_sha256(conn, rel_path)
        if not full_reindex and stored_sha == sha:
            continue  # Unchanged — skip entirely

        result.files_changed += 1
        full_path = os.path.join(project_root, rel_path.replace("/", os.sep))

        try:
            with open(full_path, "r", encoding="utf-8", errors="replace") as f:
                content = f.read()
        except OSError as e:
            result.files_errored += 1
            result.errors.append({"path": rel_path, "error": str(e)})
            continue

        # Parse
        parser = get_parser_for_language(language or "generic")
        parse_result = parser.parse(full_path, content)

        with transaction(conn):
            # Upsert file record
            file_id = upsert_file(
                conn, rel_path, sha, size, language,
                parse_result.line_count, parse_result.parse_error,
            )

            # Wipe old symbols/imports/calls for this file
            if stored_sha is not None:
                before = conn.execute("SELECT COUNT(*) FROM symbols WHERE file_id=?", (file_id,)).fetchone()[0]
                delete_symbols_for_file(conn, file_id)
                result.symbols_removed += before

            # Store new data
            syms, _ = _store_parse_result(conn, file_id, rel_path, parse_result)
            result.symbols_added += syms

        if parse_result.parse_error:
            result.files_errored += 1
            result.errors.append({"path": rel_path, "error": parse_result.parse_error})
        else:
            result.files_reparsed += 1

    # Resolve cross-file calls
    resolved = resolve_calls(conn)
    log.debug("Resolved %d cross-file calls", resolved)

    # Rebuild FTS5 content tables (required for content= virtual tables)
    with transaction(conn):
        conn.execute("INSERT INTO symbols_fts(symbols_fts) VALUES('rebuild')")
        conn.execute("INSERT INTO decisions_fts(decisions_fts) VALUES('rebuild')")

    # Update metadata
    import datetime
    now = datetime.datetime.utcnow().isoformat() + "Z"
    with transaction(conn):
        set_meta(conn, "last_indexed", now)
        set_meta(conn, "project_root", project_root)
        if get_meta(conn, "project_name") is None:
            set_meta(conn, "project_name", os.path.basename(project_root))

    result.duration_ms = (time.monotonic() - t0) * 1000
    return result
