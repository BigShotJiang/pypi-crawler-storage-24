"""
Export and import the full codebase context (index + decisions + notes) as
a portable JSON snapshot. This is the "agent switch" / "token transfer" mechanism.
"""

from __future__ import annotations
import gzip
import json
import os
import datetime
from .db import open_db, row_to_dict


def export_context(db_path: str, output_path: str | None = None,
                   include_index: bool = True, include_decisions: bool = True,
                   include_notes: bool = True, compress: bool = False) -> dict:
    """
    Dump the database to a portable JSON file.

    Returns metadata about the export (path, size, counts).
    """
    conn = open_db(db_path)

    payload: dict = {
        "schema_version": "1",
        "exported_at": datetime.datetime.utcnow().isoformat() + "Z",
        "project": {},
        "meta": {},
    }

    # Meta
    meta_rows = conn.execute("SELECT * FROM meta").fetchall()
    payload["meta"] = {r["key"]: r["value"] for r in meta_rows}
    payload["project"] = {
        "name": payload["meta"].get("project_name", ""),
        "root": payload["meta"].get("project_root", ""),
    }

    counts: dict[str, int] = {}

    if include_index:
        files = conn.execute("SELECT * FROM files ORDER BY path").fetchall()
        payload["files"] = [dict(r) for r in files]
        counts["files"] = len(files)

        symbols = conn.execute("SELECT * FROM symbols ORDER BY file_id, line_start").fetchall()
        payload["symbols"] = [dict(r) for r in symbols]
        counts["symbols"] = len(symbols)

        imports = conn.execute("SELECT * FROM imports ORDER BY file_id, line_number").fetchall()
        payload["imports"] = [dict(r) for r in imports]
        counts["imports"] = len(imports)

        calls = conn.execute("SELECT * FROM calls ORDER BY caller_file_id").fetchall()
        payload["calls"] = [dict(r) for r in calls]
        counts["calls"] = len(calls)

    if include_decisions:
        decisions = conn.execute("SELECT * FROM decisions ORDER BY created_at").fetchall()
        payload["decisions"] = [dict(r) for r in decisions]
        counts["decisions"] = len(decisions)

    if include_notes:
        notes = conn.execute("SELECT * FROM notes ORDER BY created_at").fetchall()
        payload["notes"] = [dict(r) for r in notes]
        counts["notes"] = len(notes)

    sessions = conn.execute("SELECT * FROM sessions ORDER BY started_at").fetchall()
    payload["sessions"] = [dict(r) for r in sessions]

    payload["counts"] = counts

    # Determine output path
    if not output_path:
        exports_dir = os.path.join(os.path.dirname(db_path), "exports")
        os.makedirs(exports_dir, exist_ok=True)
        ts = datetime.datetime.utcnow().strftime("%Y-%m-%dT%H-%M-%S")
        ext = ".json.gz" if compress else ".json"
        output_path = os.path.join(exports_dir, f"export-{ts}{ext}")

    json_bytes = json.dumps(payload, indent=2, default=str).encode("utf-8")

    if compress:
        with gzip.open(output_path, "wb") as f:
            f.write(json_bytes)
    else:
        with open(output_path, "wb") as f:
            f.write(json_bytes)

    return {
        "status": "exported",
        "path": output_path,
        "size_bytes": os.path.getsize(output_path),
        **{f"{k}_exported": v for k, v in counts.items()},
    }


def import_context(db_path: str, import_path: str,
                   merge_decisions: bool = True,
                   reimport_index: bool = False) -> dict:
    """
    Import a previously exported context snapshot.

    - Always imports decisions and notes (knowledge layer).
    - Optionally imports the structural index (files/symbols/etc.) if reimport_index=True.
    - merge_decisions=True: keeps existing decisions and adds new ones.
      merge_decisions=False: replaces all decisions.
    """
    # Load the export file
    if import_path.endswith(".gz"):
        with gzip.open(import_path, "rb") as f:
            payload = json.loads(f.read())
    else:
        with open(import_path, "r", encoding="utf-8") as f:
            payload = json.load(f)

    conn = open_db(db_path)
    imported: dict[str, int] = {}

    # Import decisions
    if "decisions" in payload:
        if not merge_decisions:
            conn.execute("DELETE FROM decisions")
            conn.commit()

        existing_titles = {
            r[0] for r in conn.execute("SELECT title FROM decisions").fetchall()
        }
        added = 0
        for d in payload["decisions"]:
            if merge_decisions and d.get("title") in existing_titles:
                continue
            conn.execute(
                """INSERT OR IGNORE INTO decisions
                   (id, created_at, updated_at, session_id, title, category, body,
                    related_files, related_symbols, status)
                   VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
                (d.get("id"), d.get("created_at"), d.get("updated_at"),
                 d.get("session_id"), d["title"], d.get("category", "general"),
                 d["body"], d.get("related_files"), d.get("related_symbols"),
                 d.get("status", "active")),
            )
            added += 1
        conn.commit()
        imported["decisions"] = added

    # Import notes
    if "notes" in payload:
        added = 0
        for n in payload["notes"]:
            conn.execute(
                """INSERT OR IGNORE INTO notes
                   (id, created_at, session_id, scope, scope_ref, body, tags)
                   VALUES (?, ?, ?, ?, ?, ?, ?)""",
                (n.get("id"), n.get("created_at"), n.get("session_id"),
                 n.get("scope", "project"), n.get("scope_ref"), n["body"], n.get("tags")),
            )
            added += 1
        conn.commit()
        imported["notes"] = added

    # Optionally import the structural index
    if reimport_index and "files" in payload:
        # Wipe existing index data (preserves decisions/notes)
        conn.execute("DELETE FROM calls")
        conn.execute("DELETE FROM imports")
        conn.execute("DELETE FROM symbols")
        conn.execute("DELETE FROM files")
        conn.commit()

        for file_row in payload.get("files", []):
            conn.execute(
                """INSERT OR IGNORE INTO files
                   (id, path, sha256, size_bytes, language, last_indexed, lines, parse_error)
                   VALUES (?, ?, ?, ?, ?, ?, ?, ?)""",
                (file_row.get("id"), file_row["path"], file_row["sha256"],
                 file_row.get("size_bytes", 0), file_row.get("language"),
                 file_row.get("last_indexed", ""), file_row.get("lines", 0),
                 file_row.get("parse_error")),
            )
        imported["files"] = len(payload["files"])

        for sym in payload.get("symbols", []):
            conn.execute(
                """INSERT OR IGNORE INTO symbols
                   (id, file_id, kind, name, qualified_name, signature, docstring,
                    line_start, line_end, col_start, col_end, parent_id, parent_name,
                    is_exported, is_async, return_type)
                   VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
                (sym.get("id"), sym["file_id"], sym["kind"], sym["name"], sym["qualified_name"],
                 sym.get("signature", ""), sym.get("docstring"), sym["line_start"], sym["line_end"],
                 sym.get("col_start", 0), sym.get("col_end", 0), sym.get("parent_id"),
                 sym.get("parent_name"), sym.get("is_exported", 1), sym.get("is_async", 0),
                 sym.get("return_type")),
            )
        imported["symbols"] = len(payload.get("symbols", []))

        for imp in payload.get("imports", []):
            conn.execute(
                """INSERT OR IGNORE INTO imports
                   (id, file_id, imported_name, alias, resolved_file_id, line_number, import_kind)
                   VALUES (?, ?, ?, ?, ?, ?, ?)""",
                (imp.get("id"), imp["file_id"], imp["imported_name"], imp.get("alias"),
                 imp.get("resolved_file_id"), imp.get("line_number", 0), imp.get("import_kind", "module")),
            )

        for call in payload.get("calls", []):
            conn.execute(
                """INSERT OR IGNORE INTO calls
                   (id, caller_file_id, caller_id, callee_name, callee_id, line_number, call_kind)
                   VALUES (?, ?, ?, ?, ?, ?, ?)""",
                (call.get("id"), call["caller_file_id"], call.get("caller_id"), call["callee_name"],
                 call.get("callee_id"), call.get("line_number", 0), call.get("call_kind", "direct")),
            )

        conn.commit()

    return {
        "status": "imported",
        "source": import_path,
        "imported": imported,
    }


def export_db_copy(db_path: str, output_path: str | None = None) -> dict:
    """
    Copy the raw SQLite database file to a portable location using VACUUM INTO.
    The resulting .db file can be shared directly and used without JSON conversion.
    """
    if not output_path:
        exports_dir = os.path.join(os.path.dirname(db_path), "exports")
        os.makedirs(exports_dir, exist_ok=True)
        ts = datetime.datetime.utcnow().strftime("%Y-%m-%dT%H-%M-%S")
        output_path = os.path.join(exports_dir, f"codebase-{ts}.db")

    conn = open_db(db_path)
    conn.execute(f"VACUUM INTO '{output_path}'")

    return {
        "status": "exported",
        "path": output_path,
        "size_bytes": os.path.getsize(output_path),
    }
