"""Codebase MCP — persistent, portable codebase intelligence server."""

__version__ = "0.1.0"
