"""Configuration dataclass with sensible defaults."""

from __future__ import annotations
from dataclasses import dataclass, field
import os

DB_DIR_NAME = ".codebase-mcp"
DB_FILENAME = "index.db"

# Map file extensions to tree-sitter language names
EXTENSION_TO_LANGUAGE: dict[str, str] = {
    # Python
    ".py":    "python",
    ".pyi":   "python",
    # JavaScript / TypeScript
    ".js":    "javascript",
    ".jsx":   "javascript",
    ".mjs":   "javascript",
    ".cjs":   "javascript",
    ".ts":    "typescript",
    ".tsx":   "typescript",
    ".mts":   "typescript",
    ".cts":   "typescript",
    # Systems languages
    ".go":    "go",
    ".rs":    "rust",
    ".c":     "c",
    ".h":     "c",
    ".cpp":   "cpp",
    ".cc":    "cpp",
    ".cxx":   "cpp",
    ".hpp":   "cpp",
    ".hxx":   "cpp",
    # JVM
    ".java":  "java",
    ".kt":    "kotlin",
    ".kts":   "kotlin",
    ".scala": "scala",
    ".groovy": "groovy",
    # .NET
    ".cs":    "c_sharp",
    # Scripting
    ".rb":    "ruby",
    ".php":   "php",
    ".php3":  "php",
    ".php4":  "php",
    ".php5":  "php",
    ".phtml": "php",
    ".lua":   "lua",
    ".sh":    "bash",
    ".bash":  "bash",
    ".zsh":   "bash",
    ".fish":  "fish",
    # Mobile / Apple
    ".swift": "swift",
    ".m":     "objc",
    ".mm":    "objc",
    # Functional
    ".ex":    "elixir",
    ".exs":   "elixir",
    ".erl":   "erlang",
    ".hrl":   "erlang",
    ".hs":    "haskell",
    ".lhs":   "haskell",
    ".ml":    "ocaml",
    ".mli":   "ocaml",
    ".elm":   "elm",
    ".clj":   "clojure",
    ".cljs":  "clojure",
    ".cljc":  "clojure",
    # Data science / scripting
    ".r":     "r",
    ".R":     "r",
    # Web / markup
    ".vue":   "vue",
    ".svelte": "svelte",
    ".css":   "css",
    ".scss":  "scss",
    ".sass":  "scss",
    ".less":  "css",
    ".html":  "html",
    ".htm":   "html",
    # Config / data
    ".json":  "json",
    ".json5": "json",
    ".jsonc": "json",
    ".toml":  "toml",
    ".yaml":  "yaml",
    ".yml":   "yaml",
    ".env":   "env",
    # Infrastructure / DevOps
    ".tf":    "hcl",
    ".tfvars": "hcl",
    ".hcl":   "hcl",
    ".proto":  "proto",
    ".graphql": "graphql",
    ".gql":   "graphql",
    # Database
    ".sql":   "sql",
    ".psql":  "sql",
    # Docs
    ".md":    "markdown",
    ".mdx":   "markdown",
    ".rst":   "markdown",  # basic heading extraction
    # Nix
    ".nix":   "nix",
    # Dart / Flutter
    ".dart":  "dart",
    # Zig
    ".zig":   "zig",
    # Julia
    ".jl":    "julia",
    # Perl
    ".pl":    "perl",
    ".pm":    "perl",
    # Crystal
    ".cr":    "crystal",
    # D
    ".d":     "d",
    # V
    ".v":     "v",
}

# Map extensionless basenames to language names
BASENAME_TO_LANGUAGE: dict[str, str] = {
    "Makefile":     "makefile",
    "makefile":     "makefile",
    "GNUmakefile":  "makefile",
    "Dockerfile":   "dockerfile",
    "dockerfile":   "dockerfile",
    "Containerfile": "dockerfile",
    "Jenkinsfile":  "groovy",
    "Vagrantfile":  "ruby",
    "Rakefile":     "ruby",
    "Gemfile":      "ruby",
    "Guardfile":    "ruby",
    "Podfile":      "ruby",
    "Fastfile":     "ruby",
    "Brewfile":     "ruby",
    ".env":         "env",
    ".env.local":   "env",
    ".env.example": "env",
    ".env.test":    "env",
    ".env.production": "env",
    ".envrc":       "bash",
}

# Languages with full parser support (rich symbol extraction)
FULLY_SUPPORTED = {"python", "javascript", "typescript", "go", "rust"}

DEFAULT_EXCLUDE_PATTERNS = [
    "**/node_modules/**",
    "**/.venv/**",
    "**/venv/**",
    "**/__pycache__/**",
    "**/.git/**",
    "**/dist/**",
    "**/build/**",
    "**/.next/**",
    "**/target/**",
    "**/.cargo/**",
    "**/vendor/**",
    "**/*.min.js",
    "**/*.min.css",
    "**/.codebase-mcp/**",
    "**/coverage/**",
    "**/.pytest_cache/**",
    "**/*.egg-info/**",
]

MAX_FILE_SIZE_BYTES = 1_000_000  # 1 MB — skip huge generated files


@dataclass
class Config:
    project_root: str = ""
    db_dir_name: str = DB_DIR_NAME
    db_filename: str = DB_FILENAME
    exclude_patterns: list[str] = field(default_factory=lambda: list(DEFAULT_EXCLUDE_PATTERNS))
    max_file_size_bytes: int = MAX_FILE_SIZE_BYTES
    extension_map: dict[str, str] = field(default_factory=lambda: dict(EXTENSION_TO_LANGUAGE))
    basename_map: dict[str, str] = field(default_factory=lambda: dict(BASENAME_TO_LANGUAGE))

    @property
    def db_dir(self) -> str:
        root = self.project_root or os.getcwd()
        return os.path.join(root, self.db_dir_name)

    @property
    def db_path(self) -> str:
        return os.path.join(self.db_dir, self.db_filename)

    def language_for(self, ext: str) -> str | None:
        return self.extension_map.get(ext.lower())

    def language_for_basename(self, basename: str) -> str | None:
        """Return language for extensionless files like Makefile, Dockerfile."""
        return self.basename_map.get(basename) or self.basename_map.get(os.path.basename(basename))


# Global singleton — set once on server startup by index_project or session_bootstrap
_config: Config = Config()


def get_config() -> Config:
    return _config


def set_config(cfg: Config) -> None:
    global _config
    _config = cfg
