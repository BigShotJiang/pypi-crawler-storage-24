"""Shared data models / dataclasses used across modules."""

from __future__ import annotations
from dataclasses import dataclass, field


@dataclass
class ParsedSymbol:
    kind: str           # function | class | method | interface | struct | enum | trait | type_alias | constant
    name: str
    line_start: int
    line_end: int
    col_start: int = 0
    col_end: int = 0
    signature: str = ""
    docstring: str | None = None
    parent_name: str | None = None   # class name for methods
    is_exported: bool = True
    is_async: bool = False
    return_type: str | None = None


@dataclass
class ParsedImport:
    imported_name: str
    alias: str | None = None
    line_number: int = 0
    import_kind: str = "module"      # module | from | namespace | type


@dataclass
class ParsedCall:
    callee_name: str
    caller_name: str | None = None   # enclosing function/method name
    line_number: int = 0
    call_kind: str = "direct"        # direct | method | async | decorator


@dataclass
class ParseResult:
    language: str
    symbols: list[ParsedSymbol] = field(default_factory=list)
    imports: list[ParsedImport] = field(default_factory=list)
    calls: list[ParsedCall] = field(default_factory=list)
    parse_error: str | None = None
    line_count: int = 0
