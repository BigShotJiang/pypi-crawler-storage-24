"""Go parser using tree-sitter."""

from __future__ import annotations
import logging
from ..models import ParseResult, ParsedSymbol, ParsedImport, ParsedCall
from .base import BaseParser, register, _load_language, _ts_captures, _make_query
from .generic import GenericParser

log = logging.getLogger(__name__)

_LANG = None
_PARSER = None


def _get_lang():
    global _LANG, _PARSER
    if _LANG is None:
        _LANG, _PARSER = _load_language("go")
    return _LANG, _PARSER


_FUNC_Q = """
(function_declaration
  (identifier) @name) @func

(method_declaration
  (field_identifier) @name) @method
"""

_TYPE_Q = """
(type_declaration
  (type_spec
    (type_identifier) @name
    (struct_type) @struct_body)) @struct_decl

(type_declaration
  (type_spec
    (type_identifier) @name
    (interface_type) @iface_body)) @iface_decl
"""

_IMPORT_Q = """
(import_declaration
  (import_spec
    path: (interpreted_string_literal) @path)) @imp

(import_declaration
  (import_spec_list
    (import_spec
      path: (interpreted_string_literal) @path))) @imp_list
"""

_CALL_Q = """
(call_expression
  function: [(identifier) @callee
             (selector_expression field: (field_identifier) @callee)]) @call
"""


@register("go")
class GoParser(BaseParser):
    language_name = "go"

    def parse(self, path: str, content: str) -> ParseResult:
        lang, parser = _get_lang()
        if lang is None:
            r = GenericParser().parse(path, content)
            r.language = "go"
            return r

        try:
            cb = content.encode("utf-8")
            tree = parser.parse(cb)
            return self._extract(content, cb, tree.root_node, lang)
        except Exception as e:
            log.warning("Go parse error in %s: %s", path, e)
            r = GenericParser().parse(path, content)
            r.language = "go"
            r.parse_error = str(e)
            return r

    def _extract(self, content: str, cb: bytes, root, lang) -> ParseResult:
        result = ParseResult(language="go", line_count=content.count("\n") + 1)

        # ── Structs and interfaces ─────────────────────────────────────────
        struct_ranges: list[tuple[int, int, str]] = []
        try:
            type_query = _make_query(lang, _TYPE_Q)
            type_caps = _ts_captures(type_query, root)

            def _extract_type_name(node) -> str:
                for c in node.children:
                    if c.type == "type_spec":
                        for cc in c.children:
                            if cc.type == "type_identifier":
                                return cb[cc.start_byte:cc.end_byte].decode()
                return ""

            for node in type_caps.get("struct_decl", []):
                name = _extract_type_name(node)
                if name:
                    struct_ranges.append((node.start_byte, node.end_byte, name))
                    result.symbols.append(ParsedSymbol(
                        kind="struct",
                        name=name,
                        line_start=node.start_point[0] + 1,
                        line_end=node.end_point[0] + 1,
                        signature=self._first_line(node, cb),
                        is_exported=name[0].isupper() if name else False,
                    ))

            for node in type_caps.get("iface_decl", []):
                name = _extract_type_name(node)
                if name:
                    result.symbols.append(ParsedSymbol(
                        kind="interface",
                        name=name,
                        line_start=node.start_point[0] + 1,
                        line_end=node.end_point[0] + 1,
                        signature=self._first_line(node, cb),
                        is_exported=name[0].isupper() if name else False,
                    ))
        except Exception:
            pass

        # ── Functions and methods ──────────────────────────────────────────
        func_byte_ranges: list[tuple[int, int, str]] = []  # for caller tracking
        try:
            func_query = _make_query(lang, _FUNC_Q)
            func_caps = _ts_captures(func_query, root)

            for func_node in func_caps.get("func", []):
                name = ""
                for c in func_node.children:
                    if c.type == "identifier":
                        name = cb[c.start_byte:c.end_byte].decode()
                        break
                if name:
                    func_byte_ranges.append((func_node.start_byte, func_node.end_byte, name))
                    result.symbols.append(ParsedSymbol(
                        kind="function",
                        name=name,
                        line_start=func_node.start_point[0] + 1,
                        line_end=func_node.end_point[0] + 1,
                        signature=self._first_line(func_node, cb),
                        is_exported=name[0].isupper() if name else False,
                    ))

            for method_node in func_caps.get("method", []):
                name = ""
                receiver_type = ""
                receiver_extracted = False  # Only use the FIRST parameter_list (the receiver)
                for c in method_node.children:
                    if c.type == "field_identifier":
                        name = cb[c.start_byte:c.end_byte].decode()
                    elif c.type == "parameter_list" and not receiver_extracted:
                        receiver_extracted = True
                        # Extract receiver type from first parameter_list only
                        for cc in c.children:
                            if cc.type == "parameter_declaration":
                                for ccc in cc.children:
                                    if ccc.type == "pointer_type":
                                        # *TypeName — get the inner type_identifier
                                        for inner in ccc.children:
                                            if inner.type == "type_identifier":
                                                receiver_type = cb[inner.start_byte:inner.end_byte].decode()
                                                break
                                        if not receiver_type:
                                            receiver_type = cb[ccc.start_byte:ccc.end_byte].decode().lstrip("*")
                                    elif ccc.type == "type_identifier":
                                        receiver_type = cb[ccc.start_byte:ccc.end_byte].decode()
                                break  # Only need the first parameter_declaration
                if name:
                    func_byte_ranges.append((method_node.start_byte, method_node.end_byte, name))
                    result.symbols.append(ParsedSymbol(
                        kind="method",
                        name=name,
                        line_start=method_node.start_point[0] + 1,
                        line_end=method_node.end_point[0] + 1,
                        signature=self._first_line(method_node, cb),
                        parent_name=receiver_type or None,
                        is_exported=name[0].isupper() if name else False,
                    ))
        except Exception:
            pass

        # ── Imports ────────────────────────────────────────────────────────
        try:
            imp_query = _make_query(lang, _IMPORT_Q)
            imp_caps = _ts_captures(imp_query, root)
            seen = set()
            for path_node in imp_caps.get("path", []):
                src = cb[path_node.start_byte:path_node.end_byte].decode().strip("\"")
                if src not in seen:
                    seen.add(src)
                    result.imports.append(ParsedImport(
                        imported_name=src,
                        line_number=path_node.start_point[0] + 1,
                        import_kind="module",
                    ))
        except Exception:
            pass

        # ── Calls ──────────────────────────────────────────────────────────
        try:
            call_query = _make_query(lang, _CALL_Q)
            call_caps = _ts_captures(call_query, root)
            _SKIP = frozenset({"make", "new", "len", "cap", "append", "copy", "delete",
                                "panic", "recover", "close", "print", "println"})
            for callee_node in call_caps.get("callee", []):
                callee = cb[callee_node.start_byte:callee_node.end_byte].decode()
                if callee not in _SKIP:
                    caller = self._smallest_enclosing(callee_node.start_byte, func_byte_ranges)
                    result.calls.append(ParsedCall(
                        callee_name=callee,
                        caller_name=caller,
                        line_number=callee_node.start_point[0] + 1,
                    ))
        except Exception:
            pass

        return result
