"""Rust parser using tree-sitter."""

from __future__ import annotations
import logging
from ..models import ParseResult, ParsedSymbol, ParsedImport, ParsedCall
from .base import BaseParser, register, _load_language, _ts_captures, _make_query
from .generic import GenericParser

log = logging.getLogger(__name__)

_LANG = None
_PARSER = None


def _get_lang():
    global _LANG, _PARSER
    if _LANG is None:
        _LANG, _PARSER = _load_language("rust")
    return _LANG, _PARSER


_ITEM_Q = """
(function_item
  name: (identifier) @name) @func

(struct_item
  name: (type_identifier) @name) @struct_decl

(enum_item
  name: (type_identifier) @name) @enum_decl

(trait_item
  name: (type_identifier) @name) @trait_decl

(type_item
  name: (type_identifier) @name) @type_alias
"""

_IMPL_Q = """
(impl_item
  type: (type_identifier) @type_name
  body: (declaration_list)) @impl_block
"""

_USE_Q = """
(use_declaration
  argument: (_) @path) @use_decl
"""

_CALL_Q = """
(call_expression
  function: [(identifier) @callee
             (field_expression field: (field_identifier) @callee)
             (scoped_identifier name: (identifier) @callee)]) @call
"""


@register("rust")
class RustParser(BaseParser):
    language_name = "rust"

    def parse(self, path: str, content: str) -> ParseResult:
        lang, parser = _get_lang()
        if lang is None:
            r = GenericParser().parse(path, content)
            r.language = "rust"
            return r

        try:
            cb = content.encode("utf-8")
            tree = parser.parse(cb)
            return self._extract(content, cb, tree.root_node, lang)
        except Exception as e:
            log.warning("Rust parse error in %s: %s", path, e)
            r = GenericParser().parse(path, content)
            r.language = "rust"
            r.parse_error = str(e)
            return r

    def _is_pub(self, node, cb: bytes) -> bool:
        return any(c.type == "visibility_modifier" for c in node.children)

    def _is_async(self, node, cb: bytes) -> bool:
        for c in node.children:
            if c.type == "function_modifiers":
                text = cb[c.start_byte:c.end_byte].decode()
                return "async" in text
        return False

    def _extract(self, content: str, cb: bytes, root, lang) -> ParseResult:
        result = ParseResult(language="rust", line_count=content.count("\n") + 1)

        # ── Top-level items ────────────────────────────────────────────────
        func_byte_ranges: list[tuple[int, int, str]] = []  # for caller tracking
        try:
            item_query = _make_query(lang, _ITEM_Q)
            item_caps = _ts_captures(item_query, root)

            for func_node in item_caps.get("func", []):
                name = ""
                for c in func_node.children:
                    if c.type == "identifier":
                        name = cb[c.start_byte:c.end_byte].decode()
                        break
                if name:
                    func_byte_ranges.append((func_node.start_byte, func_node.end_byte, name))
                    result.symbols.append(ParsedSymbol(
                        kind="function",
                        name=name,
                        line_start=func_node.start_point[0] + 1,
                        line_end=func_node.end_point[0] + 1,
                        signature=self._first_line(func_node, cb),
                        is_exported=self._is_pub(func_node, cb),
                        is_async=self._is_async(func_node, cb),
                    ))

            for kind_key, kind_name in [("struct_decl", "struct"), ("enum_decl", "enum"),
                                         ("trait_decl", "trait"), ("type_alias", "type_alias")]:
                for node in item_caps.get(kind_key, []):
                    name = ""
                    for c in node.children:
                        if c.type == "type_identifier":
                            name = cb[c.start_byte:c.end_byte].decode()
                            break
                    if name:
                        result.symbols.append(ParsedSymbol(
                            kind=kind_name,
                            name=name,
                            line_start=node.start_point[0] + 1,
                            line_end=node.end_point[0] + 1,
                            signature=self._first_line(node, cb),
                            is_exported=self._is_pub(node, cb),
                        ))
        except Exception:
            pass

        # ── Impl blocks → methods ──────────────────────────────────────────
        try:
            impl_query = _make_query(lang, _IMPL_Q)
            impl_caps = _ts_captures(impl_query, root)
            for impl_node in impl_caps.get("impl_block", []):
                type_name = ""
                for c in impl_node.children:
                    if c.type == "type_identifier":
                        type_name = cb[c.start_byte:c.end_byte].decode()
                        break
                # Find function_items inside the declaration_list
                body = next((c for c in impl_node.children if c.type == "declaration_list"), None)
                if body:
                    for child in body.children:
                        if child.type == "function_item":
                            name = ""
                            for c in child.children:
                                if c.type == "identifier":
                                    name = cb[c.start_byte:c.end_byte].decode()
                                    break
                            if name:
                                func_byte_ranges.append((child.start_byte, child.end_byte, name))
                                result.symbols.append(ParsedSymbol(
                                    kind="method",
                                    name=name,
                                    line_start=child.start_point[0] + 1,
                                    line_end=child.end_point[0] + 1,
                                    signature=self._first_line(child, cb),
                                    parent_name=type_name or None,
                                    is_exported=self._is_pub(child, cb),
                                    is_async=self._is_async(child, cb),
                                ))
        except Exception:
            pass

        # ── Use declarations ───────────────────────────────────────────────
        try:
            use_query = _make_query(lang, _USE_Q)
            use_caps = _ts_captures(use_query, root)
            for use_node in use_caps.get("use_decl", []):
                text = cb[use_node.start_byte:use_node.end_byte].decode()
                text = text.replace("use ", "").rstrip(";")
                result.imports.append(ParsedImport(
                    imported_name=text,
                    line_number=use_node.start_point[0] + 1,
                    import_kind="namespace",
                ))
        except Exception:
            pass

        # ── Calls ──────────────────────────────────────────────────────────
        try:
            call_query = _make_query(lang, _CALL_Q)
            call_caps = _ts_captures(call_query, root)
            _SKIP = frozenset({"vec", "format", "println", "print", "panic", "assert",
                                "assert_eq", "unwrap", "expect", "clone", "to_string", "from"})
            for callee_node in call_caps.get("callee", []):
                callee = cb[callee_node.start_byte:callee_node.end_byte].decode()
                if callee not in _SKIP:
                    caller = self._smallest_enclosing(callee_node.start_byte, func_byte_ranges)
                    result.calls.append(ParsedCall(
                        callee_name=callee,
                        caller_name=caller,
                        line_number=callee_node.start_point[0] + 1,
                    ))
        except Exception:
            pass

        return result
