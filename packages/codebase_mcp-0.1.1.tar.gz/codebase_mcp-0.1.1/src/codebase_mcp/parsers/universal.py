"""
Universal profile-driven parser for all languages tree-sitter-language-pack supports.

Each language is described by a LangProfile that tells the walker:
  - which AST node types map to which symbol kinds
  - which child node types carry the symbol name
  - which node types represent imports
  - whether to detect exported/async modifiers

The same recursive walker handles all of them. Dedicated parsers (Python, TS, Go, Rust)
are preferred when available; this module picks up every remaining language.
"""

from __future__ import annotations
import logging
from dataclasses import dataclass, field
from typing import Callable

from ..models import ParseResult, ParsedSymbol, ParsedImport, ParsedCall
from .base import BaseParser, register, _load_language, _ts_captures, _make_query
from .generic import GenericParser

log = logging.getLogger(__name__)


# ─── Language Profile ─────────────────────────────────────────────────────────

@dataclass
class LangProfile:
    ts_lang_name: str                             # key for _load_language()
    # [(ts_node_type, symbol_kind), ...]
    symbol_types: list[tuple[str, str]]
    # AST child types that carry the symbol name (tried in order)
    name_child_types: list[str]
    # Node types for import/use/require statements
    import_node_types: list[str] = field(default_factory=list)
    # Node types that make a symbol "exported" (e.g. visibility modifier)
    exported_modifier_texts: list[str] = field(default_factory=list)
    # Node types whose text signals async (empty = all are sync)
    async_texts: list[str] = field(default_factory=list)
    # For languages where function names are nested (C, C++) set True
    deep_name_extraction: bool = False
    # Special-case: Elixir uses macro `call` nodes for def/defp
    elixir_style: bool = False


# ─── Language profiles ────────────────────────────────────────────────────────

_PROFILES: dict[str, LangProfile] = {

    "java": LangProfile(
        ts_lang_name="java",
        symbol_types=[
            ("method_declaration",            "method"),
            ("constructor_declaration",       "function"),
            ("class_declaration",             "class"),
            ("interface_declaration",         "interface"),
            ("enum_declaration",              "enum"),
            ("annotation_type_declaration",   "interface"),
            ("record_declaration",            "class"),
        ],
        name_child_types=["identifier", "type_identifier"],
        import_node_types=["import_declaration"],
        exported_modifier_texts=["public"],
    ),

    "c_sharp": LangProfile(
        ts_lang_name="c_sharp",
        symbol_types=[
            ("method_declaration",       "method"),
            ("constructor_declaration",  "function"),
            ("class_declaration",        "class"),
            ("interface_declaration",    "interface"),
            ("enum_declaration",         "enum"),
            ("struct_declaration",       "struct"),
            ("record_declaration",       "class"),
            ("property_declaration",     "function"),
            ("delegate_declaration",     "type_alias"),
            ("operator_declaration",     "function"),
        ],
        name_child_types=["identifier", "type_identifier"],
        import_node_types=["using_directive"],
        exported_modifier_texts=["public"],
        async_texts=["async"],
    ),

    "ruby": LangProfile(
        ts_lang_name="ruby",
        symbol_types=[
            ("method",          "function"),
            ("singleton_method","function"),
            ("class",           "class"),
            ("module",          "interface"),
        ],
        name_child_types=["identifier", "constant"],
        import_node_types=["call"],          # require / require_relative
    ),

    "php": LangProfile(
        ts_lang_name="php",
        symbol_types=[
            ("function_definition",   "function"),
            ("method_declaration",    "method"),
            ("class_declaration",     "class"),
            ("interface_declaration", "interface"),
            ("trait_declaration",     "trait"),
            ("enum_declaration",      "enum"),
            ("arrow_function",        "function"),
        ],
        name_child_types=["name", "identifier"],
        import_node_types=["namespace_use_declaration", "use_declaration"],
        exported_modifier_texts=["public"],
        async_texts=["async"],
    ),

    "swift": LangProfile(
        ts_lang_name="swift",
        symbol_types=[
            ("function_declaration",  "function"),
            ("init_declaration",      "function"),
            ("subscript_declaration", "function"),
            ("class_declaration",     "class"),
            ("struct_declaration",    "struct"),
            ("enum_declaration",      "enum"),
            ("protocol_declaration",  "interface"),
            ("extension_declaration", "class"),
            ("typealias_declaration", "type_alias"),
        ],
        name_child_types=["simple_identifier", "type_identifier", "identifier"],
        import_node_types=["import_declaration"],
        async_texts=["async"],
    ),

    "kotlin": LangProfile(
        ts_lang_name="kotlin",
        symbol_types=[
            ("function_declaration",   "function"),
            ("class_declaration",      "class"),
            ("interface_declaration",  "interface"),
            ("object_declaration",     "class"),
            ("companion_object",       "class"),
            ("secondary_constructor",  "function"),
        ],
        name_child_types=["simple_identifier", "identifier", "type_identifier"],
        import_node_types=["import_header"],
        async_texts=["suspend"],
    ),

    "scala": LangProfile(
        ts_lang_name="scala",
        symbol_types=[
            ("function_definition",  "function"),
            ("class_definition",     "class"),
            ("object_definition",    "class"),
            ("trait_definition",     "interface"),
            ("case_class_definition","class"),
            ("type_definition",      "type_alias"),
        ],
        name_child_types=["identifier", "type_identifier"],
        import_node_types=["import_declaration"],
    ),

    "c": LangProfile(
        ts_lang_name="c",
        symbol_types=[
            ("function_definition", "function"),
            ("struct_specifier",    "struct"),
            ("enum_specifier",      "enum"),
            ("type_definition",     "type_alias"),
        ],
        name_child_types=["identifier", "type_identifier"],
        import_node_types=["preproc_include"],
        deep_name_extraction=True,
    ),

    "cpp": LangProfile(
        ts_lang_name="cpp",
        symbol_types=[
            ("function_definition",    "function"),
            ("class_specifier",        "class"),
            ("struct_specifier",       "struct"),
            ("enum_specifier",         "enum"),
            ("namespace_definition",   "interface"),
            ("template_declaration",   "function"),  # template functions
        ],
        name_child_types=["identifier", "type_identifier", "qualified_identifier"],
        import_node_types=["preproc_include"],
        deep_name_extraction=True,
    ),

    "lua": LangProfile(
        ts_lang_name="lua",
        symbol_types=[
            ("function_declaration", "function"),
            ("local_function",       "function"),
        ],
        name_child_types=["identifier", "dot_index_expression", "method_index_expression"],
        import_node_types=[],
    ),

    "bash": LangProfile(
        ts_lang_name="bash",
        symbol_types=[
            ("function_definition", "function"),
        ],
        name_child_types=["word"],
        import_node_types=["command"],      # source / .
    ),

    "elixir": LangProfile(
        ts_lang_name="elixir",
        symbol_types=[],               # handled via elixir_style special case
        name_child_types=["identifier", "alias"],
        import_node_types=["call"],
        elixir_style=True,
    ),

    "haskell": LangProfile(
        ts_lang_name="haskell",
        symbol_types=[
            ("function",           "function"),
            ("data_declaration",   "class"),
            ("newtype_declaration","class"),
            ("class_declaration",  "interface"),
            ("type_synonym",       "type_alias"),
        ],
        name_child_types=["variable", "name", "constructor"],
        import_node_types=["import"],
    ),

    "ocaml": LangProfile(
        ts_lang_name="ocaml",
        symbol_types=[
            ("let_binding",         "function"),
            ("type_definition",     "type_alias"),
            ("module_definition",   "class"),
            ("class_definition",    "class"),
        ],
        name_child_types=["value_name", "value_pattern", "type_constructor_path",
                          "module_name", "identifier"],
        import_node_types=["open_module"],
    ),

    "r": LangProfile(
        ts_lang_name="r",
        symbol_types=[
            ("left_assignment",  "function"),  # foo <- function(...)
            ("right_assignment", "function"),  # function(...) -> foo
        ],
        name_child_types=["identifier"],
        import_node_types=[],
    ),

    "elixir_erlang": LangProfile(   # erlang-style
        ts_lang_name="erlang",
        symbol_types=[
            ("function",           "function"),
            ("module_attribute",   "interface"),
        ],
        name_child_types=["atom", "identifier"],
        import_node_types=["attribute"],
    ),

    "vue": LangProfile(
        ts_lang_name="vue",
        symbol_types=[],  # handled via child lang (JS/TS inside <script>)
        name_child_types=["identifier"],
        import_node_types=[],
    ),

    "css": LangProfile(
        ts_lang_name="css",
        symbol_types=[
            ("rule_set",          "function"),  # .selector {}
            ("keyframes_statement","class"),
            ("at_rule",           "interface"),
        ],
        name_child_types=["class_selector", "id_selector", "tag_name", "keyframes_name"],
        import_node_types=["import_statement"],
    ),

    "scss": LangProfile(
        ts_lang_name="scss",
        symbol_types=[
            ("rule_set",          "function"),
            ("mixin_statement",   "function"),
            ("include_statement", "function"),
            ("function_statement","function"),
        ],
        name_child_types=["class_selector", "id_selector", "tag_name", "name"],
        import_node_types=["import_statement"],
    ),
}

# Additional aliases (alternate ts_lang_name strings)
_ALIASES: dict[str, str] = {
    "erlang": "elixir_erlang",
}


# ─── Name extraction helpers ──────────────────────────────────────────────────

def _first_name_child(node, cb: bytes, name_types: list[str]) -> str:
    """Return text of the first direct child whose type is in name_types."""
    for child in node.children:
        if child.type in name_types:
            return cb[child.start_byte:child.end_byte].decode("utf-8", "replace").strip()
    return ""


def _extract_c_function_name(declarator_node, cb: bytes, depth: int = 0) -> str:
    """
    Recursively descend a C/C++ declarator chain to find the innermost identifier.
    Handles: identifier, pointer_declarator, reference_declarator, function_declarator,
             qualified_identifier, operator_name, destructor_name.
    """
    if depth > 6 or declarator_node is None:
        return ""
    t = declarator_node.type

    if t == "identifier":
        return cb[declarator_node.start_byte:declarator_node.end_byte].decode("utf-8", "replace")

    if t == "qualified_identifier":
        # Take the last part: Foo::bar → "bar"
        for c in reversed(declarator_node.children):
            if c.type in ("identifier", "destructor_name", "operator_name"):
                return cb[c.start_byte:c.end_byte].decode("utf-8", "replace")

    if t in ("operator_name", "destructor_name", "conversion_function_id"):
        return cb[declarator_node.start_byte:declarator_node.end_byte].decode("utf-8", "replace")

    # Recurse into sub-declarators
    for child in declarator_node.children:
        if "declarator" in child.type or child.type in (
            "identifier", "qualified_identifier", "operator_name",
            "destructor_name", "function_declarator",
        ):
            result = _extract_c_function_name(child, cb, depth + 1)
            if result:
                return result
    return ""


def _extract_import_text(node, cb: bytes, profile: LangProfile) -> str | None:
    """Extract the import path/name from an import node."""
    # Ruby: call to require("foo") / require_relative("foo")
    if profile.ts_lang_name == "ruby":
        if node.type != "call":
            return None
        # Check method name
        method = ""
        for c in node.children:
            if c.type == "identifier":
                method = cb[c.start_byte:c.end_byte].decode("utf-8", "replace")
                break
        if method not in ("require", "require_relative", "require_dependency", "autoload"):
            return None
        # Find the string argument
        for c in node.children:
            if c.type in ("argument_list", "argument"):
                for cc in c.children:
                    if cc.type in ("string", "string_value", "simple_symbol"):
                        text = cb[cc.start_byte:cc.end_byte].decode("utf-8", "replace")
                        return text.strip("\"':")

    # C/C++: #include "foo.h" or #include <foo.h>
    if profile.ts_lang_name in ("c", "cpp"):
        for c in node.children:
            if c.type in ("string_literal", "system_lib_string"):
                return cb[c.start_byte:c.end_byte].decode("utf-8", "replace").strip("<>\"")

    # Bash: source / .
    if profile.ts_lang_name == "bash":
        if node.type != "command":
            return None
        children_text = [cb[c.start_byte:c.end_byte].decode("utf-8", "replace").strip()
                         for c in node.children]
        if children_text and children_text[0] in ("source", "."):
            return children_text[1] if len(children_text) > 1 else None
        return None

    # Generic: return full text of the node (for using_directive, import_declaration, etc.)
    return cb[node.start_byte:node.end_byte].decode("utf-8", "replace").strip()


def _check_exported(node, cb: bytes, modifier_texts: list[str]) -> bool:
    """Check if a node has an exported visibility modifier."""
    if not modifier_texts:
        return True  # Language has no export concept → all symbols "exported"
    for c in node.children:
        text = cb[c.start_byte:c.end_byte].decode("utf-8", "replace").strip()
        if text in modifier_texts:
            return True
    return False


def _check_async(node, cb: bytes, async_texts: list[str]) -> bool:
    if not async_texts:
        return False
    for c in node.children:
        text = cb[c.start_byte:c.end_byte].decode("utf-8", "replace").strip()
        if text in async_texts:
            return True
    return False


def _is_inside_class(node, class_ranges: list[tuple[int, int, str]]) -> str | None:
    for (start, end, name) in class_ranges:
        if start < node.start_byte < end:
            return name
    return None


# ─── Elixir special-case extraction ──────────────────────────────────────────

_ELIXIR_DEF_KEYWORDS = {"def", "defp", "defmacro", "defmacrop", "defmodule",
                        "defprotocol", "defimpl", "defstruct"}


def _extract_elixir_symbols(root, cb: bytes) -> list[ParsedSymbol]:
    symbols = []

    def _walk(node, class_name=None):
        # Elixir: def/defp/defmodule are represented as `call` nodes
        if node.type == "call":
            children = list(node.children)
            if children and children[0].type == "identifier":
                kw = cb[children[0].start_byte:children[0].end_byte].decode("utf-8", "replace")
                if kw in _ELIXIR_DEF_KEYWORDS:
                    func_name = ""
                    # Arguments list: second child
                    if len(children) > 1:
                        args = children[1]
                        for c in args.children:
                            if c.type in ("call", "identifier"):
                                if c.type == "identifier":
                                    func_name = cb[c.start_byte:c.end_byte].decode("utf-8", "replace")
                                elif c.type == "call":
                                    # def foo(args), call node for the function header
                                    for cc in c.children:
                                        if cc.type == "identifier":
                                            func_name = cb[cc.start_byte:cc.end_byte].decode("utf-8", "replace")
                                            break
                                break
                    if func_name:
                        kind = "class" if kw in ("defmodule", "defprotocol") else "function"
                        new_class = func_name if kind == "class" else class_name
                        symbols.append(ParsedSymbol(
                            kind=kind,
                            name=func_name,
                            line_start=node.start_point[0] + 1,
                            line_end=node.end_point[0] + 1,
                            signature=cb[node.start_byte:node.start_byte + min(100, node.end_byte - node.start_byte)].decode("utf-8", "replace").split("\n")[0].strip(),
                            parent_name=class_name if kind == "function" else None,
                            is_exported=(kw in ("def", "defmodule", "defprotocol", "defimpl")),
                        ))
                        for child in node.children:
                            _walk(child, new_class)
                        return

        for child in node.children:
            _walk(child, class_name)

    _walk(root)
    return symbols


# ─── Universal Parser ─────────────────────────────────────────────────────────

class UniversalParser(BaseParser):
    """Profile-driven parser registered for all languages in _PROFILES."""

    def __init__(self, profile: LangProfile):
        self.profile = profile

    def parse(self, path: str, content: str) -> ParseResult:
        p = self.profile
        lang, ts_parser = _load_language(p.ts_lang_name)

        if lang is None:
            log.debug("tree-sitter %s not available, using generic fallback", p.ts_lang_name)
            r = GenericParser().parse(path, content)
            r.language = p.ts_lang_name
            return r

        try:
            cb = content.encode("utf-8")
            tree = ts_parser.parse(cb)
            root = tree.root_node
            result = ParseResult(language=p.ts_lang_name, line_count=content.count("\n") + 1)

            if p.elixir_style:
                result.symbols = _extract_elixir_symbols(root, cb)
                return result

            self._walk(root, cb, result, p, class_ranges=[])
            return result

        except Exception as e:
            log.warning("Parse error (%s) in %s: %s", p.ts_lang_name, path, e)
            r = GenericParser().parse(path, content)
            r.language = p.ts_lang_name
            r.parse_error = str(e)
            return r

    def _walk(self, node, cb: bytes, result: ParseResult,
              profile: LangProfile,
              class_ranges: list[tuple[int, int, str]]) -> None:

        sym_map = dict(profile.symbol_types)  # {node_type: kind}
        import_types = set(profile.import_node_types)

        # ── Symbol node? ────────────────────────────────────────────────────
        if node.type in sym_map:
            kind = sym_map[node.type]
            name = self._extract_name(node, cb, profile)

            if name:
                is_class = kind in ("class", "interface", "struct", "enum", "trait")
                if is_class:
                    class_ranges.append((node.start_byte, node.end_byte, name))

                parent_class = _is_inside_class(node, class_ranges)
                if parent_class and not is_class:
                    kind = "method"

                result.symbols.append(ParsedSymbol(
                    kind=kind,
                    name=name,
                    line_start=node.start_point[0] + 1,
                    line_end=node.end_point[0] + 1,
                    col_start=node.start_point[1],
                    col_end=node.end_point[1],
                    signature=cb[node.start_byte:node.start_byte + min(200, node.end_byte - node.start_byte)].decode("utf-8", "replace").split("\n")[0].strip(),
                    parent_name=parent_class if not is_class else None,
                    is_exported=_check_exported(node, cb, profile.exported_modifier_texts),
                    is_async=_check_async(node, cb, profile.async_texts),
                ))

        # ── Import node? ─────────────────────────────────────────────────────
        if node.type in import_types:
            text = _extract_import_text(node, cb, profile)
            if text:
                result.imports.append(ParsedImport(
                    imported_name=text.split("\n")[0][:200].strip(),
                    line_number=node.start_point[0] + 1,
                ))

        # ── Recurse ──────────────────────────────────────────────────────────
        for child in node.children:
            self._walk(child, cb, result, profile, class_ranges)

    def _extract_name(self, node, cb: bytes, profile: LangProfile) -> str:
        # C/C++: names are buried in declarator chains
        if profile.deep_name_extraction:
            for child in node.children:
                if "declarator" in child.type:
                    name = _extract_c_function_name(child, cb)
                    if name:
                        return name
            # Fallback to normal extraction for structs/enums
        return _first_name_child(node, cb, profile.name_child_types)


# ─── R special case: func name is from the LHS of assignment ─────────────────

class RParser(UniversalParser):
    def _extract_name(self, node, cb: bytes, profile: LangProfile) -> str:
        # R: foo <- function(...) — name is the LHS identifier
        if node.type in ("left_assignment", "right_assignment"):
            lhs = node.children[0] if node.children else None
            rhs = node.children[-1] if node.children else None
            # Check that RHS contains a function_definition
            has_func = rhs and (rhs.type == "function_definition" or
                                 any(c.type == "function_definition" for c in rhs.children))
            if has_func and lhs and lhs.type == "identifier":
                return cb[lhs.start_byte:lhs.end_byte].decode("utf-8", "replace")
        return ""


# ─── CSS: selector extraction ─────────────────────────────────────────────────

class CSSParser(UniversalParser):
    def _extract_name(self, node, cb: bytes, profile: LangProfile) -> str:
        if node.type == "rule_set":
            # Get the first selector
            for c in node.children:
                if c.type == "selectors":
                    sel = cb[c.start_byte:c.end_byte].decode("utf-8", "replace").strip()
                    return sel[:80]  # First 80 chars of selector
            return ""
        return _first_name_child(node, cb, profile.name_child_types)


# ─── Registration ─────────────────────────────────────────────────────────────

def _register_all():
    from .base import _registry
    for lang_name, profile in _PROFILES.items():
        if lang_name in _registry:
            continue  # Already registered by a dedicated parser

        if lang_name == "r":
            parser_cls = type(f"Parser_{lang_name}", (RParser,),
                              {"language_name": lang_name,
                               "__init__": lambda self, p=profile: RParser.__init__(self, p)})
        elif lang_name in ("css", "scss"):
            parser_cls = type(f"Parser_{lang_name}", (CSSParser,),
                              {"language_name": lang_name,
                               "__init__": lambda self, p=profile: CSSParser.__init__(self, p)})
        else:
            parser_cls = type(f"Parser_{lang_name}", (UniversalParser,),
                              {"language_name": lang_name,
                               "__init__": lambda self, p=profile: UniversalParser.__init__(self, p)})

        _registry[lang_name] = parser_cls

    # Register aliases
    for alias, target in _ALIASES.items():
        if alias not in _registry and target in _registry:
            _registry[alias] = _registry[target]


_register_all()
