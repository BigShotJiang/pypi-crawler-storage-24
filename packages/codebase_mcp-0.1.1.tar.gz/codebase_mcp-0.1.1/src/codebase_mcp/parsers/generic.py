"""
Generic regex-based fallback parser.
Used for languages without a tree-sitter grammar, or when tree-sitter is unavailable.
Extracts function/class-like patterns with simple regex — better than nothing.
"""

from __future__ import annotations
import re
from ..models import ParseResult, ParsedSymbol, ParsedImport
from .base import BaseParser, register


# Patterns that work across most C-style and Python-style languages
_FUNC_PATTERNS = [
    # Python
    re.compile(r"^\s*(?:async\s+)?def\s+(\w+)\s*\(", re.M),
    # JS/TS
    re.compile(r"^\s*(?:async\s+)?function\s+(\w+)\s*\(", re.M),
    re.compile(r"^\s*(?:export\s+)?(?:async\s+)?(?:function\s+)?(\w+)\s*=\s*(?:async\s*)?\(", re.M),
    # Go
    re.compile(r"^func\s+(?:\(\w+\s+\*?\w+\)\s+)?(\w+)\s*\(", re.M),
    # Rust
    re.compile(r"^\s*(?:pub\s+)?(?:async\s+)?fn\s+(\w+)\s*[(<]", re.M),
    # Java/C#
    re.compile(r"^\s*(?:public|private|protected|static|async)[\s\w]*\s+(\w+)\s*\(", re.M),
]

_CLASS_PATTERNS = [
    re.compile(r"^\s*class\s+(\w+)", re.M),
    re.compile(r"^\s*(?:pub\s+)?struct\s+(\w+)", re.M),
    re.compile(r"^\s*(?:pub\s+)?enum\s+(\w+)", re.M),
    re.compile(r"^\s*(?:pub\s+)?trait\s+(\w+)", re.M),
    re.compile(r"^\s*interface\s+(\w+)", re.M),
]

_IMPORT_PATTERNS = [
    re.compile(r"^(?:import|from)\s+([\w.]+)", re.M),
    re.compile(r'^import\s+"([\w./]+)"', re.M),
    re.compile(r'^use\s+([\w:]+)', re.M),
    re.compile(r'^require\s*\(\s*["\']([^"\']+)', re.M),
    re.compile(r'^import\s+.*\s+from\s+["\']([^"\']+)', re.M),
]


class GenericParser(BaseParser):
    language_name = "generic"

    def parse(self, path: str, content: str) -> ParseResult:
        result = ParseResult(language="generic")
        lines = content.splitlines()
        result.line_count = len(lines)

        seen_names: set[str] = set()

        for pat in _FUNC_PATTERNS:
            for m in pat.finditer(content):
                name = m.group(1)
                if name and name not in seen_names and not name.startswith("_"):
                    seen_names.add(name)
                    line_no = content[:m.start()].count("\n") + 1
                    result.symbols.append(ParsedSymbol(
                        kind="function",
                        name=name,
                        line_start=line_no,
                        line_end=line_no,
                        signature=lines[line_no - 1].strip() if line_no <= len(lines) else "",
                    ))

        for pat in _CLASS_PATTERNS:
            for m in pat.finditer(content):
                name = m.group(1)
                if name and name not in seen_names:
                    seen_names.add(name)
                    line_no = content[:m.start()].count("\n") + 1
                    result.symbols.append(ParsedSymbol(
                        kind="class",
                        name=name,
                        line_start=line_no,
                        line_end=line_no,
                        signature=lines[line_no - 1].strip() if line_no <= len(lines) else "",
                    ))

        seen_imports: set[str] = set()
        for pat in _IMPORT_PATTERNS:
            for m in pat.finditer(content):
                name = m.group(1)
                if name and name not in seen_imports:
                    seen_imports.add(name)
                    line_no = content[:m.start()].count("\n") + 1
                    result.imports.append(ParsedImport(
                        imported_name=name,
                        line_number=line_no,
                    ))

        return result
