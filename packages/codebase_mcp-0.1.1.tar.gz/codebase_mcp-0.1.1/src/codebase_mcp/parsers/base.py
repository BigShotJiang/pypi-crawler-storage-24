"""Base parser class and parser registry."""

from __future__ import annotations
import logging
from abc import ABC, abstractmethod
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from ..models import ParseResult

log = logging.getLogger(__name__)

# ─── Tree-sitter compatibility layer ─────────────────────────────────────────

def _ts_captures(query, node) -> dict[str, list]:
    """
    Execute a tree-sitter query and return captures as {capture_name: [Node, ...]}.
    Handles tree-sitter API differences across versions:
    - 0.25+: Query() + QueryCursor.captures(node) → dict
    - 0.23-0.24: lang.query() + query.captures(node) → dict
    - <0.23:  lang.query() + query.captures(node) → list[tuple]
    """
    # tree-sitter 0.25+: QueryCursor is the execution interface
    try:
        from tree_sitter import QueryCursor
        cursor = QueryCursor(query)
        result = cursor.captures(node)
        if isinstance(result, dict):
            return result
        # Shouldn't happen, but handle just in case
        normalised: dict[str, list] = {}
        for n, name in result:
            normalised.setdefault(name, []).append(n)
        return normalised
    except ImportError:
        pass

    # tree-sitter <0.25: query has captures() directly
    result = query.captures(node)
    if isinstance(result, dict):
        return result
    normalised = {}
    for n, name in result:
        normalised.setdefault(name, []).append(n)
    return normalised


def _make_query(lang, pattern: str):
    """
    Create a query object compatible with the installed tree-sitter version.
    - 0.25+: tree_sitter.Query(lang, pattern)
    - <0.25: lang.query(pattern)  (deprecated in 0.25)
    """
    try:
        from tree_sitter import Query
        return Query(lang, pattern)
    except (ImportError, TypeError):
        pass
    # Fallback for older tree-sitter
    return lang.query(pattern)


def _load_language(lang_name: str):
    """
    Return a (language, parser) tuple for the given language name.
    Tries tree-sitter-language-pack first, then individual packages.
    Returns (None, None) if unavailable.
    """
    # 1. Try tree-sitter-language-pack (bundled, preferred)
    try:
        from tree_sitter_language_pack import get_language, get_parser  # type: ignore
        lang = get_language(lang_name)
        parser = get_parser(lang_name)
        return lang, parser
    except (ImportError, Exception):
        pass

    # 2. Try individual tree-sitter-* packages
    _individual = {
        "python":     ("tree_sitter_python",     "language"),
        "javascript": ("tree_sitter_javascript",  "language"),
        "typescript": ("tree_sitter_typescript",  "language_typescript"),
        "go":         ("tree_sitter_go",          "language"),
        "rust":       ("tree_sitter_rust",        "language"),
        "java":       ("tree_sitter_java",        "language"),
        "c":          ("tree_sitter_c",           "language"),
        "cpp":        ("tree_sitter_cpp",         "language"),
    }
    if lang_name in _individual:
        mod_name, fn_name = _individual[lang_name]
        try:
            import importlib
            from tree_sitter import Language, Parser
            mod = importlib.import_module(mod_name)
            lang_fn = getattr(mod, fn_name)
            lang = Language(lang_fn())
            parser = Parser(lang)
            return lang, parser
        except (ImportError, Exception):
            pass

    return None, None


# ─── Base class ───────────────────────────────────────────────────────────────

class BaseParser(ABC):
    language_name: str = ""

    @abstractmethod
    def parse(self, path: str, content: str) -> "ParseResult":
        """Parse source content and return extracted symbols, imports, calls."""
        ...

    def _node_text(self, node, content_bytes: bytes) -> str:
        return content_bytes[node.start_byte:node.end_byte].decode("utf-8", errors="replace")

    def _first_line(self, node, content_bytes: bytes) -> str:
        """Return just the first line of a node (useful for signatures)."""
        text = self._node_text(node, content_bytes)
        return text.split("\n")[0].strip()

    def _smallest_enclosing(self, byte_pos: int,
                             ranges: list[tuple[int, int, str]]) -> str | None:
        """
        Return the name of the smallest (byte, byte, name) range that contains
        byte_pos.  Used by every parser to find the enclosing function/method
        for a call-site, so we can set ParsedCall.caller_name.
        """
        best_name: str | None = None
        best_size: int | None = None
        for start, end, name in ranges:
            if start <= byte_pos <= end:
                size = end - start
                if best_size is None or size < best_size:
                    best_name = name
                    best_size = size
        return best_name


# ─── Registry ─────────────────────────────────────────────────────────────────

_registry: dict[str, type[BaseParser]] = {}


def register(language: str):
    def decorator(cls: type[BaseParser]):
        cls.language_name = language
        _registry[language] = cls
        return cls
    return decorator


def get_parser_for_language(language: str) -> BaseParser:
    from .generic import GenericParser
    cls = _registry.get(language, GenericParser)
    return cls()
