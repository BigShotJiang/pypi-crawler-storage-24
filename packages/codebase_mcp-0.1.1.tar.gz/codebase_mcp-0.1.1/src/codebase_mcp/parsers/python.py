"""Python parser using tree-sitter."""

from __future__ import annotations
import logging
from ..models import ParseResult, ParsedSymbol, ParsedImport, ParsedCall
from .base import BaseParser, register, _load_language, _ts_captures, _make_query
from .generic import GenericParser

log = logging.getLogger(__name__)

_LANG = None
_PARSER = None


def _get_lang():
    global _LANG, _PARSER
    if _LANG is None:
        _LANG, _PARSER = _load_language("python")
    return _LANG, _PARSER


# ─── Queries ──────────────────────────────────────────────────────────────────

_FUNC_Q = """
(function_definition
  name: (identifier) @name) @func
"""

_CLASS_Q = """
(class_definition
  name: (identifier) @name) @cls
"""

_IMPORT_Q = """
(import_statement) @imp
(import_from_statement) @from_imp
"""

_CALL_Q = """
(call
  function: (identifier) @callee) @call

(call
  function: (attribute
    attribute: (identifier) @callee)) @method_call
"""


@register("python")
class PythonParser(BaseParser):
    language_name = "python"

    def parse(self, path: str, content: str) -> ParseResult:
        lang, parser = _get_lang()
        if lang is None:
            log.debug("tree-sitter Python not available, falling back to generic parser")
            r = GenericParser().parse(path, content)
            r.language = "python"
            return r

        try:
            content_bytes = content.encode("utf-8")
            tree = parser.parse(content_bytes)
            return self._extract(content, content_bytes, tree.root_node, lang)
        except Exception as e:
            log.warning("Python parse error in %s: %s", path, e)
            result = GenericParser().parse(path, content)
            result.language = "python"
            result.parse_error = str(e)
            return result

    def _extract(self, content: str, cb: bytes, root, lang) -> ParseResult:
        result = ParseResult(language="python", line_count=content.count("\n") + 1)

        # ── Collect class ranges for method detection ──────────────────────
        class_ranges: list[tuple[int, int, str]] = []  # (start_byte, end_byte, class_name)
        cls_query = _make_query(lang, _CLASS_Q)
        cls_caps = _ts_captures(cls_query, root)
        for cls_node in cls_caps.get("cls", []):
            name_nodes = [n for n in cls_node.children if n.type == "identifier"]
            name = cb[name_nodes[0].start_byte:name_nodes[0].end_byte].decode() if name_nodes else ""
            if name:
                class_ranges.append((cls_node.start_byte, cls_node.end_byte, name))
                result.symbols.append(ParsedSymbol(
                    kind="class",
                    name=name,
                    line_start=cls_node.start_point[0] + 1,
                    line_end=cls_node.end_point[0] + 1,
                    col_start=cls_node.start_point[1],
                    col_end=cls_node.end_point[1],
                    signature=self._first_line(cls_node, cb),
                    is_exported=not name.startswith("_"),
                ))

        # ── Functions and methods ──────────────────────────────────────────
        func_query = _make_query(lang, _FUNC_Q)
        func_caps = _ts_captures(func_query, root)
        func_byte_ranges: list[tuple[int, int, str]] = []  # (start, end, name) for caller tracking
        for func_node in func_caps.get("func", []):
            name_nodes = func_caps.get("name", [])
            # Find the name node that is a direct child of this func_node
            name = ""
            for nn in func_node.children:
                if nn.type == "identifier":
                    name = cb[nn.start_byte:nn.end_byte].decode()
                    break
            if not name:
                continue

            # Detect async
            is_async = any(c.type == "async" for c in func_node.children)

            # Return type
            return_type = None
            for c in func_node.children:
                if c.type == "type":
                    return_type = cb[c.start_byte:c.end_byte].decode().strip()

            # Signature = first line
            sig = self._first_line(func_node, cb)

            # Docstring = first string in body
            docstring = None
            body = next((c for c in func_node.children if c.type == "block"), None)
            if body and body.child_count > 0:
                first = body.children[0]
                # tree-sitter may wrap in expression_statement or expose string directly
                if first.type in ("string", "concatenated_string"):
                    maybe_str = first
                elif first.type == "expression_statement" and first.child_count > 0:
                    maybe_str = first.children[0]
                else:
                    maybe_str = None
                if maybe_str and maybe_str.type in ("string", "concatenated_string"):
                    raw = cb[maybe_str.start_byte:maybe_str.end_byte].decode()
                    # Extract content from string_content child if available
                    content_node = next(
                        (c for c in maybe_str.children if c.type == "string_content"), None
                    )
                    if content_node:
                        docstring = cb[content_node.start_byte:content_node.end_byte].decode().split("\n")[0][:200]
                    else:
                        docstring = raw.strip('"\' \t\n').split("\n")[0][:200]

            # Method or function?
            parent_class = None
            for (cs, ce, cn) in class_ranges:
                if cs < func_node.start_byte < ce:
                    parent_class = cn
                    break

            kind = "method" if parent_class else "function"
            func_byte_ranges.append((func_node.start_byte, func_node.end_byte, name))
            result.symbols.append(ParsedSymbol(
                kind=kind,
                name=name,
                line_start=func_node.start_point[0] + 1,
                line_end=func_node.end_point[0] + 1,
                col_start=func_node.start_point[1],
                col_end=func_node.end_point[1],
                signature=sig,
                docstring=docstring,
                parent_name=parent_class,
                is_exported=not name.startswith("_"),
                is_async=is_async,
                return_type=return_type,
            ))

        # ── Imports ────────────────────────────────────────────────────────
        imp_query = _make_query(lang, _IMPORT_Q)
        imp_caps = _ts_captures(imp_query, root)

        for node in imp_caps.get("imp", []):
            # import X, Y  — all dotted_name children are top-level module names
            for c in node.children:
                if c.type in ("dotted_name", "aliased_import"):
                    name = cb[c.start_byte:c.end_byte].decode().split(" as ")[0].strip()
                    result.imports.append(ParsedImport(
                        imported_name=name,
                        line_number=node.start_point[0] + 1,
                        import_kind="module",
                    ))

        for node in imp_caps.get("from_imp", []):
            # from X import Y, Z  — first dotted_name = module, rest = names
            dotted_names = [c for c in node.children if c.type in ("dotted_name", "aliased_import")]
            has_wildcard = any(c.type == "wildcard_import" for c in node.children)

            if not dotted_names and not has_wildcard:
                continue

            module = cb[dotted_names[0].start_byte:dotted_names[0].end_byte].decode() if dotted_names else ""

            if has_wildcard:
                result.imports.append(ParsedImport(
                    imported_name=f"{module}.*",
                    line_number=node.start_point[0] + 1,
                    import_kind="from",
                ))
            else:
                for dn in dotted_names[1:]:
                    name = cb[dn.start_byte:dn.end_byte].decode().split(" as ")[0].strip()
                    result.imports.append(ParsedImport(
                        imported_name=f"{module}.{name}" if module else name,
                        line_number=node.start_point[0] + 1,
                        import_kind="from",
                    ))

        # ── Call sites ─────────────────────────────────────────────────────
        call_query = _make_query(lang, _CALL_Q)
        call_caps = _ts_captures(call_query, root)
        _BUILTINS = frozenset({
            "print", "len", "range", "type", "isinstance", "hasattr",
            "getattr", "setattr", "str", "int", "float", "list", "dict",
            "tuple", "set", "bool", "bytes", "enumerate", "zip", "map",
            "filter", "sorted", "reversed", "sum", "min", "max", "abs",
            "open", "super", "vars", "dir", "repr", "format", "id",
        })
        for callee_node in call_caps.get("callee", []):
            callee = cb[callee_node.start_byte:callee_node.end_byte].decode()
            if callee in _BUILTINS:
                continue  # Skip builtins for noise reduction
            caller = self._smallest_enclosing(callee_node.start_byte, func_byte_ranges)
            result.calls.append(ParsedCall(
                callee_name=callee,
                caller_name=caller,
                line_number=callee_node.start_point[0] + 1,
                call_kind="direct",
            ))

        return result
