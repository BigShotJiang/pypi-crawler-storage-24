"""TypeScript/JavaScript parser using tree-sitter."""

from __future__ import annotations
import logging
from ..models import ParseResult, ParsedSymbol, ParsedImport, ParsedCall
from .base import BaseParser, register, _load_language, _ts_captures, _make_query
from .generic import GenericParser

log = logging.getLogger(__name__)

_LANG_TS = None
_PARSER_TS = None
_LANG_JS = None
_PARSER_JS = None


def _get_lang(name: str):
    global _LANG_TS, _PARSER_TS, _LANG_JS, _PARSER_JS
    if name in ("typescript", "tsx"):
        if _LANG_TS is None:
            _LANG_TS, _PARSER_TS = _load_language("typescript")
        return _LANG_TS, _PARSER_TS
    else:
        if _LANG_JS is None:
            _LANG_JS, _PARSER_JS = _load_language("javascript")
        return _LANG_JS, _PARSER_JS


_FUNC_Q = """
(function_declaration) @func
(function_expression) @func
(generator_function_declaration) @func
(method_definition) @method
(arrow_function) @arrow
"""

_CLASS_Q = """
(class_declaration) @cls
(abstract_class_declaration) @cls
"""

_INTERFACE_Q = """
(interface_declaration) @iface
"""

_IMPORT_Q = """
(import_statement
  source: (string) @source) @imp

(call_expression
  function: (identifier) @req_fn
  arguments: (arguments (string) @source)) @require
"""

_CALL_Q = """
(call_expression
  function: [(identifier) @callee
             (member_expression property: (property_identifier) @callee)]) @call
"""


@register("javascript")
@register("typescript")
class TypeScriptParser(BaseParser):
    language_name = "typescript"

    def parse(self, path: str, content: str) -> ParseResult:
        lang_name = "typescript" if path.endswith((".ts", ".tsx")) else "javascript"
        lang, parser = _get_lang(lang_name)
        if lang is None:
            log.debug("tree-sitter %s not available, falling back to generic parser", lang_name)
            r = GenericParser().parse(path, content)
            r.language = lang_name
            return r

        try:
            cb = content.encode("utf-8")
            tree = parser.parse(cb)
            return self._extract(content, cb, tree.root_node, lang, lang_name)
        except Exception as e:
            log.warning("TS/JS parse error in %s: %s", path, e)
            r = GenericParser().parse(path, content)
            r.language = lang_name
            r.parse_error = str(e)
            return r

    def _extract(self, content: str, cb: bytes, root, lang, lang_name: str) -> ParseResult:
        result = ParseResult(language=lang_name, line_count=content.count("\n") + 1)

        # ── Classes ────────────────────────────────────────────────────────
        class_ranges: list[tuple[int, int, str]] = []
        try:
            cls_query = _make_query(lang, _CLASS_Q)
            cls_caps = _ts_captures(cls_query, root)
            for cls_node in cls_caps.get("cls", []):
                name = ""
                for c in cls_node.children:
                    if c.type in ("identifier", "type_identifier"):
                        name = cb[c.start_byte:c.end_byte].decode()
                        break
                if name:
                    class_ranges.append((cls_node.start_byte, cls_node.end_byte, name))
                    result.symbols.append(ParsedSymbol(
                        kind="class",
                        name=name,
                        line_start=cls_node.start_point[0] + 1,
                        line_end=cls_node.end_point[0] + 1,
                        signature=self._first_line(cls_node, cb),
                        is_exported=self._is_exported(cls_node, cb),
                    ))
        except Exception:
            pass

        # ── Interfaces ─────────────────────────────────────────────────────
        try:
            iface_query = _make_query(lang, _INTERFACE_Q)
            iface_caps = _ts_captures(iface_query, root)
            for iface_node in iface_caps.get("iface", []):
                name = ""
                for c in iface_node.children:
                    if c.type == "type_identifier":
                        name = cb[c.start_byte:c.end_byte].decode()
                        break
                if name:
                    result.symbols.append(ParsedSymbol(
                        kind="interface",
                        name=name,
                        line_start=iface_node.start_point[0] + 1,
                        line_end=iface_node.end_point[0] + 1,
                        signature=self._first_line(iface_node, cb),
                        is_exported=self._is_exported(iface_node, cb),
                    ))
        except Exception:
            pass

        # ── Functions and methods ──────────────────────────────────────────
        func_byte_ranges: list[tuple[int, int, str]] = []  # for caller tracking
        try:
            func_query = _make_query(lang, _FUNC_Q)
            func_caps = _ts_captures(func_query, root)

            for func_node in func_caps.get("func", []):
                name = ""
                is_async = any(c.type == "async" for c in func_node.children)
                for c in func_node.children:
                    if c.type in ("identifier", "property_identifier"):
                        name = cb[c.start_byte:c.end_byte].decode()
                        break
                # Arrow functions assigned to a variable — walk up to declarator
                if not name:
                    parent = func_node.parent
                    if parent and parent.type == "variable_declarator":
                        for c in parent.children:
                            if c.type == "identifier":
                                name = cb[c.start_byte:c.end_byte].decode()
                                break
                    elif parent and parent.type == "pair":
                        # { key: () => ... } — object method
                        for c in parent.children:
                            if c.type in ("property_identifier", "string", "identifier"):
                                name = cb[c.start_byte:c.end_byte].decode().strip("\"'")
                                break
                if not name:
                    continue

                parent_class = None
                for cs, ce, cn in class_ranges:
                    if cs < func_node.start_byte < ce:
                        parent_class = cn
                        break

                func_byte_ranges.append((func_node.start_byte, func_node.end_byte, name))
                result.symbols.append(ParsedSymbol(
                    kind="method" if parent_class else "function",
                    name=name,
                    line_start=func_node.start_point[0] + 1,
                    line_end=func_node.end_point[0] + 1,
                    signature=self._first_line(func_node, cb),
                    parent_name=parent_class,
                    is_exported=self._is_exported(func_node, cb),
                    is_async=is_async,
                ))

            # Arrow functions (const foo = () => ...) — captured separately as @arrow
            for arrow_node in func_caps.get("arrow", []):
                name = ""
                is_async = any(c.type == "async" for c in arrow_node.children)
                parent = arrow_node.parent
                if parent and parent.type == "variable_declarator":
                    for c in parent.children:
                        if c.type == "identifier":
                            name = cb[c.start_byte:c.end_byte].decode()
                            break
                elif parent and parent.type == "pair":
                    for c in parent.children:
                        if c.type in ("property_identifier", "string", "identifier"):
                            name = cb[c.start_byte:c.end_byte].decode().strip("\"'")
                            break
                if not name:
                    continue
                func_byte_ranges.append((arrow_node.start_byte, arrow_node.end_byte, name))
                result.symbols.append(ParsedSymbol(
                    kind="function",
                    name=name,
                    line_start=arrow_node.start_point[0] + 1,
                    line_end=arrow_node.end_point[0] + 1,
                    signature=self._first_line(arrow_node, cb),
                    is_exported=self._is_exported(arrow_node, cb),
                    is_async=is_async,
                ))

            for method_node in func_caps.get("method", []):
                name = ""
                is_async = any(c.type == "async" for c in method_node.children)
                for c in method_node.children:
                    if c.type in ("property_identifier", "identifier", "private_property_identifier"):
                        name = cb[c.start_byte:c.end_byte].decode()
                        break
                if not name:
                    continue

                # Walk up AST to find the enclosing class — more reliable than byte ranges
                parent_class = self._enclosing_class_name(method_node, cb)

                func_byte_ranges.append((method_node.start_byte, method_node.end_byte, name))
                result.symbols.append(ParsedSymbol(
                    kind="method",
                    name=name,
                    line_start=method_node.start_point[0] + 1,
                    line_end=method_node.end_point[0] + 1,
                    signature=self._first_line(method_node, cb),
                    parent_name=parent_class,
                    is_async=is_async,
                ))
        except Exception:
            pass

        # ── Imports ────────────────────────────────────────────────────────
        try:
            imp_query = _make_query(lang, _IMPORT_Q)
            imp_caps = _ts_captures(imp_query, root)
            for imp_node in imp_caps.get("imp", []):
                for c in imp_node.children:
                    if c.type == "string":
                        src = cb[c.start_byte:c.end_byte].decode().strip("\"'")
                        result.imports.append(ParsedImport(
                            imported_name=src,
                            line_number=imp_node.start_point[0] + 1,
                            import_kind="module",
                        ))
            for req_node in imp_caps.get("require", []):
                src_nodes = imp_caps.get("source", [])
                for sn in src_nodes:
                    if req_node.start_byte <= sn.start_byte <= req_node.end_byte:
                        src = cb[sn.start_byte:sn.end_byte].decode().strip("\"'")
                        result.imports.append(ParsedImport(
                            imported_name=src,
                            line_number=req_node.start_point[0] + 1,
                            import_kind="module",
                        ))
        except Exception:
            pass

        # ── Calls ──────────────────────────────────────────────────────────
        try:
            call_query = _make_query(lang, _CALL_Q)
            call_caps = _ts_captures(call_query, root)
            _SKIP = frozenset({"console", "require", "import", "exports", "module",
                                "Array", "Object", "String", "Number", "Boolean",
                                "Promise", "Error", "JSON", "Math", "Symbol", "Date"})
            for callee_node in call_caps.get("callee", []):
                callee = cb[callee_node.start_byte:callee_node.end_byte].decode()
                if callee not in _SKIP:
                    caller = self._smallest_enclosing(callee_node.start_byte, func_byte_ranges)
                    result.calls.append(ParsedCall(
                        callee_name=callee,
                        caller_name=caller,
                        line_number=callee_node.start_point[0] + 1,
                    ))
        except Exception:
            pass

        return result

    def _enclosing_class_name(self, node, cb: bytes) -> str | None:
        """Walk up the AST to find the nearest enclosing class/abstract class."""
        parent = node.parent
        while parent:
            if parent.type in ("class_declaration", "class_expression",
                               "abstract_class_declaration"):
                for c in parent.children:
                    if c.type in ("identifier", "type_identifier"):
                        return cb[c.start_byte:c.end_byte].decode()
            parent = parent.parent
        return None

    def _is_exported(self, node, cb: bytes) -> bool:
        parent = node.parent
        while parent:
            if parent.type == "export_statement":
                return True
            parent = parent.parent
        return False
