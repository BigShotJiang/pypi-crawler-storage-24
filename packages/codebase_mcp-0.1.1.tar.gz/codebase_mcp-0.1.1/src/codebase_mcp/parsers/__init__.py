"""
Parser package: tree-sitter based structural extraction for each language.
Falls back to a generic regex parser when tree-sitter grammar is unavailable.

Importing this package triggers parser registration via the @register decorator.
"""

from __future__ import annotations
from .base import BaseParser, get_parser_for_language

# Register all language parsers by importing them
from . import python, typescript, go, rust  # noqa: F401
from . import universal, config_parsers  # noqa: F401  — registers 18+ universal + 11 config parsers

__all__ = ["BaseParser", "get_parser_for_language"]
