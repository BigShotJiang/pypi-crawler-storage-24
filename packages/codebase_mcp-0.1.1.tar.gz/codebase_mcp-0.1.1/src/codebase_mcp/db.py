"""
Database layer: schema, connection management, and all parameterised queries.
Single SQLite file per project at <root>/.codebase-mcp/index.db
"""

from __future__ import annotations
import json
import os
import sqlite3
import time
from contextlib import contextmanager
from typing import Any, Generator

# ─── Schema ──────────────────────────────────────────────────────────────────

SCHEMA_VERSION = "2"

DDL = """
PRAGMA journal_mode = WAL;
PRAGMA synchronous = NORMAL;
PRAGMA foreign_keys = ON;

CREATE TABLE IF NOT EXISTS meta (
    key   TEXT PRIMARY KEY,
    value TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS files (
    id            INTEGER PRIMARY KEY AUTOINCREMENT,
    path          TEXT    NOT NULL UNIQUE,
    sha256        TEXT    NOT NULL,
    size_bytes    INTEGER NOT NULL DEFAULT 0,
    language      TEXT,
    last_indexed  TEXT    NOT NULL,
    lines         INTEGER NOT NULL DEFAULT 0,
    parse_error   TEXT
);

CREATE INDEX IF NOT EXISTS idx_files_sha256   ON files(sha256);
CREATE INDEX IF NOT EXISTS idx_files_language ON files(language);

CREATE TABLE IF NOT EXISTS symbols (
    id             INTEGER PRIMARY KEY AUTOINCREMENT,
    file_id        INTEGER NOT NULL REFERENCES files(id) ON DELETE CASCADE,
    kind           TEXT    NOT NULL,
    name           TEXT    NOT NULL,
    qualified_name TEXT    NOT NULL,
    signature      TEXT    NOT NULL DEFAULT '',
    docstring      TEXT,
    line_start     INTEGER NOT NULL,
    line_end       INTEGER NOT NULL,
    col_start      INTEGER NOT NULL DEFAULT 0,
    col_end        INTEGER NOT NULL DEFAULT 0,
    parent_id      INTEGER REFERENCES symbols(id) ON DELETE CASCADE,
    parent_name    TEXT,
    is_exported    INTEGER NOT NULL DEFAULT 1,
    is_async       INTEGER NOT NULL DEFAULT 0,
    return_type    TEXT
);

CREATE INDEX IF NOT EXISTS idx_symbols_file_id       ON symbols(file_id);
CREATE INDEX IF NOT EXISTS idx_symbols_name          ON symbols(name);
CREATE INDEX IF NOT EXISTS idx_symbols_qualified     ON symbols(qualified_name);
CREATE INDEX IF NOT EXISTS idx_symbols_kind          ON symbols(kind);
CREATE INDEX IF NOT EXISTS idx_symbols_parent        ON symbols(parent_id);

CREATE VIRTUAL TABLE IF NOT EXISTS symbols_fts USING fts5(
    name,
    qualified_name,
    docstring,
    content='symbols',
    content_rowid='id'
);

CREATE TABLE IF NOT EXISTS imports (
    id               INTEGER PRIMARY KEY AUTOINCREMENT,
    file_id          INTEGER NOT NULL REFERENCES files(id) ON DELETE CASCADE,
    imported_name    TEXT    NOT NULL,
    alias            TEXT,
    resolved_file_id INTEGER REFERENCES files(id) ON DELETE SET NULL,
    line_number      INTEGER NOT NULL DEFAULT 0,
    import_kind      TEXT    NOT NULL DEFAULT 'module'
);

CREATE INDEX IF NOT EXISTS idx_imports_file_id ON imports(file_id);
CREATE INDEX IF NOT EXISTS idx_imports_name    ON imports(imported_name);

CREATE TABLE IF NOT EXISTS calls (
    id             INTEGER PRIMARY KEY AUTOINCREMENT,
    caller_file_id INTEGER NOT NULL REFERENCES files(id) ON DELETE CASCADE,
    caller_id      INTEGER REFERENCES symbols(id) ON DELETE CASCADE,
    callee_name    TEXT    NOT NULL,
    callee_id      INTEGER REFERENCES symbols(id) ON DELETE SET NULL,
    line_number    INTEGER NOT NULL DEFAULT 0,
    call_kind      TEXT    NOT NULL DEFAULT 'direct'
);

CREATE INDEX IF NOT EXISTS idx_calls_caller_id   ON calls(caller_id);
CREATE INDEX IF NOT EXISTS idx_calls_callee_id   ON calls(callee_id);
CREATE INDEX IF NOT EXISTS idx_calls_callee_name ON calls(callee_name);

CREATE TABLE IF NOT EXISTS decisions (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    created_at      TEXT    NOT NULL,
    updated_at      TEXT    NOT NULL,
    session_id      TEXT,
    title           TEXT    NOT NULL,
    category        TEXT    NOT NULL DEFAULT 'general',
    body            TEXT    NOT NULL,
    related_files   TEXT,
    related_symbols TEXT,
    status          TEXT    NOT NULL DEFAULT 'active'
);

CREATE INDEX IF NOT EXISTS idx_decisions_category ON decisions(category);
CREATE INDEX IF NOT EXISTS idx_decisions_status   ON decisions(status);
CREATE INDEX IF NOT EXISTS idx_decisions_session  ON decisions(session_id);

CREATE VIRTUAL TABLE IF NOT EXISTS decisions_fts USING fts5(
    title,
    body,
    content='decisions',
    content_rowid='id'
);

CREATE TABLE IF NOT EXISTS notes (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    created_at  TEXT    NOT NULL,
    session_id  TEXT,
    scope       TEXT    NOT NULL DEFAULT 'project',
    scope_ref   TEXT,
    body        TEXT    NOT NULL,
    tags        TEXT
);

CREATE INDEX IF NOT EXISTS idx_notes_scope     ON notes(scope);
CREATE INDEX IF NOT EXISTS idx_notes_scope_ref ON notes(scope_ref);

CREATE TABLE IF NOT EXISTS sessions (
    id            TEXT    PRIMARY KEY,
    agent_hint    TEXT,
    started_at    TEXT    NOT NULL,
    last_active   TEXT    NOT NULL,
    bootstrap_done INTEGER NOT NULL DEFAULT 0
);
"""

# ─── Connection management ────────────────────────────────────────────────────

_connection_cache: dict[str, sqlite3.Connection] = {}


def close_db(db_path: str) -> None:
    """Close and remove the cached connection for db_path."""
    conn = _connection_cache.pop(db_path, None)
    if conn is not None:
        try:
            conn.close()
        except Exception:
            pass


def open_db(db_path: str) -> sqlite3.Connection:
    """Open (and initialise if needed) the SQLite database at db_path."""
    if db_path in _connection_cache:
        return _connection_cache[db_path]

    os.makedirs(os.path.dirname(db_path), exist_ok=True)
    conn = sqlite3.connect(db_path, check_same_thread=False)
    conn.row_factory = sqlite3.Row

    # Apply schema
    conn.executescript(DDL)

    # Set/verify schema version
    existing = conn.execute("SELECT value FROM meta WHERE key='schema_version'").fetchone()
    if existing is None:
        conn.execute("INSERT OR REPLACE INTO meta VALUES ('schema_version', ?)", (SCHEMA_VERSION,))
        conn.commit()

    _connection_cache[db_path] = conn
    return conn


@contextmanager
def transaction(conn: sqlite3.Connection) -> Generator[sqlite3.Connection, None, None]:
    """Context manager for explicit transactions."""
    try:
        yield conn
        conn.commit()
    except Exception:
        conn.rollback()
        raise


# ─── File queries ─────────────────────────────────────────────────────────────

def upsert_file(conn: sqlite3.Connection, path: str, sha256: str,
                size_bytes: int, language: str | None, lines: int,
                parse_error: str | None = None) -> int:
    now = _now()
    cur = conn.execute(
        """INSERT INTO files (path, sha256, size_bytes, language, last_indexed, lines, parse_error)
           VALUES (?, ?, ?, ?, ?, ?, ?)
           ON CONFLICT(path) DO UPDATE SET
               sha256=excluded.sha256, size_bytes=excluded.size_bytes,
               language=excluded.language, last_indexed=excluded.last_indexed,
               lines=excluded.lines, parse_error=excluded.parse_error""",
        (path, sha256, size_bytes, language, now, lines, parse_error),
    )
    conn.execute("SELECT id FROM files WHERE path=?", (path,))
    row = conn.execute("SELECT id FROM files WHERE path=?", (path,)).fetchone()
    return row["id"]


def get_file_by_path(conn: sqlite3.Connection, path: str) -> sqlite3.Row | None:
    return conn.execute("SELECT * FROM files WHERE path=?", (path,)).fetchone()


def get_file_sha256(conn: sqlite3.Connection, path: str) -> str | None:
    row = conn.execute("SELECT sha256 FROM files WHERE path=?", (path,)).fetchone()
    return row["sha256"] if row else None


def delete_file(conn: sqlite3.Connection, path: str) -> None:
    conn.execute("DELETE FROM files WHERE path=?", (path,))


def list_all_files(conn: sqlite3.Connection) -> list[sqlite3.Row]:
    return conn.execute("SELECT * FROM files ORDER BY path").fetchall()


# ─── Symbol queries ───────────────────────────────────────────────────────────

def delete_symbols_for_file(conn: sqlite3.Connection, file_id: int) -> None:
    conn.execute("DELETE FROM symbols WHERE file_id=?", (file_id,))
    conn.execute("DELETE FROM imports WHERE file_id=?", (file_id,))
    conn.execute("DELETE FROM calls WHERE caller_file_id=?", (file_id,))


def insert_symbol(conn: sqlite3.Connection, file_id: int, kind: str, name: str,
                  qualified_name: str, signature: str, docstring: str | None,
                  line_start: int, line_end: int, col_start: int, col_end: int,
                  parent_id: int | None, parent_name: str | None,
                  is_exported: bool, is_async: bool, return_type: str | None) -> int:
    cur = conn.execute(
        """INSERT INTO symbols
           (file_id, kind, name, qualified_name, signature, docstring,
            line_start, line_end, col_start, col_end, parent_id, parent_name,
            is_exported, is_async, return_type)
           VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
        (file_id, kind, name, qualified_name, signature, docstring,
         line_start, line_end, col_start, col_end, parent_id, parent_name,
         1 if is_exported else 0, 1 if is_async else 0, return_type),
    )
    return cur.lastrowid  # type: ignore[return-value]


def insert_import(conn: sqlite3.Connection, file_id: int, imported_name: str,
                  alias: str | None, line_number: int, import_kind: str) -> None:
    conn.execute(
        "INSERT INTO imports (file_id, imported_name, alias, line_number, import_kind) VALUES (?,?,?,?,?)",
        (file_id, imported_name, alias, line_number, import_kind),
    )


def insert_call(conn: sqlite3.Connection, caller_file_id: int,
                caller_id: int | None, callee_name: str,
                line_number: int, call_kind: str) -> int:
    cur = conn.execute(
        """INSERT INTO calls (caller_file_id, caller_id, callee_name, line_number, call_kind)
           VALUES (?, ?, ?, ?, ?)""",
        (caller_file_id, caller_id, callee_name, line_number, call_kind),
    )
    return cur.lastrowid  # type: ignore[return-value]


def search_symbols_fts(conn: sqlite3.Connection, query: str, kind: str = "",
                       language: str = "", limit: int = 20) -> list[sqlite3.Row]:
    """Full-text search + optional kind/language filter."""
    if query:
        sql = """
            SELECT s.*, f.path, f.language
            FROM symbols_fts
            JOIN symbols s ON symbols_fts.rowid = s.id
            JOIN files f ON s.file_id = f.id
            WHERE symbols_fts MATCH ?
        """
        params: list[Any] = [query]
    else:
        sql = """
            SELECT s.*, f.path, f.language
            FROM symbols s
            JOIN files f ON s.file_id = f.id
            WHERE 1=1
        """
        params = []

    if kind:
        sql += " AND s.kind = ?"
        params.append(kind)
    if language:
        sql += " AND f.language = ?"
        params.append(language)

    sql += " LIMIT ?"
    params.append(limit)
    return conn.execute(sql, params).fetchall()


def get_symbol_by_qualified_name(conn: sqlite3.Connection, qname: str) -> sqlite3.Row | None:
    return conn.execute(
        "SELECT s.*, f.path, f.language FROM symbols s JOIN files f ON s.file_id=f.id WHERE s.qualified_name=?",
        (qname,),
    ).fetchone()


def get_symbol_by_id(conn: sqlite3.Connection, sid: int) -> sqlite3.Row | None:
    return conn.execute(
        "SELECT s.*, f.path, f.language FROM symbols s JOIN files f ON s.file_id=f.id WHERE s.id=?",
        (sid,),
    ).fetchone()


def get_file_symbols(conn: sqlite3.Connection, file_id: int) -> list[sqlite3.Row]:
    return conn.execute(
        "SELECT * FROM symbols WHERE file_id=? ORDER BY line_start",
        (file_id,),
    ).fetchall()


def get_callers(conn: sqlite3.Connection, symbol_id: int, limit: int = 50) -> list[sqlite3.Row]:
    return conn.execute(
        """SELECT c.*, s.name AS caller_name, s.qualified_name AS caller_qname,
                  f.path AS caller_file
           FROM calls c
           LEFT JOIN symbols s ON c.caller_id = s.id
           JOIN files f ON c.caller_file_id = f.id
           WHERE c.callee_id = ?
           LIMIT ?""",
        (symbol_id, limit),
    ).fetchall()


def get_callees(conn: sqlite3.Connection, symbol_id: int, limit: int = 50) -> list[sqlite3.Row]:
    return conn.execute(
        """SELECT c.*, s.name AS callee_sym_name, s.qualified_name AS callee_qname,
                  f.path AS callee_file
           FROM calls c
           LEFT JOIN symbols s ON c.callee_id = s.id
           JOIN files f ON c.caller_file_id = f.id
           WHERE c.caller_id = ?
           LIMIT ?""",
        (symbol_id, limit),
    ).fetchall()


def get_unresolved_calls(conn: sqlite3.Connection) -> list[sqlite3.Row]:
    return conn.execute(
        "SELECT id, callee_name, caller_file_id FROM calls WHERE callee_id IS NULL"
    ).fetchall()


def resolve_call(conn: sqlite3.Connection, call_id: int, callee_id: int) -> None:
    conn.execute("UPDATE calls SET callee_id=? WHERE id=?", (callee_id, call_id))


def get_file_imports(conn: sqlite3.Connection, file_id: int) -> list[sqlite3.Row]:
    return conn.execute(
        "SELECT * FROM imports WHERE file_id=? ORDER BY line_number",
        (file_id,),
    ).fetchall()


# ─── Stats ────────────────────────────────────────────────────────────────────

def get_stats(conn: sqlite3.Connection) -> dict:
    files      = conn.execute("SELECT COUNT(*) FROM files").fetchone()[0]
    symbols    = conn.execute("SELECT COUNT(*) FROM symbols").fetchone()[0]
    functions  = conn.execute("SELECT COUNT(*) FROM symbols WHERE kind IN ('function','method')").fetchone()[0]
    classes    = conn.execute("SELECT COUNT(*) FROM symbols WHERE kind='class'").fetchone()[0]
    decisions  = conn.execute("SELECT COUNT(*) FROM decisions WHERE status='active'").fetchone()[0]
    notes      = conn.execute("SELECT COUNT(*) FROM notes").fetchone()[0]
    langs      = conn.execute(
        "SELECT language, COUNT(*) AS cnt FROM files WHERE language IS NOT NULL GROUP BY language ORDER BY cnt DESC"
    ).fetchall()
    return {
        "files_indexed": files,
        "symbols_total": symbols,
        "functions": functions,
        "classes": classes,
        "decisions_active": decisions,
        "notes": notes,
        "language_breakdown": {r["language"]: r["cnt"] for r in langs},
    }


def get_top_files_by_references(conn: sqlite3.Connection, limit: int = 20) -> list[dict]:
    rows = conn.execute(
        """SELECT f.path, COUNT(c.id) AS incoming_calls,
                  (SELECT COUNT(*) FROM symbols WHERE file_id=f.id) AS symbol_count
           FROM files f
           LEFT JOIN symbols s ON s.file_id = f.id
           LEFT JOIN calls c ON c.callee_id = s.id
           GROUP BY f.id
           ORDER BY incoming_calls DESC
           LIMIT ?""",
        (limit,),
    ).fetchall()
    return [dict(r) for r in rows]


# ─── Decision / Note queries ──────────────────────────────────────────────────

def insert_decision(conn: sqlite3.Connection, session_id: str | None, title: str,
                    category: str, body: str, related_files: list[str],
                    related_symbols: list[str]) -> int:
    now = _now()
    cur = conn.execute(
        """INSERT INTO decisions
           (created_at, updated_at, session_id, title, category, body, related_files, related_symbols, status)
           VALUES (?, ?, ?, ?, ?, ?, ?, ?, 'active')""",
        (now, now, session_id, title, category, body,
         json.dumps(related_files), json.dumps(related_symbols)),
    )
    return cur.lastrowid  # type: ignore[return-value]


def search_decisions_db(conn: sqlite3.Connection, query: str = "", category: str = "",
                        status: str = "active", related_to_file: str = "",
                        limit: int = 20) -> list[sqlite3.Row]:
    if query:
        sql = """SELECT d.* FROM decisions_fts
                 JOIN decisions d ON decisions_fts.rowid = d.id
                 WHERE decisions_fts MATCH ?"""
        params: list[Any] = [query]
    else:
        sql = "SELECT * FROM decisions WHERE 1=1"
        params = []

    if status:
        sql += " AND status=?" if not query else " AND d.status=?"
        params.append(status)
    if category:
        sql += " AND category=?" if not query else " AND d.category=?"
        params.append(category)
    if related_to_file:
        sql += " AND related_files LIKE ?" if not query else " AND d.related_files LIKE ?"
        params.append(f"%{related_to_file}%")

    sql += f" {'LIMIT' if not query else 'LIMIT'} ?"
    params.append(limit)
    return conn.execute(sql, params).fetchall()


def update_decision_db(conn: sqlite3.Connection, did: int, status: str | None,
                       body: str | None) -> None:
    now = _now()
    if status and body:
        conn.execute("UPDATE decisions SET status=?, body=?, updated_at=? WHERE id=?",
                     (status, body, now, did))
    elif status:
        conn.execute("UPDATE decisions SET status=?, updated_at=? WHERE id=?", (status, now, did))
    elif body:
        conn.execute("UPDATE decisions SET body=?, updated_at=? WHERE id=?", (body, now, did))


def insert_note(conn: sqlite3.Connection, session_id: str | None, scope: str,
                scope_ref: str | None, body: str, tags: list[str]) -> int:
    now = _now()
    cur = conn.execute(
        "INSERT INTO notes (created_at, session_id, scope, scope_ref, body, tags) VALUES (?,?,?,?,?,?)",
        (now, session_id, scope, scope_ref, body, json.dumps(tags)),
    )
    return cur.lastrowid  # type: ignore[return-value]


def get_notes_db(conn: sqlite3.Connection, scope: str = "", scope_ref: str = "",
                 tags: list[str] | None = None, limit: int = 50) -> list[sqlite3.Row]:
    sql = "SELECT * FROM notes WHERE 1=1"
    params: list[Any] = []
    if scope:
        sql += " AND scope=?"
        params.append(scope)
    if scope_ref:
        sql += " AND scope_ref=?"
        params.append(scope_ref)
    sql += " ORDER BY created_at DESC LIMIT ?"
    params.append(limit)
    rows = conn.execute(sql, params).fetchall()
    if tags:
        # Filter in Python since JSON array matching in SQLite is awkward
        filtered = []
        for r in rows:
            stored = json.loads(r["tags"] or "[]")
            if any(t in stored for t in tags):
                filtered.append(r)
        return filtered
    return rows


# ─── Session queries ──────────────────────────────────────────────────────────

def upsert_session(conn: sqlite3.Connection, session_id: str, agent_hint: str) -> None:
    now = _now()
    conn.execute(
        """INSERT INTO sessions (id, agent_hint, started_at, last_active)
           VALUES (?, ?, ?, ?)
           ON CONFLICT(id) DO UPDATE SET last_active=excluded.last_active""",
        (session_id, agent_hint, now, now),
    )


def touch_session(conn: sqlite3.Connection, session_id: str) -> None:
    conn.execute("UPDATE sessions SET last_active=? WHERE id=?", (_now(), session_id))


# ─── Meta ─────────────────────────────────────────────────────────────────────

def set_meta(conn: sqlite3.Connection, key: str, value: str) -> None:
    conn.execute("INSERT OR REPLACE INTO meta (key, value) VALUES (?, ?)", (key, value))


def get_meta(conn: sqlite3.Connection, key: str) -> str | None:
    row = conn.execute("SELECT value FROM meta WHERE key=?", (key,)).fetchone()
    return row["value"] if row else None


def get_all_meta(conn: sqlite3.Connection) -> dict[str, str]:
    return {r["key"]: r["value"] for r in conn.execute("SELECT * FROM meta").fetchall()}


# ─── Helpers ──────────────────────────────────────────────────────────────────

def _now() -> str:
    import datetime
    return datetime.datetime.utcnow().isoformat() + "Z"


def row_to_dict(row: sqlite3.Row) -> dict:
    return dict(row)
