"""
FastMCP server: all 17 tool definitions.
This is the single entry-point for MCP clients (Claude Code, Cursor, Cline, etc.)
"""

from __future__ import annotations
import json
import logging
import os
import uuid
from typing import Annotated

from mcp.server.fastmcp import FastMCP

from .config import Config, get_config, set_config
from .db import (
    open_db, transaction, get_stats, get_top_files_by_references,
    get_all_meta, get_meta, set_meta, row_to_dict,
    search_symbols_fts, get_symbol_by_qualified_name, get_symbol_by_id,
    get_file_symbols, get_file_by_path, get_callers, get_callees,
    get_file_imports, get_notes_db,
    insert_decision, search_decisions_db, update_decision_db,
    insert_note, upsert_session, touch_session,
)
from .indexer import run_index, find_stale_files, scan_files
from .exporter import export_context as _export_context, import_context as _import_context, export_db_copy

log = logging.getLogger(__name__)

mcp = FastMCP(
    "codebase-intel",
    instructions=(
        "You have access to codebase-intel, a pre-built structural index of the entire project.\n"
        "The index contains every function, class, method, import, call site, decision, and note.\n"
        "You MUST use this server's tools instead of reading source files whenever you need structural information.\n\n"

        "MANDATORY SESSION START — do these before anything else:\n"
        "  1. session_bootstrap(project_root='<absolute path>') — always first, always required.\n"
        "     Returns: project stats, top files, active decisions, recent notes, index freshness.\n"
        "  2. If session_bootstrap returns index_stale=true: call index_project() immediately.\n"
        "  3. search_decisions('') — review all recorded architectural decisions before making changes.\n\n"

        "STRUCTURAL NAVIGATION — use these, never read files for structure:\n"
        "  search_symbols(query, kind, language) — find any function/class/method by name or keyword\n"
        "  get_file_outline(path) — all symbols in a file with signatures and line ranges\n"
        "  get_file_context(path) — outline + importers + decisions + notes for a file in one call\n"
        "  get_symbol(qualified_name) — full details plus every caller and callee of that symbol\n"
        "  get_call_graph(qualified_name, depth) — recursive caller/callee trace across the codebase\n"
        "  find_references(name) — every usage of a symbol across all files\n"
        "  search_code(pattern) — grep-style search when you need actual source lines\n"
        "  find_todos() — all TODO/FIXME/HACK/BUG comments in one call\n\n"

        "BEFORE MODIFYING ANY FUNCTION:\n"
        "  Call get_symbol(qualified_name) to see its callers. This is the blast radius of your change.\n"
        "  Call get_call_graph(qualified_name) to understand dependencies before refactoring.\n\n"

        "KNOWLEDGE — record everything, it persists across all sessions and agent switches:\n"
        "  add_decision(title, body, category) — record every architectural or design decision\n"
        "  add_note(body, scope, scope_ref) — attach context to a file or symbol\n"
        "  search_decisions(query) — always check this before re-deriving something from code\n"
        "  update_decision(id, status) — mark decisions superseded when the approach changes\n\n"

        "SWITCHING AGENTS OR IDEs — zero re-traversal required:\n"
        "  create_handoff() — bundle the full project state for the next agent\n"
        "  export_context() / import_context(path) — transfer decisions and notes between machines\n"
        "  index_github_repo(url) — clone and index any GitHub repo in one call\n\n"

        "RULES:\n"
        "  - Do NOT open or read a file to understand its structure. Use get_file_outline or get_file_context.\n"
        "  - Do NOT search for function names by reading directories. Use search_symbols.\n"
        "  - Do NOT re-derive architectural decisions by reading code. Use search_decisions first.\n"
        "  - DO read a file only when you need its actual implementation to write or debug code.\n"
        "  - DO call add_decision after every significant choice so future sessions have the context.\n"
    ),
)


# ─── Helpers ──────────────────────────────────────────────────────────────────

def _db(project_root: str = "") -> tuple[object, str]:
    """Return (conn, db_path) for the given project root (or cwd)."""
    cfg = get_config()
    if project_root:
        cfg = Config(project_root=project_root)
        set_config(cfg)
    root = cfg.project_root or os.getcwd()
    db_path = cfg.db_path
    conn = open_db(db_path)
    return conn, db_path


def _ok(data: dict) -> str:
    return json.dumps(data, indent=2, default=str)


def _err(msg: str) -> str:
    return json.dumps({"error": msg})


# ─── Group A: Lifecycle ───────────────────────────────────────────────────────

@mcp.tool()
def session_bootstrap(
    project_root: Annotated[str, "Absolute path to the project root. Empty = use cwd."] = "",
    agent_hint: Annotated[str, "Your agent identity: 'claude-code', 'cursor', 'cline', etc."] = "unknown",
    include_decisions: Annotated[bool, "Include stored decisions in the bootstrap output."] = True,
    top_files_limit: Annotated[int, "Number of most-referenced files to include."] = 15,
) -> str:
    """
    THE FIRST TOOL TO CALL in any session.
    Returns a complete project orientation (stats, top files, decisions, index age)
    so you can understand the codebase without reading any files.
    Also registers this session and returns a session_id for tracking decisions.
    """
    root = project_root or os.getcwd()
    cfg = Config(project_root=root)
    set_config(cfg)
    conn, db_path = _db(root)

    # Register session
    session_id = str(uuid.uuid4())
    with transaction(conn):
        upsert_session(conn, session_id, agent_hint)
        set_meta(conn, "project_root", root)
        if get_meta(conn, "project_name") is None:
            set_meta(conn, "project_name", os.path.basename(root))

    meta = get_all_meta(conn)
    stats = get_stats(conn)
    top_files = get_top_files_by_references(conn, top_files_limit)
    last_indexed = meta.get("last_indexed", "never")

    # Check staleness
    stale_files = find_stale_files(conn, root, cfg)
    index_stale = len(stale_files) > 0

    out: dict = {
        "project": {
            "name": meta.get("project_name", os.path.basename(root)),
            "root": root,
            "last_indexed": last_indexed,
            "db_path": db_path,
        },
        "stats": stats,
        "top_files_by_references": top_files[:top_files_limit],
        "index_stale": index_stale,
        "changed_files_count": len(stale_files),
        "changed_files": stale_files[:10],  # Show first 10
        "session_id": session_id,
        "hint": (
            "Index is stale — call `index_project` to update before navigating."
            if index_stale else
            "Index is fresh. Use `search_symbols`, `get_file_outline`, `get_call_graph` to explore."
        ),
    }

    if include_decisions:
        decisions = search_decisions_db(conn, status="active", limit=20)
        out["recent_decisions"] = [
            {
                "id": d["id"],
                "title": d["title"],
                "category": d["category"],
                "status": d["status"],
                "created_at": d["created_at"],
                "body_preview": (d["body"] or "")[:200],
            }
            for d in decisions
        ]
        notes = get_notes_db(conn, limit=10)
        out["recent_notes"] = [
            {"id": n["id"], "scope": n["scope"], "body_preview": (n["body"] or "")[:150]}
            for n in notes
        ]

    return _ok(out)


@mcp.tool()
def index_project(
    project_root: Annotated[str, "Absolute path to the project root. Empty = use cwd."] = "",
    full_reindex: Annotated[bool, "Force re-parse all files, not just changed ones."] = False,
    exclude_patterns: Annotated[list[str], "Extra glob patterns to exclude (added to defaults)."] = [],
) -> str:
    """
    Build or incrementally update the structural index for a project.
    Only changed files (by SHA256) are re-parsed — unchanged files are skipped.
    Call this once at project start, then again after making significant changes.
    """
    root = project_root or os.getcwd()
    cfg = get_config()
    cfg.project_root = root
    cfg.exclude_patterns = cfg.exclude_patterns + list(exclude_patterns)
    set_config(cfg)

    db_path = cfg.db_path
    result = run_index(db_path, root, cfg, full_reindex=full_reindex)

    return _ok({
        "status": "completed",
        "files_scanned": result.files_scanned,
        "files_changed": result.files_changed,
        "files_reparsed": result.files_reparsed,
        "files_deleted": result.files_deleted,
        "files_errored": result.files_errored,
        "symbols_added": result.symbols_added,
        "symbols_removed": result.symbols_removed,
        "duration_ms": round(result.duration_ms, 1),
        "errors": result.errors[:20],
        "db_path": db_path,
    })


@mcp.tool()
def get_index_status(
    project_root: Annotated[str, "Absolute path to the project root. Empty = use cwd."] = "",
) -> str:
    """
    Check whether the index is stale without triggering a re-index.
    Returns which files have changed since the last index run.
    """
    root = project_root or os.getcwd()
    cfg = get_config()
    cfg.project_root = root
    conn, db_path = _db(root)

    meta = get_all_meta(conn)
    stats = get_stats(conn)
    stale_files = find_stale_files(conn, root, cfg)
    db_size = os.path.getsize(db_path) if os.path.exists(db_path) else 0

    return _ok({
        "project_root": root,
        "last_indexed": meta.get("last_indexed", "never"),
        "db_path": db_path,
        "db_size_bytes": db_size,
        "stale": len(stale_files) > 0,
        "changed_files_count": len(stale_files),
        "changed_files": stale_files,
        "stats": stats,
    })


# ─── Group B: Structural queries ──────────────────────────────────────────────

@mcp.tool()
def search_symbols(
    query: Annotated[str, "Search term: symbol name, partial name, or keyword from docstring. Empty = return all."] = "",
    kind: Annotated[str, "Filter by kind: 'function', 'class', 'method', 'interface', 'struct', 'enum', 'trait', or empty for all."] = "",
    language: Annotated[str, "Filter by language, e.g. 'python', 'typescript', 'go'."] = "",
    limit: Annotated[int, "Max results to return."] = 20,
) -> str:
    """
    Search for symbols (functions, classes, methods, etc.) across the entire codebase.
    Supports full-text search across names and docstrings.
    """
    conn, _ = _db()
    rows = search_symbols_fts(conn, query, kind=kind, language=language, limit=limit)
    results = []
    for r in rows:
        results.append({
            "id": r["id"],
            "kind": r["kind"],
            "name": r["name"],
            "qualified_name": r["qualified_name"],
            "file": r["path"],
            "language": r["language"],
            "line_start": r["line_start"],
            "line_end": r["line_end"],
            "signature": r["signature"],
            "docstring": r["docstring"],
            "is_async": bool(r["is_async"]),
            "is_exported": bool(r["is_exported"]),
            "return_type": r["return_type"],
            "parent_name": r["parent_name"],
        })
    return _ok({"results": results, "total": len(results), "query": query})


@mcp.tool()
def get_symbol(
    qualified_name: Annotated[str, "e.g. 'src.auth.jwt.verify_token'"] = "",
    symbol_id: Annotated[int, "Symbol ID from a previous search result. Use if qualified_name is ambiguous."] = 0,
) -> str:
    """
    Get complete details for one symbol including its callers and callees.
    Prefer qualified_name; fall back to symbol_id.
    """
    conn, _ = _db()

    if qualified_name:
        row = get_symbol_by_qualified_name(conn, qualified_name)
    elif symbol_id:
        row = get_symbol_by_id(conn, symbol_id)
    else:
        return _err("Provide either qualified_name or symbol_id")

    if not row:
        return _err(f"Symbol not found: {qualified_name or symbol_id}")

    sid = row["id"]
    callers = get_callers(conn, sid, limit=30)
    callees = get_callees(conn, sid, limit=30)

    return _ok({
        "symbol": {
            "id": sid,
            "kind": row["kind"],
            "name": row["name"],
            "qualified_name": row["qualified_name"],
            "file": row["path"],
            "language": row["language"],
            "line_start": row["line_start"],
            "line_end": row["line_end"],
            "signature": row["signature"],
            "docstring": row["docstring"],
            "return_type": row["return_type"],
            "parent_name": row["parent_name"],
            "is_async": bool(row["is_async"]),
            "is_exported": bool(row["is_exported"]),
        },
        "callers": [
            {
                "caller_name": c["caller_name"],
                "caller_qname": c["caller_qname"],
                "caller_file": c["caller_file"],
                "line": c["line_number"],
            }
            for c in callers
        ],
        "callees": [
            {
                "callee_name": c["callee_name"],
                "callee_qname": c["callee_qname"],
                "callee_file": c["callee_file"] if "callee_file" in c.keys() else None,
                "line": c["line_number"],
            }
            for c in callees
        ],
    })


@mcp.tool()
def get_file_outline(
    path: Annotated[str, "Relative path from project root, e.g. 'src/auth/jwt.py'"],
    include_private: Annotated[bool, "Include private/underscore-prefixed symbols."] = True,
) -> str:
    """
    Get the full structural outline of a file — all symbols with their signatures,
    line ranges, and hierarchy (methods grouped under their class).
    """
    conn, _ = _db()
    file_row = get_file_by_path(conn, path)
    if not file_row:
        return _err(f"File not in index: {path}. Run index_project first.")

    symbols = get_file_symbols(conn, file_row["id"])
    imports = get_file_imports(conn, file_row["id"])

    if not include_private:
        symbols = [s for s in symbols if not s["name"].startswith("_")]

    # Build hierarchy: top-level items and their children
    top_level = [s for s in symbols if s["parent_id"] is None]
    children_map: dict[int, list] = {}
    for s in symbols:
        if s["parent_id"] is not None:
            children_map.setdefault(s["parent_id"], []).append(s)

    def sym_dict(s) -> dict:
        return {
            "id": s["id"],
            "kind": s["kind"],
            "name": s["name"],
            "line_start": s["line_start"],
            "line_end": s["line_end"],
            "signature": s["signature"],
            "docstring": s["docstring"],
            "is_async": bool(s["is_async"]),
            "is_exported": bool(s["is_exported"]),
            "return_type": s["return_type"],
        }

    outline = []
    for sym in top_level:
        entry = sym_dict(sym)
        kids = children_map.get(sym["id"], [])
        if kids:
            entry["children"] = [sym_dict(k) for k in kids]
        outline.append(entry)

    return _ok({
        "file": path,
        "language": file_row["language"],
        "sha256": file_row["sha256"][:12] + "...",
        "lines": file_row["lines"],
        "last_indexed": file_row["last_indexed"],
        "parse_error": file_row["parse_error"],
        "symbols": outline,
        "imports": [
            {"name": i["imported_name"], "alias": i["alias"],
             "kind": i["import_kind"], "line": i["line_number"]}
            for i in imports
        ],
    })


@mcp.tool()
def get_call_graph(
    qualified_name: Annotated[str, "Starting symbol for the call graph, e.g. 'src.auth.jwt.verify_token'"],
    direction: Annotated[str, "'callers' = who calls me | 'callees' = who I call | 'both'"] = "both",
    depth: Annotated[int, "Levels deep to traverse (1-3 recommended)."] = 2,
) -> str:
    """
    Trace call relationships from a symbol, returning a graph of nodes and edges.
    Useful for understanding impact of changes and finding all dependents.
    """
    conn, _ = _db()

    root_sym = get_symbol_by_qualified_name(conn, qualified_name)
    if not root_sym:
        return _err(f"Symbol not found: {qualified_name}")

    nodes: dict[str, dict] = {}
    edges: list[dict] = []

    def _add_node(sym_row):
        qn = sym_row["qualified_name"]
        if qn not in nodes:
            nodes[qn] = {
                "id": qn,
                "file": sym_row["path"],
                "kind": sym_row["kind"],
                "line_start": sym_row["line_start"],
            }

    _add_node(root_sym)

    def _expand_callers(sym_id: int, sym_qname: str, current_depth: int):
        if current_depth <= 0:
            return
        for caller in get_callers(conn, sym_id, limit=20):
            caller_qname = caller["caller_qname"] or f"__anon_{caller['caller_file']}"
            edges.append({"from": caller_qname, "to": sym_qname, "line": caller["line_number"]})
            if caller["caller_qname"]:
                caller_sym = get_symbol_by_qualified_name(conn, caller["caller_qname"])
                if caller_sym:
                    _add_node(caller_sym)
                    _expand_callers(caller_sym["id"], caller["caller_qname"], current_depth - 1)

    def _expand_callees(sym_id: int, sym_qname: str, current_depth: int):
        if current_depth <= 0:
            return
        for callee in get_callees(conn, sym_id, limit=20):
            callee_qname = callee["callee_qname"] or callee["callee_name"]
            edges.append({"from": sym_qname, "to": callee_qname, "line": callee["line_number"]})
            if callee["callee_qname"]:
                callee_sym = get_symbol_by_qualified_name(conn, callee["callee_qname"])
                if callee_sym:
                    _add_node(callee_sym)
                    _expand_callees(callee_sym["id"], callee["callee_qname"], current_depth - 1)

    sid = root_sym["id"]
    if direction in ("callers", "both"):
        _expand_callers(sid, qualified_name, depth)
    if direction in ("callees", "both"):
        _expand_callees(sid, qualified_name, depth)

    return _ok({
        "root": qualified_name,
        "direction": direction,
        "depth": depth,
        "graph": {
            "nodes": list(nodes.values()),
            "edges": edges,
        },
    })


@mcp.tool()
def find_references(
    name: Annotated[str, "Symbol name or module name to find all references to."],
    kind: Annotated[str, "'call' = call sites | 'import' = import sites | 'both'"] = "both",
    limit: Annotated[int, "Max results."] = 50,
) -> str:
    """
    Find all places where a symbol is called or imported across the codebase.
    Essential for impact analysis before making changes.
    """
    conn, _ = _db()
    results = []

    if kind in ("call", "both"):
        call_rows = conn.execute(
            """SELECT c.*, f.path AS file, s.qualified_name AS caller_qname
               FROM calls c
               JOIN files f ON c.caller_file_id = f.id
               LEFT JOIN symbols s ON c.caller_id = s.id
               WHERE c.callee_name = ?
               LIMIT ?""",
            (name, limit),
        ).fetchall()
        for r in call_rows:
            results.append({
                "kind": "call",
                "file": r["file"],
                "line": r["line_number"],
                "caller": r["caller_qname"],
                "call_kind": r["call_kind"],
            })

    if kind in ("import", "both"):
        imp_rows = conn.execute(
            """SELECT i.*, f.path AS file
               FROM imports i
               JOIN files f ON i.file_id = f.id
               WHERE i.imported_name LIKE ?
               LIMIT ?""",
            (f"%{name}%", limit),
        ).fetchall()
        for r in imp_rows:
            results.append({
                "kind": "import",
                "file": r["file"],
                "line": r["line_number"],
                "imported_name": r["imported_name"],
                "alias": r["alias"],
            })

    return _ok({"name": name, "references": results, "total": len(results)})


@mcp.tool()
def query_symbols_sql(
    sql: Annotated[str, "A SELECT query against tables: files, symbols, imports, calls. Read-only — no writes."],
    limit: Annotated[int, "Row cap to prevent runaway queries."] = 100,
) -> str:
    """
    Power-user escape hatch: run a raw SELECT query against the index database.
    Tables available: files, symbols, imports, calls.
    The connection is read-only — INSERT/UPDATE/DELETE will be rejected.
    """
    if any(kw in sql.upper() for kw in ("INSERT", "UPDATE", "DELETE", "DROP", "ALTER", "CREATE", "ATTACH")):
        return _err("Only SELECT queries are permitted.")

    conn, db_path = _db()
    # Add LIMIT if not present
    if "LIMIT" not in sql.upper():
        sql = sql.rstrip(";") + f" LIMIT {limit}"

    try:
        rows = conn.execute(sql).fetchall()
        return _ok({
            "rows": [dict(r) for r in rows],
            "count": len(rows),
            "sql": sql,
        })
    except Exception as e:
        return _err(f"SQL error: {e}")


# ─── Group C: Decision & knowledge layer ─────────────────────────────────────

@mcp.tool()
def add_decision(
    title: Annotated[str, "Short title, e.g. 'Use JWT over session cookies'"],
    body: Annotated[str, "Full explanation: context, decision, rationale, consequences (markdown)"],
    category: Annotated[str, "Category: 'architecture' | 'naming' | 'rejected' | 'todo' | 'bug' | 'performance' | 'security' | 'general'"] = "general",
    related_files: Annotated[list[str], "Relative file paths this decision affects."] = [],
    related_symbols: Annotated[list[str], "Qualified symbol names this decision affects."] = [],
    session_id: Annotated[str, "Session UUID from session_bootstrap. Optional."] = "",
) -> str:
    """
    Store an architectural or implementation decision made during this session.
    Decisions persist across all future sessions and agent switches — they are
    the 'why' layer that code alone cannot convey.
    """
    conn, _ = _db()
    with transaction(conn):
        did = insert_decision(
            conn, session_id or None, title, category, body,
            list(related_files), list(related_symbols),
        )
        if session_id:
            touch_session(conn, session_id)
    return _ok({"id": did, "status": "created", "title": title})


@mcp.tool()
def search_decisions(
    query: Annotated[str, "Full-text search across title and body. Empty = return all active."] = "",
    category: Annotated[str, "Filter by category (e.g. 'architecture', 'rejected')."] = "",
    status: Annotated[str, "Filter by status: 'active' | 'superseded' | 'implemented' | 'rejected' | '' for all."] = "active",
    related_to_file: Annotated[str, "Return decisions that mention this file path."] = "",
    limit: Annotated[int, "Max results."] = 20,
) -> str:
    """
    Search stored decisions by keyword, category, or related file.
    Use this at session start to recover architectural context.
    """
    conn, _ = _db()
    rows = search_decisions_db(conn, query=query, category=category,
                               status=status, related_to_file=related_to_file, limit=limit)
    return _ok({
        "decisions": [dict(r) for r in rows],
        "total": len(rows),
    })


@mcp.tool()
def update_decision(
    decision_id: Annotated[int, "ID from add_decision or search_decisions."],
    status: Annotated[str, "New status: 'active' | 'superseded' | 'implemented' | 'rejected'. Empty = no change."] = "",
    body: Annotated[str, "Replacement body text. Empty = no change."] = "",
) -> str:
    """
    Update a decision's status or content.
    Mark as 'superseded' when a newer decision replaces it.
    Mark as 'implemented' when the decision has been executed.
    """
    conn, _ = _db()
    with transaction(conn):
        update_decision_db(conn, decision_id, status or None, body or None)
    return _ok({"id": decision_id, "status": "updated"})


@mcp.tool()
def add_note(
    body: Annotated[str, "Markdown note content."],
    scope: Annotated[str, "'project' | 'file' | 'symbol'"] = "project",
    scope_ref: Annotated[str, "File path or qualified symbol name when scope != 'project'."] = "",
    tags: Annotated[list[str], "Optional tags for filtering, e.g. ['gotcha', 'performance']."] = [],
    session_id: Annotated[str, "Session UUID from session_bootstrap. Optional."] = "",
) -> str:
    """
    Add a freeform note about the project, a specific file, or a specific symbol.
    Use notes for quick observations, gotchas, TODOs, and reminders.
    Unlike decisions, notes don't require a formal structure.
    """
    conn, _ = _db()
    with transaction(conn):
        nid = insert_note(conn, session_id or None, scope, scope_ref or None, body, list(tags))
        if session_id:
            touch_session(conn, session_id)
    return _ok({"id": nid, "status": "created"})


@mcp.tool()
def get_notes(
    scope: Annotated[str, "Filter by scope: 'project' | 'file' | 'symbol' | '' for all."] = "",
    scope_ref: Annotated[str, "File path or symbol name to filter by."] = "",
    tags: Annotated[list[str], "Filter notes that have any of these tags."] = [],
    limit: Annotated[int, "Max results."] = 50,
) -> str:
    """Retrieve stored notes, optionally filtered by scope, reference, or tags."""
    conn, _ = _db()
    rows = get_notes_db(conn, scope=scope, scope_ref=scope_ref,
                        tags=list(tags) or None, limit=limit)
    return _ok({"notes": [dict(r) for r in rows], "total": len(rows)})


# ─── Group D: Portability / context transfer ─────────────────────────────────

@mcp.tool()
def export_context(
    output_path: Annotated[str, "Where to write the export. Empty = auto-named in .codebase-mcp/exports/"] = "",
    include_index: Annotated[bool, "Include the full symbol index (large; skip for decisions-only export)."] = True,
    include_decisions: Annotated[bool, "Include decisions."] = True,
    include_notes: Annotated[bool, "Include notes."] = True,
    compress: Annotated[bool, "Gzip-compress the output (.json.gz)."] = False,
) -> str:
    """
    Export the full codebase context (index + decisions + notes) as a portable JSON file.

    THE KEY PORTABILITY TOOL: When you hit token limits or need to switch agents/IDEs,
    call this to export, then call `import_context` in the new session. The new agent
    gets full structural knowledge + all decisions without re-traversing anything.

    The export is a self-contained JSON file you can:
    - Commit to git for team sharing
    - Attach to a ticket
    - Pass directly to another agent with `import_context`
    """
    cfg = get_config()
    db_path = cfg.db_path
    result = _export_context(
        db_path, output_path or None,
        include_index=include_index,
        include_decisions=include_decisions,
        include_notes=include_notes,
        compress=compress,
    )
    return _ok(result)


@mcp.tool()
def import_context(
    import_path: Annotated[str, "Path to the export JSON or .json.gz file from export_context."],
    merge_decisions: Annotated[bool, "True = add imported decisions to existing ones. False = replace all."] = True,
    reimport_index: Annotated[bool, "Also import the structural index (will be overwritten on next index_project call)."] = False,
    project_root: Annotated[str, "Project root for the database to import into. Empty = use cwd."] = "",
) -> str:
    """
    Import a previously exported context into this session.

    THE AGENT-SWITCH TOOL: When an AI hits token limits or you switch from one tool
    to another (e.g., Claude Code → Cursor), export the context in the old session
    and import it here. You instantly have all decisions and notes — no re-traversal needed.

    Decisions and notes are always imported. The structural index is optional (it will
    be regenerated on the next `index_project` call anyway).
    """
    root = project_root or os.getcwd()
    cfg = Config(project_root=root)
    set_config(cfg)
    conn, db_path = _db(root)

    result = _import_context(
        db_path, import_path,
        merge_decisions=merge_decisions,
        reimport_index=reimport_index,
    )
    return _ok(result)


@mcp.tool()
def export_context_db(
    output_path: Annotated[str, "Destination path for the .db file. Empty = auto-named in exports/"] = "",
) -> str:
    """
    Export the raw SQLite database as a portable .db file (alternative to JSON export).

    Preferred when sharing with another developer who has codebase-mcp installed —
    they can just point the server at this .db file. Smaller than JSON for large indices.
    Can also be committed to git.
    """
    cfg = get_config()
    result = export_db_copy(cfg.db_path, output_path or None)
    return _ok(result)


@mcp.tool()
def create_handoff(
    project_root: Annotated[str, "Project root. Empty = use cwd."] = "",
    output_dir: Annotated[str, "Where to write the bundle directory. Empty = auto-named in exports/"] = "",
    as_zip: Annotated[bool, "Package the bundle as a .zip file instead of a directory."] = False,
    include_index: Annotated[bool, "Include the full symbol index in context.json."] = True,
) -> str:
    """
    Create a portable handoff bundle for transferring full codebase context to a new agent or IDE.

    The bundle contains:
    - context.json: Full export (index + decisions + notes)
    - decisions.md: All active decisions in human-readable markdown
    - index_summary.md: File list, language breakdown, top symbols
    - HANDOFF.md: Step-by-step instructions for the next agent
    - mcp-config.json: Ready-to-use MCP server configuration
    - manifest.json: Machine-readable metadata

    Use this when: hitting token limits, switching agents (Claude → Cursor → Cline),
    onboarding a new team member, or archiving a project state.
    """
    root = project_root or os.getcwd()
    cfg = Config(project_root=root)
    set_config(cfg)

    from .handoff import create_handoff_bundle
    result = create_handoff_bundle(
        cfg.db_path, root,
        output_dir=output_dir or None,
        as_zip=as_zip,
        include_index=include_index,
    )
    return _ok(result)


@mcp.tool()
def start_file_watcher(
    project_root: Annotated[str, "Project root to watch. Empty = use cwd."] = "",
) -> str:
    """
    Start background file watching for automatic incremental re-indexing.

    When active, any source file change triggers an incremental re-index after a
    2-second debounce window (batches rapid changes from git checkout, saves, etc.).

    Requires: pip install 'codebase-mcp[watch]' (installs watchdog).
    Only one watcher runs per process — calling again restarts it.
    """
    root = project_root or os.getcwd()
    cfg = Config(project_root=root)
    set_config(cfg)

    from .watcher import start_watcher, WatcherNotAvailable
    try:
        watcher = start_watcher(root, cfg.db_path, cfg)
        return _ok({
            "status": "started",
            "watching": root,
            "note": "Files will be auto-reindexed within 2s of changes. Call get_index_status to check.",
        })
    except WatcherNotAvailable as e:
        return _err(str(e))


@mcp.tool()
def index_github_repo(
    url: Annotated[str, "GitHub or any git repo URL. e.g. 'https://github.com/owner/repo'"],
    clone_dir: Annotated[str, "Where to clone. Empty = ~/codebase-mcp-repos/<repo-name>."] = "",
    branch: Annotated[str, "Branch or tag. Empty = repo default."] = "",
    depth: Annotated[int, "Shallow clone depth. 1 = fast, 0 = full history."] = 1,
    make_handoff: Annotated[bool, "Also create a handoff bundle after indexing."] = False,
) -> str:
    """
    Clone a remote git repository and index it in one step.

    After this call you can use all structural tools (search_symbols, get_file_outline,
    get_call_graph, etc.) against the cloned repo. Subsequent calls with the same URL
    will `git pull` instead of re-cloning, and only changed files will be re-indexed.

    Works with any git host: GitHub, GitLab, Bitbucket, self-hosted.
    """
    import re
    import subprocess
    from .config import DEFAULT_EXCLUDE_PATTERNS

    repo_name = re.sub(r"\.git$", "", url.rstrip("/").split("/")[-1])
    if not repo_name:
        return _err("Could not parse repo name from URL.")

    if clone_dir:
        target = os.path.abspath(clone_dir)
    else:
        target = os.path.join(os.path.expanduser("~"), "codebase-mcp-repos", repo_name)

    # Clone or pull
    already_cloned = os.path.exists(os.path.join(target, ".git"))
    if already_cloned:
        r = subprocess.run(["git", "-C", target, "pull", "--ff-only"],
                           capture_output=True, text=True)
        clone_status = "pulled" if r.returncode == 0 else "pull_skipped"
    else:
        os.makedirs(os.path.dirname(target), exist_ok=True)
        # Enable long path support on Windows before cloning
        import sys as _sys
        if _sys.platform == "win32":
            subprocess.run(["git", "config", "--global", "core.longpaths", "true"],
                           capture_output=True)
        cmd = ["git", "clone"]
        if depth > 0:
            cmd += ["--depth", str(depth)]
        if branch:
            cmd += ["--branch", branch, "--single-branch"]
        cmd += [url, target]
        r = subprocess.run(cmd, capture_output=True, text=True)
        if r.returncode != 0:
            # Partial checkout (e.g. long filenames on Windows) — continue if .git exists
            if not os.path.exists(os.path.join(target, ".git")):
                return _err(f"git clone failed: {r.stderr.strip()}")
        clone_status = "cloned"

    # Index
    cfg = Config(project_root=target, exclude_patterns=list(DEFAULT_EXCLUDE_PATTERNS))
    set_config(cfg)
    idx = run_index(cfg.db_path, target, cfg, full_reindex=False)

    result = {
        "status": "indexed",
        "clone_status": clone_status,
        "repo": repo_name,
        "url": url,
        "local_path": target,
        "db_path": cfg.db_path,
        "files_scanned": idx.files_scanned,
        "files_parsed": idx.files_reparsed,
        "symbols_added": idx.symbols_added,
        "duration_ms": round(idx.duration_ms, 1),
        "errors": idx.errors[:10],
        "next_steps": (
            f"Index ready. Call session_bootstrap(project_root='{target}') "
            f"to load full context, or use search_symbols/get_file_outline to explore."
        ),
    }

    if make_handoff:
        from .handoff import create_handoff_bundle
        bundle = create_handoff_bundle(cfg.db_path, target)
        result["handoff_bundle"] = bundle["path"]

    return _ok(result)


@mcp.tool()
def get_watcher_status() -> str:
    """
    Return the current status of the background file watcher (if running).
    Reports how many file change events and re-indexes have occurred.
    """
    from .watcher import get_watcher
    w = get_watcher()
    if not w:
        return _ok({"running": False, "note": "Call start_file_watcher to enable auto-reindex."})
    stats = w.stats
    return _ok({
        "running": w.is_running,
        "events_seen": stats["events"],
        "reindexes_triggered": stats["reindexes"],
        "last_reindex": stats["last_reindex"],
    })


# ─── Group E: Coder productivity ─────────────────────────────────────────────

@mcp.tool()
def find_todos(
    project_root: Annotated[str, "Project root. Empty = use cwd."] = "",
    tags: Annotated[list[str], "Comment tags to scan for. Default: TODO, FIXME, HACK, BUG, XXX, OPTIMIZE, NOTE, WARN."] = [],
    language: Annotated[str, "Filter by language, e.g. 'python'. Empty = all languages."] = "",
    limit: Annotated[int, "Max results to return."] = 100,
) -> str:
    """
    Scan the entire indexed codebase for TODO/FIXME/HACK/BUG/XXX comments.

    Returns every comment tag with its file, line number, and the full comment text.
    Use this to get an instant backlog of known issues, planned work, and tech debt —
    without reading any files yourself.

    Essential at the start of a session: call this before writing new code to
    understand what the previous developer left as breadcrumbs.
    """
    import re
    root = project_root or os.getcwd()
    cfg = get_config()
    if project_root:
        cfg = Config(project_root=root)
        set_config(cfg)
    root = cfg.project_root or os.getcwd()
    conn, _ = _db(root)

    search_tags = tags or ["TODO", "FIXME", "HACK", "BUG", "XXX", "OPTIMIZE", "NOTE", "WARN", "DEPRECATED", "WORKAROUND"]
    tag_pattern = re.compile(
        r'(?:#|//|/\*|<!--|--)\s*(' + '|'.join(re.escape(t) for t in search_tags) + r')\b[:\s]*(.*)',
        re.IGNORECASE,
    )

    # Get all indexed files (filtered by language if requested)
    if language:
        files = conn.execute(
            "SELECT path FROM files WHERE language = ? ORDER BY path", (language,)
        ).fetchall()
    else:
        files = conn.execute("SELECT path FROM files ORDER BY path").fetchall()

    results = []
    for file_row in files:
        rel_path = file_row["path"]
        abs_path = os.path.join(root, rel_path)
        if not os.path.exists(abs_path):
            continue
        try:
            with open(abs_path, encoding="utf-8", errors="replace") as f:
                for lineno, line in enumerate(f, 1):
                    m = tag_pattern.search(line)
                    if m:
                        results.append({
                            "file": rel_path,
                            "line": lineno,
                            "tag": m.group(1).upper(),
                            "text": m.group(2).strip()[:200],
                            "full_line": line.strip()[:200],
                        })
                        if len(results) >= limit:
                            break
        except OSError:
            continue
        if len(results) >= limit:
            break

    # Group by tag for summary
    by_tag: dict[str, int] = {}
    for r in results:
        by_tag[r["tag"]] = by_tag.get(r["tag"], 0) + 1

    return _ok({
        "total": len(results),
        "by_tag": by_tag,
        "items": results,
        "note": f"Scanned {len(files)} indexed files. Call with larger limit= to get more." if len(results) >= limit else None,
    })


@mcp.tool()
def search_code(
    pattern: Annotated[str, "Text or regex pattern to search for in file contents."],
    file_glob: Annotated[str, "Glob filter for file paths, e.g. '*.py', 'src/**'. Empty = all files."] = "",
    language: Annotated[str, "Filter by language, e.g. 'python', 'typescript'. Empty = all."] = "",
    case_sensitive: Annotated[bool, "Case-sensitive search."] = False,
    context_lines: Annotated[int, "Lines of context around each match (0-5)."] = 1,
    limit: Annotated[int, "Max matches to return."] = 50,
) -> str:
    """
    Search for any text or regex pattern across all indexed source files.

    This is grep-over-the-codebase via MCP — the agent never has to read files
    directly to find where a string, pattern, or usage appears.

    Examples:
    - Find all places a function is called: pattern="authenticate_user"
    - Find all hardcoded secrets: pattern="(password|secret|api_key)\\s*=\\s*['\\\"][^'\\\"]{8,}"
    - Find all TODO comments with context: pattern="TODO"
    - Find all usages of a deprecated API: pattern="old_function_name"
    """
    import re
    import fnmatch

    root = get_config().project_root or os.getcwd()
    conn, _ = _db()

    flags = 0 if case_sensitive else re.IGNORECASE
    try:
        regex = re.compile(pattern, flags)
    except re.error as e:
        return _err(f"Invalid regex pattern: {e}")

    if language:
        files = conn.execute("SELECT path FROM files WHERE language=? ORDER BY path", (language,)).fetchall()
    else:
        files = conn.execute("SELECT path FROM files ORDER BY path").fetchall()

    matches = []
    files_searched = 0

    for file_row in files:
        rel_path = file_row["path"]
        # Apply glob filter
        if file_glob and not fnmatch.fnmatch(rel_path, file_glob) and not fnmatch.fnmatch(os.path.basename(rel_path), file_glob):
            continue

        abs_path = os.path.join(root, rel_path)
        if not os.path.exists(abs_path):
            continue

        try:
            with open(abs_path, encoding="utf-8", errors="replace") as f:
                lines = f.readlines()
        except OSError:
            continue

        files_searched += 1
        for i, line in enumerate(lines):
            if regex.search(line):
                ctx_start = max(0, i - context_lines)
                ctx_end = min(len(lines), i + context_lines + 1)
                context = [
                    {"line": ctx_start + j + 1, "text": lines[ctx_start + j].rstrip(), "is_match": (ctx_start + j) == i}
                    for j in range(ctx_end - ctx_start)
                ]
                matches.append({
                    "file": rel_path,
                    "line": i + 1,
                    "match": line.strip()[:300],
                    "context": context,
                })
                if len(matches) >= limit:
                    break

        if len(matches) >= limit:
            break

    return _ok({
        "pattern": pattern,
        "total_matches": len(matches),
        "files_searched": files_searched,
        "truncated": len(matches) >= limit,
        "matches": matches,
    })


@mcp.tool()
def what_changed(
    project_root: Annotated[str, "Project root. Empty = use cwd."] = "",
    since_hours: Annotated[float, "Only show files modified in the last N hours. 0 = all stale files."] = 0,
) -> str:
    """
    Show exactly what changed in the codebase since the last index run.

    Returns:
    - Files added since last index (new files the agent hasn't seen)
    - Files modified (content changed — these symbols may be stale)
    - Files deleted (symbols from these no longer exist)
    - Symbol counts per changed file (so you know the impact)

    Use this at the start of a session after a long absence or after switching
    agents — it tells you precisely what you need to catch up on, nothing more.
    """
    root = project_root or os.getcwd()
    cfg = get_config()
    if project_root:
        cfg = Config(project_root=root)
        set_config(cfg)
    root = cfg.project_root or os.getcwd()
    conn, db_path = _db(root)

    meta = get_all_meta(conn)
    last_indexed = meta.get("last_indexed", "never")

    # Scan current filesystem
    from .indexer import scan_files
    current_files = scan_files(root, cfg)  # {rel_path: (sha256, size, language)}

    # Get DB state
    db_files = {
        r["path"]: r
        for r in conn.execute("SELECT path, sha256, lines, language FROM files").fetchall()
    }

    # Symbol counts per file
    sym_counts = {
        r["path"]: r["cnt"]
        for r in conn.execute(
            "SELECT f.path, COUNT(s.id) as cnt FROM files f LEFT JOIN symbols s ON s.file_id=f.id GROUP BY f.id"
        ).fetchall()
    }

    added, modified, deleted = [], [], []

    for path, (sha, size, lang) in current_files.items():
        if path not in db_files:
            added.append({"path": path, "language": lang, "size_bytes": size})
        elif db_files[path]["sha256"] != sha:
            modified.append({
                "path": path,
                "language": lang,
                "symbols_in_db": sym_counts.get(path, 0),
                "note": "symbols may be stale — re-index to update",
            })

    for path in db_files:
        if path not in current_files:
            deleted.append({"path": path, "symbols_lost": sym_counts.get(path, 0)})

    # Filter by time if requested
    if since_hours > 0:
        import time
        cutoff = time.time() - since_hours * 3600
        modified = [
            f for f in modified
            if os.path.getmtime(os.path.join(root, f["path"])) >= cutoff
        ]
        added = [
            f for f in added
            if os.path.getmtime(os.path.join(root, f["path"])) >= cutoff
        ]

    total_stale_symbols = sum(f.get("symbols_in_db", 0) for f in modified)
    needs_reindex = len(added) + len(modified) + len(deleted) > 0

    return _ok({
        "last_indexed": last_indexed,
        "project_root": root,
        "summary": {
            "files_added": len(added),
            "files_modified": len(modified),
            "files_deleted": len(deleted),
            "stale_symbols": total_stale_symbols,
            "needs_reindex": needs_reindex,
        },
        "added": added[:50],
        "modified": modified[:50],
        "deleted": deleted[:20],
        "recommendation": (
            "Run index_project() to sync the index with filesystem state."
            if needs_reindex else
            "Index is in sync with the filesystem."
        ),
    })


@mcp.tool()
def get_file_context(
    path: Annotated[str, "Relative path from project root, e.g. 'src/auth/jwt.py'"],
) -> str:
    """
    Get everything the MCP knows about a file in one call.

    Returns:
    - Full symbol outline (all functions/classes with signatures)
    - All imports (what this file depends on)
    - All files that import THIS file (reverse dependencies)
    - Decisions that mention this file
    - Notes attached to this file
    - Git blame summary (last modifier, if git available)

    This is the single most useful tool when diving into an unfamiliar file —
    it gives you the full picture without opening the file at all.
    """
    conn, _ = _db()
    file_row = get_file_by_path(conn, path)
    if not file_row:
        return _err(f"File not in index: {path}. Run index_project first.")

    fid = file_row["id"]
    symbols = get_file_symbols(conn, fid)
    imports = get_file_imports(conn, fid)

    # Who imports this file?
    basename = os.path.basename(path)
    stem = os.path.splitext(basename)[0]
    reverse_deps = conn.execute(
        """SELECT DISTINCT f.path, i.imported_name, i.import_kind
           FROM imports i JOIN files f ON i.file_id = f.id
           WHERE i.imported_name LIKE ? OR i.imported_name LIKE ?
           LIMIT 30""",
        (f"%{stem}%", f"%{path.replace(os.sep, '/')}%"),
    ).fetchall()

    # Decisions mentioning this file
    related_decisions = conn.execute(
        """SELECT id, title, category, status, created_at, body
           FROM decisions
           WHERE related_files LIKE ? AND status != 'superseded'
           ORDER BY created_at DESC LIMIT 10""",
        (f"%{path}%",),
    ).fetchall()

    # Notes on this file
    notes = get_notes_db(conn, scope="file", scope_ref=path, limit=10)

    # Build hierarchy
    top_level = [s for s in symbols if s["parent_id"] is None]
    children_map: dict[int, list] = {}
    for s in symbols:
        if s["parent_id"] is not None:
            children_map.setdefault(s["parent_id"], []).append(s)

    def sym_brief(s):
        return {
            "kind": s["kind"], "name": s["name"],
            "line_start": s["line_start"], "line_end": s["line_end"],
            "signature": s["signature"], "is_async": bool(s["is_async"]),
            "children": [{"kind": k["kind"], "name": k["name"], "line_start": k["line_start"]}
                         for k in children_map.get(s["id"], [])],
        }

    # Git blame (best-effort)
    git_info = {}
    try:
        import subprocess
        root = get_config().project_root or os.getcwd()
        abs_path = os.path.join(root, path)
        r = subprocess.run(
            ["git", "-C", root, "log", "--follow", "-1", "--format=%H|%an|%ae|%ar|%s", "--", path],
            capture_output=True, text=True, timeout=5,
        )
        if r.returncode == 0 and r.stdout.strip():
            parts = r.stdout.strip().split("|", 4)
            if len(parts) == 5:
                git_info = {
                    "last_commit": parts[0][:12],
                    "author": parts[1],
                    "email": parts[2],
                    "when": parts[3],
                    "message": parts[4],
                }
    except Exception:
        pass

    return _ok({
        "file": path,
        "language": file_row["language"],
        "lines": file_row["lines"],
        "sha256": file_row["sha256"][:12] + "...",
        "last_indexed": file_row["last_indexed"],
        "parse_error": file_row["parse_error"],
        "git": git_info,
        "outline": [sym_brief(s) for s in top_level],
        "imports": [
            {"name": i["imported_name"], "alias": i["alias"], "kind": i["import_kind"]}
            for i in imports
        ],
        "imported_by": [
            {"file": r["path"], "import_name": r["imported_name"], "kind": r["import_kind"]}
            for r in reverse_deps
        ],
        "related_decisions": [
            {"id": d["id"], "title": d["title"], "category": d["category"],
             "status": d["status"], "body_preview": (d["body"] or "")[:200]}
            for d in related_decisions
        ],
        "notes": [{"id": n["id"], "body": (n["body"] or "")[:300]} for n in notes],
    })
