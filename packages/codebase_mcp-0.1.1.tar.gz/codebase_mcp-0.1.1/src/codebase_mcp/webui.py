"""
Web UI: local browser interface for browsing the codebase index, decisions, and notes.
Served by a simple stdlib HTTP server — zero extra dependencies.

Start with: codebase-mcp ui [PATH]
Opens at: http://127.0.0.1:7731
"""

from __future__ import annotations
import json
import logging
import os
import threading
import urllib.parse
from http.server import BaseHTTPRequestHandler, HTTPServer
from typing import Any

log = logging.getLogger(__name__)

# ─── Embedded HTML/CSS/JS ─────────────────────────────────────────────────────
# Single-file SPA. Vanilla JS, no build step, no external CDN.

_HTML = r"""<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>codebase-mcp</title>
<style>
:root {
  --bg: #0d1117; --bg2: #161b22; --bg3: #21262d;
  --border: #30363d; --text: #e6edf3; --muted: #8b949e;
  --accent: #58a6ff; --green: #3fb950; --yellow: #d29922;
  --red: #f85149; --purple: #bc8cff; --orange: #ffa657;
  --font: 'Segoe UI', system-ui, sans-serif; --mono: 'Cascadia Code', 'Fira Code', monospace;
}
* { box-sizing: border-box; margin: 0; padding: 0; }
body { background: var(--bg); color: var(--text); font-family: var(--font); font-size: 14px; height: 100vh; display: flex; flex-direction: column; }
a { color: var(--accent); text-decoration: none; }
a:hover { text-decoration: underline; }

/* ── Header ── */
#header { background: var(--bg2); border-bottom: 1px solid var(--border); padding: 10px 16px; display: flex; align-items: center; gap: 16px; flex-shrink: 0; }
#logo { font-weight: 700; font-size: 15px; color: var(--text); }
#logo span { color: var(--accent); }
#project-name { color: var(--muted); font-size: 13px; }
#search-box { flex: 1; max-width: 400px; background: var(--bg3); border: 1px solid var(--border); border-radius: 6px; padding: 6px 10px; color: var(--text); font-size: 13px; outline: none; }
#search-box:focus { border-color: var(--accent); }
#stats-bar { margin-left: auto; display: flex; gap: 16px; font-size: 12px; color: var(--muted); }
.stat-item { display: flex; flex-direction: column; align-items: center; }
.stat-value { font-size: 16px; font-weight: 600; color: var(--text); }

/* ── Layout ── */
#app { display: flex; flex: 1; overflow: hidden; }
#sidebar { width: 220px; background: var(--bg2); border-right: 1px solid var(--border); display: flex; flex-direction: column; flex-shrink: 0; }
#nav { padding: 8px; }
.nav-item { padding: 6px 10px; border-radius: 6px; cursor: pointer; font-size: 13px; display: flex; align-items: center; gap: 8px; color: var(--muted); }
.nav-item:hover { background: var(--bg3); color: var(--text); }
.nav-item.active { background: var(--accent); color: #fff; }
.nav-icon { font-size: 15px; width: 18px; text-align: center; }

#file-list { flex: 1; overflow-y: auto; padding: 0 8px 8px; }
.file-item { padding: 4px 8px; border-radius: 4px; cursor: pointer; font-size: 12px; color: var(--muted); white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
.file-item:hover { background: var(--bg3); color: var(--text); }
.file-item.active { background: var(--bg3); color: var(--accent); }
.file-section-header { padding: 8px 8px 2px; font-size: 11px; font-weight: 600; color: var(--muted); text-transform: uppercase; letter-spacing: 0.5px; }

/* ── Main content ── */
#main { flex: 1; overflow: hidden; display: flex; flex-direction: column; }
#content { flex: 1; overflow-y: auto; padding: 20px; }

/* ── Cards ── */
.card { background: var(--bg2); border: 1px solid var(--border); border-radius: 8px; padding: 16px; margin-bottom: 12px; }
.card-title { font-size: 13px; font-weight: 600; color: var(--muted); margin-bottom: 12px; display: flex; align-items: center; gap: 8px; }
.card-title-main { font-size: 15px; font-weight: 700; color: var(--text); }

/* ── Symbol list ── */
.symbol-list { display: flex; flex-direction: column; gap: 4px; }
.symbol-row { display: grid; grid-template-columns: 80px 1fr 120px 60px; gap: 8px; padding: 6px 8px; border-radius: 4px; cursor: pointer; align-items: center; }
.symbol-row:hover { background: var(--bg3); }
.sym-kind { font-size: 11px; font-weight: 600; border-radius: 3px; padding: 1px 5px; text-align: center; }
.k-function,.k-method { background: rgba(88,166,255,.15); color: var(--accent); }
.k-class { background: rgba(63,185,80,.15); color: var(--green); }
.k-interface,.k-trait { background: rgba(188,140,255,.15); color: var(--purple); }
.k-struct,.k-enum { background: rgba(255,166,87,.15); color: var(--orange); }
.k-heading,.k-variable { background: rgba(139,148,158,.15); color: var(--muted); }
.sym-name { font-family: var(--mono); font-size: 13px; color: var(--text); overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
.sym-file { font-size: 12px; color: var(--muted); overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
.sym-line { font-size: 11px; color: var(--muted); text-align: right; }

/* ── Decision cards ── */
.decision-card { background: var(--bg2); border: 1px solid var(--border); border-radius: 8px; padding: 16px; margin-bottom: 12px; }
.decision-header { display: flex; align-items: flex-start; gap: 10px; margin-bottom: 8px; }
.decision-title { font-size: 14px; font-weight: 600; color: var(--text); }
.badge { font-size: 11px; border-radius: 12px; padding: 2px 8px; flex-shrink: 0; }
.badge-arch { background: rgba(88,166,255,.2); color: var(--accent); }
.badge-reject { background: rgba(248,81,73,.2); color: var(--red); }
.badge-general { background: rgba(139,148,158,.2); color: var(--muted); }
.badge-bug { background: rgba(248,81,73,.2); color: var(--red); }
.badge-perf { background: rgba(255,166,87,.2); color: var(--orange); }
.badge-naming { background: rgba(188,140,255,.2); color: var(--purple); }
.decision-body { font-size: 13px; color: var(--muted); line-height: 1.6; white-space: pre-wrap; word-break: break-word; }
.decision-meta { font-size: 11px; color: var(--muted); margin-top: 8px; }

/* ── Symbol detail ── */
.sig-box { background: var(--bg3); border: 1px solid var(--border); border-radius: 6px; padding: 12px; font-family: var(--mono); font-size: 13px; color: var(--orange); margin: 8px 0; overflow-x: auto; }
.callers-table { width: 100%; border-collapse: collapse; font-size: 13px; }
.callers-table th { text-align: left; padding: 4px 8px; color: var(--muted); border-bottom: 1px solid var(--border); font-weight: 500; font-size: 11px; text-transform: uppercase; }
.callers-table td { padding: 5px 8px; border-bottom: 1px solid rgba(48,54,61,.5); font-family: var(--mono); }
.callers-table tr:hover td { background: var(--bg3); }

/* ── Grid ── */
.stats-grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(180px, 1fr)); gap: 12px; margin-bottom: 16px; }
.stat-card { background: var(--bg2); border: 1px solid var(--border); border-radius: 8px; padding: 16px; text-align: center; }
.stat-card-value { font-size: 28px; font-weight: 700; color: var(--accent); }
.stat-card-label { font-size: 12px; color: var(--muted); margin-top: 4px; }

/* ── Loading / Empty ── */
.loading { color: var(--muted); text-align: center; padding: 40px; }
.empty { color: var(--muted); text-align: center; padding: 40px; font-style: italic; }

/* ── Note ── */
.note-card { background: var(--bg2); border-left: 3px solid var(--accent); border-radius: 4px; padding: 10px 14px; margin-bottom: 8px; font-size: 13px; color: var(--muted); }
.note-scope { font-size: 11px; color: var(--muted); font-family: var(--mono); margin-top: 4px; }

/* ── Scrollbar ── */
::-webkit-scrollbar { width: 6px; height: 6px; }
::-webkit-scrollbar-track { background: transparent; }
::-webkit-scrollbar-thumb { background: var(--border); border-radius: 3px; }
::-webkit-scrollbar-thumb:hover { background: var(--muted); }

/* ── Add decision form ── */
#add-decision-form { display: none; }
#add-decision-form.open { display: block; }
.form-row { margin-bottom: 12px; }
.form-row label { display: block; font-size: 12px; color: var(--muted); margin-bottom: 4px; }
.form-row input, .form-row select, .form-row textarea {
  width: 100%; background: var(--bg3); border: 1px solid var(--border); border-radius: 6px;
  padding: 8px 10px; color: var(--text); font-size: 13px; font-family: var(--font); outline: none;
}
.form-row input:focus, .form-row select:focus, .form-row textarea:focus { border-color: var(--accent); }
.form-row textarea { min-height: 100px; resize: vertical; }
.btn { padding: 6px 14px; border-radius: 6px; border: none; cursor: pointer; font-size: 13px; font-weight: 500; }
.btn-primary { background: var(--accent); color: #fff; }
.btn-secondary { background: var(--bg3); color: var(--text); border: 1px solid var(--border); }
.btn:hover { opacity: 0.85; }
</style>
</head>
<body>
<div id="header">
  <div id="logo">codebase<span>-mcp</span></div>
  <div id="project-name">Loading...</div>
  <input id="search-box" type="text" placeholder="Search symbols..." oninput="onSearch(this.value)">
  <div id="stats-bar">
    <div class="stat-item"><div class="stat-value" id="h-files">-</div><div>files</div></div>
    <div class="stat-item"><div class="stat-value" id="h-syms">-</div><div>symbols</div></div>
    <div class="stat-item"><div class="stat-value" id="h-decs">-</div><div>decisions</div></div>
  </div>
</div>
<div id="app">
  <div id="sidebar">
    <div id="nav">
      <div class="nav-item active" onclick="showTab('overview')" id="nav-overview"><span class="nav-icon">⊙</span>Overview</div>
      <div class="nav-item" onclick="showTab('symbols')" id="nav-symbols"><span class="nav-icon">ƒ</span>Symbols</div>
      <div class="nav-item" onclick="showTab('decisions')" id="nav-decisions"><span class="nav-icon">✎</span>Decisions</div>
      <div class="nav-item" onclick="showTab('notes')" id="nav-notes"><span class="nav-icon">♦</span>Notes</div>
    </div>
    <div id="file-list"><div class="loading">Loading files...</div></div>
  </div>
  <div id="main"><div id="content"><div class="loading">Loading...</div></div></div>
</div>

<script>
let _stats = {}, _decisions = [], _allFiles = [], _searchTimer = null;

// ── Boot ──────────────────────────────────────────────────────────────────
async function boot() {
  const [stats, files] = await Promise.all([
    api('/api/stats'), api('/api/files')
  ]);
  _stats = stats;
  _allFiles = files.files || [];

  document.getElementById('project-name').textContent = stats.project_name || 'Unknown project';
  document.getElementById('h-files').textContent = stats.files_indexed;
  document.getElementById('h-syms').textContent = stats.symbols_total;
  document.getElementById('h-decs').textContent = stats.decisions_active;

  renderFileList(_allFiles);
  showTab('overview');
}

async function api(url) {
  try {
    const r = await fetch(url);
    return await r.json();
  } catch(e) { return {}; }
}

// ── Sidebar file list ──────────────────────────────────────────────────────
function renderFileList(files) {
  const el = document.getElementById('file-list');
  if (!files.length) { el.innerHTML = '<div class="empty">No files indexed</div>'; return; }

  const byLang = {};
  files.forEach(f => {
    const lang = f.language || 'other';
    (byLang[lang] = byLang[lang] || []).push(f);
  });

  let html = '';
  Object.keys(byLang).sort().forEach(lang => {
    html += `<div class="file-section-header">${lang}</div>`;
    byLang[lang].sort((a,b) => a.path.localeCompare(b.path)).forEach(f => {
      const short = f.path.split('/').pop();
      html += `<div class="file-item" title="${f.path}" onclick="showFileOutline('${escHtml(f.path)}')">${escHtml(short)}</div>`;
    });
  });
  el.innerHTML = html;
}

// ── Tab navigation ─────────────────────────────────────────────────────────
function showTab(tab) {
  ['overview','symbols','decisions','notes'].forEach(t => {
    document.getElementById('nav-'+t).classList.toggle('active', t===tab);
  });
  if (tab==='overview') renderOverview();
  else if (tab==='symbols') renderSymbols('');
  else if (tab==='decisions') renderDecisions();
  else if (tab==='notes') renderNotes();
}

// ── Overview ──────────────────────────────────────────────────────────────
async function renderOverview() {
  const [topFiles, recentDec] = await Promise.all([
    api('/api/top-files'),
    api('/api/decisions?limit=5')
  ]);

  const langs = Object.entries(_stats.language_breakdown||{})
    .map(([k,v]) => `<span style="color:var(--accent)">${k}</span> <span style="color:var(--muted)">${v}</span>`).join(' · ');

  let html = `
    <div class="stats-grid">
      <div class="stat-card"><div class="stat-card-value">${_stats.files_indexed||0}</div><div class="stat-card-label">Files</div></div>
      <div class="stat-card"><div class="stat-card-value">${_stats.symbols_total||0}</div><div class="stat-card-label">Symbols</div></div>
      <div class="stat-card"><div class="stat-card-value">${_stats.functions||0}</div><div class="stat-card-label">Functions</div></div>
      <div class="stat-card"><div class="stat-card-value">${_stats.classes||0}</div><div class="stat-card-label">Classes</div></div>
      <div class="stat-card"><div class="stat-card-value">${_stats.decisions_active||0}</div><div class="stat-card-label">Decisions</div></div>
      <div class="stat-card"><div class="stat-card-value">${_stats.notes||0}</div><div class="stat-card-label">Notes</div></div>
    </div>
    <div style="color:var(--muted);font-size:12px;margin-bottom:16px">${langs}</div>

    <div class="card">
      <div class="card-title">⬤ Most-Referenced Files</div>
      <div class="symbol-list">
        ${(topFiles.files||[]).slice(0,15).map(f=>`
          <div class="symbol-row" onclick="showFileOutline('${escHtml(f.path)}')">
            <span style="font-size:12px;color:var(--accent)">${f.incoming_calls} calls</span>
            <span class="sym-name">${escHtml(f.path)}</span>
            <span class="sym-file">${f.symbol_count} symbols</span>
            <span></span>
          </div>`).join('')}
      </div>
    </div>`;

  if ((recentDec.decisions||[]).length) {
    html += `<div class="card"><div class="card-title">Recent Decisions</div>`;
    recentDec.decisions.slice(0,3).forEach(d => {
      html += renderDecisionCard(d);
    });
    html += `<a href="#" onclick="showTab('decisions');return false" style="font-size:12px">View all →</a></div>`;
  }

  setContent(html);
}

// ── Symbols ───────────────────────────────────────────────────────────────
let _lastSearch = '';
function onSearch(q) {
  clearTimeout(_searchTimer);
  _searchTimer = setTimeout(() => {
    _lastSearch = q;
    if (q.length >= 1) renderSymbols(q);
  }, 200);
}

async function renderSymbols(q) {
  const url = q ? `/api/symbols?q=${encodeURIComponent(q)}&limit=50` : '/api/symbols?limit=100';
  const data = await api(url);
  const syms = data.results || [];

  let html = `<div style="margin-bottom:12px;color:var(--muted);font-size:12px">${syms.length} symbols${q ? ` matching "${q}"` : ''}</div>
    <div class="symbol-list">
    ${syms.map(s => `
      <div class="symbol-row" onclick="showSymbolDetail(${s.id},'${escHtml(s.qualified_name)}')">
        <span class="sym-kind k-${s.kind}">${s.kind}</span>
        <span class="sym-name">${escHtml(s.name)}${s.parent_name?`<span style="color:var(--muted)"> · ${escHtml(s.parent_name)}</span>`:''}</span>
        <span class="sym-file">${escHtml(s.file)}</span>
        <span class="sym-line">:${s.line_start}</span>
      </div>`).join('')}
    </div>`;

  setContent(html);
}

async function showSymbolDetail(id, qname) {
  const data = await api(`/api/symbol?id=${id}`);
  if (!data.symbol) return;
  const s = data.symbol;

  let html = `
    <div style="margin-bottom:4px"><a href="#" onclick="showFileOutline('${escHtml(s.file)}');return false" style="font-size:12px">← ${escHtml(s.file)}</a></div>
    <h2 style="font-size:18px;margin-bottom:4px">${escHtml(s.name)}</h2>
    <div style="font-size:12px;color:var(--muted);margin-bottom:8px">${s.kind} · line ${s.line_start}–${s.line_end} · ${s.language}</div>
    ${s.signature ? `<div class="sig-box">${escHtml(s.signature)}</div>` : ''}
    ${s.docstring ? `<div style="color:var(--muted);font-size:13px;line-height:1.6;margin:8px 0">${escHtml(s.docstring)}</div>` : ''}

    <div class="card" style="margin-top:16px">
      <div class="card-title">Called by (${data.callers.length})</div>
      ${data.callers.length ? `<table class="callers-table">
        <tr><th>Caller</th><th>File</th><th>Line</th></tr>
        ${data.callers.map(c=>`<tr><td>${escHtml(c.caller_name||'(module)')}</td><td style="color:var(--muted)">${escHtml(c.caller_file||'')}</td><td style="color:var(--muted)">${c.line}</td></tr>`).join('')}
      </table>` : '<div class="empty">No callers found</div>'}
    </div>

    <div class="card">
      <div class="card-title">Calls (${data.callees.length})</div>
      ${data.callees.length ? `<table class="callers-table">
        <tr><th>Callee</th><th>File</th><th>Line</th></tr>
        ${data.callees.map(c=>`<tr><td>${escHtml(c.callee_name||c.callee_qname||'')}</td><td style="color:var(--muted)">${escHtml(c.callee_file||'')}</td><td style="color:var(--muted)">${c.line}</td></tr>`).join('')}
      </table>` : '<div class="empty">No calls recorded</div>'}
    </div>`;

  setContent(html);
}

async function showFileOutline(path) {
  // Highlight in sidebar
  document.querySelectorAll('.file-item').forEach(el => el.classList.toggle('active', el.title===path));

  const data = await api(`/api/file-outline?path=${encodeURIComponent(path)}`);
  if (data.error) { setContent(`<div class="empty">${data.error}</div>`); return; }

  const renderSym = (s, indent=0) => `
    <div class="symbol-row" onclick="showSymbolDetail(${s.id},'${escHtml(s.qualified_name||s.name)}')" style="padding-left:${8+indent*20}px">
      <span class="sym-kind k-${s.kind}">${s.kind}</span>
      <span class="sym-name">${escHtml(s.name)}</span>
      <span></span>
      <span class="sym-line">:${s.line_start}</span>
    </div>
    ${(s.children||[]).map(c=>renderSym(c,indent+1)).join('')}`;

  let html = `
    <div style="margin-bottom:8px">
      <h2 style="font-size:16px;font-family:var(--mono)">${escHtml(path)}</h2>
      <div style="font-size:12px;color:var(--muted)">${data.language} · ${data.lines} lines · indexed ${data.last_indexed||'?'}</div>
    </div>`;

  if (data.imports?.length) {
    html += `<div class="card"><div class="card-title">Imports (${data.imports.length})</div>
      ${data.imports.slice(0,20).map(i=>`<div style="font-family:var(--mono);font-size:12px;color:var(--muted);padding:2px 0">${escHtml(i.name)}</div>`).join('')}</div>`;
  }

  html += `<div class="card"><div class="card-title">Symbols (${data.symbols?.length||0})</div>
    <div class="symbol-list">${(data.symbols||[]).map(s=>renderSym(s)).join('')}</div></div>`;

  setContent(html);
}

// ── Decisions ─────────────────────────────────────────────────────────────
function renderDecisionCard(d) {
  const badgeClass = {architecture:'arch',rejected:'reject',bug:'bug',performance:'perf',naming:'naming'}[d.category]||'general';
  return `<div class="decision-card">
    <div class="decision-header">
      <div class="decision-title">${escHtml(d.title)}</div>
      <span class="badge badge-${badgeClass}">${d.category}</span>
      <span class="badge badge-general" style="margin-left:auto">${d.status}</span>
    </div>
    <div class="decision-body">${escHtml((d.body||'').slice(0,400))}${(d.body||'').length>400?'\n…':''}</div>
    <div class="decision-meta">${d.created_at?.slice(0,10)||''}</div>
  </div>`;
}

async function renderDecisions() {
  const data = await api('/api/decisions?limit=100');
  const decs = data.decisions || [];
  _decisions = decs;

  let html = `
    <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:16px">
      <h2 style="font-size:16px">${decs.length} Active Decisions</h2>
      <button class="btn btn-primary" onclick="toggleAddDecision()">+ Add Decision</button>
    </div>
    <div id="add-decision-form" class="card">
      <div class="form-row"><label>Title</label><input id="dec-title" placeholder="Short title..."></div>
      <div class="form-row"><label>Category</label>
        <select id="dec-cat">
          <option>general</option><option>architecture</option><option>naming</option>
          <option>rejected</option><option>bug</option><option>performance</option><option>security</option>
        </select>
      </div>
      <div class="form-row"><label>Body (markdown)</label><textarea id="dec-body" placeholder="Context, decision, rationale..."></textarea></div>
      <div style="display:flex;gap:8px">
        <button class="btn btn-primary" onclick="submitDecision()">Save</button>
        <button class="btn btn-secondary" onclick="toggleAddDecision()">Cancel</button>
      </div>
    </div>
    ${decs.map(d=>renderDecisionCard(d)).join('')}
    ${!decs.length ? '<div class="empty">No decisions recorded yet. Add one above!</div>' : ''}`;

  setContent(html);
}

function toggleAddDecision() {
  const el = document.getElementById('add-decision-form');
  el.classList.toggle('open');
}

async function submitDecision() {
  const title = document.getElementById('dec-title').value.trim();
  const body  = document.getElementById('dec-body').value.trim();
  const cat   = document.getElementById('dec-cat').value;
  if (!title || !body) { alert('Title and body are required'); return; }
  await fetch('/api/decisions', {
    method: 'POST',
    headers: {'Content-Type':'application/json'},
    body: JSON.stringify({title,body,category:cat})
  });
  renderDecisions();
}

// ── Notes ─────────────────────────────────────────────────────────────────
async function renderNotes() {
  const data = await api('/api/notes');
  const notes = data.notes || [];
  let html = `<h2 style="font-size:16px;margin-bottom:16px">${notes.length} Notes</h2>
    ${notes.map(n=>`
      <div class="note-card">
        ${escHtml(n.body)}
        ${n.scope_ref?`<div class="note-scope">@ ${escHtml(n.scope_ref)}</div>`:''}
      </div>`).join('')}
    ${!notes.length ? '<div class="empty">No notes recorded.</div>' : ''}`;
  setContent(html);
}

// ── Helpers ───────────────────────────────────────────────────────────────
function setContent(html) { document.getElementById('content').innerHTML = html; }
function escHtml(s) { return String(s||'').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;'); }

boot();
</script>
</body>
</html>"""


# ─── HTTP Handler ─────────────────────────────────────────────────────────────

def _make_handler(db_path: str):
    """Create a request handler class bound to the given db_path."""

    class Handler(BaseHTTPRequestHandler):
        log_message = lambda self, *a: None  # Silence default access logs

        def do_GET(self):
            parsed = urllib.parse.urlparse(self.path)
            params = urllib.parse.parse_qs(parsed.query)
            path = parsed.path

            if path == "/" or path == "/index.html":
                self._send(200, "text/html", _HTML.encode())

            elif path == "/api/stats":
                from .db import open_db, get_stats, get_all_meta
                conn = open_db(db_path)
                stats = get_stats(conn)
                meta = get_all_meta(conn)
                stats["project_name"] = meta.get("project_name", "")
                stats["last_indexed"] = meta.get("last_indexed", "")
                self._json(stats)

            elif path == "/api/files":
                from .db import open_db, list_all_files
                conn = open_db(db_path)
                files = list_all_files(conn)
                self._json({"files": [dict(f) for f in files]})

            elif path == "/api/top-files":
                from .db import open_db, get_top_files_by_references
                conn = open_db(db_path)
                files = get_top_files_by_references(conn, limit=20)
                self._json({"files": files})

            elif path == "/api/symbols":
                from .db import open_db, search_symbols_fts
                conn = open_db(db_path)
                q = params.get("q", [""])[0]
                kind = params.get("kind", [""])[0]
                lang = params.get("lang", [""])[0]
                limit = int(params.get("limit", ["50"])[0])
                rows = search_symbols_fts(conn, q, kind=kind, language=lang, limit=limit)
                self._json({"results": [dict(r) for r in rows]})

            elif path == "/api/symbol":
                from .db import open_db, get_symbol_by_id, get_callers, get_callees
                conn = open_db(db_path)
                sid = int(params.get("id", ["0"])[0])
                sym = get_symbol_by_id(conn, sid)
                if not sym:
                    self._json({"error": "Not found"})
                    return
                callers = get_callers(conn, sid, limit=30)
                callees = get_callees(conn, sid, limit=30)
                self._json({
                    "symbol": dict(sym),
                    "callers": [dict(r) for r in callers],
                    "callees": [dict(r) for r in callees],
                })

            elif path == "/api/file-outline":
                from .db import open_db, get_file_by_path, get_file_symbols, get_file_imports
                conn = open_db(db_path)
                fpath = params.get("path", [""])[0]
                row = get_file_by_path(conn, fpath)
                if not row:
                    self._json({"error": f"File not indexed: {fpath}"})
                    return
                syms = get_file_symbols(conn, row["id"])
                imports = get_file_imports(conn, row["id"])
                # Build hierarchy
                top = [s for s in syms if s["parent_id"] is None]
                kids = {}
                for s in syms:
                    if s["parent_id"]:
                        kids.setdefault(s["parent_id"], []).append(dict(s))

                def enrich(s):
                    d = dict(s)
                    d["children"] = kids.get(s["id"], [])
                    return d

                self._json({
                    "file": fpath,
                    "language": row["language"],
                    "lines": row["lines"],
                    "last_indexed": row["last_indexed"],
                    "symbols": [enrich(s) for s in top],
                    "imports": [{"name": i["imported_name"], "line": i["line_number"]} for i in imports],
                })

            elif path == "/api/decisions":
                from .db import open_db, search_decisions_db
                conn = open_db(db_path)
                q = params.get("q", [""])[0]
                status = params.get("status", ["active"])[0]
                limit = int(params.get("limit", ["100"])[0])
                rows = search_decisions_db(conn, query=q, status=status, limit=limit)
                self._json({"decisions": [dict(r) for r in rows]})

            elif path == "/api/notes":
                from .db import open_db, get_notes_db
                conn = open_db(db_path)
                rows = get_notes_db(conn, limit=100)
                self._json({"notes": [dict(r) for r in rows]})

            else:
                self._send(404, "text/plain", b"Not found")

        def do_POST(self):
            parsed = urllib.parse.urlparse(self.path)
            if parsed.path == "/api/decisions":
                content_len = int(self.headers.get("Content-Length", 0))
                body = json.loads(self.rfile.read(content_len))
                from .db import open_db, insert_decision, transaction
                conn = open_db(db_path)
                with transaction(conn):
                    did = insert_decision(
                        conn, None, body.get("title", ""), body.get("category", "general"),
                        body.get("body", ""), [], [],
                    )
                    conn.execute("INSERT INTO decisions_fts(decisions_fts) VALUES('rebuild')")
                self._json({"id": did, "status": "created"})
            else:
                self._send(404, "text/plain", b"Not found")

        def _json(self, data: Any):
            payload = json.dumps(data, indent=2, default=str).encode()
            self._send(200, "application/json", payload)

        def _send(self, code: int, ctype: str, body: bytes):
            self.send_response(code)
            self.send_header("Content-Type", ctype)
            self.send_header("Content-Length", len(body))
            self.send_header("Access-Control-Allow-Origin", "*")
            self.end_headers()
            self.wfile.write(body)

    return Handler


def start_ui_server(db_path: str, host: str = "127.0.0.1", port: int = 7731) -> None:
    """Start the Web UI HTTP server (blocking)."""
    handler = _make_handler(db_path)
    server = HTTPServer((host, port), handler)
    log.info("Web UI running at http://%s:%d", host, port)
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        server.server_close()
