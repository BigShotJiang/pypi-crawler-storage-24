"""
Tests for the reports API endpoint.
"""



from tessera.api.deps import store_scan


class TestReportsEndpoint:
    def _create_completed_scan(self, scan_id="rpt-scan"):
        """Inject a completed scan with result data."""
        store_scan({
            "scan_id": scan_id,
            "status": "completed",
            "result": {
                "framework": "Tessera",
                "version": "2.0.0",
                "project": {"name": "Test"},
                "timestamp": "2026-03-24T12:00:00",
                "total_duration_sec": 1.5,
                "summary": {"total": 2, "pass": 1, "fail": 1, "warn": 0, "error": 0, "na": 0},
                "tests": [
                    {
                        "test_id": "MOD-01",
                        "test_name": "Evasion",
                        "category": "MOD",
                        "owasp_ref": "AITG-MOD-01",
                        "status": "PASS",
                        "phases": [
                            {
                                "phase": 1,
                                "name": "Attack",
                                "status": "PASS",
                                "metrics": [{"name": "rate", "value": 0.05, "unit": "%", "status": "PASS"}],
                                "evidence": ["Test evidence"],
                                "error": "",
                            }
                        ],
                        "tools_used": ["ART"],
                        "recommendations": ["Keep monitoring"],
                    },
                    {
                        "test_id": "MOD-02",
                        "test_name": "Poisoning",
                        "category": "MOD",
                        "owasp_ref": "AITG-MOD-02",
                        "status": "FAIL",
                        "phases": [],
                        "tools_used": [],
                        "recommendations": [],
                    },
                ],
            },
        })

    def test_get_json_report(self, api_client):
        self._create_completed_scan("json-scan")
        resp = api_client.get("/api/v1/reports/json-scan", params={"format": "json"})
        assert resp.status_code == 200
        data = resp.json()
        assert data["framework"] == "Tessera"
        assert len(data["tests"]) == 2

    def test_report_not_found(self, api_client):
        resp = api_client.get("/api/v1/reports/nonexistent")
        assert resp.status_code == 404

    def test_report_no_results(self, api_client):
        store_scan({"scan_id": "empty-scan", "status": "pending"})
        resp = api_client.get("/api/v1/reports/empty-scan", params={"format": "json"})
        assert resp.status_code == 400
        assert "no results" in resp.json()["detail"].lower()

    def test_invalid_format(self, api_client):
        self._create_completed_scan("fmt-scan")
        resp = api_client.get("/api/v1/reports/fmt-scan", params={"format": "pdf"})
        assert resp.status_code == 422  # Pydantic/FastAPI validation error
