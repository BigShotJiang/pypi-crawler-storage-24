"""
Tests for utils/connector_factory.py and individual connector wrappers.
"""




class TestConnectorFactory:
    """Test the connector factory routing logic."""

    def test_ollama_by_server_type(self):
        from utils.connector_factory import get_llm_client

        target = {"_server_type": "ollama", "_url": "http://localhost:11434", "name": "phi3"}
        client = get_llm_client({}, target)
        assert client.__class__.__name__ == "OllamaClient"
        assert client.model == "phi3"

    def test_vllm_by_server_type(self):
        from utils.connector_factory import get_llm_client

        config = {"models": {"vllm": {"api_base": "/v1", "api_key": "EMPTY"}}}
        target = {"_server_type": "vllm", "_url": "localhost:8000", "name": "llama3"}
        client = get_llm_client(config, target)
        assert client.__class__.__name__ == "LLMClient"

    def test_openai_by_server_type(self):
        from utils.connector_factory import get_llm_client

        config = {"models": {"openai": {"api_base": "/v1", "api_key": "sk-test"}}}
        target = {"_server_type": "openai", "_url": "api.openai.com", "name": "gpt-4"}
        client = get_llm_client(config, target)
        assert client.__class__.__name__ == "LLMClient"

    def test_huggingface_by_server_type(self):
        from utils.connector_factory import get_llm_client

        config = {"models": {"huggingface": {"token": "hf_test"}}}
        target = {"_server_type": "huggingface", "_url": "", "name": "meta-llama/Llama-2-7b"}
        client = get_llm_client(config, target)
        assert client.__class__.__name__ == "HuggingFaceClient"

    def test_bedrock_by_server_type(self):
        from utils.connector_factory import get_llm_client

        config = {"models": {"bedrock": {"region": "us-east-1"}}}
        target = {"_server_type": "bedrock", "_url": "", "name": "anthropic.claude-v2"}
        client = get_llm_client(config, target)
        assert client.__class__.__name__ == "BedrockClient"

    def test_azure_openai_by_server_type(self):
        from utils.connector_factory import get_llm_client

        config = {"models": {"azure_openai": {"api_key": "key", "endpoint": "https://x.openai.azure.com", "api_version": "2024-02-01"}}}
        target = {"_server_type": "azure_openai", "_url": "https://x.openai.azure.com", "name": "gpt-4"}
        client = get_llm_client(config, target)
        assert client.__class__.__name__ == "AzureOpenAIClient"

    def test_anthropic_by_server_type(self):
        from utils.connector_factory import get_llm_client

        config = {"models": {"anthropic": {"api_key": "sk-ant-test"}}}
        target = {"_server_type": "anthropic", "_url": "", "name": "claude-sonnet-4-5-20250929"}
        client = get_llm_client(config, target)
        assert client.__class__.__name__ == "AnthropicClient"

    def test_litellm_by_server_type(self):
        from utils.connector_factory import get_llm_client

        config = {"models": {"litellm": {"api_key": "key", "api_base": "http://localhost:4000"}}}
        target = {"_server_type": "litellm", "_url": "http://localhost:4000", "name": "gpt-4"}
        client = get_llm_client(config, target)
        assert client.__class__.__name__ == "LiteLLMClient"

    def test_vertex_ai_by_server_type(self):
        from utils.connector_factory import get_llm_client

        config = {"models": {"vertex_ai": {"project": "my-project", "location": "us-central1"}}}
        target = {"_server_type": "vertex_ai", "_url": "", "name": "gemini-1.5-pro"}
        client = get_llm_client(config, target)
        assert client.__class__.__name__ == "VertexAIClient"

    def test_custom_by_server_type(self):
        from utils.connector_factory import get_llm_client

        target = {"_server_type": "custom", "_url": "http://localhost:9000", "name": "custom"}
        client = get_llm_client({}, target)
        assert client.__class__.__name__ == "LLMClient"

    def test_no_target_model_returns_none(self):
        from utils.connector_factory import get_llm_client

        client = get_llm_client({})
        assert client is None

    def test_fallback_ollama_from_config(self):
        from utils.connector_factory import get_llm_client

        config = {
            "models": {
                "ollama": {
                    "url": "http://localhost:11434",
                    "model": "phi3",
                },
            },
        }
        client = get_llm_client(config)
        assert client.__class__.__name__ == "OllamaClient"

    def test_fallback_vllm_from_config(self):
        from utils.connector_factory import get_llm_client

        config = {
            "models": {
                "vllm": {
                    "url": "localhost:8000",
                    "api_base": "/v1",
                    "models": [{"name": "llama3"}],
                },
            },
        }
        client = get_llm_client(config)
        assert client.__class__.__name__ == "LLMClient"

    def test_fallback_anthropic_from_config(self):
        from utils.connector_factory import get_llm_client

        config = {
            "models": {
                "anthropic": {
                    "api_key": "sk-ant-test",
                    "model": "claude-sonnet-4-5-20250929",
                },
            },
        }
        client = get_llm_client(config)
        assert client.__class__.__name__ == "AnthropicClient"


class TestAzureOpenAIClient:
    def test_client_init(self):
        from utils.azure_openai_wrapper import AzureOpenAIClient

        client = AzureOpenAIClient(
            deployment="gpt-4",
            api_key="test-key",
            api_base="https://my.openai.azure.com",
        )
        assert client.deployment == "gpt-4"
        assert client.api_key == "test-key"
        assert client.api_version == "2024-02-01"


class TestAnthropicClient:
    def test_client_init(self):
        from utils.anthropic_wrapper import AnthropicClient

        client = AnthropicClient(model="claude-sonnet-4-5-20250929", api_key="sk-ant-test")
        assert client.model == "claude-sonnet-4-5-20250929"
        assert client.api_key == "sk-ant-test"

    def test_default_model(self):
        from utils.anthropic_wrapper import AnthropicClient

        client = AnthropicClient()
        assert client.model == "claude-sonnet-4-5-20250929"


class TestVertexAIClient:
    def test_client_init(self):
        from utils.vertex_ai_wrapper import VertexAIClient

        client = VertexAIClient(model="gemini-1.5-pro", project="my-project")
        assert client.model == "gemini-1.5-pro"
        assert client.project == "my-project"
        assert client.location == "us-central1"


class TestLiteLLMClient:
    def test_client_init(self):
        from utils.litellm_wrapper import LiteLLMClient

        client = LiteLLMClient(model="gpt-4", api_key="key", api_base="http://localhost:4000")
        assert client.model == "gpt-4"
        assert client.api_key == "key"
        assert client.api_base == "http://localhost:4000"
