"""
Tests for tessera/engine.py — core scan execution logic.

Uses mock test classes to validate run_tests(), run_per_model(),
enumerate_models(), build reports, etc.
"""



from tessera.engine import (
    build_executive_summary,
    build_flat_report,
    build_model_report,
    check_dependencies,
    create_versioned_output_dir,
    enumerate_models,
    get_applicable_tests,
    run_per_model,
    run_tests,
)


class TestCheckDependencies:
    def test_returns_two_dicts(self):
        available, missing = check_dependencies()
        assert isinstance(available, dict)
        assert isinstance(missing, dict)

    def test_known_available_deps(self):
        available, _ = check_dependencies()
        # These should be available since they're in core deps
        assert "requests" in available
        assert "Pandas" in available or "pandas" in str(available).lower()

    def test_no_overlap(self):
        available, missing = check_dependencies()
        assert set(available.keys()) & set(missing.keys()) == set()


class TestEnumerateModels:
    def test_triton_models(self, sample_config):
        models = enumerate_models(sample_config)
        triton = [m for m in models if m["_server_type"] == "triton"]
        assert len(triton) == 1
        assert triton[0]["name"] == "test-resnet"
        assert triton[0]["_type"] == "cv"

    def test_vllm_models(self, sample_config):
        models = enumerate_models(sample_config)
        vllm = [m for m in models if m["_server_type"] == "vllm"]
        assert len(vllm) == 1
        assert vllm[0]["name"] == "test-llama"
        assert vllm[0]["_type"] == "llm"

    def test_ollama_models(self, sample_config):
        models = enumerate_models(sample_config)
        ollama = [m for m in models if m["_server_type"] == "ollama"]
        assert len(ollama) == 1
        assert ollama[0]["name"] == "test-phi"
        assert ollama[0]["_type"] == "llm"

    def test_total_model_count(self, sample_config):
        models = enumerate_models(sample_config)
        assert len(models) == 3

    def test_custom_models(self):
        config = {
            "models": {
                "custom": [
                    {"name": "custom-cv", "url": "http://localhost:9000", "task": "detection"},
                    {"name": "custom-llm", "url": "http://localhost:9001", "task": "chat"},
                ]
            }
        }
        models = enumerate_models(config)
        assert len(models) == 2
        cv = [m for m in models if m["_type"] == "cv"]
        llm = [m for m in models if m["_type"] == "llm"]
        assert len(cv) == 1
        assert len(llm) == 1

    def test_empty_config(self):
        models = enumerate_models({})
        assert models == []


class TestGetApplicableTests:
    def test_cv_model(self, mock_registry):
        model = {"_type": "cv"}
        result = get_applicable_tests(model, ["MOCK-01", "MOCK-02", "MOCK-03", "MOCK-04"])
        assert "MOCK-01" in result
        assert "MOCK-02" in result
        assert "MOCK-04" in result

    def test_llm_model(self, mock_registry):
        model = {"_type": "llm"}
        result = get_applicable_tests(model, ["MOCK-01", "MOCK-02", "MOCK-03", "MOCK-04"])
        assert "MOCK-01" in result
        assert "MOCK-03" in result

    def test_filters_unavailable(self, mock_registry):
        model = {"_type": "cv"}
        result = get_applicable_tests(model, ["MOCK-01"])  # Only MOCK-01 available
        assert result == ["MOCK-01"]


class TestRunTests:
    def test_run_passing_test(self, mock_registry, sample_config):
        results, duration = run_tests(sample_config, ["MOCK-01"])
        assert len(results) == 1
        assert results[0].status == "PASS"
        assert duration >= 0

    def test_run_multiple_tests(self, mock_registry, sample_config):
        results, duration = run_tests(sample_config, ["MOCK-01", "MOCK-02", "MOCK-03"])
        assert len(results) == 3
        statuses = [r.status for r in results]
        assert "PASS" in statuses
        assert "FAIL" in statuses
        assert "WARN" in statuses

    def test_run_with_progress_callback(self, mock_registry, sample_config):
        progress_events = []

        def on_progress(info):
            progress_events.append(info)

        results, _ = run_tests(sample_config, ["MOCK-01"], on_progress=on_progress)
        assert len(results) == 1
        assert len(progress_events) >= 2  # at least start + complete
        assert progress_events[-1]["message"] == "Scan complete."

    def test_run_with_selective_phases(self, mock_registry, sample_config):
        results, _ = run_tests(sample_config, ["MOCK-01"], phases=[1])
        assert len(results[0].phases) == 1
        assert results[0].phases[0].phase == 1

    def test_run_error_test_continues(self, mock_registry, sample_config):
        """Error tests should be skipped but not crash the run."""
        results, _ = run_tests(sample_config, ["MOCK-04", "MOCK-01"])
        # MOCK-04 raises in phase1_attack, but run() catches it and returns ERROR
        # The engine also catches test-level exceptions
        assert len(results) >= 1


class TestRunPerModel:
    def test_per_model_basic(self, mock_registry, sample_config):
        all_results, all_models, duration = run_per_model(
            sample_config, ["MOCK-01"],
        )
        # We patched MODEL_TYPE_TESTS to include MOCK-01 for both cv and llm
        assert isinstance(all_results, dict)
        assert isinstance(all_models, list)
        assert duration >= 0

    def test_per_model_with_model_filter(self, mock_registry, sample_config):
        _, all_models, _ = run_per_model(
            sample_config, ["MOCK-01"],
            model_filter=["test-resnet"],
        )
        assert len(all_models) == 1
        assert all_models[0]["name"] == "test-resnet"

    def test_per_model_with_type_filter(self, mock_registry, sample_config):
        _, all_models, _ = run_per_model(
            sample_config, ["MOCK-01"],
            model_type_filter="cv",
        )
        assert all(m["_type"] == "cv" for m in all_models)

    def test_per_model_progress_callback(self, mock_registry, sample_config):
        events = []
        run_per_model(sample_config, ["MOCK-01"], on_progress=lambda info: events.append(info))
        assert len(events) >= 1


class TestCreateVersionedOutputDir:
    def test_creates_directory(self, tmp_path):
        result = create_versioned_output_dir(str(tmp_path / "reports"))
        assert result.exists()
        assert result.is_dir()

    def test_path_structure(self, tmp_path):
        result = create_versioned_output_dir(str(tmp_path / "reports"))
        # Should be something like reports/2026-03-24/12-34-56
        parts = result.relative_to(tmp_path / "reports").parts
        assert len(parts) == 2  # date / time


class TestBuildFlatReport:
    def test_basic_structure(self, sample_config, mock_test_results):
        report = build_flat_report(sample_config, mock_test_results, 1.5)
        assert report["framework"] == "Tessera"
        assert report["version"] == "2.0.0"
        assert report["total_duration_sec"] == 1.5
        assert "summary" in report
        assert "tests" in report

    def test_summary_counts(self, sample_config, mock_test_results):
        report = build_flat_report(sample_config, mock_test_results, 1.0)
        s = report["summary"]
        assert s["total"] == 2
        assert s["pass"] == 1
        assert s["fail"] == 1

    def test_project_metadata(self, sample_config, mock_test_results):
        report = build_flat_report(sample_config, mock_test_results, 1.0)
        assert report["project"]["name"] == "Test Project"


class TestBuildModelReport:
    def test_includes_model_info(self, sample_config, mock_test_results):
        model = {
            "name": "test-resnet",
            "arch": "resnet50",
            "_type": "cv",
            "task": "classification",
            "_server_type": "triton",
            "_url": "localhost:8001",
        }
        report = build_model_report(sample_config, model, mock_test_results)
        assert report["model"]["name"] == "test-resnet"
        assert report["model"]["arch"] == "resnet50"
        assert report["model"]["type"] == "cv"


class TestBuildExecutiveSummary:
    def test_executive_summary(self, sample_config, mock_test_results):
        all_models = [
            {"name": "test-resnet", "arch": "resnet50", "_type": "cv", "task": "classification"},
        ]
        all_results = {"test-resnet": mock_test_results}

        summary = build_executive_summary(
            sample_config, all_models, all_results, 2.0
        )
        assert summary["mode"] == "per-model"
        assert summary["models_tested"] == 1
        assert summary["models_total"] == 1
        assert "matrix" in summary
        assert "test-resnet" in summary["matrix"]
        assert "per_model_summary" in summary
