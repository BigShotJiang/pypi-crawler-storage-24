"""
Tests for the model registry API endpoints.
"""



class TestModelRegistry:
    def test_create_model(self, api_client):
        resp = api_client.post("/api/v1/models", json={
            "name": "resnet50",
            "arch": "resnet",
            "model_type": "cv",
            "server_type": "triton",
            "url": "localhost:8001",
            "task": "classification",
        })
        assert resp.status_code == 200
        data = resp.json()
        assert data["name"] == "resnet50"
        assert "id" in data

    def test_list_models_empty(self, api_client):
        resp = api_client.get("/api/v1/models")
        assert resp.status_code == 200
        assert resp.json()["models"] == []

    def test_list_models_after_create(self, api_client):
        api_client.post("/api/v1/models", json={"name": "model-a"})
        api_client.post("/api/v1/models", json={"name": "model-b"})

        resp = api_client.get("/api/v1/models")
        assert resp.status_code == 200
        assert len(resp.json()["models"]) == 2

    def test_get_model_detail(self, api_client):
        create_resp = api_client.post("/api/v1/models", json={
            "name": "my-model",
            "arch": "transformer",
        })
        model_id = create_resp.json()["id"]

        resp = api_client.get(f"/api/v1/models/{model_id}")
        assert resp.status_code == 200
        assert resp.json()["name"] == "my-model"

    def test_get_model_not_found(self, api_client):
        resp = api_client.get("/api/v1/models/nonexistent-id")
        assert resp.status_code == 404

    def test_delete_model(self, api_client):
        create_resp = api_client.post("/api/v1/models", json={"name": "to-delete"})
        model_id = create_resp.json()["id"]

        resp = api_client.delete(f"/api/v1/models/{model_id}")
        assert resp.status_code == 200
        assert resp.json()["deleted"] is True

        # Verify it's gone
        resp = api_client.get(f"/api/v1/models/{model_id}")
        assert resp.status_code == 404

    def test_delete_model_not_found(self, api_client):
        resp = api_client.delete("/api/v1/models/nonexistent")
        assert resp.status_code == 404

    def test_create_model_minimal(self, api_client):
        resp = api_client.post("/api/v1/models", json={"name": "minimal"})
        assert resp.status_code == 200
        data = resp.json()
        assert data["arch"] == ""
        assert data["model_type"] == "cv"

    def test_create_model_with_config(self, api_client):
        resp = api_client.post("/api/v1/models", json={
            "name": "configured",
            "config": {"batch_size": 32, "precision": "fp16"},
        })
        assert resp.status_code == 200
        assert resp.json()["config"]["batch_size"] == 32
