"""
Tests for tessera/config.py — config loader with env var expansion.
"""


import pytest
import yaml

from tessera.config import _expand_env, _expand_recursive, load_config


class TestExpandEnv:
    def test_simple_var(self, monkeypatch):
        monkeypatch.setenv("TEST_VAR", "hello")
        assert _expand_env("${TEST_VAR}") == "hello"

    def test_default_value(self):
        result = _expand_env("${NONEXISTENT_VAR:-fallback}")
        assert result == "fallback"

    def test_existing_var_ignores_default(self, monkeypatch):
        monkeypatch.setenv("MY_VAR", "real")
        assert _expand_env("${MY_VAR:-fallback}") == "real"

    def test_missing_var_keeps_placeholder(self):
        # When no default and var not set, keeps the original ${VAR}
        result = _expand_env("${DEFINITELY_NOT_SET_12345}")
        assert result == "${DEFINITELY_NOT_SET_12345}"

    def test_non_string_passthrough(self):
        assert _expand_env(42) == 42
        assert _expand_env(None) is None
        assert _expand_env(True) is True

    def test_multiple_vars_in_string(self, monkeypatch):
        monkeypatch.setenv("HOST", "localhost")
        monkeypatch.setenv("PORT", "8080")
        result = _expand_env("http://${HOST}:${PORT}")
        assert result == "http://localhost:8080"


class TestExpandRecursive:
    def test_dict(self, monkeypatch):
        monkeypatch.setenv("DB_HOST", "postgres")
        result = _expand_recursive({"host": "${DB_HOST}", "port": 5432})
        assert result == {"host": "postgres", "port": 5432}

    def test_list(self, monkeypatch):
        monkeypatch.setenv("ITEM", "value")
        result = _expand_recursive(["${ITEM}", "literal"])
        assert result == ["value", "literal"]

    def test_nested(self, monkeypatch):
        monkeypatch.setenv("NESTED", "deep")
        result = _expand_recursive({"a": {"b": {"c": "${NESTED}"}}})
        assert result["a"]["b"]["c"] == "deep"


class TestLoadConfig:
    def test_loads_yaml(self, tmp_path):
        config_file = tmp_path / "config.yaml"
        config_file.write_text(yaml.dump({
            "project": {"name": "Test"},
            "models": {"triton": {"url": "localhost:8001"}},
        }))
        config = load_config(str(config_file))
        assert config["project"]["name"] == "Test"

    def test_env_expansion_in_yaml(self, tmp_path, monkeypatch):
        monkeypatch.setenv("API_KEY", "secret123")
        config_file = tmp_path / "config.yaml"
        config_file.write_text(yaml.dump({
            "models": {"vllm": {"api_key": "${API_KEY}"}},
        }))
        config = load_config(str(config_file))
        assert config["models"]["vllm"]["api_key"] == "secret123"

    def test_default_values_in_yaml(self, tmp_path):
        config_file = tmp_path / "config.yaml"
        config_file.write_text(yaml.dump({
            "models": {"vllm": {"api_key": "${MISSING_KEY:-EMPTY}"}},
        }))
        config = load_config(str(config_file))
        assert config["models"]["vllm"]["api_key"] == "EMPTY"

    def test_empty_yaml(self, tmp_path):
        config_file = tmp_path / "config.yaml"
        config_file.write_text("")
        config = load_config(str(config_file))
        assert config == {}

    def test_file_not_found(self):
        with pytest.raises(FileNotFoundError):
            load_config("/nonexistent/path/config.yaml")
