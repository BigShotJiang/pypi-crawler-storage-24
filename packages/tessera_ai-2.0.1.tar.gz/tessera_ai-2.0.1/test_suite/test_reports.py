"""
Tests for tessera/reports.py — report generation (JSON, DOCX).
"""

import json

import pytest

from tessera.reports import write_json, write_reports


class TestWriteJSON:
    def test_write_json(self, tmp_path, sample_config, mock_test_results):
        from tessera.engine import build_flat_report

        report = build_flat_report(sample_config, mock_test_results, 1.5)
        path = tmp_path / "report.json"
        write_json(report, path)

        assert path.exists()
        data = json.loads(path.read_text())
        assert data["framework"] == "Tessera"
        assert data["summary"]["total"] == 2

    def test_json_is_valid(self, tmp_path):
        path = tmp_path / "test.json"
        write_json({"key": "value", "nested": {"a": 1}}, path)
        data = json.loads(path.read_text())
        assert data["key"] == "value"


class TestWriteReports:
    def test_write_json_format(self, tmp_path, sample_config, mock_test_results):
        from tessera.engine import build_flat_report

        report = build_flat_report(sample_config, mock_test_results, 1.0)
        output_dir = tmp_path / "reports"
        write_reports(report, output_dir, ["json"])

        assert (output_dir / "report.json").exists()

    def test_write_creates_directory(self, tmp_path, sample_config, mock_test_results):
        from tessera.engine import build_flat_report

        report = build_flat_report(sample_config, mock_test_results, 1.0)
        output_dir = tmp_path / "nested" / "deep" / "reports"
        write_reports(report, output_dir, ["json"])

        assert output_dir.exists()

    def test_write_docx_format(self, tmp_path, sample_config, mock_test_results):
        """Test DOCX report generation (requires python-docx)."""
        from tessera.engine import build_flat_report

        report = build_flat_report(sample_config, mock_test_results, 1.0)
        output_dir = tmp_path / "reports"

        try:
            write_reports(report, output_dir, ["docx"])
            docx_path = output_dir / "report.docx"
            if docx_path.exists():
                assert docx_path.stat().st_size > 0
        except ImportError:
            pytest.skip("python-docx not installed")


class TestWriteDocx:
    def test_docx_generation(self, tmp_path, sample_config, mock_test_results):
        """Test the write_docx function directly."""
        try:
            from tessera.engine import build_flat_report
            from tessera.reports import write_docx

            report = build_flat_report(sample_config, mock_test_results, 1.0)
            path = tmp_path / "report.docx"
            write_docx(report, path)

            assert path.exists()
            assert path.stat().st_size > 1000  # Should be a real DOCX file

            # Verify it's a valid DOCX (ZIP format)
            import zipfile
            assert zipfile.is_zipfile(str(path))

        except ImportError:
            pytest.skip("python-docx not installed")

    def test_docx_with_model_info(self, tmp_path, sample_config, mock_test_results):
        try:
            from tessera.engine import build_model_report
            from tessera.reports import write_docx

            model = {
                "name": "test-model",
                "arch": "resnet50",
                "_type": "cv",
                "task": "classification",
                "_server_type": "triton",
                "_url": "localhost:8001",
            }
            report = build_model_report(sample_config, model, mock_test_results)
            path = tmp_path / "model_report.docx"
            write_docx(report, path)
            assert path.exists()
        except ImportError:
            pytest.skip("python-docx not installed")


class TestWriteExecutiveDocx:
    def test_executive_docx(self, tmp_path, sample_config, mock_test_results):
        try:
            from tessera.engine import build_executive_summary
            from tessera.reports import write_executive_docx

            all_models = [
                {"name": "model-a", "arch": "resnet50", "_type": "cv", "task": "classification"},
                {"name": "model-b", "arch": "llama3", "_type": "llm", "task": "chat"},
            ]
            all_results = {
                "model-a": mock_test_results,
                "model-b": mock_test_results[:1],
            }
            summary = build_executive_summary(sample_config, all_models, all_results, 3.0)

            path = tmp_path / "executive.docx"
            write_executive_docx(summary, path)
            assert path.exists()
            assert path.stat().st_size > 1000
        except ImportError:
            pytest.skip("python-docx not installed")
