"""
Shared fixtures for the Tessera end-to-end test suite.

Provides mock test classes, sample configs, FastAPI test client,
and in-memory store reset between tests.
"""

import os
import sys
from pathlib import Path
from unittest.mock import patch

import pytest

# Ensure the project root is importable
PROJECT_ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(PROJECT_ROOT))

from tests.base import (  # noqa: F401, E402
    Metric,
    OWASPTestCase,
    PhaseResult,
    TestResult,
)

# ── Mock OWASP Test Cases ──


class MockPassingTest(OWASPTestCase):
    """A fast test that always passes all 3 phases."""

    TEST_ID = "MOCK-01"
    TEST_NAME = "Mock Passing Test"
    CATEGORY = "Mock"
    OWASP_REF = "AITG-MOCK-01"
    TOOLS = ["MockTool"]

    def phase1_attack(self, config):
        return PhaseResult(
            phase=1,
            name="Attack Simulation",
            status="PASS",
            metrics=[
                Metric(
                    name="attack_success_rate",
                    value=0.05,
                    threshold_pass=0.1,
                    threshold_fail=0.5,
                    unit="%",
                    operator="<",
                )
            ],
            evidence=["Mock attack completed successfully with low success rate."],
        )

    def phase2_measure(self, config):
        return PhaseResult(
            phase=2,
            name="Quantitative Metrics",
            status="PASS",
            metrics=[
                Metric(
                    name="robustness_score",
                    value=0.95,
                    threshold_pass=0.8,
                    threshold_fail=0.5,
                    unit="",
                    operator=">",
                )
            ],
            evidence=["Model demonstrated strong robustness."],
        )

    def phase3_defend(self, config):
        return PhaseResult(
            phase=3,
            name="Defense Validation",
            status="PASS",
            metrics=[
                Metric(
                    name="defense_coverage",
                    value=0.9,
                    threshold_pass=0.7,
                    threshold_fail=0.3,
                    unit="%",
                    operator=">",
                )
            ],
            evidence=["Defense mechanisms validated."],
        )


class MockFailingTest(OWASPTestCase):
    """A fast test that fails phase 1 (attack succeeds too well)."""

    TEST_ID = "MOCK-02"
    TEST_NAME = "Mock Failing Test"
    CATEGORY = "Mock"
    OWASP_REF = "AITG-MOCK-02"
    TOOLS = ["MockTool"]

    def phase1_attack(self, config):
        return PhaseResult(
            phase=1,
            name="Attack Simulation",
            status="FAIL",
            metrics=[
                Metric(
                    name="attack_success_rate",
                    value=0.8,
                    threshold_pass=0.1,
                    threshold_fail=0.5,
                    unit="%",
                    operator="<",
                )
            ],
            evidence=["Attack succeeded — model is vulnerable."],
        )

    def phase2_measure(self, config):
        return PhaseResult(
            phase=2,
            name="Quantitative Metrics",
            status="WARN",
            metrics=[
                Metric(
                    name="robustness_score",
                    value=0.6,
                    threshold_pass=0.8,
                    threshold_fail=0.5,
                    unit="",
                    operator=">",
                )
            ],
            evidence=["Moderate robustness."],
        )

    def phase3_defend(self, config):
        return PhaseResult(
            phase=3,
            name="Defense Validation",
            status="FAIL",
            metrics=[
                Metric(
                    name="defense_coverage",
                    value=0.2,
                    threshold_pass=0.7,
                    threshold_fail=0.3,
                    unit="%",
                    operator=">",
                )
            ],
            evidence=["Defense mechanisms inadequate."],
        )


class MockWarnTest(OWASPTestCase):
    """A test that returns WARN status."""

    TEST_ID = "MOCK-03"
    TEST_NAME = "Mock Warning Test"
    CATEGORY = "Mock"
    OWASP_REF = "AITG-MOCK-03"
    TOOLS = ["MockTool"]

    def phase1_attack(self, config):
        return PhaseResult(
            phase=1,
            name="Attack Simulation",
            status="WARN",
            metrics=[
                Metric(
                    name="attack_success_rate",
                    value=0.3,
                    threshold_pass=0.1,
                    threshold_fail=0.5,
                    unit="%",
                    operator="<",
                )
            ],
            evidence=["Borderline attack results."],
        )

    def phase2_measure(self, config):
        return PhaseResult(phase=2, name="Quantitative Metrics", status="PASS", metrics=[], evidence=[])

    def phase3_defend(self, config):
        return PhaseResult(phase=3, name="Defense Validation", status="PASS", metrics=[], evidence=[])


class MockErrorTest(OWASPTestCase):
    """A test that raises an exception."""

    TEST_ID = "MOCK-04"
    TEST_NAME = "Mock Error Test"
    CATEGORY = "Mock"
    OWASP_REF = "AITG-MOCK-04"
    TOOLS = []

    def phase1_attack(self, config):
        raise RuntimeError("Simulated dependency failure")

    def phase2_measure(self, config):
        return PhaseResult(phase=2, name="Quantitative Metrics", status="PASS")

    def phase3_defend(self, config):
        return PhaseResult(phase=3, name="Defense Validation", status="PASS")


# ── Fixtures ──


@pytest.fixture
def sample_config():
    """Minimal config dict for testing without real model servers."""
    return {
        "project": {
            "name": "Test Project",
            "environment": "testing",
            "author": "Test Suite",
        },
        "models": {
            "triton": {
                "url": "localhost:8001",
                "models": [
                    {"name": "test-resnet", "arch": "resnet50", "task": "classification"},
                ],
            },
            "vllm": {
                "url": "localhost:8000",
                "api_base": "/v1",
                "api_key": "EMPTY",
                "models": [
                    {"name": "test-llama", "arch": "llama3-8b", "task": "chat"},
                ],
            },
            "ollama": {
                "url": "http://localhost:11434",
                "models": [
                    {"name": "test-phi", "arch": "phi3", "task": "chat"},
                ],
            },
        },
    }


@pytest.fixture
def sample_config_yaml(tmp_path, sample_config):
    """Write sample config to a temp YAML file and return the path."""
    import yaml

    config_file = tmp_path / "config.yaml"
    config_file.write_text(yaml.dump(sample_config, default_flow_style=False))
    return str(config_file)


MOCK_REGISTRY = {
    "MOCK-01": ("test_suite.conftest", "MockPassingTest"),
    "MOCK-02": ("test_suite.conftest", "MockFailingTest"),
    "MOCK-03": ("test_suite.conftest", "MockWarnTest"),
    "MOCK-04": ("test_suite.conftest", "MockErrorTest"),
}

MOCK_CATEGORY_MAP = {
    "mod": ["MOCK-01", "MOCK-02"],
    "app": ["MOCK-03"],
    "inf": ["MOCK-04"],
    "dat": [],
    "all": ["MOCK-01", "MOCK-02", "MOCK-03", "MOCK-04"],
}

MOCK_MODEL_TYPE_TESTS = {
    "cv": ["MOCK-01", "MOCK-02", "MOCK-04"],
    "llm": ["MOCK-01", "MOCK-03", "MOCK-04"],
}


@pytest.fixture
def mock_registry():
    """Patch the registry to use mock tests instead of real OWASP tests."""
    with patch("tessera.registry.TEST_REGISTRY", MOCK_REGISTRY), \
         patch("tessera.registry.CATEGORY_MAP", MOCK_CATEGORY_MAP), \
         patch("tessera.registry.MODEL_TYPE_TESTS", MOCK_MODEL_TYPE_TESTS), \
         patch("tessera.engine.MODEL_TYPE_TESTS", MOCK_MODEL_TYPE_TESTS):
        yield


@pytest.fixture
def reset_stores():
    """Reset in-memory stores between tests."""
    from tessera.api import deps
    deps._scans.clear()
    deps._models_store.clear()
    deps._configs.clear()
    yield
    deps._scans.clear()
    deps._models_store.clear()
    deps._configs.clear()


@pytest.fixture
def api_client(reset_stores):
    """FastAPI TestClient using the real app factory (standalone mode, no DB)."""
    # Ensure no DB is configured
    env = os.environ.copy()
    env.pop("TESSERA_DATABASE_URL", None)

    from fastapi.testclient import TestClient

    from tessera.api.app import create_app

    app = create_app()
    with TestClient(app) as client:
        yield client


@pytest.fixture
def mock_test_results():
    """Pre-built TestResult objects for report/result testing."""
    pass_result = TestResult(
        test_id="MOCK-01",
        test_name="Mock Passing Test",
        category="Mock",
        owasp_ref="AITG-MOCK-01",
        status="PASS",
        phases=[
            PhaseResult(
                phase=1,
                name="Attack Simulation",
                status="PASS",
                metrics=[
                    Metric("attack_success_rate", 0.05, 0.1, 0.5, "%", "<"),
                ],
                evidence=["Attack completed."],
                duration_sec=0.1,
            ),
            PhaseResult(
                phase=2,
                name="Quantitative Metrics",
                status="PASS",
                metrics=[
                    Metric("robustness_score", 0.95, 0.8, 0.5, "", ">"),
                ],
                evidence=["Strong robustness."],
                duration_sec=0.1,
            ),
            PhaseResult(
                phase=3,
                name="Defense Validation",
                status="PASS",
                metrics=[
                    Metric("defense_coverage", 0.9, 0.7, 0.3, "%", ">"),
                ],
                evidence=["Defenses validated."],
                duration_sec=0.1,
            ),
        ],
        tools_used=["MockTool"],
        recommendations=["Continue monitoring.", {"text": "Review docs", "url": "https://example.com"}],
        duration_sec=0.3,
        model_name="test-resnet",
        model_arch="resnet50",
        model_type="cv",
        model_task="classification",
    )

    fail_result = TestResult(
        test_id="MOCK-02",
        test_name="Mock Failing Test",
        category="Mock",
        owasp_ref="AITG-MOCK-02",
        status="FAIL",
        phases=[
            PhaseResult(
                phase=1,
                name="Attack Simulation",
                status="FAIL",
                metrics=[
                    Metric("attack_success_rate", 0.8, 0.1, 0.5, "%", "<"),
                ],
                evidence=["Attack succeeded — vulnerable."],
                duration_sec=0.1,
            ),
        ],
        tools_used=["MockTool"],
        recommendations=["Apply adversarial training."],
        duration_sec=0.1,
        model_name="test-resnet",
        model_arch="resnet50",
        model_type="cv",
        model_task="classification",
    )

    return [pass_result, fail_result]
