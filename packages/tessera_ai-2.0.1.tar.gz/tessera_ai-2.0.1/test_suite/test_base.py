"""
Tests for tests/base.py — Metric, PhaseResult, TestResult, OWASPTestCase.

Validates the foundational data models and the 3-phase execution pipeline.
"""

import json

from tests.base import Metric, OWASPTestCase, PhaseResult, TestResult

# ── Metric ──


class TestMetric:
    """Tests for the Metric dataclass and its status property."""

    def test_metric_pass_less_than(self):
        m = Metric("rate", 0.05, threshold_pass=0.1, threshold_fail=0.5, operator="<")
        assert m.status == "PASS"

    def test_metric_warn_less_than(self):
        m = Metric("rate", 0.3, threshold_pass=0.1, threshold_fail=0.5, operator="<")
        assert m.status == "WARN"

    def test_metric_fail_less_than(self):
        m = Metric("rate", 0.8, threshold_pass=0.1, threshold_fail=0.5, operator="<")
        assert m.status == "FAIL"

    def test_metric_pass_greater_than(self):
        m = Metric("score", 0.95, threshold_pass=0.8, threshold_fail=0.5, operator=">")
        assert m.status == "PASS"

    def test_metric_warn_greater_than(self):
        m = Metric("score", 0.65, threshold_pass=0.8, threshold_fail=0.5, operator=">")
        assert m.status == "WARN"

    def test_metric_fail_greater_than(self):
        m = Metric("score", 0.3, threshold_pass=0.8, threshold_fail=0.5, operator=">")
        assert m.status == "FAIL"

    def test_metric_boundary_less_than_pass(self):
        # Exact boundary: value == threshold_pass with "<" should not PASS
        m = Metric("rate", 0.1, threshold_pass=0.1, threshold_fail=0.5, operator="<")
        assert m.status == "WARN"

    def test_metric_boundary_greater_than_pass(self):
        # Exact boundary: value == threshold_pass with ">" should not PASS
        m = Metric("score", 0.8, threshold_pass=0.8, threshold_fail=0.5, operator=">")
        assert m.status == "WARN"

    def test_metric_with_unit_and_source(self):
        m = Metric("latency", 50, 100, 500, "ms", "<", "OWASP AITG")
        assert m.unit == "ms"
        assert m.source == "OWASP AITG"
        assert m.status == "PASS"


# ── PhaseResult ──


class TestPhaseResult:
    def test_default_values(self):
        pr = PhaseResult(phase=1, name="Test Phase")
        assert pr.status == "NOT_RUN"
        assert pr.metrics == []
        assert pr.evidence == []
        assert pr.duration_sec == 0.0
        assert pr.error == ""

    def test_with_metrics(self):
        m = Metric("score", 0.9, 0.8, 0.5, "", ">")
        pr = PhaseResult(phase=2, name="Measurement", status="PASS", metrics=[m])
        assert len(pr.metrics) == 1
        assert pr.metrics[0].status == "PASS"


# ── TestResult ──


class TestTestResult:
    def test_default_status(self):
        tr = TestResult(test_id="T-01", test_name="Test", category="Cat", owasp_ref="REF")
        assert tr.status == "NOT_RUN"
        assert tr.phases == []
        assert tr.tools_used == []
        assert tr.recommendations == []

    def test_to_dict(self):
        m = Metric("rate", 0.05, 0.1, 0.5, "%", "<")
        pr = PhaseResult(phase=1, name="Attack", status="PASS", metrics=[m])
        tr = TestResult(
            test_id="T-01",
            test_name="Test",
            category="Cat",
            owasp_ref="REF",
            status="PASS",
            phases=[pr],
            model_name="my-model",
        )
        d = tr.to_dict()
        assert d["test_id"] == "T-01"
        assert d["status"] == "PASS"
        assert len(d["phases"]) == 1
        assert d["phases"][0]["name"] == "Attack"
        assert d["model_name"] == "my-model"

    def test_to_json(self, tmp_path):
        tr = TestResult(test_id="T-01", test_name="Test", category="Cat", owasp_ref="REF")
        path = tmp_path / "result.json"
        tr.to_json(path)
        data = json.loads(path.read_text())
        assert data["test_id"] == "T-01"


# ── OWASPTestCase ──


class TestOWASPTestCase:
    """Tests for the base OWASPTestCase run() and _run_phase() logic."""

    def test_passing_test(self):
        from test_suite.conftest import MockPassingTest

        config = {"project": {"name": "test"}}
        test = MockPassingTest(config)
        result = test.run()

        assert result.test_id == "MOCK-01"
        assert result.status == "PASS"
        assert len(result.phases) == 3
        assert all(p.status == "PASS" for p in result.phases)
        assert result.duration_sec >= 0

    def test_failing_test(self):
        from test_suite.conftest import MockFailingTest

        config = {"project": {"name": "test"}}
        test = MockFailingTest(config)
        result = test.run()

        assert result.status == "FAIL"
        assert result.phases[0].status == "FAIL"

    def test_warn_test(self):
        from test_suite.conftest import MockWarnTest

        config = {"project": {"name": "test"}}
        test = MockWarnTest(config)
        result = test.run()

        assert result.status == "WARN"

    def test_error_test(self):
        from test_suite.conftest import MockErrorTest

        config = {"project": {"name": "test"}}
        test = MockErrorTest(config)
        result = test.run()

        assert result.status == "ERROR"
        assert "RuntimeError" in result.phases[0].error

    def test_selective_phases(self):
        from test_suite.conftest import MockPassingTest

        config = {"project": {"name": "test"}}
        test = MockPassingTest(config)
        result = test.run(phases=[1, 3])

        assert len(result.phases) == 2
        assert result.phases[0].phase == 1
        assert result.phases[1].phase == 3

    def test_single_phase(self):
        from test_suite.conftest import MockPassingTest

        config = {"project": {"name": "test"}}
        test = MockPassingTest(config)
        result = test.run(phases=[2])

        assert len(result.phases) == 1
        assert result.phases[0].phase == 2

    def test_target_model_metadata(self):
        from test_suite.conftest import MockPassingTest

        config = {"project": {"name": "test"}}
        model = {
            "name": "my-model",
            "arch": "resnet50",
            "_type": "cv",
            "task": "classification",
        }
        test = MockPassingTest(config, target_model=model)
        result = test.run(phases=[1])

        assert result.model_name == "my-model"
        assert result.model_arch == "resnet50"
        assert result.model_type == "cv"
        assert result.model_task == "classification"

    def test_phase_status_derivation_from_metrics(self):
        """Test that _run_phase derives status from metrics when status is NOT_RUN."""

        class DerivedStatusTest(OWASPTestCase):
            TEST_ID = "DERIVE-01"
            TEST_NAME = "Derived Status"
            CATEGORY = "Test"
            OWASP_REF = "TEST"

            def phase1_attack(self, config):
                return PhaseResult(
                    phase=1,
                    name="Attack",
                    # status left as NOT_RUN — should be derived from metrics
                    metrics=[
                        Metric("score", 0.9, 0.8, 0.5, "", ">"),  # PASS
                    ],
                )

            def phase2_measure(self, config):
                return PhaseResult(phase=2, name="Measure", status="PASS")

            def phase3_defend(self, config):
                return PhaseResult(phase=3, name="Defend", status="PASS")

        test = DerivedStatusTest({"project": {}})
        result = test.run(phases=[1])
        assert result.phases[0].status == "PASS"
