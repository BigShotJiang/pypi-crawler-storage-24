"""
End-to-end integration tests — full lifecycle through the API.

Tests the complete flow: create scan → poll status → query results → compare → download reports.
Uses mock test classes to avoid needing real model servers.
"""

import time
from unittest.mock import patch

import pytest

from tessera.api.deps import store_scan
from test_suite.conftest import (
    MOCK_CATEGORY_MAP,
    MOCK_MODEL_TYPE_TESTS,
    MOCK_REGISTRY,
)


class TestFullScanLifecycle:
    """End-to-end: create scan → poll → results → report."""

    @pytest.fixture(autouse=True)
    def use_mock_registry(self):
        with patch("tessera.registry.TEST_REGISTRY", MOCK_REGISTRY), \
             patch("tessera.registry.CATEGORY_MAP", MOCK_CATEGORY_MAP), \
             patch("tessera.registry.MODEL_TYPE_TESTS", MOCK_MODEL_TYPE_TESTS):
            yield

    def test_create_poll_complete(self, api_client, sample_config_yaml):
        """Create scan → poll → verify completion."""
        resp = api_client.post("/api/v1/scans", json={
            "test_ids": ["MOCK-01"],
            "config_path": sample_config_yaml,
        })
        assert resp.status_code == 200
        scan_id = resp.json()["scan_id"]

        # Poll until complete (max 10s)
        for _ in range(100):
            time.sleep(0.1)
            resp = api_client.get(f"/api/v1/scans/{scan_id}")
            if resp.json().get("status") in ("completed", "failed"):
                break

        scan = api_client.get(f"/api/v1/scans/{scan_id}").json()
        assert scan["status"] in ("completed", "failed")

    def test_results_available_after_scan(self, api_client, sample_config_yaml):
        """After a scan completes, results should be queryable."""
        resp = api_client.post("/api/v1/scans", json={
            "test_ids": ["MOCK-01"],
            "config_path": sample_config_yaml,
        })
        scan_id = resp.json()["scan_id"]

        # Wait for completion
        for _ in range(100):
            time.sleep(0.1)
            scan = api_client.get(f"/api/v1/scans/{scan_id}").json()
            if scan.get("status") in ("completed", "failed"):
                break

        if scan.get("status") == "completed":
            # Query results
            resp = api_client.get("/api/v1/results", params={"scan_id": scan_id})
            assert resp.status_code == 200

    def test_json_report_after_scan(self, api_client, sample_config_yaml):
        """After a scan completes, JSON report should be downloadable."""
        resp = api_client.post("/api/v1/scans", json={
            "test_ids": ["MOCK-01"],
            "config_path": sample_config_yaml,
        })
        scan_id = resp.json()["scan_id"]

        # Wait for completion
        for _ in range(100):
            time.sleep(0.1)
            scan = api_client.get(f"/api/v1/scans/{scan_id}").json()
            if scan.get("status") in ("completed", "failed"):
                break

        if scan.get("status") == "completed":
            resp = api_client.get(f"/api/v1/reports/{scan_id}", params={"format": "json"})
            assert resp.status_code == 200


class TestMultiScanComparison:
    """End-to-end: run two scans → compare for regressions."""

    def test_compare_two_scans(self, api_client):
        """Create two scans with different results and compare."""
        store_scan({
            "scan_id": "e2e-scan-1",
            "status": "completed",
            "result": {
                "tests": [
                    {"test_id": "MOCK-01", "status": "PASS"},
                    {"test_id": "MOCK-02", "status": "PASS"},
                ],
            },
        })
        store_scan({
            "scan_id": "e2e-scan-2",
            "status": "completed",
            "result": {
                "tests": [
                    {"test_id": "MOCK-01", "status": "PASS"},
                    {"test_id": "MOCK-02", "status": "FAIL"},
                ],
            },
        })

        resp = api_client.get("/api/v1/results/compare", params={
            "scan_a": "e2e-scan-1",
            "scan_b": "e2e-scan-2",
        })
        assert resp.status_code == 200
        data = resp.json()
        assert data["regressions"] == 1
        assert data["improvements"] == 0


class TestModelRegistryWorkflow:
    """End-to-end: register models → list → query → delete."""

    def test_full_model_lifecycle(self, api_client):
        # Create
        resp = api_client.post("/api/v1/models", json={
            "name": "e2e-model",
            "arch": "transformer",
            "model_type": "llm",
            "server_type": "vllm",
            "url": "http://localhost:8000",
        })
        assert resp.status_code == 200
        model_id = resp.json()["id"]

        # Read
        resp = api_client.get(f"/api/v1/models/{model_id}")
        assert resp.status_code == 200
        assert resp.json()["name"] == "e2e-model"

        # List
        resp = api_client.get("/api/v1/models")
        assert len(resp.json()["models"]) >= 1

        # Delete
        resp = api_client.delete(f"/api/v1/models/{model_id}")
        assert resp.json()["deleted"] is True

        # Verify gone
        resp = api_client.get(f"/api/v1/models/{model_id}")
        assert resp.status_code == 404


class TestConfigWorkflow:
    """End-to-end: save config → list → retrieve."""

    def test_full_config_lifecycle(self, api_client):
        # Save
        resp = api_client.post("/api/v1/config/saved", json={
            "name": "production-scan",
            "config": {
                "project": {"name": "Prod"},
                "models": {"vllm": {"url": "prod-server:8000"}},
            },
        })
        assert resp.status_code == 200
        config_id = resp.json()["id"]

        # List
        resp = api_client.get("/api/v1/config/saved")
        assert len(resp.json()["configs"]) >= 1

        # Retrieve
        resp = api_client.get(f"/api/v1/config/saved/{config_id}")
        assert resp.status_code == 200
        assert resp.json()["name"] == "production-scan"

    def test_test_catalog_available(self, api_client):
        resp = api_client.get("/api/v1/config/tests")
        assert resp.status_code == 200
        data = resp.json()
        assert len(data["tests"]) == 32
        assert "categories" in data
        assert "model_type_tests" in data


class TestHealthWorkflow:
    """End-to-end: verify system health endpoints."""

    def test_health_and_ready(self, api_client):
        health = api_client.get("/health").json()
        assert health["status"] == "ok"

        ready = api_client.get("/ready").json()
        assert ready["status"] in ("ready", "degraded")
        assert ready["checks"]["api"] is True

    def test_openapi_spec(self, api_client):
        resp = api_client.get("/openapi.json")
        spec = resp.json()
        paths = spec["paths"]

        # Verify key endpoints exist in the OpenAPI spec
        assert "/health" in paths
        assert "/ready" in paths
        assert "/api/v1/scans" in paths
        assert "/api/v1/models" in paths
        assert "/api/v1/results" in paths
        assert "/api/v1/results/compare" in paths


class TestComplianceE2E:
    """End-to-end: run compliance report from scan results."""

    def test_compliance_from_scan_data(self):
        """Generate all 4 compliance reports from realistic scan data."""
        from tessera.enterprise.compliance import eu_ai_act, iso27001, nist_ai_rmf, soc2

        scan_results = [
            {"test_id": "MOD-01", "test_name": "Evasion", "status": "PASS"},
            {"test_id": "MOD-02", "test_name": "Poisoning", "status": "FAIL"},
            {"test_id": "MOD-03", "test_name": "Training Data", "status": "PASS"},
            {"test_id": "MOD-06", "test_name": "Drift", "status": "WARN"},
            {"test_id": "APP-01", "test_name": "Injection", "status": "FAIL"},
            {"test_id": "APP-03", "test_name": "Disclosure", "status": "PASS"},
            {"test_id": "APP-10", "test_name": "Bias", "status": "PASS"},
            {"test_id": "INF-01", "test_name": "Supply Chain", "status": "PASS"},
            {"test_id": "INF-03", "test_name": "API Security", "status": "PASS"},
            {"test_id": "DAT-01", "test_name": "Consent", "status": "PASS"},
            {"test_id": "DAT-02", "test_name": "PII Leakage", "status": "FAIL"},
            {"test_id": "DAT-03", "test_name": "Lineage", "status": "PASS"},
        ]

        eu = eu_ai_act.get_compliance_report(scan_results)
        assert eu["framework"] == "EU AI Act (Regulation 2024/1689)"
        assert eu["total_requirements"] > 0
        assert 0 < eu["compliance_score"] < 100

        nist = nist_ai_rmf.get_compliance_report(scan_results)
        assert nist["framework"] == "NIST AI RMF 1.0"
        assert "by_function" in nist

        soc = soc2.get_compliance_report(scan_results)
        assert soc["framework"] == "SOC 2 Type II"

        iso = iso27001.get_compliance_report(scan_results)
        assert iso["framework"] == "ISO 27001:2022"

        # All frameworks should report some gaps
        assert eu["non_compliant"] > 0
        assert nist["gaps"] > 0
        assert soc["gaps"] > 0
        assert iso["gaps"] > 0
