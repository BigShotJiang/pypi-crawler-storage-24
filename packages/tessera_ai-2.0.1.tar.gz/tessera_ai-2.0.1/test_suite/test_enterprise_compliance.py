"""
Tests for all 4 compliance framework mappings.
"""


from tessera.enterprise.compliance import eu_ai_act, iso27001, nist_ai_rmf, soc2

SAMPLE_RESULTS_PASS = [
    {"test_id": "MOD-01", "test_name": "Evasion", "status": "PASS"},
    {"test_id": "MOD-02", "test_name": "Poisoning", "status": "PASS"},
    {"test_id": "MOD-03", "test_name": "Training Data", "status": "PASS"},
    {"test_id": "APP-01", "test_name": "Injection", "status": "PASS"},
    {"test_id": "APP-03", "test_name": "Disclosure", "status": "PASS"},
    {"test_id": "INF-01", "test_name": "Supply Chain", "status": "PASS"},
    {"test_id": "INF-03", "test_name": "API Security", "status": "PASS"},
    {"test_id": "DAT-01", "test_name": "Consent", "status": "PASS"},
    {"test_id": "DAT-02", "test_name": "PII Leakage", "status": "PASS"},
    {"test_id": "DAT-03", "test_name": "Data Lineage", "status": "PASS"},
]

SAMPLE_RESULTS_MIXED = [
    {"test_id": "MOD-01", "test_name": "Evasion", "status": "PASS"},
    {"test_id": "MOD-02", "test_name": "Poisoning", "status": "FAIL"},
    {"test_id": "APP-01", "test_name": "Injection", "status": "FAIL"},
    {"test_id": "INF-01", "test_name": "Supply Chain", "status": "WARN"},
    {"test_id": "DAT-02", "test_name": "PII Leakage", "status": "PASS"},
]


class TestEUAIAct:
    def test_mapping_exists(self):
        assert len(eu_ai_act.EU_AI_ACT_MAPPING) == 12

    def test_all_pass_full_compliance(self):
        report = eu_ai_act.get_compliance_report(SAMPLE_RESULTS_PASS)
        assert report["framework"] == "EU AI Act (Regulation 2024/1689)"
        assert report["non_compliant"] == 0
        assert report["compliance_score"] == 100.0

    def test_mixed_results(self):
        report = eu_ai_act.get_compliance_report(SAMPLE_RESULTS_MIXED)
        assert report["non_compliant"] > 0
        assert report["compliance_score"] < 100

    def test_findings_structure(self):
        report = eu_ai_act.get_compliance_report(SAMPLE_RESULTS_PASS)
        for f in report["findings"]:
            assert "test_id" in f
            assert "article" in f
            assert "requirement" in f
            assert "risk_level" in f
            assert "compliant" in f

    def test_unmapped_tests_ignored(self):
        report = eu_ai_act.get_compliance_report([
            {"test_id": "UNKNOWN-99", "status": "PASS"},
        ])
        assert report["total_requirements"] == 0

    def test_na_status_counts_as_compliant(self):
        report = eu_ai_act.get_compliance_report([
            {"test_id": "MOD-01", "test_name": "Evasion", "status": "N/A"},
        ])
        assert report["findings"][0]["compliant"] is True


class TestNISTAIRMF:
    def test_mapping_exists(self):
        assert len(nist_ai_rmf.NIST_AI_RMF_MAPPING) == 13

    def test_all_pass(self):
        report = nist_ai_rmf.get_compliance_report(SAMPLE_RESULTS_PASS)
        assert report["framework"] == "NIST AI RMF 1.0"
        assert report["gaps"] == 0
        assert report["score"] == 100.0

    def test_by_function_breakdown(self):
        report = nist_ai_rmf.get_compliance_report(SAMPLE_RESULTS_PASS)
        assert "by_function" in report
        # NIST AI RMF has GOVERN, MAP, MEASURE, MANAGE functions
        functions = set(report["by_function"].keys())
        assert len(functions) > 0

    def test_mixed_results(self):
        report = nist_ai_rmf.get_compliance_report(SAMPLE_RESULTS_MIXED)
        assert report["gaps"] > 0

    def test_findings_structure(self):
        report = nist_ai_rmf.get_compliance_report(SAMPLE_RESULTS_PASS)
        for f in report["findings"]:
            assert "function" in f
            assert "category" in f
            assert "subcategory" in f
            assert "addressed" in f


class TestSOC2:
    def test_mapping_exists(self):
        assert len(soc2.SOC2_MAPPING) == 12

    def test_all_pass(self):
        report = soc2.get_compliance_report(SAMPLE_RESULTS_PASS)
        assert report["framework"] == "SOC 2 Type II"
        assert report["gaps"] == 0
        assert report["score"] == 100.0

    def test_findings_structure(self):
        report = soc2.get_compliance_report(SAMPLE_RESULTS_PASS)
        for f in report["findings"]:
            assert "criteria" in f
            assert "principle" in f
            assert "description" in f
            assert "met" in f

    def test_mixed_results(self):
        report = soc2.get_compliance_report(SAMPLE_RESULTS_MIXED)
        assert report["gaps"] > 0


class TestISO27001:
    def test_mapping_exists(self):
        assert len(iso27001.ISO27001_MAPPING) == 12

    def test_all_pass(self):
        report = iso27001.get_compliance_report(SAMPLE_RESULTS_PASS)
        assert report["framework"] == "ISO 27001:2022"
        assert report["gaps"] == 0
        assert report["score"] == 100.0

    def test_findings_structure(self):
        report = iso27001.get_compliance_report(SAMPLE_RESULTS_PASS)
        for f in report["findings"]:
            assert "control" in f
            assert "title" in f
            assert "description" in f
            assert "implemented" in f

    def test_mixed_results(self):
        report = iso27001.get_compliance_report(SAMPLE_RESULTS_MIXED)
        assert report["gaps"] > 0


class TestComplianceCrossFramework:
    """Cross-cutting tests across all compliance frameworks."""

    def test_empty_results_all_frameworks(self):
        for framework in [eu_ai_act, nist_ai_rmf, soc2, iso27001]:
            report = framework.get_compliance_report([])
            assert report["findings"] == []

    def test_consistent_scoring_all_pass(self):
        for framework in [eu_ai_act, nist_ai_rmf, soc2, iso27001]:
            report = framework.get_compliance_report(SAMPLE_RESULTS_PASS)
            assert report["score" if "score" in report else "compliance_score"] == 100.0

    def test_fail_not_compliant(self):
        fail_result = [{"test_id": "MOD-01", "test_name": "Evasion", "status": "FAIL"}]
        for framework in [eu_ai_act, nist_ai_rmf, soc2, iso27001]:
            report = framework.get_compliance_report(fail_result)
            if report["findings"]:
                finding = report["findings"][0]
                compliance_key = next(
                    k for k in ("compliant", "addressed", "met", "implemented")
                    if k in finding
                )
                assert finding[compliance_key] is False
