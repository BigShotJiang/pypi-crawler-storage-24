"""
Tests for the config management API endpoints.
"""


from tessera.registry import CATEGORY_MAP, TEST_REGISTRY


class TestTestCatalog:
    def test_get_test_catalog(self, api_client):
        resp = api_client.get("/api/v1/config/tests")
        assert resp.status_code == 200
        data = resp.json()
        assert "tests" in data
        assert "categories" in data
        assert "model_type_tests" in data

    def test_catalog_has_all_tests(self, api_client):
        resp = api_client.get("/api/v1/config/tests")
        tests = resp.json()["tests"]
        assert len(tests) == len(TEST_REGISTRY)

    def test_catalog_test_structure(self, api_client):
        resp = api_client.get("/api/v1/config/tests")
        tests = resp.json()["tests"]
        for tid, name in tests.items():
            assert isinstance(name, str)
            assert len(name) > 0

    def test_catalog_categories(self, api_client):
        resp = api_client.get("/api/v1/config/tests")
        categories = resp.json()["categories"]
        assert set(categories.keys()) == set(CATEGORY_MAP.keys())

    def test_catalog_model_types(self, api_client):
        resp = api_client.get("/api/v1/config/tests")
        model_types = resp.json()["model_type_tests"]
        assert "cv" in model_types
        assert "llm" in model_types


class TestSavedConfigs:
    def test_create_config(self, api_client):
        resp = api_client.post("/api/v1/config/saved", json={
            "name": "my-config",
            "config": {"project": {"name": "Test"}},
            "is_default": False,
        })
        assert resp.status_code == 200
        data = resp.json()
        assert data["name"] == "my-config"
        assert "id" in data

    def test_list_configs_empty(self, api_client):
        resp = api_client.get("/api/v1/config/saved")
        assert resp.status_code == 200
        assert resp.json()["configs"] == []

    def test_list_configs_after_create(self, api_client):
        api_client.post("/api/v1/config/saved", json={"name": "config-1", "config": {}})
        api_client.post("/api/v1/config/saved", json={"name": "config-2", "config": {}})

        resp = api_client.get("/api/v1/config/saved")
        assert len(resp.json()["configs"]) == 2

    def test_get_saved_config(self, api_client):
        create_resp = api_client.post("/api/v1/config/saved", json={
            "name": "retrievable",
            "config": {"key": "value"},
        })
        config_id = create_resp.json()["id"]

        resp = api_client.get(f"/api/v1/config/saved/{config_id}")
        assert resp.status_code == 200
        assert resp.json()["name"] == "retrievable"

    def test_get_config_not_found(self, api_client):
        resp = api_client.get("/api/v1/config/saved/nonexistent-id")
        assert resp.status_code == 404
