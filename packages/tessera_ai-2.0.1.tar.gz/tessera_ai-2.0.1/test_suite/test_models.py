"""
Tests for tessera/models.py — Pydantic schema validation.
"""


from tessera.models import (
    MetricResult,
    ModelConfig,
    ModelType,
    PhaseResultSchema,
    ScanProgress,
    ScanRequest,
    ScanResult,
    ScanStatus,
    ScanSummary,
    TestResultSchema,
    TestStatus,
)


class TestScanStatus:
    def test_all_statuses(self):
        assert ScanStatus.PENDING == "pending"
        assert ScanStatus.RUNNING == "running"
        assert ScanStatus.COMPLETED == "completed"
        assert ScanStatus.FAILED == "failed"
        assert ScanStatus.CANCELLED == "cancelled"


class TestTestStatus:
    def test_all_statuses(self):
        assert TestStatus.PASS == "PASS"
        assert TestStatus.FAIL == "FAIL"
        assert TestStatus.WARN == "WARN"
        assert TestStatus.ERROR == "ERROR"
        assert TestStatus.NA == "N/A"
        assert TestStatus.NOT_RUN == "NOT_RUN"


class TestModelConfig:
    def test_minimal(self):
        m = ModelConfig(name="my-model")
        assert m.name == "my-model"
        assert m.model_type == ModelType.CV
        assert m.server_type == ""

    def test_full(self):
        m = ModelConfig(
            name="llama3",
            arch="llama3-8b",
            model_type=ModelType.LLM,
            server_type="vllm",
            url="http://localhost:8000",
            task="chat",
            config={"param": "value"},
        )
        assert m.model_type == ModelType.LLM
        assert m.config["param"] == "value"


class TestScanRequest:
    def test_defaults(self):
        r = ScanRequest()
        assert r.test_ids == []
        assert r.phases == [1, 2, 3]
        assert r.config_path == "config.yaml"
        assert r.per_model is False
        assert r.formats == ["json"]

    def test_custom(self):
        r = ScanRequest(
            test_ids=["MOD-01", "MOD-02"],
            category="mod",
            phases=[1],
            per_model=True,
            model_filter=["resnet"],
            model_type_filter="cv",
        )
        assert len(r.test_ids) == 2
        assert r.per_model is True
        assert r.model_type_filter == "cv"

    def test_config_override(self):
        r = ScanRequest(config_override={"project": {"name": "custom"}})
        assert r.config_override["project"]["name"] == "custom"


class TestMetricResult:
    def test_creation(self):
        m = MetricResult(name="accuracy", value=0.95)
        assert m.name == "accuracy"
        assert m.value == 0.95
        assert m.operator == "<"

    def test_all_fields(self):
        m = MetricResult(
            name="rate",
            value=0.05,
            threshold_pass=0.1,
            threshold_fail=0.5,
            unit="%",
            operator=">",
            source="OWASP",
            status="PASS",
        )
        assert m.unit == "%"
        assert m.status == "PASS"


class TestPhaseResultSchema:
    def test_defaults(self):
        p = PhaseResultSchema(phase=1, name="Attack")
        assert p.status == "NOT_RUN"
        assert p.metrics == []
        assert p.error == ""


class TestTestResultSchema:
    def test_full_construction(self):
        t = TestResultSchema(
            test_id="MOD-01",
            test_name="Evasion",
            category="MOD",
            owasp_ref="AITG-MOD-01",
            status="PASS",
            model_name="resnet",
            model_type="cv",
        )
        assert t.test_id == "MOD-01"
        assert t.model_name == "resnet"


class TestScanSummary:
    def test_alias_pass(self):
        s = ScanSummary(total=10, fail=2, warn=1, error=0, na=0)
        assert s.total == 10
        assert s.fail == 2

    def test_from_dict_with_alias(self):
        s = ScanSummary.model_validate({"total": 5, "pass": 3, "fail": 2})
        assert s.passed == 3


class TestScanResult:
    def test_defaults(self):
        r = ScanResult()
        assert r.framework == "Tessera"
        assert r.version == "2.0.0"
        assert r.status == ScanStatus.COMPLETED
        assert r.mode == "flat"

    def test_per_model_mode(self):
        r = ScanResult(
            mode="per-model",
            models_tested=5,
            models_total=10,
            matrix={"model1": {"MOD-01": "PASS"}},
        )
        assert r.mode == "per-model"
        assert r.models_tested == 5


class TestScanProgress:
    def test_creation(self):
        p = ScanProgress(
            scan_id="abc-123",
            status=ScanStatus.RUNNING,
            current_test="MOD-01",
            tests_completed=3,
            tests_total=10,
            message="Running...",
        )
        assert p.scan_id == "abc-123"
        assert p.tests_completed == 3
