"""
Tests for enterprise features: scheduling, branding, multi-tenant.
"""


import pytest


class TestScheduling:
    @pytest.fixture(autouse=True)
    def reset_schedules(self):
        from tessera.enterprise.scheduling.scheduler import _schedules
        _schedules.clear()
        yield
        _schedules.clear()

    def test_create_schedule(self):
        from tessera.enterprise.scheduling.scheduler import create_schedule

        schedule = create_schedule(name="nightly", cron="0 2 * * *")
        assert schedule.name == "nightly"
        assert schedule.cron_expression == "0 2 * * *"
        assert schedule.enabled is True
        assert schedule.id  # UUID generated

    def test_list_schedules(self):
        from tessera.enterprise.scheduling.scheduler import (
            create_schedule,
            list_schedules,
        )

        create_schedule(name="weekly", cron="0 2 * * 1")
        create_schedule(name="daily", cron="0 0 * * *")

        schedules = list_schedules()
        assert len(schedules) == 2

    def test_list_schedules_by_org(self):
        from tessera.enterprise.scheduling.scheduler import (
            create_schedule,
            list_schedules,
        )

        create_schedule(name="org1-scan", cron="0 2 * * *", org_id="org-1")
        create_schedule(name="org2-scan", cron="0 2 * * *", org_id="org-2")

        org1 = list_schedules(org_id="org-1")
        assert len(org1) == 1
        assert org1[0].name == "org1-scan"

    def test_delete_schedule(self):
        from tessera.enterprise.scheduling.scheduler import (
            create_schedule,
            delete_schedule,
            list_schedules,
        )

        schedule = create_schedule(name="temp", cron="0 0 * * *")
        assert delete_schedule(schedule.id) is True
        assert len(list_schedules()) == 0

    def test_delete_nonexistent(self):
        from tessera.enterprise.scheduling.scheduler import delete_schedule

        assert delete_schedule("fake-id") is False

    def test_schedule_defaults(self):
        from tessera.enterprise.scheduling.scheduler import ScheduledScan

        s = ScheduledScan()
        assert s.cron_expression == "0 2 * * 1"
        assert s.config_path == "config.yaml"
        assert s.category == "all"
        assert s.per_model is False
        assert s.formats == ["json", "html"]


class TestBranding:
    def test_default_brand(self):
        from tessera.enterprise.branding.white_label import get_brand_config

        config = get_brand_config()
        assert config.company_name == "Tessera"
        assert config.primary_color == "#0693e3"
        assert config.secondary_color == "#9b51e0"

    def test_custom_brand_from_env(self, monkeypatch):
        monkeypatch.setenv("TESSERA_BRAND_NAME", "ACME Corp")
        monkeypatch.setenv("TESSERA_BRAND_PRIMARY", "#ff0000")
        monkeypatch.setenv("TESSERA_BRAND_LOGO", "/opt/logo.png")

        from tessera.enterprise.branding.white_label import get_brand_config

        config = get_brand_config()
        assert config.company_name == "ACME Corp"
        assert config.primary_color == "#ff0000"
        assert config.logo_path == "/opt/logo.png"

    def test_brand_config_dataclass(self):
        from tessera.enterprise.branding.white_label import BrandConfig

        config = BrandConfig(
            company_name="Custom",
            primary_color="#000",
            footer_text="Custom footer",
        )
        assert config.company_name == "Custom"
        assert config.footer_text == "Custom footer"


class TestMultiTenant:
    def test_context_var_default(self):
        from tessera.enterprise.multi_tenant.middleware import get_current_org_id

        assert get_current_org_id() is None

    def test_context_var_set_and_reset(self):
        from tessera.enterprise.multi_tenant.middleware import (
            current_org_id,
            get_current_org_id,
        )

        token = current_org_id.set("org-123")
        assert get_current_org_id() == "org-123"
        current_org_id.reset(token)
        assert get_current_org_id() is None


class TestAuditLogger:
    def test_log_action_no_db(self):
        """Without DB configured, log_action should silently succeed."""
        from tessera.enterprise.audit.logger import log_action

        # Should not raise even without DB
        log_action("test.action", user_id="user-1", resource_type="scan")

    def test_get_audit_logs_no_db(self):
        """Without DB, get_audit_logs returns empty list."""
        from tessera.enterprise.audit.logger import get_audit_logs

        logs = get_audit_logs()
        assert logs == []
