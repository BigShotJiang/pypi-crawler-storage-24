"""
Tests for tessera/enterprise/license.py — JWT-based license validation.
"""

from datetime import datetime, timedelta, timezone

import pytest


class TestLicenseValidation:
    """Tests for the enterprise license system."""

    @pytest.fixture(autouse=True)
    def reset_cache(self):
        """Clear license cache between tests."""
        import tessera.enterprise.license as lic
        lic._LICENSE_CACHE = None
        yield
        lic._LICENSE_CACHE = None

    def _create_license_token(self, tier="pro", exp_hours=24, **extra):
        """Helper to create a valid license JWT."""
        from jose import jwt

        payload = {
            "tier": tier,
            "org": "test-org",
            "exp": datetime.now(timezone.utc) + timedelta(hours=exp_hours),
            "iat": datetime.now(timezone.utc),
            **extra,
        }
        return jwt.encode(payload, "tessera-dev-key", algorithm="HS256")

    def test_no_license(self, monkeypatch):
        monkeypatch.delenv("TESSERA_LICENSE_KEY", raising=False)
        from tessera.enterprise.license import (
            get_license,
            get_license_tier,
            is_enterprise_licensed,
        )

        assert get_license() is None
        assert get_license_tier() == "community"
        assert is_enterprise_licensed() is False

    def test_valid_pro_license(self, monkeypatch):
        token = self._create_license_token("pro")
        monkeypatch.setenv("TESSERA_LICENSE_KEY", token)
        from tessera.enterprise.license import (
            get_license,
            get_license_tier,
            is_enterprise_licensed,
        )

        assert get_license() is not None
        assert get_license_tier() == "pro"
        assert is_enterprise_licensed() is True

    def test_valid_enterprise_license(self, monkeypatch):
        token = self._create_license_token("enterprise")
        monkeypatch.setenv("TESSERA_LICENSE_KEY", token)
        from tessera.enterprise.license import get_license_tier, is_enterprise_licensed

        assert get_license_tier() == "enterprise"
        assert is_enterprise_licensed() is True

    def test_community_tier_not_enterprise(self, monkeypatch):
        token = self._create_license_token("community")
        monkeypatch.setenv("TESSERA_LICENSE_KEY", token)
        from tessera.enterprise.license import is_enterprise_licensed

        assert is_enterprise_licensed() is False

    def test_expired_license(self, monkeypatch):
        token = self._create_license_token("pro", exp_hours=-1)
        monkeypatch.setenv("TESSERA_LICENSE_KEY", token)
        from tessera.enterprise.license import get_license

        assert get_license() is None

    def test_invalid_token(self, monkeypatch):
        monkeypatch.setenv("TESSERA_LICENSE_KEY", "garbage-token-value")
        from tessera.enterprise.license import get_license

        assert get_license() is None

    def test_require_tier_pro(self, monkeypatch):
        token = self._create_license_token("pro")
        monkeypatch.setenv("TESSERA_LICENSE_KEY", token)
        from tessera.enterprise.license import require_tier

        assert require_tier("community") is True
        assert require_tier("pro") is True
        assert require_tier("enterprise") is False

    def test_require_tier_enterprise(self, monkeypatch):
        token = self._create_license_token("enterprise")
        monkeypatch.setenv("TESSERA_LICENSE_KEY", token)
        from tessera.enterprise.license import require_tier

        assert require_tier("community") is True
        assert require_tier("pro") is True
        assert require_tier("enterprise") is True

    def test_model_limit_community(self, monkeypatch):
        monkeypatch.delenv("TESSERA_LICENSE_KEY", raising=False)
        from tessera.enterprise.license import get_model_limit

        assert get_model_limit() == 10

    def test_model_limit_pro(self, monkeypatch):
        token = self._create_license_token("pro")
        monkeypatch.setenv("TESSERA_LICENSE_KEY", token)
        from tessera.enterprise.license import get_model_limit

        assert get_model_limit() == 100

    def test_model_limit_custom(self, monkeypatch):
        token = self._create_license_token("enterprise", max_models=500)
        monkeypatch.setenv("TESSERA_LICENSE_KEY", token)
        from tessera.enterprise.license import get_model_limit

        assert get_model_limit() == 500

    def test_license_caching(self, monkeypatch):
        token = self._create_license_token("pro")
        monkeypatch.setenv("TESSERA_LICENSE_KEY", token)
        from tessera.enterprise.license import get_license

        first = get_license()
        second = get_license()
        assert first is second  # Same cached object
