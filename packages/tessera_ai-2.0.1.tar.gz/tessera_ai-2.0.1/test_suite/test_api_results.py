"""
Tests for the results query and comparison API endpoints.
"""


from tessera.api.deps import store_scan


class TestResultsQuery:
    def _create_scan_with_results(self, api_client, scan_id="scan-1", tests=None):
        """Helper: inject a completed scan directly into the in-memory store."""
        if tests is None:
            tests = [
                {"test_id": "MOD-01", "status": "PASS", "test_name": "Evasion", "model_name": "model-a"},
                {"test_id": "MOD-02", "status": "FAIL", "test_name": "Poisoning", "model_name": "model-a"},
                {"test_id": "APP-01", "status": "WARN", "test_name": "Injection", "model_name": "model-b"},
            ]
        store_scan({
            "scan_id": scan_id,
            "status": "completed",
            "result": {"tests": tests},
        })

    def test_query_all_results_for_scan(self, api_client):
        self._create_scan_with_results(api_client, "s1")
        resp = api_client.get("/api/v1/results", params={"scan_id": "s1"})
        assert resp.status_code == 200
        assert resp.json()["total"] == 3

    def test_filter_by_test_id(self, api_client):
        self._create_scan_with_results(api_client, "s2")
        resp = api_client.get("/api/v1/results", params={"scan_id": "s2", "test_id": "MOD-01"})
        assert resp.status_code == 200
        results = resp.json()["results"]
        assert len(results) == 1
        assert results[0]["test_id"] == "MOD-01"

    def test_filter_by_status(self, api_client):
        self._create_scan_with_results(api_client, "s3")
        resp = api_client.get("/api/v1/results", params={"scan_id": "s3", "status": "FAIL"})
        results = resp.json()["results"]
        assert len(results) == 1
        assert results[0]["status"] == "FAIL"

    def test_filter_by_model_name(self, api_client):
        self._create_scan_with_results(api_client, "s4")
        resp = api_client.get("/api/v1/results", params={"scan_id": "s4", "model_name": "model-b"})
        results = resp.json()["results"]
        assert len(results) == 1
        assert results[0]["model_name"] == "model-b"

    def test_pagination(self, api_client):
        self._create_scan_with_results(api_client, "s5")
        resp = api_client.get("/api/v1/results", params={"scan_id": "s5", "skip": 1, "limit": 1})
        assert resp.json()["total"] == 3
        assert len(resp.json()["results"]) == 1

    def test_scan_not_found(self, api_client):
        resp = api_client.get("/api/v1/results", params={"scan_id": "nonexistent"})
        assert resp.status_code == 404

    def test_query_across_all_scans(self, api_client):
        self._create_scan_with_results(api_client, "s6", [
            {"test_id": "MOD-01", "status": "PASS"},
        ])
        self._create_scan_with_results(api_client, "s7", [
            {"test_id": "MOD-01", "status": "FAIL"},
        ])
        resp = api_client.get("/api/v1/results", params={"test_id": "MOD-01"})
        assert resp.json()["total"] == 2


class TestResultsComparison:
    def _create_scans(self, api_client):
        store_scan({
            "scan_id": "scan-a",
            "status": "completed",
            "result": {
                "tests": [
                    {"test_id": "MOD-01", "status": "PASS"},
                    {"test_id": "MOD-02", "status": "PASS"},
                    {"test_id": "APP-01", "status": "WARN"},
                ],
            },
        })
        store_scan({
            "scan_id": "scan-b",
            "status": "completed",
            "result": {
                "tests": [
                    {"test_id": "MOD-01", "status": "PASS"},
                    {"test_id": "MOD-02", "status": "FAIL"},  # regression
                    {"test_id": "APP-01", "status": "PASS"},  # improvement
                ],
            },
        })

    def test_compare_basic(self, api_client):
        self._create_scans(api_client)
        resp = api_client.get("/api/v1/results/compare", params={
            "scan_a": "scan-a",
            "scan_b": "scan-b",
        })
        assert resp.status_code == 200
        data = resp.json()
        assert data["regressions"] == 1
        assert data["improvements"] == 1

    def test_compare_details(self, api_client):
        self._create_scans(api_client)
        resp = api_client.get("/api/v1/results/compare", params={
            "scan_a": "scan-a",
            "scan_b": "scan-b",
        })
        comparison = resp.json()["comparison"]
        mod02 = next(c for c in comparison if c["test_id"] == "MOD-02")
        assert mod02["change"] == "regression"
        assert mod02["scan_a_status"] == "PASS"
        assert mod02["scan_b_status"] == "FAIL"

        app01 = next(c for c in comparison if c["test_id"] == "APP-01")
        assert app01["change"] == "improvement"

    def test_compare_unchanged(self, api_client):
        self._create_scans(api_client)
        resp = api_client.get("/api/v1/results/compare", params={
            "scan_a": "scan-a",
            "scan_b": "scan-b",
        })
        comparison = resp.json()["comparison"]
        mod01 = next(c for c in comparison if c["test_id"] == "MOD-01")
        assert mod01["change"] == "unchanged"

    def test_compare_scan_not_found(self, api_client):
        resp = api_client.get("/api/v1/results/compare", params={
            "scan_a": "missing-a",
            "scan_b": "missing-b",
        })
        assert resp.status_code == 404
