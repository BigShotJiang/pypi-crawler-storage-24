"""
Tests for tessera/enterprise/auth/ — JWT, RBAC.
"""

from datetime import datetime, timedelta, timezone

import pytest
from fastapi import HTTPException


class TestJWT:
    def test_create_and_decode_token(self):
        from tessera.enterprise.auth.jwt import create_access_token, decode_token

        token = create_access_token(
            user_id="user-1",
            email="test@example.com",
            role="admin",
            org_id="org-1",
        )
        payload = decode_token(token)
        assert payload["sub"] == "user-1"
        assert payload["email"] == "test@example.com"
        assert payload["role"] == "admin"
        assert payload["org_id"] == "org-1"

    def test_token_has_expiry(self):
        from tessera.enterprise.auth.jwt import create_access_token, decode_token

        token = create_access_token("u1", "e@x.com", "viewer")
        payload = decode_token(token)
        assert "exp" in payload
        assert "iat" in payload

    def test_invalid_token_raises(self):
        from tessera.enterprise.auth.jwt import decode_token

        with pytest.raises(HTTPException) as exc_info:
            decode_token("invalid-token-garbage")
        assert exc_info.value.status_code == 401

    def test_expired_token_raises(self):
        from jose import jwt

        from tessera.enterprise.auth.jwt import ALGORITHM, SECRET_KEY, decode_token

        payload = {
            "sub": "user-1",
            "email": "test@example.com",
            "role": "admin",
            "exp": datetime.now(timezone.utc) - timedelta(hours=1),
        }
        expired_token = jwt.encode(payload, SECRET_KEY, algorithm=ALGORITHM)
        with pytest.raises(HTTPException) as exc_info:
            decode_token(expired_token)
        assert exc_info.value.status_code == 401

    def test_token_all_roles(self):
        from tessera.enterprise.auth.jwt import create_access_token, decode_token

        for role in ["admin", "analyst", "viewer"]:
            token = create_access_token("u1", "e@x.com", role)
            payload = decode_token(token)
            assert payload["role"] == role


class TestRBAC:
    def test_admin_has_all_permissions(self):
        from tessera.enterprise.auth.rbac import PERMISSIONS, has_permission

        admin_perms = PERMISSIONS["admin"]
        for perm in admin_perms:
            assert has_permission("admin", perm) is True

    def test_viewer_limited(self):
        from tessera.enterprise.auth.rbac import has_permission

        assert has_permission("viewer", "scans.read") is True
        assert has_permission("viewer", "scans.create") is False
        assert has_permission("viewer", "scans.delete") is False

    def test_analyst_can_create(self):
        from tessera.enterprise.auth.rbac import has_permission

        assert has_permission("analyst", "scans.create") is True
        assert has_permission("analyst", "models.create") is True
        assert has_permission("analyst", "scans.delete") is False

    def test_unknown_role(self):
        from tessera.enterprise.auth.rbac import get_permissions, has_permission

        assert has_permission("unknown", "scans.read") is False
        assert get_permissions("unknown") == set()

    def test_get_permissions_returns_set(self):
        from tessera.enterprise.auth.rbac import get_permissions

        perms = get_permissions("admin")
        assert isinstance(perms, set)
        assert "scans.create" in perms
        assert "users.delete" in perms

    def test_permissions_hierarchy(self):
        """Admin should have all analyst permissions, analyst should have all viewer permissions."""
        from tessera.enterprise.auth.rbac import PERMISSIONS

        viewer = PERMISSIONS["viewer"]
        analyst = PERMISSIONS["analyst"]
        admin = PERMISSIONS["admin"]

        assert viewer.issubset(analyst)
        assert analyst.issubset(admin)
