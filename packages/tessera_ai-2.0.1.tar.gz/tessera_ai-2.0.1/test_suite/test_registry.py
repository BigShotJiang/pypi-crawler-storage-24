"""
Tests for tessera/registry.py — test registry, categories, model-type mappings.
"""

import pytest

from tessera.registry import (
    CATEGORY_MAP,
    MODEL_TYPE_TESTS,
    TEST_REGISTRY,
    get_test_ids,
    load_test_class,
)


class TestRegistry:
    """Test the central test registry."""

    def test_registry_has_32_tests(self):
        assert len(TEST_REGISTRY) == 32

    def test_all_test_ids_are_valid_format(self):
        for tid in TEST_REGISTRY:
            prefix, num = tid.split("-")
            assert prefix in ("MOD", "APP", "INF", "DAT")
            assert num.isdigit()

    def test_each_entry_has_module_and_class(self):
        for tid, (module_path, class_name) in TEST_REGISTRY.items():
            assert module_path.startswith("tests.")
            assert class_name  # non-empty

    def test_mod_tests_count(self):
        mod_tests = [k for k in TEST_REGISTRY if k.startswith("MOD")]
        assert len(mod_tests) == 7

    def test_app_tests_count(self):
        app_tests = [k for k in TEST_REGISTRY if k.startswith("APP")]
        assert len(app_tests) == 14

    def test_inf_tests_count(self):
        inf_tests = [k for k in TEST_REGISTRY if k.startswith("INF")]
        assert len(inf_tests) == 6

    def test_dat_tests_count(self):
        dat_tests = [k for k in TEST_REGISTRY if k.startswith("DAT")]
        assert len(dat_tests) == 5


class TestCategoryMap:
    def test_all_categories_present(self):
        assert set(CATEGORY_MAP.keys()) == {"mod", "app", "inf", "dat", "all"}

    def test_all_category_contains_everything(self):
        assert set(CATEGORY_MAP["all"]) == set(TEST_REGISTRY.keys())

    def test_mod_category_only_mod(self):
        for tid in CATEGORY_MAP["mod"]:
            assert tid.startswith("MOD")

    def test_app_category_only_app(self):
        for tid in CATEGORY_MAP["app"]:
            assert tid.startswith("APP")

    def test_inf_category_only_inf(self):
        for tid in CATEGORY_MAP["inf"]:
            assert tid.startswith("INF")

    def test_dat_category_only_dat(self):
        for tid in CATEGORY_MAP["dat"]:
            assert tid.startswith("DAT")

    def test_categories_are_disjoint(self):
        combined = (
            CATEGORY_MAP["mod"]
            + CATEGORY_MAP["app"]
            + CATEGORY_MAP["inf"]
            + CATEGORY_MAP["dat"]
        )
        assert len(combined) == len(set(combined))

    def test_categories_cover_all(self):
        combined = set(
            CATEGORY_MAP["mod"]
            + CATEGORY_MAP["app"]
            + CATEGORY_MAP["inf"]
            + CATEGORY_MAP["dat"]
        )
        assert combined == set(CATEGORY_MAP["all"])


class TestModelTypeTests:
    def test_cv_and_llm_types_present(self):
        assert "cv" in MODEL_TYPE_TESTS
        assert "llm" in MODEL_TYPE_TESTS

    def test_cv_includes_mod_tests(self):
        cv_tests = MODEL_TYPE_TESTS["cv"]
        assert "MOD-01" in cv_tests
        assert "MOD-06" in cv_tests

    def test_llm_includes_app_tests(self):
        llm_tests = MODEL_TYPE_TESTS["llm"]
        assert "APP-01" in llm_tests
        assert "MOD-07" in llm_tests

    def test_inf_tests_in_both(self):
        for tid in ["INF-01", "INF-02", "INF-03", "INF-04", "INF-05", "INF-06"]:
            assert tid in MODEL_TYPE_TESTS["cv"]
            assert tid in MODEL_TYPE_TESTS["llm"]

    def test_dat_tests_in_both(self):
        for tid in ["DAT-01", "DAT-02", "DAT-03", "DAT-04", "DAT-05"]:
            assert tid in MODEL_TYPE_TESTS["cv"]
            assert tid in MODEL_TYPE_TESTS["llm"]


class TestLoadTestClass:
    def test_load_valid_test(self):
        cls = load_test_class("MOD-01")
        assert cls.__name__ == "MOD01Evasion"
        assert hasattr(cls, "phase1_attack")

    def test_load_unknown_test_raises(self):
        with pytest.raises(ValueError, match="Unknown test"):
            load_test_class("FAKE-99")

    def test_all_tests_loadable(self):
        """Verify every registered test can be dynamically imported."""
        for test_id in TEST_REGISTRY:
            cls = load_test_class(test_id)
            assert cls is not None
            assert hasattr(cls, "run")
            assert hasattr(cls, "phase1_attack")
            assert hasattr(cls, "phase2_measure")
            assert hasattr(cls, "phase3_defend")


class TestGetTestIds:
    def test_explicit_ids(self):
        result = get_test_ids(test_ids=["MOD-01", "APP-01"])
        assert result == ["MOD-01", "APP-01"]

    def test_category(self):
        result = get_test_ids(category="mod")
        assert result == CATEGORY_MAP["mod"]

    def test_default_returns_all(self):
        result = get_test_ids()
        assert result == CATEGORY_MAP["all"]

    def test_explicit_ids_take_precedence(self):
        result = get_test_ids(category="mod", test_ids=["APP-01"])
        assert result == ["APP-01"]
