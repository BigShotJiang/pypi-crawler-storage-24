"""
Tests for health check API endpoints.
"""


from tessera import __version__


class TestHealthEndpoint:
    def test_health_returns_ok(self, api_client):
        resp = api_client.get("/health")
        assert resp.status_code == 200
        data = resp.json()
        assert data["status"] == "ok"
        assert data["version"] == __version__

    def test_health_version_matches(self, api_client):
        resp = api_client.get("/health")
        assert resp.json()["version"] == "2.0.0"


class TestReadyEndpoint:
    def test_ready_returns_status(self, api_client):
        resp = api_client.get("/ready")
        assert resp.status_code == 200
        data = resp.json()
        assert data["status"] in ("ready", "degraded")
        assert "checks" in data
        assert "api" in data["checks"]
        assert data["checks"]["api"] is True

    def test_ready_no_db_configured(self, api_client):
        resp = api_client.get("/ready")
        data = resp.json()
        assert data["checks"]["database"] is False


class TestDocsEndpoint:
    def test_openapi_docs_accessible(self, api_client):
        resp = api_client.get("/docs")
        assert resp.status_code == 200

    def test_redoc_accessible(self, api_client):
        resp = api_client.get("/redoc")
        assert resp.status_code == 200

    def test_openapi_json(self, api_client):
        resp = api_client.get("/openapi.json")
        assert resp.status_code == 200
        data = resp.json()
        assert data["info"]["title"] == "Tessera"
        assert data["info"]["version"] == __version__
