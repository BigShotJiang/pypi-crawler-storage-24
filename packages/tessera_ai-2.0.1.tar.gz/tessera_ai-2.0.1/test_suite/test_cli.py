"""
Tests for tessera/cli.py — CLI argument parsing and commands.
"""

import sys

import pytest


class TestCLIArgumentParsing:
    def test_version_flag(self):
        with pytest.raises(SystemExit) as exc_info:
            from tessera.cli import main
            sys.argv = ["tessera", "--version"]
            main()
        assert exc_info.value.code == 0

    def test_list_flag(self, capsys):
        from tessera.cli import main

        sys.argv = ["tessera", "--list"]
        main()
        captured = capsys.readouterr()
        assert "MOD-01" in captured.out
        assert "APP-01" in captured.out
        assert "INF-01" in captured.out
        assert "DAT-01" in captured.out

    def test_list_shows_all_32_tests(self, capsys):
        from tessera.cli import main

        sys.argv = ["tessera", "--list"]
        main()
        captured = capsys.readouterr()
        # Count lines with test IDs
        test_lines = [line for line in captured.out.strip().split("\n") if ":" in line and "-" in line.split(":")[0]]
        assert len(test_lines) == 32

    def test_check_deps_flag(self, capsys):
        from tessera.cli import main

        sys.argv = ["tessera", "--check-deps"]
        main()
        captured = capsys.readouterr()
        assert "Available" in captured.out or "[OK]" in captured.out

    def test_missing_config_exits(self):
        from tessera.cli import main

        sys.argv = ["tessera", "--config", "/nonexistent/config.yaml"]
        with pytest.raises(SystemExit) as exc_info:
            main()
        assert exc_info.value.code == 1
