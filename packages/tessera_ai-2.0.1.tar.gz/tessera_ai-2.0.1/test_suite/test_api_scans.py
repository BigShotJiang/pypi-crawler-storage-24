"""
Tests for the scan management API endpoints.

These tests validate the scan lifecycle: create, list, get, delete.
For the actual scan execution, we mock the engine to avoid needing
real model servers.
"""

import time
from unittest.mock import patch

from tessera.api.deps import store_scan


class TestCreateScan:
    def test_create_scan_returns_id(self, api_client, sample_config_yaml):
        with patch("tessera.api.routers.scans._execute_scan"):
            resp = api_client.post("/api/v1/scans", json={
                "config_path": sample_config_yaml,
                "test_ids": ["MOD-01"],
            })
        assert resp.status_code == 200
        data = resp.json()
        assert "scan_id" in data
        assert data["status"] == "pending"

    def test_create_scan_default_params(self, api_client, sample_config_yaml):
        with patch("tessera.api.routers.scans._execute_scan"):
            resp = api_client.post("/api/v1/scans", json={})
        assert resp.status_code == 200

    def test_create_scan_with_category(self, api_client, sample_config_yaml):
        with patch("tessera.api.routers.scans._execute_scan"):
            resp = api_client.post("/api/v1/scans", json={
                "category": "mod",
                "config_path": sample_config_yaml,
            })
        assert resp.status_code == 200

    def test_create_scan_per_model(self, api_client, sample_config_yaml):
        with patch("tessera.api.routers.scans._execute_scan"):
            resp = api_client.post("/api/v1/scans", json={
                "per_model": True,
                "config_path": sample_config_yaml,
            })
        assert resp.status_code == 200


class TestListScans:
    def test_list_empty(self, api_client):
        resp = api_client.get("/api/v1/scans")
        assert resp.status_code == 200
        data = resp.json()
        assert data["scans"] == []
        assert data["total"] == 0

    def test_list_after_create(self, api_client):
        store_scan({"scan_id": "s1", "status": "completed"})
        store_scan({"scan_id": "s2", "status": "pending"})

        resp = api_client.get("/api/v1/scans")
        assert resp.json()["total"] == 2

    def test_list_pagination(self, api_client):
        for i in range(5):
            store_scan({"scan_id": f"s-{i}", "status": "completed"})

        resp = api_client.get("/api/v1/scans", params={"skip": 2, "limit": 2})
        assert len(resp.json()["scans"]) == 2

    def test_list_sorted_by_created_at(self, api_client):
        store_scan({"scan_id": "older", "status": "completed"})
        time.sleep(0.01)
        store_scan({"scan_id": "newer", "status": "completed"})

        resp = api_client.get("/api/v1/scans")
        scans = resp.json()["scans"]
        # Most recent first
        assert scans[0]["scan_id"] == "newer"


class TestGetScan:
    def test_get_existing_scan(self, api_client):
        store_scan({"scan_id": "test-scan", "status": "completed", "result": {"tests": []}})

        resp = api_client.get("/api/v1/scans/test-scan")
        assert resp.status_code == 200
        assert resp.json()["scan_id"] == "test-scan"

    def test_get_scan_not_found(self, api_client):
        resp = api_client.get("/api/v1/scans/nonexistent")
        assert resp.status_code == 404
        assert "not found" in resp.json()["detail"].lower()


class TestDeleteScan:
    def test_delete_existing_scan(self, api_client):
        store_scan({"scan_id": "to-delete", "status": "completed"})

        resp = api_client.delete("/api/v1/scans/to-delete")
        assert resp.status_code == 200
        assert resp.json()["deleted"] is True

        # Verify deletion
        resp = api_client.get("/api/v1/scans/to-delete")
        assert resp.status_code == 404

    def test_delete_not_found(self, api_client):
        resp = api_client.delete("/api/v1/scans/nonexistent")
        assert resp.status_code == 404


class TestScanExecution:
    """Test the actual scan execution flow (with mocked engine)."""

    def test_scan_completes_with_mock_engine(self, api_client, sample_config_yaml, mock_registry):
        """Create a scan and verify it completes via background thread."""
        resp = api_client.post("/api/v1/scans", json={
            "config_path": sample_config_yaml,
            "test_ids": ["MOCK-01"],
        })
        scan_id = resp.json()["scan_id"]

        # Wait for background thread to complete
        for _ in range(50):
            time.sleep(0.1)
            resp = api_client.get(f"/api/v1/scans/{scan_id}")
            status = resp.json().get("status")
            if status in ("completed", "failed"):
                break

        scan = api_client.get(f"/api/v1/scans/{scan_id}").json()
        # It may fail due to config.yaml not existing or other env issues,
        # but the lifecycle should complete without crashing the server
        assert scan["status"] in ("completed", "failed")
