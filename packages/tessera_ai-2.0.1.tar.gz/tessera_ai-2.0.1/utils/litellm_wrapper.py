"""
LiteLLM universal connector — supports 100+ providers via a single interface.

Routes to OpenAI, Anthropic, Google, Azure, Ollama, and more via litellm.
"""

from __future__ import annotations


class LiteLLMClient:
    """Universal LLM client using LiteLLM."""

    def __init__(self, model: str, api_key: str = None, api_base: str = None, **kwargs):
        self.model = model
        self.api_key = api_key
        self.api_base = api_base
        self.kwargs = kwargs

    def chat(self, prompt: str, system_prompt: str = None, max_tokens: int = 1024, temperature: float = 0.7) -> str:
        """Send a chat message and return the response text."""
        import litellm

        messages = []
        if system_prompt:
            messages.append({"role": "system", "content": system_prompt})
        messages.append({"role": "user", "content": prompt})

        response = litellm.completion(
            model=self.model,
            messages=messages,
            max_tokens=max_tokens,
            temperature=temperature,
            api_key=self.api_key,
            api_base=self.api_base,
            **self.kwargs,
        )

        return response.choices[0].message.content

    def health_check(self) -> bool:
        """Check if the model endpoint is reachable."""
        try:
            self.chat("Hi", max_tokens=5)
            return True
        except Exception:
            return False
