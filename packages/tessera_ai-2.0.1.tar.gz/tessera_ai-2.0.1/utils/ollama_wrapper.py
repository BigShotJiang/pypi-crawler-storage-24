"""
Tessera — Ollama connector for local LLM testing.

Wraps the Ollama REST API (http://localhost:11434) for security testing.
Supports chat completions, model listing, and health checks.

Usage:
    client = OllamaClient(base_url="http://localhost:11434", model="llama3")
    response = client.chat("Hello, how are you?")
"""

import requests


class OllamaClient:
    """Client for Ollama local LLM inference."""

    def __init__(self, base_url: str = "http://localhost:11434",
                 model: str = "llama3", timeout: int = 60):
        self.base_url = base_url.rstrip("/")
        self.model = model
        self.timeout = timeout

    def chat(self, prompt: str, system: str = None,
             temperature: float = 0.0, max_tokens: int = 512) -> dict:
        """Send a chat request to Ollama."""
        messages = []
        if system:
            messages.append({"role": "system", "content": system})
        messages.append({"role": "user", "content": prompt})

        payload = {
            "model": self.model,
            "messages": messages,
            "stream": False,
            "options": {
                "temperature": temperature,
                "num_predict": max_tokens,
            },
        }

        try:
            resp = requests.post(
                f"{self.base_url}/api/chat",
                json=payload,
                timeout=self.timeout,
            )
            resp.raise_for_status()
            data = resp.json()
            message = data.get("message", {})
            return {
                "content": message.get("content", ""),
                "model": data.get("model", self.model),
                "done": data.get("done", True),
                "total_duration": data.get("total_duration", 0),
            }
        except Exception as e:
            return {"content": "", "error": str(e)}

    def generate(self, prompt: str, system: str = None,
                 temperature: float = 0.0, max_tokens: int = 512) -> dict:
        """Send a generate (completion) request to Ollama."""
        payload = {
            "model": self.model,
            "prompt": prompt,
            "stream": False,
            "options": {
                "temperature": temperature,
                "num_predict": max_tokens,
            },
        }
        if system:
            payload["system"] = system

        try:
            resp = requests.post(
                f"{self.base_url}/api/generate",
                json=payload,
                timeout=self.timeout,
            )
            resp.raise_for_status()
            data = resp.json()
            return {
                "content": data.get("response", ""),
                "model": data.get("model", self.model),
                "done": data.get("done", True),
            }
        except Exception as e:
            return {"content": "", "error": str(e)}

    def list_models(self) -> list:
        """List locally available models."""
        try:
            resp = requests.get(
                f"{self.base_url}/api/tags",
                timeout=self.timeout,
            )
            resp.raise_for_status()
            return [m["name"] for m in resp.json().get("models", [])]
        except Exception:
            return []

    def health_check(self) -> bool:
        """Check if Ollama is reachable."""
        try:
            resp = requests.get(self.base_url, timeout=5)
            return resp.status_code == 200
        except Exception:
            return False
