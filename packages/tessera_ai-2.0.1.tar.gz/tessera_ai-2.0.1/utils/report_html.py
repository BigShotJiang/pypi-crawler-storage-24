"""
Tessera — Interactive HTML Report Generator

Generates beautiful, interactive, single-file HTML reports with:
- Modern dark theme (#0f1117, #0693e3, #9b51e0)
- Sidebar navigation across all tests / models
- Collapsible phase sections
- Search & filter
- Model x Test matrix (executive summary)
- Responsive design
- Smooth animations
- SVG icons (no external dependencies)
"""

import html as html_module

# ── Tessera Brand ─────────────────────────────────────────────────
TESSERA_LOGO_HTML = """<span style="font-size:20px;font-weight:800;letter-spacing:-0.5px;color:#e8eaed"><span style="background:linear-gradient(135deg,#0693e3,#9b51e0);-webkit-background-clip:text;-webkit-text-fill-color:transparent">tessera</span></span>"""

CSS = """
:root {
  --bg-primary: #0f1117;
  --bg-secondary: #161b22;
  --bg-card: #1c2128;
  --bg-hover: #252d38;
  --border: #30363d;
  --text-primary: #e8eaed;
  --text-secondary: #8b949e;
  --text-muted: #636c76;
  --accent-blue: #0693e3;
  --accent-purple: #9b51e0;
  --gradient: linear-gradient(135deg, #0693e3, #9b51e0);
  --pass: #2ea043;
  --fail: #f85149;
  --warn: #d29922;
  --error: #f85149;
  --na: #636c76;
  --sidebar-width: 280px;
  --header-height: 60px;
}
* { margin: 0; padding: 0; box-sizing: border-box; }
body { font-family: 'Segoe UI', system-ui, -apple-system, sans-serif; background: var(--bg-primary); color: var(--text-primary); line-height: 1.6; }

/* ── Header ── */
.header { position: fixed; top: 0; left: 0; right: 0; height: var(--header-height); background: var(--bg-secondary); border-bottom: 1px solid var(--border); display: flex; align-items: center; justify-content: space-between; padding: 0 24px; z-index: 100; }
.header-left { display: flex; align-items: center; gap: 16px; }
.header-left svg { height: 32px; width: auto; }
.header-title { font-size: 14px; color: var(--text-secondary); }
.header-title span { color: var(--accent-blue); font-weight: 600; }
.header-right { display: flex; align-items: center; gap: 12px; }
.header-badge { padding: 4px 12px; border-radius: 12px; font-size: 12px; font-weight: 600; }

/* ── Sidebar ── */
.sidebar { position: fixed; top: var(--header-height); left: 0; width: var(--sidebar-width); height: calc(100vh - var(--header-height)); background: var(--bg-secondary); border-right: 1px solid var(--border); overflow-y: auto; z-index: 90; transition: transform 0.3s; }
.sidebar-section { padding: 16px; border-bottom: 1px solid var(--border); }
.sidebar-section h3 { font-size: 11px; text-transform: uppercase; letter-spacing: 1px; color: var(--text-muted); margin-bottom: 8px; }
.sidebar-search { width: 100%; padding: 8px 12px; background: var(--bg-primary); border: 1px solid var(--border); border-radius: 6px; color: var(--text-primary); font-size: 13px; outline: none; }
.sidebar-search:focus { border-color: var(--accent-blue); }
.nav-item { display: flex; align-items: center; gap: 8px; padding: 8px 12px; border-radius: 6px; cursor: pointer; font-size: 13px; color: var(--text-secondary); transition: all 0.15s; text-decoration: none; }
.nav-item:hover { background: var(--bg-hover); color: var(--text-primary); }
.nav-item.active { background: var(--accent-blue)18; color: var(--accent-blue); border-left: 2px solid var(--accent-blue); }
.nav-status { width: 8px; height: 8px; border-radius: 50%; flex-shrink: 0; }
.nav-status.pass { background: var(--pass); }
.nav-status.fail { background: var(--fail); }
.nav-status.warn { background: var(--warn); }
.nav-status.error { background: var(--error); }
.nav-status.na, .nav-status.n\\/a { background: var(--na); }

/* ── Main Content ── */
.main { margin-left: var(--sidebar-width); margin-top: var(--header-height); padding: 32px; min-height: calc(100vh - var(--header-height)); }

/* ── Summary Cards ── */
.summary-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(140px, 1fr)); gap: 16px; margin-bottom: 32px; }
.summary-card { background: var(--bg-card); border: 1px solid var(--border); border-radius: 12px; padding: 20px; text-align: center; transition: transform 0.2s, box-shadow 0.2s; }
.summary-card:hover { transform: translateY(-2px); box-shadow: 0 8px 24px rgba(0,0,0,0.3); }
.summary-card .number { font-size: 2.5em; font-weight: 700; line-height: 1; }
.summary-card .label { font-size: 12px; color: var(--text-secondary); text-transform: uppercase; letter-spacing: 1px; margin-top: 4px; }
.summary-card.pass .number { color: var(--pass); }
.summary-card.fail .number { color: var(--fail); }
.summary-card.warn .number { color: var(--warn); }
.summary-card.error .number { color: var(--error); }
.summary-card.total .number { background: var(--gradient); -webkit-background-clip: text; -webkit-text-fill-color: transparent; }

/* ── Test Cards ── */
.test-card { background: var(--bg-card); border: 1px solid var(--border); border-radius: 12px; margin-bottom: 20px; overflow: hidden; transition: box-shadow 0.2s; }
.test-card:hover { box-shadow: 0 4px 16px rgba(0,0,0,0.2); }
.test-card-header { padding: 20px 24px; cursor: pointer; display: flex; align-items: center; justify-content: space-between; }
.test-card-header:hover { background: var(--bg-hover); }
.test-card-title { display: flex; align-items: center; gap: 12px; }
.test-card-title h3 { font-size: 16px; font-weight: 600; }
.test-card-meta { font-size: 12px; color: var(--text-muted); margin-top: 2px; }
.test-card-body { padding: 0 24px 24px; display: none; }
.test-card.open .test-card-body { display: block; animation: slideDown 0.3s ease; }
.chevron { transition: transform 0.3s; color: var(--text-muted); }
.test-card.open .chevron { transform: rotate(180deg); }

@keyframes slideDown {
  from { opacity: 0; transform: translateY(-10px); }
  to { opacity: 1; transform: translateY(0); }
}

/* ── Status Badge ── */
.status-badge { display: inline-flex; align-items: center; gap: 4px; padding: 4px 12px; border-radius: 6px; font-size: 12px; font-weight: 600; }
.status-badge.pass { background: var(--pass)22; color: var(--pass); }
.status-badge.fail { background: var(--fail)22; color: var(--fail); }
.status-badge.warn { background: var(--warn)22; color: var(--warn); }
.status-badge.error { background: var(--error)22; color: var(--error); }
.status-badge.na, .status-badge.n\\/a, .status-badge.not_run { background: var(--na)22; color: var(--na); }

/* ── Phase ── */
.phase { background: var(--bg-secondary); border: 1px solid var(--border); border-radius: 8px; margin-bottom: 12px; overflow: hidden; }
.phase-header { padding: 14px 16px; display: flex; align-items: center; justify-content: space-between; cursor: pointer; }
.phase-header:hover { background: var(--bg-hover); }
.phase-body { padding: 16px; border-top: 1px solid var(--border); display: none; }
.phase.open .phase-body { display: block; }

/* ── Metrics ── */
.metric-row { display: flex; align-items: center; justify-content: space-between; padding: 8px 0; border-bottom: 1px solid var(--border); }
.metric-row:last-child { border-bottom: none; }
.metric-name { font-size: 13px; color: var(--text-secondary); }
.metric-value { font-weight: 600; font-size: 14px; }
.metric-bar { height: 4px; background: var(--border); border-radius: 2px; margin-top: 4px; overflow: hidden; }
.metric-bar-fill { height: 100%; border-radius: 2px; transition: width 0.5s ease; }

/* ── Evidence ── */
.evidence-list { list-style: none; padding: 0; }
.evidence-list li { padding: 6px 0; font-size: 13px; color: var(--text-secondary); border-bottom: 1px solid var(--border)44; word-break: break-word; }
.evidence-list li::before { content: "›"; margin-right: 8px; color: var(--accent-blue); font-weight: bold; }
.evidence-list li.tree-item { padding-left: 24px; border-bottom: none; padding-top: 3px; padding-bottom: 3px; }
.evidence-list li.tree-item::before { content: ""; margin-right: 0; }
.pii-value { background: var(--fail)18; color: var(--fail); padding: 2px 8px; border-radius: 4px; font-family: 'Courier New', monospace; font-size: 12px; border: 1px solid var(--fail)33; display: inline-block; margin: 1px 0; }
.evidence-list li.pii-item { padding-left: 32px; border-bottom: none; padding-top: 2px; padding-bottom: 2px; font-family: 'Courier New', monospace; }
.evidence-list li.pii-item::before { content: "⚠"; color: var(--fail); }
.evidence-section-header { color: var(--accent-blue); font-weight: 600; font-size: 13px; margin-top: 8px; }

/* ── Status Filters ── */
.filter-bar { display: flex; gap: 8px; margin-bottom: 20px; flex-wrap: wrap; align-items: center; }
.filter-btn { padding: 6px 14px; background: var(--bg-card); border: 1px solid var(--border); border-radius: 6px; color: var(--text-secondary); cursor: pointer; font-size: 12px; transition: all 0.15s; }
.filter-btn:hover { border-color: var(--accent-blue); color: var(--text-primary); }
.filter-btn.active { border-color: var(--accent-blue); color: var(--accent-blue); background: var(--accent-blue)15; }
.filter-btn.filter-fail.active { border-color: var(--fail); color: var(--fail); background: var(--fail)15; }
.filter-btn.filter-warn.active { border-color: var(--warn); color: var(--warn); background: var(--warn)15; }
.filter-btn.filter-pass.active { border-color: var(--pass); color: var(--pass); background: var(--pass)15; }

/* ── Score Ring ── */
.score-ring { position: relative; width: 80px; height: 80px; }
.score-ring svg { transform: rotate(-90deg); }
.score-ring-text { position: absolute; top: 50%; left: 50%; transform: translate(-50%, -50%); font-size: 18px; font-weight: 700; }

/* ── Category Group ── */
.sidebar-category { font-size: 10px; text-transform: uppercase; letter-spacing: 1.2px; color: var(--text-muted); padding: 12px 12px 4px; font-weight: 600; }
.sidebar-category:not(:first-child) { border-top: 1px solid var(--border); margin-top: 4px; }

/* ── Recommendations ── */
.recommendations { margin-top: 16px; padding: 16px; background: var(--accent-blue)08; border: 1px solid var(--accent-blue)33; border-radius: 8px; }
.recommendations h4 { color: var(--accent-blue); font-size: 13px; margin-bottom: 8px; }
.recommendations li { font-size: 13px; color: var(--text-secondary); margin: 4px 0; padding-left: 16px; list-style: none; position: relative; }
.recommendations li::before { content: "→"; position: absolute; left: 0; color: var(--accent-blue); }

/* ── Matrix (Executive) ── */
.matrix-container { overflow-x: auto; margin: 24px 0; }
.matrix-table { border-collapse: collapse; width: 100%; min-width: 600px; }
.matrix-table th, .matrix-table td { padding: 10px 14px; text-align: center; border: 1px solid var(--border); font-size: 13px; }
.matrix-table th { background: var(--bg-secondary); color: var(--accent-blue); font-weight: 600; position: sticky; top: 0; }
.matrix-table th:first-child { text-align: left; min-width: 200px; }
.matrix-table td:first-child { text-align: left; font-weight: 500; }
.matrix-cell { display: inline-block; padding: 2px 10px; border-radius: 4px; font-weight: 600; font-size: 11px; }
.matrix-cell.pass { background: var(--pass)22; color: var(--pass); }
.matrix-cell.fail { background: var(--fail)22; color: var(--fail); }
.matrix-cell.warn { background: var(--warn)22; color: var(--warn); }
.matrix-cell.error { background: var(--error)22; color: var(--error); }
.matrix-cell.na { background: var(--na)22; color: var(--na); }
.matrix-cell.empty { color: var(--text-muted); }

/* ── Model Info ── */
.model-info { background: var(--gradient); border-radius: 12px; padding: 24px; margin-bottom: 24px; color: #fff; }
.model-info h2 { font-size: 20px; margin-bottom: 8px; }
.model-info-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(150px, 1fr)); gap: 12px; margin-top: 12px; }
.model-info-item { font-size: 13px; }
.model-info-item .label { opacity: 0.7; }

/* ── Footer ── */
.footer { text-align: center; padding: 32px; color: var(--text-muted); font-size: 12px; border-top: 1px solid var(--border); margin-top: 48px; }
.footer a { color: var(--accent-blue); text-decoration: none; }

/* ── Responsive ── */
@media (max-width: 768px) {
  .sidebar { transform: translateX(-100%); }
  .sidebar.open { transform: translateX(0); }
  .main { margin-left: 0; }
  .summary-grid { grid-template-columns: repeat(3, 1fr); }
}

/* ── Print ── */
@media print {
  .sidebar, .header { display: none; }
  .main { margin: 0; padding: 20px; }
  .test-card-body { display: block !important; }
  .phase-body { display: block !important; }
}
"""

JS = """
// ── Sidebar Navigation ──
function scrollToTest(id) {
  const el = document.getElementById(id);
  if (el) {
    el.scrollIntoView({ behavior: 'smooth', block: 'start' });
    el.classList.add('open');
  }
  document.querySelectorAll('.nav-item').forEach(n => n.classList.remove('active'));
  const navItem = document.querySelector(`.nav-item[data-target="${id}"]`);
  if (navItem) navItem.classList.add('active');
}

// ── Toggle Cards ──
function toggleCard(el) {
  el.closest('.test-card').classList.toggle('open');
}
function togglePhase(el) {
  el.closest('.phase').classList.toggle('open');
}

// ── Search ──
function filterTests(query) {
  query = query.toLowerCase();
  document.querySelectorAll('.test-card').forEach(card => {
    const text = card.textContent.toLowerCase();
    const matchesSearch = text.includes(query);
    card.dataset.searchMatch = matchesSearch ? '1' : '0';
    applyVisibility(card);
  });
  document.querySelectorAll('.nav-item[data-target]').forEach(nav => {
    const text = nav.textContent.toLowerCase();
    nav.style.display = text.includes(query) ? '' : 'none';
  });
}

// ── Status Filter ──
let activeFilter = 'all';
function filterByStatus(status, btn) {
  if (activeFilter === status) { status = 'all'; }
  activeFilter = status;
  document.querySelectorAll('.filter-btn[data-status]').forEach(b => b.classList.remove('active'));
  if (status !== 'all' && btn) btn.classList.add('active');
  document.querySelectorAll('.test-card').forEach(card => {
    applyVisibility(card);
  });
}
function applyVisibility(card) {
  const searchOk = card.dataset.searchMatch !== '0';
  const statusOk = activeFilter === 'all' || card.dataset.status === activeFilter;
  card.style.display = (searchOk && statusOk) ? '' : 'none';
}

// ── Expand / Collapse All ──
function expandAll() {
  document.querySelectorAll('.test-card').forEach(c => c.classList.add('open'));
  document.querySelectorAll('.phase').forEach(p => p.classList.add('open'));
}
function collapseAll() {
  document.querySelectorAll('.test-card').forEach(c => c.classList.remove('open'));
  document.querySelectorAll('.phase').forEach(p => p.classList.remove('open'));
}

// ── Mobile sidebar toggle ──
function toggleSidebar() {
  document.querySelector('.sidebar').classList.toggle('open');
}

// ── Auto-expand FAIL/ERROR tests + their phases on load ──
document.addEventListener('DOMContentLoaded', () => {
  // Animate numbers
  document.querySelectorAll('.summary-card .number').forEach(el => {
    const target = parseInt(el.textContent);
    if (isNaN(target)) return;
    el.textContent = '0';
    let current = 0;
    const step = Math.max(1, Math.ceil(target / 20));
    const timer = setInterval(() => {
      current += step;
      if (current >= target) { current = target; clearInterval(timer); }
      el.textContent = current;
    }, 30);
  });
  // Auto-expand FAIL and ERROR test cards so critical findings are visible
  document.querySelectorAll('.test-card[data-status="FAIL"], .test-card[data-status="ERROR"]').forEach(card => {
    card.classList.add('open');
    card.querySelectorAll('.phase').forEach(phase => {
      const badge = phase.querySelector('.status-badge');
      if (badge && (badge.textContent.trim() === 'FAIL' || badge.textContent.trim() === 'ERROR')) {
        phase.classList.add('open');
      }
    });
  });
});
"""


def _esc(text):
    """HTML-escape text."""
    return html_module.escape(str(text)) if text else ""


def _status_class(status):
    """Map status string to CSS class."""
    return status.lower().replace("/", "\\/").replace(" ", "_") if status else "na"


def _status_css(status):
    """Simple lowercase for class names."""
    s = (status or "na").lower().replace("/", "").replace(" ", "_")
    if s == "na":
        return "na"
    return s


def generate_model_report_html(data: dict) -> str:
    """Generate an interactive HTML report for a single model."""
    project = data.get("project", {})
    summary = data.get("summary", {})
    model = data.get("model", {})
    tests = data.get("tests", [])

    # Build sidebar nav items grouped by category (MOD, APP, INF, DAT)
    CATEGORY_LABELS = {
        "MOD": "Model Security",
        "APP": "Application Security",
        "INF": "Infrastructure Security",
        "DAT": "Data Governance",
    }
    # Group tests by category prefix
    nav_groups = {}
    for t in tests:
        prefix = t["test_id"].split("-")[0]
        if prefix not in nav_groups:
            nav_groups[prefix] = []
        nav_groups[prefix].append(t)

    nav_items = ""
    for prefix in ["MOD", "APP", "INF", "DAT"]:
        group = nav_groups.get(prefix, [])
        if not group:
            continue
        # Category counts
        g_pass = sum(1 for t in group if t["status"] == "PASS")
        g_fail = sum(1 for t in group if t["status"] == "FAIL")
        g_total = len(group)
        cat_label = CATEGORY_LABELS.get(prefix, prefix)
        cat_sc = "fail" if g_fail > 0 else "pass" if g_pass == g_total else "warn"
        nav_items += '<div class="sidebar-category">'
        nav_items += f'<span class="nav-status {cat_sc}" style="display:inline-block;vertical-align:middle;margin-right:6px;"></span>'
        nav_items += f'{_esc(prefix)} — {_esc(cat_label)} '
        nav_items += f'<span style="opacity:0.5;">({g_pass}/{g_total})</span></div>\n'
        for t in group:
            sid = f"test-{t['test_id'].replace('-', '').lower()}"
            sc = _status_css(t["status"])
            nav_items += f'<a class="nav-item" data-target="{sid}" onclick="scrollToTest(\'{sid}\')" style="padding-left:24px;">'
            nav_items += f'<span class="nav-status {sc}"></span>'
            nav_items += f'{_esc(t["test_id"])}: {_esc(t["test_name"][:28])}</a>\n'

    # Build test cards
    test_cards = ""
    for t in tests:
        sid = f"test-{t['test_id'].replace('-', '').lower()}"
        sc = _status_css(t["status"])
        phases_html = _render_phases(t.get("phases", []))
        recs_html = _render_recommendations(t.get("recommendations", []))
        tools = ", ".join(t.get("tools_used", [])) or "N/A"

        test_cards += f"""
        <div class="test-card" id="{sid}" data-status="{_esc(t['status'])}">
          <div class="test-card-header" onclick="toggleCard(this)">
            <div class="test-card-title">
              <span class="status-badge {sc}">{_esc(t['status'])}</span>
              <div>
                <h3>{_esc(t['test_id'])}: {_esc(t['test_name'])}</h3>
                <div class="test-card-meta">OWASP: {_esc(t.get('owasp_ref',''))} | Tools: {_esc(tools)} | {t.get('duration_sec',0)}s</div>
              </div>
            </div>
            <span class="chevron">&#9660;</span>
          </div>
          <div class="test-card-body">
            {phases_html}
            {recs_html}
          </div>
        </div>"""

    # Model info banner
    model_banner = ""
    if model.get("name"):
        # Model type badge with color coding
        model_type = (model.get("type", "") or "").upper()
        type_colors = {"CV": "#2ea043", "LLM": "#9b51e0", "NVIDIA": "#76b900"}
        type_color = type_colors.get(model_type, "#636c76")
        type_badge = f'<span style="display:inline-block;padding:4px 12px;border-radius:16px;background:{type_color}33;color:{type_color};font-size:12px;font-weight:700;margin-left:12px;border:1px solid {type_color}66;">{_esc(model_type)}</span>' if model_type else ""
        # Server badge
        server_type = (model.get("server", "") or "").upper()
        server_colors = {"TRITON": "#76b900", "VLLM": "#9b51e0", "CUSTOM": "#0693e3"}
        server_color = server_colors.get(server_type, "#636c76")
        server_badge = f'<span style="display:inline-block;padding:4px 12px;border-radius:16px;background:{server_color}33;color:{server_color};font-size:12px;font-weight:700;margin-left:8px;border:1px solid {server_color}66;">{_esc(server_type)}</span>' if server_type else ""

        model_banner = f"""
        <div class="model-info">
          <h2>{_esc(model['name'])} {type_badge} {server_badge}</h2>
          <div class="model-info-grid">
            <div class="model-info-item"><div class="label">Architecture</div><div>{_esc(model.get('arch','N/A'))}</div></div>
            <div class="model-info-item"><div class="label">Model Type</div><div>{_esc(model_type)} {'(Computer Vision)' if model_type == 'CV' else '(Large Language Model)' if model_type == 'LLM' else ''}</div></div>
            <div class="model-info-item"><div class="label">Task</div><div>{_esc(model.get('task','N/A'))}</div></div>
            <div class="model-info-item"><div class="label">Server</div><div>{_esc(server_type)} @ {_esc(model.get('url',''))}</div></div>
          </div>
        </div>"""

    title = f"{model['name']}" if model.get("name") else project.get("name", "Report")

    return _wrap_html(
        title=f"Tessera Security Report — {title}",
        nav_items=nav_items,
        content=f"""
        {model_banner}
        <div class="summary-grid">
          <div class="summary-card total"><div class="number">{summary.get('total',0)}</div><div class="label">Total Tests</div></div>
          <div class="summary-card pass"><div class="number">{summary.get('pass',0)}</div><div class="label">Passed</div></div>
          <div class="summary-card fail"><div class="number">{summary.get('fail',0)}</div><div class="label">Failed</div></div>
          <div class="summary-card warn"><div class="number">{summary.get('warn',0)}</div><div class="label">Warnings</div></div>
          <div class="summary-card error"><div class="number">{summary.get('error',0)}</div><div class="label">Errors</div></div>
        </div>
        <div class="filter-bar">
          <button class="filter-btn" onclick="expandAll()">Expand All</button>
          <button class="filter-btn" onclick="collapseAll()">Collapse All</button>
          <span style="width:1px;height:24px;background:var(--border);margin:0 4px;"></span>
          <button class="filter-btn filter-fail" data-status="FAIL" onclick="filterByStatus('FAIL',this)">FAIL Only</button>
          <button class="filter-btn filter-warn" data-status="WARN" onclick="filterByStatus('WARN',this)">WARN Only</button>
          <button class="filter-btn filter-pass" data-status="PASS" onclick="filterByStatus('PASS',this)">PASS Only</button>
          <button class="filter-btn" data-status="all" onclick="filterByStatus('all',this)">Show All</button>
        </div>
        {test_cards}
        """,
        project=project,
        timestamp=data.get("timestamp", ""),
        duration=data.get("total_duration_sec", 0),
    )


def generate_executive_html(data: dict) -> str:
    """Generate an interactive executive summary HTML with model x test matrix."""
    project = data.get("project", {})
    matrix = data.get("matrix", {})
    test_ids = data.get("test_ids", [])
    per_model = data.get("per_model_summary", {})

    # Aggregate stats
    total_tests = sum(info.get("total", 0) for info in per_model.values())
    total_pass = sum(info.get("pass", 0) for info in per_model.values())
    total_fail = sum(info.get("fail", 0) for info in per_model.values())
    total_warn = sum(info.get("warn", 0) for info in per_model.values())
    total_error = sum(info.get("error", 0) for info in per_model.values())

    # Build matrix table
    header_cells = "".join(f"<th>{_esc(tid)}</th>" for tid in test_ids)
    rows = ""
    for model_name in sorted(matrix.keys()):
        statuses = matrix[model_name]
        info = per_model.get(model_name, {})
        cells = ""
        for tid in test_ids:
            status = statuses.get(tid, "-")
            sc = _status_css(status) if status != "-" else "empty"
            cells += f'<td><span class="matrix-cell {sc}">{_esc(status)}</span></td>'

        total = info.get("total", 0)
        passed = info.get("pass", 0)
        score = round(passed / total * 100) if total > 0 else 0
        score_sc = "pass" if score >= 80 else "warn" if score >= 50 else "fail"

        arch = info.get("arch", "")
        mtype = info.get("type", "").upper()
        rows += f"""<tr>
          <td><strong>{_esc(model_name)}</strong><br><small style="color:var(--text-muted)">{_esc(arch)} [{mtype}]</small></td>
          {cells}
          <td><span class="matrix-cell {score_sc}">{score}%</span></td>
        </tr>"""

    # Nav items grouped by model type (CV / LLM)
    nav_items = ""
    type_groups = {}
    for model_name in sorted(matrix.keys()):
        info = per_model.get(model_name, {})
        mtype = (info.get("type", "") or "unknown").upper()
        if mtype not in type_groups:
            type_groups[mtype] = []
        type_groups[mtype].append((model_name, info))

    for mtype in ["CV", "LLM"]:
        models_in_type = type_groups.get(mtype, [])
        if not models_in_type:
            continue
        type_label = "Computer Vision" if mtype == "CV" else "Large Language Models" if mtype == "LLM" else mtype
        nav_items += f'<div class="sidebar-category">{_esc(mtype)} — {_esc(type_label)} ({len(models_in_type)})</div>\n'
        for model_name, info in models_in_type:
            total = info.get("total", 0)
            passed = info.get("pass", 0)
            sc = "pass" if passed == total and total > 0 else "warn" if info.get("fail", 0) == 0 else "fail"
            nav_items += f'<a class="nav-item" style="padding-left:24px;"><span class="nav-status {sc}"></span>{_esc(model_name)}</a>\n'

    return _wrap_html(
        title="Tessera — Executive Summary",
        nav_items=nav_items,
        content=f"""
        <h2 style="margin-bottom:24px;background:var(--gradient);-webkit-background-clip:text;-webkit-text-fill-color:transparent;font-size:28px;">Executive Summary</h2>
        <div class="summary-grid">
          <div class="summary-card total"><div class="number">{data.get('models_tested',0)}</div><div class="label">Models</div></div>
          <div class="summary-card total"><div class="number">{total_tests}</div><div class="label">Total Tests</div></div>
          <div class="summary-card pass"><div class="number">{total_pass}</div><div class="label">Passed</div></div>
          <div class="summary-card fail"><div class="number">{total_fail}</div><div class="label">Failed</div></div>
          <div class="summary-card warn"><div class="number">{total_warn}</div><div class="label">Warnings</div></div>
          <div class="summary-card error"><div class="number">{total_error}</div><div class="label">Errors</div></div>
        </div>

        <h3 style="margin:32px 0 16px;color:var(--accent-blue);">Model × Test Matrix</h3>
        <div class="matrix-container">
          <table class="matrix-table">
            <thead><tr><th>Model</th>{header_cells}<th>Score</th></tr></thead>
            <tbody>{rows}</tbody>
          </table>
        </div>
        """,
        project=project,
        timestamp=data.get("timestamp", ""),
        duration=data.get("total_duration_sec", 0),
    )


def _render_phases(phases: list) -> str:
    """Render phase sections."""
    out = ""
    for p in phases:
        sc = _status_css(p.get("status", ""))
        metrics_html = ""
        for m in p.get("metrics", []):
            msc = _status_css(m.get("status", ""))
            val = m.get("value", 0)
            source = m.get("source", "")
            source_html = ""
            if source:
                # Source may contain "OWASP ... | https://..." format
                if "|" in source:
                    parts = source.split("|", 1)
                    src_label = parts[0].strip()
                    src_url = parts[1].strip()
                    source_html = f'<div style="font-size:10px;color:var(--text-muted);margin-top:2px;"><a href="{_esc(src_url)}" target="_blank" rel="noopener" style="color:var(--accent-purple);text-decoration:none;">{_esc(src_label)}</a></div>'
                else:
                    source_html = f'<div style="font-size:10px;color:var(--text-muted);margin-top:2px;">{_esc(source)}</div>'
            # Threshold info
            tp = m.get("threshold_pass", "")
            tf = m.get("threshold_fail", "")
            op = m.get("operator", "<")
            thresh_html = ""
            if tp != "" or tf != "":
                if op == "<":
                    thresh_html = f'<div style="font-size:10px;color:var(--text-muted);">Pass: &lt;{tp} | Fail: &gt;{tf}</div>'
                else:
                    thresh_html = f'<div style="font-size:10px;color:var(--text-muted);">Pass: &gt;{tp} | Fail: &lt;{tf}</div>'
            metrics_html += f"""
            <div class="metric-row">
              <div>
                <div class="metric-name">{_esc(m.get('name',''))}</div>
                {source_html}
              </div>
              <div style="text-align:right;">
                <span class="metric-value" style="color:var(--{msc});">{val} {_esc(m.get('unit',''))}</span>
                <span class="status-badge {msc}" style="margin-left:8px;font-size:10px;">{_esc(m.get('status',''))}</span>
                {thresh_html}
              </div>
            </div>"""

        evidence_html = ""
        if p.get("evidence"):
            items = ""
            for e in p["evidence"]:
                e_str = str(e)
                if e_str.strip().startswith("\u2514\u2500"):
                    # PII value tree item — highlight the value
                    val = _esc(e_str.strip()[2:].strip())
                    items += f'<li class="pii-item"><span class="pii-value">{val}</span></li>'
                elif e_str.startswith("  ") and ":" in e_str and "instance" in e_str:
                    # Category count line (e.g. "  email: 4 instance(s)")
                    items += f'<li class="tree-item" style="color:var(--warn);font-weight:600;">{_esc(e_str.strip())}</li>'
                elif e_str.startswith("[SYNTHETIC DATA]"):
                    items += f'<li style="color:var(--warn);font-weight:600;background:var(--warn)11;padding:8px;border-radius:4px;">{_esc(e_str)}</li>'
                else:
                    items += f"<li>{_esc(e_str)}</li>"
            evidence_html = f'<ul class="evidence-list">{items}</ul>'

        error_html = ""
        if p.get("error"):
            error_html = f'<div style="color:var(--fail);padding:8px;margin-top:8px;background:var(--fail)11;border-radius:6px;font-size:13px;">ERROR: {_esc(p["error"])}</div>'

        out += f"""
        <div class="phase">
          <div class="phase-header" onclick="togglePhase(this)">
            <div style="display:flex;align-items:center;gap:8px;">
              <span class="status-badge {sc}">{_esc(p.get('status',''))}</span>
              <span>Phase {p.get('phase','')}: {_esc(p.get('name',''))}</span>
            </div>
            <small style="color:var(--text-muted);">{p.get('duration_sec',0)}s</small>
          </div>
          <div class="phase-body">
            {metrics_html}
            {evidence_html}
            {error_html}
          </div>
        </div>"""
    return out


def _render_recommendations(recs: list) -> str:
    """Render recommendations section. Supports both string and dict format."""
    if not recs:
        return ""
    items = ""
    for r in recs:
        if isinstance(r, dict):
            text = _esc(r.get("text", ""))
            url = r.get("url", "")
            if url:
                items += f'<li>{text} <a href="{_esc(url)}" target="_blank" rel="noopener" style="color:var(--accent-purple);font-size:11px;margin-left:4px;">Reference &rarr;</a></li>'
            else:
                items += f"<li>{text}</li>"
        else:
            items += f"<li>{_esc(r)}</li>"
    return f"""
    <div class="recommendations">
      <h4>Recommendations</h4>
      <ul>{items}</ul>
    </div>"""


def generate_unified_report_html(all_models_data: dict, executive_data: dict = None) -> str:
    """
    Generate a single unified HTML report combining ALL models.

    Parameters
    ----------
    all_models_data : dict
        {model_name: report_json_dict, ...}  (11 models)
    executive_data : dict, optional
        Executive summary JSON data (for aggregate stats)
    """
    project = {}
    timestamp = ""
    total_duration = 0
    total_tests = total_pass = total_fail = total_warn = total_error = 0

    # Collect all model info
    models_by_type = {"CV": [], "LLM": []}
    for model_name in sorted(all_models_data.keys()):
        data = all_models_data[model_name]
        if not project:
            project = data.get("project", {})
            timestamp = data.get("timestamp", "")
        total_duration += data.get("total_duration_sec", 0)
        summary = data.get("summary", {})
        total_tests += summary.get("total", 0)
        total_pass += summary.get("pass", 0)
        total_fail += summary.get("fail", 0)
        total_warn += summary.get("warn", 0)
        total_error += summary.get("error", 0)

        model = data.get("model", {})
        mtype = (model.get("type", "") or "cv").upper()
        if mtype not in models_by_type:
            models_by_type[mtype] = []
        models_by_type[mtype].append((model_name, data))

    # Use executive data if provided
    if executive_data:
        project = executive_data.get("project", project)
        timestamp = executive_data.get("timestamp", timestamp)

    # ── Build sidebar navigation ──
    nav_items = ""
    # Overview link
    nav_items += '<a class="nav-item active" data-target="section-overview" onclick="scrollToSection(\'section-overview\')" style="font-weight:600;">'
    nav_items += '<span class="nav-status" style="background:var(--gradient);"></span>Executive Overview</a>\n'

    TYPE_LABELS = {"CV": "Computer Vision", "LLM": "Large Language Models"}
    CATEGORY_LABELS = {
        "MOD": "Model Security",
        "APP": "Application Security",
        "INF": "Infrastructure Security",
        "DAT": "Data Governance",
    }

    for mtype in ["CV", "LLM"]:
        models_in_type = models_by_type.get(mtype, [])
        if not models_in_type:
            continue
        type_label = TYPE_LABELS.get(mtype, mtype)
        nav_items += f'<div class="sidebar-category">{_esc(mtype)} — {_esc(type_label)} ({len(models_in_type)})</div>\n'

        for model_name, data in models_in_type:
            model_id = model_name.replace(" ", "_").replace("-", "_").lower()
            summary = data.get("summary", {})
            fail_count = summary.get("fail", 0)
            sc = "fail" if fail_count > 0 else "pass" if summary.get("pass", 0) == summary.get("total", 0) else "warn"

            # Model entry (collapsible)
            nav_items += f'<a class="nav-item model-nav" data-target="model-{model_id}" onclick="toggleModelNav(this, \'{model_id}\')" style="padding-left:16px;font-weight:500;">'
            nav_items += f'<span class="nav-status {sc}"></span>'
            nav_items += f'<span style="flex:1;">{_esc(model_name)}</span>'
            nav_items += '<span class="model-chevron" style="font-size:10px;color:var(--text-muted);transition:transform 0.2s;">&#9654;</span></a>\n'

            # Sub-nav (hidden by default) - grouped by category
            tests = data.get("tests", [])
            test_groups = {}
            for t in tests:
                prefix = t["test_id"].split("-")[0]
                if prefix not in test_groups:
                    test_groups[prefix] = []
                test_groups[prefix].append(t)

            nav_items += f'<div class="model-subnav" id="subnav-{model_id}" style="display:none;padding-left:24px;">\n'
            for prefix in ["MOD", "APP", "INF", "DAT"]:
                group = test_groups.get(prefix, [])
                if not group:
                    continue
                g_fail = sum(1 for t in group if t["status"] == "FAIL")
                g_pass = sum(1 for t in group if t["status"] == "PASS")
                cat_sc = "fail" if g_fail > 0 else "pass" if g_pass == len(group) else "warn"
                cat_label = CATEGORY_LABELS.get(prefix, prefix)
                nav_items += '<div style="font-size:9px;text-transform:uppercase;letter-spacing:1px;color:var(--text-muted);padding:8px 0 2px;font-weight:600;">'
                nav_items += f'<span class="nav-status {cat_sc}" style="display:inline-block;vertical-align:middle;margin-right:4px;"></span>'
                nav_items += f'{_esc(prefix)} — {_esc(cat_label)}</div>\n'

                for t in group:
                    tid = t["test_id"]
                    card_id = f"test-{model_id}-{tid.replace('-', '').lower()}"
                    tsc = _status_css(t["status"])
                    short_name = t["test_name"][:30]
                    nav_items += f'<a class="nav-item" data-target="{card_id}" onclick="scrollToSection(\'{card_id}\')" style="padding-left:12px;font-size:12px;">'
                    nav_items += f'<span class="nav-status {tsc}"></span>'
                    nav_items += f'{_esc(tid)}: {_esc(short_name)}</a>\n'

            nav_items += '</div>\n'

    # ── Build main content ──
    content = ""

    # Executive overview section
    content += f"""
    <div id="section-overview" style="margin-bottom:48px;">
      <h2 style="margin-bottom:24px;background:var(--gradient);-webkit-background-clip:text;-webkit-text-fill-color:transparent;font-size:28px;">
        OWASP AI Security Assessment — All Models
      </h2>
      <div class="summary-grid">
        <div class="summary-card total"><div class="number">{len(all_models_data)}</div><div class="label">Models</div></div>
        <div class="summary-card total"><div class="number">{total_tests}</div><div class="label">Total Tests</div></div>
        <div class="summary-card pass"><div class="number">{total_pass}</div><div class="label">Passed</div></div>
        <div class="summary-card fail"><div class="number">{total_fail}</div><div class="label">Failed</div></div>
        <div class="summary-card warn"><div class="number">{total_warn}</div><div class="label">Warnings</div></div>
        <div class="summary-card error"><div class="number">{total_error}</div><div class="label">Errors</div></div>
      </div>
    """

    # Matrix table if executive data available
    if executive_data:
        matrix = executive_data.get("matrix", {})
        test_ids = executive_data.get("test_ids", [])
        per_model = executive_data.get("per_model_summary", {})
        if matrix and test_ids:
            header_cells = "".join(f"<th>{_esc(tid)}</th>" for tid in test_ids)
            rows = ""
            for mn in sorted(matrix.keys()):
                statuses = matrix[mn]
                info = per_model.get(mn, {})
                cells = ""
                for tid in test_ids:
                    status = statuses.get(tid, "-")
                    sc = _status_css(status) if status != "-" else "empty"
                    cells += f'<td><span class="matrix-cell {sc}">{_esc(status)}</span></td>'
                total_m = info.get("total", 0)
                passed_m = info.get("pass", 0)
                score = round(passed_m / total_m * 100) if total_m > 0 else 0
                score_sc = "pass" if score >= 80 else "warn" if score >= 50 else "fail"
                arch = info.get("arch", "")
                mtype = info.get("type", "").upper()
                mid = mn.replace(" ", "_").replace("-", "_").lower()
                rows += f"""<tr>
                  <td><a href="javascript:void(0)" onclick="scrollToSection('model-{mid}')" style="color:var(--accent-blue);text-decoration:none;font-weight:600;">{_esc(mn)}</a><br><small style="color:var(--text-muted)">{_esc(arch)} [{mtype}]</small></td>
                  {cells}
                  <td><span class="matrix-cell {score_sc}">{score}%</span></td>
                </tr>"""

            content += f"""
            <h3 style="margin:32px 0 16px;color:var(--accent-blue);">Model x Test Matrix</h3>
            <div class="matrix-container">
              <table class="matrix-table">
                <thead><tr><th>Model</th>{header_cells}<th>Score</th></tr></thead>
                <tbody>{rows}</tbody>
              </table>
            </div>
            """

    content += "</div>\n"  # close overview section

    # Per-model sections
    for mtype in ["CV", "LLM"]:
        models_in_type = models_by_type.get(mtype, [])
        if not models_in_type:
            continue
        type_label = TYPE_LABELS.get(mtype, mtype)
        content += f'<h2 style="margin:48px 0 24px;padding:16px 0;border-top:2px solid var(--border);color:var(--accent-purple);font-size:22px;">{_esc(mtype)} — {_esc(type_label)} ({len(models_in_type)} models)</h2>\n'

        for model_name, data in models_in_type:
            model_id = model_name.replace(" ", "_").replace("-", "_").lower()
            model = data.get("model", {})
            summary = data.get("summary", {})
            tests = data.get("tests", [])

            # Model type/server badges
            model_type = (model.get("type", "") or "").upper()
            type_colors = {"CV": "#2ea043", "LLM": "#9b51e0"}
            type_color = type_colors.get(model_type, "#636c76")
            type_badge = f'<span style="display:inline-block;padding:4px 12px;border-radius:16px;background:{type_color}33;color:{type_color};font-size:12px;font-weight:700;margin-left:12px;border:1px solid {type_color}66;">{_esc(model_type)}</span>' if model_type else ""
            server_type = (model.get("server", "") or "").upper()
            server_colors = {"TRITON": "#76b900", "VLLM": "#9b51e0", "CUSTOM": "#0693e3"}
            server_color = server_colors.get(server_type, "#636c76")
            server_badge = f'<span style="display:inline-block;padding:4px 12px;border-radius:16px;background:{server_color}33;color:{server_color};font-size:12px;font-weight:700;margin-left:8px;border:1px solid {server_color}66;">{_esc(server_type)}</span>' if server_type else ""

            content += f"""
            <div id="model-{model_id}" style="margin-bottom:48px;scroll-margin-top:80px;">
              <div class="model-info">
                <h2>{_esc(model_name)} {type_badge} {server_badge}</h2>
                <div class="model-info-grid">
                  <div class="model-info-item"><div class="label">Architecture</div><div>{_esc(model.get('arch', model.get('architecture','N/A')))}</div></div>
                  <div class="model-info-item"><div class="label">Task</div><div>{_esc(model.get('task','N/A'))}</div></div>
                  <div class="model-info-item"><div class="label">Tests</div><div>{summary.get('total',0)} ({summary.get('pass',0)} Pass / {summary.get('fail',0)} Fail / {summary.get('warn',0)} Warn)</div></div>
                  <div class="model-info-item"><div class="label">Server</div><div>{_esc(server_type)} @ {_esc(model.get('url',''))}</div></div>
                </div>
              </div>
            """

            # Group tests by category
            test_groups = {}
            for t in tests:
                prefix = t["test_id"].split("-")[0]
                if prefix not in test_groups:
                    test_groups[prefix] = []
                test_groups[prefix].append(t)

            for prefix in ["MOD", "APP", "INF", "DAT"]:
                group = test_groups.get(prefix, [])
                if not group:
                    continue
                cat_label = CATEGORY_LABELS.get(prefix, prefix)
                g_fail = sum(1 for t in group if t["status"] == "FAIL")
                g_pass = sum(1 for t in group if t["status"] == "PASS")
                cat_sc = "fail" if g_fail > 0 else "pass" if g_pass == len(group) else "warn"

                content += f"""
                <h4 style="margin:20px 0 12px;color:var(--accent-blue);font-size:14px;text-transform:uppercase;letter-spacing:1px;">
                  <span class="nav-status {cat_sc}" style="display:inline-block;vertical-align:middle;margin-right:8px;"></span>
                  {_esc(prefix)} — {_esc(cat_label)} ({g_pass}/{len(group)} passed)
                </h4>
                """

                for t in group:
                    tid = t["test_id"]
                    card_id = f"test-{model_id}-{tid.replace('-', '').lower()}"
                    sc = _status_css(t["status"])
                    phases_html = _render_phases(t.get("phases", []))
                    recs_html = _render_recommendations(t.get("recommendations", []))
                    tools = ", ".join(t.get("tools_used", [])) or "N/A"

                    content += f"""
                    <div class="test-card" id="{card_id}" data-status="{_esc(t['status'])}" style="scroll-margin-top:80px;">
                      <div class="test-card-header" onclick="toggleCard(this)">
                        <div class="test-card-title">
                          <span class="status-badge {sc}">{_esc(t['status'])}</span>
                          <div>
                            <h3>{_esc(tid)}: {_esc(t['test_name'])}</h3>
                            <div class="test-card-meta">OWASP: {_esc(t.get('owasp_ref',''))} | Tools: {_esc(tools)} | {t.get('duration_sec',0)}s</div>
                          </div>
                        </div>
                        <span class="chevron">&#9660;</span>
                      </div>
                      <div class="test-card-body">
                        {phases_html}
                        {recs_html}
                      </div>
                    </div>"""

            content += "</div>\n"  # close model section

    # Extra JS for unified report
    unified_js = """
// ── Scroll to any section ──
function scrollToSection(id) {
  const el = document.getElementById(id);
  if (el) {
    el.scrollIntoView({ behavior: 'smooth', block: 'start' });
    // If it's a test card, expand it
    if (el.classList.contains('test-card')) {
      el.classList.add('open');
    }
  }
  // Update active nav
  document.querySelectorAll('.nav-item').forEach(n => n.classList.remove('active'));
  const navItem = document.querySelector(`.nav-item[data-target="${id}"]`);
  if (navItem) navItem.classList.add('active');
}

// ── Toggle model sub-navigation ──
function toggleModelNav(el, modelId) {
  const subnav = document.getElementById('subnav-' + modelId);
  const chevron = el.querySelector('.model-chevron');
  if (subnav) {
    const isOpen = subnav.style.display !== 'none';
    subnav.style.display = isOpen ? 'none' : 'block';
    if (chevron) chevron.style.transform = isOpen ? '' : 'rotate(90deg)';
  }
  // Also scroll to the model section
  scrollToSection('model-' + modelId);
}

// Override search to also filter model sections
const origFilterTests = filterTests;
function filterTests(query) {
  query = query.toLowerCase();
  // Filter test cards
  document.querySelectorAll('.test-card').forEach(card => {
    const text = card.textContent.toLowerCase();
    const match = !query || text.includes(query);
    card.dataset.searchMatch = match ? '1' : '0';
    applyVisibility(card);
  });
  // Filter nav items
  document.querySelectorAll('.nav-item[data-target]').forEach(nav => {
    const text = nav.textContent.toLowerCase();
    nav.style.display = (!query || text.includes(query)) ? '' : 'none';
  });
  // Show all sub-navs when searching
  if (query) {
    document.querySelectorAll('.model-subnav').forEach(s => s.style.display = 'block');
  }
}
"""

    return f"""<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Tessera — Unified Report ({len(all_models_data)} Models)</title>
<style>{CSS}
.sidebar {{ width: 320px; }}
.main {{ margin-left: 320px; }}
@media (max-width: 768px) {{ .main {{ margin-left: 0; }} }}
</style>
</head>
<body>
<header class="header">
  <div class="header-left">
    <button onclick="toggleSidebar()" style="display:none;background:none;border:none;color:var(--text-primary);font-size:20px;cursor:pointer;" class="menu-btn">&#9776;</button>
    {TESSERA_LOGO_HTML}
    <div class="header-title">Tessera &middot; <span>AI Security Testing — Unified Report</span></div>
  </div>
  <div class="header-right">
    <span style="font-size:12px;color:var(--text-muted);">{_esc(project.get('name',''))} | {_esc(project.get('environment',''))} | {_esc(timestamp[:19])}</span>
  </div>
</header>

<aside class="sidebar">
  <div class="sidebar-section">
    <input class="sidebar-search" type="text" placeholder="Search models & tests..." oninput="filterTests(this.value)">
  </div>
  <div class="sidebar-section">
    <h3>Models & Tests</h3>
    {nav_items}
  </div>
</aside>

<main class="main">
  {content}
</main>

<footer class="footer">
  Tessera v1.0.0 | OWASP AI Security Testing Framework<br>
  Based on <a href="https://owasp.org/www-project-ai-testing-guide/">OWASP AI Testing Guide</a> | {len(all_models_data)} models | {total_tests} tests | Duration: {total_duration:.0f}s
</footer>

<script>{JS}
{unified_js}
</script>
<style>@media(max-width:768px){{.menu-btn{{display:block!important;}}}}</style>
</body>
</html>"""


def _wrap_html(title: str, nav_items: str, content: str,
               project: dict = None, timestamp: str = "", duration: float = 0) -> str:
    """Wrap content in the full interactive HTML shell."""
    project = project or {}
    return f"""<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>{_esc(title)}</title>
<style>{CSS}</style>
</head>
<body>
<header class="header">
  <div class="header-left">
    <button onclick="toggleSidebar()" style="display:none;background:none;border:none;color:var(--text-primary);font-size:20px;cursor:pointer;" class="menu-btn">&#9776;</button>
    {TESSERA_LOGO_HTML}
    <div class="header-title">Tessera &middot; <span>AI Security Testing</span></div>
  </div>
  <div class="header-right">
    <span style="font-size:12px;color:var(--text-muted);">{_esc(project.get('name',''))} | {_esc(project.get('environment',''))} | {_esc(timestamp[:19])}</span>
  </div>
</header>

<aside class="sidebar">
  <div class="sidebar-section">
    <input class="sidebar-search" type="text" placeholder="Search tests..." oninput="filterTests(this.value)">
  </div>
  <div class="sidebar-section">
    <h3>Navigation</h3>
    {nav_items}
  </div>
</aside>

<main class="main">
  {content}
</main>

<footer class="footer">
  Tessera v1.0.0 | OWASP AI Security Testing Framework<br>
  Based on <a href="https://owasp.org/www-project-ai-testing-guide/">OWASP AI Testing Guide</a> | Duration: {duration}s
</footer>

<script>{JS}</script>
<style>@media(max-width:768px){{.menu-btn{{display:block!important;}}}}</style>
</body>
</html>"""
