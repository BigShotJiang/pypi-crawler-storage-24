"""
Tessera — HuggingFace Inference API connector.

Wraps the HuggingFace Inference API for security testing of hosted models.
Supports text-generation and image-classification tasks.

Requires: HF_TOKEN environment variable.

Usage:
    client = HuggingFaceClient(model="meta-llama/Llama-3-8B-Instruct")
    response = client.chat("What is AI security?")
"""

import os

import requests


class HuggingFaceClient:
    """Client for HuggingFace Inference API."""

    API_BASE = "https://api-inference.huggingface.co"

    def __init__(self, model: str, token: str = None, timeout: int = 60):
        self.model = model
        self.token = token or os.environ.get("HF_TOKEN", "")
        self.timeout = timeout
        self.headers = {
            "Authorization": f"Bearer {self.token}",
            "Content-Type": "application/json",
        }

    def chat(self, prompt: str, system: str = None,
             temperature: float = 0.0, max_tokens: int = 512) -> dict:
        """Send a text generation request."""
        full_prompt = prompt
        if system:
            full_prompt = f"<|system|>{system}<|end|>\n<|user|>{prompt}<|end|>\n<|assistant|>"

        payload = {
            "inputs": full_prompt,
            "parameters": {
                "max_new_tokens": max_tokens,
                "temperature": max(temperature, 0.01),
                "return_full_text": False,
            },
        }

        try:
            resp = requests.post(
                f"{self.API_BASE}/models/{self.model}",
                headers=self.headers,
                json=payload,
                timeout=self.timeout,
            )
            resp.raise_for_status()
            data = resp.json()
            if isinstance(data, list) and data:
                return {"content": data[0].get("generated_text", "")}
            return {"content": str(data)}
        except Exception as e:
            return {"content": "", "error": str(e)}

    def classify_image(self, image_bytes: bytes) -> dict:
        """Send an image classification request."""
        try:
            resp = requests.post(
                f"{self.API_BASE}/models/{self.model}",
                headers={"Authorization": f"Bearer {self.token}"},
                data=image_bytes,
                timeout=self.timeout,
            )
            resp.raise_for_status()
            data = resp.json()
            if isinstance(data, list):
                return {
                    "predictions": data,
                    "top_label": data[0].get("label", "") if data else "",
                    "top_score": data[0].get("score", 0.0) if data else 0.0,
                }
            return {"predictions": data}
        except Exception as e:
            return {"predictions": [], "error": str(e)}

    def health_check(self) -> bool:
        """Check if the model is loaded and reachable."""
        try:
            resp = requests.get(
                f"{self.API_BASE}/models/{self.model}",
                headers=self.headers,
                timeout=10,
            )
            return resp.status_code == 200
        except Exception:
            return False
