"""
Anthropic API direct connector.
"""

from __future__ import annotations

import os


class AnthropicClient:
    """Anthropic Claude API client."""

    def __init__(self, model: str = "claude-sonnet-4-5-20250929", api_key: str = None):
        self.model = model
        self.api_key = api_key or os.environ.get("ANTHROPIC_API_KEY", "")

    def chat(self, prompt: str, system_prompt: str = None, max_tokens: int = 1024, temperature: float = 0.7) -> str:
        """Send a chat message via Anthropic API."""
        import anthropic

        client = anthropic.Anthropic(api_key=self.api_key)
        kwargs = {
            "model": self.model,
            "max_tokens": max_tokens,
            "messages": [{"role": "user", "content": prompt}],
        }
        if system_prompt:
            kwargs["system"] = system_prompt

        response = client.messages.create(**kwargs)
        return response.content[0].text

    def health_check(self) -> bool:
        try:
            self.chat("Hi", max_tokens=5)
            return True
        except Exception:
            return False
