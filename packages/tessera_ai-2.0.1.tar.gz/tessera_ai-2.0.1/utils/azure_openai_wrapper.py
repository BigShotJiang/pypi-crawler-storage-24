"""
Azure OpenAI connector.
"""

from __future__ import annotations

import os


class AzureOpenAIClient:
    """Azure OpenAI Service client."""

    def __init__(
        self,
        deployment: str,
        api_key: str = None,
        api_base: str = None,
        api_version: str = "2024-02-01",
    ):
        self.deployment = deployment
        self.api_key = api_key or os.environ.get("AZURE_OPENAI_API_KEY", "")
        self.api_base = api_base or os.environ.get("AZURE_OPENAI_ENDPOINT", "")
        self.api_version = api_version

    def chat(self, prompt: str, system_prompt: str = None, max_tokens: int = 1024, temperature: float = 0.7) -> str:
        """Send a chat message via Azure OpenAI."""
        import requests

        url = f"{self.api_base}/openai/deployments/{self.deployment}/chat/completions?api-version={self.api_version}"
        messages = []
        if system_prompt:
            messages.append({"role": "system", "content": system_prompt})
        messages.append({"role": "user", "content": prompt})

        resp = requests.post(
            url,
            headers={"api-key": self.api_key, "Content-Type": "application/json"},
            json={"messages": messages, "max_tokens": max_tokens, "temperature": temperature},
            timeout=60,
        )
        resp.raise_for_status()
        return resp.json()["choices"][0]["message"]["content"]

    def health_check(self) -> bool:
        try:
            self.chat("Hi", max_tokens=5)
            return True
        except Exception:
            return False
