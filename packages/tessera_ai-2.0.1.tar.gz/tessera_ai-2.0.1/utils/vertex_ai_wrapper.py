"""
Google Vertex AI connector.
"""

from __future__ import annotations

import os


class VertexAIClient:
    """Google Vertex AI client."""

    def __init__(
        self,
        model: str = "gemini-1.5-pro",
        project: str = None,
        location: str = "us-central1",
    ):
        self.model = model
        self.project = project or os.environ.get("GOOGLE_CLOUD_PROJECT", "")
        self.location = location

    def chat(self, prompt: str, system_prompt: str = None, max_tokens: int = 1024, temperature: float = 0.7) -> str:
        """Send a chat message via Vertex AI."""
        from google.cloud import aiplatform
        from vertexai.generative_models import GenerativeModel

        aiplatform.init(project=self.project, location=self.location)
        model = GenerativeModel(self.model)

        full_prompt = f"{system_prompt}\n\n{prompt}" if system_prompt else prompt
        response = model.generate_content(
            full_prompt,
            generation_config={"max_output_tokens": max_tokens, "temperature": temperature},
        )
        return response.text

    def health_check(self) -> bool:
        try:
            self.chat("Hi", max_tokens=5)
            return True
        except Exception:
            return False
