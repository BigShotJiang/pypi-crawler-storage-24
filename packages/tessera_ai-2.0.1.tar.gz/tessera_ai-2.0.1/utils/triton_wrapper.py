"""
Wraps NVIDIA Triton Inference Server as an ART BlackBoxClassifier.

This allows all ART attacks (evasion, membership inference, inversion)
to target live Triton models without any code changes.

Usage:
    classifier = make_art_classifier(
        triton_url="localhost:8000",
        model_name="my_classifier",
        input_shape=(3, 224, 224),
        num_classes=10,
    )
    # Now use classifier with any ART attack:
    from art.attacks.evasion import ProjectedGradientDescent
    attack = PGD(classifier, eps=0.3)
    x_adv = attack.generate(x=x_test)
"""

import numpy as np


def make_art_classifier(triton_url: str, model_name: str,
                        input_shape: tuple, num_classes: int,
                        protocol: str = "http"):
    """
    Create an ART BlackBoxClassifier wrapping a Triton endpoint.

    Args:
        triton_url: Triton server address (host:port)
        model_name: Model name in Triton model repository
        input_shape: Model input shape (C, H, W)
        num_classes: Number of output classes
        protocol: "http" or "grpc"

    Returns:
        ART BlackBoxClassifier instance
    """
    from art.estimators.classification import BlackBoxClassifierNeuralNetwork

    if protocol == "grpc":
        predict_fn = _make_grpc_predict(triton_url, model_name, num_classes)
    else:
        predict_fn = _make_http_predict(triton_url, model_name, num_classes)

    classifier = BlackBoxClassifierNeuralNetwork(
        predict_fn=predict_fn,
        input_shape=input_shape,
        nb_classes=num_classes,
        clip_values=(0.0, 1.0),
    )
    return classifier


def _make_http_predict(triton_url: str, model_name: str, num_classes: int):
    """Return a predict function using Triton HTTP protocol."""
    try:
        import tritonclient.http as httpclient
    except ImportError:
        # Fallback to raw requests
        return _make_requests_predict(triton_url, model_name, num_classes)

    client = httpclient.InferenceServerClient(url=triton_url)

    # Auto-detect input/output names from model metadata
    try:
        meta = client.get_model_metadata(model_name)
        input_name = meta["inputs"][0]["name"]
        output_name = meta["outputs"][0]["name"]
        input_dtype = meta["inputs"][0]["datatype"]
    except Exception:
        input_name = "input"
        output_name = "output"
        input_dtype = "FP32"

    np_dtype = {"FP32": np.float32, "FP16": np.float16,
                "INT8": np.int8, "UINT8": np.uint8}.get(input_dtype, np.float32)

    def predict(x: np.ndarray) -> np.ndarray:
        """Send batch to Triton, return (N, num_classes) probabilities."""
        results_all = []
        batch_size = x.shape[0]

        for i in range(batch_size):
            sample = x[i:i+1].astype(np_dtype)
            inp = httpclient.InferInput(input_name, sample.shape, input_dtype)
            inp.set_data_from_numpy(sample)
            try:
                result = client.infer(model_name, [inp],
                                      outputs=[httpclient.InferRequestedOutput(output_name)])
                out = result.as_numpy(output_name).flatten()
                # Ensure output is probability-like
                if out.shape[0] != num_classes:
                    out = out[:num_classes] if len(out) >= num_classes else \
                        np.pad(out, (0, num_classes - len(out)))
                # Softmax if not already probabilities
                if out.max() > 1.0 or out.min() < 0.0:
                    out = _softmax(out)
                results_all.append(out)
            except Exception:
                results_all.append(np.ones(num_classes) / num_classes)

        return np.array(results_all, dtype=np.float32)

    return predict


def _make_grpc_predict(triton_url: str, model_name: str, num_classes: int):
    """Return a predict function using Triton gRPC protocol."""
    import tritonclient.grpc as grpcclient

    client = grpcclient.InferenceServerClient(url=triton_url)
    meta = client.get_model_metadata(model_name)
    input_name = meta.inputs[0].name
    output_name = meta.outputs[0].name

    def predict(x: np.ndarray) -> np.ndarray:
        results_all = []
        for i in range(x.shape[0]):
            sample = x[i:i+1].astype(np.float32)
            inp = grpcclient.InferInput(input_name, sample.shape, "FP32")
            inp.set_data_from_numpy(sample)
            result = client.infer(model_name, [inp],
                                  outputs=[grpcclient.InferRequestedOutput(output_name)])
            out = result.as_numpy(output_name).flatten()[:num_classes]
            if out.max() > 1.0 or out.min() < 0.0:
                out = _softmax(out)
            results_all.append(out)
        return np.array(results_all, dtype=np.float32)

    return predict


def _make_requests_predict(triton_url: str, model_name: str, num_classes: int):
    """Fallback: raw HTTP requests to Triton v2 API."""
    import requests

    url = f"http://{triton_url}/v2/models/{model_name}/infer"

    def predict(x: np.ndarray) -> np.ndarray:
        results_all = []
        for i in range(x.shape[0]):
            sample = x[i:i+1].astype(np.float32)
            payload = {
                "inputs": [{
                    "name": "input",
                    "shape": list(sample.shape),
                    "datatype": "FP32",
                    "data": sample.flatten().tolist(),
                }]
            }
            try:
                resp = requests.post(url, json=payload, timeout=10)
                out = np.array(resp.json()["outputs"][0]["data"], dtype=np.float32)
                out = out[:num_classes]
                if out.max() > 1.0:
                    out = _softmax(out)
                results_all.append(out)
            except Exception:
                results_all.append(np.ones(num_classes) / num_classes)
        return np.array(results_all, dtype=np.float32)

    return predict


def check_triton_health(triton_url: str) -> dict:
    """Check if Triton server is alive and list loaded models."""
    import requests
    info = {"alive": False, "models": []}
    try:
        r = requests.get(f"http://{triton_url}/v2/health/ready", timeout=5)
        info["alive"] = r.status_code == 200
    except Exception:
        return info
    try:
        r = requests.get(f"http://{triton_url}/v2/repository/index", timeout=5)
        if r.status_code == 200:
            info["models"] = [m["name"] for m in r.json() if m.get("state") == "READY"]
    except Exception:
        pass
    return info


def _softmax(x):
    e = np.exp(x - np.max(x))
    return e / e.sum()
