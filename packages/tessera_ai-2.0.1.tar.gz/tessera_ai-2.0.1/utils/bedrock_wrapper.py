"""
Tessera — AWS Bedrock connector for LLM security testing.

Wraps AWS Bedrock invoke_model() for testing hosted foundation models.
Supports Claude, Titan, and Llama model families.

Requires: AWS credentials (AWS_ACCESS_KEY_ID, AWS_SECRET_ACCESS_KEY, AWS_REGION).

Usage:
    client = BedrockClient(model_id="anthropic.claude-3-sonnet-20240229-v1:0")
    response = client.chat("What is AI security?")
"""

import json
import os


class BedrockClient:
    """Client for AWS Bedrock foundation models."""

    def __init__(self, model_id: str,
                 region: str = None, timeout: int = 60):
        self.model_id = model_id
        self.region = region or os.environ.get("AWS_REGION", "us-east-1")
        self.timeout = timeout
        self._client = None

    def _get_client(self):
        """Lazy-init boto3 client."""
        if self._client is None:
            import boto3
            self._client = boto3.client(
                "bedrock-runtime",
                region_name=self.region,
            )
        return self._client

    def chat(self, prompt: str, system: str = None,
             temperature: float = 0.0, max_tokens: int = 512) -> dict:
        """Send a chat request to Bedrock."""
        try:
            client = self._get_client()

            if "anthropic" in self.model_id:
                return self._invoke_claude(client, prompt, system,
                                           temperature, max_tokens)
            elif "titan" in self.model_id:
                return self._invoke_titan(client, prompt, system,
                                          temperature, max_tokens)
            elif "llama" in self.model_id or "meta" in self.model_id:
                return self._invoke_llama(client, prompt, system,
                                          temperature, max_tokens)
            else:
                return self._invoke_claude(client, prompt, system,
                                           temperature, max_tokens)
        except Exception as e:
            return {"content": "", "error": str(e)}

    def _invoke_claude(self, client, prompt, system, temperature, max_tokens):
        """Invoke Anthropic Claude models."""
        messages = [{"role": "user", "content": prompt}]
        body = {
            "anthropic_version": "bedrock-2023-05-31",
            "max_tokens": max_tokens,
            "temperature": temperature,
            "messages": messages,
        }
        if system:
            body["system"] = system

        resp = client.invoke_model(
            modelId=self.model_id,
            contentType="application/json",
            accept="application/json",
            body=json.dumps(body),
        )
        data = json.loads(resp["body"].read())
        content = ""
        for block in data.get("content", []):
            if block.get("type") == "text":
                content += block.get("text", "")
        return {"content": content, "model": self.model_id}

    def _invoke_titan(self, client, prompt, system, temperature, max_tokens):
        """Invoke Amazon Titan models."""
        full_prompt = f"{system}\n\n{prompt}" if system else prompt
        body = {
            "inputText": full_prompt,
            "textGenerationConfig": {
                "maxTokenCount": max_tokens,
                "temperature": temperature,
            },
        }
        resp = client.invoke_model(
            modelId=self.model_id,
            contentType="application/json",
            accept="application/json",
            body=json.dumps(body),
        )
        data = json.loads(resp["body"].read())
        results = data.get("results", [{}])
        return {
            "content": results[0].get("outputText", "") if results else "",
            "model": self.model_id,
        }

    def _invoke_llama(self, client, prompt, system, temperature, max_tokens):
        """Invoke Meta Llama models."""
        full_prompt = prompt
        if system:
            full_prompt = (
                f"<|begin_of_text|><|start_header_id|>system<|end_header_id|>\n"
                f"{system}<|eot_id|><|start_header_id|>user<|end_header_id|>\n"
                f"{prompt}<|eot_id|><|start_header_id|>assistant<|end_header_id|>"
            )
        body = {
            "prompt": full_prompt,
            "max_gen_len": max_tokens,
            "temperature": temperature,
        }
        resp = client.invoke_model(
            modelId=self.model_id,
            contentType="application/json",
            accept="application/json",
            body=json.dumps(body),
        )
        data = json.loads(resp["body"].read())
        return {
            "content": data.get("generation", ""),
            "model": self.model_id,
        }

    def health_check(self) -> bool:
        """Check if Bedrock is accessible."""
        try:
            self._get_client()
            return True
        except Exception:
            return False
