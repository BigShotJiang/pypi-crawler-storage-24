"""
Tessera — Connector factory for auto-selecting the right LLM/CV client.

Routes to the correct connector based on model config type.

Usage:
    from utils.connector_factory import get_llm_client
    client = get_llm_client(config, target_model)
    response = client.chat("Hello")
"""


def get_llm_client(config: dict, target_model: dict = None):
    """Auto-select and return the appropriate LLM client.

    Routing logic:
        - target_model._server_type == "vllm"       -> LLMClient (OpenAI-compat)
        - target_model._server_type == "ollama"      -> OllamaClient
        - target_model._server_type == "huggingface" -> HuggingFaceClient
        - target_model._server_type == "bedrock"     -> BedrockClient
        - target_model._server_type == "custom"      -> LLMClient (OpenAI-compat)
        - config.models.ollama                       -> OllamaClient
        - config.models.huggingface                  -> HuggingFaceClient
        - config.models.bedrock                      -> BedrockClient
        - config.models.vllm / config.models.openai  -> LLMClient

    Returns:
        A client instance with .chat() and .health_check() methods, or None.
    """
    if target_model:
        server_type = target_model.get("_server_type", "")
        url = target_model.get("_url", "")
        model_name = target_model.get("name", "")

        if server_type == "ollama":
            from utils.ollama_wrapper import OllamaClient
            return OllamaClient(base_url=url, model=model_name)

        if server_type == "huggingface":
            from utils.huggingface_wrapper import HuggingFaceClient
            token = config.get("models", {}).get("huggingface", {}).get("token")
            return HuggingFaceClient(model=model_name, token=token)

        if server_type == "bedrock":
            from utils.bedrock_wrapper import BedrockClient
            region = config.get("models", {}).get("bedrock", {}).get("region")
            return BedrockClient(model_id=model_name, region=region)

        if server_type in ("vllm", "openai"):
            from utils.llm_wrapper import LLMClient
            api_base = config.get("models", {}).get(server_type, {}).get("api_base", "/v1")
            api_key = config.get("models", {}).get(server_type, {}).get("api_key", "EMPTY")
            base_url = f"http://{url}{api_base}" if not url.startswith("http") else f"{url}{api_base}"
            return LLMClient(base_url=base_url, model=model_name, api_key=api_key)

        if server_type == "azure_openai":
            from utils.azure_openai_wrapper import AzureOpenAIClient
            cfg = config.get("models", {}).get("azure_openai", {})
            return AzureOpenAIClient(
                deployment=model_name,
                api_key=cfg.get("api_key"),
                api_base=url or cfg.get("endpoint", ""),
                api_version=cfg.get("api_version", "2024-02-01"),
            )

        if server_type == "vertex_ai":
            from utils.vertex_ai_wrapper import VertexAIClient
            cfg = config.get("models", {}).get("vertex_ai", {})
            return VertexAIClient(
                model=model_name,
                project=cfg.get("project"),
                location=cfg.get("location", "us-central1"),
            )

        if server_type == "anthropic":
            from utils.anthropic_wrapper import AnthropicClient
            cfg = config.get("models", {}).get("anthropic", {})
            return AnthropicClient(
                model=model_name,
                api_key=cfg.get("api_key"),
            )

        if server_type == "litellm":
            from utils.litellm_wrapper import LiteLLMClient
            cfg = config.get("models", {}).get("litellm", {})
            return LiteLLMClient(
                model=model_name,
                api_key=cfg.get("api_key"),
                api_base=url or cfg.get("api_base"),
            )

        if server_type == "custom":
            from utils.llm_wrapper import LLMClient
            return LLMClient(base_url=url)

    # Fallback: scan config for available endpoints
    models_cfg = config.get("models", {})

    if "ollama" in models_cfg:
        from utils.ollama_wrapper import OllamaClient
        cfg = models_cfg["ollama"]
        return OllamaClient(
            base_url=cfg.get("url", "http://localhost:11434"),
            model=cfg.get("model", "llama3"),
        )

    if "huggingface" in models_cfg:
        from utils.huggingface_wrapper import HuggingFaceClient
        cfg = models_cfg["huggingface"]
        return HuggingFaceClient(
            model=cfg.get("model", ""),
            token=cfg.get("token"),
        )

    if "bedrock" in models_cfg:
        from utils.bedrock_wrapper import BedrockClient
        cfg = models_cfg["bedrock"]
        return BedrockClient(
            model_id=cfg.get("model_id", ""),
            region=cfg.get("region"),
        )

    if "vllm" in models_cfg:
        from utils.llm_wrapper import LLMClient
        cfg = models_cfg["vllm"]
        url = cfg.get("url", "localhost:8000")
        api_base = cfg.get("api_base", "/v1")
        model_name = cfg.get("models", [{}])[0].get("name")
        return LLMClient(
            base_url=f"http://{url}{api_base}",
            model=model_name,
        )

    if "azure_openai" in models_cfg:
        from utils.azure_openai_wrapper import AzureOpenAIClient
        cfg = models_cfg["azure_openai"]
        return AzureOpenAIClient(
            deployment=cfg.get("deployment", ""),
            api_key=cfg.get("api_key"),
            api_base=cfg.get("endpoint", ""),
        )

    if "anthropic" in models_cfg:
        from utils.anthropic_wrapper import AnthropicClient
        cfg = models_cfg["anthropic"]
        return AnthropicClient(
            model=cfg.get("model", "claude-sonnet-4-5-20250929"),
            api_key=cfg.get("api_key"),
        )

    if "vertex_ai" in models_cfg:
        from utils.vertex_ai_wrapper import VertexAIClient
        cfg = models_cfg["vertex_ai"]
        return VertexAIClient(
            model=cfg.get("model", "gemini-1.5-pro"),
            project=cfg.get("project"),
            location=cfg.get("location", "us-central1"),
        )

    # LiteLLM as universal fallback
    if "litellm" in models_cfg:
        from utils.litellm_wrapper import LiteLLMClient
        cfg = models_cfg["litellm"]
        return LiteLLMClient(
            model=cfg.get("model", ""),
            api_key=cfg.get("api_key"),
            api_base=cfg.get("api_base"),
        )

    return None
