"""
AITG-INF-03 — Testing for Model Serving API Security

3-Phase OWASP Methodology:
    Phase 1: Probe model serving endpoints for auth, rate limits, input validation, TLS
    Phase 2: Quantitative metrics (unauthenticated endpoints, missing rate limits, TLS gaps)
    Phase 3: Defense validation (API gateway config, ingress rules, input size limits)

Tools: Triton Client, requests, Custom
Ref:   https://github.com/OWASP/www-project-ai-testing-guide/blob/main/Document/content/tests/AITG-INF-03_Testing_for_Plugin_Boundary_Violations.md
"""

import json
import os
import subprocess

from tests.base import Metric, OWASPTestCase, PhaseResult

try:
    import requests as req_lib
except ImportError:
    req_lib = None


class INF03APISecurity(OWASPTestCase):
    TEST_ID = "INF-03"
    TEST_NAME = "Testing for Model Serving API Security"
    CATEGORY = "AI Infrastructure Security"
    OWASP_REF = "AITG-INF-03"
    TOOLS = ["Triton Client", "requests", "Custom"]

    def __init__(self, config: dict, target_model: dict = None):
        super().__init__(config, target_model)
        self._unauthenticated_endpoints = []
        self._missing_rate_limit_endpoints = []
        self._no_tls_endpoints = []
        self._metadata_exposed_endpoints = []
        self._endpoint_findings = {}

    def _build_endpoint_list(self, config: dict) -> list:
        """Build list of model serving endpoints to test from config."""
        endpoints = []

        # Triton endpoints
        triton_cfg = config.get("models", {}).get("triton", {})
        if triton_cfg:
            url = triton_cfg.get("url", "")
            protocol = triton_cfg.get("protocol", "http")
            base = f"{protocol}://{url}"
            endpoints.append({
                "name": "triton-health",
                "url": f"{base}/v2/health/ready",
                "type": "triton",
                "method": "GET",
            })
            endpoints.append({
                "name": "triton-models",
                "url": f"{base}/v2/models",
                "type": "triton",
                "method": "GET",
            })
            for model in triton_cfg.get("models", []):
                model_name = model.get("name", "")
                endpoints.append({
                    "name": f"triton-model-{model_name}",
                    "url": f"{base}/v2/models/{model_name}",
                    "type": "triton",
                    "method": "GET",
                })
                endpoints.append({
                    "name": f"triton-infer-{model_name}",
                    "url": f"{base}/v2/models/{model_name}/infer",
                    "type": "triton-infer",
                    "method": "POST",
                    "model_cfg": model,
                })

        # vLLM endpoints
        vllm_cfg = config.get("models", {}).get("vllm", {})
        if vllm_cfg:
            url = vllm_cfg.get("url", "")
            api_base = vllm_cfg.get("api_base", "/v1")
            base = f"http://{url}{api_base}"
            endpoints.append({
                "name": "vllm-models",
                "url": f"{base}/models",
                "type": "vllm",
                "method": "GET",
            })
            for model in vllm_cfg.get("models", []):
                model_name = model.get("name", "")
                endpoints.append({
                    "name": f"vllm-chat-{model_name}",
                    "url": f"{base}/chat/completions",
                    "type": "vllm-chat",
                    "method": "POST",
                    "model_cfg": model,
                })

        # Custom endpoints
        for ep in config.get("models", {}).get("custom", []):
            endpoints.append({
                "name": ep.get("name", "custom"),
                "url": ep.get("url", ""),
                "type": "custom",
                "method": "GET",
            })

        return endpoints

    def _test_authentication(self, endpoint: dict) -> dict:
        """Test if endpoint requires authentication."""
        result = {"endpoint": endpoint["name"], "authenticated": False, "status_code": None}
        if req_lib is None:
            result["error"] = "requests library not installed"
            return result

        try:
            # Try accessing without any credentials
            resp = req_lib.request(
                endpoint.get("method", "GET"),
                endpoint["url"],
                timeout=10,
                verify=False,
            )
            result["status_code"] = resp.status_code
            # If we get 200/405 without auth, endpoint is unauthenticated
            if resp.status_code in (200, 405):
                result["authenticated"] = False
            elif resp.status_code in (401, 403):
                result["authenticated"] = True
            else:
                result["authenticated"] = False  # Unclear, treat as open
        except req_lib.exceptions.SSLError:
            result["error"] = "SSL error"
        except req_lib.exceptions.ConnectionError:
            result["error"] = "Connection refused"
        except req_lib.exceptions.Timeout:
            result["error"] = "Timeout"
        except Exception as e:
            result["error"] = str(e)

        return result

    def _test_rate_limiting(self, endpoint: dict) -> dict:
        """Test if endpoint has rate limiting by sending rapid requests."""
        result = {
            "endpoint": endpoint["name"],
            "rate_limited": False,
            "requests_sent": 0,
            "rate_limit_hit_at": None,
        }
        if req_lib is None:
            result["error"] = "requests library not installed"
            return result

        try:
            # Send 20 rapid requests and check for 429
            for i in range(20):
                resp = req_lib.request(
                    endpoint.get("method", "GET"),
                    endpoint["url"],
                    timeout=5,
                    verify=False,
                )
                result["requests_sent"] = i + 1
                if resp.status_code == 429:
                    result["rate_limited"] = True
                    result["rate_limit_hit_at"] = i + 1
                    break
                # Also check for rate limit headers
                if any(h in resp.headers for h in
                       ["X-RateLimit-Limit", "X-Rate-Limit-Limit",
                        "RateLimit-Limit", "Retry-After"]):
                    result["rate_limited"] = True
                    result["rate_limit_hit_at"] = i + 1
                    break
        except req_lib.exceptions.ConnectionError:
            result["error"] = "Connection refused"
        except Exception as e:
            result["error"] = str(e)

        return result

    def _test_tls(self, endpoint: dict) -> dict:
        """Test if endpoint supports TLS."""
        result = {"endpoint": endpoint["name"], "tls": False}
        url = endpoint.get("url", "")

        # Check if URL uses HTTPS
        if url.startswith("https://"):
            result["tls"] = True
            if req_lib:
                try:
                    # Verify TLS certificate is valid
                    req_lib.get(url, timeout=5, verify=True)
                    result["tls_valid"] = True
                except req_lib.exceptions.SSLError:
                    result["tls_valid"] = False
                    result["tls_error"] = "Invalid or self-signed certificate"
                except Exception:
                    result["tls_valid"] = None
        else:
            result["tls"] = False

        return result

    def _test_cors(self, endpoint: dict) -> dict:
        """Test CORS headers on endpoint."""
        result = {"endpoint": endpoint["name"], "cors_open": False}
        if req_lib is None:
            return result

        try:
            resp = req_lib.options(
                endpoint["url"],
                headers={"Origin": "http://evil.example.com"},
                timeout=5,
                verify=False,
            )
            acao = resp.headers.get("Access-Control-Allow-Origin", "")
            if acao == "*":
                result["cors_open"] = True
                result["acao"] = acao
            elif "evil.example.com" in acao:
                result["cors_open"] = True
                result["acao"] = acao
        except Exception:
            pass

        return result

    def _test_input_validation(self, endpoint: dict) -> dict:
        """Test input validation with malformed/oversized payloads."""
        result = {
            "endpoint": endpoint["name"],
            "accepts_malformed": False,
            "accepts_oversized": False,
            "accepts_wrong_content_type": False,
        }
        if req_lib is None or endpoint.get("method") != "POST":
            return result

        try:
            # Test 1: Malformed JSON
            resp = req_lib.post(
                endpoint["url"],
                data="{{{{invalid json",
                headers={"Content-Type": "application/json"},
                timeout=10,
                verify=False,
            )
            if resp.status_code == 200:
                result["accepts_malformed"] = True

            # Test 2: Wrong content type
            resp = req_lib.post(
                endpoint["url"],
                data="random text data",
                headers={"Content-Type": "text/plain"},
                timeout=10,
                verify=False,
            )
            if resp.status_code == 200:
                result["accepts_wrong_content_type"] = True

            # Test 3: Oversized payload (1MB of random data)
            oversized_data = json.dumps({"data": "A" * (1024 * 1024)})
            resp = req_lib.post(
                endpoint["url"],
                data=oversized_data,
                headers={"Content-Type": "application/json"},
                timeout=15,
                verify=False,
            )
            if resp.status_code == 200:
                result["accepts_oversized"] = True

        except req_lib.exceptions.ConnectionError:
            result["error"] = "Connection refused"
        except Exception as e:
            result["error"] = str(e)

        return result

    def _test_metadata_exposure(self, endpoint: dict) -> dict:
        """Check if model metadata is publicly accessible."""
        result = {"endpoint": endpoint["name"], "metadata_exposed": False, "metadata": {}}
        if req_lib is None:
            return result

        try:
            resp = req_lib.get(endpoint["url"], timeout=10, verify=False)
            if resp.status_code == 200:
                try:
                    data = resp.json()
                    # Check if response reveals model architecture, version, or config
                    sensitive_keys = ["platform", "backend", "version", "config",
                                     "parameters", "input", "output"]
                    exposed = {k: v for k, v in data.items() if k in sensitive_keys}
                    if exposed:
                        result["metadata_exposed"] = True
                        result["metadata"] = {k: str(v)[:200] for k, v in exposed.items()}
                except (json.JSONDecodeError, ValueError):
                    pass
        except Exception:
            pass

        return result

    def phase1_attack(self, config: dict) -> PhaseResult:
        """Phase 1: Probe model serving endpoints for security weaknesses."""
        pr = PhaseResult(phase=1, name="Model Serving API Security Scan")

        if req_lib is None:
            pr.evidence.append("requests library not installed — cannot perform API probes")
            pr.status = "ERROR"
            pr.error = "Missing dependency: requests"
            return pr

        # Suppress SSL warnings for testing
        import urllib3
        urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

        endpoints = self._build_endpoint_list(config)
        pr.evidence.append(f"Endpoints to test: {len(endpoints)}")

        for ep in endpoints:
            ep_findings = {"endpoint": ep["name"]}

            # Test 1: Authentication
            auth_result = self._test_authentication(ep)
            ep_findings["auth"] = auth_result
            if not auth_result.get("authenticated") and not auth_result.get("error"):
                self._unauthenticated_endpoints.append(ep["name"])
                pr.evidence.append(
                    f"FINDING: {ep['name']} — no authentication required "
                    f"(HTTP {auth_result.get('status_code')})"
                )

            # Test 2: Rate limiting (only on reachable non-POST endpoints to avoid load)
            if not auth_result.get("error") and ep.get("method") == "GET":
                rate_result = self._test_rate_limiting(ep)
                ep_findings["rate_limit"] = rate_result
                if not rate_result.get("rate_limited") and not rate_result.get("error"):
                    self._missing_rate_limit_endpoints.append(ep["name"])
                    pr.evidence.append(
                        f"FINDING: {ep['name']} — no rate limiting detected "
                        f"({rate_result['requests_sent']} requests sent)"
                    )

            # Test 3: TLS
            tls_result = self._test_tls(ep)
            ep_findings["tls"] = tls_result
            if not tls_result.get("tls"):
                self._no_tls_endpoints.append(ep["name"])

            # Test 4: Metadata exposure (model info endpoints)
            if ep.get("method") == "GET" and "model" in ep.get("name", ""):
                meta_result = self._test_metadata_exposure(ep)
                ep_findings["metadata"] = meta_result
                if meta_result.get("metadata_exposed"):
                    self._metadata_exposed_endpoints.append(ep["name"])
                    pr.evidence.append(
                        f"FINDING: {ep['name']} — model metadata exposed: "
                        f"{list(meta_result.get('metadata', {}).keys())}"
                    )

            # Test 5: Input validation (POST endpoints only)
            if ep.get("method") == "POST" and not auth_result.get("error"):
                input_result = self._test_input_validation(ep)
                ep_findings["input_validation"] = input_result
                if input_result.get("accepts_malformed"):
                    pr.evidence.append(f"FINDING: {ep['name']} — accepts malformed JSON")
                if input_result.get("accepts_oversized"):
                    pr.evidence.append(f"FINDING: {ep['name']} — accepts oversized payloads (1MB+)")

            # Test 6: CORS
            if not auth_result.get("error"):
                cors_result = self._test_cors(ep)
                ep_findings["cors"] = cors_result
                if cors_result.get("cors_open"):
                    pr.evidence.append(
                        f"FINDING: {ep['name']} — permissive CORS "
                        f"(Access-Control-Allow-Origin: {cors_result.get('acao')})"
                    )

            self._endpoint_findings[ep["name"]] = ep_findings

        # Summary
        if self._no_tls_endpoints:
            pr.evidence.append(
                f"Endpoints without TLS: {len(self._no_tls_endpoints)} — "
                f"{', '.join(self._no_tls_endpoints[:5])}"
            )

        pr.status = "PASS"
        return pr

    def phase2_measure(self, config: dict) -> PhaseResult:
        """Phase 2: Quantitative API security metrics."""
        pr = PhaseResult(phase=2, name="API Security Metrics")

        # Metric 1: Unauthenticated endpoints
        unauth_count = len(self._unauthenticated_endpoints)
        pr.metrics.append(Metric(
            name="Unauthenticated model endpoints",
            value=unauth_count,
            threshold_pass=0,
            threshold_fail=3,
            unit="count",
            operator="<",
            source="OWASP AITG-INF-03 §2 | https://github.com/OWASP/www-project-ai-testing-guide/blob/main/Document/content/tests/AITG-INF-03_Testing_for_Plugin_Boundary_Violations.md",
        ))

        # Metric 2: Endpoints missing rate limiting
        no_rate_count = len(self._missing_rate_limit_endpoints)
        pr.metrics.append(Metric(
            name="Endpoints without rate limiting",
            value=no_rate_count,
            threshold_pass=0,
            threshold_fail=3,
            unit="count",
            operator="<",
            source="OWASP AITG-INF-03 §2 | https://github.com/OWASP/www-project-ai-testing-guide/blob/main/Document/content/tests/AITG-INF-03_Testing_for_Plugin_Boundary_Violations.md",
        ))

        # Metric 3: Endpoints without TLS
        no_tls_count = len(self._no_tls_endpoints)
        pr.metrics.append(Metric(
            name="Endpoints without TLS",
            value=no_tls_count,
            threshold_pass=0,
            threshold_fail=1,
            unit="count",
            operator="<",
            source="OWASP AITG-INF-03 §2 | https://github.com/OWASP/www-project-ai-testing-guide/blob/main/Document/content/tests/AITG-INF-03_Testing_for_Plugin_Boundary_Violations.md",
        ))

        # Metric 4: Endpoints exposing model metadata
        meta_count = len(self._metadata_exposed_endpoints)
        pr.metrics.append(Metric(
            name="Endpoints exposing model metadata",
            value=meta_count,
            threshold_pass=0,
            threshold_fail=3,
            unit="count",
            operator="<",
            source="OWASP AITG-INF-03 §2 | https://github.com/OWASP/www-project-ai-testing-guide/blob/main/Document/content/tests/AITG-INF-03_Testing_for_Plugin_Boundary_Violations.md",
        ))

        pr.evidence.append(
            f"unauthenticated={unauth_count}, no_rate_limit={no_rate_count}, "
            f"no_tls={no_tls_count}, metadata_exposed={meta_count}"
        )
        return pr

    def phase3_defend(self, config: dict) -> PhaseResult:
        """Phase 3: Defense validation — API gateway, ingress, input size limits."""
        pr = PhaseResult(phase=3, name="API Security Defense Validation")

        # Check for API gateway / ingress in Kubernetes
        k8s_cfg = config.get("kubernetes", {})
        kubeconfig = k8s_cfg.get("kubeconfig", "")
        if kubeconfig:
            env = os.environ.copy()
            env["KUBECONFIG"] = kubeconfig

            # Check for Ingress resources
            try:
                result = subprocess.run(
                    ["kubectl", "get", "ingress", "--all-namespaces", "-o", "json"],
                    capture_output=True, text=True, timeout=30, env=env,
                )
                if result.returncode == 0:
                    data = json.loads(result.stdout)
                    ingresses = data.get("items", [])
                    pr.evidence.append(f"Ingress resources found: {len(ingresses)}")
                    for ing in ingresses:
                        name = ing.get("metadata", {}).get("name", "")
                        ns = ing.get("metadata", {}).get("namespace", "")
                        annotations = ing.get("metadata", {}).get("annotations", {})
                        # Check for rate limiting annotations
                        rate_limit_keys = [k for k in annotations
                                           if "rate" in k.lower() or "limit" in k.lower()]
                        # Check for auth annotations
                        auth_keys = [k for k in annotations
                                     if "auth" in k.lower()]
                        pr.evidence.append(
                            f"  Ingress {ns}/{name}: "
                            f"rate_limit_annotations={len(rate_limit_keys)}, "
                            f"auth_annotations={len(auth_keys)}"
                        )
            except (FileNotFoundError, subprocess.TimeoutExpired, json.JSONDecodeError) as e:
                pr.evidence.append(f"Ingress check failed: {e}")

            # Check for Gateway API resources
            try:
                result = subprocess.run(
                    ["kubectl", "get", "httproutes", "--all-namespaces", "-o", "json"],
                    capture_output=True, text=True, timeout=30, env=env,
                )
                if result.returncode == 0:
                    data = json.loads(result.stdout)
                    routes = data.get("items", [])
                    pr.evidence.append(f"Gateway API HTTPRoutes found: {len(routes)}")
            except (FileNotFoundError, subprocess.TimeoutExpired, json.JSONDecodeError):
                pass  # Gateway API may not be installed

            # Check for NetworkPolicies protecting model serving namespaces
            try:
                result = subprocess.run(
                    ["kubectl", "get", "networkpolicies", "--all-namespaces", "-o", "json"],
                    capture_output=True, text=True, timeout=30, env=env,
                )
                if result.returncode == 0:
                    data = json.loads(result.stdout)
                    policies = data.get("items", [])
                    pr.evidence.append(f"NetworkPolicies found: {len(policies)}")
            except (FileNotFoundError, subprocess.TimeoutExpired, json.JSONDecodeError):
                pass

        self.result.recommendations = [
            {"text": "Add authentication (API key or mTLS) to all model serving endpoints",
             "url": "https://kubernetes.io/docs/concepts/security/"},
            {"text": "Implement rate limiting on all inference endpoints (e.g., nginx rate-limit annotations)",
             "url": "https://kubernetes.io/docs/concepts/security/"},
            {"text": "Enable TLS termination at ingress/gateway for all model APIs",
             "url": "https://kubernetes.io/docs/concepts/security/"},
            {"text": "Restrict model metadata access (/v2/models) to authorized clients only",
             "url": "https://kubernetes.io/docs/concepts/security/"},
            {"text": "Add input size limits on inference endpoints (max payload size)",
             "url": "https://kubernetes.io/docs/concepts/security/"},
            {"text": "Deploy API gateway (Kong, Envoy, APISIX) with security policies",
             "url": "https://kubernetes.io/docs/concepts/security/"},
            {"text": "Implement CORS policies — never use Access-Control-Allow-Origin: *",
             "url": "https://kubernetes.io/docs/concepts/security/"},
            {"text": "Add request validation middleware to reject malformed inputs",
             "url": "https://kubernetes.io/docs/concepts/security/"},
        ]

        pr.status = "PASS"
        return pr


# -- Standalone execution -----------------------------------------------
if __name__ == "__main__":
    import sys

    import yaml
    cfg_path = sys.argv[1] if len(sys.argv) > 1 else "config.yaml"
    with open(cfg_path) as f:
        cfg = yaml.safe_load(f)
    test = INF03APISecurity(cfg)
    result = test.run()
    print(json.dumps(result.to_dict(), indent=2, default=str))
