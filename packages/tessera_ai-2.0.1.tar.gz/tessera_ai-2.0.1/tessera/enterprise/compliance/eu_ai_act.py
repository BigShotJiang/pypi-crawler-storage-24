"""
EU AI Act — Regulation (EU) 2024/1689 compliance mapping.

Maps Tessera test IDs to relevant articles and requirements.
"""

EU_AI_ACT_MAPPING = {
    "MOD-01": {
        "article": "Article 15 — Accuracy, Robustness & Cybersecurity",
        "requirement": "High-risk AI systems shall be resilient against attempts by unauthorized third parties to alter their use, outputs or performance by exploiting system vulnerabilities.",
        "risk_level": "high",
    },
    "MOD-02": {
        "article": "Article 15(4) — Resilience to Data Poisoning",
        "requirement": "Technical solutions to address AI specific vulnerabilities including data poisoning.",
        "risk_level": "high",
    },
    "MOD-03": {
        "article": "Article 10 — Data and Data Governance",
        "requirement": "Training, validation and testing data sets shall be relevant, sufficiently representative and, to the best extent possible, free of errors and complete.",
        "risk_level": "high",
    },
    "MOD-06": {
        "article": "Article 9 — Risk Management System",
        "requirement": "Continuous iterative risk management process throughout the lifecycle, including monitoring for performance drift.",
        "risk_level": "high",
    },
    "MOD-07": {
        "article": "Article 14 — Human Oversight",
        "requirement": "High-risk AI systems shall be designed so they can be effectively overseen by natural persons.",
        "risk_level": "high",
    },
    "APP-01": {
        "article": "Article 15 — Cybersecurity",
        "requirement": "Protection against prompt injection and manipulation of AI system inputs.",
        "risk_level": "high",
    },
    "APP-03": {
        "article": "Article 10(5) — Personal Data Processing",
        "requirement": "Appropriate data governance and management practices, including safeguards for personal data.",
        "risk_level": "high",
    },
    "APP-10": {
        "article": "Article 10(2)(f) — Bias Detection",
        "requirement": "Examination in view of possible biases that are likely to affect the health and safety of persons.",
        "risk_level": "high",
    },
    "APP-14": {
        "article": "Article 13 — Transparency",
        "requirement": "High-risk AI systems shall be designed to ensure that their operation is sufficiently transparent to enable deployers to interpret the system's output.",
        "risk_level": "high",
    },
    "DAT-01": {
        "article": "Article 10(2) — Data Governance",
        "requirement": "Training, validation, testing data sets subject to appropriate data governance practices.",
        "risk_level": "high",
    },
    "DAT-02": {
        "article": "GDPR Article 5(1)(f) — Integrity and Confidentiality",
        "requirement": "Personal data processed in a manner that ensures appropriate security and confidentiality.",
        "risk_level": "high",
    },
    "DAT-04": {
        "article": "GDPR Article 17 — Right to Erasure",
        "requirement": "The data subject shall have the right to obtain erasure of personal data.",
        "risk_level": "high",
    },
}


def get_compliance_report(test_results: list[dict]) -> dict:
    """Generate EU AI Act compliance report from test results."""
    findings = []
    for result in test_results:
        test_id = result.get("test_id", "")
        mapping = EU_AI_ACT_MAPPING.get(test_id)
        if mapping:
            findings.append({
                "test_id": test_id,
                "test_name": result.get("test_name", ""),
                "test_status": result.get("status", ""),
                "article": mapping["article"],
                "requirement": mapping["requirement"],
                "risk_level": mapping["risk_level"],
                "compliant": result.get("status") in ("PASS", "N/A"),
            })

    compliant_count = sum(1 for f in findings if f["compliant"])
    return {
        "framework": "EU AI Act (Regulation 2024/1689)",
        "total_requirements": len(findings),
        "compliant": compliant_count,
        "non_compliant": len(findings) - compliant_count,
        "compliance_score": round(compliant_count / max(len(findings), 1) * 100, 1),
        "findings": findings,
    }
