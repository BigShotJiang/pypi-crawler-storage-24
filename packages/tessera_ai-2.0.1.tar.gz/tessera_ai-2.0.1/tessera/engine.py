"""
Tessera — Core scan engine.

Shared execution logic used by both CLI and API server.
Extracts run_tests(), run_per_model(), enumerate_models(), and helpers
from the monolithic tessera.py.
"""

from __future__ import annotations

import time
from datetime import datetime
from pathlib import Path
from typing import Any, Callable, Optional

from .registry import (
    MODEL_TYPE_TESTS,
    load_test_class,
)

# Type alias for progress callbacks
ProgressCallback = Optional[Callable[[dict], None]]


def check_dependencies() -> tuple[dict, dict]:
    """Check which optional dependencies are available.

    Returns:
        (available, missing) — dicts of {display_name: version_or_pkg}.
    """
    deps = {
        # MOD tests
        "ART (adversarial-robustness-toolbox)": "art",
        "Foolbox": "foolbox",
        "TextAttack": "textattack",
        "Cleanlab": "cleanlab",
        "Evidently AI": "evidently",
        "Alibi Detect": "alibi_detect",
        "DeepChecks": "deepchecks",
        "WhyLogs": "whylogs",
        "Opacus": "opacus",
        "Detoxify": "detoxify",
        "SHAP": "shap",
        "LIME": "lime",
        "Fairlearn": "fairlearn",
        "Scikit-learn": "sklearn",
        "PyTorch": "torch",
        "Pandas": "pandas",
        "SciPy": "scipy",
        "Triton Client (HTTP)": "tritonclient.http",
        "Triton Client (gRPC)": "tritonclient.grpc",
        "python-docx": "docx",
        # APP tests
        "LLM-Guard": "llm_guard",
        "Presidio Analyzer": "presidio_analyzer",
        "Presidio Anonymizer": "presidio_anonymizer",
        # INF tests
        "requests": "requests",
        "Safety": "safety",
        # DAT tests
        "DVC": "dvc",
        "MLflow": "mlflow",
    }

    available = {}
    missing = {}
    for name, pkg in deps.items():
        try:
            mod = __import__(pkg)
            version = getattr(mod, "__version__", "?")
            available[name] = version
        except ImportError:
            missing[name] = pkg

    return available, missing


def enumerate_models(config: dict) -> list[dict]:
    """Extract all models from config, annotate with _type, _server_type, _url."""
    models = []

    # Triton CV models
    triton_cfg = config.get("models", {}).get("triton", {})
    if triton_cfg:
        triton_url = triton_cfg.get("url", "")
        for m in triton_cfg.get("models", []):
            model = dict(m)
            model["_type"] = "cv"
            model["_server_type"] = "triton"
            model["_url"] = triton_url
            models.append(model)

    # vLLM models
    vllm_cfg = config.get("models", {}).get("vllm", {})
    if vllm_cfg:
        vllm_url = vllm_cfg.get("url", "")
        for m in vllm_cfg.get("models", []):
            model = dict(m)
            model["_type"] = "llm"
            model["_server_type"] = "vllm"
            model["_url"] = vllm_url
            models.append(model)

    # Ollama models
    ollama_cfg = config.get("models", {}).get("ollama", {})
    if ollama_cfg:
        ollama_url = ollama_cfg.get("url", "")
        for m in ollama_cfg.get("models", []):
            model = dict(m)
            model["_type"] = "llm"
            model["_server_type"] = "ollama"
            model["_url"] = ollama_url
            models.append(model)

    # Custom endpoints
    for m in config.get("models", {}).get("custom", []):
        model = dict(m)
        if m.get("task") in ("llm-agent", "chat", "code-generation"):
            model["_type"] = "llm"
        else:
            model["_type"] = "cv"
        model["_server_type"] = "custom"
        model["_url"] = m.get("url", "")
        models.append(model)

    return models


def get_applicable_tests(model: dict, available_tests: list[str]) -> list[str]:
    """Return test IDs applicable to a model based on its type."""
    model_type = model.get("_type", "cv")
    applicable = MODEL_TYPE_TESTS.get(model_type, [])
    return [t for t in applicable if t in available_tests]


def create_versioned_output_dir(base_dir: str) -> Path:
    """Create reports/YYYY-MM-DD/HH-MM-SS/ directory."""
    now = datetime.now()
    date_dir = now.strftime("%Y-%m-%d")
    time_dir = now.strftime("%H-%M-%S")
    path = Path(base_dir) / date_dir / time_dir
    path.mkdir(parents=True, exist_ok=True)
    return path


def _run_single_test(
    test_id: str,
    config: dict,
    phases: list[int] | None = None,
    target_model: dict | None = None,
    on_progress: ProgressCallback = None,
) -> Any:
    """Run a single test and return its TestResult (from tests.base)."""
    test_cls = load_test_class(test_id)
    if target_model:
        test = test_cls(config, target_model=target_model)
    else:
        test = test_cls(config)
    return test.run(phases=phases)


def run_tests(
    config: dict,
    test_ids: list[str],
    phases: list[int] | None = None,
    on_progress: ProgressCallback = None,
) -> tuple[list, float]:
    """Run tests in flat (legacy) mode.

    Args:
        config: Parsed YAML config dict.
        test_ids: List of test IDs to run.
        phases: Which phases to execute (default: [1,2,3]).
        on_progress: Optional callback for progress updates.

    Returns:
        (results_list, total_duration_sec)
    """
    results = []
    total_start = time.time()

    for i, test_id in enumerate(test_ids):
        if on_progress:
            on_progress({
                "current_test": test_id,
                "tests_completed": i,
                "tests_total": len(test_ids),
                "message": f"Running {test_id}...",
            })

        try:
            result = _run_single_test(test_id, config, phases)
            results.append(result)
        except Exception as e:
            if on_progress:
                on_progress({
                    "current_test": test_id,
                    "message": f"ERROR: {test_id}: {e}",
                })

    total_duration = round(time.time() - total_start, 2)

    if on_progress:
        on_progress({
            "tests_completed": len(test_ids),
            "tests_total": len(test_ids),
            "message": "Scan complete.",
        })

    return results, total_duration


def run_per_model(
    config: dict,
    test_ids: list[str],
    phases: list[int] | None = None,
    model_filter: list[str] | None = None,
    model_type_filter: str | None = None,
    on_progress: ProgressCallback = None,
) -> tuple[dict[str, list], list[dict], float]:
    """Run tests per-model.

    Args:
        config: Parsed YAML config dict.
        test_ids: List of test IDs to run.
        phases: Which phases to execute (default: [1,2,3]).
        model_filter: Only these model names.
        model_type_filter: Only "cv" or "llm".
        on_progress: Optional callback for progress updates.

    Returns:
        (all_results, all_models, total_duration_sec)
        all_results is {model_name: [TestResult, ...]}
    """
    all_models = enumerate_models(config)

    if model_filter:
        all_models = [m for m in all_models if m["name"] in model_filter]
    if model_type_filter:
        all_models = [m for m in all_models if m["_type"] == model_type_filter]

    total_start = time.time()
    all_results: dict[str, list] = {}

    for mi, model in enumerate(all_models):
        model_name = model["name"]
        applicable = get_applicable_tests(model, test_ids)

        if not applicable:
            continue

        model_results = []
        for ti, test_id in enumerate(applicable):
            if on_progress:
                on_progress({
                    "current_test": test_id,
                    "current_model": model_name,
                    "tests_completed": ti,
                    "tests_total": len(applicable),
                    "models_completed": mi,
                    "models_total": len(all_models),
                    "message": f"Running {test_id} on {model_name}...",
                })

            try:
                result = _run_single_test(test_id, config, phases, target_model=model)
                model_results.append(result)
            except Exception:
                pass

        if model_results:
            all_results[model_name] = model_results

    total_duration = round(time.time() - total_start, 2)

    if on_progress:
        on_progress({
            "models_completed": len(all_models),
            "models_total": len(all_models),
            "message": "Per-model scan complete.",
        })

    return all_results, all_models, total_duration


def build_flat_report(
    config: dict,
    results: list,
    total_duration: float,
    version: str = "2.0.0",
) -> dict:
    """Build report dict for flat (legacy) mode."""
    return {
        "framework": "Tessera",
        "version": version,
        "project": config.get("project", {}),
        "timestamp": datetime.now().isoformat(),
        "total_duration_sec": total_duration,
        "summary": {
            "total": len(results),
            "pass": sum(1 for r in results if r.status == "PASS"),
            "fail": sum(1 for r in results if r.status == "FAIL"),
            "warn": sum(1 for r in results if r.status == "WARN"),
            "error": sum(1 for r in results if r.status == "ERROR"),
            "na": sum(1 for r in results if r.status == "N/A"),
        },
        "tests": [r.to_dict() for r in results],
    }


def build_model_report(config: dict, model: dict, results: list, version: str = "2.0.0") -> dict:
    """Build report dict for a single model."""
    total_duration = sum(r.duration_sec for r in results)
    return {
        "framework": "Tessera",
        "version": version,
        "project": config.get("project", {}),
        "timestamp": datetime.now().isoformat(),
        "total_duration_sec": round(total_duration, 2),
        "model": {
            "name": model.get("name", ""),
            "arch": model.get("arch", ""),
            "type": model.get("_type", ""),
            "task": model.get("task", ""),
            "server": model.get("_server_type", ""),
            "url": model.get("_url", ""),
        },
        "summary": {
            "total": len(results),
            "pass": sum(1 for r in results if r.status == "PASS"),
            "fail": sum(1 for r in results if r.status == "FAIL"),
            "warn": sum(1 for r in results if r.status == "WARN"),
            "error": sum(1 for r in results if r.status == "ERROR"),
            "na": sum(1 for r in results if r.status == "N/A"),
        },
        "tests": [r.to_dict() for r in results],
    }


def build_executive_summary(
    config: dict,
    all_models: list[dict],
    all_results: dict[str, list],
    total_duration: float,
    version: str = "2.0.0",
) -> dict:
    """Build cross-model executive summary with model x test matrix."""
    matrix = {}
    for model_name, results in all_results.items():
        matrix[model_name] = {}
        for r in results:
            matrix[model_name][r.test_id] = r.status

    run_test_ids = sorted(set(
        tid for statuses in matrix.values() for tid in statuses.keys()
    ))

    per_model_summary = {}
    for model_name, results in all_results.items():
        model_info = next((m for m in all_models if m["name"] == model_name), {})
        per_model_summary[model_name] = {
            "arch": model_info.get("arch", ""),
            "type": model_info.get("_type", ""),
            "task": model_info.get("task", ""),
            "total": len(results),
            "pass": sum(1 for r in results if r.status == "PASS"),
            "fail": sum(1 for r in results if r.status == "FAIL"),
            "warn": sum(1 for r in results if r.status == "WARN"),
            "error": sum(1 for r in results if r.status == "ERROR"),
        }

    return {
        "framework": "Tessera",
        "version": version,
        "project": config.get("project", {}),
        "timestamp": datetime.now().isoformat(),
        "total_duration_sec": total_duration,
        "mode": "per-model",
        "models_tested": len(all_results),
        "models_total": len(all_models),
        "matrix": matrix,
        "test_ids": run_test_ids,
        "per_model_summary": per_model_summary,
    }
