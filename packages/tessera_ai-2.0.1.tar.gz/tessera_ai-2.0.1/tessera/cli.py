"""
Tessera — CLI entry point.

Thin wrapper that parses arguments and delegates to tessera.engine / tessera.reports.
"""

import argparse
import sys
from datetime import datetime
from pathlib import Path

from . import __version__
from .config import load_config
from .engine import (
    build_executive_summary,
    build_flat_report,
    build_model_report,
    check_dependencies,
    create_versioned_output_dir,
    run_per_model,
    run_tests,
)
from .registry import CATEGORY_MAP, TEST_REGISTRY
from .reports import write_executive_reports, write_reports


def _print_result(result):
    """Print a single test result to terminal."""
    status_icon = {
        "PASS": "[PASS]", "FAIL": "[FAIL]", "WARN": "[WARN]",
        "N/A": "[ NA ]", "ERROR": "[ERR ]",
    }.get(result.status, "[????]")

    print(f"\n  {status_icon} {result.test_id}: {result.test_name}")
    print(f"  Duration: {result.duration_sec}s")

    for phase in result.phases:
        phase_icon = {
            "PASS": "+", "FAIL": "X", "WARN": "!", "N/A": "-", "ERROR": "E",
        }.get(phase.status, "?")
        print(f"    [{phase_icon}] Phase {phase.phase}: {phase.name} ({phase.status})")
        for m in phase.metrics:
            print(f"        {m.name}: {m.value} {m.unit} [{m.status}]")
        for e in phase.evidence[:3]:
            print(f"        > {e[:100]}")
        if phase.error:
            print(f"        ERROR: {phase.error}")

    if result.recommendations:
        print("  Recommendations:")
        for r in result.recommendations[:5]:
            if isinstance(r, dict):
                print(f"    - {r.get('text', r)}")
            else:
                print(f"    - {r}")


def _run_flat_mode(config, test_ids, args):
    """Execute flat (legacy) mode scan."""
    output_path = Path(args.output)
    output_path.mkdir(parents=True, exist_ok=True)

    print("=" * 70)
    print("  Tessera — OWASP AI Security Scan")
    print(f"  Project: {config.get('project', {}).get('name', 'Unknown')}")
    print(f"  Environment: {config.get('project', {}).get('environment', 'Unknown')}")
    print(f"  Date: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    print(f"  Tests: {', '.join(test_ids)}")
    print("=" * 70)

    available, missing = check_dependencies()
    print(f"\n  Dependencies: {len(available)} available, {len(missing)} missing")
    if missing:
        print(f"  Missing: {', '.join(missing.keys())}")
    print()

    results, total_duration = run_tests(config, test_ids, phases=args.phases)

    for result in results:
        print(f"{'─' * 60}")
        _print_result(result)
        print()

    report_data = build_flat_report(config, results, total_duration)
    write_reports(report_data, output_path, args.format)

    s = report_data["summary"]
    print(f"\n{'=' * 70}")
    print(f"  TOTAL: {s['total']} tests | "
          f"PASS: {s['pass']} | FAIL: {s['fail']} | "
          f"WARN: {s['warn']} | ERROR: {s['error']} | N/A: {s['na']}")
    print(f"  Duration: {total_duration}s")
    print(f"{'=' * 70}")


def _run_per_model_mode(config, test_ids, args):
    """Execute per-model mode scan."""
    all_results, all_models, total_duration = run_per_model(
        config=config,
        test_ids=test_ids,
        phases=args.phases,
        model_filter=args.model,
        model_type_filter=args.model_type,
    )

    if not all_models:
        print("No models matched the filter criteria.")
        sys.exit(1)

    versioned_dir = create_versioned_output_dir(args.output)

    print("=" * 70)
    print("  Tessera — OWASP AI Security Scan (Per-Model Mode)")
    print(f"  Project: {config.get('project', {}).get('name', 'Unknown')}")
    print(f"  Environment: {config.get('project', {}).get('environment', 'Unknown')}")
    print(f"  Date: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    print(f"  Models: {len(all_models)}")
    print(f"  Output: {versioned_dir}")
    print("=" * 70)

    available, missing = check_dependencies()
    print(f"\n  Dependencies: {len(available)} available, {len(missing)} missing")
    if missing:
        print(f"  Missing: {', '.join(missing.keys())}")
    print()

    # Print results and write per-model reports
    for model in all_models:
        model_name = model["name"]
        if model_name not in all_results:
            continue

        results = all_results[model_name]
        print(f"\n{'=' * 70}")
        print(f"  MODEL: {model_name} ({model.get('arch', 'N/A')}) [{model.get('_type', '')}]")
        print(f"  Server: {model.get('_server_type', '?')} @ {model.get('_url', '?')}")
        print(f"{'=' * 70}")

        for result in results:
            _print_result(result)

        model_dir = versioned_dir / model_name
        report_data = build_model_report(config, model, results)
        write_reports(report_data, model_dir, args.format)

    # Executive summary
    if all_results:
        summary_data = build_executive_summary(
            config, all_models, all_results, total_duration,
        )
        write_executive_reports(summary_data, versioned_dir, args.format)

    total_tests = sum(len(v) for v in all_results.values())
    total_pass = sum(1 for results in all_results.values()
                     for r in results if r.status == "PASS")
    total_fail = sum(1 for results in all_results.values()
                     for r in results if r.status == "FAIL")
    print(f"\n{'=' * 70}")
    print("  PER-MODEL SUMMARY")
    print(f"  Models tested: {len(all_results)}/{len(all_models)}")
    print(f"  Total tests: {total_tests} | PASS: {total_pass} | FAIL: {total_fail}")
    print(f"  Duration: {total_duration}s")
    print(f"  Reports: {versioned_dir}")
    print(f"{'=' * 70}")


def main():
    parser = argparse.ArgumentParser(
        description="Tessera — OWASP AI Security Testing Framework"
    )
    parser.add_argument("--config", default="config.yaml",
                        help="Path to config YAML (default: config.yaml)")
    parser.add_argument("--tests", nargs="*",
                        help="Specific test IDs (e.g., MOD-01 MOD-02)")
    parser.add_argument("--category", choices=["mod", "app", "inf", "dat", "all"],
                        help="Run all tests in a category")
    parser.add_argument("--phases", nargs="*", type=int,
                        help="Run specific phases (1, 2, 3)")
    parser.add_argument("--output", default="reports",
                        help="Output directory (default: reports)")
    parser.add_argument("--format", nargs="*", default=["json", "html"],
                        help="Output formats: json, html, docx")
    parser.add_argument("--list", action="store_true",
                        help="List available tests")
    parser.add_argument("--check-deps", action="store_true",
                        help="Check dependency availability")
    parser.add_argument("--per-model", action="store_true",
                        help="Enable per-model mode")
    parser.add_argument("--model", nargs="*",
                        help="Filter specific model names")
    parser.add_argument("--model-type", choices=["cv", "llm"],
                        help="Filter models by type")
    parser.add_argument("--version", action="version",
                        version=f"Tessera {__version__}")

    args = parser.parse_args()

    if args.list:
        print("Available tests:")
        for tid, (mod, cls) in sorted(TEST_REGISTRY.items()):
            print(f"  {tid}: {cls} ({mod})")
        return

    if args.check_deps:
        available, missing = check_dependencies()
        print("Available dependencies:")
        for name, ver in sorted(available.items()):
            print(f"  [OK] {name} ({ver})")
        if missing:
            print("\nMissing dependencies:")
            for name, pkg in sorted(missing.items()):
                print(f"  [  ] {name} — pip install {pkg}")
        return

    cfg_path = Path(args.config)
    if not cfg_path.exists():
        print(f"Config not found: {cfg_path}")
        sys.exit(1)

    config = load_config(str(cfg_path))

    if args.tests:
        test_ids = args.tests
    elif args.category:
        test_ids = CATEGORY_MAP.get(args.category, [])
    else:
        test_ids = CATEGORY_MAP["all"]

    if not test_ids:
        print("No tests selected. Use --tests or --category.")
        sys.exit(1)

    if args.per_model:
        _run_per_model_mode(config, test_ids, args)
    else:
        _run_flat_mode(config, test_ids, args)


if __name__ == "__main__":
    main()
