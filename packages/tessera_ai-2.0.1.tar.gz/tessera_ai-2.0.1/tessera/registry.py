"""
Tessera — Test Registry

Central registry of all 32 OWASP AI test cases with category and model-type mappings.
"""

# Maps TEST_ID -> (module_path, class_name)
TEST_REGISTRY = {
    # MOD — AI Model Security
    "MOD-01": ("tests.mod.mod01_evasion", "MOD01Evasion"),
    "MOD-02": ("tests.mod.mod02_poisoning", "MOD02Poisoning"),
    "MOD-03": ("tests.mod.mod03_training_data", "MOD03TrainingData"),
    "MOD-04": ("tests.mod.mod04_membership", "MOD04Membership"),
    "MOD-05": ("tests.mod.mod05_inversion", "MOD05Inversion"),
    "MOD-06": ("tests.mod.mod06_drift", "MOD06Drift"),
    "MOD-07": ("tests.mod.mod07_alignment", "MOD07Alignment"),
    # APP — AI Application Security
    "APP-01": ("tests.app.app01_injection", "APP01Injection"),
    "APP-02": ("tests.app.app02_output_handling", "APP02OutputHandling"),
    "APP-03": ("tests.app.app03_sensitive_disclosure", "APP03SensitiveDisclosure"),
    "APP-04": ("tests.app.app04_overreliance", "APP04Overreliance"),
    "APP-05": ("tests.app.app05_unsafe_outputs", "APP05UnsafeOutputs"),
    "APP-06": ("tests.app.app06_excessive_agency", "APP06ExcessiveAgency"),
    "APP-07": ("tests.app.app07_prompt_disclosure", "APP07PromptDisclosure"),
    "APP-08": ("tests.app.app08_cross_plugin", "APP08CrossPlugin"),
    "APP-09": ("tests.app.app09_model_extraction", "APP09ModelExtraction"),
    "APP-10": ("tests.app.app10_content_bias", "APP10ContentBias"),
    "APP-11": ("tests.app.app11_hallucinations", "APP11Hallucinations"),
    "APP-12": ("tests.app.app12_toxic_output", "APP12ToxicOutput"),
    "APP-13": ("tests.app.app13_overreliance", "APP13Overreliance"),
    "APP-14": ("tests.app.app14_explainability", "APP14Explainability"),
    # INF — AI Infrastructure Security
    "INF-01": ("tests.inf.inf01_supply_chain", "INF01SupplyChain"),
    "INF-02": ("tests.inf.inf02_model_storage", "INF02ModelStorage"),
    "INF-03": ("tests.inf.inf03_api_security", "INF03APISecurity"),
    "INF-04": ("tests.inf.inf04_resource_exhaustion", "INF04ResourceExhaustion"),
    "INF-05": ("tests.inf.inf05_gpu_security", "INF05GPUSecurity"),
    "INF-06": ("tests.inf.inf06_model_theft", "INF06ModelTheft"),
    # DAT — AI Data Governance
    "DAT-01": ("tests.dat.dat01_broad_consent", "DAT01BroadConsent"),
    "DAT-02": ("tests.dat.dat02_pii_leakage", "DAT02PIILeakage"),
    "DAT-03": ("tests.dat.dat03_data_lineage", "DAT03DataLineage"),
    "DAT-04": ("tests.dat.dat04_right_to_erasure", "DAT04RightToErasure"),
    "DAT-05": ("tests.dat.dat05_data_minimization", "DAT05DataMinimization"),
}

CATEGORY_MAP = {
    "mod": [k for k in TEST_REGISTRY if k.startswith("MOD")],
    "app": [k for k in TEST_REGISTRY if k.startswith("APP")],
    "inf": [k for k in TEST_REGISTRY if k.startswith("INF")],
    "dat": [k for k in TEST_REGISTRY if k.startswith("DAT")],
    "all": list(TEST_REGISTRY.keys()),
}

# Model-type to applicable test mapping
_INF_TESTS = ["INF-01", "INF-02", "INF-03", "INF-04", "INF-05", "INF-06"]
_DAT_TESTS = ["DAT-01", "DAT-02", "DAT-03", "DAT-04", "DAT-05"]
MODEL_TYPE_TESTS = {
    "cv":  ["MOD-01", "MOD-02", "MOD-03", "MOD-04", "MOD-05", "MOD-06"] + _INF_TESTS + _DAT_TESTS,
    "llm": ["MOD-07", "APP-01", "APP-02", "APP-03", "APP-04", "APP-05",
            "APP-06", "APP-07", "APP-08", "APP-09", "APP-10", "APP-11",
            "APP-12", "APP-13", "APP-14"] + _INF_TESTS + _DAT_TESTS,
}


def load_test_class(test_id: str):
    """Dynamically import and return the test class for a given test ID."""
    if test_id not in TEST_REGISTRY:
        raise ValueError(f"Unknown test: {test_id}. Available: {list(TEST_REGISTRY.keys())}")

    module_path, class_name = TEST_REGISTRY[test_id]
    module = __import__(module_path, fromlist=[class_name])
    return getattr(module, class_name)


def get_test_ids(category: str = None, test_ids: list = None) -> list:
    """Resolve test IDs from category name or explicit list."""
    if test_ids:
        return test_ids
    if category:
        return CATEGORY_MAP.get(category, [])
    return CATEGORY_MAP["all"]
