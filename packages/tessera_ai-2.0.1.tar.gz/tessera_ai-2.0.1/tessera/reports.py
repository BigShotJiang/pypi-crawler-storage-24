"""
Tessera — Report generation.

Handles JSON, HTML, and DOCX report output for both flat and per-model modes.
"""

from __future__ import annotations

import json
from pathlib import Path


def write_json(data: dict, path: Path):
    """Write report data as JSON."""
    path.write_text(json.dumps(data, indent=2, default=str))


def write_html(data: dict, path: Path):
    """Write an interactive HTML report."""
    from utils.report_html import generate_model_report_html
    path.write_text(generate_model_report_html(data))


def write_executive_html(data: dict, path: Path):
    """Write executive summary HTML report."""
    from utils.report_html import generate_executive_html
    path.write_text(generate_executive_html(data))


def write_docx(data: dict, path: Path):
    """Write a DOCX report for a single model or flat scan."""
    from docx import Document
    from docx.enum.text import WD_ALIGN_PARAGRAPH
    from docx.shared import Pt, RGBColor

    doc = Document()

    model_info = data.get("model", {})
    title_suffix = f" — {model_info['name']}" if model_info.get("name") else ""
    title = doc.add_heading(f"Tessera Security Report{title_suffix}", level=0)
    title.alignment = WD_ALIGN_PARAGRAPH.CENTER

    project = data.get("project", {})
    meta_text = (
        f"Project: {project.get('name', 'N/A')}\n"
        f"Environment: {project.get('environment', 'N/A')}\n"
        f"Author: {project.get('author', 'N/A')}\n"
        f"Date: {data['timestamp'][:19]}\n"
        f"Duration: {data['total_duration_sec']}s"
    )
    if model_info.get("name"):
        meta_text += (
            f"\nModel: {model_info['name']}\n"
            f"Architecture: {model_info.get('arch', 'N/A')}\n"
            f"Type: {model_info.get('type', 'N/A').upper()}\n"
            f"Task: {model_info.get('task', 'N/A')}"
        )
    doc.add_paragraph(meta_text)

    # Summary table
    doc.add_heading("Executive Summary", level=1)
    summary = data["summary"]
    table = doc.add_table(rows=2, cols=5)
    table.style = "Light Grid Accent 1"
    for i, label in enumerate(["PASS", "FAIL", "WARN", "ERROR", "N/A"]):
        table.rows[0].cells[i].text = label
    for i, key in enumerate(["pass", "fail", "warn", "error", "na"]):
        table.rows[1].cells[i].text = str(summary.get(key, 0))

    # Test details
    doc.add_heading("Detailed Results", level=1)
    for t in data["tests"]:
        doc.add_heading(f"[{t['status']}] {t['test_id']}: {t['test_name']}", level=2)
        doc.add_paragraph(
            f"Category: {t['category']} | OWASP Ref: {t['owasp_ref']} | "
            f"Tools: {', '.join(t.get('tools_used', []))}"
        )

        for p in t["phases"]:
            doc.add_heading(
                f"Phase {p['phase']}: {p['name']} [{p['status']}]", level=3
            )
            if p.get("metrics"):
                for m in p["metrics"]:
                    status = m.get("status", "")
                    unit = m.get("unit", "")
                    line = f"{m['name']}: {m['value']}"
                    if unit:
                        line += f" {unit}"
                    if status and status != "?":
                        line += f" [{status}]"
                    doc.add_paragraph(line, style="List Bullet")
            for e in p.get("evidence", []):
                doc.add_paragraph(e, style="List Bullet 2")
            if p.get("error"):
                doc.add_paragraph(f"ERROR: {p['error']}")

        if t.get("recommendations"):
            doc.add_heading("Recommendations", level=3)
            for r in t["recommendations"]:
                if isinstance(r, dict):
                    text = r.get("text", str(r))
                    url = r.get("url", "")
                    p = doc.add_paragraph(style="List Bullet")
                    run = p.add_run(text)
                    if url:
                        run = p.add_run(f"\n  Reference: {url}")
                        run.font.size = Pt(8)
                        run.font.color.rgb = RGBColor(0x06, 0x93, 0xe3)
                else:
                    doc.add_paragraph(str(r), style="List Bullet")

    doc.save(str(path))


def write_executive_docx(data: dict, path: Path):
    """Write executive summary DOCX with model x test matrix."""
    from docx import Document
    from docx.enum.text import WD_ALIGN_PARAGRAPH

    doc = Document()
    title = doc.add_heading("Tessera — Executive Summary", level=0)
    title.alignment = WD_ALIGN_PARAGRAPH.CENTER

    project = data.get("project", {})
    doc.add_paragraph(
        f"Project: {project.get('name', 'N/A')}\n"
        f"Environment: {project.get('environment', 'N/A')}\n"
        f"Author: {project.get('author', 'N/A')}\n"
        f"Date: {data['timestamp'][:19]}\n"
        f"Duration: {data['total_duration_sec']}s\n"
        f"Models tested: {data['models_tested']}/{data['models_total']}"
    )

    # Aggregate summary
    doc.add_heading("Summary", level=1)
    per_model = data["per_model_summary"]
    total_tests = sum(info.get("total", 0) for info in per_model.values())
    total_pass = sum(info.get("pass", 0) for info in per_model.values())
    total_fail = sum(info.get("fail", 0) for info in per_model.values())
    total_warn = sum(info.get("warn", 0) for info in per_model.values())
    total_error = sum(info.get("error", 0) for info in per_model.values())

    tbl = doc.add_table(rows=2, cols=5)
    tbl.style = "Light Grid Accent 1"
    for i, label in enumerate(["PASS", "FAIL", "WARN", "ERROR", "TOTAL"]):
        tbl.rows[0].cells[i].text = label
    for i, val in enumerate([total_pass, total_fail, total_warn, total_error, total_tests]):
        tbl.rows[1].cells[i].text = str(val)

    # Matrix table
    doc.add_heading("Model x Test Matrix", level=1)
    matrix = data["matrix"]
    test_ids = data["test_ids"]
    n_cols = 1 + len(test_ids) + 1

    tbl2 = doc.add_table(rows=1 + len(matrix), cols=n_cols)
    tbl2.style = "Light Grid Accent 1"

    tbl2.rows[0].cells[0].text = "Model"
    for j, tid in enumerate(test_ids):
        tbl2.rows[0].cells[j + 1].text = tid
    tbl2.rows[0].cells[n_cols - 1].text = "Score"

    for i, model_name in enumerate(sorted(matrix.keys())):
        info = per_model.get(model_name, {})
        row = tbl2.rows[i + 1]
        row.cells[0].text = f"{model_name}\n({info.get('arch', '')} [{info.get('type', '').upper()}])"
        for j, tid in enumerate(test_ids):
            row.cells[j + 1].text = matrix[model_name].get(tid, "-")
        total = info.get("total", 0)
        passed = info.get("pass", 0)
        score_pct = round(passed / total * 100) if total > 0 else 0
        row.cells[n_cols - 1].text = f"{score_pct}%"

    # Per-model details
    doc.add_heading("Per-Model Details", level=1)
    for model_name, info in sorted(per_model.items()):
        doc.add_heading(
            f"{model_name} ({info.get('arch', '')}) [{info.get('type', '').upper()}]",
            level=2,
        )
        doc.add_paragraph(
            f"Task: {info.get('task', 'N/A')} | "
            f"Tests: {info.get('total', 0)} | "
            f"PASS: {info.get('pass', 0)} | FAIL: {info.get('fail', 0)} | "
            f"WARN: {info.get('warn', 0)} | ERROR: {info.get('error', 0)}"
        )

    doc.save(str(path))


def write_reports(report_data: dict, output_dir: Path, formats: list[str]):
    """Write all requested report formats for a scan result."""
    output_dir.mkdir(parents=True, exist_ok=True)

    if "json" in formats:
        write_json(report_data, output_dir / "report.json")

    if "html" in formats:
        write_html(report_data, output_dir / "report.html")

    if "docx" in formats:
        try:
            write_docx(report_data, output_dir / "report.docx")
        except ImportError:
            pass


def write_executive_reports(summary_data: dict, output_dir: Path, formats: list[str]):
    """Write all requested report formats for the executive summary."""
    if "json" in formats:
        write_json(summary_data, output_dir / "executive-summary.json")

    if "html" in formats:
        write_executive_html(summary_data, output_dir / "executive-summary.html")

    if "docx" in formats:
        try:
            write_executive_docx(summary_data, output_dir / "executive-summary.docx")
        except ImportError:
            pass
