"""The jabs.vision package."""
