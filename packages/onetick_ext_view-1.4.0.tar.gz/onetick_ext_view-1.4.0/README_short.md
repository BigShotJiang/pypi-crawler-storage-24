## onetick-ext-view

Onetick View is a terminal UI for browsing Onetick databases.

It is based on [onetick-py](https://pypi.org/project/onetick-py/) library and can work in two modes: localy-installed mode and WebAPI mode.
The mode depends on the set environment variables and installed onetick python api libraries.
See onetick-py documentation for details: https://docs.pip.distribution.sol.onetick.com/static/installation/webapi.html.

In order to use WebAPI mode install package with `webapi` extra:
```
pip install onetick-ext-view[webapi]
```

#### Usage (WebAPI mode):

    # set env variables:
    OTP_HTTP_ADDRESS='https://rest.cloud.onetick.com'
    OTP_ACCESS_TOKEN_URL='https://cloud-auth.parent.onetick.com/realms/OMD/protocol/openid-connect/token'
    OTP_CLIENT_ID='?????????????'
    OTP_CLIENT_SECRET='?????????'

    onetick view                                           # (get remote databases from WebAPI server)

#### Usage (locally-installed mode):

    # set env variables:
    MAIN_ONE_TICK_DIR="/opt/one_market_data/one_tick"

    onetick view                                           # (scan current working dir)
    onetick view /tmp                                      # (i.e. for tests with --keep-generated=always)
    onetick view --remote-ts remote.example.com:40001      # (connect to remote server)
    onetick view /tmp --remote-ts remote.example.com:40001 # (both scan specific directory and connect to remote server)

#### Program windows:
1. Databases window: does recursive search in subdirectories
   and shows available databases
    - press Q to quit

2. Dates window: shows available dates for selected database
    - press C to show record count (may be slow - scans all DBs)
    - press Esc or Backspace to go back
    - press Q to quit

3. Tick types window: shows available tick types for a specific day
    - press + or - to change scroll speed (1, 10, 100 lines)
    - press Esc or Backspace to go back

4. Symbols window: shows available symbols & tick types
    - press C to show record count
    - press + or - to change scroll speed (1, 10, 100 lines)
    - press Esc or Backspace to go back

5. Data window: shows symbol data
    - Use arrows to navigate dataframe
    - press Space to zoom in top left data cell (i.e. view long alert description string)
    - press T to transpose table
    - press + or - to change scroll speed (1, 10, 100 lines)
    - press C to dump dataframe to CSV file
    - press Esc or Backspace to go back
