"""AgentTool SDK — memory, tools, verify, economy, traces, identity, and vault for AI agents."""

from .client import AgentTool
from .economy import EconomyClient, Escrow, Wallet
from .exceptions import AgentToolError
from .identity import IdentityClient
from .models import DocumentResult, ExecuteResult, Memory, ScrapeResult, SearchResult, UsageStats
from .traces import Trace, TraceChain, TraceSearchResult
from .vault import VaultClient
from .verify import VerifyClient, VerifyResult

__all__ = [
    "AgentTool",
    "AgentToolError",
    "ExecuteResult",
    "IdentityClient",
    "Memory",
    "ScrapeResult",
    "SearchResult",
    "UsageStats",
    "Trace",
    "TraceChain",
    "TraceSearchResult",
    "VaultClient",
]

__version__ = "0.4.0"
