"""Tests for the CLI leaderboard rendering and price simulation formulas."""

import pytest
from rich.console import Console


# ── Price simulation formula tests ──────────────────────────────


class TestPriceSimulationFormulas:
    def test_price_factor_same_price(self):
        from cli.commands.miner import _price_factor

        assert _price_factor(0.03, 0.03) == pytest.approx(1.0)

    def test_price_factor_cheaper_gets_bonus(self):
        from cli.commands.miner import _price_factor

        pf = _price_factor(0.03, 0.015)
        assert pf == pytest.approx(2.0)

    def test_price_factor_capped_at_p_max(self):
        from cli.commands.miner import _price_factor

        pf = _price_factor(0.03, 0.001)
        assert pf == pytest.approx(3.0)

    def test_price_factor_zero_bid(self):
        from cli.commands.miner import _price_factor

        assert _price_factor(0.03, 0.0) == 0.0

    def test_routing_score_from_components(self):
        from cli.commands.miner import _routing_score_from_components

        # SR=1.0, Rel=1.0, Lat=1.0, PF=2.0 -> 1^2 * 1^1.5 * 1^1 * 2 = 2.0
        assert _routing_score_from_components(1.0, 1.0, 1.0, 2.0) == pytest.approx(2.0)

    def test_routing_score_zero_component(self):
        from cli.commands.miner import _routing_score_from_components

        assert _routing_score_from_components(0.0, 1.0, 1.0, 2.0) == pytest.approx(0.0)

    def test_routing_score_realistic(self):
        from cli.commands.miner import _routing_score_from_components

        # SR=1.0, Rel=1.0, Lat=0.818, PF=2.0 -> 1 * 1 * 0.818 * 2.0 = 1.636
        rs = _routing_score_from_components(1.0, 1.0, 0.818, 2.0)
        assert rs == pytest.approx(1.636)


# ── Archive ordering and filtering tests ────────────────────────


class TestArchiveOrdering:
    def test_recompute_shares_sorts_by_archive(self):
        from cli.commands.leaderboard import _recompute_shares

        miners = [
            {
                "hotkey": "hk1",
                "routing_score": 2.0,
                "routing_score_archive": 0.5,
                "nodes": [
                    {
                        "routing_score": 2.0,
                        "routing_score_archive": 0.5,
                        "is_archive": True,
                    },
                ],
            },
            {
                "hotkey": "hk2",
                "routing_score": 0.5,
                "routing_score_archive": 2.0,
                "nodes": [
                    {
                        "routing_score": 0.5,
                        "routing_score_archive": 2.0,
                        "is_archive": True,
                    },
                ],
            },
        ]

        lite = _recompute_shares(miners, archive=False)
        assert lite[0]["hotkey"] == "hk1"

        archive = _recompute_shares(miners, archive=True)
        assert archive[0]["hotkey"] == "hk2"

    def test_recompute_shares_sorts_nodes_by_archive(self):
        from cli.commands.leaderboard import _recompute_shares

        miners = [
            {
                "hotkey": "hk1",
                "nodes": [
                    {
                        "node_id": "a",
                        "routing_score": 2.0,
                        "routing_score_archive": 0.5,
                        "is_archive": True,
                    },
                    {
                        "node_id": "b",
                        "routing_score": 0.5,
                        "routing_score_archive": 2.0,
                        "is_archive": True,
                    },
                ],
            },
        ]

        lite = _recompute_shares(miners, archive=False)
        assert lite[0]["nodes"][0]["node_id"] == "a"

        archive = _recompute_shares(miners, archive=True)
        assert archive[0]["nodes"][0]["node_id"] == "b"

    def test_archive_filters_non_archive_nodes(self):
        from cli.commands.leaderboard import _recompute_shares

        miners = [
            {
                "hotkey": "hk1",
                "nodes": [
                    {
                        "node_id": "archive-node",
                        "routing_score": 1.0,
                        "routing_score_archive": 1.0,
                        "is_archive": True,
                    },
                    {
                        "node_id": "lite-node",
                        "routing_score": 2.0,
                        "routing_score_archive": 0.5,
                        "is_archive": False,
                    },
                ],
            },
        ]

        lite = _recompute_shares(miners, archive=False)
        assert len(lite[0]["nodes"]) == 2

        archive = _recompute_shares(miners, archive=True)
        assert len(archive[0]["nodes"]) == 1
        assert archive[0]["nodes"][0]["node_id"] == "archive-node"

    def test_archive_removes_miners_with_no_archive_nodes(self):
        from cli.commands.leaderboard import _recompute_shares

        miners = [
            {
                "hotkey": "hk-archive",
                "nodes": [
                    {
                        "routing_score": 1.0,
                        "routing_score_archive": 1.0,
                        "is_archive": True,
                    },
                ],
            },
            {
                "hotkey": "hk-lite-only",
                "nodes": [
                    {
                        "routing_score": 2.0,
                        "routing_score_archive": 0.5,
                        "is_archive": False,
                    },
                ],
            },
        ]

        archive = _recompute_shares(miners, archive=True)
        assert len(archive) == 1
        assert archive[0]["hotkey"] == "hk-archive"


class TestRehabDisplay:
    def test_is_in_rehab_only_for_explicit_zero_score(self):
        from cli.commands.leaderboard import _is_in_rehab

        assert _is_in_rehab({"routing_score": 0.0}, archive=False) is True
        assert _is_in_rehab({"routing_score": None}, archive=False) is False
        assert _is_in_rehab({}, archive=False) is False

    def test_is_in_rehab_uses_archive_score_in_archive_mode(self):
        from cli.commands.leaderboard import _is_in_rehab

        node = {"routing_score": 1.0, "routing_score_archive": 0.0}
        assert _is_in_rehab(node, archive=True) is True
        assert _is_in_rehab(node, archive=False) is False

    def test_render_default_shows_rehab_marker_without_literal_markup(
        self, monkeypatch
    ):
        from cli.commands import leaderboard

        render_console = Console(record=True, width=120)
        monkeypatch.setattr(leaderboard, "console", render_console)

        leaderboard._render_default(
            {
                "miners": [
                    {
                        "hotkey": "hk1",
                        "node_count": 1,
                        "routing_score": 1.0,
                        "latency_score": 1.0,
                        "reliability": 1.0,
                        "_price_factor": 1.0,
                        "epoch_cus": 10,
                        "nodes": [
                            {
                                "node_id": "node-12345678",
                                "routing_score": 0.0,
                                "latency_score": 1.0,
                                "reliability": 1.0,
                                "price_factor": 1.0,
                            }
                        ],
                    }
                ]
            },
            own_hotkey=None,
            archive=False,
        )

        output = render_console.export_text()
        assert "↺" in output
        assert "[dim]↺[/dim]" not in output
