"""Authentication helpers for OAuth device flow"""

import time
import webbrowser
from datetime import datetime, timedelta, timezone

import httpx
import typer
from rich.console import Console
from rich.live import Live
from rich.spinner import Spinner

from cli import settings
from cli.config import load_config, save_config, validate_token

console = Console()


def device_login(
    scopes: list[str],
    client_id: str | None = None,
    auth_url: str | None = None,
    no_browser: bool = False,
) -> dict:
    """Run the OAuth device code flow and return token data.

    Raises typer.Exit(1) on failure.
    """
    client_id = client_id or settings.CLIENT_ID
    auth_url = auth_url or settings.auth_url()

    try:
        with httpx.Client(
            timeout=30.0,
            headers={"User-Agent": settings.user_agent()},
        ) as client:
            response = client.post(
                f"{auth_url}/v1/device/code",
                json={"client_id": client_id, "scopes": scopes},
            )
            response.raise_for_status()
            device_data = response.json()

            device_code = device_data["device_code"]
            user_code = device_data["user_code"]
            verification_uri = device_data["verification_uri"]
            interval = device_data.get("interval", 5)
            expires_in = device_data.get("expires_in", 900)

            verify_url = f"{verification_uri}?user_code={user_code}"

            console.print()
            console.print("[bold]To authenticate, visit:[/bold]")
            console.print(f"  [cyan]{verify_url}[/cyan]")
            console.print()
            console.print(f"[bold]Code:[/bold] [yellow]{user_code}[/yellow]")
            console.print()

            if not no_browser:
                try:
                    webbrowser.open(verify_url)
                    console.print("[dim]Browser opened automatically.[/dim]")
                except Exception:
                    console.print(
                        "[dim]Could not open browser. Please visit the URL above.[/dim]"
                    )

            return _poll_for_token(
                client, auth_url, client_id, device_code, interval, expires_in
            )

    except httpx.HTTPStatusError as e:
        console.print(
            f"[red]API error:[/red] {e.response.status_code} - {e.response.text}"
        )
        raise typer.Exit(1)
    except typer.Exit:
        raise
    except Exception as e:
        console.print(f"[red]Error:[/red] {e}")
        raise typer.Exit(1)


def _poll_for_token(
    client: httpx.Client,
    auth_url: str,
    client_id: str,
    device_code: str,
    interval: int,
    expires_in: int,
) -> dict:
    """Poll the token endpoint until authorization completes."""
    deadline = time.time() + expires_in
    poll_interval = interval

    with Live(
        Spinner("dots", text="Waiting for browser authorization..."),
        console=console,
        transient=True,
    ):
        while time.time() < deadline:
            time.sleep(poll_interval)

            token_response = client.post(
                f"{auth_url}/v1/oauth/token",
                json={
                    "client_id": client_id,
                    "device_code": device_code,
                    "grant_type": ("urn:ietf:params:oauth:grant-type:device_code"),
                },
            )

            if token_response.status_code == 200:
                return token_response.json()

            if token_response.status_code == 429:
                poll_interval += 5
                continue

            error = extract_error(token_response)
            if error == "authorization_pending":
                continue
            if error == "slow_down":
                poll_interval += 5
                continue
            if error == "expired_token":
                console.print("\n[red]Login timed out.[/red] Please try again.")
                raise typer.Exit(1)
            if error == "access_denied":
                console.print("\n[red]Login was denied.[/red]")
                raise typer.Exit(1)

            console.print(f"\n[red]Error:[/red] {error}")
            raise typer.Exit(1)

    console.print("\n[red]Login timed out.[/red] Please try again.")
    raise typer.Exit(1)


def save_token(
    token_data: dict,
    role: str = "miner",
    *,
    client_id: str | None = None,
    auth_url: str | None = None,
    api_url: str | None = None,
) -> dict:
    """Validate and persist a token response to CLI config.

    Returns the validated JWT claims.
    """
    claims = validate_token_claims(token_data)
    access_token = token_data["access_token"]

    token_expires_in = token_data.get("expires_in", 3600)
    expires_at = datetime.now(timezone.utc) + timedelta(seconds=token_expires_in)

    config = load_config()
    config.set_role(role)
    config.client_id = client_id or settings.CLIENT_ID
    config.auth_url = auth_url or settings.auth_url()
    config.api_url = api_url or settings.api_url()
    config.access_token = access_token
    config.refresh_token = token_data.get("refresh_token")
    config.token_expires_at = expires_at.isoformat()
    save_config(config)

    console.print("\n[green]Login successful![/green]")
    exp_str = expires_at.strftime("%Y-%m-%d %H:%M:%S UTC")
    console.print(f"[dim]Token expires: {exp_str}[/dim]")

    scope = claims.get("scope", token_data.get("scope", ""))
    if scope:
        console.print(f"[dim]Scopes: {scope}[/dim]")

    return claims


def save_miner_token(
    token_data: dict,
    client_id: str | None = None,
    auth_url: str | None = None,
    api_url: str | None = None,
) -> None:
    """Validate and persist a miner token response to CLI config."""
    save_token(
        token_data,
        "miner",
        client_id=client_id,
        auth_url=auth_url,
        api_url=api_url,
    )


def validate_token_claims(token_data: dict) -> dict:
    """Validate a token and return its claims. Exit on failure."""
    access_token = token_data["access_token"]
    claims = validate_token(access_token)
    if claims is None:
        console.print(
            "\n[red]Token validation failed.[/red]"
            " The token issuer or signature is invalid."
        )
        raise typer.Exit(1)
    return claims


def extract_error(response: httpx.Response) -> str:
    """Extract OAuth error code from a token endpoint response."""
    try:
        data = response.json()
        return data.get("error", "")
    except Exception:
        return f"HTTP {response.status_code}"


def check_status() -> None:
    """Print current authentication status."""
    config = load_config()

    if not config.networks:
        console.print("[red]Not logged in[/red]")
        return

    for net_name, net_entry in config.networks.items():
        console.print(f"\n[bold]{net_name}[/bold]")
        if net_entry.auth_url:
            console.print(f"  [dim]Auth: {net_entry.auth_url}[/dim]")
        if net_entry.api_url:
            console.print(f"  [dim]API: {net_entry.api_url}[/dim]")

        if not net_entry.tokens:
            console.print("  [red]No tokens[/red]")
            continue

        for role, tok in net_entry.tokens.items():
            console.print(f"  [bold]{role}:[/bold]", end=" ")
            if tok.access_token:
                claims = validate_token(tok.access_token)
                if claims:
                    sub = claims.get("sub", "")[:16]
                    console.print(f"[green]valid[/green] [dim]({sub}...)[/dim]")
                else:
                    console.print("[yellow]expired/invalid[/yellow]")
            else:
                console.print("[red]no token[/red]")

            if tok.refresh_token:
                console.print("    [dim]Refresh token: available[/dim]")


def do_logout() -> None:
    """Clear all stored authentication tokens (preserves network config)."""
    config = load_config()
    for net_entry in config.networks.values():
        net_entry.tokens.clear()
    save_config(config)
    console.print("[green]Logged out[/green]")
