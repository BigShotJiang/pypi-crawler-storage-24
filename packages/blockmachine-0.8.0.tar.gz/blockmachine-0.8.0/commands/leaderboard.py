"""Leaderboard command: view miner routing scores and work done"""

import logging
from typing import Optional

import jwt as pyjwt
import typer
from rich.console import Console
from rich.table import Table
from rich.text import Text

from cli.client import RegistryClient
from cli.config import CLIConfig, load_config

app = typer.Typer(help="Miner leaderboard")

console = Console()
logger = logging.getLogger(__name__)

BAR_WIDTH = 20


def _get_own_hotkey(config: CLIConfig) -> Optional[str]:
    """Extract the caller's hotkey from their stored token (no validation)."""
    token = config.access_token
    if not token:
        return None
    try:
        claims = pyjwt.decode(token, options={"verify_signature": False})
        return claims.get("sub")
    except Exception:
        return None


def _bar(pct: float, width: int = BAR_WIDTH) -> str:
    """Render a proportional bar using block characters."""
    filled = int(round(pct / 100.0 * width))
    filled = max(0, min(filled, width))
    empty = width - filled
    return "\u2588" * filled + "\u2591" * empty


def _score_bar(val: float, max_val: float, width: int = 26) -> str:
    """Render a score bar scaled to max_val."""
    if max_val <= 0:
        return "\u2591" * width
    pct = min(val / max_val, 1.0)
    filled = int(round(pct * width))
    return "\u2588" * filled + "\u2591" * (width - filled)


def _fmt_score(val: Optional[float]) -> str:
    if val is None:
        return "-"
    return f"{val:.3f}"


def _fmt_pct(val: Optional[float]) -> str:
    if val is None:
        return "-"
    return f"{val:.1f}%"


def _fmt_cus(val: Optional[int]) -> str:
    if val is None:
        return "-"
    return f"{val:,}"


def _short_hotkey(hotkey: str) -> str:
    if len(hotkey) <= 16:
        return hotkey
    return f"{hotkey[:6]}\u2026{hotkey[-6:]}"


def _node_display_name(node: dict) -> str:
    """Alias if available, otherwise truncated node ID."""
    alias = node.get("alias")
    if alias:
        if len(alias) > 12:
            return alias[:11] + "\u2026"
        return alias
    return node["node_id"][:8]


def _node_score_field(node: dict, field: str, archive: bool) -> Optional[float]:
    """Get a score field, using the archive variant when archive=True."""
    if archive and f"{field}_archive" in node:
        return node.get(f"{field}_archive")
    return node.get(field)


def _is_in_rehab(node: dict, archive: bool) -> bool:
    """True if the node has a zero routing score in the selected dimension."""
    score = _node_score_field(node, "routing_score", archive)
    return score == 0.0


def _miner_score_field(miner: dict, field: str, archive: bool) -> Optional[float]:
    """Get a miner-level score field, using archive variant when archive=True."""
    if archive and f"{field}_archive" in miner:
        return miner.get(f"{field}_archive")
    return miner.get(field)


def _render_default(data: dict, own_hotkey: Optional[str], archive: bool) -> None:
    """Render the default leaderboard view (Option B)."""
    miners = data.get("miners", [])
    epoch = data.get("epoch")

    if not miners:
        console.print("[dim]No miners with routing scores[/dim]")
        return

    total_cus = sum(m.get("epoch_cus") or 0 for m in miners)
    mode = "archive" if archive else "lite"
    header = f"Miner Leaderboard  ({mode})"
    if epoch:
        header += f"  (epoch {epoch})"

    # Recompute traffic shares for the selected dimension
    miners_with_scores = _recompute_shares(miners, archive)

    table = Table(title=header, title_style="bold", show_lines=False)
    table.add_column("", width=1)
    table.add_column("Hotkey", min_width=14)
    table.add_column("Nodes", justify="right", width=5)
    table.add_column("Share", justify="right", width=6)
    table.add_column("", min_width=BAR_WIDTH)
    table.add_column("Score", justify="right", width=7)
    table.add_column("Latency", justify="right", width=7)
    table.add_column("Rel", justify="right", width=5)
    table.add_column("Price", justify="right", width=5)
    table.add_column("Epoch CUs", justify="right", min_width=10)

    for miner in miners_with_scores:
        hotkey = miner["hotkey"]
        is_mine = own_hotkey and hotkey == own_hotkey
        marker = "[bold yellow]*[/bold yellow]" if is_mine else ""
        hk_style = "bold" if is_mine else ""
        traffic = miner.get("_share") or 0.0

        table.add_row(
            marker,
            Text(_short_hotkey(hotkey), style=hk_style),
            str(miner.get("node_count", 0)),
            _fmt_pct(traffic),
            _bar(traffic),
            _fmt_score(miner.get("_score")),
            _fmt_score(miner.get("latency_score")),
            _fmt_score(miner.get("reliability")),
            _fmt_score(miner.get("_price_factor")),
            _fmt_cus(miner.get("epoch_cus")),
        )

        nodes = miner.get("nodes", [])
        for i, node in enumerate(nodes):
            is_last = i == len(nodes) - 1
            prefix = "  \u2514\u2500 " if is_last else "  \u251c\u2500 "
            node_score = _node_score_field(node, "routing_score", archive)
            node_pf = _node_score_field(node, "price_factor", archive)
            node_traffic = node.get("_share") or 0.0
            in_rehab = _is_in_rehab(node, archive)
            node_name = prefix + _node_display_name(node)
            if in_rehab:
                node_name += " \u21ba"

            table.add_row(
                "",
                Text(node_name, style="dim"),
                "",
                Text(_fmt_pct(node_traffic), style="dim"),
                Text(_bar(node_traffic), style="dim"),
                Text(_fmt_score(node_score), style="dim"),
                Text(_fmt_score(node.get("latency_score")), style="dim"),
                Text(_fmt_score(node.get("reliability")), style="dim"),
                Text(_fmt_score(node_pf), style="dim"),
                "",
            )

    console.print(table)

    footer_parts = []
    if own_hotkey:
        footer_parts.append("[yellow]*[/yellow] = your miner")
    footer_parts.append(f"{len(miners)} miners")
    footer_parts.append(f"{total_cus:,} total CUs")
    has_rehab = any(
        _is_in_rehab(n, archive) for m in miners_with_scores for n in m.get("nodes", [])
    )
    if has_rehab:
        footer_parts.append(
            "[dim]\u21ba = in rehab (zero score, receiving synthetic probes)[/dim]"
        )
    console.print("  " + "  \u00b7  ".join(footer_parts))


def _recompute_shares(miners: list[dict], archive: bool) -> list[dict]:
    """Recompute routing scores and traffic shares for the selected dimension.

    When archive=True, filters to archive-capable nodes only and uses
    routing_score_archive / price_factor_archive.
    Adds _score, _share, _price_factor to each miner and _share to each node.
    """
    results = []
    total = 0.0

    for miner in miners:
        nodes = miner.get("nodes", [])
        if archive:
            nodes = [n for n in nodes if n.get("is_archive", False)]
        miner_score = 0.0
        for node in nodes:
            ns = _node_score_field(node, "routing_score", archive) or 0.0
            miner_score += ns
        total += miner_score

        pf = _miner_score_field(miner, "price_factor", archive)
        results.append(
            {
                **miner,
                "nodes": nodes,
                "_score": miner_score,
                "_price_factor": pf,
            }
        )

    # Remove miners with no nodes in this dimension
    results = [r for r in results if r["nodes"]]

    for entry in results:
        entry["_share"] = (entry["_score"] / total * 100.0) if total > 0 else 0.0
        for node in entry.get("nodes", []):
            ns = _node_score_field(node, "routing_score", archive) or 0.0
            node["_share"] = (ns / total * 100.0) if total > 0 else 0.0

    # Sort miners and their nodes by the selected dimension
    results.sort(key=lambda m: m["_score"], reverse=True)
    score_key = "routing_score_archive" if archive else "routing_score"
    for entry in results:
        entry["nodes"] = sorted(
            entry.get("nodes", []),
            key=lambda n: n.get(score_key) or 0.0,
            reverse=True,
        )
    return results


def _bottleneck_label(val: float, threshold: float = 0.05) -> str:
    """Return a bottleneck indicator if the score is very low."""
    if val <= threshold:
        return "  [red]<- bottleneck[/red]"
    return ""


def _render_detail(data: dict, own_hotkey: Optional[str], archive: bool) -> None:
    """Render the detailed breakdown view (Option C)."""
    miners = data.get("miners", [])
    epoch = data.get("epoch")

    if not miners:
        console.print("[dim]No miners with routing scores[/dim]")
        return

    mode = "archive" if archive else "lite"
    header = f"Miner Leaderboard  ({mode} \u00b7 detail)"
    if epoch:
        header += f"  (epoch {epoch})"
    console.print(f"[bold]{header}[/bold]\n")

    miners_with_scores = _recompute_shares(miners, archive)

    for miner in miners_with_scores:
        hotkey = miner["hotkey"]
        is_mine = own_hotkey and hotkey == own_hotkey
        star = " [bold yellow]*[/bold yellow]" if is_mine else ""
        hk_display = _short_hotkey(hotkey)

        score = miner.get("_score") or 0.0
        traffic = miner.get("_share") or 0.0
        epoch_cus = miner.get("epoch_cus")

        console.print(
            f" [bold]{hk_display}[/bold]{star}"
            f"    Score: {score:.4f}"
            f"  Share: {traffic:.1f}%"
            f"  Epoch CUs: {_fmt_cus(epoch_cus)}"
        )

        for node in miner.get("nodes", []):
            rehab_tag = (
                "  [dim]\u21ba rehab[/dim]" if _is_in_rehab(node, archive) else ""
            )
            console.print(f"   [dim]{_node_display_name(node)}[/dim]{rehab_tag}")

            lat = node.get("latency_score") or 0.0
            rel = node.get("reliability") or 0.0
            sr = node.get("success_rate") or 0.0
            pf = _node_score_field(node, "price_factor", archive) or 0.0
            p95 = node.get("p95_ms")
            epochs_good = node.get("epochs_good")
            bid_key = "bid_archive" if archive else "bid"
            median_key = "cohort_median_archive" if archive else "cohort_median"
            bid = node.get(bid_key)
            median = node.get(median_key)

            p95_label = f"  (p95: {p95:.0f}ms)" if p95 is not None else ""
            console.print(
                f"   Latency   {_score_bar(lat, 1.0)}  {lat:.3f}"
                f"{p95_label}{_bottleneck_label(lat)}"
            )

            ep_label = (
                f"  ({epochs_good}/140 good epochs)" if epochs_good is not None else ""
            )
            console.print(
                f"   Reliab.   {_score_bar(rel, 1.0)}  {rel:.3f}"
                f"{ep_label}{_bottleneck_label(rel)}"
            )

            console.print(
                f"   Success   {_score_bar(sr, 1.0)}  {sr:.3f}"
                f"  ({sr * 100:.1f}%){_bottleneck_label(sr)}"
            )

            bid_label = ""
            if bid is not None and median is not None:
                bid_label = f"  (bid: ${bid:.4f}, median: ${median:.4f})"
            console.print(
                f"   Price     {_score_bar(pf, 3.0)}  {pf:.3f}"
                f"{bid_label}{_bottleneck_label(pf)}"
            )

        console.print()


def _fetch_leaderboard(config: CLIConfig) -> dict:
    """Fetch leaderboard data from the registry API."""
    with RegistryClient(config) as client:
        response = client.get("/leaderboard")

    if response.status_code == 503:
        console.print(
            "[yellow]Leaderboard not available (scoring not enabled)[/yellow]"
        )
        raise typer.Exit(1)
    if response.status_code != 200:
        console.print(f"[red]Error:[/red] {response.status_code} - {response.text}")
        raise typer.Exit(1)

    return response.json()


@app.command("show")
def show(
    detail: bool = typer.Option(
        False, "--detail", "-d", help="Show score breakdown per component"
    ),
    archive: bool = typer.Option(
        False, "--archive", "-a", help="Show archive scores (default: lite/non-archive)"
    ),
) -> None:
    """Show the miner routing leaderboard."""
    config = load_config()
    own_hotkey = _get_own_hotkey(config)
    data = _fetch_leaderboard(config)

    if detail:
        _render_detail(data, own_hotkey, archive)
    else:
        _render_default(data, own_hotkey, archive)
