"""MCP server definition for renderdeck_mcp.

Registers all six tool stubs with the FastMCP server instance using stdio transport.
No Google or Gemini imports are triggered at module load time.

Actual tool implementations are wired in downstream tasks (generate-deck-tool, etc.).
"""

from __future__ import annotations

from collections.abc import Awaitable, Callable
from typing import Literal

from mcp.server.fastmcp import Context, FastMCP

mcp = FastMCP("renderdeck-mcp")

# Type alias for progress callbacks passed to tool implementations.
ProgressCallback = Callable[[float, float, str], Awaitable[None]]


def _make_progress_cb(ctx: Context | None) -> ProgressCallback | None:
    """Build an async progress callback from a FastMCP Context, or None.

    Uses ctx.info() (notifications/message) which is always sent without
    requiring the client to supply a progressToken. Also attempts
    report_progress() for clients that do support it.
    """
    if ctx is None:
        return None

    async def _cb(current: float, total: float, message: str) -> None:
        # Always send a log notification — works regardless of progressToken.
        await ctx.info(message)
        # Also try structured progress for clients that opt in.
        await ctx.report_progress(current, total, message)

    return _cb


# ---------------------------------------------------------------------------
# Tool stubs — all return {"status": "not_implemented", "message": "..."}
# ---------------------------------------------------------------------------


@mcp.tool()
async def generate_deck(
    slide_prompt_content: str,
    output_path: str | None = None,
    image_quality: Literal["draft", "final"] = "final",
    project_name: str | None = None,
    notes_mode: Literal["full", "narration"] = "full",
    ctx: Context | None = None,
) -> dict[str, object]:
    """Generate a .pptx presentation from a slide prompt file.

    Parses the prompt file, generates images via Gemini, and assembles
    a .pptx at output_path (default: ~/Documents/RenderDeck/{title}_{timestamp}.pptx).

    Set notes_mode to "narration" to include only the **Say:** content in speaker
    notes (labels stripped), useful for video generation tools like Pictory.
    """
    from renderdeck_mcp.tools.generate_deck import run_generate_deck

    progress_cb = _make_progress_cb(ctx)
    return await run_generate_deck(
        slide_prompt_content,
        output_path,
        image_quality,
        project_name,
        progress_cb=progress_cb,
        notes_mode=notes_mode,
    )


@mcp.tool()
def validate_prompt_file(
    slide_prompt_content: str,
) -> dict[str, object]:
    """Validate a slide prompt file and return any parsing errors.

    Checks syntax, required sections, and slide structure without generating images.
    """
    from renderdeck_mcp.tools.validate import run_validate

    return run_validate(slide_prompt_content)


@mcp.tool()
async def regenerate_slide(
    project_name: str,
    slide_numbers: list[int],
    slide_prompt_content: str,
    output_path: str | None = None,
    ctx: Context | None = None,
) -> dict[str, object]:
    """Regenerate specific slides in an existing project.

    Re-runs image generation for the given slide numbers, updates the cache,
    and rebuilds the .pptx at output_path. Requires the full prompt file
    content to obtain slide prompts.
    """
    from renderdeck_mcp.tools.regenerate import run_regenerate_slide

    progress_cb = _make_progress_cb(ctx)
    return await run_regenerate_slide(
        project_name,
        slide_numbers,
        slide_prompt_content,
        output_path,
        progress_cb=progress_cb,
    )


@mcp.tool()
def setup_gemini_key(
    api_key: str,
) -> dict[str, object]:
    """Store the Gemini API key securely for use by generate_deck.

    Saves the key to the encrypted local config. The key is validated by
    performing a lightweight test call to the Gemini API.
    """
    from renderdeck_mcp.tools.setup import run_setup_gemini_key

    return run_setup_gemini_key(api_key)


@mcp.tool()
def get_setup_status() -> dict[str, object]:
    """Return the current configuration and setup status.

    Reports whether the Gemini API key is configured, the active model,
    default output directory, and other settings.
    """
    from renderdeck_mcp.tools.setup import run_get_setup_status

    return run_get_setup_status()


@mcp.tool()
def update_settings(
    gemini_image_model: str | None = None,
    aspect_ratio: Literal["WIDE", "STANDARD"] | None = None,
    default_output_dir: str | None = None,
    gemini_max_retries: int | None = None,
    max_concurrent_images: int | None = None,
    verbose: bool | None = None,
) -> dict[str, object]:
    """Update renderdeck configuration settings.

    Only provided (non-None) fields are updated; omitted fields retain their
    current values.
    """
    from renderdeck_mcp.config import update_settings as _update

    valid_aspects = {"WIDE", "STANDARD"}
    if aspect_ratio is not None and aspect_ratio not in valid_aspects:
        return {
            "status": "error",
            "message": f"Invalid aspect_ratio: {aspect_ratio}. Must be WIDE or STANDARD.",
        }

    updates: dict[str, object] = {}
    for key, val in [
        ("gemini_image_model", gemini_image_model),
        ("aspect_ratio", aspect_ratio),
        ("default_output_dir", default_output_dir),
        ("gemini_max_retries", gemini_max_retries),
        ("max_concurrent_images", max_concurrent_images),
        ("verbose", verbose),
    ]:
        if val is not None:
            updates[key] = val

    if not updates:
        return {"status": "success", "message": "No settings to update", "settings": {}}

    merged = _update(updates)
    return {"status": "success", "message": "Settings updated", "settings": merged}


@mcp.tool()
def get_version() -> dict[str, object]:
    """Return the renderdeck-mcp server version."""
    from importlib.metadata import version

    return {"version": version("renderdeck-mcp")}


@mcp.tool()
def get_help() -> dict[str, object]:
    """Explain how RenderDeck works and list available tools, prompts, and resources.

    Call this tool when the user asks how RenderDeck works, what it can do,
    or wants to see available commands.
    """
    from importlib.metadata import version

    ver = version("renderdeck-mcp")

    return {
        "version": ver,
        "usage_hint": (
            "Tell your LLM 'How do I use RenderDeck?' "
            "to get a detailed explanation of all tools, "
            "workflows, and example prompts."
        ),
        "overview": (
            "RenderDeck is an MCP server that generates "
            "PowerPoint presentations from markdown prompt "
            "files. You write a structured prompt file "
            "describing your slides, and RenderDeck generates "
            "images via Google Gemini and assembles them into "
            "a .pptx with formatted speaker notes."
        ),
        "workflows": {
            "quick_start": {
                "description": ("Create a full presentation from a topic"),
                "steps": [
                    "Use the create_deck prompt with your topic",
                    ("The LLM reads the reference, writes a prompt file, validates, and generates"),
                ],
            },
            "step_by_step": {
                "description": ("Build a presentation with full control"),
                "steps": [
                    "Read renderdeck://reference for the format",
                    "Write your prompt file following the spec",
                    "Call validate_prompt_file to check errors",
                    "Call generate_deck to produce the .pptx",
                ],
            },
            "per_slide": {
                "description": ("Generate slides individually (avoids timeouts on large decks)"),
                "steps": [
                    "Call generate_slide for each slide",
                    "Call assemble_deck to build the .pptx",
                ],
            },
            "video_narration": {
                "description": (
                    "Generate a deck with narration-only speaker notes for video tools"
                ),
                "steps": [
                    "Use **Say:** labels for narration text",
                    ('Call generate_deck or assemble_deck with notes_mode="narration"'),
                    ("Only **Say:** content appears in notes (labels stripped)"),
                ],
            },
        },
        "tools": [
            {
                "name": "generate_deck",
                "description": ("Full pipeline: parse, generate images, assemble .pptx"),
                "key_params": ("slide_prompt_content, image_quality, notes_mode"),
            },
            {
                "name": "validate_prompt_file",
                "description": (
                    "Dry-run validation — checks syntax and structure, no image generation"
                ),
                "key_params": "slide_prompt_content",
            },
            {
                "name": "generate_slide",
                "description": ("Generate one slide image and cache it (avoids timeouts)"),
                "key_params": ("project_name, slide_number, image_prompt"),
            },
            {
                "name": "assemble_deck",
                "description": ("Assemble .pptx from cached slide images"),
                "key_params": ("project_name, slide_prompt_content, notes_mode"),
            },
            {
                "name": "regenerate_slide",
                "description": ("Re-generate specific slides and rebuild the .pptx"),
                "key_params": ("project_name, slide_numbers, slide_prompt_content"),
            },
            {
                "name": "setup_gemini_key",
                "description": ("Store and validate your Gemini API key"),
                "key_params": "api_key",
            },
            {
                "name": "get_setup_status",
                "description": ("Check API key config and current settings"),
                "key_params": "none",
            },
            {
                "name": "update_settings",
                "description": ("Change aspect ratio, model, output dir"),
                "key_params": ("aspect_ratio, gemini_image_model, default_output_dir"),
            },
            {
                "name": "get_version",
                "description": "Return the server version",
                "key_params": "none",
            },
            {
                "name": "get_help",
                "description": "Show this help (you are here)",
                "key_params": "none",
            },
        ],
        "prompts": [
            {
                "name": "create_deck",
                "description": (
                    "Guided end-to-end workflow: reads reference, writes, validates, generates"
                ),
                "params": "topic (string)",
                "example": ('create_deck(topic="Q1 engineering review")'),
            },
            {
                "name": "check_and_fix",
                "description": ("Validate a prompt file and get error-by-error fix suggestions"),
                "params": "content (string)",
                "example": ('check_and_fix(content="# My Deck...")'),
            },
        ],
        "resources": [
            {
                "uri": "renderdeck://reference",
                "description": ("Complete reference for writing slide prompt files"),
            },
        ],
        "example_prompts": [
            {
                "prompt": (
                    "Create a 10-slide deck on our Q1 "
                    "product roadmap for the engineering "
                    "all-hands. Audience: 50 engineers. "
                    "Tone: confident but honest about "
                    "delays. Include a timeline slide "
                    "and a risks slide."
                ),
                "what_happens": (
                    "The LLM reads the reference, "
                    "drafts a prompt file with 10 "
                    "slides, validates it, and calls "
                    "generate_deck."
                ),
            },
            {
                "prompt": (
                    "I have a blog post about our new "
                    "API. Turn it into a 7-slide "
                    "technical presentation for "
                    "DevRel to present at a meetup. "
                    "Use dark theme with code "
                    "snippets on slides."
                ),
                "what_happens": (
                    "The LLM distills the blog post "
                    "into key points, structures them "
                    "as slides, and generates visuals "
                    "matching the dark theme."
                ),
            },
            {
                "prompt": (
                    "Here is our investor update email "
                    "[paste text]. Create a 12-slide "
                    "board deck. Use notes_mode "
                    "narration so I can feed it into "
                    "Pictory for a video version."
                ),
                "what_happens": (
                    "The LLM extracts metrics and "
                    "narrative from the email, builds "
                    "slides with **Say:** notes for "
                    "narration, and generates with "
                    "notes_mode=narration."
                ),
            },
        ],
        "tips": {
            "generating_context_first": (
                "For best results, do not jump "
                "straight to slide generation. "
                "First ask the LLM to help you "
                "develop the raw material:"
            ),
            "recommended_steps": [
                {
                    "step": "1. BRAINSTORM",
                    "description": (
                        "Tell the LLM your topic, audience, "
                        "and goal. Ask it to outline key "
                        "messages and a narrative arc."
                    ),
                    "prompt": (
                        "I need a presentation about [topic] "
                        "for [audience]. The goal is [goal]. "
                        "Help me identify the 5-7 key messages "
                        "and suggest a narrative arc."
                    ),
                },
                {
                    "step": "2. STRUCTURE",
                    "description": (
                        "Ask the LLM to organise the outline "
                        "into a slide sequence with one idea "
                        "per slide and clear transitions."
                    ),
                    "prompt": (
                        "Organise these messages into a "
                        "slide-by-slide outline. One idea per "
                        "slide, with clear transitions. Suggest "
                        "a title for each slide."
                    ),
                },
                {
                    "step": "3. ENRICH",
                    "description": (
                        "Paste in any source material (docs, "
                        "emails, data, meeting notes). Ask the "
                        "LLM to distill the most compelling "
                        "points for your audience."
                    ),
                    "prompt": (
                        "Here is my source material: [paste "
                        "docs/emails/data]. Distill the most "
                        "compelling points for my audience and "
                        "weave them into the outline."
                    ),
                },
                {
                    "step": "4. GENERATE",
                    "description": (
                        "Once the storyline is solid, say "
                        "'now generate the deck'. The LLM "
                        "writes the prompt file and calls "
                        "the tools."
                    ),
                    "prompt": ("The outline looks good. Now generate the deck using RenderDeck."),
                },
                {
                    "step": "5. ITERATE",
                    "description": (
                        "Review the .pptx, then ask the LLM "
                        "to tweak individual slides, adjust "
                        "visuals, or reword notes."
                    ),
                    "prompt": (
                        "Slide 4 needs a stronger visual — "
                        "make it more data-driven. And reword "
                        "the speaker notes on slide 7 to be "
                        "more conversational."
                    ),
                },
            ],
            "pro_tip": (
                "The more context you give the LLM "
                "up front (audience, tone, key data "
                "points, what to emphasise, what to "
                "skip), the better the first draft. "
                "Treat the LLM as a presentation "
                "coach, not just a generator."
            ),
        },
    }


# ---------------------------------------------------------------------------
# Per-slide tools — preferred workflow for MCP clients with tool timeouts
# ---------------------------------------------------------------------------


@mcp.tool()
async def generate_slide(
    project_name: str,
    slide_number: int,
    image_prompt: str,
    general_context: str = "",
    visual_rules: str = "",
    image_quality: Literal["draft", "final"] = "final",
) -> dict[str, object]:
    """Generate a single slide image and cache it.

    Call this once per slide, then call assemble_deck to build the .pptx.
    This avoids tool-call timeouts by keeping each invocation short (~30-40s).
    Returns immediately if the slide is already cached with the same prompt.
    """
    from renderdeck_mcp.tools.generate_slide import run_generate_slide

    return await run_generate_slide(
        project_name,
        slide_number,
        image_prompt,
        general_context,
        visual_rules,
        image_quality,
    )


@mcp.tool()
def assemble_deck(
    project_name: str,
    slide_prompt_content: str,
    output_path: str | None = None,
    notes_mode: Literal["full", "narration"] = "full",
) -> dict[str, object]:
    """Assemble a .pptx from cached slide images.

    Call after running generate_slide for each slide. Reads cached images
    from the project cache directory and builds the final PowerPoint file.
    Slides without cached images become text-only slides.

    Set notes_mode to "narration" to include only the **Say:** content in speaker
    notes (labels stripped), useful for video generation tools like Pictory.
    """
    from renderdeck_mcp.tools.assemble_deck import run_assemble_deck

    return run_assemble_deck(project_name, slide_prompt_content, output_path, notes_mode=notes_mode)


# ---------------------------------------------------------------------------
# Entry point
# ---------------------------------------------------------------------------


def run() -> None:
    """Start the MCP server on stdio. Blocks until stdin EOF."""
    import renderdeck_mcp.prompts.templates  # noqa: F401  # registers @mcp.prompt
    import renderdeck_mcp.resources.handler  # noqa: F401  # registers @mcp.resource

    mcp.run()
