"""Todo read tool for viewing current task lists."""

from pydantic import BaseModel

from yier_agents.src.tool import Tool, ToolContext, ToolOutput
from yier_agents.src.todo import get_storage


class TodoReadParams(BaseModel):
    """Parameters for TodoRead tool (no parameters needed)."""
    pass


async def todo_read_execute(params: TodoReadParams, ctx: ToolContext) -> ToolOutput:
    """Execute TodoRead - get the current todo list.

    Args:
        params: TodoRead parameters (empty)
        ctx: Tool execution context

    Returns:
        ToolOutput with current todo list
    """
    # Load todos
    storage = get_storage()
    todos = storage.load(ctx.session_id)

    if not todos:
        return ToolOutput(
            content="No todos found for this session.",
            metadata={"total": 0},
            raw={
                "kind": "todo_list",
                "session_id": ctx.session_id,
                "total": 0,
                "status_counts": {
                    "pending": 0,
                    "in_progress": 0,
                    "completed": 0,
                },
                "todos": [],
            },
        )

    # Format todos for display
    lines = ["Current todo list:"]
    for i, todo in enumerate(todos, 1):
        status_icon = {
            "pending": "⏸",
            "in_progress": "▶",
            "completed": "✓"
        }.get(todo.status, "?")

        if todo.status == "in_progress":
            lines.append(f"{i}. [{status_icon}] {todo.activeForm}")
        else:
            lines.append(f"{i}. [{status_icon}] {todo.content}")

    # Add summary
    status_counts = {
        "pending": sum(1 for t in todos if t.status == "pending"),
        "in_progress": sum(1 for t in todos if t.status == "in_progress"),
        "completed": sum(1 for t in todos if t.status == "completed")
    }

    lines.append("")
    lines.append(f"Summary: {status_counts['completed']}/{len(todos)} completed")

    return ToolOutput(
        content="\n".join(lines),
        metadata={
            "total": len(todos),
            "status_counts": status_counts,
            "todos": [todo.model_dump() for todo in todos],
        },
        raw={
            "kind": "todo_list",
            "session_id": ctx.session_id,
            "total": len(todos),
            "status_counts": status_counts,
            "todos": [todo.model_dump() for todo in todos],
        },
    )


# Tool description
TODO_READ_DESCRIPTION = """Read the current todo list for this session.

Use this tool to:
- Check the current status of tasks
- See what tasks are pending, in progress, or completed
- Review the task list before making updates

This tool has no parameters - it automatically reads todos for the current session."""


# Create the TodoRead tool
TodoReadTool = Tool(
    name="todo_read",
    description=TODO_READ_DESCRIPTION,
    parameters=TodoReadParams,
    execute=todo_read_execute
)
