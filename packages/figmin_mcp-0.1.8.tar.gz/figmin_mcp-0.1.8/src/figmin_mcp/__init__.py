"""Figmin XR MCP Bridge - Connect Claude to Figmin XR."""

__version__ = "0.1.0"
