from .interpolator import JSONInterpolator

__all__ = ["JSONInterpolator"]
