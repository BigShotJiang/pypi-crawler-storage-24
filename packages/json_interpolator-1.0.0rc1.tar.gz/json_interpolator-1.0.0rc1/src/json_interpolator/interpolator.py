import json
import re


class JSONInterpolator:
    # Matches any <<name>> where name contains only word characters (letters, digits, underscores).
    # Validation of the name's content (e.g. must not start with a digit) is done in validate_template.
    PLACEHOLDER_REGEX = r"<<(?P<name>[a-zA-Z0-9_]+)>>"
    pattern = re.compile(PLACEHOLDER_REGEX)

    @classmethod
    def validate_template(cls, template: str) -> None:
        """
        Validates the template to ensure all placeholders are correctly formatted.

        Args:
            template (str): The template string to validate.

        Raises:
            ValueError: If invalid placeholders are found.
            TypeError: If the template is not a string.
        """
        if not isinstance(template, str):
            raise TypeError("Template must be string.")

        for mo in cls.pattern.finditer(template):
            name = mo.group("name")
            if name[0].isdigit():
                raise ValueError(f"Placeholder '{name}' cannot start with a digit.")
            if set(name) == {"_"}:
                raise ValueError(f"Placeholder '{name}' must include word characters.")

    @classmethod
    def validate_parameters(cls, params: dict) -> None:
        """
        Validates that parameters are provided as a dictionary.

        Args:
            params (dict): A dictionary containing placeholder-value pairs.

        Raises:
            TypeError: If the parameters are not a dictionary.
        """
        if not isinstance(params, dict):
            raise TypeError("Parameters must be a dictionary.")

    @classmethod
    def render_template(cls, params: dict, template: str) -> str:
        """
        Renders a template by replacing placeholders with corresponding values.

        Args:
            params (dict): A dictionary containing placeholder-value pairs.
            template (str): The template string with placeholders.

        Returns:
            str: The interpolated template with placeholders replaced by values.

        Raises:
            KeyError: If a placeholder has no matching entry in params.
            ValueError: If the rendered result is not valid JSON.
        """
        cls.validate_template(template)
        cls.validate_parameters(params)

        def _replace(mo: re.Match) -> str:
            name = mo.group("name")
            if name not in params:
                raise KeyError(f"Parameter '{name}' not found in the parameters.")
            return json.dumps(params[name])

        interpolated_string = cls.pattern.sub(_replace, template)

        try:
            json.loads(interpolated_string)
        except json.JSONDecodeError:
            raise ValueError("The rendered template is not valid JSON.")
        return interpolated_string
