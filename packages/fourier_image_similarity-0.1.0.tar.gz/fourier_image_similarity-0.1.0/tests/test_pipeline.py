from __future__ import annotations

import sys
import tempfile
import unittest
from pathlib import Path

import numpy as np
from PIL import Image


REPO_ROOT = Path(__file__).resolve().parents[1]
SRC_DIR = REPO_ROOT / "src"
if str(SRC_DIR) not in sys.path:
    sys.path.insert(0, str(SRC_DIR))

from fourier_image_similarity.pipeline import run_similarity_analysis


def _save_image(path: Path, image: np.ndarray) -> None:
    image_uint8 = np.clip(image * 255.0, 0, 255).astype(np.uint8)
    Image.fromarray(image_uint8, mode="L").save(path)


def _striped_image(size: int = 64, period: int = 8, shift: int = 0) -> np.ndarray:
    x = np.arange(size)
    pattern = ((x + shift) // period) % 2
    return np.tile(pattern, (size, 1)).astype(np.float64)


def _checkerboard(size: int = 64, period: int = 8) -> np.ndarray:
    y, x = np.indices((size, size))
    return (((x // period) + (y // period)) % 2).astype(np.float64)


class PipelineTestCase(unittest.TestCase):
    def test_similarity_ranks_related_images_higher(self) -> None:
        with tempfile.TemporaryDirectory() as temp_dir:
            root = Path(temp_dir)
            query_dir = root / "queries"
            reference_dir = root / "references"
            query_dir.mkdir()
            reference_dir.mkdir()

            _save_image(reference_dir / "ref_1.png", _striped_image())
            _save_image(reference_dir / "ref_2.png", _striped_image(shift=2))
            _save_image(query_dir / "similar.png", _striped_image(shift=1))
            _save_image(query_dir / "different.png", _checkerboard())

            rows, references = run_similarity_analysis(
                query_dir=query_dir,
                reference_dir=reference_dir,
                num_references=2,
                image_size=(64, 64),
                num_peaks=12,
                peak_window_radius=4,
                entropy_bins=8,
                peak_min_distance=4,
                dc_exclusion_radius=3,
                match_radius=5.0,
            )

            self.assertEqual(len(references), 2)
            self.assertEqual(rows[0]["file"], "similar.png")
            self.assertGreater(rows[0]["similarity_score"], rows[1]["similarity_score"])


if __name__ == "__main__":
    unittest.main()
