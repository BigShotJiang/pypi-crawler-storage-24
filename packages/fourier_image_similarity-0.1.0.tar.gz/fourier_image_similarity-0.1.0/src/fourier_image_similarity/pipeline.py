from __future__ import annotations

import csv
from dataclasses import dataclass
from pathlib import Path

from .features import FourierFeatures, peak_entropy, peak_prominence
from .fourier import fft_magnitude, fft_phase
from .io import LoadedImage, load_image_directory
from .peaks import detect_fft_peaks
from .reference import ReferenceSelectionResult, select_reference_indices
from .scoring import aggregate_similarity


@dataclass(frozen=True)
class DatasetEntry:
    image: LoadedImage
    features: FourierFeatures


def extract_fourier_features(
    image,
    num_peaks: int,
    peak_window_radius: int,
    entropy_bins: int,
    peak_min_distance: int,
    dc_exclusion_radius: int,
) -> FourierFeatures:
    """Extract the full frequency-domain feature set for one image."""
    magnitude = fft_magnitude(image)
    phase = fft_phase(image)
    peaks_xy = detect_fft_peaks(
        magnitude,
        num_peaks=num_peaks,
        min_distance=peak_min_distance,
        exclude_dc_radius=dc_exclusion_radius,
    )

    return FourierFeatures(
        fft_magnitude=magnitude,
        fft_phase=phase,
        peaks_xy=peaks_xy,
        peak_prominence=peak_prominence(magnitude, peaks_xy, peak_window_radius),
        peak_entropy=peak_entropy(magnitude, peaks_xy, entropy_bins, peak_window_radius),
        phase_entropy=peak_entropy(phase, peaks_xy, entropy_bins, peak_window_radius),
    )


def load_dataset(
    directory: str | Path,
    image_size: tuple[int, int] | None = (216, 685),
) -> list[LoadedImage]:
    return load_image_directory(directory, image_size=image_size)


def extract_dataset_features(
    dataset: list[LoadedImage],
    num_peaks: int = 35,
    peak_window_radius: int = 10,
    entropy_bins: int = 20,
    peak_min_distance: int = 10,
    dc_exclusion_radius: int = 6,
) -> list[DatasetEntry]:
    entries = []
    for loaded in dataset:
        features = extract_fourier_features(
            image=loaded.image,
            num_peaks=num_peaks,
            peak_window_radius=peak_window_radius,
            entropy_bins=entropy_bins,
            peak_min_distance=peak_min_distance,
            dc_exclusion_radius=dc_exclusion_radius,
        )
        entries.append(DatasetEntry(image=loaded, features=features))
    return entries


def select_references_from_directory(
    reference_candidate_dir: str | Path,
    num_references: int,
    image_size: tuple[int, int] | None = (216, 685),
    num_peaks: int = 35,
    peak_window_radius: int = 10,
    entropy_bins: int = 20,
    peak_min_distance: int = 10,
    dc_exclusion_radius: int = 6,
) -> tuple[list[DatasetEntry], ReferenceSelectionResult]:
    candidates = load_dataset(reference_candidate_dir, image_size=image_size)
    candidate_entries = extract_dataset_features(
        candidates,
        num_peaks=num_peaks,
        peak_window_radius=peak_window_radius,
        entropy_bins=entropy_bins,
        peak_min_distance=peak_min_distance,
        dc_exclusion_radius=dc_exclusion_radius,
    )
    selection = select_reference_indices(
        [entry.features.peaks_xy for entry in candidate_entries],
        num_references=num_references,
    )
    selected_entries = [candidate_entries[index] for index in selection.selected_indices]
    return selected_entries, selection


def run_similarity_analysis(
    query_dir: str | Path,
    reference_dir: str | Path | None = None,
    reference_candidate_dir: str | Path | None = None,
    num_references: int = 10,
    image_size: tuple[int, int] | None = (216, 685),
    num_peaks: int = 35,
    peak_window_radius: int = 10,
    entropy_bins: int = 20,
    peak_min_distance: int = 10,
    dc_exclusion_radius: int = 6,
    match_radius: float = 6.0,
) -> tuple[list[dict[str, float | str]], list[DatasetEntry]]:
    """Run the complete frequency-only comparison pipeline."""
    if reference_dir is None and reference_candidate_dir is None:
        raise ValueError("Provide either reference_dir or reference_candidate_dir.")
    if reference_dir is not None and reference_candidate_dir is not None:
        raise ValueError("Provide only one of reference_dir or reference_candidate_dir.")

    query_entries = extract_dataset_features(
        load_dataset(query_dir, image_size=image_size),
        num_peaks=num_peaks,
        peak_window_radius=peak_window_radius,
        entropy_bins=entropy_bins,
        peak_min_distance=peak_min_distance,
        dc_exclusion_radius=dc_exclusion_radius,
    )

    if reference_dir is not None:
        all_reference_entries = extract_dataset_features(
            load_dataset(reference_dir, image_size=image_size),
            num_peaks=num_peaks,
            peak_window_radius=peak_window_radius,
            entropy_bins=entropy_bins,
            peak_min_distance=peak_min_distance,
            dc_exclusion_radius=dc_exclusion_radius,
        )
        if num_references > 0 and len(all_reference_entries) > num_references:
            selection = select_reference_indices(
                [entry.features.peaks_xy for entry in all_reference_entries],
                num_references=num_references,
            )
            reference_entries = [all_reference_entries[index] for index in selection.selected_indices]
        else:
            reference_entries = all_reference_entries
    else:
        reference_entries, _ = select_references_from_directory(
            reference_candidate_dir=reference_candidate_dir,
            num_references=num_references,
            image_size=image_size,
            num_peaks=num_peaks,
            peak_window_radius=peak_window_radius,
            entropy_bins=entropy_bins,
            peak_min_distance=peak_min_distance,
            dc_exclusion_radius=dc_exclusion_radius,
        )

    rows = []
    for entry in query_entries:
        summary = aggregate_similarity(
            entry.features,
            [reference.features for reference in reference_entries],
            match_radius=match_radius,
        )
        rows.append(
            {
                "file": entry.image.path.name,
                "similarity_score": summary.similarity_score,
                "peak_match_ratio": summary.peak_match_ratio,
                "peak_mismatch_ratio": summary.peak_mismatch_ratio,
                "average_closest_peak_distance": summary.average_closest_peak_distance,
                "prominence_difference": summary.prominence_difference,
                "peak_entropy_difference": summary.peak_entropy_difference,
                "phase_entropy_difference": summary.phase_entropy_difference,
            }
        )

    rows = sorted(rows, key=lambda row: row["similarity_score"], reverse=True)
    return rows, reference_entries


def write_results_csv(rows: list[dict[str, float | str]], output_path: str | Path) -> None:
    """Write result rows to CSV."""
    output_path = Path(output_path)
    if not rows:
        output_path.write_text("")
        return

    with output_path.open("w", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0].keys()))
        writer.writeheader()
        writer.writerows(rows)
