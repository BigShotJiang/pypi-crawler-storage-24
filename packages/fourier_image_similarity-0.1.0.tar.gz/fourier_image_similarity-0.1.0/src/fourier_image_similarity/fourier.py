from __future__ import annotations

import numpy as np


def normalize_min_max(values: np.ndarray) -> np.ndarray:
    """Scale an array to [0, 1]."""
    values = np.asarray(values, dtype=np.float64)
    value_range = values.max() - values.min()
    if value_range == 0:
        return np.zeros_like(values, dtype=np.float64)
    return (values - values.min()) / value_range


def fft_complex(image: np.ndarray) -> np.ndarray:
    """Return the centered 2D Fourier transform."""
    return np.fft.fftshift(np.fft.fft2(image))


def fft_magnitude(image: np.ndarray, log_scale: bool = True) -> np.ndarray:
    """Return a normalized Fourier magnitude image."""
    magnitude = np.abs(fft_complex(image))
    if log_scale:
        magnitude = 20.0 * np.log1p(magnitude)
    return normalize_min_max(magnitude)


def fft_phase(image: np.ndarray) -> np.ndarray:
    """Return the normalized Fourier phase image."""
    phase = np.angle(fft_complex(image))
    return normalize_min_max(phase)
