from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path

import numpy as np
from PIL import Image


SUPPORTED_EXTENSIONS = {".tif", ".tiff", ".png", ".jpg", ".jpeg", ".bmp"}


@dataclass(frozen=True)
class LoadedImage:
    path: Path
    image: np.ndarray


def list_image_paths(directory: str | Path) -> list[Path]:
    """Return sorted image paths from a directory."""
    directory = Path(directory)
    if not directory.exists():
        raise FileNotFoundError(f"Directory does not exist: {directory}")
    if not directory.is_dir():
        raise NotADirectoryError(f"Path is not a directory: {directory}")

    paths = [path for path in directory.iterdir() if path.suffix.lower() in SUPPORTED_EXTENSIONS]
    return sorted(paths)


def load_grayscale_image(path: str | Path, image_size: tuple[int, int] | None = None) -> np.ndarray:
    """Load an image, convert it to grayscale float format, and optionally resize it."""
    image = Image.open(path).convert("L")
    if image_size is not None:
        height, width = image_size
        image = image.resize((width, height), Image.Resampling.LANCZOS)
    image_array = np.asarray(image, dtype=np.float64) / 255.0
    return image_array


def load_image_directory(
    directory: str | Path,
    image_size: tuple[int, int] | None = None,
) -> list[LoadedImage]:
    """Load every supported image in a directory."""
    paths = list_image_paths(directory)
    return [LoadedImage(path=path, image=load_grayscale_image(path, image_size)) for path in paths]
