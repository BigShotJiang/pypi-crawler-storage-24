from __future__ import annotations

import argparse
from pathlib import Path

from .pipeline import run_similarity_analysis, select_references_from_directory, write_results_csv


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description="Run frequency-domain image similarity analysis on a set of images."
    )
    parser.add_argument("--query-dir", required=True, help="Directory containing query images.")
    parser.add_argument("--reference-dir", help="Directory containing reference images.")
    parser.add_argument(
        "--reference-candidate-dir",
        help="Directory containing a larger pool from which references should be selected.",
    )
    parser.add_argument("--num-references", type=int, default=10, help="Number of references to keep.")
    parser.add_argument("--height", type=int, default=216, help="Resize height.")
    parser.add_argument("--width", type=int, default=685, help="Resize width.")
    parser.add_argument("--num-peaks", type=int, default=35, help="Number of Fourier peaks to detect.")
    parser.add_argument("--peak-window-radius", type=int, default=10, help="Radius for local peak features.")
    parser.add_argument("--peak-min-distance", type=int, default=10, help="Minimum spacing between peaks.")
    parser.add_argument("--dc-exclusion-radius", type=int, default=6, help="Radius of the masked DC region.")
    parser.add_argument("--entropy-bins", type=int, default=20, help="Histogram bins for entropy features.")
    parser.add_argument("--match-radius", type=float, default=6.0, help="Distance threshold for peak matching.")
    parser.add_argument("--csv-out", help="Optional path to save the result table as CSV.")
    return parser


def main() -> None:
    parser = build_parser()
    args = parser.parse_args()

    image_size = (args.height, args.width)
    selection = None

    if args.reference_candidate_dir:
        selected_references, selection = select_references_from_directory(
            reference_candidate_dir=args.reference_candidate_dir,
            num_references=args.num_references,
            image_size=image_size,
            num_peaks=args.num_peaks,
            peak_window_radius=args.peak_window_radius,
            entropy_bins=args.entropy_bins,
            peak_min_distance=args.peak_min_distance,
            dc_exclusion_radius=args.dc_exclusion_radius,
        )
        print("Selected reference images:")
        for entry in selected_references:
            print(f"  - {entry.image.path.name}")
        print()

    results, references = run_similarity_analysis(
        query_dir=args.query_dir,
        reference_dir=args.reference_dir,
        reference_candidate_dir=args.reference_candidate_dir,
        num_references=args.num_references,
        image_size=image_size,
        num_peaks=args.num_peaks,
        peak_window_radius=args.peak_window_radius,
        entropy_bins=args.entropy_bins,
        peak_min_distance=args.peak_min_distance,
        dc_exclusion_radius=args.dc_exclusion_radius,
        match_radius=args.match_radius,
    )

    print("References used:")
    for entry in references:
        print(f"  - {entry.image.path.name}")
    print()

    columns = [
        "file",
        "similarity_score",
        "peak_match_ratio",
        "peak_mismatch_ratio",
        "average_closest_peak_distance",
        "prominence_difference",
        "peak_entropy_difference",
        "phase_entropy_difference",
    ]
    widths = {column: len(column) for column in columns}
    for row in results:
        for column in columns:
            value = row[column]
            text = value if isinstance(value, str) else f"{value:.4f}"
            widths[column] = max(widths[column], len(text))

    print(" ".join(column.ljust(widths[column]) for column in columns))
    print(" ".join("-" * widths[column] for column in columns))
    for row in results:
        rendered = []
        for column in columns:
            value = row[column]
            text = value if isinstance(value, str) else f"{value:.4f}"
            rendered.append(text.ljust(widths[column]))
        print(" ".join(rendered))

    if args.csv_out:
        output_path = Path(args.csv_out)
        output_path.parent.mkdir(parents=True, exist_ok=True)
        write_results_csv(results, output_path)
        print()
        print(f"Saved results to {output_path}")

    if selection is not None:
        print()
        print("Reference selection scores:")
        for index in selection.selected_indices:
            print(
                f"  - {references[list(selection.selected_indices).index(index)].image.path.name}: "
                f"{selection.representativeness_scores[index]:.4f}"
            )
