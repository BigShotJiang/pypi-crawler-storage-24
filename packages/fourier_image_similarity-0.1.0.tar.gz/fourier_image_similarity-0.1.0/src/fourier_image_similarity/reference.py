from __future__ import annotations

from dataclasses import dataclass

import numpy as np


@dataclass(frozen=True)
class ReferenceSelectionResult:
    selected_indices: np.ndarray
    representativeness_scores: np.ndarray


def _pairwise_peak_distance(peaks_a: np.ndarray, peaks_b: np.ndarray) -> float:
    if len(peaks_a) == 0 or len(peaks_b) == 0:
        return float("inf")

    distances = np.linalg.norm(peaks_a[:, None, :] - peaks_b[None, :, :], axis=2)
    nearest = distances.min(axis=1)
    return float(nearest.mean())


def select_reference_indices(
    peaks_list: list[np.ndarray],
    num_references: int,
) -> ReferenceSelectionResult:
    """Choose the most representative references from a candidate pool.

    The heuristic is frequency-only: each candidate is scored by how close its peak pattern
    is to the rest of the candidate pool. Lower mean nearest-peak distance implies that the
    image is more central and therefore a better reference.
    """
    if not peaks_list:
        raise ValueError("Reference selection requires at least one candidate image.")

    num_candidates = len(peaks_list)
    num_references = min(num_references, num_candidates)

    scores = np.zeros(num_candidates, dtype=np.float64)
    for i, peaks_a in enumerate(peaks_list):
        distances = []
        for j, peaks_b in enumerate(peaks_list):
            if i == j:
                continue
            distances.append(_pairwise_peak_distance(peaks_a, peaks_b))

        finite_distances = [distance for distance in distances if np.isfinite(distance)]
        if finite_distances:
            scores[i] = -float(np.mean(finite_distances))
        else:
            scores[i] = -1e9

    selected = np.argsort(scores)[-num_references:][::-1]
    return ReferenceSelectionResult(
        selected_indices=selected,
        representativeness_scores=scores,
    )
