from __future__ import annotations

import numpy as np
from scipy.ndimage import maximum_filter


def detect_fft_peaks(
    magnitude: np.ndarray,
    num_peaks: int = 35,
    min_distance: int = 10,
    exclude_dc_radius: int = 6,
) -> np.ndarray:
    """Detect strong local maxima in the Fourier magnitude image.

    Coordinates are returned in `(x, y)` order to keep distance calculations explicit.
    The low-frequency DC region around the spectrum center is masked out because it is
    usually dominant but not very informative for pattern comparison.
    """
    masked = magnitude.copy()
    center_y, center_x = np.array(masked.shape) // 2

    yy, xx = np.ogrid[:masked.shape[0], :masked.shape[1]]
    dc_mask = (yy - center_y) ** 2 + (xx - center_x) ** 2 <= exclude_dc_radius ** 2
    masked[dc_mask] = 0.0

    footprint_size = max(1, 2 * min_distance + 1)
    local_max = maximum_filter(masked, size=footprint_size, mode="nearest")
    peak_mask = (masked == local_max) & (masked > 0)
    peaks_yx = np.argwhere(peak_mask)

    if len(peaks_yx) == 0:
        return np.empty((0, 2), dtype=np.int64)

    strengths = masked[peaks_yx[:, 0], peaks_yx[:, 1]]
    order = np.argsort(strengths)[::-1][:num_peaks]
    return peaks_yx[order][:, ::-1]
