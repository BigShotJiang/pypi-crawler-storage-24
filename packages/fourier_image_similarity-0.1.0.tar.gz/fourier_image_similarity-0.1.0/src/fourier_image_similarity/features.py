from __future__ import annotations

from dataclasses import dataclass

import numpy as np
from scipy.stats import entropy


@dataclass(frozen=True)
class FourierFeatures:
    fft_magnitude: np.ndarray
    fft_phase: np.ndarray
    peaks_xy: np.ndarray
    peak_prominence: np.ndarray
    peak_entropy: np.ndarray
    phase_entropy: np.ndarray


def _disk_values(image: np.ndarray, x: int, y: int, radius: int) -> np.ndarray:
    yy, xx = np.ogrid[:image.shape[0], :image.shape[1]]
    mask = (yy - y) ** 2 + (xx - x) ** 2 <= radius ** 2
    return image[mask]


def peak_prominence(image: np.ndarray, peaks_xy: np.ndarray, radius: int) -> np.ndarray:
    """Compute local peak prominence as max minus min inside a disk around each peak."""
    values = np.zeros(len(peaks_xy), dtype=np.float64)
    for index, (x, y) in enumerate(peaks_xy):
        region = _disk_values(image, x, y, radius)
        values[index] = float(np.ptp(region)) if region.size else 0.0
    return values


def peak_entropy(image: np.ndarray, peaks_xy: np.ndarray, bins: int, radius: int) -> np.ndarray:
    """Compute local histogram entropy around each peak."""
    values = np.zeros(len(peaks_xy), dtype=np.float64)
    for index, (x, y) in enumerate(peaks_xy):
        region = _disk_values(image, x, y, radius)
        if region.size == 0:
            continue
        hist, _ = np.histogram(region, bins=bins, range=(0.0, 1.0))
        total = hist.sum()
        if total == 0:
            continue
        probabilities = hist / total
        values[index] = float(entropy(probabilities, base=2))
    return values
