from __future__ import annotations

from dataclasses import dataclass

import numpy as np

from .features import FourierFeatures


@dataclass(frozen=True)
class PairwiseSimilarity:
    similarity_score: float
    peak_match_ratio: float
    peak_mismatch_ratio: float
    average_closest_peak_distance: float
    prominence_difference: float
    peak_entropy_difference: float
    phase_entropy_difference: float


@dataclass(frozen=True)
class AggregateSimilarity:
    similarity_score: float
    peak_match_ratio: float
    peak_mismatch_ratio: float
    average_closest_peak_distance: float
    prominence_difference: float
    peak_entropy_difference: float
    phase_entropy_difference: float


def _pairwise_distances(peaks_a: np.ndarray, peaks_b: np.ndarray) -> np.ndarray:
    if len(peaks_a) == 0 or len(peaks_b) == 0:
        return np.empty((len(peaks_a), len(peaks_b)))
    return np.linalg.norm(peaks_a[:, None, :] - peaks_b[None, :, :], axis=2)


def count_peak_matches(peaks_a: np.ndarray, peaks_b: np.ndarray, match_radius: float) -> tuple[int, int]:
    """Count matched and unmatched peaks between two peak sets."""
    if len(peaks_a) == 0 and len(peaks_b) == 0:
        return 0, 0
    if len(peaks_a) == 0:
        return 0, len(peaks_b)
    if len(peaks_b) == 0:
        return 0, len(peaks_a)

    distances = _pairwise_distances(peaks_a, peaks_b)
    matched_pairs = np.argwhere(distances <= match_radius)

    if matched_pairs.size == 0:
        return 0, len(peaks_a) + len(peaks_b)

    matched_a = np.unique(matched_pairs[:, 0])
    matched_b = np.unique(matched_pairs[:, 1])
    matches = min(len(matched_a), len(matched_b))
    mismatches = (len(peaks_a) - len(matched_a)) + (len(peaks_b) - len(matched_b))
    return matches, mismatches


def average_closest_peak_distance(peaks_a: np.ndarray, peaks_b: np.ndarray) -> float:
    """Average distance from each peak in `a` to its closest peak in `b`."""
    if len(peaks_a) == 0 or len(peaks_b) == 0:
        return float("inf")
    distances = _pairwise_distances(peaks_a, peaks_b)
    return float(distances.min(axis=1).mean())


def _mean_or_default(values: np.ndarray, default: float = 0.0) -> float:
    return float(values.mean()) if len(values) else default


def compare_feature_sets(
    query: FourierFeatures,
    reference: FourierFeatures,
    match_radius: float,
) -> PairwiseSimilarity:
    """Compare one query image against one reference image."""
    matches, mismatches = count_peak_matches(query.peaks_xy, reference.peaks_xy, match_radius)
    total_peaks = max(len(query.peaks_xy) + len(reference.peaks_xy), 1)
    match_ratio = matches / max(min(len(query.peaks_xy), len(reference.peaks_xy)), 1)
    mismatch_ratio = mismatches / total_peaks

    mean_distance = average_closest_peak_distance(query.peaks_xy, reference.peaks_xy)

    prominence_diff = abs(_mean_or_default(query.peak_prominence) - _mean_or_default(reference.peak_prominence))
    peak_entropy_diff = abs(_mean_or_default(query.peak_entropy) - _mean_or_default(reference.peak_entropy))
    phase_entropy_diff = abs(_mean_or_default(query.phase_entropy) - _mean_or_default(reference.phase_entropy))

    # Convert dissimilarity terms to bounded similarity terms so the final score is easier
    # to interpret and compare across runs.
    distance_similarity = 1.0 / (1.0 + mean_distance) if np.isfinite(mean_distance) else 0.0
    prominence_similarity = 1.0 / (1.0 + prominence_diff)
    peak_entropy_similarity = 1.0 / (1.0 + peak_entropy_diff)
    phase_entropy_similarity = 1.0 / (1.0 + phase_entropy_diff)
    mismatch_similarity = 1.0 - min(max(mismatch_ratio, 0.0), 1.0)
    match_similarity = min(max(match_ratio, 0.0), 1.0)

    similarity_score = float(
        0.35 * match_similarity
        + 0.20 * mismatch_similarity
        + 0.20 * distance_similarity
        + 0.10 * prominence_similarity
        + 0.075 * peak_entropy_similarity
        + 0.075 * phase_entropy_similarity
    )

    return PairwiseSimilarity(
        similarity_score=similarity_score,
        peak_match_ratio=match_ratio,
        peak_mismatch_ratio=mismatch_ratio,
        average_closest_peak_distance=mean_distance,
        prominence_difference=prominence_diff,
        peak_entropy_difference=peak_entropy_diff,
        phase_entropy_difference=phase_entropy_diff,
    )


def aggregate_similarity(
    query: FourierFeatures,
    references: list[FourierFeatures],
    match_radius: float,
) -> AggregateSimilarity:
    """Average pairwise similarity metrics across a reference set."""
    if not references:
        raise ValueError("At least one reference image is required.")

    pairwise = [compare_feature_sets(query, reference, match_radius) for reference in references]

    return AggregateSimilarity(
        similarity_score=float(np.mean([result.similarity_score for result in pairwise])),
        peak_match_ratio=float(np.mean([result.peak_match_ratio for result in pairwise])),
        peak_mismatch_ratio=float(np.mean([result.peak_mismatch_ratio for result in pairwise])),
        average_closest_peak_distance=float(
            np.mean([result.average_closest_peak_distance for result in pairwise])
        ),
        prominence_difference=float(np.mean([result.prominence_difference for result in pairwise])),
        peak_entropy_difference=float(np.mean([result.peak_entropy_difference for result in pairwise])),
        phase_entropy_difference=float(np.mean([result.phase_entropy_difference for result in pairwise])),
    )
