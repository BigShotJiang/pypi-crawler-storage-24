"""
Video Analyzer CLI

This application provides tools for analyzing video files using Optical Flow techniques.
It leverages the Click framework to provide a professional, POSIX-compliant interface.
"""

import cv2
import numpy as np
import click
import sys

@click.group()
def cli():
    """
    A professional Command-Line Interface for video motion analysis.
    
    This tool provides access to both Sparse and Dense Optical Flow algorithms 
    for tracking features and detecting high-motion highlights.
    """
    pass

@cli.command(name='track-sparse')
@click.argument('video_path', type=click.Path(exists=True, readable=True, dir_okay=False))
@click.option('--max-corners', default=100, type=int, help='Maximum number of corners to track.')
@click.option('--quality-level', default=0.3, type=float, help='Minimal accepted quality of image corners.')
@click.option('--min-distance', default=7, type=int, help='Minimum possible distance between returned corners.')
@click.option('--block-size', default=7, type=int, help='Size of the block for computing a derivative covariation matrix.')
@click.option('--win-size', default=15, type=int, help='Size of the search window at each pyramid level.')
@click.option('--max-level', default=2, type=int, help='Maximal pyramid level number.')
def track_sparse(video_path, max_corners, quality_level, min_distance, block_size, win_size, max_level):
    """
    Track specific points across video frames.

    This command uses Lucas Kanade Sparse Optical Flow to find and track 
    the strongest corners in the image. It is highly useful for stabilizing 
    shaky footage or tracking a specific subject to keep them centered.
    """
    click.echo(f"Starting Sparse Optical Flow on {video_path}...")
    click.echo("Press 'q' or 'ESC' in the video window to quit.")

    cap = cv2.VideoCapture(video_path)

    # Parameters for ShiTomasi corner detection
    feature_params = dict(
        maxCorners=max_corners,
        qualityLevel=quality_level,
        minDistance=min_distance,
        blockSize=block_size
    )

    # Parameters for Lucas Kanade optical flow
    lk_params = dict(
        winSize=(win_size, win_size),
        maxLevel=max_level,
        criteria=(cv2.TERM_CRITERIA_EPS | cv2.TERM_CRITERIA_COUNT, 10, 0.03)
    )

    # Create random colors for drawing tracks
    color = np.random.randint(0, 255, (100, 3))

    ret, old_frame = cap.read()
    if not ret:
        click.echo("Error: Could not read the video file.", err=True)
        sys.exit(1)

    old_gray = cv2.cvtColor(old_frame, cv2.COLOR_BGR2GRAY)
    p0 = cv2.goodFeaturesToTrack(old_gray, mask=None, **feature_params)

    # Create a mask image for drawing purposes
    mask = np.zeros_like(old_frame)

    while True:
        ret, frame = cap.read()
        if not ret:
            break
            
        frame_gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)

        # Calculate optical flow
        p1, st, err = cv2.calcOpticalFlowPyrLK(old_gray, frame_gray, p0, None, **lk_params)

        # Select good points
        if p1 is not None:
            good_new = p1[st == 1]
            good_old = p0[st == 1]

            # Draw the tracks
            for i, (new, old) in enumerate(zip(good_new, good_old)):
                a, b = new.ravel()
                c, d = old.ravel()
                # Draw line for motion history
                mask = cv2.line(mask, (int(a), int(b)), (int(c), int(d)), color[i].tolist(), 2)
                # Draw dot for current position
                frame = cv2.circle(frame, (int(a), int(b)), 5, color[i].tolist(), -1)
            
        img = cv2.add(frame, mask)
        cv2.imshow('Sparse Optical Flow Tracker', img)

        k = cv2.waitKey(30) & 0xff
        if k == 27 or k == ord('q'):
            break

        # Update the previous frame and previous points
        old_gray = frame_gray.copy()
        if p1 is not None:
            p0 = good_new.reshape(-1, 1, 2)

    cv2.destroyAllWindows()
    cap.release()
    click.echo("Sparse tracking completed.")


@cli.command(name='detect-dense')
@click.argument('video_path', type=click.Path(exists=True, readable=True, dir_okay=False))
@click.option('--threshold', '-t', default=5.0, type=click.FloatRange(min=0.0), help='Motion intensity threshold required to flag a highlight.')
def detect_dense(video_path, threshold):
    """
    Analyze video for global energy highlights.

    This command calculates motion for every pixel using Farneback Dense Optical Flow. 
    It is computationally heavier but allows the system to detect global energy changes 
    such as applause, laughter, or rapid movement.
    """
    click.echo(f"Analyzing {video_path} for high motion events (Threshold: {threshold})...")
    click.echo("Press 'q' or 'ESC' in the video window to quit.")

    cap = cv2.VideoCapture(video_path)
    
    ret, frame1 = cap.read()
    if not ret:
        click.echo("Error: Could not read the video file.", err=True)
        sys.exit(1)

    prvs = cv2.cvtColor(frame1, cv2.COLOR_BGR2GRAY)
    hsv = np.zeros_like(frame1)
    hsv[..., 1] = 255

    while True:
        ret, frame2 = cap.read()
        if not ret:
            break
            
        next_frame = cv2.cvtColor(frame2, cv2.COLOR_BGR2GRAY)

        # Calculate Dense Optical Flow
        flow = cv2.calcOpticalFlowFarneback(prvs, next_frame, None, 0.5, 3, 15, 3, 5, 1.2, 0)

        # Convert Cartesian coordinates to Polar coordinates
        mag, ang = cv2.cartToPolar(flow[..., 0], flow[..., 1])

        # Visualization
        hsv[..., 0] = ang * 180 / np.pi / 2
        hsv[..., 2] = cv2.normalize(mag, None, 0, 255, cv2.NORM_MINMAX)
        bgr = cv2.cvtColor(hsv, cv2.COLOR_HSV2BGR)

        # Calculate the mean motion intensity of the frame
        avg_motion = np.mean(mag)
        timestamp = cap.get(cv2.CAP_PROP_POS_MSEC) / 1000.0

        if avg_motion > threshold:
            click.echo(f"🔥 Highlight Detected at {timestamp:.2f} seconds (Intensity: {avg_motion:.2f})")
            # Draw a red border to visualize the detection
            cv2.rectangle(bgr, (0, 0), (bgr.shape[1], bgr.shape[0]), (0, 0, 255), 10)

        cv2.imshow('Dense Optical Flow Highlight Detector', bgr)

        k = cv2.waitKey(30) & 0xff
        if k == 27 or k == ord('q'):
            break

        prvs = next_frame

    cap.release()
    cv2.destroyAllWindows()
    click.echo("Highlight detection completed.")

if __name__ == "__main__":
    cli()