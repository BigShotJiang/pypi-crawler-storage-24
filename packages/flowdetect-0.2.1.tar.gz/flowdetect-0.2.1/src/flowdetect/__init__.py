from .main import cli

if __name__ == "__main__":
    __all__ = ["track_sparse", "detect_dense"]
    cli()
