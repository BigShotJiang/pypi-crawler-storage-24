# FlowDetect

FlowDetect is a program for your command line that looks at motion in video files. It tracks movement and finds moments with high action. This tool uses Python and provides a simple way to use it.

## Description

This program offers two main ways to processs video.

### Track Specific Points

This method finds and tracks specific strong points, such as corners, across video frames. It is very useful for making shaky videos smoother or keeping a moving subject in the center.

### Detect High Action Moments

This method calculates the movement of every single pixel in the video frame. It requires more computer power but allows the system to find big energy changes, such as a crowd cheering or sudden fast movement.

## Installation

You can install this software package using a Python installer like `uv` or `pip`.

Using `uv`:

```
uv tool install flowdetect

```

Using `pip`:

```
pip install flowdetect

```

## Usage

After you install the software, you can run the program from your terminal using the `flowdetect` command.

To view the main help page and see available commands, run:

```
flowdetect --help

```

### Track Specific Points

Use the `track-sparse` command to follow clear features in your video.

```
flowdetect track-sparse my_video.mp4

```

You can change the behavior of the tracking process by providing extra settings. If you do not provide these settings, the tool will use default values.

Checklist of available settings for tracking points:

* [ ] `--max-corners`: Maximum number of corners to track (Default is 100).

* [ ] `--quality-level`: Lowest accepted quality of image corners (Default is 0.3).

* [ ] `--min-distance`: Minimum possible space between returned corners (Default is 7).

* [ ] `--block-size`: Size of the block for calculating the values (Default is 7).

* [ ] `--win-size`: Size of the search window (Default is 15).

* [ ] `--max-level`: Maximum image scaling level (Default is 2).

### Detect High Action Moments

Use the `detect-dense` command to scan the video for moments of high overall movement. The application will print a timestamp whenever the average motion goes above your set limit.

```
flowdetect detect-dense my_video.mp4

```

Checklist of available settings for overall motion detection:

* [ ] `--threshold` or `-t`: The motion limit required to log a highlight. Lower numbers are more sensitive to movement (Default is 5.0).