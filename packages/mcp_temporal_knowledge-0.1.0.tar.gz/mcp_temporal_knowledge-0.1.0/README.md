# Temporal Knowledge Substrate

MCP server for domain-scoped knowledge accumulation with tool-enforced temporal integrity.

Two-layer architecture: an immutable **process layer** (temporal backbone) and an **append-only knowledge layer** (what was learned). Tools enforce structural invariants — no raw Cypher writes.

## Quick Start

```bash
uv sync --dev
mcp-temporal-knowledge --db-url bolt://localhost:7687
```

See `SPEC.md` for full architecture documentation.
