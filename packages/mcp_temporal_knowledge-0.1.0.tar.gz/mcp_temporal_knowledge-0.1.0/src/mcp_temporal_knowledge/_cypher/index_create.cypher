CREATE FULLTEXT INDEX knowledge_index IF NOT EXISTS
FOR (n:System|Process|Configuration|Person|Gotcha|Rationale|
     Dependency|Change|Artifact|Insight)
ON EACH [n.name, n.description]
