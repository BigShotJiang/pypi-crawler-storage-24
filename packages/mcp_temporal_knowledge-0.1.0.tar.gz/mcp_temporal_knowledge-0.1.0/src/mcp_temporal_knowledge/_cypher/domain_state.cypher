MATCH (e)
WHERE e.domain = $domain
  AND NOT (e)<-[:EVOLVED_FROM]-()
  AND NOT e:Domain AND NOT e:Run
WITH e
OPTIONAL MATCH (e)-[r]->(other)
WHERE other.domain IS NOT NULL
  AND NOT (other)<-[:EVOLVED_FROM]-()
  AND type(r) <> 'DISCOVERED' AND type(r) <> 'HAS_RUN' AND type(r) <> 'NEXT_RUN'
RETURN e.name AS name, labels(e)[0] AS type, e.description AS description,
       e.t_created AS t_created,
       collect(DISTINCT {target: other.name, type: type(r)}) AS connections
ORDER BY e.t_created DESC
