import logging
import uuid
from enum import Enum
from typing import Any, Dict, List

from neo4j import AsyncDriver, RoutingControl
from pydantic import BaseModel, Field

from .utils import load_cypher


# Set up logging
logger = logging.getLogger('mcp_temporal_knowledge')
logger.setLevel(logging.INFO)


def _neo4j_datetime_to_str(val) -> str | None:
    """Convert a Neo4j DateTime/Date to ISO string, or return None."""
    if val is None:
        return None
    return val.iso_format()


# ── Enums ────────────────────────────────────────────────────

class KnowledgeType(str, Enum):
    """Allowed knowledge entity type labels for the temporal knowledge substrate.

    10 organizational knowledge types. Process types (Domain, Run)
    are created exclusively by process tools and are NOT in this enum.
    """
    SYSTEM = "System"
    PROCESS = "Process"
    CONFIGURATION = "Configuration"
    PERSON = "Person"
    GOTCHA = "Gotcha"
    RATIONALE = "Rationale"
    DEPENDENCY = "Dependency"
    CHANGE = "Change"
    ARTIFACT = "Artifact"
    INSIGHT = "Insight"


class ConnectionType(str, Enum):
    """Allowed knowledge connection types for the temporal knowledge substrate.

    7 knowledge edge types. Process edges (HAS_RUN, NEXT_RUN, DISCOVERED)
    are created exclusively by process tools and are NOT in this enum.
    """
    EVOLVED_FROM = "EVOLVED_FROM"
    ENABLING = "ENABLING"
    REQUIRING = "REQUIRING"
    INFORMING = "INFORMING"
    CAUSING = "CAUSING"
    COMPOSING = "COMPOSING"
    RELATES_TO = "RELATES_TO"


# Process-layer label strings for guard checks
PROCESS_TYPES = {"Domain", "Run"}

# Process-layer edge type strings for guard checks
PROCESS_EDGES = {"HAS_RUN", "NEXT_RUN", "DISCOVERED"}


KNOWLEDGE_TYPE_DESCRIPTIONS: Dict[KnowledgeType, str] = {
    KnowledgeType.SYSTEM: "A software system, platform, or tool",
    KnowledgeType.PROCESS: "How something works — a workflow, procedure, routine",
    KnowledgeType.CONFIGURATION: "A specific setting, parameter, or setup detail",
    KnowledgeType.PERSON: "A role, contact, or responsible party",
    KnowledgeType.GOTCHA: "A trap, pitfall, or non-obvious failure mode",
    KnowledgeType.RATIONALE: "Why a decision was made — the reasoning behind config/process",
    KnowledgeType.DEPENDENCY: "An external requirement or integration point",
    KnowledgeType.CHANGE: "A tracked change, deprecation, or rollout",
    KnowledgeType.ARTIFACT: "A document, file, screenshot, or reference material",
    KnowledgeType.INSIGHT: "A discovered truth or realization about the domain",
}


CONNECTION_TYPE_DESCRIPTIONS: Dict[ConnectionType, str] = {
    ConnectionType.EVOLVED_FROM: "New version → old version (knowledge changed form)",
    ConnectionType.ENABLING: "Source makes target possible",
    ConnectionType.REQUIRING: "Source depends on target for coherence",
    ConnectionType.INFORMING: "Source shaped target without causing it",
    ConnectionType.CAUSING: "Source directly produced target",
    ConnectionType.COMPOSING: "Source is a building block of target",
    ConnectionType.RELATES_TO: "Cross-domain or loosely coupled connection",
}


# ── Pydantic Models ──────────────────────────────────────────

class KnowledgeEntity(BaseModel):
    """Represents a knowledge entity in the temporal knowledge substrate.

    Each entity has a single label (the type) and a description property.
    No superlabel. No type property stored in Neo4j. The label IS the type.
    """
    name: str = Field(description="Unique identifier/name for the entity.", min_length=1)
    type: KnowledgeType = Field(description="Category label. Must be one of the 10 allowed KnowledgeType values.")
    domain: str = Field(default="", description="Domain this entity belongs to. If empty, uses the Run's domain.")
    description: str = Field(default="", description="Text description of this entity.")
    confidence: float | None = Field(default=None, description="Optional confidence 0.0-1.0, human-set ONLY.", ge=0.0, le=1.0)
    sources: list[str] | None = Field(default=None, description="Optional provenance list, human-set ONLY.")
    t_created: str | None = Field(default=None, description="ISO datetime when created. Auto-set.")
    t_valid: str | None = Field(default=None, description="ISO datetime of external validity. Optional.")
    score: float | None = Field(default=None, description="Relevance score from fulltext search.")


class Connection(BaseModel):
    """Represents a connection (relationship) between two knowledge entities."""
    source: str = Field(description="Name of the source entity.", min_length=1)
    target: str = Field(description="Name of the target entity.", min_length=1)
    type: ConnectionType = Field(description="Must be one of the 7 allowed ConnectionType values.")
    t_created: str | None = Field(default=None, description="ISO datetime when created. Auto-set.")


class DomainKnowledge(BaseModel):
    """Knowledge graph slice containing entities and their connections."""
    entities: List[KnowledgeEntity] = Field(default=[], description="List of knowledge entities")
    connections: List[Connection] = Field(default=[], description="List of connections between entities")


# ── TemporalKnowledgeSubstrate ───────────────────────────────

class TemporalKnowledgeSubstrate:
    def __init__(self, driver: AsyncDriver):
        self.driver = driver

    async def create_fulltext_index(self):
        """Create fulltext search index spanning all 10 knowledge type labels."""
        try:
            for old_index in ["knowledge_index"]:
                try:
                    await self.driver.execute_query(
                        f"DROP INDEX {old_index} IF EXISTS",
                        routing_control=RoutingControl.WRITE
                    )
                except Exception:
                    pass

            await self.driver.execute_query(
                load_cypher("index_create"),
                routing_control=RoutingControl.WRITE,
            )
            logger.info("Created fulltext index knowledge_index")
        except Exception as e:
            logger.debug(f"Fulltext index creation: {e}")

    # ── Process Tools ────────────────────────────────────────

    async def create_domain(self, name: str, description: str) -> Dict[str, Any]:
        """Create or retrieve a Domain node (idempotent via MERGE)."""
        logger.info(f"create_domain: {name}")
        result = await self.driver.execute_query(
            load_cypher("domain_merge"),
            {"name": name, "description": description},
            routing_control=RoutingControl.WRITE,
        )
        if not result.records:
            raise ValueError(f"Failed to create domain '{name}'")
        r = result.records[0]
        return {
            "name": r["name"],
            "description": r["description"],
            "t_created": _neo4j_datetime_to_str(r["t_created"]),
        }

    async def list_domains(self) -> List[Dict[str, Any]]:
        """List all Domain nodes with run count and last activity."""
        logger.info("list_domains")
        result = await self.driver.execute_query(
            "MATCH (d:Domain) "
            "OPTIONAL MATCH (d)-[:HAS_RUN]->(r:Run) "
            "WITH d, count(r) AS run_count, max(r.timestamp) AS last_activity "
            "RETURN d.name AS name, d.description AS description, "
            "       d.t_created AS t_created, run_count, last_activity "
            "ORDER BY d.name",
            routing_control=RoutingControl.READ,
        )
        return [
            {
                "name": r["name"],
                "description": r["description"],
                "t_created": _neo4j_datetime_to_str(r["t_created"]),
                "run_count": r["run_count"],
                "last_activity": _neo4j_datetime_to_str(r["last_activity"]),
            }
            for r in result.records
        ]

    async def begin_session(
        self, domain: str, purpose: str = "", user: str = "agent"
    ) -> Dict[str, Any]:
        """Begin a new session in a domain. Creates Run + HAS_RUN + NEXT_RUN."""
        logger.info(f"begin_session: domain={domain}, user={user}")

        # Validate domain exists
        domain_check = await self.driver.execute_query(
            "MATCH (d:Domain {name: $domain}) RETURN d.name AS name",
            {"domain": domain},
            routing_control=RoutingControl.READ,
        )
        if not domain_check.records:
            raise ValueError(
                f"Domain '{domain}' not found. Call create_domain first."
            )

        run_id = str(uuid.uuid4())
        result = await self.driver.execute_query(
            load_cypher("run_create"),
            {"run_id": run_id, "domain": domain, "user": user, "purpose": purpose},
            routing_control=RoutingControl.WRITE,
        )

        if not result.records:
            raise ValueError(f"Failed to create run for domain '{domain}'")

        # Get current domain state
        domain_state = await self.get_domain_state(domain)

        return {
            "run_id": run_id,
            "domain": domain,
            "timestamp": _neo4j_datetime_to_str(result.records[0]["timestamp"]),
            "domain_state": domain_state.model_dump(),
        }

    async def end_session(self, run_id: str, summary: str) -> Dict[str, Any]:
        """End a session by setting summary and status on the Run."""
        logger.info(f"end_session: run_id={run_id}")

        result = await self.driver.execute_query(
            "MATCH (r:Run {run_id: $run_id}) "
            "SET r.summary = $summary, r.status = 'complete' "
            "WITH r "
            "OPTIONAL MATCH (r)-[:DISCOVERED]->(e) "
            "WITH r, count(e) AS entities_discovered "
            "RETURN r.run_id AS run_id, r.domain AS domain, "
            "       r.timestamp AS timestamp, r.purpose AS purpose, "
            "       r.summary AS summary, r.status AS status, "
            "       entities_discovered",
            {"run_id": run_id, "summary": summary},
            routing_control=RoutingControl.WRITE,
        )

        if not result.records:
            raise ValueError(f"Run '{run_id}' not found.")

        r = result.records[0]
        return {
            "run_id": r["run_id"],
            "domain": r["domain"],
            "timestamp": _neo4j_datetime_to_str(r["timestamp"]),
            "purpose": r["purpose"],
            "summary": r["summary"],
            "status": r["status"],
            "entities_discovered": r["entities_discovered"],
        }

    # ── Knowledge Tools ──────────────────────────────────────

    async def create_knowledge(
        self, run_id: str, entities: List[KnowledgeEntity]
    ) -> List[KnowledgeEntity]:
        """Create knowledge entities. HARD REJECTS process types (Domain, Run)."""
        logger.info(f"Creating {len(entities)} knowledge entities")

        # Resolve domain from Run if any entity has empty domain
        run_domain = None
        for entity in entities:
            if not entity.domain:
                if run_domain is None:
                    domain_result = await self.driver.execute_query(
                        "MATCH (r:Run {run_id: $run_id}) RETURN r.domain AS domain",
                        {"run_id": run_id},
                        routing_control=RoutingControl.READ,
                    )
                    if not domain_result.records:
                        raise ValueError(f"Run '{run_id}' not found.")
                    run_domain = domain_result.records[0]["domain"]
                entity.domain = run_domain

        for entity in entities:
            # Guard: reject process types
            if entity.type.value in PROCESS_TYPES:
                raise ValueError(
                    f"Cannot create '{entity.type.value}' via create_knowledge. "
                    f"Process-layer types must be created via process tools: "
                    f"create_domain (Domain), begin_session (Run)."
                )

            confidence_clause = (
                f"SET e.confidence = $confidence" if entity.confidence is not None else ""
            )
            sources_clause = (
                f"SET e.sources = $sources" if entity.sources is not None else ""
            )
            t_valid_clause = (
                f"SET e.t_valid = datetime($t_valid)" if entity.t_valid else ""
            )

            query = load_cypher(
                "knowledge_create",
                label=entity.type.value,
                confidence_clause=confidence_clause,
                sources_clause=sources_clause,
                t_valid_clause=t_valid_clause,
            )

            params: Dict[str, Any] = {
                "name": entity.name,
                "domain": entity.domain,
                "description": entity.description,
                "run_id": run_id,
            }
            if entity.confidence is not None:
                params["confidence"] = entity.confidence
            if entity.sources is not None:
                params["sources"] = entity.sources
            if entity.t_valid:
                params["t_valid"] = entity.t_valid

            await self.driver.execute_query(query, params, routing_control=RoutingControl.WRITE)

        return entities

    async def evolve_knowledge(
        self, run_id: str, name: str, description: str, domain: str = ""
    ) -> Dict[str, Any]:
        """Evolve a knowledge entity — find head of chain, create new version."""
        logger.info(f"evolve_knowledge: {name}")

        # Resolve domain from Run if not provided
        if not domain:
            domain_result = await self.driver.execute_query(
                "MATCH (r:Run {run_id: $run_id}) RETURN r.domain AS domain",
                {"run_id": run_id},
                routing_control=RoutingControl.READ,
            )
            if not domain_result.records:
                raise ValueError(f"Run '{run_id}' not found.")
            domain = domain_result.records[0]["domain"]

        # Find head of chain and its label
        head_result = await self.driver.execute_query(
            "MATCH (e {name: $name, domain: $domain}) "
            "WHERE NOT (e)<-[:EVOLVED_FROM]-() "
            "AND NOT e:Domain AND NOT e:Run "
            "RETURN labels(e)[0] AS label",
            {"name": name, "domain": domain},
            routing_control=RoutingControl.READ,
        )

        if not head_result.records:
            raise ValueError(
                f"Knowledge entity '{name}' not found in domain '{domain}', "
                f"or it has already been evolved (not head of chain)."
            )

        label = head_result.records[0]["label"]

        result = await self.driver.execute_query(
            load_cypher("knowledge_evolve", label=label),
            {"name": name, "domain": domain, "new_description": description, "run_id": run_id},
            routing_control=RoutingControl.WRITE,
        )

        if not result.records:
            raise ValueError(f"Failed to evolve knowledge entity '{name}'.")

        return {
            "name": result.records[0]["name"],
            "label": label,
            "domain": domain,
            "new_description": description,
            "evolved": True,
        }

    async def create_connections(self, connections: List[Connection]) -> List[Connection]:
        """Create knowledge connections. HARD REJECTS process edges and connections between two process-type nodes."""
        logger.info(f"Creating {len(connections)} connections")

        for connection in connections:
            # Guard: reject process edge types
            if connection.type.value in PROCESS_EDGES:
                raise ValueError(
                    f"Cannot create '{connection.type.value}' via create_connections. "
                    f"Process edges are created exclusively by process tools."
                )

            # Guard: reject knowledge edges between two process-type nodes
            label_check = await self.driver.execute_query(
                load_cypher("connection_label_check"),
                {"source": connection.source, "target": connection.target},
                routing_control=RoutingControl.READ,
            )

            if label_check.records:
                source_labels = set(label_check.records[0]["source_labels"])
                target_labels = set(label_check.records[0]["target_labels"])

                if source_labels & PROCESS_TYPES and target_labels & PROCESS_TYPES:
                    raise ValueError(
                        f"Knowledge edges are forbidden between two process-type nodes. "
                        f"Source '{connection.source}' and target '{connection.target}' are both process types."
                    )

            query = load_cypher("connection_create", rel_type=connection.type.value)
            await self.driver.execute_query(
                query,
                {"source": connection.source, "target": connection.target},
                routing_control=RoutingControl.WRITE,
            )

        return connections

    # ── Query Tools ──────────────────────────────────────────

    async def search_knowledge(
        self, query: str, domain: str | None = None, limit: int = 10
    ) -> DomainKnowledge:
        """Search the knowledge substrate using fulltext search."""
        logger.info(f"Searching with query: '{query}' (domain={domain}, limit={limit})")

        result_entities = await self.driver.execute_query(
            load_cypher("search_knowledge"),
            {"query": query, "domain": domain, "limit": limit},
            routing_control=RoutingControl.READ,
        )

        if not result_entities.records:
            return DomainKnowledge()

        entity_names = [r["name"] for r in result_entities.records]
        entities = [
            KnowledgeEntity(
                name=r["name"],
                type=r["type"],
                domain=r["domain"] or "",
                description=r["description"] or "",
                score=r["score"],
                t_created=_neo4j_datetime_to_str(r["t_created"]),
            )
            for r in result_entities.records
        ]

        connections = await self._connections_between(entity_names)
        return DomainKnowledge(entities=entities, connections=connections)

    async def get_domain_state(self, domain: str) -> DomainKnowledge:
        """Get all current (head-of-chain) knowledge entities for a domain."""
        logger.info(f"get_domain_state: {domain}")

        result = await self.driver.execute_query(
            load_cypher("domain_state"),
            {"domain": domain},
            routing_control=RoutingControl.READ,
        )

        entities = []
        connections = []
        seen_connections = set()

        for r in result.records:
            entities.append(KnowledgeEntity(
                name=r["name"],
                type=r["type"],
                domain=domain,
                description=r["description"] or "",
                t_created=_neo4j_datetime_to_str(r["t_created"]),
            ))

            for conn in r["connections"]:
                if conn["target"] is not None:
                    conn_key = (r["name"], conn["target"], conn["type"])
                    if conn_key not in seen_connections:
                        seen_connections.add(conn_key)
                        try:
                            connections.append(Connection(
                                source=r["name"],
                                target=conn["target"],
                                type=conn["type"],
                            ))
                        except ValueError:
                            # Skip connections with unknown types (e.g., EVOLVED_FROM handled separately)
                            pass

        return DomainKnowledge(entities=entities, connections=connections)

    async def get_run_history(self, domain: str, limit: int = 20) -> List[Dict[str, Any]]:
        """Get the Run chain for a domain."""
        logger.info(f"get_run_history: domain={domain}, limit={limit}")

        result = await self.driver.execute_query(
            load_cypher("run_history"),
            {"domain": domain, "limit": limit},
            routing_control=RoutingControl.READ,
        )

        return [
            {
                "run_id": r["run_id"],
                "user": r["user"],
                "timestamp": _neo4j_datetime_to_str(r["timestamp"]),
                "purpose": r["purpose"],
                "summary": r["summary"],
                "status": r["status"],
                "entities_discovered": r["entities_discovered"],
            }
            for r in result.records
        ]

    async def _connections_between(self, names: List[str]) -> List[Connection]:
        """Get connections ONLY between the named entities (bounded traversal)."""
        if not names:
            return []

        result = await self.driver.execute_query(
            load_cypher("search_connections"),
            {"names": names},
            routing_control=RoutingControl.READ,
        )
        connections = []
        for r in result.records:
            if r.get("connectionType"):
                try:
                    connections.append(Connection(
                        source=r["source"],
                        target=r["target"],
                        type=r["connectionType"],
                    ))
                except ValueError:
                    # Skip connections with types not in ConnectionType enum
                    pass
        return connections
