import json
import logging
from contextlib import asynccontextmanager
from typing import Any, Literal

from neo4j import AsyncGraphDatabase, Query, RoutingControl
from pydantic import Field
from starlette.middleware import Middleware
from starlette.middleware.cors import CORSMiddleware
from starlette.middleware.trustedhost import TrustedHostMiddleware

from fastmcp.server import FastMCP
from fastmcp.exceptions import ToolError
from fastmcp.tools.tool import ToolResult
from mcp.types import TextContent
from neo4j.exceptions import Neo4jError, ClientError
from mcp.types import ToolAnnotations

# Monkey patch FastMCP to support full HTTP method suite outside of auth required path
from fastmcp.server import http as fastmcp_http
from starlette.routing import Route

from .substrate import (
    TemporalKnowledgeSubstrate, KnowledgeEntity, KnowledgeType,
    KNOWLEDGE_TYPE_DESCRIPTIONS, PROCESS_TYPES,
    Connection, ConnectionType, CONNECTION_TYPE_DESCRIPTIONS,
    PROCESS_EDGES, DomainKnowledge,
)
from .utils import format_namespace, _is_write_query, _value_sanitize

logger = logging.getLogger('mcp_temporal_knowledge')
logger.setLevel(logging.INFO)


# ── FastMCP Monkey Patch (bug in 2.13.0.2) ───────────────────

_original_create_streamable_http_app = fastmcp_http.create_streamable_http_app


def patched_create_streamable_http_app(*args, **kwargs):
    app = _original_create_streamable_http_app(*args, **kwargs)
    streamable_http_path = kwargs.get('streamable_http_path', '/mcp')
    for i, route in enumerate(app.routes):
        if isinstance(route, Route) and route.path == streamable_http_path:
            if not route.methods or route.methods == ['GET']:
                app.routes[i] = Route(
                    route.path, endpoint=route.endpoint,
                    methods=["GET", "POST", "DELETE"],
                )
                logger.info(f"Patched route {route.path} to accept GET, POST, DELETE")
                break
    return app


fastmcp_http.create_streamable_http_app = patched_create_streamable_http_app


# ── Tool Helpers ─────────────────────────────────────────────

@asynccontextmanager
async def _tool_errors(operation: str):
    """Standard error handling for all MCP tools."""
    logger.info(f"MCP tool: {operation}")
    try:
        yield
    except ValueError as e:
        raise ToolError(str(e))
    except Neo4jError as e:
        logger.error(f"Neo4j error in {operation}: {e}")
        raise ToolError(f"Neo4j error in {operation}: {e}")
    except Exception as e:
        logger.error(f"Error in {operation}: {e}")
        raise ToolError(f"Error in {operation}: {e}")


def _json_result(data, structured=None) -> ToolResult:
    """Wrap JSON-serializable data in a ToolResult."""
    text = json.dumps(data, indent=2, default=str)
    return ToolResult(
        content=[TextContent(type="text", text=text)],
        structured_content=structured if structured is not None else {"result": json.loads(text)},
    )


def _text_result(text: str, structured=None) -> ToolResult:
    """Wrap a text string in a ToolResult."""
    return ToolResult(
        content=[TextContent(type="text", text=text)],
        structured_content=structured if structured is not None else {"result": text},
    )


# ── Server Factory ───────────────────────────────────────────

def create_mcp_server(
    substrate: TemporalKnowledgeSubstrate,
    namespace: str = "",
    read_timeout: int = 30,
) -> FastMCP:
    """Create an MCP server instance for the temporal knowledge substrate."""

    namespace_prefix = format_namespace(namespace)
    mcp: FastMCP = FastMCP("mcp-temporal-knowledge")

    # ── Process Tools ────────────────────────────────────────

    @mcp.tool(
        name=namespace_prefix + "list_domains",
        annotations=ToolAnnotations(title="List Domains", readOnlyHint=True,
                                    destructiveHint=False, idempotentHint=True, openWorldHint=True))
    async def list_domains() -> ToolResult:
        """List all knowledge domains with run count and last activity.

        No parameters required.
        """
        async with _tool_errors("list_domains"):
            result = await substrate.list_domains()
            return _json_result(result)

    @mcp.tool(
        name=namespace_prefix + "create_domain",
        annotations=ToolAnnotations(title="Create Domain", readOnlyHint=False,
                                    destructiveHint=False, idempotentHint=True, openWorldHint=True))
    async def create_domain(
        name: str = Field(..., description="Domain name (e.g. 'Five9', 'M365', 'Techlane')"),
        description: str = Field(..., description="What this knowledge area covers"),
    ) -> ToolResult:
        """Create or retrieve a knowledge domain (idempotent via MERGE).

        This is the entry point for a new knowledge area.
        The Domain IS the permanent envisioning — the pursuit of understanding.

        Example: {"name": "Five9", "description": "Five9 VCC contact center operations"}
        """
        async with _tool_errors("create_domain"):
            result = await substrate.create_domain(name=name, description=description)
            return _json_result(result)

    @mcp.tool(
        name=namespace_prefix + "begin_session",
        annotations=ToolAnnotations(title="Begin Session", readOnlyHint=False,
                                    destructiveHint=False, idempotentHint=False, openWorldHint=True))
    async def begin_session(
        domain: str = Field(..., description="Domain name to begin session in"),
        purpose: str = Field(default="", description="What this session is directed toward (optional)"),
        user: str = Field(default="agent", description="Who initiated this session (default: 'agent')"),
    ) -> ToolResult:
        """Begin a new knowledge session in a domain.

        Creates a Run node, links HAS_RUN from Domain and NEXT_RUN from the previous Run.
        Returns the run_id (needed for all subsequent knowledge tools) plus the current domain state.

        This is the FIRST tool every session calls after create_domain.

        Example: {"domain": "Five9", "purpose": "Campaign routing logic and peak-hour gotchas"}
        """
        async with _tool_errors("begin_session"):
            result = await substrate.begin_session(domain=domain, purpose=purpose, user=user)
            return _json_result(result)

    @mcp.tool(
        name=namespace_prefix + "end_session",
        annotations=ToolAnnotations(title="End Session", readOnlyHint=False,
                                    destructiveHint=False, idempotentHint=False, openWorldHint=True))
    async def end_session(
        run_id: str = Field(..., description="Run ID returned by begin_session"),
        summary: str = Field(..., description="Session narrative — what was actually learned/done"),
    ) -> ToolResult:
        """End a knowledge session by recording what was measured into the graph.

        Sets the Run's summary and status to 'complete'. If never called, the Run
        stays active — an honest record of an incomplete session.

        Example: {"run_id": "abc-123", "summary": "Documented campaign routing logic and discovered peak-hour allocation gotcha"}
        """
        async with _tool_errors("end_session"):
            result = await substrate.end_session(run_id=run_id, summary=summary)
            return _json_result(result)

    # ── Knowledge Tools ──────────────────────────────────────

    @mcp.tool(
        name=namespace_prefix + "create_knowledge",
        annotations=ToolAnnotations(title="Create Knowledge", readOnlyHint=False,
                                    destructiveHint=False, idempotentHint=True, openWorldHint=True))
    async def create_knowledge(
        run_id: str = Field(..., description="Run ID from begin_session"),
        entities: list[KnowledgeEntity] = Field(..., description="List of knowledge entities to create"),
    ) -> ToolResult:
        """Create knowledge entities and link them to the current session via DISCOVERED edges.

        HARD REJECTS process types (Domain, Run). Use create_domain / begin_session instead.
        Deduplicates by name within domain (MERGE). If domain is omitted on an entity,
        the Run's domain is used.

        IMPORTANT: `confidence` and `sources` are optional, human-supplied ONLY.
        Do not generate these autonomously.

        Example:
        {
            "run_id": "abc-123",
            "entities": [
                {"name": "Five9 VCC", "type": "System", "description": "Cloud contact center platform"},
                {"name": "Peak Hour Agent Allocation", "type": "Gotcha", "description": "Breaks above 200 concurrent agents"}
            ]
        }
        """
        async with _tool_errors("create_knowledge"):
            entity_objects = [KnowledgeEntity.model_validate(entity) for entity in entities]
            result = await substrate.create_knowledge(run_id, entity_objects)
            return _json_result([e.model_dump() for e in result])

    @mcp.tool(
        name=namespace_prefix + "evolve_knowledge",
        annotations=ToolAnnotations(title="Evolve Knowledge", readOnlyHint=False,
                                    destructiveHint=False, idempotentHint=False, openWorldHint=True))
    async def evolve_knowledge(
        run_id: str = Field(..., description="Run ID from begin_session"),
        name: str = Field(..., description="Name of the entity to evolve (must be head of chain)"),
        description: str = Field(..., description="New description for the evolved entity"),
        domain: str = Field(default="", description="Domain (uses Run's domain if omitted)"),
    ) -> ToolResult:
        """Evolve a knowledge entity — create a new version linked via EVOLVED_FROM.

        Finds the head of the entity's evolution chain, creates a new version with the same
        name and type, links EVOLVED_FROM (new → old), and links DISCOVERED from the current Run.
        Old version is preserved — append-only, never overwrite.

        Example: {"run_id": "abc-123", "name": "Campaign Routing", "description": "Updated: now includes skill-based routing logic"}
        """
        async with _tool_errors("evolve_knowledge"):
            result = await substrate.evolve_knowledge(
                run_id=run_id, name=name, description=description, domain=domain,
            )
            return _json_result(result)

    @mcp.tool(
        name=namespace_prefix + "create_connections",
        annotations=ToolAnnotations(title="Create Connections", readOnlyHint=False,
                                    destructiveHint=False, idempotentHint=True, openWorldHint=True))
    async def create_connections(
        connections: list[Connection] = Field(..., description="List of connections to create"),
    ) -> ToolResult:
        """Create typed connections between knowledge entities.

        HARD REJECTS process edge types (HAS_RUN, NEXT_RUN, DISCOVERED).
        HARD REJECTS knowledge edges between two process-type nodes.
        Cross-domain connections ARE allowed.

        Example:
        {
            "connections": [
                {"source": "Campaign Routing", "target": "Skill Mapping", "type": "REQUIRING"},
                {"source": "Five9 VCC", "target": "Techlane API", "type": "RELATES_TO"}
            ]
        }
        """
        async with _tool_errors("create_connections"):
            connection_objects = [Connection.model_validate(c) for c in connections]
            result = await substrate.create_connections(connection_objects)
            return _json_result([c.model_dump() for c in result])

    # ── Query Tools ──────────────────────────────────────────

    @mcp.tool(
        name=namespace_prefix + "search_knowledge",
        annotations=ToolAnnotations(title="Search Knowledge", readOnlyHint=True,
                                    destructiveHint=False, idempotentHint=True, openWorldHint=True))
    async def search_knowledge(
        query: str = Field(..., description="Fulltext search query"),
        domain: str | None = Field(default=None, description="Optional domain scope (searches all if omitted)"),
        limit: int = Field(default=10, description="Max results (default 10, max 50)", ge=1, le=50),
    ) -> ToolResult:
        """Search knowledge entities using fulltext search across names and descriptions.

        Returns head-of-chain entities (current versions) and connections between them.
        Optional domain scoping.

        Example: {"query": "campaign routing", "domain": "Five9", "limit": 20}
        """
        async with _tool_errors("search_knowledge"):
            result = await substrate.search_knowledge(query=query, domain=domain, limit=limit)
            return _text_result(result.model_dump_json(), structured=result)

    @mcp.tool(
        name=namespace_prefix + "get_domain_state",
        annotations=ToolAnnotations(title="Get Domain State", readOnlyHint=True,
                                    destructiveHint=False, idempotentHint=True, openWorldHint=True))
    async def get_domain_state(
        domain: str = Field(..., description="Domain name"),
    ) -> ToolResult:
        """Get all current (head-of-chain) knowledge entities for a domain.

        Returns "what do we know about this domain right now?" — entities and connections.

        Example: {"domain": "Five9"}
        """
        async with _tool_errors("get_domain_state"):
            result = await substrate.get_domain_state(domain=domain)
            return _text_result(result.model_dump_json(), structured=result)

    @mcp.tool(
        name=namespace_prefix + "get_run_history",
        annotations=ToolAnnotations(title="Get Run History", readOnlyHint=True,
                                    destructiveHint=False, idempotentHint=True, openWorldHint=True))
    async def get_run_history(
        domain: str = Field(..., description="Domain name"),
        limit: int = Field(default=20, description="Max runs to return (default 20)", ge=1),
    ) -> ToolResult:
        """Get the session history for a domain — who worked on what, when, and what they found.

        Ordered by timestamp (oldest → newest).

        Example: {"domain": "Five9", "limit": 10}
        """
        async with _tool_errors("get_run_history"):
            result = await substrate.get_run_history(domain=domain, limit=limit)
            return _json_result(result)

    @mcp.tool(
        name=namespace_prefix + "read_cypher",
        annotations=ToolAnnotations(title="Read Cypher", readOnlyHint=True,
                                    destructiveHint=False, idempotentHint=True, openWorldHint=True))
    async def read_cypher(
        query: str = Field(..., description="The Cypher query to execute."),
        params: dict[str, Any] = Field(default_factory=dict, description="Parameters for the query."),
    ) -> ToolResult:
        """Execute a read-only Cypher query. Write queries are rejected."""
        if _is_write_query(query):
            raise ToolError(
                "Write queries are not allowed via read_cypher. "
                "Use the bounded mutation tools instead."
            )
        async with _tool_errors("read_cypher"):
            result = await substrate.driver.execute_query(
                Query(query, timeout=read_timeout),
                parameters_=params,
                routing_=RoutingControl.READ,
            )
            records = [r for r in (_value_sanitize(dict(r)) for r in result.records) if r is not None]
            text = json.dumps(records, indent=2, default=str)
            if len(text) > 200_000:
                text = text[:200_000] + "\n... (truncated — add LIMIT to your query)"
            return _text_result(text, structured={"result": records})

    # ── Taxonomy Tools ───────────────────────────────────────

    @mcp.tool(
        name=namespace_prefix + "list_knowledge_types",
        annotations=ToolAnnotations(title="List Knowledge Types", readOnlyHint=True,
                                    destructiveHint=False, idempotentHint=True, openWorldHint=False))
    async def list_knowledge_types() -> ToolResult:
        """List all 10 allowed knowledge entity types with descriptions.

        These are the types you can use with create_knowledge.
        Process types (Domain, Run) are created by process tools only.
        """
        async with _tool_errors("list_knowledge_types"):
            types = {}
            for kt in KnowledgeType:
                types[kt.value] = KNOWLEDGE_TYPE_DESCRIPTIONS[kt]

            return _json_result({
                "total_types": len(KnowledgeType),
                "process_types": {
                    "description": "Created exclusively by process tools (create_domain, begin_session).",
                    "types": {"Domain": "Permanent knowledge domain anchor", "Run": "One session of knowledge work"},
                },
                "knowledge_types": {
                    "description": "Created via create_knowledge.",
                    "types": types,
                },
            })

    @mcp.tool(
        name=namespace_prefix + "list_connection_types",
        annotations=ToolAnnotations(title="List Connection Types", readOnlyHint=True,
                                    destructiveHint=False, idempotentHint=True, openWorldHint=False))
    async def list_connection_types() -> ToolResult:
        """List all allowed connection types — 7 knowledge + 3 process edge types.

        Knowledge edges are created via create_connections.
        Process edges are created exclusively by process tools.
        """
        async with _tool_errors("list_connection_types"):
            knowledge_types = {}
            for ct in ConnectionType:
                knowledge_types[ct.value] = CONNECTION_TYPE_DESCRIPTIONS[ct]

            process_types = {
                "HAS_RUN": "Domain owns its Runs (created by begin_session)",
                "NEXT_RUN": "Run → Run, forward in time (created by begin_session)",
                "DISCOVERED": "Run → KnowledgeEntity (created by create_knowledge / evolve_knowledge)",
            }

            return _json_result({
                "total_types": len(ConnectionType) + len(process_types),
                "layers": {
                    "process": {
                        "description": "Created exclusively by process tools.",
                        "types": process_types,
                    },
                    "knowledge": {
                        "description": "Created via create_connections.",
                        "types": knowledge_types,
                    },
                },
            })

    # ── GDS Analytics Tools ──────────────────────────────────

    @mcp.tool(
        name=namespace_prefix + "gds_create_projection",
        annotations=ToolAnnotations(title="GDS Create Projection", readOnlyHint=False,
                                    destructiveHint=False, idempotentHint=False, openWorldHint=False))
    async def gds_create_projection(
        name: str = Field(..., description="Name for the graph projection"),
        rel_types: list[str] = Field(default=None, description="Relationship types to include (defaults to all)"),
        undirected: bool = Field(default=True, description="Treat relationships as undirected (default true)"),
        memory_gb: str = Field(default="2GB", description="Memory allocation for the projection."),
    ) -> ToolResult:
        """Create a GDS graph projection for analytics. Label-agnostic MATCH.

        SCALING CONSTRAINT: Cypher projections traverse every matched relationship.
        For large graphs, scope carefully with rel_types filters.
        """
        async with _tool_errors("gds_create_projection"):
            if rel_types:
                rel_filter = "|".join(f"`{rt}`" for rt in rel_types)
                match_clause = f"MATCH (source)-[r:{rel_filter}]->(target)"
            else:
                match_clause = "MATCH (source)-[r]->(target)"

            config_parts = [f"memory: '{memory_gb}'"]
            if undirected:
                config_parts.append("undirectedRelationshipTypes: ['*']")

            query = f"""
                {match_clause}
                RETURN gds.graph.project($name, source, target, {{}}, {{{", ".join(config_parts)}}})
            """
            result = await substrate.driver.execute_query(query, name=name, routing_=RoutingControl.READ)
            records = [r for r in (_value_sanitize(dict(r)) for r in result.records) if r is not None]
            return _json_result(records)

    @mcp.tool(
        name=namespace_prefix + "gds_drop_projection",
        annotations=ToolAnnotations(title="GDS Drop Projection", readOnlyHint=False,
                                    destructiveHint=True, idempotentHint=True, openWorldHint=False))
    async def gds_drop_projection(
        name: str = Field(..., description="Name of the graph projection to drop"),
    ) -> ToolResult:
        """Drop a GDS graph projection to free memory."""
        async with _tool_errors("gds_drop_projection"):
            result = await substrate.driver.execute_query(
                "CALL gds.graph.drop($name)", name=name, routing_=RoutingControl.WRITE)
            return _json_result([dict(r) for r in result.records])

    @mcp.tool(
        name=namespace_prefix + "gds_pagerank",
        annotations=ToolAnnotations(title="GDS PageRank", readOnlyHint=True,
                                    destructiveHint=False, idempotentHint=True, openWorldHint=False))
    async def gds_pagerank(
        projection: str = Field(..., description="Name of the graph projection"),
        result_limit: int = Field(default=20, ge=1, le=1000, description="Max results (default 20)"),
    ) -> ToolResult:
        """Run PageRank on a GDS graph projection. Requires gds_create_projection first."""
        async with _tool_errors("gds_pagerank"):
            result = await substrate.driver.execute_query(
                "CALL gds.pageRank.stream($projection) YIELD nodeId, score "
                "RETURN gds.util.asNode(nodeId).name AS node, "
                "labels(gds.util.asNode(nodeId))[0] AS type, score "
                "ORDER BY score DESC LIMIT $result_limit",
                projection=projection, result_limit=result_limit, routing_=RoutingControl.READ,
            )
            return _json_result([dict(r) for r in result.records])

    @mcp.tool(
        name=namespace_prefix + "gds_betweenness",
        annotations=ToolAnnotations(title="GDS Betweenness Centrality", readOnlyHint=True,
                                    destructiveHint=False, idempotentHint=True, openWorldHint=False))
    async def gds_betweenness(
        projection: str = Field(..., description="Name of the graph projection"),
        result_limit: int = Field(default=20, ge=1, le=1000, description="Max results (default 20)"),
    ) -> ToolResult:
        """Run Betweenness Centrality on a GDS graph projection.

        Identifies bridge nodes — entities that sit on the shortest paths between other nodes.
        """
        async with _tool_errors("gds_betweenness"):
            result = await substrate.driver.execute_query(
                "CALL gds.betweenness.stream($projection) YIELD nodeId, score "
                "RETURN gds.util.asNode(nodeId).name AS node, "
                "labels(gds.util.asNode(nodeId))[0] AS type, score "
                "ORDER BY score DESC LIMIT $result_limit",
                projection=projection, result_limit=result_limit, routing_=RoutingControl.READ,
            )
            return _json_result([dict(r) for r in result.records])

    @mcp.tool(
        name=namespace_prefix + "gds_louvain",
        annotations=ToolAnnotations(title="GDS Louvain", readOnlyHint=True,
                                    destructiveHint=False, idempotentHint=True, openWorldHint=False))
    async def gds_louvain(
        projection: str = Field(..., description="Name of the graph projection"),
        result_limit: int = Field(default=20, ge=1, le=1000, description="Max results (default 20)"),
    ) -> ToolResult:
        """Run Louvain community detection on a GDS graph projection."""
        async with _tool_errors("gds_louvain"):
            result = await substrate.driver.execute_query(
                "CALL gds.louvain.stream($projection) YIELD nodeId, communityId "
                "RETURN gds.util.asNode(nodeId).name AS node, "
                "labels(gds.util.asNode(nodeId))[0] AS type, communityId "
                "ORDER BY communityId, node LIMIT $result_limit",
                projection=projection, result_limit=result_limit, routing_=RoutingControl.READ,
            )
            return _json_result([dict(r) for r in result.records])

    @mcp.tool(
        name=namespace_prefix + "gds_wcc",
        annotations=ToolAnnotations(title="GDS Weakly Connected Components", readOnlyHint=True,
                                    destructiveHint=False, idempotentHint=True, openWorldHint=False))
    async def gds_wcc(
        projection: str = Field(..., description="Name of the graph projection"),
        result_limit: int = Field(default=20, ge=1, le=1000, description="Max results (default 20)"),
    ) -> ToolResult:
        """Run Weakly Connected Components on a GDS graph projection."""
        async with _tool_errors("gds_wcc"):
            result = await substrate.driver.execute_query(
                "CALL gds.wcc.stream($projection) YIELD nodeId, componentId "
                "RETURN gds.util.asNode(nodeId).name AS node, "
                "labels(gds.util.asNode(nodeId))[0] AS type, componentId "
                "ORDER BY componentId, node LIMIT $result_limit",
                projection=projection, result_limit=result_limit, routing_=RoutingControl.READ,
            )
            return _json_result([dict(r) for r in result.records])

    return mcp


# ── Server Entry Point ───────────────────────────────────────

async def main(
    neo4j_uri: str,
    neo4j_user: str,
    neo4j_password: str,
    neo4j_database: str,
    transport: Literal["stdio", "sse", "streamable-http"] = "stdio",
    namespace: str = "",
    host: str = "127.0.0.1",
    port: int = 8000,
    path: str = "/mcp/",
    allow_origins: list[str] = [],
    allowed_hosts: list[str] = [],
    read_timeout: int = 30,
) -> None:
    logger.info(f"Starting Temporal Knowledge Substrate MCP Server")
    logger.info(f"Connecting to Neo4j with DB URL: {neo4j_uri}")

    neo4j_driver = AsyncGraphDatabase.driver(
        neo4j_uri, auth=(neo4j_user, neo4j_password), database=neo4j_database)

    try:
        await neo4j_driver.verify_connectivity()
        logger.info(f"Connected to Neo4j at {neo4j_uri}")
    except Exception as e:
        logger.error(f"Failed to connect to Neo4j: {e}")
        exit(1)

    substrate = TemporalKnowledgeSubstrate(neo4j_driver)
    await substrate.create_fulltext_index()

    custom_middleware = [
        Middleware(CORSMiddleware, allow_origins=allow_origins,
                   allow_methods=["GET", "POST"], allow_headers=["*"]),
        Middleware(TrustedHostMiddleware, allowed_hosts=allowed_hosts),
    ]

    mcp = create_mcp_server(substrate, namespace, read_timeout=read_timeout)

    match transport:
        case "streamable-http":
            await mcp.run_http_async(host=host, port=port, path=path, middleware=custom_middleware,
                                     transport="streamable-http", stateless_http=True)
        case "stdio":
            await mcp.run_stdio_async()
        case "sse":
            await mcp.run_http_async(host=host, port=port, path=path, middleware=custom_middleware, transport="sse")
        case _:
            raise ValueError(f"Unsupported transport: {transport}")
