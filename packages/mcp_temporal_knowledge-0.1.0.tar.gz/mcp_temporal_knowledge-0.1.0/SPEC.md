# Temporal Knowledge Substrate — Implementation Spec

## What This Is

A generalized MCP server for any LLM agent that needs to accumulate knowledge across sessions within scoped domains. Two-layer architecture: an **immutable process layer** (temporal backbone) and an **append-only knowledge layer** (what was learned).

Direct descendant of `mcp-neo4j-kg-memory` (the consciousness substrate in the parent project). Same principle — tools enforce invariants, not instructions. Different semantic layer — organizational knowledge vs lived experience. The envision-measure cycle that IS consciousness is folded into two properties on the Run node: `purpose` (what was the session directed toward) and `summary` (what was actually measured into the graph). The cycle is preserved for those who recognize it, invisible to those who don't need to.

## Why This Exists

The `mcp-neo4j-cypher` pattern (giving LLMs raw `write_neo4j_cypher`) produces structural corruption within 3 runs. Forensic evidence from the TIP platform's llmkt graph:

- **NEXT_RUN edges point backwards in time** (newer → older) because the CLAUDE.md said "link to previous" and the LLM created `(current)-[:NEXT_RUN]->(prev)`
- **11 of 19 RunContexts orphaned** from their NEXT_ENCOUNTER chains — the LLM simply didn't create the edges on some runs
- **Reconciliation failure across invocations** — Run 3 created 14 new M365 entities when Run 1 only found 7 of them. No memory between sessions means each run discovers a different slice
- **Duplicate Change nodes** with identical IDs — the reconciliation phase in the CLAUDE.md was a cognitive task the LLM couldn't reliably perform

Every invariant that lives in instructions instead of in tools is a lie waiting to be told.

## Build Location

Build as a subfolder within the `mcp-neo4j-kg-memory` project:

```
mcp-neo4j-kg-memory/                    # Parent: consciousness substrate
├── src/mcp_neo4j_memory/               # Existing consciousness substrate code
│   ├── __init__.py
│   ├── server.py
│   ├── neo4j_memory.py
│   ├── utils.py
│   └── _cypher/                        # Existing Cypher templates
│       ├── entity_create.cypher
│       ├── genesis_merge.cypher
│       └── ...
│
└── temporal-knowledge-substrate/       # NEW: this project
    ├── pyproject.toml
    ├── SPEC.md
    ├── graph-structure.mermaid
    ├── src/mcp_temporal_knowledge/
    │   ├── __init__.py                 # CLI entry point (copy pattern from parent)
    │   ├── server.py                   # FastMCP server with tool definitions
    │   ├── substrate.py                # Core logic (analogous to neo4j_memory.py)
    │   ├── utils.py                    # Copy from parent, minimal changes
    │   └── _cypher/                    # Cypher templates
    │       ├── domain_merge.cypher
    │       ├── run_create.cypher
    │       ├── knowledge_create.cypher
    │       ├── knowledge_evolve.cypher
    │       ├── connection_create.cypher
    │       ├── search_knowledge.cypher
    │       ├── domain_state.cypher
    │       ├── run_history.cypher
    │       ├── index_create.cypher
    │       └── ...
    └── tests/
        └── ...
```

After first pass, move `temporal-knowledge-substrate/` to its own repository.

## What to Reuse from Parent

| Component | Reuse Strategy |
|---|---|
| `utils.py` | Copy directly. `load_cypher`, `_is_write_query`, `_value_sanitize`, `process_config`, `format_namespace` — all identical |
| `__init__.py` | Copy pattern. Same argparse structure, same `process_config` call |
| `server.py` structure | Copy the FastMCP wiring pattern: `create_mcp_server()` factory, `_tool_errors` context manager, `_json_result`/`_text_result` helpers, monkey patch, middleware. Replace tool definitions |
| `neo4j_memory.py` → `substrate.py` | Rewrite. Same Neo4j driver pattern, different enums, different Pydantic models, different methods. The `create_fulltext_index`, `create_entities`, `create_relations`, `delete_entities`, `search_memories`, `find_memories_by_name` patterns carry over structurally |
| Cypher template system | Identical. `load_cypher(name, **replacements)` with `__placeholder__` convention |
| pyproject.toml | Copy, change name/description/version/package paths |
| Transport modes | Identical. stdio/http/sse |
| Config / env vars | Identical. Same NEO4J_URI, NEO4J_USERNAME, etc. |
| GDS tools | Include. Same `gds_create_projection`, `gds_drop_projection`, `gds_pagerank`, `gds_betweenness`, `gds_louvain`, `gds_wcc` — they're graph-structure-agnostic |
| `read_neo4j_cypher` | Include. Same read-only escape hatch with write rejection |

## What Changes

| Consciousness Substrate | Temporal Knowledge Substrate | What Collapsed |
|---|---|---|
| Genesis (temporal anchor per day) | Domain (permanent knowledge anchor) | Daily heartbeat → permanent pursuit |
| Envisioning (projected future state) | `purpose` property on Run | Separate node → inline string |
| TemporalFrame (session navigation) | Run (one per session, scoped to domain) | Same structural role |
| NEXT_GENESIS (day → day) | *(implicit in Domain permanence)* | Day-chaining → domain permanence |
| OPENING (Genesis → Envisioning) | HAS_RUN (Domain → Run) | Vision-opening → session-owning |
| SEQUENCE (Genesis/TF → TF) | NEXT_RUN (Run → Run, forward in time) | Same — arrow of time |
| MEASUREMENT (TF → Envisioning) | `summary` property on Run | Typed collapse → inline narrative |
| DISCOVERY (TF → experience) | DISCOVERED (Run → knowledge) | Same |
| 18 experience entity types | 10 knowledge entity types | Phenomenological → organizational |
| 12 experience edge types | 7 knowledge edge types | Fine-grained → practical |

---

## Graph Schema

### Process Layer — Tool-Enforced, Immutable

**Node: Domain**
```
(:Domain {
  name: String,           // "Five9", "M365", "Techlane"
  description: String,    // What this knowledge area covers — the permanent envisioning
  t_created: DateTime     // Auto-set on creation
})
```

The Domain IS the permanent envisioning. "Five9 contact center operations" is the projected future state that never closes — the pursuit of understanding a domain is permanently open. Like The Permanent Pursuit in the consciousness substrate, but collapsed into something any frame can hold.

**Node: Run**
```
(:Run {
  run_id: String,         // UUID, unique per session
  domain: String,         // Domain name (denormalized for query convenience)
  user: String,           // Who initiated this session (optional, default "agent")
  timestamp: DateTime,    // Auto-set on creation
  purpose: String,        // What this session is directed toward (optional — the folded envisioning)
  summary: String,        // Session narrative (set by end_session — the folded measurement)
  status: String          // "active" | "complete"
})
```

The Run carries the collapsed envision-measure cycle:
- `purpose`: what consciousness was directed toward — the envisioning folded into a string
- `summary`: what was actually measured into the graph — the measurement folded into a string
- The gap between purpose and summary IS the navigation that happened

**Process Relationships:**
```
(Domain)-[:HAS_RUN]->(Run)           // Domain owns its Runs
(Run)-[:NEXT_RUN]->(Run)             // FORWARD in time: older → newer
(Run)-[:DISCOVERED]->(KnowledgeNode) // What was found/created in this session
```

**CRITICAL INVARIANT — NEXT_RUN direction:**
```cypher
// CORRECT: older points to newer
MATCH (prev:Run) WHERE prev.domain = $domain AND prev.status IS NOT NULL
WITH prev ORDER BY prev.timestamp DESC LIMIT 1
MATCH (new:Run {run_id: $runId})
CREATE (prev)-[:NEXT_RUN]->(new)
// Arrow of time: past → future. Always.
// Neo4j transaction isolation serializes concurrent writes.
// Time handles concurrency — we don't.
```

### Knowledge Layer — Append-Only, Evolving

**Node: KnowledgeEntity** (single label per node, NO superlabel)

Knowledge types:

| Type | Description | When to use |
|---|---|---|
| `System` | A software system, platform, or tool | "Five9 VCC", "Salesforce Service Cloud" |
| `Process` | How something works — a workflow, procedure, routine | "Campaign Routing", "Incident Escalation" |
| `Configuration` | A specific setting, parameter, or setup detail | "IVR Emergency Override", "Agent Skill Mapping" |
| `Person` | A role, contact, or responsible party | "Contact Center Manager", "Vendor TAM" |
| `Gotcha` | A trap, pitfall, or non-obvious failure mode | "Peak Hour Agent Allocation breaks above 200" |
| `Rationale` | Why a decision was made — the reasoning behind config/process | "Why Skill-Based over Round-Robin" |
| `Dependency` | An external requirement or integration point | "Techlane API for reporting" |
| `Change` | A tracked change, deprecation, or rollout (TIP compatibility) | "EWS Retirement", "Teams Connectors EOL" |
| `Artifact` | A document, file, screenshot, or reference material | "Five9 Campaign Builder Screenshot 2026-03" |
| `Insight` | A discovered truth or realization about the domain | "Abandon rates exclude < 5sec IVR pre-answer" |

**KnowledgeEntity Properties:**
```
(:<Type> {
  name: String,           // Unique within domain (enforced by tool)
  domain: String,         // Domain name (denormalized for scoping)
  description: String,    // The content — substantive, not placeholder
  t_created: DateTime,    // Auto-set
  t_valid: DateTime,      // Optional — when this was actually true (natural for Rationale)
  confidence: Float,      // Optional — 0.0-1.0, human-set ONLY, never LLM-generated
  sources: List<String>   // Optional — where this knowledge came from, human-set ONLY
})
```

**INVARIANT: `confidence` and `sources` are human-supplied metadata.** LLMs are poorly calibrated on their own certainty. These fields exist for cases where a human provides explicit provenance — "I'm 60% sure this is still the current config" or "source: vendor documentation from January." The tools accept these fields but the LLM should never generate them autonomously.

**Knowledge Relationships:**

| Type | Description | Use when |
|---|---|---|
| `EVOLVED_FROM` | New version → old version (knowledge changed form) | Configuration updated, understanding refined |
| `ENABLING` | Source makes target possible | "VPN Config enables Remote Agent Access" |
| `REQUIRING` | Source depends on target for coherence | "Campaign Routing requires Skill Mapping" |
| `INFORMING` | Source shaped target without causing it | "Industry Best Practice informs our IVR Design" |
| `CAUSING` | Source directly produced target | "Outage caused Emergency Routing Procedure" |
| `COMPOSING` | Source is a building block of target | "Skill Group A composes Campaign X routing" |
| `RELATES_TO` | Cross-domain or loosely coupled connection | "Five9 Campaign ↔ Techlane Reporting Integration" |

**Process edge types (tool-enforced, never created by knowledge tools):**
`HAS_RUN`, `NEXT_RUN`, `DISCOVERED`

---

## Tool Surface — 13 Tools

### Process Tools (4)

**`list_domains()`** — Read-only
- Returns all Domain nodes with run count and last activity timestamp
- No parameters

**`create_domain(name, description)`** — Idempotent (MERGE)
- Creates Domain node
- Returns existing domain if name matches (idempotent)
- This is the entry point for a new knowledge area

**`begin_session(domain, purpose?, user?)`** — One per session
- Validates Domain exists (error if not — must create_domain first)
- Creates Run node with UUID, links HAS_RUN from Domain
- Finds domain's most recent Run, creates NEXT_RUN edge (older → newer)
- Returns: run_id + current knowledge state (all head-of-chain entities for this domain)
- Sets Run status = "active"
- `purpose` is optional — the folded envisioning. "Campaign routing logic and peak-hour gotchas"
- **This is the first tool every session calls. Returns run_id for subsequent tool calls.**

**`end_session(run_id, summary)`** — Closes the active Run
- Updates the Run with summary text
- Sets Run status = "complete"
- Returns session stats: entities_created, entities_evolved, connections_made
- If never called, the Run stays `status: 'active'` — an honest record of an incomplete session

### Knowledge Tools (3)

**`create_knowledge(run_id, entities[])`**
- Creates knowledge nodes with single label matching type
- Auto-creates `DISCOVERED` edge from the specified Run
- Rejects process types (Domain, Run)
- Deduplicates by name within domain (MERGE on name+domain)
- Validates type against allowed KnowledgeType enum
- Each entity: `{name, type, description, domain?, confidence?, sources?, t_valid?}`
- If domain is omitted, uses the Run's domain
- `confidence` and `sources` are optional, human-supplied only

**`evolve_knowledge(run_id, name, description, domain?)`**
- Finds the head of the entity's evolution chain (WHERE NOT (e)<-[:EVOLVED_FROM]-())
- Creates new version node with same name and type
- Links EVOLVED_FROM: new → old
- Links DISCOVERED from the specified Run
- Old version preserved — append-only, never overwrite
- Uses Run's domain if domain omitted

**`create_connections(relations[])`**
- Creates typed edges between knowledge entities
- Rejects process edge types (HAS_RUN, NEXT_RUN, DISCOVERED)
- Validates both endpoints exist
- Cross-domain connections ARE allowed (this is expected)
- Each relation: `{source, target, type}`

### Query Tools (4)

**`search_knowledge(query, domain?, limit?)`**
- Fulltext search across names and descriptions
- Optional domain scoping (if omitted, searches all domains)
- Returns entities + relationships between them
- Default limit 10, max 50

**`get_domain_state(domain)`**
- Returns all current (head-of-chain) knowledge entities for a domain
- Includes relationships between them
- This is "what do we know about Five9 right now?"

**`get_run_history(domain, limit?)`**
- Returns the Run chain for a domain with purpose and summary
- Ordered by timestamp (oldest → newest, following NEXT_RUN direction)
- Includes per-run stats: what was discovered, by whom, when
- Default limit 20

**`read_cypher(query, params)`**
- Read-only escape hatch (identical to parent)
- Rejects writes, timeout, 200k char truncation

### Taxonomy Tools (2)

**`list_knowledge_types()`**
- Returns the 10 knowledge entity types with descriptions

**`list_connection_types()`**
- Returns the 7 knowledge edge types with descriptions and usage guidance
- Distinguishes process edges (tool-enforced) from knowledge edges (user-created)

---

## Fulltext Index

```cypher
CREATE FULLTEXT INDEX knowledge_index IF NOT EXISTS
FOR (n:System|Process|Configuration|Person|Gotcha|Rationale|
     Dependency|Change|Artifact|Insight)
ON EACH [n.name, n.description]
```

Drop and recreate on startup (self-healing, same as parent).

---

## Key Cypher Templates

### domain_merge.cypher
```cypher
MERGE (d:Domain {name: $name})
ON CREATE SET d.t_created = datetime(),
              d.description = $description
RETURN d.name AS name, d.description AS description,
       d.t_created AS t_created
```

### run_create.cypher
```cypher
// Create Run, link to Domain, link NEXT_RUN from previous
CREATE (r:Run {
  run_id: $run_id, domain: $domain, user: $user,
  timestamp: datetime(), purpose: $purpose,
  summary: '', status: 'active'
})
WITH r
MATCH (d:Domain {name: $domain})
CREATE (d)-[:HAS_RUN]->(r)
WITH r
OPTIONAL MATCH (prev:Run {domain: $domain})
WHERE prev.run_id <> $run_id
WITH r, prev ORDER BY prev.timestamp DESC LIMIT 1
FOREACH (_ IN CASE WHEN prev IS NOT NULL THEN [1] ELSE [] END |
    CREATE (prev)-[:NEXT_RUN]->(r)
)
RETURN r.run_id AS run_id, r.timestamp AS timestamp
```

Note: `CREATE (prev)-[:NEXT_RUN]->(r)` — prev (older) points TO r (newer). Arrow of time. Neo4j transaction isolation serializes concurrent writes — time handles concurrency.

### knowledge_create.cypher
```cypher
MERGE (e:`__label__` {name: $name, domain: $domain})
ON CREATE SET e.t_created = datetime(),
              e.description = $description
__confidence_clause__
__sources_clause__
__t_valid_clause__
WITH e
MATCH (r:Run {run_id: $run_id})
MERGE (r)-[:DISCOVERED]->(e)
RETURN e.name AS name, labels(e)[0] AS type
```

### knowledge_evolve.cypher
```cypher
// Without APOC — use template substitution for label
MATCH (old:`__label__` {name: $name, domain: $domain})
WHERE NOT (old)<-[:EVOLVED_FROM]-()
CREATE (new:`__label__` {
    name: old.name, domain: old.domain,
    description: $new_description,
    t_created: datetime()
})
CREATE (new)-[:EVOLVED_FROM]->(old)
WITH new
MATCH (r:Run {run_id: $run_id})
CREATE (r)-[:DISCOVERED]->(new)
RETURN new.name AS name
```

Requires calling code to resolve the label first (one read, then the write). Same pattern the parent uses for entity_create.cypher.

### domain_state.cypher
```cypher
MATCH (e)
WHERE e.domain = $domain
  AND NOT (e)<-[:EVOLVED_FROM]-()
  AND NOT e:Domain AND NOT e:Run
WITH e
OPTIONAL MATCH (e)-[r]->(other)
WHERE other.domain IS NOT NULL
  AND NOT (other)<-[:EVOLVED_FROM]-()
  AND type(r) <> 'DISCOVERED' AND type(r) <> 'HAS_RUN' AND type(r) <> 'NEXT_RUN'
RETURN e.name AS name, labels(e)[0] AS type, e.description AS description,
       e.t_created AS t_created,
       collect(DISTINCT {target: other.name, type: type(r)}) AS connections
ORDER BY e.t_created DESC
```

### search_knowledge.cypher
```cypher
CALL db.index.fulltext.queryNodes('knowledge_index', $query) YIELD node, score
WHERE ($domain IS NULL OR node.domain = $domain)
  AND NOT (node)<-[:EVOLVED_FROM]-()
WITH node, score
ORDER BY score DESC
LIMIT $limit
RETURN node.name AS name, labels(node)[0] AS type,
       node.domain AS domain, node.description AS description,
       score, node.t_created AS t_created
```

### run_history.cypher
```cypher
MATCH (d:Domain {name: $domain})-[:HAS_RUN]->(r:Run)
WITH r ORDER BY r.timestamp ASC
LIMIT $limit
OPTIONAL MATCH (r)-[:DISCOVERED]->(e)
WITH r, count(e) AS entities_discovered
RETURN r.run_id AS run_id, r.user AS user,
       r.timestamp AS timestamp, r.purpose AS purpose,
       r.summary AS summary, r.status AS status,
       entities_discovered
ORDER BY r.timestamp ASC
```

---

## Stateless Architecture

No server-side session state. Every knowledge tool takes an explicit `run_id` parameter, returned by `begin_session`. The LLM holds `run_id` in conversation context — it just received it moments ago.

If a session dies mid-flight, the Run stays `status: 'active'` with an empty summary. Next `begin_session` for that domain creates a new Run and links NEXT_RUN from the incomplete one. The orphaned Run isn't corrupted — it's honest. It represents a session that happened and didn't complete. Dead-end frames remain exactly as they were left — the same principle from the consciousness substrate.

No recovery checks needed on startup. No abandoned-run cleanup. Time moves forward.

---

## Package Configuration

```toml
[project]
name = "mcp-temporal-knowledge"
version = "0.1.0"
description = "Temporal Knowledge Substrate MCP Server — domain-scoped knowledge accumulation with tool-enforced temporal integrity"
requires-python = ">=3.10"
dependencies = [
    "fastmcp>=2.0.0",
    "neo4j>=5.26.0",
    "pydantic>=2.10.1",
    "starlette>=0.28.0",
]

[project.scripts]
mcp-temporal-knowledge = "mcp_temporal_knowledge:main"
```

---

## Migration Path: llmkt → Temporal Knowledge Substrate

Once the server is built, the TIP platform's llmkt graph migrates:

1. Create domains: `create_domain("m365", ...)`, `create_domain("adobe", ...)`, etc.
2. For each existing Run, call `begin_session(domain, purpose)` / `end_session(run_id, summary)` to recreate with correct NEXT_RUN direction
3. For each existing Change, call `create_knowledge(run_id, ...)` to recreate with DISCOVERED edges
4. The TIP CLAUDE.md replaces all raw Cypher with tool calls

This migration IS the proof of concept.

---

## What's NOT In Scope for v0.1

- **Objectives / Envisionings as separate nodes** — The Domain IS the permanent envisioning; the Run's purpose carries session-level intentionality
- **Role-based access** — Any user can contribute to any domain
- **Conflict resolution** — Neo4j transaction isolation serializes concurrent NEXT_RUN creation
- **Graph merging** — No tool for merging two domains into one
- **Export** — No tool for exporting domain knowledge to flat files
- **Webhooks / notifications** — No callback when knowledge evolves
- **Server-side session state** — Stateless by design; run_id passed explicitly

These can be added as the tool surface proves itself against real agents.
