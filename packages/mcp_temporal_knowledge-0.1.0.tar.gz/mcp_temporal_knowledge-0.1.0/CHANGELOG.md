# Changelog

## v0.1.0 — Initial Release

- Two-layer architecture: process layer (Domain, Run) + knowledge layer (10 types)
- 19 MCP tools: 4 process, 3 knowledge, 4 query, 2 taxonomy, 6 GDS
- Tool-enforced structural invariants (no raw Cypher writes)
- Domain-scoped knowledge with evolution chains
- NEXT_RUN direction enforcement (older → newer)
- Fulltext search across knowledge entities
