"""Allow running as `python -m model_diff`."""
from model_diff.cli import main

main()
