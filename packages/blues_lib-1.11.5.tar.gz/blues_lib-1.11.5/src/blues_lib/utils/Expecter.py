from typing import Any
from blues_lib.types.ability import AbilityExpect

class Expecter:
  @classmethod
  def to_be(cls, expect: AbilityExpect) -> bool:
    """Check if the result equals the expected value."""
    result = expect.get("result")
    value = expect.get("value")
    return result == value

  @classmethod
  def not_to_be(cls, expect: AbilityExpect) -> bool:
    """Check if the result does not equal the expected value."""
    result = expect.get("result")
    value = expect.get("value")
    return result != value

  @classmethod
  def to_equal(cls, expect: AbilityExpect) -> bool:
    """Check if the result deeply equals the expected value."""
    result = expect.get("result")
    value = expect.get("value")
    return result == value

  @classmethod
  def not_to_equal(cls, expect: AbilityExpect) -> bool:
    """Check if the result does not deeply equal the expected value."""
    result = expect.get("result")
    value = expect.get("value")
    return result != value

  @classmethod
  def to_be_null(cls, expect: AbilityExpect) -> bool:
    """Check if the result is None."""
    result = expect.get("result")
    return result is None

  @classmethod
  def not_to_be_null(cls, expect: AbilityExpect) -> bool:
    """Check if the result is not None."""
    result = expect.get("result")
    return result is not None

  @classmethod
  def to_be_truthy(cls, expect: AbilityExpect) -> bool:
    """Check if the result is truthy."""
    result = expect.get("result")
    return bool(result) is True

  @classmethod
  def not_to_be_truthy(cls, expect: AbilityExpect) -> bool:
    """Check if the result is not truthy."""
    result = expect.get("result")
    return bool(result) is False

  @classmethod
  def to_be_falsy(cls, expect: AbilityExpect) -> bool:
    """Check if the result is falsy."""
    result = expect.get("result")
    return bool(result) is False

  @classmethod
  def not_to_be_falsy(cls, expect: AbilityExpect) -> bool:
    """Check if the result is not falsy."""
    result = expect.get("result")
    return bool(result) is True

  @classmethod
  def to_be_greater_than(cls, expect: AbilityExpect) -> bool:
    """Check if the result is greater than the expected value."""
    result = expect.get("result")
    value = expect.get("value")
    return float(result) > float(value)

  @classmethod
  def not_to_be_greater_than(cls, expect: AbilityExpect) -> bool:
    """Check if the result is not greater than the expected value."""
    result = expect.get("result")
    value = expect.get("value")
    return not (float(result) > float(value))

  @classmethod
  def to_be_less_than(cls, expect: AbilityExpect) -> bool:
    """Check if the result is less than the expected value."""
    result = expect.get("result")
    value = expect.get("value")
    return float(result) < float(value)

  @classmethod
  def not_to_be_less_than(cls, expect: AbilityExpect) -> bool:
    """Check if the result is not less than the expected value."""
    result = expect.get("result")
    value = expect.get("value")
    return not (float(result) < float(value))

  @classmethod
  def to_be_greater_than_or_equal(cls, expect: AbilityExpect) -> bool:
    """Check if the result is greater than or equal to the expected value."""
    result = expect.get("result")
    value = expect.get("value")
    return float(result) >= float(value)

  @classmethod
  def not_to_be_greater_than_or_equal(cls, expect: AbilityExpect) -> bool:
    """Check if the result is not greater than or equal to the expected value."""
    result = expect.get("result")
    value = expect.get("value")
    return not (float(result) >= float(value))

  @classmethod
  def to_be_less_than_or_equal(cls, expect: AbilityExpect) -> bool:
    """Check if the result is less than or equal to the expected value."""
    result = expect.get("result")
    value = expect.get("value")
    return float(result) <= float(value)

  @classmethod
  def not_to_be_less_than_or_equal(cls, expect: AbilityExpect) -> bool:
    """Check if the result is not less than or equal to the expected value."""
    result = expect.get("result")
    value = expect.get("value")
    return not (float(result) <= float(value))

  @classmethod
  def to_contain(cls, expect: AbilityExpect) -> bool:
    """Check if the result contains the expected value."""
    result = expect.get("result")
    value = expect.get("value")
    return value in result

  @classmethod
  def not_to_contain(cls, expect: AbilityExpect) -> bool:
    """Check if the result does not contain the expected value."""
    result = expect.get("result")
    value = expect.get("value")
    return value not in result

  @classmethod
  def to_match(cls, expect: AbilityExpect) -> bool:
    """Check if the result matches the expected regex pattern."""
    import re
    result = expect.get("result")
    value = expect.get("value")
    return bool(re.search(value, result))

  @classmethod
  def not_to_match(cls, expect: AbilityExpect) -> bool:
    """Check if the result does not match the expected regex pattern."""
    import re
    result = expect.get("result")
    value = expect.get("value")
    return not bool(re.search(value, result))

  @classmethod
  def to_have_length(cls, expect: AbilityExpect) -> bool:
    """Check if the result has the expected length."""
    result = expect.get("result")
    value = expect.get("value")
    return len(result) == value

  @classmethod
  def not_to_have_length(cls, expect: AbilityExpect) -> bool:
    """Check if the result does not have the expected length."""
    result = expect.get("result")
    value = expect.get("value")
    return len(result) != value

  @classmethod
  def to_have_property(cls, expect: AbilityExpect) -> bool:
    """Check if the result has the expected property."""
    result = expect.get("result")
    value = expect.get("value")
    return value in result

  @classmethod
  def not_to_have_property(cls, expect: AbilityExpect) -> bool:
    """Check if the result does not have the expected property."""
    result = expect.get("result")
    value = expect.get("value")
    return value not in result
