from blues_lib.resources.ResourceManager import ResourceManager
from blues_lib.utils.hocon.render.BaseRenderer import BaseRenderer
from blues_lib.utils.MCPUri import MCPUri

class ResourceRenderer(BaseRenderer):

  def _render_str_node(self, value:str)->str:
    if MCPUri.is_uri(value):
      return ResourceManager.read(value)
    return value
