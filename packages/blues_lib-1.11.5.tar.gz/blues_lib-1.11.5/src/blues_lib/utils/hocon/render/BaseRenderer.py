from abc import abstractmethod
from typing import Any

class BaseRenderer():

  def __init__(self,template:dict):
    self._template = template
  
  def render(self)->dict:
    """递归替换所有占位符"""
    if not self._template:
      return self._template
    return self._render_node(self._template)
  
  def _render_node(self, node:Any)->Any:
    """递归遍历并替换占位符"""
    if isinstance(node, str):
      return self._render_str_node(node)
    elif isinstance(node, dict):
      # 创建新字典，不修改原对象
      return {key: self._render_node(value) for key, value in node.items()}
    elif isinstance(node, list):
      # 处理列表
      return [self._render_node(item) for item in node]
    else:
      # 其他类型直接返回
      return node
  
  @classmethod
  @abstractmethod
  def _render_str_node(cls, value:str)->str:
    """替换单个字符串中的占位符（要求完全匹配）"""
    pass