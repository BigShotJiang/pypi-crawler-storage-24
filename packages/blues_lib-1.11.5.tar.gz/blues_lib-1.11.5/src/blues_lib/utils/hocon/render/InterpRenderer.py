import re
from typing import Any
from blues_lib.utils.hocon.render.BaseRenderer import BaseRenderer

class InterpRenderer(BaseRenderer):
  '''
  replace the variable replace with the given values
  - single variable "{{var}}"
  - interpolate variable "name is {{name}}, age is {{age}}"
  '''  

  VAR_PATTERN = r"\{\{([a-zA-Z0-9_|:\-.]+)\}\}" # support val1||val2||val3

  def __init__(self,template:dict, variables:dict|None=None):
    self._template = template
    self._variables = variables
    self._unmatched_placeholder_policy = 'replace_with_none' # 'keep'

  def render(self)->dict:
    if not self._variables:
      return self._template
    return super().render()

  def render_by_self(self)->dict:
    self._variables = self._template.copy()
    self._unmatched_placeholder_policy = 'keep'
    return self.render()

  def _render_str_node(self, value:str)->Any:

    match = re.fullmatch(self.VAR_PATTERN, value)
    if match:
      # single variable replace, use the original value or None
      expr = match.group(1) 
      return self._get_full_var_value(expr)
    else:
      return self._interpolate(value)
    
  def _get_full_var_value(self, expr:str)->Any:
    if '||' not in expr:
      # 处理多个变量的情况
      return self._get_one_full_var_value(expr)
    else:
      # 处理单个变量
      sub_exprs = expr.split('||')
      for sub_expr in sub_exprs:
        value = self._get_one_full_var_value(sub_expr)
        if value is not None:
          return value
      return None

  def _get_one_full_var_value(self, expr:str)->Any:
    key, default = self._get_key_default(expr)
    return self._variables.get(key, default)
    
  def _interpolate(self, value:str)->str:
    # 处理包含多个占位符或其他文本的字符串
    def replace_match(match):
      expr = match.group(1)
      # 处理带默认值的情况: ${key:-default}
      return str(self._get_full_var_value(expr))
     
    return re.sub(self.VAR_PATTERN, replace_match, value)
  
  def _get_key_default(self, expr:str,as_string:bool=False)->tuple:
    # 处理带默认值的情况: {{key:-default}}
    if ':-' in expr:
      key, default = expr.split(':-', 1)
      value = default if as_string else self._get_raw_value(default)
      return key, value
    else:
      default = "{{"+expr+"}}" if self._unmatched_placeholder_policy == 'keep' else None
    return expr, default

  def _get_raw_value(self, value_str: str) -> Any|None:
    """
    将字符串转换为原始类型
    now ,don't support list and dict
    """
    lower_value = value_str.lower().strip()
    # 处理布尔值
    if lower_value == 'true':
      return True
    if lower_value == 'false':
      return False
    
    # 处理None
    if lower_value == 'none' or lower_value == 'null':
      return None
    
    # 处理数字
    try:
      num = int(value_str)
      return num
    except ValueError:
      try:
        num = float(value_str)
        return num
      except ValueError:
        pass
    # 默认返回字符串
    return value_str

