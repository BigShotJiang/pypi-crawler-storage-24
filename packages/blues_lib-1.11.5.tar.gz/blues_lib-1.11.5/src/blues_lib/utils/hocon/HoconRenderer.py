from blues_lib.utils.hocon.render.InterpRenderer import InterpRenderer
from blues_lib.utils.hocon.render.ResourceRenderer import ResourceRenderer

class HoconRenderer:
  '''
  Render a dict with variables, contains:
  - env : environment variables, such as ${PROJECT_ROOT}， it will be replaced by HOCON reader automatically
  - resource : support any type resources, contains definition/bizdata/schema/property
    - file: "definition://ability/login/account.conf"
    - property: "property://datetime/now"
  - interpolate : interpolate variables, such as {{name}}
  '''
  def __init__(self,template:dict,variables:dict|None=None):
    self._template = template
    self._variables = variables
    
  def render(self) -> dict:
    template = ResourceRenderer(self._template).render()
    return InterpRenderer(template, self._variables).render()
  
  def render_by_self(self) -> dict:
    template = ResourceRenderer(self._template).render()
    return InterpRenderer(template).render_by_self()
  
  def render_resource(self) -> dict:
    return ResourceRenderer(self._template).render()

  def render_interp(self) -> dict:
    return InterpRenderer(self._template, self._variables).render()

  def render_interp_by_self(self) -> dict:
    return InterpRenderer(self._template).render_by_self()